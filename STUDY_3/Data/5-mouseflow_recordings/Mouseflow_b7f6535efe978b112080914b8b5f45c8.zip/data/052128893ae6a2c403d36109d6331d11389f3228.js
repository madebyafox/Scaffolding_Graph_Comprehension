var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["052128893ae6a2c403d36109d6331d11389f3228"] = {
  "startTime": "2018-05-21T19:20:28.4387972Z",
  "websitePageUrl": "/16",
  "visitTime": 151462,
  "engagementTime": 104634,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1200,
  "tags": [
    "form-interact",
    "submit"
  ],
  "session": {
    "id": "b7f6535efe978b112080914b8b5f45c8",
    "created": "2018-05-21T19:20:28.4387972+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.181",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/16",
    "tags": [
      "form-interact",
      "submit"
    ],
    "variables": [
      "SID=WKBNA",
      "CONDITION=111"
    ],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "0f65f430f2d7edcac09f59f7b0fb948e",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/b7f6535efe978b112080914b8b5f45c8/play"
  },
  "events": [
    {
      "t": 0,
      "e": 0,
      "ty": 14,
      "x": 0,
      "y": 1199
    },
    {
      "t": 184,
      "e": 184,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 184,
      "e": 184,
      "ty": 1,
      "x": 0,
      "y": 16
    },
    {
      "t": 751,
      "e": 751,
      "ty": 41,
      "x": 56531,
      "y": 40440,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 800,
      "e": 800,
      "ty": 2,
      "x": 585,
      "y": 741
    },
    {
      "t": 1001,
      "e": 1001,
      "ty": 41,
      "x": 54845,
      "y": 40606,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 1201,
      "e": 1201,
      "ty": 2,
      "x": 586,
      "y": 741
    },
    {
      "t": 1251,
      "e": 1251,
      "ty": 41,
      "x": 54957,
      "y": 40606,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 1500,
      "e": 1500,
      "ty": 2,
      "x": 590,
      "y": 723
    },
    {
      "t": 1501,
      "e": 1501,
      "ty": 41,
      "x": 55407,
      "y": 39609,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 1601,
      "e": 1601,
      "ty": 2,
      "x": 594,
      "y": 715
    },
    {
      "t": 1700,
      "e": 1700,
      "ty": 2,
      "x": 594,
      "y": 714
    },
    {
      "t": 1748,
      "e": 1748,
      "ty": 6,
      "x": 527,
      "y": 577,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1750,
      "e": 1750,
      "ty": 41,
      "x": 48325,
      "y": 43904,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1797,
      "e": 1797,
      "ty": 7,
      "x": 428,
      "y": 501,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1799,
      "e": 1799,
      "ty": 2,
      "x": 428,
      "y": 501
    },
    {
      "t": 1900,
      "e": 1900,
      "ty": 2,
      "x": 379,
      "y": 482
    },
    {
      "t": 2000,
      "e": 2000,
      "ty": 2,
      "x": 381,
      "y": 499
    },
    {
      "t": 2001,
      "e": 2001,
      "ty": 41,
      "x": 31913,
      "y": 9983,
      "ta": "#.strategy > p"
    },
    {
      "t": 2015,
      "e": 2015,
      "ty": 6,
      "x": 396,
      "y": 526,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2081,
      "e": 2081,
      "ty": 7,
      "x": 450,
      "y": 613,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2100,
      "e": 2100,
      "ty": 2,
      "x": 454,
      "y": 616
    },
    {
      "t": 2200,
      "e": 2200,
      "ty": 2,
      "x": 456,
      "y": 617
    },
    {
      "t": 2251,
      "e": 2251,
      "ty": 41,
      "x": 40344,
      "y": 63387,
      "ta": "> div.stimulus > div > div:[2]"
    },
    {
      "t": 2366,
      "e": 2366,
      "ty": 6,
      "x": 459,
      "y": 593,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2399,
      "e": 2399,
      "ty": 2,
      "x": 462,
      "y": 579
    },
    {
      "t": 2500,
      "e": 2500,
      "ty": 2,
      "x": 463,
      "y": 569
    },
    {
      "t": 2501,
      "e": 2501,
      "ty": 41,
      "x": 41131,
      "y": 37432,
      "ta": "#strategyAnswer"
    },
    {
      "t": 3045,
      "e": 3045,
      "ty": 3,
      "x": 463,
      "y": 569,
      "ta": "#strategyAnswer"
    },
    {
      "t": 3047,
      "e": 3047,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 3228,
      "e": 3228,
      "ty": 4,
      "x": 41131,
      "y": 37432,
      "ta": "#strategyAnswer"
    },
    {
      "t": 3228,
      "e": 3228,
      "ty": 5,
      "x": 463,
      "y": 569,
      "ta": "#strategyAnswer"
    },
    {
      "t": 3877,
      "e": 3877,
      "ty": 3,
      "x": 463,
      "y": 569,
      "ta": "#strategyAnswer"
    },
    {
      "t": 3996,
      "e": 3996,
      "ty": 4,
      "x": 41131,
      "y": 37432,
      "ta": "#strategyAnswer"
    },
    {
      "t": 3996,
      "e": 3996,
      "ty": 5,
      "x": 463,
      "y": 569,
      "ta": "#strategyAnswer"
    },
    {
      "t": 5895,
      "e": 5895,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 6393,
      "e": 6393,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 6426,
      "e": 6426,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 6460,
      "e": 6460,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 6492,
      "e": 6492,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 6525,
      "e": 6525,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 6559,
      "e": 6559,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 6592,
      "e": 6592,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 6625,
      "e": 6625,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 6658,
      "e": 6658,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 6691,
      "e": 6691,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 6724,
      "e": 6724,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 6757,
      "e": 6757,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 6790,
      "e": 6790,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 6823,
      "e": 6823,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 6856,
      "e": 6856,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 6888,
      "e": 6888,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 6921,
      "e": 6921,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 6954,
      "e": 6954,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 6987,
      "e": 6987,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 7020,
      "e": 7020,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 7053,
      "e": 7053,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 7087,
      "e": 7087,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 7120,
      "e": 7120,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 7153,
      "e": 7153,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 7183,
      "e": 7183,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 7183,
      "e": 7183,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 7311,
      "e": 7311,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "S"
    },
    {
      "t": 7335,
      "e": 7335,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "S"
    },
    {
      "t": 7574,
      "e": 7574,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 7574,
      "e": 7574,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 7750,
      "e": 7750,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "St"
    },
    {
      "t": 7806,
      "e": 7806,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 7807,
      "e": 7807,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8002,
      "e": 8002,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Sta"
    },
    {
      "t": 8007,
      "e": 8007,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Sta"
    },
    {
      "t": 8142,
      "e": 8142,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 8142,
      "e": 8142,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8303,
      "e": 8303,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Star"
    },
    {
      "t": 8422,
      "e": 8422,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 8423,
      "e": 8423,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8590,
      "e": 8590,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 8607,
      "e": 8607,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 8607,
      "e": 8607,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8757,
      "e": 8757,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 8798,
      "e": 8798,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 8798,
      "e": 8798,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8901,
      "e": 8901,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 8902,
      "e": 8902,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8958,
      "e": 8958,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||at"
    },
    {
      "t": 9062,
      "e": 9062,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 9206,
      "e": 9206,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 9207,
      "e": 9207,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9358,
      "e": 9358,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 10000,
      "e": 10000,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 11551,
      "e": 11551,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 11552,
      "e": 11552,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11654,
      "e": 11654,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 11654,
      "e": 11654,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11750,
      "e": 11750,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||12"
    },
    {
      "t": 11823,
      "e": 11823,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 12510,
      "e": 12510,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 12511,
      "e": 12511,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12670,
      "e": 12670,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 12838,
      "e": 12838,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 12840,
      "e": 12840,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12966,
      "e": 12966,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 13406,
      "e": 13406,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 13406,
      "e": 13406,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13518,
      "e": 13518,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 13998,
      "e": 13998,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 13998,
      "e": 13998,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14174,
      "e": 14174,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 14230,
      "e": 14230,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 14231,
      "e": 14231,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14318,
      "e": 14318,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 14432,
      "e": 14432,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 14433,
      "e": 14433,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14525,
      "e": 14525,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 14582,
      "e": 14582,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 14582,
      "e": 14582,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14751,
      "e": 14751,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 14751,
      "e": 14751,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14774,
      "e": 14774,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||th"
    },
    {
      "t": 14918,
      "e": 14918,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 14918,
      "e": 14918,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14925,
      "e": 14925,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 15046,
      "e": 15046,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 15062,
      "e": 15062,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 15062,
      "e": 15062,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15183,
      "e": 15183,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 17271,
      "e": 17271,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 17272,
      "e": 17272,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17402,
      "e": 17402,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Start at 12pm on the h"
    },
    {
      "t": 17430,
      "e": 17430,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 17454,
      "e": 17454,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 17455,
      "e": 17455,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17591,
      "e": 17591,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 17592,
      "e": 17592,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 17592,
      "e": 17592,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17718,
      "e": 17718,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 17750,
      "e": 17750,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 17750,
      "e": 17750,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17846,
      "e": 17846,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 17878,
      "e": 17878,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "90"
    },
    {
      "t": 17880,
      "e": 17880,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17981,
      "e": 17981,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 17982,
      "e": 17982,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18014,
      "e": 18014,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||zo"
    },
    {
      "t": 18135,
      "e": 18135,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 18135,
      "e": 18135,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18174,
      "e": 18174,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 18285,
      "e": 18285,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 18286,
      "e": 18286,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18310,
      "e": 18310,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 18422,
      "e": 18422,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 18463,
      "e": 18463,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 18463,
      "e": 18463,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18603,
      "e": 18603,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Start at 12pm on the horizonta"
    },
    {
      "t": 18606,
      "e": 18606,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 18607,
      "e": 18607,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18630,
      "e": 18630,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||al"
    },
    {
      "t": 18750,
      "e": 18750,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 18846,
      "e": 18846,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 18846,
      "e": 18846,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18974,
      "e": 18974,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 19287,
      "e": 19287,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 19288,
      "e": 19288,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19401,
      "e": 19401,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Start at 12pm on the horizontal a"
    },
    {
      "t": 19421,
      "e": 19421,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 19725,
      "e": 19725,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 19726,
      "e": 19726,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19886,
      "e": 19886,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||x"
    },
    {
      "t": 19894,
      "e": 19894,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 19894,
      "e": 19894,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20000,
      "e": 20000,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 20001,
      "e": 20001,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Start at 12pm on the horizontal axi"
    },
    {
      "t": 20006,
      "e": 20006,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 20037,
      "e": 20037,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 20037,
      "e": 20037,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20181,
      "e": 20181,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 21526,
      "e": 21526,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "188"
    },
    {
      "t": 21528,
      "e": 21528,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21638,
      "e": 21638,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||,"
    },
    {
      "t": 21799,
      "e": 21799,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 21799,
      "e": 21799,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21894,
      "e": 21894,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 21982,
      "e": 21982,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 21982,
      "e": 21982,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22110,
      "e": 22110,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 22112,
      "e": 22112,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 22112,
      "e": 22112,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22221,
      "e": 22221,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 22222,
      "e": 22222,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22229,
      "e": 22229,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||nd"
    },
    {
      "t": 22342,
      "e": 22342,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 22343,
      "e": 22343,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22350,
      "e": 22350,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 22430,
      "e": 22430,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 22686,
      "e": 22686,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 22687,
      "e": 22687,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22801,
      "e": 22801,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Start at 12pm on the horizontal axis, and t"
    },
    {
      "t": 22862,
      "e": 22862,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 22863,
      "e": 22863,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22878,
      "e": 22878,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||th"
    },
    {
      "t": 23001,
      "e": 23001,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Start at 12pm on the horizontal axis, and th"
    },
    {
      "t": 23006,
      "e": 23006,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 23047,
      "e": 23047,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 23047,
      "e": 23047,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23198,
      "e": 23198,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 23206,
      "e": 23206,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 23206,
      "e": 23206,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23317,
      "e": 23317,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 23422,
      "e": 23422,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 23422,
      "e": 23422,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23510,
      "e": 23510,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 24622,
      "e": 24622,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 24622,
      "e": 24622,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24803,
      "e": 24803,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Start at 12pm on the horizontal axis, and then f"
    },
    {
      "t": 24823,
      "e": 24823,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||f"
    },
    {
      "t": 25101,
      "e": 25101,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 25102,
      "e": 25102,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25229,
      "e": 25229,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 25414,
      "e": 25414,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 25415,
      "e": 25415,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25526,
      "e": 25526,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 25646,
      "e": 25646,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 25647,
      "e": 25647,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25774,
      "e": 25774,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 26006,
      "e": 26006,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 26007,
      "e": 26007,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26149,
      "e": 26149,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 26150,
      "e": 26150,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26166,
      "e": 26166,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ow"
    },
    {
      "t": 26247,
      "e": 26247,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 26287,
      "e": 26287,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 26287,
      "e": 26287,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26365,
      "e": 26365,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 26445,
      "e": 26445,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 26447,
      "e": 26447,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26602,
      "e": 26602,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Start at 12pm on the horizontal axis, and then follow t"
    },
    {
      "t": 26638,
      "e": 26638,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 26686,
      "e": 26686,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 26687,
      "e": 26687,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26801,
      "e": 26801,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Start at 12pm on the horizontal axis, and then follow th"
    },
    {
      "t": 26822,
      "e": 26822,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 26822,
      "e": 26822,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26838,
      "e": 26838,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||he"
    },
    {
      "t": 26934,
      "e": 26934,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 26935,
      "e": 26935,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26966,
      "e": 26966,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 27038,
      "e": 27038,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 27358,
      "e": 27358,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 27361,
      "e": 27361,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27445,
      "e": 27445,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 27734,
      "e": 27734,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 27736,
      "e": 27736,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27878,
      "e": 27878,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 27878,
      "e": 27878,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 27878,
      "e": 27878,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28002,
      "e": 28002,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Start at 12pm on the horizontal axis, and then follow the lin"
    },
    {
      "t": 28023,
      "e": 28023,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 28071,
      "e": 28071,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 28073,
      "e": 28073,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28201,
      "e": 28201,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Start at 12pm on the horizontal axis, and then follow the line"
    },
    {
      "t": 28222,
      "e": 28222,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 28222,
      "e": 28222,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28238,
      "e": 28238,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e "
    },
    {
      "t": 28318,
      "e": 28318,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 28422,
      "e": 28422,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 28423,
      "e": 28423,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28559,
      "e": 28559,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 28559,
      "e": 28559,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28566,
      "e": 28566,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||an"
    },
    {
      "t": 28718,
      "e": 28718,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 29510,
      "e": 29510,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 29511,
      "e": 29511,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29669,
      "e": 29669,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 29686,
      "e": 29686,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 29687,
      "e": 29687,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29801,
      "e": 29801,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Start at 12pm on the horizontal axis, and then follow the line angl"
    },
    {
      "t": 29838,
      "e": 29838,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 29839,
      "e": 29839,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29853,
      "e": 29853,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||le"
    },
    {
      "t": 29966,
      "e": 29966,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 29967,
      "e": 29967,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30039,
      "e": 30039,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 30085,
      "e": 30085,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 30149,
      "e": 30149,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 30150,
      "e": 30150,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30254,
      "e": 30254,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 31111,
      "e": 31111,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 31111,
      "e": 31111,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31222,
      "e": 31222,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 31222,
      "e": 31222,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31285,
      "e": 31285,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||to"
    },
    {
      "t": 31366,
      "e": 31366,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 31367,
      "e": 31367,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31398,
      "e": 31398,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||w"
    },
    {
      "t": 31517,
      "e": 31517,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 31518,
      "e": 31518,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31533,
      "e": 31533,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 31614,
      "e": 31614,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 31616,
      "e": 31616,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31662,
      "e": 31662,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 31733,
      "e": 31733,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 31831,
      "e": 31831,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 31831,
      "e": 31831,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31934,
      "e": 31934,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 31957,
      "e": 31957,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 31957,
      "e": 31957,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32053,
      "e": 32053,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 32126,
      "e": 32126,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 32126,
      "e": 32126,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32238,
      "e": 32238,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 32239,
      "e": 32239,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32286,
      "e": 32286,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||th"
    },
    {
      "t": 32341,
      "e": 32341,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 32341,
      "e": 32341,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32373,
      "e": 32373,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 32430,
      "e": 32430,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 32430,
      "e": 32430,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32478,
      "e": 32478,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 32550,
      "e": 32550,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 32598,
      "e": 32598,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 32599,
      "e": 32599,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32701,
      "e": 32701,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 32702,
      "e": 32702,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32758,
      "e": 32758,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ri"
    },
    {
      "t": 32846,
      "e": 32846,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 32854,
      "e": 32854,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 32855,
      "e": 32855,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32973,
      "e": 32973,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 32997,
      "e": 32997,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 32997,
      "e": 32997,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33102,
      "e": 33102,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 33103,
      "e": 33103,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 33103,
      "e": 33103,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33214,
      "e": 33214,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 33254,
      "e": 33254,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "190"
    },
    {
      "t": 33255,
      "e": 33255,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33382,
      "e": 33382,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||."
    },
    {
      "t": 33470,
      "e": 33470,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 33470,
      "e": 33470,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33533,
      "e": 33533,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 34377,
      "e": 34377,
      "ty": 7,
      "x": 590,
      "y": 649,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34400,
      "e": 34400,
      "ty": 2,
      "x": 675,
      "y": 722
    },
    {
      "t": 34499,
      "e": 34499,
      "ty": 2,
      "x": 1021,
      "y": 1062
    },
    {
      "t": 34500,
      "e": 34500,
      "ty": 41,
      "x": 34885,
      "y": 58388,
      "ta": "> div.stimulus"
    },
    {
      "t": 34599,
      "e": 34599,
      "ty": 2,
      "x": 1256,
      "y": 1073
    },
    {
      "t": 34700,
      "e": 34700,
      "ty": 2,
      "x": 1228,
      "y": 930
    },
    {
      "t": 34749,
      "e": 34749,
      "ty": 41,
      "x": 29668,
      "y": 56152,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 34799,
      "e": 34799,
      "ty": 2,
      "x": 1147,
      "y": 939
    },
    {
      "t": 34899,
      "e": 34899,
      "ty": 2,
      "x": 1126,
      "y": 991
    },
    {
      "t": 35000,
      "e": 35000,
      "ty": 2,
      "x": 1154,
      "y": 973
    },
    {
      "t": 35000,
      "e": 35000,
      "ty": 41,
      "x": 34130,
      "y": 16639,
      "ta": "> div.stimulus > div:[2] > svg > g > g:[3] > g:[9] > text"
    },
    {
      "t": 35099,
      "e": 35099,
      "ty": 2,
      "x": 1159,
      "y": 964
    },
    {
      "t": 35250,
      "e": 35250,
      "ty": 41,
      "x": 26285,
      "y": 59303,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 35300,
      "e": 35300,
      "ty": 2,
      "x": 1159,
      "y": 968
    },
    {
      "t": 35400,
      "e": 35400,
      "ty": 2,
      "x": 1151,
      "y": 961
    },
    {
      "t": 35500,
      "e": 35500,
      "ty": 2,
      "x": 1150,
      "y": 960
    },
    {
      "t": 35501,
      "e": 35501,
      "ty": 41,
      "x": 25651,
      "y": 58874,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 35800,
      "e": 35800,
      "ty": 2,
      "x": 1149,
      "y": 959
    },
    {
      "t": 35900,
      "e": 35900,
      "ty": 2,
      "x": 1151,
      "y": 954
    },
    {
      "t": 36001,
      "e": 36001,
      "ty": 41,
      "x": 25721,
      "y": 58444,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 36099,
      "e": 36099,
      "ty": 2,
      "x": 1155,
      "y": 943
    },
    {
      "t": 36250,
      "e": 36250,
      "ty": 41,
      "x": 26144,
      "y": 57441,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 36299,
      "e": 36299,
      "ty": 2,
      "x": 1159,
      "y": 938
    },
    {
      "t": 36400,
      "e": 36400,
      "ty": 2,
      "x": 1159,
      "y": 937
    },
    {
      "t": 36500,
      "e": 36500,
      "ty": 41,
      "x": 26285,
      "y": 57226,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 36601,
      "e": 36501,
      "ty": 2,
      "x": 1160,
      "y": 937
    },
    {
      "t": 36750,
      "e": 36650,
      "ty": 41,
      "x": 26356,
      "y": 57226,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 36899,
      "e": 36799,
      "ty": 2,
      "x": 1160,
      "y": 939
    },
    {
      "t": 37001,
      "e": 36901,
      "ty": 41,
      "x": 26356,
      "y": 57369,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 37500,
      "e": 37400,
      "ty": 2,
      "x": 1174,
      "y": 938
    },
    {
      "t": 37501,
      "e": 37401,
      "ty": 41,
      "x": 27342,
      "y": 57298,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 37699,
      "e": 37599,
      "ty": 2,
      "x": 1172,
      "y": 944
    },
    {
      "t": 37750,
      "e": 37650,
      "ty": 41,
      "x": 27060,
      "y": 58157,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 37800,
      "e": 37700,
      "ty": 2,
      "x": 1170,
      "y": 950
    },
    {
      "t": 37900,
      "e": 37800,
      "ty": 2,
      "x": 1167,
      "y": 955
    },
    {
      "t": 38000,
      "e": 37900,
      "ty": 2,
      "x": 1158,
      "y": 966
    },
    {
      "t": 38000,
      "e": 37900,
      "ty": 41,
      "x": 26215,
      "y": 59303,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 38250,
      "e": 38150,
      "ty": 41,
      "x": 26144,
      "y": 59375,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 38300,
      "e": 38200,
      "ty": 2,
      "x": 1155,
      "y": 965
    },
    {
      "t": 38400,
      "e": 38300,
      "ty": 2,
      "x": 1153,
      "y": 964
    },
    {
      "t": 40199,
      "e": 40099,
      "ty": 2,
      "x": 1163,
      "y": 959
    },
    {
      "t": 40250,
      "e": 40150,
      "ty": 41,
      "x": 26849,
      "y": 58587,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 40300,
      "e": 40200,
      "ty": 2,
      "x": 1171,
      "y": 953
    },
    {
      "t": 40500,
      "e": 40400,
      "ty": 2,
      "x": 1131,
      "y": 946
    },
    {
      "t": 40500,
      "e": 40400,
      "ty": 41,
      "x": 24312,
      "y": 57871,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 40600,
      "e": 40500,
      "ty": 2,
      "x": 551,
      "y": 712
    },
    {
      "t": 40615,
      "e": 40515,
      "ty": 6,
      "x": 446,
      "y": 664,
      "ta": "#strategyButton"
    },
    {
      "t": 40630,
      "e": 40530,
      "ty": 7,
      "x": 352,
      "y": 625,
      "ta": "#strategyButton"
    },
    {
      "t": 40647,
      "e": 40547,
      "ty": 6,
      "x": 284,
      "y": 586,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40700,
      "e": 40600,
      "ty": 2,
      "x": 226,
      "y": 525
    },
    {
      "t": 40713,
      "e": 40613,
      "ty": 7,
      "x": 225,
      "y": 512,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40750,
      "e": 40650,
      "ty": 41,
      "x": 14040,
      "y": 4422,
      "ta": "> div.stimulus > div > div:[2]"
    },
    {
      "t": 40800,
      "e": 40700,
      "ty": 2,
      "x": 222,
      "y": 483
    },
    {
      "t": 40900,
      "e": 40800,
      "ty": 2,
      "x": 219,
      "y": 483
    },
    {
      "t": 41000,
      "e": 40900,
      "ty": 2,
      "x": 209,
      "y": 510
    },
    {
      "t": 41000,
      "e": 40900,
      "ty": 41,
      "x": 12579,
      "y": 35729,
      "ta": "#.strategy > p"
    },
    {
      "t": 41099,
      "e": 40999,
      "ty": 2,
      "x": 200,
      "y": 515
    },
    {
      "t": 41181,
      "e": 41081,
      "ty": 6,
      "x": 198,
      "y": 522,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41200,
      "e": 41100,
      "ty": 2,
      "x": 198,
      "y": 525
    },
    {
      "t": 41250,
      "e": 41150,
      "ty": 41,
      "x": 11342,
      "y": 5878,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41299,
      "e": 41199,
      "ty": 2,
      "x": 198,
      "y": 531
    },
    {
      "t": 41401,
      "e": 41301,
      "ty": 2,
      "x": 198,
      "y": 532
    },
    {
      "t": 41500,
      "e": 41400,
      "ty": 41,
      "x": 11342,
      "y": 7496,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41601,
      "e": 41501,
      "ty": 2,
      "x": 193,
      "y": 534
    },
    {
      "t": 41700,
      "e": 41600,
      "ty": 2,
      "x": 192,
      "y": 534
    },
    {
      "t": 41750,
      "e": 41650,
      "ty": 41,
      "x": 10555,
      "y": 9923,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41800,
      "e": 41700,
      "ty": 2,
      "x": 191,
      "y": 535
    },
    {
      "t": 41829,
      "e": 41729,
      "ty": 3,
      "x": 191,
      "y": 535,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41956,
      "e": 41856,
      "ty": 4,
      "x": 10555,
      "y": 9923,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41956,
      "e": 41856,
      "ty": 5,
      "x": 191,
      "y": 535,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42614,
      "e": 42514,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "39"
    },
    {
      "t": 42749,
      "e": 42649,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 43015,
      "e": 42915,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 43117,
      "e": 43017,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Start at 12p on the horizontal axis, and then follow the line angled toward the right. "
    },
    {
      "t": 43214,
      "e": 43114,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 43286,
      "e": 43186,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Start at 12 on the horizontal axis, and then follow the line angled toward the right. "
    },
    {
      "t": 43366,
      "e": 43266,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 43367,
      "e": 43267,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43493,
      "e": 43393,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Start at 12  on the horizontal axis, and then follow the line angled toward the right. "
    },
    {
      "t": 43614,
      "e": 43514,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 43934,
      "e": 43834,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 43934,
      "e": 43834,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44062,
      "e": 43962,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 44062,
      "e": 43962,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44069,
      "e": 43969,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Start at 12 PM on the horizontal axis, and then follow the line angled toward the right. "
    },
    {
      "t": 44174,
      "e": 44074,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 44278,
      "e": 44178,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 45200,
      "e": 45100,
      "ty": 2,
      "x": 192,
      "y": 544
    },
    {
      "t": 45251,
      "e": 45151,
      "ty": 41,
      "x": 12017,
      "y": 21250,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45301,
      "e": 45201,
      "ty": 2,
      "x": 205,
      "y": 549
    },
    {
      "t": 45400,
      "e": 45300,
      "ty": 2,
      "x": 205,
      "y": 550
    },
    {
      "t": 45421,
      "e": 45321,
      "ty": 3,
      "x": 205,
      "y": 550,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45500,
      "e": 45400,
      "ty": 41,
      "x": 12129,
      "y": 22059,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45571,
      "e": 45471,
      "ty": 4,
      "x": 12129,
      "y": 22059,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45572,
      "e": 45472,
      "ty": 5,
      "x": 205,
      "y": 550,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49997,
      "e": 49897,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 52796,
      "e": 50472,
      "ty": 2,
      "x": 322,
      "y": 590
    },
    {
      "t": 52804,
      "e": 50480,
      "ty": 7,
      "x": 379,
      "y": 612,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52897,
      "e": 50573,
      "ty": 2,
      "x": 474,
      "y": 653
    },
    {
      "t": 52997,
      "e": 50673,
      "ty": 2,
      "x": 389,
      "y": 619
    },
    {
      "t": 52997,
      "e": 50673,
      "ty": 41,
      "x": 32813,
      "y": 64294,
      "ta": "> div.stimulus > div > div:[2]"
    },
    {
      "t": 53098,
      "e": 50774,
      "ty": 2,
      "x": 355,
      "y": 614
    },
    {
      "t": 53172,
      "e": 50848,
      "ty": 6,
      "x": 396,
      "y": 657,
      "ta": "#strategyButton"
    },
    {
      "t": 53196,
      "e": 50872,
      "ty": 2,
      "x": 402,
      "y": 659
    },
    {
      "t": 53246,
      "e": 50922,
      "ty": 41,
      "x": 38996,
      "y": 12076,
      "ta": "#strategyButton"
    },
    {
      "t": 53296,
      "e": 50972,
      "ty": 2,
      "x": 410,
      "y": 661
    },
    {
      "t": 53396,
      "e": 51072,
      "ty": 2,
      "x": 378,
      "y": 670
    },
    {
      "t": 53497,
      "e": 51173,
      "ty": 2,
      "x": 366,
      "y": 671
    },
    {
      "t": 53497,
      "e": 51173,
      "ty": 41,
      "x": 14967,
      "y": 31351,
      "ta": "#strategyButton"
    },
    {
      "t": 53696,
      "e": 51372,
      "ty": 2,
      "x": 367,
      "y": 670
    },
    {
      "t": 53747,
      "e": 51423,
      "ty": 41,
      "x": 16059,
      "y": 29424,
      "ta": "#strategyButton"
    },
    {
      "t": 53797,
      "e": 51473,
      "ty": 2,
      "x": 368,
      "y": 670
    },
    {
      "t": 59997,
      "e": 56473,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 62002,
      "e": 56473,
      "ty": 3,
      "x": 368,
      "y": 670,
      "ta": "#strategyButton"
    },
    {
      "t": 62004,
      "e": 56475,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Start at 12 PM on the horizontal axis, and then follow the line angled toward the right. "
    },
    {
      "t": 62005,
      "e": 56476,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 62005,
      "e": 56476,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 62160,
      "e": 56631,
      "ty": 4,
      "x": 16059,
      "y": 29424,
      "ta": "#strategyButton"
    },
    {
      "t": 62172,
      "e": 56643,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 62174,
      "e": 56645,
      "ty": 5,
      "x": 368,
      "y": 670,
      "ta": "#strategyButton"
    },
    {
      "t": 62179,
      "e": 56650,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 62697,
      "e": 57168,
      "ty": 2,
      "x": 368,
      "y": 648
    },
    {
      "t": 62747,
      "e": 57218,
      "ty": 41,
      "x": 12328,
      "y": 34789,
      "ta": "html > body"
    },
    {
      "t": 62797,
      "e": 57268,
      "ty": 2,
      "x": 355,
      "y": 604
    },
    {
      "t": 62897,
      "e": 57368,
      "ty": 2,
      "x": 333,
      "y": 544
    },
    {
      "t": 62997,
      "e": 57468,
      "ty": 2,
      "x": 331,
      "y": 539
    },
    {
      "t": 62997,
      "e": 57468,
      "ty": 41,
      "x": 11123,
      "y": 29415,
      "ta": "html > body"
    },
    {
      "t": 63097,
      "e": 57568,
      "ty": 2,
      "x": 327,
      "y": 530
    },
    {
      "t": 63181,
      "e": 57652,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 63247,
      "e": 57718,
      "ty": 41,
      "x": 10985,
      "y": 28917,
      "ta": "html > body"
    },
    {
      "t": 63497,
      "e": 57968,
      "ty": 2,
      "x": 315,
      "y": 524
    },
    {
      "t": 63497,
      "e": 57968,
      "ty": 41,
      "x": 10572,
      "y": 28585,
      "ta": "html > body"
    },
    {
      "t": 63597,
      "e": 58068,
      "ty": 2,
      "x": 333,
      "y": 524
    },
    {
      "t": 63697,
      "e": 58168,
      "ty": 2,
      "x": 729,
      "y": 581
    },
    {
      "t": 63747,
      "e": 58218,
      "ty": 41,
      "x": 27481,
      "y": 32573,
      "ta": "html > body"
    },
    {
      "t": 63796,
      "e": 58267,
      "ty": 2,
      "x": 812,
      "y": 599
    },
    {
      "t": 63897,
      "e": 58368,
      "ty": 2,
      "x": 831,
      "y": 592
    },
    {
      "t": 63946,
      "e": 58417,
      "ty": 6,
      "x": 863,
      "y": 571,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 63997,
      "e": 58468,
      "ty": 2,
      "x": 869,
      "y": 567
    },
    {
      "t": 63998,
      "e": 58469,
      "ty": 41,
      "x": 13193,
      "y": 40569,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 64153,
      "e": 58624,
      "ty": 3,
      "x": 869,
      "y": 567,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 64154,
      "e": 58625,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 64288,
      "e": 58759,
      "ty": 4,
      "x": 13193,
      "y": 40569,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 64289,
      "e": 58760,
      "ty": 5,
      "x": 869,
      "y": 567,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 65858,
      "e": 60329,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "49"
    },
    {
      "t": 65858,
      "e": 60329,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 65998,
      "e": 60469,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "1"
    },
    {
      "t": 66027,
      "e": 60498,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "1"
    },
    {
      "t": 66051,
      "e": 60522,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "57"
    },
    {
      "t": 66052,
      "e": 60523,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 66199,
      "e": 60670,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "19"
    },
    {
      "t": 66242,
      "e": 60713,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "19"
    },
    {
      "t": 66347,
      "e": 60818,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "9"
    },
    {
      "t": 66348,
      "e": 60819,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "19"
    },
    {
      "t": 66348,
      "e": 60819,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 66349,
      "e": 60820,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 66482,
      "e": 60953,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": ""
    },
    {
      "t": 66819,
      "e": 61290,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 67107,
      "e": 61578,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "85"
    },
    {
      "t": 67107,
      "e": 61578,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 67185,
      "e": 61656,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "U"
    },
    {
      "t": 67217,
      "e": 61688,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "U"
    },
    {
      "t": 67282,
      "e": 61753,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "78"
    },
    {
      "t": 67283,
      "e": 61754,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 67399,
      "e": 61870,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Un"
    },
    {
      "t": 67426,
      "e": 61897,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Un"
    },
    {
      "t": 67451,
      "e": 61922,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "73"
    },
    {
      "t": 67451,
      "e": 61922,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 67554,
      "e": 62025,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "84"
    },
    {
      "t": 67554,
      "e": 62025,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 67586,
      "e": 62057,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Unit"
    },
    {
      "t": 67707,
      "e": 62178,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 67722,
      "e": 62193,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "69"
    },
    {
      "t": 67723,
      "e": 62194,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 67866,
      "e": 62337,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "68"
    },
    {
      "t": 67866,
      "e": 62337,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 67938,
      "e": 62409,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||ed"
    },
    {
      "t": 68018,
      "e": 62489,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "32"
    },
    {
      "t": 68019,
      "e": 62490,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 68026,
      "e": 62497,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+|| "
    },
    {
      "t": 68083,
      "e": 62554,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 68186,
      "e": 62657,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 68291,
      "e": 62762,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "83"
    },
    {
      "t": 68291,
      "e": 62762,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 68398,
      "e": 62869,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "United S"
    },
    {
      "t": 68409,
      "e": 62880,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||S"
    },
    {
      "t": 68426,
      "e": 62897,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 68546,
      "e": 63017,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "84"
    },
    {
      "t": 68547,
      "e": 63018,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 68673,
      "e": 63144,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||t"
    },
    {
      "t": 68698,
      "e": 63169,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "65"
    },
    {
      "t": 68699,
      "e": 63170,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 68842,
      "e": 63313,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "84"
    },
    {
      "t": 68843,
      "e": 63314,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 68874,
      "e": 63345,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||at"
    },
    {
      "t": 68970,
      "e": 63441,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "69"
    },
    {
      "t": 68971,
      "e": 63442,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 69018,
      "e": 63489,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||e"
    },
    {
      "t": 69114,
      "e": 63585,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 69171,
      "e": 63642,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "83"
    },
    {
      "t": 69171,
      "e": 63642,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 69298,
      "e": 63769,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||s"
    },
    {
      "t": 69685,
      "e": 64156,
      "ty": 7,
      "x": 887,
      "y": 575,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 69698,
      "e": 64169,
      "ty": 2,
      "x": 887,
      "y": 575
    },
    {
      "t": 69747,
      "e": 64218,
      "ty": 41,
      "x": 19249,
      "y": 35108,
      "ta": "#jspsych-survey-text-1 > p"
    },
    {
      "t": 69797,
      "e": 64268,
      "ty": 2,
      "x": 911,
      "y": 640
    },
    {
      "t": 69851,
      "e": 64322,
      "ty": 6,
      "x": 923,
      "y": 652,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 69885,
      "e": 64356,
      "ty": 7,
      "x": 937,
      "y": 670,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 69897,
      "e": 64368,
      "ty": 2,
      "x": 937,
      "y": 670
    },
    {
      "t": 69919,
      "e": 64390,
      "ty": 6,
      "x": 943,
      "y": 676,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 69997,
      "e": 64468,
      "ty": 2,
      "x": 947,
      "y": 680
    },
    {
      "t": 69998,
      "e": 64469,
      "ty": 41,
      "x": 26325,
      "y": 7943,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 69998,
      "e": 64469,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 70097,
      "e": 64568,
      "ty": 2,
      "x": 950,
      "y": 686
    },
    {
      "t": 70136,
      "e": 64607,
      "ty": 3,
      "x": 950,
      "y": 686,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 70137,
      "e": 64608,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "United States"
    },
    {
      "t": 70137,
      "e": 64608,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 70137,
      "e": 64608,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 70247,
      "e": 64718,
      "ty": 41,
      "x": 27871,
      "y": 19859,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 70281,
      "e": 64752,
      "ty": 4,
      "x": 27871,
      "y": 19859,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 70283,
      "e": 64754,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 70283,
      "e": 64754,
      "ty": 5,
      "x": 950,
      "y": 686,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 70284,
      "e": 64755,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 71299,
      "e": 65770,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 71797,
      "e": 66268,
      "ty": 2,
      "x": 950,
      "y": 653
    },
    {
      "t": 71898,
      "e": 66369,
      "ty": 2,
      "x": 921,
      "y": 548
    },
    {
      "t": 71997,
      "e": 66468,
      "ty": 2,
      "x": 881,
      "y": 415
    },
    {
      "t": 71997,
      "e": 66468,
      "ty": 41,
      "x": 14139,
      "y": 32767,
      "ta": "#jspsych-survey-multi-choice-option-1-0"
    },
    {
      "t": 72097,
      "e": 66568,
      "ty": 2,
      "x": 867,
      "y": 370
    },
    {
      "t": 72197,
      "e": 66668,
      "ty": 2,
      "x": 847,
      "y": 337
    },
    {
      "t": 72237,
      "e": 66708,
      "ty": 6,
      "x": 839,
      "y": 300,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 72247,
      "e": 66718,
      "ty": 41,
      "x": 63408,
      "y": 60493,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 72271,
      "e": 66742,
      "ty": 7,
      "x": 837,
      "y": 278,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 72286,
      "e": 66757,
      "ty": 6,
      "x": 836,
      "y": 263,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 72297,
      "e": 66768,
      "ty": 2,
      "x": 836,
      "y": 263
    },
    {
      "t": 72303,
      "e": 66774,
      "ty": 7,
      "x": 834,
      "y": 249,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 72397,
      "e": 66868,
      "ty": 2,
      "x": 827,
      "y": 210
    },
    {
      "t": 72497,
      "e": 66968,
      "ty": 41,
      "x": 1323,
      "y": 12858,
      "ta": "#jspsych-survey-multi-choice-0"
    },
    {
      "t": 72697,
      "e": 67168,
      "ty": 2,
      "x": 826,
      "y": 217
    },
    {
      "t": 72748,
      "e": 67219,
      "ty": 41,
      "x": 1086,
      "y": 17420,
      "ta": "#jspsych-survey-multi-choice-0"
    },
    {
      "t": 72797,
      "e": 67268,
      "ty": 2,
      "x": 825,
      "y": 224
    },
    {
      "t": 72872,
      "e": 67343,
      "ty": 6,
      "x": 827,
      "y": 232,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 72897,
      "e": 67368,
      "ty": 2,
      "x": 829,
      "y": 233
    },
    {
      "t": 72997,
      "e": 67468,
      "ty": 2,
      "x": 830,
      "y": 236
    },
    {
      "t": 72998,
      "e": 67469,
      "ty": 41,
      "x": 18037,
      "y": 20164,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 73097,
      "e": 67568,
      "ty": 2,
      "x": 832,
      "y": 240
    },
    {
      "t": 73198,
      "e": 67669,
      "ty": 2,
      "x": 833,
      "y": 242
    },
    {
      "t": 73248,
      "e": 67719,
      "ty": 41,
      "x": 33161,
      "y": 50411,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 74098,
      "e": 68569,
      "ty": 2,
      "x": 833,
      "y": 236
    },
    {
      "t": 74197,
      "e": 68668,
      "ty": 2,
      "x": 833,
      "y": 232
    },
    {
      "t": 74247,
      "e": 68718,
      "ty": 41,
      "x": 33161,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 74457,
      "e": 68928,
      "ty": 3,
      "x": 833,
      "y": 232,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 74457,
      "e": 68928,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 74640,
      "e": 69111,
      "ty": 4,
      "x": 33161,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 74640,
      "e": 69111,
      "ty": 5,
      "x": 833,
      "y": 232,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 74640,
      "e": 69111,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf",
      "v": "English"
    },
    {
      "t": 74961,
      "e": 69432,
      "ty": 7,
      "x": 846,
      "y": 239,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 74997,
      "e": 69468,
      "ty": 2,
      "x": 869,
      "y": 252
    },
    {
      "t": 74997,
      "e": 69468,
      "ty": 41,
      "x": 11291,
      "y": 63194,
      "ta": "#jspsych-survey-multi-choice-option-0-0"
    },
    {
      "t": 75097,
      "e": 69568,
      "ty": 2,
      "x": 904,
      "y": 280
    },
    {
      "t": 75197,
      "e": 69668,
      "ty": 2,
      "x": 906,
      "y": 300
    },
    {
      "t": 75248,
      "e": 69719,
      "ty": 41,
      "x": 26506,
      "y": 58981,
      "ta": "#jspsych-survey-multi-choice-option-0-2 > label"
    },
    {
      "t": 75298,
      "e": 69769,
      "ty": 2,
      "x": 906,
      "y": 303
    },
    {
      "t": 75397,
      "e": 69868,
      "ty": 2,
      "x": 899,
      "y": 321
    },
    {
      "t": 75498,
      "e": 69969,
      "ty": 2,
      "x": 892,
      "y": 333
    },
    {
      "t": 75498,
      "e": 69969,
      "ty": 41,
      "x": 16749,
      "y": 56172,
      "ta": "#jspsych-survey-multi-choice-option-0-3"
    },
    {
      "t": 75597,
      "e": 70068,
      "ty": 2,
      "x": 885,
      "y": 342
    },
    {
      "t": 75698,
      "e": 70169,
      "ty": 2,
      "x": 872,
      "y": 352
    },
    {
      "t": 75748,
      "e": 70219,
      "ty": 41,
      "x": 11291,
      "y": 14422,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 75797,
      "e": 70268,
      "ty": 2,
      "x": 868,
      "y": 357
    },
    {
      "t": 75898,
      "e": 70369,
      "ty": 2,
      "x": 864,
      "y": 366
    },
    {
      "t": 75997,
      "e": 70468,
      "ty": 2,
      "x": 864,
      "y": 367
    },
    {
      "t": 75998,
      "e": 70469,
      "ty": 41,
      "x": 10104,
      "y": 28086,
      "ta": "#jspsych-survey-multi-choice-1 > p"
    },
    {
      "t": 76098,
      "e": 70569,
      "ty": 2,
      "x": 862,
      "y": 380
    },
    {
      "t": 76248,
      "e": 70719,
      "ty": 41,
      "x": 9630,
      "y": 58513,
      "ta": "#jspsych-survey-multi-choice-1 > p"
    },
    {
      "t": 76497,
      "e": 70968,
      "ty": 2,
      "x": 862,
      "y": 388
    },
    {
      "t": 76498,
      "e": 70969,
      "ty": 41,
      "x": 9630,
      "y": 8936,
      "ta": "#jspsych-survey-multi-choice-1"
    },
    {
      "t": 76598,
      "e": 71069,
      "ty": 2,
      "x": 862,
      "y": 399
    },
    {
      "t": 76748,
      "e": 71219,
      "ty": 41,
      "x": 9630,
      "y": 11915,
      "ta": "#jspsych-survey-multi-choice-1"
    },
    {
      "t": 76898,
      "e": 71369,
      "ty": 2,
      "x": 863,
      "y": 399
    },
    {
      "t": 76998,
      "e": 71469,
      "ty": 2,
      "x": 864,
      "y": 398
    },
    {
      "t": 76998,
      "e": 71469,
      "ty": 41,
      "x": 10104,
      "y": 11644,
      "ta": "#jspsych-survey-multi-choice-1"
    },
    {
      "t": 79247,
      "e": 73718,
      "ty": 41,
      "x": 10104,
      "y": 12186,
      "ta": "#jspsych-survey-multi-choice-1"
    },
    {
      "t": 79296,
      "e": 73767,
      "ty": 2,
      "x": 863,
      "y": 404
    },
    {
      "t": 79396,
      "e": 73867,
      "ty": 2,
      "x": 863,
      "y": 412
    },
    {
      "t": 79497,
      "e": 73968,
      "ty": 2,
      "x": 859,
      "y": 421
    },
    {
      "t": 79497,
      "e": 73968,
      "ty": 41,
      "x": 43988,
      "y": 52428,
      "ta": "#jspsych-survey-multi-choice-option-1-0 > label"
    },
    {
      "t": 79596,
      "e": 74067,
      "ty": 2,
      "x": 858,
      "y": 422
    },
    {
      "t": 79696,
      "e": 74167,
      "ty": 2,
      "x": 856,
      "y": 429
    },
    {
      "t": 79746,
      "e": 74217,
      "ty": 41,
      "x": 8206,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-1-1"
    },
    {
      "t": 79896,
      "e": 74367,
      "ty": 2,
      "x": 856,
      "y": 433
    },
    {
      "t": 79996,
      "e": 74467,
      "ty": 41,
      "x": 27619,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-1-1 > label"
    },
    {
      "t": 80097,
      "e": 74568,
      "ty": 2,
      "x": 853,
      "y": 435
    },
    {
      "t": 80196,
      "e": 74667,
      "ty": 2,
      "x": 853,
      "y": 437
    },
    {
      "t": 80246,
      "e": 74717,
      "ty": 41,
      "x": 25223,
      "y": 13107,
      "ta": "#jspsych-survey-multi-choice-option-1-1 > label"
    },
    {
      "t": 80577,
      "e": 75048,
      "ty": 6,
      "x": 838,
      "y": 438,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 80596,
      "e": 75067,
      "ty": 2,
      "x": 833,
      "y": 438
    },
    {
      "t": 80697,
      "e": 75168,
      "ty": 2,
      "x": 827,
      "y": 438
    },
    {
      "t": 80747,
      "e": 75218,
      "ty": 41,
      "x": 2914,
      "y": 10082,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 81078,
      "e": 75549,
      "ty": 7,
      "x": 830,
      "y": 435,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 81097,
      "e": 75568,
      "ty": 2,
      "x": 833,
      "y": 434
    },
    {
      "t": 81196,
      "e": 75667,
      "ty": 2,
      "x": 834,
      "y": 433
    },
    {
      "t": 81246,
      "e": 75717,
      "ty": 41,
      "x": 10046,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-1-1 > label"
    },
    {
      "t": 81997,
      "e": 76468,
      "ty": 2,
      "x": 834,
      "y": 428
    },
    {
      "t": 81997,
      "e": 76468,
      "ty": 41,
      "x": 2985,
      "y": 63194,
      "ta": "#jspsych-survey-multi-choice-option-1-0"
    },
    {
      "t": 82097,
      "e": 76568,
      "ty": 2,
      "x": 840,
      "y": 422
    },
    {
      "t": 82247,
      "e": 76718,
      "ty": 41,
      "x": 21747,
      "y": 55704,
      "ta": "#jspsych-survey-multi-choice-option-1-0 > label"
    },
    {
      "t": 82396,
      "e": 76867,
      "ty": 6,
      "x": 839,
      "y": 442,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 82396,
      "e": 76867,
      "ty": 2,
      "x": 839,
      "y": 442
    },
    {
      "t": 82481,
      "e": 76952,
      "ty": 7,
      "x": 839,
      "y": 449,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 82496,
      "e": 76967,
      "ty": 2,
      "x": 839,
      "y": 452
    },
    {
      "t": 82496,
      "e": 76967,
      "ty": 41,
      "x": 14040,
      "y": 62258,
      "ta": "#jspsych-survey-multi-choice-option-1-1 > label"
    },
    {
      "t": 82596,
      "e": 77067,
      "ty": 2,
      "x": 840,
      "y": 466
    },
    {
      "t": 82747,
      "e": 77218,
      "ty": 41,
      "x": 19637,
      "y": 36044,
      "ta": "#jspsych-survey-multi-choice-option-1-2 > label"
    },
    {
      "t": 82797,
      "e": 77268,
      "ty": 2,
      "x": 840,
      "y": 478
    },
    {
      "t": 82896,
      "e": 77367,
      "ty": 2,
      "x": 841,
      "y": 479
    },
    {
      "t": 82996,
      "e": 77467,
      "ty": 2,
      "x": 841,
      "y": 484
    },
    {
      "t": 82997,
      "e": 77468,
      "ty": 41,
      "x": 4646,
      "y": 63194,
      "ta": "#jspsych-survey-multi-choice-option-1-2"
    },
    {
      "t": 83097,
      "e": 77568,
      "ty": 2,
      "x": 842,
      "y": 486
    },
    {
      "t": 83196,
      "e": 77667,
      "ty": 2,
      "x": 843,
      "y": 486
    },
    {
      "t": 83247,
      "e": 77718,
      "ty": 41,
      "x": 5358,
      "y": 63194,
      "ta": "#jspsych-survey-multi-choice-option-1-2"
    },
    {
      "t": 83296,
      "e": 77767,
      "ty": 2,
      "x": 846,
      "y": 470
    },
    {
      "t": 83397,
      "e": 77868,
      "ty": 2,
      "x": 846,
      "y": 456
    },
    {
      "t": 83497,
      "e": 77968,
      "ty": 41,
      "x": 5832,
      "y": 63194,
      "ta": "#jspsych-survey-multi-choice-option-1-1"
    },
    {
      "t": 83597,
      "e": 78068,
      "ty": 2,
      "x": 846,
      "y": 452
    },
    {
      "t": 83747,
      "e": 78218,
      "ty": 41,
      "x": 19631,
      "y": 62258,
      "ta": "#jspsych-survey-multi-choice-option-1-1 > label"
    },
    {
      "t": 83897,
      "e": 78368,
      "ty": 2,
      "x": 845,
      "y": 439
    },
    {
      "t": 83997,
      "e": 78468,
      "ty": 41,
      "x": 16436,
      "y": 3276,
      "ta": "#jspsych-survey-multi-choice-option-1-1 > label"
    },
    {
      "t": 83997,
      "e": 78468,
      "ty": 2,
      "x": 842,
      "y": 434
    },
    {
      "t": 84097,
      "e": 78568,
      "ty": 2,
      "x": 840,
      "y": 434
    },
    {
      "t": 84197,
      "e": 78668,
      "ty": 2,
      "x": 835,
      "y": 435
    },
    {
      "t": 84247,
      "e": 78718,
      "ty": 41,
      "x": 10845,
      "y": 6553,
      "ta": "#jspsych-survey-multi-choice-option-1-1 > label"
    },
    {
      "t": 84569,
      "e": 79040,
      "ty": 6,
      "x": 835,
      "y": 436,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 84597,
      "e": 79068,
      "ty": 2,
      "x": 834,
      "y": 437
    },
    {
      "t": 84696,
      "e": 79167,
      "ty": 2,
      "x": 829,
      "y": 445
    },
    {
      "t": 84747,
      "e": 79218,
      "ty": 41,
      "x": 12996,
      "y": 45370,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 85018,
      "e": 79489,
      "ty": 3,
      "x": 829,
      "y": 445,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 85019,
      "e": 79490,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 85019,
      "e": 79490,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 85199,
      "e": 79670,
      "ty": 4,
      "x": 12996,
      "y": 45370,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 85199,
      "e": 79670,
      "ty": 5,
      "x": 829,
      "y": 445,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 85199,
      "e": 79670,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf",
      "v": "Second"
    },
    {
      "t": 85537,
      "e": 80008,
      "ty": 7,
      "x": 830,
      "y": 457,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 85548,
      "e": 80019,
      "ty": 6,
      "x": 834,
      "y": 469,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 85565,
      "e": 80036,
      "ty": 7,
      "x": 846,
      "y": 496,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 85596,
      "e": 80067,
      "ty": 2,
      "x": 869,
      "y": 549
    },
    {
      "t": 85696,
      "e": 80167,
      "ty": 2,
      "x": 929,
      "y": 712
    },
    {
      "t": 85749,
      "e": 80169,
      "ty": 41,
      "x": 31016,
      "y": 42597,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 85797,
      "e": 80217,
      "ty": 2,
      "x": 946,
      "y": 735
    },
    {
      "t": 85897,
      "e": 80317,
      "ty": 2,
      "x": 939,
      "y": 701
    },
    {
      "t": 85997,
      "e": 80417,
      "ty": 2,
      "x": 874,
      "y": 576
    },
    {
      "t": 85997,
      "e": 80417,
      "ty": 41,
      "x": 52195,
      "y": 9830,
      "ta": "#jspsych-survey-multi-choice-option-1-6 > label"
    },
    {
      "t": 86096,
      "e": 80516,
      "ty": 2,
      "x": 862,
      "y": 559
    },
    {
      "t": 86197,
      "e": 80617,
      "ty": 2,
      "x": 914,
      "y": 715
    },
    {
      "t": 86247,
      "e": 80667,
      "ty": 41,
      "x": 23486,
      "y": 22937,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 86297,
      "e": 80717,
      "ty": 2,
      "x": 915,
      "y": 728
    },
    {
      "t": 86397,
      "e": 80817,
      "ty": 2,
      "x": 904,
      "y": 725
    },
    {
      "t": 86497,
      "e": 80917,
      "ty": 2,
      "x": 895,
      "y": 723
    },
    {
      "t": 86498,
      "e": 80918,
      "ty": 41,
      "x": 18467,
      "y": 6553,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 86597,
      "e": 81017,
      "ty": 2,
      "x": 890,
      "y": 717
    },
    {
      "t": 86697,
      "e": 81117,
      "ty": 2,
      "x": 869,
      "y": 714
    },
    {
      "t": 86747,
      "e": 81167,
      "ty": 41,
      "x": 11054,
      "y": 58513,
      "ta": "#jspsych-survey-multi-choice-option-2-1"
    },
    {
      "t": 86796,
      "e": 81216,
      "ty": 2,
      "x": 868,
      "y": 714
    },
    {
      "t": 86897,
      "e": 81317,
      "ty": 2,
      "x": 870,
      "y": 729
    },
    {
      "t": 86997,
      "e": 81417,
      "ty": 2,
      "x": 873,
      "y": 733
    },
    {
      "t": 86997,
      "e": 81417,
      "ty": 41,
      "x": 12945,
      "y": 39321,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 87096,
      "e": 81516,
      "ty": 2,
      "x": 875,
      "y": 755
    },
    {
      "t": 87197,
      "e": 81617,
      "ty": 2,
      "x": 873,
      "y": 763
    },
    {
      "t": 87247,
      "e": 81667,
      "ty": 41,
      "x": 21521,
      "y": 55704,
      "ta": "#jspsych-survey-multi-choice-option-2-3 > label"
    },
    {
      "t": 87297,
      "e": 81717,
      "ty": 2,
      "x": 873,
      "y": 770
    },
    {
      "t": 87497,
      "e": 81917,
      "ty": 2,
      "x": 870,
      "y": 749
    },
    {
      "t": 87497,
      "e": 81917,
      "ty": 41,
      "x": 20269,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-2-3 > label"
    },
    {
      "t": 87597,
      "e": 82017,
      "ty": 2,
      "x": 866,
      "y": 744
    },
    {
      "t": 87697,
      "e": 82117,
      "ty": 2,
      "x": 844,
      "y": 705
    },
    {
      "t": 87747,
      "e": 82167,
      "ty": 41,
      "x": 5689,
      "y": 39321,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 87897,
      "e": 82317,
      "ty": 2,
      "x": 839,
      "y": 695
    },
    {
      "t": 87997,
      "e": 82417,
      "ty": 41,
      "x": 4429,
      "y": 6553,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 88096,
      "e": 82516,
      "ty": 2,
      "x": 839,
      "y": 689
    },
    {
      "t": 88197,
      "e": 82617,
      "ty": 2,
      "x": 839,
      "y": 688
    },
    {
      "t": 88247,
      "e": 82667,
      "ty": 41,
      "x": 4171,
      "y": 63194,
      "ta": "#jspsych-survey-multi-choice-option-2-0"
    },
    {
      "t": 88397,
      "e": 82817,
      "ty": 2,
      "x": 839,
      "y": 687
    },
    {
      "t": 88497,
      "e": 82917,
      "ty": 41,
      "x": 4171,
      "y": 60853,
      "ta": "#jspsych-survey-multi-choice-option-2-0"
    },
    {
      "t": 88747,
      "e": 83167,
      "ty": 41,
      "x": 3934,
      "y": 58513,
      "ta": "#jspsych-survey-multi-choice-option-2-0"
    },
    {
      "t": 88797,
      "e": 83217,
      "ty": 2,
      "x": 836,
      "y": 686
    },
    {
      "t": 88870,
      "e": 83290,
      "ty": 6,
      "x": 834,
      "y": 696,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 88897,
      "e": 83317,
      "ty": 2,
      "x": 833,
      "y": 697
    },
    {
      "t": 88997,
      "e": 83417,
      "ty": 2,
      "x": 833,
      "y": 699
    },
    {
      "t": 88997,
      "e": 83417,
      "ty": 41,
      "x": 33161,
      "y": 15123,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 89197,
      "e": 83617,
      "ty": 2,
      "x": 831,
      "y": 702
    },
    {
      "t": 89247,
      "e": 83667,
      "ty": 41,
      "x": 23079,
      "y": 30246,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 89297,
      "e": 83717,
      "ty": 2,
      "x": 831,
      "y": 703
    },
    {
      "t": 89456,
      "e": 83876,
      "ty": 3,
      "x": 831,
      "y": 703,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 89457,
      "e": 83877,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 89457,
      "e": 83877,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 89497,
      "e": 83917,
      "ty": 41,
      "x": 23079,
      "y": 35288,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 89608,
      "e": 84028,
      "ty": 4,
      "x": 23079,
      "y": 35288,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 89609,
      "e": 84029,
      "ty": 5,
      "x": 831,
      "y": 703,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 89609,
      "e": 84029,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf",
      "v": "Social Sciences (incl. CogSci)"
    },
    {
      "t": 89869,
      "e": 84289,
      "ty": 7,
      "x": 838,
      "y": 711,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 89897,
      "e": 84317,
      "ty": 2,
      "x": 849,
      "y": 723
    },
    {
      "t": 89996,
      "e": 84416,
      "ty": 2,
      "x": 930,
      "y": 790
    },
    {
      "t": 89997,
      "e": 84417,
      "ty": 41,
      "x": 60785,
      "y": 42597,
      "ta": "#jspsych-survey-multi-choice-option-2-4 > label"
    },
    {
      "t": 90097,
      "e": 84517,
      "ty": 2,
      "x": 965,
      "y": 825
    },
    {
      "t": 90197,
      "e": 84617,
      "ty": 2,
      "x": 966,
      "y": 833
    },
    {
      "t": 90248,
      "e": 84618,
      "ty": 41,
      "x": 34311,
      "y": 49151,
      "ta": "#jspsych-survey-multi-choice-option-2-6"
    },
    {
      "t": 90297,
      "e": 84667,
      "ty": 2,
      "x": 964,
      "y": 876
    },
    {
      "t": 90397,
      "e": 84767,
      "ty": 2,
      "x": 957,
      "y": 892
    },
    {
      "t": 90497,
      "e": 84867,
      "ty": 2,
      "x": 925,
      "y": 921
    },
    {
      "t": 90498,
      "e": 84868,
      "ty": 41,
      "x": 24581,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-3-0"
    },
    {
      "t": 90597,
      "e": 84967,
      "ty": 2,
      "x": 902,
      "y": 925
    },
    {
      "t": 90697,
      "e": 85067,
      "ty": 2,
      "x": 884,
      "y": 927
    },
    {
      "t": 90747,
      "e": 85117,
      "ty": 41,
      "x": 37767,
      "y": 6553,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 90797,
      "e": 85167,
      "ty": 2,
      "x": 834,
      "y": 927
    },
    {
      "t": 90836,
      "e": 85206,
      "ty": 6,
      "x": 831,
      "y": 936,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 90853,
      "e": 85223,
      "ty": 7,
      "x": 831,
      "y": 944,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 90886,
      "e": 85256,
      "ty": 6,
      "x": 831,
      "y": 959,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 90897,
      "e": 85267,
      "ty": 2,
      "x": 831,
      "y": 959
    },
    {
      "t": 90997,
      "e": 85367,
      "ty": 2,
      "x": 831,
      "y": 966
    },
    {
      "t": 90998,
      "e": 85368,
      "ty": 41,
      "x": 23079,
      "y": 50411,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 91097,
      "e": 85467,
      "ty": 2,
      "x": 837,
      "y": 964
    },
    {
      "t": 91248,
      "e": 85618,
      "ty": 41,
      "x": 53325,
      "y": 40329,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 91297,
      "e": 85667,
      "ty": 2,
      "x": 836,
      "y": 964
    },
    {
      "t": 91361,
      "e": 85731,
      "ty": 3,
      "x": 836,
      "y": 964,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 91362,
      "e": 85732,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 91363,
      "e": 85733,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 91497,
      "e": 85867,
      "ty": 41,
      "x": 48284,
      "y": 40329,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 91536,
      "e": 85906,
      "ty": 4,
      "x": 48284,
      "y": 40329,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 91536,
      "e": 85906,
      "ty": 5,
      "x": 836,
      "y": 964,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 91537,
      "e": 85907,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf",
      "v": "Female"
    },
    {
      "t": 91697,
      "e": 86067,
      "ty": 2,
      "x": 834,
      "y": 964
    },
    {
      "t": 91747,
      "e": 86117,
      "ty": 41,
      "x": 33161,
      "y": 40329,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 91797,
      "e": 86167,
      "ty": 2,
      "x": 833,
      "y": 964
    },
    {
      "t": 91889,
      "e": 86259,
      "ty": 7,
      "x": 832,
      "y": 970,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 91897,
      "e": 86267,
      "ty": 2,
      "x": 832,
      "y": 970
    },
    {
      "t": 91997,
      "e": 86367,
      "ty": 2,
      "x": 844,
      "y": 978
    },
    {
      "t": 91997,
      "e": 86367,
      "ty": 41,
      "x": 5358,
      "y": 2340,
      "ta": "#jspsych-survey-multi-choice-option-3-2"
    },
    {
      "t": 92097,
      "e": 86467,
      "ty": 2,
      "x": 862,
      "y": 998
    },
    {
      "t": 92197,
      "e": 86567,
      "ty": 2,
      "x": 865,
      "y": 1001
    },
    {
      "t": 92247,
      "e": 86617,
      "ty": 41,
      "x": 10579,
      "y": 56172,
      "ta": "#jspsych-survey-multi-choice-option-3-2"
    },
    {
      "t": 92273,
      "e": 86643,
      "ty": 6,
      "x": 869,
      "y": 1005,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 92297,
      "e": 86667,
      "ty": 2,
      "x": 871,
      "y": 1007
    },
    {
      "t": 92397,
      "e": 86767,
      "ty": 2,
      "x": 875,
      "y": 1014
    },
    {
      "t": 92497,
      "e": 86867,
      "ty": 41,
      "x": 23490,
      "y": 17873,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 92998,
      "e": 87368,
      "ty": 2,
      "x": 875,
      "y": 1018
    },
    {
      "t": 92998,
      "e": 87368,
      "ty": 41,
      "x": 23490,
      "y": 25816,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 93097,
      "e": 87467,
      "ty": 2,
      "x": 874,
      "y": 1022
    },
    {
      "t": 93247,
      "e": 87617,
      "ty": 41,
      "x": 22975,
      "y": 33760,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 93457,
      "e": 87827,
      "ty": 3,
      "x": 874,
      "y": 1022,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 93458,
      "e": 87828,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 93458,
      "e": 87828,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 93656,
      "e": 88026,
      "ty": 4,
      "x": 22975,
      "y": 33760,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 93657,
      "e": 88027,
      "ty": 5,
      "x": 874,
      "y": 1022,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 93661,
      "e": 88031,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 93662,
      "e": 88032,
      "ty": 13,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 93664,
      "e": 88034,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 94197,
      "e": 88567,
      "ty": 2,
      "x": 869,
      "y": 1013
    },
    {
      "t": 94248,
      "e": 88618,
      "ty": 41,
      "x": 28858,
      "y": 53513,
      "ta": "html > body"
    },
    {
      "t": 94297,
      "e": 88667,
      "ty": 2,
      "x": 844,
      "y": 971
    },
    {
      "t": 94397,
      "e": 88767,
      "ty": 2,
      "x": 844,
      "y": 968
    },
    {
      "t": 94497,
      "e": 88867,
      "ty": 2,
      "x": 846,
      "y": 942
    },
    {
      "t": 94497,
      "e": 88867,
      "ty": 41,
      "x": 28858,
      "y": 51741,
      "ta": "html > body"
    },
    {
      "t": 94697,
      "e": 89067,
      "ty": 2,
      "x": 848,
      "y": 938
    },
    {
      "t": 94747,
      "e": 89117,
      "ty": 41,
      "x": 28927,
      "y": 51519,
      "ta": "html > body"
    },
    {
      "t": 94897,
      "e": 89267,
      "ty": 2,
      "x": 848,
      "y": 937
    },
    {
      "t": 94987,
      "e": 89357,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 94997,
      "e": 89367,
      "ty": 2,
      "x": 848,
      "y": 936
    },
    {
      "t": 94997,
      "e": 89367,
      "ty": 41,
      "x": 27282,
      "y": 56069,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 99897,
      "e": 94267,
      "ty": 2,
      "x": 833,
      "y": 933
    },
    {
      "t": 99997,
      "e": 94367,
      "ty": 2,
      "x": 828,
      "y": 933
    },
    {
      "t": 99997,
      "e": 94367,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 100000,
      "e": 94370,
      "ty": 41,
      "x": 26298,
      "y": 55862,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 100097,
      "e": 94467,
      "ty": 2,
      "x": 818,
      "y": 928
    },
    {
      "t": 100196,
      "e": 94566,
      "ty": 2,
      "x": 813,
      "y": 926
    },
    {
      "t": 100247,
      "e": 94617,
      "ty": 41,
      "x": 24527,
      "y": 53992,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 100296,
      "e": 94666,
      "ty": 2,
      "x": 762,
      "y": 811
    },
    {
      "t": 100398,
      "e": 94768,
      "ty": 2,
      "x": 694,
      "y": 656
    },
    {
      "t": 100497,
      "e": 94867,
      "ty": 2,
      "x": 662,
      "y": 612
    },
    {
      "t": 100497,
      "e": 94867,
      "ty": 41,
      "x": 18131,
      "y": 50522,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 100597,
      "e": 94967,
      "ty": 2,
      "x": 608,
      "y": 542
    },
    {
      "t": 100696,
      "e": 95066,
      "ty": 2,
      "x": 602,
      "y": 538
    },
    {
      "t": 100746,
      "e": 95116,
      "ty": 41,
      "x": 15179,
      "y": 21656,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 101247,
      "e": 95617,
      "ty": 41,
      "x": 13802,
      "y": 16974,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 101296,
      "e": 95666,
      "ty": 2,
      "x": 557,
      "y": 523
    },
    {
      "t": 101397,
      "e": 95767,
      "ty": 2,
      "x": 536,
      "y": 522
    },
    {
      "t": 101497,
      "e": 95867,
      "ty": 2,
      "x": 532,
      "y": 521
    },
    {
      "t": 101497,
      "e": 95867,
      "ty": 41,
      "x": 11735,
      "y": 15024,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 109995,
      "e": 100867,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 147695,
      "e": 100867,
      "ty": 2,
      "x": 400,
      "y": 753
    },
    {
      "t": 147746,
      "e": 100918,
      "ty": 41,
      "x": 2339,
      "y": 4114,
      "ta": "> div.masterdiv > div:[2] > div > p:[5]"
    },
    {
      "t": 147795,
      "e": 100967,
      "ty": 2,
      "x": 338,
      "y": 800
    },
    {
      "t": 147896,
      "e": 101068,
      "ty": 2,
      "x": 351,
      "y": 715
    },
    {
      "t": 147995,
      "e": 101167,
      "ty": 2,
      "x": 870,
      "y": 836
    },
    {
      "t": 147996,
      "e": 101168,
      "ty": 41,
      "x": 28364,
      "y": 43903,
      "ta": "> div.masterdiv > div:[2] > div > p:[5]"
    },
    {
      "t": 148095,
      "e": 101267,
      "ty": 2,
      "x": 1606,
      "y": 1199
    },
    {
      "t": 148195,
      "e": 101367,
      "ty": 2,
      "x": 1175,
      "y": 1134
    },
    {
      "t": 148245,
      "e": 101417,
      "ty": 41,
      "x": 55938,
      "y": 22332,
      "ta": "> div.masterdiv > div:[3]"
    },
    {
      "t": 148294,
      "e": 101466,
      "ty": 2,
      "x": 992,
      "y": 1118
    },
    {
      "t": 148396,
      "e": 101568,
      "ty": 2,
      "x": 1007,
      "y": 1129
    },
    {
      "t": 148449,
      "e": 101621,
      "ty": 6,
      "x": 1011,
      "y": 1105,
      "ta": "#start"
    },
    {
      "t": 148496,
      "e": 101668,
      "ty": 2,
      "x": 1011,
      "y": 1093
    },
    {
      "t": 148496,
      "e": 101668,
      "ty": 41,
      "x": 55431,
      "y": 39152,
      "ta": "#start"
    },
    {
      "t": 148596,
      "e": 101768,
      "ty": 2,
      "x": 1008,
      "y": 1093
    },
    {
      "t": 148695,
      "e": 101867,
      "ty": 3,
      "x": 1005,
      "y": 1091,
      "ta": "#start"
    },
    {
      "t": 148696,
      "e": 101868,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 148698,
      "e": 101870,
      "ty": 2,
      "x": 1005,
      "y": 1091
    },
    {
      "t": 148745,
      "e": 101917,
      "ty": 41,
      "x": 52154,
      "y": 35297,
      "ta": "#start"
    },
    {
      "t": 148837,
      "e": 102009,
      "ty": 4,
      "x": 52154,
      "y": 35297,
      "ta": "#start"
    },
    {
      "t": 148838,
      "e": 102010,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 148839,
      "e": 102011,
      "ty": 5,
      "x": 1005,
      "y": 1091,
      "ta": "#start"
    },
    {
      "t": 148839,
      "e": 102011,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 149595,
      "e": 102767,
      "ty": 2,
      "x": 1004,
      "y": 1046
    },
    {
      "t": 149694,
      "e": 102866,
      "ty": 2,
      "x": 1004,
      "y": 1022
    },
    {
      "t": 149744,
      "e": 102916,
      "ty": 41,
      "x": 34299,
      "y": 55452,
      "ta": "html > body"
    },
    {
      "t": 149794,
      "e": 102966,
      "ty": 2,
      "x": 985,
      "y": 965
    },
    {
      "t": 149883,
      "e": 103055,
      "ty": 38,
      "x": 8,
      "y": 0
    },
    {
      "t": 150784,
      "e": 103956,
      "ty": 2,
      "x": 912,
      "y": 866
    },
    {
      "t": 150784,
      "e": 103956,
      "ty": 41,
      "x": 30764,
      "y": 32821,
      "ta": "#jspsych-data-display"
    },
    {
      "t": 151395,
      "e": 104567,
      "ty": 2,
      "x": 910,
      "y": 862
    },
    {
      "t": 151462,
      "e": 104634,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":56},{\"id\":57},{\"id\":58},{\"id\":59},{\"id\":60},{\"id\":61},{\"id\":62},{\"id\":63},{\"id\":64},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":72},{\"id\":73},{\"id\":74},{\"id\":75},{\"id\":76},{\"id\":77},{\"id\":78},{\"id\":79},{\"id\":80},{\"id\":81},{\"id\":82},{\"id\":83},{\"id\":84},{\"id\":85},{\"id\":86},{\"id\":87},{\"id\":88},{\"id\":89},{\"id\":90},{\"id\":91},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":96},{\"id\":97},{\"id\":98},{\"id\":99},{\"id\":100},{\"id\":101},{\"id\":102},{\"id\":103},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":109},{\"id\":110},{\"id\":111},{\"id\":112},{\"id\":113},{\"id\":114},{\"id\":115},{\"id\":116},{\"id\":117},{\"id\":118},{\"id\":119},{\"id\":120},{\"id\":121},{\"id\":122},{\"id\":123},{\"id\":124},{\"id\":125},{\"id\":126},{\"id\":127},{\"id\":128},{\"id\":129},{\"id\":130},{\"id\":131},{\"id\":132},{\"id\":133},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":141},{\"id\":142},{\"id\":143},{\"id\":144},{\"id\":145},{\"id\":146},{\"id\":147},{\"id\":148},{\"id\":149},{\"id\":150},{\"id\":151},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":155},{\"id\":156},{\"id\":157},{\"id\":158},{\"id\":159},{\"id\":160},{\"id\":161},{\"id\":162},{\"id\":163},{\"id\":164},{\"id\":165},{\"id\":166},{\"id\":167},{\"id\":168},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":172},{\"id\":173},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":178},{\"id\":179},{\"id\":180},{\"id\":181},{\"id\":182},{\"id\":183},{\"id\":184},{\"id\":185},{\"id\":186},{\"id\":187},{\"id\":188},{\"id\":189},{\"id\":190},{\"id\":191},{\"id\":192},{\"id\":193},{\"id\":194},{\"id\":195},{\"id\":196},{\"id\":197},{\"id\":198},{\"id\":199},{\"id\":200},{\"id\":201},{\"id\":202},{\"id\":203},{\"id\":204},{\"id\":205},{\"id\":206},{\"id\":207},{\"id\":208},{\"id\":209},{\"id\":210},{\"id\":211},{\"id\":212},{\"id\":213},{\"id\":214},{\"id\":215},{\"id\":216},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":220},{\"id\":221},{\"id\":222},{\"id\":223},{\"id\":224},{\"id\":225},{\"id\":226},{\"id\":227},{\"id\":228},{\"id\":229},{\"id\":230},{\"id\":231},{\"id\":232},{\"id\":233},{\"id\":234},{\"id\":235},{\"id\":236},{\"id\":237},{\"id\":238},{\"id\":239},{\"id\":240},{\"id\":241},{\"id\":242},{\"id\":243},{\"id\":244},{\"id\":245},{\"id\":246},{\"id\":247},{\"id\":248},{\"id\":249},{\"id\":250},{\"id\":251},{\"id\":252},{\"id\":253},{\"id\":254},{\"id\":255},{\"id\":256},{\"id\":257},{\"id\":258},{\"id\":259},{\"id\":260},{\"id\":261},{\"id\":262},{\"id\":263},{\"id\":264},{\"id\":265},{\"id\":266},{\"id\":267},{\"id\":268},{\"id\":269},{\"id\":270},{\"id\":271},{\"id\":272},{\"id\":273},{\"id\":274},{\"id\":275},{\"id\":276},{\"id\":277},{\"id\":278},{\"id\":279},{\"id\":280},{\"id\":281},{\"id\":282},{\"id\":283},{\"id\":284},{\"id\":285},{\"id\":286},{\"id\":287},{\"id\":288},{\"id\":289},{\"id\":290},{\"id\":291},{\"id\":292},{\"id\":293},{\"id\":294},{\"id\":295},{\"id\":296},{\"id\":297},{\"id\":298},{\"id\":299},{\"id\":300},{\"id\":301},{\"id\":302},{\"id\":303},{\"id\":304},{\"id\":305},{\"id\":306},{\"id\":307},{\"id\":308},{\"id\":309},{\"id\":310},{\"id\":311},{\"id\":312},{\"id\":313},{\"id\":314},{\"id\":315},{\"id\":316},{\"id\":317},{\"id\":318},{\"id\":319},{\"id\":320},{\"id\":321},{\"id\":322},{\"id\":323},{\"id\":324},{\"id\":325},{\"id\":326},{\"id\":327},{\"id\":328},{\"id\":329},{\"id\":330},{\"id\":331},{\"id\":332},{\"id\":333},{\"id\":334},{\"id\":335},{\"id\":336},{\"id\":337},{\"id\":338},{\"id\":339},{\"id\":340},{\"id\":341},{\"id\":342},{\"id\":343},{\"id\":344},{\"id\":345},{\"id\":346},{\"id\":347},{\"id\":348},{\"id\":349},{\"id\":350},{\"id\":351},{\"id\":352},{\"id\":353},{\"id\":354},{\"id\":355},{\"id\":356},{\"id\":357},{\"id\":358},{\"id\":359},{\"id\":360},{\"id\":361},{\"id\":362},{\"id\":363},{\"id\":364},{\"id\":365},{\"id\":366},{\"id\":367},{\"id\":368},{\"id\":369},{\"id\":370},{\"id\":371},{\"id\":372},{\"id\":373},{\"id\":374},{\"id\":375},{\"id\":376},{\"id\":377},{\"id\":378},{\"id\":379},{\"id\":380},{\"id\":381},{\"id\":382},{\"id\":383},{\"id\":384},{\"id\":385},{\"id\":386},{\"id\":387},{\"id\":388},{\"id\":389},{\"id\":390},{\"id\":391},{\"id\":392},{\"id\":393},{\"id\":394},{\"id\":395},{\"id\":396},{\"id\":397},{\"id\":398},{\"id\":399},{\"id\":400},{\"id\":401},{\"id\":402},{\"id\":403},{\"id\":404},{\"id\":405},{\"id\":406},{\"id\":407},{\"id\":408},{\"id\":409},{\"id\":410},{\"id\":411},{\"id\":412},{\"id\":413},{\"id\":414},{\"id\":415},{\"id\":416},{\"id\":417},{\"id\":418},{\"id\":419},{\"id\":420},{\"id\":421},{\"id\":422},{\"id\":423},{\"id\":424},{\"id\":425},{\"id\":426},{\"id\":427},{\"id\":428},{\"id\":429},{\"id\":430},{\"id\":431},{\"id\":432},{\"id\":433},{\"id\":434},{\"id\":435},{\"id\":436},{\"id\":437},{\"id\":438},{\"id\":439},{\"id\":440},{\"id\":441},{\"id\":442},{\"id\":443},{\"id\":444},{\"id\":445},{\"id\":446},{\"id\":447},{\"id\":448},{\"id\":449},{\"id\":450},{\"id\":451},{\"id\":452},{\"id\":453},{\"id\":454},{\"id\":455},{\"id\":456},{\"id\":457},{\"id\":458},{\"id\":459},{\"id\":460},{\"id\":461},{\"id\":462},{\"id\":463},{\"id\":464},{\"id\":465},{\"id\":466},{\"id\":467},{\"id\":468},{\"id\":469},{\"id\":470},{\"id\":471},{\"id\":472},{\"id\":473},{\"id\":474},{\"id\":475},{\"id\":476},{\"id\":477},{\"id\":478},{\"id\":479},{\"id\":480},{\"id\":481},{\"id\":482},{\"id\":483},{\"id\":484},{\"id\":485},{\"id\":486},{\"id\":487},{\"id\":488},{\"id\":489},{\"id\":490},{\"id\":491},{\"id\":492},{\"id\":493},{\"id\":494},{\"id\":495},{\"id\":496},{\"id\":497},{\"id\":498},{\"id\":499},{\"id\":500},{\"id\":501},{\"id\":502},{\"id\":503},{\"id\":504},{\"id\":505},{\"id\":506},{\"id\":507},{\"id\":508},{\"id\":509},{\"id\":510},{\"id\":511},{\"id\":512},{\"id\":513},{\"id\":514},{\"id\":515},{\"id\":516},{\"id\":517},{\"id\":518},{\"id\":519},{\"id\":520},{\"id\":521},{\"id\":522},{\"id\":523},{\"id\":524},{\"id\":525},{\"id\":526},{\"id\":527},{\"id\":528},{\"id\":529},{\"id\":530},{\"id\":531},{\"id\":532},{\"id\":533},{\"id\":534},{\"id\":535},{\"id\":536},{\"id\":537},{\"id\":538},{\"id\":539},{\"id\":540},{\"id\":541},{\"id\":542},{\"id\":543},{\"id\":544},{\"id\":545},{\"id\":546},{\"id\":547},{\"id\":548},{\"id\":549},{\"id\":550},{\"id\":551},{\"id\":552},{\"id\":553},{\"id\":554},{\"id\":555},{\"id\":556},{\"id\":557},{\"id\":558},{\"id\":559},{\"id\":560},{\"id\":561},{\"id\":562},{\"id\":563},{\"id\":564},{\"id\":565},{\"id\":566},{\"id\":567},{\"id\":568},{\"id\":569},{\"id\":570},{\"id\":571},{\"id\":572},{\"id\":573},{\"id\":574},{\"id\":575},{\"id\":576},{\"id\":577},{\"id\":578},{\"id\":579},{\"id\":580},{\"id\":581},{\"id\":582},{\"id\":583},{\"id\":584},{\"id\":585},{\"id\":586},{\"id\":587},{\"id\":588},{\"id\":589},{\"id\":590},{\"id\":591},{\"id\":592},{\"id\":593},{\"id\":594},{\"id\":595},{\"id\":596},{\"id\":597},{\"id\":598},{\"id\":599},{\"id\":600},{\"id\":601},{\"id\":602},{\"id\":603},{\"id\":604},{\"id\":605},{\"id\":606},{\"id\":607},{\"id\":608},{\"id\":609},{\"id\":610},{\"id\":611},{\"id\":612},{\"id\":613},{\"id\":614},{\"id\":615},{\"id\":616},{\"id\":617},{\"id\":618},{\"id\":619},{\"id\":620},{\"id\":621},{\"id\":622},{\"id\":623},{\"id\":624},{\"id\":625},{\"id\":626},{\"id\":627},{\"id\":628},{\"id\":629},{\"id\":630},{\"id\":631},{\"id\":632},{\"id\":633},{\"id\":634},{\"id\":635},{\"id\":636},{\"id\":637},{\"id\":638},{\"id\":639},{\"id\":640},{\"id\":641},{\"id\":642},{\"id\":643},{\"id\":644},{\"id\":645},{\"id\":646},{\"id\":647},{\"id\":648},{\"id\":649},{\"id\":650},{\"id\":651},{\"id\":652},{\"id\":653},{\"id\":654},{\"id\":655},{\"id\":656},{\"id\":657},{\"id\":658},{\"id\":659},{\"id\":660},{\"id\":661},{\"id\":662},{\"id\":663},{\"id\":664},{\"id\":665},{\"id\":666},{\"id\":667},{\"id\":668},{\"id\":669},{\"id\":670},{\"id\":671},{\"id\":672},{\"id\":673},{\"id\":674},{\"id\":675},{\"id\":676},{\"id\":677},{\"id\":678},{\"id\":679},{\"id\":680},{\"id\":681},{\"id\":682},{\"id\":683},{\"id\":684},{\"id\":685},{\"id\":686},{\"id\":687},{\"id\":688},{\"id\":689},{\"id\":690},{\"id\":691},{\"id\":692},{\"id\":693},{\"id\":694},{\"id\":695},{\"id\":696},{\"id\":697},{\"id\":698},{\"id\":699},{\"id\":700},{\"id\":701},{\"id\":702},{\"id\":703},{\"id\":704},{\"id\":705},{\"id\":706},{\"id\":707},{\"id\":708},{\"id\":709},{\"id\":710},{\"id\":711},{\"id\":712},{\"id\":713},{\"id\":714},{\"id\":715},{\"id\":716},{\"id\":717},{\"id\":718},{\"id\":719},{\"id\":720},{\"id\":721},{\"id\":722},{\"id\":723},{\"id\":724},{\"id\":725},{\"id\":726},{\"id\":727},{\"id\":728},{\"id\":729},{\"id\":730},{\"id\":731},{\"id\":732},{\"id\":733},{\"id\":734},{\"id\":735},{\"id\":736},{\"id\":737},{\"id\":738},{\"id\":739},{\"id\":740},{\"id\":741},{\"id\":742},{\"id\":743},{\"id\":744},{\"id\":745},{\"id\":746},{\"id\":747},{\"id\":748},{\"id\":749},{\"id\":750},{\"id\":751},{\"id\":752},{\"id\":753},{\"id\":754},{\"id\":755},{\"id\":756},{\"id\":757},{\"id\":758},{\"id\":759},{\"id\":760},{\"id\":761},{\"id\":762},{\"id\":763},{\"id\":764},{\"id\":765},{\"id\":766},{\"id\":767},{\"id\":768},{\"id\":769},{\"id\":770},{\"id\":771},{\"id\":772},{\"id\":773},{\"id\":774},{\"id\":775},{\"id\":776},{\"id\":777},{\"id\":778},{\"id\":779},{\"id\":780},{\"id\":781},{\"id\":782},{\"id\":783},{\"id\":784},{\"id\":785},{\"id\":786},{\"id\":787},{\"id\":788},{\"id\":789},{\"id\":790},{\"id\":791},{\"id\":792},{\"id\":793},{\"id\":794},{\"id\":795},{\"id\":796},{\"id\":797},{\"id\":798},{\"id\":799},{\"id\":800},{\"id\":801},{\"id\":802},{\"id\":803},{\"id\":804},{\"id\":805},{\"id\":806},{\"id\":807},{\"id\":808},{\"id\":809},{\"id\":810},{\"id\":811},{\"id\":812},{\"id\":813},{\"id\":814},{\"id\":815},{\"id\":816},{\"id\":817},{\"id\":818},{\"id\":819},{\"id\":820},{\"id\":821},{\"id\":822},{\"id\":823},{\"id\":824},{\"id\":825},{\"id\":826},{\"id\":827},{\"id\":828},{\"id\":829},{\"id\":830},{\"id\":831},{\"id\":832},{\"id\":833},{\"id\":834},{\"id\":835},{\"id\":836},{\"id\":837},{\"id\":838},{\"id\":839},{\"id\":840},{\"id\":841},{\"id\":842},{\"id\":843},{\"id\":844},{\"id\":845},{\"id\":846},{\"id\":847},{\"id\":848},{\"id\":849},{\"id\":850},{\"id\":851},{\"id\":852},{\"id\":853},{\"id\":854},{\"id\":855},{\"id\":856},{\"id\":857},{\"id\":858},{\"id\":859},{\"id\":860},{\"id\":861},{\"id\":862},{\"id\":863},{\"id\":864},{\"id\":865},{\"id\":866},{\"id\":867},{\"id\":868},{\"id\":869},{\"id\":870},{\"id\":871},{\"id\":872},{\"id\":873},{\"id\":874},{\"id\":875},{\"id\":876},{\"id\":877},{\"id\":878},{\"id\":879},{\"id\":880},{\"id\":881},{\"id\":882},{\"id\":883},{\"id\":884},{\"id\":885},{\"id\":886},{\"id\":887},{\"id\":888},{\"id\":889},{\"id\":890},{\"id\":891},{\"id\":892},{\"id\":893},{\"id\":894},{\"id\":895},{\"id\":896},{\"id\":897},{\"id\":898},{\"id\":899},{\"id\":900},{\"id\":901},{\"id\":902},{\"id\":903},{\"id\":904},{\"id\":905},{\"id\":906},{\"id\":907},{\"id\":908},{\"id\":909},{\"id\":910},{\"id\":911},{\"id\":912},{\"id\":913},{\"id\":914},{\"id\":915},{\"id\":916},{\"id\":917},{\"id\":918},{\"id\":919},{\"id\":920},{\"id\":921},{\"id\":922},{\"id\":923},{\"id\":924},{\"id\":925},{\"id\":926},{\"id\":927},{\"id\":928},{\"id\":929},{\"id\":930},{\"id\":931},{\"id\":932},{\"id\":933},{\"id\":934},{\"id\":935},{\"id\":936},{\"id\":937},{\"id\":938},{\"id\":939},{\"id\":940},{\"id\":941},{\"id\":942},{\"id\":943},{\"id\":944},{\"id\":945},{\"id\":946},{\"id\":947},{\"id\":948},{\"id\":949},{\"id\":950},{\"id\":951},{\"id\":952},{\"id\":953},{\"id\":954},{\"id\":955},{\"id\":956},{\"id\":957},{\"id\":958},{\"id\":959},{\"id\":960},{\"id\":961},{\"id\":962},{\"id\":963},{\"id\":964},{\"id\":965},{\"id\":966},{\"id\":967},{\"id\":968},{\"id\":969},{\"id\":970},{\"id\":971},{\"id\":972},{\"id\":973},{\"id\":974},{\"id\":975},{\"id\":976},{\"id\":977},{\"id\":978},{\"id\":979},{\"id\":980},{\"id\":981},{\"id\":982},{\"id\":983},{\"id\":984},{\"id\":985},{\"id\":986},{\"id\":987},{\"id\":988},{\"id\":989},{\"id\":990},{\"id\":991},{\"id\":992},{\"id\":993},{\"id\":994},{\"id\":995},{\"id\":996},{\"id\":997},{\"id\":998},{\"id\":999},{\"id\":1000},{\"id\":1001},{\"id\":1002},{\"id\":1003},{\"id\":1004},{\"id\":1005},{\"id\":1006},{\"id\":1007},{\"id\":1008},{\"id\":1009},{\"id\":1010},{\"id\":1011},{\"id\":1012},{\"id\":1013},{\"id\":1014},{\"id\":1015},{\"id\":1016},{\"id\":1017},{\"id\":1018},{\"id\":1019},{\"id\":1020},{\"id\":1021},{\"id\":1022},{\"id\":1023},{\"id\":1024},{\"id\":1025},{\"id\":1026},{\"id\":1027},{\"id\":1028},{\"id\":1029},{\"id\":1030},{\"id\":1031},{\"id\":1032},{\"id\":1033},{\"id\":1034},{\"id\":1035},{\"id\":1036},{\"id\":1037},{\"id\":1038},{\"id\":1039},{\"id\":1040},{\"id\":1041},{\"id\":1042},{\"id\":1043},{\"id\":1044},{\"id\":1045},{\"id\":1046},{\"id\":1047},{\"id\":1048},{\"id\":1049},{\"id\":1050},{\"id\":1051},{\"id\":1052},{\"id\":1053},{\"id\":1054},{\"id\":1055},{\"id\":1056},{\"id\":1057},{\"id\":1058},{\"id\":1059},{\"id\":1060},{\"id\":1061},{\"id\":1062},{\"id\":1063},{\"id\":1064},{\"id\":1065},{\"id\":1066},{\"id\":1067},{\"id\":1068},{\"id\":1069},{\"id\":1070},{\"id\":1071},{\"id\":1072},{\"id\":1073},{\"id\":1074},{\"id\":1075},{\"id\":1076},{\"id\":1077},{\"id\":1078},{\"id\":1079},{\"id\":1080},{\"id\":1081},{\"id\":1082},{\"id\":1083},{\"id\":1084},{\"id\":1085},{\"id\":1086},{\"id\":1087},{\"id\":1088},{\"id\":1089},{\"id\":1090},{\"id\":1091},{\"id\":1092},{\"id\":1093},{\"id\":1094},{\"id\":1095},{\"id\":1096},{\"id\":1097},{\"id\":1098},{\"id\":1099},{\"id\":1100},{\"id\":1101},{\"id\":1102},{\"id\":1103},{\"id\":1104},{\"id\":1105},{\"id\":1106},{\"id\":1107},{\"id\":1108},{\"id\":1109},{\"id\":1110},{\"id\":1111},{\"id\":1112},{\"id\":1113},{\"id\":1114},{\"id\":1115},{\"id\":1116},{\"id\":1117},{\"id\":1118},{\"id\":1119},{\"id\":1120},{\"id\":1121},{\"id\":1122},{\"id\":1123},{\"id\":1124},{\"id\":1125},{\"id\":1126},{\"id\":1127},{\"id\":1128},{\"id\":1129},{\"id\":1130},{\"id\":1131},{\"id\":1132},{\"id\":1133},{\"id\":1134},{\"id\":1135},{\"id\":1136},{\"id\":1137},{\"id\":1138},{\"id\":1139},{\"id\":1140},{\"id\":1141},{\"id\":1142},{\"id\":1143},{\"id\":1144},{\"id\":1145},{\"id\":1146},{\"id\":1147},{\"id\":1148},{\"id\":1149},{\"id\":1150},{\"id\":1151},{\"id\":1152},{\"id\":1153},{\"id\":1154},{\"id\":1155},{\"id\":1156},{\"id\":1157},{\"id\":1158},{\"id\":1159},{\"id\":1160},{\"id\":1161},{\"id\":1162},{\"id\":1163},{\"id\":1164},{\"id\":1165},{\"id\":1166},{\"id\":1167},{\"id\":1168},{\"id\":1169},{\"id\":1170},{\"id\":1171},{\"id\":1172},{\"id\":1173},{\"id\":1174},{\"id\":1175},{\"id\":1176},{\"id\":1177},{\"id\":1178},{\"id\":1179},{\"id\":1180},{\"id\":1181},{\"id\":1182},{\"id\":1183},{\"id\":1184},{\"id\":1185},{\"id\":1186},{\"id\":1187},{\"id\":1188},{\"id\":1189},{\"id\":1190},{\"id\":1191},{\"id\":1192},{\"id\":1193},{\"id\":1194},{\"id\":1195},{\"id\":1196},{\"id\":1197},{\"id\":1198},{\"id\":1199},{\"id\":1200},{\"id\":1201},{\"id\":1202},{\"id\":1203},{\"id\":1204},{\"id\":1205},{\"id\":1206},{\"id\":1207},{\"id\":1208},{\"id\":1209},{\"id\":1210},{\"id\":1211},{\"id\":1212},{\"id\":1213},{\"id\":1214},{\"id\":1215},{\"id\":1216},{\"id\":1217},{\"id\":1218},{\"id\":1219},{\"id\":1220},{\"id\":1221},{\"id\":1222},{\"id\":1223},{\"id\":1224},{\"id\":1225},{\"id\":1226},{\"id\":1227},{\"id\":1228},{\"id\":1229},{\"id\":1230},{\"id\":1231},{\"id\":1232},{\"id\":1233},{\"id\":1234},{\"id\":1235},{\"id\":1236},{\"id\":1237},{\"id\":1238},{\"id\":1239},{\"id\":1240},{\"id\":1241},{\"id\":1242},{\"id\":1243},{\"id\":1244},{\"id\":1245},{\"id\":1246},{\"id\":1247},{\"id\":1248},{\"id\":1249},{\"id\":1250},{\"id\":1251},{\"id\":1252},{\"id\":1253},{\"id\":1254},{\"id\":1255},{\"id\":1256},{\"id\":1257},{\"id\":1258},{\"id\":1259},{\"id\":1260},{\"id\":1261},{\"id\":1262},{\"id\":1263},{\"id\":1264},{\"id\":1265},{\"id\":1266},{\"id\":1267},{\"id\":1268},{\"id\":1269},{\"id\":1270},{\"id\":1271},{\"id\":1272},{\"id\":1273},{\"id\":1274},{\"id\":1275},{\"id\":1276},{\"id\":1277},{\"id\":1278},{\"id\":1279},{\"id\":1280},{\"id\":1281},{\"id\":1282},{\"id\":1283},{\"id\":1284},{\"id\":1285},{\"id\":1286},{\"id\":1287},{\"id\":1288},{\"id\":1289},{\"id\":1290},{\"id\":1291},{\"id\":1292},{\"id\":1293},{\"id\":1294},{\"id\":1295},{\"id\":1296},{\"id\":1297},{\"id\":1298},{\"id\":1299},{\"id\":1300},{\"id\":1301},{\"id\":1302},{\"id\":1303},{\"id\":1304},{\"id\":1305},{\"id\":1306},{\"id\":1307},{\"id\":1308},{\"id\":1309},{\"id\":1310},{\"id\":1311},{\"id\":1312},{\"id\":1313},{\"id\":1314},{\"id\":1315},{\"id\":1316},{\"id\":1317},{\"id\":1318},{\"id\":1319},{\"id\":1320},{\"id\":1321},{\"id\":1322},{\"id\":1323},{\"id\":1324},{\"id\":1325},{\"id\":1326},{\"id\":1327},{\"id\":1328},{\"id\":1329},{\"id\":1330},{\"id\":1331},{\"id\":1332},{\"id\":1333},{\"id\":1334},{\"id\":1335},{\"id\":1336},{\"id\":1337},{\"id\":1338},{\"id\":1339},{\"id\":1340},{\"id\":1341},{\"id\":1342},{\"id\":1343},{\"id\":1344},{\"id\":1345},{\"id\":1346},{\"id\":1347},{\"id\":1348},{\"id\":1349},{\"id\":1350},{\"id\":1351},{\"id\":1352},{\"id\":1353},{\"id\":1354},{\"id\":1355},{\"id\":1356},{\"id\":1357},{\"id\":1358},{\"id\":1359},{\"id\":1360},{\"id\":1361},{\"id\":1362},{\"id\":1363},{\"id\":1364},{\"id\":1365},{\"id\":1366},{\"id\":1367},{\"id\":1368},{\"id\":1369},{\"id\":1370},{\"id\":1371},{\"id\":1372},{\"id\":1373},{\"id\":1374},{\"id\":1375},{\"id\":1376},{\"id\":1377},{\"id\":1378},{\"id\":1379},{\"id\":1380},{\"id\":1381},{\"id\":1382},{\"id\":1383},{\"id\":1384},{\"id\":1385},{\"id\":1386},{\"id\":1387},{\"id\":1388},{\"id\":1389},{\"id\":1390},{\"id\":1391},{\"id\":1392},{\"id\":1393},{\"id\":1394},{\"id\":1395},{\"id\":1396},{\"id\":1397},{\"id\":1398},{\"id\":1399},{\"id\":1400},{\"id\":1401},{\"id\":1402},{\"id\":1403},{\"id\":1404},{\"id\":1405},{\"id\":1406},{\"id\":1407},{\"id\":1408},{\"id\":1409},{\"id\":1410},{\"id\":1411},{\"id\":1412},{\"id\":1413},{\"id\":1414},{\"id\":1415},{\"id\":1416},{\"id\":1417},{\"id\":1418},{\"id\":1419},{\"id\":1420},{\"id\":1421},{\"id\":1422},{\"id\":1423},{\"id\":1424},{\"id\":1425},{\"id\":1426},{\"id\":1427},{\"id\":1428},{\"id\":1429},{\"id\":1430},{\"id\":1431},{\"id\":1432},{\"id\":1433},{\"id\":1434},{\"id\":1435},{\"id\":1436},{\"id\":1437},{\"id\":1438},{\"id\":1439},{\"id\":1440},{\"id\":1441},{\"id\":1442},{\"id\":1443},{\"id\":1444},{\"id\":1445},{\"id\":1446},{\"id\":1447},{\"id\":1448},{\"id\":1449},{\"id\":1450},{\"id\":1451},{\"id\":1452},{\"id\":1453},{\"id\":1454},{\"id\":1455},{\"id\":1456},{\"id\":1457},{\"id\":1458},{\"id\":1459},{\"id\":1460},{\"id\":1461},{\"id\":1462},{\"id\":1463},{\"id\":1464},{\"id\":1465},{\"id\":1466},{\"id\":1467},{\"id\":1468},{\"id\":1469},{\"id\":1470},{\"id\":1471},{\"id\":1472},{\"id\":1473},{\"id\":1474},{\"id\":1475},{\"id\":1476},{\"id\":1477},{\"id\":1478},{\"id\":1479},{\"id\":1480},{\"id\":1481},{\"id\":1482},{\"id\":1483},{\"id\":1484},{\"id\":1485},{\"id\":1486},{\"id\":1487},{\"id\":1488},{\"id\":1489},{\"id\":1490},{\"id\":1491},{\"id\":1492},{\"id\":1493},{\"id\":1494},{\"id\":1495},{\"id\":1496},{\"id\":1497},{\"id\":1498},{\"id\":1499},{\"id\":1500},{\"id\":1501},{\"id\":1502},{\"id\":1503},{\"id\":1504},{\"id\":1505},{\"id\":1506},{\"id\":1507},{\"id\":1508},{\"id\":1509},{\"id\":1510},{\"id\":1511},{\"id\":1512},{\"id\":1513},{\"id\":1514},{\"id\":1515},{\"id\":1516},{\"id\":1517},{\"id\":1518},{\"id\":1519},{\"id\":1520},{\"id\":1521},{\"id\":1522},{\"id\":1523},{\"id\":1524},{\"id\":1525},{\"id\":1526},{\"id\":1527},{\"id\":1528},{\"id\":1529},{\"id\":1530},{\"id\":1531},{\"id\":1532},{\"id\":1533},{\"id\":1534},{\"id\":1535},{\"id\":1536},{\"id\":1537},{\"id\":1538},{\"id\":1539},{\"id\":1540},{\"id\":1541},{\"id\":1542},{\"id\":1543},{\"id\":1544},{\"id\":1545},{\"id\":1546},{\"id\":1547},{\"id\":1548},{\"id\":1549},{\"id\":1550},{\"id\":1551},{\"id\":1552},{\"id\":1553},{\"id\":1554},{\"id\":1555},{\"id\":1556},{\"id\":1557},{\"id\":1558},{\"id\":1559},{\"id\":1560},{\"id\":1561},{\"id\":1562},{\"id\":1563},{\"id\":1564},{\"id\":1565},{\"id\":1566},{\"id\":1567},{\"id\":1568},{\"id\":1569},{\"id\":1570},{\"id\":1571},{\"id\":1572},{\"id\":1573},{\"id\":1574},{\"id\":1575},{\"id\":1576},{\"id\":1577},{\"id\":1578},{\"id\":1579},{\"id\":1580},{\"id\":1581},{\"id\":1582},{\"id\":1583},{\"id\":1584},{\"id\":1585},{\"id\":1586},{\"id\":1587},{\"id\":1588},{\"id\":1589},{\"id\":1590},{\"id\":1591},{\"id\":1592},{\"id\":1593},{\"id\":1594},{\"id\":1595},{\"id\":1596},{\"id\":1597},{\"id\":1598},{\"id\":1599},{\"id\":1600},{\"id\":1601},{\"id\":1602},{\"id\":1603},{\"id\":1604},{\"id\":1605},{\"id\":1606},{\"id\":1607},{\"id\":1608},{\"id\":1609},{\"id\":1610},{\"id\":1611},{\"id\":1612},{\"id\":1613},{\"id\":1614},{\"id\":1615},{\"id\":1616},{\"id\":1617},{\"id\":1618},{\"id\":1619},{\"id\":1620},{\"id\":1621},{\"id\":1622},{\"id\":1623},{\"id\":1624},{\"id\":1625},{\"id\":1626},{\"id\":1627},{\"id\":1628},{\"id\":1629},{\"id\":1630},{\"id\":1631},{\"id\":1632},{\"id\":1633},{\"id\":1634},{\"id\":1635},{\"id\":1636},{\"id\":1637},{\"id\":1638},{\"id\":1639},{\"id\":1640},{\"id\":1641},{\"id\":1642},{\"id\":1643},{\"id\":1644},{\"id\":1645},{\"id\":1646},{\"id\":1647},{\"id\":1648},{\"id\":1649},{\"id\":1650},{\"id\":1651},{\"id\":1652},{\"id\":1653},{\"id\":1654},{\"id\":1655},{\"id\":1656},{\"id\":1657},{\"id\":1658},{\"id\":1659},{\"id\":1660},{\"id\":1661},{\"id\":1662},{\"id\":1663},{\"id\":1664},{\"id\":1665},{\"id\":1666},{\"id\":1667},{\"id\":1668},{\"id\":1669},{\"id\":1670},{\"id\":1671},{\"id\":1672},{\"id\":1673},{\"id\":1674},{\"id\":1675},{\"id\":1676},{\"id\":1677},{\"id\":1678},{\"id\":1679},{\"id\":1680},{\"id\":1681},{\"id\":1682},{\"id\":1683},{\"id\":1684},{\"id\":1685},{\"id\":1686},{\"id\":1687},{\"id\":1688},{\"id\":1689},{\"id\":1690},{\"id\":1691},{\"id\":1692},{\"id\":1693},{\"id\":1694},{\"id\":1695},{\"id\":1696},{\"id\":1697},{\"id\":1698},{\"id\":1699},{\"id\":1700},{\"id\":1701},{\"id\":1702},{\"id\":1703},{\"id\":1704},{\"id\":1705},{\"id\":1706},{\"id\":1707},{\"id\":1708},{\"id\":1709},{\"id\":1710},{\"id\":1711},{\"id\":1712},{\"id\":1713},{\"id\":1714},{\"id\":1715},{\"id\":1716},{\"id\":1717},{\"id\":1718},{\"id\":1719},{\"id\":1720},{\"id\":1721},{\"id\":1722},{\"id\":1723},{\"id\":1724},{\"id\":1725},{\"id\":1726},{\"id\":1727},{\"id\":1728},{\"id\":1729},{\"id\":1730},{\"id\":1731},{\"id\":1732},{\"id\":1733},{\"id\":1734},{\"id\":1735},{\"id\":1736},{\"id\":1737},{\"id\":1738},{\"id\":1739},{\"id\":1740},{\"id\":1741},{\"id\":1742},{\"id\":1743},{\"id\":1744},{\"id\":1745},{\"id\":1746},{\"id\":1747},{\"id\":1748},{\"id\":1749},{\"id\":1750},{\"id\":1751},{\"id\":1752},{\"id\":1753},{\"id\":1754},{\"id\":1755},{\"id\":1756},{\"id\":1757},{\"id\":1758},{\"id\":1759},{\"id\":1760},{\"id\":1761},{\"id\":1762},{\"id\":1763},{\"id\":1764},{\"id\":1765},{\"id\":1766},{\"id\":1767},{\"id\":1768},{\"id\":1769},{\"id\":1770},{\"id\":1771},{\"id\":1772},{\"id\":1773},{\"id\":1774},{\"id\":1775},{\"id\":1776},{\"id\":1777},{\"id\":1778},{\"id\":1779},{\"id\":1780},{\"id\":1781},{\"id\":1782},{\"id\":1783},{\"id\":1784},{\"id\":1785},{\"id\":1786},{\"id\":1787},{\"id\":1788},{\"id\":1789},{\"id\":1790},{\"id\":1791},{\"id\":1792},{\"id\":1793},{\"id\":1794},{\"id\":1795},{\"id\":1796},{\"id\":1797},{\"id\":1798},{\"id\":1799},{\"id\":1800},{\"id\":1801},{\"id\":1802},{\"id\":1803},{\"id\":1804},{\"id\":1805},{\"id\":1806},{\"id\":1807},{\"id\":1808},{\"id\":1809},{\"id\":1810},{\"id\":1811},{\"id\":1812},{\"id\":1813},{\"id\":1814},{\"id\":1815},{\"id\":1816},{\"id\":1817},{\"id\":1818},{\"id\":1819},{\"id\":1820},{\"id\":1821},{\"id\":1822},{\"id\":1823},{\"id\":1824},{\"id\":1825},{\"id\":1826},{\"id\":1827},{\"id\":1828},{\"id\":1829},{\"id\":1830},{\"id\":1831},{\"id\":1832},{\"id\":1833},{\"id\":1834},{\"id\":1835},{\"id\":1836},{\"id\":1837},{\"id\":1838},{\"id\":1839},{\"id\":1840},{\"id\":1841},{\"id\":1842},{\"id\":1843},{\"id\":1844},{\"id\":1845},{\"id\":1846},{\"id\":1847},{\"id\":1848},{\"id\":1849},{\"id\":1850},{\"id\":1851},{\"id\":1852},{\"id\":1853},{\"id\":1854},{\"id\":1855},{\"id\":1856},{\"id\":1857},{\"id\":1858},{\"id\":1859},{\"id\":1860},{\"id\":1861},{\"id\":1862},{\"id\":1863},{\"id\":1864},{\"id\":1865},{\"id\":1866},{\"id\":1867},{\"id\":1868},{\"id\":1869},{\"id\":1870},{\"id\":1871},{\"id\":1872},{\"id\":1873},{\"id\":1874},{\"id\":1875},{\"id\":1876},{\"id\":1877},{\"id\":1878},{\"id\":1879},{\"id\":1880},{\"id\":1881},{\"id\":1882},{\"id\":1883},{\"id\":1884},{\"id\":1885},{\"id\":1886},{\"id\":1887},{\"id\":1888},{\"id\":1889},{\"id\":1890},{\"id\":1891},{\"id\":1892},{\"id\":1893},{\"id\":1894},{\"id\":1895},{\"id\":1896},{\"id\":1897},{\"id\":1898},{\"id\":1899},{\"id\":1900},{\"id\":1901},{\"id\":1902},{\"id\":1903},{\"id\":1904},{\"id\":1905},{\"id\":1906},{\"id\":1907},{\"id\":1908},{\"id\":1909},{\"id\":1910},{\"id\":1911},{\"id\":1912},{\"id\":1913},{\"id\":1914},{\"id\":1915},{\"id\":1916},{\"id\":1917},{\"id\":1918},{\"id\":1919},{\"id\":1920},{\"id\":1921},{\"id\":1922},{\"id\":1923},{\"id\":1924},{\"id\":1925},{\"id\":1926},{\"id\":1927},{\"id\":1928},{\"id\":1929},{\"id\":1930},{\"id\":1931},{\"id\":1932},{\"id\":1933},{\"id\":1934},{\"id\":1935},{\"id\":1936},{\"id\":1937},{\"id\":1938},{\"id\":1939},{\"id\":1940},{\"id\":1941},{\"id\":1942},{\"id\":1943},{\"id\":1944},{\"id\":1945},{\"id\":1946},{\"id\":1947},{\"id\":1948},{\"id\":1949},{\"id\":1950},{\"id\":1951},{\"id\":1952},{\"id\":1953},{\"id\":1954},{\"id\":1955},{\"id\":1956},{\"id\":1957},{\"id\":1958},{\"id\":1959},{\"id\":1960},{\"id\":1961},{\"id\":1962},{\"id\":1963},{\"id\":1964},{\"id\":1965},{\"id\":1966},{\"id\":1967},{\"id\":1968},{\"id\":1969},{\"id\":1970},{\"id\":1971},{\"id\":1972},{\"id\":1973},{\"id\":1974},{\"id\":1975},{\"id\":1976},{\"id\":1977},{\"id\":1978},{\"id\":1979},{\"id\":1980},{\"id\":1981},{\"id\":1982},{\"id\":1983},{\"id\":1984},{\"id\":1985},{\"id\":1986},{\"id\":1987},{\"id\":1988},{\"id\":1989},{\"id\":1990},{\"id\":1991},{\"id\":1992},{\"id\":1993},{\"id\":1994},{\"id\":1995},{\"id\":1996},{\"id\":1997},{\"id\":1998},{\"id\":1999},{\"id\":2000},{\"id\":2001},{\"id\":2002},{\"id\":2003},{\"id\":2004},{\"id\":2005},{\"id\":2006},{\"id\":2007},{\"id\":2008},{\"id\":2009},{\"id\":2010},{\"id\":2011},{\"id\":2012},{\"id\":2013},{\"id\":2014},{\"id\":2015},{\"id\":2016},{\"id\":2017},{\"id\":2018},{\"id\":2019},{\"id\":2020},{\"id\":2021},{\"id\":2022},{\"id\":2023},{\"id\":2024},{\"id\":2025},{\"id\":2026},{\"id\":2027},{\"id\":2028},{\"id\":2029},{\"id\":2030},{\"id\":2031},{\"id\":2032},{\"id\":2033},{\"id\":2034},{\"id\":2035},{\"id\":2036},{\"id\":2037},{\"id\":2038},{\"id\":2039},{\"id\":2040},{\"id\":2041},{\"id\":2042},{\"id\":2043},{\"id\":2044},{\"id\":2045},{\"id\":2046},{\"id\":2047},{\"id\":2048},{\"id\":2049},{\"id\":2050},{\"id\":2051},{\"id\":2052},{\"id\":2053},{\"id\":2054},{\"id\":2055},{\"id\":2056},{\"id\":2057},{\"id\":2058},{\"id\":2059},{\"id\":2060},{\"id\":2061},{\"id\":2062},{\"id\":2063},{\"id\":2064},{\"id\":2065},{\"id\":2066},{\"id\":2067},{\"id\":2068},{\"id\":2069},{\"id\":2070},{\"id\":2071},{\"id\":2072},{\"id\":2073},{\"id\":2074},{\"id\":2075},{\"id\":2076},{\"id\":2077},{\"id\":2078},{\"id\":2079},{\"id\":2080},{\"id\":2081},{\"id\":2082},{\"id\":2083},{\"id\":2084},{\"id\":2085},{\"id\":2086},{\"id\":2087},{\"id\":2088},{\"id\":2089},{\"id\":2090},{\"id\":2091},{\"id\":2092},{\"id\":2093},{\"id\":2094},{\"id\":2095},{\"id\":2096},{\"id\":2097},{\"id\":2098},{\"id\":2099},{\"id\":2100},{\"id\":2101},{\"id\":2102},{\"id\":2103},{\"id\":2104},{\"id\":2105},{\"id\":2106},{\"id\":2107},{\"id\":2108},{\"id\":2109},{\"id\":2110},{\"id\":2111},{\"id\":2112},{\"id\":2113},{\"id\":2114},{\"id\":2115},{\"id\":2116},{\"id\":2117},{\"id\":2118},{\"id\":2119},{\"id\":2120},{\"id\":2121},{\"id\":2122},{\"id\":2123},{\"id\":2124},{\"id\":2125},{\"id\":2126},{\"id\":2127},{\"id\":2128},{\"id\":2129},{\"id\":2130},{\"id\":2131},{\"id\":2132},{\"id\":2133},{\"id\":2134},{\"id\":2135},{\"id\":2136},{\"id\":2137},{\"id\":2138},{\"id\":2139},{\"id\":2140},{\"id\":2141},{\"id\":2142},{\"id\":2143},{\"id\":2144},{\"id\":2145},{\"id\":2146},{\"id\":2147},{\"id\":2148},{\"id\":2149},{\"id\":2150},{\"id\":2151},{\"id\":2152},{\"id\":2153},{\"id\":2154},{\"id\":2155},{\"id\":2156},{\"id\":2157},{\"id\":2158},{\"id\":2159},{\"id\":2160},{\"id\":2161},{\"id\":2162},{\"id\":2163},{\"id\":2164},{\"id\":2165},{\"id\":2166},{\"id\":2167},{\"id\":2168},{\"id\":2169},{\"id\":2170},{\"id\":2171},{\"id\":2172},{\"id\":2173},{\"id\":2174},{\"id\":2175},{\"id\":2176},{\"id\":2177},{\"id\":2178},{\"id\":2179},{\"id\":2180},{\"id\":2181},{\"id\":2182},{\"id\":2183},{\"id\":2184},{\"id\":2185},{\"id\":2186},{\"id\":2187},{\"id\":2188},{\"id\":2189},{\"id\":2190},{\"id\":2191},{\"id\":2192},{\"id\":2193},{\"id\":2194},{\"id\":2195},{\"id\":2196},{\"id\":2197},{\"id\":2198},{\"id\":2199},{\"id\":2200},{\"id\":2201},{\"id\":2202},{\"id\":2203},{\"id\":2204},{\"id\":2205},{\"id\":2206},{\"id\":2207},{\"id\":2208},{\"id\":2209},{\"id\":2210},{\"id\":2211},{\"id\":2212},{\"id\":2213},{\"id\":2214},{\"id\":2215},{\"id\":2216},{\"id\":2217},{\"id\":2218},{\"id\":2219},{\"id\":2220},{\"id\":2221},{\"id\":2222},{\"id\":2223},{\"id\":2224},{\"id\":2225},{\"id\":2226},{\"id\":2227},{\"id\":2228},{\"id\":2229},{\"id\":2230},{\"id\":2231},{\"id\":2232},{\"id\":2233},{\"id\":2234},{\"id\":2235},{\"id\":2236},{\"id\":2237},{\"id\":2238},{\"id\":2239},{\"id\":2240},{\"id\":2241},{\"id\":2242},{\"id\":2243},{\"id\":2244},{\"id\":2245},{\"id\":2246},{\"id\":2247},{\"id\":2248},{\"id\":2249},{\"id\":2250},{\"id\":2251},{\"id\":2252},{\"id\":2253},{\"id\":2254},{\"id\":2255},{\"id\":2256},{\"id\":2257},{\"id\":2258},{\"id\":2259},{\"id\":2260},{\"id\":2261},{\"id\":2262},{\"id\":2263},{\"id\":2264},{\"id\":2265},{\"id\":2266},{\"id\":2267},{\"id\":2268},{\"id\":2269},{\"id\":2270},{\"id\":2271},{\"id\":2272},{\"id\":2273},{\"id\":2274},{\"id\":2275},{\"id\":2276},{\"id\":2277},{\"id\":2278},{\"id\":2279},{\"id\":2280},{\"id\":2281},{\"id\":2282},{\"id\":2283},{\"id\":2284},{\"id\":2285},{\"id\":2286},{\"id\":2287},{\"id\":2288},{\"id\":2289},{\"id\":2290},{\"id\":2291},{\"id\":2292},{\"id\":2293},{\"id\":2294},{\"id\":2295},{\"id\":2296},{\"id\":2297},{\"id\":2298},{\"id\":2299},{\"id\":2300},{\"id\":2301},{\"id\":2302},{\"id\":2303},{\"id\":2304},{\"id\":2305},{\"id\":2306},{\"id\":2307},{\"id\":2308},{\"id\":2309},{\"id\":2310},{\"id\":2311},{\"id\":2312},{\"id\":2313},{\"id\":2314},{\"id\":2315},{\"id\":2316},{\"id\":2317},{\"id\":2318},{\"id\":2319},{\"id\":2320},{\"id\":2321},{\"id\":2322},{\"id\":2323},{\"id\":2324},{\"id\":2325},{\"id\":2326},{\"id\":2327},{\"id\":2328},{\"id\":2329},{\"id\":2330},{\"id\":2331},{\"id\":2332},{\"id\":2333},{\"id\":2334},{\"id\":2335},{\"id\":2336},{\"id\":2337},{\"id\":2338},{\"id\":2339},{\"id\":2340},{\"id\":2341},{\"id\":2342},{\"id\":2343},{\"id\":2344},{\"id\":2345},{\"id\":2346},{\"id\":2347},{\"id\":2348},{\"id\":2349},{\"id\":2350},{\"id\":2351},{\"id\":2352},{\"id\":2353},{\"id\":2354},{\"id\":2355},{\"id\":2356},{\"id\":2357},{\"id\":2358},{\"id\":2359},{\"id\":2360},{\"id\":2361},{\"id\":2362},{\"id\":2363},{\"id\":2364},{\"id\":2365},{\"id\":2366},{\"id\":2367},{\"id\":2368},{\"id\":2369},{\"id\":2370},{\"id\":2371},{\"id\":2372},{\"id\":2373},{\"id\":2374},{\"id\":2375},{\"id\":2376},{\"id\":2377},{\"id\":2378},{\"id\":2379},{\"id\":2380},{\"id\":2381},{\"id\":2382},{\"id\":2383},{\"id\":2384},{\"id\":2385},{\"id\":2386},{\"id\":2387},{\"id\":2388},{\"id\":2389},{\"id\":2390},{\"id\":2391},{\"id\":2392},{\"id\":2393},{\"id\":2394},{\"id\":2395},{\"id\":2396},{\"id\":2397},{\"id\":2398},{\"id\":2399},{\"id\":2400},{\"id\":2401},{\"id\":2402},{\"id\":2403},{\"id\":2404},{\"id\":2405},{\"id\":2406},{\"id\":2407},{\"id\":2408},{\"id\":2409},{\"id\":2410},{\"id\":2411},{\"id\":2412},{\"id\":2413},{\"id\":2414},{\"id\":2415},{\"id\":2416},{\"id\":2417},{\"id\":2418},{\"id\":2419},{\"id\":2420},{\"id\":2421},{\"id\":2422},{\"id\":2423},{\"id\":2424},{\"id\":2425},{\"id\":2426},{\"id\":2427},{\"id\":2428},{\"id\":2429},{\"id\":2430},{\"id\":2431},{\"id\":2432},{\"id\":2433},{\"id\":2434},{\"id\":2435},{\"id\":2436},{\"id\":2437},{\"id\":2438},{\"id\":2439},{\"id\":2440},{\"id\":2441},{\"id\":2442},{\"id\":2443},{\"id\":2444},{\"id\":2445},{\"id\":2446},{\"id\":2447},{\"id\":2448},{\"id\":2449},{\"id\":2450},{\"id\":2451},{\"id\":2452},{\"id\":2453},{\"id\":2454},{\"id\":2455},{\"id\":2456},{\"id\":2457},{\"id\":2458},{\"id\":2459},{\"id\":2460},{\"id\":2461},{\"id\":2462},{\"id\":2463},{\"id\":2464},{\"id\":2465},{\"id\":2466},{\"id\":2467},{\"id\":2468},{\"id\":2469},{\"id\":2470},{\"id\":2471},{\"id\":2472},{\"id\":2473},{\"id\":2474},{\"id\":2475},{\"id\":2476},{\"id\":2477},{\"id\":2478},{\"id\":2479},{\"id\":2480},{\"id\":2481},{\"id\":2482},{\"id\":2483},{\"id\":2484},{\"id\":2485},{\"id\":2486},{\"id\":2487},{\"id\":2488},{\"id\":2489},{\"id\":2490},{\"id\":2491},{\"id\":2492},{\"id\":2493},{\"id\":2494},{\"id\":2495},{\"id\":2496},{\"id\":2497},{\"id\":2498},{\"id\":2499},{\"id\":2500},{\"id\":2501},{\"id\":2502},{\"id\":2503},{\"id\":2504},{\"id\":2505},{\"id\":2506},{\"id\":2507},{\"id\":2508},{\"id\":2509},{\"id\":2510},{\"id\":2511},{\"id\":2512},{\"id\":2513},{\"id\":2514},{\"id\":2515},{\"id\":2516},{\"id\":2517},{\"id\":2518},{\"id\":2519},{\"id\":2520},{\"id\":2521},{\"id\":2522},{\"id\":2523},{\"id\":2524},{\"id\":2525},{\"id\":2526},{\"id\":2527},{\"id\":2528},{\"id\":2529},{\"id\":2530},{\"id\":2531},{\"id\":2532},{\"id\":2533},{\"id\":2534},{\"id\":2535},{\"id\":2536},{\"id\":2537},{\"id\":2538},{\"id\":2539},{\"id\":2540},{\"id\":2541},{\"id\":2542},{\"id\":2543},{\"id\":2544},{\"id\":2545},{\"id\":2546},{\"id\":2547},{\"id\":2548},{\"id\":2549},{\"id\":2550},{\"id\":2551},{\"id\":2552},{\"id\":2553},{\"id\":2554},{\"id\":2555},{\"id\":2556},{\"id\":2557},{\"id\":2558},{\"id\":2559},{\"id\":2560},{\"id\":2561},{\"id\":2562},{\"id\":2563},{\"id\":2564},{\"id\":2565},{\"id\":2566},{\"id\":2567},{\"id\":2568},{\"id\":2569},{\"id\":2570},{\"id\":2571},{\"id\":2572},{\"id\":2573},{\"id\":2574},{\"id\":2575},{\"id\":2576},{\"id\":2577},{\"id\":2578},{\"id\":2579},{\"id\":2580},{\"id\":2581},{\"id\":2582},{\"id\":2583},{\"id\":2584},{\"id\":2585},{\"id\":2586},{\"id\":2587},{\"id\":2588},{\"id\":2589},{\"id\":2590},{\"id\":2591},{\"id\":2592},{\"nodeType\":3,\"id\":2596,\"textContent\":\" // Track clicks on page $(document).ready(function() { $(\\\".control\\\").click(function(e) { e.stopImmediatePropagation(); clicks = clicks + 1; console.log(clicks); }); }); $('.userid').html(sid); // console.log(\\\"start of clicked array: \\\"+clicked); // console.log(\\\"start of hovered string: \\\"+hovered); //set correct answers for each question var triangular_answers = { \\\"acme.starttime.1\\\" : [\\\"F\\\"], \\\"acme.starts.1\\\" : [\\\"K\\\"], \\\"acme.meets.1\\\" : [\\\"F\\\"], \\\"acme.endtime.1\\\" : [\\\"H\\\"], \\\"acme.midpoint.1\\\" : [\\\"O\\\"], \\\"acme.starttime.2\\\" : [\\\"F\\\"], \\\"acme.starts.2\\\" : [\\\"K\\\"], \\\"acme.meets.2\\\" : [\\\"F\\\"], \\\"acme.endtime.2\\\" : [\\\"H\\\"], \\\"acme.midpoint.2\\\" : [\\\"A\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"E\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"E\\\"], \\\"bigset.starttime.1\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.1\\\" : [\\\"G\\\"], \\\"bigset.meets.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.1\\\" : [\\\"X\\\"], \\\"bigset.midpoint.1\\\" : [\\\"K\\\",\\\"X\\\"], \\\"bigset.starttime.2\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.2\\\" : [\\\"G\\\"], \\\"bigset.meets.2\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.2\\\" : [\\\"X\\\"], \\\"bigset.midpoint.2\\\" : [\\\"K\\\",\\\"X\\\"] } var orthogonal_answers = { \\\"acme.starttime.1\\\" : [\\\"A\\\"], \\\"acme.starts.1\\\" : [\\\"E\\\"], \\\"acme.meets.1\\\" : [\\\"Z\\\"], \\\"acme.endtime.1\\\" : [\\\"U\\\"], \\\"acme.midpoint.1\\\" : [\\\"U\\\"], \\\"acme.starttime.2\\\" : [\\\"0\\\"], \\\"acme.starts.2\\\" : [\\\"0\\\"], \\\"acme.meets.2\\\" : [\\\"0\\\"], \\\"acme.endtime.2\\\" : [\\\"0\\\"], \\\"acme.midpoint.2\\\" : [\\\"0\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"X\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"X\\\"], \\\"bigset.starttime.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.1\\\" : [\\\"B\\\"], \\\"bigset.meets.1\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.1\\\" : [\\\"B\\\"], \\\"bigset.midpoint.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.starttime.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.2\\\" : [\\\"B\\\"], \\\"bigset.meets.2\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.2\\\" : [\\\"B\\\"], \\\"bigset.midpoint.2\\\" : [\\\"E\\\",\\\"F\\\"] } //display the question and answer buttons based on input values from jsPsych document.getElementById(scenario+\\\".\\\"+question).style.display = \\\"block\\\"; if (question == \\\"strategy\\\") {document.getElementById(\\\"strategyButton\\\").style.display = \\\"block\\\";} else {document.getElementById(\\\"testingButton\\\").style.display = \\\"block\\\";} //---------SET PROPERTIES OF THE GRAPH -------------// // set the dimensions and margins of the graph var margin = {top: 25, right: 30, bottom: 90, left: 100}, width = 800, height = 800; var intersects = false; //default value for intersects scaffold var xAxisTitle, yAxisTitle; var datafile =\\\"\\\"; // SET AXIS VALUES if (axis == 1){ axis = \\\"Orthogonal-XInside-YFull\\\"; } else if (axis == 2){ axis = \\\"Orthogonal-XInside-YPartial\\\"; } else if (axis ==3){ axis = \\\"Triangular-XInside-YInside\\\"; } else if (axis ==4){ axis = \\\"Orthogonal-XInside-YInside\\\"; } else if (axis ==5){ axis = \\\"Orthogonal-XFull-YFull\\\"; } // SET EXPLICIT SCAFFOLD FEATURES if (explicit ==2 && axis != \\\"diagonal\\\"){ scaffold = 2; intersects = false; } else if (explicit == 2 && axis == \\\"diagonal\\\"){ scaffold = 2; intersects = false; } //TODO: not sure if above two lines are still valid since leaders are now generated on the fly else if (explicit == 3){ $('#hint-interactive').css(\\\"display\\\",\\\"block\\\"); //display textimage scaffold intersects = true; } //SET DATA FILE FOR IMPLICIT SCAFFOLD if (impasse == 1){ datafile = \\\"../views/src/data/acme_nonimpasse.csv\\\"; } else if (impasse == 2){ datafile = \\\"../views/src/data/acme_impasse.csv\\\"; } //OVERRIDE DATA FILE FOR NON-SCAFFOLD QUESTIONS if (q > 5) { //override data file if q# is greater than 5 datafile = \\\"../views/src/data/bigset.csv\\\"; console.log(\\\"override data file\\\"); $('#orthogonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#diagonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#hint-interactive').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold intersects = false; } // //---------CREATE THE SVG ------------------------// var svg = d3.select(\\\".d3container\\\").append(\\\"svg\\\") .attr(\\\"width\\\", width + margin.left + margin.right) .attr(\\\"height\\\", height + margin.top + margin.bottom) .append(\\\"g\\\") .attr(\\\"transform\\\", \\\"translate(\\\" + margin.left + \\\",\\\" + margin.top + \\\")\\\"); //---------DRAW THE GRAPH ------------------------// xAxisTitle = \\\"START & END TIME (time of day)\\\"; yAxisTitle = \\\"DURATION (in hours)\\\"; drawTriangleModel(datafile,intersects,axis,scaffold,q); \"},{\"id\":2593},{\"id\":2594},{\"nodeType\":3,\"id\":2597,\"textContent\":\" //MOUSE LOGGING SCRIPT var mouseLog = [] var xwidth = $(document).width(); var xheight = $(document).width(); mouseLog.push(\\\"{x:\\\"+xwidth+\\\",y:\\\"+xheight+\\\",t:\\\"+\\\"0};\\\") document.onmousemove = function(e){ var pageCoords = \\\"{x:\\\" + e.pageX + \\\",y:\\\"+ e.pageY +\\\",t:\\\"+ Date.now()+ \\\"};\\\" ; mouseLog.push(pageCoords); // console.log(pageCoords); }; \"},{\"id\":2595}],[],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2598,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2599,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2598},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2600,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2599},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2601,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":2600},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2602,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2599}},{\"nodeType\":1,\"id\":2603,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2602},\"parentNode\":{\"id\":2599}},{\"nodeType\":3,\"id\":2604,\"textContent\":\"What is your age?\",\"parentNode\":{\"id\":2602}},{\"nodeType\":1,\"id\":2605,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2600}},{\"nodeType\":1,\"id\":2606,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2605},\"parentNode\":{\"id\":2600}},{\"nodeType\":3,\"id\":2607,\"textContent\":\"In what country were you born?\",\"parentNode\":{\"id\":2605}},{\"nodeType\":3,\"id\":2608,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":2601}}],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2598},{\"id\":2599},{\"id\":2602},{\"id\":2604},{\"id\":2603},{\"id\":2600},{\"id\":2605},{\"id\":2607},{\"id\":2606},{\"id\":2601},{\"id\":2608}],[],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2609,\"tagName\":\"FORM\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-form\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2610,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-preamble\",\"class\":\"jspsych-survey-multi-choice-preamble\"},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2611,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-0\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2610},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2612,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-1\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2611},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2613,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-2\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2612},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2614,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-3\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2613},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2615,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"submit\",\"id\":\"jspsych-survey-multi-choice-next\",\"class\":\"jspsych-survey-multi-choice jspsych-btn\",\"value\":\"Submit Answers\"},\"previousSibling\":{\"id\":2614},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2616,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2617,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2616},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2618,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2617},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2619,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2618},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2620,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2619},\"parentNode\":{\"id\":2611}},{\"nodeType\":3,\"id\":2621,\"textContent\":\"What is your first language?\",\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2622,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2621},\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2623,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2624,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2623}},{\"nodeType\":3,\"id\":2625,\"textContent\":\"English\",\"previousSibling\":{\"id\":2624},\"parentNode\":{\"id\":2623}},{\"nodeType\":1,\"id\":2626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2618}},{\"nodeType\":1,\"id\":2627,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2626}},{\"nodeType\":3,\"id\":2628,\"textContent\":\"Spanish\",\"previousSibling\":{\"id\":2627},\"parentNode\":{\"id\":2626}},{\"nodeType\":1,\"id\":2629,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2619}},{\"nodeType\":1,\"id\":2630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2629}},{\"nodeType\":3,\"id\":2631,\"textContent\":\"Mandarin or Cantonese\",\"previousSibling\":{\"id\":2630},\"parentNode\":{\"id\":2629}},{\"nodeType\":1,\"id\":2632,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2633,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2634,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2633},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2635,\"textContent\":\"*\",\"parentNode\":{\"id\":2622}},{\"nodeType\":1,\"id\":2636,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2637,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2636},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2638,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2637},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2639,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2638},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2640,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2639},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2641,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2640},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2642,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2641},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2643,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2642},\"parentNode\":{\"id\":2612}},{\"nodeType\":3,\"id\":2644,\"textContent\":\"What is your year in school?\",\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2645,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2644},\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2646,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2637}},{\"nodeType\":1,\"id\":2647,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2646}},{\"nodeType\":3,\"id\":2648,\"textContent\":\"First\",\"previousSibling\":{\"id\":2647},\"parentNode\":{\"id\":2646}},{\"nodeType\":1,\"id\":2649,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2638}},{\"nodeType\":1,\"id\":2650,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2649}},{\"nodeType\":3,\"id\":2651,\"textContent\":\"Second\",\"previousSibling\":{\"id\":2650},\"parentNode\":{\"id\":2649}},{\"nodeType\":1,\"id\":2652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2639}},{\"nodeType\":1,\"id\":2653,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2652}},{\"nodeType\":3,\"id\":2654,\"textContent\":\"Third\",\"previousSibling\":{\"id\":2653},\"parentNode\":{\"id\":2652}},{\"nodeType\":1,\"id\":2655,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2640}},{\"nodeType\":1,\"id\":2656,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2655}},{\"nodeType\":3,\"id\":2657,\"textContent\":\"Fourth\",\"previousSibling\":{\"id\":2656},\"parentNode\":{\"id\":2655}},{\"nodeType\":1,\"id\":2658,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2641}},{\"nodeType\":1,\"id\":2659,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2658}},{\"nodeType\":3,\"id\":2660,\"textContent\":\"Fifth\",\"previousSibling\":{\"id\":2659},\"parentNode\":{\"id\":2658}},{\"nodeType\":1,\"id\":2661,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2642}},{\"nodeType\":1,\"id\":2662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2661}},{\"nodeType\":3,\"id\":2663,\"textContent\":\"Graduate\",\"previousSibling\":{\"id\":2662},\"parentNode\":{\"id\":2661}},{\"nodeType\":1,\"id\":2664,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2643}},{\"nodeType\":1,\"id\":2665,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2666,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2665},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2667,\"textContent\":\"*\",\"parentNode\":{\"id\":2645}},{\"nodeType\":1,\"id\":2668,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2669,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2668},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2670,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2669},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2671,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2670},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2672,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2671},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2673,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2672},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2674,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2673},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2675,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2674},\"parentNode\":{\"id\":2613}},{\"nodeType\":3,\"id\":2676,\"textContent\":\"What is your major area of study?\",\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2677,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2676},\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2678,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2669}},{\"nodeType\":1,\"id\":2679,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2678}},{\"nodeType\":3,\"id\":2680,\"textContent\":\"Math or Computer Sciences\",\"previousSibling\":{\"id\":2679},\"parentNode\":{\"id\":2678}},{\"nodeType\":1,\"id\":2681,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2670}},{\"nodeType\":1,\"id\":2682,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2681}},{\"nodeType\":3,\"id\":2683,\"textContent\":\"Social Sciences (incl. CogSci)\",\"previousSibling\":{\"id\":2682},\"parentNode\":{\"id\":2681}},{\"nodeType\":1,\"id\":2684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2671}},{\"nodeType\":1,\"id\":2685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2684}},{\"nodeType\":3,\"id\":2686,\"textContent\":\"Biomedical & Health Sciences\",\"previousSibling\":{\"id\":2685},\"parentNode\":{\"id\":2684}},{\"nodeType\":1,\"id\":2687,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2672}},{\"nodeType\":1,\"id\":2688,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2687}},{\"nodeType\":3,\"id\":2689,\"textContent\":\"Natural Sciences\",\"previousSibling\":{\"id\":2688},\"parentNode\":{\"id\":2687}},{\"nodeType\":1,\"id\":2690,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2673}},{\"nodeType\":1,\"id\":2691,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2690}},{\"nodeType\":3,\"id\":2692,\"textContent\":\"Engineering\",\"previousSibling\":{\"id\":2691},\"parentNode\":{\"id\":2690}},{\"nodeType\":1,\"id\":2693,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2674}},{\"nodeType\":1,\"id\":2694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2693}},{\"nodeType\":3,\"id\":2695,\"textContent\":\"Humanities\",\"previousSibling\":{\"id\":2694},\"parentNode\":{\"id\":2693}},{\"nodeType\":1,\"id\":2696,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2675}},{\"nodeType\":1,\"id\":2697,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2698,\"textContent\":\"Fine Arts\",\"previousSibling\":{\"id\":2697},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2699,\"textContent\":\"*\",\"parentNode\":{\"id\":2677}},{\"nodeType\":1,\"id\":2700,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2701,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2700},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2702,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2701},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2703,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2702},\"parentNode\":{\"id\":2614}},{\"nodeType\":3,\"id\":2704,\"textContent\":\"What is your gender?\",\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2705,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2704},\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2706,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2701}},{\"nodeType\":1,\"id\":2707,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2706}},{\"nodeType\":3,\"id\":2708,\"textContent\":\"Male\",\"previousSibling\":{\"id\":2707},\"parentNode\":{\"id\":2706}},{\"nodeType\":1,\"id\":2709,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2702}},{\"nodeType\":1,\"id\":2710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2709}},{\"nodeType\":3,\"id\":2711,\"textContent\":\"Female\",\"previousSibling\":{\"id\":2710},\"parentNode\":{\"id\":2709}},{\"nodeType\":1,\"id\":2712,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2703}},{\"nodeType\":1,\"id\":2713,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2714,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2713},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2715,\"textContent\":\"*\",\"parentNode\":{\"id\":2705}}],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2609},{\"id\":2610},{\"id\":2611},{\"id\":2616},{\"id\":2621},{\"id\":2622},{\"id\":2635},{\"id\":2617},{\"id\":2623},{\"id\":2624},{\"id\":2625},{\"id\":2618},{\"id\":2626},{\"id\":2627},{\"id\":2628},{\"id\":2619},{\"id\":2629},{\"id\":2630},{\"id\":2631},{\"id\":2620},{\"id\":2632},{\"id\":2633},{\"id\":2634},{\"id\":2612},{\"id\":2636},{\"id\":2644},{\"id\":2645},{\"id\":2667},{\"id\":2637},{\"id\":2646},{\"id\":2647},{\"id\":2648},{\"id\":2638},{\"id\":2649},{\"id\":2650},{\"id\":2651},{\"id\":2639},{\"id\":2652},{\"id\":2653},{\"id\":2654},{\"id\":2640},{\"id\":2655},{\"id\":2656},{\"id\":2657},{\"id\":2641},{\"id\":2658},{\"id\":2659},{\"id\":2660},{\"id\":2642},{\"id\":2661},{\"id\":2662},{\"id\":2663},{\"id\":2643},{\"id\":2664},{\"id\":2665},{\"id\":2666},{\"id\":2613},{\"id\":2668},{\"id\":2676},{\"id\":2677},{\"id\":2699},{\"id\":2669},{\"id\":2678},{\"id\":2679},{\"id\":2680},{\"id\":2670},{\"id\":2681},{\"id\":2682},{\"id\":2683},{\"id\":2671},{\"id\":2684},{\"id\":2685},{\"id\":2686},{\"id\":2672},{\"id\":2687},{\"id\":2688},{\"id\":2689},{\"id\":2673},{\"id\":2690},{\"id\":2691},{\"id\":2692},{\"id\":2674},{\"id\":2693},{\"id\":2694},{\"id\":2695},{\"id\":2675},{\"id\":2696},{\"id\":2697},{\"id\":2698},{\"id\":2614},{\"id\":2700},{\"id\":2704},{\"id\":2705},{\"id\":2715},{\"id\":2701},{\"id\":2706},{\"id\":2707},{\"id\":2708},{\"id\":2702},{\"id\":2709},{\"id\":2710},{\"id\":2711},{\"id\":2703},{\"id\":2712},{\"id\":2713},{\"id\":2714},{\"id\":2615}],[],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2716,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2717,\"textContent\":\" \",\"previousSibling\":{\"id\":2716},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2718,\"textContent\":\" \",\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":2718},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2720,\"textContent\":\" \",\"previousSibling\":{\"id\":2719},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2721,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":2720},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2722,\"textContent\":\" \",\"previousSibling\":{\"id\":2721},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2723,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":2722},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2724,\"textContent\":\" \",\"previousSibling\":{\"id\":2723},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2725,\"textContent\":\" \",\"parentNode\":{\"id\":2719}},{\"nodeType\":1,\"id\":2726,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":2725},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2727,\"textContent\":\" \",\"previousSibling\":{\"id\":2726},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2728,\"textContent\":\" \",\"parentNode\":{\"id\":2726}},{\"nodeType\":1,\"id\":2729,\"tagName\":\"H3\",\"attributes\":{},\"previousSibling\":{\"id\":2728},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2730,\"textContent\":\" \",\"previousSibling\":{\"id\":2729},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2731,\"textContent\":\"DEBRIEFING\",\"parentNode\":{\"id\":2729}},{\"nodeType\":3,\"id\":2732,\"textContent\":\" \",\"parentNode\":{\"id\":2721}},{\"nodeType\":1,\"id\":2733,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":2732},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2734,\"textContent\":\" \",\"previousSibling\":{\"id\":2733},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2735,\"textContent\":\" \",\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2736,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic\"},\"previousSibling\":{\"id\":2735},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2737,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2736},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2738,\"textContent\":\" \",\"previousSibling\":{\"id\":2737},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2739,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2738},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2740,\"textContent\":\" \",\"previousSibling\":{\"id\":2739},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2741,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2740},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2742,\"textContent\":\" \",\"previousSibling\":{\"id\":2741},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2743,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:bold;\"},\"previousSibling\":{\"id\":2742},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2744,\"textContent\":\" \",\"previousSibling\":{\"id\":2743},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2745,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":2744},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2746,\"textContent\":\" \",\"previousSibling\":{\"id\":2745},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2747,\"textContent\":\"Thank you very much for your participation! This debriefing will tell you more about the study, what you did, and why. \",\"parentNode\":{\"id\":2736}},{\"nodeType\":3,\"id\":2748,\"textContent\":\" \",\"parentNode\":{\"id\":2737}},{\"nodeType\":1,\"id\":2749,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2748},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2750,\"textContent\":\" You have just used a series of pictures (charts, graphs and diagrams) accompanied by different types of instructions to answer a series of problem solving questions. While you were using the pictures, we measured where you clicked, scrolled and pointed with the computer mouse. We also measured the accuracy of your responses and the time it took to complete each question.\",\"previousSibling\":{\"id\":2749},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2751,\"textContent\":\"What did you just do?\",\"parentNode\":{\"id\":2749}},{\"nodeType\":3,\"id\":2752,\"textContent\":\" \",\"parentNode\":{\"id\":2739}},{\"nodeType\":1,\"id\":2753,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2752},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2754,\"textContent\":\" Researchers of learning and cognition have long been interested in how graphic displays of information can be used to communicate, solve problems, and generate insights. As powerful as graphics may be in their communicative efficiency, they're not always immediately intuitive to understand. In short, we know a great deal more about learning with representations than we do about the learning of representations. In this project we are building upon previous research on reading and graph comprehension to explore how readers make sense of unfamiliar representations. The instructions you saw for each type of graph are known as “scaffolding techniques”, and we will compare your performance with the scaffolding techniques you saw with the performance of other participants to determine which types of instructions are most effective in helping humans to make sense of unfamiliar graphs. \",\"previousSibling\":{\"id\":2753},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2755,\"textContent\":\"Why did we have you do it?\",\"parentNode\":{\"id\":2753}},{\"nodeType\":1,\"id\":2756,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2757,\"textContent\":\" We expect that you will have found some of the graphics more difficult to use than others. We also expect that with the assistance of the instructions, after solving several problems you will learn to use the difficult graphics so that you can answer the questions even more quickly than without. If you would like to receive a copy of the results of the study, or have any further questions, please contact the researchers Primary Researcher: Amy Fox : a2fox@ucsd.edu Faculty Advisor : Dr. Jim Hollan : hollan@ucsd.edu \",\"previousSibling\":{\"id\":2756},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2758,\"textContent\":\"What do we expect to find?\",\"parentNode\":{\"id\":2756}},{\"nodeType\":3,\"id\":2759,\"textContent\":\"It is important that you do not discuss this experiment with other students who might participate after you. They must participate in the same way as you did, without any knowledge of what the experiment entails, or the reasoning behind it.\",\"parentNode\":{\"id\":2743}},{\"nodeType\":3,\"id\":2760,\"textContent\":\"Thank you for your time! We hope you enjoyed participating in this study as much as we enjoyed designing it.\",\"parentNode\":{\"id\":2745}},{\"nodeType\":3,\"id\":2761,\"textContent\":\" \",\"parentNode\":{\"id\":2723}},{\"nodeType\":1,\"id\":2762,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":2761},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2763,\"textContent\":\" \",\"previousSibling\":{\"id\":2762},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2764,\"textContent\":\"FINISH\",\"parentNode\":{\"id\":2762}}],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2716},{\"id\":2718},{\"id\":2719},{\"id\":2725},{\"id\":2726},{\"id\":2728},{\"id\":2729},{\"id\":2731},{\"id\":2730},{\"id\":2727},{\"id\":2720},{\"id\":2721},{\"id\":2732},{\"id\":2733},{\"id\":2735},{\"id\":2736},{\"id\":2747},{\"id\":2737},{\"id\":2748},{\"id\":2749},{\"id\":2751},{\"id\":2750},{\"id\":2738},{\"id\":2739},{\"id\":2752},{\"id\":2753},{\"id\":2755},{\"id\":2754},{\"id\":2740},{\"id\":2741},{\"id\":2756},{\"id\":2758},{\"id\":2757},{\"id\":2742},{\"id\":2743},{\"id\":2759},{\"id\":2744},{\"id\":2745},{\"id\":2760},{\"id\":2746},{\"id\":2734},{\"id\":2722},{\"id\":2723},{\"id\":2761},{\"id\":2762},{\"id\":2764},{\"id\":2763},{\"id\":2724},{\"id\":2717}],[],[],[]]}"
    },
    {
      "sequence": 8,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2765,\"tagName\":\"PRE\",\"attributes\":{\"id\":\"jspsych-data-display\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2766,\"textContent\":\"[ { \\\"rt\\\": 154870, \\\"stimulus\\\": \\\"img/phone.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"phone\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 0, \\\"time_elapsed\\\": 154874, \\\"internal_node_id\\\": \\\"0.0-0.0\\\", \\\"subject\\\": \\\"WKBNA\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\" }, { \\\"rt\\\": 42821, \\\"url\\\": \\\"../views/src/external/consent.html\\\", \\\"block\\\": \\\"consent\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 1, \\\"time_elapsed\\\": 199027, \\\"internal_node_id\\\": \\\"0.0-1.0\\\", \\\"subject\\\": \\\"WKBNA\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\" }, { \\\"rt\\\": 11514, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"CHARLIE\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"111\\\\\\\"}\\\", \\\"block\\\": \\\"codes\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 2, \\\"time_elapsed\\\": 211546, \\\"internal_node_id\\\": \\\"0.0-2.0\\\", \\\"subject\\\": \\\"WKBNA\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\" }, { \\\"rt\\\": 37944, \\\"url\\\": \\\"../views/src/external/instructions_lab.html\\\", \\\"block\\\": \\\"instructions_lab\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 3, \\\"time_elapsed\\\": 250574, \\\"internal_node_id\\\": \\\"0.0-3.0\\\", \\\"subject\\\": \\\"WKBNA\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\" }, { \\\"rt\\\": 13945, \\\"stimulus\\\": \\\"img/acme.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"scenario\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 4, \\\"time_elapsed\\\": 265521, \\\"internal_node_id\\\": \\\"0.0-4.0\\\", \\\"subject\\\": \\\"WKBNA\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\" }, { \\\"rt\\\": 74261, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 5, \\\"time_elapsed\\\": 341147, \\\"internal_node_id\\\": \\\"0.0-5.0-0.0\\\", \\\"subject\\\": \\\"WKBNA\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 1, \\\"clicks\\\": 3, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-11 AM-A -A -A -A -A -A -A -01 PM-11 AM-11 AM-11 AM-12 PM-A -A -A -O -A -10 AM-10 AM-12 PM-08 AM-C -12 PM-C -F -11 AM-11 AM-11 AM-11 AM-10 AM\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:949,y:1012,t:1526929908053};\\\", \\\"{x:954,y:1009,t:1526929908064};\\\", \\\"{x:973,y:1009,t:1526929908080};\\\", \\\"{x:985,y:1009,t:1526929908098};\\\", \\\"{x:987,y:1011,t:1526929908114};\\\", \\\"{x:991,y:1012,t:1526929908130};\\\", \\\"{x:993,y:1014,t:1526929908147};\\\", \\\"{x:994,y:1019,t:1526929908164};\\\", \\\"{x:994,y:1022,t:1526929908180};\\\", \\\"{x:994,y:1024,t:1526929908197};\\\", \\\"{x:995,y:1023,t:1526929908349};\\\", \\\"{x:1002,y:1018,t:1526929908364};\\\", \\\"{x:1012,y:1012,t:1526929908380};\\\", \\\"{x:1020,y:1008,t:1526929908397};\\\", \\\"{x:1026,y:1005,t:1526929908414};\\\", \\\"{x:1034,y:1004,t:1526929908431};\\\", \\\"{x:1041,y:1001,t:1526929908447};\\\", \\\"{x:1054,y:1001,t:1526929908464};\\\", \\\"{x:1069,y:1001,t:1526929908481};\\\", \\\"{x:1092,y:1001,t:1526929908497};\\\", \\\"{x:1112,y:1001,t:1526929908514};\\\", \\\"{x:1132,y:1003,t:1526929908531};\\\", \\\"{x:1150,y:1009,t:1526929908547};\\\", \\\"{x:1182,y:1012,t:1526929908564};\\\", \\\"{x:1205,y:1013,t:1526929908581};\\\", \\\"{x:1220,y:1013,t:1526929908597};\\\", \\\"{x:1232,y:1010,t:1526929908614};\\\", \\\"{x:1243,y:1002,t:1526929908631};\\\", \\\"{x:1250,y:998,t:1526929908648};\\\", \\\"{x:1256,y:994,t:1526929908664};\\\", \\\"{x:1258,y:990,t:1526929908681};\\\", \\\"{x:1259,y:990,t:1526929908698};\\\", \\\"{x:1259,y:989,t:1526929908828};\\\", \\\"{x:1260,y:987,t:1526929908835};\\\", \\\"{x:1261,y:986,t:1526929908848};\\\", \\\"{x:1261,y:983,t:1526929908864};\\\", \\\"{x:1264,y:980,t:1526929908881};\\\", \\\"{x:1264,y:979,t:1526929908908};\\\", \\\"{x:1265,y:978,t:1526929908939};\\\", \\\"{x:1265,y:977,t:1526929908979};\\\", \\\"{x:1266,y:976,t:1526929909004};\\\", \\\"{x:1267,y:975,t:1526929909020};\\\", \\\"{x:1267,y:974,t:1526929909036};\\\", \\\"{x:1268,y:973,t:1526929909048};\\\", \\\"{x:1269,y:971,t:1526929909064};\\\", \\\"{x:1271,y:969,t:1526929909081};\\\", \\\"{x:1271,y:967,t:1526929909099};\\\", \\\"{x:1271,y:966,t:1526929909117};\\\", \\\"{x:1272,y:964,t:1526929909261};\\\", \\\"{x:1273,y:963,t:1526929909277};\\\", \\\"{x:1274,y:962,t:1526929909285};\\\", \\\"{x:1274,y:960,t:1526929909300};\\\", \\\"{x:1276,y:959,t:1526929909461};\\\", \\\"{x:1278,y:958,t:1526929909477};\\\", \\\"{x:1279,y:957,t:1526929909484};\\\", \\\"{x:1280,y:957,t:1526929909501};\\\", \\\"{x:1282,y:956,t:1526929909515};\\\", \\\"{x:1283,y:956,t:1526929909531};\\\", \\\"{x:1285,y:956,t:1526929909549};\\\", \\\"{x:1286,y:957,t:1526929909581};\\\", \\\"{x:1287,y:958,t:1526929909653};\\\", \\\"{x:1287,y:957,t:1526929911917};\\\", \\\"{x:1285,y:952,t:1526929911934};\\\", \\\"{x:1284,y:947,t:1526929911950};\\\", \\\"{x:1282,y:943,t:1526929911967};\\\", \\\"{x:1280,y:939,t:1526929911983};\\\", \\\"{x:1279,y:934,t:1526929912001};\\\", \\\"{x:1277,y:926,t:1526929912017};\\\", \\\"{x:1276,y:921,t:1526929912033};\\\", \\\"{x:1276,y:916,t:1526929912052};\\\", \\\"{x:1275,y:911,t:1526929912068};\\\", \\\"{x:1273,y:907,t:1526929912084};\\\", \\\"{x:1273,y:900,t:1526929912100};\\\", \\\"{x:1273,y:897,t:1526929912117};\\\", \\\"{x:1272,y:891,t:1526929912134};\\\", \\\"{x:1272,y:889,t:1526929912150};\\\", \\\"{x:1272,y:885,t:1526929912168};\\\", \\\"{x:1272,y:881,t:1526929912183};\\\", \\\"{x:1271,y:876,t:1526929912200};\\\", \\\"{x:1270,y:872,t:1526929912218};\\\", \\\"{x:1269,y:867,t:1526929912233};\\\", \\\"{x:1269,y:864,t:1526929912251};\\\", \\\"{x:1269,y:863,t:1526929912268};\\\", \\\"{x:1269,y:862,t:1526929912284};\\\", \\\"{x:1269,y:861,t:1526929912301};\\\", \\\"{x:1269,y:860,t:1526929912940};\\\", \\\"{x:1269,y:859,t:1526929912956};\\\", \\\"{x:1269,y:858,t:1526929912967};\\\", \\\"{x:1269,y:857,t:1526929912984};\\\", \\\"{x:1269,y:856,t:1526929913000};\\\", \\\"{x:1269,y:855,t:1526929913017};\\\", \\\"{x:1269,y:853,t:1526929913036};\\\", \\\"{x:1269,y:852,t:1526929913060};\\\", \\\"{x:1269,y:851,t:1526929913093};\\\", \\\"{x:1269,y:850,t:1526929913244};\\\", \\\"{x:1269,y:849,t:1526929913252};\\\", \\\"{x:1269,y:848,t:1526929913268};\\\", \\\"{x:1269,y:845,t:1526929913285};\\\", \\\"{x:1270,y:840,t:1526929913302};\\\", \\\"{x:1274,y:832,t:1526929913317};\\\", \\\"{x:1278,y:825,t:1526929913337};\\\", \\\"{x:1279,y:823,t:1526929913351};\\\", \\\"{x:1280,y:822,t:1526929913367};\\\", \\\"{x:1280,y:825,t:1526929913886};\\\", \\\"{x:1279,y:829,t:1526929913901};\\\", \\\"{x:1278,y:831,t:1526929913928};\\\", \\\"{x:1277,y:832,t:1526929913940};\\\", \\\"{x:1277,y:834,t:1526929914557};\\\", \\\"{x:1277,y:835,t:1526929914569};\\\", \\\"{x:1277,y:836,t:1526929914595};\\\", \\\"{x:1277,y:837,t:1526929914611};\\\", \\\"{x:1277,y:838,t:1526929914627};\\\", \\\"{x:1278,y:838,t:1526929914635};\\\", \\\"{x:1278,y:839,t:1526929914667};\\\", \\\"{x:1278,y:840,t:1526929914699};\\\", \\\"{x:1278,y:841,t:1526929914716};\\\", \\\"{x:1279,y:841,t:1526929914732};\\\", \\\"{x:1279,y:842,t:1526929914900};\\\", \\\"{x:1280,y:842,t:1526929914907};\\\", \\\"{x:1281,y:842,t:1526929914918};\\\", \\\"{x:1282,y:842,t:1526929914935};\\\", \\\"{x:1284,y:842,t:1526929914952};\\\", \\\"{x:1284,y:840,t:1526929914969};\\\", \\\"{x:1285,y:838,t:1526929914985};\\\", \\\"{x:1285,y:837,t:1526929915093};\\\", \\\"{x:1284,y:837,t:1526929915244};\\\", \\\"{x:1284,y:836,t:1526929915251};\\\", \\\"{x:1283,y:835,t:1526929915645};\\\", \\\"{x:1282,y:834,t:1526929915669};\\\", \\\"{x:1281,y:833,t:1526929915692};\\\", \\\"{x:1281,y:832,t:1526929915702};\\\", \\\"{x:1281,y:831,t:1526929915732};\\\", \\\"{x:1281,y:830,t:1526929915747};\\\", \\\"{x:1281,y:829,t:1526929915756};\\\", \\\"{x:1281,y:828,t:1526929915788};\\\", \\\"{x:1281,y:826,t:1526929915802};\\\", \\\"{x:1280,y:825,t:1526929915821};\\\", \\\"{x:1280,y:824,t:1526929915861};\\\", \\\"{x:1280,y:823,t:1526929915915};\\\", \\\"{x:1280,y:822,t:1526929915947};\\\", \\\"{x:1280,y:821,t:1526929915971};\\\", \\\"{x:1280,y:820,t:1526929915986};\\\", \\\"{x:1280,y:819,t:1526929916002};\\\", \\\"{x:1279,y:818,t:1526929916019};\\\", \\\"{x:1279,y:817,t:1526929916036};\\\", \\\"{x:1279,y:816,t:1526929916067};\\\", \\\"{x:1279,y:814,t:1526929916075};\\\", \\\"{x:1278,y:812,t:1526929916092};\\\", \\\"{x:1278,y:811,t:1526929916107};\\\", \\\"{x:1278,y:810,t:1526929916119};\\\", \\\"{x:1278,y:808,t:1526929916137};\\\", \\\"{x:1278,y:807,t:1526929916153};\\\", \\\"{x:1278,y:806,t:1526929916169};\\\", \\\"{x:1278,y:805,t:1526929916187};\\\", \\\"{x:1278,y:804,t:1526929916212};\\\", \\\"{x:1278,y:803,t:1526929916316};\\\", \\\"{x:1278,y:802,t:1526929916331};\\\", \\\"{x:1277,y:803,t:1526929917412};\\\", \\\"{x:1277,y:805,t:1526929917421};\\\", \\\"{x:1277,y:811,t:1526929917437};\\\", \\\"{x:1278,y:817,t:1526929917454};\\\", \\\"{x:1279,y:821,t:1526929917470};\\\", \\\"{x:1280,y:823,t:1526929917487};\\\", \\\"{x:1280,y:825,t:1526929917504};\\\", \\\"{x:1280,y:826,t:1526929917572};\\\", \\\"{x:1280,y:827,t:1526929917693};\\\", \\\"{x:1276,y:827,t:1526929917704};\\\", \\\"{x:1263,y:824,t:1526929917722};\\\", \\\"{x:1239,y:818,t:1526929917738};\\\", \\\"{x:1205,y:808,t:1526929917755};\\\", \\\"{x:1160,y:799,t:1526929917770};\\\", \\\"{x:1109,y:792,t:1526929917788};\\\", \\\"{x:1018,y:777,t:1526929917804};\\\", \\\"{x:948,y:768,t:1526929917822};\\\", \\\"{x:878,y:757,t:1526929917838};\\\", \\\"{x:803,y:747,t:1526929917854};\\\", \\\"{x:734,y:738,t:1526929917872};\\\", \\\"{x:671,y:724,t:1526929917887};\\\", \\\"{x:631,y:710,t:1526929917905};\\\", \\\"{x:595,y:697,t:1526929917921};\\\", \\\"{x:577,y:689,t:1526929917937};\\\", \\\"{x:565,y:683,t:1526929917954};\\\", \\\"{x:560,y:680,t:1526929917972};\\\", \\\"{x:557,y:679,t:1526929917988};\\\", \\\"{x:551,y:679,t:1526929918004};\\\", \\\"{x:547,y:679,t:1526929918022};\\\", \\\"{x:542,y:679,t:1526929918038};\\\", \\\"{x:534,y:679,t:1526929918055};\\\", \\\"{x:527,y:677,t:1526929918071};\\\", \\\"{x:516,y:672,t:1526929918088};\\\", \\\"{x:501,y:662,t:1526929918105};\\\", \\\"{x:475,y:643,t:1526929918123};\\\", \\\"{x:433,y:612,t:1526929918137};\\\", \\\"{x:385,y:588,t:1526929918154};\\\", \\\"{x:323,y:563,t:1526929918172};\\\", \\\"{x:298,y:555,t:1526929918189};\\\", \\\"{x:286,y:550,t:1526929918204};\\\", \\\"{x:285,y:548,t:1526929918222};\\\", \\\"{x:284,y:548,t:1526929918239};\\\", \\\"{x:283,y:547,t:1526929918292};\\\", \\\"{x:284,y:545,t:1526929918307};\\\", \\\"{x:288,y:544,t:1526929918322};\\\", \\\"{x:301,y:540,t:1526929918339};\\\", \\\"{x:322,y:536,t:1526929918355};\\\", \\\"{x:354,y:531,t:1526929918372};\\\", \\\"{x:374,y:528,t:1526929918389};\\\", \\\"{x:397,y:525,t:1526929918406};\\\", \\\"{x:412,y:525,t:1526929918422};\\\", \\\"{x:416,y:525,t:1526929918439};\\\", \\\"{x:417,y:524,t:1526929918564};\\\", \\\"{x:416,y:524,t:1526929918572};\\\", \\\"{x:413,y:522,t:1526929918589};\\\", \\\"{x:408,y:520,t:1526929918607};\\\", \\\"{x:402,y:519,t:1526929918622};\\\", \\\"{x:395,y:517,t:1526929918639};\\\", \\\"{x:390,y:516,t:1526929918657};\\\", \\\"{x:386,y:515,t:1526929918673};\\\", \\\"{x:393,y:515,t:1526929919460};\\\", \\\"{x:400,y:519,t:1526929919474};\\\", \\\"{x:415,y:526,t:1526929919491};\\\", \\\"{x:426,y:531,t:1526929919508};\\\", \\\"{x:446,y:540,t:1526929919524};\\\", \\\"{x:461,y:545,t:1526929919540};\\\", \\\"{x:474,y:549,t:1526929919556};\\\", \\\"{x:484,y:550,t:1526929919573};\\\", \\\"{x:494,y:551,t:1526929919590};\\\", \\\"{x:502,y:551,t:1526929919607};\\\", \\\"{x:510,y:551,t:1526929919623};\\\", \\\"{x:514,y:551,t:1526929919640};\\\", \\\"{x:517,y:551,t:1526929919657};\\\", \\\"{x:518,y:551,t:1526929919673};\\\", \\\"{x:519,y:552,t:1526929919690};\\\", \\\"{x:521,y:553,t:1526929919706};\\\", \\\"{x:525,y:556,t:1526929919723};\\\", \\\"{x:527,y:558,t:1526929919741};\\\", \\\"{x:529,y:558,t:1526929919757};\\\", \\\"{x:529,y:559,t:1526929919774};\\\", \\\"{x:530,y:559,t:1526929920093};\\\", \\\"{x:539,y:560,t:1526929920107};\\\", \\\"{x:560,y:562,t:1526929920124};\\\", \\\"{x:590,y:566,t:1526929920141};\\\", \\\"{x:616,y:576,t:1526929920158};\\\", \\\"{x:655,y:580,t:1526929920174};\\\", \\\"{x:708,y:588,t:1526929920190};\\\", \\\"{x:764,y:596,t:1526929920208};\\\", \\\"{x:818,y:604,t:1526929920224};\\\", \\\"{x:879,y:612,t:1526929920239};\\\", \\\"{x:942,y:625,t:1526929920257};\\\", \\\"{x:1001,y:635,t:1526929920274};\\\", \\\"{x:1053,y:650,t:1526929920290};\\\", \\\"{x:1107,y:666,t:1526929920307};\\\", \\\"{x:1134,y:675,t:1526929920324};\\\", \\\"{x:1155,y:683,t:1526929920341};\\\", \\\"{x:1174,y:693,t:1526929920357};\\\", \\\"{x:1200,y:704,t:1526929920375};\\\", \\\"{x:1229,y:716,t:1526929920391};\\\", \\\"{x:1254,y:726,t:1526929920407};\\\", \\\"{x:1281,y:736,t:1526929920424};\\\", \\\"{x:1300,y:743,t:1526929920441};\\\", \\\"{x:1313,y:751,t:1526929920458};\\\", \\\"{x:1330,y:755,t:1526929920475};\\\", \\\"{x:1352,y:761,t:1526929920492};\\\", \\\"{x:1372,y:770,t:1526929920508};\\\", \\\"{x:1389,y:781,t:1526929920524};\\\", \\\"{x:1403,y:790,t:1526929920542};\\\", \\\"{x:1412,y:798,t:1526929920559};\\\", \\\"{x:1417,y:803,t:1526929920575};\\\", \\\"{x:1420,y:809,t:1526929920592};\\\", \\\"{x:1424,y:818,t:1526929920608};\\\", \\\"{x:1427,y:834,t:1526929920626};\\\", \\\"{x:1430,y:855,t:1526929920642};\\\", \\\"{x:1431,y:880,t:1526929920658};\\\", \\\"{x:1431,y:923,t:1526929920676};\\\", \\\"{x:1427,y:951,t:1526929920692};\\\", \\\"{x:1420,y:975,t:1526929920708};\\\", \\\"{x:1409,y:998,t:1526929920726};\\\", \\\"{x:1395,y:1014,t:1526929920743};\\\", \\\"{x:1381,y:1025,t:1526929920758};\\\", \\\"{x:1368,y:1032,t:1526929920775};\\\", \\\"{x:1359,y:1038,t:1526929920792};\\\", \\\"{x:1354,y:1040,t:1526929920809};\\\", \\\"{x:1352,y:1040,t:1526929920825};\\\", \\\"{x:1351,y:1040,t:1526929920842};\\\", \\\"{x:1347,y:1037,t:1526929920860};\\\", \\\"{x:1341,y:1030,t:1526929920875};\\\", \\\"{x:1331,y:1017,t:1526929920892};\\\", \\\"{x:1322,y:1005,t:1526929920909};\\\", \\\"{x:1315,y:996,t:1526929920925};\\\", \\\"{x:1311,y:991,t:1526929920942};\\\", \\\"{x:1307,y:986,t:1526929920960};\\\", \\\"{x:1303,y:980,t:1526929920976};\\\", \\\"{x:1302,y:979,t:1526929920993};\\\", \\\"{x:1302,y:977,t:1526929921108};\\\", \\\"{x:1299,y:973,t:1526929921127};\\\", \\\"{x:1298,y:970,t:1526929921143};\\\", \\\"{x:1296,y:967,t:1526929921160};\\\", \\\"{x:1296,y:966,t:1526929921177};\\\", \\\"{x:1295,y:964,t:1526929921194};\\\", \\\"{x:1295,y:963,t:1526929921341};\\\", \\\"{x:1294,y:963,t:1526929921348};\\\", \\\"{x:1293,y:963,t:1526929921361};\\\", \\\"{x:1289,y:963,t:1526929921377};\\\", \\\"{x:1285,y:964,t:1526929921394};\\\", \\\"{x:1281,y:965,t:1526929921411};\\\", \\\"{x:1279,y:966,t:1526929921428};\\\", \\\"{x:1279,y:965,t:1526929921652};\\\", \\\"{x:1279,y:964,t:1526929921661};\\\", \\\"{x:1280,y:961,t:1526929921678};\\\", \\\"{x:1281,y:958,t:1526929921694};\\\", \\\"{x:1283,y:956,t:1526929921711};\\\", \\\"{x:1283,y:954,t:1526929921844};\\\", \\\"{x:1283,y:952,t:1526929921851};\\\", \\\"{x:1283,y:951,t:1526929921861};\\\", \\\"{x:1283,y:950,t:1526929921878};\\\", \\\"{x:1283,y:947,t:1526929921895};\\\", \\\"{x:1283,y:946,t:1526929921911};\\\", \\\"{x:1283,y:947,t:1526929922180};\\\", \\\"{x:1283,y:949,t:1526929922196};\\\", \\\"{x:1283,y:950,t:1526929922213};\\\", \\\"{x:1283,y:951,t:1526929922340};\\\", \\\"{x:1283,y:952,t:1526929922347};\\\", \\\"{x:1283,y:953,t:1526929922363};\\\", \\\"{x:1283,y:957,t:1526929922379};\\\", \\\"{x:1285,y:959,t:1526929922396};\\\", \\\"{x:1286,y:961,t:1526929922420};\\\", \\\"{x:1286,y:962,t:1526929922444};\\\", \\\"{x:1286,y:964,t:1526929922557};\\\", \\\"{x:1286,y:965,t:1526929922571};\\\", \\\"{x:1286,y:966,t:1526929922580};\\\", \\\"{x:1286,y:968,t:1526929922596};\\\", \\\"{x:1286,y:969,t:1526929922708};\\\", \\\"{x:1286,y:971,t:1526929923133};\\\", \\\"{x:1285,y:973,t:1526929923149};\\\", \\\"{x:1285,y:972,t:1526929923629};\\\", \\\"{x:1285,y:971,t:1526929923644};\\\", \\\"{x:1285,y:970,t:1526929923660};\\\", \\\"{x:1285,y:972,t:1526929924588};\\\", \\\"{x:1285,y:975,t:1526929924602};\\\", \\\"{x:1285,y:977,t:1526929924619};\\\", \\\"{x:1285,y:978,t:1526929924788};\\\", \\\"{x:1285,y:977,t:1526929925301};\\\", \\\"{x:1285,y:976,t:1526929925308};\\\", \\\"{x:1285,y:974,t:1526929925321};\\\", \\\"{x:1285,y:972,t:1526929925338};\\\", \\\"{x:1286,y:971,t:1526929925477};\\\", \\\"{x:1287,y:969,t:1526929925488};\\\", \\\"{x:1288,y:967,t:1526929925506};\\\", \\\"{x:1289,y:964,t:1526929925522};\\\", \\\"{x:1292,y:961,t:1526929925539};\\\", \\\"{x:1292,y:960,t:1526929925555};\\\", \\\"{x:1293,y:960,t:1526929930228};\\\", \\\"{x:1293,y:962,t:1526929930260};\\\", \\\"{x:1293,y:963,t:1526929930268};\\\", \\\"{x:1292,y:965,t:1526929930285};\\\", \\\"{x:1292,y:969,t:1526929930302};\\\", \\\"{x:1292,y:971,t:1526929930318};\\\", \\\"{x:1292,y:975,t:1526929930334};\\\", \\\"{x:1292,y:984,t:1526929930351};\\\", \\\"{x:1292,y:986,t:1526929930369};\\\", \\\"{x:1292,y:989,t:1526929930384};\\\", \\\"{x:1292,y:991,t:1526929930401};\\\", \\\"{x:1292,y:992,t:1526929930418};\\\", \\\"{x:1292,y:994,t:1526929930435};\\\", \\\"{x:1292,y:995,t:1526929930451};\\\", \\\"{x:1293,y:999,t:1526929930468};\\\", \\\"{x:1293,y:1001,t:1526929930485};\\\", \\\"{x:1293,y:1005,t:1526929930502};\\\", \\\"{x:1293,y:1007,t:1526929930518};\\\", \\\"{x:1295,y:1011,t:1526929930535};\\\", \\\"{x:1295,y:1013,t:1526929930552};\\\", \\\"{x:1296,y:1018,t:1526929930569};\\\", \\\"{x:1297,y:1019,t:1526929930585};\\\", \\\"{x:1297,y:1021,t:1526929930603};\\\", \\\"{x:1299,y:1021,t:1526929930915};\\\", \\\"{x:1299,y:1019,t:1526929930931};\\\", \\\"{x:1299,y:1018,t:1526929931084};\\\", \\\"{x:1299,y:1015,t:1526929931092};\\\", \\\"{x:1300,y:1014,t:1526929931104};\\\", \\\"{x:1301,y:1011,t:1526929931120};\\\", \\\"{x:1302,y:1009,t:1526929931140};\\\", \\\"{x:1303,y:1008,t:1526929931236};\\\", \\\"{x:1303,y:1007,t:1526929931268};\\\", \\\"{x:1305,y:1007,t:1526929931276};\\\", \\\"{x:1305,y:1006,t:1526929931287};\\\", \\\"{x:1307,y:1003,t:1526929931303};\\\", \\\"{x:1308,y:997,t:1526929931320};\\\", \\\"{x:1309,y:997,t:1526929931337};\\\", \\\"{x:1310,y:995,t:1526929931354};\\\", \\\"{x:1310,y:994,t:1526929931436};\\\", \\\"{x:1311,y:993,t:1526929931454};\\\", \\\"{x:1313,y:991,t:1526929931471};\\\", \\\"{x:1315,y:986,t:1526929931487};\\\", \\\"{x:1320,y:979,t:1526929931504};\\\", \\\"{x:1321,y:974,t:1526929931521};\\\", \\\"{x:1322,y:968,t:1526929931537};\\\", \\\"{x:1323,y:966,t:1526929931554};\\\", \\\"{x:1323,y:964,t:1526929931571};\\\", \\\"{x:1323,y:963,t:1526929931588};\\\", \\\"{x:1323,y:961,t:1526929931708};\\\", \\\"{x:1323,y:959,t:1526929931723};\\\", \\\"{x:1323,y:958,t:1526929931738};\\\", \\\"{x:1323,y:957,t:1526929931755};\\\", \\\"{x:1322,y:955,t:1526929931771};\\\", \\\"{x:1321,y:955,t:1526929931972};\\\", \\\"{x:1320,y:954,t:1526929931990};\\\", \\\"{x:1320,y:952,t:1526929932173};\\\", \\\"{x:1319,y:952,t:1526929932190};\\\", \\\"{x:1318,y:950,t:1526929932356};\\\", \\\"{x:1317,y:948,t:1526929932374};\\\", \\\"{x:1317,y:947,t:1526929932391};\\\", \\\"{x:1317,y:946,t:1526929932407};\\\", \\\"{x:1317,y:944,t:1526929932581};\\\", \\\"{x:1317,y:943,t:1526929932604};\\\", \\\"{x:1316,y:942,t:1526929932612};\\\", \\\"{x:1317,y:942,t:1526929932724};\\\", \\\"{x:1318,y:942,t:1526929932765};\\\", \\\"{x:1320,y:942,t:1526929932796};\\\", \\\"{x:1321,y:942,t:1526929932821};\\\", \\\"{x:1323,y:942,t:1526929932884};\\\", \\\"{x:1325,y:942,t:1526929932900};\\\", \\\"{x:1326,y:942,t:1526929932908};\\\", \\\"{x:1327,y:942,t:1526929932924};\\\", \\\"{x:1328,y:942,t:1526929933213};\\\", \\\"{x:1331,y:942,t:1526929933668};\\\", \\\"{x:1332,y:944,t:1526929933676};\\\", \\\"{x:1336,y:951,t:1526929933694};\\\", \\\"{x:1341,y:958,t:1526929933711};\\\", \\\"{x:1343,y:967,t:1526929933727};\\\", \\\"{x:1344,y:970,t:1526929933744};\\\", \\\"{x:1345,y:972,t:1526929933760};\\\", \\\"{x:1346,y:972,t:1526929933778};\\\", \\\"{x:1345,y:972,t:1526929933836};\\\", \\\"{x:1343,y:969,t:1526929933843};\\\", \\\"{x:1339,y:965,t:1526929933860};\\\", \\\"{x:1336,y:962,t:1526929933877};\\\", \\\"{x:1333,y:961,t:1526929933894};\\\", \\\"{x:1332,y:960,t:1526929933909};\\\", \\\"{x:1331,y:960,t:1526929933926};\\\", \\\"{x:1329,y:959,t:1526929934003};\\\", \\\"{x:1329,y:957,t:1526929934010};\\\", \\\"{x:1327,y:954,t:1526929934027};\\\", \\\"{x:1321,y:945,t:1526929934043};\\\", \\\"{x:1319,y:940,t:1526929934061};\\\", \\\"{x:1313,y:933,t:1526929934077};\\\", \\\"{x:1307,y:926,t:1526929934093};\\\", \\\"{x:1304,y:922,t:1526929934110};\\\", \\\"{x:1302,y:918,t:1526929934128};\\\", \\\"{x:1299,y:914,t:1526929934143};\\\", \\\"{x:1297,y:907,t:1526929934161};\\\", \\\"{x:1295,y:903,t:1526929934178};\\\", \\\"{x:1294,y:890,t:1526929934194};\\\", \\\"{x:1292,y:879,t:1526929934211};\\\", \\\"{x:1290,y:867,t:1526929934228};\\\", \\\"{x:1288,y:862,t:1526929934244};\\\", \\\"{x:1287,y:860,t:1526929934262};\\\", \\\"{x:1287,y:857,t:1526929934278};\\\", \\\"{x:1287,y:856,t:1526929934296};\\\", \\\"{x:1286,y:856,t:1526929934311};\\\", \\\"{x:1286,y:855,t:1526929934329};\\\", \\\"{x:1285,y:854,t:1526929934348};\\\", \\\"{x:1285,y:853,t:1526929934361};\\\", \\\"{x:1285,y:851,t:1526929934380};\\\", \\\"{x:1285,y:848,t:1526929934395};\\\", \\\"{x:1285,y:843,t:1526929934412};\\\", \\\"{x:1285,y:839,t:1526929934428};\\\", \\\"{x:1285,y:835,t:1526929934446};\\\", \\\"{x:1285,y:832,t:1526929934463};\\\", \\\"{x:1285,y:829,t:1526929934478};\\\", \\\"{x:1284,y:828,t:1526929934495};\\\", \\\"{x:1284,y:826,t:1526929934639};\\\", \\\"{x:1284,y:825,t:1526929934646};\\\", \\\"{x:1284,y:823,t:1526929934662};\\\", \\\"{x:1284,y:822,t:1526929934678};\\\", \\\"{x:1284,y:821,t:1526929934696};\\\", \\\"{x:1284,y:820,t:1526929934711};\\\", \\\"{x:1284,y:822,t:1526929934884};\\\", \\\"{x:1284,y:823,t:1526929934924};\\\", \\\"{x:1284,y:825,t:1526929934965};\\\", \\\"{x:1284,y:826,t:1526929934980};\\\", \\\"{x:1284,y:828,t:1526929934996};\\\", \\\"{x:1284,y:829,t:1526929935564};\\\", \\\"{x:1284,y:831,t:1526929935582};\\\", \\\"{x:1284,y:832,t:1526929935598};\\\", \\\"{x:1284,y:834,t:1526929935615};\\\", \\\"{x:1283,y:834,t:1526929938926};\\\", \\\"{x:1281,y:835,t:1526929938942};\\\", \\\"{x:1280,y:836,t:1526929939136};\\\", \\\"{x:1278,y:837,t:1526929939335};\\\", \\\"{x:1278,y:838,t:1526929939344};\\\", \\\"{x:1277,y:839,t:1526929939367};\\\", \\\"{x:1275,y:842,t:1526929939496};\\\", \\\"{x:1274,y:844,t:1526929939511};\\\", \\\"{x:1274,y:845,t:1526929939529};\\\", \\\"{x:1271,y:849,t:1526929939545};\\\", \\\"{x:1271,y:851,t:1526929939567};\\\", \\\"{x:1269,y:853,t:1526929939735};\\\", \\\"{x:1269,y:854,t:1526929939745};\\\", \\\"{x:1268,y:855,t:1526929939763};\\\", \\\"{x:1267,y:856,t:1526929939779};\\\", \\\"{x:1267,y:857,t:1526929939975};\\\", \\\"{x:1267,y:858,t:1526929940151};\\\", \\\"{x:1265,y:859,t:1526929940164};\\\", \\\"{x:1265,y:860,t:1526929940180};\\\", \\\"{x:1264,y:861,t:1526929940196};\\\", \\\"{x:1264,y:862,t:1526929940327};\\\", \\\"{x:1261,y:865,t:1526929940343};\\\", \\\"{x:1261,y:866,t:1526929940359};\\\", \\\"{x:1259,y:869,t:1526929940367};\\\", \\\"{x:1258,y:870,t:1526929940380};\\\", \\\"{x:1256,y:875,t:1526929940397};\\\", \\\"{x:1253,y:880,t:1526929940414};\\\", \\\"{x:1251,y:883,t:1526929940430};\\\", \\\"{x:1250,y:884,t:1526929940447};\\\", \\\"{x:1248,y:886,t:1526929940463};\\\", \\\"{x:1247,y:887,t:1526929940480};\\\", \\\"{x:1245,y:890,t:1526929940497};\\\", \\\"{x:1243,y:894,t:1526929940513};\\\", \\\"{x:1240,y:898,t:1526929940531};\\\", \\\"{x:1237,y:903,t:1526929940547};\\\", \\\"{x:1235,y:909,t:1526929940564};\\\", \\\"{x:1233,y:913,t:1526929940581};\\\", \\\"{x:1233,y:916,t:1526929940597};\\\", \\\"{x:1232,y:920,t:1526929940614};\\\", \\\"{x:1231,y:921,t:1526929940630};\\\", \\\"{x:1231,y:922,t:1526929940654};\\\", \\\"{x:1231,y:923,t:1526929940686};\\\", \\\"{x:1230,y:925,t:1526929940698};\\\", \\\"{x:1229,y:927,t:1526929940715};\\\", \\\"{x:1227,y:930,t:1526929940732};\\\", \\\"{x:1225,y:933,t:1526929940748};\\\", \\\"{x:1223,y:937,t:1526929940765};\\\", \\\"{x:1222,y:940,t:1526929940782};\\\", \\\"{x:1219,y:945,t:1526929940798};\\\", \\\"{x:1219,y:946,t:1526929940831};\\\", \\\"{x:1218,y:947,t:1526929940943};\\\", \\\"{x:1217,y:947,t:1526929940967};\\\", \\\"{x:1216,y:947,t:1526929940982};\\\", \\\"{x:1215,y:948,t:1526929940999};\\\", \\\"{x:1214,y:948,t:1526929941591};\\\", \\\"{x:1213,y:949,t:1526929941601};\\\", \\\"{x:1212,y:951,t:1526929941617};\\\", \\\"{x:1210,y:952,t:1526929941633};\\\", \\\"{x:1209,y:952,t:1526929941687};\\\", \\\"{x:1208,y:952,t:1526929942225};\\\", \\\"{x:1207,y:952,t:1526929942235};\\\", \\\"{x:1205,y:953,t:1526929942253};\\\", \\\"{x:1204,y:954,t:1526929942407};\\\", \\\"{x:1203,y:955,t:1526929942551};\\\", \\\"{x:1202,y:954,t:1526929943943};\\\", \\\"{x:1202,y:953,t:1526929943959};\\\", \\\"{x:1201,y:952,t:1526929944159};\\\", \\\"{x:1201,y:950,t:1526929948671};\\\", \\\"{x:1201,y:945,t:1526929948685};\\\", \\\"{x:1218,y:915,t:1526929948702};\\\", \\\"{x:1230,y:895,t:1526929948720};\\\", \\\"{x:1246,y:868,t:1526929948735};\\\", \\\"{x:1260,y:842,t:1526929948753};\\\", \\\"{x:1273,y:814,t:1526929948770};\\\", \\\"{x:1281,y:795,t:1526929948786};\\\", \\\"{x:1289,y:777,t:1526929948803};\\\", \\\"{x:1296,y:763,t:1526929948820};\\\", \\\"{x:1301,y:751,t:1526929948837};\\\", \\\"{x:1303,y:743,t:1526929948852};\\\", \\\"{x:1305,y:735,t:1526929948870};\\\", \\\"{x:1307,y:723,t:1526929948886};\\\", \\\"{x:1307,y:715,t:1526929948903};\\\", \\\"{x:1309,y:705,t:1526929948919};\\\", \\\"{x:1312,y:689,t:1526929948936};\\\", \\\"{x:1315,y:669,t:1526929948953};\\\", \\\"{x:1320,y:642,t:1526929948970};\\\", \\\"{x:1324,y:620,t:1526929948987};\\\", \\\"{x:1328,y:602,t:1526929949004};\\\", \\\"{x:1331,y:585,t:1526929949019};\\\", \\\"{x:1333,y:574,t:1526929949035};\\\", \\\"{x:1335,y:568,t:1526929949053};\\\", \\\"{x:1335,y:562,t:1526929949069};\\\", \\\"{x:1337,y:560,t:1526929949085};\\\", \\\"{x:1337,y:557,t:1526929949103};\\\", \\\"{x:1337,y:556,t:1526929949141};\\\", \\\"{x:1334,y:558,t:1526929949198};\\\", \\\"{x:1332,y:569,t:1526929949205};\\\", \\\"{x:1328,y:582,t:1526929949220};\\\", \\\"{x:1318,y:619,t:1526929949237};\\\", \\\"{x:1295,y:662,t:1526929949253};\\\", \\\"{x:1275,y:695,t:1526929949270};\\\", \\\"{x:1265,y:707,t:1526929949288};\\\", \\\"{x:1257,y:714,t:1526929949303};\\\", \\\"{x:1254,y:718,t:1526929949320};\\\", \\\"{x:1253,y:721,t:1526929949337};\\\", \\\"{x:1252,y:721,t:1526929949354};\\\", \\\"{x:1251,y:722,t:1526929949370};\\\", \\\"{x:1251,y:725,t:1526929949390};\\\", \\\"{x:1251,y:726,t:1526929949574};\\\", \\\"{x:1254,y:730,t:1526929949588};\\\", \\\"{x:1260,y:739,t:1526929949604};\\\", \\\"{x:1262,y:748,t:1526929949621};\\\", \\\"{x:1266,y:767,t:1526929949637};\\\", \\\"{x:1268,y:774,t:1526929949654};\\\", \\\"{x:1268,y:777,t:1526929949671};\\\", \\\"{x:1269,y:778,t:1526929949687};\\\", \\\"{x:1270,y:781,t:1526929949705};\\\", \\\"{x:1273,y:786,t:1526929949721};\\\", \\\"{x:1273,y:788,t:1526929949738};\\\", \\\"{x:1273,y:789,t:1526929949755};\\\", \\\"{x:1274,y:791,t:1526929949771};\\\", \\\"{x:1277,y:796,t:1526929949788};\\\", \\\"{x:1279,y:807,t:1526929949806};\\\", \\\"{x:1290,y:832,t:1526929949822};\\\", \\\"{x:1295,y:843,t:1526929949838};\\\", \\\"{x:1298,y:851,t:1526929949855};\\\", \\\"{x:1301,y:855,t:1526929949872};\\\", \\\"{x:1301,y:856,t:1526929949894};\\\", \\\"{x:1301,y:855,t:1526929950030};\\\", \\\"{x:1299,y:851,t:1526929950039};\\\", \\\"{x:1295,y:844,t:1526929950056};\\\", \\\"{x:1292,y:839,t:1526929950073};\\\", \\\"{x:1289,y:836,t:1526929950089};\\\", \\\"{x:1287,y:834,t:1526929950106};\\\", \\\"{x:1285,y:831,t:1526929950123};\\\", \\\"{x:1284,y:828,t:1526929950139};\\\", \\\"{x:1283,y:827,t:1526929950157};\\\", \\\"{x:1283,y:826,t:1526929950173};\\\", \\\"{x:1282,y:826,t:1526929950311};\\\", \\\"{x:1280,y:826,t:1526929950415};\\\", \\\"{x:1279,y:827,t:1526929950424};\\\", \\\"{x:1278,y:828,t:1526929950440};\\\", \\\"{x:1278,y:831,t:1526929950456};\\\", \\\"{x:1276,y:835,t:1526929950475};\\\", \\\"{x:1275,y:839,t:1526929950490};\\\", \\\"{x:1272,y:844,t:1526929950508};\\\", \\\"{x:1270,y:847,t:1526929950523};\\\", \\\"{x:1269,y:848,t:1526929950540};\\\", \\\"{x:1269,y:849,t:1526929950630};\\\", \\\"{x:1268,y:849,t:1526929950640};\\\", \\\"{x:1267,y:853,t:1526929950657};\\\", \\\"{x:1267,y:855,t:1526929950674};\\\", \\\"{x:1265,y:860,t:1526929950690};\\\", \\\"{x:1264,y:863,t:1526929950707};\\\", \\\"{x:1263,y:868,t:1526929950724};\\\", \\\"{x:1261,y:874,t:1526929950741};\\\", \\\"{x:1260,y:879,t:1526929950757};\\\", \\\"{x:1257,y:890,t:1526929950774};\\\", \\\"{x:1256,y:894,t:1526929950791};\\\", \\\"{x:1253,y:902,t:1526929950808};\\\", \\\"{x:1251,y:906,t:1526929950823};\\\", \\\"{x:1247,y:914,t:1526929950841};\\\", \\\"{x:1242,y:927,t:1526929950857};\\\", \\\"{x:1241,y:940,t:1526929950874};\\\", \\\"{x:1239,y:949,t:1526929950891};\\\", \\\"{x:1238,y:954,t:1526929950908};\\\", \\\"{x:1237,y:957,t:1526929950924};\\\", \\\"{x:1237,y:960,t:1526929950941};\\\", \\\"{x:1236,y:960,t:1526929951023};\\\", \\\"{x:1235,y:962,t:1526929951030};\\\", \\\"{x:1235,y:963,t:1526929951041};\\\", \\\"{x:1234,y:967,t:1526929951058};\\\", \\\"{x:1231,y:972,t:1526929951075};\\\", \\\"{x:1230,y:976,t:1526929951091};\\\", \\\"{x:1228,y:981,t:1526929951108};\\\", \\\"{x:1227,y:983,t:1526929951126};\\\", \\\"{x:1225,y:985,t:1526929951143};\\\", \\\"{x:1224,y:985,t:1526929951678};\\\", \\\"{x:1223,y:985,t:1526929951694};\\\", \\\"{x:1219,y:986,t:1526929951710};\\\", \\\"{x:1215,y:989,t:1526929951728};\\\", \\\"{x:1212,y:990,t:1526929951743};\\\", \\\"{x:1211,y:990,t:1526929951761};\\\", \\\"{x:1210,y:990,t:1526929951783};\\\", \\\"{x:1210,y:988,t:1526929951943};\\\", \\\"{x:1210,y:986,t:1526929951951};\\\", \\\"{x:1210,y:984,t:1526929951961};\\\", \\\"{x:1212,y:977,t:1526929951977};\\\", \\\"{x:1216,y:963,t:1526929951995};\\\", \\\"{x:1222,y:950,t:1526929952012};\\\", \\\"{x:1228,y:938,t:1526929952028};\\\", \\\"{x:1234,y:928,t:1526929952045};\\\", \\\"{x:1238,y:924,t:1526929952062};\\\", \\\"{x:1241,y:920,t:1526929952078};\\\", \\\"{x:1242,y:915,t:1526929952094};\\\", \\\"{x:1243,y:914,t:1526929952111};\\\", \\\"{x:1244,y:910,t:1526929952128};\\\", \\\"{x:1245,y:902,t:1526929952145};\\\", \\\"{x:1247,y:894,t:1526929952162};\\\", \\\"{x:1249,y:885,t:1526929952179};\\\", \\\"{x:1252,y:875,t:1526929952195};\\\", \\\"{x:1254,y:867,t:1526929952211};\\\", \\\"{x:1257,y:861,t:1526929952229};\\\", \\\"{x:1261,y:849,t:1526929952246};\\\", \\\"{x:1264,y:837,t:1526929952262};\\\", \\\"{x:1274,y:816,t:1526929952279};\\\", \\\"{x:1279,y:807,t:1526929952296};\\\", \\\"{x:1283,y:800,t:1526929952311};\\\", \\\"{x:1285,y:795,t:1526929952328};\\\", \\\"{x:1286,y:795,t:1526929952463};\\\", \\\"{x:1287,y:796,t:1526929952511};\\\", \\\"{x:1288,y:799,t:1526929952518};\\\", \\\"{x:1289,y:803,t:1526929952530};\\\", \\\"{x:1291,y:814,t:1526929952546};\\\", \\\"{x:1293,y:824,t:1526929952563};\\\", \\\"{x:1297,y:838,t:1526929952580};\\\", \\\"{x:1301,y:849,t:1526929952596};\\\", \\\"{x:1304,y:858,t:1526929952612};\\\", \\\"{x:1305,y:863,t:1526929952629};\\\", \\\"{x:1308,y:874,t:1526929952645};\\\", \\\"{x:1310,y:882,t:1526929952662};\\\", \\\"{x:1312,y:889,t:1526929952679};\\\", \\\"{x:1316,y:901,t:1526929952696};\\\", \\\"{x:1318,y:909,t:1526929952712};\\\", \\\"{x:1323,y:917,t:1526929952729};\\\", \\\"{x:1323,y:920,t:1526929952746};\\\", \\\"{x:1326,y:924,t:1526929952763};\\\", \\\"{x:1326,y:925,t:1526929952779};\\\", \\\"{x:1326,y:927,t:1526929952797};\\\", \\\"{x:1328,y:929,t:1526929952814};\\\", \\\"{x:1329,y:931,t:1526929952830};\\\", \\\"{x:1329,y:933,t:1526929952854};\\\", \\\"{x:1330,y:934,t:1526929952864};\\\", \\\"{x:1332,y:938,t:1526929952880};\\\", \\\"{x:1336,y:945,t:1526929952896};\\\", \\\"{x:1341,y:952,t:1526929952913};\\\", \\\"{x:1345,y:959,t:1526929952930};\\\", \\\"{x:1348,y:964,t:1526929952947};\\\", \\\"{x:1350,y:967,t:1526929952964};\\\", \\\"{x:1353,y:969,t:1526929952981};\\\", \\\"{x:1353,y:970,t:1526929952998};\\\", \\\"{x:1351,y:970,t:1526929953455};\\\", \\\"{x:1351,y:969,t:1526929953464};\\\", \\\"{x:1348,y:966,t:1526929953482};\\\", \\\"{x:1346,y:964,t:1526929953499};\\\", \\\"{x:1345,y:964,t:1526929953559};\\\", \\\"{x:1345,y:963,t:1526929953687};\\\", \\\"{x:1345,y:962,t:1526929953760};\\\", \\\"{x:1344,y:961,t:1526929953774};\\\", \\\"{x:1343,y:960,t:1526929953790};\\\", \\\"{x:1342,y:960,t:1526929953815};\\\", \\\"{x:1341,y:959,t:1526929953833};\\\", \\\"{x:1339,y:958,t:1526929953850};\\\", \\\"{x:1337,y:954,t:1526929953866};\\\", \\\"{x:1336,y:954,t:1526929953883};\\\", \\\"{x:1335,y:952,t:1526929953900};\\\", \\\"{x:1333,y:950,t:1526929953917};\\\", \\\"{x:1332,y:950,t:1526929953933};\\\", \\\"{x:1330,y:950,t:1526929953950};\\\", \\\"{x:1325,y:950,t:1526929953967};\\\", \\\"{x:1320,y:950,t:1526929953983};\\\", \\\"{x:1315,y:951,t:1526929954000};\\\", \\\"{x:1308,y:952,t:1526929954017};\\\", \\\"{x:1300,y:955,t:1526929954034};\\\", \\\"{x:1292,y:959,t:1526929954050};\\\", \\\"{x:1273,y:966,t:1526929954066};\\\", \\\"{x:1223,y:988,t:1526929954083};\\\", \\\"{x:1178,y:1003,t:1526929954099};\\\", \\\"{x:1136,y:1016,t:1526929954116};\\\", \\\"{x:1084,y:1030,t:1526929954134};\\\", \\\"{x:1065,y:1038,t:1526929954149};\\\", \\\"{x:1055,y:1043,t:1526929954167};\\\", \\\"{x:1050,y:1046,t:1526929954183};\\\", \\\"{x:1049,y:1047,t:1526929954200};\\\", \\\"{x:1048,y:1047,t:1526929954262};\\\", \\\"{x:1048,y:1045,t:1526929954270};\\\", \\\"{x:1048,y:1037,t:1526929954284};\\\", \\\"{x:1055,y:1019,t:1526929954301};\\\", \\\"{x:1062,y:996,t:1526929954318};\\\", \\\"{x:1068,y:975,t:1526929954333};\\\", \\\"{x:1078,y:953,t:1526929954351};\\\", \\\"{x:1080,y:948,t:1526929954368};\\\", \\\"{x:1081,y:948,t:1526929954384};\\\", \\\"{x:1082,y:947,t:1526929954463};\\\", \\\"{x:1083,y:947,t:1526929954472};\\\", \\\"{x:1084,y:947,t:1526929954485};\\\", \\\"{x:1088,y:948,t:1526929954501};\\\", \\\"{x:1091,y:951,t:1526929954518};\\\", \\\"{x:1093,y:954,t:1526929954535};\\\", \\\"{x:1094,y:958,t:1526929954552};\\\", \\\"{x:1094,y:960,t:1526929954568};\\\", \\\"{x:1095,y:962,t:1526929954585};\\\", \\\"{x:1096,y:960,t:1526929954711};\\\", \\\"{x:1096,y:959,t:1526929954731};\\\", \\\"{x:1096,y:956,t:1526929955302};\\\", \\\"{x:1097,y:956,t:1526929955350};\\\", \\\"{x:1097,y:955,t:1526929955750};\\\", \\\"{x:1097,y:953,t:1526929956743};\\\", \\\"{x:1082,y:934,t:1526929956757};\\\", \\\"{x:1011,y:879,t:1526929956774};\\\", \\\"{x:853,y:771,t:1526929956791};\\\", \\\"{x:746,y:706,t:1526929956807};\\\", \\\"{x:646,y:659,t:1526929956824};\\\", \\\"{x:602,y:639,t:1526929956842};\\\", \\\"{x:572,y:629,t:1526929956857};\\\", \\\"{x:560,y:625,t:1526929956873};\\\", \\\"{x:555,y:623,t:1526929956890};\\\", \\\"{x:555,y:622,t:1526929956909};\\\", \\\"{x:555,y:621,t:1526929956923};\\\", \\\"{x:554,y:616,t:1526929956940};\\\", \\\"{x:548,y:609,t:1526929956958};\\\", \\\"{x:543,y:602,t:1526929956973};\\\", \\\"{x:539,y:595,t:1526929956990};\\\", \\\"{x:533,y:586,t:1526929957007};\\\", \\\"{x:523,y:572,t:1526929957024};\\\", \\\"{x:512,y:558,t:1526929957040};\\\", \\\"{x:499,y:544,t:1526929957058};\\\", \\\"{x:485,y:532,t:1526929957075};\\\", \\\"{x:475,y:526,t:1526929957091};\\\", \\\"{x:467,y:518,t:1526929957107};\\\", \\\"{x:462,y:515,t:1526929957124};\\\", \\\"{x:457,y:512,t:1526929957141};\\\", \\\"{x:453,y:509,t:1526929957158};\\\", \\\"{x:451,y:508,t:1526929957173};\\\", \\\"{x:448,y:508,t:1526929957191};\\\", \\\"{x:443,y:508,t:1526929957208};\\\", \\\"{x:437,y:509,t:1526929957225};\\\", \\\"{x:430,y:513,t:1526929957241};\\\", \\\"{x:425,y:515,t:1526929957258};\\\", \\\"{x:424,y:516,t:1526929957274};\\\", \\\"{x:423,y:517,t:1526929957294};\\\", \\\"{x:420,y:517,t:1526929957310};\\\", \\\"{x:418,y:517,t:1526929957325};\\\", \\\"{x:411,y:517,t:1526929957342};\\\", \\\"{x:402,y:513,t:1526929957358};\\\", \\\"{x:400,y:511,t:1526929957374};\\\", \\\"{x:399,y:511,t:1526929957390};\\\", \\\"{x:397,y:511,t:1526929957461};\\\", \\\"{x:395,y:511,t:1526929957475};\\\", \\\"{x:394,y:511,t:1526929957493};\\\", \\\"{x:393,y:511,t:1526929957508};\\\", \\\"{x:392,y:511,t:1526929957574};\\\", \\\"{x:392,y:512,t:1526929957598};\\\", \\\"{x:391,y:512,t:1526929957622};\\\", \\\"{x:390,y:512,t:1526929957629};\\\", \\\"{x:389,y:512,t:1526929957641};\\\", \\\"{x:389,y:513,t:1526929957658};\\\", \\\"{x:388,y:513,t:1526929957674};\\\", \\\"{x:388,y:514,t:1526929957692};\\\", \\\"{x:387,y:514,t:1526929957707};\\\", \\\"{x:389,y:517,t:1526929958119};\\\", \\\"{x:398,y:524,t:1526929958127};\\\", \\\"{x:420,y:537,t:1526929958143};\\\", \\\"{x:452,y:548,t:1526929958159};\\\", \\\"{x:499,y:562,t:1526929958175};\\\", \\\"{x:578,y:576,t:1526929958192};\\\", \\\"{x:676,y:596,t:1526929958209};\\\", \\\"{x:780,y:630,t:1526929958224};\\\", \\\"{x:880,y:660,t:1526929958242};\\\", \\\"{x:995,y:706,t:1526929958258};\\\", \\\"{x:1105,y:757,t:1526929958276};\\\", \\\"{x:1214,y:811,t:1526929958291};\\\", \\\"{x:1315,y:869,t:1526929958308};\\\", \\\"{x:1436,y:943,t:1526929958325};\\\", \\\"{x:1514,y:995,t:1526929958341};\\\", \\\"{x:1573,y:1027,t:1526929958358};\\\", \\\"{x:1622,y:1054,t:1526929958376};\\\", \\\"{x:1650,y:1066,t:1526929958392};\\\", \\\"{x:1662,y:1072,t:1526929958408};\\\", \\\"{x:1664,y:1073,t:1526929958425};\\\", \\\"{x:1664,y:1074,t:1526929958462};\\\", \\\"{x:1664,y:1073,t:1526929958535};\\\", \\\"{x:1658,y:1071,t:1526929958542};\\\", \\\"{x:1616,y:1064,t:1526929958559};\\\", \\\"{x:1545,y:1047,t:1526929958577};\\\", \\\"{x:1489,y:1022,t:1526929958593};\\\", \\\"{x:1427,y:1002,t:1526929958610};\\\", \\\"{x:1368,y:982,t:1526929958626};\\\", \\\"{x:1308,y:970,t:1526929958644};\\\", \\\"{x:1272,y:962,t:1526929958660};\\\", \\\"{x:1257,y:959,t:1526929958676};\\\", \\\"{x:1256,y:959,t:1526929958693};\\\", \\\"{x:1258,y:960,t:1526929958895};\\\", \\\"{x:1262,y:960,t:1526929958910};\\\", \\\"{x:1266,y:963,t:1526929958927};\\\", \\\"{x:1268,y:964,t:1526929958945};\\\", \\\"{x:1272,y:966,t:1526929958961};\\\", \\\"{x:1274,y:966,t:1526929958977};\\\", \\\"{x:1277,y:966,t:1526929959207};\\\", \\\"{x:1278,y:966,t:1526929959214};\\\", \\\"{x:1280,y:965,t:1526929959228};\\\", \\\"{x:1283,y:962,t:1526929959244};\\\", \\\"{x:1284,y:961,t:1526929959261};\\\", \\\"{x:1285,y:961,t:1526929961127};\\\", \\\"{x:1285,y:962,t:1526929961135};\\\", \\\"{x:1285,y:963,t:1526929961149};\\\", \\\"{x:1286,y:964,t:1526929961165};\\\", \\\"{x:1286,y:965,t:1526929961182};\\\", \\\"{x:1286,y:966,t:1526929961198};\\\", \\\"{x:1287,y:966,t:1526929961454};\\\", \\\"{x:1288,y:965,t:1526929961466};\\\", \\\"{x:1290,y:959,t:1526929961483};\\\", \\\"{x:1294,y:950,t:1526929961499};\\\", \\\"{x:1297,y:941,t:1526929961516};\\\", \\\"{x:1300,y:934,t:1526929961534};\\\", \\\"{x:1304,y:927,t:1526929961549};\\\", \\\"{x:1307,y:921,t:1526929961566};\\\", \\\"{x:1309,y:918,t:1526929961583};\\\", \\\"{x:1311,y:916,t:1526929961601};\\\", \\\"{x:1313,y:911,t:1526929961616};\\\", \\\"{x:1316,y:906,t:1526929961634};\\\", \\\"{x:1320,y:896,t:1526929961650};\\\", \\\"{x:1325,y:885,t:1526929961666};\\\", \\\"{x:1331,y:871,t:1526929961684};\\\", \\\"{x:1335,y:862,t:1526929961700};\\\", \\\"{x:1339,y:857,t:1526929961717};\\\", \\\"{x:1341,y:853,t:1526929961733};\\\", \\\"{x:1344,y:846,t:1526929961750};\\\", \\\"{x:1347,y:840,t:1526929961767};\\\", \\\"{x:1349,y:835,t:1526929961783};\\\", \\\"{x:1351,y:829,t:1526929961800};\\\", \\\"{x:1354,y:822,t:1526929961817};\\\", \\\"{x:1357,y:816,t:1526929961833};\\\", \\\"{x:1359,y:813,t:1526929961850};\\\", \\\"{x:1361,y:809,t:1526929961867};\\\", \\\"{x:1362,y:806,t:1526929961884};\\\", \\\"{x:1365,y:801,t:1526929961900};\\\", \\\"{x:1365,y:799,t:1526929961918};\\\", \\\"{x:1366,y:793,t:1526929961934};\\\", \\\"{x:1367,y:788,t:1526929961950};\\\", \\\"{x:1369,y:787,t:1526929961968};\\\", \\\"{x:1369,y:786,t:1526929961984};\\\", \\\"{x:1369,y:785,t:1526929962001};\\\", \\\"{x:1369,y:784,t:1526929962017};\\\", \\\"{x:1370,y:783,t:1526929962035};\\\", \\\"{x:1370,y:782,t:1526929962052};\\\", \\\"{x:1371,y:780,t:1526929962067};\\\", \\\"{x:1372,y:776,t:1526929962085};\\\", \\\"{x:1372,y:775,t:1526929962101};\\\", \\\"{x:1373,y:772,t:1526929962118};\\\", \\\"{x:1374,y:770,t:1526929962135};\\\", \\\"{x:1374,y:771,t:1526929962783};\\\", \\\"{x:1374,y:772,t:1526929962799};\\\", \\\"{x:1374,y:774,t:1526929962806};\\\", \\\"{x:1374,y:775,t:1526929962819};\\\", \\\"{x:1374,y:776,t:1526929962836};\\\", \\\"{x:1374,y:778,t:1526929962852};\\\", \\\"{x:1373,y:780,t:1526929962999};\\\", \\\"{x:1373,y:782,t:1526929963006};\\\", \\\"{x:1372,y:782,t:1526929963019};\\\", \\\"{x:1370,y:786,t:1526929963036};\\\", \\\"{x:1367,y:789,t:1526929963053};\\\", \\\"{x:1360,y:797,t:1526929963070};\\\", \\\"{x:1352,y:803,t:1526929963086};\\\", \\\"{x:1337,y:811,t:1526929963102};\\\", \\\"{x:1310,y:818,t:1526929963120};\\\", \\\"{x:1248,y:824,t:1526929963136};\\\", \\\"{x:1151,y:824,t:1526929963152};\\\", \\\"{x:1028,y:819,t:1526929963170};\\\", \\\"{x:890,y:800,t:1526929963187};\\\", \\\"{x:768,y:781,t:1526929963203};\\\", \\\"{x:659,y:761,t:1526929963219};\\\", \\\"{x:595,y:744,t:1526929963237};\\\", \\\"{x:567,y:736,t:1526929963253};\\\", \\\"{x:555,y:731,t:1526929963272};\\\", \\\"{x:554,y:730,t:1526929963287};\\\", \\\"{x:553,y:730,t:1526929963334};\\\", \\\"{x:553,y:728,t:1526929963345};\\\", \\\"{x:552,y:723,t:1526929963363};\\\", \\\"{x:548,y:713,t:1526929963379};\\\", \\\"{x:544,y:703,t:1526929963396};\\\", \\\"{x:543,y:694,t:1526929963413};\\\", \\\"{x:543,y:678,t:1526929963429};\\\", \\\"{x:539,y:665,t:1526929963445};\\\", \\\"{x:533,y:655,t:1526929963462};\\\", \\\"{x:522,y:641,t:1526929963479};\\\", \\\"{x:514,y:628,t:1526929963496};\\\", \\\"{x:507,y:619,t:1526929963514};\\\", \\\"{x:498,y:610,t:1526929963529};\\\", \\\"{x:484,y:597,t:1526929963546};\\\", \\\"{x:473,y:588,t:1526929963563};\\\", \\\"{x:465,y:582,t:1526929963579};\\\", \\\"{x:458,y:579,t:1526929963596};\\\", \\\"{x:452,y:578,t:1526929963613};\\\", \\\"{x:448,y:578,t:1526929963629};\\\", \\\"{x:439,y:578,t:1526929963646};\\\", \\\"{x:426,y:578,t:1526929963663};\\\", \\\"{x:412,y:578,t:1526929963680};\\\", \\\"{x:384,y:572,t:1526929963697};\\\", \\\"{x:364,y:567,t:1526929963712};\\\", \\\"{x:353,y:563,t:1526929963730};\\\", \\\"{x:342,y:559,t:1526929963745};\\\", \\\"{x:339,y:558,t:1526929963762};\\\", \\\"{x:339,y:557,t:1526929963779};\\\", \\\"{x:343,y:559,t:1526929963894};\\\", \\\"{x:348,y:561,t:1526929963902};\\\", \\\"{x:352,y:561,t:1526929963913};\\\", \\\"{x:356,y:563,t:1526929963930};\\\", \\\"{x:360,y:564,t:1526929963946};\\\", \\\"{x:365,y:564,t:1526929963963};\\\", \\\"{x:369,y:564,t:1526929963980};\\\", \\\"{x:373,y:564,t:1526929963997};\\\", \\\"{x:374,y:564,t:1526929964013};\\\", \\\"{x:376,y:564,t:1526929964030};\\\", \\\"{x:377,y:564,t:1526929964054};\\\", \\\"{x:379,y:565,t:1526929964063};\\\", \\\"{x:380,y:566,t:1526929964085};\\\", \\\"{x:383,y:566,t:1526929964703};\\\", \\\"{x:394,y:566,t:1526929964713};\\\", \\\"{x:424,y:574,t:1526929964731};\\\", \\\"{x:465,y:584,t:1526929964746};\\\", \\\"{x:507,y:595,t:1526929964764};\\\", \\\"{x:550,y:604,t:1526929964781};\\\", \\\"{x:574,y:609,t:1526929964796};\\\", \\\"{x:596,y:615,t:1526929964814};\\\", \\\"{x:599,y:617,t:1526929964831};\\\", \\\"{x:600,y:617,t:1526929964847};\\\", \\\"{x:602,y:619,t:1526929964864};\\\", \\\"{x:604,y:621,t:1526929964881};\\\", \\\"{x:610,y:624,t:1526929964898};\\\", \\\"{x:617,y:630,t:1526929964914};\\\", \\\"{x:633,y:640,t:1526929964931};\\\", \\\"{x:657,y:648,t:1526929964947};\\\", \\\"{x:690,y:658,t:1526929964964};\\\", \\\"{x:741,y:674,t:1526929964981};\\\", \\\"{x:792,y:683,t:1526929964997};\\\", \\\"{x:847,y:696,t:1526929965014};\\\", \\\"{x:879,y:707,t:1526929965031};\\\", \\\"{x:908,y:715,t:1526929965047};\\\", \\\"{x:927,y:724,t:1526929965064};\\\", \\\"{x:934,y:729,t:1526929965080};\\\", \\\"{x:944,y:734,t:1526929965097};\\\", \\\"{x:950,y:738,t:1526929965113};\\\", \\\"{x:956,y:740,t:1526929965130};\\\", \\\"{x:962,y:742,t:1526929965147};\\\", \\\"{x:973,y:744,t:1526929965164};\\\", \\\"{x:984,y:747,t:1526929965180};\\\", \\\"{x:1000,y:751,t:1526929965197};\\\", \\\"{x:1030,y:754,t:1526929965213};\\\", \\\"{x:1055,y:760,t:1526929965230};\\\", \\\"{x:1076,y:769,t:1526929965247};\\\", \\\"{x:1103,y:776,t:1526929965264};\\\", \\\"{x:1128,y:785,t:1526929965280};\\\", \\\"{x:1155,y:795,t:1526929965297};\\\", \\\"{x:1181,y:803,t:1526929965314};\\\", \\\"{x:1199,y:809,t:1526929965330};\\\", \\\"{x:1211,y:811,t:1526929965347};\\\", \\\"{x:1216,y:814,t:1526929965364};\\\", \\\"{x:1222,y:815,t:1526929965380};\\\", \\\"{x:1227,y:817,t:1526929965397};\\\", \\\"{x:1234,y:818,t:1526929965414};\\\", \\\"{x:1239,y:818,t:1526929965430};\\\", \\\"{x:1240,y:818,t:1526929965447};\\\", \\\"{x:1242,y:818,t:1526929965464};\\\", \\\"{x:1249,y:818,t:1526929965480};\\\", \\\"{x:1257,y:818,t:1526929965497};\\\", \\\"{x:1269,y:812,t:1526929965514};\\\", \\\"{x:1288,y:805,t:1526929965530};\\\", \\\"{x:1304,y:797,t:1526929965547};\\\", \\\"{x:1317,y:788,t:1526929965564};\\\", \\\"{x:1327,y:780,t:1526929965581};\\\", \\\"{x:1337,y:772,t:1526929965598};\\\", \\\"{x:1348,y:762,t:1526929965614};\\\", \\\"{x:1362,y:751,t:1526929965630};\\\", \\\"{x:1366,y:747,t:1526929965647};\\\", \\\"{x:1370,y:745,t:1526929965664};\\\", \\\"{x:1370,y:744,t:1526929965680};\\\", \\\"{x:1372,y:743,t:1526929965698};\\\", \\\"{x:1373,y:743,t:1526929965751};\\\", \\\"{x:1374,y:743,t:1526929965853};\\\", \\\"{x:1377,y:744,t:1526929965862};\\\", \\\"{x:1387,y:752,t:1526929965880};\\\", \\\"{x:1394,y:757,t:1526929965897};\\\", \\\"{x:1400,y:759,t:1526929965913};\\\", \\\"{x:1403,y:762,t:1526929965929};\\\", \\\"{x:1407,y:763,t:1526929965947};\\\", \\\"{x:1409,y:764,t:1526929965964};\\\", \\\"{x:1409,y:765,t:1526929965980};\\\", \\\"{x:1410,y:766,t:1526929966158};\\\", \\\"{x:1410,y:768,t:1526929966270};\\\", \\\"{x:1410,y:770,t:1526929966281};\\\", \\\"{x:1407,y:780,t:1526929966296};\\\", \\\"{x:1401,y:798,t:1526929966313};\\\", \\\"{x:1396,y:819,t:1526929966330};\\\", \\\"{x:1384,y:843,t:1526929966347};\\\", \\\"{x:1374,y:863,t:1526929966363};\\\", \\\"{x:1360,y:886,t:1526929966380};\\\", \\\"{x:1345,y:911,t:1526929966397};\\\", \\\"{x:1332,y:930,t:1526929966414};\\\", \\\"{x:1316,y:952,t:1526929966430};\\\", \\\"{x:1311,y:960,t:1526929966446};\\\", \\\"{x:1306,y:972,t:1526929966463};\\\", \\\"{x:1299,y:980,t:1526929966480};\\\", \\\"{x:1293,y:988,t:1526929966497};\\\", \\\"{x:1288,y:995,t:1526929966513};\\\", \\\"{x:1284,y:1000,t:1526929966530};\\\", \\\"{x:1279,y:1007,t:1526929966546};\\\", \\\"{x:1276,y:1010,t:1526929966563};\\\", \\\"{x:1274,y:1013,t:1526929966580};\\\", \\\"{x:1273,y:1013,t:1526929966879};\\\", \\\"{x:1273,y:1011,t:1526929966897};\\\", \\\"{x:1272,y:1010,t:1526929966913};\\\", \\\"{x:1271,y:1009,t:1526929966930};\\\", \\\"{x:1270,y:1007,t:1526929966946};\\\", \\\"{x:1268,y:1005,t:1526929966963};\\\", \\\"{x:1267,y:1002,t:1526929966979};\\\", \\\"{x:1263,y:995,t:1526929966996};\\\", \\\"{x:1261,y:987,t:1526929967014};\\\", \\\"{x:1258,y:979,t:1526929967029};\\\", \\\"{x:1255,y:970,t:1526929967046};\\\", \\\"{x:1254,y:966,t:1526929967064};\\\", \\\"{x:1254,y:964,t:1526929967080};\\\", \\\"{x:1254,y:967,t:1526929967182};\\\", \\\"{x:1255,y:969,t:1526929967196};\\\", \\\"{x:1258,y:973,t:1526929967213};\\\", \\\"{x:1260,y:976,t:1526929967230};\\\", \\\"{x:1265,y:979,t:1526929967246};\\\", \\\"{x:1267,y:981,t:1526929967263};\\\", \\\"{x:1269,y:981,t:1526929967438};\\\", \\\"{x:1272,y:981,t:1526929967447};\\\", \\\"{x:1279,y:976,t:1526929967462};\\\", \\\"{x:1290,y:964,t:1526929967480};\\\", \\\"{x:1300,y:946,t:1526929967496};\\\", \\\"{x:1308,y:931,t:1526929967512};\\\", \\\"{x:1313,y:922,t:1526929967529};\\\", \\\"{x:1320,y:911,t:1526929967547};\\\", \\\"{x:1325,y:903,t:1526929967563};\\\", \\\"{x:1329,y:891,t:1526929967579};\\\", \\\"{x:1334,y:876,t:1526929967597};\\\", \\\"{x:1339,y:859,t:1526929967612};\\\", \\\"{x:1343,y:841,t:1526929967629};\\\", \\\"{x:1347,y:816,t:1526929967645};\\\", \\\"{x:1351,y:802,t:1526929967661};\\\", \\\"{x:1355,y:787,t:1526929967678};\\\", \\\"{x:1357,y:778,t:1526929967696};\\\", \\\"{x:1357,y:773,t:1526929967712};\\\", \\\"{x:1357,y:768,t:1526929967729};\\\", \\\"{x:1358,y:767,t:1526929967746};\\\", \\\"{x:1358,y:766,t:1526929968199};\\\", \\\"{x:1358,y:765,t:1526929968213};\\\", \\\"{x:1359,y:765,t:1526929968230};\\\", \\\"{x:1359,y:766,t:1526929968245};\\\", \\\"{x:1361,y:767,t:1526929968262};\\\", \\\"{x:1361,y:768,t:1526929968279};\\\", \\\"{x:1362,y:769,t:1526929968295};\\\", \\\"{x:1363,y:769,t:1526929968317};\\\", \\\"{x:1363,y:770,t:1526929968382};\\\", \\\"{x:1363,y:772,t:1526929968395};\\\", \\\"{x:1362,y:778,t:1526929968412};\\\", \\\"{x:1360,y:784,t:1526929968428};\\\", \\\"{x:1357,y:802,t:1526929968446};\\\", \\\"{x:1355,y:819,t:1526929968462};\\\", \\\"{x:1350,y:834,t:1526929968478};\\\", \\\"{x:1346,y:849,t:1526929968495};\\\", \\\"{x:1341,y:862,t:1526929968512};\\\", \\\"{x:1334,y:878,t:1526929968528};\\\", \\\"{x:1328,y:891,t:1526929968545};\\\", \\\"{x:1318,y:909,t:1526929968562};\\\", \\\"{x:1311,y:926,t:1526929968578};\\\", \\\"{x:1304,y:940,t:1526929968596};\\\", \\\"{x:1297,y:955,t:1526929968612};\\\", \\\"{x:1292,y:967,t:1526929968628};\\\", \\\"{x:1288,y:975,t:1526929968645};\\\", \\\"{x:1287,y:982,t:1526929968662};\\\", \\\"{x:1287,y:985,t:1526929968679};\\\", \\\"{x:1287,y:986,t:1526929968696};\\\", \\\"{x:1287,y:984,t:1526929968934};\\\", \\\"{x:1287,y:979,t:1526929968945};\\\", \\\"{x:1287,y:973,t:1526929968961};\\\", \\\"{x:1287,y:968,t:1526929968978};\\\", \\\"{x:1287,y:965,t:1526929968996};\\\", \\\"{x:1287,y:963,t:1526929969012};\\\", \\\"{x:1287,y:959,t:1526929969029};\\\", \\\"{x:1287,y:958,t:1526929969046};\\\", \\\"{x:1287,y:957,t:1526929969447};\\\", \\\"{x:1286,y:957,t:1526929969919};\\\", \\\"{x:1285,y:958,t:1526929970087};\\\", \\\"{x:1285,y:959,t:1526929970094};\\\", \\\"{x:1284,y:960,t:1526929970112};\\\", \\\"{x:1284,y:962,t:1526929970128};\\\", \\\"{x:1284,y:963,t:1526929970166};\\\", \\\"{x:1284,y:959,t:1526929973943};\\\", \\\"{x:1284,y:956,t:1526929973959};\\\", \\\"{x:1285,y:952,t:1526929973976};\\\", \\\"{x:1286,y:949,t:1526929973993};\\\", \\\"{x:1286,y:946,t:1526929974009};\\\", \\\"{x:1288,y:942,t:1526929974025};\\\", \\\"{x:1289,y:939,t:1526929974043};\\\", \\\"{x:1290,y:936,t:1526929974058};\\\", \\\"{x:1293,y:933,t:1526929974075};\\\", \\\"{x:1293,y:932,t:1526929974093};\\\", \\\"{x:1294,y:928,t:1526929974109};\\\", \\\"{x:1296,y:924,t:1526929974126};\\\", \\\"{x:1297,y:922,t:1526929974142};\\\", \\\"{x:1298,y:921,t:1526929974166};\\\", \\\"{x:1298,y:920,t:1526929974182};\\\", \\\"{x:1298,y:918,t:1526929974206};\\\", \\\"{x:1299,y:918,t:1526929974215};\\\", \\\"{x:1299,y:917,t:1526929974225};\\\", \\\"{x:1300,y:916,t:1526929974245};\\\", \\\"{x:1301,y:916,t:1526929974261};\\\", \\\"{x:1301,y:915,t:1526929974293};\\\", \\\"{x:1303,y:914,t:1526929974308};\\\", \\\"{x:1305,y:910,t:1526929974325};\\\", \\\"{x:1306,y:909,t:1526929974341};\\\", \\\"{x:1306,y:907,t:1526929974358};\\\", \\\"{x:1307,y:906,t:1526929974462};\\\", \\\"{x:1308,y:906,t:1526929974476};\\\", \\\"{x:1308,y:905,t:1526929974491};\\\", \\\"{x:1309,y:905,t:1526929974509};\\\", \\\"{x:1313,y:902,t:1526929974526};\\\", \\\"{x:1315,y:899,t:1526929974542};\\\", \\\"{x:1316,y:898,t:1526929974559};\\\", \\\"{x:1317,y:896,t:1526929974576};\\\", \\\"{x:1314,y:899,t:1526929974950};\\\", \\\"{x:1310,y:902,t:1526929974958};\\\", \\\"{x:1301,y:915,t:1526929974975};\\\", \\\"{x:1281,y:933,t:1526929974992};\\\", \\\"{x:1254,y:951,t:1526929975009};\\\", \\\"{x:1222,y:977,t:1526929975025};\\\", \\\"{x:1187,y:998,t:1526929975041};\\\", \\\"{x:1149,y:1020,t:1526929975058};\\\", \\\"{x:1117,y:1036,t:1526929975074};\\\", \\\"{x:1095,y:1045,t:1526929975091};\\\", \\\"{x:1079,y:1048,t:1526929975108};\\\", \\\"{x:1073,y:1049,t:1526929975124};\\\", \\\"{x:1070,y:1049,t:1526929975141};\\\", \\\"{x:1068,y:1046,t:1526929975157};\\\", \\\"{x:1057,y:1036,t:1526929975175};\\\", \\\"{x:1036,y:1021,t:1526929975191};\\\", \\\"{x:994,y:998,t:1526929975209};\\\", \\\"{x:935,y:967,t:1526929975225};\\\", \\\"{x:858,y:937,t:1526929975241};\\\", \\\"{x:776,y:905,t:1526929975258};\\\", \\\"{x:696,y:872,t:1526929975274};\\\", \\\"{x:650,y:854,t:1526929975291};\\\", \\\"{x:628,y:841,t:1526929975307};\\\", \\\"{x:619,y:835,t:1526929975324};\\\", \\\"{x:615,y:830,t:1526929975340};\\\", \\\"{x:613,y:826,t:1526929975357};\\\", \\\"{x:610,y:817,t:1526929975374};\\\", \\\"{x:608,y:811,t:1526929975392};\\\", \\\"{x:606,y:806,t:1526929975407};\\\", \\\"{x:604,y:804,t:1526929975424};\\\", \\\"{x:598,y:800,t:1526929975441};\\\", \\\"{x:587,y:797,t:1526929975457};\\\", \\\"{x:579,y:793,t:1526929975474};\\\", \\\"{x:570,y:787,t:1526929975491};\\\", \\\"{x:557,y:779,t:1526929975507};\\\", \\\"{x:550,y:773,t:1526929975524};\\\", \\\"{x:542,y:765,t:1526929975541};\\\", \\\"{x:538,y:760,t:1526929975558};\\\", \\\"{x:535,y:755,t:1526929975574};\\\", \\\"{x:534,y:751,t:1526929975591};\\\", \\\"{x:533,y:748,t:1526929975608};\\\", \\\"{x:530,y:744,t:1526929975624};\\\", \\\"{x:530,y:742,t:1526929975641};\\\", \\\"{x:529,y:740,t:1526929975657};\\\", \\\"{x:529,y:739,t:1526929975674};\\\", \\\"{x:529,y:738,t:1526929975691};\\\", \\\"{x:529,y:737,t:1526929975710};\\\", \\\"{x:529,y:736,t:1526929975726};\\\", \\\"{x:531,y:733,t:1526929975743};\\\", \\\"{x:534,y:730,t:1526929975757};\\\", \\\"{x:535,y:727,t:1526929975774};\\\", \\\"{x:537,y:723,t:1526929975789};\\\", \\\"{x:538,y:722,t:1526929975806};\\\", \\\"{x:538,y:721,t:1526929975949};\\\", \\\"{x:538,y:720,t:1526929975957};\\\", \\\"{x:538,y:717,t:1526929975972};\\\", \\\"{x:538,y:713,t:1526929975989};\\\", \\\"{x:538,y:709,t:1526929976007};\\\", \\\"{x:538,y:707,t:1526929976023};\\\", \\\"{x:538,y:706,t:1526929976039};\\\", \\\"{x:538,y:705,t:1526929976069};\\\", \\\"{x:537,y:708,t:1526929978150};\\\", \\\"{x:537,y:715,t:1526929978158};\\\", \\\"{x:535,y:725,t:1526929978174};\\\", \\\"{x:535,y:729,t:1526929978192};\\\", \\\"{x:533,y:730,t:1526929978209};\\\", \\\"{x:533,y:731,t:1526929978225};\\\", \\\"{x:533,y:732,t:1526929978327};\\\", \\\"{x:531,y:731,t:1526929978342};\\\", \\\"{x:530,y:731,t:1526929978359};\\\", \\\"{x:528,y:730,t:1526929978375};\\\", \\\"{x:527,y:729,t:1526929978391};\\\", \\\"{x:525,y:728,t:1526929978408};\\\", \\\"{x:523,y:727,t:1526929978429};\\\", \\\"{x:523,y:726,t:1526929978441};\\\", \\\"{x:522,y:725,t:1526929978462};\\\", \\\"{x:521,y:725,t:1526929978478};\\\", \\\"{x:521,y:724,t:1526929978492};\\\", \\\"{x:521,y:723,t:1526929978550};\\\", \\\"{x:521,y:722,t:1526929978646};\\\", \\\"{x:521,y:720,t:1526929978659};\\\", \\\"{x:520,y:718,t:1526929978676};\\\", \\\"{x:518,y:714,t:1526929978691};\\\", \\\"{x:517,y:713,t:1526929978709};\\\", \\\"{x:516,y:712,t:1526929978726};\\\" ] }, { \\\"rt\\\": 19550, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 6, \\\"time_elapsed\\\": 362263, \\\"internal_node_id\\\": \\\"0.0-5.0-1.0\\\", \\\"subject\\\": \\\"WKBNA\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 2, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"K\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-K \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:518,y:709,t:1526929982254};\\\", \\\"{x:536,y:700,t:1526929982263};\\\", \\\"{x:595,y:683,t:1526929982278};\\\", \\\"{x:685,y:666,t:1526929982294};\\\", \\\"{x:803,y:654,t:1526929982310};\\\", \\\"{x:942,y:634,t:1526929982328};\\\", \\\"{x:1086,y:615,t:1526929982344};\\\", \\\"{x:1224,y:615,t:1526929982361};\\\", \\\"{x:1351,y:615,t:1526929982377};\\\", \\\"{x:1448,y:615,t:1526929982395};\\\", \\\"{x:1501,y:615,t:1526929982411};\\\", \\\"{x:1518,y:615,t:1526929982427};\\\", \\\"{x:1521,y:616,t:1526929982444};\\\", \\\"{x:1522,y:616,t:1526929982478};\\\", \\\"{x:1522,y:618,t:1526929982495};\\\", \\\"{x:1520,y:619,t:1526929982511};\\\", \\\"{x:1518,y:620,t:1526929982528};\\\", \\\"{x:1514,y:621,t:1526929982545};\\\", \\\"{x:1511,y:621,t:1526929982561};\\\", \\\"{x:1503,y:621,t:1526929982579};\\\", \\\"{x:1493,y:621,t:1526929982595};\\\", \\\"{x:1480,y:620,t:1526929982611};\\\", \\\"{x:1468,y:615,t:1526929982628};\\\", \\\"{x:1453,y:614,t:1526929982645};\\\", \\\"{x:1438,y:612,t:1526929982661};\\\", \\\"{x:1421,y:612,t:1526929982677};\\\", \\\"{x:1416,y:612,t:1526929982695};\\\", \\\"{x:1413,y:613,t:1526929982711};\\\", \\\"{x:1409,y:613,t:1526929982728};\\\", \\\"{x:1406,y:615,t:1526929982745};\\\", \\\"{x:1401,y:616,t:1526929982760};\\\", \\\"{x:1393,y:620,t:1526929982778};\\\", \\\"{x:1390,y:621,t:1526929982795};\\\", \\\"{x:1389,y:622,t:1526929983133};\\\", \\\"{x:1390,y:624,t:1526929983149};\\\", \\\"{x:1391,y:624,t:1526929984437};\\\", \\\"{x:1392,y:624,t:1526929984461};\\\", \\\"{x:1393,y:624,t:1526929984484};\\\", \\\"{x:1394,y:624,t:1526929984494};\\\", \\\"{x:1396,y:624,t:1526929984511};\\\", \\\"{x:1396,y:623,t:1526929984527};\\\", \\\"{x:1398,y:623,t:1526929984773};\\\", \\\"{x:1406,y:624,t:1526929984780};\\\", \\\"{x:1414,y:625,t:1526929984794};\\\", \\\"{x:1424,y:625,t:1526929984810};\\\", \\\"{x:1430,y:625,t:1526929984827};\\\", \\\"{x:1436,y:623,t:1526929984844};\\\", \\\"{x:1440,y:622,t:1526929984860};\\\", \\\"{x:1442,y:621,t:1526929984877};\\\", \\\"{x:1443,y:621,t:1526929984973};\\\", \\\"{x:1444,y:624,t:1526929984980};\\\", \\\"{x:1444,y:627,t:1526929984993};\\\", \\\"{x:1446,y:634,t:1526929985010};\\\", \\\"{x:1446,y:641,t:1526929985027};\\\", \\\"{x:1447,y:647,t:1526929985044};\\\", \\\"{x:1448,y:654,t:1526929985060};\\\", \\\"{x:1447,y:664,t:1526929985077};\\\", \\\"{x:1442,y:677,t:1526929985095};\\\", \\\"{x:1434,y:691,t:1526929985111};\\\", \\\"{x:1423,y:706,t:1526929985127};\\\", \\\"{x:1409,y:724,t:1526929985143};\\\", \\\"{x:1397,y:735,t:1526929985160};\\\", \\\"{x:1389,y:740,t:1526929985177};\\\", \\\"{x:1385,y:742,t:1526929985194};\\\", \\\"{x:1383,y:742,t:1526929985210};\\\", \\\"{x:1383,y:743,t:1526929985228};\\\", \\\"{x:1382,y:743,t:1526929985260};\\\", \\\"{x:1379,y:742,t:1526929985277};\\\", \\\"{x:1374,y:738,t:1526929985294};\\\", \\\"{x:1369,y:734,t:1526929985310};\\\", \\\"{x:1363,y:728,t:1526929985328};\\\", \\\"{x:1351,y:714,t:1526929985344};\\\", \\\"{x:1343,y:702,t:1526929985361};\\\", \\\"{x:1340,y:693,t:1526929985378};\\\", \\\"{x:1337,y:683,t:1526929985394};\\\", \\\"{x:1335,y:676,t:1526929985411};\\\", \\\"{x:1334,y:668,t:1526929985427};\\\", \\\"{x:1333,y:664,t:1526929985444};\\\", \\\"{x:1332,y:660,t:1526929985461};\\\", \\\"{x:1332,y:657,t:1526929985477};\\\", \\\"{x:1331,y:654,t:1526929985494};\\\", \\\"{x:1331,y:653,t:1526929985510};\\\", \\\"{x:1331,y:652,t:1526929985528};\\\", \\\"{x:1330,y:652,t:1526929985544};\\\", \\\"{x:1330,y:651,t:1526929985590};\\\", \\\"{x:1329,y:651,t:1526929985630};\\\", \\\"{x:1329,y:650,t:1526929985645};\\\", \\\"{x:1329,y:648,t:1526929985660};\\\", \\\"{x:1327,y:644,t:1526929985678};\\\", \\\"{x:1326,y:643,t:1526929986005};\\\", \\\"{x:1324,y:643,t:1526929986013};\\\", \\\"{x:1323,y:641,t:1526929986086};\\\", \\\"{x:1323,y:635,t:1526929986094};\\\", \\\"{x:1331,y:617,t:1526929986110};\\\", \\\"{x:1349,y:596,t:1526929986127};\\\", \\\"{x:1377,y:569,t:1526929986144};\\\", \\\"{x:1415,y:528,t:1526929986161};\\\", \\\"{x:1459,y:481,t:1526929986178};\\\", \\\"{x:1499,y:443,t:1526929986193};\\\", \\\"{x:1532,y:412,t:1526929986210};\\\", \\\"{x:1569,y:389,t:1526929986228};\\\", \\\"{x:1602,y:373,t:1526929986244};\\\", \\\"{x:1633,y:355,t:1526929986260};\\\", \\\"{x:1659,y:338,t:1526929986277};\\\", \\\"{x:1670,y:332,t:1526929986294};\\\", \\\"{x:1675,y:325,t:1526929986310};\\\", \\\"{x:1677,y:322,t:1526929986328};\\\", \\\"{x:1679,y:320,t:1526929986344};\\\", \\\"{x:1679,y:326,t:1526929986421};\\\", \\\"{x:1679,y:333,t:1526929986429};\\\", \\\"{x:1679,y:341,t:1526929986443};\\\", \\\"{x:1676,y:359,t:1526929986460};\\\", \\\"{x:1671,y:377,t:1526929986477};\\\", \\\"{x:1668,y:384,t:1526929986493};\\\", \\\"{x:1664,y:394,t:1526929986510};\\\", \\\"{x:1663,y:400,t:1526929986527};\\\", \\\"{x:1659,y:408,t:1526929986544};\\\", \\\"{x:1658,y:416,t:1526929986561};\\\", \\\"{x:1655,y:426,t:1526929986578};\\\", \\\"{x:1654,y:435,t:1526929986594};\\\", \\\"{x:1654,y:439,t:1526929986611};\\\", \\\"{x:1654,y:443,t:1526929986628};\\\", \\\"{x:1654,y:445,t:1526929986644};\\\", \\\"{x:1654,y:448,t:1526929986660};\\\", \\\"{x:1655,y:451,t:1526929986678};\\\", \\\"{x:1655,y:452,t:1526929986694};\\\", \\\"{x:1653,y:451,t:1526929986830};\\\", \\\"{x:1647,y:447,t:1526929986844};\\\", \\\"{x:1640,y:442,t:1526929986861};\\\", \\\"{x:1632,y:438,t:1526929986878};\\\", \\\"{x:1630,y:436,t:1526929986893};\\\", \\\"{x:1629,y:435,t:1526929986911};\\\", \\\"{x:1628,y:434,t:1526929986928};\\\", \\\"{x:1627,y:434,t:1526929986944};\\\", \\\"{x:1626,y:433,t:1526929986961};\\\", \\\"{x:1625,y:433,t:1526929986978};\\\", \\\"{x:1624,y:433,t:1526929986994};\\\", \\\"{x:1622,y:433,t:1526929987198};\\\", \\\"{x:1622,y:432,t:1526929987342};\\\", \\\"{x:1621,y:431,t:1526929987822};\\\", \\\"{x:1621,y:433,t:1526929988118};\\\", \\\"{x:1621,y:437,t:1526929988128};\\\", \\\"{x:1621,y:440,t:1526929988144};\\\", \\\"{x:1621,y:446,t:1526929988161};\\\", \\\"{x:1621,y:448,t:1526929988177};\\\", \\\"{x:1621,y:450,t:1526929988193};\\\", \\\"{x:1621,y:451,t:1526929988211};\\\", \\\"{x:1622,y:450,t:1526929988326};\\\", \\\"{x:1622,y:446,t:1526929988334};\\\", \\\"{x:1622,y:441,t:1526929988345};\\\", \\\"{x:1622,y:430,t:1526929988361};\\\", \\\"{x:1622,y:424,t:1526929988378};\\\", \\\"{x:1622,y:418,t:1526929988394};\\\", \\\"{x:1622,y:415,t:1526929988411};\\\", \\\"{x:1622,y:414,t:1526929988427};\\\", \\\"{x:1623,y:414,t:1526929988550};\\\", \\\"{x:1624,y:415,t:1526929988566};\\\", \\\"{x:1624,y:417,t:1526929988577};\\\", \\\"{x:1624,y:424,t:1526929988594};\\\", \\\"{x:1624,y:434,t:1526929988611};\\\", \\\"{x:1624,y:451,t:1526929988627};\\\", \\\"{x:1622,y:474,t:1526929988644};\\\", \\\"{x:1610,y:501,t:1526929988661};\\\", \\\"{x:1584,y:540,t:1526929988677};\\\", \\\"{x:1555,y:578,t:1526929988695};\\\", \\\"{x:1501,y:622,t:1526929988712};\\\", \\\"{x:1416,y:667,t:1526929988727};\\\", \\\"{x:1296,y:713,t:1526929988744};\\\", \\\"{x:1168,y:758,t:1526929988762};\\\", \\\"{x:1018,y:800,t:1526929988777};\\\", \\\"{x:891,y:824,t:1526929988794};\\\", \\\"{x:887,y:825,t:1526929988811};\\\", \\\"{x:885,y:825,t:1526929988829};\\\", \\\"{x:884,y:824,t:1526929988845};\\\", \\\"{x:882,y:823,t:1526929988861};\\\", \\\"{x:881,y:822,t:1526929988878};\\\", \\\"{x:881,y:819,t:1526929988910};\\\", \\\"{x:880,y:818,t:1526929988917};\\\", \\\"{x:878,y:818,t:1526929988927};\\\", \\\"{x:857,y:814,t:1526929988944};\\\", \\\"{x:805,y:813,t:1526929988961};\\\", \\\"{x:728,y:804,t:1526929988977};\\\", \\\"{x:645,y:785,t:1526929988994};\\\", \\\"{x:572,y:757,t:1526929989011};\\\", \\\"{x:516,y:732,t:1526929989028};\\\", \\\"{x:483,y:710,t:1526929989043};\\\", \\\"{x:457,y:688,t:1526929989061};\\\", \\\"{x:447,y:668,t:1526929989083};\\\", \\\"{x:445,y:637,t:1526929989101};\\\", \\\"{x:445,y:625,t:1526929989117};\\\", \\\"{x:445,y:611,t:1526929989133};\\\", \\\"{x:445,y:601,t:1526929989150};\\\", \\\"{x:442,y:595,t:1526929989167};\\\", \\\"{x:442,y:589,t:1526929989184};\\\", \\\"{x:450,y:577,t:1526929989201};\\\", \\\"{x:465,y:563,t:1526929989217};\\\", \\\"{x:476,y:557,t:1526929989233};\\\", \\\"{x:479,y:555,t:1526929989250};\\\", \\\"{x:479,y:556,t:1526929989269};\\\", \\\"{x:479,y:557,t:1526929989283};\\\", \\\"{x:470,y:571,t:1526929989300};\\\", \\\"{x:460,y:583,t:1526929989318};\\\", \\\"{x:456,y:587,t:1526929989334};\\\", \\\"{x:455,y:588,t:1526929989350};\\\", \\\"{x:453,y:588,t:1526929989381};\\\", \\\"{x:447,y:589,t:1526929989389};\\\", \\\"{x:439,y:591,t:1526929989401};\\\", \\\"{x:428,y:592,t:1526929989416};\\\", \\\"{x:423,y:592,t:1526929989434};\\\", \\\"{x:416,y:586,t:1526929989451};\\\", \\\"{x:415,y:584,t:1526929989466};\\\", \\\"{x:415,y:581,t:1526929989484};\\\", \\\"{x:415,y:579,t:1526929989501};\\\", \\\"{x:415,y:577,t:1526929989517};\\\", \\\"{x:415,y:575,t:1526929989534};\\\", \\\"{x:415,y:574,t:1526929989551};\\\", \\\"{x:415,y:571,t:1526929989567};\\\", \\\"{x:412,y:570,t:1526929989612};\\\", \\\"{x:409,y:570,t:1526929989621};\\\", \\\"{x:408,y:570,t:1526929989634};\\\", \\\"{x:403,y:571,t:1526929989651};\\\", \\\"{x:402,y:571,t:1526929989667};\\\", \\\"{x:400,y:572,t:1526929989684};\\\", \\\"{x:400,y:574,t:1526929989700};\\\", \\\"{x:400,y:577,t:1526929989718};\\\", \\\"{x:400,y:580,t:1526929989734};\\\", \\\"{x:400,y:582,t:1526929989752};\\\", \\\"{x:400,y:583,t:1526929989768};\\\", \\\"{x:401,y:585,t:1526929989784};\\\", \\\"{x:402,y:586,t:1526929989800};\\\", \\\"{x:402,y:587,t:1526929989818};\\\", \\\"{x:402,y:589,t:1526929989845};\\\", \\\"{x:402,y:590,t:1526929989861};\\\", \\\"{x:402,y:592,t:1526929989869};\\\", \\\"{x:402,y:593,t:1526929989885};\\\", \\\"{x:400,y:594,t:1526929989901};\\\", \\\"{x:398,y:596,t:1526929989917};\\\", \\\"{x:397,y:596,t:1526929989934};\\\", \\\"{x:395,y:596,t:1526929989952};\\\", \\\"{x:394,y:596,t:1526929989968};\\\", \\\"{x:392,y:596,t:1526929989985};\\\", \\\"{x:389,y:595,t:1526929990002};\\\", \\\"{x:388,y:595,t:1526929990017};\\\", \\\"{x:387,y:595,t:1526929990045};\\\", \\\"{x:386,y:595,t:1526929990061};\\\", \\\"{x:385,y:595,t:1526929990086};\\\", \\\"{x:388,y:595,t:1526929993006};\\\", \\\"{x:391,y:597,t:1526929993020};\\\", \\\"{x:394,y:598,t:1526929993037};\\\", \\\"{x:400,y:605,t:1526929993054};\\\", \\\"{x:404,y:609,t:1526929993071};\\\", \\\"{x:406,y:611,t:1526929993086};\\\", \\\"{x:407,y:612,t:1526929993104};\\\", \\\"{x:407,y:613,t:1526929993121};\\\", \\\"{x:408,y:613,t:1526929993285};\\\", \\\"{x:409,y:614,t:1526929993301};\\\", \\\"{x:409,y:615,t:1526929993334};\\\", \\\"{x:410,y:615,t:1526929993454};\\\", \\\"{x:418,y:615,t:1526929993472};\\\", \\\"{x:430,y:617,t:1526929993488};\\\", \\\"{x:452,y:620,t:1526929993506};\\\", \\\"{x:487,y:625,t:1526929993520};\\\", \\\"{x:530,y:628,t:1526929993540};\\\", \\\"{x:603,y:628,t:1526929993554};\\\", \\\"{x:697,y:628,t:1526929993571};\\\", \\\"{x:804,y:621,t:1526929993589};\\\", \\\"{x:915,y:605,t:1526929993605};\\\", \\\"{x:1103,y:574,t:1526929993620};\\\", \\\"{x:1216,y:541,t:1526929993637};\\\", \\\"{x:1316,y:511,t:1526929993654};\\\", \\\"{x:1391,y:489,t:1526929993671};\\\", \\\"{x:1445,y:473,t:1526929993688};\\\", \\\"{x:1476,y:461,t:1526929993703};\\\", \\\"{x:1499,y:451,t:1526929993720};\\\", \\\"{x:1516,y:441,t:1526929993738};\\\", \\\"{x:1531,y:429,t:1526929993753};\\\", \\\"{x:1548,y:417,t:1526929993771};\\\", \\\"{x:1560,y:407,t:1526929993788};\\\", \\\"{x:1591,y:385,t:1526929993805};\\\", \\\"{x:1613,y:369,t:1526929993821};\\\", \\\"{x:1634,y:355,t:1526929993838};\\\", \\\"{x:1657,y:343,t:1526929993855};\\\", \\\"{x:1681,y:331,t:1526929993871};\\\", \\\"{x:1707,y:322,t:1526929993888};\\\", \\\"{x:1721,y:318,t:1526929993905};\\\", \\\"{x:1723,y:317,t:1526929993921};\\\", \\\"{x:1725,y:317,t:1526929993938};\\\", \\\"{x:1722,y:321,t:1526929993998};\\\", \\\"{x:1720,y:326,t:1526929994005};\\\", \\\"{x:1715,y:338,t:1526929994021};\\\", \\\"{x:1709,y:353,t:1526929994038};\\\", \\\"{x:1701,y:365,t:1526929994055};\\\", \\\"{x:1694,y:374,t:1526929994071};\\\", \\\"{x:1684,y:385,t:1526929994088};\\\", \\\"{x:1677,y:393,t:1526929994104};\\\", \\\"{x:1671,y:400,t:1526929994121};\\\", \\\"{x:1666,y:406,t:1526929994138};\\\", \\\"{x:1664,y:408,t:1526929994154};\\\", \\\"{x:1663,y:410,t:1526929994171};\\\", \\\"{x:1662,y:413,t:1526929994294};\\\", \\\"{x:1660,y:415,t:1526929994305};\\\", \\\"{x:1654,y:422,t:1526929994323};\\\", \\\"{x:1641,y:434,t:1526929994338};\\\", \\\"{x:1628,y:446,t:1526929994355};\\\", \\\"{x:1621,y:452,t:1526929994373};\\\", \\\"{x:1618,y:454,t:1526929994388};\\\", \\\"{x:1615,y:459,t:1526929994958};\\\", \\\"{x:1611,y:471,t:1526929994973};\\\", \\\"{x:1600,y:494,t:1526929994990};\\\", \\\"{x:1595,y:507,t:1526929995006};\\\", \\\"{x:1591,y:515,t:1526929995022};\\\", \\\"{x:1591,y:517,t:1526929995039};\\\", \\\"{x:1592,y:515,t:1526929995125};\\\", \\\"{x:1596,y:508,t:1526929995139};\\\", \\\"{x:1605,y:492,t:1526929995156};\\\", \\\"{x:1612,y:478,t:1526929995171};\\\", \\\"{x:1619,y:466,t:1526929995189};\\\", \\\"{x:1622,y:462,t:1526929995206};\\\", \\\"{x:1622,y:459,t:1526929995222};\\\", \\\"{x:1623,y:458,t:1526929995239};\\\", \\\"{x:1623,y:457,t:1526929995256};\\\", \\\"{x:1623,y:456,t:1526929995272};\\\", \\\"{x:1624,y:455,t:1526929995289};\\\", \\\"{x:1625,y:454,t:1526929995333};\\\", \\\"{x:1626,y:455,t:1526929995381};\\\", \\\"{x:1630,y:461,t:1526929995390};\\\", \\\"{x:1634,y:470,t:1526929995406};\\\", \\\"{x:1640,y:480,t:1526929995422};\\\", \\\"{x:1650,y:492,t:1526929995439};\\\", \\\"{x:1657,y:502,t:1526929995456};\\\", \\\"{x:1664,y:509,t:1526929995472};\\\", \\\"{x:1668,y:511,t:1526929995489};\\\", \\\"{x:1670,y:514,t:1526929995506};\\\", \\\"{x:1672,y:514,t:1526929995522};\\\", \\\"{x:1670,y:514,t:1526929995654};\\\", \\\"{x:1667,y:514,t:1526929995662};\\\", \\\"{x:1666,y:513,t:1526929995673};\\\", \\\"{x:1658,y:506,t:1526929995689};\\\", \\\"{x:1651,y:498,t:1526929995706};\\\", \\\"{x:1646,y:490,t:1526929995723};\\\", \\\"{x:1643,y:482,t:1526929995739};\\\", \\\"{x:1638,y:472,t:1526929995756};\\\", \\\"{x:1634,y:462,t:1526929995774};\\\", \\\"{x:1633,y:459,t:1526929995789};\\\", \\\"{x:1632,y:453,t:1526929995807};\\\", \\\"{x:1631,y:451,t:1526929995824};\\\", \\\"{x:1630,y:451,t:1526929995950};\\\", \\\"{x:1626,y:455,t:1526929995957};\\\", \\\"{x:1620,y:469,t:1526929995973};\\\", \\\"{x:1615,y:489,t:1526929995989};\\\", \\\"{x:1607,y:507,t:1526929996007};\\\", \\\"{x:1597,y:526,t:1526929996024};\\\", \\\"{x:1586,y:543,t:1526929996040};\\\", \\\"{x:1576,y:559,t:1526929996056};\\\", \\\"{x:1566,y:574,t:1526929996074};\\\", \\\"{x:1556,y:585,t:1526929996091};\\\", \\\"{x:1549,y:597,t:1526929996107};\\\", \\\"{x:1546,y:603,t:1526929996123};\\\", \\\"{x:1542,y:613,t:1526929996141};\\\", \\\"{x:1537,y:623,t:1526929996157};\\\", \\\"{x:1531,y:638,t:1526929996173};\\\", \\\"{x:1530,y:639,t:1526929996190};\\\", \\\"{x:1530,y:640,t:1526929996207};\\\", \\\"{x:1530,y:644,t:1526929996662};\\\", \\\"{x:1530,y:647,t:1526929996673};\\\", \\\"{x:1529,y:656,t:1526929996690};\\\", \\\"{x:1523,y:669,t:1526929996708};\\\", \\\"{x:1513,y:680,t:1526929996724};\\\", \\\"{x:1506,y:689,t:1526929996741};\\\", \\\"{x:1496,y:700,t:1526929996757};\\\", \\\"{x:1492,y:712,t:1526929996774};\\\", \\\"{x:1488,y:726,t:1526929996790};\\\", \\\"{x:1483,y:743,t:1526929996807};\\\", \\\"{x:1479,y:754,t:1526929996824};\\\", \\\"{x:1478,y:761,t:1526929996841};\\\", \\\"{x:1478,y:764,t:1526929996858};\\\", \\\"{x:1481,y:761,t:1526929996926};\\\", \\\"{x:1487,y:751,t:1526929996940};\\\", \\\"{x:1516,y:715,t:1526929996958};\\\", \\\"{x:1532,y:698,t:1526929996974};\\\", \\\"{x:1542,y:691,t:1526929996991};\\\", \\\"{x:1546,y:691,t:1526929997007};\\\", \\\"{x:1549,y:691,t:1526929997025};\\\", \\\"{x:1557,y:697,t:1526929997041};\\\", \\\"{x:1564,y:713,t:1526929997057};\\\", \\\"{x:1572,y:732,t:1526929997074};\\\", \\\"{x:1580,y:752,t:1526929997090};\\\", \\\"{x:1587,y:768,t:1526929997107};\\\", \\\"{x:1596,y:785,t:1526929997125};\\\", \\\"{x:1605,y:805,t:1526929997142};\\\", \\\"{x:1611,y:819,t:1526929997157};\\\", \\\"{x:1617,y:835,t:1526929997174};\\\", \\\"{x:1623,y:856,t:1526929997191};\\\", \\\"{x:1629,y:880,t:1526929997207};\\\", \\\"{x:1633,y:897,t:1526929997225};\\\", \\\"{x:1634,y:908,t:1526929997241};\\\", \\\"{x:1634,y:913,t:1526929997258};\\\", \\\"{x:1634,y:916,t:1526929997274};\\\", \\\"{x:1634,y:917,t:1526929997291};\\\", \\\"{x:1634,y:918,t:1526929997422};\\\", \\\"{x:1633,y:918,t:1526929997445};\\\", \\\"{x:1631,y:918,t:1526929997458};\\\", \\\"{x:1630,y:918,t:1526929997475};\\\", \\\"{x:1627,y:918,t:1526929997493};\\\", \\\"{x:1626,y:918,t:1526929997517};\\\", \\\"{x:1625,y:918,t:1526929997524};\\\", \\\"{x:1624,y:918,t:1526929997541};\\\", \\\"{x:1623,y:918,t:1526929997564};\\\", \\\"{x:1622,y:918,t:1526929997580};\\\", \\\"{x:1621,y:918,t:1526929997612};\\\", \\\"{x:1620,y:918,t:1526929997637};\\\", \\\"{x:1619,y:918,t:1526929997653};\\\", \\\"{x:1618,y:918,t:1526929997661};\\\", \\\"{x:1617,y:918,t:1526929997685};\\\", \\\"{x:1616,y:918,t:1526929997693};\\\", \\\"{x:1615,y:918,t:1526929997758};\\\", \\\"{x:1613,y:920,t:1526929997774};\\\", \\\"{x:1606,y:915,t:1526929997792};\\\", \\\"{x:1595,y:901,t:1526929997809};\\\", \\\"{x:1579,y:887,t:1526929997828};\\\", \\\"{x:1573,y:882,t:1526929997845};\\\", \\\"{x:1573,y:880,t:1526929998345};\\\", \\\"{x:1572,y:879,t:1526929998362};\\\", \\\"{x:1572,y:877,t:1526929998408};\\\", \\\"{x:1571,y:876,t:1526929998417};\\\", \\\"{x:1571,y:874,t:1526929998433};\\\", \\\"{x:1570,y:873,t:1526929998445};\\\", \\\"{x:1567,y:872,t:1526929998462};\\\", \\\"{x:1547,y:864,t:1526929998479};\\\", \\\"{x:1493,y:857,t:1526929998496};\\\", \\\"{x:1405,y:845,t:1526929998512};\\\", \\\"{x:1185,y:822,t:1526929998529};\\\", \\\"{x:980,y:811,t:1526929998545};\\\", \\\"{x:769,y:799,t:1526929998562};\\\", \\\"{x:715,y:754,t:1526929998579};\\\", \\\"{x:708,y:752,t:1526929998595};\\\", \\\"{x:704,y:752,t:1526929998612};\\\", \\\"{x:697,y:752,t:1526929998629};\\\", \\\"{x:691,y:752,t:1526929998646};\\\", \\\"{x:676,y:750,t:1526929998662};\\\", \\\"{x:655,y:744,t:1526929998679};\\\", \\\"{x:635,y:739,t:1526929998696};\\\", \\\"{x:630,y:737,t:1526929998712};\\\", \\\"{x:623,y:737,t:1526929998729};\\\", \\\"{x:622,y:736,t:1526929998747};\\\", \\\"{x:621,y:735,t:1526929998785};\\\", \\\"{x:620,y:735,t:1526929998802};\\\", \\\"{x:619,y:733,t:1526929998817};\\\", \\\"{x:617,y:733,t:1526929998866};\\\", \\\"{x:616,y:733,t:1526929998879};\\\", \\\"{x:615,y:733,t:1526929998897};\\\", \\\"{x:609,y:734,t:1526929998912};\\\", \\\"{x:590,y:740,t:1526929998929};\\\", \\\"{x:573,y:744,t:1526929998945};\\\", \\\"{x:556,y:748,t:1526929998963};\\\", \\\"{x:533,y:750,t:1526929998980};\\\", \\\"{x:508,y:756,t:1526929998996};\\\", \\\"{x:482,y:761,t:1526929999012};\\\", \\\"{x:452,y:765,t:1526929999029};\\\", \\\"{x:425,y:768,t:1526929999046};\\\", \\\"{x:402,y:768,t:1526929999062};\\\", \\\"{x:387,y:765,t:1526929999079};\\\", \\\"{x:383,y:761,t:1526929999096};\\\", \\\"{x:383,y:758,t:1526929999113};\\\", \\\"{x:383,y:756,t:1526929999129};\\\", \\\"{x:383,y:754,t:1526929999146};\\\", \\\"{x:384,y:751,t:1526929999164};\\\", \\\"{x:384,y:746,t:1526929999180};\\\", \\\"{x:389,y:737,t:1526929999196};\\\", \\\"{x:393,y:725,t:1526929999213};\\\", \\\"{x:397,y:713,t:1526929999229};\\\", \\\"{x:398,y:708,t:1526929999246};\\\", \\\"{x:400,y:702,t:1526929999264};\\\", \\\"{x:402,y:700,t:1526929999279};\\\", \\\"{x:403,y:699,t:1526929999296};\\\", \\\"{x:410,y:696,t:1526929999314};\\\", \\\"{x:411,y:696,t:1526929999330};\\\", \\\"{x:413,y:696,t:1526929999346};\\\", \\\"{x:419,y:697,t:1526929999364};\\\", \\\"{x:427,y:700,t:1526929999380};\\\", \\\"{x:433,y:701,t:1526929999396};\\\", \\\"{x:437,y:701,t:1526929999413};\\\", \\\"{x:444,y:701,t:1526929999429};\\\", \\\"{x:452,y:701,t:1526929999447};\\\", \\\"{x:457,y:701,t:1526929999463};\\\", \\\"{x:471,y:701,t:1526929999479};\\\", \\\"{x:483,y:701,t:1526929999488};\\\", \\\"{x:487,y:701,t:1526929999506};\\\", \\\"{x:495,y:705,t:1526929999522};\\\", \\\"{x:500,y:709,t:1526929999538};\\\", \\\"{x:506,y:715,t:1526929999556};\\\", \\\"{x:509,y:717,t:1526929999572};\\\", \\\"{x:510,y:718,t:1526929999589};\\\", \\\"{x:511,y:718,t:1526929999606};\\\", \\\"{x:512,y:719,t:1526929999623};\\\", \\\"{x:513,y:719,t:1526929999639};\\\", \\\"{x:513,y:720,t:1526929999656};\\\", \\\"{x:514,y:721,t:1526929999673};\\\" ] }, { \\\"rt\\\": 16765, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 7, \\\"time_elapsed\\\": 380239, \\\"internal_node_id\\\": \\\"0.0-5.0-2.0\\\", \\\"subject\\\": \\\"WKBNA\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 3, \\\"clicks\\\": 1.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F -C -A -11 AM-11 AM-11 AM\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:520,y:720,t:1526930002808};\\\", \\\"{x:524,y:717,t:1526930002817};\\\", \\\"{x:548,y:709,t:1526930002833};\\\", \\\"{x:600,y:694,t:1526930002851};\\\", \\\"{x:684,y:679,t:1526930002867};\\\", \\\"{x:792,y:665,t:1526930002882};\\\", \\\"{x:915,y:663,t:1526930002899};\\\", \\\"{x:1042,y:663,t:1526930002916};\\\", \\\"{x:1181,y:660,t:1526930002932};\\\", \\\"{x:1300,y:660,t:1526930002949};\\\", \\\"{x:1424,y:660,t:1526930002966};\\\", \\\"{x:1525,y:663,t:1526930002982};\\\", \\\"{x:1592,y:663,t:1526930002999};\\\", \\\"{x:1648,y:663,t:1526930003016};\\\", \\\"{x:1679,y:663,t:1526930003032};\\\", \\\"{x:1706,y:661,t:1526930003049};\\\", \\\"{x:1712,y:659,t:1526930003066};\\\", \\\"{x:1720,y:654,t:1526930003082};\\\", \\\"{x:1724,y:650,t:1526930003100};\\\", \\\"{x:1730,y:646,t:1526930003116};\\\", \\\"{x:1732,y:643,t:1526930003132};\\\", \\\"{x:1733,y:642,t:1526930003149};\\\", \\\"{x:1733,y:640,t:1526930003166};\\\", \\\"{x:1729,y:639,t:1526930003266};\\\", \\\"{x:1698,y:634,t:1526930003284};\\\", \\\"{x:1654,y:629,t:1526930003300};\\\", \\\"{x:1601,y:623,t:1526930003316};\\\", \\\"{x:1542,y:615,t:1526930003334};\\\", \\\"{x:1490,y:610,t:1526930003349};\\\", \\\"{x:1467,y:610,t:1526930003366};\\\", \\\"{x:1458,y:610,t:1526930003383};\\\", \\\"{x:1456,y:610,t:1526930003400};\\\", \\\"{x:1455,y:610,t:1526930003416};\\\", \\\"{x:1454,y:611,t:1526930003433};\\\", \\\"{x:1453,y:614,t:1526930003449};\\\", \\\"{x:1451,y:617,t:1526930003467};\\\", \\\"{x:1448,y:625,t:1526930003484};\\\", \\\"{x:1443,y:640,t:1526930003500};\\\", \\\"{x:1436,y:659,t:1526930003517};\\\", \\\"{x:1431,y:679,t:1526930003534};\\\", \\\"{x:1422,y:699,t:1526930003549};\\\", \\\"{x:1408,y:723,t:1526930003567};\\\", \\\"{x:1393,y:743,t:1526930003583};\\\", \\\"{x:1385,y:757,t:1526930003599};\\\", \\\"{x:1380,y:768,t:1526930003619};\\\", \\\"{x:1376,y:776,t:1526930003634};\\\", \\\"{x:1373,y:780,t:1526930003651};\\\", \\\"{x:1373,y:781,t:1526930003667};\\\", \\\"{x:1372,y:782,t:1526930003786};\\\", \\\"{x:1369,y:787,t:1526930003801};\\\", \\\"{x:1365,y:791,t:1526930003816};\\\", \\\"{x:1353,y:809,t:1526930003833};\\\", \\\"{x:1338,y:822,t:1526930003850};\\\", \\\"{x:1320,y:834,t:1526930003866};\\\", \\\"{x:1302,y:838,t:1526930003884};\\\", \\\"{x:1281,y:842,t:1526930003901};\\\", \\\"{x:1269,y:842,t:1526930003916};\\\", \\\"{x:1261,y:842,t:1526930003933};\\\", \\\"{x:1258,y:842,t:1526930003951};\\\", \\\"{x:1257,y:842,t:1526930003966};\\\", \\\"{x:1256,y:842,t:1526930003993};\\\", \\\"{x:1254,y:842,t:1526930004017};\\\", \\\"{x:1252,y:842,t:1526930004034};\\\", \\\"{x:1251,y:842,t:1526930004051};\\\", \\\"{x:1250,y:842,t:1526930004106};\\\", \\\"{x:1249,y:842,t:1526930004117};\\\", \\\"{x:1248,y:842,t:1526930004133};\\\", \\\"{x:1245,y:842,t:1526930004150};\\\", \\\"{x:1242,y:842,t:1526930004167};\\\", \\\"{x:1237,y:842,t:1526930004183};\\\", \\\"{x:1232,y:842,t:1526930004200};\\\", \\\"{x:1223,y:845,t:1526930004216};\\\", \\\"{x:1220,y:848,t:1526930004233};\\\", \\\"{x:1216,y:850,t:1526930004251};\\\", \\\"{x:1215,y:850,t:1526930004267};\\\", \\\"{x:1214,y:850,t:1526930004297};\\\", \\\"{x:1213,y:850,t:1526930004305};\\\", \\\"{x:1212,y:850,t:1526930004318};\\\", \\\"{x:1210,y:850,t:1526930004333};\\\", \\\"{x:1208,y:850,t:1526930004350};\\\", \\\"{x:1205,y:849,t:1526930004367};\\\", \\\"{x:1203,y:848,t:1526930004384};\\\", \\\"{x:1203,y:847,t:1526930004474};\\\", \\\"{x:1203,y:845,t:1526930004538};\\\", \\\"{x:1203,y:844,t:1526930004551};\\\", \\\"{x:1204,y:841,t:1526930004568};\\\", \\\"{x:1205,y:840,t:1526930004657};\\\", \\\"{x:1206,y:840,t:1526930004673};\\\", \\\"{x:1208,y:840,t:1526930004689};\\\", \\\"{x:1210,y:841,t:1526930004701};\\\", \\\"{x:1212,y:841,t:1526930004718};\\\", \\\"{x:1213,y:842,t:1526930004735};\\\", \\\"{x:1214,y:841,t:1526930004914};\\\", \\\"{x:1214,y:838,t:1526930004922};\\\", \\\"{x:1216,y:835,t:1526930004935};\\\", \\\"{x:1217,y:829,t:1526930004951};\\\", \\\"{x:1220,y:823,t:1526930004969};\\\", \\\"{x:1220,y:819,t:1526930004985};\\\", \\\"{x:1221,y:818,t:1526930005001};\\\", \\\"{x:1221,y:817,t:1526930005018};\\\", \\\"{x:1222,y:817,t:1526930005154};\\\", \\\"{x:1223,y:817,t:1526930005167};\\\", \\\"{x:1223,y:818,t:1526930005266};\\\", \\\"{x:1223,y:819,t:1526930005290};\\\", \\\"{x:1223,y:820,t:1526930005306};\\\", \\\"{x:1223,y:821,t:1526930005321};\\\", \\\"{x:1223,y:823,t:1526930005425};\\\", \\\"{x:1222,y:825,t:1526930005435};\\\", \\\"{x:1218,y:837,t:1526930005452};\\\", \\\"{x:1217,y:850,t:1526930005468};\\\", \\\"{x:1212,y:865,t:1526930005484};\\\", \\\"{x:1207,y:881,t:1526930005501};\\\", \\\"{x:1203,y:890,t:1526930005518};\\\", \\\"{x:1200,y:896,t:1526930005535};\\\", \\\"{x:1199,y:897,t:1526930005552};\\\", \\\"{x:1199,y:893,t:1526930005594};\\\", \\\"{x:1201,y:886,t:1526930005602};\\\", \\\"{x:1208,y:865,t:1526930005619};\\\", \\\"{x:1214,y:849,t:1526930005634};\\\", \\\"{x:1223,y:835,t:1526930005652};\\\", \\\"{x:1232,y:825,t:1526930005668};\\\", \\\"{x:1237,y:821,t:1526930005685};\\\", \\\"{x:1238,y:821,t:1526930005730};\\\", \\\"{x:1240,y:821,t:1526930005745};\\\", \\\"{x:1241,y:821,t:1526930005753};\\\", \\\"{x:1243,y:825,t:1526930005769};\\\", \\\"{x:1248,y:833,t:1526930005784};\\\", \\\"{x:1259,y:849,t:1526930005801};\\\", \\\"{x:1270,y:864,t:1526930005818};\\\", \\\"{x:1280,y:878,t:1526930005834};\\\", \\\"{x:1286,y:892,t:1526930005851};\\\", \\\"{x:1294,y:910,t:1526930005869};\\\", \\\"{x:1298,y:928,t:1526930005885};\\\", \\\"{x:1302,y:945,t:1526930005901};\\\", \\\"{x:1306,y:960,t:1526930005918};\\\", \\\"{x:1311,y:975,t:1526930005934};\\\", \\\"{x:1316,y:986,t:1526930005951};\\\", \\\"{x:1317,y:990,t:1526930005968};\\\", \\\"{x:1317,y:991,t:1526930005984};\\\", \\\"{x:1317,y:990,t:1526930006088};\\\", \\\"{x:1317,y:989,t:1526930006102};\\\", \\\"{x:1315,y:987,t:1526930006119};\\\", \\\"{x:1313,y:982,t:1526930006136};\\\", \\\"{x:1310,y:978,t:1526930006151};\\\", \\\"{x:1303,y:968,t:1526930006169};\\\", \\\"{x:1300,y:961,t:1526930006184};\\\", \\\"{x:1300,y:958,t:1526930006202};\\\", \\\"{x:1299,y:954,t:1526930006219};\\\", \\\"{x:1299,y:951,t:1526930006235};\\\", \\\"{x:1298,y:947,t:1526930006251};\\\", \\\"{x:1298,y:945,t:1526930006268};\\\", \\\"{x:1297,y:944,t:1526930006285};\\\", \\\"{x:1296,y:944,t:1526930006301};\\\", \\\"{x:1295,y:944,t:1526930006338};\\\", \\\"{x:1293,y:946,t:1526930006351};\\\", \\\"{x:1290,y:950,t:1526930006369};\\\", \\\"{x:1283,y:960,t:1526930006386};\\\", \\\"{x:1280,y:962,t:1526930006402};\\\", \\\"{x:1280,y:961,t:1526930006658};\\\", \\\"{x:1281,y:961,t:1526930006779};\\\", \\\"{x:1282,y:960,t:1526930006785};\\\", \\\"{x:1285,y:958,t:1526930006802};\\\", \\\"{x:1289,y:955,t:1526930006818};\\\", \\\"{x:1298,y:946,t:1526930006835};\\\", \\\"{x:1308,y:934,t:1526930006852};\\\", \\\"{x:1319,y:915,t:1526930006868};\\\", \\\"{x:1330,y:895,t:1526930006885};\\\", \\\"{x:1342,y:873,t:1526930006903};\\\", \\\"{x:1357,y:850,t:1526930006918};\\\", \\\"{x:1370,y:830,t:1526930006936};\\\", \\\"{x:1395,y:792,t:1526930006952};\\\", \\\"{x:1411,y:772,t:1526930006969};\\\", \\\"{x:1422,y:756,t:1526930006985};\\\", \\\"{x:1428,y:746,t:1526930007002};\\\", \\\"{x:1430,y:744,t:1526930007019};\\\", \\\"{x:1426,y:748,t:1526930007169};\\\", \\\"{x:1408,y:759,t:1526930007185};\\\", \\\"{x:1367,y:778,t:1526930007202};\\\", \\\"{x:1306,y:795,t:1526930007220};\\\", \\\"{x:1232,y:800,t:1526930007235};\\\", \\\"{x:1143,y:800,t:1526930007252};\\\", \\\"{x:1027,y:768,t:1526930007270};\\\", \\\"{x:885,y:715,t:1526930007285};\\\", \\\"{x:745,y:660,t:1526930007302};\\\", \\\"{x:623,y:607,t:1526930007320};\\\", \\\"{x:501,y:567,t:1526930007337};\\\", \\\"{x:399,y:539,t:1526930007352};\\\", \\\"{x:294,y:525,t:1526930007370};\\\", \\\"{x:262,y:523,t:1526930007387};\\\", \\\"{x:239,y:523,t:1526930007403};\\\", \\\"{x:222,y:527,t:1526930007419};\\\", \\\"{x:220,y:529,t:1526930007436};\\\", \\\"{x:219,y:530,t:1526930007453};\\\", \\\"{x:219,y:531,t:1526930007528};\\\", \\\"{x:223,y:531,t:1526930007536};\\\", \\\"{x:240,y:533,t:1526930007553};\\\", \\\"{x:254,y:536,t:1526930007569};\\\", \\\"{x:267,y:540,t:1526930007587};\\\", \\\"{x:282,y:545,t:1526930007604};\\\", \\\"{x:295,y:550,t:1526930007619};\\\", \\\"{x:310,y:553,t:1526930007636};\\\", \\\"{x:326,y:559,t:1526930007653};\\\", \\\"{x:341,y:563,t:1526930007669};\\\", \\\"{x:350,y:565,t:1526930007686};\\\", \\\"{x:356,y:566,t:1526930007703};\\\", \\\"{x:360,y:567,t:1526930007721};\\\", \\\"{x:362,y:567,t:1526930007818};\\\", \\\"{x:363,y:567,t:1526930007841};\\\", \\\"{x:364,y:567,t:1526930007881};\\\", \\\"{x:365,y:566,t:1526930007905};\\\", \\\"{x:367,y:565,t:1526930007920};\\\", \\\"{x:370,y:562,t:1526930007937};\\\", \\\"{x:372,y:560,t:1526930007953};\\\", \\\"{x:374,y:559,t:1526930008688};\\\", \\\"{x:380,y:559,t:1526930008705};\\\", \\\"{x:382,y:560,t:1526930008720};\\\", \\\"{x:384,y:560,t:1526930008752};\\\", \\\"{x:385,y:560,t:1526930008777};\\\", \\\"{x:389,y:560,t:1526930009314};\\\", \\\"{x:391,y:559,t:1526930009321};\\\", \\\"{x:397,y:556,t:1526930009338};\\\", \\\"{x:400,y:555,t:1526930009354};\\\", \\\"{x:412,y:555,t:1526930009371};\\\", \\\"{x:431,y:555,t:1526930009387};\\\", \\\"{x:472,y:565,t:1526930009405};\\\", \\\"{x:548,y:582,t:1526930009422};\\\", \\\"{x:647,y:604,t:1526930009438};\\\", \\\"{x:757,y:634,t:1526930009454};\\\", \\\"{x:881,y:666,t:1526930009471};\\\", \\\"{x:1061,y:716,t:1526930009488};\\\", \\\"{x:1155,y:744,t:1526930009504};\\\", \\\"{x:1206,y:759,t:1526930009522};\\\", \\\"{x:1229,y:768,t:1526930009539};\\\", \\\"{x:1250,y:777,t:1526930009554};\\\", \\\"{x:1266,y:784,t:1526930009571};\\\", \\\"{x:1275,y:789,t:1526930009588};\\\", \\\"{x:1280,y:792,t:1526930009604};\\\", \\\"{x:1282,y:793,t:1526930009621};\\\", \\\"{x:1282,y:794,t:1526930009638};\\\", \\\"{x:1284,y:798,t:1526930009654};\\\", \\\"{x:1285,y:803,t:1526930009671};\\\", \\\"{x:1286,y:816,t:1526930009688};\\\", \\\"{x:1286,y:827,t:1526930009705};\\\", \\\"{x:1276,y:840,t:1526930009721};\\\", \\\"{x:1262,y:850,t:1526930009739};\\\", \\\"{x:1246,y:858,t:1526930009754};\\\", \\\"{x:1233,y:863,t:1526930009771};\\\", \\\"{x:1221,y:866,t:1526930009789};\\\", \\\"{x:1214,y:868,t:1526930009805};\\\", \\\"{x:1210,y:868,t:1526930009821};\\\", \\\"{x:1209,y:868,t:1526930009838};\\\", \\\"{x:1207,y:869,t:1526930009855};\\\", \\\"{x:1205,y:869,t:1526930009871};\\\", \\\"{x:1202,y:871,t:1526930009888};\\\", \\\"{x:1200,y:872,t:1526930009905};\\\", \\\"{x:1200,y:871,t:1526930009953};\\\", \\\"{x:1202,y:865,t:1526930009960};\\\", \\\"{x:1206,y:859,t:1526930009971};\\\", \\\"{x:1216,y:844,t:1526930009988};\\\", \\\"{x:1229,y:832,t:1526930010006};\\\", \\\"{x:1244,y:822,t:1526930010021};\\\", \\\"{x:1255,y:818,t:1526930010039};\\\", \\\"{x:1264,y:817,t:1526930010055};\\\", \\\"{x:1267,y:816,t:1526930010072};\\\", \\\"{x:1266,y:818,t:1526930010298};\\\", \\\"{x:1262,y:820,t:1526930010306};\\\", \\\"{x:1254,y:824,t:1526930010323};\\\", \\\"{x:1243,y:831,t:1526930010339};\\\", \\\"{x:1235,y:835,t:1526930010356};\\\", \\\"{x:1230,y:836,t:1526930010373};\\\", \\\"{x:1229,y:836,t:1526930010400};\\\", \\\"{x:1228,y:836,t:1526930010408};\\\", \\\"{x:1227,y:836,t:1526930010424};\\\", \\\"{x:1226,y:836,t:1526930010441};\\\", \\\"{x:1225,y:836,t:1526930010456};\\\", \\\"{x:1224,y:836,t:1526930010609};\\\", \\\"{x:1222,y:835,t:1526930010665};\\\", \\\"{x:1221,y:835,t:1526930010673};\\\", \\\"{x:1222,y:835,t:1526930011321};\\\", \\\"{x:1225,y:839,t:1526930011330};\\\", \\\"{x:1227,y:843,t:1526930011340};\\\", \\\"{x:1234,y:854,t:1526930011357};\\\", \\\"{x:1243,y:865,t:1526930011373};\\\", \\\"{x:1251,y:877,t:1526930011390};\\\", \\\"{x:1258,y:886,t:1526930011407};\\\", \\\"{x:1265,y:900,t:1526930011422};\\\", \\\"{x:1274,y:915,t:1526930011440};\\\", \\\"{x:1290,y:944,t:1526930011457};\\\", \\\"{x:1300,y:962,t:1526930011473};\\\", \\\"{x:1309,y:978,t:1526930011490};\\\", \\\"{x:1316,y:993,t:1526930011506};\\\", \\\"{x:1319,y:999,t:1526930011522};\\\", \\\"{x:1319,y:1002,t:1526930011540};\\\", \\\"{x:1320,y:1003,t:1526930011556};\\\", \\\"{x:1321,y:1005,t:1526930011573};\\\", \\\"{x:1321,y:1006,t:1526930011590};\\\", \\\"{x:1321,y:1008,t:1526930011607};\\\", \\\"{x:1321,y:1010,t:1526930011624};\\\", \\\"{x:1321,y:1011,t:1526930011639};\\\", \\\"{x:1321,y:1013,t:1526930011657};\\\", \\\"{x:1320,y:1013,t:1526930011745};\\\", \\\"{x:1317,y:1007,t:1526930011757};\\\", \\\"{x:1309,y:994,t:1526930011774};\\\", \\\"{x:1303,y:985,t:1526930011790};\\\", \\\"{x:1302,y:983,t:1526930011807};\\\", \\\"{x:1299,y:980,t:1526930011824};\\\", \\\"{x:1298,y:979,t:1526930011840};\\\", \\\"{x:1296,y:978,t:1526930011856};\\\", \\\"{x:1295,y:977,t:1526930011874};\\\", \\\"{x:1293,y:976,t:1526930011890};\\\", \\\"{x:1292,y:976,t:1526930011930};\\\", \\\"{x:1291,y:976,t:1526930011980};\\\", \\\"{x:1290,y:975,t:1526930011992};\\\", \\\"{x:1289,y:974,t:1526930012006};\\\", \\\"{x:1288,y:973,t:1526930012024};\\\", \\\"{x:1287,y:971,t:1526930012040};\\\", \\\"{x:1286,y:970,t:1526930012089};\\\", \\\"{x:1285,y:968,t:1526930012121};\\\", \\\"{x:1284,y:967,t:1526930012137};\\\", \\\"{x:1283,y:965,t:1526930012145};\\\", \\\"{x:1281,y:963,t:1526930012161};\\\", \\\"{x:1279,y:959,t:1526930012174};\\\", \\\"{x:1276,y:954,t:1526930012191};\\\", \\\"{x:1275,y:952,t:1526930012206};\\\", \\\"{x:1274,y:952,t:1526930012233};\\\", \\\"{x:1275,y:952,t:1526930012570};\\\", \\\"{x:1276,y:953,t:1526930012610};\\\", \\\"{x:1277,y:953,t:1526930012643};\\\", \\\"{x:1278,y:954,t:1526930012658};\\\", \\\"{x:1279,y:954,t:1526930012674};\\\", \\\"{x:1281,y:956,t:1526930012691};\\\", \\\"{x:1281,y:957,t:1526930013313};\\\", \\\"{x:1281,y:958,t:1526930013325};\\\", \\\"{x:1281,y:960,t:1526930013341};\\\", \\\"{x:1281,y:962,t:1526930013359};\\\", \\\"{x:1282,y:963,t:1526930013386};\\\", \\\"{x:1283,y:964,t:1526930013650};\\\", \\\"{x:1284,y:967,t:1526930013658};\\\", \\\"{x:1291,y:976,t:1526930013675};\\\", \\\"{x:1293,y:983,t:1526930013692};\\\", \\\"{x:1293,y:987,t:1526930013709};\\\", \\\"{x:1293,y:990,t:1526930013725};\\\", \\\"{x:1293,y:991,t:1526930013742};\\\", \\\"{x:1293,y:992,t:1526930013758};\\\", \\\"{x:1293,y:991,t:1526930013849};\\\", \\\"{x:1293,y:990,t:1526930013859};\\\", \\\"{x:1293,y:986,t:1526930013875};\\\", \\\"{x:1292,y:983,t:1526930013892};\\\", \\\"{x:1292,y:981,t:1526930013909};\\\", \\\"{x:1291,y:980,t:1526930013925};\\\", \\\"{x:1290,y:979,t:1526930013942};\\\", \\\"{x:1290,y:978,t:1526930013959};\\\", \\\"{x:1290,y:977,t:1526930014193};\\\", \\\"{x:1289,y:976,t:1526930014209};\\\", \\\"{x:1288,y:974,t:1526930014225};\\\", \\\"{x:1287,y:974,t:1526930014249};\\\", \\\"{x:1286,y:972,t:1526930014314};\\\", \\\"{x:1286,y:971,t:1526930014426};\\\", \\\"{x:1286,y:970,t:1526930014442};\\\", \\\"{x:1286,y:968,t:1526930014570};\\\", \\\"{x:1286,y:967,t:1526930014593};\\\", \\\"{x:1288,y:965,t:1526930014610};\\\", \\\"{x:1289,y:963,t:1526930014626};\\\", \\\"{x:1290,y:960,t:1526930014643};\\\", \\\"{x:1292,y:959,t:1526930014659};\\\", \\\"{x:1293,y:957,t:1526930014689};\\\", \\\"{x:1294,y:955,t:1526930014780};\\\", \\\"{x:1295,y:954,t:1526930014793};\\\", \\\"{x:1296,y:952,t:1526930014809};\\\", \\\"{x:1297,y:951,t:1526930014841};\\\", \\\"{x:1298,y:950,t:1526930014938};\\\", \\\"{x:1298,y:949,t:1526930014980};\\\", \\\"{x:1298,y:948,t:1526930014993};\\\", \\\"{x:1299,y:947,t:1526930015009};\\\", \\\"{x:1299,y:946,t:1526930015026};\\\", \\\"{x:1300,y:944,t:1526930015043};\\\", \\\"{x:1301,y:942,t:1526930015059};\\\", \\\"{x:1302,y:937,t:1526930015076};\\\", \\\"{x:1305,y:933,t:1526930015094};\\\", \\\"{x:1306,y:929,t:1526930015110};\\\", \\\"{x:1308,y:923,t:1526930015126};\\\", \\\"{x:1310,y:922,t:1526930015143};\\\", \\\"{x:1310,y:919,t:1526930015160};\\\", \\\"{x:1312,y:915,t:1526930015176};\\\", \\\"{x:1316,y:908,t:1526930015194};\\\", \\\"{x:1321,y:901,t:1526930015209};\\\", \\\"{x:1324,y:895,t:1526930015226};\\\", \\\"{x:1327,y:888,t:1526930015243};\\\", \\\"{x:1330,y:885,t:1526930015260};\\\", \\\"{x:1333,y:881,t:1526930015276};\\\", \\\"{x:1336,y:877,t:1526930015293};\\\", \\\"{x:1337,y:876,t:1526930015310};\\\", \\\"{x:1337,y:875,t:1526930015326};\\\", \\\"{x:1339,y:873,t:1526930015343};\\\", \\\"{x:1340,y:871,t:1526930015360};\\\", \\\"{x:1342,y:868,t:1526930015377};\\\", \\\"{x:1344,y:864,t:1526930015393};\\\", \\\"{x:1347,y:860,t:1526930015410};\\\", \\\"{x:1351,y:853,t:1526930015426};\\\", \\\"{x:1354,y:848,t:1526930015443};\\\", \\\"{x:1357,y:844,t:1526930015460};\\\", \\\"{x:1360,y:839,t:1526930015476};\\\", \\\"{x:1364,y:833,t:1526930015493};\\\", \\\"{x:1367,y:828,t:1526930015510};\\\", \\\"{x:1368,y:824,t:1526930015527};\\\", \\\"{x:1370,y:821,t:1526930015544};\\\", \\\"{x:1370,y:818,t:1526930015561};\\\", \\\"{x:1371,y:815,t:1526930015579};\\\", \\\"{x:1372,y:814,t:1526930015593};\\\", \\\"{x:1373,y:812,t:1526930015610};\\\", \\\"{x:1373,y:811,t:1526930015627};\\\", \\\"{x:1374,y:809,t:1526930015643};\\\", \\\"{x:1374,y:808,t:1526930015660};\\\", \\\"{x:1375,y:806,t:1526930015677};\\\", \\\"{x:1375,y:805,t:1526930015693};\\\", \\\"{x:1376,y:803,t:1526930015710};\\\", \\\"{x:1377,y:802,t:1526930015729};\\\", \\\"{x:1377,y:801,t:1526930015753};\\\", \\\"{x:1377,y:799,t:1526930015769};\\\", \\\"{x:1378,y:798,t:1526930015779};\\\", \\\"{x:1378,y:796,t:1526930015793};\\\", \\\"{x:1380,y:793,t:1526930015810};\\\", \\\"{x:1381,y:791,t:1526930015826};\\\", \\\"{x:1382,y:788,t:1526930015843};\\\", \\\"{x:1384,y:785,t:1526930015860};\\\", \\\"{x:1384,y:784,t:1526930015876};\\\", \\\"{x:1385,y:783,t:1526930015893};\\\", \\\"{x:1376,y:783,t:1526930016098};\\\", \\\"{x:1360,y:783,t:1526930016110};\\\", \\\"{x:1282,y:783,t:1526930016127};\\\", \\\"{x:1182,y:770,t:1526930016144};\\\", \\\"{x:1064,y:743,t:1526930016160};\\\", \\\"{x:853,y:693,t:1526930016178};\\\", \\\"{x:704,y:660,t:1526930016194};\\\", \\\"{x:604,y:642,t:1526930016211};\\\", \\\"{x:552,y:639,t:1526930016227};\\\", \\\"{x:529,y:635,t:1526930016243};\\\", \\\"{x:519,y:635,t:1526930016255};\\\", \\\"{x:507,y:635,t:1526930016271};\\\", \\\"{x:502,y:635,t:1526930016287};\\\", \\\"{x:501,y:635,t:1526930016344};\\\", \\\"{x:499,y:635,t:1526930016354};\\\", \\\"{x:494,y:637,t:1526930016371};\\\", \\\"{x:481,y:640,t:1526930016387};\\\", \\\"{x:457,y:645,t:1526930016411};\\\", \\\"{x:450,y:647,t:1526930016428};\\\", \\\"{x:446,y:649,t:1526930016444};\\\", \\\"{x:443,y:650,t:1526930016461};\\\", \\\"{x:441,y:652,t:1526930016478};\\\", \\\"{x:441,y:654,t:1526930016493};\\\", \\\"{x:441,y:659,t:1526930016510};\\\", \\\"{x:441,y:662,t:1526930016527};\\\", \\\"{x:449,y:671,t:1526930016544};\\\", \\\"{x:469,y:686,t:1526930016561};\\\", \\\"{x:481,y:694,t:1526930016578};\\\", \\\"{x:487,y:697,t:1526930016593};\\\", \\\"{x:492,y:700,t:1526930016611};\\\", \\\"{x:497,y:703,t:1526930016628};\\\", \\\"{x:504,y:707,t:1526930016643};\\\", \\\"{x:508,y:709,t:1526930016661};\\\", \\\"{x:509,y:710,t:1526930016678};\\\", \\\"{x:510,y:710,t:1526930016694};\\\", \\\"{x:512,y:711,t:1526930016711};\\\", \\\"{x:512,y:712,t:1526930016794};\\\", \\\"{x:512,y:713,t:1526930016817};\\\", \\\"{x:513,y:714,t:1526930016841};\\\" ] }, { \\\"rt\\\": 16689, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 8, \\\"time_elapsed\\\": 398150, \\\"internal_node_id\\\": \\\"0.0-5.0-3.0\\\", \\\"subject\\\": \\\"WKBNA\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 4, \\\"clicks\\\": 3, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"H\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-01 PM-09 AM-11 AM-12 PM-04 PM-04 PM-H -05 PM-04 PM\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:512,y:717,t:1526930020498};\\\", \\\"{x:509,y:721,t:1526930020515};\\\", \\\"{x:489,y:747,t:1526930020617};\\\", \\\"{x:489,y:749,t:1526930020632};\\\", \\\"{x:488,y:750,t:1526930020647};\\\", \\\"{x:487,y:751,t:1526930020664};\\\", \\\"{x:492,y:751,t:1526930020897};\\\", \\\"{x:528,y:745,t:1526930020914};\\\", \\\"{x:586,y:736,t:1526930020931};\\\", \\\"{x:674,y:729,t:1526930020948};\\\", \\\"{x:782,y:729,t:1526930020964};\\\", \\\"{x:893,y:729,t:1526930020981};\\\", \\\"{x:1020,y:729,t:1526930020998};\\\", \\\"{x:1158,y:739,t:1526930021015};\\\", \\\"{x:1295,y:754,t:1526930021032};\\\", \\\"{x:1414,y:764,t:1526930021049};\\\", \\\"{x:1520,y:770,t:1526930021065};\\\", \\\"{x:1613,y:773,t:1526930021081};\\\", \\\"{x:1635,y:773,t:1526930021099};\\\", \\\"{x:1639,y:773,t:1526930021115};\\\", \\\"{x:1640,y:773,t:1526930021131};\\\", \\\"{x:1639,y:773,t:1526930021250};\\\", \\\"{x:1634,y:774,t:1526930021265};\\\", \\\"{x:1624,y:774,t:1526930021281};\\\", \\\"{x:1606,y:774,t:1526930021298};\\\", \\\"{x:1584,y:774,t:1526930021316};\\\", \\\"{x:1554,y:773,t:1526930021331};\\\", \\\"{x:1517,y:768,t:1526930021349};\\\", \\\"{x:1475,y:768,t:1526930021365};\\\", \\\"{x:1438,y:766,t:1526930021383};\\\", \\\"{x:1396,y:766,t:1526930021398};\\\", \\\"{x:1358,y:766,t:1526930021416};\\\", \\\"{x:1329,y:766,t:1526930021433};\\\", \\\"{x:1312,y:766,t:1526930021449};\\\", \\\"{x:1300,y:766,t:1526930021465};\\\", \\\"{x:1297,y:766,t:1526930021482};\\\", \\\"{x:1296,y:766,t:1526930021505};\\\", \\\"{x:1295,y:766,t:1526930021521};\\\", \\\"{x:1294,y:766,t:1526930021533};\\\", \\\"{x:1293,y:766,t:1526930021585};\\\", \\\"{x:1293,y:767,t:1526930021888};\\\", \\\"{x:1298,y:773,t:1526930021899};\\\", \\\"{x:1313,y:789,t:1526930021915};\\\", \\\"{x:1332,y:813,t:1526930021933};\\\", \\\"{x:1361,y:849,t:1526930021949};\\\", \\\"{x:1381,y:871,t:1526930021966};\\\", \\\"{x:1398,y:888,t:1526930021982};\\\", \\\"{x:1412,y:903,t:1526930021999};\\\", \\\"{x:1424,y:917,t:1526930022015};\\\", \\\"{x:1436,y:934,t:1526930022032};\\\", \\\"{x:1447,y:952,t:1526930022049};\\\", \\\"{x:1451,y:960,t:1526930022066};\\\", \\\"{x:1453,y:966,t:1526930022082};\\\", \\\"{x:1453,y:969,t:1526930022099};\\\", \\\"{x:1453,y:972,t:1526930022117};\\\", \\\"{x:1453,y:973,t:1526930022132};\\\", \\\"{x:1452,y:973,t:1526930022154};\\\", \\\"{x:1451,y:973,t:1526930022167};\\\", \\\"{x:1450,y:973,t:1526930022182};\\\", \\\"{x:1444,y:975,t:1526930022199};\\\", \\\"{x:1433,y:975,t:1526930022217};\\\", \\\"{x:1414,y:980,t:1526930022232};\\\", \\\"{x:1371,y:986,t:1526930022250};\\\", \\\"{x:1330,y:988,t:1526930022266};\\\", \\\"{x:1282,y:990,t:1526930022282};\\\", \\\"{x:1237,y:990,t:1526930022299};\\\", \\\"{x:1206,y:990,t:1526930022316};\\\", \\\"{x:1173,y:981,t:1526930022332};\\\", \\\"{x:1154,y:975,t:1526930022349};\\\", \\\"{x:1136,y:967,t:1526930022367};\\\", \\\"{x:1129,y:963,t:1526930022383};\\\", \\\"{x:1126,y:961,t:1526930022399};\\\", \\\"{x:1125,y:961,t:1526930022473};\\\", \\\"{x:1124,y:961,t:1526930022554};\\\", \\\"{x:1123,y:961,t:1526930022567};\\\", \\\"{x:1122,y:960,t:1526930022583};\\\", \\\"{x:1122,y:959,t:1526930022599};\\\", \\\"{x:1122,y:958,t:1526930022616};\\\", \\\"{x:1122,y:957,t:1526930022633};\\\", \\\"{x:1122,y:956,t:1526930022688};\\\", \\\"{x:1123,y:955,t:1526930022704};\\\", \\\"{x:1124,y:954,t:1526930022716};\\\", \\\"{x:1125,y:954,t:1526930022733};\\\", \\\"{x:1129,y:951,t:1526930022749};\\\", \\\"{x:1130,y:949,t:1526930022766};\\\", \\\"{x:1132,y:947,t:1526930022783};\\\", \\\"{x:1133,y:946,t:1526930022800};\\\", \\\"{x:1137,y:946,t:1526930023314};\\\", \\\"{x:1150,y:950,t:1526930023321};\\\", \\\"{x:1170,y:955,t:1526930023333};\\\", \\\"{x:1219,y:966,t:1526930023350};\\\", \\\"{x:1285,y:975,t:1526930023368};\\\", \\\"{x:1360,y:984,t:1526930023384};\\\", \\\"{x:1429,y:992,t:1526930023401};\\\", \\\"{x:1522,y:994,t:1526930023417};\\\", \\\"{x:1556,y:994,t:1526930023435};\\\", \\\"{x:1577,y:994,t:1526930023451};\\\", \\\"{x:1588,y:997,t:1526930023467};\\\", \\\"{x:1596,y:999,t:1526930023485};\\\", \\\"{x:1599,y:1000,t:1526930023500};\\\", \\\"{x:1603,y:1001,t:1526930023517};\\\", \\\"{x:1606,y:1001,t:1526930023535};\\\", \\\"{x:1611,y:1001,t:1526930023551};\\\", \\\"{x:1613,y:1001,t:1526930023568};\\\", \\\"{x:1616,y:1001,t:1526930023584};\\\", \\\"{x:1617,y:1001,t:1526930023600};\\\", \\\"{x:1620,y:1001,t:1526930023617};\\\", \\\"{x:1620,y:999,t:1526930023794};\\\", \\\"{x:1620,y:996,t:1526930023801};\\\", \\\"{x:1619,y:985,t:1526930023818};\\\", \\\"{x:1616,y:972,t:1526930023835};\\\", \\\"{x:1616,y:966,t:1526930023851};\\\", \\\"{x:1614,y:960,t:1526930023867};\\\", \\\"{x:1613,y:957,t:1526930023885};\\\", \\\"{x:1612,y:956,t:1526930023900};\\\", \\\"{x:1613,y:956,t:1526930024080};\\\", \\\"{x:1615,y:957,t:1526930024088};\\\", \\\"{x:1616,y:958,t:1526930024101};\\\", \\\"{x:1619,y:961,t:1526930024118};\\\", \\\"{x:1623,y:968,t:1526930024134};\\\", \\\"{x:1627,y:972,t:1526930024150};\\\", \\\"{x:1631,y:977,t:1526930024168};\\\", \\\"{x:1631,y:978,t:1526930024184};\\\", \\\"{x:1632,y:978,t:1526930024202};\\\", \\\"{x:1632,y:977,t:1526930024337};\\\", \\\"{x:1631,y:977,t:1526930024351};\\\", \\\"{x:1630,y:976,t:1526930024368};\\\", \\\"{x:1628,y:973,t:1526930024385};\\\", \\\"{x:1627,y:971,t:1526930024401};\\\", \\\"{x:1626,y:968,t:1526930024418};\\\", \\\"{x:1624,y:962,t:1526930024435};\\\", \\\"{x:1622,y:960,t:1526930024451};\\\", \\\"{x:1621,y:957,t:1526930024468};\\\", \\\"{x:1620,y:955,t:1526930024485};\\\", \\\"{x:1619,y:955,t:1526930024502};\\\", \\\"{x:1619,y:954,t:1526930024593};\\\", \\\"{x:1618,y:953,t:1526930024602};\\\", \\\"{x:1617,y:950,t:1526930024618};\\\", \\\"{x:1613,y:943,t:1526930024635};\\\", \\\"{x:1612,y:937,t:1526930024651};\\\", \\\"{x:1605,y:928,t:1526930024669};\\\", \\\"{x:1600,y:921,t:1526930024685};\\\", \\\"{x:1597,y:918,t:1526930024702};\\\", \\\"{x:1593,y:913,t:1526930024718};\\\", \\\"{x:1589,y:909,t:1526930024735};\\\", \\\"{x:1584,y:905,t:1526930024752};\\\", \\\"{x:1582,y:902,t:1526930024768};\\\", \\\"{x:1581,y:900,t:1526930024785};\\\", \\\"{x:1577,y:895,t:1526930024801};\\\", \\\"{x:1576,y:892,t:1526930024818};\\\", \\\"{x:1572,y:887,t:1526930024835};\\\", \\\"{x:1568,y:878,t:1526930024852};\\\", \\\"{x:1562,y:864,t:1526930024868};\\\", \\\"{x:1554,y:852,t:1526930024885};\\\", \\\"{x:1541,y:836,t:1526930024902};\\\", \\\"{x:1531,y:824,t:1526930024918};\\\", \\\"{x:1522,y:814,t:1526930024935};\\\", \\\"{x:1512,y:804,t:1526930024952};\\\", \\\"{x:1510,y:801,t:1526930024968};\\\", \\\"{x:1508,y:798,t:1526930024985};\\\", \\\"{x:1506,y:795,t:1526930025002};\\\", \\\"{x:1505,y:793,t:1526930025018};\\\", \\\"{x:1505,y:792,t:1526930025035};\\\", \\\"{x:1505,y:788,t:1526930025052};\\\", \\\"{x:1502,y:783,t:1526930025068};\\\", \\\"{x:1498,y:774,t:1526930025084};\\\", \\\"{x:1495,y:766,t:1526930025101};\\\", \\\"{x:1489,y:755,t:1526930025119};\\\", \\\"{x:1482,y:744,t:1526930025135};\\\", \\\"{x:1473,y:727,t:1526930025152};\\\", \\\"{x:1468,y:714,t:1526930025168};\\\", \\\"{x:1463,y:702,t:1526930025185};\\\", \\\"{x:1460,y:688,t:1526930025202};\\\", \\\"{x:1457,y:672,t:1526930025219};\\\", \\\"{x:1453,y:658,t:1526930025235};\\\", \\\"{x:1449,y:644,t:1526930025252};\\\", \\\"{x:1446,y:631,t:1526930025269};\\\", \\\"{x:1440,y:615,t:1526930025285};\\\", \\\"{x:1432,y:595,t:1526930025302};\\\", \\\"{x:1427,y:579,t:1526930025319};\\\", \\\"{x:1421,y:565,t:1526930025335};\\\", \\\"{x:1415,y:551,t:1526930025353};\\\", \\\"{x:1412,y:544,t:1526930025369};\\\", \\\"{x:1411,y:542,t:1526930025386};\\\", \\\"{x:1411,y:541,t:1526930025402};\\\", \\\"{x:1409,y:542,t:1526930025577};\\\", \\\"{x:1409,y:545,t:1526930025586};\\\", \\\"{x:1408,y:549,t:1526930025603};\\\", \\\"{x:1406,y:558,t:1526930025619};\\\", \\\"{x:1403,y:563,t:1526930025637};\\\", \\\"{x:1395,y:568,t:1526930025653};\\\", \\\"{x:1379,y:572,t:1526930025670};\\\", \\\"{x:1354,y:576,t:1526930025687};\\\", \\\"{x:1321,y:576,t:1526930025703};\\\", \\\"{x:1257,y:576,t:1526930025720};\\\", \\\"{x:1137,y:576,t:1526930025737};\\\", \\\"{x:1062,y:576,t:1526930025754};\\\", \\\"{x:1007,y:576,t:1526930025770};\\\", \\\"{x:954,y:576,t:1526930025786};\\\", \\\"{x:926,y:577,t:1526930025803};\\\", \\\"{x:903,y:581,t:1526930025819};\\\", \\\"{x:891,y:583,t:1526930025837};\\\", \\\"{x:885,y:588,t:1526930025853};\\\", \\\"{x:880,y:591,t:1526930025868};\\\", \\\"{x:875,y:591,t:1526930025885};\\\", \\\"{x:872,y:594,t:1526930025901};\\\", \\\"{x:863,y:595,t:1526930025918};\\\", \\\"{x:847,y:596,t:1526930025934};\\\", \\\"{x:819,y:596,t:1526930025952};\\\", \\\"{x:765,y:596,t:1526930025968};\\\", \\\"{x:739,y:596,t:1526930025985};\\\", \\\"{x:732,y:596,t:1526930026002};\\\", \\\"{x:729,y:599,t:1526930026018};\\\", \\\"{x:725,y:601,t:1526930026035};\\\", \\\"{x:723,y:602,t:1526930026053};\\\", \\\"{x:717,y:603,t:1526930026068};\\\", \\\"{x:709,y:603,t:1526930026084};\\\", \\\"{x:694,y:594,t:1526930026102};\\\", \\\"{x:673,y:585,t:1526930026119};\\\", \\\"{x:652,y:576,t:1526930026135};\\\", \\\"{x:627,y:567,t:1526930026153};\\\", \\\"{x:612,y:566,t:1526930026168};\\\", \\\"{x:597,y:566,t:1526930026185};\\\", \\\"{x:584,y:566,t:1526930026202};\\\", \\\"{x:575,y:566,t:1526930026218};\\\", \\\"{x:574,y:566,t:1526930026337};\\\", \\\"{x:573,y:566,t:1526930026353};\\\", \\\"{x:573,y:567,t:1526930026418};\\\", \\\"{x:571,y:566,t:1526930026681};\\\", \\\"{x:566,y:558,t:1526930026688};\\\", \\\"{x:563,y:548,t:1526930026705};\\\", \\\"{x:563,y:539,t:1526930026721};\\\", \\\"{x:563,y:537,t:1526930026737};\\\", \\\"{x:563,y:536,t:1526930026753};\\\", \\\"{x:563,y:535,t:1526930026769};\\\", \\\"{x:563,y:534,t:1526930026785};\\\", \\\"{x:566,y:531,t:1526930026802};\\\", \\\"{x:568,y:531,t:1526930026819};\\\", \\\"{x:569,y:530,t:1526930026836};\\\", \\\"{x:571,y:530,t:1526930026857};\\\", \\\"{x:574,y:530,t:1526930026869};\\\", \\\"{x:586,y:535,t:1526930026887};\\\", \\\"{x:606,y:543,t:1526930026903};\\\", \\\"{x:615,y:546,t:1526930026919};\\\", \\\"{x:633,y:551,t:1526930026936};\\\", \\\"{x:644,y:553,t:1526930026952};\\\", \\\"{x:648,y:554,t:1526930026969};\\\", \\\"{x:649,y:555,t:1526930026986};\\\", \\\"{x:650,y:555,t:1526930027002};\\\", \\\"{x:650,y:557,t:1526930027032};\\\", \\\"{x:650,y:560,t:1526930027040};\\\", \\\"{x:645,y:562,t:1526930027051};\\\", \\\"{x:637,y:567,t:1526930027070};\\\", \\\"{x:630,y:570,t:1526930027085};\\\", \\\"{x:628,y:571,t:1526930027103};\\\", \\\"{x:627,y:571,t:1526930027120};\\\", \\\"{x:623,y:571,t:1526930027136};\\\", \\\"{x:616,y:570,t:1526930027153};\\\", \\\"{x:608,y:566,t:1526930027169};\\\", \\\"{x:603,y:565,t:1526930027186};\\\", \\\"{x:601,y:564,t:1526930027203};\\\", \\\"{x:601,y:563,t:1526930027220};\\\", \\\"{x:602,y:563,t:1526930027688};\\\", \\\"{x:607,y:563,t:1526930027703};\\\", \\\"{x:629,y:563,t:1526930027724};\\\", \\\"{x:646,y:561,t:1526930027736};\\\", \\\"{x:664,y:559,t:1526930027753};\\\", \\\"{x:677,y:556,t:1526930027770};\\\", \\\"{x:693,y:555,t:1526930027786};\\\", \\\"{x:711,y:555,t:1526930027803};\\\", \\\"{x:728,y:555,t:1526930027821};\\\", \\\"{x:741,y:555,t:1526930027836};\\\", \\\"{x:755,y:559,t:1526930027853};\\\", \\\"{x:770,y:564,t:1526930027870};\\\", \\\"{x:786,y:568,t:1526930027887};\\\", \\\"{x:804,y:571,t:1526930027903};\\\", \\\"{x:832,y:574,t:1526930027920};\\\", \\\"{x:842,y:576,t:1526930027937};\\\", \\\"{x:845,y:576,t:1526930027952};\\\", \\\"{x:843,y:576,t:1526930028081};\\\", \\\"{x:839,y:578,t:1526930028088};\\\", \\\"{x:832,y:578,t:1526930028103};\\\", \\\"{x:814,y:578,t:1526930028120};\\\", \\\"{x:800,y:576,t:1526930028137};\\\", \\\"{x:789,y:571,t:1526930028153};\\\", \\\"{x:778,y:567,t:1526930028170};\\\", \\\"{x:770,y:563,t:1526930028187};\\\", \\\"{x:767,y:562,t:1526930028203};\\\", \\\"{x:766,y:561,t:1526930028273};\\\", \\\"{x:765,y:559,t:1526930028312};\\\", \\\"{x:763,y:556,t:1526930028320};\\\", \\\"{x:755,y:547,t:1526930028337};\\\", \\\"{x:736,y:539,t:1526930028355};\\\", \\\"{x:719,y:529,t:1526930028370};\\\", \\\"{x:683,y:515,t:1526930028387};\\\", \\\"{x:656,y:503,t:1526930028405};\\\", \\\"{x:639,y:497,t:1526930028419};\\\", \\\"{x:632,y:494,t:1526930028437};\\\", \\\"{x:631,y:494,t:1526930028453};\\\", \\\"{x:631,y:497,t:1526930028561};\\\", \\\"{x:631,y:501,t:1526930028570};\\\", \\\"{x:634,y:508,t:1526930028587};\\\", \\\"{x:638,y:516,t:1526930028603};\\\", \\\"{x:638,y:522,t:1526930028621};\\\", \\\"{x:638,y:528,t:1526930028637};\\\", \\\"{x:638,y:535,t:1526930028655};\\\", \\\"{x:638,y:538,t:1526930028672};\\\", \\\"{x:637,y:539,t:1526930028687};\\\", \\\"{x:632,y:542,t:1526930028704};\\\", \\\"{x:631,y:542,t:1526930028720};\\\", \\\"{x:629,y:542,t:1526930028737};\\\", \\\"{x:626,y:542,t:1526930028755};\\\", \\\"{x:626,y:541,t:1526930028777};\\\", \\\"{x:625,y:540,t:1526930028801};\\\", \\\"{x:624,y:539,t:1526930028809};\\\", \\\"{x:624,y:538,t:1526930028821};\\\", \\\"{x:623,y:536,t:1526930028838};\\\", \\\"{x:622,y:534,t:1526930028854};\\\", \\\"{x:619,y:532,t:1526930028871};\\\", \\\"{x:618,y:531,t:1526930028888};\\\", \\\"{x:618,y:530,t:1526930028903};\\\", \\\"{x:616,y:529,t:1526930028928};\\\", \\\"{x:617,y:530,t:1526930029712};\\\", \\\"{x:622,y:532,t:1526930029721};\\\", \\\"{x:637,y:536,t:1526930029739};\\\", \\\"{x:659,y:540,t:1526930029755};\\\", \\\"{x:685,y:542,t:1526930029771};\\\", \\\"{x:709,y:542,t:1526930029788};\\\", \\\"{x:737,y:545,t:1526930029806};\\\", \\\"{x:778,y:554,t:1526930029821};\\\", \\\"{x:842,y:573,t:1526930029838};\\\", \\\"{x:928,y:602,t:1526930029856};\\\", \\\"{x:1016,y:635,t:1526930029872};\\\", \\\"{x:1158,y:699,t:1526930029888};\\\", \\\"{x:1255,y:742,t:1526930029905};\\\", \\\"{x:1338,y:780,t:1526930029921};\\\", \\\"{x:1425,y:826,t:1526930029939};\\\", \\\"{x:1490,y:862,t:1526930029955};\\\", \\\"{x:1548,y:887,t:1526930029972};\\\", \\\"{x:1601,y:912,t:1526930029988};\\\", \\\"{x:1626,y:926,t:1526930030005};\\\", \\\"{x:1645,y:941,t:1526930030022};\\\", \\\"{x:1655,y:951,t:1526930030038};\\\", \\\"{x:1660,y:962,t:1526930030056};\\\", \\\"{x:1670,y:982,t:1526930030071};\\\", \\\"{x:1682,y:1013,t:1526930030088};\\\", \\\"{x:1688,y:1026,t:1526930030105};\\\", \\\"{x:1690,y:1029,t:1526930030121};\\\", \\\"{x:1690,y:1030,t:1526930030273};\\\", \\\"{x:1689,y:1030,t:1526930030297};\\\", \\\"{x:1688,y:1030,t:1526930030305};\\\", \\\"{x:1685,y:1030,t:1526930030323};\\\", \\\"{x:1678,y:1029,t:1526930030338};\\\", \\\"{x:1670,y:1027,t:1526930030356};\\\", \\\"{x:1667,y:1024,t:1526930030373};\\\", \\\"{x:1663,y:1020,t:1526930030388};\\\", \\\"{x:1657,y:1015,t:1526930030406};\\\", \\\"{x:1650,y:1010,t:1526930030422};\\\", \\\"{x:1639,y:1005,t:1526930030438};\\\", \\\"{x:1628,y:1002,t:1526930030455};\\\", \\\"{x:1610,y:999,t:1526930030472};\\\", \\\"{x:1604,y:999,t:1526930030488};\\\", \\\"{x:1601,y:999,t:1526930030505};\\\", \\\"{x:1600,y:999,t:1526930030569};\\\", \\\"{x:1600,y:998,t:1526930030584};\\\", \\\"{x:1599,y:997,t:1526930030592};\\\", \\\"{x:1599,y:996,t:1526930030605};\\\", \\\"{x:1597,y:991,t:1526930030623};\\\", \\\"{x:1596,y:989,t:1526930030639};\\\", \\\"{x:1596,y:988,t:1526930030656};\\\", \\\"{x:1596,y:986,t:1526930030762};\\\", \\\"{x:1596,y:984,t:1526930030773};\\\", \\\"{x:1603,y:979,t:1526930030789};\\\", \\\"{x:1611,y:971,t:1526930030805};\\\", \\\"{x:1617,y:966,t:1526930030823};\\\", \\\"{x:1620,y:962,t:1526930030840};\\\", \\\"{x:1622,y:961,t:1526930030856};\\\", \\\"{x:1623,y:960,t:1526930030873};\\\", \\\"{x:1622,y:960,t:1526930031234};\\\", \\\"{x:1622,y:957,t:1526930031240};\\\", \\\"{x:1622,y:955,t:1526930031257};\\\", \\\"{x:1622,y:954,t:1526930031272};\\\", \\\"{x:1622,y:952,t:1526930031434};\\\", \\\"{x:1621,y:949,t:1526930031441};\\\", \\\"{x:1617,y:946,t:1526930031458};\\\", \\\"{x:1612,y:943,t:1526930031473};\\\", \\\"{x:1602,y:940,t:1526930031490};\\\", \\\"{x:1595,y:939,t:1526930031507};\\\", \\\"{x:1586,y:938,t:1526930031523};\\\", \\\"{x:1581,y:938,t:1526930031540};\\\", \\\"{x:1577,y:938,t:1526930031557};\\\", \\\"{x:1576,y:938,t:1526930031573};\\\", \\\"{x:1577,y:938,t:1526930031689};\\\", \\\"{x:1580,y:938,t:1526930031707};\\\", \\\"{x:1582,y:940,t:1526930031723};\\\", \\\"{x:1583,y:943,t:1526930031740};\\\", \\\"{x:1586,y:945,t:1526930031756};\\\", \\\"{x:1586,y:948,t:1526930031773};\\\", \\\"{x:1587,y:949,t:1526930031790};\\\", \\\"{x:1587,y:948,t:1526930031874};\\\", \\\"{x:1587,y:942,t:1526930031890};\\\", \\\"{x:1587,y:939,t:1526930031907};\\\", \\\"{x:1587,y:934,t:1526930031923};\\\", \\\"{x:1585,y:930,t:1526930031941};\\\", \\\"{x:1582,y:925,t:1526930031957};\\\", \\\"{x:1580,y:922,t:1526930031973};\\\", \\\"{x:1576,y:916,t:1526930031990};\\\", \\\"{x:1573,y:911,t:1526930032007};\\\", \\\"{x:1570,y:902,t:1526930032023};\\\", \\\"{x:1567,y:893,t:1526930032040};\\\", \\\"{x:1559,y:875,t:1526930032057};\\\", \\\"{x:1553,y:861,t:1526930032073};\\\", \\\"{x:1549,y:850,t:1526930032090};\\\", \\\"{x:1544,y:841,t:1526930032107};\\\", \\\"{x:1541,y:834,t:1526930032124};\\\", \\\"{x:1539,y:831,t:1526930032140};\\\", \\\"{x:1537,y:824,t:1526930032157};\\\", \\\"{x:1537,y:821,t:1526930032174};\\\", \\\"{x:1536,y:819,t:1526930032190};\\\", \\\"{x:1536,y:818,t:1526930032206};\\\", \\\"{x:1536,y:816,t:1526930032224};\\\", \\\"{x:1536,y:814,t:1526930032239};\\\", \\\"{x:1536,y:810,t:1526930032256};\\\", \\\"{x:1536,y:806,t:1526930032273};\\\", \\\"{x:1536,y:802,t:1526930032290};\\\", \\\"{x:1536,y:800,t:1526930032306};\\\", \\\"{x:1537,y:797,t:1526930032323};\\\", \\\"{x:1537,y:796,t:1526930032340};\\\", \\\"{x:1537,y:793,t:1526930032357};\\\", \\\"{x:1537,y:792,t:1526930032374};\\\", \\\"{x:1537,y:790,t:1526930032389};\\\", \\\"{x:1538,y:786,t:1526930032407};\\\", \\\"{x:1539,y:783,t:1526930032424};\\\", \\\"{x:1540,y:780,t:1526930032440};\\\", \\\"{x:1541,y:774,t:1526930032457};\\\", \\\"{x:1541,y:771,t:1526930032474};\\\", \\\"{x:1542,y:768,t:1526930032489};\\\", \\\"{x:1543,y:766,t:1526930032507};\\\", \\\"{x:1543,y:765,t:1526930032524};\\\", \\\"{x:1543,y:764,t:1526930032642};\\\", \\\"{x:1549,y:765,t:1526930032657};\\\", \\\"{x:1555,y:771,t:1526930032674};\\\", \\\"{x:1562,y:778,t:1526930032690};\\\", \\\"{x:1570,y:788,t:1526930032707};\\\", \\\"{x:1582,y:797,t:1526930032724};\\\", \\\"{x:1593,y:814,t:1526930032741};\\\", \\\"{x:1602,y:828,t:1526930032757};\\\", \\\"{x:1612,y:847,t:1526930032773};\\\", \\\"{x:1618,y:863,t:1526930032790};\\\", \\\"{x:1623,y:878,t:1526930032806};\\\", \\\"{x:1625,y:886,t:1526930032823};\\\", \\\"{x:1627,y:893,t:1526930032840};\\\", \\\"{x:1627,y:897,t:1526930032856};\\\", \\\"{x:1627,y:899,t:1526930032873};\\\", \\\"{x:1626,y:904,t:1526930032890};\\\", \\\"{x:1624,y:911,t:1526930032906};\\\", \\\"{x:1619,y:922,t:1526930032923};\\\", \\\"{x:1612,y:934,t:1526930032940};\\\", \\\"{x:1603,y:947,t:1526930032956};\\\", \\\"{x:1601,y:950,t:1526930032973};\\\", \\\"{x:1600,y:953,t:1526930032990};\\\", \\\"{x:1600,y:956,t:1526930033006};\\\", \\\"{x:1600,y:959,t:1526930033023};\\\", \\\"{x:1600,y:963,t:1526930033040};\\\", \\\"{x:1600,y:966,t:1526930033057};\\\", \\\"{x:1601,y:966,t:1526930033266};\\\", \\\"{x:1602,y:965,t:1526930033274};\\\", \\\"{x:1604,y:957,t:1526930033291};\\\", \\\"{x:1606,y:951,t:1526930033307};\\\", \\\"{x:1606,y:949,t:1526930033325};\\\", \\\"{x:1606,y:947,t:1526930033341};\\\", \\\"{x:1606,y:944,t:1526930033358};\\\", \\\"{x:1606,y:942,t:1526930033374};\\\", \\\"{x:1604,y:941,t:1526930033391};\\\", \\\"{x:1604,y:940,t:1526930033408};\\\", \\\"{x:1603,y:938,t:1526930033424};\\\", \\\"{x:1603,y:934,t:1526930033441};\\\", \\\"{x:1602,y:929,t:1526930033458};\\\", \\\"{x:1600,y:922,t:1526930033474};\\\", \\\"{x:1599,y:913,t:1526930033491};\\\", \\\"{x:1597,y:904,t:1526930033508};\\\", \\\"{x:1595,y:895,t:1526930033524};\\\", \\\"{x:1591,y:888,t:1526930033541};\\\", \\\"{x:1589,y:882,t:1526930033558};\\\", \\\"{x:1586,y:878,t:1526930033574};\\\", \\\"{x:1583,y:873,t:1526930033591};\\\", \\\"{x:1582,y:867,t:1526930033609};\\\", \\\"{x:1579,y:860,t:1526930033624};\\\", \\\"{x:1578,y:852,t:1526930033642};\\\", \\\"{x:1575,y:847,t:1526930033658};\\\", \\\"{x:1575,y:840,t:1526930033674};\\\", \\\"{x:1570,y:830,t:1526930033691};\\\", \\\"{x:1563,y:817,t:1526930033709};\\\", \\\"{x:1555,y:803,t:1526930033724};\\\", \\\"{x:1549,y:794,t:1526930033741};\\\", \\\"{x:1543,y:785,t:1526930033758};\\\", \\\"{x:1538,y:776,t:1526930033774};\\\", \\\"{x:1531,y:766,t:1526930033791};\\\", \\\"{x:1530,y:762,t:1526930033808};\\\", \\\"{x:1529,y:758,t:1526930033825};\\\", \\\"{x:1527,y:756,t:1526930033841};\\\", \\\"{x:1526,y:752,t:1526930033858};\\\", \\\"{x:1526,y:749,t:1526930033874};\\\", \\\"{x:1523,y:742,t:1526930033891};\\\", \\\"{x:1520,y:736,t:1526930033908};\\\", \\\"{x:1515,y:728,t:1526930033924};\\\", \\\"{x:1512,y:722,t:1526930033941};\\\", \\\"{x:1506,y:713,t:1526930033958};\\\", \\\"{x:1497,y:703,t:1526930033974};\\\", \\\"{x:1487,y:692,t:1526930033991};\\\", \\\"{x:1477,y:682,t:1526930034008};\\\", \\\"{x:1465,y:673,t:1526930034025};\\\", \\\"{x:1462,y:669,t:1526930034041};\\\", \\\"{x:1458,y:666,t:1526930034058};\\\", \\\"{x:1454,y:660,t:1526930034076};\\\", \\\"{x:1449,y:653,t:1526930034091};\\\", \\\"{x:1446,y:646,t:1526930034108};\\\", \\\"{x:1442,y:641,t:1526930034125};\\\", \\\"{x:1439,y:636,t:1526930034141};\\\", \\\"{x:1436,y:633,t:1526930034158};\\\", \\\"{x:1433,y:628,t:1526930034175};\\\", \\\"{x:1431,y:622,t:1526930034191};\\\", \\\"{x:1428,y:615,t:1526930034208};\\\", \\\"{x:1426,y:607,t:1526930034225};\\\", \\\"{x:1424,y:603,t:1526930034241};\\\", \\\"{x:1421,y:599,t:1526930034258};\\\", \\\"{x:1419,y:595,t:1526930034275};\\\", \\\"{x:1415,y:589,t:1526930034290};\\\", \\\"{x:1412,y:584,t:1526930034307};\\\", \\\"{x:1410,y:580,t:1526930034325};\\\", \\\"{x:1409,y:576,t:1526930034340};\\\", \\\"{x:1407,y:574,t:1526930034357};\\\", \\\"{x:1407,y:573,t:1526930034505};\\\", \\\"{x:1403,y:572,t:1526930035585};\\\", \\\"{x:1388,y:572,t:1526930035593};\\\", \\\"{x:1325,y:581,t:1526930035609};\\\", \\\"{x:1217,y:595,t:1526930035625};\\\", \\\"{x:1074,y:625,t:1526930035642};\\\", \\\"{x:910,y:658,t:1526930035659};\\\", \\\"{x:769,y:702,t:1526930035676};\\\", \\\"{x:705,y:720,t:1526930035692};\\\", \\\"{x:701,y:720,t:1526930035709};\\\", \\\"{x:699,y:723,t:1526930035724};\\\", \\\"{x:699,y:726,t:1526930035741};\\\", \\\"{x:697,y:734,t:1526930035758};\\\", \\\"{x:694,y:744,t:1526930035775};\\\", \\\"{x:687,y:752,t:1526930035791};\\\", \\\"{x:674,y:765,t:1526930035808};\\\", \\\"{x:665,y:775,t:1526930035824};\\\", \\\"{x:655,y:783,t:1526930035841};\\\", \\\"{x:645,y:789,t:1526930035858};\\\", \\\"{x:637,y:792,t:1526930035875};\\\", \\\"{x:636,y:793,t:1526930035891};\\\", \\\"{x:634,y:793,t:1526930035909};\\\", \\\"{x:632,y:793,t:1526930035925};\\\", \\\"{x:631,y:792,t:1526930035941};\\\", \\\"{x:631,y:791,t:1526930035959};\\\", \\\"{x:631,y:788,t:1526930035975};\\\", \\\"{x:631,y:783,t:1526930035991};\\\", \\\"{x:630,y:777,t:1526930036008};\\\", \\\"{x:629,y:774,t:1526930036026};\\\", \\\"{x:626,y:772,t:1526930036041};\\\", \\\"{x:610,y:770,t:1526930036058};\\\", \\\"{x:591,y:770,t:1526930036075};\\\", \\\"{x:566,y:777,t:1526930036092};\\\", \\\"{x:534,y:780,t:1526930036109};\\\", \\\"{x:484,y:788,t:1526930036126};\\\", \\\"{x:431,y:794,t:1526930036142};\\\", \\\"{x:393,y:800,t:1526930036158};\\\", \\\"{x:373,y:802,t:1526930036176};\\\", \\\"{x:365,y:804,t:1526930036192};\\\", \\\"{x:366,y:804,t:1526930036216};\\\", \\\"{x:371,y:799,t:1526930036225};\\\", \\\"{x:380,y:790,t:1526930036242};\\\", \\\"{x:391,y:774,t:1526930036259};\\\", \\\"{x:396,y:762,t:1526930036275};\\\", \\\"{x:399,y:754,t:1526930036292};\\\", \\\"{x:400,y:750,t:1526930036309};\\\", \\\"{x:404,y:745,t:1526930036326};\\\", \\\"{x:418,y:737,t:1526930036341};\\\", \\\"{x:429,y:729,t:1526930036359};\\\", \\\"{x:435,y:726,t:1526930036376};\\\", \\\"{x:439,y:723,t:1526930036392};\\\", \\\"{x:443,y:721,t:1526930036408};\\\", \\\"{x:446,y:720,t:1526930036425};\\\", \\\"{x:451,y:716,t:1526930036442};\\\", \\\"{x:457,y:713,t:1526930036458};\\\", \\\"{x:459,y:713,t:1526930036478};\\\", \\\"{x:462,y:712,t:1526930036493};\\\", \\\"{x:466,y:711,t:1526930036510};\\\", \\\"{x:469,y:710,t:1526930036527};\\\" ] }, { \\\"rt\\\": 22755, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 9, \\\"time_elapsed\\\": 422168, \\\"internal_node_id\\\": \\\"0.0-5.0-4.0\\\", \\\"subject\\\": \\\"WKBNA\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 5, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"O\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-O -O -O -6\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:471,y:709,t:1526930039113};\\\", \\\"{x:472,y:709,t:1526930039130};\\\", \\\"{x:474,y:709,t:1526930039152};\\\", \\\"{x:476,y:709,t:1526930039169};\\\", \\\"{x:478,y:709,t:1526930039180};\\\", \\\"{x:480,y:709,t:1526930039201};\\\", \\\"{x:481,y:709,t:1526930039212};\\\", \\\"{x:482,y:709,t:1526930039230};\\\", \\\"{x:484,y:709,t:1526930039246};\\\", \\\"{x:488,y:709,t:1526930039263};\\\", \\\"{x:493,y:709,t:1526930039280};\\\", \\\"{x:497,y:707,t:1526930039295};\\\", \\\"{x:503,y:704,t:1526930039313};\\\", \\\"{x:505,y:702,t:1526930039330};\\\", \\\"{x:506,y:702,t:1526930039346};\\\", \\\"{x:507,y:702,t:1526930039376};\\\", \\\"{x:508,y:702,t:1526930039385};\\\", \\\"{x:509,y:702,t:1526930039396};\\\", \\\"{x:510,y:702,t:1526930039412};\\\", \\\"{x:513,y:702,t:1526930039430};\\\", \\\"{x:516,y:703,t:1526930039445};\\\", \\\"{x:517,y:703,t:1526930039462};\\\", \\\"{x:520,y:703,t:1526930039479};\\\", \\\"{x:525,y:703,t:1526930039495};\\\", \\\"{x:527,y:702,t:1526930039513};\\\", \\\"{x:528,y:702,t:1526930039530};\\\", \\\"{x:530,y:702,t:1526930039584};\\\", \\\"{x:531,y:702,t:1526930039624};\\\", \\\"{x:539,y:702,t:1526930040353};\\\", \\\"{x:548,y:702,t:1526930040364};\\\", \\\"{x:573,y:702,t:1526930040381};\\\", \\\"{x:620,y:709,t:1526930040396};\\\", \\\"{x:680,y:714,t:1526930040414};\\\", \\\"{x:772,y:730,t:1526930040430};\\\", \\\"{x:874,y:741,t:1526930040446};\\\", \\\"{x:997,y:743,t:1526930040464};\\\", \\\"{x:1191,y:747,t:1526930040480};\\\", \\\"{x:1310,y:749,t:1526930040496};\\\", \\\"{x:1360,y:749,t:1526930040516};\\\", \\\"{x:1477,y:749,t:1526930040531};\\\", \\\"{x:1514,y:751,t:1526930040546};\\\", \\\"{x:1540,y:751,t:1526930040564};\\\", \\\"{x:1551,y:751,t:1526930040580};\\\", \\\"{x:1554,y:751,t:1526930040597};\\\", \\\"{x:1555,y:751,t:1526930040614};\\\", \\\"{x:1550,y:751,t:1526930040802};\\\", \\\"{x:1541,y:748,t:1526930040814};\\\", \\\"{x:1517,y:739,t:1526930040832};\\\", \\\"{x:1492,y:734,t:1526930040848};\\\", \\\"{x:1458,y:728,t:1526930040864};\\\", \\\"{x:1399,y:717,t:1526930040881};\\\", \\\"{x:1364,y:714,t:1526930040897};\\\", \\\"{x:1353,y:711,t:1526930040914};\\\", \\\"{x:1352,y:711,t:1526930040931};\\\", \\\"{x:1352,y:708,t:1526930041329};\\\", \\\"{x:1354,y:701,t:1526930041337};\\\", \\\"{x:1358,y:699,t:1526930041348};\\\", \\\"{x:1367,y:690,t:1526930041364};\\\", \\\"{x:1378,y:684,t:1526930041382};\\\", \\\"{x:1386,y:682,t:1526930041398};\\\", \\\"{x:1391,y:680,t:1526930041414};\\\", \\\"{x:1394,y:680,t:1526930041431};\\\", \\\"{x:1395,y:680,t:1526930041449};\\\", \\\"{x:1397,y:680,t:1526930041465};\\\", \\\"{x:1398,y:680,t:1526930041481};\\\", \\\"{x:1400,y:680,t:1526930041513};\\\", \\\"{x:1402,y:680,t:1526930041529};\\\", \\\"{x:1402,y:679,t:1526930041537};\\\", \\\"{x:1403,y:678,t:1526930041548};\\\", \\\"{x:1405,y:677,t:1526930041566};\\\", \\\"{x:1403,y:675,t:1526930042473};\\\", \\\"{x:1397,y:670,t:1526930042483};\\\", \\\"{x:1377,y:659,t:1526930042500};\\\", \\\"{x:1358,y:648,t:1526930042515};\\\", \\\"{x:1345,y:639,t:1526930042532};\\\", \\\"{x:1326,y:628,t:1526930042549};\\\", \\\"{x:1311,y:618,t:1526930042565};\\\", \\\"{x:1300,y:610,t:1526930042583};\\\", \\\"{x:1290,y:601,t:1526930042599};\\\", \\\"{x:1282,y:592,t:1526930042615};\\\", \\\"{x:1278,y:587,t:1526930042632};\\\", \\\"{x:1277,y:582,t:1526930042649};\\\", \\\"{x:1277,y:581,t:1526930042665};\\\", \\\"{x:1277,y:579,t:1526930042689};\\\", \\\"{x:1278,y:577,t:1526930042699};\\\", \\\"{x:1282,y:572,t:1526930042714};\\\", \\\"{x:1287,y:565,t:1526930042732};\\\", \\\"{x:1292,y:558,t:1526930042749};\\\", \\\"{x:1300,y:547,t:1526930042764};\\\", \\\"{x:1307,y:538,t:1526930042781};\\\", \\\"{x:1314,y:529,t:1526930042798};\\\", \\\"{x:1316,y:524,t:1526930042815};\\\", \\\"{x:1318,y:521,t:1526930042832};\\\", \\\"{x:1319,y:519,t:1526930042848};\\\", \\\"{x:1319,y:518,t:1526930042969};\\\", \\\"{x:1319,y:517,t:1526930042983};\\\", \\\"{x:1319,y:516,t:1526930042999};\\\", \\\"{x:1319,y:513,t:1526930043017};\\\", \\\"{x:1319,y:512,t:1526930043032};\\\", \\\"{x:1318,y:511,t:1526930043049};\\\", \\\"{x:1318,y:510,t:1526930043081};\\\", \\\"{x:1318,y:509,t:1526930045745};\\\", \\\"{x:1318,y:508,t:1526930045864};\\\", \\\"{x:1318,y:507,t:1526930045880};\\\", \\\"{x:1318,y:505,t:1526930045896};\\\", \\\"{x:1317,y:508,t:1526930045985};\\\", \\\"{x:1315,y:513,t:1526930046001};\\\", \\\"{x:1314,y:517,t:1526930046018};\\\", \\\"{x:1314,y:518,t:1526930046034};\\\", \\\"{x:1314,y:519,t:1526930046051};\\\", \\\"{x:1313,y:519,t:1526930046265};\\\", \\\"{x:1313,y:518,t:1526930046273};\\\", \\\"{x:1313,y:516,t:1526930046286};\\\", \\\"{x:1313,y:513,t:1526930046301};\\\", \\\"{x:1313,y:512,t:1526930046319};\\\", \\\"{x:1313,y:510,t:1526930046336};\\\", \\\"{x:1313,y:509,t:1526930046351};\\\", \\\"{x:1313,y:508,t:1526930046537};\\\", \\\"{x:1313,y:507,t:1526930046713};\\\", \\\"{x:1313,y:506,t:1526930046729};\\\", \\\"{x:1313,y:504,t:1526930046737};\\\", \\\"{x:1313,y:506,t:1526930047641};\\\", \\\"{x:1313,y:507,t:1526930047653};\\\", \\\"{x:1313,y:510,t:1526930047669};\\\", \\\"{x:1313,y:512,t:1526930047687};\\\", \\\"{x:1313,y:513,t:1526930047702};\\\", \\\"{x:1313,y:515,t:1526930047719};\\\", \\\"{x:1313,y:518,t:1526930047736};\\\", \\\"{x:1313,y:523,t:1526930047752};\\\", \\\"{x:1311,y:527,t:1526930047769};\\\", \\\"{x:1311,y:532,t:1526930047786};\\\", \\\"{x:1310,y:543,t:1526930047802};\\\", \\\"{x:1310,y:555,t:1526930047819};\\\", \\\"{x:1309,y:573,t:1526930047836};\\\", \\\"{x:1306,y:589,t:1526930047852};\\\", \\\"{x:1306,y:600,t:1526930047869};\\\", \\\"{x:1306,y:609,t:1526930047886};\\\", \\\"{x:1306,y:613,t:1526930047903};\\\", \\\"{x:1306,y:616,t:1526930047920};\\\", \\\"{x:1306,y:619,t:1526930047936};\\\", \\\"{x:1306,y:625,t:1526930047952};\\\", \\\"{x:1307,y:632,t:1526930047969};\\\", \\\"{x:1307,y:637,t:1526930047986};\\\", \\\"{x:1308,y:642,t:1526930048002};\\\", \\\"{x:1309,y:647,t:1526930048019};\\\", \\\"{x:1310,y:653,t:1526930048036};\\\", \\\"{x:1312,y:659,t:1526930048052};\\\", \\\"{x:1314,y:665,t:1526930048069};\\\", \\\"{x:1314,y:666,t:1526930048086};\\\", \\\"{x:1315,y:667,t:1526930048102};\\\", \\\"{x:1315,y:668,t:1526930048250};\\\", \\\"{x:1315,y:669,t:1526930048257};\\\", \\\"{x:1315,y:671,t:1526930048269};\\\", \\\"{x:1315,y:672,t:1526930048286};\\\", \\\"{x:1316,y:672,t:1526930048305};\\\", \\\"{x:1316,y:673,t:1526930048409};\\\", \\\"{x:1317,y:674,t:1526930048420};\\\", \\\"{x:1317,y:679,t:1526930048437};\\\", \\\"{x:1318,y:683,t:1526930048454};\\\", \\\"{x:1318,y:686,t:1526930048470};\\\", \\\"{x:1318,y:688,t:1526930048486};\\\", \\\"{x:1319,y:688,t:1526930048504};\\\", \\\"{x:1320,y:688,t:1526930048753};\\\", \\\"{x:1320,y:683,t:1526930048770};\\\", \\\"{x:1319,y:676,t:1526930048787};\\\", \\\"{x:1319,y:673,t:1526930048803};\\\", \\\"{x:1319,y:671,t:1526930048821};\\\", \\\"{x:1318,y:669,t:1526930048837};\\\", \\\"{x:1318,y:668,t:1526930048853};\\\", \\\"{x:1317,y:667,t:1526930048896};\\\", \\\"{x:1317,y:666,t:1526930048904};\\\", \\\"{x:1317,y:663,t:1526930048920};\\\", \\\"{x:1317,y:657,t:1526930048936};\\\", \\\"{x:1315,y:649,t:1526930048953};\\\", \\\"{x:1315,y:644,t:1526930048970};\\\", \\\"{x:1314,y:643,t:1526930048986};\\\", \\\"{x:1313,y:642,t:1526930049003};\\\", \\\"{x:1313,y:641,t:1526930049113};\\\", \\\"{x:1313,y:639,t:1526930049129};\\\", \\\"{x:1313,y:638,t:1526930049137};\\\", \\\"{x:1313,y:636,t:1526930049154};\\\", \\\"{x:1313,y:635,t:1526930049171};\\\", \\\"{x:1313,y:634,t:1526930049187};\\\", \\\"{x:1314,y:632,t:1526930050153};\\\", \\\"{x:1315,y:632,t:1526930050161};\\\", \\\"{x:1317,y:632,t:1526930050184};\\\", \\\"{x:1318,y:631,t:1526930050217};\\\", \\\"{x:1319,y:631,t:1526930051321};\\\", \\\"{x:1319,y:635,t:1526930051340};\\\", \\\"{x:1319,y:637,t:1526930051355};\\\", \\\"{x:1319,y:638,t:1526930051372};\\\", \\\"{x:1319,y:639,t:1526930051425};\\\", \\\"{x:1319,y:640,t:1526930051465};\\\", \\\"{x:1319,y:641,t:1526930051481};\\\", \\\"{x:1319,y:642,t:1526930051489};\\\", \\\"{x:1319,y:644,t:1526930051505};\\\", \\\"{x:1319,y:647,t:1526930051523};\\\", \\\"{x:1320,y:649,t:1526930051539};\\\", \\\"{x:1320,y:648,t:1526930051937};\\\", \\\"{x:1320,y:647,t:1526930051945};\\\", \\\"{x:1320,y:646,t:1526930051984};\\\", \\\"{x:1320,y:645,t:1526930052000};\\\", \\\"{x:1320,y:643,t:1526930052009};\\\", \\\"{x:1320,y:642,t:1526930052023};\\\", \\\"{x:1319,y:638,t:1526930052039};\\\", \\\"{x:1319,y:636,t:1526930052056};\\\", \\\"{x:1318,y:633,t:1526930052073};\\\", \\\"{x:1318,y:634,t:1526930052577};\\\", \\\"{x:1318,y:635,t:1526930052590};\\\", \\\"{x:1318,y:638,t:1526930052953};\\\", \\\"{x:1318,y:641,t:1526930052960};\\\", \\\"{x:1318,y:643,t:1526930052973};\\\", \\\"{x:1318,y:650,t:1526930052989};\\\", \\\"{x:1318,y:656,t:1526930053006};\\\", \\\"{x:1318,y:660,t:1526930053023};\\\", \\\"{x:1318,y:664,t:1526930053039};\\\", \\\"{x:1319,y:668,t:1526930053056};\\\", \\\"{x:1319,y:672,t:1526930053073};\\\", \\\"{x:1320,y:678,t:1526930053089};\\\", \\\"{x:1320,y:684,t:1526930053107};\\\", \\\"{x:1321,y:689,t:1526930053123};\\\", \\\"{x:1323,y:694,t:1526930053139};\\\", \\\"{x:1324,y:701,t:1526930053156};\\\", \\\"{x:1324,y:706,t:1526930053173};\\\", \\\"{x:1325,y:713,t:1526930053190};\\\", \\\"{x:1326,y:717,t:1526930053207};\\\", \\\"{x:1327,y:721,t:1526930053224};\\\", \\\"{x:1328,y:723,t:1526930053240};\\\", \\\"{x:1329,y:725,t:1526930053257};\\\", \\\"{x:1329,y:726,t:1526930053274};\\\", \\\"{x:1329,y:730,t:1526930053290};\\\", \\\"{x:1329,y:732,t:1526930053306};\\\", \\\"{x:1330,y:737,t:1526930053324};\\\", \\\"{x:1330,y:742,t:1526930053340};\\\", \\\"{x:1330,y:748,t:1526930053356};\\\", \\\"{x:1330,y:754,t:1526930053374};\\\", \\\"{x:1330,y:758,t:1526930053390};\\\", \\\"{x:1331,y:762,t:1526930053406};\\\", \\\"{x:1331,y:764,t:1526930053423};\\\", \\\"{x:1331,y:766,t:1526930053441};\\\", \\\"{x:1331,y:767,t:1526930053457};\\\", \\\"{x:1331,y:768,t:1526930053496};\\\", \\\"{x:1331,y:769,t:1526930053507};\\\", \\\"{x:1331,y:770,t:1526930053524};\\\", \\\"{x:1331,y:774,t:1526930053540};\\\", \\\"{x:1331,y:778,t:1526930053557};\\\", \\\"{x:1331,y:783,t:1526930053574};\\\", \\\"{x:1331,y:788,t:1526930053591};\\\", \\\"{x:1331,y:792,t:1526930053607};\\\", \\\"{x:1331,y:795,t:1526930053623};\\\", \\\"{x:1331,y:799,t:1526930053641};\\\", \\\"{x:1331,y:802,t:1526930053657};\\\", \\\"{x:1331,y:804,t:1526930053674};\\\", \\\"{x:1331,y:808,t:1526930053691};\\\", \\\"{x:1331,y:813,t:1526930053707};\\\", \\\"{x:1331,y:820,t:1526930053724};\\\", \\\"{x:1330,y:827,t:1526930053741};\\\", \\\"{x:1326,y:839,t:1526930053756};\\\", \\\"{x:1321,y:852,t:1526930053774};\\\", \\\"{x:1309,y:865,t:1526930053791};\\\", \\\"{x:1285,y:879,t:1526930053807};\\\", \\\"{x:1237,y:893,t:1526930053824};\\\", \\\"{x:1124,y:909,t:1526930053840};\\\", \\\"{x:1049,y:908,t:1526930053857};\\\", \\\"{x:945,y:886,t:1526930053874};\\\", \\\"{x:842,y:856,t:1526930053891};\\\", \\\"{x:739,y:821,t:1526930053908};\\\", \\\"{x:673,y:795,t:1526930053923};\\\", \\\"{x:651,y:774,t:1526930053941};\\\", \\\"{x:648,y:771,t:1526930053957};\\\", \\\"{x:646,y:768,t:1526930053973};\\\", \\\"{x:641,y:760,t:1526930053991};\\\", \\\"{x:631,y:743,t:1526930054007};\\\", \\\"{x:607,y:719,t:1526930054024};\\\", \\\"{x:543,y:678,t:1526930054041};\\\", \\\"{x:508,y:659,t:1526930054059};\\\", \\\"{x:473,y:645,t:1526930054074};\\\", \\\"{x:445,y:634,t:1526930054090};\\\", \\\"{x:413,y:626,t:1526930054107};\\\", \\\"{x:385,y:615,t:1526930054123};\\\", \\\"{x:378,y:611,t:1526930054142};\\\", \\\"{x:377,y:611,t:1526930054158};\\\", \\\"{x:380,y:611,t:1526930054304};\\\", \\\"{x:384,y:611,t:1526930054312};\\\", \\\"{x:388,y:610,t:1526930054325};\\\", \\\"{x:400,y:609,t:1526930054342};\\\", \\\"{x:417,y:606,t:1526930054360};\\\", \\\"{x:425,y:605,t:1526930054376};\\\", \\\"{x:442,y:605,t:1526930054392};\\\", \\\"{x:449,y:605,t:1526930054409};\\\", \\\"{x:461,y:605,t:1526930054425};\\\", \\\"{x:484,y:605,t:1526930054442};\\\", \\\"{x:514,y:605,t:1526930054461};\\\", \\\"{x:556,y:599,t:1526930054475};\\\", \\\"{x:601,y:594,t:1526930054492};\\\", \\\"{x:657,y:586,t:1526930054510};\\\", \\\"{x:706,y:583,t:1526930054525};\\\", \\\"{x:749,y:578,t:1526930054542};\\\", \\\"{x:778,y:577,t:1526930054559};\\\", \\\"{x:801,y:577,t:1526930054575};\\\", \\\"{x:818,y:577,t:1526930054591};\\\", \\\"{x:822,y:578,t:1526930054609};\\\", \\\"{x:823,y:578,t:1526930054625};\\\", \\\"{x:824,y:578,t:1526930054648};\\\", \\\"{x:825,y:578,t:1526930054659};\\\", \\\"{x:827,y:578,t:1526930054676};\\\", \\\"{x:834,y:574,t:1526930054692};\\\", \\\"{x:838,y:569,t:1526930054710};\\\", \\\"{x:842,y:564,t:1526930054725};\\\", \\\"{x:846,y:558,t:1526930054742};\\\", \\\"{x:849,y:555,t:1526930054760};\\\", \\\"{x:851,y:554,t:1526930054775};\\\", \\\"{x:851,y:552,t:1526930054872};\\\", \\\"{x:851,y:550,t:1526930054881};\\\", \\\"{x:851,y:547,t:1526930054896};\\\", \\\"{x:851,y:545,t:1526930054909};\\\", \\\"{x:851,y:540,t:1526930054926};\\\", \\\"{x:851,y:539,t:1526930054942};\\\", \\\"{x:851,y:537,t:1526930054959};\\\", \\\"{x:851,y:534,t:1526930054975};\\\", \\\"{x:850,y:534,t:1526930054992};\\\", \\\"{x:850,y:533,t:1526930055009};\\\", \\\"{x:849,y:533,t:1526930055039};\\\", \\\"{x:848,y:532,t:1526930055112};\\\", \\\"{x:847,y:531,t:1526930055737};\\\", \\\"{x:846,y:531,t:1526930055744};\\\", \\\"{x:844,y:531,t:1526930055760};\\\", \\\"{x:842,y:531,t:1526930055776};\\\", \\\"{x:841,y:531,t:1526930055793};\\\", \\\"{x:840,y:532,t:1526930056137};\\\", \\\"{x:840,y:534,t:1526930056144};\\\", \\\"{x:846,y:542,t:1526930056161};\\\", \\\"{x:850,y:552,t:1526930056178};\\\", \\\"{x:856,y:560,t:1526930056194};\\\", \\\"{x:861,y:570,t:1526930056211};\\\", \\\"{x:868,y:582,t:1526930056227};\\\", \\\"{x:873,y:591,t:1526930056244};\\\", \\\"{x:877,y:597,t:1526930056261};\\\", \\\"{x:878,y:599,t:1526930056277};\\\", \\\"{x:879,y:600,t:1526930056293};\\\", \\\"{x:879,y:601,t:1526930056310};\\\", \\\"{x:881,y:601,t:1526930056352};\\\", \\\"{x:882,y:600,t:1526930056361};\\\", \\\"{x:890,y:596,t:1526930056376};\\\", \\\"{x:899,y:592,t:1526930056394};\\\", \\\"{x:910,y:588,t:1526930056410};\\\", \\\"{x:928,y:583,t:1526930056427};\\\", \\\"{x:951,y:581,t:1526930056445};\\\", \\\"{x:978,y:576,t:1526930056460};\\\", \\\"{x:1016,y:570,t:1526930056477};\\\", \\\"{x:1062,y:562,t:1526930056493};\\\", \\\"{x:1104,y:555,t:1526930056511};\\\", \\\"{x:1149,y:549,t:1526930056527};\\\", \\\"{x:1215,y:539,t:1526930056543};\\\", \\\"{x:1247,y:535,t:1526930056560};\\\", \\\"{x:1274,y:528,t:1526930056577};\\\", \\\"{x:1283,y:520,t:1526930056594};\\\", \\\"{x:1290,y:519,t:1526930056610};\\\", \\\"{x:1295,y:516,t:1526930056627};\\\", \\\"{x:1302,y:514,t:1526930056644};\\\", \\\"{x:1305,y:514,t:1526930056660};\\\", \\\"{x:1309,y:512,t:1526930056677};\\\", \\\"{x:1311,y:512,t:1526930056694};\\\", \\\"{x:1317,y:508,t:1526930056710};\\\", \\\"{x:1324,y:506,t:1526930056727};\\\", \\\"{x:1335,y:500,t:1526930056743};\\\", \\\"{x:1337,y:498,t:1526930056760};\\\", \\\"{x:1338,y:497,t:1526930056777};\\\", \\\"{x:1339,y:496,t:1526930056794};\\\", \\\"{x:1340,y:495,t:1526930056810};\\\", \\\"{x:1340,y:496,t:1526930056904};\\\", \\\"{x:1340,y:499,t:1526930056912};\\\", \\\"{x:1341,y:503,t:1526930056927};\\\", \\\"{x:1344,y:511,t:1526930056944};\\\", \\\"{x:1344,y:516,t:1526930056961};\\\", \\\"{x:1345,y:520,t:1526930056977};\\\", \\\"{x:1345,y:526,t:1526930056995};\\\", \\\"{x:1345,y:535,t:1526930057011};\\\", \\\"{x:1346,y:550,t:1526930057027};\\\", \\\"{x:1349,y:567,t:1526930057044};\\\", \\\"{x:1350,y:583,t:1526930057061};\\\", \\\"{x:1350,y:597,t:1526930057077};\\\", \\\"{x:1350,y:607,t:1526930057094};\\\", \\\"{x:1350,y:614,t:1526930057111};\\\", \\\"{x:1350,y:619,t:1526930057127};\\\", \\\"{x:1350,y:621,t:1526930057145};\\\", \\\"{x:1350,y:622,t:1526930057263};\\\", \\\"{x:1350,y:623,t:1526930057279};\\\", \\\"{x:1350,y:624,t:1526930057294};\\\", \\\"{x:1349,y:624,t:1526930057456};\\\", \\\"{x:1348,y:624,t:1526930057464};\\\", \\\"{x:1346,y:625,t:1526930057480};\\\", \\\"{x:1346,y:626,t:1526930057495};\\\", \\\"{x:1345,y:628,t:1526930057511};\\\", \\\"{x:1342,y:632,t:1526930057528};\\\", \\\"{x:1342,y:634,t:1526930057545};\\\", \\\"{x:1340,y:638,t:1526930057561};\\\", \\\"{x:1339,y:639,t:1526930057578};\\\", \\\"{x:1337,y:640,t:1526930057596};\\\", \\\"{x:1333,y:643,t:1526930057611};\\\", \\\"{x:1324,y:647,t:1526930057628};\\\", \\\"{x:1309,y:662,t:1526930057645};\\\", \\\"{x:1287,y:679,t:1526930057661};\\\", \\\"{x:1263,y:700,t:1526930057679};\\\", \\\"{x:1234,y:722,t:1526930057695};\\\", \\\"{x:1209,y:749,t:1526930057712};\\\", \\\"{x:1168,y:781,t:1526930057728};\\\", \\\"{x:1115,y:815,t:1526930057745};\\\", \\\"{x:1060,y:840,t:1526930057761};\\\", \\\"{x:1018,y:858,t:1526930057778};\\\", \\\"{x:978,y:872,t:1526930057795};\\\", \\\"{x:943,y:884,t:1526930057811};\\\", \\\"{x:916,y:894,t:1526930057831};\\\", \\\"{x:895,y:897,t:1526930057849};\\\", \\\"{x:847,y:912,t:1526930057866};\\\", \\\"{x:794,y:928,t:1526930057881};\\\", \\\"{x:738,y:945,t:1526930057899};\\\", \\\"{x:647,y:960,t:1526930057915};\\\", \\\"{x:577,y:968,t:1526930057932};\\\", \\\"{x:513,y:968,t:1526930057949};\\\", \\\"{x:466,y:968,t:1526930057966};\\\", \\\"{x:435,y:965,t:1526930057982};\\\", \\\"{x:412,y:954,t:1526930057998};\\\", \\\"{x:397,y:940,t:1526930058016};\\\", \\\"{x:387,y:924,t:1526930058032};\\\", \\\"{x:386,y:907,t:1526930058049};\\\", \\\"{x:386,y:889,t:1526930058066};\\\", \\\"{x:386,y:870,t:1526930058081};\\\", \\\"{x:392,y:849,t:1526930058099};\\\", \\\"{x:407,y:820,t:1526930058115};\\\", \\\"{x:422,y:803,t:1526930058132};\\\", \\\"{x:432,y:788,t:1526930058149};\\\", \\\"{x:443,y:775,t:1526930058166};\\\", \\\"{x:451,y:765,t:1526930058182};\\\", \\\"{x:459,y:758,t:1526930058199};\\\", \\\"{x:466,y:752,t:1526930058216};\\\", \\\"{x:471,y:746,t:1526930058234};\\\", \\\"{x:474,y:742,t:1526930058249};\\\", \\\"{x:476,y:740,t:1526930058265};\\\", \\\"{x:476,y:739,t:1526930058283};\\\", \\\"{x:477,y:737,t:1526930058299};\\\", \\\"{x:481,y:737,t:1526930058314};\\\", \\\"{x:482,y:737,t:1526930058371};\\\", \\\"{x:483,y:737,t:1526930058381};\\\", \\\"{x:487,y:736,t:1526930058398};\\\", \\\"{x:490,y:734,t:1526930058416};\\\", \\\"{x:492,y:733,t:1526930058431};\\\", \\\"{x:493,y:731,t:1526930058449};\\\" ] }, { \\\"rt\\\": 52025, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 10, \\\"time_elapsed\\\": 475417, \\\"internal_node_id\\\": \\\"0.0-6.0-0.0\\\", \\\"subject\\\": \\\"WKBNA\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration\\\", \\\"q\\\": 6, \\\"clicks\\\": 2.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\", \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-2-12 PM-08 AM-I -6-G -E -E -6-L -C -C -F -E -E -E \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:495,y:731,t:1526930063253};\\\", \\\"{x:515,y:731,t:1526930063269};\\\", \\\"{x:538,y:738,t:1526930063286};\\\", \\\"{x:570,y:749,t:1526930063303};\\\", \\\"{x:600,y:756,t:1526930063318};\\\", \\\"{x:646,y:772,t:1526930063336};\\\", \\\"{x:706,y:787,t:1526930063352};\\\", \\\"{x:773,y:797,t:1526930063370};\\\", \\\"{x:835,y:805,t:1526930063386};\\\", \\\"{x:892,y:807,t:1526930063403};\\\", \\\"{x:915,y:807,t:1526930063420};\\\", \\\"{x:927,y:807,t:1526930063436};\\\", \\\"{x:934,y:807,t:1526930063453};\\\", \\\"{x:936,y:807,t:1526930063470};\\\", \\\"{x:938,y:807,t:1526930063485};\\\", \\\"{x:941,y:809,t:1526930063503};\\\", \\\"{x:942,y:810,t:1526930063520};\\\", \\\"{x:945,y:811,t:1526930063536};\\\", \\\"{x:949,y:812,t:1526930063553};\\\", \\\"{x:953,y:812,t:1526930063570};\\\", \\\"{x:959,y:812,t:1526930063586};\\\", \\\"{x:971,y:812,t:1526930063604};\\\", \\\"{x:981,y:812,t:1526930063620};\\\", \\\"{x:986,y:812,t:1526930063637};\\\", \\\"{x:994,y:811,t:1526930063653};\\\", \\\"{x:1003,y:811,t:1526930063670};\\\", \\\"{x:1011,y:811,t:1526930063687};\\\", \\\"{x:1020,y:817,t:1526930063703};\\\", \\\"{x:1036,y:825,t:1526930063721};\\\", \\\"{x:1056,y:833,t:1526930063737};\\\", \\\"{x:1074,y:841,t:1526930063754};\\\", \\\"{x:1092,y:846,t:1526930063771};\\\", \\\"{x:1128,y:853,t:1526930063787};\\\", \\\"{x:1139,y:853,t:1526930063804};\\\", \\\"{x:1163,y:853,t:1526930063820};\\\", \\\"{x:1176,y:853,t:1526930063838};\\\", \\\"{x:1184,y:857,t:1526930063853};\\\", \\\"{x:1188,y:858,t:1526930063870};\\\", \\\"{x:1192,y:860,t:1526930063887};\\\", \\\"{x:1199,y:863,t:1526930063904};\\\", \\\"{x:1206,y:869,t:1526930063920};\\\", \\\"{x:1215,y:875,t:1526930063937};\\\", \\\"{x:1230,y:885,t:1526930063953};\\\", \\\"{x:1242,y:891,t:1526930063970};\\\", \\\"{x:1265,y:899,t:1526930063988};\\\", \\\"{x:1270,y:900,t:1526930064004};\\\", \\\"{x:1291,y:905,t:1526930064021};\\\", \\\"{x:1299,y:906,t:1526930064038};\\\", \\\"{x:1302,y:907,t:1526930064054};\\\", \\\"{x:1303,y:908,t:1526930064070};\\\", \\\"{x:1305,y:909,t:1526930064088};\\\", \\\"{x:1308,y:912,t:1526930064104};\\\", \\\"{x:1312,y:916,t:1526930064120};\\\", \\\"{x:1317,y:921,t:1526930064138};\\\", \\\"{x:1327,y:928,t:1526930064155};\\\", \\\"{x:1337,y:934,t:1526930064171};\\\", \\\"{x:1352,y:940,t:1526930064188};\\\", \\\"{x:1360,y:943,t:1526930064204};\\\", \\\"{x:1366,y:943,t:1526930064220};\\\", \\\"{x:1368,y:943,t:1526930064238};\\\", \\\"{x:1369,y:947,t:1526930064332};\\\", \\\"{x:1369,y:950,t:1526930064348};\\\", \\\"{x:1369,y:952,t:1526930064356};\\\", \\\"{x:1371,y:954,t:1526930064371};\\\", \\\"{x:1371,y:957,t:1526930064387};\\\", \\\"{x:1371,y:961,t:1526930064524};\\\", \\\"{x:1370,y:962,t:1526930064537};\\\", \\\"{x:1368,y:966,t:1526930064554};\\\", \\\"{x:1364,y:973,t:1526930064572};\\\", \\\"{x:1364,y:974,t:1526930064588};\\\", \\\"{x:1362,y:976,t:1526930064604};\\\", \\\"{x:1361,y:977,t:1526930064622};\\\", \\\"{x:1360,y:978,t:1526930064644};\\\", \\\"{x:1359,y:978,t:1526930064655};\\\", \\\"{x:1359,y:979,t:1526930064671};\\\", \\\"{x:1355,y:980,t:1526930064686};\\\", \\\"{x:1348,y:984,t:1526930064703};\\\", \\\"{x:1339,y:991,t:1526930064721};\\\", \\\"{x:1328,y:999,t:1526930064737};\\\", \\\"{x:1310,y:1010,t:1526930064754};\\\", \\\"{x:1273,y:1027,t:1526930064771};\\\", \\\"{x:1249,y:1037,t:1526930064787};\\\", \\\"{x:1227,y:1042,t:1526930064804};\\\", \\\"{x:1216,y:1044,t:1526930064821};\\\", \\\"{x:1212,y:1044,t:1526930064838};\\\", \\\"{x:1211,y:1044,t:1526930064854};\\\", \\\"{x:1207,y:1041,t:1526930064871};\\\", \\\"{x:1196,y:1033,t:1526930064888};\\\", \\\"{x:1183,y:1026,t:1526930064904};\\\", \\\"{x:1165,y:1017,t:1526930064922};\\\", \\\"{x:1144,y:1007,t:1526930064938};\\\", \\\"{x:1121,y:999,t:1526930064954};\\\", \\\"{x:1095,y:987,t:1526930064972};\\\", \\\"{x:1088,y:983,t:1526930064988};\\\", \\\"{x:1085,y:979,t:1526930065004};\\\", \\\"{x:1082,y:974,t:1526930065021};\\\", \\\"{x:1081,y:966,t:1526930065038};\\\", \\\"{x:1081,y:958,t:1526930065054};\\\", \\\"{x:1081,y:952,t:1526930065071};\\\", \\\"{x:1081,y:948,t:1526930065088};\\\", \\\"{x:1081,y:946,t:1526930065104};\\\", \\\"{x:1081,y:945,t:1526930065121};\\\", \\\"{x:1083,y:945,t:1526930065245};\\\", \\\"{x:1084,y:944,t:1526930065255};\\\", \\\"{x:1086,y:943,t:1526930065271};\\\", \\\"{x:1089,y:943,t:1526930065289};\\\", \\\"{x:1092,y:942,t:1526930065306};\\\", \\\"{x:1093,y:942,t:1526930065322};\\\", \\\"{x:1095,y:942,t:1526930065381};\\\", \\\"{x:1099,y:942,t:1526930065388};\\\", \\\"{x:1106,y:947,t:1526930065405};\\\", \\\"{x:1115,y:952,t:1526930065422};\\\", \\\"{x:1123,y:953,t:1526930065439};\\\", \\\"{x:1127,y:954,t:1526930065456};\\\", \\\"{x:1130,y:956,t:1526930065472};\\\", \\\"{x:1131,y:956,t:1526930065613};\\\", \\\"{x:1131,y:957,t:1526930066003};\\\", \\\"{x:1130,y:957,t:1526930066067};\\\", \\\"{x:1129,y:957,t:1526930066083};\\\", \\\"{x:1127,y:957,t:1526930066091};\\\", \\\"{x:1125,y:957,t:1526930066105};\\\", \\\"{x:1124,y:957,t:1526930066148};\\\", \\\"{x:1123,y:957,t:1526930066172};\\\", \\\"{x:1121,y:958,t:1526930066204};\\\", \\\"{x:1121,y:959,t:1526930066212};\\\", \\\"{x:1121,y:960,t:1526930066223};\\\", \\\"{x:1121,y:962,t:1526930066239};\\\", \\\"{x:1121,y:963,t:1526930066260};\\\", \\\"{x:1121,y:964,t:1526930066292};\\\", \\\"{x:1121,y:965,t:1526930066306};\\\", \\\"{x:1122,y:965,t:1526930066396};\\\", \\\"{x:1123,y:966,t:1526930066420};\\\", \\\"{x:1122,y:966,t:1526930067701};\\\", \\\"{x:1120,y:966,t:1526930067708};\\\", \\\"{x:1114,y:965,t:1526930067723};\\\", \\\"{x:1109,y:964,t:1526930067740};\\\", \\\"{x:1103,y:961,t:1526930067757};\\\", \\\"{x:1096,y:961,t:1526930067773};\\\", \\\"{x:1090,y:960,t:1526930067790};\\\", \\\"{x:1085,y:960,t:1526930067807};\\\", \\\"{x:1081,y:960,t:1526930067823};\\\", \\\"{x:1078,y:960,t:1526930067841};\\\", \\\"{x:1077,y:960,t:1526930067857};\\\", \\\"{x:1075,y:960,t:1526930067874};\\\", \\\"{x:1074,y:960,t:1526930068261};\\\", \\\"{x:1073,y:961,t:1526930068685};\\\", \\\"{x:1073,y:959,t:1526930068748};\\\", \\\"{x:1073,y:954,t:1526930068758};\\\", \\\"{x:1077,y:943,t:1526930068775};\\\", \\\"{x:1084,y:935,t:1526930068792};\\\", \\\"{x:1093,y:924,t:1526930068808};\\\", \\\"{x:1105,y:911,t:1526930068825};\\\", \\\"{x:1119,y:900,t:1526930068842};\\\", \\\"{x:1129,y:888,t:1526930068858};\\\", \\\"{x:1145,y:877,t:1526930068875};\\\", \\\"{x:1171,y:858,t:1526930068892};\\\", \\\"{x:1197,y:844,t:1526930068907};\\\", \\\"{x:1224,y:829,t:1526930068925};\\\", \\\"{x:1252,y:816,t:1526930068942};\\\", \\\"{x:1280,y:802,t:1526930068958};\\\", \\\"{x:1309,y:790,t:1526930068975};\\\", \\\"{x:1328,y:781,t:1526930068992};\\\", \\\"{x:1340,y:775,t:1526930069009};\\\", \\\"{x:1342,y:772,t:1526930069025};\\\", \\\"{x:1342,y:770,t:1526930069180};\\\", \\\"{x:1342,y:768,t:1526930069191};\\\", \\\"{x:1341,y:767,t:1526930069388};\\\", \\\"{x:1341,y:766,t:1526930069492};\\\", \\\"{x:1338,y:766,t:1526930069509};\\\", \\\"{x:1337,y:766,t:1526930069526};\\\", \\\"{x:1337,y:767,t:1526930069596};\\\", \\\"{x:1338,y:767,t:1526930069797};\\\", \\\"{x:1339,y:767,t:1526930069812};\\\", \\\"{x:1340,y:767,t:1526930069826};\\\", \\\"{x:1341,y:767,t:1526930069843};\\\", \\\"{x:1343,y:769,t:1526930069859};\\\", \\\"{x:1345,y:772,t:1526930069875};\\\", \\\"{x:1347,y:776,t:1526930069892};\\\", \\\"{x:1348,y:778,t:1526930069909};\\\", \\\"{x:1349,y:780,t:1526930069926};\\\", \\\"{x:1350,y:780,t:1526930069956};\\\", \\\"{x:1350,y:779,t:1526930070203};\\\", \\\"{x:1350,y:777,t:1526930070211};\\\", \\\"{x:1350,y:776,t:1526930070225};\\\", \\\"{x:1350,y:775,t:1526930070242};\\\", \\\"{x:1350,y:774,t:1526930070260};\\\", \\\"{x:1350,y:773,t:1526930070388};\\\", \\\"{x:1350,y:772,t:1526930070412};\\\", \\\"{x:1350,y:770,t:1526930070425};\\\", \\\"{x:1350,y:769,t:1526930070442};\\\", \\\"{x:1349,y:769,t:1526930070458};\\\", \\\"{x:1348,y:769,t:1526930070604};\\\", \\\"{x:1347,y:769,t:1526930073643};\\\", \\\"{x:1345,y:769,t:1526930073972};\\\", \\\"{x:1340,y:769,t:1526930073980};\\\", \\\"{x:1332,y:769,t:1526930073995};\\\", \\\"{x:1322,y:770,t:1526930074013};\\\", \\\"{x:1315,y:770,t:1526930074029};\\\", \\\"{x:1310,y:769,t:1526930074045};\\\", \\\"{x:1309,y:769,t:1526930074063};\\\", \\\"{x:1307,y:767,t:1526930074079};\\\", \\\"{x:1307,y:766,t:1526930074096};\\\", \\\"{x:1305,y:766,t:1526930074572};\\\", \\\"{x:1304,y:766,t:1526930074579};\\\", \\\"{x:1302,y:766,t:1526930074596};\\\", \\\"{x:1299,y:766,t:1526930074613};\\\", \\\"{x:1298,y:766,t:1526930074631};\\\", \\\"{x:1297,y:766,t:1526930074652};\\\", \\\"{x:1296,y:766,t:1526930074676};\\\", \\\"{x:1294,y:766,t:1526930074684};\\\", \\\"{x:1293,y:766,t:1526930074707};\\\", \\\"{x:1292,y:766,t:1526930074715};\\\", \\\"{x:1291,y:766,t:1526930074730};\\\", \\\"{x:1290,y:766,t:1526930074748};\\\", \\\"{x:1289,y:766,t:1526930074763};\\\", \\\"{x:1288,y:766,t:1526930074780};\\\", \\\"{x:1287,y:766,t:1526930074797};\\\", \\\"{x:1285,y:766,t:1526930074813};\\\", \\\"{x:1284,y:766,t:1526930074924};\\\", \\\"{x:1283,y:766,t:1526930074948};\\\", \\\"{x:1282,y:766,t:1526930074963};\\\", \\\"{x:1278,y:767,t:1526930074980};\\\", \\\"{x:1277,y:768,t:1526930074997};\\\", \\\"{x:1276,y:769,t:1526930075013};\\\", \\\"{x:1275,y:769,t:1526930075092};\\\", \\\"{x:1275,y:767,t:1526930075508};\\\", \\\"{x:1276,y:767,t:1526930075572};\\\", \\\"{x:1277,y:766,t:1526930075692};\\\", \\\"{x:1279,y:764,t:1526930075708};\\\", \\\"{x:1279,y:763,t:1526930075716};\\\", \\\"{x:1281,y:763,t:1526930075731};\\\", \\\"{x:1282,y:763,t:1526930075747};\\\", \\\"{x:1283,y:763,t:1526930075787};\\\", \\\"{x:1284,y:763,t:1526930075811};\\\", \\\"{x:1285,y:763,t:1526930075844};\\\", \\\"{x:1286,y:762,t:1526930075892};\\\", \\\"{x:1286,y:761,t:1526930075900};\\\", \\\"{x:1287,y:761,t:1526930075914};\\\", \\\"{x:1288,y:760,t:1526930075931};\\\", \\\"{x:1289,y:760,t:1526930075996};\\\", \\\"{x:1290,y:760,t:1526930076212};\\\", \\\"{x:1291,y:760,t:1526930076220};\\\", \\\"{x:1291,y:762,t:1526930076604};\\\", \\\"{x:1290,y:763,t:1526930076620};\\\", \\\"{x:1288,y:764,t:1526930076631};\\\", \\\"{x:1286,y:764,t:1526930076659};\\\", \\\"{x:1285,y:764,t:1526930076692};\\\", \\\"{x:1282,y:764,t:1526930076700};\\\", \\\"{x:1282,y:763,t:1526930076716};\\\", \\\"{x:1281,y:763,t:1526930076732};\\\", \\\"{x:1280,y:763,t:1526930076748};\\\", \\\"{x:1279,y:763,t:1526930076765};\\\", \\\"{x:1276,y:763,t:1526930076782};\\\", \\\"{x:1273,y:763,t:1526930076798};\\\", \\\"{x:1270,y:763,t:1526930076815};\\\", \\\"{x:1266,y:763,t:1526930076832};\\\", \\\"{x:1263,y:763,t:1526930076848};\\\", \\\"{x:1260,y:763,t:1526930076865};\\\", \\\"{x:1258,y:763,t:1526930076882};\\\", \\\"{x:1255,y:763,t:1526930076898};\\\", \\\"{x:1251,y:762,t:1526930076916};\\\", \\\"{x:1240,y:758,t:1526930076932};\\\", \\\"{x:1234,y:756,t:1526930076948};\\\", \\\"{x:1226,y:755,t:1526930076965};\\\", \\\"{x:1220,y:755,t:1526930076982};\\\", \\\"{x:1214,y:755,t:1526930076998};\\\", \\\"{x:1207,y:755,t:1526930077015};\\\", \\\"{x:1200,y:755,t:1526930077032};\\\", \\\"{x:1195,y:755,t:1526930077048};\\\", \\\"{x:1191,y:755,t:1526930077065};\\\", \\\"{x:1185,y:754,t:1526930077082};\\\", \\\"{x:1179,y:751,t:1526930077098};\\\", \\\"{x:1169,y:746,t:1526930077116};\\\", \\\"{x:1153,y:742,t:1526930077132};\\\", \\\"{x:1139,y:742,t:1526930077149};\\\", \\\"{x:1127,y:742,t:1526930077165};\\\", \\\"{x:1113,y:742,t:1526930077182};\\\", \\\"{x:1102,y:742,t:1526930077199};\\\", \\\"{x:1096,y:743,t:1526930077215};\\\", \\\"{x:1092,y:744,t:1526930077232};\\\", \\\"{x:1091,y:744,t:1526930077249};\\\", \\\"{x:1090,y:744,t:1526930077265};\\\", \\\"{x:1089,y:744,t:1526930077396};\\\", \\\"{x:1089,y:745,t:1526930077404};\\\", \\\"{x:1087,y:746,t:1526930077416};\\\", \\\"{x:1086,y:747,t:1526930077432};\\\", \\\"{x:1085,y:748,t:1526930077449};\\\", \\\"{x:1083,y:750,t:1526930077548};\\\", \\\"{x:1082,y:752,t:1526930077567};\\\", \\\"{x:1078,y:757,t:1526930077582};\\\", \\\"{x:1076,y:767,t:1526930077599};\\\", \\\"{x:1075,y:773,t:1526930077616};\\\", \\\"{x:1074,y:776,t:1526930077633};\\\", \\\"{x:1074,y:777,t:1526930077650};\\\", \\\"{x:1074,y:779,t:1526930077666};\\\", \\\"{x:1074,y:778,t:1526930078069};\\\", \\\"{x:1074,y:775,t:1526930078083};\\\", \\\"{x:1074,y:769,t:1526930078099};\\\", \\\"{x:1069,y:753,t:1526930078116};\\\", \\\"{x:1063,y:740,t:1526930078133};\\\", \\\"{x:1059,y:725,t:1526930078150};\\\", \\\"{x:1051,y:712,t:1526930078166};\\\", \\\"{x:1044,y:701,t:1526930078183};\\\", \\\"{x:1039,y:694,t:1526930078199};\\\", \\\"{x:1037,y:691,t:1526930078216};\\\", \\\"{x:1035,y:687,t:1526930078233};\\\", \\\"{x:1034,y:682,t:1526930078249};\\\", \\\"{x:1032,y:677,t:1526930078267};\\\", \\\"{x:1031,y:667,t:1526930078284};\\\", \\\"{x:1030,y:657,t:1526930078298};\\\", \\\"{x:1030,y:643,t:1526930078316};\\\", \\\"{x:1029,y:633,t:1526930078332};\\\", \\\"{x:1029,y:625,t:1526930078350};\\\", \\\"{x:1029,y:619,t:1526930078366};\\\", \\\"{x:1029,y:614,t:1526930078383};\\\", \\\"{x:1029,y:611,t:1526930078400};\\\", \\\"{x:1029,y:608,t:1526930078416};\\\", \\\"{x:1029,y:607,t:1526930078433};\\\", \\\"{x:1029,y:605,t:1526930078450};\\\", \\\"{x:1029,y:603,t:1526930078466};\\\", \\\"{x:1030,y:599,t:1526930078483};\\\", \\\"{x:1032,y:592,t:1526930078499};\\\", \\\"{x:1034,y:587,t:1526930078516};\\\", \\\"{x:1036,y:582,t:1526930078533};\\\", \\\"{x:1037,y:576,t:1526930078550};\\\", \\\"{x:1038,y:569,t:1526930078566};\\\", \\\"{x:1041,y:565,t:1526930078583};\\\", \\\"{x:1041,y:561,t:1526930078600};\\\", \\\"{x:1042,y:558,t:1526930078616};\\\", \\\"{x:1044,y:555,t:1526930078633};\\\", \\\"{x:1044,y:553,t:1526930078652};\\\", \\\"{x:1045,y:553,t:1526930078666};\\\", \\\"{x:1046,y:553,t:1526930078972};\\\", \\\"{x:1047,y:553,t:1526930078983};\\\", \\\"{x:1051,y:553,t:1526930079000};\\\", \\\"{x:1059,y:556,t:1526930079018};\\\", \\\"{x:1073,y:559,t:1526930079034};\\\", \\\"{x:1095,y:563,t:1526930079050};\\\", \\\"{x:1117,y:565,t:1526930079067};\\\", \\\"{x:1152,y:564,t:1526930079084};\\\", \\\"{x:1181,y:560,t:1526930079100};\\\", \\\"{x:1216,y:552,t:1526930079117};\\\", \\\"{x:1244,y:544,t:1526930079133};\\\", \\\"{x:1267,y:536,t:1526930079150};\\\", \\\"{x:1288,y:533,t:1526930079167};\\\", \\\"{x:1296,y:532,t:1526930079183};\\\", \\\"{x:1300,y:531,t:1526930079200};\\\", \\\"{x:1301,y:531,t:1526930079217};\\\", \\\"{x:1303,y:531,t:1526930079324};\\\", \\\"{x:1304,y:531,t:1526930079334};\\\", \\\"{x:1306,y:531,t:1526930079350};\\\", \\\"{x:1308,y:531,t:1526930079368};\\\", \\\"{x:1311,y:532,t:1526930079384};\\\", \\\"{x:1313,y:534,t:1526930079401};\\\", \\\"{x:1314,y:536,t:1526930079417};\\\", \\\"{x:1317,y:542,t:1526930079434};\\\", \\\"{x:1317,y:548,t:1526930079450};\\\", \\\"{x:1317,y:553,t:1526930079467};\\\", \\\"{x:1317,y:555,t:1526930079484};\\\", \\\"{x:1316,y:557,t:1526930079500};\\\", \\\"{x:1316,y:558,t:1526930079580};\\\", \\\"{x:1315,y:559,t:1526930079596};\\\", \\\"{x:1313,y:560,t:1526930079619};\\\", \\\"{x:1310,y:561,t:1526930079652};\\\", \\\"{x:1309,y:562,t:1526930079668};\\\", \\\"{x:1308,y:564,t:1526930079684};\\\", \\\"{x:1307,y:564,t:1526930079701};\\\", \\\"{x:1306,y:564,t:1526930079860};\\\", \\\"{x:1304,y:565,t:1526930079900};\\\", \\\"{x:1303,y:566,t:1526930080092};\\\", \\\"{x:1304,y:567,t:1526930080509};\\\", \\\"{x:1304,y:568,t:1526930080740};\\\", \\\"{x:1304,y:569,t:1526930080900};\\\", \\\"{x:1305,y:569,t:1526930081532};\\\", \\\"{x:1306,y:569,t:1526930081540};\\\", \\\"{x:1308,y:569,t:1526930081552};\\\", \\\"{x:1313,y:569,t:1526930081570};\\\", \\\"{x:1320,y:566,t:1526930081585};\\\", \\\"{x:1329,y:565,t:1526930081602};\\\", \\\"{x:1342,y:564,t:1526930081620};\\\", \\\"{x:1348,y:564,t:1526930081636};\\\", \\\"{x:1352,y:564,t:1526930081652};\\\", \\\"{x:1355,y:564,t:1526930081669};\\\", \\\"{x:1359,y:564,t:1526930081686};\\\", \\\"{x:1366,y:564,t:1526930081702};\\\", \\\"{x:1376,y:565,t:1526930081720};\\\", \\\"{x:1383,y:565,t:1526930081737};\\\", \\\"{x:1392,y:565,t:1526930081753};\\\", \\\"{x:1404,y:565,t:1526930081770};\\\", \\\"{x:1415,y:565,t:1526930081788};\\\", \\\"{x:1418,y:565,t:1526930081802};\\\", \\\"{x:1419,y:565,t:1526930081819};\\\", \\\"{x:1417,y:565,t:1526930082139};\\\", \\\"{x:1416,y:565,t:1526930082155};\\\", \\\"{x:1415,y:564,t:1526930082169};\\\", \\\"{x:1412,y:562,t:1526930082186};\\\", \\\"{x:1403,y:561,t:1526930082204};\\\", \\\"{x:1393,y:559,t:1526930082219};\\\", \\\"{x:1382,y:559,t:1526930082236};\\\", \\\"{x:1372,y:559,t:1526930082253};\\\", \\\"{x:1353,y:560,t:1526930082269};\\\", \\\"{x:1333,y:566,t:1526930082287};\\\", \\\"{x:1312,y:569,t:1526930082304};\\\", \\\"{x:1293,y:575,t:1526930082320};\\\", \\\"{x:1276,y:578,t:1526930082336};\\\", \\\"{x:1264,y:581,t:1526930082353};\\\", \\\"{x:1263,y:581,t:1526930082369};\\\", \\\"{x:1262,y:581,t:1526930082387};\\\", \\\"{x:1261,y:580,t:1526930082404};\\\", \\\"{x:1260,y:580,t:1526930082421};\\\", \\\"{x:1260,y:579,t:1526930082437};\\\", \\\"{x:1260,y:578,t:1526930082572};\\\", \\\"{x:1260,y:577,t:1526930082586};\\\", \\\"{x:1267,y:572,t:1526930082603};\\\", \\\"{x:1273,y:568,t:1526930082619};\\\", \\\"{x:1276,y:566,t:1526930082637};\\\", \\\"{x:1278,y:565,t:1526930082653};\\\", \\\"{x:1280,y:564,t:1526930082748};\\\", \\\"{x:1283,y:564,t:1526930082764};\\\", \\\"{x:1283,y:563,t:1526930082780};\\\", \\\"{x:1285,y:562,t:1526930082788};\\\", \\\"{x:1286,y:562,t:1526930082804};\\\", \\\"{x:1287,y:562,t:1526930082820};\\\", \\\"{x:1288,y:562,t:1526930082842};\\\", \\\"{x:1289,y:562,t:1526930082882};\\\", \\\"{x:1290,y:562,t:1526930082890};\\\", \\\"{x:1291,y:562,t:1526930082903};\\\", \\\"{x:1294,y:562,t:1526930082920};\\\", \\\"{x:1295,y:563,t:1526930082937};\\\", \\\"{x:1296,y:565,t:1526930082953};\\\", \\\"{x:1296,y:566,t:1526930083084};\\\", \\\"{x:1296,y:567,t:1526930083100};\\\", \\\"{x:1296,y:569,t:1526930083116};\\\", \\\"{x:1295,y:569,t:1526930083131};\\\", \\\"{x:1294,y:569,t:1526930083748};\\\", \\\"{x:1293,y:569,t:1526930083755};\\\", \\\"{x:1293,y:570,t:1526930084572};\\\", \\\"{x:1293,y:571,t:1526930084756};\\\", \\\"{x:1293,y:572,t:1526930084779};\\\", \\\"{x:1292,y:572,t:1526930092484};\\\", \\\"{x:1290,y:572,t:1526930092523};\\\", \\\"{x:1288,y:570,t:1526930092532};\\\", \\\"{x:1285,y:569,t:1526930092544};\\\", \\\"{x:1283,y:568,t:1526930092562};\\\", \\\"{x:1278,y:565,t:1526930092578};\\\", \\\"{x:1274,y:564,t:1526930092596};\\\", \\\"{x:1269,y:564,t:1526930092612};\\\", \\\"{x:1268,y:564,t:1526930092628};\\\", \\\"{x:1265,y:564,t:1526930092802};\\\", \\\"{x:1262,y:564,t:1526930092811};\\\", \\\"{x:1251,y:564,t:1526930092829};\\\", \\\"{x:1234,y:565,t:1526930092845};\\\", \\\"{x:1216,y:570,t:1526930092862};\\\", \\\"{x:1197,y:570,t:1526930092878};\\\", \\\"{x:1177,y:570,t:1526930092895};\\\", \\\"{x:1154,y:567,t:1526930092911};\\\", \\\"{x:1132,y:562,t:1526930092928};\\\", \\\"{x:1123,y:559,t:1526930092946};\\\", \\\"{x:1114,y:554,t:1526930092962};\\\", \\\"{x:1112,y:554,t:1526930092979};\\\", \\\"{x:1111,y:554,t:1526930093010};\\\", \\\"{x:1110,y:554,t:1526930093018};\\\", \\\"{x:1108,y:554,t:1526930093034};\\\", \\\"{x:1106,y:554,t:1526930093045};\\\", \\\"{x:1097,y:554,t:1526930093061};\\\", \\\"{x:1089,y:554,t:1526930093078};\\\", \\\"{x:1084,y:554,t:1526930093094};\\\", \\\"{x:1083,y:554,t:1526930093114};\\\", \\\"{x:1082,y:554,t:1526930093163};\\\", \\\"{x:1081,y:554,t:1526930093178};\\\", \\\"{x:1079,y:554,t:1526930093195};\\\", \\\"{x:1076,y:556,t:1526930093212};\\\", \\\"{x:1070,y:560,t:1526930093228};\\\", \\\"{x:1060,y:565,t:1526930093245};\\\", \\\"{x:1047,y:573,t:1526930093262};\\\", \\\"{x:1029,y:578,t:1526930093278};\\\", \\\"{x:1018,y:580,t:1526930093295};\\\", \\\"{x:1000,y:581,t:1526930093312};\\\", \\\"{x:978,y:581,t:1526930093328};\\\", \\\"{x:947,y:581,t:1526930093346};\\\", \\\"{x:901,y:573,t:1526930093362};\\\", \\\"{x:870,y:564,t:1526930093378};\\\", \\\"{x:796,y:561,t:1526930093395};\\\", \\\"{x:742,y:560,t:1526930093410};\\\", \\\"{x:689,y:560,t:1526930093427};\\\", \\\"{x:657,y:560,t:1526930093444};\\\", \\\"{x:633,y:562,t:1526930093461};\\\", \\\"{x:625,y:562,t:1526930093478};\\\", \\\"{x:623,y:562,t:1526930093494};\\\", \\\"{x:622,y:562,t:1526930093522};\\\", \\\"{x:621,y:562,t:1526930093539};\\\", \\\"{x:619,y:562,t:1526930093546};\\\", \\\"{x:616,y:560,t:1526930093571};\\\", \\\"{x:612,y:558,t:1526930093587};\\\", \\\"{x:611,y:558,t:1526930093603};\\\", \\\"{x:609,y:558,t:1526930093612};\\\", \\\"{x:607,y:558,t:1526930093628};\\\", \\\"{x:605,y:558,t:1526930093645};\\\", \\\"{x:602,y:558,t:1526930093662};\\\", \\\"{x:600,y:558,t:1526930093678};\\\", \\\"{x:599,y:558,t:1526930093696};\\\", \\\"{x:597,y:557,t:1526930093711};\\\", \\\"{x:596,y:555,t:1526930093730};\\\", \\\"{x:593,y:551,t:1526930093745};\\\", \\\"{x:591,y:549,t:1526930093761};\\\", \\\"{x:589,y:545,t:1526930093777};\\\", \\\"{x:588,y:544,t:1526930093794};\\\", \\\"{x:588,y:543,t:1526930093811};\\\", \\\"{x:587,y:543,t:1526930093843};\\\", \\\"{x:586,y:543,t:1526930093859};\\\", \\\"{x:585,y:543,t:1526930093882};\\\", \\\"{x:584,y:543,t:1526930093956};\\\", \\\"{x:583,y:542,t:1526930093963};\\\", \\\"{x:582,y:542,t:1526930093977};\\\", \\\"{x:579,y:538,t:1526930093995};\\\", \\\"{x:578,y:538,t:1526930094011};\\\", \\\"{x:576,y:538,t:1526930094027};\\\", \\\"{x:576,y:537,t:1526930094084};\\\", \\\"{x:576,y:535,t:1526930094115};\\\", \\\"{x:579,y:535,t:1526930094128};\\\", \\\"{x:593,y:530,t:1526930094144};\\\", \\\"{x:615,y:528,t:1526930094162};\\\", \\\"{x:639,y:524,t:1526930094178};\\\", \\\"{x:656,y:520,t:1526930094195};\\\", \\\"{x:659,y:520,t:1526930094212};\\\", \\\"{x:658,y:520,t:1526930094323};\\\", \\\"{x:656,y:519,t:1526930094331};\\\", \\\"{x:655,y:517,t:1526930094348};\\\", \\\"{x:653,y:516,t:1526930094362};\\\", \\\"{x:651,y:515,t:1526930094378};\\\", \\\"{x:646,y:513,t:1526930094394};\\\", \\\"{x:642,y:511,t:1526930094412};\\\", \\\"{x:640,y:511,t:1526930094428};\\\", \\\"{x:636,y:509,t:1526930094445};\\\", \\\"{x:635,y:509,t:1526930094463};\\\", \\\"{x:633,y:508,t:1526930094478};\\\", \\\"{x:631,y:508,t:1526930094495};\\\", \\\"{x:629,y:507,t:1526930094512};\\\", \\\"{x:626,y:505,t:1526930094529};\\\", \\\"{x:623,y:504,t:1526930094545};\\\", \\\"{x:621,y:502,t:1526930094562};\\\", \\\"{x:617,y:501,t:1526930094580};\\\", \\\"{x:613,y:499,t:1526930094595};\\\", \\\"{x:611,y:499,t:1526930094613};\\\", \\\"{x:610,y:499,t:1526930094635};\\\", \\\"{x:609,y:499,t:1526930095675};\\\", \\\"{x:609,y:507,t:1526930095683};\\\", \\\"{x:609,y:511,t:1526930095697};\\\", \\\"{x:606,y:520,t:1526930095715};\\\", \\\"{x:606,y:529,t:1526930095731};\\\", \\\"{x:606,y:537,t:1526930095747};\\\", \\\"{x:606,y:538,t:1526930095763};\\\", \\\"{x:607,y:538,t:1526930095780};\\\", \\\"{x:607,y:539,t:1526930095907};\\\", \\\"{x:609,y:540,t:1526930095914};\\\", \\\"{x:609,y:541,t:1526930095930};\\\", \\\"{x:610,y:541,t:1526930095946};\\\", \\\"{x:619,y:543,t:1526930095963};\\\", \\\"{x:630,y:543,t:1526930095981};\\\", \\\"{x:642,y:543,t:1526930095996};\\\", \\\"{x:660,y:543,t:1526930096014};\\\", \\\"{x:684,y:543,t:1526930096030};\\\", \\\"{x:718,y:543,t:1526930096046};\\\", \\\"{x:751,y:543,t:1526930096064};\\\", \\\"{x:810,y:545,t:1526930096080};\\\", \\\"{x:850,y:545,t:1526930096097};\\\", \\\"{x:876,y:547,t:1526930096113};\\\", \\\"{x:896,y:549,t:1526930096131};\\\", \\\"{x:897,y:549,t:1526930096147};\\\", \\\"{x:895,y:549,t:1526930096211};\\\", \\\"{x:893,y:548,t:1526930096219};\\\", \\\"{x:888,y:546,t:1526930096231};\\\", \\\"{x:885,y:545,t:1526930096246};\\\", \\\"{x:883,y:544,t:1526930096263};\\\", \\\"{x:880,y:544,t:1526930096281};\\\", \\\"{x:875,y:544,t:1526930096297};\\\", \\\"{x:870,y:544,t:1526930096313};\\\", \\\"{x:859,y:544,t:1526930096332};\\\", \\\"{x:848,y:545,t:1526930096346};\\\", \\\"{x:842,y:545,t:1526930096363};\\\", \\\"{x:834,y:545,t:1526930096380};\\\", \\\"{x:828,y:542,t:1526930096397};\\\", \\\"{x:825,y:540,t:1526930096414};\\\", \\\"{x:822,y:537,t:1526930096430};\\\", \\\"{x:821,y:537,t:1526930096450};\\\", \\\"{x:824,y:537,t:1526930097740};\\\", \\\"{x:872,y:549,t:1526930097748};\\\", \\\"{x:1033,y:571,t:1526930097765};\\\", \\\"{x:1256,y:601,t:1526930097782};\\\", \\\"{x:1482,y:622,t:1526930097799};\\\", \\\"{x:1714,y:622,t:1526930097814};\\\", \\\"{x:1899,y:616,t:1526930097831};\\\", \\\"{x:1919,y:596,t:1526930097848};\\\", \\\"{x:1919,y:582,t:1526930097865};\\\", \\\"{x:1919,y:581,t:1526930097881};\\\", \\\"{x:1919,y:580,t:1526930097898};\\\", \\\"{x:1914,y:576,t:1526930097915};\\\", \\\"{x:1840,y:551,t:1526930097931};\\\", \\\"{x:1716,y:524,t:1526930097948};\\\", \\\"{x:1585,y:496,t:1526930097966};\\\", \\\"{x:1456,y:486,t:1526930097982};\\\", \\\"{x:1361,y:484,t:1526930097998};\\\", \\\"{x:1318,y:484,t:1526930098015};\\\", \\\"{x:1301,y:488,t:1526930098032};\\\", \\\"{x:1294,y:492,t:1526930098049};\\\", \\\"{x:1290,y:496,t:1526930098066};\\\", \\\"{x:1290,y:498,t:1526930098082};\\\", \\\"{x:1291,y:504,t:1526930098099};\\\", \\\"{x:1302,y:510,t:1526930098115};\\\", \\\"{x:1323,y:524,t:1526930098132};\\\", \\\"{x:1381,y:541,t:1526930098149};\\\", \\\"{x:1480,y:567,t:1526930098166};\\\", \\\"{x:1592,y:587,t:1526930098182};\\\", \\\"{x:1661,y:605,t:1526930098198};\\\", \\\"{x:1758,y:621,t:1526930098216};\\\", \\\"{x:1825,y:629,t:1526930098232};\\\", \\\"{x:1862,y:632,t:1526930098248};\\\", \\\"{x:1875,y:632,t:1526930098266};\\\", \\\"{x:1877,y:632,t:1526930098283};\\\", \\\"{x:1870,y:632,t:1526930098307};\\\", \\\"{x:1853,y:631,t:1526930098315};\\\", \\\"{x:1816,y:624,t:1526930098333};\\\", \\\"{x:1757,y:616,t:1526930098349};\\\", \\\"{x:1708,y:604,t:1526930098366};\\\", \\\"{x:1661,y:591,t:1526930098383};\\\", \\\"{x:1616,y:578,t:1526930098399};\\\", \\\"{x:1573,y:563,t:1526930098417};\\\", \\\"{x:1536,y:551,t:1526930098433};\\\", \\\"{x:1508,y:543,t:1526930098449};\\\", \\\"{x:1492,y:539,t:1526930098466};\\\", \\\"{x:1488,y:538,t:1526930098483};\\\", \\\"{x:1493,y:540,t:1526930098588};\\\", \\\"{x:1498,y:545,t:1526930098600};\\\", \\\"{x:1511,y:560,t:1526930098616};\\\", \\\"{x:1519,y:574,t:1526930098633};\\\", \\\"{x:1522,y:584,t:1526930098650};\\\", \\\"{x:1525,y:589,t:1526930098666};\\\", \\\"{x:1526,y:595,t:1526930098683};\\\", \\\"{x:1526,y:596,t:1526930098699};\\\", \\\"{x:1526,y:597,t:1526930098716};\\\", \\\"{x:1523,y:601,t:1526930098733};\\\", \\\"{x:1521,y:607,t:1526930098749};\\\", \\\"{x:1519,y:613,t:1526930098766};\\\", \\\"{x:1517,y:617,t:1526930098783};\\\", \\\"{x:1516,y:619,t:1526930098800};\\\", \\\"{x:1512,y:619,t:1526930099068};\\\", \\\"{x:1508,y:619,t:1526930099083};\\\", \\\"{x:1486,y:619,t:1526930099100};\\\", \\\"{x:1470,y:619,t:1526930099116};\\\", \\\"{x:1454,y:619,t:1526930099133};\\\", \\\"{x:1449,y:619,t:1526930099150};\\\", \\\"{x:1448,y:618,t:1526930099167};\\\", \\\"{x:1447,y:612,t:1526930099183};\\\", \\\"{x:1445,y:608,t:1526930099201};\\\", \\\"{x:1441,y:602,t:1526930099217};\\\", \\\"{x:1435,y:595,t:1526930099233};\\\", \\\"{x:1433,y:594,t:1526930099250};\\\", \\\"{x:1431,y:594,t:1526930099267};\\\", \\\"{x:1430,y:592,t:1526930099283};\\\", \\\"{x:1428,y:591,t:1526930099300};\\\", \\\"{x:1423,y:588,t:1526930099318};\\\", \\\"{x:1420,y:585,t:1526930099333};\\\", \\\"{x:1419,y:585,t:1526930099350};\\\", \\\"{x:1418,y:584,t:1526930099367};\\\", \\\"{x:1416,y:583,t:1526930099383};\\\", \\\"{x:1414,y:582,t:1526930099411};\\\", \\\"{x:1414,y:581,t:1526930099420};\\\", \\\"{x:1413,y:580,t:1526930099436};\\\", \\\"{x:1412,y:579,t:1526930099452};\\\", \\\"{x:1411,y:579,t:1526930099467};\\\", \\\"{x:1411,y:577,t:1526930099483};\\\", \\\"{x:1410,y:577,t:1526930099940};\\\", \\\"{x:1409,y:578,t:1526930099950};\\\", \\\"{x:1409,y:583,t:1526930099967};\\\", \\\"{x:1409,y:589,t:1526930099984};\\\", \\\"{x:1410,y:599,t:1526930100000};\\\", \\\"{x:1412,y:614,t:1526930100017};\\\", \\\"{x:1416,y:629,t:1526930100034};\\\", \\\"{x:1421,y:641,t:1526930100050};\\\", \\\"{x:1432,y:656,t:1526930100067};\\\", \\\"{x:1440,y:664,t:1526930100084};\\\", \\\"{x:1454,y:669,t:1526930100101};\\\", \\\"{x:1464,y:672,t:1526930100117};\\\", \\\"{x:1474,y:675,t:1526930100134};\\\", \\\"{x:1478,y:675,t:1526930100151};\\\", \\\"{x:1479,y:675,t:1526930100171};\\\", \\\"{x:1481,y:674,t:1526930100184};\\\", \\\"{x:1481,y:669,t:1526930100201};\\\", \\\"{x:1486,y:659,t:1526930100217};\\\", \\\"{x:1488,y:648,t:1526930100234};\\\", \\\"{x:1492,y:638,t:1526930100251};\\\", \\\"{x:1492,y:635,t:1526930100268};\\\", \\\"{x:1492,y:634,t:1526930100292};\\\", \\\"{x:1492,y:633,t:1526930100301};\\\", \\\"{x:1492,y:631,t:1526930100317};\\\", \\\"{x:1491,y:630,t:1526930100334};\\\", \\\"{x:1490,y:629,t:1526930100350};\\\", \\\"{x:1489,y:629,t:1526930100378};\\\", \\\"{x:1488,y:628,t:1526930100498};\\\", \\\"{x:1487,y:628,t:1526930100506};\\\", \\\"{x:1484,y:626,t:1526930100517};\\\", \\\"{x:1482,y:623,t:1526930100534};\\\", \\\"{x:1481,y:619,t:1526930100551};\\\", \\\"{x:1480,y:614,t:1526930100568};\\\", \\\"{x:1480,y:612,t:1526930100583};\\\", \\\"{x:1482,y:612,t:1526930100643};\\\", \\\"{x:1484,y:612,t:1526930100650};\\\", \\\"{x:1486,y:612,t:1526930100667};\\\", \\\"{x:1489,y:613,t:1526930100684};\\\", \\\"{x:1492,y:617,t:1526930100700};\\\", \\\"{x:1496,y:624,t:1526930100718};\\\", \\\"{x:1496,y:626,t:1526930100734};\\\", \\\"{x:1492,y:625,t:1526930101268};\\\", \\\"{x:1487,y:624,t:1526930101285};\\\", \\\"{x:1483,y:622,t:1526930101301};\\\", \\\"{x:1477,y:619,t:1526930101318};\\\", \\\"{x:1474,y:618,t:1526930101336};\\\", \\\"{x:1473,y:618,t:1526930101580};\\\", \\\"{x:1470,y:617,t:1526930101588};\\\", \\\"{x:1469,y:616,t:1526930101602};\\\", \\\"{x:1467,y:615,t:1526930101618};\\\", \\\"{x:1466,y:615,t:1526930101635};\\\", \\\"{x:1465,y:615,t:1526930101652};\\\", \\\"{x:1463,y:615,t:1526930101668};\\\", \\\"{x:1462,y:615,t:1526930101685};\\\", \\\"{x:1460,y:615,t:1526930101748};\\\", \\\"{x:1460,y:617,t:1526930101788};\\\", \\\"{x:1460,y:618,t:1526930101811};\\\", \\\"{x:1460,y:619,t:1526930101828};\\\", \\\"{x:1460,y:620,t:1526930101852};\\\", \\\"{x:1460,y:622,t:1526930101886};\\\", \\\"{x:1459,y:624,t:1526930101901};\\\", \\\"{x:1455,y:626,t:1526930101918};\\\", \\\"{x:1451,y:629,t:1526930101935};\\\", \\\"{x:1449,y:629,t:1526930101952};\\\", \\\"{x:1448,y:629,t:1526930101969};\\\", \\\"{x:1446,y:629,t:1526930102018};\\\", \\\"{x:1445,y:629,t:1526930102043};\\\", \\\"{x:1444,y:629,t:1526930102075};\\\", \\\"{x:1443,y:631,t:1526930102364};\\\", \\\"{x:1443,y:633,t:1526930102732};\\\", \\\"{x:1443,y:634,t:1526930102740};\\\", \\\"{x:1442,y:634,t:1526930102770};\\\", \\\"{x:1442,y:635,t:1526930102891};\\\", \\\"{x:1442,y:636,t:1526930102903};\\\", \\\"{x:1442,y:640,t:1526930102919};\\\", \\\"{x:1442,y:642,t:1526930102935};\\\", \\\"{x:1441,y:644,t:1526930102952};\\\", \\\"{x:1441,y:645,t:1526930103796};\\\", \\\"{x:1440,y:648,t:1526930103803};\\\", \\\"{x:1436,y:653,t:1526930103821};\\\", \\\"{x:1430,y:656,t:1526930103837};\\\", \\\"{x:1427,y:659,t:1526930103853};\\\", \\\"{x:1425,y:660,t:1526930103871};\\\", \\\"{x:1423,y:662,t:1526930104044};\\\", \\\"{x:1422,y:663,t:1526930104054};\\\", \\\"{x:1420,y:666,t:1526930104071};\\\", \\\"{x:1418,y:667,t:1526930104087};\\\", \\\"{x:1417,y:667,t:1526930104235};\\\", \\\"{x:1413,y:670,t:1526930104254};\\\", \\\"{x:1406,y:676,t:1526930104271};\\\", \\\"{x:1402,y:679,t:1526930104287};\\\", \\\"{x:1397,y:681,t:1526930104304};\\\", \\\"{x:1395,y:682,t:1526930104320};\\\", \\\"{x:1393,y:684,t:1526930104338};\\\", \\\"{x:1392,y:684,t:1526930104355};\\\", \\\"{x:1391,y:684,t:1526930104459};\\\", \\\"{x:1388,y:684,t:1526930104470};\\\", \\\"{x:1381,y:689,t:1526930104487};\\\", \\\"{x:1370,y:695,t:1526930104504};\\\", \\\"{x:1363,y:699,t:1526930104521};\\\", \\\"{x:1360,y:700,t:1526930104538};\\\", \\\"{x:1356,y:700,t:1526930104554};\\\", \\\"{x:1348,y:702,t:1526930104571};\\\", \\\"{x:1342,y:702,t:1526930104588};\\\", \\\"{x:1337,y:702,t:1526930104604};\\\", \\\"{x:1333,y:702,t:1526930104621};\\\", \\\"{x:1325,y:703,t:1526930104638};\\\", \\\"{x:1310,y:705,t:1526930104655};\\\", \\\"{x:1285,y:713,t:1526930104672};\\\", \\\"{x:1228,y:735,t:1526930104687};\\\", \\\"{x:1156,y:757,t:1526930104704};\\\", \\\"{x:1073,y:777,t:1526930104721};\\\", \\\"{x:985,y:789,t:1526930104737};\\\", \\\"{x:897,y:796,t:1526930104754};\\\", \\\"{x:775,y:796,t:1526930104771};\\\", \\\"{x:698,y:792,t:1526930104787};\\\", \\\"{x:616,y:775,t:1526930104804};\\\", \\\"{x:545,y:757,t:1526930104821};\\\", \\\"{x:528,y:756,t:1526930104837};\\\", \\\"{x:526,y:756,t:1526930104875};\\\", \\\"{x:524,y:756,t:1526930104955};\\\", \\\"{x:519,y:756,t:1526930104970};\\\", \\\"{x:514,y:755,t:1526930104987};\\\", \\\"{x:502,y:753,t:1526930105004};\\\", \\\"{x:485,y:750,t:1526930105020};\\\", \\\"{x:474,y:748,t:1526930105038};\\\", \\\"{x:464,y:747,t:1526930105052};\\\", \\\"{x:461,y:746,t:1526930105067};\\\", \\\"{x:459,y:746,t:1526930105154};\\\", \\\"{x:458,y:746,t:1526930105211};\\\", \\\"{x:457,y:744,t:1526930105643};\\\", \\\"{x:463,y:740,t:1526930105652};\\\", \\\"{x:484,y:725,t:1526930105669};\\\", \\\"{x:528,y:697,t:1526930105685};\\\", \\\"{x:581,y:661,t:1526930105702};\\\", \\\"{x:642,y:624,t:1526930105722};\\\", \\\"{x:712,y:586,t:1526930105738};\\\", \\\"{x:842,y:540,t:1526930105756};\\\", \\\"{x:919,y:520,t:1526930105773};\\\", \\\"{x:990,y:503,t:1526930105787};\\\", \\\"{x:1043,y:496,t:1526930105805};\\\", \\\"{x:1090,y:491,t:1526930105822};\\\", \\\"{x:1114,y:491,t:1526930105839};\\\", \\\"{x:1126,y:490,t:1526930105855};\\\", \\\"{x:1131,y:490,t:1526930105872};\\\", \\\"{x:1133,y:491,t:1526930105889};\\\", \\\"{x:1134,y:491,t:1526930105906};\\\", \\\"{x:1135,y:491,t:1526930105922};\\\", \\\"{x:1137,y:491,t:1526930105939};\\\", \\\"{x:1145,y:494,t:1526930105955};\\\", \\\"{x:1156,y:499,t:1526930105972};\\\", \\\"{x:1165,y:506,t:1526930105989};\\\", \\\"{x:1180,y:520,t:1526930106006};\\\", \\\"{x:1198,y:539,t:1526930106023};\\\", \\\"{x:1212,y:555,t:1526930106039};\\\", \\\"{x:1222,y:566,t:1526930106056};\\\", \\\"{x:1232,y:574,t:1526930106074};\\\", \\\"{x:1237,y:577,t:1526930106090};\\\", \\\"{x:1238,y:578,t:1526930106106};\\\", \\\"{x:1239,y:578,t:1526930106204};\\\", \\\"{x:1241,y:578,t:1526930106211};\\\", \\\"{x:1242,y:577,t:1526930106223};\\\", \\\"{x:1245,y:576,t:1526930106241};\\\", \\\"{x:1247,y:575,t:1526930106258};\\\", \\\"{x:1249,y:574,t:1526930106275};\\\", \\\"{x:1250,y:574,t:1526930106290};\\\", \\\"{x:1252,y:574,t:1526930106307};\\\", \\\"{x:1254,y:574,t:1526930106324};\\\", \\\"{x:1256,y:574,t:1526930106340};\\\", \\\"{x:1260,y:574,t:1526930106357};\\\", \\\"{x:1266,y:570,t:1526930106374};\\\", \\\"{x:1269,y:569,t:1526930106390};\\\", \\\"{x:1276,y:566,t:1526930106408};\\\", \\\"{x:1281,y:563,t:1526930106424};\\\", \\\"{x:1288,y:562,t:1526930106442};\\\", \\\"{x:1292,y:562,t:1526930106457};\\\", \\\"{x:1295,y:562,t:1526930106474};\\\", \\\"{x:1299,y:562,t:1526930106491};\\\", \\\"{x:1304,y:562,t:1526930106507};\\\", \\\"{x:1307,y:562,t:1526930106524};\\\", \\\"{x:1313,y:562,t:1526930106541};\\\", \\\"{x:1315,y:563,t:1526930106559};\\\", \\\"{x:1317,y:563,t:1526930106579};\\\", \\\"{x:1318,y:563,t:1526930106604};\\\", \\\"{x:1317,y:563,t:1526930106963};\\\", \\\"{x:1315,y:563,t:1526930108100};\\\", \\\"{x:1309,y:563,t:1526930108114};\\\", \\\"{x:1295,y:561,t:1526930108130};\\\", \\\"{x:1281,y:558,t:1526930108147};\\\", \\\"{x:1261,y:556,t:1526930108164};\\\", \\\"{x:1256,y:555,t:1526930108180};\\\", \\\"{x:1255,y:555,t:1526930108197};\\\", \\\"{x:1255,y:556,t:1526930108436};\\\", \\\"{x:1255,y:557,t:1526930108451};\\\", \\\"{x:1256,y:557,t:1526930108465};\\\", \\\"{x:1262,y:558,t:1526930108482};\\\", \\\"{x:1268,y:558,t:1526930108497};\\\", \\\"{x:1277,y:560,t:1526930108515};\\\", \\\"{x:1295,y:560,t:1526930108532};\\\", \\\"{x:1299,y:560,t:1526930108547};\\\", \\\"{x:1293,y:559,t:1526930108604};\\\", \\\"{x:1271,y:555,t:1526930108615};\\\", \\\"{x:1190,y:541,t:1526930108631};\\\", \\\"{x:1081,y:524,t:1526930108649};\\\", \\\"{x:965,y:522,t:1526930108664};\\\", \\\"{x:862,y:522,t:1526930108682};\\\", \\\"{x:770,y:525,t:1526930108699};\\\", \\\"{x:707,y:536,t:1526930108715};\\\", \\\"{x:688,y:544,t:1526930108730};\\\", \\\"{x:685,y:545,t:1526930108741};\\\", \\\"{x:684,y:546,t:1526930108794};\\\", \\\"{x:684,y:547,t:1526930108810};\\\", \\\"{x:684,y:548,t:1526930108826};\\\", \\\"{x:685,y:548,t:1526930108842};\\\", \\\"{x:687,y:548,t:1526930108857};\\\", \\\"{x:695,y:549,t:1526930108874};\\\", \\\"{x:731,y:555,t:1526930108891};\\\", \\\"{x:759,y:558,t:1526930108908};\\\", \\\"{x:784,y:564,t:1526930108924};\\\", \\\"{x:806,y:566,t:1526930108941};\\\", \\\"{x:827,y:568,t:1526930108959};\\\", \\\"{x:836,y:569,t:1526930108974};\\\", \\\"{x:843,y:569,t:1526930108991};\\\", \\\"{x:844,y:569,t:1526930109007};\\\", \\\"{x:845,y:568,t:1526930109025};\\\", \\\"{x:846,y:568,t:1526930109041};\\\", \\\"{x:846,y:566,t:1526930109057};\\\", \\\"{x:847,y:566,t:1526930109090};\\\", \\\"{x:847,y:565,t:1526930109124};\\\", \\\"{x:847,y:562,t:1526930109141};\\\", \\\"{x:844,y:559,t:1526930109158};\\\", \\\"{x:844,y:558,t:1526930109174};\\\", \\\"{x:842,y:557,t:1526930109191};\\\", \\\"{x:841,y:555,t:1526930109208};\\\", \\\"{x:841,y:552,t:1526930109225};\\\", \\\"{x:839,y:549,t:1526930109241};\\\", \\\"{x:839,y:544,t:1526930109257};\\\", \\\"{x:838,y:535,t:1526930109274};\\\", \\\"{x:835,y:530,t:1526930109290};\\\", \\\"{x:834,y:527,t:1526930109308};\\\", \\\"{x:833,y:524,t:1526930109325};\\\", \\\"{x:832,y:524,t:1526930109835};\\\", \\\"{x:832,y:526,t:1526930109844};\\\", \\\"{x:832,y:530,t:1526930109858};\\\", \\\"{x:832,y:535,t:1526930109875};\\\", \\\"{x:832,y:536,t:1526930109892};\\\", \\\"{x:832,y:537,t:1526930109930};\\\", \\\"{x:835,y:539,t:1526930110444};\\\", \\\"{x:855,y:554,t:1526930110460};\\\", \\\"{x:874,y:576,t:1526930110476};\\\", \\\"{x:881,y:590,t:1526930110491};\\\", \\\"{x:882,y:591,t:1526930110509};\\\", \\\"{x:883,y:591,t:1526930111115};\\\", \\\"{x:886,y:589,t:1526930111127};\\\", \\\"{x:888,y:590,t:1526930111188};\\\", \\\"{x:889,y:591,t:1526930111195};\\\", \\\"{x:891,y:592,t:1526930111209};\\\", \\\"{x:898,y:598,t:1526930111228};\\\", \\\"{x:915,y:607,t:1526930111242};\\\", \\\"{x:928,y:611,t:1526930111260};\\\", \\\"{x:943,y:613,t:1526930111276};\\\", \\\"{x:970,y:615,t:1526930111293};\\\", \\\"{x:1011,y:622,t:1526930111310};\\\", \\\"{x:1068,y:633,t:1526930111326};\\\", \\\"{x:1127,y:641,t:1526930111343};\\\", \\\"{x:1184,y:646,t:1526930111359};\\\", \\\"{x:1243,y:648,t:1526930111376};\\\", \\\"{x:1291,y:648,t:1526930111393};\\\", \\\"{x:1330,y:649,t:1526930111409};\\\", \\\"{x:1351,y:645,t:1526930111426};\\\", \\\"{x:1373,y:627,t:1526930111443};\\\", \\\"{x:1379,y:611,t:1526930111459};\\\", \\\"{x:1379,y:594,t:1526930111476};\\\", \\\"{x:1378,y:574,t:1526930111493};\\\", \\\"{x:1369,y:554,t:1526930111509};\\\", \\\"{x:1361,y:539,t:1526930111526};\\\", \\\"{x:1355,y:529,t:1526930111543};\\\", \\\"{x:1348,y:524,t:1526930111559};\\\", \\\"{x:1340,y:520,t:1526930111576};\\\", \\\"{x:1331,y:517,t:1526930111593};\\\", \\\"{x:1325,y:517,t:1526930111609};\\\", \\\"{x:1316,y:519,t:1526930111627};\\\", \\\"{x:1302,y:529,t:1526930111643};\\\", \\\"{x:1292,y:534,t:1526930111659};\\\", \\\"{x:1289,y:537,t:1526930111676};\\\", \\\"{x:1280,y:541,t:1526930111694};\\\", \\\"{x:1277,y:542,t:1526930111709};\\\", \\\"{x:1275,y:543,t:1526930111726};\\\", \\\"{x:1276,y:543,t:1526930111884};\\\", \\\"{x:1279,y:543,t:1526930111892};\\\", \\\"{x:1281,y:543,t:1526930111909};\\\", \\\"{x:1284,y:542,t:1526930111938};\\\", \\\"{x:1285,y:541,t:1526930111946};\\\", \\\"{x:1286,y:541,t:1526930111959};\\\", \\\"{x:1289,y:539,t:1526930111976};\\\", \\\"{x:1291,y:539,t:1526930111993};\\\", \\\"{x:1292,y:538,t:1526930112008};\\\", \\\"{x:1293,y:538,t:1526930112026};\\\", \\\"{x:1297,y:538,t:1526930112043};\\\", \\\"{x:1303,y:540,t:1526930112060};\\\", \\\"{x:1313,y:542,t:1526930112076};\\\", \\\"{x:1328,y:548,t:1526930112093};\\\", \\\"{x:1337,y:549,t:1526930112110};\\\", \\\"{x:1348,y:551,t:1526930112127};\\\", \\\"{x:1356,y:551,t:1526930112143};\\\", \\\"{x:1360,y:552,t:1526930112160};\\\", \\\"{x:1362,y:552,t:1526930112176};\\\", \\\"{x:1363,y:552,t:1526930112194};\\\", \\\"{x:1359,y:552,t:1526930112283};\\\", \\\"{x:1349,y:557,t:1526930112294};\\\", \\\"{x:1323,y:564,t:1526930112310};\\\", \\\"{x:1224,y:585,t:1526930112326};\\\", \\\"{x:1098,y:595,t:1526930112343};\\\", \\\"{x:926,y:620,t:1526930112360};\\\", \\\"{x:755,y:647,t:1526930112378};\\\", \\\"{x:579,y:685,t:1526930112392};\\\", \\\"{x:398,y:721,t:1526930112408};\\\", \\\"{x:226,y:750,t:1526930112426};\\\", \\\"{x:79,y:752,t:1526930112442};\\\", \\\"{x:0,y:749,t:1526930112459};\\\", \\\"{x:0,y:750,t:1526930112498};\\\", \\\"{x:4,y:750,t:1526930112612};\\\", \\\"{x:14,y:750,t:1526930112626};\\\", \\\"{x:38,y:746,t:1526930112642};\\\", \\\"{x:68,y:739,t:1526930112658};\\\", \\\"{x:88,y:736,t:1526930112675};\\\", \\\"{x:112,y:736,t:1526930112692};\\\", \\\"{x:138,y:737,t:1526930112708};\\\", \\\"{x:179,y:744,t:1526930112725};\\\", \\\"{x:228,y:753,t:1526930112742};\\\", \\\"{x:267,y:765,t:1526930112759};\\\", \\\"{x:298,y:779,t:1526930112775};\\\", \\\"{x:314,y:787,t:1526930112792};\\\", \\\"{x:323,y:794,t:1526930112810};\\\", \\\"{x:325,y:795,t:1526930112825};\\\", \\\"{x:326,y:795,t:1526930112842};\\\", \\\"{x:328,y:795,t:1526930112987};\\\", \\\"{x:329,y:795,t:1526930112995};\\\", \\\"{x:331,y:794,t:1526930113009};\\\", \\\"{x:340,y:789,t:1526930113026};\\\", \\\"{x:355,y:784,t:1526930113042};\\\", \\\"{x:381,y:768,t:1526930113059};\\\", \\\"{x:397,y:760,t:1526930113076};\\\", \\\"{x:420,y:746,t:1526930113093};\\\", \\\"{x:440,y:735,t:1526930113109};\\\", \\\"{x:460,y:728,t:1526930113126};\\\", \\\"{x:480,y:723,t:1526930113142};\\\", \\\"{x:494,y:721,t:1526930113161};\\\", \\\"{x:504,y:721,t:1526930113178};\\\", \\\"{x:509,y:721,t:1526930113194};\\\", \\\"{x:511,y:721,t:1526930113211};\\\", \\\"{x:512,y:721,t:1526930113234};\\\", \\\"{x:514,y:721,t:1526930113244};\\\", \\\"{x:517,y:721,t:1526930113261};\\\", \\\"{x:521,y:721,t:1526930113278};\\\", \\\"{x:522,y:721,t:1526930113294};\\\", \\\"{x:525,y:721,t:1526930113311};\\\", \\\"{x:527,y:721,t:1526930113328};\\\", \\\"{x:528,y:721,t:1526930113347};\\\", \\\"{x:528,y:722,t:1526930113435};\\\", \\\"{x:528,y:726,t:1526930113445};\\\", \\\"{x:528,y:730,t:1526930113462};\\\", \\\"{x:528,y:733,t:1526930113478};\\\", \\\"{x:528,y:734,t:1526930113495};\\\", \\\"{x:529,y:734,t:1526930113548};\\\" ] }, { \\\"rt\\\": 28424, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 11, \\\"time_elapsed\\\": 505142, \\\"internal_node_id\\\": \\\"0.0-6.0-1.0\\\", \\\"subject\\\": \\\"WKBNA\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+starts\\\", \\\"q\\\": 7, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"X\\\", \\\"O\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F -X -01 PM-01 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:529,y:735,t:1526930117060};\\\", \\\"{x:529,y:736,t:1526930117068};\\\", \\\"{x:527,y:736,t:1526930117089};\\\", \\\"{x:527,y:737,t:1526930117259};\\\", \\\"{x:527,y:738,t:1526930117740};\\\", \\\"{x:527,y:739,t:1526930117959};\\\", \\\"{x:527,y:740,t:1526930118208};\\\", \\\"{x:533,y:738,t:1526930118671};\\\", \\\"{x:540,y:730,t:1526930118679};\\\", \\\"{x:549,y:722,t:1526930118692};\\\", \\\"{x:572,y:707,t:1526930118710};\\\", \\\"{x:613,y:687,t:1526930118726};\\\", \\\"{x:636,y:679,t:1526930118741};\\\", \\\"{x:663,y:669,t:1526930118766};\\\", \\\"{x:680,y:667,t:1526930118784};\\\", \\\"{x:693,y:664,t:1526930118800};\\\", \\\"{x:704,y:664,t:1526930118817};\\\", \\\"{x:715,y:662,t:1526930118833};\\\", \\\"{x:724,y:660,t:1526930118850};\\\", \\\"{x:739,y:658,t:1526930118867};\\\", \\\"{x:754,y:655,t:1526930118884};\\\", \\\"{x:767,y:654,t:1526930118901};\\\", \\\"{x:785,y:649,t:1526930118917};\\\", \\\"{x:814,y:647,t:1526930118934};\\\", \\\"{x:836,y:646,t:1526930118950};\\\", \\\"{x:859,y:644,t:1526930118967};\\\", \\\"{x:881,y:642,t:1526930118984};\\\", \\\"{x:902,y:642,t:1526930119001};\\\", \\\"{x:917,y:642,t:1526930119017};\\\", \\\"{x:929,y:639,t:1526930119034};\\\", \\\"{x:942,y:636,t:1526930119051};\\\", \\\"{x:952,y:632,t:1526930119067};\\\", \\\"{x:957,y:631,t:1526930119084};\\\", \\\"{x:961,y:630,t:1526930119101};\\\", \\\"{x:963,y:629,t:1526930119118};\\\", \\\"{x:967,y:629,t:1526930119134};\\\", \\\"{x:971,y:629,t:1526930119150};\\\", \\\"{x:979,y:630,t:1526930119167};\\\", \\\"{x:987,y:630,t:1526930119185};\\\", \\\"{x:997,y:630,t:1526930119201};\\\", \\\"{x:1005,y:630,t:1526930119218};\\\", \\\"{x:1011,y:630,t:1526930119234};\\\", \\\"{x:1017,y:629,t:1526930119251};\\\", \\\"{x:1021,y:627,t:1526930119268};\\\", \\\"{x:1027,y:625,t:1526930119285};\\\", \\\"{x:1031,y:623,t:1526930119301};\\\", \\\"{x:1032,y:623,t:1526930119317};\\\", \\\"{x:1035,y:622,t:1526930119335};\\\", \\\"{x:1036,y:622,t:1526930119351};\\\", \\\"{x:1038,y:622,t:1526930119367};\\\", \\\"{x:1041,y:622,t:1526930119384};\\\", \\\"{x:1046,y:623,t:1526930119401};\\\", \\\"{x:1054,y:626,t:1526930119418};\\\", \\\"{x:1072,y:633,t:1526930119435};\\\", \\\"{x:1092,y:642,t:1526930119452};\\\", \\\"{x:1111,y:649,t:1526930119467};\\\", \\\"{x:1117,y:652,t:1526930119484};\\\", \\\"{x:1121,y:654,t:1526930119502};\\\", \\\"{x:1123,y:654,t:1526930119517};\\\", \\\"{x:1124,y:655,t:1526930119535};\\\", \\\"{x:1125,y:656,t:1526930119599};\\\", \\\"{x:1126,y:656,t:1526930119615};\\\", \\\"{x:1126,y:658,t:1526930119622};\\\", \\\"{x:1126,y:659,t:1526930119634};\\\", \\\"{x:1125,y:663,t:1526930119652};\\\", \\\"{x:1123,y:666,t:1526930119667};\\\", \\\"{x:1119,y:671,t:1526930119685};\\\", \\\"{x:1117,y:673,t:1526930119702};\\\", \\\"{x:1115,y:675,t:1526930119717};\\\", \\\"{x:1115,y:676,t:1526930119734};\\\", \\\"{x:1114,y:678,t:1526930119775};\\\", \\\"{x:1114,y:679,t:1526930119798};\\\", \\\"{x:1111,y:682,t:1526930119807};\\\", \\\"{x:1109,y:684,t:1526930119817};\\\", \\\"{x:1106,y:687,t:1526930119834};\\\", \\\"{x:1098,y:691,t:1526930119851};\\\", \\\"{x:1092,y:692,t:1526930119867};\\\", \\\"{x:1085,y:695,t:1526930119884};\\\", \\\"{x:1076,y:697,t:1526930119901};\\\", \\\"{x:1071,y:700,t:1526930119917};\\\", \\\"{x:1065,y:701,t:1526930119934};\\\", \\\"{x:1064,y:703,t:1526930119951};\\\", \\\"{x:1064,y:702,t:1526930120143};\\\", \\\"{x:1064,y:701,t:1526930120151};\\\", \\\"{x:1065,y:697,t:1526930120167};\\\", \\\"{x:1067,y:695,t:1526930120184};\\\", \\\"{x:1068,y:694,t:1526930120202};\\\", \\\"{x:1069,y:694,t:1526930120218};\\\", \\\"{x:1070,y:694,t:1526930120319};\\\", \\\"{x:1071,y:694,t:1526930120519};\\\", \\\"{x:1071,y:696,t:1526930120728};\\\", \\\"{x:1071,y:697,t:1526930120742};\\\", \\\"{x:1072,y:697,t:1526930121535};\\\", \\\"{x:1073,y:697,t:1526930121551};\\\", \\\"{x:1074,y:697,t:1526930121569};\\\", \\\"{x:1075,y:697,t:1526930121631};\\\", \\\"{x:1076,y:697,t:1526930121735};\\\", \\\"{x:1077,y:697,t:1526930121752};\\\", \\\"{x:1078,y:697,t:1526930121769};\\\", \\\"{x:1079,y:697,t:1526930121784};\\\", \\\"{x:1080,y:697,t:1526930122223};\\\", \\\"{x:1081,y:697,t:1526930122303};\\\", \\\"{x:1082,y:697,t:1526930122319};\\\", \\\"{x:1083,y:697,t:1526930122359};\\\", \\\"{x:1084,y:697,t:1526930122369};\\\", \\\"{x:1086,y:697,t:1526930122385};\\\", \\\"{x:1089,y:697,t:1526930122402};\\\", \\\"{x:1092,y:696,t:1526930122418};\\\", \\\"{x:1098,y:695,t:1526930122435};\\\", \\\"{x:1103,y:695,t:1526930122452};\\\", \\\"{x:1105,y:695,t:1526930122468};\\\", \\\"{x:1107,y:695,t:1526930122485};\\\", \\\"{x:1109,y:695,t:1526930122501};\\\", \\\"{x:1111,y:695,t:1526930122518};\\\", \\\"{x:1112,y:696,t:1526930122535};\\\", \\\"{x:1113,y:696,t:1526930122552};\\\", \\\"{x:1113,y:697,t:1526930122575};\\\", \\\"{x:1115,y:697,t:1526930122623};\\\", \\\"{x:1117,y:696,t:1526930122635};\\\", \\\"{x:1119,y:695,t:1526930122652};\\\", \\\"{x:1122,y:694,t:1526930122669};\\\", \\\"{x:1126,y:694,t:1526930122685};\\\", \\\"{x:1129,y:694,t:1526930122701};\\\", \\\"{x:1134,y:694,t:1526930122719};\\\", \\\"{x:1138,y:696,t:1526930122735};\\\", \\\"{x:1143,y:699,t:1526930122752};\\\", \\\"{x:1145,y:700,t:1526930122769};\\\", \\\"{x:1148,y:701,t:1526930122784};\\\", \\\"{x:1150,y:701,t:1526930122801};\\\", \\\"{x:1151,y:701,t:1526930122818};\\\", \\\"{x:1152,y:701,t:1526930122834};\\\", \\\"{x:1154,y:701,t:1526930122851};\\\", \\\"{x:1157,y:701,t:1526930122868};\\\", \\\"{x:1161,y:701,t:1526930122884};\\\", \\\"{x:1164,y:701,t:1526930122901};\\\", \\\"{x:1165,y:701,t:1526930122918};\\\", \\\"{x:1169,y:701,t:1526930122934};\\\", \\\"{x:1173,y:704,t:1526930122951};\\\", \\\"{x:1177,y:707,t:1526930122968};\\\", \\\"{x:1183,y:709,t:1526930122984};\\\", \\\"{x:1191,y:713,t:1526930123001};\\\", \\\"{x:1197,y:714,t:1526930123019};\\\", \\\"{x:1201,y:716,t:1526930123034};\\\", \\\"{x:1203,y:716,t:1526930123051};\\\", \\\"{x:1208,y:715,t:1526930123068};\\\", \\\"{x:1210,y:715,t:1526930123085};\\\", \\\"{x:1212,y:714,t:1526930123102};\\\", \\\"{x:1216,y:712,t:1526930123119};\\\", \\\"{x:1217,y:712,t:1526930123134};\\\", \\\"{x:1218,y:712,t:1526930123208};\\\", \\\"{x:1219,y:712,t:1526930123219};\\\", \\\"{x:1220,y:712,t:1526930123239};\\\", \\\"{x:1221,y:712,t:1526930123287};\\\", \\\"{x:1222,y:712,t:1526930123303};\\\", \\\"{x:1224,y:711,t:1526930123319};\\\", \\\"{x:1226,y:709,t:1526930123334};\\\", \\\"{x:1227,y:709,t:1526930123352};\\\", \\\"{x:1229,y:709,t:1526930123369};\\\", \\\"{x:1230,y:709,t:1526930123384};\\\", \\\"{x:1233,y:709,t:1526930123402};\\\", \\\"{x:1235,y:710,t:1526930123418};\\\", \\\"{x:1238,y:713,t:1526930123435};\\\", \\\"{x:1240,y:714,t:1526930123451};\\\", \\\"{x:1242,y:714,t:1526930123503};\\\", \\\"{x:1244,y:712,t:1526930123519};\\\", \\\"{x:1247,y:710,t:1526930123534};\\\", \\\"{x:1250,y:709,t:1526930123552};\\\", \\\"{x:1252,y:708,t:1526930123569};\\\", \\\"{x:1255,y:708,t:1526930123751};\\\", \\\"{x:1258,y:706,t:1526930123769};\\\", \\\"{x:1262,y:705,t:1526930123785};\\\", \\\"{x:1266,y:705,t:1526930123802};\\\", \\\"{x:1268,y:704,t:1526930123819};\\\", \\\"{x:1269,y:704,t:1526930123835};\\\", \\\"{x:1271,y:704,t:1526930123852};\\\", \\\"{x:1273,y:704,t:1526930123869};\\\", \\\"{x:1276,y:705,t:1526930123885};\\\", \\\"{x:1278,y:706,t:1526930123901};\\\", \\\"{x:1280,y:706,t:1526930123919};\\\", \\\"{x:1282,y:706,t:1526930123935};\\\", \\\"{x:1284,y:706,t:1526930123952};\\\", \\\"{x:1285,y:706,t:1526930123968};\\\", \\\"{x:1287,y:706,t:1526930123985};\\\", \\\"{x:1290,y:706,t:1526930124002};\\\", \\\"{x:1292,y:706,t:1526930124019};\\\", \\\"{x:1293,y:706,t:1526930124035};\\\", \\\"{x:1294,y:706,t:1526930124079};\\\", \\\"{x:1295,y:706,t:1526930124086};\\\", \\\"{x:1296,y:706,t:1526930124103};\\\", \\\"{x:1299,y:706,t:1526930124119};\\\", \\\"{x:1300,y:706,t:1526930124175};\\\", \\\"{x:1301,y:706,t:1526930124190};\\\", \\\"{x:1302,y:706,t:1526930124202};\\\", \\\"{x:1306,y:705,t:1526930124219};\\\", \\\"{x:1309,y:704,t:1526930124235};\\\", \\\"{x:1310,y:703,t:1526930124252};\\\", \\\"{x:1311,y:703,t:1526930124269};\\\", \\\"{x:1312,y:703,t:1526930124286};\\\", \\\"{x:1313,y:703,t:1526930124302};\\\", \\\"{x:1315,y:704,t:1526930124319};\\\", \\\"{x:1316,y:704,t:1526930124334};\\\", \\\"{x:1317,y:705,t:1526930124352};\\\", \\\"{x:1318,y:705,t:1526930124369};\\\", \\\"{x:1320,y:705,t:1526930124407};\\\", \\\"{x:1321,y:705,t:1526930124430};\\\", \\\"{x:1323,y:705,t:1526930124439};\\\", \\\"{x:1324,y:704,t:1526930124452};\\\", \\\"{x:1328,y:704,t:1526930124469};\\\", \\\"{x:1330,y:704,t:1526930124543};\\\", \\\"{x:1331,y:704,t:1526930124551};\\\", \\\"{x:1333,y:704,t:1526930124569};\\\", \\\"{x:1334,y:705,t:1526930124585};\\\", \\\"{x:1336,y:705,t:1526930124663};\\\", \\\"{x:1337,y:705,t:1526930124671};\\\", \\\"{x:1338,y:705,t:1526930125342};\\\", \\\"{x:1339,y:704,t:1526930125358};\\\", \\\"{x:1340,y:704,t:1526930125368};\\\", \\\"{x:1341,y:704,t:1526930125390};\\\", \\\"{x:1342,y:704,t:1526930125623};\\\", \\\"{x:1343,y:703,t:1526930125636};\\\", \\\"{x:1343,y:702,t:1526930126063};\\\", \\\"{x:1347,y:702,t:1526930130289};\\\", \\\"{x:1364,y:702,t:1526930130302};\\\", \\\"{x:1389,y:706,t:1526930130318};\\\", \\\"{x:1411,y:713,t:1526930130336};\\\", \\\"{x:1426,y:719,t:1526930130352};\\\", \\\"{x:1436,y:723,t:1526930130369};\\\", \\\"{x:1442,y:725,t:1526930130385};\\\", \\\"{x:1445,y:725,t:1526930130402};\\\", \\\"{x:1447,y:725,t:1526930130418};\\\", \\\"{x:1449,y:725,t:1526930130435};\\\", \\\"{x:1452,y:725,t:1526930130453};\\\", \\\"{x:1453,y:725,t:1526930130468};\\\", \\\"{x:1456,y:725,t:1526930130485};\\\", \\\"{x:1459,y:725,t:1526930130502};\\\", \\\"{x:1461,y:727,t:1526930130518};\\\", \\\"{x:1466,y:731,t:1526930130536};\\\", \\\"{x:1469,y:736,t:1526930130552};\\\", \\\"{x:1474,y:743,t:1526930130569};\\\", \\\"{x:1479,y:747,t:1526930130586};\\\", \\\"{x:1486,y:751,t:1526930130602};\\\", \\\"{x:1489,y:752,t:1526930130618};\\\", \\\"{x:1492,y:754,t:1526930130636};\\\", \\\"{x:1493,y:754,t:1526930130652};\\\", \\\"{x:1496,y:754,t:1526930130669};\\\", \\\"{x:1497,y:754,t:1526930130693};\\\", \\\"{x:1498,y:754,t:1526930130702};\\\", \\\"{x:1501,y:754,t:1526930130718};\\\", \\\"{x:1502,y:754,t:1526930130741};\\\", \\\"{x:1503,y:754,t:1526930130798};\\\", \\\"{x:1504,y:754,t:1526930130821};\\\", \\\"{x:1505,y:754,t:1526930130951};\\\", \\\"{x:1506,y:755,t:1526930130959};\\\", \\\"{x:1506,y:757,t:1526930130975};\\\", \\\"{x:1506,y:758,t:1526930130986};\\\", \\\"{x:1506,y:759,t:1526930131005};\\\", \\\"{x:1506,y:760,t:1526930131018};\\\", \\\"{x:1506,y:761,t:1526930131036};\\\", \\\"{x:1507,y:761,t:1526930131135};\\\", \\\"{x:1507,y:762,t:1526930131223};\\\", \\\"{x:1507,y:764,t:1526930131236};\\\", \\\"{x:1507,y:766,t:1526930131253};\\\", \\\"{x:1506,y:770,t:1526930131269};\\\", \\\"{x:1506,y:772,t:1526930131286};\\\", \\\"{x:1503,y:776,t:1526930131302};\\\", \\\"{x:1502,y:777,t:1526930131320};\\\", \\\"{x:1502,y:778,t:1526930131351};\\\", \\\"{x:1502,y:779,t:1526930131423};\\\", \\\"{x:1501,y:781,t:1526930131436};\\\", \\\"{x:1500,y:782,t:1526930131453};\\\", \\\"{x:1500,y:786,t:1526930131470};\\\", \\\"{x:1500,y:790,t:1526930131486};\\\", \\\"{x:1499,y:794,t:1526930131503};\\\", \\\"{x:1499,y:795,t:1526930131520};\\\", \\\"{x:1498,y:797,t:1526930131536};\\\", \\\"{x:1496,y:800,t:1526930131553};\\\", \\\"{x:1495,y:803,t:1526930131570};\\\", \\\"{x:1492,y:806,t:1526930131586};\\\", \\\"{x:1490,y:810,t:1526930131603};\\\", \\\"{x:1488,y:812,t:1526930131620};\\\", \\\"{x:1485,y:815,t:1526930131636};\\\", \\\"{x:1485,y:820,t:1526930131653};\\\", \\\"{x:1481,y:827,t:1526930131670};\\\", \\\"{x:1480,y:830,t:1526930131686};\\\", \\\"{x:1477,y:834,t:1526930131703};\\\", \\\"{x:1476,y:835,t:1526930131721};\\\", \\\"{x:1476,y:836,t:1526930131847};\\\", \\\"{x:1476,y:837,t:1526930131855};\\\", \\\"{x:1476,y:839,t:1526930131870};\\\", \\\"{x:1476,y:843,t:1526930131887};\\\", \\\"{x:1476,y:858,t:1526930131903};\\\", \\\"{x:1476,y:873,t:1526930131921};\\\", \\\"{x:1471,y:886,t:1526930131936};\\\", \\\"{x:1467,y:898,t:1526930131953};\\\", \\\"{x:1464,y:913,t:1526930131970};\\\", \\\"{x:1461,y:922,t:1526930131986};\\\", \\\"{x:1456,y:932,t:1526930132003};\\\", \\\"{x:1453,y:942,t:1526930132019};\\\", \\\"{x:1450,y:948,t:1526930132036};\\\", \\\"{x:1449,y:953,t:1526930132054};\\\", \\\"{x:1449,y:956,t:1526930132070};\\\", \\\"{x:1449,y:957,t:1526930132086};\\\", \\\"{x:1449,y:960,t:1526930132103};\\\", \\\"{x:1449,y:963,t:1526930132120};\\\", \\\"{x:1448,y:967,t:1526930132136};\\\", \\\"{x:1447,y:969,t:1526930132154};\\\", \\\"{x:1446,y:972,t:1526930132170};\\\", \\\"{x:1446,y:973,t:1526930132186};\\\", \\\"{x:1445,y:974,t:1526930132203};\\\", \\\"{x:1445,y:975,t:1526930132222};\\\", \\\"{x:1443,y:976,t:1526930132236};\\\", \\\"{x:1440,y:977,t:1526930132253};\\\", \\\"{x:1434,y:980,t:1526930132270};\\\", \\\"{x:1429,y:982,t:1526930132286};\\\", \\\"{x:1425,y:984,t:1526930132303};\\\", \\\"{x:1423,y:985,t:1526930132321};\\\", \\\"{x:1420,y:986,t:1526930132336};\\\", \\\"{x:1417,y:988,t:1526930132353};\\\", \\\"{x:1416,y:988,t:1526930132370};\\\", \\\"{x:1415,y:988,t:1526930132386};\\\", \\\"{x:1414,y:988,t:1526930132403};\\\", \\\"{x:1413,y:988,t:1526930132423};\\\", \\\"{x:1412,y:988,t:1526930132436};\\\", \\\"{x:1410,y:988,t:1526930132453};\\\", \\\"{x:1408,y:987,t:1526930132470};\\\", \\\"{x:1408,y:986,t:1526930132486};\\\", \\\"{x:1407,y:985,t:1526930132503};\\\", \\\"{x:1407,y:984,t:1526930132551};\\\", \\\"{x:1407,y:983,t:1526930132567};\\\", \\\"{x:1407,y:982,t:1526930132590};\\\", \\\"{x:1407,y:981,t:1526930132603};\\\", \\\"{x:1408,y:980,t:1526930132620};\\\", \\\"{x:1408,y:979,t:1526930132636};\\\", \\\"{x:1408,y:978,t:1526930132654};\\\", \\\"{x:1409,y:973,t:1526930132670};\\\", \\\"{x:1411,y:971,t:1526930132686};\\\", \\\"{x:1411,y:968,t:1526930132704};\\\", \\\"{x:1411,y:967,t:1526930132720};\\\", \\\"{x:1412,y:965,t:1526930132837};\\\", \\\"{x:1413,y:961,t:1526930132853};\\\", \\\"{x:1418,y:941,t:1526930132870};\\\", \\\"{x:1423,y:925,t:1526930132885};\\\", \\\"{x:1426,y:915,t:1526930132902};\\\", \\\"{x:1428,y:907,t:1526930132919};\\\", \\\"{x:1431,y:900,t:1526930132936};\\\", \\\"{x:1434,y:894,t:1526930132953};\\\", \\\"{x:1435,y:891,t:1526930132969};\\\", \\\"{x:1435,y:887,t:1526930132986};\\\", \\\"{x:1437,y:885,t:1526930133003};\\\", \\\"{x:1437,y:884,t:1526930133019};\\\", \\\"{x:1438,y:883,t:1526930133036};\\\", \\\"{x:1438,y:882,t:1526930133054};\\\", \\\"{x:1438,y:879,t:1526930133070};\\\", \\\"{x:1438,y:877,t:1526930133086};\\\", \\\"{x:1438,y:875,t:1526930133103};\\\", \\\"{x:1438,y:874,t:1526930133120};\\\", \\\"{x:1438,y:872,t:1526930133137};\\\", \\\"{x:1435,y:872,t:1526930133239};\\\", \\\"{x:1429,y:872,t:1526930133253};\\\", \\\"{x:1401,y:863,t:1526930133270};\\\", \\\"{x:1376,y:855,t:1526930133286};\\\", \\\"{x:1327,y:838,t:1526930133303};\\\", \\\"{x:1253,y:809,t:1526930133320};\\\", \\\"{x:1160,y:773,t:1526930133336};\\\", \\\"{x:1051,y:736,t:1526930133353};\\\", \\\"{x:939,y:697,t:1526930133370};\\\", \\\"{x:823,y:666,t:1526930133386};\\\", \\\"{x:717,y:633,t:1526930133403};\\\", \\\"{x:619,y:614,t:1526930133421};\\\", \\\"{x:557,y:602,t:1526930133436};\\\", \\\"{x:520,y:595,t:1526930133453};\\\", \\\"{x:495,y:592,t:1526930133482};\\\", \\\"{x:493,y:592,t:1526930133499};\\\", \\\"{x:496,y:592,t:1526930133638};\\\", \\\"{x:499,y:594,t:1526930133649};\\\", \\\"{x:505,y:596,t:1526930133666};\\\", \\\"{x:512,y:599,t:1526930133682};\\\", \\\"{x:519,y:603,t:1526930133699};\\\", \\\"{x:525,y:604,t:1526930133715};\\\", \\\"{x:528,y:607,t:1526930133731};\\\", \\\"{x:532,y:607,t:1526930133749};\\\", \\\"{x:537,y:607,t:1526930133765};\\\", \\\"{x:541,y:610,t:1526930133782};\\\", \\\"{x:543,y:610,t:1526930133798};\\\", \\\"{x:544,y:611,t:1526930133838};\\\", \\\"{x:544,y:612,t:1526930133849};\\\", \\\"{x:544,y:616,t:1526930133865};\\\", \\\"{x:544,y:620,t:1526930133881};\\\", \\\"{x:540,y:626,t:1526930133898};\\\", \\\"{x:533,y:630,t:1526930133916};\\\", \\\"{x:523,y:631,t:1526930133932};\\\", \\\"{x:509,y:631,t:1526930133949};\\\", \\\"{x:485,y:622,t:1526930133968};\\\", \\\"{x:467,y:611,t:1526930133981};\\\", \\\"{x:451,y:599,t:1526930133999};\\\", \\\"{x:428,y:588,t:1526930134016};\\\", \\\"{x:415,y:582,t:1526930134031};\\\", \\\"{x:410,y:580,t:1526930134048};\\\", \\\"{x:409,y:580,t:1526930134066};\\\", \\\"{x:410,y:580,t:1526930134174};\\\", \\\"{x:414,y:580,t:1526930134181};\\\", \\\"{x:431,y:578,t:1526930134199};\\\", \\\"{x:448,y:575,t:1526930134215};\\\", \\\"{x:459,y:574,t:1526930134233};\\\", \\\"{x:462,y:574,t:1526930134248};\\\", \\\"{x:463,y:574,t:1526930134265};\\\", \\\"{x:465,y:574,t:1526930134283};\\\", \\\"{x:470,y:575,t:1526930134298};\\\", \\\"{x:478,y:579,t:1526930134315};\\\", \\\"{x:487,y:585,t:1526930134333};\\\", \\\"{x:498,y:590,t:1526930134349};\\\", \\\"{x:521,y:599,t:1526930134367};\\\", \\\"{x:533,y:601,t:1526930134383};\\\", \\\"{x:544,y:603,t:1526930134399};\\\", \\\"{x:558,y:603,t:1526930134416};\\\", \\\"{x:570,y:603,t:1526930134433};\\\", \\\"{x:582,y:601,t:1526930134449};\\\", \\\"{x:592,y:598,t:1526930134466};\\\", \\\"{x:602,y:595,t:1526930134482};\\\", \\\"{x:604,y:594,t:1526930134498};\\\", \\\"{x:606,y:593,t:1526930134516};\\\", \\\"{x:607,y:593,t:1526930134598};\\\", \\\"{x:607,y:592,t:1526930134623};\\\", \\\"{x:607,y:590,t:1526930134633};\\\", \\\"{x:603,y:586,t:1526930134651};\\\", \\\"{x:603,y:583,t:1526930134665};\\\", \\\"{x:602,y:581,t:1526930134683};\\\", \\\"{x:602,y:578,t:1526930134700};\\\", \\\"{x:605,y:577,t:1526930135110};\\\", \\\"{x:618,y:575,t:1526930135117};\\\", \\\"{x:627,y:574,t:1526930135133};\\\", \\\"{x:661,y:574,t:1526930135150};\\\", \\\"{x:681,y:574,t:1526930135167};\\\", \\\"{x:697,y:574,t:1526930135183};\\\", \\\"{x:705,y:576,t:1526930135200};\\\", \\\"{x:713,y:578,t:1526930135217};\\\", \\\"{x:715,y:578,t:1526930135237};\\\", \\\"{x:717,y:578,t:1526930135262};\\\", \\\"{x:720,y:577,t:1526930135269};\\\", \\\"{x:723,y:575,t:1526930135282};\\\", \\\"{x:735,y:570,t:1526930135301};\\\", \\\"{x:746,y:566,t:1526930135316};\\\", \\\"{x:757,y:563,t:1526930135334};\\\", \\\"{x:760,y:562,t:1526930135350};\\\", \\\"{x:761,y:562,t:1526930135367};\\\", \\\"{x:762,y:562,t:1526930135382};\\\", \\\"{x:764,y:562,t:1526930135406};\\\", \\\"{x:765,y:563,t:1526930135423};\\\", \\\"{x:766,y:563,t:1526930135433};\\\", \\\"{x:769,y:565,t:1526930135450};\\\", \\\"{x:774,y:567,t:1526930135467};\\\", \\\"{x:780,y:569,t:1526930135484};\\\", \\\"{x:783,y:570,t:1526930135500};\\\", \\\"{x:787,y:571,t:1526930135517};\\\", \\\"{x:793,y:573,t:1526930135534};\\\", \\\"{x:795,y:574,t:1526930135550};\\\", \\\"{x:796,y:574,t:1526930135567};\\\", \\\"{x:800,y:574,t:1526930135583};\\\", \\\"{x:803,y:576,t:1526930135600};\\\", \\\"{x:806,y:578,t:1526930135617};\\\", \\\"{x:809,y:579,t:1526930135633};\\\", \\\"{x:813,y:580,t:1526930135649};\\\", \\\"{x:817,y:580,t:1526930135667};\\\", \\\"{x:819,y:580,t:1526930135684};\\\", \\\"{x:821,y:580,t:1526930135699};\\\", \\\"{x:822,y:580,t:1526930135717};\\\", \\\"{x:827,y:580,t:1526930135735};\\\", \\\"{x:830,y:580,t:1526930135750};\\\", \\\"{x:831,y:580,t:1526930135766};\\\", \\\"{x:832,y:580,t:1526930135784};\\\", \\\"{x:833,y:580,t:1526930135801};\\\", \\\"{x:834,y:580,t:1526930136455};\\\", \\\"{x:841,y:580,t:1526930136468};\\\", \\\"{x:859,y:587,t:1526930136485};\\\", \\\"{x:885,y:598,t:1526930136503};\\\", \\\"{x:921,y:609,t:1526930136518};\\\", \\\"{x:943,y:614,t:1526930136533};\\\", \\\"{x:960,y:616,t:1526930136551};\\\", \\\"{x:974,y:616,t:1526930136567};\\\", \\\"{x:991,y:616,t:1526930136584};\\\", \\\"{x:1009,y:615,t:1526930136601};\\\", \\\"{x:1034,y:612,t:1526930136618};\\\", \\\"{x:1056,y:612,t:1526930136635};\\\", \\\"{x:1092,y:612,t:1526930136651};\\\", \\\"{x:1143,y:625,t:1526930136668};\\\", \\\"{x:1197,y:641,t:1526930136684};\\\", \\\"{x:1241,y:653,t:1526930136701};\\\", \\\"{x:1300,y:671,t:1526930136718};\\\", \\\"{x:1328,y:678,t:1526930136734};\\\", \\\"{x:1378,y:692,t:1526930136751};\\\", \\\"{x:1441,y:709,t:1526930136768};\\\", \\\"{x:1511,y:719,t:1526930136784};\\\", \\\"{x:1570,y:728,t:1526930136800};\\\", \\\"{x:1619,y:732,t:1526930136817};\\\", \\\"{x:1653,y:736,t:1526930136835};\\\", \\\"{x:1685,y:742,t:1526930136850};\\\", \\\"{x:1710,y:745,t:1526930136868};\\\", \\\"{x:1723,y:750,t:1526930136885};\\\", \\\"{x:1725,y:751,t:1526930136900};\\\", \\\"{x:1724,y:749,t:1526930136959};\\\", \\\"{x:1719,y:746,t:1526930136968};\\\", \\\"{x:1700,y:740,t:1526930136985};\\\", \\\"{x:1670,y:732,t:1526930137001};\\\", \\\"{x:1638,y:727,t:1526930137018};\\\", \\\"{x:1613,y:723,t:1526930137035};\\\", \\\"{x:1596,y:723,t:1526930137051};\\\", \\\"{x:1586,y:724,t:1526930137068};\\\", \\\"{x:1576,y:733,t:1526930137085};\\\", \\\"{x:1571,y:738,t:1526930137101};\\\", \\\"{x:1566,y:747,t:1526930137119};\\\", \\\"{x:1567,y:751,t:1526930137135};\\\", \\\"{x:1567,y:753,t:1526930137151};\\\", \\\"{x:1568,y:754,t:1526930137182};\\\", \\\"{x:1570,y:754,t:1526930137206};\\\", \\\"{x:1572,y:754,t:1526930137222};\\\", \\\"{x:1574,y:754,t:1526930137235};\\\", \\\"{x:1579,y:750,t:1526930137252};\\\", \\\"{x:1583,y:748,t:1526930137268};\\\", \\\"{x:1585,y:747,t:1526930137285};\\\", \\\"{x:1588,y:746,t:1526930137301};\\\", \\\"{x:1589,y:746,t:1526930137487};\\\", \\\"{x:1589,y:745,t:1526930137583};\\\", \\\"{x:1588,y:745,t:1526930137598};\\\", \\\"{x:1587,y:745,t:1526930137783};\\\", \\\"{x:1586,y:746,t:1526930137799};\\\", \\\"{x:1584,y:746,t:1526930137806};\\\", \\\"{x:1584,y:748,t:1526930137818};\\\", \\\"{x:1582,y:749,t:1526930137836};\\\", \\\"{x:1581,y:750,t:1526930137951};\\\", \\\"{x:1580,y:752,t:1526930137969};\\\", \\\"{x:1577,y:757,t:1526930137985};\\\", \\\"{x:1575,y:761,t:1526930138003};\\\", \\\"{x:1573,y:763,t:1526930138019};\\\", \\\"{x:1570,y:767,t:1526930138036};\\\", \\\"{x:1570,y:768,t:1526930138052};\\\", \\\"{x:1568,y:768,t:1526930138111};\\\", \\\"{x:1567,y:768,t:1526930138126};\\\", \\\"{x:1565,y:768,t:1526930138199};\\\", \\\"{x:1563,y:769,t:1526930138222};\\\", \\\"{x:1562,y:770,t:1526930138236};\\\", \\\"{x:1560,y:772,t:1526930138253};\\\", \\\"{x:1559,y:773,t:1526930138268};\\\", \\\"{x:1558,y:774,t:1526930138285};\\\", \\\"{x:1555,y:774,t:1526930141287};\\\", \\\"{x:1547,y:780,t:1526930141302};\\\", \\\"{x:1536,y:785,t:1526930141319};\\\", \\\"{x:1524,y:790,t:1526930141337};\\\", \\\"{x:1511,y:793,t:1526930141352};\\\", \\\"{x:1496,y:797,t:1526930141369};\\\", \\\"{x:1477,y:799,t:1526930141386};\\\", \\\"{x:1443,y:802,t:1526930141402};\\\", \\\"{x:1412,y:803,t:1526930141419};\\\", \\\"{x:1380,y:803,t:1526930141437};\\\", \\\"{x:1349,y:803,t:1526930141453};\\\", \\\"{x:1319,y:803,t:1526930141469};\\\", \\\"{x:1281,y:803,t:1526930141486};\\\", \\\"{x:1264,y:805,t:1526930141502};\\\", \\\"{x:1249,y:810,t:1526930141519};\\\", \\\"{x:1230,y:817,t:1526930141537};\\\", \\\"{x:1217,y:824,t:1526930141554};\\\", \\\"{x:1209,y:825,t:1526930141570};\\\", \\\"{x:1200,y:829,t:1526930141586};\\\", \\\"{x:1193,y:830,t:1526930141604};\\\", \\\"{x:1188,y:832,t:1526930141620};\\\", \\\"{x:1184,y:833,t:1526930141636};\\\", \\\"{x:1183,y:834,t:1526930141783};\\\", \\\"{x:1186,y:835,t:1526930141951};\\\", \\\"{x:1194,y:835,t:1526930141959};\\\", \\\"{x:1205,y:835,t:1526930141970};\\\", \\\"{x:1232,y:835,t:1526930141986};\\\", \\\"{x:1265,y:835,t:1526930142003};\\\", \\\"{x:1302,y:835,t:1526930142019};\\\", \\\"{x:1335,y:835,t:1526930142036};\\\", \\\"{x:1362,y:835,t:1526930142054};\\\", \\\"{x:1384,y:835,t:1526930142070};\\\", \\\"{x:1396,y:835,t:1526930142086};\\\", \\\"{x:1399,y:834,t:1526930142103};\\\", \\\"{x:1402,y:834,t:1526930142119};\\\", \\\"{x:1405,y:832,t:1526930142136};\\\", \\\"{x:1408,y:832,t:1526930142153};\\\", \\\"{x:1413,y:832,t:1526930142169};\\\", \\\"{x:1417,y:833,t:1526930142186};\\\", \\\"{x:1419,y:833,t:1526930142203};\\\", \\\"{x:1420,y:834,t:1526930142219};\\\", \\\"{x:1419,y:835,t:1526930142302};\\\", \\\"{x:1376,y:826,t:1526930142319};\\\", \\\"{x:1290,y:814,t:1526930142336};\\\", \\\"{x:1166,y:796,t:1526930142353};\\\", \\\"{x:1013,y:774,t:1526930142370};\\\", \\\"{x:836,y:745,t:1526930142386};\\\", \\\"{x:664,y:718,t:1526930142402};\\\", \\\"{x:487,y:693,t:1526930142419};\\\", \\\"{x:357,y:674,t:1526930142436};\\\", \\\"{x:254,y:657,t:1526930142455};\\\", \\\"{x:183,y:648,t:1526930142469};\\\", \\\"{x:166,y:643,t:1526930142503};\\\", \\\"{x:165,y:642,t:1526930142525};\\\", \\\"{x:165,y:641,t:1526930142549};\\\", \\\"{x:169,y:642,t:1526930142663};\\\", \\\"{x:179,y:649,t:1526930142672};\\\", \\\"{x:198,y:660,t:1526930142689};\\\", \\\"{x:237,y:675,t:1526930142706};\\\", \\\"{x:282,y:687,t:1526930142723};\\\", \\\"{x:326,y:699,t:1526930142739};\\\", \\\"{x:359,y:708,t:1526930142756};\\\", \\\"{x:387,y:712,t:1526930142773};\\\", \\\"{x:414,y:718,t:1526930142790};\\\", \\\"{x:422,y:718,t:1526930142806};\\\", \\\"{x:423,y:718,t:1526930142823};\\\", \\\"{x:424,y:719,t:1526930142895};\\\", \\\"{x:424,y:720,t:1526930142906};\\\", \\\"{x:425,y:720,t:1526930142966};\\\", \\\"{x:426,y:720,t:1526930142974};\\\", \\\"{x:432,y:720,t:1526930142989};\\\", \\\"{x:442,y:720,t:1526930143005};\\\", \\\"{x:460,y:718,t:1526930143023};\\\", \\\"{x:480,y:715,t:1526930143040};\\\", \\\"{x:502,y:712,t:1526930143056};\\\", \\\"{x:513,y:710,t:1526930143073};\\\", \\\"{x:520,y:709,t:1526930143090};\\\", \\\"{x:522,y:709,t:1526930143107};\\\", \\\"{x:523,y:709,t:1526930143123};\\\", \\\"{x:524,y:708,t:1526930143140};\\\", \\\"{x:524,y:710,t:1526930143326};\\\", \\\"{x:524,y:715,t:1526930143340};\\\", \\\"{x:524,y:722,t:1526930143358};\\\", \\\"{x:524,y:734,t:1526930143373};\\\" ] }, { \\\"rt\\\": 85601, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 12, \\\"time_elapsed\\\": 592138, \\\"internal_node_id\\\": \\\"0.0-6.0-2.0\\\", \\\"subject\\\": \\\"WKBNA\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+contained\\\", \\\"q\\\": 8, \\\"clicks\\\": 0, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-B -B -B -B -11 AM-B -E -E -E -E -F -F \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:528,y:731,t:1526930146887};\\\", \\\"{x:529,y:722,t:1526930146895};\\\", \\\"{x:533,y:702,t:1526930146911};\\\", \\\"{x:541,y:681,t:1526930146928};\\\", \\\"{x:546,y:657,t:1526930146945};\\\", \\\"{x:556,y:635,t:1526930146959};\\\", \\\"{x:562,y:612,t:1526930146977};\\\", \\\"{x:569,y:590,t:1526930146994};\\\", \\\"{x:574,y:574,t:1526930147009};\\\", \\\"{x:580,y:558,t:1526930147027};\\\", \\\"{x:587,y:547,t:1526930147043};\\\", \\\"{x:588,y:541,t:1526930147059};\\\", \\\"{x:591,y:537,t:1526930147076};\\\", \\\"{x:593,y:531,t:1526930147093};\\\", \\\"{x:598,y:524,t:1526930147109};\\\", \\\"{x:604,y:518,t:1526930147126};\\\", \\\"{x:612,y:512,t:1526930147143};\\\", \\\"{x:623,y:505,t:1526930147160};\\\", \\\"{x:638,y:499,t:1526930147176};\\\", \\\"{x:665,y:490,t:1526930147193};\\\", \\\"{x:708,y:483,t:1526930147211};\\\", \\\"{x:751,y:483,t:1526930147226};\\\", \\\"{x:812,y:483,t:1526930147243};\\\", \\\"{x:887,y:483,t:1526930147260};\\\", \\\"{x:954,y:483,t:1526930147276};\\\", \\\"{x:1016,y:486,t:1526930147293};\\\", \\\"{x:1071,y:493,t:1526930147310};\\\", \\\"{x:1089,y:499,t:1526930147326};\\\", \\\"{x:1094,y:500,t:1526930147343};\\\", \\\"{x:1093,y:501,t:1526930147493};\\\", \\\"{x:1089,y:504,t:1526930147509};\\\", \\\"{x:1085,y:506,t:1526930147527};\\\", \\\"{x:1082,y:507,t:1526930147543};\\\", \\\"{x:1081,y:507,t:1526930147582};\\\", \\\"{x:1081,y:505,t:1526930147821};\\\", \\\"{x:1081,y:504,t:1526930147838};\\\", \\\"{x:1081,y:503,t:1526930147845};\\\", \\\"{x:1081,y:501,t:1526930148031};\\\", \\\"{x:1081,y:500,t:1526930148046};\\\", \\\"{x:1081,y:499,t:1526930148471};\\\", \\\"{x:1082,y:498,t:1526930148487};\\\", \\\"{x:1083,y:498,t:1526930148495};\\\", \\\"{x:1085,y:498,t:1526930148518};\\\", \\\"{x:1086,y:498,t:1526930148534};\\\", \\\"{x:1088,y:498,t:1526930148559};\\\", \\\"{x:1089,y:498,t:1526930148566};\\\", \\\"{x:1090,y:498,t:1526930148578};\\\", \\\"{x:1093,y:498,t:1526930148595};\\\", \\\"{x:1094,y:499,t:1526930148611};\\\", \\\"{x:1094,y:500,t:1526930149935};\\\", \\\"{x:1095,y:502,t:1526930149951};\\\", \\\"{x:1096,y:502,t:1526930149963};\\\", \\\"{x:1097,y:503,t:1526930149979};\\\", \\\"{x:1098,y:503,t:1526930149998};\\\", \\\"{x:1099,y:503,t:1526930150013};\\\", \\\"{x:1102,y:503,t:1526930150029};\\\", \\\"{x:1103,y:503,t:1526930150046};\\\", \\\"{x:1107,y:503,t:1526930150063};\\\", \\\"{x:1109,y:503,t:1526930150080};\\\", \\\"{x:1110,y:503,t:1526930150118};\\\", \\\"{x:1111,y:503,t:1526930150142};\\\", \\\"{x:1112,y:503,t:1526930150151};\\\", \\\"{x:1113,y:503,t:1526930150163};\\\", \\\"{x:1115,y:503,t:1526930150179};\\\", \\\"{x:1116,y:505,t:1526930150196};\\\", \\\"{x:1118,y:505,t:1526930150212};\\\", \\\"{x:1119,y:505,t:1526930150255};\\\", \\\"{x:1120,y:505,t:1526930150262};\\\", \\\"{x:1121,y:505,t:1526930150280};\\\", \\\"{x:1125,y:504,t:1526930150296};\\\", \\\"{x:1127,y:504,t:1526930150327};\\\", \\\"{x:1128,y:503,t:1526930150342};\\\", \\\"{x:1129,y:502,t:1526930150471};\\\", \\\"{x:1131,y:502,t:1526930150486};\\\", \\\"{x:1131,y:501,t:1526930150496};\\\", \\\"{x:1132,y:501,t:1526930150513};\\\", \\\"{x:1135,y:499,t:1526930150530};\\\", \\\"{x:1136,y:499,t:1526930150546};\\\", \\\"{x:1138,y:499,t:1526930150563};\\\", \\\"{x:1140,y:499,t:1526930150582};\\\", \\\"{x:1141,y:499,t:1526930150599};\\\", \\\"{x:1143,y:499,t:1526930150613};\\\", \\\"{x:1144,y:500,t:1526930150630};\\\", \\\"{x:1145,y:501,t:1526930150647};\\\", \\\"{x:1146,y:501,t:1526930150703};\\\", \\\"{x:1147,y:501,t:1526930150713};\\\", \\\"{x:1148,y:501,t:1526930150730};\\\", \\\"{x:1151,y:501,t:1526930150746};\\\", \\\"{x:1154,y:501,t:1526930150763};\\\", \\\"{x:1157,y:501,t:1526930150779};\\\", \\\"{x:1161,y:503,t:1526930150797};\\\", \\\"{x:1165,y:504,t:1526930150813};\\\", \\\"{x:1171,y:507,t:1526930150831};\\\", \\\"{x:1177,y:510,t:1526930150846};\\\", \\\"{x:1182,y:511,t:1526930150863};\\\", \\\"{x:1184,y:511,t:1526930150880};\\\", \\\"{x:1185,y:511,t:1526930150897};\\\", \\\"{x:1187,y:511,t:1526930150913};\\\", \\\"{x:1189,y:511,t:1526930150930};\\\", \\\"{x:1193,y:511,t:1526930150947};\\\", \\\"{x:1197,y:511,t:1526930150963};\\\", \\\"{x:1199,y:511,t:1526930150980};\\\", \\\"{x:1201,y:510,t:1526930150997};\\\", \\\"{x:1202,y:510,t:1526930151015};\\\", \\\"{x:1204,y:511,t:1526930151038};\\\", \\\"{x:1205,y:511,t:1526930151047};\\\", \\\"{x:1208,y:513,t:1526930151063};\\\", \\\"{x:1213,y:514,t:1526930151081};\\\", \\\"{x:1217,y:517,t:1526930151097};\\\", \\\"{x:1220,y:517,t:1526930151114};\\\", \\\"{x:1221,y:517,t:1526930151130};\\\", \\\"{x:1223,y:517,t:1526930151147};\\\", \\\"{x:1227,y:517,t:1526930151164};\\\", \\\"{x:1232,y:514,t:1526930151180};\\\", \\\"{x:1235,y:513,t:1526930151196};\\\", \\\"{x:1243,y:512,t:1526930151214};\\\", \\\"{x:1246,y:512,t:1526930151230};\\\", \\\"{x:1250,y:512,t:1526930151246};\\\", \\\"{x:1254,y:512,t:1526930151264};\\\", \\\"{x:1256,y:512,t:1526930151280};\\\", \\\"{x:1259,y:512,t:1526930151296};\\\", \\\"{x:1260,y:512,t:1526930151314};\\\", \\\"{x:1263,y:512,t:1526930151330};\\\", \\\"{x:1266,y:512,t:1526930151347};\\\", \\\"{x:1270,y:512,t:1526930151364};\\\", \\\"{x:1274,y:512,t:1526930151380};\\\", \\\"{x:1280,y:512,t:1526930151397};\\\", \\\"{x:1287,y:510,t:1526930151415};\\\", \\\"{x:1292,y:508,t:1526930151431};\\\", \\\"{x:1295,y:508,t:1526930151447};\\\", \\\"{x:1297,y:508,t:1526930151463};\\\", \\\"{x:1298,y:508,t:1526930151479};\\\", \\\"{x:1299,y:508,t:1526930151501};\\\", \\\"{x:1300,y:508,t:1526930151513};\\\", \\\"{x:1301,y:508,t:1526930151530};\\\", \\\"{x:1303,y:508,t:1526930151547};\\\", \\\"{x:1304,y:508,t:1526930151563};\\\", \\\"{x:1305,y:508,t:1526930151581};\\\", \\\"{x:1307,y:508,t:1526930151596};\\\", \\\"{x:1311,y:508,t:1526930151613};\\\", \\\"{x:1313,y:508,t:1526930151630};\\\", \\\"{x:1315,y:508,t:1526930151646};\\\", \\\"{x:1317,y:508,t:1526930151663};\\\", \\\"{x:1318,y:508,t:1526930151681};\\\", \\\"{x:1319,y:508,t:1526930151697};\\\", \\\"{x:1320,y:508,t:1526930151714};\\\", \\\"{x:1321,y:508,t:1526930151731};\\\", \\\"{x:1325,y:508,t:1526930151747};\\\", \\\"{x:1330,y:510,t:1526930151764};\\\", \\\"{x:1334,y:511,t:1526930151780};\\\", \\\"{x:1339,y:513,t:1526930151797};\\\", \\\"{x:1342,y:513,t:1526930151814};\\\", \\\"{x:1345,y:513,t:1526930151830};\\\", \\\"{x:1347,y:513,t:1526930151847};\\\", \\\"{x:1348,y:513,t:1526930151863};\\\", \\\"{x:1348,y:514,t:1526930151895};\\\", \\\"{x:1349,y:514,t:1526930151919};\\\", \\\"{x:1350,y:515,t:1526930151931};\\\", \\\"{x:1351,y:516,t:1526930151947};\\\", \\\"{x:1352,y:517,t:1526930151964};\\\", \\\"{x:1352,y:518,t:1526930162255};\\\", \\\"{x:1375,y:508,t:1526930162272};\\\", \\\"{x:1395,y:507,t:1526930162290};\\\", \\\"{x:1410,y:511,t:1526930162305};\\\", \\\"{x:1424,y:526,t:1526930162322};\\\", \\\"{x:1434,y:544,t:1526930162340};\\\", \\\"{x:1443,y:570,t:1526930162356};\\\", \\\"{x:1445,y:592,t:1526930162373};\\\", \\\"{x:1445,y:608,t:1526930162390};\\\", \\\"{x:1439,y:618,t:1526930162406};\\\", \\\"{x:1436,y:620,t:1526930162422};\\\", \\\"{x:1435,y:620,t:1526930162454};\\\", \\\"{x:1434,y:620,t:1526930162519};\\\", \\\"{x:1434,y:624,t:1526930162526};\\\", \\\"{x:1434,y:628,t:1526930162539};\\\", \\\"{x:1429,y:650,t:1526930162557};\\\", \\\"{x:1417,y:687,t:1526930162573};\\\", \\\"{x:1403,y:732,t:1526930162589};\\\", \\\"{x:1395,y:762,t:1526930162606};\\\", \\\"{x:1374,y:787,t:1526930162622};\\\", \\\"{x:1373,y:787,t:1526930162639};\\\", \\\"{x:1371,y:787,t:1526930162657};\\\", \\\"{x:1370,y:789,t:1526930162672};\\\", \\\"{x:1370,y:790,t:1526930162689};\\\", \\\"{x:1370,y:788,t:1526930162774};\\\", \\\"{x:1371,y:784,t:1526930162790};\\\", \\\"{x:1380,y:765,t:1526930162806};\\\", \\\"{x:1382,y:760,t:1526930162822};\\\", \\\"{x:1382,y:756,t:1526930162839};\\\", \\\"{x:1383,y:754,t:1526930162855};\\\", \\\"{x:1383,y:751,t:1526930162872};\\\", \\\"{x:1383,y:747,t:1526930162888};\\\", \\\"{x:1381,y:745,t:1526930162906};\\\", \\\"{x:1381,y:743,t:1526930162922};\\\", \\\"{x:1380,y:742,t:1526930162938};\\\", \\\"{x:1380,y:743,t:1526930162997};\\\", \\\"{x:1380,y:746,t:1526930163005};\\\", \\\"{x:1380,y:752,t:1526930163023};\\\", \\\"{x:1378,y:758,t:1526930163039};\\\", \\\"{x:1377,y:760,t:1526930163056};\\\", \\\"{x:1376,y:763,t:1526930163074};\\\", \\\"{x:1376,y:764,t:1526930163090};\\\", \\\"{x:1376,y:766,t:1526930163415};\\\", \\\"{x:1376,y:767,t:1526930163423};\\\", \\\"{x:1376,y:771,t:1526930163441};\\\", \\\"{x:1376,y:774,t:1526930163457};\\\", \\\"{x:1376,y:776,t:1526930163474};\\\", \\\"{x:1375,y:779,t:1526930163490};\\\", \\\"{x:1374,y:779,t:1526930163599};\\\", \\\"{x:1373,y:778,t:1526930163630};\\\", \\\"{x:1372,y:776,t:1526930163759};\\\", \\\"{x:1371,y:776,t:1526930163775};\\\", \\\"{x:1370,y:775,t:1526930163790};\\\", \\\"{x:1369,y:774,t:1526930163807};\\\", \\\"{x:1368,y:774,t:1526930164006};\\\", \\\"{x:1367,y:773,t:1526930164023};\\\", \\\"{x:1367,y:772,t:1526930164255};\\\", \\\"{x:1366,y:771,t:1526930164462};\\\", \\\"{x:1365,y:770,t:1526930164574};\\\", \\\"{x:1364,y:770,t:1526930164590};\\\", \\\"{x:1362,y:770,t:1526930164615};\\\", \\\"{x:1361,y:769,t:1526930164646};\\\", \\\"{x:1360,y:768,t:1526930164658};\\\", \\\"{x:1358,y:766,t:1526930164675};\\\", \\\"{x:1357,y:766,t:1526930164691};\\\", \\\"{x:1356,y:766,t:1526930165029};\\\", \\\"{x:1354,y:766,t:1526930165223};\\\", \\\"{x:1354,y:767,t:1526930165230};\\\", \\\"{x:1354,y:768,t:1526930165591};\\\", \\\"{x:1353,y:766,t:1526930166207};\\\", \\\"{x:1352,y:765,t:1526930166216};\\\", \\\"{x:1352,y:764,t:1526930166225};\\\", \\\"{x:1351,y:762,t:1526930166241};\\\", \\\"{x:1351,y:760,t:1526930166446};\\\", \\\"{x:1350,y:759,t:1526930166462};\\\", \\\"{x:1350,y:758,t:1526930166475};\\\", \\\"{x:1349,y:757,t:1526930166519};\\\", \\\"{x:1347,y:755,t:1526930168022};\\\", \\\"{x:1344,y:753,t:1526930168030};\\\", \\\"{x:1341,y:752,t:1526930168045};\\\", \\\"{x:1337,y:749,t:1526930168061};\\\", \\\"{x:1338,y:749,t:1526930168480};\\\", \\\"{x:1339,y:749,t:1526930168614};\\\", \\\"{x:1340,y:749,t:1526930168638};\\\", \\\"{x:1341,y:749,t:1526930168654};\\\", \\\"{x:1342,y:749,t:1526930168662};\\\", \\\"{x:1342,y:750,t:1526930168775};\\\", \\\"{x:1342,y:751,t:1526930168790};\\\", \\\"{x:1343,y:752,t:1526930168798};\\\", \\\"{x:1343,y:753,t:1526930168811};\\\", \\\"{x:1343,y:754,t:1526930168828};\\\", \\\"{x:1343,y:756,t:1526930168999};\\\", \\\"{x:1343,y:757,t:1526930169014};\\\", \\\"{x:1343,y:759,t:1526930169031};\\\", \\\"{x:1343,y:760,t:1526930169054};\\\", \\\"{x:1343,y:762,t:1526930169182};\\\", \\\"{x:1343,y:763,t:1526930169214};\\\", \\\"{x:1343,y:765,t:1526930169230};\\\", \\\"{x:1343,y:766,t:1526930169246};\\\", \\\"{x:1343,y:767,t:1526930169280};\\\", \\\"{x:1343,y:769,t:1526930169711};\\\", \\\"{x:1343,y:770,t:1526930169734};\\\", \\\"{x:1343,y:771,t:1526930169751};\\\", \\\"{x:1344,y:772,t:1526930169854};\\\", \\\"{x:1344,y:773,t:1526930169886};\\\", \\\"{x:1344,y:774,t:1526930169895};\\\", \\\"{x:1344,y:775,t:1526930169912};\\\", \\\"{x:1344,y:776,t:1526930169929};\\\", \\\"{x:1344,y:777,t:1526930170270};\\\", \\\"{x:1344,y:778,t:1526930170280};\\\", \\\"{x:1347,y:779,t:1526930170295};\\\", \\\"{x:1347,y:781,t:1526930170312};\\\", \\\"{x:1347,y:788,t:1526930170329};\\\", \\\"{x:1348,y:798,t:1526930170345};\\\", \\\"{x:1350,y:808,t:1526930170361};\\\", \\\"{x:1351,y:818,t:1526930170379};\\\", \\\"{x:1351,y:827,t:1526930170396};\\\", \\\"{x:1352,y:834,t:1526930170412};\\\", \\\"{x:1352,y:841,t:1526930170428};\\\", \\\"{x:1352,y:850,t:1526930170445};\\\", \\\"{x:1351,y:853,t:1526930170462};\\\", \\\"{x:1351,y:854,t:1526930170479};\\\", \\\"{x:1351,y:855,t:1526930170533};\\\", \\\"{x:1350,y:856,t:1526930170546};\\\", \\\"{x:1350,y:857,t:1526930170562};\\\", \\\"{x:1350,y:859,t:1526930170578};\\\", \\\"{x:1349,y:859,t:1526930170639};\\\", \\\"{x:1348,y:859,t:1526930170662};\\\", \\\"{x:1347,y:856,t:1526930170682};\\\", \\\"{x:1346,y:855,t:1526930170696};\\\", \\\"{x:1346,y:854,t:1526930170713};\\\", \\\"{x:1346,y:855,t:1526930170790};\\\", \\\"{x:1346,y:858,t:1526930170798};\\\", \\\"{x:1346,y:860,t:1526930170812};\\\", \\\"{x:1346,y:866,t:1526930170829};\\\", \\\"{x:1346,y:875,t:1526930170847};\\\", \\\"{x:1346,y:878,t:1526930170863};\\\", \\\"{x:1345,y:878,t:1526930171070};\\\", \\\"{x:1344,y:876,t:1526930171080};\\\", \\\"{x:1343,y:865,t:1526930171095};\\\", \\\"{x:1340,y:853,t:1526930171112};\\\", \\\"{x:1339,y:841,t:1526930171129};\\\", \\\"{x:1337,y:828,t:1526930171145};\\\", \\\"{x:1335,y:819,t:1526930171162};\\\", \\\"{x:1334,y:811,t:1526930171179};\\\", \\\"{x:1333,y:806,t:1526930171195};\\\", \\\"{x:1333,y:803,t:1526930171212};\\\", \\\"{x:1333,y:801,t:1526930171229};\\\", \\\"{x:1331,y:799,t:1526930171246};\\\", \\\"{x:1331,y:798,t:1526930171262};\\\", \\\"{x:1331,y:797,t:1526930171302};\\\", \\\"{x:1330,y:796,t:1526930171313};\\\", \\\"{x:1329,y:795,t:1526930171330};\\\", \\\"{x:1329,y:792,t:1526930171346};\\\", \\\"{x:1329,y:788,t:1526930171363};\\\", \\\"{x:1328,y:784,t:1526930171380};\\\", \\\"{x:1327,y:782,t:1526930171397};\\\", \\\"{x:1327,y:779,t:1526930171413};\\\", \\\"{x:1327,y:777,t:1526930171566};\\\", \\\"{x:1327,y:775,t:1526930171580};\\\", \\\"{x:1327,y:773,t:1526930171596};\\\", \\\"{x:1327,y:772,t:1526930171613};\\\", \\\"{x:1327,y:770,t:1526930171823};\\\", \\\"{x:1327,y:769,t:1526930171830};\\\", \\\"{x:1327,y:767,t:1526930171854};\\\", \\\"{x:1327,y:768,t:1526930171974};\\\", \\\"{x:1327,y:769,t:1526930171982};\\\", \\\"{x:1327,y:770,t:1526930171997};\\\", \\\"{x:1326,y:771,t:1526930172030};\\\", \\\"{x:1325,y:772,t:1526930172143};\\\", \\\"{x:1325,y:773,t:1526930172150};\\\", \\\"{x:1325,y:775,t:1526930172166};\\\", \\\"{x:1325,y:776,t:1526930172180};\\\", \\\"{x:1324,y:778,t:1526930172197};\\\", \\\"{x:1323,y:782,t:1526930172214};\\\", \\\"{x:1321,y:784,t:1526930172231};\\\", \\\"{x:1321,y:786,t:1526930172246};\\\", \\\"{x:1320,y:787,t:1526930172264};\\\", \\\"{x:1320,y:788,t:1526930172281};\\\", \\\"{x:1320,y:787,t:1526930172454};\\\", \\\"{x:1320,y:785,t:1526930172464};\\\", \\\"{x:1321,y:778,t:1526930172481};\\\", \\\"{x:1322,y:773,t:1526930172496};\\\", \\\"{x:1324,y:769,t:1526930172514};\\\", \\\"{x:1325,y:766,t:1526930172530};\\\", \\\"{x:1326,y:763,t:1526930172547};\\\", \\\"{x:1327,y:760,t:1526930172564};\\\", \\\"{x:1328,y:760,t:1526930172581};\\\", \\\"{x:1328,y:759,t:1526930172598};\\\", \\\"{x:1329,y:758,t:1526930172614};\\\", \\\"{x:1331,y:756,t:1526930172630};\\\", \\\"{x:1333,y:753,t:1526930172647};\\\", \\\"{x:1337,y:747,t:1526930172664};\\\", \\\"{x:1339,y:741,t:1526930172681};\\\", \\\"{x:1344,y:733,t:1526930172697};\\\", \\\"{x:1346,y:726,t:1526930172714};\\\", \\\"{x:1348,y:721,t:1526930172730};\\\", \\\"{x:1349,y:716,t:1526930172747};\\\", \\\"{x:1351,y:712,t:1526930172764};\\\", \\\"{x:1351,y:710,t:1526930172781};\\\", \\\"{x:1351,y:707,t:1526930173174};\\\", \\\"{x:1351,y:706,t:1526930173190};\\\", \\\"{x:1351,y:703,t:1526930173198};\\\", \\\"{x:1351,y:702,t:1526930173230};\\\", \\\"{x:1350,y:703,t:1526930177295};\\\", \\\"{x:1345,y:709,t:1526930177301};\\\", \\\"{x:1338,y:720,t:1526930177318};\\\", \\\"{x:1329,y:732,t:1526930177334};\\\", \\\"{x:1322,y:745,t:1526930177351};\\\", \\\"{x:1315,y:753,t:1526930177368};\\\", \\\"{x:1312,y:758,t:1526930177385};\\\", \\\"{x:1310,y:761,t:1526930177402};\\\", \\\"{x:1309,y:762,t:1526930177430};\\\", \\\"{x:1310,y:763,t:1526930177462};\\\", \\\"{x:1311,y:764,t:1526930177486};\\\", \\\"{x:1312,y:765,t:1526930177502};\\\", \\\"{x:1315,y:767,t:1526930177518};\\\", \\\"{x:1317,y:771,t:1526930177534};\\\", \\\"{x:1320,y:776,t:1526930177550};\\\", \\\"{x:1323,y:779,t:1526930177568};\\\", \\\"{x:1327,y:782,t:1526930177585};\\\", \\\"{x:1334,y:783,t:1526930177601};\\\", \\\"{x:1341,y:783,t:1526930177618};\\\", \\\"{x:1347,y:783,t:1526930177635};\\\", \\\"{x:1351,y:782,t:1526930177651};\\\", \\\"{x:1356,y:779,t:1526930177668};\\\", \\\"{x:1360,y:773,t:1526930177686};\\\", \\\"{x:1363,y:769,t:1526930177701};\\\", \\\"{x:1365,y:765,t:1526930177718};\\\", \\\"{x:1365,y:764,t:1526930177734};\\\", \\\"{x:1365,y:765,t:1526930177836};\\\", \\\"{x:1364,y:765,t:1526930177878};\\\", \\\"{x:1363,y:765,t:1526930177893};\\\", \\\"{x:1362,y:765,t:1526930177909};\\\", \\\"{x:1362,y:764,t:1526930177920};\\\", \\\"{x:1361,y:764,t:1526930178010};\\\", \\\"{x:1360,y:764,t:1526930178025};\\\", \\\"{x:1359,y:764,t:1526930178041};\\\", \\\"{x:1357,y:767,t:1526930178057};\\\", \\\"{x:1356,y:769,t:1526930178072};\\\", \\\"{x:1351,y:781,t:1526930178089};\\\", \\\"{x:1344,y:813,t:1526930178106};\\\", \\\"{x:1339,y:841,t:1526930178121};\\\", \\\"{x:1333,y:861,t:1526930178139};\\\", \\\"{x:1324,y:881,t:1526930178155};\\\", \\\"{x:1311,y:904,t:1526930178172};\\\", \\\"{x:1298,y:927,t:1526930178189};\\\", \\\"{x:1288,y:944,t:1526930178205};\\\", \\\"{x:1280,y:957,t:1526930178222};\\\", \\\"{x:1273,y:969,t:1526930178239};\\\", \\\"{x:1269,y:977,t:1526930178256};\\\", \\\"{x:1263,y:986,t:1526930178273};\\\", \\\"{x:1260,y:989,t:1526930178288};\\\", \\\"{x:1259,y:989,t:1526930178329};\\\", \\\"{x:1258,y:989,t:1526930178345};\\\", \\\"{x:1257,y:989,t:1526930178369};\\\", \\\"{x:1256,y:989,t:1526930178394};\\\", \\\"{x:1255,y:989,t:1526930178409};\\\", \\\"{x:1252,y:988,t:1526930178490};\\\", \\\"{x:1249,y:983,t:1526930178505};\\\", \\\"{x:1245,y:974,t:1526930178523};\\\", \\\"{x:1241,y:965,t:1526930178539};\\\", \\\"{x:1241,y:959,t:1526930178556};\\\", \\\"{x:1241,y:954,t:1526930178573};\\\", \\\"{x:1241,y:951,t:1526930178589};\\\", \\\"{x:1241,y:950,t:1526930178606};\\\", \\\"{x:1241,y:949,t:1526930178623};\\\", \\\"{x:1241,y:946,t:1526930178954};\\\", \\\"{x:1245,y:940,t:1526930178962};\\\", \\\"{x:1250,y:934,t:1526930178973};\\\", \\\"{x:1264,y:919,t:1526930178990};\\\", \\\"{x:1278,y:904,t:1526930179006};\\\", \\\"{x:1288,y:893,t:1526930179022};\\\", \\\"{x:1297,y:885,t:1526930179039};\\\", \\\"{x:1302,y:882,t:1526930179056};\\\", \\\"{x:1304,y:880,t:1526930179073};\\\", \\\"{x:1306,y:880,t:1526930179090};\\\", \\\"{x:1307,y:878,t:1526930179106};\\\", \\\"{x:1310,y:877,t:1526930179122};\\\", \\\"{x:1314,y:874,t:1526930179139};\\\", \\\"{x:1320,y:871,t:1526930179155};\\\", \\\"{x:1327,y:864,t:1526930179173};\\\", \\\"{x:1332,y:857,t:1526930179190};\\\", \\\"{x:1336,y:847,t:1526930179205};\\\", \\\"{x:1340,y:836,t:1526930179223};\\\", \\\"{x:1343,y:825,t:1526930179239};\\\", \\\"{x:1347,y:815,t:1526930179257};\\\", \\\"{x:1349,y:810,t:1526930179273};\\\", \\\"{x:1350,y:807,t:1526930179290};\\\", \\\"{x:1350,y:806,t:1526930179306};\\\", \\\"{x:1350,y:805,t:1526930179323};\\\", \\\"{x:1350,y:804,t:1526930179340};\\\", \\\"{x:1351,y:803,t:1526930179357};\\\", \\\"{x:1351,y:801,t:1526930179372};\\\", \\\"{x:1351,y:797,t:1526930179390};\\\", \\\"{x:1351,y:793,t:1526930179407};\\\", \\\"{x:1350,y:789,t:1526930179423};\\\", \\\"{x:1349,y:785,t:1526930179440};\\\", \\\"{x:1348,y:781,t:1526930179457};\\\", \\\"{x:1347,y:778,t:1526930179473};\\\", \\\"{x:1346,y:774,t:1526930179490};\\\", \\\"{x:1346,y:772,t:1526930179641};\\\", \\\"{x:1346,y:771,t:1526930179657};\\\", \\\"{x:1346,y:766,t:1526930179674};\\\", \\\"{x:1346,y:765,t:1526930179689};\\\", \\\"{x:1346,y:764,t:1526930179707};\\\", \\\"{x:1346,y:763,t:1526930180585};\\\", \\\"{x:1346,y:762,t:1526930180593};\\\", \\\"{x:1345,y:761,t:1526930189922};\\\", \\\"{x:1336,y:757,t:1526930189932};\\\", \\\"{x:1300,y:745,t:1526930189948};\\\", \\\"{x:1244,y:720,t:1526930189966};\\\", \\\"{x:1227,y:714,t:1526930189981};\\\", \\\"{x:1223,y:714,t:1526930189998};\\\", \\\"{x:1221,y:713,t:1526930190016};\\\", \\\"{x:1220,y:711,t:1526930190074};\\\", \\\"{x:1220,y:702,t:1526930190081};\\\", \\\"{x:1220,y:688,t:1526930190098};\\\", \\\"{x:1221,y:676,t:1526930190115};\\\", \\\"{x:1224,y:660,t:1526930190131};\\\", \\\"{x:1224,y:641,t:1526930190149};\\\", \\\"{x:1224,y:621,t:1526930190166};\\\", \\\"{x:1224,y:596,t:1526930190181};\\\", \\\"{x:1219,y:573,t:1526930190199};\\\", \\\"{x:1216,y:555,t:1526930190215};\\\", \\\"{x:1214,y:548,t:1526930190232};\\\", \\\"{x:1212,y:542,t:1526930190248};\\\", \\\"{x:1212,y:541,t:1526930190281};\\\", \\\"{x:1212,y:539,t:1526930190322};\\\", \\\"{x:1212,y:538,t:1526930190332};\\\", \\\"{x:1213,y:533,t:1526930190349};\\\", \\\"{x:1217,y:523,t:1526930190365};\\\", \\\"{x:1223,y:515,t:1526930190381};\\\", \\\"{x:1232,y:506,t:1526930190398};\\\", \\\"{x:1242,y:501,t:1526930190415};\\\", \\\"{x:1250,y:496,t:1526930190431};\\\", \\\"{x:1265,y:492,t:1526930190448};\\\", \\\"{x:1292,y:487,t:1526930190464};\\\", \\\"{x:1310,y:485,t:1526930190482};\\\", \\\"{x:1332,y:481,t:1526930190498};\\\", \\\"{x:1353,y:479,t:1526930190515};\\\", \\\"{x:1373,y:479,t:1526930190531};\\\", \\\"{x:1394,y:479,t:1526930190548};\\\", \\\"{x:1408,y:478,t:1526930190564};\\\", \\\"{x:1424,y:475,t:1526930190582};\\\", \\\"{x:1437,y:474,t:1526930190598};\\\", \\\"{x:1454,y:473,t:1526930190615};\\\", \\\"{x:1474,y:471,t:1526930190632};\\\", \\\"{x:1499,y:471,t:1526930190648};\\\", \\\"{x:1538,y:471,t:1526930190665};\\\", \\\"{x:1569,y:471,t:1526930190684};\\\", \\\"{x:1601,y:471,t:1526930190699};\\\", \\\"{x:1643,y:471,t:1526930190715};\\\", \\\"{x:1685,y:471,t:1526930190732};\\\", \\\"{x:1727,y:471,t:1526930190749};\\\", \\\"{x:1767,y:469,t:1526930190765};\\\", \\\"{x:1804,y:464,t:1526930190782};\\\", \\\"{x:1832,y:461,t:1526930190800};\\\", \\\"{x:1863,y:454,t:1526930190815};\\\", \\\"{x:1885,y:451,t:1526930190832};\\\", \\\"{x:1914,y:450,t:1526930190849};\\\", \\\"{x:1919,y:450,t:1526930190864};\\\", \\\"{x:1919,y:452,t:1526930190896};\\\", \\\"{x:1919,y:455,t:1526930190913};\\\", \\\"{x:1919,y:457,t:1526930190928};\\\", \\\"{x:1919,y:459,t:1526930190937};\\\", \\\"{x:1919,y:462,t:1526930190950};\\\", \\\"{x:1918,y:469,t:1526930190966};\\\", \\\"{x:1901,y:476,t:1526930190984};\\\", \\\"{x:1865,y:488,t:1526930190999};\\\", \\\"{x:1710,y:501,t:1526930191016};\\\", \\\"{x:1581,y:509,t:1526930191033};\\\", \\\"{x:1459,y:509,t:1526930191050};\\\", \\\"{x:1356,y:511,t:1526930191067};\\\", \\\"{x:1283,y:526,t:1526930191084};\\\", \\\"{x:1253,y:532,t:1526930191100};\\\", \\\"{x:1250,y:533,t:1526930191117};\\\", \\\"{x:1249,y:534,t:1526930191145};\\\", \\\"{x:1251,y:536,t:1526930191153};\\\", \\\"{x:1257,y:539,t:1526930191167};\\\", \\\"{x:1271,y:546,t:1526930191183};\\\", \\\"{x:1296,y:554,t:1526930191199};\\\", \\\"{x:1357,y:565,t:1526930191216};\\\", \\\"{x:1433,y:571,t:1526930191234};\\\", \\\"{x:1503,y:571,t:1526930191250};\\\", \\\"{x:1561,y:571,t:1526930191266};\\\", \\\"{x:1601,y:571,t:1526930191283};\\\", \\\"{x:1619,y:570,t:1526930191299};\\\", \\\"{x:1621,y:567,t:1526930191317};\\\", \\\"{x:1622,y:567,t:1526930191334};\\\", \\\"{x:1619,y:565,t:1526930191350};\\\", \\\"{x:1596,y:565,t:1526930191367};\\\", \\\"{x:1552,y:565,t:1526930191383};\\\", \\\"{x:1428,y:576,t:1526930191401};\\\", \\\"{x:1339,y:599,t:1526930191416};\\\", \\\"{x:1260,y:627,t:1526930191434};\\\", \\\"{x:1197,y:655,t:1526930191450};\\\", \\\"{x:1158,y:681,t:1526930191467};\\\", \\\"{x:1140,y:700,t:1526930191485};\\\", \\\"{x:1138,y:711,t:1526930191501};\\\", \\\"{x:1153,y:728,t:1526930191516};\\\", \\\"{x:1197,y:750,t:1526930191533};\\\", \\\"{x:1271,y:778,t:1526930191551};\\\", \\\"{x:1379,y:813,t:1526930191567};\\\", \\\"{x:1499,y:851,t:1526930191583};\\\", \\\"{x:1660,y:881,t:1526930191600};\\\", \\\"{x:1743,y:883,t:1526930191616};\\\", \\\"{x:1818,y:861,t:1526930191634};\\\", \\\"{x:1869,y:822,t:1526930191651};\\\", \\\"{x:1902,y:777,t:1526930191666};\\\", \\\"{x:1919,y:737,t:1526930191684};\\\", \\\"{x:1919,y:708,t:1526930191700};\\\", \\\"{x:1919,y:685,t:1526930191717};\\\", \\\"{x:1914,y:664,t:1526930191733};\\\", \\\"{x:1898,y:643,t:1526930191751};\\\", \\\"{x:1881,y:628,t:1526930191768};\\\", \\\"{x:1845,y:610,t:1526930191784};\\\", \\\"{x:1748,y:591,t:1526930191801};\\\", \\\"{x:1662,y:591,t:1526930191818};\\\", \\\"{x:1575,y:591,t:1526930191833};\\\", \\\"{x:1487,y:591,t:1526930191851};\\\", \\\"{x:1425,y:591,t:1526930191869};\\\", \\\"{x:1389,y:591,t:1526930191884};\\\", \\\"{x:1362,y:593,t:1526930191901};\\\", \\\"{x:1345,y:595,t:1526930191918};\\\", \\\"{x:1333,y:597,t:1526930191934};\\\", \\\"{x:1327,y:600,t:1526930191951};\\\", \\\"{x:1324,y:602,t:1526930191968};\\\", \\\"{x:1320,y:609,t:1526930191984};\\\", \\\"{x:1315,y:628,t:1526930192001};\\\", \\\"{x:1307,y:652,t:1526930192018};\\\", \\\"{x:1303,y:674,t:1526930192035};\\\", \\\"{x:1302,y:694,t:1526930192051};\\\", \\\"{x:1302,y:711,t:1526930192068};\\\", \\\"{x:1308,y:728,t:1526930192084};\\\", \\\"{x:1317,y:743,t:1526930192101};\\\", \\\"{x:1332,y:760,t:1526930192118};\\\", \\\"{x:1343,y:773,t:1526930192134};\\\", \\\"{x:1354,y:786,t:1526930192151};\\\", \\\"{x:1363,y:801,t:1526930192168};\\\", \\\"{x:1374,y:815,t:1526930192185};\\\", \\\"{x:1388,y:830,t:1526930192201};\\\", \\\"{x:1407,y:843,t:1526930192218};\\\", \\\"{x:1424,y:851,t:1526930192235};\\\", \\\"{x:1437,y:863,t:1526930192251};\\\", \\\"{x:1475,y:860,t:1526930192268};\\\", \\\"{x:1541,y:831,t:1526930192285};\\\", \\\"{x:1611,y:782,t:1526930192301};\\\", \\\"{x:1657,y:746,t:1526930192318};\\\", \\\"{x:1688,y:712,t:1526930192335};\\\", \\\"{x:1701,y:686,t:1526930192352};\\\", \\\"{x:1705,y:663,t:1526930192368};\\\", \\\"{x:1703,y:635,t:1526930192385};\\\", \\\"{x:1698,y:619,t:1526930192401};\\\", \\\"{x:1690,y:604,t:1526930192419};\\\", \\\"{x:1683,y:597,t:1526930192435};\\\", \\\"{x:1678,y:594,t:1526930192451};\\\", \\\"{x:1669,y:590,t:1526930192468};\\\", \\\"{x:1661,y:589,t:1526930192485};\\\", \\\"{x:1644,y:586,t:1526930192501};\\\", \\\"{x:1618,y:584,t:1526930192518};\\\", \\\"{x:1573,y:575,t:1526930192535};\\\", \\\"{x:1530,y:562,t:1526930192551};\\\", \\\"{x:1486,y:544,t:1526930192568};\\\", \\\"{x:1435,y:517,t:1526930192586};\\\", \\\"{x:1409,y:498,t:1526930192601};\\\", \\\"{x:1389,y:482,t:1526930192618};\\\", \\\"{x:1376,y:471,t:1526930192635};\\\", \\\"{x:1371,y:464,t:1526930192651};\\\", \\\"{x:1368,y:459,t:1526930192668};\\\", \\\"{x:1366,y:457,t:1526930192685};\\\", \\\"{x:1365,y:457,t:1526930192729};\\\", \\\"{x:1363,y:457,t:1526930192745};\\\", \\\"{x:1362,y:456,t:1526930192770};\\\", \\\"{x:1361,y:461,t:1526930192810};\\\", \\\"{x:1361,y:463,t:1526930192818};\\\", \\\"{x:1368,y:474,t:1526930192836};\\\", \\\"{x:1377,y:484,t:1526930192852};\\\", \\\"{x:1384,y:492,t:1526930192868};\\\", \\\"{x:1394,y:500,t:1526930192885};\\\", \\\"{x:1397,y:504,t:1526930192901};\\\", \\\"{x:1399,y:507,t:1526930192918};\\\", \\\"{x:1399,y:508,t:1526930192934};\\\", \\\"{x:1399,y:510,t:1526930192951};\\\", \\\"{x:1399,y:511,t:1526930192967};\\\", \\\"{x:1399,y:512,t:1526930192984};\\\", \\\"{x:1393,y:512,t:1526930193001};\\\", \\\"{x:1387,y:512,t:1526930193017};\\\", \\\"{x:1375,y:512,t:1526930193034};\\\", \\\"{x:1366,y:508,t:1526930193051};\\\", \\\"{x:1360,y:505,t:1526930193069};\\\", \\\"{x:1357,y:504,t:1526930193085};\\\", \\\"{x:1357,y:506,t:1526930193154};\\\", \\\"{x:1362,y:512,t:1526930193169};\\\", \\\"{x:1369,y:517,t:1526930193185};\\\", \\\"{x:1377,y:523,t:1526930193202};\\\", \\\"{x:1383,y:526,t:1526930193220};\\\", \\\"{x:1390,y:529,t:1526930193236};\\\", \\\"{x:1395,y:531,t:1526930193252};\\\", \\\"{x:1399,y:531,t:1526930193269};\\\", \\\"{x:1403,y:529,t:1526930193285};\\\", \\\"{x:1407,y:526,t:1526930193302};\\\", \\\"{x:1415,y:523,t:1526930193319};\\\", \\\"{x:1425,y:521,t:1526930193335};\\\", \\\"{x:1436,y:521,t:1526930193353};\\\", \\\"{x:1451,y:519,t:1526930193369};\\\", \\\"{x:1456,y:519,t:1526930193386};\\\", \\\"{x:1461,y:519,t:1526930193403};\\\", \\\"{x:1463,y:519,t:1526930193419};\\\", \\\"{x:1465,y:518,t:1526930193458};\\\", \\\"{x:1466,y:516,t:1526930193489};\\\", \\\"{x:1467,y:515,t:1526930193522};\\\", \\\"{x:1469,y:515,t:1526930193594};\\\", \\\"{x:1472,y:515,t:1526930193617};\\\", \\\"{x:1474,y:517,t:1526930193625};\\\", \\\"{x:1477,y:517,t:1526930193637};\\\", \\\"{x:1482,y:519,t:1526930193652};\\\", \\\"{x:1486,y:520,t:1526930193669};\\\", \\\"{x:1487,y:520,t:1526930193686};\\\", \\\"{x:1488,y:520,t:1526930193702};\\\", \\\"{x:1489,y:519,t:1526930193719};\\\", \\\"{x:1490,y:518,t:1526930193736};\\\", \\\"{x:1490,y:517,t:1526930193753};\\\", \\\"{x:1489,y:517,t:1526930193866};\\\", \\\"{x:1488,y:517,t:1526930193874};\\\", \\\"{x:1486,y:517,t:1526930193886};\\\", \\\"{x:1480,y:517,t:1526930193902};\\\", \\\"{x:1475,y:517,t:1526930193919};\\\", \\\"{x:1470,y:516,t:1526930193936};\\\", \\\"{x:1463,y:513,t:1526930193953};\\\", \\\"{x:1462,y:512,t:1526930193969};\\\", \\\"{x:1461,y:511,t:1526930193986};\\\", \\\"{x:1460,y:511,t:1526930194305};\\\", \\\"{x:1460,y:512,t:1526930194319};\\\", \\\"{x:1458,y:513,t:1526930194738};\\\", \\\"{x:1457,y:514,t:1526930194758};\\\", \\\"{x:1454,y:516,t:1526930194770};\\\", \\\"{x:1453,y:516,t:1526930194800};\\\", \\\"{x:1452,y:516,t:1526930194808};\\\", \\\"{x:1451,y:516,t:1526930194819};\\\", \\\"{x:1449,y:513,t:1526930194837};\\\", \\\"{x:1446,y:511,t:1526930194853};\\\", \\\"{x:1445,y:510,t:1526930194920};\\\", \\\"{x:1443,y:510,t:1526930194945};\\\", \\\"{x:1442,y:511,t:1526930194969};\\\", \\\"{x:1440,y:511,t:1526930195138};\\\", \\\"{x:1439,y:511,t:1526930195154};\\\", \\\"{x:1435,y:513,t:1526930195171};\\\", \\\"{x:1431,y:514,t:1526930195187};\\\", \\\"{x:1426,y:516,t:1526930195203};\\\", \\\"{x:1423,y:516,t:1526930195220};\\\", \\\"{x:1421,y:516,t:1526930195238};\\\", \\\"{x:1418,y:516,t:1526930195254};\\\", \\\"{x:1414,y:515,t:1526930195270};\\\", \\\"{x:1410,y:513,t:1526930195287};\\\", \\\"{x:1408,y:512,t:1526930195305};\\\", \\\"{x:1407,y:512,t:1526930195321};\\\", \\\"{x:1405,y:512,t:1526930195354};\\\", \\\"{x:1403,y:512,t:1526930195370};\\\", \\\"{x:1399,y:513,t:1526930195388};\\\", \\\"{x:1396,y:514,t:1526930195404};\\\", \\\"{x:1393,y:515,t:1526930195421};\\\", \\\"{x:1391,y:516,t:1526930195438};\\\", \\\"{x:1389,y:516,t:1526930195454};\\\", \\\"{x:1387,y:516,t:1526930195473};\\\", \\\"{x:1386,y:515,t:1526930195487};\\\", \\\"{x:1383,y:514,t:1526930195505};\\\", \\\"{x:1382,y:513,t:1526930195520};\\\", \\\"{x:1381,y:513,t:1526930195537};\\\", \\\"{x:1380,y:513,t:1526930195602};\\\", \\\"{x:1379,y:513,t:1526930195609};\\\", \\\"{x:1379,y:514,t:1526930195620};\\\", \\\"{x:1377,y:515,t:1526930195641};\\\", \\\"{x:1377,y:516,t:1526930195842};\\\", \\\"{x:1377,y:517,t:1526930196114};\\\", \\\"{x:1377,y:519,t:1526930196298};\\\", \\\"{x:1377,y:522,t:1526930196682};\\\", \\\"{x:1377,y:525,t:1526930196689};\\\", \\\"{x:1373,y:532,t:1526930196704};\\\", \\\"{x:1369,y:536,t:1526930196721};\\\", \\\"{x:1368,y:538,t:1526930196738};\\\", \\\"{x:1368,y:539,t:1526930196768};\\\", \\\"{x:1368,y:540,t:1526930196777};\\\", \\\"{x:1366,y:541,t:1526930196801};\\\", \\\"{x:1365,y:541,t:1526930196817};\\\", \\\"{x:1363,y:541,t:1526930196824};\\\", \\\"{x:1362,y:542,t:1526930196837};\\\", \\\"{x:1360,y:545,t:1526930196855};\\\", \\\"{x:1357,y:549,t:1526930196871};\\\", \\\"{x:1354,y:553,t:1526930196888};\\\", \\\"{x:1349,y:566,t:1526930196905};\\\", \\\"{x:1343,y:578,t:1526930196922};\\\", \\\"{x:1334,y:591,t:1526930196938};\\\", \\\"{x:1326,y:605,t:1526930196956};\\\", \\\"{x:1319,y:617,t:1526930196971};\\\", \\\"{x:1315,y:621,t:1526930196988};\\\", \\\"{x:1313,y:622,t:1526930197005};\\\", \\\"{x:1313,y:624,t:1526930197049};\\\", \\\"{x:1313,y:625,t:1526930197057};\\\", \\\"{x:1314,y:628,t:1526930197072};\\\", \\\"{x:1315,y:638,t:1526930197089};\\\", \\\"{x:1322,y:664,t:1526930197105};\\\", \\\"{x:1325,y:673,t:1526930197123};\\\", \\\"{x:1330,y:686,t:1526930197138};\\\", \\\"{x:1339,y:701,t:1526930197156};\\\", \\\"{x:1345,y:713,t:1526930197172};\\\", \\\"{x:1348,y:719,t:1526930197188};\\\", \\\"{x:1348,y:723,t:1526930197205};\\\", \\\"{x:1347,y:726,t:1526930197222};\\\", \\\"{x:1345,y:727,t:1526930197238};\\\", \\\"{x:1339,y:727,t:1526930197255};\\\", \\\"{x:1332,y:727,t:1526930197273};\\\", \\\"{x:1321,y:727,t:1526930197289};\\\", \\\"{x:1310,y:727,t:1526930197305};\\\", \\\"{x:1304,y:727,t:1526930197322};\\\", \\\"{x:1300,y:727,t:1526930197338};\\\", \\\"{x:1295,y:727,t:1526930197356};\\\", \\\"{x:1289,y:729,t:1526930197372};\\\", \\\"{x:1280,y:734,t:1526930197388};\\\", \\\"{x:1270,y:739,t:1526930197405};\\\", \\\"{x:1262,y:741,t:1526930197422};\\\", \\\"{x:1259,y:742,t:1526930197438};\\\", \\\"{x:1254,y:743,t:1526930197455};\\\", \\\"{x:1253,y:743,t:1526930197473};\\\", \\\"{x:1247,y:745,t:1526930197489};\\\", \\\"{x:1242,y:750,t:1526930197506};\\\", \\\"{x:1239,y:752,t:1526930197522};\\\", \\\"{x:1236,y:754,t:1526930197539};\\\", \\\"{x:1233,y:759,t:1526930197555};\\\", \\\"{x:1227,y:766,t:1526930197572};\\\", \\\"{x:1223,y:774,t:1526930197589};\\\", \\\"{x:1217,y:784,t:1526930197605};\\\", \\\"{x:1213,y:790,t:1526930197623};\\\", \\\"{x:1206,y:796,t:1526930197639};\\\", \\\"{x:1200,y:798,t:1526930197655};\\\", \\\"{x:1192,y:799,t:1526930197672};\\\", \\\"{x:1187,y:799,t:1526930197689};\\\", \\\"{x:1182,y:798,t:1526930197705};\\\", \\\"{x:1182,y:795,t:1526930197723};\\\", \\\"{x:1181,y:793,t:1526930197739};\\\", \\\"{x:1181,y:789,t:1526930197755};\\\", \\\"{x:1181,y:787,t:1526930197772};\\\", \\\"{x:1181,y:785,t:1526930197789};\\\", \\\"{x:1181,y:782,t:1526930197806};\\\", \\\"{x:1182,y:778,t:1526930197823};\\\", \\\"{x:1187,y:772,t:1526930197839};\\\", \\\"{x:1192,y:765,t:1526930197855};\\\", \\\"{x:1195,y:760,t:1526930197872};\\\", \\\"{x:1200,y:752,t:1526930197889};\\\", \\\"{x:1204,y:744,t:1526930197905};\\\", \\\"{x:1208,y:737,t:1526930197922};\\\", \\\"{x:1211,y:728,t:1526930197940};\\\", \\\"{x:1216,y:716,t:1526930197955};\\\", \\\"{x:1222,y:706,t:1526930197973};\\\", \\\"{x:1228,y:697,t:1526930197990};\\\", \\\"{x:1233,y:689,t:1526930198007};\\\", \\\"{x:1237,y:679,t:1526930198022};\\\", \\\"{x:1242,y:674,t:1526930198039};\\\", \\\"{x:1246,y:668,t:1526930198055};\\\", \\\"{x:1250,y:661,t:1526930198073};\\\", \\\"{x:1259,y:644,t:1526930198089};\\\", \\\"{x:1265,y:628,t:1526930198107};\\\", \\\"{x:1272,y:612,t:1526930198123};\\\", \\\"{x:1284,y:597,t:1526930198140};\\\", \\\"{x:1293,y:582,t:1526930198157};\\\", \\\"{x:1304,y:570,t:1526930198173};\\\", \\\"{x:1315,y:558,t:1526930198189};\\\", \\\"{x:1326,y:550,t:1526930198206};\\\", \\\"{x:1332,y:546,t:1526930198222};\\\", \\\"{x:1334,y:544,t:1526930198240};\\\", \\\"{x:1335,y:546,t:1526930198289};\\\", \\\"{x:1335,y:557,t:1526930198306};\\\", \\\"{x:1335,y:574,t:1526930198323};\\\", \\\"{x:1333,y:589,t:1526930198340};\\\", \\\"{x:1327,y:605,t:1526930198356};\\\", \\\"{x:1322,y:620,t:1526930198373};\\\", \\\"{x:1312,y:637,t:1526930198390};\\\", \\\"{x:1303,y:655,t:1526930198406};\\\", \\\"{x:1294,y:673,t:1526930198424};\\\", \\\"{x:1280,y:695,t:1526930198439};\\\", \\\"{x:1271,y:715,t:1526930198457};\\\", \\\"{x:1258,y:746,t:1526930198473};\\\", \\\"{x:1248,y:764,t:1526930198490};\\\", \\\"{x:1240,y:777,t:1526930198506};\\\", \\\"{x:1232,y:789,t:1526930198524};\\\", \\\"{x:1229,y:796,t:1526930198539};\\\", \\\"{x:1228,y:801,t:1526930198556};\\\", \\\"{x:1226,y:805,t:1526930198573};\\\", \\\"{x:1226,y:809,t:1526930198589};\\\", \\\"{x:1226,y:811,t:1526930198606};\\\", \\\"{x:1226,y:812,t:1526930198624};\\\", \\\"{x:1226,y:814,t:1526930198639};\\\", \\\"{x:1226,y:815,t:1526930198697};\\\", \\\"{x:1227,y:815,t:1526930198778};\\\", \\\"{x:1229,y:815,t:1526930198801};\\\", \\\"{x:1230,y:815,t:1526930198817};\\\", \\\"{x:1231,y:815,t:1526930198825};\\\", \\\"{x:1232,y:815,t:1526930198840};\\\", \\\"{x:1234,y:815,t:1526930198856};\\\", \\\"{x:1237,y:817,t:1526930198873};\\\", \\\"{x:1238,y:819,t:1526930198896};\\\", \\\"{x:1238,y:821,t:1526930198912};\\\", \\\"{x:1239,y:822,t:1526930198923};\\\", \\\"{x:1241,y:824,t:1526930198940};\\\", \\\"{x:1244,y:827,t:1526930198955};\\\", \\\"{x:1245,y:828,t:1526930198973};\\\", \\\"{x:1246,y:828,t:1526930199008};\\\", \\\"{x:1248,y:828,t:1526930199025};\\\", \\\"{x:1248,y:827,t:1526930199040};\\\", \\\"{x:1252,y:821,t:1526930199056};\\\", \\\"{x:1254,y:816,t:1526930199073};\\\", \\\"{x:1255,y:816,t:1526930199090};\\\", \\\"{x:1256,y:816,t:1526930199130};\\\", \\\"{x:1257,y:816,t:1526930199145};\\\", \\\"{x:1259,y:816,t:1526930199161};\\\", \\\"{x:1260,y:816,t:1526930199186};\\\", \\\"{x:1263,y:813,t:1526930199226};\\\", \\\"{x:1265,y:811,t:1526930199241};\\\", \\\"{x:1267,y:809,t:1526930199257};\\\", \\\"{x:1269,y:807,t:1526930199281};\\\", \\\"{x:1270,y:807,t:1526930199370};\\\", \\\"{x:1271,y:808,t:1526930199378};\\\", \\\"{x:1271,y:809,t:1526930199391};\\\", \\\"{x:1272,y:810,t:1526930199408};\\\", \\\"{x:1273,y:810,t:1526930199423};\\\", \\\"{x:1275,y:810,t:1526930199440};\\\", \\\"{x:1282,y:805,t:1526930199457};\\\", \\\"{x:1288,y:799,t:1526930199473};\\\", \\\"{x:1293,y:793,t:1526930199491};\\\", \\\"{x:1297,y:786,t:1526930199508};\\\", \\\"{x:1298,y:786,t:1526930199524};\\\", \\\"{x:1298,y:787,t:1526930199777};\\\", \\\"{x:1298,y:789,t:1526930199791};\\\", \\\"{x:1297,y:793,t:1526930199808};\\\", \\\"{x:1297,y:796,t:1526930199824};\\\", \\\"{x:1297,y:798,t:1526930199841};\\\", \\\"{x:1297,y:801,t:1526930199857};\\\", \\\"{x:1298,y:800,t:1526930200034};\\\", \\\"{x:1298,y:799,t:1526930200114};\\\", \\\"{x:1298,y:798,t:1526930200129};\\\", \\\"{x:1298,y:796,t:1526930200142};\\\", \\\"{x:1298,y:794,t:1526930200158};\\\", \\\"{x:1298,y:793,t:1526930200174};\\\", \\\"{x:1298,y:792,t:1526930200191};\\\", \\\"{x:1299,y:791,t:1526930200210};\\\", \\\"{x:1300,y:791,t:1526930200242};\\\", \\\"{x:1301,y:791,t:1526930200346};\\\", \\\"{x:1301,y:792,t:1526930200358};\\\", \\\"{x:1296,y:796,t:1526930200374};\\\", \\\"{x:1285,y:803,t:1526930200391};\\\", \\\"{x:1274,y:808,t:1526930200408};\\\", \\\"{x:1267,y:812,t:1526930200425};\\\", \\\"{x:1263,y:818,t:1526930200441};\\\", \\\"{x:1263,y:822,t:1526930200457};\\\", \\\"{x:1263,y:825,t:1526930200474};\\\", \\\"{x:1261,y:829,t:1526930200492};\\\", \\\"{x:1260,y:831,t:1526930200508};\\\", \\\"{x:1259,y:831,t:1526930200524};\\\", \\\"{x:1258,y:831,t:1526930200698};\\\", \\\"{x:1257,y:831,t:1526930200708};\\\", \\\"{x:1255,y:833,t:1526930200724};\\\", \\\"{x:1254,y:834,t:1526930200742};\\\", \\\"{x:1253,y:834,t:1526930200759};\\\", \\\"{x:1252,y:834,t:1526930200777};\\\", \\\"{x:1251,y:834,t:1526930200794};\\\", \\\"{x:1249,y:833,t:1526930200809};\\\", \\\"{x:1249,y:832,t:1526930200825};\\\", \\\"{x:1248,y:831,t:1526930200841};\\\", \\\"{x:1248,y:829,t:1526930200977};\\\", \\\"{x:1248,y:827,t:1526930200991};\\\", \\\"{x:1248,y:822,t:1526930201008};\\\", \\\"{x:1251,y:812,t:1526930201025};\\\", \\\"{x:1253,y:806,t:1526930201041};\\\", \\\"{x:1256,y:799,t:1526930201058};\\\", \\\"{x:1259,y:795,t:1526930201076};\\\", \\\"{x:1261,y:793,t:1526930201092};\\\", \\\"{x:1263,y:791,t:1526930201108};\\\", \\\"{x:1265,y:790,t:1526930201137};\\\", \\\"{x:1266,y:789,t:1526930201154};\\\", \\\"{x:1268,y:788,t:1526930201177};\\\", \\\"{x:1269,y:786,t:1526930201192};\\\", \\\"{x:1270,y:784,t:1526930201208};\\\", \\\"{x:1273,y:775,t:1526930201225};\\\", \\\"{x:1274,y:770,t:1526930201242};\\\", \\\"{x:1275,y:768,t:1526930201259};\\\", \\\"{x:1276,y:765,t:1526930201276};\\\", \\\"{x:1277,y:764,t:1526930201291};\\\", \\\"{x:1278,y:764,t:1526930201353};\\\", \\\"{x:1279,y:764,t:1526930201369};\\\", \\\"{x:1281,y:763,t:1526930201386};\\\", \\\"{x:1281,y:762,t:1526930201401};\\\", \\\"{x:1281,y:761,t:1526930201417};\\\", \\\"{x:1283,y:758,t:1526930201425};\\\", \\\"{x:1283,y:756,t:1526930201442};\\\", \\\"{x:1283,y:753,t:1526930201459};\\\", \\\"{x:1283,y:750,t:1526930201476};\\\", \\\"{x:1283,y:749,t:1526930201492};\\\", \\\"{x:1283,y:748,t:1526930201509};\\\", \\\"{x:1283,y:749,t:1526930201769};\\\", \\\"{x:1283,y:751,t:1526930201785};\\\", \\\"{x:1283,y:752,t:1526930201793};\\\", \\\"{x:1282,y:754,t:1526930201809};\\\", \\\"{x:1281,y:757,t:1526930201826};\\\", \\\"{x:1279,y:758,t:1526930201842};\\\", \\\"{x:1279,y:759,t:1526930201859};\\\", \\\"{x:1276,y:761,t:1526930201876};\\\", \\\"{x:1275,y:762,t:1526930201892};\\\", \\\"{x:1274,y:762,t:1526930201909};\\\", \\\"{x:1273,y:763,t:1526930201926};\\\", \\\"{x:1271,y:767,t:1526930201943};\\\", \\\"{x:1269,y:772,t:1526930201959};\\\", \\\"{x:1266,y:776,t:1526930201975};\\\", \\\"{x:1263,y:782,t:1526930201993};\\\", \\\"{x:1260,y:789,t:1526930202010};\\\", \\\"{x:1257,y:792,t:1526930202025};\\\", \\\"{x:1256,y:795,t:1526930202043};\\\", \\\"{x:1255,y:795,t:1526930202060};\\\", \\\"{x:1255,y:796,t:1526930202146};\\\", \\\"{x:1254,y:797,t:1526930202160};\\\", \\\"{x:1254,y:798,t:1526930202176};\\\", \\\"{x:1250,y:804,t:1526930202193};\\\", \\\"{x:1248,y:807,t:1526930202209};\\\", \\\"{x:1245,y:812,t:1526930202226};\\\", \\\"{x:1242,y:815,t:1526930202243};\\\", \\\"{x:1239,y:817,t:1526930202260};\\\", \\\"{x:1238,y:819,t:1526930202276};\\\", \\\"{x:1238,y:820,t:1526930202418};\\\", \\\"{x:1237,y:821,t:1526930202427};\\\", \\\"{x:1236,y:822,t:1526930202443};\\\", \\\"{x:1234,y:827,t:1526930202460};\\\", \\\"{x:1233,y:829,t:1526930202477};\\\", \\\"{x:1232,y:830,t:1526930202493};\\\", \\\"{x:1231,y:830,t:1526930202537};\\\", \\\"{x:1229,y:830,t:1526930202553};\\\", \\\"{x:1227,y:830,t:1526930202569};\\\", \\\"{x:1226,y:830,t:1526930202577};\\\", \\\"{x:1225,y:829,t:1526930202593};\\\", \\\"{x:1224,y:828,t:1526930202610};\\\", \\\"{x:1223,y:828,t:1526930202738};\\\", \\\"{x:1223,y:826,t:1526930202745};\\\", \\\"{x:1223,y:825,t:1526930202759};\\\", \\\"{x:1223,y:822,t:1526930202777};\\\", \\\"{x:1225,y:816,t:1526930202793};\\\", \\\"{x:1226,y:815,t:1526930202810};\\\", \\\"{x:1228,y:812,t:1526930202827};\\\", \\\"{x:1229,y:810,t:1526930202844};\\\", \\\"{x:1230,y:808,t:1526930202859};\\\", \\\"{x:1233,y:806,t:1526930202876};\\\", \\\"{x:1235,y:805,t:1526930202893};\\\", \\\"{x:1237,y:802,t:1526930202909};\\\", \\\"{x:1237,y:800,t:1526930202926};\\\", \\\"{x:1239,y:794,t:1526930202943};\\\", \\\"{x:1247,y:779,t:1526930202959};\\\", \\\"{x:1253,y:766,t:1526930202976};\\\", \\\"{x:1264,y:745,t:1526930202992};\\\", \\\"{x:1271,y:732,t:1526930203009};\\\", \\\"{x:1279,y:718,t:1526930203026};\\\", \\\"{x:1285,y:707,t:1526930203043};\\\", \\\"{x:1292,y:695,t:1526930203060};\\\", \\\"{x:1298,y:688,t:1526930203076};\\\", \\\"{x:1303,y:680,t:1526930203094};\\\", \\\"{x:1306,y:673,t:1526930203109};\\\", \\\"{x:1309,y:665,t:1526930203126};\\\", \\\"{x:1312,y:653,t:1526930203144};\\\", \\\"{x:1314,y:641,t:1526930203160};\\\", \\\"{x:1316,y:632,t:1526930203176};\\\", \\\"{x:1318,y:616,t:1526930203194};\\\", \\\"{x:1318,y:610,t:1526930203209};\\\", \\\"{x:1318,y:604,t:1526930203227};\\\", \\\"{x:1318,y:598,t:1526930203243};\\\", \\\"{x:1318,y:593,t:1526930203260};\\\", \\\"{x:1317,y:589,t:1526930203277};\\\", \\\"{x:1317,y:585,t:1526930203293};\\\", \\\"{x:1317,y:582,t:1526930203310};\\\", \\\"{x:1317,y:581,t:1526930203327};\\\", \\\"{x:1317,y:578,t:1526930203344};\\\", \\\"{x:1317,y:574,t:1526930203361};\\\", \\\"{x:1317,y:568,t:1526930203377};\\\", \\\"{x:1316,y:564,t:1526930203393};\\\", \\\"{x:1315,y:559,t:1526930203410};\\\", \\\"{x:1315,y:556,t:1526930203426};\\\", \\\"{x:1312,y:552,t:1526930203443};\\\", \\\"{x:1312,y:548,t:1526930203460};\\\", \\\"{x:1311,y:545,t:1526930203476};\\\", \\\"{x:1310,y:545,t:1526930203513};\\\", \\\"{x:1310,y:544,t:1526930203552};\\\", \\\"{x:1309,y:543,t:1526930203568};\\\", \\\"{x:1307,y:542,t:1526930203576};\\\", \\\"{x:1302,y:541,t:1526930203593};\\\", \\\"{x:1291,y:536,t:1526930203611};\\\", \\\"{x:1279,y:531,t:1526930203628};\\\", \\\"{x:1269,y:527,t:1526930203643};\\\", \\\"{x:1263,y:524,t:1526930203660};\\\", \\\"{x:1259,y:522,t:1526930203677};\\\", \\\"{x:1256,y:521,t:1526930203693};\\\", \\\"{x:1255,y:521,t:1526930203762};\\\", \\\"{x:1253,y:521,t:1526930203785};\\\", \\\"{x:1252,y:522,t:1526930203809};\\\", \\\"{x:1252,y:523,t:1526930203828};\\\", \\\"{x:1252,y:524,t:1526930203906};\\\", \\\"{x:1252,y:526,t:1526930203929};\\\", \\\"{x:1252,y:527,t:1526930203944};\\\", \\\"{x:1253,y:530,t:1526930203960};\\\", \\\"{x:1253,y:533,t:1526930203978};\\\", \\\"{x:1253,y:534,t:1526930203993};\\\", \\\"{x:1254,y:536,t:1526930204010};\\\", \\\"{x:1255,y:537,t:1526930204048};\\\", \\\"{x:1255,y:538,t:1526930204225};\\\", \\\"{x:1256,y:538,t:1526930204233};\\\", \\\"{x:1256,y:539,t:1526930204442};\\\", \\\"{x:1256,y:540,t:1526930204457};\\\", \\\"{x:1256,y:541,t:1526930204602};\\\", \\\"{x:1256,y:542,t:1526930204612};\\\", \\\"{x:1259,y:544,t:1526930204628};\\\", \\\"{x:1262,y:548,t:1526930204644};\\\", \\\"{x:1269,y:553,t:1526930204662};\\\", \\\"{x:1278,y:559,t:1526930204678};\\\", \\\"{x:1289,y:566,t:1526930204694};\\\", \\\"{x:1292,y:569,t:1526930204711};\\\", \\\"{x:1294,y:569,t:1526930204727};\\\", \\\"{x:1296,y:570,t:1526930204744};\\\", \\\"{x:1297,y:570,t:1526930204776};\\\", \\\"{x:1297,y:571,t:1526930204905};\\\", \\\"{x:1298,y:571,t:1526930205209};\\\", \\\"{x:1299,y:571,t:1526930205313};\\\", \\\"{x:1300,y:572,t:1526930205337};\\\", \\\"{x:1300,y:573,t:1526930205353};\\\", \\\"{x:1300,y:574,t:1526930205362};\\\", \\\"{x:1298,y:574,t:1526930205433};\\\", \\\"{x:1298,y:572,t:1526930205650};\\\", \\\"{x:1298,y:570,t:1526930205665};\\\", \\\"{x:1298,y:569,t:1526930205682};\\\", \\\"{x:1298,y:568,t:1526930205825};\\\", \\\"{x:1298,y:567,t:1526930205834};\\\", \\\"{x:1297,y:565,t:1526930205846};\\\", \\\"{x:1297,y:562,t:1526930205862};\\\", \\\"{x:1297,y:561,t:1526930205879};\\\", \\\"{x:1296,y:560,t:1526930205896};\\\", \\\"{x:1296,y:559,t:1526930206081};\\\", \\\"{x:1296,y:558,t:1526930206096};\\\", \\\"{x:1295,y:558,t:1526930206834};\\\", \\\"{x:1294,y:558,t:1526930206857};\\\", \\\"{x:1293,y:558,t:1526930206865};\\\", \\\"{x:1292,y:558,t:1526930206905};\\\", \\\"{x:1291,y:556,t:1526930206921};\\\", \\\"{x:1290,y:556,t:1526930206930};\\\", \\\"{x:1289,y:551,t:1526930206947};\\\", \\\"{x:1287,y:548,t:1526930206963};\\\", \\\"{x:1287,y:546,t:1526930206980};\\\", \\\"{x:1286,y:545,t:1526930206997};\\\", \\\"{x:1286,y:544,t:1526930207013};\\\", \\\"{x:1285,y:544,t:1526930207266};\\\", \\\"{x:1285,y:545,t:1526930207280};\\\", \\\"{x:1284,y:548,t:1526930207297};\\\", \\\"{x:1283,y:552,t:1526930207313};\\\", \\\"{x:1281,y:554,t:1526930207330};\\\", \\\"{x:1281,y:555,t:1526930207473};\\\", \\\"{x:1281,y:556,t:1526930207488};\\\", \\\"{x:1280,y:558,t:1526930207498};\\\", \\\"{x:1280,y:559,t:1526930207513};\\\", \\\"{x:1280,y:560,t:1526930207537};\\\", \\\"{x:1279,y:561,t:1526930207593};\\\", \\\"{x:1278,y:561,t:1526930207721};\\\", \\\"{x:1278,y:562,t:1526930207737};\\\", \\\"{x:1278,y:564,t:1526930207746};\\\", \\\"{x:1278,y:566,t:1526930208162};\\\", \\\"{x:1278,y:567,t:1526930208169};\\\", \\\"{x:1277,y:568,t:1526930208182};\\\", \\\"{x:1277,y:570,t:1526930208198};\\\", \\\"{x:1277,y:571,t:1526930208214};\\\", \\\"{x:1276,y:571,t:1526930213344};\\\", \\\"{x:1264,y:572,t:1526930213352};\\\", \\\"{x:1238,y:574,t:1526930213367};\\\", \\\"{x:1115,y:588,t:1526930213385};\\\", \\\"{x:1018,y:600,t:1526930213402};\\\", \\\"{x:911,y:610,t:1526930213418};\\\", \\\"{x:828,y:619,t:1526930213435};\\\", \\\"{x:783,y:626,t:1526930213452};\\\", \\\"{x:766,y:630,t:1526930213468};\\\", \\\"{x:757,y:635,t:1526930213486};\\\", \\\"{x:752,y:639,t:1526930213501};\\\", \\\"{x:747,y:644,t:1526930213518};\\\", \\\"{x:740,y:654,t:1526930213535};\\\", \\\"{x:736,y:660,t:1526930213551};\\\", \\\"{x:733,y:663,t:1526930213568};\\\", \\\"{x:731,y:666,t:1526930213585};\\\", \\\"{x:727,y:672,t:1526930213603};\\\", \\\"{x:718,y:681,t:1526930213619};\\\", \\\"{x:701,y:694,t:1526930213636};\\\", \\\"{x:673,y:706,t:1526930213652};\\\", \\\"{x:649,y:715,t:1526930213668};\\\", \\\"{x:619,y:722,t:1526930213686};\\\", \\\"{x:592,y:728,t:1526930213703};\\\", \\\"{x:567,y:728,t:1526930213718};\\\", \\\"{x:548,y:728,t:1526930213737};\\\", \\\"{x:530,y:727,t:1526930213751};\\\", \\\"{x:526,y:726,t:1526930213769};\\\", \\\"{x:524,y:726,t:1526930213785};\\\", \\\"{x:522,y:726,t:1526930213802};\\\", \\\"{x:520,y:724,t:1526930213818};\\\", \\\"{x:519,y:724,t:1526930213836};\\\", \\\"{x:517,y:725,t:1526930213853};\\\", \\\"{x:516,y:726,t:1526930213868};\\\", \\\"{x:515,y:726,t:1526930213885};\\\", \\\"{x:514,y:727,t:1526930213903};\\\", \\\"{x:513,y:728,t:1526930213919};\\\", \\\"{x:512,y:729,t:1526930214120};\\\", \\\"{x:512,y:731,t:1526930214538};\\\", \\\"{x:512,y:729,t:1526930214920};\\\", \\\"{x:515,y:728,t:1526930214936};\\\", \\\"{x:518,y:727,t:1526930214953};\\\", \\\"{x:524,y:723,t:1526930214969};\\\", \\\"{x:529,y:719,t:1526930214987};\\\", \\\"{x:535,y:718,t:1526930215003};\\\", \\\"{x:547,y:713,t:1526930215020};\\\", \\\"{x:575,y:697,t:1526930215036};\\\", \\\"{x:616,y:670,t:1526930215053};\\\", \\\"{x:675,y:643,t:1526930215069};\\\", \\\"{x:730,y:619,t:1526930215087};\\\", \\\"{x:781,y:604,t:1526930215103};\\\", \\\"{x:820,y:598,t:1526930215121};\\\", \\\"{x:866,y:593,t:1526930215137};\\\", \\\"{x:885,y:592,t:1526930215154};\\\", \\\"{x:900,y:592,t:1526930215170};\\\", \\\"{x:912,y:594,t:1526930215187};\\\", \\\"{x:925,y:598,t:1526930215203};\\\", \\\"{x:935,y:600,t:1526930215219};\\\", \\\"{x:944,y:600,t:1526930215237};\\\", \\\"{x:953,y:600,t:1526930215253};\\\", \\\"{x:962,y:600,t:1526930215269};\\\", \\\"{x:974,y:600,t:1526930215287};\\\", \\\"{x:989,y:600,t:1526930215304};\\\", \\\"{x:1004,y:600,t:1526930215320};\\\", \\\"{x:1027,y:603,t:1526930215337};\\\", \\\"{x:1040,y:605,t:1526930215354};\\\", \\\"{x:1051,y:609,t:1526930215370};\\\", \\\"{x:1067,y:614,t:1526930215387};\\\", \\\"{x:1084,y:620,t:1526930215404};\\\", \\\"{x:1106,y:623,t:1526930215420};\\\", \\\"{x:1127,y:624,t:1526930215437};\\\", \\\"{x:1147,y:624,t:1526930215454};\\\", \\\"{x:1163,y:622,t:1526930215470};\\\", \\\"{x:1178,y:617,t:1526930215486};\\\", \\\"{x:1195,y:608,t:1526930215504};\\\", \\\"{x:1209,y:600,t:1526930215520};\\\", \\\"{x:1239,y:581,t:1526930215537};\\\", \\\"{x:1258,y:570,t:1526930215554};\\\", \\\"{x:1268,y:565,t:1526930215570};\\\", \\\"{x:1274,y:562,t:1526930215587};\\\", \\\"{x:1275,y:561,t:1526930215745};\\\", \\\"{x:1276,y:561,t:1526930215896};\\\", \\\"{x:1276,y:562,t:1526930216040};\\\", \\\"{x:1277,y:562,t:1526930216053};\\\", \\\"{x:1277,y:563,t:1526930216072};\\\", \\\"{x:1277,y:564,t:1526930216086};\\\", \\\"{x:1279,y:564,t:1526930216218};\\\", \\\"{x:1280,y:564,t:1526930216369};\\\", \\\"{x:1281,y:564,t:1526930216376};\\\", \\\"{x:1281,y:563,t:1526930216393};\\\", \\\"{x:1284,y:559,t:1526930217017};\\\", \\\"{x:1285,y:558,t:1526930217050};\\\", \\\"{x:1286,y:558,t:1526930217625};\\\", \\\"{x:1287,y:558,t:1526930217697};\\\", \\\"{x:1288,y:558,t:1526930217753};\\\", \\\"{x:1289,y:559,t:1526930217772};\\\", \\\"{x:1290,y:560,t:1526930217788};\\\", \\\"{x:1291,y:563,t:1526930222402};\\\", \\\"{x:1291,y:568,t:1526930222409};\\\", \\\"{x:1291,y:572,t:1526930222422};\\\", \\\"{x:1294,y:581,t:1526930222439};\\\", \\\"{x:1296,y:589,t:1526930222455};\\\", \\\"{x:1300,y:597,t:1526930222473};\\\", \\\"{x:1304,y:603,t:1526930222488};\\\", \\\"{x:1307,y:609,t:1526930222506};\\\", \\\"{x:1310,y:615,t:1526930222522};\\\", \\\"{x:1315,y:626,t:1526930222539};\\\", \\\"{x:1322,y:639,t:1526930222556};\\\", \\\"{x:1325,y:653,t:1526930222573};\\\", \\\"{x:1330,y:668,t:1526930222589};\\\", \\\"{x:1336,y:677,t:1526930222605};\\\", \\\"{x:1339,y:684,t:1526930222622};\\\", \\\"{x:1342,y:691,t:1526930222639};\\\", \\\"{x:1344,y:693,t:1526930222656};\\\", \\\"{x:1344,y:695,t:1526930222672};\\\", \\\"{x:1346,y:695,t:1526930222697};\\\", \\\"{x:1347,y:696,t:1526930222729};\\\", \\\"{x:1348,y:697,t:1526930222745};\\\", \\\"{x:1349,y:698,t:1526930222755};\\\", \\\"{x:1350,y:702,t:1526930222774};\\\", \\\"{x:1351,y:710,t:1526930222790};\\\", \\\"{x:1352,y:718,t:1526930222805};\\\", \\\"{x:1355,y:731,t:1526930222823};\\\", \\\"{x:1357,y:742,t:1526930222839};\\\", \\\"{x:1358,y:747,t:1526930222856};\\\", \\\"{x:1359,y:752,t:1526930222873};\\\", \\\"{x:1359,y:753,t:1526930223001};\\\", \\\"{x:1359,y:756,t:1526930223008};\\\", \\\"{x:1359,y:757,t:1526930223024};\\\", \\\"{x:1359,y:760,t:1526930223039};\\\", \\\"{x:1359,y:762,t:1526930223055};\\\", \\\"{x:1359,y:766,t:1526930223072};\\\", \\\"{x:1359,y:767,t:1526930223089};\\\", \\\"{x:1359,y:769,t:1526930223490};\\\", \\\"{x:1359,y:770,t:1526930223506};\\\", \\\"{x:1360,y:769,t:1526930223841};\\\", \\\"{x:1360,y:765,t:1526930223857};\\\", \\\"{x:1360,y:764,t:1526930223873};\\\", \\\"{x:1360,y:763,t:1526930223890};\\\", \\\"{x:1360,y:762,t:1526930223970};\\\", \\\"{x:1360,y:760,t:1526930223977};\\\", \\\"{x:1360,y:757,t:1526930223989};\\\", \\\"{x:1360,y:748,t:1526930224006};\\\", \\\"{x:1360,y:735,t:1526930224023};\\\", \\\"{x:1359,y:724,t:1526930224040};\\\", \\\"{x:1358,y:716,t:1526930224057};\\\", \\\"{x:1358,y:714,t:1526930224072};\\\", \\\"{x:1357,y:712,t:1526930224089};\\\", \\\"{x:1357,y:711,t:1526930224106};\\\", \\\"{x:1357,y:709,t:1526930224122};\\\", \\\"{x:1357,y:708,t:1526930224140};\\\", \\\"{x:1357,y:706,t:1526930224157};\\\", \\\"{x:1356,y:704,t:1526930224217};\\\", \\\"{x:1356,y:703,t:1526930224224};\\\", \\\"{x:1356,y:701,t:1526930224241};\\\", \\\"{x:1355,y:698,t:1526930224257};\\\", \\\"{x:1354,y:696,t:1526930224272};\\\", \\\"{x:1354,y:694,t:1526930224290};\\\", \\\"{x:1352,y:693,t:1526930224826};\\\", \\\"{x:1350,y:694,t:1526930224857};\\\", \\\"{x:1349,y:694,t:1526930228217};\\\", \\\"{x:1348,y:694,t:1526930228224};\\\", \\\"{x:1341,y:694,t:1526930228242};\\\", \\\"{x:1325,y:696,t:1526930228257};\\\", \\\"{x:1296,y:698,t:1526930228274};\\\", \\\"{x:1235,y:703,t:1526930228290};\\\", \\\"{x:1129,y:719,t:1526930228308};\\\", \\\"{x:1019,y:733,t:1526930228324};\\\", \\\"{x:910,y:768,t:1526930228341};\\\", \\\"{x:808,y:794,t:1526930228358};\\\", \\\"{x:736,y:815,t:1526930228373};\\\", \\\"{x:695,y:830,t:1526930228391};\\\", \\\"{x:673,y:839,t:1526930228408};\\\", \\\"{x:661,y:845,t:1526930228424};\\\", \\\"{x:655,y:848,t:1526930228441};\\\", \\\"{x:653,y:850,t:1526930228457};\\\", \\\"{x:647,y:850,t:1526930228474};\\\", \\\"{x:640,y:850,t:1526930228491};\\\", \\\"{x:635,y:850,t:1526930228508};\\\", \\\"{x:629,y:850,t:1526930228524};\\\", \\\"{x:624,y:848,t:1526930228541};\\\", \\\"{x:619,y:845,t:1526930228558};\\\", \\\"{x:617,y:843,t:1526930228574};\\\", \\\"{x:614,y:841,t:1526930228591};\\\", \\\"{x:610,y:836,t:1526930228607};\\\", \\\"{x:603,y:830,t:1526930228624};\\\", \\\"{x:581,y:817,t:1526930228640};\\\", \\\"{x:565,y:807,t:1526930228657};\\\", \\\"{x:550,y:797,t:1526930228673};\\\", \\\"{x:537,y:786,t:1526930228691};\\\", \\\"{x:528,y:776,t:1526930228708};\\\", \\\"{x:521,y:767,t:1526930228723};\\\", \\\"{x:519,y:764,t:1526930228740};\\\", \\\"{x:519,y:763,t:1526930228757};\\\", \\\"{x:518,y:762,t:1526930228774};\\\", \\\"{x:518,y:761,t:1526930228857};\\\", \\\"{x:518,y:754,t:1526930228875};\\\", \\\"{x:518,y:750,t:1526930228890};\\\", \\\"{x:518,y:742,t:1526930228907};\\\", \\\"{x:518,y:737,t:1526930228926};\\\", \\\"{x:518,y:734,t:1526930228943};\\\", \\\"{x:518,y:732,t:1526930228959};\\\" ] }, { \\\"rt\\\": 88032, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 13, \\\"time_elapsed\\\": 681778, \\\"internal_node_id\\\": \\\"0.0-6.0-3.0\\\", \\\"subject\\\": \\\"WKBNA\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime+before+endtime+during\\\", \\\"q\\\": 9, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-X -J -F -F -J -J -J -J -I -I -I -I -M -M -E -F -F -F -J -I -E -E -5-E \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:518,y:731,t:1526930233361};\\\", \\\"{x:525,y:728,t:1526930233368};\\\", \\\"{x:547,y:725,t:1526930233385};\\\", \\\"{x:574,y:725,t:1526930233403};\\\", \\\"{x:609,y:722,t:1526930233418};\\\", \\\"{x:658,y:726,t:1526930233435};\\\", \\\"{x:703,y:733,t:1526930233452};\\\", \\\"{x:736,y:745,t:1526930233468};\\\", \\\"{x:774,y:753,t:1526930233485};\\\", \\\"{x:801,y:762,t:1526930233502};\\\", \\\"{x:830,y:768,t:1526930233518};\\\", \\\"{x:862,y:769,t:1526930233536};\\\", \\\"{x:906,y:773,t:1526930233552};\\\", \\\"{x:946,y:773,t:1526930233570};\\\", \\\"{x:988,y:773,t:1526930233585};\\\", \\\"{x:1033,y:773,t:1526930233603};\\\", \\\"{x:1077,y:773,t:1526930233619};\\\", \\\"{x:1116,y:776,t:1526930233635};\\\", \\\"{x:1155,y:781,t:1526930233653};\\\", \\\"{x:1184,y:787,t:1526930233670};\\\", \\\"{x:1219,y:794,t:1526930233686};\\\", \\\"{x:1260,y:800,t:1526930233703};\\\", \\\"{x:1312,y:809,t:1526930233719};\\\", \\\"{x:1369,y:814,t:1526930233736};\\\", \\\"{x:1453,y:814,t:1526930233752};\\\", \\\"{x:1506,y:814,t:1526930233770};\\\", \\\"{x:1538,y:814,t:1526930233786};\\\", \\\"{x:1583,y:808,t:1526930233803};\\\", \\\"{x:1617,y:797,t:1526930233820};\\\", \\\"{x:1657,y:786,t:1526930233836};\\\", \\\"{x:1685,y:781,t:1526930233852};\\\", \\\"{x:1704,y:776,t:1526930233870};\\\", \\\"{x:1712,y:774,t:1526930233886};\\\", \\\"{x:1713,y:774,t:1526930233993};\\\", \\\"{x:1713,y:772,t:1526930234003};\\\", \\\"{x:1712,y:767,t:1526930234020};\\\", \\\"{x:1707,y:762,t:1526930234038};\\\", \\\"{x:1704,y:759,t:1526930234052};\\\", \\\"{x:1700,y:757,t:1526930234069};\\\", \\\"{x:1697,y:755,t:1526930234086};\\\", \\\"{x:1691,y:754,t:1526930234102};\\\", \\\"{x:1683,y:754,t:1526930234120};\\\", \\\"{x:1670,y:757,t:1526930234136};\\\", \\\"{x:1654,y:758,t:1526930234152};\\\", \\\"{x:1639,y:761,t:1526930234170};\\\", \\\"{x:1623,y:762,t:1526930234187};\\\", \\\"{x:1606,y:763,t:1526930234203};\\\", \\\"{x:1594,y:763,t:1526930234219};\\\", \\\"{x:1585,y:763,t:1526930234236};\\\", \\\"{x:1574,y:763,t:1526930234252};\\\", \\\"{x:1559,y:766,t:1526930234270};\\\", \\\"{x:1545,y:769,t:1526930234287};\\\", \\\"{x:1533,y:776,t:1526930234303};\\\", \\\"{x:1522,y:783,t:1526930234320};\\\", \\\"{x:1495,y:807,t:1526930234337};\\\", \\\"{x:1482,y:826,t:1526930234357};\\\", \\\"{x:1467,y:845,t:1526930234370};\\\", \\\"{x:1457,y:860,t:1526930234386};\\\", \\\"{x:1450,y:876,t:1526930234403};\\\", \\\"{x:1446,y:887,t:1526930234419};\\\", \\\"{x:1445,y:890,t:1526930234436};\\\", \\\"{x:1445,y:891,t:1526930234456};\\\", \\\"{x:1445,y:892,t:1526930234470};\\\", \\\"{x:1446,y:893,t:1526930234486};\\\", \\\"{x:1447,y:894,t:1526930234503};\\\", \\\"{x:1447,y:895,t:1526930234536};\\\", \\\"{x:1447,y:896,t:1526930234560};\\\", \\\"{x:1447,y:892,t:1526930234665};\\\", \\\"{x:1447,y:881,t:1526930234672};\\\", \\\"{x:1447,y:871,t:1526930234687};\\\", \\\"{x:1438,y:841,t:1526930234704};\\\", \\\"{x:1423,y:804,t:1526930234720};\\\", \\\"{x:1415,y:787,t:1526930234737};\\\", \\\"{x:1410,y:774,t:1526930234754};\\\", \\\"{x:1406,y:768,t:1526930234771};\\\", \\\"{x:1404,y:765,t:1526930234787};\\\", \\\"{x:1403,y:764,t:1526930234805};\\\", \\\"{x:1402,y:762,t:1526930234821};\\\", \\\"{x:1400,y:759,t:1526930234837};\\\", \\\"{x:1398,y:755,t:1526930234854};\\\", \\\"{x:1393,y:746,t:1526930234871};\\\", \\\"{x:1389,y:738,t:1526930234887};\\\", \\\"{x:1386,y:732,t:1526930234904};\\\", \\\"{x:1381,y:719,t:1526930234920};\\\", \\\"{x:1377,y:714,t:1526930234937};\\\", \\\"{x:1376,y:711,t:1526930234954};\\\", \\\"{x:1374,y:709,t:1526930234971};\\\", \\\"{x:1373,y:709,t:1526930235016};\\\", \\\"{x:1373,y:708,t:1526930235024};\\\", \\\"{x:1368,y:708,t:1526930235201};\\\", \\\"{x:1366,y:710,t:1526930235208};\\\", \\\"{x:1359,y:714,t:1526930235221};\\\", \\\"{x:1346,y:721,t:1526930235238};\\\", \\\"{x:1335,y:728,t:1526930235254};\\\", \\\"{x:1319,y:739,t:1526930235271};\\\", \\\"{x:1306,y:747,t:1526930235288};\\\", \\\"{x:1294,y:756,t:1526930235305};\\\", \\\"{x:1291,y:758,t:1526930235320};\\\", \\\"{x:1289,y:758,t:1526930235338};\\\", \\\"{x:1289,y:759,t:1526930235355};\\\", \\\"{x:1285,y:760,t:1526930235371};\\\", \\\"{x:1284,y:762,t:1526930235388};\\\", \\\"{x:1284,y:766,t:1526930235405};\\\", \\\"{x:1281,y:777,t:1526930235421};\\\", \\\"{x:1280,y:790,t:1526930235438};\\\", \\\"{x:1278,y:804,t:1526930235455};\\\", \\\"{x:1275,y:813,t:1526930235471};\\\", \\\"{x:1272,y:821,t:1526930235488};\\\", \\\"{x:1267,y:833,t:1526930235504};\\\", \\\"{x:1266,y:836,t:1526930235521};\\\", \\\"{x:1264,y:839,t:1526930235538};\\\", \\\"{x:1262,y:841,t:1526930235555};\\\", \\\"{x:1259,y:843,t:1526930235571};\\\", \\\"{x:1255,y:845,t:1526930235588};\\\", \\\"{x:1249,y:846,t:1526930235605};\\\", \\\"{x:1248,y:846,t:1526930235622};\\\", \\\"{x:1247,y:846,t:1526930235657};\\\", \\\"{x:1246,y:846,t:1526930235672};\\\", \\\"{x:1242,y:849,t:1526930235688};\\\", \\\"{x:1238,y:853,t:1526930235705};\\\", \\\"{x:1235,y:854,t:1526930235722};\\\", \\\"{x:1234,y:854,t:1526930235738};\\\", \\\"{x:1232,y:854,t:1526930235755};\\\", \\\"{x:1231,y:854,t:1526930235772};\\\", \\\"{x:1227,y:850,t:1526930235788};\\\", \\\"{x:1224,y:844,t:1526930235805};\\\", \\\"{x:1221,y:839,t:1526930235822};\\\", \\\"{x:1219,y:835,t:1526930235838};\\\", \\\"{x:1218,y:834,t:1526930235855};\\\", \\\"{x:1217,y:833,t:1526930235896};\\\", \\\"{x:1216,y:833,t:1526930236031};\\\", \\\"{x:1215,y:832,t:1526930236071};\\\", \\\"{x:1215,y:833,t:1526930236337};\\\", \\\"{x:1215,y:835,t:1526930236344};\\\", \\\"{x:1215,y:837,t:1526930236356};\\\", \\\"{x:1212,y:842,t:1526930236371};\\\", \\\"{x:1210,y:845,t:1526930236388};\\\", \\\"{x:1208,y:849,t:1526930236405};\\\", \\\"{x:1207,y:852,t:1526930236422};\\\", \\\"{x:1206,y:852,t:1526930236438};\\\", \\\"{x:1206,y:854,t:1526930236560};\\\", \\\"{x:1206,y:855,t:1526930236576};\\\", \\\"{x:1205,y:858,t:1526930236592};\\\", \\\"{x:1205,y:854,t:1526930236688};\\\", \\\"{x:1205,y:851,t:1526930236695};\\\", \\\"{x:1205,y:850,t:1526930236706};\\\", \\\"{x:1205,y:847,t:1526930236722};\\\", \\\"{x:1203,y:845,t:1526930236739};\\\", \\\"{x:1204,y:844,t:1526930237113};\\\", \\\"{x:1204,y:843,t:1526930237123};\\\", \\\"{x:1206,y:840,t:1526930237140};\\\", \\\"{x:1206,y:838,t:1526930237156};\\\", \\\"{x:1206,y:837,t:1526930237306};\\\", \\\"{x:1206,y:834,t:1526930237312};\\\", \\\"{x:1206,y:831,t:1526930237323};\\\", \\\"{x:1206,y:827,t:1526930237339};\\\", \\\"{x:1205,y:823,t:1526930237356};\\\", \\\"{x:1203,y:820,t:1526930237373};\\\", \\\"{x:1200,y:815,t:1526930237389};\\\", \\\"{x:1200,y:814,t:1526930237407};\\\", \\\"{x:1199,y:813,t:1526930237423};\\\", \\\"{x:1198,y:812,t:1526930237440};\\\", \\\"{x:1197,y:812,t:1526930237465};\\\", \\\"{x:1196,y:812,t:1526930237473};\\\", \\\"{x:1195,y:810,t:1526930237490};\\\", \\\"{x:1194,y:806,t:1526930237507};\\\", \\\"{x:1192,y:798,t:1526930237523};\\\", \\\"{x:1190,y:792,t:1526930237540};\\\", \\\"{x:1188,y:784,t:1526930237557};\\\", \\\"{x:1187,y:779,t:1526930237573};\\\", \\\"{x:1187,y:776,t:1526930237590};\\\", \\\"{x:1186,y:774,t:1526930237607};\\\", \\\"{x:1185,y:774,t:1526930237682};\\\", \\\"{x:1184,y:774,t:1526930237690};\\\", \\\"{x:1182,y:774,t:1526930237707};\\\", \\\"{x:1181,y:774,t:1526930237728};\\\", \\\"{x:1180,y:774,t:1526930237740};\\\", \\\"{x:1178,y:772,t:1526930237757};\\\", \\\"{x:1177,y:770,t:1526930237774};\\\", \\\"{x:1175,y:768,t:1526930237790};\\\", \\\"{x:1175,y:767,t:1526930237807};\\\", \\\"{x:1175,y:766,t:1526930237978};\\\", \\\"{x:1174,y:765,t:1526930237993};\\\", \\\"{x:1174,y:764,t:1526930238009};\\\", \\\"{x:1173,y:763,t:1526930238573};\\\", \\\"{x:1172,y:763,t:1526930238788};\\\", \\\"{x:1172,y:764,t:1526930239028};\\\", \\\"{x:1172,y:766,t:1526930239220};\\\", \\\"{x:1170,y:768,t:1526930247573};\\\", \\\"{x:1167,y:771,t:1526930247587};\\\", \\\"{x:1159,y:778,t:1526930247603};\\\", \\\"{x:1149,y:780,t:1526930247621};\\\", \\\"{x:1142,y:781,t:1526930247637};\\\", \\\"{x:1135,y:781,t:1526930247653};\\\", \\\"{x:1133,y:781,t:1526930247671};\\\", \\\"{x:1131,y:781,t:1526930247692};\\\", \\\"{x:1132,y:777,t:1526930248196};\\\", \\\"{x:1135,y:772,t:1526930248204};\\\", \\\"{x:1136,y:771,t:1526930248221};\\\", \\\"{x:1136,y:770,t:1526930248259};\\\", \\\"{x:1137,y:771,t:1526930248270};\\\", \\\"{x:1140,y:777,t:1526930248287};\\\", \\\"{x:1141,y:781,t:1526930248304};\\\", \\\"{x:1144,y:784,t:1526930248320};\\\", \\\"{x:1145,y:785,t:1526930248337};\\\", \\\"{x:1146,y:785,t:1526930248354};\\\", \\\"{x:1160,y:785,t:1526930248372};\\\", \\\"{x:1180,y:785,t:1526930248387};\\\", \\\"{x:1201,y:788,t:1526930248404};\\\", \\\"{x:1214,y:794,t:1526930248422};\\\", \\\"{x:1222,y:801,t:1526930248437};\\\", \\\"{x:1225,y:805,t:1526930248454};\\\", \\\"{x:1227,y:807,t:1526930248472};\\\", \\\"{x:1229,y:812,t:1526930248487};\\\", \\\"{x:1230,y:816,t:1526930248504};\\\", \\\"{x:1230,y:822,t:1526930248522};\\\", \\\"{x:1230,y:824,t:1526930248537};\\\", \\\"{x:1230,y:828,t:1526930248554};\\\", \\\"{x:1229,y:831,t:1526930248571};\\\", \\\"{x:1229,y:834,t:1526930248587};\\\", \\\"{x:1229,y:838,t:1526930248605};\\\", \\\"{x:1228,y:845,t:1526930248621};\\\", \\\"{x:1225,y:853,t:1526930248637};\\\", \\\"{x:1223,y:863,t:1526930248655};\\\", \\\"{x:1217,y:875,t:1526930248672};\\\", \\\"{x:1214,y:881,t:1526930248687};\\\", \\\"{x:1210,y:885,t:1526930248704};\\\", \\\"{x:1203,y:891,t:1526930248722};\\\", \\\"{x:1199,y:893,t:1526930248739};\\\", \\\"{x:1197,y:894,t:1526930248754};\\\", \\\"{x:1194,y:894,t:1526930248772};\\\", \\\"{x:1193,y:894,t:1526930248788};\\\", \\\"{x:1191,y:894,t:1526930248805};\\\", \\\"{x:1190,y:893,t:1526930249235};\\\", \\\"{x:1190,y:891,t:1526930249242};\\\", \\\"{x:1190,y:890,t:1526930249255};\\\", \\\"{x:1191,y:888,t:1526930249271};\\\", \\\"{x:1191,y:887,t:1526930249288};\\\", \\\"{x:1193,y:887,t:1526930249412};\\\", \\\"{x:1193,y:885,t:1526930249423};\\\", \\\"{x:1194,y:881,t:1526930249438};\\\", \\\"{x:1195,y:879,t:1526930249455};\\\", \\\"{x:1196,y:876,t:1526930249472};\\\", \\\"{x:1195,y:874,t:1526930249668};\\\", \\\"{x:1195,y:873,t:1526930249675};\\\", \\\"{x:1193,y:872,t:1526930250003};\\\", \\\"{x:1189,y:870,t:1526930250010};\\\", \\\"{x:1183,y:869,t:1526930250022};\\\", \\\"{x:1176,y:867,t:1526930250039};\\\", \\\"{x:1160,y:863,t:1526930250056};\\\", \\\"{x:1149,y:857,t:1526930250072};\\\", \\\"{x:1134,y:849,t:1526930250089};\\\", \\\"{x:1126,y:844,t:1526930250106};\\\", \\\"{x:1125,y:844,t:1526930250164};\\\", \\\"{x:1125,y:841,t:1526930250173};\\\", \\\"{x:1132,y:834,t:1526930250189};\\\", \\\"{x:1141,y:826,t:1526930250206};\\\", \\\"{x:1165,y:806,t:1526930250223};\\\", \\\"{x:1200,y:785,t:1526930250239};\\\", \\\"{x:1242,y:757,t:1526930250257};\\\", \\\"{x:1271,y:736,t:1526930250273};\\\", \\\"{x:1298,y:720,t:1526930250289};\\\", \\\"{x:1317,y:707,t:1526930250307};\\\", \\\"{x:1331,y:696,t:1526930250323};\\\", \\\"{x:1343,y:688,t:1526930250340};\\\", \\\"{x:1345,y:687,t:1526930250357};\\\", \\\"{x:1347,y:687,t:1526930250373};\\\", \\\"{x:1348,y:687,t:1526930250628};\\\", \\\"{x:1349,y:688,t:1526930250639};\\\", \\\"{x:1349,y:690,t:1526930250656};\\\", \\\"{x:1349,y:692,t:1526930250674};\\\", \\\"{x:1349,y:695,t:1526930250690};\\\", \\\"{x:1350,y:695,t:1526930250740};\\\", \\\"{x:1350,y:696,t:1526930250868};\\\", \\\"{x:1350,y:697,t:1526930250876};\\\", \\\"{x:1350,y:698,t:1526930250890};\\\", \\\"{x:1350,y:699,t:1526930250907};\\\", \\\"{x:1348,y:699,t:1526930253388};\\\", \\\"{x:1341,y:699,t:1526930253395};\\\", \\\"{x:1336,y:699,t:1526930253409};\\\", \\\"{x:1323,y:701,t:1526930253427};\\\", \\\"{x:1309,y:701,t:1526930253442};\\\", \\\"{x:1287,y:703,t:1526930253459};\\\", \\\"{x:1276,y:708,t:1526930253477};\\\", \\\"{x:1269,y:715,t:1526930253492};\\\", \\\"{x:1263,y:726,t:1526930253510};\\\", \\\"{x:1252,y:741,t:1526930253526};\\\", \\\"{x:1243,y:758,t:1526930253542};\\\", \\\"{x:1233,y:777,t:1526930253559};\\\", \\\"{x:1228,y:791,t:1526930253577};\\\", \\\"{x:1222,y:807,t:1526930253592};\\\", \\\"{x:1218,y:820,t:1526930253609};\\\", \\\"{x:1215,y:828,t:1526930253627};\\\", \\\"{x:1214,y:833,t:1526930253642};\\\", \\\"{x:1213,y:834,t:1526930253660};\\\", \\\"{x:1213,y:835,t:1526930253707};\\\", \\\"{x:1213,y:837,t:1526930253724};\\\", \\\"{x:1213,y:839,t:1526930253739};\\\", \\\"{x:1213,y:840,t:1526930253747};\\\", \\\"{x:1213,y:842,t:1526930253763};\\\", \\\"{x:1213,y:844,t:1526930253777};\\\", \\\"{x:1213,y:845,t:1526930253794};\\\", \\\"{x:1213,y:846,t:1526930253810};\\\", \\\"{x:1213,y:847,t:1526930253827};\\\", \\\"{x:1213,y:846,t:1526930253899};\\\", \\\"{x:1213,y:844,t:1526930253909};\\\", \\\"{x:1213,y:843,t:1526930253926};\\\", \\\"{x:1213,y:841,t:1526930254060};\\\", \\\"{x:1213,y:837,t:1526930254077};\\\", \\\"{x:1211,y:832,t:1526930254095};\\\", \\\"{x:1211,y:829,t:1526930254110};\\\", \\\"{x:1211,y:825,t:1526930254127};\\\", \\\"{x:1211,y:823,t:1526930254144};\\\", \\\"{x:1210,y:822,t:1526930254211};\\\", \\\"{x:1210,y:823,t:1526930254444};\\\", \\\"{x:1210,y:824,t:1526930254461};\\\", \\\"{x:1210,y:826,t:1526930254478};\\\", \\\"{x:1211,y:827,t:1526930254516};\\\", \\\"{x:1212,y:827,t:1526930254660};\\\", \\\"{x:1212,y:829,t:1526930254678};\\\", \\\"{x:1212,y:831,t:1526930254695};\\\", \\\"{x:1212,y:832,t:1526930254711};\\\", \\\"{x:1212,y:833,t:1526930256203};\\\", \\\"{x:1212,y:834,t:1526930256492};\\\", \\\"{x:1212,y:835,t:1526930256508};\\\", \\\"{x:1212,y:837,t:1526930256693};\\\", \\\"{x:1212,y:838,t:1526930256707};\\\", \\\"{x:1211,y:839,t:1526930256739};\\\", \\\"{x:1210,y:834,t:1526930257444};\\\", \\\"{x:1208,y:828,t:1526930257451};\\\", \\\"{x:1206,y:824,t:1526930257464};\\\", \\\"{x:1203,y:811,t:1526930257481};\\\", \\\"{x:1200,y:799,t:1526930257497};\\\", \\\"{x:1197,y:793,t:1526930257514};\\\", \\\"{x:1196,y:788,t:1526930257531};\\\", \\\"{x:1195,y:788,t:1526930257547};\\\", \\\"{x:1194,y:787,t:1526930257579};\\\", \\\"{x:1193,y:786,t:1526930257603};\\\", \\\"{x:1192,y:785,t:1526930257620};\\\", \\\"{x:1191,y:783,t:1526930257630};\\\", \\\"{x:1189,y:780,t:1526930257648};\\\", \\\"{x:1189,y:777,t:1526930257664};\\\", \\\"{x:1186,y:772,t:1526930257681};\\\", \\\"{x:1185,y:769,t:1526930257698};\\\", \\\"{x:1183,y:765,t:1526930257714};\\\", \\\"{x:1181,y:763,t:1526930257731};\\\", \\\"{x:1180,y:763,t:1526930257803};\\\", \\\"{x:1179,y:762,t:1526930257827};\\\", \\\"{x:1178,y:762,t:1526930257859};\\\", \\\"{x:1177,y:761,t:1526930257875};\\\", \\\"{x:1176,y:759,t:1526930257892};\\\", \\\"{x:1176,y:757,t:1526930257908};\\\", \\\"{x:1176,y:756,t:1526930257915};\\\", \\\"{x:1175,y:755,t:1526930257932};\\\", \\\"{x:1175,y:756,t:1526930258132};\\\", \\\"{x:1176,y:757,t:1526930258148};\\\", \\\"{x:1177,y:757,t:1526930258165};\\\", \\\"{x:1178,y:757,t:1526930258363};\\\", \\\"{x:1179,y:757,t:1526930258387};\\\", \\\"{x:1180,y:757,t:1526930258957};\\\", \\\"{x:1180,y:758,t:1526930258972};\\\", \\\"{x:1182,y:758,t:1526930279155};\\\", \\\"{x:1186,y:758,t:1526930279170};\\\", \\\"{x:1192,y:760,t:1526930279187};\\\", \\\"{x:1199,y:763,t:1526930279203};\\\", \\\"{x:1208,y:765,t:1526930279220};\\\", \\\"{x:1213,y:769,t:1526930279236};\\\", \\\"{x:1222,y:773,t:1526930279253};\\\", \\\"{x:1235,y:780,t:1526930279270};\\\", \\\"{x:1251,y:790,t:1526930279286};\\\", \\\"{x:1273,y:801,t:1526930279302};\\\", \\\"{x:1293,y:811,t:1526930279320};\\\", \\\"{x:1314,y:820,t:1526930279337};\\\", \\\"{x:1329,y:825,t:1526930279352};\\\", \\\"{x:1343,y:828,t:1526930279370};\\\", \\\"{x:1357,y:833,t:1526930279387};\\\", \\\"{x:1359,y:835,t:1526930279403};\\\", \\\"{x:1360,y:835,t:1526930279468};\\\", \\\"{x:1361,y:837,t:1526930279476};\\\", \\\"{x:1362,y:839,t:1526930279487};\\\", \\\"{x:1365,y:845,t:1526930279503};\\\", \\\"{x:1366,y:855,t:1526930279520};\\\", \\\"{x:1374,y:866,t:1526930279537};\\\", \\\"{x:1382,y:876,t:1526930279554};\\\", \\\"{x:1391,y:883,t:1526930279570};\\\", \\\"{x:1398,y:887,t:1526930279587};\\\", \\\"{x:1402,y:890,t:1526930279603};\\\", \\\"{x:1403,y:890,t:1526930279627};\\\", \\\"{x:1403,y:891,t:1526930279667};\\\", \\\"{x:1403,y:893,t:1526930279683};\\\", \\\"{x:1403,y:895,t:1526930279699};\\\", \\\"{x:1403,y:896,t:1526930279716};\\\", \\\"{x:1402,y:897,t:1526930279731};\\\", \\\"{x:1400,y:897,t:1526930279739};\\\", \\\"{x:1397,y:897,t:1526930279754};\\\", \\\"{x:1392,y:899,t:1526930279770};\\\", \\\"{x:1387,y:899,t:1526930279787};\\\", \\\"{x:1386,y:899,t:1526930279805};\\\", \\\"{x:1385,y:899,t:1526930279820};\\\", \\\"{x:1384,y:899,t:1526930279875};\\\", \\\"{x:1383,y:899,t:1526930279955};\\\", \\\"{x:1383,y:898,t:1526930280067};\\\", \\\"{x:1382,y:896,t:1526930280074};\\\", \\\"{x:1382,y:895,t:1526930280299};\\\", \\\"{x:1381,y:894,t:1526930280306};\\\", \\\"{x:1381,y:892,t:1526930283836};\\\", \\\"{x:1381,y:889,t:1526930283844};\\\", \\\"{x:1380,y:888,t:1526930283857};\\\", \\\"{x:1378,y:886,t:1526930283875};\\\", \\\"{x:1378,y:885,t:1526930284075};\\\", \\\"{x:1377,y:885,t:1526930284171};\\\", \\\"{x:1371,y:879,t:1526930284180};\\\", \\\"{x:1365,y:870,t:1526930284192};\\\", \\\"{x:1346,y:840,t:1526930284208};\\\", \\\"{x:1306,y:784,t:1526930284225};\\\", \\\"{x:1260,y:712,t:1526930284241};\\\", \\\"{x:1223,y:659,t:1526930284257};\\\", \\\"{x:1176,y:596,t:1526930284275};\\\", \\\"{x:1153,y:567,t:1526930284291};\\\", \\\"{x:1132,y:543,t:1526930284308};\\\", \\\"{x:1126,y:533,t:1526930284325};\\\", \\\"{x:1123,y:523,t:1526930284343};\\\", \\\"{x:1123,y:519,t:1526930284357};\\\", \\\"{x:1123,y:514,t:1526930284375};\\\", \\\"{x:1126,y:508,t:1526930284392};\\\", \\\"{x:1130,y:503,t:1526930284407};\\\", \\\"{x:1138,y:495,t:1526930284425};\\\", \\\"{x:1152,y:486,t:1526930284442};\\\", \\\"{x:1182,y:469,t:1526930284459};\\\", \\\"{x:1203,y:466,t:1526930284475};\\\", \\\"{x:1226,y:465,t:1526930284492};\\\", \\\"{x:1252,y:467,t:1526930284509};\\\", \\\"{x:1270,y:476,t:1526930284525};\\\", \\\"{x:1281,y:483,t:1526930284542};\\\", \\\"{x:1291,y:493,t:1526930284559};\\\", \\\"{x:1297,y:509,t:1526930284574};\\\", \\\"{x:1301,y:522,t:1526930284592};\\\", \\\"{x:1305,y:537,t:1526930284609};\\\", \\\"{x:1307,y:549,t:1526930284625};\\\", \\\"{x:1309,y:558,t:1526930284642};\\\", \\\"{x:1310,y:564,t:1526930284659};\\\", \\\"{x:1310,y:565,t:1526930284796};\\\", \\\"{x:1310,y:568,t:1526930284819};\\\", \\\"{x:1310,y:571,t:1526930284827};\\\", \\\"{x:1310,y:572,t:1526930284842};\\\", \\\"{x:1309,y:575,t:1526930284859};\\\", \\\"{x:1308,y:575,t:1526930284899};\\\", \\\"{x:1307,y:575,t:1526930284915};\\\", \\\"{x:1304,y:575,t:1526930284931};\\\", \\\"{x:1303,y:574,t:1526930284947};\\\", \\\"{x:1300,y:572,t:1526930284963};\\\", \\\"{x:1299,y:572,t:1526930284976};\\\", \\\"{x:1297,y:572,t:1526930284992};\\\", \\\"{x:1297,y:571,t:1526930285009};\\\", \\\"{x:1295,y:571,t:1526930285026};\\\", \\\"{x:1294,y:571,t:1526930285042};\\\", \\\"{x:1293,y:571,t:1526930285067};\\\", \\\"{x:1292,y:571,t:1526930285123};\\\", \\\"{x:1291,y:571,t:1526930285131};\\\", \\\"{x:1290,y:570,t:1526930285147};\\\", \\\"{x:1288,y:568,t:1526930285163};\\\", \\\"{x:1287,y:567,t:1526930285176};\\\", \\\"{x:1287,y:566,t:1526930285193};\\\", \\\"{x:1286,y:566,t:1526930285348};\\\", \\\"{x:1285,y:566,t:1526930285359};\\\", \\\"{x:1284,y:564,t:1526930285376};\\\", \\\"{x:1282,y:561,t:1526930285393};\\\", \\\"{x:1281,y:560,t:1526930285491};\\\", \\\"{x:1280,y:561,t:1526930285947};\\\", \\\"{x:1280,y:562,t:1526930285960};\\\", \\\"{x:1279,y:563,t:1526930285977};\\\", \\\"{x:1279,y:564,t:1526930286131};\\\", \\\"{x:1279,y:565,t:1526930286144};\\\", \\\"{x:1278,y:567,t:1526930286160};\\\", \\\"{x:1278,y:568,t:1526930286177};\\\", \\\"{x:1278,y:575,t:1526930308952};\\\", \\\"{x:1281,y:583,t:1526930308958};\\\", \\\"{x:1290,y:588,t:1526930308971};\\\", \\\"{x:1309,y:599,t:1526930308988};\\\", \\\"{x:1340,y:612,t:1526930309005};\\\", \\\"{x:1367,y:624,t:1526930309021};\\\", \\\"{x:1419,y:635,t:1526930309037};\\\", \\\"{x:1449,y:656,t:1526930309055};\\\", \\\"{x:1459,y:663,t:1526930309071};\\\", \\\"{x:1460,y:665,t:1526930309088};\\\", \\\"{x:1443,y:665,t:1526930309150};\\\", \\\"{x:1404,y:665,t:1526930309157};\\\", \\\"{x:1360,y:665,t:1526930309171};\\\", \\\"{x:1265,y:669,t:1526930309187};\\\", \\\"{x:1215,y:680,t:1526930309204};\\\", \\\"{x:1211,y:682,t:1526930309221};\\\", \\\"{x:1209,y:682,t:1526930309237};\\\", \\\"{x:1209,y:685,t:1526930309342};\\\", \\\"{x:1220,y:685,t:1526930309354};\\\", \\\"{x:1235,y:686,t:1526930309372};\\\", \\\"{x:1243,y:686,t:1526930309387};\\\", \\\"{x:1246,y:684,t:1526930309404};\\\", \\\"{x:1250,y:682,t:1526930309421};\\\", \\\"{x:1252,y:680,t:1526930309437};\\\", \\\"{x:1261,y:680,t:1526930309455};\\\", \\\"{x:1271,y:680,t:1526930309472};\\\", \\\"{x:1286,y:680,t:1526930309488};\\\", \\\"{x:1306,y:685,t:1526930309504};\\\", \\\"{x:1328,y:695,t:1526930309521};\\\", \\\"{x:1340,y:700,t:1526930309539};\\\", \\\"{x:1344,y:703,t:1526930309555};\\\", \\\"{x:1345,y:703,t:1526930309783};\\\", \\\"{x:1345,y:702,t:1526930309790};\\\", \\\"{x:1345,y:700,t:1526930309805};\\\", \\\"{x:1345,y:696,t:1526930309821};\\\", \\\"{x:1345,y:690,t:1526930309840};\\\", \\\"{x:1346,y:688,t:1526930309856};\\\", \\\"{x:1346,y:685,t:1526930309871};\\\", \\\"{x:1347,y:684,t:1526930309888};\\\", \\\"{x:1347,y:683,t:1526930309905};\\\", \\\"{x:1347,y:684,t:1526930310175};\\\", \\\"{x:1347,y:685,t:1526930310189};\\\", \\\"{x:1348,y:686,t:1526930310205};\\\", \\\"{x:1348,y:687,t:1526930311398};\\\", \\\"{x:1348,y:688,t:1526930311407};\\\", \\\"{x:1348,y:692,t:1526930311424};\\\", \\\"{x:1347,y:692,t:1526930311440};\\\", \\\"{x:1346,y:693,t:1526930311478};\\\", \\\"{x:1346,y:694,t:1526930311535};\\\", \\\"{x:1345,y:696,t:1526930311542};\\\", \\\"{x:1341,y:700,t:1526930311558};\\\", \\\"{x:1330,y:715,t:1526930311574};\\\", \\\"{x:1305,y:739,t:1526930311590};\\\", \\\"{x:1287,y:755,t:1526930311607};\\\", \\\"{x:1275,y:766,t:1526930311624};\\\", \\\"{x:1269,y:770,t:1526930311641};\\\", \\\"{x:1265,y:772,t:1526930311657};\\\", \\\"{x:1261,y:773,t:1526930311673};\\\", \\\"{x:1256,y:777,t:1526930311690};\\\", \\\"{x:1253,y:779,t:1526930311707};\\\", \\\"{x:1249,y:782,t:1526930311724};\\\", \\\"{x:1243,y:787,t:1526930311741};\\\", \\\"{x:1235,y:793,t:1526930311757};\\\", \\\"{x:1226,y:804,t:1526930311774};\\\", \\\"{x:1223,y:812,t:1526930311790};\\\", \\\"{x:1218,y:823,t:1526930311807};\\\", \\\"{x:1214,y:833,t:1526930311824};\\\", \\\"{x:1213,y:838,t:1526930311842};\\\", \\\"{x:1208,y:845,t:1526930311857};\\\", \\\"{x:1206,y:847,t:1526930311873};\\\", \\\"{x:1204,y:850,t:1526930311890};\\\", \\\"{x:1202,y:852,t:1526930311907};\\\", \\\"{x:1200,y:852,t:1526930311923};\\\", \\\"{x:1199,y:854,t:1526930311940};\\\", \\\"{x:1197,y:855,t:1526930311958};\\\", \\\"{x:1196,y:856,t:1526930311974};\\\", \\\"{x:1194,y:857,t:1526930311990};\\\", \\\"{x:1193,y:857,t:1526930312007};\\\", \\\"{x:1192,y:857,t:1526930312024};\\\", \\\"{x:1190,y:857,t:1526930312041};\\\", \\\"{x:1187,y:853,t:1526930312058};\\\", \\\"{x:1186,y:852,t:1526930312074};\\\", \\\"{x:1186,y:844,t:1526930312090};\\\", \\\"{x:1183,y:830,t:1526930312108};\\\", \\\"{x:1182,y:820,t:1526930312124};\\\", \\\"{x:1182,y:813,t:1526930312141};\\\", \\\"{x:1182,y:802,t:1526930312159};\\\", \\\"{x:1182,y:796,t:1526930312174};\\\", \\\"{x:1182,y:793,t:1526930312190};\\\", \\\"{x:1182,y:791,t:1526930312207};\\\", \\\"{x:1182,y:790,t:1526930312224};\\\", \\\"{x:1182,y:788,t:1526930312239};\\\", \\\"{x:1182,y:787,t:1526930312293};\\\", \\\"{x:1182,y:785,t:1526930312308};\\\", \\\"{x:1182,y:783,t:1526930312324};\\\", \\\"{x:1181,y:781,t:1526930312341};\\\", \\\"{x:1179,y:779,t:1526930312357};\\\", \\\"{x:1179,y:777,t:1526930312535};\\\", \\\"{x:1179,y:775,t:1526930312542};\\\", \\\"{x:1179,y:772,t:1526930312558};\\\", \\\"{x:1179,y:771,t:1526930312574};\\\", \\\"{x:1179,y:769,t:1526930312974};\\\", \\\"{x:1179,y:768,t:1526930312992};\\\", \\\"{x:1179,y:767,t:1526930313008};\\\", \\\"{x:1179,y:766,t:1526930313024};\\\", \\\"{x:1179,y:764,t:1526930313182};\\\", \\\"{x:1183,y:760,t:1526930313191};\\\", \\\"{x:1190,y:751,t:1526930313210};\\\", \\\"{x:1202,y:737,t:1526930313226};\\\", \\\"{x:1218,y:719,t:1526930313242};\\\", \\\"{x:1236,y:704,t:1526930313258};\\\", \\\"{x:1252,y:689,t:1526930313275};\\\", \\\"{x:1266,y:676,t:1526930313291};\\\", \\\"{x:1276,y:665,t:1526930313308};\\\", \\\"{x:1294,y:644,t:1526930313325};\\\", \\\"{x:1304,y:627,t:1526930313341};\\\", \\\"{x:1315,y:608,t:1526930313359};\\\", \\\"{x:1324,y:594,t:1526930313375};\\\", \\\"{x:1325,y:588,t:1526930313391};\\\", \\\"{x:1327,y:585,t:1526930313408};\\\", \\\"{x:1327,y:584,t:1526930313426};\\\", \\\"{x:1327,y:581,t:1526930313559};\\\", \\\"{x:1324,y:577,t:1526930313575};\\\", \\\"{x:1317,y:571,t:1526930313593};\\\", \\\"{x:1310,y:564,t:1526930313609};\\\", \\\"{x:1303,y:556,t:1526930313626};\\\", \\\"{x:1297,y:551,t:1526930313642};\\\", \\\"{x:1296,y:549,t:1526930313659};\\\", \\\"{x:1293,y:548,t:1526930313774};\\\", \\\"{x:1291,y:548,t:1526930313792};\\\", \\\"{x:1285,y:548,t:1526930313809};\\\", \\\"{x:1282,y:549,t:1526930313826};\\\", \\\"{x:1280,y:550,t:1526930313842};\\\", \\\"{x:1279,y:550,t:1526930313885};\\\", \\\"{x:1279,y:551,t:1526930313893};\\\", \\\"{x:1279,y:552,t:1526930313909};\\\", \\\"{x:1279,y:555,t:1526930313925};\\\", \\\"{x:1279,y:556,t:1526930313942};\\\", \\\"{x:1279,y:557,t:1526930313960};\\\", \\\"{x:1279,y:558,t:1526930313975};\\\", \\\"{x:1279,y:559,t:1526930314847};\\\", \\\"{x:1279,y:561,t:1526930317550};\\\", \\\"{x:1268,y:568,t:1526930317563};\\\", \\\"{x:1224,y:588,t:1526930317580};\\\", \\\"{x:1155,y:617,t:1526930317597};\\\", \\\"{x:1074,y:641,t:1526930317614};\\\", \\\"{x:938,y:682,t:1526930317630};\\\", \\\"{x:838,y:710,t:1526930317647};\\\", \\\"{x:733,y:741,t:1526930317663};\\\", \\\"{x:635,y:762,t:1526930317680};\\\", \\\"{x:571,y:771,t:1526930317697};\\\", \\\"{x:536,y:774,t:1526930317713};\\\", \\\"{x:525,y:774,t:1526930317729};\\\", \\\"{x:524,y:774,t:1526930317747};\\\", \\\"{x:529,y:774,t:1526930317830};\\\", \\\"{x:544,y:772,t:1526930317847};\\\", \\\"{x:572,y:769,t:1526930317863};\\\", \\\"{x:603,y:763,t:1526930317880};\\\", \\\"{x:648,y:756,t:1526930317896};\\\", \\\"{x:716,y:746,t:1526930317914};\\\", \\\"{x:786,y:733,t:1526930317929};\\\", \\\"{x:846,y:722,t:1526930317946};\\\", \\\"{x:901,y:705,t:1526930317963};\\\", \\\"{x:949,y:681,t:1526930317979};\\\", \\\"{x:991,y:662,t:1526930317997};\\\", \\\"{x:1025,y:645,t:1526930318013};\\\", \\\"{x:1043,y:637,t:1526930318029};\\\", \\\"{x:1056,y:632,t:1526930318047};\\\", \\\"{x:1067,y:628,t:1526930318064};\\\", \\\"{x:1083,y:618,t:1526930318080};\\\", \\\"{x:1106,y:608,t:1526930318097};\\\", \\\"{x:1139,y:593,t:1526930318114};\\\", \\\"{x:1174,y:580,t:1526930318130};\\\", \\\"{x:1219,y:567,t:1526930318147};\\\", \\\"{x:1255,y:563,t:1526930318164};\\\", \\\"{x:1277,y:559,t:1526930318181};\\\", \\\"{x:1292,y:558,t:1526930318198};\\\", \\\"{x:1309,y:555,t:1526930318215};\\\", \\\"{x:1316,y:554,t:1526930318230};\\\", \\\"{x:1317,y:554,t:1526930318247};\\\", \\\"{x:1317,y:555,t:1526930318351};\\\", \\\"{x:1317,y:558,t:1526930318364};\\\", \\\"{x:1313,y:562,t:1526930318382};\\\", \\\"{x:1308,y:565,t:1526930318397};\\\", \\\"{x:1300,y:567,t:1526930318414};\\\", \\\"{x:1296,y:568,t:1526930318432};\\\", \\\"{x:1287,y:570,t:1526930318447};\\\", \\\"{x:1265,y:572,t:1526930318464};\\\", \\\"{x:1215,y:586,t:1526930318481};\\\", \\\"{x:1125,y:605,t:1526930318497};\\\", \\\"{x:1004,y:632,t:1526930318514};\\\", \\\"{x:869,y:665,t:1526930318531};\\\", \\\"{x:722,y:693,t:1526930318548};\\\", \\\"{x:572,y:714,t:1526930318564};\\\", \\\"{x:453,y:733,t:1526930318583};\\\", \\\"{x:326,y:739,t:1526930318597};\\\", \\\"{x:295,y:739,t:1526930318613};\\\", \\\"{x:282,y:737,t:1526930318629};\\\", \\\"{x:273,y:734,t:1526930318645};\\\", \\\"{x:270,y:731,t:1526930318661};\\\", \\\"{x:269,y:730,t:1526930318678};\\\", \\\"{x:269,y:731,t:1526930318750};\\\", \\\"{x:269,y:732,t:1526930318761};\\\", \\\"{x:270,y:738,t:1526930318778};\\\", \\\"{x:272,y:740,t:1526930318795};\\\", \\\"{x:279,y:743,t:1526930318812};\\\", \\\"{x:291,y:747,t:1526930318828};\\\", \\\"{x:297,y:751,t:1526930318845};\\\", \\\"{x:304,y:754,t:1526930318862};\\\", \\\"{x:307,y:754,t:1526930318879};\\\", \\\"{x:311,y:754,t:1526930318894};\\\", \\\"{x:317,y:754,t:1526930318912};\\\", \\\"{x:323,y:754,t:1526930318929};\\\", \\\"{x:336,y:754,t:1526930318946};\\\", \\\"{x:347,y:754,t:1526930318962};\\\", \\\"{x:378,y:741,t:1526930318978};\\\", \\\"{x:431,y:714,t:1526930318996};\\\", \\\"{x:478,y:683,t:1526930319012};\\\", \\\"{x:525,y:641,t:1526930319028};\\\", \\\"{x:582,y:572,t:1526930319048};\\\", \\\"{x:609,y:532,t:1526930319062};\\\", \\\"{x:627,y:502,t:1526930319080};\\\", \\\"{x:640,y:478,t:1526930319096};\\\", \\\"{x:642,y:466,t:1526930319114};\\\", \\\"{x:643,y:465,t:1526930319129};\\\", \\\"{x:643,y:464,t:1526930319146};\\\", \\\"{x:643,y:462,t:1526930319165};\\\", \\\"{x:644,y:458,t:1526930319179};\\\", \\\"{x:649,y:450,t:1526930319197};\\\", \\\"{x:652,y:444,t:1526930319213};\\\", \\\"{x:651,y:444,t:1526930319261};\\\", \\\"{x:650,y:446,t:1526930319269};\\\", \\\"{x:645,y:452,t:1526930319279};\\\", \\\"{x:634,y:467,t:1526930319296};\\\", \\\"{x:621,y:486,t:1526930319314};\\\", \\\"{x:610,y:500,t:1526930319330};\\\", \\\"{x:605,y:506,t:1526930319346};\\\", \\\"{x:605,y:507,t:1526930319363};\\\", \\\"{x:603,y:507,t:1526930319422};\\\", \\\"{x:601,y:507,t:1526930319430};\\\", \\\"{x:600,y:509,t:1526930319709};\\\", \\\"{x:600,y:516,t:1526930319717};\\\", \\\"{x:600,y:524,t:1526930319731};\\\", \\\"{x:604,y:543,t:1526930319747};\\\", \\\"{x:604,y:562,t:1526930319764};\\\", \\\"{x:604,y:579,t:1526930319780};\\\", \\\"{x:598,y:598,t:1526930319796};\\\", \\\"{x:592,y:619,t:1526930319813};\\\", \\\"{x:589,y:626,t:1526930319830};\\\", \\\"{x:584,y:633,t:1526930319847};\\\", \\\"{x:583,y:637,t:1526930319864};\\\", \\\"{x:579,y:642,t:1526930319880};\\\", \\\"{x:576,y:646,t:1526930319897};\\\", \\\"{x:573,y:650,t:1526930319914};\\\", \\\"{x:569,y:654,t:1526930319931};\\\", \\\"{x:568,y:656,t:1526930319947};\\\", \\\"{x:563,y:659,t:1526930319964};\\\", \\\"{x:559,y:663,t:1526930319980};\\\", \\\"{x:550,y:677,t:1526930319998};\\\", \\\"{x:545,y:687,t:1526930320014};\\\", \\\"{x:541,y:692,t:1526930320031};\\\", \\\"{x:539,y:696,t:1526930320048};\\\", \\\"{x:538,y:699,t:1526930320063};\\\", \\\"{x:536,y:703,t:1526930320081};\\\", \\\"{x:530,y:712,t:1526930320098};\\\", \\\"{x:527,y:722,t:1526930320115};\\\", \\\"{x:522,y:734,t:1526930320131};\\\", \\\"{x:519,y:740,t:1526930320148};\\\", \\\"{x:517,y:743,t:1526930320165};\\\", \\\"{x:521,y:742,t:1526930320806};\\\", \\\"{x:521,y:741,t:1526930320815};\\\", \\\"{x:526,y:738,t:1526930320831};\\\", \\\"{x:529,y:736,t:1526930320848};\\\", \\\"{x:533,y:734,t:1526930320865};\\\", \\\"{x:534,y:734,t:1526930320882};\\\", \\\"{x:536,y:733,t:1526930320898};\\\", \\\"{x:537,y:732,t:1526930320915};\\\", \\\"{x:538,y:732,t:1526930320932};\\\", \\\"{x:541,y:731,t:1526930320948};\\\", \\\"{x:546,y:729,t:1526930320965};\\\", \\\"{x:555,y:725,t:1526930320982};\\\", \\\"{x:566,y:720,t:1526930320998};\\\", \\\"{x:578,y:714,t:1526930321015};\\\", \\\"{x:593,y:700,t:1526930321032};\\\", \\\"{x:611,y:685,t:1526930321048};\\\", \\\"{x:627,y:671,t:1526930321065};\\\", \\\"{x:643,y:661,t:1526930321082};\\\", \\\"{x:658,y:654,t:1526930321098};\\\", \\\"{x:664,y:650,t:1526930321115};\\\", \\\"{x:674,y:647,t:1526930321132};\\\", \\\"{x:684,y:646,t:1526930321147};\\\", \\\"{x:695,y:645,t:1526930321165};\\\", \\\"{x:721,y:645,t:1526930321181};\\\", \\\"{x:739,y:645,t:1526930321198};\\\", \\\"{x:761,y:644,t:1526930321215};\\\", \\\"{x:780,y:639,t:1526930321231};\\\", \\\"{x:796,y:635,t:1526930321248};\\\", \\\"{x:808,y:630,t:1526930321264};\\\", \\\"{x:816,y:627,t:1526930321282};\\\", \\\"{x:818,y:626,t:1526930321297};\\\" ] }, { \\\"rt\\\": 10862, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 14, \\\"time_elapsed\\\": 694211, \\\"internal_node_id\\\": \\\"0.0-6.0-4.0\\\", \\\"subject\\\": \\\"WKBNA\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"ends\\\", \\\"q\\\": 10, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F -F -02 PM-02 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:802,y:610,t:1526930322244};\\\", \\\"{x:800,y:609,t:1526930322265};\\\", \\\"{x:798,y:609,t:1526930322283};\\\", \\\"{x:796,y:609,t:1526930322299};\\\", \\\"{x:794,y:609,t:1526930322315};\\\", \\\"{x:791,y:609,t:1526930322332};\\\", \\\"{x:789,y:612,t:1526930322349};\\\", \\\"{x:787,y:613,t:1526930322365};\\\", \\\"{x:783,y:613,t:1526930322382};\\\", \\\"{x:780,y:616,t:1526930322399};\\\", \\\"{x:776,y:616,t:1526930322416};\\\", \\\"{x:773,y:617,t:1526930322432};\\\", \\\"{x:769,y:619,t:1526930322450};\\\", \\\"{x:766,y:619,t:1526930322466};\\\", \\\"{x:765,y:619,t:1526930322501};\\\", \\\"{x:764,y:619,t:1526930322517};\\\", \\\"{x:761,y:619,t:1526930322533};\\\", \\\"{x:752,y:617,t:1526930322550};\\\", \\\"{x:741,y:612,t:1526930322566};\\\", \\\"{x:729,y:606,t:1526930322584};\\\", \\\"{x:720,y:602,t:1526930322601};\\\", \\\"{x:708,y:599,t:1526930322617};\\\", \\\"{x:696,y:596,t:1526930322633};\\\", \\\"{x:684,y:594,t:1526930322649};\\\", \\\"{x:677,y:593,t:1526930322666};\\\", \\\"{x:670,y:593,t:1526930322682};\\\", \\\"{x:663,y:593,t:1526930322700};\\\", \\\"{x:654,y:596,t:1526930322716};\\\", \\\"{x:644,y:600,t:1526930322732};\\\", \\\"{x:629,y:609,t:1526930322749};\\\", \\\"{x:613,y:618,t:1526930322767};\\\", \\\"{x:598,y:629,t:1526930322783};\\\", \\\"{x:588,y:635,t:1526930322800};\\\", \\\"{x:587,y:637,t:1526930322817};\\\", \\\"{x:584,y:641,t:1526930322832};\\\", \\\"{x:584,y:659,t:1526930322850};\\\", \\\"{x:583,y:678,t:1526930322867};\\\", \\\"{x:583,y:701,t:1526930322883};\\\", \\\"{x:583,y:725,t:1526930322900};\\\", \\\"{x:584,y:751,t:1526930322916};\\\", \\\"{x:587,y:782,t:1526930322933};\\\", \\\"{x:591,y:800,t:1526930322949};\\\", \\\"{x:592,y:807,t:1526930322967};\\\", \\\"{x:592,y:809,t:1526930322984};\\\", \\\"{x:592,y:808,t:1526930323038};\\\", \\\"{x:591,y:805,t:1526930323050};\\\", \\\"{x:590,y:803,t:1526930323067};\\\", \\\"{x:590,y:800,t:1526930323084};\\\", \\\"{x:590,y:799,t:1526930323100};\\\", \\\"{x:590,y:796,t:1526930323117};\\\", \\\"{x:590,y:792,t:1526930323134};\\\", \\\"{x:590,y:791,t:1526930323190};\\\", \\\"{x:590,y:788,t:1526930323201};\\\", \\\"{x:590,y:780,t:1526930323217};\\\", \\\"{x:588,y:768,t:1526930323234};\\\", \\\"{x:586,y:756,t:1526930323251};\\\", \\\"{x:586,y:745,t:1526930323269};\\\", \\\"{x:586,y:740,t:1526930323284};\\\", \\\"{x:586,y:739,t:1526930323301};\\\", \\\"{x:586,y:738,t:1526930323334};\\\", \\\"{x:586,y:737,t:1526930323351};\\\", \\\"{x:586,y:736,t:1526930323368};\\\", \\\"{x:587,y:734,t:1526930323384};\\\", \\\"{x:592,y:730,t:1526930323401};\\\", \\\"{x:601,y:721,t:1526930323418};\\\", \\\"{x:620,y:709,t:1526930323435};\\\", \\\"{x:651,y:696,t:1526930323451};\\\", \\\"{x:686,y:688,t:1526930323468};\\\", \\\"{x:718,y:682,t:1526930323486};\\\", \\\"{x:758,y:678,t:1526930323501};\\\", \\\"{x:814,y:678,t:1526930323518};\\\", \\\"{x:854,y:678,t:1526930323535};\\\", \\\"{x:910,y:680,t:1526930323550};\\\", \\\"{x:966,y:686,t:1526930323568};\\\", \\\"{x:1022,y:686,t:1526930323586};\\\", \\\"{x:1087,y:684,t:1526930323602};\\\", \\\"{x:1154,y:672,t:1526930323619};\\\", \\\"{x:1210,y:657,t:1526930323635};\\\", \\\"{x:1249,y:638,t:1526930323653};\\\", \\\"{x:1290,y:620,t:1526930323668};\\\", \\\"{x:1329,y:604,t:1526930323686};\\\", \\\"{x:1370,y:592,t:1526930323702};\\\", \\\"{x:1395,y:586,t:1526930323719};\\\", \\\"{x:1424,y:578,t:1526930323735};\\\", \\\"{x:1456,y:574,t:1526930323751};\\\", \\\"{x:1487,y:569,t:1526930323769};\\\", \\\"{x:1512,y:566,t:1526930323784};\\\", \\\"{x:1540,y:563,t:1526930323802};\\\", \\\"{x:1564,y:560,t:1526930323819};\\\", \\\"{x:1584,y:551,t:1526930323835};\\\", \\\"{x:1607,y:540,t:1526930323852};\\\", \\\"{x:1629,y:525,t:1526930323869};\\\", \\\"{x:1643,y:510,t:1526930323885};\\\", \\\"{x:1643,y:508,t:1526930323901};\\\", \\\"{x:1644,y:507,t:1526930323918};\\\", \\\"{x:1638,y:508,t:1526930323965};\\\", \\\"{x:1624,y:519,t:1526930323974};\\\", \\\"{x:1609,y:533,t:1526930323986};\\\", \\\"{x:1574,y:563,t:1526930324002};\\\", \\\"{x:1528,y:597,t:1526930324020};\\\", \\\"{x:1484,y:632,t:1526930324036};\\\", \\\"{x:1448,y:664,t:1526930324052};\\\", \\\"{x:1420,y:688,t:1526930324069};\\\", \\\"{x:1400,y:707,t:1526930324085};\\\", \\\"{x:1397,y:709,t:1526930324103};\\\", \\\"{x:1395,y:710,t:1526930324119};\\\", \\\"{x:1394,y:712,t:1526930324137};\\\", \\\"{x:1393,y:713,t:1526930324154};\\\", \\\"{x:1391,y:716,t:1526930324170};\\\", \\\"{x:1391,y:717,t:1526930324186};\\\", \\\"{x:1391,y:721,t:1526930324203};\\\", \\\"{x:1390,y:723,t:1526930324219};\\\", \\\"{x:1390,y:726,t:1526930324237};\\\", \\\"{x:1389,y:727,t:1526930324253};\\\", \\\"{x:1389,y:728,t:1526930324286};\\\", \\\"{x:1389,y:729,t:1526930324303};\\\", \\\"{x:1389,y:730,t:1526930324321};\\\", \\\"{x:1388,y:730,t:1526930324336};\\\", \\\"{x:1387,y:731,t:1526930324358};\\\", \\\"{x:1386,y:731,t:1526930324374};\\\", \\\"{x:1386,y:733,t:1526930324387};\\\", \\\"{x:1385,y:734,t:1526930324404};\\\", \\\"{x:1384,y:735,t:1526930324420};\\\", \\\"{x:1383,y:736,t:1526930324437};\\\", \\\"{x:1382,y:737,t:1526930324453};\\\", \\\"{x:1381,y:737,t:1526930324470};\\\", \\\"{x:1376,y:737,t:1526930324487};\\\", \\\"{x:1362,y:724,t:1526930324504};\\\", \\\"{x:1343,y:705,t:1526930324521};\\\", \\\"{x:1322,y:686,t:1526930324537};\\\", \\\"{x:1301,y:670,t:1526930324553};\\\", \\\"{x:1287,y:662,t:1526930324570};\\\", \\\"{x:1282,y:660,t:1526930324586};\\\", \\\"{x:1281,y:660,t:1526930324604};\\\", \\\"{x:1280,y:660,t:1526930324620};\\\", \\\"{x:1278,y:660,t:1526930324637};\\\", \\\"{x:1279,y:665,t:1526930324653};\\\", \\\"{x:1284,y:669,t:1526930324670};\\\", \\\"{x:1292,y:675,t:1526930324687};\\\", \\\"{x:1304,y:680,t:1526930324704};\\\", \\\"{x:1312,y:684,t:1526930324721};\\\", \\\"{x:1317,y:685,t:1526930324736};\\\", \\\"{x:1321,y:685,t:1526930324754};\\\", \\\"{x:1324,y:685,t:1526930324771};\\\", \\\"{x:1328,y:685,t:1526930324787};\\\", \\\"{x:1332,y:685,t:1526930324804};\\\", \\\"{x:1337,y:685,t:1526930324821};\\\", \\\"{x:1343,y:687,t:1526930324837};\\\", \\\"{x:1355,y:693,t:1526930324855};\\\", \\\"{x:1360,y:695,t:1526930324871};\\\", \\\"{x:1361,y:696,t:1526930324889};\\\", \\\"{x:1363,y:696,t:1526930324904};\\\", \\\"{x:1363,y:698,t:1526930325078};\\\", \\\"{x:1363,y:700,t:1526930325094};\\\", \\\"{x:1362,y:702,t:1526930325106};\\\", \\\"{x:1361,y:704,t:1526930325122};\\\", \\\"{x:1359,y:706,t:1526930325139};\\\", \\\"{x:1357,y:706,t:1526930325155};\\\", \\\"{x:1355,y:706,t:1526930325171};\\\", \\\"{x:1351,y:704,t:1526930325188};\\\", \\\"{x:1348,y:702,t:1526930325208};\\\", \\\"{x:1345,y:700,t:1526930325222};\\\", \\\"{x:1344,y:700,t:1526930325237};\\\", \\\"{x:1344,y:699,t:1526930325791};\\\", \\\"{x:1344,y:702,t:1526930325944};\\\", \\\"{x:1345,y:704,t:1526930325957};\\\", \\\"{x:1348,y:709,t:1526930325973};\\\", \\\"{x:1351,y:713,t:1526930325990};\\\", \\\"{x:1352,y:714,t:1526930326007};\\\", \\\"{x:1352,y:715,t:1526930326182};\\\", \\\"{x:1352,y:716,t:1526930326190};\\\", \\\"{x:1354,y:720,t:1526930326208};\\\", \\\"{x:1356,y:723,t:1526930326224};\\\", \\\"{x:1357,y:725,t:1526930326241};\\\", \\\"{x:1359,y:726,t:1526930326257};\\\", \\\"{x:1359,y:727,t:1526930326275};\\\", \\\"{x:1361,y:729,t:1526930326291};\\\", \\\"{x:1363,y:733,t:1526930326307};\\\", \\\"{x:1368,y:739,t:1526930326325};\\\", \\\"{x:1372,y:745,t:1526930326342};\\\", \\\"{x:1375,y:753,t:1526930326358};\\\", \\\"{x:1383,y:768,t:1526930326374};\\\", \\\"{x:1390,y:783,t:1526930326392};\\\", \\\"{x:1400,y:802,t:1526930326408};\\\", \\\"{x:1410,y:817,t:1526930326425};\\\", \\\"{x:1418,y:833,t:1526930326441};\\\", \\\"{x:1426,y:842,t:1526930326457};\\\", \\\"{x:1429,y:846,t:1526930326474};\\\", \\\"{x:1430,y:847,t:1526930326492};\\\", \\\"{x:1430,y:849,t:1526930327341};\\\", \\\"{x:1430,y:851,t:1526930327349};\\\", \\\"{x:1432,y:853,t:1526930327502};\\\", \\\"{x:1433,y:854,t:1526930327509};\\\", \\\"{x:1434,y:859,t:1526930327526};\\\", \\\"{x:1436,y:861,t:1526930327543};\\\", \\\"{x:1436,y:862,t:1526930327560};\\\", \\\"{x:1435,y:857,t:1526930327646};\\\", \\\"{x:1431,y:850,t:1526930327660};\\\", \\\"{x:1413,y:808,t:1526930327678};\\\", \\\"{x:1396,y:774,t:1526930327694};\\\", \\\"{x:1383,y:744,t:1526930327710};\\\", \\\"{x:1375,y:730,t:1526930327728};\\\", \\\"{x:1373,y:725,t:1526930327743};\\\", \\\"{x:1372,y:723,t:1526930327761};\\\", \\\"{x:1371,y:722,t:1526930327777};\\\", \\\"{x:1369,y:721,t:1526930328013};\\\", \\\"{x:1368,y:720,t:1526930328026};\\\", \\\"{x:1366,y:719,t:1526930328044};\\\", \\\"{x:1365,y:718,t:1526930328061};\\\", \\\"{x:1365,y:719,t:1526930328109};\\\", \\\"{x:1367,y:723,t:1526930328117};\\\", \\\"{x:1370,y:728,t:1526930328128};\\\", \\\"{x:1377,y:741,t:1526930328144};\\\", \\\"{x:1387,y:756,t:1526930328161};\\\", \\\"{x:1394,y:769,t:1526930328178};\\\", \\\"{x:1401,y:778,t:1526930328194};\\\", \\\"{x:1405,y:788,t:1526930328211};\\\", \\\"{x:1411,y:796,t:1526930328229};\\\", \\\"{x:1414,y:800,t:1526930328244};\\\", \\\"{x:1415,y:801,t:1526930328262};\\\", \\\"{x:1416,y:804,t:1526930328278};\\\", \\\"{x:1417,y:805,t:1526930328295};\\\", \\\"{x:1418,y:806,t:1526930328311};\\\", \\\"{x:1418,y:812,t:1526930328328};\\\", \\\"{x:1423,y:821,t:1526930328345};\\\", \\\"{x:1429,y:836,t:1526930328361};\\\", \\\"{x:1437,y:849,t:1526930328378};\\\", \\\"{x:1443,y:864,t:1526930328395};\\\", \\\"{x:1453,y:881,t:1526930328413};\\\", \\\"{x:1461,y:897,t:1526930328429};\\\", \\\"{x:1475,y:915,t:1526930328446};\\\", \\\"{x:1478,y:919,t:1526930328461};\\\", \\\"{x:1478,y:920,t:1526930328567};\\\", \\\"{x:1480,y:925,t:1526930328580};\\\", \\\"{x:1482,y:936,t:1526930328595};\\\", \\\"{x:1486,y:949,t:1526930328612};\\\", \\\"{x:1488,y:959,t:1526930328630};\\\", \\\"{x:1490,y:962,t:1526930328646};\\\", \\\"{x:1490,y:963,t:1526930328663};\\\", \\\"{x:1491,y:964,t:1526930328774};\\\", \\\"{x:1491,y:968,t:1526930328782};\\\", \\\"{x:1491,y:971,t:1526930328797};\\\", \\\"{x:1495,y:980,t:1526930328812};\\\", \\\"{x:1500,y:994,t:1526930328831};\\\", \\\"{x:1501,y:998,t:1526930328846};\\\", \\\"{x:1503,y:1001,t:1526930328863};\\\", \\\"{x:1503,y:1002,t:1526930328886};\\\", \\\"{x:1503,y:1000,t:1526930328974};\\\", \\\"{x:1502,y:997,t:1526930328982};\\\", \\\"{x:1499,y:991,t:1526930328997};\\\", \\\"{x:1497,y:984,t:1526930329014};\\\", \\\"{x:1492,y:977,t:1526930329030};\\\", \\\"{x:1483,y:966,t:1526930329047};\\\", \\\"{x:1474,y:954,t:1526930329063};\\\", \\\"{x:1468,y:945,t:1526930329080};\\\", \\\"{x:1463,y:937,t:1526930329096};\\\", \\\"{x:1457,y:927,t:1526930329113};\\\", \\\"{x:1448,y:915,t:1526930329131};\\\", \\\"{x:1437,y:900,t:1526930329147};\\\", \\\"{x:1425,y:885,t:1526930329164};\\\", \\\"{x:1412,y:869,t:1526930329181};\\\", \\\"{x:1392,y:846,t:1526930329198};\\\", \\\"{x:1380,y:835,t:1526930329214};\\\", \\\"{x:1373,y:826,t:1526930329231};\\\", \\\"{x:1365,y:814,t:1526930329248};\\\", \\\"{x:1355,y:798,t:1526930329264};\\\", \\\"{x:1346,y:775,t:1526930329281};\\\", \\\"{x:1335,y:750,t:1526930329297};\\\", \\\"{x:1323,y:726,t:1526930329314};\\\", \\\"{x:1311,y:700,t:1526930329330};\\\", \\\"{x:1301,y:677,t:1526930329347};\\\", \\\"{x:1290,y:648,t:1526930329363};\\\", \\\"{x:1271,y:615,t:1526930329380};\\\", \\\"{x:1252,y:585,t:1526930329397};\\\", \\\"{x:1243,y:569,t:1526930329413};\\\", \\\"{x:1239,y:561,t:1526930329430};\\\", \\\"{x:1238,y:557,t:1526930329447};\\\", \\\"{x:1236,y:553,t:1526930329464};\\\", \\\"{x:1235,y:552,t:1526930329480};\\\", \\\"{x:1235,y:551,t:1526930329647};\\\", \\\"{x:1231,y:550,t:1526930329665};\\\", \\\"{x:1219,y:553,t:1526930329681};\\\", \\\"{x:1199,y:559,t:1526930329699};\\\", \\\"{x:1159,y:563,t:1526930329715};\\\", \\\"{x:1089,y:563,t:1526930329731};\\\", \\\"{x:997,y:560,t:1526930329748};\\\", \\\"{x:903,y:550,t:1526930329764};\\\", \\\"{x:802,y:538,t:1526930329780};\\\", \\\"{x:739,y:525,t:1526930329798};\\\", \\\"{x:656,y:504,t:1526930329823};\\\", \\\"{x:611,y:489,t:1526930329838};\\\", \\\"{x:583,y:480,t:1526930329855};\\\", \\\"{x:570,y:475,t:1526930329872};\\\", \\\"{x:568,y:475,t:1526930329888};\\\", \\\"{x:566,y:475,t:1526930329941};\\\", \\\"{x:565,y:475,t:1526930329956};\\\", \\\"{x:564,y:477,t:1526930329972};\\\", \\\"{x:564,y:478,t:1526930329989};\\\", \\\"{x:564,y:479,t:1526930330013};\\\", \\\"{x:565,y:483,t:1526930330022};\\\", \\\"{x:584,y:488,t:1526930330040};\\\", \\\"{x:604,y:491,t:1526930330056};\\\", \\\"{x:617,y:494,t:1526930330072};\\\", \\\"{x:634,y:497,t:1526930330089};\\\", \\\"{x:643,y:499,t:1526930330106};\\\", \\\"{x:647,y:501,t:1526930330122};\\\", \\\"{x:648,y:502,t:1526930330138};\\\", \\\"{x:647,y:502,t:1526930330262};\\\", \\\"{x:645,y:502,t:1526930330272};\\\", \\\"{x:640,y:500,t:1526930330289};\\\", \\\"{x:635,y:498,t:1526930330306};\\\", \\\"{x:631,y:495,t:1526930330322};\\\", \\\"{x:628,y:495,t:1526930330339};\\\", \\\"{x:626,y:495,t:1526930330356};\\\", \\\"{x:624,y:495,t:1526930330373};\\\", \\\"{x:621,y:495,t:1526930330389};\\\", \\\"{x:618,y:498,t:1526930330406};\\\", \\\"{x:615,y:502,t:1526930330423};\\\", \\\"{x:613,y:502,t:1526930330439};\\\", \\\"{x:612,y:502,t:1526930330470};\\\", \\\"{x:611,y:502,t:1526930330494};\\\", \\\"{x:610,y:502,t:1526930330506};\\\", \\\"{x:609,y:502,t:1526930330534};\\\", \\\"{x:608,y:502,t:1526930330558};\\\", \\\"{x:607,y:504,t:1526930331486};\\\", \\\"{x:606,y:515,t:1526930331495};\\\", \\\"{x:606,y:532,t:1526930331508};\\\", \\\"{x:604,y:561,t:1526930331524};\\\", \\\"{x:597,y:588,t:1526930331540};\\\", \\\"{x:586,y:619,t:1526930331557};\\\", \\\"{x:581,y:629,t:1526930331573};\\\", \\\"{x:579,y:633,t:1526930331590};\\\", \\\"{x:578,y:634,t:1526930331607};\\\", \\\"{x:578,y:635,t:1526930331661};\\\", \\\"{x:577,y:638,t:1526930331674};\\\", \\\"{x:576,y:643,t:1526930331690};\\\", \\\"{x:574,y:654,t:1526930331707};\\\", \\\"{x:572,y:665,t:1526930331724};\\\", \\\"{x:572,y:676,t:1526930331741};\\\", \\\"{x:572,y:680,t:1526930331757};\\\", \\\"{x:570,y:686,t:1526930331774};\\\", \\\"{x:570,y:688,t:1526930331934};\\\", \\\"{x:570,y:689,t:1526930331942};\\\", \\\"{x:570,y:692,t:1526930331958};\\\", \\\"{x:570,y:694,t:1526930331974};\\\", \\\"{x:570,y:695,t:1526930331991};\\\", \\\"{x:570,y:696,t:1526930332009};\\\", \\\"{x:570,y:697,t:1526930332166};\\\", \\\"{x:570,y:698,t:1526930332176};\\\", \\\"{x:570,y:700,t:1526930332191};\\\", \\\"{x:571,y:702,t:1526930332209};\\\", \\\"{x:571,y:703,t:1526930332270};\\\", \\\"{x:571,y:704,t:1526930332350};\\\", \\\"{x:571,y:705,t:1526930332359};\\\", \\\"{x:568,y:710,t:1526930332375};\\\", \\\"{x:566,y:714,t:1526930332392};\\\", \\\"{x:564,y:717,t:1526930332409};\\\", \\\"{x:562,y:720,t:1526930332426};\\\", \\\"{x:559,y:723,t:1526930332444};\\\", \\\"{x:558,y:724,t:1526930332458};\\\", \\\"{x:556,y:726,t:1526930332573};\\\", \\\"{x:555,y:729,t:1526930332590};\\\", \\\"{x:554,y:732,t:1526930332606};\\\", \\\"{x:551,y:735,t:1526930332623};\\\", \\\"{x:550,y:736,t:1526930332765};\\\", \\\"{x:550,y:736,t:1526930332905};\\\" ] }, { \\\"rt\\\": 14284, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 15, \\\"time_elapsed\\\": 709700, \\\"internal_node_id\\\": \\\"0.0-6.0-5.0\\\", \\\"subject\\\": \\\"WKBNA\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 11, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"M\\\", \\\"L\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-04 PM-05 PM-06 PM-12 PM-12 PM-M -L -I -06 PM-M \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:550,y:734,t:1526930334902};\\\", \\\"{x:550,y:733,t:1526930334913};\\\", \\\"{x:550,y:730,t:1526930334934};\\\", \\\"{x:550,y:727,t:1526930334946};\\\", \\\"{x:554,y:725,t:1526930334962};\\\", \\\"{x:564,y:720,t:1526930334980};\\\", \\\"{x:578,y:715,t:1526930334996};\\\", \\\"{x:602,y:714,t:1526930335010};\\\", \\\"{x:633,y:714,t:1526930335026};\\\", \\\"{x:694,y:730,t:1526930335043};\\\", \\\"{x:801,y:756,t:1526930335060};\\\", \\\"{x:907,y:786,t:1526930335076};\\\", \\\"{x:1103,y:822,t:1526930335094};\\\", \\\"{x:1223,y:843,t:1526930335110};\\\", \\\"{x:1339,y:859,t:1526930335127};\\\", \\\"{x:1451,y:880,t:1526930335143};\\\", \\\"{x:1555,y:906,t:1526930335160};\\\", \\\"{x:1663,y:934,t:1526930335176};\\\", \\\"{x:1750,y:965,t:1526930335194};\\\", \\\"{x:1812,y:995,t:1526930335211};\\\", \\\"{x:1855,y:1012,t:1526930335227};\\\", \\\"{x:1879,y:1023,t:1526930335243};\\\", \\\"{x:1896,y:1028,t:1526930335261};\\\", \\\"{x:1909,y:1033,t:1526930335278};\\\", \\\"{x:1911,y:1034,t:1526930335293};\\\", \\\"{x:1911,y:1033,t:1526930335334};\\\", \\\"{x:1911,y:1030,t:1526930335344};\\\", \\\"{x:1904,y:1021,t:1526930335361};\\\", \\\"{x:1894,y:1012,t:1526930335377};\\\", \\\"{x:1886,y:1008,t:1526930335394};\\\", \\\"{x:1876,y:1005,t:1526930335411};\\\", \\\"{x:1861,y:1005,t:1526930335427};\\\", \\\"{x:1838,y:1005,t:1526930335444};\\\", \\\"{x:1815,y:1005,t:1526930335460};\\\", \\\"{x:1773,y:1005,t:1526930335478};\\\", \\\"{x:1747,y:1005,t:1526930335494};\\\", \\\"{x:1720,y:1005,t:1526930335511};\\\", \\\"{x:1693,y:1002,t:1526930335527};\\\", \\\"{x:1663,y:997,t:1526930335544};\\\", \\\"{x:1645,y:991,t:1526930335561};\\\", \\\"{x:1634,y:988,t:1526930335578};\\\", \\\"{x:1632,y:987,t:1526930335594};\\\", \\\"{x:1632,y:986,t:1526930335774};\\\", \\\"{x:1631,y:985,t:1526930335782};\\\", \\\"{x:1631,y:984,t:1526930335795};\\\", \\\"{x:1631,y:982,t:1526930335810};\\\", \\\"{x:1631,y:981,t:1526930335854};\\\", \\\"{x:1633,y:980,t:1526930335878};\\\", \\\"{x:1634,y:979,t:1526930335894};\\\", \\\"{x:1641,y:978,t:1526930335912};\\\", \\\"{x:1647,y:978,t:1526930335928};\\\", \\\"{x:1654,y:978,t:1526930335945};\\\", \\\"{x:1666,y:976,t:1526930335960};\\\", \\\"{x:1678,y:975,t:1526930335977};\\\", \\\"{x:1688,y:973,t:1526930335995};\\\", \\\"{x:1695,y:971,t:1526930336012};\\\", \\\"{x:1703,y:968,t:1526930336028};\\\", \\\"{x:1710,y:968,t:1526930336045};\\\", \\\"{x:1720,y:968,t:1526930336061};\\\", \\\"{x:1726,y:968,t:1526930336078};\\\", \\\"{x:1736,y:970,t:1526930336095};\\\", \\\"{x:1743,y:973,t:1526930336112};\\\", \\\"{x:1754,y:975,t:1526930336128};\\\", \\\"{x:1761,y:976,t:1526930336145};\\\", \\\"{x:1769,y:977,t:1526930336162};\\\", \\\"{x:1772,y:977,t:1526930336178};\\\", \\\"{x:1775,y:977,t:1526930336195};\\\", \\\"{x:1776,y:977,t:1526930336212};\\\", \\\"{x:1777,y:977,t:1526930336228};\\\", \\\"{x:1778,y:976,t:1526930336245};\\\", \\\"{x:1778,y:975,t:1526930336261};\\\", \\\"{x:1778,y:974,t:1526930336310};\\\", \\\"{x:1778,y:972,t:1526930336318};\\\", \\\"{x:1774,y:971,t:1526930336328};\\\", \\\"{x:1750,y:968,t:1526930336345};\\\", \\\"{x:1706,y:963,t:1526930336362};\\\", \\\"{x:1643,y:958,t:1526930336378};\\\", \\\"{x:1579,y:949,t:1526930336394};\\\", \\\"{x:1514,y:946,t:1526930336411};\\\", \\\"{x:1442,y:935,t:1526930336428};\\\", \\\"{x:1372,y:927,t:1526930336444};\\\", \\\"{x:1307,y:918,t:1526930336461};\\\", \\\"{x:1285,y:918,t:1526930336479};\\\", \\\"{x:1272,y:918,t:1526930336494};\\\", \\\"{x:1270,y:918,t:1526930336511};\\\", \\\"{x:1269,y:920,t:1526930336528};\\\", \\\"{x:1268,y:925,t:1526930336544};\\\", \\\"{x:1268,y:932,t:1526930336562};\\\", \\\"{x:1268,y:939,t:1526930336578};\\\", \\\"{x:1268,y:945,t:1526930336595};\\\", \\\"{x:1269,y:951,t:1526930336612};\\\", \\\"{x:1272,y:955,t:1526930336628};\\\", \\\"{x:1272,y:956,t:1526930336645};\\\", \\\"{x:1274,y:957,t:1526930336718};\\\", \\\"{x:1280,y:958,t:1526930336729};\\\", \\\"{x:1289,y:959,t:1526930336745};\\\", \\\"{x:1306,y:962,t:1526930336762};\\\", \\\"{x:1326,y:966,t:1526930336779};\\\", \\\"{x:1341,y:968,t:1526930336796};\\\", \\\"{x:1358,y:972,t:1526930336812};\\\", \\\"{x:1367,y:972,t:1526930336829};\\\", \\\"{x:1376,y:968,t:1526930336846};\\\", \\\"{x:1379,y:963,t:1526930336861};\\\", \\\"{x:1379,y:960,t:1526930336879};\\\", \\\"{x:1379,y:958,t:1526930336896};\\\", \\\"{x:1379,y:957,t:1526930336911};\\\", \\\"{x:1379,y:956,t:1526930337006};\\\", \\\"{x:1378,y:956,t:1526930337021};\\\", \\\"{x:1378,y:958,t:1526930337029};\\\", \\\"{x:1376,y:961,t:1526930337046};\\\", \\\"{x:1375,y:962,t:1526930337062};\\\", \\\"{x:1374,y:963,t:1526930337199};\\\", \\\"{x:1373,y:964,t:1526930337214};\\\", \\\"{x:1372,y:965,t:1526930337229};\\\", \\\"{x:1371,y:968,t:1526930337246};\\\", \\\"{x:1370,y:970,t:1526930337262};\\\", \\\"{x:1369,y:971,t:1526930337279};\\\", \\\"{x:1368,y:971,t:1526930337351};\\\", \\\"{x:1367,y:971,t:1526930337363};\\\", \\\"{x:1366,y:970,t:1526930337379};\\\", \\\"{x:1365,y:969,t:1526930337396};\\\", \\\"{x:1365,y:967,t:1526930337543};\\\", \\\"{x:1365,y:965,t:1526930337557};\\\", \\\"{x:1365,y:964,t:1526930337566};\\\", \\\"{x:1365,y:962,t:1526930337582};\\\", \\\"{x:1365,y:961,t:1526930337596};\\\", \\\"{x:1364,y:961,t:1526930337613};\\\", \\\"{x:1364,y:960,t:1526930337798};\\\", \\\"{x:1364,y:959,t:1526930337814};\\\", \\\"{x:1363,y:959,t:1526930337910};\\\", \\\"{x:1362,y:959,t:1526930337926};\\\", \\\"{x:1360,y:959,t:1526930337934};\\\", \\\"{x:1359,y:959,t:1526930338246};\\\", \\\"{x:1357,y:959,t:1526930338264};\\\", \\\"{x:1357,y:958,t:1526930338902};\\\", \\\"{x:1356,y:958,t:1526930338914};\\\", \\\"{x:1355,y:958,t:1526930339470};\\\", \\\"{x:1355,y:956,t:1526930339790};\\\", \\\"{x:1355,y:955,t:1526930339798};\\\", \\\"{x:1355,y:954,t:1526930339814};\\\", \\\"{x:1357,y:953,t:1526930339832};\\\", \\\"{x:1357,y:951,t:1526930339949};\\\", \\\"{x:1357,y:949,t:1526930339965};\\\", \\\"{x:1361,y:940,t:1526930339981};\\\", \\\"{x:1363,y:935,t:1526930339998};\\\", \\\"{x:1366,y:930,t:1526930340014};\\\", \\\"{x:1368,y:928,t:1526930340032};\\\", \\\"{x:1369,y:926,t:1526930340158};\\\", \\\"{x:1369,y:925,t:1526930340165};\\\", \\\"{x:1370,y:921,t:1526930340181};\\\", \\\"{x:1372,y:917,t:1526930340199};\\\", \\\"{x:1374,y:912,t:1526930340215};\\\", \\\"{x:1375,y:907,t:1526930340232};\\\", \\\"{x:1376,y:906,t:1526930340249};\\\", \\\"{x:1376,y:905,t:1526930340265};\\\", \\\"{x:1377,y:904,t:1526930340407};\\\", \\\"{x:1377,y:901,t:1526930340416};\\\", \\\"{x:1379,y:899,t:1526930340434};\\\", \\\"{x:1379,y:897,t:1526930340449};\\\", \\\"{x:1381,y:895,t:1526930340465};\\\", \\\"{x:1381,y:894,t:1526930340481};\\\", \\\"{x:1382,y:893,t:1526930340499};\\\", \\\"{x:1383,y:893,t:1526930340630};\\\", \\\"{x:1387,y:889,t:1526930340638};\\\", \\\"{x:1389,y:886,t:1526930340648};\\\", \\\"{x:1397,y:871,t:1526930340666};\\\", \\\"{x:1404,y:854,t:1526930340682};\\\", \\\"{x:1414,y:837,t:1526930340698};\\\", \\\"{x:1433,y:800,t:1526930340716};\\\", \\\"{x:1461,y:751,t:1526930340733};\\\", \\\"{x:1489,y:709,t:1526930340749};\\\", \\\"{x:1530,y:643,t:1526930340765};\\\", \\\"{x:1551,y:608,t:1526930340783};\\\", \\\"{x:1574,y:565,t:1526930340799};\\\", \\\"{x:1586,y:530,t:1526930340816};\\\", \\\"{x:1597,y:504,t:1526930340833};\\\", \\\"{x:1601,y:485,t:1526930340848};\\\", \\\"{x:1606,y:464,t:1526930340866};\\\", \\\"{x:1609,y:444,t:1526930340882};\\\", \\\"{x:1612,y:430,t:1526930340898};\\\", \\\"{x:1617,y:417,t:1526930340916};\\\", \\\"{x:1621,y:408,t:1526930340932};\\\", \\\"{x:1623,y:404,t:1526930340948};\\\", \\\"{x:1623,y:403,t:1526930341013};\\\", \\\"{x:1620,y:406,t:1526930341029};\\\", \\\"{x:1618,y:411,t:1526930341037};\\\", \\\"{x:1615,y:418,t:1526930341049};\\\", \\\"{x:1609,y:437,t:1526930341065};\\\", \\\"{x:1602,y:455,t:1526930341083};\\\", \\\"{x:1597,y:468,t:1526930341100};\\\", \\\"{x:1591,y:476,t:1526930341116};\\\", \\\"{x:1589,y:478,t:1526930341133};\\\", \\\"{x:1589,y:481,t:1526930341150};\\\", \\\"{x:1586,y:483,t:1526930341166};\\\", \\\"{x:1585,y:488,t:1526930341183};\\\", \\\"{x:1582,y:494,t:1526930341200};\\\", \\\"{x:1582,y:497,t:1526930341216};\\\", \\\"{x:1580,y:501,t:1526930341233};\\\", \\\"{x:1579,y:505,t:1526930341251};\\\", \\\"{x:1578,y:507,t:1526930341265};\\\", \\\"{x:1577,y:508,t:1526930341283};\\\", \\\"{x:1577,y:509,t:1526930341302};\\\", \\\"{x:1577,y:510,t:1526930341316};\\\", \\\"{x:1577,y:512,t:1526930341374};\\\", \\\"{x:1577,y:516,t:1526930341383};\\\", \\\"{x:1567,y:536,t:1526930341400};\\\", \\\"{x:1553,y:559,t:1526930341417};\\\", \\\"{x:1537,y:586,t:1526930341433};\\\", \\\"{x:1520,y:613,t:1526930341451};\\\", \\\"{x:1503,y:636,t:1526930341467};\\\", \\\"{x:1490,y:655,t:1526930341483};\\\", \\\"{x:1477,y:679,t:1526930341500};\\\", \\\"{x:1462,y:702,t:1526930341517};\\\", \\\"{x:1443,y:728,t:1526930341533};\\\", \\\"{x:1424,y:757,t:1526930341549};\\\", \\\"{x:1414,y:777,t:1526930341567};\\\", \\\"{x:1404,y:797,t:1526930341583};\\\", \\\"{x:1397,y:816,t:1526930341601};\\\", \\\"{x:1389,y:833,t:1526930341617};\\\", \\\"{x:1383,y:849,t:1526930341633};\\\", \\\"{x:1374,y:867,t:1526930341650};\\\", \\\"{x:1363,y:882,t:1526930341667};\\\", \\\"{x:1349,y:893,t:1526930341683};\\\", \\\"{x:1327,y:902,t:1526930341700};\\\", \\\"{x:1295,y:905,t:1526930341717};\\\", \\\"{x:1255,y:905,t:1526930341733};\\\", \\\"{x:1130,y:865,t:1526930341750};\\\", \\\"{x:1027,y:818,t:1526930341767};\\\", \\\"{x:933,y:776,t:1526930341784};\\\", \\\"{x:863,y:751,t:1526930341800};\\\", \\\"{x:804,y:734,t:1526930341816};\\\", \\\"{x:771,y:725,t:1526930341834};\\\", \\\"{x:749,y:721,t:1526930341850};\\\", \\\"{x:740,y:721,t:1526930341867};\\\", \\\"{x:737,y:721,t:1526930341884};\\\", \\\"{x:736,y:721,t:1526930341926};\\\", \\\"{x:736,y:720,t:1526930341933};\\\", \\\"{x:729,y:707,t:1526930341950};\\\", \\\"{x:721,y:691,t:1526930341966};\\\", \\\"{x:703,y:668,t:1526930341985};\\\", \\\"{x:681,y:650,t:1526930342000};\\\", \\\"{x:640,y:620,t:1526930342019};\\\", \\\"{x:596,y:594,t:1526930342035};\\\", \\\"{x:556,y:581,t:1526930342050};\\\", \\\"{x:532,y:576,t:1526930342066};\\\", \\\"{x:520,y:575,t:1526930342082};\\\", \\\"{x:513,y:575,t:1526930342098};\\\", \\\"{x:507,y:575,t:1526930342115};\\\", \\\"{x:504,y:575,t:1526930342132};\\\", \\\"{x:499,y:576,t:1526930342149};\\\", \\\"{x:494,y:576,t:1526930342166};\\\", \\\"{x:488,y:576,t:1526930342182};\\\", \\\"{x:477,y:574,t:1526930342198};\\\", \\\"{x:467,y:570,t:1526930342215};\\\", \\\"{x:458,y:568,t:1526930342233};\\\", \\\"{x:450,y:568,t:1526930342249};\\\", \\\"{x:443,y:567,t:1526930342265};\\\", \\\"{x:437,y:567,t:1526930342282};\\\", \\\"{x:430,y:567,t:1526930342299};\\\", \\\"{x:424,y:567,t:1526930342315};\\\", \\\"{x:418,y:566,t:1526930342332};\\\", \\\"{x:413,y:563,t:1526930342349};\\\", \\\"{x:412,y:561,t:1526930342366};\\\", \\\"{x:409,y:556,t:1526930342382};\\\", \\\"{x:406,y:548,t:1526930342400};\\\", \\\"{x:404,y:545,t:1526930342415};\\\", \\\"{x:402,y:541,t:1526930342432};\\\", \\\"{x:401,y:539,t:1526930342450};\\\", \\\"{x:399,y:538,t:1526930342466};\\\", \\\"{x:399,y:537,t:1526930342482};\\\", \\\"{x:397,y:536,t:1526930342499};\\\", \\\"{x:395,y:534,t:1526930342516};\\\", \\\"{x:393,y:533,t:1526930342532};\\\", \\\"{x:392,y:533,t:1526930342581};\\\", \\\"{x:391,y:532,t:1526930342605};\\\", \\\"{x:390,y:531,t:1526930342621};\\\", \\\"{x:390,y:535,t:1526930342973};\\\", \\\"{x:391,y:543,t:1526930342983};\\\", \\\"{x:392,y:559,t:1526930343000};\\\", \\\"{x:394,y:571,t:1526930343017};\\\", \\\"{x:395,y:580,t:1526930343034};\\\", \\\"{x:395,y:587,t:1526930343049};\\\", \\\"{x:396,y:591,t:1526930343067};\\\", \\\"{x:396,y:594,t:1526930343083};\\\", \\\"{x:396,y:595,t:1526930343099};\\\", \\\"{x:397,y:597,t:1526930343116};\\\", \\\"{x:398,y:601,t:1526930343134};\\\", \\\"{x:398,y:605,t:1526930343151};\\\", \\\"{x:398,y:609,t:1526930343166};\\\", \\\"{x:398,y:611,t:1526930343183};\\\", \\\"{x:398,y:613,t:1526930343199};\\\", \\\"{x:398,y:615,t:1526930343254};\\\", \\\"{x:396,y:615,t:1526930343285};\\\", \\\"{x:397,y:615,t:1526930343958};\\\", \\\"{x:404,y:615,t:1526930343967};\\\", \\\"{x:418,y:613,t:1526930343984};\\\", \\\"{x:434,y:613,t:1526930344001};\\\", \\\"{x:463,y:613,t:1526930344017};\\\", \\\"{x:500,y:622,t:1526930344033};\\\", \\\"{x:566,y:640,t:1526930344051};\\\", \\\"{x:646,y:660,t:1526930344067};\\\", \\\"{x:731,y:683,t:1526930344083};\\\", \\\"{x:855,y:711,t:1526930344100};\\\", \\\"{x:936,y:724,t:1526930344117};\\\", \\\"{x:1014,y:735,t:1526930344133};\\\", \\\"{x:1103,y:750,t:1526930344150};\\\", \\\"{x:1179,y:763,t:1526930344168};\\\", \\\"{x:1252,y:775,t:1526930344184};\\\", \\\"{x:1342,y:796,t:1526930344201};\\\", \\\"{x:1416,y:826,t:1526930344218};\\\", \\\"{x:1508,y:865,t:1526930344235};\\\", \\\"{x:1593,y:904,t:1526930344251};\\\", \\\"{x:1649,y:941,t:1526930344267};\\\", \\\"{x:1687,y:963,t:1526930344285};\\\", \\\"{x:1713,y:974,t:1526930344301};\\\", \\\"{x:1726,y:978,t:1526930344318};\\\", \\\"{x:1728,y:978,t:1526930344335};\\\", \\\"{x:1730,y:978,t:1526930344351};\\\", \\\"{x:1729,y:972,t:1526930344368};\\\", \\\"{x:1721,y:962,t:1526930344386};\\\", \\\"{x:1706,y:948,t:1526930344401};\\\", \\\"{x:1685,y:935,t:1526930344419};\\\", \\\"{x:1664,y:926,t:1526930344435};\\\", \\\"{x:1643,y:919,t:1526930344451};\\\", \\\"{x:1619,y:916,t:1526930344468};\\\", \\\"{x:1598,y:916,t:1526930344485};\\\", \\\"{x:1581,y:916,t:1526930344501};\\\", \\\"{x:1548,y:922,t:1526930344518};\\\", \\\"{x:1530,y:927,t:1526930344535};\\\", \\\"{x:1516,y:933,t:1526930344551};\\\", \\\"{x:1507,y:934,t:1526930344568};\\\", \\\"{x:1500,y:934,t:1526930344585};\\\", \\\"{x:1494,y:934,t:1526930344601};\\\", \\\"{x:1490,y:934,t:1526930344618};\\\", \\\"{x:1484,y:935,t:1526930344635};\\\", \\\"{x:1478,y:937,t:1526930344651};\\\", \\\"{x:1472,y:940,t:1526930344668};\\\", \\\"{x:1467,y:945,t:1526930344685};\\\", \\\"{x:1458,y:953,t:1526930344702};\\\", \\\"{x:1452,y:961,t:1526930344718};\\\", \\\"{x:1446,y:965,t:1526930344735};\\\", \\\"{x:1443,y:968,t:1526930344752};\\\", \\\"{x:1443,y:969,t:1526930344798};\\\", \\\"{x:1443,y:970,t:1526930344814};\\\", \\\"{x:1443,y:971,t:1526930344829};\\\", \\\"{x:1444,y:971,t:1526930344838};\\\", \\\"{x:1445,y:971,t:1526930344902};\\\", \\\"{x:1446,y:972,t:1526930344926};\\\", \\\"{x:1446,y:973,t:1526930344942};\\\", \\\"{x:1446,y:975,t:1526930344952};\\\", \\\"{x:1446,y:977,t:1526930344968};\\\", \\\"{x:1445,y:976,t:1526930345030};\\\", \\\"{x:1445,y:973,t:1526930345038};\\\", \\\"{x:1441,y:969,t:1526930345052};\\\", \\\"{x:1435,y:962,t:1526930345069};\\\", \\\"{x:1427,y:956,t:1526930345085};\\\", \\\"{x:1415,y:952,t:1526930345102};\\\", \\\"{x:1408,y:952,t:1526930345121};\\\", \\\"{x:1402,y:952,t:1526930345135};\\\", \\\"{x:1394,y:952,t:1526930345152};\\\", \\\"{x:1389,y:954,t:1526930345169};\\\", \\\"{x:1383,y:956,t:1526930345185};\\\", \\\"{x:1379,y:957,t:1526930345202};\\\", \\\"{x:1371,y:958,t:1526930345219};\\\", \\\"{x:1364,y:958,t:1526930345236};\\\", \\\"{x:1357,y:958,t:1526930345252};\\\", \\\"{x:1355,y:958,t:1526930345269};\\\", \\\"{x:1352,y:958,t:1526930345285};\\\", \\\"{x:1351,y:958,t:1526930345302};\\\", \\\"{x:1351,y:959,t:1526930345366};\\\", \\\"{x:1351,y:960,t:1526930345382};\\\", \\\"{x:1351,y:962,t:1526930345390};\\\", \\\"{x:1351,y:963,t:1526930345406};\\\", \\\"{x:1350,y:963,t:1526930345470};\\\", \\\"{x:1349,y:963,t:1526930345486};\\\", \\\"{x:1347,y:962,t:1526930345503};\\\", \\\"{x:1346,y:959,t:1526930345521};\\\", \\\"{x:1345,y:958,t:1526930345614};\\\", \\\"{x:1345,y:957,t:1526930345622};\\\", \\\"{x:1343,y:957,t:1526930345646};\\\", \\\"{x:1343,y:956,t:1526930345654};\\\", \\\"{x:1342,y:953,t:1526930345669};\\\", \\\"{x:1341,y:950,t:1526930345686};\\\", \\\"{x:1341,y:944,t:1526930345703};\\\", \\\"{x:1341,y:941,t:1526930345721};\\\", \\\"{x:1341,y:937,t:1526930345736};\\\", \\\"{x:1342,y:935,t:1526930345806};\\\", \\\"{x:1344,y:933,t:1526930345822};\\\", \\\"{x:1344,y:932,t:1526930345837};\\\", \\\"{x:1347,y:927,t:1526930345852};\\\", \\\"{x:1348,y:922,t:1526930345869};\\\", \\\"{x:1349,y:919,t:1526930345886};\\\", \\\"{x:1355,y:907,t:1526930345902};\\\", \\\"{x:1361,y:896,t:1526930345920};\\\", \\\"{x:1365,y:889,t:1526930345936};\\\", \\\"{x:1367,y:886,t:1526930345952};\\\", \\\"{x:1368,y:885,t:1526930345968};\\\", \\\"{x:1369,y:884,t:1526930345985};\\\", \\\"{x:1371,y:884,t:1526930346005};\\\", \\\"{x:1372,y:884,t:1526930346018};\\\", \\\"{x:1373,y:883,t:1526930346045};\\\", \\\"{x:1376,y:881,t:1526930346093};\\\", \\\"{x:1379,y:877,t:1526930346110};\\\", \\\"{x:1380,y:875,t:1526930346120};\\\", \\\"{x:1384,y:870,t:1526930346136};\\\", \\\"{x:1387,y:864,t:1526930346153};\\\", \\\"{x:1390,y:860,t:1526930346169};\\\", \\\"{x:1396,y:854,t:1526930346185};\\\", \\\"{x:1401,y:847,t:1526930346203};\\\", \\\"{x:1413,y:829,t:1526930346219};\\\", \\\"{x:1426,y:813,t:1526930346236};\\\", \\\"{x:1444,y:781,t:1526930346254};\\\", \\\"{x:1452,y:768,t:1526930346269};\\\", \\\"{x:1486,y:696,t:1526930346286};\\\", \\\"{x:1508,y:642,t:1526930346304};\\\", \\\"{x:1530,y:584,t:1526930346321};\\\", \\\"{x:1548,y:540,t:1526930346336};\\\", \\\"{x:1564,y:502,t:1526930346353};\\\", \\\"{x:1573,y:476,t:1526930346369};\\\", \\\"{x:1580,y:454,t:1526930346386};\\\", \\\"{x:1589,y:435,t:1526930346403};\\\", \\\"{x:1591,y:430,t:1526930346419};\\\", \\\"{x:1592,y:428,t:1526930346436};\\\", \\\"{x:1593,y:429,t:1526930346574};\\\", \\\"{x:1592,y:435,t:1526930346586};\\\", \\\"{x:1592,y:446,t:1526930346603};\\\", \\\"{x:1590,y:458,t:1526930346621};\\\", \\\"{x:1587,y:471,t:1526930346636};\\\", \\\"{x:1583,y:504,t:1526930346654};\\\", \\\"{x:1577,y:530,t:1526930346669};\\\", \\\"{x:1563,y:567,t:1526930346686};\\\", \\\"{x:1534,y:621,t:1526930346704};\\\", \\\"{x:1501,y:668,t:1526930346721};\\\", \\\"{x:1463,y:711,t:1526930346736};\\\", \\\"{x:1408,y:746,t:1526930346753};\\\", \\\"{x:1340,y:771,t:1526930346770};\\\", \\\"{x:1248,y:786,t:1526930346786};\\\", \\\"{x:1128,y:790,t:1526930346804};\\\", \\\"{x:990,y:790,t:1526930346820};\\\", \\\"{x:841,y:778,t:1526930346837};\\\", \\\"{x:675,y:756,t:1526930346853};\\\", \\\"{x:441,y:741,t:1526930346870};\\\", \\\"{x:303,y:741,t:1526930346887};\\\", \\\"{x:170,y:741,t:1526930346903};\\\", \\\"{x:73,y:741,t:1526930346920};\\\", \\\"{x:0,y:741,t:1526930346938};\\\", \\\"{x:0,y:747,t:1526930346953};\\\", \\\"{x:0,y:750,t:1526930346970};\\\", \\\"{x:0,y:751,t:1526930346988};\\\", \\\"{x:0,y:748,t:1526930347038};\\\", \\\"{x:7,y:740,t:1526930347053};\\\", \\\"{x:30,y:730,t:1526930347070};\\\", \\\"{x:56,y:720,t:1526930347087};\\\", \\\"{x:89,y:718,t:1526930347103};\\\", \\\"{x:140,y:718,t:1526930347121};\\\", \\\"{x:183,y:726,t:1526930347137};\\\", \\\"{x:225,y:738,t:1526930347153};\\\", \\\"{x:272,y:750,t:1526930347170};\\\", \\\"{x:308,y:759,t:1526930347187};\\\", \\\"{x:334,y:764,t:1526930347203};\\\", \\\"{x:350,y:766,t:1526930347220};\\\", \\\"{x:358,y:768,t:1526930347238};\\\", \\\"{x:359,y:767,t:1526930347342};\\\", \\\"{x:361,y:766,t:1526930347354};\\\", \\\"{x:365,y:761,t:1526930347370};\\\", \\\"{x:371,y:755,t:1526930347387};\\\", \\\"{x:383,y:745,t:1526930347404};\\\", \\\"{x:402,y:734,t:1526930347420};\\\", \\\"{x:422,y:728,t:1526930347437};\\\", \\\"{x:435,y:724,t:1526930347454};\\\", \\\"{x:444,y:721,t:1526930347470};\\\", \\\"{x:448,y:720,t:1526930347487};\\\", \\\"{x:451,y:719,t:1526930347504};\\\", \\\"{x:456,y:719,t:1526930347520};\\\", \\\"{x:457,y:719,t:1526930347537};\\\", \\\"{x:460,y:720,t:1526930347555};\\\", \\\"{x:469,y:726,t:1526930347570};\\\", \\\"{x:478,y:734,t:1526930347587};\\\", \\\"{x:484,y:738,t:1526930347603};\\\", \\\"{x:490,y:744,t:1526930347620};\\\", \\\"{x:493,y:747,t:1526930347636};\\\" ] }, { \\\"rt\\\": 16906, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 16, \\\"time_elapsed\\\": 727924, \\\"internal_node_id\\\": \\\"0.0-6.0-6.0\\\", \\\"subject\\\": \\\"WKBNA\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 12, \\\"clicks\\\": 1.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F -B -F \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:495,y:746,t:1526930350758};\\\", \\\"{x:505,y:734,t:1526930350772};\\\", \\\"{x:516,y:722,t:1526930350780};\\\", \\\"{x:533,y:706,t:1526930350793};\\\", \\\"{x:552,y:694,t:1526930350810};\\\", \\\"{x:570,y:685,t:1526930350823};\\\", \\\"{x:586,y:679,t:1526930350839};\\\", \\\"{x:606,y:673,t:1526930350855};\\\", \\\"{x:627,y:668,t:1526930350873};\\\", \\\"{x:649,y:667,t:1526930350890};\\\", \\\"{x:678,y:667,t:1526930350906};\\\", \\\"{x:710,y:667,t:1526930350923};\\\", \\\"{x:737,y:667,t:1526930350940};\\\", \\\"{x:774,y:667,t:1526930350957};\\\", \\\"{x:796,y:663,t:1526930350973};\\\", \\\"{x:813,y:658,t:1526930350990};\\\", \\\"{x:836,y:655,t:1526930351007};\\\", \\\"{x:849,y:650,t:1526930351023};\\\", \\\"{x:874,y:645,t:1526930351040};\\\", \\\"{x:897,y:645,t:1526930351057};\\\", \\\"{x:917,y:645,t:1526930351073};\\\", \\\"{x:942,y:646,t:1526930351090};\\\", \\\"{x:965,y:653,t:1526930351107};\\\", \\\"{x:988,y:660,t:1526930351124};\\\", \\\"{x:1011,y:666,t:1526930351143};\\\", \\\"{x:1050,y:677,t:1526930351157};\\\", \\\"{x:1081,y:683,t:1526930351173};\\\", \\\"{x:1111,y:686,t:1526930351190};\\\", \\\"{x:1145,y:686,t:1526930351207};\\\", \\\"{x:1169,y:686,t:1526930351223};\\\", \\\"{x:1193,y:686,t:1526930351239};\\\", \\\"{x:1215,y:686,t:1526930351257};\\\", \\\"{x:1241,y:684,t:1526930351273};\\\", \\\"{x:1267,y:681,t:1526930351290};\\\", \\\"{x:1295,y:680,t:1526930351306};\\\", \\\"{x:1325,y:680,t:1526930351323};\\\", \\\"{x:1355,y:680,t:1526930351340};\\\", \\\"{x:1395,y:683,t:1526930351356};\\\", \\\"{x:1413,y:687,t:1526930351372};\\\", \\\"{x:1426,y:688,t:1526930351390};\\\", \\\"{x:1431,y:688,t:1526930351407};\\\", \\\"{x:1433,y:688,t:1526930351424};\\\", \\\"{x:1433,y:693,t:1526930351590};\\\", \\\"{x:1419,y:702,t:1526930351607};\\\", \\\"{x:1400,y:709,t:1526930351625};\\\", \\\"{x:1379,y:713,t:1526930351641};\\\", \\\"{x:1364,y:713,t:1526930351658};\\\", \\\"{x:1357,y:713,t:1526930351674};\\\", \\\"{x:1353,y:713,t:1526930351690};\\\", \\\"{x:1352,y:712,t:1526930351910};\\\", \\\"{x:1350,y:712,t:1526930351924};\\\", \\\"{x:1348,y:711,t:1526930351942};\\\", \\\"{x:1347,y:710,t:1526930351965};\\\", \\\"{x:1347,y:708,t:1526930352094};\\\", \\\"{x:1347,y:706,t:1526930352108};\\\", \\\"{x:1348,y:701,t:1526930352127};\\\", \\\"{x:1348,y:699,t:1526930352142};\\\", \\\"{x:1348,y:696,t:1526930352157};\\\", \\\"{x:1349,y:695,t:1526930352237};\\\", \\\"{x:1349,y:696,t:1526930353342};\\\", \\\"{x:1349,y:698,t:1526930353358};\\\", \\\"{x:1349,y:699,t:1526930353375};\\\", \\\"{x:1349,y:700,t:1526930353392};\\\", \\\"{x:1349,y:701,t:1526930353574};\\\", \\\"{x:1349,y:702,t:1526930353589};\\\", \\\"{x:1349,y:704,t:1526930353632};\\\", \\\"{x:1349,y:706,t:1526930353646};\\\", \\\"{x:1350,y:709,t:1526930353660};\\\", \\\"{x:1353,y:715,t:1526930353676};\\\", \\\"{x:1353,y:719,t:1526930353692};\\\", \\\"{x:1353,y:723,t:1526930353710};\\\", \\\"{x:1353,y:727,t:1526930353725};\\\", \\\"{x:1352,y:733,t:1526930353743};\\\", \\\"{x:1349,y:739,t:1526930353760};\\\", \\\"{x:1348,y:743,t:1526930353775};\\\", \\\"{x:1346,y:747,t:1526930353793};\\\", \\\"{x:1343,y:751,t:1526930353809};\\\", \\\"{x:1341,y:754,t:1526930353826};\\\", \\\"{x:1338,y:758,t:1526930353843};\\\", \\\"{x:1336,y:760,t:1526930353859};\\\", \\\"{x:1333,y:761,t:1526930353876};\\\", \\\"{x:1331,y:762,t:1526930353893};\\\", \\\"{x:1323,y:765,t:1526930353909};\\\", \\\"{x:1316,y:766,t:1526930353926};\\\", \\\"{x:1310,y:768,t:1526930353943};\\\", \\\"{x:1307,y:769,t:1526930353959};\\\", \\\"{x:1299,y:774,t:1526930353975};\\\", \\\"{x:1294,y:780,t:1526930353992};\\\", \\\"{x:1290,y:785,t:1526930354009};\\\", \\\"{x:1287,y:791,t:1526930354026};\\\", \\\"{x:1284,y:796,t:1526930354042};\\\", \\\"{x:1283,y:798,t:1526930354060};\\\", \\\"{x:1283,y:799,t:1526930354077};\\\", \\\"{x:1283,y:798,t:1526930354134};\\\", \\\"{x:1283,y:797,t:1526930354150};\\\", \\\"{x:1283,y:795,t:1526930354165};\\\", \\\"{x:1283,y:794,t:1526930354189};\\\", \\\"{x:1283,y:793,t:1526930354198};\\\", \\\"{x:1285,y:791,t:1526930354221};\\\", \\\"{x:1287,y:790,t:1526930354238};\\\", \\\"{x:1289,y:789,t:1526930354245};\\\", \\\"{x:1291,y:789,t:1526930354261};\\\", \\\"{x:1291,y:788,t:1526930354276};\\\", \\\"{x:1294,y:785,t:1526930354292};\\\", \\\"{x:1299,y:779,t:1526930354310};\\\", \\\"{x:1300,y:776,t:1526930354326};\\\", \\\"{x:1302,y:770,t:1526930354343};\\\", \\\"{x:1305,y:766,t:1526930354360};\\\", \\\"{x:1307,y:760,t:1526930354376};\\\", \\\"{x:1310,y:757,t:1526930354392};\\\", \\\"{x:1311,y:755,t:1526930354410};\\\", \\\"{x:1313,y:752,t:1526930354427};\\\", \\\"{x:1315,y:748,t:1526930354442};\\\", \\\"{x:1317,y:744,t:1526930354460};\\\", \\\"{x:1319,y:742,t:1526930354477};\\\", \\\"{x:1322,y:733,t:1526930354493};\\\", \\\"{x:1325,y:727,t:1526930354510};\\\", \\\"{x:1328,y:719,t:1526930354527};\\\", \\\"{x:1331,y:710,t:1526930354544};\\\", \\\"{x:1333,y:703,t:1526930354560};\\\", \\\"{x:1336,y:698,t:1526930354577};\\\", \\\"{x:1337,y:696,t:1526930354594};\\\", \\\"{x:1339,y:693,t:1526930354610};\\\", \\\"{x:1339,y:692,t:1526930354626};\\\", \\\"{x:1340,y:691,t:1526930354643};\\\", \\\"{x:1340,y:690,t:1526930354661};\\\", \\\"{x:1342,y:687,t:1526930354677};\\\", \\\"{x:1344,y:684,t:1526930354694};\\\", \\\"{x:1348,y:679,t:1526930354709};\\\", \\\"{x:1351,y:673,t:1526930354727};\\\", \\\"{x:1355,y:665,t:1526930354743};\\\", \\\"{x:1361,y:655,t:1526930354760};\\\", \\\"{x:1363,y:649,t:1526930354777};\\\", \\\"{x:1366,y:643,t:1526930354794};\\\", \\\"{x:1367,y:642,t:1526930354809};\\\", \\\"{x:1368,y:642,t:1526930354826};\\\", \\\"{x:1368,y:641,t:1526930354862};\\\", \\\"{x:1368,y:640,t:1526930354876};\\\", \\\"{x:1370,y:637,t:1526930354894};\\\", \\\"{x:1371,y:635,t:1526930354909};\\\", \\\"{x:1372,y:633,t:1526930354926};\\\", \\\"{x:1373,y:630,t:1526930354943};\\\", \\\"{x:1374,y:628,t:1526930354961};\\\", \\\"{x:1376,y:624,t:1526930354976};\\\", \\\"{x:1376,y:622,t:1526930354994};\\\", \\\"{x:1377,y:620,t:1526930355010};\\\", \\\"{x:1372,y:620,t:1526930355198};\\\", \\\"{x:1364,y:620,t:1526930355210};\\\", \\\"{x:1340,y:620,t:1526930355227};\\\", \\\"{x:1302,y:618,t:1526930355243};\\\", \\\"{x:1240,y:610,t:1526930355260};\\\", \\\"{x:1135,y:592,t:1526930355277};\\\", \\\"{x:967,y:569,t:1526930355294};\\\", \\\"{x:850,y:549,t:1526930355312};\\\", \\\"{x:751,y:537,t:1526930355327};\\\", \\\"{x:688,y:532,t:1526930355344};\\\", \\\"{x:658,y:529,t:1526930355360};\\\", \\\"{x:647,y:527,t:1526930355377};\\\", \\\"{x:644,y:527,t:1526930355393};\\\", \\\"{x:643,y:527,t:1526930355410};\\\", \\\"{x:642,y:527,t:1526930355460};\\\", \\\"{x:640,y:527,t:1526930355477};\\\", \\\"{x:639,y:530,t:1526930355493};\\\", \\\"{x:636,y:535,t:1526930355510};\\\", \\\"{x:635,y:540,t:1526930355527};\\\", \\\"{x:632,y:545,t:1526930355544};\\\", \\\"{x:629,y:550,t:1526930355560};\\\", \\\"{x:626,y:553,t:1526930355578};\\\", \\\"{x:623,y:554,t:1526930355594};\\\", \\\"{x:620,y:554,t:1526930355610};\\\", \\\"{x:617,y:554,t:1526930355627};\\\", \\\"{x:615,y:554,t:1526930355644};\\\", \\\"{x:602,y:548,t:1526930355661};\\\", \\\"{x:587,y:542,t:1526930355676};\\\", \\\"{x:586,y:541,t:1526930355694};\\\", \\\"{x:590,y:541,t:1526930355764};\\\", \\\"{x:600,y:541,t:1526930355777};\\\", \\\"{x:624,y:541,t:1526930355794};\\\", \\\"{x:652,y:538,t:1526930355810};\\\", \\\"{x:695,y:535,t:1526930355827};\\\", \\\"{x:736,y:526,t:1526930355845};\\\", \\\"{x:774,y:518,t:1526930355861};\\\", \\\"{x:811,y:511,t:1526930355877};\\\", \\\"{x:828,y:511,t:1526930355894};\\\", \\\"{x:835,y:511,t:1526930355910};\\\", \\\"{x:837,y:511,t:1526930355927};\\\", \\\"{x:838,y:511,t:1526930355956};\\\", \\\"{x:838,y:513,t:1526930355965};\\\", \\\"{x:836,y:515,t:1526930355977};\\\", \\\"{x:832,y:520,t:1526930355994};\\\", \\\"{x:830,y:526,t:1526930356011};\\\", \\\"{x:827,y:531,t:1526930356027};\\\", \\\"{x:826,y:534,t:1526930356044};\\\", \\\"{x:826,y:535,t:1526930356076};\\\", \\\"{x:825,y:536,t:1526930356093};\\\", \\\"{x:825,y:537,t:1526930356117};\\\", \\\"{x:825,y:538,t:1526930356127};\\\", \\\"{x:824,y:539,t:1526930356144};\\\", \\\"{x:824,y:540,t:1526930356161};\\\", \\\"{x:823,y:542,t:1526930356177};\\\", \\\"{x:824,y:543,t:1526930356567};\\\", \\\"{x:825,y:543,t:1526930356581};\\\", \\\"{x:830,y:543,t:1526930356594};\\\", \\\"{x:833,y:543,t:1526930356612};\\\", \\\"{x:842,y:546,t:1526930356628};\\\", \\\"{x:855,y:551,t:1526930356645};\\\", \\\"{x:871,y:556,t:1526930356662};\\\", \\\"{x:881,y:556,t:1526930356678};\\\", \\\"{x:895,y:558,t:1526930356694};\\\", \\\"{x:906,y:558,t:1526930356710};\\\", \\\"{x:920,y:558,t:1526930356728};\\\", \\\"{x:936,y:558,t:1526930356745};\\\", \\\"{x:954,y:561,t:1526930356761};\\\", \\\"{x:975,y:567,t:1526930356778};\\\", \\\"{x:998,y:574,t:1526930356795};\\\", \\\"{x:1026,y:584,t:1526930356811};\\\", \\\"{x:1066,y:600,t:1526930356829};\\\", \\\"{x:1105,y:614,t:1526930356844};\\\", \\\"{x:1128,y:623,t:1526930356861};\\\", \\\"{x:1154,y:630,t:1526930356878};\\\", \\\"{x:1178,y:633,t:1526930356895};\\\", \\\"{x:1198,y:635,t:1526930356911};\\\", \\\"{x:1215,y:635,t:1526930356928};\\\", \\\"{x:1226,y:635,t:1526930356945};\\\", \\\"{x:1234,y:635,t:1526930356961};\\\", \\\"{x:1240,y:635,t:1526930356979};\\\", \\\"{x:1243,y:635,t:1526930356996};\\\", \\\"{x:1244,y:636,t:1526930357011};\\\", \\\"{x:1246,y:638,t:1526930357029};\\\", \\\"{x:1251,y:641,t:1526930357045};\\\", \\\"{x:1255,y:646,t:1526930357061};\\\", \\\"{x:1257,y:648,t:1526930357079};\\\", \\\"{x:1258,y:651,t:1526930357095};\\\", \\\"{x:1259,y:652,t:1526930357112};\\\", \\\"{x:1259,y:654,t:1526930357129};\\\", \\\"{x:1259,y:655,t:1526930357146};\\\", \\\"{x:1258,y:657,t:1526930357162};\\\", \\\"{x:1248,y:664,t:1526930357179};\\\", \\\"{x:1231,y:675,t:1526930357196};\\\", \\\"{x:1201,y:692,t:1526930357211};\\\", \\\"{x:1154,y:713,t:1526930357228};\\\", \\\"{x:1067,y:750,t:1526930357245};\\\", \\\"{x:995,y:770,t:1526930357262};\\\", \\\"{x:912,y:792,t:1526930357278};\\\", \\\"{x:830,y:807,t:1526930357295};\\\", \\\"{x:747,y:818,t:1526930357312};\\\", \\\"{x:656,y:826,t:1526930357328};\\\", \\\"{x:568,y:826,t:1526930357345};\\\", \\\"{x:498,y:826,t:1526930357363};\\\", \\\"{x:448,y:826,t:1526930357378};\\\", \\\"{x:415,y:824,t:1526930357396};\\\", \\\"{x:389,y:820,t:1526930357413};\\\", \\\"{x:372,y:819,t:1526930357428};\\\", \\\"{x:351,y:817,t:1526930357445};\\\", \\\"{x:347,y:817,t:1526930357462};\\\", \\\"{x:345,y:817,t:1526930357478};\\\", \\\"{x:344,y:811,t:1526930357565};\\\", \\\"{x:344,y:807,t:1526930357578};\\\", \\\"{x:351,y:789,t:1526930357596};\\\", \\\"{x:363,y:770,t:1526930357612};\\\", \\\"{x:388,y:749,t:1526930357628};\\\", \\\"{x:407,y:739,t:1526930357645};\\\", \\\"{x:428,y:732,t:1526930357662};\\\", \\\"{x:455,y:723,t:1526930357678};\\\", \\\"{x:481,y:713,t:1526930357695};\\\", \\\"{x:506,y:703,t:1526930357711};\\\", \\\"{x:528,y:687,t:1526930357728};\\\", \\\"{x:547,y:671,t:1526930357745};\\\", \\\"{x:560,y:657,t:1526930357762};\\\", \\\"{x:572,y:642,t:1526930357779};\\\", \\\"{x:582,y:628,t:1526930357797};\\\", \\\"{x:591,y:614,t:1526930357812};\\\", \\\"{x:597,y:606,t:1526930357828};\\\", \\\"{x:600,y:600,t:1526930357845};\\\", \\\"{x:603,y:595,t:1526930357862};\\\", \\\"{x:603,y:594,t:1526930357878};\\\", \\\"{x:604,y:594,t:1526930357973};\\\", \\\"{x:604,y:592,t:1526930357982};\\\", \\\"{x:604,y:590,t:1526930357995};\\\", \\\"{x:605,y:583,t:1526930358012};\\\", \\\"{x:609,y:574,t:1526930358028};\\\", \\\"{x:611,y:570,t:1526930358045};\\\", \\\"{x:615,y:567,t:1526930358065};\\\", \\\"{x:623,y:563,t:1526930358081};\\\", \\\"{x:642,y:559,t:1526930358099};\\\", \\\"{x:670,y:558,t:1526930358114};\\\", \\\"{x:705,y:558,t:1526930358132};\\\", \\\"{x:735,y:558,t:1526930358149};\\\", \\\"{x:767,y:558,t:1526930358164};\\\", \\\"{x:807,y:560,t:1526930358181};\\\", \\\"{x:839,y:560,t:1526930358198};\\\", \\\"{x:855,y:560,t:1526930358215};\\\", \\\"{x:859,y:559,t:1526930358232};\\\", \\\"{x:860,y:558,t:1526930358249};\\\", \\\"{x:860,y:554,t:1526930358265};\\\", \\\"{x:860,y:552,t:1526930358282};\\\", \\\"{x:860,y:551,t:1526930358299};\\\", \\\"{x:860,y:549,t:1526930358328};\\\", \\\"{x:858,y:547,t:1526930358344};\\\", \\\"{x:855,y:546,t:1526930358360};\\\", \\\"{x:854,y:545,t:1526930358432};\\\", \\\"{x:853,y:541,t:1526930358449};\\\", \\\"{x:851,y:538,t:1526930358465};\\\", \\\"{x:850,y:536,t:1526930358482};\\\", \\\"{x:849,y:533,t:1526930358500};\\\", \\\"{x:848,y:532,t:1526930358515};\\\", \\\"{x:847,y:531,t:1526930358536};\\\", \\\"{x:846,y:531,t:1526930358560};\\\", \\\"{x:844,y:531,t:1526930358585};\\\", \\\"{x:843,y:531,t:1526930358600};\\\", \\\"{x:842,y:531,t:1526930358616};\\\", \\\"{x:842,y:532,t:1526930358632};\\\", \\\"{x:841,y:532,t:1526930363712};\\\", \\\"{x:835,y:534,t:1526930363719};\\\", \\\"{x:818,y:535,t:1526930363737};\\\", \\\"{x:799,y:535,t:1526930363753};\\\", \\\"{x:780,y:536,t:1526930363769};\\\", \\\"{x:752,y:539,t:1526930363785};\\\", \\\"{x:732,y:539,t:1526930363802};\\\", \\\"{x:709,y:539,t:1526930363820};\\\", \\\"{x:696,y:539,t:1526930363835};\\\", \\\"{x:692,y:539,t:1526930363853};\\\", \\\"{x:687,y:541,t:1526930363870};\\\", \\\"{x:683,y:544,t:1526930363886};\\\", \\\"{x:678,y:547,t:1526930363903};\\\", \\\"{x:675,y:549,t:1526930363919};\\\", \\\"{x:673,y:550,t:1526930363936};\\\", \\\"{x:672,y:551,t:1526930364048};\\\", \\\"{x:670,y:552,t:1526930364056};\\\", \\\"{x:669,y:553,t:1526930364071};\\\", \\\"{x:667,y:555,t:1526930364087};\\\", \\\"{x:665,y:557,t:1526930364104};\\\", \\\"{x:662,y:561,t:1526930364120};\\\", \\\"{x:662,y:564,t:1526930364137};\\\", \\\"{x:661,y:565,t:1526930364154};\\\", \\\"{x:661,y:566,t:1526930364169};\\\", \\\"{x:660,y:567,t:1526930364186};\\\", \\\"{x:658,y:567,t:1526930364203};\\\", \\\"{x:655,y:568,t:1526930364220};\\\", \\\"{x:652,y:569,t:1526930364236};\\\", \\\"{x:648,y:572,t:1526930364253};\\\", \\\"{x:643,y:575,t:1526930364270};\\\", \\\"{x:630,y:584,t:1526930364288};\\\", \\\"{x:621,y:590,t:1526930364303};\\\", \\\"{x:607,y:602,t:1526930364321};\\\", \\\"{x:596,y:609,t:1526930364337};\\\", \\\"{x:582,y:616,t:1526930364354};\\\", \\\"{x:567,y:624,t:1526930364370};\\\", \\\"{x:556,y:630,t:1526930364387};\\\", \\\"{x:547,y:633,t:1526930364403};\\\", \\\"{x:541,y:636,t:1526930364420};\\\", \\\"{x:535,y:639,t:1526930364437};\\\", \\\"{x:532,y:641,t:1526930364454};\\\", \\\"{x:527,y:644,t:1526930364470};\\\", \\\"{x:524,y:648,t:1526930364486};\\\", \\\"{x:521,y:654,t:1526930364503};\\\", \\\"{x:517,y:662,t:1526930364520};\\\", \\\"{x:513,y:670,t:1526930364537};\\\", \\\"{x:510,y:680,t:1526930364554};\\\", \\\"{x:503,y:694,t:1526930364571};\\\", \\\"{x:500,y:704,t:1526930364587};\\\", \\\"{x:497,y:713,t:1526930364604};\\\", \\\"{x:496,y:721,t:1526930364621};\\\", \\\"{x:495,y:728,t:1526930364636};\\\", \\\"{x:494,y:731,t:1526930364654};\\\", \\\"{x:494,y:733,t:1526930364670};\\\", \\\"{x:493,y:736,t:1526930364687};\\\", \\\"{x:493,y:738,t:1526930364703};\\\", \\\"{x:493,y:741,t:1526930364720};\\\", \\\"{x:493,y:747,t:1526930364737};\\\", \\\"{x:493,y:751,t:1526930364754};\\\", \\\"{x:493,y:756,t:1526930364770};\\\", \\\"{x:493,y:757,t:1526930364786};\\\", \\\"{x:492,y:758,t:1526930364804};\\\", \\\"{x:492,y:759,t:1526930364888};\\\", \\\"{x:490,y:759,t:1526930364904};\\\", \\\"{x:489,y:759,t:1526930364928};\\\", \\\"{x:489,y:758,t:1526930365048};\\\", \\\"{x:489,y:757,t:1526930365064};\\\", \\\"{x:489,y:754,t:1526930365081};\\\", \\\"{x:488,y:753,t:1526930365087};\\\", \\\"{x:488,y:751,t:1526930365104};\\\", \\\"{x:488,y:748,t:1526930365121};\\\", \\\"{x:488,y:747,t:1526930365138};\\\", \\\"{x:488,y:746,t:1526930365154};\\\", \\\"{x:487,y:746,t:1526930365296};\\\", \\\"{x:487,y:745,t:1526930365305};\\\", \\\"{x:487,y:744,t:1526930365322};\\\", \\\"{x:487,y:743,t:1526930365339};\\\" ] }, { \\\"rt\\\": 24502, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 17, \\\"time_elapsed\\\": 753633, \\\"internal_node_id\\\": \\\"0.0-6.0-7.0\\\", \\\"subject\\\": \\\"WKBNA\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 13, \\\"clicks\\\": 2.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"E\\\", \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-Z -O -Z -Z -02 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:487,y:742,t:1526930368841};\\\", \\\"{x:487,y:741,t:1526930369488};\\\", \\\"{x:487,y:740,t:1526930369496};\\\", \\\"{x:487,y:738,t:1526930369696};\\\", \\\"{x:487,y:737,t:1526930369712};\\\", \\\"{x:487,y:736,t:1526930369725};\\\", \\\"{x:487,y:735,t:1526930369888};\\\", \\\"{x:487,y:734,t:1526930369896};\\\", \\\"{x:487,y:732,t:1526930369908};\\\", \\\"{x:487,y:729,t:1526930369925};\\\", \\\"{x:489,y:727,t:1526930369942};\\\", \\\"{x:490,y:726,t:1526930369958};\\\", \\\"{x:491,y:725,t:1526930369999};\\\", \\\"{x:493,y:724,t:1526930370015};\\\", \\\"{x:495,y:723,t:1526930370047};\\\", \\\"{x:498,y:721,t:1526930370058};\\\", \\\"{x:510,y:717,t:1526930370075};\\\", \\\"{x:521,y:709,t:1526930370091};\\\", \\\"{x:536,y:702,t:1526930370108};\\\", \\\"{x:558,y:690,t:1526930370125};\\\", \\\"{x:587,y:679,t:1526930370141};\\\", \\\"{x:616,y:670,t:1526930370158};\\\", \\\"{x:659,y:657,t:1526930370175};\\\", \\\"{x:688,y:654,t:1526930370192};\\\", \\\"{x:717,y:649,t:1526930370208};\\\", \\\"{x:748,y:649,t:1526930370225};\\\", \\\"{x:790,y:648,t:1526930370242};\\\", \\\"{x:834,y:648,t:1526930370259};\\\", \\\"{x:879,y:648,t:1526930370275};\\\", \\\"{x:930,y:648,t:1526930370292};\\\", \\\"{x:977,y:648,t:1526930370309};\\\", \\\"{x:1016,y:648,t:1526930370326};\\\", \\\"{x:1056,y:648,t:1526930370343};\\\", \\\"{x:1095,y:648,t:1526930370358};\\\", \\\"{x:1157,y:648,t:1526930370375};\\\", \\\"{x:1191,y:648,t:1526930370392};\\\", \\\"{x:1223,y:652,t:1526930370409};\\\", \\\"{x:1256,y:662,t:1526930370426};\\\", \\\"{x:1292,y:670,t:1526930370442};\\\", \\\"{x:1329,y:683,t:1526930370459};\\\", \\\"{x:1372,y:698,t:1526930370476};\\\", \\\"{x:1400,y:710,t:1526930370493};\\\", \\\"{x:1425,y:716,t:1526930370508};\\\", \\\"{x:1453,y:723,t:1526930370526};\\\", \\\"{x:1473,y:728,t:1526930370543};\\\", \\\"{x:1496,y:729,t:1526930370559};\\\", \\\"{x:1500,y:729,t:1526930370576};\\\", \\\"{x:1502,y:729,t:1526930370593};\\\", \\\"{x:1504,y:731,t:1526930370696};\\\", \\\"{x:1505,y:731,t:1526930370710};\\\", \\\"{x:1506,y:733,t:1526930370726};\\\", \\\"{x:1507,y:734,t:1526930370743};\\\", \\\"{x:1508,y:735,t:1526930370897};\\\", \\\"{x:1508,y:736,t:1526930370910};\\\", \\\"{x:1508,y:740,t:1526930370927};\\\", \\\"{x:1508,y:745,t:1526930370943};\\\", \\\"{x:1508,y:753,t:1526930370960};\\\", \\\"{x:1505,y:759,t:1526930370976};\\\", \\\"{x:1503,y:763,t:1526930370994};\\\", \\\"{x:1501,y:766,t:1526930371011};\\\", \\\"{x:1499,y:768,t:1526930371027};\\\", \\\"{x:1497,y:771,t:1526930371043};\\\", \\\"{x:1494,y:775,t:1526930371060};\\\", \\\"{x:1490,y:781,t:1526930371077};\\\", \\\"{x:1486,y:788,t:1526930371093};\\\", \\\"{x:1482,y:794,t:1526930371110};\\\", \\\"{x:1479,y:801,t:1526930371127};\\\", \\\"{x:1477,y:804,t:1526930371143};\\\", \\\"{x:1475,y:807,t:1526930371160};\\\", \\\"{x:1474,y:808,t:1526930371177};\\\", \\\"{x:1474,y:809,t:1526930371200};\\\", \\\"{x:1474,y:807,t:1526930371448};\\\", \\\"{x:1473,y:804,t:1526930371460};\\\", \\\"{x:1473,y:795,t:1526930371477};\\\", \\\"{x:1471,y:785,t:1526930371494};\\\", \\\"{x:1471,y:771,t:1526930371510};\\\", \\\"{x:1471,y:759,t:1526930371527};\\\", \\\"{x:1471,y:747,t:1526930371544};\\\", \\\"{x:1471,y:743,t:1526930371560};\\\", \\\"{x:1471,y:737,t:1526930371577};\\\", \\\"{x:1471,y:732,t:1526930371594};\\\", \\\"{x:1471,y:724,t:1526930371611};\\\", \\\"{x:1471,y:715,t:1526930371627};\\\", \\\"{x:1471,y:703,t:1526930371644};\\\", \\\"{x:1471,y:693,t:1526930371661};\\\", \\\"{x:1470,y:684,t:1526930371677};\\\", \\\"{x:1469,y:677,t:1526930371694};\\\", \\\"{x:1468,y:669,t:1526930371711};\\\", \\\"{x:1467,y:666,t:1526930371727};\\\", \\\"{x:1466,y:664,t:1526930371744};\\\", \\\"{x:1466,y:662,t:1526930371880};\\\", \\\"{x:1466,y:660,t:1526930371894};\\\", \\\"{x:1466,y:658,t:1526930371911};\\\", \\\"{x:1466,y:654,t:1526930371927};\\\", \\\"{x:1466,y:652,t:1526930371944};\\\", \\\"{x:1466,y:651,t:1526930371968};\\\", \\\"{x:1467,y:651,t:1526930372264};\\\", \\\"{x:1468,y:651,t:1526930372280};\\\", \\\"{x:1469,y:651,t:1526930372304};\\\", \\\"{x:1470,y:651,t:1526930372320};\\\", \\\"{x:1472,y:650,t:1526930372344};\\\", \\\"{x:1473,y:650,t:1526930372368};\\\", \\\"{x:1474,y:650,t:1526930372400};\\\", \\\"{x:1475,y:650,t:1526930372520};\\\", \\\"{x:1476,y:649,t:1526930372528};\\\", \\\"{x:1477,y:648,t:1526930372568};\\\", \\\"{x:1478,y:647,t:1526930372578};\\\", \\\"{x:1480,y:644,t:1526930372595};\\\", \\\"{x:1483,y:643,t:1526930372611};\\\", \\\"{x:1483,y:642,t:1526930372628};\\\", \\\"{x:1484,y:641,t:1526930372645};\\\", \\\"{x:1486,y:640,t:1526930372735};\\\", \\\"{x:1488,y:640,t:1526930372744};\\\", \\\"{x:1498,y:637,t:1526930372761};\\\", \\\"{x:1513,y:636,t:1526930372778};\\\", \\\"{x:1534,y:636,t:1526930372794};\\\", \\\"{x:1561,y:640,t:1526930372811};\\\", \\\"{x:1618,y:662,t:1526930372827};\\\", \\\"{x:1671,y:678,t:1526930372844};\\\", \\\"{x:1704,y:691,t:1526930372861};\\\", \\\"{x:1724,y:696,t:1526930372877};\\\", \\\"{x:1736,y:699,t:1526930372894};\\\", \\\"{x:1737,y:699,t:1526930372911};\\\", \\\"{x:1737,y:701,t:1526930373015};\\\", \\\"{x:1736,y:702,t:1526930373027};\\\", \\\"{x:1724,y:707,t:1526930373044};\\\", \\\"{x:1707,y:711,t:1526930373062};\\\", \\\"{x:1684,y:712,t:1526930373078};\\\", \\\"{x:1658,y:712,t:1526930373095};\\\", \\\"{x:1631,y:713,t:1526930373111};\\\", \\\"{x:1627,y:713,t:1526930373130};\\\", \\\"{x:1626,y:713,t:1526930373224};\\\", \\\"{x:1626,y:712,t:1526930373256};\\\", \\\"{x:1626,y:711,t:1526930373264};\\\", \\\"{x:1627,y:709,t:1526930373278};\\\", \\\"{x:1628,y:708,t:1526930373304};\\\", \\\"{x:1628,y:707,t:1526930373336};\\\", \\\"{x:1628,y:706,t:1526930373345};\\\", \\\"{x:1628,y:704,t:1526930373362};\\\", \\\"{x:1626,y:702,t:1526930373379};\\\", \\\"{x:1620,y:698,t:1526930373399};\\\", \\\"{x:1618,y:697,t:1526930373412};\\\", \\\"{x:1616,y:696,t:1526930373429};\\\", \\\"{x:1615,y:696,t:1526930373445};\\\", \\\"{x:1614,y:696,t:1526930373735};\\\", \\\"{x:1613,y:696,t:1526930373745};\\\", \\\"{x:1612,y:696,t:1526930373761};\\\", \\\"{x:1609,y:697,t:1526930373779};\\\", \\\"{x:1609,y:698,t:1526930373795};\\\", \\\"{x:1608,y:698,t:1526930373813};\\\", \\\"{x:1607,y:698,t:1526930374096};\\\", \\\"{x:1608,y:698,t:1526930374368};\\\", \\\"{x:1608,y:700,t:1526930374383};\\\", \\\"{x:1608,y:701,t:1526930374397};\\\", \\\"{x:1608,y:702,t:1526930374413};\\\", \\\"{x:1608,y:703,t:1526930374431};\\\", \\\"{x:1608,y:704,t:1526930374568};\\\", \\\"{x:1608,y:705,t:1526930374583};\\\", \\\"{x:1608,y:706,t:1526930374600};\\\", \\\"{x:1608,y:707,t:1526930374613};\\\", \\\"{x:1609,y:707,t:1526930374952};\\\", \\\"{x:1608,y:707,t:1526930375273};\\\", \\\"{x:1607,y:708,t:1526930375480};\\\", \\\"{x:1606,y:709,t:1526930375497};\\\", \\\"{x:1605,y:710,t:1526930375553};\\\", \\\"{x:1605,y:711,t:1526930375656};\\\", \\\"{x:1605,y:713,t:1526930375672};\\\", \\\"{x:1605,y:715,t:1526930375682};\\\", \\\"{x:1604,y:719,t:1526930375698};\\\", \\\"{x:1603,y:721,t:1526930375714};\\\", \\\"{x:1603,y:723,t:1526930375732};\\\", \\\"{x:1602,y:725,t:1526930375748};\\\", \\\"{x:1600,y:727,t:1526930375808};\\\", \\\"{x:1600,y:728,t:1526930375824};\\\", \\\"{x:1599,y:730,t:1526930375840};\\\", \\\"{x:1598,y:732,t:1526930375848};\\\", \\\"{x:1594,y:738,t:1526930375864};\\\", \\\"{x:1590,y:744,t:1526930375881};\\\", \\\"{x:1586,y:751,t:1526930375898};\\\", \\\"{x:1583,y:755,t:1526930375915};\\\", \\\"{x:1579,y:761,t:1526930375931};\\\", \\\"{x:1575,y:767,t:1526930375948};\\\", \\\"{x:1572,y:772,t:1526930375965};\\\", \\\"{x:1569,y:776,t:1526930375982};\\\", \\\"{x:1567,y:778,t:1526930375998};\\\", \\\"{x:1565,y:780,t:1526930376015};\\\", \\\"{x:1560,y:785,t:1526930376032};\\\", \\\"{x:1557,y:793,t:1526930376048};\\\", \\\"{x:1551,y:803,t:1526930376065};\\\", \\\"{x:1544,y:820,t:1526930376081};\\\", \\\"{x:1535,y:836,t:1526930376098};\\\", \\\"{x:1527,y:855,t:1526930376115};\\\", \\\"{x:1518,y:876,t:1526930376131};\\\", \\\"{x:1507,y:896,t:1526930376148};\\\", \\\"{x:1497,y:912,t:1526930376166};\\\", \\\"{x:1488,y:929,t:1526930376181};\\\", \\\"{x:1480,y:940,t:1526930376198};\\\", \\\"{x:1474,y:947,t:1526930376215};\\\", \\\"{x:1469,y:952,t:1526930376232};\\\", \\\"{x:1469,y:953,t:1526930376248};\\\", \\\"{x:1469,y:954,t:1526930376287};\\\", \\\"{x:1469,y:955,t:1526930376304};\\\", \\\"{x:1469,y:956,t:1526930376320};\\\", \\\"{x:1469,y:957,t:1526930376332};\\\", \\\"{x:1469,y:959,t:1526930376349};\\\", \\\"{x:1469,y:961,t:1526930376376};\\\", \\\"{x:1469,y:962,t:1526930376513};\\\", \\\"{x:1470,y:962,t:1526930376520};\\\", \\\"{x:1471,y:962,t:1526930376536};\\\", \\\"{x:1472,y:962,t:1526930376560};\\\", \\\"{x:1472,y:959,t:1526930376776};\\\", \\\"{x:1471,y:958,t:1526930376784};\\\", \\\"{x:1470,y:957,t:1526930376799};\\\", \\\"{x:1468,y:955,t:1526930376815};\\\", \\\"{x:1465,y:951,t:1526930376832};\\\", \\\"{x:1462,y:945,t:1526930376849};\\\", \\\"{x:1458,y:938,t:1526930376866};\\\", \\\"{x:1452,y:930,t:1526930376882};\\\", \\\"{x:1446,y:923,t:1526930376899};\\\", \\\"{x:1443,y:918,t:1526930376916};\\\", \\\"{x:1439,y:914,t:1526930376932};\\\", \\\"{x:1437,y:911,t:1526930376949};\\\", \\\"{x:1436,y:910,t:1526930376965};\\\", \\\"{x:1436,y:909,t:1526930376984};\\\", \\\"{x:1436,y:908,t:1526930376999};\\\", \\\"{x:1434,y:904,t:1526930377016};\\\", \\\"{x:1432,y:899,t:1526930377032};\\\", \\\"{x:1430,y:895,t:1526930377049};\\\", \\\"{x:1426,y:886,t:1526930377066};\\\", \\\"{x:1420,y:874,t:1526930377082};\\\", \\\"{x:1414,y:860,t:1526930377099};\\\", \\\"{x:1407,y:849,t:1526930377117};\\\", \\\"{x:1403,y:841,t:1526930377132};\\\", \\\"{x:1399,y:834,t:1526930377149};\\\", \\\"{x:1397,y:831,t:1526930377166};\\\", \\\"{x:1395,y:826,t:1526930377182};\\\", \\\"{x:1391,y:813,t:1526930377200};\\\", \\\"{x:1388,y:804,t:1526930377216};\\\", \\\"{x:1386,y:798,t:1526930377232};\\\", \\\"{x:1383,y:795,t:1526930377249};\\\", \\\"{x:1382,y:789,t:1526930377266};\\\", \\\"{x:1380,y:785,t:1526930377282};\\\", \\\"{x:1378,y:778,t:1526930377299};\\\", \\\"{x:1373,y:768,t:1526930377316};\\\", \\\"{x:1368,y:757,t:1526930377333};\\\", \\\"{x:1363,y:746,t:1526930377349};\\\", \\\"{x:1357,y:735,t:1526930377366};\\\", \\\"{x:1354,y:729,t:1526930377383};\\\", \\\"{x:1350,y:725,t:1526930377399};\\\", \\\"{x:1348,y:721,t:1526930377416};\\\", \\\"{x:1347,y:719,t:1526930377433};\\\", \\\"{x:1343,y:713,t:1526930377449};\\\", \\\"{x:1340,y:704,t:1526930377466};\\\", \\\"{x:1332,y:689,t:1526930377483};\\\", \\\"{x:1325,y:680,t:1526930377499};\\\", \\\"{x:1319,y:671,t:1526930377516};\\\", \\\"{x:1313,y:660,t:1526930377534};\\\", \\\"{x:1306,y:649,t:1526930377549};\\\", \\\"{x:1299,y:641,t:1526930377566};\\\", \\\"{x:1295,y:635,t:1526930377583};\\\", \\\"{x:1293,y:631,t:1526930377599};\\\", \\\"{x:1292,y:630,t:1526930377617};\\\", \\\"{x:1292,y:627,t:1526930377720};\\\", \\\"{x:1291,y:626,t:1526930377736};\\\", \\\"{x:1290,y:623,t:1526930377750};\\\", \\\"{x:1288,y:619,t:1526930377766};\\\", \\\"{x:1286,y:615,t:1526930377783};\\\", \\\"{x:1284,y:612,t:1526930377800};\\\", \\\"{x:1283,y:609,t:1526930377816};\\\", \\\"{x:1282,y:606,t:1526930377833};\\\", \\\"{x:1281,y:605,t:1526930377850};\\\", \\\"{x:1281,y:602,t:1526930377976};\\\", \\\"{x:1281,y:601,t:1526930377992};\\\", \\\"{x:1280,y:600,t:1526930378000};\\\", \\\"{x:1280,y:599,t:1526930378018};\\\", \\\"{x:1280,y:598,t:1526930378199};\\\", \\\"{x:1279,y:596,t:1526930378217};\\\", \\\"{x:1279,y:597,t:1526930378337};\\\", \\\"{x:1279,y:598,t:1526930378350};\\\", \\\"{x:1279,y:601,t:1526930378368};\\\", \\\"{x:1280,y:605,t:1526930378383};\\\", \\\"{x:1280,y:606,t:1526930378399};\\\", \\\"{x:1280,y:607,t:1526930378417};\\\", \\\"{x:1281,y:609,t:1526930378471};\\\", \\\"{x:1282,y:610,t:1526930378520};\\\", \\\"{x:1282,y:611,t:1526930378534};\\\", \\\"{x:1282,y:612,t:1526930378550};\\\", \\\"{x:1283,y:614,t:1526930378567};\\\", \\\"{x:1283,y:615,t:1526930378584};\\\", \\\"{x:1284,y:618,t:1526930378776};\\\", \\\"{x:1285,y:619,t:1526930378784};\\\", \\\"{x:1286,y:620,t:1526930378801};\\\", \\\"{x:1286,y:621,t:1526930378823};\\\", \\\"{x:1286,y:623,t:1526930378961};\\\", \\\"{x:1286,y:624,t:1526930378968};\\\", \\\"{x:1287,y:627,t:1526930378984};\\\", \\\"{x:1288,y:630,t:1526930379001};\\\", \\\"{x:1290,y:632,t:1526930379017};\\\", \\\"{x:1290,y:634,t:1526930379033};\\\", \\\"{x:1290,y:636,t:1526930379216};\\\", \\\"{x:1290,y:637,t:1526930379224};\\\", \\\"{x:1292,y:638,t:1526930379235};\\\", \\\"{x:1292,y:640,t:1526930379251};\\\", \\\"{x:1292,y:641,t:1526930379456};\\\", \\\"{x:1292,y:643,t:1526930379468};\\\", \\\"{x:1293,y:645,t:1526930379485};\\\", \\\"{x:1294,y:645,t:1526930379504};\\\", \\\"{x:1295,y:645,t:1526930379560};\\\", \\\"{x:1296,y:645,t:1526930379583};\\\", \\\"{x:1296,y:644,t:1526930379592};\\\", \\\"{x:1298,y:644,t:1526930379840};\\\", \\\"{x:1299,y:645,t:1526930379851};\\\", \\\"{x:1302,y:649,t:1526930379868};\\\", \\\"{x:1303,y:651,t:1526930379885};\\\", \\\"{x:1304,y:652,t:1526930379902};\\\", \\\"{x:1305,y:652,t:1526930379918};\\\", \\\"{x:1302,y:649,t:1526930379976};\\\", \\\"{x:1296,y:643,t:1526930379985};\\\", \\\"{x:1262,y:618,t:1526930380003};\\\", \\\"{x:1200,y:588,t:1526930380018};\\\", \\\"{x:1123,y:570,t:1526930380035};\\\", \\\"{x:1070,y:562,t:1526930380052};\\\", \\\"{x:1037,y:562,t:1526930380068};\\\", \\\"{x:1010,y:562,t:1526930380085};\\\", \\\"{x:988,y:571,t:1526930380102};\\\", \\\"{x:970,y:581,t:1526930380119};\\\", \\\"{x:956,y:592,t:1526930380136};\\\", \\\"{x:950,y:604,t:1526930380152};\\\", \\\"{x:949,y:609,t:1526930380169};\\\", \\\"{x:948,y:610,t:1526930380184};\\\", \\\"{x:946,y:610,t:1526930380223};\\\", \\\"{x:944,y:610,t:1526930380233};\\\", \\\"{x:934,y:606,t:1526930380250};\\\", \\\"{x:911,y:596,t:1526930380266};\\\", \\\"{x:880,y:584,t:1526930380284};\\\", \\\"{x:842,y:569,t:1526930380300};\\\", \\\"{x:818,y:551,t:1526930380317};\\\", \\\"{x:809,y:541,t:1526930380333};\\\", \\\"{x:807,y:537,t:1526930380350};\\\", \\\"{x:807,y:535,t:1526930380367};\\\", \\\"{x:807,y:534,t:1526930380391};\\\", \\\"{x:807,y:532,t:1526930380399};\\\", \\\"{x:807,y:528,t:1526930380416};\\\", \\\"{x:807,y:524,t:1526930380435};\\\", \\\"{x:810,y:517,t:1526930380451};\\\", \\\"{x:811,y:514,t:1526930380466};\\\", \\\"{x:814,y:511,t:1526930380483};\\\", \\\"{x:815,y:510,t:1526930380501};\\\", \\\"{x:817,y:508,t:1526930380517};\\\", \\\"{x:818,y:508,t:1526930380534};\\\", \\\"{x:821,y:508,t:1526930380551};\\\", \\\"{x:824,y:508,t:1526930380567};\\\", \\\"{x:828,y:508,t:1526930380584};\\\", \\\"{x:829,y:508,t:1526930380601};\\\", \\\"{x:831,y:507,t:1526930380616};\\\", \\\"{x:834,y:506,t:1526930380633};\\\", \\\"{x:836,y:505,t:1526930380651};\\\", \\\"{x:833,y:505,t:1526930381103};\\\", \\\"{x:826,y:503,t:1526930381118};\\\", \\\"{x:807,y:501,t:1526930381134};\\\", \\\"{x:779,y:497,t:1526930381151};\\\", \\\"{x:762,y:495,t:1526930381167};\\\", \\\"{x:753,y:495,t:1526930381183};\\\", \\\"{x:750,y:495,t:1526930381200};\\\", \\\"{x:748,y:495,t:1526930381218};\\\", \\\"{x:747,y:495,t:1526930381234};\\\", \\\"{x:745,y:496,t:1526930381251};\\\", \\\"{x:744,y:497,t:1526930381268};\\\", \\\"{x:741,y:497,t:1526930381284};\\\", \\\"{x:739,y:497,t:1526930381300};\\\", \\\"{x:737,y:497,t:1526930381318};\\\", \\\"{x:726,y:496,t:1526930381336};\\\", \\\"{x:717,y:495,t:1526930381354};\\\", \\\"{x:694,y:493,t:1526930381367};\\\", \\\"{x:679,y:493,t:1526930381384};\\\", \\\"{x:661,y:493,t:1526930381401};\\\", \\\"{x:646,y:493,t:1526930381417};\\\", \\\"{x:629,y:493,t:1526930381435};\\\", \\\"{x:612,y:493,t:1526930381451};\\\", \\\"{x:594,y:493,t:1526930381468};\\\", \\\"{x:584,y:493,t:1526930381485};\\\", \\\"{x:580,y:493,t:1526930381501};\\\", \\\"{x:579,y:493,t:1526930381608};\\\", \\\"{x:579,y:494,t:1526930381631};\\\", \\\"{x:581,y:495,t:1526930381639};\\\", \\\"{x:583,y:496,t:1526930381652};\\\", \\\"{x:592,y:500,t:1526930381668};\\\", \\\"{x:604,y:503,t:1526930381686};\\\", \\\"{x:618,y:505,t:1526930381702};\\\", \\\"{x:626,y:507,t:1526930381718};\\\", \\\"{x:628,y:507,t:1526930381735};\\\", \\\"{x:629,y:507,t:1526930381775};\\\", \\\"{x:627,y:507,t:1526930381855};\\\", \\\"{x:625,y:506,t:1526930381868};\\\", \\\"{x:620,y:506,t:1526930381885};\\\", \\\"{x:616,y:506,t:1526930381902};\\\", \\\"{x:613,y:506,t:1526930381918};\\\", \\\"{x:610,y:506,t:1526930381936};\\\", \\\"{x:609,y:506,t:1526930381952};\\\", \\\"{x:604,y:503,t:1526930381968};\\\", \\\"{x:595,y:499,t:1526930381986};\\\", \\\"{x:587,y:495,t:1526930382002};\\\", \\\"{x:585,y:495,t:1526930382018};\\\", \\\"{x:584,y:494,t:1526930382034};\\\", \\\"{x:584,y:495,t:1526930382111};\\\", \\\"{x:585,y:496,t:1526930382135};\\\", \\\"{x:586,y:496,t:1526930382151};\\\", \\\"{x:590,y:499,t:1526930382168};\\\", \\\"{x:591,y:499,t:1526930382185};\\\", \\\"{x:593,y:500,t:1526930382202};\\\", \\\"{x:594,y:500,t:1526930382219};\\\", \\\"{x:596,y:501,t:1526930382960};\\\", \\\"{x:597,y:503,t:1526930382969};\\\", \\\"{x:598,y:504,t:1526930382987};\\\", \\\"{x:600,y:507,t:1526930383008};\\\", \\\"{x:601,y:507,t:1526930383018};\\\", \\\"{x:601,y:508,t:1526930383047};\\\", \\\"{x:601,y:506,t:1526930383344};\\\", \\\"{x:602,y:504,t:1526930383367};\\\", \\\"{x:602,y:506,t:1526930384935};\\\", \\\"{x:604,y:511,t:1526930384943};\\\", \\\"{x:606,y:519,t:1526930384955};\\\", \\\"{x:615,y:534,t:1526930384972};\\\", \\\"{x:622,y:547,t:1526930384987};\\\", \\\"{x:627,y:555,t:1526930385004};\\\", \\\"{x:634,y:563,t:1526930385022};\\\", \\\"{x:642,y:570,t:1526930385037};\\\", \\\"{x:653,y:576,t:1526930385054};\\\", \\\"{x:672,y:581,t:1526930385070};\\\", \\\"{x:687,y:582,t:1526930385087};\\\", \\\"{x:704,y:582,t:1526930385103};\\\", \\\"{x:724,y:580,t:1526930385122};\\\", \\\"{x:746,y:578,t:1526930385138};\\\", \\\"{x:775,y:574,t:1526930385154};\\\", \\\"{x:806,y:573,t:1526930385171};\\\", \\\"{x:834,y:573,t:1526930385187};\\\", \\\"{x:868,y:574,t:1526930385204};\\\", \\\"{x:908,y:581,t:1526930385221};\\\", \\\"{x:962,y:590,t:1526930385238};\\\", \\\"{x:1029,y:601,t:1526930385254};\\\", \\\"{x:1120,y:614,t:1526930385270};\\\", \\\"{x:1190,y:622,t:1526930385288};\\\", \\\"{x:1246,y:624,t:1526930385304};\\\", \\\"{x:1294,y:625,t:1526930385321};\\\", \\\"{x:1350,y:625,t:1526930385338};\\\", \\\"{x:1398,y:625,t:1526930385354};\\\", \\\"{x:1442,y:625,t:1526930385371};\\\", \\\"{x:1476,y:628,t:1526930385388};\\\", \\\"{x:1505,y:630,t:1526930385404};\\\", \\\"{x:1533,y:636,t:1526930385421};\\\", \\\"{x:1562,y:643,t:1526930385438};\\\", \\\"{x:1586,y:651,t:1526930385455};\\\", \\\"{x:1620,y:666,t:1526930385472};\\\", \\\"{x:1635,y:671,t:1526930385488};\\\", \\\"{x:1642,y:675,t:1526930385506};\\\", \\\"{x:1641,y:676,t:1526930385600};\\\", \\\"{x:1638,y:679,t:1526930385608};\\\", \\\"{x:1633,y:682,t:1526930385621};\\\", \\\"{x:1623,y:687,t:1526930385639};\\\", \\\"{x:1601,y:703,t:1526930385655};\\\", \\\"{x:1586,y:714,t:1526930385671};\\\", \\\"{x:1569,y:726,t:1526930385688};\\\", \\\"{x:1555,y:738,t:1526930385705};\\\", \\\"{x:1546,y:745,t:1526930385721};\\\", \\\"{x:1537,y:750,t:1526930385738};\\\", \\\"{x:1531,y:754,t:1526930385755};\\\", \\\"{x:1528,y:754,t:1526930385771};\\\", \\\"{x:1526,y:754,t:1526930385788};\\\", \\\"{x:1525,y:754,t:1526930385856};\\\", \\\"{x:1522,y:756,t:1526930385872};\\\", \\\"{x:1521,y:757,t:1526930385888};\\\", \\\"{x:1519,y:758,t:1526930385906};\\\", \\\"{x:1517,y:759,t:1526930385922};\\\", \\\"{x:1516,y:759,t:1526930385992};\\\", \\\"{x:1515,y:759,t:1526930386005};\\\", \\\"{x:1514,y:758,t:1526930386022};\\\", \\\"{x:1514,y:759,t:1526930386103};\\\", \\\"{x:1515,y:762,t:1526930386111};\\\", \\\"{x:1516,y:765,t:1526930386122};\\\", \\\"{x:1516,y:770,t:1526930386138};\\\", \\\"{x:1519,y:778,t:1526930386155};\\\", \\\"{x:1521,y:784,t:1526930386172};\\\", \\\"{x:1524,y:788,t:1526930386188};\\\", \\\"{x:1524,y:790,t:1526930386205};\\\", \\\"{x:1525,y:792,t:1526930386231};\\\", \\\"{x:1525,y:793,t:1526930386264};\\\", \\\"{x:1526,y:794,t:1526930386272};\\\", \\\"{x:1526,y:795,t:1526930386289};\\\", \\\"{x:1527,y:800,t:1526930386306};\\\", \\\"{x:1527,y:803,t:1526930386322};\\\", \\\"{x:1528,y:809,t:1526930386338};\\\", \\\"{x:1530,y:817,t:1526930386356};\\\", \\\"{x:1531,y:821,t:1526930386373};\\\", \\\"{x:1531,y:823,t:1526930386389};\\\", \\\"{x:1531,y:822,t:1526930386496};\\\", \\\"{x:1531,y:820,t:1526930386512};\\\", \\\"{x:1531,y:819,t:1526930386522};\\\", \\\"{x:1530,y:816,t:1526930386539};\\\", \\\"{x:1529,y:816,t:1526930386583};\\\", \\\"{x:1528,y:816,t:1526930386592};\\\", \\\"{x:1527,y:816,t:1526930386680};\\\", \\\"{x:1526,y:816,t:1526930386690};\\\", \\\"{x:1525,y:815,t:1526930386705};\\\", \\\"{x:1525,y:812,t:1526930386872};\\\", \\\"{x:1538,y:782,t:1526930386890};\\\", \\\"{x:1550,y:754,t:1526930386907};\\\", \\\"{x:1563,y:734,t:1526930386923};\\\", \\\"{x:1571,y:722,t:1526930386939};\\\", \\\"{x:1577,y:719,t:1526930386956};\\\", \\\"{x:1580,y:718,t:1526930386972};\\\", \\\"{x:1582,y:719,t:1526930387048};\\\", \\\"{x:1583,y:719,t:1526930387055};\\\", \\\"{x:1585,y:723,t:1526930387072};\\\", \\\"{x:1587,y:724,t:1526930387089};\\\", \\\"{x:1587,y:725,t:1526930387106};\\\", \\\"{x:1588,y:725,t:1526930387123};\\\", \\\"{x:1589,y:725,t:1526930387140};\\\", \\\"{x:1590,y:725,t:1526930387157};\\\", \\\"{x:1591,y:725,t:1526930387172};\\\", \\\"{x:1592,y:725,t:1526930387190};\\\", \\\"{x:1597,y:723,t:1526930387207};\\\", \\\"{x:1600,y:722,t:1526930387223};\\\", \\\"{x:1605,y:720,t:1526930387239};\\\", \\\"{x:1605,y:719,t:1526930387288};\\\", \\\"{x:1607,y:716,t:1526930387295};\\\", \\\"{x:1607,y:715,t:1526930387306};\\\", \\\"{x:1608,y:709,t:1526930387324};\\\", \\\"{x:1609,y:703,t:1526930387339};\\\", \\\"{x:1609,y:699,t:1526930387357};\\\", \\\"{x:1609,y:698,t:1526930387373};\\\", \\\"{x:1609,y:697,t:1526930387389};\\\", \\\"{x:1610,y:697,t:1526930387448};\\\", \\\"{x:1611,y:697,t:1526930387456};\\\", \\\"{x:1611,y:699,t:1526930387487};\\\", \\\"{x:1611,y:700,t:1526930387672};\\\", \\\"{x:1611,y:701,t:1526930387688};\\\", \\\"{x:1611,y:702,t:1526930387697};\\\", \\\"{x:1611,y:701,t:1526930388015};\\\", \\\"{x:1611,y:700,t:1526930388022};\\\", \\\"{x:1611,y:702,t:1526930388809};\\\", \\\"{x:1611,y:704,t:1526930388824};\\\", \\\"{x:1611,y:706,t:1526930388841};\\\", \\\"{x:1611,y:708,t:1526930388928};\\\", \\\"{x:1610,y:711,t:1526930388941};\\\", \\\"{x:1605,y:723,t:1526930388958};\\\", \\\"{x:1597,y:740,t:1526930388975};\\\", \\\"{x:1583,y:761,t:1526930388991};\\\", \\\"{x:1565,y:787,t:1526930389007};\\\", \\\"{x:1555,y:802,t:1526930389024};\\\", \\\"{x:1545,y:817,t:1526930389040};\\\", \\\"{x:1537,y:832,t:1526930389058};\\\", \\\"{x:1529,y:846,t:1526930389074};\\\", \\\"{x:1526,y:854,t:1526930389092};\\\", \\\"{x:1523,y:858,t:1526930389108};\\\", \\\"{x:1520,y:861,t:1526930389125};\\\", \\\"{x:1519,y:864,t:1526930389141};\\\", \\\"{x:1518,y:865,t:1526930389157};\\\", \\\"{x:1518,y:867,t:1526930389175};\\\", \\\"{x:1518,y:874,t:1526930389191};\\\", \\\"{x:1517,y:880,t:1526930389207};\\\", \\\"{x:1515,y:886,t:1526930389225};\\\", \\\"{x:1514,y:892,t:1526930389242};\\\", \\\"{x:1511,y:900,t:1526930389257};\\\", \\\"{x:1510,y:906,t:1526930389274};\\\", \\\"{x:1508,y:912,t:1526930389292};\\\", \\\"{x:1508,y:914,t:1526930389308};\\\", \\\"{x:1507,y:917,t:1526930389324};\\\", \\\"{x:1507,y:918,t:1526930389341};\\\", \\\"{x:1506,y:919,t:1526930389357};\\\", \\\"{x:1505,y:921,t:1526930389384};\\\", \\\"{x:1504,y:924,t:1526930389400};\\\", \\\"{x:1503,y:926,t:1526930389416};\\\", \\\"{x:1502,y:929,t:1526930389424};\\\", \\\"{x:1500,y:933,t:1526930389442};\\\", \\\"{x:1497,y:939,t:1526930389458};\\\", \\\"{x:1495,y:942,t:1526930389475};\\\", \\\"{x:1494,y:947,t:1526930389491};\\\", \\\"{x:1492,y:951,t:1526930389509};\\\", \\\"{x:1492,y:952,t:1526930389524};\\\", \\\"{x:1492,y:954,t:1526930389541};\\\", \\\"{x:1491,y:955,t:1526930389559};\\\", \\\"{x:1490,y:956,t:1526930389575};\\\", \\\"{x:1489,y:959,t:1526930389592};\\\", \\\"{x:1488,y:961,t:1526930389608};\\\", \\\"{x:1488,y:964,t:1526930389625};\\\", \\\"{x:1484,y:971,t:1526930389642};\\\", \\\"{x:1483,y:975,t:1526930389659};\\\", \\\"{x:1481,y:979,t:1526930389675};\\\", \\\"{x:1478,y:983,t:1526930389691};\\\", \\\"{x:1477,y:984,t:1526930389708};\\\", \\\"{x:1475,y:984,t:1526930389744};\\\", \\\"{x:1474,y:984,t:1526930389758};\\\", \\\"{x:1469,y:977,t:1526930389774};\\\", \\\"{x:1464,y:959,t:1526930389792};\\\", \\\"{x:1459,y:951,t:1526930389809};\\\", \\\"{x:1455,y:944,t:1526930389824};\\\", \\\"{x:1452,y:940,t:1526930389841};\\\", \\\"{x:1450,y:937,t:1526930389858};\\\", \\\"{x:1449,y:936,t:1526930389911};\\\", \\\"{x:1449,y:935,t:1526930389925};\\\", \\\"{x:1448,y:933,t:1526930389941};\\\", \\\"{x:1447,y:929,t:1526930389958};\\\", \\\"{x:1444,y:919,t:1526930389975};\\\", \\\"{x:1443,y:909,t:1526930389991};\\\", \\\"{x:1440,y:894,t:1526930390008};\\\", \\\"{x:1437,y:880,t:1526930390025};\\\", \\\"{x:1434,y:870,t:1526930390041};\\\", \\\"{x:1432,y:862,t:1526930390058};\\\", \\\"{x:1430,y:858,t:1526930390075};\\\", \\\"{x:1429,y:854,t:1526930390091};\\\", \\\"{x:1429,y:850,t:1526930390108};\\\", \\\"{x:1426,y:846,t:1526930390125};\\\", \\\"{x:1426,y:844,t:1526930390142};\\\", \\\"{x:1425,y:842,t:1526930390158};\\\", \\\"{x:1421,y:833,t:1526930390175};\\\", \\\"{x:1416,y:822,t:1526930390192};\\\", \\\"{x:1407,y:807,t:1526930390209};\\\", \\\"{x:1397,y:791,t:1526930390225};\\\", \\\"{x:1390,y:777,t:1526930390242};\\\", \\\"{x:1385,y:765,t:1526930390258};\\\", \\\"{x:1378,y:757,t:1526930390276};\\\", \\\"{x:1374,y:749,t:1526930390292};\\\", \\\"{x:1371,y:743,t:1526930390309};\\\", \\\"{x:1368,y:739,t:1526930390326};\\\", \\\"{x:1365,y:734,t:1526930390342};\\\", \\\"{x:1362,y:729,t:1526930390359};\\\", \\\"{x:1356,y:717,t:1526930390375};\\\", \\\"{x:1350,y:706,t:1526930390391};\\\", \\\"{x:1341,y:690,t:1526930390408};\\\", \\\"{x:1331,y:669,t:1526930390426};\\\", \\\"{x:1323,y:647,t:1526930390443};\\\", \\\"{x:1313,y:627,t:1526930390458};\\\", \\\"{x:1301,y:607,t:1526930390476};\\\", \\\"{x:1290,y:591,t:1526930390493};\\\", \\\"{x:1282,y:581,t:1526930390509};\\\", \\\"{x:1278,y:578,t:1526930390525};\\\", \\\"{x:1275,y:577,t:1526930390543};\\\", \\\"{x:1275,y:575,t:1526930390559};\\\", \\\"{x:1275,y:574,t:1526930390600};\\\", \\\"{x:1275,y:572,t:1526930390616};\\\", \\\"{x:1275,y:571,t:1526930390631};\\\", \\\"{x:1274,y:569,t:1526930390643};\\\", \\\"{x:1273,y:567,t:1526930390659};\\\", \\\"{x:1272,y:564,t:1526930390676};\\\", \\\"{x:1271,y:562,t:1526930390693};\\\", \\\"{x:1271,y:561,t:1526930390709};\\\", \\\"{x:1271,y:559,t:1526930390726};\\\", \\\"{x:1270,y:558,t:1526930391248};\\\", \\\"{x:1269,y:558,t:1526930391264};\\\", \\\"{x:1268,y:558,t:1526930391275};\\\", \\\"{x:1267,y:558,t:1526930391293};\\\", \\\"{x:1265,y:558,t:1526930391310};\\\", \\\"{x:1264,y:558,t:1526930391327};\\\", \\\"{x:1261,y:558,t:1526930391343};\\\", \\\"{x:1248,y:556,t:1526930391359};\\\", \\\"{x:1230,y:556,t:1526930391376};\\\", \\\"{x:1212,y:556,t:1526930391393};\\\", \\\"{x:1186,y:571,t:1526930391410};\\\", \\\"{x:1147,y:592,t:1526930391426};\\\", \\\"{x:1094,y:617,t:1526930391442};\\\", \\\"{x:1039,y:642,t:1526930391460};\\\", \\\"{x:975,y:659,t:1526930391477};\\\", \\\"{x:905,y:668,t:1526930391493};\\\", \\\"{x:852,y:669,t:1526930391510};\\\", \\\"{x:799,y:669,t:1526930391526};\\\", \\\"{x:759,y:669,t:1526930391543};\\\", \\\"{x:723,y:666,t:1526930391560};\\\", \\\"{x:710,y:663,t:1526930391577};\\\", \\\"{x:704,y:662,t:1526930391593};\\\", \\\"{x:699,y:662,t:1526930391609};\\\", \\\"{x:692,y:662,t:1526930391627};\\\", \\\"{x:687,y:662,t:1526930391643};\\\", \\\"{x:681,y:663,t:1526930391659};\\\", \\\"{x:673,y:666,t:1526930391676};\\\", \\\"{x:663,y:672,t:1526930391693};\\\", \\\"{x:650,y:677,t:1526930391708};\\\", \\\"{x:636,y:682,t:1526930391726};\\\", \\\"{x:607,y:690,t:1526930391742};\\\", \\\"{x:588,y:695,t:1526930391759};\\\", \\\"{x:577,y:695,t:1526930391776};\\\", \\\"{x:568,y:695,t:1526930391793};\\\", \\\"{x:564,y:695,t:1526930391809};\\\", \\\"{x:561,y:695,t:1526930391826};\\\", \\\"{x:558,y:695,t:1526930391844};\\\", \\\"{x:554,y:697,t:1526930391859};\\\", \\\"{x:549,y:702,t:1526930391876};\\\", \\\"{x:547,y:704,t:1526930391893};\\\", \\\"{x:539,y:711,t:1526930391910};\\\", \\\"{x:533,y:717,t:1526930391926};\\\", \\\"{x:525,y:725,t:1526930391943};\\\", \\\"{x:522,y:731,t:1526930391959};\\\", \\\"{x:521,y:732,t:1526930391976};\\\", \\\"{x:520,y:734,t:1526930391993};\\\" ] }, { \\\"rt\\\": 17935, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 18, \\\"time_elapsed\\\": 772839, \\\"internal_node_id\\\": \\\"0.0-6.0-8.0\\\", \\\"subject\\\": \\\"WKBNA\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 14, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-03 PM-03 PM-X \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:520,y:733,t:1526930394303};\\\", \\\"{x:520,y:732,t:1526930394311};\\\", \\\"{x:519,y:731,t:1526930394328};\\\", \\\"{x:519,y:730,t:1526930394383};\\\", \\\"{x:519,y:728,t:1526930394398};\\\", \\\"{x:522,y:727,t:1526930394410};\\\", \\\"{x:528,y:724,t:1526930394427};\\\", \\\"{x:535,y:720,t:1526930394444};\\\", \\\"{x:550,y:718,t:1526930394461};\\\", \\\"{x:571,y:714,t:1526930394477};\\\", \\\"{x:595,y:714,t:1526930394494};\\\", \\\"{x:639,y:712,t:1526930394511};\\\", \\\"{x:676,y:712,t:1526930394528};\\\", \\\"{x:722,y:719,t:1526930394545};\\\", \\\"{x:756,y:725,t:1526930394561};\\\", \\\"{x:803,y:731,t:1526930394578};\\\", \\\"{x:845,y:741,t:1526930394594};\\\", \\\"{x:898,y:749,t:1526930394611};\\\", \\\"{x:937,y:753,t:1526930394629};\\\", \\\"{x:971,y:753,t:1526930394645};\\\", \\\"{x:995,y:753,t:1526930394662};\\\", \\\"{x:1016,y:750,t:1526930394679};\\\", \\\"{x:1038,y:740,t:1526930394695};\\\", \\\"{x:1048,y:735,t:1526930394712};\\\", \\\"{x:1061,y:732,t:1526930394729};\\\", \\\"{x:1070,y:731,t:1526930394745};\\\", \\\"{x:1075,y:731,t:1526930394762};\\\", \\\"{x:1084,y:730,t:1526930394778};\\\", \\\"{x:1095,y:730,t:1526930394795};\\\", \\\"{x:1106,y:730,t:1526930394811};\\\", \\\"{x:1122,y:730,t:1526930394829};\\\", \\\"{x:1138,y:733,t:1526930394846};\\\", \\\"{x:1150,y:735,t:1526930394861};\\\", \\\"{x:1156,y:739,t:1526930394879};\\\", \\\"{x:1158,y:739,t:1526930394896};\\\", \\\"{x:1161,y:739,t:1526930395160};\\\", \\\"{x:1163,y:738,t:1526930395168};\\\", \\\"{x:1166,y:737,t:1526930395179};\\\", \\\"{x:1175,y:736,t:1526930395196};\\\", \\\"{x:1192,y:736,t:1526930395212};\\\", \\\"{x:1214,y:741,t:1526930395229};\\\", \\\"{x:1243,y:750,t:1526930395245};\\\", \\\"{x:1272,y:759,t:1526930395261};\\\", \\\"{x:1298,y:767,t:1526930395278};\\\", \\\"{x:1334,y:776,t:1526930395295};\\\", \\\"{x:1352,y:779,t:1526930395312};\\\", \\\"{x:1368,y:781,t:1526930395328};\\\", \\\"{x:1379,y:781,t:1526930395345};\\\", \\\"{x:1386,y:784,t:1526930395361};\\\", \\\"{x:1391,y:785,t:1526930395379};\\\", \\\"{x:1398,y:789,t:1526930395395};\\\", \\\"{x:1406,y:796,t:1526930395412};\\\", \\\"{x:1415,y:804,t:1526930395428};\\\", \\\"{x:1422,y:811,t:1526930395445};\\\", \\\"{x:1435,y:822,t:1526930395462};\\\", \\\"{x:1452,y:835,t:1526930395478};\\\", \\\"{x:1462,y:844,t:1526930395495};\\\", \\\"{x:1481,y:855,t:1526930395511};\\\", \\\"{x:1492,y:863,t:1526930395528};\\\", \\\"{x:1496,y:865,t:1526930395545};\\\", \\\"{x:1497,y:866,t:1526930395561};\\\", \\\"{x:1498,y:867,t:1526930395615};\\\", \\\"{x:1500,y:868,t:1526930395628};\\\", \\\"{x:1501,y:872,t:1526930395645};\\\", \\\"{x:1501,y:878,t:1526930395662};\\\", \\\"{x:1503,y:885,t:1526930395678};\\\", \\\"{x:1503,y:892,t:1526930395696};\\\", \\\"{x:1503,y:894,t:1526930395712};\\\", \\\"{x:1503,y:895,t:1526930395729};\\\", \\\"{x:1503,y:896,t:1526930395896};\\\", \\\"{x:1503,y:900,t:1526930395913};\\\", \\\"{x:1503,y:902,t:1526930395928};\\\", \\\"{x:1504,y:905,t:1526930395945};\\\", \\\"{x:1505,y:907,t:1526930395962};\\\", \\\"{x:1506,y:907,t:1526930395978};\\\", \\\"{x:1507,y:907,t:1526930396015};\\\", \\\"{x:1507,y:908,t:1526930396039};\\\", \\\"{x:1508,y:909,t:1526930396055};\\\", \\\"{x:1509,y:910,t:1526930396080};\\\", \\\"{x:1511,y:913,t:1526930396096};\\\", \\\"{x:1515,y:919,t:1526930396113};\\\", \\\"{x:1522,y:926,t:1526930396129};\\\", \\\"{x:1525,y:931,t:1526930396146};\\\", \\\"{x:1530,y:935,t:1526930396163};\\\", \\\"{x:1535,y:938,t:1526930396179};\\\", \\\"{x:1537,y:939,t:1526930396197};\\\", \\\"{x:1539,y:941,t:1526930396320};\\\", \\\"{x:1539,y:942,t:1526930396329};\\\", \\\"{x:1543,y:946,t:1526930396346};\\\", \\\"{x:1545,y:950,t:1526930396363};\\\", \\\"{x:1547,y:951,t:1526930396379};\\\", \\\"{x:1548,y:952,t:1526930396396};\\\", \\\"{x:1548,y:953,t:1526930396413};\\\", \\\"{x:1550,y:953,t:1526930396480};\\\", \\\"{x:1551,y:954,t:1526930396536};\\\", \\\"{x:1552,y:955,t:1526930396547};\\\", \\\"{x:1552,y:956,t:1526930396563};\\\", \\\"{x:1553,y:959,t:1526930396579};\\\", \\\"{x:1554,y:962,t:1526930396596};\\\", \\\"{x:1554,y:964,t:1526930396632};\\\", \\\"{x:1555,y:965,t:1526930396760};\\\", \\\"{x:1555,y:967,t:1526930396775};\\\", \\\"{x:1555,y:968,t:1526930396792};\\\", \\\"{x:1555,y:970,t:1526930396800};\\\", \\\"{x:1555,y:971,t:1526930396823};\\\", \\\"{x:1556,y:973,t:1526930397232};\\\", \\\"{x:1556,y:974,t:1526930397246};\\\", \\\"{x:1556,y:977,t:1526930397263};\\\", \\\"{x:1556,y:978,t:1526930397280};\\\", \\\"{x:1556,y:977,t:1526930397359};\\\", \\\"{x:1556,y:976,t:1526930397368};\\\", \\\"{x:1555,y:975,t:1526930397380};\\\", \\\"{x:1554,y:974,t:1526930397396};\\\", \\\"{x:1553,y:974,t:1526930397464};\\\", \\\"{x:1552,y:974,t:1526930397527};\\\", \\\"{x:1551,y:974,t:1526930397535};\\\", \\\"{x:1549,y:973,t:1526930397546};\\\", \\\"{x:1547,y:970,t:1526930397562};\\\", \\\"{x:1543,y:965,t:1526930397579};\\\", \\\"{x:1541,y:964,t:1526930397595};\\\", \\\"{x:1541,y:963,t:1526930397612};\\\", \\\"{x:1540,y:963,t:1526930397679};\\\", \\\"{x:1539,y:964,t:1526930397703};\\\", \\\"{x:1538,y:965,t:1526930397784};\\\", \\\"{x:1538,y:966,t:1526930398544};\\\", \\\"{x:1538,y:967,t:1526930398552};\\\", \\\"{x:1538,y:969,t:1526930398562};\\\", \\\"{x:1538,y:971,t:1526930398579};\\\", \\\"{x:1539,y:973,t:1526930398596};\\\", \\\"{x:1540,y:974,t:1526930398615};\\\", \\\"{x:1540,y:972,t:1526930398878};\\\", \\\"{x:1540,y:971,t:1526930398886};\\\", \\\"{x:1540,y:970,t:1526930398897};\\\", \\\"{x:1540,y:969,t:1526930398912};\\\", \\\"{x:1540,y:966,t:1526930399320};\\\", \\\"{x:1540,y:963,t:1526930399330};\\\", \\\"{x:1540,y:962,t:1526930399347};\\\", \\\"{x:1540,y:960,t:1526930399364};\\\", \\\"{x:1540,y:959,t:1526930399768};\\\", \\\"{x:1540,y:957,t:1526930399780};\\\", \\\"{x:1540,y:956,t:1526930399797};\\\", \\\"{x:1540,y:955,t:1526930399814};\\\", \\\"{x:1541,y:954,t:1526930400160};\\\", \\\"{x:1542,y:954,t:1526930400168};\\\", \\\"{x:1544,y:954,t:1526930400207};\\\", \\\"{x:1545,y:954,t:1526930400264};\\\", \\\"{x:1546,y:954,t:1526930400336};\\\", \\\"{x:1546,y:956,t:1526930400352};\\\", \\\"{x:1547,y:957,t:1526930400364};\\\", \\\"{x:1548,y:959,t:1526930400379};\\\", \\\"{x:1548,y:958,t:1526930400920};\\\", \\\"{x:1548,y:957,t:1526930401152};\\\", \\\"{x:1548,y:955,t:1526930402240};\\\", \\\"{x:1548,y:954,t:1526930402912};\\\", \\\"{x:1548,y:952,t:1526930402919};\\\", \\\"{x:1547,y:950,t:1526930402984};\\\", \\\"{x:1547,y:948,t:1526930403086};\\\", \\\"{x:1545,y:946,t:1526930403102};\\\", \\\"{x:1543,y:942,t:1526930403115};\\\", \\\"{x:1537,y:937,t:1526930403131};\\\", \\\"{x:1531,y:932,t:1526930403147};\\\", \\\"{x:1525,y:927,t:1526930403165};\\\", \\\"{x:1522,y:926,t:1526930403180};\\\", \\\"{x:1519,y:924,t:1526930403197};\\\", \\\"{x:1517,y:923,t:1526930403215};\\\", \\\"{x:1516,y:922,t:1526930403247};\\\", \\\"{x:1515,y:920,t:1526930403263};\\\", \\\"{x:1512,y:919,t:1526930403271};\\\", \\\"{x:1511,y:917,t:1526930403281};\\\", \\\"{x:1507,y:911,t:1526930403298};\\\", \\\"{x:1499,y:901,t:1526930403315};\\\", \\\"{x:1492,y:890,t:1526930403331};\\\", \\\"{x:1485,y:880,t:1526930403348};\\\", \\\"{x:1480,y:873,t:1526930403364};\\\", \\\"{x:1476,y:868,t:1526930403381};\\\", \\\"{x:1476,y:866,t:1526930403398};\\\", \\\"{x:1474,y:863,t:1526930403415};\\\", \\\"{x:1473,y:860,t:1526930403544};\\\", \\\"{x:1471,y:858,t:1526930403552};\\\", \\\"{x:1471,y:856,t:1526930403565};\\\", \\\"{x:1469,y:853,t:1526930403582};\\\", \\\"{x:1468,y:850,t:1526930403598};\\\", \\\"{x:1467,y:849,t:1526930403615};\\\", \\\"{x:1467,y:847,t:1526930403808};\\\", \\\"{x:1467,y:846,t:1526930404023};\\\", \\\"{x:1467,y:844,t:1526930404031};\\\", \\\"{x:1467,y:843,t:1526930404056};\\\", \\\"{x:1467,y:842,t:1526930404272};\\\", \\\"{x:1467,y:841,t:1526930404448};\\\", \\\"{x:1467,y:837,t:1526930404465};\\\", \\\"{x:1467,y:834,t:1526930404482};\\\", \\\"{x:1468,y:831,t:1526930404498};\\\", \\\"{x:1468,y:829,t:1526930404515};\\\", \\\"{x:1470,y:828,t:1526930404532};\\\", \\\"{x:1471,y:830,t:1526930404760};\\\", \\\"{x:1471,y:832,t:1526930404776};\\\", \\\"{x:1472,y:834,t:1526930404783};\\\", \\\"{x:1473,y:835,t:1526930404798};\\\", \\\"{x:1473,y:834,t:1526930404888};\\\", \\\"{x:1473,y:831,t:1526930404899};\\\", \\\"{x:1470,y:826,t:1526930404915};\\\", \\\"{x:1470,y:823,t:1526930404933};\\\", \\\"{x:1469,y:823,t:1526930404948};\\\", \\\"{x:1469,y:821,t:1526930404965};\\\", \\\"{x:1468,y:821,t:1526930405039};\\\", \\\"{x:1467,y:820,t:1526930405079};\\\", \\\"{x:1466,y:820,t:1526930405128};\\\", \\\"{x:1467,y:821,t:1526930405143};\\\", \\\"{x:1470,y:823,t:1526930405160};\\\", \\\"{x:1471,y:824,t:1526930405168};\\\", \\\"{x:1474,y:825,t:1526930405183};\\\", \\\"{x:1475,y:827,t:1526930405198};\\\", \\\"{x:1476,y:829,t:1526930405218};\\\", \\\"{x:1476,y:830,t:1526930405232};\\\", \\\"{x:1477,y:831,t:1526930405247};\\\", \\\"{x:1477,y:832,t:1526930405278};\\\", \\\"{x:1478,y:832,t:1526930405287};\\\", \\\"{x:1479,y:832,t:1526930405298};\\\", \\\"{x:1480,y:833,t:1526930405314};\\\", \\\"{x:1481,y:833,t:1526930405331};\\\", \\\"{x:1483,y:833,t:1526930405349};\\\", \\\"{x:1484,y:833,t:1526930405544};\\\", \\\"{x:1484,y:834,t:1526930406552};\\\", \\\"{x:1483,y:835,t:1526930406566};\\\", \\\"{x:1483,y:838,t:1526930406584};\\\", \\\"{x:1481,y:843,t:1526930406599};\\\", \\\"{x:1481,y:844,t:1526930406696};\\\", \\\"{x:1480,y:845,t:1526930406703};\\\", \\\"{x:1479,y:847,t:1526930406717};\\\", \\\"{x:1476,y:848,t:1526930406732};\\\", \\\"{x:1471,y:852,t:1526930406749};\\\", \\\"{x:1465,y:853,t:1526930406767};\\\", \\\"{x:1459,y:855,t:1526930406783};\\\", \\\"{x:1432,y:856,t:1526930406800};\\\", \\\"{x:1393,y:844,t:1526930406815};\\\", \\\"{x:1338,y:819,t:1526930406833};\\\", \\\"{x:1233,y:772,t:1526930406849};\\\", \\\"{x:1104,y:725,t:1526930406867};\\\", \\\"{x:988,y:689,t:1526930406883};\\\", \\\"{x:899,y:666,t:1526930406899};\\\", \\\"{x:841,y:651,t:1526930406916};\\\", \\\"{x:814,y:643,t:1526930406932};\\\", \\\"{x:797,y:638,t:1526930406949};\\\", \\\"{x:792,y:636,t:1526930406966};\\\", \\\"{x:791,y:636,t:1526930406982};\\\", \\\"{x:791,y:634,t:1526930407056};\\\", \\\"{x:790,y:632,t:1526930407066};\\\", \\\"{x:782,y:622,t:1526930407084};\\\", \\\"{x:768,y:614,t:1526930407098};\\\", \\\"{x:753,y:606,t:1526930407115};\\\", \\\"{x:718,y:594,t:1526930407139};\\\", \\\"{x:691,y:589,t:1526930407156};\\\", \\\"{x:665,y:589,t:1526930407172};\\\", \\\"{x:655,y:590,t:1526930407189};\\\", \\\"{x:648,y:595,t:1526930407206};\\\", \\\"{x:646,y:603,t:1526930407222};\\\", \\\"{x:646,y:612,t:1526930407239};\\\", \\\"{x:649,y:621,t:1526930407256};\\\", \\\"{x:653,y:626,t:1526930407273};\\\", \\\"{x:655,y:629,t:1526930407289};\\\", \\\"{x:653,y:630,t:1526930407351};\\\", \\\"{x:647,y:630,t:1526930407358};\\\", \\\"{x:638,y:630,t:1526930407372};\\\", \\\"{x:613,y:630,t:1526930407390};\\\", \\\"{x:574,y:634,t:1526930407406};\\\", \\\"{x:511,y:637,t:1526930407423};\\\", \\\"{x:490,y:642,t:1526930407440};\\\", \\\"{x:484,y:642,t:1526930407457};\\\", \\\"{x:481,y:641,t:1526930407472};\\\", \\\"{x:481,y:640,t:1526930407490};\\\", \\\"{x:481,y:638,t:1526930407551};\\\", \\\"{x:480,y:638,t:1526930407623};\\\", \\\"{x:472,y:642,t:1526930407641};\\\", \\\"{x:463,y:645,t:1526930407656};\\\", \\\"{x:455,y:648,t:1526930407673};\\\", \\\"{x:447,y:652,t:1526930407690};\\\", \\\"{x:442,y:652,t:1526930407707};\\\", \\\"{x:439,y:652,t:1526930407723};\\\", \\\"{x:435,y:651,t:1526930407742};\\\", \\\"{x:433,y:647,t:1526930407756};\\\", \\\"{x:433,y:639,t:1526930407773};\\\", \\\"{x:441,y:629,t:1526930407792};\\\", \\\"{x:474,y:621,t:1526930407806};\\\", \\\"{x:506,y:618,t:1526930407823};\\\", \\\"{x:559,y:618,t:1526930407840};\\\", \\\"{x:617,y:618,t:1526930407857};\\\", \\\"{x:684,y:618,t:1526930407873};\\\", \\\"{x:741,y:626,t:1526930407890};\\\", \\\"{x:786,y:635,t:1526930407906};\\\", \\\"{x:805,y:639,t:1526930407922};\\\", \\\"{x:808,y:639,t:1526930407939};\\\", \\\"{x:801,y:635,t:1526930407990};\\\", \\\"{x:794,y:628,t:1526930408007};\\\", \\\"{x:758,y:613,t:1526930408022};\\\", \\\"{x:725,y:606,t:1526930408039};\\\", \\\"{x:697,y:600,t:1526930408057};\\\", \\\"{x:670,y:599,t:1526930408072};\\\", \\\"{x:647,y:599,t:1526930408090};\\\", \\\"{x:634,y:599,t:1526930408107};\\\", \\\"{x:629,y:599,t:1526930408124};\\\", \\\"{x:627,y:599,t:1526930408140};\\\", \\\"{x:626,y:599,t:1526930408157};\\\", \\\"{x:625,y:599,t:1526930408175};\\\", \\\"{x:623,y:598,t:1526930408190};\\\", \\\"{x:620,y:592,t:1526930408207};\\\", \\\"{x:620,y:589,t:1526930408224};\\\", \\\"{x:618,y:588,t:1526930408240};\\\", \\\"{x:618,y:586,t:1526930408257};\\\", \\\"{x:616,y:585,t:1526930408274};\\\", \\\"{x:612,y:584,t:1526930408290};\\\", \\\"{x:609,y:582,t:1526930408307};\\\", \\\"{x:606,y:581,t:1526930408324};\\\", \\\"{x:605,y:581,t:1526930408340};\\\", \\\"{x:608,y:588,t:1526930408751};\\\", \\\"{x:612,y:596,t:1526930408758};\\\", \\\"{x:616,y:604,t:1526930408775};\\\", \\\"{x:622,y:629,t:1526930408790};\\\", \\\"{x:624,y:639,t:1526930408808};\\\", \\\"{x:626,y:643,t:1526930408823};\\\", \\\"{x:626,y:645,t:1526930408841};\\\", \\\"{x:626,y:646,t:1526930408935};\\\", \\\"{x:626,y:648,t:1526930408943};\\\", \\\"{x:626,y:649,t:1526930408957};\\\", \\\"{x:625,y:653,t:1526930408974};\\\", \\\"{x:618,y:657,t:1526930408990};\\\", \\\"{x:616,y:661,t:1526930409007};\\\", \\\"{x:615,y:662,t:1526930409023};\\\", \\\"{x:614,y:663,t:1526930409087};\\\", \\\"{x:613,y:663,t:1526930409127};\\\", \\\"{x:609,y:664,t:1526930410376};\\\", \\\"{x:596,y:670,t:1526930410391};\\\", \\\"{x:584,y:674,t:1526930410408};\\\", \\\"{x:575,y:676,t:1526930410424};\\\", \\\"{x:564,y:680,t:1526930410442};\\\", \\\"{x:553,y:684,t:1526930410458};\\\", \\\"{x:542,y:689,t:1526930410475};\\\", \\\"{x:532,y:695,t:1526930410491};\\\", \\\"{x:527,y:701,t:1526930410508};\\\", \\\"{x:525,y:705,t:1526930410525};\\\", \\\"{x:524,y:709,t:1526930410541};\\\", \\\"{x:524,y:712,t:1526930410559};\\\", \\\"{x:524,y:713,t:1526930410574};\\\", \\\"{x:524,y:715,t:1526930410592};\\\", \\\"{x:524,y:716,t:1526930410671};\\\", \\\"{x:525,y:718,t:1526930410712};\\\", \\\"{x:525,y:719,t:1526930410725};\\\", \\\"{x:526,y:723,t:1526930410742};\\\", \\\"{x:526,y:729,t:1526930410758};\\\", \\\"{x:528,y:738,t:1526930410774};\\\", \\\"{x:528,y:739,t:1526930410790};\\\", \\\"{x:528,y:741,t:1526930410806};\\\", \\\"{x:528,y:743,t:1526930410823};\\\", \\\"{x:529,y:745,t:1526930410840};\\\", \\\"{x:529,y:746,t:1526930411064};\\\", \\\"{x:527,y:746,t:1526930411095};\\\" ] }, { \\\"rt\\\": 14926, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 19, \\\"time_elapsed\\\": 789085, \\\"internal_node_id\\\": \\\"0.0-6.0-9.0\\\", \\\"subject\\\": \\\"WKBNA\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 15, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"K\\\", \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-I -X -X -02 PM-X -X \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:527,y:745,t:1526930412974};\\\", \\\"{x:527,y:744,t:1526930413119};\\\", \\\"{x:527,y:742,t:1526930413151};\\\", \\\"{x:529,y:741,t:1526930413161};\\\", \\\"{x:530,y:740,t:1526930413178};\\\", \\\"{x:534,y:736,t:1526930413195};\\\", \\\"{x:537,y:735,t:1526930413211};\\\", \\\"{x:538,y:734,t:1526930413228};\\\", \\\"{x:540,y:733,t:1526930413246};\\\", \\\"{x:541,y:733,t:1526930413261};\\\", \\\"{x:543,y:733,t:1526930413286};\\\", \\\"{x:544,y:733,t:1526930413294};\\\", \\\"{x:546,y:733,t:1526930413310};\\\", \\\"{x:548,y:734,t:1526930413328};\\\", \\\"{x:550,y:734,t:1526930413441};\\\", \\\"{x:552,y:735,t:1526930413519};\\\", \\\"{x:554,y:737,t:1526930413528};\\\", \\\"{x:556,y:739,t:1526930413544};\\\", \\\"{x:559,y:740,t:1526930413561};\\\", \\\"{x:565,y:741,t:1526930413578};\\\", \\\"{x:571,y:741,t:1526930413594};\\\", \\\"{x:577,y:741,t:1526930413610};\\\", \\\"{x:583,y:741,t:1526930413628};\\\", \\\"{x:591,y:740,t:1526930413644};\\\", \\\"{x:602,y:739,t:1526930413661};\\\", \\\"{x:616,y:738,t:1526930413678};\\\", \\\"{x:638,y:738,t:1526930413694};\\\", \\\"{x:679,y:741,t:1526930413711};\\\", \\\"{x:707,y:747,t:1526930413728};\\\", \\\"{x:732,y:753,t:1526930413744};\\\", \\\"{x:766,y:761,t:1526930413761};\\\", \\\"{x:792,y:768,t:1526930413778};\\\", \\\"{x:821,y:770,t:1526930413794};\\\", \\\"{x:848,y:770,t:1526930413811};\\\", \\\"{x:858,y:771,t:1526930413828};\\\", \\\"{x:865,y:770,t:1526930413844};\\\", \\\"{x:866,y:770,t:1526930413861};\\\", \\\"{x:870,y:765,t:1526930414527};\\\", \\\"{x:923,y:752,t:1526930414546};\\\", \\\"{x:990,y:750,t:1526930414562};\\\", \\\"{x:1057,y:750,t:1526930414578};\\\", \\\"{x:1116,y:750,t:1526930414596};\\\", \\\"{x:1185,y:759,t:1526930414615};\\\", \\\"{x:1253,y:773,t:1526930414628};\\\", \\\"{x:1315,y:790,t:1526930414646};\\\", \\\"{x:1378,y:799,t:1526930414661};\\\", \\\"{x:1432,y:808,t:1526930414678};\\\", \\\"{x:1479,y:809,t:1526930414695};\\\", \\\"{x:1504,y:809,t:1526930414711};\\\", \\\"{x:1525,y:805,t:1526930414728};\\\", \\\"{x:1536,y:799,t:1526930414745};\\\", \\\"{x:1546,y:788,t:1526930414761};\\\", \\\"{x:1552,y:776,t:1526930414778};\\\", \\\"{x:1554,y:768,t:1526930414795};\\\", \\\"{x:1555,y:764,t:1526930414811};\\\", \\\"{x:1555,y:759,t:1526930414828};\\\", \\\"{x:1555,y:752,t:1526930414845};\\\", \\\"{x:1554,y:746,t:1526930414861};\\\", \\\"{x:1546,y:738,t:1526930414878};\\\", \\\"{x:1528,y:725,t:1526930414895};\\\", \\\"{x:1513,y:714,t:1526930414912};\\\", \\\"{x:1497,y:703,t:1526930414928};\\\", \\\"{x:1477,y:692,t:1526930414946};\\\", \\\"{x:1440,y:670,t:1526930414961};\\\", \\\"{x:1384,y:645,t:1526930414978};\\\", \\\"{x:1330,y:624,t:1526930414995};\\\", \\\"{x:1285,y:610,t:1526930415011};\\\", \\\"{x:1268,y:605,t:1526930415029};\\\", \\\"{x:1259,y:605,t:1526930415045};\\\", \\\"{x:1255,y:605,t:1526930415061};\\\", \\\"{x:1254,y:605,t:1526930415311};\\\", \\\"{x:1262,y:608,t:1526930415329};\\\", \\\"{x:1291,y:617,t:1526930415346};\\\", \\\"{x:1330,y:635,t:1526930415362};\\\", \\\"{x:1358,y:646,t:1526930415379};\\\", \\\"{x:1373,y:650,t:1526930415396};\\\", \\\"{x:1375,y:651,t:1526930415411};\\\", \\\"{x:1377,y:651,t:1526930415429};\\\", \\\"{x:1379,y:651,t:1526930415446};\\\", \\\"{x:1380,y:652,t:1526930415496};\\\", \\\"{x:1381,y:653,t:1526930415511};\\\", \\\"{x:1383,y:656,t:1526930415528};\\\", \\\"{x:1384,y:659,t:1526930415546};\\\", \\\"{x:1385,y:660,t:1526930415562};\\\", \\\"{x:1387,y:661,t:1526930415887};\\\", \\\"{x:1390,y:661,t:1526930415895};\\\", \\\"{x:1392,y:661,t:1526930415936};\\\", \\\"{x:1393,y:663,t:1526930415946};\\\", \\\"{x:1397,y:664,t:1526930415963};\\\", \\\"{x:1401,y:667,t:1526930415979};\\\", \\\"{x:1408,y:672,t:1526930415996};\\\", \\\"{x:1420,y:677,t:1526930416013};\\\", \\\"{x:1435,y:683,t:1526930416028};\\\", \\\"{x:1446,y:684,t:1526930416046};\\\", \\\"{x:1458,y:684,t:1526930416063};\\\", \\\"{x:1461,y:684,t:1526930416079};\\\", \\\"{x:1471,y:682,t:1526930416095};\\\", \\\"{x:1475,y:680,t:1526930416113};\\\", \\\"{x:1478,y:679,t:1526930416129};\\\", \\\"{x:1480,y:679,t:1526930416146};\\\", \\\"{x:1482,y:679,t:1526930416163};\\\", \\\"{x:1486,y:679,t:1526930416179};\\\", \\\"{x:1489,y:679,t:1526930416195};\\\", \\\"{x:1490,y:679,t:1526930416213};\\\", \\\"{x:1492,y:679,t:1526930416229};\\\", \\\"{x:1493,y:679,t:1526930416320};\\\", \\\"{x:1496,y:682,t:1526930416351};\\\", \\\"{x:1497,y:688,t:1526930416363};\\\", \\\"{x:1498,y:709,t:1526930416378};\\\", \\\"{x:1498,y:736,t:1526930416396};\\\", \\\"{x:1498,y:767,t:1526930416413};\\\", \\\"{x:1498,y:794,t:1526930416429};\\\", \\\"{x:1498,y:815,t:1526930416446};\\\", \\\"{x:1501,y:844,t:1526930416463};\\\", \\\"{x:1502,y:853,t:1526930416479};\\\", \\\"{x:1502,y:856,t:1526930416496};\\\", \\\"{x:1502,y:859,t:1526930416513};\\\", \\\"{x:1502,y:860,t:1526930416529};\\\", \\\"{x:1501,y:863,t:1526930416546};\\\", \\\"{x:1498,y:868,t:1526930416563};\\\", \\\"{x:1494,y:872,t:1526930416579};\\\", \\\"{x:1486,y:881,t:1526930416596};\\\", \\\"{x:1477,y:888,t:1526930416613};\\\", \\\"{x:1469,y:896,t:1526930416629};\\\", \\\"{x:1460,y:906,t:1526930416646};\\\", \\\"{x:1451,y:923,t:1526930416663};\\\", \\\"{x:1448,y:932,t:1526930416680};\\\", \\\"{x:1445,y:944,t:1526930416695};\\\", \\\"{x:1444,y:952,t:1526930416713};\\\", \\\"{x:1445,y:960,t:1526930416729};\\\", \\\"{x:1449,y:966,t:1526930416746};\\\", \\\"{x:1453,y:969,t:1526930416763};\\\", \\\"{x:1456,y:969,t:1526930416778};\\\", \\\"{x:1460,y:970,t:1526930416796};\\\", \\\"{x:1461,y:971,t:1526930416813};\\\", \\\"{x:1461,y:972,t:1526930416871};\\\", \\\"{x:1461,y:973,t:1526930416879};\\\", \\\"{x:1461,y:974,t:1526930416903};\\\", \\\"{x:1461,y:971,t:1526930416968};\\\", \\\"{x:1461,y:968,t:1526930416978};\\\", \\\"{x:1461,y:964,t:1526930416996};\\\", \\\"{x:1461,y:963,t:1526930417013};\\\", \\\"{x:1461,y:962,t:1526930417030};\\\", \\\"{x:1461,y:961,t:1526930417046};\\\", \\\"{x:1462,y:960,t:1526930417062};\\\", \\\"{x:1463,y:960,t:1526930417080};\\\", \\\"{x:1468,y:961,t:1526930417095};\\\", \\\"{x:1470,y:963,t:1526930417113};\\\", \\\"{x:1473,y:966,t:1526930417131};\\\", \\\"{x:1475,y:967,t:1526930417145};\\\", \\\"{x:1476,y:967,t:1526930417240};\\\", \\\"{x:1476,y:966,t:1526930417279};\\\", \\\"{x:1476,y:965,t:1526930417424};\\\", \\\"{x:1476,y:963,t:1526930417440};\\\", \\\"{x:1475,y:961,t:1526930417448};\\\", \\\"{x:1475,y:960,t:1526930417471};\\\", \\\"{x:1476,y:960,t:1526930417704};\\\", \\\"{x:1476,y:961,t:1526930417719};\\\", \\\"{x:1477,y:961,t:1526930417730};\\\", \\\"{x:1477,y:962,t:1526930417746};\\\", \\\"{x:1477,y:959,t:1526930418040};\\\", \\\"{x:1476,y:954,t:1526930418047};\\\", \\\"{x:1475,y:946,t:1526930418062};\\\", \\\"{x:1475,y:937,t:1526930418077};\\\", \\\"{x:1473,y:934,t:1526930418094};\\\", \\\"{x:1473,y:932,t:1526930418110};\\\", \\\"{x:1473,y:930,t:1526930418127};\\\", \\\"{x:1473,y:929,t:1526930418144};\\\", \\\"{x:1473,y:926,t:1526930418204};\\\", \\\"{x:1472,y:925,t:1526930418211};\\\", \\\"{x:1472,y:923,t:1526930418228};\\\", \\\"{x:1471,y:917,t:1526930418244};\\\", \\\"{x:1469,y:911,t:1526930418260};\\\", \\\"{x:1468,y:905,t:1526930418277};\\\", \\\"{x:1467,y:901,t:1526930418294};\\\", \\\"{x:1466,y:899,t:1526930418310};\\\", \\\"{x:1465,y:897,t:1526930418327};\\\", \\\"{x:1465,y:896,t:1526930418405};\\\", \\\"{x:1465,y:895,t:1526930418429};\\\", \\\"{x:1465,y:894,t:1526930418444};\\\", \\\"{x:1465,y:891,t:1526930418460};\\\", \\\"{x:1465,y:887,t:1526930418477};\\\", \\\"{x:1466,y:883,t:1526930418494};\\\", \\\"{x:1466,y:879,t:1526930418511};\\\", \\\"{x:1466,y:877,t:1526930418528};\\\", \\\"{x:1467,y:875,t:1526930418702};\\\", \\\"{x:1469,y:872,t:1526930418711};\\\", \\\"{x:1471,y:869,t:1526930418727};\\\", \\\"{x:1473,y:866,t:1526930418745};\\\", \\\"{x:1474,y:864,t:1526930418760};\\\", \\\"{x:1474,y:863,t:1526930418778};\\\", \\\"{x:1474,y:862,t:1526930418795};\\\", \\\"{x:1476,y:859,t:1526930418917};\\\", \\\"{x:1477,y:854,t:1526930418928};\\\", \\\"{x:1478,y:848,t:1526930418945};\\\", \\\"{x:1480,y:843,t:1526930418961};\\\", \\\"{x:1481,y:841,t:1526930418978};\\\", \\\"{x:1481,y:840,t:1526930418995};\\\", \\\"{x:1481,y:839,t:1526930419190};\\\", \\\"{x:1481,y:840,t:1526930419293};\\\", \\\"{x:1481,y:842,t:1526930419309};\\\", \\\"{x:1481,y:843,t:1526930419318};\\\", \\\"{x:1482,y:844,t:1526930419333};\\\", \\\"{x:1483,y:842,t:1526930419597};\\\", \\\"{x:1483,y:840,t:1526930419612};\\\", \\\"{x:1483,y:838,t:1526930419628};\\\", \\\"{x:1484,y:836,t:1526930419645};\\\", \\\"{x:1484,y:835,t:1526930419661};\\\", \\\"{x:1484,y:834,t:1526930419862};\\\", \\\"{x:1484,y:832,t:1526930419877};\\\", \\\"{x:1484,y:830,t:1526930419917};\\\", \\\"{x:1484,y:829,t:1526930420062};\\\", \\\"{x:1484,y:825,t:1526930420078};\\\", \\\"{x:1484,y:822,t:1526930420095};\\\", \\\"{x:1484,y:821,t:1526930420294};\\\", \\\"{x:1483,y:819,t:1526930420301};\\\", \\\"{x:1479,y:817,t:1526930420312};\\\", \\\"{x:1471,y:814,t:1526930420329};\\\", \\\"{x:1467,y:812,t:1526930420345};\\\", \\\"{x:1468,y:812,t:1526930420590};\\\", \\\"{x:1470,y:815,t:1526930420597};\\\", \\\"{x:1472,y:820,t:1526930420612};\\\", \\\"{x:1480,y:839,t:1526930420629};\\\", \\\"{x:1486,y:852,t:1526930420645};\\\", \\\"{x:1490,y:861,t:1526930420661};\\\", \\\"{x:1491,y:867,t:1526930420679};\\\", \\\"{x:1492,y:868,t:1526930420695};\\\", \\\"{x:1488,y:866,t:1526930420757};\\\", \\\"{x:1478,y:860,t:1526930420765};\\\", \\\"{x:1468,y:852,t:1526930420779};\\\", \\\"{x:1427,y:828,t:1526930420795};\\\", \\\"{x:1365,y:810,t:1526930420812};\\\", \\\"{x:1243,y:789,t:1526930420829};\\\", \\\"{x:1157,y:776,t:1526930420844};\\\", \\\"{x:1078,y:773,t:1526930420861};\\\", \\\"{x:1000,y:771,t:1526930420879};\\\", \\\"{x:922,y:771,t:1526930420895};\\\", \\\"{x:861,y:771,t:1526930420911};\\\", \\\"{x:783,y:771,t:1526930420928};\\\", \\\"{x:756,y:771,t:1526930420944};\\\", \\\"{x:733,y:771,t:1526930420962};\\\", \\\"{x:715,y:769,t:1526930420978};\\\", \\\"{x:704,y:766,t:1526930420994};\\\", \\\"{x:698,y:762,t:1526930421012};\\\", \\\"{x:686,y:757,t:1526930421029};\\\", \\\"{x:671,y:750,t:1526930421044};\\\", \\\"{x:663,y:748,t:1526930421061};\\\", \\\"{x:658,y:745,t:1526930421079};\\\", \\\"{x:657,y:744,t:1526930421094};\\\", \\\"{x:655,y:739,t:1526930421111};\\\", \\\"{x:651,y:728,t:1526930421128};\\\", \\\"{x:643,y:711,t:1526930421145};\\\", \\\"{x:633,y:685,t:1526930421162};\\\", \\\"{x:625,y:664,t:1526930421179};\\\", \\\"{x:619,y:644,t:1526930421195};\\\", \\\"{x:615,y:631,t:1526930421212};\\\", \\\"{x:612,y:620,t:1526930421227};\\\", \\\"{x:610,y:599,t:1526930421250};\\\", \\\"{x:609,y:583,t:1526930421265};\\\", \\\"{x:609,y:576,t:1526930421283};\\\", \\\"{x:609,y:575,t:1526930421300};\\\", \\\"{x:611,y:574,t:1526930421469};\\\", \\\"{x:613,y:574,t:1526930421485};\\\", \\\"{x:616,y:575,t:1526930421499};\\\", \\\"{x:620,y:579,t:1526930421517};\\\", \\\"{x:623,y:583,t:1526930421533};\\\", \\\"{x:623,y:585,t:1526930421550};\\\", \\\"{x:623,y:587,t:1526930421740};\\\", \\\"{x:623,y:588,t:1526930421750};\\\", \\\"{x:623,y:591,t:1526930421766};\\\", \\\"{x:623,y:594,t:1526930421782};\\\", \\\"{x:623,y:595,t:1526930421805};\\\", \\\"{x:622,y:597,t:1526930422229};\\\", \\\"{x:620,y:598,t:1526930422237};\\\", \\\"{x:618,y:600,t:1526930422249};\\\", \\\"{x:614,y:602,t:1526930422266};\\\", \\\"{x:610,y:603,t:1526930422283};\\\", \\\"{x:603,y:603,t:1526930422299};\\\", \\\"{x:590,y:603,t:1526930422317};\\\", \\\"{x:583,y:600,t:1526930422333};\\\", \\\"{x:567,y:596,t:1526930422349};\\\", \\\"{x:555,y:593,t:1526930422366};\\\", \\\"{x:541,y:593,t:1526930422383};\\\", \\\"{x:529,y:593,t:1526930422399};\\\", \\\"{x:518,y:593,t:1526930422416};\\\", \\\"{x:507,y:597,t:1526930422433};\\\", \\\"{x:500,y:601,t:1526930422449};\\\", \\\"{x:496,y:602,t:1526930422468};\\\", \\\"{x:491,y:605,t:1526930422483};\\\", \\\"{x:488,y:606,t:1526930422499};\\\", \\\"{x:486,y:606,t:1526930422516};\\\", \\\"{x:485,y:606,t:1526930422533};\\\", \\\"{x:483,y:606,t:1526930422549};\\\", \\\"{x:478,y:606,t:1526930422566};\\\", \\\"{x:473,y:605,t:1526930422584};\\\", \\\"{x:464,y:605,t:1526930422600};\\\", \\\"{x:453,y:605,t:1526930422617};\\\", \\\"{x:442,y:605,t:1526930422633};\\\", \\\"{x:428,y:606,t:1526930422650};\\\", \\\"{x:418,y:607,t:1526930422667};\\\", \\\"{x:410,y:607,t:1526930422683};\\\", \\\"{x:397,y:607,t:1526930422701};\\\", \\\"{x:393,y:607,t:1526930422716};\\\", \\\"{x:390,y:607,t:1526930422733};\\\", \\\"{x:389,y:607,t:1526930422751};\\\", \\\"{x:386,y:603,t:1526930422767};\\\", \\\"{x:385,y:598,t:1526930422783};\\\", \\\"{x:382,y:596,t:1526930422800};\\\", \\\"{x:381,y:593,t:1526930422816};\\\", \\\"{x:380,y:592,t:1526930422834};\\\", \\\"{x:381,y:592,t:1526930423260};\\\", \\\"{x:383,y:591,t:1526930423268};\\\", \\\"{x:385,y:591,t:1526930423421};\\\", \\\"{x:390,y:591,t:1526930423435};\\\", \\\"{x:413,y:591,t:1526930423451};\\\", \\\"{x:460,y:591,t:1526930423469};\\\", \\\"{x:618,y:591,t:1526930423485};\\\", \\\"{x:760,y:594,t:1526930423501};\\\", \\\"{x:901,y:613,t:1526930423518};\\\", \\\"{x:1032,y:639,t:1526930423534};\\\", \\\"{x:1154,y:677,t:1526930423550};\\\", \\\"{x:1277,y:721,t:1526930423568};\\\", \\\"{x:1384,y:767,t:1526930423584};\\\", \\\"{x:1492,y:812,t:1526930423601};\\\", \\\"{x:1586,y:858,t:1526930423618};\\\", \\\"{x:1660,y:900,t:1526930423634};\\\", \\\"{x:1700,y:922,t:1526930423652};\\\", \\\"{x:1709,y:927,t:1526930423667};\\\", \\\"{x:1709,y:928,t:1526930423741};\\\", \\\"{x:1708,y:930,t:1526930423752};\\\", \\\"{x:1705,y:934,t:1526930423769};\\\", \\\"{x:1703,y:940,t:1526930423785};\\\", \\\"{x:1699,y:946,t:1526930423802};\\\", \\\"{x:1696,y:949,t:1526930423819};\\\", \\\"{x:1690,y:954,t:1526930423834};\\\", \\\"{x:1682,y:956,t:1526930423852};\\\", \\\"{x:1665,y:956,t:1526930423868};\\\", \\\"{x:1656,y:956,t:1526930423885};\\\", \\\"{x:1648,y:955,t:1526930423901};\\\", \\\"{x:1637,y:954,t:1526930423919};\\\", \\\"{x:1628,y:951,t:1526930423936};\\\", \\\"{x:1619,y:949,t:1526930423951};\\\", \\\"{x:1612,y:946,t:1526930423969};\\\", \\\"{x:1605,y:946,t:1526930423986};\\\", \\\"{x:1600,y:946,t:1526930424003};\\\", \\\"{x:1592,y:947,t:1526930424018};\\\", \\\"{x:1589,y:950,t:1526930424036};\\\", \\\"{x:1580,y:954,t:1526930424053};\\\", \\\"{x:1567,y:957,t:1526930424068};\\\", \\\"{x:1548,y:962,t:1526930424086};\\\", \\\"{x:1534,y:965,t:1526930424103};\\\", \\\"{x:1523,y:965,t:1526930424119};\\\", \\\"{x:1517,y:965,t:1526930424136};\\\", \\\"{x:1513,y:965,t:1526930424153};\\\", \\\"{x:1508,y:965,t:1526930424170};\\\", \\\"{x:1506,y:965,t:1526930424186};\\\", \\\"{x:1505,y:965,t:1526930424203};\\\", \\\"{x:1504,y:965,t:1526930424220};\\\", \\\"{x:1503,y:965,t:1526930424236};\\\", \\\"{x:1499,y:967,t:1526930424253};\\\", \\\"{x:1499,y:968,t:1526930424270};\\\", \\\"{x:1497,y:970,t:1526930424287};\\\", \\\"{x:1496,y:971,t:1526930424303};\\\", \\\"{x:1492,y:970,t:1526930424366};\\\", \\\"{x:1489,y:967,t:1526930424374};\\\", \\\"{x:1487,y:963,t:1526930424387};\\\", \\\"{x:1481,y:958,t:1526930424403};\\\", \\\"{x:1476,y:956,t:1526930424420};\\\", \\\"{x:1467,y:952,t:1526930424437};\\\", \\\"{x:1465,y:950,t:1526930424454};\\\", \\\"{x:1464,y:950,t:1526930424582};\\\", \\\"{x:1464,y:948,t:1526930424589};\\\", \\\"{x:1464,y:946,t:1526930424604};\\\", \\\"{x:1464,y:941,t:1526930424621};\\\", \\\"{x:1464,y:939,t:1526930424638};\\\", \\\"{x:1464,y:937,t:1526930424654};\\\", \\\"{x:1464,y:936,t:1526930424718};\\\", \\\"{x:1466,y:937,t:1526930424725};\\\", \\\"{x:1468,y:938,t:1526930424738};\\\", \\\"{x:1473,y:942,t:1526930424754};\\\", \\\"{x:1477,y:946,t:1526930424771};\\\", \\\"{x:1481,y:949,t:1526930424788};\\\", \\\"{x:1483,y:949,t:1526930424805};\\\", \\\"{x:1484,y:948,t:1526930424821};\\\", \\\"{x:1485,y:946,t:1526930424839};\\\", \\\"{x:1485,y:943,t:1526930424855};\\\", \\\"{x:1486,y:942,t:1526930424871};\\\", \\\"{x:1486,y:939,t:1526930425006};\\\", \\\"{x:1485,y:928,t:1526930425022};\\\", \\\"{x:1482,y:913,t:1526930425039};\\\", \\\"{x:1480,y:897,t:1526930425056};\\\", \\\"{x:1479,y:884,t:1526930425072};\\\", \\\"{x:1479,y:874,t:1526930425089};\\\", \\\"{x:1479,y:864,t:1526930425105};\\\", \\\"{x:1477,y:855,t:1526930425122};\\\", \\\"{x:1477,y:848,t:1526930425139};\\\", \\\"{x:1477,y:844,t:1526930425156};\\\", \\\"{x:1477,y:840,t:1526930425172};\\\", \\\"{x:1477,y:836,t:1526930425189};\\\", \\\"{x:1477,y:830,t:1526930425207};\\\", \\\"{x:1477,y:823,t:1526930425222};\\\", \\\"{x:1477,y:812,t:1526930425239};\\\", \\\"{x:1477,y:795,t:1526930425257};\\\", \\\"{x:1477,y:778,t:1526930425273};\\\", \\\"{x:1477,y:765,t:1526930425289};\\\", \\\"{x:1477,y:757,t:1526930425306};\\\", \\\"{x:1477,y:748,t:1526930425324};\\\", \\\"{x:1477,y:740,t:1526930425339};\\\", \\\"{x:1477,y:730,t:1526930425357};\\\", \\\"{x:1479,y:709,t:1526930425373};\\\", \\\"{x:1481,y:696,t:1526930425388};\\\", \\\"{x:1481,y:687,t:1526930425405};\\\", \\\"{x:1481,y:684,t:1526930425422};\\\", \\\"{x:1481,y:671,t:1526930425440};\\\", \\\"{x:1477,y:649,t:1526930425455};\\\", \\\"{x:1474,y:620,t:1526930425472};\\\", \\\"{x:1471,y:588,t:1526930425490};\\\", \\\"{x:1470,y:554,t:1526930425505};\\\", \\\"{x:1465,y:525,t:1526930425522};\\\", \\\"{x:1462,y:499,t:1526930425539};\\\", \\\"{x:1457,y:468,t:1526930425556};\\\", \\\"{x:1454,y:451,t:1526930425573};\\\", \\\"{x:1453,y:439,t:1526930425590};\\\", \\\"{x:1453,y:433,t:1526930425607};\\\", \\\"{x:1453,y:428,t:1526930425622};\\\", \\\"{x:1454,y:423,t:1526930425640};\\\", \\\"{x:1455,y:418,t:1526930425657};\\\", \\\"{x:1458,y:411,t:1526930425674};\\\", \\\"{x:1462,y:395,t:1526930425690};\\\", \\\"{x:1465,y:379,t:1526930425706};\\\", \\\"{x:1470,y:356,t:1526930425724};\\\", \\\"{x:1473,y:331,t:1526930425739};\\\", \\\"{x:1474,y:304,t:1526930425757};\\\", \\\"{x:1474,y:290,t:1526930425775};\\\", \\\"{x:1474,y:285,t:1526930425790};\\\", \\\"{x:1474,y:282,t:1526930425808};\\\", \\\"{x:1475,y:281,t:1526930425825};\\\", \\\"{x:1475,y:280,t:1526930425989};\\\", \\\"{x:1471,y:280,t:1526930426005};\\\", \\\"{x:1456,y:283,t:1526930426013};\\\", \\\"{x:1434,y:289,t:1526930426024};\\\", \\\"{x:1364,y:315,t:1526930426041};\\\", \\\"{x:1263,y:349,t:1526930426058};\\\", \\\"{x:1163,y:381,t:1526930426075};\\\", \\\"{x:1049,y:414,t:1526930426091};\\\", \\\"{x:922,y:445,t:1526930426108};\\\", \\\"{x:734,y:503,t:1526930426127};\\\", \\\"{x:625,y:537,t:1526930426141};\\\", \\\"{x:570,y:556,t:1526930426154};\\\", \\\"{x:474,y:590,t:1526930426169};\\\", \\\"{x:390,y:633,t:1526930426186};\\\", \\\"{x:327,y:672,t:1526930426205};\\\", \\\"{x:285,y:715,t:1526930426220};\\\", \\\"{x:256,y:775,t:1526930426237};\\\", \\\"{x:254,y:785,t:1526930426253};\\\", \\\"{x:254,y:790,t:1526930426269};\\\", \\\"{x:257,y:799,t:1526930426286};\\\", \\\"{x:265,y:810,t:1526930426302};\\\", \\\"{x:272,y:817,t:1526930426320};\\\", \\\"{x:280,y:823,t:1526930426336};\\\", \\\"{x:296,y:828,t:1526930426353};\\\", \\\"{x:319,y:828,t:1526930426369};\\\", \\\"{x:347,y:828,t:1526930426386};\\\", \\\"{x:404,y:812,t:1526930426404};\\\", \\\"{x:470,y:783,t:1526930426420};\\\", \\\"{x:547,y:748,t:1526930426437};\\\", \\\"{x:569,y:739,t:1526930426454};\\\", \\\"{x:577,y:735,t:1526930426470};\\\", \\\"{x:578,y:735,t:1526930426486};\\\", \\\"{x:579,y:735,t:1526930426516};\\\", \\\"{x:579,y:734,t:1526930426598};\\\", \\\"{x:578,y:730,t:1526930426605};\\\", \\\"{x:576,y:727,t:1526930426620};\\\", \\\"{x:570,y:719,t:1526930426636};\\\", \\\"{x:565,y:716,t:1526930426653};\\\", \\\"{x:562,y:713,t:1526930426670};\\\", \\\"{x:561,y:713,t:1526930426700};\\\", \\\"{x:559,y:714,t:1526930426741};\\\", \\\"{x:559,y:715,t:1526930426753};\\\", \\\"{x:558,y:720,t:1526930426771};\\\", \\\"{x:554,y:725,t:1526930426787};\\\", \\\"{x:552,y:729,t:1526930426803};\\\", \\\"{x:550,y:732,t:1526930426820};\\\", \\\"{x:549,y:733,t:1526930426835};\\\", \\\"{x:548,y:734,t:1526930426932};\\\", \\\"{x:548,y:735,t:1526930426948};\\\", \\\"{x:548,y:736,t:1526930426956};\\\", \\\"{x:547,y:739,t:1526930426971};\\\", \\\"{x:544,y:743,t:1526930426986};\\\", \\\"{x:542,y:748,t:1526930427003};\\\", \\\"{x:537,y:754,t:1526930427020};\\\", \\\"{x:535,y:756,t:1526930427036};\\\", \\\"{x:532,y:756,t:1526930427053};\\\", \\\"{x:531,y:756,t:1526930427293};\\\", \\\"{x:529,y:756,t:1526930427304};\\\", \\\"{x:526,y:754,t:1526930427321};\\\", \\\"{x:522,y:750,t:1526930427338};\\\", \\\"{x:518,y:747,t:1526930427354};\\\", \\\"{x:513,y:743,t:1526930427371};\\\", \\\"{x:512,y:743,t:1526930427388};\\\", \\\"{x:511,y:743,t:1526930427437};\\\", \\\"{x:508,y:743,t:1526930427454};\\\", \\\"{x:506,y:743,t:1526930427477};\\\", \\\"{x:522,y:744,t:1526930428389};\\\", \\\"{x:652,y:744,t:1526930428405};\\\", \\\"{x:676,y:746,t:1526930428422};\\\", \\\"{x:673,y:749,t:1526930428438};\\\", \\\"{x:660,y:747,t:1526930428455};\\\", \\\"{x:655,y:744,t:1526930428472};\\\", \\\"{x:651,y:741,t:1526930428488};\\\", \\\"{x:647,y:738,t:1526930428505};\\\", \\\"{x:642,y:735,t:1526930428522};\\\", \\\"{x:641,y:735,t:1526930428539};\\\" ] }, { \\\"rt\\\": 61980, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 20, \\\"time_elapsed\\\": 852278, \\\"internal_node_id\\\": \\\"0.0-7.0-0.0\\\", \\\"subject\\\": \\\"WKBNA\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\", \\\"q\\\": 16, \\\"answer\\\": \\\"Start at 12 PM on the horizontal axis, and then follow the line angled toward the right. \\\", \\\"block\\\": \\\"triangular_testing\\\" }, { \\\"rt\\\": 7102, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"19\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"United States\\\\\\\"}\\\", \\\"block\\\": \\\"demo-1\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 21, \\\"time_elapsed\\\": 860388, \\\"internal_node_id\\\": \\\"0.0-8.0\\\", \\\"subject\\\": \\\"WKBNA\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\" }, { \\\"rt\\\": 22362, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"English\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"Second\\\\\\\",\\\\\\\"Q2\\\\\\\":\\\\\\\"Social Sciences (incl. CogSci)\\\\\\\",\\\\\\\"Q3\\\\\\\":\\\\\\\"Female\\\\\\\"}\\\", \\\"block\\\": \\\"demo-2\\\", \\\"trial_type\\\": \\\"survey-multi-choice\\\", \\\"trial_index\\\": 22, \\\"time_elapsed\\\": 883767, \\\"internal_node_id\\\": \\\"0.0-9.0\\\", \\\"subject\\\": \\\"WKBNA\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\" }, { \\\"rt\\\": 53859, \\\"url\\\": \\\"../views/src/external/debrief.html\\\", \\\"block\\\": \\\"debrief\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 23, \\\"time_elapsed\\\": 938943, \\\"internal_node_id\\\": \\\"0.0-10.0\\\", \\\"subject\\\": \\\"WKBNA\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\" } ]\",\"parentNode\":{\"id\":2765}}],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"META\",\"attributes\":{\"charset\":\"utf-8\"}},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":8,\"id\":59},{\"nodeType\":3,\"id\":60,\"textContent\":\" \"},{\"nodeType\":1,\"id\":61,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":62,\"textContent\":\" \"},{\"nodeType\":1,\"id\":63,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":64,\"textContent\":\" \"},{\"nodeType\":1,\"id\":65,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":66,\"textContent\":\" \"},{\"nodeType\":1,\"id\":67,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":68,\"textContent\":\" \"},{\"nodeType\":1,\"id\":69,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":70,\"textContent\":\" \"},{\"nodeType\":1,\"id\":71,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":72,\"textContent\":\" \"},{\"nodeType\":1,\"id\":73,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"stimulus\"},\"childNodes\":[{\"nodeType\":3,\"id\":74,\"textContent\":\" \"},{\"nodeType\":1,\"id\":75,\"tagName\":\"P\",\"attributes\":{\"class\":\"userid\",\"id\":\"userid\"},\"childNodes\":[{\"nodeType\":3,\"id\":76,\"textContent\":\"WKBNA\"}]},{\"nodeType\":3,\"id\":77,\"textContent\":\" \"},{\"nodeType\":1,\"id\":78,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"userinput\"},\"childNodes\":[{\"nodeType\":3,\"id\":79,\"textContent\":\" \"},{\"nodeType\":8,\"id\":80},{\"nodeType\":3,\"id\":81,\"textContent\":\" \"},{\"nodeType\":1,\"id\":82,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"legend\",\"id\":\"hint-interactive\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":83,\"textContent\":\" \"},{\"nodeType\":1,\"id\":84,\"tagName\":\"P\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":85,\"textContent\":\"Hint: Hover your mouse over the data points in the graph\"}]},{\"nodeType\":3,\"id\":86,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":87,\"textContent\":\" \"},{\"nodeType\":8,\"id\":88},{\"nodeType\":3,\"id\":89,\"textContent\":\" \"},{\"nodeType\":8,\"id\":90},{\"nodeType\":3,\"id\":91,\"textContent\":\" \"},{\"nodeType\":1,\"id\":92,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"test\"},\"childNodes\":[{\"nodeType\":3,\"id\":93,\"textContent\":\" \"},{\"nodeType\":1,\"id\":94,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":95,\"textContent\":\" \"},{\"nodeType\":1,\"id\":96,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":97,\"textContent\":\"Which shift(s) start at 11 am? \"}]},{\"nodeType\":3,\"id\":98,\"textContent\":\" \"},{\"nodeType\":1,\"id\":99,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":100,\"textContent\":\" \"},{\"nodeType\":1,\"id\":101,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":102,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":103,\"textContent\":\" \"},{\"nodeType\":1,\"id\":104,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":105,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":106,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":107,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":108,\"textContent\":\" \"},{\"nodeType\":1,\"id\":109,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":110,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":111,\"textContent\":\" \"},{\"nodeType\":1,\"id\":112,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":113,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":115,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":116,\"textContent\":\" \"},{\"nodeType\":1,\"id\":117,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":118,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":120,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":121,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":122,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":123,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":125,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":126,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":127,\"textContent\":\" \"},{\"nodeType\":1,\"id\":128,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":129,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":130,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":132,\"textContent\":\" \"},{\"nodeType\":1,\"id\":133,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":134,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":135,\"textContent\":\" \"},{\"nodeType\":1,\"id\":136,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":137,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":138,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":140,\"textContent\":\" \"},{\"nodeType\":1,\"id\":141,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":142,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":143,\"textContent\":\" \"},{\"nodeType\":1,\"id\":144,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":145,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":146,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":147,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":148,\"textContent\":\" \"},{\"nodeType\":1,\"id\":149,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":150,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":151,\"textContent\":\" \"},{\"nodeType\":1,\"id\":152,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":153,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":154,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":156,\"textContent\":\" \"},{\"nodeType\":1,\"id\":157,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":158,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":159,\"textContent\":\" \"},{\"nodeType\":1,\"id\":160,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":161,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":162,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":163,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":164,\"textContent\":\" \"},{\"nodeType\":1,\"id\":165,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":166,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":167,\"textContent\":\" \"},{\"nodeType\":1,\"id\":168,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":169,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":170,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":171,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":172,\"textContent\":\" \"},{\"nodeType\":1,\"id\":173,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":174,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":175,\"textContent\":\" \"},{\"nodeType\":1,\"id\":176,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":177,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":178,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":179,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":180,\"textContent\":\" \"},{\"nodeType\":1,\"id\":181,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":182,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":183,\"textContent\":\" \"},{\"nodeType\":1,\"id\":184,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":185,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":186,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":187,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":188,\"textContent\":\" \"},{\"nodeType\":1,\"id\":189,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":190,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":191,\"textContent\":\" \"},{\"nodeType\":1,\"id\":192,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":193,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":194,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":196,\"textContent\":\" \"},{\"nodeType\":1,\"id\":197,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":198,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":200,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":201,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":202,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":203,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":205,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":206,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":207,\"textContent\":\" \"},{\"nodeType\":1,\"id\":208,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":209,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":210,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":211,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":212,\"textContent\":\" \"},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":214,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":215,\"textContent\":\" \"},{\"nodeType\":1,\"id\":216,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":217,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":218,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":219,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":220,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":221,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":223,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":224,\"textContent\":\" \"},{\"nodeType\":1,\"id\":225,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":226,\"textContent\":\"Which shift(s) start at the same time as D?\"}]},{\"nodeType\":3,\"id\":227,\"textContent\":\" \"},{\"nodeType\":1,\"id\":228,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":229,\"textContent\":\" \"},{\"nodeType\":1,\"id\":230,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":231,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":232,\"textContent\":\" \"},{\"nodeType\":1,\"id\":233,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":234,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":235,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":236,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":237,\"textContent\":\" \"},{\"nodeType\":1,\"id\":238,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":239,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":240,\"textContent\":\" \"},{\"nodeType\":1,\"id\":241,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":242,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":243,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":244,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":245,\"textContent\":\" \"},{\"nodeType\":1,\"id\":246,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":247,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":248,\"textContent\":\" \"},{\"nodeType\":1,\"id\":249,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":250,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":251,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":252,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":253,\"textContent\":\" \"},{\"nodeType\":1,\"id\":254,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":255,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":256,\"textContent\":\" \"},{\"nodeType\":1,\"id\":257,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":258,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":259,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":260,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":261,\"textContent\":\" \"},{\"nodeType\":1,\"id\":262,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":263,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":264,\"textContent\":\" \"},{\"nodeType\":1,\"id\":265,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":266,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":267,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":268,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":269,\"textContent\":\" \"},{\"nodeType\":1,\"id\":270,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":271,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":273,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":274,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":275,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":276,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":278,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":279,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":280,\"textContent\":\" \"},{\"nodeType\":1,\"id\":281,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":282,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":283,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":284,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":286,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":287,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":288,\"textContent\":\" \"},{\"nodeType\":1,\"id\":289,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":290,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":291,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":292,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":293,\"textContent\":\" \"},{\"nodeType\":1,\"id\":294,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":295,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":296,\"textContent\":\" \"},{\"nodeType\":1,\"id\":297,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":298,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":299,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":300,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":301,\"textContent\":\" \"},{\"nodeType\":1,\"id\":302,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":303,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":304,\"textContent\":\" \"},{\"nodeType\":1,\"id\":305,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":306,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":307,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":308,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":309,\"textContent\":\" \"},{\"nodeType\":1,\"id\":310,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":311,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":312,\"textContent\":\" \"},{\"nodeType\":1,\"id\":313,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":314,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":315,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":316,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":317,\"textContent\":\" \"},{\"nodeType\":1,\"id\":318,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":319,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":320,\"textContent\":\" \"},{\"nodeType\":1,\"id\":321,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":322,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":323,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":324,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":325,\"textContent\":\" \"},{\"nodeType\":1,\"id\":326,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":327,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":328,\"textContent\":\" \"},{\"nodeType\":1,\"id\":329,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":330,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":331,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":332,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":333,\"textContent\":\" \"},{\"nodeType\":1,\"id\":334,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":335,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":336,\"textContent\":\" \"},{\"nodeType\":1,\"id\":337,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":338,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":339,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":340,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":341,\"textContent\":\" \"},{\"nodeType\":1,\"id\":342,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":343,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":344,\"textContent\":\" \"},{\"nodeType\":1,\"id\":345,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":346,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":347,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":348,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":349,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":351,\"textContent\":\" \"},{\"nodeType\":1,\"id\":352,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":353,\"textContent\":\" \"},{\"nodeType\":1,\"id\":354,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":355,\"textContent\":\"Which shift(s) begin when C ends?\"}]},{\"nodeType\":3,\"id\":356,\"textContent\":\" \"},{\"nodeType\":1,\"id\":357,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":358,\"textContent\":\" \"},{\"nodeType\":1,\"id\":359,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":360,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":361,\"textContent\":\" \"},{\"nodeType\":1,\"id\":362,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":363,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":364,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":365,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":366,\"textContent\":\" \"},{\"nodeType\":1,\"id\":367,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":368,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":369,\"textContent\":\" \"},{\"nodeType\":1,\"id\":370,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":371,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":372,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":373,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":374,\"textContent\":\" \"},{\"nodeType\":1,\"id\":375,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":376,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":377,\"textContent\":\" \"},{\"nodeType\":1,\"id\":378,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":379,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":380,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":381,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":382,\"textContent\":\" \"},{\"nodeType\":1,\"id\":383,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":384,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":385,\"textContent\":\" \"},{\"nodeType\":1,\"id\":386,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":387,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":388,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":389,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":390,\"textContent\":\" \"},{\"nodeType\":1,\"id\":391,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":392,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":393,\"textContent\":\" \"},{\"nodeType\":1,\"id\":394,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":395,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":396,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":397,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":398,\"textContent\":\" \"},{\"nodeType\":1,\"id\":399,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":400,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":401,\"textContent\":\" \"},{\"nodeType\":1,\"id\":402,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":403,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":404,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":405,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":406,\"textContent\":\" \"},{\"nodeType\":1,\"id\":407,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":408,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":409,\"textContent\":\" \"},{\"nodeType\":1,\"id\":410,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":411,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":412,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":413,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":414,\"textContent\":\" \"},{\"nodeType\":1,\"id\":415,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":416,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":417,\"textContent\":\" \"},{\"nodeType\":1,\"id\":418,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":419,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":420,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":421,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":422,\"textContent\":\" \"},{\"nodeType\":1,\"id\":423,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":424,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":425,\"textContent\":\" \"},{\"nodeType\":1,\"id\":426,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":427,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":428,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":429,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":430,\"textContent\":\" \"},{\"nodeType\":1,\"id\":431,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":432,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":433,\"textContent\":\" \"},{\"nodeType\":1,\"id\":434,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":435,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":436,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":437,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":438,\"textContent\":\" \"},{\"nodeType\":1,\"id\":439,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":440,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":441,\"textContent\":\" \"},{\"nodeType\":1,\"id\":442,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":443,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":444,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":445,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":446,\"textContent\":\" \"},{\"nodeType\":1,\"id\":447,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":448,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":449,\"textContent\":\" \"},{\"nodeType\":1,\"id\":450,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":451,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":452,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":453,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":454,\"textContent\":\" \"},{\"nodeType\":1,\"id\":455,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":456,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":457,\"textContent\":\" \"},{\"nodeType\":1,\"id\":458,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":459,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":460,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":461,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":462,\"textContent\":\" \"},{\"nodeType\":1,\"id\":463,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":464,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":465,\"textContent\":\" \"},{\"nodeType\":1,\"id\":466,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":467,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":468,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":469,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":470,\"textContent\":\" \"},{\"nodeType\":1,\"id\":471,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":472,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":473,\"textContent\":\" \"},{\"nodeType\":1,\"id\":474,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":475,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":476,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":477,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":478,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":479,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":480,\"textContent\":\" \"},{\"nodeType\":1,\"id\":481,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":483,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":484,\"textContent\":\" Which shift(s) end at 4 pm?\"}]},{\"nodeType\":3,\"id\":485,\"textContent\":\" \"},{\"nodeType\":1,\"id\":486,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":492,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":500,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":503,\"textContent\":\" \"},{\"nodeType\":1,\"id\":504,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":505,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":506,\"textContent\":\" \"},{\"nodeType\":1,\"id\":507,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":508,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":509,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":510,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":511,\"textContent\":\" \"},{\"nodeType\":1,\"id\":512,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":513,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":514,\"textContent\":\" \"},{\"nodeType\":1,\"id\":515,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":516,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":517,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":518,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":519,\"textContent\":\" \"},{\"nodeType\":1,\"id\":520,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":521,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":522,\"textContent\":\" \"},{\"nodeType\":1,\"id\":523,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":524,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":525,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":526,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":527,\"textContent\":\" \"},{\"nodeType\":1,\"id\":528,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":529,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":530,\"textContent\":\" \"},{\"nodeType\":1,\"id\":531,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":532,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":533,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":534,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":535,\"textContent\":\" \"},{\"nodeType\":1,\"id\":536,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":537,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":538,\"textContent\":\" \"},{\"nodeType\":1,\"id\":539,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":540,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":541,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":542,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":543,\"textContent\":\" \"},{\"nodeType\":1,\"id\":544,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":545,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":546,\"textContent\":\" \"},{\"nodeType\":1,\"id\":547,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":548,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":549,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":550,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":551,\"textContent\":\" \"},{\"nodeType\":1,\"id\":552,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":553,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":554,\"textContent\":\" \"},{\"nodeType\":1,\"id\":555,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":556,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":557,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":558,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":559,\"textContent\":\" \"},{\"nodeType\":1,\"id\":560,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":561,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":562,\"textContent\":\" \"},{\"nodeType\":1,\"id\":563,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":564,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":565,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":566,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":567,\"textContent\":\" \"},{\"nodeType\":1,\"id\":568,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":569,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":570,\"textContent\":\" \"},{\"nodeType\":1,\"id\":571,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":572,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":573,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":574,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":575,\"textContent\":\" \"},{\"nodeType\":1,\"id\":576,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":577,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":578,\"textContent\":\" \"},{\"nodeType\":1,\"id\":579,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":580,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":581,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":582,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":583,\"textContent\":\" \"},{\"nodeType\":1,\"id\":584,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":585,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":586,\"textContent\":\" \"},{\"nodeType\":1,\"id\":587,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":588,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":589,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":590,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":592,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":593,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":594,\"textContent\":\" \"},{\"nodeType\":1,\"id\":595,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":596,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":597,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":598,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":599,\"textContent\":\" \"},{\"nodeType\":1,\"id\":600,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":601,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":602,\"textContent\":\" \"},{\"nodeType\":1,\"id\":603,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":604,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":605,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":606,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":607,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":608,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":609,\"textContent\":\" \"},{\"nodeType\":1,\"id\":610,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":612,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":613,\"textContent\":\"Coffee breaks happen halfway through a shift.\"},{\"nodeType\":1,\"id\":614,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":615,\"textContent\":\" Which shift(s) share a break with I?\"}]},{\"nodeType\":3,\"id\":616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":617,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":618,\"textContent\":\" \"},{\"nodeType\":1,\"id\":619,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":620,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":621,\"textContent\":\" \"},{\"nodeType\":1,\"id\":622,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":623,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":624,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":625,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":626,\"textContent\":\" \"},{\"nodeType\":1,\"id\":627,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":628,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":629,\"textContent\":\" \"},{\"nodeType\":1,\"id\":630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":631,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":632,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":633,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":634,\"textContent\":\" \"},{\"nodeType\":1,\"id\":635,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":636,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":637,\"textContent\":\" \"},{\"nodeType\":1,\"id\":638,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":639,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":640,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":641,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":642,\"textContent\":\" \"},{\"nodeType\":1,\"id\":643,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":644,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":645,\"textContent\":\" \"},{\"nodeType\":1,\"id\":646,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":647,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":648,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":649,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":650,\"textContent\":\" \"},{\"nodeType\":1,\"id\":651,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":653,\"textContent\":\" \"},{\"nodeType\":1,\"id\":654,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":655,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":656,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":657,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":659,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":660,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":661,\"textContent\":\" \"},{\"nodeType\":1,\"id\":662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":663,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":664,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":665,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":666,\"textContent\":\" \"},{\"nodeType\":1,\"id\":667,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":668,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":669,\"textContent\":\" \"},{\"nodeType\":1,\"id\":670,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":671,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":672,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":673,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":674,\"textContent\":\" \"},{\"nodeType\":1,\"id\":675,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":676,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":677,\"textContent\":\" \"},{\"nodeType\":1,\"id\":678,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":679,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":680,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":681,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":682,\"textContent\":\" \"},{\"nodeType\":1,\"id\":683,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":685,\"textContent\":\" \"},{\"nodeType\":1,\"id\":686,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":687,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":688,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":689,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":690,\"textContent\":\" \"},{\"nodeType\":1,\"id\":691,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":692,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":693,\"textContent\":\" \"},{\"nodeType\":1,\"id\":694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":695,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":696,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":697,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":698,\"textContent\":\" \"},{\"nodeType\":1,\"id\":699,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":700,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":701,\"textContent\":\" \"},{\"nodeType\":1,\"id\":702,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":703,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":704,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":705,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":706,\"textContent\":\" \"},{\"nodeType\":1,\"id\":707,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":708,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":709,\"textContent\":\" \"},{\"nodeType\":1,\"id\":710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":711,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":712,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":713,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":714,\"textContent\":\" \"},{\"nodeType\":1,\"id\":715,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":716,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":717,\"textContent\":\" \"},{\"nodeType\":1,\"id\":718,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":719,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":720,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":721,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":722,\"textContent\":\" \"},{\"nodeType\":1,\"id\":723,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":724,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":725,\"textContent\":\" \"},{\"nodeType\":1,\"id\":726,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":727,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":728,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":729,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":730,\"textContent\":\" \"},{\"nodeType\":1,\"id\":731,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":732,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":733,\"textContent\":\" \"},{\"nodeType\":1,\"id\":734,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":735,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":736,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":737,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":738,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":739,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":741,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":742,\"textContent\":\" \"},{\"nodeType\":1,\"id\":743,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":744,\"textContent\":\"Which shift(s) are six hours long?\"}]},{\"nodeType\":3,\"id\":745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":746,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":747,\"textContent\":\" \"},{\"nodeType\":1,\"id\":748,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":749,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":750,\"textContent\":\" \"},{\"nodeType\":1,\"id\":751,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":752,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":753,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":754,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":755,\"textContent\":\" \"},{\"nodeType\":1,\"id\":756,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":757,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":758,\"textContent\":\" \"},{\"nodeType\":1,\"id\":759,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":760,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":761,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":762,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":763,\"textContent\":\" \"},{\"nodeType\":1,\"id\":764,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":765,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":766,\"textContent\":\" \"},{\"nodeType\":1,\"id\":767,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":768,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":769,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":770,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":771,\"textContent\":\" \"},{\"nodeType\":1,\"id\":772,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":773,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":774,\"textContent\":\" \"},{\"nodeType\":1,\"id\":775,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":776,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":777,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":778,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":779,\"textContent\":\" \"},{\"nodeType\":1,\"id\":780,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":781,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":782,\"textContent\":\" \"},{\"nodeType\":1,\"id\":783,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":784,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":785,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":786,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":787,\"textContent\":\" \"},{\"nodeType\":1,\"id\":788,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":789,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":790,\"textContent\":\" \"},{\"nodeType\":1,\"id\":791,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":792,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":793,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":794,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":795,\"textContent\":\" \"},{\"nodeType\":1,\"id\":796,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":797,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":798,\"textContent\":\" \"},{\"nodeType\":1,\"id\":799,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":800,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":801,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":802,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":803,\"textContent\":\" \"},{\"nodeType\":1,\"id\":804,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":805,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":806,\"textContent\":\" \"},{\"nodeType\":1,\"id\":807,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":808,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":809,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":810,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":812,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":813,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":814,\"textContent\":\" \"},{\"nodeType\":1,\"id\":815,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":816,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":817,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":818,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":819,\"textContent\":\" \"},{\"nodeType\":1,\"id\":820,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":821,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":822,\"textContent\":\" \"},{\"nodeType\":1,\"id\":823,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":824,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":825,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":826,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":827,\"textContent\":\" \"},{\"nodeType\":1,\"id\":828,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":829,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":830,\"textContent\":\" \"},{\"nodeType\":1,\"id\":831,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":832,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":833,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":834,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":835,\"textContent\":\" \"},{\"nodeType\":1,\"id\":836,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":837,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":838,\"textContent\":\" \"},{\"nodeType\":1,\"id\":839,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":840,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":841,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":842,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":843,\"textContent\":\" \"},{\"nodeType\":1,\"id\":844,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":845,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":846,\"textContent\":\" \"},{\"nodeType\":1,\"id\":847,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":848,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":849,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":850,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":851,\"textContent\":\" \"},{\"nodeType\":1,\"id\":852,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":853,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":854,\"textContent\":\" \"},{\"nodeType\":1,\"id\":855,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":856,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":857,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":858,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":859,\"textContent\":\" \"},{\"nodeType\":1,\"id\":860,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":861,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":862,\"textContent\":\" \"},{\"nodeType\":1,\"id\":863,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":864,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":865,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":866,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":867,\"textContent\":\" \"},{\"nodeType\":1,\"id\":868,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":869,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":870,\"textContent\":\" \"},{\"nodeType\":1,\"id\":871,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":872,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":873,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":874,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":875,\"textContent\":\" \"},{\"nodeType\":1,\"id\":876,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":877,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":878,\"textContent\":\" \"},{\"nodeType\":1,\"id\":879,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":880,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":881,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":882,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":883,\"textContent\":\" \"},{\"nodeType\":1,\"id\":884,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":885,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":886,\"textContent\":\" \"},{\"nodeType\":1,\"id\":887,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":888,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":889,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":890,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":891,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":892,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":894,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":895,\"textContent\":\" \"},{\"nodeType\":1,\"id\":896,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":897,\"textContent\":\"Which 2 shifts less than 5 hours long start at the same time?\"}]},{\"nodeType\":3,\"id\":898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":899,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":900,\"textContent\":\" \"},{\"nodeType\":1,\"id\":901,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":902,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":903,\"textContent\":\" \"},{\"nodeType\":1,\"id\":904,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":905,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":906,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":907,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":908,\"textContent\":\" \"},{\"nodeType\":1,\"id\":909,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":910,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":911,\"textContent\":\" \"},{\"nodeType\":1,\"id\":912,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":913,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":914,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":915,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":916,\"textContent\":\" \"},{\"nodeType\":1,\"id\":917,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":918,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":919,\"textContent\":\" \"},{\"nodeType\":1,\"id\":920,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":921,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":922,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":923,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":924,\"textContent\":\" \"},{\"nodeType\":1,\"id\":925,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":926,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":927,\"textContent\":\" \"},{\"nodeType\":1,\"id\":928,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":929,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":930,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":931,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":932,\"textContent\":\" \"},{\"nodeType\":1,\"id\":933,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":934,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":935,\"textContent\":\" \"},{\"nodeType\":1,\"id\":936,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":937,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":938,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":939,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":940,\"textContent\":\" \"},{\"nodeType\":1,\"id\":941,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":942,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":943,\"textContent\":\" \"},{\"nodeType\":1,\"id\":944,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":945,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":946,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":947,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":948,\"textContent\":\" \"},{\"nodeType\":1,\"id\":949,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":950,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":951,\"textContent\":\" \"},{\"nodeType\":1,\"id\":952,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":953,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":954,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":955,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":956,\"textContent\":\" \"},{\"nodeType\":1,\"id\":957,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":958,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":959,\"textContent\":\" \"},{\"nodeType\":1,\"id\":960,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":961,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":962,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":963,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":965,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":966,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":967,\"textContent\":\" \"},{\"nodeType\":1,\"id\":968,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":969,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":970,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":971,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":972,\"textContent\":\" \"},{\"nodeType\":1,\"id\":973,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":974,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":975,\"textContent\":\" \"},{\"nodeType\":1,\"id\":976,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":977,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":978,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":979,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":980,\"textContent\":\" \"},{\"nodeType\":1,\"id\":981,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":982,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":983,\"textContent\":\" \"},{\"nodeType\":1,\"id\":984,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":985,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":986,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":987,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":988,\"textContent\":\" \"},{\"nodeType\":1,\"id\":989,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":990,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":991,\"textContent\":\" \"},{\"nodeType\":1,\"id\":992,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":993,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":994,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":995,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":996,\"textContent\":\" \"},{\"nodeType\":1,\"id\":997,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":998,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":999,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1000,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1001,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1002,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1003,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1004,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1005,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1006,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1007,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1008,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1009,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1010,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1011,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1012,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1013,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1014,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1015,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1016,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1017,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1018,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1019,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1020,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1021,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1022,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1023,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1024,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1025,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1026,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1027,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1028,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1029,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1030,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1031,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1032,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1033,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1034,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1035,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1036,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1037,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1038,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1039,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1040,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1041,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1042,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1043,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1044,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1045,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1047,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+contained\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1048,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1049,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1050,\"textContent\":\"Which shift(s) under 7 hours long starts before B starts, and ends after X ends?\"}]},{\"nodeType\":3,\"id\":1051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1052,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1053,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1054,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1055,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1056,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1057,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1058,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1059,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1060,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1061,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1062,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1063,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1064,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1065,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1066,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1067,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1068,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1069,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1070,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1071,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1072,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1073,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1074,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1075,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1076,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1077,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1078,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1079,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1080,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1081,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1082,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1083,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1084,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1085,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1086,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1087,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1088,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1089,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1090,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1091,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1092,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1093,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1094,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1095,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1096,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1097,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1098,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1099,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1100,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1101,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1102,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1103,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1104,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1105,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1106,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1107,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1108,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1109,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1110,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1111,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1112,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1113,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1114,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1115,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1116,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1118,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1119,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1120,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1121,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1122,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1123,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1124,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1125,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1126,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1127,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1128,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1129,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1130,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1131,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1132,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1133,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1134,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1135,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1136,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1137,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1138,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1139,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1140,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1141,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1142,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1143,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1144,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1145,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1146,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1147,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1148,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1149,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1150,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1151,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1152,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1153,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1154,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1155,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1156,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1157,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1158,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1159,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1160,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1161,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1162,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1163,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1164,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1165,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1166,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1167,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1168,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1169,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1170,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1171,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1172,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1173,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1174,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1175,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1176,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1177,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1178,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1179,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1180,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1181,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1182,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1183,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1184,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1185,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1186,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1187,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1188,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1189,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1190,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1191,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1192,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1193,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1194,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1195,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1196,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1197,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1198,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1200,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime+before+endtime+during\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1202,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1203,\"textContent\":\"Which shift(s) begins before J begins and ends during B?\"}]},{\"nodeType\":3,\"id\":1204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1205,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1211,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1219,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1227,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1235,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1243,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1251,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1259,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1267,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1270,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1271,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1272,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1273,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1274,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1275,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1276,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1277,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1278,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1279,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1280,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1281,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1282,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1283,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1284,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1285,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1286,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1287,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1288,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1289,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1290,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1291,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1292,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1293,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1294,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1295,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1296,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1298,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1299,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1300,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1301,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1302,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1303,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1304,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1305,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1306,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1307,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1308,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1309,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1310,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1311,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1312,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1313,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1314,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1315,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1316,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1317,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1318,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1319,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1320,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1321,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1322,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1323,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1324,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1325,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1326,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1327,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1328,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1329,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1330,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1331,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1332,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1333,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1334,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1335,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1336,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1337,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1338,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1339,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1340,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1341,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1342,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1343,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1344,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1345,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1346,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1347,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1348,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1349,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1351,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1352,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1353,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.ends\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1354,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1355,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1356,\"textContent\":\"Which shift(s) end at the same time as F?\"}]},{\"nodeType\":3,\"id\":1357,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1358,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1359,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1360,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1361,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1362,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1363,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1364,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1365,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1366,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1367,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1368,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1369,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1370,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1371,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1372,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1373,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1374,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1375,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1376,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1377,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1378,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1379,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1380,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1381,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1382,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1383,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1384,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1385,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1386,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1387,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1388,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1389,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1390,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1391,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1392,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1393,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1394,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1395,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1396,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1397,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1398,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1399,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1400,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1401,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1402,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1403,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1404,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1405,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1406,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1407,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1408,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1409,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1410,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1411,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1412,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1413,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1414,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1415,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1416,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1417,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1418,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1419,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1420,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1421,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1422,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1423,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1424,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1425,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1426,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1427,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1428,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1429,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1430,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1431,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1432,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1433,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1434,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1435,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1436,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1437,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1438,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1439,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1440,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1441,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1442,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1443,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1444,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1445,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1446,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1447,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1448,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1449,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1450,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1451,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1452,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1453,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1454,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1455,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1456,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1457,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1458,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1459,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1460,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1461,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1462,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1463,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1464,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1465,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1466,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1467,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1468,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1469,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1470,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1471,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1472,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1473,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1474,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1475,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1476,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1477,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1478,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1479,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1480,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1481,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1483,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1484,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1485,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1486,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1492,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1500,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1503,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1504,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1505,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1506,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1507,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1508,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1509,\"textContent\":\"Which shift(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":1510,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1511,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1512,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1513,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1514,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1515,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1516,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1517,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1518,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1519,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1520,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1521,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1522,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1523,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1524,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1525,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1526,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1527,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1528,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1529,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1530,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1531,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1532,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1533,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1534,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1535,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1536,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1537,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1538,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1539,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1540,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1541,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1542,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1543,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1544,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1545,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1546,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1547,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1548,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1549,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1550,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1551,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1552,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1553,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1554,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1555,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1556,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1557,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1558,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1559,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1560,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1561,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1562,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1563,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1564,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1565,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1566,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1567,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1568,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1569,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1570,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1571,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1572,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1573,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1574,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1575,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1576,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1577,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1578,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1579,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1580,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1581,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1582,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1583,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1584,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1585,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1586,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1587,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1588,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1589,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1590,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1591,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1592,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1593,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1594,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1595,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1596,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1597,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1598,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1599,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1600,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1601,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1602,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1603,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1604,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1605,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1606,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1607,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1608,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1609,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1610,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1612,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1613,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1614,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1615,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1617,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1618,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1619,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1620,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1621,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1622,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1623,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1624,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1625,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1627,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1628,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1629,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1630,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1631,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1632,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1633,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1634,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1635,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1636,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1637,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1638,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1639,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1640,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1641,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1642,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1643,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1644,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1645,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1646,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1647,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1648,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1649,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1650,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1651,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1652,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1653,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1654,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1655,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1656,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1657,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1659,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1660,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1661,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1662,\"textContent\":\"Which shift(s) start at the same time as F?\"}]},{\"nodeType\":3,\"id\":1663,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1664,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1665,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1666,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1667,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1668,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1669,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1670,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1671,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1672,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1673,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1674,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1675,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1676,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1677,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1678,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1679,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1680,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1681,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1682,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1683,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1684,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1686,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1687,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1688,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1689,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1690,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1691,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1692,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1693,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1694,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1695,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1696,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1697,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1698,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1699,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1700,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1701,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1702,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1703,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1704,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1705,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1706,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1707,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1708,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1709,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1710,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1711,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1712,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1713,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1714,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1715,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1716,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1717,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1718,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1720,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1721,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1722,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1723,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1724,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1725,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1726,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1727,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1728,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1729,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1730,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1731,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1732,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1733,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1734,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1735,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1736,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1737,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1738,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1739,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1741,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1742,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1743,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1744,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1746,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1747,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1748,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1749,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1750,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1751,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1752,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1753,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1754,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1755,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1756,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1757,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1758,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1759,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1760,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1761,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1762,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1763,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1764,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1765,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1766,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1767,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1768,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1769,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1770,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1771,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1772,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1773,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1774,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1775,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1776,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1777,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1778,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1779,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1780,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1781,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1782,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1783,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1784,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1785,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1786,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1787,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1788,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1789,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1790,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1791,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1792,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1793,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1794,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1795,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1796,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1797,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1798,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1799,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1800,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1801,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1802,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1803,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1804,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1805,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1806,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1807,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1808,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1809,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1810,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1812,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1813,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1814,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1815,\"textContent\":\"Which 2 shifts end when Z begins?\"}]},{\"nodeType\":3,\"id\":1816,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1817,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1818,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1819,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1820,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1821,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1822,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1823,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1824,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1825,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1826,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1827,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1828,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1829,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1830,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1831,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1832,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1833,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1834,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1835,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1836,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1837,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1838,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1839,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1840,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1841,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1842,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1843,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1844,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1845,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1846,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1847,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1848,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1849,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1850,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1851,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1852,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1853,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1854,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1855,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1856,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1857,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1858,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1859,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1860,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1861,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1862,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1863,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1864,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1865,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1866,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1867,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1868,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1869,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1870,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1871,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1872,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1873,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1874,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1875,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1876,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1877,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1878,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1879,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1880,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1881,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1882,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1883,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1884,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1885,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1886,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1887,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1888,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1889,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1890,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1891,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1892,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1894,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1895,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1896,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1897,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1899,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1900,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1901,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1902,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1903,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1904,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1905,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1906,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1907,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1908,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1909,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1910,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1911,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1912,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1913,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1914,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1915,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1916,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1917,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1918,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1919,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1920,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1921,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1922,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1923,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1924,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1925,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1926,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1927,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1928,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1929,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1930,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1931,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1932,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1933,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1934,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1935,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1936,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1937,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1938,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1939,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1940,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1941,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1942,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1943,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1944,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1945,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1946,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1947,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1948,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1949,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1950,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1951,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1952,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1953,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1954,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1955,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1956,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1957,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1958,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1959,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1960,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1961,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1962,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1963,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1965,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1966,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1967,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1968,\"textContent\":\"Which shift(s) end at 3pm?\"}]},{\"nodeType\":3,\"id\":1969,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1970,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1971,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1972,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1973,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1974,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1975,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1976,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1977,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1978,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1979,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1980,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1981,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1982,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1983,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1984,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1985,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1986,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1987,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1988,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1989,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1990,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1991,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1992,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1993,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1994,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1995,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1996,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1997,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1998,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1999,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2000,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2001,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2002,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2003,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2004,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2005,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2006,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2007,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2008,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2009,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2010,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2011,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2012,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2013,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2014,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2015,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2016,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2017,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2018,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2019,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2020,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2021,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2022,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2023,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2024,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2025,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2026,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2027,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2028,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2029,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2030,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2031,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2032,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2033,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2034,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2035,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2036,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2037,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2038,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2039,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2040,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2041,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2042,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2043,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2044,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2045,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2047,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2048,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2049,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2050,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2052,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2053,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2054,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2055,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2056,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2057,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2058,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2059,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2060,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2061,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2062,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2063,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2064,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2065,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2066,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2067,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2068,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2069,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2070,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2071,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2072,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2073,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2074,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2075,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2076,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2077,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2078,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2079,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2080,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2081,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2082,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2083,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2084,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2085,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2086,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2087,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2088,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2089,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2090,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2091,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2092,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2093,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2094,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2095,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2096,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2097,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2098,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2099,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2100,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2101,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2102,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2103,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2104,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2105,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2106,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2107,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2108,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2109,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2110,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2111,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2112,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2113,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2114,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2115,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2116,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2118,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":2119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2120,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2121,\"textContent\":\"Coffee breaks happen halfway through a shift. \"},{\"nodeType\":1,\"id\":2122,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":2123,\"textContent\":\"Which shifts share a break at 2pm?\"}]},{\"nodeType\":3,\"id\":2124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2125,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":2126,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2127,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2128,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2129,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2130,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2131,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":2132,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2133,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2134,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2135,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2136,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2137,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2138,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2139,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":2140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2141,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2142,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2143,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2144,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2145,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2146,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2147,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":2148,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2149,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2150,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2151,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2152,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2153,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2154,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2155,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2156,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2157,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2158,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2159,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2160,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2161,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2162,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2163,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2164,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2165,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2166,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2167,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2168,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2169,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2170,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2171,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2172,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2173,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2174,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2175,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2176,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2177,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2178,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2179,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2180,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2181,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2182,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2183,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2184,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2185,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2186,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2187,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2188,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2189,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2190,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2191,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2192,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2193,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2194,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2195,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2196,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2197,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2198,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2199,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2200,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2202,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2203,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2204,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2205,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2211,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2219,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2227,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2235,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2243,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2251,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2259,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2267,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2270,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2271,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2273,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\".strategy\",\"style\":\"display: block;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2274,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2275,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2276,\"textContent\":\"Please describe how to determine what event(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":2277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2278,\"tagName\":\"TEXTAREA\",\"attributes\":{\"id\":\"strategyAnswer\",\"rows\":\"5\",\"cols\":\"80\"}},{\"nodeType\":3,\"id\":2279,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2280,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2281,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2282},{\"nodeType\":3,\"id\":2283,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2284},{\"nodeType\":3,\"id\":2285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2286,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"fixbottom\"},\"childNodes\":[{\"nodeType\":3,\"id\":2287,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2288,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"testingButton\",\"style\":\"display:none;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2289,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2290,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2291,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"strategyButton\",\"style\":\"display: block;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2292,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2293,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2294,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2295,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2296},{\"nodeType\":3,\"id\":2297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2298,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"d3container\"},\"childNodes\":[{\"nodeType\":1,\"id\":2299,\"tagName\":\"svg\",\"attributes\":{\"width\":\"930\",\"height\":\"915\"},\"childNodes\":[{\"nodeType\":1,\"id\":2300,\"tagName\":\"g\",\"attributes\":{\"transform\":\"translate(100,25)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2301,\"tagName\":\"g\",\"attributes\":{\"class\":\"leaders\"}},{\"nodeType\":1,\"id\":2302,\"tagName\":\"g\",\"attributes\":{\"class\":\"static-scaffold\"}},{\"nodeType\":1,\"id\":2303,\"tagName\":\"g\",\"attributes\":{\"class\":\"xaxis\",\"transform\":\"translate(0,800)\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"middle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2304,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M0.5,6V0.5H800.5V6\"}},{\"nodeType\":1,\"id\":2305,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2306,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2307,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2308,\"textContent\":\"08 AM\"}]}]},{\"nodeType\":1,\"id\":2309,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(33.83333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2310,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2311,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2312,\"textContent\":\"08:30\"}]}]},{\"nodeType\":1,\"id\":2313,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(67.16666666666666,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2314,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2315,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2316,\"textContent\":\"09 AM\"}]}]},{\"nodeType\":1,\"id\":2317,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(100.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2318,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2319,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2320,\"textContent\":\"09:30\"}]}]},{\"nodeType\":1,\"id\":2321,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(133.83333333333331,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2322,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2323,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2324,\"textContent\":\"10 AM\"}]}]},{\"nodeType\":1,\"id\":2325,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(167.16666666666669,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2326,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2327,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2328,\"textContent\":\"10:30\"}]}]},{\"nodeType\":1,\"id\":2329,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(200.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2330,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2331,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2332,\"textContent\":\"11 AM\"}]}]},{\"nodeType\":1,\"id\":2333,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(233.83333333333334,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2334,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2335,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2336,\"textContent\":\"11:30\"}]}]},{\"nodeType\":1,\"id\":2337,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(267.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2338,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2339,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2340,\"textContent\":\"12 PM\"}]}]},{\"nodeType\":1,\"id\":2341,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(300.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2342,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2343,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2344,\"textContent\":\"12:30\"}]}]},{\"nodeType\":1,\"id\":2345,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(333.83333333333337,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2346,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2347,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2348,\"textContent\":\"01 PM\"}]}]},{\"nodeType\":1,\"id\":2349,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(367.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2350,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2351,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2352,\"textContent\":\"01:30\"}]}]},{\"nodeType\":1,\"id\":2353,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(400.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2354,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2355,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2356,\"textContent\":\"02 PM\"}]}]},{\"nodeType\":1,\"id\":2357,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(433.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2358,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2359,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2360,\"textContent\":\"02:30\"}]}]},{\"nodeType\":1,\"id\":2361,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(467.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2362,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2363,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2364,\"textContent\":\"03 PM\"}]}]},{\"nodeType\":1,\"id\":2365,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(500.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2366,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2367,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2368,\"textContent\":\"03:30\"}]}]},{\"nodeType\":1,\"id\":2369,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(533.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2370,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2371,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2372,\"textContent\":\"04 PM\"}]}]},{\"nodeType\":1,\"id\":2373,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(567.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2374,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2375,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2376,\"textContent\":\"04:30\"}]}]},{\"nodeType\":1,\"id\":2377,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(600.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2378,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2379,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2380,\"textContent\":\"05 PM\"}]}]},{\"nodeType\":1,\"id\":2381,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(633.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2382,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2383,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2384,\"textContent\":\"05:30\"}]}]},{\"nodeType\":1,\"id\":2385,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(667.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2386,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2387,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2388,\"textContent\":\"06 PM\"}]}]},{\"nodeType\":1,\"id\":2389,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(700.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2390,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2391,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2392,\"textContent\":\"06:30\"}]}]},{\"nodeType\":1,\"id\":2393,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(733.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2394,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2395,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2396,\"textContent\":\"07 PM\"}]}]},{\"nodeType\":1,\"id\":2397,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(767.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2398,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2399,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2400,\"textContent\":\"07:30\"}]}]},{\"nodeType\":1,\"id\":2401,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(800.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2402,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2403,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2404,\"textContent\":\"08 PM\"}]}]},{\"nodeType\":1,\"id\":2405,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2406,\"tagName\":\"text\",\"attributes\":{\"x\":\"533.3333333333334\",\"y\":\"80\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2407,\"textContent\":\"START & END TIME (time of day)\"}]}]}]},{\"nodeType\":1,\"id\":2408,\"tagName\":\"g\",\"attributes\":{\"class\":\"yaxis\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"end\"},\"childNodes\":[{\"nodeType\":1,\"id\":2409,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M-15,800.5H0.5V0.5H-15\"}},{\"nodeType\":1,\"id\":2410,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,800.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2411,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2412,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2413,\"textContent\":\"0\"}]}]},{\"nodeType\":1,\"id\":2414,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,733.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2415,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2416,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2417,\"textContent\":\"1\"}]}]},{\"nodeType\":1,\"id\":2418,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,667.1666666666667)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2419,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2420,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2421,\"textContent\":\"2\"}]}]},{\"nodeType\":1,\"id\":2422,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,600.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2423,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2424,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2425,\"textContent\":\"3\"}]}]},{\"nodeType\":1,\"id\":2426,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,533.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2427,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2428,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2429,\"textContent\":\"4\"}]}]},{\"nodeType\":1,\"id\":2430,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,467.16666666666663)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2431,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2432,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2433,\"textContent\":\"5\"}]}]},{\"nodeType\":1,\"id\":2434,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,400.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2435,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2436,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2437,\"textContent\":\"6\"}]}]},{\"nodeType\":1,\"id\":2438,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,333.8333333333333)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2439,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2440,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2441,\"textContent\":\"7\"}]}]},{\"nodeType\":1,\"id\":2442,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,267.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2443,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2444,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2445,\"textContent\":\"8\"}]}]},{\"nodeType\":1,\"id\":2446,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,200.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2447,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2448,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2449,\"textContent\":\"9\"}]}]},{\"nodeType\":1,\"id\":2450,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,133.83333333333326)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2451,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2452,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2453,\"textContent\":\"10\"}]}]},{\"nodeType\":1,\"id\":2454,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,67.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2455,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2456,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2457,\"textContent\":\"11\"}]}]},{\"nodeType\":1,\"id\":2458,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,0.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2459,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2460,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2461,\"textContent\":\"12\"}]}]},{\"nodeType\":1,\"id\":2462,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2463,\"tagName\":\"text\",\"attributes\":{\"transform\":\"rotate(-90)\",\"x\":\"-350\",\"y\":\"-60\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2464,\"textContent\":\"DURATION (in hours)\"}]}]}]},{\"nodeType\":1,\"id\":2465,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2466,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2467,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"733.3333333333334\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2468,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2469,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"666.6666666666667\",\"y2\":\"666.6666666666667\"}}]},{\"nodeType\":1,\"id\":2470,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2471,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"600\",\"y2\":\"600\"}}]},{\"nodeType\":1,\"id\":2472,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2473,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"533.3333333333334\",\"y2\":\"533.3333333333334\"}}]},{\"nodeType\":1,\"id\":2474,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2475,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"466.66666666666663\",\"y2\":\"466.66666666666663\"}}]},{\"nodeType\":1,\"id\":2476,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2477,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"400\",\"y2\":\"400\"}}]},{\"nodeType\":1,\"id\":2478,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2479,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"333.3333333333333\",\"y2\":\"333.3333333333333\"}}]},{\"nodeType\":1,\"id\":2480,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2481,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"266.66666666666674\",\"y2\":\"266.66666666666674\"}}]},{\"nodeType\":1,\"id\":2482,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2483,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"200\",\"y2\":\"200\"}}]},{\"nodeType\":1,\"id\":2484,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2485,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"133.33333333333326\",\"y2\":\"133.33333333333326\"}}]},{\"nodeType\":1,\"id\":2486,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2487,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"66.66666666666674\",\"y2\":\"66.66666666666674\"}}]},{\"nodeType\":1,\"id\":2488,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2489,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"0\",\"y2\":\"0\"}}]}]},{\"nodeType\":1,\"id\":2490,\"tagName\":\"g\",\"attributes\":{\"class\":\"xgrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2491,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"0\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2492,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"800\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2493,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"433.3333333333333\",\"y2\":\"66.66666666666674\"}},{\"nodeType\":1,\"id\":2494,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"366.66666666666663\",\"y2\":\"66.66666666666674\"}},{\"nodeType\":1,\"id\":2495,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"466.6666666666667\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2496,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"333.33333333333337\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2497,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"500\",\"y2\":\"200\"}},{\"nodeType\":1,\"id\":2498,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"300\",\"y2\":\"200\"}},{\"nodeType\":1,\"id\":2499,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"533.3333333333333\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2500,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"266.66666666666663\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2501,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"566.6666666666667\",\"y2\":\"333.3333333333333\"}},{\"nodeType\":1,\"id\":2502,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"233.33333333333334\",\"y2\":\"333.3333333333333\"}},{\"nodeType\":1,\"id\":2503,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"600\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2504,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"200\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2505,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"633.3333333333333\",\"y2\":\"466.66666666666663\"}},{\"nodeType\":1,\"id\":2506,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"166.66666666666669\",\"y2\":\"466.66666666666663\"}},{\"nodeType\":1,\"id\":2507,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"666.6666666666667\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2508,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"133.33333333333331\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2509,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"700\",\"y2\":\"600\"}},{\"nodeType\":1,\"id\":2510,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"100\",\"y2\":\"600\"}},{\"nodeType\":1,\"id\":2511,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"733.3333333333333\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2512,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"66.66666666666666\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2513,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"766.6666666666667\",\"y2\":\"733.3333333333334\"}},{\"nodeType\":1,\"id\":2514,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"33.33333333333333\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2515,\"tagName\":\"g\",\"attributes\":{\"class\":\"data\"},\"childNodes\":[{\"nodeType\":1,\"id\":2516,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2517,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"266.66666666666674\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2518,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"258.66666666666674\"},\"childNodes\":[{\"nodeType\":3,\"id\":2519,\"textContent\":\"A \"}]}]},{\"nodeType\":1,\"id\":2520,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2521,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2522,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2523,\"textContent\":\"B \"}]}]},{\"nodeType\":1,\"id\":2524,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2525,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"366.66666666666663\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2526,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"361.66666666666663\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2527,\"textContent\":\"C \"}]}]},{\"nodeType\":1,\"id\":2528,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2529,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"666.6666666666667\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2530,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"661.6666666666667\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2531,\"textContent\":\"D \"}]}]},{\"nodeType\":1,\"id\":2532,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2533,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"200\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2534,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"195\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2535,\"textContent\":\"E \"}]}]},{\"nodeType\":1,\"id\":2536,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2537,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2538,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2539,\"textContent\":\"F \"}]}]},{\"nodeType\":1,\"id\":2540,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2541,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2542,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2543,\"textContent\":\"G \"}]}]},{\"nodeType\":1,\"id\":2544,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2545,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2546,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2547,\"textContent\":\"H \"}]}]},{\"nodeType\":1,\"id\":2548,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2549,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"100\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2550,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"95\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2551,\"textContent\":\"I \"}]}]},{\"nodeType\":1,\"id\":2552,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2553,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"133.33333333333331\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2554,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"128.33333333333331\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2555,\"textContent\":\"J \"}]}]},{\"nodeType\":1,\"id\":2556,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2557,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"133.33333333333326\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2558,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"125.33333333333326\"},\"childNodes\":[{\"nodeType\":3,\"id\":2559,\"textContent\":\"K \"}]}]},{\"nodeType\":1,\"id\":2560,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2561,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"333.3333333333333\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2562,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"325.3333333333333\"},\"childNodes\":[{\"nodeType\":3,\"id\":2563,\"textContent\":\"L \"}]}]},{\"nodeType\":1,\"id\":2564,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2565,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"300\",\"cy\":\"733.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2566,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"295\",\"y\":\"725.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2567,\"textContent\":\"M \"}]}]},{\"nodeType\":1,\"id\":2568,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2569,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"600\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2570,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"595\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2571,\"textContent\":\"N \"}]}]},{\"nodeType\":1,\"id\":2572,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2573,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"433.3333333333333\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2574,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"428.3333333333333\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2575,\"textContent\":\"O \"}]}]},{\"nodeType\":1,\"id\":2576,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2577,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"200\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2578,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"192\"},\"childNodes\":[{\"nodeType\":3,\"id\":2579,\"textContent\":\"P \"}]}]},{\"nodeType\":1,\"id\":2580,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2581,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"533.3333333333333\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2582,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"528.3333333333333\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2583,\"textContent\":\"Z \"}]}]},{\"nodeType\":1,\"id\":2584,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2585,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2586,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2587,\"textContent\":\"X \"}]}]}]}]}]}]},{\"nodeType\":3,\"id\":2588,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2589,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2590},{\"nodeType\":3,\"id\":2591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2592,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2593,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2594,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2595,\"textContent\":\" \"}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 215, dom: 933, initialDom: 1041",
  "javascriptErrors": []
}