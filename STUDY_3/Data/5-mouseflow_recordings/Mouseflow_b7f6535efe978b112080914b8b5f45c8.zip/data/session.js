var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "b7f6535efe978b112080914b8b5f45c8",
  "created": "2018-05-21T12:20:28.4387972-07:00",
  "lastActivity": "2018-05-21T12:22:59.9007972-07:00",
  "pageViews": [
    {
      "id": "052128893ae6a2c403d36109d6331d11389f3228",
      "startTime": "2018-05-21T12:20:28.4387972-07:00",
      "endTime": "2018-05-21T12:22:59.9007972-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/16",
      "visitTime": 151462,
      "engagementTime": 104634,
      "scroll": 100.0,
      "tags": [
        "form-interact",
        "submit"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 151462,
  "engagementTime": 104634,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.33",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact",
    "submit"
  ],
  "variables": [
    "SID=WKBNA",
    "CONDITION=111"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "0f65f430f2d7edcac09f59f7b0fb948e",
  "gdpr": false
}