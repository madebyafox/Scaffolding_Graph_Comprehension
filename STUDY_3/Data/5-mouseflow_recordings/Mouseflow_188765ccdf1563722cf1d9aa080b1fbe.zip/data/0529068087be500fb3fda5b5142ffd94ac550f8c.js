var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["0529068087be500fb3fda5b5142ffd94ac550f8c"] = {
  "startTime": "2018-05-29T17:02:07.1033377Z",
  "websitePageUrl": "/",
  "visitTime": 53676,
  "engagementTime": 39402,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1094,
  "tags": [],
  "session": {
    "id": "188765ccdf1563722cf1d9aa080b1fbe",
    "created": "2018-05-29T17:02:07.1033377+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.181",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/",
    "tags": [],
    "variables": [],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "c8e745f5449f864b04f5497b61819098",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/188765ccdf1563722cf1d9aa080b1fbe/play"
  },
  "events": [
    {
      "t": 7,
      "e": 7,
      "ty": 14,
      "x": 0,
      "y": 1093
    },
    {
      "t": 100,
      "e": 100,
      "ty": 0,
      "x": 1920,
      "y": 1094
    },
    {
      "t": 3501,
      "e": 3501,
      "ty": 2,
      "x": 267,
      "y": 2
    },
    {
      "t": 3502,
      "e": 3502,
      "ty": 41,
      "x": 9194,
      "y": 121,
      "ta": "html"
    },
    {
      "t": 3601,
      "e": 3601,
      "ty": 2,
      "x": 298,
      "y": 19
    },
    {
      "t": 3701,
      "e": 3701,
      "ty": 2,
      "x": 638,
      "y": 258
    },
    {
      "t": 3751,
      "e": 3751,
      "ty": 41,
      "x": 34760,
      "y": 31989,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 3801,
      "e": 3801,
      "ty": 2,
      "x": 1111,
      "y": 635
    },
    {
      "t": 3901,
      "e": 3901,
      "ty": 2,
      "x": 1121,
      "y": 642
    },
    {
      "t": 4001,
      "e": 4001,
      "ty": 2,
      "x": 1084,
      "y": 678
    },
    {
      "t": 4001,
      "e": 4001,
      "ty": 41,
      "x": 39566,
      "y": 43539,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 4101,
      "e": 4101,
      "ty": 2,
      "x": 1071,
      "y": 775
    },
    {
      "t": 4201,
      "e": 4201,
      "ty": 2,
      "x": 1062,
      "y": 799
    },
    {
      "t": 4251,
      "e": 4251,
      "ty": 41,
      "x": 38146,
      "y": 54107,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 4301,
      "e": 4301,
      "ty": 2,
      "x": 1058,
      "y": 815
    },
    {
      "t": 4386,
      "e": 4386,
      "ty": 3,
      "x": 1058,
      "y": 816,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 4401,
      "e": 4401,
      "ty": 2,
      "x": 1058,
      "y": 816
    },
    {
      "t": 4497,
      "e": 4497,
      "ty": 4,
      "x": 38146,
      "y": 54844,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 4498,
      "e": 4498,
      "ty": 5,
      "x": 1058,
      "y": 816,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 4500,
      "e": 4500,
      "ty": 41,
      "x": 38146,
      "y": 54844,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 4801,
      "e": 4801,
      "ty": 2,
      "x": 1071,
      "y": 835
    },
    {
      "t": 4900,
      "e": 4900,
      "ty": 2,
      "x": 1339,
      "y": 1030
    },
    {
      "t": 5001,
      "e": 5001,
      "ty": 2,
      "x": 1365,
      "y": 1049
    },
    {
      "t": 5001,
      "e": 5001,
      "ty": 41,
      "x": 46731,
      "y": 63344,
      "ta": "html > body"
    },
    {
      "t": 5101,
      "e": 5101,
      "ty": 2,
      "x": 1364,
      "y": 1050
    },
    {
      "t": 5251,
      "e": 5251,
      "ty": 41,
      "x": 46697,
      "y": 63405,
      "ta": "html > body"
    },
    {
      "t": 5601,
      "e": 5601,
      "ty": 2,
      "x": 1363,
      "y": 1041
    },
    {
      "t": 5701,
      "e": 5701,
      "ty": 2,
      "x": 1363,
      "y": 1039
    },
    {
      "t": 5750,
      "e": 5750,
      "ty": 41,
      "x": 46663,
      "y": 62431,
      "ta": "html > body"
    },
    {
      "t": 5800,
      "e": 5800,
      "ty": 2,
      "x": 1361,
      "y": 1032
    },
    {
      "t": 6000,
      "e": 6000,
      "ty": 41,
      "x": 46594,
      "y": 62309,
      "ta": "html > body"
    },
    {
      "t": 10000,
      "e": 10000,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 14500,
      "e": 11000,
      "ty": 2,
      "x": 1350,
      "y": 1041
    },
    {
      "t": 14501,
      "e": 11001,
      "ty": 41,
      "x": 46215,
      "y": 62857,
      "ta": "html > body"
    },
    {
      "t": 14530,
      "e": 11030,
      "ty": 40,
      "x": 0,
      "y": 0
    },
    {
      "t": 14600,
      "e": 11100,
      "ty": 2,
      "x": 1327,
      "y": 1091
    },
    {
      "t": 14900,
      "e": 11400,
      "ty": 2,
      "x": 1309,
      "y": 1062
    },
    {
      "t": 15000,
      "e": 11500,
      "ty": 2,
      "x": 1312,
      "y": 1059
    },
    {
      "t": 15000,
      "e": 11500,
      "ty": 41,
      "x": 44906,
      "y": 63952,
      "ta": "html > body"
    },
    {
      "t": 16250,
      "e": 12750,
      "ty": 41,
      "x": 44906,
      "y": 63892,
      "ta": "html > body"
    },
    {
      "t": 16301,
      "e": 12801,
      "ty": 2,
      "x": 1312,
      "y": 1058
    },
    {
      "t": 19200,
      "e": 15700,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 19200,
      "e": 15700,
      "ty": 2,
      "x": 1312,
      "y": 1124
    },
    {
      "t": 19250,
      "e": 15750,
      "ty": 41,
      "x": 44906,
      "y": 61823,
      "ta": "html > body"
    },
    {
      "t": 20001,
      "e": 16501,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 36200,
      "e": 20750,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 36301,
      "e": 20750,
      "ty": 1,
      "x": 0,
      "y": 12
    },
    {
      "t": 36400,
      "e": 20849,
      "ty": 1,
      "x": 0,
      "y": 16
    },
    {
      "t": 37282,
      "e": 21731,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 38800,
      "e": 23249,
      "ty": 2,
      "x": 1266,
      "y": 1127
    },
    {
      "t": 38900,
      "e": 23349,
      "ty": 2,
      "x": 1187,
      "y": 1106
    },
    {
      "t": 39001,
      "e": 23450,
      "ty": 41,
      "x": 40602,
      "y": 60826,
      "ta": "> div.masterdiv"
    },
    {
      "t": 46900,
      "e": 28450,
      "ty": 2,
      "x": 742,
      "y": 967
    },
    {
      "t": 47000,
      "e": 28550,
      "ty": 41,
      "x": 22067,
      "y": 58216,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 47100,
      "e": 28650,
      "ty": 2,
      "x": 792,
      "y": 964
    },
    {
      "t": 47200,
      "e": 28750,
      "ty": 2,
      "x": 1064,
      "y": 1004
    },
    {
      "t": 47251,
      "e": 28801,
      "ty": 41,
      "x": 39827,
      "y": 61401,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 47300,
      "e": 28850,
      "ty": 2,
      "x": 1103,
      "y": 1013
    },
    {
      "t": 47501,
      "e": 29051,
      "ty": 2,
      "x": 1091,
      "y": 1007
    },
    {
      "t": 47501,
      "e": 29051,
      "ty": 41,
      "x": 39236,
      "y": 60986,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 47600,
      "e": 29150,
      "ty": 2,
      "x": 1067,
      "y": 1001
    },
    {
      "t": 47700,
      "e": 29250,
      "ty": 2,
      "x": 1035,
      "y": 1002
    },
    {
      "t": 47750,
      "e": 29300,
      "ty": 41,
      "x": 35251,
      "y": 60501,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 47800,
      "e": 29350,
      "ty": 2,
      "x": 968,
      "y": 978
    },
    {
      "t": 47900,
      "e": 29450,
      "ty": 2,
      "x": 951,
      "y": 970
    },
    {
      "t": 48000,
      "e": 29550,
      "ty": 2,
      "x": 952,
      "y": 973
    },
    {
      "t": 48001,
      "e": 29551,
      "ty": 41,
      "x": 32398,
      "y": 58631,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 48100,
      "e": 29650,
      "ty": 2,
      "x": 949,
      "y": 978
    },
    {
      "t": 48200,
      "e": 29750,
      "ty": 2,
      "x": 948,
      "y": 978
    },
    {
      "t": 48250,
      "e": 29800,
      "ty": 41,
      "x": 32103,
      "y": 58978,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 48300,
      "e": 29850,
      "ty": 2,
      "x": 946,
      "y": 978
    },
    {
      "t": 48501,
      "e": 30051,
      "ty": 2,
      "x": 945,
      "y": 977
    },
    {
      "t": 48501,
      "e": 30051,
      "ty": 41,
      "x": 32054,
      "y": 58908,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 48600,
      "e": 30150,
      "ty": 2,
      "x": 946,
      "y": 974
    },
    {
      "t": 48700,
      "e": 30250,
      "ty": 2,
      "x": 948,
      "y": 973
    },
    {
      "t": 48750,
      "e": 30300,
      "ty": 41,
      "x": 32250,
      "y": 58562,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 48801,
      "e": 30351,
      "ty": 2,
      "x": 949,
      "y": 972
    },
    {
      "t": 48900,
      "e": 30450,
      "ty": 2,
      "x": 949,
      "y": 971
    },
    {
      "t": 49001,
      "e": 30551,
      "ty": 41,
      "x": 32250,
      "y": 58493,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 49101,
      "e": 30651,
      "ty": 2,
      "x": 949,
      "y": 970
    },
    {
      "t": 49200,
      "e": 30750,
      "ty": 2,
      "x": 917,
      "y": 960
    },
    {
      "t": 49250,
      "e": 30800,
      "ty": 41,
      "x": 31119,
      "y": 57246,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 49300,
      "e": 30850,
      "ty": 2,
      "x": 929,
      "y": 951
    },
    {
      "t": 49500,
      "e": 31050,
      "ty": 41,
      "x": 31266,
      "y": 57108,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 50000,
      "e": 31550,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 51500,
      "e": 37226,
      "ty": 0,
      "x": 1920,
      "y": 1094
    },
    {
      "t": 51500,
      "e": 37226,
      "ty": 2,
      "x": 929,
      "y": 885
    },
    {
      "t": 51501,
      "e": 37227,
      "ty": 41,
      "x": 31266,
      "y": 58514,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 52600,
      "e": 38326,
      "ty": 2,
      "x": 677,
      "y": 829
    },
    {
      "t": 52701,
      "e": 38427,
      "ty": 2,
      "x": 10,
      "y": 325
    },
    {
      "t": 52750,
      "e": 38476,
      "ty": 41,
      "x": 2307,
      "y": 5719,
      "ta": "> div.masterdiv"
    },
    {
      "t": 52776,
      "e": 38502,
      "ty": 40,
      "x": 0,
      "y": 0
    },
    {
      "t": 52801,
      "e": 38527,
      "ty": 2,
      "x": 108,
      "y": 23
    },
    {
      "t": 53000,
      "e": 38726,
      "ty": 41,
      "x": 3443,
      "y": 912,
      "ta": "> div.masterdiv"
    },
    {
      "t": 53676,
      "e": 39402,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":56},{\"id\":57},{\"id\":58},{\"id\":59}],[],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":60,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"parentNode\":{\"id\":55}},{\"nodeType\":8,\"id\":61,\"previousSibling\":{\"id\":60},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":62,\"textContent\":\" \",\"previousSibling\":{\"id\":61},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":63,\"textContent\":\" \",\"parentNode\":{\"id\":60}},{\"nodeType\":1,\"id\":64,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":63},\"parentNode\":{\"id\":60}},{\"nodeType\":3,\"id\":65,\"textContent\":\" \",\"previousSibling\":{\"id\":64},\"parentNode\":{\"id\":60}},{\"nodeType\":8,\"id\":66,\"previousSibling\":{\"id\":65},\"parentNode\":{\"id\":60}},{\"nodeType\":3,\"id\":67,\"textContent\":\" \",\"previousSibling\":{\"id\":66},\"parentNode\":{\"id\":60}},{\"nodeType\":1,\"id\":68,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":67},\"parentNode\":{\"id\":60}},{\"nodeType\":8,\"id\":69,\"previousSibling\":{\"id\":68},\"parentNode\":{\"id\":60}},{\"nodeType\":3,\"id\":70,\"textContent\":\" \",\"previousSibling\":{\"id\":69},\"parentNode\":{\"id\":60}},{\"nodeType\":1,\"id\":71,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":70},\"parentNode\":{\"id\":60}},{\"nodeType\":8,\"id\":72,\"previousSibling\":{\"id\":71},\"parentNode\":{\"id\":60}},{\"nodeType\":3,\"id\":73,\"textContent\":\" \",\"previousSibling\":{\"id\":72},\"parentNode\":{\"id\":60}},{\"nodeType\":3,\"id\":74,\"textContent\":\" \",\"parentNode\":{\"id\":64}},{\"nodeType\":1,\"id\":75,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":74},\"parentNode\":{\"id\":64}},{\"nodeType\":3,\"id\":76,\"textContent\":\" \",\"previousSibling\":{\"id\":75},\"parentNode\":{\"id\":64}},{\"nodeType\":3,\"id\":77,\"textContent\":\" \",\"parentNode\":{\"id\":75}},{\"nodeType\":1,\"id\":78,\"tagName\":\"H3\",\"attributes\":{},\"previousSibling\":{\"id\":77},\"parentNode\":{\"id\":75}},{\"nodeType\":3,\"id\":79,\"textContent\":\" \",\"previousSibling\":{\"id\":78},\"parentNode\":{\"id\":75}},{\"nodeType\":3,\"id\":80,\"textContent\":\"UNIVERSITY OF CALIFORNIA, SAN DIEGO CONSENT TO ACT AS A RESEARCH SUBJECT\",\"parentNode\":{\"id\":78}},{\"nodeType\":3,\"id\":81,\"textContent\":\" \",\"parentNode\":{\"id\":68}},{\"nodeType\":1,\"id\":82,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":81},\"parentNode\":{\"id\":68}},{\"nodeType\":3,\"id\":83,\"textContent\":\" \",\"previousSibling\":{\"id\":82},\"parentNode\":{\"id\":68}},{\"nodeType\":3,\"id\":84,\"textContent\":\" \",\"parentNode\":{\"id\":82}},{\"nodeType\":1,\"id\":85,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":84},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":86,\"textContent\":\" \",\"previousSibling\":{\"id\":85},\"parentNode\":{\"id\":82}},{\"nodeType\":1,\"id\":87,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":86},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":88,\"textContent\":\" \",\"previousSibling\":{\"id\":87},\"parentNode\":{\"id\":82}},{\"nodeType\":1,\"id\":89,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":88},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":90,\"textContent\":\" \",\"previousSibling\":{\"id\":89},\"parentNode\":{\"id\":82}},{\"nodeType\":1,\"id\":91,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic\"},\"previousSibling\":{\"id\":90},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":92,\"textContent\":\" \",\"previousSibling\":{\"id\":91},\"parentNode\":{\"id\":82}},{\"nodeType\":8,\"id\":93,\"previousSibling\":{\"id\":92},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":94,\"textContent\":\" \",\"previousSibling\":{\"id\":93},\"parentNode\":{\"id\":82}},{\"nodeType\":1,\"id\":95,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control-group centered\"},\"previousSibling\":{\"id\":94},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":96,\"textContent\":\" \",\"previousSibling\":{\"id\":95},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":97,\"textContent\":\" You are being invited to participate in a research study titled Learning Diagrams: Evaluating Learning With External Representations. This study is being done by Amy Fox and Dr. Jim Hollan from the University of California - San Diego (UCSD). You were selected to participate in this study because we think you might use graphs and diagrams in your work and educational activities.\",\"parentNode\":{\"id\":85}},{\"nodeType\":3,\"id\":98,\"textContent\":\" The purpose of this research study is to understand how humans try to make sense of charts, diagrams and graphs that are unconventional and that we may not have seen before. If you agree to take part in this study, you will be asked to read a series of instructions and answer a series of questions. The entire study should take no more than 60 minutes to complete. The researchers expect there will be no direct benefit to you from this research, other than any enjoyment you might have in contributing to research. We hope that you will find the questions interesting, though at times you may feel bored. The investigator(s), however, may learn more about how different types of instructions trigger different levels of understanding when using graphs. There are minimal risks associated with this research study, including a loss of confidentiality of your participation. The researchers are taking all required steps to protect your confidentiality, including storing all of your responses to questions in a secure, encrypted database separate from any information that can personally identify you. The only records containing your name and other personally identifying information are those stored in the system through which you signed up to participate in the study. These records will never be connected with the data we collect from you today. Research records will be kept confidential to the extent allowed by law and may be reviewed by the UCSD Institutional Review Board.\",\"parentNode\":{\"id\":87}},{\"nodeType\":3,\"id\":99,\"textContent\":\" Your participation in this study is completely voluntary and you can withdraw at any time by notifying the researcher that you wish to end your participation. Choosing not to participate or withdrawing will result in no penalty or loss of benefits to which you are entitled. You are free to skip any questions that you choose. If you have questions about this project or if you have a research-related problem, you may contact the researcher(s), Amy Fox: 919 886 4455: a2fox@ucsd.edu, and Jim Hollan: hollan@ucsd.edu. If you have any questions concerning your rights as a research subject, you may contact the UCSD Human Research Protections Program Office at 858-246-HRPP (858-246-4777). \",\"parentNode\":{\"id\":89}},{\"nodeType\":3,\"id\":100,\"textContent\":\" By clicking “I agree” below you are indicating that: you are at least 18 years old, have read this consent form, and agree to participate in this research study. If you do not wish to participate in the study, please notify the researcher now.\",\"parentNode\":{\"id\":91}},{\"nodeType\":3,\"id\":101,\"textContent\":\" \",\"parentNode\":{\"id\":95}},{\"nodeType\":1,\"id\":102,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"centered control control-checkbox\"},\"previousSibling\":{\"id\":101},\"parentNode\":{\"id\":95}},{\"nodeType\":3,\"id\":103,\"textContent\":\" \",\"previousSibling\":{\"id\":102},\"parentNode\":{\"id\":95}},{\"nodeType\":3,\"id\":104,\"textContent\":\" I agree to take part in this study. \",\"parentNode\":{\"id\":102}},{\"nodeType\":1,\"id\":105,\"tagName\":\"INPUT\",\"attributes\":{\"id\":\"consent_checkbox\",\"type\":\"checkbox\"},\"previousSibling\":{\"id\":104},\"parentNode\":{\"id\":102}},{\"nodeType\":3,\"id\":106,\"textContent\":\" \",\"previousSibling\":{\"id\":105},\"parentNode\":{\"id\":102}},{\"nodeType\":1,\"id\":107,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"},\"previousSibling\":{\"id\":106},\"parentNode\":{\"id\":102}},{\"nodeType\":3,\"id\":108,\"textContent\":\" \",\"previousSibling\":{\"id\":107},\"parentNode\":{\"id\":102}},{\"nodeType\":3,\"id\":109,\"textContent\":\" \",\"parentNode\":{\"id\":71}},{\"nodeType\":1,\"id\":110,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":109},\"parentNode\":{\"id\":71}},{\"nodeType\":3,\"id\":111,\"textContent\":\" \",\"previousSibling\":{\"id\":110},\"parentNode\":{\"id\":71}},{\"nodeType\":3,\"id\":112,\"textContent\":\"START\",\"parentNode\":{\"id\":110}}],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":1,\"id\":59,\"tagName\":\"IMG\",\"attributes\":{\"src\":\"img/phone.png\",\"id\":\"jspsych-single-stim-stimulus\"}}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 120, dom: 274, initialDom: 278",
  "javascriptErrors": []
}