var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "e3a8b14e05647985a0f6430f7a40774e",
  "created": "2018-05-22T13:05:43.8568689-07:00",
  "lastActivity": "2018-05-22T13:07:01.4838689-07:00",
  "pageViews": [
    {
      "id": "052244448500fae3f07f0fcb5a581c5e5d6327f1",
      "startTime": "2018-05-22T13:05:43.8568689-07:00",
      "endTime": "2018-05-22T13:07:01.4838689-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/2",
      "visitTime": 77627,
      "engagementTime": 51134,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 77627,
  "engagementTime": 51134,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.27",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=ZKB08",
    "CONDITION=121"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "0610e046ac6f76870aff98304fb3fcb2",
  "gdpr": false
}