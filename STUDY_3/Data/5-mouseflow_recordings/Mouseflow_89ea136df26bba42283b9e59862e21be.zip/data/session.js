var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "89ea136df26bba42283b9e59862e21be",
  "created": "2018-05-21T10:10:27.1853478-07:00",
  "lastActivity": "2018-05-21T10:10:58.6314837-07:00",
  "pageViews": [
    {
      "id": "05212718c3b8af031b0ea6629947c48787e46b9b",
      "startTime": "2018-05-21T10:10:27.1853478-07:00",
      "endTime": "2018-05-21T10:10:58.6314837-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/1",
      "visitTime": 31617,
      "engagementTime": 31240,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 31617,
  "engagementTime": 31240,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.28",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=RGJZL",
    "CONDITION=121"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "c1f4796d16465b521f6100c2a01e763b",
  "gdpr": false
}