var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["052244930043692490f37400ec7d7fffdbcbda17"] = {
  "startTime": "2018-05-22T20:13:44.08219Z",
  "websitePageUrl": "/16",
  "visitTime": 87884,
  "engagementTime": 85047,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1200,
  "tags": [
    "form-interact",
    "submit"
  ],
  "session": {
    "id": "a3614ba759c5ca4c6fa5108187132db8",
    "created": "2018-05-22T20:13:44.08219+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.181",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/16",
    "tags": [
      "form-interact",
      "submit"
    ],
    "variables": [
      "SID=VT5BG",
      "CONDITION=121"
    ],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "cb53068812f6dd6dce351097b34a455f",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/a3614ba759c5ca4c6fa5108187132db8/play"
  },
  "events": [
    {
      "t": 1,
      "e": 1,
      "ty": 14,
      "x": 0,
      "y": 1199
    },
    {
      "t": 101,
      "e": 101,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 693,
      "e": 693,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 1200,
      "e": 1200,
      "ty": 2,
      "x": 515,
      "y": 735
    },
    {
      "t": 1251,
      "e": 1251,
      "ty": 41,
      "x": 45627,
      "y": 39165,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 1300,
      "e": 1300,
      "ty": 2,
      "x": 496,
      "y": 704
    },
    {
      "t": 1400,
      "e": 1400,
      "ty": 2,
      "x": 495,
      "y": 701
    },
    {
      "t": 1501,
      "e": 1501,
      "ty": 41,
      "x": 44728,
      "y": 38390,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 2210,
      "e": 2210,
      "ty": 2,
      "x": 490,
      "y": 691
    },
    {
      "t": 2250,
      "e": 2250,
      "ty": 41,
      "x": 44391,
      "y": 37780,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 2300,
      "e": 2300,
      "ty": 2,
      "x": 493,
      "y": 692
    },
    {
      "t": 2400,
      "e": 2400,
      "ty": 2,
      "x": 493,
      "y": 695
    },
    {
      "t": 2501,
      "e": 2501,
      "ty": 41,
      "x": 44503,
      "y": 38057,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 2600,
      "e": 2600,
      "ty": 2,
      "x": 495,
      "y": 696
    },
    {
      "t": 2700,
      "e": 2700,
      "ty": 2,
      "x": 501,
      "y": 698
    },
    {
      "t": 2750,
      "e": 2750,
      "ty": 41,
      "x": 46077,
      "y": 38224,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 2800,
      "e": 2800,
      "ty": 2,
      "x": 522,
      "y": 692
    },
    {
      "t": 2900,
      "e": 2900,
      "ty": 2,
      "x": 548,
      "y": 674
    },
    {
      "t": 3000,
      "e": 3000,
      "ty": 2,
      "x": 549,
      "y": 673
    },
    {
      "t": 3002,
      "e": 3002,
      "ty": 41,
      "x": 50798,
      "y": 36839,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 3200,
      "e": 3200,
      "ty": 2,
      "x": 551,
      "y": 650
    },
    {
      "t": 3251,
      "e": 3251,
      "ty": 41,
      "x": 51023,
      "y": 34844,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 3301,
      "e": 3301,
      "ty": 2,
      "x": 552,
      "y": 631
    },
    {
      "t": 3400,
      "e": 3400,
      "ty": 2,
      "x": 552,
      "y": 616
    },
    {
      "t": 3501,
      "e": 3501,
      "ty": 2,
      "x": 552,
      "y": 608
    },
    {
      "t": 3501,
      "e": 3501,
      "ty": 41,
      "x": 51135,
      "y": 63443,
      "ta": "#.strategy"
    },
    {
      "t": 4200,
      "e": 4200,
      "ty": 2,
      "x": 556,
      "y": 607
    },
    {
      "t": 4250,
      "e": 4250,
      "ty": 41,
      "x": 51698,
      "y": 61762,
      "ta": "#.strategy"
    },
    {
      "t": 4300,
      "e": 4300,
      "ty": 2,
      "x": 557,
      "y": 605
    },
    {
      "t": 4601,
      "e": 4601,
      "ty": 2,
      "x": 558,
      "y": 604
    },
    {
      "t": 4615,
      "e": 4615,
      "ty": 6,
      "x": 560,
      "y": 602,
      "ta": "#strategyAnswer"
    },
    {
      "t": 4700,
      "e": 4700,
      "ty": 2,
      "x": 566,
      "y": 591
    },
    {
      "t": 4750,
      "e": 4750,
      "ty": 41,
      "x": 53384,
      "y": 43095,
      "ta": "#strategyAnswer"
    },
    {
      "t": 4800,
      "e": 4800,
      "ty": 2,
      "x": 572,
      "y": 572
    },
    {
      "t": 5001,
      "e": 5001,
      "ty": 41,
      "x": 53384,
      "y": 39859,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10001,
      "e": 10001,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 10101,
      "e": 10001,
      "ty": 3,
      "x": 572,
      "y": 572,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10102,
      "e": 10002,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10236,
      "e": 10136,
      "ty": 4,
      "x": 53384,
      "y": 39859,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10236,
      "e": 10136,
      "ty": 5,
      "x": 572,
      "y": 572,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11146,
      "e": 11046,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 11321,
      "e": 11221,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 11322,
      "e": 11222,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11464,
      "e": 11364,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "W"
    },
    {
      "t": 11480,
      "e": 11380,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "W"
    },
    {
      "t": 11633,
      "e": 11533,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 11634,
      "e": 11534,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11745,
      "e": 11645,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 11745,
      "e": 11645,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11800,
      "e": 11700,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Whi"
    },
    {
      "t": 11889,
      "e": 11789,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Whi"
    },
    {
      "t": 11993,
      "e": 11893,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 11994,
      "e": 11894,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12041,
      "e": 11941,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Whic"
    },
    {
      "t": 12402,
      "e": 12302,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 12402,
      "e": 12302,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12513,
      "e": 12413,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 12576,
      "e": 12476,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 12577,
      "e": 12477,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12672,
      "e": 12572,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 12977,
      "e": 12877,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 12978,
      "e": 12878,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13065,
      "e": 12965,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 13153,
      "e": 13053,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "86"
    },
    {
      "t": 13154,
      "e": 13054,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13264,
      "e": 13164,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||v"
    },
    {
      "t": 13312,
      "e": 13212,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 13313,
      "e": 13213,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13433,
      "e": 13333,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 13434,
      "e": 13334,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13513,
      "e": 13413,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||er"
    },
    {
      "t": 13545,
      "e": 13445,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 13576,
      "e": 13476,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 13577,
      "e": 13477,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13697,
      "e": 13597,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 13777,
      "e": 13677,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 13778,
      "e": 13678,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13872,
      "e": 13772,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 13873,
      "e": 13773,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13897,
      "e": 13797,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||sh"
    },
    {
      "t": 13969,
      "e": 13869,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 13969,
      "e": 13869,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14024,
      "e": 13924,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 14089,
      "e": 13989,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 14321,
      "e": 14221,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 14322,
      "e": 14222,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14409,
      "e": 14309,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||f"
    },
    {
      "t": 14537,
      "e": 14437,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 14538,
      "e": 14438,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14624,
      "e": 14524,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 14648,
      "e": 14548,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 14648,
      "e": 14548,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14752,
      "e": 14652,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 14857,
      "e": 14757,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 14858,
      "e": 14758,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14976,
      "e": 14876,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 15041,
      "e": 14941,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 15041,
      "e": 14941,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15137,
      "e": 15037,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 15138,
      "e": 15038,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15145,
      "e": 15045,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s "
    },
    {
      "t": 15225,
      "e": 15125,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 16121,
      "e": 16021,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 16121,
      "e": 16021,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16200,
      "e": 16100,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 16257,
      "e": 16157,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 16258,
      "e": 16158,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16328,
      "e": 16228,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 16473,
      "e": 16373,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 16474,
      "e": 16374,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16569,
      "e": 16469,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 16706,
      "e": 16606,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 16706,
      "e": 16606,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16784,
      "e": 16684,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 17169,
      "e": 17069,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 17171,
      "e": 17071,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17281,
      "e": 17181,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 17336,
      "e": 17236,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 17337,
      "e": 17237,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17417,
      "e": 17317,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 17498,
      "e": 17398,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 17498,
      "e": 17398,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17576,
      "e": 17476,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 17577,
      "e": 17477,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17593,
      "e": 17493,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||al"
    },
    {
      "t": 17688,
      "e": 17588,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 17761,
      "e": 17661,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 17762,
      "e": 17662,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17841,
      "e": 17741,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 18289,
      "e": 18189,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 18290,
      "e": 18190,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18369,
      "e": 18269,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||y"
    },
    {
      "t": 18489,
      "e": 18389,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 18489,
      "e": 18389,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18560,
      "e": 18460,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 18826,
      "e": 18726,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 18826,
      "e": 18726,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18905,
      "e": 18805,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||c"
    },
    {
      "t": 19000,
      "e": 18900,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 19001,
      "e": 18901,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19064,
      "e": 18964,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 19322,
      "e": 19222,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 19322,
      "e": 19222,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19377,
      "e": 19277,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 19465,
      "e": 19365,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 19466,
      "e": 19366,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19520,
      "e": 19420,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 19552,
      "e": 19452,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 19552,
      "e": 19452,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19608,
      "e": 19508,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 19745,
      "e": 19645,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 19747,
      "e": 19647,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19848,
      "e": 19748,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||c"
    },
    {
      "t": 20002,
      "e": 19902,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 20016,
      "e": 19916,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 20016,
      "e": 19916,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20112,
      "e": 20012,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 20257,
      "e": 20157,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 20257,
      "e": 20157,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20337,
      "e": 20237,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 20401,
      "e": 20301,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 20401,
      "e": 20301,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20537,
      "e": 20437,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 20545,
      "e": 20445,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 20546,
      "e": 20446,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20632,
      "e": 20532,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 21938,
      "e": 21838,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 21938,
      "e": 21838,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22000,
      "e": 21900,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 22104,
      "e": 22004,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 22105,
      "e": 22005,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22185,
      "e": 22085,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 22824,
      "e": 22724,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 22864,
      "e": 22764,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Which ever shift is diagonally connected t"
    },
    {
      "t": 22953,
      "e": 22853,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 23009,
      "e": 22909,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Which ever shift is diagonally connected "
    },
    {
      "t": 24785,
      "e": 24685,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 24786,
      "e": 24686,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24848,
      "e": 24748,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 24904,
      "e": 24804,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 24904,
      "e": 24804,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25016,
      "e": 24916,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 25018,
      "e": 24918,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25040,
      "e": 24940,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o "
    },
    {
      "t": 25088,
      "e": 24988,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 25203,
      "e": 25103,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Which ever shift is diagonally connected to "
    },
    {
      "t": 25258,
      "e": 25158,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 25258,
      "e": 25158,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25344,
      "e": 25244,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 25361,
      "e": 25261,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 25361,
      "e": 25261,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25440,
      "e": 25340,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 25522,
      "e": 25422,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 25522,
      "e": 25422,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25600,
      "e": 25500,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 25616,
      "e": 25516,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 25617,
      "e": 25517,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25665,
      "e": 25565,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 25802,
      "e": 25702,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Which ever shift is diagonally connected to the "
    },
    {
      "t": 25969,
      "e": 25869,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 25969,
      "e": 25869,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26024,
      "e": 25924,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 26024,
      "e": 25924,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26080,
      "e": 25980,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||12"
    },
    {
      "t": 26120,
      "e": 26020,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 26617,
      "e": 26517,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 26617,
      "e": 26517,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26744,
      "e": 26644,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 26881,
      "e": 26781,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 26882,
      "e": 26782,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26986,
      "e": 26886,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 27089,
      "e": 26989,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 27090,
      "e": 26990,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27160,
      "e": 27060,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 27993,
      "e": 27893,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 27994,
      "e": 27894,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28119,
      "e": 28019,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||x"
    },
    {
      "t": 28263,
      "e": 28163,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "189"
    },
    {
      "t": 28263,
      "e": 28163,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28342,
      "e": 28242,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||-"
    },
    {
      "t": 29759,
      "e": 29659,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 29821,
      "e": 29721,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Which ever shift is diagonally connected to the 12pm x"
    },
    {
      "t": 29910,
      "e": 29810,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 29974,
      "e": 29874,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Which ever shift is diagonally connected to the 12pm "
    },
    {
      "t": 29998,
      "e": 29898,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 30558,
      "e": 30458,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 30559,
      "e": 30459,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30687,
      "e": 30587,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 30719,
      "e": 30619,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 30719,
      "e": 30619,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30815,
      "e": 30715,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 30871,
      "e": 30771,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 30872,
      "e": 30772,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30942,
      "e": 30842,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 31006,
      "e": 30906,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 31006,
      "e": 30906,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31070,
      "e": 30970,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 31078,
      "e": 30978,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 31079,
      "e": 30979,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31159,
      "e": 31059,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 31207,
      "e": 31107,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 31207,
      "e": 31107,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31269,
      "e": 31169,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 31270,
      "e": 31170,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31294,
      "e": 31194,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e "
    },
    {
      "t": 31341,
      "e": 31241,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 32702,
      "e": 32602,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 32703,
      "e": 32603,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32798,
      "e": 32698,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||x"
    },
    {
      "t": 32990,
      "e": 32890,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "189"
    },
    {
      "t": 32991,
      "e": 32891,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33078,
      "e": 32978,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||-"
    },
    {
      "t": 33423,
      "e": 33323,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 33423,
      "e": 33323,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33510,
      "e": 33410,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 33783,
      "e": 33683,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 33783,
      "e": 33683,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33862,
      "e": 33762,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||x"
    },
    {
      "t": 33934,
      "e": 33834,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 33935,
      "e": 33835,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33990,
      "e": 33890,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 33998,
      "e": 33898,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 33998,
      "e": 33898,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34101,
      "e": 34001,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 34999,
      "e": 34899,
      "ty": 2,
      "x": 571,
      "y": 572
    },
    {
      "t": 34999,
      "e": 34899,
      "ty": 41,
      "x": 53271,
      "y": 39859,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35399,
      "e": 35299,
      "ty": 2,
      "x": 571,
      "y": 573
    },
    {
      "t": 35499,
      "e": 35399,
      "ty": 2,
      "x": 559,
      "y": 586
    },
    {
      "t": 35499,
      "e": 35399,
      "ty": 41,
      "x": 51922,
      "y": 51186,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35571,
      "e": 35471,
      "ty": 7,
      "x": 545,
      "y": 613,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35598,
      "e": 35498,
      "ty": 2,
      "x": 540,
      "y": 623
    },
    {
      "t": 35698,
      "e": 35598,
      "ty": 2,
      "x": 465,
      "y": 699
    },
    {
      "t": 35748,
      "e": 35648,
      "ty": 41,
      "x": 41019,
      "y": 38445,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 35799,
      "e": 35699,
      "ty": 2,
      "x": 462,
      "y": 702
    },
    {
      "t": 35898,
      "e": 35798,
      "ty": 2,
      "x": 451,
      "y": 699
    },
    {
      "t": 35955,
      "e": 35855,
      "ty": 6,
      "x": 446,
      "y": 687,
      "ta": "#strategyButton"
    },
    {
      "t": 35998,
      "e": 35898,
      "ty": 2,
      "x": 444,
      "y": 681
    },
    {
      "t": 35998,
      "e": 35898,
      "ty": 41,
      "x": 57564,
      "y": 50626,
      "ta": "#strategyButton"
    },
    {
      "t": 36099,
      "e": 35999,
      "ty": 2,
      "x": 444,
      "y": 678
    },
    {
      "t": 36248,
      "e": 36148,
      "ty": 41,
      "x": 57564,
      "y": 44844,
      "ta": "#strategyButton"
    },
    {
      "t": 37598,
      "e": 37498,
      "ty": 2,
      "x": 445,
      "y": 675
    },
    {
      "t": 37698,
      "e": 37598,
      "ty": 2,
      "x": 446,
      "y": 674
    },
    {
      "t": 37749,
      "e": 37649,
      "ty": 41,
      "x": 59203,
      "y": 37134,
      "ta": "#strategyButton"
    },
    {
      "t": 37798,
      "e": 37698,
      "ty": 2,
      "x": 447,
      "y": 674
    },
    {
      "t": 38772,
      "e": 38672,
      "ty": 3,
      "x": 447,
      "y": 674,
      "ta": "#strategyButton"
    },
    {
      "t": 38773,
      "e": 38673,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Which ever shift is diagonally connected to the 12pm on the x-axis"
    },
    {
      "t": 38774,
      "e": 38674,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38774,
      "e": 38674,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 38962,
      "e": 38862,
      "ty": 4,
      "x": 59203,
      "y": 37134,
      "ta": "#strategyButton"
    },
    {
      "t": 38975,
      "e": 38875,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 38976,
      "e": 38876,
      "ty": 5,
      "x": 447,
      "y": 674,
      "ta": "#strategyButton"
    },
    {
      "t": 38981,
      "e": 38881,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 39979,
      "e": 39879,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 39999,
      "e": 39899,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 40599,
      "e": 40499,
      "ty": 2,
      "x": 576,
      "y": 636
    },
    {
      "t": 40698,
      "e": 40598,
      "ty": 2,
      "x": 904,
      "y": 598
    },
    {
      "t": 40749,
      "e": 40649,
      "ty": 41,
      "x": 20763,
      "y": 11274,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 40799,
      "e": 40699,
      "ty": 2,
      "x": 904,
      "y": 599
    },
    {
      "t": 40899,
      "e": 40799,
      "ty": 2,
      "x": 906,
      "y": 598
    },
    {
      "t": 40998,
      "e": 40898,
      "ty": 2,
      "x": 909,
      "y": 595
    },
    {
      "t": 40999,
      "e": 40899,
      "ty": 41,
      "x": 21845,
      "y": 8456,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 41075,
      "e": 40975,
      "ty": 6,
      "x": 922,
      "y": 574,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 41099,
      "e": 40999,
      "ty": 2,
      "x": 922,
      "y": 574
    },
    {
      "t": 41198,
      "e": 41098,
      "ty": 2,
      "x": 924,
      "y": 568
    },
    {
      "t": 41226,
      "e": 41126,
      "ty": 3,
      "x": 925,
      "y": 567,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 41227,
      "e": 41127,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 41249,
      "e": 41149,
      "ty": 41,
      "x": 25305,
      "y": 34327,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 41298,
      "e": 41198,
      "ty": 4,
      "x": 25305,
      "y": 28086,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 41299,
      "e": 41199,
      "ty": 5,
      "x": 925,
      "y": 563,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 41301,
      "e": 41201,
      "ty": 2,
      "x": 925,
      "y": 563
    },
    {
      "t": 41499,
      "e": 41399,
      "ty": 41,
      "x": 25305,
      "y": 28086,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 42311,
      "e": 42211,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "97"
    },
    {
      "t": 42311,
      "e": 42211,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 42366,
      "e": 42266,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "1"
    },
    {
      "t": 42462,
      "e": 42362,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "105"
    },
    {
      "t": 42463,
      "e": 42363,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 42550,
      "e": 42450,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "19"
    },
    {
      "t": 43926,
      "e": 43826,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "9"
    },
    {
      "t": 43928,
      "e": 43828,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "19"
    },
    {
      "t": 43928,
      "e": 43828,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 43928,
      "e": 43828,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 44006,
      "e": 43906,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": ""
    },
    {
      "t": 44935,
      "e": 44835,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 45159,
      "e": 45059,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "85"
    },
    {
      "t": 45159,
      "e": 45059,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 45229,
      "e": 45129,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "U"
    },
    {
      "t": 45318,
      "e": 45218,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "83"
    },
    {
      "t": 45318,
      "e": 45218,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 45421,
      "e": 45321,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "65"
    },
    {
      "t": 45421,
      "e": 45321,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 45453,
      "e": 45353,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "USA"
    },
    {
      "t": 45550,
      "e": 45450,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "USA"
    },
    {
      "t": 45566,
      "e": 45466,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "USA"
    },
    {
      "t": 46128,
      "e": 46028,
      "ty": 7,
      "x": 940,
      "y": 585,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 46163,
      "e": 46063,
      "ty": 6,
      "x": 944,
      "y": 677,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 46196,
      "e": 46096,
      "ty": 7,
      "x": 945,
      "y": 728,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 46198,
      "e": 46098,
      "ty": 2,
      "x": 945,
      "y": 728
    },
    {
      "t": 46249,
      "e": 46149,
      "ty": 41,
      "x": 32509,
      "y": 40384,
      "ta": "html > body"
    },
    {
      "t": 46298,
      "e": 46198,
      "ty": 2,
      "x": 953,
      "y": 759
    },
    {
      "t": 46380,
      "e": 46280,
      "ty": 6,
      "x": 973,
      "y": 707,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 46397,
      "e": 46297,
      "ty": 7,
      "x": 982,
      "y": 658,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 46397,
      "e": 46297,
      "ty": 6,
      "x": 982,
      "y": 658,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 46398,
      "e": 46298,
      "ty": 2,
      "x": 982,
      "y": 658
    },
    {
      "t": 46412,
      "e": 46312,
      "ty": 7,
      "x": 990,
      "y": 641,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 46499,
      "e": 46399,
      "ty": 2,
      "x": 992,
      "y": 637
    },
    {
      "t": 46499,
      "e": 46399,
      "ty": 41,
      "x": 39796,
      "y": 38052,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 46580,
      "e": 46480,
      "ty": 6,
      "x": 983,
      "y": 676,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 46597,
      "e": 46497,
      "ty": 7,
      "x": 969,
      "y": 709,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 46599,
      "e": 46499,
      "ty": 2,
      "x": 969,
      "y": 709
    },
    {
      "t": 46699,
      "e": 46599,
      "ty": 2,
      "x": 964,
      "y": 724
    },
    {
      "t": 46746,
      "e": 46646,
      "ty": 6,
      "x": 971,
      "y": 704,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 46748,
      "e": 46648,
      "ty": 41,
      "x": 38694,
      "y": 55605,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 46799,
      "e": 46699,
      "ty": 2,
      "x": 975,
      "y": 695
    },
    {
      "t": 46899,
      "e": 46799,
      "ty": 2,
      "x": 980,
      "y": 683
    },
    {
      "t": 46922,
      "e": 46822,
      "ty": 3,
      "x": 980,
      "y": 683,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 46924,
      "e": 46824,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "USA"
    },
    {
      "t": 46924,
      "e": 46824,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 46924,
      "e": 46824,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 46993,
      "e": 46893,
      "ty": 4,
      "x": 44363,
      "y": 11915,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 46994,
      "e": 46894,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 46995,
      "e": 46895,
      "ty": 5,
      "x": 982,
      "y": 682,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 46995,
      "e": 46895,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 46999,
      "e": 46899,
      "ty": 2,
      "x": 982,
      "y": 682
    },
    {
      "t": 46999,
      "e": 46899,
      "ty": 41,
      "x": 33542,
      "y": 37337,
      "ta": "html > body"
    },
    {
      "t": 47099,
      "e": 46999,
      "ty": 2,
      "x": 964,
      "y": 678
    },
    {
      "t": 47249,
      "e": 47149,
      "ty": 41,
      "x": 32922,
      "y": 37116,
      "ta": "html > body"
    },
    {
      "t": 47599,
      "e": 47499,
      "ty": 2,
      "x": 959,
      "y": 688
    },
    {
      "t": 47699,
      "e": 47599,
      "ty": 2,
      "x": 956,
      "y": 697
    },
    {
      "t": 47749,
      "e": 47649,
      "ty": 41,
      "x": 32612,
      "y": 38334,
      "ta": "html > body"
    },
    {
      "t": 47797,
      "e": 47697,
      "ty": 2,
      "x": 953,
      "y": 704
    },
    {
      "t": 47898,
      "e": 47798,
      "ty": 2,
      "x": 948,
      "y": 713
    },
    {
      "t": 48011,
      "e": 47911,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 48015,
      "e": 47915,
      "ty": 41,
      "x": 30040,
      "y": 56172,
      "ta": "#jspsych-survey-multi-choice-option-2-1"
    },
    {
      "t": 48098,
      "e": 47998,
      "ty": 2,
      "x": 948,
      "y": 714
    },
    {
      "t": 48248,
      "e": 48148,
      "ty": 41,
      "x": 30040,
      "y": 58513,
      "ta": "#jspsych-survey-multi-choice-option-2-1"
    },
    {
      "t": 48997,
      "e": 48897,
      "ty": 2,
      "x": 978,
      "y": 141
    },
    {
      "t": 48998,
      "e": 48898,
      "ty": 41,
      "x": 33404,
      "y": 7367,
      "ta": "html > body"
    },
    {
      "t": 49098,
      "e": 48998,
      "ty": 2,
      "x": 955,
      "y": 78
    },
    {
      "t": 49198,
      "e": 49098,
      "ty": 2,
      "x": 885,
      "y": 215
    },
    {
      "t": 49248,
      "e": 49148,
      "ty": 41,
      "x": 29381,
      "y": 36044,
      "ta": "#jspsych-survey-multi-choice-option-0-1 > label"
    },
    {
      "t": 49298,
      "e": 49198,
      "ty": 6,
      "x": 832,
      "y": 263,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 49299,
      "e": 49199,
      "ty": 2,
      "x": 832,
      "y": 263
    },
    {
      "t": 49314,
      "e": 49214,
      "ty": 7,
      "x": 817,
      "y": 251,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 49397,
      "e": 49297,
      "ty": 2,
      "x": 808,
      "y": 208
    },
    {
      "t": 49497,
      "e": 49397,
      "ty": 2,
      "x": 810,
      "y": 208
    },
    {
      "t": 49498,
      "e": 49398,
      "ty": 41,
      "x": 27619,
      "y": 11079,
      "ta": "html > body"
    },
    {
      "t": 49598,
      "e": 49498,
      "ty": 2,
      "x": 841,
      "y": 231
    },
    {
      "t": 49683,
      "e": 49499,
      "ty": 6,
      "x": 837,
      "y": 235,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 49698,
      "e": 49514,
      "ty": 2,
      "x": 836,
      "y": 236
    },
    {
      "t": 49732,
      "e": 49548,
      "ty": 7,
      "x": 824,
      "y": 239,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 49748,
      "e": 49564,
      "ty": 41,
      "x": 473,
      "y": 32767,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 49798,
      "e": 49614,
      "ty": 2,
      "x": 822,
      "y": 239
    },
    {
      "t": 49842,
      "e": 49658,
      "ty": 3,
      "x": 822,
      "y": 239,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 49907,
      "e": 49723,
      "ty": 4,
      "x": 0,
      "y": 32767,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 49908,
      "e": 49724,
      "ty": 5,
      "x": 821,
      "y": 239,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 49908,
      "e": 49724,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 49910,
      "e": 49726,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf",
      "v": "English"
    },
    {
      "t": 49998,
      "e": 49814,
      "ty": 2,
      "x": 823,
      "y": 239
    },
    {
      "t": 49998,
      "e": 49814,
      "ty": 41,
      "x": 1292,
      "y": 32767,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 50233,
      "e": 50049,
      "ty": 6,
      "x": 826,
      "y": 264,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 50248,
      "e": 50064,
      "ty": 41,
      "x": 0,
      "y": 20164,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 50250,
      "e": 50066,
      "ty": 7,
      "x": 826,
      "y": 297,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 50250,
      "e": 50066,
      "ty": 6,
      "x": 826,
      "y": 297,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 50265,
      "e": 50081,
      "ty": 7,
      "x": 826,
      "y": 336,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 50297,
      "e": 50113,
      "ty": 2,
      "x": 826,
      "y": 368
    },
    {
      "t": 50398,
      "e": 50214,
      "ty": 2,
      "x": 830,
      "y": 406
    },
    {
      "t": 50498,
      "e": 50314,
      "ty": 2,
      "x": 830,
      "y": 407
    },
    {
      "t": 50499,
      "e": 50315,
      "ty": 41,
      "x": 10041,
      "y": 6553,
      "ta": "#jspsych-survey-multi-choice-option-1-0 > label"
    },
    {
      "t": 50963,
      "e": 50779,
      "ty": 6,
      "x": 830,
      "y": 411,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 50998,
      "e": 50814,
      "ty": 2,
      "x": 833,
      "y": 419
    },
    {
      "t": 50998,
      "e": 50814,
      "ty": 41,
      "x": 33161,
      "y": 55452,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 51001,
      "e": 50817,
      "ty": 7,
      "x": 834,
      "y": 424,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 51066,
      "e": 50882,
      "ty": 6,
      "x": 834,
      "y": 437,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 51098,
      "e": 50914,
      "ty": 2,
      "x": 834,
      "y": 441
    },
    {
      "t": 51199,
      "e": 51015,
      "ty": 2,
      "x": 835,
      "y": 443
    },
    {
      "t": 51248,
      "e": 51064,
      "ty": 41,
      "x": 43243,
      "y": 55452,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 51298,
      "e": 51114,
      "ty": 2,
      "x": 835,
      "y": 447
    },
    {
      "t": 51379,
      "e": 51195,
      "ty": 7,
      "x": 835,
      "y": 449,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 51398,
      "e": 51214,
      "ty": 2,
      "x": 835,
      "y": 449
    },
    {
      "t": 51499,
      "e": 51315,
      "ty": 41,
      "x": 10845,
      "y": 52428,
      "ta": "#jspsych-survey-multi-choice-option-1-1 > label"
    },
    {
      "t": 51658,
      "e": 51474,
      "ty": 3,
      "x": 835,
      "y": 449,
      "ta": "#jspsych-survey-multi-choice-option-1-1 > label"
    },
    {
      "t": 51658,
      "e": 51474,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 51737,
      "e": 51553,
      "ty": 4,
      "x": 10845,
      "y": 52428,
      "ta": "#jspsych-survey-multi-choice-option-1-1 > label"
    },
    {
      "t": 51738,
      "e": 51554,
      "ty": 5,
      "x": 835,
      "y": 449,
      "ta": "#jspsych-survey-multi-choice-option-1-1 > label"
    },
    {
      "t": 51738,
      "e": 51554,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 51739,
      "e": 51555,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf",
      "v": "Second"
    },
    {
      "t": 52698,
      "e": 52514,
      "ty": 2,
      "x": 833,
      "y": 458
    },
    {
      "t": 52748,
      "e": 52564,
      "ty": 41,
      "x": 11181,
      "y": 6553,
      "ta": "#jspsych-survey-multi-choice-option-1-2 > label"
    },
    {
      "t": 52753,
      "e": 52566,
      "ty": 6,
      "x": 832,
      "y": 464,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 52798,
      "e": 52611,
      "ty": 2,
      "x": 829,
      "y": 470
    },
    {
      "t": 52817,
      "e": 52630,
      "ty": 7,
      "x": 829,
      "y": 478,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 52868,
      "e": 52681,
      "ty": 6,
      "x": 829,
      "y": 496,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 52898,
      "e": 52711,
      "ty": 2,
      "x": 828,
      "y": 501
    },
    {
      "t": 52900,
      "e": 52713,
      "ty": 7,
      "x": 826,
      "y": 508,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 52998,
      "e": 52811,
      "ty": 2,
      "x": 816,
      "y": 581
    },
    {
      "t": 52998,
      "e": 52811,
      "ty": 41,
      "x": 27825,
      "y": 31742,
      "ta": "html > body"
    },
    {
      "t": 53098,
      "e": 52911,
      "ty": 2,
      "x": 813,
      "y": 649
    },
    {
      "t": 53198,
      "e": 53011,
      "ty": 2,
      "x": 808,
      "y": 686
    },
    {
      "t": 53248,
      "e": 53061,
      "ty": 41,
      "x": 27515,
      "y": 37725,
      "ta": "html > body"
    },
    {
      "t": 53298,
      "e": 53111,
      "ty": 2,
      "x": 807,
      "y": 689
    },
    {
      "t": 53398,
      "e": 53211,
      "ty": 2,
      "x": 808,
      "y": 689
    },
    {
      "t": 53499,
      "e": 53312,
      "ty": 2,
      "x": 823,
      "y": 680
    },
    {
      "t": 53499,
      "e": 53312,
      "ty": 41,
      "x": 423,
      "y": 49151,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 53535,
      "e": 53348,
      "ty": 6,
      "x": 826,
      "y": 678,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 53599,
      "e": 53412,
      "ty": 2,
      "x": 828,
      "y": 675
    },
    {
      "t": 53748,
      "e": 53561,
      "ty": 41,
      "x": 7955,
      "y": 35288,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 56122,
      "e": 55935,
      "ty": 7,
      "x": 828,
      "y": 681,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 56170,
      "e": 55983,
      "ty": 6,
      "x": 830,
      "y": 696,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 56198,
      "e": 56011,
      "ty": 2,
      "x": 830,
      "y": 698
    },
    {
      "t": 56249,
      "e": 56062,
      "ty": 41,
      "x": 18037,
      "y": 50411,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 56287,
      "e": 56100,
      "ty": 7,
      "x": 830,
      "y": 709,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 56298,
      "e": 56111,
      "ty": 2,
      "x": 830,
      "y": 709
    },
    {
      "t": 56398,
      "e": 56211,
      "ty": 2,
      "x": 830,
      "y": 715
    },
    {
      "t": 56499,
      "e": 56312,
      "ty": 2,
      "x": 830,
      "y": 718
    },
    {
      "t": 56499,
      "e": 56312,
      "ty": 41,
      "x": 2035,
      "y": 2340,
      "ta": "#jspsych-survey-multi-choice-option-2-2"
    },
    {
      "t": 56598,
      "e": 56411,
      "ty": 2,
      "x": 830,
      "y": 722
    },
    {
      "t": 56748,
      "e": 56561,
      "ty": 41,
      "x": 2152,
      "y": 3276,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 56891,
      "e": 56704,
      "ty": 6,
      "x": 830,
      "y": 724,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 56898,
      "e": 56711,
      "ty": 2,
      "x": 830,
      "y": 724
    },
    {
      "t": 56998,
      "e": 56811,
      "ty": 2,
      "x": 830,
      "y": 727
    },
    {
      "t": 56998,
      "e": 56811,
      "ty": 41,
      "x": 18037,
      "y": 15123,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 58198,
      "e": 58011,
      "ty": 2,
      "x": 830,
      "y": 731
    },
    {
      "t": 58205,
      "e": 58018,
      "ty": 7,
      "x": 845,
      "y": 765,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 58249,
      "e": 58062,
      "ty": 41,
      "x": 59468,
      "y": 39789,
      "ta": "#jspsych-survey-multi-choice-option-3-1"
    },
    {
      "t": 58298,
      "e": 58111,
      "ty": 2,
      "x": 1261,
      "y": 1026
    },
    {
      "t": 58398,
      "e": 58211,
      "ty": 2,
      "x": 1274,
      "y": 1022
    },
    {
      "t": 58499,
      "e": 58312,
      "ty": 2,
      "x": 1115,
      "y": 925
    },
    {
      "t": 58499,
      "e": 58312,
      "ty": 41,
      "x": 38122,
      "y": 50799,
      "ta": "html > body"
    },
    {
      "t": 58598,
      "e": 58411,
      "ty": 2,
      "x": 1024,
      "y": 869
    },
    {
      "t": 58698,
      "e": 58511,
      "ty": 2,
      "x": 998,
      "y": 848
    },
    {
      "t": 58748,
      "e": 58561,
      "ty": 41,
      "x": 38109,
      "y": 18724,
      "ta": "#jspsych-survey-multi-choice-option-2-6"
    },
    {
      "t": 58798,
      "e": 58611,
      "ty": 2,
      "x": 966,
      "y": 818
    },
    {
      "t": 58898,
      "e": 58711,
      "ty": 2,
      "x": 919,
      "y": 775
    },
    {
      "t": 58998,
      "e": 58811,
      "ty": 2,
      "x": 885,
      "y": 747
    },
    {
      "t": 58999,
      "e": 58812,
      "ty": 41,
      "x": 15088,
      "y": 4681,
      "ta": "#jspsych-survey-multi-choice-option-2-3"
    },
    {
      "t": 59098,
      "e": 58911,
      "ty": 2,
      "x": 832,
      "y": 710
    },
    {
      "t": 59106,
      "e": 58919,
      "ty": 6,
      "x": 828,
      "y": 707,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 59122,
      "e": 58935,
      "ty": 7,
      "x": 824,
      "y": 705,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 59198,
      "e": 59011,
      "ty": 2,
      "x": 820,
      "y": 703
    },
    {
      "t": 59249,
      "e": 59062,
      "ty": 41,
      "x": 27860,
      "y": 38999,
      "ta": "html > body"
    },
    {
      "t": 59298,
      "e": 59111,
      "ty": 2,
      "x": 813,
      "y": 734
    },
    {
      "t": 59399,
      "e": 59212,
      "ty": 2,
      "x": 827,
      "y": 742
    },
    {
      "t": 59499,
      "e": 59312,
      "ty": 41,
      "x": 1323,
      "y": 58513,
      "ta": "#jspsych-survey-multi-choice-option-2-2"
    },
    {
      "t": 59798,
      "e": 59611,
      "ty": 2,
      "x": 828,
      "y": 740
    },
    {
      "t": 59807,
      "e": 59620,
      "ty": 6,
      "x": 831,
      "y": 733,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 59898,
      "e": 59711,
      "ty": 2,
      "x": 832,
      "y": 729
    },
    {
      "t": 59954,
      "e": 59767,
      "ty": 3,
      "x": 832,
      "y": 729,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 59956,
      "e": 59769,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 59957,
      "e": 59770,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 59998,
      "e": 59811,
      "ty": 41,
      "x": 28120,
      "y": 25205,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 60066,
      "e": 59879,
      "ty": 4,
      "x": 28120,
      "y": 25205,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 60066,
      "e": 59879,
      "ty": 5,
      "x": 832,
      "y": 729,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 60066,
      "e": 59879,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf",
      "v": "Biomedical & Health Sciences"
    },
    {
      "t": 62126,
      "e": 61939,
      "ty": 7,
      "x": 832,
      "y": 742,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 62141,
      "e": 61954,
      "ty": 6,
      "x": 832,
      "y": 759,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 62159,
      "e": 61972,
      "ty": 7,
      "x": 832,
      "y": 775,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 62175,
      "e": 61988,
      "ty": 6,
      "x": 832,
      "y": 790,
      "ta": "jspsych-survey-multi-choice-response-2[4]_mf"
    },
    {
      "t": 62192,
      "e": 62005,
      "ty": 7,
      "x": 832,
      "y": 800,
      "ta": "jspsych-survey-multi-choice-response-2[4]_mf"
    },
    {
      "t": 62198,
      "e": 62011,
      "ty": 2,
      "x": 832,
      "y": 800
    },
    {
      "t": 62224,
      "e": 62037,
      "ty": 6,
      "x": 833,
      "y": 811,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 62248,
      "e": 62061,
      "ty": 41,
      "x": 38202,
      "y": 30246,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 62274,
      "e": 62087,
      "ty": 7,
      "x": 834,
      "y": 821,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 62298,
      "e": 62111,
      "ty": 2,
      "x": 834,
      "y": 825
    },
    {
      "t": 62358,
      "e": 62171,
      "ty": 6,
      "x": 834,
      "y": 837,
      "ta": "jspsych-survey-multi-choice-response-2[6]_mf"
    },
    {
      "t": 62392,
      "e": 62205,
      "ty": 7,
      "x": 832,
      "y": 852,
      "ta": "jspsych-survey-multi-choice-response-2[6]_mf"
    },
    {
      "t": 62398,
      "e": 62211,
      "ty": 2,
      "x": 832,
      "y": 852
    },
    {
      "t": 62498,
      "e": 62311,
      "ty": 2,
      "x": 828,
      "y": 874
    },
    {
      "t": 62498,
      "e": 62311,
      "ty": 41,
      "x": 1561,
      "y": 53279,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 62599,
      "e": 62412,
      "ty": 2,
      "x": 828,
      "y": 893
    },
    {
      "t": 62698,
      "e": 62511,
      "ty": 2,
      "x": 828,
      "y": 896
    },
    {
      "t": 62749,
      "e": 62562,
      "ty": 41,
      "x": 1561,
      "y": 49151,
      "ta": "#jspsych-survey-multi-choice-3 > p"
    },
    {
      "t": 62998,
      "e": 62811,
      "ty": 2,
      "x": 828,
      "y": 918
    },
    {
      "t": 62999,
      "e": 62812,
      "ty": 41,
      "x": 1561,
      "y": 21676,
      "ta": "#jspsych-survey-multi-choice-3"
    },
    {
      "t": 63098,
      "e": 62911,
      "ty": 2,
      "x": 828,
      "y": 925
    },
    {
      "t": 63249,
      "e": 63062,
      "ty": 41,
      "x": 7184,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 65299,
      "e": 65112,
      "ty": 2,
      "x": 830,
      "y": 917
    },
    {
      "t": 65399,
      "e": 65212,
      "ty": 2,
      "x": 856,
      "y": 817
    },
    {
      "t": 65499,
      "e": 65312,
      "ty": 2,
      "x": 857,
      "y": 793
    },
    {
      "t": 65499,
      "e": 65312,
      "ty": 41,
      "x": 19917,
      "y": 52428,
      "ta": "#jspsych-survey-multi-choice-option-2-4 > label"
    },
    {
      "t": 65598,
      "e": 65411,
      "ty": 2,
      "x": 855,
      "y": 771
    },
    {
      "t": 65749,
      "e": 65562,
      "ty": 41,
      "x": 7968,
      "y": 60853,
      "ta": "#jspsych-survey-multi-choice-option-2-3"
    },
    {
      "t": 66098,
      "e": 65911,
      "ty": 2,
      "x": 855,
      "y": 793
    },
    {
      "t": 66198,
      "e": 66011,
      "ty": 2,
      "x": 855,
      "y": 811
    },
    {
      "t": 66249,
      "e": 66011,
      "ty": 41,
      "x": 19228,
      "y": 42597,
      "ta": "#jspsych-survey-multi-choice-option-2-5 > label"
    },
    {
      "t": 66299,
      "e": 66061,
      "ty": 2,
      "x": 854,
      "y": 826
    },
    {
      "t": 66399,
      "e": 66161,
      "ty": 2,
      "x": 852,
      "y": 840
    },
    {
      "t": 66498,
      "e": 66260,
      "ty": 2,
      "x": 852,
      "y": 822
    },
    {
      "t": 66499,
      "e": 66261,
      "ty": 41,
      "x": 18048,
      "y": 55704,
      "ta": "#jspsych-survey-multi-choice-option-2-5 > label"
    },
    {
      "t": 66599,
      "e": 66361,
      "ty": 2,
      "x": 854,
      "y": 783
    },
    {
      "t": 66749,
      "e": 66511,
      "ty": 41,
      "x": 18238,
      "y": 19660,
      "ta": "#jspsych-survey-multi-choice-option-2-4 > label"
    },
    {
      "t": 66799,
      "e": 66561,
      "ty": 2,
      "x": 853,
      "y": 778
    },
    {
      "t": 66899,
      "e": 66661,
      "ty": 2,
      "x": 852,
      "y": 760
    },
    {
      "t": 66986,
      "e": 66748,
      "ty": 3,
      "x": 852,
      "y": 760,
      "ta": "#jspsych-survey-multi-choice-option-2-3 > label"
    },
    {
      "t": 66986,
      "e": 66748,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 66999,
      "e": 66761,
      "ty": 41,
      "x": 12758,
      "y": 36044,
      "ta": "#jspsych-survey-multi-choice-option-2-3 > label"
    },
    {
      "t": 67066,
      "e": 66828,
      "ty": 4,
      "x": 12758,
      "y": 36044,
      "ta": "#jspsych-survey-multi-choice-option-2-3 > label"
    },
    {
      "t": 67066,
      "e": 66828,
      "ty": 5,
      "x": 852,
      "y": 760,
      "ta": "#jspsych-survey-multi-choice-option-2-3 > label"
    },
    {
      "t": 67067,
      "e": 66829,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 67068,
      "e": 66830,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf",
      "v": "Natural Sciences"
    },
    {
      "t": 70099,
      "e": 69861,
      "ty": 2,
      "x": 847,
      "y": 802
    },
    {
      "t": 70198,
      "e": 69960,
      "ty": 2,
      "x": 843,
      "y": 836
    },
    {
      "t": 70249,
      "e": 70011,
      "ty": 41,
      "x": 4646,
      "y": 58513,
      "ta": "#jspsych-survey-multi-choice-option-2-6"
    },
    {
      "t": 70298,
      "e": 70060,
      "ty": 2,
      "x": 841,
      "y": 865
    },
    {
      "t": 70399,
      "e": 70161,
      "ty": 2,
      "x": 840,
      "y": 889
    },
    {
      "t": 70499,
      "e": 70261,
      "ty": 41,
      "x": 4409,
      "y": 32767,
      "ta": "#jspsych-survey-multi-choice-3 > p"
    },
    {
      "t": 70599,
      "e": 70361,
      "ty": 2,
      "x": 837,
      "y": 912
    },
    {
      "t": 70699,
      "e": 70461,
      "ty": 2,
      "x": 836,
      "y": 918
    },
    {
      "t": 70749,
      "e": 70511,
      "ty": 41,
      "x": 3459,
      "y": 21676,
      "ta": "#jspsych-survey-multi-choice-3"
    },
    {
      "t": 70799,
      "e": 70561,
      "ty": 2,
      "x": 836,
      "y": 921
    },
    {
      "t": 70848,
      "e": 70610,
      "ty": 6,
      "x": 835,
      "y": 928,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 70898,
      "e": 70660,
      "ty": 2,
      "x": 834,
      "y": 934
    },
    {
      "t": 70999,
      "e": 70761,
      "ty": 2,
      "x": 833,
      "y": 936
    },
    {
      "t": 70999,
      "e": 70761,
      "ty": 41,
      "x": 33161,
      "y": 40329,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 71091,
      "e": 70853,
      "ty": 7,
      "x": 833,
      "y": 941,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 71098,
      "e": 70860,
      "ty": 2,
      "x": 833,
      "y": 941
    },
    {
      "t": 71199,
      "e": 70961,
      "ty": 2,
      "x": 833,
      "y": 946
    },
    {
      "t": 71249,
      "e": 71011,
      "ty": 41,
      "x": 2747,
      "y": 58513,
      "ta": "#jspsych-survey-multi-choice-option-3-0"
    },
    {
      "t": 71298,
      "e": 71060,
      "ty": 2,
      "x": 833,
      "y": 949
    },
    {
      "t": 71398,
      "e": 71160,
      "ty": 2,
      "x": 833,
      "y": 951
    },
    {
      "t": 71499,
      "e": 71261,
      "ty": 41,
      "x": 2747,
      "y": 4681,
      "ta": "#jspsych-survey-multi-choice-option-3-1"
    },
    {
      "t": 71811,
      "e": 71573,
      "ty": 3,
      "x": 833,
      "y": 951,
      "ta": "#jspsych-survey-multi-choice-option-3-1"
    },
    {
      "t": 71811,
      "e": 71573,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 71889,
      "e": 71651,
      "ty": 4,
      "x": 2747,
      "y": 4681,
      "ta": "#jspsych-survey-multi-choice-option-3-1"
    },
    {
      "t": 71889,
      "e": 71651,
      "ty": 5,
      "x": 833,
      "y": 951,
      "ta": "#jspsych-survey-multi-choice-option-3-1"
    },
    {
      "t": 72099,
      "e": 71861,
      "ty": 2,
      "x": 832,
      "y": 952
    },
    {
      "t": 72150,
      "e": 71912,
      "ty": 6,
      "x": 829,
      "y": 958,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 72198,
      "e": 71960,
      "ty": 2,
      "x": 826,
      "y": 963
    },
    {
      "t": 72234,
      "e": 71996,
      "ty": 3,
      "x": 826,
      "y": 963,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 72235,
      "e": 71997,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 72248,
      "e": 72010,
      "ty": 41,
      "x": 0,
      "y": 35288,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 72321,
      "e": 72083,
      "ty": 4,
      "x": 0,
      "y": 35288,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 72321,
      "e": 72083,
      "ty": 5,
      "x": 826,
      "y": 963,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 72322,
      "e": 72084,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf",
      "v": "Female"
    },
    {
      "t": 72483,
      "e": 72245,
      "ty": 7,
      "x": 832,
      "y": 982,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 72498,
      "e": 72260,
      "ty": 2,
      "x": 832,
      "y": 982
    },
    {
      "t": 72498,
      "e": 72260,
      "ty": 41,
      "x": 10501,
      "y": 3276,
      "ta": "#jspsych-survey-multi-choice-option-3-2 > label"
    },
    {
      "t": 72598,
      "e": 72360,
      "ty": 2,
      "x": 876,
      "y": 1160
    },
    {
      "t": 72698,
      "e": 72460,
      "ty": 2,
      "x": 919,
      "y": 1086
    },
    {
      "t": 72749,
      "e": 72511,
      "ty": 41,
      "x": 31510,
      "y": 57225,
      "ta": "html > body"
    },
    {
      "t": 72751,
      "e": 72513,
      "ty": 6,
      "x": 923,
      "y": 1037,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 72797,
      "e": 72559,
      "ty": 2,
      "x": 923,
      "y": 1034
    },
    {
      "t": 72866,
      "e": 72628,
      "ty": 3,
      "x": 924,
      "y": 1026,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 72866,
      "e": 72628,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 72866,
      "e": 72628,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 72898,
      "e": 72660,
      "ty": 2,
      "x": 924,
      "y": 1026
    },
    {
      "t": 72938,
      "e": 72700,
      "ty": 4,
      "x": 48744,
      "y": 39718,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 72938,
      "e": 72700,
      "ty": 5,
      "x": 924,
      "y": 1025,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 72942,
      "e": 72704,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 72944,
      "e": 72706,
      "ty": 13,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 72945,
      "e": 72707,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 72998,
      "e": 72760,
      "ty": 2,
      "x": 924,
      "y": 1025
    },
    {
      "t": 72998,
      "e": 72760,
      "ty": 41,
      "x": 31544,
      "y": 56339,
      "ta": "html > body"
    },
    {
      "t": 73098,
      "e": 72860,
      "ty": 2,
      "x": 923,
      "y": 1024
    },
    {
      "t": 73248,
      "e": 73010,
      "ty": 41,
      "x": 31510,
      "y": 56283,
      "ta": "html > body"
    },
    {
      "t": 74296,
      "e": 74058,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 77098,
      "e": 76860,
      "ty": 2,
      "x": 922,
      "y": 1054
    },
    {
      "t": 77249,
      "e": 76861,
      "ty": 41,
      "x": 30922,
      "y": 64240,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 77298,
      "e": 76910,
      "ty": 2,
      "x": 924,
      "y": 1054
    },
    {
      "t": 77398,
      "e": 77010,
      "ty": 2,
      "x": 933,
      "y": 1054
    },
    {
      "t": 77498,
      "e": 77110,
      "ty": 2,
      "x": 937,
      "y": 1052
    },
    {
      "t": 77498,
      "e": 77110,
      "ty": 41,
      "x": 31660,
      "y": 64102,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 77598,
      "e": 77210,
      "ty": 2,
      "x": 939,
      "y": 1051
    },
    {
      "t": 77749,
      "e": 77361,
      "ty": 41,
      "x": 31758,
      "y": 64033,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 85198,
      "e": 82361,
      "ty": 2,
      "x": 936,
      "y": 1070
    },
    {
      "t": 85210,
      "e": 82373,
      "ty": 6,
      "x": 934,
      "y": 1078,
      "ta": "#start"
    },
    {
      "t": 85249,
      "e": 82412,
      "ty": 41,
      "x": 13380,
      "y": 12167,
      "ta": "#start"
    },
    {
      "t": 85299,
      "e": 82462,
      "ty": 2,
      "x": 934,
      "y": 1079
    },
    {
      "t": 85337,
      "e": 82500,
      "ty": 3,
      "x": 934,
      "y": 1079,
      "ta": "#start"
    },
    {
      "t": 85339,
      "e": 82502,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 85410,
      "e": 82573,
      "ty": 4,
      "x": 13380,
      "y": 12167,
      "ta": "#start"
    },
    {
      "t": 85410,
      "e": 82573,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 85411,
      "e": 82574,
      "ty": 5,
      "x": 934,
      "y": 1079,
      "ta": "#start"
    },
    {
      "t": 85411,
      "e": 82574,
      "ty": 38,
      "x": 8,
      "y": 0
    },
    {
      "t": 86444,
      "e": 83607,
      "ty": 38,
      "x": 9,
      "y": 0
    },
    {
      "t": 87884,
      "e": 85047,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2311,\"tagName\":\"g\",\"attributes\":{\"class\":\"xaxis\",\"transform\":\"translate(0,800)\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"middle\"},\"previousSibling\":{\"id\":2302},\"parentNode\":{\"id\":2300}},{\"nodeType\":1,\"id\":2312,\"tagName\":\"g\",\"attributes\":{\"class\":\"yaxis\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"end\"},\"previousSibling\":{\"id\":2311},\"parentNode\":{\"id\":2300}},{\"nodeType\":1,\"id\":2313,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2312},\"parentNode\":{\"id\":2300}},{\"nodeType\":1,\"id\":2314,\"tagName\":\"g\",\"attributes\":{\"class\":\"xgrid\"},\"previousSibling\":{\"id\":2313},\"parentNode\":{\"id\":2300}},{\"nodeType\":1,\"id\":2315,\"tagName\":\"g\",\"attributes\":{\"class\":\"data\"},\"previousSibling\":{\"id\":2314},\"parentNode\":{\"id\":2300}},{\"nodeType\":1,\"id\":2316,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M0.5,6V0.5H800.5V6\"},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2317,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0.5,0)\"},\"previousSibling\":{\"id\":2316},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2318,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(33.83333333333333,0)\"},\"previousSibling\":{\"id\":2317},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2319,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(67.16666666666666,0)\"},\"previousSibling\":{\"id\":2318},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2320,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(100.5,0)\"},\"previousSibling\":{\"id\":2319},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2321,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(133.83333333333331,0)\"},\"previousSibling\":{\"id\":2320},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2322,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(167.16666666666669,0)\"},\"previousSibling\":{\"id\":2321},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2323,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(200.5,0)\"},\"previousSibling\":{\"id\":2322},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2324,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(233.83333333333334,0)\"},\"previousSibling\":{\"id\":2323},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2325,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(267.16666666666663,0)\"},\"previousSibling\":{\"id\":2324},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2326,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(300.5,0)\"},\"previousSibling\":{\"id\":2325},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2327,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(333.83333333333337,0)\"},\"previousSibling\":{\"id\":2326},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2328,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(367.16666666666663,0)\"},\"previousSibling\":{\"id\":2327},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2329,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(400.5,0)\"},\"previousSibling\":{\"id\":2328},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2330,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(433.8333333333333,0)\"},\"previousSibling\":{\"id\":2329},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2331,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(467.1666666666667,0)\"},\"previousSibling\":{\"id\":2330},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2332,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(500.5,0)\"},\"previousSibling\":{\"id\":2331},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2333,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(533.8333333333333,0)\"},\"previousSibling\":{\"id\":2332},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2334,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(567.1666666666667,0)\"},\"previousSibling\":{\"id\":2333},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2335,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(600.5,0)\"},\"previousSibling\":{\"id\":2334},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2336,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(633.8333333333333,0)\"},\"previousSibling\":{\"id\":2335},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2337,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(667.1666666666667,0)\"},\"previousSibling\":{\"id\":2336},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2338,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(700.5,0)\"},\"previousSibling\":{\"id\":2337},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2339,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(733.8333333333333,0)\"},\"previousSibling\":{\"id\":2338},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2340,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(767.1666666666667,0)\"},\"previousSibling\":{\"id\":2339},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2341,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(800.5,0)\"},\"previousSibling\":{\"id\":2340},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2342,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"previousSibling\":{\"id\":2341},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2343,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2317}},{\"nodeType\":1,\"id\":2344,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2343},\"parentNode\":{\"id\":2317}},{\"nodeType\":1,\"id\":2345,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2318}},{\"nodeType\":1,\"id\":2346,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2345},\"parentNode\":{\"id\":2318}},{\"nodeType\":1,\"id\":2347,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2319}},{\"nodeType\":1,\"id\":2348,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2347},\"parentNode\":{\"id\":2319}},{\"nodeType\":1,\"id\":2349,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2320}},{\"nodeType\":1,\"id\":2350,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2349},\"parentNode\":{\"id\":2320}},{\"nodeType\":1,\"id\":2351,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2321}},{\"nodeType\":1,\"id\":2352,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2351},\"parentNode\":{\"id\":2321}},{\"nodeType\":1,\"id\":2353,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2322}},{\"nodeType\":1,\"id\":2354,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2353},\"parentNode\":{\"id\":2322}},{\"nodeType\":1,\"id\":2355,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2323}},{\"nodeType\":1,\"id\":2356,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2355},\"parentNode\":{\"id\":2323}},{\"nodeType\":1,\"id\":2357,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2324}},{\"nodeType\":1,\"id\":2358,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2357},\"parentNode\":{\"id\":2324}},{\"nodeType\":1,\"id\":2359,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2325}},{\"nodeType\":1,\"id\":2360,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2359},\"parentNode\":{\"id\":2325}},{\"nodeType\":1,\"id\":2361,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2326}},{\"nodeType\":1,\"id\":2362,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2361},\"parentNode\":{\"id\":2326}},{\"nodeType\":1,\"id\":2363,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2327}},{\"nodeType\":1,\"id\":2364,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2363},\"parentNode\":{\"id\":2327}},{\"nodeType\":1,\"id\":2365,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2328}},{\"nodeType\":1,\"id\":2366,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2365},\"parentNode\":{\"id\":2328}},{\"nodeType\":1,\"id\":2367,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2329}},{\"nodeType\":1,\"id\":2368,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2367},\"parentNode\":{\"id\":2329}},{\"nodeType\":1,\"id\":2369,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2330}},{\"nodeType\":1,\"id\":2370,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2369},\"parentNode\":{\"id\":2330}},{\"nodeType\":1,\"id\":2371,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2331}},{\"nodeType\":1,\"id\":2372,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2371},\"parentNode\":{\"id\":2331}},{\"nodeType\":1,\"id\":2373,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2332}},{\"nodeType\":1,\"id\":2374,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2373},\"parentNode\":{\"id\":2332}},{\"nodeType\":1,\"id\":2375,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2333}},{\"nodeType\":1,\"id\":2376,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2375},\"parentNode\":{\"id\":2333}},{\"nodeType\":1,\"id\":2377,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2334}},{\"nodeType\":1,\"id\":2378,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2377},\"parentNode\":{\"id\":2334}},{\"nodeType\":1,\"id\":2379,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2335}},{\"nodeType\":1,\"id\":2380,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2379},\"parentNode\":{\"id\":2335}},{\"nodeType\":1,\"id\":2381,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2336}},{\"nodeType\":1,\"id\":2382,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2381},\"parentNode\":{\"id\":2336}},{\"nodeType\":1,\"id\":2383,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2337}},{\"nodeType\":1,\"id\":2384,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2383},\"parentNode\":{\"id\":2337}},{\"nodeType\":1,\"id\":2385,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2338}},{\"nodeType\":1,\"id\":2386,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2385},\"parentNode\":{\"id\":2338}},{\"nodeType\":1,\"id\":2387,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2339}},{\"nodeType\":1,\"id\":2388,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2387},\"parentNode\":{\"id\":2339}},{\"nodeType\":1,\"id\":2389,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2340}},{\"nodeType\":1,\"id\":2390,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2389},\"parentNode\":{\"id\":2340}},{\"nodeType\":1,\"id\":2391,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2341}},{\"nodeType\":1,\"id\":2392,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2391},\"parentNode\":{\"id\":2341}},{\"nodeType\":3,\"id\":2393,\"textContent\":\"08 AM\",\"parentNode\":{\"id\":2344}},{\"nodeType\":3,\"id\":2394,\"textContent\":\"08:30\",\"parentNode\":{\"id\":2346}},{\"nodeType\":3,\"id\":2395,\"textContent\":\"09 AM\",\"parentNode\":{\"id\":2348}},{\"nodeType\":3,\"id\":2396,\"textContent\":\"09:30\",\"parentNode\":{\"id\":2350}},{\"nodeType\":3,\"id\":2397,\"textContent\":\"10 AM\",\"parentNode\":{\"id\":2352}},{\"nodeType\":3,\"id\":2398,\"textContent\":\"10:30\",\"parentNode\":{\"id\":2354}},{\"nodeType\":3,\"id\":2399,\"textContent\":\"11 AM\",\"parentNode\":{\"id\":2356}},{\"nodeType\":3,\"id\":2400,\"textContent\":\"11:30\",\"parentNode\":{\"id\":2358}},{\"nodeType\":3,\"id\":2401,\"textContent\":\"12 PM\",\"parentNode\":{\"id\":2360}},{\"nodeType\":3,\"id\":2402,\"textContent\":\"12:30\",\"parentNode\":{\"id\":2362}},{\"nodeType\":3,\"id\":2403,\"textContent\":\"01 PM\",\"parentNode\":{\"id\":2364}},{\"nodeType\":3,\"id\":2404,\"textContent\":\"01:30\",\"parentNode\":{\"id\":2366}},{\"nodeType\":3,\"id\":2405,\"textContent\":\"02 PM\",\"parentNode\":{\"id\":2368}},{\"nodeType\":3,\"id\":2406,\"textContent\":\"02:30\",\"parentNode\":{\"id\":2370}},{\"nodeType\":3,\"id\":2407,\"textContent\":\"03 PM\",\"parentNode\":{\"id\":2372}},{\"nodeType\":3,\"id\":2408,\"textContent\":\"03:30\",\"parentNode\":{\"id\":2374}},{\"nodeType\":3,\"id\":2409,\"textContent\":\"04 PM\",\"parentNode\":{\"id\":2376}},{\"nodeType\":3,\"id\":2410,\"textContent\":\"04:30\",\"parentNode\":{\"id\":2378}},{\"nodeType\":3,\"id\":2411,\"textContent\":\"05 PM\",\"parentNode\":{\"id\":2380}},{\"nodeType\":3,\"id\":2412,\"textContent\":\"05:30\",\"parentNode\":{\"id\":2382}},{\"nodeType\":3,\"id\":2413,\"textContent\":\"06 PM\",\"parentNode\":{\"id\":2384}},{\"nodeType\":3,\"id\":2414,\"textContent\":\"06:30\",\"parentNode\":{\"id\":2386}},{\"nodeType\":3,\"id\":2415,\"textContent\":\"07 PM\",\"parentNode\":{\"id\":2388}},{\"nodeType\":3,\"id\":2416,\"textContent\":\"07:30\",\"parentNode\":{\"id\":2390}},{\"nodeType\":3,\"id\":2417,\"textContent\":\"08 PM\",\"parentNode\":{\"id\":2392}},{\"nodeType\":1,\"id\":2418,\"tagName\":\"text\",\"attributes\":{\"x\":\"533.3333333333334\",\"y\":\"80\",\"style\":\"text-anchor: end;\"},\"parentNode\":{\"id\":2342}},{\"nodeType\":3,\"id\":2419,\"textContent\":\"START & END TIME (time of day)\",\"parentNode\":{\"id\":2418}},{\"nodeType\":1,\"id\":2420,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M-15,800.5H0.5V0.5H-15\"},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2421,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,800.5)\"},\"previousSibling\":{\"id\":2420},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2422,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,733.8333333333334)\"},\"previousSibling\":{\"id\":2421},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2423,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,667.1666666666667)\"},\"previousSibling\":{\"id\":2422},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2424,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,600.5)\"},\"previousSibling\":{\"id\":2423},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2425,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,533.8333333333334)\"},\"previousSibling\":{\"id\":2424},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2426,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,467.16666666666663)\"},\"previousSibling\":{\"id\":2425},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2427,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,400.5)\"},\"previousSibling\":{\"id\":2426},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2428,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,333.8333333333333)\"},\"previousSibling\":{\"id\":2427},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2429,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,267.16666666666674)\"},\"previousSibling\":{\"id\":2428},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2430,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,200.5)\"},\"previousSibling\":{\"id\":2429},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2431,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,133.83333333333326)\"},\"previousSibling\":{\"id\":2430},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2432,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,67.16666666666674)\"},\"previousSibling\":{\"id\":2431},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2433,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,0.5)\"},\"previousSibling\":{\"id\":2432},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2434,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"previousSibling\":{\"id\":2433},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2435,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2421}},{\"nodeType\":1,\"id\":2436,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2435},\"parentNode\":{\"id\":2421}},{\"nodeType\":1,\"id\":2437,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2422}},{\"nodeType\":1,\"id\":2438,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2437},\"parentNode\":{\"id\":2422}},{\"nodeType\":1,\"id\":2439,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2423}},{\"nodeType\":1,\"id\":2440,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2439},\"parentNode\":{\"id\":2423}},{\"nodeType\":1,\"id\":2441,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2424}},{\"nodeType\":1,\"id\":2442,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2441},\"parentNode\":{\"id\":2424}},{\"nodeType\":1,\"id\":2443,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2425}},{\"nodeType\":1,\"id\":2444,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2443},\"parentNode\":{\"id\":2425}},{\"nodeType\":1,\"id\":2445,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2426}},{\"nodeType\":1,\"id\":2446,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2445},\"parentNode\":{\"id\":2426}},{\"nodeType\":1,\"id\":2447,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2427}},{\"nodeType\":1,\"id\":2448,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2447},\"parentNode\":{\"id\":2427}},{\"nodeType\":1,\"id\":2449,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2428}},{\"nodeType\":1,\"id\":2450,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2449},\"parentNode\":{\"id\":2428}},{\"nodeType\":1,\"id\":2451,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2429}},{\"nodeType\":1,\"id\":2452,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2451},\"parentNode\":{\"id\":2429}},{\"nodeType\":1,\"id\":2453,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2430}},{\"nodeType\":1,\"id\":2454,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2453},\"parentNode\":{\"id\":2430}},{\"nodeType\":1,\"id\":2455,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2431}},{\"nodeType\":1,\"id\":2456,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2455},\"parentNode\":{\"id\":2431}},{\"nodeType\":1,\"id\":2457,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2432}},{\"nodeType\":1,\"id\":2458,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2457},\"parentNode\":{\"id\":2432}},{\"nodeType\":1,\"id\":2459,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2433}},{\"nodeType\":1,\"id\":2460,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2459},\"parentNode\":{\"id\":2433}},{\"nodeType\":3,\"id\":2461,\"textContent\":\"0\",\"parentNode\":{\"id\":2436}},{\"nodeType\":3,\"id\":2462,\"textContent\":\"1\",\"parentNode\":{\"id\":2438}},{\"nodeType\":3,\"id\":2463,\"textContent\":\"2\",\"parentNode\":{\"id\":2440}},{\"nodeType\":3,\"id\":2464,\"textContent\":\"3\",\"parentNode\":{\"id\":2442}},{\"nodeType\":3,\"id\":2465,\"textContent\":\"4\",\"parentNode\":{\"id\":2444}},{\"nodeType\":3,\"id\":2466,\"textContent\":\"5\",\"parentNode\":{\"id\":2446}},{\"nodeType\":3,\"id\":2467,\"textContent\":\"6\",\"parentNode\":{\"id\":2448}},{\"nodeType\":3,\"id\":2468,\"textContent\":\"7\",\"parentNode\":{\"id\":2450}},{\"nodeType\":3,\"id\":2469,\"textContent\":\"8\",\"parentNode\":{\"id\":2452}},{\"nodeType\":3,\"id\":2470,\"textContent\":\"9\",\"parentNode\":{\"id\":2454}},{\"nodeType\":3,\"id\":2471,\"textContent\":\"10\",\"parentNode\":{\"id\":2456}},{\"nodeType\":3,\"id\":2472,\"textContent\":\"11\",\"parentNode\":{\"id\":2458}},{\"nodeType\":3,\"id\":2473,\"textContent\":\"12\",\"parentNode\":{\"id\":2460}},{\"nodeType\":1,\"id\":2474,\"tagName\":\"text\",\"attributes\":{\"transform\":\"rotate(-90)\",\"x\":\"-350\",\"y\":\"-60\",\"style\":\"text-anchor: end;\"},\"parentNode\":{\"id\":2434}},{\"nodeType\":3,\"id\":2475,\"textContent\":\"DURATION (in hours)\",\"parentNode\":{\"id\":2474}},{\"nodeType\":1,\"id\":2476,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2477,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2476},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2478,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2477},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2479,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2478},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2480,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2479},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2481,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2480},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2482,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2481},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2483,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2482},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2484,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2483},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2485,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2484},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2486,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2485},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2487,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2486},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2488,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"733.3333333333334\",\"y2\":\"733.3333333333334\"},\"parentNode\":{\"id\":2476}},{\"nodeType\":1,\"id\":2489,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"666.6666666666667\",\"y2\":\"666.6666666666667\"},\"parentNode\":{\"id\":2477}},{\"nodeType\":1,\"id\":2490,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"600\",\"y2\":\"600\"},\"parentNode\":{\"id\":2478}},{\"nodeType\":1,\"id\":2491,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"533.3333333333334\",\"y2\":\"533.3333333333334\"},\"parentNode\":{\"id\":2479}},{\"nodeType\":1,\"id\":2492,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"466.66666666666663\",\"y2\":\"466.66666666666663\"},\"parentNode\":{\"id\":2480}},{\"nodeType\":1,\"id\":2493,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"400\",\"y2\":\"400\"},\"parentNode\":{\"id\":2481}},{\"nodeType\":1,\"id\":2494,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"333.3333333333333\",\"y2\":\"333.3333333333333\"},\"parentNode\":{\"id\":2482}},{\"nodeType\":1,\"id\":2495,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"266.66666666666674\",\"y2\":\"266.66666666666674\"},\"parentNode\":{\"id\":2483}},{\"nodeType\":1,\"id\":2496,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"200\",\"y2\":\"200\"},\"parentNode\":{\"id\":2484}},{\"nodeType\":1,\"id\":2497,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"133.33333333333326\",\"y2\":\"133.33333333333326\"},\"parentNode\":{\"id\":2485}},{\"nodeType\":1,\"id\":2498,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"66.66666666666674\",\"y2\":\"66.66666666666674\"},\"parentNode\":{\"id\":2486}},{\"nodeType\":1,\"id\":2499,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"0\",\"y2\":\"0\"},\"parentNode\":{\"id\":2487}},{\"nodeType\":1,\"id\":2500,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"0\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2501,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"800\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"},\"previousSibling\":{\"id\":2500},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2502,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"433.3333333333333\",\"y2\":\"66.66666666666674\"},\"previousSibling\":{\"id\":2501},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2503,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"366.66666666666663\",\"y2\":\"66.66666666666674\"},\"previousSibling\":{\"id\":2502},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2504,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"466.6666666666667\",\"y2\":\"133.33333333333326\"},\"previousSibling\":{\"id\":2503},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2505,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"333.33333333333337\",\"y2\":\"133.33333333333326\"},\"previousSibling\":{\"id\":2504},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2506,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"500\",\"y2\":\"200\"},\"previousSibling\":{\"id\":2505},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2507,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"300\",\"y2\":\"200\"},\"previousSibling\":{\"id\":2506},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2508,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"533.3333333333333\",\"y2\":\"266.66666666666674\"},\"previousSibling\":{\"id\":2507},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2509,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"266.66666666666663\",\"y2\":\"266.66666666666674\"},\"previousSibling\":{\"id\":2508},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2510,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"566.6666666666667\",\"y2\":\"333.3333333333333\"},\"previousSibling\":{\"id\":2509},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2511,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"233.33333333333334\",\"y2\":\"333.3333333333333\"},\"previousSibling\":{\"id\":2510},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2512,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"600\",\"y2\":\"400\"},\"previousSibling\":{\"id\":2511},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2513,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"200\",\"y2\":\"400\"},\"previousSibling\":{\"id\":2512},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2514,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"633.3333333333333\",\"y2\":\"466.66666666666663\"},\"previousSibling\":{\"id\":2513},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2515,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"166.66666666666669\",\"y2\":\"466.66666666666663\"},\"previousSibling\":{\"id\":2514},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2516,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"666.6666666666667\",\"y2\":\"533.3333333333334\"},\"previousSibling\":{\"id\":2515},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2517,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"133.33333333333331\",\"y2\":\"533.3333333333334\"},\"previousSibling\":{\"id\":2516},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2518,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"700\",\"y2\":\"600\"},\"previousSibling\":{\"id\":2517},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2519,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"100\",\"y2\":\"600\"},\"previousSibling\":{\"id\":2518},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2520,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"733.3333333333333\",\"y2\":\"666.6666666666667\"},\"previousSibling\":{\"id\":2519},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2521,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"66.66666666666666\",\"y2\":\"666.6666666666667\"},\"previousSibling\":{\"id\":2520},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2522,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"766.6666666666667\",\"y2\":\"733.3333333333334\"},\"previousSibling\":{\"id\":2521},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2523,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"33.33333333333333\",\"y2\":\"733.3333333333334\"},\"previousSibling\":{\"id\":2522},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2524,\"tagName\":\"g\",\"attributes\":{},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2525,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2524},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2526,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2525},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2527,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2526},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2528,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2527},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2529,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2528},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2530,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2529},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2531,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2530},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2532,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2531},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2533,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2532},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2534,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2533},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2535,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2534},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2536,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2535},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2537,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2536},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2538,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2537},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2539,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2538},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2540,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2539},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2541,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2540},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2542,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"266.66666666666674\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2524}},{\"nodeType\":1,\"id\":2543,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"258.66666666666674\"},\"previousSibling\":{\"id\":2542},\"parentNode\":{\"id\":2524}},{\"nodeType\":1,\"id\":2544,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2525}},{\"nodeType\":1,\"id\":2545,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"592\"},\"previousSibling\":{\"id\":2544},\"parentNode\":{\"id\":2525}},{\"nodeType\":1,\"id\":2546,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"366.66666666666663\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2526}},{\"nodeType\":1,\"id\":2547,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"361.66666666666663\",\"y\":\"458.66666666666663\"},\"previousSibling\":{\"id\":2546},\"parentNode\":{\"id\":2526}},{\"nodeType\":1,\"id\":2548,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"666.6666666666667\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2527}},{\"nodeType\":1,\"id\":2549,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"661.6666666666667\",\"y\":\"658.6666666666667\"},\"previousSibling\":{\"id\":2548},\"parentNode\":{\"id\":2527}},{\"nodeType\":1,\"id\":2550,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"200\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2528}},{\"nodeType\":1,\"id\":2551,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"195\",\"y\":\"392\"},\"previousSibling\":{\"id\":2550},\"parentNode\":{\"id\":2528}},{\"nodeType\":1,\"id\":2552,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2529}},{\"nodeType\":1,\"id\":2553,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"525.3333333333334\"},\"previousSibling\":{\"id\":2552},\"parentNode\":{\"id\":2529}},{\"nodeType\":1,\"id\":2554,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2530}},{\"nodeType\":1,\"id\":2555,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"392\"},\"previousSibling\":{\"id\":2554},\"parentNode\":{\"id\":2530}},{\"nodeType\":1,\"id\":2556,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2531}},{\"nodeType\":1,\"id\":2557,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"458.66666666666663\"},\"previousSibling\":{\"id\":2556},\"parentNode\":{\"id\":2531}},{\"nodeType\":1,\"id\":2558,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"100\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2532}},{\"nodeType\":1,\"id\":2559,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"95\",\"y\":\"592\"},\"previousSibling\":{\"id\":2558},\"parentNode\":{\"id\":2532}},{\"nodeType\":1,\"id\":2560,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"133.33333333333331\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2533}},{\"nodeType\":1,\"id\":2561,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"128.33333333333331\",\"y\":\"658.6666666666667\"},\"previousSibling\":{\"id\":2560},\"parentNode\":{\"id\":2533}},{\"nodeType\":1,\"id\":2562,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"133.33333333333326\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2534}},{\"nodeType\":1,\"id\":2563,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"125.33333333333326\"},\"previousSibling\":{\"id\":2562},\"parentNode\":{\"id\":2534}},{\"nodeType\":1,\"id\":2564,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"333.3333333333333\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2535}},{\"nodeType\":1,\"id\":2565,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"325.3333333333333\"},\"previousSibling\":{\"id\":2564},\"parentNode\":{\"id\":2535}},{\"nodeType\":1,\"id\":2566,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"300\",\"cy\":\"733.3333333333334\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2536}},{\"nodeType\":1,\"id\":2567,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"295\",\"y\":\"725.3333333333334\"},\"previousSibling\":{\"id\":2566},\"parentNode\":{\"id\":2536}},{\"nodeType\":1,\"id\":2568,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"600\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2537}},{\"nodeType\":1,\"id\":2569,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"595\",\"y\":\"658.6666666666667\"},\"previousSibling\":{\"id\":2568},\"parentNode\":{\"id\":2537}},{\"nodeType\":1,\"id\":2570,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"433.3333333333333\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2538}},{\"nodeType\":1,\"id\":2571,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"428.3333333333333\",\"y\":\"592\"},\"previousSibling\":{\"id\":2570},\"parentNode\":{\"id\":2538}},{\"nodeType\":1,\"id\":2572,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"200\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2539}},{\"nodeType\":1,\"id\":2573,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"192\"},\"previousSibling\":{\"id\":2572},\"parentNode\":{\"id\":2539}},{\"nodeType\":1,\"id\":2574,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"533.3333333333333\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2540}},{\"nodeType\":1,\"id\":2575,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"528.3333333333333\",\"y\":\"525.3333333333334\"},\"previousSibling\":{\"id\":2574},\"parentNode\":{\"id\":2540}},{\"nodeType\":1,\"id\":2576,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2541}},{\"nodeType\":1,\"id\":2577,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"658.6666666666667\"},\"previousSibling\":{\"id\":2576},\"parentNode\":{\"id\":2541}},{\"nodeType\":3,\"id\":2578,\"textContent\":\"A \",\"parentNode\":{\"id\":2543}},{\"nodeType\":3,\"id\":2579,\"textContent\":\"B \",\"parentNode\":{\"id\":2545}},{\"nodeType\":3,\"id\":2580,\"textContent\":\"C \",\"parentNode\":{\"id\":2547}},{\"nodeType\":3,\"id\":2581,\"textContent\":\"D \",\"parentNode\":{\"id\":2549}},{\"nodeType\":3,\"id\":2582,\"textContent\":\"E \",\"parentNode\":{\"id\":2551}},{\"nodeType\":3,\"id\":2583,\"textContent\":\"F \",\"parentNode\":{\"id\":2553}},{\"nodeType\":3,\"id\":2584,\"textContent\":\"G \",\"parentNode\":{\"id\":2555}},{\"nodeType\":3,\"id\":2585,\"textContent\":\"H \",\"parentNode\":{\"id\":2557}},{\"nodeType\":3,\"id\":2586,\"textContent\":\"I \",\"parentNode\":{\"id\":2559}},{\"nodeType\":3,\"id\":2587,\"textContent\":\"J \",\"parentNode\":{\"id\":2561}},{\"nodeType\":3,\"id\":2588,\"textContent\":\"K \",\"parentNode\":{\"id\":2563}},{\"nodeType\":3,\"id\":2589,\"textContent\":\"L \",\"parentNode\":{\"id\":2565}},{\"nodeType\":3,\"id\":2590,\"textContent\":\"M \",\"parentNode\":{\"id\":2567}},{\"nodeType\":3,\"id\":2591,\"textContent\":\"N \",\"parentNode\":{\"id\":2569}},{\"nodeType\":3,\"id\":2592,\"textContent\":\"O \",\"parentNode\":{\"id\":2571}},{\"nodeType\":3,\"id\":2593,\"textContent\":\"P \",\"parentNode\":{\"id\":2573}},{\"nodeType\":3,\"id\":2594,\"textContent\":\"Z \",\"parentNode\":{\"id\":2575}},{\"nodeType\":3,\"id\":2595,\"textContent\":\"X \",\"parentNode\":{\"id\":2577}}],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":56},{\"id\":57},{\"id\":58},{\"id\":59},{\"id\":60},{\"id\":61},{\"id\":62},{\"id\":63},{\"id\":64},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":72},{\"id\":73},{\"id\":74},{\"id\":75},{\"id\":76},{\"id\":77},{\"id\":78},{\"id\":79},{\"id\":80},{\"id\":81},{\"id\":82},{\"id\":83},{\"id\":84},{\"id\":85},{\"id\":86},{\"id\":87},{\"id\":88},{\"id\":89},{\"id\":90},{\"id\":91},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":96},{\"id\":97},{\"id\":98},{\"id\":99},{\"id\":100},{\"id\":101},{\"id\":102},{\"id\":103},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":109},{\"id\":110},{\"id\":111},{\"id\":112},{\"id\":113},{\"id\":114},{\"id\":115},{\"id\":116},{\"id\":117},{\"id\":118},{\"id\":119},{\"id\":120},{\"id\":121},{\"id\":122},{\"id\":123},{\"id\":124},{\"id\":125},{\"id\":126},{\"id\":127},{\"id\":128},{\"id\":129},{\"id\":130},{\"id\":131},{\"id\":132},{\"id\":133},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":141},{\"id\":142},{\"id\":143},{\"id\":144},{\"id\":145},{\"id\":146},{\"id\":147},{\"id\":148},{\"id\":149},{\"id\":150},{\"id\":151},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":155},{\"id\":156},{\"id\":157},{\"id\":158},{\"id\":159},{\"id\":160},{\"id\":161},{\"id\":162},{\"id\":163},{\"id\":164},{\"id\":165},{\"id\":166},{\"id\":167},{\"id\":168},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":172},{\"id\":173},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":178},{\"id\":179},{\"id\":180},{\"id\":181},{\"id\":182},{\"id\":183},{\"id\":184},{\"id\":185},{\"id\":186},{\"id\":187},{\"id\":188},{\"id\":189},{\"id\":190},{\"id\":191},{\"id\":192},{\"id\":193},{\"id\":194},{\"id\":195},{\"id\":196},{\"id\":197},{\"id\":198},{\"id\":199},{\"id\":200},{\"id\":201},{\"id\":202},{\"id\":203},{\"id\":204},{\"id\":205},{\"id\":206},{\"id\":207},{\"id\":208},{\"id\":209},{\"id\":210},{\"id\":211},{\"id\":212},{\"id\":213},{\"id\":214},{\"id\":215},{\"id\":216},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":220},{\"id\":221},{\"id\":222},{\"id\":223},{\"id\":224},{\"id\":225},{\"id\":226},{\"id\":227},{\"id\":228},{\"id\":229},{\"id\":230},{\"id\":231},{\"id\":232},{\"id\":233},{\"id\":234},{\"id\":235},{\"id\":236},{\"id\":237},{\"id\":238},{\"id\":239},{\"id\":240},{\"id\":241},{\"id\":242},{\"id\":243},{\"id\":244},{\"id\":245},{\"id\":246},{\"id\":247},{\"id\":248},{\"id\":249},{\"id\":250},{\"id\":251},{\"id\":252},{\"id\":253},{\"id\":254},{\"id\":255},{\"id\":256},{\"id\":257},{\"id\":258},{\"id\":259},{\"id\":260},{\"id\":261},{\"id\":262},{\"id\":263},{\"id\":264},{\"id\":265},{\"id\":266},{\"id\":267},{\"id\":268},{\"id\":269},{\"id\":270},{\"id\":271},{\"id\":272},{\"id\":273},{\"id\":274},{\"id\":275},{\"id\":276},{\"id\":277},{\"id\":278},{\"id\":279},{\"id\":280},{\"id\":281},{\"id\":282},{\"id\":283},{\"id\":284},{\"id\":285},{\"id\":286},{\"id\":287},{\"id\":288},{\"id\":289},{\"id\":290},{\"id\":291},{\"id\":292},{\"id\":293},{\"id\":294},{\"id\":295},{\"id\":296},{\"id\":297},{\"id\":298},{\"id\":299},{\"id\":300},{\"id\":301},{\"id\":302},{\"id\":303},{\"id\":304},{\"id\":305},{\"id\":306},{\"id\":307},{\"id\":308},{\"id\":309},{\"id\":310},{\"id\":311},{\"id\":312},{\"id\":313},{\"id\":314},{\"id\":315},{\"id\":316},{\"id\":317},{\"id\":318},{\"id\":319},{\"id\":320},{\"id\":321},{\"id\":322},{\"id\":323},{\"id\":324},{\"id\":325},{\"id\":326},{\"id\":327},{\"id\":328},{\"id\":329},{\"id\":330},{\"id\":331},{\"id\":332},{\"id\":333},{\"id\":334},{\"id\":335},{\"id\":336},{\"id\":337},{\"id\":338},{\"id\":339},{\"id\":340},{\"id\":341},{\"id\":342},{\"id\":343},{\"id\":344},{\"id\":345},{\"id\":346},{\"id\":347},{\"id\":348},{\"id\":349},{\"id\":350},{\"id\":351},{\"id\":352},{\"id\":353},{\"id\":354},{\"id\":355},{\"id\":356},{\"id\":357},{\"id\":358},{\"id\":359},{\"id\":360},{\"id\":361},{\"id\":362},{\"id\":363},{\"id\":364},{\"id\":365},{\"id\":366},{\"id\":367},{\"id\":368},{\"id\":369},{\"id\":370},{\"id\":371},{\"id\":372},{\"id\":373},{\"id\":374},{\"id\":375},{\"id\":376},{\"id\":377},{\"id\":378},{\"id\":379},{\"id\":380},{\"id\":381},{\"id\":382},{\"id\":383},{\"id\":384},{\"id\":385},{\"id\":386},{\"id\":387},{\"id\":388},{\"id\":389},{\"id\":390},{\"id\":391},{\"id\":392},{\"id\":393},{\"id\":394},{\"id\":395},{\"id\":396},{\"id\":397},{\"id\":398},{\"id\":399},{\"id\":400},{\"id\":401},{\"id\":402},{\"id\":403},{\"id\":404},{\"id\":405},{\"id\":406},{\"id\":407},{\"id\":408},{\"id\":409},{\"id\":410},{\"id\":411},{\"id\":412},{\"id\":413},{\"id\":414},{\"id\":415},{\"id\":416},{\"id\":417},{\"id\":418},{\"id\":419},{\"id\":420},{\"id\":421},{\"id\":422},{\"id\":423},{\"id\":424},{\"id\":425},{\"id\":426},{\"id\":427},{\"id\":428},{\"id\":429},{\"id\":430},{\"id\":431},{\"id\":432},{\"id\":433},{\"id\":434},{\"id\":435},{\"id\":436},{\"id\":437},{\"id\":438},{\"id\":439},{\"id\":440},{\"id\":441},{\"id\":442},{\"id\":443},{\"id\":444},{\"id\":445},{\"id\":446},{\"id\":447},{\"id\":448},{\"id\":449},{\"id\":450},{\"id\":451},{\"id\":452},{\"id\":453},{\"id\":454},{\"id\":455},{\"id\":456},{\"id\":457},{\"id\":458},{\"id\":459},{\"id\":460},{\"id\":461},{\"id\":462},{\"id\":463},{\"id\":464},{\"id\":465},{\"id\":466},{\"id\":467},{\"id\":468},{\"id\":469},{\"id\":470},{\"id\":471},{\"id\":472},{\"id\":473},{\"id\":474},{\"id\":475},{\"id\":476},{\"id\":477},{\"id\":478},{\"id\":479},{\"id\":480},{\"id\":481},{\"id\":482},{\"id\":483},{\"id\":484},{\"id\":485},{\"id\":486},{\"id\":487},{\"id\":488},{\"id\":489},{\"id\":490},{\"id\":491},{\"id\":492},{\"id\":493},{\"id\":494},{\"id\":495},{\"id\":496},{\"id\":497},{\"id\":498},{\"id\":499},{\"id\":500},{\"id\":501},{\"id\":502},{\"id\":503},{\"id\":504},{\"id\":505},{\"id\":506},{\"id\":507},{\"id\":508},{\"id\":509},{\"id\":510},{\"id\":511},{\"id\":512},{\"id\":513},{\"id\":514},{\"id\":515},{\"id\":516},{\"id\":517},{\"id\":518},{\"id\":519},{\"id\":520},{\"id\":521},{\"id\":522},{\"id\":523},{\"id\":524},{\"id\":525},{\"id\":526},{\"id\":527},{\"id\":528},{\"id\":529},{\"id\":530},{\"id\":531},{\"id\":532},{\"id\":533},{\"id\":534},{\"id\":535},{\"id\":536},{\"id\":537},{\"id\":538},{\"id\":539},{\"id\":540},{\"id\":541},{\"id\":542},{\"id\":543},{\"id\":544},{\"id\":545},{\"id\":546},{\"id\":547},{\"id\":548},{\"id\":549},{\"id\":550},{\"id\":551},{\"id\":552},{\"id\":553},{\"id\":554},{\"id\":555},{\"id\":556},{\"id\":557},{\"id\":558},{\"id\":559},{\"id\":560},{\"id\":561},{\"id\":562},{\"id\":563},{\"id\":564},{\"id\":565},{\"id\":566},{\"id\":567},{\"id\":568},{\"id\":569},{\"id\":570},{\"id\":571},{\"id\":572},{\"id\":573},{\"id\":574},{\"id\":575},{\"id\":576},{\"id\":577},{\"id\":578},{\"id\":579},{\"id\":580},{\"id\":581},{\"id\":582},{\"id\":583},{\"id\":584},{\"id\":585},{\"id\":586},{\"id\":587},{\"id\":588},{\"id\":589},{\"id\":590},{\"id\":591},{\"id\":592},{\"id\":593},{\"id\":594},{\"id\":595},{\"id\":596},{\"id\":597},{\"id\":598},{\"id\":599},{\"id\":600},{\"id\":601},{\"id\":602},{\"id\":603},{\"id\":604},{\"id\":605},{\"id\":606},{\"id\":607},{\"id\":608},{\"id\":609},{\"id\":610},{\"id\":611},{\"id\":612},{\"id\":613},{\"id\":614},{\"id\":615},{\"id\":616},{\"id\":617},{\"id\":618},{\"id\":619},{\"id\":620},{\"id\":621},{\"id\":622},{\"id\":623},{\"id\":624},{\"id\":625},{\"id\":626},{\"id\":627},{\"id\":628},{\"id\":629},{\"id\":630},{\"id\":631},{\"id\":632},{\"id\":633},{\"id\":634},{\"id\":635},{\"id\":636},{\"id\":637},{\"id\":638},{\"id\":639},{\"id\":640},{\"id\":641},{\"id\":642},{\"id\":643},{\"id\":644},{\"id\":645},{\"id\":646},{\"id\":647},{\"id\":648},{\"id\":649},{\"id\":650},{\"id\":651},{\"id\":652},{\"id\":653},{\"id\":654},{\"id\":655},{\"id\":656},{\"id\":657},{\"id\":658},{\"id\":659},{\"id\":660},{\"id\":661},{\"id\":662},{\"id\":663},{\"id\":664},{\"id\":665},{\"id\":666},{\"id\":667},{\"id\":668},{\"id\":669},{\"id\":670},{\"id\":671},{\"id\":672},{\"id\":673},{\"id\":674},{\"id\":675},{\"id\":676},{\"id\":677},{\"id\":678},{\"id\":679},{\"id\":680},{\"id\":681},{\"id\":682},{\"id\":683},{\"id\":684},{\"id\":685},{\"id\":686},{\"id\":687},{\"id\":688},{\"id\":689},{\"id\":690},{\"id\":691},{\"id\":692},{\"id\":693},{\"id\":694},{\"id\":695},{\"id\":696},{\"id\":697},{\"id\":698},{\"id\":699},{\"id\":700},{\"id\":701},{\"id\":702},{\"id\":703},{\"id\":704},{\"id\":705},{\"id\":706},{\"id\":707},{\"id\":708},{\"id\":709},{\"id\":710},{\"id\":711},{\"id\":712},{\"id\":713},{\"id\":714},{\"id\":715},{\"id\":716},{\"id\":717},{\"id\":718},{\"id\":719},{\"id\":720},{\"id\":721},{\"id\":722},{\"id\":723},{\"id\":724},{\"id\":725},{\"id\":726},{\"id\":727},{\"id\":728},{\"id\":729},{\"id\":730},{\"id\":731},{\"id\":732},{\"id\":733},{\"id\":734},{\"id\":735},{\"id\":736},{\"id\":737},{\"id\":738},{\"id\":739},{\"id\":740},{\"id\":741},{\"id\":742},{\"id\":743},{\"id\":744},{\"id\":745},{\"id\":746},{\"id\":747},{\"id\":748},{\"id\":749},{\"id\":750},{\"id\":751},{\"id\":752},{\"id\":753},{\"id\":754},{\"id\":755},{\"id\":756},{\"id\":757},{\"id\":758},{\"id\":759},{\"id\":760},{\"id\":761},{\"id\":762},{\"id\":763},{\"id\":764},{\"id\":765},{\"id\":766},{\"id\":767},{\"id\":768},{\"id\":769},{\"id\":770},{\"id\":771},{\"id\":772},{\"id\":773},{\"id\":774},{\"id\":775},{\"id\":776},{\"id\":777},{\"id\":778},{\"id\":779},{\"id\":780},{\"id\":781},{\"id\":782},{\"id\":783},{\"id\":784},{\"id\":785},{\"id\":786},{\"id\":787},{\"id\":788},{\"id\":789},{\"id\":790},{\"id\":791},{\"id\":792},{\"id\":793},{\"id\":794},{\"id\":795},{\"id\":796},{\"id\":797},{\"id\":798},{\"id\":799},{\"id\":800},{\"id\":801},{\"id\":802},{\"id\":803},{\"id\":804},{\"id\":805},{\"id\":806},{\"id\":807},{\"id\":808},{\"id\":809},{\"id\":810},{\"id\":811},{\"id\":812},{\"id\":813},{\"id\":814},{\"id\":815},{\"id\":816},{\"id\":817},{\"id\":818},{\"id\":819},{\"id\":820},{\"id\":821},{\"id\":822},{\"id\":823},{\"id\":824},{\"id\":825},{\"id\":826},{\"id\":827},{\"id\":828},{\"id\":829},{\"id\":830},{\"id\":831},{\"id\":832},{\"id\":833},{\"id\":834},{\"id\":835},{\"id\":836},{\"id\":837},{\"id\":838},{\"id\":839},{\"id\":840},{\"id\":841},{\"id\":842},{\"id\":843},{\"id\":844},{\"id\":845},{\"id\":846},{\"id\":847},{\"id\":848},{\"id\":849},{\"id\":850},{\"id\":851},{\"id\":852},{\"id\":853},{\"id\":854},{\"id\":855},{\"id\":856},{\"id\":857},{\"id\":858},{\"id\":859},{\"id\":860},{\"id\":861},{\"id\":862},{\"id\":863},{\"id\":864},{\"id\":865},{\"id\":866},{\"id\":867},{\"id\":868},{\"id\":869},{\"id\":870},{\"id\":871},{\"id\":872},{\"id\":873},{\"id\":874},{\"id\":875},{\"id\":876},{\"id\":877},{\"id\":878},{\"id\":879},{\"id\":880},{\"id\":881},{\"id\":882},{\"id\":883},{\"id\":884},{\"id\":885},{\"id\":886},{\"id\":887},{\"id\":888},{\"id\":889},{\"id\":890},{\"id\":891},{\"id\":892},{\"id\":893},{\"id\":894},{\"id\":895},{\"id\":896},{\"id\":897},{\"id\":898},{\"id\":899},{\"id\":900},{\"id\":901},{\"id\":902},{\"id\":903},{\"id\":904},{\"id\":905},{\"id\":906},{\"id\":907},{\"id\":908},{\"id\":909},{\"id\":910},{\"id\":911},{\"id\":912},{\"id\":913},{\"id\":914},{\"id\":915},{\"id\":916},{\"id\":917},{\"id\":918},{\"id\":919},{\"id\":920},{\"id\":921},{\"id\":922},{\"id\":923},{\"id\":924},{\"id\":925},{\"id\":926},{\"id\":927},{\"id\":928},{\"id\":929},{\"id\":930},{\"id\":931},{\"id\":932},{\"id\":933},{\"id\":934},{\"id\":935},{\"id\":936},{\"id\":937},{\"id\":938},{\"id\":939},{\"id\":940},{\"id\":941},{\"id\":942},{\"id\":943},{\"id\":944},{\"id\":945},{\"id\":946},{\"id\":947},{\"id\":948},{\"id\":949},{\"id\":950},{\"id\":951},{\"id\":952},{\"id\":953},{\"id\":954},{\"id\":955},{\"id\":956},{\"id\":957},{\"id\":958},{\"id\":959},{\"id\":960},{\"id\":961},{\"id\":962},{\"id\":963},{\"id\":964},{\"id\":965},{\"id\":966},{\"id\":967},{\"id\":968},{\"id\":969},{\"id\":970},{\"id\":971},{\"id\":972},{\"id\":973},{\"id\":974},{\"id\":975},{\"id\":976},{\"id\":977},{\"id\":978},{\"id\":979},{\"id\":980},{\"id\":981},{\"id\":982},{\"id\":983},{\"id\":984},{\"id\":985},{\"id\":986},{\"id\":987},{\"id\":988},{\"id\":989},{\"id\":990},{\"id\":991},{\"id\":992},{\"id\":993},{\"id\":994},{\"id\":995},{\"id\":996},{\"id\":997},{\"id\":998},{\"id\":999},{\"id\":1000},{\"id\":1001},{\"id\":1002},{\"id\":1003},{\"id\":1004},{\"id\":1005},{\"id\":1006},{\"id\":1007},{\"id\":1008},{\"id\":1009},{\"id\":1010},{\"id\":1011},{\"id\":1012},{\"id\":1013},{\"id\":1014},{\"id\":1015},{\"id\":1016},{\"id\":1017},{\"id\":1018},{\"id\":1019},{\"id\":1020},{\"id\":1021},{\"id\":1022},{\"id\":1023},{\"id\":1024},{\"id\":1025},{\"id\":1026},{\"id\":1027},{\"id\":1028},{\"id\":1029},{\"id\":1030},{\"id\":1031},{\"id\":1032},{\"id\":1033},{\"id\":1034},{\"id\":1035},{\"id\":1036},{\"id\":1037},{\"id\":1038},{\"id\":1039},{\"id\":1040},{\"id\":1041},{\"id\":1042},{\"id\":1043},{\"id\":1044},{\"id\":1045},{\"id\":1046},{\"id\":1047},{\"id\":1048},{\"id\":1049},{\"id\":1050},{\"id\":1051},{\"id\":1052},{\"id\":1053},{\"id\":1054},{\"id\":1055},{\"id\":1056},{\"id\":1057},{\"id\":1058},{\"id\":1059},{\"id\":1060},{\"id\":1061},{\"id\":1062},{\"id\":1063},{\"id\":1064},{\"id\":1065},{\"id\":1066},{\"id\":1067},{\"id\":1068},{\"id\":1069},{\"id\":1070},{\"id\":1071},{\"id\":1072},{\"id\":1073},{\"id\":1074},{\"id\":1075},{\"id\":1076},{\"id\":1077},{\"id\":1078},{\"id\":1079},{\"id\":1080},{\"id\":1081},{\"id\":1082},{\"id\":1083},{\"id\":1084},{\"id\":1085},{\"id\":1086},{\"id\":1087},{\"id\":1088},{\"id\":1089},{\"id\":1090},{\"id\":1091},{\"id\":1092},{\"id\":1093},{\"id\":1094},{\"id\":1095},{\"id\":1096},{\"id\":1097},{\"id\":1098},{\"id\":1099},{\"id\":1100},{\"id\":1101},{\"id\":1102},{\"id\":1103},{\"id\":1104},{\"id\":1105},{\"id\":1106},{\"id\":1107},{\"id\":1108},{\"id\":1109},{\"id\":1110},{\"id\":1111},{\"id\":1112},{\"id\":1113},{\"id\":1114},{\"id\":1115},{\"id\":1116},{\"id\":1117},{\"id\":1118},{\"id\":1119},{\"id\":1120},{\"id\":1121},{\"id\":1122},{\"id\":1123},{\"id\":1124},{\"id\":1125},{\"id\":1126},{\"id\":1127},{\"id\":1128},{\"id\":1129},{\"id\":1130},{\"id\":1131},{\"id\":1132},{\"id\":1133},{\"id\":1134},{\"id\":1135},{\"id\":1136},{\"id\":1137},{\"id\":1138},{\"id\":1139},{\"id\":1140},{\"id\":1141},{\"id\":1142},{\"id\":1143},{\"id\":1144},{\"id\":1145},{\"id\":1146},{\"id\":1147},{\"id\":1148},{\"id\":1149},{\"id\":1150},{\"id\":1151},{\"id\":1152},{\"id\":1153},{\"id\":1154},{\"id\":1155},{\"id\":1156},{\"id\":1157},{\"id\":1158},{\"id\":1159},{\"id\":1160},{\"id\":1161},{\"id\":1162},{\"id\":1163},{\"id\":1164},{\"id\":1165},{\"id\":1166},{\"id\":1167},{\"id\":1168},{\"id\":1169},{\"id\":1170},{\"id\":1171},{\"id\":1172},{\"id\":1173},{\"id\":1174},{\"id\":1175},{\"id\":1176},{\"id\":1177},{\"id\":1178},{\"id\":1179},{\"id\":1180},{\"id\":1181},{\"id\":1182},{\"id\":1183},{\"id\":1184},{\"id\":1185},{\"id\":1186},{\"id\":1187},{\"id\":1188},{\"id\":1189},{\"id\":1190},{\"id\":1191},{\"id\":1192},{\"id\":1193},{\"id\":1194},{\"id\":1195},{\"id\":1196},{\"id\":1197},{\"id\":1198},{\"id\":1199},{\"id\":1200},{\"id\":1201},{\"id\":1202},{\"id\":1203},{\"id\":1204},{\"id\":1205},{\"id\":1206},{\"id\":1207},{\"id\":1208},{\"id\":1209},{\"id\":1210},{\"id\":1211},{\"id\":1212},{\"id\":1213},{\"id\":1214},{\"id\":1215},{\"id\":1216},{\"id\":1217},{\"id\":1218},{\"id\":1219},{\"id\":1220},{\"id\":1221},{\"id\":1222},{\"id\":1223},{\"id\":1224},{\"id\":1225},{\"id\":1226},{\"id\":1227},{\"id\":1228},{\"id\":1229},{\"id\":1230},{\"id\":1231},{\"id\":1232},{\"id\":1233},{\"id\":1234},{\"id\":1235},{\"id\":1236},{\"id\":1237},{\"id\":1238},{\"id\":1239},{\"id\":1240},{\"id\":1241},{\"id\":1242},{\"id\":1243},{\"id\":1244},{\"id\":1245},{\"id\":1246},{\"id\":1247},{\"id\":1248},{\"id\":1249},{\"id\":1250},{\"id\":1251},{\"id\":1252},{\"id\":1253},{\"id\":1254},{\"id\":1255},{\"id\":1256},{\"id\":1257},{\"id\":1258},{\"id\":1259},{\"id\":1260},{\"id\":1261},{\"id\":1262},{\"id\":1263},{\"id\":1264},{\"id\":1265},{\"id\":1266},{\"id\":1267},{\"id\":1268},{\"id\":1269},{\"id\":1270},{\"id\":1271},{\"id\":1272},{\"id\":1273},{\"id\":1274},{\"id\":1275},{\"id\":1276},{\"id\":1277},{\"id\":1278},{\"id\":1279},{\"id\":1280},{\"id\":1281},{\"id\":1282},{\"id\":1283},{\"id\":1284},{\"id\":1285},{\"id\":1286},{\"id\":1287},{\"id\":1288},{\"id\":1289},{\"id\":1290},{\"id\":1291},{\"id\":1292},{\"id\":1293},{\"id\":1294},{\"id\":1295},{\"id\":1296},{\"id\":1297},{\"id\":1298},{\"id\":1299},{\"id\":1300},{\"id\":1301},{\"id\":1302},{\"id\":1303},{\"id\":1304},{\"id\":1305},{\"id\":1306},{\"id\":1307},{\"id\":1308},{\"id\":1309},{\"id\":1310},{\"id\":1311},{\"id\":1312},{\"id\":1313},{\"id\":1314},{\"id\":1315},{\"id\":1316},{\"id\":1317},{\"id\":1318},{\"id\":1319},{\"id\":1320},{\"id\":1321},{\"id\":1322},{\"id\":1323},{\"id\":1324},{\"id\":1325},{\"id\":1326},{\"id\":1327},{\"id\":1328},{\"id\":1329},{\"id\":1330},{\"id\":1331},{\"id\":1332},{\"id\":1333},{\"id\":1334},{\"id\":1335},{\"id\":1336},{\"id\":1337},{\"id\":1338},{\"id\":1339},{\"id\":1340},{\"id\":1341},{\"id\":1342},{\"id\":1343},{\"id\":1344},{\"id\":1345},{\"id\":1346},{\"id\":1347},{\"id\":1348},{\"id\":1349},{\"id\":1350},{\"id\":1351},{\"id\":1352},{\"id\":1353},{\"id\":1354},{\"id\":1355},{\"id\":1356},{\"id\":1357},{\"id\":1358},{\"id\":1359},{\"id\":1360},{\"id\":1361},{\"id\":1362},{\"id\":1363},{\"id\":1364},{\"id\":1365},{\"id\":1366},{\"id\":1367},{\"id\":1368},{\"id\":1369},{\"id\":1370},{\"id\":1371},{\"id\":1372},{\"id\":1373},{\"id\":1374},{\"id\":1375},{\"id\":1376},{\"id\":1377},{\"id\":1378},{\"id\":1379},{\"id\":1380},{\"id\":1381},{\"id\":1382},{\"id\":1383},{\"id\":1384},{\"id\":1385},{\"id\":1386},{\"id\":1387},{\"id\":1388},{\"id\":1389},{\"id\":1390},{\"id\":1391},{\"id\":1392},{\"id\":1393},{\"id\":1394},{\"id\":1395},{\"id\":1396},{\"id\":1397},{\"id\":1398},{\"id\":1399},{\"id\":1400},{\"id\":1401},{\"id\":1402},{\"id\":1403},{\"id\":1404},{\"id\":1405},{\"id\":1406},{\"id\":1407},{\"id\":1408},{\"id\":1409},{\"id\":1410},{\"id\":1411},{\"id\":1412},{\"id\":1413},{\"id\":1414},{\"id\":1415},{\"id\":1416},{\"id\":1417},{\"id\":1418},{\"id\":1419},{\"id\":1420},{\"id\":1421},{\"id\":1422},{\"id\":1423},{\"id\":1424},{\"id\":1425},{\"id\":1426},{\"id\":1427},{\"id\":1428},{\"id\":1429},{\"id\":1430},{\"id\":1431},{\"id\":1432},{\"id\":1433},{\"id\":1434},{\"id\":1435},{\"id\":1436},{\"id\":1437},{\"id\":1438},{\"id\":1439},{\"id\":1440},{\"id\":1441},{\"id\":1442},{\"id\":1443},{\"id\":1444},{\"id\":1445},{\"id\":1446},{\"id\":1447},{\"id\":1448},{\"id\":1449},{\"id\":1450},{\"id\":1451},{\"id\":1452},{\"id\":1453},{\"id\":1454},{\"id\":1455},{\"id\":1456},{\"id\":1457},{\"id\":1458},{\"id\":1459},{\"id\":1460},{\"id\":1461},{\"id\":1462},{\"id\":1463},{\"id\":1464},{\"id\":1465},{\"id\":1466},{\"id\":1467},{\"id\":1468},{\"id\":1469},{\"id\":1470},{\"id\":1471},{\"id\":1472},{\"id\":1473},{\"id\":1474},{\"id\":1475},{\"id\":1476},{\"id\":1477},{\"id\":1478},{\"id\":1479},{\"id\":1480},{\"id\":1481},{\"id\":1482},{\"id\":1483},{\"id\":1484},{\"id\":1485},{\"id\":1486},{\"id\":1487},{\"id\":1488},{\"id\":1489},{\"id\":1490},{\"id\":1491},{\"id\":1492},{\"id\":1493},{\"id\":1494},{\"id\":1495},{\"id\":1496},{\"id\":1497},{\"id\":1498},{\"id\":1499},{\"id\":1500},{\"id\":1501},{\"id\":1502},{\"id\":1503},{\"id\":1504},{\"id\":1505},{\"id\":1506},{\"id\":1507},{\"id\":1508},{\"id\":1509},{\"id\":1510},{\"id\":1511},{\"id\":1512},{\"id\":1513},{\"id\":1514},{\"id\":1515},{\"id\":1516},{\"id\":1517},{\"id\":1518},{\"id\":1519},{\"id\":1520},{\"id\":1521},{\"id\":1522},{\"id\":1523},{\"id\":1524},{\"id\":1525},{\"id\":1526},{\"id\":1527},{\"id\":1528},{\"id\":1529},{\"id\":1530},{\"id\":1531},{\"id\":1532},{\"id\":1533},{\"id\":1534},{\"id\":1535},{\"id\":1536},{\"id\":1537},{\"id\":1538},{\"id\":1539},{\"id\":1540},{\"id\":1541},{\"id\":1542},{\"id\":1543},{\"id\":1544},{\"id\":1545},{\"id\":1546},{\"id\":1547},{\"id\":1548},{\"id\":1549},{\"id\":1550},{\"id\":1551},{\"id\":1552},{\"id\":1553},{\"id\":1554},{\"id\":1555},{\"id\":1556},{\"id\":1557},{\"id\":1558},{\"id\":1559},{\"id\":1560},{\"id\":1561},{\"id\":1562},{\"id\":1563},{\"id\":1564},{\"id\":1565},{\"id\":1566},{\"id\":1567},{\"id\":1568},{\"id\":1569},{\"id\":1570},{\"id\":1571},{\"id\":1572},{\"id\":1573},{\"id\":1574},{\"id\":1575},{\"id\":1576},{\"id\":1577},{\"id\":1578},{\"id\":1579},{\"id\":1580},{\"id\":1581},{\"id\":1582},{\"id\":1583},{\"id\":1584},{\"id\":1585},{\"id\":1586},{\"id\":1587},{\"id\":1588},{\"id\":1589},{\"id\":1590},{\"id\":1591},{\"id\":1592},{\"id\":1593},{\"id\":1594},{\"id\":1595},{\"id\":1596},{\"id\":1597},{\"id\":1598},{\"id\":1599},{\"id\":1600},{\"id\":1601},{\"id\":1602},{\"id\":1603},{\"id\":1604},{\"id\":1605},{\"id\":1606},{\"id\":1607},{\"id\":1608},{\"id\":1609},{\"id\":1610},{\"id\":1611},{\"id\":1612},{\"id\":1613},{\"id\":1614},{\"id\":1615},{\"id\":1616},{\"id\":1617},{\"id\":1618},{\"id\":1619},{\"id\":1620},{\"id\":1621},{\"id\":1622},{\"id\":1623},{\"id\":1624},{\"id\":1625},{\"id\":1626},{\"id\":1627},{\"id\":1628},{\"id\":1629},{\"id\":1630},{\"id\":1631},{\"id\":1632},{\"id\":1633},{\"id\":1634},{\"id\":1635},{\"id\":1636},{\"id\":1637},{\"id\":1638},{\"id\":1639},{\"id\":1640},{\"id\":1641},{\"id\":1642},{\"id\":1643},{\"id\":1644},{\"id\":1645},{\"id\":1646},{\"id\":1647},{\"id\":1648},{\"id\":1649},{\"id\":1650},{\"id\":1651},{\"id\":1652},{\"id\":1653},{\"id\":1654},{\"id\":1655},{\"id\":1656},{\"id\":1657},{\"id\":1658},{\"id\":1659},{\"id\":1660},{\"id\":1661},{\"id\":1662},{\"id\":1663},{\"id\":1664},{\"id\":1665},{\"id\":1666},{\"id\":1667},{\"id\":1668},{\"id\":1669},{\"id\":1670},{\"id\":1671},{\"id\":1672},{\"id\":1673},{\"id\":1674},{\"id\":1675},{\"id\":1676},{\"id\":1677},{\"id\":1678},{\"id\":1679},{\"id\":1680},{\"id\":1681},{\"id\":1682},{\"id\":1683},{\"id\":1684},{\"id\":1685},{\"id\":1686},{\"id\":1687},{\"id\":1688},{\"id\":1689},{\"id\":1690},{\"id\":1691},{\"id\":1692},{\"id\":1693},{\"id\":1694},{\"id\":1695},{\"id\":1696},{\"id\":1697},{\"id\":1698},{\"id\":1699},{\"id\":1700},{\"id\":1701},{\"id\":1702},{\"id\":1703},{\"id\":1704},{\"id\":1705},{\"id\":1706},{\"id\":1707},{\"id\":1708},{\"id\":1709},{\"id\":1710},{\"id\":1711},{\"id\":1712},{\"id\":1713},{\"id\":1714},{\"id\":1715},{\"id\":1716},{\"id\":1717},{\"id\":1718},{\"id\":1719},{\"id\":1720},{\"id\":1721},{\"id\":1722},{\"id\":1723},{\"id\":1724},{\"id\":1725},{\"id\":1726},{\"id\":1727},{\"id\":1728},{\"id\":1729},{\"id\":1730},{\"id\":1731},{\"id\":1732},{\"id\":1733},{\"id\":1734},{\"id\":1735},{\"id\":1736},{\"id\":1737},{\"id\":1738},{\"id\":1739},{\"id\":1740},{\"id\":1741},{\"id\":1742},{\"id\":1743},{\"id\":1744},{\"id\":1745},{\"id\":1746},{\"id\":1747},{\"id\":1748},{\"id\":1749},{\"id\":1750},{\"id\":1751},{\"id\":1752},{\"id\":1753},{\"id\":1754},{\"id\":1755},{\"id\":1756},{\"id\":1757},{\"id\":1758},{\"id\":1759},{\"id\":1760},{\"id\":1761},{\"id\":1762},{\"id\":1763},{\"id\":1764},{\"id\":1765},{\"id\":1766},{\"id\":1767},{\"id\":1768},{\"id\":1769},{\"id\":1770},{\"id\":1771},{\"id\":1772},{\"id\":1773},{\"id\":1774},{\"id\":1775},{\"id\":1776},{\"id\":1777},{\"id\":1778},{\"id\":1779},{\"id\":1780},{\"id\":1781},{\"id\":1782},{\"id\":1783},{\"id\":1784},{\"id\":1785},{\"id\":1786},{\"id\":1787},{\"id\":1788},{\"id\":1789},{\"id\":1790},{\"id\":1791},{\"id\":1792},{\"id\":1793},{\"id\":1794},{\"id\":1795},{\"id\":1796},{\"id\":1797},{\"id\":1798},{\"id\":1799},{\"id\":1800},{\"id\":1801},{\"id\":1802},{\"id\":1803},{\"id\":1804},{\"id\":1805},{\"id\":1806},{\"id\":1807},{\"id\":1808},{\"id\":1809},{\"id\":1810},{\"id\":1811},{\"id\":1812},{\"id\":1813},{\"id\":1814},{\"id\":1815},{\"id\":1816},{\"id\":1817},{\"id\":1818},{\"id\":1819},{\"id\":1820},{\"id\":1821},{\"id\":1822},{\"id\":1823},{\"id\":1824},{\"id\":1825},{\"id\":1826},{\"id\":1827},{\"id\":1828},{\"id\":1829},{\"id\":1830},{\"id\":1831},{\"id\":1832},{\"id\":1833},{\"id\":1834},{\"id\":1835},{\"id\":1836},{\"id\":1837},{\"id\":1838},{\"id\":1839},{\"id\":1840},{\"id\":1841},{\"id\":1842},{\"id\":1843},{\"id\":1844},{\"id\":1845},{\"id\":1846},{\"id\":1847},{\"id\":1848},{\"id\":1849},{\"id\":1850},{\"id\":1851},{\"id\":1852},{\"id\":1853},{\"id\":1854},{\"id\":1855},{\"id\":1856},{\"id\":1857},{\"id\":1858},{\"id\":1859},{\"id\":1860},{\"id\":1861},{\"id\":1862},{\"id\":1863},{\"id\":1864},{\"id\":1865},{\"id\":1866},{\"id\":1867},{\"id\":1868},{\"id\":1869},{\"id\":1870},{\"id\":1871},{\"id\":1872},{\"id\":1873},{\"id\":1874},{\"id\":1875},{\"id\":1876},{\"id\":1877},{\"id\":1878},{\"id\":1879},{\"id\":1880},{\"id\":1881},{\"id\":1882},{\"id\":1883},{\"id\":1884},{\"id\":1885},{\"id\":1886},{\"id\":1887},{\"id\":1888},{\"id\":1889},{\"id\":1890},{\"id\":1891},{\"id\":1892},{\"id\":1893},{\"id\":1894},{\"id\":1895},{\"id\":1896},{\"id\":1897},{\"id\":1898},{\"id\":1899},{\"id\":1900},{\"id\":1901},{\"id\":1902},{\"id\":1903},{\"id\":1904},{\"id\":1905},{\"id\":1906},{\"id\":1907},{\"id\":1908},{\"id\":1909},{\"id\":1910},{\"id\":1911},{\"id\":1912},{\"id\":1913},{\"id\":1914},{\"id\":1915},{\"id\":1916},{\"id\":1917},{\"id\":1918},{\"id\":1919},{\"id\":1920},{\"id\":1921},{\"id\":1922},{\"id\":1923},{\"id\":1924},{\"id\":1925},{\"id\":1926},{\"id\":1927},{\"id\":1928},{\"id\":1929},{\"id\":1930},{\"id\":1931},{\"id\":1932},{\"id\":1933},{\"id\":1934},{\"id\":1935},{\"id\":1936},{\"id\":1937},{\"id\":1938},{\"id\":1939},{\"id\":1940},{\"id\":1941},{\"id\":1942},{\"id\":1943},{\"id\":1944},{\"id\":1945},{\"id\":1946},{\"id\":1947},{\"id\":1948},{\"id\":1949},{\"id\":1950},{\"id\":1951},{\"id\":1952},{\"id\":1953},{\"id\":1954},{\"id\":1955},{\"id\":1956},{\"id\":1957},{\"id\":1958},{\"id\":1959},{\"id\":1960},{\"id\":1961},{\"id\":1962},{\"id\":1963},{\"id\":1964},{\"id\":1965},{\"id\":1966},{\"id\":1967},{\"id\":1968},{\"id\":1969},{\"id\":1970},{\"id\":1971},{\"id\":1972},{\"id\":1973},{\"id\":1974},{\"id\":1975},{\"id\":1976},{\"id\":1977},{\"id\":1978},{\"id\":1979},{\"id\":1980},{\"id\":1981},{\"id\":1982},{\"id\":1983},{\"id\":1984},{\"id\":1985},{\"id\":1986},{\"id\":1987},{\"id\":1988},{\"id\":1989},{\"id\":1990},{\"id\":1991},{\"id\":1992},{\"id\":1993},{\"id\":1994},{\"id\":1995},{\"id\":1996},{\"id\":1997},{\"id\":1998},{\"id\":1999},{\"id\":2000},{\"id\":2001},{\"id\":2002},{\"id\":2003},{\"id\":2004},{\"id\":2005},{\"id\":2006},{\"id\":2007},{\"id\":2008},{\"id\":2009},{\"id\":2010},{\"id\":2011},{\"id\":2012},{\"id\":2013},{\"id\":2014},{\"id\":2015},{\"id\":2016},{\"id\":2017},{\"id\":2018},{\"id\":2019},{\"id\":2020},{\"id\":2021},{\"id\":2022},{\"id\":2023},{\"id\":2024},{\"id\":2025},{\"id\":2026},{\"id\":2027},{\"id\":2028},{\"id\":2029},{\"id\":2030},{\"id\":2031},{\"id\":2032},{\"id\":2033},{\"id\":2034},{\"id\":2035},{\"id\":2036},{\"id\":2037},{\"id\":2038},{\"id\":2039},{\"id\":2040},{\"id\":2041},{\"id\":2042},{\"id\":2043},{\"id\":2044},{\"id\":2045},{\"id\":2046},{\"id\":2047},{\"id\":2048},{\"id\":2049},{\"id\":2050},{\"id\":2051},{\"id\":2052},{\"id\":2053},{\"id\":2054},{\"id\":2055},{\"id\":2056},{\"id\":2057},{\"id\":2058},{\"id\":2059},{\"id\":2060},{\"id\":2061},{\"id\":2062},{\"id\":2063},{\"id\":2064},{\"id\":2065},{\"id\":2066},{\"id\":2067},{\"id\":2068},{\"id\":2069},{\"id\":2070},{\"id\":2071},{\"id\":2072},{\"id\":2073},{\"id\":2074},{\"id\":2075},{\"id\":2076},{\"id\":2077},{\"id\":2078},{\"id\":2079},{\"id\":2080},{\"id\":2081},{\"id\":2082},{\"id\":2083},{\"id\":2084},{\"id\":2085},{\"id\":2086},{\"id\":2087},{\"id\":2088},{\"id\":2089},{\"id\":2090},{\"id\":2091},{\"id\":2092},{\"id\":2093},{\"id\":2094},{\"id\":2095},{\"id\":2096},{\"id\":2097},{\"id\":2098},{\"id\":2099},{\"id\":2100},{\"id\":2101},{\"id\":2102},{\"id\":2103},{\"id\":2104},{\"id\":2105},{\"id\":2106},{\"id\":2107},{\"id\":2108},{\"id\":2109},{\"id\":2110},{\"id\":2111},{\"id\":2112},{\"id\":2113},{\"id\":2114},{\"id\":2115},{\"id\":2116},{\"id\":2117},{\"id\":2118},{\"id\":2119},{\"id\":2120},{\"id\":2121},{\"id\":2122},{\"id\":2123},{\"id\":2124},{\"id\":2125},{\"id\":2126},{\"id\":2127},{\"id\":2128},{\"id\":2129},{\"id\":2130},{\"id\":2131},{\"id\":2132},{\"id\":2133},{\"id\":2134},{\"id\":2135},{\"id\":2136},{\"id\":2137},{\"id\":2138},{\"id\":2139},{\"id\":2140},{\"id\":2141},{\"id\":2142},{\"id\":2143},{\"id\":2144},{\"id\":2145},{\"id\":2146},{\"id\":2147},{\"id\":2148},{\"id\":2149},{\"id\":2150},{\"id\":2151},{\"id\":2152},{\"id\":2153},{\"id\":2154},{\"id\":2155},{\"id\":2156},{\"id\":2157},{\"id\":2158},{\"id\":2159},{\"id\":2160},{\"id\":2161},{\"id\":2162},{\"id\":2163},{\"id\":2164},{\"id\":2165},{\"id\":2166},{\"id\":2167},{\"id\":2168},{\"id\":2169},{\"id\":2170},{\"id\":2171},{\"id\":2172},{\"id\":2173},{\"id\":2174},{\"id\":2175},{\"id\":2176},{\"id\":2177},{\"id\":2178},{\"id\":2179},{\"id\":2180},{\"id\":2181},{\"id\":2182},{\"id\":2183},{\"id\":2184},{\"id\":2185},{\"id\":2186},{\"id\":2187},{\"id\":2188},{\"id\":2189},{\"id\":2190},{\"id\":2191},{\"id\":2192},{\"id\":2193},{\"id\":2194},{\"id\":2195},{\"id\":2196},{\"id\":2197},{\"id\":2198},{\"id\":2199},{\"id\":2200},{\"id\":2201},{\"id\":2202},{\"id\":2203},{\"id\":2204},{\"id\":2205},{\"id\":2206},{\"id\":2207},{\"id\":2208},{\"id\":2209},{\"id\":2210},{\"id\":2211},{\"id\":2212},{\"id\":2213},{\"id\":2214},{\"id\":2215},{\"id\":2216},{\"id\":2217},{\"id\":2218},{\"id\":2219},{\"id\":2220},{\"id\":2221},{\"id\":2222},{\"id\":2223},{\"id\":2224},{\"id\":2225},{\"id\":2226},{\"id\":2227},{\"id\":2228},{\"id\":2229},{\"id\":2230},{\"id\":2231},{\"id\":2232},{\"id\":2233},{\"id\":2234},{\"id\":2235},{\"id\":2236},{\"id\":2237},{\"id\":2238},{\"id\":2239},{\"id\":2240},{\"id\":2241},{\"id\":2242},{\"id\":2243},{\"id\":2244},{\"id\":2245},{\"id\":2246},{\"id\":2247},{\"id\":2248},{\"id\":2249},{\"id\":2250},{\"id\":2251},{\"id\":2252},{\"id\":2253},{\"id\":2254},{\"id\":2255},{\"id\":2256},{\"id\":2257},{\"id\":2258},{\"id\":2259},{\"id\":2260},{\"id\":2261},{\"id\":2262},{\"id\":2263},{\"id\":2264},{\"id\":2265},{\"id\":2266},{\"id\":2267},{\"id\":2268},{\"id\":2269},{\"id\":2270},{\"id\":2271},{\"id\":2272},{\"id\":2273},{\"id\":2274},{\"id\":2275},{\"id\":2276},{\"id\":2277},{\"id\":2278},{\"id\":2279},{\"id\":2280},{\"id\":2281},{\"id\":2282},{\"id\":2283},{\"id\":2284},{\"id\":2285},{\"id\":2286},{\"id\":2287},{\"id\":2288},{\"id\":2289},{\"id\":2290},{\"id\":2291},{\"id\":2292},{\"id\":2293},{\"id\":2294},{\"id\":2295},{\"id\":2296},{\"id\":2297},{\"id\":2298},{\"id\":2299},{\"id\":2300},{\"id\":2301},{\"id\":2302},{\"id\":2311},{\"id\":2316},{\"id\":2317},{\"id\":2343},{\"id\":2344},{\"id\":2393},{\"id\":2318},{\"id\":2345},{\"id\":2346},{\"id\":2394},{\"id\":2319},{\"id\":2347},{\"id\":2348},{\"id\":2395},{\"id\":2320},{\"id\":2349},{\"id\":2350},{\"id\":2396},{\"id\":2321},{\"id\":2351},{\"id\":2352},{\"id\":2397},{\"id\":2322},{\"id\":2353},{\"id\":2354},{\"id\":2398},{\"id\":2323},{\"id\":2355},{\"id\":2356},{\"id\":2399},{\"id\":2324},{\"id\":2357},{\"id\":2358},{\"id\":2400},{\"id\":2325},{\"id\":2359},{\"id\":2360},{\"id\":2401},{\"id\":2326},{\"id\":2361},{\"id\":2362},{\"id\":2402},{\"id\":2327},{\"id\":2363},{\"id\":2364},{\"id\":2403},{\"id\":2328},{\"id\":2365},{\"id\":2366},{\"id\":2404},{\"id\":2329},{\"id\":2367},{\"id\":2368},{\"id\":2405},{\"id\":2330},{\"id\":2369},{\"id\":2370},{\"id\":2406},{\"id\":2331},{\"id\":2371},{\"id\":2372},{\"id\":2407},{\"id\":2332},{\"id\":2373},{\"id\":2374},{\"id\":2408},{\"id\":2333},{\"id\":2375},{\"id\":2376},{\"id\":2409},{\"id\":2334},{\"id\":2377},{\"id\":2378},{\"id\":2410},{\"id\":2335},{\"id\":2379},{\"id\":2380},{\"id\":2411},{\"id\":2336},{\"id\":2381},{\"id\":2382},{\"id\":2412},{\"id\":2337},{\"id\":2383},{\"id\":2384},{\"id\":2413},{\"id\":2338},{\"id\":2385},{\"id\":2386},{\"id\":2414},{\"id\":2339},{\"id\":2387},{\"id\":2388},{\"id\":2415},{\"id\":2340},{\"id\":2389},{\"id\":2390},{\"id\":2416},{\"id\":2341},{\"id\":2391},{\"id\":2392},{\"id\":2417},{\"id\":2342},{\"id\":2418},{\"id\":2419},{\"id\":2312},{\"id\":2420},{\"id\":2421},{\"id\":2435},{\"id\":2436},{\"id\":2461},{\"id\":2422},{\"id\":2437},{\"id\":2438},{\"id\":2462},{\"id\":2423},{\"id\":2439},{\"id\":2440},{\"id\":2463},{\"id\":2424},{\"id\":2441},{\"id\":2442},{\"id\":2464},{\"id\":2425},{\"id\":2443},{\"id\":2444},{\"id\":2465},{\"id\":2426},{\"id\":2445},{\"id\":2446},{\"id\":2466},{\"id\":2427},{\"id\":2447},{\"id\":2448},{\"id\":2467},{\"id\":2428},{\"id\":2449},{\"id\":2450},{\"id\":2468},{\"id\":2429},{\"id\":2451},{\"id\":2452},{\"id\":2469},{\"id\":2430},{\"id\":2453},{\"id\":2454},{\"id\":2470},{\"id\":2431},{\"id\":2455},{\"id\":2456},{\"id\":2471},{\"id\":2432},{\"id\":2457},{\"id\":2458},{\"id\":2472},{\"id\":2433},{\"id\":2459},{\"id\":2460},{\"id\":2473},{\"id\":2434},{\"id\":2474},{\"id\":2475},{\"id\":2313},{\"id\":2476},{\"id\":2488},{\"id\":2477},{\"id\":2489},{\"id\":2478},{\"id\":2490},{\"id\":2479},{\"id\":2491},{\"id\":2480},{\"id\":2492},{\"id\":2481},{\"id\":2493},{\"id\":2482},{\"id\":2494},{\"id\":2483},{\"id\":2495},{\"id\":2484},{\"id\":2496},{\"id\":2485},{\"id\":2497},{\"id\":2486},{\"id\":2498},{\"id\":2487},{\"id\":2499},{\"id\":2314},{\"id\":2500},{\"id\":2501},{\"id\":2502},{\"id\":2503},{\"id\":2504},{\"id\":2505},{\"id\":2506},{\"id\":2507},{\"id\":2508},{\"id\":2509},{\"id\":2510},{\"id\":2511},{\"id\":2512},{\"id\":2513},{\"id\":2514},{\"id\":2515},{\"id\":2516},{\"id\":2517},{\"id\":2518},{\"id\":2519},{\"id\":2520},{\"id\":2521},{\"id\":2522},{\"id\":2523},{\"id\":2315},{\"id\":2524},{\"id\":2542},{\"id\":2543},{\"id\":2578},{\"id\":2525},{\"id\":2544},{\"id\":2545},{\"id\":2579},{\"id\":2526},{\"id\":2546},{\"id\":2547},{\"id\":2580},{\"id\":2527},{\"id\":2548},{\"id\":2549},{\"id\":2581},{\"id\":2528},{\"id\":2550},{\"id\":2551},{\"id\":2582},{\"id\":2529},{\"id\":2552},{\"id\":2553},{\"id\":2583},{\"id\":2530},{\"id\":2554},{\"id\":2555},{\"id\":2584},{\"id\":2531},{\"id\":2556},{\"id\":2557},{\"id\":2585},{\"id\":2532},{\"id\":2558},{\"id\":2559},{\"id\":2586},{\"id\":2533},{\"id\":2560},{\"id\":2561},{\"id\":2587},{\"id\":2534},{\"id\":2562},{\"id\":2563},{\"id\":2588},{\"id\":2535},{\"id\":2564},{\"id\":2565},{\"id\":2589},{\"id\":2536},{\"id\":2566},{\"id\":2567},{\"id\":2590},{\"id\":2537},{\"id\":2568},{\"id\":2569},{\"id\":2591},{\"id\":2538},{\"id\":2570},{\"id\":2571},{\"id\":2592},{\"id\":2539},{\"id\":2572},{\"id\":2573},{\"id\":2593},{\"id\":2540},{\"id\":2574},{\"id\":2575},{\"id\":2594},{\"id\":2541},{\"id\":2576},{\"id\":2577},{\"id\":2595},{\"id\":2303},{\"id\":2304},{\"id\":2305},{\"id\":2306},{\"id\":2307},{\"nodeType\":3,\"id\":2596,\"textContent\":\" // Track clicks on page $(document).ready(function() { $(\\\".control\\\").click(function(e) { e.stopImmediatePropagation(); clicks = clicks + 1; console.log(clicks); }); }); $('.userid').html(sid); // console.log(\\\"start of clicked array: \\\"+clicked); // console.log(\\\"start of hovered string: \\\"+hovered); //set correct answers for each question var triangular_answers = { \\\"acme.starttime.1\\\" : [\\\"F\\\"], \\\"acme.starts.1\\\" : [\\\"K\\\"], \\\"acme.meets.1\\\" : [\\\"F\\\"], \\\"acme.endtime.1\\\" : [\\\"H\\\"], \\\"acme.midpoint.1\\\" : [\\\"O\\\"], \\\"acme.starttime.2\\\" : [\\\"F\\\"], \\\"acme.starts.2\\\" : [\\\"K\\\"], \\\"acme.meets.2\\\" : [\\\"F\\\"], \\\"acme.endtime.2\\\" : [\\\"H\\\"], \\\"acme.midpoint.2\\\" : [\\\"A\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"E\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"E\\\"], \\\"bigset.starttime.1\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.1\\\" : [\\\"G\\\"], \\\"bigset.meets.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.1\\\" : [\\\"X\\\"], \\\"bigset.midpoint.1\\\" : [\\\"K\\\",\\\"X\\\"], \\\"bigset.starttime.2\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.2\\\" : [\\\"G\\\"], \\\"bigset.meets.2\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.2\\\" : [\\\"X\\\"], \\\"bigset.midpoint.2\\\" : [\\\"K\\\",\\\"X\\\"] } var orthogonal_answers = { \\\"acme.starttime.1\\\" : [\\\"A\\\"], \\\"acme.starts.1\\\" : [\\\"E\\\"], \\\"acme.meets.1\\\" : [\\\"Z\\\"], \\\"acme.endtime.1\\\" : [\\\"U\\\"], \\\"acme.midpoint.1\\\" : [\\\"U\\\"], \\\"acme.starttime.2\\\" : [\\\"0\\\"], \\\"acme.starts.2\\\" : [\\\"0\\\"], \\\"acme.meets.2\\\" : [\\\"0\\\"], \\\"acme.endtime.2\\\" : [\\\"0\\\"], \\\"acme.midpoint.2\\\" : [\\\"0\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"X\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"X\\\"], \\\"bigset.starttime.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.1\\\" : [\\\"B\\\"], \\\"bigset.meets.1\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.1\\\" : [\\\"B\\\"], \\\"bigset.midpoint.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.starttime.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.2\\\" : [\\\"B\\\"], \\\"bigset.meets.2\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.2\\\" : [\\\"B\\\"], \\\"bigset.midpoint.2\\\" : [\\\"E\\\",\\\"F\\\"] } //display the question and answer buttons based on input values from jsPsych document.getElementById(scenario+\\\".\\\"+question).style.display = \\\"block\\\"; if (question == \\\"strategy\\\") {document.getElementById(\\\"strategyButton\\\").style.display = \\\"block\\\";} else {document.getElementById(\\\"testingButton\\\").style.display = \\\"block\\\";} //---------SET PROPERTIES OF THE GRAPH -------------// // set the dimensions and margins of the graph var margin = {top: 25, right: 30, bottom: 90, left: 100}, width = 800, height = 800; var intersects = false; //default value for intersects scaffold var xAxisTitle, yAxisTitle; var datafile =\\\"\\\"; // SET AXIS VALUES if (axis == 1){ axis = \\\"Orthogonal-XInside-YFull\\\"; } else if (axis == 2){ axis = \\\"Orthogonal-XInside-YPartial\\\"; } else if (axis ==3){ axis = \\\"Triangular-XInside-YInside\\\"; } else if (axis ==4){ axis = \\\"Orthogonal-XInside-YInside\\\"; } else if (axis ==5){ axis = \\\"Orthogonal-XFull-YFull\\\"; } // SET EXPLICIT SCAFFOLD FEATURES if (explicit ==2 && axis != \\\"diagonal\\\"){ scaffold = 2; intersects = false; } else if (explicit == 2 && axis == \\\"diagonal\\\"){ scaffold = 2; intersects = false; } //TODO: not sure if above two lines are still valid since leaders are now generated on the fly else if (explicit == 3){ $('#hint-interactive').css(\\\"display\\\",\\\"block\\\"); //display textimage scaffold intersects = true; } //SET DATA FILE FOR IMPLICIT SCAFFOLD if (impasse == 1){ datafile = \\\"../views/src/data/acme_nonimpasse.csv\\\"; } else if (impasse == 2){ datafile = \\\"../views/src/data/acme_impasse.csv\\\"; } //OVERRIDE DATA FILE FOR NON-SCAFFOLD QUESTIONS if (q > 5) { //override data file if q# is greater than 5 datafile = \\\"../views/src/data/bigset.csv\\\"; console.log(\\\"override data file\\\"); $('#orthogonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#diagonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#hint-interactive').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold intersects = false; } // //---------CREATE THE SVG ------------------------// var svg = d3.select(\\\".d3container\\\").append(\\\"svg\\\") .attr(\\\"width\\\", width + margin.left + margin.right) .attr(\\\"height\\\", height + margin.top + margin.bottom) .append(\\\"g\\\") .attr(\\\"transform\\\", \\\"translate(\\\" + margin.left + \\\",\\\" + margin.top + \\\")\\\"); //---------DRAW THE GRAPH ------------------------// xAxisTitle = \\\"START & END TIME (time of day)\\\"; yAxisTitle = \\\"DURATION (in hours)\\\"; drawTriangleModel(datafile,intersects,axis,scaffold,q); \"},{\"id\":2308},{\"id\":2309},{\"nodeType\":3,\"id\":2597,\"textContent\":\" //MOUSE LOGGING SCRIPT var mouseLog = [] var xwidth = $(document).width(); var xheight = $(document).width(); mouseLog.push(\\\"{x:\\\"+xwidth+\\\",y:\\\"+xheight+\\\",t:\\\"+\\\"0};\\\") document.onmousemove = function(e){ var pageCoords = \\\"{x:\\\" + e.pageX + \\\",y:\\\"+ e.pageY +\\\",t:\\\"+ Date.now()+ \\\"};\\\" ; mouseLog.push(pageCoords); // console.log(pageCoords); }; \"},{\"id\":2310}],[],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2598,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2599,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2598},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2600,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2599},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2601,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":2600},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2602,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2599}},{\"nodeType\":1,\"id\":2603,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2602},\"parentNode\":{\"id\":2599}},{\"nodeType\":3,\"id\":2604,\"textContent\":\"What is your age?\",\"parentNode\":{\"id\":2602}},{\"nodeType\":1,\"id\":2605,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2600}},{\"nodeType\":1,\"id\":2606,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2605},\"parentNode\":{\"id\":2600}},{\"nodeType\":3,\"id\":2607,\"textContent\":\"In what country were you born?\",\"parentNode\":{\"id\":2605}},{\"nodeType\":3,\"id\":2608,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":2601}}],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2598},{\"id\":2599},{\"id\":2602},{\"id\":2604},{\"id\":2603},{\"id\":2600},{\"id\":2605},{\"id\":2607},{\"id\":2606},{\"id\":2601},{\"id\":2608}],[],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2609,\"tagName\":\"FORM\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-form\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2610,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-preamble\",\"class\":\"jspsych-survey-multi-choice-preamble\"},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2611,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-0\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2610},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2612,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-1\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2611},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2613,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-2\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2612},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2614,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-3\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2613},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2615,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"submit\",\"id\":\"jspsych-survey-multi-choice-next\",\"class\":\"jspsych-survey-multi-choice jspsych-btn\",\"value\":\"Submit Answers\"},\"previousSibling\":{\"id\":2614},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2616,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2617,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2616},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2618,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2617},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2619,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2618},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2620,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2619},\"parentNode\":{\"id\":2611}},{\"nodeType\":3,\"id\":2621,\"textContent\":\"What is your first language?\",\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2622,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2621},\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2623,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2624,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2623}},{\"nodeType\":3,\"id\":2625,\"textContent\":\"English\",\"previousSibling\":{\"id\":2624},\"parentNode\":{\"id\":2623}},{\"nodeType\":1,\"id\":2626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2618}},{\"nodeType\":1,\"id\":2627,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2626}},{\"nodeType\":3,\"id\":2628,\"textContent\":\"Spanish\",\"previousSibling\":{\"id\":2627},\"parentNode\":{\"id\":2626}},{\"nodeType\":1,\"id\":2629,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2619}},{\"nodeType\":1,\"id\":2630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2629}},{\"nodeType\":3,\"id\":2631,\"textContent\":\"Mandarin or Cantonese\",\"previousSibling\":{\"id\":2630},\"parentNode\":{\"id\":2629}},{\"nodeType\":1,\"id\":2632,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2633,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2634,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2633},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2635,\"textContent\":\"*\",\"parentNode\":{\"id\":2622}},{\"nodeType\":1,\"id\":2636,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2637,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2636},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2638,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2637},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2639,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2638},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2640,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2639},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2641,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2640},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2642,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2641},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2643,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2642},\"parentNode\":{\"id\":2612}},{\"nodeType\":3,\"id\":2644,\"textContent\":\"What is your year in school?\",\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2645,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2644},\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2646,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2637}},{\"nodeType\":1,\"id\":2647,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2646}},{\"nodeType\":3,\"id\":2648,\"textContent\":\"First\",\"previousSibling\":{\"id\":2647},\"parentNode\":{\"id\":2646}},{\"nodeType\":1,\"id\":2649,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2638}},{\"nodeType\":1,\"id\":2650,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2649}},{\"nodeType\":3,\"id\":2651,\"textContent\":\"Second\",\"previousSibling\":{\"id\":2650},\"parentNode\":{\"id\":2649}},{\"nodeType\":1,\"id\":2652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2639}},{\"nodeType\":1,\"id\":2653,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2652}},{\"nodeType\":3,\"id\":2654,\"textContent\":\"Third\",\"previousSibling\":{\"id\":2653},\"parentNode\":{\"id\":2652}},{\"nodeType\":1,\"id\":2655,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2640}},{\"nodeType\":1,\"id\":2656,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2655}},{\"nodeType\":3,\"id\":2657,\"textContent\":\"Fourth\",\"previousSibling\":{\"id\":2656},\"parentNode\":{\"id\":2655}},{\"nodeType\":1,\"id\":2658,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2641}},{\"nodeType\":1,\"id\":2659,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2658}},{\"nodeType\":3,\"id\":2660,\"textContent\":\"Fifth\",\"previousSibling\":{\"id\":2659},\"parentNode\":{\"id\":2658}},{\"nodeType\":1,\"id\":2661,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2642}},{\"nodeType\":1,\"id\":2662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2661}},{\"nodeType\":3,\"id\":2663,\"textContent\":\"Graduate\",\"previousSibling\":{\"id\":2662},\"parentNode\":{\"id\":2661}},{\"nodeType\":1,\"id\":2664,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2643}},{\"nodeType\":1,\"id\":2665,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2666,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2665},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2667,\"textContent\":\"*\",\"parentNode\":{\"id\":2645}},{\"nodeType\":1,\"id\":2668,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2669,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2668},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2670,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2669},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2671,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2670},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2672,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2671},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2673,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2672},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2674,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2673},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2675,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2674},\"parentNode\":{\"id\":2613}},{\"nodeType\":3,\"id\":2676,\"textContent\":\"What is your major area of study?\",\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2677,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2676},\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2678,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2669}},{\"nodeType\":1,\"id\":2679,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2678}},{\"nodeType\":3,\"id\":2680,\"textContent\":\"Math or Computer Sciences\",\"previousSibling\":{\"id\":2679},\"parentNode\":{\"id\":2678}},{\"nodeType\":1,\"id\":2681,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2670}},{\"nodeType\":1,\"id\":2682,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2681}},{\"nodeType\":3,\"id\":2683,\"textContent\":\"Social Sciences (incl. CogSci)\",\"previousSibling\":{\"id\":2682},\"parentNode\":{\"id\":2681}},{\"nodeType\":1,\"id\":2684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2671}},{\"nodeType\":1,\"id\":2685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2684}},{\"nodeType\":3,\"id\":2686,\"textContent\":\"Biomedical & Health Sciences\",\"previousSibling\":{\"id\":2685},\"parentNode\":{\"id\":2684}},{\"nodeType\":1,\"id\":2687,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2672}},{\"nodeType\":1,\"id\":2688,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2687}},{\"nodeType\":3,\"id\":2689,\"textContent\":\"Natural Sciences\",\"previousSibling\":{\"id\":2688},\"parentNode\":{\"id\":2687}},{\"nodeType\":1,\"id\":2690,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2673}},{\"nodeType\":1,\"id\":2691,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2690}},{\"nodeType\":3,\"id\":2692,\"textContent\":\"Engineering\",\"previousSibling\":{\"id\":2691},\"parentNode\":{\"id\":2690}},{\"nodeType\":1,\"id\":2693,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2674}},{\"nodeType\":1,\"id\":2694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2693}},{\"nodeType\":3,\"id\":2695,\"textContent\":\"Humanities\",\"previousSibling\":{\"id\":2694},\"parentNode\":{\"id\":2693}},{\"nodeType\":1,\"id\":2696,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2675}},{\"nodeType\":1,\"id\":2697,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2698,\"textContent\":\"Fine Arts\",\"previousSibling\":{\"id\":2697},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2699,\"textContent\":\"*\",\"parentNode\":{\"id\":2677}},{\"nodeType\":1,\"id\":2700,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2701,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2700},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2702,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2701},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2703,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2702},\"parentNode\":{\"id\":2614}},{\"nodeType\":3,\"id\":2704,\"textContent\":\"What is your gender?\",\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2705,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2704},\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2706,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2701}},{\"nodeType\":1,\"id\":2707,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2706}},{\"nodeType\":3,\"id\":2708,\"textContent\":\"Male\",\"previousSibling\":{\"id\":2707},\"parentNode\":{\"id\":2706}},{\"nodeType\":1,\"id\":2709,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2702}},{\"nodeType\":1,\"id\":2710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2709}},{\"nodeType\":3,\"id\":2711,\"textContent\":\"Female\",\"previousSibling\":{\"id\":2710},\"parentNode\":{\"id\":2709}},{\"nodeType\":1,\"id\":2712,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2703}},{\"nodeType\":1,\"id\":2713,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2714,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2713},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2715,\"textContent\":\"*\",\"parentNode\":{\"id\":2705}}],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2609},{\"id\":2610},{\"id\":2611},{\"id\":2616},{\"id\":2621},{\"id\":2622},{\"id\":2635},{\"id\":2617},{\"id\":2623},{\"id\":2624},{\"id\":2625},{\"id\":2618},{\"id\":2626},{\"id\":2627},{\"id\":2628},{\"id\":2619},{\"id\":2629},{\"id\":2630},{\"id\":2631},{\"id\":2620},{\"id\":2632},{\"id\":2633},{\"id\":2634},{\"id\":2612},{\"id\":2636},{\"id\":2644},{\"id\":2645},{\"id\":2667},{\"id\":2637},{\"id\":2646},{\"id\":2647},{\"id\":2648},{\"id\":2638},{\"id\":2649},{\"id\":2650},{\"id\":2651},{\"id\":2639},{\"id\":2652},{\"id\":2653},{\"id\":2654},{\"id\":2640},{\"id\":2655},{\"id\":2656},{\"id\":2657},{\"id\":2641},{\"id\":2658},{\"id\":2659},{\"id\":2660},{\"id\":2642},{\"id\":2661},{\"id\":2662},{\"id\":2663},{\"id\":2643},{\"id\":2664},{\"id\":2665},{\"id\":2666},{\"id\":2613},{\"id\":2668},{\"id\":2676},{\"id\":2677},{\"id\":2699},{\"id\":2669},{\"id\":2678},{\"id\":2679},{\"id\":2680},{\"id\":2670},{\"id\":2681},{\"id\":2682},{\"id\":2683},{\"id\":2671},{\"id\":2684},{\"id\":2685},{\"id\":2686},{\"id\":2672},{\"id\":2687},{\"id\":2688},{\"id\":2689},{\"id\":2673},{\"id\":2690},{\"id\":2691},{\"id\":2692},{\"id\":2674},{\"id\":2693},{\"id\":2694},{\"id\":2695},{\"id\":2675},{\"id\":2696},{\"id\":2697},{\"id\":2698},{\"id\":2614},{\"id\":2700},{\"id\":2704},{\"id\":2705},{\"id\":2715},{\"id\":2701},{\"id\":2706},{\"id\":2707},{\"id\":2708},{\"id\":2702},{\"id\":2709},{\"id\":2710},{\"id\":2711},{\"id\":2703},{\"id\":2712},{\"id\":2713},{\"id\":2714},{\"id\":2615}],[],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2716,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2717,\"textContent\":\" \",\"previousSibling\":{\"id\":2716},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2718,\"textContent\":\" \",\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":2718},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2720,\"textContent\":\" \",\"previousSibling\":{\"id\":2719},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2721,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":2720},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2722,\"textContent\":\" \",\"previousSibling\":{\"id\":2721},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2723,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":2722},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2724,\"textContent\":\" \",\"previousSibling\":{\"id\":2723},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2725,\"textContent\":\" \",\"parentNode\":{\"id\":2719}},{\"nodeType\":1,\"id\":2726,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":2725},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2727,\"textContent\":\" \",\"previousSibling\":{\"id\":2726},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2728,\"textContent\":\" \",\"parentNode\":{\"id\":2726}},{\"nodeType\":1,\"id\":2729,\"tagName\":\"H3\",\"attributes\":{},\"previousSibling\":{\"id\":2728},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2730,\"textContent\":\" \",\"previousSibling\":{\"id\":2729},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2731,\"textContent\":\"DEBRIEFING\",\"parentNode\":{\"id\":2729}},{\"nodeType\":3,\"id\":2732,\"textContent\":\" \",\"parentNode\":{\"id\":2721}},{\"nodeType\":1,\"id\":2733,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":2732},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2734,\"textContent\":\" \",\"previousSibling\":{\"id\":2733},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2735,\"textContent\":\" \",\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2736,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic\"},\"previousSibling\":{\"id\":2735},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2737,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2736},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2738,\"textContent\":\" \",\"previousSibling\":{\"id\":2737},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2739,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2738},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2740,\"textContent\":\" \",\"previousSibling\":{\"id\":2739},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2741,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2740},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2742,\"textContent\":\" \",\"previousSibling\":{\"id\":2741},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2743,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:bold;\"},\"previousSibling\":{\"id\":2742},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2744,\"textContent\":\" \",\"previousSibling\":{\"id\":2743},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2745,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":2744},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2746,\"textContent\":\" \",\"previousSibling\":{\"id\":2745},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2747,\"textContent\":\"Thank you very much for your participation! This debriefing will tell you more about the study, what you did, and why. \",\"parentNode\":{\"id\":2736}},{\"nodeType\":3,\"id\":2748,\"textContent\":\" \",\"parentNode\":{\"id\":2737}},{\"nodeType\":1,\"id\":2749,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2748},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2750,\"textContent\":\" You have just used a series of pictures (charts, graphs and diagrams) accompanied by different types of instructions to answer a series of problem solving questions. While you were using the pictures, we measured where you clicked, scrolled and pointed with the computer mouse. We also measured the accuracy of your responses and the time it took to complete each question.\",\"previousSibling\":{\"id\":2749},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2751,\"textContent\":\"What did you just do?\",\"parentNode\":{\"id\":2749}},{\"nodeType\":3,\"id\":2752,\"textContent\":\" \",\"parentNode\":{\"id\":2739}},{\"nodeType\":1,\"id\":2753,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2752},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2754,\"textContent\":\" Researchers of learning and cognition have long been interested in how graphic displays of information can be used to communicate, solve problems, and generate insights. As powerful as graphics may be in their communicative efficiency, they're not always immediately intuitive to understand. In short, we know a great deal more about learning with representations than we do about the learning of representations. In this project we are building upon previous research on reading and graph comprehension to explore how readers make sense of unfamiliar representations. The instructions you saw for each type of graph are known as “scaffolding techniques”, and we will compare your performance with the scaffolding techniques you saw with the performance of other participants to determine which types of instructions are most effective in helping humans to make sense of unfamiliar graphs. \",\"previousSibling\":{\"id\":2753},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2755,\"textContent\":\"Why did we have you do it?\",\"parentNode\":{\"id\":2753}},{\"nodeType\":1,\"id\":2756,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2757,\"textContent\":\" We expect that you will have found some of the graphics more difficult to use than others. We also expect that with the assistance of the instructions, after solving several problems you will learn to use the difficult graphics so that you can answer the questions even more quickly than without. If you would like to receive a copy of the results of the study, or have any further questions, please contact the researchers Primary Researcher: Amy Fox : a2fox@ucsd.edu Faculty Advisor : Dr. Jim Hollan : hollan@ucsd.edu \",\"previousSibling\":{\"id\":2756},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2758,\"textContent\":\"What do we expect to find?\",\"parentNode\":{\"id\":2756}},{\"nodeType\":3,\"id\":2759,\"textContent\":\"It is important that you do not discuss this experiment with other students who might participate after you. They must participate in the same way as you did, without any knowledge of what the experiment entails, or the reasoning behind it.\",\"parentNode\":{\"id\":2743}},{\"nodeType\":3,\"id\":2760,\"textContent\":\"Thank you for your time! We hope you enjoyed participating in this study as much as we enjoyed designing it.\",\"parentNode\":{\"id\":2745}},{\"nodeType\":3,\"id\":2761,\"textContent\":\" \",\"parentNode\":{\"id\":2723}},{\"nodeType\":1,\"id\":2762,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":2761},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2763,\"textContent\":\" \",\"previousSibling\":{\"id\":2762},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2764,\"textContent\":\"FINISH\",\"parentNode\":{\"id\":2762}}],[],[]]}"
    },
    {
      "sequence": 8,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2716},{\"id\":2718},{\"id\":2719},{\"id\":2725},{\"id\":2726},{\"id\":2728},{\"id\":2729},{\"id\":2731},{\"id\":2730},{\"id\":2727},{\"id\":2720},{\"id\":2721},{\"id\":2732},{\"id\":2733},{\"id\":2735},{\"id\":2736},{\"id\":2747},{\"id\":2737},{\"id\":2748},{\"id\":2749},{\"id\":2751},{\"id\":2750},{\"id\":2738},{\"id\":2739},{\"id\":2752},{\"id\":2753},{\"id\":2755},{\"id\":2754},{\"id\":2740},{\"id\":2741},{\"id\":2756},{\"id\":2758},{\"id\":2757},{\"id\":2742},{\"id\":2743},{\"id\":2759},{\"id\":2744},{\"id\":2745},{\"id\":2760},{\"id\":2746},{\"id\":2734},{\"id\":2722},{\"id\":2723},{\"id\":2761},{\"id\":2762},{\"id\":2764},{\"id\":2763},{\"id\":2724},{\"id\":2717}],[],[],[]]}"
    },
    {
      "sequence": 9,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2765,\"tagName\":\"PRE\",\"attributes\":{\"id\":\"jspsych-data-display\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2766,\"textContent\":\"[ { \\\"rt\\\": 62851, \\\"stimulus\\\": \\\"img/phone.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"phone\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 0, \\\"time_elapsed\\\": 62857, \\\"internal_node_id\\\": \\\"0.0-0.0\\\", \\\"subject\\\": \\\"VT5BG\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"golf\\\", \\\"condition\\\": \\\"121\\\" }, { \\\"rt\\\": 14767, \\\"url\\\": \\\"../views/src/external/consent.html\\\", \\\"block\\\": \\\"consent\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 1, \\\"time_elapsed\\\": 78944, \\\"internal_node_id\\\": \\\"0.0-1.0\\\", \\\"subject\\\": \\\"VT5BG\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"golf\\\", \\\"condition\\\": \\\"121\\\" }, { \\\"rt\\\": 11956, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"golf\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"121\\\\\\\"}\\\", \\\"block\\\": \\\"codes\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 2, \\\"time_elapsed\\\": 91906, \\\"internal_node_id\\\": \\\"0.0-2.0\\\", \\\"subject\\\": \\\"VT5BG\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"golf\\\", \\\"condition\\\": \\\"121\\\" }, { \\\"rt\\\": 16945, \\\"url\\\": \\\"../views/src/external/instructions_lab.html\\\", \\\"block\\\": \\\"instructions_lab\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 3, \\\"time_elapsed\\\": 109935, \\\"internal_node_id\\\": \\\"0.0-3.0\\\", \\\"subject\\\": \\\"VT5BG\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"golf\\\", \\\"condition\\\": \\\"121\\\" }, { \\\"rt\\\": 10373, \\\"stimulus\\\": \\\"img/acme.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"scenario\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 4, \\\"time_elapsed\\\": 121312, \\\"internal_node_id\\\": \\\"0.0-4.0\\\", \\\"subject\\\": \\\"VT5BG\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"golf\\\", \\\"condition\\\": \\\"121\\\" }, { \\\"rt\\\": 49714, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 5, \\\"time_elapsed\\\": 172406, \\\"internal_node_id\\\": \\\"0.0-5.0-0.0\\\", \\\"subject\\\": \\\"VT5BG\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"golf\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 1, \\\"clicks\\\": 0, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-10 AM-11 AM-01 PM-11 AM-O -O -10 AM-O -11 AM-11 AM-11 AM-4\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:982,y:1029,t:1527019520792};\\\", \\\"{x:986,y:1029,t:1527019520801};\\\", \\\"{x:999,y:1025,t:1527019520818};\\\", \\\"{x:1012,y:1022,t:1527019520834};\\\", \\\"{x:1023,y:1019,t:1527019520850};\\\", \\\"{x:1029,y:1017,t:1527019520868};\\\", \\\"{x:1037,y:1015,t:1527019520885};\\\", \\\"{x:1045,y:1013,t:1527019520900};\\\", \\\"{x:1053,y:1011,t:1527019520917};\\\", \\\"{x:1064,y:1008,t:1527019520934};\\\", \\\"{x:1070,y:1005,t:1527019520950};\\\", \\\"{x:1080,y:1002,t:1527019520968};\\\", \\\"{x:1101,y:997,t:1527019520985};\\\", \\\"{x:1126,y:993,t:1527019521001};\\\", \\\"{x:1161,y:988,t:1527019521018};\\\", \\\"{x:1203,y:984,t:1527019521035};\\\", \\\"{x:1245,y:978,t:1527019521052};\\\", \\\"{x:1281,y:973,t:1527019521068};\\\", \\\"{x:1317,y:970,t:1527019521085};\\\", \\\"{x:1351,y:965,t:1527019521101};\\\", \\\"{x:1375,y:961,t:1527019521118};\\\", \\\"{x:1407,y:956,t:1527019521135};\\\", \\\"{x:1418,y:955,t:1527019521152};\\\", \\\"{x:1426,y:955,t:1527019521168};\\\", \\\"{x:1428,y:955,t:1527019521185};\\\", \\\"{x:1429,y:955,t:1527019521263};\\\", \\\"{x:1429,y:958,t:1527019521279};\\\", \\\"{x:1429,y:959,t:1527019521287};\\\", \\\"{x:1429,y:962,t:1527019521301};\\\", \\\"{x:1429,y:967,t:1527019521318};\\\", \\\"{x:1433,y:980,t:1527019521335};\\\", \\\"{x:1438,y:990,t:1527019521352};\\\", \\\"{x:1442,y:995,t:1527019521367};\\\", \\\"{x:1443,y:996,t:1527019521384};\\\", \\\"{x:1444,y:997,t:1527019521401};\\\", \\\"{x:1443,y:998,t:1527019521542};\\\", \\\"{x:1442,y:1000,t:1527019521551};\\\", \\\"{x:1438,y:1001,t:1527019521569};\\\", \\\"{x:1437,y:1002,t:1527019521584};\\\", \\\"{x:1435,y:1003,t:1527019521601};\\\", \\\"{x:1433,y:1003,t:1527019521630};\\\", \\\"{x:1432,y:1003,t:1527019521638};\\\", \\\"{x:1428,y:1003,t:1527019521652};\\\", \\\"{x:1419,y:1003,t:1527019521669};\\\", \\\"{x:1412,y:1003,t:1527019521684};\\\", \\\"{x:1402,y:1002,t:1527019521702};\\\", \\\"{x:1377,y:998,t:1527019521719};\\\", \\\"{x:1360,y:997,t:1527019521734};\\\", \\\"{x:1349,y:996,t:1527019521752};\\\", \\\"{x:1345,y:996,t:1527019521769};\\\", \\\"{x:1341,y:996,t:1527019521785};\\\", \\\"{x:1336,y:996,t:1527019521802};\\\", \\\"{x:1330,y:996,t:1527019521820};\\\", \\\"{x:1325,y:996,t:1527019521835};\\\", \\\"{x:1317,y:996,t:1527019521852};\\\", \\\"{x:1311,y:996,t:1527019521869};\\\", \\\"{x:1307,y:996,t:1527019521885};\\\", \\\"{x:1306,y:996,t:1527019521983};\\\", \\\"{x:1304,y:996,t:1527019522031};\\\", \\\"{x:1302,y:995,t:1527019522047};\\\", \\\"{x:1302,y:994,t:1527019522055};\\\", \\\"{x:1301,y:994,t:1527019522069};\\\", \\\"{x:1299,y:993,t:1527019522086};\\\", \\\"{x:1296,y:992,t:1527019522102};\\\", \\\"{x:1290,y:989,t:1527019522119};\\\", \\\"{x:1286,y:986,t:1527019522136};\\\", \\\"{x:1285,y:984,t:1527019522153};\\\", \\\"{x:1285,y:983,t:1527019522168};\\\", \\\"{x:1285,y:981,t:1527019522186};\\\", \\\"{x:1285,y:975,t:1527019522202};\\\", \\\"{x:1284,y:969,t:1527019522218};\\\", \\\"{x:1281,y:964,t:1527019522237};\\\", \\\"{x:1281,y:961,t:1527019522252};\\\", \\\"{x:1280,y:960,t:1527019522269};\\\", \\\"{x:1279,y:959,t:1527019522286};\\\", \\\"{x:1278,y:958,t:1527019522302};\\\", \\\"{x:1278,y:957,t:1527019522895};\\\", \\\"{x:1278,y:956,t:1527019522902};\\\", \\\"{x:1278,y:953,t:1527019522920};\\\", \\\"{x:1278,y:949,t:1527019522936};\\\", \\\"{x:1278,y:945,t:1527019522953};\\\", \\\"{x:1278,y:939,t:1527019522970};\\\", \\\"{x:1278,y:933,t:1527019522986};\\\", \\\"{x:1278,y:930,t:1527019523002};\\\", \\\"{x:1278,y:926,t:1527019523019};\\\", \\\"{x:1278,y:924,t:1527019523036};\\\", \\\"{x:1278,y:923,t:1527019523053};\\\", \\\"{x:1278,y:922,t:1527019523069};\\\", \\\"{x:1278,y:921,t:1527019523086};\\\", \\\"{x:1278,y:920,t:1527019523104};\\\", \\\"{x:1278,y:918,t:1527019523120};\\\", \\\"{x:1278,y:916,t:1527019523136};\\\", \\\"{x:1279,y:914,t:1527019523153};\\\", \\\"{x:1279,y:911,t:1527019523170};\\\", \\\"{x:1279,y:909,t:1527019523186};\\\", \\\"{x:1279,y:906,t:1527019523204};\\\", \\\"{x:1279,y:903,t:1527019523220};\\\", \\\"{x:1280,y:899,t:1527019523236};\\\", \\\"{x:1280,y:895,t:1527019523253};\\\", \\\"{x:1282,y:891,t:1527019523270};\\\", \\\"{x:1282,y:889,t:1527019523286};\\\", \\\"{x:1282,y:885,t:1527019523303};\\\", \\\"{x:1282,y:883,t:1527019523320};\\\", \\\"{x:1282,y:880,t:1527019523336};\\\", \\\"{x:1282,y:878,t:1527019523353};\\\", \\\"{x:1282,y:876,t:1527019523370};\\\", \\\"{x:1282,y:873,t:1527019523387};\\\", \\\"{x:1282,y:871,t:1527019523403};\\\", \\\"{x:1282,y:869,t:1527019523420};\\\", \\\"{x:1282,y:866,t:1527019523437};\\\", \\\"{x:1283,y:864,t:1527019523453};\\\", \\\"{x:1283,y:863,t:1527019523470};\\\", \\\"{x:1284,y:856,t:1527019523487};\\\", \\\"{x:1284,y:850,t:1527019523502};\\\", \\\"{x:1284,y:844,t:1527019523520};\\\", \\\"{x:1285,y:836,t:1527019523536};\\\", \\\"{x:1286,y:832,t:1527019523552};\\\", \\\"{x:1286,y:828,t:1527019523569};\\\", \\\"{x:1287,y:825,t:1527019523587};\\\", \\\"{x:1287,y:823,t:1527019523603};\\\", \\\"{x:1287,y:822,t:1527019523619};\\\", \\\"{x:1287,y:820,t:1527019523636};\\\", \\\"{x:1287,y:819,t:1527019523653};\\\", \\\"{x:1287,y:817,t:1527019523670};\\\", \\\"{x:1287,y:816,t:1527019523695};\\\", \\\"{x:1287,y:814,t:1527019523719};\\\", \\\"{x:1287,y:813,t:1527019523737};\\\", \\\"{x:1287,y:811,t:1527019523758};\\\", \\\"{x:1287,y:810,t:1527019523774};\\\", \\\"{x:1287,y:808,t:1527019523789};\\\", \\\"{x:1287,y:807,t:1527019523814};\\\", \\\"{x:1287,y:805,t:1527019523830};\\\", \\\"{x:1287,y:804,t:1527019523838};\\\", \\\"{x:1287,y:803,t:1527019523853};\\\", \\\"{x:1287,y:802,t:1527019523870};\\\", \\\"{x:1287,y:801,t:1527019523886};\\\", \\\"{x:1287,y:799,t:1527019523918};\\\", \\\"{x:1287,y:798,t:1527019523934};\\\", \\\"{x:1287,y:797,t:1527019523950};\\\", \\\"{x:1287,y:796,t:1527019523967};\\\", \\\"{x:1287,y:795,t:1527019523998};\\\", \\\"{x:1287,y:794,t:1527019524006};\\\", \\\"{x:1287,y:793,t:1527019524020};\\\", \\\"{x:1287,y:792,t:1527019524037};\\\", \\\"{x:1287,y:789,t:1527019524054};\\\", \\\"{x:1287,y:786,t:1527019524069};\\\", \\\"{x:1287,y:779,t:1527019524087};\\\", \\\"{x:1287,y:775,t:1527019524104};\\\", \\\"{x:1287,y:768,t:1527019524120};\\\", \\\"{x:1287,y:762,t:1527019524137};\\\", \\\"{x:1287,y:754,t:1527019524153};\\\", \\\"{x:1287,y:748,t:1527019524170};\\\", \\\"{x:1287,y:744,t:1527019524186};\\\", \\\"{x:1287,y:740,t:1527019524203};\\\", \\\"{x:1287,y:738,t:1527019524219};\\\", \\\"{x:1287,y:736,t:1527019524237};\\\", \\\"{x:1287,y:731,t:1527019524253};\\\", \\\"{x:1287,y:723,t:1527019524269};\\\", \\\"{x:1287,y:712,t:1527019524286};\\\", \\\"{x:1287,y:705,t:1527019524303};\\\", \\\"{x:1287,y:701,t:1527019524320};\\\", \\\"{x:1287,y:697,t:1527019524337};\\\", \\\"{x:1287,y:694,t:1527019524353};\\\", \\\"{x:1287,y:692,t:1527019524371};\\\", \\\"{x:1287,y:690,t:1527019524386};\\\", \\\"{x:1287,y:689,t:1527019524404};\\\", \\\"{x:1287,y:688,t:1527019524559};\\\", \\\"{x:1287,y:685,t:1527019524571};\\\", \\\"{x:1287,y:680,t:1527019524587};\\\", \\\"{x:1287,y:674,t:1527019524603};\\\", \\\"{x:1287,y:669,t:1527019524620};\\\", \\\"{x:1287,y:663,t:1527019524636};\\\", \\\"{x:1287,y:655,t:1527019524654};\\\", \\\"{x:1287,y:652,t:1527019524670};\\\", \\\"{x:1287,y:647,t:1527019524687};\\\", \\\"{x:1287,y:643,t:1527019524703};\\\", \\\"{x:1287,y:638,t:1527019524721};\\\", \\\"{x:1287,y:634,t:1527019524737};\\\", \\\"{x:1287,y:633,t:1527019524754};\\\", \\\"{x:1287,y:630,t:1527019524776};\\\", \\\"{x:1287,y:628,t:1527019524790};\\\", \\\"{x:1287,y:626,t:1527019524806};\\\", \\\"{x:1287,y:625,t:1527019524821};\\\", \\\"{x:1286,y:621,t:1527019524837};\\\", \\\"{x:1286,y:619,t:1527019524853};\\\", \\\"{x:1285,y:617,t:1527019524870};\\\", \\\"{x:1285,y:614,t:1527019524887};\\\", \\\"{x:1285,y:609,t:1527019524903};\\\", \\\"{x:1283,y:602,t:1527019524921};\\\", \\\"{x:1282,y:594,t:1527019524937};\\\", \\\"{x:1281,y:585,t:1527019524954};\\\", \\\"{x:1280,y:580,t:1527019524971};\\\", \\\"{x:1280,y:577,t:1527019524987};\\\", \\\"{x:1279,y:577,t:1527019525004};\\\", \\\"{x:1279,y:574,t:1527019525063};\\\", \\\"{x:1279,y:572,t:1527019525070};\\\", \\\"{x:1278,y:570,t:1527019525088};\\\", \\\"{x:1278,y:567,t:1527019525104};\\\", \\\"{x:1278,y:565,t:1527019525122};\\\", \\\"{x:1268,y:574,t:1527019532896};\\\", \\\"{x:1228,y:605,t:1527019532911};\\\", \\\"{x:1196,y:628,t:1527019532927};\\\", \\\"{x:1162,y:653,t:1527019532943};\\\", \\\"{x:1122,y:682,t:1527019532960};\\\", \\\"{x:1072,y:713,t:1527019532978};\\\", \\\"{x:1012,y:749,t:1527019532994};\\\", \\\"{x:955,y:781,t:1527019533010};\\\", \\\"{x:889,y:822,t:1527019533027};\\\", \\\"{x:814,y:872,t:1527019533043};\\\", \\\"{x:750,y:913,t:1527019533060};\\\", \\\"{x:703,y:934,t:1527019533077};\\\", \\\"{x:682,y:941,t:1527019533093};\\\", \\\"{x:656,y:943,t:1527019533110};\\\", \\\"{x:640,y:943,t:1527019533126};\\\", \\\"{x:622,y:943,t:1527019533144};\\\", \\\"{x:611,y:943,t:1527019533160};\\\", \\\"{x:604,y:943,t:1527019533177};\\\", \\\"{x:595,y:943,t:1527019533193};\\\", \\\"{x:586,y:939,t:1527019533210};\\\", \\\"{x:578,y:936,t:1527019533227};\\\", \\\"{x:573,y:931,t:1527019533244};\\\", \\\"{x:569,y:927,t:1527019533260};\\\", \\\"{x:569,y:926,t:1527019533277};\\\", \\\"{x:568,y:926,t:1527019533293};\\\", \\\"{x:567,y:925,t:1527019533310};\\\", \\\"{x:566,y:923,t:1527019533327};\\\", \\\"{x:565,y:921,t:1527019533343};\\\", \\\"{x:565,y:917,t:1527019533360};\\\", \\\"{x:565,y:914,t:1527019533377};\\\", \\\"{x:564,y:911,t:1527019533393};\\\", \\\"{x:564,y:909,t:1527019533410};\\\", \\\"{x:564,y:908,t:1527019533427};\\\", \\\"{x:564,y:906,t:1527019533444};\\\", \\\"{x:564,y:905,t:1527019533460};\\\", \\\"{x:564,y:903,t:1527019533477};\\\", \\\"{x:564,y:902,t:1527019533502};\\\", \\\"{x:564,y:901,t:1527019533510};\\\", \\\"{x:564,y:900,t:1527019533527};\\\", \\\"{x:564,y:898,t:1527019533544};\\\", \\\"{x:564,y:897,t:1527019533663};\\\", \\\"{x:568,y:894,t:1527019554791};\\\", \\\"{x:586,y:890,t:1527019554799};\\\", \\\"{x:618,y:884,t:1527019554809};\\\", \\\"{x:707,y:870,t:1527019554827};\\\", \\\"{x:826,y:854,t:1527019554843};\\\", \\\"{x:951,y:837,t:1527019554860};\\\", \\\"{x:1089,y:820,t:1527019554877};\\\", \\\"{x:1213,y:810,t:1527019554894};\\\", \\\"{x:1377,y:790,t:1527019554911};\\\", \\\"{x:1458,y:777,t:1527019554926};\\\", \\\"{x:1506,y:762,t:1527019554943};\\\", \\\"{x:1526,y:753,t:1527019554960};\\\", \\\"{x:1534,y:749,t:1527019554976};\\\", \\\"{x:1539,y:745,t:1527019554994};\\\", \\\"{x:1540,y:743,t:1527019555010};\\\", \\\"{x:1544,y:737,t:1527019555026};\\\", \\\"{x:1549,y:729,t:1527019555044};\\\", \\\"{x:1552,y:723,t:1527019555061};\\\", \\\"{x:1552,y:716,t:1527019555076};\\\", \\\"{x:1547,y:710,t:1527019555094};\\\", \\\"{x:1514,y:693,t:1527019555110};\\\", \\\"{x:1489,y:682,t:1527019555126};\\\", \\\"{x:1456,y:675,t:1527019555143};\\\", \\\"{x:1426,y:669,t:1527019555160};\\\", \\\"{x:1411,y:664,t:1527019555176};\\\", \\\"{x:1404,y:664,t:1527019555193};\\\", \\\"{x:1403,y:664,t:1527019555210};\\\", \\\"{x:1401,y:664,t:1527019555230};\\\", \\\"{x:1397,y:664,t:1527019555247};\\\", \\\"{x:1387,y:664,t:1527019555261};\\\", \\\"{x:1364,y:666,t:1527019555276};\\\", \\\"{x:1345,y:668,t:1527019555292};\\\", \\\"{x:1334,y:668,t:1527019555309};\\\", \\\"{x:1328,y:668,t:1527019555326};\\\", \\\"{x:1317,y:665,t:1527019555343};\\\", \\\"{x:1309,y:661,t:1527019555360};\\\", \\\"{x:1307,y:661,t:1527019555377};\\\", \\\"{x:1304,y:659,t:1527019555393};\\\", \\\"{x:1299,y:657,t:1527019555410};\\\", \\\"{x:1294,y:655,t:1527019555427};\\\", \\\"{x:1292,y:654,t:1527019555527};\\\", \\\"{x:1287,y:652,t:1527019555543};\\\", \\\"{x:1281,y:649,t:1527019555559};\\\", \\\"{x:1277,y:647,t:1527019555577};\\\", \\\"{x:1270,y:644,t:1527019555593};\\\", \\\"{x:1264,y:640,t:1527019555610};\\\", \\\"{x:1263,y:640,t:1527019555662};\\\", \\\"{x:1262,y:640,t:1527019555685};\\\", \\\"{x:1261,y:640,t:1527019555702};\\\", \\\"{x:1259,y:640,t:1527019555767};\\\", \\\"{x:1256,y:638,t:1527019555783};\\\", \\\"{x:1249,y:637,t:1527019555793};\\\", \\\"{x:1234,y:636,t:1527019555811};\\\", \\\"{x:1218,y:633,t:1527019555827};\\\", \\\"{x:1215,y:633,t:1527019555843};\\\", \\\"{x:1213,y:633,t:1527019555869};\\\", \\\"{x:1212,y:633,t:1527019555893};\\\", \\\"{x:1210,y:632,t:1527019555910};\\\", \\\"{x:1211,y:632,t:1527019556031};\\\", \\\"{x:1213,y:632,t:1527019556044};\\\", \\\"{x:1217,y:632,t:1527019556060};\\\", \\\"{x:1223,y:631,t:1527019556078};\\\", \\\"{x:1227,y:630,t:1527019556095};\\\", \\\"{x:1228,y:630,t:1527019556111};\\\", \\\"{x:1231,y:628,t:1527019556175};\\\", \\\"{x:1234,y:627,t:1527019556182};\\\", \\\"{x:1235,y:626,t:1527019556194};\\\", \\\"{x:1238,y:625,t:1527019556210};\\\", \\\"{x:1239,y:625,t:1527019556228};\\\", \\\"{x:1241,y:624,t:1527019556302};\\\", \\\"{x:1245,y:623,t:1527019556319};\\\", \\\"{x:1246,y:622,t:1527019556333};\\\", \\\"{x:1247,y:622,t:1527019556350};\\\", \\\"{x:1248,y:622,t:1527019556558};\\\", \\\"{x:1248,y:625,t:1527019556569};\\\", \\\"{x:1248,y:629,t:1527019556577};\\\", \\\"{x:1247,y:637,t:1527019556594};\\\", \\\"{x:1247,y:641,t:1527019556610};\\\", \\\"{x:1246,y:646,t:1527019556626};\\\", \\\"{x:1244,y:653,t:1527019556644};\\\", \\\"{x:1243,y:662,t:1527019556661};\\\", \\\"{x:1243,y:669,t:1527019556677};\\\", \\\"{x:1243,y:677,t:1527019556694};\\\", \\\"{x:1243,y:681,t:1527019556711};\\\", \\\"{x:1242,y:684,t:1527019556727};\\\", \\\"{x:1242,y:689,t:1527019556743};\\\", \\\"{x:1240,y:693,t:1527019556761};\\\", \\\"{x:1240,y:697,t:1527019556777};\\\", \\\"{x:1240,y:700,t:1527019556794};\\\", \\\"{x:1240,y:702,t:1527019556811};\\\", \\\"{x:1239,y:705,t:1527019556827};\\\", \\\"{x:1238,y:710,t:1527019556845};\\\", \\\"{x:1238,y:717,t:1527019556862};\\\", \\\"{x:1237,y:727,t:1527019556878};\\\", \\\"{x:1236,y:730,t:1527019556894};\\\", \\\"{x:1236,y:736,t:1527019556912};\\\", \\\"{x:1236,y:739,t:1527019556928};\\\", \\\"{x:1236,y:744,t:1527019556945};\\\", \\\"{x:1236,y:748,t:1527019556961};\\\", \\\"{x:1236,y:751,t:1527019556978};\\\", \\\"{x:1236,y:754,t:1527019556994};\\\", \\\"{x:1235,y:758,t:1527019557011};\\\", \\\"{x:1235,y:761,t:1527019557028};\\\", \\\"{x:1235,y:766,t:1527019557045};\\\", \\\"{x:1235,y:768,t:1527019557062};\\\", \\\"{x:1235,y:771,t:1527019557078};\\\", \\\"{x:1235,y:772,t:1527019557094};\\\", \\\"{x:1235,y:774,t:1527019557111};\\\", \\\"{x:1235,y:778,t:1527019557128};\\\", \\\"{x:1235,y:780,t:1527019557144};\\\", \\\"{x:1235,y:782,t:1527019557161};\\\", \\\"{x:1235,y:784,t:1527019557178};\\\", \\\"{x:1235,y:785,t:1527019557199};\\\", \\\"{x:1235,y:787,t:1527019557215};\\\", \\\"{x:1235,y:788,t:1527019557228};\\\", \\\"{x:1235,y:791,t:1527019557246};\\\", \\\"{x:1235,y:794,t:1527019557262};\\\", \\\"{x:1235,y:796,t:1527019557278};\\\", \\\"{x:1235,y:798,t:1527019557295};\\\", \\\"{x:1235,y:800,t:1527019557312};\\\", \\\"{x:1235,y:803,t:1527019557328};\\\", \\\"{x:1235,y:804,t:1527019557345};\\\", \\\"{x:1235,y:806,t:1527019557361};\\\", \\\"{x:1235,y:808,t:1527019557378};\\\", \\\"{x:1235,y:813,t:1527019557395};\\\", \\\"{x:1235,y:816,t:1527019557412};\\\", \\\"{x:1235,y:821,t:1527019557428};\\\", \\\"{x:1235,y:825,t:1527019557445};\\\", \\\"{x:1235,y:827,t:1527019557461};\\\", \\\"{x:1235,y:831,t:1527019557478};\\\", \\\"{x:1235,y:835,t:1527019557496};\\\", \\\"{x:1235,y:842,t:1527019557511};\\\", \\\"{x:1235,y:849,t:1527019557529};\\\", \\\"{x:1235,y:854,t:1527019557545};\\\", \\\"{x:1235,y:859,t:1527019557562};\\\", \\\"{x:1235,y:864,t:1527019557579};\\\", \\\"{x:1235,y:867,t:1527019557595};\\\", \\\"{x:1235,y:873,t:1527019557611};\\\", \\\"{x:1235,y:882,t:1527019557628};\\\", \\\"{x:1235,y:893,t:1527019557646};\\\", \\\"{x:1235,y:901,t:1527019557661};\\\", \\\"{x:1234,y:911,t:1527019557678};\\\", \\\"{x:1233,y:922,t:1527019557696};\\\", \\\"{x:1233,y:930,t:1527019557711};\\\", \\\"{x:1233,y:937,t:1527019557728};\\\", \\\"{x:1233,y:940,t:1527019557745};\\\", \\\"{x:1233,y:943,t:1527019557762};\\\", \\\"{x:1233,y:944,t:1527019557778};\\\", \\\"{x:1233,y:946,t:1527019557798};\\\", \\\"{x:1233,y:947,t:1527019557812};\\\", \\\"{x:1233,y:949,t:1527019557829};\\\", \\\"{x:1233,y:953,t:1527019557846};\\\", \\\"{x:1233,y:957,t:1527019557862};\\\", \\\"{x:1233,y:960,t:1527019557878};\\\", \\\"{x:1233,y:963,t:1527019557896};\\\", \\\"{x:1233,y:970,t:1527019557913};\\\", \\\"{x:1233,y:981,t:1527019557928};\\\", \\\"{x:1233,y:989,t:1527019557946};\\\", \\\"{x:1233,y:995,t:1527019557962};\\\", \\\"{x:1233,y:999,t:1527019557978};\\\", \\\"{x:1235,y:1004,t:1527019557995};\\\", \\\"{x:1237,y:1008,t:1527019558013};\\\", \\\"{x:1238,y:1008,t:1527019558028};\\\", \\\"{x:1239,y:1008,t:1527019558135};\\\", \\\"{x:1240,y:1003,t:1527019558146};\\\", \\\"{x:1243,y:993,t:1527019558162};\\\", \\\"{x:1246,y:978,t:1527019558179};\\\", \\\"{x:1250,y:963,t:1527019558196};\\\", \\\"{x:1254,y:949,t:1527019558213};\\\", \\\"{x:1255,y:938,t:1527019558229};\\\", \\\"{x:1258,y:928,t:1527019558245};\\\", \\\"{x:1259,y:923,t:1527019558262};\\\", \\\"{x:1259,y:921,t:1527019558487};\\\", \\\"{x:1259,y:914,t:1527019558496};\\\", \\\"{x:1265,y:895,t:1527019558513};\\\", \\\"{x:1272,y:866,t:1527019558529};\\\", \\\"{x:1282,y:827,t:1527019558546};\\\", \\\"{x:1290,y:784,t:1527019558563};\\\", \\\"{x:1295,y:755,t:1527019558579};\\\", \\\"{x:1298,y:733,t:1527019558596};\\\", \\\"{x:1302,y:712,t:1527019558613};\\\", \\\"{x:1303,y:697,t:1527019558629};\\\", \\\"{x:1303,y:687,t:1527019558645};\\\", \\\"{x:1303,y:682,t:1527019558662};\\\", \\\"{x:1303,y:681,t:1527019558694};\\\", \\\"{x:1303,y:680,t:1527019558718};\\\", \\\"{x:1303,y:678,t:1527019558729};\\\", \\\"{x:1297,y:670,t:1527019558745};\\\", \\\"{x:1292,y:664,t:1527019558763};\\\", \\\"{x:1286,y:657,t:1527019558780};\\\", \\\"{x:1281,y:653,t:1527019558796};\\\", \\\"{x:1277,y:649,t:1527019558813};\\\", \\\"{x:1273,y:645,t:1527019558829};\\\", \\\"{x:1271,y:642,t:1527019558847};\\\", \\\"{x:1268,y:637,t:1527019558862};\\\", \\\"{x:1264,y:634,t:1527019558880};\\\", \\\"{x:1261,y:631,t:1527019558897};\\\", \\\"{x:1260,y:631,t:1527019558913};\\\", \\\"{x:1258,y:631,t:1527019559007};\\\", \\\"{x:1257,y:631,t:1527019559014};\\\", \\\"{x:1255,y:631,t:1527019559029};\\\", \\\"{x:1252,y:631,t:1527019559047};\\\", \\\"{x:1251,y:631,t:1527019559062};\\\", \\\"{x:1250,y:631,t:1527019559119};\\\", \\\"{x:1250,y:632,t:1527019559271};\\\", \\\"{x:1249,y:632,t:1527019559279};\\\", \\\"{x:1246,y:635,t:1527019559296};\\\", \\\"{x:1246,y:641,t:1527019560615};\\\", \\\"{x:1246,y:656,t:1527019560631};\\\", \\\"{x:1250,y:669,t:1527019560648};\\\", \\\"{x:1254,y:684,t:1527019560664};\\\", \\\"{x:1255,y:694,t:1527019560681};\\\", \\\"{x:1256,y:701,t:1527019560698};\\\", \\\"{x:1257,y:706,t:1527019560715};\\\", \\\"{x:1258,y:709,t:1527019560730};\\\", \\\"{x:1259,y:713,t:1527019560747};\\\", \\\"{x:1260,y:716,t:1527019560765};\\\", \\\"{x:1261,y:720,t:1527019560781};\\\", \\\"{x:1261,y:722,t:1527019560798};\\\", \\\"{x:1262,y:727,t:1527019560814};\\\", \\\"{x:1262,y:730,t:1527019560830};\\\", \\\"{x:1262,y:736,t:1527019560848};\\\", \\\"{x:1262,y:742,t:1527019560865};\\\", \\\"{x:1262,y:750,t:1527019560880};\\\", \\\"{x:1262,y:758,t:1527019560898};\\\", \\\"{x:1262,y:765,t:1527019560915};\\\", \\\"{x:1262,y:770,t:1527019560931};\\\", \\\"{x:1262,y:775,t:1527019560947};\\\", \\\"{x:1262,y:780,t:1527019560964};\\\", \\\"{x:1262,y:789,t:1527019560981};\\\", \\\"{x:1262,y:797,t:1527019560998};\\\", \\\"{x:1262,y:810,t:1527019561014};\\\", \\\"{x:1262,y:816,t:1527019561030};\\\", \\\"{x:1262,y:821,t:1527019561047};\\\", \\\"{x:1262,y:825,t:1527019561065};\\\", \\\"{x:1262,y:828,t:1527019561080};\\\", \\\"{x:1262,y:832,t:1527019561097};\\\", \\\"{x:1262,y:834,t:1527019561114};\\\", \\\"{x:1262,y:837,t:1527019561131};\\\", \\\"{x:1262,y:840,t:1527019561147};\\\", \\\"{x:1262,y:844,t:1527019561164};\\\", \\\"{x:1262,y:849,t:1527019561181};\\\", \\\"{x:1262,y:855,t:1527019561196};\\\", \\\"{x:1262,y:865,t:1527019561214};\\\", \\\"{x:1262,y:870,t:1527019561231};\\\", \\\"{x:1262,y:876,t:1527019561247};\\\", \\\"{x:1262,y:884,t:1527019561264};\\\", \\\"{x:1262,y:899,t:1527019561281};\\\", \\\"{x:1262,y:916,t:1527019561297};\\\", \\\"{x:1262,y:930,t:1527019561314};\\\", \\\"{x:1263,y:938,t:1527019561331};\\\", \\\"{x:1264,y:946,t:1527019561347};\\\", \\\"{x:1266,y:950,t:1527019561364};\\\", \\\"{x:1266,y:955,t:1527019561382};\\\", \\\"{x:1266,y:961,t:1527019561398};\\\", \\\"{x:1265,y:970,t:1527019561414};\\\", \\\"{x:1264,y:974,t:1527019561432};\\\", \\\"{x:1264,y:978,t:1527019561448};\\\", \\\"{x:1263,y:979,t:1527019561464};\\\", \\\"{x:1263,y:980,t:1527019561482};\\\", \\\"{x:1263,y:982,t:1527019561497};\\\", \\\"{x:1262,y:983,t:1527019561514};\\\", \\\"{x:1262,y:985,t:1527019561531};\\\", \\\"{x:1261,y:986,t:1527019561548};\\\", \\\"{x:1259,y:989,t:1527019561564};\\\", \\\"{x:1258,y:990,t:1527019561589};\\\", \\\"{x:1257,y:990,t:1527019561622};\\\", \\\"{x:1256,y:990,t:1527019561630};\\\", \\\"{x:1254,y:992,t:1527019561647};\\\", \\\"{x:1253,y:993,t:1527019561664};\\\", \\\"{x:1252,y:995,t:1527019561682};\\\", \\\"{x:1253,y:995,t:1527019561799};\\\", \\\"{x:1256,y:992,t:1527019561814};\\\", \\\"{x:1262,y:985,t:1527019561831};\\\", \\\"{x:1267,y:976,t:1527019561848};\\\", \\\"{x:1275,y:969,t:1527019561864};\\\", \\\"{x:1282,y:965,t:1527019561881};\\\", \\\"{x:1289,y:960,t:1527019561898};\\\", \\\"{x:1293,y:957,t:1527019561914};\\\", \\\"{x:1294,y:955,t:1527019561931};\\\", \\\"{x:1295,y:954,t:1527019561948};\\\", \\\"{x:1294,y:955,t:1527019562198};\\\", \\\"{x:1293,y:956,t:1527019562215};\\\", \\\"{x:1293,y:957,t:1527019562238};\\\", \\\"{x:1292,y:958,t:1527019562254};\\\", \\\"{x:1290,y:960,t:1527019562266};\\\", \\\"{x:1283,y:970,t:1527019562281};\\\", \\\"{x:1278,y:978,t:1527019562298};\\\", \\\"{x:1275,y:981,t:1527019562315};\\\", \\\"{x:1275,y:982,t:1527019562345};\\\", \\\"{x:1275,y:981,t:1527019562493};\\\", \\\"{x:1275,y:976,t:1527019562502};\\\", \\\"{x:1275,y:973,t:1527019562515};\\\", \\\"{x:1276,y:965,t:1527019562532};\\\", \\\"{x:1276,y:960,t:1527019562549};\\\", \\\"{x:1276,y:957,t:1527019562565};\\\", \\\"{x:1277,y:956,t:1527019562790};\\\", \\\"{x:1277,y:954,t:1527019562798};\\\", \\\"{x:1277,y:950,t:1527019562815};\\\", \\\"{x:1278,y:946,t:1527019562832};\\\", \\\"{x:1279,y:943,t:1527019562848};\\\", \\\"{x:1279,y:939,t:1527019562865};\\\", \\\"{x:1280,y:935,t:1527019562883};\\\", \\\"{x:1280,y:933,t:1527019562899};\\\", \\\"{x:1280,y:931,t:1527019562915};\\\", \\\"{x:1281,y:929,t:1527019562933};\\\", \\\"{x:1281,y:926,t:1527019562948};\\\", \\\"{x:1281,y:925,t:1527019562965};\\\", \\\"{x:1283,y:920,t:1527019562982};\\\", \\\"{x:1283,y:917,t:1527019562999};\\\", \\\"{x:1284,y:912,t:1527019563015};\\\", \\\"{x:1284,y:910,t:1527019563032};\\\", \\\"{x:1284,y:908,t:1527019563048};\\\", \\\"{x:1284,y:906,t:1527019563065};\\\", \\\"{x:1284,y:903,t:1527019563082};\\\", \\\"{x:1284,y:900,t:1527019563098};\\\", \\\"{x:1285,y:895,t:1527019563115};\\\", \\\"{x:1285,y:892,t:1527019563132};\\\", \\\"{x:1285,y:884,t:1527019563149};\\\", \\\"{x:1285,y:881,t:1527019563165};\\\", \\\"{x:1285,y:877,t:1527019563182};\\\", \\\"{x:1285,y:873,t:1527019563199};\\\", \\\"{x:1285,y:870,t:1527019563215};\\\", \\\"{x:1285,y:864,t:1527019563233};\\\", \\\"{x:1285,y:863,t:1527019563249};\\\", \\\"{x:1285,y:859,t:1527019563265};\\\", \\\"{x:1285,y:856,t:1527019563282};\\\", \\\"{x:1285,y:851,t:1527019563299};\\\", \\\"{x:1285,y:845,t:1527019563315};\\\", \\\"{x:1285,y:839,t:1527019563332};\\\", \\\"{x:1285,y:831,t:1527019563349};\\\", \\\"{x:1285,y:828,t:1527019563366};\\\", \\\"{x:1285,y:824,t:1527019563382};\\\", \\\"{x:1285,y:821,t:1527019563400};\\\", \\\"{x:1285,y:820,t:1527019563416};\\\", \\\"{x:1285,y:817,t:1527019563432};\\\", \\\"{x:1285,y:816,t:1527019563449};\\\", \\\"{x:1285,y:815,t:1527019563466};\\\", \\\"{x:1285,y:814,t:1527019563486};\\\", \\\"{x:1285,y:813,t:1527019563500};\\\", \\\"{x:1285,y:812,t:1527019563516};\\\", \\\"{x:1285,y:810,t:1527019563533};\\\", \\\"{x:1285,y:809,t:1527019563550};\\\", \\\"{x:1285,y:808,t:1527019563566};\\\", \\\"{x:1285,y:805,t:1527019563583};\\\", \\\"{x:1285,y:804,t:1527019563599};\\\", \\\"{x:1285,y:801,t:1527019563617};\\\", \\\"{x:1284,y:798,t:1527019563632};\\\", \\\"{x:1283,y:795,t:1527019563649};\\\", \\\"{x:1282,y:790,t:1527019563667};\\\", \\\"{x:1279,y:785,t:1527019563683};\\\", \\\"{x:1278,y:778,t:1527019563699};\\\", \\\"{x:1275,y:769,t:1527019563717};\\\", \\\"{x:1274,y:764,t:1527019563733};\\\", \\\"{x:1271,y:758,t:1527019563749};\\\", \\\"{x:1271,y:753,t:1527019563766};\\\", \\\"{x:1270,y:746,t:1527019563782};\\\", \\\"{x:1269,y:738,t:1527019563800};\\\", \\\"{x:1267,y:729,t:1527019563816};\\\", \\\"{x:1267,y:721,t:1527019563833};\\\", \\\"{x:1267,y:714,t:1527019563849};\\\", \\\"{x:1267,y:710,t:1527019563867};\\\", \\\"{x:1267,y:704,t:1527019563882};\\\", \\\"{x:1267,y:697,t:1527019563899};\\\", \\\"{x:1267,y:689,t:1527019563916};\\\", \\\"{x:1267,y:682,t:1527019563932};\\\", \\\"{x:1267,y:672,t:1527019563949};\\\", \\\"{x:1267,y:665,t:1527019563966};\\\", \\\"{x:1267,y:658,t:1527019563983};\\\", \\\"{x:1267,y:651,t:1527019563999};\\\", \\\"{x:1267,y:644,t:1527019564015};\\\", \\\"{x:1266,y:640,t:1527019564033};\\\", \\\"{x:1266,y:638,t:1527019564049};\\\", \\\"{x:1265,y:638,t:1527019564070};\\\", \\\"{x:1258,y:638,t:1527019564083};\\\", \\\"{x:1224,y:639,t:1527019564099};\\\", \\\"{x:1168,y:658,t:1527019564116};\\\", \\\"{x:1060,y:696,t:1527019564134};\\\", \\\"{x:952,y:714,t:1527019564149};\\\", \\\"{x:825,y:730,t:1527019564167};\\\", \\\"{x:705,y:747,t:1527019564183};\\\", \\\"{x:628,y:758,t:1527019564200};\\\", \\\"{x:593,y:768,t:1527019564216};\\\", \\\"{x:588,y:769,t:1527019564233};\\\", \\\"{x:586,y:769,t:1527019564374};\\\", \\\"{x:578,y:755,t:1527019564384};\\\", \\\"{x:548,y:713,t:1527019564401};\\\", \\\"{x:519,y:684,t:1527019564417};\\\", \\\"{x:507,y:677,t:1527019564432};\\\", \\\"{x:503,y:675,t:1527019564452};\\\", \\\"{x:502,y:675,t:1527019564468};\\\", \\\"{x:501,y:675,t:1527019564549};\\\", \\\"{x:501,y:677,t:1527019564574};\\\", \\\"{x:501,y:678,t:1527019564585};\\\", \\\"{x:500,y:680,t:1527019564602};\\\", \\\"{x:500,y:681,t:1527019564618};\\\", \\\"{x:499,y:687,t:1527019564635};\\\", \\\"{x:496,y:695,t:1527019564652};\\\", \\\"{x:495,y:699,t:1527019564669};\\\", \\\"{x:495,y:701,t:1527019564686};\\\", \\\"{x:494,y:702,t:1527019564702};\\\", \\\"{x:494,y:703,t:1527019564721};\\\", \\\"{x:494,y:706,t:1527019564736};\\\" ] }, { \\\"rt\\\": 108440, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 6, \\\"time_elapsed\\\": 282094, \\\"internal_node_id\\\": \\\"0.0-5.0-1.0\\\", \\\"subject\\\": \\\"VT5BG\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"golf\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 2, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"K\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-D -D -D -D -G -04 PM-04 PM-G -04 PM-04 PM-08 AM-08 AM-08 AM-09 AM-11 AM-O -11 AM-10 AM-O -08 AM-08 AM-O -K -J -K -K -F -12 PM-11 AM\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:494,y:707,t:1527019566829};\\\", \\\"{x:504,y:688,t:1527019568543};\\\", \\\"{x:544,y:635,t:1527019568554};\\\", \\\"{x:648,y:536,t:1527019568573};\\\", \\\"{x:722,y:446,t:1527019568589};\\\", \\\"{x:779,y:352,t:1527019568606};\\\", \\\"{x:818,y:254,t:1527019568623};\\\", \\\"{x:863,y:167,t:1527019568639};\\\", \\\"{x:949,y:61,t:1527019568656};\\\", \\\"{x:1003,y:0,t:1527019568674};\\\", \\\"{x:1068,y:0,t:1527019568689};\\\", \\\"{x:1069,y:2,t:1527019569110};\\\", \\\"{x:1069,y:6,t:1527019569123};\\\", \\\"{x:1069,y:9,t:1527019569140};\\\", \\\"{x:1066,y:14,t:1527019569156};\\\", \\\"{x:1058,y:25,t:1527019569172};\\\", \\\"{x:1051,y:42,t:1527019569188};\\\", \\\"{x:1038,y:65,t:1527019569206};\\\", \\\"{x:1028,y:75,t:1527019569222};\\\", \\\"{x:1021,y:81,t:1527019569238};\\\", \\\"{x:1015,y:90,t:1527019569255};\\\", \\\"{x:1012,y:96,t:1527019569272};\\\", \\\"{x:1010,y:102,t:1527019569288};\\\", \\\"{x:1006,y:114,t:1527019569305};\\\", \\\"{x:996,y:136,t:1527019569323};\\\", \\\"{x:984,y:165,t:1527019569338};\\\", \\\"{x:963,y:217,t:1527019569356};\\\", \\\"{x:936,y:273,t:1527019569372};\\\", \\\"{x:906,y:332,t:1527019569388};\\\", \\\"{x:864,y:416,t:1527019569405};\\\", \\\"{x:849,y:459,t:1527019569422};\\\", \\\"{x:842,y:484,t:1527019569438};\\\", \\\"{x:835,y:505,t:1527019569455};\\\", \\\"{x:830,y:520,t:1527019569471};\\\", \\\"{x:826,y:530,t:1527019569488};\\\", \\\"{x:824,y:532,t:1527019569507};\\\", \\\"{x:824,y:533,t:1527019569524};\\\", \\\"{x:824,y:534,t:1527019569806};\\\", \\\"{x:824,y:535,t:1527019569813};\\\", \\\"{x:824,y:536,t:1527019569853};\\\", \\\"{x:824,y:537,t:1527019569959};\\\", \\\"{x:826,y:538,t:1527019569973};\\\", \\\"{x:829,y:540,t:1527019569990};\\\", \\\"{x:833,y:541,t:1527019570008};\\\", \\\"{x:838,y:544,t:1527019570027};\\\", \\\"{x:842,y:545,t:1527019570040};\\\", \\\"{x:848,y:547,t:1527019570058};\\\", \\\"{x:856,y:548,t:1527019570074};\\\", \\\"{x:869,y:552,t:1527019570090};\\\", \\\"{x:888,y:553,t:1527019570107};\\\", \\\"{x:919,y:557,t:1527019570124};\\\", \\\"{x:955,y:563,t:1527019570141};\\\", \\\"{x:970,y:565,t:1527019570156};\\\", \\\"{x:983,y:566,t:1527019570174};\\\", \\\"{x:987,y:567,t:1527019570191};\\\", \\\"{x:991,y:569,t:1527019570207};\\\", \\\"{x:993,y:569,t:1527019570224};\\\", \\\"{x:998,y:572,t:1527019570242};\\\", \\\"{x:1014,y:579,t:1527019570257};\\\", \\\"{x:1031,y:589,t:1527019570274};\\\", \\\"{x:1047,y:598,t:1527019570291};\\\", \\\"{x:1059,y:604,t:1527019570307};\\\", \\\"{x:1071,y:611,t:1527019570325};\\\", \\\"{x:1092,y:627,t:1527019570341};\\\", \\\"{x:1106,y:635,t:1527019570357};\\\", \\\"{x:1114,y:640,t:1527019570375};\\\", \\\"{x:1122,y:645,t:1527019570392};\\\", \\\"{x:1127,y:648,t:1527019570408};\\\", \\\"{x:1134,y:653,t:1527019570424};\\\", \\\"{x:1150,y:662,t:1527019570441};\\\", \\\"{x:1168,y:669,t:1527019570458};\\\", \\\"{x:1189,y:675,t:1527019570474};\\\", \\\"{x:1208,y:683,t:1527019570492};\\\", \\\"{x:1231,y:697,t:1527019570508};\\\", \\\"{x:1262,y:715,t:1527019570524};\\\", \\\"{x:1306,y:742,t:1527019570541};\\\", \\\"{x:1323,y:753,t:1527019570558};\\\", \\\"{x:1330,y:759,t:1527019570574};\\\", \\\"{x:1332,y:761,t:1527019570591};\\\", \\\"{x:1333,y:767,t:1527019570609};\\\", \\\"{x:1335,y:776,t:1527019570624};\\\", \\\"{x:1336,y:786,t:1527019570642};\\\", \\\"{x:1337,y:795,t:1527019570659};\\\", \\\"{x:1337,y:802,t:1527019570675};\\\", \\\"{x:1337,y:811,t:1527019570691};\\\", \\\"{x:1337,y:819,t:1527019570709};\\\", \\\"{x:1337,y:825,t:1527019570725};\\\", \\\"{x:1335,y:832,t:1527019570742};\\\", \\\"{x:1332,y:835,t:1527019570758};\\\", \\\"{x:1328,y:840,t:1527019570776};\\\", \\\"{x:1324,y:847,t:1527019570791};\\\", \\\"{x:1320,y:853,t:1527019570808};\\\", \\\"{x:1316,y:858,t:1527019570825};\\\", \\\"{x:1312,y:861,t:1527019570842};\\\", \\\"{x:1309,y:861,t:1527019570858};\\\", \\\"{x:1306,y:862,t:1527019570875};\\\", \\\"{x:1301,y:864,t:1527019570892};\\\", \\\"{x:1298,y:865,t:1527019570908};\\\", \\\"{x:1292,y:870,t:1527019570926};\\\", \\\"{x:1290,y:871,t:1527019570941};\\\", \\\"{x:1289,y:872,t:1527019570959};\\\", \\\"{x:1288,y:872,t:1527019570990};\\\", \\\"{x:1291,y:872,t:1527019571157};\\\", \\\"{x:1292,y:870,t:1527019571165};\\\", \\\"{x:1295,y:867,t:1527019571175};\\\", \\\"{x:1302,y:858,t:1527019571192};\\\", \\\"{x:1308,y:853,t:1527019571208};\\\", \\\"{x:1317,y:844,t:1527019571225};\\\", \\\"{x:1323,y:838,t:1527019571242};\\\", \\\"{x:1326,y:833,t:1527019571258};\\\", \\\"{x:1327,y:831,t:1527019571275};\\\", \\\"{x:1329,y:827,t:1527019571292};\\\", \\\"{x:1330,y:825,t:1527019571309};\\\", \\\"{x:1335,y:819,t:1527019571325};\\\", \\\"{x:1337,y:815,t:1527019571342};\\\", \\\"{x:1341,y:811,t:1527019571359};\\\", \\\"{x:1345,y:806,t:1527019571375};\\\", \\\"{x:1348,y:800,t:1527019571393};\\\", \\\"{x:1354,y:794,t:1527019571408};\\\", \\\"{x:1357,y:792,t:1527019571426};\\\", \\\"{x:1358,y:791,t:1527019571443};\\\", \\\"{x:1358,y:789,t:1527019571458};\\\", \\\"{x:1359,y:788,t:1527019571478};\\\", \\\"{x:1366,y:777,t:1527019572054};\\\", \\\"{x:1373,y:764,t:1527019572060};\\\", \\\"{x:1385,y:749,t:1527019572074};\\\", \\\"{x:1400,y:721,t:1527019572091};\\\", \\\"{x:1422,y:691,t:1527019572107};\\\", \\\"{x:1435,y:677,t:1527019572125};\\\", \\\"{x:1440,y:670,t:1527019572141};\\\", \\\"{x:1447,y:661,t:1527019572158};\\\", \\\"{x:1458,y:646,t:1527019572174};\\\", \\\"{x:1466,y:635,t:1527019572191};\\\", \\\"{x:1469,y:628,t:1527019572207};\\\", \\\"{x:1471,y:623,t:1527019572224};\\\", \\\"{x:1473,y:621,t:1527019572242};\\\", \\\"{x:1473,y:620,t:1527019572316};\\\", \\\"{x:1474,y:619,t:1527019572325};\\\", \\\"{x:1478,y:613,t:1527019572342};\\\", \\\"{x:1486,y:604,t:1527019572358};\\\", \\\"{x:1491,y:595,t:1527019572375};\\\", \\\"{x:1496,y:588,t:1527019572392};\\\", \\\"{x:1503,y:577,t:1527019572408};\\\", \\\"{x:1510,y:567,t:1527019572425};\\\", \\\"{x:1517,y:559,t:1527019572442};\\\", \\\"{x:1525,y:547,t:1527019572458};\\\", \\\"{x:1531,y:535,t:1527019572475};\\\", \\\"{x:1540,y:518,t:1527019572491};\\\", \\\"{x:1547,y:508,t:1527019572507};\\\", \\\"{x:1551,y:501,t:1527019572524};\\\", \\\"{x:1556,y:494,t:1527019572542};\\\", \\\"{x:1561,y:487,t:1527019572558};\\\", \\\"{x:1563,y:479,t:1527019572575};\\\", \\\"{x:1569,y:471,t:1527019572592};\\\", \\\"{x:1576,y:462,t:1527019572609};\\\", \\\"{x:1583,y:454,t:1527019572625};\\\", \\\"{x:1587,y:449,t:1527019572642};\\\", \\\"{x:1590,y:445,t:1527019572659};\\\", \\\"{x:1594,y:440,t:1527019572675};\\\", \\\"{x:1597,y:435,t:1527019572692};\\\", \\\"{x:1601,y:428,t:1527019572708};\\\", \\\"{x:1606,y:422,t:1527019572725};\\\", \\\"{x:1610,y:415,t:1527019572742};\\\", \\\"{x:1611,y:414,t:1527019572759};\\\", \\\"{x:1611,y:415,t:1527019572940};\\\", \\\"{x:1611,y:418,t:1527019572948};\\\", \\\"{x:1610,y:422,t:1527019572963};\\\", \\\"{x:1609,y:424,t:1527019572976};\\\", \\\"{x:1609,y:425,t:1527019573653};\\\", \\\"{x:1608,y:426,t:1527019576932};\\\", \\\"{x:1608,y:427,t:1527019576964};\\\", \\\"{x:1607,y:427,t:1527019576987};\\\", \\\"{x:1607,y:428,t:1527019577076};\\\", \\\"{x:1606,y:429,t:1527019577100};\\\", \\\"{x:1605,y:429,t:1527019577132};\\\", \\\"{x:1604,y:429,t:1527019577145};\\\", \\\"{x:1603,y:430,t:1527019577229};\\\", \\\"{x:1602,y:431,t:1527019577244};\\\", \\\"{x:1601,y:431,t:1527019577300};\\\", \\\"{x:1600,y:431,t:1527019577380};\\\", \\\"{x:1603,y:431,t:1527019577747};\\\", \\\"{x:1609,y:429,t:1527019577763};\\\", \\\"{x:1617,y:425,t:1527019577780};\\\", \\\"{x:1619,y:423,t:1527019577797};\\\", \\\"{x:1616,y:423,t:1527019577988};\\\", \\\"{x:1614,y:424,t:1527019578003};\\\", \\\"{x:1613,y:425,t:1527019578028};\\\", \\\"{x:1611,y:426,t:1527019578076};\\\", \\\"{x:1610,y:430,t:1527019578356};\\\", \\\"{x:1610,y:435,t:1527019578364};\\\", \\\"{x:1610,y:445,t:1527019578381};\\\", \\\"{x:1610,y:451,t:1527019578397};\\\", \\\"{x:1610,y:456,t:1527019578414};\\\", \\\"{x:1610,y:458,t:1527019578431};\\\", \\\"{x:1610,y:459,t:1527019578447};\\\", \\\"{x:1610,y:462,t:1527019578464};\\\", \\\"{x:1610,y:465,t:1527019578481};\\\", \\\"{x:1610,y:467,t:1527019578497};\\\", \\\"{x:1610,y:469,t:1527019578514};\\\", \\\"{x:1610,y:472,t:1527019578531};\\\", \\\"{x:1610,y:478,t:1527019578547};\\\", \\\"{x:1610,y:483,t:1527019578563};\\\", \\\"{x:1610,y:486,t:1527019578581};\\\", \\\"{x:1610,y:489,t:1527019578597};\\\", \\\"{x:1610,y:493,t:1527019578614};\\\", \\\"{x:1610,y:497,t:1527019578631};\\\", \\\"{x:1610,y:505,t:1527019578648};\\\", \\\"{x:1611,y:512,t:1527019578664};\\\", \\\"{x:1611,y:517,t:1527019578681};\\\", \\\"{x:1611,y:524,t:1527019578698};\\\", \\\"{x:1611,y:531,t:1527019578714};\\\", \\\"{x:1611,y:538,t:1527019578731};\\\", \\\"{x:1611,y:555,t:1527019578748};\\\", \\\"{x:1611,y:570,t:1527019578764};\\\", \\\"{x:1612,y:582,t:1527019578782};\\\", \\\"{x:1614,y:587,t:1527019578798};\\\", \\\"{x:1614,y:593,t:1527019578813};\\\", \\\"{x:1614,y:599,t:1527019578830};\\\", \\\"{x:1614,y:608,t:1527019578848};\\\", \\\"{x:1616,y:626,t:1527019578864};\\\", \\\"{x:1618,y:641,t:1527019578880};\\\", \\\"{x:1622,y:653,t:1527019578898};\\\", \\\"{x:1624,y:660,t:1527019578913};\\\", \\\"{x:1624,y:664,t:1527019578930};\\\", \\\"{x:1626,y:677,t:1527019578947};\\\", \\\"{x:1628,y:698,t:1527019578963};\\\", \\\"{x:1634,y:715,t:1527019578980};\\\", \\\"{x:1641,y:728,t:1527019578997};\\\", \\\"{x:1642,y:734,t:1527019579015};\\\", \\\"{x:1642,y:735,t:1527019579068};\\\", \\\"{x:1643,y:736,t:1527019579091};\\\", \\\"{x:1643,y:737,t:1527019579099};\\\", \\\"{x:1643,y:738,t:1527019579115};\\\", \\\"{x:1643,y:741,t:1527019579130};\\\", \\\"{x:1643,y:743,t:1527019579148};\\\", \\\"{x:1643,y:744,t:1527019579165};\\\", \\\"{x:1643,y:747,t:1527019579181};\\\", \\\"{x:1643,y:750,t:1527019579198};\\\", \\\"{x:1643,y:751,t:1527019579215};\\\", \\\"{x:1641,y:754,t:1527019579231};\\\", \\\"{x:1641,y:758,t:1527019579248};\\\", \\\"{x:1640,y:761,t:1527019579265};\\\", \\\"{x:1638,y:764,t:1527019579281};\\\", \\\"{x:1638,y:767,t:1527019579298};\\\", \\\"{x:1637,y:768,t:1527019579315};\\\", \\\"{x:1636,y:772,t:1527019579331};\\\", \\\"{x:1635,y:774,t:1527019579348};\\\", \\\"{x:1634,y:775,t:1527019579365};\\\", \\\"{x:1634,y:778,t:1527019579381};\\\", \\\"{x:1631,y:781,t:1527019579398};\\\", \\\"{x:1631,y:786,t:1527019579414};\\\", \\\"{x:1630,y:789,t:1527019579432};\\\", \\\"{x:1630,y:790,t:1527019579448};\\\", \\\"{x:1630,y:791,t:1527019579465};\\\", \\\"{x:1630,y:792,t:1527019579482};\\\", \\\"{x:1628,y:795,t:1527019579498};\\\", \\\"{x:1627,y:799,t:1527019579515};\\\", \\\"{x:1627,y:802,t:1527019579532};\\\", \\\"{x:1627,y:804,t:1527019579556};\\\", \\\"{x:1626,y:804,t:1527019579565};\\\", \\\"{x:1626,y:805,t:1527019579587};\\\", \\\"{x:1626,y:807,t:1527019579612};\\\", \\\"{x:1626,y:808,t:1527019579628};\\\", \\\"{x:1626,y:811,t:1527019579644};\\\", \\\"{x:1624,y:812,t:1527019579652};\\\", \\\"{x:1624,y:813,t:1527019579665};\\\", \\\"{x:1624,y:819,t:1527019579682};\\\", \\\"{x:1624,y:827,t:1527019579698};\\\", \\\"{x:1624,y:833,t:1527019579715};\\\", \\\"{x:1624,y:840,t:1527019579731};\\\", \\\"{x:1624,y:845,t:1527019579749};\\\", \\\"{x:1622,y:854,t:1527019579765};\\\", \\\"{x:1622,y:867,t:1527019579781};\\\", \\\"{x:1622,y:882,t:1527019579799};\\\", \\\"{x:1622,y:891,t:1527019579815};\\\", \\\"{x:1622,y:895,t:1527019579832};\\\", \\\"{x:1621,y:898,t:1527019579849};\\\", \\\"{x:1621,y:900,t:1527019579865};\\\", \\\"{x:1621,y:902,t:1527019579882};\\\", \\\"{x:1621,y:904,t:1527019579899};\\\", \\\"{x:1621,y:905,t:1527019579914};\\\", \\\"{x:1621,y:909,t:1527019579931};\\\", \\\"{x:1621,y:911,t:1527019579950};\\\", \\\"{x:1621,y:914,t:1527019579966};\\\", \\\"{x:1621,y:918,t:1527019579982};\\\", \\\"{x:1621,y:923,t:1527019579999};\\\", \\\"{x:1621,y:930,t:1527019580015};\\\", \\\"{x:1621,y:937,t:1527019580033};\\\", \\\"{x:1621,y:945,t:1527019580049};\\\", \\\"{x:1621,y:955,t:1527019580066};\\\", \\\"{x:1621,y:967,t:1527019580082};\\\", \\\"{x:1621,y:977,t:1527019580099};\\\", \\\"{x:1621,y:984,t:1527019580115};\\\", \\\"{x:1621,y:988,t:1527019580133};\\\", \\\"{x:1621,y:990,t:1527019580149};\\\", \\\"{x:1621,y:992,t:1527019580166};\\\", \\\"{x:1621,y:994,t:1527019580182};\\\", \\\"{x:1621,y:995,t:1527019580227};\\\", \\\"{x:1621,y:994,t:1527019580739};\\\", \\\"{x:1621,y:992,t:1527019580749};\\\", \\\"{x:1621,y:991,t:1527019580779};\\\", \\\"{x:1621,y:990,t:1527019580812};\\\", \\\"{x:1621,y:989,t:1527019580819};\\\", \\\"{x:1621,y:988,t:1527019580843};\\\", \\\"{x:1621,y:987,t:1527019580851};\\\", \\\"{x:1623,y:986,t:1527019580866};\\\", \\\"{x:1623,y:985,t:1527019580884};\\\", \\\"{x:1623,y:982,t:1527019580900};\\\", \\\"{x:1623,y:979,t:1527019580916};\\\", \\\"{x:1624,y:973,t:1527019580933};\\\", \\\"{x:1625,y:968,t:1527019580950};\\\", \\\"{x:1626,y:965,t:1527019580967};\\\", \\\"{x:1627,y:963,t:1527019580983};\\\", \\\"{x:1627,y:962,t:1527019581000};\\\", \\\"{x:1627,y:960,t:1527019581016};\\\", \\\"{x:1628,y:958,t:1527019581034};\\\", \\\"{x:1628,y:955,t:1527019581050};\\\", \\\"{x:1628,y:954,t:1527019581066};\\\", \\\"{x:1628,y:953,t:1527019581084};\\\", \\\"{x:1628,y:949,t:1527019581100};\\\", \\\"{x:1628,y:943,t:1527019581117};\\\", \\\"{x:1628,y:937,t:1527019581133};\\\", \\\"{x:1628,y:932,t:1527019581150};\\\", \\\"{x:1628,y:926,t:1527019581167};\\\", \\\"{x:1628,y:919,t:1527019581183};\\\", \\\"{x:1628,y:902,t:1527019581200};\\\", \\\"{x:1628,y:873,t:1527019581217};\\\", \\\"{x:1625,y:832,t:1527019581233};\\\", \\\"{x:1615,y:788,t:1527019581250};\\\", \\\"{x:1604,y:749,t:1527019581267};\\\", \\\"{x:1595,y:720,t:1527019581283};\\\", \\\"{x:1583,y:679,t:1527019581300};\\\", \\\"{x:1579,y:654,t:1527019581317};\\\", \\\"{x:1571,y:629,t:1527019581334};\\\", \\\"{x:1567,y:610,t:1527019581350};\\\", \\\"{x:1566,y:593,t:1527019581367};\\\", \\\"{x:1564,y:584,t:1527019581383};\\\", \\\"{x:1564,y:577,t:1527019581400};\\\", \\\"{x:1564,y:565,t:1527019581417};\\\", \\\"{x:1564,y:553,t:1527019581433};\\\", \\\"{x:1564,y:541,t:1527019581450};\\\", \\\"{x:1564,y:532,t:1527019581468};\\\", \\\"{x:1565,y:526,t:1527019581484};\\\", \\\"{x:1567,y:522,t:1527019581500};\\\", \\\"{x:1568,y:517,t:1527019581517};\\\", \\\"{x:1569,y:514,t:1527019581533};\\\", \\\"{x:1571,y:512,t:1527019581550};\\\", \\\"{x:1572,y:510,t:1527019581566};\\\", \\\"{x:1572,y:512,t:1527019581611};\\\", \\\"{x:1572,y:525,t:1527019581618};\\\", \\\"{x:1574,y:540,t:1527019581634};\\\", \\\"{x:1593,y:602,t:1527019581650};\\\", \\\"{x:1643,y:750,t:1527019581667};\\\", \\\"{x:1674,y:855,t:1527019581683};\\\", \\\"{x:1697,y:946,t:1527019581700};\\\", \\\"{x:1714,y:1010,t:1527019581717};\\\", \\\"{x:1730,y:1061,t:1527019581734};\\\", \\\"{x:1744,y:1094,t:1527019581750};\\\", \\\"{x:1750,y:1108,t:1527019581767};\\\", \\\"{x:1751,y:1111,t:1527019581784};\\\", \\\"{x:1748,y:1111,t:1527019581827};\\\", \\\"{x:1743,y:1111,t:1527019581836};\\\", \\\"{x:1732,y:1106,t:1527019581852};\\\", \\\"{x:1721,y:1103,t:1527019581867};\\\", \\\"{x:1704,y:1098,t:1527019581883};\\\", \\\"{x:1680,y:1086,t:1527019581900};\\\", \\\"{x:1655,y:1072,t:1527019581916};\\\", \\\"{x:1642,y:1063,t:1527019581934};\\\", \\\"{x:1641,y:1054,t:1527019581951};\\\", \\\"{x:1641,y:1031,t:1527019581967};\\\", \\\"{x:1644,y:1003,t:1527019581983};\\\", \\\"{x:1645,y:994,t:1527019582000};\\\", \\\"{x:1647,y:990,t:1527019582016};\\\", \\\"{x:1648,y:988,t:1527019582033};\\\", \\\"{x:1649,y:984,t:1527019582050};\\\", \\\"{x:1649,y:980,t:1527019582066};\\\", \\\"{x:1649,y:976,t:1527019582083};\\\", \\\"{x:1651,y:970,t:1527019582101};\\\", \\\"{x:1651,y:963,t:1527019582117};\\\", \\\"{x:1651,y:952,t:1527019582134};\\\", \\\"{x:1646,y:942,t:1527019582151};\\\", \\\"{x:1645,y:941,t:1527019582166};\\\", \\\"{x:1644,y:941,t:1527019582184};\\\", \\\"{x:1643,y:940,t:1527019582204};\\\", \\\"{x:1642,y:940,t:1527019582236};\\\", \\\"{x:1640,y:941,t:1527019582261};\\\", \\\"{x:1639,y:942,t:1527019582267};\\\", \\\"{x:1639,y:947,t:1527019582284};\\\", \\\"{x:1639,y:949,t:1527019582307};\\\", \\\"{x:1638,y:949,t:1527019582318};\\\", \\\"{x:1637,y:950,t:1527019582334};\\\", \\\"{x:1635,y:954,t:1527019582350};\\\", \\\"{x:1633,y:959,t:1527019582368};\\\", \\\"{x:1633,y:960,t:1527019582384};\\\", \\\"{x:1633,y:961,t:1527019582412};\\\", \\\"{x:1632,y:962,t:1527019582420};\\\", \\\"{x:1631,y:964,t:1527019582434};\\\", \\\"{x:1629,y:968,t:1527019582452};\\\", \\\"{x:1628,y:970,t:1527019582468};\\\", \\\"{x:1628,y:969,t:1527019582862};\\\", \\\"{x:1628,y:967,t:1527019582868};\\\", \\\"{x:1628,y:965,t:1527019582885};\\\", \\\"{x:1628,y:962,t:1527019582902};\\\", \\\"{x:1628,y:959,t:1527019582918};\\\", \\\"{x:1628,y:958,t:1527019582936};\\\", \\\"{x:1628,y:957,t:1527019582951};\\\", \\\"{x:1628,y:955,t:1527019582968};\\\", \\\"{x:1628,y:953,t:1527019582985};\\\", \\\"{x:1628,y:951,t:1527019583002};\\\", \\\"{x:1628,y:948,t:1527019583018};\\\", \\\"{x:1628,y:943,t:1527019583036};\\\", \\\"{x:1628,y:938,t:1527019583052};\\\", \\\"{x:1628,y:936,t:1527019583068};\\\", \\\"{x:1626,y:933,t:1527019583086};\\\", \\\"{x:1626,y:931,t:1527019583103};\\\", \\\"{x:1626,y:927,t:1527019583118};\\\", \\\"{x:1625,y:921,t:1527019583136};\\\", \\\"{x:1625,y:917,t:1527019583152};\\\", \\\"{x:1624,y:910,t:1527019583168};\\\", \\\"{x:1622,y:903,t:1527019583185};\\\", \\\"{x:1621,y:899,t:1527019583202};\\\", \\\"{x:1621,y:897,t:1527019583219};\\\", \\\"{x:1621,y:893,t:1527019583235};\\\", \\\"{x:1620,y:889,t:1527019583252};\\\", \\\"{x:1618,y:883,t:1527019583268};\\\", \\\"{x:1618,y:878,t:1527019583285};\\\", \\\"{x:1617,y:871,t:1527019583303};\\\", \\\"{x:1617,y:866,t:1527019583319};\\\", \\\"{x:1616,y:862,t:1527019583335};\\\", \\\"{x:1615,y:857,t:1527019583352};\\\", \\\"{x:1614,y:851,t:1527019583370};\\\", \\\"{x:1610,y:835,t:1527019583385};\\\", \\\"{x:1603,y:814,t:1527019583402};\\\", \\\"{x:1597,y:791,t:1527019583420};\\\", \\\"{x:1596,y:784,t:1527019583435};\\\", \\\"{x:1595,y:780,t:1527019583452};\\\", \\\"{x:1594,y:776,t:1527019583469};\\\", \\\"{x:1593,y:767,t:1527019583485};\\\", \\\"{x:1590,y:755,t:1527019583502};\\\", \\\"{x:1588,y:741,t:1527019583519};\\\", \\\"{x:1587,y:731,t:1527019583535};\\\", \\\"{x:1587,y:724,t:1527019583552};\\\", \\\"{x:1585,y:718,t:1527019583569};\\\", \\\"{x:1584,y:712,t:1527019583586};\\\", \\\"{x:1584,y:707,t:1527019583603};\\\", \\\"{x:1581,y:694,t:1527019583620};\\\", \\\"{x:1580,y:685,t:1527019583635};\\\", \\\"{x:1579,y:678,t:1527019583652};\\\", \\\"{x:1579,y:670,t:1527019583669};\\\", \\\"{x:1579,y:660,t:1527019583686};\\\", \\\"{x:1579,y:650,t:1527019583702};\\\", \\\"{x:1576,y:637,t:1527019583719};\\\", \\\"{x:1575,y:626,t:1527019583737};\\\", \\\"{x:1575,y:610,t:1527019583753};\\\", \\\"{x:1575,y:594,t:1527019583769};\\\", \\\"{x:1575,y:580,t:1527019583787};\\\", \\\"{x:1575,y:565,t:1527019583802};\\\", \\\"{x:1575,y:542,t:1527019583818};\\\", \\\"{x:1575,y:528,t:1527019583836};\\\", \\\"{x:1575,y:518,t:1527019583851};\\\", \\\"{x:1575,y:513,t:1527019583868};\\\", \\\"{x:1575,y:509,t:1527019583886};\\\", \\\"{x:1575,y:508,t:1527019583901};\\\", \\\"{x:1574,y:508,t:1527019588069};\\\", \\\"{x:1574,y:505,t:1527019595061};\\\", \\\"{x:1575,y:497,t:1527019595068};\\\", \\\"{x:1578,y:489,t:1527019595080};\\\", \\\"{x:1583,y:474,t:1527019595096};\\\", \\\"{x:1589,y:462,t:1527019595113};\\\", \\\"{x:1592,y:454,t:1527019595130};\\\", \\\"{x:1593,y:452,t:1527019595146};\\\", \\\"{x:1593,y:451,t:1527019595163};\\\", \\\"{x:1594,y:450,t:1527019595380};\\\", \\\"{x:1594,y:451,t:1527019595490};\\\", \\\"{x:1594,y:453,t:1527019595498};\\\", \\\"{x:1594,y:454,t:1527019595514};\\\", \\\"{x:1594,y:456,t:1527019595530};\\\", \\\"{x:1594,y:459,t:1527019595546};\\\", \\\"{x:1594,y:462,t:1527019595563};\\\", \\\"{x:1592,y:465,t:1527019595581};\\\", \\\"{x:1591,y:467,t:1527019595598};\\\", \\\"{x:1591,y:470,t:1527019595613};\\\", \\\"{x:1590,y:472,t:1527019595630};\\\", \\\"{x:1590,y:473,t:1527019595647};\\\", \\\"{x:1590,y:475,t:1527019595663};\\\", \\\"{x:1589,y:476,t:1527019595680};\\\", \\\"{x:1589,y:477,t:1527019595739};\\\", \\\"{x:1589,y:479,t:1527019595747};\\\", \\\"{x:1589,y:480,t:1527019595764};\\\", \\\"{x:1589,y:482,t:1527019595781};\\\", \\\"{x:1589,y:483,t:1527019595804};\\\", \\\"{x:1589,y:484,t:1527019595815};\\\", \\\"{x:1589,y:485,t:1527019595831};\\\", \\\"{x:1589,y:488,t:1527019595848};\\\", \\\"{x:1589,y:491,t:1527019595864};\\\", \\\"{x:1588,y:492,t:1527019595880};\\\", \\\"{x:1588,y:493,t:1527019595898};\\\", \\\"{x:1588,y:494,t:1527019595915};\\\", \\\"{x:1588,y:496,t:1527019595931};\\\", \\\"{x:1588,y:497,t:1527019595948};\\\", \\\"{x:1588,y:498,t:1527019595964};\\\", \\\"{x:1588,y:500,t:1527019595987};\\\", \\\"{x:1588,y:503,t:1527019596004};\\\", \\\"{x:1588,y:505,t:1527019596014};\\\", \\\"{x:1588,y:511,t:1527019596031};\\\", \\\"{x:1588,y:515,t:1527019596048};\\\", \\\"{x:1588,y:518,t:1527019596064};\\\", \\\"{x:1588,y:521,t:1527019596081};\\\", \\\"{x:1588,y:525,t:1527019596098};\\\", \\\"{x:1588,y:531,t:1527019596114};\\\", \\\"{x:1588,y:539,t:1527019596131};\\\", \\\"{x:1588,y:542,t:1527019596147};\\\", \\\"{x:1588,y:543,t:1527019596164};\\\", \\\"{x:1589,y:544,t:1527019596181};\\\", \\\"{x:1589,y:548,t:1527019596198};\\\", \\\"{x:1589,y:554,t:1527019596214};\\\", \\\"{x:1590,y:558,t:1527019596231};\\\", \\\"{x:1590,y:562,t:1527019596247};\\\", \\\"{x:1592,y:563,t:1527019596265};\\\", \\\"{x:1592,y:570,t:1527019596282};\\\", \\\"{x:1594,y:575,t:1527019596298};\\\", \\\"{x:1597,y:584,t:1527019596315};\\\", \\\"{x:1601,y:599,t:1527019596331};\\\", \\\"{x:1606,y:613,t:1527019596348};\\\", \\\"{x:1609,y:629,t:1527019596365};\\\", \\\"{x:1614,y:649,t:1527019596382};\\\", \\\"{x:1622,y:675,t:1527019596398};\\\", \\\"{x:1630,y:703,t:1527019596415};\\\", \\\"{x:1642,y:742,t:1527019596432};\\\", \\\"{x:1654,y:787,t:1527019596449};\\\", \\\"{x:1669,y:832,t:1527019596464};\\\", \\\"{x:1683,y:866,t:1527019596482};\\\", \\\"{x:1692,y:888,t:1527019596498};\\\", \\\"{x:1698,y:908,t:1527019596514};\\\", \\\"{x:1703,y:942,t:1527019596531};\\\", \\\"{x:1705,y:963,t:1527019596548};\\\", \\\"{x:1707,y:986,t:1527019596564};\\\", \\\"{x:1708,y:1015,t:1527019596581};\\\", \\\"{x:1708,y:1045,t:1527019596598};\\\", \\\"{x:1708,y:1072,t:1527019596614};\\\", \\\"{x:1708,y:1094,t:1527019596631};\\\", \\\"{x:1707,y:1101,t:1527019596648};\\\", \\\"{x:1706,y:1103,t:1527019596664};\\\", \\\"{x:1704,y:1103,t:1527019596682};\\\", \\\"{x:1702,y:1103,t:1527019596698};\\\", \\\"{x:1700,y:1104,t:1527019596714};\\\", \\\"{x:1696,y:1105,t:1527019596731};\\\", \\\"{x:1691,y:1105,t:1527019596748};\\\", \\\"{x:1687,y:1105,t:1527019596765};\\\", \\\"{x:1678,y:1103,t:1527019596781};\\\", \\\"{x:1662,y:1086,t:1527019596798};\\\", \\\"{x:1645,y:1057,t:1527019596816};\\\", \\\"{x:1629,y:1026,t:1527019596831};\\\", \\\"{x:1624,y:1015,t:1527019596848};\\\", \\\"{x:1624,y:1013,t:1527019596875};\\\", \\\"{x:1624,y:1011,t:1527019596882};\\\", \\\"{x:1623,y:1010,t:1527019596898};\\\", \\\"{x:1621,y:1003,t:1527019596914};\\\", \\\"{x:1620,y:999,t:1527019596931};\\\", \\\"{x:1620,y:996,t:1527019596948};\\\", \\\"{x:1620,y:993,t:1527019596965};\\\", \\\"{x:1620,y:990,t:1527019596981};\\\", \\\"{x:1621,y:986,t:1527019596998};\\\", \\\"{x:1622,y:984,t:1527019597015};\\\", \\\"{x:1623,y:984,t:1527019597050};\\\", \\\"{x:1624,y:982,t:1527019597065};\\\", \\\"{x:1625,y:982,t:1527019597081};\\\", \\\"{x:1627,y:978,t:1527019597099};\\\", \\\"{x:1627,y:972,t:1527019597115};\\\", \\\"{x:1627,y:971,t:1527019597131};\\\", \\\"{x:1627,y:970,t:1527019597149};\\\", \\\"{x:1629,y:968,t:1527019597167};\\\", \\\"{x:1629,y:967,t:1527019597183};\\\", \\\"{x:1631,y:965,t:1527019597199};\\\", \\\"{x:1632,y:964,t:1527019597216};\\\", \\\"{x:1633,y:963,t:1527019597233};\\\", \\\"{x:1634,y:962,t:1527019597248};\\\", \\\"{x:1635,y:961,t:1527019597265};\\\", \\\"{x:1636,y:961,t:1527019597314};\\\", \\\"{x:1639,y:962,t:1527019597322};\\\", \\\"{x:1640,y:963,t:1527019597332};\\\", \\\"{x:1644,y:963,t:1527019597348};\\\", \\\"{x:1640,y:963,t:1527019607732};\\\", \\\"{x:1626,y:958,t:1527019607743};\\\", \\\"{x:1599,y:946,t:1527019607759};\\\", \\\"{x:1599,y:947,t:1527019608235};\\\", \\\"{x:1599,y:948,t:1527019608275};\\\", \\\"{x:1599,y:950,t:1527019608293};\\\", \\\"{x:1598,y:952,t:1527019608310};\\\", \\\"{x:1593,y:959,t:1527019608327};\\\", \\\"{x:1585,y:970,t:1527019608344};\\\", \\\"{x:1575,y:981,t:1527019608360};\\\", \\\"{x:1566,y:991,t:1527019608377};\\\", \\\"{x:1559,y:997,t:1527019608393};\\\", \\\"{x:1553,y:1004,t:1527019608410};\\\", \\\"{x:1543,y:1009,t:1527019608426};\\\", \\\"{x:1527,y:1022,t:1527019608443};\\\", \\\"{x:1509,y:1036,t:1527019608460};\\\", \\\"{x:1474,y:1061,t:1527019608476};\\\", \\\"{x:1425,y:1103,t:1527019608493};\\\", \\\"{x:1372,y:1139,t:1527019608510};\\\", \\\"{x:1319,y:1164,t:1527019608527};\\\", \\\"{x:1266,y:1179,t:1527019608543};\\\", \\\"{x:1199,y:1189,t:1527019608561};\\\", \\\"{x:1132,y:1199,t:1527019608577};\\\", \\\"{x:1084,y:1199,t:1527019608586};\\\", \\\"{x:1052,y:1199,t:1527019608604};\\\", \\\"{x:1037,y:1199,t:1527019608619};\\\", \\\"{x:1031,y:1199,t:1527019608637};\\\", \\\"{x:1026,y:1199,t:1527019608653};\\\", \\\"{x:1024,y:1199,t:1527019608670};\\\", \\\"{x:1023,y:1199,t:1527019608687};\\\", \\\"{x:1020,y:1199,t:1527019608703};\\\", \\\"{x:1019,y:1198,t:1527019608722};\\\", \\\"{x:1019,y:1192,t:1527019609131};\\\", \\\"{x:1020,y:1187,t:1527019609139};\\\", \\\"{x:1021,y:1184,t:1527019609155};\\\", \\\"{x:1022,y:1174,t:1527019609172};\\\", \\\"{x:1022,y:1156,t:1527019609187};\\\", \\\"{x:1012,y:1132,t:1527019609204};\\\", \\\"{x:1002,y:1113,t:1527019609219};\\\", \\\"{x:998,y:1091,t:1527019609237};\\\", \\\"{x:994,y:1050,t:1527019609254};\\\", \\\"{x:989,y:985,t:1527019609271};\\\", \\\"{x:982,y:919,t:1527019609287};\\\", \\\"{x:979,y:883,t:1527019609304};\\\", \\\"{x:978,y:869,t:1527019609321};\\\", \\\"{x:976,y:861,t:1527019609337};\\\", \\\"{x:976,y:857,t:1527019609354};\\\", \\\"{x:976,y:850,t:1527019609371};\\\", \\\"{x:978,y:846,t:1527019609386};\\\", \\\"{x:981,y:843,t:1527019609404};\\\", \\\"{x:981,y:841,t:1527019609421};\\\", \\\"{x:981,y:839,t:1527019609437};\\\", \\\"{x:981,y:838,t:1527019609454};\\\", \\\"{x:981,y:837,t:1527019609471};\\\", \\\"{x:981,y:836,t:1527019609487};\\\", \\\"{x:981,y:840,t:1527019609716};\\\", \\\"{x:981,y:845,t:1527019609723};\\\", \\\"{x:981,y:848,t:1527019609738};\\\", \\\"{x:981,y:851,t:1527019609754};\\\", \\\"{x:980,y:853,t:1527019609947};\\\", \\\"{x:981,y:856,t:1527019609955};\\\", \\\"{x:990,y:860,t:1527019609972};\\\", \\\"{x:997,y:862,t:1527019609988};\\\", \\\"{x:1002,y:865,t:1527019610004};\\\", \\\"{x:1011,y:869,t:1527019610021};\\\", \\\"{x:1019,y:872,t:1527019610038};\\\", \\\"{x:1021,y:874,t:1527019610054};\\\", \\\"{x:1022,y:874,t:1527019610072};\\\", \\\"{x:1023,y:874,t:1527019610140};\\\", \\\"{x:1024,y:874,t:1527019610211};\\\", \\\"{x:1025,y:877,t:1527019610274};\\\", \\\"{x:1026,y:879,t:1527019610288};\\\", \\\"{x:1030,y:883,t:1527019610305};\\\", \\\"{x:1035,y:889,t:1527019610320};\\\", \\\"{x:1042,y:899,t:1527019610338};\\\", \\\"{x:1049,y:908,t:1527019610355};\\\", \\\"{x:1052,y:913,t:1527019610371};\\\", \\\"{x:1054,y:916,t:1527019610388};\\\", \\\"{x:1054,y:918,t:1527019610405};\\\", \\\"{x:1055,y:920,t:1527019610420};\\\", \\\"{x:1055,y:921,t:1527019610438};\\\", \\\"{x:1055,y:924,t:1527019610455};\\\", \\\"{x:1057,y:928,t:1527019610471};\\\", \\\"{x:1058,y:931,t:1527019610489};\\\", \\\"{x:1059,y:933,t:1527019610505};\\\", \\\"{x:1062,y:938,t:1527019610521};\\\", \\\"{x:1062,y:942,t:1527019610538};\\\", \\\"{x:1066,y:950,t:1527019610554};\\\", \\\"{x:1066,y:953,t:1527019610571};\\\", \\\"{x:1066,y:954,t:1527019610610};\\\", \\\"{x:1066,y:955,t:1527019610621};\\\", \\\"{x:1066,y:956,t:1527019610638};\\\", \\\"{x:1067,y:956,t:1527019611267};\\\", \\\"{x:1069,y:956,t:1527019611275};\\\", \\\"{x:1069,y:957,t:1527019611289};\\\", \\\"{x:1070,y:958,t:1527019611395};\\\", \\\"{x:1070,y:959,t:1527019611406};\\\", \\\"{x:1074,y:960,t:1527019611422};\\\", \\\"{x:1079,y:963,t:1527019611440};\\\", \\\"{x:1082,y:963,t:1527019611491};\\\", \\\"{x:1083,y:965,t:1527019611506};\\\", \\\"{x:1096,y:969,t:1527019611522};\\\", \\\"{x:1106,y:970,t:1527019611539};\\\", \\\"{x:1111,y:970,t:1527019611556};\\\", \\\"{x:1113,y:971,t:1527019611572};\\\", \\\"{x:1115,y:972,t:1527019611589};\\\", \\\"{x:1118,y:973,t:1527019611606};\\\", \\\"{x:1119,y:974,t:1527019611622};\\\", \\\"{x:1118,y:975,t:1527019611756};\\\", \\\"{x:1117,y:976,t:1527019611772};\\\", \\\"{x:1115,y:976,t:1527019611789};\\\", \\\"{x:1113,y:976,t:1527019611806};\\\", \\\"{x:1112,y:976,t:1527019611823};\\\", \\\"{x:1110,y:976,t:1527019611839};\\\", \\\"{x:1109,y:976,t:1527019611856};\\\", \\\"{x:1107,y:976,t:1527019611971};\\\", \\\"{x:1106,y:976,t:1527019611978};\\\", \\\"{x:1104,y:975,t:1527019611989};\\\", \\\"{x:1102,y:974,t:1527019612006};\\\", \\\"{x:1099,y:971,t:1527019612023};\\\", \\\"{x:1095,y:970,t:1527019612038};\\\", \\\"{x:1094,y:970,t:1527019612056};\\\", \\\"{x:1093,y:969,t:1527019612372};\\\", \\\"{x:1094,y:969,t:1527019612571};\\\", \\\"{x:1095,y:968,t:1527019612579};\\\", \\\"{x:1096,y:967,t:1527019612590};\\\", \\\"{x:1098,y:966,t:1527019612606};\\\", \\\"{x:1099,y:966,t:1527019612624};\\\", \\\"{x:1102,y:964,t:1527019612641};\\\", \\\"{x:1104,y:964,t:1527019612675};\\\", \\\"{x:1105,y:964,t:1527019612691};\\\", \\\"{x:1107,y:964,t:1527019612706};\\\", \\\"{x:1110,y:963,t:1527019612723};\\\", \\\"{x:1111,y:963,t:1527019612741};\\\", \\\"{x:1113,y:963,t:1527019612756};\\\", \\\"{x:1116,y:962,t:1527019612773};\\\", \\\"{x:1118,y:961,t:1527019612791};\\\", \\\"{x:1122,y:960,t:1527019612807};\\\", \\\"{x:1126,y:959,t:1527019612824};\\\", \\\"{x:1133,y:957,t:1527019612840};\\\", \\\"{x:1135,y:957,t:1527019612857};\\\", \\\"{x:1138,y:957,t:1527019612873};\\\", \\\"{x:1139,y:957,t:1527019612890};\\\", \\\"{x:1141,y:957,t:1527019612907};\\\", \\\"{x:1142,y:957,t:1527019612939};\\\", \\\"{x:1143,y:957,t:1527019612947};\\\", \\\"{x:1144,y:957,t:1527019612957};\\\", \\\"{x:1145,y:957,t:1527019612979};\\\", \\\"{x:1143,y:957,t:1527019613062};\\\", \\\"{x:1140,y:957,t:1527019613074};\\\", \\\"{x:1131,y:957,t:1527019613090};\\\", \\\"{x:1123,y:954,t:1527019613107};\\\", \\\"{x:1122,y:954,t:1527019613218};\\\", \\\"{x:1119,y:955,t:1527019613226};\\\", \\\"{x:1117,y:957,t:1527019613240};\\\", \\\"{x:1111,y:963,t:1527019613257};\\\", \\\"{x:1105,y:965,t:1527019613274};\\\", \\\"{x:1099,y:967,t:1527019613290};\\\", \\\"{x:1092,y:970,t:1527019613306};\\\", \\\"{x:1092,y:972,t:1527019613324};\\\", \\\"{x:1092,y:973,t:1527019613355};\\\", \\\"{x:1094,y:973,t:1527019613508};\\\", \\\"{x:1100,y:973,t:1527019613524};\\\", \\\"{x:1108,y:973,t:1527019613541};\\\", \\\"{x:1116,y:973,t:1527019613557};\\\", \\\"{x:1119,y:973,t:1527019613574};\\\", \\\"{x:1121,y:973,t:1527019613590};\\\", \\\"{x:1123,y:973,t:1527019613607};\\\", \\\"{x:1126,y:972,t:1527019613625};\\\", \\\"{x:1131,y:972,t:1527019613641};\\\", \\\"{x:1138,y:972,t:1527019613657};\\\", \\\"{x:1144,y:972,t:1527019613673};\\\", \\\"{x:1148,y:972,t:1527019613690};\\\", \\\"{x:1150,y:972,t:1527019613707};\\\", \\\"{x:1152,y:972,t:1527019613731};\\\", \\\"{x:1153,y:972,t:1527019613770};\\\", \\\"{x:1156,y:971,t:1527019613794};\\\", \\\"{x:1157,y:971,t:1527019613807};\\\", \\\"{x:1160,y:971,t:1527019613824};\\\", \\\"{x:1164,y:971,t:1527019613841};\\\", \\\"{x:1165,y:971,t:1527019613857};\\\", \\\"{x:1165,y:970,t:1527019613874};\\\", \\\"{x:1166,y:970,t:1527019614260};\\\", \\\"{x:1167,y:970,t:1527019614275};\\\", \\\"{x:1170,y:970,t:1527019614292};\\\", \\\"{x:1172,y:969,t:1527019614309};\\\", \\\"{x:1173,y:969,t:1527019614324};\\\", \\\"{x:1174,y:969,t:1527019614341};\\\", \\\"{x:1176,y:968,t:1527019614358};\\\", \\\"{x:1177,y:968,t:1527019614378};\\\", \\\"{x:1178,y:968,t:1527019614391};\\\", \\\"{x:1181,y:968,t:1527019614409};\\\", \\\"{x:1182,y:967,t:1527019614424};\\\", \\\"{x:1187,y:966,t:1527019614441};\\\", \\\"{x:1192,y:965,t:1527019614459};\\\", \\\"{x:1192,y:964,t:1527019614474};\\\", \\\"{x:1195,y:964,t:1527019614491};\\\", \\\"{x:1199,y:964,t:1527019614508};\\\", \\\"{x:1205,y:962,t:1527019614525};\\\", \\\"{x:1209,y:962,t:1527019614542};\\\", \\\"{x:1209,y:961,t:1527019614558};\\\", \\\"{x:1210,y:961,t:1527019614575};\\\", \\\"{x:1212,y:961,t:1527019614592};\\\", \\\"{x:1218,y:961,t:1527019614608};\\\", \\\"{x:1223,y:961,t:1527019614625};\\\", \\\"{x:1224,y:961,t:1527019614642};\\\", \\\"{x:1225,y:961,t:1527019614658};\\\", \\\"{x:1225,y:958,t:1527019616906};\\\", \\\"{x:1226,y:949,t:1527019616914};\\\", \\\"{x:1228,y:943,t:1527019616926};\\\", \\\"{x:1229,y:928,t:1527019616943};\\\", \\\"{x:1233,y:917,t:1527019616960};\\\", \\\"{x:1234,y:912,t:1527019616976};\\\", \\\"{x:1235,y:906,t:1527019616993};\\\", \\\"{x:1238,y:889,t:1527019617010};\\\", \\\"{x:1239,y:882,t:1527019617026};\\\", \\\"{x:1242,y:862,t:1527019617043};\\\", \\\"{x:1242,y:855,t:1527019617060};\\\", \\\"{x:1242,y:851,t:1527019617076};\\\", \\\"{x:1242,y:848,t:1527019617093};\\\", \\\"{x:1242,y:847,t:1527019617110};\\\", \\\"{x:1242,y:846,t:1527019617126};\\\", \\\"{x:1242,y:843,t:1527019617144};\\\", \\\"{x:1242,y:842,t:1527019617161};\\\", \\\"{x:1242,y:841,t:1527019617176};\\\", \\\"{x:1242,y:840,t:1527019617194};\\\", \\\"{x:1242,y:838,t:1527019617210};\\\", \\\"{x:1242,y:836,t:1527019617227};\\\", \\\"{x:1242,y:833,t:1527019617243};\\\", \\\"{x:1241,y:833,t:1527019617260};\\\", \\\"{x:1241,y:832,t:1527019617277};\\\", \\\"{x:1241,y:830,t:1527019617294};\\\", \\\"{x:1241,y:828,t:1527019617311};\\\", \\\"{x:1239,y:826,t:1527019617328};\\\", \\\"{x:1239,y:824,t:1527019617343};\\\", \\\"{x:1239,y:823,t:1527019617360};\\\", \\\"{x:1239,y:819,t:1527019617377};\\\", \\\"{x:1239,y:810,t:1527019617394};\\\", \\\"{x:1238,y:785,t:1527019617411};\\\", \\\"{x:1238,y:774,t:1527019617427};\\\", \\\"{x:1238,y:769,t:1527019617443};\\\", \\\"{x:1238,y:768,t:1527019617461};\\\", \\\"{x:1238,y:767,t:1527019617477};\\\", \\\"{x:1237,y:768,t:1527019617668};\\\", \\\"{x:1236,y:769,t:1527019617678};\\\", \\\"{x:1234,y:775,t:1527019617695};\\\", \\\"{x:1233,y:778,t:1527019617711};\\\", \\\"{x:1232,y:779,t:1527019617728};\\\", \\\"{x:1232,y:781,t:1527019617812};\\\", \\\"{x:1231,y:786,t:1527019617827};\\\", \\\"{x:1231,y:791,t:1527019617844};\\\", \\\"{x:1230,y:798,t:1527019617861};\\\", \\\"{x:1227,y:808,t:1527019617878};\\\", \\\"{x:1226,y:818,t:1527019617895};\\\", \\\"{x:1226,y:830,t:1527019617911};\\\", \\\"{x:1226,y:838,t:1527019617928};\\\", \\\"{x:1226,y:847,t:1527019617945};\\\", \\\"{x:1226,y:858,t:1527019617961};\\\", \\\"{x:1226,y:869,t:1527019617977};\\\", \\\"{x:1226,y:877,t:1527019617995};\\\", \\\"{x:1226,y:880,t:1527019618011};\\\", \\\"{x:1226,y:881,t:1527019618028};\\\", \\\"{x:1226,y:883,t:1527019618045};\\\", \\\"{x:1226,y:885,t:1527019618062};\\\", \\\"{x:1227,y:890,t:1527019618077};\\\", \\\"{x:1227,y:895,t:1527019618095};\\\", \\\"{x:1228,y:900,t:1527019618111};\\\", \\\"{x:1228,y:905,t:1527019618127};\\\", \\\"{x:1231,y:909,t:1527019618145};\\\", \\\"{x:1231,y:911,t:1527019618161};\\\", \\\"{x:1232,y:916,t:1527019618178};\\\", \\\"{x:1237,y:932,t:1527019618195};\\\", \\\"{x:1241,y:941,t:1527019618211};\\\", \\\"{x:1243,y:947,t:1527019618228};\\\", \\\"{x:1244,y:948,t:1527019618245};\\\", \\\"{x:1244,y:949,t:1527019618267};\\\", \\\"{x:1244,y:950,t:1527019618278};\\\", \\\"{x:1246,y:956,t:1527019618295};\\\", \\\"{x:1247,y:960,t:1527019618312};\\\", \\\"{x:1249,y:965,t:1527019618328};\\\", \\\"{x:1249,y:967,t:1527019618345};\\\", \\\"{x:1250,y:968,t:1527019618362};\\\", \\\"{x:1252,y:971,t:1527019618378};\\\", \\\"{x:1253,y:972,t:1527019618403};\\\", \\\"{x:1254,y:972,t:1527019618435};\\\", \\\"{x:1255,y:972,t:1527019618491};\\\", \\\"{x:1256,y:973,t:1527019618540};\\\", \\\"{x:1258,y:974,t:1527019618547};\\\", \\\"{x:1260,y:974,t:1527019618628};\\\", \\\"{x:1261,y:975,t:1527019618651};\\\", \\\"{x:1262,y:975,t:1527019619002};\\\", \\\"{x:1262,y:974,t:1527019619011};\\\", \\\"{x:1264,y:971,t:1527019619028};\\\", \\\"{x:1265,y:970,t:1527019619045};\\\", \\\"{x:1265,y:968,t:1527019619061};\\\", \\\"{x:1265,y:967,t:1527019619079};\\\", \\\"{x:1265,y:965,t:1527019619099};\\\", \\\"{x:1266,y:963,t:1527019619140};\\\", \\\"{x:1266,y:962,t:1527019619164};\\\", \\\"{x:1266,y:961,t:1527019619179};\\\", \\\"{x:1266,y:959,t:1527019619195};\\\", \\\"{x:1266,y:958,t:1527019619212};\\\", \\\"{x:1266,y:957,t:1527019619229};\\\", \\\"{x:1266,y:956,t:1527019619246};\\\", \\\"{x:1266,y:955,t:1527019619261};\\\", \\\"{x:1266,y:953,t:1527019619279};\\\", \\\"{x:1266,y:952,t:1527019619296};\\\", \\\"{x:1266,y:949,t:1527019619311};\\\", \\\"{x:1266,y:947,t:1527019619328};\\\", \\\"{x:1266,y:944,t:1527019619345};\\\", \\\"{x:1266,y:941,t:1527019619362};\\\", \\\"{x:1266,y:937,t:1527019619379};\\\", \\\"{x:1266,y:932,t:1527019619396};\\\", \\\"{x:1266,y:926,t:1527019619413};\\\", \\\"{x:1266,y:915,t:1527019619429};\\\", \\\"{x:1266,y:894,t:1527019619446};\\\", \\\"{x:1266,y:864,t:1527019619463};\\\", \\\"{x:1266,y:821,t:1527019619479};\\\", \\\"{x:1266,y:773,t:1527019619496};\\\", \\\"{x:1266,y:739,t:1527019619513};\\\", \\\"{x:1266,y:718,t:1527019619528};\\\", \\\"{x:1266,y:701,t:1527019619546};\\\", \\\"{x:1269,y:675,t:1527019619563};\\\", \\\"{x:1273,y:659,t:1527019619579};\\\", \\\"{x:1277,y:642,t:1527019619595};\\\", \\\"{x:1279,y:627,t:1527019619612};\\\", \\\"{x:1280,y:614,t:1527019619628};\\\", \\\"{x:1282,y:604,t:1527019619646};\\\", \\\"{x:1283,y:600,t:1527019619663};\\\", \\\"{x:1284,y:597,t:1527019619678};\\\", \\\"{x:1285,y:595,t:1527019619696};\\\", \\\"{x:1285,y:594,t:1527019619713};\\\", \\\"{x:1284,y:594,t:1527019619924};\\\", \\\"{x:1281,y:600,t:1527019619931};\\\", \\\"{x:1278,y:605,t:1527019619945};\\\", \\\"{x:1268,y:619,t:1527019619962};\\\", \\\"{x:1263,y:627,t:1527019619979};\\\", \\\"{x:1261,y:631,t:1527019619995};\\\", \\\"{x:1260,y:632,t:1527019620013};\\\", \\\"{x:1259,y:633,t:1527019620029};\\\", \\\"{x:1259,y:634,t:1527019620046};\\\", \\\"{x:1258,y:635,t:1527019620067};\\\", \\\"{x:1257,y:635,t:1527019620080};\\\", \\\"{x:1255,y:637,t:1527019620140};\\\", \\\"{x:1254,y:637,t:1527019620171};\\\", \\\"{x:1253,y:637,t:1527019620203};\\\", \\\"{x:1250,y:637,t:1527019620219};\\\", \\\"{x:1249,y:637,t:1527019620235};\\\", \\\"{x:1247,y:636,t:1527019620246};\\\", \\\"{x:1246,y:634,t:1527019620263};\\\", \\\"{x:1246,y:635,t:1527019621332};\\\", \\\"{x:1246,y:643,t:1527019621348};\\\", \\\"{x:1246,y:650,t:1527019621363};\\\", \\\"{x:1246,y:655,t:1527019621381};\\\", \\\"{x:1247,y:660,t:1527019621396};\\\", \\\"{x:1248,y:665,t:1527019621414};\\\", \\\"{x:1249,y:672,t:1527019621430};\\\", \\\"{x:1251,y:684,t:1527019621447};\\\", \\\"{x:1253,y:705,t:1527019621464};\\\", \\\"{x:1257,y:725,t:1527019621480};\\\", \\\"{x:1261,y:740,t:1527019621497};\\\", \\\"{x:1264,y:756,t:1527019621513};\\\", \\\"{x:1270,y:779,t:1527019621529};\\\", \\\"{x:1273,y:795,t:1527019621546};\\\", \\\"{x:1278,y:823,t:1527019621563};\\\", \\\"{x:1281,y:853,t:1527019621580};\\\", \\\"{x:1289,y:877,t:1527019621597};\\\", \\\"{x:1294,y:895,t:1527019621613};\\\", \\\"{x:1296,y:905,t:1527019621631};\\\", \\\"{x:1296,y:910,t:1527019621647};\\\", \\\"{x:1296,y:916,t:1527019621663};\\\", \\\"{x:1296,y:921,t:1527019621681};\\\", \\\"{x:1296,y:928,t:1527019621697};\\\", \\\"{x:1296,y:935,t:1527019621713};\\\", \\\"{x:1296,y:948,t:1527019621730};\\\", \\\"{x:1294,y:960,t:1527019621747};\\\", \\\"{x:1288,y:973,t:1527019621763};\\\", \\\"{x:1284,y:983,t:1527019621781};\\\", \\\"{x:1280,y:990,t:1527019621798};\\\", \\\"{x:1277,y:996,t:1527019621814};\\\", \\\"{x:1272,y:1002,t:1527019621831};\\\", \\\"{x:1270,y:1007,t:1527019621848};\\\", \\\"{x:1267,y:1013,t:1527019621863};\\\", \\\"{x:1266,y:1016,t:1527019621880};\\\", \\\"{x:1266,y:1017,t:1527019621899};\\\", \\\"{x:1265,y:1017,t:1527019621923};\\\", \\\"{x:1265,y:1016,t:1527019622011};\\\", \\\"{x:1264,y:1015,t:1527019622019};\\\", \\\"{x:1264,y:1014,t:1527019622030};\\\", \\\"{x:1264,y:1012,t:1527019622048};\\\", \\\"{x:1263,y:1012,t:1527019622065};\\\", \\\"{x:1263,y:1011,t:1527019622081};\\\", \\\"{x:1260,y:1010,t:1527019622097};\\\", \\\"{x:1257,y:1009,t:1527019622114};\\\", \\\"{x:1256,y:1009,t:1527019622130};\\\", \\\"{x:1255,y:1009,t:1527019622147};\\\", \\\"{x:1249,y:1009,t:1527019622165};\\\", \\\"{x:1240,y:1008,t:1527019622181};\\\", \\\"{x:1234,y:1008,t:1527019622197};\\\", \\\"{x:1233,y:1008,t:1527019622214};\\\", \\\"{x:1232,y:1007,t:1527019622316};\\\", \\\"{x:1232,y:1002,t:1527019622331};\\\", \\\"{x:1232,y:994,t:1527019622348};\\\", \\\"{x:1232,y:987,t:1527019622365};\\\", \\\"{x:1232,y:979,t:1527019622381};\\\", \\\"{x:1232,y:977,t:1527019622397};\\\", \\\"{x:1232,y:976,t:1527019622415};\\\", \\\"{x:1232,y:973,t:1527019622430};\\\", \\\"{x:1233,y:972,t:1527019622448};\\\", \\\"{x:1233,y:970,t:1527019622465};\\\", \\\"{x:1233,y:969,t:1527019622481};\\\", \\\"{x:1233,y:968,t:1527019622556};\\\", \\\"{x:1234,y:965,t:1527019622564};\\\", \\\"{x:1235,y:961,t:1527019622581};\\\", \\\"{x:1235,y:955,t:1527019622598};\\\", \\\"{x:1236,y:951,t:1527019622615};\\\", \\\"{x:1237,y:941,t:1527019622631};\\\", \\\"{x:1241,y:923,t:1527019622648};\\\", \\\"{x:1247,y:894,t:1527019622664};\\\", \\\"{x:1254,y:846,t:1527019622682};\\\", \\\"{x:1254,y:807,t:1527019622697};\\\", \\\"{x:1254,y:750,t:1527019622715};\\\", \\\"{x:1254,y:714,t:1527019622732};\\\", \\\"{x:1254,y:669,t:1527019622748};\\\", \\\"{x:1254,y:645,t:1527019622765};\\\", \\\"{x:1255,y:627,t:1527019622782};\\\", \\\"{x:1258,y:614,t:1527019622798};\\\", \\\"{x:1258,y:607,t:1527019622814};\\\", \\\"{x:1259,y:603,t:1527019622832};\\\", \\\"{x:1259,y:600,t:1527019622848};\\\", \\\"{x:1259,y:603,t:1527019623034};\\\", \\\"{x:1257,y:608,t:1527019623048};\\\", \\\"{x:1252,y:614,t:1527019623064};\\\", \\\"{x:1245,y:624,t:1527019623081};\\\", \\\"{x:1237,y:636,t:1527019623099};\\\", \\\"{x:1237,y:637,t:1527019623138};\\\", \\\"{x:1235,y:638,t:1527019629561};\\\", \\\"{x:1233,y:643,t:1527019629569};\\\", \\\"{x:1228,y:649,t:1527019629586};\\\", \\\"{x:1221,y:657,t:1527019629604};\\\", \\\"{x:1211,y:672,t:1527019629620};\\\", \\\"{x:1202,y:686,t:1527019629636};\\\", \\\"{x:1191,y:706,t:1527019629654};\\\", \\\"{x:1179,y:722,t:1527019629669};\\\", \\\"{x:1169,y:740,t:1527019629686};\\\", \\\"{x:1156,y:761,t:1527019629703};\\\", \\\"{x:1143,y:784,t:1527019629720};\\\", \\\"{x:1131,y:807,t:1527019629737};\\\", \\\"{x:1120,y:830,t:1527019629754};\\\", \\\"{x:1110,y:851,t:1527019629770};\\\", \\\"{x:1103,y:879,t:1527019629787};\\\", \\\"{x:1098,y:897,t:1527019629803};\\\", \\\"{x:1093,y:913,t:1527019629819};\\\", \\\"{x:1089,y:928,t:1527019629836};\\\", \\\"{x:1086,y:937,t:1527019629854};\\\", \\\"{x:1083,y:943,t:1527019629869};\\\", \\\"{x:1080,y:949,t:1527019629887};\\\", \\\"{x:1074,y:964,t:1527019629903};\\\", \\\"{x:1070,y:982,t:1527019629921};\\\", \\\"{x:1066,y:998,t:1527019629937};\\\", \\\"{x:1064,y:1002,t:1527019629953};\\\", \\\"{x:1064,y:1003,t:1527019630091};\\\", \\\"{x:1066,y:1002,t:1527019630104};\\\", \\\"{x:1067,y:996,t:1527019630121};\\\", \\\"{x:1071,y:990,t:1527019630137};\\\", \\\"{x:1071,y:988,t:1527019630154};\\\", \\\"{x:1072,y:985,t:1527019630171};\\\", \\\"{x:1073,y:984,t:1527019630291};\\\", \\\"{x:1074,y:983,t:1527019630323};\\\", \\\"{x:1074,y:982,t:1527019630337};\\\", \\\"{x:1074,y:981,t:1527019630795};\\\", \\\"{x:1077,y:979,t:1527019630804};\\\", \\\"{x:1077,y:978,t:1527019630821};\\\", \\\"{x:1078,y:977,t:1527019630861};\\\", \\\"{x:1078,y:976,t:1527019630923};\\\", \\\"{x:1078,y:975,t:1527019630980};\\\", \\\"{x:1078,y:974,t:1527019631387};\\\", \\\"{x:1084,y:967,t:1527019631405};\\\", \\\"{x:1090,y:959,t:1527019631422};\\\", \\\"{x:1096,y:951,t:1527019631438};\\\", \\\"{x:1102,y:943,t:1527019631455};\\\", \\\"{x:1106,y:938,t:1527019631472};\\\", \\\"{x:1109,y:932,t:1527019631487};\\\", \\\"{x:1113,y:927,t:1527019631504};\\\", \\\"{x:1115,y:923,t:1527019631521};\\\", \\\"{x:1116,y:920,t:1527019631537};\\\", \\\"{x:1122,y:912,t:1527019631555};\\\", \\\"{x:1127,y:902,t:1527019631572};\\\", \\\"{x:1133,y:890,t:1527019631588};\\\", \\\"{x:1136,y:883,t:1527019631605};\\\", \\\"{x:1136,y:882,t:1527019631622};\\\", \\\"{x:1137,y:881,t:1527019631638};\\\", \\\"{x:1139,y:875,t:1527019631891};\\\", \\\"{x:1140,y:873,t:1527019631905};\\\", \\\"{x:1144,y:865,t:1527019631922};\\\", \\\"{x:1148,y:857,t:1527019631939};\\\", \\\"{x:1148,y:856,t:1527019631956};\\\", \\\"{x:1149,y:854,t:1527019631972};\\\", \\\"{x:1149,y:853,t:1527019631989};\\\", \\\"{x:1151,y:848,t:1527019632006};\\\", \\\"{x:1153,y:842,t:1527019632022};\\\", \\\"{x:1155,y:833,t:1527019632039};\\\", \\\"{x:1156,y:831,t:1527019632056};\\\", \\\"{x:1157,y:829,t:1527019632069};\\\", \\\"{x:1157,y:828,t:1527019632086};\\\", \\\"{x:1158,y:825,t:1527019632297};\\\", \\\"{x:1160,y:821,t:1527019632304};\\\", \\\"{x:1162,y:817,t:1527019632319};\\\", \\\"{x:1170,y:797,t:1527019632336};\\\", \\\"{x:1175,y:787,t:1527019632354};\\\", \\\"{x:1180,y:776,t:1527019632370};\\\", \\\"{x:1180,y:773,t:1527019632387};\\\", \\\"{x:1181,y:771,t:1527019632403};\\\", \\\"{x:1181,y:770,t:1527019632420};\\\", \\\"{x:1182,y:770,t:1527019632457};\\\", \\\"{x:1183,y:768,t:1527019632488};\\\", \\\"{x:1184,y:767,t:1527019632503};\\\", \\\"{x:1187,y:762,t:1527019632521};\\\", \\\"{x:1188,y:761,t:1527019632544};\\\", \\\"{x:1188,y:760,t:1527019632689};\\\", \\\"{x:1188,y:756,t:1527019632703};\\\", \\\"{x:1198,y:736,t:1527019632720};\\\", \\\"{x:1204,y:724,t:1527019632736};\\\", \\\"{x:1210,y:715,t:1527019632753};\\\", \\\"{x:1212,y:709,t:1527019632770};\\\", \\\"{x:1213,y:708,t:1527019632787};\\\", \\\"{x:1214,y:707,t:1527019632803};\\\", \\\"{x:1214,y:706,t:1527019632849};\\\", \\\"{x:1215,y:706,t:1527019632858};\\\", \\\"{x:1215,y:705,t:1527019632871};\\\", \\\"{x:1217,y:703,t:1527019632886};\\\", \\\"{x:1217,y:702,t:1527019632905};\\\", \\\"{x:1217,y:696,t:1527019633072};\\\", \\\"{x:1219,y:692,t:1527019633087};\\\", \\\"{x:1226,y:676,t:1527019633103};\\\", \\\"{x:1235,y:651,t:1527019633120};\\\", \\\"{x:1243,y:639,t:1527019633138};\\\", \\\"{x:1249,y:627,t:1527019633154};\\\", \\\"{x:1253,y:620,t:1527019633171};\\\", \\\"{x:1254,y:617,t:1527019633188};\\\", \\\"{x:1258,y:618,t:1527019637841};\\\", \\\"{x:1268,y:634,t:1527019637858};\\\", \\\"{x:1273,y:641,t:1527019637875};\\\", \\\"{x:1276,y:645,t:1527019637891};\\\", \\\"{x:1280,y:653,t:1527019637908};\\\", \\\"{x:1289,y:667,t:1527019637925};\\\", \\\"{x:1300,y:681,t:1527019637941};\\\", \\\"{x:1309,y:689,t:1527019637958};\\\", \\\"{x:1313,y:693,t:1527019637975};\\\", \\\"{x:1318,y:696,t:1527019637991};\\\", \\\"{x:1326,y:704,t:1527019638008};\\\", \\\"{x:1335,y:712,t:1527019638024};\\\", \\\"{x:1342,y:715,t:1527019638041};\\\", \\\"{x:1346,y:716,t:1527019638058};\\\", \\\"{x:1351,y:716,t:1527019638075};\\\", \\\"{x:1362,y:713,t:1527019638091};\\\", \\\"{x:1382,y:703,t:1527019638108};\\\", \\\"{x:1416,y:687,t:1527019638125};\\\", \\\"{x:1474,y:646,t:1527019638141};\\\", \\\"{x:1540,y:564,t:1527019638158};\\\", \\\"{x:1598,y:478,t:1527019638175};\\\", \\\"{x:1648,y:388,t:1527019638191};\\\", \\\"{x:1685,y:331,t:1527019638208};\\\", \\\"{x:1692,y:324,t:1527019638224};\\\", \\\"{x:1689,y:324,t:1527019638272};\\\", \\\"{x:1678,y:330,t:1527019638280};\\\", \\\"{x:1674,y:332,t:1527019638291};\\\", \\\"{x:1672,y:333,t:1527019638307};\\\", \\\"{x:1671,y:334,t:1527019638353};\\\", \\\"{x:1671,y:338,t:1527019638360};\\\", \\\"{x:1671,y:353,t:1527019638375};\\\", \\\"{x:1666,y:404,t:1527019638392};\\\", \\\"{x:1654,y:435,t:1527019638408};\\\", \\\"{x:1644,y:460,t:1527019638425};\\\", \\\"{x:1640,y:473,t:1527019638442};\\\", \\\"{x:1637,y:478,t:1527019638459};\\\", \\\"{x:1637,y:479,t:1527019638474};\\\", \\\"{x:1637,y:472,t:1527019638600};\\\", \\\"{x:1637,y:461,t:1527019638608};\\\", \\\"{x:1637,y:446,t:1527019638624};\\\", \\\"{x:1637,y:436,t:1527019638642};\\\", \\\"{x:1637,y:433,t:1527019638658};\\\", \\\"{x:1637,y:431,t:1527019638675};\\\", \\\"{x:1636,y:431,t:1527019638769};\\\", \\\"{x:1635,y:431,t:1527019638784};\\\", \\\"{x:1634,y:431,t:1527019638792};\\\", \\\"{x:1632,y:431,t:1527019638808};\\\", \\\"{x:1630,y:431,t:1527019638824};\\\", \\\"{x:1630,y:432,t:1527019638849};\\\", \\\"{x:1630,y:434,t:1527019638859};\\\", \\\"{x:1628,y:436,t:1527019638874};\\\", \\\"{x:1626,y:438,t:1527019638891};\\\", \\\"{x:1625,y:438,t:1527019638909};\\\", \\\"{x:1624,y:438,t:1527019638952};\\\", \\\"{x:1623,y:440,t:1527019638959};\\\", \\\"{x:1619,y:445,t:1527019638974};\\\", \\\"{x:1608,y:462,t:1527019638991};\\\", \\\"{x:1605,y:466,t:1527019639008};\\\", \\\"{x:1604,y:467,t:1527019639024};\\\", \\\"{x:1604,y:468,t:1527019639703};\\\", \\\"{x:1601,y:472,t:1527019639711};\\\", \\\"{x:1599,y:475,t:1527019639727};\\\", \\\"{x:1596,y:479,t:1527019639743};\\\", \\\"{x:1592,y:483,t:1527019639758};\\\", \\\"{x:1590,y:486,t:1527019639775};\\\", \\\"{x:1589,y:487,t:1527019639815};\\\", \\\"{x:1588,y:490,t:1527019639840};\\\", \\\"{x:1586,y:491,t:1527019639848};\\\", \\\"{x:1586,y:494,t:1527019639859};\\\", \\\"{x:1582,y:499,t:1527019639876};\\\", \\\"{x:1580,y:505,t:1527019639893};\\\", \\\"{x:1579,y:505,t:1527019639908};\\\", \\\"{x:1578,y:510,t:1527019640201};\\\", \\\"{x:1576,y:514,t:1527019640209};\\\", \\\"{x:1574,y:518,t:1527019640225};\\\", \\\"{x:1572,y:523,t:1527019640242};\\\", \\\"{x:1570,y:526,t:1527019640260};\\\", \\\"{x:1567,y:532,t:1527019640275};\\\", \\\"{x:1562,y:543,t:1527019640293};\\\", \\\"{x:1556,y:555,t:1527019640310};\\\", \\\"{x:1552,y:561,t:1527019640326};\\\", \\\"{x:1551,y:565,t:1527019640343};\\\", \\\"{x:1549,y:567,t:1527019640360};\\\", \\\"{x:1549,y:568,t:1527019640384};\\\", \\\"{x:1548,y:568,t:1527019640401};\\\", \\\"{x:1548,y:569,t:1527019640416};\\\", \\\"{x:1546,y:571,t:1527019640640};\\\", \\\"{x:1546,y:573,t:1527019640648};\\\", \\\"{x:1545,y:576,t:1527019640660};\\\", \\\"{x:1541,y:583,t:1527019640676};\\\", \\\"{x:1537,y:588,t:1527019640693};\\\", \\\"{x:1536,y:591,t:1527019640709};\\\", \\\"{x:1535,y:593,t:1527019640727};\\\", \\\"{x:1533,y:595,t:1527019640743};\\\", \\\"{x:1528,y:605,t:1527019640760};\\\", \\\"{x:1523,y:618,t:1527019640776};\\\", \\\"{x:1518,y:627,t:1527019640793};\\\", \\\"{x:1515,y:632,t:1527019640810};\\\", \\\"{x:1513,y:634,t:1527019640827};\\\", \\\"{x:1513,y:635,t:1527019640842};\\\", \\\"{x:1513,y:637,t:1527019640861};\\\", \\\"{x:1511,y:638,t:1527019640877};\\\", \\\"{x:1511,y:639,t:1527019640893};\\\", \\\"{x:1509,y:642,t:1527019640910};\\\", \\\"{x:1509,y:644,t:1527019641144};\\\", \\\"{x:1508,y:646,t:1527019641160};\\\", \\\"{x:1505,y:651,t:1527019641177};\\\", \\\"{x:1501,y:657,t:1527019641194};\\\", \\\"{x:1498,y:660,t:1527019641210};\\\", \\\"{x:1496,y:664,t:1527019641226};\\\", \\\"{x:1493,y:668,t:1527019641244};\\\", \\\"{x:1490,y:672,t:1527019641260};\\\", \\\"{x:1485,y:681,t:1527019641276};\\\", \\\"{x:1482,y:686,t:1527019641294};\\\", \\\"{x:1479,y:690,t:1527019641310};\\\", \\\"{x:1478,y:692,t:1527019641384};\\\", \\\"{x:1475,y:697,t:1527019641394};\\\", \\\"{x:1474,y:702,t:1527019641411};\\\", \\\"{x:1472,y:705,t:1527019641427};\\\", \\\"{x:1471,y:706,t:1527019641444};\\\", \\\"{x:1470,y:699,t:1527019642488};\\\", \\\"{x:1469,y:676,t:1527019642496};\\\", \\\"{x:1464,y:644,t:1527019642512};\\\", \\\"{x:1441,y:560,t:1527019642527};\\\", \\\"{x:1433,y:535,t:1527019642544};\\\", \\\"{x:1429,y:524,t:1527019642560};\\\", \\\"{x:1428,y:522,t:1527019642578};\\\", \\\"{x:1428,y:518,t:1527019642595};\\\", \\\"{x:1425,y:512,t:1527019642611};\\\", \\\"{x:1423,y:502,t:1527019642628};\\\", \\\"{x:1421,y:487,t:1527019642645};\\\", \\\"{x:1421,y:477,t:1527019642661};\\\", \\\"{x:1420,y:472,t:1527019642678};\\\", \\\"{x:1420,y:471,t:1527019642695};\\\", \\\"{x:1419,y:466,t:1527019642712};\\\", \\\"{x:1418,y:463,t:1527019642728};\\\", \\\"{x:1418,y:462,t:1527019642745};\\\", \\\"{x:1416,y:459,t:1527019642762};\\\", \\\"{x:1416,y:455,t:1527019642778};\\\", \\\"{x:1414,y:451,t:1527019642795};\\\", \\\"{x:1414,y:450,t:1527019642812};\\\", \\\"{x:1414,y:449,t:1527019642828};\\\", \\\"{x:1414,y:448,t:1527019642845};\\\", \\\"{x:1413,y:447,t:1527019642862};\\\", \\\"{x:1413,y:446,t:1527019642880};\\\", \\\"{x:1413,y:445,t:1527019642895};\\\", \\\"{x:1413,y:438,t:1527019642912};\\\", \\\"{x:1413,y:435,t:1527019642928};\\\", \\\"{x:1413,y:434,t:1527019642944};\\\", \\\"{x:1411,y:433,t:1527019643176};\\\", \\\"{x:1406,y:440,t:1527019643184};\\\", \\\"{x:1400,y:447,t:1527019643195};\\\", \\\"{x:1389,y:462,t:1527019643212};\\\", \\\"{x:1379,y:474,t:1527019643229};\\\", \\\"{x:1375,y:479,t:1527019643245};\\\", \\\"{x:1374,y:481,t:1527019643261};\\\", \\\"{x:1372,y:483,t:1527019643278};\\\", \\\"{x:1372,y:484,t:1527019643294};\\\", \\\"{x:1371,y:486,t:1527019643311};\\\", \\\"{x:1371,y:487,t:1527019643351};\\\", \\\"{x:1370,y:488,t:1527019643367};\\\", \\\"{x:1370,y:490,t:1527019643383};\\\", \\\"{x:1370,y:491,t:1527019643399};\\\", \\\"{x:1370,y:492,t:1527019643423};\\\", \\\"{x:1367,y:499,t:1527019643728};\\\", \\\"{x:1363,y:514,t:1527019643746};\\\", \\\"{x:1361,y:524,t:1527019643762};\\\", \\\"{x:1360,y:530,t:1527019643779};\\\", \\\"{x:1358,y:536,t:1527019643796};\\\", \\\"{x:1357,y:540,t:1527019643812};\\\", \\\"{x:1355,y:549,t:1527019643830};\\\", \\\"{x:1352,y:558,t:1527019643847};\\\", \\\"{x:1350,y:562,t:1527019643862};\\\", \\\"{x:1349,y:564,t:1527019643879};\\\", \\\"{x:1348,y:568,t:1527019643895};\\\", \\\"{x:1347,y:571,t:1527019643912};\\\", \\\"{x:1346,y:572,t:1527019644344};\\\", \\\"{x:1346,y:575,t:1527019644352};\\\", \\\"{x:1345,y:579,t:1527019644363};\\\", \\\"{x:1342,y:584,t:1527019644379};\\\", \\\"{x:1340,y:587,t:1527019644396};\\\", \\\"{x:1339,y:588,t:1527019644413};\\\", \\\"{x:1339,y:589,t:1527019644430};\\\", \\\"{x:1338,y:589,t:1527019644446};\\\", \\\"{x:1338,y:590,t:1527019644463};\\\", \\\"{x:1336,y:593,t:1527019644480};\\\", \\\"{x:1336,y:594,t:1527019644496};\\\", \\\"{x:1335,y:595,t:1527019644513};\\\", \\\"{x:1335,y:596,t:1527019644530};\\\", \\\"{x:1332,y:598,t:1527019644546};\\\", \\\"{x:1331,y:603,t:1527019644563};\\\", \\\"{x:1329,y:607,t:1527019644580};\\\", \\\"{x:1328,y:610,t:1527019644596};\\\", \\\"{x:1327,y:612,t:1527019644613};\\\", \\\"{x:1326,y:613,t:1527019644705};\\\", \\\"{x:1327,y:610,t:1527019644800};\\\", \\\"{x:1346,y:591,t:1527019644813};\\\", \\\"{x:1384,y:559,t:1527019644830};\\\", \\\"{x:1428,y:524,t:1527019644846};\\\", \\\"{x:1476,y:498,t:1527019644863};\\\", \\\"{x:1525,y:478,t:1527019644880};\\\", \\\"{x:1542,y:470,t:1527019644896};\\\", \\\"{x:1549,y:468,t:1527019644913};\\\", \\\"{x:1549,y:474,t:1527019645007};\\\", \\\"{x:1546,y:484,t:1527019645015};\\\", \\\"{x:1544,y:492,t:1527019645029};\\\", \\\"{x:1540,y:506,t:1527019645046};\\\", \\\"{x:1539,y:513,t:1527019645062};\\\", \\\"{x:1538,y:515,t:1527019645080};\\\", \\\"{x:1538,y:516,t:1527019645119};\\\", \\\"{x:1542,y:516,t:1527019645129};\\\", \\\"{x:1550,y:510,t:1527019645147};\\\", \\\"{x:1557,y:502,t:1527019645163};\\\", \\\"{x:1563,y:496,t:1527019645180};\\\", \\\"{x:1575,y:488,t:1527019645197};\\\", \\\"{x:1590,y:478,t:1527019645213};\\\", \\\"{x:1603,y:469,t:1527019645230};\\\", \\\"{x:1611,y:463,t:1527019645247};\\\", \\\"{x:1613,y:460,t:1527019645263};\\\", \\\"{x:1614,y:460,t:1527019645280};\\\", \\\"{x:1616,y:458,t:1527019645297};\\\", \\\"{x:1620,y:453,t:1527019645313};\\\", \\\"{x:1625,y:444,t:1527019645330};\\\", \\\"{x:1626,y:441,t:1527019645347};\\\", \\\"{x:1627,y:437,t:1527019645363};\\\", \\\"{x:1628,y:437,t:1527019645380};\\\", \\\"{x:1627,y:438,t:1527019645473};\\\", \\\"{x:1624,y:444,t:1527019645480};\\\", \\\"{x:1616,y:461,t:1527019645497};\\\", \\\"{x:1609,y:480,t:1527019645514};\\\", \\\"{x:1604,y:492,t:1527019645530};\\\", \\\"{x:1603,y:493,t:1527019645547};\\\", \\\"{x:1602,y:495,t:1527019645600};\\\", \\\"{x:1601,y:497,t:1527019645614};\\\", \\\"{x:1598,y:502,t:1527019645630};\\\", \\\"{x:1596,y:505,t:1527019645647};\\\", \\\"{x:1595,y:507,t:1527019645985};\\\", \\\"{x:1595,y:508,t:1527019645998};\\\", \\\"{x:1591,y:512,t:1527019646014};\\\", \\\"{x:1587,y:516,t:1527019646031};\\\", \\\"{x:1583,y:520,t:1527019646047};\\\", \\\"{x:1579,y:524,t:1527019646064};\\\", \\\"{x:1577,y:527,t:1527019646080};\\\", \\\"{x:1573,y:533,t:1527019646097};\\\", \\\"{x:1568,y:540,t:1527019646114};\\\", \\\"{x:1563,y:548,t:1527019646131};\\\", \\\"{x:1560,y:553,t:1527019646147};\\\", \\\"{x:1559,y:556,t:1527019646164};\\\", \\\"{x:1558,y:558,t:1527019646181};\\\", \\\"{x:1557,y:559,t:1527019646197};\\\", \\\"{x:1557,y:560,t:1527019646215};\\\", \\\"{x:1556,y:562,t:1527019646231};\\\", \\\"{x:1555,y:565,t:1527019646247};\\\", \\\"{x:1554,y:566,t:1527019646264};\\\", \\\"{x:1554,y:567,t:1527019646281};\\\", \\\"{x:1552,y:568,t:1527019646623};\\\", \\\"{x:1552,y:569,t:1527019646631};\\\", \\\"{x:1549,y:573,t:1527019646647};\\\", \\\"{x:1546,y:578,t:1527019646665};\\\", \\\"{x:1540,y:585,t:1527019646681};\\\", \\\"{x:1535,y:594,t:1527019646698};\\\", \\\"{x:1524,y:608,t:1527019646715};\\\", \\\"{x:1516,y:619,t:1527019646731};\\\", \\\"{x:1512,y:626,t:1527019646748};\\\", \\\"{x:1508,y:634,t:1527019646765};\\\", \\\"{x:1507,y:636,t:1527019646781};\\\", \\\"{x:1506,y:639,t:1527019646798};\\\", \\\"{x:1506,y:640,t:1527019647257};\\\", \\\"{x:1501,y:648,t:1527019647265};\\\", \\\"{x:1494,y:664,t:1527019647282};\\\", \\\"{x:1486,y:679,t:1527019647298};\\\", \\\"{x:1483,y:684,t:1527019647315};\\\", \\\"{x:1482,y:688,t:1527019647332};\\\", \\\"{x:1482,y:689,t:1527019647348};\\\", \\\"{x:1480,y:692,t:1527019647365};\\\", \\\"{x:1478,y:697,t:1527019647382};\\\", \\\"{x:1474,y:704,t:1527019647398};\\\", \\\"{x:1471,y:709,t:1527019647415};\\\", \\\"{x:1471,y:710,t:1527019647432};\\\", \\\"{x:1468,y:716,t:1527019647936};\\\", \\\"{x:1467,y:719,t:1527019647949};\\\", \\\"{x:1466,y:723,t:1527019647965};\\\", \\\"{x:1464,y:727,t:1527019647982};\\\", \\\"{x:1463,y:732,t:1527019647999};\\\", \\\"{x:1460,y:740,t:1527019648016};\\\", \\\"{x:1459,y:742,t:1527019648032};\\\", \\\"{x:1458,y:745,t:1527019648208};\\\", \\\"{x:1456,y:748,t:1527019648215};\\\", \\\"{x:1452,y:756,t:1527019648232};\\\", \\\"{x:1450,y:759,t:1527019648249};\\\", \\\"{x:1447,y:763,t:1527019648266};\\\", \\\"{x:1444,y:769,t:1527019648283};\\\", \\\"{x:1440,y:774,t:1527019648299};\\\", \\\"{x:1439,y:776,t:1527019648317};\\\", \\\"{x:1439,y:779,t:1527019648721};\\\", \\\"{x:1439,y:782,t:1527019648733};\\\", \\\"{x:1439,y:788,t:1527019648749};\\\", \\\"{x:1438,y:792,t:1527019648766};\\\", \\\"{x:1436,y:795,t:1527019648783};\\\", \\\"{x:1436,y:797,t:1527019648799};\\\", \\\"{x:1434,y:807,t:1527019648816};\\\", \\\"{x:1432,y:811,t:1527019648833};\\\", \\\"{x:1432,y:813,t:1527019648850};\\\", \\\"{x:1432,y:814,t:1527019648867};\\\", \\\"{x:1431,y:814,t:1527019648883};\\\", \\\"{x:1431,y:815,t:1527019648927};\\\", \\\"{x:1431,y:817,t:1527019648943};\\\", \\\"{x:1429,y:818,t:1527019648951};\\\", \\\"{x:1428,y:821,t:1527019648966};\\\", \\\"{x:1425,y:824,t:1527019648982};\\\", \\\"{x:1423,y:829,t:1527019648999};\\\", \\\"{x:1422,y:829,t:1527019649064};\\\", \\\"{x:1422,y:830,t:1527019649072};\\\", \\\"{x:1420,y:830,t:1527019649087};\\\", \\\"{x:1420,y:831,t:1527019649104};\\\", \\\"{x:1420,y:832,t:1527019649288};\\\", \\\"{x:1418,y:834,t:1527019649301};\\\", \\\"{x:1416,y:836,t:1527019649317};\\\", \\\"{x:1412,y:843,t:1527019649333};\\\", \\\"{x:1403,y:854,t:1527019649350};\\\", \\\"{x:1393,y:874,t:1527019649368};\\\", \\\"{x:1390,y:877,t:1527019649383};\\\", \\\"{x:1387,y:881,t:1527019649399};\\\", \\\"{x:1387,y:882,t:1527019649424};\\\", \\\"{x:1387,y:883,t:1527019649433};\\\", \\\"{x:1387,y:887,t:1527019649545};\\\", \\\"{x:1386,y:894,t:1527019649552};\\\", \\\"{x:1385,y:900,t:1527019649567};\\\", \\\"{x:1382,y:907,t:1527019649583};\\\", \\\"{x:1381,y:908,t:1527019649600};\\\", \\\"{x:1380,y:909,t:1527019649648};\\\", \\\"{x:1378,y:912,t:1527019650935};\\\", \\\"{x:1377,y:916,t:1527019650951};\\\", \\\"{x:1369,y:927,t:1527019650967};\\\", \\\"{x:1368,y:930,t:1527019650984};\\\", \\\"{x:1367,y:931,t:1527019651007};\\\", \\\"{x:1366,y:933,t:1527019651023};\\\", \\\"{x:1366,y:935,t:1527019651034};\\\", \\\"{x:1363,y:938,t:1527019651051};\\\", \\\"{x:1362,y:940,t:1527019651068};\\\", \\\"{x:1361,y:943,t:1527019651085};\\\", \\\"{x:1361,y:944,t:1527019651101};\\\", \\\"{x:1360,y:945,t:1527019651118};\\\", \\\"{x:1359,y:947,t:1527019651136};\\\", \\\"{x:1358,y:949,t:1527019651152};\\\", \\\"{x:1356,y:951,t:1527019651168};\\\", \\\"{x:1355,y:953,t:1527019651185};\\\", \\\"{x:1353,y:954,t:1527019651201};\\\", \\\"{x:1353,y:955,t:1527019651218};\\\", \\\"{x:1351,y:956,t:1527019651235};\\\", \\\"{x:1350,y:958,t:1527019651251};\\\", \\\"{x:1349,y:959,t:1527019651268};\\\", \\\"{x:1348,y:960,t:1527019651285};\\\", \\\"{x:1346,y:962,t:1527019651301};\\\", \\\"{x:1346,y:963,t:1527019651319};\\\", \\\"{x:1345,y:963,t:1527019651376};\\\", \\\"{x:1343,y:963,t:1527019659104};\\\", \\\"{x:1341,y:963,t:1527019659112};\\\", \\\"{x:1340,y:963,t:1527019659128};\\\", \\\"{x:1338,y:963,t:1527019659944};\\\", \\\"{x:1336,y:963,t:1527019659959};\\\", \\\"{x:1332,y:948,t:1527019659976};\\\", \\\"{x:1330,y:941,t:1527019659992};\\\", \\\"{x:1328,y:932,t:1527019660008};\\\", \\\"{x:1327,y:926,t:1527019660026};\\\", \\\"{x:1326,y:923,t:1527019660042};\\\", \\\"{x:1326,y:920,t:1527019660059};\\\", \\\"{x:1326,y:919,t:1527019660076};\\\", \\\"{x:1325,y:916,t:1527019660092};\\\", \\\"{x:1324,y:914,t:1527019660108};\\\", \\\"{x:1323,y:913,t:1527019660126};\\\", \\\"{x:1323,y:912,t:1527019660142};\\\", \\\"{x:1323,y:911,t:1527019660159};\\\", \\\"{x:1323,y:908,t:1527019660176};\\\", \\\"{x:1322,y:907,t:1527019660191};\\\", \\\"{x:1322,y:906,t:1527019660209};\\\", \\\"{x:1321,y:905,t:1527019660225};\\\", \\\"{x:1321,y:904,t:1527019660271};\\\", \\\"{x:1321,y:901,t:1527019660280};\\\", \\\"{x:1319,y:899,t:1527019660296};\\\", \\\"{x:1319,y:897,t:1527019660309};\\\", \\\"{x:1319,y:891,t:1527019660326};\\\", \\\"{x:1318,y:886,t:1527019660343};\\\", \\\"{x:1318,y:876,t:1527019660359};\\\", \\\"{x:1320,y:855,t:1527019660376};\\\", \\\"{x:1325,y:841,t:1527019660392};\\\", \\\"{x:1331,y:829,t:1527019660408};\\\", \\\"{x:1335,y:819,t:1527019660426};\\\", \\\"{x:1339,y:811,t:1527019660443};\\\", \\\"{x:1340,y:809,t:1527019660459};\\\", \\\"{x:1340,y:807,t:1527019660475};\\\", \\\"{x:1341,y:807,t:1527019660492};\\\", \\\"{x:1341,y:806,t:1527019660512};\\\", \\\"{x:1342,y:805,t:1527019660526};\\\", \\\"{x:1344,y:802,t:1527019660542};\\\", \\\"{x:1348,y:796,t:1527019660559};\\\", \\\"{x:1356,y:786,t:1527019660575};\\\", \\\"{x:1356,y:783,t:1527019660592};\\\", \\\"{x:1359,y:780,t:1527019660608};\\\", \\\"{x:1361,y:777,t:1527019660625};\\\", \\\"{x:1366,y:775,t:1527019660643};\\\", \\\"{x:1373,y:770,t:1527019660658};\\\", \\\"{x:1379,y:767,t:1527019660676};\\\", \\\"{x:1383,y:766,t:1527019660692};\\\", \\\"{x:1383,y:765,t:1527019660709};\\\", \\\"{x:1384,y:765,t:1527019660725};\\\", \\\"{x:1383,y:765,t:1527019660968};\\\", \\\"{x:1381,y:765,t:1527019660976};\\\", \\\"{x:1378,y:765,t:1527019660993};\\\", \\\"{x:1376,y:765,t:1527019661009};\\\", \\\"{x:1375,y:765,t:1527019661027};\\\", \\\"{x:1374,y:765,t:1527019663120};\\\", \\\"{x:1374,y:766,t:1527019663990};\\\", \\\"{x:1372,y:767,t:1527019664624};\\\", \\\"{x:1368,y:772,t:1527019664632};\\\", \\\"{x:1365,y:777,t:1527019664646};\\\", \\\"{x:1357,y:795,t:1527019664662};\\\", \\\"{x:1346,y:819,t:1527019664679};\\\", \\\"{x:1332,y:880,t:1527019664695};\\\", \\\"{x:1327,y:948,t:1527019664713};\\\", \\\"{x:1327,y:1010,t:1527019664729};\\\", \\\"{x:1327,y:1042,t:1527019664745};\\\", \\\"{x:1327,y:1057,t:1527019664763};\\\", \\\"{x:1327,y:1062,t:1527019664779};\\\", \\\"{x:1327,y:1065,t:1527019664795};\\\", \\\"{x:1326,y:1066,t:1527019664813};\\\", \\\"{x:1326,y:1063,t:1527019664943};\\\", \\\"{x:1326,y:1053,t:1527019664951};\\\", \\\"{x:1326,y:1044,t:1527019664962};\\\", \\\"{x:1326,y:1031,t:1527019664978};\\\", \\\"{x:1330,y:1019,t:1527019664995};\\\", \\\"{x:1333,y:1011,t:1527019665012};\\\", \\\"{x:1336,y:1002,t:1527019665028};\\\", \\\"{x:1340,y:996,t:1527019665045};\\\", \\\"{x:1340,y:993,t:1527019665062};\\\", \\\"{x:1342,y:990,t:1527019665078};\\\", \\\"{x:1344,y:985,t:1527019665095};\\\", \\\"{x:1347,y:981,t:1527019665112};\\\", \\\"{x:1347,y:978,t:1527019665128};\\\", \\\"{x:1348,y:977,t:1527019665146};\\\", \\\"{x:1349,y:975,t:1527019665162};\\\", \\\"{x:1350,y:973,t:1527019665180};\\\", \\\"{x:1351,y:972,t:1527019665196};\\\", \\\"{x:1351,y:970,t:1527019665212};\\\", \\\"{x:1351,y:969,t:1527019665255};\\\", \\\"{x:1351,y:968,t:1527019665337};\\\", \\\"{x:1351,y:967,t:1527019665352};\\\", \\\"{x:1351,y:966,t:1527019665456};\\\", \\\"{x:1351,y:965,t:1527019665470};\\\", \\\"{x:1351,y:964,t:1527019665478};\\\", \\\"{x:1351,y:963,t:1527019665495};\\\", \\\"{x:1351,y:962,t:1527019665513};\\\", \\\"{x:1351,y:961,t:1527019665529};\\\", \\\"{x:1351,y:958,t:1527019665546};\\\", \\\"{x:1351,y:954,t:1527019665562};\\\", \\\"{x:1353,y:946,t:1527019665579};\\\", \\\"{x:1354,y:941,t:1527019665596};\\\", \\\"{x:1355,y:934,t:1527019665612};\\\", \\\"{x:1357,y:926,t:1527019665630};\\\", \\\"{x:1364,y:910,t:1527019665646};\\\", \\\"{x:1377,y:884,t:1527019665662};\\\", \\\"{x:1404,y:819,t:1527019665679};\\\", \\\"{x:1417,y:786,t:1527019665697};\\\", \\\"{x:1431,y:752,t:1527019665713};\\\", \\\"{x:1443,y:723,t:1527019665729};\\\", \\\"{x:1457,y:688,t:1527019665747};\\\", \\\"{x:1466,y:642,t:1527019665763};\\\", \\\"{x:1469,y:622,t:1527019665780};\\\", \\\"{x:1471,y:608,t:1527019665797};\\\", \\\"{x:1474,y:599,t:1527019665813};\\\", \\\"{x:1476,y:593,t:1527019665830};\\\", \\\"{x:1480,y:583,t:1527019665847};\\\", \\\"{x:1484,y:575,t:1527019665863};\\\", \\\"{x:1485,y:571,t:1527019665880};\\\", \\\"{x:1486,y:570,t:1527019665897};\\\", \\\"{x:1486,y:571,t:1527019665992};\\\", \\\"{x:1486,y:577,t:1527019665999};\\\", \\\"{x:1486,y:582,t:1527019666014};\\\", \\\"{x:1486,y:590,t:1527019666029};\\\", \\\"{x:1486,y:591,t:1527019666047};\\\", \\\"{x:1486,y:592,t:1527019666224};\\\", \\\"{x:1477,y:599,t:1527019666232};\\\", \\\"{x:1455,y:611,t:1527019666247};\\\", \\\"{x:1322,y:666,t:1527019666264};\\\", \\\"{x:1196,y:715,t:1527019666280};\\\", \\\"{x:1047,y:752,t:1527019666297};\\\", \\\"{x:906,y:771,t:1527019666314};\\\", \\\"{x:773,y:774,t:1527019666330};\\\", \\\"{x:656,y:773,t:1527019666347};\\\", \\\"{x:538,y:744,t:1527019666364};\\\", \\\"{x:445,y:706,t:1527019666381};\\\", \\\"{x:382,y:672,t:1527019666397};\\\", \\\"{x:352,y:652,t:1527019666413};\\\", \\\"{x:339,y:640,t:1527019666429};\\\", \\\"{x:331,y:619,t:1527019666445};\\\", \\\"{x:311,y:567,t:1527019666464};\\\", \\\"{x:301,y:535,t:1527019666480};\\\", \\\"{x:299,y:523,t:1527019666497};\\\", \\\"{x:297,y:514,t:1527019666513};\\\", \\\"{x:297,y:502,t:1527019666530};\\\", \\\"{x:297,y:487,t:1527019666548};\\\", \\\"{x:297,y:476,t:1527019666563};\\\", \\\"{x:297,y:469,t:1527019666580};\\\", \\\"{x:299,y:466,t:1527019666597};\\\", \\\"{x:308,y:466,t:1527019666614};\\\", \\\"{x:319,y:466,t:1527019666631};\\\", \\\"{x:337,y:470,t:1527019666647};\\\", \\\"{x:342,y:474,t:1527019666665};\\\", \\\"{x:343,y:474,t:1527019666680};\\\", \\\"{x:344,y:476,t:1527019666711};\\\", \\\"{x:344,y:480,t:1527019666719};\\\", \\\"{x:343,y:486,t:1527019666730};\\\", \\\"{x:333,y:504,t:1527019666747};\\\", \\\"{x:322,y:524,t:1527019666765};\\\", \\\"{x:315,y:540,t:1527019666781};\\\", \\\"{x:311,y:549,t:1527019666798};\\\", \\\"{x:308,y:559,t:1527019666814};\\\", \\\"{x:306,y:567,t:1527019666831};\\\", \\\"{x:306,y:572,t:1527019666847};\\\", \\\"{x:303,y:574,t:1527019666936};\\\", \\\"{x:302,y:575,t:1527019666949};\\\", \\\"{x:299,y:576,t:1527019666965};\\\", \\\"{x:295,y:577,t:1527019666981};\\\", \\\"{x:290,y:580,t:1527019666997};\\\", \\\"{x:280,y:582,t:1527019667015};\\\", \\\"{x:264,y:584,t:1527019667032};\\\", \\\"{x:258,y:584,t:1527019667047};\\\", \\\"{x:255,y:584,t:1527019667065};\\\", \\\"{x:254,y:584,t:1527019667080};\\\", \\\"{x:251,y:584,t:1527019667097};\\\", \\\"{x:248,y:585,t:1527019667114};\\\", \\\"{x:247,y:586,t:1527019667130};\\\", \\\"{x:245,y:588,t:1527019667148};\\\", \\\"{x:244,y:590,t:1527019667164};\\\", \\\"{x:243,y:590,t:1527019667181};\\\", \\\"{x:243,y:591,t:1527019667272};\\\", \\\"{x:249,y:591,t:1527019667282};\\\", \\\"{x:269,y:600,t:1527019667298};\\\", \\\"{x:291,y:602,t:1527019667316};\\\", \\\"{x:316,y:596,t:1527019667331};\\\", \\\"{x:331,y:590,t:1527019667347};\\\", \\\"{x:339,y:585,t:1527019667364};\\\", \\\"{x:345,y:584,t:1527019667381};\\\", \\\"{x:347,y:582,t:1527019667399};\\\", \\\"{x:349,y:581,t:1527019667414};\\\", \\\"{x:351,y:581,t:1527019667431};\\\", \\\"{x:354,y:580,t:1527019667448};\\\", \\\"{x:355,y:579,t:1527019667464};\\\", \\\"{x:359,y:582,t:1527019667609};\\\", \\\"{x:363,y:584,t:1527019667615};\\\", \\\"{x:387,y:599,t:1527019667631};\\\", \\\"{x:409,y:612,t:1527019667648};\\\", \\\"{x:420,y:618,t:1527019667665};\\\", \\\"{x:423,y:620,t:1527019667682};\\\", \\\"{x:424,y:620,t:1527019667847};\\\", \\\"{x:423,y:616,t:1527019667855};\\\", \\\"{x:422,y:615,t:1527019667865};\\\", \\\"{x:421,y:612,t:1527019667882};\\\", \\\"{x:420,y:610,t:1527019667899};\\\", \\\"{x:419,y:609,t:1527019667915};\\\", \\\"{x:419,y:608,t:1527019667931};\\\", \\\"{x:423,y:608,t:1527019668479};\\\", \\\"{x:453,y:613,t:1527019668489};\\\", \\\"{x:494,y:621,t:1527019668500};\\\", \\\"{x:584,y:624,t:1527019668515};\\\", \\\"{x:599,y:624,t:1527019668532};\\\", \\\"{x:599,y:627,t:1527019668848};\\\", \\\"{x:566,y:627,t:1527019668866};\\\", \\\"{x:530,y:627,t:1527019668882};\\\", \\\"{x:503,y:622,t:1527019668898};\\\", \\\"{x:485,y:615,t:1527019668916};\\\", \\\"{x:470,y:609,t:1527019668933};\\\", \\\"{x:458,y:604,t:1527019668949};\\\", \\\"{x:444,y:599,t:1527019668966};\\\", \\\"{x:433,y:595,t:1527019668982};\\\", \\\"{x:430,y:594,t:1527019669000};\\\", \\\"{x:429,y:594,t:1527019669080};\\\", \\\"{x:425,y:595,t:1527019669088};\\\", \\\"{x:424,y:599,t:1527019669100};\\\", \\\"{x:410,y:604,t:1527019669117};\\\", \\\"{x:393,y:604,t:1527019669133};\\\", \\\"{x:382,y:604,t:1527019669149};\\\", \\\"{x:377,y:604,t:1527019669165};\\\", \\\"{x:376,y:604,t:1527019669183};\\\", \\\"{x:375,y:604,t:1527019669200};\\\", \\\"{x:373,y:603,t:1527019669241};\\\", \\\"{x:371,y:601,t:1527019669250};\\\", \\\"{x:371,y:600,t:1527019669399};\\\", \\\"{x:374,y:600,t:1527019669416};\\\", \\\"{x:375,y:600,t:1527019669433};\\\", \\\"{x:377,y:600,t:1527019669616};\\\", \\\"{x:379,y:600,t:1527019669633};\\\", \\\"{x:381,y:600,t:1527019669650};\\\", \\\"{x:382,y:600,t:1527019669666};\\\", \\\"{x:385,y:600,t:1527019669682};\\\", \\\"{x:391,y:597,t:1527019669700};\\\", \\\"{x:393,y:597,t:1527019669717};\\\", \\\"{x:393,y:596,t:1527019669817};\\\", \\\"{x:392,y:594,t:1527019669833};\\\", \\\"{x:391,y:593,t:1527019669849};\\\", \\\"{x:390,y:593,t:1527019669935};\\\", \\\"{x:389,y:593,t:1527019669959};\\\", \\\"{x:389,y:592,t:1527019669983};\\\", \\\"{x:389,y:592,t:1527019670020};\\\", \\\"{x:389,y:593,t:1527019670034};\\\", \\\"{x:393,y:595,t:1527019670049};\\\", \\\"{x:396,y:596,t:1527019670071};\\\", \\\"{x:397,y:596,t:1527019670087};\\\", \\\"{x:398,y:596,t:1527019670100};\\\", \\\"{x:403,y:596,t:1527019670116};\\\", \\\"{x:405,y:596,t:1527019670134};\\\", \\\"{x:413,y:596,t:1527019670150};\\\", \\\"{x:434,y:604,t:1527019670167};\\\", \\\"{x:489,y:627,t:1527019670184};\\\", \\\"{x:550,y:652,t:1527019670200};\\\", \\\"{x:591,y:670,t:1527019670216};\\\", \\\"{x:604,y:677,t:1527019670233};\\\", \\\"{x:614,y:685,t:1527019670250};\\\", \\\"{x:621,y:702,t:1527019670267};\\\", \\\"{x:626,y:721,t:1527019670283};\\\", \\\"{x:631,y:737,t:1527019670300};\\\", \\\"{x:634,y:748,t:1527019670316};\\\", \\\"{x:639,y:757,t:1527019670333};\\\", \\\"{x:643,y:765,t:1527019670350};\\\", \\\"{x:644,y:766,t:1527019670367};\\\", \\\"{x:643,y:767,t:1527019670423};\\\", \\\"{x:642,y:767,t:1527019670433};\\\", \\\"{x:640,y:767,t:1527019670451};\\\", \\\"{x:640,y:766,t:1527019670560};\\\", \\\"{x:651,y:761,t:1527019670566};\\\", \\\"{x:715,y:741,t:1527019670583};\\\", \\\"{x:826,y:725,t:1527019670601};\\\", \\\"{x:915,y:696,t:1527019670618};\\\", \\\"{x:993,y:658,t:1527019670634};\\\", \\\"{x:1109,y:610,t:1527019670651};\\\", \\\"{x:1257,y:545,t:1527019670668};\\\", \\\"{x:1434,y:470,t:1527019670685};\\\", \\\"{x:1645,y:395,t:1527019670701};\\\", \\\"{x:1837,y:316,t:1527019670718};\\\", \\\"{x:1882,y:233,t:1527019670872};\\\", \\\"{x:1847,y:251,t:1527019670884};\\\", \\\"{x:1795,y:282,t:1527019670901};\\\", \\\"{x:1759,y:302,t:1527019670918};\\\", \\\"{x:1742,y:314,t:1527019670934};\\\", \\\"{x:1727,y:326,t:1527019670952};\\\", \\\"{x:1722,y:335,t:1527019670967};\\\", \\\"{x:1717,y:345,t:1527019670985};\\\", \\\"{x:1711,y:353,t:1527019671001};\\\", \\\"{x:1707,y:360,t:1527019671018};\\\", \\\"{x:1706,y:361,t:1527019671035};\\\", \\\"{x:1706,y:362,t:1527019671063};\\\", \\\"{x:1705,y:371,t:1527019671072};\\\", \\\"{x:1702,y:382,t:1527019671084};\\\", \\\"{x:1690,y:410,t:1527019671100};\\\", \\\"{x:1668,y:438,t:1527019671118};\\\", \\\"{x:1633,y:467,t:1527019671136};\\\", \\\"{x:1621,y:473,t:1527019671151};\\\", \\\"{x:1590,y:483,t:1527019671167};\\\", \\\"{x:1574,y:486,t:1527019671186};\\\", \\\"{x:1567,y:486,t:1527019671201};\\\", \\\"{x:1566,y:486,t:1527019671232};\\\", \\\"{x:1566,y:481,t:1527019671239};\\\", \\\"{x:1567,y:473,t:1527019671251};\\\", \\\"{x:1568,y:471,t:1527019671269};\\\", \\\"{x:1567,y:471,t:1527019671344};\\\", \\\"{x:1564,y:474,t:1527019671352};\\\", \\\"{x:1554,y:498,t:1527019671368};\\\", \\\"{x:1547,y:523,t:1527019671385};\\\", \\\"{x:1536,y:548,t:1527019671402};\\\", \\\"{x:1521,y:574,t:1527019671418};\\\", \\\"{x:1509,y:597,t:1527019671435};\\\", \\\"{x:1488,y:634,t:1527019671453};\\\", \\\"{x:1469,y:667,t:1527019671468};\\\", \\\"{x:1458,y:688,t:1527019671484};\\\", \\\"{x:1455,y:694,t:1527019671502};\\\", \\\"{x:1455,y:704,t:1527019672304};\\\", \\\"{x:1452,y:734,t:1527019672319};\\\", \\\"{x:1447,y:757,t:1527019672336};\\\", \\\"{x:1445,y:778,t:1527019672352};\\\", \\\"{x:1441,y:801,t:1527019672369};\\\", \\\"{x:1441,y:830,t:1527019672386};\\\", \\\"{x:1441,y:856,t:1527019672403};\\\", \\\"{x:1439,y:878,t:1527019672420};\\\", \\\"{x:1434,y:891,t:1527019672436};\\\", \\\"{x:1425,y:906,t:1527019672452};\\\", \\\"{x:1418,y:914,t:1527019672470};\\\", \\\"{x:1412,y:920,t:1527019672486};\\\", \\\"{x:1401,y:928,t:1527019672503};\\\", \\\"{x:1394,y:933,t:1527019672519};\\\", \\\"{x:1383,y:939,t:1527019672535};\\\", \\\"{x:1369,y:942,t:1527019672554};\\\", \\\"{x:1356,y:945,t:1527019672570};\\\", \\\"{x:1344,y:953,t:1527019672586};\\\", \\\"{x:1333,y:960,t:1527019672603};\\\", \\\"{x:1323,y:967,t:1527019672619};\\\", \\\"{x:1317,y:971,t:1527019672636};\\\", \\\"{x:1312,y:974,t:1527019672653};\\\", \\\"{x:1307,y:980,t:1527019672669};\\\", \\\"{x:1306,y:981,t:1527019672686};\\\", \\\"{x:1305,y:981,t:1527019673032};\\\", \\\"{x:1303,y:981,t:1527019673040};\\\", \\\"{x:1299,y:979,t:1527019673053};\\\", \\\"{x:1288,y:972,t:1527019673071};\\\", \\\"{x:1263,y:961,t:1527019673086};\\\", \\\"{x:1225,y:942,t:1527019673104};\\\", \\\"{x:1196,y:932,t:1527019673120};\\\", \\\"{x:1174,y:927,t:1527019673136};\\\", \\\"{x:1150,y:921,t:1527019673153};\\\", \\\"{x:1123,y:919,t:1527019673170};\\\", \\\"{x:1073,y:913,t:1527019673186};\\\", \\\"{x:1018,y:913,t:1527019673203};\\\", \\\"{x:964,y:913,t:1527019673220};\\\", \\\"{x:939,y:913,t:1527019673237};\\\", \\\"{x:927,y:914,t:1527019673253};\\\", \\\"{x:923,y:914,t:1527019673270};\\\", \\\"{x:920,y:914,t:1527019673287};\\\", \\\"{x:916,y:913,t:1527019673304};\\\", \\\"{x:912,y:911,t:1527019673320};\\\", \\\"{x:904,y:909,t:1527019673337};\\\", \\\"{x:884,y:904,t:1527019673353};\\\", \\\"{x:857,y:893,t:1527019673370};\\\", \\\"{x:808,y:872,t:1527019673387};\\\", \\\"{x:753,y:859,t:1527019673403};\\\", \\\"{x:703,y:851,t:1527019673420};\\\", \\\"{x:657,y:844,t:1527019673437};\\\", \\\"{x:607,y:830,t:1527019673453};\\\", \\\"{x:562,y:815,t:1527019673470};\\\", \\\"{x:496,y:795,t:1527019673487};\\\", \\\"{x:475,y:789,t:1527019673503};\\\", \\\"{x:465,y:785,t:1527019673520};\\\", \\\"{x:449,y:779,t:1527019673537};\\\", \\\"{x:426,y:769,t:1527019673553};\\\", \\\"{x:402,y:755,t:1527019673570};\\\", \\\"{x:391,y:747,t:1527019673587};\\\", \\\"{x:390,y:746,t:1527019673603};\\\", \\\"{x:394,y:742,t:1527019673620};\\\", \\\"{x:409,y:736,t:1527019673637};\\\", \\\"{x:424,y:727,t:1527019673654};\\\", \\\"{x:435,y:719,t:1527019673670};\\\", \\\"{x:441,y:716,t:1527019673687};\\\", \\\"{x:443,y:716,t:1527019673704};\\\", \\\"{x:444,y:716,t:1527019673793};\\\", \\\"{x:445,y:716,t:1527019673804};\\\", \\\"{x:446,y:715,t:1527019673918};\\\", \\\"{x:448,y:713,t:1527019673926};\\\", \\\"{x:453,y:710,t:1527019673937};\\\", \\\"{x:465,y:705,t:1527019673953};\\\", \\\"{x:477,y:700,t:1527019673970};\\\", \\\"{x:482,y:699,t:1527019673986};\\\", \\\"{x:485,y:698,t:1527019674003};\\\", \\\"{x:486,y:698,t:1527019674071};\\\", \\\"{x:487,y:698,t:1527019674086};\\\", \\\"{x:487,y:698,t:1527019674209};\\\", \\\"{x:488,y:698,t:1527019674568};\\\", \\\"{x:490,y:705,t:1527019674576};\\\", \\\"{x:491,y:710,t:1527019674586};\\\", \\\"{x:494,y:717,t:1527019674604};\\\", \\\"{x:494,y:721,t:1527019674621};\\\", \\\"{x:497,y:726,t:1527019674636};\\\", \\\"{x:499,y:731,t:1527019674653};\\\", \\\"{x:502,y:740,t:1527019674671};\\\", \\\"{x:503,y:741,t:1527019674687};\\\", \\\"{x:505,y:741,t:1527019674783};\\\", \\\"{x:505,y:740,t:1527019674791};\\\", \\\"{x:507,y:738,t:1527019674804};\\\", \\\"{x:509,y:736,t:1527019674820};\\\", \\\"{x:513,y:733,t:1527019674838};\\\", \\\"{x:518,y:729,t:1527019674853};\\\", \\\"{x:521,y:723,t:1527019674871};\\\", \\\"{x:523,y:721,t:1527019674887};\\\", \\\"{x:524,y:721,t:1527019674936};\\\", \\\"{x:524,y:720,t:1527019676088};\\\", \\\"{x:526,y:719,t:1527019676120};\\\", \\\"{x:526,y:717,t:1527019676139};\\\", \\\"{x:527,y:716,t:1527019676157};\\\", \\\"{x:527,y:714,t:1527019676172};\\\", \\\"{x:527,y:713,t:1527019676188};\\\", \\\"{x:528,y:711,t:1527019676204};\\\", \\\"{x:529,y:709,t:1527019676221};\\\", \\\"{x:530,y:707,t:1527019676238};\\\", \\\"{x:531,y:705,t:1527019676254};\\\", \\\"{x:532,y:703,t:1527019676271};\\\", \\\"{x:533,y:701,t:1527019676287};\\\", \\\"{x:534,y:698,t:1527019676305};\\\", \\\"{x:534,y:697,t:1527019676322};\\\", \\\"{x:536,y:695,t:1527019676338};\\\", \\\"{x:536,y:694,t:1527019676354};\\\", \\\"{x:537,y:691,t:1527019676372};\\\", \\\"{x:537,y:690,t:1527019676389};\\\", \\\"{x:538,y:687,t:1527019676405};\\\", \\\"{x:540,y:685,t:1527019676422};\\\", \\\"{x:540,y:684,t:1527019676447};\\\" ] }, { \\\"rt\\\": 27944, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 7, \\\"time_elapsed\\\": 311586, \\\"internal_node_id\\\": \\\"0.0-5.0-2.0\\\", \\\"subject\\\": \\\"VT5BG\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"golf\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 3, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-E -E -09 AM-11 AM-F -F \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:543,y:678,t:1527019676629};\\\", \\\"{x:544,y:675,t:1527019676702};\\\", \\\"{x:547,y:672,t:1527019676710};\\\", \\\"{x:551,y:665,t:1527019676729};\\\", \\\"{x:655,y:574,t:1527019676827};\\\", \\\"{x:663,y:570,t:1527019676838};\\\", \\\"{x:673,y:562,t:1527019676855};\\\", \\\"{x:678,y:559,t:1527019676872};\\\", \\\"{x:681,y:556,t:1527019676888};\\\", \\\"{x:684,y:553,t:1527019676905};\\\", \\\"{x:685,y:552,t:1527019676921};\\\", \\\"{x:685,y:551,t:1527019676958};\\\", \\\"{x:685,y:550,t:1527019677686};\\\", \\\"{x:687,y:549,t:1527019677695};\\\", \\\"{x:687,y:548,t:1527019677706};\\\", \\\"{x:687,y:543,t:1527019677723};\\\", \\\"{x:687,y:541,t:1527019677739};\\\", \\\"{x:687,y:537,t:1527019677756};\\\", \\\"{x:687,y:535,t:1527019677773};\\\", \\\"{x:688,y:532,t:1527019677790};\\\", \\\"{x:688,y:531,t:1527019677806};\\\", \\\"{x:688,y:530,t:1527019677823};\\\", \\\"{x:688,y:528,t:1527019677856};\\\", \\\"{x:688,y:527,t:1527019677879};\\\", \\\"{x:688,y:526,t:1527019677895};\\\", \\\"{x:688,y:525,t:1527019677906};\\\", \\\"{x:688,y:522,t:1527019677924};\\\", \\\"{x:689,y:521,t:1527019677940};\\\", \\\"{x:689,y:519,t:1527019677956};\\\", \\\"{x:691,y:518,t:1527019677973};\\\", \\\"{x:692,y:513,t:1527019677990};\\\", \\\"{x:694,y:509,t:1527019678006};\\\", \\\"{x:696,y:506,t:1527019678024};\\\", \\\"{x:696,y:503,t:1527019678041};\\\", \\\"{x:699,y:500,t:1527019678056};\\\", \\\"{x:700,y:499,t:1527019678073};\\\", \\\"{x:705,y:496,t:1527019678090};\\\", \\\"{x:710,y:493,t:1527019678106};\\\", \\\"{x:722,y:488,t:1527019678123};\\\", \\\"{x:745,y:482,t:1527019678140};\\\", \\\"{x:784,y:467,t:1527019678156};\\\", \\\"{x:831,y:447,t:1527019678174};\\\", \\\"{x:842,y:441,t:1527019678190};\\\", \\\"{x:842,y:442,t:1527019679151};\\\", \\\"{x:843,y:442,t:1527019679175};\\\", \\\"{x:847,y:444,t:1527019679191};\\\", \\\"{x:851,y:447,t:1527019679208};\\\", \\\"{x:855,y:448,t:1527019679224};\\\", \\\"{x:862,y:448,t:1527019679242};\\\", \\\"{x:884,y:448,t:1527019679258};\\\", \\\"{x:937,y:448,t:1527019679274};\\\", \\\"{x:1021,y:447,t:1527019679292};\\\", \\\"{x:1118,y:434,t:1527019679309};\\\", \\\"{x:1213,y:430,t:1527019679324};\\\", \\\"{x:1308,y:428,t:1527019679342};\\\", \\\"{x:1380,y:428,t:1527019679358};\\\", \\\"{x:1474,y:428,t:1527019679374};\\\", \\\"{x:1655,y:450,t:1527019679391};\\\", \\\"{x:1771,y:479,t:1527019679408};\\\", \\\"{x:1860,y:494,t:1527019679424};\\\", \\\"{x:1914,y:503,t:1527019679441};\\\", \\\"{x:1908,y:543,t:1527019679760};\\\", \\\"{x:1863,y:549,t:1527019679776};\\\", \\\"{x:1823,y:556,t:1527019679791};\\\", \\\"{x:1794,y:559,t:1527019679808};\\\", \\\"{x:1771,y:562,t:1527019679825};\\\", \\\"{x:1749,y:560,t:1527019679841};\\\", \\\"{x:1726,y:556,t:1527019679858};\\\", \\\"{x:1703,y:549,t:1527019679875};\\\", \\\"{x:1689,y:549,t:1527019679891};\\\", \\\"{x:1683,y:554,t:1527019679908};\\\", \\\"{x:1681,y:558,t:1527019679926};\\\", \\\"{x:1680,y:560,t:1527019679941};\\\", \\\"{x:1679,y:563,t:1527019679958};\\\", \\\"{x:1678,y:566,t:1527019679974};\\\", \\\"{x:1676,y:569,t:1527019679991};\\\", \\\"{x:1674,y:577,t:1527019680008};\\\", \\\"{x:1672,y:585,t:1527019680025};\\\", \\\"{x:1669,y:587,t:1527019680041};\\\", \\\"{x:1668,y:589,t:1527019680058};\\\", \\\"{x:1667,y:589,t:1527019680076};\\\", \\\"{x:1667,y:590,t:1527019680122};\\\", \\\"{x:1667,y:591,t:1527019680208};\\\", \\\"{x:1667,y:592,t:1527019680279};\\\", \\\"{x:1666,y:594,t:1527019680295};\\\", \\\"{x:1661,y:596,t:1527019680309};\\\", \\\"{x:1651,y:599,t:1527019680326};\\\", \\\"{x:1643,y:599,t:1527019680343};\\\", \\\"{x:1641,y:599,t:1527019681071};\\\", \\\"{x:1640,y:599,t:1527019681087};\\\", \\\"{x:1637,y:599,t:1527019681103};\\\", \\\"{x:1636,y:600,t:1527019681111};\\\", \\\"{x:1632,y:601,t:1527019681126};\\\", \\\"{x:1623,y:605,t:1527019681142};\\\", \\\"{x:1610,y:608,t:1527019681158};\\\", \\\"{x:1607,y:610,t:1527019681176};\\\", \\\"{x:1603,y:610,t:1527019681192};\\\", \\\"{x:1601,y:610,t:1527019681214};\\\", \\\"{x:1600,y:611,t:1527019681230};\\\", \\\"{x:1598,y:611,t:1527019681254};\\\", \\\"{x:1597,y:612,t:1527019681263};\\\", \\\"{x:1595,y:612,t:1527019681278};\\\", \\\"{x:1594,y:613,t:1527019681292};\\\", \\\"{x:1590,y:613,t:1527019681309};\\\", \\\"{x:1585,y:616,t:1527019681326};\\\", \\\"{x:1580,y:616,t:1527019681342};\\\", \\\"{x:1571,y:620,t:1527019681359};\\\", \\\"{x:1564,y:623,t:1527019681376};\\\", \\\"{x:1555,y:628,t:1527019681393};\\\", \\\"{x:1547,y:632,t:1527019681409};\\\", \\\"{x:1539,y:635,t:1527019681426};\\\", \\\"{x:1534,y:637,t:1527019681443};\\\", \\\"{x:1532,y:637,t:1527019681459};\\\", \\\"{x:1530,y:637,t:1527019681476};\\\", \\\"{x:1529,y:637,t:1527019681631};\\\", \\\"{x:1527,y:638,t:1527019681647};\\\", \\\"{x:1525,y:638,t:1527019681660};\\\", \\\"{x:1523,y:639,t:1527019681677};\\\", \\\"{x:1521,y:639,t:1527019681694};\\\", \\\"{x:1519,y:640,t:1527019681710};\\\", \\\"{x:1517,y:641,t:1527019681727};\\\", \\\"{x:1516,y:641,t:1527019681743};\\\", \\\"{x:1512,y:645,t:1527019681759};\\\", \\\"{x:1510,y:647,t:1527019681776};\\\", \\\"{x:1510,y:648,t:1527019681793};\\\", \\\"{x:1509,y:648,t:1527019681810};\\\", \\\"{x:1508,y:649,t:1527019681827};\\\", \\\"{x:1507,y:651,t:1527019681844};\\\", \\\"{x:1507,y:653,t:1527019681860};\\\", \\\"{x:1505,y:656,t:1527019681876};\\\", \\\"{x:1504,y:658,t:1527019681893};\\\", \\\"{x:1503,y:659,t:1527019681910};\\\", \\\"{x:1503,y:660,t:1527019681926};\\\", \\\"{x:1503,y:661,t:1527019681943};\\\", \\\"{x:1501,y:664,t:1527019681960};\\\", \\\"{x:1499,y:666,t:1527019681976};\\\", \\\"{x:1499,y:667,t:1527019681994};\\\", \\\"{x:1498,y:669,t:1527019682011};\\\", \\\"{x:1497,y:670,t:1527019682026};\\\", \\\"{x:1496,y:672,t:1527019682043};\\\", \\\"{x:1494,y:674,t:1527019682060};\\\", \\\"{x:1493,y:676,t:1527019682079};\\\", \\\"{x:1492,y:676,t:1527019682152};\\\", \\\"{x:1491,y:676,t:1527019682176};\\\", \\\"{x:1490,y:676,t:1527019682223};\\\", \\\"{x:1490,y:675,t:1527019682351};\\\", \\\"{x:1488,y:671,t:1527019682361};\\\", \\\"{x:1487,y:669,t:1527019682377};\\\", \\\"{x:1487,y:668,t:1527019682394};\\\", \\\"{x:1487,y:666,t:1527019682411};\\\", \\\"{x:1487,y:662,t:1527019682427};\\\", \\\"{x:1487,y:658,t:1527019682444};\\\", \\\"{x:1487,y:651,t:1527019682460};\\\", \\\"{x:1487,y:645,t:1527019682478};\\\", \\\"{x:1487,y:639,t:1527019682494};\\\", \\\"{x:1487,y:636,t:1527019682510};\\\", \\\"{x:1487,y:629,t:1527019682528};\\\", \\\"{x:1489,y:621,t:1527019682544};\\\", \\\"{x:1489,y:615,t:1527019682560};\\\", \\\"{x:1490,y:608,t:1527019682578};\\\", \\\"{x:1490,y:605,t:1527019682595};\\\", \\\"{x:1490,y:604,t:1527019682611};\\\", \\\"{x:1490,y:602,t:1527019682627};\\\", \\\"{x:1490,y:601,t:1527019682644};\\\", \\\"{x:1487,y:607,t:1527019682904};\\\", \\\"{x:1484,y:613,t:1527019682911};\\\", \\\"{x:1478,y:625,t:1527019682927};\\\", \\\"{x:1472,y:634,t:1527019682945};\\\", \\\"{x:1468,y:643,t:1527019682961};\\\", \\\"{x:1465,y:645,t:1527019682977};\\\", \\\"{x:1461,y:652,t:1527019682994};\\\", \\\"{x:1460,y:657,t:1527019683011};\\\", \\\"{x:1453,y:666,t:1527019683027};\\\", \\\"{x:1446,y:675,t:1527019683044};\\\", \\\"{x:1444,y:679,t:1527019683061};\\\", \\\"{x:1443,y:680,t:1527019683086};\\\", \\\"{x:1442,y:681,t:1527019683102};\\\", \\\"{x:1442,y:682,t:1527019683119};\\\", \\\"{x:1441,y:682,t:1527019683127};\\\", \\\"{x:1436,y:685,t:1527019683144};\\\", \\\"{x:1432,y:687,t:1527019683161};\\\", \\\"{x:1432,y:688,t:1527019683178};\\\", \\\"{x:1432,y:692,t:1527019683195};\\\", \\\"{x:1432,y:697,t:1527019683211};\\\", \\\"{x:1429,y:704,t:1527019683227};\\\", \\\"{x:1428,y:715,t:1527019683245};\\\", \\\"{x:1424,y:726,t:1527019683261};\\\", \\\"{x:1417,y:737,t:1527019683277};\\\", \\\"{x:1410,y:747,t:1527019683294};\\\", \\\"{x:1401,y:765,t:1527019683310};\\\", \\\"{x:1393,y:777,t:1527019683326};\\\", \\\"{x:1384,y:787,t:1527019683344};\\\", \\\"{x:1373,y:799,t:1527019683361};\\\", \\\"{x:1367,y:806,t:1527019683378};\\\", \\\"{x:1359,y:817,t:1527019683394};\\\", \\\"{x:1352,y:829,t:1527019683411};\\\", \\\"{x:1345,y:840,t:1527019683428};\\\", \\\"{x:1340,y:845,t:1527019683444};\\\", \\\"{x:1337,y:848,t:1527019683461};\\\", \\\"{x:1336,y:848,t:1527019683479};\\\", \\\"{x:1336,y:849,t:1527019683494};\\\", \\\"{x:1334,y:850,t:1527019683534};\\\", \\\"{x:1333,y:850,t:1527019683559};\\\", \\\"{x:1332,y:854,t:1527019683798};\\\", \\\"{x:1331,y:862,t:1527019683812};\\\", \\\"{x:1328,y:875,t:1527019683828};\\\", \\\"{x:1325,y:882,t:1527019683844};\\\", \\\"{x:1324,y:884,t:1527019683861};\\\", \\\"{x:1324,y:886,t:1527019683919};\\\", \\\"{x:1324,y:887,t:1527019683943};\\\", \\\"{x:1323,y:888,t:1527019684023};\\\", \\\"{x:1323,y:889,t:1527019684030};\\\", \\\"{x:1322,y:889,t:1527019684045};\\\", \\\"{x:1320,y:889,t:1527019684431};\\\", \\\"{x:1318,y:889,t:1527019684445};\\\", \\\"{x:1317,y:889,t:1527019684462};\\\", \\\"{x:1314,y:888,t:1527019684478};\\\", \\\"{x:1310,y:886,t:1527019684495};\\\", \\\"{x:1308,y:885,t:1527019684512};\\\", \\\"{x:1305,y:883,t:1527019684527};\\\", \\\"{x:1304,y:881,t:1527019684545};\\\", \\\"{x:1301,y:879,t:1527019684562};\\\", \\\"{x:1298,y:878,t:1527019684579};\\\", \\\"{x:1292,y:874,t:1527019684595};\\\", \\\"{x:1287,y:870,t:1527019684612};\\\", \\\"{x:1284,y:868,t:1527019684629};\\\", \\\"{x:1283,y:867,t:1527019684645};\\\", \\\"{x:1282,y:866,t:1527019684662};\\\", \\\"{x:1278,y:864,t:1527019684678};\\\", \\\"{x:1277,y:862,t:1527019684695};\\\", \\\"{x:1276,y:861,t:1527019684711};\\\", \\\"{x:1273,y:860,t:1527019684729};\\\", \\\"{x:1271,y:858,t:1527019684745};\\\", \\\"{x:1270,y:857,t:1527019684790};\\\", \\\"{x:1269,y:857,t:1527019684798};\\\", \\\"{x:1268,y:857,t:1527019684812};\\\", \\\"{x:1268,y:856,t:1527019684829};\\\", \\\"{x:1266,y:855,t:1527019684845};\\\", \\\"{x:1266,y:854,t:1527019684862};\\\", \\\"{x:1265,y:854,t:1527019684887};\\\", \\\"{x:1264,y:853,t:1527019684942};\\\", \\\"{x:1263,y:853,t:1527019684966};\\\", \\\"{x:1263,y:852,t:1527019685183};\\\", \\\"{x:1262,y:851,t:1527019685196};\\\", \\\"{x:1260,y:849,t:1527019685212};\\\", \\\"{x:1259,y:849,t:1527019685229};\\\", \\\"{x:1259,y:848,t:1527019685246};\\\", \\\"{x:1257,y:848,t:1527019685287};\\\", \\\"{x:1257,y:847,t:1527019685359};\\\", \\\"{x:1256,y:846,t:1527019685367};\\\", \\\"{x:1255,y:846,t:1527019685378};\\\", \\\"{x:1251,y:846,t:1527019685397};\\\", \\\"{x:1243,y:845,t:1527019685412};\\\", \\\"{x:1233,y:845,t:1527019685429};\\\", \\\"{x:1218,y:845,t:1527019685446};\\\", \\\"{x:1202,y:850,t:1527019685462};\\\", \\\"{x:1192,y:855,t:1527019685479};\\\", \\\"{x:1184,y:859,t:1527019685496};\\\", \\\"{x:1181,y:861,t:1527019685513};\\\", \\\"{x:1180,y:861,t:1527019685529};\\\", \\\"{x:1177,y:864,t:1527019685646};\\\", \\\"{x:1166,y:890,t:1527019685662};\\\", \\\"{x:1153,y:913,t:1527019685679};\\\", \\\"{x:1138,y:935,t:1527019685696};\\\", \\\"{x:1128,y:949,t:1527019685713};\\\", \\\"{x:1124,y:957,t:1527019685729};\\\", \\\"{x:1122,y:960,t:1527019685746};\\\", \\\"{x:1120,y:964,t:1527019685763};\\\", \\\"{x:1120,y:965,t:1527019685780};\\\", \\\"{x:1118,y:969,t:1527019685796};\\\", \\\"{x:1118,y:971,t:1527019685813};\\\", \\\"{x:1116,y:974,t:1527019685829};\\\", \\\"{x:1118,y:974,t:1527019685927};\\\", \\\"{x:1119,y:974,t:1527019685934};\\\", \\\"{x:1120,y:974,t:1527019685946};\\\", \\\"{x:1122,y:974,t:1527019685963};\\\", \\\"{x:1123,y:974,t:1527019685980};\\\", \\\"{x:1124,y:974,t:1527019686055};\\\", \\\"{x:1126,y:973,t:1527019686174};\\\", \\\"{x:1126,y:972,t:1527019686190};\\\", \\\"{x:1127,y:971,t:1527019686198};\\\", \\\"{x:1128,y:969,t:1527019686213};\\\", \\\"{x:1130,y:965,t:1527019686230};\\\", \\\"{x:1133,y:961,t:1527019686246};\\\", \\\"{x:1137,y:954,t:1527019686263};\\\", \\\"{x:1140,y:946,t:1527019686280};\\\", \\\"{x:1143,y:940,t:1527019686297};\\\", \\\"{x:1146,y:935,t:1527019686313};\\\", \\\"{x:1148,y:931,t:1527019686330};\\\", \\\"{x:1152,y:927,t:1527019686347};\\\", \\\"{x:1156,y:923,t:1527019686363};\\\", \\\"{x:1160,y:916,t:1527019686380};\\\", \\\"{x:1166,y:908,t:1527019686398};\\\", \\\"{x:1171,y:897,t:1527019686413};\\\", \\\"{x:1174,y:892,t:1527019686430};\\\", \\\"{x:1175,y:890,t:1527019686447};\\\", \\\"{x:1175,y:889,t:1527019686463};\\\", \\\"{x:1176,y:887,t:1527019686481};\\\", \\\"{x:1179,y:882,t:1527019686498};\\\", \\\"{x:1180,y:879,t:1527019686514};\\\", \\\"{x:1181,y:878,t:1527019686530};\\\", \\\"{x:1182,y:876,t:1527019686547};\\\", \\\"{x:1183,y:876,t:1527019686751};\\\", \\\"{x:1185,y:876,t:1527019686764};\\\", \\\"{x:1190,y:871,t:1527019686780};\\\", \\\"{x:1197,y:865,t:1527019686798};\\\", \\\"{x:1204,y:855,t:1527019686815};\\\", \\\"{x:1210,y:848,t:1527019686830};\\\", \\\"{x:1212,y:844,t:1527019686847};\\\", \\\"{x:1214,y:841,t:1527019686865};\\\", \\\"{x:1215,y:839,t:1527019686880};\\\", \\\"{x:1215,y:837,t:1527019687015};\\\", \\\"{x:1219,y:844,t:1527019695805};\\\", \\\"{x:1223,y:852,t:1527019695820};\\\", \\\"{x:1231,y:872,t:1527019695837};\\\", \\\"{x:1240,y:886,t:1527019695853};\\\", \\\"{x:1245,y:894,t:1527019695870};\\\", \\\"{x:1248,y:898,t:1527019695886};\\\", \\\"{x:1248,y:900,t:1527019695903};\\\", \\\"{x:1248,y:901,t:1527019695933};\\\", \\\"{x:1249,y:902,t:1527019695940};\\\", \\\"{x:1251,y:905,t:1527019695953};\\\", \\\"{x:1252,y:913,t:1527019695969};\\\", \\\"{x:1257,y:924,t:1527019695987};\\\", \\\"{x:1262,y:931,t:1527019696003};\\\", \\\"{x:1263,y:935,t:1527019696020};\\\", \\\"{x:1264,y:936,t:1527019696037};\\\", \\\"{x:1266,y:940,t:1527019696196};\\\", \\\"{x:1267,y:945,t:1527019696204};\\\", \\\"{x:1268,y:950,t:1527019696219};\\\", \\\"{x:1273,y:961,t:1527019696236};\\\", \\\"{x:1275,y:968,t:1527019696253};\\\", \\\"{x:1276,y:970,t:1527019696269};\\\", \\\"{x:1277,y:971,t:1527019696292};\\\", \\\"{x:1277,y:970,t:1527019699917};\\\", \\\"{x:1277,y:969,t:1527019699925};\\\", \\\"{x:1277,y:967,t:1527019699940};\\\", \\\"{x:1278,y:965,t:1527019699956};\\\", \\\"{x:1278,y:963,t:1527019699972};\\\", \\\"{x:1278,y:961,t:1527019699990};\\\", \\\"{x:1279,y:960,t:1527019700007};\\\", \\\"{x:1279,y:959,t:1527019700051};\\\", \\\"{x:1279,y:958,t:1527019700092};\\\", \\\"{x:1280,y:958,t:1527019700107};\\\", \\\"{x:1280,y:957,t:1527019700124};\\\", \\\"{x:1280,y:956,t:1527019700157};\\\", \\\"{x:1280,y:954,t:1527019700437};\\\", \\\"{x:1281,y:953,t:1527019700444};\\\", \\\"{x:1282,y:952,t:1527019700461};\\\", \\\"{x:1282,y:950,t:1527019700474};\\\", \\\"{x:1283,y:949,t:1527019700490};\\\", \\\"{x:1284,y:948,t:1527019700509};\\\", \\\"{x:1284,y:947,t:1527019700533};\\\", \\\"{x:1284,y:946,t:1527019700564};\\\", \\\"{x:1284,y:945,t:1527019700596};\\\", \\\"{x:1285,y:944,t:1527019700607};\\\", \\\"{x:1285,y:943,t:1527019700685};\\\", \\\"{x:1286,y:942,t:1527019700700};\\\", \\\"{x:1287,y:941,t:1527019700732};\\\", \\\"{x:1287,y:940,t:1527019700780};\\\", \\\"{x:1287,y:939,t:1527019700804};\\\", \\\"{x:1288,y:938,t:1527019700821};\\\", \\\"{x:1289,y:936,t:1527019700845};\\\", \\\"{x:1290,y:935,t:1527019700860};\\\", \\\"{x:1290,y:934,t:1527019700874};\\\", \\\"{x:1292,y:931,t:1527019700891};\\\", \\\"{x:1293,y:929,t:1527019700907};\\\", \\\"{x:1294,y:926,t:1527019700924};\\\", \\\"{x:1297,y:921,t:1527019700941};\\\", \\\"{x:1298,y:917,t:1527019700958};\\\", \\\"{x:1300,y:915,t:1527019700973};\\\", \\\"{x:1300,y:914,t:1527019700991};\\\", \\\"{x:1302,y:911,t:1527019701008};\\\", \\\"{x:1302,y:909,t:1527019701024};\\\", \\\"{x:1303,y:908,t:1527019701041};\\\", \\\"{x:1304,y:907,t:1527019701058};\\\", \\\"{x:1304,y:905,t:1527019701074};\\\", \\\"{x:1304,y:904,t:1527019701091};\\\", \\\"{x:1306,y:902,t:1527019701108};\\\", \\\"{x:1307,y:899,t:1527019701124};\\\", \\\"{x:1308,y:895,t:1527019701141};\\\", \\\"{x:1309,y:894,t:1527019701158};\\\", \\\"{x:1309,y:893,t:1527019701174};\\\", \\\"{x:1310,y:891,t:1527019701191};\\\", \\\"{x:1311,y:890,t:1527019701208};\\\", \\\"{x:1311,y:889,t:1527019701223};\\\", \\\"{x:1311,y:888,t:1527019701241};\\\", \\\"{x:1313,y:886,t:1527019701257};\\\", \\\"{x:1313,y:885,t:1527019701273};\\\", \\\"{x:1314,y:885,t:1527019701291};\\\", \\\"{x:1315,y:883,t:1527019701308};\\\", \\\"{x:1315,y:882,t:1527019701323};\\\", \\\"{x:1316,y:881,t:1527019701341};\\\", \\\"{x:1316,y:880,t:1527019701364};\\\", \\\"{x:1317,y:880,t:1527019701389};\\\", \\\"{x:1318,y:878,t:1527019701396};\\\", \\\"{x:1319,y:877,t:1527019701408};\\\", \\\"{x:1320,y:876,t:1527019701425};\\\", \\\"{x:1322,y:872,t:1527019701441};\\\", \\\"{x:1323,y:870,t:1527019701458};\\\", \\\"{x:1325,y:869,t:1527019701475};\\\", \\\"{x:1327,y:866,t:1527019701490};\\\", \\\"{x:1328,y:864,t:1527019701507};\\\", \\\"{x:1329,y:862,t:1527019701524};\\\", \\\"{x:1330,y:860,t:1527019701541};\\\", \\\"{x:1332,y:859,t:1527019701557};\\\", \\\"{x:1332,y:858,t:1527019701575};\\\", \\\"{x:1333,y:857,t:1527019701590};\\\", \\\"{x:1334,y:855,t:1527019701612};\\\", \\\"{x:1335,y:855,t:1527019701627};\\\", \\\"{x:1335,y:854,t:1527019701640};\\\", \\\"{x:1336,y:852,t:1527019701660};\\\", \\\"{x:1337,y:851,t:1527019701676};\\\", \\\"{x:1338,y:851,t:1527019701690};\\\", \\\"{x:1339,y:849,t:1527019701707};\\\", \\\"{x:1340,y:847,t:1527019701723};\\\", \\\"{x:1341,y:846,t:1527019701740};\\\", \\\"{x:1342,y:845,t:1527019701758};\\\", \\\"{x:1342,y:844,t:1527019701774};\\\", \\\"{x:1343,y:842,t:1527019701791};\\\", \\\"{x:1344,y:842,t:1527019701808};\\\", \\\"{x:1345,y:841,t:1527019701825};\\\", \\\"{x:1345,y:838,t:1527019701842};\\\", \\\"{x:1346,y:837,t:1527019701860};\\\", \\\"{x:1347,y:836,t:1527019701874};\\\", \\\"{x:1348,y:835,t:1527019701891};\\\", \\\"{x:1349,y:833,t:1527019701908};\\\", \\\"{x:1351,y:830,t:1527019701924};\\\", \\\"{x:1351,y:829,t:1527019701942};\\\", \\\"{x:1352,y:827,t:1527019701958};\\\", \\\"{x:1353,y:825,t:1527019701975};\\\", \\\"{x:1354,y:823,t:1527019701992};\\\", \\\"{x:1354,y:822,t:1527019702008};\\\", \\\"{x:1355,y:819,t:1527019702025};\\\", \\\"{x:1356,y:818,t:1527019702042};\\\", \\\"{x:1356,y:817,t:1527019702058};\\\", \\\"{x:1357,y:816,t:1527019702075};\\\", \\\"{x:1358,y:814,t:1527019702100};\\\", \\\"{x:1358,y:813,t:1527019702118};\\\", \\\"{x:1358,y:811,t:1527019702133};\\\", \\\"{x:1360,y:809,t:1527019702142};\\\", \\\"{x:1360,y:807,t:1527019702181};\\\", \\\"{x:1361,y:807,t:1527019702192};\\\", \\\"{x:1361,y:806,t:1527019702212};\\\", \\\"{x:1363,y:804,t:1527019702228};\\\", \\\"{x:1363,y:802,t:1527019702253};\\\", \\\"{x:1364,y:802,t:1527019702268};\\\", \\\"{x:1364,y:801,t:1527019702284};\\\", \\\"{x:1365,y:801,t:1527019702292};\\\", \\\"{x:1365,y:800,t:1527019702308};\\\", \\\"{x:1366,y:798,t:1527019702325};\\\", \\\"{x:1366,y:797,t:1527019702342};\\\", \\\"{x:1367,y:795,t:1527019702359};\\\", \\\"{x:1368,y:793,t:1527019702381};\\\", \\\"{x:1368,y:792,t:1527019702413};\\\", \\\"{x:1368,y:791,t:1527019702425};\\\", \\\"{x:1369,y:791,t:1527019702442};\\\", \\\"{x:1369,y:790,t:1527019702459};\\\", \\\"{x:1370,y:788,t:1527019702474};\\\", \\\"{x:1371,y:787,t:1527019702492};\\\", \\\"{x:1372,y:784,t:1527019702508};\\\", \\\"{x:1373,y:784,t:1527019702525};\\\", \\\"{x:1373,y:783,t:1527019702541};\\\", \\\"{x:1373,y:781,t:1527019702559};\\\", \\\"{x:1374,y:780,t:1527019702574};\\\", \\\"{x:1376,y:778,t:1527019702591};\\\", \\\"{x:1376,y:776,t:1527019702609};\\\", \\\"{x:1376,y:775,t:1527019702626};\\\", \\\"{x:1376,y:774,t:1527019702642};\\\", \\\"{x:1377,y:773,t:1527019702659};\\\", \\\"{x:1377,y:771,t:1527019702676};\\\", \\\"{x:1378,y:770,t:1527019702691};\\\", \\\"{x:1380,y:766,t:1527019702709};\\\", \\\"{x:1382,y:764,t:1527019702742};\\\", \\\"{x:1382,y:763,t:1527019702759};\\\", \\\"{x:1382,y:761,t:1527019702775};\\\", \\\"{x:1382,y:760,t:1527019702791};\\\", \\\"{x:1383,y:759,t:1527019702809};\\\", \\\"{x:1383,y:758,t:1527019702825};\\\", \\\"{x:1382,y:756,t:1527019702886};\\\", \\\"{x:1374,y:752,t:1527019702893};\\\", \\\"{x:1342,y:744,t:1527019702908};\\\", \\\"{x:1266,y:729,t:1527019702925};\\\", \\\"{x:1155,y:727,t:1527019702942};\\\", \\\"{x:1032,y:709,t:1527019702959};\\\", \\\"{x:913,y:688,t:1527019702976};\\\", \\\"{x:824,y:665,t:1527019702992};\\\", \\\"{x:763,y:646,t:1527019703009};\\\", \\\"{x:729,y:635,t:1527019703025};\\\", \\\"{x:716,y:633,t:1527019703044};\\\", \\\"{x:713,y:633,t:1527019703058};\\\", \\\"{x:710,y:633,t:1527019703091};\\\", \\\"{x:705,y:633,t:1527019703107};\\\", \\\"{x:677,y:638,t:1527019703123};\\\", \\\"{x:646,y:643,t:1527019703140};\\\", \\\"{x:620,y:645,t:1527019703157};\\\", \\\"{x:598,y:645,t:1527019703174};\\\", \\\"{x:578,y:645,t:1527019703190};\\\", \\\"{x:539,y:635,t:1527019703207};\\\", \\\"{x:459,y:614,t:1527019703224};\\\", \\\"{x:409,y:600,t:1527019703241};\\\", \\\"{x:391,y:598,t:1527019703257};\\\", \\\"{x:388,y:598,t:1527019703274};\\\", \\\"{x:387,y:598,t:1527019703291};\\\", \\\"{x:386,y:597,t:1527019703307};\\\", \\\"{x:385,y:595,t:1527019703324};\\\", \\\"{x:385,y:592,t:1527019703341};\\\", \\\"{x:385,y:590,t:1527019703357};\\\", \\\"{x:385,y:589,t:1527019703396};\\\", \\\"{x:384,y:588,t:1527019703461};\\\", \\\"{x:384,y:585,t:1527019703475};\\\", \\\"{x:384,y:578,t:1527019703493};\\\", \\\"{x:384,y:571,t:1527019703508};\\\", \\\"{x:384,y:570,t:1527019703524};\\\", \\\"{x:384,y:569,t:1527019703541};\\\", \\\"{x:385,y:568,t:1527019703709};\\\", \\\"{x:386,y:568,t:1527019703852};\\\", \\\"{x:387,y:568,t:1527019703859};\\\", \\\"{x:388,y:568,t:1527019703883};\\\", \\\"{x:389,y:568,t:1527019703947};\\\", \\\"{x:395,y:568,t:1527019703958};\\\", \\\"{x:410,y:573,t:1527019703975};\\\", \\\"{x:418,y:577,t:1527019703992};\\\", \\\"{x:420,y:577,t:1527019704008};\\\", \\\"{x:421,y:578,t:1527019704024};\\\", \\\"{x:423,y:580,t:1527019704042};\\\", \\\"{x:429,y:585,t:1527019704059};\\\", \\\"{x:434,y:595,t:1527019704074};\\\", \\\"{x:440,y:607,t:1527019704091};\\\", \\\"{x:445,y:618,t:1527019704108};\\\", \\\"{x:455,y:636,t:1527019704125};\\\", \\\"{x:464,y:654,t:1527019704142};\\\", \\\"{x:471,y:666,t:1527019704158};\\\", \\\"{x:473,y:670,t:1527019704174};\\\", \\\"{x:473,y:672,t:1527019704211};\\\", \\\"{x:476,y:674,t:1527019704224};\\\", \\\"{x:480,y:685,t:1527019704241};\\\", \\\"{x:485,y:695,t:1527019704258};\\\", \\\"{x:488,y:700,t:1527019704275};\\\", \\\"{x:489,y:701,t:1527019704293};\\\", \\\"{x:490,y:702,t:1527019704829};\\\" ] }, { \\\"rt\\\": 11570, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 8, \\\"time_elapsed\\\": 324373, \\\"internal_node_id\\\": \\\"0.0-5.0-3.0\\\", \\\"subject\\\": \\\"VT5BG\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"golf\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 4, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"H\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-04 PM\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:491,y:701,t:1527019706452};\\\", \\\"{x:492,y:696,t:1527019706460};\\\", \\\"{x:494,y:689,t:1527019706476};\\\", \\\"{x:497,y:681,t:1527019706493};\\\", \\\"{x:498,y:675,t:1527019706510};\\\", \\\"{x:500,y:672,t:1527019706526};\\\", \\\"{x:501,y:667,t:1527019706543};\\\", \\\"{x:502,y:667,t:1527019706560};\\\", \\\"{x:502,y:664,t:1527019706576};\\\", \\\"{x:505,y:659,t:1527019706593};\\\", \\\"{x:510,y:651,t:1527019706610};\\\", \\\"{x:513,y:646,t:1527019706627};\\\", \\\"{x:514,y:640,t:1527019706644};\\\", \\\"{x:514,y:639,t:1527019706660};\\\", \\\"{x:514,y:637,t:1527019707220};\\\", \\\"{x:514,y:636,t:1527019707228};\\\", \\\"{x:517,y:633,t:1527019707309};\\\", \\\"{x:517,y:632,t:1527019707324};\\\", \\\"{x:517,y:631,t:1527019707364};\\\", \\\"{x:519,y:630,t:1527019707377};\\\", \\\"{x:524,y:628,t:1527019707394};\\\", \\\"{x:526,y:628,t:1527019707411};\\\", \\\"{x:530,y:626,t:1527019707427};\\\", \\\"{x:531,y:625,t:1527019707444};\\\", \\\"{x:537,y:621,t:1527019707460};\\\", \\\"{x:547,y:618,t:1527019707478};\\\", \\\"{x:558,y:613,t:1527019707494};\\\", \\\"{x:566,y:609,t:1527019707511};\\\", \\\"{x:574,y:606,t:1527019707527};\\\", \\\"{x:586,y:603,t:1527019707544};\\\", \\\"{x:602,y:599,t:1527019707561};\\\", \\\"{x:631,y:593,t:1527019707577};\\\", \\\"{x:668,y:587,t:1527019707594};\\\", \\\"{x:702,y:586,t:1527019707610};\\\", \\\"{x:748,y:584,t:1527019707628};\\\", \\\"{x:791,y:584,t:1527019707644};\\\", \\\"{x:852,y:584,t:1527019707660};\\\", \\\"{x:921,y:589,t:1527019707677};\\\", \\\"{x:977,y:597,t:1527019707695};\\\", \\\"{x:1027,y:604,t:1527019707711};\\\", \\\"{x:1062,y:611,t:1527019707728};\\\", \\\"{x:1092,y:617,t:1527019707745};\\\", \\\"{x:1114,y:624,t:1527019707762};\\\", \\\"{x:1125,y:630,t:1527019707777};\\\", \\\"{x:1133,y:638,t:1527019707794};\\\", \\\"{x:1154,y:665,t:1527019707812};\\\", \\\"{x:1185,y:688,t:1527019707828};\\\", \\\"{x:1208,y:703,t:1527019707844};\\\", \\\"{x:1241,y:716,t:1527019707862};\\\", \\\"{x:1249,y:717,t:1527019707877};\\\", \\\"{x:1249,y:718,t:1527019708277};\\\", \\\"{x:1249,y:719,t:1527019708380};\\\", \\\"{x:1250,y:719,t:1527019708669};\\\", \\\"{x:1251,y:718,t:1527019708679};\\\", \\\"{x:1253,y:718,t:1527019709581};\\\", \\\"{x:1254,y:722,t:1527019709597};\\\", \\\"{x:1256,y:728,t:1527019709613};\\\", \\\"{x:1256,y:733,t:1527019709630};\\\", \\\"{x:1257,y:735,t:1527019709647};\\\", \\\"{x:1258,y:738,t:1527019709663};\\\", \\\"{x:1258,y:739,t:1527019709893};\\\", \\\"{x:1260,y:740,t:1527019709901};\\\", \\\"{x:1261,y:742,t:1527019709914};\\\", \\\"{x:1263,y:744,t:1527019709930};\\\", \\\"{x:1264,y:746,t:1527019709947};\\\", \\\"{x:1275,y:753,t:1527019709964};\\\", \\\"{x:1293,y:763,t:1527019709981};\\\", \\\"{x:1314,y:776,t:1527019709998};\\\", \\\"{x:1340,y:789,t:1527019710014};\\\", \\\"{x:1375,y:807,t:1527019710030};\\\", \\\"{x:1421,y:825,t:1527019710047};\\\", \\\"{x:1474,y:850,t:1527019710064};\\\", \\\"{x:1537,y:886,t:1527019710080};\\\", \\\"{x:1602,y:932,t:1527019710098};\\\", \\\"{x:1652,y:965,t:1527019710114};\\\", \\\"{x:1683,y:987,t:1527019710130};\\\", \\\"{x:1703,y:998,t:1527019710147};\\\", \\\"{x:1714,y:1006,t:1527019710164};\\\", \\\"{x:1718,y:1008,t:1527019710180};\\\", \\\"{x:1713,y:1008,t:1527019710245};\\\", \\\"{x:1708,y:1008,t:1527019710252};\\\", \\\"{x:1703,y:1008,t:1527019710264};\\\", \\\"{x:1697,y:1008,t:1527019710281};\\\", \\\"{x:1691,y:1010,t:1527019710296};\\\", \\\"{x:1679,y:1010,t:1527019710313};\\\", \\\"{x:1671,y:1009,t:1527019710330};\\\", \\\"{x:1664,y:1005,t:1527019710346};\\\", \\\"{x:1661,y:998,t:1527019710363};\\\", \\\"{x:1661,y:992,t:1527019710380};\\\", \\\"{x:1661,y:979,t:1527019710396};\\\", \\\"{x:1661,y:970,t:1527019710413};\\\", \\\"{x:1661,y:966,t:1527019710431};\\\", \\\"{x:1656,y:960,t:1527019710447};\\\", \\\"{x:1639,y:951,t:1527019710464};\\\", \\\"{x:1625,y:944,t:1527019710480};\\\", \\\"{x:1622,y:943,t:1527019710497};\\\", \\\"{x:1621,y:955,t:1527019710513};\\\", \\\"{x:1619,y:965,t:1527019710531};\\\", \\\"{x:1616,y:967,t:1527019710547};\\\", \\\"{x:1615,y:969,t:1527019710564};\\\", \\\"{x:1615,y:972,t:1527019710580};\\\", \\\"{x:1614,y:974,t:1527019710598};\\\", \\\"{x:1614,y:975,t:1527019710620};\\\", \\\"{x:1614,y:976,t:1527019710644};\\\", \\\"{x:1614,y:975,t:1527019710876};\\\", \\\"{x:1614,y:971,t:1527019710884};\\\", \\\"{x:1614,y:969,t:1527019710898};\\\", \\\"{x:1614,y:968,t:1527019710916};\\\", \\\"{x:1607,y:963,t:1527019715091};\\\", \\\"{x:1577,y:952,t:1527019715102};\\\", \\\"{x:1458,y:902,t:1527019715118};\\\", \\\"{x:1298,y:827,t:1527019715135};\\\", \\\"{x:1118,y:744,t:1527019715152};\\\", \\\"{x:939,y:659,t:1527019715169};\\\", \\\"{x:760,y:583,t:1527019715185};\\\", \\\"{x:601,y:525,t:1527019715202};\\\", \\\"{x:499,y:497,t:1527019715219};\\\", \\\"{x:428,y:491,t:1527019715250};\\\", \\\"{x:424,y:491,t:1527019715267};\\\", \\\"{x:423,y:491,t:1527019715283};\\\", \\\"{x:419,y:496,t:1527019715299};\\\", \\\"{x:407,y:509,t:1527019715317};\\\", \\\"{x:394,y:525,t:1527019715334};\\\", \\\"{x:387,y:536,t:1527019715351};\\\", \\\"{x:387,y:543,t:1527019715367};\\\", \\\"{x:387,y:547,t:1527019715384};\\\", \\\"{x:394,y:553,t:1527019715401};\\\", \\\"{x:405,y:561,t:1527019715416};\\\", \\\"{x:417,y:566,t:1527019715434};\\\", \\\"{x:422,y:568,t:1527019715451};\\\", \\\"{x:421,y:568,t:1527019715523};\\\", \\\"{x:415,y:568,t:1527019715534};\\\", \\\"{x:403,y:573,t:1527019715551};\\\", \\\"{x:395,y:577,t:1527019715568};\\\", \\\"{x:392,y:578,t:1527019715583};\\\", \\\"{x:391,y:584,t:1527019715765};\\\", \\\"{x:390,y:592,t:1527019715772};\\\", \\\"{x:388,y:602,t:1527019715783};\\\", \\\"{x:386,y:613,t:1527019715801};\\\", \\\"{x:386,y:619,t:1527019715817};\\\", \\\"{x:386,y:620,t:1527019715877};\\\", \\\"{x:382,y:621,t:1527019715883};\\\", \\\"{x:364,y:623,t:1527019715901};\\\", \\\"{x:337,y:623,t:1527019715917};\\\", \\\"{x:316,y:623,t:1527019715934};\\\", \\\"{x:306,y:622,t:1527019715951};\\\", \\\"{x:302,y:621,t:1527019715967};\\\", \\\"{x:300,y:621,t:1527019715985};\\\", \\\"{x:299,y:618,t:1527019716001};\\\", \\\"{x:297,y:618,t:1527019716019};\\\", \\\"{x:296,y:618,t:1527019716035};\\\", \\\"{x:290,y:618,t:1527019716051};\\\", \\\"{x:279,y:619,t:1527019716067};\\\", \\\"{x:270,y:622,t:1527019716085};\\\", \\\"{x:256,y:627,t:1527019716101};\\\", \\\"{x:235,y:633,t:1527019716118};\\\", \\\"{x:207,y:637,t:1527019716134};\\\", \\\"{x:188,y:641,t:1527019716152};\\\", \\\"{x:181,y:641,t:1527019716168};\\\", \\\"{x:186,y:641,t:1527019716203};\\\", \\\"{x:197,y:638,t:1527019716219};\\\", \\\"{x:224,y:628,t:1527019716235};\\\", \\\"{x:282,y:622,t:1527019716251};\\\", \\\"{x:401,y:614,t:1527019716269};\\\", \\\"{x:481,y:603,t:1527019716285};\\\", \\\"{x:562,y:592,t:1527019716301};\\\", \\\"{x:624,y:582,t:1527019716318};\\\", \\\"{x:670,y:573,t:1527019716336};\\\", \\\"{x:690,y:571,t:1527019716352};\\\", \\\"{x:693,y:571,t:1527019716368};\\\", \\\"{x:692,y:571,t:1527019716476};\\\", \\\"{x:685,y:572,t:1527019716485};\\\", \\\"{x:672,y:576,t:1527019716502};\\\", \\\"{x:659,y:576,t:1527019716518};\\\", \\\"{x:646,y:576,t:1527019716535};\\\", \\\"{x:639,y:575,t:1527019716552};\\\", \\\"{x:630,y:570,t:1527019716568};\\\", \\\"{x:623,y:566,t:1527019716585};\\\", \\\"{x:620,y:565,t:1527019716602};\\\", \\\"{x:618,y:565,t:1527019716617};\\\", \\\"{x:618,y:564,t:1527019716635};\\\", \\\"{x:615,y:575,t:1527019716884};\\\", \\\"{x:603,y:602,t:1527019716902};\\\", \\\"{x:589,y:625,t:1527019716920};\\\", \\\"{x:574,y:651,t:1527019716935};\\\", \\\"{x:562,y:674,t:1527019716952};\\\", \\\"{x:557,y:690,t:1527019716969};\\\", \\\"{x:556,y:700,t:1527019716984};\\\", \\\"{x:555,y:705,t:1527019717002};\\\", \\\"{x:549,y:713,t:1527019717019};\\\", \\\"{x:543,y:719,t:1527019717035};\\\", \\\"{x:532,y:726,t:1527019717051};\\\", \\\"{x:530,y:728,t:1527019717068};\\\", \\\"{x:529,y:728,t:1527019717377};\\\", \\\"{x:528,y:728,t:1527019717443};\\\", \\\"{x:528,y:726,t:1527019717467};\\\", \\\"{x:528,y:725,t:1527019717475};\\\", \\\"{x:528,y:723,t:1527019717491};\\\", \\\"{x:528,y:722,t:1527019717501};\\\", \\\"{x:527,y:720,t:1527019717539};\\\", \\\"{x:527,y:719,t:1527019717620};\\\", \\\"{x:527,y:718,t:1527019717643};\\\", \\\"{x:527,y:717,t:1527019717652};\\\", \\\"{x:528,y:716,t:1527019717669};\\\", \\\"{x:529,y:716,t:1527019717685};\\\", \\\"{x:529,y:715,t:1527019717702};\\\", \\\"{x:530,y:714,t:1527019717719};\\\", \\\"{x:531,y:713,t:1527019717736};\\\", \\\"{x:532,y:711,t:1527019717755};\\\", \\\"{x:533,y:709,t:1527019717769};\\\", \\\"{x:538,y:706,t:1527019717786};\\\", \\\"{x:539,y:705,t:1527019717802};\\\", \\\"{x:541,y:705,t:1527019717819};\\\", \\\"{x:541,y:704,t:1527019717924};\\\", \\\"{x:542,y:703,t:1527019717948};\\\", \\\"{x:542,y:702,t:1527019717980};\\\", \\\"{x:544,y:701,t:1527019718012};\\\", \\\"{x:544,y:700,t:1527019718052};\\\", \\\"{x:545,y:699,t:1527019718069};\\\", \\\"{x:546,y:699,t:1527019718086};\\\", \\\"{x:546,y:697,t:1527019718103};\\\", \\\"{x:547,y:696,t:1527019718119};\\\", \\\"{x:548,y:696,t:1527019718140};\\\", \\\"{x:549,y:695,t:1527019718172};\\\", \\\"{x:549,y:694,t:1527019718204};\\\", \\\"{x:550,y:693,t:1527019718419};\\\" ] }, { \\\"rt\\\": 18178, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 9, \\\"time_elapsed\\\": 343762, \\\"internal_node_id\\\": \\\"0.0-5.0-4.0\\\", \\\"subject\\\": \\\"VT5BG\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"golf\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 5, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"O\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-I -I -I -O -O \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:550,y:690,t:1527019718570};\\\", \\\"{x:550,y:688,t:1527019718669};\\\", \\\"{x:551,y:688,t:1527019718687};\\\", \\\"{x:552,y:686,t:1527019718703};\\\", \\\"{x:553,y:684,t:1527019718720};\\\", \\\"{x:554,y:682,t:1527019718737};\\\", \\\"{x:554,y:681,t:1527019718753};\\\", \\\"{x:554,y:680,t:1527019718770};\\\", \\\"{x:554,y:679,t:1527019718948};\\\", \\\"{x:555,y:678,t:1527019718956};\\\", \\\"{x:556,y:675,t:1527019719063};\\\", \\\"{x:556,y:674,t:1527019719075};\\\", \\\"{x:557,y:672,t:1527019719086};\\\", \\\"{x:557,y:671,t:1527019719179};\\\", \\\"{x:557,y:670,t:1527019719244};\\\", \\\"{x:557,y:669,t:1527019719254};\\\", \\\"{x:557,y:668,t:1527019719275};\\\", \\\"{x:558,y:666,t:1527019719291};\\\", \\\"{x:558,y:665,t:1527019719331};\\\", \\\"{x:558,y:664,t:1527019719339};\\\", \\\"{x:558,y:663,t:1527019719355};\\\", \\\"{x:558,y:662,t:1527019719468};\\\", \\\"{x:559,y:661,t:1527019719476};\\\", \\\"{x:559,y:660,t:1527019719499};\\\", \\\"{x:559,y:659,t:1527019719523};\\\", \\\"{x:559,y:658,t:1527019719537};\\\", \\\"{x:560,y:656,t:1527019719554};\\\", \\\"{x:560,y:655,t:1527019719571};\\\", \\\"{x:560,y:654,t:1527019719587};\\\", \\\"{x:560,y:653,t:1527019719604};\\\", \\\"{x:560,y:651,t:1527019719621};\\\", \\\"{x:560,y:650,t:1527019719652};\\\", \\\"{x:560,y:649,t:1527019719668};\\\", \\\"{x:560,y:648,t:1527019719676};\\\", \\\"{x:561,y:647,t:1527019719740};\\\", \\\"{x:561,y:646,t:1527019719860};\\\", \\\"{x:561,y:645,t:1527019720005};\\\", \\\"{x:561,y:644,t:1527019720035};\\\", \\\"{x:562,y:643,t:1527019720043};\\\", \\\"{x:563,y:642,t:1527019720075};\\\", \\\"{x:563,y:640,t:1527019720107};\\\", \\\"{x:564,y:638,t:1527019720131};\\\", \\\"{x:565,y:637,t:1527019720163};\\\", \\\"{x:565,y:636,t:1527019720179};\\\", \\\"{x:566,y:635,t:1527019720196};\\\", \\\"{x:566,y:633,t:1527019720229};\\\", \\\"{x:566,y:632,t:1527019720292};\\\", \\\"{x:567,y:632,t:1527019720304};\\\", \\\"{x:567,y:630,t:1527019720321};\\\", \\\"{x:568,y:629,t:1527019720339};\\\", \\\"{x:569,y:628,t:1527019720371};\\\", \\\"{x:569,y:627,t:1527019720388};\\\", \\\"{x:569,y:626,t:1527019720406};\\\", \\\"{x:570,y:625,t:1527019720477};\\\", \\\"{x:570,y:624,t:1527019720516};\\\", \\\"{x:570,y:623,t:1527019720548};\\\", \\\"{x:571,y:621,t:1527019720564};\\\", \\\"{x:572,y:620,t:1527019720579};\\\", \\\"{x:572,y:619,t:1527019720588};\\\", \\\"{x:573,y:617,t:1527019720605};\\\", \\\"{x:575,y:615,t:1527019720621};\\\", \\\"{x:575,y:614,t:1527019720638};\\\", \\\"{x:576,y:612,t:1527019720668};\\\", \\\"{x:577,y:610,t:1527019720676};\\\", \\\"{x:578,y:609,t:1527019720700};\\\", \\\"{x:578,y:608,t:1527019720708};\\\", \\\"{x:579,y:607,t:1527019720722};\\\", \\\"{x:580,y:606,t:1527019720740};\\\", \\\"{x:581,y:605,t:1527019720755};\\\", \\\"{x:582,y:604,t:1527019720772};\\\", \\\"{x:583,y:603,t:1527019720795};\\\", \\\"{x:583,y:602,t:1527019720805};\\\", \\\"{x:584,y:601,t:1527019720822};\\\", \\\"{x:585,y:599,t:1527019720852};\\\", \\\"{x:586,y:598,t:1527019720900};\\\", \\\"{x:587,y:596,t:1527019720916};\\\", \\\"{x:588,y:594,t:1527019720925};\\\", \\\"{x:589,y:592,t:1527019720940};\\\", \\\"{x:591,y:590,t:1527019720955};\\\", \\\"{x:596,y:583,t:1527019720972};\\\", \\\"{x:599,y:578,t:1527019720988};\\\", \\\"{x:602,y:573,t:1527019721005};\\\", \\\"{x:605,y:569,t:1527019721022};\\\", \\\"{x:606,y:568,t:1527019721477};\\\", \\\"{x:610,y:566,t:1527019721489};\\\", \\\"{x:616,y:563,t:1527019721505};\\\", \\\"{x:623,y:559,t:1527019721522};\\\", \\\"{x:627,y:558,t:1527019721539};\\\", \\\"{x:629,y:557,t:1527019721555};\\\", \\\"{x:633,y:555,t:1527019721572};\\\", \\\"{x:638,y:555,t:1527019721588};\\\", \\\"{x:642,y:555,t:1527019721605};\\\", \\\"{x:648,y:555,t:1527019721622};\\\", \\\"{x:655,y:555,t:1527019721639};\\\", \\\"{x:665,y:555,t:1527019721655};\\\", \\\"{x:679,y:555,t:1527019721672};\\\", \\\"{x:686,y:555,t:1527019721689};\\\", \\\"{x:692,y:554,t:1527019721705};\\\", \\\"{x:696,y:554,t:1527019721722};\\\", \\\"{x:698,y:554,t:1527019721739};\\\", \\\"{x:708,y:554,t:1527019721755};\\\", \\\"{x:722,y:558,t:1527019721773};\\\", \\\"{x:736,y:562,t:1527019721791};\\\", \\\"{x:746,y:563,t:1527019721805};\\\", \\\"{x:752,y:567,t:1527019721822};\\\", \\\"{x:755,y:568,t:1527019721839};\\\", \\\"{x:759,y:571,t:1527019721856};\\\", \\\"{x:765,y:572,t:1527019721873};\\\", \\\"{x:770,y:577,t:1527019721889};\\\", \\\"{x:776,y:579,t:1527019721906};\\\", \\\"{x:780,y:583,t:1527019721923};\\\", \\\"{x:783,y:588,t:1527019721939};\\\", \\\"{x:784,y:590,t:1527019721957};\\\", \\\"{x:786,y:594,t:1527019721973};\\\", \\\"{x:786,y:596,t:1527019721989};\\\", \\\"{x:787,y:601,t:1527019722005};\\\", \\\"{x:788,y:601,t:1527019722023};\\\", \\\"{x:789,y:602,t:1527019722039};\\\", \\\"{x:789,y:603,t:1527019722056};\\\", \\\"{x:790,y:606,t:1527019725236};\\\", \\\"{x:800,y:609,t:1527019725244};\\\", \\\"{x:813,y:613,t:1527019725259};\\\", \\\"{x:859,y:626,t:1527019725275};\\\", \\\"{x:892,y:635,t:1527019725293};\\\", \\\"{x:923,y:645,t:1527019725309};\\\", \\\"{x:975,y:666,t:1527019725325};\\\", \\\"{x:1024,y:677,t:1527019725342};\\\", \\\"{x:1071,y:689,t:1527019725359};\\\", \\\"{x:1109,y:693,t:1527019725375};\\\", \\\"{x:1137,y:698,t:1527019725392};\\\", \\\"{x:1160,y:701,t:1527019725409};\\\", \\\"{x:1175,y:702,t:1527019725425};\\\", \\\"{x:1185,y:702,t:1527019725442};\\\", \\\"{x:1190,y:702,t:1527019725459};\\\", \\\"{x:1191,y:702,t:1527019725476};\\\", \\\"{x:1192,y:702,t:1527019725581};\\\", \\\"{x:1194,y:701,t:1527019725593};\\\", \\\"{x:1199,y:696,t:1527019725609};\\\", \\\"{x:1202,y:693,t:1527019725626};\\\", \\\"{x:1205,y:686,t:1527019725642};\\\", \\\"{x:1211,y:673,t:1527019725659};\\\", \\\"{x:1216,y:665,t:1527019725676};\\\", \\\"{x:1219,y:659,t:1527019725692};\\\", \\\"{x:1220,y:657,t:1527019725710};\\\", \\\"{x:1221,y:657,t:1527019725725};\\\", \\\"{x:1221,y:656,t:1527019725743};\\\", \\\"{x:1222,y:655,t:1527019726037};\\\", \\\"{x:1226,y:652,t:1527019726052};\\\", \\\"{x:1227,y:652,t:1527019726068};\\\", \\\"{x:1228,y:652,t:1527019726212};\\\", \\\"{x:1229,y:652,t:1527019726227};\\\", \\\"{x:1230,y:652,t:1527019726244};\\\", \\\"{x:1231,y:652,t:1527019726292};\\\", \\\"{x:1236,y:653,t:1527019727579};\\\", \\\"{x:1244,y:655,t:1527019727594};\\\", \\\"{x:1261,y:659,t:1527019727610};\\\", \\\"{x:1279,y:659,t:1527019727627};\\\", \\\"{x:1293,y:658,t:1527019727644};\\\", \\\"{x:1298,y:658,t:1527019727660};\\\", \\\"{x:1300,y:658,t:1527019727677};\\\", \\\"{x:1301,y:657,t:1527019727694};\\\", \\\"{x:1303,y:655,t:1527019727837};\\\", \\\"{x:1305,y:654,t:1527019727844};\\\", \\\"{x:1306,y:653,t:1527019727861};\\\", \\\"{x:1308,y:653,t:1527019727878};\\\", \\\"{x:1309,y:651,t:1527019728316};\\\", \\\"{x:1310,y:646,t:1527019728329};\\\", \\\"{x:1317,y:635,t:1527019728345};\\\", \\\"{x:1318,y:623,t:1527019728362};\\\", \\\"{x:1318,y:605,t:1527019728380};\\\", \\\"{x:1318,y:579,t:1527019728395};\\\", \\\"{x:1317,y:554,t:1527019728411};\\\", \\\"{x:1317,y:550,t:1527019728428};\\\", \\\"{x:1317,y:547,t:1527019728444};\\\", \\\"{x:1317,y:542,t:1527019728462};\\\", \\\"{x:1317,y:535,t:1527019728478};\\\", \\\"{x:1317,y:530,t:1527019728494};\\\", \\\"{x:1317,y:524,t:1527019728512};\\\", \\\"{x:1317,y:521,t:1527019728529};\\\", \\\"{x:1317,y:517,t:1527019728545};\\\", \\\"{x:1317,y:513,t:1527019728562};\\\", \\\"{x:1317,y:506,t:1527019728578};\\\", \\\"{x:1317,y:497,t:1527019728596};\\\", \\\"{x:1317,y:489,t:1527019728612};\\\", \\\"{x:1317,y:488,t:1527019728628};\\\", \\\"{x:1317,y:487,t:1527019728645};\\\", \\\"{x:1317,y:486,t:1527019728661};\\\", \\\"{x:1317,y:485,t:1527019728678};\\\", \\\"{x:1317,y:484,t:1527019728695};\\\", \\\"{x:1317,y:482,t:1527019728712};\\\", \\\"{x:1315,y:484,t:1527019729333};\\\", \\\"{x:1312,y:490,t:1527019729346};\\\", \\\"{x:1311,y:491,t:1527019729362};\\\", \\\"{x:1311,y:492,t:1527019731238};\\\", \\\"{x:1310,y:494,t:1527019731373};\\\", \\\"{x:1310,y:498,t:1527019731380};\\\", \\\"{x:1309,y:502,t:1527019731399};\\\", \\\"{x:1308,y:506,t:1527019731413};\\\", \\\"{x:1306,y:509,t:1527019731431};\\\", \\\"{x:1306,y:510,t:1527019731448};\\\", \\\"{x:1305,y:512,t:1527019731463};\\\", \\\"{x:1304,y:513,t:1527019731491};\\\", \\\"{x:1304,y:514,t:1527019731507};\\\", \\\"{x:1303,y:516,t:1527019731515};\\\", \\\"{x:1302,y:517,t:1527019731531};\\\", \\\"{x:1302,y:519,t:1527019731547};\\\", \\\"{x:1300,y:522,t:1527019731571};\\\", \\\"{x:1300,y:524,t:1527019731580};\\\", \\\"{x:1298,y:527,t:1527019731597};\\\", \\\"{x:1296,y:535,t:1527019731615};\\\", \\\"{x:1295,y:538,t:1527019731631};\\\", \\\"{x:1294,y:540,t:1527019731648};\\\", \\\"{x:1294,y:542,t:1527019731665};\\\", \\\"{x:1294,y:543,t:1527019731681};\\\", \\\"{x:1292,y:545,t:1527019731698};\\\", \\\"{x:1292,y:546,t:1527019731724};\\\", \\\"{x:1292,y:547,t:1527019731740};\\\", \\\"{x:1291,y:547,t:1527019731748};\\\", \\\"{x:1291,y:549,t:1527019731764};\\\", \\\"{x:1290,y:550,t:1527019731781};\\\", \\\"{x:1289,y:553,t:1527019731798};\\\", \\\"{x:1285,y:558,t:1527019731815};\\\", \\\"{x:1284,y:560,t:1527019731972};\\\", \\\"{x:1283,y:561,t:1527019731983};\\\", \\\"{x:1282,y:564,t:1527019731998};\\\", \\\"{x:1281,y:564,t:1527019732014};\\\", \\\"{x:1281,y:566,t:1527019732032};\\\", \\\"{x:1280,y:567,t:1527019732048};\\\", \\\"{x:1279,y:568,t:1527019732065};\\\", \\\"{x:1279,y:569,t:1527019732082};\\\", \\\"{x:1278,y:570,t:1527019732098};\\\", \\\"{x:1278,y:572,t:1527019732116};\\\", \\\"{x:1277,y:574,t:1527019732132};\\\", \\\"{x:1276,y:578,t:1527019732148};\\\", \\\"{x:1274,y:582,t:1527019732165};\\\", \\\"{x:1273,y:586,t:1527019732182};\\\", \\\"{x:1271,y:589,t:1527019732198};\\\", \\\"{x:1270,y:592,t:1527019732215};\\\", \\\"{x:1269,y:594,t:1527019732232};\\\", \\\"{x:1268,y:596,t:1527019732248};\\\", \\\"{x:1267,y:599,t:1527019732265};\\\", \\\"{x:1267,y:601,t:1527019732284};\\\", \\\"{x:1265,y:603,t:1527019732298};\\\", \\\"{x:1264,y:604,t:1527019732315};\\\", \\\"{x:1261,y:608,t:1527019732332};\\\", \\\"{x:1260,y:610,t:1527019732348};\\\", \\\"{x:1258,y:612,t:1527019732365};\\\", \\\"{x:1257,y:613,t:1527019732382};\\\", \\\"{x:1256,y:615,t:1527019732400};\\\", \\\"{x:1254,y:616,t:1527019732415};\\\", \\\"{x:1254,y:618,t:1527019732432};\\\", \\\"{x:1252,y:619,t:1527019732449};\\\", \\\"{x:1251,y:621,t:1527019732464};\\\", \\\"{x:1249,y:624,t:1527019732481};\\\", \\\"{x:1248,y:625,t:1527019732498};\\\", \\\"{x:1247,y:626,t:1527019732514};\\\", \\\"{x:1246,y:627,t:1527019733717};\\\", \\\"{x:1245,y:628,t:1527019733733};\\\", \\\"{x:1244,y:628,t:1527019733755};\\\", \\\"{x:1238,y:630,t:1527019734221};\\\", \\\"{x:1227,y:634,t:1527019734233};\\\", \\\"{x:1190,y:639,t:1527019734250};\\\", \\\"{x:1121,y:650,t:1527019734267};\\\", \\\"{x:1032,y:661,t:1527019734283};\\\", \\\"{x:884,y:679,t:1527019734300};\\\", \\\"{x:778,y:685,t:1527019734317};\\\", \\\"{x:691,y:687,t:1527019734332};\\\", \\\"{x:676,y:687,t:1527019734350};\\\", \\\"{x:671,y:688,t:1527019734367};\\\", \\\"{x:658,y:688,t:1527019734383};\\\", \\\"{x:645,y:684,t:1527019734400};\\\", \\\"{x:633,y:678,t:1527019734418};\\\", \\\"{x:618,y:669,t:1527019734433};\\\", \\\"{x:605,y:662,t:1527019734451};\\\", \\\"{x:599,y:660,t:1527019734467};\\\", \\\"{x:579,y:658,t:1527019734483};\\\", \\\"{x:556,y:654,t:1527019734499};\\\", \\\"{x:527,y:643,t:1527019734515};\\\", \\\"{x:467,y:622,t:1527019734533};\\\", \\\"{x:395,y:589,t:1527019734550};\\\", \\\"{x:345,y:567,t:1527019734566};\\\", \\\"{x:325,y:560,t:1527019734582};\\\", \\\"{x:317,y:557,t:1527019734600};\\\", \\\"{x:316,y:557,t:1527019734615};\\\", \\\"{x:315,y:557,t:1527019734675};\\\", \\\"{x:314,y:557,t:1527019734691};\\\", \\\"{x:311,y:557,t:1527019734699};\\\", \\\"{x:308,y:559,t:1527019734716};\\\", \\\"{x:306,y:560,t:1527019734733};\\\", \\\"{x:304,y:561,t:1527019734749};\\\", \\\"{x:301,y:563,t:1527019734767};\\\", \\\"{x:297,y:565,t:1527019734783};\\\", \\\"{x:291,y:569,t:1527019734799};\\\", \\\"{x:281,y:574,t:1527019734816};\\\", \\\"{x:264,y:577,t:1527019734834};\\\", \\\"{x:233,y:578,t:1527019734849};\\\", \\\"{x:184,y:572,t:1527019734867};\\\", \\\"{x:134,y:560,t:1527019734883};\\\", \\\"{x:108,y:557,t:1527019734900};\\\", \\\"{x:101,y:553,t:1527019734916};\\\", \\\"{x:98,y:551,t:1527019734933};\\\", \\\"{x:98,y:550,t:1527019734972};\\\", \\\"{x:100,y:549,t:1527019734994};\\\", \\\"{x:101,y:549,t:1527019735003};\\\", \\\"{x:105,y:547,t:1527019735016};\\\", \\\"{x:124,y:543,t:1527019735034};\\\", \\\"{x:161,y:543,t:1527019735050};\\\", \\\"{x:241,y:553,t:1527019735067};\\\", \\\"{x:362,y:567,t:1527019735083};\\\", \\\"{x:577,y:597,t:1527019735100};\\\", \\\"{x:702,y:599,t:1527019735116};\\\", \\\"{x:811,y:606,t:1527019735133};\\\", \\\"{x:868,y:603,t:1527019735149};\\\", \\\"{x:890,y:603,t:1527019735167};\\\", \\\"{x:892,y:603,t:1527019735183};\\\", \\\"{x:892,y:601,t:1527019735200};\\\", \\\"{x:892,y:600,t:1527019735217};\\\", \\\"{x:892,y:598,t:1527019735233};\\\", \\\"{x:892,y:597,t:1527019735250};\\\", \\\"{x:890,y:592,t:1527019735268};\\\", \\\"{x:877,y:581,t:1527019735284};\\\", \\\"{x:866,y:573,t:1527019735300};\\\", \\\"{x:854,y:566,t:1527019735317};\\\", \\\"{x:841,y:558,t:1527019735334};\\\", \\\"{x:835,y:553,t:1527019735350};\\\", \\\"{x:833,y:551,t:1527019735367};\\\", \\\"{x:835,y:550,t:1527019735412};\\\", \\\"{x:836,y:550,t:1527019735427};\\\", \\\"{x:839,y:548,t:1527019735435};\\\", \\\"{x:840,y:548,t:1527019735450};\\\", \\\"{x:845,y:546,t:1527019735466};\\\", \\\"{x:847,y:545,t:1527019735483};\\\", \\\"{x:847,y:544,t:1527019735500};\\\", \\\"{x:843,y:546,t:1527019735819};\\\", \\\"{x:838,y:551,t:1527019735834};\\\", \\\"{x:817,y:573,t:1527019735851};\\\", \\\"{x:793,y:597,t:1527019735867};\\\", \\\"{x:719,y:639,t:1527019735884};\\\", \\\"{x:644,y:675,t:1527019735901};\\\", \\\"{x:625,y:685,t:1527019735916};\\\", \\\"{x:625,y:686,t:1527019735933};\\\", \\\"{x:625,y:690,t:1527019736060};\\\", \\\"{x:625,y:696,t:1527019736067};\\\", \\\"{x:617,y:705,t:1527019736084};\\\", \\\"{x:616,y:707,t:1527019736100};\\\", \\\"{x:618,y:707,t:1527019736132};\\\", \\\"{x:620,y:706,t:1527019736140};\\\", \\\"{x:623,y:704,t:1527019736151};\\\", \\\"{x:625,y:699,t:1527019736168};\\\", \\\"{x:626,y:698,t:1527019736185};\\\", \\\"{x:625,y:696,t:1527019736211};\\\", \\\"{x:619,y:695,t:1527019736219};\\\", \\\"{x:608,y:694,t:1527019736234};\\\", \\\"{x:568,y:691,t:1527019736250};\\\", \\\"{x:543,y:694,t:1527019736268};\\\", \\\"{x:515,y:701,t:1527019736284};\\\", \\\"{x:492,y:705,t:1527019736302};\\\", \\\"{x:477,y:705,t:1527019736318};\\\", \\\"{x:470,y:705,t:1527019736335};\\\", \\\"{x:468,y:705,t:1527019736352};\\\", \\\"{x:468,y:707,t:1527019736491};\\\", \\\"{x:468,y:709,t:1527019736501};\\\", \\\"{x:467,y:713,t:1527019736517};\\\", \\\"{x:467,y:718,t:1527019736534};\\\", \\\"{x:467,y:721,t:1527019736550};\\\", \\\"{x:467,y:722,t:1527019736567};\\\", \\\"{x:468,y:725,t:1527019736584};\\\", \\\"{x:470,y:725,t:1527019736600};\\\", \\\"{x:471,y:725,t:1527019736619};\\\", \\\"{x:473,y:726,t:1527019736643};\\\", \\\"{x:474,y:726,t:1527019736684};\\\", \\\"{x:476,y:726,t:1527019736803};\\\", \\\"{x:477,y:726,t:1527019736826};\\\", \\\"{x:478,y:725,t:1527019736835};\\\", \\\"{x:479,y:724,t:1527019736867};\\\", \\\"{x:480,y:724,t:1527019736883};\\\", \\\"{x:481,y:724,t:1527019736891};\\\", \\\"{x:481,y:723,t:1527019736900};\\\", \\\"{x:482,y:723,t:1527019736917};\\\", \\\"{x:484,y:722,t:1527019736934};\\\", \\\"{x:487,y:721,t:1527019736951};\\\", \\\"{x:493,y:720,t:1527019736967};\\\", \\\"{x:499,y:718,t:1527019736984};\\\", \\\"{x:510,y:716,t:1527019737002};\\\", \\\"{x:520,y:713,t:1527019737018};\\\", \\\"{x:525,y:712,t:1527019737035};\\\", \\\"{x:534,y:710,t:1527019737051};\\\", \\\"{x:535,y:709,t:1527019737067};\\\", \\\"{x:538,y:709,t:1527019737084};\\\", \\\"{x:540,y:707,t:1527019737102};\\\", \\\"{x:547,y:702,t:1527019737118};\\\", \\\"{x:559,y:696,t:1527019737135};\\\", \\\"{x:572,y:691,t:1527019737151};\\\", \\\"{x:583,y:688,t:1527019737168};\\\", \\\"{x:586,y:686,t:1527019737185};\\\", \\\"{x:591,y:683,t:1527019737202};\\\", \\\"{x:595,y:682,t:1527019737218};\\\", \\\"{x:596,y:682,t:1527019737235};\\\", \\\"{x:599,y:680,t:1527019737252};\\\", \\\"{x:601,y:679,t:1527019737275};\\\", \\\"{x:602,y:678,t:1527019737292};\\\", \\\"{x:603,y:677,t:1527019737302};\\\", \\\"{x:605,y:676,t:1527019737318};\\\", \\\"{x:609,y:673,t:1527019737335};\\\", \\\"{x:613,y:670,t:1527019737352};\\\", \\\"{x:617,y:664,t:1527019737368};\\\", \\\"{x:625,y:654,t:1527019737385};\\\", \\\"{x:629,y:650,t:1527019737402};\\\", \\\"{x:632,y:648,t:1527019737418};\\\", \\\"{x:635,y:645,t:1527019737435};\\\", \\\"{x:639,y:640,t:1527019737452};\\\", \\\"{x:640,y:638,t:1527019737469};\\\", \\\"{x:641,y:636,t:1527019737485};\\\", \\\"{x:644,y:630,t:1527019737502};\\\", \\\"{x:647,y:627,t:1527019737519};\\\", \\\"{x:650,y:622,t:1527019737535};\\\", \\\"{x:653,y:616,t:1527019737552};\\\", \\\"{x:655,y:614,t:1527019737569};\\\", \\\"{x:656,y:612,t:1527019737585};\\\", \\\"{x:656,y:611,t:1527019737602};\\\", \\\"{x:656,y:610,t:1527019737620};\\\", \\\"{x:656,y:608,t:1527019737635};\\\", \\\"{x:657,y:605,t:1527019737651};\\\", \\\"{x:657,y:604,t:1527019737668};\\\", \\\"{x:657,y:603,t:1527019737684};\\\", \\\"{x:657,y:601,t:1527019737701};\\\", \\\"{x:658,y:600,t:1527019737719};\\\", \\\"{x:658,y:598,t:1527019737734};\\\", \\\"{x:658,y:597,t:1527019737755};\\\", \\\"{x:658,y:596,t:1527019737777};\\\" ] }, { \\\"rt\\\": 14258, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 10, \\\"time_elapsed\\\": 359280, \\\"internal_node_id\\\": \\\"0.0-6.0-0.0\\\", \\\"subject\\\": \\\"VT5BG\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"golf\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration\\\", \\\"q\\\": 6, \\\"clicks\\\": 2.5, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\", \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-E \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:658,y:595,t:1527019738008};\\\", \\\"{x:658,y:593,t:1527019738035};\\\", \\\"{x:658,y:592,t:1527019738052};\\\", \\\"{x:658,y:591,t:1527019738107};\\\", \\\"{x:659,y:589,t:1527019738119};\\\", \\\"{x:659,y:587,t:1527019738332};\\\", \\\"{x:660,y:586,t:1527019738339};\\\", \\\"{x:661,y:580,t:1527019738442};\\\", \\\"{x:661,y:579,t:1527019738491};\\\", \\\"{x:661,y:577,t:1527019738674};\\\", \\\"{x:661,y:576,t:1527019738715};\\\", \\\"{x:661,y:575,t:1527019738924};\\\", \\\"{x:661,y:574,t:1527019738938};\\\", \\\"{x:662,y:572,t:1527019738955};\\\", \\\"{x:662,y:570,t:1527019738971};\\\", \\\"{x:662,y:563,t:1527019738987};\\\", \\\"{x:664,y:561,t:1527019739005};\\\", \\\"{x:664,y:560,t:1527019739021};\\\", \\\"{x:664,y:558,t:1527019739043};\\\", \\\"{x:664,y:557,t:1527019739067};\\\", \\\"{x:664,y:555,t:1527019739099};\\\", \\\"{x:664,y:554,t:1527019739115};\\\", \\\"{x:665,y:552,t:1527019739139};\\\", \\\"{x:665,y:551,t:1527019739235};\\\", \\\"{x:667,y:550,t:1527019739250};\\\", \\\"{x:669,y:549,t:1527019739259};\\\", \\\"{x:675,y:546,t:1527019739269};\\\", \\\"{x:692,y:536,t:1527019739287};\\\", \\\"{x:708,y:527,t:1527019739302};\\\", \\\"{x:719,y:520,t:1527019739320};\\\", \\\"{x:725,y:515,t:1527019739337};\\\", \\\"{x:729,y:512,t:1527019739352};\\\", \\\"{x:732,y:506,t:1527019739369};\\\", \\\"{x:740,y:495,t:1527019739386};\\\", \\\"{x:748,y:484,t:1527019739403};\\\", \\\"{x:761,y:474,t:1527019739419};\\\", \\\"{x:771,y:461,t:1527019739437};\\\", \\\"{x:776,y:455,t:1527019739454};\\\", \\\"{x:792,y:453,t:1527019739469};\\\", \\\"{x:802,y:451,t:1527019739486};\\\", \\\"{x:802,y:450,t:1527019739898};\\\", \\\"{x:801,y:449,t:1527019739914};\\\", \\\"{x:807,y:452,t:1527019740244};\\\", \\\"{x:814,y:458,t:1527019740254};\\\", \\\"{x:824,y:467,t:1527019740271};\\\", \\\"{x:830,y:472,t:1527019740288};\\\", \\\"{x:843,y:481,t:1527019740304};\\\", \\\"{x:862,y:494,t:1527019740321};\\\", \\\"{x:888,y:511,t:1527019740338};\\\", \\\"{x:925,y:528,t:1527019740354};\\\", \\\"{x:975,y:552,t:1527019740371};\\\", \\\"{x:1003,y:568,t:1527019740387};\\\", \\\"{x:1038,y:588,t:1527019740404};\\\", \\\"{x:1056,y:597,t:1527019740421};\\\", \\\"{x:1064,y:601,t:1527019740437};\\\", \\\"{x:1065,y:601,t:1527019740460};\\\", \\\"{x:1067,y:601,t:1527019740484};\\\", \\\"{x:1069,y:604,t:1527019740490};\\\", \\\"{x:1073,y:610,t:1527019740504};\\\", \\\"{x:1084,y:628,t:1527019740521};\\\", \\\"{x:1098,y:648,t:1527019740538};\\\", \\\"{x:1112,y:667,t:1527019740553};\\\", \\\"{x:1125,y:687,t:1527019740571};\\\", \\\"{x:1128,y:691,t:1527019740587};\\\", \\\"{x:1128,y:693,t:1527019740604};\\\", \\\"{x:1128,y:695,t:1527019740620};\\\", \\\"{x:1128,y:698,t:1527019740638};\\\", \\\"{x:1128,y:701,t:1527019740654};\\\", \\\"{x:1128,y:707,t:1527019740671};\\\", \\\"{x:1128,y:711,t:1527019740688};\\\", \\\"{x:1128,y:712,t:1527019740704};\\\", \\\"{x:1128,y:715,t:1527019740721};\\\", \\\"{x:1127,y:719,t:1527019740973};\\\", \\\"{x:1125,y:725,t:1527019740988};\\\", \\\"{x:1123,y:727,t:1527019741005};\\\", \\\"{x:1126,y:727,t:1527019741372};\\\", \\\"{x:1129,y:727,t:1527019741388};\\\", \\\"{x:1130,y:727,t:1527019741428};\\\", \\\"{x:1131,y:727,t:1527019741438};\\\", \\\"{x:1131,y:728,t:1527019741468};\\\", \\\"{x:1132,y:728,t:1527019741476};\\\", \\\"{x:1132,y:729,t:1527019741491};\\\", \\\"{x:1132,y:733,t:1527019741504};\\\", \\\"{x:1132,y:748,t:1527019741522};\\\", \\\"{x:1131,y:767,t:1527019741538};\\\", \\\"{x:1131,y:793,t:1527019741555};\\\", \\\"{x:1131,y:804,t:1527019741572};\\\", \\\"{x:1131,y:817,t:1527019741587};\\\", \\\"{x:1132,y:840,t:1527019741605};\\\", \\\"{x:1136,y:869,t:1527019741622};\\\", \\\"{x:1139,y:891,t:1527019741637};\\\", \\\"{x:1139,y:899,t:1527019741655};\\\", \\\"{x:1139,y:901,t:1527019741672};\\\", \\\"{x:1138,y:901,t:1527019741699};\\\", \\\"{x:1136,y:899,t:1527019741716};\\\", \\\"{x:1136,y:896,t:1527019741723};\\\", \\\"{x:1136,y:893,t:1527019741739};\\\", \\\"{x:1135,y:887,t:1527019741755};\\\", \\\"{x:1135,y:872,t:1527019741772};\\\", \\\"{x:1138,y:859,t:1527019741789};\\\", \\\"{x:1142,y:844,t:1527019741805};\\\", \\\"{x:1147,y:830,t:1527019741823};\\\", \\\"{x:1152,y:809,t:1527019741840};\\\", \\\"{x:1155,y:772,t:1527019741855};\\\", \\\"{x:1155,y:727,t:1527019741872};\\\", \\\"{x:1160,y:700,t:1527019741889};\\\", \\\"{x:1166,y:679,t:1527019741906};\\\", \\\"{x:1172,y:652,t:1527019741923};\\\", \\\"{x:1179,y:595,t:1527019741940};\\\", \\\"{x:1182,y:581,t:1527019741955};\\\", \\\"{x:1192,y:550,t:1527019741972};\\\", \\\"{x:1197,y:538,t:1527019741989};\\\", \\\"{x:1202,y:528,t:1527019742006};\\\", \\\"{x:1204,y:522,t:1527019742022};\\\", \\\"{x:1209,y:517,t:1527019742039};\\\", \\\"{x:1213,y:513,t:1527019742055};\\\", \\\"{x:1220,y:511,t:1527019742072};\\\", \\\"{x:1227,y:509,t:1527019742089};\\\", \\\"{x:1231,y:509,t:1527019742105};\\\", \\\"{x:1232,y:509,t:1527019742140};\\\", \\\"{x:1234,y:509,t:1527019742156};\\\", \\\"{x:1238,y:510,t:1527019742172};\\\", \\\"{x:1240,y:513,t:1527019742190};\\\", \\\"{x:1241,y:514,t:1527019742205};\\\", \\\"{x:1244,y:521,t:1527019742222};\\\", \\\"{x:1250,y:534,t:1527019742239};\\\", \\\"{x:1259,y:557,t:1527019742256};\\\", \\\"{x:1269,y:576,t:1527019742273};\\\", \\\"{x:1272,y:582,t:1527019742290};\\\", \\\"{x:1272,y:583,t:1527019742306};\\\", \\\"{x:1273,y:584,t:1527019742322};\\\", \\\"{x:1274,y:584,t:1527019742421};\\\", \\\"{x:1275,y:583,t:1527019742436};\\\", \\\"{x:1276,y:583,t:1527019742444};\\\", \\\"{x:1277,y:581,t:1527019742456};\\\", \\\"{x:1277,y:580,t:1527019742472};\\\", \\\"{x:1279,y:578,t:1527019742490};\\\", \\\"{x:1279,y:577,t:1527019742507};\\\", \\\"{x:1280,y:573,t:1527019742523};\\\", \\\"{x:1281,y:571,t:1527019742540};\\\", \\\"{x:1282,y:567,t:1527019742558};\\\", \\\"{x:1279,y:567,t:1527019746140};\\\", \\\"{x:1257,y:573,t:1527019746148};\\\", \\\"{x:1220,y:576,t:1527019746159};\\\", \\\"{x:1084,y:595,t:1527019746175};\\\", \\\"{x:896,y:622,t:1527019746195};\\\", \\\"{x:718,y:638,t:1527019746209};\\\", \\\"{x:566,y:638,t:1527019746224};\\\", \\\"{x:447,y:638,t:1527019746236};\\\", \\\"{x:363,y:638,t:1527019746252};\\\", \\\"{x:332,y:626,t:1527019746269};\\\", \\\"{x:327,y:621,t:1527019746286};\\\", \\\"{x:329,y:603,t:1527019746309};\\\", \\\"{x:336,y:589,t:1527019746326};\\\", \\\"{x:341,y:579,t:1527019746342};\\\", \\\"{x:345,y:572,t:1527019746359};\\\", \\\"{x:348,y:565,t:1527019746377};\\\", \\\"{x:356,y:557,t:1527019746392};\\\", \\\"{x:371,y:544,t:1527019746409};\\\", \\\"{x:387,y:531,t:1527019746427};\\\", \\\"{x:397,y:520,t:1527019746442};\\\", \\\"{x:408,y:512,t:1527019746459};\\\", \\\"{x:414,y:509,t:1527019746476};\\\", \\\"{x:427,y:507,t:1527019746492};\\\", \\\"{x:444,y:504,t:1527019746509};\\\", \\\"{x:453,y:503,t:1527019746526};\\\", \\\"{x:456,y:503,t:1527019746542};\\\", \\\"{x:457,y:502,t:1527019746560};\\\", \\\"{x:464,y:502,t:1527019746584};\\\", \\\"{x:469,y:502,t:1527019746592};\\\", \\\"{x:483,y:502,t:1527019746609};\\\", \\\"{x:497,y:501,t:1527019746626};\\\", \\\"{x:541,y:501,t:1527019746643};\\\", \\\"{x:593,y:505,t:1527019746658};\\\", \\\"{x:624,y:507,t:1527019746676};\\\", \\\"{x:636,y:507,t:1527019746692};\\\", \\\"{x:637,y:507,t:1527019746709};\\\", \\\"{x:634,y:507,t:1527019746779};\\\", \\\"{x:633,y:506,t:1527019746791};\\\", \\\"{x:626,y:504,t:1527019746809};\\\", \\\"{x:625,y:503,t:1527019746826};\\\", \\\"{x:624,y:503,t:1527019746859};\\\", \\\"{x:621,y:503,t:1527019746876};\\\", \\\"{x:615,y:508,t:1527019746892};\\\", \\\"{x:610,y:512,t:1527019746909};\\\", \\\"{x:607,y:512,t:1527019746926};\\\", \\\"{x:607,y:513,t:1527019747275};\\\", \\\"{x:610,y:515,t:1527019747283};\\\", \\\"{x:618,y:520,t:1527019747294};\\\", \\\"{x:636,y:525,t:1527019747309};\\\", \\\"{x:656,y:529,t:1527019747326};\\\", \\\"{x:671,y:531,t:1527019747343};\\\", \\\"{x:687,y:535,t:1527019747360};\\\", \\\"{x:704,y:536,t:1527019747377};\\\", \\\"{x:734,y:542,t:1527019747394};\\\", \\\"{x:760,y:544,t:1527019747410};\\\", \\\"{x:775,y:547,t:1527019747426};\\\", \\\"{x:780,y:547,t:1527019747443};\\\", \\\"{x:781,y:547,t:1527019747461};\\\", \\\"{x:783,y:547,t:1527019747532};\\\", \\\"{x:788,y:547,t:1527019747543};\\\", \\\"{x:800,y:545,t:1527019747561};\\\", \\\"{x:812,y:543,t:1527019747579};\\\", \\\"{x:814,y:543,t:1527019747593};\\\", \\\"{x:816,y:542,t:1527019747684};\\\", \\\"{x:817,y:542,t:1527019747756};\\\", \\\"{x:820,y:540,t:1527019747775};\\\", \\\"{x:822,y:539,t:1527019747793};\\\", \\\"{x:823,y:539,t:1527019747810};\\\", \\\"{x:823,y:539,t:1527019747827};\\\", \\\"{x:824,y:539,t:1527019748045};\\\", \\\"{x:831,y:539,t:1527019748093};\\\", \\\"{x:839,y:541,t:1527019748110};\\\", \\\"{x:843,y:541,t:1527019748127};\\\", \\\"{x:846,y:541,t:1527019748144};\\\", \\\"{x:847,y:543,t:1527019748160};\\\", \\\"{x:848,y:543,t:1527019748212};\\\", \\\"{x:854,y:549,t:1527019748228};\\\", \\\"{x:861,y:555,t:1527019748244};\\\", \\\"{x:865,y:559,t:1527019748260};\\\", \\\"{x:871,y:566,t:1527019748277};\\\", \\\"{x:874,y:569,t:1527019748293};\\\", \\\"{x:878,y:574,t:1527019748310};\\\", \\\"{x:883,y:578,t:1527019748327};\\\", \\\"{x:886,y:580,t:1527019748344};\\\", \\\"{x:889,y:581,t:1527019748360};\\\", \\\"{x:893,y:584,t:1527019748377};\\\", \\\"{x:903,y:589,t:1527019748394};\\\", \\\"{x:913,y:592,t:1527019748410};\\\", \\\"{x:923,y:594,t:1527019748428};\\\", \\\"{x:924,y:594,t:1527019748444};\\\", \\\"{x:925,y:594,t:1527019748467};\\\", \\\"{x:926,y:594,t:1527019748484};\\\", \\\"{x:926,y:591,t:1527019748495};\\\", \\\"{x:920,y:579,t:1527019748511};\\\", \\\"{x:912,y:573,t:1527019748527};\\\", \\\"{x:910,y:570,t:1527019748544};\\\", \\\"{x:908,y:570,t:1527019748560};\\\", \\\"{x:904,y:567,t:1527019748577};\\\", \\\"{x:896,y:564,t:1527019748594};\\\", \\\"{x:890,y:561,t:1527019748611};\\\", \\\"{x:886,y:560,t:1527019748627};\\\", \\\"{x:884,y:558,t:1527019748645};\\\", \\\"{x:878,y:554,t:1527019748661};\\\", \\\"{x:876,y:552,t:1527019748677};\\\", \\\"{x:875,y:552,t:1527019748787};\\\", \\\"{x:872,y:552,t:1527019748803};\\\", \\\"{x:869,y:551,t:1527019748811};\\\", \\\"{x:866,y:549,t:1527019748827};\\\", \\\"{x:859,y:545,t:1527019748844};\\\", \\\"{x:851,y:539,t:1527019748861};\\\", \\\"{x:849,y:538,t:1527019748877};\\\", \\\"{x:851,y:540,t:1527019749019};\\\", \\\"{x:854,y:541,t:1527019749027};\\\", \\\"{x:856,y:541,t:1527019749044};\\\", \\\"{x:860,y:543,t:1527019749212};\\\", \\\"{x:881,y:552,t:1527019749230};\\\", \\\"{x:906,y:560,t:1527019749245};\\\", \\\"{x:921,y:561,t:1527019749261};\\\", \\\"{x:930,y:561,t:1527019749278};\\\", \\\"{x:933,y:562,t:1527019749295};\\\", \\\"{x:937,y:563,t:1527019749312};\\\", \\\"{x:946,y:565,t:1527019749328};\\\", \\\"{x:958,y:566,t:1527019749345};\\\", \\\"{x:966,y:566,t:1527019749361};\\\", \\\"{x:972,y:566,t:1527019749378};\\\", \\\"{x:991,y:566,t:1527019749394};\\\", \\\"{x:1055,y:567,t:1527019749411};\\\", \\\"{x:1132,y:567,t:1527019749429};\\\", \\\"{x:1203,y:567,t:1527019749445};\\\", \\\"{x:1270,y:554,t:1527019749461};\\\", \\\"{x:1321,y:547,t:1527019749478};\\\", \\\"{x:1347,y:541,t:1527019749494};\\\", \\\"{x:1356,y:537,t:1527019749511};\\\", \\\"{x:1357,y:537,t:1527019749529};\\\", \\\"{x:1357,y:536,t:1527019749644};\\\", \\\"{x:1353,y:536,t:1527019749652};\\\", \\\"{x:1350,y:536,t:1527019749662};\\\", \\\"{x:1341,y:539,t:1527019749679};\\\", \\\"{x:1331,y:548,t:1527019749696};\\\", \\\"{x:1317,y:560,t:1527019749712};\\\", \\\"{x:1298,y:575,t:1527019749729};\\\", \\\"{x:1276,y:591,t:1527019749745};\\\", \\\"{x:1269,y:597,t:1527019749762};\\\", \\\"{x:1267,y:598,t:1527019749779};\\\", \\\"{x:1269,y:598,t:1527019749955};\\\", \\\"{x:1274,y:595,t:1527019749963};\\\", \\\"{x:1278,y:594,t:1527019749978};\\\", \\\"{x:1292,y:588,t:1527019749995};\\\", \\\"{x:1301,y:586,t:1527019750012};\\\", \\\"{x:1307,y:586,t:1527019750028};\\\", \\\"{x:1316,y:585,t:1527019750046};\\\", \\\"{x:1331,y:585,t:1527019750062};\\\", \\\"{x:1346,y:585,t:1527019750078};\\\", \\\"{x:1361,y:585,t:1527019750095};\\\", \\\"{x:1376,y:584,t:1527019750112};\\\", \\\"{x:1380,y:584,t:1527019750128};\\\", \\\"{x:1381,y:582,t:1527019750146};\\\", \\\"{x:1382,y:582,t:1527019750162};\\\", \\\"{x:1383,y:582,t:1527019750196};\\\", \\\"{x:1384,y:582,t:1527019750268};\\\", \\\"{x:1386,y:580,t:1527019750280};\\\", \\\"{x:1391,y:580,t:1527019750296};\\\", \\\"{x:1395,y:579,t:1527019750313};\\\", \\\"{x:1401,y:578,t:1527019750329};\\\", \\\"{x:1402,y:577,t:1527019750346};\\\", \\\"{x:1404,y:577,t:1527019750363};\\\", \\\"{x:1396,y:580,t:1527019751453};\\\", \\\"{x:1380,y:595,t:1527019751464};\\\", \\\"{x:1275,y:664,t:1527019751480};\\\", \\\"{x:1108,y:753,t:1527019751496};\\\", \\\"{x:909,y:847,t:1527019751513};\\\", \\\"{x:739,y:919,t:1527019751530};\\\", \\\"{x:623,y:968,t:1527019751546};\\\", \\\"{x:551,y:985,t:1527019751563};\\\", \\\"{x:545,y:985,t:1527019751580};\\\", \\\"{x:544,y:985,t:1527019751596};\\\", \\\"{x:543,y:985,t:1527019751619};\\\", \\\"{x:543,y:983,t:1527019751630};\\\", \\\"{x:535,y:967,t:1527019751646};\\\", \\\"{x:516,y:945,t:1527019751663};\\\", \\\"{x:503,y:927,t:1527019751681};\\\", \\\"{x:500,y:922,t:1527019751697};\\\", \\\"{x:500,y:911,t:1527019751713};\\\", \\\"{x:503,y:892,t:1527019751730};\\\", \\\"{x:508,y:856,t:1527019751746};\\\", \\\"{x:515,y:813,t:1527019751763};\\\", \\\"{x:517,y:796,t:1527019751780};\\\", \\\"{x:519,y:790,t:1527019751797};\\\", \\\"{x:519,y:787,t:1527019751814};\\\", \\\"{x:520,y:785,t:1527019751830};\\\", \\\"{x:520,y:783,t:1527019751846};\\\", \\\"{x:520,y:775,t:1527019751864};\\\", \\\"{x:522,y:770,t:1527019751881};\\\", \\\"{x:522,y:764,t:1527019751897};\\\", \\\"{x:522,y:759,t:1527019751913};\\\", \\\"{x:522,y:757,t:1527019751931};\\\", \\\"{x:522,y:756,t:1527019752027};\\\", \\\"{x:522,y:754,t:1527019752036};\\\", \\\"{x:522,y:753,t:1527019752047};\\\", \\\"{x:522,y:752,t:1527019752063};\\\", \\\"{x:522,y:748,t:1527019752076};\\\", \\\"{x:522,y:742,t:1527019752093};\\\", \\\"{x:523,y:737,t:1527019752110};\\\", \\\"{x:523,y:731,t:1527019752124};\\\", \\\"{x:523,y:730,t:1527019752141};\\\" ] }, { \\\"rt\\\": 36031, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 11, \\\"time_elapsed\\\": 396622, \\\"internal_node_id\\\": \\\"0.0-6.0-1.0\\\", \\\"subject\\\": \\\"VT5BG\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"golf\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+starts\\\", \\\"q\\\": 7, \\\"clicks\\\": 2.5, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"X\\\", \\\"O\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-6-F -X \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:525,y:729,t:1527019756594};\\\", \\\"{x:537,y:728,t:1527019756614};\\\", \\\"{x:552,y:719,t:1527019756631};\\\", \\\"{x:573,y:707,t:1527019756648};\\\", \\\"{x:616,y:698,t:1527019756665};\\\", \\\"{x:644,y:698,t:1527019756681};\\\", \\\"{x:668,y:697,t:1527019756698};\\\", \\\"{x:671,y:697,t:1527019756715};\\\", \\\"{x:672,y:697,t:1527019757121};\\\", \\\"{x:673,y:697,t:1527019757202};\\\", \\\"{x:675,y:696,t:1527019757215};\\\", \\\"{x:680,y:693,t:1527019757233};\\\", \\\"{x:685,y:689,t:1527019757249};\\\", \\\"{x:689,y:687,t:1527019757266};\\\", \\\"{x:693,y:686,t:1527019757283};\\\", \\\"{x:697,y:685,t:1527019757298};\\\", \\\"{x:703,y:684,t:1527019757316};\\\", \\\"{x:712,y:684,t:1527019757333};\\\", \\\"{x:719,y:684,t:1527019757348};\\\", \\\"{x:725,y:684,t:1527019757366};\\\", \\\"{x:732,y:684,t:1527019757382};\\\", \\\"{x:739,y:684,t:1527019757398};\\\", \\\"{x:746,y:682,t:1527019757415};\\\", \\\"{x:756,y:682,t:1527019757433};\\\", \\\"{x:773,y:682,t:1527019757449};\\\", \\\"{x:784,y:682,t:1527019757466};\\\", \\\"{x:790,y:682,t:1527019757482};\\\", \\\"{x:795,y:682,t:1527019757499};\\\", \\\"{x:797,y:682,t:1527019757516};\\\", \\\"{x:800,y:682,t:1527019757533};\\\", \\\"{x:802,y:682,t:1527019757549};\\\", \\\"{x:804,y:681,t:1527019757566};\\\", \\\"{x:806,y:681,t:1527019757583};\\\", \\\"{x:808,y:680,t:1527019757600};\\\", \\\"{x:809,y:679,t:1527019757615};\\\", \\\"{x:810,y:679,t:1527019757641};\\\", \\\"{x:811,y:678,t:1527019757649};\\\", \\\"{x:812,y:678,t:1527019757842};\\\", \\\"{x:812,y:677,t:1527019758234};\\\", \\\"{x:813,y:677,t:1527019758290};\\\", \\\"{x:814,y:676,t:1527019761521};\\\", \\\"{x:814,y:674,t:1527019761545};\\\", \\\"{x:814,y:671,t:1527019761552};\\\", \\\"{x:814,y:669,t:1527019761568};\\\", \\\"{x:814,y:667,t:1527019761586};\\\", \\\"{x:814,y:666,t:1527019761602};\\\", \\\"{x:814,y:665,t:1527019761641};\\\", \\\"{x:814,y:664,t:1527019761656};\\\", \\\"{x:814,y:662,t:1527019761688};\\\", \\\"{x:815,y:662,t:1527019761702};\\\", \\\"{x:815,y:661,t:1527019761721};\\\", \\\"{x:815,y:660,t:1527019761737};\\\", \\\"{x:815,y:659,t:1527019761752};\\\", \\\"{x:815,y:658,t:1527019761768};\\\", \\\"{x:816,y:656,t:1527019761785};\\\", \\\"{x:816,y:654,t:1527019761802};\\\", \\\"{x:818,y:651,t:1527019761819};\\\", \\\"{x:818,y:649,t:1527019761835};\\\", \\\"{x:818,y:646,t:1527019761852};\\\", \\\"{x:819,y:644,t:1527019761869};\\\", \\\"{x:819,y:639,t:1527019761885};\\\", \\\"{x:819,y:636,t:1527019761903};\\\", \\\"{x:820,y:631,t:1527019761920};\\\", \\\"{x:820,y:629,t:1527019761935};\\\", \\\"{x:822,y:622,t:1527019761953};\\\", \\\"{x:822,y:617,t:1527019761970};\\\", \\\"{x:822,y:613,t:1527019761985};\\\", \\\"{x:822,y:610,t:1527019762002};\\\", \\\"{x:822,y:601,t:1527019762019};\\\", \\\"{x:822,y:598,t:1527019762036};\\\", \\\"{x:822,y:595,t:1527019762052};\\\", \\\"{x:822,y:592,t:1527019762070};\\\", \\\"{x:822,y:589,t:1527019762085};\\\", \\\"{x:822,y:587,t:1527019762102};\\\", \\\"{x:822,y:585,t:1527019762119};\\\", \\\"{x:822,y:583,t:1527019762135};\\\", \\\"{x:822,y:582,t:1527019762152};\\\", \\\"{x:822,y:580,t:1527019762170};\\\", \\\"{x:822,y:579,t:1527019762217};\\\", \\\"{x:822,y:577,t:1527019762241};\\\", \\\"{x:822,y:576,t:1527019762265};\\\", \\\"{x:823,y:574,t:1527019762305};\\\", \\\"{x:824,y:573,t:1527019762322};\\\", \\\"{x:825,y:572,t:1527019762337};\\\", \\\"{x:826,y:572,t:1527019762360};\\\", \\\"{x:827,y:571,t:1527019762385};\\\", \\\"{x:829,y:570,t:1527019762544};\\\", \\\"{x:838,y:570,t:1527019766282};\\\", \\\"{x:850,y:570,t:1527019766289};\\\", \\\"{x:880,y:571,t:1527019766307};\\\", \\\"{x:911,y:574,t:1527019766323};\\\", \\\"{x:949,y:574,t:1527019766339};\\\", \\\"{x:983,y:574,t:1527019766355};\\\", \\\"{x:1009,y:574,t:1527019766372};\\\", \\\"{x:1023,y:574,t:1527019766389};\\\", \\\"{x:1030,y:571,t:1527019766406};\\\", \\\"{x:1038,y:568,t:1527019766422};\\\", \\\"{x:1046,y:565,t:1527019766439};\\\", \\\"{x:1062,y:561,t:1527019766456};\\\", \\\"{x:1096,y:557,t:1527019766473};\\\", \\\"{x:1121,y:557,t:1527019766490};\\\", \\\"{x:1139,y:557,t:1527019766507};\\\", \\\"{x:1148,y:557,t:1527019766523};\\\", \\\"{x:1156,y:557,t:1527019766540};\\\", \\\"{x:1166,y:558,t:1527019766557};\\\", \\\"{x:1178,y:560,t:1527019766572};\\\", \\\"{x:1183,y:561,t:1527019766590};\\\", \\\"{x:1186,y:561,t:1527019766606};\\\", \\\"{x:1189,y:561,t:1527019766623};\\\", \\\"{x:1193,y:561,t:1527019766640};\\\", \\\"{x:1206,y:563,t:1527019766657};\\\", \\\"{x:1215,y:567,t:1527019766673};\\\", \\\"{x:1229,y:571,t:1527019766689};\\\", \\\"{x:1238,y:575,t:1527019766707};\\\", \\\"{x:1244,y:577,t:1527019766723};\\\", \\\"{x:1253,y:586,t:1527019766740};\\\", \\\"{x:1267,y:601,t:1527019766756};\\\", \\\"{x:1279,y:613,t:1527019766773};\\\", \\\"{x:1288,y:621,t:1527019766789};\\\", \\\"{x:1289,y:621,t:1527019766807};\\\", \\\"{x:1290,y:621,t:1527019766823};\\\", \\\"{x:1290,y:623,t:1527019766938};\\\", \\\"{x:1290,y:624,t:1527019766945};\\\", \\\"{x:1290,y:628,t:1527019766958};\\\", \\\"{x:1289,y:631,t:1527019766974};\\\", \\\"{x:1288,y:633,t:1527019767026};\\\", \\\"{x:1288,y:634,t:1527019767129};\\\", \\\"{x:1287,y:634,t:1527019767140};\\\", \\\"{x:1287,y:635,t:1527019767161};\\\", \\\"{x:1286,y:635,t:1527019767174};\\\", \\\"{x:1285,y:637,t:1527019767190};\\\", \\\"{x:1282,y:641,t:1527019767207};\\\", \\\"{x:1282,y:642,t:1527019771250};\\\", \\\"{x:1284,y:642,t:1527019771261};\\\", \\\"{x:1291,y:647,t:1527019771277};\\\", \\\"{x:1307,y:652,t:1527019771294};\\\", \\\"{x:1316,y:656,t:1527019771310};\\\", \\\"{x:1320,y:656,t:1527019771327};\\\", \\\"{x:1320,y:658,t:1527019771521};\\\", \\\"{x:1320,y:665,t:1527019771528};\\\", \\\"{x:1315,y:681,t:1527019771544};\\\", \\\"{x:1297,y:733,t:1527019771560};\\\", \\\"{x:1288,y:767,t:1527019771577};\\\", \\\"{x:1288,y:768,t:1527019771594};\\\", \\\"{x:1288,y:767,t:1527019771632};\\\", \\\"{x:1288,y:766,t:1527019771644};\\\", \\\"{x:1288,y:764,t:1527019771660};\\\", \\\"{x:1290,y:761,t:1527019771678};\\\", \\\"{x:1294,y:757,t:1527019771694};\\\", \\\"{x:1300,y:747,t:1527019771710};\\\", \\\"{x:1306,y:741,t:1527019771727};\\\", \\\"{x:1313,y:733,t:1527019771745};\\\", \\\"{x:1316,y:729,t:1527019771761};\\\", \\\"{x:1319,y:725,t:1527019771777};\\\", \\\"{x:1322,y:723,t:1527019771795};\\\", \\\"{x:1324,y:720,t:1527019771810};\\\", \\\"{x:1325,y:720,t:1527019771828};\\\", \\\"{x:1326,y:719,t:1527019771882};\\\", \\\"{x:1328,y:718,t:1527019771895};\\\", \\\"{x:1329,y:716,t:1527019771911};\\\", \\\"{x:1330,y:714,t:1527019771927};\\\", \\\"{x:1331,y:713,t:1527019771945};\\\", \\\"{x:1331,y:712,t:1527019771969};\\\", \\\"{x:1331,y:711,t:1527019771977};\\\", \\\"{x:1331,y:710,t:1527019772001};\\\", \\\"{x:1332,y:709,t:1527019772017};\\\", \\\"{x:1332,y:708,t:1527019772041};\\\", \\\"{x:1332,y:707,t:1527019772066};\\\", \\\"{x:1332,y:706,t:1527019772114};\\\", \\\"{x:1332,y:705,t:1527019772128};\\\", \\\"{x:1334,y:703,t:1527019772145};\\\", \\\"{x:1335,y:699,t:1527019772161};\\\", \\\"{x:1337,y:696,t:1527019772177};\\\", \\\"{x:1338,y:694,t:1527019772195};\\\", \\\"{x:1339,y:694,t:1527019772212};\\\", \\\"{x:1340,y:692,t:1527019772228};\\\", \\\"{x:1340,y:691,t:1527019772244};\\\", \\\"{x:1341,y:690,t:1527019772261};\\\", \\\"{x:1341,y:689,t:1527019772281};\\\", \\\"{x:1342,y:689,t:1527019772294};\\\", \\\"{x:1342,y:687,t:1527019772311};\\\", \\\"{x:1343,y:686,t:1527019772329};\\\", \\\"{x:1343,y:687,t:1527019774273};\\\", \\\"{x:1343,y:688,t:1527019774281};\\\", \\\"{x:1343,y:690,t:1527019774296};\\\", \\\"{x:1341,y:694,t:1527019774312};\\\", \\\"{x:1337,y:704,t:1527019774329};\\\", \\\"{x:1334,y:711,t:1527019774346};\\\", \\\"{x:1331,y:718,t:1527019774362};\\\", \\\"{x:1327,y:727,t:1527019774379};\\\", \\\"{x:1322,y:740,t:1527019774396};\\\", \\\"{x:1318,y:752,t:1527019774412};\\\", \\\"{x:1313,y:767,t:1527019774429};\\\", \\\"{x:1312,y:781,t:1527019774446};\\\", \\\"{x:1310,y:799,t:1527019774463};\\\", \\\"{x:1306,y:819,t:1527019774479};\\\", \\\"{x:1306,y:841,t:1527019774496};\\\", \\\"{x:1308,y:872,t:1527019774512};\\\", \\\"{x:1313,y:887,t:1527019774529};\\\", \\\"{x:1317,y:896,t:1527019774547};\\\", \\\"{x:1320,y:908,t:1527019774564};\\\", \\\"{x:1327,y:924,t:1527019774580};\\\", \\\"{x:1328,y:931,t:1527019774596};\\\", \\\"{x:1329,y:942,t:1527019774613};\\\", \\\"{x:1330,y:948,t:1527019774629};\\\", \\\"{x:1330,y:950,t:1527019774646};\\\", \\\"{x:1330,y:951,t:1527019774663};\\\", \\\"{x:1330,y:955,t:1527019774679};\\\", \\\"{x:1330,y:958,t:1527019774696};\\\", \\\"{x:1330,y:966,t:1527019774713};\\\", \\\"{x:1327,y:971,t:1527019774729};\\\", \\\"{x:1322,y:979,t:1527019774746};\\\", \\\"{x:1318,y:987,t:1527019774763};\\\", \\\"{x:1316,y:996,t:1527019774780};\\\", \\\"{x:1312,y:1002,t:1527019774796};\\\", \\\"{x:1309,y:1007,t:1527019774813};\\\", \\\"{x:1307,y:1009,t:1527019774829};\\\", \\\"{x:1304,y:1011,t:1527019774847};\\\", \\\"{x:1303,y:1012,t:1527019774864};\\\", \\\"{x:1303,y:1010,t:1527019775050};\\\", \\\"{x:1303,y:1009,t:1527019775065};\\\", \\\"{x:1303,y:1006,t:1527019775080};\\\", \\\"{x:1302,y:1003,t:1527019775097};\\\", \\\"{x:1302,y:999,t:1527019775114};\\\", \\\"{x:1302,y:997,t:1527019775131};\\\", \\\"{x:1302,y:996,t:1527019775146};\\\", \\\"{x:1302,y:992,t:1527019775164};\\\", \\\"{x:1302,y:990,t:1527019775181};\\\", \\\"{x:1303,y:988,t:1527019775197};\\\", \\\"{x:1307,y:982,t:1527019775213};\\\", \\\"{x:1313,y:973,t:1527019775230};\\\", \\\"{x:1317,y:968,t:1527019775246};\\\", \\\"{x:1318,y:966,t:1527019775263};\\\", \\\"{x:1319,y:965,t:1527019775280};\\\", \\\"{x:1321,y:964,t:1527019775297};\\\", \\\"{x:1328,y:960,t:1527019775313};\\\", \\\"{x:1336,y:956,t:1527019775331};\\\", \\\"{x:1342,y:952,t:1527019775347};\\\", \\\"{x:1345,y:949,t:1527019775363};\\\", \\\"{x:1347,y:948,t:1527019775379};\\\", \\\"{x:1348,y:948,t:1527019775553};\\\", \\\"{x:1349,y:953,t:1527019775569};\\\", \\\"{x:1349,y:957,t:1527019775580};\\\", \\\"{x:1351,y:962,t:1527019775597};\\\", \\\"{x:1352,y:963,t:1527019775614};\\\", \\\"{x:1352,y:964,t:1527019776714};\\\", \\\"{x:1353,y:965,t:1527019776732};\\\", \\\"{x:1355,y:966,t:1527019776748};\\\", \\\"{x:1356,y:967,t:1527019776765};\\\", \\\"{x:1359,y:967,t:1527019776782};\\\", \\\"{x:1364,y:967,t:1527019776799};\\\", \\\"{x:1368,y:967,t:1527019776815};\\\", \\\"{x:1372,y:967,t:1527019776832};\\\", \\\"{x:1373,y:967,t:1527019776849};\\\", \\\"{x:1376,y:967,t:1527019776865};\\\", \\\"{x:1380,y:967,t:1527019776882};\\\", \\\"{x:1387,y:967,t:1527019776898};\\\", \\\"{x:1393,y:967,t:1527019776915};\\\", \\\"{x:1397,y:967,t:1527019776932};\\\", \\\"{x:1398,y:966,t:1527019776949};\\\", \\\"{x:1400,y:966,t:1527019776965};\\\", \\\"{x:1403,y:964,t:1527019776982};\\\", \\\"{x:1409,y:964,t:1527019776998};\\\", \\\"{x:1417,y:964,t:1527019777015};\\\", \\\"{x:1421,y:964,t:1527019777032};\\\", \\\"{x:1424,y:963,t:1527019777049};\\\", \\\"{x:1423,y:963,t:1527019777282};\\\", \\\"{x:1421,y:965,t:1527019777299};\\\", \\\"{x:1420,y:967,t:1527019777316};\\\", \\\"{x:1420,y:964,t:1527019777898};\\\", \\\"{x:1425,y:940,t:1527019777916};\\\", \\\"{x:1433,y:902,t:1527019777933};\\\", \\\"{x:1446,y:860,t:1527019777949};\\\", \\\"{x:1453,y:831,t:1527019777965};\\\", \\\"{x:1462,y:809,t:1527019777982};\\\", \\\"{x:1472,y:793,t:1527019778000};\\\", \\\"{x:1479,y:779,t:1527019778016};\\\", \\\"{x:1488,y:762,t:1527019778033};\\\", \\\"{x:1494,y:753,t:1527019778049};\\\", \\\"{x:1500,y:742,t:1527019778066};\\\", \\\"{x:1505,y:735,t:1527019778083};\\\", \\\"{x:1510,y:729,t:1527019778100};\\\", \\\"{x:1513,y:725,t:1527019778115};\\\", \\\"{x:1516,y:722,t:1527019778133};\\\", \\\"{x:1518,y:718,t:1527019778150};\\\", \\\"{x:1519,y:716,t:1527019778165};\\\", \\\"{x:1519,y:718,t:1527019778282};\\\", \\\"{x:1518,y:722,t:1527019778300};\\\", \\\"{x:1518,y:723,t:1527019778316};\\\", \\\"{x:1517,y:723,t:1527019778333};\\\", \\\"{x:1517,y:724,t:1527019778350};\\\", \\\"{x:1516,y:726,t:1527019778366};\\\", \\\"{x:1515,y:728,t:1527019778382};\\\", \\\"{x:1514,y:731,t:1527019778400};\\\", \\\"{x:1512,y:735,t:1527019778417};\\\", \\\"{x:1512,y:736,t:1527019778441};\\\", \\\"{x:1512,y:737,t:1527019778449};\\\", \\\"{x:1512,y:738,t:1527019778466};\\\", \\\"{x:1511,y:739,t:1527019778483};\\\", \\\"{x:1511,y:741,t:1527019778500};\\\", \\\"{x:1509,y:744,t:1527019778517};\\\", \\\"{x:1508,y:747,t:1527019778536};\\\", \\\"{x:1504,y:753,t:1527019778550};\\\", \\\"{x:1504,y:758,t:1527019778567};\\\", \\\"{x:1503,y:761,t:1527019778584};\\\", \\\"{x:1500,y:765,t:1527019778600};\\\", \\\"{x:1497,y:772,t:1527019778617};\\\", \\\"{x:1493,y:778,t:1527019778633};\\\", \\\"{x:1488,y:791,t:1527019778650};\\\", \\\"{x:1482,y:802,t:1527019778667};\\\", \\\"{x:1481,y:808,t:1527019778683};\\\", \\\"{x:1481,y:809,t:1527019778700};\\\", \\\"{x:1479,y:811,t:1527019778738};\\\", \\\"{x:1479,y:812,t:1527019778750};\\\", \\\"{x:1478,y:814,t:1527019778767};\\\", \\\"{x:1475,y:820,t:1527019778783};\\\", \\\"{x:1473,y:826,t:1527019778800};\\\", \\\"{x:1470,y:832,t:1527019778816};\\\", \\\"{x:1470,y:833,t:1527019778833};\\\", \\\"{x:1469,y:835,t:1527019778856};\\\", \\\"{x:1464,y:835,t:1527019780281};\\\", \\\"{x:1449,y:834,t:1527019780289};\\\", \\\"{x:1416,y:831,t:1527019780301};\\\", \\\"{x:1302,y:815,t:1527019780318};\\\", \\\"{x:1175,y:798,t:1527019780335};\\\", \\\"{x:1060,y:778,t:1527019780351};\\\", \\\"{x:940,y:751,t:1527019780368};\\\", \\\"{x:764,y:712,t:1527019780385};\\\", \\\"{x:641,y:685,t:1527019780401};\\\", \\\"{x:526,y:658,t:1527019780418};\\\", \\\"{x:425,y:638,t:1527019780434};\\\", \\\"{x:369,y:632,t:1527019780451};\\\", \\\"{x:347,y:632,t:1527019780468};\\\", \\\"{x:335,y:633,t:1527019780485};\\\", \\\"{x:327,y:633,t:1527019780501};\\\", \\\"{x:322,y:635,t:1527019780517};\\\", \\\"{x:319,y:635,t:1527019780534};\\\", \\\"{x:317,y:635,t:1527019780550};\\\", \\\"{x:314,y:636,t:1527019780568};\\\", \\\"{x:307,y:636,t:1527019780584};\\\", \\\"{x:305,y:636,t:1527019780601};\\\", \\\"{x:298,y:636,t:1527019780617};\\\", \\\"{x:290,y:636,t:1527019780634};\\\", \\\"{x:286,y:636,t:1527019780651};\\\", \\\"{x:283,y:639,t:1527019780668};\\\", \\\"{x:282,y:639,t:1527019780684};\\\", \\\"{x:284,y:639,t:1527019780777};\\\", \\\"{x:291,y:639,t:1527019780784};\\\", \\\"{x:311,y:639,t:1527019780800};\\\", \\\"{x:326,y:638,t:1527019780818};\\\", \\\"{x:335,y:634,t:1527019780834};\\\", \\\"{x:347,y:634,t:1527019780851};\\\", \\\"{x:363,y:636,t:1527019780867};\\\", \\\"{x:386,y:641,t:1527019780885};\\\", \\\"{x:413,y:642,t:1527019780902};\\\", \\\"{x:442,y:642,t:1527019780917};\\\", \\\"{x:454,y:642,t:1527019780934};\\\", \\\"{x:459,y:641,t:1527019780951};\\\", \\\"{x:462,y:638,t:1527019780968};\\\", \\\"{x:462,y:637,t:1527019780984};\\\", \\\"{x:462,y:633,t:1527019781001};\\\", \\\"{x:462,y:626,t:1527019781019};\\\", \\\"{x:460,y:618,t:1527019781034};\\\", \\\"{x:454,y:607,t:1527019781051};\\\", \\\"{x:452,y:605,t:1527019781068};\\\", \\\"{x:449,y:602,t:1527019782082};\\\", \\\"{x:443,y:599,t:1527019782090};\\\", \\\"{x:439,y:598,t:1527019782103};\\\", \\\"{x:428,y:594,t:1527019782118};\\\", \\\"{x:424,y:591,t:1527019782136};\\\", \\\"{x:423,y:591,t:1527019782152};\\\", \\\"{x:422,y:591,t:1527019782232};\\\", \\\"{x:421,y:591,t:1527019782240};\\\", \\\"{x:420,y:591,t:1527019782252};\\\", \\\"{x:416,y:590,t:1527019782269};\\\", \\\"{x:411,y:590,t:1527019782285};\\\", \\\"{x:403,y:590,t:1527019782302};\\\", \\\"{x:386,y:593,t:1527019782320};\\\", \\\"{x:361,y:598,t:1527019782336};\\\", \\\"{x:331,y:602,t:1527019782352};\\\", \\\"{x:317,y:604,t:1527019782369};\\\", \\\"{x:309,y:605,t:1527019782385};\\\", \\\"{x:304,y:605,t:1527019782402};\\\", \\\"{x:299,y:605,t:1527019782419};\\\", \\\"{x:295,y:605,t:1527019782435};\\\", \\\"{x:294,y:605,t:1527019782452};\\\", \\\"{x:293,y:605,t:1527019782470};\\\", \\\"{x:288,y:604,t:1527019782485};\\\", \\\"{x:278,y:602,t:1527019782503};\\\", \\\"{x:260,y:599,t:1527019782520};\\\", \\\"{x:236,y:597,t:1527019782535};\\\", \\\"{x:202,y:591,t:1527019782553};\\\", \\\"{x:183,y:588,t:1527019782570};\\\", \\\"{x:167,y:586,t:1527019782586};\\\", \\\"{x:156,y:585,t:1527019782602};\\\", \\\"{x:151,y:583,t:1527019782619};\\\", \\\"{x:147,y:583,t:1527019782635};\\\", \\\"{x:145,y:583,t:1527019782652};\\\", \\\"{x:152,y:585,t:1527019782689};\\\", \\\"{x:170,y:589,t:1527019782703};\\\", \\\"{x:222,y:591,t:1527019782719};\\\", \\\"{x:346,y:583,t:1527019782738};\\\", \\\"{x:445,y:571,t:1527019782752};\\\", \\\"{x:556,y:555,t:1527019782771};\\\", \\\"{x:665,y:551,t:1527019782786};\\\", \\\"{x:754,y:551,t:1527019782803};\\\", \\\"{x:807,y:551,t:1527019782819};\\\", \\\"{x:827,y:551,t:1527019782836};\\\", \\\"{x:832,y:551,t:1527019782852};\\\", \\\"{x:832,y:550,t:1527019782869};\\\", \\\"{x:832,y:553,t:1527019783000};\\\", \\\"{x:819,y:560,t:1527019783020};\\\", \\\"{x:802,y:570,t:1527019783037};\\\", \\\"{x:780,y:579,t:1527019783053};\\\", \\\"{x:772,y:583,t:1527019783070};\\\", \\\"{x:771,y:583,t:1527019783145};\\\", \\\"{x:770,y:586,t:1527019783154};\\\", \\\"{x:769,y:596,t:1527019783169};\\\", \\\"{x:769,y:602,t:1527019783186};\\\", \\\"{x:773,y:604,t:1527019783203};\\\", \\\"{x:775,y:604,t:1527019783219};\\\", \\\"{x:780,y:606,t:1527019783236};\\\", \\\"{x:784,y:606,t:1527019783253};\\\", \\\"{x:790,y:606,t:1527019783270};\\\", \\\"{x:800,y:602,t:1527019783287};\\\", \\\"{x:821,y:596,t:1527019783304};\\\", \\\"{x:856,y:585,t:1527019783321};\\\", \\\"{x:867,y:580,t:1527019783336};\\\", \\\"{x:866,y:580,t:1527019783641};\\\", \\\"{x:866,y:580,t:1527019783668};\\\", \\\"{x:865,y:580,t:1527019783712};\\\", \\\"{x:863,y:579,t:1527019783720};\\\", \\\"{x:862,y:578,t:1527019783752};\\\", \\\"{x:861,y:577,t:1527019783993};\\\", \\\"{x:857,y:575,t:1527019784008};\\\", \\\"{x:848,y:575,t:1527019784021};\\\", \\\"{x:831,y:575,t:1527019784038};\\\", \\\"{x:816,y:575,t:1527019784054};\\\", \\\"{x:805,y:575,t:1527019784070};\\\", \\\"{x:803,y:576,t:1527019784087};\\\", \\\"{x:800,y:576,t:1527019784103};\\\", \\\"{x:781,y:581,t:1527019784120};\\\", \\\"{x:764,y:585,t:1527019784137};\\\", \\\"{x:749,y:586,t:1527019784153};\\\", \\\"{x:738,y:586,t:1527019784171};\\\", \\\"{x:723,y:586,t:1527019784188};\\\", \\\"{x:710,y:587,t:1527019784203};\\\", \\\"{x:700,y:590,t:1527019784220};\\\", \\\"{x:687,y:592,t:1527019784238};\\\", \\\"{x:671,y:596,t:1527019784254};\\\", \\\"{x:653,y:600,t:1527019784270};\\\", \\\"{x:633,y:601,t:1527019784288};\\\", \\\"{x:604,y:601,t:1527019784304};\\\", \\\"{x:584,y:601,t:1527019784320};\\\", \\\"{x:567,y:601,t:1527019784338};\\\", \\\"{x:553,y:601,t:1527019784354};\\\", \\\"{x:543,y:601,t:1527019784371};\\\", \\\"{x:526,y:600,t:1527019784388};\\\", \\\"{x:506,y:600,t:1527019784404};\\\", \\\"{x:481,y:599,t:1527019784421};\\\", \\\"{x:458,y:594,t:1527019784438};\\\", \\\"{x:441,y:594,t:1527019784454};\\\", \\\"{x:423,y:594,t:1527019784470};\\\", \\\"{x:404,y:594,t:1527019784487};\\\", \\\"{x:372,y:594,t:1527019784504};\\\", \\\"{x:355,y:594,t:1527019784520};\\\", \\\"{x:341,y:592,t:1527019784538};\\\", \\\"{x:332,y:589,t:1527019784554};\\\", \\\"{x:324,y:588,t:1527019784570};\\\", \\\"{x:322,y:586,t:1527019784587};\\\", \\\"{x:321,y:586,t:1527019784605};\\\", \\\"{x:320,y:586,t:1527019784721};\\\", \\\"{x:317,y:586,t:1527019784937};\\\", \\\"{x:310,y:586,t:1527019784954};\\\", \\\"{x:295,y:586,t:1527019784972};\\\", \\\"{x:277,y:586,t:1527019784988};\\\", \\\"{x:266,y:587,t:1527019785007};\\\", \\\"{x:257,y:596,t:1527019785022};\\\", \\\"{x:252,y:602,t:1527019785038};\\\", \\\"{x:247,y:608,t:1527019785054};\\\", \\\"{x:243,y:614,t:1527019785071};\\\", \\\"{x:242,y:617,t:1527019785087};\\\", \\\"{x:240,y:623,t:1527019785104};\\\", \\\"{x:239,y:624,t:1527019785121};\\\", \\\"{x:238,y:626,t:1527019785137};\\\", \\\"{x:236,y:623,t:1527019785305};\\\", \\\"{x:233,y:610,t:1527019785322};\\\", \\\"{x:228,y:593,t:1527019785340};\\\", \\\"{x:224,y:584,t:1527019785354};\\\", \\\"{x:224,y:581,t:1527019785371};\\\", \\\"{x:232,y:573,t:1527019785389};\\\", \\\"{x:249,y:565,t:1527019785405};\\\", \\\"{x:267,y:557,t:1527019785422};\\\", \\\"{x:274,y:553,t:1527019785440};\\\", \\\"{x:283,y:549,t:1527019785454};\\\", \\\"{x:286,y:548,t:1527019785471};\\\", \\\"{x:293,y:545,t:1527019785488};\\\", \\\"{x:302,y:544,t:1527019785505};\\\", \\\"{x:316,y:541,t:1527019785521};\\\", \\\"{x:326,y:541,t:1527019785539};\\\", \\\"{x:336,y:541,t:1527019785554};\\\", \\\"{x:343,y:540,t:1527019785571};\\\", \\\"{x:345,y:540,t:1527019785589};\\\", \\\"{x:347,y:539,t:1527019785605};\\\", \\\"{x:349,y:537,t:1527019785622};\\\", \\\"{x:354,y:535,t:1527019785638};\\\", \\\"{x:361,y:533,t:1527019785655};\\\", \\\"{x:365,y:532,t:1527019785671};\\\", \\\"{x:368,y:531,t:1527019785689};\\\", \\\"{x:370,y:531,t:1527019785825};\\\", \\\"{x:372,y:534,t:1527019785839};\\\", \\\"{x:379,y:547,t:1527019785857};\\\", \\\"{x:387,y:561,t:1527019785873};\\\", \\\"{x:396,y:585,t:1527019785890};\\\", \\\"{x:404,y:598,t:1527019785906};\\\", \\\"{x:409,y:610,t:1527019785922};\\\", \\\"{x:414,y:619,t:1527019785938};\\\", \\\"{x:416,y:623,t:1527019785956};\\\", \\\"{x:416,y:624,t:1527019785971};\\\", \\\"{x:416,y:626,t:1527019785992};\\\", \\\"{x:417,y:627,t:1527019786006};\\\", \\\"{x:418,y:630,t:1527019786022};\\\", \\\"{x:418,y:638,t:1527019786039};\\\", \\\"{x:421,y:648,t:1527019786056};\\\", \\\"{x:422,y:654,t:1527019786071};\\\", \\\"{x:422,y:655,t:1527019786088};\\\", \\\"{x:423,y:656,t:1527019786105};\\\", \\\"{x:423,y:657,t:1527019786152};\\\", \\\"{x:422,y:659,t:1527019786160};\\\", \\\"{x:418,y:659,t:1527019786173};\\\", \\\"{x:408,y:659,t:1527019786189};\\\", \\\"{x:392,y:659,t:1527019786206};\\\", \\\"{x:374,y:659,t:1527019786222};\\\", \\\"{x:362,y:659,t:1527019786239};\\\", \\\"{x:349,y:662,t:1527019786255};\\\", \\\"{x:336,y:664,t:1527019786272};\\\", \\\"{x:335,y:665,t:1527019786288};\\\", \\\"{x:334,y:666,t:1527019786336};\\\", \\\"{x:334,y:667,t:1527019786360};\\\", \\\"{x:334,y:669,t:1527019786376};\\\", \\\"{x:334,y:670,t:1527019786394};\\\", \\\"{x:334,y:672,t:1527019786408};\\\", \\\"{x:334,y:673,t:1527019786422};\\\", \\\"{x:335,y:675,t:1527019786439};\\\", \\\"{x:345,y:681,t:1527019786456};\\\", \\\"{x:384,y:689,t:1527019786473};\\\", \\\"{x:426,y:695,t:1527019786489};\\\", \\\"{x:471,y:696,t:1527019786506};\\\", \\\"{x:514,y:696,t:1527019786522};\\\", \\\"{x:550,y:696,t:1527019786539};\\\", \\\"{x:589,y:696,t:1527019786556};\\\", \\\"{x:615,y:696,t:1527019786573};\\\", \\\"{x:632,y:696,t:1527019786589};\\\", \\\"{x:646,y:698,t:1527019786606};\\\", \\\"{x:657,y:698,t:1527019786623};\\\", \\\"{x:669,y:698,t:1527019786639};\\\", \\\"{x:681,y:694,t:1527019786656};\\\", \\\"{x:707,y:682,t:1527019786674};\\\", \\\"{x:722,y:676,t:1527019786689};\\\", \\\"{x:734,y:670,t:1527019786706};\\\", \\\"{x:743,y:662,t:1527019786723};\\\", \\\"{x:746,y:658,t:1527019786740};\\\", \\\"{x:749,y:654,t:1527019786756};\\\", \\\"{x:753,y:650,t:1527019786773};\\\", \\\"{x:757,y:647,t:1527019786790};\\\", \\\"{x:765,y:645,t:1527019786806};\\\", \\\"{x:769,y:643,t:1527019786823};\\\", \\\"{x:772,y:641,t:1527019786840};\\\", \\\"{x:773,y:640,t:1527019786881};\\\", \\\"{x:773,y:639,t:1527019786896};\\\", \\\"{x:770,y:638,t:1527019786906};\\\", \\\"{x:763,y:634,t:1527019786923};\\\", \\\"{x:752,y:629,t:1527019786941};\\\", \\\"{x:740,y:624,t:1527019786956};\\\", \\\"{x:734,y:620,t:1527019786972};\\\", \\\"{x:732,y:619,t:1527019786990};\\\", \\\"{x:730,y:618,t:1527019787006};\\\", \\\"{x:728,y:618,t:1527019787022};\\\", \\\"{x:725,y:617,t:1527019787039};\\\", \\\"{x:717,y:615,t:1527019787057};\\\", \\\"{x:710,y:613,t:1527019787072};\\\", \\\"{x:701,y:612,t:1527019787089};\\\", \\\"{x:692,y:611,t:1527019787107};\\\", \\\"{x:688,y:611,t:1527019787122};\\\", \\\"{x:685,y:611,t:1527019787140};\\\", \\\"{x:683,y:611,t:1527019787156};\\\", \\\"{x:679,y:611,t:1527019787173};\\\", \\\"{x:674,y:609,t:1527019787189};\\\", \\\"{x:666,y:608,t:1527019787206};\\\", \\\"{x:652,y:608,t:1527019787223};\\\", \\\"{x:637,y:608,t:1527019787240};\\\", \\\"{x:625,y:605,t:1527019787257};\\\", \\\"{x:623,y:602,t:1527019787273};\\\", \\\"{x:620,y:596,t:1527019787291};\\\", \\\"{x:619,y:588,t:1527019787306};\\\", \\\"{x:618,y:582,t:1527019787322};\\\", \\\"{x:615,y:576,t:1527019787340};\\\", \\\"{x:615,y:575,t:1527019787356};\\\", \\\"{x:615,y:574,t:1527019787374};\\\", \\\"{x:615,y:573,t:1527019787389};\\\", \\\"{x:615,y:571,t:1527019787406};\\\", \\\"{x:615,y:570,t:1527019787424};\\\", \\\"{x:615,y:569,t:1527019787440};\\\", \\\"{x:615,y:568,t:1527019787540};\\\", \\\"{x:615,y:568,t:1527019787568};\\\", \\\"{x:614,y:577,t:1527019787656};\\\", \\\"{x:602,y:617,t:1527019787675};\\\", \\\"{x:590,y:648,t:1527019787691};\\\", \\\"{x:572,y:675,t:1527019787706};\\\", \\\"{x:557,y:709,t:1527019787724};\\\", \\\"{x:544,y:737,t:1527019787741};\\\", \\\"{x:533,y:757,t:1527019787757};\\\", \\\"{x:524,y:770,t:1527019787774};\\\", \\\"{x:517,y:781,t:1527019787790};\\\", \\\"{x:512,y:788,t:1527019787807};\\\", \\\"{x:511,y:791,t:1527019787824};\\\", \\\"{x:510,y:791,t:1527019787848};\\\", \\\"{x:510,y:790,t:1527019787889};\\\", \\\"{x:510,y:789,t:1527019787896};\\\", \\\"{x:510,y:787,t:1527019787907};\\\", \\\"{x:510,y:786,t:1527019787924};\\\", \\\"{x:511,y:784,t:1527019787941};\\\", \\\"{x:513,y:782,t:1527019787957};\\\", \\\"{x:515,y:779,t:1527019787973};\\\", \\\"{x:518,y:776,t:1527019787991};\\\", \\\"{x:520,y:774,t:1527019788007};\\\", \\\"{x:522,y:771,t:1527019788024};\\\", \\\"{x:530,y:753,t:1527019788040};\\\", \\\"{x:538,y:738,t:1527019788058};\\\", \\\"{x:541,y:733,t:1527019788073};\\\", \\\"{x:541,y:731,t:1527019788091};\\\", \\\"{x:542,y:730,t:1527019788108};\\\", \\\"{x:542,y:729,t:1527019788273};\\\", \\\"{x:543,y:727,t:1527019788281};\\\", \\\"{x:544,y:726,t:1527019788292};\\\", \\\"{x:544,y:725,t:1527019788308};\\\", \\\"{x:544,y:724,t:1527019788325};\\\", \\\"{x:544,y:723,t:1527019788342};\\\", \\\"{x:546,y:717,t:1527019788360};\\\", \\\"{x:551,y:700,t:1527019788375};\\\", \\\"{x:560,y:677,t:1527019788391};\\\", \\\"{x:568,y:657,t:1527019788408};\\\", \\\"{x:576,y:645,t:1527019788424};\\\", \\\"{x:592,y:620,t:1527019788442};\\\", \\\"{x:609,y:596,t:1527019788458};\\\", \\\"{x:615,y:584,t:1527019788474};\\\", \\\"{x:616,y:579,t:1527019788490};\\\", \\\"{x:616,y:578,t:1527019788508};\\\", \\\"{x:616,y:586,t:1527019788912};\\\", \\\"{x:615,y:601,t:1527019788925};\\\", \\\"{x:607,y:627,t:1527019788941};\\\", \\\"{x:601,y:642,t:1527019788958};\\\", \\\"{x:597,y:648,t:1527019788975};\\\", \\\"{x:594,y:656,t:1527019788990};\\\", \\\"{x:587,y:665,t:1527019789008};\\\", \\\"{x:563,y:695,t:1527019789025};\\\", \\\"{x:546,y:715,t:1527019789041};\\\", \\\"{x:538,y:728,t:1527019789059};\\\", \\\"{x:537,y:729,t:1527019789075};\\\", \\\"{x:537,y:730,t:1527019789160};\\\", \\\"{x:536,y:734,t:1527019789174};\\\", \\\"{x:533,y:749,t:1527019789191};\\\", \\\"{x:527,y:763,t:1527019789208};\\\", \\\"{x:525,y:771,t:1527019789224};\\\", \\\"{x:525,y:769,t:1527019789377};\\\", \\\"{x:528,y:764,t:1527019789392};\\\", \\\"{x:529,y:756,t:1527019789407};\\\", \\\"{x:534,y:746,t:1527019789425};\\\", \\\"{x:537,y:742,t:1527019789442};\\\", \\\"{x:538,y:739,t:1527019789457};\\\", \\\"{x:539,y:737,t:1527019789475};\\\", \\\"{x:540,y:737,t:1527019789536};\\\", \\\"{x:541,y:736,t:1527019789551};\\\", \\\"{x:542,y:736,t:1527019789568};\\\", \\\"{x:542,y:736,t:1527019789626};\\\", \\\"{x:542,y:735,t:1527019790024};\\\", \\\"{x:543,y:735,t:1527019790592};\\\" ] }, { \\\"rt\\\": 67292, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 12, \\\"time_elapsed\\\": 465180, \\\"internal_node_id\\\": \\\"0.0-6.0-2.0\\\", \\\"subject\\\": \\\"VT5BG\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"golf\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+contained\\\", \\\"q\\\": 8, \\\"clicks\\\": 3.5, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"A\\\", \\\"G\\\", \\\"K\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-G -J -X -X -09 AM-X -X -G -G -7\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:543,y:734,t:1527019791016};\\\", \\\"{x:543,y:733,t:1527019791025};\\\", \\\"{x:543,y:731,t:1527019791042};\\\", \\\"{x:543,y:729,t:1527019791059};\\\", \\\"{x:543,y:728,t:1527019791076};\\\", \\\"{x:543,y:727,t:1527019791092};\\\", \\\"{x:543,y:726,t:1527019791111};\\\", \\\"{x:543,y:725,t:1527019791152};\\\", \\\"{x:543,y:724,t:1527019791184};\\\", \\\"{x:543,y:723,t:1527019791200};\\\", \\\"{x:543,y:722,t:1527019791268};\\\", \\\"{x:543,y:720,t:1527019792402};\\\", \\\"{x:543,y:719,t:1527019792413};\\\", \\\"{x:544,y:716,t:1527019792429};\\\", \\\"{x:544,y:714,t:1527019792443};\\\", \\\"{x:544,y:711,t:1527019792459};\\\", \\\"{x:544,y:709,t:1527019792476};\\\", \\\"{x:544,y:708,t:1527019792493};\\\", \\\"{x:545,y:708,t:1527019792509};\\\", \\\"{x:545,y:707,t:1527019792526};\\\", \\\"{x:545,y:706,t:1527019793025};\\\", \\\"{x:543,y:703,t:1527019793033};\\\", \\\"{x:541,y:703,t:1527019793043};\\\", \\\"{x:538,y:701,t:1527019793060};\\\", \\\"{x:538,y:698,t:1527019793273};\\\", \\\"{x:538,y:684,t:1527019793281};\\\", \\\"{x:538,y:656,t:1527019793295};\\\", \\\"{x:538,y:616,t:1527019793311};\\\", \\\"{x:536,y:592,t:1527019793329};\\\", \\\"{x:532,y:568,t:1527019793343};\\\", \\\"{x:531,y:558,t:1527019793361};\\\", \\\"{x:529,y:545,t:1527019793378};\\\", \\\"{x:528,y:540,t:1527019793395};\\\", \\\"{x:527,y:534,t:1527019793412};\\\", \\\"{x:523,y:525,t:1527019793427};\\\", \\\"{x:519,y:518,t:1527019793445};\\\", \\\"{x:512,y:508,t:1527019793462};\\\", \\\"{x:502,y:496,t:1527019793477};\\\", \\\"{x:494,y:487,t:1527019793495};\\\", \\\"{x:486,y:481,t:1527019793512};\\\", \\\"{x:473,y:476,t:1527019793528};\\\", \\\"{x:448,y:468,t:1527019793545};\\\", \\\"{x:424,y:454,t:1527019793560};\\\", \\\"{x:401,y:442,t:1527019793578};\\\", \\\"{x:386,y:431,t:1527019793594};\\\", \\\"{x:374,y:424,t:1527019793612};\\\", \\\"{x:370,y:421,t:1527019793628};\\\", \\\"{x:368,y:421,t:1527019793680};\\\", \\\"{x:365,y:421,t:1527019793695};\\\", \\\"{x:356,y:421,t:1527019793712};\\\", \\\"{x:346,y:422,t:1527019793728};\\\", \\\"{x:341,y:424,t:1527019793745};\\\", \\\"{x:339,y:426,t:1527019793762};\\\", \\\"{x:338,y:427,t:1527019793778};\\\", \\\"{x:338,y:428,t:1527019793795};\\\", \\\"{x:337,y:429,t:1527019793812};\\\", \\\"{x:337,y:431,t:1527019793856};\\\", \\\"{x:338,y:432,t:1527019793865};\\\", \\\"{x:341,y:433,t:1527019793878};\\\", \\\"{x:346,y:436,t:1527019793895};\\\", \\\"{x:351,y:437,t:1527019793913};\\\", \\\"{x:353,y:437,t:1527019793929};\\\", \\\"{x:356,y:437,t:1527019793945};\\\", \\\"{x:362,y:437,t:1527019793962};\\\", \\\"{x:381,y:437,t:1527019793978};\\\", \\\"{x:404,y:435,t:1527019793995};\\\", \\\"{x:432,y:432,t:1527019794012};\\\", \\\"{x:450,y:429,t:1527019794028};\\\", \\\"{x:469,y:429,t:1527019794045};\\\", \\\"{x:493,y:429,t:1527019794062};\\\", \\\"{x:543,y:429,t:1527019794079};\\\", \\\"{x:612,y:429,t:1527019794094};\\\", \\\"{x:740,y:429,t:1527019794112};\\\", \\\"{x:856,y:429,t:1527019794128};\\\", \\\"{x:995,y:450,t:1527019794145};\\\", \\\"{x:1138,y:467,t:1527019794162};\\\", \\\"{x:1260,y:484,t:1527019794179};\\\", \\\"{x:1355,y:485,t:1527019794195};\\\", \\\"{x:1427,y:485,t:1527019794212};\\\", \\\"{x:1483,y:485,t:1527019794229};\\\", \\\"{x:1525,y:485,t:1527019794245};\\\", \\\"{x:1547,y:485,t:1527019794262};\\\", \\\"{x:1559,y:485,t:1527019794279};\\\", \\\"{x:1565,y:485,t:1527019794295};\\\", \\\"{x:1566,y:485,t:1527019794337};\\\", \\\"{x:1567,y:486,t:1527019794385};\\\", \\\"{x:1564,y:488,t:1527019794395};\\\", \\\"{x:1550,y:496,t:1527019794412};\\\", \\\"{x:1534,y:506,t:1527019794430};\\\", \\\"{x:1517,y:521,t:1527019794446};\\\", \\\"{x:1501,y:532,t:1527019794463};\\\", \\\"{x:1493,y:536,t:1527019794480};\\\", \\\"{x:1492,y:536,t:1527019794496};\\\", \\\"{x:1491,y:536,t:1527019794512};\\\", \\\"{x:1484,y:539,t:1527019794529};\\\", \\\"{x:1472,y:546,t:1527019794545};\\\", \\\"{x:1459,y:552,t:1527019794563};\\\", \\\"{x:1447,y:557,t:1527019794579};\\\", \\\"{x:1442,y:557,t:1527019794596};\\\", \\\"{x:1441,y:559,t:1527019794613};\\\", \\\"{x:1439,y:559,t:1527019794641};\\\", \\\"{x:1438,y:558,t:1527019794649};\\\", \\\"{x:1437,y:558,t:1527019794662};\\\", \\\"{x:1433,y:556,t:1527019794679};\\\", \\\"{x:1431,y:555,t:1527019794753};\\\", \\\"{x:1424,y:551,t:1527019794762};\\\", \\\"{x:1414,y:544,t:1527019794779};\\\", \\\"{x:1401,y:533,t:1527019794798};\\\", \\\"{x:1391,y:523,t:1527019794812};\\\", \\\"{x:1377,y:513,t:1527019794829};\\\", \\\"{x:1368,y:506,t:1527019794846};\\\", \\\"{x:1364,y:502,t:1527019794862};\\\", \\\"{x:1363,y:502,t:1527019794944};\\\", \\\"{x:1362,y:502,t:1527019794976};\\\", \\\"{x:1362,y:500,t:1527019795000};\\\", \\\"{x:1362,y:499,t:1527019795012};\\\", \\\"{x:1362,y:496,t:1527019795029};\\\", \\\"{x:1362,y:493,t:1527019795046};\\\", \\\"{x:1363,y:491,t:1527019795062};\\\", \\\"{x:1366,y:489,t:1527019795079};\\\", \\\"{x:1368,y:484,t:1527019795097};\\\", \\\"{x:1369,y:482,t:1527019795112};\\\", \\\"{x:1369,y:481,t:1527019795129};\\\", \\\"{x:1370,y:479,t:1527019795146};\\\", \\\"{x:1372,y:478,t:1527019795169};\\\", \\\"{x:1372,y:477,t:1527019795185};\\\", \\\"{x:1373,y:476,t:1527019795201};\\\", \\\"{x:1374,y:476,t:1527019795233};\\\", \\\"{x:1374,y:475,t:1527019795249};\\\", \\\"{x:1376,y:475,t:1527019795263};\\\", \\\"{x:1382,y:475,t:1527019795279};\\\", \\\"{x:1384,y:475,t:1527019795296};\\\", \\\"{x:1388,y:475,t:1527019795312};\\\", \\\"{x:1391,y:476,t:1527019795330};\\\", \\\"{x:1397,y:479,t:1527019795346};\\\", \\\"{x:1400,y:480,t:1527019795363};\\\", \\\"{x:1403,y:480,t:1527019795379};\\\", \\\"{x:1404,y:480,t:1527019795408};\\\", \\\"{x:1406,y:480,t:1527019795424};\\\", \\\"{x:1407,y:480,t:1527019795440};\\\", \\\"{x:1408,y:480,t:1527019795448};\\\", \\\"{x:1410,y:480,t:1527019795463};\\\", \\\"{x:1411,y:483,t:1527019795945};\\\", \\\"{x:1411,y:486,t:1527019795963};\\\", \\\"{x:1411,y:488,t:1527019795980};\\\", \\\"{x:1411,y:489,t:1527019796249};\\\", \\\"{x:1412,y:490,t:1527019796265};\\\", \\\"{x:1413,y:490,t:1527019796280};\\\", \\\"{x:1429,y:491,t:1527019796297};\\\", \\\"{x:1444,y:493,t:1527019796314};\\\", \\\"{x:1457,y:493,t:1527019796330};\\\", \\\"{x:1463,y:493,t:1527019796347};\\\", \\\"{x:1468,y:493,t:1527019796364};\\\", \\\"{x:1479,y:493,t:1527019796381};\\\", \\\"{x:1487,y:493,t:1527019796398};\\\", \\\"{x:1492,y:493,t:1527019796414};\\\", \\\"{x:1494,y:493,t:1527019796430};\\\", \\\"{x:1495,y:493,t:1527019796481};\\\", \\\"{x:1498,y:493,t:1527019796497};\\\", \\\"{x:1502,y:493,t:1527019796513};\\\", \\\"{x:1505,y:493,t:1527019796530};\\\", \\\"{x:1512,y:493,t:1527019796547};\\\", \\\"{x:1524,y:493,t:1527019796564};\\\", \\\"{x:1539,y:496,t:1527019796580};\\\", \\\"{x:1552,y:500,t:1527019796598};\\\", \\\"{x:1557,y:501,t:1527019796613};\\\", \\\"{x:1559,y:502,t:1527019796631};\\\", \\\"{x:1560,y:502,t:1527019796746};\\\", \\\"{x:1561,y:502,t:1527019796768};\\\", \\\"{x:1562,y:502,t:1527019796858};\\\", \\\"{x:1563,y:502,t:1527019796864};\\\", \\\"{x:1565,y:501,t:1527019796881};\\\", \\\"{x:1566,y:500,t:1527019796905};\\\", \\\"{x:1567,y:500,t:1527019796937};\\\", \\\"{x:1568,y:500,t:1527019796969};\\\", \\\"{x:1569,y:499,t:1527019796981};\\\", \\\"{x:1570,y:499,t:1527019799690};\\\", \\\"{x:1570,y:500,t:1527019799700};\\\", \\\"{x:1569,y:502,t:1527019799716};\\\", \\\"{x:1568,y:503,t:1527019799732};\\\", \\\"{x:1567,y:504,t:1527019799753};\\\", \\\"{x:1566,y:505,t:1527019799896};\\\", \\\"{x:1566,y:506,t:1527019799912};\\\", \\\"{x:1565,y:507,t:1527019799920};\\\", \\\"{x:1565,y:508,t:1527019799932};\\\", \\\"{x:1563,y:511,t:1527019799949};\\\", \\\"{x:1562,y:513,t:1527019799966};\\\", \\\"{x:1559,y:516,t:1527019799982};\\\", \\\"{x:1559,y:517,t:1527019799999};\\\", \\\"{x:1557,y:519,t:1527019800016};\\\", \\\"{x:1555,y:521,t:1527019800032};\\\", \\\"{x:1553,y:524,t:1527019800050};\\\", \\\"{x:1551,y:526,t:1527019800066};\\\", \\\"{x:1549,y:529,t:1527019800082};\\\", \\\"{x:1547,y:531,t:1527019800099};\\\", \\\"{x:1546,y:532,t:1527019800116};\\\", \\\"{x:1545,y:532,t:1527019800132};\\\", \\\"{x:1545,y:533,t:1527019800150};\\\", \\\"{x:1544,y:534,t:1527019800166};\\\", \\\"{x:1542,y:535,t:1527019800185};\\\", \\\"{x:1542,y:537,t:1527019800199};\\\", \\\"{x:1535,y:547,t:1527019800217};\\\", \\\"{x:1530,y:554,t:1527019800232};\\\", \\\"{x:1521,y:568,t:1527019800249};\\\", \\\"{x:1514,y:578,t:1527019800267};\\\", \\\"{x:1504,y:593,t:1527019800282};\\\", \\\"{x:1492,y:612,t:1527019800299};\\\", \\\"{x:1481,y:633,t:1527019800317};\\\", \\\"{x:1466,y:652,t:1527019800333};\\\", \\\"{x:1456,y:668,t:1527019800349};\\\", \\\"{x:1448,y:683,t:1527019800367};\\\", \\\"{x:1438,y:699,t:1527019800384};\\\", \\\"{x:1432,y:713,t:1527019800399};\\\", \\\"{x:1427,y:722,t:1527019800417};\\\", \\\"{x:1427,y:723,t:1527019800434};\\\", \\\"{x:1426,y:724,t:1527019800449};\\\", \\\"{x:1421,y:727,t:1527019800467};\\\", \\\"{x:1409,y:736,t:1527019800484};\\\", \\\"{x:1393,y:747,t:1527019800499};\\\", \\\"{x:1379,y:757,t:1527019800517};\\\", \\\"{x:1365,y:767,t:1527019800534};\\\", \\\"{x:1357,y:771,t:1527019800550};\\\", \\\"{x:1356,y:771,t:1527019800566};\\\", \\\"{x:1354,y:771,t:1527019800601};\\\", \\\"{x:1352,y:771,t:1527019800617};\\\", \\\"{x:1351,y:771,t:1527019801018};\\\", \\\"{x:1351,y:770,t:1527019801984};\\\", \\\"{x:1351,y:769,t:1527019802000};\\\", \\\"{x:1353,y:769,t:1527019807841};\\\", \\\"{x:1355,y:769,t:1527019807865};\\\", \\\"{x:1355,y:770,t:1527019808713};\\\", \\\"{x:1353,y:772,t:1527019808722};\\\", \\\"{x:1349,y:773,t:1527019808739};\\\", \\\"{x:1346,y:774,t:1527019808756};\\\", \\\"{x:1344,y:774,t:1527019808772};\\\", \\\"{x:1339,y:775,t:1527019808788};\\\", \\\"{x:1334,y:775,t:1527019808806};\\\", \\\"{x:1330,y:777,t:1527019808821};\\\", \\\"{x:1326,y:779,t:1527019808839};\\\", \\\"{x:1321,y:783,t:1527019808855};\\\", \\\"{x:1314,y:791,t:1527019808871};\\\", \\\"{x:1295,y:801,t:1527019808889};\\\", \\\"{x:1282,y:805,t:1527019808906};\\\", \\\"{x:1276,y:806,t:1527019808922};\\\", \\\"{x:1273,y:807,t:1527019808939};\\\", \\\"{x:1272,y:807,t:1527019808968};\\\", \\\"{x:1270,y:808,t:1527019808977};\\\", \\\"{x:1269,y:808,t:1527019808989};\\\", \\\"{x:1264,y:811,t:1527019809005};\\\", \\\"{x:1261,y:813,t:1527019809022};\\\", \\\"{x:1256,y:816,t:1527019809039};\\\", \\\"{x:1248,y:821,t:1527019809056};\\\", \\\"{x:1237,y:828,t:1527019809072};\\\", \\\"{x:1223,y:834,t:1527019809088};\\\", \\\"{x:1217,y:838,t:1527019809106};\\\", \\\"{x:1214,y:839,t:1527019809122};\\\", \\\"{x:1209,y:841,t:1527019809139};\\\", \\\"{x:1202,y:841,t:1527019809157};\\\", \\\"{x:1198,y:842,t:1527019809172};\\\", \\\"{x:1195,y:842,t:1527019809189};\\\", \\\"{x:1194,y:842,t:1527019809513};\\\", \\\"{x:1192,y:842,t:1527019809705};\\\", \\\"{x:1191,y:842,t:1527019809833};\\\", \\\"{x:1189,y:842,t:1527019809857};\\\", \\\"{x:1188,y:841,t:1527019809873};\\\", \\\"{x:1187,y:840,t:1527019809912};\\\", \\\"{x:1187,y:839,t:1527019821182};\\\", \\\"{x:1189,y:836,t:1527019821195};\\\", \\\"{x:1196,y:833,t:1527019821212};\\\", \\\"{x:1200,y:832,t:1527019821227};\\\", \\\"{x:1202,y:830,t:1527019821245};\\\", \\\"{x:1204,y:830,t:1527019821294};\\\", \\\"{x:1206,y:829,t:1527019821312};\\\", \\\"{x:1211,y:827,t:1527019821330};\\\", \\\"{x:1214,y:826,t:1527019821345};\\\", \\\"{x:1217,y:825,t:1527019821361};\\\", \\\"{x:1222,y:825,t:1527019821379};\\\", \\\"{x:1227,y:822,t:1527019821395};\\\", \\\"{x:1234,y:821,t:1527019821411};\\\", \\\"{x:1244,y:819,t:1527019821427};\\\", \\\"{x:1251,y:818,t:1527019821444};\\\", \\\"{x:1259,y:817,t:1527019821461};\\\", \\\"{x:1262,y:817,t:1527019821477};\\\", \\\"{x:1263,y:816,t:1527019821494};\\\", \\\"{x:1266,y:816,t:1527019821511};\\\", \\\"{x:1267,y:816,t:1527019821527};\\\", \\\"{x:1269,y:816,t:1527019821544};\\\", \\\"{x:1271,y:815,t:1527019821561};\\\", \\\"{x:1272,y:815,t:1527019821578};\\\", \\\"{x:1273,y:815,t:1527019821594};\\\", \\\"{x:1274,y:815,t:1527019821611};\\\", \\\"{x:1275,y:815,t:1527019821654};\\\", \\\"{x:1276,y:815,t:1527019821677};\\\", \\\"{x:1277,y:815,t:1527019821782};\\\", \\\"{x:1278,y:815,t:1527019821814};\\\", \\\"{x:1279,y:815,t:1527019821846};\\\", \\\"{x:1280,y:815,t:1527019821862};\\\", \\\"{x:1281,y:815,t:1527019821879};\\\", \\\"{x:1282,y:815,t:1527019821901};\\\", \\\"{x:1283,y:815,t:1527019821917};\\\", \\\"{x:1284,y:815,t:1527019821941};\\\", \\\"{x:1286,y:815,t:1527019821958};\\\", \\\"{x:1287,y:815,t:1527019821966};\\\", \\\"{x:1288,y:815,t:1527019821982};\\\", \\\"{x:1290,y:815,t:1527019821995};\\\", \\\"{x:1291,y:815,t:1527019822012};\\\", \\\"{x:1293,y:815,t:1527019822029};\\\", \\\"{x:1294,y:815,t:1527019822045};\\\", \\\"{x:1295,y:815,t:1527019822062};\\\", \\\"{x:1296,y:815,t:1527019822079};\\\", \\\"{x:1297,y:815,t:1527019822095};\\\", \\\"{x:1299,y:815,t:1527019822111};\\\", \\\"{x:1301,y:815,t:1527019822129};\\\", \\\"{x:1302,y:814,t:1527019822145};\\\", \\\"{x:1303,y:814,t:1527019822173};\\\", \\\"{x:1304,y:814,t:1527019822197};\\\", \\\"{x:1305,y:814,t:1527019822212};\\\", \\\"{x:1306,y:814,t:1527019822228};\\\", \\\"{x:1309,y:814,t:1527019822245};\\\", \\\"{x:1310,y:814,t:1527019822262};\\\", \\\"{x:1311,y:814,t:1527019822279};\\\", \\\"{x:1312,y:814,t:1527019822309};\\\", \\\"{x:1313,y:814,t:1527019822358};\\\", \\\"{x:1314,y:814,t:1527019822366};\\\", \\\"{x:1309,y:815,t:1527019822854};\\\", \\\"{x:1300,y:817,t:1527019822862};\\\", \\\"{x:1279,y:822,t:1527019822879};\\\", \\\"{x:1260,y:828,t:1527019822895};\\\", \\\"{x:1242,y:834,t:1527019822913};\\\", \\\"{x:1216,y:852,t:1527019822929};\\\", \\\"{x:1197,y:867,t:1527019822946};\\\", \\\"{x:1180,y:878,t:1527019822963};\\\", \\\"{x:1175,y:882,t:1527019822979};\\\", \\\"{x:1170,y:886,t:1527019822995};\\\", \\\"{x:1164,y:892,t:1527019823013};\\\", \\\"{x:1157,y:901,t:1527019823029};\\\", \\\"{x:1150,y:914,t:1527019823046};\\\", \\\"{x:1145,y:922,t:1527019823063};\\\", \\\"{x:1142,y:927,t:1527019823079};\\\", \\\"{x:1141,y:931,t:1527019823096};\\\", \\\"{x:1137,y:936,t:1527019823113};\\\", \\\"{x:1135,y:939,t:1527019823128};\\\", \\\"{x:1134,y:942,t:1527019823146};\\\", \\\"{x:1133,y:945,t:1527019823162};\\\", \\\"{x:1132,y:948,t:1527019823178};\\\", \\\"{x:1132,y:951,t:1527019823195};\\\", \\\"{x:1132,y:955,t:1527019823213};\\\", \\\"{x:1132,y:957,t:1527019823229};\\\", \\\"{x:1131,y:959,t:1527019823246};\\\", \\\"{x:1131,y:960,t:1527019823262};\\\", \\\"{x:1131,y:961,t:1527019823279};\\\", \\\"{x:1131,y:962,t:1527019823296};\\\", \\\"{x:1130,y:962,t:1527019823312};\\\", \\\"{x:1130,y:963,t:1527019823622};\\\", \\\"{x:1131,y:963,t:1527019823645};\\\", \\\"{x:1132,y:963,t:1527019823702};\\\", \\\"{x:1133,y:963,t:1527019823725};\\\", \\\"{x:1134,y:963,t:1527019823734};\\\", \\\"{x:1135,y:962,t:1527019823746};\\\", \\\"{x:1137,y:961,t:1527019823763};\\\", \\\"{x:1139,y:960,t:1527019823780};\\\", \\\"{x:1141,y:959,t:1527019823796};\\\", \\\"{x:1143,y:958,t:1527019823813};\\\", \\\"{x:1144,y:957,t:1527019823830};\\\", \\\"{x:1146,y:956,t:1527019823854};\\\", \\\"{x:1148,y:955,t:1527019823870};\\\", \\\"{x:1150,y:954,t:1527019823886};\\\", \\\"{x:1152,y:953,t:1527019823901};\\\", \\\"{x:1153,y:951,t:1527019823913};\\\", \\\"{x:1154,y:951,t:1527019823930};\\\", \\\"{x:1155,y:951,t:1527019823947};\\\", \\\"{x:1156,y:950,t:1527019823963};\\\", \\\"{x:1157,y:949,t:1527019823990};\\\", \\\"{x:1159,y:949,t:1527019824021};\\\", \\\"{x:1159,y:948,t:1527019824029};\\\", \\\"{x:1161,y:948,t:1527019824077};\\\", \\\"{x:1162,y:948,t:1527019824101};\\\", \\\"{x:1162,y:947,t:1527019824117};\\\", \\\"{x:1163,y:947,t:1527019824141};\\\", \\\"{x:1164,y:947,t:1527019824148};\\\", \\\"{x:1165,y:946,t:1527019824163};\\\", \\\"{x:1166,y:945,t:1527019824181};\\\", \\\"{x:1167,y:945,t:1527019824196};\\\", \\\"{x:1168,y:945,t:1527019824213};\\\", \\\"{x:1168,y:944,t:1527019824230};\\\", \\\"{x:1170,y:943,t:1527019824247};\\\", \\\"{x:1172,y:942,t:1527019824285};\\\", \\\"{x:1173,y:941,t:1527019824325};\\\", \\\"{x:1174,y:941,t:1527019824350};\\\", \\\"{x:1176,y:940,t:1527019824390};\\\", \\\"{x:1176,y:939,t:1527019824422};\\\", \\\"{x:1178,y:939,t:1527019824445};\\\", \\\"{x:1179,y:938,t:1527019824464};\\\", \\\"{x:1180,y:936,t:1527019824480};\\\", \\\"{x:1181,y:936,t:1527019824496};\\\", \\\"{x:1182,y:935,t:1527019824514};\\\", \\\"{x:1185,y:935,t:1527019824530};\\\", \\\"{x:1189,y:931,t:1527019824546};\\\", \\\"{x:1191,y:931,t:1527019824564};\\\", \\\"{x:1195,y:929,t:1527019824579};\\\", \\\"{x:1197,y:928,t:1527019824597};\\\", \\\"{x:1200,y:927,t:1527019824614};\\\", \\\"{x:1206,y:926,t:1527019824630};\\\", \\\"{x:1215,y:923,t:1527019824647};\\\", \\\"{x:1226,y:918,t:1527019824664};\\\", \\\"{x:1242,y:908,t:1527019824680};\\\", \\\"{x:1251,y:903,t:1527019824696};\\\", \\\"{x:1262,y:899,t:1527019824714};\\\", \\\"{x:1275,y:894,t:1527019824730};\\\", \\\"{x:1294,y:885,t:1527019824747};\\\", \\\"{x:1317,y:872,t:1527019824763};\\\", \\\"{x:1344,y:859,t:1527019824780};\\\", \\\"{x:1395,y:842,t:1527019824798};\\\", \\\"{x:1420,y:839,t:1527019824814};\\\", \\\"{x:1442,y:835,t:1527019824831};\\\", \\\"{x:1458,y:829,t:1527019824846};\\\", \\\"{x:1467,y:824,t:1527019824863};\\\", \\\"{x:1473,y:820,t:1527019824880};\\\", \\\"{x:1482,y:817,t:1527019824897};\\\", \\\"{x:1497,y:813,t:1527019824914};\\\", \\\"{x:1506,y:810,t:1527019824931};\\\", \\\"{x:1512,y:807,t:1527019824947};\\\", \\\"{x:1513,y:808,t:1527019825126};\\\", \\\"{x:1509,y:812,t:1527019825134};\\\", \\\"{x:1502,y:817,t:1527019825147};\\\", \\\"{x:1493,y:819,t:1527019825163};\\\", \\\"{x:1491,y:821,t:1527019825181};\\\", \\\"{x:1488,y:823,t:1527019825429};\\\", \\\"{x:1485,y:825,t:1527019825437};\\\", \\\"{x:1485,y:826,t:1527019825448};\\\", \\\"{x:1482,y:828,t:1527019825464};\\\", \\\"{x:1481,y:829,t:1527019825480};\\\", \\\"{x:1480,y:830,t:1527019825497};\\\", \\\"{x:1478,y:832,t:1527019827118};\\\", \\\"{x:1474,y:834,t:1527019827133};\\\", \\\"{x:1465,y:837,t:1527019827149};\\\", \\\"{x:1460,y:840,t:1527019827165};\\\", \\\"{x:1456,y:841,t:1527019827182};\\\", \\\"{x:1455,y:841,t:1527019827269};\\\", \\\"{x:1451,y:841,t:1527019827281};\\\", \\\"{x:1440,y:818,t:1527019827299};\\\", \\\"{x:1429,y:800,t:1527019827316};\\\", \\\"{x:1425,y:790,t:1527019827332};\\\", \\\"{x:1425,y:773,t:1527019827349};\\\", \\\"{x:1425,y:753,t:1527019827365};\\\", \\\"{x:1424,y:733,t:1527019827382};\\\", \\\"{x:1424,y:721,t:1527019827399};\\\", \\\"{x:1422,y:708,t:1527019827415};\\\", \\\"{x:1417,y:690,t:1527019827433};\\\", \\\"{x:1405,y:669,t:1527019827450};\\\", \\\"{x:1400,y:656,t:1527019827465};\\\", \\\"{x:1398,y:654,t:1527019827482};\\\", \\\"{x:1398,y:653,t:1527019827499};\\\", \\\"{x:1397,y:653,t:1527019827516};\\\", \\\"{x:1397,y:652,t:1527019827532};\\\", \\\"{x:1396,y:652,t:1527019827549};\\\", \\\"{x:1394,y:651,t:1527019827565};\\\", \\\"{x:1388,y:650,t:1527019827582};\\\", \\\"{x:1377,y:649,t:1527019827599};\\\", \\\"{x:1352,y:648,t:1527019827616};\\\", \\\"{x:1320,y:648,t:1527019827633};\\\", \\\"{x:1278,y:648,t:1527019827649};\\\", \\\"{x:1233,y:648,t:1527019827666};\\\", \\\"{x:1178,y:648,t:1527019827682};\\\", \\\"{x:1113,y:648,t:1527019827699};\\\", \\\"{x:1030,y:648,t:1527019827716};\\\", \\\"{x:977,y:648,t:1527019827732};\\\", \\\"{x:932,y:648,t:1527019827749};\\\", \\\"{x:892,y:644,t:1527019827766};\\\", \\\"{x:881,y:644,t:1527019827782};\\\", \\\"{x:875,y:641,t:1527019827798};\\\", \\\"{x:874,y:641,t:1527019827886};\\\", \\\"{x:871,y:639,t:1527019827898};\\\", \\\"{x:869,y:638,t:1527019827916};\\\", \\\"{x:868,y:638,t:1527019827990};\\\", \\\"{x:868,y:636,t:1527019828230};\\\", \\\"{x:868,y:634,t:1527019828237};\\\", \\\"{x:868,y:632,t:1527019828249};\\\", \\\"{x:874,y:622,t:1527019828267};\\\", \\\"{x:878,y:615,t:1527019828282};\\\", \\\"{x:883,y:606,t:1527019828299};\\\", \\\"{x:887,y:599,t:1527019828320};\\\", \\\"{x:888,y:594,t:1527019828336};\\\", \\\"{x:890,y:592,t:1527019828353};\\\", \\\"{x:890,y:589,t:1527019828437};\\\", \\\"{x:895,y:579,t:1527019828454};\\\", \\\"{x:901,y:570,t:1527019828469};\\\", \\\"{x:913,y:556,t:1527019828487};\\\", \\\"{x:928,y:542,t:1527019828504};\\\", \\\"{x:950,y:523,t:1527019828521};\\\", \\\"{x:971,y:506,t:1527019828536};\\\", \\\"{x:990,y:488,t:1527019828554};\\\", \\\"{x:1008,y:470,t:1527019828570};\\\", \\\"{x:1034,y:454,t:1527019828587};\\\", \\\"{x:1073,y:439,t:1527019828604};\\\", \\\"{x:1108,y:423,t:1527019828620};\\\", \\\"{x:1136,y:413,t:1527019828637};\\\", \\\"{x:1159,y:403,t:1527019828654};\\\", \\\"{x:1164,y:400,t:1527019828671};\\\", \\\"{x:1165,y:400,t:1527019828709};\\\", \\\"{x:1166,y:400,t:1527019828733};\\\", \\\"{x:1168,y:400,t:1527019828741};\\\", \\\"{x:1169,y:400,t:1527019828753};\\\", \\\"{x:1178,y:401,t:1527019828770};\\\", \\\"{x:1185,y:403,t:1527019828787};\\\", \\\"{x:1191,y:405,t:1527019828804};\\\", \\\"{x:1195,y:407,t:1527019828820};\\\", \\\"{x:1202,y:415,t:1527019828837};\\\", \\\"{x:1205,y:422,t:1527019828854};\\\", \\\"{x:1208,y:427,t:1527019828871};\\\", \\\"{x:1215,y:436,t:1527019828887};\\\", \\\"{x:1227,y:447,t:1527019828903};\\\", \\\"{x:1235,y:454,t:1527019828921};\\\", \\\"{x:1243,y:458,t:1527019828938};\\\", \\\"{x:1250,y:462,t:1527019828954};\\\", \\\"{x:1259,y:466,t:1527019828971};\\\", \\\"{x:1270,y:468,t:1527019828988};\\\", \\\"{x:1276,y:468,t:1527019829003};\\\", \\\"{x:1296,y:461,t:1527019829021};\\\", \\\"{x:1311,y:453,t:1527019829038};\\\", \\\"{x:1344,y:447,t:1527019829054};\\\", \\\"{x:1449,y:447,t:1527019829071};\\\", \\\"{x:1545,y:437,t:1527019829088};\\\", \\\"{x:1572,y:432,t:1527019829104};\\\", \\\"{x:1590,y:427,t:1527019829121};\\\", \\\"{x:1594,y:426,t:1527019829138};\\\", \\\"{x:1592,y:423,t:1527019829238};\\\", \\\"{x:1557,y:420,t:1527019829254};\\\", \\\"{x:1531,y:421,t:1527019829271};\\\", \\\"{x:1518,y:430,t:1527019829289};\\\", \\\"{x:1510,y:434,t:1527019829304};\\\", \\\"{x:1501,y:437,t:1527019829321};\\\", \\\"{x:1494,y:439,t:1527019829338};\\\", \\\"{x:1492,y:440,t:1527019829355};\\\", \\\"{x:1490,y:440,t:1527019829371};\\\", \\\"{x:1486,y:441,t:1527019829388};\\\", \\\"{x:1482,y:444,t:1527019829405};\\\", \\\"{x:1473,y:449,t:1527019829421};\\\", \\\"{x:1452,y:460,t:1527019829437};\\\", \\\"{x:1439,y:468,t:1527019829455};\\\", \\\"{x:1424,y:479,t:1527019829471};\\\", \\\"{x:1400,y:503,t:1527019829488};\\\", \\\"{x:1365,y:551,t:1527019829505};\\\", \\\"{x:1329,y:609,t:1527019829521};\\\", \\\"{x:1297,y:661,t:1527019829538};\\\", \\\"{x:1263,y:714,t:1527019829555};\\\", \\\"{x:1230,y:781,t:1527019829571};\\\", \\\"{x:1193,y:866,t:1527019829587};\\\", \\\"{x:1149,y:972,t:1527019829605};\\\", \\\"{x:1142,y:1003,t:1527019829622};\\\", \\\"{x:1142,y:1011,t:1527019829638};\\\", \\\"{x:1150,y:1013,t:1527019829655};\\\", \\\"{x:1197,y:1013,t:1527019829671};\\\", \\\"{x:1287,y:994,t:1527019829688};\\\", \\\"{x:1388,y:958,t:1527019829705};\\\", \\\"{x:1480,y:912,t:1527019829721};\\\", \\\"{x:1571,y:872,t:1527019829738};\\\", \\\"{x:1627,y:856,t:1527019829755};\\\", \\\"{x:1646,y:855,t:1527019829772};\\\", \\\"{x:1647,y:855,t:1527019829788};\\\", \\\"{x:1647,y:849,t:1527019829854};\\\", \\\"{x:1644,y:803,t:1527019829872};\\\", \\\"{x:1619,y:725,t:1527019829888};\\\", \\\"{x:1616,y:706,t:1527019829905};\\\", \\\"{x:1616,y:705,t:1527019829922};\\\", \\\"{x:1613,y:705,t:1527019829958};\\\", \\\"{x:1604,y:705,t:1527019829972};\\\", \\\"{x:1566,y:725,t:1527019829988};\\\", \\\"{x:1497,y:775,t:1527019830005};\\\", \\\"{x:1460,y:797,t:1527019830022};\\\", \\\"{x:1425,y:813,t:1527019830038};\\\", \\\"{x:1406,y:821,t:1527019830055};\\\", \\\"{x:1400,y:825,t:1527019830072};\\\", \\\"{x:1400,y:830,t:1527019830109};\\\", \\\"{x:1400,y:838,t:1527019830122};\\\", \\\"{x:1400,y:853,t:1527019830138};\\\", \\\"{x:1399,y:862,t:1527019830155};\\\", \\\"{x:1398,y:863,t:1527019830172};\\\", \\\"{x:1397,y:864,t:1527019830188};\\\", \\\"{x:1396,y:865,t:1527019830205};\\\", \\\"{x:1398,y:862,t:1527019830229};\\\", \\\"{x:1411,y:850,t:1527019830239};\\\", \\\"{x:1438,y:815,t:1527019830254};\\\", \\\"{x:1457,y:792,t:1527019830272};\\\", \\\"{x:1464,y:788,t:1527019830288};\\\", \\\"{x:1465,y:787,t:1527019830305};\\\", \\\"{x:1467,y:788,t:1527019830389};\\\", \\\"{x:1471,y:800,t:1527019830405};\\\", \\\"{x:1474,y:807,t:1527019830421};\\\", \\\"{x:1474,y:812,t:1527019830438};\\\", \\\"{x:1474,y:823,t:1527019830455};\\\", \\\"{x:1474,y:845,t:1527019830472};\\\", \\\"{x:1476,y:859,t:1527019830489};\\\", \\\"{x:1477,y:862,t:1527019830505};\\\", \\\"{x:1478,y:862,t:1527019830582};\\\", \\\"{x:1479,y:860,t:1527019830590};\\\", \\\"{x:1480,y:856,t:1527019830606};\\\", \\\"{x:1481,y:855,t:1527019830622};\\\", \\\"{x:1481,y:853,t:1527019830638};\\\", \\\"{x:1481,y:851,t:1527019830655};\\\", \\\"{x:1483,y:846,t:1527019830672};\\\", \\\"{x:1484,y:839,t:1527019830688};\\\", \\\"{x:1485,y:833,t:1527019830705};\\\", \\\"{x:1486,y:828,t:1527019830721};\\\", \\\"{x:1486,y:827,t:1527019830739};\\\", \\\"{x:1486,y:826,t:1527019830756};\\\", \\\"{x:1487,y:825,t:1527019830773};\\\", \\\"{x:1486,y:825,t:1527019832302};\\\", \\\"{x:1485,y:825,t:1527019832309};\\\", \\\"{x:1483,y:827,t:1527019832324};\\\", \\\"{x:1481,y:829,t:1527019832339};\\\", \\\"{x:1476,y:832,t:1527019832357};\\\", \\\"{x:1473,y:833,t:1527019832374};\\\", \\\"{x:1471,y:834,t:1527019832390};\\\", \\\"{x:1470,y:835,t:1527019832478};\\\", \\\"{x:1469,y:835,t:1527019832490};\\\", \\\"{x:1468,y:836,t:1527019832507};\\\", \\\"{x:1467,y:836,t:1527019832523};\\\", \\\"{x:1468,y:836,t:1527019832934};\\\", \\\"{x:1470,y:836,t:1527019832949};\\\", \\\"{x:1471,y:836,t:1527019832957};\\\", \\\"{x:1472,y:835,t:1527019832982};\\\", \\\"{x:1468,y:832,t:1527019838358};\\\", \\\"{x:1458,y:829,t:1527019838365};\\\", \\\"{x:1443,y:821,t:1527019838377};\\\", \\\"{x:1410,y:806,t:1527019838394};\\\", \\\"{x:1377,y:792,t:1527019838412};\\\", \\\"{x:1341,y:778,t:1527019838428};\\\", \\\"{x:1319,y:768,t:1527019838444};\\\", \\\"{x:1303,y:761,t:1527019838461};\\\", \\\"{x:1300,y:760,t:1527019838478};\\\", \\\"{x:1302,y:760,t:1527019838645};\\\", \\\"{x:1304,y:760,t:1527019838662};\\\", \\\"{x:1307,y:761,t:1527019838679};\\\", \\\"{x:1307,y:762,t:1527019838695};\\\", \\\"{x:1309,y:762,t:1527019838717};\\\", \\\"{x:1310,y:762,t:1527019838733};\\\", \\\"{x:1312,y:763,t:1527019838744};\\\", \\\"{x:1316,y:765,t:1527019838762};\\\", \\\"{x:1318,y:766,t:1527019838779};\\\", \\\"{x:1320,y:767,t:1527019838794};\\\", \\\"{x:1322,y:767,t:1527019838902};\\\", \\\"{x:1322,y:768,t:1527019838918};\\\", \\\"{x:1323,y:768,t:1527019838933};\\\", \\\"{x:1324,y:765,t:1527019839237};\\\", \\\"{x:1324,y:747,t:1527019839245};\\\", \\\"{x:1324,y:685,t:1527019839261};\\\", \\\"{x:1324,y:613,t:1527019839279};\\\", \\\"{x:1351,y:542,t:1527019839296};\\\", \\\"{x:1390,y:474,t:1527019839311};\\\", \\\"{x:1432,y:375,t:1527019839328};\\\", \\\"{x:1477,y:270,t:1527019839345};\\\", \\\"{x:1514,y:164,t:1527019839362};\\\", \\\"{x:1537,y:114,t:1527019839378};\\\", \\\"{x:1551,y:89,t:1527019839395};\\\", \\\"{x:1557,y:76,t:1527019839412};\\\", \\\"{x:1562,y:64,t:1527019839429};\\\", \\\"{x:1570,y:47,t:1527019839445};\\\", \\\"{x:1576,y:40,t:1527019839462};\\\", \\\"{x:1580,y:35,t:1527019839478};\\\", \\\"{x:1581,y:34,t:1527019839495};\\\", \\\"{x:1575,y:36,t:1527019839541};\\\", \\\"{x:1564,y:42,t:1527019839549};\\\", \\\"{x:1550,y:51,t:1527019839562};\\\", \\\"{x:1521,y:83,t:1527019839579};\\\", \\\"{x:1489,y:130,t:1527019839595};\\\", \\\"{x:1461,y:170,t:1527019839612};\\\", \\\"{x:1455,y:183,t:1527019839628};\\\", \\\"{x:1455,y:184,t:1527019839646};\\\", \\\"{x:1457,y:187,t:1527019839741};\\\", \\\"{x:1458,y:188,t:1527019839749};\\\", \\\"{x:1459,y:189,t:1527019839762};\\\", \\\"{x:1459,y:196,t:1527019839779};\\\", \\\"{x:1459,y:212,t:1527019839795};\\\", \\\"{x:1459,y:220,t:1527019839812};\\\", \\\"{x:1459,y:229,t:1527019839828};\\\", \\\"{x:1457,y:242,t:1527019839844};\\\", \\\"{x:1457,y:254,t:1527019839862};\\\", \\\"{x:1454,y:262,t:1527019839878};\\\", \\\"{x:1454,y:267,t:1527019839895};\\\", \\\"{x:1452,y:276,t:1527019839912};\\\", \\\"{x:1450,y:284,t:1527019839929};\\\", \\\"{x:1446,y:293,t:1527019839945};\\\", \\\"{x:1445,y:301,t:1527019839962};\\\", \\\"{x:1441,y:306,t:1527019839979};\\\", \\\"{x:1440,y:310,t:1527019839995};\\\", \\\"{x:1437,y:314,t:1527019840012};\\\", \\\"{x:1434,y:318,t:1527019840029};\\\", \\\"{x:1433,y:320,t:1527019840045};\\\", \\\"{x:1432,y:321,t:1527019840069};\\\", \\\"{x:1432,y:322,t:1527019840084};\\\", \\\"{x:1431,y:323,t:1527019840109};\\\", \\\"{x:1431,y:324,t:1527019840141};\\\", \\\"{x:1431,y:326,t:1527019840182};\\\", \\\"{x:1430,y:326,t:1527019840195};\\\", \\\"{x:1429,y:328,t:1527019840212};\\\", \\\"{x:1427,y:333,t:1527019840230};\\\", \\\"{x:1425,y:336,t:1527019840245};\\\", \\\"{x:1424,y:338,t:1527019840263};\\\", \\\"{x:1424,y:339,t:1527019840285};\\\", \\\"{x:1424,y:340,t:1527019840933};\\\", \\\"{x:1423,y:344,t:1527019840947};\\\", \\\"{x:1422,y:347,t:1527019840964};\\\", \\\"{x:1422,y:349,t:1527019840980};\\\", \\\"{x:1421,y:350,t:1527019840996};\\\", \\\"{x:1421,y:351,t:1527019841037};\\\", \\\"{x:1421,y:352,t:1527019841046};\\\", \\\"{x:1421,y:353,t:1527019841063};\\\", \\\"{x:1421,y:354,t:1527019841079};\\\", \\\"{x:1421,y:355,t:1527019841097};\\\", \\\"{x:1421,y:356,t:1527019841125};\\\", \\\"{x:1421,y:357,t:1527019841133};\\\", \\\"{x:1421,y:359,t:1527019841147};\\\", \\\"{x:1420,y:363,t:1527019841164};\\\", \\\"{x:1420,y:367,t:1527019841179};\\\", \\\"{x:1418,y:373,t:1527019841196};\\\", \\\"{x:1418,y:376,t:1527019841213};\\\", \\\"{x:1418,y:377,t:1527019841261};\\\", \\\"{x:1417,y:379,t:1527019841357};\\\", \\\"{x:1417,y:380,t:1527019841365};\\\", \\\"{x:1417,y:381,t:1527019841381};\\\", \\\"{x:1417,y:382,t:1527019841396};\\\", \\\"{x:1417,y:383,t:1527019841414};\\\", \\\"{x:1417,y:384,t:1527019841430};\\\", \\\"{x:1417,y:385,t:1527019841469};\\\", \\\"{x:1417,y:386,t:1527019841484};\\\", \\\"{x:1416,y:387,t:1527019841495};\\\", \\\"{x:1416,y:390,t:1527019841837};\\\", \\\"{x:1415,y:392,t:1527019841848};\\\", \\\"{x:1413,y:396,t:1527019841863};\\\", \\\"{x:1413,y:398,t:1527019841881};\\\", \\\"{x:1413,y:400,t:1527019841898};\\\", \\\"{x:1413,y:401,t:1527019841917};\\\", \\\"{x:1411,y:402,t:1527019841931};\\\", \\\"{x:1411,y:403,t:1527019841947};\\\", \\\"{x:1411,y:406,t:1527019841964};\\\", \\\"{x:1410,y:407,t:1527019841981};\\\", \\\"{x:1410,y:409,t:1527019841998};\\\", \\\"{x:1409,y:409,t:1527019842013};\\\", \\\"{x:1409,y:410,t:1527019842061};\\\", \\\"{x:1408,y:413,t:1527019842070};\\\", \\\"{x:1407,y:413,t:1527019842085};\\\", \\\"{x:1407,y:414,t:1527019842098};\\\", \\\"{x:1404,y:415,t:1527019842114};\\\", \\\"{x:1400,y:416,t:1527019842131};\\\", \\\"{x:1393,y:418,t:1527019842148};\\\", \\\"{x:1382,y:421,t:1527019842164};\\\", \\\"{x:1362,y:428,t:1527019842181};\\\", \\\"{x:1308,y:438,t:1527019842198};\\\", \\\"{x:1239,y:454,t:1527019842214};\\\", \\\"{x:1134,y:484,t:1527019842231};\\\", \\\"{x:1013,y:511,t:1527019842248};\\\", \\\"{x:891,y:549,t:1527019842266};\\\", \\\"{x:798,y:572,t:1527019842282};\\\", \\\"{x:726,y:591,t:1527019842297};\\\", \\\"{x:693,y:594,t:1527019842315};\\\", \\\"{x:685,y:596,t:1527019842331};\\\", \\\"{x:683,y:596,t:1527019842347};\\\", \\\"{x:668,y:603,t:1527019842364};\\\", \\\"{x:648,y:609,t:1527019842380};\\\", \\\"{x:623,y:617,t:1527019842398};\\\", \\\"{x:593,y:624,t:1527019842415};\\\", \\\"{x:570,y:627,t:1527019842431};\\\", \\\"{x:555,y:626,t:1527019842448};\\\", \\\"{x:545,y:620,t:1527019842464};\\\", \\\"{x:533,y:606,t:1527019842481};\\\", \\\"{x:519,y:586,t:1527019842499};\\\", \\\"{x:498,y:566,t:1527019842515};\\\", \\\"{x:477,y:552,t:1527019842531};\\\", \\\"{x:455,y:542,t:1527019842547};\\\", \\\"{x:429,y:529,t:1527019842564};\\\", \\\"{x:423,y:523,t:1527019842582};\\\", \\\"{x:417,y:525,t:1527019842679};\\\", \\\"{x:404,y:542,t:1527019842698};\\\", \\\"{x:387,y:561,t:1527019842715};\\\", \\\"{x:371,y:579,t:1527019842732};\\\", \\\"{x:355,y:595,t:1527019842748};\\\", \\\"{x:325,y:620,t:1527019842765};\\\", \\\"{x:310,y:626,t:1527019842782};\\\", \\\"{x:304,y:629,t:1527019842797};\\\", \\\"{x:303,y:629,t:1527019842860};\\\", \\\"{x:302,y:629,t:1527019842868};\\\", \\\"{x:301,y:629,t:1527019842881};\\\", \\\"{x:297,y:629,t:1527019842898};\\\", \\\"{x:290,y:627,t:1527019842914};\\\", \\\"{x:281,y:626,t:1527019842931};\\\", \\\"{x:268,y:622,t:1527019842949};\\\", \\\"{x:257,y:617,t:1527019842964};\\\", \\\"{x:246,y:612,t:1527019842982};\\\", \\\"{x:240,y:610,t:1527019842999};\\\", \\\"{x:234,y:607,t:1527019843015};\\\", \\\"{x:233,y:606,t:1527019843031};\\\", \\\"{x:232,y:605,t:1527019843049};\\\", \\\"{x:232,y:602,t:1527019843093};\\\", \\\"{x:232,y:597,t:1527019843101};\\\", \\\"{x:232,y:592,t:1527019843116};\\\", \\\"{x:232,y:578,t:1527019843132};\\\", \\\"{x:231,y:573,t:1527019843148};\\\", \\\"{x:231,y:570,t:1527019843166};\\\", \\\"{x:228,y:567,t:1527019843182};\\\", \\\"{x:222,y:564,t:1527019843198};\\\", \\\"{x:217,y:562,t:1527019843216};\\\", \\\"{x:216,y:562,t:1527019843232};\\\", \\\"{x:214,y:562,t:1527019843317};\\\", \\\"{x:213,y:566,t:1527019843334};\\\", \\\"{x:210,y:588,t:1527019843348};\\\", \\\"{x:208,y:597,t:1527019843365};\\\", \\\"{x:207,y:611,t:1527019843383};\\\", \\\"{x:204,y:627,t:1527019843399};\\\", \\\"{x:201,y:639,t:1527019843416};\\\", \\\"{x:199,y:647,t:1527019843432};\\\", \\\"{x:198,y:650,t:1527019843449};\\\", \\\"{x:197,y:654,t:1527019843465};\\\", \\\"{x:196,y:661,t:1527019843482};\\\", \\\"{x:192,y:668,t:1527019843500};\\\", \\\"{x:191,y:670,t:1527019843517};\\\", \\\"{x:190,y:670,t:1527019843540};\\\", \\\"{x:192,y:669,t:1527019843605};\\\", \\\"{x:201,y:665,t:1527019843616};\\\", \\\"{x:236,y:644,t:1527019843632};\\\", \\\"{x:279,y:623,t:1527019843650};\\\", \\\"{x:308,y:601,t:1527019843666};\\\", \\\"{x:328,y:590,t:1527019843683};\\\", \\\"{x:340,y:585,t:1527019843699};\\\", \\\"{x:346,y:582,t:1527019843715};\\\", \\\"{x:347,y:582,t:1527019843732};\\\", \\\"{x:348,y:580,t:1527019843814};\\\", \\\"{x:349,y:580,t:1527019843829};\\\", \\\"{x:349,y:579,t:1527019843837};\\\", \\\"{x:350,y:578,t:1527019843849};\\\", \\\"{x:352,y:578,t:1527019843869};\\\", \\\"{x:353,y:578,t:1527019843883};\\\", \\\"{x:359,y:573,t:1527019843899};\\\", \\\"{x:369,y:565,t:1527019843916};\\\", \\\"{x:379,y:559,t:1527019843934};\\\", \\\"{x:383,y:557,t:1527019843949};\\\", \\\"{x:384,y:557,t:1527019843966};\\\", \\\"{x:385,y:557,t:1527019843982};\\\", \\\"{x:386,y:558,t:1527019843999};\\\", \\\"{x:388,y:560,t:1527019844015};\\\", \\\"{x:390,y:561,t:1527019844032};\\\", \\\"{x:389,y:567,t:1527019844160};\\\", \\\"{x:389,y:573,t:1527019844166};\\\", \\\"{x:388,y:584,t:1527019844182};\\\", \\\"{x:388,y:589,t:1527019844198};\\\", \\\"{x:388,y:590,t:1527019844216};\\\", \\\"{x:388,y:591,t:1527019844317};\\\", \\\"{x:388,y:591,t:1527019844365};\\\", \\\"{x:389,y:590,t:1527019844653};\\\", \\\"{x:389,y:588,t:1527019844668};\\\", \\\"{x:389,y:585,t:1527019844683};\\\", \\\"{x:389,y:584,t:1527019844700};\\\", \\\"{x:389,y:583,t:1527019844758};\\\", \\\"{x:389,y:582,t:1527019845036};\\\", \\\"{x:389,y:582,t:1527019845046};\\\", \\\"{x:389,y:581,t:1527019845268};\\\", \\\"{x:387,y:582,t:1527019845292};\\\", \\\"{x:386,y:582,t:1527019845301};\\\", \\\"{x:382,y:585,t:1527019845316};\\\", \\\"{x:380,y:585,t:1527019845334};\\\", \\\"{x:379,y:586,t:1527019845350};\\\", \\\"{x:375,y:587,t:1527019845367};\\\", \\\"{x:368,y:587,t:1527019845385};\\\", \\\"{x:351,y:587,t:1527019845400};\\\", \\\"{x:330,y:587,t:1527019845416};\\\", \\\"{x:310,y:587,t:1527019845433};\\\", \\\"{x:294,y:587,t:1527019845450};\\\", \\\"{x:274,y:587,t:1527019845467};\\\", \\\"{x:258,y:587,t:1527019845484};\\\", \\\"{x:232,y:587,t:1527019845500};\\\", \\\"{x:225,y:589,t:1527019845517};\\\", \\\"{x:224,y:591,t:1527019845535};\\\", \\\"{x:223,y:593,t:1527019845550};\\\", \\\"{x:223,y:599,t:1527019845569};\\\", \\\"{x:223,y:605,t:1527019845585};\\\", \\\"{x:225,y:615,t:1527019845600};\\\", \\\"{x:226,y:616,t:1527019845617};\\\", \\\"{x:240,y:622,t:1527019845634};\\\", \\\"{x:249,y:624,t:1527019845650};\\\", \\\"{x:277,y:630,t:1527019845668};\\\", \\\"{x:344,y:640,t:1527019845685};\\\", \\\"{x:414,y:642,t:1527019845701};\\\", \\\"{x:478,y:618,t:1527019845718};\\\", \\\"{x:508,y:603,t:1527019845735};\\\", \\\"{x:532,y:593,t:1527019845751};\\\", \\\"{x:537,y:591,t:1527019845767};\\\", \\\"{x:539,y:589,t:1527019845784};\\\", \\\"{x:539,y:588,t:1527019845801};\\\", \\\"{x:539,y:587,t:1527019845817};\\\", \\\"{x:539,y:586,t:1527019845834};\\\", \\\"{x:543,y:582,t:1527019845851};\\\", \\\"{x:550,y:576,t:1527019845867};\\\", \\\"{x:559,y:571,t:1527019845884};\\\", \\\"{x:564,y:568,t:1527019845900};\\\", \\\"{x:569,y:567,t:1527019845917};\\\", \\\"{x:577,y:567,t:1527019845933};\\\", \\\"{x:592,y:564,t:1527019845950};\\\", \\\"{x:612,y:562,t:1527019845968};\\\", \\\"{x:620,y:558,t:1527019845984};\\\", \\\"{x:624,y:555,t:1527019846002};\\\", \\\"{x:625,y:554,t:1527019846016};\\\", \\\"{x:625,y:553,t:1527019846034};\\\", \\\"{x:626,y:551,t:1527019846051};\\\", \\\"{x:628,y:548,t:1527019846067};\\\", \\\"{x:630,y:541,t:1527019846084};\\\", \\\"{x:630,y:539,t:1527019846100};\\\", \\\"{x:632,y:534,t:1527019846117};\\\", \\\"{x:632,y:530,t:1527019846134};\\\", \\\"{x:632,y:528,t:1527019846151};\\\", \\\"{x:630,y:529,t:1527019846277};\\\", \\\"{x:623,y:533,t:1527019846285};\\\", \\\"{x:622,y:534,t:1527019846301};\\\", \\\"{x:622,y:535,t:1527019846317};\\\", \\\"{x:622,y:536,t:1527019846654};\\\", \\\"{x:643,y:533,t:1527019846669};\\\", \\\"{x:854,y:505,t:1527019846684};\\\", \\\"{x:1017,y:490,t:1527019846701};\\\", \\\"{x:1161,y:468,t:1527019846718};\\\", \\\"{x:1329,y:451,t:1527019846735};\\\", \\\"{x:1458,y:436,t:1527019846751};\\\", \\\"{x:1574,y:426,t:1527019846768};\\\", \\\"{x:1627,y:416,t:1527019846785};\\\", \\\"{x:1641,y:414,t:1527019846801};\\\", \\\"{x:1642,y:414,t:1527019846818};\\\", \\\"{x:1643,y:413,t:1527019846853};\\\", \\\"{x:1639,y:409,t:1527019846918};\\\", \\\"{x:1613,y:399,t:1527019846935};\\\", \\\"{x:1572,y:383,t:1527019846952};\\\", \\\"{x:1532,y:368,t:1527019846969};\\\", \\\"{x:1511,y:363,t:1527019846986};\\\", \\\"{x:1508,y:363,t:1527019847002};\\\", \\\"{x:1507,y:362,t:1527019847142};\\\", \\\"{x:1506,y:362,t:1527019847230};\\\", \\\"{x:1505,y:360,t:1527019847237};\\\", \\\"{x:1501,y:355,t:1527019847253};\\\", \\\"{x:1492,y:342,t:1527019847269};\\\", \\\"{x:1489,y:332,t:1527019847286};\\\", \\\"{x:1489,y:328,t:1527019847303};\\\", \\\"{x:1489,y:324,t:1527019847319};\\\", \\\"{x:1488,y:322,t:1527019847336};\\\", \\\"{x:1488,y:321,t:1527019847358};\\\", \\\"{x:1487,y:321,t:1527019847726};\\\", \\\"{x:1485,y:321,t:1527019848406};\\\", \\\"{x:1481,y:331,t:1527019848420};\\\", \\\"{x:1467,y:360,t:1527019848437};\\\", \\\"{x:1462,y:371,t:1527019848454};\\\", \\\"{x:1461,y:375,t:1527019848471};\\\", \\\"{x:1459,y:377,t:1527019848487};\\\", \\\"{x:1459,y:378,t:1527019848504};\\\", \\\"{x:1459,y:379,t:1527019848566};\\\", \\\"{x:1457,y:381,t:1527019848573};\\\", \\\"{x:1457,y:382,t:1527019848586};\\\", \\\"{x:1456,y:386,t:1527019848604};\\\", \\\"{x:1453,y:392,t:1527019848621};\\\", \\\"{x:1450,y:399,t:1527019848637};\\\", \\\"{x:1445,y:408,t:1527019848653};\\\", \\\"{x:1440,y:417,t:1527019848671};\\\", \\\"{x:1436,y:424,t:1527019848687};\\\", \\\"{x:1434,y:432,t:1527019848704};\\\", \\\"{x:1432,y:438,t:1527019848721};\\\", \\\"{x:1430,y:443,t:1527019848737};\\\", \\\"{x:1429,y:447,t:1527019848754};\\\", \\\"{x:1428,y:451,t:1527019848771};\\\", \\\"{x:1426,y:458,t:1527019848788};\\\", \\\"{x:1424,y:470,t:1527019848804};\\\", \\\"{x:1423,y:481,t:1527019848821};\\\", \\\"{x:1422,y:483,t:1527019848838};\\\", \\\"{x:1422,y:484,t:1527019848854};\\\", \\\"{x:1421,y:485,t:1527019848901};\\\", \\\"{x:1421,y:490,t:1527019849725};\\\", \\\"{x:1421,y:497,t:1527019849737};\\\", \\\"{x:1419,y:507,t:1527019849754};\\\", \\\"{x:1417,y:512,t:1527019849771};\\\", \\\"{x:1417,y:513,t:1527019849787};\\\", \\\"{x:1417,y:514,t:1527019849804};\\\", \\\"{x:1417,y:515,t:1527019849996};\\\", \\\"{x:1416,y:516,t:1527019850012};\\\", \\\"{x:1416,y:519,t:1527019850021};\\\", \\\"{x:1415,y:526,t:1527019850038};\\\", \\\"{x:1414,y:529,t:1527019850054};\\\", \\\"{x:1414,y:532,t:1527019850071};\\\", \\\"{x:1414,y:534,t:1527019850088};\\\", \\\"{x:1412,y:538,t:1527019850104};\\\", \\\"{x:1412,y:542,t:1527019850121};\\\", \\\"{x:1411,y:549,t:1527019850139};\\\", \\\"{x:1411,y:553,t:1527019850154};\\\", \\\"{x:1410,y:556,t:1527019850172};\\\", \\\"{x:1410,y:557,t:1527019850188};\\\", \\\"{x:1410,y:559,t:1527019850229};\\\", \\\"{x:1402,y:561,t:1527019854661};\\\", \\\"{x:1377,y:570,t:1527019854676};\\\", \\\"{x:1212,y:593,t:1527019854692};\\\", \\\"{x:1012,y:598,t:1527019854710};\\\", \\\"{x:807,y:609,t:1527019854727};\\\", \\\"{x:638,y:634,t:1527019854743};\\\", \\\"{x:512,y:644,t:1527019854759};\\\", \\\"{x:429,y:644,t:1527019854775};\\\", \\\"{x:397,y:644,t:1527019854792};\\\", \\\"{x:391,y:644,t:1527019854808};\\\", \\\"{x:389,y:644,t:1527019854836};\\\", \\\"{x:386,y:644,t:1527019854844};\\\", \\\"{x:380,y:644,t:1527019854858};\\\", \\\"{x:359,y:650,t:1527019854875};\\\", \\\"{x:329,y:650,t:1527019854891};\\\", \\\"{x:299,y:650,t:1527019854907};\\\", \\\"{x:286,y:648,t:1527019854924};\\\", \\\"{x:285,y:647,t:1527019854948};\\\", \\\"{x:285,y:645,t:1527019854958};\\\", \\\"{x:290,y:639,t:1527019854975};\\\", \\\"{x:309,y:629,t:1527019854992};\\\", \\\"{x:334,y:617,t:1527019855008};\\\", \\\"{x:366,y:603,t:1527019855024};\\\", \\\"{x:407,y:585,t:1527019855041};\\\", \\\"{x:436,y:572,t:1527019855058};\\\", \\\"{x:453,y:565,t:1527019855075};\\\", \\\"{x:469,y:558,t:1527019855091};\\\", \\\"{x:489,y:553,t:1527019855109};\\\", \\\"{x:501,y:550,t:1527019855125};\\\", \\\"{x:507,y:548,t:1527019855142};\\\", \\\"{x:513,y:546,t:1527019855158};\\\", \\\"{x:519,y:545,t:1527019855175};\\\", \\\"{x:527,y:545,t:1527019855191};\\\", \\\"{x:542,y:545,t:1527019855209};\\\", \\\"{x:564,y:545,t:1527019855225};\\\", \\\"{x:587,y:545,t:1527019855241};\\\", \\\"{x:610,y:545,t:1527019855259};\\\", \\\"{x:640,y:545,t:1527019855275};\\\", \\\"{x:671,y:550,t:1527019855292};\\\", \\\"{x:714,y:554,t:1527019855308};\\\", \\\"{x:736,y:554,t:1527019855325};\\\", \\\"{x:749,y:554,t:1527019855341};\\\", \\\"{x:757,y:554,t:1527019855358};\\\", \\\"{x:766,y:554,t:1527019855374};\\\", \\\"{x:773,y:554,t:1527019855391};\\\", \\\"{x:785,y:554,t:1527019855408};\\\", \\\"{x:806,y:551,t:1527019855424};\\\", \\\"{x:835,y:550,t:1527019855442};\\\", \\\"{x:866,y:545,t:1527019855458};\\\", \\\"{x:895,y:539,t:1527019855476};\\\", \\\"{x:915,y:534,t:1527019855491};\\\", \\\"{x:925,y:529,t:1527019855508};\\\", \\\"{x:926,y:527,t:1527019855526};\\\", \\\"{x:927,y:527,t:1527019855541};\\\", \\\"{x:924,y:527,t:1527019855614};\\\", \\\"{x:915,y:529,t:1527019855625};\\\", \\\"{x:895,y:539,t:1527019855642};\\\", \\\"{x:871,y:545,t:1527019855659};\\\", \\\"{x:848,y:545,t:1527019855677};\\\", \\\"{x:835,y:545,t:1527019855691};\\\", \\\"{x:833,y:545,t:1527019855708};\\\", \\\"{x:833,y:543,t:1527019856181};\\\", \\\"{x:843,y:540,t:1527019856193};\\\", \\\"{x:877,y:532,t:1527019856210};\\\", \\\"{x:935,y:518,t:1527019856225};\\\", \\\"{x:996,y:509,t:1527019856242};\\\", \\\"{x:1057,y:501,t:1527019856259};\\\", \\\"{x:1111,y:499,t:1527019856275};\\\", \\\"{x:1199,y:496,t:1527019856293};\\\", \\\"{x:1252,y:496,t:1527019856310};\\\", \\\"{x:1296,y:490,t:1527019856326};\\\", \\\"{x:1338,y:485,t:1527019856343};\\\", \\\"{x:1372,y:485,t:1527019856359};\\\", \\\"{x:1387,y:485,t:1527019856376};\\\", \\\"{x:1392,y:485,t:1527019856392};\\\", \\\"{x:1393,y:489,t:1527019856510};\\\", \\\"{x:1396,y:506,t:1527019856526};\\\", \\\"{x:1400,y:539,t:1527019856543};\\\", \\\"{x:1402,y:568,t:1527019856560};\\\", \\\"{x:1405,y:587,t:1527019856576};\\\", \\\"{x:1408,y:596,t:1527019856592};\\\", \\\"{x:1409,y:601,t:1527019856609};\\\", \\\"{x:1411,y:604,t:1527019856625};\\\", \\\"{x:1411,y:606,t:1527019856643};\\\", \\\"{x:1411,y:610,t:1527019856660};\\\", \\\"{x:1411,y:615,t:1527019856676};\\\", \\\"{x:1411,y:616,t:1527019856806};\\\", \\\"{x:1411,y:621,t:1527019856862};\\\", \\\"{x:1411,y:630,t:1527019856877};\\\", \\\"{x:1409,y:636,t:1527019856894};\\\", \\\"{x:1407,y:641,t:1527019856910};\\\", \\\"{x:1407,y:645,t:1527019856926};\\\", \\\"{x:1403,y:651,t:1527019856943};\\\", \\\"{x:1401,y:657,t:1527019856960};\\\", \\\"{x:1398,y:662,t:1527019856977};\\\", \\\"{x:1397,y:663,t:1527019856993};\\\", \\\"{x:1396,y:665,t:1527019857010};\\\", \\\"{x:1394,y:668,t:1527019857027};\\\", \\\"{x:1390,y:677,t:1527019857043};\\\", \\\"{x:1385,y:687,t:1527019857060};\\\", \\\"{x:1378,y:701,t:1527019857077};\\\", \\\"{x:1374,y:708,t:1527019857094};\\\", \\\"{x:1372,y:710,t:1527019857111};\\\", \\\"{x:1370,y:713,t:1527019857127};\\\", \\\"{x:1369,y:716,t:1527019857144};\\\", \\\"{x:1368,y:719,t:1527019857160};\\\", \\\"{x:1367,y:722,t:1527019857177};\\\", \\\"{x:1366,y:723,t:1527019857195};\\\", \\\"{x:1366,y:725,t:1527019857221};\\\", \\\"{x:1366,y:728,t:1527019857229};\\\", \\\"{x:1366,y:730,t:1527019857244};\\\", \\\"{x:1366,y:741,t:1527019857260};\\\", \\\"{x:1362,y:760,t:1527019857277};\\\", \\\"{x:1356,y:773,t:1527019857294};\\\", \\\"{x:1345,y:791,t:1527019857310};\\\", \\\"{x:1315,y:809,t:1527019857327};\\\", \\\"{x:1234,y:831,t:1527019857344};\\\", \\\"{x:1136,y:865,t:1527019857360};\\\", \\\"{x:1033,y:897,t:1527019857377};\\\", \\\"{x:922,y:915,t:1527019857394};\\\", \\\"{x:786,y:920,t:1527019857410};\\\", \\\"{x:642,y:920,t:1527019857427};\\\", \\\"{x:533,y:917,t:1527019857444};\\\", \\\"{x:430,y:883,t:1527019857461};\\\", \\\"{x:316,y:808,t:1527019857476};\\\", \\\"{x:293,y:780,t:1527019857494};\\\", \\\"{x:292,y:771,t:1527019857510};\\\", \\\"{x:292,y:761,t:1527019857526};\\\", \\\"{x:299,y:757,t:1527019857544};\\\", \\\"{x:306,y:754,t:1527019857561};\\\", \\\"{x:310,y:752,t:1527019857577};\\\", \\\"{x:314,y:749,t:1527019857594};\\\", \\\"{x:314,y:741,t:1527019857611};\\\", \\\"{x:309,y:726,t:1527019857627};\\\", \\\"{x:308,y:723,t:1527019857644};\\\", \\\"{x:310,y:715,t:1527019857661};\\\", \\\"{x:321,y:684,t:1527019857677};\\\", \\\"{x:331,y:667,t:1527019857696};\\\", \\\"{x:334,y:664,t:1527019857711};\\\", \\\"{x:338,y:662,t:1527019857726};\\\", \\\"{x:343,y:660,t:1527019857744};\\\", \\\"{x:355,y:671,t:1527019857761};\\\", \\\"{x:379,y:706,t:1527019857776};\\\", \\\"{x:391,y:726,t:1527019857793};\\\", \\\"{x:397,y:735,t:1527019857810};\\\", \\\"{x:399,y:738,t:1527019857827};\\\", \\\"{x:403,y:741,t:1527019857844};\\\", \\\"{x:408,y:742,t:1527019857860};\\\", \\\"{x:415,y:745,t:1527019857877};\\\", \\\"{x:425,y:751,t:1527019857894};\\\", \\\"{x:435,y:757,t:1527019857911};\\\", \\\"{x:441,y:759,t:1527019857927};\\\", \\\"{x:445,y:759,t:1527019857944};\\\", \\\"{x:446,y:759,t:1527019857961};\\\", \\\"{x:448,y:756,t:1527019857977};\\\", \\\"{x:450,y:753,t:1527019857993};\\\", \\\"{x:456,y:750,t:1527019858010};\\\", \\\"{x:464,y:746,t:1527019858027};\\\", \\\"{x:474,y:740,t:1527019858043};\\\", \\\"{x:477,y:738,t:1527019858060};\\\", \\\"{x:478,y:737,t:1527019858100};\\\", \\\"{x:479,y:737,t:1527019858111};\\\", \\\"{x:482,y:736,t:1527019858127};\\\", \\\"{x:483,y:735,t:1527019858143};\\\", \\\"{x:483,y:735,t:1527019858184};\\\", \\\"{x:482,y:735,t:1527019858389};\\\", \\\"{x:481,y:736,t:1527019858412};\\\", \\\"{x:480,y:736,t:1527019858837};\\\", \\\"{x:478,y:736,t:1527019858845};\\\", \\\"{x:476,y:738,t:1527019858861};\\\", \\\"{x:475,y:738,t:1527019858885};\\\", \\\"{x:474,y:739,t:1527019858909};\\\", \\\"{x:473,y:739,t:1527019858917};\\\", \\\"{x:472,y:740,t:1527019858928};\\\", \\\"{x:471,y:740,t:1527019858949};\\\", \\\"{x:470,y:741,t:1527019859284};\\\", \\\"{x:469,y:741,t:1527019859296};\\\", \\\"{x:466,y:741,t:1527019859311};\\\", \\\"{x:465,y:741,t:1527019859328};\\\", \\\"{x:463,y:741,t:1527019859345};\\\", \\\"{x:461,y:741,t:1527019859362};\\\", \\\"{x:458,y:740,t:1527019859378};\\\", \\\"{x:457,y:740,t:1527019859396};\\\", \\\"{x:456,y:739,t:1527019859436};\\\", \\\"{x:455,y:739,t:1527019859446};\\\", \\\"{x:452,y:738,t:1527019859469};\\\", \\\"{x:450,y:737,t:1527019859479};\\\", \\\"{x:444,y:737,t:1527019859496};\\\", \\\"{x:440,y:735,t:1527019859512};\\\" ] }, { \\\"rt\\\": 32748, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 13, \\\"time_elapsed\\\": 499466, \\\"internal_node_id\\\": \\\"0.0-6.0-3.0\\\", \\\"subject\\\": \\\"VT5BG\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"golf\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime+before+endtime+during\\\", \\\"q\\\": 9, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"I\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-12 PM-I -I -B \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:421,y:730,t:1527019859697};\\\", \\\"{x:417,y:730,t:1527019859712};\\\", \\\"{x:416,y:730,t:1527019859729};\\\", \\\"{x:413,y:728,t:1527019859745};\\\", \\\"{x:410,y:727,t:1527019859762};\\\", \\\"{x:406,y:727,t:1527019859784};\\\", \\\"{x:405,y:726,t:1527019859796};\\\", \\\"{x:402,y:725,t:1527019859811};\\\", \\\"{x:401,y:725,t:1527019859829};\\\", \\\"{x:400,y:724,t:1527019859846};\\\", \\\"{x:397,y:723,t:1527019859862};\\\", \\\"{x:388,y:721,t:1527019859933};\\\", \\\"{x:386,y:720,t:1527019859946};\\\", \\\"{x:384,y:720,t:1527019859962};\\\", \\\"{x:383,y:719,t:1527019859979};\\\", \\\"{x:382,y:719,t:1527019859996};\\\", \\\"{x:379,y:717,t:1527019860011};\\\", \\\"{x:374,y:716,t:1527019860029};\\\", \\\"{x:371,y:714,t:1527019860046};\\\", \\\"{x:368,y:713,t:1527019860061};\\\", \\\"{x:365,y:712,t:1527019860079};\\\", \\\"{x:364,y:711,t:1527019860096};\\\", \\\"{x:362,y:710,t:1527019860140};\\\", \\\"{x:361,y:710,t:1527019860197};\\\", \\\"{x:360,y:710,t:1527019860244};\\\", \\\"{x:359,y:709,t:1527019860277};\\\", \\\"{x:358,y:709,t:1527019860309};\\\", \\\"{x:356,y:708,t:1527019860349};\\\", \\\"{x:356,y:706,t:1527019861548};\\\", \\\"{x:363,y:698,t:1527019861564};\\\", \\\"{x:392,y:675,t:1527019861580};\\\", \\\"{x:532,y:594,t:1527019861597};\\\", \\\"{x:672,y:555,t:1527019861614};\\\", \\\"{x:741,y:539,t:1527019861630};\\\", \\\"{x:743,y:538,t:1527019862166};\\\", \\\"{x:748,y:538,t:1527019862180};\\\", \\\"{x:749,y:538,t:1527019862197};\\\", \\\"{x:750,y:538,t:1527019862228};\\\", \\\"{x:753,y:536,t:1527019862237};\\\", \\\"{x:758,y:536,t:1527019862247};\\\", \\\"{x:790,y:544,t:1527019862264};\\\", \\\"{x:866,y:590,t:1527019862283};\\\", \\\"{x:994,y:680,t:1527019862298};\\\", \\\"{x:1127,y:771,t:1527019862313};\\\", \\\"{x:1252,y:865,t:1527019862330};\\\", \\\"{x:1341,y:946,t:1527019862346};\\\", \\\"{x:1365,y:984,t:1527019862363};\\\", \\\"{x:1370,y:1002,t:1527019862380};\\\", \\\"{x:1368,y:1014,t:1527019862396};\\\", \\\"{x:1355,y:1020,t:1527019862412};\\\", \\\"{x:1346,y:1024,t:1527019862430};\\\", \\\"{x:1337,y:1025,t:1527019862446};\\\", \\\"{x:1333,y:1025,t:1527019862463};\\\", \\\"{x:1330,y:1019,t:1527019862549};\\\", \\\"{x:1327,y:1006,t:1527019862564};\\\", \\\"{x:1304,y:963,t:1527019862579};\\\", \\\"{x:1267,y:922,t:1527019862596};\\\", \\\"{x:1213,y:874,t:1527019862612};\\\", \\\"{x:1197,y:858,t:1527019862629};\\\", \\\"{x:1189,y:851,t:1527019862646};\\\", \\\"{x:1190,y:852,t:1527019862957};\\\", \\\"{x:1194,y:859,t:1527019862965};\\\", \\\"{x:1196,y:868,t:1527019862979};\\\", \\\"{x:1204,y:888,t:1527019862997};\\\", \\\"{x:1210,y:902,t:1527019863013};\\\", \\\"{x:1214,y:907,t:1527019863029};\\\", \\\"{x:1215,y:908,t:1527019863046};\\\", \\\"{x:1216,y:908,t:1527019863062};\\\", \\\"{x:1217,y:908,t:1527019863084};\\\", \\\"{x:1218,y:908,t:1527019863096};\\\", \\\"{x:1219,y:908,t:1527019863111};\\\", \\\"{x:1221,y:906,t:1527019863128};\\\", \\\"{x:1223,y:904,t:1527019863146};\\\", \\\"{x:1224,y:902,t:1527019863294};\\\", \\\"{x:1224,y:901,t:1527019863301};\\\", \\\"{x:1224,y:900,t:1527019863317};\\\", \\\"{x:1224,y:899,t:1527019863812};\\\", \\\"{x:1224,y:898,t:1527019863828};\\\", \\\"{x:1224,y:897,t:1527019863845};\\\", \\\"{x:1223,y:896,t:1527019864156};\\\", \\\"{x:1223,y:895,t:1527019864406};\\\", \\\"{x:1223,y:894,t:1527019864413};\\\", \\\"{x:1223,y:892,t:1527019864428};\\\", \\\"{x:1223,y:890,t:1527019864445};\\\", \\\"{x:1223,y:889,t:1527019864461};\\\", \\\"{x:1222,y:888,t:1527019864485};\\\", \\\"{x:1221,y:887,t:1527019864524};\\\", \\\"{x:1220,y:886,t:1527019864597};\\\", \\\"{x:1219,y:885,t:1527019864621};\\\", \\\"{x:1219,y:884,t:1527019864637};\\\", \\\"{x:1218,y:884,t:1527019864685};\\\", \\\"{x:1218,y:883,t:1527019864701};\\\", \\\"{x:1217,y:882,t:1527019864757};\\\", \\\"{x:1216,y:881,t:1527019864821};\\\", \\\"{x:1216,y:880,t:1527019864861};\\\", \\\"{x:1215,y:879,t:1527019865181};\\\", \\\"{x:1214,y:877,t:1527019865195};\\\", \\\"{x:1212,y:874,t:1527019865211};\\\", \\\"{x:1212,y:872,t:1527019865227};\\\", \\\"{x:1210,y:870,t:1527019865244};\\\", \\\"{x:1208,y:863,t:1527019865261};\\\", \\\"{x:1206,y:860,t:1527019865278};\\\", \\\"{x:1205,y:857,t:1527019865295};\\\", \\\"{x:1204,y:853,t:1527019865310};\\\", \\\"{x:1202,y:850,t:1527019865328};\\\", \\\"{x:1202,y:849,t:1527019865344};\\\", \\\"{x:1201,y:846,t:1527019865360};\\\", \\\"{x:1199,y:844,t:1527019865377};\\\", \\\"{x:1198,y:841,t:1527019865395};\\\", \\\"{x:1198,y:840,t:1527019865411};\\\", \\\"{x:1198,y:839,t:1527019865427};\\\", \\\"{x:1198,y:838,t:1527019865477};\\\", \\\"{x:1197,y:837,t:1527019865495};\\\", \\\"{x:1196,y:837,t:1527019865511};\\\", \\\"{x:1196,y:836,t:1527019865528};\\\", \\\"{x:1196,y:835,t:1527019865549};\\\", \\\"{x:1195,y:834,t:1527019865573};\\\", \\\"{x:1195,y:833,t:1527019865741};\\\", \\\"{x:1195,y:832,t:1527019865765};\\\", \\\"{x:1195,y:829,t:1527019866878};\\\", \\\"{x:1194,y:799,t:1527019866893};\\\", \\\"{x:1186,y:774,t:1527019866909};\\\", \\\"{x:1182,y:758,t:1527019866929};\\\", \\\"{x:1179,y:751,t:1527019866944};\\\", \\\"{x:1178,y:746,t:1527019866959};\\\", \\\"{x:1178,y:745,t:1527019867253};\\\", \\\"{x:1176,y:745,t:1527019867261};\\\", \\\"{x:1173,y:746,t:1527019867276};\\\", \\\"{x:1168,y:751,t:1527019867293};\\\", \\\"{x:1166,y:752,t:1527019867310};\\\", \\\"{x:1167,y:752,t:1527019869885};\\\", \\\"{x:1168,y:752,t:1527019869893};\\\", \\\"{x:1169,y:751,t:1527019869917};\\\", \\\"{x:1170,y:750,t:1527019869941};\\\", \\\"{x:1170,y:749,t:1527019869957};\\\", \\\"{x:1171,y:748,t:1527019869997};\\\", \\\"{x:1171,y:747,t:1527019870012};\\\", \\\"{x:1172,y:745,t:1527019870028};\\\", \\\"{x:1173,y:745,t:1527019870045};\\\", \\\"{x:1174,y:743,t:1527019870077};\\\", \\\"{x:1175,y:741,t:1527019870123};\\\", \\\"{x:1176,y:739,t:1527019870155};\\\", \\\"{x:1176,y:738,t:1527019870173};\\\", \\\"{x:1177,y:738,t:1527019870191};\\\", \\\"{x:1178,y:737,t:1527019870206};\\\", \\\"{x:1179,y:736,t:1527019870236};\\\", \\\"{x:1180,y:735,t:1527019870244};\\\", \\\"{x:1181,y:733,t:1527019870256};\\\", \\\"{x:1181,y:731,t:1527019870273};\\\", \\\"{x:1183,y:729,t:1527019870290};\\\", \\\"{x:1184,y:728,t:1527019870306};\\\", \\\"{x:1186,y:725,t:1527019870323};\\\", \\\"{x:1188,y:722,t:1527019870339};\\\", \\\"{x:1191,y:718,t:1527019870357};\\\", \\\"{x:1193,y:715,t:1527019870374};\\\", \\\"{x:1196,y:712,t:1527019870389};\\\", \\\"{x:1201,y:708,t:1527019870406};\\\", \\\"{x:1206,y:704,t:1527019870424};\\\", \\\"{x:1212,y:699,t:1527019870440};\\\", \\\"{x:1219,y:695,t:1527019870456};\\\", \\\"{x:1226,y:691,t:1527019870473};\\\", \\\"{x:1231,y:687,t:1527019870490};\\\", \\\"{x:1236,y:684,t:1527019870506};\\\", \\\"{x:1241,y:680,t:1527019870523};\\\", \\\"{x:1245,y:677,t:1527019870540};\\\", \\\"{x:1249,y:674,t:1527019870557};\\\", \\\"{x:1251,y:672,t:1527019870574};\\\", \\\"{x:1255,y:670,t:1527019870590};\\\", \\\"{x:1257,y:668,t:1527019870607};\\\", \\\"{x:1258,y:667,t:1527019870624};\\\", \\\"{x:1259,y:665,t:1527019870639};\\\", \\\"{x:1260,y:665,t:1527019871206};\\\", \\\"{x:1263,y:669,t:1527019871223};\\\", \\\"{x:1270,y:681,t:1527019871240};\\\", \\\"{x:1276,y:690,t:1527019871255};\\\", \\\"{x:1279,y:695,t:1527019871273};\\\", \\\"{x:1281,y:698,t:1527019871290};\\\", \\\"{x:1282,y:699,t:1527019871306};\\\", \\\"{x:1282,y:700,t:1527019871342};\\\", \\\"{x:1283,y:702,t:1527019871356};\\\", \\\"{x:1286,y:707,t:1527019871373};\\\", \\\"{x:1288,y:710,t:1527019871389};\\\", \\\"{x:1289,y:713,t:1527019871406};\\\", \\\"{x:1290,y:714,t:1527019871423};\\\", \\\"{x:1292,y:719,t:1527019871440};\\\", \\\"{x:1295,y:725,t:1527019871455};\\\", \\\"{x:1300,y:735,t:1527019871472};\\\", \\\"{x:1304,y:742,t:1527019871488};\\\", \\\"{x:1307,y:747,t:1527019871506};\\\", \\\"{x:1311,y:752,t:1527019871523};\\\", \\\"{x:1317,y:759,t:1527019871539};\\\", \\\"{x:1320,y:766,t:1527019871556};\\\", \\\"{x:1327,y:773,t:1527019871573};\\\", \\\"{x:1331,y:779,t:1527019871589};\\\", \\\"{x:1334,y:782,t:1527019871606};\\\", \\\"{x:1339,y:787,t:1527019871623};\\\", \\\"{x:1342,y:790,t:1527019871639};\\\", \\\"{x:1345,y:791,t:1527019871656};\\\", \\\"{x:1346,y:792,t:1527019871869};\\\", \\\"{x:1346,y:791,t:1527019871885};\\\", \\\"{x:1347,y:789,t:1527019871893};\\\", \\\"{x:1348,y:786,t:1527019871906};\\\", \\\"{x:1349,y:782,t:1527019871922};\\\", \\\"{x:1349,y:781,t:1527019871938};\\\", \\\"{x:1350,y:778,t:1527019871956};\\\", \\\"{x:1351,y:777,t:1527019871972};\\\", \\\"{x:1351,y:772,t:1527019872739};\\\", \\\"{x:1351,y:769,t:1527019872753};\\\", \\\"{x:1351,y:763,t:1527019872769};\\\", \\\"{x:1351,y:761,t:1527019872785};\\\", \\\"{x:1351,y:760,t:1527019877547};\\\", \\\"{x:1341,y:762,t:1527019877555};\\\", \\\"{x:1327,y:767,t:1527019877566};\\\", \\\"{x:1287,y:781,t:1527019877582};\\\", \\\"{x:1218,y:810,t:1527019877599};\\\", \\\"{x:1129,y:835,t:1527019877616};\\\", \\\"{x:1086,y:844,t:1527019877631};\\\", \\\"{x:1073,y:845,t:1527019877649};\\\", \\\"{x:1069,y:845,t:1527019877664};\\\", \\\"{x:1068,y:845,t:1527019877699};\\\", \\\"{x:1069,y:845,t:1527019877755};\\\", \\\"{x:1071,y:845,t:1527019877764};\\\", \\\"{x:1079,y:845,t:1527019877782};\\\", \\\"{x:1084,y:843,t:1527019877798};\\\", \\\"{x:1092,y:839,t:1527019877815};\\\", \\\"{x:1104,y:834,t:1527019877832};\\\", \\\"{x:1118,y:831,t:1527019877849};\\\", \\\"{x:1129,y:829,t:1527019877864};\\\", \\\"{x:1136,y:829,t:1527019877882};\\\", \\\"{x:1138,y:829,t:1527019877898};\\\", \\\"{x:1139,y:829,t:1527019877930};\\\", \\\"{x:1141,y:830,t:1527019877949};\\\", \\\"{x:1144,y:831,t:1527019877965};\\\", \\\"{x:1146,y:832,t:1527019877982};\\\", \\\"{x:1147,y:832,t:1527019877999};\\\", \\\"{x:1148,y:832,t:1527019878018};\\\", \\\"{x:1149,y:832,t:1527019878067};\\\", \\\"{x:1151,y:832,t:1527019878082};\\\", \\\"{x:1155,y:832,t:1527019878098};\\\", \\\"{x:1158,y:831,t:1527019878114};\\\", \\\"{x:1160,y:831,t:1527019878131};\\\", \\\"{x:1162,y:831,t:1527019878147};\\\", \\\"{x:1167,y:831,t:1527019878164};\\\", \\\"{x:1169,y:831,t:1527019878181};\\\", \\\"{x:1171,y:831,t:1527019878314};\\\", \\\"{x:1173,y:835,t:1527019878331};\\\", \\\"{x:1175,y:838,t:1527019878347};\\\", \\\"{x:1176,y:840,t:1527019878364};\\\", \\\"{x:1177,y:840,t:1527019878395};\\\", \\\"{x:1179,y:842,t:1527019878402};\\\", \\\"{x:1180,y:842,t:1527019878415};\\\", \\\"{x:1182,y:843,t:1527019878431};\\\", \\\"{x:1183,y:844,t:1527019878448};\\\", \\\"{x:1183,y:843,t:1527019878634};\\\", \\\"{x:1182,y:843,t:1527019878675};\\\", \\\"{x:1181,y:843,t:1527019878690};\\\", \\\"{x:1180,y:842,t:1527019878698};\\\", \\\"{x:1178,y:841,t:1527019878714};\\\", \\\"{x:1176,y:841,t:1527019878730};\\\", \\\"{x:1176,y:840,t:1527019878875};\\\", \\\"{x:1174,y:840,t:1527019878890};\\\", \\\"{x:1172,y:839,t:1527019878898};\\\", \\\"{x:1170,y:838,t:1527019878914};\\\", \\\"{x:1161,y:830,t:1527019878930};\\\", \\\"{x:1158,y:826,t:1527019878948};\\\", \\\"{x:1156,y:825,t:1527019878963};\\\", \\\"{x:1155,y:824,t:1527019879098};\\\", \\\"{x:1154,y:824,t:1527019879113};\\\", \\\"{x:1149,y:820,t:1527019879129};\\\", \\\"{x:1146,y:818,t:1527019879147};\\\", \\\"{x:1142,y:815,t:1527019879163};\\\", \\\"{x:1138,y:812,t:1527019879180};\\\", \\\"{x:1136,y:810,t:1527019879196};\\\", \\\"{x:1135,y:809,t:1527019879213};\\\", \\\"{x:1134,y:809,t:1527019879230};\\\", \\\"{x:1132,y:808,t:1527019879246};\\\", \\\"{x:1131,y:807,t:1527019879265};\\\", \\\"{x:1130,y:806,t:1527019879280};\\\", \\\"{x:1130,y:805,t:1527019879297};\\\", \\\"{x:1129,y:805,t:1527019879313};\\\", \\\"{x:1128,y:805,t:1527019879329};\\\", \\\"{x:1126,y:804,t:1527019879346};\\\", \\\"{x:1126,y:803,t:1527019879369};\\\", \\\"{x:1125,y:802,t:1527019879394};\\\", \\\"{x:1125,y:801,t:1527019879417};\\\", \\\"{x:1118,y:801,t:1527019884643};\\\", \\\"{x:1006,y:784,t:1527019884659};\\\", \\\"{x:981,y:768,t:1527019884676};\\\", \\\"{x:982,y:768,t:1527019886250};\\\", \\\"{x:983,y:768,t:1527019886307};\\\", \\\"{x:984,y:768,t:1527019886330};\\\", \\\"{x:986,y:768,t:1527019886341};\\\", \\\"{x:988,y:768,t:1527019886358};\\\", \\\"{x:991,y:770,t:1527019886375};\\\", \\\"{x:991,y:771,t:1527019886391};\\\", \\\"{x:994,y:772,t:1527019886408};\\\", \\\"{x:1002,y:777,t:1527019886424};\\\", \\\"{x:1015,y:782,t:1527019886441};\\\", \\\"{x:1022,y:786,t:1527019886458};\\\", \\\"{x:1026,y:789,t:1527019886474};\\\", \\\"{x:1026,y:788,t:1527019887555};\\\", \\\"{x:1026,y:786,t:1527019887587};\\\", \\\"{x:1026,y:785,t:1527019887602};\\\", \\\"{x:1026,y:784,t:1527019887610};\\\", \\\"{x:1026,y:783,t:1527019887635};\\\", \\\"{x:1026,y:782,t:1527019888131};\\\", \\\"{x:1025,y:781,t:1527019888140};\\\", \\\"{x:1022,y:779,t:1527019888163};\\\", \\\"{x:1022,y:778,t:1527019888173};\\\", \\\"{x:1021,y:778,t:1527019888190};\\\", \\\"{x:1020,y:778,t:1527019888206};\\\", \\\"{x:1018,y:777,t:1527019888563};\\\", \\\"{x:1017,y:776,t:1527019888573};\\\", \\\"{x:1016,y:775,t:1527019888589};\\\", \\\"{x:1015,y:775,t:1527019888618};\\\", \\\"{x:1013,y:775,t:1527019888626};\\\", \\\"{x:1011,y:773,t:1527019888642};\\\", \\\"{x:1009,y:772,t:1527019888656};\\\", \\\"{x:1007,y:772,t:1527019888673};\\\", \\\"{x:1002,y:771,t:1527019888689};\\\", \\\"{x:1000,y:769,t:1527019888706};\\\", \\\"{x:999,y:769,t:1527019888723};\\\", \\\"{x:998,y:769,t:1527019888739};\\\", \\\"{x:997,y:769,t:1527019888756};\\\", \\\"{x:996,y:769,t:1527019888773};\\\", \\\"{x:994,y:768,t:1527019888810};\\\", \\\"{x:993,y:768,t:1527019888842};\\\", \\\"{x:992,y:768,t:1527019888856};\\\", \\\"{x:991,y:768,t:1527019888872};\\\", \\\"{x:989,y:767,t:1527019888889};\\\", \\\"{x:984,y:765,t:1527019888906};\\\", \\\"{x:981,y:764,t:1527019888922};\\\", \\\"{x:975,y:762,t:1527019888939};\\\", \\\"{x:966,y:757,t:1527019888956};\\\", \\\"{x:955,y:752,t:1527019888972};\\\", \\\"{x:947,y:748,t:1527019888989};\\\", \\\"{x:941,y:746,t:1527019889006};\\\", \\\"{x:934,y:743,t:1527019889022};\\\", \\\"{x:929,y:741,t:1527019889038};\\\", \\\"{x:922,y:738,t:1527019889056};\\\", \\\"{x:913,y:734,t:1527019889072};\\\", \\\"{x:905,y:730,t:1527019889089};\\\", \\\"{x:900,y:729,t:1527019889105};\\\", \\\"{x:895,y:727,t:1527019889122};\\\", \\\"{x:890,y:725,t:1527019889139};\\\", \\\"{x:885,y:723,t:1527019889156};\\\", \\\"{x:877,y:721,t:1527019889172};\\\", \\\"{x:868,y:716,t:1527019889191};\\\", \\\"{x:860,y:714,t:1527019889204};\\\", \\\"{x:854,y:712,t:1527019889221};\\\", \\\"{x:847,y:710,t:1527019889238};\\\", \\\"{x:843,y:709,t:1527019889254};\\\", \\\"{x:838,y:706,t:1527019889271};\\\", \\\"{x:832,y:704,t:1527019889289};\\\", \\\"{x:822,y:700,t:1527019889305};\\\", \\\"{x:815,y:697,t:1527019889321};\\\", \\\"{x:812,y:696,t:1527019889338};\\\", \\\"{x:809,y:695,t:1527019889355};\\\", \\\"{x:807,y:694,t:1527019889371};\\\", \\\"{x:804,y:694,t:1527019889388};\\\", \\\"{x:801,y:693,t:1527019889405};\\\", \\\"{x:797,y:691,t:1527019889422};\\\", \\\"{x:791,y:688,t:1527019889438};\\\", \\\"{x:784,y:685,t:1527019889454};\\\", \\\"{x:778,y:683,t:1527019889472};\\\", \\\"{x:775,y:681,t:1527019889489};\\\", \\\"{x:773,y:681,t:1527019889505};\\\", \\\"{x:770,y:680,t:1527019889522};\\\", \\\"{x:769,y:679,t:1527019889539};\\\", \\\"{x:767,y:679,t:1527019889555};\\\", \\\"{x:765,y:679,t:1527019889571};\\\", \\\"{x:764,y:678,t:1527019889590};\\\", \\\"{x:761,y:677,t:1527019889605};\\\", \\\"{x:760,y:676,t:1527019889622};\\\", \\\"{x:757,y:676,t:1527019889638};\\\", \\\"{x:757,y:675,t:1527019889655};\\\", \\\"{x:756,y:675,t:1527019889672};\\\", \\\"{x:754,y:675,t:1527019889698};\\\", \\\"{x:753,y:674,t:1527019889730};\\\", \\\"{x:752,y:674,t:1527019889754};\\\", \\\"{x:752,y:673,t:1527019889771};\\\", \\\"{x:750,y:672,t:1527019889789};\\\", \\\"{x:748,y:672,t:1527019889817};\\\", \\\"{x:747,y:672,t:1527019889858};\\\", \\\"{x:747,y:671,t:1527019889872};\\\", \\\"{x:745,y:671,t:1527019889906};\\\", \\\"{x:744,y:670,t:1527019889930};\\\", \\\"{x:744,y:669,t:1527019889970};\\\", \\\"{x:743,y:669,t:1527019890043};\\\", \\\"{x:742,y:669,t:1527019890074};\\\", \\\"{x:741,y:668,t:1527019890090};\\\", \\\"{x:740,y:668,t:1527019890113};\\\", \\\"{x:740,y:667,t:1527019890138};\\\", \\\"{x:739,y:666,t:1527019890162};\\\", \\\"{x:738,y:666,t:1527019890186};\\\", \\\"{x:736,y:665,t:1527019890242};\\\", \\\"{x:735,y:665,t:1527019890394};\\\", \\\"{x:735,y:664,t:1527019890404};\\\", \\\"{x:734,y:663,t:1527019890421};\\\", \\\"{x:732,y:663,t:1527019890438};\\\", \\\"{x:730,y:662,t:1527019890454};\\\", \\\"{x:728,y:661,t:1527019890471};\\\", \\\"{x:726,y:660,t:1527019890488};\\\", \\\"{x:723,y:659,t:1527019890504};\\\", \\\"{x:721,y:658,t:1527019890521};\\\", \\\"{x:718,y:657,t:1527019890538};\\\", \\\"{x:714,y:655,t:1527019890554};\\\", \\\"{x:710,y:653,t:1527019890571};\\\", \\\"{x:705,y:651,t:1527019890589};\\\", \\\"{x:699,y:648,t:1527019890604};\\\", \\\"{x:689,y:643,t:1527019890621};\\\", \\\"{x:677,y:638,t:1527019890638};\\\", \\\"{x:664,y:630,t:1527019890655};\\\", \\\"{x:645,y:619,t:1527019890670};\\\", \\\"{x:625,y:608,t:1527019890687};\\\", \\\"{x:602,y:594,t:1527019890703};\\\", \\\"{x:582,y:584,t:1527019890719};\\\", \\\"{x:560,y:574,t:1527019890735};\\\", \\\"{x:544,y:567,t:1527019890751};\\\", \\\"{x:532,y:562,t:1527019890767};\\\", \\\"{x:524,y:560,t:1527019890784};\\\", \\\"{x:516,y:557,t:1527019890801};\\\", \\\"{x:513,y:555,t:1527019890818};\\\", \\\"{x:512,y:555,t:1527019890834};\\\", \\\"{x:509,y:554,t:1527019890852};\\\", \\\"{x:505,y:553,t:1527019890867};\\\", \\\"{x:501,y:553,t:1527019890885};\\\", \\\"{x:497,y:553,t:1527019890902};\\\", \\\"{x:485,y:550,t:1527019890917};\\\", \\\"{x:470,y:548,t:1527019890935};\\\", \\\"{x:452,y:546,t:1527019890951};\\\", \\\"{x:438,y:541,t:1527019890967};\\\", \\\"{x:427,y:539,t:1527019890985};\\\", \\\"{x:415,y:536,t:1527019891002};\\\", \\\"{x:407,y:535,t:1527019891019};\\\", \\\"{x:400,y:535,t:1527019891035};\\\", \\\"{x:395,y:534,t:1527019891052};\\\", \\\"{x:380,y:531,t:1527019891069};\\\", \\\"{x:361,y:529,t:1527019891085};\\\", \\\"{x:350,y:529,t:1527019891101};\\\", \\\"{x:345,y:529,t:1527019891118};\\\", \\\"{x:341,y:529,t:1527019891134};\\\", \\\"{x:335,y:531,t:1527019891151};\\\", \\\"{x:327,y:535,t:1527019891169};\\\", \\\"{x:315,y:542,t:1527019891184};\\\", \\\"{x:300,y:547,t:1527019891201};\\\", \\\"{x:295,y:551,t:1527019891218};\\\", \\\"{x:290,y:551,t:1527019891234};\\\", \\\"{x:284,y:555,t:1527019891252};\\\", \\\"{x:274,y:557,t:1527019891269};\\\", \\\"{x:261,y:559,t:1527019891284};\\\", \\\"{x:247,y:559,t:1527019891301};\\\", \\\"{x:236,y:559,t:1527019891318};\\\", \\\"{x:229,y:559,t:1527019891335};\\\", \\\"{x:221,y:558,t:1527019891352};\\\", \\\"{x:215,y:556,t:1527019891368};\\\", \\\"{x:206,y:554,t:1527019891386};\\\", \\\"{x:192,y:552,t:1527019891401};\\\", \\\"{x:182,y:545,t:1527019891419};\\\", \\\"{x:172,y:535,t:1527019891436};\\\", \\\"{x:159,y:520,t:1527019891451};\\\", \\\"{x:148,y:506,t:1527019891470};\\\", \\\"{x:141,y:499,t:1527019891485};\\\", \\\"{x:136,y:496,t:1527019891501};\\\", \\\"{x:134,y:494,t:1527019891518};\\\", \\\"{x:133,y:493,t:1527019891536};\\\", \\\"{x:132,y:493,t:1527019891601};\\\", \\\"{x:132,y:491,t:1527019891618};\\\", \\\"{x:133,y:491,t:1527019891666};\\\", \\\"{x:139,y:492,t:1527019891674};\\\", \\\"{x:145,y:494,t:1527019891686};\\\", \\\"{x:151,y:497,t:1527019891703};\\\", \\\"{x:155,y:500,t:1527019891720};\\\", \\\"{x:155,y:501,t:1527019891810};\\\", \\\"{x:157,y:501,t:1527019891819};\\\", \\\"{x:158,y:501,t:1527019891826};\\\", \\\"{x:159,y:501,t:1527019891835};\\\", \\\"{x:160,y:501,t:1527019891852};\\\", \\\"{x:160,y:501,t:1527019891893};\\\", \\\"{x:161,y:501,t:1527019891904};\\\", \\\"{x:163,y:501,t:1527019891918};\\\", \\\"{x:170,y:506,t:1527019891935};\\\", \\\"{x:190,y:527,t:1527019891952};\\\", \\\"{x:242,y:571,t:1527019891969};\\\", \\\"{x:363,y:666,t:1527019891986};\\\", \\\"{x:429,y:718,t:1527019892003};\\\", \\\"{x:477,y:753,t:1527019892018};\\\", \\\"{x:500,y:771,t:1527019892036};\\\", \\\"{x:517,y:791,t:1527019892053};\\\", \\\"{x:527,y:809,t:1527019892068};\\\", \\\"{x:532,y:823,t:1527019892085};\\\", \\\"{x:534,y:825,t:1527019892102};\\\", \\\"{x:538,y:822,t:1527019892161};\\\", \\\"{x:541,y:817,t:1527019892169};\\\", \\\"{x:545,y:808,t:1527019892185};\\\", \\\"{x:548,y:792,t:1527019892202};\\\", \\\"{x:548,y:779,t:1527019892219};\\\", \\\"{x:548,y:766,t:1527019892235};\\\", \\\"{x:544,y:757,t:1527019892252};\\\", \\\"{x:539,y:750,t:1527019892270};\\\", \\\"{x:535,y:745,t:1527019892286};\\\", \\\"{x:534,y:744,t:1527019892303};\\\", \\\"{x:534,y:743,t:1527019893395};\\\", \\\"{x:534,y:740,t:1527019893404};\\\", \\\"{x:532,y:735,t:1527019893420};\\\", \\\"{x:532,y:728,t:1527019893437};\\\", \\\"{x:532,y:720,t:1527019893454};\\\", \\\"{x:532,y:712,t:1527019893480};\\\", \\\"{x:532,y:708,t:1527019893487};\\\", \\\"{x:531,y:702,t:1527019893503};\\\", \\\"{x:531,y:695,t:1527019893519};\\\", \\\"{x:530,y:684,t:1527019893536};\\\", \\\"{x:530,y:669,t:1527019893553};\\\" ] }, { \\\"rt\\\": 8207, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 14, \\\"time_elapsed\\\": 508874, \\\"internal_node_id\\\": \\\"0.0-6.0-4.0\\\", \\\"subject\\\": \\\"VT5BG\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"golf\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"ends\\\", \\\"q\\\": 10, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F -B -B -02 PM-02 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:533,y:634,t:1527019893653};\\\", \\\"{x:535,y:634,t:1527019895642};\\\", \\\"{x:541,y:634,t:1527019896042};\\\", \\\"{x:569,y:643,t:1527019896057};\\\", \\\"{x:608,y:656,t:1527019896072};\\\", \\\"{x:613,y:656,t:1527019896521};\\\", \\\"{x:619,y:658,t:1527019896529};\\\", \\\"{x:626,y:659,t:1527019896539};\\\", \\\"{x:633,y:660,t:1527019896555};\\\", \\\"{x:637,y:661,t:1527019896573};\\\", \\\"{x:646,y:661,t:1527019896593};\\\", \\\"{x:657,y:662,t:1527019896605};\\\", \\\"{x:668,y:662,t:1527019896623};\\\", \\\"{x:681,y:662,t:1527019896639};\\\", \\\"{x:693,y:662,t:1527019896656};\\\", \\\"{x:706,y:662,t:1527019896673};\\\", \\\"{x:733,y:662,t:1527019896690};\\\", \\\"{x:804,y:662,t:1527019896706};\\\", \\\"{x:863,y:662,t:1527019896723};\\\", \\\"{x:924,y:662,t:1527019896738};\\\", \\\"{x:986,y:662,t:1527019896756};\\\", \\\"{x:1046,y:667,t:1527019896773};\\\", \\\"{x:1112,y:685,t:1527019896789};\\\", \\\"{x:1177,y:708,t:1527019896806};\\\", \\\"{x:1241,y:725,t:1527019896824};\\\", \\\"{x:1283,y:736,t:1527019896841};\\\", \\\"{x:1304,y:737,t:1527019896856};\\\", \\\"{x:1318,y:737,t:1527019896873};\\\", \\\"{x:1322,y:737,t:1527019896890};\\\", \\\"{x:1322,y:738,t:1527019896946};\\\", \\\"{x:1321,y:739,t:1527019896963};\\\", \\\"{x:1322,y:738,t:1527019897034};\\\", \\\"{x:1325,y:735,t:1527019897042};\\\", \\\"{x:1327,y:731,t:1527019897056};\\\", \\\"{x:1338,y:719,t:1527019897073};\\\", \\\"{x:1361,y:704,t:1527019897090};\\\", \\\"{x:1369,y:699,t:1527019897106};\\\", \\\"{x:1371,y:698,t:1527019897123};\\\", \\\"{x:1373,y:697,t:1527019897699};\\\", \\\"{x:1374,y:696,t:1527019897708};\\\", \\\"{x:1378,y:695,t:1527019897724};\\\", \\\"{x:1380,y:695,t:1527019897741};\\\", \\\"{x:1381,y:694,t:1527019897757};\\\", \\\"{x:1382,y:693,t:1527019897819};\\\", \\\"{x:1384,y:692,t:1527019897826};\\\", \\\"{x:1386,y:692,t:1527019897840};\\\", \\\"{x:1387,y:692,t:1527019897857};\\\", \\\"{x:1388,y:690,t:1527019897874};\\\", \\\"{x:1389,y:690,t:1527019897890};\\\", \\\"{x:1387,y:690,t:1527019898066};\\\", \\\"{x:1385,y:691,t:1527019898082};\\\", \\\"{x:1384,y:691,t:1527019898092};\\\", \\\"{x:1381,y:691,t:1527019898107};\\\", \\\"{x:1380,y:693,t:1527019898125};\\\", \\\"{x:1379,y:694,t:1527019898141};\\\", \\\"{x:1377,y:694,t:1527019898157};\\\", \\\"{x:1375,y:695,t:1527019898174};\\\", \\\"{x:1374,y:695,t:1527019898191};\\\", \\\"{x:1370,y:696,t:1527019898208};\\\", \\\"{x:1368,y:696,t:1527019898266};\\\", \\\"{x:1367,y:696,t:1527019898282};\\\", \\\"{x:1365,y:696,t:1527019898298};\\\", \\\"{x:1363,y:696,t:1527019898307};\\\", \\\"{x:1360,y:696,t:1527019898324};\\\", \\\"{x:1356,y:696,t:1527019898342};\\\", \\\"{x:1354,y:696,t:1527019898357};\\\", \\\"{x:1353,y:696,t:1527019898377};\\\", \\\"{x:1351,y:696,t:1527019898390};\\\", \\\"{x:1349,y:696,t:1527019898407};\\\", \\\"{x:1348,y:696,t:1527019898465};\\\", \\\"{x:1347,y:696,t:1527019898489};\\\", \\\"{x:1346,y:696,t:1527019898497};\\\", \\\"{x:1346,y:697,t:1527019898513};\\\", \\\"{x:1346,y:699,t:1527019898524};\\\", \\\"{x:1346,y:701,t:1527019898541};\\\", \\\"{x:1346,y:702,t:1527019898558};\\\", \\\"{x:1345,y:703,t:1527019898575};\\\", \\\"{x:1345,y:706,t:1527019898591};\\\", \\\"{x:1345,y:713,t:1527019898608};\\\", \\\"{x:1345,y:721,t:1527019898624};\\\", \\\"{x:1345,y:729,t:1527019898641};\\\", \\\"{x:1346,y:739,t:1527019898658};\\\", \\\"{x:1348,y:749,t:1527019898675};\\\", \\\"{x:1350,y:759,t:1527019898691};\\\", \\\"{x:1354,y:771,t:1527019898709};\\\", \\\"{x:1358,y:779,t:1527019898724};\\\", \\\"{x:1360,y:785,t:1527019898741};\\\", \\\"{x:1362,y:794,t:1527019898758};\\\", \\\"{x:1365,y:805,t:1527019898774};\\\", \\\"{x:1370,y:822,t:1527019898791};\\\", \\\"{x:1374,y:833,t:1527019898808};\\\", \\\"{x:1378,y:841,t:1527019898824};\\\", \\\"{x:1380,y:846,t:1527019898841};\\\", \\\"{x:1385,y:852,t:1527019898858};\\\", \\\"{x:1388,y:859,t:1527019898874};\\\", \\\"{x:1393,y:869,t:1527019898891};\\\", \\\"{x:1400,y:877,t:1527019898908};\\\", \\\"{x:1404,y:884,t:1527019898924};\\\", \\\"{x:1408,y:889,t:1527019898941};\\\", \\\"{x:1413,y:896,t:1527019898958};\\\", \\\"{x:1416,y:902,t:1527019898975};\\\", \\\"{x:1421,y:909,t:1527019898991};\\\", \\\"{x:1427,y:916,t:1527019899009};\\\", \\\"{x:1436,y:925,t:1527019899024};\\\", \\\"{x:1443,y:935,t:1527019899042};\\\", \\\"{x:1457,y:947,t:1527019899058};\\\", \\\"{x:1463,y:954,t:1527019899075};\\\", \\\"{x:1469,y:962,t:1527019899092};\\\", \\\"{x:1473,y:965,t:1527019899108};\\\", \\\"{x:1475,y:968,t:1527019899125};\\\", \\\"{x:1476,y:970,t:1527019899141};\\\", \\\"{x:1477,y:973,t:1527019899158};\\\", \\\"{x:1480,y:978,t:1527019899175};\\\", \\\"{x:1485,y:986,t:1527019899191};\\\", \\\"{x:1491,y:992,t:1527019899208};\\\", \\\"{x:1493,y:994,t:1527019899224};\\\", \\\"{x:1495,y:996,t:1527019899241};\\\", \\\"{x:1499,y:1000,t:1527019899258};\\\", \\\"{x:1501,y:1002,t:1527019899275};\\\", \\\"{x:1502,y:1002,t:1527019899291};\\\", \\\"{x:1503,y:1002,t:1527019899465};\\\", \\\"{x:1503,y:1001,t:1527019899505};\\\", \\\"{x:1503,y:1000,t:1527019899530};\\\", \\\"{x:1503,y:997,t:1527019899542};\\\", \\\"{x:1503,y:992,t:1527019899558};\\\", \\\"{x:1503,y:990,t:1527019899575};\\\", \\\"{x:1503,y:988,t:1527019899762};\\\", \\\"{x:1502,y:986,t:1527019899775};\\\", \\\"{x:1501,y:982,t:1527019899792};\\\", \\\"{x:1500,y:981,t:1527019899809};\\\", \\\"{x:1500,y:980,t:1527019899826};\\\", \\\"{x:1498,y:980,t:1527019900098};\\\", \\\"{x:1493,y:976,t:1527019900109};\\\", \\\"{x:1471,y:965,t:1527019900126};\\\", \\\"{x:1418,y:933,t:1527019900143};\\\", \\\"{x:1322,y:871,t:1527019900160};\\\", \\\"{x:1149,y:775,t:1527019900176};\\\", \\\"{x:947,y:674,t:1527019900193};\\\", \\\"{x:717,y:583,t:1527019900211};\\\", \\\"{x:411,y:438,t:1527019900226};\\\", \\\"{x:223,y:354,t:1527019900259};\\\", \\\"{x:192,y:341,t:1527019900274};\\\", \\\"{x:186,y:338,t:1527019900291};\\\", \\\"{x:185,y:338,t:1527019900377};\\\", \\\"{x:185,y:340,t:1527019900391};\\\", \\\"{x:185,y:355,t:1527019900407};\\\", \\\"{x:195,y:376,t:1527019900424};\\\", \\\"{x:221,y:392,t:1527019900442};\\\", \\\"{x:233,y:396,t:1527019900457};\\\", \\\"{x:315,y:419,t:1527019900474};\\\", \\\"{x:416,y:439,t:1527019900491};\\\", \\\"{x:496,y:447,t:1527019900507};\\\", \\\"{x:551,y:454,t:1527019900524};\\\", \\\"{x:584,y:460,t:1527019900541};\\\", \\\"{x:602,y:461,t:1527019900557};\\\", \\\"{x:613,y:463,t:1527019900574};\\\", \\\"{x:619,y:466,t:1527019900591};\\\", \\\"{x:624,y:467,t:1527019900607};\\\", \\\"{x:635,y:470,t:1527019900624};\\\", \\\"{x:660,y:472,t:1527019900642};\\\", \\\"{x:668,y:474,t:1527019900657};\\\", \\\"{x:669,y:475,t:1527019900675};\\\", \\\"{x:671,y:476,t:1527019900698};\\\", \\\"{x:677,y:481,t:1527019900708};\\\", \\\"{x:689,y:496,t:1527019900725};\\\", \\\"{x:696,y:505,t:1527019900741};\\\", \\\"{x:697,y:506,t:1527019900758};\\\", \\\"{x:694,y:506,t:1527019900793};\\\", \\\"{x:683,y:505,t:1527019900808};\\\", \\\"{x:644,y:489,t:1527019900825};\\\", \\\"{x:638,y:489,t:1527019900841};\\\", \\\"{x:637,y:489,t:1527019900858};\\\", \\\"{x:636,y:490,t:1527019900890};\\\", \\\"{x:633,y:492,t:1527019900908};\\\", \\\"{x:627,y:494,t:1527019900926};\\\", \\\"{x:619,y:495,t:1527019900944};\\\", \\\"{x:616,y:496,t:1527019900959};\\\", \\\"{x:615,y:497,t:1527019900976};\\\", \\\"{x:612,y:500,t:1527019901217};\\\", \\\"{x:609,y:512,t:1527019901226};\\\", \\\"{x:599,y:542,t:1527019901244};\\\", \\\"{x:591,y:567,t:1527019901260};\\\", \\\"{x:589,y:573,t:1527019901276};\\\", \\\"{x:589,y:574,t:1527019901297};\\\", \\\"{x:589,y:577,t:1527019901309};\\\", \\\"{x:589,y:590,t:1527019901326};\\\", \\\"{x:589,y:616,t:1527019901343};\\\", \\\"{x:582,y:642,t:1527019901361};\\\", \\\"{x:573,y:672,t:1527019901376};\\\", \\\"{x:559,y:700,t:1527019901393};\\\", \\\"{x:557,y:715,t:1527019901409};\\\", \\\"{x:555,y:728,t:1527019901427};\\\", \\\"{x:553,y:734,t:1527019901443};\\\", \\\"{x:549,y:747,t:1527019901460};\\\", \\\"{x:543,y:772,t:1527019901476};\\\", \\\"{x:538,y:788,t:1527019901493};\\\", \\\"{x:537,y:795,t:1527019901510};\\\", \\\"{x:537,y:796,t:1527019901527};\\\", \\\"{x:536,y:796,t:1527019901619};\\\", \\\"{x:536,y:790,t:1527019901627};\\\", \\\"{x:536,y:763,t:1527019901643};\\\", \\\"{x:536,y:743,t:1527019901661};\\\", \\\"{x:537,y:737,t:1527019901677};\\\", \\\"{x:537,y:734,t:1527019902378};\\\", \\\"{x:537,y:731,t:1527019902393};\\\", \\\"{x:537,y:727,t:1527019902411};\\\", \\\"{x:536,y:720,t:1527019902434};\\\", \\\"{x:532,y:706,t:1527019902474};\\\", \\\"{x:532,y:704,t:1527019902480};\\\", \\\"{x:531,y:702,t:1527019902494};\\\", \\\"{x:531,y:699,t:1527019902511};\\\", \\\"{x:531,y:694,t:1527019902527};\\\", \\\"{x:531,y:691,t:1527019902544};\\\", \\\"{x:530,y:688,t:1527019902560};\\\", \\\"{x:530,y:686,t:1527019902577};\\\", \\\"{x:530,y:684,t:1527019902593};\\\", \\\"{x:529,y:683,t:1527019902611};\\\", \\\"{x:529,y:681,t:1527019902626};\\\", \\\"{x:528,y:679,t:1527019902644};\\\", \\\"{x:528,y:678,t:1527019902661};\\\", \\\"{x:528,y:677,t:1527019902677};\\\", \\\"{x:528,y:676,t:1527019902694};\\\", \\\"{x:528,y:675,t:1527019902711};\\\", \\\"{x:528,y:674,t:1527019902730};\\\", \\\"{x:527,y:674,t:1527019902744};\\\", \\\"{x:527,y:672,t:1527019902761};\\\", \\\"{x:527,y:671,t:1527019902801};\\\", \\\"{x:527,y:670,t:1527019902818};\\\", \\\"{x:527,y:669,t:1527019902827};\\\", \\\"{x:527,y:666,t:1527019902922};\\\", \\\"{x:527,y:665,t:1527019902928};\\\", \\\"{x:526,y:663,t:1527019902945};\\\", \\\"{x:526,y:662,t:1527019902985};\\\", \\\"{x:526,y:661,t:1527019903000};\\\", \\\"{x:526,y:660,t:1527019903010};\\\" ] }, { \\\"rt\\\": 12190, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 15, \\\"time_elapsed\\\": 522369, \\\"internal_node_id\\\": \\\"0.0-6.0-5.0\\\", \\\"subject\\\": \\\"VT5BG\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"golf\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 11, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"M\\\", \\\"L\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-12 PM-M -12 PM-O -O \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:524,y:654,t:1527019903164};\\\", \\\"{x:524,y:653,t:1527019903273};\\\", \\\"{x:523,y:653,t:1527019903337};\\\", \\\"{x:523,y:652,t:1527019903344};\\\", \\\"{x:522,y:651,t:1527019903628};\\\", \\\"{x:522,y:650,t:1527019903924};\\\", \\\"{x:522,y:648,t:1527019904202};\\\", \\\"{x:522,y:640,t:1527019904213};\\\", \\\"{x:523,y:630,t:1527019904230};\\\", \\\"{x:524,y:625,t:1527019904246};\\\", \\\"{x:526,y:621,t:1527019904262};\\\", \\\"{x:526,y:619,t:1527019904279};\\\", \\\"{x:527,y:618,t:1527019904897};\\\", \\\"{x:561,y:618,t:1527019904913};\\\", \\\"{x:705,y:642,t:1527019904930};\\\", \\\"{x:933,y:727,t:1527019904946};\\\", \\\"{x:1217,y:810,t:1527019904962};\\\", \\\"{x:1475,y:872,t:1527019904979};\\\", \\\"{x:1677,y:904,t:1527019904996};\\\", \\\"{x:1772,y:916,t:1527019905013};\\\", \\\"{x:1783,y:918,t:1527019905029};\\\", \\\"{x:1781,y:918,t:1527019905046};\\\", \\\"{x:1755,y:915,t:1527019905063};\\\", \\\"{x:1710,y:915,t:1527019905079};\\\", \\\"{x:1668,y:915,t:1527019905096};\\\", \\\"{x:1618,y:913,t:1527019905114};\\\", \\\"{x:1554,y:903,t:1527019905129};\\\", \\\"{x:1461,y:883,t:1527019905146};\\\", \\\"{x:1380,y:871,t:1527019905163};\\\", \\\"{x:1303,y:862,t:1527019905180};\\\", \\\"{x:1244,y:853,t:1527019905196};\\\", \\\"{x:1195,y:850,t:1527019905213};\\\", \\\"{x:1171,y:850,t:1527019905229};\\\", \\\"{x:1167,y:850,t:1527019905247};\\\", \\\"{x:1166,y:850,t:1527019905324};\\\", \\\"{x:1165,y:852,t:1527019905330};\\\", \\\"{x:1165,y:859,t:1527019905347};\\\", \\\"{x:1165,y:863,t:1527019905364};\\\", \\\"{x:1166,y:865,t:1527019905380};\\\", \\\"{x:1176,y:870,t:1527019905397};\\\", \\\"{x:1194,y:878,t:1527019905414};\\\", \\\"{x:1219,y:879,t:1527019905430};\\\", \\\"{x:1251,y:881,t:1527019905447};\\\", \\\"{x:1276,y:881,t:1527019905464};\\\", \\\"{x:1292,y:881,t:1527019905480};\\\", \\\"{x:1294,y:881,t:1527019905497};\\\", \\\"{x:1293,y:881,t:1527019905579};\\\", \\\"{x:1289,y:880,t:1527019905586};\\\", \\\"{x:1283,y:877,t:1527019905597};\\\", \\\"{x:1258,y:874,t:1527019905613};\\\", \\\"{x:1216,y:868,t:1527019905631};\\\", \\\"{x:1155,y:859,t:1527019905646};\\\", \\\"{x:1070,y:843,t:1527019905663};\\\", \\\"{x:959,y:810,t:1527019905681};\\\", \\\"{x:835,y:759,t:1527019905697};\\\", \\\"{x:657,y:673,t:1527019905714};\\\", \\\"{x:605,y:656,t:1527019905729};\\\", \\\"{x:583,y:650,t:1527019905747};\\\", \\\"{x:572,y:646,t:1527019905763};\\\", \\\"{x:571,y:645,t:1527019905781};\\\", \\\"{x:569,y:645,t:1527019905834};\\\", \\\"{x:568,y:645,t:1527019905846};\\\", \\\"{x:556,y:637,t:1527019905864};\\\", \\\"{x:538,y:623,t:1527019905881};\\\", \\\"{x:526,y:615,t:1527019905897};\\\", \\\"{x:523,y:612,t:1527019905913};\\\", \\\"{x:520,y:609,t:1527019905929};\\\", \\\"{x:519,y:607,t:1527019905947};\\\", \\\"{x:517,y:604,t:1527019905963};\\\", \\\"{x:516,y:601,t:1527019905980};\\\", \\\"{x:515,y:599,t:1527019905998};\\\", \\\"{x:515,y:598,t:1527019906017};\\\", \\\"{x:515,y:597,t:1527019906090};\\\", \\\"{x:515,y:596,t:1527019906098};\\\", \\\"{x:514,y:596,t:1527019906129};\\\", \\\"{x:513,y:596,t:1527019906322};\\\", \\\"{x:509,y:596,t:1527019906330};\\\", \\\"{x:498,y:602,t:1527019906349};\\\", \\\"{x:491,y:606,t:1527019906363};\\\", \\\"{x:483,y:612,t:1527019906380};\\\", \\\"{x:472,y:616,t:1527019906397};\\\", \\\"{x:463,y:621,t:1527019906413};\\\", \\\"{x:452,y:626,t:1527019906430};\\\", \\\"{x:448,y:627,t:1527019906447};\\\", \\\"{x:447,y:627,t:1527019906464};\\\", \\\"{x:446,y:626,t:1527019906481};\\\", \\\"{x:447,y:612,t:1527019906497};\\\", \\\"{x:447,y:594,t:1527019906515};\\\", \\\"{x:447,y:577,t:1527019906532};\\\", \\\"{x:447,y:571,t:1527019906547};\\\", \\\"{x:446,y:569,t:1527019906563};\\\", \\\"{x:442,y:567,t:1527019906580};\\\", \\\"{x:437,y:566,t:1527019906597};\\\", \\\"{x:431,y:564,t:1527019906614};\\\", \\\"{x:426,y:563,t:1527019906630};\\\", \\\"{x:424,y:562,t:1527019906647};\\\", \\\"{x:422,y:559,t:1527019906664};\\\", \\\"{x:421,y:559,t:1527019906680};\\\", \\\"{x:420,y:559,t:1527019906697};\\\", \\\"{x:416,y:559,t:1527019906714};\\\", \\\"{x:409,y:559,t:1527019906731};\\\", \\\"{x:402,y:557,t:1527019906747};\\\", \\\"{x:399,y:556,t:1527019906764};\\\", \\\"{x:398,y:556,t:1527019906793};\\\", \\\"{x:398,y:554,t:1527019906803};\\\", \\\"{x:396,y:552,t:1527019906814};\\\", \\\"{x:394,y:547,t:1527019906831};\\\", \\\"{x:393,y:545,t:1527019906847};\\\", \\\"{x:393,y:543,t:1527019906864};\\\", \\\"{x:407,y:543,t:1527019907274};\\\", \\\"{x:445,y:554,t:1527019907282};\\\", \\\"{x:553,y:583,t:1527019907299};\\\", \\\"{x:668,y:606,t:1527019907314};\\\", \\\"{x:788,y:633,t:1527019907332};\\\", \\\"{x:936,y:686,t:1527019907348};\\\", \\\"{x:1094,y:760,t:1527019907364};\\\", \\\"{x:1234,y:821,t:1527019907382};\\\", \\\"{x:1343,y:882,t:1527019907399};\\\", \\\"{x:1394,y:915,t:1527019907414};\\\", \\\"{x:1407,y:931,t:1527019907431};\\\", \\\"{x:1407,y:939,t:1527019907449};\\\", \\\"{x:1405,y:948,t:1527019907465};\\\", \\\"{x:1391,y:961,t:1527019907482};\\\", \\\"{x:1387,y:968,t:1527019907499};\\\", \\\"{x:1387,y:984,t:1527019907515};\\\", \\\"{x:1390,y:1005,t:1527019907532};\\\", \\\"{x:1396,y:1017,t:1527019907548};\\\", \\\"{x:1396,y:1018,t:1527019907565};\\\", \\\"{x:1396,y:1016,t:1527019907618};\\\", \\\"{x:1392,y:1010,t:1527019907632};\\\", \\\"{x:1389,y:1006,t:1527019907649};\\\", \\\"{x:1382,y:997,t:1527019907666};\\\", \\\"{x:1366,y:986,t:1527019907681};\\\", \\\"{x:1351,y:981,t:1527019907700};\\\", \\\"{x:1349,y:981,t:1527019907716};\\\", \\\"{x:1347,y:981,t:1527019907732};\\\", \\\"{x:1346,y:981,t:1527019907834};\\\", \\\"{x:1344,y:981,t:1527019907849};\\\", \\\"{x:1340,y:977,t:1527019907866};\\\", \\\"{x:1340,y:974,t:1527019907881};\\\", \\\"{x:1340,y:972,t:1527019907899};\\\", \\\"{x:1340,y:971,t:1527019907916};\\\", \\\"{x:1340,y:969,t:1527019907932};\\\", \\\"{x:1341,y:968,t:1527019907963};\\\", \\\"{x:1341,y:966,t:1527019907994};\\\", \\\"{x:1343,y:962,t:1527019908002};\\\", \\\"{x:1345,y:960,t:1527019908016};\\\", \\\"{x:1349,y:952,t:1527019908032};\\\", \\\"{x:1352,y:948,t:1527019908049};\\\", \\\"{x:1356,y:943,t:1527019908066};\\\", \\\"{x:1357,y:941,t:1527019908082};\\\", \\\"{x:1361,y:936,t:1527019908099};\\\", \\\"{x:1365,y:932,t:1527019908115};\\\", \\\"{x:1371,y:925,t:1527019908133};\\\", \\\"{x:1373,y:921,t:1527019908149};\\\", \\\"{x:1377,y:914,t:1527019908166};\\\", \\\"{x:1380,y:909,t:1527019908183};\\\", \\\"{x:1382,y:903,t:1527019908199};\\\", \\\"{x:1385,y:898,t:1527019908216};\\\", \\\"{x:1388,y:894,t:1527019908232};\\\", \\\"{x:1390,y:890,t:1527019908249};\\\", \\\"{x:1392,y:886,t:1527019908265};\\\", \\\"{x:1392,y:884,t:1527019908282};\\\", \\\"{x:1393,y:882,t:1527019908298};\\\", \\\"{x:1393,y:880,t:1527019908321};\\\", \\\"{x:1395,y:878,t:1527019908332};\\\", \\\"{x:1395,y:877,t:1527019908349};\\\", \\\"{x:1396,y:873,t:1527019908366};\\\", \\\"{x:1397,y:871,t:1527019908382};\\\", \\\"{x:1397,y:869,t:1527019908399};\\\", \\\"{x:1397,y:868,t:1527019908416};\\\", \\\"{x:1398,y:867,t:1527019908433};\\\", \\\"{x:1399,y:865,t:1527019908449};\\\", \\\"{x:1399,y:860,t:1527019908466};\\\", \\\"{x:1401,y:856,t:1527019908482};\\\", \\\"{x:1402,y:853,t:1527019908499};\\\", \\\"{x:1403,y:851,t:1527019908516};\\\", \\\"{x:1406,y:844,t:1527019908533};\\\", \\\"{x:1407,y:840,t:1527019908549};\\\", \\\"{x:1409,y:835,t:1527019908566};\\\", \\\"{x:1411,y:832,t:1527019908583};\\\", \\\"{x:1414,y:825,t:1527019908598};\\\", \\\"{x:1417,y:818,t:1527019908615};\\\", \\\"{x:1419,y:813,t:1527019908632};\\\", \\\"{x:1422,y:808,t:1527019908648};\\\", \\\"{x:1423,y:801,t:1527019908666};\\\", \\\"{x:1425,y:797,t:1527019908683};\\\", \\\"{x:1428,y:792,t:1527019908700};\\\", \\\"{x:1430,y:789,t:1527019908716};\\\", \\\"{x:1431,y:785,t:1527019908733};\\\", \\\"{x:1434,y:779,t:1527019908750};\\\", \\\"{x:1437,y:774,t:1527019908766};\\\", \\\"{x:1438,y:769,t:1527019908783};\\\", \\\"{x:1442,y:763,t:1527019908800};\\\", \\\"{x:1444,y:758,t:1527019908816};\\\", \\\"{x:1446,y:754,t:1527019908833};\\\", \\\"{x:1450,y:743,t:1527019908850};\\\", \\\"{x:1453,y:735,t:1527019908866};\\\", \\\"{x:1457,y:727,t:1527019908883};\\\", \\\"{x:1459,y:721,t:1527019908900};\\\", \\\"{x:1462,y:717,t:1527019908916};\\\", \\\"{x:1464,y:713,t:1527019908933};\\\", \\\"{x:1467,y:708,t:1527019908949};\\\", \\\"{x:1468,y:704,t:1527019908966};\\\", \\\"{x:1470,y:700,t:1527019908983};\\\", \\\"{x:1471,y:698,t:1527019909000};\\\", \\\"{x:1471,y:695,t:1527019909016};\\\", \\\"{x:1471,y:694,t:1527019909033};\\\", \\\"{x:1471,y:692,t:1527019909050};\\\", \\\"{x:1471,y:689,t:1527019909066};\\\", \\\"{x:1473,y:687,t:1527019909083};\\\", \\\"{x:1473,y:685,t:1527019909100};\\\", \\\"{x:1473,y:682,t:1527019909116};\\\", \\\"{x:1474,y:681,t:1527019909132};\\\", \\\"{x:1476,y:678,t:1527019909149};\\\", \\\"{x:1473,y:676,t:1527019909225};\\\", \\\"{x:1469,y:674,t:1527019909233};\\\", \\\"{x:1451,y:672,t:1527019909249};\\\", \\\"{x:1422,y:672,t:1527019909266};\\\", \\\"{x:1376,y:672,t:1527019909283};\\\", \\\"{x:1326,y:672,t:1527019909299};\\\", \\\"{x:1273,y:672,t:1527019909316};\\\", \\\"{x:1195,y:672,t:1527019909333};\\\", \\\"{x:1081,y:672,t:1527019909349};\\\", \\\"{x:948,y:653,t:1527019909366};\\\", \\\"{x:853,y:634,t:1527019909382};\\\", \\\"{x:791,y:615,t:1527019909402};\\\", \\\"{x:741,y:601,t:1527019909416};\\\", \\\"{x:695,y:586,t:1527019909433};\\\", \\\"{x:639,y:569,t:1527019909450};\\\", \\\"{x:616,y:565,t:1527019909466};\\\", \\\"{x:594,y:561,t:1527019909483};\\\", \\\"{x:566,y:557,t:1527019909499};\\\", \\\"{x:536,y:551,t:1527019909516};\\\", \\\"{x:523,y:542,t:1527019909533};\\\", \\\"{x:516,y:536,t:1527019909549};\\\", \\\"{x:513,y:532,t:1527019909566};\\\", \\\"{x:513,y:528,t:1527019909583};\\\", \\\"{x:512,y:525,t:1527019909600};\\\", \\\"{x:512,y:524,t:1527019909617};\\\", \\\"{x:512,y:523,t:1527019909634};\\\", \\\"{x:510,y:522,t:1527019909681};\\\", \\\"{x:504,y:522,t:1527019909689};\\\", \\\"{x:495,y:522,t:1527019909700};\\\", \\\"{x:468,y:530,t:1527019909718};\\\", \\\"{x:441,y:535,t:1527019909733};\\\", \\\"{x:414,y:541,t:1527019909750};\\\", \\\"{x:394,y:544,t:1527019909766};\\\", \\\"{x:379,y:546,t:1527019909783};\\\", \\\"{x:369,y:550,t:1527019909801};\\\", \\\"{x:361,y:553,t:1527019909816};\\\", \\\"{x:359,y:555,t:1527019909833};\\\", \\\"{x:363,y:557,t:1527019909859};\\\", \\\"{x:373,y:557,t:1527019909867};\\\", \\\"{x:407,y:557,t:1527019909883};\\\", \\\"{x:459,y:545,t:1527019909901};\\\", \\\"{x:523,y:528,t:1527019909917};\\\", \\\"{x:590,y:505,t:1527019909934};\\\", \\\"{x:644,y:487,t:1527019909950};\\\", \\\"{x:671,y:476,t:1527019909967};\\\", \\\"{x:686,y:470,t:1527019909983};\\\", \\\"{x:700,y:464,t:1527019910000};\\\", \\\"{x:709,y:461,t:1527019910016};\\\", \\\"{x:717,y:457,t:1527019910033};\\\", \\\"{x:720,y:456,t:1527019910050};\\\", \\\"{x:722,y:456,t:1527019910068};\\\", \\\"{x:723,y:458,t:1527019910105};\\\", \\\"{x:723,y:470,t:1527019910118};\\\", \\\"{x:723,y:503,t:1527019910135};\\\", \\\"{x:744,y:546,t:1527019910151};\\\", \\\"{x:771,y:578,t:1527019910167};\\\", \\\"{x:788,y:599,t:1527019910184};\\\", \\\"{x:792,y:606,t:1527019910201};\\\", \\\"{x:782,y:626,t:1527019910217};\\\", \\\"{x:754,y:639,t:1527019910233};\\\", \\\"{x:718,y:656,t:1527019910250};\\\", \\\"{x:693,y:663,t:1527019910266};\\\", \\\"{x:680,y:663,t:1527019910283};\\\", \\\"{x:670,y:663,t:1527019910300};\\\", \\\"{x:660,y:661,t:1527019910317};\\\", \\\"{x:650,y:657,t:1527019910333};\\\", \\\"{x:638,y:653,t:1527019910350};\\\", \\\"{x:628,y:650,t:1527019910366};\\\", \\\"{x:626,y:650,t:1527019910383};\\\", \\\"{x:627,y:648,t:1527019910417};\\\", \\\"{x:634,y:643,t:1527019910432};\\\", \\\"{x:639,y:630,t:1527019910450};\\\", \\\"{x:639,y:625,t:1527019910467};\\\", \\\"{x:635,y:620,t:1527019910484};\\\", \\\"{x:615,y:616,t:1527019910500};\\\", \\\"{x:578,y:616,t:1527019910518};\\\", \\\"{x:537,y:621,t:1527019910534};\\\", \\\"{x:489,y:634,t:1527019910551};\\\", \\\"{x:429,y:646,t:1527019910569};\\\", \\\"{x:374,y:654,t:1527019910584};\\\", \\\"{x:339,y:654,t:1527019910601};\\\", \\\"{x:328,y:648,t:1527019910617};\\\", \\\"{x:328,y:644,t:1527019910634};\\\", \\\"{x:328,y:639,t:1527019910651};\\\", \\\"{x:329,y:633,t:1527019910669};\\\", \\\"{x:329,y:629,t:1527019910685};\\\", \\\"{x:332,y:624,t:1527019910700};\\\", \\\"{x:341,y:615,t:1527019910717};\\\", \\\"{x:355,y:605,t:1527019910734};\\\", \\\"{x:370,y:591,t:1527019910751};\\\", \\\"{x:381,y:583,t:1527019910768};\\\", \\\"{x:385,y:580,t:1527019910785};\\\", \\\"{x:386,y:580,t:1527019910801};\\\", \\\"{x:387,y:580,t:1527019910833};\\\", \\\"{x:389,y:580,t:1527019910841};\\\", \\\"{x:390,y:580,t:1527019910857};\\\", \\\"{x:393,y:580,t:1527019910868};\\\", \\\"{x:394,y:584,t:1527019910884};\\\", \\\"{x:395,y:586,t:1527019910900};\\\", \\\"{x:395,y:588,t:1527019910970};\\\", \\\"{x:395,y:592,t:1527019910985};\\\", \\\"{x:386,y:606,t:1527019911002};\\\", \\\"{x:384,y:610,t:1527019911018};\\\", \\\"{x:383,y:611,t:1527019911034};\\\", \\\"{x:382,y:611,t:1527019911129};\\\", \\\"{x:381,y:611,t:1527019911137};\\\", \\\"{x:380,y:611,t:1527019911177};\\\", \\\"{x:396,y:615,t:1527019911787};\\\", \\\"{x:513,y:648,t:1527019911803};\\\", \\\"{x:674,y:709,t:1527019911819};\\\", \\\"{x:895,y:818,t:1527019911834};\\\", \\\"{x:1127,y:928,t:1527019911851};\\\", \\\"{x:1350,y:1020,t:1527019911868};\\\", \\\"{x:1518,y:1091,t:1527019911885};\\\", \\\"{x:1619,y:1137,t:1527019911906};\\\", \\\"{x:1593,y:1142,t:1527019911951};\\\", \\\"{x:1548,y:1142,t:1527019911969};\\\", \\\"{x:1519,y:1142,t:1527019911984};\\\", \\\"{x:1498,y:1145,t:1527019912001};\\\", \\\"{x:1492,y:1146,t:1527019912018};\\\", \\\"{x:1490,y:1146,t:1527019912035};\\\", \\\"{x:1487,y:1144,t:1527019912051};\\\", \\\"{x:1483,y:1137,t:1527019912068};\\\", \\\"{x:1477,y:1117,t:1527019912085};\\\", \\\"{x:1458,y:1068,t:1527019912101};\\\", \\\"{x:1426,y:994,t:1527019912118};\\\", \\\"{x:1388,y:931,t:1527019912136};\\\", \\\"{x:1362,y:896,t:1527019912151};\\\", \\\"{x:1359,y:892,t:1527019912169};\\\", \\\"{x:1358,y:893,t:1527019912201};\\\", \\\"{x:1356,y:901,t:1527019912219};\\\", \\\"{x:1345,y:923,t:1527019912236};\\\", \\\"{x:1342,y:946,t:1527019912251};\\\", \\\"{x:1340,y:961,t:1527019912268};\\\", \\\"{x:1340,y:967,t:1527019912286};\\\", \\\"{x:1340,y:969,t:1527019912302};\\\", \\\"{x:1340,y:968,t:1527019912539};\\\", \\\"{x:1345,y:964,t:1527019912552};\\\", \\\"{x:1369,y:946,t:1527019912569};\\\", \\\"{x:1414,y:909,t:1527019912586};\\\", \\\"{x:1439,y:886,t:1527019912603};\\\", \\\"{x:1456,y:871,t:1527019912619};\\\", \\\"{x:1468,y:862,t:1527019912636};\\\", \\\"{x:1473,y:855,t:1527019912653};\\\", \\\"{x:1477,y:848,t:1527019912669};\\\", \\\"{x:1480,y:842,t:1527019912686};\\\", \\\"{x:1483,y:837,t:1527019912703};\\\", \\\"{x:1487,y:832,t:1527019912719};\\\", \\\"{x:1489,y:828,t:1527019912736};\\\", \\\"{x:1492,y:823,t:1527019912753};\\\", \\\"{x:1494,y:818,t:1527019912769};\\\", \\\"{x:1500,y:805,t:1527019912785};\\\", \\\"{x:1503,y:794,t:1527019912803};\\\", \\\"{x:1507,y:784,t:1527019912819};\\\", \\\"{x:1511,y:773,t:1527019912836};\\\", \\\"{x:1515,y:760,t:1527019912853};\\\", \\\"{x:1518,y:747,t:1527019912869};\\\", \\\"{x:1522,y:730,t:1527019912886};\\\", \\\"{x:1528,y:716,t:1527019912902};\\\", \\\"{x:1532,y:701,t:1527019912918};\\\", \\\"{x:1536,y:683,t:1527019912935};\\\", \\\"{x:1543,y:661,t:1527019912952};\\\", \\\"{x:1564,y:618,t:1527019912968};\\\", \\\"{x:1573,y:594,t:1527019912986};\\\", \\\"{x:1580,y:586,t:1527019913002};\\\", \\\"{x:1581,y:585,t:1527019913020};\\\", \\\"{x:1582,y:584,t:1527019913036};\\\", \\\"{x:1582,y:588,t:1527019913266};\\\", \\\"{x:1582,y:591,t:1527019913273};\\\", \\\"{x:1581,y:591,t:1527019913290};\\\", \\\"{x:1581,y:592,t:1527019913394};\\\", \\\"{x:1579,y:596,t:1527019913403};\\\", \\\"{x:1577,y:601,t:1527019913420};\\\", \\\"{x:1572,y:608,t:1527019913436};\\\", \\\"{x:1570,y:612,t:1527019913453};\\\", \\\"{x:1568,y:614,t:1527019913470};\\\", \\\"{x:1567,y:615,t:1527019913486};\\\", \\\"{x:1567,y:617,t:1527019913554};\\\", \\\"{x:1564,y:624,t:1527019913570};\\\", \\\"{x:1556,y:631,t:1527019913588};\\\", \\\"{x:1548,y:637,t:1527019913603};\\\", \\\"{x:1542,y:642,t:1527019913620};\\\", \\\"{x:1535,y:648,t:1527019913637};\\\", \\\"{x:1530,y:656,t:1527019913653};\\\", \\\"{x:1523,y:666,t:1527019913670};\\\", \\\"{x:1513,y:677,t:1527019913687};\\\", \\\"{x:1504,y:687,t:1527019913703};\\\", \\\"{x:1492,y:701,t:1527019913720};\\\", \\\"{x:1478,y:720,t:1527019913737};\\\", \\\"{x:1467,y:739,t:1527019913753};\\\", \\\"{x:1450,y:766,t:1527019913770};\\\", \\\"{x:1436,y:787,t:1527019913787};\\\", \\\"{x:1409,y:817,t:1527019913804};\\\", \\\"{x:1383,y:858,t:1527019913820};\\\", \\\"{x:1365,y:893,t:1527019913838};\\\", \\\"{x:1354,y:913,t:1527019913853};\\\", \\\"{x:1345,y:925,t:1527019913870};\\\", \\\"{x:1339,y:936,t:1527019913887};\\\", \\\"{x:1326,y:951,t:1527019913903};\\\", \\\"{x:1311,y:972,t:1527019913919};\\\", \\\"{x:1300,y:991,t:1527019913936};\\\", \\\"{x:1291,y:1006,t:1527019913953};\\\", \\\"{x:1289,y:1010,t:1527019913970};\\\", \\\"{x:1288,y:1011,t:1527019913986};\\\", \\\"{x:1287,y:1013,t:1527019914004};\\\", \\\"{x:1287,y:1015,t:1527019914019};\\\", \\\"{x:1287,y:1016,t:1527019914036};\\\", \\\"{x:1286,y:1017,t:1527019914146};\\\", \\\"{x:1280,y:1017,t:1527019914153};\\\", \\\"{x:1255,y:1013,t:1527019914170};\\\", \\\"{x:1224,y:1010,t:1527019914187};\\\", \\\"{x:1191,y:1002,t:1527019914204};\\\", \\\"{x:1146,y:989,t:1527019914220};\\\", \\\"{x:1081,y:966,t:1527019914238};\\\", \\\"{x:1010,y:943,t:1527019914255};\\\", \\\"{x:950,y:919,t:1527019914270};\\\", \\\"{x:895,y:884,t:1527019914287};\\\", \\\"{x:852,y:839,t:1527019914304};\\\", \\\"{x:789,y:774,t:1527019914320};\\\", \\\"{x:717,y:712,t:1527019914336};\\\", \\\"{x:645,y:675,t:1527019914353};\\\", \\\"{x:631,y:674,t:1527019914370};\\\", \\\"{x:615,y:676,t:1527019914387};\\\", \\\"{x:590,y:689,t:1527019914405};\\\", \\\"{x:564,y:703,t:1527019914421};\\\", \\\"{x:554,y:707,t:1527019914437};\\\", \\\"{x:552,y:709,t:1527019914454};\\\", \\\"{x:550,y:710,t:1527019914471};\\\", \\\"{x:546,y:714,t:1527019914486};\\\", \\\"{x:536,y:715,t:1527019914504};\\\", \\\"{x:527,y:718,t:1527019914521};\\\", \\\"{x:523,y:725,t:1527019914541};\\\", \\\"{x:521,y:734,t:1527019914553};\\\", \\\"{x:520,y:738,t:1527019914570};\\\", \\\"{x:520,y:750,t:1527019914587};\\\", \\\"{x:520,y:764,t:1527019914604};\\\", \\\"{x:520,y:773,t:1527019914621};\\\", \\\"{x:523,y:777,t:1527019914637};\\\", \\\"{x:523,y:779,t:1527019914681};\\\", \\\"{x:524,y:779,t:1527019914688};\\\", \\\"{x:524,y:777,t:1527019914785};\\\", \\\"{x:525,y:774,t:1527019914794};\\\", \\\"{x:525,y:771,t:1527019914803};\\\", \\\"{x:525,y:767,t:1527019914821};\\\", \\\"{x:525,y:765,t:1527019914838};\\\", \\\"{x:525,y:764,t:1527019914858};\\\", \\\"{x:525,y:763,t:1527019914874};\\\", \\\"{x:525,y:762,t:1527019914888};\\\", \\\"{x:525,y:761,t:1527019914903};\\\", \\\"{x:525,y:759,t:1527019914921};\\\", \\\"{x:525,y:758,t:1527019914937};\\\", \\\"{x:525,y:757,t:1527019915001};\\\", \\\"{x:525,y:756,t:1527019915009};\\\", \\\"{x:525,y:754,t:1527019915021};\\\", \\\"{x:525,y:751,t:1527019915090};\\\", \\\"{x:525,y:750,t:1527019915105};\\\", \\\"{x:525,y:749,t:1527019915120};\\\", \\\"{x:525,y:748,t:1527019915137};\\\", \\\"{x:525,y:744,t:1527019916106};\\\", \\\"{x:525,y:741,t:1527019916121};\\\", \\\"{x:525,y:740,t:1527019916139};\\\", \\\"{x:525,y:738,t:1527019916155};\\\", \\\"{x:525,y:737,t:1527019916177};\\\", \\\"{x:525,y:736,t:1527019916201};\\\", \\\"{x:525,y:735,t:1527019916218};\\\", \\\"{x:525,y:734,t:1527019916266};\\\", \\\"{x:526,y:734,t:1527019916273};\\\", \\\"{x:526,y:733,t:1527019916290};\\\", \\\"{x:526,y:732,t:1527019916330};\\\", \\\"{x:526,y:731,t:1527019916346};\\\", \\\"{x:526,y:730,t:1527019916361};\\\", \\\"{x:526,y:729,t:1527019916421};\\\", \\\"{x:526,y:728,t:1527019916481};\\\" ] }, { \\\"rt\\\": 9882, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 16, \\\"time_elapsed\\\": 533575, \\\"internal_node_id\\\": \\\"0.0-6.0-6.0\\\", \\\"subject\\\": \\\"VT5BG\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"golf\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 12, \\\"clicks\\\": 1.5, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:526,y:724,t:1527019916675};\\\", \\\"{x:527,y:723,t:1527019917506};\\\", \\\"{x:527,y:720,t:1527019917738};\\\", \\\"{x:528,y:716,t:1527019917747};\\\", \\\"{x:529,y:715,t:1527019917756};\\\", \\\"{x:530,y:713,t:1527019917772};\\\", \\\"{x:530,y:712,t:1527019917789};\\\", \\\"{x:531,y:711,t:1527019917807};\\\", \\\"{x:531,y:710,t:1527019917824};\\\", \\\"{x:531,y:709,t:1527019917839};\\\", \\\"{x:532,y:708,t:1527019917857};\\\", \\\"{x:533,y:707,t:1527019917872};\\\", \\\"{x:534,y:706,t:1527019917889};\\\", \\\"{x:534,y:704,t:1527019917907};\\\", \\\"{x:536,y:703,t:1527019917924};\\\", \\\"{x:536,y:701,t:1527019917940};\\\", \\\"{x:539,y:697,t:1527019917957};\\\", \\\"{x:543,y:692,t:1527019917974};\\\", \\\"{x:549,y:685,t:1527019917990};\\\", \\\"{x:559,y:676,t:1527019918007};\\\", \\\"{x:576,y:666,t:1527019918023};\\\", \\\"{x:604,y:654,t:1527019918039};\\\", \\\"{x:665,y:630,t:1527019918058};\\\", \\\"{x:716,y:614,t:1527019918073};\\\", \\\"{x:764,y:598,t:1527019918090};\\\", \\\"{x:809,y:591,t:1527019918107};\\\", \\\"{x:855,y:588,t:1527019918124};\\\", \\\"{x:911,y:595,t:1527019918140};\\\", \\\"{x:976,y:616,t:1527019918156};\\\", \\\"{x:1033,y:640,t:1527019918174};\\\", \\\"{x:1072,y:657,t:1527019918190};\\\", \\\"{x:1089,y:668,t:1527019918206};\\\", \\\"{x:1111,y:675,t:1527019918223};\\\", \\\"{x:1124,y:680,t:1527019918241};\\\", \\\"{x:1125,y:680,t:1527019918257};\\\", \\\"{x:1129,y:683,t:1527019918274};\\\", \\\"{x:1136,y:690,t:1527019918291};\\\", \\\"{x:1147,y:699,t:1527019918306};\\\", \\\"{x:1168,y:710,t:1527019918324};\\\", \\\"{x:1191,y:718,t:1527019918341};\\\", \\\"{x:1213,y:727,t:1527019918358};\\\", \\\"{x:1247,y:747,t:1527019918374};\\\", \\\"{x:1283,y:770,t:1527019918391};\\\", \\\"{x:1310,y:790,t:1527019918409};\\\", \\\"{x:1324,y:802,t:1527019918424};\\\", \\\"{x:1329,y:806,t:1527019918441};\\\", \\\"{x:1329,y:810,t:1527019918458};\\\", \\\"{x:1329,y:816,t:1527019918475};\\\", \\\"{x:1329,y:827,t:1527019918491};\\\", \\\"{x:1329,y:831,t:1527019918508};\\\", \\\"{x:1331,y:817,t:1527019918578};\\\", \\\"{x:1334,y:793,t:1527019918592};\\\", \\\"{x:1344,y:731,t:1527019918608};\\\", \\\"{x:1356,y:684,t:1527019918625};\\\", \\\"{x:1369,y:660,t:1527019918642};\\\", \\\"{x:1371,y:658,t:1527019918660};\\\", \\\"{x:1371,y:655,t:1527019918675};\\\", \\\"{x:1372,y:655,t:1527019918802};\\\", \\\"{x:1371,y:658,t:1527019918809};\\\", \\\"{x:1357,y:679,t:1527019918826};\\\", \\\"{x:1340,y:699,t:1527019918843};\\\", \\\"{x:1327,y:708,t:1527019918859};\\\", \\\"{x:1327,y:709,t:1527019918877};\\\", \\\"{x:1326,y:710,t:1527019918893};\\\", \\\"{x:1326,y:709,t:1527019920866};\\\", \\\"{x:1328,y:704,t:1527019920884};\\\", \\\"{x:1331,y:700,t:1527019920899};\\\", \\\"{x:1334,y:696,t:1527019920917};\\\", \\\"{x:1335,y:694,t:1527019920934};\\\", \\\"{x:1336,y:694,t:1527019920950};\\\", \\\"{x:1335,y:692,t:1527019923586};\\\", \\\"{x:1324,y:692,t:1527019923593};\\\", \\\"{x:1311,y:692,t:1527019923608};\\\", \\\"{x:1221,y:692,t:1527019923625};\\\", \\\"{x:1138,y:692,t:1527019923641};\\\", \\\"{x:1051,y:689,t:1527019923659};\\\", \\\"{x:962,y:677,t:1527019923675};\\\", \\\"{x:884,y:666,t:1527019923692};\\\", \\\"{x:823,y:649,t:1527019923708};\\\", \\\"{x:765,y:633,t:1527019923726};\\\", \\\"{x:717,y:619,t:1527019923743};\\\", \\\"{x:689,y:611,t:1527019923759};\\\", \\\"{x:679,y:607,t:1527019923775};\\\", \\\"{x:672,y:606,t:1527019923795};\\\", \\\"{x:666,y:604,t:1527019923810};\\\", \\\"{x:651,y:602,t:1527019923828};\\\", \\\"{x:624,y:598,t:1527019923844};\\\", \\\"{x:588,y:586,t:1527019923861};\\\", \\\"{x:552,y:575,t:1527019923878};\\\", \\\"{x:510,y:563,t:1527019923893};\\\", \\\"{x:471,y:554,t:1527019923912};\\\", \\\"{x:443,y:546,t:1527019923928};\\\", \\\"{x:410,y:537,t:1527019923945};\\\", \\\"{x:353,y:530,t:1527019923961};\\\", \\\"{x:325,y:530,t:1527019923977};\\\", \\\"{x:318,y:530,t:1527019923995};\\\", \\\"{x:316,y:530,t:1527019924011};\\\", \\\"{x:315,y:530,t:1527019924040};\\\", \\\"{x:313,y:530,t:1527019924048};\\\", \\\"{x:313,y:531,t:1527019924061};\\\", \\\"{x:311,y:533,t:1527019924078};\\\", \\\"{x:307,y:539,t:1527019924095};\\\", \\\"{x:303,y:545,t:1527019924111};\\\", \\\"{x:299,y:550,t:1527019924128};\\\", \\\"{x:293,y:558,t:1527019924146};\\\", \\\"{x:288,y:563,t:1527019924162};\\\", \\\"{x:282,y:564,t:1527019924177};\\\", \\\"{x:277,y:566,t:1527019924195};\\\", \\\"{x:269,y:566,t:1527019924213};\\\", \\\"{x:256,y:566,t:1527019924228};\\\", \\\"{x:241,y:566,t:1527019924245};\\\", \\\"{x:233,y:566,t:1527019924262};\\\", \\\"{x:231,y:566,t:1527019924278};\\\", \\\"{x:226,y:567,t:1527019924294};\\\", \\\"{x:224,y:568,t:1527019924312};\\\", \\\"{x:220,y:570,t:1527019924327};\\\", \\\"{x:216,y:571,t:1527019924345};\\\", \\\"{x:214,y:572,t:1527019924362};\\\", \\\"{x:214,y:574,t:1527019924409};\\\", \\\"{x:223,y:574,t:1527019924417};\\\", \\\"{x:239,y:574,t:1527019924428};\\\", \\\"{x:283,y:573,t:1527019924447};\\\", \\\"{x:306,y:565,t:1527019924462};\\\", \\\"{x:335,y:555,t:1527019924479};\\\", \\\"{x:363,y:548,t:1527019924494};\\\", \\\"{x:386,y:546,t:1527019924513};\\\", \\\"{x:406,y:544,t:1527019924530};\\\", \\\"{x:411,y:543,t:1527019924545};\\\", \\\"{x:414,y:543,t:1527019924562};\\\", \\\"{x:423,y:542,t:1527019924579};\\\", \\\"{x:448,y:540,t:1527019924595};\\\", \\\"{x:472,y:540,t:1527019924612};\\\", \\\"{x:485,y:540,t:1527019924628};\\\", \\\"{x:487,y:540,t:1527019924644};\\\", \\\"{x:489,y:540,t:1527019924665};\\\", \\\"{x:491,y:540,t:1527019924678};\\\", \\\"{x:509,y:540,t:1527019924696};\\\", \\\"{x:537,y:542,t:1527019924712};\\\", \\\"{x:560,y:545,t:1527019924728};\\\", \\\"{x:579,y:545,t:1527019924745};\\\", \\\"{x:584,y:545,t:1527019924762};\\\", \\\"{x:587,y:545,t:1527019924779};\\\", \\\"{x:589,y:545,t:1527019924795};\\\", \\\"{x:596,y:545,t:1527019924812};\\\", \\\"{x:607,y:545,t:1527019924829};\\\", \\\"{x:617,y:545,t:1527019924846};\\\", \\\"{x:631,y:545,t:1527019924862};\\\", \\\"{x:647,y:545,t:1527019924879};\\\", \\\"{x:663,y:545,t:1527019924894};\\\", \\\"{x:682,y:545,t:1527019924912};\\\", \\\"{x:718,y:543,t:1527019924929};\\\", \\\"{x:759,y:542,t:1527019924946};\\\", \\\"{x:810,y:542,t:1527019924962};\\\", \\\"{x:849,y:542,t:1527019924979};\\\", \\\"{x:876,y:542,t:1527019924996};\\\", \\\"{x:895,y:545,t:1527019925012};\\\", \\\"{x:901,y:545,t:1527019925028};\\\", \\\"{x:902,y:545,t:1527019925046};\\\", \\\"{x:903,y:545,t:1527019925105};\\\", \\\"{x:904,y:545,t:1527019925112};\\\", \\\"{x:905,y:545,t:1527019925129};\\\", \\\"{x:906,y:545,t:1527019925146};\\\", \\\"{x:907,y:545,t:1527019925162};\\\", \\\"{x:906,y:544,t:1527019925194};\\\", \\\"{x:900,y:541,t:1527019925201};\\\", \\\"{x:894,y:539,t:1527019925213};\\\", \\\"{x:884,y:539,t:1527019925229};\\\", \\\"{x:880,y:539,t:1527019925246};\\\", \\\"{x:874,y:541,t:1527019925262};\\\", \\\"{x:869,y:543,t:1527019925279};\\\", \\\"{x:861,y:547,t:1527019925296};\\\", \\\"{x:856,y:548,t:1527019925312};\\\", \\\"{x:853,y:549,t:1527019925329};\\\", \\\"{x:851,y:550,t:1527019925347};\\\", \\\"{x:850,y:550,t:1527019925754};\\\", \\\"{x:845,y:549,t:1527019925765};\\\", \\\"{x:838,y:546,t:1527019925780};\\\", \\\"{x:832,y:546,t:1527019926121};\\\", \\\"{x:819,y:554,t:1527019926130};\\\", \\\"{x:777,y:582,t:1527019926147};\\\", \\\"{x:719,y:632,t:1527019926164};\\\", \\\"{x:678,y:666,t:1527019926180};\\\", \\\"{x:667,y:673,t:1527019926196};\\\", \\\"{x:663,y:676,t:1527019926213};\\\", \\\"{x:653,y:681,t:1527019926230};\\\", \\\"{x:635,y:692,t:1527019926246};\\\", \\\"{x:604,y:709,t:1527019926263};\\\", \\\"{x:558,y:724,t:1527019926281};\\\", \\\"{x:533,y:731,t:1527019926296};\\\", \\\"{x:522,y:734,t:1527019926313};\\\", \\\"{x:522,y:732,t:1527019927066};\\\", \\\"{x:522,y:731,t:1527019927080};\\\", \\\"{x:522,y:729,t:1527019927097};\\\", \\\"{x:522,y:728,t:1527019927114};\\\", \\\"{x:522,y:727,t:1527019927131};\\\", \\\"{x:522,y:726,t:1527019927148};\\\", \\\"{x:522,y:724,t:1527019927164};\\\", \\\"{x:522,y:723,t:1527019927181};\\\", \\\"{x:522,y:722,t:1527019927197};\\\", \\\"{x:522,y:721,t:1527019927214};\\\", \\\"{x:522,y:720,t:1527019927231};\\\", \\\"{x:522,y:719,t:1527019927247};\\\", \\\"{x:522,y:718,t:1527019927264};\\\", \\\"{x:522,y:717,t:1527019927289};\\\", \\\"{x:522,y:716,t:1527019927305};\\\", \\\"{x:522,y:715,t:1527019927321};\\\", \\\"{x:522,y:714,t:1527019927354};\\\", \\\"{x:522,y:713,t:1527019927369};\\\", \\\"{x:522,y:712,t:1527019927393};\\\", \\\"{x:522,y:711,t:1527019927425};\\\", \\\"{x:522,y:710,t:1527019927450};\\\", \\\"{x:522,y:709,t:1527019927473};\\\", \\\"{x:522,y:708,t:1527019927506};\\\", \\\"{x:522,y:707,t:1527019927546};\\\" ] }, { \\\"rt\\\": 9838, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 17, \\\"time_elapsed\\\": 544677, \\\"internal_node_id\\\": \\\"0.0-6.0-7.0\\\", \\\"subject\\\": \\\"VT5BG\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"golf\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 13, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"E\\\", \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-Z -Z -02 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:522,y:705,t:1527019929858};\\\", \\\"{x:522,y:702,t:1527019929866};\\\", \\\"{x:522,y:699,t:1527019929884};\\\", \\\"{x:523,y:697,t:1527019929899};\\\", \\\"{x:523,y:696,t:1527019929917};\\\", \\\"{x:525,y:693,t:1527019929933};\\\", \\\"{x:526,y:690,t:1527019929949};\\\", \\\"{x:528,y:689,t:1527019929967};\\\", \\\"{x:529,y:687,t:1527019929983};\\\", \\\"{x:529,y:686,t:1527019929999};\\\", \\\"{x:532,y:683,t:1527019930023};\\\", \\\"{x:533,y:682,t:1527019930033};\\\", \\\"{x:534,y:679,t:1527019930049};\\\", \\\"{x:535,y:678,t:1527019930066};\\\", \\\"{x:537,y:677,t:1527019930083};\\\", \\\"{x:543,y:674,t:1527019930099};\\\", \\\"{x:552,y:669,t:1527019930116};\\\", \\\"{x:566,y:664,t:1527019930133};\\\", \\\"{x:577,y:661,t:1527019930149};\\\", \\\"{x:592,y:656,t:1527019930166};\\\", \\\"{x:605,y:651,t:1527019930183};\\\", \\\"{x:626,y:645,t:1527019930199};\\\", \\\"{x:653,y:640,t:1527019930216};\\\", \\\"{x:706,y:639,t:1527019930233};\\\", \\\"{x:732,y:639,t:1527019930250};\\\", \\\"{x:749,y:639,t:1527019930266};\\\", \\\"{x:770,y:645,t:1527019930282};\\\", \\\"{x:797,y:653,t:1527019930300};\\\", \\\"{x:848,y:669,t:1527019930315};\\\", \\\"{x:909,y:686,t:1527019930333};\\\", \\\"{x:970,y:705,t:1527019930350};\\\", \\\"{x:1009,y:714,t:1527019930366};\\\", \\\"{x:1044,y:728,t:1527019930383};\\\", \\\"{x:1084,y:747,t:1527019930400};\\\", \\\"{x:1116,y:760,t:1527019930416};\\\", \\\"{x:1149,y:772,t:1527019930433};\\\", \\\"{x:1173,y:783,t:1527019930450};\\\", \\\"{x:1209,y:796,t:1527019930466};\\\", \\\"{x:1238,y:811,t:1527019930483};\\\", \\\"{x:1262,y:824,t:1527019930500};\\\", \\\"{x:1280,y:836,t:1527019930516};\\\", \\\"{x:1292,y:853,t:1527019930533};\\\", \\\"{x:1295,y:859,t:1527019930550};\\\", \\\"{x:1296,y:859,t:1527019931675};\\\", \\\"{x:1297,y:859,t:1527019931738};\\\", \\\"{x:1299,y:859,t:1527019931751};\\\", \\\"{x:1302,y:859,t:1527019931768};\\\", \\\"{x:1307,y:855,t:1527019931785};\\\", \\\"{x:1326,y:848,t:1527019931802};\\\", \\\"{x:1411,y:826,t:1527019931818};\\\", \\\"{x:1473,y:798,t:1527019931835};\\\", \\\"{x:1529,y:767,t:1527019931852};\\\", \\\"{x:1573,y:742,t:1527019931867};\\\", \\\"{x:1607,y:716,t:1527019931885};\\\", \\\"{x:1627,y:701,t:1527019931902};\\\", \\\"{x:1638,y:692,t:1527019931918};\\\", \\\"{x:1642,y:689,t:1527019931935};\\\", \\\"{x:1644,y:688,t:1527019931952};\\\", \\\"{x:1647,y:686,t:1527019931968};\\\", \\\"{x:1649,y:681,t:1527019931985};\\\", \\\"{x:1654,y:675,t:1527019932001};\\\", \\\"{x:1654,y:674,t:1527019932018};\\\", \\\"{x:1655,y:673,t:1527019932034};\\\", \\\"{x:1652,y:673,t:1527019932098};\\\", \\\"{x:1645,y:675,t:1527019932106};\\\", \\\"{x:1638,y:677,t:1527019932118};\\\", \\\"{x:1624,y:683,t:1527019932135};\\\", \\\"{x:1619,y:687,t:1527019932152};\\\", \\\"{x:1618,y:690,t:1527019932169};\\\", \\\"{x:1617,y:691,t:1527019932187};\\\", \\\"{x:1618,y:691,t:1527019932273};\\\", \\\"{x:1619,y:691,t:1527019932285};\\\", \\\"{x:1621,y:691,t:1527019932304};\\\", \\\"{x:1620,y:698,t:1527019933080};\\\", \\\"{x:1600,y:745,t:1527019933100};\\\", \\\"{x:1583,y:789,t:1527019933117};\\\", \\\"{x:1577,y:810,t:1527019933133};\\\", \\\"{x:1573,y:821,t:1527019933151};\\\", \\\"{x:1565,y:850,t:1527019933167};\\\", \\\"{x:1540,y:924,t:1527019933184};\\\", \\\"{x:1527,y:974,t:1527019933201};\\\", \\\"{x:1519,y:999,t:1527019933217};\\\", \\\"{x:1515,y:1014,t:1527019933234};\\\", \\\"{x:1513,y:1022,t:1527019933251};\\\", \\\"{x:1512,y:1026,t:1527019933267};\\\", \\\"{x:1508,y:1034,t:1527019933283};\\\", \\\"{x:1504,y:1042,t:1527019933301};\\\", \\\"{x:1500,y:1048,t:1527019933317};\\\", \\\"{x:1496,y:1051,t:1527019933333};\\\", \\\"{x:1492,y:1054,t:1527019933351};\\\", \\\"{x:1482,y:1056,t:1527019933368};\\\", \\\"{x:1481,y:1056,t:1527019933384};\\\", \\\"{x:1480,y:1056,t:1527019933423};\\\", \\\"{x:1480,y:1049,t:1527019933434};\\\", \\\"{x:1480,y:1022,t:1527019933450};\\\", \\\"{x:1480,y:1008,t:1527019933467};\\\", \\\"{x:1480,y:997,t:1527019933484};\\\", \\\"{x:1481,y:991,t:1527019933500};\\\", \\\"{x:1482,y:987,t:1527019933517};\\\", \\\"{x:1482,y:983,t:1527019933712};\\\", \\\"{x:1482,y:977,t:1527019933719};\\\", \\\"{x:1482,y:974,t:1527019933734};\\\", \\\"{x:1482,y:971,t:1527019933751};\\\", \\\"{x:1482,y:970,t:1527019933768};\\\", \\\"{x:1482,y:969,t:1527019934287};\\\", \\\"{x:1482,y:968,t:1527019934303};\\\", \\\"{x:1482,y:967,t:1527019934317};\\\", \\\"{x:1482,y:966,t:1527019934351};\\\", \\\"{x:1482,y:965,t:1527019934375};\\\", \\\"{x:1482,y:964,t:1527019934398};\\\", \\\"{x:1482,y:963,t:1527019934407};\\\", \\\"{x:1482,y:962,t:1527019934696};\\\", \\\"{x:1479,y:958,t:1527019934703};\\\", \\\"{x:1455,y:950,t:1527019934718};\\\", \\\"{x:1422,y:937,t:1527019934734};\\\", \\\"{x:1384,y:917,t:1527019934751};\\\", \\\"{x:1336,y:891,t:1527019934768};\\\", \\\"{x:1256,y:840,t:1527019934784};\\\", \\\"{x:1156,y:767,t:1527019934801};\\\", \\\"{x:1049,y:684,t:1527019934818};\\\", \\\"{x:952,y:613,t:1527019934834};\\\", \\\"{x:858,y:550,t:1527019934852};\\\", \\\"{x:762,y:497,t:1527019934869};\\\", \\\"{x:673,y:451,t:1527019934884};\\\", \\\"{x:602,y:411,t:1527019934916};\\\", \\\"{x:588,y:404,t:1527019934932};\\\", \\\"{x:574,y:397,t:1527019934948};\\\", \\\"{x:554,y:383,t:1527019934966};\\\", \\\"{x:515,y:359,t:1527019934982};\\\", \\\"{x:492,y:353,t:1527019934998};\\\", \\\"{x:492,y:352,t:1527019935046};\\\", \\\"{x:495,y:353,t:1527019935192};\\\", \\\"{x:502,y:359,t:1527019935199};\\\", \\\"{x:525,y:382,t:1527019935216};\\\", \\\"{x:551,y:412,t:1527019935233};\\\", \\\"{x:566,y:428,t:1527019935250};\\\", \\\"{x:580,y:436,t:1527019935266};\\\", \\\"{x:583,y:438,t:1527019935282};\\\", \\\"{x:588,y:442,t:1527019935299};\\\", \\\"{x:591,y:446,t:1527019935316};\\\", \\\"{x:596,y:454,t:1527019935332};\\\", \\\"{x:600,y:463,t:1527019935349};\\\", \\\"{x:606,y:475,t:1527019935366};\\\", \\\"{x:607,y:475,t:1527019935382};\\\", \\\"{x:607,y:476,t:1527019935431};\\\", \\\"{x:607,y:483,t:1527019935438};\\\", \\\"{x:607,y:488,t:1527019935451};\\\", \\\"{x:612,y:503,t:1527019935466};\\\", \\\"{x:614,y:507,t:1527019935484};\\\", \\\"{x:615,y:509,t:1527019935502};\\\", \\\"{x:621,y:509,t:1527019935894};\\\", \\\"{x:636,y:509,t:1527019935902};\\\", \\\"{x:668,y:507,t:1527019935918};\\\", \\\"{x:694,y:504,t:1527019935935};\\\", \\\"{x:712,y:498,t:1527019935952};\\\", \\\"{x:733,y:494,t:1527019935970};\\\", \\\"{x:751,y:491,t:1527019935985};\\\", \\\"{x:772,y:490,t:1527019936002};\\\", \\\"{x:788,y:490,t:1527019936019};\\\", \\\"{x:811,y:498,t:1527019936035};\\\", \\\"{x:842,y:515,t:1527019936052};\\\", \\\"{x:865,y:526,t:1527019936070};\\\", \\\"{x:873,y:532,t:1527019936084};\\\", \\\"{x:874,y:532,t:1527019936102};\\\", \\\"{x:874,y:534,t:1527019936143};\\\", \\\"{x:872,y:535,t:1527019936152};\\\", \\\"{x:863,y:538,t:1527019936171};\\\", \\\"{x:855,y:539,t:1527019936185};\\\", \\\"{x:850,y:539,t:1527019936202};\\\", \\\"{x:849,y:539,t:1527019936246};\\\", \\\"{x:846,y:539,t:1527019936254};\\\", \\\"{x:843,y:538,t:1527019936269};\\\", \\\"{x:832,y:529,t:1527019936286};\\\", \\\"{x:833,y:527,t:1527019936319};\\\", \\\"{x:838,y:524,t:1527019936337};\\\", \\\"{x:840,y:523,t:1527019936352};\\\", \\\"{x:842,y:521,t:1527019936369};\\\", \\\"{x:843,y:520,t:1527019936431};\\\", \\\"{x:844,y:518,t:1527019936438};\\\", \\\"{x:844,y:516,t:1527019936453};\\\", \\\"{x:845,y:511,t:1527019936469};\\\", \\\"{x:845,y:509,t:1527019936486};\\\", \\\"{x:845,y:508,t:1527019936510};\\\", \\\"{x:845,y:506,t:1527019936607};\\\", \\\"{x:845,y:505,t:1527019936622};\\\", \\\"{x:845,y:502,t:1527019936636};\\\", \\\"{x:845,y:499,t:1527019936652};\\\", \\\"{x:844,y:498,t:1527019936669};\\\", \\\"{x:844,y:497,t:1527019936736};\\\", \\\"{x:844,y:497,t:1527019936795};\\\", \\\"{x:839,y:497,t:1527019936918};\\\", \\\"{x:829,y:505,t:1527019936926};\\\", \\\"{x:818,y:513,t:1527019936937};\\\", \\\"{x:786,y:541,t:1527019936954};\\\", \\\"{x:747,y:566,t:1527019936970};\\\", \\\"{x:728,y:576,t:1527019936986};\\\", \\\"{x:720,y:579,t:1527019937004};\\\", \\\"{x:711,y:584,t:1527019937019};\\\", \\\"{x:696,y:595,t:1527019937037};\\\", \\\"{x:677,y:610,t:1527019937054};\\\", \\\"{x:672,y:626,t:1527019937069};\\\", \\\"{x:671,y:647,t:1527019937087};\\\", \\\"{x:671,y:654,t:1527019937104};\\\", \\\"{x:671,y:658,t:1527019937119};\\\", \\\"{x:670,y:658,t:1527019937183};\\\", \\\"{x:668,y:658,t:1527019937191};\\\", \\\"{x:665,y:659,t:1527019937203};\\\", \\\"{x:663,y:662,t:1527019937220};\\\", \\\"{x:660,y:666,t:1527019937236};\\\", \\\"{x:657,y:670,t:1527019937253};\\\", \\\"{x:649,y:674,t:1527019937270};\\\", \\\"{x:637,y:675,t:1527019937286};\\\", \\\"{x:622,y:679,t:1527019937303};\\\", \\\"{x:603,y:686,t:1527019937320};\\\", \\\"{x:586,y:697,t:1527019937336};\\\", \\\"{x:566,y:711,t:1527019937353};\\\", \\\"{x:556,y:722,t:1527019937372};\\\", \\\"{x:555,y:723,t:1527019937386};\\\", \\\"{x:554,y:723,t:1527019937407};\\\", \\\"{x:553,y:723,t:1527019937420};\\\", \\\"{x:547,y:723,t:1527019937436};\\\", \\\"{x:542,y:721,t:1527019937453};\\\", \\\"{x:540,y:721,t:1527019937478};\\\", \\\"{x:540,y:722,t:1527019937718};\\\", \\\"{x:540,y:724,t:1527019937734};\\\", \\\"{x:541,y:724,t:1527019937750};\\\", \\\"{x:541,y:725,t:1527019937831};\\\", \\\"{x:542,y:725,t:1527019937863};\\\", \\\"{x:543,y:725,t:1527019937935};\\\", \\\"{x:545,y:725,t:1527019937943};\\\", \\\"{x:546,y:725,t:1527019937953};\\\", \\\"{x:549,y:724,t:1527019937970};\\\", \\\"{x:553,y:723,t:1527019937987};\\\", \\\"{x:558,y:720,t:1527019938003};\\\", \\\"{x:570,y:714,t:1527019938020};\\\", \\\"{x:576,y:710,t:1527019938037};\\\", \\\"{x:580,y:709,t:1527019938053};\\\", \\\"{x:585,y:706,t:1527019938070};\\\", \\\"{x:595,y:706,t:1527019938087};\\\", \\\"{x:612,y:708,t:1527019938103};\\\", \\\"{x:631,y:708,t:1527019938120};\\\", \\\"{x:656,y:698,t:1527019938137};\\\", \\\"{x:664,y:687,t:1527019938153};\\\", \\\"{x:664,y:686,t:1527019938171};\\\", \\\"{x:665,y:685,t:1527019938188};\\\", \\\"{x:665,y:684,t:1527019938247};\\\", \\\"{x:667,y:684,t:1527019938255};\\\", \\\"{x:676,y:684,t:1527019938270};\\\", \\\"{x:711,y:684,t:1527019938287};\\\", \\\"{x:713,y:684,t:1527019938304};\\\", \\\"{x:713,y:686,t:1527019938321};\\\" ] }, { \\\"rt\\\": 8503, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 18, \\\"time_elapsed\\\": 554391, \\\"internal_node_id\\\": \\\"0.0-6.0-8.0\\\", \\\"subject\\\": \\\"VT5BG\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"golf\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 14, \\\"clicks\\\": 0, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-2-M -03 PM-03 PM-03 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:713,y:687,t:1527019938893};\\\", \\\"{x:712,y:688,t:1527019938904};\\\", \\\"{x:711,y:688,t:1527019938921};\\\", \\\"{x:713,y:689,t:1527019939630};\\\", \\\"{x:718,y:692,t:1527019939638};\\\", \\\"{x:733,y:699,t:1527019939655};\\\", \\\"{x:782,y:735,t:1527019939671};\\\", \\\"{x:832,y:770,t:1527019939688};\\\", \\\"{x:852,y:784,t:1527019939705};\\\", \\\"{x:856,y:786,t:1527019939721};\\\", \\\"{x:860,y:786,t:1527019939738};\\\", \\\"{x:866,y:786,t:1527019939755};\\\", \\\"{x:867,y:786,t:1527019939771};\\\", \\\"{x:871,y:786,t:1527019940119};\\\", \\\"{x:874,y:786,t:1527019940127};\\\", \\\"{x:876,y:786,t:1527019940143};\\\", \\\"{x:878,y:786,t:1527019940156};\\\", \\\"{x:893,y:786,t:1527019940173};\\\", \\\"{x:925,y:792,t:1527019940189};\\\", \\\"{x:963,y:796,t:1527019940206};\\\", \\\"{x:999,y:802,t:1527019940223};\\\", \\\"{x:1012,y:805,t:1527019940239};\\\", \\\"{x:1019,y:808,t:1527019940255};\\\", \\\"{x:1025,y:812,t:1527019940272};\\\", \\\"{x:1029,y:817,t:1527019940289};\\\", \\\"{x:1032,y:820,t:1527019940306};\\\", \\\"{x:1035,y:822,t:1527019940323};\\\", \\\"{x:1040,y:824,t:1527019940340};\\\", \\\"{x:1043,y:825,t:1527019940356};\\\", \\\"{x:1048,y:829,t:1527019940373};\\\", \\\"{x:1049,y:829,t:1527019940390};\\\", \\\"{x:1050,y:830,t:1527019940551};\\\", \\\"{x:1058,y:833,t:1527019940559};\\\", \\\"{x:1079,y:840,t:1527019940574};\\\", \\\"{x:1124,y:848,t:1527019940590};\\\", \\\"{x:1163,y:853,t:1527019940606};\\\", \\\"{x:1211,y:858,t:1527019940623};\\\", \\\"{x:1242,y:864,t:1527019940639};\\\", \\\"{x:1286,y:872,t:1527019940656};\\\", \\\"{x:1313,y:877,t:1527019940673};\\\", \\\"{x:1331,y:878,t:1527019940691};\\\", \\\"{x:1345,y:879,t:1527019940706};\\\", \\\"{x:1354,y:880,t:1527019940723};\\\", \\\"{x:1359,y:881,t:1527019940740};\\\", \\\"{x:1364,y:883,t:1527019940757};\\\", \\\"{x:1380,y:889,t:1527019940773};\\\", \\\"{x:1404,y:903,t:1527019940790};\\\", \\\"{x:1424,y:916,t:1527019940806};\\\", \\\"{x:1456,y:935,t:1527019940823};\\\", \\\"{x:1489,y:948,t:1527019940840};\\\", \\\"{x:1519,y:954,t:1527019940858};\\\", \\\"{x:1534,y:958,t:1527019940873};\\\", \\\"{x:1539,y:958,t:1527019940890};\\\", \\\"{x:1539,y:959,t:1527019940960};\\\", \\\"{x:1539,y:961,t:1527019941151};\\\", \\\"{x:1539,y:965,t:1527019941159};\\\", \\\"{x:1539,y:970,t:1527019941174};\\\", \\\"{x:1539,y:976,t:1527019941191};\\\", \\\"{x:1540,y:976,t:1527019941336};\\\", \\\"{x:1541,y:977,t:1527019941343};\\\", \\\"{x:1542,y:977,t:1527019941519};\\\", \\\"{x:1544,y:978,t:1527019941527};\\\", \\\"{x:1544,y:979,t:1527019941540};\\\", \\\"{x:1545,y:979,t:1527019941557};\\\", \\\"{x:1548,y:981,t:1527019941574};\\\", \\\"{x:1555,y:983,t:1527019941590};\\\", \\\"{x:1561,y:987,t:1527019941607};\\\", \\\"{x:1563,y:988,t:1527019941624};\\\", \\\"{x:1564,y:988,t:1527019941672};\\\", \\\"{x:1563,y:986,t:1527019941831};\\\", \\\"{x:1561,y:981,t:1527019941841};\\\", \\\"{x:1557,y:969,t:1527019941857};\\\", \\\"{x:1557,y:967,t:1527019941874};\\\", \\\"{x:1557,y:966,t:1527019941891};\\\", \\\"{x:1555,y:970,t:1527019943119};\\\", \\\"{x:1553,y:974,t:1527019943127};\\\", \\\"{x:1550,y:978,t:1527019943142};\\\", \\\"{x:1549,y:979,t:1527019943158};\\\", \\\"{x:1549,y:980,t:1527019943175};\\\", \\\"{x:1545,y:980,t:1527019944311};\\\", \\\"{x:1522,y:967,t:1527019944326};\\\", \\\"{x:1333,y:865,t:1527019944343};\\\", \\\"{x:1167,y:776,t:1527019944359};\\\", \\\"{x:986,y:710,t:1527019944376};\\\", \\\"{x:806,y:651,t:1527019944393};\\\", \\\"{x:632,y:606,t:1527019944410};\\\", \\\"{x:453,y:553,t:1527019944427};\\\", \\\"{x:296,y:520,t:1527019944442};\\\", \\\"{x:205,y:511,t:1527019944459};\\\", \\\"{x:176,y:511,t:1527019944476};\\\", \\\"{x:169,y:511,t:1527019944492};\\\", \\\"{x:168,y:511,t:1527019944508};\\\", \\\"{x:167,y:511,t:1527019944574};\\\", \\\"{x:167,y:514,t:1527019944582};\\\", \\\"{x:167,y:517,t:1527019944592};\\\", \\\"{x:173,y:521,t:1527019944609};\\\", \\\"{x:183,y:522,t:1527019944625};\\\", \\\"{x:202,y:522,t:1527019944643};\\\", \\\"{x:229,y:522,t:1527019944659};\\\", \\\"{x:261,y:528,t:1527019944676};\\\", \\\"{x:289,y:536,t:1527019944694};\\\", \\\"{x:308,y:545,t:1527019944709};\\\", \\\"{x:317,y:549,t:1527019944725};\\\", \\\"{x:334,y:556,t:1527019944742};\\\", \\\"{x:348,y:561,t:1527019944760};\\\", \\\"{x:358,y:562,t:1527019944775};\\\", \\\"{x:362,y:562,t:1527019944793};\\\", \\\"{x:362,y:564,t:1527019944944};\\\", \\\"{x:360,y:575,t:1527019944959};\\\", \\\"{x:350,y:588,t:1527019944976};\\\", \\\"{x:339,y:599,t:1527019944993};\\\", \\\"{x:323,y:611,t:1527019945010};\\\", \\\"{x:300,y:622,t:1527019945025};\\\", \\\"{x:274,y:633,t:1527019945043};\\\", \\\"{x:247,y:635,t:1527019945059};\\\", \\\"{x:215,y:635,t:1527019945075};\\\", \\\"{x:181,y:635,t:1527019945093};\\\", \\\"{x:164,y:635,t:1527019945109};\\\", \\\"{x:158,y:636,t:1527019945126};\\\", \\\"{x:161,y:639,t:1527019945336};\\\", \\\"{x:165,y:641,t:1527019945343};\\\", \\\"{x:193,y:643,t:1527019945359};\\\", \\\"{x:249,y:643,t:1527019945376};\\\", \\\"{x:330,y:643,t:1527019945393};\\\", \\\"{x:417,y:638,t:1527019945409};\\\", \\\"{x:512,y:625,t:1527019945427};\\\", \\\"{x:601,y:598,t:1527019945443};\\\", \\\"{x:669,y:571,t:1527019945460};\\\", \\\"{x:704,y:557,t:1527019945476};\\\", \\\"{x:713,y:552,t:1527019945494};\\\", \\\"{x:714,y:552,t:1527019945510};\\\", \\\"{x:716,y:552,t:1527019945542};\\\", \\\"{x:732,y:549,t:1527019945560};\\\", \\\"{x:754,y:544,t:1527019945576};\\\", \\\"{x:769,y:541,t:1527019945593};\\\", \\\"{x:779,y:536,t:1527019945609};\\\", \\\"{x:792,y:533,t:1527019945626};\\\", \\\"{x:805,y:531,t:1527019945644};\\\", \\\"{x:818,y:529,t:1527019945659};\\\", \\\"{x:819,y:529,t:1527019945676};\\\", \\\"{x:820,y:532,t:1527019945711};\\\", \\\"{x:824,y:550,t:1527019945728};\\\", \\\"{x:830,y:565,t:1527019945745};\\\", \\\"{x:832,y:567,t:1527019945759};\\\", \\\"{x:833,y:568,t:1527019945776};\\\", \\\"{x:833,y:574,t:1527019945793};\\\", \\\"{x:827,y:583,t:1527019945809};\\\", \\\"{x:811,y:605,t:1527019945827};\\\", \\\"{x:793,y:625,t:1527019945843};\\\", \\\"{x:772,y:643,t:1527019945860};\\\", \\\"{x:751,y:652,t:1527019945876};\\\", \\\"{x:723,y:657,t:1527019945893};\\\", \\\"{x:670,y:659,t:1527019945910};\\\", \\\"{x:643,y:662,t:1527019945927};\\\", \\\"{x:625,y:662,t:1527019945943};\\\", \\\"{x:613,y:662,t:1527019945960};\\\", \\\"{x:607,y:662,t:1527019945977};\\\", \\\"{x:605,y:662,t:1527019945993};\\\", \\\"{x:604,y:662,t:1527019946010};\\\", \\\"{x:603,y:662,t:1527019946026};\\\", \\\"{x:603,y:660,t:1527019946055};\\\", \\\"{x:602,y:652,t:1527019946062};\\\", \\\"{x:597,y:641,t:1527019946077};\\\", \\\"{x:587,y:618,t:1527019946094};\\\", \\\"{x:581,y:609,t:1527019946110};\\\", \\\"{x:581,y:608,t:1527019946142};\\\", \\\"{x:581,y:604,t:1527019946150};\\\", \\\"{x:582,y:603,t:1527019946160};\\\", \\\"{x:588,y:596,t:1527019946178};\\\", \\\"{x:589,y:591,t:1527019946195};\\\", \\\"{x:589,y:589,t:1527019946210};\\\", \\\"{x:591,y:587,t:1527019946226};\\\", \\\"{x:592,y:584,t:1527019946279};\\\", \\\"{x:593,y:583,t:1527019946294};\\\", \\\"{x:596,y:578,t:1527019946311};\\\", \\\"{x:597,y:577,t:1527019946327};\\\", \\\"{x:598,y:577,t:1527019946344};\\\", \\\"{x:599,y:577,t:1527019946455};\\\", \\\"{x:600,y:577,t:1527019946536};\\\", \\\"{x:601,y:577,t:1527019946543};\\\", \\\"{x:601,y:577,t:1527019946582};\\\", \\\"{x:601,y:582,t:1527019946686};\\\", \\\"{x:596,y:589,t:1527019946694};\\\", \\\"{x:591,y:608,t:1527019946711};\\\", \\\"{x:582,y:626,t:1527019946727};\\\", \\\"{x:567,y:652,t:1527019946745};\\\", \\\"{x:552,y:675,t:1527019946760};\\\", \\\"{x:542,y:695,t:1527019946778};\\\", \\\"{x:541,y:703,t:1527019946793};\\\", \\\"{x:540,y:705,t:1527019946811};\\\", \\\"{x:540,y:707,t:1527019946828};\\\", \\\"{x:540,y:708,t:1527019946847};\\\", \\\"{x:539,y:711,t:1527019946990};\\\", \\\"{x:536,y:722,t:1527019946999};\\\", \\\"{x:532,y:737,t:1527019947011};\\\", \\\"{x:530,y:747,t:1527019947027};\\\", \\\"{x:528,y:752,t:1527019947045};\\\", \\\"{x:528,y:747,t:1527019947102};\\\", \\\"{x:529,y:740,t:1527019947110};\\\", \\\"{x:531,y:734,t:1527019947127};\\\", \\\"{x:533,y:730,t:1527019947145};\\\", \\\"{x:534,y:729,t:1527019947160};\\\", \\\"{x:535,y:726,t:1527019948070};\\\", \\\"{x:535,y:724,t:1527019948078};\\\", \\\"{x:535,y:723,t:1527019948095};\\\" ] }, { \\\"rt\\\": 74609, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 19, \\\"time_elapsed\\\": 630290, \\\"internal_node_id\\\": \\\"0.0-6.0-9.0\\\", \\\"subject\\\": \\\"VT5BG\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"golf\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 15, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"K\\\", \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-02 PM-02 PM-02 PM-02 PM-X -X -X -X -03 PM-12 PM-M -M -X -C -C \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:535,y:724,t:1527019949719};\\\", \\\"{x:535,y:725,t:1527019949730};\\\", \\\"{x:535,y:727,t:1527019949747};\\\", \\\"{x:536,y:727,t:1527019949829};\\\", \\\"{x:538,y:727,t:1527019949870};\\\", \\\"{x:539,y:727,t:1527019949950};\\\", \\\"{x:539,y:728,t:1527019952399};\\\", \\\"{x:535,y:730,t:1527019959775};\\\", \\\"{x:533,y:731,t:1527019959788};\\\", \\\"{x:529,y:732,t:1527019959804};\\\", \\\"{x:528,y:732,t:1527019959821};\\\", \\\"{x:527,y:733,t:1527019959838};\\\", \\\"{x:526,y:733,t:1527019961231};\\\", \\\"{x:525,y:734,t:1527019961865};\\\", \\\"{x:516,y:738,t:1527019961872};\\\", \\\"{x:497,y:748,t:1527019961888};\\\", \\\"{x:476,y:757,t:1527019961906};\\\", \\\"{x:443,y:761,t:1527019961923};\\\", \\\"{x:442,y:764,t:1527019961940};\\\", \\\"{x:443,y:764,t:1527019962375};\\\", \\\"{x:446,y:759,t:1527019962391};\\\", \\\"{x:446,y:758,t:1527019962407};\\\", \\\"{x:443,y:753,t:1527019962424};\\\", \\\"{x:441,y:748,t:1527019962440};\\\", \\\"{x:441,y:747,t:1527019962456};\\\", \\\"{x:441,y:746,t:1527019962478};\\\", \\\"{x:442,y:745,t:1527019962490};\\\", \\\"{x:459,y:744,t:1527019962508};\\\", \\\"{x:494,y:744,t:1527019962523};\\\", \\\"{x:544,y:744,t:1527019962540};\\\", \\\"{x:592,y:744,t:1527019962558};\\\", \\\"{x:650,y:744,t:1527019962573};\\\", \\\"{x:774,y:773,t:1527019962590};\\\", \\\"{x:876,y:801,t:1527019962607};\\\", \\\"{x:998,y:835,t:1527019962623};\\\", \\\"{x:1125,y:873,t:1527019962640};\\\", \\\"{x:1200,y:904,t:1527019962658};\\\", \\\"{x:1219,y:914,t:1527019962673};\\\", \\\"{x:1223,y:917,t:1527019962690};\\\", \\\"{x:1224,y:917,t:1527019962775};\\\", \\\"{x:1225,y:917,t:1527019962791};\\\", \\\"{x:1239,y:931,t:1527019965327};\\\", \\\"{x:1265,y:955,t:1527019965342};\\\", \\\"{x:1319,y:995,t:1527019965358};\\\", \\\"{x:1394,y:1022,t:1527019965374};\\\", \\\"{x:1414,y:1027,t:1527019965392};\\\", \\\"{x:1423,y:1027,t:1527019965408};\\\", \\\"{x:1424,y:1027,t:1527019965424};\\\", \\\"{x:1426,y:1027,t:1527019965442};\\\", \\\"{x:1429,y:1027,t:1527019965457};\\\", \\\"{x:1437,y:1027,t:1527019965474};\\\", \\\"{x:1448,y:1027,t:1527019965491};\\\", \\\"{x:1463,y:1027,t:1527019965507};\\\", \\\"{x:1473,y:1027,t:1527019965524};\\\", \\\"{x:1478,y:1026,t:1527019965542};\\\", \\\"{x:1479,y:1025,t:1527019965557};\\\", \\\"{x:1479,y:1024,t:1527019965574};\\\", \\\"{x:1479,y:1017,t:1527019965592};\\\", \\\"{x:1479,y:1007,t:1527019965609};\\\", \\\"{x:1479,y:996,t:1527019965625};\\\", \\\"{x:1479,y:988,t:1527019965642};\\\", \\\"{x:1479,y:986,t:1527019965657};\\\", \\\"{x:1479,y:985,t:1527019965791};\\\", \\\"{x:1480,y:985,t:1527019965808};\\\", \\\"{x:1482,y:985,t:1527019965825};\\\", \\\"{x:1483,y:985,t:1527019965871};\\\", \\\"{x:1486,y:985,t:1527019965886};\\\", \\\"{x:1488,y:985,t:1527019965903};\\\", \\\"{x:1488,y:984,t:1527019965911};\\\", \\\"{x:1490,y:984,t:1527019965925};\\\", \\\"{x:1490,y:983,t:1527019965942};\\\", \\\"{x:1491,y:983,t:1527019965958};\\\", \\\"{x:1491,y:982,t:1527019966015};\\\", \\\"{x:1490,y:981,t:1527019966024};\\\", \\\"{x:1486,y:979,t:1527019966042};\\\", \\\"{x:1485,y:978,t:1527019966059};\\\", \\\"{x:1485,y:976,t:1527019966075};\\\", \\\"{x:1485,y:973,t:1527019966091};\\\", \\\"{x:1485,y:970,t:1527019966109};\\\", \\\"{x:1485,y:966,t:1527019966126};\\\", \\\"{x:1485,y:962,t:1527019966142};\\\", \\\"{x:1484,y:958,t:1527019966159};\\\", \\\"{x:1484,y:957,t:1527019966175};\\\", \\\"{x:1483,y:957,t:1527019966375};\\\", \\\"{x:1482,y:957,t:1527019966423};\\\", \\\"{x:1481,y:956,t:1527019966430};\\\", \\\"{x:1480,y:955,t:1527019966462};\\\", \\\"{x:1480,y:954,t:1527019966719};\\\", \\\"{x:1478,y:954,t:1527019966742};\\\", \\\"{x:1478,y:953,t:1527019966759};\\\", \\\"{x:1477,y:951,t:1527019966782};\\\", \\\"{x:1476,y:950,t:1527019966806};\\\", \\\"{x:1475,y:948,t:1527019966815};\\\", \\\"{x:1474,y:948,t:1527019966847};\\\", \\\"{x:1474,y:947,t:1527019966879};\\\", \\\"{x:1473,y:945,t:1527019966935};\\\", \\\"{x:1472,y:944,t:1527019966967};\\\", \\\"{x:1472,y:943,t:1527019966983};\\\", \\\"{x:1471,y:942,t:1527019966993};\\\", \\\"{x:1471,y:941,t:1527019967023};\\\", \\\"{x:1471,y:940,t:1527019967038};\\\", \\\"{x:1469,y:938,t:1527019967047};\\\", \\\"{x:1469,y:937,t:1527019967064};\\\", \\\"{x:1468,y:935,t:1527019967079};\\\", \\\"{x:1467,y:934,t:1527019967094};\\\", \\\"{x:1467,y:932,t:1527019967111};\\\", \\\"{x:1466,y:932,t:1527019967126};\\\", \\\"{x:1465,y:931,t:1527019967142};\\\", \\\"{x:1465,y:930,t:1527019967159};\\\", \\\"{x:1465,y:929,t:1527019967176};\\\", \\\"{x:1465,y:928,t:1527019967199};\\\", \\\"{x:1464,y:927,t:1527019967209};\\\", \\\"{x:1464,y:926,t:1527019967225};\\\", \\\"{x:1463,y:925,t:1527019967241};\\\", \\\"{x:1463,y:924,t:1527019967259};\\\", \\\"{x:1463,y:923,t:1527019967278};\\\", \\\"{x:1462,y:922,t:1527019967292};\\\", \\\"{x:1461,y:921,t:1527019967308};\\\", \\\"{x:1461,y:920,t:1527019967325};\\\", \\\"{x:1460,y:919,t:1527019967342};\\\", \\\"{x:1459,y:918,t:1527019967358};\\\", \\\"{x:1458,y:916,t:1527019967375};\\\", \\\"{x:1457,y:915,t:1527019967392};\\\", \\\"{x:1456,y:914,t:1527019967409};\\\", \\\"{x:1456,y:912,t:1527019967426};\\\", \\\"{x:1455,y:911,t:1527019967442};\\\", \\\"{x:1453,y:908,t:1527019967459};\\\", \\\"{x:1452,y:907,t:1527019967477};\\\", \\\"{x:1450,y:905,t:1527019967492};\\\", \\\"{x:1449,y:904,t:1527019967509};\\\", \\\"{x:1449,y:902,t:1527019967526};\\\", \\\"{x:1448,y:901,t:1527019967631};\\\", \\\"{x:1447,y:901,t:1527019967654};\\\", \\\"{x:1447,y:900,t:1527019967663};\\\", \\\"{x:1446,y:900,t:1527019967679};\\\", \\\"{x:1445,y:899,t:1527019967692};\\\", \\\"{x:1444,y:898,t:1527019967709};\\\", \\\"{x:1443,y:897,t:1527019967742};\\\", \\\"{x:1442,y:896,t:1527019967879};\\\", \\\"{x:1442,y:895,t:1527019967911};\\\", \\\"{x:1441,y:894,t:1527019967935};\\\", \\\"{x:1441,y:893,t:1527019968031};\\\", \\\"{x:1441,y:892,t:1527019968095};\\\", \\\"{x:1441,y:891,t:1527019968109};\\\", \\\"{x:1441,y:890,t:1527019968126};\\\", \\\"{x:1441,y:889,t:1527019968142};\\\", \\\"{x:1440,y:888,t:1527019968191};\\\", \\\"{x:1440,y:887,t:1527019968231};\\\", \\\"{x:1439,y:886,t:1527019968255};\\\", \\\"{x:1438,y:885,t:1527019968630};\\\", \\\"{x:1437,y:884,t:1527019968647};\\\", \\\"{x:1437,y:883,t:1527019968671};\\\", \\\"{x:1436,y:883,t:1527019968687};\\\", \\\"{x:1436,y:882,t:1527019968703};\\\", \\\"{x:1435,y:881,t:1527019968743};\\\", \\\"{x:1434,y:880,t:1527019968767};\\\", \\\"{x:1434,y:879,t:1527019968791};\\\", \\\"{x:1433,y:878,t:1527019968839};\\\", \\\"{x:1433,y:877,t:1527019968879};\\\", \\\"{x:1432,y:877,t:1527019968893};\\\", \\\"{x:1432,y:876,t:1527019968909};\\\", \\\"{x:1431,y:876,t:1527019968926};\\\", \\\"{x:1430,y:875,t:1527019968951};\\\", \\\"{x:1430,y:874,t:1527019969206};\\\", \\\"{x:1428,y:872,t:1527019969214};\\\", \\\"{x:1428,y:871,t:1527019969225};\\\", \\\"{x:1425,y:864,t:1527019969242};\\\", \\\"{x:1424,y:862,t:1527019969258};\\\", \\\"{x:1423,y:859,t:1527019969275};\\\", \\\"{x:1421,y:857,t:1527019969293};\\\", \\\"{x:1421,y:856,t:1527019969309};\\\", \\\"{x:1420,y:855,t:1527019969326};\\\", \\\"{x:1420,y:853,t:1527019969342};\\\", \\\"{x:1418,y:849,t:1527019969359};\\\", \\\"{x:1417,y:846,t:1527019969376};\\\", \\\"{x:1415,y:842,t:1527019969393};\\\", \\\"{x:1414,y:841,t:1527019969408};\\\", \\\"{x:1414,y:839,t:1527019969425};\\\", \\\"{x:1413,y:838,t:1527019969442};\\\", \\\"{x:1413,y:837,t:1527019969459};\\\", \\\"{x:1412,y:835,t:1527019969476};\\\", \\\"{x:1410,y:832,t:1527019969495};\\\", \\\"{x:1410,y:830,t:1527019969509};\\\", \\\"{x:1408,y:827,t:1527019969526};\\\", \\\"{x:1406,y:822,t:1527019969542};\\\", \\\"{x:1404,y:819,t:1527019969559};\\\", \\\"{x:1402,y:815,t:1527019969576};\\\", \\\"{x:1400,y:813,t:1527019969593};\\\", \\\"{x:1400,y:811,t:1527019969609};\\\", \\\"{x:1399,y:808,t:1527019969626};\\\", \\\"{x:1397,y:806,t:1527019969643};\\\", \\\"{x:1397,y:805,t:1527019969659};\\\", \\\"{x:1397,y:804,t:1527019970935};\\\", \\\"{x:1396,y:801,t:1527019970943};\\\", \\\"{x:1395,y:800,t:1527019970960};\\\", \\\"{x:1394,y:797,t:1527019970977};\\\", \\\"{x:1394,y:796,t:1527019970999};\\\", \\\"{x:1393,y:795,t:1527019971010};\\\", \\\"{x:1393,y:794,t:1527019971118};\\\", \\\"{x:1393,y:793,t:1527019971231};\\\", \\\"{x:1392,y:792,t:1527019971243};\\\", \\\"{x:1392,y:791,t:1527019971335};\\\", \\\"{x:1391,y:789,t:1527019971366};\\\", \\\"{x:1391,y:788,t:1527019971647};\\\", \\\"{x:1390,y:788,t:1527019971661};\\\", \\\"{x:1390,y:787,t:1527019971807};\\\", \\\"{x:1389,y:787,t:1527019971814};\\\", \\\"{x:1388,y:786,t:1527019971902};\\\", \\\"{x:1388,y:785,t:1527019971983};\\\", \\\"{x:1388,y:784,t:1527019972006};\\\", \\\"{x:1387,y:783,t:1527019972030};\\\", \\\"{x:1387,y:782,t:1527019972043};\\\", \\\"{x:1387,y:781,t:1527019972079};\\\", \\\"{x:1386,y:780,t:1527019972093};\\\", \\\"{x:1386,y:779,t:1527019972110};\\\", \\\"{x:1385,y:779,t:1527019972126};\\\", \\\"{x:1385,y:778,t:1527019972158};\\\", \\\"{x:1385,y:777,t:1527019972166};\\\", \\\"{x:1384,y:776,t:1527019972177};\\\", \\\"{x:1382,y:774,t:1527019972193};\\\", \\\"{x:1381,y:772,t:1527019972210};\\\", \\\"{x:1380,y:770,t:1527019972227};\\\", \\\"{x:1379,y:769,t:1527019972243};\\\", \\\"{x:1378,y:768,t:1527019972263};\\\", \\\"{x:1378,y:767,t:1527019972278};\\\", \\\"{x:1377,y:766,t:1527019972294};\\\", \\\"{x:1375,y:765,t:1527019972311};\\\", \\\"{x:1373,y:762,t:1527019972327};\\\", \\\"{x:1372,y:759,t:1527019972344};\\\", \\\"{x:1369,y:755,t:1527019972360};\\\", \\\"{x:1366,y:749,t:1527019972377};\\\", \\\"{x:1363,y:745,t:1527019972394};\\\", \\\"{x:1360,y:741,t:1527019972410};\\\", \\\"{x:1357,y:735,t:1527019972427};\\\", \\\"{x:1354,y:729,t:1527019972444};\\\", \\\"{x:1348,y:718,t:1527019972460};\\\", \\\"{x:1342,y:707,t:1527019972477};\\\", \\\"{x:1335,y:694,t:1527019972495};\\\", \\\"{x:1333,y:691,t:1527019972511};\\\", \\\"{x:1332,y:687,t:1527019972527};\\\", \\\"{x:1330,y:684,t:1527019972544};\\\", \\\"{x:1327,y:679,t:1527019972560};\\\", \\\"{x:1323,y:673,t:1527019972577};\\\", \\\"{x:1322,y:670,t:1527019972594};\\\", \\\"{x:1321,y:666,t:1527019972610};\\\", \\\"{x:1319,y:664,t:1527019972628};\\\", \\\"{x:1319,y:662,t:1527019972823};\\\", \\\"{x:1317,y:658,t:1527019972830};\\\", \\\"{x:1315,y:654,t:1527019972844};\\\", \\\"{x:1313,y:646,t:1527019972860};\\\", \\\"{x:1310,y:641,t:1527019972877};\\\", \\\"{x:1308,y:637,t:1527019972894};\\\", \\\"{x:1305,y:633,t:1527019972910};\\\", \\\"{x:1303,y:628,t:1527019972927};\\\", \\\"{x:1302,y:624,t:1527019972944};\\\", \\\"{x:1300,y:622,t:1527019972960};\\\", \\\"{x:1299,y:620,t:1527019972977};\\\", \\\"{x:1298,y:618,t:1527019972995};\\\", \\\"{x:1297,y:614,t:1527019973010};\\\", \\\"{x:1295,y:610,t:1527019973027};\\\", \\\"{x:1292,y:605,t:1527019973044};\\\", \\\"{x:1288,y:593,t:1527019973061};\\\", \\\"{x:1280,y:573,t:1527019973077};\\\", \\\"{x:1269,y:548,t:1527019973095};\\\", \\\"{x:1265,y:539,t:1527019973110};\\\", \\\"{x:1264,y:535,t:1527019973127};\\\", \\\"{x:1263,y:534,t:1527019973144};\\\", \\\"{x:1264,y:542,t:1527019975887};\\\", \\\"{x:1273,y:559,t:1527019975894};\\\", \\\"{x:1290,y:586,t:1527019975911};\\\", \\\"{x:1299,y:601,t:1527019975927};\\\", \\\"{x:1305,y:609,t:1527019975945};\\\", \\\"{x:1307,y:613,t:1527019975961};\\\", \\\"{x:1309,y:617,t:1527019975978};\\\", \\\"{x:1312,y:621,t:1527019975995};\\\", \\\"{x:1317,y:633,t:1527019976011};\\\", \\\"{x:1328,y:652,t:1527019976028};\\\", \\\"{x:1338,y:668,t:1527019976045};\\\", \\\"{x:1350,y:685,t:1527019976061};\\\", \\\"{x:1366,y:705,t:1527019976079};\\\", \\\"{x:1372,y:713,t:1527019976094};\\\", \\\"{x:1379,y:723,t:1527019976111};\\\", \\\"{x:1388,y:739,t:1527019976128};\\\", \\\"{x:1399,y:758,t:1527019976145};\\\", \\\"{x:1410,y:778,t:1527019976161};\\\", \\\"{x:1422,y:798,t:1527019976178};\\\", \\\"{x:1436,y:819,t:1527019976195};\\\", \\\"{x:1447,y:832,t:1527019976211};\\\", \\\"{x:1452,y:840,t:1527019976228};\\\", \\\"{x:1454,y:844,t:1527019976246};\\\", \\\"{x:1455,y:845,t:1527019976262};\\\", \\\"{x:1459,y:857,t:1527019976278};\\\", \\\"{x:1464,y:871,t:1527019976295};\\\", \\\"{x:1470,y:885,t:1527019976311};\\\", \\\"{x:1475,y:900,t:1527019976329};\\\", \\\"{x:1480,y:914,t:1527019976345};\\\", \\\"{x:1484,y:927,t:1527019976361};\\\", \\\"{x:1489,y:945,t:1527019976378};\\\", \\\"{x:1494,y:961,t:1527019976396};\\\", \\\"{x:1496,y:974,t:1527019976412};\\\", \\\"{x:1500,y:986,t:1527019976429};\\\", \\\"{x:1504,y:998,t:1527019976445};\\\", \\\"{x:1505,y:1005,t:1527019976462};\\\", \\\"{x:1508,y:1013,t:1527019976479};\\\", \\\"{x:1509,y:1014,t:1527019976518};\\\", \\\"{x:1508,y:1008,t:1527019976639};\\\", \\\"{x:1505,y:997,t:1527019976647};\\\", \\\"{x:1503,y:992,t:1527019976661};\\\", \\\"{x:1503,y:990,t:1527019976678};\\\", \\\"{x:1502,y:990,t:1527019976695};\\\", \\\"{x:1502,y:988,t:1527019976711};\\\", \\\"{x:1501,y:987,t:1527019976728};\\\", \\\"{x:1500,y:983,t:1527019976746};\\\", \\\"{x:1499,y:981,t:1527019976774};\\\", \\\"{x:1498,y:977,t:1527019976791};\\\", \\\"{x:1498,y:976,t:1527019976799};\\\", \\\"{x:1496,y:974,t:1527019976812};\\\", \\\"{x:1494,y:968,t:1527019976829};\\\", \\\"{x:1491,y:964,t:1527019976846};\\\", \\\"{x:1488,y:958,t:1527019976863};\\\", \\\"{x:1487,y:957,t:1527019976878};\\\", \\\"{x:1487,y:955,t:1527019976895};\\\", \\\"{x:1486,y:955,t:1527019976913};\\\", \\\"{x:1485,y:954,t:1527019977527};\\\", \\\"{x:1485,y:944,t:1527019977545};\\\", \\\"{x:1487,y:941,t:1527019989423};\\\", \\\"{x:1490,y:922,t:1527019989433};\\\", \\\"{x:1497,y:859,t:1527019989449};\\\", \\\"{x:1497,y:795,t:1527019989466};\\\", \\\"{x:1499,y:714,t:1527019989483};\\\", \\\"{x:1508,y:639,t:1527019989499};\\\", \\\"{x:1519,y:561,t:1527019989516};\\\", \\\"{x:1529,y:486,t:1527019989533};\\\", \\\"{x:1534,y:415,t:1527019989549};\\\", \\\"{x:1534,y:304,t:1527019989566};\\\", \\\"{x:1532,y:244,t:1527019989582};\\\", \\\"{x:1524,y:188,t:1527019989598};\\\", \\\"{x:1517,y:143,t:1527019989616};\\\", \\\"{x:1511,y:98,t:1527019989633};\\\", \\\"{x:1510,y:58,t:1527019989649};\\\", \\\"{x:1510,y:30,t:1527019989666};\\\", \\\"{x:1510,y:15,t:1527019989683};\\\", \\\"{x:1509,y:11,t:1527019989699};\\\", \\\"{x:1508,y:10,t:1527019989718};\\\", \\\"{x:1506,y:14,t:1527019989733};\\\", \\\"{x:1499,y:39,t:1527019989748};\\\", \\\"{x:1487,y:82,t:1527019989766};\\\", \\\"{x:1480,y:109,t:1527019989782};\\\", \\\"{x:1475,y:129,t:1527019989798};\\\", \\\"{x:1470,y:142,t:1527019989816};\\\", \\\"{x:1469,y:146,t:1527019989832};\\\", \\\"{x:1468,y:148,t:1527019989848};\\\", \\\"{x:1467,y:153,t:1527019989865};\\\", \\\"{x:1467,y:161,t:1527019989882};\\\", \\\"{x:1466,y:175,t:1527019989898};\\\", \\\"{x:1465,y:189,t:1527019989915};\\\", \\\"{x:1463,y:195,t:1527019989933};\\\", \\\"{x:1463,y:199,t:1527019989949};\\\", \\\"{x:1463,y:201,t:1527019989965};\\\", \\\"{x:1463,y:210,t:1527019989982};\\\", \\\"{x:1463,y:229,t:1527019989999};\\\", \\\"{x:1462,y:244,t:1527019990015};\\\", \\\"{x:1461,y:246,t:1527019990033};\\\", \\\"{x:1465,y:246,t:1527019990167};\\\", \\\"{x:1486,y:236,t:1527019990182};\\\", \\\"{x:1491,y:225,t:1527019990200};\\\", \\\"{x:1491,y:221,t:1527019990216};\\\", \\\"{x:1487,y:221,t:1527019990233};\\\", \\\"{x:1486,y:221,t:1527019990250};\\\", \\\"{x:1487,y:229,t:1527019991159};\\\", \\\"{x:1487,y:232,t:1527019991166};\\\", \\\"{x:1487,y:252,t:1527019991182};\\\", \\\"{x:1487,y:304,t:1527019991200};\\\", \\\"{x:1480,y:368,t:1527019991217};\\\", \\\"{x:1456,y:416,t:1527019991232};\\\", \\\"{x:1434,y:447,t:1527019991250};\\\", \\\"{x:1422,y:463,t:1527019991266};\\\", \\\"{x:1418,y:480,t:1527019991282};\\\", \\\"{x:1408,y:512,t:1527019991299};\\\", \\\"{x:1377,y:578,t:1527019991316};\\\", \\\"{x:1346,y:671,t:1527019991332};\\\", \\\"{x:1336,y:846,t:1527019991350};\\\", \\\"{x:1372,y:944,t:1527019991366};\\\", \\\"{x:1388,y:1042,t:1527019991382};\\\", \\\"{x:1390,y:1139,t:1527019991400};\\\", \\\"{x:1382,y:1199,t:1527019991417};\\\", \\\"{x:1370,y:1199,t:1527019991432};\\\", \\\"{x:1371,y:1199,t:1527019991510};\\\", \\\"{x:1374,y:1198,t:1527019991518};\\\", \\\"{x:1383,y:1193,t:1527019991531};\\\", \\\"{x:1426,y:1164,t:1527019991548};\\\", \\\"{x:1506,y:1109,t:1527019991563};\\\", \\\"{x:1547,y:1069,t:1527019991581};\\\", \\\"{x:1557,y:1044,t:1527019991597};\\\", \\\"{x:1558,y:1027,t:1527019991614};\\\", \\\"{x:1550,y:1016,t:1527019991630};\\\", \\\"{x:1533,y:1005,t:1527019991647};\\\", \\\"{x:1515,y:995,t:1527019991664};\\\", \\\"{x:1496,y:989,t:1527019991680};\\\", \\\"{x:1490,y:989,t:1527019991697};\\\", \\\"{x:1489,y:987,t:1527019991735};\\\", \\\"{x:1489,y:980,t:1527019991747};\\\", \\\"{x:1484,y:972,t:1527019991764};\\\", \\\"{x:1483,y:970,t:1527019991781};\\\", \\\"{x:1482,y:970,t:1527019991796};\\\", \\\"{x:1481,y:970,t:1527019991814};\\\", \\\"{x:1480,y:970,t:1527019991870};\\\", \\\"{x:1480,y:967,t:1527019991880};\\\", \\\"{x:1482,y:957,t:1527019991896};\\\", \\\"{x:1482,y:954,t:1527019991914};\\\", \\\"{x:1482,y:953,t:1527019991930};\\\", \\\"{x:1481,y:953,t:1527019992063};\\\", \\\"{x:1476,y:953,t:1527019992080};\\\", \\\"{x:1472,y:953,t:1527019992097};\\\", \\\"{x:1471,y:953,t:1527019992114};\\\", \\\"{x:1471,y:952,t:1527019992247};\\\", \\\"{x:1471,y:950,t:1527019992264};\\\", \\\"{x:1471,y:947,t:1527019992280};\\\", \\\"{x:1472,y:945,t:1527019992298};\\\", \\\"{x:1473,y:940,t:1527019992314};\\\", \\\"{x:1474,y:940,t:1527019992330};\\\", \\\"{x:1474,y:938,t:1527019992429};\\\", \\\"{x:1474,y:934,t:1527019992445};\\\", \\\"{x:1474,y:931,t:1527019992462};\\\", \\\"{x:1474,y:926,t:1527019992478};\\\", \\\"{x:1474,y:924,t:1527019992495};\\\", \\\"{x:1473,y:921,t:1527019992512};\\\", \\\"{x:1471,y:915,t:1527019992528};\\\", \\\"{x:1471,y:911,t:1527019992545};\\\", \\\"{x:1470,y:907,t:1527019992562};\\\", \\\"{x:1470,y:904,t:1527019992578};\\\", \\\"{x:1470,y:901,t:1527019992595};\\\", \\\"{x:1470,y:899,t:1527019992611};\\\", \\\"{x:1470,y:894,t:1527019992628};\\\", \\\"{x:1470,y:889,t:1527019992645};\\\", \\\"{x:1470,y:884,t:1527019992661};\\\", \\\"{x:1470,y:881,t:1527019992678};\\\", \\\"{x:1470,y:878,t:1527019992695};\\\", \\\"{x:1469,y:877,t:1527019992711};\\\", \\\"{x:1469,y:874,t:1527019992728};\\\", \\\"{x:1469,y:870,t:1527019992745};\\\", \\\"{x:1469,y:866,t:1527019992761};\\\", \\\"{x:1469,y:863,t:1527019992778};\\\", \\\"{x:1469,y:860,t:1527019992795};\\\", \\\"{x:1469,y:857,t:1527019992811};\\\", \\\"{x:1469,y:854,t:1527019992828};\\\", \\\"{x:1469,y:851,t:1527019992845};\\\", \\\"{x:1469,y:844,t:1527019992861};\\\", \\\"{x:1469,y:838,t:1527019992878};\\\", \\\"{x:1469,y:835,t:1527019992895};\\\", \\\"{x:1469,y:832,t:1527019992911};\\\", \\\"{x:1469,y:829,t:1527019992928};\\\", \\\"{x:1469,y:826,t:1527019992945};\\\", \\\"{x:1469,y:825,t:1527019992961};\\\", \\\"{x:1469,y:823,t:1527019992978};\\\", \\\"{x:1469,y:822,t:1527019993052};\\\", \\\"{x:1470,y:822,t:1527019993085};\\\", \\\"{x:1470,y:821,t:1527019993125};\\\", \\\"{x:1471,y:821,t:1527019993140};\\\", \\\"{x:1472,y:821,t:1527019993148};\\\", \\\"{x:1473,y:820,t:1527019993161};\\\", \\\"{x:1474,y:819,t:1527019993178};\\\", \\\"{x:1475,y:819,t:1527019993196};\\\", \\\"{x:1476,y:820,t:1527019994597};\\\", \\\"{x:1477,y:823,t:1527019994611};\\\", \\\"{x:1478,y:828,t:1527019994629};\\\", \\\"{x:1478,y:835,t:1527019994644};\\\", \\\"{x:1481,y:840,t:1527019994661};\\\", \\\"{x:1481,y:839,t:1527019995149};\\\", \\\"{x:1481,y:838,t:1527019995160};\\\", \\\"{x:1481,y:833,t:1527019995178};\\\", \\\"{x:1481,y:831,t:1527019995194};\\\", \\\"{x:1481,y:828,t:1527019995210};\\\", \\\"{x:1481,y:826,t:1527019995227};\\\", \\\"{x:1481,y:825,t:1527019995252};\\\", \\\"{x:1481,y:822,t:1527019995573};\\\", \\\"{x:1481,y:818,t:1527019995580};\\\", \\\"{x:1481,y:816,t:1527019995594};\\\", \\\"{x:1481,y:811,t:1527019995610};\\\", \\\"{x:1481,y:809,t:1527019995627};\\\", \\\"{x:1481,y:807,t:1527019995643};\\\", \\\"{x:1481,y:806,t:1527019995660};\\\", \\\"{x:1481,y:805,t:1527019995692};\\\", \\\"{x:1481,y:804,t:1527019995716};\\\", \\\"{x:1481,y:803,t:1527019995727};\\\", \\\"{x:1481,y:802,t:1527019995743};\\\", \\\"{x:1481,y:801,t:1527019995760};\\\", \\\"{x:1481,y:800,t:1527019995777};\\\", \\\"{x:1481,y:799,t:1527019995793};\\\", \\\"{x:1481,y:798,t:1527019995810};\\\", \\\"{x:1480,y:797,t:1527019995827};\\\", \\\"{x:1480,y:796,t:1527019995852};\\\", \\\"{x:1480,y:795,t:1527019995908};\\\", \\\"{x:1479,y:793,t:1527019995927};\\\", \\\"{x:1479,y:792,t:1527019995943};\\\", \\\"{x:1478,y:789,t:1527019995960};\\\", \\\"{x:1478,y:788,t:1527019995989};\\\", \\\"{x:1478,y:787,t:1527019996005};\\\", \\\"{x:1477,y:786,t:1527019996028};\\\", \\\"{x:1477,y:784,t:1527019996077};\\\", \\\"{x:1477,y:783,t:1527019996133};\\\", \\\"{x:1477,y:781,t:1527019996156};\\\", \\\"{x:1477,y:780,t:1527019996181};\\\", \\\"{x:1477,y:779,t:1527019996220};\\\", \\\"{x:1477,y:778,t:1527019996228};\\\", \\\"{x:1477,y:777,t:1527019996244};\\\", \\\"{x:1476,y:776,t:1527019996260};\\\", \\\"{x:1476,y:775,t:1527019996276};\\\", \\\"{x:1476,y:774,t:1527019996316};\\\", \\\"{x:1476,y:772,t:1527019996357};\\\", \\\"{x:1476,y:771,t:1527019996388};\\\", \\\"{x:1476,y:769,t:1527019996621};\\\", \\\"{x:1476,y:768,t:1527019996636};\\\", \\\"{x:1476,y:766,t:1527019996644};\\\", \\\"{x:1476,y:765,t:1527019996660};\\\", \\\"{x:1476,y:759,t:1527019996676};\\\", \\\"{x:1476,y:755,t:1527019996693};\\\", \\\"{x:1476,y:751,t:1527019996710};\\\", \\\"{x:1475,y:749,t:1527019996726};\\\", \\\"{x:1475,y:748,t:1527019996743};\\\", \\\"{x:1475,y:746,t:1527019996760};\\\", \\\"{x:1474,y:745,t:1527019996776};\\\", \\\"{x:1474,y:741,t:1527019996793};\\\", \\\"{x:1473,y:734,t:1527019996810};\\\", \\\"{x:1471,y:732,t:1527019996825};\\\", \\\"{x:1471,y:730,t:1527019996843};\\\", \\\"{x:1471,y:729,t:1527019996915};\\\", \\\"{x:1471,y:728,t:1527019996932};\\\", \\\"{x:1470,y:727,t:1527019996943};\\\", \\\"{x:1469,y:725,t:1527019997053};\\\", \\\"{x:1469,y:724,t:1527019997141};\\\", \\\"{x:1469,y:723,t:1527019997229};\\\", \\\"{x:1469,y:722,t:1527019997244};\\\", \\\"{x:1469,y:721,t:1527019997260};\\\", \\\"{x:1468,y:721,t:1527019997277};\\\", \\\"{x:1468,y:720,t:1527019997372};\\\", \\\"{x:1468,y:719,t:1527019997429};\\\", \\\"{x:1468,y:718,t:1527019998077};\\\", \\\"{x:1468,y:717,t:1527019998092};\\\", \\\"{x:1468,y:716,t:1527019998116};\\\", \\\"{x:1468,y:715,t:1527019998197};\\\", \\\"{x:1468,y:728,t:1527019999725};\\\", \\\"{x:1468,y:771,t:1527019999742};\\\", \\\"{x:1483,y:837,t:1527019999759};\\\", \\\"{x:1497,y:890,t:1527019999775};\\\", \\\"{x:1503,y:919,t:1527019999793};\\\", \\\"{x:1508,y:941,t:1527019999808};\\\", \\\"{x:1511,y:955,t:1527019999826};\\\", \\\"{x:1511,y:960,t:1527019999842};\\\", \\\"{x:1511,y:961,t:1527019999858};\\\", \\\"{x:1511,y:962,t:1527019999875};\\\", \\\"{x:1511,y:978,t:1527019999892};\\\", \\\"{x:1510,y:998,t:1527019999908};\\\", \\\"{x:1510,y:1014,t:1527019999925};\\\", \\\"{x:1512,y:1023,t:1527019999942};\\\", \\\"{x:1512,y:1024,t:1527019999958};\\\", \\\"{x:1514,y:1024,t:1527019999988};\\\", \\\"{x:1516,y:1024,t:1527019999996};\\\", \\\"{x:1518,y:1022,t:1527020000008};\\\", \\\"{x:1524,y:1013,t:1527020000025};\\\", \\\"{x:1529,y:996,t:1527020000041};\\\", \\\"{x:1531,y:980,t:1527020000059};\\\", \\\"{x:1533,y:966,t:1527020000076};\\\", \\\"{x:1534,y:960,t:1527020000092};\\\", \\\"{x:1534,y:959,t:1527020000108};\\\", \\\"{x:1534,y:958,t:1527020000237};\\\", \\\"{x:1528,y:958,t:1527020000244};\\\", \\\"{x:1518,y:958,t:1527020000259};\\\", \\\"{x:1496,y:958,t:1527020000275};\\\", \\\"{x:1469,y:958,t:1527020000291};\\\", \\\"{x:1449,y:958,t:1527020000308};\\\", \\\"{x:1450,y:958,t:1527020000485};\\\", \\\"{x:1456,y:961,t:1527020000492};\\\", \\\"{x:1466,y:965,t:1527020000508};\\\", \\\"{x:1472,y:965,t:1527020000526};\\\", \\\"{x:1474,y:966,t:1527020000541};\\\", \\\"{x:1475,y:966,t:1527020000559};\\\", \\\"{x:1472,y:966,t:1527020004876};\\\", \\\"{x:1456,y:966,t:1527020004889};\\\", \\\"{x:1417,y:966,t:1527020004907};\\\", \\\"{x:1394,y:966,t:1527020004923};\\\", \\\"{x:1380,y:966,t:1527020004940};\\\", \\\"{x:1377,y:968,t:1527020004957};\\\", \\\"{x:1375,y:968,t:1527020004973};\\\", \\\"{x:1373,y:968,t:1527020004990};\\\", \\\"{x:1369,y:968,t:1527020005007};\\\", \\\"{x:1367,y:969,t:1527020005024};\\\", \\\"{x:1366,y:969,t:1527020005039};\\\", \\\"{x:1365,y:969,t:1527020005068};\\\", \\\"{x:1364,y:969,t:1527020005300};\\\", \\\"{x:1362,y:971,t:1527020005308};\\\", \\\"{x:1359,y:972,t:1527020005324};\\\", \\\"{x:1356,y:972,t:1527020005339};\\\", \\\"{x:1355,y:972,t:1527020005356};\\\", \\\"{x:1353,y:973,t:1527020005373};\\\", \\\"{x:1351,y:974,t:1527020005389};\\\", \\\"{x:1350,y:974,t:1527020005406};\\\", \\\"{x:1350,y:973,t:1527020005700};\\\", \\\"{x:1350,y:968,t:1527020005708};\\\", \\\"{x:1351,y:964,t:1527020005723};\\\", \\\"{x:1354,y:957,t:1527020005739};\\\", \\\"{x:1356,y:952,t:1527020005756};\\\", \\\"{x:1357,y:950,t:1527020005773};\\\", \\\"{x:1358,y:948,t:1527020005789};\\\", \\\"{x:1359,y:946,t:1527020005808};\\\", \\\"{x:1360,y:943,t:1527020005823};\\\", \\\"{x:1364,y:938,t:1527020005839};\\\", \\\"{x:1366,y:932,t:1527020005856};\\\", \\\"{x:1369,y:927,t:1527020005872};\\\", \\\"{x:1371,y:923,t:1527020005889};\\\", \\\"{x:1373,y:918,t:1527020005906};\\\", \\\"{x:1376,y:914,t:1527020005923};\\\", \\\"{x:1378,y:904,t:1527020005940};\\\", \\\"{x:1379,y:893,t:1527020005957};\\\", \\\"{x:1380,y:883,t:1527020005973};\\\", \\\"{x:1381,y:872,t:1527020005990};\\\", \\\"{x:1383,y:863,t:1527020006007};\\\", \\\"{x:1385,y:856,t:1527020006023};\\\", \\\"{x:1386,y:853,t:1527020006039};\\\", \\\"{x:1389,y:847,t:1527020006057};\\\", \\\"{x:1390,y:842,t:1527020006073};\\\", \\\"{x:1393,y:837,t:1527020006090};\\\", \\\"{x:1395,y:833,t:1527020006105};\\\", \\\"{x:1399,y:829,t:1527020006123};\\\", \\\"{x:1405,y:823,t:1527020006139};\\\", \\\"{x:1412,y:810,t:1527020006156};\\\", \\\"{x:1419,y:800,t:1527020006172};\\\", \\\"{x:1423,y:789,t:1527020006189};\\\", \\\"{x:1425,y:783,t:1527020006207};\\\", \\\"{x:1429,y:775,t:1527020006223};\\\", \\\"{x:1435,y:762,t:1527020006239};\\\", \\\"{x:1442,y:744,t:1527020006256};\\\", \\\"{x:1447,y:736,t:1527020006272};\\\", \\\"{x:1449,y:732,t:1527020006289};\\\", \\\"{x:1451,y:726,t:1527020006305};\\\", \\\"{x:1453,y:719,t:1527020006322};\\\", \\\"{x:1456,y:716,t:1527020006340};\\\", \\\"{x:1457,y:714,t:1527020006355};\\\", \\\"{x:1460,y:712,t:1527020006372};\\\", \\\"{x:1463,y:708,t:1527020006389};\\\", \\\"{x:1464,y:703,t:1527020006406};\\\", \\\"{x:1464,y:697,t:1527020006423};\\\", \\\"{x:1464,y:693,t:1527020006439};\\\", \\\"{x:1464,y:688,t:1527020006455};\\\", \\\"{x:1464,y:685,t:1527020006472};\\\", \\\"{x:1462,y:678,t:1527020006489};\\\", \\\"{x:1460,y:674,t:1527020006505};\\\", \\\"{x:1457,y:671,t:1527020006521};\\\", \\\"{x:1456,y:669,t:1527020006539};\\\", \\\"{x:1455,y:669,t:1527020006571};\\\", \\\"{x:1454,y:669,t:1527020006579};\\\", \\\"{x:1453,y:668,t:1527020006611};\\\", \\\"{x:1452,y:667,t:1527020006627};\\\", \\\"{x:1450,y:665,t:1527020006716};\\\", \\\"{x:1448,y:660,t:1527020006724};\\\", \\\"{x:1446,y:655,t:1527020006739};\\\", \\\"{x:1441,y:649,t:1527020006755};\\\", \\\"{x:1441,y:647,t:1527020006773};\\\", \\\"{x:1440,y:646,t:1527020006790};\\\", \\\"{x:1440,y:640,t:1527020006807};\\\", \\\"{x:1440,y:637,t:1527020006823};\\\", \\\"{x:1440,y:635,t:1527020006838};\\\", \\\"{x:1440,y:633,t:1527020006856};\\\", \\\"{x:1440,y:632,t:1527020006875};\\\", \\\"{x:1440,y:631,t:1527020006891};\\\", \\\"{x:1440,y:630,t:1527020006931};\\\", \\\"{x:1441,y:629,t:1527020012397};\\\", \\\"{x:1441,y:630,t:1527020012533};\\\", \\\"{x:1451,y:664,t:1527020012541};\\\", \\\"{x:1464,y:705,t:1527020012554};\\\", \\\"{x:1503,y:791,t:1527020012570};\\\", \\\"{x:1532,y:845,t:1527020012587};\\\", \\\"{x:1549,y:888,t:1527020012604};\\\", \\\"{x:1555,y:908,t:1527020012620};\\\", \\\"{x:1555,y:936,t:1527020012636};\\\", \\\"{x:1555,y:989,t:1527020012654};\\\", \\\"{x:1555,y:1026,t:1527020012669};\\\", \\\"{x:1553,y:1045,t:1527020012687};\\\", \\\"{x:1551,y:1054,t:1527020012704};\\\", \\\"{x:1550,y:1057,t:1527020012720};\\\", \\\"{x:1549,y:1058,t:1527020012764};\\\", \\\"{x:1543,y:1058,t:1527020012772};\\\", \\\"{x:1534,y:1057,t:1527020012786};\\\", \\\"{x:1517,y:1050,t:1527020012804};\\\", \\\"{x:1510,y:1046,t:1527020012820};\\\", \\\"{x:1502,y:1042,t:1527020012837};\\\", \\\"{x:1499,y:1039,t:1527020012854};\\\", \\\"{x:1498,y:1039,t:1527020012870};\\\", \\\"{x:1498,y:1038,t:1527020012908};\\\", \\\"{x:1498,y:1035,t:1527020012919};\\\", \\\"{x:1499,y:1017,t:1527020012937};\\\", \\\"{x:1500,y:1007,t:1527020012952};\\\", \\\"{x:1502,y:1001,t:1527020012970};\\\", \\\"{x:1502,y:999,t:1527020012987};\\\", \\\"{x:1502,y:996,t:1527020013003};\\\", \\\"{x:1502,y:990,t:1527020013019};\\\", \\\"{x:1502,y:984,t:1527020013037};\\\", \\\"{x:1502,y:982,t:1527020013053};\\\", \\\"{x:1502,y:978,t:1527020013070};\\\", \\\"{x:1502,y:972,t:1527020013087};\\\", \\\"{x:1502,y:967,t:1527020013102};\\\", \\\"{x:1502,y:964,t:1527020013121};\\\", \\\"{x:1502,y:962,t:1527020013137};\\\", \\\"{x:1502,y:960,t:1527020013153};\\\", \\\"{x:1502,y:955,t:1527020013170};\\\", \\\"{x:1500,y:945,t:1527020013187};\\\", \\\"{x:1493,y:918,t:1527020013203};\\\", \\\"{x:1484,y:886,t:1527020013220};\\\", \\\"{x:1481,y:874,t:1527020013237};\\\", \\\"{x:1481,y:868,t:1527020013253};\\\", \\\"{x:1481,y:862,t:1527020013269};\\\", \\\"{x:1481,y:855,t:1527020013287};\\\", \\\"{x:1481,y:849,t:1527020013302};\\\", \\\"{x:1484,y:842,t:1527020013320};\\\", \\\"{x:1486,y:833,t:1527020013336};\\\", \\\"{x:1487,y:819,t:1527020013353};\\\", \\\"{x:1487,y:812,t:1527020013370};\\\", \\\"{x:1487,y:808,t:1527020013387};\\\", \\\"{x:1487,y:807,t:1527020013403};\\\", \\\"{x:1487,y:809,t:1527020013669};\\\", \\\"{x:1487,y:813,t:1527020013676};\\\", \\\"{x:1487,y:816,t:1527020013687};\\\", \\\"{x:1486,y:822,t:1527020013703};\\\", \\\"{x:1486,y:826,t:1527020013719};\\\", \\\"{x:1486,y:827,t:1527020013736};\\\", \\\"{x:1486,y:828,t:1527020013752};\\\", \\\"{x:1486,y:829,t:1527020013771};\\\", \\\"{x:1486,y:826,t:1527020014414};\\\", \\\"{x:1487,y:823,t:1527020014418};\\\", \\\"{x:1487,y:819,t:1527020014435};\\\", \\\"{x:1487,y:815,t:1527020014453};\\\", \\\"{x:1487,y:811,t:1527020014470};\\\", \\\"{x:1487,y:808,t:1527020014485};\\\", \\\"{x:1487,y:806,t:1527020014502};\\\", \\\"{x:1487,y:804,t:1527020014518};\\\", \\\"{x:1487,y:802,t:1527020014536};\\\", \\\"{x:1487,y:799,t:1527020014552};\\\", \\\"{x:1487,y:796,t:1527020014568};\\\", \\\"{x:1487,y:793,t:1527020014585};\\\", \\\"{x:1487,y:789,t:1527020014603};\\\", \\\"{x:1487,y:785,t:1527020014618};\\\", \\\"{x:1487,y:778,t:1527020014636};\\\", \\\"{x:1486,y:772,t:1527020014652};\\\", \\\"{x:1486,y:767,t:1527020014669};\\\", \\\"{x:1485,y:762,t:1527020014685};\\\", \\\"{x:1485,y:756,t:1527020014703};\\\", \\\"{x:1484,y:750,t:1527020014719};\\\", \\\"{x:1482,y:742,t:1527020014735};\\\", \\\"{x:1480,y:734,t:1527020014752};\\\", \\\"{x:1479,y:728,t:1527020014768};\\\", \\\"{x:1478,y:721,t:1527020014786};\\\", \\\"{x:1476,y:712,t:1527020014803};\\\", \\\"{x:1474,y:706,t:1527020014819};\\\", \\\"{x:1471,y:695,t:1527020014835};\\\", \\\"{x:1471,y:687,t:1527020014852};\\\", \\\"{x:1468,y:679,t:1527020014869};\\\", \\\"{x:1468,y:675,t:1527020014886};\\\", \\\"{x:1468,y:671,t:1527020014903};\\\", \\\"{x:1468,y:670,t:1527020014919};\\\", \\\"{x:1467,y:668,t:1527020014936};\\\", \\\"{x:1467,y:666,t:1527020014953};\\\", \\\"{x:1467,y:665,t:1527020014972};\\\", \\\"{x:1466,y:664,t:1527020014988};\\\", \\\"{x:1465,y:663,t:1527020015588};\\\", \\\"{x:1463,y:661,t:1527020015602};\\\", \\\"{x:1459,y:652,t:1527020015619};\\\", \\\"{x:1455,y:640,t:1527020015636};\\\", \\\"{x:1453,y:632,t:1527020015652};\\\", \\\"{x:1451,y:627,t:1527020015668};\\\", \\\"{x:1448,y:619,t:1527020015687};\\\", \\\"{x:1447,y:611,t:1527020015701};\\\", \\\"{x:1442,y:597,t:1527020015719};\\\", \\\"{x:1436,y:573,t:1527020015736};\\\", \\\"{x:1422,y:542,t:1527020015752};\\\", \\\"{x:1411,y:518,t:1527020015769};\\\", \\\"{x:1407,y:509,t:1527020015786};\\\", \\\"{x:1403,y:501,t:1527020015802};\\\", \\\"{x:1402,y:497,t:1527020015819};\\\", \\\"{x:1400,y:494,t:1527020015835};\\\", \\\"{x:1399,y:493,t:1527020015851};\\\", \\\"{x:1398,y:488,t:1527020015869};\\\", \\\"{x:1397,y:485,t:1527020015886};\\\", \\\"{x:1396,y:483,t:1527020015901};\\\", \\\"{x:1396,y:482,t:1527020015919};\\\", \\\"{x:1396,y:489,t:1527020016044};\\\", \\\"{x:1398,y:522,t:1527020016052};\\\", \\\"{x:1411,y:574,t:1527020016069};\\\", \\\"{x:1418,y:586,t:1527020016085};\\\", \\\"{x:1409,y:585,t:1527020016509};\\\", \\\"{x:1394,y:584,t:1527020016519};\\\", \\\"{x:1367,y:582,t:1527020016535};\\\", \\\"{x:1326,y:581,t:1527020016552};\\\", \\\"{x:1262,y:581,t:1527020016569};\\\", \\\"{x:1239,y:581,t:1527020016585};\\\", \\\"{x:1218,y:581,t:1527020016602};\\\", \\\"{x:1185,y:581,t:1527020016619};\\\", \\\"{x:1105,y:581,t:1527020016635};\\\", \\\"{x:900,y:559,t:1527020016654};\\\", \\\"{x:718,y:514,t:1527020016669};\\\", \\\"{x:515,y:468,t:1527020016684};\\\", \\\"{x:242,y:425,t:1527020016715};\\\", \\\"{x:92,y:421,t:1527020016730};\\\", \\\"{x:73,y:425,t:1527020016747};\\\", \\\"{x:73,y:426,t:1527020016764};\\\", \\\"{x:73,y:427,t:1527020016795};\\\", \\\"{x:73,y:431,t:1527020016803};\\\", \\\"{x:73,y:442,t:1527020016815};\\\", \\\"{x:76,y:480,t:1527020016832};\\\", \\\"{x:109,y:571,t:1527020016849};\\\", \\\"{x:165,y:656,t:1527020016865};\\\", \\\"{x:204,y:699,t:1527020016882};\\\", \\\"{x:220,y:710,t:1527020016898};\\\", \\\"{x:221,y:711,t:1527020016915};\\\", \\\"{x:222,y:711,t:1527020016939};\\\", \\\"{x:227,y:713,t:1527020016949};\\\", \\\"{x:248,y:720,t:1527020016966};\\\", \\\"{x:272,y:723,t:1527020016982};\\\", \\\"{x:286,y:724,t:1527020016998};\\\", \\\"{x:290,y:724,t:1527020017015};\\\", \\\"{x:293,y:724,t:1527020017033};\\\", \\\"{x:293,y:722,t:1527020017049};\\\", \\\"{x:294,y:719,t:1527020017065};\\\", \\\"{x:294,y:715,t:1527020017082};\\\", \\\"{x:294,y:708,t:1527020017099};\\\", \\\"{x:294,y:704,t:1527020017116};\\\", \\\"{x:294,y:703,t:1527020017133};\\\", \\\"{x:294,y:702,t:1527020017150};\\\", \\\"{x:294,y:701,t:1527020017172};\\\", \\\"{x:294,y:698,t:1527020017404};\\\", \\\"{x:292,y:694,t:1527020017417};\\\", \\\"{x:292,y:689,t:1527020017433};\\\", \\\"{x:291,y:684,t:1527020017450};\\\", \\\"{x:290,y:681,t:1527020017468};\\\", \\\"{x:289,y:677,t:1527020017482};\\\", \\\"{x:288,y:671,t:1527020017499};\\\", \\\"{x:286,y:655,t:1527020017516};\\\", \\\"{x:284,y:643,t:1527020017533};\\\", \\\"{x:284,y:637,t:1527020017549};\\\", \\\"{x:284,y:633,t:1527020017565};\\\", \\\"{x:287,y:632,t:1527020017582};\\\", \\\"{x:292,y:629,t:1527020017599};\\\", \\\"{x:301,y:623,t:1527020017615};\\\", \\\"{x:310,y:618,t:1527020017632};\\\", \\\"{x:315,y:612,t:1527020017650};\\\", \\\"{x:316,y:610,t:1527020017665};\\\", \\\"{x:316,y:609,t:1527020017682};\\\", \\\"{x:317,y:608,t:1527020017748};\\\", \\\"{x:320,y:607,t:1527020017765};\\\", \\\"{x:322,y:606,t:1527020017782};\\\", \\\"{x:325,y:604,t:1527020017799};\\\", \\\"{x:333,y:601,t:1527020017817};\\\", \\\"{x:339,y:599,t:1527020017832};\\\", \\\"{x:343,y:598,t:1527020017849};\\\", \\\"{x:344,y:598,t:1527020017866};\\\", \\\"{x:344,y:597,t:1527020017882};\\\", \\\"{x:344,y:596,t:1527020017988};\\\", \\\"{x:340,y:594,t:1527020018000};\\\", \\\"{x:327,y:587,t:1527020018017};\\\", \\\"{x:314,y:582,t:1527020018032};\\\", \\\"{x:300,y:577,t:1527020018050};\\\", \\\"{x:283,y:574,t:1527020018068};\\\", \\\"{x:268,y:574,t:1527020018082};\\\", \\\"{x:255,y:574,t:1527020018099};\\\", \\\"{x:248,y:574,t:1527020018117};\\\", \\\"{x:245,y:578,t:1527020018133};\\\", \\\"{x:239,y:583,t:1527020018149};\\\", \\\"{x:236,y:586,t:1527020018166};\\\", \\\"{x:231,y:590,t:1527020018183};\\\", \\\"{x:227,y:592,t:1527020018200};\\\", \\\"{x:223,y:597,t:1527020018216};\\\", \\\"{x:220,y:603,t:1527020018233};\\\", \\\"{x:220,y:609,t:1527020018250};\\\", \\\"{x:220,y:613,t:1527020018267};\\\", \\\"{x:220,y:615,t:1527020018284};\\\", \\\"{x:227,y:617,t:1527020018299};\\\", \\\"{x:249,y:619,t:1527020018316};\\\", \\\"{x:285,y:619,t:1527020018334};\\\", \\\"{x:326,y:616,t:1527020018349};\\\", \\\"{x:359,y:607,t:1527020018367};\\\", \\\"{x:383,y:600,t:1527020018384};\\\", \\\"{x:405,y:596,t:1527020018400};\\\", \\\"{x:427,y:595,t:1527020018417};\\\", \\\"{x:448,y:595,t:1527020018434};\\\", \\\"{x:469,y:599,t:1527020018449};\\\", \\\"{x:490,y:606,t:1527020018466};\\\", \\\"{x:503,y:609,t:1527020018483};\\\", \\\"{x:510,y:612,t:1527020018499};\\\", \\\"{x:510,y:614,t:1527020020924};\\\", \\\"{x:508,y:615,t:1527020020940};\\\", \\\"{x:500,y:617,t:1527020020955};\\\", \\\"{x:499,y:618,t:1527020020972};\\\", \\\"{x:498,y:619,t:1527020020989};\\\", \\\"{x:498,y:620,t:1527020021027};\\\", \\\"{x:498,y:621,t:1527020021035};\\\", \\\"{x:498,y:625,t:1527020021052};\\\", \\\"{x:498,y:627,t:1527020021068};\\\", \\\"{x:500,y:628,t:1527020021086};\\\", \\\"{x:504,y:628,t:1527020021102};\\\", \\\"{x:510,y:628,t:1527020021118};\\\", \\\"{x:515,y:628,t:1527020021136};\\\", \\\"{x:528,y:623,t:1527020021152};\\\", \\\"{x:541,y:618,t:1527020021169};\\\", \\\"{x:557,y:615,t:1527020021186};\\\", \\\"{x:571,y:612,t:1527020021203};\\\", \\\"{x:584,y:611,t:1527020021218};\\\", \\\"{x:594,y:610,t:1527020021235};\\\", \\\"{x:595,y:609,t:1527020021252};\\\", \\\"{x:596,y:609,t:1527020021331};\\\", \\\"{x:597,y:608,t:1527020021346};\\\", \\\"{x:598,y:607,t:1527020021356};\\\", \\\"{x:600,y:606,t:1527020021368};\\\", \\\"{x:604,y:603,t:1527020021386};\\\", \\\"{x:609,y:599,t:1527020021401};\\\", \\\"{x:611,y:598,t:1527020021419};\\\", \\\"{x:612,y:597,t:1527020021435};\\\", \\\"{x:612,y:595,t:1527020021491};\\\", \\\"{x:613,y:595,t:1527020021502};\\\", \\\"{x:614,y:594,t:1527020021658};\\\", \\\"{x:615,y:594,t:1527020021669};\\\", \\\"{x:615,y:593,t:1527020021686};\\\", \\\"{x:615,y:594,t:1527020021787};\\\", \\\"{x:614,y:594,t:1527020021802};\\\", \\\"{x:603,y:600,t:1527020021819};\\\", \\\"{x:595,y:603,t:1527020021836};\\\", \\\"{x:584,y:605,t:1527020021853};\\\", \\\"{x:572,y:608,t:1527020021869};\\\", \\\"{x:550,y:609,t:1527020021885};\\\", \\\"{x:517,y:609,t:1527020021902};\\\", \\\"{x:488,y:609,t:1527020021919};\\\", \\\"{x:459,y:609,t:1527020021935};\\\", \\\"{x:450,y:609,t:1527020021953};\\\", \\\"{x:449,y:609,t:1527020021969};\\\", \\\"{x:446,y:607,t:1527020022013};\\\", \\\"{x:442,y:599,t:1527020022019};\\\", \\\"{x:436,y:591,t:1527020022036};\\\", \\\"{x:427,y:583,t:1527020022052};\\\", \\\"{x:412,y:577,t:1527020022069};\\\", \\\"{x:403,y:575,t:1527020022086};\\\", \\\"{x:394,y:575,t:1527020022102};\\\", \\\"{x:383,y:579,t:1527020022120};\\\", \\\"{x:375,y:581,t:1527020022135};\\\", \\\"{x:372,y:584,t:1527020022152};\\\", \\\"{x:366,y:586,t:1527020022169};\\\", \\\"{x:356,y:589,t:1527020022187};\\\", \\\"{x:349,y:593,t:1527020022202};\\\", \\\"{x:349,y:594,t:1527020022243};\\\", \\\"{x:349,y:595,t:1527020022268};\\\", \\\"{x:350,y:595,t:1527020022291};\\\", \\\"{x:352,y:594,t:1527020022307};\\\", \\\"{x:353,y:594,t:1527020022320};\\\", \\\"{x:359,y:591,t:1527020022337};\\\", \\\"{x:361,y:590,t:1527020022353};\\\", \\\"{x:364,y:589,t:1527020022369};\\\", \\\"{x:364,y:588,t:1527020022387};\\\", \\\"{x:366,y:588,t:1527020022412};\\\", \\\"{x:367,y:588,t:1527020022420};\\\", \\\"{x:370,y:586,t:1527020022437};\\\", \\\"{x:374,y:584,t:1527020022454};\\\", \\\"{x:375,y:584,t:1527020022470};\\\", \\\"{x:377,y:588,t:1527020022635};\\\", \\\"{x:383,y:604,t:1527020022643};\\\", \\\"{x:394,y:626,t:1527020022654};\\\", \\\"{x:415,y:654,t:1527020022670};\\\", \\\"{x:431,y:671,t:1527020022686};\\\", \\\"{x:435,y:673,t:1527020022703};\\\", \\\"{x:435,y:674,t:1527020022720};\\\", \\\"{x:440,y:678,t:1527020022737};\\\", \\\"{x:448,y:688,t:1527020022754};\\\", \\\"{x:456,y:708,t:1527020022770};\\\", \\\"{x:470,y:740,t:1527020022787};\\\", \\\"{x:494,y:787,t:1527020022803};\\\", \\\"{x:526,y:826,t:1527020022820};\\\", \\\"{x:527,y:828,t:1527020022836};\\\", \\\"{x:528,y:828,t:1527020022859};\\\", \\\"{x:528,y:827,t:1527020022870};\\\", \\\"{x:528,y:826,t:1527020022887};\\\", \\\"{x:528,y:823,t:1527020022903};\\\", \\\"{x:528,y:822,t:1527020022921};\\\", \\\"{x:528,y:821,t:1527020022948};\\\", \\\"{x:528,y:819,t:1527020022955};\\\", \\\"{x:528,y:815,t:1527020022971};\\\", \\\"{x:528,y:805,t:1527020022987};\\\", \\\"{x:528,y:789,t:1527020023004};\\\", \\\"{x:528,y:784,t:1527020023021};\\\", \\\"{x:528,y:783,t:1527020023037};\\\", \\\"{x:528,y:782,t:1527020023054};\\\", \\\"{x:528,y:779,t:1527020023071};\\\", \\\"{x:528,y:773,t:1527020023087};\\\", \\\"{x:528,y:764,t:1527020023105};\\\", \\\"{x:527,y:760,t:1527020023121};\\\", \\\"{x:527,y:758,t:1527020023137};\\\", \\\"{x:526,y:757,t:1527020024100};\\\" ] }, { \\\"rt\\\": 38460, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 20, \\\"time_elapsed\\\": 670274, \\\"internal_node_id\\\": \\\"0.0-7.0-0.0\\\", \\\"subject\\\": \\\"VT5BG\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"golf\\\", \\\"condition\\\": \\\"121\\\", \\\"q\\\": 16, \\\"answer\\\": \\\"Which ever shift is diagonally connected to the 12pm on the x-axis\\\", \\\"block\\\": \\\"triangular_testing\\\" }, { \\\"rt\\\": 7015, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"19\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"USA\\\\\\\"}\\\", \\\"block\\\": \\\"demo-1\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 21, \\\"time_elapsed\\\": 678293, \\\"internal_node_id\\\": \\\"0.0-8.0\\\", \\\"subject\\\": \\\"VT5BG\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"golf\\\", \\\"condition\\\": \\\"121\\\" }, { \\\"rt\\\": 24931, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"English\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"Second\\\\\\\",\\\\\\\"Q2\\\\\\\":\\\\\\\"Natural Sciences\\\\\\\",\\\\\\\"Q3\\\\\\\":\\\\\\\"Female\\\\\\\"}\\\", \\\"block\\\": \\\"demo-2\\\", \\\"trial_type\\\": \\\"survey-multi-choice\\\", \\\"trial_index\\\": 22, \\\"time_elapsed\\\": 704241, \\\"internal_node_id\\\": \\\"0.0-9.0\\\", \\\"subject\\\": \\\"VT5BG\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"golf\\\", \\\"condition\\\": \\\"121\\\" }, { \\\"rt\\\": 11121, \\\"url\\\": \\\"../views/src/external/debrief.html\\\", \\\"block\\\": \\\"debrief\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 23, \\\"time_elapsed\\\": 716709, \\\"internal_node_id\\\": \\\"0.0-10.0\\\", \\\"subject\\\": \\\"VT5BG\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"golf\\\", \\\"condition\\\": \\\"121\\\" } ]\",\"parentNode\":{\"id\":2765}}],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"META\",\"attributes\":{\"charset\":\"utf-8\"}},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":8,\"id\":59},{\"nodeType\":3,\"id\":60,\"textContent\":\" \"},{\"nodeType\":1,\"id\":61,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":62,\"textContent\":\" \"},{\"nodeType\":1,\"id\":63,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":64,\"textContent\":\" \"},{\"nodeType\":1,\"id\":65,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":66,\"textContent\":\" \"},{\"nodeType\":1,\"id\":67,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":68,\"textContent\":\" \"},{\"nodeType\":1,\"id\":69,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":70,\"textContent\":\" \"},{\"nodeType\":1,\"id\":71,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":72,\"textContent\":\" \"},{\"nodeType\":1,\"id\":73,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"stimulus\"},\"childNodes\":[{\"nodeType\":3,\"id\":74,\"textContent\":\" \"},{\"nodeType\":1,\"id\":75,\"tagName\":\"P\",\"attributes\":{\"class\":\"userid\",\"id\":\"userid\"},\"childNodes\":[{\"nodeType\":3,\"id\":76,\"textContent\":\"VT5BG\"}]},{\"nodeType\":3,\"id\":77,\"textContent\":\" \"},{\"nodeType\":1,\"id\":78,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"userinput\"},\"childNodes\":[{\"nodeType\":3,\"id\":79,\"textContent\":\" \"},{\"nodeType\":8,\"id\":80},{\"nodeType\":3,\"id\":81,\"textContent\":\" \"},{\"nodeType\":1,\"id\":82,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"legend\",\"id\":\"hint-interactive\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":83,\"textContent\":\" \"},{\"nodeType\":1,\"id\":84,\"tagName\":\"P\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":85,\"textContent\":\"Hint: Hover your mouse over the data points in the graph\"}]},{\"nodeType\":3,\"id\":86,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":87,\"textContent\":\" \"},{\"nodeType\":8,\"id\":88},{\"nodeType\":3,\"id\":89,\"textContent\":\" \"},{\"nodeType\":8,\"id\":90},{\"nodeType\":3,\"id\":91,\"textContent\":\" \"},{\"nodeType\":1,\"id\":92,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"test\"},\"childNodes\":[{\"nodeType\":3,\"id\":93,\"textContent\":\" \"},{\"nodeType\":1,\"id\":94,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":95,\"textContent\":\" \"},{\"nodeType\":1,\"id\":96,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":97,\"textContent\":\"Which shift(s) start at 11 am? \"}]},{\"nodeType\":3,\"id\":98,\"textContent\":\" \"},{\"nodeType\":1,\"id\":99,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":100,\"textContent\":\" \"},{\"nodeType\":1,\"id\":101,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":102,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":103,\"textContent\":\" \"},{\"nodeType\":1,\"id\":104,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":105,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":106,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":107,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":108,\"textContent\":\" \"},{\"nodeType\":1,\"id\":109,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":110,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":111,\"textContent\":\" \"},{\"nodeType\":1,\"id\":112,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":113,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":115,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":116,\"textContent\":\" \"},{\"nodeType\":1,\"id\":117,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":118,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":120,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":121,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":122,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":123,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":125,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":126,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":127,\"textContent\":\" \"},{\"nodeType\":1,\"id\":128,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":129,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":130,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":132,\"textContent\":\" \"},{\"nodeType\":1,\"id\":133,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":134,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":135,\"textContent\":\" \"},{\"nodeType\":1,\"id\":136,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":137,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":138,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":140,\"textContent\":\" \"},{\"nodeType\":1,\"id\":141,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":142,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":143,\"textContent\":\" \"},{\"nodeType\":1,\"id\":144,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":145,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":146,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":147,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":148,\"textContent\":\" \"},{\"nodeType\":1,\"id\":149,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":150,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":151,\"textContent\":\" \"},{\"nodeType\":1,\"id\":152,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":153,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":154,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":156,\"textContent\":\" \"},{\"nodeType\":1,\"id\":157,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":158,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":159,\"textContent\":\" \"},{\"nodeType\":1,\"id\":160,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":161,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":162,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":163,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":164,\"textContent\":\" \"},{\"nodeType\":1,\"id\":165,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":166,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":167,\"textContent\":\" \"},{\"nodeType\":1,\"id\":168,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":169,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":170,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":171,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":172,\"textContent\":\" \"},{\"nodeType\":1,\"id\":173,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":174,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":175,\"textContent\":\" \"},{\"nodeType\":1,\"id\":176,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":177,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":178,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":179,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":180,\"textContent\":\" \"},{\"nodeType\":1,\"id\":181,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":182,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":183,\"textContent\":\" \"},{\"nodeType\":1,\"id\":184,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":185,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":186,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":187,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":188,\"textContent\":\" \"},{\"nodeType\":1,\"id\":189,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":190,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":191,\"textContent\":\" \"},{\"nodeType\":1,\"id\":192,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":193,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":194,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":196,\"textContent\":\" \"},{\"nodeType\":1,\"id\":197,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":198,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":200,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":201,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":202,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":203,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":205,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":206,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":207,\"textContent\":\" \"},{\"nodeType\":1,\"id\":208,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":209,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":210,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":211,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":212,\"textContent\":\" \"},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":214,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":215,\"textContent\":\" \"},{\"nodeType\":1,\"id\":216,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":217,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":218,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":219,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":220,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":221,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":223,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":224,\"textContent\":\" \"},{\"nodeType\":1,\"id\":225,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":226,\"textContent\":\"Which shift(s) start at the same time as D?\"}]},{\"nodeType\":3,\"id\":227,\"textContent\":\" \"},{\"nodeType\":1,\"id\":228,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":229,\"textContent\":\" \"},{\"nodeType\":1,\"id\":230,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":231,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":232,\"textContent\":\" \"},{\"nodeType\":1,\"id\":233,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":234,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":235,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":236,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":237,\"textContent\":\" \"},{\"nodeType\":1,\"id\":238,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":239,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":240,\"textContent\":\" \"},{\"nodeType\":1,\"id\":241,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":242,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":243,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":244,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":245,\"textContent\":\" \"},{\"nodeType\":1,\"id\":246,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":247,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":248,\"textContent\":\" \"},{\"nodeType\":1,\"id\":249,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":250,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":251,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":252,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":253,\"textContent\":\" \"},{\"nodeType\":1,\"id\":254,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":255,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":256,\"textContent\":\" \"},{\"nodeType\":1,\"id\":257,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":258,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":259,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":260,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":261,\"textContent\":\" \"},{\"nodeType\":1,\"id\":262,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":263,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":264,\"textContent\":\" \"},{\"nodeType\":1,\"id\":265,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":266,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":267,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":268,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":269,\"textContent\":\" \"},{\"nodeType\":1,\"id\":270,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":271,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":273,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":274,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":275,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":276,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":278,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":279,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":280,\"textContent\":\" \"},{\"nodeType\":1,\"id\":281,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":282,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":283,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":284,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":286,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":287,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":288,\"textContent\":\" \"},{\"nodeType\":1,\"id\":289,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":290,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":291,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":292,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":293,\"textContent\":\" \"},{\"nodeType\":1,\"id\":294,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":295,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":296,\"textContent\":\" \"},{\"nodeType\":1,\"id\":297,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":298,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":299,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":300,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":301,\"textContent\":\" \"},{\"nodeType\":1,\"id\":302,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":303,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":304,\"textContent\":\" \"},{\"nodeType\":1,\"id\":305,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":306,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":307,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":308,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":309,\"textContent\":\" \"},{\"nodeType\":1,\"id\":310,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":311,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":312,\"textContent\":\" \"},{\"nodeType\":1,\"id\":313,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":314,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":315,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":316,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":317,\"textContent\":\" \"},{\"nodeType\":1,\"id\":318,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":319,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":320,\"textContent\":\" \"},{\"nodeType\":1,\"id\":321,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":322,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":323,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":324,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":325,\"textContent\":\" \"},{\"nodeType\":1,\"id\":326,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":327,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":328,\"textContent\":\" \"},{\"nodeType\":1,\"id\":329,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":330,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":331,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":332,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":333,\"textContent\":\" \"},{\"nodeType\":1,\"id\":334,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":335,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":336,\"textContent\":\" \"},{\"nodeType\":1,\"id\":337,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":338,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":339,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":340,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":341,\"textContent\":\" \"},{\"nodeType\":1,\"id\":342,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":343,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":344,\"textContent\":\" \"},{\"nodeType\":1,\"id\":345,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":346,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":347,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":348,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":349,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":351,\"textContent\":\" \"},{\"nodeType\":1,\"id\":352,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":353,\"textContent\":\" \"},{\"nodeType\":1,\"id\":354,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":355,\"textContent\":\"Which shift(s) begin when C ends?\"}]},{\"nodeType\":3,\"id\":356,\"textContent\":\" \"},{\"nodeType\":1,\"id\":357,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":358,\"textContent\":\" \"},{\"nodeType\":1,\"id\":359,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":360,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":361,\"textContent\":\" \"},{\"nodeType\":1,\"id\":362,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":363,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":364,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":365,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":366,\"textContent\":\" \"},{\"nodeType\":1,\"id\":367,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":368,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":369,\"textContent\":\" \"},{\"nodeType\":1,\"id\":370,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":371,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":372,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":373,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":374,\"textContent\":\" \"},{\"nodeType\":1,\"id\":375,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":376,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":377,\"textContent\":\" \"},{\"nodeType\":1,\"id\":378,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":379,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":380,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":381,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":382,\"textContent\":\" \"},{\"nodeType\":1,\"id\":383,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":384,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":385,\"textContent\":\" \"},{\"nodeType\":1,\"id\":386,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":387,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":388,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":389,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":390,\"textContent\":\" \"},{\"nodeType\":1,\"id\":391,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":392,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":393,\"textContent\":\" \"},{\"nodeType\":1,\"id\":394,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":395,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":396,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":397,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":398,\"textContent\":\" \"},{\"nodeType\":1,\"id\":399,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":400,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":401,\"textContent\":\" \"},{\"nodeType\":1,\"id\":402,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":403,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":404,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":405,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":406,\"textContent\":\" \"},{\"nodeType\":1,\"id\":407,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":408,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":409,\"textContent\":\" \"},{\"nodeType\":1,\"id\":410,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":411,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":412,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":413,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":414,\"textContent\":\" \"},{\"nodeType\":1,\"id\":415,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":416,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":417,\"textContent\":\" \"},{\"nodeType\":1,\"id\":418,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":419,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":420,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":421,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":422,\"textContent\":\" \"},{\"nodeType\":1,\"id\":423,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":424,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":425,\"textContent\":\" \"},{\"nodeType\":1,\"id\":426,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":427,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":428,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":429,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":430,\"textContent\":\" \"},{\"nodeType\":1,\"id\":431,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":432,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":433,\"textContent\":\" \"},{\"nodeType\":1,\"id\":434,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":435,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":436,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":437,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":438,\"textContent\":\" \"},{\"nodeType\":1,\"id\":439,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":440,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":441,\"textContent\":\" \"},{\"nodeType\":1,\"id\":442,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":443,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":444,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":445,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":446,\"textContent\":\" \"},{\"nodeType\":1,\"id\":447,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":448,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":449,\"textContent\":\" \"},{\"nodeType\":1,\"id\":450,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":451,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":452,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":453,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":454,\"textContent\":\" \"},{\"nodeType\":1,\"id\":455,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":456,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":457,\"textContent\":\" \"},{\"nodeType\":1,\"id\":458,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":459,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":460,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":461,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":462,\"textContent\":\" \"},{\"nodeType\":1,\"id\":463,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":464,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":465,\"textContent\":\" \"},{\"nodeType\":1,\"id\":466,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":467,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":468,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":469,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":470,\"textContent\":\" \"},{\"nodeType\":1,\"id\":471,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":472,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":473,\"textContent\":\" \"},{\"nodeType\":1,\"id\":474,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":475,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":476,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":477,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":478,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":479,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":480,\"textContent\":\" \"},{\"nodeType\":1,\"id\":481,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":483,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":484,\"textContent\":\" Which shift(s) end at 4 pm?\"}]},{\"nodeType\":3,\"id\":485,\"textContent\":\" \"},{\"nodeType\":1,\"id\":486,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":492,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":500,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":503,\"textContent\":\" \"},{\"nodeType\":1,\"id\":504,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":505,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":506,\"textContent\":\" \"},{\"nodeType\":1,\"id\":507,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":508,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":509,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":510,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":511,\"textContent\":\" \"},{\"nodeType\":1,\"id\":512,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":513,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":514,\"textContent\":\" \"},{\"nodeType\":1,\"id\":515,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":516,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":517,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":518,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":519,\"textContent\":\" \"},{\"nodeType\":1,\"id\":520,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":521,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":522,\"textContent\":\" \"},{\"nodeType\":1,\"id\":523,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":524,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":525,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":526,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":527,\"textContent\":\" \"},{\"nodeType\":1,\"id\":528,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":529,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":530,\"textContent\":\" \"},{\"nodeType\":1,\"id\":531,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":532,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":533,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":534,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":535,\"textContent\":\" \"},{\"nodeType\":1,\"id\":536,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":537,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":538,\"textContent\":\" \"},{\"nodeType\":1,\"id\":539,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":540,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":541,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":542,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":543,\"textContent\":\" \"},{\"nodeType\":1,\"id\":544,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":545,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":546,\"textContent\":\" \"},{\"nodeType\":1,\"id\":547,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":548,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":549,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":550,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":551,\"textContent\":\" \"},{\"nodeType\":1,\"id\":552,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":553,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":554,\"textContent\":\" \"},{\"nodeType\":1,\"id\":555,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":556,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":557,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":558,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":559,\"textContent\":\" \"},{\"nodeType\":1,\"id\":560,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":561,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":562,\"textContent\":\" \"},{\"nodeType\":1,\"id\":563,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":564,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":565,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":566,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":567,\"textContent\":\" \"},{\"nodeType\":1,\"id\":568,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":569,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":570,\"textContent\":\" \"},{\"nodeType\":1,\"id\":571,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":572,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":573,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":574,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":575,\"textContent\":\" \"},{\"nodeType\":1,\"id\":576,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":577,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":578,\"textContent\":\" \"},{\"nodeType\":1,\"id\":579,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":580,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":581,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":582,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":583,\"textContent\":\" \"},{\"nodeType\":1,\"id\":584,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":585,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":586,\"textContent\":\" \"},{\"nodeType\":1,\"id\":587,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":588,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":589,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":590,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":592,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":593,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":594,\"textContent\":\" \"},{\"nodeType\":1,\"id\":595,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":596,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":597,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":598,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":599,\"textContent\":\" \"},{\"nodeType\":1,\"id\":600,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":601,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":602,\"textContent\":\" \"},{\"nodeType\":1,\"id\":603,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":604,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":605,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":606,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":607,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":608,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":609,\"textContent\":\" \"},{\"nodeType\":1,\"id\":610,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":612,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":613,\"textContent\":\"Coffee breaks happen halfway through a shift.\"},{\"nodeType\":1,\"id\":614,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":615,\"textContent\":\" Which shift(s) share a break with I?\"}]},{\"nodeType\":3,\"id\":616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":617,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":618,\"textContent\":\" \"},{\"nodeType\":1,\"id\":619,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":620,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":621,\"textContent\":\" \"},{\"nodeType\":1,\"id\":622,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":623,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":624,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":625,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":626,\"textContent\":\" \"},{\"nodeType\":1,\"id\":627,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":628,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":629,\"textContent\":\" \"},{\"nodeType\":1,\"id\":630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":631,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":632,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":633,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":634,\"textContent\":\" \"},{\"nodeType\":1,\"id\":635,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":636,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":637,\"textContent\":\" \"},{\"nodeType\":1,\"id\":638,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":639,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":640,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":641,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":642,\"textContent\":\" \"},{\"nodeType\":1,\"id\":643,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":644,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":645,\"textContent\":\" \"},{\"nodeType\":1,\"id\":646,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":647,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":648,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":649,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":650,\"textContent\":\" \"},{\"nodeType\":1,\"id\":651,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":653,\"textContent\":\" \"},{\"nodeType\":1,\"id\":654,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":655,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":656,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":657,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":659,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":660,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":661,\"textContent\":\" \"},{\"nodeType\":1,\"id\":662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":663,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":664,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":665,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":666,\"textContent\":\" \"},{\"nodeType\":1,\"id\":667,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":668,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":669,\"textContent\":\" \"},{\"nodeType\":1,\"id\":670,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":671,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":672,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":673,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":674,\"textContent\":\" \"},{\"nodeType\":1,\"id\":675,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":676,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":677,\"textContent\":\" \"},{\"nodeType\":1,\"id\":678,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":679,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":680,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":681,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":682,\"textContent\":\" \"},{\"nodeType\":1,\"id\":683,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":685,\"textContent\":\" \"},{\"nodeType\":1,\"id\":686,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":687,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":688,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":689,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":690,\"textContent\":\" \"},{\"nodeType\":1,\"id\":691,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":692,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":693,\"textContent\":\" \"},{\"nodeType\":1,\"id\":694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":695,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":696,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":697,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":698,\"textContent\":\" \"},{\"nodeType\":1,\"id\":699,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":700,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":701,\"textContent\":\" \"},{\"nodeType\":1,\"id\":702,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":703,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":704,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":705,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":706,\"textContent\":\" \"},{\"nodeType\":1,\"id\":707,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":708,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":709,\"textContent\":\" \"},{\"nodeType\":1,\"id\":710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":711,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":712,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":713,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":714,\"textContent\":\" \"},{\"nodeType\":1,\"id\":715,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":716,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":717,\"textContent\":\" \"},{\"nodeType\":1,\"id\":718,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":719,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":720,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":721,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":722,\"textContent\":\" \"},{\"nodeType\":1,\"id\":723,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":724,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":725,\"textContent\":\" \"},{\"nodeType\":1,\"id\":726,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":727,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":728,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":729,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":730,\"textContent\":\" \"},{\"nodeType\":1,\"id\":731,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":732,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":733,\"textContent\":\" \"},{\"nodeType\":1,\"id\":734,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":735,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":736,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":737,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":738,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":739,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":741,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":742,\"textContent\":\" \"},{\"nodeType\":1,\"id\":743,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":744,\"textContent\":\"Which shift(s) are six hours long?\"}]},{\"nodeType\":3,\"id\":745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":746,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":747,\"textContent\":\" \"},{\"nodeType\":1,\"id\":748,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":749,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":750,\"textContent\":\" \"},{\"nodeType\":1,\"id\":751,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":752,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":753,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":754,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":755,\"textContent\":\" \"},{\"nodeType\":1,\"id\":756,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":757,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":758,\"textContent\":\" \"},{\"nodeType\":1,\"id\":759,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":760,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":761,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":762,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":763,\"textContent\":\" \"},{\"nodeType\":1,\"id\":764,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":765,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":766,\"textContent\":\" \"},{\"nodeType\":1,\"id\":767,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":768,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":769,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":770,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":771,\"textContent\":\" \"},{\"nodeType\":1,\"id\":772,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":773,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":774,\"textContent\":\" \"},{\"nodeType\":1,\"id\":775,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":776,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":777,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":778,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":779,\"textContent\":\" \"},{\"nodeType\":1,\"id\":780,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":781,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":782,\"textContent\":\" \"},{\"nodeType\":1,\"id\":783,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":784,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":785,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":786,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":787,\"textContent\":\" \"},{\"nodeType\":1,\"id\":788,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":789,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":790,\"textContent\":\" \"},{\"nodeType\":1,\"id\":791,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":792,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":793,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":794,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":795,\"textContent\":\" \"},{\"nodeType\":1,\"id\":796,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":797,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":798,\"textContent\":\" \"},{\"nodeType\":1,\"id\":799,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":800,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":801,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":802,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":803,\"textContent\":\" \"},{\"nodeType\":1,\"id\":804,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":805,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":806,\"textContent\":\" \"},{\"nodeType\":1,\"id\":807,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":808,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":809,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":810,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":812,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":813,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":814,\"textContent\":\" \"},{\"nodeType\":1,\"id\":815,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":816,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":817,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":818,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":819,\"textContent\":\" \"},{\"nodeType\":1,\"id\":820,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":821,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":822,\"textContent\":\" \"},{\"nodeType\":1,\"id\":823,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":824,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":825,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":826,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":827,\"textContent\":\" \"},{\"nodeType\":1,\"id\":828,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":829,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":830,\"textContent\":\" \"},{\"nodeType\":1,\"id\":831,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":832,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":833,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":834,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":835,\"textContent\":\" \"},{\"nodeType\":1,\"id\":836,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":837,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":838,\"textContent\":\" \"},{\"nodeType\":1,\"id\":839,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":840,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":841,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":842,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":843,\"textContent\":\" \"},{\"nodeType\":1,\"id\":844,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":845,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":846,\"textContent\":\" \"},{\"nodeType\":1,\"id\":847,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":848,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":849,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":850,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":851,\"textContent\":\" \"},{\"nodeType\":1,\"id\":852,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":853,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":854,\"textContent\":\" \"},{\"nodeType\":1,\"id\":855,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":856,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":857,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":858,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":859,\"textContent\":\" \"},{\"nodeType\":1,\"id\":860,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":861,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":862,\"textContent\":\" \"},{\"nodeType\":1,\"id\":863,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":864,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":865,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":866,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":867,\"textContent\":\" \"},{\"nodeType\":1,\"id\":868,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":869,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":870,\"textContent\":\" \"},{\"nodeType\":1,\"id\":871,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":872,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":873,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":874,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":875,\"textContent\":\" \"},{\"nodeType\":1,\"id\":876,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":877,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":878,\"textContent\":\" \"},{\"nodeType\":1,\"id\":879,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":880,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":881,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":882,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":883,\"textContent\":\" \"},{\"nodeType\":1,\"id\":884,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":885,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":886,\"textContent\":\" \"},{\"nodeType\":1,\"id\":887,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":888,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":889,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":890,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":891,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":892,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":894,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":895,\"textContent\":\" \"},{\"nodeType\":1,\"id\":896,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":897,\"textContent\":\"Which 2 shifts less than 5 hours long start at the same time?\"}]},{\"nodeType\":3,\"id\":898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":899,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":900,\"textContent\":\" \"},{\"nodeType\":1,\"id\":901,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":902,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":903,\"textContent\":\" \"},{\"nodeType\":1,\"id\":904,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":905,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":906,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":907,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":908,\"textContent\":\" \"},{\"nodeType\":1,\"id\":909,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":910,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":911,\"textContent\":\" \"},{\"nodeType\":1,\"id\":912,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":913,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":914,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":915,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":916,\"textContent\":\" \"},{\"nodeType\":1,\"id\":917,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":918,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":919,\"textContent\":\" \"},{\"nodeType\":1,\"id\":920,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":921,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":922,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":923,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":924,\"textContent\":\" \"},{\"nodeType\":1,\"id\":925,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":926,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":927,\"textContent\":\" \"},{\"nodeType\":1,\"id\":928,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":929,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":930,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":931,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":932,\"textContent\":\" \"},{\"nodeType\":1,\"id\":933,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":934,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":935,\"textContent\":\" \"},{\"nodeType\":1,\"id\":936,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":937,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":938,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":939,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":940,\"textContent\":\" \"},{\"nodeType\":1,\"id\":941,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":942,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":943,\"textContent\":\" \"},{\"nodeType\":1,\"id\":944,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":945,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":946,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":947,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":948,\"textContent\":\" \"},{\"nodeType\":1,\"id\":949,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":950,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":951,\"textContent\":\" \"},{\"nodeType\":1,\"id\":952,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":953,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":954,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":955,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":956,\"textContent\":\" \"},{\"nodeType\":1,\"id\":957,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":958,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":959,\"textContent\":\" \"},{\"nodeType\":1,\"id\":960,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":961,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":962,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":963,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":965,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":966,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":967,\"textContent\":\" \"},{\"nodeType\":1,\"id\":968,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":969,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":970,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":971,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":972,\"textContent\":\" \"},{\"nodeType\":1,\"id\":973,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":974,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":975,\"textContent\":\" \"},{\"nodeType\":1,\"id\":976,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":977,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":978,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":979,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":980,\"textContent\":\" \"},{\"nodeType\":1,\"id\":981,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":982,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":983,\"textContent\":\" \"},{\"nodeType\":1,\"id\":984,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":985,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":986,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":987,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":988,\"textContent\":\" \"},{\"nodeType\":1,\"id\":989,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":990,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":991,\"textContent\":\" \"},{\"nodeType\":1,\"id\":992,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":993,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":994,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":995,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":996,\"textContent\":\" \"},{\"nodeType\":1,\"id\":997,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":998,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":999,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1000,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1001,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1002,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1003,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1004,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1005,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1006,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1007,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1008,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1009,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1010,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1011,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1012,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1013,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1014,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1015,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1016,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1017,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1018,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1019,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1020,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1021,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1022,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1023,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1024,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1025,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1026,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1027,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1028,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1029,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1030,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1031,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1032,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1033,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1034,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1035,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1036,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1037,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1038,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1039,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1040,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1041,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1042,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1043,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1044,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1045,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1047,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+contained\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1048,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1049,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1050,\"textContent\":\"Which shift(s) under 7 hours long starts before B starts, and ends after X ends?\"}]},{\"nodeType\":3,\"id\":1051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1052,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1053,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1054,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1055,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1056,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1057,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1058,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1059,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1060,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1061,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1062,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1063,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1064,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1065,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1066,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1067,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1068,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1069,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1070,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1071,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1072,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1073,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1074,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1075,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1076,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1077,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1078,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1079,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1080,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1081,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1082,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1083,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1084,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1085,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1086,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1087,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1088,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1089,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1090,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1091,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1092,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1093,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1094,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1095,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1096,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1097,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1098,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1099,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1100,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1101,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1102,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1103,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1104,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1105,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1106,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1107,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1108,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1109,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1110,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1111,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1112,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1113,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1114,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1115,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1116,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1118,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1119,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1120,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1121,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1122,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1123,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1124,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1125,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1126,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1127,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1128,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1129,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1130,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1131,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1132,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1133,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1134,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1135,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1136,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1137,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1138,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1139,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1140,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1141,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1142,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1143,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1144,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1145,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1146,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1147,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1148,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1149,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1150,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1151,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1152,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1153,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1154,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1155,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1156,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1157,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1158,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1159,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1160,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1161,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1162,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1163,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1164,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1165,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1166,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1167,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1168,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1169,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1170,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1171,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1172,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1173,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1174,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1175,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1176,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1177,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1178,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1179,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1180,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1181,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1182,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1183,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1184,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1185,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1186,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1187,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1188,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1189,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1190,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1191,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1192,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1193,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1194,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1195,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1196,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1197,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1198,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1200,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime+before+endtime+during\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1202,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1203,\"textContent\":\"Which shift(s) begins before J begins and ends during B?\"}]},{\"nodeType\":3,\"id\":1204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1205,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1211,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1219,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1227,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1235,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1243,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1251,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1259,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1267,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1270,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1271,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1272,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1273,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1274,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1275,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1276,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1277,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1278,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1279,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1280,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1281,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1282,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1283,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1284,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1285,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1286,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1287,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1288,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1289,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1290,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1291,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1292,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1293,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1294,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1295,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1296,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1298,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1299,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1300,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1301,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1302,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1303,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1304,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1305,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1306,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1307,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1308,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1309,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1310,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1311,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1312,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1313,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1314,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1315,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1316,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1317,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1318,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1319,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1320,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1321,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1322,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1323,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1324,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1325,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1326,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1327,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1328,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1329,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1330,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1331,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1332,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1333,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1334,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1335,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1336,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1337,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1338,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1339,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1340,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1341,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1342,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1343,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1344,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1345,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1346,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1347,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1348,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1349,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1351,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1352,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1353,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.ends\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1354,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1355,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1356,\"textContent\":\"Which shift(s) end at the same time as F?\"}]},{\"nodeType\":3,\"id\":1357,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1358,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1359,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1360,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1361,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1362,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1363,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1364,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1365,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1366,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1367,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1368,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1369,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1370,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1371,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1372,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1373,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1374,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1375,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1376,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1377,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1378,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1379,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1380,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1381,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1382,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1383,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1384,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1385,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1386,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1387,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1388,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1389,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1390,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1391,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1392,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1393,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1394,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1395,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1396,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1397,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1398,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1399,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1400,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1401,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1402,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1403,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1404,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1405,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1406,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1407,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1408,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1409,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1410,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1411,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1412,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1413,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1414,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1415,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1416,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1417,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1418,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1419,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1420,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1421,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1422,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1423,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1424,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1425,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1426,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1427,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1428,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1429,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1430,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1431,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1432,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1433,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1434,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1435,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1436,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1437,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1438,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1439,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1440,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1441,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1442,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1443,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1444,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1445,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1446,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1447,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1448,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1449,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1450,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1451,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1452,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1453,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1454,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1455,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1456,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1457,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1458,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1459,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1460,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1461,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1462,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1463,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1464,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1465,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1466,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1467,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1468,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1469,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1470,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1471,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1472,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1473,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1474,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1475,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1476,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1477,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1478,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1479,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1480,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1481,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1483,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1484,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1485,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1486,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1492,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1500,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1503,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1504,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1505,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1506,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1507,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1508,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1509,\"textContent\":\"Which shift(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":1510,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1511,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1512,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1513,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1514,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1515,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1516,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1517,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1518,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1519,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1520,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1521,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1522,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1523,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1524,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1525,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1526,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1527,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1528,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1529,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1530,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1531,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1532,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1533,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1534,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1535,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1536,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1537,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1538,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1539,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1540,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1541,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1542,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1543,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1544,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1545,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1546,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1547,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1548,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1549,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1550,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1551,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1552,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1553,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1554,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1555,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1556,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1557,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1558,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1559,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1560,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1561,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1562,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1563,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1564,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1565,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1566,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1567,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1568,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1569,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1570,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1571,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1572,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1573,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1574,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1575,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1576,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1577,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1578,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1579,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1580,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1581,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1582,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1583,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1584,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1585,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1586,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1587,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1588,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1589,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1590,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1591,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1592,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1593,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1594,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1595,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1596,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1597,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1598,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1599,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1600,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1601,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1602,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1603,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1604,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1605,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1606,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1607,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1608,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1609,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1610,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1612,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1613,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1614,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1615,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1617,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1618,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1619,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1620,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1621,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1622,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1623,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1624,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1625,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1627,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1628,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1629,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1630,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1631,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1632,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1633,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1634,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1635,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1636,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1637,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1638,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1639,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1640,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1641,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1642,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1643,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1644,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1645,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1646,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1647,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1648,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1649,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1650,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1651,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1652,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1653,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1654,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1655,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1656,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1657,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1659,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1660,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1661,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1662,\"textContent\":\"Which shift(s) start at the same time as F?\"}]},{\"nodeType\":3,\"id\":1663,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1664,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1665,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1666,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1667,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1668,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1669,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1670,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1671,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1672,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1673,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1674,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1675,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1676,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1677,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1678,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1679,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1680,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1681,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1682,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1683,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1684,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1686,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1687,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1688,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1689,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1690,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1691,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1692,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1693,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1694,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1695,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1696,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1697,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1698,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1699,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1700,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1701,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1702,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1703,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1704,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1705,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1706,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1707,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1708,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1709,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1710,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1711,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1712,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1713,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1714,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1715,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1716,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1717,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1718,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1720,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1721,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1722,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1723,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1724,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1725,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1726,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1727,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1728,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1729,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1730,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1731,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1732,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1733,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1734,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1735,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1736,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1737,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1738,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1739,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1741,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1742,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1743,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1744,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1746,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1747,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1748,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1749,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1750,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1751,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1752,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1753,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1754,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1755,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1756,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1757,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1758,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1759,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1760,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1761,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1762,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1763,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1764,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1765,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1766,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1767,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1768,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1769,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1770,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1771,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1772,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1773,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1774,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1775,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1776,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1777,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1778,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1779,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1780,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1781,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1782,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1783,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1784,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1785,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1786,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1787,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1788,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1789,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1790,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1791,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1792,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1793,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1794,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1795,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1796,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1797,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1798,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1799,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1800,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1801,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1802,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1803,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1804,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1805,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1806,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1807,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1808,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1809,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1810,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1812,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1813,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1814,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1815,\"textContent\":\"Which 2 shifts end when Z begins?\"}]},{\"nodeType\":3,\"id\":1816,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1817,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1818,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1819,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1820,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1821,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1822,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1823,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1824,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1825,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1826,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1827,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1828,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1829,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1830,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1831,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1832,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1833,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1834,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1835,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1836,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1837,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1838,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1839,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1840,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1841,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1842,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1843,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1844,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1845,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1846,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1847,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1848,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1849,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1850,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1851,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1852,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1853,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1854,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1855,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1856,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1857,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1858,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1859,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1860,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1861,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1862,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1863,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1864,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1865,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1866,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1867,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1868,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1869,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1870,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1871,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1872,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1873,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1874,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1875,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1876,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1877,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1878,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1879,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1880,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1881,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1882,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1883,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1884,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1885,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1886,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1887,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1888,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1889,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1890,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1891,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1892,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1894,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1895,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1896,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1897,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1899,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1900,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1901,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1902,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1903,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1904,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1905,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1906,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1907,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1908,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1909,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1910,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1911,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1912,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1913,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1914,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1915,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1916,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1917,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1918,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1919,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1920,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1921,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1922,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1923,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1924,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1925,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1926,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1927,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1928,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1929,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1930,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1931,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1932,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1933,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1934,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1935,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1936,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1937,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1938,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1939,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1940,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1941,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1942,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1943,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1944,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1945,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1946,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1947,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1948,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1949,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1950,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1951,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1952,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1953,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1954,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1955,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1956,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1957,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1958,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1959,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1960,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1961,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1962,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1963,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1965,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1966,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1967,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1968,\"textContent\":\"Which shift(s) end at 3pm?\"}]},{\"nodeType\":3,\"id\":1969,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1970,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1971,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1972,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1973,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1974,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1975,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1976,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1977,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1978,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1979,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1980,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1981,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1982,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1983,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1984,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1985,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1986,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1987,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1988,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1989,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1990,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1991,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1992,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1993,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1994,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1995,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1996,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1997,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1998,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1999,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2000,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2001,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2002,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2003,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2004,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2005,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2006,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2007,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2008,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2009,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2010,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2011,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2012,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2013,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2014,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2015,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2016,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2017,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2018,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2019,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2020,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2021,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2022,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2023,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2024,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2025,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2026,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2027,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2028,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2029,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2030,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2031,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2032,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2033,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2034,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2035,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2036,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2037,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2038,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2039,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2040,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2041,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2042,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2043,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2044,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2045,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2047,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2048,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2049,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2050,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2052,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2053,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2054,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2055,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2056,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2057,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2058,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2059,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2060,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2061,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2062,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2063,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2064,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2065,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2066,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2067,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2068,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2069,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2070,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2071,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2072,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2073,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2074,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2075,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2076,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2077,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2078,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2079,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2080,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2081,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2082,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2083,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2084,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2085,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2086,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2087,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2088,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2089,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2090,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2091,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2092,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2093,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2094,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2095,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2096,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2097,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2098,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2099,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2100,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2101,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2102,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2103,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2104,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2105,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2106,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2107,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2108,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2109,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2110,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2111,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2112,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2113,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2114,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2115,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2116,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2118,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":2119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2120,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2121,\"textContent\":\"Coffee breaks happen halfway through a shift. \"},{\"nodeType\":1,\"id\":2122,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":2123,\"textContent\":\"Which shifts share a break at 2pm?\"}]},{\"nodeType\":3,\"id\":2124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2125,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":2126,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2127,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2128,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2129,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2130,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2131,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":2132,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2133,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2134,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2135,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2136,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2137,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2138,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2139,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":2140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2141,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2142,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2143,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2144,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2145,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2146,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2147,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":2148,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2149,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2150,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2151,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2152,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2153,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2154,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2155,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2156,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2157,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2158,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2159,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2160,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2161,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2162,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2163,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2164,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2165,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2166,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2167,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2168,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2169,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2170,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2171,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2172,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2173,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2174,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2175,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2176,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2177,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2178,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2179,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2180,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2181,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2182,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2183,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2184,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2185,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2186,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2187,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2188,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2189,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2190,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2191,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2192,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2193,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2194,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2195,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2196,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2197,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2198,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2199,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2200,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2202,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2203,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2204,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2205,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2211,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2219,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2227,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2235,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2243,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2251,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2259,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2267,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2270,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2271,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2273,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\".strategy\",\"style\":\"display: block;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2274,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2275,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2276,\"textContent\":\"Please describe how to determine what event(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":2277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2278,\"tagName\":\"TEXTAREA\",\"attributes\":{\"id\":\"strategyAnswer\",\"rows\":\"5\",\"cols\":\"80\"}},{\"nodeType\":3,\"id\":2279,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2280,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2281,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2282},{\"nodeType\":3,\"id\":2283,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2284},{\"nodeType\":3,\"id\":2285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2286,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"fixbottom\"},\"childNodes\":[{\"nodeType\":3,\"id\":2287,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2288,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"testingButton\",\"style\":\"display:none;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2289,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2290,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2291,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"strategyButton\",\"style\":\"display: block;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2292,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2293,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2294,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2295,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2296},{\"nodeType\":3,\"id\":2297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2298,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"d3container\"},\"childNodes\":[{\"nodeType\":1,\"id\":2299,\"tagName\":\"svg\",\"attributes\":{\"width\":\"930\",\"height\":\"915\"},\"childNodes\":[{\"nodeType\":1,\"id\":2300,\"tagName\":\"g\",\"attributes\":{\"transform\":\"translate(100,25)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2301,\"tagName\":\"g\",\"attributes\":{\"class\":\"leaders\"}},{\"nodeType\":1,\"id\":2302,\"tagName\":\"g\",\"attributes\":{\"class\":\"static-scaffold\"}}]}]}]},{\"nodeType\":3,\"id\":2303,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2304,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2305},{\"nodeType\":3,\"id\":2306,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2307,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2308,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2309,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2310,\"textContent\":\" \"}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 147, dom: 910, initialDom: 1014",
  "javascriptErrors": []
}