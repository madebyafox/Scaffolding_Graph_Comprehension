var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "0a18a7944d4d39b591194f8ba6de2f43",
  "created": "2018-05-29T16:07:17.8355923-07:00",
  "lastActivity": "2018-05-29T16:07:49.6738924-07:00",
  "pageViews": [
    {
      "id": "05291725c94bbd53ec35c91ee71970fb2c967d22",
      "startTime": "2018-05-29T16:07:17.8355923-07:00",
      "endTime": "2018-05-29T16:07:49.6738924-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/2",
      "visitTime": 31916,
      "engagementTime": 29466,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 31916,
  "engagementTime": 29466,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.39",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.62 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "67.0.3396.62",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=CSU5Z",
    "CONDITION=113"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "7ef5951ed02c41f0693e8d5a651478dd",
  "gdpr": false
}