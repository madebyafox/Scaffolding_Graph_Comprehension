var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "76c7679210749ad35b916d5beec9df55",
  "created": "2018-05-29T16:07:05.1603787-07:00",
  "lastActivity": "2018-05-29T16:07:27.5504484-07:00",
  "pageViews": [
    {
      "id": "052905885dbfaeaacce240cc9267fd8498188a1f",
      "startTime": "2018-05-29T16:07:05.1616182-07:00",
      "endTime": "2018-05-29T16:07:27.5504484-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/2",
      "visitTime": 22450,
      "engagementTime": 22413,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 22450,
  "engagementTime": 22413,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.49",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=93XU7",
    "CONDITION=113"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "732f4a9e7215763bcc276245a08e01b9",
  "gdpr": false
}