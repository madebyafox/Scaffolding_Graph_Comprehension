var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["05223920a7af19fb139c364b71a1902878bc493b"] = {
  "startTime": "2018-05-22T21:13:39.0493186Z",
  "websitePageUrl": "/16",
  "visitTime": 95779,
  "engagementTime": 95327,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1200,
  "tags": [
    "form-interact",
    "submit",
    "click-rage"
  ],
  "session": {
    "id": "55e97e26352d00d0eab0a988f0eed747",
    "created": "2018-05-22T21:13:39.0493186+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.181",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/16",
    "tags": [
      "form-interact",
      "submit",
      "click-rage"
    ],
    "variables": [
      "SID=8LK9M",
      "CONDITION=121"
    ],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "d2cf12624a610576e2919fd0b864ec8e",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/55e97e26352d00d0eab0a988f0eed747/play"
  },
  "events": [
    {
      "t": 1,
      "e": 1,
      "ty": 14,
      "x": 0,
      "y": 1199
    },
    {
      "t": 181,
      "e": 181,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 901,
      "e": 901,
      "ty": 2,
      "x": 564,
      "y": 706
    },
    {
      "t": 1000,
      "e": 1000,
      "ty": 2,
      "x": 544,
      "y": 622
    },
    {
      "t": 1001,
      "e": 1001,
      "ty": 41,
      "x": 50236,
      "y": 34013,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 1037,
      "e": 1037,
      "ty": 6,
      "x": 539,
      "y": 598,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1100,
      "e": 1100,
      "ty": 2,
      "x": 533,
      "y": 578
    },
    {
      "t": 1201,
      "e": 1201,
      "ty": 2,
      "x": 520,
      "y": 545
    },
    {
      "t": 1251,
      "e": 1251,
      "ty": 41,
      "x": 47201,
      "y": 13160,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1301,
      "e": 1301,
      "ty": 2,
      "x": 517,
      "y": 539
    },
    {
      "t": 1400,
      "e": 1400,
      "ty": 2,
      "x": 515,
      "y": 547
    },
    {
      "t": 1420,
      "e": 1420,
      "ty": 3,
      "x": 515,
      "y": 547,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1421,
      "e": 1421,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1468,
      "e": 1468,
      "ty": 4,
      "x": 46976,
      "y": 19632,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1468,
      "e": 1468,
      "ty": 5,
      "x": 515,
      "y": 547,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1501,
      "e": 1501,
      "ty": 41,
      "x": 46976,
      "y": 19632,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2000,
      "e": 2000,
      "ty": 2,
      "x": 491,
      "y": 531
    },
    {
      "t": 2001,
      "e": 2001,
      "ty": 41,
      "x": 44278,
      "y": 6687,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2019,
      "e": 2019,
      "ty": 7,
      "x": 461,
      "y": 521,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2100,
      "e": 2100,
      "ty": 2,
      "x": 401,
      "y": 505
    },
    {
      "t": 2200,
      "e": 2200,
      "ty": 2,
      "x": 332,
      "y": 501
    },
    {
      "t": 2251,
      "e": 2251,
      "ty": 41,
      "x": 25731,
      "y": 12324,
      "ta": "#.strategy > p"
    },
    {
      "t": 2300,
      "e": 2300,
      "ty": 2,
      "x": 326,
      "y": 500
    },
    {
      "t": 2401,
      "e": 2401,
      "ty": 2,
      "x": 323,
      "y": 501
    },
    {
      "t": 2445,
      "e": 2445,
      "ty": 3,
      "x": 323,
      "y": 501,
      "ta": "#.strategy > p"
    },
    {
      "t": 2445,
      "e": 2445,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2500,
      "e": 2500,
      "ty": 2,
      "x": 329,
      "y": 501
    },
    {
      "t": 2500,
      "e": 2500,
      "ty": 41,
      "x": 26068,
      "y": 14664,
      "ta": "#.strategy > p"
    },
    {
      "t": 2601,
      "e": 2601,
      "ty": 2,
      "x": 402,
      "y": 501
    },
    {
      "t": 2700,
      "e": 2700,
      "ty": 2,
      "x": 640,
      "y": 519
    },
    {
      "t": 2720,
      "e": 2720,
      "ty": 6,
      "x": 676,
      "y": 522,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2736,
      "e": 2736,
      "ty": 7,
      "x": 685,
      "y": 524,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2750,
      "e": 2750,
      "ty": 41,
      "x": 281,
      "y": 27406,
      "ta": "> div.stimulus > div:[2]"
    },
    {
      "t": 2800,
      "e": 2800,
      "ty": 2,
      "x": 692,
      "y": 524
    },
    {
      "t": 2900,
      "e": 2900,
      "ty": 2,
      "x": 696,
      "y": 524
    },
    {
      "t": 2948,
      "e": 2948,
      "ty": 4,
      "x": 912,
      "y": 27406,
      "ta": "> div.stimulus > div:[2]"
    },
    {
      "t": 2949,
      "e": 2949,
      "ty": 5,
      "x": 696,
      "y": 524,
      "ta": "> div.stimulus"
    },
    {
      "t": 3001,
      "e": 3001,
      "ty": 41,
      "x": 912,
      "y": 27406,
      "ta": "> div.stimulus > div:[2]"
    },
    {
      "t": 3071,
      "e": 3071,
      "ty": 6,
      "x": 680,
      "y": 533,
      "ta": "#strategyAnswer"
    },
    {
      "t": 3100,
      "e": 3100,
      "ty": 2,
      "x": 667,
      "y": 538
    },
    {
      "t": 3201,
      "e": 3201,
      "ty": 2,
      "x": 631,
      "y": 545
    },
    {
      "t": 3251,
      "e": 3251,
      "ty": 41,
      "x": 60016,
      "y": 18014,
      "ta": "#strategyAnswer"
    },
    {
      "t": 3300,
      "e": 3300,
      "ty": 3,
      "x": 631,
      "y": 545,
      "ta": "#strategyAnswer"
    },
    {
      "t": 3302,
      "e": 3302,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 3372,
      "e": 3372,
      "ty": 4,
      "x": 60016,
      "y": 18014,
      "ta": "#strategyAnswer"
    },
    {
      "t": 3372,
      "e": 3372,
      "ty": 5,
      "x": 631,
      "y": 545,
      "ta": "#strategyAnswer"
    },
    {
      "t": 4357,
      "e": 4357,
      "ty": 3,
      "x": 631,
      "y": 545,
      "ta": "#strategyAnswer"
    },
    {
      "t": 4484,
      "e": 4484,
      "ty": 4,
      "x": 60016,
      "y": 18014,
      "ta": "#strategyAnswer"
    },
    {
      "t": 4484,
      "e": 4484,
      "ty": 5,
      "x": 631,
      "y": 545,
      "ta": "#strategyAnswer"
    },
    {
      "t": 7600,
      "e": 7600,
      "ty": 2,
      "x": 630,
      "y": 545
    },
    {
      "t": 7750,
      "e": 7750,
      "ty": 41,
      "x": 59903,
      "y": 18014,
      "ta": "#strategyAnswer"
    },
    {
      "t": 7890,
      "e": 7890,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 7890,
      "e": 7890,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 7976,
      "e": 7976,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "l"
    },
    {
      "t": 8096,
      "e": 8096,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 8097,
      "e": 8097,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8160,
      "e": 8160,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "lo"
    },
    {
      "t": 8248,
      "e": 8248,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 8249,
      "e": 8249,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8279,
      "e": 8279,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "loo"
    },
    {
      "t": 8367,
      "e": 8367,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "75"
    },
    {
      "t": 8368,
      "e": 8368,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8513,
      "e": 8513,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 8513,
      "e": 8513,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8543,
      "e": 8543,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look "
    },
    {
      "t": 8655,
      "e": 8655,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 8656,
      "e": 8656,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8664,
      "e": 8664,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 8776,
      "e": 8776,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 8777,
      "e": 8777,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8859,
      "e": 8859,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 8860,
      "e": 8860,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 8861,
      "e": 8861,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8871,
      "e": 8871,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 8928,
      "e": 8928,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 8983,
      "e": 8983,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 8984,
      "e": 8984,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9056,
      "e": 9056,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 9056,
      "e": 9056,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9071,
      "e": 9071,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||th"
    },
    {
      "t": 9136,
      "e": 9136,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 9176,
      "e": 9176,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 9176,
      "e": 9176,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9255,
      "e": 9255,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 9255,
      "e": 9255,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9288,
      "e": 9288,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e "
    },
    {
      "t": 9385,
      "e": 9385,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 9689,
      "e": 9689,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 9689,
      "e": 9689,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9802,
      "e": 9802,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look at the h"
    },
    {
      "t": 9824,
      "e": 9824,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 9824,
      "e": 9824,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9831,
      "e": 9831,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ho"
    },
    {
      "t": 9904,
      "e": 9904,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 10000,
      "e": 10000,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 10159,
      "e": 10159,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 10216,
      "e": 10216,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look at the h"
    },
    {
      "t": 10328,
      "e": 10328,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 10367,
      "e": 10367,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look at the "
    },
    {
      "t": 10864,
      "e": 10864,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "86"
    },
    {
      "t": 10864,
      "e": 10864,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10943,
      "e": 10943,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||v"
    },
    {
      "t": 11073,
      "e": 11073,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 11073,
      "e": 11073,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11152,
      "e": 11152,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 11152,
      "e": 11152,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11240,
      "e": 11240,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||er"
    },
    {
      "t": 11255,
      "e": 11255,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 11393,
      "e": 11393,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 11393,
      "e": 11393,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11463,
      "e": 11463,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 11511,
      "e": 11511,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 11512,
      "e": 11512,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11584,
      "e": 11584,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 11649,
      "e": 11649,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 11649,
      "e": 11649,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11735,
      "e": 11735,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||c"
    },
    {
      "t": 11816,
      "e": 11816,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 11816,
      "e": 11816,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11928,
      "e": 11928,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 11929,
      "e": 11929,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11936,
      "e": 11936,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||al"
    },
    {
      "t": 11951,
      "e": 11951,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 11952,
      "e": 11952,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12016,
      "e": 12016,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 12120,
      "e": 12120,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 12184,
      "e": 12184,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 12185,
      "e": 12185,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12287,
      "e": 12287,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 12287,
      "e": 12287,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 12288,
      "e": 12288,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12402,
      "e": 12402,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look at the vertical li"
    },
    {
      "t": 12424,
      "e": 12424,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 12447,
      "e": 12447,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 12447,
      "e": 12447,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12455,
      "e": 12455,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 12455,
      "e": 12455,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12487,
      "e": 12487,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ni"
    },
    {
      "t": 12552,
      "e": 12552,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 12568,
      "e": 12568,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 12568,
      "e": 12568,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12656,
      "e": 12656,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 12680,
      "e": 12680,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 12680,
      "e": 12680,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12791,
      "e": 12791,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 13201,
      "e": 13201,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 13231,
      "e": 13231,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look at the vertical linie"
    },
    {
      "t": 13335,
      "e": 13335,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 13376,
      "e": 13376,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look at the vertical lini"
    },
    {
      "t": 13448,
      "e": 13448,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 13511,
      "e": 13511,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look at the vertical lin"
    },
    {
      "t": 13575,
      "e": 13575,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 13576,
      "e": 13576,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13656,
      "e": 13656,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 13672,
      "e": 13672,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 13673,
      "e": 13673,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13751,
      "e": 13751,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 13856,
      "e": 13856,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 13857,
      "e": 13857,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13937,
      "e": 13937,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 13937,
      "e": 13937,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13951,
      "e": 13951,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||go"
    },
    {
      "t": 14087,
      "e": 14087,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 14088,
      "e": 14088,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14120,
      "e": 14120,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 14120,
      "e": 14120,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14127,
      "e": 14127,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||in"
    },
    {
      "t": 14159,
      "e": 14159,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 14249,
      "e": 14249,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 14249,
      "e": 14249,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14296,
      "e": 14296,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 14336,
      "e": 14336,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 14337,
      "e": 14337,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 14338,
      "e": 14338,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14424,
      "e": 14424,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 14712,
      "e": 14712,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 14713,
      "e": 14713,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14792,
      "e": 14792,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||u"
    },
    {
      "t": 14944,
      "e": 14944,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 14945,
      "e": 14945,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15023,
      "e": 15023,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 15024,
      "e": 15024,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15071,
      "e": 15071,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p "
    },
    {
      "t": 15160,
      "e": 15160,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 15160,
      "e": 15160,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 15161,
      "e": 15161,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15207,
      "e": 15207,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||f"
    },
    {
      "t": 15327,
      "e": 15327,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 15328,
      "e": 15328,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15392,
      "e": 15392,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 15408,
      "e": 15408,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 15408,
      "e": 15408,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15495,
      "e": 15495,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 15496,
      "e": 15496,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15544,
      "e": 15544,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||om"
    },
    {
      "t": 15592,
      "e": 15592,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 15592,
      "e": 15592,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15665,
      "e": 15665,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 15760,
      "e": 15760,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 15984,
      "e": 15984,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "81"
    },
    {
      "t": 15985,
      "e": 15985,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15987,
      "e": 15987,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 15989,
      "e": 15989,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16047,
      "e": 16047,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||q1"
    },
    {
      "t": 16072,
      "e": 16072,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 16536,
      "e": 16536,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 16591,
      "e": 16591,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look at the vertical line going up from q"
    },
    {
      "t": 16841,
      "e": 16592,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 16845,
      "e": 16596,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16976,
      "e": 16727,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 17000,
      "e": 16751,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 17040,
      "e": 16791,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 17152,
      "e": 16903,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 17199,
      "e": 16950,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look at the vertical line going up from "
    },
    {
      "t": 17303,
      "e": 17054,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 17304,
      "e": 17055,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17393,
      "e": 17144,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 17393,
      "e": 17144,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17447,
      "e": 17198,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||12"
    },
    {
      "t": 17471,
      "e": 17222,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 17471,
      "e": 17222,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17544,
      "e": 17295,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 17648,
      "e": 17399,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 17664,
      "e": 17415,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 17665,
      "e": 17416,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17671,
      "e": 17422,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 17802,
      "e": 17553,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look at the vertical line going up from 12  "
    },
    {
      "t": 18065,
      "e": 17816,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 18066,
      "e": 17817,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18143,
      "e": 17894,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 18143,
      "e": 17894,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18199,
      "e": 17950,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||pm"
    },
    {
      "t": 18304,
      "e": 18055,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 19807,
      "e": 19558,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 19847,
      "e": 19598,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look at the vertical line going up from 12  p"
    },
    {
      "t": 19953,
      "e": 19704,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 19999,
      "e": 19750,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look at the vertical line going up from 12  "
    },
    {
      "t": 20103,
      "e": 19854,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 20167,
      "e": 19918,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look at the vertical line going up from 12 "
    },
    {
      "t": 20640,
      "e": 20391,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 20727,
      "e": 20478,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look at the vertical line going up from 12"
    },
    {
      "t": 21160,
      "e": 20911,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 21161,
      "e": 20912,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21240,
      "e": 20991,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 21496,
      "e": 21247,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 21497,
      "e": 21248,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21503,
      "e": 21254,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 21504,
      "e": 21255,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21648,
      "e": 21399,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||mp"
    },
    {
      "t": 21648,
      "e": 21399,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 21648,
      "e": 21399,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21720,
      "e": 21471,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 21856,
      "e": 21607,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 22152,
      "e": 21903,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 22153,
      "e": 21904,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22232,
      "e": 21983,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 22264,
      "e": 22015,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 22265,
      "e": 22016,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22383,
      "e": 22134,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 22384,
      "e": 22135,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22423,
      "e": 22174,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ar"
    },
    {
      "t": 22488,
      "e": 22239,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 22512,
      "e": 22263,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "75"
    },
    {
      "t": 22513,
      "e": 22264,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22584,
      "e": 22335,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 22585,
      "e": 22336,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22648,
      "e": 22399,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||k "
    },
    {
      "t": 22744,
      "e": 22495,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 22832,
      "e": 22583,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 22833,
      "e": 22584,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22911,
      "e": 22662,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 22912,
      "e": 22663,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22975,
      "e": 22726,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||on"
    },
    {
      "t": 23000,
      "e": 22751,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 23000,
      "e": 22751,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23064,
      "e": 22815,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 23128,
      "e": 22879,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 23136,
      "e": 22887,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 23137,
      "e": 22888,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23215,
      "e": 22966,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 23215,
      "e": 22966,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23223,
      "e": 22974,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||th"
    },
    {
      "t": 23304,
      "e": 23055,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 23352,
      "e": 23103,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 23353,
      "e": 23104,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23409,
      "e": 23160,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 23410,
      "e": 23161,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23431,
      "e": 23182,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e "
    },
    {
      "t": 23519,
      "e": 23270,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 23744,
      "e": 23495,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 23745,
      "e": 23496,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23847,
      "e": 23598,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 23871,
      "e": 23622,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 23872,
      "e": 23623,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23992,
      "e": 23743,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 24184,
      "e": 23935,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 24185,
      "e": 23936,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24240,
      "e": 23991,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 24484,
      "e": 24235,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 24484,
      "e": 24235,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24530,
      "e": 24281,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 24739,
      "e": 24490,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "90"
    },
    {
      "t": 24741,
      "e": 24492,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24858,
      "e": 24609,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||z"
    },
    {
      "t": 24980,
      "e": 24731,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 24980,
      "e": 24731,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25098,
      "e": 24849,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 25099,
      "e": 24850,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25147,
      "e": 24850,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||on"
    },
    {
      "t": 25203,
      "e": 24906,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 25203,
      "e": 24906,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25211,
      "e": 24914,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 25275,
      "e": 24978,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 25411,
      "e": 25114,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 25412,
      "e": 25115,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25491,
      "e": 25194,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 25491,
      "e": 25194,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25515,
      "e": 25218,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||al"
    },
    {
      "t": 25555,
      "e": 25258,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 25556,
      "e": 25259,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25611,
      "e": 25314,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 25691,
      "e": 25394,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 25875,
      "e": 25578,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 25876,
      "e": 25579,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25979,
      "e": 25682,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 26339,
      "e": 26042,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 26340,
      "e": 26043,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26443,
      "e": 26146,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||x"
    },
    {
      "t": 26451,
      "e": 26154,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 26452,
      "e": 26155,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26522,
      "e": 26225,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 26587,
      "e": 26290,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 26587,
      "e": 26290,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26667,
      "e": 26370,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 27304,
      "e": 27007,
      "ty": 2,
      "x": 580,
      "y": 542
    },
    {
      "t": 27404,
      "e": 27107,
      "ty": 2,
      "x": 467,
      "y": 539
    },
    {
      "t": 27504,
      "e": 27207,
      "ty": 2,
      "x": 464,
      "y": 538
    },
    {
      "t": 27505,
      "e": 27208,
      "ty": 41,
      "x": 41243,
      "y": 12351,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27604,
      "e": 27307,
      "ty": 2,
      "x": 433,
      "y": 530
    },
    {
      "t": 27704,
      "e": 27407,
      "ty": 2,
      "x": 420,
      "y": 530
    },
    {
      "t": 27754,
      "e": 27457,
      "ty": 41,
      "x": 36185,
      "y": 5878,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27804,
      "e": 27507,
      "ty": 2,
      "x": 419,
      "y": 530
    },
    {
      "t": 28004,
      "e": 27707,
      "ty": 2,
      "x": 418,
      "y": 531
    },
    {
      "t": 28004,
      "e": 27707,
      "ty": 41,
      "x": 36073,
      "y": 6687,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28104,
      "e": 27807,
      "ty": 2,
      "x": 421,
      "y": 532
    },
    {
      "t": 28204,
      "e": 27907,
      "ty": 2,
      "x": 422,
      "y": 532
    },
    {
      "t": 28254,
      "e": 27957,
      "ty": 41,
      "x": 36859,
      "y": 7496,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28304,
      "e": 28007,
      "ty": 2,
      "x": 426,
      "y": 532
    },
    {
      "t": 28361,
      "e": 28064,
      "ty": 3,
      "x": 426,
      "y": 532,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28463,
      "e": 28166,
      "ty": 4,
      "x": 36972,
      "y": 7496,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28463,
      "e": 28166,
      "ty": 5,
      "x": 426,
      "y": 532,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28504,
      "e": 28207,
      "ty": 41,
      "x": 36972,
      "y": 7496,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28604,
      "e": 28307,
      "ty": 2,
      "x": 439,
      "y": 564
    },
    {
      "t": 28704,
      "e": 28407,
      "ty": 2,
      "x": 441,
      "y": 567
    },
    {
      "t": 28754,
      "e": 28457,
      "ty": 41,
      "x": 38658,
      "y": 35814,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29228,
      "e": 28931,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 29306,
      "e": 29009,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look at the vertical line going up from 12 p mark on the horizontal axis"
    },
    {
      "t": 29827,
      "e": 29530,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "39"
    },
    {
      "t": 30010,
      "e": 29713,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 30027,
      "e": 29730,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 30027,
      "e": 29730,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30083,
      "e": 29786,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look at the vertical line going up from 12 pm mark on the horizontal axis"
    },
    {
      "t": 30204,
      "e": 29907,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look at the vertical line going up from 12 pm mark on the horizontal axis"
    },
    {
      "t": 30646,
      "e": 30349,
      "ty": 7,
      "x": 441,
      "y": 604,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30704,
      "e": 30407,
      "ty": 2,
      "x": 441,
      "y": 639
    },
    {
      "t": 30754,
      "e": 30457,
      "ty": 41,
      "x": 57299,
      "y": 13936,
      "ta": "> div.stimulus > div > div:[3]"
    },
    {
      "t": 30764,
      "e": 30467,
      "ty": 6,
      "x": 440,
      "y": 657,
      "ta": "#strategyButton"
    },
    {
      "t": 30804,
      "e": 30507,
      "ty": 2,
      "x": 438,
      "y": 680
    },
    {
      "t": 30935,
      "e": 30638,
      "ty": 3,
      "x": 438,
      "y": 680,
      "ta": "#strategyButton"
    },
    {
      "t": 30936,
      "e": 30639,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look at the vertical line going up from 12 pm mark on the horizontal axis"
    },
    {
      "t": 30936,
      "e": 30639,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30937,
      "e": 30640,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 31003,
      "e": 30706,
      "ty": 41,
      "x": 54288,
      "y": 48699,
      "ta": "#strategyButton"
    },
    {
      "t": 31047,
      "e": 30750,
      "ty": 4,
      "x": 54288,
      "y": 48699,
      "ta": "#strategyButton"
    },
    {
      "t": 31057,
      "e": 30760,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 31058,
      "e": 30761,
      "ty": 5,
      "x": 438,
      "y": 680,
      "ta": "#strategyButton"
    },
    {
      "t": 31066,
      "e": 30769,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 31703,
      "e": 31406,
      "ty": 2,
      "x": 517,
      "y": 656
    },
    {
      "t": 31754,
      "e": 31457,
      "ty": 41,
      "x": 17769,
      "y": 35343,
      "ta": "html > body"
    },
    {
      "t": 31803,
      "e": 31506,
      "ty": 2,
      "x": 524,
      "y": 646
    },
    {
      "t": 32066,
      "e": 31769,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 32703,
      "e": 32406,
      "ty": 2,
      "x": 555,
      "y": 644
    },
    {
      "t": 32753,
      "e": 32456,
      "ty": 41,
      "x": 21971,
      "y": 34401,
      "ta": "html > body"
    },
    {
      "t": 32803,
      "e": 32506,
      "ty": 2,
      "x": 678,
      "y": 609
    },
    {
      "t": 32903,
      "e": 32606,
      "ty": 2,
      "x": 687,
      "y": 591
    },
    {
      "t": 33003,
      "e": 32706,
      "ty": 2,
      "x": 742,
      "y": 591
    },
    {
      "t": 33003,
      "e": 32706,
      "ty": 41,
      "x": 25277,
      "y": 32296,
      "ta": "html > body"
    },
    {
      "t": 33103,
      "e": 32806,
      "ty": 2,
      "x": 880,
      "y": 595
    },
    {
      "t": 33203,
      "e": 32906,
      "ty": 2,
      "x": 929,
      "y": 586
    },
    {
      "t": 33249,
      "e": 32952,
      "ty": 6,
      "x": 939,
      "y": 573,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 33253,
      "e": 32956,
      "ty": 41,
      "x": 28333,
      "y": 59293,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 33303,
      "e": 33006,
      "ty": 2,
      "x": 940,
      "y": 571
    },
    {
      "t": 33374,
      "e": 33077,
      "ty": 3,
      "x": 940,
      "y": 571,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 33375,
      "e": 33078,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 33463,
      "e": 33166,
      "ty": 4,
      "x": 28549,
      "y": 53052,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 33463,
      "e": 33166,
      "ty": 5,
      "x": 940,
      "y": 571,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 33503,
      "e": 33206,
      "ty": 41,
      "x": 28549,
      "y": 53052,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 34786,
      "e": 34489,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "50"
    },
    {
      "t": 34787,
      "e": 34490,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 34858,
      "e": 34561,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "48"
    },
    {
      "t": 34859,
      "e": 34562,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 34915,
      "e": 34563,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "20"
    },
    {
      "t": 34995,
      "e": 34643,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "20"
    },
    {
      "t": 35123,
      "e": 34771,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "192"
    },
    {
      "t": 35124,
      "e": 34772,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 35234,
      "e": 34882,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "20`"
    },
    {
      "t": 35635,
      "e": 35283,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "8"
    },
    {
      "t": 35754,
      "e": 35402,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "20"
    },
    {
      "t": 36419,
      "e": 36067,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "9"
    },
    {
      "t": 36420,
      "e": 36068,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "20"
    },
    {
      "t": 36421,
      "e": 36069,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 36422,
      "e": 36070,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 36564,
      "e": 36212,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": ""
    },
    {
      "t": 36659,
      "e": 36307,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 36908,
      "e": 36556,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "76"
    },
    {
      "t": 36908,
      "e": 36556,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 36962,
      "e": 36610,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "L"
    },
    {
      "t": 37018,
      "e": 36666,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "L"
    },
    {
      "t": 37051,
      "e": 36699,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "69"
    },
    {
      "t": 37051,
      "e": 36699,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 37131,
      "e": 36779,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Le"
    },
    {
      "t": 37164,
      "e": 36812,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "66"
    },
    {
      "t": 37164,
      "e": 36812,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 37235,
      "e": 36883,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Leb"
    },
    {
      "t": 37315,
      "e": 36963,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "65"
    },
    {
      "t": 37315,
      "e": 36963,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 37403,
      "e": 37051,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "78"
    },
    {
      "t": 37404,
      "e": 37052,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 37435,
      "e": 37083,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Leban"
    },
    {
      "t": 37498,
      "e": 37146,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 37891,
      "e": 37539,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "79"
    },
    {
      "t": 37892,
      "e": 37540,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 37980,
      "e": 37628,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "78"
    },
    {
      "t": 37980,
      "e": 37628,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 37987,
      "e": 37635,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||on"
    },
    {
      "t": 38083,
      "e": 37731,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 38355,
      "e": 38003,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "13"
    },
    {
      "t": 38356,
      "e": 38004,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 38458,
      "e": 38106,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||\n"
    },
    {
      "t": 39500,
      "e": 39148,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "8"
    },
    {
      "t": 39604,
      "e": 39252,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Lebanon"
    },
    {
      "t": 39618,
      "e": 39266,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Lebanon"
    },
    {
      "t": 40003,
      "e": 39651,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 40404,
      "e": 40052,
      "ty": 2,
      "x": 940,
      "y": 572
    },
    {
      "t": 40408,
      "e": 40056,
      "ty": 7,
      "x": 940,
      "y": 578,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 40503,
      "e": 40151,
      "ty": 2,
      "x": 947,
      "y": 626
    },
    {
      "t": 40504,
      "e": 40152,
      "ty": 41,
      "x": 30063,
      "y": 58513,
      "ta": "#jspsych-survey-text-1 > p"
    },
    {
      "t": 40554,
      "e": 40202,
      "ty": 6,
      "x": 950,
      "y": 652,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 40588,
      "e": 40236,
      "ty": 7,
      "x": 956,
      "y": 669,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 40603,
      "e": 40251,
      "ty": 2,
      "x": 956,
      "y": 669
    },
    {
      "t": 40638,
      "e": 40286,
      "ty": 6,
      "x": 959,
      "y": 676,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 40704,
      "e": 40352,
      "ty": 2,
      "x": 968,
      "y": 700
    },
    {
      "t": 40753,
      "e": 40401,
      "ty": 41,
      "x": 37148,
      "y": 47661,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 41111,
      "e": 40759,
      "ty": 3,
      "x": 968,
      "y": 700,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 41112,
      "e": 40760,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Lebanon"
    },
    {
      "t": 41114,
      "e": 40762,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 41114,
      "e": 40762,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 41504,
      "e": 41152,
      "ty": 4,
      "x": 37148,
      "y": 47661,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 41505,
      "e": 41153,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 41506,
      "e": 41154,
      "ty": 5,
      "x": 968,
      "y": 700,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 41507,
      "e": 41155,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 41604,
      "e": 41252,
      "ty": 2,
      "x": 968,
      "y": 699
    },
    {
      "t": 41704,
      "e": 41352,
      "ty": 2,
      "x": 962,
      "y": 688
    },
    {
      "t": 41754,
      "e": 41402,
      "ty": 41,
      "x": 32853,
      "y": 37670,
      "ta": "html > body"
    },
    {
      "t": 42520,
      "e": 42168,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 42904,
      "e": 42552,
      "ty": 2,
      "x": 962,
      "y": 694
    },
    {
      "t": 43004,
      "e": 42652,
      "ty": 2,
      "x": 962,
      "y": 705
    },
    {
      "t": 43004,
      "e": 42652,
      "ty": 41,
      "x": 35423,
      "y": 39321,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 43104,
      "e": 42752,
      "ty": 2,
      "x": 966,
      "y": 650
    },
    {
      "t": 43203,
      "e": 42851,
      "ty": 2,
      "x": 920,
      "y": 421
    },
    {
      "t": 43254,
      "e": 42902,
      "ty": 41,
      "x": 16275,
      "y": 39789,
      "ta": "#jspsych-survey-multi-choice-option-0-3"
    },
    {
      "t": 43304,
      "e": 42952,
      "ty": 2,
      "x": 866,
      "y": 280
    },
    {
      "t": 43403,
      "e": 43051,
      "ty": 2,
      "x": 835,
      "y": 220
    },
    {
      "t": 43504,
      "e": 43152,
      "ty": 41,
      "x": 3222,
      "y": 17005,
      "ta": "#jspsych-survey-multi-choice-0"
    },
    {
      "t": 43603,
      "e": 43251,
      "ty": 2,
      "x": 839,
      "y": 220
    },
    {
      "t": 43704,
      "e": 43352,
      "ty": 2,
      "x": 850,
      "y": 222
    },
    {
      "t": 43754,
      "e": 43402,
      "ty": 41,
      "x": 7019,
      "y": 18665,
      "ta": "#jspsych-survey-multi-choice-0"
    },
    {
      "t": 43804,
      "e": 43452,
      "ty": 2,
      "x": 854,
      "y": 226
    },
    {
      "t": 43904,
      "e": 43552,
      "ty": 2,
      "x": 855,
      "y": 230
    },
    {
      "t": 44004,
      "e": 43652,
      "ty": 41,
      "x": 27496,
      "y": 3276,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 44104,
      "e": 43752,
      "ty": 2,
      "x": 858,
      "y": 234
    },
    {
      "t": 44253,
      "e": 43901,
      "ty": 41,
      "x": 29952,
      "y": 16383,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 45496,
      "e": 45144,
      "ty": 3,
      "x": 858,
      "y": 234,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 45615,
      "e": 45263,
      "ty": 4,
      "x": 29952,
      "y": 16383,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 45615,
      "e": 45263,
      "ty": 5,
      "x": 858,
      "y": 234,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 45617,
      "e": 45265,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 45619,
      "e": 45267,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf",
      "v": "English"
    },
    {
      "t": 45804,
      "e": 45452,
      "ty": 2,
      "x": 858,
      "y": 239
    },
    {
      "t": 45904,
      "e": 45552,
      "ty": 2,
      "x": 871,
      "y": 273
    },
    {
      "t": 46004,
      "e": 45652,
      "ty": 2,
      "x": 907,
      "y": 356
    },
    {
      "t": 46004,
      "e": 45652,
      "ty": 41,
      "x": 20309,
      "y": 2340,
      "ta": "#jspsych-survey-multi-choice-1 > p"
    },
    {
      "t": 46104,
      "e": 45752,
      "ty": 2,
      "x": 921,
      "y": 401
    },
    {
      "t": 46203,
      "e": 45851,
      "ty": 2,
      "x": 921,
      "y": 402
    },
    {
      "t": 46254,
      "e": 45902,
      "ty": 41,
      "x": 21971,
      "y": 16383,
      "ta": "#jspsych-survey-multi-choice-option-1-0"
    },
    {
      "t": 46304,
      "e": 45952,
      "ty": 2,
      "x": 901,
      "y": 413
    },
    {
      "t": 46404,
      "e": 46052,
      "ty": 2,
      "x": 870,
      "y": 420
    },
    {
      "t": 46503,
      "e": 46151,
      "ty": 2,
      "x": 860,
      "y": 421
    },
    {
      "t": 46504,
      "e": 46152,
      "ty": 41,
      "x": 45159,
      "y": 52428,
      "ta": "#jspsych-survey-multi-choice-option-1-0 > label"
    },
    {
      "t": 46603,
      "e": 46251,
      "ty": 2,
      "x": 857,
      "y": 424
    },
    {
      "t": 46704,
      "e": 46352,
      "ty": 2,
      "x": 857,
      "y": 426
    },
    {
      "t": 46755,
      "e": 46353,
      "ty": 41,
      "x": 28418,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-1-1 > label"
    },
    {
      "t": 46804,
      "e": 46402,
      "ty": 2,
      "x": 857,
      "y": 451
    },
    {
      "t": 46903,
      "e": 46501,
      "ty": 2,
      "x": 860,
      "y": 460
    },
    {
      "t": 47003,
      "e": 46601,
      "ty": 2,
      "x": 861,
      "y": 470
    },
    {
      "t": 47004,
      "e": 46602,
      "ty": 41,
      "x": 41834,
      "y": 29490,
      "ta": "#jspsych-survey-multi-choice-option-1-2 > label"
    },
    {
      "t": 47104,
      "e": 46702,
      "ty": 2,
      "x": 860,
      "y": 492
    },
    {
      "t": 47204,
      "e": 46802,
      "ty": 2,
      "x": 857,
      "y": 503
    },
    {
      "t": 47254,
      "e": 46852,
      "ty": 41,
      "x": 31035,
      "y": 52428,
      "ta": "#jspsych-survey-multi-choice-option-1-3 > label"
    },
    {
      "t": 47303,
      "e": 46901,
      "ty": 2,
      "x": 855,
      "y": 509
    },
    {
      "t": 47404,
      "e": 47002,
      "ty": 2,
      "x": 854,
      "y": 512
    },
    {
      "t": 47505,
      "e": 47103,
      "ty": 41,
      "x": 7731,
      "y": 63194,
      "ta": "#jspsych-survey-multi-choice-option-1-3"
    },
    {
      "t": 47604,
      "e": 47202,
      "ty": 2,
      "x": 854,
      "y": 522
    },
    {
      "t": 47703,
      "e": 47301,
      "ty": 2,
      "x": 852,
      "y": 528
    },
    {
      "t": 47754,
      "e": 47352,
      "ty": 41,
      "x": 35784,
      "y": 36044,
      "ta": "#jspsych-survey-multi-choice-option-1-4 > label"
    },
    {
      "t": 47804,
      "e": 47402,
      "ty": 2,
      "x": 852,
      "y": 527
    },
    {
      "t": 47904,
      "e": 47502,
      "ty": 2,
      "x": 852,
      "y": 511
    },
    {
      "t": 48004,
      "e": 47602,
      "ty": 2,
      "x": 851,
      "y": 506
    },
    {
      "t": 48004,
      "e": 47602,
      "ty": 41,
      "x": 26547,
      "y": 55704,
      "ta": "#jspsych-survey-multi-choice-option-1-3 > label"
    },
    {
      "t": 48103,
      "e": 47701,
      "ty": 2,
      "x": 851,
      "y": 504
    },
    {
      "t": 48254,
      "e": 47852,
      "ty": 41,
      "x": 26547,
      "y": 49151,
      "ta": "#jspsych-survey-multi-choice-option-1-3 > label"
    },
    {
      "t": 48404,
      "e": 48002,
      "ty": 2,
      "x": 851,
      "y": 503
    },
    {
      "t": 48407,
      "e": 48005,
      "ty": 3,
      "x": 851,
      "y": 503,
      "ta": "#jspsych-survey-multi-choice-option-1-3 > label"
    },
    {
      "t": 48408,
      "e": 48006,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 48505,
      "e": 48103,
      "ty": 41,
      "x": 26547,
      "y": 45874,
      "ta": "#jspsych-survey-multi-choice-option-1-3 > label"
    },
    {
      "t": 48511,
      "e": 48109,
      "ty": 4,
      "x": 26547,
      "y": 45874,
      "ta": "#jspsych-survey-multi-choice-option-1-3 > label"
    },
    {
      "t": 48512,
      "e": 48110,
      "ty": 5,
      "x": 851,
      "y": 503,
      "ta": "#jspsych-survey-multi-choice-option-1-3 > label"
    },
    {
      "t": 48512,
      "e": 48110,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 48514,
      "e": 48112,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf",
      "v": "Fourth"
    },
    {
      "t": 48904,
      "e": 48502,
      "ty": 2,
      "x": 854,
      "y": 524
    },
    {
      "t": 49004,
      "e": 48602,
      "ty": 2,
      "x": 867,
      "y": 585
    },
    {
      "t": 49004,
      "e": 48602,
      "ty": 41,
      "x": 45246,
      "y": 39321,
      "ta": "#jspsych-survey-multi-choice-option-1-6 > label"
    },
    {
      "t": 49104,
      "e": 48702,
      "ty": 2,
      "x": 871,
      "y": 625
    },
    {
      "t": 49204,
      "e": 48802,
      "ty": 2,
      "x": 871,
      "y": 661
    },
    {
      "t": 49254,
      "e": 48852,
      "ty": 41,
      "x": 11766,
      "y": 7021,
      "ta": "#jspsych-survey-multi-choice-option-2-0"
    },
    {
      "t": 49304,
      "e": 48902,
      "ty": 2,
      "x": 871,
      "y": 666
    },
    {
      "t": 49504,
      "e": 49102,
      "ty": 2,
      "x": 872,
      "y": 683
    },
    {
      "t": 49505,
      "e": 49103,
      "ty": 41,
      "x": 13580,
      "y": 58981,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 49604,
      "e": 49202,
      "ty": 2,
      "x": 878,
      "y": 723
    },
    {
      "t": 49704,
      "e": 49302,
      "ty": 2,
      "x": 881,
      "y": 753
    },
    {
      "t": 49754,
      "e": 49302,
      "ty": 41,
      "x": 25693,
      "y": 42597,
      "ta": "#jspsych-survey-multi-choice-option-2-3 > label"
    },
    {
      "t": 49803,
      "e": 49351,
      "ty": 2,
      "x": 884,
      "y": 771
    },
    {
      "t": 49904,
      "e": 49452,
      "ty": 2,
      "x": 888,
      "y": 804
    },
    {
      "t": 50004,
      "e": 49552,
      "ty": 2,
      "x": 891,
      "y": 823
    },
    {
      "t": 50004,
      "e": 49552,
      "ty": 41,
      "x": 41067,
      "y": 58981,
      "ta": "#jspsych-survey-multi-choice-option-2-5 > label"
    },
    {
      "t": 50104,
      "e": 49652,
      "ty": 2,
      "x": 888,
      "y": 832
    },
    {
      "t": 50204,
      "e": 49752,
      "ty": 2,
      "x": 884,
      "y": 840
    },
    {
      "t": 50254,
      "e": 49802,
      "ty": 41,
      "x": 42680,
      "y": 39321,
      "ta": "#jspsych-survey-multi-choice-option-2-6 > label"
    },
    {
      "t": 50304,
      "e": 49852,
      "ty": 2,
      "x": 881,
      "y": 846
    },
    {
      "t": 50504,
      "e": 50052,
      "ty": 2,
      "x": 876,
      "y": 819
    },
    {
      "t": 50504,
      "e": 50052,
      "ty": 41,
      "x": 32214,
      "y": 45874,
      "ta": "#jspsych-survey-multi-choice-option-2-5 > label"
    },
    {
      "t": 50904,
      "e": 50452,
      "ty": 2,
      "x": 876,
      "y": 812
    },
    {
      "t": 51004,
      "e": 50552,
      "ty": 2,
      "x": 873,
      "y": 798
    },
    {
      "t": 51004,
      "e": 50552,
      "ty": 41,
      "x": 12240,
      "y": 58513,
      "ta": "#jspsych-survey-multi-choice-option-2-4"
    },
    {
      "t": 51104,
      "e": 50652,
      "ty": 2,
      "x": 859,
      "y": 756
    },
    {
      "t": 51204,
      "e": 50752,
      "ty": 2,
      "x": 855,
      "y": 744
    },
    {
      "t": 51254,
      "e": 50802,
      "ty": 41,
      "x": 7925,
      "y": 62258,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 51304,
      "e": 50852,
      "ty": 2,
      "x": 851,
      "y": 733
    },
    {
      "t": 51404,
      "e": 50952,
      "ty": 2,
      "x": 851,
      "y": 723
    },
    {
      "t": 51504,
      "e": 51052,
      "ty": 41,
      "x": 7423,
      "y": 6553,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 51704,
      "e": 51252,
      "ty": 2,
      "x": 855,
      "y": 715
    },
    {
      "t": 51754,
      "e": 51302,
      "ty": 41,
      "x": 9469,
      "y": 52428,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 51804,
      "e": 51352,
      "ty": 2,
      "x": 861,
      "y": 706
    },
    {
      "t": 51904,
      "e": 51452,
      "ty": 2,
      "x": 861,
      "y": 704
    },
    {
      "t": 52004,
      "e": 51552,
      "ty": 2,
      "x": 861,
      "y": 703
    },
    {
      "t": 52004,
      "e": 51552,
      "ty": 41,
      "x": 9972,
      "y": 32767,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 52080,
      "e": 51628,
      "ty": 3,
      "x": 861,
      "y": 703,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 52082,
      "e": 51630,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 52175,
      "e": 51723,
      "ty": 4,
      "x": 9972,
      "y": 32767,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 52175,
      "e": 51723,
      "ty": 5,
      "x": 861,
      "y": 703,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 52176,
      "e": 51724,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 52181,
      "e": 51729,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf",
      "v": "Social Sciences (incl. CogSci)"
    },
    {
      "t": 52404,
      "e": 51952,
      "ty": 2,
      "x": 876,
      "y": 723
    },
    {
      "t": 52504,
      "e": 52052,
      "ty": 2,
      "x": 1050,
      "y": 933
    },
    {
      "t": 52504,
      "e": 52052,
      "ty": 41,
      "x": 54247,
      "y": 28086,
      "ta": "#jspsych-survey-multi-choice-option-3-0"
    },
    {
      "t": 52604,
      "e": 52152,
      "ty": 2,
      "x": 1074,
      "y": 948
    },
    {
      "t": 52754,
      "e": 52302,
      "ty": 41,
      "x": 59943,
      "y": 63194,
      "ta": "#jspsych-survey-multi-choice-option-3-0"
    },
    {
      "t": 52904,
      "e": 52452,
      "ty": 2,
      "x": 1071,
      "y": 948
    },
    {
      "t": 53004,
      "e": 52552,
      "ty": 2,
      "x": 1063,
      "y": 948
    },
    {
      "t": 53005,
      "e": 52553,
      "ty": 41,
      "x": 57332,
      "y": 63194,
      "ta": "#jspsych-survey-multi-choice-option-3-0"
    },
    {
      "t": 53104,
      "e": 52652,
      "ty": 2,
      "x": 1043,
      "y": 948
    },
    {
      "t": 53204,
      "e": 52752,
      "ty": 2,
      "x": 996,
      "y": 953
    },
    {
      "t": 53204,
      "e": 52752,
      "ty": 1,
      "x": 0,
      "y": 1
    },
    {
      "t": 53254,
      "e": 52802,
      "ty": 41,
      "x": 27429,
      "y": 37448,
      "ta": "#jspsych-survey-multi-choice-option-3-1"
    },
    {
      "t": 53304,
      "e": 52852,
      "ty": 2,
      "x": 883,
      "y": 971
    },
    {
      "t": 53304,
      "e": 52852,
      "ty": 1,
      "x": 0,
      "y": 14
    },
    {
      "t": 53404,
      "e": 52952,
      "ty": 2,
      "x": 842,
      "y": 972
    },
    {
      "t": 53404,
      "e": 52952,
      "ty": 1,
      "x": 0,
      "y": 16
    },
    {
      "t": 53504,
      "e": 53052,
      "ty": 41,
      "x": 16646,
      "y": 62258,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 53760,
      "e": 53308,
      "ty": 3,
      "x": 842,
      "y": 972,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 53760,
      "e": 53308,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 53847,
      "e": 53395,
      "ty": 4,
      "x": 16646,
      "y": 62258,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 53847,
      "e": 53395,
      "ty": 5,
      "x": 842,
      "y": 972,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 53849,
      "e": 53397,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 53852,
      "e": 53400,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf",
      "v": "Female"
    },
    {
      "t": 54104,
      "e": 53652,
      "ty": 2,
      "x": 849,
      "y": 994
    },
    {
      "t": 54133,
      "e": 53681,
      "ty": 6,
      "x": 856,
      "y": 1006,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 54204,
      "e": 53752,
      "ty": 2,
      "x": 888,
      "y": 1029
    },
    {
      "t": 54254,
      "e": 53802,
      "ty": 41,
      "x": 30705,
      "y": 47661,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 54304,
      "e": 53852,
      "ty": 2,
      "x": 889,
      "y": 1029
    },
    {
      "t": 54392,
      "e": 53940,
      "ty": 3,
      "x": 889,
      "y": 1029,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 54393,
      "e": 53941,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 54393,
      "e": 53941,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 54503,
      "e": 54051,
      "ty": 4,
      "x": 30705,
      "y": 47661,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 54503,
      "e": 54051,
      "ty": 5,
      "x": 889,
      "y": 1029,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 54506,
      "e": 54054,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 54506,
      "e": 54054,
      "ty": 13,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 54508,
      "e": 54056,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 54703,
      "e": 54251,
      "ty": 2,
      "x": 910,
      "y": 1029
    },
    {
      "t": 54754,
      "e": 54302,
      "ty": 41,
      "x": 32337,
      "y": 56228,
      "ta": "html > body"
    },
    {
      "t": 54804,
      "e": 54352,
      "ty": 2,
      "x": 971,
      "y": 1015
    },
    {
      "t": 54903,
      "e": 54451,
      "ty": 2,
      "x": 974,
      "y": 1014
    },
    {
      "t": 55004,
      "e": 54552,
      "ty": 41,
      "x": 33266,
      "y": 55729,
      "ta": "html > body"
    },
    {
      "t": 55598,
      "e": 55146,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 55903,
      "e": 55451,
      "ty": 2,
      "x": 973,
      "y": 1015
    },
    {
      "t": 56003,
      "e": 55551,
      "ty": 2,
      "x": 974,
      "y": 953
    },
    {
      "t": 56003,
      "e": 55551,
      "ty": 41,
      "x": 33480,
      "y": 57246,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 56103,
      "e": 55651,
      "ty": 2,
      "x": 950,
      "y": 503
    },
    {
      "t": 56203,
      "e": 55751,
      "ty": 2,
      "x": 953,
      "y": 490
    },
    {
      "t": 56253,
      "e": 55801,
      "ty": 41,
      "x": 32300,
      "y": 11513,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 56303,
      "e": 55851,
      "ty": 2,
      "x": 950,
      "y": 513
    },
    {
      "t": 56404,
      "e": 55952,
      "ty": 2,
      "x": 944,
      "y": 511
    },
    {
      "t": 56503,
      "e": 56051,
      "ty": 2,
      "x": 820,
      "y": 464
    },
    {
      "t": 56503,
      "e": 56051,
      "ty": 41,
      "x": 25904,
      "y": 65157,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 56603,
      "e": 56151,
      "ty": 2,
      "x": 599,
      "y": 419
    },
    {
      "t": 56703,
      "e": 56251,
      "ty": 2,
      "x": 475,
      "y": 392
    },
    {
      "t": 56753,
      "e": 56301,
      "ty": 41,
      "x": 6422,
      "y": 4691,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 56804,
      "e": 56352,
      "ty": 2,
      "x": 408,
      "y": 369
    },
    {
      "t": 56903,
      "e": 56451,
      "ty": 2,
      "x": 396,
      "y": 367
    },
    {
      "t": 57003,
      "e": 56551,
      "ty": 2,
      "x": 393,
      "y": 371
    },
    {
      "t": 57003,
      "e": 56551,
      "ty": 41,
      "x": 4897,
      "y": 4228,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 57103,
      "e": 56651,
      "ty": 2,
      "x": 393,
      "y": 377
    },
    {
      "t": 57204,
      "e": 56752,
      "ty": 2,
      "x": 388,
      "y": 383
    },
    {
      "t": 57254,
      "e": 56802,
      "ty": 41,
      "x": 32266,
      "y": 4966,
      "ta": "> div.masterdiv > div:[2] > div > p:[2] > b"
    },
    {
      "t": 57304,
      "e": 56852,
      "ty": 2,
      "x": 387,
      "y": 389
    },
    {
      "t": 57403,
      "e": 56951,
      "ty": 2,
      "x": 463,
      "y": 372
    },
    {
      "t": 57503,
      "e": 57051,
      "ty": 2,
      "x": 542,
      "y": 353
    },
    {
      "t": 57504,
      "e": 57052,
      "ty": 41,
      "x": 12227,
      "y": 43336,
      "ta": "> div.masterdiv > div:[2] > div > p"
    },
    {
      "t": 57603,
      "e": 57151,
      "ty": 2,
      "x": 564,
      "y": 351
    },
    {
      "t": 57703,
      "e": 57251,
      "ty": 2,
      "x": 654,
      "y": 349
    },
    {
      "t": 57754,
      "e": 57302,
      "ty": 41,
      "x": 20886,
      "y": 33974,
      "ta": "> div.masterdiv > div:[2] > div > p"
    },
    {
      "t": 57803,
      "e": 57351,
      "ty": 2,
      "x": 802,
      "y": 348
    },
    {
      "t": 57904,
      "e": 57452,
      "ty": 2,
      "x": 913,
      "y": 347
    },
    {
      "t": 58003,
      "e": 57551,
      "ty": 2,
      "x": 965,
      "y": 342
    },
    {
      "t": 58003,
      "e": 57551,
      "ty": 41,
      "x": 33038,
      "y": 17590,
      "ta": "> div.masterdiv > div:[2] > div > p"
    },
    {
      "t": 58103,
      "e": 57651,
      "ty": 2,
      "x": 1059,
      "y": 338
    },
    {
      "t": 58203,
      "e": 57751,
      "ty": 2,
      "x": 1177,
      "y": 332
    },
    {
      "t": 58253,
      "e": 57801,
      "ty": 41,
      "x": 46665,
      "y": 14244,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 58303,
      "e": 57851,
      "ty": 2,
      "x": 1295,
      "y": 332
    },
    {
      "t": 58403,
      "e": 57951,
      "ty": 2,
      "x": 1253,
      "y": 341
    },
    {
      "t": 58503,
      "e": 58051,
      "ty": 2,
      "x": 979,
      "y": 372
    },
    {
      "t": 58504,
      "e": 58052,
      "ty": 41,
      "x": 33726,
      "y": 4343,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 58604,
      "e": 58152,
      "ty": 2,
      "x": 907,
      "y": 372
    },
    {
      "t": 58704,
      "e": 58252,
      "ty": 2,
      "x": 754,
      "y": 379
    },
    {
      "t": 58753,
      "e": 58301,
      "ty": 41,
      "x": 19656,
      "y": 4922,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 58804,
      "e": 58352,
      "ty": 2,
      "x": 658,
      "y": 375
    },
    {
      "t": 58903,
      "e": 58451,
      "ty": 2,
      "x": 603,
      "y": 381
    },
    {
      "t": 59003,
      "e": 58551,
      "ty": 2,
      "x": 586,
      "y": 384
    },
    {
      "t": 59004,
      "e": 58552,
      "ty": 41,
      "x": 14392,
      "y": 2742,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 59304,
      "e": 58852,
      "ty": 2,
      "x": 597,
      "y": 390
    },
    {
      "t": 59403,
      "e": 58951,
      "ty": 2,
      "x": 630,
      "y": 393
    },
    {
      "t": 59503,
      "e": 59051,
      "ty": 2,
      "x": 651,
      "y": 394
    },
    {
      "t": 59504,
      "e": 59052,
      "ty": 41,
      "x": 17590,
      "y": 10544,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 59603,
      "e": 59151,
      "ty": 2,
      "x": 652,
      "y": 394
    },
    {
      "t": 59655,
      "e": 59203,
      "ty": 3,
      "x": 658,
      "y": 394,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 59703,
      "e": 59251,
      "ty": 2,
      "x": 678,
      "y": 393
    },
    {
      "t": 59754,
      "e": 59302,
      "ty": 41,
      "x": 21968,
      "y": 9764,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 59804,
      "e": 59352,
      "ty": 2,
      "x": 812,
      "y": 390
    },
    {
      "t": 59903,
      "e": 59451,
      "ty": 2,
      "x": 984,
      "y": 388
    },
    {
      "t": 60003,
      "e": 59551,
      "ty": 2,
      "x": 1030,
      "y": 388
    },
    {
      "t": 60004,
      "e": 59552,
      "ty": 41,
      "x": 36629,
      "y": 5863,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 60004,
      "e": 59552,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 60103,
      "e": 59651,
      "ty": 2,
      "x": 1130,
      "y": 388
    },
    {
      "t": 60203,
      "e": 59751,
      "ty": 2,
      "x": 1230,
      "y": 388
    },
    {
      "t": 60253,
      "e": 59801,
      "ty": 41,
      "x": 48092,
      "y": 5863,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 60304,
      "e": 59852,
      "ty": 2,
      "x": 1307,
      "y": 388
    },
    {
      "t": 60403,
      "e": 59951,
      "ty": 2,
      "x": 1415,
      "y": 388
    },
    {
      "t": 60503,
      "e": 60051,
      "ty": 2,
      "x": 1485,
      "y": 388
    },
    {
      "t": 60504,
      "e": 60052,
      "ty": 41,
      "x": 58866,
      "y": 5863,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 60603,
      "e": 60151,
      "ty": 2,
      "x": 1556,
      "y": 388
    },
    {
      "t": 60704,
      "e": 60252,
      "ty": 2,
      "x": 1611,
      "y": 389
    },
    {
      "t": 60754,
      "e": 60302,
      "ty": 41,
      "x": 56030,
      "y": 21327,
      "ta": "> div.masterdiv"
    },
    {
      "t": 60804,
      "e": 60352,
      "ty": 2,
      "x": 1669,
      "y": 398
    },
    {
      "t": 60903,
      "e": 60451,
      "ty": 2,
      "x": 1695,
      "y": 402
    },
    {
      "t": 61004,
      "e": 60552,
      "ty": 2,
      "x": 1720,
      "y": 407
    },
    {
      "t": 61004,
      "e": 60552,
      "ty": 41,
      "x": 58991,
      "y": 22103,
      "ta": "> div.masterdiv"
    },
    {
      "t": 61103,
      "e": 60651,
      "ty": 2,
      "x": 1736,
      "y": 412
    },
    {
      "t": 61204,
      "e": 60752,
      "ty": 2,
      "x": 1740,
      "y": 413
    },
    {
      "t": 61254,
      "e": 60802,
      "ty": 41,
      "x": 59646,
      "y": 22435,
      "ta": "> div.masterdiv"
    },
    {
      "t": 61403,
      "e": 60951,
      "ty": 2,
      "x": 1736,
      "y": 419
    },
    {
      "t": 61503,
      "e": 61051,
      "ty": 2,
      "x": 1707,
      "y": 430
    },
    {
      "t": 61504,
      "e": 61052,
      "ty": 41,
      "x": 58509,
      "y": 23377,
      "ta": "> div.masterdiv"
    },
    {
      "t": 61603,
      "e": 61151,
      "ty": 2,
      "x": 1666,
      "y": 440
    },
    {
      "t": 61703,
      "e": 61251,
      "ty": 2,
      "x": 1601,
      "y": 440
    },
    {
      "t": 61754,
      "e": 61302,
      "ty": 41,
      "x": 63146,
      "y": 46432,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 61803,
      "e": 61351,
      "ty": 2,
      "x": 1551,
      "y": 437
    },
    {
      "t": 61903,
      "e": 61451,
      "ty": 2,
      "x": 1395,
      "y": 426
    },
    {
      "t": 62004,
      "e": 61552,
      "ty": 2,
      "x": 1245,
      "y": 428
    },
    {
      "t": 62004,
      "e": 61552,
      "ty": 41,
      "x": 46813,
      "y": 37070,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 62103,
      "e": 61651,
      "ty": 2,
      "x": 1015,
      "y": 428
    },
    {
      "t": 62203,
      "e": 61751,
      "ty": 2,
      "x": 765,
      "y": 428
    },
    {
      "t": 62254,
      "e": 61802,
      "ty": 41,
      "x": 18672,
      "y": 38631,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 62303,
      "e": 61851,
      "ty": 2,
      "x": 617,
      "y": 430
    },
    {
      "t": 62403,
      "e": 61951,
      "ty": 2,
      "x": 534,
      "y": 430
    },
    {
      "t": 62503,
      "e": 62051,
      "ty": 2,
      "x": 480,
      "y": 433
    },
    {
      "t": 62503,
      "e": 62051,
      "ty": 41,
      "x": 9177,
      "y": 40971,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 62604,
      "e": 62152,
      "ty": 2,
      "x": 479,
      "y": 433
    },
    {
      "t": 62754,
      "e": 62302,
      "ty": 41,
      "x": 9128,
      "y": 40971,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 62804,
      "e": 62352,
      "ty": 2,
      "x": 480,
      "y": 433
    },
    {
      "t": 62903,
      "e": 62451,
      "ty": 2,
      "x": 563,
      "y": 435
    },
    {
      "t": 63003,
      "e": 62551,
      "ty": 2,
      "x": 577,
      "y": 436
    },
    {
      "t": 63004,
      "e": 62552,
      "ty": 41,
      "x": 13949,
      "y": 43312,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 63103,
      "e": 62651,
      "ty": 2,
      "x": 687,
      "y": 436
    },
    {
      "t": 63203,
      "e": 62751,
      "ty": 2,
      "x": 765,
      "y": 437
    },
    {
      "t": 63254,
      "e": 62802,
      "ty": 41,
      "x": 23247,
      "y": 44872,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 63304,
      "e": 62852,
      "ty": 2,
      "x": 768,
      "y": 438
    },
    {
      "t": 63404,
      "e": 62952,
      "ty": 2,
      "x": 776,
      "y": 441
    },
    {
      "t": 63504,
      "e": 63052,
      "ty": 2,
      "x": 804,
      "y": 441
    },
    {
      "t": 63504,
      "e": 63052,
      "ty": 41,
      "x": 25117,
      "y": 47212,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 63603,
      "e": 63151,
      "ty": 2,
      "x": 821,
      "y": 440
    },
    {
      "t": 63703,
      "e": 63251,
      "ty": 2,
      "x": 845,
      "y": 438
    },
    {
      "t": 63754,
      "e": 63302,
      "ty": 41,
      "x": 27724,
      "y": 44872,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 63804,
      "e": 63352,
      "ty": 2,
      "x": 861,
      "y": 437
    },
    {
      "t": 63997,
      "e": 63545,
      "ty": 4,
      "x": 27921,
      "y": 44092,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 63999,
      "e": 63547,
      "ty": 5,
      "x": 861,
      "y": 437,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 64004,
      "e": 63552,
      "ty": 41,
      "x": 27921,
      "y": 44092,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 64503,
      "e": 64051,
      "ty": 2,
      "x": 862,
      "y": 437
    },
    {
      "t": 64504,
      "e": 64052,
      "ty": 41,
      "x": 27970,
      "y": 44092,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 64604,
      "e": 64152,
      "ty": 2,
      "x": 863,
      "y": 437
    },
    {
      "t": 64703,
      "e": 64251,
      "ty": 2,
      "x": 911,
      "y": 447
    },
    {
      "t": 64754,
      "e": 64302,
      "ty": 41,
      "x": 30479,
      "y": 52674,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 64804,
      "e": 64352,
      "ty": 2,
      "x": 916,
      "y": 450
    },
    {
      "t": 65004,
      "e": 64552,
      "ty": 41,
      "x": 30627,
      "y": 54234,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 65104,
      "e": 64652,
      "ty": 2,
      "x": 923,
      "y": 450
    },
    {
      "t": 65204,
      "e": 64752,
      "ty": 2,
      "x": 946,
      "y": 446
    },
    {
      "t": 65254,
      "e": 64802,
      "ty": 41,
      "x": 32546,
      "y": 49553,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 65304,
      "e": 64852,
      "ty": 2,
      "x": 956,
      "y": 444
    },
    {
      "t": 65313,
      "e": 64861,
      "ty": 3,
      "x": 956,
      "y": 444,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 65407,
      "e": 64955,
      "ty": 4,
      "x": 32595,
      "y": 49553,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 65407,
      "e": 64955,
      "ty": 5,
      "x": 956,
      "y": 444,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 65504,
      "e": 65052,
      "ty": 41,
      "x": 32595,
      "y": 49553,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 66104,
      "e": 65652,
      "ty": 2,
      "x": 958,
      "y": 445
    },
    {
      "t": 66204,
      "e": 65752,
      "ty": 2,
      "x": 1135,
      "y": 512
    },
    {
      "t": 66254,
      "e": 65802,
      "ty": 41,
      "x": 41549,
      "y": 13854,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 66303,
      "e": 65851,
      "ty": 2,
      "x": 1138,
      "y": 518
    },
    {
      "t": 66604,
      "e": 66152,
      "ty": 2,
      "x": 1351,
      "y": 489
    },
    {
      "t": 66704,
      "e": 66252,
      "ty": 2,
      "x": 1444,
      "y": 468
    },
    {
      "t": 66753,
      "e": 66301,
      "ty": 41,
      "x": 57292,
      "y": 15227,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 66803,
      "e": 66351,
      "ty": 2,
      "x": 1508,
      "y": 465
    },
    {
      "t": 66904,
      "e": 66452,
      "ty": 2,
      "x": 1536,
      "y": 455
    },
    {
      "t": 67003,
      "e": 66551,
      "ty": 2,
      "x": 1572,
      "y": 433
    },
    {
      "t": 67003,
      "e": 66551,
      "ty": 41,
      "x": 62900,
      "y": 40971,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 67104,
      "e": 66652,
      "ty": 2,
      "x": 1595,
      "y": 428
    },
    {
      "t": 67204,
      "e": 66752,
      "ty": 2,
      "x": 1506,
      "y": 453
    },
    {
      "t": 67254,
      "e": 66802,
      "ty": 41,
      "x": 47698,
      "y": 57355,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 67303,
      "e": 66851,
      "ty": 2,
      "x": 846,
      "y": 454
    },
    {
      "t": 67404,
      "e": 66952,
      "ty": 2,
      "x": 518,
      "y": 486
    },
    {
      "t": 67504,
      "e": 67052,
      "ty": 41,
      "x": 11047,
      "y": 1371,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 67604,
      "e": 67152,
      "ty": 2,
      "x": 520,
      "y": 488
    },
    {
      "t": 67703,
      "e": 67251,
      "ty": 2,
      "x": 417,
      "y": 470
    },
    {
      "t": 67753,
      "e": 67301,
      "ty": 41,
      "x": 5290,
      "y": 15111,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 67803,
      "e": 67351,
      "ty": 2,
      "x": 401,
      "y": 465
    },
    {
      "t": 67904,
      "e": 67452,
      "ty": 2,
      "x": 397,
      "y": 463
    },
    {
      "t": 68003,
      "e": 67551,
      "ty": 2,
      "x": 373,
      "y": 458
    },
    {
      "t": 68004,
      "e": 67552,
      "ty": 41,
      "x": 3913,
      "y": 60476,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 68103,
      "e": 67651,
      "ty": 2,
      "x": 355,
      "y": 461
    },
    {
      "t": 68204,
      "e": 67752,
      "ty": 2,
      "x": 341,
      "y": 461
    },
    {
      "t": 68254,
      "e": 67802,
      "ty": 41,
      "x": 2240,
      "y": 62816,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 68304,
      "e": 67852,
      "ty": 2,
      "x": 324,
      "y": 461
    },
    {
      "t": 68404,
      "e": 67952,
      "ty": 2,
      "x": 308,
      "y": 453
    },
    {
      "t": 68504,
      "e": 68052,
      "ty": 2,
      "x": 307,
      "y": 453
    },
    {
      "t": 68504,
      "e": 68052,
      "ty": 41,
      "x": 666,
      "y": 56575,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 68512,
      "e": 68060,
      "ty": 3,
      "x": 307,
      "y": 453,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 68603,
      "e": 68151,
      "ty": 2,
      "x": 333,
      "y": 453
    },
    {
      "t": 68703,
      "e": 68251,
      "ty": 2,
      "x": 483,
      "y": 453
    },
    {
      "t": 68754,
      "e": 68302,
      "ty": 41,
      "x": 14490,
      "y": 58915,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 68804,
      "e": 68352,
      "ty": 2,
      "x": 705,
      "y": 459
    },
    {
      "t": 68903,
      "e": 68451,
      "ty": 2,
      "x": 887,
      "y": 474
    },
    {
      "t": 69004,
      "e": 68552,
      "ty": 2,
      "x": 900,
      "y": 474
    },
    {
      "t": 69004,
      "e": 68552,
      "ty": 41,
      "x": 29840,
      "y": 16153,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 69203,
      "e": 68751,
      "ty": 2,
      "x": 904,
      "y": 473
    },
    {
      "t": 69253,
      "e": 68801,
      "ty": 41,
      "x": 30381,
      "y": 65157,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 69304,
      "e": 68852,
      "ty": 2,
      "x": 915,
      "y": 459
    },
    {
      "t": 69404,
      "e": 68952,
      "ty": 2,
      "x": 921,
      "y": 452
    },
    {
      "t": 69504,
      "e": 69052,
      "ty": 2,
      "x": 927,
      "y": 443
    },
    {
      "t": 69504,
      "e": 69052,
      "ty": 41,
      "x": 31168,
      "y": 48773,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 69623,
      "e": 69171,
      "ty": 4,
      "x": 31168,
      "y": 48773,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 69624,
      "e": 69172,
      "ty": 5,
      "x": 927,
      "y": 443,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 69804,
      "e": 69352,
      "ty": 2,
      "x": 923,
      "y": 506
    },
    {
      "t": 69904,
      "e": 69452,
      "ty": 2,
      "x": 962,
      "y": 734
    },
    {
      "t": 70004,
      "e": 69552,
      "ty": 2,
      "x": 973,
      "y": 772
    },
    {
      "t": 70004,
      "e": 69552,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 70007,
      "e": 69555,
      "ty": 41,
      "x": 33431,
      "y": 60570,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 70103,
      "e": 69651,
      "ty": 2,
      "x": 973,
      "y": 779
    },
    {
      "t": 70204,
      "e": 69752,
      "ty": 2,
      "x": 981,
      "y": 804
    },
    {
      "t": 70254,
      "e": 69802,
      "ty": 41,
      "x": 34218,
      "y": 42733,
      "ta": "> div.masterdiv > div:[2] > div > p:[5]"
    },
    {
      "t": 70304,
      "e": 69852,
      "ty": 2,
      "x": 1004,
      "y": 869
    },
    {
      "t": 70404,
      "e": 69952,
      "ty": 2,
      "x": 1017,
      "y": 890
    },
    {
      "t": 70504,
      "e": 70052,
      "ty": 2,
      "x": 1018,
      "y": 890
    },
    {
      "t": 70504,
      "e": 70052,
      "ty": 41,
      "x": 35645,
      "y": 40995,
      "ta": "> div.masterdiv > div:[2] > div > p:[6]"
    },
    {
      "t": 70664,
      "e": 70212,
      "ty": 3,
      "x": 1018,
      "y": 890,
      "ta": "> div.masterdiv > div:[2] > div > p:[6]"
    },
    {
      "t": 70754,
      "e": 70302,
      "ty": 41,
      "x": 35547,
      "y": 40995,
      "ta": "> div.masterdiv > div:[2] > div > p:[6]"
    },
    {
      "t": 70804,
      "e": 70352,
      "ty": 2,
      "x": 973,
      "y": 867
    },
    {
      "t": 70903,
      "e": 70451,
      "ty": 2,
      "x": 441,
      "y": 624
    },
    {
      "t": 71004,
      "e": 70552,
      "ty": 2,
      "x": 364,
      "y": 552
    },
    {
      "t": 71004,
      "e": 70552,
      "ty": 41,
      "x": 3470,
      "y": 27117,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 71103,
      "e": 70651,
      "ty": 2,
      "x": 355,
      "y": 534
    },
    {
      "t": 71254,
      "e": 70802,
      "ty": 41,
      "x": 2929,
      "y": 19315,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 71303,
      "e": 70851,
      "ty": 2,
      "x": 341,
      "y": 512
    },
    {
      "t": 71403,
      "e": 70951,
      "ty": 2,
      "x": 335,
      "y": 503
    },
    {
      "t": 71406,
      "e": 70954,
      "ty": 4,
      "x": 11537,
      "y": 54117,
      "ta": "> div.masterdiv > div:[2] > div > p:[3] > b"
    },
    {
      "t": 71406,
      "e": 70954,
      "ty": 5,
      "x": 335,
      "y": 503,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 71504,
      "e": 71052,
      "ty": 41,
      "x": 11537,
      "y": 54117,
      "ta": "> div.masterdiv > div:[2] > div > p:[3] > b"
    },
    {
      "t": 71704,
      "e": 71252,
      "ty": 2,
      "x": 292,
      "y": 485
    },
    {
      "t": 71754,
      "e": 71302,
      "ty": 41,
      "x": 9642,
      "y": 26369,
      "ta": "> div.masterdiv"
    },
    {
      "t": 71800,
      "e": 71348,
      "ty": 3,
      "x": 288,
      "y": 484,
      "ta": "> div.masterdiv"
    },
    {
      "t": 71804,
      "e": 71352,
      "ty": 2,
      "x": 288,
      "y": 484
    },
    {
      "t": 71854,
      "e": 71402,
      "ty": 4,
      "x": 9642,
      "y": 26369,
      "ta": "> div.masterdiv"
    },
    {
      "t": 71854,
      "e": 71402,
      "ty": 5,
      "x": 288,
      "y": 484,
      "ta": "> div.masterdiv"
    },
    {
      "t": 71950,
      "e": 71498,
      "ty": 3,
      "x": 288,
      "y": 484,
      "ta": "> div.masterdiv"
    },
    {
      "t": 72047,
      "e": 71595,
      "ty": 4,
      "x": 9642,
      "y": 26369,
      "ta": "> div.masterdiv"
    },
    {
      "t": 72047,
      "e": 71595,
      "ty": 5,
      "x": 288,
      "y": 484,
      "ta": "> div.masterdiv"
    },
    {
      "t": 72303,
      "e": 71851,
      "ty": 2,
      "x": 305,
      "y": 486
    },
    {
      "t": 72404,
      "e": 71952,
      "ty": 2,
      "x": 351,
      "y": 506
    },
    {
      "t": 72431,
      "e": 71979,
      "ty": 3,
      "x": 351,
      "y": 506,
      "ta": "> div.masterdiv > div:[2] > div > p:[3] > b"
    },
    {
      "t": 72502,
      "e": 72050,
      "ty": 4,
      "x": 15980,
      "y": 63947,
      "ta": "> div.masterdiv > div:[2] > div > p:[3] > b"
    },
    {
      "t": 72502,
      "e": 72050,
      "ty": 5,
      "x": 351,
      "y": 506,
      "ta": "> div.masterdiv > div:[2] > div > p:[3] > b"
    },
    {
      "t": 72503,
      "e": 72051,
      "ty": 41,
      "x": 15980,
      "y": 63947,
      "ta": "> div.masterdiv > div:[2] > div > p:[3] > b"
    },
    {
      "t": 72591,
      "e": 72139,
      "ty": 3,
      "x": 351,
      "y": 506,
      "ta": "> div.masterdiv > div:[2] > div > p:[3] > b"
    },
    {
      "t": 72671,
      "e": 72219,
      "ty": 4,
      "x": 15980,
      "y": 63947,
      "ta": "> div.masterdiv > div:[2] > div > p:[3] > b"
    },
    {
      "t": 72671,
      "e": 72219,
      "ty": 5,
      "x": 351,
      "y": 506,
      "ta": "> div.masterdiv > div:[2] > div > p:[3] > b"
    },
    {
      "t": 72751,
      "e": 72299,
      "ty": 3,
      "x": 351,
      "y": 506,
      "ta": "> div.masterdiv > div:[2] > div > p:[3] > b"
    },
    {
      "t": 72831,
      "e": 72379,
      "ty": 4,
      "x": 15980,
      "y": 63947,
      "ta": "> div.masterdiv > div:[2] > div > p:[3] > b"
    },
    {
      "t": 72831,
      "e": 72379,
      "ty": 5,
      "x": 351,
      "y": 506,
      "ta": "> div.masterdiv > div:[2] > div > p:[3] > b"
    },
    {
      "t": 73004,
      "e": 72552,
      "ty": 2,
      "x": 441,
      "y": 567
    },
    {
      "t": 73005,
      "e": 72553,
      "ty": 41,
      "x": 7258,
      "y": 32968,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 73103,
      "e": 72651,
      "ty": 2,
      "x": 661,
      "y": 685
    },
    {
      "t": 73204,
      "e": 72752,
      "ty": 2,
      "x": 675,
      "y": 695
    },
    {
      "t": 73215,
      "e": 72763,
      "ty": 3,
      "x": 675,
      "y": 695,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 73254,
      "e": 72802,
      "ty": 41,
      "x": 18770,
      "y": 15515,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 73295,
      "e": 72843,
      "ty": 4,
      "x": 18770,
      "y": 15515,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 73296,
      "e": 72844,
      "ty": 5,
      "x": 675,
      "y": 695,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 73391,
      "e": 72939,
      "ty": 3,
      "x": 675,
      "y": 695,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 73463,
      "e": 73011,
      "ty": 4,
      "x": 18770,
      "y": 15515,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 73464,
      "e": 73012,
      "ty": 5,
      "x": 675,
      "y": 695,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 73543,
      "e": 73091,
      "ty": 3,
      "x": 675,
      "y": 695,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 73631,
      "e": 73179,
      "ty": 4,
      "x": 18770,
      "y": 15515,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 73632,
      "e": 73180,
      "ty": 5,
      "x": 675,
      "y": 695,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 73754,
      "e": 73302,
      "ty": 41,
      "x": 19361,
      "y": 21366,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 73804,
      "e": 73352,
      "ty": 2,
      "x": 757,
      "y": 753
    },
    {
      "t": 73904,
      "e": 73452,
      "ty": 2,
      "x": 889,
      "y": 855
    },
    {
      "t": 74004,
      "e": 73552,
      "ty": 2,
      "x": 898,
      "y": 861
    },
    {
      "t": 74004,
      "e": 73552,
      "ty": 41,
      "x": 29741,
      "y": 60963,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 74254,
      "e": 73802,
      "ty": 41,
      "x": 29791,
      "y": 62627,
      "ta": "> div.masterdiv > div:[2] > div > p:[5]"
    },
    {
      "t": 74304,
      "e": 73852,
      "ty": 2,
      "x": 899,
      "y": 847
    },
    {
      "t": 74404,
      "e": 73952,
      "ty": 2,
      "x": 899,
      "y": 844
    },
    {
      "t": 74504,
      "e": 74052,
      "ty": 2,
      "x": 899,
      "y": 836
    },
    {
      "t": 74505,
      "e": 74053,
      "ty": 41,
      "x": 29791,
      "y": 43903,
      "ta": "> div.masterdiv > div:[2] > div > p:[5]"
    },
    {
      "t": 74604,
      "e": 74152,
      "ty": 2,
      "x": 899,
      "y": 831
    },
    {
      "t": 74703,
      "e": 74251,
      "ty": 2,
      "x": 899,
      "y": 827
    },
    {
      "t": 74754,
      "e": 74302,
      "ty": 41,
      "x": 29791,
      "y": 33370,
      "ta": "> div.masterdiv > div:[2] > div > p:[5]"
    },
    {
      "t": 76004,
      "e": 75552,
      "ty": 2,
      "x": 899,
      "y": 826
    },
    {
      "t": 76004,
      "e": 75552,
      "ty": 41,
      "x": 29791,
      "y": 32200,
      "ta": "> div.masterdiv > div:[2] > div > p:[5]"
    },
    {
      "t": 76104,
      "e": 75652,
      "ty": 2,
      "x": 939,
      "y": 802
    },
    {
      "t": 76204,
      "e": 75752,
      "ty": 2,
      "x": 924,
      "y": 791
    },
    {
      "t": 76255,
      "e": 75803,
      "ty": 41,
      "x": 31021,
      "y": 52858,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 76604,
      "e": 76152,
      "ty": 2,
      "x": 903,
      "y": 787
    },
    {
      "t": 76704,
      "e": 76252,
      "ty": 2,
      "x": 851,
      "y": 757
    },
    {
      "t": 76754,
      "e": 76302,
      "ty": 41,
      "x": 27429,
      "y": 44186,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 76804,
      "e": 76352,
      "ty": 2,
      "x": 854,
      "y": 732
    },
    {
      "t": 76903,
      "e": 76451,
      "ty": 2,
      "x": 885,
      "y": 717
    },
    {
      "t": 77004,
      "e": 76552,
      "ty": 2,
      "x": 994,
      "y": 696
    },
    {
      "t": 77004,
      "e": 76552,
      "ty": 41,
      "x": 34464,
      "y": 16100,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 77103,
      "e": 76651,
      "ty": 2,
      "x": 1062,
      "y": 693
    },
    {
      "t": 77204,
      "e": 76752,
      "ty": 2,
      "x": 1103,
      "y": 692
    },
    {
      "t": 77254,
      "e": 76802,
      "ty": 41,
      "x": 41204,
      "y": 11419,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 77303,
      "e": 76851,
      "ty": 2,
      "x": 1145,
      "y": 687
    },
    {
      "t": 77404,
      "e": 76952,
      "ty": 2,
      "x": 1166,
      "y": 684
    },
    {
      "t": 77504,
      "e": 77052,
      "ty": 2,
      "x": 1175,
      "y": 681
    },
    {
      "t": 77504,
      "e": 77052,
      "ty": 41,
      "x": 43369,
      "y": 7323,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 77604,
      "e": 77152,
      "ty": 2,
      "x": 1183,
      "y": 680
    },
    {
      "t": 77754,
      "e": 77302,
      "ty": 41,
      "x": 43812,
      "y": 6738,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 77804,
      "e": 77352,
      "ty": 2,
      "x": 1184,
      "y": 680
    },
    {
      "t": 78404,
      "e": 77952,
      "ty": 2,
      "x": 1257,
      "y": 689
    },
    {
      "t": 78504,
      "e": 78052,
      "ty": 2,
      "x": 1300,
      "y": 699
    },
    {
      "t": 78505,
      "e": 78053,
      "ty": 41,
      "x": 49519,
      "y": 17855,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 78604,
      "e": 78152,
      "ty": 2,
      "x": 1302,
      "y": 699
    },
    {
      "t": 78704,
      "e": 78252,
      "ty": 2,
      "x": 1309,
      "y": 699
    },
    {
      "t": 78754,
      "e": 78302,
      "ty": 41,
      "x": 49961,
      "y": 17855,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 80004,
      "e": 79552,
      "ty": 2,
      "x": 1344,
      "y": 698
    },
    {
      "t": 80004,
      "e": 79552,
      "ty": 41,
      "x": 51683,
      "y": 17270,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 80004,
      "e": 79552,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 80103,
      "e": 79651,
      "ty": 2,
      "x": 1356,
      "y": 697
    },
    {
      "t": 80203,
      "e": 79751,
      "ty": 2,
      "x": 1373,
      "y": 694
    },
    {
      "t": 80253,
      "e": 79801,
      "ty": 41,
      "x": 53848,
      "y": 13759,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 80304,
      "e": 79852,
      "ty": 2,
      "x": 1408,
      "y": 692
    },
    {
      "t": 80403,
      "e": 79951,
      "ty": 2,
      "x": 1427,
      "y": 690
    },
    {
      "t": 80503,
      "e": 80051,
      "ty": 2,
      "x": 1462,
      "y": 685
    },
    {
      "t": 80504,
      "e": 80052,
      "ty": 41,
      "x": 57488,
      "y": 9663,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 80603,
      "e": 80151,
      "ty": 2,
      "x": 1477,
      "y": 683
    },
    {
      "t": 80703,
      "e": 80251,
      "ty": 2,
      "x": 1497,
      "y": 682
    },
    {
      "t": 80753,
      "e": 80301,
      "ty": 41,
      "x": 59210,
      "y": 7908,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 80803,
      "e": 80351,
      "ty": 2,
      "x": 1498,
      "y": 682
    },
    {
      "t": 81004,
      "e": 80552,
      "ty": 41,
      "x": 59260,
      "y": 7908,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 81203,
      "e": 80751,
      "ty": 2,
      "x": 1500,
      "y": 682
    },
    {
      "t": 81254,
      "e": 80802,
      "ty": 41,
      "x": 63294,
      "y": 24292,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 81303,
      "e": 80851,
      "ty": 2,
      "x": 1640,
      "y": 726
    },
    {
      "t": 81403,
      "e": 80951,
      "ty": 2,
      "x": 1640,
      "y": 727
    },
    {
      "t": 81503,
      "e": 81051,
      "ty": 41,
      "x": 56202,
      "y": 39830,
      "ta": "> div.masterdiv"
    },
    {
      "t": 81603,
      "e": 81151,
      "ty": 2,
      "x": 1578,
      "y": 774
    },
    {
      "t": 81703,
      "e": 81251,
      "ty": 2,
      "x": 999,
      "y": 880
    },
    {
      "t": 81754,
      "e": 81302,
      "ty": 41,
      "x": 21329,
      "y": 56776,
      "ta": "> div.masterdiv > div:[2] > div > p:[5]"
    },
    {
      "t": 81804,
      "e": 81352,
      "ty": 2,
      "x": 576,
      "y": 802
    },
    {
      "t": 81903,
      "e": 81451,
      "ty": 2,
      "x": 462,
      "y": 737
    },
    {
      "t": 82004,
      "e": 81552,
      "ty": 2,
      "x": 374,
      "y": 683
    },
    {
      "t": 82004,
      "e": 81552,
      "ty": 41,
      "x": 22656,
      "y": 34457,
      "ta": "> div.masterdiv > div:[2] > div > p:[4] > b"
    },
    {
      "t": 82104,
      "e": 81652,
      "ty": 2,
      "x": 373,
      "y": 682
    },
    {
      "t": 82203,
      "e": 81751,
      "ty": 2,
      "x": 325,
      "y": 702
    },
    {
      "t": 82254,
      "e": 81802,
      "ty": 41,
      "x": 1207,
      "y": 24292,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 82303,
      "e": 81851,
      "ty": 2,
      "x": 318,
      "y": 712
    },
    {
      "t": 82403,
      "e": 81951,
      "ty": 2,
      "x": 337,
      "y": 721
    },
    {
      "t": 82503,
      "e": 82051,
      "ty": 2,
      "x": 360,
      "y": 723
    },
    {
      "t": 82504,
      "e": 82052,
      "ty": 41,
      "x": 3273,
      "y": 31898,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 82603,
      "e": 82151,
      "ty": 2,
      "x": 365,
      "y": 722
    },
    {
      "t": 82703,
      "e": 82251,
      "ty": 2,
      "x": 398,
      "y": 721
    },
    {
      "t": 82753,
      "e": 82301,
      "ty": 41,
      "x": 5635,
      "y": 30728,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 82803,
      "e": 82351,
      "ty": 2,
      "x": 418,
      "y": 721
    },
    {
      "t": 82903,
      "e": 82451,
      "ty": 2,
      "x": 436,
      "y": 721
    },
    {
      "t": 83003,
      "e": 82551,
      "ty": 2,
      "x": 448,
      "y": 721
    },
    {
      "t": 83004,
      "e": 82552,
      "ty": 41,
      "x": 7603,
      "y": 30728,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 83103,
      "e": 82651,
      "ty": 2,
      "x": 477,
      "y": 721
    },
    {
      "t": 83203,
      "e": 82751,
      "ty": 2,
      "x": 524,
      "y": 724
    },
    {
      "t": 83254,
      "e": 82802,
      "ty": 41,
      "x": 12080,
      "y": 32484,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 83303,
      "e": 82851,
      "ty": 2,
      "x": 554,
      "y": 724
    },
    {
      "t": 83403,
      "e": 82951,
      "ty": 2,
      "x": 602,
      "y": 724
    },
    {
      "t": 83503,
      "e": 83051,
      "ty": 2,
      "x": 625,
      "y": 724
    },
    {
      "t": 83504,
      "e": 83052,
      "ty": 41,
      "x": 16311,
      "y": 32484,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 83603,
      "e": 83151,
      "ty": 2,
      "x": 644,
      "y": 718
    },
    {
      "t": 83704,
      "e": 83252,
      "ty": 2,
      "x": 715,
      "y": 700
    },
    {
      "t": 83754,
      "e": 83302,
      "ty": 41,
      "x": 21476,
      "y": 17855,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 83803,
      "e": 83351,
      "ty": 2,
      "x": 746,
      "y": 699
    },
    {
      "t": 83904,
      "e": 83452,
      "ty": 2,
      "x": 778,
      "y": 699
    },
    {
      "t": 84004,
      "e": 83552,
      "ty": 2,
      "x": 832,
      "y": 701
    },
    {
      "t": 84004,
      "e": 83552,
      "ty": 41,
      "x": 26494,
      "y": 19025,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 84103,
      "e": 83651,
      "ty": 2,
      "x": 902,
      "y": 712
    },
    {
      "t": 84203,
      "e": 83751,
      "ty": 2,
      "x": 920,
      "y": 715
    },
    {
      "t": 84253,
      "e": 83801,
      "ty": 41,
      "x": 31611,
      "y": 27217,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 84305,
      "e": 83853,
      "ty": 2,
      "x": 944,
      "y": 716
    },
    {
      "t": 84403,
      "e": 83951,
      "ty": 2,
      "x": 968,
      "y": 719
    },
    {
      "t": 84506,
      "e": 84054,
      "ty": 2,
      "x": 981,
      "y": 721
    },
    {
      "t": 84507,
      "e": 84055,
      "ty": 41,
      "x": 33825,
      "y": 30728,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 84606,
      "e": 84154,
      "ty": 2,
      "x": 993,
      "y": 722
    },
    {
      "t": 84707,
      "e": 84255,
      "ty": 2,
      "x": 1014,
      "y": 721
    },
    {
      "t": 84757,
      "e": 84305,
      "ty": 41,
      "x": 35743,
      "y": 28973,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 84807,
      "e": 84355,
      "ty": 2,
      "x": 1024,
      "y": 717
    },
    {
      "t": 84907,
      "e": 84455,
      "ty": 2,
      "x": 1035,
      "y": 717
    },
    {
      "t": 85007,
      "e": 84555,
      "ty": 2,
      "x": 1040,
      "y": 716
    },
    {
      "t": 85007,
      "e": 84555,
      "ty": 41,
      "x": 36727,
      "y": 27803,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 85107,
      "e": 84655,
      "ty": 2,
      "x": 1051,
      "y": 714
    },
    {
      "t": 85207,
      "e": 84755,
      "ty": 2,
      "x": 1072,
      "y": 712
    },
    {
      "t": 85257,
      "e": 84805,
      "ty": 41,
      "x": 38695,
      "y": 24292,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 85307,
      "e": 84855,
      "ty": 2,
      "x": 1083,
      "y": 710
    },
    {
      "t": 85406,
      "e": 84954,
      "ty": 2,
      "x": 1093,
      "y": 708
    },
    {
      "t": 85506,
      "e": 85054,
      "ty": 2,
      "x": 1105,
      "y": 706
    },
    {
      "t": 85507,
      "e": 85055,
      "ty": 41,
      "x": 39925,
      "y": 21951,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 85607,
      "e": 85155,
      "ty": 2,
      "x": 1122,
      "y": 706
    },
    {
      "t": 85707,
      "e": 85255,
      "ty": 2,
      "x": 1150,
      "y": 706
    },
    {
      "t": 85757,
      "e": 85305,
      "ty": 41,
      "x": 42877,
      "y": 21951,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 85806,
      "e": 85354,
      "ty": 2,
      "x": 1180,
      "y": 706
    },
    {
      "t": 85906,
      "e": 85454,
      "ty": 2,
      "x": 1181,
      "y": 706
    },
    {
      "t": 86007,
      "e": 85555,
      "ty": 2,
      "x": 1197,
      "y": 703
    },
    {
      "t": 86007,
      "e": 85555,
      "ty": 41,
      "x": 44451,
      "y": 20196,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 86107,
      "e": 85655,
      "ty": 2,
      "x": 1220,
      "y": 698
    },
    {
      "t": 86206,
      "e": 85754,
      "ty": 2,
      "x": 1261,
      "y": 690
    },
    {
      "t": 86257,
      "e": 85805,
      "ty": 41,
      "x": 48141,
      "y": 10834,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 86306,
      "e": 85854,
      "ty": 2,
      "x": 1286,
      "y": 684
    },
    {
      "t": 86407,
      "e": 85955,
      "ty": 2,
      "x": 1306,
      "y": 684
    },
    {
      "t": 86507,
      "e": 86055,
      "ty": 2,
      "x": 1349,
      "y": 689
    },
    {
      "t": 86507,
      "e": 86055,
      "ty": 41,
      "x": 51929,
      "y": 12004,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 86607,
      "e": 86155,
      "ty": 2,
      "x": 1382,
      "y": 691
    },
    {
      "t": 86706,
      "e": 86254,
      "ty": 2,
      "x": 1393,
      "y": 693
    },
    {
      "t": 86757,
      "e": 86305,
      "ty": 41,
      "x": 55127,
      "y": 16100,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 86806,
      "e": 86354,
      "ty": 2,
      "x": 1435,
      "y": 701
    },
    {
      "t": 86907,
      "e": 86455,
      "ty": 2,
      "x": 1469,
      "y": 706
    },
    {
      "t": 87007,
      "e": 86555,
      "ty": 2,
      "x": 1484,
      "y": 706
    },
    {
      "t": 87007,
      "e": 86555,
      "ty": 41,
      "x": 58571,
      "y": 21951,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 87107,
      "e": 86655,
      "ty": 2,
      "x": 1503,
      "y": 706
    },
    {
      "t": 87207,
      "e": 86755,
      "ty": 2,
      "x": 1562,
      "y": 706
    },
    {
      "t": 87257,
      "e": 86805,
      "ty": 41,
      "x": 63097,
      "y": 21951,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 87307,
      "e": 86855,
      "ty": 2,
      "x": 1583,
      "y": 706
    },
    {
      "t": 87406,
      "e": 86954,
      "ty": 2,
      "x": 1621,
      "y": 706
    },
    {
      "t": 87506,
      "e": 87054,
      "ty": 2,
      "x": 1646,
      "y": 706
    },
    {
      "t": 87507,
      "e": 87055,
      "ty": 41,
      "x": 56409,
      "y": 38667,
      "ta": "> div.masterdiv"
    },
    {
      "t": 87607,
      "e": 87155,
      "ty": 2,
      "x": 1659,
      "y": 706
    },
    {
      "t": 87707,
      "e": 87255,
      "ty": 2,
      "x": 1660,
      "y": 706
    },
    {
      "t": 87756,
      "e": 87304,
      "ty": 41,
      "x": 56891,
      "y": 38667,
      "ta": "> div.masterdiv"
    },
    {
      "t": 87907,
      "e": 87455,
      "ty": 2,
      "x": 1654,
      "y": 713
    },
    {
      "t": 88007,
      "e": 87555,
      "ty": 2,
      "x": 1556,
      "y": 747
    },
    {
      "t": 88008,
      "e": 87556,
      "ty": 41,
      "x": 62113,
      "y": 45942,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 88107,
      "e": 87655,
      "ty": 2,
      "x": 1384,
      "y": 795
    },
    {
      "t": 88207,
      "e": 87755,
      "ty": 2,
      "x": 1249,
      "y": 815
    },
    {
      "t": 88257,
      "e": 87805,
      "ty": 41,
      "x": 44796,
      "y": 26349,
      "ta": "> div.masterdiv > div:[2] > div > p:[5]"
    },
    {
      "t": 88307,
      "e": 87855,
      "ty": 2,
      "x": 1166,
      "y": 824
    },
    {
      "t": 88407,
      "e": 87955,
      "ty": 2,
      "x": 1082,
      "y": 824
    },
    {
      "t": 88507,
      "e": 88055,
      "ty": 2,
      "x": 968,
      "y": 809
    },
    {
      "t": 88508,
      "e": 88056,
      "ty": 41,
      "x": 33185,
      "y": 12306,
      "ta": "> div.masterdiv > div:[2] > div > p:[5]"
    },
    {
      "t": 88607,
      "e": 88155,
      "ty": 2,
      "x": 928,
      "y": 802
    },
    {
      "t": 88707,
      "e": 88255,
      "ty": 2,
      "x": 863,
      "y": 787
    },
    {
      "t": 88757,
      "e": 88305,
      "ty": 41,
      "x": 25215,
      "y": 63496,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 88806,
      "e": 88354,
      "ty": 2,
      "x": 779,
      "y": 775
    },
    {
      "t": 88907,
      "e": 88455,
      "ty": 2,
      "x": 764,
      "y": 798
    },
    {
      "t": 89006,
      "e": 88554,
      "ty": 2,
      "x": 760,
      "y": 803
    },
    {
      "t": 89007,
      "e": 88555,
      "ty": 41,
      "x": 22952,
      "y": 5284,
      "ta": "> div.masterdiv > div:[2] > div > p:[5]"
    },
    {
      "t": 89106,
      "e": 88654,
      "ty": 2,
      "x": 761,
      "y": 812
    },
    {
      "t": 89207,
      "e": 88755,
      "ty": 2,
      "x": 767,
      "y": 824
    },
    {
      "t": 89257,
      "e": 88805,
      "ty": 41,
      "x": 23395,
      "y": 33370,
      "ta": "> div.masterdiv > div:[2] > div > p:[5]"
    },
    {
      "t": 89307,
      "e": 88855,
      "ty": 2,
      "x": 771,
      "y": 829
    },
    {
      "t": 89407,
      "e": 88955,
      "ty": 2,
      "x": 772,
      "y": 829
    },
    {
      "t": 89507,
      "e": 89055,
      "ty": 41,
      "x": 23543,
      "y": 35711,
      "ta": "> div.masterdiv > div:[2] > div > p:[5]"
    },
    {
      "t": 90007,
      "e": 89555,
      "ty": 2,
      "x": 779,
      "y": 832
    },
    {
      "t": 90007,
      "e": 89555,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 90010,
      "e": 89558,
      "ty": 41,
      "x": 23887,
      "y": 39222,
      "ta": "> div.masterdiv > div:[2] > div > p:[5]"
    },
    {
      "t": 90207,
      "e": 89755,
      "ty": 2,
      "x": 781,
      "y": 833
    },
    {
      "t": 90257,
      "e": 89805,
      "ty": 41,
      "x": 23985,
      "y": 40392,
      "ta": "> div.masterdiv > div:[2] > div > p:[5]"
    },
    {
      "t": 90507,
      "e": 90055,
      "ty": 2,
      "x": 791,
      "y": 835
    },
    {
      "t": 90507,
      "e": 90055,
      "ty": 41,
      "x": 24477,
      "y": 42733,
      "ta": "> div.masterdiv > div:[2] > div > p:[5]"
    },
    {
      "t": 90607,
      "e": 90155,
      "ty": 2,
      "x": 809,
      "y": 838
    },
    {
      "t": 90706,
      "e": 90254,
      "ty": 2,
      "x": 816,
      "y": 840
    },
    {
      "t": 90757,
      "e": 90305,
      "ty": 41,
      "x": 25953,
      "y": 48584,
      "ta": "> div.masterdiv > div:[2] > div > p:[5]"
    },
    {
      "t": 90807,
      "e": 90355,
      "ty": 2,
      "x": 825,
      "y": 840
    },
    {
      "t": 90907,
      "e": 90455,
      "ty": 2,
      "x": 836,
      "y": 837
    },
    {
      "t": 91007,
      "e": 90555,
      "ty": 2,
      "x": 839,
      "y": 836
    },
    {
      "t": 91007,
      "e": 90555,
      "ty": 41,
      "x": 26839,
      "y": 43903,
      "ta": "> div.masterdiv > div:[2] > div > p:[5]"
    },
    {
      "t": 91107,
      "e": 90655,
      "ty": 2,
      "x": 841,
      "y": 833
    },
    {
      "t": 91207,
      "e": 90755,
      "ty": 2,
      "x": 843,
      "y": 830
    },
    {
      "t": 91257,
      "e": 90805,
      "ty": 41,
      "x": 27036,
      "y": 36881,
      "ta": "> div.masterdiv > div:[2] > div > p:[5]"
    },
    {
      "t": 91307,
      "e": 90855,
      "ty": 2,
      "x": 844,
      "y": 830
    },
    {
      "t": 91508,
      "e": 91056,
      "ty": 41,
      "x": 27085,
      "y": 36881,
      "ta": "> div.masterdiv > div:[2] > div > p:[5]"
    },
    {
      "t": 91531,
      "e": 91079,
      "ty": 3,
      "x": 844,
      "y": 830,
      "ta": "> div.masterdiv > div:[2] > div > p:[5]"
    },
    {
      "t": 91649,
      "e": 91197,
      "ty": 4,
      "x": 27085,
      "y": 36881,
      "ta": "> div.masterdiv > div:[2] > div > p:[5]"
    },
    {
      "t": 91649,
      "e": 91197,
      "ty": 5,
      "x": 844,
      "y": 830,
      "ta": "> div.masterdiv > div:[2] > div > p:[5]"
    },
    {
      "t": 91907,
      "e": 91455,
      "ty": 2,
      "x": 855,
      "y": 900
    },
    {
      "t": 92007,
      "e": 91555,
      "ty": 2,
      "x": 883,
      "y": 986
    },
    {
      "t": 92007,
      "e": 91555,
      "ty": 41,
      "x": 29003,
      "y": 59532,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 92107,
      "e": 91655,
      "ty": 2,
      "x": 903,
      "y": 1029
    },
    {
      "t": 92257,
      "e": 91805,
      "ty": 41,
      "x": 30086,
      "y": 62509,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 92306,
      "e": 91854,
      "ty": 2,
      "x": 908,
      "y": 1033
    },
    {
      "t": 92406,
      "e": 91954,
      "ty": 2,
      "x": 912,
      "y": 1036
    },
    {
      "t": 92507,
      "e": 92055,
      "ty": 41,
      "x": 30430,
      "y": 62994,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 92706,
      "e": 92254,
      "ty": 2,
      "x": 912,
      "y": 1038
    },
    {
      "t": 92757,
      "e": 92305,
      "ty": 41,
      "x": 30430,
      "y": 63132,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 92807,
      "e": 92355,
      "ty": 2,
      "x": 914,
      "y": 1040
    },
    {
      "t": 92907,
      "e": 92455,
      "ty": 2,
      "x": 916,
      "y": 1048
    },
    {
      "t": 93007,
      "e": 92555,
      "ty": 2,
      "x": 922,
      "y": 1065
    },
    {
      "t": 93007,
      "e": 92555,
      "ty": 41,
      "x": 30922,
      "y": 65002,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 93031,
      "e": 92579,
      "ty": 6,
      "x": 924,
      "y": 1073,
      "ta": "#start"
    },
    {
      "t": 93106,
      "e": 92654,
      "ty": 2,
      "x": 926,
      "y": 1083
    },
    {
      "t": 93206,
      "e": 92754,
      "ty": 2,
      "x": 929,
      "y": 1093
    },
    {
      "t": 93257,
      "e": 92805,
      "ty": 41,
      "x": 11195,
      "y": 48789,
      "ta": "#start"
    },
    {
      "t": 93307,
      "e": 92855,
      "ty": 2,
      "x": 931,
      "y": 1100
    },
    {
      "t": 93370,
      "e": 92918,
      "ty": 3,
      "x": 931,
      "y": 1100,
      "ta": "#start"
    },
    {
      "t": 93371,
      "e": 92919,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 93506,
      "e": 93054,
      "ty": 2,
      "x": 931,
      "y": 1101
    },
    {
      "t": 93507,
      "e": 93055,
      "ty": 41,
      "x": 11741,
      "y": 54572,
      "ta": "#start"
    },
    {
      "t": 93513,
      "e": 93061,
      "ty": 4,
      "x": 11741,
      "y": 54572,
      "ta": "#start"
    },
    {
      "t": 93513,
      "e": 93061,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 93514,
      "e": 93062,
      "ty": 5,
      "x": 931,
      "y": 1101,
      "ta": "#start"
    },
    {
      "t": 93515,
      "e": 93063,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 93906,
      "e": 93454,
      "ty": 2,
      "x": 927,
      "y": 1078
    },
    {
      "t": 94007,
      "e": 93555,
      "ty": 2,
      "x": 925,
      "y": 950
    },
    {
      "t": 94007,
      "e": 93555,
      "ty": 41,
      "x": 31579,
      "y": 52184,
      "ta": "html > body"
    },
    {
      "t": 94107,
      "e": 93655,
      "ty": 2,
      "x": 911,
      "y": 732
    },
    {
      "t": 94207,
      "e": 93755,
      "ty": 2,
      "x": 905,
      "y": 599
    },
    {
      "t": 94257,
      "e": 93805,
      "ty": 41,
      "x": 30959,
      "y": 31687,
      "ta": "html > body"
    },
    {
      "t": 94307,
      "e": 93855,
      "ty": 2,
      "x": 907,
      "y": 578
    },
    {
      "t": 94507,
      "e": 94055,
      "ty": 41,
      "x": 30959,
      "y": 31576,
      "ta": "html > body"
    },
    {
      "t": 94546,
      "e": 94094,
      "ty": 38,
      "x": 8,
      "y": 0
    },
    {
      "t": 95779,
      "e": 95327,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":56},{\"id\":57},{\"id\":58},{\"id\":59},{\"id\":60},{\"id\":61},{\"id\":62},{\"id\":63},{\"id\":64},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":72},{\"id\":73},{\"id\":74},{\"id\":75},{\"id\":76},{\"id\":77},{\"id\":78},{\"id\":79},{\"id\":80},{\"id\":81},{\"id\":82},{\"id\":83},{\"id\":84},{\"id\":85},{\"id\":86},{\"id\":87},{\"id\":88},{\"id\":89},{\"id\":90},{\"id\":91},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":96},{\"id\":97},{\"id\":98},{\"id\":99},{\"id\":100},{\"id\":101},{\"id\":102},{\"id\":103},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":109},{\"id\":110},{\"id\":111},{\"id\":112},{\"id\":113},{\"id\":114},{\"id\":115},{\"id\":116},{\"id\":117},{\"id\":118},{\"id\":119},{\"id\":120},{\"id\":121},{\"id\":122},{\"id\":123},{\"id\":124},{\"id\":125},{\"id\":126},{\"id\":127},{\"id\":128},{\"id\":129},{\"id\":130},{\"id\":131},{\"id\":132},{\"id\":133},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":141},{\"id\":142},{\"id\":143},{\"id\":144},{\"id\":145},{\"id\":146},{\"id\":147},{\"id\":148},{\"id\":149},{\"id\":150},{\"id\":151},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":155},{\"id\":156},{\"id\":157},{\"id\":158},{\"id\":159},{\"id\":160},{\"id\":161},{\"id\":162},{\"id\":163},{\"id\":164},{\"id\":165},{\"id\":166},{\"id\":167},{\"id\":168},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":172},{\"id\":173},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":178},{\"id\":179},{\"id\":180},{\"id\":181},{\"id\":182},{\"id\":183},{\"id\":184},{\"id\":185},{\"id\":186},{\"id\":187},{\"id\":188},{\"id\":189},{\"id\":190},{\"id\":191},{\"id\":192},{\"id\":193},{\"id\":194},{\"id\":195},{\"id\":196},{\"id\":197},{\"id\":198},{\"id\":199},{\"id\":200},{\"id\":201},{\"id\":202},{\"id\":203},{\"id\":204},{\"id\":205},{\"id\":206},{\"id\":207},{\"id\":208},{\"id\":209},{\"id\":210},{\"id\":211},{\"id\":212},{\"id\":213},{\"id\":214},{\"id\":215},{\"id\":216},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":220},{\"id\":221},{\"id\":222},{\"id\":223},{\"id\":224},{\"id\":225},{\"id\":226},{\"id\":227},{\"id\":228},{\"id\":229},{\"id\":230},{\"id\":231},{\"id\":232},{\"id\":233},{\"id\":234},{\"id\":235},{\"id\":236},{\"id\":237},{\"id\":238},{\"id\":239},{\"id\":240},{\"id\":241},{\"id\":242},{\"id\":243},{\"id\":244},{\"id\":245},{\"id\":246},{\"id\":247},{\"id\":248},{\"id\":249},{\"id\":250},{\"id\":251},{\"id\":252},{\"id\":253},{\"id\":254},{\"id\":255},{\"id\":256},{\"id\":257},{\"id\":258},{\"id\":259},{\"id\":260},{\"id\":261},{\"id\":262},{\"id\":263},{\"id\":264},{\"id\":265},{\"id\":266},{\"id\":267},{\"id\":268},{\"id\":269},{\"id\":270},{\"id\":271},{\"id\":272},{\"id\":273},{\"id\":274},{\"id\":275},{\"id\":276},{\"id\":277},{\"id\":278},{\"id\":279},{\"id\":280},{\"id\":281},{\"id\":282},{\"id\":283},{\"id\":284},{\"id\":285},{\"id\":286},{\"id\":287},{\"id\":288},{\"id\":289},{\"id\":290},{\"id\":291},{\"id\":292},{\"id\":293},{\"id\":294},{\"id\":295},{\"id\":296},{\"id\":297},{\"id\":298},{\"id\":299},{\"id\":300},{\"id\":301},{\"id\":302},{\"id\":303},{\"id\":304},{\"id\":305},{\"id\":306},{\"id\":307},{\"id\":308},{\"id\":309},{\"id\":310},{\"id\":311},{\"id\":312},{\"id\":313},{\"id\":314},{\"id\":315},{\"id\":316},{\"id\":317},{\"id\":318},{\"id\":319},{\"id\":320},{\"id\":321},{\"id\":322},{\"id\":323},{\"id\":324},{\"id\":325},{\"id\":326},{\"id\":327},{\"id\":328},{\"id\":329},{\"id\":330},{\"id\":331},{\"id\":332},{\"id\":333},{\"id\":334},{\"id\":335},{\"id\":336},{\"id\":337},{\"id\":338},{\"id\":339},{\"id\":340},{\"id\":341},{\"id\":342},{\"id\":343},{\"id\":344},{\"id\":345},{\"id\":346},{\"id\":347},{\"id\":348},{\"id\":349},{\"id\":350},{\"id\":351},{\"id\":352},{\"id\":353},{\"id\":354},{\"id\":355},{\"id\":356},{\"id\":357},{\"id\":358},{\"id\":359},{\"id\":360},{\"id\":361},{\"id\":362},{\"id\":363},{\"id\":364},{\"id\":365},{\"id\":366},{\"id\":367},{\"id\":368},{\"id\":369},{\"id\":370},{\"id\":371},{\"id\":372},{\"id\":373},{\"id\":374},{\"id\":375},{\"id\":376},{\"id\":377},{\"id\":378},{\"id\":379},{\"id\":380},{\"id\":381},{\"id\":382},{\"id\":383},{\"id\":384},{\"id\":385},{\"id\":386},{\"id\":387},{\"id\":388},{\"id\":389},{\"id\":390},{\"id\":391},{\"id\":392},{\"id\":393},{\"id\":394},{\"id\":395},{\"id\":396},{\"id\":397},{\"id\":398},{\"id\":399},{\"id\":400},{\"id\":401},{\"id\":402},{\"id\":403},{\"id\":404},{\"id\":405},{\"id\":406},{\"id\":407},{\"id\":408},{\"id\":409},{\"id\":410},{\"id\":411},{\"id\":412},{\"id\":413},{\"id\":414},{\"id\":415},{\"id\":416},{\"id\":417},{\"id\":418},{\"id\":419},{\"id\":420},{\"id\":421},{\"id\":422},{\"id\":423},{\"id\":424},{\"id\":425},{\"id\":426},{\"id\":427},{\"id\":428},{\"id\":429},{\"id\":430},{\"id\":431},{\"id\":432},{\"id\":433},{\"id\":434},{\"id\":435},{\"id\":436},{\"id\":437},{\"id\":438},{\"id\":439},{\"id\":440},{\"id\":441},{\"id\":442},{\"id\":443},{\"id\":444},{\"id\":445},{\"id\":446},{\"id\":447},{\"id\":448},{\"id\":449},{\"id\":450},{\"id\":451},{\"id\":452},{\"id\":453},{\"id\":454},{\"id\":455},{\"id\":456},{\"id\":457},{\"id\":458},{\"id\":459},{\"id\":460},{\"id\":461},{\"id\":462},{\"id\":463},{\"id\":464},{\"id\":465},{\"id\":466},{\"id\":467},{\"id\":468},{\"id\":469},{\"id\":470},{\"id\":471},{\"id\":472},{\"id\":473},{\"id\":474},{\"id\":475},{\"id\":476},{\"id\":477},{\"id\":478},{\"id\":479},{\"id\":480},{\"id\":481},{\"id\":482},{\"id\":483},{\"id\":484},{\"id\":485},{\"id\":486},{\"id\":487},{\"id\":488},{\"id\":489},{\"id\":490},{\"id\":491},{\"id\":492},{\"id\":493},{\"id\":494},{\"id\":495},{\"id\":496},{\"id\":497},{\"id\":498},{\"id\":499},{\"id\":500},{\"id\":501},{\"id\":502},{\"id\":503},{\"id\":504},{\"id\":505},{\"id\":506},{\"id\":507},{\"id\":508},{\"id\":509},{\"id\":510},{\"id\":511},{\"id\":512},{\"id\":513},{\"id\":514},{\"id\":515},{\"id\":516},{\"id\":517},{\"id\":518},{\"id\":519},{\"id\":520},{\"id\":521},{\"id\":522},{\"id\":523},{\"id\":524},{\"id\":525},{\"id\":526},{\"id\":527},{\"id\":528},{\"id\":529},{\"id\":530},{\"id\":531},{\"id\":532},{\"id\":533},{\"id\":534},{\"id\":535},{\"id\":536},{\"id\":537},{\"id\":538},{\"id\":539},{\"id\":540},{\"id\":541},{\"id\":542},{\"id\":543},{\"id\":544},{\"id\":545},{\"id\":546},{\"id\":547},{\"id\":548},{\"id\":549},{\"id\":550},{\"id\":551},{\"id\":552},{\"id\":553},{\"id\":554},{\"id\":555},{\"id\":556},{\"id\":557},{\"id\":558},{\"id\":559},{\"id\":560},{\"id\":561},{\"id\":562},{\"id\":563},{\"id\":564},{\"id\":565},{\"id\":566},{\"id\":567},{\"id\":568},{\"id\":569},{\"id\":570},{\"id\":571},{\"id\":572},{\"id\":573},{\"id\":574},{\"id\":575},{\"id\":576},{\"id\":577},{\"id\":578},{\"id\":579},{\"id\":580},{\"id\":581},{\"id\":582},{\"id\":583},{\"id\":584},{\"id\":585},{\"id\":586},{\"id\":587},{\"id\":588},{\"id\":589},{\"id\":590},{\"id\":591},{\"id\":592},{\"id\":593},{\"id\":594},{\"id\":595},{\"id\":596},{\"id\":597},{\"id\":598},{\"id\":599},{\"id\":600},{\"id\":601},{\"id\":602},{\"id\":603},{\"id\":604},{\"id\":605},{\"id\":606},{\"id\":607},{\"id\":608},{\"id\":609},{\"id\":610},{\"id\":611},{\"id\":612},{\"id\":613},{\"id\":614},{\"id\":615},{\"id\":616},{\"id\":617},{\"id\":618},{\"id\":619},{\"id\":620},{\"id\":621},{\"id\":622},{\"id\":623},{\"id\":624},{\"id\":625},{\"id\":626},{\"id\":627},{\"id\":628},{\"id\":629},{\"id\":630},{\"id\":631},{\"id\":632},{\"id\":633},{\"id\":634},{\"id\":635},{\"id\":636},{\"id\":637},{\"id\":638},{\"id\":639},{\"id\":640},{\"id\":641},{\"id\":642},{\"id\":643},{\"id\":644},{\"id\":645},{\"id\":646},{\"id\":647},{\"id\":648},{\"id\":649},{\"id\":650},{\"id\":651},{\"id\":652},{\"id\":653},{\"id\":654},{\"id\":655},{\"id\":656},{\"id\":657},{\"id\":658},{\"id\":659},{\"id\":660},{\"id\":661},{\"id\":662},{\"id\":663},{\"id\":664},{\"id\":665},{\"id\":666},{\"id\":667},{\"id\":668},{\"id\":669},{\"id\":670},{\"id\":671},{\"id\":672},{\"id\":673},{\"id\":674},{\"id\":675},{\"id\":676},{\"id\":677},{\"id\":678},{\"id\":679},{\"id\":680},{\"id\":681},{\"id\":682},{\"id\":683},{\"id\":684},{\"id\":685},{\"id\":686},{\"id\":687},{\"id\":688},{\"id\":689},{\"id\":690},{\"id\":691},{\"id\":692},{\"id\":693},{\"id\":694},{\"id\":695},{\"id\":696},{\"id\":697},{\"id\":698},{\"id\":699},{\"id\":700},{\"id\":701},{\"id\":702},{\"id\":703},{\"id\":704},{\"id\":705},{\"id\":706},{\"id\":707},{\"id\":708},{\"id\":709},{\"id\":710},{\"id\":711},{\"id\":712},{\"id\":713},{\"id\":714},{\"id\":715},{\"id\":716},{\"id\":717},{\"id\":718},{\"id\":719},{\"id\":720},{\"id\":721},{\"id\":722},{\"id\":723},{\"id\":724},{\"id\":725},{\"id\":726},{\"id\":727},{\"id\":728},{\"id\":729},{\"id\":730},{\"id\":731},{\"id\":732},{\"id\":733},{\"id\":734},{\"id\":735},{\"id\":736},{\"id\":737},{\"id\":738},{\"id\":739},{\"id\":740},{\"id\":741},{\"id\":742},{\"id\":743},{\"id\":744},{\"id\":745},{\"id\":746},{\"id\":747},{\"id\":748},{\"id\":749},{\"id\":750},{\"id\":751},{\"id\":752},{\"id\":753},{\"id\":754},{\"id\":755},{\"id\":756},{\"id\":757},{\"id\":758},{\"id\":759},{\"id\":760},{\"id\":761},{\"id\":762},{\"id\":763},{\"id\":764},{\"id\":765},{\"id\":766},{\"id\":767},{\"id\":768},{\"id\":769},{\"id\":770},{\"id\":771},{\"id\":772},{\"id\":773},{\"id\":774},{\"id\":775},{\"id\":776},{\"id\":777},{\"id\":778},{\"id\":779},{\"id\":780},{\"id\":781},{\"id\":782},{\"id\":783},{\"id\":784},{\"id\":785},{\"id\":786},{\"id\":787},{\"id\":788},{\"id\":789},{\"id\":790},{\"id\":791},{\"id\":792},{\"id\":793},{\"id\":794},{\"id\":795},{\"id\":796},{\"id\":797},{\"id\":798},{\"id\":799},{\"id\":800},{\"id\":801},{\"id\":802},{\"id\":803},{\"id\":804},{\"id\":805},{\"id\":806},{\"id\":807},{\"id\":808},{\"id\":809},{\"id\":810},{\"id\":811},{\"id\":812},{\"id\":813},{\"id\":814},{\"id\":815},{\"id\":816},{\"id\":817},{\"id\":818},{\"id\":819},{\"id\":820},{\"id\":821},{\"id\":822},{\"id\":823},{\"id\":824},{\"id\":825},{\"id\":826},{\"id\":827},{\"id\":828},{\"id\":829},{\"id\":830},{\"id\":831},{\"id\":832},{\"id\":833},{\"id\":834},{\"id\":835},{\"id\":836},{\"id\":837},{\"id\":838},{\"id\":839},{\"id\":840},{\"id\":841},{\"id\":842},{\"id\":843},{\"id\":844},{\"id\":845},{\"id\":846},{\"id\":847},{\"id\":848},{\"id\":849},{\"id\":850},{\"id\":851},{\"id\":852},{\"id\":853},{\"id\":854},{\"id\":855},{\"id\":856},{\"id\":857},{\"id\":858},{\"id\":859},{\"id\":860},{\"id\":861},{\"id\":862},{\"id\":863},{\"id\":864},{\"id\":865},{\"id\":866},{\"id\":867},{\"id\":868},{\"id\":869},{\"id\":870},{\"id\":871},{\"id\":872},{\"id\":873},{\"id\":874},{\"id\":875},{\"id\":876},{\"id\":877},{\"id\":878},{\"id\":879},{\"id\":880},{\"id\":881},{\"id\":882},{\"id\":883},{\"id\":884},{\"id\":885},{\"id\":886},{\"id\":887},{\"id\":888},{\"id\":889},{\"id\":890},{\"id\":891},{\"id\":892},{\"id\":893},{\"id\":894},{\"id\":895},{\"id\":896},{\"id\":897},{\"id\":898},{\"id\":899},{\"id\":900},{\"id\":901},{\"id\":902},{\"id\":903},{\"id\":904},{\"id\":905},{\"id\":906},{\"id\":907},{\"id\":908},{\"id\":909},{\"id\":910},{\"id\":911},{\"id\":912},{\"id\":913},{\"id\":914},{\"id\":915},{\"id\":916},{\"id\":917},{\"id\":918},{\"id\":919},{\"id\":920},{\"id\":921},{\"id\":922},{\"id\":923},{\"id\":924},{\"id\":925},{\"id\":926},{\"id\":927},{\"id\":928},{\"id\":929},{\"id\":930},{\"id\":931},{\"id\":932},{\"id\":933},{\"id\":934},{\"id\":935},{\"id\":936},{\"id\":937},{\"id\":938},{\"id\":939},{\"id\":940},{\"id\":941},{\"id\":942},{\"id\":943},{\"id\":944},{\"id\":945},{\"id\":946},{\"id\":947},{\"id\":948},{\"id\":949},{\"id\":950},{\"id\":951},{\"id\":952},{\"id\":953},{\"id\":954},{\"id\":955},{\"id\":956},{\"id\":957},{\"id\":958},{\"id\":959},{\"id\":960},{\"id\":961},{\"id\":962},{\"id\":963},{\"id\":964},{\"id\":965},{\"id\":966},{\"id\":967},{\"id\":968},{\"id\":969},{\"id\":970},{\"id\":971},{\"id\":972},{\"id\":973},{\"id\":974},{\"id\":975},{\"id\":976},{\"id\":977},{\"id\":978},{\"id\":979},{\"id\":980},{\"id\":981},{\"id\":982},{\"id\":983},{\"id\":984},{\"id\":985},{\"id\":986},{\"id\":987},{\"id\":988},{\"id\":989},{\"id\":990},{\"id\":991},{\"id\":992},{\"id\":993},{\"id\":994},{\"id\":995},{\"id\":996},{\"id\":997},{\"id\":998},{\"id\":999},{\"id\":1000},{\"id\":1001},{\"id\":1002},{\"id\":1003},{\"id\":1004},{\"id\":1005},{\"id\":1006},{\"id\":1007},{\"id\":1008},{\"id\":1009},{\"id\":1010},{\"id\":1011},{\"id\":1012},{\"id\":1013},{\"id\":1014},{\"id\":1015},{\"id\":1016},{\"id\":1017},{\"id\":1018},{\"id\":1019},{\"id\":1020},{\"id\":1021},{\"id\":1022},{\"id\":1023},{\"id\":1024},{\"id\":1025},{\"id\":1026},{\"id\":1027},{\"id\":1028},{\"id\":1029},{\"id\":1030},{\"id\":1031},{\"id\":1032},{\"id\":1033},{\"id\":1034},{\"id\":1035},{\"id\":1036},{\"id\":1037},{\"id\":1038},{\"id\":1039},{\"id\":1040},{\"id\":1041},{\"id\":1042},{\"id\":1043},{\"id\":1044},{\"id\":1045},{\"id\":1046},{\"id\":1047},{\"id\":1048},{\"id\":1049},{\"id\":1050},{\"id\":1051},{\"id\":1052},{\"id\":1053},{\"id\":1054},{\"id\":1055},{\"id\":1056},{\"id\":1057},{\"id\":1058},{\"id\":1059},{\"id\":1060},{\"id\":1061},{\"id\":1062},{\"id\":1063},{\"id\":1064},{\"id\":1065},{\"id\":1066},{\"id\":1067},{\"id\":1068},{\"id\":1069},{\"id\":1070},{\"id\":1071},{\"id\":1072},{\"id\":1073},{\"id\":1074},{\"id\":1075},{\"id\":1076},{\"id\":1077},{\"id\":1078},{\"id\":1079},{\"id\":1080},{\"id\":1081},{\"id\":1082},{\"id\":1083},{\"id\":1084},{\"id\":1085},{\"id\":1086},{\"id\":1087},{\"id\":1088},{\"id\":1089},{\"id\":1090},{\"id\":1091},{\"id\":1092},{\"id\":1093},{\"id\":1094},{\"id\":1095},{\"id\":1096},{\"id\":1097},{\"id\":1098},{\"id\":1099},{\"id\":1100},{\"id\":1101},{\"id\":1102},{\"id\":1103},{\"id\":1104},{\"id\":1105},{\"id\":1106},{\"id\":1107},{\"id\":1108},{\"id\":1109},{\"id\":1110},{\"id\":1111},{\"id\":1112},{\"id\":1113},{\"id\":1114},{\"id\":1115},{\"id\":1116},{\"id\":1117},{\"id\":1118},{\"id\":1119},{\"id\":1120},{\"id\":1121},{\"id\":1122},{\"id\":1123},{\"id\":1124},{\"id\":1125},{\"id\":1126},{\"id\":1127},{\"id\":1128},{\"id\":1129},{\"id\":1130},{\"id\":1131},{\"id\":1132},{\"id\":1133},{\"id\":1134},{\"id\":1135},{\"id\":1136},{\"id\":1137},{\"id\":1138},{\"id\":1139},{\"id\":1140},{\"id\":1141},{\"id\":1142},{\"id\":1143},{\"id\":1144},{\"id\":1145},{\"id\":1146},{\"id\":1147},{\"id\":1148},{\"id\":1149},{\"id\":1150},{\"id\":1151},{\"id\":1152},{\"id\":1153},{\"id\":1154},{\"id\":1155},{\"id\":1156},{\"id\":1157},{\"id\":1158},{\"id\":1159},{\"id\":1160},{\"id\":1161},{\"id\":1162},{\"id\":1163},{\"id\":1164},{\"id\":1165},{\"id\":1166},{\"id\":1167},{\"id\":1168},{\"id\":1169},{\"id\":1170},{\"id\":1171},{\"id\":1172},{\"id\":1173},{\"id\":1174},{\"id\":1175},{\"id\":1176},{\"id\":1177},{\"id\":1178},{\"id\":1179},{\"id\":1180},{\"id\":1181},{\"id\":1182},{\"id\":1183},{\"id\":1184},{\"id\":1185},{\"id\":1186},{\"id\":1187},{\"id\":1188},{\"id\":1189},{\"id\":1190},{\"id\":1191},{\"id\":1192},{\"id\":1193},{\"id\":1194},{\"id\":1195},{\"id\":1196},{\"id\":1197},{\"id\":1198},{\"id\":1199},{\"id\":1200},{\"id\":1201},{\"id\":1202},{\"id\":1203},{\"id\":1204},{\"id\":1205},{\"id\":1206},{\"id\":1207},{\"id\":1208},{\"id\":1209},{\"id\":1210},{\"id\":1211},{\"id\":1212},{\"id\":1213},{\"id\":1214},{\"id\":1215},{\"id\":1216},{\"id\":1217},{\"id\":1218},{\"id\":1219},{\"id\":1220},{\"id\":1221},{\"id\":1222},{\"id\":1223},{\"id\":1224},{\"id\":1225},{\"id\":1226},{\"id\":1227},{\"id\":1228},{\"id\":1229},{\"id\":1230},{\"id\":1231},{\"id\":1232},{\"id\":1233},{\"id\":1234},{\"id\":1235},{\"id\":1236},{\"id\":1237},{\"id\":1238},{\"id\":1239},{\"id\":1240},{\"id\":1241},{\"id\":1242},{\"id\":1243},{\"id\":1244},{\"id\":1245},{\"id\":1246},{\"id\":1247},{\"id\":1248},{\"id\":1249},{\"id\":1250},{\"id\":1251},{\"id\":1252},{\"id\":1253},{\"id\":1254},{\"id\":1255},{\"id\":1256},{\"id\":1257},{\"id\":1258},{\"id\":1259},{\"id\":1260},{\"id\":1261},{\"id\":1262},{\"id\":1263},{\"id\":1264},{\"id\":1265},{\"id\":1266},{\"id\":1267},{\"id\":1268},{\"id\":1269},{\"id\":1270},{\"id\":1271},{\"id\":1272},{\"id\":1273},{\"id\":1274},{\"id\":1275},{\"id\":1276},{\"id\":1277},{\"id\":1278},{\"id\":1279},{\"id\":1280},{\"id\":1281},{\"id\":1282},{\"id\":1283},{\"id\":1284},{\"id\":1285},{\"id\":1286},{\"id\":1287},{\"id\":1288},{\"id\":1289},{\"id\":1290},{\"id\":1291},{\"id\":1292},{\"id\":1293},{\"id\":1294},{\"id\":1295},{\"id\":1296},{\"id\":1297},{\"id\":1298},{\"id\":1299},{\"id\":1300},{\"id\":1301},{\"id\":1302},{\"id\":1303},{\"id\":1304},{\"id\":1305},{\"id\":1306},{\"id\":1307},{\"id\":1308},{\"id\":1309},{\"id\":1310},{\"id\":1311},{\"id\":1312},{\"id\":1313},{\"id\":1314},{\"id\":1315},{\"id\":1316},{\"id\":1317},{\"id\":1318},{\"id\":1319},{\"id\":1320},{\"id\":1321},{\"id\":1322},{\"id\":1323},{\"id\":1324},{\"id\":1325},{\"id\":1326},{\"id\":1327},{\"id\":1328},{\"id\":1329},{\"id\":1330},{\"id\":1331},{\"id\":1332},{\"id\":1333},{\"id\":1334},{\"id\":1335},{\"id\":1336},{\"id\":1337},{\"id\":1338},{\"id\":1339},{\"id\":1340},{\"id\":1341},{\"id\":1342},{\"id\":1343},{\"id\":1344},{\"id\":1345},{\"id\":1346},{\"id\":1347},{\"id\":1348},{\"id\":1349},{\"id\":1350},{\"id\":1351},{\"id\":1352},{\"id\":1353},{\"id\":1354},{\"id\":1355},{\"id\":1356},{\"id\":1357},{\"id\":1358},{\"id\":1359},{\"id\":1360},{\"id\":1361},{\"id\":1362},{\"id\":1363},{\"id\":1364},{\"id\":1365},{\"id\":1366},{\"id\":1367},{\"id\":1368},{\"id\":1369},{\"id\":1370},{\"id\":1371},{\"id\":1372},{\"id\":1373},{\"id\":1374},{\"id\":1375},{\"id\":1376},{\"id\":1377},{\"id\":1378},{\"id\":1379},{\"id\":1380},{\"id\":1381},{\"id\":1382},{\"id\":1383},{\"id\":1384},{\"id\":1385},{\"id\":1386},{\"id\":1387},{\"id\":1388},{\"id\":1389},{\"id\":1390},{\"id\":1391},{\"id\":1392},{\"id\":1393},{\"id\":1394},{\"id\":1395},{\"id\":1396},{\"id\":1397},{\"id\":1398},{\"id\":1399},{\"id\":1400},{\"id\":1401},{\"id\":1402},{\"id\":1403},{\"id\":1404},{\"id\":1405},{\"id\":1406},{\"id\":1407},{\"id\":1408},{\"id\":1409},{\"id\":1410},{\"id\":1411},{\"id\":1412},{\"id\":1413},{\"id\":1414},{\"id\":1415},{\"id\":1416},{\"id\":1417},{\"id\":1418},{\"id\":1419},{\"id\":1420},{\"id\":1421},{\"id\":1422},{\"id\":1423},{\"id\":1424},{\"id\":1425},{\"id\":1426},{\"id\":1427},{\"id\":1428},{\"id\":1429},{\"id\":1430},{\"id\":1431},{\"id\":1432},{\"id\":1433},{\"id\":1434},{\"id\":1435},{\"id\":1436},{\"id\":1437},{\"id\":1438},{\"id\":1439},{\"id\":1440},{\"id\":1441},{\"id\":1442},{\"id\":1443},{\"id\":1444},{\"id\":1445},{\"id\":1446},{\"id\":1447},{\"id\":1448},{\"id\":1449},{\"id\":1450},{\"id\":1451},{\"id\":1452},{\"id\":1453},{\"id\":1454},{\"id\":1455},{\"id\":1456},{\"id\":1457},{\"id\":1458},{\"id\":1459},{\"id\":1460},{\"id\":1461},{\"id\":1462},{\"id\":1463},{\"id\":1464},{\"id\":1465},{\"id\":1466},{\"id\":1467},{\"id\":1468},{\"id\":1469},{\"id\":1470},{\"id\":1471},{\"id\":1472},{\"id\":1473},{\"id\":1474},{\"id\":1475},{\"id\":1476},{\"id\":1477},{\"id\":1478},{\"id\":1479},{\"id\":1480},{\"id\":1481},{\"id\":1482},{\"id\":1483},{\"id\":1484},{\"id\":1485},{\"id\":1486},{\"id\":1487},{\"id\":1488},{\"id\":1489},{\"id\":1490},{\"id\":1491},{\"id\":1492},{\"id\":1493},{\"id\":1494},{\"id\":1495},{\"id\":1496},{\"id\":1497},{\"id\":1498},{\"id\":1499},{\"id\":1500},{\"id\":1501},{\"id\":1502},{\"id\":1503},{\"id\":1504},{\"id\":1505},{\"id\":1506},{\"id\":1507},{\"id\":1508},{\"id\":1509},{\"id\":1510},{\"id\":1511},{\"id\":1512},{\"id\":1513},{\"id\":1514},{\"id\":1515},{\"id\":1516},{\"id\":1517},{\"id\":1518},{\"id\":1519},{\"id\":1520},{\"id\":1521},{\"id\":1522},{\"id\":1523},{\"id\":1524},{\"id\":1525},{\"id\":1526},{\"id\":1527},{\"id\":1528},{\"id\":1529},{\"id\":1530},{\"id\":1531},{\"id\":1532},{\"id\":1533},{\"id\":1534},{\"id\":1535},{\"id\":1536},{\"id\":1537},{\"id\":1538},{\"id\":1539},{\"id\":1540},{\"id\":1541},{\"id\":1542},{\"id\":1543},{\"id\":1544},{\"id\":1545},{\"id\":1546},{\"id\":1547},{\"id\":1548},{\"id\":1549},{\"id\":1550},{\"id\":1551},{\"id\":1552},{\"id\":1553},{\"id\":1554},{\"id\":1555},{\"id\":1556},{\"id\":1557},{\"id\":1558},{\"id\":1559},{\"id\":1560},{\"id\":1561},{\"id\":1562},{\"id\":1563},{\"id\":1564},{\"id\":1565},{\"id\":1566},{\"id\":1567},{\"id\":1568},{\"id\":1569},{\"id\":1570},{\"id\":1571},{\"id\":1572},{\"id\":1573},{\"id\":1574},{\"id\":1575},{\"id\":1576},{\"id\":1577},{\"id\":1578},{\"id\":1579},{\"id\":1580},{\"id\":1581},{\"id\":1582},{\"id\":1583},{\"id\":1584},{\"id\":1585},{\"id\":1586},{\"id\":1587},{\"id\":1588},{\"id\":1589},{\"id\":1590},{\"id\":1591},{\"id\":1592},{\"id\":1593},{\"id\":1594},{\"id\":1595},{\"id\":1596},{\"id\":1597},{\"id\":1598},{\"id\":1599},{\"id\":1600},{\"id\":1601},{\"id\":1602},{\"id\":1603},{\"id\":1604},{\"id\":1605},{\"id\":1606},{\"id\":1607},{\"id\":1608},{\"id\":1609},{\"id\":1610},{\"id\":1611},{\"id\":1612},{\"id\":1613},{\"id\":1614},{\"id\":1615},{\"id\":1616},{\"id\":1617},{\"id\":1618},{\"id\":1619},{\"id\":1620},{\"id\":1621},{\"id\":1622},{\"id\":1623},{\"id\":1624},{\"id\":1625},{\"id\":1626},{\"id\":1627},{\"id\":1628},{\"id\":1629},{\"id\":1630},{\"id\":1631},{\"id\":1632},{\"id\":1633},{\"id\":1634},{\"id\":1635},{\"id\":1636},{\"id\":1637},{\"id\":1638},{\"id\":1639},{\"id\":1640},{\"id\":1641},{\"id\":1642},{\"id\":1643},{\"id\":1644},{\"id\":1645},{\"id\":1646},{\"id\":1647},{\"id\":1648},{\"id\":1649},{\"id\":1650},{\"id\":1651},{\"id\":1652},{\"id\":1653},{\"id\":1654},{\"id\":1655},{\"id\":1656},{\"id\":1657},{\"id\":1658},{\"id\":1659},{\"id\":1660},{\"id\":1661},{\"id\":1662},{\"id\":1663},{\"id\":1664},{\"id\":1665},{\"id\":1666},{\"id\":1667},{\"id\":1668},{\"id\":1669},{\"id\":1670},{\"id\":1671},{\"id\":1672},{\"id\":1673},{\"id\":1674},{\"id\":1675},{\"id\":1676},{\"id\":1677},{\"id\":1678},{\"id\":1679},{\"id\":1680},{\"id\":1681},{\"id\":1682},{\"id\":1683},{\"id\":1684},{\"id\":1685},{\"id\":1686},{\"id\":1687},{\"id\":1688},{\"id\":1689},{\"id\":1690},{\"id\":1691},{\"id\":1692},{\"id\":1693},{\"id\":1694},{\"id\":1695},{\"id\":1696},{\"id\":1697},{\"id\":1698},{\"id\":1699},{\"id\":1700},{\"id\":1701},{\"id\":1702},{\"id\":1703},{\"id\":1704},{\"id\":1705},{\"id\":1706},{\"id\":1707},{\"id\":1708},{\"id\":1709},{\"id\":1710},{\"id\":1711},{\"id\":1712},{\"id\":1713},{\"id\":1714},{\"id\":1715},{\"id\":1716},{\"id\":1717},{\"id\":1718},{\"id\":1719},{\"id\":1720},{\"id\":1721},{\"id\":1722},{\"id\":1723},{\"id\":1724},{\"id\":1725},{\"id\":1726},{\"id\":1727},{\"id\":1728},{\"id\":1729},{\"id\":1730},{\"id\":1731},{\"id\":1732},{\"id\":1733},{\"id\":1734},{\"id\":1735},{\"id\":1736},{\"id\":1737},{\"id\":1738},{\"id\":1739},{\"id\":1740},{\"id\":1741},{\"id\":1742},{\"id\":1743},{\"id\":1744},{\"id\":1745},{\"id\":1746},{\"id\":1747},{\"id\":1748},{\"id\":1749},{\"id\":1750},{\"id\":1751},{\"id\":1752},{\"id\":1753},{\"id\":1754},{\"id\":1755},{\"id\":1756},{\"id\":1757},{\"id\":1758},{\"id\":1759},{\"id\":1760},{\"id\":1761},{\"id\":1762},{\"id\":1763},{\"id\":1764},{\"id\":1765},{\"id\":1766},{\"id\":1767},{\"id\":1768},{\"id\":1769},{\"id\":1770},{\"id\":1771},{\"id\":1772},{\"id\":1773},{\"id\":1774},{\"id\":1775},{\"id\":1776},{\"id\":1777},{\"id\":1778},{\"id\":1779},{\"id\":1780},{\"id\":1781},{\"id\":1782},{\"id\":1783},{\"id\":1784},{\"id\":1785},{\"id\":1786},{\"id\":1787},{\"id\":1788},{\"id\":1789},{\"id\":1790},{\"id\":1791},{\"id\":1792},{\"id\":1793},{\"id\":1794},{\"id\":1795},{\"id\":1796},{\"id\":1797},{\"id\":1798},{\"id\":1799},{\"id\":1800},{\"id\":1801},{\"id\":1802},{\"id\":1803},{\"id\":1804},{\"id\":1805},{\"id\":1806},{\"id\":1807},{\"id\":1808},{\"id\":1809},{\"id\":1810},{\"id\":1811},{\"id\":1812},{\"id\":1813},{\"id\":1814},{\"id\":1815},{\"id\":1816},{\"id\":1817},{\"id\":1818},{\"id\":1819},{\"id\":1820},{\"id\":1821},{\"id\":1822},{\"id\":1823},{\"id\":1824},{\"id\":1825},{\"id\":1826},{\"id\":1827},{\"id\":1828},{\"id\":1829},{\"id\":1830},{\"id\":1831},{\"id\":1832},{\"id\":1833},{\"id\":1834},{\"id\":1835},{\"id\":1836},{\"id\":1837},{\"id\":1838},{\"id\":1839},{\"id\":1840},{\"id\":1841},{\"id\":1842},{\"id\":1843},{\"id\":1844},{\"id\":1845},{\"id\":1846},{\"id\":1847},{\"id\":1848},{\"id\":1849},{\"id\":1850},{\"id\":1851},{\"id\":1852},{\"id\":1853},{\"id\":1854},{\"id\":1855},{\"id\":1856},{\"id\":1857},{\"id\":1858},{\"id\":1859},{\"id\":1860},{\"id\":1861},{\"id\":1862},{\"id\":1863},{\"id\":1864},{\"id\":1865},{\"id\":1866},{\"id\":1867},{\"id\":1868},{\"id\":1869},{\"id\":1870},{\"id\":1871},{\"id\":1872},{\"id\":1873},{\"id\":1874},{\"id\":1875},{\"id\":1876},{\"id\":1877},{\"id\":1878},{\"id\":1879},{\"id\":1880},{\"id\":1881},{\"id\":1882},{\"id\":1883},{\"id\":1884},{\"id\":1885},{\"id\":1886},{\"id\":1887},{\"id\":1888},{\"id\":1889},{\"id\":1890},{\"id\":1891},{\"id\":1892},{\"id\":1893},{\"id\":1894},{\"id\":1895},{\"id\":1896},{\"id\":1897},{\"id\":1898},{\"id\":1899},{\"id\":1900},{\"id\":1901},{\"id\":1902},{\"id\":1903},{\"id\":1904},{\"id\":1905},{\"id\":1906},{\"id\":1907},{\"id\":1908},{\"id\":1909},{\"id\":1910},{\"id\":1911},{\"id\":1912},{\"id\":1913},{\"id\":1914},{\"id\":1915},{\"id\":1916},{\"id\":1917},{\"id\":1918},{\"id\":1919},{\"id\":1920},{\"id\":1921},{\"id\":1922},{\"id\":1923},{\"id\":1924},{\"id\":1925},{\"id\":1926},{\"id\":1927},{\"id\":1928},{\"id\":1929},{\"id\":1930},{\"id\":1931},{\"id\":1932},{\"id\":1933},{\"id\":1934},{\"id\":1935},{\"id\":1936},{\"id\":1937},{\"id\":1938},{\"id\":1939},{\"id\":1940},{\"id\":1941},{\"id\":1942},{\"id\":1943},{\"id\":1944},{\"id\":1945},{\"id\":1946},{\"id\":1947},{\"id\":1948},{\"id\":1949},{\"id\":1950},{\"id\":1951},{\"id\":1952},{\"id\":1953},{\"id\":1954},{\"id\":1955},{\"id\":1956},{\"id\":1957},{\"id\":1958},{\"id\":1959},{\"id\":1960},{\"id\":1961},{\"id\":1962},{\"id\":1963},{\"id\":1964},{\"id\":1965},{\"id\":1966},{\"id\":1967},{\"id\":1968},{\"id\":1969},{\"id\":1970},{\"id\":1971},{\"id\":1972},{\"id\":1973},{\"id\":1974},{\"id\":1975},{\"id\":1976},{\"id\":1977},{\"id\":1978},{\"id\":1979},{\"id\":1980},{\"id\":1981},{\"id\":1982},{\"id\":1983},{\"id\":1984},{\"id\":1985},{\"id\":1986},{\"id\":1987},{\"id\":1988},{\"id\":1989},{\"id\":1990},{\"id\":1991},{\"id\":1992},{\"id\":1993},{\"id\":1994},{\"id\":1995},{\"id\":1996},{\"id\":1997},{\"id\":1998},{\"id\":1999},{\"id\":2000},{\"id\":2001},{\"id\":2002},{\"id\":2003},{\"id\":2004},{\"id\":2005},{\"id\":2006},{\"id\":2007},{\"id\":2008},{\"id\":2009},{\"id\":2010},{\"id\":2011},{\"id\":2012},{\"id\":2013},{\"id\":2014},{\"id\":2015},{\"id\":2016},{\"id\":2017},{\"id\":2018},{\"id\":2019},{\"id\":2020},{\"id\":2021},{\"id\":2022},{\"id\":2023},{\"id\":2024},{\"id\":2025},{\"id\":2026},{\"id\":2027},{\"id\":2028},{\"id\":2029},{\"id\":2030},{\"id\":2031},{\"id\":2032},{\"id\":2033},{\"id\":2034},{\"id\":2035},{\"id\":2036},{\"id\":2037},{\"id\":2038},{\"id\":2039},{\"id\":2040},{\"id\":2041},{\"id\":2042},{\"id\":2043},{\"id\":2044},{\"id\":2045},{\"id\":2046},{\"id\":2047},{\"id\":2048},{\"id\":2049},{\"id\":2050},{\"id\":2051},{\"id\":2052},{\"id\":2053},{\"id\":2054},{\"id\":2055},{\"id\":2056},{\"id\":2057},{\"id\":2058},{\"id\":2059},{\"id\":2060},{\"id\":2061},{\"id\":2062},{\"id\":2063},{\"id\":2064},{\"id\":2065},{\"id\":2066},{\"id\":2067},{\"id\":2068},{\"id\":2069},{\"id\":2070},{\"id\":2071},{\"id\":2072},{\"id\":2073},{\"id\":2074},{\"id\":2075},{\"id\":2076},{\"id\":2077},{\"id\":2078},{\"id\":2079},{\"id\":2080},{\"id\":2081},{\"id\":2082},{\"id\":2083},{\"id\":2084},{\"id\":2085},{\"id\":2086},{\"id\":2087},{\"id\":2088},{\"id\":2089},{\"id\":2090},{\"id\":2091},{\"id\":2092},{\"id\":2093},{\"id\":2094},{\"id\":2095},{\"id\":2096},{\"id\":2097},{\"id\":2098},{\"id\":2099},{\"id\":2100},{\"id\":2101},{\"id\":2102},{\"id\":2103},{\"id\":2104},{\"id\":2105},{\"id\":2106},{\"id\":2107},{\"id\":2108},{\"id\":2109},{\"id\":2110},{\"id\":2111},{\"id\":2112},{\"id\":2113},{\"id\":2114},{\"id\":2115},{\"id\":2116},{\"id\":2117},{\"id\":2118},{\"id\":2119},{\"id\":2120},{\"id\":2121},{\"id\":2122},{\"id\":2123},{\"id\":2124},{\"id\":2125},{\"id\":2126},{\"id\":2127},{\"id\":2128},{\"id\":2129},{\"id\":2130},{\"id\":2131},{\"id\":2132},{\"id\":2133},{\"id\":2134},{\"id\":2135},{\"id\":2136},{\"id\":2137},{\"id\":2138},{\"id\":2139},{\"id\":2140},{\"id\":2141},{\"id\":2142},{\"id\":2143},{\"id\":2144},{\"id\":2145},{\"id\":2146},{\"id\":2147},{\"id\":2148},{\"id\":2149},{\"id\":2150},{\"id\":2151},{\"id\":2152},{\"id\":2153},{\"id\":2154},{\"id\":2155},{\"id\":2156},{\"id\":2157},{\"id\":2158},{\"id\":2159},{\"id\":2160},{\"id\":2161},{\"id\":2162},{\"id\":2163},{\"id\":2164},{\"id\":2165},{\"id\":2166},{\"id\":2167},{\"id\":2168},{\"id\":2169},{\"id\":2170},{\"id\":2171},{\"id\":2172},{\"id\":2173},{\"id\":2174},{\"id\":2175},{\"id\":2176},{\"id\":2177},{\"id\":2178},{\"id\":2179},{\"id\":2180},{\"id\":2181},{\"id\":2182},{\"id\":2183},{\"id\":2184},{\"id\":2185},{\"id\":2186},{\"id\":2187},{\"id\":2188},{\"id\":2189},{\"id\":2190},{\"id\":2191},{\"id\":2192},{\"id\":2193},{\"id\":2194},{\"id\":2195},{\"id\":2196},{\"id\":2197},{\"id\":2198},{\"id\":2199},{\"id\":2200},{\"id\":2201},{\"id\":2202},{\"id\":2203},{\"id\":2204},{\"id\":2205},{\"id\":2206},{\"id\":2207},{\"id\":2208},{\"id\":2209},{\"id\":2210},{\"id\":2211},{\"id\":2212},{\"id\":2213},{\"id\":2214},{\"id\":2215},{\"id\":2216},{\"id\":2217},{\"id\":2218},{\"id\":2219},{\"id\":2220},{\"id\":2221},{\"id\":2222},{\"id\":2223},{\"id\":2224},{\"id\":2225},{\"id\":2226},{\"id\":2227},{\"id\":2228},{\"id\":2229},{\"id\":2230},{\"id\":2231},{\"id\":2232},{\"id\":2233},{\"id\":2234},{\"id\":2235},{\"id\":2236},{\"id\":2237},{\"id\":2238},{\"id\":2239},{\"id\":2240},{\"id\":2241},{\"id\":2242},{\"id\":2243},{\"id\":2244},{\"id\":2245},{\"id\":2246},{\"id\":2247},{\"id\":2248},{\"id\":2249},{\"id\":2250},{\"id\":2251},{\"id\":2252},{\"id\":2253},{\"id\":2254},{\"id\":2255},{\"id\":2256},{\"id\":2257},{\"id\":2258},{\"id\":2259},{\"id\":2260},{\"id\":2261},{\"id\":2262},{\"id\":2263},{\"id\":2264},{\"id\":2265},{\"id\":2266},{\"id\":2267},{\"id\":2268},{\"id\":2269},{\"id\":2270},{\"id\":2271},{\"id\":2272},{\"id\":2273},{\"id\":2274},{\"id\":2275},{\"id\":2276},{\"id\":2277},{\"id\":2278},{\"id\":2279},{\"id\":2280},{\"id\":2281},{\"id\":2282},{\"id\":2283},{\"id\":2284},{\"id\":2285},{\"id\":2286},{\"id\":2287},{\"id\":2288},{\"id\":2289},{\"id\":2290},{\"id\":2291},{\"id\":2292},{\"id\":2293},{\"id\":2294},{\"id\":2295},{\"id\":2296},{\"id\":2297},{\"id\":2298},{\"id\":2299},{\"id\":2300},{\"id\":2301},{\"id\":2302},{\"id\":2303},{\"id\":2304},{\"id\":2305},{\"id\":2306},{\"id\":2307},{\"id\":2308},{\"id\":2309},{\"id\":2310},{\"id\":2311},{\"id\":2312},{\"id\":2313},{\"id\":2314},{\"id\":2315},{\"id\":2316},{\"id\":2317},{\"id\":2318},{\"id\":2319},{\"id\":2320},{\"id\":2321},{\"id\":2322},{\"id\":2323},{\"id\":2324},{\"id\":2325},{\"id\":2326},{\"id\":2327},{\"id\":2328},{\"id\":2329},{\"id\":2330},{\"id\":2331},{\"id\":2332},{\"id\":2333},{\"id\":2334},{\"id\":2335},{\"id\":2336},{\"id\":2337},{\"id\":2338},{\"id\":2339},{\"id\":2340},{\"id\":2341},{\"id\":2342},{\"id\":2343},{\"id\":2344},{\"id\":2345},{\"id\":2346},{\"id\":2347},{\"id\":2348},{\"id\":2349},{\"id\":2350},{\"id\":2351},{\"id\":2352},{\"id\":2353},{\"id\":2354},{\"id\":2355},{\"id\":2356},{\"id\":2357},{\"id\":2358},{\"id\":2359},{\"id\":2360},{\"id\":2361},{\"id\":2362},{\"id\":2363},{\"id\":2364},{\"id\":2365},{\"id\":2366},{\"id\":2367},{\"id\":2368},{\"id\":2369},{\"id\":2370},{\"id\":2371},{\"id\":2372},{\"id\":2373},{\"id\":2374},{\"id\":2375},{\"id\":2376},{\"id\":2377},{\"id\":2378},{\"id\":2379},{\"id\":2380},{\"id\":2381},{\"id\":2382},{\"id\":2383},{\"id\":2384},{\"id\":2385},{\"id\":2386},{\"id\":2387},{\"id\":2388},{\"id\":2389},{\"id\":2390},{\"id\":2391},{\"id\":2392},{\"id\":2393},{\"id\":2394},{\"id\":2395},{\"id\":2396},{\"id\":2397},{\"id\":2398},{\"id\":2399},{\"id\":2400},{\"id\":2401},{\"id\":2402},{\"id\":2403},{\"id\":2404},{\"id\":2405},{\"id\":2406},{\"id\":2407},{\"id\":2408},{\"id\":2409},{\"id\":2410},{\"id\":2411},{\"id\":2412},{\"id\":2413},{\"id\":2414},{\"id\":2415},{\"id\":2416},{\"id\":2417},{\"id\":2418},{\"id\":2419},{\"id\":2420},{\"id\":2421},{\"id\":2422},{\"id\":2423},{\"id\":2424},{\"id\":2425},{\"id\":2426},{\"id\":2427},{\"id\":2428},{\"id\":2429},{\"id\":2430},{\"id\":2431},{\"id\":2432},{\"id\":2433},{\"id\":2434},{\"id\":2435},{\"id\":2436},{\"id\":2437},{\"id\":2438},{\"id\":2439},{\"id\":2440},{\"id\":2441},{\"id\":2442},{\"id\":2443},{\"id\":2444},{\"id\":2445},{\"id\":2446},{\"id\":2447},{\"id\":2448},{\"id\":2449},{\"id\":2450},{\"id\":2451},{\"id\":2452},{\"id\":2453},{\"id\":2454},{\"id\":2455},{\"id\":2456},{\"id\":2457},{\"id\":2458},{\"id\":2459},{\"id\":2460},{\"id\":2461},{\"id\":2462},{\"id\":2463},{\"id\":2464},{\"id\":2465},{\"id\":2466},{\"id\":2467},{\"id\":2468},{\"id\":2469},{\"id\":2470},{\"id\":2471},{\"id\":2472},{\"id\":2473},{\"id\":2474},{\"id\":2475},{\"id\":2476},{\"id\":2477},{\"id\":2478},{\"id\":2479},{\"id\":2480},{\"id\":2481},{\"id\":2482},{\"id\":2483},{\"id\":2484},{\"id\":2485},{\"id\":2486},{\"id\":2487},{\"id\":2488},{\"id\":2489},{\"id\":2490},{\"id\":2491},{\"id\":2492},{\"id\":2493},{\"id\":2494},{\"id\":2495},{\"id\":2496},{\"id\":2497},{\"id\":2498},{\"id\":2499},{\"id\":2500},{\"id\":2501},{\"id\":2502},{\"id\":2503},{\"id\":2504},{\"id\":2505},{\"id\":2506},{\"id\":2507},{\"id\":2508},{\"id\":2509},{\"id\":2510},{\"id\":2511},{\"id\":2512},{\"id\":2513},{\"id\":2514},{\"id\":2515},{\"id\":2516},{\"id\":2517},{\"id\":2518},{\"id\":2519},{\"id\":2520},{\"id\":2521},{\"id\":2522},{\"id\":2523},{\"id\":2524},{\"id\":2525},{\"id\":2526},{\"id\":2527},{\"id\":2528},{\"id\":2529},{\"id\":2530},{\"id\":2531},{\"id\":2532},{\"id\":2533},{\"id\":2534},{\"id\":2535},{\"id\":2536},{\"id\":2537},{\"id\":2538},{\"id\":2539},{\"id\":2540},{\"id\":2541},{\"id\":2542},{\"id\":2543},{\"id\":2544},{\"id\":2545},{\"id\":2546},{\"id\":2547},{\"id\":2548},{\"id\":2549},{\"id\":2550},{\"id\":2551},{\"id\":2552},{\"id\":2553},{\"id\":2554},{\"id\":2555},{\"id\":2556},{\"id\":2557},{\"id\":2558},{\"id\":2559},{\"id\":2560},{\"id\":2561},{\"id\":2562},{\"id\":2563},{\"id\":2564},{\"id\":2565},{\"id\":2566},{\"id\":2567},{\"id\":2568},{\"id\":2569},{\"id\":2570},{\"id\":2571},{\"id\":2572},{\"id\":2573},{\"id\":2574},{\"id\":2575},{\"id\":2576},{\"id\":2577},{\"id\":2578},{\"id\":2579},{\"id\":2580},{\"id\":2581},{\"id\":2582},{\"id\":2583},{\"id\":2584},{\"id\":2585},{\"id\":2586},{\"id\":2587},{\"id\":2588},{\"id\":2589},{\"id\":2590},{\"id\":2591},{\"id\":2592},{\"nodeType\":3,\"id\":2596,\"textContent\":\" // Track clicks on page $(document).ready(function() { $(\\\".control\\\").click(function(e) { e.stopImmediatePropagation(); clicks = clicks + 1; console.log(clicks); }); }); $('.userid').html(sid); // console.log(\\\"start of clicked array: \\\"+clicked); // console.log(\\\"start of hovered string: \\\"+hovered); //set correct answers for each question var triangular_answers = { \\\"acme.starttime.1\\\" : [\\\"F\\\"], \\\"acme.starts.1\\\" : [\\\"K\\\"], \\\"acme.meets.1\\\" : [\\\"F\\\"], \\\"acme.endtime.1\\\" : [\\\"H\\\"], \\\"acme.midpoint.1\\\" : [\\\"O\\\"], \\\"acme.starttime.2\\\" : [\\\"F\\\"], \\\"acme.starts.2\\\" : [\\\"K\\\"], \\\"acme.meets.2\\\" : [\\\"F\\\"], \\\"acme.endtime.2\\\" : [\\\"H\\\"], \\\"acme.midpoint.2\\\" : [\\\"A\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"E\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"E\\\"], \\\"bigset.starttime.1\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.1\\\" : [\\\"G\\\"], \\\"bigset.meets.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.1\\\" : [\\\"X\\\"], \\\"bigset.midpoint.1\\\" : [\\\"K\\\",\\\"X\\\"], \\\"bigset.starttime.2\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.2\\\" : [\\\"G\\\"], \\\"bigset.meets.2\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.2\\\" : [\\\"X\\\"], \\\"bigset.midpoint.2\\\" : [\\\"K\\\",\\\"X\\\"] } var orthogonal_answers = { \\\"acme.starttime.1\\\" : [\\\"A\\\"], \\\"acme.starts.1\\\" : [\\\"E\\\"], \\\"acme.meets.1\\\" : [\\\"Z\\\"], \\\"acme.endtime.1\\\" : [\\\"U\\\"], \\\"acme.midpoint.1\\\" : [\\\"U\\\"], \\\"acme.starttime.2\\\" : [\\\"0\\\"], \\\"acme.starts.2\\\" : [\\\"0\\\"], \\\"acme.meets.2\\\" : [\\\"0\\\"], \\\"acme.endtime.2\\\" : [\\\"0\\\"], \\\"acme.midpoint.2\\\" : [\\\"0\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"X\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"X\\\"], \\\"bigset.starttime.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.1\\\" : [\\\"B\\\"], \\\"bigset.meets.1\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.1\\\" : [\\\"B\\\"], \\\"bigset.midpoint.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.starttime.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.2\\\" : [\\\"B\\\"], \\\"bigset.meets.2\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.2\\\" : [\\\"B\\\"], \\\"bigset.midpoint.2\\\" : [\\\"E\\\",\\\"F\\\"] } //display the question and answer buttons based on input values from jsPsych document.getElementById(scenario+\\\".\\\"+question).style.display = \\\"block\\\"; if (question == \\\"strategy\\\") {document.getElementById(\\\"strategyButton\\\").style.display = \\\"block\\\";} else {document.getElementById(\\\"testingButton\\\").style.display = \\\"block\\\";} //---------SET PROPERTIES OF THE GRAPH -------------// // set the dimensions and margins of the graph var margin = {top: 25, right: 30, bottom: 90, left: 100}, width = 800, height = 800; var intersects = false; //default value for intersects scaffold var xAxisTitle, yAxisTitle; var datafile =\\\"\\\"; // SET AXIS VALUES if (axis == 1){ axis = \\\"Orthogonal-XInside-YFull\\\"; } else if (axis == 2){ axis = \\\"Orthogonal-XInside-YPartial\\\"; } else if (axis ==3){ axis = \\\"Triangular-XInside-YInside\\\"; } else if (axis ==4){ axis = \\\"Orthogonal-XInside-YInside\\\"; } else if (axis ==5){ axis = \\\"Orthogonal-XFull-YFull\\\"; } // SET EXPLICIT SCAFFOLD FEATURES if (explicit ==2 && axis != \\\"diagonal\\\"){ scaffold = 2; intersects = false; } else if (explicit == 2 && axis == \\\"diagonal\\\"){ scaffold = 2; intersects = false; } //TODO: not sure if above two lines are still valid since leaders are now generated on the fly else if (explicit == 3){ $('#hint-interactive').css(\\\"display\\\",\\\"block\\\"); //display textimage scaffold intersects = true; } //SET DATA FILE FOR IMPLICIT SCAFFOLD if (impasse == 1){ datafile = \\\"../views/src/data/acme_nonimpasse.csv\\\"; } else if (impasse == 2){ datafile = \\\"../views/src/data/acme_impasse.csv\\\"; } //OVERRIDE DATA FILE FOR NON-SCAFFOLD QUESTIONS if (q > 5) { //override data file if q# is greater than 5 datafile = \\\"../views/src/data/bigset.csv\\\"; console.log(\\\"override data file\\\"); $('#orthogonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#diagonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#hint-interactive').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold intersects = false; } // //---------CREATE THE SVG ------------------------// var svg = d3.select(\\\".d3container\\\").append(\\\"svg\\\") .attr(\\\"width\\\", width + margin.left + margin.right) .attr(\\\"height\\\", height + margin.top + margin.bottom) .append(\\\"g\\\") .attr(\\\"transform\\\", \\\"translate(\\\" + margin.left + \\\",\\\" + margin.top + \\\")\\\"); //---------DRAW THE GRAPH ------------------------// xAxisTitle = \\\"START & END TIME (time of day)\\\"; yAxisTitle = \\\"DURATION (in hours)\\\"; drawTriangleModel(datafile,intersects,axis,scaffold,q); \"},{\"id\":2593},{\"id\":2594},{\"nodeType\":3,\"id\":2597,\"textContent\":\" //MOUSE LOGGING SCRIPT var mouseLog = [] var xwidth = $(document).width(); var xheight = $(document).width(); mouseLog.push(\\\"{x:\\\"+xwidth+\\\",y:\\\"+xheight+\\\",t:\\\"+\\\"0};\\\") document.onmousemove = function(e){ var pageCoords = \\\"{x:\\\" + e.pageX + \\\",y:\\\"+ e.pageY +\\\",t:\\\"+ Date.now()+ \\\"};\\\" ; mouseLog.push(pageCoords); // console.log(pageCoords); }; \"},{\"id\":2595}],[],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2598,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2599,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2598},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2600,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2599},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2601,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":2600},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2602,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2599}},{\"nodeType\":1,\"id\":2603,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2602},\"parentNode\":{\"id\":2599}},{\"nodeType\":3,\"id\":2604,\"textContent\":\"What is your age?\",\"parentNode\":{\"id\":2602}},{\"nodeType\":1,\"id\":2605,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2600}},{\"nodeType\":1,\"id\":2606,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2605},\"parentNode\":{\"id\":2600}},{\"nodeType\":3,\"id\":2607,\"textContent\":\"In what country were you born?\",\"parentNode\":{\"id\":2605}},{\"nodeType\":3,\"id\":2608,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":2601}}],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2598},{\"id\":2599},{\"id\":2602},{\"id\":2604},{\"id\":2603},{\"id\":2600},{\"id\":2605},{\"id\":2607},{\"id\":2606},{\"id\":2601},{\"id\":2608}],[],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2609,\"tagName\":\"FORM\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-form\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2610,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-preamble\",\"class\":\"jspsych-survey-multi-choice-preamble\"},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2611,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-0\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2610},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2612,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-1\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2611},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2613,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-2\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2612},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2614,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-3\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2613},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2615,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"submit\",\"id\":\"jspsych-survey-multi-choice-next\",\"class\":\"jspsych-survey-multi-choice jspsych-btn\",\"value\":\"Submit Answers\"},\"previousSibling\":{\"id\":2614},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2616,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2617,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2616},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2618,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2617},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2619,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2618},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2620,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2619},\"parentNode\":{\"id\":2611}},{\"nodeType\":3,\"id\":2621,\"textContent\":\"What is your first language?\",\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2622,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2621},\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2623,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2624,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2623}},{\"nodeType\":3,\"id\":2625,\"textContent\":\"English\",\"previousSibling\":{\"id\":2624},\"parentNode\":{\"id\":2623}},{\"nodeType\":1,\"id\":2626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2618}},{\"nodeType\":1,\"id\":2627,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2626}},{\"nodeType\":3,\"id\":2628,\"textContent\":\"Spanish\",\"previousSibling\":{\"id\":2627},\"parentNode\":{\"id\":2626}},{\"nodeType\":1,\"id\":2629,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2619}},{\"nodeType\":1,\"id\":2630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2629}},{\"nodeType\":3,\"id\":2631,\"textContent\":\"Mandarin or Cantonese\",\"previousSibling\":{\"id\":2630},\"parentNode\":{\"id\":2629}},{\"nodeType\":1,\"id\":2632,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2633,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2634,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2633},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2635,\"textContent\":\"*\",\"parentNode\":{\"id\":2622}},{\"nodeType\":1,\"id\":2636,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2637,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2636},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2638,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2637},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2639,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2638},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2640,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2639},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2641,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2640},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2642,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2641},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2643,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2642},\"parentNode\":{\"id\":2612}},{\"nodeType\":3,\"id\":2644,\"textContent\":\"What is your year in school?\",\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2645,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2644},\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2646,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2637}},{\"nodeType\":1,\"id\":2647,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2646}},{\"nodeType\":3,\"id\":2648,\"textContent\":\"First\",\"previousSibling\":{\"id\":2647},\"parentNode\":{\"id\":2646}},{\"nodeType\":1,\"id\":2649,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2638}},{\"nodeType\":1,\"id\":2650,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2649}},{\"nodeType\":3,\"id\":2651,\"textContent\":\"Second\",\"previousSibling\":{\"id\":2650},\"parentNode\":{\"id\":2649}},{\"nodeType\":1,\"id\":2652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2639}},{\"nodeType\":1,\"id\":2653,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2652}},{\"nodeType\":3,\"id\":2654,\"textContent\":\"Third\",\"previousSibling\":{\"id\":2653},\"parentNode\":{\"id\":2652}},{\"nodeType\":1,\"id\":2655,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2640}},{\"nodeType\":1,\"id\":2656,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2655}},{\"nodeType\":3,\"id\":2657,\"textContent\":\"Fourth\",\"previousSibling\":{\"id\":2656},\"parentNode\":{\"id\":2655}},{\"nodeType\":1,\"id\":2658,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2641}},{\"nodeType\":1,\"id\":2659,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2658}},{\"nodeType\":3,\"id\":2660,\"textContent\":\"Fifth\",\"previousSibling\":{\"id\":2659},\"parentNode\":{\"id\":2658}},{\"nodeType\":1,\"id\":2661,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2642}},{\"nodeType\":1,\"id\":2662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2661}},{\"nodeType\":3,\"id\":2663,\"textContent\":\"Graduate\",\"previousSibling\":{\"id\":2662},\"parentNode\":{\"id\":2661}},{\"nodeType\":1,\"id\":2664,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2643}},{\"nodeType\":1,\"id\":2665,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2666,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2665},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2667,\"textContent\":\"*\",\"parentNode\":{\"id\":2645}},{\"nodeType\":1,\"id\":2668,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2669,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2668},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2670,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2669},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2671,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2670},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2672,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2671},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2673,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2672},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2674,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2673},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2675,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2674},\"parentNode\":{\"id\":2613}},{\"nodeType\":3,\"id\":2676,\"textContent\":\"What is your major area of study?\",\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2677,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2676},\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2678,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2669}},{\"nodeType\":1,\"id\":2679,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2678}},{\"nodeType\":3,\"id\":2680,\"textContent\":\"Math or Computer Sciences\",\"previousSibling\":{\"id\":2679},\"parentNode\":{\"id\":2678}},{\"nodeType\":1,\"id\":2681,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2670}},{\"nodeType\":1,\"id\":2682,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2681}},{\"nodeType\":3,\"id\":2683,\"textContent\":\"Social Sciences (incl. CogSci)\",\"previousSibling\":{\"id\":2682},\"parentNode\":{\"id\":2681}},{\"nodeType\":1,\"id\":2684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2671}},{\"nodeType\":1,\"id\":2685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2684}},{\"nodeType\":3,\"id\":2686,\"textContent\":\"Biomedical & Health Sciences\",\"previousSibling\":{\"id\":2685},\"parentNode\":{\"id\":2684}},{\"nodeType\":1,\"id\":2687,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2672}},{\"nodeType\":1,\"id\":2688,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2687}},{\"nodeType\":3,\"id\":2689,\"textContent\":\"Natural Sciences\",\"previousSibling\":{\"id\":2688},\"parentNode\":{\"id\":2687}},{\"nodeType\":1,\"id\":2690,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2673}},{\"nodeType\":1,\"id\":2691,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2690}},{\"nodeType\":3,\"id\":2692,\"textContent\":\"Engineering\",\"previousSibling\":{\"id\":2691},\"parentNode\":{\"id\":2690}},{\"nodeType\":1,\"id\":2693,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2674}},{\"nodeType\":1,\"id\":2694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2693}},{\"nodeType\":3,\"id\":2695,\"textContent\":\"Humanities\",\"previousSibling\":{\"id\":2694},\"parentNode\":{\"id\":2693}},{\"nodeType\":1,\"id\":2696,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2675}},{\"nodeType\":1,\"id\":2697,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2698,\"textContent\":\"Fine Arts\",\"previousSibling\":{\"id\":2697},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2699,\"textContent\":\"*\",\"parentNode\":{\"id\":2677}},{\"nodeType\":1,\"id\":2700,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2701,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2700},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2702,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2701},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2703,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2702},\"parentNode\":{\"id\":2614}},{\"nodeType\":3,\"id\":2704,\"textContent\":\"What is your gender?\",\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2705,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2704},\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2706,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2701}},{\"nodeType\":1,\"id\":2707,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2706}},{\"nodeType\":3,\"id\":2708,\"textContent\":\"Male\",\"previousSibling\":{\"id\":2707},\"parentNode\":{\"id\":2706}},{\"nodeType\":1,\"id\":2709,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2702}},{\"nodeType\":1,\"id\":2710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2709}},{\"nodeType\":3,\"id\":2711,\"textContent\":\"Female\",\"previousSibling\":{\"id\":2710},\"parentNode\":{\"id\":2709}},{\"nodeType\":1,\"id\":2712,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2703}},{\"nodeType\":1,\"id\":2713,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2714,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2713},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2715,\"textContent\":\"*\",\"parentNode\":{\"id\":2705}}],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2609},{\"id\":2610},{\"id\":2611},{\"id\":2616},{\"id\":2621},{\"id\":2622},{\"id\":2635},{\"id\":2617},{\"id\":2623},{\"id\":2624},{\"id\":2625},{\"id\":2618},{\"id\":2626},{\"id\":2627},{\"id\":2628},{\"id\":2619},{\"id\":2629},{\"id\":2630},{\"id\":2631},{\"id\":2620},{\"id\":2632},{\"id\":2633},{\"id\":2634},{\"id\":2612},{\"id\":2636},{\"id\":2644},{\"id\":2645},{\"id\":2667},{\"id\":2637},{\"id\":2646},{\"id\":2647},{\"id\":2648},{\"id\":2638},{\"id\":2649},{\"id\":2650},{\"id\":2651},{\"id\":2639},{\"id\":2652},{\"id\":2653},{\"id\":2654},{\"id\":2640},{\"id\":2655},{\"id\":2656},{\"id\":2657},{\"id\":2641},{\"id\":2658},{\"id\":2659},{\"id\":2660},{\"id\":2642},{\"id\":2661},{\"id\":2662},{\"id\":2663},{\"id\":2643},{\"id\":2664},{\"id\":2665},{\"id\":2666},{\"id\":2613},{\"id\":2668},{\"id\":2676},{\"id\":2677},{\"id\":2699},{\"id\":2669},{\"id\":2678},{\"id\":2679},{\"id\":2680},{\"id\":2670},{\"id\":2681},{\"id\":2682},{\"id\":2683},{\"id\":2671},{\"id\":2684},{\"id\":2685},{\"id\":2686},{\"id\":2672},{\"id\":2687},{\"id\":2688},{\"id\":2689},{\"id\":2673},{\"id\":2690},{\"id\":2691},{\"id\":2692},{\"id\":2674},{\"id\":2693},{\"id\":2694},{\"id\":2695},{\"id\":2675},{\"id\":2696},{\"id\":2697},{\"id\":2698},{\"id\":2614},{\"id\":2700},{\"id\":2704},{\"id\":2705},{\"id\":2715},{\"id\":2701},{\"id\":2706},{\"id\":2707},{\"id\":2708},{\"id\":2702},{\"id\":2709},{\"id\":2710},{\"id\":2711},{\"id\":2703},{\"id\":2712},{\"id\":2713},{\"id\":2714},{\"id\":2615}],[],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2716,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2717,\"textContent\":\" \",\"previousSibling\":{\"id\":2716},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2718,\"textContent\":\" \",\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":2718},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2720,\"textContent\":\" \",\"previousSibling\":{\"id\":2719},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2721,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":2720},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2722,\"textContent\":\" \",\"previousSibling\":{\"id\":2721},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2723,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":2722},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2724,\"textContent\":\" \",\"previousSibling\":{\"id\":2723},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2725,\"textContent\":\" \",\"parentNode\":{\"id\":2719}},{\"nodeType\":1,\"id\":2726,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":2725},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2727,\"textContent\":\" \",\"previousSibling\":{\"id\":2726},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2728,\"textContent\":\" \",\"parentNode\":{\"id\":2726}},{\"nodeType\":1,\"id\":2729,\"tagName\":\"H3\",\"attributes\":{},\"previousSibling\":{\"id\":2728},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2730,\"textContent\":\" \",\"previousSibling\":{\"id\":2729},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2731,\"textContent\":\"DEBRIEFING\",\"parentNode\":{\"id\":2729}},{\"nodeType\":3,\"id\":2732,\"textContent\":\" \",\"parentNode\":{\"id\":2721}},{\"nodeType\":1,\"id\":2733,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":2732},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2734,\"textContent\":\" \",\"previousSibling\":{\"id\":2733},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2735,\"textContent\":\" \",\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2736,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic\"},\"previousSibling\":{\"id\":2735},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2737,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2736},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2738,\"textContent\":\" \",\"previousSibling\":{\"id\":2737},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2739,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2738},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2740,\"textContent\":\" \",\"previousSibling\":{\"id\":2739},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2741,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2740},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2742,\"textContent\":\" \",\"previousSibling\":{\"id\":2741},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2743,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:bold;\"},\"previousSibling\":{\"id\":2742},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2744,\"textContent\":\" \",\"previousSibling\":{\"id\":2743},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2745,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":2744},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2746,\"textContent\":\" \",\"previousSibling\":{\"id\":2745},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2747,\"textContent\":\"Thank you very much for your participation! This debriefing will tell you more about the study, what you did, and why. \",\"parentNode\":{\"id\":2736}},{\"nodeType\":3,\"id\":2748,\"textContent\":\" \",\"parentNode\":{\"id\":2737}},{\"nodeType\":1,\"id\":2749,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2748},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2750,\"textContent\":\" You have just used a series of pictures (charts, graphs and diagrams) accompanied by different types of instructions to answer a series of problem solving questions. While you were using the pictures, we measured where you clicked, scrolled and pointed with the computer mouse. We also measured the accuracy of your responses and the time it took to complete each question.\",\"previousSibling\":{\"id\":2749},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2751,\"textContent\":\"What did you just do?\",\"parentNode\":{\"id\":2749}},{\"nodeType\":3,\"id\":2752,\"textContent\":\" \",\"parentNode\":{\"id\":2739}},{\"nodeType\":1,\"id\":2753,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2752},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2754,\"textContent\":\" Researchers of learning and cognition have long been interested in how graphic displays of information can be used to communicate, solve problems, and generate insights. As powerful as graphics may be in their communicative efficiency, they're not always immediately intuitive to understand. In short, we know a great deal more about learning with representations than we do about the learning of representations. In this project we are building upon previous research on reading and graph comprehension to explore how readers make sense of unfamiliar representations. The instructions you saw for each type of graph are known as “scaffolding techniques”, and we will compare your performance with the scaffolding techniques you saw with the performance of other participants to determine which types of instructions are most effective in helping humans to make sense of unfamiliar graphs. \",\"previousSibling\":{\"id\":2753},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2755,\"textContent\":\"Why did we have you do it?\",\"parentNode\":{\"id\":2753}},{\"nodeType\":1,\"id\":2756,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2757,\"textContent\":\" We expect that you will have found some of the graphics more difficult to use than others. We also expect that with the assistance of the instructions, after solving several problems you will learn to use the difficult graphics so that you can answer the questions even more quickly than without. If you would like to receive a copy of the results of the study, or have any further questions, please contact the researchers Primary Researcher: Amy Fox : a2fox@ucsd.edu Faculty Advisor : Dr. Jim Hollan : hollan@ucsd.edu \",\"previousSibling\":{\"id\":2756},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2758,\"textContent\":\"What do we expect to find?\",\"parentNode\":{\"id\":2756}},{\"nodeType\":3,\"id\":2759,\"textContent\":\"It is important that you do not discuss this experiment with other students who might participate after you. They must participate in the same way as you did, without any knowledge of what the experiment entails, or the reasoning behind it.\",\"parentNode\":{\"id\":2743}},{\"nodeType\":3,\"id\":2760,\"textContent\":\"Thank you for your time! We hope you enjoyed participating in this study as much as we enjoyed designing it.\",\"parentNode\":{\"id\":2745}},{\"nodeType\":3,\"id\":2761,\"textContent\":\" \",\"parentNode\":{\"id\":2723}},{\"nodeType\":1,\"id\":2762,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":2761},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2763,\"textContent\":\" \",\"previousSibling\":{\"id\":2762},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2764,\"textContent\":\"FINISH\",\"parentNode\":{\"id\":2762}}],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2716},{\"id\":2718},{\"id\":2719},{\"id\":2725},{\"id\":2726},{\"id\":2728},{\"id\":2729},{\"id\":2731},{\"id\":2730},{\"id\":2727},{\"id\":2720},{\"id\":2721},{\"id\":2732},{\"id\":2733},{\"id\":2735},{\"id\":2736},{\"id\":2747},{\"id\":2737},{\"id\":2748},{\"id\":2749},{\"id\":2751},{\"id\":2750},{\"id\":2738},{\"id\":2739},{\"id\":2752},{\"id\":2753},{\"id\":2755},{\"id\":2754},{\"id\":2740},{\"id\":2741},{\"id\":2756},{\"id\":2758},{\"id\":2757},{\"id\":2742},{\"id\":2743},{\"id\":2759},{\"id\":2744},{\"id\":2745},{\"id\":2760},{\"id\":2746},{\"id\":2734},{\"id\":2722},{\"id\":2723},{\"id\":2761},{\"id\":2762},{\"id\":2764},{\"id\":2763},{\"id\":2724},{\"id\":2717}],[],[],[]]}"
    },
    {
      "sequence": 8,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2765,\"tagName\":\"PRE\",\"attributes\":{\"id\":\"jspsych-data-display\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2766,\"textContent\":\"[ { \\\"rt\\\": 209913, \\\"stimulus\\\": \\\"img/phone.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"phone\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 0, \\\"time_elapsed\\\": 209917, \\\"internal_node_id\\\": \\\"0.0-0.0\\\", \\\"subject\\\": \\\"8LK9M\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"hotel\\\", \\\"condition\\\": \\\"121\\\" }, { \\\"rt\\\": 4418, \\\"url\\\": \\\"../views/src/external/consent.html\\\", \\\"block\\\": \\\"consent\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 1, \\\"time_elapsed\\\": 215694, \\\"internal_node_id\\\": \\\"0.0-1.0\\\", \\\"subject\\\": \\\"8LK9M\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"hotel\\\", \\\"condition\\\": \\\"121\\\" }, { \\\"rt\\\": 6770, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"hotel\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"121\\\\\\\"}\\\", \\\"block\\\": \\\"codes\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 2, \\\"time_elapsed\\\": 223473, \\\"internal_node_id\\\": \\\"0.0-2.0\\\", \\\"subject\\\": \\\"8LK9M\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"hotel\\\", \\\"condition\\\": \\\"121\\\" }, { \\\"rt\\\": 25388, \\\"url\\\": \\\"../views/src/external/instructions_lab.html\\\", \\\"block\\\": \\\"instructions_lab\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 3, \\\"time_elapsed\\\": 249947, \\\"internal_node_id\\\": \\\"0.0-3.0\\\", \\\"subject\\\": \\\"8LK9M\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"hotel\\\", \\\"condition\\\": \\\"121\\\" }, { \\\"rt\\\": 21830, \\\"stimulus\\\": \\\"img/acme.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"scenario\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 4, \\\"time_elapsed\\\": 272781, \\\"internal_node_id\\\": \\\"0.0-4.0\\\", \\\"subject\\\": \\\"8LK9M\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"hotel\\\", \\\"condition\\\": \\\"121\\\" }, { \\\"rt\\\": 44790, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 5, \\\"time_elapsed\\\": 318958, \\\"internal_node_id\\\": \\\"0.0-5.0-0.0\\\", \\\"subject\\\": \\\"8LK9M\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"hotel\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 1, \\\"clicks\\\": 1.5, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-12 PM-01 PM-09 AM-10 AM-11 AM-F -F -F -11 AM-11 AM-11 AM-F \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:1110,y:876,t:1527023262215};\\\", \\\"{x:1114,y:878,t:1527023262230};\\\", \\\"{x:1118,y:880,t:1527023262247};\\\", \\\"{x:1124,y:882,t:1527023262263};\\\", \\\"{x:1129,y:884,t:1527023262281};\\\", \\\"{x:1132,y:885,t:1527023262296};\\\", \\\"{x:1135,y:886,t:1527023262313};\\\", \\\"{x:1137,y:888,t:1527023262330};\\\", \\\"{x:1140,y:889,t:1527023262347};\\\", \\\"{x:1142,y:889,t:1527023262364};\\\", \\\"{x:1145,y:890,t:1527023262380};\\\", \\\"{x:1148,y:892,t:1527023262398};\\\", \\\"{x:1151,y:894,t:1527023262414};\\\", \\\"{x:1155,y:897,t:1527023262430};\\\", \\\"{x:1161,y:901,t:1527023262448};\\\", \\\"{x:1174,y:909,t:1527023262464};\\\", \\\"{x:1186,y:914,t:1527023262481};\\\", \\\"{x:1194,y:919,t:1527023262497};\\\", \\\"{x:1203,y:924,t:1527023262514};\\\", \\\"{x:1206,y:928,t:1527023262531};\\\", \\\"{x:1211,y:933,t:1527023262547};\\\", \\\"{x:1214,y:937,t:1527023262563};\\\", \\\"{x:1221,y:941,t:1527023262580};\\\", \\\"{x:1226,y:945,t:1527023262597};\\\", \\\"{x:1228,y:947,t:1527023262613};\\\", \\\"{x:1232,y:950,t:1527023262630};\\\", \\\"{x:1234,y:951,t:1527023262662};\\\", \\\"{x:1234,y:953,t:1527023262670};\\\", \\\"{x:1234,y:954,t:1527023262686};\\\", \\\"{x:1233,y:955,t:1527023262783};\\\", \\\"{x:1233,y:957,t:1527023262853};\\\", \\\"{x:1233,y:956,t:1527023263503};\\\", \\\"{x:1234,y:956,t:1527023263543};\\\", \\\"{x:1237,y:956,t:1527023263566};\\\", \\\"{x:1242,y:956,t:1527023263582};\\\", \\\"{x:1248,y:956,t:1527023263598};\\\", \\\"{x:1256,y:957,t:1527023263615};\\\", \\\"{x:1262,y:959,t:1527023263631};\\\", \\\"{x:1269,y:959,t:1527023263647};\\\", \\\"{x:1272,y:961,t:1527023263664};\\\", \\\"{x:1275,y:962,t:1527023263681};\\\", \\\"{x:1276,y:962,t:1527023263697};\\\", \\\"{x:1277,y:962,t:1527023263714};\\\", \\\"{x:1278,y:962,t:1527023263731};\\\", \\\"{x:1279,y:962,t:1527023263747};\\\", \\\"{x:1280,y:963,t:1527023263765};\\\", \\\"{x:1281,y:963,t:1527023263781};\\\", \\\"{x:1283,y:963,t:1527023263798};\\\", \\\"{x:1285,y:963,t:1527023263814};\\\", \\\"{x:1288,y:963,t:1527023263831};\\\", \\\"{x:1289,y:963,t:1527023263847};\\\", \\\"{x:1290,y:963,t:1527023263864};\\\", \\\"{x:1291,y:963,t:1527023263881};\\\", \\\"{x:1292,y:963,t:1527023263949};\\\", \\\"{x:1293,y:963,t:1527023263973};\\\", \\\"{x:1294,y:963,t:1527023263981};\\\", \\\"{x:1295,y:963,t:1527023263998};\\\", \\\"{x:1298,y:963,t:1527023264014};\\\", \\\"{x:1301,y:963,t:1527023264031};\\\", \\\"{x:1307,y:963,t:1527023264048};\\\", \\\"{x:1317,y:965,t:1527023264064};\\\", \\\"{x:1326,y:966,t:1527023264081};\\\", \\\"{x:1336,y:967,t:1527023264098};\\\", \\\"{x:1348,y:970,t:1527023264114};\\\", \\\"{x:1357,y:971,t:1527023264131};\\\", \\\"{x:1369,y:972,t:1527023264149};\\\", \\\"{x:1376,y:974,t:1527023264164};\\\", \\\"{x:1381,y:976,t:1527023264182};\\\", \\\"{x:1383,y:976,t:1527023264198};\\\", \\\"{x:1386,y:978,t:1527023264215};\\\", \\\"{x:1390,y:979,t:1527023264231};\\\", \\\"{x:1396,y:979,t:1527023264248};\\\", \\\"{x:1403,y:982,t:1527023264265};\\\", \\\"{x:1411,y:984,t:1527023264282};\\\", \\\"{x:1417,y:986,t:1527023264299};\\\", \\\"{x:1425,y:989,t:1527023264315};\\\", \\\"{x:1435,y:993,t:1527023264332};\\\", \\\"{x:1445,y:998,t:1527023264348};\\\", \\\"{x:1462,y:1006,t:1527023264366};\\\", \\\"{x:1468,y:1011,t:1527023264382};\\\", \\\"{x:1473,y:1016,t:1527023264398};\\\", \\\"{x:1475,y:1019,t:1527023264415};\\\", \\\"{x:1476,y:1023,t:1527023264431};\\\", \\\"{x:1478,y:1027,t:1527023264449};\\\", \\\"{x:1480,y:1029,t:1527023264466};\\\", \\\"{x:1481,y:1031,t:1527023264481};\\\", \\\"{x:1481,y:1032,t:1527023264499};\\\", \\\"{x:1481,y:1033,t:1527023264516};\\\", \\\"{x:1482,y:1034,t:1527023264542};\\\", \\\"{x:1482,y:1035,t:1527023264574};\\\", \\\"{x:1482,y:1036,t:1527023264590};\\\", \\\"{x:1482,y:1037,t:1527023264599};\\\", \\\"{x:1482,y:1039,t:1527023264615};\\\", \\\"{x:1482,y:1040,t:1527023264638};\\\", \\\"{x:1481,y:1041,t:1527023264654};\\\", \\\"{x:1480,y:1042,t:1527023264670};\\\", \\\"{x:1480,y:1043,t:1527023264682};\\\", \\\"{x:1478,y:1045,t:1527023264699};\\\", \\\"{x:1477,y:1045,t:1527023264716};\\\", \\\"{x:1476,y:1047,t:1527023264732};\\\", \\\"{x:1473,y:1049,t:1527023264748};\\\", \\\"{x:1470,y:1049,t:1527023264765};\\\", \\\"{x:1469,y:1049,t:1527023264782};\\\", \\\"{x:1467,y:1049,t:1527023264798};\\\", \\\"{x:1464,y:1049,t:1527023264816};\\\", \\\"{x:1460,y:1049,t:1527023264833};\\\", \\\"{x:1455,y:1049,t:1527023264849};\\\", \\\"{x:1447,y:1047,t:1527023264866};\\\", \\\"{x:1432,y:1044,t:1527023264883};\\\", \\\"{x:1415,y:1039,t:1527023264899};\\\", \\\"{x:1399,y:1034,t:1527023264916};\\\", \\\"{x:1385,y:1030,t:1527023264932};\\\", \\\"{x:1375,y:1027,t:1527023264948};\\\", \\\"{x:1355,y:1024,t:1527023264966};\\\", \\\"{x:1342,y:1021,t:1527023264982};\\\", \\\"{x:1325,y:1020,t:1527023264999};\\\", \\\"{x:1308,y:1017,t:1527023265015};\\\", \\\"{x:1294,y:1014,t:1527023265032};\\\", \\\"{x:1284,y:1011,t:1527023265048};\\\", \\\"{x:1275,y:1009,t:1527023265066};\\\", \\\"{x:1265,y:1007,t:1527023265083};\\\", \\\"{x:1255,y:1005,t:1527023265099};\\\", \\\"{x:1248,y:1005,t:1527023265116};\\\", \\\"{x:1245,y:1004,t:1527023265133};\\\", \\\"{x:1241,y:1003,t:1527023265149};\\\", \\\"{x:1235,y:1002,t:1527023265166};\\\", \\\"{x:1229,y:1002,t:1527023265182};\\\", \\\"{x:1224,y:1001,t:1527023265199};\\\", \\\"{x:1221,y:999,t:1527023265216};\\\", \\\"{x:1217,y:999,t:1527023265233};\\\", \\\"{x:1211,y:995,t:1527023265249};\\\", \\\"{x:1204,y:994,t:1527023265265};\\\", \\\"{x:1194,y:992,t:1527023265282};\\\", \\\"{x:1190,y:990,t:1527023265300};\\\", \\\"{x:1184,y:989,t:1527023265316};\\\", \\\"{x:1180,y:987,t:1527023265332};\\\", \\\"{x:1172,y:986,t:1527023265351};\\\", \\\"{x:1169,y:985,t:1527023265366};\\\", \\\"{x:1167,y:984,t:1527023265383};\\\", \\\"{x:1166,y:983,t:1527023265400};\\\", \\\"{x:1166,y:982,t:1527023265430};\\\", \\\"{x:1166,y:981,t:1527023265454};\\\", \\\"{x:1167,y:979,t:1527023265486};\\\", \\\"{x:1168,y:979,t:1527023265500};\\\", \\\"{x:1171,y:979,t:1527023265516};\\\", \\\"{x:1178,y:976,t:1527023265533};\\\", \\\"{x:1182,y:975,t:1527023265549};\\\", \\\"{x:1183,y:975,t:1527023265565};\\\", \\\"{x:1185,y:973,t:1527023265583};\\\", \\\"{x:1188,y:973,t:1527023265600};\\\", \\\"{x:1192,y:972,t:1527023265616};\\\", \\\"{x:1199,y:972,t:1527023265633};\\\", \\\"{x:1205,y:972,t:1527023265649};\\\", \\\"{x:1212,y:972,t:1527023265665};\\\", \\\"{x:1217,y:972,t:1527023265683};\\\", \\\"{x:1220,y:972,t:1527023265700};\\\", \\\"{x:1223,y:972,t:1527023265717};\\\", \\\"{x:1228,y:971,t:1527023265733};\\\", \\\"{x:1233,y:971,t:1527023265751};\\\", \\\"{x:1236,y:971,t:1527023265767};\\\", \\\"{x:1239,y:971,t:1527023265782};\\\", \\\"{x:1243,y:971,t:1527023265800};\\\", \\\"{x:1245,y:971,t:1527023265817};\\\", \\\"{x:1247,y:971,t:1527023265833};\\\", \\\"{x:1248,y:971,t:1527023265862};\\\", \\\"{x:1249,y:971,t:1527023265870};\\\", \\\"{x:1250,y:971,t:1527023265883};\\\", \\\"{x:1251,y:971,t:1527023265900};\\\", \\\"{x:1252,y:971,t:1527023265917};\\\", \\\"{x:1256,y:971,t:1527023265933};\\\", \\\"{x:1259,y:971,t:1527023265950};\\\", \\\"{x:1260,y:971,t:1527023265974};\\\", \\\"{x:1262,y:970,t:1527023265983};\\\", \\\"{x:1264,y:970,t:1527023266006};\\\", \\\"{x:1265,y:970,t:1527023266017};\\\", \\\"{x:1266,y:970,t:1527023266033};\\\", \\\"{x:1266,y:969,t:1527023266050};\\\", \\\"{x:1268,y:969,t:1527023266135};\\\", \\\"{x:1270,y:969,t:1527023266150};\\\", \\\"{x:1271,y:969,t:1527023266166};\\\", \\\"{x:1272,y:969,t:1527023266255};\\\", \\\"{x:1273,y:969,t:1527023266303};\\\", \\\"{x:1274,y:969,t:1527023266326};\\\", \\\"{x:1275,y:969,t:1527023266342};\\\", \\\"{x:1276,y:968,t:1527023266358};\\\", \\\"{x:1277,y:968,t:1527023266383};\\\", \\\"{x:1278,y:967,t:1527023266390};\\\", \\\"{x:1279,y:966,t:1527023266414};\\\", \\\"{x:1280,y:966,t:1527023266462};\\\", \\\"{x:1281,y:966,t:1527023266511};\\\", \\\"{x:1281,y:965,t:1527023266533};\\\", \\\"{x:1283,y:965,t:1527023266550};\\\", \\\"{x:1283,y:964,t:1527023266613};\\\", \\\"{x:1285,y:961,t:1527023267821};\\\", \\\"{x:1287,y:956,t:1527023267834};\\\", \\\"{x:1289,y:953,t:1527023267850};\\\", \\\"{x:1289,y:951,t:1527023267867};\\\", \\\"{x:1290,y:947,t:1527023267884};\\\", \\\"{x:1291,y:947,t:1527023267900};\\\", \\\"{x:1292,y:945,t:1527023267917};\\\", \\\"{x:1292,y:944,t:1527023268005};\\\", \\\"{x:1293,y:942,t:1527023268017};\\\", \\\"{x:1293,y:941,t:1527023268054};\\\", \\\"{x:1295,y:940,t:1527023268070};\\\", \\\"{x:1295,y:939,t:1527023268085};\\\", \\\"{x:1295,y:938,t:1527023268101};\\\", \\\"{x:1296,y:937,t:1527023268118};\\\", \\\"{x:1296,y:936,t:1527023268143};\\\", \\\"{x:1297,y:935,t:1527023268174};\\\", \\\"{x:1297,y:934,t:1527023268189};\\\", \\\"{x:1298,y:934,t:1527023268202};\\\", \\\"{x:1298,y:933,t:1527023268217};\\\", \\\"{x:1299,y:932,t:1527023268238};\\\", \\\"{x:1299,y:931,t:1527023268270};\\\", \\\"{x:1299,y:930,t:1527023268285};\\\", \\\"{x:1301,y:929,t:1527023268302};\\\", \\\"{x:1302,y:927,t:1527023268318};\\\", \\\"{x:1302,y:926,t:1527023268342};\\\", \\\"{x:1304,y:925,t:1527023268352};\\\", \\\"{x:1304,y:923,t:1527023268368};\\\", \\\"{x:1306,y:920,t:1527023268385};\\\", \\\"{x:1306,y:919,t:1527023268402};\\\", \\\"{x:1308,y:918,t:1527023268418};\\\", \\\"{x:1308,y:916,t:1527023268435};\\\", \\\"{x:1309,y:914,t:1527023268452};\\\", \\\"{x:1310,y:913,t:1527023268468};\\\", \\\"{x:1311,y:912,t:1527023268485};\\\", \\\"{x:1312,y:909,t:1527023268502};\\\", \\\"{x:1314,y:907,t:1527023268518};\\\", \\\"{x:1314,y:906,t:1527023268535};\\\", \\\"{x:1314,y:905,t:1527023268552};\\\", \\\"{x:1315,y:904,t:1527023268568};\\\", \\\"{x:1315,y:902,t:1527023268585};\\\", \\\"{x:1317,y:900,t:1527023268602};\\\", \\\"{x:1317,y:899,t:1527023268619};\\\", \\\"{x:1317,y:898,t:1527023268635};\\\", \\\"{x:1317,y:895,t:1527023268652};\\\", \\\"{x:1317,y:894,t:1527023268668};\\\", \\\"{x:1317,y:893,t:1527023268684};\\\", \\\"{x:1318,y:890,t:1527023268701};\\\", \\\"{x:1318,y:889,t:1527023268718};\\\", \\\"{x:1318,y:888,t:1527023268735};\\\", \\\"{x:1320,y:886,t:1527023268751};\\\", \\\"{x:1320,y:885,t:1527023268768};\\\", \\\"{x:1321,y:882,t:1527023268784};\\\", \\\"{x:1321,y:881,t:1527023268802};\\\", \\\"{x:1322,y:879,t:1527023268818};\\\", \\\"{x:1322,y:877,t:1527023268835};\\\", \\\"{x:1323,y:876,t:1527023268852};\\\", \\\"{x:1324,y:874,t:1527023268868};\\\", \\\"{x:1325,y:873,t:1527023268885};\\\", \\\"{x:1327,y:868,t:1527023268902};\\\", \\\"{x:1328,y:866,t:1527023268918};\\\", \\\"{x:1330,y:863,t:1527023268935};\\\", \\\"{x:1330,y:861,t:1527023268952};\\\", \\\"{x:1331,y:860,t:1527023268969};\\\", \\\"{x:1333,y:857,t:1527023268984};\\\", \\\"{x:1334,y:855,t:1527023269001};\\\", \\\"{x:1335,y:853,t:1527023269019};\\\", \\\"{x:1337,y:850,t:1527023269035};\\\", \\\"{x:1338,y:848,t:1527023269051};\\\", \\\"{x:1338,y:847,t:1527023269069};\\\", \\\"{x:1341,y:843,t:1527023269087};\\\", \\\"{x:1342,y:841,t:1527023269102};\\\", \\\"{x:1343,y:840,t:1527023269119};\\\", \\\"{x:1344,y:839,t:1527023269136};\\\", \\\"{x:1345,y:837,t:1527023269152};\\\", \\\"{x:1346,y:834,t:1527023269169};\\\", \\\"{x:1347,y:831,t:1527023269186};\\\", \\\"{x:1349,y:827,t:1527023269202};\\\", \\\"{x:1350,y:825,t:1527023269219};\\\", \\\"{x:1351,y:823,t:1527023269236};\\\", \\\"{x:1351,y:821,t:1527023269252};\\\", \\\"{x:1353,y:819,t:1527023269269};\\\", \\\"{x:1353,y:816,t:1527023269286};\\\", \\\"{x:1354,y:814,t:1527023269301};\\\", \\\"{x:1356,y:811,t:1527023269319};\\\", \\\"{x:1357,y:810,t:1527023269336};\\\", \\\"{x:1358,y:808,t:1527023269352};\\\", \\\"{x:1358,y:807,t:1527023269369};\\\", \\\"{x:1359,y:806,t:1527023269386};\\\", \\\"{x:1359,y:805,t:1527023269407};\\\", \\\"{x:1360,y:804,t:1527023269420};\\\", \\\"{x:1360,y:803,t:1527023269436};\\\", \\\"{x:1360,y:799,t:1527023269452};\\\", \\\"{x:1361,y:798,t:1527023269469};\\\", \\\"{x:1361,y:795,t:1527023269486};\\\", \\\"{x:1362,y:794,t:1527023269502};\\\", \\\"{x:1362,y:793,t:1527023269519};\\\", \\\"{x:1363,y:791,t:1527023269536};\\\", \\\"{x:1363,y:790,t:1527023269553};\\\", \\\"{x:1363,y:788,t:1527023269569};\\\", \\\"{x:1363,y:786,t:1527023269586};\\\", \\\"{x:1363,y:785,t:1527023269603};\\\", \\\"{x:1364,y:782,t:1527023269622};\\\", \\\"{x:1364,y:781,t:1527023269646};\\\", \\\"{x:1365,y:780,t:1527023269654};\\\", \\\"{x:1365,y:779,t:1527023269669};\\\", \\\"{x:1366,y:778,t:1527023269686};\\\", \\\"{x:1367,y:776,t:1527023269703};\\\", \\\"{x:1367,y:775,t:1527023269719};\\\", \\\"{x:1368,y:773,t:1527023269736};\\\", \\\"{x:1368,y:772,t:1527023269753};\\\", \\\"{x:1369,y:771,t:1527023269769};\\\", \\\"{x:1370,y:770,t:1527023269786};\\\", \\\"{x:1370,y:769,t:1527023269803};\\\", \\\"{x:1371,y:768,t:1527023269818};\\\", \\\"{x:1372,y:767,t:1527023269869};\\\", \\\"{x:1373,y:766,t:1527023269941};\\\", \\\"{x:1373,y:765,t:1527023269957};\\\", \\\"{x:1374,y:764,t:1527023269998};\\\", \\\"{x:1375,y:763,t:1527023270016};\\\", \\\"{x:1376,y:762,t:1527023270035};\\\", \\\"{x:1377,y:761,t:1527023270053};\\\", \\\"{x:1378,y:760,t:1527023270093};\\\", \\\"{x:1379,y:760,t:1527023270125};\\\", \\\"{x:1379,y:759,t:1527023270135};\\\", \\\"{x:1380,y:758,t:1527023270153};\\\", \\\"{x:1381,y:757,t:1527023270170};\\\", \\\"{x:1382,y:757,t:1527023270263};\\\", \\\"{x:1382,y:758,t:1527023271767};\\\", \\\"{x:1382,y:759,t:1527023271787};\\\", \\\"{x:1382,y:761,t:1527023271804};\\\", \\\"{x:1381,y:761,t:1527023271821};\\\", \\\"{x:1377,y:768,t:1527023278335};\\\", \\\"{x:1367,y:783,t:1527023278341};\\\", \\\"{x:1350,y:807,t:1527023278359};\\\", \\\"{x:1339,y:818,t:1527023278375};\\\", \\\"{x:1334,y:824,t:1527023278392};\\\", \\\"{x:1330,y:827,t:1527023278409};\\\", \\\"{x:1328,y:829,t:1527023278425};\\\", \\\"{x:1328,y:830,t:1527023278442};\\\", \\\"{x:1328,y:832,t:1527023278460};\\\", \\\"{x:1325,y:836,t:1527023278475};\\\", \\\"{x:1321,y:842,t:1527023278493};\\\", \\\"{x:1318,y:847,t:1527023278509};\\\", \\\"{x:1313,y:854,t:1527023278526};\\\", \\\"{x:1306,y:869,t:1527023278543};\\\", \\\"{x:1301,y:885,t:1527023278560};\\\", \\\"{x:1296,y:901,t:1527023278575};\\\", \\\"{x:1293,y:910,t:1527023278592};\\\", \\\"{x:1290,y:920,t:1527023278609};\\\", \\\"{x:1288,y:934,t:1527023278625};\\\", \\\"{x:1286,y:947,t:1527023278642};\\\", \\\"{x:1285,y:954,t:1527023278660};\\\", \\\"{x:1284,y:960,t:1527023278676};\\\", \\\"{x:1282,y:964,t:1527023278693};\\\", \\\"{x:1282,y:967,t:1527023278709};\\\", \\\"{x:1280,y:974,t:1527023278726};\\\", \\\"{x:1280,y:978,t:1527023278742};\\\", \\\"{x:1279,y:981,t:1527023278759};\\\", \\\"{x:1279,y:982,t:1527023278776};\\\", \\\"{x:1279,y:985,t:1527023278793};\\\", \\\"{x:1279,y:986,t:1527023278810};\\\", \\\"{x:1278,y:988,t:1527023278825};\\\", \\\"{x:1278,y:987,t:1527023279070};\\\", \\\"{x:1278,y:984,t:1527023279078};\\\", \\\"{x:1278,y:982,t:1527023279093};\\\", \\\"{x:1280,y:976,t:1527023279110};\\\", \\\"{x:1282,y:971,t:1527023279126};\\\", \\\"{x:1283,y:967,t:1527023279144};\\\", \\\"{x:1284,y:961,t:1527023279159};\\\", \\\"{x:1285,y:945,t:1527023279176};\\\", \\\"{x:1286,y:923,t:1527023279194};\\\", \\\"{x:1290,y:909,t:1527023279209};\\\", \\\"{x:1294,y:900,t:1527023279227};\\\", \\\"{x:1298,y:890,t:1527023279244};\\\", \\\"{x:1298,y:885,t:1527023279258};\\\", \\\"{x:1299,y:874,t:1527023279276};\\\", \\\"{x:1299,y:864,t:1527023279293};\\\", \\\"{x:1299,y:856,t:1527023279308};\\\", \\\"{x:1299,y:853,t:1527023279326};\\\", \\\"{x:1299,y:851,t:1527023279342};\\\", \\\"{x:1299,y:850,t:1527023279359};\\\", \\\"{x:1299,y:847,t:1527023279375};\\\", \\\"{x:1299,y:846,t:1527023279393};\\\", \\\"{x:1299,y:843,t:1527023279409};\\\", \\\"{x:1299,y:841,t:1527023279426};\\\", \\\"{x:1299,y:840,t:1527023279443};\\\", \\\"{x:1299,y:836,t:1527023279459};\\\", \\\"{x:1299,y:834,t:1527023279477};\\\", \\\"{x:1299,y:831,t:1527023279493};\\\", \\\"{x:1299,y:828,t:1527023279510};\\\", \\\"{x:1299,y:827,t:1527023279527};\\\", \\\"{x:1299,y:826,t:1527023279543};\\\", \\\"{x:1298,y:826,t:1527023279614};\\\", \\\"{x:1295,y:829,t:1527023279626};\\\", \\\"{x:1286,y:849,t:1527023279644};\\\", \\\"{x:1278,y:865,t:1527023279659};\\\", \\\"{x:1272,y:876,t:1527023279676};\\\", \\\"{x:1267,y:884,t:1527023279694};\\\", \\\"{x:1264,y:893,t:1527023279710};\\\", \\\"{x:1264,y:896,t:1527023279727};\\\", \\\"{x:1264,y:899,t:1527023279744};\\\", \\\"{x:1264,y:900,t:1527023279760};\\\", \\\"{x:1263,y:902,t:1527023279776};\\\", \\\"{x:1263,y:903,t:1527023279794};\\\", \\\"{x:1263,y:905,t:1527023279813};\\\", \\\"{x:1263,y:907,t:1527023279826};\\\", \\\"{x:1262,y:911,t:1527023279843};\\\", \\\"{x:1262,y:913,t:1527023279860};\\\", \\\"{x:1262,y:915,t:1527023279876};\\\", \\\"{x:1262,y:921,t:1527023279893};\\\", \\\"{x:1262,y:925,t:1527023279909};\\\", \\\"{x:1262,y:930,t:1527023279926};\\\", \\\"{x:1262,y:933,t:1527023279942};\\\", \\\"{x:1262,y:938,t:1527023279960};\\\", \\\"{x:1265,y:942,t:1527023279976};\\\", \\\"{x:1268,y:947,t:1527023279993};\\\", \\\"{x:1269,y:951,t:1527023280011};\\\", \\\"{x:1272,y:954,t:1527023280027};\\\", \\\"{x:1273,y:956,t:1527023280043};\\\", \\\"{x:1274,y:959,t:1527023280060};\\\", \\\"{x:1277,y:963,t:1527023280076};\\\", \\\"{x:1277,y:965,t:1527023280093};\\\", \\\"{x:1279,y:966,t:1527023280110};\\\", \\\"{x:1280,y:967,t:1527023280141};\\\", \\\"{x:1281,y:966,t:1527023280287};\\\", \\\"{x:1282,y:963,t:1527023280293};\\\", \\\"{x:1283,y:961,t:1527023280311};\\\", \\\"{x:1284,y:957,t:1527023280328};\\\", \\\"{x:1284,y:951,t:1527023280344};\\\", \\\"{x:1284,y:945,t:1527023280360};\\\", \\\"{x:1284,y:936,t:1527023280377};\\\", \\\"{x:1284,y:928,t:1527023280394};\\\", \\\"{x:1283,y:922,t:1527023280412};\\\", \\\"{x:1283,y:920,t:1527023280427};\\\", \\\"{x:1283,y:917,t:1527023280443};\\\", \\\"{x:1283,y:913,t:1527023280460};\\\", \\\"{x:1283,y:904,t:1527023280478};\\\", \\\"{x:1281,y:891,t:1527023280494};\\\", \\\"{x:1281,y:888,t:1527023280510};\\\", \\\"{x:1281,y:885,t:1527023280527};\\\", \\\"{x:1281,y:882,t:1527023280543};\\\", \\\"{x:1282,y:878,t:1527023280561};\\\", \\\"{x:1282,y:870,t:1527023280577};\\\", \\\"{x:1282,y:861,t:1527023280594};\\\", \\\"{x:1282,y:856,t:1527023280611};\\\", \\\"{x:1284,y:853,t:1527023280627};\\\", \\\"{x:1285,y:849,t:1527023280644};\\\", \\\"{x:1286,y:846,t:1527023280661};\\\", \\\"{x:1287,y:841,t:1527023280678};\\\", \\\"{x:1289,y:835,t:1527023280694};\\\", \\\"{x:1290,y:831,t:1527023280710};\\\", \\\"{x:1290,y:827,t:1527023280727};\\\", \\\"{x:1290,y:824,t:1527023280745};\\\", \\\"{x:1290,y:821,t:1527023280760};\\\", \\\"{x:1291,y:817,t:1527023280777};\\\", \\\"{x:1291,y:813,t:1527023280795};\\\", \\\"{x:1291,y:806,t:1527023280812};\\\", \\\"{x:1293,y:801,t:1527023280827};\\\", \\\"{x:1293,y:796,t:1527023280845};\\\", \\\"{x:1293,y:790,t:1527023280861};\\\", \\\"{x:1293,y:783,t:1527023280878};\\\", \\\"{x:1293,y:776,t:1527023280894};\\\", \\\"{x:1293,y:772,t:1527023280910};\\\", \\\"{x:1294,y:770,t:1527023280927};\\\", \\\"{x:1294,y:766,t:1527023280944};\\\", \\\"{x:1294,y:761,t:1527023280961};\\\", \\\"{x:1294,y:756,t:1527023280978};\\\", \\\"{x:1294,y:751,t:1527023280994};\\\", \\\"{x:1293,y:745,t:1527023281012};\\\", \\\"{x:1292,y:741,t:1527023281027};\\\", \\\"{x:1289,y:736,t:1527023281045};\\\", \\\"{x:1288,y:734,t:1527023281061};\\\", \\\"{x:1286,y:729,t:1527023281077};\\\", \\\"{x:1284,y:725,t:1527023281094};\\\", \\\"{x:1282,y:723,t:1527023281112};\\\", \\\"{x:1282,y:722,t:1527023281128};\\\", \\\"{x:1280,y:717,t:1527023281144};\\\", \\\"{x:1277,y:710,t:1527023281161};\\\", \\\"{x:1272,y:699,t:1527023281178};\\\", \\\"{x:1270,y:696,t:1527023281195};\\\", \\\"{x:1269,y:695,t:1527023281212};\\\", \\\"{x:1269,y:693,t:1527023281228};\\\", \\\"{x:1269,y:692,t:1527023281244};\\\", \\\"{x:1269,y:689,t:1527023281262};\\\", \\\"{x:1269,y:688,t:1527023281277};\\\", \\\"{x:1268,y:686,t:1527023281294};\\\", \\\"{x:1268,y:685,t:1527023281312};\\\", \\\"{x:1268,y:683,t:1527023281328};\\\", \\\"{x:1267,y:681,t:1527023281344};\\\", \\\"{x:1267,y:680,t:1527023281361};\\\", \\\"{x:1267,y:679,t:1527023281382};\\\", \\\"{x:1266,y:677,t:1527023281398};\\\", \\\"{x:1266,y:676,t:1527023281414};\\\", \\\"{x:1265,y:674,t:1527023281430};\\\", \\\"{x:1265,y:673,t:1527023281446};\\\", \\\"{x:1264,y:671,t:1527023281461};\\\", \\\"{x:1264,y:669,t:1527023281478};\\\", \\\"{x:1263,y:667,t:1527023281495};\\\", \\\"{x:1262,y:666,t:1527023281511};\\\", \\\"{x:1262,y:664,t:1527023281528};\\\", \\\"{x:1262,y:663,t:1527023281545};\\\", \\\"{x:1260,y:661,t:1527023281562};\\\", \\\"{x:1260,y:659,t:1527023281578};\\\", \\\"{x:1260,y:655,t:1527023281595};\\\", \\\"{x:1260,y:653,t:1527023281612};\\\", \\\"{x:1260,y:650,t:1527023281629};\\\", \\\"{x:1259,y:648,t:1527023281644};\\\", \\\"{x:1259,y:647,t:1527023281662};\\\", \\\"{x:1258,y:647,t:1527023282367};\\\", \\\"{x:1260,y:656,t:1527023282622};\\\", \\\"{x:1262,y:664,t:1527023282630};\\\", \\\"{x:1267,y:680,t:1527023282646};\\\", \\\"{x:1273,y:702,t:1527023282662};\\\", \\\"{x:1280,y:722,t:1527023282678};\\\", \\\"{x:1287,y:734,t:1527023282695};\\\", \\\"{x:1289,y:744,t:1527023282713};\\\", \\\"{x:1293,y:756,t:1527023282729};\\\", \\\"{x:1298,y:774,t:1527023282745};\\\", \\\"{x:1303,y:797,t:1527023282762};\\\", \\\"{x:1307,y:819,t:1527023282778};\\\", \\\"{x:1308,y:833,t:1527023282795};\\\", \\\"{x:1308,y:840,t:1527023282812};\\\", \\\"{x:1308,y:848,t:1527023282829};\\\", \\\"{x:1304,y:865,t:1527023282846};\\\", \\\"{x:1304,y:879,t:1527023282862};\\\", \\\"{x:1305,y:890,t:1527023282879};\\\", \\\"{x:1306,y:898,t:1527023282895};\\\", \\\"{x:1308,y:904,t:1527023282912};\\\", \\\"{x:1309,y:908,t:1527023282930};\\\", \\\"{x:1309,y:913,t:1527023282946};\\\", \\\"{x:1309,y:919,t:1527023282963};\\\", \\\"{x:1309,y:923,t:1527023282978};\\\", \\\"{x:1309,y:928,t:1527023282996};\\\", \\\"{x:1309,y:935,t:1527023283012};\\\", \\\"{x:1308,y:944,t:1527023283029};\\\", \\\"{x:1307,y:948,t:1527023283046};\\\", \\\"{x:1306,y:951,t:1527023283062};\\\", \\\"{x:1305,y:955,t:1527023283079};\\\", \\\"{x:1304,y:958,t:1527023283095};\\\", \\\"{x:1299,y:963,t:1527023283113};\\\", \\\"{x:1295,y:965,t:1527023283129};\\\", \\\"{x:1293,y:966,t:1527023283146};\\\", \\\"{x:1292,y:966,t:1527023283182};\\\", \\\"{x:1292,y:967,t:1527023283246};\\\", \\\"{x:1292,y:969,t:1527023283262};\\\", \\\"{x:1293,y:969,t:1527023283302};\\\", \\\"{x:1291,y:969,t:1527023283389};\\\", \\\"{x:1290,y:969,t:1527023283429};\\\", \\\"{x:1287,y:968,t:1527023283448};\\\", \\\"{x:1286,y:966,t:1527023283464};\\\", \\\"{x:1285,y:964,t:1527023283482};\\\", \\\"{x:1284,y:964,t:1527023283499};\\\", \\\"{x:1284,y:963,t:1527023283516};\\\", \\\"{x:1283,y:962,t:1527023283533};\\\", \\\"{x:1282,y:961,t:1527023283549};\\\", \\\"{x:1280,y:958,t:1527023283565};\\\", \\\"{x:1280,y:957,t:1527023283582};\\\", \\\"{x:1279,y:955,t:1527023283599};\\\", \\\"{x:1279,y:953,t:1527023283615};\\\", \\\"{x:1279,y:952,t:1527023283632};\\\", \\\"{x:1279,y:950,t:1527023283648};\\\", \\\"{x:1278,y:949,t:1527023283665};\\\", \\\"{x:1278,y:947,t:1527023283697};\\\", \\\"{x:1277,y:947,t:1527023283705};\\\", \\\"{x:1277,y:946,t:1527023283715};\\\", \\\"{x:1276,y:944,t:1527023283736};\\\", \\\"{x:1276,y:943,t:1527023283753};\\\", \\\"{x:1276,y:941,t:1527023283777};\\\", \\\"{x:1275,y:940,t:1527023283785};\\\", \\\"{x:1275,y:939,t:1527023283801};\\\", \\\"{x:1274,y:937,t:1527023283816};\\\", \\\"{x:1273,y:934,t:1527023283832};\\\", \\\"{x:1273,y:931,t:1527023283848};\\\", \\\"{x:1273,y:930,t:1527023283868};\\\", \\\"{x:1273,y:928,t:1527023283882};\\\", \\\"{x:1273,y:925,t:1527023283899};\\\", \\\"{x:1273,y:920,t:1527023283915};\\\", \\\"{x:1273,y:916,t:1527023283932};\\\", \\\"{x:1273,y:914,t:1527023283948};\\\", \\\"{x:1274,y:911,t:1527023283966};\\\", \\\"{x:1274,y:909,t:1527023283981};\\\", \\\"{x:1274,y:907,t:1527023283999};\\\", \\\"{x:1275,y:901,t:1527023284015};\\\", \\\"{x:1276,y:896,t:1527023284032};\\\", \\\"{x:1276,y:894,t:1527023284049};\\\", \\\"{x:1277,y:892,t:1527023284066};\\\", \\\"{x:1277,y:891,t:1527023284081};\\\", \\\"{x:1278,y:889,t:1527023284099};\\\", \\\"{x:1278,y:887,t:1527023284116};\\\", \\\"{x:1279,y:886,t:1527023284132};\\\", \\\"{x:1279,y:882,t:1527023284149};\\\", \\\"{x:1281,y:878,t:1527023284166};\\\", \\\"{x:1281,y:876,t:1527023284182};\\\", \\\"{x:1282,y:872,t:1527023284199};\\\", \\\"{x:1283,y:866,t:1527023284216};\\\", \\\"{x:1283,y:864,t:1527023284232};\\\", \\\"{x:1283,y:862,t:1527023284249};\\\", \\\"{x:1285,y:860,t:1527023284266};\\\", \\\"{x:1285,y:858,t:1527023284283};\\\", \\\"{x:1285,y:856,t:1527023284300};\\\", \\\"{x:1285,y:855,t:1527023284316};\\\", \\\"{x:1286,y:854,t:1527023284361};\\\", \\\"{x:1286,y:855,t:1527023284464};\\\", \\\"{x:1284,y:864,t:1527023284472};\\\", \\\"{x:1283,y:873,t:1527023284483};\\\", \\\"{x:1278,y:888,t:1527023284499};\\\", \\\"{x:1274,y:900,t:1527023284516};\\\", \\\"{x:1274,y:909,t:1527023284533};\\\", \\\"{x:1274,y:915,t:1527023284549};\\\", \\\"{x:1272,y:919,t:1527023284566};\\\", \\\"{x:1272,y:925,t:1527023284583};\\\", \\\"{x:1272,y:929,t:1527023284599};\\\", \\\"{x:1272,y:936,t:1527023284616};\\\", \\\"{x:1272,y:939,t:1527023284632};\\\", \\\"{x:1272,y:943,t:1527023284649};\\\", \\\"{x:1272,y:945,t:1527023284666};\\\", \\\"{x:1274,y:951,t:1527023284684};\\\", \\\"{x:1277,y:955,t:1527023284700};\\\", \\\"{x:1280,y:959,t:1527023284716};\\\", \\\"{x:1282,y:961,t:1527023284734};\\\", \\\"{x:1283,y:963,t:1527023284749};\\\", \\\"{x:1284,y:964,t:1527023284766};\\\", \\\"{x:1284,y:965,t:1527023284784};\\\", \\\"{x:1285,y:965,t:1527023285017};\\\", \\\"{x:1285,y:964,t:1527023285041};\\\", \\\"{x:1285,y:963,t:1527023285051};\\\", \\\"{x:1285,y:962,t:1527023285067};\\\", \\\"{x:1285,y:961,t:1527023285084};\\\", \\\"{x:1285,y:959,t:1527023285100};\\\", \\\"{x:1286,y:958,t:1527023285116};\\\", \\\"{x:1286,y:957,t:1527023285134};\\\", \\\"{x:1286,y:956,t:1527023285161};\\\", \\\"{x:1286,y:955,t:1527023285185};\\\", \\\"{x:1286,y:954,t:1527023285201};\\\", \\\"{x:1286,y:953,t:1527023285225};\\\", \\\"{x:1286,y:952,t:1527023285264};\\\", \\\"{x:1286,y:951,t:1527023285282};\\\", \\\"{x:1286,y:950,t:1527023285305};\\\", \\\"{x:1286,y:949,t:1527023285345};\\\", \\\"{x:1286,y:948,t:1527023285369};\\\", \\\"{x:1286,y:947,t:1527023285385};\\\", \\\"{x:1286,y:945,t:1527023285401};\\\", \\\"{x:1286,y:944,t:1527023285417};\\\", \\\"{x:1286,y:943,t:1527023285433};\\\", \\\"{x:1286,y:942,t:1527023285450};\\\", \\\"{x:1286,y:941,t:1527023285467};\\\", \\\"{x:1286,y:939,t:1527023285484};\\\", \\\"{x:1286,y:938,t:1527023285500};\\\", \\\"{x:1286,y:937,t:1527023285517};\\\", \\\"{x:1286,y:935,t:1527023285533};\\\", \\\"{x:1286,y:933,t:1527023285551};\\\", \\\"{x:1286,y:931,t:1527023285568};\\\", \\\"{x:1286,y:929,t:1527023285584};\\\", \\\"{x:1286,y:926,t:1527023285601};\\\", \\\"{x:1286,y:925,t:1527023285618};\\\", \\\"{x:1286,y:923,t:1527023285633};\\\", \\\"{x:1286,y:922,t:1527023285665};\\\", \\\"{x:1286,y:920,t:1527023285689};\\\", \\\"{x:1286,y:919,t:1527023285705};\\\", \\\"{x:1286,y:917,t:1527023285718};\\\", \\\"{x:1286,y:916,t:1527023285737};\\\", \\\"{x:1286,y:914,t:1527023285761};\\\", \\\"{x:1286,y:913,t:1527023285785};\\\", \\\"{x:1286,y:911,t:1527023285801};\\\", \\\"{x:1286,y:910,t:1527023285817};\\\", \\\"{x:1286,y:908,t:1527023285849};\\\", \\\"{x:1286,y:907,t:1527023285872};\\\", \\\"{x:1286,y:905,t:1527023285888};\\\", \\\"{x:1286,y:904,t:1527023285905};\\\", \\\"{x:1286,y:902,t:1527023285944};\\\", \\\"{x:1286,y:901,t:1527023285977};\\\", \\\"{x:1286,y:900,t:1527023286009};\\\", \\\"{x:1286,y:899,t:1527023286048};\\\", \\\"{x:1286,y:898,t:1527023286056};\\\", \\\"{x:1286,y:897,t:1527023286080};\\\", \\\"{x:1286,y:896,t:1527023286087};\\\", \\\"{x:1286,y:895,t:1527023286100};\\\", \\\"{x:1286,y:894,t:1527023286119};\\\", \\\"{x:1286,y:893,t:1527023286144};\\\", \\\"{x:1286,y:892,t:1527023286168};\\\", \\\"{x:1287,y:891,t:1527023286184};\\\", \\\"{x:1287,y:890,t:1527023286208};\\\", \\\"{x:1287,y:889,t:1527023286321};\\\", \\\"{x:1287,y:887,t:1527023286337};\\\", \\\"{x:1287,y:886,t:1527023286377};\\\", \\\"{x:1287,y:885,t:1527023286401};\\\", \\\"{x:1287,y:883,t:1527023286418};\\\", \\\"{x:1288,y:883,t:1527023286435};\\\", \\\"{x:1288,y:882,t:1527023286451};\\\", \\\"{x:1288,y:880,t:1527023286468};\\\", \\\"{x:1288,y:879,t:1527023286489};\\\", \\\"{x:1289,y:877,t:1527023286503};\\\", \\\"{x:1289,y:875,t:1527023286517};\\\", \\\"{x:1289,y:874,t:1527023286534};\\\", \\\"{x:1289,y:872,t:1527023286551};\\\", \\\"{x:1289,y:868,t:1527023286567};\\\", \\\"{x:1289,y:867,t:1527023286584};\\\", \\\"{x:1289,y:865,t:1527023286601};\\\", \\\"{x:1289,y:864,t:1527023286616};\\\", \\\"{x:1289,y:862,t:1527023286634};\\\", \\\"{x:1289,y:861,t:1527023286651};\\\", \\\"{x:1289,y:860,t:1527023286680};\\\", \\\"{x:1289,y:859,t:1527023286695};\\\", \\\"{x:1289,y:858,t:1527023286712};\\\", \\\"{x:1289,y:857,t:1527023286736};\\\", \\\"{x:1289,y:856,t:1527023286751};\\\", \\\"{x:1289,y:855,t:1527023286768};\\\", \\\"{x:1289,y:853,t:1527023286784};\\\", \\\"{x:1289,y:852,t:1527023286802};\\\", \\\"{x:1289,y:851,t:1527023286818};\\\", \\\"{x:1289,y:850,t:1527023286834};\\\", \\\"{x:1289,y:849,t:1527023286851};\\\", \\\"{x:1289,y:848,t:1527023286872};\\\", \\\"{x:1289,y:847,t:1527023286884};\\\", \\\"{x:1289,y:846,t:1527023286901};\\\", \\\"{x:1289,y:845,t:1527023286921};\\\", \\\"{x:1289,y:844,t:1527023286953};\\\", \\\"{x:1289,y:843,t:1527023286968};\\\", \\\"{x:1289,y:842,t:1527023286993};\\\", \\\"{x:1289,y:841,t:1527023287009};\\\", \\\"{x:1289,y:840,t:1527023287019};\\\", \\\"{x:1289,y:839,t:1527023287035};\\\", \\\"{x:1288,y:836,t:1527023287051};\\\", \\\"{x:1288,y:835,t:1527023287068};\\\", \\\"{x:1288,y:833,t:1527023287084};\\\", \\\"{x:1288,y:832,t:1527023287101};\\\", \\\"{x:1288,y:831,t:1527023287119};\\\", \\\"{x:1288,y:830,t:1527023287134};\\\", \\\"{x:1288,y:829,t:1527023287151};\\\", \\\"{x:1288,y:828,t:1527023287185};\\\", \\\"{x:1288,y:827,t:1527023287209};\\\", \\\"{x:1287,y:827,t:1527023287225};\\\", \\\"{x:1287,y:826,t:1527023287257};\\\", \\\"{x:1287,y:825,t:1527023287305};\\\", \\\"{x:1287,y:826,t:1527023287433};\\\", \\\"{x:1284,y:831,t:1527023287441};\\\", \\\"{x:1283,y:836,t:1527023287451};\\\", \\\"{x:1280,y:846,t:1527023287469};\\\", \\\"{x:1278,y:853,t:1527023287486};\\\", \\\"{x:1276,y:859,t:1527023287502};\\\", \\\"{x:1275,y:864,t:1527023287519};\\\", \\\"{x:1275,y:871,t:1527023287536};\\\", \\\"{x:1275,y:879,t:1527023287551};\\\", \\\"{x:1275,y:889,t:1527023287569};\\\", \\\"{x:1275,y:896,t:1527023287585};\\\", \\\"{x:1275,y:904,t:1527023287602};\\\", \\\"{x:1275,y:913,t:1527023287619};\\\", \\\"{x:1275,y:920,t:1527023287636};\\\", \\\"{x:1276,y:928,t:1527023287651};\\\", \\\"{x:1276,y:933,t:1527023287669};\\\", \\\"{x:1277,y:940,t:1527023287685};\\\", \\\"{x:1280,y:945,t:1527023287703};\\\", \\\"{x:1281,y:949,t:1527023287719};\\\", \\\"{x:1281,y:951,t:1527023287735};\\\", \\\"{x:1281,y:952,t:1527023287753};\\\", \\\"{x:1281,y:953,t:1527023287777};\\\", \\\"{x:1281,y:954,t:1527023287793};\\\", \\\"{x:1281,y:955,t:1527023287817};\\\", \\\"{x:1283,y:955,t:1527023287968};\\\", \\\"{x:1284,y:954,t:1527023287985};\\\", \\\"{x:1285,y:953,t:1527023288002};\\\", \\\"{x:1286,y:951,t:1527023288018};\\\", \\\"{x:1287,y:951,t:1527023288035};\\\", \\\"{x:1287,y:950,t:1527023288052};\\\", \\\"{x:1288,y:949,t:1527023288089};\\\", \\\"{x:1288,y:948,t:1527023288103};\\\", \\\"{x:1289,y:947,t:1527023288118};\\\", \\\"{x:1290,y:945,t:1527023288136};\\\", \\\"{x:1290,y:944,t:1527023288289};\\\", \\\"{x:1290,y:943,t:1527023288312};\\\", \\\"{x:1290,y:944,t:1527023288449};\\\", \\\"{x:1290,y:946,t:1527023288456};\\\", \\\"{x:1290,y:948,t:1527023288470};\\\", \\\"{x:1289,y:950,t:1527023288486};\\\", \\\"{x:1289,y:952,t:1527023288503};\\\", \\\"{x:1289,y:953,t:1527023288521};\\\", \\\"{x:1288,y:953,t:1527023288553};\\\", \\\"{x:1288,y:954,t:1527023288592};\\\", \\\"{x:1287,y:954,t:1527023288603};\\\", \\\"{x:1287,y:955,t:1527023288657};\\\", \\\"{x:1287,y:956,t:1527023288669};\\\", \\\"{x:1286,y:957,t:1527023288713};\\\", \\\"{x:1285,y:957,t:1527023288977};\\\", \\\"{x:1285,y:958,t:1527023288993};\\\", \\\"{x:1285,y:959,t:1527023289041};\\\", \\\"{x:1285,y:956,t:1527023289152};\\\", \\\"{x:1285,y:952,t:1527023289159};\\\", \\\"{x:1285,y:949,t:1527023289169};\\\", \\\"{x:1287,y:940,t:1527023289186};\\\", \\\"{x:1290,y:932,t:1527023289203};\\\", \\\"{x:1292,y:927,t:1527023289218};\\\", \\\"{x:1295,y:920,t:1527023289236};\\\", \\\"{x:1297,y:914,t:1527023289253};\\\", \\\"{x:1299,y:905,t:1527023289268};\\\", \\\"{x:1301,y:901,t:1527023289286};\\\", \\\"{x:1302,y:898,t:1527023289303};\\\", \\\"{x:1303,y:897,t:1527023289319};\\\", \\\"{x:1304,y:894,t:1527023289336};\\\", \\\"{x:1306,y:891,t:1527023289353};\\\", \\\"{x:1307,y:887,t:1527023289369};\\\", \\\"{x:1308,y:885,t:1527023289386};\\\", \\\"{x:1310,y:880,t:1527023289403};\\\", \\\"{x:1311,y:876,t:1527023289419};\\\", \\\"{x:1313,y:874,t:1527023289436};\\\", \\\"{x:1314,y:871,t:1527023289453};\\\", \\\"{x:1314,y:869,t:1527023289469};\\\", \\\"{x:1317,y:865,t:1527023289487};\\\", \\\"{x:1320,y:861,t:1527023289504};\\\", \\\"{x:1322,y:859,t:1527023289519};\\\", \\\"{x:1325,y:855,t:1527023289536};\\\", \\\"{x:1326,y:852,t:1527023289553};\\\", \\\"{x:1329,y:849,t:1527023289569};\\\", \\\"{x:1332,y:846,t:1527023289587};\\\", \\\"{x:1335,y:841,t:1527023289604};\\\", \\\"{x:1337,y:837,t:1527023289620};\\\", \\\"{x:1340,y:833,t:1527023289636};\\\", \\\"{x:1343,y:828,t:1527023289653};\\\", \\\"{x:1344,y:824,t:1527023289670};\\\", \\\"{x:1347,y:821,t:1527023289686};\\\", \\\"{x:1351,y:816,t:1527023289703};\\\", \\\"{x:1358,y:809,t:1527023289720};\\\", \\\"{x:1362,y:803,t:1527023289736};\\\", \\\"{x:1364,y:799,t:1527023289753};\\\", \\\"{x:1367,y:795,t:1527023289770};\\\", \\\"{x:1369,y:794,t:1527023289786};\\\", \\\"{x:1371,y:792,t:1527023289804};\\\", \\\"{x:1371,y:791,t:1527023289821};\\\", \\\"{x:1373,y:789,t:1527023289836};\\\", \\\"{x:1374,y:787,t:1527023289854};\\\", \\\"{x:1374,y:786,t:1527023289881};\\\", \\\"{x:1376,y:785,t:1527023289889};\\\", \\\"{x:1376,y:784,t:1527023289905};\\\", \\\"{x:1377,y:784,t:1527023289920};\\\", \\\"{x:1377,y:783,t:1527023289936};\\\", \\\"{x:1377,y:782,t:1527023289953};\\\", \\\"{x:1379,y:781,t:1527023289971};\\\", \\\"{x:1379,y:779,t:1527023289987};\\\", \\\"{x:1381,y:777,t:1527023290004};\\\", \\\"{x:1383,y:775,t:1527023290020};\\\", \\\"{x:1384,y:773,t:1527023290037};\\\", \\\"{x:1386,y:771,t:1527023290054};\\\", \\\"{x:1386,y:769,t:1527023290076};\\\", \\\"{x:1387,y:768,t:1527023290086};\\\", \\\"{x:1387,y:766,t:1527023290103};\\\", \\\"{x:1389,y:765,t:1527023290120};\\\", \\\"{x:1390,y:763,t:1527023290137};\\\", \\\"{x:1390,y:762,t:1527023290153};\\\", \\\"{x:1390,y:761,t:1527023290170};\\\", \\\"{x:1391,y:761,t:1527023290191};\\\", \\\"{x:1391,y:760,t:1527023290203};\\\", \\\"{x:1391,y:759,t:1527023290220};\\\", \\\"{x:1390,y:759,t:1527023291081};\\\", \\\"{x:1389,y:760,t:1527023291089};\\\", \\\"{x:1386,y:760,t:1527023291105};\\\", \\\"{x:1383,y:761,t:1527023291121};\\\", \\\"{x:1380,y:762,t:1527023291137};\\\", \\\"{x:1379,y:763,t:1527023291155};\\\", \\\"{x:1378,y:763,t:1527023291449};\\\", \\\"{x:1375,y:764,t:1527023291458};\\\", \\\"{x:1373,y:764,t:1527023291473};\\\", \\\"{x:1372,y:764,t:1527023291489};\\\", \\\"{x:1371,y:765,t:1527023291504};\\\", \\\"{x:1370,y:765,t:1527023291977};\\\", \\\"{x:1370,y:766,t:1527023292361};\\\", \\\"{x:1370,y:767,t:1527023292371};\\\", \\\"{x:1369,y:777,t:1527023292389};\\\", \\\"{x:1368,y:782,t:1527023292406};\\\", \\\"{x:1368,y:787,t:1527023292422};\\\", \\\"{x:1368,y:790,t:1527023292439};\\\", \\\"{x:1368,y:795,t:1527023292456};\\\", \\\"{x:1369,y:804,t:1527023292472};\\\", \\\"{x:1370,y:812,t:1527023292488};\\\", \\\"{x:1375,y:820,t:1527023292505};\\\", \\\"{x:1377,y:826,t:1527023292523};\\\", \\\"{x:1380,y:831,t:1527023292539};\\\", \\\"{x:1383,y:838,t:1527023292556};\\\", \\\"{x:1387,y:844,t:1527023292573};\\\", \\\"{x:1395,y:854,t:1527023292589};\\\", \\\"{x:1404,y:862,t:1527023292606};\\\", \\\"{x:1411,y:868,t:1527023292623};\\\", \\\"{x:1421,y:875,t:1527023292639};\\\", \\\"{x:1425,y:879,t:1527023292655};\\\", \\\"{x:1428,y:881,t:1527023292672};\\\", \\\"{x:1431,y:883,t:1527023292688};\\\", \\\"{x:1431,y:885,t:1527023292706};\\\", \\\"{x:1434,y:889,t:1527023292723};\\\", \\\"{x:1438,y:895,t:1527023292739};\\\", \\\"{x:1443,y:901,t:1527023292755};\\\", \\\"{x:1447,y:907,t:1527023292773};\\\", \\\"{x:1450,y:912,t:1527023292789};\\\", \\\"{x:1455,y:918,t:1527023292805};\\\", \\\"{x:1458,y:924,t:1527023292823};\\\", \\\"{x:1463,y:929,t:1527023292839};\\\", \\\"{x:1466,y:932,t:1527023292856};\\\", \\\"{x:1469,y:935,t:1527023292873};\\\", \\\"{x:1471,y:937,t:1527023292889};\\\", \\\"{x:1471,y:938,t:1527023292905};\\\", \\\"{x:1473,y:940,t:1527023292923};\\\", \\\"{x:1473,y:941,t:1527023292938};\\\", \\\"{x:1474,y:943,t:1527023292956};\\\", \\\"{x:1474,y:944,t:1527023292976};\\\", \\\"{x:1474,y:945,t:1527023293000};\\\", \\\"{x:1474,y:946,t:1527023293008};\\\", \\\"{x:1473,y:947,t:1527023293022};\\\", \\\"{x:1466,y:948,t:1527023293040};\\\", \\\"{x:1460,y:949,t:1527023293056};\\\", \\\"{x:1434,y:949,t:1527023293073};\\\", \\\"{x:1414,y:944,t:1527023293089};\\\", \\\"{x:1370,y:928,t:1527023293106};\\\", \\\"{x:1291,y:900,t:1527023293123};\\\", \\\"{x:1213,y:866,t:1527023293140};\\\", \\\"{x:1149,y:847,t:1527023293156};\\\", \\\"{x:1123,y:838,t:1527023293173};\\\", \\\"{x:1107,y:833,t:1527023293190};\\\", \\\"{x:1102,y:832,t:1527023293206};\\\", \\\"{x:1101,y:832,t:1527023293297};\\\", \\\"{x:1097,y:832,t:1527023293306};\\\", \\\"{x:1086,y:831,t:1527023293323};\\\", \\\"{x:1068,y:828,t:1527023293340};\\\", \\\"{x:1048,y:825,t:1527023293356};\\\", \\\"{x:1026,y:824,t:1527023293372};\\\", \\\"{x:1015,y:824,t:1527023293390};\\\", \\\"{x:1007,y:824,t:1527023293407};\\\", \\\"{x:1002,y:824,t:1527023293424};\\\", \\\"{x:995,y:824,t:1527023293440};\\\", \\\"{x:987,y:824,t:1527023293457};\\\", \\\"{x:978,y:823,t:1527023293473};\\\", \\\"{x:971,y:823,t:1527023293490};\\\", \\\"{x:962,y:821,t:1527023293507};\\\", \\\"{x:955,y:820,t:1527023293523};\\\", \\\"{x:947,y:817,t:1527023293539};\\\", \\\"{x:940,y:816,t:1527023293556};\\\", \\\"{x:928,y:812,t:1527023293573};\\\", \\\"{x:917,y:806,t:1527023293590};\\\", \\\"{x:903,y:800,t:1527023293606};\\\", \\\"{x:890,y:793,t:1527023293622};\\\", \\\"{x:881,y:788,t:1527023293640};\\\", \\\"{x:874,y:783,t:1527023293656};\\\", \\\"{x:872,y:781,t:1527023293672};\\\", \\\"{x:871,y:780,t:1527023293689};\\\", \\\"{x:870,y:779,t:1527023293706};\\\", \\\"{x:868,y:779,t:1527023293722};\\\", \\\"{x:867,y:779,t:1527023293739};\\\", \\\"{x:858,y:779,t:1527023293756};\\\", \\\"{x:835,y:774,t:1527023293772};\\\", \\\"{x:809,y:768,t:1527023293789};\\\", \\\"{x:780,y:759,t:1527023293806};\\\", \\\"{x:754,y:753,t:1527023293822};\\\", \\\"{x:733,y:748,t:1527023293839};\\\", \\\"{x:703,y:739,t:1527023293855};\\\", \\\"{x:691,y:735,t:1527023293872};\\\", \\\"{x:688,y:734,t:1527023293889};\\\", \\\"{x:686,y:733,t:1527023293907};\\\", \\\"{x:685,y:733,t:1527023293928};\\\", \\\"{x:684,y:733,t:1527023293939};\\\", \\\"{x:683,y:732,t:1527023293956};\\\", \\\"{x:677,y:731,t:1527023293974};\\\", \\\"{x:665,y:727,t:1527023293990};\\\", \\\"{x:638,y:713,t:1527023294007};\\\", \\\"{x:608,y:701,t:1527023294023};\\\", \\\"{x:571,y:683,t:1527023294040};\\\", \\\"{x:515,y:660,t:1527023294057};\\\", \\\"{x:482,y:646,t:1527023294075};\\\", \\\"{x:448,y:630,t:1527023294089};\\\", \\\"{x:431,y:622,t:1527023294106};\\\", \\\"{x:417,y:616,t:1527023294125};\\\", \\\"{x:416,y:615,t:1527023294142};\\\", \\\"{x:414,y:613,t:1527023294183};\\\", \\\"{x:414,y:612,t:1527023294192};\\\", \\\"{x:413,y:610,t:1527023294209};\\\", \\\"{x:412,y:609,t:1527023294271};\\\", \\\"{x:411,y:607,t:1527023294280};\\\", \\\"{x:410,y:603,t:1527023294292};\\\", \\\"{x:409,y:597,t:1527023294309};\\\", \\\"{x:407,y:592,t:1527023294325};\\\", \\\"{x:406,y:584,t:1527023294342};\\\", \\\"{x:403,y:580,t:1527023294360};\\\", \\\"{x:402,y:576,t:1527023294375};\\\", \\\"{x:400,y:573,t:1527023294392};\\\", \\\"{x:399,y:571,t:1527023294409};\\\", \\\"{x:399,y:570,t:1527023294426};\\\", \\\"{x:398,y:569,t:1527023294442};\\\", \\\"{x:398,y:568,t:1527023295561};\\\", \\\"{x:396,y:564,t:1527023295573};\\\", \\\"{x:393,y:562,t:1527023295593};\\\", \\\"{x:393,y:561,t:1527023296088};\\\", \\\"{x:393,y:566,t:1527023301137};\\\", \\\"{x:402,y:589,t:1527023301149};\\\", \\\"{x:431,y:643,t:1527023301165};\\\", \\\"{x:442,y:662,t:1527023301181};\\\", \\\"{x:445,y:672,t:1527023301198};\\\", \\\"{x:448,y:679,t:1527023301215};\\\", \\\"{x:451,y:683,t:1527023301231};\\\", \\\"{x:452,y:686,t:1527023301247};\\\", \\\"{x:454,y:691,t:1527023301264};\\\", \\\"{x:456,y:696,t:1527023301282};\\\", \\\"{x:457,y:698,t:1527023301297};\\\", \\\"{x:458,y:700,t:1527023301314};\\\", \\\"{x:458,y:701,t:1527023301332};\\\", \\\"{x:459,y:702,t:1527023301416};\\\", \\\"{x:464,y:704,t:1527023301431};\\\", \\\"{x:467,y:708,t:1527023301448};\\\", \\\"{x:470,y:712,t:1527023301465};\\\", \\\"{x:473,y:717,t:1527023301481};\\\", \\\"{x:475,y:719,t:1527023301497};\\\", \\\"{x:476,y:722,t:1527023301515};\\\", \\\"{x:477,y:722,t:1527023301532};\\\" ] }, { \\\"rt\\\": 14934, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 6, \\\"time_elapsed\\\": 335229, \\\"internal_node_id\\\": \\\"0.0-5.0-1.0\\\", \\\"subject\\\": \\\"8LK9M\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"hotel\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 2, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"K\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-D -Z \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:484,y:747,t:1527023304298};\\\", \\\"{x:483,y:747,t:1527023304936};\\\", \\\"{x:480,y:747,t:1527023304951};\\\", \\\"{x:466,y:740,t:1527023304968};\\\", \\\"{x:458,y:735,t:1527023304985};\\\", \\\"{x:448,y:731,t:1527023305000};\\\", \\\"{x:441,y:726,t:1527023305018};\\\", \\\"{x:433,y:720,t:1527023305033};\\\", \\\"{x:427,y:715,t:1527023305051};\\\", \\\"{x:418,y:708,t:1527023305068};\\\", \\\"{x:409,y:697,t:1527023305085};\\\", \\\"{x:403,y:685,t:1527023305100};\\\", \\\"{x:398,y:676,t:1527023305117};\\\", \\\"{x:394,y:667,t:1527023305134};\\\", \\\"{x:392,y:664,t:1527023305150};\\\", \\\"{x:391,y:657,t:1527023305168};\\\", \\\"{x:391,y:646,t:1527023305186};\\\", \\\"{x:394,y:636,t:1527023305200};\\\", \\\"{x:399,y:626,t:1527023305218};\\\", \\\"{x:402,y:619,t:1527023305234};\\\", \\\"{x:405,y:613,t:1527023305250};\\\", \\\"{x:409,y:606,t:1527023305268};\\\", \\\"{x:413,y:598,t:1527023305285};\\\", \\\"{x:418,y:589,t:1527023305300};\\\", \\\"{x:425,y:576,t:1527023305318};\\\", \\\"{x:431,y:567,t:1527023305335};\\\", \\\"{x:439,y:557,t:1527023305350};\\\", \\\"{x:449,y:539,t:1527023305368};\\\", \\\"{x:455,y:533,t:1527023305385};\\\", \\\"{x:464,y:525,t:1527023305400};\\\", \\\"{x:473,y:520,t:1527023305418};\\\", \\\"{x:481,y:516,t:1527023305434};\\\", \\\"{x:490,y:509,t:1527023305451};\\\", \\\"{x:495,y:505,t:1527023305468};\\\", \\\"{x:501,y:501,t:1527023305485};\\\", \\\"{x:506,y:497,t:1527023305501};\\\", \\\"{x:510,y:495,t:1527023305518};\\\", \\\"{x:513,y:494,t:1527023305535};\\\", \\\"{x:516,y:493,t:1527023305552};\\\", \\\"{x:519,y:491,t:1527023305568};\\\", \\\"{x:520,y:491,t:1527023305585};\\\", \\\"{x:522,y:490,t:1527023305602};\\\", \\\"{x:523,y:489,t:1527023305618};\\\", \\\"{x:525,y:489,t:1527023305635};\\\", \\\"{x:531,y:488,t:1527023305653};\\\", \\\"{x:537,y:487,t:1527023305668};\\\", \\\"{x:543,y:486,t:1527023305684};\\\", \\\"{x:549,y:484,t:1527023305702};\\\", \\\"{x:559,y:483,t:1527023305718};\\\", \\\"{x:569,y:482,t:1527023305734};\\\", \\\"{x:582,y:479,t:1527023305752};\\\", \\\"{x:591,y:478,t:1527023305768};\\\", \\\"{x:600,y:477,t:1527023305786};\\\", \\\"{x:608,y:476,t:1527023305802};\\\", \\\"{x:614,y:476,t:1527023305818};\\\", \\\"{x:620,y:475,t:1527023305835};\\\", \\\"{x:623,y:475,t:1527023305852};\\\", \\\"{x:628,y:474,t:1527023305868};\\\", \\\"{x:633,y:474,t:1527023305884};\\\", \\\"{x:637,y:474,t:1527023305902};\\\", \\\"{x:642,y:474,t:1527023305918};\\\", \\\"{x:651,y:474,t:1527023305935};\\\", \\\"{x:667,y:474,t:1527023305952};\\\", \\\"{x:677,y:474,t:1527023305968};\\\", \\\"{x:684,y:474,t:1527023305985};\\\", \\\"{x:688,y:474,t:1527023306002};\\\", \\\"{x:691,y:474,t:1527023306018};\\\", \\\"{x:692,y:474,t:1527023306035};\\\", \\\"{x:694,y:474,t:1527023306096};\\\", \\\"{x:695,y:474,t:1527023306104};\\\", \\\"{x:697,y:474,t:1527023306119};\\\", \\\"{x:702,y:474,t:1527023306134};\\\", \\\"{x:722,y:474,t:1527023306152};\\\", \\\"{x:748,y:474,t:1527023306169};\\\", \\\"{x:777,y:474,t:1527023306185};\\\", \\\"{x:807,y:474,t:1527023306202};\\\", \\\"{x:843,y:474,t:1527023306219};\\\", \\\"{x:895,y:478,t:1527023306237};\\\", \\\"{x:946,y:486,t:1527023306252};\\\", \\\"{x:983,y:492,t:1527023306269};\\\", \\\"{x:1016,y:497,t:1527023306286};\\\", \\\"{x:1047,y:502,t:1527023306302};\\\", \\\"{x:1078,y:506,t:1527023306319};\\\", \\\"{x:1107,y:510,t:1527023306335};\\\", \\\"{x:1146,y:511,t:1527023306352};\\\", \\\"{x:1163,y:511,t:1527023306369};\\\", \\\"{x:1172,y:514,t:1527023306386};\\\", \\\"{x:1179,y:516,t:1527023306402};\\\", \\\"{x:1190,y:520,t:1527023306419};\\\", \\\"{x:1204,y:526,t:1527023306436};\\\", \\\"{x:1215,y:531,t:1527023306452};\\\", \\\"{x:1225,y:537,t:1527023306469};\\\", \\\"{x:1233,y:544,t:1527023306485};\\\", \\\"{x:1247,y:556,t:1527023306503};\\\", \\\"{x:1270,y:572,t:1527023306519};\\\", \\\"{x:1298,y:592,t:1527023306536};\\\", \\\"{x:1311,y:602,t:1527023306552};\\\", \\\"{x:1326,y:612,t:1527023306569};\\\", \\\"{x:1337,y:620,t:1527023306585};\\\", \\\"{x:1348,y:630,t:1527023306603};\\\", \\\"{x:1361,y:641,t:1527023306620};\\\", \\\"{x:1369,y:651,t:1527023306637};\\\", \\\"{x:1381,y:662,t:1527023306652};\\\", \\\"{x:1396,y:679,t:1527023306669};\\\", \\\"{x:1410,y:693,t:1527023306686};\\\", \\\"{x:1422,y:704,t:1527023306703};\\\", \\\"{x:1427,y:710,t:1527023306719};\\\", \\\"{x:1431,y:715,t:1527023306736};\\\", \\\"{x:1434,y:720,t:1527023306752};\\\", \\\"{x:1434,y:722,t:1527023306770};\\\", \\\"{x:1435,y:725,t:1527023306786};\\\", \\\"{x:1436,y:730,t:1527023306802};\\\", \\\"{x:1438,y:737,t:1527023306819};\\\", \\\"{x:1439,y:741,t:1527023306837};\\\", \\\"{x:1440,y:749,t:1527023306852};\\\", \\\"{x:1441,y:756,t:1527023306869};\\\", \\\"{x:1442,y:767,t:1527023306887};\\\", \\\"{x:1444,y:778,t:1527023306902};\\\", \\\"{x:1446,y:785,t:1527023306920};\\\", \\\"{x:1447,y:791,t:1527023306936};\\\", \\\"{x:1448,y:794,t:1527023306953};\\\", \\\"{x:1450,y:798,t:1527023306969};\\\", \\\"{x:1451,y:802,t:1527023306986};\\\", \\\"{x:1455,y:807,t:1527023307002};\\\", \\\"{x:1458,y:812,t:1527023307019};\\\", \\\"{x:1461,y:818,t:1527023307037};\\\", \\\"{x:1464,y:822,t:1527023307053};\\\", \\\"{x:1470,y:830,t:1527023307069};\\\", \\\"{x:1475,y:840,t:1527023307086};\\\", \\\"{x:1482,y:852,t:1527023307103};\\\", \\\"{x:1490,y:864,t:1527023307119};\\\", \\\"{x:1502,y:880,t:1527023307136};\\\", \\\"{x:1507,y:888,t:1527023307152};\\\", \\\"{x:1513,y:893,t:1527023307169};\\\", \\\"{x:1521,y:896,t:1527023307186};\\\", \\\"{x:1527,y:899,t:1527023307203};\\\", \\\"{x:1532,y:901,t:1527023307219};\\\", \\\"{x:1542,y:901,t:1527023307237};\\\", \\\"{x:1551,y:901,t:1527023307254};\\\", \\\"{x:1564,y:901,t:1527023307269};\\\", \\\"{x:1576,y:897,t:1527023307286};\\\", \\\"{x:1587,y:892,t:1527023307303};\\\", \\\"{x:1601,y:885,t:1527023307319};\\\", \\\"{x:1617,y:873,t:1527023307335};\\\", \\\"{x:1624,y:868,t:1527023307352};\\\", \\\"{x:1627,y:864,t:1527023307369};\\\", \\\"{x:1629,y:861,t:1527023307385};\\\", \\\"{x:1629,y:860,t:1527023307403};\\\", \\\"{x:1629,y:859,t:1527023307418};\\\", \\\"{x:1629,y:858,t:1527023307435};\\\", \\\"{x:1629,y:855,t:1527023307453};\\\", \\\"{x:1629,y:850,t:1527023307468};\\\", \\\"{x:1630,y:842,t:1527023307486};\\\", \\\"{x:1634,y:829,t:1527023307503};\\\", \\\"{x:1635,y:812,t:1527023307519};\\\", \\\"{x:1626,y:786,t:1527023307535};\\\", \\\"{x:1618,y:773,t:1527023307552};\\\", \\\"{x:1616,y:766,t:1527023307569};\\\", \\\"{x:1612,y:761,t:1527023307586};\\\", \\\"{x:1612,y:758,t:1527023307602};\\\", \\\"{x:1610,y:757,t:1527023307632};\\\", \\\"{x:1610,y:756,t:1527023307640};\\\", \\\"{x:1607,y:756,t:1527023307656};\\\", \\\"{x:1602,y:759,t:1527023307672};\\\", \\\"{x:1602,y:760,t:1527023307686};\\\", \\\"{x:1598,y:764,t:1527023307703};\\\", \\\"{x:1596,y:765,t:1527023307719};\\\", \\\"{x:1590,y:769,t:1527023307736};\\\", \\\"{x:1529,y:793,t:1527023307754};\\\", \\\"{x:1508,y:809,t:1527023307769};\\\", \\\"{x:1499,y:814,t:1527023307786};\\\", \\\"{x:1495,y:818,t:1527023307803};\\\", \\\"{x:1485,y:822,t:1527023307820};\\\", \\\"{x:1484,y:823,t:1527023307835};\\\", \\\"{x:1482,y:825,t:1527023308112};\\\", \\\"{x:1481,y:825,t:1527023308135};\\\", \\\"{x:1477,y:826,t:1527023308160};\\\", \\\"{x:1475,y:826,t:1527023308170};\\\", \\\"{x:1471,y:826,t:1527023308186};\\\", \\\"{x:1468,y:826,t:1527023308203};\\\", \\\"{x:1466,y:825,t:1527023308219};\\\", \\\"{x:1465,y:825,t:1527023308235};\\\", \\\"{x:1459,y:822,t:1527023308253};\\\", \\\"{x:1456,y:822,t:1527023308269};\\\", \\\"{x:1450,y:822,t:1527023308286};\\\", \\\"{x:1442,y:822,t:1527023308303};\\\", \\\"{x:1427,y:822,t:1527023308319};\\\", \\\"{x:1419,y:822,t:1527023308337};\\\", \\\"{x:1410,y:823,t:1527023308353};\\\", \\\"{x:1402,y:825,t:1527023308369};\\\", \\\"{x:1398,y:827,t:1527023308387};\\\", \\\"{x:1394,y:829,t:1527023308403};\\\", \\\"{x:1390,y:830,t:1527023308420};\\\", \\\"{x:1383,y:833,t:1527023308437};\\\", \\\"{x:1379,y:834,t:1527023308453};\\\", \\\"{x:1371,y:837,t:1527023308470};\\\", \\\"{x:1360,y:840,t:1527023308487};\\\", \\\"{x:1348,y:848,t:1527023308504};\\\", \\\"{x:1336,y:857,t:1527023308520};\\\", \\\"{x:1330,y:860,t:1527023308537};\\\", \\\"{x:1326,y:863,t:1527023308553};\\\", \\\"{x:1322,y:866,t:1527023308570};\\\", \\\"{x:1321,y:866,t:1527023308587};\\\", \\\"{x:1318,y:869,t:1527023308603};\\\", \\\"{x:1314,y:870,t:1527023308620};\\\", \\\"{x:1309,y:874,t:1527023308637};\\\", \\\"{x:1302,y:878,t:1527023308653};\\\", \\\"{x:1293,y:882,t:1527023308670};\\\", \\\"{x:1286,y:883,t:1527023308687};\\\", \\\"{x:1283,y:885,t:1527023308703};\\\", \\\"{x:1280,y:886,t:1527023308719};\\\", \\\"{x:1279,y:887,t:1527023308736};\\\", \\\"{x:1280,y:887,t:1527023308848};\\\", \\\"{x:1286,y:883,t:1527023308856};\\\", \\\"{x:1294,y:879,t:1527023308869};\\\", \\\"{x:1311,y:867,t:1527023308887};\\\", \\\"{x:1333,y:849,t:1527023308903};\\\", \\\"{x:1368,y:819,t:1527023308920};\\\", \\\"{x:1392,y:792,t:1527023308938};\\\", \\\"{x:1414,y:761,t:1527023308953};\\\", \\\"{x:1435,y:725,t:1527023308970};\\\", \\\"{x:1458,y:678,t:1527023308987};\\\", \\\"{x:1474,y:634,t:1527023309004};\\\", \\\"{x:1487,y:608,t:1527023309020};\\\", \\\"{x:1500,y:585,t:1527023309037};\\\", \\\"{x:1512,y:567,t:1527023309054};\\\", \\\"{x:1520,y:552,t:1527023309070};\\\", \\\"{x:1529,y:540,t:1527023309087};\\\", \\\"{x:1535,y:527,t:1527023309104};\\\", \\\"{x:1544,y:515,t:1527023309121};\\\", \\\"{x:1551,y:507,t:1527023309137};\\\", \\\"{x:1555,y:502,t:1527023309154};\\\", \\\"{x:1559,y:497,t:1527023309170};\\\", \\\"{x:1564,y:494,t:1527023309187};\\\", \\\"{x:1570,y:489,t:1527023309204};\\\", \\\"{x:1579,y:482,t:1527023309220};\\\", \\\"{x:1587,y:475,t:1527023309237};\\\", \\\"{x:1593,y:469,t:1527023309254};\\\", \\\"{x:1596,y:466,t:1527023309270};\\\", \\\"{x:1597,y:463,t:1527023309288};\\\", \\\"{x:1599,y:461,t:1527023309303};\\\", \\\"{x:1601,y:459,t:1527023309319};\\\", \\\"{x:1603,y:456,t:1527023309337};\\\", \\\"{x:1606,y:453,t:1527023309354};\\\", \\\"{x:1609,y:449,t:1527023309370};\\\", \\\"{x:1609,y:448,t:1527023309416};\\\", \\\"{x:1610,y:447,t:1527023309423};\\\", \\\"{x:1610,y:446,t:1527023309437};\\\", \\\"{x:1615,y:442,t:1527023309454};\\\", \\\"{x:1618,y:440,t:1527023309469};\\\", \\\"{x:1623,y:436,t:1527023309487};\\\", \\\"{x:1631,y:429,t:1527023309503};\\\", \\\"{x:1632,y:427,t:1527023309521};\\\", \\\"{x:1634,y:424,t:1527023309537};\\\", \\\"{x:1635,y:422,t:1527023309554};\\\", \\\"{x:1636,y:422,t:1527023309571};\\\", \\\"{x:1636,y:421,t:1527023309587};\\\", \\\"{x:1636,y:420,t:1527023309753};\\\", \\\"{x:1635,y:420,t:1527023309792};\\\", \\\"{x:1632,y:420,t:1527023309804};\\\", \\\"{x:1627,y:420,t:1527023309821};\\\", \\\"{x:1624,y:422,t:1527023309837};\\\", \\\"{x:1620,y:425,t:1527023310104};\\\", \\\"{x:1615,y:427,t:1527023310123};\\\", \\\"{x:1613,y:428,t:1527023310138};\\\", \\\"{x:1613,y:429,t:1527023310155};\\\", \\\"{x:1612,y:429,t:1527023315576};\\\", \\\"{x:1609,y:431,t:1527023315591};\\\", \\\"{x:1607,y:433,t:1527023315609};\\\", \\\"{x:1606,y:434,t:1527023315624};\\\", \\\"{x:1605,y:434,t:1527023315641};\\\", \\\"{x:1603,y:436,t:1527023315658};\\\", \\\"{x:1602,y:437,t:1527023315674};\\\", \\\"{x:1599,y:440,t:1527023315692};\\\", \\\"{x:1596,y:444,t:1527023315708};\\\", \\\"{x:1594,y:447,t:1527023315724};\\\", \\\"{x:1592,y:450,t:1527023315740};\\\", \\\"{x:1588,y:455,t:1527023315757};\\\", \\\"{x:1586,y:461,t:1527023315774};\\\", \\\"{x:1580,y:471,t:1527023315791};\\\", \\\"{x:1576,y:483,t:1527023315807};\\\", \\\"{x:1569,y:497,t:1527023315824};\\\", \\\"{x:1563,y:512,t:1527023315841};\\\", \\\"{x:1558,y:525,t:1527023315857};\\\", \\\"{x:1552,y:540,t:1527023315874};\\\", \\\"{x:1548,y:553,t:1527023315891};\\\", \\\"{x:1543,y:570,t:1527023315907};\\\", \\\"{x:1538,y:590,t:1527023315924};\\\", \\\"{x:1531,y:611,t:1527023315941};\\\", \\\"{x:1528,y:627,t:1527023315958};\\\", \\\"{x:1526,y:644,t:1527023315974};\\\", \\\"{x:1522,y:667,t:1527023315991};\\\", \\\"{x:1521,y:675,t:1527023316008};\\\", \\\"{x:1517,y:683,t:1527023316024};\\\", \\\"{x:1517,y:690,t:1527023316041};\\\", \\\"{x:1513,y:700,t:1527023316058};\\\", \\\"{x:1507,y:714,t:1527023316074};\\\", \\\"{x:1502,y:724,t:1527023316091};\\\", \\\"{x:1497,y:735,t:1527023316109};\\\", \\\"{x:1492,y:748,t:1527023316124};\\\", \\\"{x:1488,y:757,t:1527023316142};\\\", \\\"{x:1482,y:767,t:1527023316159};\\\", \\\"{x:1476,y:778,t:1527023316175};\\\", \\\"{x:1471,y:790,t:1527023316191};\\\", \\\"{x:1464,y:806,t:1527023316208};\\\", \\\"{x:1458,y:816,t:1527023316225};\\\", \\\"{x:1453,y:825,t:1527023316242};\\\", \\\"{x:1449,y:835,t:1527023316259};\\\", \\\"{x:1446,y:841,t:1527023316275};\\\", \\\"{x:1441,y:851,t:1527023316292};\\\", \\\"{x:1439,y:857,t:1527023316308};\\\", \\\"{x:1434,y:867,t:1527023316325};\\\", \\\"{x:1429,y:876,t:1527023316342};\\\", \\\"{x:1422,y:883,t:1527023316359};\\\", \\\"{x:1421,y:886,t:1527023316375};\\\", \\\"{x:1418,y:890,t:1527023316391};\\\", \\\"{x:1417,y:891,t:1527023316449};\\\", \\\"{x:1417,y:892,t:1527023316458};\\\", \\\"{x:1414,y:895,t:1527023316476};\\\", \\\"{x:1411,y:899,t:1527023316491};\\\", \\\"{x:1410,y:900,t:1527023316575};\\\", \\\"{x:1409,y:900,t:1527023316591};\\\", \\\"{x:1407,y:900,t:1527023316720};\\\", \\\"{x:1403,y:900,t:1527023316864};\\\", \\\"{x:1400,y:900,t:1527023316875};\\\", \\\"{x:1399,y:900,t:1527023316892};\\\", \\\"{x:1388,y:900,t:1527023316909};\\\", \\\"{x:1377,y:900,t:1527023316926};\\\", \\\"{x:1364,y:898,t:1527023316942};\\\", \\\"{x:1344,y:894,t:1527023316959};\\\", \\\"{x:1294,y:879,t:1527023316976};\\\", \\\"{x:1254,y:866,t:1527023316992};\\\", \\\"{x:1224,y:848,t:1527023317009};\\\", \\\"{x:1187,y:831,t:1527023317026};\\\", \\\"{x:1156,y:817,t:1527023317042};\\\", \\\"{x:1116,y:805,t:1527023317059};\\\", \\\"{x:1074,y:791,t:1527023317075};\\\", \\\"{x:1034,y:777,t:1527023317092};\\\", \\\"{x:986,y:762,t:1527023317108};\\\", \\\"{x:942,y:745,t:1527023317125};\\\", \\\"{x:909,y:732,t:1527023317142};\\\", \\\"{x:874,y:717,t:1527023317158};\\\", \\\"{x:828,y:703,t:1527023317175};\\\", \\\"{x:808,y:696,t:1527023317191};\\\", \\\"{x:787,y:688,t:1527023317208};\\\", \\\"{x:762,y:680,t:1527023317225};\\\", \\\"{x:731,y:671,t:1527023317242};\\\", \\\"{x:702,y:664,t:1527023317258};\\\", \\\"{x:672,y:654,t:1527023317275};\\\", \\\"{x:649,y:646,t:1527023317293};\\\", \\\"{x:632,y:637,t:1527023317309};\\\", \\\"{x:621,y:632,t:1527023317325};\\\", \\\"{x:618,y:630,t:1527023317341};\\\", \\\"{x:616,y:629,t:1527023317358};\\\", \\\"{x:615,y:628,t:1527023317383};\\\", \\\"{x:614,y:626,t:1527023317391};\\\", \\\"{x:610,y:623,t:1527023317408};\\\", \\\"{x:602,y:621,t:1527023317425};\\\", \\\"{x:593,y:616,t:1527023317441};\\\", \\\"{x:580,y:612,t:1527023317462};\\\", \\\"{x:567,y:610,t:1527023317477};\\\", \\\"{x:542,y:606,t:1527023317494};\\\", \\\"{x:507,y:602,t:1527023317511};\\\", \\\"{x:485,y:600,t:1527023317528};\\\", \\\"{x:469,y:597,t:1527023317544};\\\", \\\"{x:463,y:596,t:1527023317561};\\\", \\\"{x:459,y:595,t:1527023317577};\\\", \\\"{x:458,y:595,t:1527023317656};\\\", \\\"{x:457,y:595,t:1527023317663};\\\", \\\"{x:455,y:594,t:1527023317677};\\\", \\\"{x:453,y:593,t:1527023317694};\\\", \\\"{x:443,y:593,t:1527023317711};\\\", \\\"{x:424,y:593,t:1527023317727};\\\", \\\"{x:401,y:593,t:1527023317745};\\\", \\\"{x:382,y:593,t:1527023317762};\\\", \\\"{x:366,y:593,t:1527023317779};\\\", \\\"{x:356,y:593,t:1527023317793};\\\", \\\"{x:342,y:593,t:1527023317811};\\\", \\\"{x:326,y:593,t:1527023317828};\\\", \\\"{x:317,y:593,t:1527023317844};\\\", \\\"{x:314,y:593,t:1527023317861};\\\", \\\"{x:313,y:593,t:1527023317879};\\\", \\\"{x:312,y:593,t:1527023317894};\\\", \\\"{x:306,y:593,t:1527023317911};\\\", \\\"{x:302,y:593,t:1527023317927};\\\", \\\"{x:300,y:593,t:1527023317944};\\\", \\\"{x:301,y:593,t:1527023318017};\\\", \\\"{x:304,y:592,t:1527023318028};\\\", \\\"{x:313,y:591,t:1527023318045};\\\", \\\"{x:319,y:589,t:1527023318061};\\\", \\\"{x:324,y:588,t:1527023318078};\\\", \\\"{x:327,y:588,t:1527023318094};\\\", \\\"{x:330,y:588,t:1527023318112};\\\", \\\"{x:332,y:588,t:1527023318127};\\\", \\\"{x:337,y:587,t:1527023318144};\\\", \\\"{x:341,y:585,t:1527023318161};\\\", \\\"{x:343,y:585,t:1527023318178};\\\", \\\"{x:346,y:585,t:1527023318194};\\\", \\\"{x:348,y:585,t:1527023318211};\\\", \\\"{x:349,y:585,t:1527023318228};\\\", \\\"{x:351,y:585,t:1527023318245};\\\", \\\"{x:354,y:585,t:1527023318261};\\\", \\\"{x:358,y:585,t:1527023318279};\\\", \\\"{x:361,y:585,t:1527023318295};\\\", \\\"{x:362,y:585,t:1527023318319};\\\", \\\"{x:364,y:585,t:1527023318336};\\\", \\\"{x:364,y:586,t:1527023318345};\\\", \\\"{x:366,y:587,t:1527023318361};\\\", \\\"{x:367,y:588,t:1527023318378};\\\", \\\"{x:369,y:589,t:1527023318395};\\\", \\\"{x:370,y:589,t:1527023318411};\\\", \\\"{x:372,y:591,t:1527023318428};\\\", \\\"{x:373,y:591,t:1527023318445};\\\", \\\"{x:375,y:591,t:1527023318461};\\\", \\\"{x:376,y:591,t:1527023318478};\\\", \\\"{x:377,y:592,t:1527023318495};\\\", \\\"{x:378,y:592,t:1527023318527};\\\", \\\"{x:378,y:592,t:1527023318583};\\\", \\\"{x:378,y:593,t:1527023318639};\\\", \\\"{x:378,y:597,t:1527023318647};\\\", \\\"{x:383,y:606,t:1527023318661};\\\", \\\"{x:406,y:639,t:1527023318679};\\\", \\\"{x:436,y:684,t:1527023318696};\\\", \\\"{x:450,y:708,t:1527023318712};\\\", \\\"{x:459,y:728,t:1527023318728};\\\", \\\"{x:462,y:736,t:1527023318746};\\\", \\\"{x:465,y:740,t:1527023318762};\\\", \\\"{x:465,y:741,t:1527023318778};\\\", \\\"{x:466,y:744,t:1527023318800};\\\", \\\"{x:467,y:745,t:1527023318812};\\\", \\\"{x:470,y:746,t:1527023318828};\\\", \\\"{x:480,y:750,t:1527023318845};\\\", \\\"{x:487,y:751,t:1527023318862};\\\", \\\"{x:491,y:752,t:1527023318878};\\\", \\\"{x:493,y:752,t:1527023318896};\\\", \\\"{x:498,y:748,t:1527023318912};\\\", \\\"{x:506,y:739,t:1527023318928};\\\", \\\"{x:510,y:733,t:1527023318946};\\\", \\\"{x:514,y:728,t:1527023318962};\\\", \\\"{x:517,y:726,t:1527023318979};\\\", \\\"{x:519,y:723,t:1527023318996};\\\", \\\"{x:520,y:722,t:1527023319013};\\\", \\\"{x:520,y:720,t:1527023319029};\\\", \\\"{x:520,y:718,t:1527023319045};\\\", \\\"{x:520,y:716,t:1527023319063};\\\", \\\"{x:521,y:714,t:1527023319079};\\\", \\\"{x:522,y:713,t:1527023319480};\\\", \\\"{x:523,y:713,t:1527023319496};\\\", \\\"{x:529,y:713,t:1527023319512};\\\", \\\"{x:530,y:714,t:1527023319529};\\\", \\\"{x:531,y:714,t:1527023319546};\\\", \\\"{x:533,y:715,t:1527023319562};\\\", \\\"{x:537,y:716,t:1527023319580};\\\", \\\"{x:543,y:716,t:1527023319596};\\\", \\\"{x:553,y:716,t:1527023319612};\\\", \\\"{x:562,y:719,t:1527023319630};\\\", \\\"{x:572,y:720,t:1527023319647};\\\", \\\"{x:582,y:721,t:1527023319662};\\\", \\\"{x:592,y:723,t:1527023319679};\\\", \\\"{x:598,y:724,t:1527023319695};\\\", \\\"{x:606,y:725,t:1527023319713};\\\", \\\"{x:620,y:727,t:1527023319729};\\\", \\\"{x:635,y:728,t:1527023319747};\\\", \\\"{x:653,y:733,t:1527023319763};\\\", \\\"{x:670,y:735,t:1527023319779};\\\", \\\"{x:684,y:736,t:1527023319796};\\\", \\\"{x:701,y:739,t:1527023319813};\\\", \\\"{x:719,y:741,t:1527023319829};\\\", \\\"{x:736,y:744,t:1527023319846};\\\", \\\"{x:751,y:745,t:1527023319862};\\\", \\\"{x:772,y:749,t:1527023319880};\\\", \\\"{x:788,y:752,t:1527023319896};\\\", \\\"{x:799,y:753,t:1527023319913};\\\", \\\"{x:815,y:756,t:1527023319929};\\\", \\\"{x:830,y:759,t:1527023319946};\\\", \\\"{x:847,y:760,t:1527023319962};\\\", \\\"{x:857,y:762,t:1527023319979};\\\", \\\"{x:872,y:765,t:1527023319996};\\\", \\\"{x:885,y:766,t:1527023320012};\\\", \\\"{x:895,y:767,t:1527023320029};\\\", \\\"{x:906,y:769,t:1527023320046};\\\", \\\"{x:913,y:770,t:1527023320062};\\\", \\\"{x:919,y:770,t:1527023320079};\\\", \\\"{x:924,y:771,t:1527023320096};\\\", \\\"{x:934,y:771,t:1527023320112};\\\", \\\"{x:943,y:771,t:1527023320129};\\\", \\\"{x:954,y:773,t:1527023320146};\\\", \\\"{x:960,y:774,t:1527023320162};\\\", \\\"{x:969,y:775,t:1527023320179};\\\", \\\"{x:979,y:776,t:1527023320197};\\\", \\\"{x:989,y:777,t:1527023320213};\\\", \\\"{x:998,y:777,t:1527023320230};\\\", \\\"{x:1022,y:780,t:1527023320270};\\\", \\\"{x:1031,y:782,t:1527023320279};\\\", \\\"{x:1039,y:783,t:1527023320295};\\\", \\\"{x:1046,y:784,t:1527023320313};\\\", \\\"{x:1049,y:785,t:1527023320328};\\\", \\\"{x:1053,y:785,t:1527023320346};\\\" ] }, { \\\"rt\\\": 17515, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 7, \\\"time_elapsed\\\": 353981, \\\"internal_node_id\\\": \\\"0.0-5.0-2.0\\\", \\\"subject\\\": \\\"8LK9M\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"hotel\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 3, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-1-10 AM-11 AM-C -F \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:1076,y:788,t:1527023320470};\\\", \\\"{x:1080,y:790,t:1527023320492};\\\", \\\"{x:1083,y:790,t:1527023320503};\\\", \\\"{x:1085,y:791,t:1527023320513};\\\", \\\"{x:1089,y:793,t:1527023320530};\\\", \\\"{x:1093,y:795,t:1527023320546};\\\", \\\"{x:1107,y:800,t:1527023320571};\\\", \\\"{x:1112,y:802,t:1527023320581};\\\", \\\"{x:1127,y:805,t:1527023320596};\\\", \\\"{x:1138,y:807,t:1527023320613};\\\", \\\"{x:1145,y:809,t:1527023320630};\\\", \\\"{x:1147,y:811,t:1527023320646};\\\", \\\"{x:1151,y:810,t:1527023320663};\\\", \\\"{x:1150,y:808,t:1527023321768};\\\", \\\"{x:1123,y:796,t:1527023321780};\\\", \\\"{x:1016,y:759,t:1527023321798};\\\", \\\"{x:944,y:739,t:1527023321815};\\\", \\\"{x:848,y:705,t:1527023321832};\\\", \\\"{x:837,y:700,t:1527023321847};\\\", \\\"{x:825,y:693,t:1527023321865};\\\", \\\"{x:823,y:689,t:1527023321881};\\\", \\\"{x:819,y:688,t:1527023321898};\\\", \\\"{x:818,y:687,t:1527023321914};\\\", \\\"{x:809,y:682,t:1527023321932};\\\", \\\"{x:794,y:676,t:1527023321948};\\\", \\\"{x:779,y:666,t:1527023321965};\\\", \\\"{x:764,y:659,t:1527023321982};\\\", \\\"{x:755,y:649,t:1527023321998};\\\", \\\"{x:737,y:642,t:1527023322015};\\\", \\\"{x:711,y:627,t:1527023322033};\\\", \\\"{x:679,y:619,t:1527023322048};\\\", \\\"{x:654,y:608,t:1527023322064};\\\", \\\"{x:637,y:606,t:1527023322081};\\\", \\\"{x:630,y:603,t:1527023322098};\\\", \\\"{x:629,y:603,t:1527023322119};\\\", \\\"{x:623,y:603,t:1527023322131};\\\", \\\"{x:620,y:604,t:1527023322148};\\\", \\\"{x:616,y:604,t:1527023322164};\\\", \\\"{x:615,y:604,t:1527023322181};\\\", \\\"{x:611,y:604,t:1527023322198};\\\", \\\"{x:609,y:604,t:1527023322223};\\\", \\\"{x:607,y:603,t:1527023322231};\\\", \\\"{x:605,y:603,t:1527023322248};\\\", \\\"{x:597,y:597,t:1527023322265};\\\", \\\"{x:589,y:591,t:1527023322281};\\\", \\\"{x:579,y:584,t:1527023322298};\\\", \\\"{x:568,y:576,t:1527023322316};\\\", \\\"{x:565,y:574,t:1527023322332};\\\", \\\"{x:563,y:571,t:1527023322347};\\\", \\\"{x:561,y:569,t:1527023322364};\\\", \\\"{x:561,y:568,t:1527023322424};\\\", \\\"{x:561,y:567,t:1527023322440};\\\", \\\"{x:560,y:565,t:1527023322448};\\\", \\\"{x:559,y:563,t:1527023322464};\\\", \\\"{x:556,y:558,t:1527023322481};\\\", \\\"{x:553,y:553,t:1527023322498};\\\", \\\"{x:547,y:548,t:1527023322515};\\\", \\\"{x:541,y:542,t:1527023322532};\\\", \\\"{x:538,y:539,t:1527023322548};\\\", \\\"{x:535,y:533,t:1527023322566};\\\", \\\"{x:534,y:526,t:1527023322583};\\\", \\\"{x:533,y:521,t:1527023322598};\\\", \\\"{x:532,y:511,t:1527023322615};\\\", \\\"{x:532,y:510,t:1527023322640};\\\", \\\"{x:532,y:509,t:1527023322664};\\\", \\\"{x:532,y:508,t:1527023322672};\\\", \\\"{x:532,y:506,t:1527023322681};\\\", \\\"{x:532,y:503,t:1527023322700};\\\", \\\"{x:532,y:501,t:1527023322715};\\\", \\\"{x:532,y:499,t:1527023322731};\\\", \\\"{x:531,y:499,t:1527023322748};\\\", \\\"{x:530,y:498,t:1527023322871};\\\", \\\"{x:530,y:497,t:1527023322882};\\\", \\\"{x:530,y:495,t:1527023322899};\\\", \\\"{x:531,y:493,t:1527023322915};\\\", \\\"{x:534,y:492,t:1527023322933};\\\", \\\"{x:539,y:490,t:1527023322950};\\\", \\\"{x:542,y:487,t:1527023322966};\\\", \\\"{x:546,y:486,t:1527023322982};\\\", \\\"{x:550,y:485,t:1527023322999};\\\", \\\"{x:551,y:485,t:1527023323015};\\\", \\\"{x:552,y:485,t:1527023323033};\\\", \\\"{x:553,y:485,t:1527023323049};\\\", \\\"{x:553,y:484,t:1527023323066};\\\", \\\"{x:554,y:484,t:1527023323145};\\\", \\\"{x:555,y:484,t:1527023323152};\\\", \\\"{x:556,y:484,t:1527023323166};\\\", \\\"{x:559,y:484,t:1527023323183};\\\", \\\"{x:562,y:484,t:1527023323200};\\\", \\\"{x:566,y:484,t:1527023323216};\\\", \\\"{x:574,y:485,t:1527023323232};\\\", \\\"{x:590,y:489,t:1527023323249};\\\", \\\"{x:606,y:490,t:1527023323266};\\\", \\\"{x:621,y:493,t:1527023323283};\\\", \\\"{x:624,y:493,t:1527023323300};\\\", \\\"{x:626,y:495,t:1527023323472};\\\", \\\"{x:626,y:496,t:1527023323512};\\\", \\\"{x:627,y:497,t:1527023323520};\\\", \\\"{x:630,y:498,t:1527023323680};\\\", \\\"{x:637,y:501,t:1527023323688};\\\", \\\"{x:648,y:503,t:1527023323701};\\\", \\\"{x:689,y:515,t:1527023323717};\\\", \\\"{x:764,y:535,t:1527023323734};\\\", \\\"{x:839,y:571,t:1527023323750};\\\", \\\"{x:897,y:596,t:1527023323765};\\\", \\\"{x:916,y:608,t:1527023323782};\\\", \\\"{x:938,y:627,t:1527023323800};\\\", \\\"{x:951,y:644,t:1527023323816};\\\", \\\"{x:964,y:656,t:1527023323832};\\\", \\\"{x:984,y:667,t:1527023323849};\\\", \\\"{x:1022,y:684,t:1527023323865};\\\", \\\"{x:1039,y:701,t:1527023323882};\\\", \\\"{x:1070,y:712,t:1527023323899};\\\", \\\"{x:1087,y:717,t:1527023323917};\\\", \\\"{x:1097,y:725,t:1527023323932};\\\", \\\"{x:1105,y:730,t:1527023323950};\\\", \\\"{x:1107,y:731,t:1527023324375};\\\", \\\"{x:1109,y:735,t:1527023324382};\\\", \\\"{x:1117,y:741,t:1527023324400};\\\", \\\"{x:1132,y:746,t:1527023324416};\\\", \\\"{x:1150,y:752,t:1527023324433};\\\", \\\"{x:1174,y:757,t:1527023324449};\\\", \\\"{x:1199,y:767,t:1527023324466};\\\", \\\"{x:1225,y:774,t:1527023324483};\\\", \\\"{x:1250,y:779,t:1527023324500};\\\", \\\"{x:1272,y:786,t:1527023324517};\\\", \\\"{x:1296,y:794,t:1527023324533};\\\", \\\"{x:1317,y:801,t:1527023324550};\\\", \\\"{x:1335,y:806,t:1527023324566};\\\", \\\"{x:1364,y:816,t:1527023324584};\\\", \\\"{x:1385,y:822,t:1527023324599};\\\", \\\"{x:1395,y:824,t:1527023324617};\\\", \\\"{x:1407,y:827,t:1527023324634};\\\", \\\"{x:1412,y:829,t:1527023324650};\\\", \\\"{x:1417,y:831,t:1527023324667};\\\", \\\"{x:1423,y:834,t:1527023324684};\\\", \\\"{x:1425,y:835,t:1527023324701};\\\", \\\"{x:1425,y:836,t:1527023324717};\\\", \\\"{x:1425,y:837,t:1527023324734};\\\", \\\"{x:1427,y:839,t:1527023324751};\\\", \\\"{x:1428,y:840,t:1527023324767};\\\", \\\"{x:1428,y:841,t:1527023325248};\\\", \\\"{x:1426,y:841,t:1527023325256};\\\", \\\"{x:1424,y:840,t:1527023325268};\\\", \\\"{x:1418,y:837,t:1527023325284};\\\", \\\"{x:1409,y:835,t:1527023325302};\\\", \\\"{x:1401,y:834,t:1527023325318};\\\", \\\"{x:1389,y:832,t:1527023325335};\\\", \\\"{x:1374,y:831,t:1527023325351};\\\", \\\"{x:1338,y:825,t:1527023325368};\\\", \\\"{x:1309,y:823,t:1527023325385};\\\", \\\"{x:1279,y:823,t:1527023325401};\\\", \\\"{x:1252,y:823,t:1527023325418};\\\", \\\"{x:1227,y:823,t:1527023325434};\\\", \\\"{x:1202,y:823,t:1527023325451};\\\", \\\"{x:1179,y:823,t:1527023325468};\\\", \\\"{x:1152,y:823,t:1527023325484};\\\", \\\"{x:1132,y:823,t:1527023325500};\\\", \\\"{x:1116,y:824,t:1527023325518};\\\", \\\"{x:1102,y:827,t:1527023325534};\\\", \\\"{x:1093,y:828,t:1527023325550};\\\", \\\"{x:1087,y:832,t:1527023325567};\\\", \\\"{x:1084,y:833,t:1527023325584};\\\", \\\"{x:1079,y:837,t:1527023325600};\\\", \\\"{x:1075,y:839,t:1527023325617};\\\", \\\"{x:1073,y:840,t:1527023325635};\\\", \\\"{x:1072,y:842,t:1527023325651};\\\", \\\"{x:1069,y:845,t:1527023325668};\\\", \\\"{x:1066,y:851,t:1527023325685};\\\", \\\"{x:1063,y:859,t:1527023325702};\\\", \\\"{x:1063,y:864,t:1527023325718};\\\", \\\"{x:1061,y:871,t:1527023325735};\\\", \\\"{x:1061,y:881,t:1527023325752};\\\", \\\"{x:1061,y:887,t:1527023325768};\\\", \\\"{x:1061,y:898,t:1527023325785};\\\", \\\"{x:1061,y:907,t:1527023325803};\\\", \\\"{x:1061,y:910,t:1527023325817};\\\", \\\"{x:1060,y:913,t:1527023325835};\\\", \\\"{x:1060,y:914,t:1527023325852};\\\", \\\"{x:1060,y:915,t:1527023325937};\\\", \\\"{x:1061,y:915,t:1527023325952};\\\", \\\"{x:1062,y:915,t:1527023325968};\\\", \\\"{x:1064,y:915,t:1527023325992};\\\", \\\"{x:1065,y:914,t:1527023326032};\\\", \\\"{x:1066,y:914,t:1527023326064};\\\", \\\"{x:1067,y:914,t:1527023326075};\\\", \\\"{x:1069,y:913,t:1527023326087};\\\", \\\"{x:1071,y:912,t:1527023326103};\\\", \\\"{x:1074,y:911,t:1527023326119};\\\", \\\"{x:1078,y:908,t:1527023326135};\\\", \\\"{x:1083,y:904,t:1527023326151};\\\", \\\"{x:1086,y:902,t:1527023326223};\\\", \\\"{x:1087,y:900,t:1527023326247};\\\", \\\"{x:1088,y:899,t:1527023326312};\\\", \\\"{x:1089,y:899,t:1527023326319};\\\", \\\"{x:1090,y:899,t:1527023326335};\\\", \\\"{x:1096,y:899,t:1527023326352};\\\", \\\"{x:1101,y:898,t:1527023326369};\\\", \\\"{x:1106,y:898,t:1527023326385};\\\", \\\"{x:1108,y:897,t:1527023326402};\\\", \\\"{x:1112,y:897,t:1527023326419};\\\", \\\"{x:1113,y:897,t:1527023326448};\\\", \\\"{x:1114,y:897,t:1527023326456};\\\", \\\"{x:1116,y:897,t:1527023326481};\\\", \\\"{x:1118,y:897,t:1527023326488};\\\", \\\"{x:1125,y:900,t:1527023326502};\\\", \\\"{x:1146,y:913,t:1527023326520};\\\", \\\"{x:1153,y:917,t:1527023326536};\\\", \\\"{x:1165,y:927,t:1527023326551};\\\", \\\"{x:1177,y:935,t:1527023326569};\\\", \\\"{x:1185,y:944,t:1527023326586};\\\", \\\"{x:1189,y:947,t:1527023326602};\\\", \\\"{x:1192,y:950,t:1527023326619};\\\", \\\"{x:1195,y:954,t:1527023326636};\\\", \\\"{x:1197,y:957,t:1527023326652};\\\", \\\"{x:1198,y:958,t:1527023326669};\\\", \\\"{x:1199,y:959,t:1527023326685};\\\", \\\"{x:1199,y:960,t:1527023326703};\\\", \\\"{x:1199,y:962,t:1527023326912};\\\", \\\"{x:1199,y:963,t:1527023326936};\\\", \\\"{x:1198,y:964,t:1527023326960};\\\", \\\"{x:1197,y:965,t:1527023326977};\\\", \\\"{x:1197,y:966,t:1527023326986};\\\", \\\"{x:1200,y:970,t:1527023327003};\\\", \\\"{x:1208,y:972,t:1527023327021};\\\", \\\"{x:1217,y:978,t:1527023327036};\\\", \\\"{x:1224,y:981,t:1527023327053};\\\", \\\"{x:1233,y:985,t:1527023327070};\\\", \\\"{x:1242,y:987,t:1527023327086};\\\", \\\"{x:1247,y:988,t:1527023327103};\\\", \\\"{x:1249,y:988,t:1527023327119};\\\", \\\"{x:1250,y:988,t:1527023327136};\\\", \\\"{x:1251,y:988,t:1527023327153};\\\", \\\"{x:1252,y:988,t:1527023327176};\\\", \\\"{x:1253,y:987,t:1527023327232};\\\", \\\"{x:1254,y:987,t:1527023327256};\\\", \\\"{x:1255,y:986,t:1527023327280};\\\", \\\"{x:1256,y:985,t:1527023327296};\\\", \\\"{x:1256,y:984,t:1527023327312};\\\", \\\"{x:1257,y:983,t:1527023327328};\\\", \\\"{x:1258,y:982,t:1527023327336};\\\", \\\"{x:1259,y:981,t:1527023327353};\\\", \\\"{x:1260,y:980,t:1527023327424};\\\", \\\"{x:1260,y:978,t:1527023327436};\\\", \\\"{x:1261,y:978,t:1527023327456};\\\", \\\"{x:1261,y:977,t:1527023327471};\\\", \\\"{x:1263,y:975,t:1527023327496};\\\", \\\"{x:1263,y:974,t:1527023327520};\\\", \\\"{x:1265,y:972,t:1527023327536};\\\", \\\"{x:1266,y:971,t:1527023327553};\\\", \\\"{x:1267,y:971,t:1527023327570};\\\", \\\"{x:1268,y:970,t:1527023327633};\\\", \\\"{x:1269,y:970,t:1527023327664};\\\", \\\"{x:1269,y:969,t:1527023327695};\\\", \\\"{x:1270,y:968,t:1527023327736};\\\", \\\"{x:1271,y:967,t:1527023327767};\\\", \\\"{x:1271,y:966,t:1527023327783};\\\", \\\"{x:1272,y:966,t:1527023327807};\\\", \\\"{x:1272,y:965,t:1527023327824};\\\", \\\"{x:1273,y:964,t:1527023327848};\\\", \\\"{x:1273,y:963,t:1527023327863};\\\", \\\"{x:1273,y:962,t:1527023327872};\\\", \\\"{x:1274,y:961,t:1527023327888};\\\", \\\"{x:1274,y:960,t:1527023327903};\\\", \\\"{x:1274,y:959,t:1527023327920};\\\", \\\"{x:1274,y:958,t:1527023327937};\\\", \\\"{x:1275,y:956,t:1527023327953};\\\", \\\"{x:1276,y:955,t:1527023327984};\\\", \\\"{x:1277,y:953,t:1527023328000};\\\", \\\"{x:1277,y:952,t:1527023328120};\\\", \\\"{x:1274,y:949,t:1527023328137};\\\", \\\"{x:1266,y:946,t:1527023328157};\\\", \\\"{x:1252,y:945,t:1527023328169};\\\", \\\"{x:1246,y:944,t:1527023328187};\\\", \\\"{x:1240,y:942,t:1527023328204};\\\", \\\"{x:1233,y:940,t:1527023328220};\\\", \\\"{x:1229,y:940,t:1527023328237};\\\", \\\"{x:1225,y:940,t:1527023328253};\\\", \\\"{x:1223,y:940,t:1527023328270};\\\", \\\"{x:1222,y:940,t:1527023328295};\\\", \\\"{x:1222,y:942,t:1527023328326};\\\", \\\"{x:1222,y:944,t:1527023328336};\\\", \\\"{x:1222,y:945,t:1527023328353};\\\", \\\"{x:1222,y:947,t:1527023328371};\\\", \\\"{x:1222,y:948,t:1527023328398};\\\", \\\"{x:1220,y:949,t:1527023328599};\\\", \\\"{x:1215,y:949,t:1527023328607};\\\", \\\"{x:1201,y:947,t:1527023328620};\\\", \\\"{x:1186,y:941,t:1527023328637};\\\", \\\"{x:1170,y:935,t:1527023328654};\\\", \\\"{x:1154,y:931,t:1527023328670};\\\", \\\"{x:1151,y:930,t:1527023328686};\\\", \\\"{x:1149,y:930,t:1527023328703};\\\", \\\"{x:1148,y:929,t:1527023328808};\\\", \\\"{x:1150,y:927,t:1527023328848};\\\", \\\"{x:1155,y:923,t:1527023328856};\\\", \\\"{x:1161,y:916,t:1527023328871};\\\", \\\"{x:1169,y:905,t:1527023328887};\\\", \\\"{x:1177,y:895,t:1527023328904};\\\", \\\"{x:1183,y:884,t:1527023328921};\\\", \\\"{x:1189,y:875,t:1527023328938};\\\", \\\"{x:1192,y:870,t:1527023328954};\\\", \\\"{x:1196,y:864,t:1527023328971};\\\", \\\"{x:1202,y:853,t:1527023328988};\\\", \\\"{x:1208,y:844,t:1527023329004};\\\", \\\"{x:1213,y:837,t:1527023329021};\\\", \\\"{x:1217,y:833,t:1527023329041};\\\", \\\"{x:1218,y:828,t:1527023329054};\\\", \\\"{x:1221,y:821,t:1527023329071};\\\", \\\"{x:1221,y:819,t:1527023329087};\\\", \\\"{x:1221,y:818,t:1527023329119};\\\", \\\"{x:1221,y:817,t:1527023329167};\\\", \\\"{x:1221,y:819,t:1527023329279};\\\", \\\"{x:1221,y:820,t:1527023329288};\\\", \\\"{x:1221,y:826,t:1527023329305};\\\", \\\"{x:1221,y:831,t:1527023329320};\\\", \\\"{x:1221,y:837,t:1527023329337};\\\", \\\"{x:1221,y:841,t:1527023329354};\\\", \\\"{x:1221,y:842,t:1527023329371};\\\", \\\"{x:1221,y:846,t:1527023329388};\\\", \\\"{x:1221,y:847,t:1527023329404};\\\", \\\"{x:1221,y:849,t:1527023329421};\\\", \\\"{x:1221,y:850,t:1527023329438};\\\", \\\"{x:1222,y:852,t:1527023329454};\\\", \\\"{x:1224,y:856,t:1527023329471};\\\", \\\"{x:1224,y:858,t:1527023329488};\\\", \\\"{x:1225,y:861,t:1527023329504};\\\", \\\"{x:1226,y:864,t:1527023329522};\\\", \\\"{x:1229,y:870,t:1527023329538};\\\", \\\"{x:1233,y:877,t:1527023329555};\\\", \\\"{x:1237,y:882,t:1527023329572};\\\", \\\"{x:1241,y:889,t:1527023329588};\\\", \\\"{x:1244,y:893,t:1527023329605};\\\", \\\"{x:1246,y:896,t:1527023329622};\\\", \\\"{x:1249,y:899,t:1527023329638};\\\", \\\"{x:1252,y:902,t:1527023329655};\\\", \\\"{x:1254,y:905,t:1527023329672};\\\", \\\"{x:1256,y:906,t:1527023329688};\\\", \\\"{x:1257,y:907,t:1527023329704};\\\", \\\"{x:1258,y:908,t:1527023329722};\\\", \\\"{x:1260,y:910,t:1527023329737};\\\", \\\"{x:1261,y:911,t:1527023329754};\\\", \\\"{x:1263,y:913,t:1527023329772};\\\", \\\"{x:1265,y:917,t:1527023329788};\\\", \\\"{x:1268,y:920,t:1527023329805};\\\", \\\"{x:1269,y:922,t:1527023329821};\\\", \\\"{x:1272,y:926,t:1527023329838};\\\", \\\"{x:1274,y:932,t:1527023329855};\\\", \\\"{x:1279,y:938,t:1527023329871};\\\", \\\"{x:1280,y:940,t:1527023329889};\\\", \\\"{x:1282,y:943,t:1527023329905};\\\", \\\"{x:1284,y:944,t:1527023329922};\\\", \\\"{x:1284,y:946,t:1527023329939};\\\", \\\"{x:1286,y:948,t:1527023329955};\\\", \\\"{x:1288,y:951,t:1527023329972};\\\", \\\"{x:1291,y:955,t:1527023329989};\\\", \\\"{x:1293,y:958,t:1527023330005};\\\", \\\"{x:1297,y:960,t:1527023330022};\\\", \\\"{x:1298,y:961,t:1527023330040};\\\", \\\"{x:1300,y:962,t:1527023330055};\\\", \\\"{x:1299,y:962,t:1527023330336};\\\", \\\"{x:1299,y:963,t:1527023330344};\\\", \\\"{x:1298,y:964,t:1527023330368};\\\", \\\"{x:1297,y:964,t:1527023330399};\\\", \\\"{x:1296,y:964,t:1527023330424};\\\", \\\"{x:1295,y:964,t:1527023330439};\\\", \\\"{x:1294,y:964,t:1527023330456};\\\", \\\"{x:1293,y:964,t:1527023330480};\\\", \\\"{x:1292,y:964,t:1527023330489};\\\", \\\"{x:1291,y:964,t:1527023330506};\\\", \\\"{x:1290,y:964,t:1527023330522};\\\", \\\"{x:1288,y:964,t:1527023330776};\\\", \\\"{x:1288,y:965,t:1527023330800};\\\", \\\"{x:1287,y:966,t:1527023330840};\\\", \\\"{x:1286,y:966,t:1527023330959};\\\", \\\"{x:1285,y:966,t:1527023331425};\\\", \\\"{x:1283,y:966,t:1527023331784};\\\", \\\"{x:1282,y:966,t:1527023331825};\\\", \\\"{x:1281,y:966,t:1527023331840};\\\", \\\"{x:1279,y:965,t:1527023331880};\\\", \\\"{x:1278,y:965,t:1527023331895};\\\", \\\"{x:1277,y:965,t:1527023331920};\\\", \\\"{x:1276,y:964,t:1527023331953};\\\", \\\"{x:1275,y:963,t:1527023332431};\\\", \\\"{x:1276,y:963,t:1527023332873};\\\", \\\"{x:1277,y:963,t:1527023332912};\\\", \\\"{x:1278,y:964,t:1527023332925};\\\", \\\"{x:1279,y:964,t:1527023332968};\\\", \\\"{x:1280,y:964,t:1527023332999};\\\", \\\"{x:1281,y:962,t:1527023333376};\\\", \\\"{x:1283,y:956,t:1527023333392};\\\", \\\"{x:1283,y:955,t:1527023333408};\\\", \\\"{x:1283,y:952,t:1527023333425};\\\", \\\"{x:1284,y:951,t:1527023333443};\\\", \\\"{x:1284,y:950,t:1527023333458};\\\", \\\"{x:1284,y:949,t:1527023333475};\\\", \\\"{x:1284,y:948,t:1527023333492};\\\", \\\"{x:1284,y:946,t:1527023333508};\\\", \\\"{x:1284,y:945,t:1527023333527};\\\", \\\"{x:1284,y:944,t:1527023333541};\\\", \\\"{x:1285,y:942,t:1527023333558};\\\", \\\"{x:1285,y:940,t:1527023333575};\\\", \\\"{x:1285,y:938,t:1527023333591};\\\", \\\"{x:1286,y:934,t:1527023333608};\\\", \\\"{x:1287,y:931,t:1527023333624};\\\", \\\"{x:1289,y:928,t:1527023333642};\\\", \\\"{x:1289,y:925,t:1527023333658};\\\", \\\"{x:1290,y:921,t:1527023333675};\\\", \\\"{x:1292,y:917,t:1527023333693};\\\", \\\"{x:1296,y:909,t:1527023333709};\\\", \\\"{x:1297,y:903,t:1527023333725};\\\", \\\"{x:1299,y:897,t:1527023333742};\\\", \\\"{x:1303,y:879,t:1527023333759};\\\", \\\"{x:1306,y:870,t:1527023333775};\\\", \\\"{x:1309,y:862,t:1527023333792};\\\", \\\"{x:1311,y:858,t:1527023333809};\\\", \\\"{x:1313,y:853,t:1527023333825};\\\", \\\"{x:1315,y:848,t:1527023333842};\\\", \\\"{x:1317,y:845,t:1527023333858};\\\", \\\"{x:1318,y:840,t:1527023333875};\\\", \\\"{x:1321,y:837,t:1527023333892};\\\", \\\"{x:1323,y:833,t:1527023333909};\\\", \\\"{x:1325,y:830,t:1527023333925};\\\", \\\"{x:1326,y:828,t:1527023333942};\\\", \\\"{x:1328,y:825,t:1527023333960};\\\", \\\"{x:1329,y:823,t:1527023333975};\\\", \\\"{x:1332,y:821,t:1527023333992};\\\", \\\"{x:1335,y:817,t:1527023334009};\\\", \\\"{x:1337,y:813,t:1527023334025};\\\", \\\"{x:1340,y:809,t:1527023334042};\\\", \\\"{x:1340,y:802,t:1527023334059};\\\", \\\"{x:1343,y:798,t:1527023334077};\\\", \\\"{x:1346,y:793,t:1527023334092};\\\", \\\"{x:1348,y:790,t:1527023334109};\\\", \\\"{x:1351,y:787,t:1527023334126};\\\", \\\"{x:1351,y:786,t:1527023334142};\\\", \\\"{x:1356,y:782,t:1527023334160};\\\", \\\"{x:1358,y:780,t:1527023334176};\\\", \\\"{x:1360,y:778,t:1527023334193};\\\", \\\"{x:1361,y:776,t:1527023334210};\\\", \\\"{x:1364,y:772,t:1527023334227};\\\", \\\"{x:1365,y:772,t:1527023334242};\\\", \\\"{x:1368,y:769,t:1527023334259};\\\", \\\"{x:1371,y:766,t:1527023334277};\\\", \\\"{x:1371,y:764,t:1527023334292};\\\", \\\"{x:1373,y:762,t:1527023334309};\\\", \\\"{x:1376,y:759,t:1527023334326};\\\", \\\"{x:1379,y:756,t:1527023334343};\\\", \\\"{x:1381,y:756,t:1527023334359};\\\", \\\"{x:1381,y:755,t:1527023334472};\\\", \\\"{x:1381,y:754,t:1527023334503};\\\", \\\"{x:1381,y:753,t:1527023334512};\\\", \\\"{x:1380,y:753,t:1527023334632};\\\", \\\"{x:1378,y:753,t:1527023336304};\\\", \\\"{x:1373,y:753,t:1527023336313};\\\", \\\"{x:1357,y:752,t:1527023336327};\\\", \\\"{x:1333,y:752,t:1527023336345};\\\", \\\"{x:1297,y:752,t:1527023336361};\\\", \\\"{x:1246,y:752,t:1527023336378};\\\", \\\"{x:1198,y:751,t:1527023336394};\\\", \\\"{x:1126,y:742,t:1527023336411};\\\", \\\"{x:1067,y:732,t:1527023336429};\\\", \\\"{x:1000,y:724,t:1527023336444};\\\", \\\"{x:939,y:715,t:1527023336461};\\\", \\\"{x:877,y:703,t:1527023336479};\\\", \\\"{x:817,y:699,t:1527023336494};\\\", \\\"{x:756,y:689,t:1527023336512};\\\", \\\"{x:720,y:683,t:1527023336527};\\\", \\\"{x:684,y:679,t:1527023336544};\\\", \\\"{x:658,y:674,t:1527023336561};\\\", \\\"{x:640,y:673,t:1527023336579};\\\", \\\"{x:619,y:670,t:1527023336594};\\\", \\\"{x:590,y:664,t:1527023336611};\\\", \\\"{x:563,y:662,t:1527023336628};\\\", \\\"{x:542,y:659,t:1527023336644};\\\", \\\"{x:521,y:658,t:1527023336661};\\\", \\\"{x:504,y:658,t:1527023336678};\\\", \\\"{x:484,y:658,t:1527023336695};\\\", \\\"{x:474,y:658,t:1527023336711};\\\", \\\"{x:469,y:658,t:1527023336727};\\\", \\\"{x:467,y:658,t:1527023336745};\\\", \\\"{x:466,y:658,t:1527023336761};\\\", \\\"{x:466,y:656,t:1527023336783};\\\", \\\"{x:465,y:655,t:1527023336794};\\\", \\\"{x:462,y:650,t:1527023336811};\\\", \\\"{x:455,y:642,t:1527023336828};\\\", \\\"{x:445,y:635,t:1527023336844};\\\", \\\"{x:433,y:627,t:1527023336860};\\\", \\\"{x:419,y:616,t:1527023336876};\\\", \\\"{x:404,y:609,t:1527023336893};\\\", \\\"{x:387,y:599,t:1527023336910};\\\", \\\"{x:362,y:585,t:1527023336927};\\\", \\\"{x:354,y:581,t:1527023336943};\\\", \\\"{x:347,y:577,t:1527023336960};\\\", \\\"{x:345,y:575,t:1527023336976};\\\", \\\"{x:345,y:574,t:1527023336994};\\\", \\\"{x:345,y:573,t:1527023337010};\\\", \\\"{x:345,y:572,t:1527023337025};\\\", \\\"{x:345,y:569,t:1527023337043};\\\", \\\"{x:347,y:567,t:1527023337059};\\\", \\\"{x:347,y:566,t:1527023337075};\\\", \\\"{x:347,y:564,t:1527023337092};\\\", \\\"{x:348,y:563,t:1527023337110};\\\", \\\"{x:348,y:562,t:1527023337126};\\\", \\\"{x:352,y:561,t:1527023337142};\\\", \\\"{x:359,y:560,t:1527023337159};\\\", \\\"{x:365,y:560,t:1527023337176};\\\", \\\"{x:370,y:559,t:1527023337193};\\\", \\\"{x:373,y:559,t:1527023337209};\\\", \\\"{x:375,y:558,t:1527023337227};\\\", \\\"{x:376,y:559,t:1527023337518};\\\", \\\"{x:379,y:567,t:1527023337527};\\\", \\\"{x:385,y:587,t:1527023337544};\\\", \\\"{x:392,y:603,t:1527023337560};\\\", \\\"{x:399,y:619,t:1527023337577};\\\", \\\"{x:406,y:631,t:1527023337594};\\\", \\\"{x:410,y:638,t:1527023337609};\\\", \\\"{x:416,y:648,t:1527023337627};\\\", \\\"{x:425,y:660,t:1527023337644};\\\", \\\"{x:435,y:673,t:1527023337661};\\\", \\\"{x:448,y:684,t:1527023337676};\\\", \\\"{x:457,y:692,t:1527023337694};\\\", \\\"{x:463,y:697,t:1527023337710};\\\", \\\"{x:466,y:701,t:1527023337729};\\\", \\\"{x:468,y:703,t:1527023337743};\\\", \\\"{x:472,y:707,t:1527023337761};\\\", \\\"{x:477,y:709,t:1527023337777};\\\", \\\"{x:479,y:711,t:1527023337794};\\\", \\\"{x:482,y:712,t:1527023337811};\\\", \\\"{x:483,y:713,t:1527023337827};\\\", \\\"{x:484,y:713,t:1527023338328};\\\", \\\"{x:486,y:714,t:1527023338344};\\\", \\\"{x:487,y:714,t:1527023338375};\\\" ] }, { \\\"rt\\\": 9635, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 8, \\\"time_elapsed\\\": 364913, \\\"internal_node_id\\\": \\\"0.0-5.0-3.0\\\", \\\"subject\\\": \\\"8LK9M\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"hotel\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 4, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"H\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-01 PM-02 PM-03 PM-04 PM-H \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:488,y:713,t:1527023340663};\\\", \\\"{x:490,y:707,t:1527023340670};\\\", \\\"{x:492,y:697,t:1527023340682};\\\", \\\"{x:499,y:685,t:1527023340697};\\\", \\\"{x:505,y:671,t:1527023340713};\\\", \\\"{x:510,y:659,t:1527023340729};\\\", \\\"{x:515,y:649,t:1527023340747};\\\", \\\"{x:517,y:640,t:1527023340763};\\\", \\\"{x:520,y:626,t:1527023340779};\\\", \\\"{x:520,y:607,t:1527023340796};\\\", \\\"{x:522,y:583,t:1527023340813};\\\", \\\"{x:519,y:560,t:1527023340831};\\\", \\\"{x:518,y:545,t:1527023340846};\\\", \\\"{x:515,y:536,t:1527023340863};\\\", \\\"{x:515,y:532,t:1527023340880};\\\", \\\"{x:515,y:526,t:1527023340895};\\\", \\\"{x:514,y:521,t:1527023340913};\\\", \\\"{x:513,y:517,t:1527023340930};\\\", \\\"{x:513,y:515,t:1527023340946};\\\", \\\"{x:513,y:514,t:1527023340963};\\\", \\\"{x:513,y:513,t:1527023340980};\\\", \\\"{x:513,y:512,t:1527023341032};\\\", \\\"{x:513,y:511,t:1527023341047};\\\", \\\"{x:513,y:508,t:1527023341063};\\\", \\\"{x:513,y:507,t:1527023341080};\\\", \\\"{x:513,y:505,t:1527023341099};\\\", \\\"{x:515,y:501,t:1527023341113};\\\", \\\"{x:516,y:499,t:1527023341130};\\\", \\\"{x:517,y:498,t:1527023341183};\\\", \\\"{x:517,y:497,t:1527023341196};\\\", \\\"{x:519,y:497,t:1527023341212};\\\", \\\"{x:519,y:496,t:1527023341230};\\\", \\\"{x:520,y:496,t:1527023341246};\\\", \\\"{x:520,y:495,t:1527023341262};\\\", \\\"{x:522,y:494,t:1527023341311};\\\", \\\"{x:522,y:493,t:1527023341328};\\\", \\\"{x:523,y:493,t:1527023341335};\\\", \\\"{x:524,y:492,t:1527023341347};\\\", \\\"{x:525,y:492,t:1527023341363};\\\", \\\"{x:527,y:491,t:1527023341380};\\\", \\\"{x:528,y:490,t:1527023341397};\\\", \\\"{x:530,y:490,t:1527023341413};\\\", \\\"{x:535,y:489,t:1527023341430};\\\", \\\"{x:546,y:488,t:1527023341448};\\\", \\\"{x:559,y:486,t:1527023341463};\\\", \\\"{x:575,y:486,t:1527023341480};\\\", \\\"{x:590,y:486,t:1527023341497};\\\", \\\"{x:610,y:491,t:1527023341513};\\\", \\\"{x:637,y:500,t:1527023341530};\\\", \\\"{x:667,y:513,t:1527023341548};\\\", \\\"{x:688,y:524,t:1527023341563};\\\", \\\"{x:722,y:542,t:1527023341581};\\\", \\\"{x:770,y:568,t:1527023341598};\\\", \\\"{x:825,y:601,t:1527023341616};\\\", \\\"{x:877,y:631,t:1527023341632};\\\", \\\"{x:942,y:670,t:1527023341647};\\\", \\\"{x:978,y:691,t:1527023341664};\\\", \\\"{x:1011,y:712,t:1527023341680};\\\", \\\"{x:1042,y:732,t:1527023341697};\\\", \\\"{x:1069,y:752,t:1527023341714};\\\", \\\"{x:1098,y:770,t:1527023341730};\\\", \\\"{x:1122,y:784,t:1527023341747};\\\", \\\"{x:1152,y:801,t:1527023341765};\\\", \\\"{x:1172,y:813,t:1527023341780};\\\", \\\"{x:1187,y:820,t:1527023341797};\\\", \\\"{x:1203,y:830,t:1527023341815};\\\", \\\"{x:1218,y:839,t:1527023341831};\\\", \\\"{x:1234,y:851,t:1527023341848};\\\", \\\"{x:1239,y:854,t:1527023341864};\\\", \\\"{x:1245,y:859,t:1527023341881};\\\", \\\"{x:1253,y:867,t:1527023341898};\\\", \\\"{x:1259,y:874,t:1527023341915};\\\", \\\"{x:1264,y:881,t:1527023341931};\\\", \\\"{x:1271,y:888,t:1527023341947};\\\", \\\"{x:1279,y:898,t:1527023341965};\\\", \\\"{x:1284,y:903,t:1527023341981};\\\", \\\"{x:1288,y:907,t:1527023341997};\\\", \\\"{x:1291,y:910,t:1527023342015};\\\", \\\"{x:1294,y:913,t:1527023342031};\\\", \\\"{x:1296,y:916,t:1527023342048};\\\", \\\"{x:1297,y:918,t:1527023342064};\\\", \\\"{x:1298,y:920,t:1527023342111};\\\", \\\"{x:1298,y:921,t:1527023342120};\\\", \\\"{x:1299,y:921,t:1527023342131};\\\", \\\"{x:1305,y:929,t:1527023342148};\\\", \\\"{x:1310,y:934,t:1527023342164};\\\", \\\"{x:1318,y:939,t:1527023342181};\\\", \\\"{x:1324,y:942,t:1527023342197};\\\", \\\"{x:1331,y:945,t:1527023342215};\\\", \\\"{x:1335,y:947,t:1527023342231};\\\", \\\"{x:1343,y:951,t:1527023342247};\\\", \\\"{x:1346,y:951,t:1527023342264};\\\", \\\"{x:1347,y:951,t:1527023342281};\\\", \\\"{x:1349,y:952,t:1527023342298};\\\", \\\"{x:1351,y:953,t:1527023342315};\\\", \\\"{x:1357,y:955,t:1527023342331};\\\", \\\"{x:1363,y:957,t:1527023342348};\\\", \\\"{x:1369,y:959,t:1527023342364};\\\", \\\"{x:1374,y:960,t:1527023342381};\\\", \\\"{x:1378,y:961,t:1527023342397};\\\", \\\"{x:1386,y:963,t:1527023342416};\\\", \\\"{x:1389,y:964,t:1527023342430};\\\", \\\"{x:1402,y:967,t:1527023342448};\\\", \\\"{x:1409,y:968,t:1527023342465};\\\", \\\"{x:1414,y:970,t:1527023342481};\\\", \\\"{x:1416,y:970,t:1527023342498};\\\", \\\"{x:1417,y:970,t:1527023342514};\\\", \\\"{x:1420,y:970,t:1527023342531};\\\", \\\"{x:1421,y:970,t:1527023342547};\\\", \\\"{x:1425,y:970,t:1527023342564};\\\", \\\"{x:1428,y:971,t:1527023342580};\\\", \\\"{x:1432,y:971,t:1527023342597};\\\", \\\"{x:1435,y:972,t:1527023342614};\\\", \\\"{x:1437,y:972,t:1527023342631};\\\", \\\"{x:1441,y:972,t:1527023342647};\\\", \\\"{x:1444,y:972,t:1527023342664};\\\", \\\"{x:1448,y:972,t:1527023342680};\\\", \\\"{x:1452,y:972,t:1527023342697};\\\", \\\"{x:1458,y:972,t:1527023342714};\\\", \\\"{x:1464,y:974,t:1527023342731};\\\", \\\"{x:1472,y:974,t:1527023342748};\\\", \\\"{x:1479,y:974,t:1527023342764};\\\", \\\"{x:1486,y:974,t:1527023342780};\\\", \\\"{x:1492,y:975,t:1527023342798};\\\", \\\"{x:1500,y:976,t:1527023342814};\\\", \\\"{x:1510,y:978,t:1527023342831};\\\", \\\"{x:1525,y:978,t:1527023342847};\\\", \\\"{x:1535,y:978,t:1527023342864};\\\", \\\"{x:1541,y:978,t:1527023342881};\\\", \\\"{x:1551,y:978,t:1527023342897};\\\", \\\"{x:1560,y:978,t:1527023342914};\\\", \\\"{x:1568,y:978,t:1527023342931};\\\", \\\"{x:1573,y:978,t:1527023342948};\\\", \\\"{x:1578,y:978,t:1527023342965};\\\", \\\"{x:1580,y:978,t:1527023342981};\\\", \\\"{x:1582,y:978,t:1527023342997};\\\", \\\"{x:1586,y:978,t:1527023343014};\\\", \\\"{x:1596,y:978,t:1527023343031};\\\", \\\"{x:1602,y:978,t:1527023343047};\\\", \\\"{x:1606,y:978,t:1527023343064};\\\", \\\"{x:1609,y:978,t:1527023343082};\\\", \\\"{x:1610,y:978,t:1527023343240};\\\", \\\"{x:1612,y:978,t:1527023343248};\\\", \\\"{x:1613,y:977,t:1527023343265};\\\", \\\"{x:1615,y:976,t:1527023343282};\\\", \\\"{x:1615,y:975,t:1527023343303};\\\", \\\"{x:1616,y:975,t:1527023343328};\\\", \\\"{x:1618,y:974,t:1527023343335};\\\", \\\"{x:1619,y:972,t:1527023343348};\\\", \\\"{x:1623,y:970,t:1527023343364};\\\", \\\"{x:1628,y:967,t:1527023343382};\\\", \\\"{x:1629,y:966,t:1527023343397};\\\", \\\"{x:1630,y:966,t:1527023343415};\\\", \\\"{x:1630,y:965,t:1527023343603};\\\", \\\"{x:1630,y:963,t:1527023343619};\\\", \\\"{x:1630,y:962,t:1527023343635};\\\", \\\"{x:1630,y:961,t:1527023343651};\\\", \\\"{x:1630,y:959,t:1527023343691};\\\", \\\"{x:1630,y:958,t:1527023343701};\\\", \\\"{x:1629,y:958,t:1527023343718};\\\", \\\"{x:1627,y:954,t:1527023343735};\\\", \\\"{x:1626,y:952,t:1527023343751};\\\", \\\"{x:1625,y:952,t:1527023343768};\\\", \\\"{x:1624,y:951,t:1527023343785};\\\", \\\"{x:1622,y:948,t:1527023343801};\\\", \\\"{x:1621,y:947,t:1527023343818};\\\", \\\"{x:1618,y:945,t:1527023343834};\\\", \\\"{x:1617,y:945,t:1527023343851};\\\", \\\"{x:1617,y:944,t:1527023343868};\\\", \\\"{x:1616,y:943,t:1527023343906};\\\", \\\"{x:1615,y:942,t:1527023343939};\\\", \\\"{x:1614,y:942,t:1527023343955};\\\", \\\"{x:1614,y:941,t:1527023343988};\\\", \\\"{x:1612,y:940,t:1527023344043};\\\", \\\"{x:1611,y:940,t:1527023344051};\\\", \\\"{x:1610,y:939,t:1527023344068};\\\", \\\"{x:1608,y:938,t:1527023344085};\\\", \\\"{x:1606,y:937,t:1527023344103};\\\", \\\"{x:1605,y:935,t:1527023344119};\\\", \\\"{x:1604,y:935,t:1527023344135};\\\", \\\"{x:1601,y:932,t:1527023344152};\\\", \\\"{x:1600,y:931,t:1527023344168};\\\", \\\"{x:1598,y:928,t:1527023344185};\\\", \\\"{x:1596,y:925,t:1527023344202};\\\", \\\"{x:1593,y:923,t:1527023344219};\\\", \\\"{x:1591,y:920,t:1527023344235};\\\", \\\"{x:1591,y:918,t:1527023344253};\\\", \\\"{x:1589,y:917,t:1527023344268};\\\", \\\"{x:1588,y:915,t:1527023344285};\\\", \\\"{x:1588,y:914,t:1527023344315};\\\", \\\"{x:1587,y:914,t:1527023344339};\\\", \\\"{x:1587,y:913,t:1527023344499};\\\", \\\"{x:1587,y:911,t:1527023344515};\\\", \\\"{x:1586,y:909,t:1527023344523};\\\", \\\"{x:1585,y:909,t:1527023344535};\\\", \\\"{x:1584,y:907,t:1527023344552};\\\", \\\"{x:1582,y:903,t:1527023344568};\\\", \\\"{x:1579,y:900,t:1527023344586};\\\", \\\"{x:1576,y:895,t:1527023344603};\\\", \\\"{x:1574,y:891,t:1527023344618};\\\", \\\"{x:1573,y:888,t:1527023344635};\\\", \\\"{x:1571,y:884,t:1527023344652};\\\", \\\"{x:1571,y:879,t:1527023344668};\\\", \\\"{x:1568,y:874,t:1527023344685};\\\", \\\"{x:1566,y:867,t:1527023344703};\\\", \\\"{x:1561,y:856,t:1527023344718};\\\", \\\"{x:1556,y:847,t:1527023344735};\\\", \\\"{x:1553,y:839,t:1527023344752};\\\", \\\"{x:1549,y:833,t:1527023344768};\\\", \\\"{x:1547,y:829,t:1527023344785};\\\", \\\"{x:1545,y:824,t:1527023344802};\\\", \\\"{x:1541,y:816,t:1527023344819};\\\", \\\"{x:1534,y:803,t:1527023344835};\\\", \\\"{x:1527,y:794,t:1527023344853};\\\", \\\"{x:1521,y:785,t:1527023344868};\\\", \\\"{x:1511,y:774,t:1527023344885};\\\", \\\"{x:1500,y:758,t:1527023344902};\\\", \\\"{x:1493,y:747,t:1527023344919};\\\", \\\"{x:1485,y:735,t:1527023344935};\\\", \\\"{x:1478,y:722,t:1527023344953};\\\", \\\"{x:1470,y:713,t:1527023344968};\\\", \\\"{x:1463,y:704,t:1527023344985};\\\", \\\"{x:1461,y:702,t:1527023345003};\\\", \\\"{x:1461,y:699,t:1527023345018};\\\", \\\"{x:1458,y:693,t:1527023345034};\\\", \\\"{x:1457,y:689,t:1527023345051};\\\", \\\"{x:1454,y:685,t:1527023345067};\\\", \\\"{x:1454,y:681,t:1527023345085};\\\", \\\"{x:1452,y:676,t:1527023345102};\\\", \\\"{x:1451,y:671,t:1527023345118};\\\", \\\"{x:1447,y:662,t:1527023345134};\\\", \\\"{x:1443,y:656,t:1527023345152};\\\", \\\"{x:1435,y:643,t:1527023345168};\\\", \\\"{x:1425,y:629,t:1527023345185};\\\", \\\"{x:1416,y:615,t:1527023345202};\\\", \\\"{x:1411,y:606,t:1527023345219};\\\", \\\"{x:1409,y:599,t:1527023345235};\\\", \\\"{x:1409,y:594,t:1527023345253};\\\", \\\"{x:1408,y:588,t:1527023345269};\\\", \\\"{x:1407,y:585,t:1527023345285};\\\", \\\"{x:1407,y:581,t:1527023345302};\\\", \\\"{x:1407,y:580,t:1527023345319};\\\", \\\"{x:1407,y:578,t:1527023345335};\\\", \\\"{x:1407,y:577,t:1527023345363};\\\", \\\"{x:1407,y:576,t:1527023345412};\\\", \\\"{x:1407,y:574,t:1527023345427};\\\", \\\"{x:1407,y:572,t:1527023345443};\\\", \\\"{x:1407,y:571,t:1527023345452};\\\", \\\"{x:1408,y:570,t:1527023345469};\\\", \\\"{x:1410,y:567,t:1527023345493};\\\", \\\"{x:1411,y:564,t:1527023345518};\\\", \\\"{x:1411,y:563,t:1527023345535};\\\", \\\"{x:1411,y:561,t:1527023345551};\\\", \\\"{x:1412,y:561,t:1527023345569};\\\", \\\"{x:1407,y:565,t:1527023347661};\\\", \\\"{x:1392,y:572,t:1527023347670};\\\", \\\"{x:1358,y:586,t:1527023347687};\\\", \\\"{x:1322,y:597,t:1527023347704};\\\", \\\"{x:1281,y:606,t:1527023347719};\\\", \\\"{x:1229,y:616,t:1527023347736};\\\", \\\"{x:1154,y:629,t:1527023347753};\\\", \\\"{x:1073,y:631,t:1527023347770};\\\", \\\"{x:1019,y:631,t:1527023347786};\\\", \\\"{x:950,y:631,t:1527023347803};\\\", \\\"{x:828,y:631,t:1527023347819};\\\", \\\"{x:755,y:631,t:1527023347836};\\\", \\\"{x:696,y:634,t:1527023347854};\\\", \\\"{x:650,y:637,t:1527023347869};\\\", \\\"{x:628,y:639,t:1527023347886};\\\", \\\"{x:616,y:642,t:1527023347903};\\\", \\\"{x:610,y:642,t:1527023347915};\\\", \\\"{x:608,y:642,t:1527023347932};\\\", \\\"{x:607,y:642,t:1527023347978};\\\", \\\"{x:607,y:638,t:1527023347986};\\\", \\\"{x:607,y:633,t:1527023347999};\\\", \\\"{x:608,y:625,t:1527023348015};\\\", \\\"{x:608,y:613,t:1527023348032};\\\", \\\"{x:608,y:605,t:1527023348049};\\\", \\\"{x:608,y:592,t:1527023348072};\\\", \\\"{x:610,y:587,t:1527023348089};\\\", \\\"{x:613,y:582,t:1527023348106};\\\", \\\"{x:616,y:575,t:1527023348123};\\\", \\\"{x:617,y:571,t:1527023348140};\\\", \\\"{x:619,y:569,t:1527023348157};\\\", \\\"{x:619,y:566,t:1527023348172};\\\", \\\"{x:619,y:565,t:1527023348188};\\\", \\\"{x:619,y:564,t:1527023348206};\\\", \\\"{x:619,y:563,t:1527023348227};\\\", \\\"{x:617,y:569,t:1527023348506};\\\", \\\"{x:604,y:589,t:1527023348523};\\\", \\\"{x:591,y:614,t:1527023348539};\\\", \\\"{x:578,y:641,t:1527023348556};\\\", \\\"{x:566,y:667,t:1527023348573};\\\", \\\"{x:559,y:687,t:1527023348590};\\\", \\\"{x:555,y:695,t:1527023348605};\\\", \\\"{x:554,y:697,t:1527023348623};\\\", \\\"{x:552,y:701,t:1527023348639};\\\", \\\"{x:551,y:704,t:1527023348655};\\\", \\\"{x:549,y:708,t:1527023348673};\\\", \\\"{x:549,y:709,t:1527023348690};\\\", \\\"{x:548,y:709,t:1527023348706};\\\" ] }, { \\\"rt\\\": 56608, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 9, \\\"time_elapsed\\\": 422753, \\\"internal_node_id\\\": \\\"0.0-5.0-4.0\\\", \\\"subject\\\": \\\"8LK9M\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"hotel\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 5, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"J\\\", \\\"D\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-09 AM-I -I -I -I -7\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:549,y:705,t:1527023350658};\\\", \\\"{x:549,y:697,t:1527023350674};\\\", \\\"{x:551,y:671,t:1527023350691};\\\", \\\"{x:551,y:656,t:1527023350709};\\\", \\\"{x:551,y:642,t:1527023350724};\\\", \\\"{x:547,y:626,t:1527023350742};\\\", \\\"{x:541,y:608,t:1527023350758};\\\", \\\"{x:533,y:587,t:1527023350775};\\\", \\\"{x:525,y:565,t:1527023350790};\\\", \\\"{x:517,y:547,t:1527023350809};\\\", \\\"{x:510,y:532,t:1527023350825};\\\", \\\"{x:504,y:520,t:1527023350841};\\\", \\\"{x:490,y:501,t:1527023350859};\\\", \\\"{x:479,y:485,t:1527023350874};\\\", \\\"{x:469,y:475,t:1527023350891};\\\", \\\"{x:463,y:466,t:1527023350908};\\\", \\\"{x:459,y:462,t:1527023350925};\\\", \\\"{x:455,y:457,t:1527023350941};\\\", \\\"{x:451,y:454,t:1527023350958};\\\", \\\"{x:448,y:453,t:1527023350974};\\\", \\\"{x:443,y:449,t:1527023350991};\\\", \\\"{x:440,y:448,t:1527023351008};\\\", \\\"{x:435,y:448,t:1527023351025};\\\", \\\"{x:429,y:448,t:1527023351041};\\\", \\\"{x:422,y:448,t:1527023351058};\\\", \\\"{x:415,y:448,t:1527023351074};\\\", \\\"{x:410,y:449,t:1527023351091};\\\", \\\"{x:408,y:450,t:1527023351108};\\\", \\\"{x:406,y:451,t:1527023351125};\\\", \\\"{x:404,y:451,t:1527023351142};\\\", \\\"{x:403,y:453,t:1527023351158};\\\", \\\"{x:402,y:453,t:1527023351179};\\\", \\\"{x:401,y:453,t:1527023351323};\\\", \\\"{x:401,y:454,t:1527023351379};\\\", \\\"{x:402,y:454,t:1527023351651};\\\", \\\"{x:403,y:454,t:1527023351691};\\\", \\\"{x:407,y:454,t:1527023351708};\\\", \\\"{x:415,y:454,t:1527023351724};\\\", \\\"{x:431,y:454,t:1527023351742};\\\", \\\"{x:453,y:454,t:1527023351758};\\\", \\\"{x:478,y:454,t:1527023351775};\\\", \\\"{x:505,y:454,t:1527023351791};\\\", \\\"{x:526,y:454,t:1527023351809};\\\", \\\"{x:544,y:454,t:1527023351825};\\\", \\\"{x:561,y:454,t:1527023351842};\\\", \\\"{x:569,y:454,t:1527023351859};\\\", \\\"{x:576,y:454,t:1527023351875};\\\", \\\"{x:581,y:454,t:1527023351892};\\\", \\\"{x:587,y:454,t:1527023351909};\\\", \\\"{x:592,y:454,t:1527023351924};\\\", \\\"{x:599,y:454,t:1527023351942};\\\", \\\"{x:605,y:454,t:1527023351959};\\\", \\\"{x:612,y:454,t:1527023351975};\\\", \\\"{x:618,y:454,t:1527023351992};\\\", \\\"{x:623,y:454,t:1527023352009};\\\", \\\"{x:634,y:457,t:1527023352025};\\\", \\\"{x:642,y:458,t:1527023352041};\\\", \\\"{x:648,y:459,t:1527023352059};\\\", \\\"{x:653,y:460,t:1527023352075};\\\", \\\"{x:658,y:460,t:1527023352092};\\\", \\\"{x:659,y:461,t:1527023352109};\\\", \\\"{x:662,y:461,t:1527023352125};\\\", \\\"{x:663,y:461,t:1527023352142};\\\", \\\"{x:664,y:461,t:1527023352159};\\\", \\\"{x:665,y:462,t:1527023352194};\\\", \\\"{x:666,y:462,t:1527023352283};\\\", \\\"{x:666,y:463,t:1527023352427};\\\", \\\"{x:667,y:464,t:1527023352450};\\\", \\\"{x:668,y:464,t:1527023352459};\\\", \\\"{x:669,y:465,t:1527023352475};\\\", \\\"{x:669,y:466,t:1527023352493};\\\", \\\"{x:670,y:467,t:1527023352508};\\\", \\\"{x:670,y:468,t:1527023352526};\\\", \\\"{x:671,y:469,t:1527023352543};\\\", \\\"{x:672,y:470,t:1527023352562};\\\", \\\"{x:672,y:471,t:1527023352602};\\\", \\\"{x:672,y:472,t:1527023352618};\\\", \\\"{x:673,y:473,t:1527023352650};\\\", \\\"{x:674,y:474,t:1527023352683};\\\", \\\"{x:674,y:475,t:1527023352723};\\\", \\\"{x:674,y:475,t:1527023352893};\\\", \\\"{x:668,y:479,t:1527023354642};\\\", \\\"{x:652,y:487,t:1527023354650};\\\", \\\"{x:628,y:496,t:1527023354661};\\\", \\\"{x:601,y:501,t:1527023354677};\\\", \\\"{x:578,y:503,t:1527023354694};\\\", \\\"{x:562,y:505,t:1527023354711};\\\", \\\"{x:558,y:506,t:1527023354727};\\\", \\\"{x:559,y:506,t:1527023354915};\\\", \\\"{x:561,y:506,t:1527023354927};\\\", \\\"{x:565,y:505,t:1527023354944};\\\", \\\"{x:573,y:502,t:1527023354962};\\\", \\\"{x:583,y:501,t:1527023354978};\\\", \\\"{x:600,y:500,t:1527023354995};\\\", \\\"{x:613,y:500,t:1527023355011};\\\", \\\"{x:625,y:500,t:1527023355028};\\\", \\\"{x:636,y:500,t:1527023355044};\\\", \\\"{x:653,y:502,t:1527023355061};\\\", \\\"{x:674,y:507,t:1527023355079};\\\", \\\"{x:714,y:517,t:1527023355094};\\\", \\\"{x:771,y:527,t:1527023355113};\\\", \\\"{x:832,y:535,t:1527023355129};\\\", \\\"{x:885,y:543,t:1527023355144};\\\", \\\"{x:937,y:554,t:1527023355162};\\\", \\\"{x:1013,y:578,t:1527023355178};\\\", \\\"{x:1067,y:591,t:1527023355194};\\\", \\\"{x:1125,y:613,t:1527023355211};\\\", \\\"{x:1171,y:631,t:1527023355228};\\\", \\\"{x:1209,y:652,t:1527023355245};\\\", \\\"{x:1254,y:684,t:1527023355261};\\\", \\\"{x:1293,y:711,t:1527023355278};\\\", \\\"{x:1321,y:735,t:1527023355295};\\\", \\\"{x:1342,y:753,t:1527023355312};\\\", \\\"{x:1353,y:770,t:1527023355328};\\\", \\\"{x:1357,y:787,t:1527023355346};\\\", \\\"{x:1359,y:805,t:1527023355361};\\\", \\\"{x:1359,y:827,t:1527023355378};\\\", \\\"{x:1356,y:837,t:1527023355395};\\\", \\\"{x:1347,y:848,t:1527023355411};\\\", \\\"{x:1337,y:861,t:1527023355428};\\\", \\\"{x:1323,y:872,t:1527023355445};\\\", \\\"{x:1311,y:884,t:1527023355461};\\\", \\\"{x:1302,y:895,t:1527023355478};\\\", \\\"{x:1293,y:905,t:1527023355495};\\\", \\\"{x:1286,y:913,t:1527023355511};\\\", \\\"{x:1277,y:920,t:1527023355529};\\\", \\\"{x:1268,y:925,t:1527023355544};\\\", \\\"{x:1252,y:932,t:1527023355561};\\\", \\\"{x:1222,y:945,t:1527023355578};\\\", \\\"{x:1204,y:953,t:1527023355595};\\\", \\\"{x:1187,y:959,t:1527023355611};\\\", \\\"{x:1173,y:964,t:1527023355628};\\\", \\\"{x:1162,y:967,t:1527023355646};\\\", \\\"{x:1151,y:971,t:1527023355661};\\\", \\\"{x:1142,y:973,t:1527023355678};\\\", \\\"{x:1129,y:976,t:1527023355695};\\\", \\\"{x:1120,y:977,t:1527023355712};\\\", \\\"{x:1111,y:978,t:1527023355728};\\\", \\\"{x:1108,y:978,t:1527023355744};\\\", \\\"{x:1107,y:978,t:1527023355761};\\\", \\\"{x:1105,y:978,t:1527023355794};\\\", \\\"{x:1105,y:977,t:1527023355811};\\\", \\\"{x:1105,y:975,t:1527023355829};\\\", \\\"{x:1105,y:971,t:1527023355844};\\\", \\\"{x:1105,y:966,t:1527023355861};\\\", \\\"{x:1105,y:964,t:1527023355879};\\\", \\\"{x:1105,y:963,t:1527023355895};\\\", \\\"{x:1106,y:959,t:1527023355911};\\\", \\\"{x:1107,y:957,t:1527023355929};\\\", \\\"{x:1108,y:956,t:1527023355945};\\\", \\\"{x:1108,y:953,t:1527023355961};\\\", \\\"{x:1108,y:950,t:1527023355979};\\\", \\\"{x:1109,y:948,t:1527023355994};\\\", \\\"{x:1110,y:946,t:1527023356012};\\\", \\\"{x:1110,y:945,t:1527023356029};\\\", \\\"{x:1110,y:943,t:1527023356045};\\\", \\\"{x:1111,y:942,t:1527023356062};\\\", \\\"{x:1111,y:941,t:1527023356079};\\\", \\\"{x:1111,y:940,t:1527023356095};\\\", \\\"{x:1111,y:939,t:1527023356111};\\\", \\\"{x:1111,y:938,t:1527023356129};\\\", \\\"{x:1112,y:937,t:1527023356145};\\\", \\\"{x:1112,y:935,t:1527023356291};\\\", \\\"{x:1112,y:934,t:1527023356299};\\\", \\\"{x:1112,y:932,t:1527023356312};\\\", \\\"{x:1112,y:931,t:1527023356329};\\\", \\\"{x:1113,y:926,t:1527023356346};\\\", \\\"{x:1114,y:921,t:1527023356362};\\\", \\\"{x:1115,y:911,t:1527023356379};\\\", \\\"{x:1118,y:903,t:1527023356396};\\\", \\\"{x:1121,y:890,t:1527023356412};\\\", \\\"{x:1125,y:878,t:1527023356429};\\\", \\\"{x:1128,y:865,t:1527023356445};\\\", \\\"{x:1130,y:857,t:1527023356462};\\\", \\\"{x:1134,y:850,t:1527023356479};\\\", \\\"{x:1136,y:845,t:1527023356495};\\\", \\\"{x:1138,y:839,t:1527023356511};\\\", \\\"{x:1141,y:830,t:1527023356529};\\\", \\\"{x:1144,y:819,t:1527023356545};\\\", \\\"{x:1147,y:806,t:1527023356562};\\\", \\\"{x:1152,y:787,t:1527023356579};\\\", \\\"{x:1155,y:778,t:1527023356595};\\\", \\\"{x:1158,y:772,t:1527023356612};\\\", \\\"{x:1159,y:765,t:1527023356629};\\\", \\\"{x:1162,y:757,t:1527023356645};\\\", \\\"{x:1166,y:748,t:1527023356662};\\\", \\\"{x:1167,y:741,t:1527023356679};\\\", \\\"{x:1171,y:735,t:1527023356695};\\\", \\\"{x:1173,y:729,t:1527023356712};\\\", \\\"{x:1177,y:721,t:1527023356729};\\\", \\\"{x:1179,y:716,t:1527023356745};\\\", \\\"{x:1182,y:709,t:1527023356762};\\\", \\\"{x:1187,y:699,t:1527023356779};\\\", \\\"{x:1191,y:692,t:1527023356795};\\\", \\\"{x:1196,y:683,t:1527023356812};\\\", \\\"{x:1204,y:670,t:1527023356828};\\\", \\\"{x:1209,y:656,t:1527023356844};\\\", \\\"{x:1213,y:649,t:1527023356862};\\\", \\\"{x:1216,y:641,t:1527023356878};\\\", \\\"{x:1219,y:636,t:1527023356894};\\\", \\\"{x:1222,y:630,t:1527023356912};\\\", \\\"{x:1224,y:624,t:1527023356929};\\\", \\\"{x:1225,y:621,t:1527023356945};\\\", \\\"{x:1227,y:617,t:1527023356962};\\\", \\\"{x:1229,y:612,t:1527023356979};\\\", \\\"{x:1231,y:608,t:1527023356995};\\\", \\\"{x:1234,y:603,t:1527023357012};\\\", \\\"{x:1237,y:599,t:1527023357029};\\\", \\\"{x:1238,y:595,t:1527023357044};\\\", \\\"{x:1241,y:589,t:1527023357062};\\\", \\\"{x:1244,y:585,t:1527023357079};\\\", \\\"{x:1250,y:578,t:1527023357095};\\\", \\\"{x:1254,y:572,t:1527023357112};\\\", \\\"{x:1259,y:565,t:1527023357129};\\\", \\\"{x:1263,y:558,t:1527023357145};\\\", \\\"{x:1267,y:553,t:1527023357162};\\\", \\\"{x:1274,y:546,t:1527023357179};\\\", \\\"{x:1278,y:542,t:1527023357195};\\\", \\\"{x:1282,y:539,t:1527023357212};\\\", \\\"{x:1283,y:538,t:1527023357229};\\\", \\\"{x:1285,y:536,t:1527023357244};\\\", \\\"{x:1285,y:535,t:1527023357262};\\\", \\\"{x:1286,y:535,t:1527023357279};\\\", \\\"{x:1286,y:533,t:1527023357294};\\\", \\\"{x:1288,y:531,t:1527023357312};\\\", \\\"{x:1290,y:530,t:1527023357329};\\\", \\\"{x:1292,y:526,t:1527023357345};\\\", \\\"{x:1293,y:524,t:1527023357362};\\\", \\\"{x:1296,y:519,t:1527023357379};\\\", \\\"{x:1296,y:518,t:1527023357395};\\\", \\\"{x:1298,y:516,t:1527023357412};\\\", \\\"{x:1299,y:515,t:1527023357429};\\\", \\\"{x:1300,y:512,t:1527023357445};\\\", \\\"{x:1302,y:510,t:1527023357462};\\\", \\\"{x:1304,y:507,t:1527023357478};\\\", \\\"{x:1306,y:506,t:1527023357495};\\\", \\\"{x:1306,y:505,t:1527023357511};\\\", \\\"{x:1308,y:503,t:1527023357528};\\\", \\\"{x:1308,y:502,t:1527023357544};\\\", \\\"{x:1309,y:502,t:1527023357674};\\\", \\\"{x:1310,y:502,t:1527023357706};\\\", \\\"{x:1311,y:501,t:1527023357714};\\\", \\\"{x:1312,y:500,t:1527023357745};\\\", \\\"{x:1312,y:499,t:1527023357761};\\\", \\\"{x:1314,y:497,t:1527023357777};\\\", \\\"{x:1315,y:497,t:1527023358171};\\\", \\\"{x:1316,y:497,t:1527023358627};\\\", \\\"{x:1317,y:497,t:1527023358850};\\\", \\\"{x:1317,y:498,t:1527023358874};\\\", \\\"{x:1317,y:499,t:1527023358915};\\\", \\\"{x:1317,y:500,t:1527023358954};\\\", \\\"{x:1317,y:501,t:1527023359227};\\\", \\\"{x:1317,y:502,t:1527023359236};\\\", \\\"{x:1318,y:502,t:1527023359259};\\\", \\\"{x:1318,y:504,t:1527023359267};\\\", \\\"{x:1319,y:506,t:1527023359283};\\\", \\\"{x:1319,y:508,t:1527023359295};\\\", \\\"{x:1319,y:511,t:1527023359312};\\\", \\\"{x:1321,y:515,t:1527023359329};\\\", \\\"{x:1321,y:518,t:1527023359346};\\\", \\\"{x:1324,y:525,t:1527023359362};\\\", \\\"{x:1327,y:535,t:1527023359378};\\\", \\\"{x:1331,y:543,t:1527023359394};\\\", \\\"{x:1335,y:552,t:1527023359411};\\\", \\\"{x:1341,y:566,t:1527023359428};\\\", \\\"{x:1348,y:580,t:1527023359445};\\\", \\\"{x:1354,y:594,t:1527023359461};\\\", \\\"{x:1361,y:609,t:1527023359479};\\\", \\\"{x:1370,y:629,t:1527023359494};\\\", \\\"{x:1377,y:648,t:1527023359512};\\\", \\\"{x:1386,y:668,t:1527023359529};\\\", \\\"{x:1392,y:684,t:1527023359545};\\\", \\\"{x:1399,y:697,t:1527023359562};\\\", \\\"{x:1408,y:717,t:1527023359578};\\\", \\\"{x:1415,y:729,t:1527023359594};\\\", \\\"{x:1420,y:738,t:1527023359612};\\\", \\\"{x:1427,y:749,t:1527023359628};\\\", \\\"{x:1435,y:762,t:1527023359645};\\\", \\\"{x:1443,y:773,t:1527023359662};\\\", \\\"{x:1451,y:784,t:1527023359679};\\\", \\\"{x:1459,y:794,t:1527023359695};\\\", \\\"{x:1468,y:807,t:1527023359712};\\\", \\\"{x:1476,y:820,t:1527023359729};\\\", \\\"{x:1485,y:830,t:1527023359744};\\\", \\\"{x:1493,y:839,t:1527023359762};\\\", \\\"{x:1508,y:859,t:1527023359778};\\\", \\\"{x:1518,y:876,t:1527023359794};\\\", \\\"{x:1527,y:888,t:1527023359811};\\\", \\\"{x:1535,y:899,t:1527023359828};\\\", \\\"{x:1541,y:906,t:1527023359844};\\\", \\\"{x:1546,y:913,t:1527023359861};\\\", \\\"{x:1552,y:920,t:1527023359878};\\\", \\\"{x:1563,y:931,t:1527023359894};\\\", \\\"{x:1569,y:939,t:1527023359911};\\\", \\\"{x:1575,y:947,t:1527023359928};\\\", \\\"{x:1580,y:953,t:1527023359945};\\\", \\\"{x:1583,y:958,t:1527023359961};\\\", \\\"{x:1587,y:963,t:1527023359978};\\\", \\\"{x:1589,y:967,t:1527023359994};\\\", \\\"{x:1590,y:969,t:1527023360012};\\\", \\\"{x:1590,y:970,t:1527023360028};\\\", \\\"{x:1590,y:973,t:1527023360045};\\\", \\\"{x:1590,y:975,t:1527023360061};\\\", \\\"{x:1590,y:976,t:1527023360078};\\\", \\\"{x:1590,y:977,t:1527023360094};\\\", \\\"{x:1590,y:978,t:1527023360114};\\\", \\\"{x:1589,y:978,t:1527023360211};\\\", \\\"{x:1580,y:972,t:1527023360229};\\\", \\\"{x:1576,y:967,t:1527023360244};\\\", \\\"{x:1572,y:960,t:1527023360262};\\\", \\\"{x:1567,y:946,t:1527023360278};\\\", \\\"{x:1561,y:927,t:1527023360294};\\\", \\\"{x:1548,y:902,t:1527023360312};\\\", \\\"{x:1536,y:871,t:1527023360328};\\\", \\\"{x:1521,y:843,t:1527023360345};\\\", \\\"{x:1507,y:822,t:1527023360361};\\\", \\\"{x:1488,y:794,t:1527023360377};\\\", \\\"{x:1478,y:777,t:1527023360394};\\\", \\\"{x:1468,y:763,t:1527023360411};\\\", \\\"{x:1461,y:745,t:1527023360428};\\\", \\\"{x:1456,y:731,t:1527023360444};\\\", \\\"{x:1452,y:716,t:1527023360462};\\\", \\\"{x:1444,y:698,t:1527023360478};\\\", \\\"{x:1435,y:682,t:1527023360494};\\\", \\\"{x:1426,y:670,t:1527023360511};\\\", \\\"{x:1419,y:658,t:1527023360528};\\\", \\\"{x:1410,y:646,t:1527023360544};\\\", \\\"{x:1404,y:635,t:1527023360562};\\\", \\\"{x:1393,y:614,t:1527023360578};\\\", \\\"{x:1383,y:603,t:1527023360594};\\\", \\\"{x:1375,y:594,t:1527023360611};\\\", \\\"{x:1371,y:589,t:1527023360628};\\\", \\\"{x:1367,y:582,t:1527023360644};\\\", \\\"{x:1364,y:576,t:1527023360661};\\\", \\\"{x:1361,y:571,t:1527023360678};\\\", \\\"{x:1358,y:567,t:1527023360694};\\\", \\\"{x:1357,y:564,t:1527023360711};\\\", \\\"{x:1355,y:561,t:1527023360728};\\\", \\\"{x:1352,y:556,t:1527023360744};\\\", \\\"{x:1346,y:549,t:1527023360761};\\\", \\\"{x:1340,y:540,t:1527023360778};\\\", \\\"{x:1338,y:538,t:1527023360794};\\\", \\\"{x:1337,y:535,t:1527023360811};\\\", \\\"{x:1336,y:532,t:1527023360828};\\\", \\\"{x:1335,y:530,t:1527023360844};\\\", \\\"{x:1334,y:529,t:1527023360865};\\\", \\\"{x:1333,y:528,t:1527023360878};\\\", \\\"{x:1331,y:526,t:1527023360894};\\\", \\\"{x:1331,y:525,t:1527023360911};\\\", \\\"{x:1331,y:524,t:1527023360928};\\\", \\\"{x:1331,y:523,t:1527023360946};\\\", \\\"{x:1330,y:522,t:1527023360961};\\\", \\\"{x:1329,y:518,t:1527023360978};\\\", \\\"{x:1327,y:516,t:1527023360994};\\\", \\\"{x:1327,y:515,t:1527023361011};\\\", \\\"{x:1327,y:514,t:1527023361042};\\\", \\\"{x:1327,y:513,t:1527023361057};\\\", \\\"{x:1328,y:513,t:1527023361073};\\\", \\\"{x:1328,y:512,t:1527023361081};\\\", \\\"{x:1328,y:511,t:1527023361105};\\\", \\\"{x:1328,y:510,t:1527023361114};\\\", \\\"{x:1328,y:509,t:1527023361128};\\\", \\\"{x:1328,y:508,t:1527023361322};\\\", \\\"{x:1327,y:507,t:1527023361330};\\\", \\\"{x:1325,y:506,t:1527023361345};\\\", \\\"{x:1323,y:506,t:1527023361361};\\\", \\\"{x:1321,y:504,t:1527023361378};\\\", \\\"{x:1320,y:504,t:1527023361394};\\\", \\\"{x:1319,y:504,t:1527023361411};\\\", \\\"{x:1318,y:503,t:1527023361442};\\\", \\\"{x:1318,y:502,t:1527023361610};\\\", \\\"{x:1318,y:501,t:1527023361626};\\\", \\\"{x:1318,y:500,t:1527023361644};\\\", \\\"{x:1318,y:499,t:1527023361690};\\\", \\\"{x:1317,y:498,t:1527023361874};\\\", \\\"{x:1316,y:496,t:1527023361970};\\\", \\\"{x:1315,y:495,t:1527023362002};\\\", \\\"{x:1310,y:488,t:1527023395553};\\\", \\\"{x:1289,y:462,t:1527023395561};\\\", \\\"{x:1257,y:424,t:1527023395579};\\\", \\\"{x:1256,y:424,t:1527023396209};\\\", \\\"{x:1256,y:426,t:1527023396321};\\\", \\\"{x:1260,y:430,t:1527023396329};\\\", \\\"{x:1263,y:430,t:1527023396345};\\\", \\\"{x:1269,y:431,t:1527023396602};\\\", \\\"{x:1282,y:438,t:1527023396611};\\\", \\\"{x:1326,y:457,t:1527023396629};\\\", \\\"{x:1363,y:468,t:1527023396645};\\\", \\\"{x:1389,y:476,t:1527023396662};\\\", \\\"{x:1411,y:477,t:1527023396678};\\\", \\\"{x:1433,y:477,t:1527023396695};\\\", \\\"{x:1448,y:477,t:1527023396711};\\\", \\\"{x:1464,y:471,t:1527023396729};\\\", \\\"{x:1484,y:461,t:1527023396745};\\\", \\\"{x:1499,y:450,t:1527023396762};\\\", \\\"{x:1512,y:439,t:1527023396778};\\\", \\\"{x:1520,y:431,t:1527023396796};\\\", \\\"{x:1525,y:422,t:1527023396811};\\\", \\\"{x:1525,y:415,t:1527023396829};\\\", \\\"{x:1527,y:403,t:1527023396845};\\\", \\\"{x:1527,y:386,t:1527023396861};\\\", \\\"{x:1527,y:364,t:1527023396878};\\\", \\\"{x:1527,y:348,t:1527023396896};\\\", \\\"{x:1527,y:337,t:1527023396911};\\\", \\\"{x:1527,y:327,t:1527023396929};\\\", \\\"{x:1527,y:316,t:1527023396945};\\\", \\\"{x:1527,y:305,t:1527023396962};\\\", \\\"{x:1527,y:295,t:1527023396978};\\\", \\\"{x:1525,y:283,t:1527023396995};\\\", \\\"{x:1522,y:272,t:1527023397011};\\\", \\\"{x:1517,y:263,t:1527023397028};\\\", \\\"{x:1517,y:262,t:1527023397046};\\\", \\\"{x:1517,y:260,t:1527023397062};\\\", \\\"{x:1515,y:255,t:1527023397078};\\\", \\\"{x:1515,y:249,t:1527023397096};\\\", \\\"{x:1514,y:245,t:1527023397111};\\\", \\\"{x:1511,y:240,t:1527023397128};\\\", \\\"{x:1507,y:234,t:1527023397145};\\\", \\\"{x:1506,y:233,t:1527023397162};\\\", \\\"{x:1506,y:231,t:1527023397193};\\\", \\\"{x:1504,y:230,t:1527023397201};\\\", \\\"{x:1504,y:229,t:1527023397211};\\\", \\\"{x:1503,y:227,t:1527023397229};\\\", \\\"{x:1503,y:224,t:1527023397246};\\\", \\\"{x:1502,y:224,t:1527023397261};\\\", \\\"{x:1501,y:223,t:1527023397279};\\\", \\\"{x:1501,y:222,t:1527023397537};\\\", \\\"{x:1501,y:218,t:1527023397545};\\\", \\\"{x:1501,y:213,t:1527023397561};\\\", \\\"{x:1501,y:211,t:1527023397579};\\\", \\\"{x:1501,y:206,t:1527023397596};\\\", \\\"{x:1501,y:202,t:1527023397611};\\\", \\\"{x:1501,y:197,t:1527023397629};\\\", \\\"{x:1500,y:191,t:1527023397645};\\\", \\\"{x:1500,y:187,t:1527023397661};\\\", \\\"{x:1500,y:185,t:1527023397679};\\\", \\\"{x:1500,y:184,t:1527023397696};\\\", \\\"{x:1499,y:184,t:1527023397761};\\\", \\\"{x:1495,y:188,t:1527023397768};\\\", \\\"{x:1492,y:191,t:1527023397778};\\\", \\\"{x:1487,y:198,t:1527023397796};\\\", \\\"{x:1478,y:211,t:1527023397811};\\\", \\\"{x:1472,y:222,t:1527023397828};\\\", \\\"{x:1468,y:238,t:1527023397846};\\\", \\\"{x:1464,y:252,t:1527023397862};\\\", \\\"{x:1460,y:264,t:1527023397878};\\\", \\\"{x:1456,y:277,t:1527023397896};\\\", \\\"{x:1452,y:287,t:1527023397912};\\\", \\\"{x:1447,y:298,t:1527023397928};\\\", \\\"{x:1442,y:312,t:1527023397945};\\\", \\\"{x:1438,y:327,t:1527023397961};\\\", \\\"{x:1432,y:342,t:1527023397979};\\\", \\\"{x:1427,y:355,t:1527023397995};\\\", \\\"{x:1422,y:366,t:1527023398011};\\\", \\\"{x:1417,y:375,t:1527023398029};\\\", \\\"{x:1412,y:393,t:1527023398046};\\\", \\\"{x:1402,y:415,t:1527023398062};\\\", \\\"{x:1395,y:432,t:1527023398079};\\\", \\\"{x:1389,y:443,t:1527023398095};\\\", \\\"{x:1384,y:455,t:1527023398112};\\\", \\\"{x:1379,y:467,t:1527023398128};\\\", \\\"{x:1373,y:484,t:1527023398145};\\\", \\\"{x:1368,y:493,t:1527023398162};\\\", \\\"{x:1363,y:500,t:1527023398178};\\\", \\\"{x:1359,y:508,t:1527023398195};\\\", \\\"{x:1354,y:516,t:1527023398212};\\\", \\\"{x:1352,y:521,t:1527023398229};\\\", \\\"{x:1350,y:524,t:1527023398246};\\\", \\\"{x:1350,y:525,t:1527023398289};\\\", \\\"{x:1349,y:526,t:1527023398514};\\\", \\\"{x:1347,y:526,t:1527023398537};\\\", \\\"{x:1346,y:526,t:1527023398545};\\\", \\\"{x:1344,y:526,t:1527023398561};\\\", \\\"{x:1342,y:526,t:1527023398578};\\\", \\\"{x:1336,y:523,t:1527023398596};\\\", \\\"{x:1333,y:523,t:1527023398611};\\\", \\\"{x:1329,y:520,t:1527023398628};\\\", \\\"{x:1326,y:519,t:1527023398645};\\\", \\\"{x:1321,y:516,t:1527023398662};\\\", \\\"{x:1319,y:515,t:1527023398679};\\\", \\\"{x:1317,y:514,t:1527023398696};\\\", \\\"{x:1316,y:514,t:1527023398712};\\\", \\\"{x:1315,y:514,t:1527023398729};\\\", \\\"{x:1315,y:513,t:1527023398746};\\\", \\\"{x:1314,y:513,t:1527023398762};\\\", \\\"{x:1312,y:511,t:1527023398779};\\\", \\\"{x:1310,y:509,t:1527023398795};\\\", \\\"{x:1309,y:508,t:1527023398812};\\\", \\\"{x:1308,y:506,t:1527023398829};\\\", \\\"{x:1307,y:503,t:1527023398846};\\\", \\\"{x:1307,y:502,t:1527023398873};\\\", \\\"{x:1307,y:501,t:1527023398905};\\\", \\\"{x:1307,y:500,t:1527023399049};\\\", \\\"{x:1307,y:499,t:1527023399061};\\\", \\\"{x:1307,y:498,t:1527023399079};\\\", \\\"{x:1307,y:497,t:1527023399097};\\\", \\\"{x:1307,y:496,t:1527023399121};\\\", \\\"{x:1308,y:496,t:1527023399137};\\\", \\\"{x:1308,y:495,t:1527023399161};\\\", \\\"{x:1309,y:495,t:1527023399169};\\\", \\\"{x:1310,y:494,t:1527023399377};\\\", \\\"{x:1311,y:494,t:1527023399537};\\\", \\\"{x:1311,y:493,t:1527023399545};\\\", \\\"{x:1312,y:493,t:1527023399592};\\\", \\\"{x:1313,y:493,t:1527023399617};\\\", \\\"{x:1314,y:493,t:1527023399665};\\\", \\\"{x:1315,y:493,t:1527023399729};\\\", \\\"{x:1316,y:493,t:1527023399752};\\\", \\\"{x:1317,y:493,t:1527023399792};\\\", \\\"{x:1316,y:493,t:1527023402505};\\\", \\\"{x:1305,y:493,t:1527023402513};\\\", \\\"{x:1273,y:493,t:1527023402529};\\\", \\\"{x:1223,y:493,t:1527023402545};\\\", \\\"{x:1170,y:493,t:1527023402561};\\\", \\\"{x:1137,y:493,t:1527023402578};\\\", \\\"{x:1108,y:493,t:1527023402596};\\\", \\\"{x:1084,y:493,t:1527023402611};\\\", \\\"{x:1068,y:490,t:1527023402628};\\\", \\\"{x:1058,y:490,t:1527023402646};\\\", \\\"{x:1053,y:490,t:1527023402662};\\\", \\\"{x:1041,y:490,t:1527023402678};\\\", \\\"{x:1016,y:490,t:1527023402695};\\\", \\\"{x:985,y:490,t:1527023402712};\\\", \\\"{x:932,y:494,t:1527023402729};\\\", \\\"{x:890,y:501,t:1527023402745};\\\", \\\"{x:840,y:507,t:1527023402762};\\\", \\\"{x:800,y:520,t:1527023402779};\\\", \\\"{x:759,y:530,t:1527023402796};\\\", \\\"{x:713,y:545,t:1527023402816};\\\", \\\"{x:615,y:576,t:1527023402833};\\\", \\\"{x:557,y:593,t:1527023402850};\\\", \\\"{x:500,y:611,t:1527023402866};\\\", \\\"{x:441,y:630,t:1527023402883};\\\", \\\"{x:383,y:644,t:1527023402900};\\\", \\\"{x:360,y:656,t:1527023402916};\\\", \\\"{x:345,y:661,t:1527023402933};\\\", \\\"{x:324,y:662,t:1527023402950};\\\", \\\"{x:310,y:662,t:1527023402965};\\\", \\\"{x:308,y:662,t:1527023402982};\\\", \\\"{x:308,y:661,t:1527023403049};\\\", \\\"{x:311,y:658,t:1527023403057};\\\", \\\"{x:315,y:654,t:1527023403067};\\\", \\\"{x:324,y:645,t:1527023403082};\\\", \\\"{x:329,y:640,t:1527023403100};\\\", \\\"{x:336,y:633,t:1527023403117};\\\", \\\"{x:342,y:624,t:1527023403134};\\\", \\\"{x:347,y:616,t:1527023403149};\\\", \\\"{x:351,y:611,t:1527023403167};\\\", \\\"{x:351,y:610,t:1527023403183};\\\", \\\"{x:352,y:609,t:1527023403199};\\\", \\\"{x:353,y:608,t:1527023403216};\\\", \\\"{x:355,y:607,t:1527023403497};\\\", \\\"{x:357,y:607,t:1527023403505};\\\", \\\"{x:359,y:606,t:1527023403521};\\\", \\\"{x:362,y:604,t:1527023403538};\\\", \\\"{x:368,y:603,t:1527023403554};\\\", \\\"{x:375,y:599,t:1527023403571};\\\", \\\"{x:378,y:598,t:1527023403588};\\\", \\\"{x:382,y:595,t:1527023403604};\\\", \\\"{x:385,y:593,t:1527023403621};\\\", \\\"{x:386,y:590,t:1527023403638};\\\", \\\"{x:388,y:588,t:1527023403654};\\\", \\\"{x:389,y:586,t:1527023403671};\\\", \\\"{x:389,y:584,t:1527023403688};\\\", \\\"{x:391,y:582,t:1527023403704};\\\", \\\"{x:393,y:578,t:1527023403721};\\\", \\\"{x:396,y:575,t:1527023403738};\\\", \\\"{x:398,y:574,t:1527023403754};\\\", \\\"{x:399,y:573,t:1527023403771};\\\", \\\"{x:401,y:572,t:1527023403788};\\\", \\\"{x:402,y:571,t:1527023403803};\\\", \\\"{x:403,y:571,t:1527023403820};\\\", \\\"{x:401,y:571,t:1527023403941};\\\", \\\"{x:399,y:572,t:1527023403954};\\\", \\\"{x:388,y:579,t:1527023403971};\\\", \\\"{x:376,y:586,t:1527023403988};\\\", \\\"{x:355,y:596,t:1527023404006};\\\", \\\"{x:337,y:600,t:1527023404021};\\\", \\\"{x:317,y:604,t:1527023404038};\\\", \\\"{x:297,y:605,t:1527023404054};\\\", \\\"{x:274,y:605,t:1527023404070};\\\", \\\"{x:252,y:605,t:1527023404089};\\\", \\\"{x:233,y:605,t:1527023404105};\\\", \\\"{x:218,y:605,t:1527023404121};\\\", \\\"{x:209,y:605,t:1527023404137};\\\", \\\"{x:206,y:605,t:1527023404155};\\\", \\\"{x:205,y:605,t:1527023404269};\\\", \\\"{x:211,y:603,t:1527023404277};\\\", \\\"{x:223,y:600,t:1527023404287};\\\", \\\"{x:256,y:598,t:1527023404305};\\\", \\\"{x:318,y:586,t:1527023404321};\\\", \\\"{x:381,y:570,t:1527023404338};\\\", \\\"{x:448,y:553,t:1527023404355};\\\", \\\"{x:482,y:541,t:1527023404373};\\\", \\\"{x:515,y:534,t:1527023404389};\\\", \\\"{x:562,y:530,t:1527023404404};\\\", \\\"{x:587,y:529,t:1527023404422};\\\", \\\"{x:614,y:529,t:1527023404438};\\\", \\\"{x:635,y:529,t:1527023404455};\\\", \\\"{x:647,y:530,t:1527023404473};\\\", \\\"{x:657,y:532,t:1527023404488};\\\", \\\"{x:674,y:535,t:1527023404505};\\\", \\\"{x:693,y:537,t:1527023404522};\\\", \\\"{x:714,y:541,t:1527023404538};\\\", \\\"{x:734,y:543,t:1527023404556};\\\", \\\"{x:752,y:548,t:1527023404572};\\\", \\\"{x:767,y:554,t:1527023404588};\\\", \\\"{x:775,y:556,t:1527023404605};\\\", \\\"{x:776,y:557,t:1527023404622};\\\", \\\"{x:781,y:560,t:1527023404638};\\\", \\\"{x:785,y:564,t:1527023404655};\\\", \\\"{x:789,y:568,t:1527023404672};\\\", \\\"{x:793,y:568,t:1527023404688};\\\", \\\"{x:794,y:569,t:1527023404705};\\\", \\\"{x:795,y:569,t:1527023404722};\\\", \\\"{x:795,y:570,t:1527023404738};\\\", \\\"{x:796,y:571,t:1527023404755};\\\", \\\"{x:797,y:571,t:1527023404781};\\\", \\\"{x:798,y:571,t:1527023404796};\\\", \\\"{x:799,y:571,t:1527023404813};\\\", \\\"{x:801,y:571,t:1527023404837};\\\", \\\"{x:802,y:571,t:1527023404844};\\\", \\\"{x:803,y:571,t:1527023404855};\\\", \\\"{x:808,y:571,t:1527023404872};\\\", \\\"{x:813,y:571,t:1527023404888};\\\", \\\"{x:818,y:571,t:1527023404905};\\\", \\\"{x:824,y:571,t:1527023404921};\\\", \\\"{x:830,y:571,t:1527023404938};\\\", \\\"{x:835,y:571,t:1527023404955};\\\", \\\"{x:836,y:571,t:1527023404972};\\\", \\\"{x:837,y:571,t:1527023404989};\\\", \\\"{x:837,y:571,t:1527023405030};\\\", \\\"{x:837,y:573,t:1527023405181};\\\", \\\"{x:837,y:577,t:1527023405189};\\\", \\\"{x:837,y:587,t:1527023405205};\\\", \\\"{x:837,y:593,t:1527023405223};\\\", \\\"{x:837,y:598,t:1527023405239};\\\", \\\"{x:837,y:602,t:1527023405256};\\\", \\\"{x:837,y:608,t:1527023405272};\\\", \\\"{x:837,y:612,t:1527023405289};\\\", \\\"{x:837,y:614,t:1527023405306};\\\", \\\"{x:838,y:615,t:1527023405322};\\\", \\\"{x:838,y:616,t:1527023405339};\\\", \\\"{x:839,y:617,t:1527023405429};\\\", \\\"{x:836,y:621,t:1527023405589};\\\", \\\"{x:823,y:640,t:1527023405606};\\\", \\\"{x:805,y:657,t:1527023405622};\\\", \\\"{x:781,y:675,t:1527023405639};\\\", \\\"{x:758,y:691,t:1527023405656};\\\", \\\"{x:733,y:705,t:1527023405672};\\\", \\\"{x:711,y:715,t:1527023405689};\\\", \\\"{x:696,y:725,t:1527023405706};\\\", \\\"{x:680,y:737,t:1527023405723};\\\", \\\"{x:665,y:751,t:1527023405739};\\\", \\\"{x:654,y:759,t:1527023405756};\\\", \\\"{x:641,y:774,t:1527023405773};\\\", \\\"{x:640,y:775,t:1527023405789};\\\", \\\"{x:635,y:775,t:1527023406013};\\\", \\\"{x:633,y:775,t:1527023406023};\\\", \\\"{x:617,y:774,t:1527023406039};\\\", \\\"{x:601,y:769,t:1527023406056};\\\", \\\"{x:596,y:768,t:1527023406073};\\\", \\\"{x:595,y:767,t:1527023406089};\\\", \\\"{x:595,y:766,t:1527023406125};\\\", \\\"{x:595,y:765,t:1527023406140};\\\", \\\"{x:595,y:764,t:1527023406156};\\\", \\\"{x:595,y:761,t:1527023406173};\\\", \\\"{x:595,y:759,t:1527023406190};\\\", \\\"{x:595,y:758,t:1527023406206};\\\", \\\"{x:593,y:756,t:1527023406223};\\\", \\\"{x:591,y:753,t:1527023406240};\\\", \\\"{x:588,y:750,t:1527023406256};\\\", \\\"{x:585,y:747,t:1527023406273};\\\", \\\"{x:582,y:745,t:1527023406290};\\\", \\\"{x:578,y:743,t:1527023406306};\\\", \\\"{x:576,y:743,t:1527023406323};\\\", \\\"{x:575,y:743,t:1527023406364};\\\", \\\"{x:574,y:742,t:1527023406372};\\\", \\\"{x:573,y:741,t:1527023406390};\\\", \\\"{x:573,y:740,t:1527023406406};\\\", \\\"{x:572,y:740,t:1527023406423};\\\", \\\"{x:571,y:740,t:1527023406440};\\\", \\\"{x:570,y:740,t:1527023406456};\\\", \\\"{x:567,y:738,t:1527023406473};\\\", \\\"{x:562,y:736,t:1527023406490};\\\", \\\"{x:554,y:732,t:1527023406506};\\\", \\\"{x:546,y:729,t:1527023406523};\\\", \\\"{x:538,y:725,t:1527023406540};\\\", \\\"{x:535,y:724,t:1527023406557};\\\", \\\"{x:533,y:724,t:1527023406573};\\\" ] }, { \\\"rt\\\": 10554, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 10, \\\"time_elapsed\\\": 434528, \\\"internal_node_id\\\": \\\"0.0-6.0-0.0\\\", \\\"subject\\\": \\\"8LK9M\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"hotel\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration\\\", \\\"q\\\": 6, \\\"clicks\\\": 2.5, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\", \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-6-E \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:536,y:651,t:1527023408465};\\\", \\\"{x:536,y:634,t:1527023408475};\\\", \\\"{x:536,y:602,t:1527023408491};\\\", \\\"{x:532,y:574,t:1527023408509};\\\", \\\"{x:524,y:544,t:1527023408526};\\\", \\\"{x:524,y:530,t:1527023408541};\\\", \\\"{x:524,y:517,t:1527023408559};\\\", \\\"{x:524,y:505,t:1527023408575};\\\", \\\"{x:524,y:495,t:1527023408591};\\\", \\\"{x:524,y:492,t:1527023408608};\\\", \\\"{x:524,y:490,t:1527023408626};\\\", \\\"{x:524,y:489,t:1527023408642};\\\", \\\"{x:524,y:487,t:1527023408757};\\\", \\\"{x:524,y:486,t:1527023408766};\\\", \\\"{x:524,y:485,t:1527023408775};\\\", \\\"{x:524,y:480,t:1527023408792};\\\", \\\"{x:526,y:471,t:1527023408808};\\\", \\\"{x:528,y:465,t:1527023408825};\\\", \\\"{x:530,y:459,t:1527023408842};\\\", \\\"{x:532,y:454,t:1527023408858};\\\", \\\"{x:533,y:451,t:1527023408875};\\\", \\\"{x:533,y:450,t:1527023408892};\\\", \\\"{x:534,y:448,t:1527023409237};\\\", \\\"{x:536,y:448,t:1527023409245};\\\", \\\"{x:538,y:448,t:1527023409259};\\\", \\\"{x:549,y:447,t:1527023409275};\\\", \\\"{x:565,y:447,t:1527023409292};\\\", \\\"{x:588,y:447,t:1527023409308};\\\", \\\"{x:602,y:447,t:1527023409325};\\\", \\\"{x:608,y:447,t:1527023409342};\\\", \\\"{x:613,y:447,t:1527023409360};\\\", \\\"{x:614,y:447,t:1527023409375};\\\", \\\"{x:615,y:447,t:1527023409469};\\\", \\\"{x:616,y:447,t:1527023409477};\\\", \\\"{x:618,y:447,t:1527023409492};\\\", \\\"{x:621,y:447,t:1527023409509};\\\", \\\"{x:627,y:447,t:1527023409525};\\\", \\\"{x:636,y:447,t:1527023409542};\\\", \\\"{x:648,y:447,t:1527023409559};\\\", \\\"{x:669,y:447,t:1527023409576};\\\", \\\"{x:696,y:447,t:1527023409592};\\\", \\\"{x:729,y:447,t:1527023409609};\\\", \\\"{x:773,y:450,t:1527023409626};\\\", \\\"{x:812,y:456,t:1527023409643};\\\", \\\"{x:838,y:458,t:1527023409659};\\\", \\\"{x:861,y:463,t:1527023409676};\\\", \\\"{x:883,y:470,t:1527023409692};\\\", \\\"{x:915,y:481,t:1527023409709};\\\", \\\"{x:937,y:490,t:1527023409726};\\\", \\\"{x:955,y:498,t:1527023409743};\\\", \\\"{x:971,y:506,t:1527023409760};\\\", \\\"{x:987,y:513,t:1527023409777};\\\", \\\"{x:1004,y:523,t:1527023409792};\\\", \\\"{x:1017,y:530,t:1527023409809};\\\", \\\"{x:1027,y:538,t:1527023409826};\\\", \\\"{x:1042,y:548,t:1527023409843};\\\", \\\"{x:1056,y:558,t:1527023409859};\\\", \\\"{x:1068,y:564,t:1527023409876};\\\", \\\"{x:1079,y:570,t:1527023409893};\\\", \\\"{x:1089,y:574,t:1527023409909};\\\", \\\"{x:1098,y:579,t:1527023409926};\\\", \\\"{x:1111,y:584,t:1527023409942};\\\", \\\"{x:1123,y:589,t:1527023409959};\\\", \\\"{x:1131,y:590,t:1527023409976};\\\", \\\"{x:1140,y:592,t:1527023409992};\\\", \\\"{x:1149,y:592,t:1527023410009};\\\", \\\"{x:1156,y:592,t:1527023410026};\\\", \\\"{x:1162,y:592,t:1527023410042};\\\", \\\"{x:1168,y:592,t:1527023410059};\\\", \\\"{x:1172,y:592,t:1527023410076};\\\", \\\"{x:1174,y:592,t:1527023410092};\\\", \\\"{x:1178,y:590,t:1527023410109};\\\", \\\"{x:1181,y:589,t:1527023410126};\\\", \\\"{x:1183,y:588,t:1527023410144};\\\", \\\"{x:1188,y:585,t:1527023410160};\\\", \\\"{x:1193,y:582,t:1527023410177};\\\", \\\"{x:1196,y:579,t:1527023410193};\\\", \\\"{x:1201,y:576,t:1527023410209};\\\", \\\"{x:1207,y:573,t:1527023410226};\\\", \\\"{x:1212,y:568,t:1527023410243};\\\", \\\"{x:1218,y:563,t:1527023410260};\\\", \\\"{x:1224,y:558,t:1527023410276};\\\", \\\"{x:1229,y:554,t:1527023410293};\\\", \\\"{x:1232,y:554,t:1527023410541};\\\", \\\"{x:1235,y:553,t:1527023410549};\\\", \\\"{x:1236,y:553,t:1527023410559};\\\", \\\"{x:1237,y:553,t:1527023410629};\\\", \\\"{x:1238,y:553,t:1527023410653};\\\", \\\"{x:1239,y:553,t:1527023410660};\\\", \\\"{x:1241,y:553,t:1527023410677};\\\", \\\"{x:1246,y:553,t:1527023410692};\\\", \\\"{x:1250,y:553,t:1527023410711};\\\", \\\"{x:1253,y:553,t:1527023410727};\\\", \\\"{x:1255,y:553,t:1527023410743};\\\", \\\"{x:1256,y:553,t:1527023410760};\\\", \\\"{x:1257,y:553,t:1527023410781};\\\", \\\"{x:1259,y:554,t:1527023410794};\\\", \\\"{x:1262,y:555,t:1527023410810};\\\", \\\"{x:1264,y:556,t:1527023410827};\\\", \\\"{x:1265,y:556,t:1527023410843};\\\", \\\"{x:1266,y:556,t:1527023410861};\\\", \\\"{x:1267,y:556,t:1527023410876};\\\", \\\"{x:1268,y:556,t:1527023410893};\\\", \\\"{x:1269,y:556,t:1527023410911};\\\", \\\"{x:1271,y:556,t:1527023410926};\\\", \\\"{x:1274,y:557,t:1527023410943};\\\", \\\"{x:1277,y:557,t:1527023410960};\\\", \\\"{x:1279,y:557,t:1527023410976};\\\", \\\"{x:1282,y:557,t:1527023410993};\\\", \\\"{x:1286,y:557,t:1527023411011};\\\", \\\"{x:1291,y:557,t:1527023411026};\\\", \\\"{x:1295,y:557,t:1527023411043};\\\", \\\"{x:1300,y:557,t:1527023411060};\\\", \\\"{x:1303,y:557,t:1527023411077};\\\", \\\"{x:1310,y:558,t:1527023411093};\\\", \\\"{x:1317,y:558,t:1527023411110};\\\", \\\"{x:1323,y:561,t:1527023411127};\\\", \\\"{x:1332,y:562,t:1527023411143};\\\", \\\"{x:1339,y:562,t:1527023411160};\\\", \\\"{x:1344,y:562,t:1527023411177};\\\", \\\"{x:1351,y:564,t:1527023411194};\\\", \\\"{x:1358,y:565,t:1527023411210};\\\", \\\"{x:1366,y:567,t:1527023411227};\\\", \\\"{x:1376,y:570,t:1527023411244};\\\", \\\"{x:1388,y:571,t:1527023411261};\\\", \\\"{x:1401,y:573,t:1527023411277};\\\", \\\"{x:1408,y:573,t:1527023411294};\\\", \\\"{x:1413,y:573,t:1527023411310};\\\", \\\"{x:1415,y:573,t:1527023411328};\\\", \\\"{x:1416,y:573,t:1527023411389};\\\", \\\"{x:1417,y:573,t:1527023411405};\\\", \\\"{x:1416,y:574,t:1527023411517};\\\", \\\"{x:1408,y:576,t:1527023411527};\\\", \\\"{x:1379,y:586,t:1527023411543};\\\", \\\"{x:1346,y:593,t:1527023411561};\\\", \\\"{x:1306,y:602,t:1527023411578};\\\", \\\"{x:1251,y:613,t:1527023411594};\\\", \\\"{x:1196,y:618,t:1527023411611};\\\", \\\"{x:1149,y:625,t:1527023411627};\\\", \\\"{x:1121,y:630,t:1527023411644};\\\", \\\"{x:1105,y:635,t:1527023411661};\\\", \\\"{x:1079,y:637,t:1527023411677};\\\", \\\"{x:1061,y:640,t:1527023411694};\\\", \\\"{x:1037,y:645,t:1527023411710};\\\", \\\"{x:1006,y:650,t:1527023411727};\\\", \\\"{x:979,y:653,t:1527023411744};\\\", \\\"{x:943,y:658,t:1527023411761};\\\", \\\"{x:895,y:659,t:1527023411777};\\\", \\\"{x:830,y:661,t:1527023411794};\\\", \\\"{x:752,y:661,t:1527023411810};\\\", \\\"{x:683,y:661,t:1527023411828};\\\", \\\"{x:618,y:660,t:1527023411845};\\\", \\\"{x:588,y:656,t:1527023411860};\\\", \\\"{x:542,y:644,t:1527023411877};\\\", \\\"{x:517,y:639,t:1527023411894};\\\", \\\"{x:503,y:636,t:1527023411911};\\\", \\\"{x:497,y:632,t:1527023411927};\\\", \\\"{x:494,y:631,t:1527023411944};\\\", \\\"{x:493,y:631,t:1527023411961};\\\", \\\"{x:492,y:631,t:1527023412037};\\\", \\\"{x:491,y:631,t:1527023412045};\\\", \\\"{x:486,y:630,t:1527023412061};\\\", \\\"{x:486,y:629,t:1527023412077};\\\", \\\"{x:484,y:629,t:1527023412109};\\\", \\\"{x:483,y:627,t:1527023412133};\\\", \\\"{x:481,y:626,t:1527023412145};\\\", \\\"{x:475,y:625,t:1527023412161};\\\", \\\"{x:472,y:624,t:1527023412177};\\\", \\\"{x:469,y:623,t:1527023412194};\\\", \\\"{x:461,y:623,t:1527023412212};\\\", \\\"{x:455,y:622,t:1527023412227};\\\", \\\"{x:453,y:622,t:1527023412244};\\\", \\\"{x:452,y:621,t:1527023412285};\\\", \\\"{x:452,y:620,t:1527023412341};\\\", \\\"{x:452,y:619,t:1527023412397};\\\", \\\"{x:451,y:619,t:1527023412411};\\\", \\\"{x:450,y:617,t:1527023412427};\\\", \\\"{x:448,y:617,t:1527023412837};\\\", \\\"{x:447,y:617,t:1527023412845};\\\", \\\"{x:444,y:616,t:1527023412862};\\\", \\\"{x:443,y:616,t:1527023412879};\\\", \\\"{x:440,y:616,t:1527023412894};\\\", \\\"{x:436,y:615,t:1527023412911};\\\", \\\"{x:435,y:615,t:1527023412929};\\\", \\\"{x:433,y:615,t:1527023412944};\\\", \\\"{x:430,y:613,t:1527023412961};\\\", \\\"{x:429,y:613,t:1527023412989};\\\", \\\"{x:428,y:613,t:1527023413013};\\\", \\\"{x:426,y:612,t:1527023413028};\\\", \\\"{x:425,y:611,t:1527023413045};\\\", \\\"{x:424,y:610,t:1527023413061};\\\", \\\"{x:423,y:606,t:1527023413078};\\\", \\\"{x:420,y:602,t:1527023413096};\\\", \\\"{x:419,y:599,t:1527023413112};\\\", \\\"{x:416,y:596,t:1527023413129};\\\", \\\"{x:413,y:593,t:1527023413146};\\\", \\\"{x:412,y:592,t:1527023413162};\\\", \\\"{x:410,y:590,t:1527023413178};\\\", \\\"{x:407,y:586,t:1527023413196};\\\", \\\"{x:403,y:582,t:1527023413212};\\\", \\\"{x:401,y:580,t:1527023413229};\\\", \\\"{x:397,y:577,t:1527023413245};\\\", \\\"{x:395,y:576,t:1527023413263};\\\", \\\"{x:392,y:573,t:1527023413279};\\\", \\\"{x:388,y:571,t:1527023413296};\\\", \\\"{x:384,y:567,t:1527023413313};\\\", \\\"{x:379,y:566,t:1527023413328};\\\", \\\"{x:376,y:562,t:1527023413345};\\\", \\\"{x:375,y:561,t:1527023413362};\\\", \\\"{x:375,y:560,t:1527023413378};\\\", \\\"{x:375,y:558,t:1527023413395};\\\", \\\"{x:375,y:557,t:1527023413412};\\\", \\\"{x:375,y:554,t:1527023413429};\\\", \\\"{x:376,y:551,t:1527023413446};\\\", \\\"{x:378,y:545,t:1527023413463};\\\", \\\"{x:378,y:541,t:1527023413479};\\\", \\\"{x:379,y:537,t:1527023413495};\\\", \\\"{x:379,y:536,t:1527023413517};\\\", \\\"{x:381,y:536,t:1527023413533};\\\", \\\"{x:384,y:536,t:1527023413545};\\\", \\\"{x:393,y:532,t:1527023413563};\\\", \\\"{x:409,y:528,t:1527023413579};\\\", \\\"{x:428,y:522,t:1527023413595};\\\", \\\"{x:452,y:520,t:1527023413613};\\\", \\\"{x:489,y:513,t:1527023413629};\\\", \\\"{x:518,y:509,t:1527023413646};\\\", \\\"{x:545,y:507,t:1527023413662};\\\", \\\"{x:559,y:507,t:1527023413679};\\\", \\\"{x:568,y:507,t:1527023413695};\\\", \\\"{x:572,y:506,t:1527023413713};\\\", \\\"{x:573,y:506,t:1527023413973};\\\", \\\"{x:576,y:506,t:1527023413981};\\\", \\\"{x:577,y:506,t:1527023413997};\\\", \\\"{x:580,y:505,t:1527023414013};\\\", \\\"{x:585,y:505,t:1527023414029};\\\", \\\"{x:586,y:505,t:1527023414046};\\\", \\\"{x:587,y:505,t:1527023414063};\\\", \\\"{x:588,y:505,t:1527023414429};\\\", \\\"{x:590,y:505,t:1527023414436};\\\", \\\"{x:594,y:505,t:1527023414446};\\\", \\\"{x:604,y:505,t:1527023414463};\\\", \\\"{x:608,y:508,t:1527023414480};\\\", \\\"{x:611,y:509,t:1527023414496};\\\", \\\"{x:616,y:512,t:1527023414512};\\\", \\\"{x:618,y:515,t:1527023414530};\\\", \\\"{x:620,y:515,t:1527023414547};\\\", \\\"{x:622,y:518,t:1527023414564};\\\", \\\"{x:623,y:519,t:1527023414579};\\\", \\\"{x:626,y:522,t:1527023414596};\\\", \\\"{x:629,y:526,t:1527023414613};\\\", \\\"{x:632,y:530,t:1527023414630};\\\", \\\"{x:641,y:536,t:1527023414647};\\\", \\\"{x:653,y:541,t:1527023414664};\\\", \\\"{x:665,y:545,t:1527023414679};\\\", \\\"{x:675,y:547,t:1527023414696};\\\", \\\"{x:680,y:547,t:1527023414714};\\\", \\\"{x:683,y:547,t:1527023414730};\\\", \\\"{x:687,y:547,t:1527023414746};\\\", \\\"{x:691,y:547,t:1527023414764};\\\", \\\"{x:698,y:546,t:1527023414780};\\\", \\\"{x:700,y:546,t:1527023414796};\\\", \\\"{x:702,y:545,t:1527023414813};\\\", \\\"{x:702,y:544,t:1527023414837};\\\", \\\"{x:700,y:544,t:1527023414917};\\\", \\\"{x:693,y:544,t:1527023414930};\\\", \\\"{x:679,y:540,t:1527023414947};\\\", \\\"{x:662,y:539,t:1527023414963};\\\", \\\"{x:650,y:535,t:1527023414980};\\\", \\\"{x:643,y:532,t:1527023414996};\\\", \\\"{x:635,y:530,t:1527023415014};\\\", \\\"{x:631,y:529,t:1527023415031};\\\", \\\"{x:630,y:528,t:1527023415052};\\\", \\\"{x:628,y:528,t:1527023415069};\\\", \\\"{x:627,y:528,t:1527023415080};\\\", \\\"{x:624,y:527,t:1527023415097};\\\", \\\"{x:623,y:526,t:1527023415113};\\\", \\\"{x:622,y:526,t:1527023415130};\\\", \\\"{x:620,y:525,t:1527023415157};\\\", \\\"{x:619,y:524,t:1527023415174};\\\", \\\"{x:618,y:524,t:1527023415181};\\\", \\\"{x:617,y:522,t:1527023415197};\\\", \\\"{x:614,y:521,t:1527023415213};\\\", \\\"{x:613,y:519,t:1527023415230};\\\", \\\"{x:612,y:516,t:1527023415261};\\\", \\\"{x:611,y:515,t:1527023415269};\\\", \\\"{x:610,y:513,t:1527023415285};\\\", \\\"{x:610,y:511,t:1527023415309};\\\", \\\"{x:610,y:509,t:1527023415317};\\\", \\\"{x:609,y:508,t:1527023415330};\\\", \\\"{x:607,y:505,t:1527023415347};\\\", \\\"{x:606,y:501,t:1527023415364};\\\", \\\"{x:604,y:498,t:1527023415381};\\\", \\\"{x:603,y:496,t:1527023415397};\\\", \\\"{x:603,y:495,t:1527023415414};\\\", \\\"{x:604,y:494,t:1527023415709};\\\", \\\"{x:613,y:495,t:1527023415717};\\\", \\\"{x:624,y:497,t:1527023415730};\\\", \\\"{x:642,y:502,t:1527023415747};\\\", \\\"{x:678,y:507,t:1527023415764};\\\", \\\"{x:711,y:510,t:1527023415781};\\\", \\\"{x:744,y:516,t:1527023415798};\\\", \\\"{x:757,y:518,t:1527023415815};\\\", \\\"{x:764,y:519,t:1527023415831};\\\", \\\"{x:766,y:519,t:1527023415847};\\\", \\\"{x:767,y:519,t:1527023415864};\\\", \\\"{x:768,y:519,t:1527023415973};\\\", \\\"{x:770,y:519,t:1527023415981};\\\", \\\"{x:774,y:520,t:1527023415997};\\\", \\\"{x:781,y:527,t:1527023416015};\\\", \\\"{x:791,y:536,t:1527023416031};\\\", \\\"{x:802,y:544,t:1527023416047};\\\", \\\"{x:819,y:554,t:1527023416065};\\\", \\\"{x:833,y:559,t:1527023416080};\\\", \\\"{x:844,y:564,t:1527023416098};\\\", \\\"{x:847,y:565,t:1527023416114};\\\", \\\"{x:849,y:567,t:1527023416132};\\\", \\\"{x:850,y:567,t:1527023416148};\\\", \\\"{x:851,y:567,t:1527023416164};\\\", \\\"{x:851,y:566,t:1527023416333};\\\", \\\"{x:851,y:565,t:1527023416347};\\\", \\\"{x:851,y:564,t:1527023416364};\\\", \\\"{x:851,y:562,t:1527023416382};\\\", \\\"{x:851,y:561,t:1527023416397};\\\", \\\"{x:851,y:559,t:1527023416421};\\\", \\\"{x:851,y:558,t:1527023416445};\\\", \\\"{x:851,y:557,t:1527023416485};\\\", \\\"{x:850,y:557,t:1527023416501};\\\", \\\"{x:849,y:555,t:1527023416549};\\\", \\\"{x:848,y:555,t:1527023416565};\\\", \\\"{x:847,y:554,t:1527023416581};\\\", \\\"{x:846,y:553,t:1527023416620};\\\", \\\"{x:845,y:553,t:1527023416637};\\\", \\\"{x:844,y:552,t:1527023416649};\\\", \\\"{x:843,y:550,t:1527023416665};\\\", \\\"{x:842,y:549,t:1527023416682};\\\", \\\"{x:841,y:548,t:1527023416698};\\\", \\\"{x:840,y:547,t:1527023416717};\\\", \\\"{x:839,y:546,t:1527023416733};\\\", \\\"{x:839,y:545,t:1527023416749};\\\", \\\"{x:838,y:544,t:1527023416773};\\\", \\\"{x:837,y:543,t:1527023417494};\\\", \\\"{x:831,y:544,t:1527023417501};\\\", \\\"{x:823,y:555,t:1527023417516};\\\", \\\"{x:803,y:573,t:1527023417534};\\\", \\\"{x:776,y:589,t:1527023417548};\\\", \\\"{x:740,y:606,t:1527023417566};\\\", \\\"{x:719,y:614,t:1527023417582};\\\", \\\"{x:700,y:624,t:1527023417599};\\\", \\\"{x:676,y:637,t:1527023417616};\\\", \\\"{x:649,y:652,t:1527023417633};\\\", \\\"{x:625,y:665,t:1527023417649};\\\", \\\"{x:605,y:675,t:1527023417666};\\\", \\\"{x:591,y:680,t:1527023417683};\\\", \\\"{x:583,y:684,t:1527023417698};\\\", \\\"{x:577,y:687,t:1527023417715};\\\", \\\"{x:571,y:690,t:1527023417732};\\\", \\\"{x:566,y:693,t:1527023417749};\\\", \\\"{x:551,y:701,t:1527023417766};\\\", \\\"{x:544,y:705,t:1527023417782};\\\", \\\"{x:539,y:709,t:1527023417799};\\\", \\\"{x:532,y:715,t:1527023417816};\\\", \\\"{x:523,y:721,t:1527023417833};\\\", \\\"{x:519,y:723,t:1527023417850};\\\", \\\"{x:513,y:727,t:1527023417866};\\\", \\\"{x:509,y:730,t:1527023417883};\\\", \\\"{x:506,y:735,t:1527023417898};\\\", \\\"{x:505,y:737,t:1527023417915};\\\", \\\"{x:503,y:740,t:1527023417932};\\\", \\\"{x:503,y:741,t:1527023417949};\\\", \\\"{x:501,y:743,t:1527023417965};\\\", \\\"{x:501,y:744,t:1527023417982};\\\", \\\"{x:500,y:745,t:1527023417999};\\\", \\\"{x:499,y:746,t:1527023418016};\\\", \\\"{x:499,y:748,t:1527023418032};\\\", \\\"{x:499,y:749,t:1527023418061};\\\", \\\"{x:499,y:750,t:1527023418101};\\\", \\\"{x:499,y:751,t:1527023418125};\\\", \\\"{x:500,y:751,t:1527023418438};\\\", \\\"{x:502,y:750,t:1527023418710};\\\", \\\"{x:503,y:749,t:1527023418717};\\\", \\\"{x:504,y:747,t:1527023418733};\\\", \\\"{x:506,y:743,t:1527023418750};\\\", \\\"{x:506,y:742,t:1527023418821};\\\", \\\"{x:507,y:742,t:1527023418973};\\\", \\\"{x:508,y:741,t:1527023419006};\\\", \\\"{x:509,y:740,t:1527023419117};\\\" ] }, { \\\"rt\\\": 23321, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 11, \\\"time_elapsed\\\": 459162, \\\"internal_node_id\\\": \\\"0.0-6.0-1.0\\\", \\\"subject\\\": \\\"8LK9M\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"hotel\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+starts\\\", \\\"q\\\": 7, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"X\\\", \\\"O\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F -F -10 AM-10 AM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:511,y:722,t:1527023420219};\\\", \\\"{x:514,y:711,t:1527023420236};\\\", \\\"{x:519,y:693,t:1527023420251};\\\", \\\"{x:522,y:675,t:1527023420267};\\\", \\\"{x:526,y:655,t:1527023420285};\\\", \\\"{x:538,y:613,t:1527023420301};\\\", \\\"{x:548,y:580,t:1527023420318};\\\", \\\"{x:551,y:561,t:1527023420336};\\\", \\\"{x:554,y:545,t:1527023420351};\\\", \\\"{x:555,y:532,t:1527023420368};\\\", \\\"{x:556,y:520,t:1527023420385};\\\", \\\"{x:556,y:507,t:1527023420401};\\\", \\\"{x:556,y:490,t:1527023420418};\\\", \\\"{x:554,y:477,t:1527023420435};\\\", \\\"{x:549,y:465,t:1527023420451};\\\", \\\"{x:542,y:453,t:1527023420468};\\\", \\\"{x:533,y:443,t:1527023420484};\\\", \\\"{x:512,y:430,t:1527023420501};\\\", \\\"{x:495,y:421,t:1527023420518};\\\", \\\"{x:480,y:417,t:1527023420534};\\\", \\\"{x:472,y:416,t:1527023420552};\\\", \\\"{x:458,y:416,t:1527023420568};\\\", \\\"{x:444,y:416,t:1527023420585};\\\", \\\"{x:434,y:416,t:1527023420602};\\\", \\\"{x:424,y:418,t:1527023420618};\\\", \\\"{x:410,y:421,t:1527023420635};\\\", \\\"{x:392,y:424,t:1527023420652};\\\", \\\"{x:371,y:428,t:1527023420668};\\\", \\\"{x:350,y:430,t:1527023420685};\\\", \\\"{x:345,y:430,t:1527023420701};\\\", \\\"{x:343,y:430,t:1527023420718};\\\", \\\"{x:339,y:431,t:1527023420735};\\\", \\\"{x:338,y:431,t:1527023420830};\\\", \\\"{x:337,y:431,t:1527023420853};\\\", \\\"{x:336,y:431,t:1527023420868};\\\", \\\"{x:334,y:431,t:1527023420885};\\\", \\\"{x:332,y:431,t:1527023420902};\\\", \\\"{x:331,y:432,t:1527023420918};\\\", \\\"{x:331,y:434,t:1527023420949};\\\", \\\"{x:332,y:435,t:1527023420957};\\\", \\\"{x:333,y:436,t:1527023420968};\\\", \\\"{x:338,y:436,t:1527023420984};\\\", \\\"{x:343,y:439,t:1527023421002};\\\", \\\"{x:347,y:440,t:1527023421019};\\\", \\\"{x:350,y:440,t:1527023421035};\\\", \\\"{x:352,y:440,t:1527023421052};\\\", \\\"{x:353,y:440,t:1527023421125};\\\", \\\"{x:353,y:441,t:1527023421135};\\\", \\\"{x:357,y:442,t:1527023421151};\\\", \\\"{x:359,y:443,t:1527023421169};\\\", \\\"{x:362,y:444,t:1527023421184};\\\", \\\"{x:364,y:444,t:1527023421202};\\\", \\\"{x:366,y:444,t:1527023421219};\\\", \\\"{x:370,y:447,t:1527023421235};\\\", \\\"{x:373,y:448,t:1527023421252};\\\", \\\"{x:376,y:449,t:1527023421269};\\\", \\\"{x:377,y:449,t:1527023421285};\\\", \\\"{x:378,y:449,t:1527023421301};\\\", \\\"{x:379,y:450,t:1527023421318};\\\", \\\"{x:380,y:450,t:1527023421509};\\\", \\\"{x:380,y:451,t:1527023421519};\\\", \\\"{x:381,y:452,t:1527023421536};\\\", \\\"{x:382,y:453,t:1527023421552};\\\", \\\"{x:383,y:453,t:1527023421569};\\\", \\\"{x:386,y:454,t:1527023421585};\\\", \\\"{x:387,y:455,t:1527023421602};\\\", \\\"{x:389,y:455,t:1527023421619};\\\", \\\"{x:391,y:455,t:1527023421636};\\\", \\\"{x:394,y:455,t:1527023421652};\\\", \\\"{x:398,y:455,t:1527023421669};\\\", \\\"{x:399,y:455,t:1527023421685};\\\", \\\"{x:401,y:455,t:1527023421702};\\\", \\\"{x:402,y:455,t:1527023421719};\\\", \\\"{x:403,y:455,t:1527023421736};\\\", \\\"{x:404,y:455,t:1527023421752};\\\", \\\"{x:406,y:455,t:1527023421797};\\\", \\\"{x:407,y:455,t:1527023421812};\\\", \\\"{x:408,y:455,t:1527023421837};\\\", \\\"{x:410,y:455,t:1527023421853};\\\", \\\"{x:413,y:454,t:1527023421869};\\\", \\\"{x:415,y:454,t:1527023421886};\\\", \\\"{x:418,y:452,t:1527023421903};\\\", \\\"{x:420,y:452,t:1527023421919};\\\", \\\"{x:422,y:452,t:1527023421936};\\\", \\\"{x:423,y:451,t:1527023421953};\\\", \\\"{x:428,y:450,t:1527023422269};\\\", \\\"{x:441,y:448,t:1527023422286};\\\", \\\"{x:451,y:446,t:1527023422303};\\\", \\\"{x:458,y:446,t:1527023422320};\\\", \\\"{x:466,y:445,t:1527023422336};\\\", \\\"{x:475,y:443,t:1527023422353};\\\", \\\"{x:481,y:442,t:1527023422370};\\\", \\\"{x:489,y:440,t:1527023422386};\\\", \\\"{x:492,y:440,t:1527023422403};\\\", \\\"{x:495,y:440,t:1527023422420};\\\", \\\"{x:498,y:440,t:1527023422436};\\\", \\\"{x:501,y:439,t:1527023422453};\\\", \\\"{x:502,y:439,t:1527023422470};\\\", \\\"{x:506,y:439,t:1527023422485};\\\", \\\"{x:510,y:438,t:1527023422503};\\\", \\\"{x:516,y:436,t:1527023422520};\\\", \\\"{x:520,y:436,t:1527023422536};\\\", \\\"{x:523,y:436,t:1527023422552};\\\", \\\"{x:524,y:436,t:1527023422570};\\\", \\\"{x:526,y:435,t:1527023422586};\\\", \\\"{x:529,y:435,t:1527023422602};\\\", \\\"{x:531,y:435,t:1527023422620};\\\", \\\"{x:539,y:433,t:1527023422637};\\\", \\\"{x:545,y:433,t:1527023422653};\\\", \\\"{x:551,y:432,t:1527023422670};\\\", \\\"{x:557,y:432,t:1527023422686};\\\", \\\"{x:565,y:431,t:1527023422702};\\\", \\\"{x:573,y:431,t:1527023422720};\\\", \\\"{x:577,y:431,t:1527023422737};\\\", \\\"{x:583,y:429,t:1527023422753};\\\", \\\"{x:585,y:429,t:1527023422770};\\\", \\\"{x:588,y:429,t:1527023422787};\\\", \\\"{x:591,y:428,t:1527023422803};\\\", \\\"{x:593,y:428,t:1527023422820};\\\", \\\"{x:596,y:428,t:1527023422837};\\\", \\\"{x:600,y:428,t:1527023422853};\\\", \\\"{x:604,y:428,t:1527023422870};\\\", \\\"{x:610,y:428,t:1527023422887};\\\", \\\"{x:616,y:428,t:1527023422903};\\\", \\\"{x:620,y:428,t:1527023422920};\\\", \\\"{x:626,y:428,t:1527023422937};\\\", \\\"{x:632,y:428,t:1527023422953};\\\", \\\"{x:640,y:428,t:1527023422970};\\\", \\\"{x:647,y:428,t:1527023422987};\\\", \\\"{x:658,y:428,t:1527023423003};\\\", \\\"{x:670,y:428,t:1527023423019};\\\", \\\"{x:688,y:428,t:1527023423036};\\\", \\\"{x:699,y:428,t:1527023423053};\\\", \\\"{x:711,y:428,t:1527023423070};\\\", \\\"{x:718,y:428,t:1527023423087};\\\", \\\"{x:730,y:428,t:1527023423103};\\\", \\\"{x:743,y:428,t:1527023423120};\\\", \\\"{x:755,y:427,t:1527023423137};\\\", \\\"{x:765,y:427,t:1527023423153};\\\", \\\"{x:776,y:427,t:1527023423170};\\\", \\\"{x:785,y:427,t:1527023423187};\\\", \\\"{x:789,y:427,t:1527023423203};\\\", \\\"{x:793,y:425,t:1527023423220};\\\", \\\"{x:794,y:425,t:1527023423253};\\\", \\\"{x:795,y:425,t:1527023423270};\\\", \\\"{x:796,y:425,t:1527023423287};\\\", \\\"{x:797,y:425,t:1527023423309};\\\", \\\"{x:799,y:425,t:1527023423333};\\\", \\\"{x:800,y:425,t:1527023423365};\\\", \\\"{x:801,y:425,t:1527023423373};\\\", \\\"{x:802,y:425,t:1527023423397};\\\", \\\"{x:802,y:425,t:1527023423565};\\\", \\\"{x:805,y:433,t:1527023426934};\\\", \\\"{x:810,y:446,t:1527023426941};\\\", \\\"{x:819,y:464,t:1527023426958};\\\", \\\"{x:827,y:473,t:1527023426975};\\\", \\\"{x:834,y:484,t:1527023426991};\\\", \\\"{x:846,y:497,t:1527023427008};\\\", \\\"{x:858,y:507,t:1527023427024};\\\", \\\"{x:872,y:519,t:1527023427040};\\\", \\\"{x:887,y:530,t:1527023427056};\\\", \\\"{x:905,y:546,t:1527023427073};\\\", \\\"{x:920,y:557,t:1527023427090};\\\", \\\"{x:938,y:568,t:1527023427107};\\\", \\\"{x:952,y:579,t:1527023427123};\\\", \\\"{x:967,y:591,t:1527023427140};\\\", \\\"{x:989,y:610,t:1527023427157};\\\", \\\"{x:1005,y:621,t:1527023427173};\\\", \\\"{x:1019,y:631,t:1527023427190};\\\", \\\"{x:1032,y:640,t:1527023427207};\\\", \\\"{x:1047,y:651,t:1527023427223};\\\", \\\"{x:1061,y:663,t:1527023427241};\\\", \\\"{x:1079,y:676,t:1527023427257};\\\", \\\"{x:1097,y:692,t:1527023427275};\\\", \\\"{x:1115,y:704,t:1527023427290};\\\", \\\"{x:1141,y:719,t:1527023427307};\\\", \\\"{x:1179,y:733,t:1527023427325};\\\", \\\"{x:1230,y:751,t:1527023427339};\\\", \\\"{x:1264,y:762,t:1527023427357};\\\", \\\"{x:1274,y:768,t:1527023427374};\\\", \\\"{x:1277,y:771,t:1527023427390};\\\", \\\"{x:1279,y:772,t:1527023427407};\\\", \\\"{x:1276,y:766,t:1527023428421};\\\", \\\"{x:1275,y:765,t:1527023428429};\\\", \\\"{x:1273,y:762,t:1527023428443};\\\", \\\"{x:1271,y:759,t:1527023428460};\\\", \\\"{x:1267,y:752,t:1527023428476};\\\", \\\"{x:1264,y:740,t:1527023428492};\\\", \\\"{x:1262,y:732,t:1527023428509};\\\", \\\"{x:1262,y:726,t:1527023428526};\\\", \\\"{x:1262,y:723,t:1527023428543};\\\", \\\"{x:1262,y:716,t:1527023428559};\\\", \\\"{x:1262,y:709,t:1527023428576};\\\", \\\"{x:1264,y:703,t:1527023428593};\\\", \\\"{x:1264,y:697,t:1527023428610};\\\", \\\"{x:1264,y:689,t:1527023428627};\\\", \\\"{x:1264,y:681,t:1527023428643};\\\", \\\"{x:1263,y:670,t:1527023428660};\\\", \\\"{x:1262,y:662,t:1527023428676};\\\", \\\"{x:1260,y:654,t:1527023428692};\\\", \\\"{x:1260,y:648,t:1527023428710};\\\", \\\"{x:1259,y:644,t:1527023428727};\\\", \\\"{x:1259,y:643,t:1527023428748};\\\", \\\"{x:1259,y:642,t:1527023428761};\\\", \\\"{x:1259,y:640,t:1527023428778};\\\", \\\"{x:1259,y:637,t:1527023428794};\\\", \\\"{x:1258,y:635,t:1527023428810};\\\", \\\"{x:1258,y:634,t:1527023428827};\\\", \\\"{x:1257,y:633,t:1527023428843};\\\", \\\"{x:1257,y:634,t:1527023429269};\\\", \\\"{x:1257,y:638,t:1527023429278};\\\", \\\"{x:1258,y:646,t:1527023429294};\\\", \\\"{x:1261,y:651,t:1527023429312};\\\", \\\"{x:1262,y:654,t:1527023429328};\\\", \\\"{x:1263,y:655,t:1527023429344};\\\", \\\"{x:1264,y:656,t:1527023429361};\\\", \\\"{x:1265,y:658,t:1527023429378};\\\", \\\"{x:1268,y:660,t:1527023429394};\\\", \\\"{x:1271,y:663,t:1527023429411};\\\", \\\"{x:1276,y:666,t:1527023429428};\\\", \\\"{x:1281,y:669,t:1527023429445};\\\", \\\"{x:1284,y:672,t:1527023429462};\\\", \\\"{x:1286,y:673,t:1527023429479};\\\", \\\"{x:1287,y:675,t:1527023429495};\\\", \\\"{x:1290,y:677,t:1527023429512};\\\", \\\"{x:1293,y:679,t:1527023429529};\\\", \\\"{x:1296,y:681,t:1527023429545};\\\", \\\"{x:1297,y:683,t:1527023429562};\\\", \\\"{x:1299,y:684,t:1527023429578};\\\", \\\"{x:1299,y:686,t:1527023429596};\\\", \\\"{x:1299,y:688,t:1527023429612};\\\", \\\"{x:1300,y:688,t:1527023429628};\\\", \\\"{x:1303,y:691,t:1527023429645};\\\", \\\"{x:1307,y:693,t:1527023429662};\\\", \\\"{x:1310,y:693,t:1527023429679};\\\", \\\"{x:1314,y:696,t:1527023429695};\\\", \\\"{x:1318,y:696,t:1527023429712};\\\", \\\"{x:1322,y:697,t:1527023429729};\\\", \\\"{x:1326,y:699,t:1527023429745};\\\", \\\"{x:1329,y:699,t:1527023429762};\\\", \\\"{x:1331,y:699,t:1527023429779};\\\", \\\"{x:1332,y:699,t:1527023429795};\\\", \\\"{x:1333,y:699,t:1527023429812};\\\", \\\"{x:1335,y:700,t:1527023429853};\\\", \\\"{x:1336,y:701,t:1527023429869};\\\", \\\"{x:1337,y:701,t:1527023429885};\\\", \\\"{x:1338,y:701,t:1527023429896};\\\", \\\"{x:1339,y:701,t:1527023429917};\\\", \\\"{x:1341,y:701,t:1527023429933};\\\", \\\"{x:1341,y:702,t:1527023429946};\\\", \\\"{x:1342,y:702,t:1527023430005};\\\", \\\"{x:1343,y:702,t:1527023430206};\\\", \\\"{x:1344,y:702,t:1527023430213};\\\", \\\"{x:1346,y:702,t:1527023430231};\\\", \\\"{x:1348,y:702,t:1527023430246};\\\", \\\"{x:1349,y:701,t:1527023430301};\\\", \\\"{x:1350,y:700,t:1527023430357};\\\", \\\"{x:1351,y:700,t:1527023430469};\\\", \\\"{x:1351,y:699,t:1527023430480};\\\", \\\"{x:1352,y:699,t:1527023430533};\\\", \\\"{x:1353,y:698,t:1527023430557};\\\", \\\"{x:1354,y:697,t:1527023430565};\\\", \\\"{x:1355,y:696,t:1527023430581};\\\", \\\"{x:1356,y:696,t:1527023430597};\\\", \\\"{x:1357,y:695,t:1527023430637};\\\", \\\"{x:1359,y:694,t:1527023430661};\\\", \\\"{x:1358,y:694,t:1527023432309};\\\", \\\"{x:1357,y:694,t:1527023432341};\\\", \\\"{x:1356,y:695,t:1527023432422};\\\", \\\"{x:1355,y:696,t:1527023432605};\\\", \\\"{x:1354,y:696,t:1527023432621};\\\", \\\"{x:1353,y:697,t:1527023432661};\\\", \\\"{x:1353,y:698,t:1527023432716};\\\", \\\"{x:1352,y:698,t:1527023432757};\\\", \\\"{x:1351,y:698,t:1527023432797};\\\", \\\"{x:1350,y:699,t:1527023433069};\\\", \\\"{x:1350,y:700,t:1527023433085};\\\", \\\"{x:1349,y:702,t:1527023433102};\\\", \\\"{x:1348,y:703,t:1527023433125};\\\", \\\"{x:1347,y:703,t:1527023433165};\\\", \\\"{x:1345,y:709,t:1527023434173};\\\", \\\"{x:1345,y:712,t:1527023434188};\\\", \\\"{x:1342,y:719,t:1527023434204};\\\", \\\"{x:1338,y:728,t:1527023434221};\\\", \\\"{x:1335,y:735,t:1527023434239};\\\", \\\"{x:1334,y:739,t:1527023434254};\\\", \\\"{x:1332,y:746,t:1527023434271};\\\", \\\"{x:1331,y:751,t:1527023434288};\\\", \\\"{x:1327,y:760,t:1527023434304};\\\", \\\"{x:1322,y:776,t:1527023434321};\\\", \\\"{x:1314,y:793,t:1527023434338};\\\", \\\"{x:1303,y:815,t:1527023434355};\\\", \\\"{x:1298,y:831,t:1527023434371};\\\", \\\"{x:1293,y:841,t:1527023434388};\\\", \\\"{x:1284,y:862,t:1527023434405};\\\", \\\"{x:1282,y:870,t:1527023434421};\\\", \\\"{x:1280,y:882,t:1527023434438};\\\", \\\"{x:1277,y:891,t:1527023434455};\\\", \\\"{x:1272,y:902,t:1527023434471};\\\", \\\"{x:1267,y:914,t:1527023434489};\\\", \\\"{x:1260,y:927,t:1527023434505};\\\", \\\"{x:1254,y:937,t:1527023434521};\\\", \\\"{x:1248,y:948,t:1527023434539};\\\", \\\"{x:1242,y:960,t:1527023434555};\\\", \\\"{x:1238,y:969,t:1527023434573};\\\", \\\"{x:1233,y:977,t:1527023434589};\\\", \\\"{x:1227,y:985,t:1527023434606};\\\", \\\"{x:1226,y:987,t:1527023434622};\\\", \\\"{x:1225,y:989,t:1527023434638};\\\", \\\"{x:1224,y:990,t:1527023434655};\\\", \\\"{x:1222,y:990,t:1527023434909};\\\", \\\"{x:1221,y:990,t:1527023434923};\\\", \\\"{x:1217,y:987,t:1527023434940};\\\", \\\"{x:1216,y:986,t:1527023434956};\\\", \\\"{x:1215,y:985,t:1527023434972};\\\", \\\"{x:1213,y:984,t:1527023434989};\\\", \\\"{x:1213,y:983,t:1527023435301};\\\", \\\"{x:1213,y:982,t:1527023435309};\\\", \\\"{x:1213,y:981,t:1527023435324};\\\", \\\"{x:1213,y:980,t:1527023435341};\\\", \\\"{x:1213,y:979,t:1527023435381};\\\", \\\"{x:1213,y:978,t:1527023435391};\\\", \\\"{x:1213,y:977,t:1527023435509};\\\", \\\"{x:1213,y:976,t:1527023435525};\\\", \\\"{x:1213,y:975,t:1527023436693};\\\", \\\"{x:1229,y:970,t:1527023436709};\\\", \\\"{x:1245,y:965,t:1527023436727};\\\", \\\"{x:1260,y:962,t:1527023436744};\\\", \\\"{x:1271,y:959,t:1527023436760};\\\", \\\"{x:1277,y:957,t:1527023436777};\\\", \\\"{x:1279,y:956,t:1527023436794};\\\", \\\"{x:1280,y:956,t:1527023436810};\\\", \\\"{x:1281,y:955,t:1527023436861};\\\", \\\"{x:1282,y:955,t:1527023436885};\\\", \\\"{x:1284,y:954,t:1527023436900};\\\", \\\"{x:1284,y:953,t:1527023436933};\\\", \\\"{x:1285,y:953,t:1527023436943};\\\", \\\"{x:1286,y:952,t:1527023436973};\\\", \\\"{x:1287,y:952,t:1527023437013};\\\", \\\"{x:1288,y:951,t:1527023437029};\\\", \\\"{x:1289,y:951,t:1527023437085};\\\", \\\"{x:1290,y:951,t:1527023437117};\\\", \\\"{x:1291,y:950,t:1527023437127};\\\", \\\"{x:1292,y:950,t:1527023437143};\\\", \\\"{x:1292,y:949,t:1527023437160};\\\", \\\"{x:1293,y:949,t:1527023437181};\\\", \\\"{x:1293,y:948,t:1527023437197};\\\", \\\"{x:1295,y:948,t:1527023437221};\\\", \\\"{x:1296,y:948,t:1527023437253};\\\", \\\"{x:1296,y:947,t:1527023437269};\\\", \\\"{x:1297,y:947,t:1527023437285};\\\", \\\"{x:1298,y:947,t:1527023437309};\\\", \\\"{x:1299,y:947,t:1527023437317};\\\", \\\"{x:1301,y:947,t:1527023437327};\\\", \\\"{x:1305,y:947,t:1527023437345};\\\", \\\"{x:1307,y:946,t:1527023437361};\\\", \\\"{x:1309,y:946,t:1527023437377};\\\", \\\"{x:1310,y:946,t:1527023437413};\\\", \\\"{x:1311,y:946,t:1527023437429};\\\", \\\"{x:1312,y:946,t:1527023437444};\\\", \\\"{x:1313,y:946,t:1527023437469};\\\", \\\"{x:1314,y:946,t:1527023437478};\\\", \\\"{x:1315,y:945,t:1527023437495};\\\", \\\"{x:1316,y:945,t:1527023437533};\\\", \\\"{x:1317,y:945,t:1527023437548};\\\", \\\"{x:1318,y:945,t:1527023437589};\\\", \\\"{x:1319,y:945,t:1527023437629};\\\", \\\"{x:1321,y:945,t:1527023437645};\\\", \\\"{x:1324,y:945,t:1527023437661};\\\", \\\"{x:1327,y:945,t:1527023437678};\\\", \\\"{x:1331,y:945,t:1527023437696};\\\", \\\"{x:1335,y:945,t:1527023437712};\\\", \\\"{x:1338,y:945,t:1527023437728};\\\", \\\"{x:1341,y:945,t:1527023437745};\\\", \\\"{x:1345,y:945,t:1527023437762};\\\", \\\"{x:1350,y:946,t:1527023437779};\\\", \\\"{x:1355,y:947,t:1527023437796};\\\", \\\"{x:1361,y:948,t:1527023437812};\\\", \\\"{x:1363,y:948,t:1527023437828};\\\", \\\"{x:1367,y:948,t:1527023437845};\\\", \\\"{x:1370,y:948,t:1527023437862};\\\", \\\"{x:1371,y:948,t:1527023437879};\\\", \\\"{x:1372,y:948,t:1527023437896};\\\", \\\"{x:1373,y:948,t:1527023437913};\\\", \\\"{x:1374,y:950,t:1527023437934};\\\", \\\"{x:1375,y:950,t:1527023437949};\\\", \\\"{x:1376,y:950,t:1527023437962};\\\", \\\"{x:1377,y:950,t:1527023437979};\\\", \\\"{x:1379,y:950,t:1527023437995};\\\", \\\"{x:1383,y:950,t:1527023438012};\\\", \\\"{x:1386,y:950,t:1527023438029};\\\", \\\"{x:1388,y:950,t:1527023438046};\\\", \\\"{x:1389,y:950,t:1527023438063};\\\", \\\"{x:1391,y:950,t:1527023438079};\\\", \\\"{x:1394,y:950,t:1527023438095};\\\", \\\"{x:1396,y:949,t:1527023438112};\\\", \\\"{x:1399,y:949,t:1527023438129};\\\", \\\"{x:1400,y:949,t:1527023438146};\\\", \\\"{x:1401,y:949,t:1527023438163};\\\", \\\"{x:1402,y:949,t:1527023438413};\\\", \\\"{x:1404,y:947,t:1527023438510};\\\", \\\"{x:1405,y:947,t:1527023438549};\\\", \\\"{x:1407,y:947,t:1527023438629};\\\", \\\"{x:1408,y:947,t:1527023438645};\\\", \\\"{x:1409,y:946,t:1527023438653};\\\", \\\"{x:1410,y:946,t:1527023438664};\\\", \\\"{x:1411,y:946,t:1527023438681};\\\", \\\"{x:1413,y:946,t:1527023438698};\\\", \\\"{x:1414,y:946,t:1527023438714};\\\", \\\"{x:1416,y:946,t:1527023438740};\\\", \\\"{x:1417,y:946,t:1527023438757};\\\", \\\"{x:1420,y:945,t:1527023438765};\\\", \\\"{x:1422,y:945,t:1527023438780};\\\", \\\"{x:1424,y:945,t:1527023438798};\\\", \\\"{x:1426,y:945,t:1527023438814};\\\", \\\"{x:1428,y:945,t:1527023438831};\\\", \\\"{x:1429,y:945,t:1527023438847};\\\", \\\"{x:1432,y:945,t:1527023438864};\\\", \\\"{x:1434,y:945,t:1527023438881};\\\", \\\"{x:1435,y:945,t:1527023438898};\\\", \\\"{x:1436,y:945,t:1527023438915};\\\", \\\"{x:1437,y:945,t:1527023438931};\\\", \\\"{x:1438,y:945,t:1527023438949};\\\", \\\"{x:1439,y:945,t:1527023439205};\\\", \\\"{x:1441,y:954,t:1527023439215};\\\", \\\"{x:1441,y:984,t:1527023439231};\\\", \\\"{x:1439,y:988,t:1527023439249};\\\", \\\"{x:1438,y:990,t:1527023439265};\\\", \\\"{x:1438,y:993,t:1527023439281};\\\", \\\"{x:1438,y:992,t:1527023439389};\\\", \\\"{x:1438,y:990,t:1527023439399};\\\", \\\"{x:1439,y:988,t:1527023439416};\\\", \\\"{x:1440,y:985,t:1527023439431};\\\", \\\"{x:1442,y:982,t:1527023439448};\\\", \\\"{x:1443,y:979,t:1527023439466};\\\", \\\"{x:1444,y:973,t:1527023439482};\\\", \\\"{x:1447,y:966,t:1527023439499};\\\", \\\"{x:1450,y:961,t:1527023439515};\\\", \\\"{x:1452,y:958,t:1527023439533};\\\", \\\"{x:1453,y:956,t:1527023439549};\\\", \\\"{x:1456,y:950,t:1527023439565};\\\", \\\"{x:1460,y:941,t:1527023439583};\\\", \\\"{x:1465,y:929,t:1527023439599};\\\", \\\"{x:1469,y:915,t:1527023439616};\\\", \\\"{x:1473,y:905,t:1527023439632};\\\", \\\"{x:1476,y:897,t:1527023439650};\\\", \\\"{x:1479,y:888,t:1527023439665};\\\", \\\"{x:1483,y:877,t:1527023439682};\\\", \\\"{x:1489,y:869,t:1527023439700};\\\", \\\"{x:1491,y:866,t:1527023439716};\\\", \\\"{x:1495,y:855,t:1527023439732};\\\", \\\"{x:1496,y:850,t:1527023439749};\\\", \\\"{x:1499,y:846,t:1527023439766};\\\", \\\"{x:1500,y:844,t:1527023439783};\\\", \\\"{x:1500,y:838,t:1527023439800};\\\", \\\"{x:1503,y:830,t:1527023439816};\\\", \\\"{x:1504,y:827,t:1527023439833};\\\", \\\"{x:1505,y:825,t:1527023439850};\\\", \\\"{x:1506,y:823,t:1527023439867};\\\", \\\"{x:1507,y:820,t:1527023439882};\\\", \\\"{x:1507,y:816,t:1527023439900};\\\", \\\"{x:1508,y:807,t:1527023439917};\\\", \\\"{x:1510,y:804,t:1527023439933};\\\", \\\"{x:1510,y:800,t:1527023439949};\\\", \\\"{x:1510,y:798,t:1527023439967};\\\", \\\"{x:1510,y:796,t:1527023439988};\\\", \\\"{x:1510,y:794,t:1527023439999};\\\", \\\"{x:1510,y:793,t:1527023440021};\\\", \\\"{x:1511,y:791,t:1527023440037};\\\", \\\"{x:1512,y:789,t:1527023440053};\\\", \\\"{x:1512,y:786,t:1527023440067};\\\", \\\"{x:1513,y:783,t:1527023440083};\\\", \\\"{x:1513,y:780,t:1527023440100};\\\", \\\"{x:1513,y:776,t:1527023440117};\\\", \\\"{x:1513,y:774,t:1527023440134};\\\", \\\"{x:1512,y:773,t:1527023440285};\\\", \\\"{x:1491,y:782,t:1527023440301};\\\", \\\"{x:1460,y:800,t:1527023440317};\\\", \\\"{x:1425,y:818,t:1527023440334};\\\", \\\"{x:1385,y:830,t:1527023440351};\\\", \\\"{x:1338,y:844,t:1527023440368};\\\", \\\"{x:1280,y:852,t:1527023440384};\\\", \\\"{x:1194,y:861,t:1527023440401};\\\", \\\"{x:1086,y:861,t:1527023440418};\\\", \\\"{x:949,y:856,t:1527023440434};\\\", \\\"{x:928,y:858,t:1527023440451};\\\", \\\"{x:927,y:856,t:1527023440853};\\\", \\\"{x:912,y:847,t:1527023440869};\\\", \\\"{x:894,y:837,t:1527023440885};\\\", \\\"{x:877,y:825,t:1527023440901};\\\", \\\"{x:866,y:818,t:1527023440919};\\\", \\\"{x:863,y:815,t:1527023440934};\\\", \\\"{x:859,y:812,t:1527023440952};\\\", \\\"{x:856,y:809,t:1527023440968};\\\", \\\"{x:851,y:803,t:1527023440985};\\\", \\\"{x:847,y:797,t:1527023441002};\\\", \\\"{x:845,y:793,t:1527023441019};\\\", \\\"{x:845,y:789,t:1527023441035};\\\", \\\"{x:845,y:782,t:1527023441051};\\\", \\\"{x:849,y:761,t:1527023441068};\\\", \\\"{x:856,y:716,t:1527023441085};\\\", \\\"{x:865,y:670,t:1527023441102};\\\", \\\"{x:871,y:647,t:1527023441118};\\\", \\\"{x:878,y:631,t:1527023441136};\\\", \\\"{x:881,y:620,t:1527023441152};\\\", \\\"{x:883,y:611,t:1527023441167};\\\", \\\"{x:883,y:602,t:1527023441184};\\\", \\\"{x:882,y:584,t:1527023441201};\\\", \\\"{x:877,y:568,t:1527023441219};\\\", \\\"{x:876,y:559,t:1527023441235};\\\", \\\"{x:876,y:556,t:1527023441252};\\\", \\\"{x:876,y:551,t:1527023441268};\\\", \\\"{x:876,y:547,t:1527023441284};\\\", \\\"{x:875,y:546,t:1527023441302};\\\", \\\"{x:873,y:544,t:1527023441318};\\\", \\\"{x:872,y:543,t:1527023441335};\\\", \\\"{x:870,y:543,t:1527023441389};\\\", \\\"{x:867,y:543,t:1527023441402};\\\", \\\"{x:860,y:546,t:1527023441418};\\\", \\\"{x:855,y:547,t:1527023441434};\\\", \\\"{x:852,y:548,t:1527023441451};\\\", \\\"{x:849,y:550,t:1527023441468};\\\", \\\"{x:847,y:552,t:1527023441484};\\\", \\\"{x:844,y:555,t:1527023441501};\\\", \\\"{x:842,y:556,t:1527023441519};\\\", \\\"{x:839,y:559,t:1527023441535};\\\", \\\"{x:834,y:564,t:1527023441552};\\\", \\\"{x:830,y:566,t:1527023441569};\\\", \\\"{x:829,y:567,t:1527023441584};\\\", \\\"{x:829,y:569,t:1527023441602};\\\", \\\"{x:827,y:570,t:1527023441876};\\\", \\\"{x:824,y:572,t:1527023441885};\\\", \\\"{x:813,y:582,t:1527023441902};\\\", \\\"{x:802,y:590,t:1527023441919};\\\", \\\"{x:790,y:596,t:1527023441936};\\\", \\\"{x:774,y:601,t:1527023441952};\\\", \\\"{x:762,y:604,t:1527023441968};\\\", \\\"{x:753,y:606,t:1527023441986};\\\", \\\"{x:745,y:607,t:1527023442002};\\\", \\\"{x:737,y:609,t:1527023442019};\\\", \\\"{x:732,y:609,t:1527023442036};\\\", \\\"{x:727,y:609,t:1527023442052};\\\", \\\"{x:716,y:606,t:1527023442069};\\\", \\\"{x:710,y:601,t:1527023442085};\\\", \\\"{x:703,y:595,t:1527023442103};\\\", \\\"{x:693,y:589,t:1527023442119};\\\", \\\"{x:683,y:586,t:1527023442136};\\\", \\\"{x:674,y:581,t:1527023442152};\\\", \\\"{x:668,y:577,t:1527023442168};\\\", \\\"{x:663,y:573,t:1527023442186};\\\", \\\"{x:660,y:572,t:1527023442202};\\\", \\\"{x:653,y:570,t:1527023442218};\\\", \\\"{x:644,y:569,t:1527023442235};\\\", \\\"{x:632,y:568,t:1527023442252};\\\", \\\"{x:623,y:568,t:1527023442269};\\\", \\\"{x:622,y:568,t:1527023442293};\\\", \\\"{x:618,y:568,t:1527023442557};\\\", \\\"{x:614,y:577,t:1527023442569};\\\", \\\"{x:608,y:589,t:1527023442586};\\\", \\\"{x:602,y:596,t:1527023442603};\\\", \\\"{x:598,y:602,t:1527023442620};\\\", \\\"{x:593,y:611,t:1527023442635};\\\", \\\"{x:590,y:622,t:1527023442653};\\\", \\\"{x:588,y:634,t:1527023442670};\\\", \\\"{x:587,y:644,t:1527023442686};\\\", \\\"{x:582,y:660,t:1527023442703};\\\", \\\"{x:578,y:674,t:1527023442720};\\\", \\\"{x:573,y:687,t:1527023442735};\\\", \\\"{x:571,y:699,t:1527023442753};\\\", \\\"{x:570,y:707,t:1527023442769};\\\", \\\"{x:570,y:717,t:1527023442786};\\\", \\\"{x:570,y:728,t:1527023442803};\\\", \\\"{x:570,y:737,t:1527023442819};\\\", \\\"{x:567,y:748,t:1527023442837};\\\", \\\"{x:566,y:750,t:1527023442854};\\\", \\\"{x:566,y:747,t:1527023442892};\\\", \\\"{x:565,y:746,t:1527023442904};\\\", \\\"{x:565,y:742,t:1527023442920};\\\", \\\"{x:564,y:734,t:1527023442936};\\\", \\\"{x:564,y:732,t:1527023442954};\\\", \\\"{x:563,y:730,t:1527023442969};\\\", \\\"{x:563,y:728,t:1527023442989};\\\", \\\"{x:562,y:728,t:1527023443021};\\\", \\\"{x:561,y:728,t:1527023443124};\\\", \\\"{x:559,y:728,t:1527023443135};\\\", \\\"{x:558,y:729,t:1527023443153};\\\", \\\"{x:558,y:729,t:1527023443186};\\\", \\\"{x:557,y:729,t:1527023443202};\\\", \\\"{x:555,y:729,t:1527023443219};\\\", \\\"{x:547,y:729,t:1527023443237};\\\", \\\"{x:541,y:729,t:1527023443252};\\\", \\\"{x:537,y:729,t:1527023443269};\\\", \\\"{x:536,y:730,t:1527023443286};\\\", \\\"{x:535,y:731,t:1527023443349};\\\", \\\"{x:536,y:731,t:1527023443460};\\\", \\\"{x:537,y:731,t:1527023443469};\\\", \\\"{x:542,y:731,t:1527023443487};\\\", \\\"{x:548,y:731,t:1527023443503};\\\", \\\"{x:556,y:731,t:1527023443519};\\\", \\\"{x:562,y:731,t:1527023443537};\\\", \\\"{x:567,y:729,t:1527023443554};\\\", \\\"{x:574,y:726,t:1527023443570};\\\", \\\"{x:580,y:722,t:1527023443586};\\\", \\\"{x:586,y:718,t:1527023443603};\\\", \\\"{x:594,y:711,t:1527023443620};\\\", \\\"{x:607,y:697,t:1527023443636};\\\", \\\"{x:617,y:685,t:1527023443654};\\\", \\\"{x:626,y:676,t:1527023443670};\\\", \\\"{x:633,y:668,t:1527023443686};\\\", \\\"{x:637,y:666,t:1527023443703};\\\", \\\"{x:640,y:664,t:1527023443720};\\\", \\\"{x:641,y:663,t:1527023443740};\\\", \\\"{x:642,y:662,t:1527023443753};\\\", \\\"{x:643,y:661,t:1527023443770};\\\", \\\"{x:644,y:660,t:1527023443786};\\\", \\\"{x:645,y:660,t:1527023443804};\\\", \\\"{x:646,y:659,t:1527023443820};\\\", \\\"{x:648,y:658,t:1527023443837};\\\", \\\"{x:651,y:656,t:1527023443854};\\\", \\\"{x:655,y:655,t:1527023443870};\\\", \\\"{x:659,y:652,t:1527023443886};\\\", \\\"{x:661,y:650,t:1527023443903};\\\", \\\"{x:665,y:645,t:1527023443919};\\\", \\\"{x:671,y:637,t:1527023443937};\\\", \\\"{x:676,y:625,t:1527023443953};\\\", \\\"{x:679,y:616,t:1527023443969};\\\", \\\"{x:682,y:608,t:1527023443987};\\\", \\\"{x:682,y:604,t:1527023444003};\\\", \\\"{x:682,y:594,t:1527023444021};\\\", \\\"{x:682,y:584,t:1527023444037};\\\", \\\"{x:682,y:575,t:1527023444054};\\\", \\\"{x:682,y:571,t:1527023444071};\\\", \\\"{x:680,y:567,t:1527023444087};\\\", \\\"{x:680,y:563,t:1527023444104};\\\", \\\"{x:680,y:561,t:1527023444120};\\\", \\\"{x:680,y:557,t:1527023444136};\\\", \\\"{x:678,y:554,t:1527023444154};\\\", \\\"{x:677,y:550,t:1527023444171};\\\", \\\"{x:676,y:537,t:1527023444222};\\\", \\\"{x:675,y:533,t:1527023444237};\\\", \\\"{x:672,y:528,t:1527023444254};\\\", \\\"{x:670,y:525,t:1527023444271};\\\", \\\"{x:669,y:521,t:1527023444287};\\\" ] }, { \\\"rt\\\": 50258, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 12, \\\"time_elapsed\\\": 510658, \\\"internal_node_id\\\": \\\"0.0-6.0-2.0\\\", \\\"subject\\\": \\\"8LK9M\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"hotel\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+contained\\\", \\\"q\\\": 8, \\\"clicks\\\": 0, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-8-F -B -B -B -J -J -J -J -J -J -X -X \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:644,y:480,t:1527023444408};\\\", \\\"{x:639,y:471,t:1527023444447};\\\", \\\"{x:637,y:467,t:1527023444454};\\\", \\\"{x:632,y:460,t:1527023444470};\\\", \\\"{x:632,y:459,t:1527023444487};\\\", \\\"{x:631,y:458,t:1527023444515};\\\", \\\"{x:631,y:457,t:1527023444537};\\\", \\\"{x:631,y:456,t:1527023445029};\\\", \\\"{x:629,y:456,t:1527023445038};\\\", \\\"{x:624,y:456,t:1527023445055};\\\", \\\"{x:605,y:456,t:1527023445071};\\\", \\\"{x:581,y:455,t:1527023445088};\\\", \\\"{x:558,y:455,t:1527023445105};\\\", \\\"{x:533,y:451,t:1527023445121};\\\", \\\"{x:514,y:451,t:1527023445138};\\\", \\\"{x:502,y:451,t:1527023445154};\\\", \\\"{x:495,y:450,t:1527023445171};\\\", \\\"{x:490,y:450,t:1527023445188};\\\", \\\"{x:478,y:450,t:1527023445205};\\\", \\\"{x:472,y:450,t:1527023445220};\\\", \\\"{x:467,y:450,t:1527023445237};\\\", \\\"{x:459,y:450,t:1527023445255};\\\", \\\"{x:450,y:451,t:1527023445270};\\\", \\\"{x:440,y:451,t:1527023445287};\\\", \\\"{x:428,y:451,t:1527023445305};\\\", \\\"{x:418,y:451,t:1527023445320};\\\", \\\"{x:409,y:451,t:1527023445337};\\\", \\\"{x:402,y:451,t:1527023445355};\\\", \\\"{x:400,y:451,t:1527023445371};\\\", \\\"{x:395,y:451,t:1527023445387};\\\", \\\"{x:386,y:452,t:1527023445404};\\\", \\\"{x:375,y:453,t:1527023445422};\\\", \\\"{x:369,y:453,t:1527023445437};\\\", \\\"{x:365,y:454,t:1527023445454};\\\", \\\"{x:362,y:454,t:1527023445472};\\\", \\\"{x:355,y:454,t:1527023445487};\\\", \\\"{x:348,y:454,t:1527023445504};\\\", \\\"{x:340,y:454,t:1527023445522};\\\", \\\"{x:330,y:456,t:1527023445537};\\\", \\\"{x:314,y:458,t:1527023445555};\\\", \\\"{x:303,y:458,t:1527023445572};\\\", \\\"{x:292,y:458,t:1527023445588};\\\", \\\"{x:277,y:458,t:1527023445605};\\\", \\\"{x:269,y:458,t:1527023445622};\\\", \\\"{x:266,y:458,t:1527023445638};\\\", \\\"{x:263,y:458,t:1527023445655};\\\", \\\"{x:260,y:458,t:1527023445672};\\\", \\\"{x:256,y:458,t:1527023445688};\\\", \\\"{x:251,y:458,t:1527023445705};\\\", \\\"{x:244,y:458,t:1527023445722};\\\", \\\"{x:237,y:458,t:1527023445738};\\\", \\\"{x:232,y:458,t:1527023445754};\\\", \\\"{x:230,y:458,t:1527023445771};\\\", \\\"{x:229,y:457,t:1527023445844};\\\", \\\"{x:228,y:455,t:1527023445860};\\\", \\\"{x:227,y:454,t:1527023445876};\\\", \\\"{x:226,y:453,t:1527023445892};\\\", \\\"{x:229,y:453,t:1527023446245};\\\", \\\"{x:232,y:453,t:1527023446255};\\\", \\\"{x:240,y:453,t:1527023446272};\\\", \\\"{x:251,y:453,t:1527023446288};\\\", \\\"{x:266,y:453,t:1527023446306};\\\", \\\"{x:283,y:453,t:1527023446322};\\\", \\\"{x:296,y:453,t:1527023446339};\\\", \\\"{x:312,y:453,t:1527023446356};\\\", \\\"{x:335,y:453,t:1527023446372};\\\", \\\"{x:366,y:453,t:1527023446389};\\\", \\\"{x:378,y:453,t:1527023446406};\\\", \\\"{x:388,y:453,t:1527023446422};\\\", \\\"{x:393,y:453,t:1527023446439};\\\", \\\"{x:397,y:452,t:1527023446456};\\\", \\\"{x:403,y:451,t:1527023446472};\\\", \\\"{x:409,y:450,t:1527023446488};\\\", \\\"{x:414,y:449,t:1527023446506};\\\", \\\"{x:419,y:449,t:1527023446522};\\\", \\\"{x:429,y:448,t:1527023446539};\\\", \\\"{x:440,y:448,t:1527023446556};\\\", \\\"{x:450,y:446,t:1527023446571};\\\", \\\"{x:460,y:446,t:1527023446589};\\\", \\\"{x:467,y:446,t:1527023446606};\\\", \\\"{x:474,y:446,t:1527023446623};\\\", \\\"{x:481,y:446,t:1527023446639};\\\", \\\"{x:488,y:446,t:1527023446656};\\\", \\\"{x:493,y:446,t:1527023446672};\\\", \\\"{x:495,y:446,t:1527023446689};\\\", \\\"{x:500,y:446,t:1527023446705};\\\", \\\"{x:505,y:446,t:1527023446722};\\\", \\\"{x:513,y:446,t:1527023446739};\\\", \\\"{x:523,y:446,t:1527023446756};\\\", \\\"{x:541,y:446,t:1527023446772};\\\", \\\"{x:555,y:446,t:1527023446789};\\\", \\\"{x:566,y:446,t:1527023446806};\\\", \\\"{x:577,y:446,t:1527023446824};\\\", \\\"{x:591,y:446,t:1527023446839};\\\", \\\"{x:601,y:446,t:1527023446856};\\\", \\\"{x:615,y:446,t:1527023446873};\\\", \\\"{x:628,y:446,t:1527023446889};\\\", \\\"{x:642,y:446,t:1527023446906};\\\", \\\"{x:652,y:446,t:1527023446923};\\\", \\\"{x:661,y:445,t:1527023446939};\\\", \\\"{x:667,y:445,t:1527023446956};\\\", \\\"{x:674,y:444,t:1527023446972};\\\", \\\"{x:675,y:444,t:1527023446989};\\\", \\\"{x:678,y:444,t:1527023447006};\\\", \\\"{x:680,y:444,t:1527023447023};\\\", \\\"{x:684,y:444,t:1527023447038};\\\", \\\"{x:687,y:444,t:1527023447056};\\\", \\\"{x:691,y:444,t:1527023447072};\\\", \\\"{x:695,y:444,t:1527023447089};\\\", \\\"{x:699,y:444,t:1527023447106};\\\", \\\"{x:704,y:444,t:1527023447123};\\\", \\\"{x:710,y:444,t:1527023447140};\\\", \\\"{x:714,y:444,t:1527023447156};\\\", \\\"{x:722,y:444,t:1527023447172};\\\", \\\"{x:728,y:444,t:1527023447190};\\\", \\\"{x:731,y:444,t:1527023447206};\\\", \\\"{x:736,y:444,t:1527023447223};\\\", \\\"{x:740,y:444,t:1527023447240};\\\", \\\"{x:743,y:444,t:1527023447256};\\\", \\\"{x:748,y:444,t:1527023447273};\\\", \\\"{x:755,y:444,t:1527023447290};\\\", \\\"{x:761,y:444,t:1527023447306};\\\", \\\"{x:763,y:444,t:1527023447323};\\\", \\\"{x:766,y:443,t:1527023447340};\\\", \\\"{x:767,y:443,t:1527023447357};\\\", \\\"{x:769,y:443,t:1527023447373};\\\", \\\"{x:771,y:443,t:1527023447390};\\\", \\\"{x:776,y:442,t:1527023447406};\\\", \\\"{x:779,y:442,t:1527023447423};\\\", \\\"{x:783,y:442,t:1527023447440};\\\", \\\"{x:787,y:442,t:1527023447456};\\\", \\\"{x:789,y:441,t:1527023447473};\\\", \\\"{x:791,y:441,t:1527023447490};\\\", \\\"{x:792,y:441,t:1527023447507};\\\", \\\"{x:793,y:441,t:1527023447523};\\\", \\\"{x:795,y:441,t:1527023447540};\\\", \\\"{x:797,y:441,t:1527023447556};\\\", \\\"{x:799,y:441,t:1527023447573};\\\", \\\"{x:800,y:441,t:1527023447590};\\\", \\\"{x:801,y:441,t:1527023447606};\\\", \\\"{x:803,y:441,t:1527023447623};\\\", \\\"{x:805,y:441,t:1527023447640};\\\", \\\"{x:809,y:441,t:1527023447656};\\\", \\\"{x:812,y:441,t:1527023447672};\\\", \\\"{x:816,y:441,t:1527023447689};\\\", \\\"{x:818,y:441,t:1527023447706};\\\", \\\"{x:820,y:441,t:1527023447723};\\\", \\\"{x:821,y:441,t:1527023447740};\\\", \\\"{x:822,y:441,t:1527023447756};\\\", \\\"{x:826,y:441,t:1527023447772};\\\", \\\"{x:828,y:441,t:1527023447790};\\\", \\\"{x:829,y:441,t:1527023447812};\\\", \\\"{x:830,y:441,t:1527023447829};\\\", \\\"{x:830,y:441,t:1527023447925};\\\", \\\"{x:831,y:441,t:1527023448221};\\\", \\\"{x:833,y:440,t:1527023448229};\\\", \\\"{x:834,y:440,t:1527023448239};\\\", \\\"{x:840,y:438,t:1527023448256};\\\", \\\"{x:844,y:436,t:1527023448273};\\\", \\\"{x:848,y:433,t:1527023448289};\\\", \\\"{x:855,y:430,t:1527023448306};\\\", \\\"{x:862,y:427,t:1527023448323};\\\", \\\"{x:868,y:423,t:1527023448339};\\\", \\\"{x:873,y:419,t:1527023448356};\\\", \\\"{x:874,y:417,t:1527023448372};\\\", \\\"{x:878,y:417,t:1527023448901};\\\", \\\"{x:892,y:419,t:1527023448908};\\\", \\\"{x:907,y:420,t:1527023448922};\\\", \\\"{x:946,y:422,t:1527023448939};\\\", \\\"{x:980,y:422,t:1527023448955};\\\", \\\"{x:1013,y:422,t:1527023448972};\\\", \\\"{x:1061,y:422,t:1527023448988};\\\", \\\"{x:1088,y:425,t:1527023449005};\\\", \\\"{x:1105,y:428,t:1527023449022};\\\", \\\"{x:1117,y:432,t:1527023449039};\\\", \\\"{x:1125,y:434,t:1527023449055};\\\", \\\"{x:1130,y:436,t:1527023449072};\\\", \\\"{x:1138,y:440,t:1527023449089};\\\", \\\"{x:1149,y:445,t:1527023449105};\\\", \\\"{x:1161,y:450,t:1527023449121};\\\", \\\"{x:1173,y:455,t:1527023449139};\\\", \\\"{x:1188,y:461,t:1527023449155};\\\", \\\"{x:1199,y:465,t:1527023449172};\\\", \\\"{x:1213,y:470,t:1527023449189};\\\", \\\"{x:1222,y:473,t:1527023449205};\\\", \\\"{x:1231,y:476,t:1527023449222};\\\", \\\"{x:1239,y:480,t:1527023449239};\\\", \\\"{x:1247,y:483,t:1527023449254};\\\", \\\"{x:1256,y:487,t:1527023449272};\\\", \\\"{x:1263,y:490,t:1527023449288};\\\", \\\"{x:1268,y:492,t:1527023449305};\\\", \\\"{x:1270,y:493,t:1527023449322};\\\", \\\"{x:1271,y:493,t:1527023449338};\\\", \\\"{x:1273,y:495,t:1527023449355};\\\", \\\"{x:1274,y:495,t:1527023449493};\\\", \\\"{x:1276,y:495,t:1527023449505};\\\", \\\"{x:1282,y:493,t:1527023449522};\\\", \\\"{x:1288,y:490,t:1527023449538};\\\", \\\"{x:1294,y:486,t:1527023449555};\\\", \\\"{x:1297,y:483,t:1527023449573};\\\", \\\"{x:1298,y:482,t:1527023449588};\\\", \\\"{x:1299,y:481,t:1527023449605};\\\", \\\"{x:1300,y:481,t:1527023449765};\\\", \\\"{x:1302,y:479,t:1527023449773};\\\", \\\"{x:1303,y:479,t:1527023449788};\\\", \\\"{x:1308,y:477,t:1527023449805};\\\", \\\"{x:1309,y:476,t:1527023449822};\\\", \\\"{x:1310,y:474,t:1527023449838};\\\", \\\"{x:1311,y:473,t:1527023449855};\\\", \\\"{x:1313,y:472,t:1527023449871};\\\", \\\"{x:1313,y:473,t:1527023450045};\\\", \\\"{x:1313,y:477,t:1527023450055};\\\", \\\"{x:1312,y:478,t:1527023450071};\\\", \\\"{x:1312,y:480,t:1527023450089};\\\", \\\"{x:1311,y:482,t:1527023450105};\\\", \\\"{x:1309,y:486,t:1527023450121};\\\", \\\"{x:1308,y:491,t:1527023450138};\\\", \\\"{x:1308,y:493,t:1527023450181};\\\", \\\"{x:1308,y:494,t:1527023450189};\\\", \\\"{x:1308,y:496,t:1527023450205};\\\", \\\"{x:1308,y:497,t:1527023450222};\\\", \\\"{x:1308,y:499,t:1527023450238};\\\", \\\"{x:1308,y:500,t:1527023450261};\\\", \\\"{x:1308,y:501,t:1527023450285};\\\", \\\"{x:1308,y:502,t:1527023450300};\\\", \\\"{x:1308,y:503,t:1527023450861};\\\", \\\"{x:1309,y:503,t:1527023450877};\\\", \\\"{x:1310,y:503,t:1527023450887};\\\", \\\"{x:1311,y:503,t:1527023450904};\\\", \\\"{x:1312,y:503,t:1527023450921};\\\", \\\"{x:1314,y:503,t:1527023450948};\\\", \\\"{x:1316,y:506,t:1527023453093};\\\", \\\"{x:1318,y:511,t:1527023453102};\\\", \\\"{x:1324,y:520,t:1527023453119};\\\", \\\"{x:1326,y:523,t:1527023453136};\\\", \\\"{x:1328,y:527,t:1527023453152};\\\", \\\"{x:1330,y:529,t:1527023453169};\\\", \\\"{x:1331,y:532,t:1527023453186};\\\", \\\"{x:1331,y:533,t:1527023453229};\\\", \\\"{x:1332,y:534,t:1527023453237};\\\", \\\"{x:1333,y:535,t:1527023453261};\\\", \\\"{x:1333,y:536,t:1527023453309};\\\", \\\"{x:1333,y:537,t:1527023453319};\\\", \\\"{x:1335,y:539,t:1527023453336};\\\", \\\"{x:1335,y:540,t:1527023453352};\\\", \\\"{x:1335,y:541,t:1527023453369};\\\", \\\"{x:1336,y:543,t:1527023453385};\\\", \\\"{x:1338,y:545,t:1527023453402};\\\", \\\"{x:1339,y:546,t:1527023453420};\\\", \\\"{x:1340,y:548,t:1527023453435};\\\", \\\"{x:1341,y:549,t:1527023453453};\\\", \\\"{x:1342,y:551,t:1527023453468};\\\", \\\"{x:1344,y:554,t:1527023453485};\\\", \\\"{x:1345,y:555,t:1527023453503};\\\", \\\"{x:1345,y:556,t:1527023453520};\\\", \\\"{x:1347,y:558,t:1527023453556};\\\", \\\"{x:1348,y:558,t:1527023453629};\\\", \\\"{x:1348,y:559,t:1527023453693};\\\", \\\"{x:1349,y:560,t:1527023453740};\\\", \\\"{x:1350,y:561,t:1527023453765};\\\", \\\"{x:1351,y:562,t:1527023453780};\\\", \\\"{x:1351,y:563,t:1527023453813};\\\", \\\"{x:1352,y:563,t:1527023453836};\\\", \\\"{x:1352,y:564,t:1527023453853};\\\", \\\"{x:1354,y:566,t:1527023453868};\\\", \\\"{x:1354,y:567,t:1527023453933};\\\", \\\"{x:1355,y:567,t:1527023453940};\\\", \\\"{x:1355,y:569,t:1527023457997};\\\", \\\"{x:1355,y:579,t:1527023458004};\\\", \\\"{x:1355,y:590,t:1527023458016};\\\", \\\"{x:1352,y:616,t:1527023458033};\\\", \\\"{x:1350,y:640,t:1527023458050};\\\", \\\"{x:1350,y:660,t:1527023458065};\\\", \\\"{x:1350,y:679,t:1527023458082};\\\", \\\"{x:1347,y:697,t:1527023458100};\\\", \\\"{x:1345,y:714,t:1527023458116};\\\", \\\"{x:1341,y:740,t:1527023458133};\\\", \\\"{x:1340,y:755,t:1527023458148};\\\", \\\"{x:1339,y:761,t:1527023458166};\\\", \\\"{x:1339,y:763,t:1527023458183};\\\", \\\"{x:1339,y:764,t:1527023458199};\\\", \\\"{x:1339,y:766,t:1527023458216};\\\", \\\"{x:1338,y:767,t:1527023458301};\\\", \\\"{x:1338,y:768,t:1527023458316};\\\", \\\"{x:1339,y:768,t:1527023458605};\\\", \\\"{x:1340,y:768,t:1527023458620};\\\", \\\"{x:1341,y:768,t:1527023458653};\\\", \\\"{x:1342,y:768,t:1527023458665};\\\", \\\"{x:1344,y:767,t:1527023458682};\\\", \\\"{x:1345,y:767,t:1527023458715};\\\", \\\"{x:1346,y:766,t:1527023458732};\\\", \\\"{x:1349,y:765,t:1527023458749};\\\", \\\"{x:1350,y:763,t:1527023459157};\\\", \\\"{x:1351,y:762,t:1527023459237};\\\", \\\"{x:1352,y:761,t:1527023459260};\\\", \\\"{x:1353,y:760,t:1527023459333};\\\", \\\"{x:1353,y:759,t:1527023459485};\\\", \\\"{x:1353,y:758,t:1527023459917};\\\", \\\"{x:1352,y:758,t:1527023459949};\\\", \\\"{x:1351,y:758,t:1527023460005};\\\", \\\"{x:1350,y:759,t:1527023460357};\\\", \\\"{x:1350,y:760,t:1527023460429};\\\", \\\"{x:1350,y:762,t:1527023461517};\\\", \\\"{x:1349,y:763,t:1527023461530};\\\", \\\"{x:1349,y:764,t:1527023461546};\\\", \\\"{x:1348,y:766,t:1527023461563};\\\", \\\"{x:1348,y:767,t:1527023461580};\\\", \\\"{x:1347,y:769,t:1527023461597};\\\", \\\"{x:1347,y:770,t:1527023461628};\\\", \\\"{x:1347,y:771,t:1527023461637};\\\", \\\"{x:1347,y:772,t:1527023461652};\\\", \\\"{x:1347,y:773,t:1527023461668};\\\", \\\"{x:1347,y:774,t:1527023461684};\\\", \\\"{x:1347,y:775,t:1527023461701};\\\", \\\"{x:1346,y:776,t:1527023461713};\\\", \\\"{x:1346,y:777,t:1527023461729};\\\", \\\"{x:1345,y:778,t:1527023461746};\\\", \\\"{x:1345,y:779,t:1527023461764};\\\", \\\"{x:1345,y:781,t:1527023461779};\\\", \\\"{x:1344,y:785,t:1527023461796};\\\", \\\"{x:1343,y:787,t:1527023461814};\\\", \\\"{x:1343,y:790,t:1527023461830};\\\", \\\"{x:1342,y:792,t:1527023461846};\\\", \\\"{x:1342,y:796,t:1527023461863};\\\", \\\"{x:1340,y:799,t:1527023461880};\\\", \\\"{x:1339,y:803,t:1527023461897};\\\", \\\"{x:1338,y:806,t:1527023461912};\\\", \\\"{x:1337,y:809,t:1527023461929};\\\", \\\"{x:1335,y:812,t:1527023461947};\\\", \\\"{x:1332,y:818,t:1527023461962};\\\", \\\"{x:1331,y:821,t:1527023461980};\\\", \\\"{x:1328,y:827,t:1527023461996};\\\", \\\"{x:1325,y:831,t:1527023462012};\\\", \\\"{x:1322,y:837,t:1527023462029};\\\", \\\"{x:1319,y:841,t:1527023462046};\\\", \\\"{x:1316,y:846,t:1527023462063};\\\", \\\"{x:1313,y:850,t:1527023462079};\\\", \\\"{x:1312,y:853,t:1527023462096};\\\", \\\"{x:1310,y:856,t:1527023462112};\\\", \\\"{x:1308,y:859,t:1527023462129};\\\", \\\"{x:1306,y:862,t:1527023462147};\\\", \\\"{x:1303,y:868,t:1527023462162};\\\", \\\"{x:1300,y:873,t:1527023462180};\\\", \\\"{x:1298,y:877,t:1527023462196};\\\", \\\"{x:1295,y:881,t:1527023462213};\\\", \\\"{x:1293,y:885,t:1527023462229};\\\", \\\"{x:1291,y:888,t:1527023462246};\\\", \\\"{x:1290,y:890,t:1527023462262};\\\", \\\"{x:1287,y:895,t:1527023462280};\\\", \\\"{x:1284,y:900,t:1527023462296};\\\", \\\"{x:1282,y:903,t:1527023462312};\\\", \\\"{x:1281,y:906,t:1527023462329};\\\", \\\"{x:1279,y:908,t:1527023462346};\\\", \\\"{x:1277,y:911,t:1527023462363};\\\", \\\"{x:1276,y:913,t:1527023462380};\\\", \\\"{x:1274,y:916,t:1527023462396};\\\", \\\"{x:1272,y:920,t:1527023462412};\\\", \\\"{x:1270,y:925,t:1527023462430};\\\", \\\"{x:1268,y:928,t:1527023462445};\\\", \\\"{x:1268,y:930,t:1527023462462};\\\", \\\"{x:1267,y:931,t:1527023462480};\\\", \\\"{x:1266,y:932,t:1527023462500};\\\", \\\"{x:1266,y:933,t:1527023462512};\\\", \\\"{x:1265,y:935,t:1527023462530};\\\", \\\"{x:1264,y:937,t:1527023462546};\\\", \\\"{x:1263,y:938,t:1527023462562};\\\", \\\"{x:1263,y:940,t:1527023462580};\\\", \\\"{x:1261,y:942,t:1527023462595};\\\", \\\"{x:1260,y:945,t:1527023462612};\\\", \\\"{x:1259,y:948,t:1527023462629};\\\", \\\"{x:1257,y:950,t:1527023462645};\\\", \\\"{x:1255,y:954,t:1527023462663};\\\", \\\"{x:1250,y:958,t:1527023462679};\\\", \\\"{x:1247,y:962,t:1527023462695};\\\", \\\"{x:1245,y:964,t:1527023462713};\\\", \\\"{x:1244,y:965,t:1527023462728};\\\", \\\"{x:1243,y:966,t:1527023462749};\\\", \\\"{x:1243,y:967,t:1527023462789};\\\", \\\"{x:1244,y:966,t:1527023463237};\\\", \\\"{x:1245,y:966,t:1527023463277};\\\", \\\"{x:1246,y:966,t:1527023463284};\\\", \\\"{x:1246,y:965,t:1527023463301};\\\", \\\"{x:1247,y:965,t:1527023463311};\\\", \\\"{x:1247,y:964,t:1527023463328};\\\", \\\"{x:1248,y:963,t:1527023463346};\\\", \\\"{x:1249,y:963,t:1527023463362};\\\", \\\"{x:1250,y:962,t:1527023463397};\\\", \\\"{x:1251,y:961,t:1527023463413};\\\", \\\"{x:1252,y:961,t:1527023463436};\\\", \\\"{x:1253,y:961,t:1527023463445};\\\", \\\"{x:1254,y:960,t:1527023463462};\\\", \\\"{x:1254,y:959,t:1527023463485};\\\", \\\"{x:1255,y:959,t:1527023463496};\\\", \\\"{x:1256,y:958,t:1527023463511};\\\", \\\"{x:1258,y:957,t:1527023463528};\\\", \\\"{x:1259,y:957,t:1527023463549};\\\", \\\"{x:1260,y:956,t:1527023463565};\\\", \\\"{x:1261,y:955,t:1527023463582};\\\", \\\"{x:1262,y:955,t:1527023463599};\\\", \\\"{x:1264,y:953,t:1527023463615};\\\", \\\"{x:1267,y:952,t:1527023463632};\\\", \\\"{x:1268,y:950,t:1527023463648};\\\", \\\"{x:1272,y:948,t:1527023463665};\\\", \\\"{x:1274,y:946,t:1527023463682};\\\", \\\"{x:1275,y:946,t:1527023463698};\\\", \\\"{x:1276,y:945,t:1527023463715};\\\", \\\"{x:1277,y:942,t:1527023463732};\\\", \\\"{x:1279,y:937,t:1527023463748};\\\", \\\"{x:1281,y:935,t:1527023463765};\\\", \\\"{x:1283,y:930,t:1527023463782};\\\", \\\"{x:1284,y:927,t:1527023463798};\\\", \\\"{x:1287,y:924,t:1527023463815};\\\", \\\"{x:1288,y:919,t:1527023463831};\\\", \\\"{x:1288,y:918,t:1527023463848};\\\", \\\"{x:1289,y:915,t:1527023463865};\\\", \\\"{x:1290,y:911,t:1527023463882};\\\", \\\"{x:1292,y:907,t:1527023463897};\\\", \\\"{x:1294,y:902,t:1527023463914};\\\", \\\"{x:1296,y:897,t:1527023463932};\\\", \\\"{x:1296,y:891,t:1527023463948};\\\", \\\"{x:1298,y:888,t:1527023463965};\\\", \\\"{x:1299,y:883,t:1527023463982};\\\", \\\"{x:1300,y:874,t:1527023463998};\\\", \\\"{x:1302,y:865,t:1527023464015};\\\", \\\"{x:1305,y:852,t:1527023464031};\\\", \\\"{x:1306,y:847,t:1527023464048};\\\", \\\"{x:1308,y:845,t:1527023464065};\\\", \\\"{x:1308,y:841,t:1527023464081};\\\", \\\"{x:1311,y:838,t:1527023464097};\\\", \\\"{x:1311,y:834,t:1527023464114};\\\", \\\"{x:1312,y:827,t:1527023464130};\\\", \\\"{x:1315,y:819,t:1527023464148};\\\", \\\"{x:1316,y:810,t:1527023464165};\\\", \\\"{x:1319,y:807,t:1527023464180};\\\", \\\"{x:1319,y:805,t:1527023464197};\\\", \\\"{x:1321,y:803,t:1527023464215};\\\", \\\"{x:1322,y:802,t:1527023464231};\\\", \\\"{x:1324,y:798,t:1527023464247};\\\", \\\"{x:1326,y:792,t:1527023464265};\\\", \\\"{x:1329,y:786,t:1527023464281};\\\", \\\"{x:1331,y:784,t:1527023464298};\\\", \\\"{x:1333,y:781,t:1527023464315};\\\", \\\"{x:1333,y:779,t:1527023464331};\\\", \\\"{x:1334,y:778,t:1527023464348};\\\", \\\"{x:1335,y:777,t:1527023464365};\\\", \\\"{x:1336,y:776,t:1527023464380};\\\", \\\"{x:1337,y:774,t:1527023464398};\\\", \\\"{x:1339,y:771,t:1527023464415};\\\", \\\"{x:1340,y:769,t:1527023464431};\\\", \\\"{x:1341,y:767,t:1527023464448};\\\", \\\"{x:1343,y:765,t:1527023464465};\\\", \\\"{x:1343,y:764,t:1527023464504};\\\", \\\"{x:1343,y:763,t:1527023464514};\\\", \\\"{x:1344,y:761,t:1527023464531};\\\", \\\"{x:1345,y:760,t:1527023464547};\\\", \\\"{x:1345,y:759,t:1527023464563};\\\", \\\"{x:1344,y:759,t:1527023464864};\\\", \\\"{x:1338,y:760,t:1527023464881};\\\", \\\"{x:1334,y:760,t:1527023464897};\\\", \\\"{x:1328,y:761,t:1527023464914};\\\", \\\"{x:1325,y:761,t:1527023464931};\\\", \\\"{x:1323,y:762,t:1527023464947};\\\", \\\"{x:1321,y:763,t:1527023464965};\\\", \\\"{x:1320,y:763,t:1527023464984};\\\", \\\"{x:1319,y:763,t:1527023465000};\\\", \\\"{x:1318,y:763,t:1527023465014};\\\", \\\"{x:1317,y:764,t:1527023465031};\\\", \\\"{x:1316,y:764,t:1527023465080};\\\", \\\"{x:1315,y:764,t:1527023465088};\\\", \\\"{x:1314,y:764,t:1527023465104};\\\", \\\"{x:1314,y:765,t:1527023465114};\\\", \\\"{x:1310,y:766,t:1527023465131};\\\", \\\"{x:1309,y:766,t:1527023465147};\\\", \\\"{x:1307,y:767,t:1527023465164};\\\", \\\"{x:1306,y:767,t:1527023465180};\\\", \\\"{x:1305,y:768,t:1527023465197};\\\", \\\"{x:1303,y:769,t:1527023465213};\\\", \\\"{x:1301,y:769,t:1527023465230};\\\", \\\"{x:1300,y:770,t:1527023465247};\\\", \\\"{x:1297,y:771,t:1527023465263};\\\", \\\"{x:1295,y:771,t:1527023465281};\\\", \\\"{x:1293,y:772,t:1527023465297};\\\", \\\"{x:1289,y:772,t:1527023465314};\\\", \\\"{x:1287,y:773,t:1527023465331};\\\", \\\"{x:1285,y:774,t:1527023465347};\\\", \\\"{x:1280,y:774,t:1527023465363};\\\", \\\"{x:1279,y:774,t:1527023465380};\\\", \\\"{x:1277,y:774,t:1527023465396};\\\", \\\"{x:1276,y:775,t:1527023465413};\\\", \\\"{x:1274,y:775,t:1527023465431};\\\", \\\"{x:1272,y:776,t:1527023465447};\\\", \\\"{x:1270,y:777,t:1527023465463};\\\", \\\"{x:1268,y:777,t:1527023465481};\\\", \\\"{x:1265,y:778,t:1527023465496};\\\", \\\"{x:1262,y:780,t:1527023465514};\\\", \\\"{x:1260,y:781,t:1527023465530};\\\", \\\"{x:1255,y:784,t:1527023465547};\\\", \\\"{x:1251,y:785,t:1527023465564};\\\", \\\"{x:1248,y:788,t:1527023465580};\\\", \\\"{x:1244,y:791,t:1527023465597};\\\", \\\"{x:1242,y:793,t:1527023465613};\\\", \\\"{x:1238,y:795,t:1527023465630};\\\", \\\"{x:1235,y:796,t:1527023465647};\\\", \\\"{x:1229,y:802,t:1527023465663};\\\", \\\"{x:1226,y:804,t:1527023465679};\\\", \\\"{x:1223,y:806,t:1527023465697};\\\", \\\"{x:1219,y:808,t:1527023465714};\\\", \\\"{x:1218,y:809,t:1527023465730};\\\", \\\"{x:1216,y:812,t:1527023465747};\\\", \\\"{x:1215,y:813,t:1527023465764};\\\", \\\"{x:1214,y:815,t:1527023465783};\\\", \\\"{x:1214,y:816,t:1527023465796};\\\", \\\"{x:1213,y:817,t:1527023465813};\\\", \\\"{x:1213,y:818,t:1527023465831};\\\", \\\"{x:1212,y:818,t:1527023465847};\\\", \\\"{x:1212,y:819,t:1527023465871};\\\", \\\"{x:1212,y:820,t:1527023465903};\\\", \\\"{x:1212,y:821,t:1527023465920};\\\", \\\"{x:1212,y:822,t:1527023465951};\\\", \\\"{x:1212,y:823,t:1527023466007};\\\", \\\"{x:1212,y:824,t:1527023466015};\\\", \\\"{x:1213,y:825,t:1527023466032};\\\", \\\"{x:1214,y:825,t:1527023466079};\\\", \\\"{x:1215,y:826,t:1527023466096};\\\", \\\"{x:1216,y:826,t:1527023466119};\\\", \\\"{x:1216,y:827,t:1527023466200};\\\", \\\"{x:1217,y:827,t:1527023466213};\\\", \\\"{x:1218,y:828,t:1527023466230};\\\", \\\"{x:1219,y:829,t:1527023466246};\\\", \\\"{x:1221,y:830,t:1527023466295};\\\", \\\"{x:1222,y:830,t:1527023467240};\\\", \\\"{x:1223,y:829,t:1527023467263};\\\", \\\"{x:1223,y:828,t:1527023467279};\\\", \\\"{x:1223,y:826,t:1527023467296};\\\", \\\"{x:1224,y:824,t:1527023467312};\\\", \\\"{x:1225,y:822,t:1527023467329};\\\", \\\"{x:1225,y:821,t:1527023467346};\\\", \\\"{x:1227,y:818,t:1527023467361};\\\", \\\"{x:1227,y:816,t:1527023467379};\\\", \\\"{x:1227,y:815,t:1527023467396};\\\", \\\"{x:1229,y:813,t:1527023467412};\\\", \\\"{x:1229,y:812,t:1527023467428};\\\", \\\"{x:1229,y:811,t:1527023467455};\\\", \\\"{x:1229,y:810,t:1527023467463};\\\", \\\"{x:1230,y:809,t:1527023467479};\\\", \\\"{x:1230,y:808,t:1527023467503};\\\", \\\"{x:1230,y:807,t:1527023467511};\\\", \\\"{x:1230,y:806,t:1527023467528};\\\", \\\"{x:1231,y:804,t:1527023467551};\\\", \\\"{x:1232,y:804,t:1527023467567};\\\", \\\"{x:1232,y:803,t:1527023467583};\\\", \\\"{x:1232,y:802,t:1527023467616};\\\", \\\"{x:1229,y:804,t:1527023467768};\\\", \\\"{x:1225,y:809,t:1527023467780};\\\", \\\"{x:1221,y:814,t:1527023467795};\\\", \\\"{x:1217,y:818,t:1527023467812};\\\", \\\"{x:1213,y:822,t:1527023467829};\\\", \\\"{x:1210,y:825,t:1527023467845};\\\", \\\"{x:1209,y:826,t:1527023467862};\\\", \\\"{x:1207,y:827,t:1527023467879};\\\", \\\"{x:1206,y:828,t:1527023467894};\\\", \\\"{x:1204,y:831,t:1527023467911};\\\", \\\"{x:1204,y:833,t:1527023467929};\\\", \\\"{x:1203,y:833,t:1527023467944};\\\", \\\"{x:1206,y:832,t:1527023468527};\\\", \\\"{x:1213,y:829,t:1527023468545};\\\", \\\"{x:1218,y:826,t:1527023468562};\\\", \\\"{x:1222,y:825,t:1527023468578};\\\", \\\"{x:1225,y:825,t:1527023468595};\\\", \\\"{x:1224,y:825,t:1527023469232};\\\", \\\"{x:1221,y:827,t:1527023469244};\\\", \\\"{x:1215,y:829,t:1527023469261};\\\", \\\"{x:1210,y:831,t:1527023469277};\\\", \\\"{x:1205,y:833,t:1527023469294};\\\", \\\"{x:1205,y:834,t:1527023469311};\\\", \\\"{x:1210,y:832,t:1527023473560};\\\", \\\"{x:1217,y:828,t:1527023473574};\\\", \\\"{x:1241,y:822,t:1527023473591};\\\", \\\"{x:1255,y:818,t:1527023473608};\\\", \\\"{x:1267,y:817,t:1527023473624};\\\", \\\"{x:1275,y:814,t:1527023473641};\\\", \\\"{x:1278,y:814,t:1527023473658};\\\", \\\"{x:1282,y:813,t:1527023473674};\\\", \\\"{x:1288,y:809,t:1527023473691};\\\", \\\"{x:1295,y:807,t:1527023473708};\\\", \\\"{x:1303,y:801,t:1527023473724};\\\", \\\"{x:1313,y:797,t:1527023473741};\\\", \\\"{x:1320,y:795,t:1527023473758};\\\", \\\"{x:1326,y:792,t:1527023473774};\\\", \\\"{x:1330,y:792,t:1527023473791};\\\", \\\"{x:1338,y:792,t:1527023473807};\\\", \\\"{x:1349,y:791,t:1527023473824};\\\", \\\"{x:1367,y:790,t:1527023473841};\\\", \\\"{x:1388,y:787,t:1527023473859};\\\", \\\"{x:1411,y:787,t:1527023473874};\\\", \\\"{x:1432,y:787,t:1527023473891};\\\", \\\"{x:1453,y:787,t:1527023473908};\\\", \\\"{x:1463,y:787,t:1527023473924};\\\", \\\"{x:1473,y:789,t:1527023473941};\\\", \\\"{x:1480,y:791,t:1527023473958};\\\", \\\"{x:1483,y:792,t:1527023473974};\\\", \\\"{x:1484,y:792,t:1527023473991};\\\", \\\"{x:1486,y:793,t:1527023474007};\\\", \\\"{x:1487,y:793,t:1527023474087};\\\", \\\"{x:1487,y:795,t:1527023474094};\\\", \\\"{x:1487,y:798,t:1527023474107};\\\", \\\"{x:1487,y:801,t:1527023474124};\\\", \\\"{x:1483,y:811,t:1527023474141};\\\", \\\"{x:1480,y:819,t:1527023474157};\\\", \\\"{x:1473,y:828,t:1527023474174};\\\", \\\"{x:1469,y:835,t:1527023474191};\\\", \\\"{x:1469,y:836,t:1527023474207};\\\", \\\"{x:1469,y:837,t:1527023474560};\\\", \\\"{x:1471,y:837,t:1527023474592};\\\", \\\"{x:1472,y:837,t:1527023474607};\\\", \\\"{x:1473,y:837,t:1527023474623};\\\", \\\"{x:1474,y:837,t:1527023474640};\\\", \\\"{x:1475,y:836,t:1527023474657};\\\", \\\"{x:1476,y:835,t:1527023474679};\\\", \\\"{x:1477,y:835,t:1527023474711};\\\", \\\"{x:1477,y:833,t:1527023475432};\\\", \\\"{x:1477,y:830,t:1527023475440};\\\", \\\"{x:1477,y:828,t:1527023475456};\\\", \\\"{x:1477,y:827,t:1527023475473};\\\", \\\"{x:1478,y:826,t:1527023475490};\\\", \\\"{x:1478,y:825,t:1527023492799};\\\", \\\"{x:1477,y:825,t:1527023492823};\\\", \\\"{x:1476,y:825,t:1527023492831};\\\", \\\"{x:1475,y:825,t:1527023492844};\\\", \\\"{x:1473,y:825,t:1527023492861};\\\", \\\"{x:1471,y:825,t:1527023492879};\\\", \\\"{x:1469,y:824,t:1527023492894};\\\", \\\"{x:1468,y:824,t:1527023492911};\\\", \\\"{x:1467,y:824,t:1527023492935};\\\", \\\"{x:1466,y:823,t:1527023492951};\\\", \\\"{x:1465,y:823,t:1527023492967};\\\", \\\"{x:1463,y:823,t:1527023492983};\\\", \\\"{x:1461,y:822,t:1527023492994};\\\", \\\"{x:1459,y:821,t:1527023493011};\\\", \\\"{x:1458,y:821,t:1527023493028};\\\", \\\"{x:1455,y:820,t:1527023493044};\\\", \\\"{x:1453,y:820,t:1527023493061};\\\", \\\"{x:1453,y:819,t:1527023493078};\\\", \\\"{x:1452,y:819,t:1527023493094};\\\", \\\"{x:1450,y:819,t:1527023493111};\\\", \\\"{x:1448,y:819,t:1527023493128};\\\", \\\"{x:1446,y:819,t:1527023493144};\\\", \\\"{x:1443,y:817,t:1527023493161};\\\", \\\"{x:1439,y:817,t:1527023493178};\\\", \\\"{x:1431,y:814,t:1527023493194};\\\", \\\"{x:1418,y:810,t:1527023493211};\\\", \\\"{x:1394,y:803,t:1527023493228};\\\", \\\"{x:1353,y:787,t:1527023493244};\\\", \\\"{x:1270,y:752,t:1527023493261};\\\", \\\"{x:1184,y:726,t:1527023493277};\\\", \\\"{x:1094,y:694,t:1527023493294};\\\", \\\"{x:973,y:666,t:1527023493311};\\\", \\\"{x:890,y:653,t:1527023493326};\\\", \\\"{x:806,y:640,t:1527023493344};\\\", \\\"{x:735,y:626,t:1527023493361};\\\", \\\"{x:663,y:615,t:1527023493377};\\\", \\\"{x:576,y:614,t:1527023493394};\\\", \\\"{x:507,y:614,t:1527023493413};\\\", \\\"{x:467,y:614,t:1527023493430};\\\", \\\"{x:424,y:612,t:1527023493447};\\\", \\\"{x:396,y:612,t:1527023493463};\\\", \\\"{x:374,y:613,t:1527023493480};\\\", \\\"{x:356,y:622,t:1527023493497};\\\", \\\"{x:350,y:629,t:1527023493513};\\\", \\\"{x:345,y:636,t:1527023493530};\\\", \\\"{x:341,y:643,t:1527023493549};\\\", \\\"{x:340,y:652,t:1527023493563};\\\", \\\"{x:341,y:661,t:1527023493580};\\\", \\\"{x:350,y:670,t:1527023493597};\\\", \\\"{x:360,y:675,t:1527023493613};\\\", \\\"{x:371,y:679,t:1527023493630};\\\", \\\"{x:390,y:685,t:1527023493647};\\\", \\\"{x:407,y:686,t:1527023493663};\\\", \\\"{x:416,y:690,t:1527023493680};\\\", \\\"{x:421,y:691,t:1527023493697};\\\", \\\"{x:436,y:694,t:1527023493713};\\\", \\\"{x:437,y:694,t:1527023493730};\\\", \\\"{x:434,y:695,t:1527023493823};\\\", \\\"{x:432,y:697,t:1527023493831};\\\", \\\"{x:427,y:703,t:1527023493847};\\\", \\\"{x:423,y:716,t:1527023493863};\\\", \\\"{x:422,y:723,t:1527023493880};\\\", \\\"{x:421,y:726,t:1527023493897};\\\", \\\"{x:424,y:726,t:1527023494015};\\\", \\\"{x:428,y:726,t:1527023494030};\\\", \\\"{x:439,y:726,t:1527023494046};\\\", \\\"{x:443,y:727,t:1527023494063};\\\", \\\"{x:445,y:727,t:1527023494080};\\\", \\\"{x:448,y:728,t:1527023494097};\\\", \\\"{x:450,y:730,t:1527023494114};\\\", \\\"{x:454,y:732,t:1527023494131};\\\", \\\"{x:460,y:736,t:1527023494147};\\\", \\\"{x:472,y:741,t:1527023494164};\\\", \\\"{x:479,y:744,t:1527023494181};\\\", \\\"{x:487,y:748,t:1527023494197};\\\", \\\"{x:489,y:748,t:1527023494213};\\\", \\\"{x:490,y:748,t:1527023494231};\\\", \\\"{x:490,y:747,t:1527023495135};\\\", \\\"{x:490,y:746,t:1527023495148};\\\", \\\"{x:488,y:741,t:1527023495165};\\\", \\\"{x:484,y:737,t:1527023495181};\\\", \\\"{x:474,y:729,t:1527023495197};\\\", \\\"{x:458,y:721,t:1527023495214};\\\", \\\"{x:455,y:719,t:1527023495230};\\\", \\\"{x:453,y:719,t:1527023495248};\\\" ] }, { \\\"rt\\\": 24306, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 13, \\\"time_elapsed\\\": 536179, \\\"internal_node_id\\\": \\\"0.0-6.0-3.0\\\", \\\"subject\\\": \\\"8LK9M\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"hotel\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime+before+endtime+during\\\", \\\"q\\\": 9, \\\"clicks\\\": 1.5, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-J -E -E -F -F \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:452,y:719,t:1527023495960};\\\", \\\"{x:451,y:719,t:1527023495978};\\\", \\\"{x:450,y:719,t:1527023495999};\\\", \\\"{x:449,y:719,t:1527023496015};\\\", \\\"{x:449,y:717,t:1527023496231};\\\", \\\"{x:449,y:713,t:1527023496239};\\\", \\\"{x:449,y:709,t:1527023496248};\\\", \\\"{x:467,y:654,t:1527023496331};\\\", \\\"{x:473,y:635,t:1527023496350};\\\", \\\"{x:479,y:608,t:1527023496368};\\\", \\\"{x:484,y:598,t:1527023496383};\\\", \\\"{x:490,y:574,t:1527023496399};\\\", \\\"{x:493,y:553,t:1527023496416};\\\", \\\"{x:496,y:536,t:1527023496432};\\\", \\\"{x:502,y:522,t:1527023496450};\\\", \\\"{x:504,y:511,t:1527023496466};\\\", \\\"{x:511,y:498,t:1527023496482};\\\", \\\"{x:514,y:489,t:1527023496499};\\\", \\\"{x:517,y:484,t:1527023496517};\\\", \\\"{x:519,y:480,t:1527023496532};\\\", \\\"{x:522,y:476,t:1527023496549};\\\", \\\"{x:523,y:473,t:1527023496566};\\\", \\\"{x:525,y:471,t:1527023496581};\\\", \\\"{x:526,y:469,t:1527023496599};\\\", \\\"{x:526,y:467,t:1527023496616};\\\", \\\"{x:527,y:466,t:1527023496632};\\\", \\\"{x:528,y:463,t:1527023496648};\\\", \\\"{x:528,y:461,t:1527023496666};\\\", \\\"{x:529,y:460,t:1527023497431};\\\", \\\"{x:530,y:460,t:1527023497439};\\\", \\\"{x:532,y:460,t:1527023497450};\\\", \\\"{x:534,y:461,t:1527023497467};\\\", \\\"{x:538,y:461,t:1527023497483};\\\", \\\"{x:544,y:461,t:1527023497500};\\\", \\\"{x:546,y:461,t:1527023497517};\\\", \\\"{x:547,y:461,t:1527023497533};\\\", \\\"{x:549,y:461,t:1527023497550};\\\", \\\"{x:550,y:461,t:1527023497567};\\\", \\\"{x:551,y:462,t:1527023497655};\\\", \\\"{x:552,y:463,t:1527023497783};\\\", \\\"{x:555,y:463,t:1527023497800};\\\", \\\"{x:561,y:463,t:1527023497817};\\\", \\\"{x:566,y:462,t:1527023497834};\\\", \\\"{x:576,y:459,t:1527023497850};\\\", \\\"{x:594,y:455,t:1527023497867};\\\", \\\"{x:610,y:453,t:1527023497884};\\\", \\\"{x:621,y:450,t:1527023497900};\\\", \\\"{x:633,y:445,t:1527023497917};\\\", \\\"{x:639,y:443,t:1527023497934};\\\", \\\"{x:644,y:440,t:1527023497950};\\\", \\\"{x:647,y:439,t:1527023497967};\\\", \\\"{x:649,y:439,t:1527023497984};\\\", \\\"{x:649,y:438,t:1527023498000};\\\", \\\"{x:650,y:437,t:1527023498017};\\\", \\\"{x:652,y:437,t:1527023498063};\\\", \\\"{x:652,y:436,t:1527023498071};\\\", \\\"{x:653,y:436,t:1527023498085};\\\", \\\"{x:654,y:436,t:1527023498101};\\\", \\\"{x:656,y:436,t:1527023498117};\\\", \\\"{x:659,y:436,t:1527023498134};\\\", \\\"{x:669,y:436,t:1527023498150};\\\", \\\"{x:680,y:436,t:1527023498167};\\\", \\\"{x:695,y:436,t:1527023498184};\\\", \\\"{x:716,y:436,t:1527023498201};\\\", \\\"{x:737,y:436,t:1527023498217};\\\", \\\"{x:759,y:436,t:1527023498234};\\\", \\\"{x:782,y:436,t:1527023498251};\\\", \\\"{x:804,y:436,t:1527023498267};\\\", \\\"{x:824,y:436,t:1527023498284};\\\", \\\"{x:846,y:436,t:1527023498301};\\\", \\\"{x:863,y:438,t:1527023498317};\\\", \\\"{x:876,y:439,t:1527023498334};\\\", \\\"{x:888,y:442,t:1527023498351};\\\", \\\"{x:892,y:443,t:1527023498367};\\\", \\\"{x:895,y:444,t:1527023498384};\\\", \\\"{x:897,y:444,t:1527023498401};\\\", \\\"{x:899,y:444,t:1527023498418};\\\", \\\"{x:902,y:446,t:1527023498435};\\\", \\\"{x:904,y:446,t:1527023498451};\\\", \\\"{x:907,y:446,t:1527023498469};\\\", \\\"{x:913,y:447,t:1527023498485};\\\", \\\"{x:918,y:448,t:1527023498501};\\\", \\\"{x:926,y:450,t:1527023498518};\\\", \\\"{x:934,y:450,t:1527023498535};\\\", \\\"{x:952,y:452,t:1527023498551};\\\", \\\"{x:965,y:455,t:1527023498568};\\\", \\\"{x:978,y:456,t:1527023498584};\\\", \\\"{x:991,y:458,t:1527023498601};\\\", \\\"{x:1005,y:462,t:1527023498618};\\\", \\\"{x:1026,y:467,t:1527023498634};\\\", \\\"{x:1052,y:474,t:1527023498651};\\\", \\\"{x:1079,y:482,t:1527023498668};\\\", \\\"{x:1107,y:486,t:1527023498684};\\\", \\\"{x:1145,y:491,t:1527023498701};\\\", \\\"{x:1184,y:496,t:1527023498718};\\\", \\\"{x:1222,y:503,t:1527023498734};\\\", \\\"{x:1282,y:511,t:1527023498751};\\\", \\\"{x:1319,y:518,t:1527023498768};\\\", \\\"{x:1352,y:526,t:1527023498784};\\\", \\\"{x:1383,y:536,t:1527023498801};\\\", \\\"{x:1409,y:544,t:1527023498818};\\\", \\\"{x:1436,y:556,t:1527023498835};\\\", \\\"{x:1457,y:566,t:1527023498851};\\\", \\\"{x:1476,y:576,t:1527023498868};\\\", \\\"{x:1494,y:585,t:1527023498885};\\\", \\\"{x:1507,y:594,t:1527023498901};\\\", \\\"{x:1517,y:603,t:1527023498918};\\\", \\\"{x:1526,y:614,t:1527023498935};\\\", \\\"{x:1532,y:622,t:1527023498951};\\\", \\\"{x:1536,y:630,t:1527023498968};\\\", \\\"{x:1540,y:638,t:1527023498985};\\\", \\\"{x:1542,y:647,t:1527023499001};\\\", \\\"{x:1542,y:653,t:1527023499018};\\\", \\\"{x:1542,y:655,t:1527023499035};\\\", \\\"{x:1541,y:656,t:1527023499071};\\\", \\\"{x:1540,y:656,t:1527023499085};\\\", \\\"{x:1538,y:656,t:1527023499101};\\\", \\\"{x:1537,y:656,t:1527023499119};\\\", \\\"{x:1536,y:656,t:1527023499552};\\\", \\\"{x:1535,y:656,t:1527023499567};\\\", \\\"{x:1532,y:656,t:1527023499575};\\\", \\\"{x:1526,y:654,t:1527023499585};\\\", \\\"{x:1503,y:646,t:1527023499603};\\\", \\\"{x:1481,y:639,t:1527023499619};\\\", \\\"{x:1453,y:634,t:1527023499635};\\\", \\\"{x:1409,y:623,t:1527023499652};\\\", \\\"{x:1370,y:612,t:1527023499669};\\\", \\\"{x:1338,y:603,t:1527023499685};\\\", \\\"{x:1311,y:595,t:1527023499702};\\\", \\\"{x:1270,y:583,t:1527023499718};\\\", \\\"{x:1249,y:579,t:1527023499735};\\\", \\\"{x:1235,y:578,t:1527023499753};\\\", \\\"{x:1230,y:578,t:1527023499769};\\\", \\\"{x:1227,y:578,t:1527023499785};\\\", \\\"{x:1225,y:578,t:1527023499802};\\\", \\\"{x:1223,y:583,t:1527023499819};\\\", \\\"{x:1219,y:605,t:1527023499835};\\\", \\\"{x:1216,y:636,t:1527023499852};\\\", \\\"{x:1216,y:665,t:1527023499869};\\\", \\\"{x:1228,y:696,t:1527023499885};\\\", \\\"{x:1241,y:727,t:1527023499902};\\\", \\\"{x:1253,y:760,t:1527023499918};\\\", \\\"{x:1258,y:777,t:1527023499936};\\\", \\\"{x:1261,y:785,t:1527023499952};\\\", \\\"{x:1263,y:793,t:1527023499969};\\\", \\\"{x:1263,y:794,t:1527023499986};\\\", \\\"{x:1264,y:795,t:1527023500039};\\\", \\\"{x:1265,y:795,t:1527023500055};\\\", \\\"{x:1266,y:796,t:1527023500069};\\\", \\\"{x:1267,y:799,t:1527023500086};\\\", \\\"{x:1267,y:806,t:1527023500102};\\\", \\\"{x:1262,y:816,t:1527023500119};\\\", \\\"{x:1257,y:822,t:1527023500136};\\\", \\\"{x:1250,y:827,t:1527023500152};\\\", \\\"{x:1245,y:831,t:1527023500169};\\\", \\\"{x:1242,y:836,t:1527023500186};\\\", \\\"{x:1238,y:839,t:1527023500202};\\\", \\\"{x:1235,y:839,t:1527023500220};\\\", \\\"{x:1234,y:839,t:1527023500236};\\\", \\\"{x:1233,y:839,t:1527023500255};\\\", \\\"{x:1232,y:839,t:1527023500270};\\\", \\\"{x:1228,y:839,t:1527023500286};\\\", \\\"{x:1223,y:837,t:1527023500303};\\\", \\\"{x:1222,y:837,t:1527023500351};\\\", \\\"{x:1221,y:837,t:1527023500399};\\\", \\\"{x:1221,y:836,t:1527023500407};\\\", \\\"{x:1220,y:836,t:1527023500431};\\\", \\\"{x:1218,y:835,t:1527023500567};\\\", \\\"{x:1217,y:834,t:1527023500776};\\\", \\\"{x:1215,y:834,t:1527023501295};\\\", \\\"{x:1213,y:834,t:1527023501303};\\\", \\\"{x:1212,y:834,t:1527023501320};\\\", \\\"{x:1210,y:832,t:1527023501337};\\\", \\\"{x:1209,y:832,t:1527023501354};\\\", \\\"{x:1208,y:832,t:1527023501376};\\\", \\\"{x:1207,y:832,t:1527023501671};\\\", \\\"{x:1204,y:833,t:1527023501687};\\\", \\\"{x:1199,y:835,t:1527023501705};\\\", \\\"{x:1192,y:839,t:1527023501722};\\\", \\\"{x:1185,y:843,t:1527023501738};\\\", \\\"{x:1179,y:845,t:1527023501754};\\\", \\\"{x:1170,y:848,t:1527023501772};\\\", \\\"{x:1157,y:852,t:1527023501787};\\\", \\\"{x:1143,y:859,t:1527023501804};\\\", \\\"{x:1125,y:867,t:1527023501821};\\\", \\\"{x:1108,y:879,t:1527023501838};\\\", \\\"{x:1093,y:893,t:1527023501855};\\\", \\\"{x:1081,y:911,t:1527023501871};\\\", \\\"{x:1079,y:919,t:1527023501887};\\\", \\\"{x:1077,y:925,t:1527023501905};\\\", \\\"{x:1076,y:928,t:1527023501921};\\\", \\\"{x:1076,y:933,t:1527023501938};\\\", \\\"{x:1076,y:936,t:1527023501954};\\\", \\\"{x:1079,y:940,t:1527023501971};\\\", \\\"{x:1084,y:942,t:1527023501987};\\\", \\\"{x:1087,y:945,t:1527023502004};\\\", \\\"{x:1093,y:948,t:1527023502021};\\\", \\\"{x:1096,y:951,t:1527023502038};\\\", \\\"{x:1099,y:954,t:1527023502054};\\\", \\\"{x:1103,y:957,t:1527023502071};\\\", \\\"{x:1104,y:957,t:1527023502089};\\\", \\\"{x:1104,y:955,t:1527023502135};\\\", \\\"{x:1103,y:954,t:1527023502143};\\\", \\\"{x:1103,y:953,t:1527023502167};\\\", \\\"{x:1103,y:951,t:1527023502183};\\\", \\\"{x:1103,y:950,t:1527023502198};\\\", \\\"{x:1103,y:949,t:1527023502207};\\\", \\\"{x:1103,y:948,t:1527023502221};\\\", \\\"{x:1104,y:944,t:1527023502238};\\\", \\\"{x:1104,y:941,t:1527023502254};\\\", \\\"{x:1105,y:933,t:1527023502271};\\\", \\\"{x:1107,y:926,t:1527023502288};\\\", \\\"{x:1108,y:920,t:1527023502304};\\\", \\\"{x:1111,y:908,t:1527023502321};\\\", \\\"{x:1116,y:894,t:1527023502338};\\\", \\\"{x:1119,y:876,t:1527023502354};\\\", \\\"{x:1122,y:858,t:1527023502371};\\\", \\\"{x:1124,y:842,t:1527023502388};\\\", \\\"{x:1127,y:829,t:1527023502405};\\\", \\\"{x:1130,y:820,t:1527023502421};\\\", \\\"{x:1132,y:814,t:1527023502438};\\\", \\\"{x:1133,y:808,t:1527023502455};\\\", \\\"{x:1134,y:805,t:1527023502471};\\\", \\\"{x:1134,y:804,t:1527023502489};\\\", \\\"{x:1134,y:801,t:1527023502506};\\\", \\\"{x:1135,y:801,t:1527023502521};\\\", \\\"{x:1135,y:798,t:1527023502538};\\\", \\\"{x:1136,y:796,t:1527023502555};\\\", \\\"{x:1138,y:793,t:1527023502572};\\\", \\\"{x:1139,y:788,t:1527023502589};\\\", \\\"{x:1141,y:784,t:1527023502605};\\\", \\\"{x:1144,y:778,t:1527023502622};\\\", \\\"{x:1146,y:775,t:1527023502639};\\\", \\\"{x:1149,y:769,t:1527023502655};\\\", \\\"{x:1150,y:768,t:1527023502671};\\\", \\\"{x:1151,y:766,t:1527023502688};\\\", \\\"{x:1153,y:765,t:1527023502706};\\\", \\\"{x:1153,y:763,t:1527023502723};\\\", \\\"{x:1156,y:760,t:1527023502739};\\\", \\\"{x:1158,y:758,t:1527023502755};\\\", \\\"{x:1160,y:755,t:1527023502772};\\\", \\\"{x:1163,y:750,t:1527023502788};\\\", \\\"{x:1164,y:748,t:1527023502806};\\\", \\\"{x:1165,y:747,t:1527023502831};\\\", \\\"{x:1166,y:746,t:1527023502855};\\\", \\\"{x:1167,y:745,t:1527023503272};\\\", \\\"{x:1168,y:744,t:1527023503279};\\\", \\\"{x:1170,y:743,t:1527023503289};\\\", \\\"{x:1171,y:740,t:1527023503306};\\\", \\\"{x:1174,y:737,t:1527023503323};\\\", \\\"{x:1176,y:734,t:1527023503340};\\\", \\\"{x:1178,y:731,t:1527023503356};\\\", \\\"{x:1183,y:724,t:1527023503372};\\\", \\\"{x:1185,y:719,t:1527023503389};\\\", \\\"{x:1186,y:716,t:1527023503405};\\\", \\\"{x:1188,y:714,t:1527023503423};\\\", \\\"{x:1189,y:712,t:1527023503440};\\\", \\\"{x:1190,y:711,t:1527023503456};\\\", \\\"{x:1190,y:708,t:1527023503473};\\\", \\\"{x:1192,y:706,t:1527023503490};\\\", \\\"{x:1192,y:705,t:1527023503506};\\\", \\\"{x:1193,y:703,t:1527023503522};\\\", \\\"{x:1194,y:702,t:1527023503539};\\\", \\\"{x:1195,y:699,t:1527023503556};\\\", \\\"{x:1196,y:695,t:1527023503572};\\\", \\\"{x:1199,y:692,t:1527023503590};\\\", \\\"{x:1201,y:687,t:1527023503606};\\\", \\\"{x:1202,y:685,t:1527023503622};\\\", \\\"{x:1203,y:683,t:1527023503640};\\\", \\\"{x:1203,y:681,t:1527023503656};\\\", \\\"{x:1205,y:678,t:1527023503672};\\\", \\\"{x:1205,y:676,t:1527023503689};\\\", \\\"{x:1207,y:675,t:1527023503706};\\\", \\\"{x:1208,y:673,t:1527023503723};\\\", \\\"{x:1208,y:672,t:1527023503739};\\\", \\\"{x:1209,y:671,t:1527023503759};\\\", \\\"{x:1211,y:668,t:1527023504560};\\\", \\\"{x:1212,y:667,t:1527023504573};\\\", \\\"{x:1213,y:665,t:1527023504591};\\\", \\\"{x:1216,y:660,t:1527023504607};\\\", \\\"{x:1219,y:655,t:1527023504624};\\\", \\\"{x:1221,y:651,t:1527023504640};\\\", \\\"{x:1224,y:647,t:1527023504657};\\\", \\\"{x:1225,y:644,t:1527023504673};\\\", \\\"{x:1227,y:642,t:1527023504690};\\\", \\\"{x:1227,y:641,t:1527023504708};\\\", \\\"{x:1228,y:640,t:1527023504735};\\\", \\\"{x:1229,y:639,t:1527023504759};\\\", \\\"{x:1230,y:638,t:1527023504775};\\\", \\\"{x:1230,y:637,t:1527023504791};\\\", \\\"{x:1231,y:636,t:1527023504807};\\\", \\\"{x:1231,y:635,t:1527023504831};\\\", \\\"{x:1232,y:635,t:1527023504840};\\\", \\\"{x:1233,y:633,t:1527023504858};\\\", \\\"{x:1234,y:631,t:1527023504874};\\\", \\\"{x:1236,y:629,t:1527023504890};\\\", \\\"{x:1237,y:627,t:1527023504908};\\\", \\\"{x:1239,y:625,t:1527023504924};\\\", \\\"{x:1240,y:624,t:1527023504941};\\\", \\\"{x:1241,y:622,t:1527023504957};\\\", \\\"{x:1241,y:621,t:1527023504974};\\\", \\\"{x:1242,y:619,t:1527023504990};\\\", \\\"{x:1244,y:617,t:1527023505008};\\\", \\\"{x:1245,y:616,t:1527023505024};\\\", \\\"{x:1245,y:615,t:1527023505040};\\\", \\\"{x:1246,y:614,t:1527023505063};\\\", \\\"{x:1246,y:613,t:1527023505207};\\\", \\\"{x:1247,y:611,t:1527023505225};\\\", \\\"{x:1248,y:610,t:1527023505241};\\\", \\\"{x:1249,y:608,t:1527023505258};\\\", \\\"{x:1251,y:605,t:1527023505275};\\\", \\\"{x:1251,y:603,t:1527023505292};\\\", \\\"{x:1254,y:599,t:1527023505308};\\\", \\\"{x:1255,y:598,t:1527023505325};\\\", \\\"{x:1256,y:594,t:1527023505342};\\\", \\\"{x:1257,y:591,t:1527023505357};\\\", \\\"{x:1258,y:588,t:1527023505374};\\\", \\\"{x:1260,y:585,t:1527023505391};\\\", \\\"{x:1261,y:582,t:1527023505408};\\\", \\\"{x:1262,y:580,t:1527023505424};\\\", \\\"{x:1264,y:578,t:1527023505441};\\\", \\\"{x:1265,y:576,t:1527023505457};\\\", \\\"{x:1266,y:575,t:1527023505479};\\\", \\\"{x:1267,y:574,t:1527023505503};\\\", \\\"{x:1267,y:573,t:1527023505511};\\\", \\\"{x:1268,y:572,t:1527023505551};\\\", \\\"{x:1268,y:571,t:1527023506327};\\\", \\\"{x:1269,y:570,t:1527023507687};\\\", \\\"{x:1270,y:569,t:1527023507695};\\\", \\\"{x:1271,y:569,t:1527023507710};\\\", \\\"{x:1274,y:564,t:1527023507727};\\\", \\\"{x:1275,y:563,t:1527023507744};\\\", \\\"{x:1275,y:562,t:1527023507761};\\\", \\\"{x:1277,y:561,t:1527023507806};\\\", \\\"{x:1277,y:560,t:1527023507839};\\\", \\\"{x:1277,y:559,t:1527023507880};\\\", \\\"{x:1278,y:558,t:1527023508423};\\\", \\\"{x:1279,y:558,t:1527023508447};\\\", \\\"{x:1280,y:559,t:1527023508460};\\\", \\\"{x:1281,y:560,t:1527023508479};\\\", \\\"{x:1281,y:561,t:1527023508503};\\\", \\\"{x:1281,y:562,t:1527023508511};\\\", \\\"{x:1283,y:563,t:1527023508528};\\\", \\\"{x:1283,y:564,t:1527023508545};\\\", \\\"{x:1284,y:564,t:1527023508561};\\\", \\\"{x:1284,y:565,t:1527023508578};\\\", \\\"{x:1285,y:566,t:1527023508595};\\\", \\\"{x:1286,y:566,t:1527023508611};\\\", \\\"{x:1287,y:566,t:1527023508631};\\\", \\\"{x:1289,y:567,t:1527023508645};\\\", \\\"{x:1289,y:568,t:1527023508663};\\\", \\\"{x:1290,y:569,t:1527023508695};\\\", \\\"{x:1291,y:569,t:1527023508735};\\\", \\\"{x:1292,y:570,t:1527023508751};\\\", \\\"{x:1293,y:571,t:1527023508767};\\\", \\\"{x:1294,y:572,t:1527023508778};\\\", \\\"{x:1294,y:573,t:1527023508795};\\\", \\\"{x:1295,y:573,t:1527023508810};\\\", \\\"{x:1296,y:574,t:1527023508828};\\\", \\\"{x:1296,y:575,t:1527023508844};\\\", \\\"{x:1298,y:577,t:1527023508861};\\\", \\\"{x:1299,y:581,t:1527023508878};\\\", \\\"{x:1302,y:588,t:1527023508894};\\\", \\\"{x:1304,y:596,t:1527023508911};\\\", \\\"{x:1306,y:602,t:1527023508928};\\\", \\\"{x:1311,y:613,t:1527023508945};\\\", \\\"{x:1316,y:621,t:1527023508962};\\\", \\\"{x:1321,y:630,t:1527023508978};\\\", \\\"{x:1324,y:638,t:1527023508995};\\\", \\\"{x:1328,y:644,t:1527023509011};\\\", \\\"{x:1330,y:650,t:1527023509027};\\\", \\\"{x:1333,y:658,t:1527023509044};\\\", \\\"{x:1338,y:665,t:1527023509062};\\\", \\\"{x:1339,y:669,t:1527023509077};\\\", \\\"{x:1342,y:675,t:1527023509094};\\\", \\\"{x:1345,y:680,t:1527023509112};\\\", \\\"{x:1347,y:686,t:1527023509127};\\\", \\\"{x:1349,y:690,t:1527023509145};\\\", \\\"{x:1352,y:697,t:1527023509162};\\\", \\\"{x:1354,y:701,t:1527023509179};\\\", \\\"{x:1356,y:707,t:1527023509194};\\\", \\\"{x:1358,y:710,t:1527023509211};\\\", \\\"{x:1360,y:713,t:1527023509228};\\\", \\\"{x:1361,y:717,t:1527023509245};\\\", \\\"{x:1365,y:723,t:1527023509261};\\\", \\\"{x:1367,y:730,t:1527023509279};\\\", \\\"{x:1371,y:737,t:1527023509295};\\\", \\\"{x:1375,y:746,t:1527023509312};\\\", \\\"{x:1378,y:751,t:1527023509329};\\\", \\\"{x:1380,y:755,t:1527023509345};\\\", \\\"{x:1382,y:759,t:1527023509361};\\\", \\\"{x:1382,y:761,t:1527023509379};\\\", \\\"{x:1384,y:763,t:1527023509395};\\\", \\\"{x:1385,y:768,t:1527023509412};\\\", \\\"{x:1388,y:772,t:1527023509429};\\\", \\\"{x:1389,y:775,t:1527023509445};\\\", \\\"{x:1391,y:778,t:1527023509462};\\\", \\\"{x:1392,y:780,t:1527023509479};\\\", \\\"{x:1393,y:782,t:1527023509496};\\\", \\\"{x:1394,y:785,t:1527023509512};\\\", \\\"{x:1394,y:786,t:1527023509528};\\\", \\\"{x:1396,y:788,t:1527023509546};\\\", \\\"{x:1396,y:789,t:1527023509567};\\\", \\\"{x:1396,y:791,t:1527023509631};\\\", \\\"{x:1397,y:792,t:1527023509645};\\\", \\\"{x:1398,y:793,t:1527023509661};\\\", \\\"{x:1399,y:795,t:1527023509678};\\\", \\\"{x:1399,y:797,t:1527023509696};\\\", \\\"{x:1401,y:799,t:1527023509712};\\\", \\\"{x:1402,y:801,t:1527023509728};\\\", \\\"{x:1403,y:804,t:1527023509746};\\\", \\\"{x:1405,y:807,t:1527023509762};\\\", \\\"{x:1405,y:809,t:1527023509779};\\\", \\\"{x:1407,y:812,t:1527023509795};\\\", \\\"{x:1408,y:813,t:1527023509812};\\\", \\\"{x:1409,y:814,t:1527023509828};\\\", \\\"{x:1409,y:815,t:1527023509846};\\\", \\\"{x:1409,y:816,t:1527023509862};\\\", \\\"{x:1409,y:818,t:1527023509878};\\\", \\\"{x:1409,y:820,t:1527023509895};\\\", \\\"{x:1411,y:822,t:1527023509913};\\\", \\\"{x:1411,y:823,t:1527023509929};\\\", \\\"{x:1412,y:825,t:1527023509946};\\\", \\\"{x:1412,y:826,t:1527023509967};\\\", \\\"{x:1414,y:828,t:1527023509979};\\\", \\\"{x:1414,y:830,t:1527023509996};\\\", \\\"{x:1415,y:831,t:1527023510012};\\\", \\\"{x:1416,y:833,t:1527023510029};\\\", \\\"{x:1417,y:835,t:1527023510046};\\\", \\\"{x:1418,y:837,t:1527023510063};\\\", \\\"{x:1419,y:840,t:1527023510079};\\\", \\\"{x:1421,y:845,t:1527023510095};\\\", \\\"{x:1422,y:847,t:1527023510113};\\\", \\\"{x:1424,y:852,t:1527023510129};\\\", \\\"{x:1425,y:854,t:1527023510145};\\\", \\\"{x:1427,y:859,t:1527023510163};\\\", \\\"{x:1429,y:863,t:1527023510179};\\\", \\\"{x:1430,y:866,t:1527023510196};\\\", \\\"{x:1433,y:873,t:1527023510213};\\\", \\\"{x:1436,y:879,t:1527023510230};\\\", \\\"{x:1438,y:886,t:1527023510245};\\\", \\\"{x:1441,y:890,t:1527023510262};\\\", \\\"{x:1442,y:894,t:1527023510280};\\\", \\\"{x:1443,y:896,t:1527023510296};\\\", \\\"{x:1444,y:899,t:1527023510313};\\\", \\\"{x:1445,y:900,t:1527023510329};\\\", \\\"{x:1445,y:901,t:1527023510345};\\\", \\\"{x:1445,y:902,t:1527023510363};\\\", \\\"{x:1447,y:906,t:1527023510380};\\\", \\\"{x:1447,y:907,t:1527023510395};\\\", \\\"{x:1447,y:909,t:1527023510412};\\\", \\\"{x:1448,y:911,t:1527023510430};\\\", \\\"{x:1448,y:913,t:1527023510454};\\\", \\\"{x:1448,y:914,t:1527023510471};\\\", \\\"{x:1450,y:915,t:1527023510583};\\\", \\\"{x:1450,y:917,t:1527023510599};\\\", \\\"{x:1451,y:919,t:1527023510615};\\\", \\\"{x:1451,y:920,t:1527023510631};\\\", \\\"{x:1451,y:919,t:1527023511703};\\\", \\\"{x:1451,y:918,t:1527023511727};\\\", \\\"{x:1451,y:917,t:1527023511742};\\\", \\\"{x:1451,y:916,t:1527023511759};\\\", \\\"{x:1451,y:915,t:1527023511775};\\\", \\\"{x:1451,y:914,t:1527023511783};\\\", \\\"{x:1451,y:913,t:1527023511797};\\\", \\\"{x:1451,y:911,t:1527023511815};\\\", \\\"{x:1451,y:908,t:1527023511831};\\\", \\\"{x:1451,y:907,t:1527023511855};\\\", \\\"{x:1451,y:906,t:1527023511864};\\\", \\\"{x:1451,y:904,t:1527023511881};\\\", \\\"{x:1451,y:902,t:1527023511898};\\\", \\\"{x:1451,y:899,t:1527023511914};\\\", \\\"{x:1450,y:898,t:1527023511931};\\\", \\\"{x:1449,y:895,t:1527023511947};\\\", \\\"{x:1449,y:891,t:1527023511964};\\\", \\\"{x:1449,y:887,t:1527023511981};\\\", \\\"{x:1449,y:884,t:1527023511998};\\\", \\\"{x:1446,y:876,t:1527023512015};\\\", \\\"{x:1442,y:869,t:1527023512031};\\\", \\\"{x:1439,y:863,t:1527023512048};\\\", \\\"{x:1437,y:857,t:1527023512064};\\\", \\\"{x:1434,y:851,t:1527023512080};\\\", \\\"{x:1433,y:849,t:1527023512098};\\\", \\\"{x:1431,y:845,t:1527023512114};\\\", \\\"{x:1429,y:842,t:1527023512130};\\\", \\\"{x:1428,y:838,t:1527023512148};\\\", \\\"{x:1426,y:833,t:1527023512164};\\\", \\\"{x:1424,y:830,t:1527023512181};\\\", \\\"{x:1422,y:826,t:1527023512197};\\\", \\\"{x:1419,y:818,t:1527023512214};\\\", \\\"{x:1418,y:815,t:1527023512231};\\\", \\\"{x:1415,y:810,t:1527023512247};\\\", \\\"{x:1413,y:806,t:1527023512265};\\\", \\\"{x:1411,y:803,t:1527023512280};\\\", \\\"{x:1408,y:797,t:1527023512297};\\\", \\\"{x:1407,y:793,t:1527023512314};\\\", \\\"{x:1405,y:789,t:1527023512331};\\\", \\\"{x:1403,y:784,t:1527023512347};\\\", \\\"{x:1401,y:781,t:1527023512364};\\\", \\\"{x:1400,y:778,t:1527023512382};\\\", \\\"{x:1399,y:776,t:1527023512398};\\\", \\\"{x:1397,y:771,t:1527023512415};\\\", \\\"{x:1396,y:770,t:1527023512432};\\\", \\\"{x:1396,y:768,t:1527023512447};\\\", \\\"{x:1394,y:765,t:1527023512464};\\\", \\\"{x:1393,y:763,t:1527023512482};\\\", \\\"{x:1390,y:758,t:1527023512497};\\\", \\\"{x:1386,y:754,t:1527023512514};\\\", \\\"{x:1382,y:750,t:1527023512531};\\\", \\\"{x:1378,y:745,t:1527023512548};\\\", \\\"{x:1375,y:741,t:1527023512565};\\\", \\\"{x:1370,y:735,t:1527023512582};\\\", \\\"{x:1364,y:728,t:1527023512598};\\\", \\\"{x:1354,y:717,t:1527023512614};\\\", \\\"{x:1346,y:705,t:1527023512632};\\\", \\\"{x:1335,y:689,t:1527023512647};\\\", \\\"{x:1324,y:676,t:1527023512664};\\\", \\\"{x:1316,y:665,t:1527023512681};\\\", \\\"{x:1312,y:658,t:1527023512699};\\\", \\\"{x:1311,y:656,t:1527023512715};\\\", \\\"{x:1310,y:652,t:1527023512731};\\\", \\\"{x:1308,y:649,t:1527023512748};\\\", \\\"{x:1307,y:645,t:1527023512764};\\\", \\\"{x:1305,y:641,t:1527023512782};\\\", \\\"{x:1302,y:635,t:1527023512799};\\\", \\\"{x:1301,y:632,t:1527023512814};\\\", \\\"{x:1301,y:631,t:1527023512847};\\\", \\\"{x:1300,y:629,t:1527023512855};\\\", \\\"{x:1299,y:627,t:1527023512879};\\\", \\\"{x:1299,y:626,t:1527023512894};\\\", \\\"{x:1298,y:625,t:1527023512903};\\\", \\\"{x:1298,y:624,t:1527023512915};\\\", \\\"{x:1297,y:623,t:1527023512932};\\\", \\\"{x:1297,y:621,t:1527023512949};\\\", \\\"{x:1297,y:619,t:1527023512967};\\\", \\\"{x:1296,y:617,t:1527023512982};\\\", \\\"{x:1294,y:610,t:1527023512998};\\\", \\\"{x:1293,y:604,t:1527023513015};\\\", \\\"{x:1292,y:599,t:1527023513031};\\\", \\\"{x:1290,y:596,t:1527023513048};\\\", \\\"{x:1288,y:591,t:1527023513066};\\\", \\\"{x:1287,y:587,t:1527023513082};\\\", \\\"{x:1286,y:585,t:1527023513099};\\\", \\\"{x:1286,y:584,t:1527023513118};\\\", \\\"{x:1285,y:583,t:1527023513134};\\\", \\\"{x:1282,y:583,t:1527023513383};\\\", \\\"{x:1271,y:588,t:1527023513399};\\\", \\\"{x:1263,y:593,t:1527023513416};\\\", \\\"{x:1254,y:598,t:1527023513432};\\\", \\\"{x:1238,y:603,t:1527023513449};\\\", \\\"{x:1227,y:608,t:1527023513465};\\\", \\\"{x:1214,y:612,t:1527023513482};\\\", \\\"{x:1199,y:615,t:1527023513499};\\\", \\\"{x:1181,y:620,t:1527023513516};\\\", \\\"{x:1159,y:626,t:1527023513533};\\\", \\\"{x:1134,y:634,t:1527023513549};\\\", \\\"{x:1116,y:635,t:1527023513566};\\\", \\\"{x:1083,y:640,t:1527023513582};\\\", \\\"{x:1064,y:642,t:1527023513599};\\\", \\\"{x:1044,y:646,t:1527023513616};\\\", \\\"{x:1024,y:651,t:1527023513633};\\\", \\\"{x:1002,y:657,t:1527023513649};\\\", \\\"{x:979,y:661,t:1527023513665};\\\", \\\"{x:963,y:664,t:1527023513683};\\\", \\\"{x:946,y:669,t:1527023513699};\\\", \\\"{x:929,y:671,t:1527023513716};\\\", \\\"{x:910,y:674,t:1527023513733};\\\", \\\"{x:886,y:680,t:1527023513749};\\\", \\\"{x:848,y:685,t:1527023513765};\\\", \\\"{x:763,y:696,t:1527023513782};\\\", \\\"{x:701,y:705,t:1527023513800};\\\", \\\"{x:647,y:709,t:1527023513816};\\\", \\\"{x:588,y:709,t:1527023513832};\\\", \\\"{x:532,y:709,t:1527023513850};\\\", \\\"{x:484,y:711,t:1527023513866};\\\", \\\"{x:448,y:711,t:1527023513883};\\\", \\\"{x:424,y:711,t:1527023513899};\\\", \\\"{x:407,y:711,t:1527023513916};\\\", \\\"{x:392,y:711,t:1527023513933};\\\", \\\"{x:383,y:712,t:1527023513949};\\\", \\\"{x:380,y:713,t:1527023513966};\\\", \\\"{x:378,y:714,t:1527023513983};\\\", \\\"{x:379,y:707,t:1527023514095};\\\", \\\"{x:384,y:695,t:1527023514102};\\\", \\\"{x:388,y:681,t:1527023514117};\\\", \\\"{x:398,y:642,t:1527023514133};\\\", \\\"{x:403,y:611,t:1527023514151};\\\", \\\"{x:409,y:585,t:1527023514167};\\\", \\\"{x:412,y:580,t:1527023514180};\\\", \\\"{x:416,y:573,t:1527023514196};\\\", \\\"{x:421,y:565,t:1527023514213};\\\", \\\"{x:422,y:562,t:1527023514230};\\\", \\\"{x:426,y:558,t:1527023514247};\\\", \\\"{x:431,y:553,t:1527023514264};\\\", \\\"{x:439,y:545,t:1527023514280};\\\", \\\"{x:450,y:539,t:1527023514297};\\\", \\\"{x:464,y:531,t:1527023514314};\\\", \\\"{x:478,y:525,t:1527023514330};\\\", \\\"{x:501,y:518,t:1527023514347};\\\", \\\"{x:524,y:511,t:1527023514364};\\\", \\\"{x:544,y:508,t:1527023514380};\\\", \\\"{x:561,y:506,t:1527023514396};\\\", \\\"{x:573,y:504,t:1527023514413};\\\", \\\"{x:582,y:503,t:1527023514430};\\\", \\\"{x:584,y:503,t:1527023514446};\\\", \\\"{x:585,y:502,t:1527023514471};\\\", \\\"{x:586,y:502,t:1527023514543};\\\", \\\"{x:587,y:502,t:1527023514551};\\\", \\\"{x:588,y:503,t:1527023514566};\\\", \\\"{x:589,y:504,t:1527023514583};\\\", \\\"{x:589,y:510,t:1527023515847};\\\", \\\"{x:588,y:521,t:1527023515855};\\\", \\\"{x:586,y:531,t:1527023515867};\\\", \\\"{x:580,y:549,t:1527023515879};\\\", \\\"{x:575,y:569,t:1527023515897};\\\", \\\"{x:572,y:582,t:1527023515912};\\\", \\\"{x:571,y:589,t:1527023515931};\\\", \\\"{x:571,y:596,t:1527023515948};\\\", \\\"{x:568,y:602,t:1527023515966};\\\", \\\"{x:566,y:613,t:1527023515981};\\\", \\\"{x:561,y:627,t:1527023515998};\\\", \\\"{x:557,y:643,t:1527023516015};\\\", \\\"{x:556,y:654,t:1527023516032};\\\", \\\"{x:556,y:666,t:1527023516048};\\\", \\\"{x:556,y:675,t:1527023516065};\\\", \\\"{x:554,y:681,t:1527023516082};\\\", \\\"{x:552,y:686,t:1527023516097};\\\", \\\"{x:550,y:691,t:1527023516115};\\\", \\\"{x:549,y:693,t:1527023516132};\\\", \\\"{x:549,y:695,t:1527023516149};\\\", \\\"{x:548,y:697,t:1527023516165};\\\", \\\"{x:548,y:698,t:1527023516181};\\\", \\\"{x:546,y:704,t:1527023516199};\\\", \\\"{x:545,y:708,t:1527023516215};\\\", \\\"{x:544,y:712,t:1527023516232};\\\", \\\"{x:543,y:717,t:1527023516249};\\\", \\\"{x:542,y:721,t:1527023516265};\\\", \\\"{x:542,y:725,t:1527023516281};\\\", \\\"{x:541,y:728,t:1527023516299};\\\", \\\"{x:541,y:729,t:1527023516318};\\\", \\\"{x:541,y:731,t:1527023516331};\\\", \\\"{x:541,y:732,t:1527023516349};\\\", \\\"{x:541,y:733,t:1527023516422};\\\", \\\"{x:540,y:734,t:1527023516567};\\\", \\\"{x:542,y:729,t:1527023518639};\\\", \\\"{x:547,y:716,t:1527023518651};\\\", \\\"{x:564,y:681,t:1527023518667};\\\", \\\"{x:587,y:635,t:1527023518683};\\\", \\\"{x:620,y:588,t:1527023518700};\\\", \\\"{x:656,y:542,t:1527023518717};\\\", \\\"{x:672,y:524,t:1527023518734};\\\", \\\"{x:680,y:510,t:1527023518750};\\\", \\\"{x:688,y:500,t:1527023518767};\\\", \\\"{x:689,y:498,t:1527023518784};\\\", \\\"{x:690,y:498,t:1527023518801};\\\", \\\"{x:690,y:498,t:1527023518887};\\\", \\\"{x:690,y:497,t:1527023519007};\\\", \\\"{x:687,y:496,t:1527023519018};\\\", \\\"{x:676,y:496,t:1527023519035};\\\", \\\"{x:660,y:494,t:1527023519052};\\\", \\\"{x:646,y:494,t:1527023519068};\\\", \\\"{x:633,y:494,t:1527023519085};\\\", \\\"{x:624,y:494,t:1527023519102};\\\", \\\"{x:621,y:494,t:1527023519117};\\\", \\\"{x:620,y:494,t:1527023519135};\\\", \\\"{x:615,y:497,t:1527023519414};\\\", \\\"{x:610,y:507,t:1527023519422};\\\", \\\"{x:607,y:514,t:1527023519434};\\\", \\\"{x:596,y:532,t:1527023519452};\\\", \\\"{x:586,y:552,t:1527023519468};\\\", \\\"{x:580,y:570,t:1527023519485};\\\", \\\"{x:575,y:586,t:1527023519501};\\\", \\\"{x:571,y:598,t:1527023519519};\\\", \\\"{x:568,y:607,t:1527023519534};\\\", \\\"{x:567,y:615,t:1527023519551};\\\", \\\"{x:567,y:618,t:1527023519568};\\\", \\\"{x:567,y:624,t:1527023519584};\\\", \\\"{x:567,y:628,t:1527023519601};\\\", \\\"{x:567,y:633,t:1527023519619};\\\", \\\"{x:568,y:637,t:1527023519634};\\\", \\\"{x:568,y:643,t:1527023519651};\\\", \\\"{x:568,y:646,t:1527023519668};\\\", \\\"{x:569,y:648,t:1527023519684};\\\", \\\"{x:569,y:653,t:1527023519700};\\\", \\\"{x:571,y:658,t:1527023519717};\\\", \\\"{x:572,y:662,t:1527023519734};\\\", \\\"{x:572,y:667,t:1527023519751};\\\", \\\"{x:573,y:672,t:1527023519769};\\\", \\\"{x:575,y:677,t:1527023519784};\\\", \\\"{x:575,y:683,t:1527023519801};\\\", \\\"{x:575,y:688,t:1527023519818};\\\", \\\"{x:575,y:692,t:1527023519834};\\\", \\\"{x:575,y:699,t:1527023519851};\\\", \\\"{x:573,y:704,t:1527023519867};\\\", \\\"{x:571,y:710,t:1527023519884};\\\", \\\"{x:568,y:715,t:1527023519901};\\\", \\\"{x:563,y:722,t:1527023519919};\\\", \\\"{x:560,y:729,t:1527023519934};\\\", \\\"{x:556,y:736,t:1527023519951};\\\", \\\"{x:554,y:737,t:1527023519968};\\\", \\\"{x:553,y:739,t:1527023519985};\\\", \\\"{x:552,y:740,t:1527023520001};\\\", \\\"{x:551,y:740,t:1527023520030};\\\" ] }, { \\\"rt\\\": 17234, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 14, \\\"time_elapsed\\\": 554647, \\\"internal_node_id\\\": \\\"0.0-6.0-4.0\\\", \\\"subject\\\": \\\"8LK9M\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"hotel\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"ends\\\", \\\"q\\\": 10, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-11 AM-F -B -B -M \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:552,y:737,t:1527023521959};\\\", \\\"{x:553,y:732,t:1527023521971};\\\", \\\"{x:554,y:730,t:1527023521987};\\\", \\\"{x:556,y:725,t:1527023522003};\\\", \\\"{x:556,y:722,t:1527023522020};\\\", \\\"{x:556,y:716,t:1527023522037};\\\", \\\"{x:556,y:713,t:1527023522053};\\\", \\\"{x:557,y:708,t:1527023522070};\\\", \\\"{x:558,y:704,t:1527023522086};\\\", \\\"{x:558,y:696,t:1527023522103};\\\", \\\"{x:558,y:690,t:1527023522120};\\\", \\\"{x:558,y:685,t:1527023522136};\\\", \\\"{x:558,y:681,t:1527023522154};\\\", \\\"{x:558,y:675,t:1527023522170};\\\", \\\"{x:556,y:667,t:1527023522186};\\\", \\\"{x:556,y:662,t:1527023522203};\\\", \\\"{x:556,y:658,t:1527023522220};\\\", \\\"{x:555,y:655,t:1527023522236};\\\", \\\"{x:555,y:652,t:1527023522253};\\\", \\\"{x:554,y:650,t:1527023522270};\\\", \\\"{x:554,y:646,t:1527023522286};\\\", \\\"{x:553,y:640,t:1527023522303};\\\", \\\"{x:553,y:633,t:1527023522320};\\\", \\\"{x:553,y:625,t:1527023522336};\\\", \\\"{x:553,y:611,t:1527023522353};\\\", \\\"{x:553,y:593,t:1527023522371};\\\", \\\"{x:553,y:573,t:1527023522386};\\\", \\\"{x:555,y:553,t:1527023522403};\\\", \\\"{x:558,y:534,t:1527023522420};\\\", \\\"{x:560,y:513,t:1527023522438};\\\", \\\"{x:565,y:492,t:1527023522453};\\\", \\\"{x:566,y:478,t:1527023522471};\\\", \\\"{x:568,y:468,t:1527023522486};\\\", \\\"{x:568,y:464,t:1527023522503};\\\", \\\"{x:568,y:460,t:1527023522520};\\\", \\\"{x:568,y:458,t:1527023522537};\\\", \\\"{x:568,y:457,t:1527023522553};\\\", \\\"{x:568,y:456,t:1527023522570};\\\", \\\"{x:568,y:455,t:1527023522587};\\\", \\\"{x:569,y:455,t:1527023523063};\\\", \\\"{x:572,y:455,t:1527023523070};\\\", \\\"{x:577,y:455,t:1527023523087};\\\", \\\"{x:584,y:455,t:1527023523103};\\\", \\\"{x:591,y:455,t:1527023523120};\\\", \\\"{x:601,y:455,t:1527023523137};\\\", \\\"{x:609,y:455,t:1527023523155};\\\", \\\"{x:616,y:455,t:1527023523170};\\\", \\\"{x:622,y:455,t:1527023523187};\\\", \\\"{x:631,y:455,t:1527023523204};\\\", \\\"{x:637,y:455,t:1527023523222};\\\", \\\"{x:644,y:455,t:1527023523238};\\\", \\\"{x:653,y:453,t:1527023523254};\\\", \\\"{x:660,y:451,t:1527023523270};\\\", \\\"{x:661,y:451,t:1527023523287};\\\", \\\"{x:663,y:451,t:1527023523304};\\\", \\\"{x:665,y:451,t:1527023523321};\\\", \\\"{x:666,y:451,t:1527023523337};\\\", \\\"{x:669,y:450,t:1527023523355};\\\", \\\"{x:671,y:450,t:1527023523371};\\\", \\\"{x:673,y:450,t:1527023523389};\\\", \\\"{x:674,y:450,t:1527023523405};\\\", \\\"{x:675,y:450,t:1527023523421};\\\", \\\"{x:675,y:450,t:1527023523503};\\\", \\\"{x:676,y:450,t:1527023523579};\\\", \\\"{x:677,y:450,t:1527023523592};\\\", \\\"{x:680,y:450,t:1527023523609};\\\", \\\"{x:684,y:450,t:1527023523625};\\\", \\\"{x:696,y:450,t:1527023523643};\\\", \\\"{x:717,y:450,t:1527023523659};\\\", \\\"{x:734,y:450,t:1527023523675};\\\", \\\"{x:753,y:450,t:1527023523693};\\\", \\\"{x:774,y:450,t:1527023523709};\\\", \\\"{x:792,y:450,t:1527023523726};\\\", \\\"{x:813,y:450,t:1527023523743};\\\", \\\"{x:838,y:450,t:1527023523759};\\\", \\\"{x:861,y:450,t:1527023523777};\\\", \\\"{x:890,y:450,t:1527023523792};\\\", \\\"{x:921,y:450,t:1527023523810};\\\", \\\"{x:955,y:450,t:1527023523826};\\\", \\\"{x:991,y:450,t:1527023523843};\\\", \\\"{x:1014,y:450,t:1527023523860};\\\", \\\"{x:1036,y:450,t:1527023523877};\\\", \\\"{x:1058,y:450,t:1527023523894};\\\", \\\"{x:1076,y:450,t:1527023523910};\\\", \\\"{x:1091,y:450,t:1527023523927};\\\", \\\"{x:1101,y:450,t:1527023523944};\\\", \\\"{x:1112,y:449,t:1527023523960};\\\", \\\"{x:1123,y:447,t:1527023523977};\\\", \\\"{x:1140,y:446,t:1527023523993};\\\", \\\"{x:1158,y:446,t:1527023524011};\\\", \\\"{x:1176,y:445,t:1527023524027};\\\", \\\"{x:1206,y:445,t:1527023524043};\\\", \\\"{x:1223,y:445,t:1527023524060};\\\", \\\"{x:1238,y:445,t:1527023524076};\\\", \\\"{x:1247,y:445,t:1527023524094};\\\", \\\"{x:1257,y:445,t:1527023524110};\\\", \\\"{x:1268,y:445,t:1527023524127};\\\", \\\"{x:1275,y:446,t:1527023524144};\\\", \\\"{x:1282,y:448,t:1527023524160};\\\", \\\"{x:1286,y:449,t:1527023524178};\\\", \\\"{x:1287,y:449,t:1527023524193};\\\", \\\"{x:1288,y:450,t:1527023524210};\\\", \\\"{x:1290,y:454,t:1527023524227};\\\", \\\"{x:1294,y:466,t:1527023524244};\\\", \\\"{x:1297,y:477,t:1527023524260};\\\", \\\"{x:1302,y:493,t:1527023524277};\\\", \\\"{x:1307,y:505,t:1527023524294};\\\", \\\"{x:1313,y:520,t:1527023524311};\\\", \\\"{x:1319,y:533,t:1527023524327};\\\", \\\"{x:1324,y:546,t:1527023524345};\\\", \\\"{x:1330,y:563,t:1527023524361};\\\", \\\"{x:1339,y:582,t:1527023524378};\\\", \\\"{x:1344,y:598,t:1527023524395};\\\", \\\"{x:1352,y:627,t:1527023524411};\\\", \\\"{x:1355,y:652,t:1527023524427};\\\", \\\"{x:1359,y:679,t:1527023524445};\\\", \\\"{x:1363,y:706,t:1527023524461};\\\", \\\"{x:1363,y:733,t:1527023524477};\\\", \\\"{x:1365,y:755,t:1527023524494};\\\", \\\"{x:1365,y:771,t:1527023524511};\\\", \\\"{x:1365,y:786,t:1527023524528};\\\", \\\"{x:1361,y:800,t:1527023524544};\\\", \\\"{x:1357,y:816,t:1527023524562};\\\", \\\"{x:1355,y:829,t:1527023524578};\\\", \\\"{x:1350,y:840,t:1527023524594};\\\", \\\"{x:1343,y:855,t:1527023524612};\\\", \\\"{x:1337,y:866,t:1527023524628};\\\", \\\"{x:1331,y:878,t:1527023524645};\\\", \\\"{x:1326,y:887,t:1527023524661};\\\", \\\"{x:1317,y:900,t:1527023524679};\\\", \\\"{x:1305,y:912,t:1527023524696};\\\", \\\"{x:1295,y:924,t:1527023524712};\\\", \\\"{x:1285,y:932,t:1527023524729};\\\", \\\"{x:1277,y:940,t:1527023524746};\\\", \\\"{x:1275,y:944,t:1527023524761};\\\", \\\"{x:1273,y:949,t:1527023524778};\\\", \\\"{x:1270,y:958,t:1527023524795};\\\", \\\"{x:1267,y:965,t:1527023524813};\\\", \\\"{x:1266,y:970,t:1527023524829};\\\", \\\"{x:1264,y:975,t:1527023524846};\\\", \\\"{x:1264,y:977,t:1527023524862};\\\", \\\"{x:1261,y:981,t:1527023524879};\\\", \\\"{x:1260,y:983,t:1527023524895};\\\", \\\"{x:1258,y:986,t:1527023524913};\\\", \\\"{x:1257,y:988,t:1527023524929};\\\", \\\"{x:1256,y:989,t:1527023524945};\\\", \\\"{x:1254,y:992,t:1527023524962};\\\", \\\"{x:1252,y:993,t:1527023524979};\\\", \\\"{x:1249,y:993,t:1527023525003};\\\", \\\"{x:1247,y:994,t:1527023525012};\\\", \\\"{x:1247,y:995,t:1527023525035};\\\", \\\"{x:1247,y:994,t:1527023525475};\\\", \\\"{x:1247,y:987,t:1527023525483};\\\", \\\"{x:1249,y:980,t:1527023525497};\\\", \\\"{x:1252,y:955,t:1527023525514};\\\", \\\"{x:1263,y:919,t:1527023525530};\\\", \\\"{x:1273,y:861,t:1527023525546};\\\", \\\"{x:1276,y:844,t:1527023525563};\\\", \\\"{x:1280,y:831,t:1527023525580};\\\", \\\"{x:1283,y:820,t:1527023525598};\\\", \\\"{x:1286,y:811,t:1527023525613};\\\", \\\"{x:1289,y:803,t:1527023525631};\\\", \\\"{x:1291,y:797,t:1527023525647};\\\", \\\"{x:1291,y:793,t:1527023525664};\\\", \\\"{x:1292,y:790,t:1527023525680};\\\", \\\"{x:1293,y:788,t:1527023525697};\\\", \\\"{x:1294,y:786,t:1527023525714};\\\", \\\"{x:1296,y:781,t:1527023525730};\\\", \\\"{x:1297,y:779,t:1527023525748};\\\", \\\"{x:1298,y:776,t:1527023525765};\\\", \\\"{x:1300,y:771,t:1527023525781};\\\", \\\"{x:1302,y:767,t:1527023525797};\\\", \\\"{x:1305,y:762,t:1527023525814};\\\", \\\"{x:1308,y:758,t:1527023525831};\\\", \\\"{x:1310,y:754,t:1527023525847};\\\", \\\"{x:1312,y:751,t:1527023525864};\\\", \\\"{x:1314,y:747,t:1527023525881};\\\", \\\"{x:1315,y:746,t:1527023525897};\\\", \\\"{x:1316,y:743,t:1527023525915};\\\", \\\"{x:1318,y:741,t:1527023525931};\\\", \\\"{x:1319,y:739,t:1527023525948};\\\", \\\"{x:1320,y:737,t:1527023525964};\\\", \\\"{x:1321,y:736,t:1527023525982};\\\", \\\"{x:1322,y:736,t:1527023526002};\\\", \\\"{x:1322,y:735,t:1527023526019};\\\", \\\"{x:1324,y:734,t:1527023526031};\\\", \\\"{x:1324,y:733,t:1527023526049};\\\", \\\"{x:1326,y:731,t:1527023526065};\\\", \\\"{x:1326,y:730,t:1527023526082};\\\", \\\"{x:1327,y:729,t:1527023526098};\\\", \\\"{x:1328,y:728,t:1527023526123};\\\", \\\"{x:1329,y:727,t:1527023526139};\\\", \\\"{x:1330,y:726,t:1527023526148};\\\", \\\"{x:1330,y:725,t:1527023526165};\\\", \\\"{x:1331,y:724,t:1527023526181};\\\", \\\"{x:1332,y:723,t:1527023526198};\\\", \\\"{x:1333,y:721,t:1527023526216};\\\", \\\"{x:1334,y:719,t:1527023526232};\\\", \\\"{x:1335,y:718,t:1527023526248};\\\", \\\"{x:1337,y:716,t:1527023526265};\\\", \\\"{x:1338,y:715,t:1527023526282};\\\", \\\"{x:1340,y:712,t:1527023526299};\\\", \\\"{x:1341,y:712,t:1527023526315};\\\", \\\"{x:1341,y:711,t:1527023526339};\\\", \\\"{x:1341,y:710,t:1527023526459};\\\", \\\"{x:1341,y:709,t:1527023526507};\\\", \\\"{x:1342,y:709,t:1527023526517};\\\", \\\"{x:1343,y:708,t:1527023526533};\\\", \\\"{x:1344,y:706,t:1527023526549};\\\", \\\"{x:1344,y:705,t:1527023526566};\\\", \\\"{x:1344,y:703,t:1527023526583};\\\", \\\"{x:1346,y:701,t:1527023526600};\\\", \\\"{x:1346,y:699,t:1527023526616};\\\", \\\"{x:1348,y:697,t:1527023526634};\\\", \\\"{x:1348,y:696,t:1527023526650};\\\", \\\"{x:1348,y:695,t:1527023526666};\\\", \\\"{x:1348,y:696,t:1527023529515};\\\", \\\"{x:1348,y:697,t:1527023529523};\\\", \\\"{x:1348,y:700,t:1527023529539};\\\", \\\"{x:1348,y:702,t:1527023529556};\\\", \\\"{x:1348,y:703,t:1527023529574};\\\", \\\"{x:1348,y:704,t:1527023529603};\\\", \\\"{x:1348,y:705,t:1527023529619};\\\", \\\"{x:1346,y:706,t:1527023529627};\\\", \\\"{x:1346,y:707,t:1527023529651};\\\", \\\"{x:1346,y:708,t:1527023529667};\\\", \\\"{x:1345,y:709,t:1527023529675};\\\", \\\"{x:1345,y:710,t:1527023529699};\\\", \\\"{x:1345,y:711,t:1527023529715};\\\", \\\"{x:1344,y:712,t:1527023529739};\\\", \\\"{x:1344,y:714,t:1527023530587};\\\", \\\"{x:1343,y:719,t:1527023530594};\\\", \\\"{x:1343,y:722,t:1527023530610};\\\", \\\"{x:1343,y:728,t:1527023530626};\\\", \\\"{x:1343,y:743,t:1527023530643};\\\", \\\"{x:1343,y:755,t:1527023530660};\\\", \\\"{x:1344,y:765,t:1527023530676};\\\", \\\"{x:1344,y:777,t:1527023530693};\\\", \\\"{x:1351,y:793,t:1527023530709};\\\", \\\"{x:1356,y:811,t:1527023530727};\\\", \\\"{x:1361,y:829,t:1527023530743};\\\", \\\"{x:1366,y:849,t:1527023530760};\\\", \\\"{x:1371,y:865,t:1527023530776};\\\", \\\"{x:1377,y:879,t:1527023530793};\\\", \\\"{x:1382,y:889,t:1527023530809};\\\", \\\"{x:1389,y:899,t:1527023530827};\\\", \\\"{x:1392,y:904,t:1527023530842};\\\", \\\"{x:1400,y:914,t:1527023530859};\\\", \\\"{x:1409,y:927,t:1527023530877};\\\", \\\"{x:1424,y:943,t:1527023530894};\\\", \\\"{x:1434,y:951,t:1527023530910};\\\", \\\"{x:1439,y:954,t:1527023530927};\\\", \\\"{x:1443,y:957,t:1527023530944};\\\", \\\"{x:1449,y:960,t:1527023530961};\\\", \\\"{x:1453,y:960,t:1527023530977};\\\", \\\"{x:1454,y:960,t:1527023531219};\\\", \\\"{x:1455,y:960,t:1527023531234};\\\", \\\"{x:1456,y:960,t:1527023531331};\\\", \\\"{x:1457,y:960,t:1527023532139};\\\", \\\"{x:1459,y:960,t:1527023532154};\\\", \\\"{x:1460,y:960,t:1527023532179};\\\", \\\"{x:1462,y:960,t:1527023532195};\\\", \\\"{x:1463,y:960,t:1527023532219};\\\", \\\"{x:1465,y:960,t:1527023532235};\\\", \\\"{x:1466,y:960,t:1527023532251};\\\", \\\"{x:1468,y:960,t:1527023532264};\\\", \\\"{x:1471,y:960,t:1527023532280};\\\", \\\"{x:1476,y:961,t:1527023532296};\\\", \\\"{x:1482,y:962,t:1527023532314};\\\", \\\"{x:1488,y:963,t:1527023532330};\\\", \\\"{x:1490,y:963,t:1527023532347};\\\", \\\"{x:1491,y:963,t:1527023532364};\\\", \\\"{x:1489,y:963,t:1527023534355};\\\", \\\"{x:1486,y:963,t:1527023534368};\\\", \\\"{x:1473,y:963,t:1527023534385};\\\", \\\"{x:1466,y:963,t:1527023534402};\\\", \\\"{x:1454,y:962,t:1527023534419};\\\", \\\"{x:1453,y:960,t:1527023534435};\\\", \\\"{x:1452,y:960,t:1527023534747};\\\", \\\"{x:1452,y:959,t:1527023534763};\\\", \\\"{x:1452,y:958,t:1527023534779};\\\", \\\"{x:1453,y:956,t:1527023534794};\\\", \\\"{x:1454,y:955,t:1527023534899};\\\", \\\"{x:1455,y:955,t:1527023534971};\\\", \\\"{x:1455,y:954,t:1527023535027};\\\", \\\"{x:1456,y:954,t:1527023535075};\\\", \\\"{x:1457,y:954,t:1527023535090};\\\", \\\"{x:1458,y:954,t:1527023535103};\\\", \\\"{x:1459,y:954,t:1527023535120};\\\", \\\"{x:1460,y:954,t:1527023535138};\\\", \\\"{x:1462,y:954,t:1527023535154};\\\", \\\"{x:1463,y:954,t:1527023535170};\\\", \\\"{x:1466,y:954,t:1527023535186};\\\", \\\"{x:1469,y:955,t:1527023535204};\\\", \\\"{x:1470,y:956,t:1527023535243};\\\", \\\"{x:1471,y:956,t:1527023535254};\\\", \\\"{x:1472,y:957,t:1527023535271};\\\", \\\"{x:1474,y:958,t:1527023535306};\\\", \\\"{x:1475,y:958,t:1527023535339};\\\", \\\"{x:1476,y:958,t:1527023535354};\\\", \\\"{x:1477,y:958,t:1527023535403};\\\", \\\"{x:1478,y:958,t:1527023535499};\\\", \\\"{x:1476,y:958,t:1527023535755};\\\", \\\"{x:1465,y:958,t:1527023535772};\\\", \\\"{x:1449,y:958,t:1527023535789};\\\", \\\"{x:1422,y:953,t:1527023535805};\\\", \\\"{x:1316,y:931,t:1527023535822};\\\", \\\"{x:1175,y:890,t:1527023535839};\\\", \\\"{x:1066,y:870,t:1527023535855};\\\", \\\"{x:975,y:849,t:1527023535872};\\\", \\\"{x:904,y:823,t:1527023535888};\\\", \\\"{x:863,y:807,t:1527023535906};\\\", \\\"{x:846,y:797,t:1527023535922};\\\", \\\"{x:836,y:792,t:1527023535938};\\\", \\\"{x:834,y:790,t:1527023535956};\\\", \\\"{x:834,y:787,t:1527023535972};\\\", \\\"{x:834,y:782,t:1527023535989};\\\", \\\"{x:834,y:780,t:1527023536007};\\\", \\\"{x:835,y:778,t:1527023536022};\\\", \\\"{x:839,y:774,t:1527023536083};\\\", \\\"{x:840,y:773,t:1527023536091};\\\", \\\"{x:840,y:771,t:1527023536106};\\\", \\\"{x:837,y:753,t:1527023536123};\\\", \\\"{x:833,y:739,t:1527023536139};\\\", \\\"{x:833,y:738,t:1527023536156};\\\", \\\"{x:828,y:730,t:1527023536172};\\\", \\\"{x:820,y:719,t:1527023536190};\\\", \\\"{x:804,y:703,t:1527023536206};\\\", \\\"{x:793,y:696,t:1527023536223};\\\", \\\"{x:787,y:693,t:1527023536240};\\\", \\\"{x:786,y:692,t:1527023536650};\\\", \\\"{x:785,y:692,t:1527023536659};\\\", \\\"{x:783,y:690,t:1527023536673};\\\", \\\"{x:782,y:690,t:1527023536723};\\\", \\\"{x:782,y:688,t:1527023536730};\\\", \\\"{x:780,y:682,t:1527023536741};\\\", \\\"{x:769,y:662,t:1527023536758};\\\", \\\"{x:758,y:645,t:1527023536773};\\\", \\\"{x:749,y:631,t:1527023536791};\\\", \\\"{x:739,y:615,t:1527023536808};\\\", \\\"{x:731,y:602,t:1527023536824};\\\", \\\"{x:727,y:596,t:1527023536834};\\\", \\\"{x:719,y:581,t:1527023536850};\\\", \\\"{x:717,y:573,t:1527023536867};\\\", \\\"{x:716,y:566,t:1527023536886};\\\", \\\"{x:715,y:559,t:1527023536903};\\\", \\\"{x:713,y:553,t:1527023536919};\\\", \\\"{x:710,y:549,t:1527023536936};\\\", \\\"{x:709,y:547,t:1527023536953};\\\", \\\"{x:708,y:546,t:1527023536987};\\\", \\\"{x:707,y:545,t:1527023537003};\\\", \\\"{x:707,y:544,t:1527023537019};\\\", \\\"{x:705,y:544,t:1527023537226};\\\", \\\"{x:704,y:543,t:1527023537242};\\\", \\\"{x:703,y:543,t:1527023537307};\\\", \\\"{x:702,y:542,t:1527023537323};\\\", \\\"{x:700,y:542,t:1527023537339};\\\", \\\"{x:698,y:540,t:1527023537354};\\\", \\\"{x:697,y:540,t:1527023537369};\\\", \\\"{x:696,y:539,t:1527023537387};\\\", \\\"{x:695,y:538,t:1527023537411};\\\", \\\"{x:692,y:538,t:1527023537420};\\\", \\\"{x:684,y:538,t:1527023537436};\\\", \\\"{x:678,y:538,t:1527023537452};\\\", \\\"{x:672,y:538,t:1527023537470};\\\", \\\"{x:666,y:538,t:1527023537486};\\\", \\\"{x:659,y:538,t:1527023537503};\\\", \\\"{x:651,y:538,t:1527023537520};\\\", \\\"{x:643,y:536,t:1527023537536};\\\", \\\"{x:632,y:534,t:1527023537553};\\\", \\\"{x:623,y:533,t:1527023537570};\\\", \\\"{x:621,y:532,t:1527023537586};\\\", \\\"{x:620,y:531,t:1527023537643};\\\", \\\"{x:617,y:526,t:1527023537653};\\\", \\\"{x:612,y:522,t:1527023537670};\\\", \\\"{x:608,y:517,t:1527023537687};\\\", \\\"{x:604,y:512,t:1527023537703};\\\", \\\"{x:600,y:509,t:1527023537720};\\\", \\\"{x:599,y:508,t:1527023537737};\\\", \\\"{x:599,y:507,t:1527023537771};\\\", \\\"{x:599,y:506,t:1527023537787};\\\", \\\"{x:599,y:504,t:1527023537803};\\\", \\\"{x:600,y:502,t:1527023537820};\\\", \\\"{x:598,y:507,t:1527023538091};\\\", \\\"{x:592,y:521,t:1527023538104};\\\", \\\"{x:583,y:543,t:1527023538120};\\\", \\\"{x:576,y:563,t:1527023538137};\\\", \\\"{x:566,y:581,t:1527023538153};\\\", \\\"{x:560,y:601,t:1527023538170};\\\", \\\"{x:556,y:620,t:1527023538187};\\\", \\\"{x:555,y:632,t:1527023538205};\\\", \\\"{x:554,y:646,t:1527023538220};\\\", \\\"{x:551,y:657,t:1527023538237};\\\", \\\"{x:550,y:669,t:1527023538254};\\\", \\\"{x:550,y:679,t:1527023538270};\\\", \\\"{x:550,y:684,t:1527023538286};\\\", \\\"{x:549,y:688,t:1527023538304};\\\", \\\"{x:548,y:690,t:1527023538320};\\\", \\\"{x:547,y:693,t:1527023538336};\\\", \\\"{x:547,y:700,t:1527023538354};\\\", \\\"{x:546,y:706,t:1527023538370};\\\", \\\"{x:543,y:712,t:1527023538386};\\\", \\\"{x:542,y:715,t:1527023538404};\\\", \\\"{x:540,y:719,t:1527023538420};\\\", \\\"{x:538,y:724,t:1527023538438};\\\", \\\"{x:536,y:727,t:1527023538454};\\\", \\\"{x:536,y:730,t:1527023538469};\\\", \\\"{x:536,y:733,t:1527023538487};\\\", \\\"{x:535,y:735,t:1527023538504};\\\", \\\"{x:535,y:737,t:1527023538520};\\\", \\\"{x:534,y:738,t:1527023538669};\\\", \\\"{x:533,y:737,t:1527023538687};\\\", \\\"{x:533,y:734,t:1527023538954};\\\", \\\"{x:533,y:726,t:1527023538971};\\\", \\\"{x:533,y:720,t:1527023538987};\\\", \\\"{x:533,y:716,t:1527023539004};\\\", \\\"{x:531,y:710,t:1527023539021};\\\", \\\"{x:529,y:704,t:1527023539037};\\\", \\\"{x:528,y:698,t:1527023539054};\\\", \\\"{x:525,y:692,t:1527023539071};\\\", \\\"{x:519,y:676,t:1527023539088};\\\", \\\"{x:512,y:662,t:1527023539104};\\\", \\\"{x:510,y:654,t:1527023539121};\\\", \\\"{x:510,y:651,t:1527023539138};\\\", \\\"{x:510,y:649,t:1527023539154};\\\", \\\"{x:510,y:643,t:1527023539171};\\\", \\\"{x:509,y:634,t:1527023539188};\\\", \\\"{x:506,y:622,t:1527023539204};\\\", \\\"{x:503,y:610,t:1527023539221};\\\", \\\"{x:501,y:602,t:1527023539237};\\\", \\\"{x:501,y:600,t:1527023539254};\\\", \\\"{x:501,y:595,t:1527023539271};\\\", \\\"{x:500,y:592,t:1527023539288};\\\", \\\"{x:499,y:587,t:1527023539304};\\\", \\\"{x:498,y:583,t:1527023539321};\\\", \\\"{x:497,y:577,t:1527023539338};\\\", \\\"{x:495,y:572,t:1527023539354};\\\", \\\"{x:492,y:561,t:1527023539370};\\\", \\\"{x:491,y:556,t:1527023539387};\\\", \\\"{x:489,y:551,t:1527023539404};\\\", \\\"{x:488,y:547,t:1527023539421};\\\", \\\"{x:488,y:545,t:1527023539438};\\\", \\\"{x:486,y:540,t:1527023539453};\\\", \\\"{x:485,y:538,t:1527023539471};\\\", \\\"{x:485,y:535,t:1527023539488};\\\", \\\"{x:485,y:532,t:1527023539504};\\\", \\\"{x:484,y:529,t:1527023539521};\\\", \\\"{x:483,y:527,t:1527023539538};\\\", \\\"{x:483,y:525,t:1527023539554};\\\", \\\"{x:482,y:524,t:1527023539570};\\\", \\\"{x:481,y:522,t:1527023539587};\\\", \\\"{x:481,y:520,t:1527023539605};\\\", \\\"{x:481,y:519,t:1527023539635};\\\", \\\"{x:479,y:518,t:1527023539642};\\\", \\\"{x:478,y:516,t:1527023539688};\\\", \\\"{x:478,y:514,t:1527023539705};\\\", \\\"{x:477,y:513,t:1527023539721};\\\", \\\"{x:477,y:512,t:1527023539738};\\\", \\\"{x:476,y:511,t:1527023539755};\\\" ] }, { \\\"rt\\\": 12602, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 15, \\\"time_elapsed\\\": 568462, \\\"internal_node_id\\\": \\\"0.0-6.0-5.0\\\", \\\"subject\\\": \\\"8LK9M\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"hotel\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 11, \\\"clicks\\\": 2.5, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"M\\\", \\\"L\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-M \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:474,y:505,t:1527023539865};\\\", \\\"{x:473,y:505,t:1527023539874};\\\", \\\"{x:472,y:503,t:1527023539893};\\\", \\\"{x:472,y:502,t:1527023539904};\\\", \\\"{x:471,y:501,t:1527023539921};\\\", \\\"{x:470,y:499,t:1527023539938};\\\", \\\"{x:469,y:498,t:1527023539954};\\\", \\\"{x:469,y:496,t:1527023539979};\\\", \\\"{x:468,y:496,t:1527023540021};\\\", \\\"{x:467,y:495,t:1527023540043};\\\", \\\"{x:467,y:494,t:1527023540058};\\\", \\\"{x:466,y:494,t:1527023540072};\\\", \\\"{x:466,y:492,t:1527023540088};\\\", \\\"{x:464,y:489,t:1527023540105};\\\", \\\"{x:461,y:485,t:1527023540122};\\\", \\\"{x:458,y:481,t:1527023540138};\\\", \\\"{x:451,y:472,t:1527023540154};\\\", \\\"{x:443,y:464,t:1527023540172};\\\", \\\"{x:433,y:458,t:1527023540189};\\\", \\\"{x:426,y:451,t:1527023540205};\\\", \\\"{x:422,y:448,t:1527023540222};\\\", \\\"{x:420,y:446,t:1527023540239};\\\", \\\"{x:414,y:441,t:1527023540310};\\\", \\\"{x:413,y:441,t:1527023540323};\\\", \\\"{x:418,y:441,t:1527023540827};\\\", \\\"{x:422,y:441,t:1527023540839};\\\", \\\"{x:437,y:442,t:1527023540856};\\\", \\\"{x:458,y:447,t:1527023540872};\\\", \\\"{x:472,y:448,t:1527023540889};\\\", \\\"{x:481,y:449,t:1527023540906};\\\", \\\"{x:491,y:450,t:1527023540922};\\\", \\\"{x:509,y:452,t:1527023540939};\\\", \\\"{x:521,y:453,t:1527023540956};\\\", \\\"{x:530,y:453,t:1527023540972};\\\", \\\"{x:545,y:453,t:1527023540989};\\\", \\\"{x:559,y:453,t:1527023541006};\\\", \\\"{x:568,y:453,t:1527023541023};\\\", \\\"{x:572,y:453,t:1527023541039};\\\", \\\"{x:578,y:453,t:1527023541056};\\\", \\\"{x:581,y:453,t:1527023541072};\\\", \\\"{x:583,y:453,t:1527023541089};\\\", \\\"{x:585,y:453,t:1527023541106};\\\", \\\"{x:588,y:453,t:1527023541122};\\\", \\\"{x:593,y:453,t:1527023541139};\\\", \\\"{x:602,y:453,t:1527023541155};\\\", \\\"{x:609,y:453,t:1527023541172};\\\", \\\"{x:615,y:453,t:1527023541189};\\\", \\\"{x:619,y:455,t:1527023541206};\\\", \\\"{x:621,y:455,t:1527023541223};\\\", \\\"{x:622,y:455,t:1527023541239};\\\", \\\"{x:622,y:455,t:1527023541355};\\\", \\\"{x:623,y:455,t:1527023541363};\\\", \\\"{x:624,y:455,t:1527023543043};\\\", \\\"{x:626,y:455,t:1527023543057};\\\", \\\"{x:634,y:457,t:1527023543074};\\\", \\\"{x:656,y:465,t:1527023543090};\\\", \\\"{x:672,y:470,t:1527023543107};\\\", \\\"{x:686,y:473,t:1527023543124};\\\", \\\"{x:698,y:477,t:1527023543140};\\\", \\\"{x:708,y:480,t:1527023543157};\\\", \\\"{x:721,y:485,t:1527023543174};\\\", \\\"{x:736,y:488,t:1527023543191};\\\", \\\"{x:747,y:492,t:1527023543207};\\\", \\\"{x:762,y:498,t:1527023543224};\\\", \\\"{x:778,y:503,t:1527023543241};\\\", \\\"{x:789,y:507,t:1527023543256};\\\", \\\"{x:808,y:514,t:1527023543274};\\\", \\\"{x:822,y:518,t:1527023543292};\\\", \\\"{x:833,y:523,t:1527023543307};\\\", \\\"{x:847,y:528,t:1527023543324};\\\", \\\"{x:863,y:535,t:1527023543341};\\\", \\\"{x:879,y:542,t:1527023543358};\\\", \\\"{x:895,y:550,t:1527023543374};\\\", \\\"{x:915,y:558,t:1527023543391};\\\", \\\"{x:931,y:566,t:1527023543409};\\\", \\\"{x:947,y:572,t:1527023543424};\\\", \\\"{x:961,y:580,t:1527023543441};\\\", \\\"{x:979,y:588,t:1527023543458};\\\", \\\"{x:998,y:599,t:1527023543474};\\\", \\\"{x:1028,y:619,t:1527023543491};\\\", \\\"{x:1051,y:634,t:1527023543508};\\\", \\\"{x:1076,y:652,t:1527023543524};\\\", \\\"{x:1109,y:672,t:1527023543541};\\\", \\\"{x:1147,y:694,t:1527023543558};\\\", \\\"{x:1175,y:706,t:1527023543574};\\\", \\\"{x:1194,y:719,t:1527023543591};\\\", \\\"{x:1212,y:732,t:1527023543608};\\\", \\\"{x:1232,y:745,t:1527023543624};\\\", \\\"{x:1256,y:760,t:1527023543641};\\\", \\\"{x:1282,y:768,t:1527023543658};\\\", \\\"{x:1299,y:774,t:1527023543674};\\\", \\\"{x:1310,y:777,t:1527023543691};\\\", \\\"{x:1313,y:779,t:1527023543708};\\\", \\\"{x:1313,y:781,t:1527023543724};\\\", \\\"{x:1313,y:782,t:1527023543746};\\\", \\\"{x:1314,y:784,t:1527023544555};\\\", \\\"{x:1320,y:786,t:1527023544563};\\\", \\\"{x:1321,y:787,t:1527023544576};\\\", \\\"{x:1322,y:788,t:1527023544650};\\\", \\\"{x:1322,y:789,t:1527023544699};\\\", \\\"{x:1322,y:790,t:1527023544714};\\\", \\\"{x:1322,y:791,t:1527023544725};\\\", \\\"{x:1322,y:793,t:1527023544742};\\\", \\\"{x:1322,y:794,t:1527023544763};\\\", \\\"{x:1322,y:796,t:1527023544778};\\\", \\\"{x:1322,y:797,t:1527023544792};\\\", \\\"{x:1322,y:800,t:1527023544809};\\\", \\\"{x:1321,y:803,t:1527023544825};\\\", \\\"{x:1319,y:807,t:1527023544842};\\\", \\\"{x:1317,y:813,t:1527023544859};\\\", \\\"{x:1316,y:817,t:1527023544875};\\\", \\\"{x:1314,y:822,t:1527023544892};\\\", \\\"{x:1312,y:827,t:1527023544910};\\\", \\\"{x:1312,y:834,t:1527023544925};\\\", \\\"{x:1312,y:840,t:1527023544942};\\\", \\\"{x:1312,y:845,t:1527023544959};\\\", \\\"{x:1312,y:849,t:1527023544975};\\\", \\\"{x:1312,y:853,t:1527023544992};\\\", \\\"{x:1312,y:859,t:1527023545009};\\\", \\\"{x:1312,y:863,t:1527023545026};\\\", \\\"{x:1312,y:867,t:1527023545042};\\\", \\\"{x:1312,y:876,t:1527023545059};\\\", \\\"{x:1312,y:883,t:1527023545076};\\\", \\\"{x:1312,y:889,t:1527023545093};\\\", \\\"{x:1312,y:894,t:1527023545109};\\\", \\\"{x:1312,y:899,t:1527023545126};\\\", \\\"{x:1312,y:902,t:1527023545142};\\\", \\\"{x:1312,y:906,t:1527023545159};\\\", \\\"{x:1313,y:909,t:1527023545176};\\\", \\\"{x:1314,y:913,t:1527023545192};\\\", \\\"{x:1314,y:916,t:1527023545209};\\\", \\\"{x:1315,y:919,t:1527023545226};\\\", \\\"{x:1315,y:923,t:1527023545242};\\\", \\\"{x:1315,y:926,t:1527023545259};\\\", \\\"{x:1315,y:928,t:1527023545276};\\\", \\\"{x:1316,y:930,t:1527023545292};\\\", \\\"{x:1316,y:932,t:1527023545309};\\\", \\\"{x:1317,y:934,t:1527023545327};\\\", \\\"{x:1317,y:935,t:1527023545342};\\\", \\\"{x:1317,y:936,t:1527023545359};\\\", \\\"{x:1317,y:938,t:1527023545377};\\\", \\\"{x:1318,y:940,t:1527023545392};\\\", \\\"{x:1318,y:941,t:1527023545410};\\\", \\\"{x:1319,y:942,t:1527023545427};\\\", \\\"{x:1320,y:943,t:1527023545442};\\\", \\\"{x:1321,y:944,t:1527023545466};\\\", \\\"{x:1321,y:945,t:1527023545490};\\\", \\\"{x:1323,y:946,t:1527023545506};\\\", \\\"{x:1323,y:947,t:1527023545514};\\\", \\\"{x:1324,y:947,t:1527023545530};\\\", \\\"{x:1324,y:948,t:1527023545547};\\\", \\\"{x:1325,y:950,t:1527023545559};\\\", \\\"{x:1326,y:951,t:1527023545576};\\\", \\\"{x:1327,y:952,t:1527023545592};\\\", \\\"{x:1329,y:953,t:1527023545609};\\\", \\\"{x:1332,y:954,t:1527023545627};\\\", \\\"{x:1333,y:955,t:1527023545642};\\\", \\\"{x:1334,y:956,t:1527023545660};\\\", \\\"{x:1334,y:957,t:1527023545677};\\\", \\\"{x:1335,y:957,t:1527023545692};\\\", \\\"{x:1336,y:959,t:1527023545709};\\\", \\\"{x:1337,y:961,t:1527023545726};\\\", \\\"{x:1338,y:962,t:1527023545742};\\\", \\\"{x:1339,y:963,t:1527023545760};\\\", \\\"{x:1340,y:964,t:1527023545843};\\\", \\\"{x:1341,y:964,t:1527023545955};\\\", \\\"{x:1343,y:964,t:1527023546114};\\\", \\\"{x:1344,y:963,t:1527023546147};\\\", \\\"{x:1345,y:962,t:1527023546163};\\\", \\\"{x:1346,y:961,t:1527023546178};\\\", \\\"{x:1346,y:960,t:1527023546193};\\\", \\\"{x:1350,y:957,t:1527023546211};\\\", \\\"{x:1352,y:954,t:1527023546226};\\\", \\\"{x:1354,y:953,t:1527023546243};\\\", \\\"{x:1355,y:951,t:1527023546260};\\\", \\\"{x:1357,y:949,t:1527023546277};\\\", \\\"{x:1359,y:947,t:1527023546293};\\\", \\\"{x:1362,y:943,t:1527023546310};\\\", \\\"{x:1363,y:940,t:1527023546326};\\\", \\\"{x:1365,y:938,t:1527023546343};\\\", \\\"{x:1366,y:937,t:1527023546360};\\\", \\\"{x:1367,y:935,t:1527023546377};\\\", \\\"{x:1367,y:933,t:1527023546393};\\\", \\\"{x:1369,y:929,t:1527023546410};\\\", \\\"{x:1369,y:926,t:1527023546427};\\\", \\\"{x:1369,y:924,t:1527023546443};\\\", \\\"{x:1372,y:922,t:1527023546460};\\\", \\\"{x:1372,y:920,t:1527023546476};\\\", \\\"{x:1373,y:919,t:1527023546494};\\\", \\\"{x:1376,y:915,t:1527023546510};\\\", \\\"{x:1377,y:912,t:1527023546527};\\\", \\\"{x:1379,y:907,t:1527023546544};\\\", \\\"{x:1380,y:902,t:1527023546561};\\\", \\\"{x:1382,y:898,t:1527023546577};\\\", \\\"{x:1383,y:897,t:1527023546593};\\\", \\\"{x:1383,y:896,t:1527023546610};\\\", \\\"{x:1383,y:895,t:1527023546674};\\\", \\\"{x:1384,y:895,t:1527023546683};\\\", \\\"{x:1385,y:894,t:1527023546739};\\\", \\\"{x:1386,y:892,t:1527023546771};\\\", \\\"{x:1387,y:892,t:1527023546795};\\\", \\\"{x:1388,y:890,t:1527023546810};\\\", \\\"{x:1389,y:889,t:1527023546826};\\\", \\\"{x:1389,y:888,t:1527023546843};\\\", \\\"{x:1390,y:888,t:1527023546861};\\\", \\\"{x:1392,y:885,t:1527023546878};\\\", \\\"{x:1393,y:883,t:1527023546893};\\\", \\\"{x:1395,y:881,t:1527023546910};\\\", \\\"{x:1395,y:876,t:1527023546927};\\\", \\\"{x:1396,y:871,t:1527023546943};\\\", \\\"{x:1397,y:864,t:1527023546960};\\\", \\\"{x:1397,y:858,t:1527023546977};\\\", \\\"{x:1397,y:849,t:1527023546994};\\\", \\\"{x:1397,y:840,t:1527023547010};\\\", \\\"{x:1397,y:824,t:1527023547027};\\\", \\\"{x:1397,y:813,t:1527023547043};\\\", \\\"{x:1397,y:802,t:1527023547061};\\\", \\\"{x:1397,y:794,t:1527023547078};\\\", \\\"{x:1397,y:782,t:1527023547093};\\\", \\\"{x:1397,y:773,t:1527023547111};\\\", \\\"{x:1397,y:762,t:1527023547128};\\\", \\\"{x:1398,y:757,t:1527023547143};\\\", \\\"{x:1399,y:753,t:1527023547160};\\\", \\\"{x:1400,y:748,t:1527023547177};\\\", \\\"{x:1404,y:740,t:1527023547194};\\\", \\\"{x:1404,y:738,t:1527023547210};\\\", \\\"{x:1407,y:733,t:1527023547227};\\\", \\\"{x:1407,y:731,t:1527023547244};\\\", \\\"{x:1407,y:729,t:1527023547260};\\\", \\\"{x:1407,y:728,t:1527023547339};\\\", \\\"{x:1400,y:732,t:1527023547346};\\\", \\\"{x:1390,y:736,t:1527023547360};\\\", \\\"{x:1369,y:750,t:1527023547378};\\\", \\\"{x:1326,y:764,t:1527023547394};\\\", \\\"{x:1287,y:775,t:1527023547410};\\\", \\\"{x:1245,y:783,t:1527023547427};\\\", \\\"{x:1208,y:788,t:1527023547444};\\\", \\\"{x:1175,y:789,t:1527023547461};\\\", \\\"{x:1150,y:789,t:1527023547477};\\\", \\\"{x:1126,y:789,t:1527023547494};\\\", \\\"{x:1099,y:790,t:1527023547510};\\\", \\\"{x:1069,y:790,t:1527023547527};\\\", \\\"{x:1054,y:787,t:1527023547544};\\\", \\\"{x:1045,y:783,t:1527023547560};\\\", \\\"{x:1043,y:779,t:1527023547577};\\\", \\\"{x:1039,y:777,t:1527023547650};\\\", \\\"{x:1036,y:771,t:1527023547662};\\\", \\\"{x:1024,y:764,t:1527023547677};\\\", \\\"{x:1005,y:753,t:1527023547694};\\\", \\\"{x:970,y:734,t:1527023547711};\\\", \\\"{x:919,y:706,t:1527023547727};\\\", \\\"{x:871,y:680,t:1527023547744};\\\", \\\"{x:847,y:666,t:1527023547761};\\\", \\\"{x:835,y:663,t:1527023547778};\\\", \\\"{x:826,y:657,t:1527023547794};\\\", \\\"{x:823,y:653,t:1527023547811};\\\", \\\"{x:821,y:650,t:1527023547827};\\\", \\\"{x:819,y:647,t:1527023547844};\\\", \\\"{x:819,y:644,t:1527023547861};\\\", \\\"{x:822,y:640,t:1527023547877};\\\", \\\"{x:822,y:639,t:1527023548218};\\\", \\\"{x:817,y:636,t:1527023548228};\\\", \\\"{x:799,y:629,t:1527023548245};\\\", \\\"{x:787,y:628,t:1527023548262};\\\", \\\"{x:785,y:626,t:1527023548277};\\\", \\\"{x:784,y:625,t:1527023548387};\\\", \\\"{x:783,y:615,t:1527023548486};\\\", \\\"{x:783,y:613,t:1527023548494};\\\", \\\"{x:782,y:606,t:1527023548510};\\\", \\\"{x:781,y:600,t:1527023548527};\\\", \\\"{x:781,y:597,t:1527023548543};\\\", \\\"{x:781,y:592,t:1527023548563};\\\", \\\"{x:781,y:588,t:1527023548578};\\\", \\\"{x:782,y:583,t:1527023548595};\\\", \\\"{x:783,y:580,t:1527023548612};\\\", \\\"{x:785,y:577,t:1527023548629};\\\", \\\"{x:788,y:575,t:1527023548646};\\\", \\\"{x:791,y:571,t:1527023548662};\\\", \\\"{x:795,y:569,t:1527023548678};\\\", \\\"{x:800,y:567,t:1527023548696};\\\", \\\"{x:806,y:565,t:1527023548713};\\\", \\\"{x:813,y:563,t:1527023548728};\\\", \\\"{x:818,y:561,t:1527023548745};\\\", \\\"{x:825,y:558,t:1527023548762};\\\", \\\"{x:829,y:556,t:1527023548778};\\\", \\\"{x:831,y:555,t:1527023548796};\\\", \\\"{x:833,y:554,t:1527023548813};\\\", \\\"{x:835,y:551,t:1527023548829};\\\", \\\"{x:835,y:549,t:1527023548845};\\\", \\\"{x:837,y:546,t:1527023548862};\\\", \\\"{x:837,y:544,t:1527023548878};\\\", \\\"{x:837,y:540,t:1527023548895};\\\", \\\"{x:838,y:535,t:1527023548912};\\\", \\\"{x:838,y:531,t:1527023548928};\\\", \\\"{x:838,y:529,t:1527023548946};\\\", \\\"{x:838,y:527,t:1527023548962};\\\", \\\"{x:835,y:527,t:1527023548986};\\\", \\\"{x:829,y:527,t:1527023548996};\\\", \\\"{x:806,y:529,t:1527023549012};\\\", \\\"{x:774,y:538,t:1527023549029};\\\", \\\"{x:732,y:551,t:1527023549046};\\\", \\\"{x:685,y:562,t:1527023549063};\\\", \\\"{x:639,y:564,t:1527023549111};\\\", \\\"{x:637,y:563,t:1527023549129};\\\", \\\"{x:635,y:562,t:1527023549146};\\\", \\\"{x:634,y:561,t:1527023549171};\\\", \\\"{x:632,y:561,t:1527023549227};\\\", \\\"{x:631,y:561,t:1527023549235};\\\", \\\"{x:629,y:561,t:1527023549250};\\\", \\\"{x:623,y:561,t:1527023549262};\\\", \\\"{x:615,y:561,t:1527023549279};\\\", \\\"{x:604,y:561,t:1527023549295};\\\", \\\"{x:584,y:561,t:1527023549312};\\\", \\\"{x:559,y:561,t:1527023549329};\\\", \\\"{x:519,y:565,t:1527023549347};\\\", \\\"{x:496,y:569,t:1527023549363};\\\", \\\"{x:474,y:572,t:1527023549380};\\\", \\\"{x:454,y:574,t:1527023549395};\\\", \\\"{x:443,y:575,t:1527023549412};\\\", \\\"{x:434,y:579,t:1527023549429};\\\", \\\"{x:433,y:580,t:1527023549445};\\\", \\\"{x:431,y:580,t:1527023549466};\\\", \\\"{x:431,y:581,t:1527023549482};\\\", \\\"{x:430,y:581,t:1527023549506};\\\", \\\"{x:428,y:582,t:1527023549514};\\\", \\\"{x:426,y:583,t:1527023549528};\\\", \\\"{x:419,y:586,t:1527023549546};\\\", \\\"{x:406,y:587,t:1527023549563};\\\", \\\"{x:398,y:591,t:1527023549580};\\\", \\\"{x:393,y:591,t:1527023549597};\\\", \\\"{x:391,y:591,t:1527023549614};\\\", \\\"{x:387,y:591,t:1527023549630};\\\", \\\"{x:386,y:591,t:1527023549647};\\\", \\\"{x:384,y:591,t:1527023549663};\\\", \\\"{x:383,y:591,t:1527023549762};\\\", \\\"{x:381,y:591,t:1527023549771};\\\", \\\"{x:380,y:591,t:1527023549786};\\\", \\\"{x:379,y:591,t:1527023549802};\\\", \\\"{x:377,y:591,t:1527023549813};\\\", \\\"{x:374,y:591,t:1527023549830};\\\", \\\"{x:362,y:599,t:1527023549847};\\\", \\\"{x:355,y:604,t:1527023549864};\\\", \\\"{x:350,y:609,t:1527023549879};\\\", \\\"{x:347,y:609,t:1527023549896};\\\", \\\"{x:346,y:611,t:1527023549914};\\\", \\\"{x:346,y:612,t:1527023549938};\\\", \\\"{x:346,y:614,t:1527023549954};\\\", \\\"{x:346,y:615,t:1527023550010};\\\", \\\"{x:347,y:615,t:1527023550019};\\\", \\\"{x:351,y:615,t:1527023550030};\\\", \\\"{x:360,y:610,t:1527023550047};\\\", \\\"{x:364,y:605,t:1527023550064};\\\", \\\"{x:368,y:600,t:1527023550081};\\\", \\\"{x:371,y:592,t:1527023550098};\\\", \\\"{x:374,y:583,t:1527023550114};\\\", \\\"{x:376,y:575,t:1527023550129};\\\", \\\"{x:376,y:571,t:1527023550146};\\\", \\\"{x:376,y:570,t:1527023550163};\\\", \\\"{x:376,y:569,t:1527023550179};\\\", \\\"{x:376,y:567,t:1527023550242};\\\", \\\"{x:376,y:566,t:1527023550258};\\\", \\\"{x:376,y:565,t:1527023550274};\\\", \\\"{x:376,y:564,t:1527023550282};\\\", \\\"{x:376,y:563,t:1527023550298};\\\", \\\"{x:375,y:562,t:1527023550314};\\\", \\\"{x:372,y:553,t:1527023550331};\\\", \\\"{x:369,y:548,t:1527023550346};\\\", \\\"{x:367,y:543,t:1527023550363};\\\", \\\"{x:364,y:539,t:1527023550379};\\\", \\\"{x:364,y:538,t:1527023550396};\\\", \\\"{x:363,y:538,t:1527023550707};\\\", \\\"{x:361,y:539,t:1527023550714};\\\", \\\"{x:358,y:545,t:1527023550730};\\\", \\\"{x:356,y:554,t:1527023550746};\\\", \\\"{x:354,y:563,t:1527023550764};\\\", \\\"{x:354,y:569,t:1527023550780};\\\", \\\"{x:354,y:575,t:1527023550797};\\\", \\\"{x:354,y:578,t:1527023550814};\\\", \\\"{x:354,y:582,t:1527023550831};\\\", \\\"{x:355,y:585,t:1527023550847};\\\", \\\"{x:356,y:588,t:1527023550874};\\\", \\\"{x:357,y:588,t:1527023550890};\\\", \\\"{x:357,y:589,t:1527023550906};\\\", \\\"{x:358,y:589,t:1527023550915};\\\", \\\"{x:358,y:590,t:1527023550930};\\\", \\\"{x:360,y:590,t:1527023550970};\\\", \\\"{x:361,y:590,t:1527023550980};\\\", \\\"{x:367,y:576,t:1527023550997};\\\", \\\"{x:375,y:557,t:1527023551014};\\\", \\\"{x:377,y:549,t:1527023551031};\\\", \\\"{x:381,y:543,t:1527023551047};\\\", \\\"{x:381,y:542,t:1527023551064};\\\", \\\"{x:381,y:541,t:1527023551080};\\\", \\\"{x:381,y:542,t:1527023551378};\\\", \\\"{x:381,y:546,t:1527023551387};\\\", \\\"{x:381,y:551,t:1527023551398};\\\", \\\"{x:381,y:560,t:1527023551414};\\\", \\\"{x:381,y:569,t:1527023551431};\\\", \\\"{x:382,y:575,t:1527023551447};\\\", \\\"{x:383,y:578,t:1527023551464};\\\", \\\"{x:384,y:581,t:1527023551481};\\\", \\\"{x:384,y:583,t:1527023551497};\\\", \\\"{x:385,y:585,t:1527023551514};\\\", \\\"{x:386,y:588,t:1527023551531};\\\", \\\"{x:386,y:590,t:1527023551547};\\\", \\\"{x:388,y:594,t:1527023551565};\\\", \\\"{x:388,y:596,t:1527023551581};\\\", \\\"{x:389,y:599,t:1527023551597};\\\", \\\"{x:390,y:602,t:1527023551615};\\\", \\\"{x:391,y:606,t:1527023551631};\\\", \\\"{x:391,y:607,t:1527023551647};\\\", \\\"{x:391,y:608,t:1527023551664};\\\", \\\"{x:391,y:609,t:1527023551954};\\\", \\\"{x:394,y:616,t:1527023551965};\\\", \\\"{x:400,y:629,t:1527023551981};\\\", \\\"{x:411,y:647,t:1527023551998};\\\", \\\"{x:423,y:667,t:1527023552015};\\\", \\\"{x:434,y:682,t:1527023552032};\\\", \\\"{x:444,y:691,t:1527023552049};\\\", \\\"{x:454,y:699,t:1527023552065};\\\", \\\"{x:463,y:705,t:1527023552082};\\\", \\\"{x:470,y:710,t:1527023552098};\\\", \\\"{x:474,y:712,t:1527023552114};\\\", \\\"{x:475,y:713,t:1527023552131};\\\", \\\"{x:476,y:713,t:1527023552162};\\\", \\\"{x:477,y:713,t:1527023552171};\\\", \\\"{x:480,y:715,t:1527023552186};\\\", \\\"{x:483,y:716,t:1527023552198};\\\", \\\"{x:488,y:719,t:1527023552214};\\\", \\\"{x:497,y:724,t:1527023552233};\\\", \\\"{x:506,y:730,t:1527023552249};\\\", \\\"{x:512,y:734,t:1527023552264};\\\", \\\"{x:517,y:738,t:1527023552282};\\\", \\\"{x:520,y:740,t:1527023552297};\\\", \\\"{x:521,y:741,t:1527023552315};\\\", \\\"{x:521,y:743,t:1527023552338};\\\", \\\"{x:522,y:744,t:1527023552738};\\\", \\\"{x:529,y:744,t:1527023552748};\\\", \\\"{x:544,y:736,t:1527023552766};\\\", \\\"{x:561,y:724,t:1527023552781};\\\", \\\"{x:582,y:707,t:1527023552799};\\\", \\\"{x:601,y:691,t:1527023552816};\\\", \\\"{x:618,y:677,t:1527023552831};\\\", \\\"{x:630,y:658,t:1527023552849};\\\", \\\"{x:639,y:643,t:1527023552865};\\\", \\\"{x:642,y:632,t:1527023552881};\\\", \\\"{x:648,y:616,t:1527023552898};\\\", \\\"{x:650,y:609,t:1527023552915};\\\", \\\"{x:652,y:604,t:1527023552932};\\\", \\\"{x:652,y:599,t:1527023552948};\\\", \\\"{x:653,y:596,t:1527023552965};\\\", \\\"{x:654,y:591,t:1527023552982};\\\", \\\"{x:655,y:589,t:1527023552999};\\\", \\\"{x:656,y:587,t:1527023553015};\\\", \\\"{x:656,y:586,t:1527023553033};\\\", \\\"{x:656,y:585,t:1527023553049};\\\", \\\"{x:653,y:585,t:1527023553434};\\\", \\\"{x:649,y:585,t:1527023553450};\\\", \\\"{x:646,y:587,t:1527023553465};\\\", \\\"{x:643,y:588,t:1527023553522};\\\", \\\"{x:642,y:588,t:1527023553546};\\\", \\\"{x:641,y:589,t:1527023553562};\\\", \\\"{x:640,y:589,t:1527023553578};\\\", \\\"{x:638,y:590,t:1527023553585};\\\" ] }, { \\\"rt\\\": 9352, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 16, \\\"time_elapsed\\\": 579037, \\\"internal_node_id\\\": \\\"0.0-6.0-6.0\\\", \\\"subject\\\": \\\"8LK9M\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"hotel\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 12, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F -F -F -G \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:621,y:590,t:1527023553692};\\\", \\\"{x:620,y:590,t:1527023553717};\\\", \\\"{x:618,y:590,t:1527023553732};\\\", \\\"{x:617,y:591,t:1527023553874};\\\", \\\"{x:615,y:593,t:1527023553882};\\\", \\\"{x:609,y:599,t:1527023553900};\\\", \\\"{x:604,y:601,t:1527023553917};\\\", \\\"{x:600,y:603,t:1527023553932};\\\", \\\"{x:595,y:603,t:1527023553949};\\\", \\\"{x:589,y:603,t:1527023553966};\\\", \\\"{x:585,y:603,t:1527023553983};\\\", \\\"{x:583,y:603,t:1527023554000};\\\", \\\"{x:580,y:606,t:1527023554016};\\\", \\\"{x:579,y:606,t:1527023554739};\\\", \\\"{x:578,y:606,t:1527023554750};\\\", \\\"{x:573,y:602,t:1527023554767};\\\", \\\"{x:566,y:596,t:1527023554784};\\\", \\\"{x:559,y:589,t:1527023554801};\\\", \\\"{x:554,y:585,t:1527023554818};\\\", \\\"{x:549,y:581,t:1527023554834};\\\", \\\"{x:544,y:577,t:1527023554850};\\\", \\\"{x:541,y:574,t:1527023554868};\\\", \\\"{x:539,y:570,t:1527023554884};\\\", \\\"{x:535,y:563,t:1527023554900};\\\", \\\"{x:529,y:556,t:1527023554918};\\\", \\\"{x:523,y:547,t:1527023554935};\\\", \\\"{x:518,y:543,t:1527023554951};\\\", \\\"{x:511,y:536,t:1527023554966};\\\", \\\"{x:505,y:531,t:1527023554984};\\\", \\\"{x:497,y:525,t:1527023555001};\\\", \\\"{x:487,y:516,t:1527023555017};\\\", \\\"{x:478,y:507,t:1527023555034};\\\", \\\"{x:468,y:497,t:1527023555051};\\\", \\\"{x:460,y:490,t:1527023555068};\\\", \\\"{x:456,y:485,t:1527023555084};\\\", \\\"{x:447,y:478,t:1527023555101};\\\", \\\"{x:440,y:474,t:1527023555116};\\\", \\\"{x:434,y:471,t:1527023555134};\\\", \\\"{x:430,y:470,t:1527023555150};\\\", \\\"{x:429,y:470,t:1527023555167};\\\", \\\"{x:428,y:470,t:1527023555226};\\\", \\\"{x:427,y:469,t:1527023555251};\\\", \\\"{x:425,y:468,t:1527023555266};\\\", \\\"{x:421,y:467,t:1527023555283};\\\", \\\"{x:416,y:463,t:1527023555300};\\\", \\\"{x:409,y:460,t:1527023555316};\\\", \\\"{x:404,y:456,t:1527023555333};\\\", \\\"{x:397,y:451,t:1527023555349};\\\", \\\"{x:392,y:448,t:1527023555366};\\\", \\\"{x:389,y:447,t:1527023555382};\\\", \\\"{x:388,y:446,t:1527023555399};\\\", \\\"{x:387,y:445,t:1527023555417};\\\", \\\"{x:388,y:445,t:1527023555627};\\\", \\\"{x:389,y:445,t:1527023555650};\\\", \\\"{x:391,y:445,t:1527023555666};\\\", \\\"{x:394,y:445,t:1527023555682};\\\", \\\"{x:405,y:446,t:1527023555700};\\\", \\\"{x:421,y:448,t:1527023555718};\\\", \\\"{x:438,y:451,t:1527023555735};\\\", \\\"{x:454,y:452,t:1527023555751};\\\", \\\"{x:475,y:455,t:1527023555768};\\\", \\\"{x:495,y:460,t:1527023555785};\\\", \\\"{x:507,y:461,t:1527023555800};\\\", \\\"{x:513,y:461,t:1527023555818};\\\", \\\"{x:520,y:461,t:1527023555834};\\\", \\\"{x:526,y:462,t:1527023555851};\\\", \\\"{x:535,y:462,t:1527023555868};\\\", \\\"{x:548,y:462,t:1527023555884};\\\", \\\"{x:567,y:462,t:1527023555901};\\\", \\\"{x:582,y:462,t:1527023555918};\\\", \\\"{x:595,y:462,t:1527023555935};\\\", \\\"{x:606,y:462,t:1527023555951};\\\", \\\"{x:616,y:462,t:1527023555968};\\\", \\\"{x:626,y:462,t:1527023555985};\\\", \\\"{x:638,y:462,t:1527023556001};\\\", \\\"{x:650,y:462,t:1527023556017};\\\", \\\"{x:666,y:462,t:1527023556035};\\\", \\\"{x:674,y:462,t:1527023556052};\\\", \\\"{x:680,y:462,t:1527023556067};\\\", \\\"{x:681,y:462,t:1527023556084};\\\", \\\"{x:683,y:462,t:1527023556102};\\\", \\\"{x:684,y:462,t:1527023556117};\\\", \\\"{x:685,y:462,t:1527023556135};\\\", \\\"{x:686,y:462,t:1527023556151};\\\", \\\"{x:686,y:462,t:1527023556355};\\\", \\\"{x:688,y:467,t:1527023556491};\\\", \\\"{x:700,y:470,t:1527023556502};\\\", \\\"{x:725,y:477,t:1527023556519};\\\", \\\"{x:756,y:487,t:1527023556535};\\\", \\\"{x:803,y:497,t:1527023556551};\\\", \\\"{x:861,y:514,t:1527023556568};\\\", \\\"{x:922,y:531,t:1527023556586};\\\", \\\"{x:999,y:549,t:1527023556602};\\\", \\\"{x:1108,y:582,t:1527023556618};\\\", \\\"{x:1168,y:595,t:1527023556635};\\\", \\\"{x:1218,y:609,t:1527023556651};\\\", \\\"{x:1257,y:620,t:1527023556669};\\\", \\\"{x:1286,y:627,t:1527023556685};\\\", \\\"{x:1306,y:633,t:1527023556702};\\\", \\\"{x:1318,y:637,t:1527023556719};\\\", \\\"{x:1320,y:638,t:1527023556735};\\\", \\\"{x:1321,y:638,t:1527023556907};\\\", \\\"{x:1323,y:639,t:1527023556918};\\\", \\\"{x:1335,y:647,t:1527023556936};\\\", \\\"{x:1349,y:660,t:1527023556952};\\\", \\\"{x:1360,y:674,t:1527023556969};\\\", \\\"{x:1367,y:685,t:1527023556986};\\\", \\\"{x:1374,y:694,t:1527023557002};\\\", \\\"{x:1376,y:697,t:1527023557019};\\\", \\\"{x:1376,y:698,t:1527023557035};\\\", \\\"{x:1376,y:699,t:1527023557163};\\\", \\\"{x:1375,y:700,t:1527023557171};\\\", \\\"{x:1370,y:700,t:1527023557186};\\\", \\\"{x:1366,y:700,t:1527023557202};\\\", \\\"{x:1356,y:700,t:1527023557218};\\\", \\\"{x:1355,y:701,t:1527023557236};\\\", \\\"{x:1354,y:701,t:1527023557253};\\\", \\\"{x:1353,y:701,t:1527023557363};\\\", \\\"{x:1352,y:701,t:1527023557459};\\\", \\\"{x:1351,y:701,t:1527023557475};\\\", \\\"{x:1349,y:701,t:1527023557486};\\\", \\\"{x:1347,y:701,t:1527023557503};\\\", \\\"{x:1346,y:701,t:1527023557519};\\\", \\\"{x:1345,y:701,t:1527023557536};\\\", \\\"{x:1343,y:701,t:1527023557553};\\\", \\\"{x:1342,y:700,t:1527023558739};\\\", \\\"{x:1342,y:698,t:1527023558753};\\\", \\\"{x:1345,y:691,t:1527023558771};\\\", \\\"{x:1350,y:684,t:1527023558787};\\\", \\\"{x:1354,y:678,t:1527023558803};\\\", \\\"{x:1358,y:672,t:1527023558820};\\\", \\\"{x:1363,y:666,t:1527023558837};\\\", \\\"{x:1365,y:660,t:1527023558853};\\\", \\\"{x:1369,y:651,t:1527023558870};\\\", \\\"{x:1372,y:643,t:1527023558886};\\\", \\\"{x:1374,y:634,t:1527023558903};\\\", \\\"{x:1377,y:626,t:1527023558920};\\\", \\\"{x:1379,y:620,t:1527023558937};\\\", \\\"{x:1384,y:613,t:1527023558953};\\\", \\\"{x:1387,y:608,t:1527023558970};\\\", \\\"{x:1389,y:604,t:1527023558986};\\\", \\\"{x:1390,y:602,t:1527023559003};\\\", \\\"{x:1392,y:600,t:1527023559019};\\\", \\\"{x:1394,y:597,t:1527023559037};\\\", \\\"{x:1395,y:595,t:1527023559053};\\\", \\\"{x:1396,y:594,t:1527023559070};\\\", \\\"{x:1397,y:592,t:1527023559087};\\\", \\\"{x:1398,y:591,t:1527023559103};\\\", \\\"{x:1400,y:589,t:1527023559120};\\\", \\\"{x:1402,y:586,t:1527023559137};\\\", \\\"{x:1404,y:583,t:1527023559152};\\\", \\\"{x:1406,y:581,t:1527023559170};\\\", \\\"{x:1407,y:579,t:1527023559187};\\\", \\\"{x:1408,y:577,t:1527023559202};\\\", \\\"{x:1409,y:576,t:1527023559220};\\\", \\\"{x:1410,y:574,t:1527023559237};\\\", \\\"{x:1411,y:572,t:1527023559253};\\\", \\\"{x:1411,y:571,t:1527023559270};\\\", \\\"{x:1412,y:569,t:1527023559287};\\\", \\\"{x:1412,y:568,t:1527023559306};\\\", \\\"{x:1412,y:567,t:1527023559337};\\\", \\\"{x:1408,y:567,t:1527023559483};\\\", \\\"{x:1398,y:572,t:1527023559490};\\\", \\\"{x:1383,y:578,t:1527023559504};\\\", \\\"{x:1346,y:584,t:1527023559519};\\\", \\\"{x:1295,y:592,t:1527023559537};\\\", \\\"{x:1228,y:602,t:1527023559554};\\\", \\\"{x:1153,y:613,t:1527023559569};\\\", \\\"{x:1048,y:629,t:1527023559587};\\\", \\\"{x:984,y:639,t:1527023559603};\\\", \\\"{x:937,y:645,t:1527023559620};\\\", \\\"{x:906,y:650,t:1527023559637};\\\", \\\"{x:887,y:651,t:1527023559654};\\\", \\\"{x:873,y:651,t:1527023559670};\\\", \\\"{x:859,y:651,t:1527023559687};\\\", \\\"{x:848,y:651,t:1527023559704};\\\", \\\"{x:830,y:652,t:1527023559720};\\\", \\\"{x:814,y:652,t:1527023559737};\\\", \\\"{x:800,y:652,t:1527023559754};\\\", \\\"{x:791,y:652,t:1527023559770};\\\", \\\"{x:781,y:648,t:1527023559787};\\\", \\\"{x:777,y:644,t:1527023559804};\\\", \\\"{x:769,y:638,t:1527023559820};\\\", \\\"{x:761,y:631,t:1527023559837};\\\", \\\"{x:750,y:623,t:1527023559853};\\\", \\\"{x:739,y:615,t:1527023559870};\\\", \\\"{x:726,y:607,t:1527023559887};\\\", \\\"{x:712,y:597,t:1527023559906};\\\", \\\"{x:698,y:591,t:1527023559921};\\\", \\\"{x:690,y:588,t:1527023559938};\\\", \\\"{x:688,y:587,t:1527023559953};\\\", \\\"{x:685,y:586,t:1527023559970};\\\", \\\"{x:682,y:584,t:1527023559987};\\\", \\\"{x:681,y:584,t:1527023560005};\\\", \\\"{x:675,y:582,t:1527023560020};\\\", \\\"{x:671,y:581,t:1527023560038};\\\", \\\"{x:664,y:579,t:1527023560055};\\\", \\\"{x:660,y:578,t:1527023560071};\\\", \\\"{x:651,y:576,t:1527023560088};\\\", \\\"{x:637,y:576,t:1527023560105};\\\", \\\"{x:621,y:573,t:1527023560121};\\\", \\\"{x:603,y:571,t:1527023560138};\\\", \\\"{x:581,y:571,t:1527023560154};\\\", \\\"{x:547,y:569,t:1527023560171};\\\", \\\"{x:522,y:568,t:1527023560188};\\\", \\\"{x:498,y:568,t:1527023560206};\\\", \\\"{x:471,y:568,t:1527023560222};\\\", \\\"{x:437,y:568,t:1527023560237};\\\", \\\"{x:413,y:566,t:1527023560255};\\\", \\\"{x:397,y:566,t:1527023560271};\\\", \\\"{x:388,y:566,t:1527023560288};\\\", \\\"{x:381,y:564,t:1527023560305};\\\", \\\"{x:380,y:564,t:1527023560322};\\\", \\\"{x:378,y:564,t:1527023560522};\\\", \\\"{x:375,y:564,t:1527023560538};\\\", \\\"{x:361,y:565,t:1527023560554};\\\", \\\"{x:346,y:566,t:1527023560571};\\\", \\\"{x:329,y:568,t:1527023560587};\\\", \\\"{x:305,y:568,t:1527023560604};\\\", \\\"{x:274,y:570,t:1527023560622};\\\", \\\"{x:250,y:570,t:1527023560639};\\\", \\\"{x:228,y:570,t:1527023560655};\\\", \\\"{x:212,y:570,t:1527023560672};\\\", \\\"{x:203,y:570,t:1527023560689};\\\", \\\"{x:200,y:570,t:1527023560704};\\\", \\\"{x:198,y:570,t:1527023560738};\\\", \\\"{x:196,y:570,t:1527023560794};\\\", \\\"{x:195,y:571,t:1527023560805};\\\", \\\"{x:193,y:572,t:1527023560821};\\\", \\\"{x:189,y:573,t:1527023560839};\\\", \\\"{x:188,y:574,t:1527023560856};\\\", \\\"{x:187,y:575,t:1527023560872};\\\", \\\"{x:186,y:577,t:1527023560889};\\\", \\\"{x:185,y:580,t:1527023560905};\\\", \\\"{x:184,y:587,t:1527023560923};\\\", \\\"{x:184,y:590,t:1527023560939};\\\", \\\"{x:184,y:592,t:1527023560955};\\\", \\\"{x:184,y:598,t:1527023560972};\\\", \\\"{x:184,y:603,t:1527023560989};\\\", \\\"{x:185,y:611,t:1527023561005};\\\", \\\"{x:191,y:622,t:1527023561022};\\\", \\\"{x:194,y:628,t:1527023561039};\\\", \\\"{x:198,y:633,t:1527023561055};\\\", \\\"{x:202,y:639,t:1527023561073};\\\", \\\"{x:207,y:645,t:1527023561089};\\\", \\\"{x:211,y:649,t:1527023561105};\\\", \\\"{x:216,y:654,t:1527023561122};\\\", \\\"{x:218,y:656,t:1527023561138};\\\", \\\"{x:220,y:657,t:1527023561156};\\\", \\\"{x:222,y:658,t:1527023561171};\\\", \\\"{x:223,y:658,t:1527023561194};\\\", \\\"{x:224,y:658,t:1527023561206};\\\", \\\"{x:226,y:659,t:1527023561222};\\\", \\\"{x:229,y:659,t:1527023561239};\\\", \\\"{x:237,y:659,t:1527023561256};\\\", \\\"{x:242,y:658,t:1527023561272};\\\", \\\"{x:246,y:655,t:1527023561288};\\\", \\\"{x:257,y:649,t:1527023561306};\\\", \\\"{x:275,y:638,t:1527023561322};\\\", \\\"{x:301,y:622,t:1527023561339};\\\", \\\"{x:333,y:603,t:1527023561356};\\\", \\\"{x:374,y:579,t:1527023561372};\\\", \\\"{x:414,y:557,t:1527023561389};\\\", \\\"{x:452,y:536,t:1527023561406};\\\", \\\"{x:478,y:523,t:1527023561422};\\\", \\\"{x:504,y:511,t:1527023561440};\\\", \\\"{x:525,y:502,t:1527023561455};\\\", \\\"{x:538,y:497,t:1527023561473};\\\", \\\"{x:557,y:489,t:1527023561489};\\\", \\\"{x:572,y:484,t:1527023561506};\\\", \\\"{x:595,y:477,t:1527023561523};\\\", \\\"{x:615,y:474,t:1527023561538};\\\", \\\"{x:630,y:473,t:1527023561555};\\\", \\\"{x:637,y:472,t:1527023561573};\\\", \\\"{x:644,y:472,t:1527023561589};\\\", \\\"{x:653,y:475,t:1527023561606};\\\", \\\"{x:667,y:479,t:1527023561623};\\\", \\\"{x:678,y:482,t:1527023561638};\\\", \\\"{x:690,y:484,t:1527023561656};\\\", \\\"{x:695,y:485,t:1527023561673};\\\", \\\"{x:698,y:485,t:1527023561689};\\\", \\\"{x:702,y:485,t:1527023561706};\\\", \\\"{x:706,y:485,t:1527023561722};\\\", \\\"{x:713,y:485,t:1527023561739};\\\", \\\"{x:729,y:486,t:1527023561756};\\\", \\\"{x:750,y:492,t:1527023561773};\\\", \\\"{x:762,y:495,t:1527023561789};\\\", \\\"{x:774,y:499,t:1527023561806};\\\", \\\"{x:782,y:501,t:1527023561823};\\\", \\\"{x:792,y:504,t:1527023561839};\\\", \\\"{x:800,y:509,t:1527023561856};\\\", \\\"{x:810,y:512,t:1527023561873};\\\", \\\"{x:820,y:517,t:1527023561888};\\\", \\\"{x:824,y:519,t:1527023561906};\\\", \\\"{x:825,y:519,t:1527023561923};\\\", \\\"{x:825,y:520,t:1527023561994};\\\", \\\"{x:826,y:521,t:1527023562006};\\\", \\\"{x:826,y:523,t:1527023562023};\\\", \\\"{x:826,y:524,t:1527023562039};\\\", \\\"{x:828,y:527,t:1527023562056};\\\", \\\"{x:829,y:528,t:1527023562073};\\\", \\\"{x:830,y:531,t:1527023562090};\\\", \\\"{x:832,y:533,t:1527023562106};\\\", \\\"{x:834,y:536,t:1527023562123};\\\", \\\"{x:835,y:537,t:1527023562370};\\\", \\\"{x:835,y:541,t:1527023562378};\\\", \\\"{x:828,y:553,t:1527023562390};\\\", \\\"{x:799,y:577,t:1527023562406};\\\", \\\"{x:767,y:600,t:1527023562423};\\\", \\\"{x:744,y:614,t:1527023562441};\\\", \\\"{x:727,y:625,t:1527023562456};\\\", \\\"{x:708,y:635,t:1527023562474};\\\", \\\"{x:691,y:645,t:1527023562490};\\\", \\\"{x:685,y:646,t:1527023562506};\\\", \\\"{x:680,y:650,t:1527023562523};\\\", \\\"{x:673,y:654,t:1527023562540};\\\", \\\"{x:666,y:657,t:1527023562556};\\\", \\\"{x:660,y:660,t:1527023562573};\\\", \\\"{x:652,y:663,t:1527023562589};\\\", \\\"{x:645,y:666,t:1527023562606};\\\", \\\"{x:636,y:670,t:1527023562623};\\\", \\\"{x:623,y:675,t:1527023562640};\\\", \\\"{x:603,y:681,t:1527023562656};\\\", \\\"{x:582,y:685,t:1527023562673};\\\", \\\"{x:557,y:688,t:1527023562690};\\\", \\\"{x:551,y:690,t:1527023562706};\\\", \\\"{x:535,y:692,t:1527023562723};\\\", \\\"{x:533,y:692,t:1527023562740};\\\", \\\"{x:531,y:693,t:1527023562756};\\\", \\\"{x:531,y:695,t:1527023562773};\\\", \\\"{x:529,y:703,t:1527023562789};\\\", \\\"{x:525,y:712,t:1527023562806};\\\", \\\"{x:523,y:718,t:1527023562822};\\\", \\\"{x:521,y:723,t:1527023562840};\\\", \\\"{x:521,y:724,t:1527023562856};\\\", \\\"{x:521,y:726,t:1527023562873};\\\", \\\"{x:521,y:729,t:1527023562890};\\\", \\\"{x:521,y:730,t:1527023562907};\\\", \\\"{x:521,y:731,t:1527023562923};\\\", \\\"{x:522,y:729,t:1527023563402};\\\", \\\"{x:523,y:719,t:1527023563410};\\\", \\\"{x:524,y:707,t:1527023563424};\\\", \\\"{x:529,y:671,t:1527023563440};\\\", \\\"{x:535,y:633,t:1527023563457};\\\", \\\"{x:542,y:610,t:1527023563474};\\\", \\\"{x:548,y:587,t:1527023563490};\\\", \\\"{x:552,y:566,t:1527023563507};\\\", \\\"{x:557,y:548,t:1527023563524};\\\", \\\"{x:561,y:531,t:1527023563540};\\\", \\\"{x:567,y:514,t:1527023563557};\\\", \\\"{x:569,y:501,t:1527023563573};\\\", \\\"{x:574,y:488,t:1527023563590};\\\", \\\"{x:577,y:481,t:1527023563607};\\\", \\\"{x:577,y:480,t:1527023563624};\\\", \\\"{x:578,y:479,t:1527023563826};\\\" ] }, { \\\"rt\\\": 14377, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 17, \\\"time_elapsed\\\": 594631, \\\"internal_node_id\\\": \\\"0.0-6.0-7.0\\\", \\\"subject\\\": \\\"8LK9M\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"hotel\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 13, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"E\\\", \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-Z -02 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:578,y:478,t:1527023564835};\\\", \\\"{x:577,y:478,t:1527023564842};\\\", \\\"{x:573,y:476,t:1527023564858};\\\", \\\"{x:569,y:476,t:1527023564875};\\\", \\\"{x:561,y:475,t:1527023564892};\\\", \\\"{x:555,y:472,t:1527023564908};\\\", \\\"{x:549,y:471,t:1527023564925};\\\", \\\"{x:547,y:470,t:1527023564942};\\\", \\\"{x:544,y:469,t:1527023564958};\\\", \\\"{x:543,y:469,t:1527023564978};\\\", \\\"{x:543,y:468,t:1527023564992};\\\", \\\"{x:541,y:467,t:1527023565024};\\\", \\\"{x:538,y:465,t:1527023565042};\\\", \\\"{x:536,y:465,t:1527023565058};\\\", \\\"{x:531,y:463,t:1527023565075};\\\", \\\"{x:525,y:461,t:1527023565092};\\\", \\\"{x:516,y:459,t:1527023565108};\\\", \\\"{x:502,y:456,t:1527023565125};\\\", \\\"{x:485,y:454,t:1527023565142};\\\", \\\"{x:465,y:450,t:1527023565159};\\\", \\\"{x:445,y:448,t:1527023565175};\\\", \\\"{x:430,y:445,t:1527023565192};\\\", \\\"{x:421,y:444,t:1527023565209};\\\", \\\"{x:418,y:444,t:1527023565225};\\\", \\\"{x:416,y:444,t:1527023565354};\\\", \\\"{x:415,y:444,t:1527023565362};\\\", \\\"{x:413,y:444,t:1527023565378};\\\", \\\"{x:416,y:444,t:1527023565554};\\\", \\\"{x:421,y:444,t:1527023565561};\\\", \\\"{x:428,y:444,t:1527023565576};\\\", \\\"{x:438,y:446,t:1527023565592};\\\", \\\"{x:449,y:447,t:1527023565608};\\\", \\\"{x:469,y:450,t:1527023565625};\\\", \\\"{x:487,y:453,t:1527023565642};\\\", \\\"{x:500,y:454,t:1527023565659};\\\", \\\"{x:506,y:454,t:1527023565676};\\\", \\\"{x:510,y:455,t:1527023565692};\\\", \\\"{x:512,y:455,t:1527023565709};\\\", \\\"{x:516,y:455,t:1527023565726};\\\", \\\"{x:517,y:455,t:1527023565742};\\\", \\\"{x:523,y:455,t:1527023565759};\\\", \\\"{x:528,y:455,t:1527023565776};\\\", \\\"{x:532,y:455,t:1527023565793};\\\", \\\"{x:536,y:455,t:1527023565809};\\\", \\\"{x:544,y:455,t:1527023565826};\\\", \\\"{x:550,y:456,t:1527023565842};\\\", \\\"{x:555,y:456,t:1527023565859};\\\", \\\"{x:562,y:456,t:1527023565875};\\\", \\\"{x:570,y:456,t:1527023565893};\\\", \\\"{x:583,y:456,t:1527023565909};\\\", \\\"{x:594,y:456,t:1527023565926};\\\", \\\"{x:604,y:456,t:1527023565942};\\\", \\\"{x:611,y:456,t:1527023565959};\\\", \\\"{x:617,y:457,t:1527023565976};\\\", \\\"{x:621,y:457,t:1527023565992};\\\", \\\"{x:624,y:457,t:1527023566009};\\\", \\\"{x:626,y:459,t:1527023566026};\\\", \\\"{x:627,y:459,t:1527023566043};\\\", \\\"{x:627,y:459,t:1527023566290};\\\", \\\"{x:628,y:459,t:1527023566883};\\\", \\\"{x:629,y:459,t:1527023567594};\\\", \\\"{x:636,y:459,t:1527023567603};\\\", \\\"{x:642,y:459,t:1527023567615};\\\", \\\"{x:670,y:462,t:1527023567632};\\\", \\\"{x:726,y:470,t:1527023567649};\\\", \\\"{x:785,y:478,t:1527023567665};\\\", \\\"{x:900,y:494,t:1527023567682};\\\", \\\"{x:992,y:509,t:1527023567699};\\\", \\\"{x:1035,y:513,t:1527023567710};\\\", \\\"{x:1118,y:524,t:1527023567726};\\\", \\\"{x:1199,y:537,t:1527023567743};\\\", \\\"{x:1255,y:545,t:1527023567760};\\\", \\\"{x:1303,y:553,t:1527023567777};\\\", \\\"{x:1346,y:561,t:1527023567793};\\\", \\\"{x:1386,y:568,t:1527023567811};\\\", \\\"{x:1403,y:571,t:1527023567826};\\\", \\\"{x:1417,y:573,t:1527023567844};\\\", \\\"{x:1430,y:576,t:1527023567860};\\\", \\\"{x:1440,y:579,t:1527023567876};\\\", \\\"{x:1448,y:582,t:1527023567893};\\\", \\\"{x:1452,y:582,t:1527023567911};\\\", \\\"{x:1458,y:582,t:1527023567926};\\\", \\\"{x:1464,y:582,t:1527023567943};\\\", \\\"{x:1470,y:582,t:1527023567961};\\\", \\\"{x:1474,y:582,t:1527023567976};\\\", \\\"{x:1477,y:582,t:1527023567993};\\\", \\\"{x:1479,y:582,t:1527023568010};\\\", \\\"{x:1481,y:582,t:1527023568026};\\\", \\\"{x:1477,y:584,t:1527023568058};\\\", \\\"{x:1474,y:585,t:1527023568067};\\\", \\\"{x:1472,y:586,t:1527023568076};\\\", \\\"{x:1470,y:588,t:1527023568094};\\\", \\\"{x:1467,y:591,t:1527023568110};\\\", \\\"{x:1465,y:591,t:1527023568627};\\\", \\\"{x:1463,y:591,t:1527023568644};\\\", \\\"{x:1462,y:593,t:1527023568660};\\\", \\\"{x:1462,y:597,t:1527023568676};\\\", \\\"{x:1463,y:601,t:1527023568694};\\\", \\\"{x:1466,y:608,t:1527023568710};\\\", \\\"{x:1471,y:617,t:1527023568726};\\\", \\\"{x:1477,y:628,t:1527023568744};\\\", \\\"{x:1485,y:644,t:1527023568760};\\\", \\\"{x:1498,y:658,t:1527023568776};\\\", \\\"{x:1514,y:676,t:1527023568793};\\\", \\\"{x:1539,y:694,t:1527023568811};\\\", \\\"{x:1557,y:705,t:1527023568826};\\\", \\\"{x:1570,y:713,t:1527023568844};\\\", \\\"{x:1581,y:719,t:1527023568860};\\\", \\\"{x:1587,y:721,t:1527023568877};\\\", \\\"{x:1591,y:721,t:1527023568893};\\\", \\\"{x:1594,y:723,t:1527023568910};\\\", \\\"{x:1598,y:723,t:1527023568926};\\\", \\\"{x:1599,y:723,t:1527023568943};\\\", \\\"{x:1601,y:723,t:1527023568960};\\\", \\\"{x:1606,y:723,t:1527023568977};\\\", \\\"{x:1609,y:721,t:1527023568993};\\\", \\\"{x:1612,y:718,t:1527023569010};\\\", \\\"{x:1613,y:717,t:1527023569026};\\\", \\\"{x:1613,y:716,t:1527023569043};\\\", \\\"{x:1615,y:714,t:1527023569060};\\\", \\\"{x:1615,y:713,t:1527023569076};\\\", \\\"{x:1616,y:712,t:1527023569094};\\\", \\\"{x:1616,y:711,t:1527023569110};\\\", \\\"{x:1616,y:710,t:1527023569130};\\\", \\\"{x:1616,y:709,t:1527023569202};\\\", \\\"{x:1616,y:708,t:1527023569226};\\\", \\\"{x:1618,y:707,t:1527023569243};\\\", \\\"{x:1618,y:706,t:1527023569290};\\\", \\\"{x:1618,y:705,t:1527023569299};\\\", \\\"{x:1618,y:703,t:1527023569330};\\\", \\\"{x:1618,y:702,t:1527023570019};\\\", \\\"{x:1618,y:701,t:1527023570067};\\\", \\\"{x:1616,y:701,t:1527023572507};\\\", \\\"{x:1615,y:705,t:1527023572515};\\\", \\\"{x:1614,y:708,t:1527023572528};\\\", \\\"{x:1614,y:713,t:1527023572545};\\\", \\\"{x:1614,y:723,t:1527023572560};\\\", \\\"{x:1614,y:738,t:1527023572577};\\\", \\\"{x:1614,y:766,t:1527023572594};\\\", \\\"{x:1613,y:783,t:1527023572610};\\\", \\\"{x:1607,y:800,t:1527023572628};\\\", \\\"{x:1604,y:800,t:1527023572644};\\\", \\\"{x:1601,y:810,t:1527023572660};\\\", \\\"{x:1600,y:810,t:1527023572682};\\\", \\\"{x:1600,y:811,t:1527023572714};\\\", \\\"{x:1599,y:812,t:1527023572727};\\\", \\\"{x:1596,y:815,t:1527023572745};\\\", \\\"{x:1593,y:820,t:1527023572760};\\\", \\\"{x:1592,y:820,t:1527023572778};\\\", \\\"{x:1591,y:820,t:1527023572826};\\\", \\\"{x:1590,y:822,t:1527023572833};\\\", \\\"{x:1590,y:824,t:1527023572844};\\\", \\\"{x:1587,y:828,t:1527023572861};\\\", \\\"{x:1585,y:830,t:1527023572877};\\\", \\\"{x:1583,y:832,t:1527023572894};\\\", \\\"{x:1578,y:837,t:1527023572910};\\\", \\\"{x:1574,y:840,t:1527023572927};\\\", \\\"{x:1572,y:843,t:1527023572944};\\\", \\\"{x:1566,y:843,t:1527023572960};\\\", \\\"{x:1563,y:846,t:1527023572977};\\\", \\\"{x:1556,y:850,t:1527023572994};\\\", \\\"{x:1552,y:852,t:1527023573010};\\\", \\\"{x:1551,y:852,t:1527023573027};\\\", \\\"{x:1548,y:855,t:1527023573044};\\\", \\\"{x:1544,y:861,t:1527023573060};\\\", \\\"{x:1542,y:867,t:1527023573077};\\\", \\\"{x:1540,y:870,t:1527023573094};\\\", \\\"{x:1539,y:874,t:1527023573110};\\\", \\\"{x:1537,y:878,t:1527023573127};\\\", \\\"{x:1537,y:880,t:1527023573144};\\\", \\\"{x:1535,y:886,t:1527023573160};\\\", \\\"{x:1530,y:895,t:1527023573177};\\\", \\\"{x:1522,y:908,t:1527023573193};\\\", \\\"{x:1518,y:917,t:1527023573210};\\\", \\\"{x:1512,y:928,t:1527023573227};\\\", \\\"{x:1507,y:939,t:1527023573244};\\\", \\\"{x:1501,y:952,t:1527023573260};\\\", \\\"{x:1494,y:961,t:1527023573278};\\\", \\\"{x:1485,y:972,t:1527023573294};\\\", \\\"{x:1481,y:976,t:1527023573311};\\\", \\\"{x:1477,y:981,t:1527023573327};\\\", \\\"{x:1475,y:983,t:1527023573345};\\\", \\\"{x:1474,y:984,t:1527023573361};\\\", \\\"{x:1473,y:984,t:1527023573458};\\\", \\\"{x:1473,y:982,t:1527023573466};\\\", \\\"{x:1473,y:981,t:1527023573477};\\\", \\\"{x:1473,y:979,t:1527023573494};\\\", \\\"{x:1473,y:976,t:1527023573510};\\\", \\\"{x:1473,y:972,t:1527023573527};\\\", \\\"{x:1473,y:968,t:1527023573545};\\\", \\\"{x:1474,y:966,t:1527023573560};\\\", \\\"{x:1475,y:965,t:1527023573578};\\\", \\\"{x:1475,y:964,t:1527023573594};\\\", \\\"{x:1476,y:963,t:1527023573610};\\\", \\\"{x:1477,y:962,t:1527023573650};\\\", \\\"{x:1477,y:960,t:1527023573674};\\\", \\\"{x:1478,y:958,t:1527023573698};\\\", \\\"{x:1479,y:957,t:1527023573714};\\\", \\\"{x:1479,y:956,t:1527023573727};\\\", \\\"{x:1480,y:955,t:1527023573744};\\\", \\\"{x:1481,y:953,t:1527023573760};\\\", \\\"{x:1481,y:952,t:1527023573777};\\\", \\\"{x:1482,y:950,t:1527023573795};\\\", \\\"{x:1483,y:950,t:1527023573866};\\\", \\\"{x:1485,y:950,t:1527023573882};\\\", \\\"{x:1487,y:950,t:1527023573899};\\\", \\\"{x:1487,y:951,t:1527023573910};\\\", \\\"{x:1487,y:954,t:1527023573928};\\\", \\\"{x:1487,y:957,t:1527023573945};\\\", \\\"{x:1487,y:958,t:1527023573961};\\\", \\\"{x:1487,y:959,t:1527023573977};\\\", \\\"{x:1487,y:960,t:1527023573995};\\\", \\\"{x:1487,y:961,t:1527023574012};\\\", \\\"{x:1486,y:961,t:1527023574028};\\\", \\\"{x:1485,y:961,t:1527023574083};\\\", \\\"{x:1484,y:962,t:1527023574114};\\\", \\\"{x:1483,y:962,t:1527023574146};\\\", \\\"{x:1482,y:962,t:1527023574178};\\\", \\\"{x:1481,y:962,t:1527023574227};\\\", \\\"{x:1480,y:962,t:1527023574258};\\\", \\\"{x:1479,y:960,t:1527023574658};\\\", \\\"{x:1479,y:959,t:1527023574682};\\\", \\\"{x:1479,y:958,t:1527023574698};\\\", \\\"{x:1479,y:957,t:1527023574715};\\\", \\\"{x:1478,y:956,t:1527023574802};\\\", \\\"{x:1477,y:956,t:1527023574922};\\\", \\\"{x:1476,y:956,t:1527023575011};\\\", \\\"{x:1475,y:956,t:1527023575034};\\\", \\\"{x:1474,y:956,t:1527023575045};\\\", \\\"{x:1472,y:956,t:1527023575074};\\\", \\\"{x:1471,y:956,t:1527023575082};\\\", \\\"{x:1470,y:956,t:1527023575106};\\\", \\\"{x:1469,y:956,t:1527023575114};\\\", \\\"{x:1468,y:956,t:1527023575130};\\\", \\\"{x:1467,y:956,t:1527023575170};\\\", \\\"{x:1466,y:956,t:1527023575178};\\\", \\\"{x:1465,y:956,t:1527023575194};\\\", \\\"{x:1461,y:956,t:1527023575211};\\\", \\\"{x:1460,y:956,t:1527023575228};\\\", \\\"{x:1458,y:956,t:1527023575245};\\\", \\\"{x:1455,y:955,t:1527023575262};\\\", \\\"{x:1451,y:955,t:1527023575278};\\\", \\\"{x:1445,y:952,t:1527023575294};\\\", \\\"{x:1440,y:951,t:1527023575312};\\\", \\\"{x:1432,y:948,t:1527023575327};\\\", \\\"{x:1422,y:942,t:1527023575345};\\\", \\\"{x:1414,y:938,t:1527023575362};\\\", \\\"{x:1407,y:933,t:1527023575378};\\\", \\\"{x:1397,y:926,t:1527023575394};\\\", \\\"{x:1391,y:923,t:1527023575412};\\\", \\\"{x:1386,y:921,t:1527023575428};\\\", \\\"{x:1378,y:917,t:1527023575445};\\\", \\\"{x:1370,y:914,t:1527023575462};\\\", \\\"{x:1359,y:908,t:1527023575478};\\\", \\\"{x:1344,y:901,t:1527023575495};\\\", \\\"{x:1322,y:884,t:1527023575512};\\\", \\\"{x:1290,y:859,t:1527023575528};\\\", \\\"{x:1255,y:833,t:1527023575545};\\\", \\\"{x:1243,y:816,t:1527023575562};\\\", \\\"{x:1242,y:809,t:1527023575578};\\\", \\\"{x:1242,y:808,t:1527023575906};\\\", \\\"{x:1233,y:803,t:1527023575914};\\\", \\\"{x:1220,y:796,t:1527023575928};\\\", \\\"{x:1178,y:783,t:1527023575944};\\\", \\\"{x:1110,y:760,t:1527023575962};\\\", \\\"{x:1045,y:733,t:1527023575977};\\\", \\\"{x:949,y:702,t:1527023575995};\\\", \\\"{x:879,y:678,t:1527023576011};\\\", \\\"{x:792,y:647,t:1527023576028};\\\", \\\"{x:704,y:612,t:1527023576045};\\\", \\\"{x:648,y:594,t:1527023576061};\\\", \\\"{x:629,y:588,t:1527023576078};\\\", \\\"{x:611,y:579,t:1527023576101};\\\", \\\"{x:595,y:571,t:1527023576117};\\\", \\\"{x:580,y:562,t:1527023576134};\\\", \\\"{x:567,y:557,t:1527023576151};\\\", \\\"{x:553,y:550,t:1527023576168};\\\", \\\"{x:544,y:546,t:1527023576185};\\\", \\\"{x:539,y:542,t:1527023576200};\\\", \\\"{x:538,y:539,t:1527023576217};\\\", \\\"{x:538,y:533,t:1527023576234};\\\", \\\"{x:538,y:528,t:1527023576251};\\\", \\\"{x:538,y:517,t:1527023576268};\\\", \\\"{x:542,y:503,t:1527023576284};\\\", \\\"{x:546,y:495,t:1527023576300};\\\", \\\"{x:548,y:488,t:1527023576317};\\\", \\\"{x:549,y:485,t:1527023576334};\\\", \\\"{x:550,y:484,t:1527023576350};\\\", \\\"{x:552,y:481,t:1527023576368};\\\", \\\"{x:555,y:480,t:1527023576385};\\\", \\\"{x:558,y:479,t:1527023576400};\\\", \\\"{x:562,y:479,t:1527023576417};\\\", \\\"{x:569,y:479,t:1527023576434};\\\", \\\"{x:572,y:479,t:1527023576451};\\\", \\\"{x:574,y:479,t:1527023576468};\\\", \\\"{x:577,y:480,t:1527023576484};\\\", \\\"{x:585,y:488,t:1527023576501};\\\", \\\"{x:598,y:505,t:1527023576517};\\\", \\\"{x:611,y:523,t:1527023576535};\\\", \\\"{x:624,y:532,t:1527023576553};\\\", \\\"{x:629,y:536,t:1527023576567};\\\", \\\"{x:631,y:537,t:1527023576584};\\\", \\\"{x:630,y:537,t:1527023576706};\\\", \\\"{x:630,y:535,t:1527023576718};\\\", \\\"{x:626,y:530,t:1527023576734};\\\", \\\"{x:620,y:521,t:1527023576752};\\\", \\\"{x:615,y:515,t:1527023576768};\\\", \\\"{x:614,y:514,t:1527023576785};\\\", \\\"{x:612,y:511,t:1527023576802};\\\", \\\"{x:610,y:507,t:1527023576817};\\\", \\\"{x:609,y:504,t:1527023576835};\\\", \\\"{x:608,y:502,t:1527023576852};\\\", \\\"{x:607,y:499,t:1527023576868};\\\", \\\"{x:606,y:496,t:1527023576884};\\\", \\\"{x:605,y:495,t:1527023576906};\\\", \\\"{x:604,y:494,t:1527023576922};\\\", \\\"{x:608,y:494,t:1527023577203};\\\", \\\"{x:627,y:494,t:1527023577218};\\\", \\\"{x:652,y:494,t:1527023577235};\\\", \\\"{x:673,y:494,t:1527023577252};\\\", \\\"{x:690,y:494,t:1527023577269};\\\", \\\"{x:702,y:494,t:1527023577284};\\\", \\\"{x:709,y:494,t:1527023577301};\\\", \\\"{x:714,y:494,t:1527023577319};\\\", \\\"{x:718,y:496,t:1527023577334};\\\", \\\"{x:723,y:496,t:1527023577352};\\\", \\\"{x:726,y:496,t:1527023577369};\\\", \\\"{x:732,y:495,t:1527023577386};\\\", \\\"{x:737,y:494,t:1527023577402};\\\", \\\"{x:746,y:491,t:1527023577418};\\\", \\\"{x:760,y:490,t:1527023577436};\\\", \\\"{x:776,y:490,t:1527023577452};\\\", \\\"{x:796,y:490,t:1527023577469};\\\", \\\"{x:803,y:492,t:1527023577486};\\\", \\\"{x:818,y:495,t:1527023577502};\\\", \\\"{x:832,y:500,t:1527023577519};\\\", \\\"{x:838,y:504,t:1527023577536};\\\", \\\"{x:842,y:505,t:1527023577552};\\\", \\\"{x:843,y:506,t:1527023577569};\\\", \\\"{x:844,y:507,t:1527023577585};\\\", \\\"{x:844,y:511,t:1527023577986};\\\", \\\"{x:836,y:525,t:1527023578003};\\\", \\\"{x:826,y:536,t:1527023578019};\\\", \\\"{x:811,y:555,t:1527023578036};\\\", \\\"{x:796,y:575,t:1527023578054};\\\", \\\"{x:775,y:601,t:1527023578070};\\\", \\\"{x:760,y:623,t:1527023578085};\\\", \\\"{x:750,y:638,t:1527023578103};\\\", \\\"{x:737,y:652,t:1527023578118};\\\", \\\"{x:725,y:663,t:1527023578135};\\\", \\\"{x:716,y:673,t:1527023578153};\\\", \\\"{x:710,y:682,t:1527023578169};\\\", \\\"{x:706,y:687,t:1527023578185};\\\", \\\"{x:694,y:695,t:1527023578203};\\\", \\\"{x:682,y:702,t:1527023578219};\\\", \\\"{x:656,y:714,t:1527023578237};\\\", \\\"{x:621,y:728,t:1527023578253};\\\", \\\"{x:589,y:736,t:1527023578269};\\\", \\\"{x:573,y:740,t:1527023578287};\\\", \\\"{x:568,y:740,t:1527023578302};\\\", \\\"{x:562,y:740,t:1527023578320};\\\", \\\"{x:558,y:739,t:1527023578337};\\\", \\\"{x:556,y:739,t:1527023578353};\\\", \\\"{x:554,y:738,t:1527023578370};\\\" ] }, { \\\"rt\\\": 7552, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 18, \\\"time_elapsed\\\": 603386, \\\"internal_node_id\\\": \\\"0.0-6.0-8.0\\\", \\\"subject\\\": \\\"8LK9M\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"hotel\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 14, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-X -X \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:603,y:561,t:1527023580315};\\\", \\\"{x:607,y:549,t:1527023580324};\\\", \\\"{x:610,y:539,t:1527023580338};\\\", \\\"{x:613,y:516,t:1527023580354};\\\", \\\"{x:616,y:495,t:1527023580371};\\\", \\\"{x:616,y:475,t:1527023580388};\\\", \\\"{x:616,y:453,t:1527023580404};\\\", \\\"{x:616,y:443,t:1527023580420};\\\", \\\"{x:616,y:440,t:1527023580438};\\\", \\\"{x:613,y:434,t:1527023580455};\\\", \\\"{x:606,y:427,t:1527023580471};\\\", \\\"{x:598,y:421,t:1527023580487};\\\", \\\"{x:589,y:415,t:1527023580505};\\\", \\\"{x:580,y:410,t:1527023580522};\\\", \\\"{x:579,y:409,t:1527023580537};\\\", \\\"{x:577,y:409,t:1527023580554};\\\", \\\"{x:576,y:409,t:1527023580572};\\\", \\\"{x:573,y:409,t:1527023580588};\\\", \\\"{x:569,y:409,t:1527023580605};\\\", \\\"{x:563,y:409,t:1527023580622};\\\", \\\"{x:556,y:411,t:1527023580639};\\\", \\\"{x:551,y:415,t:1527023580655};\\\", \\\"{x:546,y:418,t:1527023580672};\\\", \\\"{x:544,y:420,t:1527023580688};\\\", \\\"{x:539,y:424,t:1527023580704};\\\", \\\"{x:537,y:427,t:1527023580721};\\\", \\\"{x:536,y:430,t:1527023580739};\\\", \\\"{x:535,y:430,t:1527023580756};\\\", \\\"{x:535,y:432,t:1527023580772};\\\", \\\"{x:534,y:436,t:1527023580789};\\\", \\\"{x:534,y:439,t:1527023580806};\\\", \\\"{x:532,y:446,t:1527023580822};\\\", \\\"{x:532,y:450,t:1527023580839};\\\", \\\"{x:532,y:455,t:1527023580856};\\\", \\\"{x:532,y:461,t:1527023580872};\\\", \\\"{x:532,y:466,t:1527023580889};\\\", \\\"{x:532,y:473,t:1527023580906};\\\", \\\"{x:532,y:474,t:1527023580922};\\\", \\\"{x:532,y:475,t:1527023580938};\\\", \\\"{x:531,y:476,t:1527023581186};\\\", \\\"{x:525,y:475,t:1527023581194};\\\", \\\"{x:519,y:472,t:1527023581207};\\\", \\\"{x:515,y:470,t:1527023581223};\\\", \\\"{x:514,y:470,t:1527023581240};\\\", \\\"{x:512,y:469,t:1527023581257};\\\", \\\"{x:511,y:468,t:1527023581290};\\\", \\\"{x:511,y:467,t:1527023581307};\\\", \\\"{x:509,y:467,t:1527023581324};\\\", \\\"{x:508,y:467,t:1527023581490};\\\", \\\"{x:499,y:464,t:1527023581507};\\\", \\\"{x:488,y:460,t:1527023581523};\\\", \\\"{x:475,y:459,t:1527023581541};\\\", \\\"{x:472,y:458,t:1527023581558};\\\", \\\"{x:473,y:458,t:1527023581642};\\\", \\\"{x:479,y:458,t:1527023581657};\\\", \\\"{x:483,y:458,t:1527023581675};\\\", \\\"{x:492,y:458,t:1527023581691};\\\", \\\"{x:509,y:458,t:1527023581708};\\\", \\\"{x:532,y:458,t:1527023581724};\\\", \\\"{x:556,y:458,t:1527023581742};\\\", \\\"{x:578,y:458,t:1527023581757};\\\", \\\"{x:596,y:460,t:1527023581774};\\\", \\\"{x:610,y:462,t:1527023581792};\\\", \\\"{x:627,y:465,t:1527023581807};\\\", \\\"{x:645,y:472,t:1527023581825};\\\", \\\"{x:686,y:479,t:1527023581841};\\\", \\\"{x:720,y:484,t:1527023581858};\\\", \\\"{x:763,y:491,t:1527023581875};\\\", \\\"{x:795,y:496,t:1527023581891};\\\", \\\"{x:849,y:505,t:1527023581906};\\\", \\\"{x:895,y:507,t:1527023581922};\\\", \\\"{x:965,y:517,t:1527023581939};\\\", \\\"{x:1003,y:527,t:1527023581956};\\\", \\\"{x:1008,y:530,t:1527023581972};\\\", \\\"{x:1022,y:533,t:1527023581989};\\\", \\\"{x:1028,y:534,t:1527023582006};\\\", \\\"{x:1030,y:534,t:1527023582022};\\\", \\\"{x:1032,y:535,t:1527023582039};\\\", \\\"{x:1034,y:535,t:1527023582066};\\\", \\\"{x:1035,y:535,t:1527023582074};\\\", \\\"{x:1036,y:537,t:1527023582722};\\\", \\\"{x:1041,y:545,t:1527023582737};\\\", \\\"{x:1041,y:551,t:1527023582755};\\\", \\\"{x:1045,y:557,t:1527023582772};\\\", \\\"{x:1054,y:565,t:1527023582788};\\\", \\\"{x:1072,y:579,t:1527023582805};\\\", \\\"{x:1094,y:593,t:1527023582822};\\\", \\\"{x:1115,y:609,t:1527023582838};\\\", \\\"{x:1140,y:627,t:1527023582855};\\\", \\\"{x:1180,y:648,t:1527023582872};\\\", \\\"{x:1218,y:670,t:1527023582888};\\\", \\\"{x:1270,y:700,t:1527023582905};\\\", \\\"{x:1357,y:749,t:1527023582922};\\\", \\\"{x:1418,y:774,t:1527023582938};\\\", \\\"{x:1476,y:800,t:1527023582955};\\\", \\\"{x:1517,y:818,t:1527023582971};\\\", \\\"{x:1542,y:831,t:1527023582988};\\\", \\\"{x:1555,y:842,t:1527023583004};\\\", \\\"{x:1559,y:845,t:1527023583022};\\\", \\\"{x:1559,y:847,t:1527023583038};\\\", \\\"{x:1559,y:852,t:1527023583055};\\\", \\\"{x:1555,y:855,t:1527023583072};\\\", \\\"{x:1551,y:867,t:1527023583088};\\\", \\\"{x:1545,y:873,t:1527023583105};\\\", \\\"{x:1540,y:881,t:1527023583121};\\\", \\\"{x:1531,y:887,t:1527023583138};\\\", \\\"{x:1526,y:891,t:1527023583155};\\\", \\\"{x:1521,y:899,t:1527023583170};\\\", \\\"{x:1520,y:909,t:1527023583187};\\\", \\\"{x:1520,y:916,t:1527023583204};\\\", \\\"{x:1520,y:920,t:1527023583221};\\\", \\\"{x:1520,y:921,t:1527023583238};\\\", \\\"{x:1520,y:923,t:1527023583266};\\\", \\\"{x:1522,y:924,t:1527023583274};\\\", \\\"{x:1522,y:926,t:1527023583287};\\\", \\\"{x:1526,y:932,t:1527023583305};\\\", \\\"{x:1530,y:936,t:1527023583320};\\\", \\\"{x:1534,y:940,t:1527023583338};\\\", \\\"{x:1535,y:940,t:1527023583355};\\\", \\\"{x:1535,y:941,t:1527023583371};\\\", \\\"{x:1536,y:943,t:1527023583388};\\\", \\\"{x:1537,y:945,t:1527023583405};\\\", \\\"{x:1537,y:946,t:1527023583506};\\\", \\\"{x:1537,y:949,t:1527023583529};\\\", \\\"{x:1538,y:950,t:1527023583537};\\\", \\\"{x:1539,y:951,t:1527023583554};\\\", \\\"{x:1540,y:952,t:1527023583571};\\\", \\\"{x:1541,y:953,t:1527023583590};\\\", \\\"{x:1542,y:957,t:1527023583621};\\\", \\\"{x:1544,y:960,t:1527023583637};\\\", \\\"{x:1545,y:962,t:1527023583653};\\\", \\\"{x:1545,y:963,t:1527023583678};\\\", \\\"{x:1546,y:963,t:1527023583691};\\\", \\\"{x:1546,y:964,t:1527023583733};\\\", \\\"{x:1547,y:965,t:1527023583749};\\\", \\\"{x:1548,y:965,t:1527023583797};\\\", \\\"{x:1549,y:967,t:1527023583813};\\\", \\\"{x:1549,y:966,t:1527023584149};\\\", \\\"{x:1549,y:964,t:1527023584173};\\\", \\\"{x:1549,y:963,t:1527023584253};\\\", \\\"{x:1549,y:962,t:1527023584261};\\\", \\\"{x:1549,y:961,t:1527023584274};\\\", \\\"{x:1549,y:960,t:1527023584365};\\\", \\\"{x:1549,y:959,t:1527023584373};\\\", \\\"{x:1549,y:958,t:1527023584390};\\\", \\\"{x:1549,y:957,t:1527023584407};\\\", \\\"{x:1549,y:956,t:1527023584423};\\\", \\\"{x:1549,y:955,t:1527023584440};\\\", \\\"{x:1549,y:954,t:1527023584461};\\\", \\\"{x:1549,y:953,t:1527023584477};\\\", \\\"{x:1549,y:952,t:1527023584517};\\\", \\\"{x:1549,y:951,t:1527023584525};\\\", \\\"{x:1549,y:950,t:1527023584540};\\\", \\\"{x:1548,y:947,t:1527023584557};\\\", \\\"{x:1547,y:945,t:1527023584573};\\\", \\\"{x:1547,y:942,t:1527023584590};\\\", \\\"{x:1546,y:939,t:1527023584607};\\\", \\\"{x:1546,y:936,t:1527023584624};\\\", \\\"{x:1546,y:933,t:1527023584641};\\\", \\\"{x:1543,y:928,t:1527023584657};\\\", \\\"{x:1543,y:926,t:1527023584673};\\\", \\\"{x:1541,y:921,t:1527023584690};\\\", \\\"{x:1540,y:919,t:1527023584708};\\\", \\\"{x:1538,y:915,t:1527023584723};\\\", \\\"{x:1535,y:909,t:1527023584740};\\\", \\\"{x:1526,y:895,t:1527023584757};\\\", \\\"{x:1523,y:891,t:1527023584773};\\\", \\\"{x:1521,y:888,t:1527023584790};\\\", \\\"{x:1519,y:884,t:1527023584807};\\\", \\\"{x:1516,y:881,t:1527023584823};\\\", \\\"{x:1512,y:877,t:1527023584840};\\\", \\\"{x:1508,y:872,t:1527023584857};\\\", \\\"{x:1507,y:871,t:1527023584873};\\\", \\\"{x:1504,y:868,t:1527023584890};\\\", \\\"{x:1503,y:866,t:1527023584907};\\\", \\\"{x:1500,y:862,t:1527023584923};\\\", \\\"{x:1497,y:858,t:1527023584940};\\\", \\\"{x:1496,y:856,t:1527023584957};\\\", \\\"{x:1496,y:855,t:1527023584973};\\\", \\\"{x:1494,y:853,t:1527023584990};\\\", \\\"{x:1494,y:852,t:1527023585006};\\\", \\\"{x:1494,y:850,t:1527023585023};\\\", \\\"{x:1493,y:850,t:1527023585040};\\\", \\\"{x:1493,y:849,t:1527023585056};\\\", \\\"{x:1493,y:848,t:1527023585073};\\\", \\\"{x:1491,y:846,t:1527023585090};\\\", \\\"{x:1490,y:844,t:1527023585106};\\\", \\\"{x:1490,y:841,t:1527023585123};\\\", \\\"{x:1489,y:839,t:1527023585140};\\\", \\\"{x:1488,y:838,t:1527023585157};\\\", \\\"{x:1488,y:837,t:1527023585173};\\\", \\\"{x:1487,y:836,t:1527023585190};\\\", \\\"{x:1485,y:833,t:1527023585206};\\\", \\\"{x:1485,y:830,t:1527023585223};\\\", \\\"{x:1484,y:829,t:1527023585240};\\\", \\\"{x:1483,y:828,t:1527023585255};\\\", \\\"{x:1483,y:826,t:1527023585272};\\\", \\\"{x:1482,y:826,t:1527023585289};\\\", \\\"{x:1481,y:825,t:1527023585306};\\\", \\\"{x:1480,y:824,t:1527023585325};\\\", \\\"{x:1479,y:823,t:1527023585340};\\\", \\\"{x:1474,y:820,t:1527023585357};\\\", \\\"{x:1451,y:813,t:1527023585373};\\\", \\\"{x:1424,y:805,t:1527023585389};\\\", \\\"{x:1380,y:793,t:1527023585406};\\\", \\\"{x:1317,y:770,t:1527023585423};\\\", \\\"{x:1243,y:741,t:1527023585439};\\\", \\\"{x:1163,y:704,t:1527023585456};\\\", \\\"{x:1103,y:680,t:1527023585473};\\\", \\\"{x:1075,y:670,t:1527023585489};\\\", \\\"{x:1059,y:663,t:1527023585507};\\\", \\\"{x:1044,y:657,t:1527023585524};\\\", \\\"{x:1033,y:652,t:1527023585540};\\\", \\\"{x:1021,y:648,t:1527023585557};\\\", \\\"{x:1002,y:643,t:1527023585573};\\\", \\\"{x:990,y:640,t:1527023585589};\\\", \\\"{x:974,y:634,t:1527023585606};\\\", \\\"{x:953,y:627,t:1527023585623};\\\", \\\"{x:930,y:621,t:1527023585640};\\\", \\\"{x:902,y:613,t:1527023585656};\\\", \\\"{x:864,y:599,t:1527023585673};\\\", \\\"{x:830,y:588,t:1527023585690};\\\", \\\"{x:796,y:579,t:1527023585712};\\\", \\\"{x:778,y:574,t:1527023585728};\\\", \\\"{x:768,y:569,t:1527023585745};\\\", \\\"{x:767,y:567,t:1527023585762};\\\", \\\"{x:765,y:565,t:1527023585778};\\\", \\\"{x:762,y:562,t:1527023585796};\\\", \\\"{x:753,y:554,t:1527023585813};\\\", \\\"{x:747,y:553,t:1527023585828};\\\", \\\"{x:741,y:553,t:1527023585845};\\\", \\\"{x:737,y:553,t:1527023585861};\\\", \\\"{x:730,y:550,t:1527023585878};\\\", \\\"{x:723,y:549,t:1527023585896};\\\", \\\"{x:719,y:548,t:1527023585911};\\\", \\\"{x:713,y:547,t:1527023585928};\\\", \\\"{x:711,y:547,t:1527023585945};\\\", \\\"{x:708,y:547,t:1527023585962};\\\", \\\"{x:706,y:546,t:1527023585979};\\\", \\\"{x:700,y:545,t:1527023585995};\\\", \\\"{x:698,y:545,t:1527023586012};\\\", \\\"{x:686,y:543,t:1527023586029};\\\", \\\"{x:675,y:541,t:1527023586045};\\\", \\\"{x:667,y:541,t:1527023586062};\\\", \\\"{x:655,y:538,t:1527023586079};\\\", \\\"{x:641,y:533,t:1527023586095};\\\", \\\"{x:634,y:531,t:1527023586112};\\\", \\\"{x:628,y:528,t:1527023586129};\\\", \\\"{x:622,y:528,t:1527023586145};\\\", \\\"{x:616,y:524,t:1527023586162};\\\", \\\"{x:612,y:523,t:1527023586179};\\\", \\\"{x:610,y:522,t:1527023586195};\\\", \\\"{x:609,y:522,t:1527023586221};\\\", \\\"{x:607,y:522,t:1527023586253};\\\", \\\"{x:607,y:523,t:1527023586262};\\\", \\\"{x:606,y:529,t:1527023586279};\\\", \\\"{x:606,y:535,t:1527023586296};\\\", \\\"{x:606,y:542,t:1527023586312};\\\", \\\"{x:607,y:550,t:1527023586329};\\\", \\\"{x:610,y:558,t:1527023586346};\\\", \\\"{x:611,y:563,t:1527023586364};\\\", \\\"{x:613,y:568,t:1527023586380};\\\", \\\"{x:615,y:573,t:1527023586396};\\\", \\\"{x:616,y:575,t:1527023586412};\\\", \\\"{x:616,y:576,t:1527023586469};\\\", \\\"{x:616,y:577,t:1527023586479};\\\", \\\"{x:616,y:578,t:1527023586496};\\\", \\\"{x:613,y:582,t:1527023586765};\\\", \\\"{x:613,y:584,t:1527023586778};\\\", \\\"{x:610,y:590,t:1527023586797};\\\", \\\"{x:604,y:601,t:1527023586813};\\\", \\\"{x:594,y:619,t:1527023586829};\\\", \\\"{x:586,y:634,t:1527023586846};\\\", \\\"{x:579,y:646,t:1527023586862};\\\", \\\"{x:573,y:657,t:1527023586879};\\\", \\\"{x:568,y:665,t:1527023586896};\\\", \\\"{x:560,y:676,t:1527023586913};\\\", \\\"{x:554,y:683,t:1527023586930};\\\", \\\"{x:548,y:686,t:1527023586946};\\\", \\\"{x:545,y:689,t:1527023586963};\\\", \\\"{x:542,y:692,t:1527023586981};\\\", \\\"{x:541,y:692,t:1527023586996};\\\", \\\"{x:538,y:693,t:1527023587013};\\\", \\\"{x:537,y:694,t:1527023587030};\\\", \\\"{x:536,y:697,t:1527023587047};\\\", \\\"{x:534,y:699,t:1527023587063};\\\", \\\"{x:533,y:701,t:1527023587080};\\\", \\\"{x:533,y:702,t:1527023587097};\\\", \\\"{x:533,y:707,t:1527023587114};\\\", \\\"{x:531,y:711,t:1527023587131};\\\", \\\"{x:530,y:715,t:1527023587147};\\\", \\\"{x:530,y:719,t:1527023587164};\\\", \\\"{x:530,y:724,t:1527023587181};\\\", \\\"{x:530,y:729,t:1527023587197};\\\", \\\"{x:531,y:731,t:1527023587213};\\\", \\\"{x:531,y:733,t:1527023587230};\\\", \\\"{x:533,y:733,t:1527023587677};\\\", \\\"{x:534,y:733,t:1527023587685};\\\", \\\"{x:534,y:732,t:1527023587701};\\\", \\\"{x:535,y:732,t:1527023587713};\\\", \\\"{x:537,y:728,t:1527023587730};\\\", \\\"{x:538,y:726,t:1527023587747};\\\", \\\"{x:539,y:724,t:1527023587763};\\\", \\\"{x:540,y:722,t:1527023587780};\\\", \\\"{x:541,y:718,t:1527023587797};\\\", \\\"{x:542,y:714,t:1527023587813};\\\", \\\"{x:544,y:713,t:1527023587830};\\\", \\\"{x:544,y:710,t:1527023587847};\\\", \\\"{x:545,y:707,t:1527023587863};\\\", \\\"{x:545,y:705,t:1527023587880};\\\", \\\"{x:545,y:700,t:1527023587897};\\\", \\\"{x:548,y:696,t:1527023587913};\\\", \\\"{x:549,y:693,t:1527023587930};\\\", \\\"{x:549,y:691,t:1527023587947};\\\", \\\"{x:549,y:689,t:1527023587963};\\\", \\\"{x:550,y:688,t:1527023587980};\\\", \\\"{x:550,y:686,t:1527023587997};\\\", \\\"{x:551,y:685,t:1527023588014};\\\", \\\"{x:551,y:683,t:1527023588030};\\\", \\\"{x:551,y:681,t:1527023588047};\\\", \\\"{x:552,y:679,t:1527023588063};\\\", \\\"{x:552,y:675,t:1527023588080};\\\", \\\"{x:552,y:673,t:1527023588097};\\\", \\\"{x:552,y:670,t:1527023588114};\\\", \\\"{x:554,y:667,t:1527023588130};\\\", \\\"{x:554,y:664,t:1527023588147};\\\", \\\"{x:555,y:660,t:1527023588164};\\\", \\\"{x:556,y:655,t:1527023588180};\\\", \\\"{x:558,y:648,t:1527023588196};\\\", \\\"{x:558,y:645,t:1527023588214};\\\", \\\"{x:559,y:642,t:1527023588230};\\\", \\\"{x:560,y:640,t:1527023588247};\\\", \\\"{x:561,y:637,t:1527023588264};\\\", \\\"{x:562,y:634,t:1527023588280};\\\", \\\"{x:563,y:631,t:1527023588297};\\\", \\\"{x:563,y:629,t:1527023588314};\\\", \\\"{x:565,y:627,t:1527023588330};\\\", \\\"{x:566,y:623,t:1527023588347};\\\", \\\"{x:569,y:618,t:1527023588364};\\\", \\\"{x:570,y:616,t:1527023588380};\\\", \\\"{x:572,y:609,t:1527023588397};\\\", \\\"{x:575,y:603,t:1527023588414};\\\", \\\"{x:576,y:596,t:1527023588431};\\\", \\\"{x:580,y:580,t:1527023588447};\\\", \\\"{x:582,y:570,t:1527023588464};\\\", \\\"{x:589,y:558,t:1527023588481};\\\" ] }, { \\\"rt\\\": 29487, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 19, \\\"time_elapsed\\\": 634098, \\\"internal_node_id\\\": \\\"0.0-6.0-9.0\\\", \\\"subject\\\": \\\"8LK9M\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"hotel\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 15, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"K\\\", \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-N -02 PM-X -X -X \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:627,y:506,t:1527023588616};\\\", \\\"{x:627,y:503,t:1527023589070};\\\", \\\"{x:623,y:489,t:1527023589085};\\\", \\\"{x:603,y:458,t:1527023589097};\\\", \\\"{x:586,y:444,t:1527023589115};\\\", \\\"{x:561,y:430,t:1527023589131};\\\", \\\"{x:530,y:421,t:1527023589148};\\\", \\\"{x:501,y:415,t:1527023589164};\\\", \\\"{x:471,y:406,t:1527023589181};\\\", \\\"{x:458,y:405,t:1527023589198};\\\", \\\"{x:448,y:405,t:1527023589214};\\\", \\\"{x:441,y:405,t:1527023589231};\\\", \\\"{x:435,y:405,t:1527023589248};\\\", \\\"{x:431,y:405,t:1527023589264};\\\", \\\"{x:428,y:405,t:1527023589281};\\\", \\\"{x:426,y:406,t:1527023589299};\\\", \\\"{x:424,y:406,t:1527023589314};\\\", \\\"{x:419,y:409,t:1527023589331};\\\", \\\"{x:417,y:410,t:1527023589349};\\\", \\\"{x:409,y:413,t:1527023589364};\\\", \\\"{x:400,y:417,t:1527023589381};\\\", \\\"{x:394,y:421,t:1527023589398};\\\", \\\"{x:392,y:422,t:1527023589415};\\\", \\\"{x:391,y:422,t:1527023589468};\\\", \\\"{x:393,y:425,t:1527023590133};\\\", \\\"{x:398,y:425,t:1527023590148};\\\", \\\"{x:411,y:430,t:1527023590165};\\\", \\\"{x:432,y:436,t:1527023590181};\\\", \\\"{x:453,y:440,t:1527023590198};\\\", \\\"{x:467,y:445,t:1527023590215};\\\", \\\"{x:479,y:449,t:1527023590233};\\\", \\\"{x:493,y:450,t:1527023590248};\\\", \\\"{x:502,y:451,t:1527023590266};\\\", \\\"{x:511,y:452,t:1527023590282};\\\", \\\"{x:518,y:454,t:1527023590299};\\\", \\\"{x:524,y:455,t:1527023590315};\\\", \\\"{x:530,y:456,t:1527023590332};\\\", \\\"{x:538,y:456,t:1527023590349};\\\", \\\"{x:544,y:458,t:1527023590365};\\\", \\\"{x:551,y:459,t:1527023590382};\\\", \\\"{x:556,y:459,t:1527023590398};\\\", \\\"{x:561,y:459,t:1527023590415};\\\", \\\"{x:564,y:460,t:1527023590432};\\\", \\\"{x:568,y:460,t:1527023590449};\\\", \\\"{x:572,y:460,t:1527023590465};\\\", \\\"{x:577,y:460,t:1527023590482};\\\", \\\"{x:584,y:460,t:1527023590498};\\\", \\\"{x:588,y:460,t:1527023590515};\\\", \\\"{x:594,y:460,t:1527023590532};\\\", \\\"{x:601,y:460,t:1527023590549};\\\", \\\"{x:613,y:460,t:1527023590566};\\\", \\\"{x:624,y:461,t:1527023590582};\\\", \\\"{x:629,y:462,t:1527023590599};\\\", \\\"{x:634,y:463,t:1527023590616};\\\", \\\"{x:640,y:464,t:1527023590632};\\\", \\\"{x:643,y:464,t:1527023590649};\\\", \\\"{x:649,y:464,t:1527023590666};\\\", \\\"{x:654,y:467,t:1527023590682};\\\", \\\"{x:659,y:467,t:1527023590699};\\\", \\\"{x:662,y:467,t:1527023590717};\\\", \\\"{x:663,y:467,t:1527023590733};\\\", \\\"{x:666,y:467,t:1527023590749};\\\", \\\"{x:668,y:468,t:1527023590766};\\\", \\\"{x:671,y:468,t:1527023590783};\\\", \\\"{x:672,y:468,t:1527023590800};\\\", \\\"{x:674,y:468,t:1527023590817};\\\", \\\"{x:676,y:470,t:1527023590832};\\\", \\\"{x:677,y:470,t:1527023590861};\\\", \\\"{x:677,y:470,t:1527023591053};\\\", \\\"{x:679,y:470,t:1527023591205};\\\", \\\"{x:683,y:470,t:1527023591217};\\\", \\\"{x:695,y:470,t:1527023591234};\\\", \\\"{x:710,y:470,t:1527023591251};\\\", \\\"{x:730,y:471,t:1527023591267};\\\", \\\"{x:763,y:476,t:1527023591283};\\\", \\\"{x:811,y:483,t:1527023591301};\\\", \\\"{x:932,y:498,t:1527023591317};\\\", \\\"{x:1016,y:513,t:1527023591334};\\\", \\\"{x:1096,y:522,t:1527023591351};\\\", \\\"{x:1162,y:529,t:1527023591367};\\\", \\\"{x:1225,y:534,t:1527023591384};\\\", \\\"{x:1293,y:541,t:1527023591400};\\\", \\\"{x:1339,y:542,t:1527023591417};\\\", \\\"{x:1361,y:542,t:1527023591435};\\\", \\\"{x:1371,y:542,t:1527023591450};\\\", \\\"{x:1372,y:543,t:1527023591467};\\\", \\\"{x:1372,y:544,t:1527023591484};\\\", \\\"{x:1374,y:544,t:1527023591773};\\\", \\\"{x:1382,y:546,t:1527023591784};\\\", \\\"{x:1407,y:554,t:1527023591801};\\\", \\\"{x:1430,y:560,t:1527023591819};\\\", \\\"{x:1452,y:567,t:1527023591835};\\\", \\\"{x:1467,y:572,t:1527023591851};\\\", \\\"{x:1476,y:577,t:1527023591868};\\\", \\\"{x:1485,y:582,t:1527023591884};\\\", \\\"{x:1494,y:587,t:1527023591901};\\\", \\\"{x:1496,y:589,t:1527023591919};\\\", \\\"{x:1499,y:591,t:1527023591936};\\\", \\\"{x:1501,y:593,t:1527023591951};\\\", \\\"{x:1501,y:595,t:1527023591968};\\\", \\\"{x:1501,y:596,t:1527023591989};\\\", \\\"{x:1501,y:598,t:1527023592005};\\\", \\\"{x:1502,y:598,t:1527023592019};\\\", \\\"{x:1502,y:599,t:1527023592035};\\\", \\\"{x:1504,y:600,t:1527023592052};\\\", \\\"{x:1507,y:602,t:1527023592069};\\\", \\\"{x:1509,y:603,t:1527023592085};\\\", \\\"{x:1509,y:604,t:1527023592845};\\\", \\\"{x:1508,y:604,t:1527023592853};\\\", \\\"{x:1503,y:604,t:1527023592871};\\\", \\\"{x:1496,y:604,t:1527023592887};\\\", \\\"{x:1487,y:604,t:1527023592904};\\\", \\\"{x:1473,y:604,t:1527023592921};\\\", \\\"{x:1464,y:604,t:1527023592937};\\\", \\\"{x:1461,y:604,t:1527023592954};\\\", \\\"{x:1457,y:604,t:1527023592971};\\\", \\\"{x:1453,y:604,t:1527023592988};\\\", \\\"{x:1448,y:604,t:1527023593003};\\\", \\\"{x:1441,y:602,t:1527023593021};\\\", \\\"{x:1421,y:600,t:1527023593037};\\\", \\\"{x:1407,y:599,t:1527023593053};\\\", \\\"{x:1387,y:596,t:1527023593070};\\\", \\\"{x:1375,y:595,t:1527023593087};\\\", \\\"{x:1364,y:592,t:1527023593103};\\\", \\\"{x:1356,y:590,t:1527023593121};\\\", \\\"{x:1348,y:588,t:1527023593138};\\\", \\\"{x:1344,y:586,t:1527023593155};\\\", \\\"{x:1343,y:585,t:1527023593170};\\\", \\\"{x:1342,y:585,t:1527023593187};\\\", \\\"{x:1341,y:585,t:1527023593205};\\\", \\\"{x:1340,y:584,t:1527023593237};\\\", \\\"{x:1338,y:584,t:1527023593262};\\\", \\\"{x:1335,y:583,t:1527023593271};\\\", \\\"{x:1331,y:582,t:1527023593288};\\\", \\\"{x:1326,y:581,t:1527023593305};\\\", \\\"{x:1324,y:581,t:1527023593321};\\\", \\\"{x:1321,y:580,t:1527023593338};\\\", \\\"{x:1320,y:580,t:1527023593354};\\\", \\\"{x:1319,y:579,t:1527023593372};\\\", \\\"{x:1318,y:579,t:1527023593388};\\\", \\\"{x:1317,y:579,t:1527023593405};\\\", \\\"{x:1316,y:579,t:1527023593438};\\\", \\\"{x:1315,y:578,t:1527023593757};\\\", \\\"{x:1314,y:578,t:1527023593772};\\\", \\\"{x:1312,y:577,t:1527023593788};\\\", \\\"{x:1309,y:577,t:1527023593805};\\\", \\\"{x:1305,y:576,t:1527023593822};\\\", \\\"{x:1302,y:576,t:1527023593839};\\\", \\\"{x:1300,y:574,t:1527023593856};\\\", \\\"{x:1298,y:574,t:1527023593873};\\\", \\\"{x:1295,y:573,t:1527023593889};\\\", \\\"{x:1294,y:573,t:1527023593905};\\\", \\\"{x:1292,y:573,t:1527023593923};\\\", \\\"{x:1291,y:573,t:1527023593965};\\\", \\\"{x:1292,y:573,t:1527023594614};\\\", \\\"{x:1302,y:576,t:1527023594624};\\\", \\\"{x:1336,y:590,t:1527023594641};\\\", \\\"{x:1386,y:613,t:1527023594657};\\\", \\\"{x:1458,y:642,t:1527023594674};\\\", \\\"{x:1542,y:675,t:1527023594692};\\\", \\\"{x:1609,y:706,t:1527023594708};\\\", \\\"{x:1664,y:729,t:1527023594725};\\\", \\\"{x:1699,y:747,t:1527023594741};\\\", \\\"{x:1723,y:764,t:1527023594758};\\\", \\\"{x:1725,y:772,t:1527023594774};\\\", \\\"{x:1725,y:777,t:1527023594792};\\\", \\\"{x:1725,y:781,t:1527023594809};\\\", \\\"{x:1722,y:786,t:1527023594824};\\\", \\\"{x:1719,y:788,t:1527023594842};\\\", \\\"{x:1714,y:792,t:1527023594859};\\\", \\\"{x:1709,y:798,t:1527023594875};\\\", \\\"{x:1704,y:805,t:1527023594891};\\\", \\\"{x:1700,y:814,t:1527023594908};\\\", \\\"{x:1698,y:817,t:1527023594925};\\\", \\\"{x:1693,y:823,t:1527023594941};\\\", \\\"{x:1682,y:834,t:1527023594961};\\\", \\\"{x:1671,y:838,t:1527023594975};\\\", \\\"{x:1659,y:844,t:1527023594991};\\\", \\\"{x:1647,y:848,t:1527023595008};\\\", \\\"{x:1638,y:851,t:1527023595024};\\\", \\\"{x:1635,y:853,t:1527023595041};\\\", \\\"{x:1629,y:859,t:1527023595057};\\\", \\\"{x:1627,y:865,t:1527023595074};\\\", \\\"{x:1627,y:870,t:1527023595092};\\\", \\\"{x:1627,y:871,t:1527023595107};\\\", \\\"{x:1627,y:875,t:1527023595125};\\\", \\\"{x:1629,y:880,t:1527023595141};\\\", \\\"{x:1631,y:882,t:1527023595158};\\\", \\\"{x:1631,y:886,t:1527023595175};\\\", \\\"{x:1633,y:894,t:1527023595192};\\\", \\\"{x:1634,y:896,t:1527023595209};\\\", \\\"{x:1640,y:903,t:1527023595226};\\\", \\\"{x:1646,y:912,t:1527023595242};\\\", \\\"{x:1657,y:920,t:1527023595258};\\\", \\\"{x:1672,y:926,t:1527023595275};\\\", \\\"{x:1674,y:934,t:1527023595293};\\\", \\\"{x:1682,y:942,t:1527023595309};\\\", \\\"{x:1696,y:949,t:1527023595325};\\\", \\\"{x:1703,y:955,t:1527023595342};\\\", \\\"{x:1706,y:958,t:1527023595359};\\\", \\\"{x:1706,y:959,t:1527023595463};\\\", \\\"{x:1705,y:959,t:1527023595476};\\\", \\\"{x:1700,y:959,t:1527023595492};\\\", \\\"{x:1696,y:959,t:1527023595509};\\\", \\\"{x:1681,y:958,t:1527023595526};\\\", \\\"{x:1658,y:954,t:1527023595542};\\\", \\\"{x:1628,y:951,t:1527023595559};\\\", \\\"{x:1580,y:943,t:1527023595576};\\\", \\\"{x:1549,y:938,t:1527023595592};\\\", \\\"{x:1543,y:934,t:1527023595610};\\\", \\\"{x:1541,y:933,t:1527023595626};\\\", \\\"{x:1540,y:932,t:1527023595643};\\\", \\\"{x:1540,y:931,t:1527023595711};\\\", \\\"{x:1538,y:931,t:1527023595871};\\\", \\\"{x:1537,y:931,t:1527023595878};\\\", \\\"{x:1533,y:931,t:1527023595894};\\\", \\\"{x:1530,y:934,t:1527023595910};\\\", \\\"{x:1527,y:937,t:1527023595926};\\\", \\\"{x:1525,y:940,t:1527023595944};\\\", \\\"{x:1521,y:946,t:1527023595961};\\\", \\\"{x:1515,y:955,t:1527023595976};\\\", \\\"{x:1500,y:969,t:1527023595994};\\\", \\\"{x:1496,y:977,t:1527023596010};\\\", \\\"{x:1492,y:981,t:1527023596027};\\\", \\\"{x:1489,y:980,t:1527023596263};\\\", \\\"{x:1488,y:979,t:1527023596277};\\\", \\\"{x:1487,y:978,t:1527023596294};\\\", \\\"{x:1486,y:977,t:1527023596310};\\\", \\\"{x:1484,y:977,t:1527023596358};\\\", \\\"{x:1484,y:976,t:1527023596366};\\\", \\\"{x:1481,y:975,t:1527023596390};\\\", \\\"{x:1480,y:974,t:1527023596398};\\\", \\\"{x:1477,y:973,t:1527023596438};\\\", \\\"{x:1471,y:973,t:1527023596446};\\\", \\\"{x:1468,y:971,t:1527023596462};\\\", \\\"{x:1466,y:970,t:1527023596477};\\\", \\\"{x:1465,y:970,t:1527023596494};\\\", \\\"{x:1465,y:969,t:1527023596511};\\\", \\\"{x:1464,y:969,t:1527023596551};\\\", \\\"{x:1465,y:968,t:1527023597046};\\\", \\\"{x:1469,y:967,t:1527023597061};\\\", \\\"{x:1473,y:966,t:1527023597079};\\\", \\\"{x:1476,y:965,t:1527023597095};\\\", \\\"{x:1480,y:963,t:1527023597112};\\\", \\\"{x:1481,y:963,t:1527023597129};\\\", \\\"{x:1482,y:963,t:1527023597145};\\\", \\\"{x:1481,y:961,t:1527023600095};\\\", \\\"{x:1481,y:960,t:1527023600102};\\\", \\\"{x:1481,y:957,t:1527023600118};\\\", \\\"{x:1482,y:954,t:1527023600134};\\\", \\\"{x:1484,y:951,t:1527023600152};\\\", \\\"{x:1484,y:949,t:1527023600168};\\\", \\\"{x:1486,y:947,t:1527023600185};\\\", \\\"{x:1486,y:945,t:1527023600202};\\\", \\\"{x:1486,y:944,t:1527023600219};\\\", \\\"{x:1486,y:942,t:1527023600238};\\\", \\\"{x:1487,y:942,t:1527023600254};\\\", \\\"{x:1487,y:941,t:1527023600269};\\\", \\\"{x:1487,y:939,t:1527023600286};\\\", \\\"{x:1488,y:937,t:1527023600302};\\\", \\\"{x:1489,y:931,t:1527023600318};\\\", \\\"{x:1490,y:927,t:1527023600336};\\\", \\\"{x:1490,y:922,t:1527023600352};\\\", \\\"{x:1491,y:919,t:1527023600368};\\\", \\\"{x:1492,y:915,t:1527023600386};\\\", \\\"{x:1492,y:911,t:1527023600402};\\\", \\\"{x:1492,y:909,t:1527023600419};\\\", \\\"{x:1492,y:906,t:1527023600436};\\\", \\\"{x:1492,y:905,t:1527023600453};\\\", \\\"{x:1492,y:903,t:1527023600468};\\\", \\\"{x:1492,y:900,t:1527023600486};\\\", \\\"{x:1492,y:898,t:1527023600502};\\\", \\\"{x:1492,y:896,t:1527023600519};\\\", \\\"{x:1492,y:894,t:1527023600536};\\\", \\\"{x:1492,y:891,t:1527023600552};\\\", \\\"{x:1492,y:889,t:1527023600569};\\\", \\\"{x:1492,y:887,t:1527023600586};\\\", \\\"{x:1492,y:882,t:1527023600602};\\\", \\\"{x:1492,y:876,t:1527023600619};\\\", \\\"{x:1492,y:875,t:1527023600636};\\\", \\\"{x:1492,y:873,t:1527023600652};\\\", \\\"{x:1492,y:871,t:1527023600670};\\\", \\\"{x:1492,y:870,t:1527023600685};\\\", \\\"{x:1492,y:865,t:1527023600702};\\\", \\\"{x:1492,y:863,t:1527023600719};\\\", \\\"{x:1492,y:862,t:1527023600737};\\\", \\\"{x:1492,y:861,t:1527023600782};\\\", \\\"{x:1492,y:860,t:1527023600839};\\\", \\\"{x:1492,y:859,t:1527023600853};\\\", \\\"{x:1492,y:854,t:1527023600870};\\\", \\\"{x:1491,y:854,t:1527023600886};\\\", \\\"{x:1491,y:852,t:1527023600903};\\\", \\\"{x:1491,y:851,t:1527023600920};\\\", \\\"{x:1491,y:848,t:1527023600936};\\\", \\\"{x:1490,y:846,t:1527023600953};\\\", \\\"{x:1490,y:844,t:1527023600969};\\\", \\\"{x:1489,y:843,t:1527023600990};\\\", \\\"{x:1489,y:841,t:1527023601006};\\\", \\\"{x:1489,y:840,t:1527023601030};\\\", \\\"{x:1489,y:839,t:1527023601038};\\\", \\\"{x:1489,y:838,t:1527023601054};\\\", \\\"{x:1489,y:837,t:1527023601077};\\\", \\\"{x:1489,y:836,t:1527023601599};\\\", \\\"{x:1489,y:835,t:1527023601606};\\\", \\\"{x:1489,y:834,t:1527023601638};\\\", \\\"{x:1482,y:831,t:1527023601655};\\\", \\\"{x:1481,y:830,t:1527023601671};\\\", \\\"{x:1481,y:831,t:1527023602013};\\\", \\\"{x:1480,y:832,t:1527023602950};\\\", \\\"{x:1479,y:832,t:1527023606238};\\\", \\\"{x:1479,y:844,t:1527023606247};\\\", \\\"{x:1479,y:863,t:1527023606264};\\\", \\\"{x:1479,y:867,t:1527023606280};\\\", \\\"{x:1479,y:874,t:1527023606297};\\\", \\\"{x:1479,y:880,t:1527023606313};\\\", \\\"{x:1480,y:885,t:1527023606330};\\\", \\\"{x:1481,y:887,t:1527023606347};\\\", \\\"{x:1481,y:890,t:1527023606364};\\\", \\\"{x:1482,y:896,t:1527023606381};\\\", \\\"{x:1482,y:901,t:1527023606397};\\\", \\\"{x:1484,y:908,t:1527023606414};\\\", \\\"{x:1484,y:910,t:1527023606430};\\\", \\\"{x:1486,y:914,t:1527023606447};\\\", \\\"{x:1486,y:916,t:1527023606464};\\\", \\\"{x:1486,y:918,t:1527023606481};\\\", \\\"{x:1486,y:920,t:1527023606497};\\\", \\\"{x:1486,y:924,t:1527023606514};\\\", \\\"{x:1486,y:927,t:1527023606531};\\\", \\\"{x:1486,y:931,t:1527023606548};\\\", \\\"{x:1486,y:935,t:1527023606564};\\\", \\\"{x:1487,y:938,t:1527023606581};\\\", \\\"{x:1487,y:941,t:1527023606598};\\\", \\\"{x:1487,y:942,t:1527023606614};\\\", \\\"{x:1487,y:943,t:1527023606630};\\\", \\\"{x:1487,y:945,t:1527023606647};\\\", \\\"{x:1487,y:948,t:1527023606664};\\\", \\\"{x:1486,y:950,t:1527023606681};\\\", \\\"{x:1486,y:951,t:1527023606698};\\\", \\\"{x:1486,y:953,t:1527023606715};\\\", \\\"{x:1486,y:955,t:1527023606732};\\\", \\\"{x:1486,y:956,t:1527023606774};\\\", \\\"{x:1485,y:954,t:1527023606895};\\\", \\\"{x:1485,y:951,t:1527023606902};\\\", \\\"{x:1485,y:947,t:1527023606915};\\\", \\\"{x:1484,y:937,t:1527023606932};\\\", \\\"{x:1482,y:928,t:1527023606948};\\\", \\\"{x:1481,y:919,t:1527023606965};\\\", \\\"{x:1479,y:906,t:1527023606982};\\\", \\\"{x:1479,y:898,t:1527023606998};\\\", \\\"{x:1478,y:883,t:1527023607014};\\\", \\\"{x:1478,y:877,t:1527023607032};\\\", \\\"{x:1478,y:876,t:1527023607049};\\\", \\\"{x:1478,y:875,t:1527023607065};\\\", \\\"{x:1478,y:874,t:1527023607094};\\\", \\\"{x:1478,y:873,t:1527023607102};\\\", \\\"{x:1478,y:872,t:1527023607115};\\\", \\\"{x:1478,y:871,t:1527023607132};\\\", \\\"{x:1478,y:866,t:1527023607149};\\\", \\\"{x:1478,y:863,t:1527023607165};\\\", \\\"{x:1478,y:861,t:1527023607181};\\\", \\\"{x:1478,y:859,t:1527023607198};\\\", \\\"{x:1478,y:857,t:1527023607215};\\\", \\\"{x:1478,y:855,t:1527023607232};\\\", \\\"{x:1478,y:852,t:1527023607249};\\\", \\\"{x:1478,y:851,t:1527023607266};\\\", \\\"{x:1478,y:850,t:1527023607282};\\\", \\\"{x:1478,y:849,t:1527023607299};\\\", \\\"{x:1478,y:847,t:1527023607358};\\\", \\\"{x:1478,y:846,t:1527023607366};\\\", \\\"{x:1478,y:844,t:1527023607381};\\\", \\\"{x:1478,y:843,t:1527023607398};\\\", \\\"{x:1478,y:841,t:1527023607416};\\\", \\\"{x:1478,y:840,t:1527023607433};\\\", \\\"{x:1478,y:838,t:1527023607449};\\\", \\\"{x:1478,y:836,t:1527023607466};\\\", \\\"{x:1478,y:835,t:1527023607482};\\\", \\\"{x:1478,y:834,t:1527023607502};\\\", \\\"{x:1478,y:833,t:1527023607515};\\\", \\\"{x:1478,y:832,t:1527023607542};\\\", \\\"{x:1478,y:831,t:1527023607830};\\\", \\\"{x:1478,y:830,t:1527023608062};\\\", \\\"{x:1478,y:829,t:1527023608078};\\\", \\\"{x:1478,y:828,t:1527023608086};\\\", \\\"{x:1478,y:827,t:1527023608101};\\\", \\\"{x:1478,y:826,t:1527023608117};\\\", \\\"{x:1479,y:824,t:1527023608134};\\\", \\\"{x:1479,y:823,t:1527023609790};\\\", \\\"{x:1479,y:822,t:1527023609803};\\\", \\\"{x:1479,y:806,t:1527023609821};\\\", \\\"{x:1479,y:795,t:1527023609838};\\\", \\\"{x:1479,y:789,t:1527023609854};\\\", \\\"{x:1479,y:786,t:1527023609870};\\\", \\\"{x:1479,y:780,t:1527023609887};\\\", \\\"{x:1479,y:777,t:1527023609904};\\\", \\\"{x:1479,y:771,t:1527023609921};\\\", \\\"{x:1475,y:760,t:1527023609937};\\\", \\\"{x:1475,y:756,t:1527023609954};\\\", \\\"{x:1475,y:755,t:1527023609971};\\\", \\\"{x:1475,y:752,t:1527023609987};\\\", \\\"{x:1475,y:749,t:1527023610004};\\\", \\\"{x:1475,y:746,t:1527023610021};\\\", \\\"{x:1472,y:737,t:1527023610037};\\\", \\\"{x:1471,y:732,t:1527023610054};\\\", \\\"{x:1469,y:727,t:1527023610071};\\\", \\\"{x:1469,y:726,t:1527023610088};\\\", \\\"{x:1469,y:722,t:1527023610104};\\\", \\\"{x:1468,y:715,t:1527023610121};\\\", \\\"{x:1467,y:708,t:1527023610138};\\\", \\\"{x:1465,y:698,t:1527023610154};\\\", \\\"{x:1464,y:689,t:1527023610171};\\\", \\\"{x:1464,y:683,t:1527023610188};\\\", \\\"{x:1464,y:678,t:1527023610204};\\\", \\\"{x:1464,y:673,t:1527023610221};\\\", \\\"{x:1464,y:659,t:1527023610238};\\\", \\\"{x:1464,y:647,t:1527023610254};\\\", \\\"{x:1462,y:637,t:1527023610271};\\\", \\\"{x:1460,y:627,t:1527023610288};\\\", \\\"{x:1459,y:619,t:1527023610305};\\\", \\\"{x:1459,y:615,t:1527023610321};\\\", \\\"{x:1459,y:609,t:1527023610338};\\\", \\\"{x:1459,y:603,t:1527023610355};\\\", \\\"{x:1459,y:591,t:1527023610371};\\\", \\\"{x:1458,y:582,t:1527023610388};\\\", \\\"{x:1456,y:573,t:1527023610406};\\\", \\\"{x:1455,y:562,t:1527023610422};\\\", \\\"{x:1455,y:554,t:1527023610438};\\\", \\\"{x:1454,y:543,t:1527023610455};\\\", \\\"{x:1453,y:530,t:1527023610472};\\\", \\\"{x:1453,y:514,t:1527023610488};\\\", \\\"{x:1451,y:498,t:1527023610505};\\\", \\\"{x:1448,y:487,t:1527023610522};\\\", \\\"{x:1444,y:475,t:1527023610538};\\\", \\\"{x:1441,y:466,t:1527023610555};\\\", \\\"{x:1439,y:455,t:1527023610572};\\\", \\\"{x:1434,y:438,t:1527023610589};\\\", \\\"{x:1429,y:423,t:1527023610605};\\\", \\\"{x:1428,y:406,t:1527023610621};\\\", \\\"{x:1428,y:397,t:1527023610638};\\\", \\\"{x:1428,y:390,t:1527023610654};\\\", \\\"{x:1430,y:384,t:1527023610671};\\\", \\\"{x:1430,y:380,t:1527023610688};\\\", \\\"{x:1430,y:377,t:1527023610704};\\\", \\\"{x:1431,y:375,t:1527023610721};\\\", \\\"{x:1432,y:373,t:1527023610738};\\\", \\\"{x:1434,y:370,t:1527023610756};\\\", \\\"{x:1435,y:366,t:1527023610772};\\\", \\\"{x:1436,y:364,t:1527023610788};\\\", \\\"{x:1439,y:359,t:1527023610806};\\\", \\\"{x:1442,y:355,t:1527023610822};\\\", \\\"{x:1444,y:352,t:1527023610838};\\\", \\\"{x:1445,y:351,t:1527023610856};\\\", \\\"{x:1446,y:348,t:1527023610872};\\\", \\\"{x:1448,y:346,t:1527023610889};\\\", \\\"{x:1451,y:343,t:1527023610906};\\\", \\\"{x:1455,y:338,t:1527023610922};\\\", \\\"{x:1459,y:332,t:1527023610939};\\\", \\\"{x:1462,y:330,t:1527023610956};\\\", \\\"{x:1465,y:327,t:1527023610973};\\\", \\\"{x:1466,y:325,t:1527023610989};\\\", \\\"{x:1470,y:321,t:1527023611006};\\\", \\\"{x:1472,y:319,t:1527023611023};\\\", \\\"{x:1474,y:316,t:1527023611039};\\\", \\\"{x:1475,y:315,t:1527023611056};\\\", \\\"{x:1476,y:314,t:1527023611073};\\\", \\\"{x:1477,y:313,t:1527023611151};\\\", \\\"{x:1477,y:311,t:1527023611166};\\\", \\\"{x:1477,y:310,t:1527023611181};\\\", \\\"{x:1478,y:308,t:1527023611214};\\\", \\\"{x:1478,y:307,t:1527023611223};\\\", \\\"{x:1478,y:306,t:1527023611240};\\\", \\\"{x:1479,y:304,t:1527023611256};\\\", \\\"{x:1479,y:303,t:1527023611286};\\\", \\\"{x:1479,y:302,t:1527023611366};\\\", \\\"{x:1477,y:304,t:1527023611942};\\\", \\\"{x:1453,y:322,t:1527023611959};\\\", \\\"{x:1429,y:336,t:1527023611974};\\\", \\\"{x:1392,y:353,t:1527023611991};\\\", \\\"{x:1336,y:380,t:1527023612008};\\\", \\\"{x:1244,y:409,t:1527023612025};\\\", \\\"{x:1102,y:457,t:1527023612040};\\\", \\\"{x:923,y:536,t:1527023612058};\\\", \\\"{x:710,y:640,t:1527023612076};\\\", \\\"{x:521,y:721,t:1527023612091};\\\", \\\"{x:351,y:777,t:1527023612108};\\\", \\\"{x:207,y:819,t:1527023612128};\\\", \\\"{x:180,y:823,t:1527023612144};\\\", \\\"{x:164,y:824,t:1527023612160};\\\", \\\"{x:150,y:824,t:1527023612177};\\\", \\\"{x:144,y:825,t:1527023612194};\\\", \\\"{x:143,y:825,t:1527023612310};\\\", \\\"{x:145,y:802,t:1527023612328};\\\", \\\"{x:157,y:770,t:1527023612345};\\\", \\\"{x:164,y:743,t:1527023612361};\\\", \\\"{x:176,y:715,t:1527023612377};\\\", \\\"{x:191,y:696,t:1527023612395};\\\", \\\"{x:209,y:683,t:1527023612412};\\\", \\\"{x:228,y:673,t:1527023612428};\\\", \\\"{x:252,y:657,t:1527023612451};\\\", \\\"{x:268,y:645,t:1527023612467};\\\", \\\"{x:282,y:635,t:1527023612484};\\\", \\\"{x:303,y:624,t:1527023612501};\\\", \\\"{x:335,y:607,t:1527023612518};\\\", \\\"{x:347,y:602,t:1527023612534};\\\", \\\"{x:352,y:600,t:1527023612550};\\\", \\\"{x:357,y:599,t:1527023612568};\\\", \\\"{x:368,y:597,t:1527023612583};\\\", \\\"{x:375,y:596,t:1527023612601};\\\", \\\"{x:381,y:594,t:1527023612618};\\\", \\\"{x:387,y:592,t:1527023612633};\\\", \\\"{x:394,y:591,t:1527023612651};\\\", \\\"{x:397,y:590,t:1527023612668};\\\", \\\"{x:399,y:590,t:1527023612798};\\\", \\\"{x:402,y:592,t:1527023612805};\\\", \\\"{x:404,y:592,t:1527023612817};\\\", \\\"{x:408,y:593,t:1527023612833};\\\", \\\"{x:416,y:595,t:1527023612850};\\\", \\\"{x:430,y:598,t:1527023612868};\\\", \\\"{x:456,y:601,t:1527023612883};\\\", \\\"{x:484,y:601,t:1527023612901};\\\", \\\"{x:528,y:601,t:1527023612918};\\\", \\\"{x:553,y:601,t:1527023612934};\\\", \\\"{x:572,y:601,t:1527023612950};\\\", \\\"{x:576,y:601,t:1527023612967};\\\", \\\"{x:577,y:601,t:1527023613101};\\\", \\\"{x:578,y:601,t:1527023613117};\\\", \\\"{x:579,y:601,t:1527023613134};\\\", \\\"{x:582,y:601,t:1527023613151};\\\", \\\"{x:584,y:601,t:1527023613168};\\\", \\\"{x:589,y:600,t:1527023613185};\\\", \\\"{x:596,y:598,t:1527023613201};\\\", \\\"{x:608,y:597,t:1527023613218};\\\", \\\"{x:622,y:596,t:1527023613235};\\\", \\\"{x:637,y:595,t:1527023613250};\\\", \\\"{x:646,y:592,t:1527023613268};\\\", \\\"{x:649,y:592,t:1527023613284};\\\", \\\"{x:650,y:591,t:1527023613300};\\\", \\\"{x:653,y:590,t:1527023613318};\\\", \\\"{x:657,y:589,t:1527023613334};\\\", \\\"{x:667,y:586,t:1527023613350};\\\", \\\"{x:684,y:581,t:1527023613367};\\\", \\\"{x:694,y:577,t:1527023613385};\\\", \\\"{x:696,y:576,t:1527023613401};\\\", \\\"{x:695,y:576,t:1527023613470};\\\", \\\"{x:689,y:576,t:1527023613485};\\\", \\\"{x:649,y:586,t:1527023613502};\\\", \\\"{x:617,y:588,t:1527023613518};\\\", \\\"{x:590,y:590,t:1527023613535};\\\", \\\"{x:565,y:590,t:1527023613551};\\\", \\\"{x:550,y:590,t:1527023613567};\\\", \\\"{x:542,y:590,t:1527023613584};\\\", \\\"{x:541,y:590,t:1527023613601};\\\", \\\"{x:540,y:590,t:1527023613709};\\\", \\\"{x:538,y:590,t:1527023613718};\\\", \\\"{x:530,y:590,t:1527023613735};\\\", \\\"{x:517,y:591,t:1527023613752};\\\", \\\"{x:506,y:594,t:1527023613768};\\\", \\\"{x:490,y:600,t:1527023613787};\\\", \\\"{x:482,y:604,t:1527023613801};\\\", \\\"{x:473,y:607,t:1527023613818};\\\", \\\"{x:467,y:612,t:1527023613834};\\\", \\\"{x:463,y:617,t:1527023613852};\\\", \\\"{x:462,y:627,t:1527023613868};\\\", \\\"{x:462,y:640,t:1527023613884};\\\", \\\"{x:462,y:651,t:1527023613901};\\\", \\\"{x:461,y:655,t:1527023613918};\\\", \\\"{x:459,y:656,t:1527023613934};\\\", \\\"{x:457,y:658,t:1527023613951};\\\", \\\"{x:454,y:659,t:1527023613968};\\\", \\\"{x:445,y:661,t:1527023613984};\\\", \\\"{x:433,y:662,t:1527023614001};\\\", \\\"{x:416,y:663,t:1527023614019};\\\", \\\"{x:394,y:663,t:1527023614034};\\\", \\\"{x:369,y:663,t:1527023614051};\\\", \\\"{x:350,y:659,t:1527023614068};\\\", \\\"{x:331,y:654,t:1527023614085};\\\", \\\"{x:301,y:648,t:1527023614102};\\\", \\\"{x:286,y:647,t:1527023614118};\\\", \\\"{x:271,y:644,t:1527023614135};\\\", \\\"{x:266,y:644,t:1527023614151};\\\", \\\"{x:263,y:644,t:1527023614168};\\\", \\\"{x:262,y:644,t:1527023614185};\\\", \\\"{x:260,y:644,t:1527023614201};\\\", \\\"{x:255,y:641,t:1527023614218};\\\", \\\"{x:251,y:641,t:1527023614236};\\\", \\\"{x:248,y:641,t:1527023614252};\\\", \\\"{x:250,y:640,t:1527023614293};\\\", \\\"{x:257,y:638,t:1527023614302};\\\", \\\"{x:269,y:631,t:1527023614318};\\\", \\\"{x:285,y:623,t:1527023614337};\\\", \\\"{x:305,y:614,t:1527023614352};\\\", \\\"{x:335,y:607,t:1527023614369};\\\", \\\"{x:387,y:603,t:1527023614386};\\\", \\\"{x:443,y:603,t:1527023614402};\\\", \\\"{x:502,y:603,t:1527023614419};\\\", \\\"{x:538,y:603,t:1527023614435};\\\", \\\"{x:578,y:603,t:1527023614452};\\\", \\\"{x:605,y:603,t:1527023614470};\\\", \\\"{x:630,y:601,t:1527023614486};\\\", \\\"{x:631,y:600,t:1527023614502};\\\", \\\"{x:632,y:599,t:1527023614518};\\\", \\\"{x:633,y:599,t:1527023614541};\\\", \\\"{x:634,y:598,t:1527023614621};\\\", \\\"{x:634,y:597,t:1527023614653};\\\", \\\"{x:632,y:596,t:1527023614678};\\\", \\\"{x:629,y:596,t:1527023614685};\\\", \\\"{x:624,y:594,t:1527023614703};\\\", \\\"{x:615,y:593,t:1527023614720};\\\", \\\"{x:609,y:592,t:1527023614736};\\\", \\\"{x:607,y:592,t:1527023614753};\\\", \\\"{x:606,y:591,t:1527023614822};\\\", \\\"{x:609,y:591,t:1527023615149};\\\", \\\"{x:616,y:590,t:1527023615157};\\\", \\\"{x:624,y:588,t:1527023615169};\\\", \\\"{x:653,y:584,t:1527023615186};\\\", \\\"{x:676,y:579,t:1527023615203};\\\", \\\"{x:700,y:577,t:1527023615219};\\\", \\\"{x:722,y:575,t:1527023615236};\\\", \\\"{x:741,y:575,t:1527023615252};\\\", \\\"{x:751,y:575,t:1527023615268};\\\", \\\"{x:769,y:575,t:1527023615286};\\\", \\\"{x:780,y:575,t:1527023615302};\\\", \\\"{x:795,y:576,t:1527023615320};\\\", \\\"{x:804,y:576,t:1527023615336};\\\", \\\"{x:811,y:576,t:1527023615353};\\\", \\\"{x:814,y:576,t:1527023615369};\\\", \\\"{x:815,y:576,t:1527023615389};\\\", \\\"{x:817,y:576,t:1527023615414};\\\", \\\"{x:818,y:575,t:1527023615422};\\\", \\\"{x:820,y:575,t:1527023615438};\\\", \\\"{x:820,y:574,t:1527023615452};\\\", \\\"{x:824,y:573,t:1527023615469};\\\", \\\"{x:825,y:572,t:1527023615486};\\\", \\\"{x:827,y:570,t:1527023615503};\\\", \\\"{x:829,y:568,t:1527023615521};\\\", \\\"{x:831,y:567,t:1527023615535};\\\", \\\"{x:833,y:565,t:1527023615554};\\\", \\\"{x:835,y:563,t:1527023615569};\\\", \\\"{x:835,y:562,t:1527023615585};\\\", \\\"{x:836,y:561,t:1527023615603};\\\", \\\"{x:837,y:559,t:1527023615620};\\\", \\\"{x:838,y:557,t:1527023615637};\\\", \\\"{x:838,y:556,t:1527023615652};\\\", \\\"{x:837,y:553,t:1527023615669};\\\", \\\"{x:826,y:551,t:1527023615687};\\\", \\\"{x:799,y:548,t:1527023615703};\\\", \\\"{x:749,y:548,t:1527023615719};\\\", \\\"{x:663,y:548,t:1527023615737};\\\", \\\"{x:564,y:557,t:1527023615752};\\\", \\\"{x:467,y:570,t:1527023615770};\\\", \\\"{x:397,y:570,t:1527023615786};\\\", \\\"{x:350,y:570,t:1527023615802};\\\", \\\"{x:318,y:570,t:1527023615819};\\\", \\\"{x:303,y:570,t:1527023615837};\\\", \\\"{x:298,y:570,t:1527023615852};\\\", \\\"{x:298,y:569,t:1527023615877};\\\", \\\"{x:298,y:568,t:1527023615886};\\\", \\\"{x:304,y:568,t:1527023615902};\\\", \\\"{x:310,y:566,t:1527023615920};\\\", \\\"{x:314,y:566,t:1527023615936};\\\", \\\"{x:317,y:565,t:1527023615953};\\\", \\\"{x:319,y:564,t:1527023615969};\\\", \\\"{x:321,y:564,t:1527023615987};\\\", \\\"{x:326,y:564,t:1527023616002};\\\", \\\"{x:333,y:564,t:1527023616020};\\\", \\\"{x:339,y:564,t:1527023616037};\\\", \\\"{x:343,y:564,t:1527023616054};\\\", \\\"{x:341,y:564,t:1527023616110};\\\", \\\"{x:336,y:566,t:1527023616119};\\\", \\\"{x:323,y:572,t:1527023616138};\\\", \\\"{x:304,y:579,t:1527023616153};\\\", \\\"{x:282,y:583,t:1527023616170};\\\", \\\"{x:266,y:583,t:1527023616187};\\\", \\\"{x:251,y:583,t:1527023616203};\\\", \\\"{x:242,y:583,t:1527023616219};\\\", \\\"{x:232,y:581,t:1527023616236};\\\", \\\"{x:214,y:578,t:1527023616252};\\\", \\\"{x:207,y:578,t:1527023616269};\\\", \\\"{x:205,y:578,t:1527023616286};\\\", \\\"{x:203,y:577,t:1527023616303};\\\", \\\"{x:199,y:577,t:1527023616319};\\\", \\\"{x:196,y:577,t:1527023616337};\\\", \\\"{x:190,y:578,t:1527023616353};\\\", \\\"{x:187,y:579,t:1527023616369};\\\", \\\"{x:184,y:581,t:1527023616387};\\\", \\\"{x:181,y:583,t:1527023616404};\\\", \\\"{x:179,y:583,t:1527023616420};\\\", \\\"{x:175,y:587,t:1527023616436};\\\", \\\"{x:173,y:592,t:1527023616453};\\\", \\\"{x:171,y:596,t:1527023616470};\\\", \\\"{x:168,y:602,t:1527023616487};\\\", \\\"{x:167,y:607,t:1527023616504};\\\", \\\"{x:164,y:616,t:1527023616521};\\\", \\\"{x:160,y:625,t:1527023616536};\\\", \\\"{x:156,y:637,t:1527023616554};\\\", \\\"{x:155,y:651,t:1527023616571};\\\", \\\"{x:155,y:666,t:1527023616586};\\\", \\\"{x:155,y:677,t:1527023616603};\\\", \\\"{x:155,y:683,t:1527023616620};\\\", \\\"{x:156,y:687,t:1527023616637};\\\", \\\"{x:159,y:689,t:1527023616654};\\\", \\\"{x:165,y:691,t:1527023616671};\\\", \\\"{x:172,y:693,t:1527023616687};\\\", \\\"{x:186,y:696,t:1527023616704};\\\", \\\"{x:196,y:698,t:1527023616721};\\\", \\\"{x:203,y:698,t:1527023616736};\\\", \\\"{x:209,y:699,t:1527023616754};\\\", \\\"{x:212,y:699,t:1527023616770};\\\", \\\"{x:220,y:698,t:1527023616787};\\\", \\\"{x:230,y:694,t:1527023616803};\\\", \\\"{x:242,y:688,t:1527023616820};\\\", \\\"{x:251,y:681,t:1527023616837};\\\", \\\"{x:261,y:675,t:1527023616853};\\\", \\\"{x:270,y:672,t:1527023616870};\\\", \\\"{x:281,y:667,t:1527023616889};\\\", \\\"{x:295,y:661,t:1527023616904};\\\", \\\"{x:307,y:656,t:1527023616920};\\\", \\\"{x:319,y:650,t:1527023616938};\\\", \\\"{x:326,y:646,t:1527023616953};\\\", \\\"{x:332,y:642,t:1527023616971};\\\", \\\"{x:337,y:637,t:1527023616988};\\\", \\\"{x:342,y:633,t:1527023617003};\\\", \\\"{x:350,y:627,t:1527023617020};\\\", \\\"{x:351,y:625,t:1527023617036};\\\", \\\"{x:352,y:623,t:1527023617053};\\\", \\\"{x:353,y:620,t:1527023617070};\\\", \\\"{x:353,y:618,t:1527023617088};\\\", \\\"{x:353,y:617,t:1527023617109};\\\", \\\"{x:354,y:616,t:1527023617125};\\\", \\\"{x:354,y:615,t:1527023617140};\\\", \\\"{x:354,y:614,t:1527023617158};\\\", \\\"{x:355,y:614,t:1527023617173};\\\", \\\"{x:355,y:613,t:1527023617187};\\\", \\\"{x:356,y:612,t:1527023617204};\\\", \\\"{x:359,y:610,t:1527023617221};\\\", \\\"{x:365,y:606,t:1527023617238};\\\", \\\"{x:370,y:604,t:1527023617254};\\\", \\\"{x:376,y:601,t:1527023617271};\\\", \\\"{x:378,y:600,t:1527023617287};\\\", \\\"{x:379,y:599,t:1527023617304};\\\", \\\"{x:380,y:599,t:1527023617321};\\\", \\\"{x:380,y:600,t:1527023617605};\\\", \\\"{x:380,y:607,t:1527023617621};\\\", \\\"{x:383,y:623,t:1527023617638};\\\", \\\"{x:386,y:632,t:1527023617654};\\\", \\\"{x:388,y:638,t:1527023617670};\\\", \\\"{x:391,y:646,t:1527023617688};\\\", \\\"{x:398,y:657,t:1527023617705};\\\", \\\"{x:404,y:665,t:1527023617721};\\\", \\\"{x:412,y:675,t:1527023617738};\\\", \\\"{x:420,y:685,t:1527023617755};\\\", \\\"{x:425,y:691,t:1527023617771};\\\", \\\"{x:430,y:699,t:1527023617787};\\\", \\\"{x:439,y:710,t:1527023617804};\\\", \\\"{x:446,y:718,t:1527023617821};\\\", \\\"{x:450,y:723,t:1527023617837};\\\", \\\"{x:462,y:732,t:1527023617854};\\\", \\\"{x:471,y:739,t:1527023617873};\\\", \\\"{x:481,y:745,t:1527023617888};\\\", \\\"{x:487,y:750,t:1527023617905};\\\", \\\"{x:494,y:755,t:1527023617922};\\\", \\\"{x:496,y:757,t:1527023617938};\\\", \\\"{x:500,y:761,t:1527023617954};\\\", \\\"{x:502,y:763,t:1527023617971};\\\", \\\"{x:502,y:765,t:1527023618014};\\\", \\\"{x:502,y:766,t:1527023618060};\\\", \\\"{x:502,y:766,t:1527023618120};\\\", \\\"{x:501,y:766,t:1527023618220};\\\", \\\"{x:501,y:764,t:1527023618237};\\\", \\\"{x:501,y:759,t:1527023618255};\\\", \\\"{x:501,y:755,t:1527023618272};\\\", \\\"{x:501,y:754,t:1527023618288};\\\", \\\"{x:501,y:753,t:1527023618305};\\\", \\\"{x:501,y:752,t:1527023618333};\\\", \\\"{x:502,y:752,t:1527023618341};\\\", \\\"{x:504,y:751,t:1527023618389};\\\", \\\"{x:507,y:749,t:1527023618405};\\\", \\\"{x:511,y:748,t:1527023618422};\\\", \\\"{x:514,y:746,t:1527023618439};\\\", \\\"{x:517,y:745,t:1527023618454};\\\", \\\"{x:521,y:743,t:1527023618472};\\\", \\\"{x:526,y:741,t:1527023618488};\\\", \\\"{x:530,y:741,t:1527023618505};\\\", \\\"{x:536,y:741,t:1527023618522};\\\", \\\"{x:540,y:741,t:1527023618539};\\\", \\\"{x:547,y:741,t:1527023618555};\\\", \\\"{x:551,y:741,t:1527023618572};\\\", \\\"{x:555,y:740,t:1527023618589};\\\", \\\"{x:556,y:740,t:1527023618604};\\\", \\\"{x:560,y:738,t:1527023618621};\\\", \\\"{x:563,y:738,t:1527023618639};\\\", \\\"{x:563,y:737,t:1527023618774};\\\" ] }, { \\\"rt\\\": 30869, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 20, \\\"time_elapsed\\\": 666165, \\\"internal_node_id\\\": \\\"0.0-7.0-0.0\\\", \\\"subject\\\": \\\"8LK9M\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"hotel\\\", \\\"condition\\\": \\\"121\\\", \\\"q\\\": 16, \\\"answer\\\": \\\"look at the vertical line going up from 12 pm mark on the horizontal axis\\\", \\\"block\\\": \\\"triangular_testing\\\" }, { \\\"rt\\\": 9440, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"20\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"Lebanon\\\\\\\"}\\\", \\\"block\\\": \\\"demo-1\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 21, \\\"time_elapsed\\\": 676613, \\\"internal_node_id\\\": \\\"0.0-8.0\\\", \\\"subject\\\": \\\"8LK9M\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"hotel\\\", \\\"condition\\\": \\\"121\\\" }, { \\\"rt\\\": 11985, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"English\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"Fourth\\\\\\\",\\\\\\\"Q2\\\\\\\":\\\\\\\"Social Sciences (incl. CogSci)\\\\\\\",\\\\\\\"Q3\\\\\\\":\\\\\\\"Female\\\\\\\"}\\\", \\\"block\\\": \\\"demo-2\\\", \\\"trial_type\\\": \\\"survey-multi-choice\\\", \\\"trial_index\\\": 22, \\\"time_elapsed\\\": 689613, \\\"internal_node_id\\\": \\\"0.0-9.0\\\", \\\"subject\\\": \\\"8LK9M\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"hotel\\\", \\\"condition\\\": \\\"121\\\" }, { \\\"rt\\\": 37923, \\\"url\\\": \\\"../views/src/external/debrief.html\\\", \\\"block\\\": \\\"debrief\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 23, \\\"time_elapsed\\\": 728621, \\\"internal_node_id\\\": \\\"0.0-10.0\\\", \\\"subject\\\": \\\"8LK9M\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"hotel\\\", \\\"condition\\\": \\\"121\\\" } ]\",\"parentNode\":{\"id\":2765}}],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"META\",\"attributes\":{\"charset\":\"utf-8\"}},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":8,\"id\":59},{\"nodeType\":3,\"id\":60,\"textContent\":\" \"},{\"nodeType\":1,\"id\":61,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":62,\"textContent\":\" \"},{\"nodeType\":1,\"id\":63,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":64,\"textContent\":\" \"},{\"nodeType\":1,\"id\":65,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":66,\"textContent\":\" \"},{\"nodeType\":1,\"id\":67,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":68,\"textContent\":\" \"},{\"nodeType\":1,\"id\":69,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":70,\"textContent\":\" \"},{\"nodeType\":1,\"id\":71,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":72,\"textContent\":\" \"},{\"nodeType\":1,\"id\":73,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"stimulus\"},\"childNodes\":[{\"nodeType\":3,\"id\":74,\"textContent\":\" \"},{\"nodeType\":1,\"id\":75,\"tagName\":\"P\",\"attributes\":{\"class\":\"userid\",\"id\":\"userid\"},\"childNodes\":[{\"nodeType\":3,\"id\":76,\"textContent\":\"8LK9M\"}]},{\"nodeType\":3,\"id\":77,\"textContent\":\" \"},{\"nodeType\":1,\"id\":78,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"userinput\"},\"childNodes\":[{\"nodeType\":3,\"id\":79,\"textContent\":\" \"},{\"nodeType\":8,\"id\":80},{\"nodeType\":3,\"id\":81,\"textContent\":\" \"},{\"nodeType\":1,\"id\":82,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"legend\",\"id\":\"hint-interactive\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":83,\"textContent\":\" \"},{\"nodeType\":1,\"id\":84,\"tagName\":\"P\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":85,\"textContent\":\"Hint: Hover your mouse over the data points in the graph\"}]},{\"nodeType\":3,\"id\":86,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":87,\"textContent\":\" \"},{\"nodeType\":8,\"id\":88},{\"nodeType\":3,\"id\":89,\"textContent\":\" \"},{\"nodeType\":8,\"id\":90},{\"nodeType\":3,\"id\":91,\"textContent\":\" \"},{\"nodeType\":1,\"id\":92,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"test\"},\"childNodes\":[{\"nodeType\":3,\"id\":93,\"textContent\":\" \"},{\"nodeType\":1,\"id\":94,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":95,\"textContent\":\" \"},{\"nodeType\":1,\"id\":96,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":97,\"textContent\":\"Which shift(s) start at 11 am? \"}]},{\"nodeType\":3,\"id\":98,\"textContent\":\" \"},{\"nodeType\":1,\"id\":99,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":100,\"textContent\":\" \"},{\"nodeType\":1,\"id\":101,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":102,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":103,\"textContent\":\" \"},{\"nodeType\":1,\"id\":104,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":105,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":106,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":107,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":108,\"textContent\":\" \"},{\"nodeType\":1,\"id\":109,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":110,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":111,\"textContent\":\" \"},{\"nodeType\":1,\"id\":112,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":113,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":115,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":116,\"textContent\":\" \"},{\"nodeType\":1,\"id\":117,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":118,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":120,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":121,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":122,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":123,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":125,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":126,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":127,\"textContent\":\" \"},{\"nodeType\":1,\"id\":128,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":129,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":130,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":132,\"textContent\":\" \"},{\"nodeType\":1,\"id\":133,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":134,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":135,\"textContent\":\" \"},{\"nodeType\":1,\"id\":136,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":137,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":138,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":140,\"textContent\":\" \"},{\"nodeType\":1,\"id\":141,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":142,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":143,\"textContent\":\" \"},{\"nodeType\":1,\"id\":144,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":145,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":146,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":147,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":148,\"textContent\":\" \"},{\"nodeType\":1,\"id\":149,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":150,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":151,\"textContent\":\" \"},{\"nodeType\":1,\"id\":152,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":153,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":154,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":156,\"textContent\":\" \"},{\"nodeType\":1,\"id\":157,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":158,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":159,\"textContent\":\" \"},{\"nodeType\":1,\"id\":160,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":161,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":162,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":163,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":164,\"textContent\":\" \"},{\"nodeType\":1,\"id\":165,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":166,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":167,\"textContent\":\" \"},{\"nodeType\":1,\"id\":168,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":169,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":170,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":171,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":172,\"textContent\":\" \"},{\"nodeType\":1,\"id\":173,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":174,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":175,\"textContent\":\" \"},{\"nodeType\":1,\"id\":176,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":177,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":178,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":179,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":180,\"textContent\":\" \"},{\"nodeType\":1,\"id\":181,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":182,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":183,\"textContent\":\" \"},{\"nodeType\":1,\"id\":184,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":185,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":186,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":187,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":188,\"textContent\":\" \"},{\"nodeType\":1,\"id\":189,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":190,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":191,\"textContent\":\" \"},{\"nodeType\":1,\"id\":192,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":193,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":194,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":196,\"textContent\":\" \"},{\"nodeType\":1,\"id\":197,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":198,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":200,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":201,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":202,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":203,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":205,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":206,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":207,\"textContent\":\" \"},{\"nodeType\":1,\"id\":208,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":209,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":210,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":211,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":212,\"textContent\":\" \"},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":214,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":215,\"textContent\":\" \"},{\"nodeType\":1,\"id\":216,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":217,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":218,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":219,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":220,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":221,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":223,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":224,\"textContent\":\" \"},{\"nodeType\":1,\"id\":225,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":226,\"textContent\":\"Which shift(s) start at the same time as D?\"}]},{\"nodeType\":3,\"id\":227,\"textContent\":\" \"},{\"nodeType\":1,\"id\":228,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":229,\"textContent\":\" \"},{\"nodeType\":1,\"id\":230,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":231,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":232,\"textContent\":\" \"},{\"nodeType\":1,\"id\":233,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":234,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":235,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":236,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":237,\"textContent\":\" \"},{\"nodeType\":1,\"id\":238,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":239,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":240,\"textContent\":\" \"},{\"nodeType\":1,\"id\":241,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":242,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":243,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":244,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":245,\"textContent\":\" \"},{\"nodeType\":1,\"id\":246,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":247,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":248,\"textContent\":\" \"},{\"nodeType\":1,\"id\":249,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":250,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":251,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":252,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":253,\"textContent\":\" \"},{\"nodeType\":1,\"id\":254,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":255,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":256,\"textContent\":\" \"},{\"nodeType\":1,\"id\":257,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":258,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":259,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":260,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":261,\"textContent\":\" \"},{\"nodeType\":1,\"id\":262,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":263,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":264,\"textContent\":\" \"},{\"nodeType\":1,\"id\":265,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":266,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":267,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":268,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":269,\"textContent\":\" \"},{\"nodeType\":1,\"id\":270,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":271,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":273,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":274,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":275,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":276,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":278,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":279,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":280,\"textContent\":\" \"},{\"nodeType\":1,\"id\":281,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":282,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":283,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":284,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":286,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":287,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":288,\"textContent\":\" \"},{\"nodeType\":1,\"id\":289,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":290,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":291,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":292,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":293,\"textContent\":\" \"},{\"nodeType\":1,\"id\":294,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":295,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":296,\"textContent\":\" \"},{\"nodeType\":1,\"id\":297,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":298,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":299,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":300,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":301,\"textContent\":\" \"},{\"nodeType\":1,\"id\":302,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":303,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":304,\"textContent\":\" \"},{\"nodeType\":1,\"id\":305,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":306,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":307,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":308,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":309,\"textContent\":\" \"},{\"nodeType\":1,\"id\":310,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":311,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":312,\"textContent\":\" \"},{\"nodeType\":1,\"id\":313,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":314,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":315,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":316,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":317,\"textContent\":\" \"},{\"nodeType\":1,\"id\":318,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":319,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":320,\"textContent\":\" \"},{\"nodeType\":1,\"id\":321,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":322,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":323,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":324,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":325,\"textContent\":\" \"},{\"nodeType\":1,\"id\":326,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":327,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":328,\"textContent\":\" \"},{\"nodeType\":1,\"id\":329,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":330,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":331,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":332,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":333,\"textContent\":\" \"},{\"nodeType\":1,\"id\":334,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":335,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":336,\"textContent\":\" \"},{\"nodeType\":1,\"id\":337,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":338,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":339,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":340,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":341,\"textContent\":\" \"},{\"nodeType\":1,\"id\":342,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":343,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":344,\"textContent\":\" \"},{\"nodeType\":1,\"id\":345,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":346,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":347,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":348,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":349,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":351,\"textContent\":\" \"},{\"nodeType\":1,\"id\":352,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":353,\"textContent\":\" \"},{\"nodeType\":1,\"id\":354,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":355,\"textContent\":\"Which shift(s) begin when C ends?\"}]},{\"nodeType\":3,\"id\":356,\"textContent\":\" \"},{\"nodeType\":1,\"id\":357,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":358,\"textContent\":\" \"},{\"nodeType\":1,\"id\":359,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":360,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":361,\"textContent\":\" \"},{\"nodeType\":1,\"id\":362,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":363,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":364,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":365,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":366,\"textContent\":\" \"},{\"nodeType\":1,\"id\":367,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":368,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":369,\"textContent\":\" \"},{\"nodeType\":1,\"id\":370,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":371,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":372,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":373,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":374,\"textContent\":\" \"},{\"nodeType\":1,\"id\":375,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":376,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":377,\"textContent\":\" \"},{\"nodeType\":1,\"id\":378,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":379,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":380,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":381,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":382,\"textContent\":\" \"},{\"nodeType\":1,\"id\":383,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":384,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":385,\"textContent\":\" \"},{\"nodeType\":1,\"id\":386,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":387,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":388,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":389,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":390,\"textContent\":\" \"},{\"nodeType\":1,\"id\":391,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":392,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":393,\"textContent\":\" \"},{\"nodeType\":1,\"id\":394,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":395,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":396,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":397,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":398,\"textContent\":\" \"},{\"nodeType\":1,\"id\":399,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":400,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":401,\"textContent\":\" \"},{\"nodeType\":1,\"id\":402,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":403,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":404,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":405,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":406,\"textContent\":\" \"},{\"nodeType\":1,\"id\":407,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":408,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":409,\"textContent\":\" \"},{\"nodeType\":1,\"id\":410,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":411,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":412,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":413,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":414,\"textContent\":\" \"},{\"nodeType\":1,\"id\":415,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":416,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":417,\"textContent\":\" \"},{\"nodeType\":1,\"id\":418,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":419,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":420,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":421,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":422,\"textContent\":\" \"},{\"nodeType\":1,\"id\":423,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":424,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":425,\"textContent\":\" \"},{\"nodeType\":1,\"id\":426,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":427,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":428,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":429,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":430,\"textContent\":\" \"},{\"nodeType\":1,\"id\":431,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":432,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":433,\"textContent\":\" \"},{\"nodeType\":1,\"id\":434,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":435,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":436,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":437,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":438,\"textContent\":\" \"},{\"nodeType\":1,\"id\":439,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":440,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":441,\"textContent\":\" \"},{\"nodeType\":1,\"id\":442,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":443,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":444,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":445,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":446,\"textContent\":\" \"},{\"nodeType\":1,\"id\":447,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":448,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":449,\"textContent\":\" \"},{\"nodeType\":1,\"id\":450,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":451,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":452,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":453,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":454,\"textContent\":\" \"},{\"nodeType\":1,\"id\":455,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":456,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":457,\"textContent\":\" \"},{\"nodeType\":1,\"id\":458,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":459,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":460,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":461,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":462,\"textContent\":\" \"},{\"nodeType\":1,\"id\":463,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":464,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":465,\"textContent\":\" \"},{\"nodeType\":1,\"id\":466,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":467,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":468,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":469,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":470,\"textContent\":\" \"},{\"nodeType\":1,\"id\":471,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":472,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":473,\"textContent\":\" \"},{\"nodeType\":1,\"id\":474,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":475,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":476,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":477,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":478,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":479,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":480,\"textContent\":\" \"},{\"nodeType\":1,\"id\":481,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":483,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":484,\"textContent\":\" Which shift(s) end at 4 pm?\"}]},{\"nodeType\":3,\"id\":485,\"textContent\":\" \"},{\"nodeType\":1,\"id\":486,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":492,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":500,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":503,\"textContent\":\" \"},{\"nodeType\":1,\"id\":504,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":505,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":506,\"textContent\":\" \"},{\"nodeType\":1,\"id\":507,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":508,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":509,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":510,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":511,\"textContent\":\" \"},{\"nodeType\":1,\"id\":512,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":513,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":514,\"textContent\":\" \"},{\"nodeType\":1,\"id\":515,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":516,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":517,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":518,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":519,\"textContent\":\" \"},{\"nodeType\":1,\"id\":520,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":521,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":522,\"textContent\":\" \"},{\"nodeType\":1,\"id\":523,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":524,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":525,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":526,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":527,\"textContent\":\" \"},{\"nodeType\":1,\"id\":528,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":529,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":530,\"textContent\":\" \"},{\"nodeType\":1,\"id\":531,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":532,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":533,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":534,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":535,\"textContent\":\" \"},{\"nodeType\":1,\"id\":536,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":537,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":538,\"textContent\":\" \"},{\"nodeType\":1,\"id\":539,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":540,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":541,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":542,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":543,\"textContent\":\" \"},{\"nodeType\":1,\"id\":544,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":545,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":546,\"textContent\":\" \"},{\"nodeType\":1,\"id\":547,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":548,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":549,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":550,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":551,\"textContent\":\" \"},{\"nodeType\":1,\"id\":552,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":553,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":554,\"textContent\":\" \"},{\"nodeType\":1,\"id\":555,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":556,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":557,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":558,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":559,\"textContent\":\" \"},{\"nodeType\":1,\"id\":560,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":561,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":562,\"textContent\":\" \"},{\"nodeType\":1,\"id\":563,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":564,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":565,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":566,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":567,\"textContent\":\" \"},{\"nodeType\":1,\"id\":568,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":569,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":570,\"textContent\":\" \"},{\"nodeType\":1,\"id\":571,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":572,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":573,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":574,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":575,\"textContent\":\" \"},{\"nodeType\":1,\"id\":576,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":577,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":578,\"textContent\":\" \"},{\"nodeType\":1,\"id\":579,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":580,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":581,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":582,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":583,\"textContent\":\" \"},{\"nodeType\":1,\"id\":584,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":585,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":586,\"textContent\":\" \"},{\"nodeType\":1,\"id\":587,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":588,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":589,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":590,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":592,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":593,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":594,\"textContent\":\" \"},{\"nodeType\":1,\"id\":595,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":596,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":597,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":598,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":599,\"textContent\":\" \"},{\"nodeType\":1,\"id\":600,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":601,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":602,\"textContent\":\" \"},{\"nodeType\":1,\"id\":603,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":604,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":605,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":606,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":607,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":608,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":609,\"textContent\":\" \"},{\"nodeType\":1,\"id\":610,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":612,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":613,\"textContent\":\"Coffee breaks happen halfway through a shift.\"},{\"nodeType\":1,\"id\":614,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":615,\"textContent\":\" Which shift(s) share a break with I?\"}]},{\"nodeType\":3,\"id\":616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":617,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":618,\"textContent\":\" \"},{\"nodeType\":1,\"id\":619,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":620,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":621,\"textContent\":\" \"},{\"nodeType\":1,\"id\":622,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":623,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":624,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":625,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":626,\"textContent\":\" \"},{\"nodeType\":1,\"id\":627,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":628,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":629,\"textContent\":\" \"},{\"nodeType\":1,\"id\":630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":631,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":632,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":633,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":634,\"textContent\":\" \"},{\"nodeType\":1,\"id\":635,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":636,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":637,\"textContent\":\" \"},{\"nodeType\":1,\"id\":638,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":639,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":640,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":641,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":642,\"textContent\":\" \"},{\"nodeType\":1,\"id\":643,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":644,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":645,\"textContent\":\" \"},{\"nodeType\":1,\"id\":646,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":647,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":648,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":649,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":650,\"textContent\":\" \"},{\"nodeType\":1,\"id\":651,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":653,\"textContent\":\" \"},{\"nodeType\":1,\"id\":654,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":655,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":656,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":657,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":659,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":660,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":661,\"textContent\":\" \"},{\"nodeType\":1,\"id\":662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":663,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":664,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":665,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":666,\"textContent\":\" \"},{\"nodeType\":1,\"id\":667,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":668,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":669,\"textContent\":\" \"},{\"nodeType\":1,\"id\":670,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":671,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":672,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":673,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":674,\"textContent\":\" \"},{\"nodeType\":1,\"id\":675,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":676,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":677,\"textContent\":\" \"},{\"nodeType\":1,\"id\":678,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":679,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":680,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":681,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":682,\"textContent\":\" \"},{\"nodeType\":1,\"id\":683,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":685,\"textContent\":\" \"},{\"nodeType\":1,\"id\":686,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":687,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":688,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":689,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":690,\"textContent\":\" \"},{\"nodeType\":1,\"id\":691,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":692,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":693,\"textContent\":\" \"},{\"nodeType\":1,\"id\":694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":695,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":696,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":697,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":698,\"textContent\":\" \"},{\"nodeType\":1,\"id\":699,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":700,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":701,\"textContent\":\" \"},{\"nodeType\":1,\"id\":702,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":703,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":704,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":705,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":706,\"textContent\":\" \"},{\"nodeType\":1,\"id\":707,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":708,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":709,\"textContent\":\" \"},{\"nodeType\":1,\"id\":710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":711,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":712,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":713,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":714,\"textContent\":\" \"},{\"nodeType\":1,\"id\":715,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":716,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":717,\"textContent\":\" \"},{\"nodeType\":1,\"id\":718,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":719,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":720,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":721,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":722,\"textContent\":\" \"},{\"nodeType\":1,\"id\":723,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":724,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":725,\"textContent\":\" \"},{\"nodeType\":1,\"id\":726,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":727,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":728,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":729,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":730,\"textContent\":\" \"},{\"nodeType\":1,\"id\":731,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":732,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":733,\"textContent\":\" \"},{\"nodeType\":1,\"id\":734,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":735,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":736,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":737,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":738,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":739,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":741,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":742,\"textContent\":\" \"},{\"nodeType\":1,\"id\":743,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":744,\"textContent\":\"Which shift(s) are six hours long?\"}]},{\"nodeType\":3,\"id\":745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":746,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":747,\"textContent\":\" \"},{\"nodeType\":1,\"id\":748,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":749,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":750,\"textContent\":\" \"},{\"nodeType\":1,\"id\":751,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":752,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":753,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":754,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":755,\"textContent\":\" \"},{\"nodeType\":1,\"id\":756,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":757,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":758,\"textContent\":\" \"},{\"nodeType\":1,\"id\":759,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":760,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":761,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":762,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":763,\"textContent\":\" \"},{\"nodeType\":1,\"id\":764,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":765,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":766,\"textContent\":\" \"},{\"nodeType\":1,\"id\":767,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":768,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":769,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":770,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":771,\"textContent\":\" \"},{\"nodeType\":1,\"id\":772,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":773,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":774,\"textContent\":\" \"},{\"nodeType\":1,\"id\":775,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":776,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":777,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":778,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":779,\"textContent\":\" \"},{\"nodeType\":1,\"id\":780,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":781,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":782,\"textContent\":\" \"},{\"nodeType\":1,\"id\":783,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":784,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":785,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":786,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":787,\"textContent\":\" \"},{\"nodeType\":1,\"id\":788,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":789,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":790,\"textContent\":\" \"},{\"nodeType\":1,\"id\":791,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":792,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":793,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":794,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":795,\"textContent\":\" \"},{\"nodeType\":1,\"id\":796,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":797,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":798,\"textContent\":\" \"},{\"nodeType\":1,\"id\":799,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":800,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":801,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":802,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":803,\"textContent\":\" \"},{\"nodeType\":1,\"id\":804,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":805,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":806,\"textContent\":\" \"},{\"nodeType\":1,\"id\":807,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":808,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":809,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":810,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":812,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":813,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":814,\"textContent\":\" \"},{\"nodeType\":1,\"id\":815,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":816,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":817,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":818,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":819,\"textContent\":\" \"},{\"nodeType\":1,\"id\":820,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":821,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":822,\"textContent\":\" \"},{\"nodeType\":1,\"id\":823,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":824,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":825,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":826,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":827,\"textContent\":\" \"},{\"nodeType\":1,\"id\":828,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":829,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":830,\"textContent\":\" \"},{\"nodeType\":1,\"id\":831,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":832,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":833,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":834,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":835,\"textContent\":\" \"},{\"nodeType\":1,\"id\":836,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":837,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":838,\"textContent\":\" \"},{\"nodeType\":1,\"id\":839,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":840,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":841,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":842,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":843,\"textContent\":\" \"},{\"nodeType\":1,\"id\":844,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":845,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":846,\"textContent\":\" \"},{\"nodeType\":1,\"id\":847,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":848,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":849,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":850,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":851,\"textContent\":\" \"},{\"nodeType\":1,\"id\":852,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":853,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":854,\"textContent\":\" \"},{\"nodeType\":1,\"id\":855,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":856,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":857,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":858,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":859,\"textContent\":\" \"},{\"nodeType\":1,\"id\":860,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":861,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":862,\"textContent\":\" \"},{\"nodeType\":1,\"id\":863,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":864,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":865,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":866,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":867,\"textContent\":\" \"},{\"nodeType\":1,\"id\":868,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":869,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":870,\"textContent\":\" \"},{\"nodeType\":1,\"id\":871,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":872,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":873,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":874,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":875,\"textContent\":\" \"},{\"nodeType\":1,\"id\":876,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":877,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":878,\"textContent\":\" \"},{\"nodeType\":1,\"id\":879,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":880,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":881,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":882,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":883,\"textContent\":\" \"},{\"nodeType\":1,\"id\":884,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":885,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":886,\"textContent\":\" \"},{\"nodeType\":1,\"id\":887,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":888,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":889,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":890,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":891,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":892,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":894,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":895,\"textContent\":\" \"},{\"nodeType\":1,\"id\":896,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":897,\"textContent\":\"Which 2 shifts less than 5 hours long start at the same time?\"}]},{\"nodeType\":3,\"id\":898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":899,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":900,\"textContent\":\" \"},{\"nodeType\":1,\"id\":901,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":902,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":903,\"textContent\":\" \"},{\"nodeType\":1,\"id\":904,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":905,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":906,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":907,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":908,\"textContent\":\" \"},{\"nodeType\":1,\"id\":909,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":910,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":911,\"textContent\":\" \"},{\"nodeType\":1,\"id\":912,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":913,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":914,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":915,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":916,\"textContent\":\" \"},{\"nodeType\":1,\"id\":917,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":918,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":919,\"textContent\":\" \"},{\"nodeType\":1,\"id\":920,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":921,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":922,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":923,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":924,\"textContent\":\" \"},{\"nodeType\":1,\"id\":925,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":926,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":927,\"textContent\":\" \"},{\"nodeType\":1,\"id\":928,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":929,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":930,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":931,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":932,\"textContent\":\" \"},{\"nodeType\":1,\"id\":933,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":934,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":935,\"textContent\":\" \"},{\"nodeType\":1,\"id\":936,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":937,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":938,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":939,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":940,\"textContent\":\" \"},{\"nodeType\":1,\"id\":941,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":942,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":943,\"textContent\":\" \"},{\"nodeType\":1,\"id\":944,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":945,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":946,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":947,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":948,\"textContent\":\" \"},{\"nodeType\":1,\"id\":949,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":950,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":951,\"textContent\":\" \"},{\"nodeType\":1,\"id\":952,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":953,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":954,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":955,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":956,\"textContent\":\" \"},{\"nodeType\":1,\"id\":957,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":958,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":959,\"textContent\":\" \"},{\"nodeType\":1,\"id\":960,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":961,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":962,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":963,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":965,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":966,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":967,\"textContent\":\" \"},{\"nodeType\":1,\"id\":968,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":969,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":970,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":971,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":972,\"textContent\":\" \"},{\"nodeType\":1,\"id\":973,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":974,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":975,\"textContent\":\" \"},{\"nodeType\":1,\"id\":976,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":977,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":978,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":979,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":980,\"textContent\":\" \"},{\"nodeType\":1,\"id\":981,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":982,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":983,\"textContent\":\" \"},{\"nodeType\":1,\"id\":984,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":985,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":986,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":987,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":988,\"textContent\":\" \"},{\"nodeType\":1,\"id\":989,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":990,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":991,\"textContent\":\" \"},{\"nodeType\":1,\"id\":992,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":993,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":994,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":995,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":996,\"textContent\":\" \"},{\"nodeType\":1,\"id\":997,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":998,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":999,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1000,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1001,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1002,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1003,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1004,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1005,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1006,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1007,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1008,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1009,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1010,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1011,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1012,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1013,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1014,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1015,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1016,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1017,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1018,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1019,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1020,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1021,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1022,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1023,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1024,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1025,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1026,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1027,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1028,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1029,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1030,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1031,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1032,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1033,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1034,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1035,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1036,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1037,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1038,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1039,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1040,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1041,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1042,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1043,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1044,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1045,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1047,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+contained\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1048,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1049,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1050,\"textContent\":\"Which shift(s) under 7 hours long starts before B starts, and ends after X ends?\"}]},{\"nodeType\":3,\"id\":1051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1052,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1053,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1054,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1055,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1056,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1057,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1058,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1059,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1060,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1061,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1062,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1063,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1064,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1065,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1066,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1067,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1068,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1069,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1070,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1071,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1072,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1073,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1074,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1075,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1076,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1077,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1078,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1079,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1080,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1081,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1082,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1083,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1084,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1085,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1086,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1087,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1088,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1089,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1090,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1091,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1092,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1093,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1094,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1095,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1096,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1097,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1098,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1099,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1100,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1101,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1102,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1103,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1104,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1105,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1106,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1107,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1108,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1109,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1110,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1111,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1112,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1113,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1114,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1115,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1116,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1118,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1119,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1120,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1121,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1122,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1123,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1124,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1125,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1126,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1127,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1128,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1129,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1130,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1131,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1132,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1133,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1134,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1135,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1136,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1137,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1138,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1139,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1140,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1141,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1142,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1143,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1144,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1145,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1146,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1147,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1148,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1149,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1150,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1151,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1152,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1153,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1154,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1155,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1156,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1157,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1158,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1159,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1160,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1161,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1162,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1163,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1164,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1165,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1166,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1167,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1168,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1169,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1170,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1171,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1172,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1173,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1174,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1175,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1176,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1177,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1178,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1179,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1180,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1181,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1182,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1183,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1184,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1185,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1186,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1187,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1188,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1189,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1190,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1191,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1192,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1193,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1194,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1195,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1196,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1197,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1198,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1200,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime+before+endtime+during\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1202,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1203,\"textContent\":\"Which shift(s) begins before J begins and ends during B?\"}]},{\"nodeType\":3,\"id\":1204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1205,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1211,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1219,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1227,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1235,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1243,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1251,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1259,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1267,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1270,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1271,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1272,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1273,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1274,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1275,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1276,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1277,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1278,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1279,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1280,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1281,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1282,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1283,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1284,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1285,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1286,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1287,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1288,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1289,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1290,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1291,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1292,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1293,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1294,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1295,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1296,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1298,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1299,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1300,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1301,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1302,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1303,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1304,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1305,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1306,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1307,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1308,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1309,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1310,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1311,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1312,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1313,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1314,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1315,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1316,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1317,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1318,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1319,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1320,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1321,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1322,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1323,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1324,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1325,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1326,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1327,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1328,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1329,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1330,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1331,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1332,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1333,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1334,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1335,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1336,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1337,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1338,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1339,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1340,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1341,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1342,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1343,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1344,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1345,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1346,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1347,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1348,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1349,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1351,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1352,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1353,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.ends\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1354,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1355,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1356,\"textContent\":\"Which shift(s) end at the same time as F?\"}]},{\"nodeType\":3,\"id\":1357,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1358,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1359,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1360,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1361,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1362,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1363,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1364,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1365,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1366,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1367,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1368,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1369,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1370,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1371,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1372,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1373,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1374,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1375,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1376,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1377,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1378,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1379,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1380,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1381,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1382,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1383,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1384,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1385,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1386,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1387,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1388,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1389,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1390,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1391,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1392,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1393,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1394,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1395,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1396,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1397,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1398,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1399,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1400,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1401,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1402,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1403,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1404,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1405,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1406,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1407,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1408,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1409,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1410,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1411,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1412,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1413,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1414,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1415,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1416,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1417,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1418,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1419,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1420,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1421,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1422,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1423,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1424,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1425,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1426,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1427,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1428,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1429,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1430,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1431,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1432,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1433,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1434,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1435,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1436,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1437,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1438,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1439,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1440,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1441,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1442,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1443,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1444,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1445,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1446,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1447,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1448,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1449,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1450,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1451,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1452,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1453,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1454,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1455,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1456,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1457,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1458,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1459,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1460,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1461,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1462,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1463,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1464,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1465,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1466,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1467,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1468,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1469,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1470,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1471,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1472,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1473,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1474,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1475,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1476,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1477,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1478,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1479,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1480,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1481,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1483,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1484,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1485,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1486,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1492,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1500,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1503,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1504,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1505,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1506,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1507,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1508,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1509,\"textContent\":\"Which shift(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":1510,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1511,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1512,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1513,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1514,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1515,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1516,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1517,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1518,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1519,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1520,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1521,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1522,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1523,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1524,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1525,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1526,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1527,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1528,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1529,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1530,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1531,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1532,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1533,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1534,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1535,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1536,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1537,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1538,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1539,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1540,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1541,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1542,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1543,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1544,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1545,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1546,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1547,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1548,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1549,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1550,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1551,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1552,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1553,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1554,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1555,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1556,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1557,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1558,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1559,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1560,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1561,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1562,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1563,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1564,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1565,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1566,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1567,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1568,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1569,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1570,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1571,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1572,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1573,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1574,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1575,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1576,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1577,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1578,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1579,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1580,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1581,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1582,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1583,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1584,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1585,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1586,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1587,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1588,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1589,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1590,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1591,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1592,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1593,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1594,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1595,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1596,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1597,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1598,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1599,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1600,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1601,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1602,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1603,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1604,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1605,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1606,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1607,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1608,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1609,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1610,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1612,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1613,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1614,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1615,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1617,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1618,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1619,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1620,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1621,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1622,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1623,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1624,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1625,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1627,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1628,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1629,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1630,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1631,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1632,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1633,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1634,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1635,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1636,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1637,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1638,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1639,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1640,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1641,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1642,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1643,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1644,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1645,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1646,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1647,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1648,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1649,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1650,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1651,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1652,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1653,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1654,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1655,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1656,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1657,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1659,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1660,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1661,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1662,\"textContent\":\"Which shift(s) start at the same time as F?\"}]},{\"nodeType\":3,\"id\":1663,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1664,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1665,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1666,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1667,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1668,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1669,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1670,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1671,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1672,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1673,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1674,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1675,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1676,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1677,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1678,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1679,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1680,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1681,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1682,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1683,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1684,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1686,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1687,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1688,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1689,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1690,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1691,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1692,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1693,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1694,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1695,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1696,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1697,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1698,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1699,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1700,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1701,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1702,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1703,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1704,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1705,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1706,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1707,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1708,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1709,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1710,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1711,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1712,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1713,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1714,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1715,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1716,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1717,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1718,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1720,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1721,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1722,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1723,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1724,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1725,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1726,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1727,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1728,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1729,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1730,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1731,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1732,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1733,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1734,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1735,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1736,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1737,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1738,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1739,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1741,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1742,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1743,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1744,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1746,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1747,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1748,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1749,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1750,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1751,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1752,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1753,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1754,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1755,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1756,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1757,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1758,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1759,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1760,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1761,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1762,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1763,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1764,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1765,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1766,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1767,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1768,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1769,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1770,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1771,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1772,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1773,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1774,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1775,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1776,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1777,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1778,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1779,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1780,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1781,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1782,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1783,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1784,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1785,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1786,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1787,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1788,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1789,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1790,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1791,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1792,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1793,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1794,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1795,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1796,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1797,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1798,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1799,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1800,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1801,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1802,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1803,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1804,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1805,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1806,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1807,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1808,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1809,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1810,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1812,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1813,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1814,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1815,\"textContent\":\"Which 2 shifts end when Z begins?\"}]},{\"nodeType\":3,\"id\":1816,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1817,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1818,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1819,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1820,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1821,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1822,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1823,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1824,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1825,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1826,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1827,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1828,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1829,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1830,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1831,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1832,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1833,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1834,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1835,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1836,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1837,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1838,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1839,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1840,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1841,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1842,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1843,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1844,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1845,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1846,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1847,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1848,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1849,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1850,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1851,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1852,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1853,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1854,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1855,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1856,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1857,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1858,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1859,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1860,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1861,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1862,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1863,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1864,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1865,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1866,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1867,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1868,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1869,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1870,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1871,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1872,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1873,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1874,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1875,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1876,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1877,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1878,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1879,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1880,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1881,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1882,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1883,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1884,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1885,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1886,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1887,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1888,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1889,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1890,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1891,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1892,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1894,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1895,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1896,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1897,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1899,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1900,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1901,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1902,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1903,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1904,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1905,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1906,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1907,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1908,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1909,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1910,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1911,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1912,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1913,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1914,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1915,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1916,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1917,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1918,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1919,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1920,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1921,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1922,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1923,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1924,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1925,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1926,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1927,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1928,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1929,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1930,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1931,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1932,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1933,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1934,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1935,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1936,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1937,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1938,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1939,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1940,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1941,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1942,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1943,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1944,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1945,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1946,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1947,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1948,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1949,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1950,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1951,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1952,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1953,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1954,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1955,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1956,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1957,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1958,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1959,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1960,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1961,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1962,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1963,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1965,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1966,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1967,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1968,\"textContent\":\"Which shift(s) end at 3pm?\"}]},{\"nodeType\":3,\"id\":1969,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1970,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1971,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1972,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1973,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1974,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1975,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1976,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1977,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1978,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1979,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1980,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1981,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1982,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1983,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1984,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1985,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1986,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1987,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1988,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1989,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1990,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1991,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1992,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1993,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1994,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1995,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1996,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1997,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1998,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1999,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2000,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2001,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2002,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2003,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2004,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2005,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2006,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2007,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2008,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2009,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2010,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2011,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2012,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2013,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2014,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2015,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2016,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2017,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2018,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2019,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2020,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2021,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2022,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2023,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2024,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2025,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2026,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2027,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2028,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2029,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2030,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2031,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2032,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2033,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2034,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2035,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2036,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2037,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2038,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2039,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2040,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2041,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2042,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2043,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2044,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2045,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2047,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2048,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2049,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2050,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2052,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2053,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2054,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2055,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2056,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2057,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2058,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2059,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2060,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2061,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2062,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2063,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2064,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2065,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2066,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2067,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2068,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2069,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2070,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2071,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2072,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2073,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2074,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2075,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2076,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2077,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2078,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2079,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2080,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2081,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2082,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2083,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2084,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2085,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2086,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2087,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2088,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2089,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2090,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2091,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2092,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2093,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2094,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2095,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2096,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2097,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2098,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2099,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2100,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2101,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2102,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2103,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2104,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2105,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2106,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2107,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2108,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2109,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2110,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2111,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2112,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2113,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2114,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2115,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2116,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2118,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":2119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2120,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2121,\"textContent\":\"Coffee breaks happen halfway through a shift. \"},{\"nodeType\":1,\"id\":2122,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":2123,\"textContent\":\"Which shifts share a break at 2pm?\"}]},{\"nodeType\":3,\"id\":2124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2125,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":2126,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2127,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2128,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2129,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2130,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2131,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":2132,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2133,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2134,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2135,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2136,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2137,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2138,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2139,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":2140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2141,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2142,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2143,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2144,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2145,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2146,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2147,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":2148,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2149,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2150,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2151,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2152,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2153,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2154,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2155,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2156,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2157,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2158,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2159,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2160,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2161,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2162,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2163,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2164,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2165,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2166,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2167,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2168,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2169,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2170,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2171,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2172,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2173,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2174,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2175,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2176,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2177,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2178,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2179,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2180,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2181,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2182,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2183,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2184,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2185,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2186,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2187,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2188,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2189,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2190,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2191,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2192,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2193,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2194,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2195,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2196,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2197,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2198,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2199,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2200,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2202,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2203,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2204,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2205,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2211,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2219,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2227,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2235,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2243,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2251,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2259,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2267,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2270,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2271,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2273,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\".strategy\",\"style\":\"display: block;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2274,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2275,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2276,\"textContent\":\"Please describe how to determine what event(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":2277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2278,\"tagName\":\"TEXTAREA\",\"attributes\":{\"id\":\"strategyAnswer\",\"rows\":\"5\",\"cols\":\"80\"}},{\"nodeType\":3,\"id\":2279,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2280,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2281,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2282},{\"nodeType\":3,\"id\":2283,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2284},{\"nodeType\":3,\"id\":2285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2286,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"fixbottom\"},\"childNodes\":[{\"nodeType\":3,\"id\":2287,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2288,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"testingButton\",\"style\":\"display:none;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2289,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2290,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2291,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"strategyButton\",\"style\":\"display: block;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2292,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2293,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2294,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2295,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2296},{\"nodeType\":3,\"id\":2297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2298,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"d3container\"},\"childNodes\":[{\"nodeType\":1,\"id\":2299,\"tagName\":\"svg\",\"attributes\":{\"width\":\"930\",\"height\":\"915\"},\"childNodes\":[{\"nodeType\":1,\"id\":2300,\"tagName\":\"g\",\"attributes\":{\"transform\":\"translate(100,25)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2301,\"tagName\":\"g\",\"attributes\":{\"class\":\"leaders\"}},{\"nodeType\":1,\"id\":2302,\"tagName\":\"g\",\"attributes\":{\"class\":\"static-scaffold\"}},{\"nodeType\":1,\"id\":2303,\"tagName\":\"g\",\"attributes\":{\"class\":\"xaxis\",\"transform\":\"translate(0,800)\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"middle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2304,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M0.5,6V0.5H800.5V6\"}},{\"nodeType\":1,\"id\":2305,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2306,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2307,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2308,\"textContent\":\"08 AM\"}]}]},{\"nodeType\":1,\"id\":2309,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(33.83333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2310,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2311,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2312,\"textContent\":\"08:30\"}]}]},{\"nodeType\":1,\"id\":2313,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(67.16666666666666,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2314,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2315,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2316,\"textContent\":\"09 AM\"}]}]},{\"nodeType\":1,\"id\":2317,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(100.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2318,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2319,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2320,\"textContent\":\"09:30\"}]}]},{\"nodeType\":1,\"id\":2321,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(133.83333333333331,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2322,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2323,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2324,\"textContent\":\"10 AM\"}]}]},{\"nodeType\":1,\"id\":2325,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(167.16666666666669,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2326,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2327,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2328,\"textContent\":\"10:30\"}]}]},{\"nodeType\":1,\"id\":2329,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(200.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2330,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2331,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2332,\"textContent\":\"11 AM\"}]}]},{\"nodeType\":1,\"id\":2333,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(233.83333333333334,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2334,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2335,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2336,\"textContent\":\"11:30\"}]}]},{\"nodeType\":1,\"id\":2337,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(267.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2338,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2339,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2340,\"textContent\":\"12 PM\"}]}]},{\"nodeType\":1,\"id\":2341,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(300.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2342,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2343,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2344,\"textContent\":\"12:30\"}]}]},{\"nodeType\":1,\"id\":2345,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(333.83333333333337,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2346,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2347,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2348,\"textContent\":\"01 PM\"}]}]},{\"nodeType\":1,\"id\":2349,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(367.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2350,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2351,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2352,\"textContent\":\"01:30\"}]}]},{\"nodeType\":1,\"id\":2353,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(400.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2354,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2355,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2356,\"textContent\":\"02 PM\"}]}]},{\"nodeType\":1,\"id\":2357,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(433.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2358,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2359,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2360,\"textContent\":\"02:30\"}]}]},{\"nodeType\":1,\"id\":2361,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(467.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2362,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2363,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2364,\"textContent\":\"03 PM\"}]}]},{\"nodeType\":1,\"id\":2365,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(500.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2366,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2367,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2368,\"textContent\":\"03:30\"}]}]},{\"nodeType\":1,\"id\":2369,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(533.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2370,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2371,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2372,\"textContent\":\"04 PM\"}]}]},{\"nodeType\":1,\"id\":2373,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(567.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2374,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2375,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2376,\"textContent\":\"04:30\"}]}]},{\"nodeType\":1,\"id\":2377,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(600.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2378,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2379,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2380,\"textContent\":\"05 PM\"}]}]},{\"nodeType\":1,\"id\":2381,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(633.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2382,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2383,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2384,\"textContent\":\"05:30\"}]}]},{\"nodeType\":1,\"id\":2385,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(667.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2386,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2387,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2388,\"textContent\":\"06 PM\"}]}]},{\"nodeType\":1,\"id\":2389,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(700.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2390,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2391,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2392,\"textContent\":\"06:30\"}]}]},{\"nodeType\":1,\"id\":2393,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(733.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2394,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2395,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2396,\"textContent\":\"07 PM\"}]}]},{\"nodeType\":1,\"id\":2397,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(767.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2398,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2399,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2400,\"textContent\":\"07:30\"}]}]},{\"nodeType\":1,\"id\":2401,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(800.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2402,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2403,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2404,\"textContent\":\"08 PM\"}]}]},{\"nodeType\":1,\"id\":2405,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2406,\"tagName\":\"text\",\"attributes\":{\"x\":\"533.3333333333334\",\"y\":\"80\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2407,\"textContent\":\"START & END TIME (time of day)\"}]}]}]},{\"nodeType\":1,\"id\":2408,\"tagName\":\"g\",\"attributes\":{\"class\":\"yaxis\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"end\"},\"childNodes\":[{\"nodeType\":1,\"id\":2409,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M-15,800.5H0.5V0.5H-15\"}},{\"nodeType\":1,\"id\":2410,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,800.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2411,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2412,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2413,\"textContent\":\"0\"}]}]},{\"nodeType\":1,\"id\":2414,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,733.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2415,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2416,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2417,\"textContent\":\"1\"}]}]},{\"nodeType\":1,\"id\":2418,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,667.1666666666667)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2419,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2420,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2421,\"textContent\":\"2\"}]}]},{\"nodeType\":1,\"id\":2422,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,600.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2423,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2424,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2425,\"textContent\":\"3\"}]}]},{\"nodeType\":1,\"id\":2426,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,533.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2427,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2428,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2429,\"textContent\":\"4\"}]}]},{\"nodeType\":1,\"id\":2430,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,467.16666666666663)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2431,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2432,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2433,\"textContent\":\"5\"}]}]},{\"nodeType\":1,\"id\":2434,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,400.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2435,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2436,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2437,\"textContent\":\"6\"}]}]},{\"nodeType\":1,\"id\":2438,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,333.8333333333333)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2439,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2440,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2441,\"textContent\":\"7\"}]}]},{\"nodeType\":1,\"id\":2442,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,267.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2443,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2444,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2445,\"textContent\":\"8\"}]}]},{\"nodeType\":1,\"id\":2446,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,200.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2447,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2448,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2449,\"textContent\":\"9\"}]}]},{\"nodeType\":1,\"id\":2450,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,133.83333333333326)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2451,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2452,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2453,\"textContent\":\"10\"}]}]},{\"nodeType\":1,\"id\":2454,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,67.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2455,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2456,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2457,\"textContent\":\"11\"}]}]},{\"nodeType\":1,\"id\":2458,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,0.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2459,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2460,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2461,\"textContent\":\"12\"}]}]},{\"nodeType\":1,\"id\":2462,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2463,\"tagName\":\"text\",\"attributes\":{\"transform\":\"rotate(-90)\",\"x\":\"-350\",\"y\":\"-60\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2464,\"textContent\":\"DURATION (in hours)\"}]}]}]},{\"nodeType\":1,\"id\":2465,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2466,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2467,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"733.3333333333334\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2468,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2469,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"666.6666666666667\",\"y2\":\"666.6666666666667\"}}]},{\"nodeType\":1,\"id\":2470,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2471,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"600\",\"y2\":\"600\"}}]},{\"nodeType\":1,\"id\":2472,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2473,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"533.3333333333334\",\"y2\":\"533.3333333333334\"}}]},{\"nodeType\":1,\"id\":2474,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2475,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"466.66666666666663\",\"y2\":\"466.66666666666663\"}}]},{\"nodeType\":1,\"id\":2476,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2477,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"400\",\"y2\":\"400\"}}]},{\"nodeType\":1,\"id\":2478,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2479,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"333.3333333333333\",\"y2\":\"333.3333333333333\"}}]},{\"nodeType\":1,\"id\":2480,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2481,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"266.66666666666674\",\"y2\":\"266.66666666666674\"}}]},{\"nodeType\":1,\"id\":2482,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2483,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"200\",\"y2\":\"200\"}}]},{\"nodeType\":1,\"id\":2484,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2485,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"133.33333333333326\",\"y2\":\"133.33333333333326\"}}]},{\"nodeType\":1,\"id\":2486,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2487,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"66.66666666666674\",\"y2\":\"66.66666666666674\"}}]},{\"nodeType\":1,\"id\":2488,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2489,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"0\",\"y2\":\"0\"}}]}]},{\"nodeType\":1,\"id\":2490,\"tagName\":\"g\",\"attributes\":{\"class\":\"xgrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2491,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"0\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2492,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"800\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2493,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"433.3333333333333\",\"y2\":\"66.66666666666674\"}},{\"nodeType\":1,\"id\":2494,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"366.66666666666663\",\"y2\":\"66.66666666666674\"}},{\"nodeType\":1,\"id\":2495,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"466.6666666666667\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2496,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"333.33333333333337\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2497,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"500\",\"y2\":\"200\"}},{\"nodeType\":1,\"id\":2498,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"300\",\"y2\":\"200\"}},{\"nodeType\":1,\"id\":2499,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"533.3333333333333\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2500,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"266.66666666666663\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2501,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"566.6666666666667\",\"y2\":\"333.3333333333333\"}},{\"nodeType\":1,\"id\":2502,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"233.33333333333334\",\"y2\":\"333.3333333333333\"}},{\"nodeType\":1,\"id\":2503,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"600\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2504,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"200\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2505,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"633.3333333333333\",\"y2\":\"466.66666666666663\"}},{\"nodeType\":1,\"id\":2506,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"166.66666666666669\",\"y2\":\"466.66666666666663\"}},{\"nodeType\":1,\"id\":2507,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"666.6666666666667\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2508,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"133.33333333333331\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2509,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"700\",\"y2\":\"600\"}},{\"nodeType\":1,\"id\":2510,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"100\",\"y2\":\"600\"}},{\"nodeType\":1,\"id\":2511,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"733.3333333333333\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2512,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"66.66666666666666\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2513,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"766.6666666666667\",\"y2\":\"733.3333333333334\"}},{\"nodeType\":1,\"id\":2514,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"33.33333333333333\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2515,\"tagName\":\"g\",\"attributes\":{\"class\":\"data\"},\"childNodes\":[{\"nodeType\":1,\"id\":2516,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2517,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"266.66666666666674\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2518,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"258.66666666666674\"},\"childNodes\":[{\"nodeType\":3,\"id\":2519,\"textContent\":\"A \"}]}]},{\"nodeType\":1,\"id\":2520,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2521,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2522,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2523,\"textContent\":\"B \"}]}]},{\"nodeType\":1,\"id\":2524,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2525,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"366.66666666666663\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2526,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"361.66666666666663\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2527,\"textContent\":\"C \"}]}]},{\"nodeType\":1,\"id\":2528,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2529,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"666.6666666666667\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2530,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"661.6666666666667\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2531,\"textContent\":\"D \"}]}]},{\"nodeType\":1,\"id\":2532,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2533,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"200\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2534,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"195\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2535,\"textContent\":\"E \"}]}]},{\"nodeType\":1,\"id\":2536,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2537,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2538,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2539,\"textContent\":\"F \"}]}]},{\"nodeType\":1,\"id\":2540,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2541,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2542,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2543,\"textContent\":\"G \"}]}]},{\"nodeType\":1,\"id\":2544,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2545,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2546,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2547,\"textContent\":\"H \"}]}]},{\"nodeType\":1,\"id\":2548,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2549,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"100\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2550,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"95\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2551,\"textContent\":\"I \"}]}]},{\"nodeType\":1,\"id\":2552,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2553,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"133.33333333333331\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2554,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"128.33333333333331\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2555,\"textContent\":\"J \"}]}]},{\"nodeType\":1,\"id\":2556,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2557,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"133.33333333333326\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2558,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"125.33333333333326\"},\"childNodes\":[{\"nodeType\":3,\"id\":2559,\"textContent\":\"K \"}]}]},{\"nodeType\":1,\"id\":2560,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2561,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"333.3333333333333\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2562,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"325.3333333333333\"},\"childNodes\":[{\"nodeType\":3,\"id\":2563,\"textContent\":\"L \"}]}]},{\"nodeType\":1,\"id\":2564,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2565,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"300\",\"cy\":\"733.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2566,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"295\",\"y\":\"725.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2567,\"textContent\":\"M \"}]}]},{\"nodeType\":1,\"id\":2568,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2569,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"600\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2570,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"595\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2571,\"textContent\":\"N \"}]}]},{\"nodeType\":1,\"id\":2572,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2573,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"433.3333333333333\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2574,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"428.3333333333333\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2575,\"textContent\":\"O \"}]}]},{\"nodeType\":1,\"id\":2576,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2577,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"200\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2578,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"192\"},\"childNodes\":[{\"nodeType\":3,\"id\":2579,\"textContent\":\"P \"}]}]},{\"nodeType\":1,\"id\":2580,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2581,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"533.3333333333333\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2582,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"528.3333333333333\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2583,\"textContent\":\"Z \"}]}]},{\"nodeType\":1,\"id\":2584,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2585,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2586,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2587,\"textContent\":\"X \"}]}]}]}]}]}]},{\"nodeType\":3,\"id\":2588,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2589,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2590},{\"nodeType\":3,\"id\":2591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2592,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2593,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2594,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2595,\"textContent\":\" \"}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 562, dom: 1045, initialDom: 1137",
  "javascriptErrors": []
}