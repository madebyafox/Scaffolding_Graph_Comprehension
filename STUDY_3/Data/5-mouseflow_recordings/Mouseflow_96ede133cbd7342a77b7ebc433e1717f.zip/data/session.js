var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "96ede133cbd7342a77b7ebc433e1717f",
  "created": "2018-05-29T14:04:37.3876013-07:00",
  "lastActivity": "2018-05-29T14:06:05.8575357-07:00",
  "pageViews": [
    {
      "id": "052937283de91cc235a6bab27d582ff6b1df8b3a",
      "startTime": "2018-05-29T14:04:37.3876013-07:00",
      "endTime": "2018-05-29T14:06:05.8575357-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/",
      "visitTime": 88640,
      "engagementTime": 59567,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 88640,
  "engagementTime": 59567,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.41",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "3e74ea3c954e69587b4cdd8095341157",
  "gdpr": false
}