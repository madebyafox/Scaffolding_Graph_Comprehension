var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "3e5b6451e92a66fb0318e0c128b28f3c",
  "created": "2018-05-29T12:08:14.2949529-07:00",
  "lastActivity": "2018-05-29T12:09:45.538408-07:00",
  "pageViews": [
    {
      "id": "05291479f7645562ab54bd863f38c8bbc770d90d",
      "startTime": "2018-05-29T12:08:14.6336537-07:00",
      "endTime": "2018-05-29T12:09:45.538408-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/8",
      "visitTime": 91060,
      "engagementTime": 69762,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 91060,
  "engagementTime": 69762,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.37",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=MD6NK",
    "CONDITION=114"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "3184e265c149bb8988c6cf8a8eccc677",
  "gdpr": false
}