var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["060124347ac527db1c017bee98187e3b991d67aa"] = {
  "startTime": "2018-06-01T16:20:24.0995631Z",
  "websitePageUrl": "/16",
  "visitTime": 132869,
  "engagementTime": 116534,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1200,
  "tags": [
    "form-interact",
    "submit"
  ],
  "session": {
    "id": "da90c33a939430b5e3129dbeda714158",
    "created": "2018-06-01T16:20:24.0995631+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.181",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/16",
    "tags": [
      "form-interact",
      "submit"
    ],
    "variables": [
      "SID=DZD6F",
      "CONDITION=114"
    ],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "003944d5eed8d646733055295c93fb5f",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/da90c33a939430b5e3129dbeda714158/play"
  },
  "events": [
    {
      "t": 2,
      "e": 2,
      "ty": 14,
      "x": 0,
      "y": 1199
    },
    {
      "t": 174,
      "e": 174,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 174,
      "e": 174,
      "ty": 2,
      "x": 508,
      "y": 667
    },
    {
      "t": 174,
      "e": 174,
      "ty": 1,
      "x": 0,
      "y": 16
    },
    {
      "t": 201,
      "e": 201,
      "ty": 2,
      "x": 508,
      "y": 666
    },
    {
      "t": 251,
      "e": 251,
      "ty": 41,
      "x": 46189,
      "y": 36451,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 301,
      "e": 301,
      "ty": 2,
      "x": 509,
      "y": 666
    },
    {
      "t": 401,
      "e": 401,
      "ty": 2,
      "x": 509,
      "y": 665
    },
    {
      "t": 501,
      "e": 501,
      "ty": 2,
      "x": 509,
      "y": 664
    },
    {
      "t": 501,
      "e": 501,
      "ty": 41,
      "x": 46302,
      "y": 36340,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 657,
      "e": 657,
      "ty": 2,
      "x": 509,
      "y": 661
    },
    {
      "t": 701,
      "e": 701,
      "ty": 2,
      "x": 509,
      "y": 651
    },
    {
      "t": 751,
      "e": 751,
      "ty": 41,
      "x": 46302,
      "y": 62026,
      "ta": "> div.stimulus > div > div:[2]"
    },
    {
      "t": 783,
      "e": 783,
      "ty": 6,
      "x": 508,
      "y": 594,
      "ta": "#strategyAnswer"
    },
    {
      "t": 800,
      "e": 800,
      "ty": 2,
      "x": 508,
      "y": 586
    },
    {
      "t": 901,
      "e": 901,
      "ty": 2,
      "x": 508,
      "y": 579
    },
    {
      "t": 1001,
      "e": 1001,
      "ty": 2,
      "x": 508,
      "y": 571
    },
    {
      "t": 1001,
      "e": 1001,
      "ty": 41,
      "x": 46189,
      "y": 39050,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1101,
      "e": 1101,
      "ty": 2,
      "x": 507,
      "y": 566
    },
    {
      "t": 1251,
      "e": 1251,
      "ty": 41,
      "x": 46077,
      "y": 35005,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2320,
      "e": 2320,
      "ty": 3,
      "x": 507,
      "y": 566,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2322,
      "e": 2322,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2424,
      "e": 2424,
      "ty": 4,
      "x": 46077,
      "y": 35005,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2424,
      "e": 2424,
      "ty": 5,
      "x": 507,
      "y": 566,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10004,
      "e": 7424,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 20546,
      "e": 7424,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 20546,
      "e": 7424,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20719,
      "e": 7597,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "d"
    },
    {
      "t": 21191,
      "e": 8069,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 21192,
      "e": 8070,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21335,
      "e": 8213,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "de"
    },
    {
      "t": 21384,
      "e": 8262,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 21384,
      "e": 8262,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21472,
      "e": 8350,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "det"
    },
    {
      "t": 21536,
      "e": 8414,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 21537,
      "e": 8415,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21624,
      "e": 8502,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 21624,
      "e": 8502,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21679,
      "e": 8557,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "deter"
    },
    {
      "t": 21743,
      "e": 8621,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 21767,
      "e": 8645,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 21767,
      "e": 8645,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21896,
      "e": 8774,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 21944,
      "e": 8822,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 21945,
      "e": 8823,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22039,
      "e": 8917,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 22056,
      "e": 8934,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 22056,
      "e": 8934,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22135,
      "e": 9013,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 22135,
      "e": 9013,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22143,
      "e": 9021,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ne"
    },
    {
      "t": 22215,
      "e": 9093,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 22263,
      "e": 9141,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 22264,
      "e": 9142,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22343,
      "e": 9221,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 22367,
      "e": 9245,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 22367,
      "e": 9245,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22439,
      "e": 9317,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 22439,
      "e": 9317,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22455,
      "e": 9333,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||wh"
    },
    {
      "t": 22519,
      "e": 9397,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 22520,
      "e": 9398,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22543,
      "e": 9421,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 22631,
      "e": 9509,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 22655,
      "e": 9533,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 22656,
      "e": 9534,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22735,
      "e": 9613,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 22735,
      "e": 9613,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22760,
      "e": 9638,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ch"
    },
    {
      "t": 22815,
      "e": 9693,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 22815,
      "e": 9693,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22831,
      "e": 9709,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 22944,
      "e": 9822,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 22983,
      "e": 9861,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 22983,
      "e": 9861,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23056,
      "e": 9934,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 23144,
      "e": 10022,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "86"
    },
    {
      "t": 23145,
      "e": 10023,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23224,
      "e": 10102,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 23225,
      "e": 10103,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23247,
      "e": 10125,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ve"
    },
    {
      "t": 23335,
      "e": 10213,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 23343,
      "e": 10221,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 23343,
      "e": 10221,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23431,
      "e": 10309,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 23472,
      "e": 10350,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 23472,
      "e": 10350,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23552,
      "e": 10430,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 23600,
      "e": 10478,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 23600,
      "e": 10478,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23687,
      "e": 10565,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 28528,
      "e": 15406,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 28529,
      "e": 15407,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28656,
      "e": 15534,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 28663,
      "e": 15541,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 28664,
      "e": 15542,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28743,
      "e": 15621,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 28855,
      "e": 15733,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 28855,
      "e": 15733,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28903,
      "e": 15781,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 28904,
      "e": 15782,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28999,
      "e": 15877,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ar"
    },
    {
      "t": 29008,
      "e": 15886,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 29103,
      "e": 15981,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 29103,
      "e": 15981,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29184,
      "e": 16062,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 29256,
      "e": 16134,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 29257,
      "e": 16135,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29351,
      "e": 16229,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 29367,
      "e": 16245,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 29367,
      "e": 16245,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29455,
      "e": 16333,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 29464,
      "e": 16342,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 29464,
      "e": 16342,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29535,
      "e": 16413,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||w"
    },
    {
      "t": 29575,
      "e": 16453,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 29575,
      "e": 16453,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29639,
      "e": 16517,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 29640,
      "e": 16518,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29671,
      "e": 16549,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||it"
    },
    {
      "t": 29728,
      "e": 16606,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 29847,
      "e": 16725,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 29848,
      "e": 16726,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29879,
      "e": 16757,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 30005,
      "e": 16883,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 30009,
      "e": 16887,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "determine which event starts with"
    },
    {
      "t": 30191,
      "e": 17069,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 30272,
      "e": 17150,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "determine which event starts wit"
    },
    {
      "t": 30359,
      "e": 17237,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 30446,
      "e": 17324,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "determine which event starts wi"
    },
    {
      "t": 30551,
      "e": 17429,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 30615,
      "e": 17493,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "determine which event starts w"
    },
    {
      "t": 30734,
      "e": 17612,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 30895,
      "e": 17773,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "determine which event starts "
    },
    {
      "t": 33464,
      "e": 20342,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 33606,
      "e": 20484,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "determine which event starts"
    },
    {
      "t": 33964,
      "e": 20842,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 33995,
      "e": 20873,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 34028,
      "e": 20906,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 34061,
      "e": 20939,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 34095,
      "e": 20973,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 34127,
      "e": 21005,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 34161,
      "e": 21039,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 34193,
      "e": 21071,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 34227,
      "e": 21105,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 34260,
      "e": 21138,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 34293,
      "e": 21171,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 34325,
      "e": 21203,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 34359,
      "e": 21237,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 34391,
      "e": 21269,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 34424,
      "e": 21302,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 34458,
      "e": 21336,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 34490,
      "e": 21368,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 34523,
      "e": 21401,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 34556,
      "e": 21434,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 34590,
      "e": 21468,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 34622,
      "e": 21500,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 34656,
      "e": 21534,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 34689,
      "e": 21567,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 34722,
      "e": 21600,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 34755,
      "e": 21633,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 34788,
      "e": 21666,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 34821,
      "e": 21699,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 34854,
      "e": 21732,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 34887,
      "e": 21765,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 34920,
      "e": 21798,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 34954,
      "e": 21832,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 34987,
      "e": 21865,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 35019,
      "e": 21897,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 35052,
      "e": 21930,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 35086,
      "e": 21964,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 35118,
      "e": 21996,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 35152,
      "e": 22030,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 35184,
      "e": 22062,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 35217,
      "e": 22095,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 35249,
      "e": 22127,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 35283,
      "e": 22161,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 35311,
      "e": 22189,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": ""
    },
    {
      "t": 37264,
      "e": 24142,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 37264,
      "e": 24142,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37375,
      "e": 24253,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "y"
    },
    {
      "t": 37815,
      "e": 24693,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 37871,
      "e": 24749,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": ""
    },
    {
      "t": 37952,
      "e": 24830,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 38008,
      "e": 24886,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": ""
    },
    {
      "t": 38591,
      "e": 25469,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 38592,
      "e": 25470,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38648,
      "e": 25526,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "l"
    },
    {
      "t": 38839,
      "e": 25717,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 38841,
      "e": 25719,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38935,
      "e": 25813,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "lo"
    },
    {
      "t": 38975,
      "e": 25853,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 38975,
      "e": 25853,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39047,
      "e": 25925,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "loo"
    },
    {
      "t": 39728,
      "e": 26606,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "75"
    },
    {
      "t": 39728,
      "e": 26606,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39791,
      "e": 26669,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look"
    },
    {
      "t": 39879,
      "e": 26757,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 39879,
      "e": 26757,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39968,
      "e": 26846,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 39991,
      "e": 26869,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 39992,
      "e": 26870,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40004,
      "e": 26882,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 40071,
      "e": 26949,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||f"
    },
    {
      "t": 40119,
      "e": 26997,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 40119,
      "e": 26997,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40167,
      "e": 27045,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 40167,
      "e": 27045,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40174,
      "e": 27052,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||or"
    },
    {
      "t": 40263,
      "e": 27141,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 40327,
      "e": 27205,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 40327,
      "e": 27205,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40414,
      "e": 27292,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 40479,
      "e": 27357,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 40480,
      "e": 27358,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40575,
      "e": 27453,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 40616,
      "e": 27494,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "86"
    },
    {
      "t": 40616,
      "e": 27494,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40704,
      "e": 27582,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 40704,
      "e": 27582,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40734,
      "e": 27612,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ve"
    },
    {
      "t": 40807,
      "e": 27685,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 40807,
      "e": 27685,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40822,
      "e": 27700,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 40919,
      "e": 27797,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 41047,
      "e": 27925,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 41048,
      "e": 27926,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41151,
      "e": 28029,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 41303,
      "e": 28181,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 41304,
      "e": 28182,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41367,
      "e": 28245,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 41671,
      "e": 28549,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 41734,
      "e": 28612,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look for event"
    },
    {
      "t": 41775,
      "e": 28653,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 41775,
      "e": 28653,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41830,
      "e": 28708,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 41863,
      "e": 28741,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 41863,
      "e": 28741,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41952,
      "e": 28830,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 41953,
      "e": 28831,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 41953,
      "e": 28831,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42024,
      "e": 28902,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 42055,
      "e": 28933,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 42056,
      "e": 28934,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42118,
      "e": 28996,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 42118,
      "e": 28996,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42134,
      "e": 29012,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ha"
    },
    {
      "t": 42206,
      "e": 29084,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 42207,
      "e": 29085,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42247,
      "e": 29125,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 42311,
      "e": 29189,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 42311,
      "e": 29189,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 42311,
      "e": 29189,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42439,
      "e": 29317,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 42455,
      "e": 29333,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 42456,
      "e": 29334,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42576,
      "e": 29454,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 42576,
      "e": 29454,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42599,
      "e": 29477,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||st"
    },
    {
      "t": 42671,
      "e": 29549,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 42727,
      "e": 29605,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 42727,
      "e": 29605,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42825,
      "e": 29703,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 42826,
      "e": 29704,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42887,
      "e": 29765,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ar"
    },
    {
      "t": 42895,
      "e": 29773,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 43006,
      "e": 29884,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look for events that star"
    },
    {
      "t": 43006,
      "e": 29884,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 43007,
      "e": 29885,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43095,
      "e": 29973,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 43207,
      "e": 30085,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look for events that start"
    },
    {
      "t": 45095,
      "e": 31973,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 45206,
      "e": 32084,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look for events that star"
    },
    {
      "t": 45594,
      "e": 32472,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 45627,
      "e": 32505,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 45660,
      "e": 32538,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 45693,
      "e": 32571,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 45726,
      "e": 32604,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 45759,
      "e": 32637,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 45792,
      "e": 32670,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 45825,
      "e": 32703,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 45858,
      "e": 32736,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 45891,
      "e": 32769,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 45924,
      "e": 32802,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 45958,
      "e": 32836,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 45990,
      "e": 32868,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 46023,
      "e": 32901,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 46056,
      "e": 32934,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 46089,
      "e": 32967,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 46122,
      "e": 33000,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 46155,
      "e": 33033,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 46188,
      "e": 33066,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 46220,
      "e": 33098,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 46254,
      "e": 33132,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 46287,
      "e": 33165,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 46320,
      "e": 33198,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 46353,
      "e": 33231,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 46386,
      "e": 33264,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 46420,
      "e": 33298,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 46452,
      "e": 33330,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 46485,
      "e": 33363,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 46519,
      "e": 33397,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 46552,
      "e": 33430,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 46585,
      "e": 33463,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 46618,
      "e": 33496,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 46651,
      "e": 33529,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 46684,
      "e": 33562,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 46717,
      "e": 33595,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 46749,
      "e": 33627,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 46759,
      "e": 33637,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": ""
    },
    {
      "t": 47655,
      "e": 34533,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 47735,
      "e": 34613,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": ""
    },
    {
      "t": 48016,
      "e": 34894,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 48016,
      "e": 34894,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48087,
      "e": 34965,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "d"
    },
    {
      "t": 48207,
      "e": 35085,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "d"
    },
    {
      "t": 48207,
      "e": 35085,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 48208,
      "e": 35086,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48264,
      "e": 35142,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "de"
    },
    {
      "t": 48407,
      "e": 35285,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "de"
    },
    {
      "t": 48440,
      "e": 35318,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 48441,
      "e": 35319,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48567,
      "e": 35319,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "det"
    },
    {
      "t": 48631,
      "e": 35383,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 48631,
      "e": 35383,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48728,
      "e": 35480,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 48728,
      "e": 35480,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48767,
      "e": 35519,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "deter"
    },
    {
      "t": 48831,
      "e": 35583,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 48935,
      "e": 35687,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 48935,
      "e": 35687,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48983,
      "e": 35735,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 49287,
      "e": 36039,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 49352,
      "e": 36104,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "deter"
    },
    {
      "t": 49519,
      "e": 36271,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 49520,
      "e": 36272,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49583,
      "e": 36335,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 49615,
      "e": 36367,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 49615,
      "e": 36367,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49678,
      "e": 36430,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 49751,
      "e": 36503,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 49752,
      "e": 36504,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49855,
      "e": 36607,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 49878,
      "e": 36630,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 49878,
      "e": 36630,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49950,
      "e": 36702,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 49974,
      "e": 36726,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 49975,
      "e": 36727,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50038,
      "e": 36790,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 50038,
      "e": 36790,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50063,
      "e": 36815,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| w"
    },
    {
      "t": 50119,
      "e": 36871,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 50135,
      "e": 36887,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 50135,
      "e": 36887,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50222,
      "e": 36974,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 50222,
      "e": 36974,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 50222,
      "e": 36974,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50318,
      "e": 37070,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 50318,
      "e": 37070,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50343,
      "e": 37095,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||er"
    },
    {
      "t": 50431,
      "e": 37183,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 50432,
      "e": 37184,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50462,
      "e": 37214,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 50478,
      "e": 37230,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 50478,
      "e": 37230,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50519,
      "e": 37271,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 50599,
      "e": 37351,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 50688,
      "e": 37440,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 50688,
      "e": 37440,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50806,
      "e": 37558,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "determine where 1"
    },
    {
      "t": 50806,
      "e": 37558,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 50807,
      "e": 37559,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50878,
      "e": 37630,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||12"
    },
    {
      "t": 50943,
      "e": 37695,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 51103,
      "e": 37855,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 51103,
      "e": 37855,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51199,
      "e": 37951,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 51296,
      "e": 38048,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 51296,
      "e": 38048,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51374,
      "e": 38126,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 51382,
      "e": 38134,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 51383,
      "e": 38135,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51462,
      "e": 38214,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 51463,
      "e": 38215,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51494,
      "e": 38246,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| i"
    },
    {
      "t": 51566,
      "e": 38318,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 51582,
      "e": 38334,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 51583,
      "e": 38335,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51654,
      "e": 38406,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 51679,
      "e": 38431,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 51680,
      "e": 38432,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51799,
      "e": 38551,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 51799,
      "e": 38551,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51806,
      "e": 38558,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| o"
    },
    {
      "t": 51871,
      "e": 38623,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 51919,
      "e": 38671,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 51920,
      "e": 38672,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52008,
      "e": 38760,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 52009,
      "e": 38761,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52070,
      "e": 38822,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n "
    },
    {
      "t": 52150,
      "e": 38902,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 52151,
      "e": 38903,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52166,
      "e": 38918,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 52247,
      "e": 38999,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 52263,
      "e": 39015,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 52264,
      "e": 39016,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52350,
      "e": 39102,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 52358,
      "e": 39110,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 52358,
      "e": 39110,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52446,
      "e": 39198,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 52455,
      "e": 39207,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 52455,
      "e": 39207,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52544,
      "e": 39296,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 52551,
      "e": 39303,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 52551,
      "e": 39303,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52662,
      "e": 39414,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||c"
    },
    {
      "t": 52686,
      "e": 39438,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 52686,
      "e": 39438,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52751,
      "e": 39503,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 52775,
      "e": 39527,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 52776,
      "e": 39528,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52878,
      "e": 39630,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 52879,
      "e": 39631,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 52879,
      "e": 39631,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52934,
      "e": 39686,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 53031,
      "e": 39783,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 53032,
      "e": 39784,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53111,
      "e": 39863,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 53415,
      "e": 40167,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "188"
    },
    {
      "t": 53416,
      "e": 40168,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53510,
      "e": 40262,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||,"
    },
    {
      "t": 53575,
      "e": 40327,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 53575,
      "e": 40327,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53622,
      "e": 40374,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 53767,
      "e": 40519,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 53768,
      "e": 40520,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53870,
      "e": 40622,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 53886,
      "e": 40638,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 53886,
      "e": 40638,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53958,
      "e": 40710,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 53975,
      "e": 40727,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 53976,
      "e": 40728,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54054,
      "e": 40806,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 54103,
      "e": 40855,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 54103,
      "e": 40855,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54182,
      "e": 40934,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 55367,
      "e": 42119,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 55368,
      "e": 42120,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 55430,
      "e": 42182,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 55543,
      "e": 42295,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 55543,
      "e": 42295,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 55656,
      "e": 42296,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 55678,
      "e": 42318,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 55678,
      "e": 42318,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 55791,
      "e": 42431,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 55847,
      "e": 42487,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "86"
    },
    {
      "t": 55847,
      "e": 42487,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 55934,
      "e": 42574,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 55934,
      "e": 42574,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 55966,
      "e": 42606,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ve"
    },
    {
      "t": 56054,
      "e": 42694,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 56070,
      "e": 42710,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 56070,
      "e": 42710,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56167,
      "e": 42807,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 56295,
      "e": 42935,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 56296,
      "e": 42936,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56382,
      "e": 43022,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 57151,
      "e": 43791,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 57152,
      "e": 43792,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 57262,
      "e": 43902,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||u"
    },
    {
      "t": 57270,
      "e": 43910,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 57271,
      "e": 43911,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 57366,
      "e": 44006,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 58127,
      "e": 44767,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 58198,
      "e": 44838,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "determine where 12pm is on the chart, and travel u"
    },
    {
      "t": 58302,
      "e": 44942,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 58343,
      "e": 44983,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "determine where 12pm is on the chart, and travel "
    },
    {
      "t": 58559,
      "e": 45199,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 58560,
      "e": 45200,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 58679,
      "e": 45319,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||u"
    },
    {
      "t": 58687,
      "e": 45327,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 58688,
      "e": 45328,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 58790,
      "e": 45430,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 58798,
      "e": 45438,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 58798,
      "e": 45438,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 58918,
      "e": 45558,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 58927,
      "e": 45567,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 58927,
      "e": 45567,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 59015,
      "e": 45655,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 59078,
      "e": 45718,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 59078,
      "e": 45718,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 59135,
      "e": 45775,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 59135,
      "e": 45775,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 59182,
      "e": 45822,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n "
    },
    {
      "t": 59230,
      "e": 45870,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 59270,
      "e": 45910,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 59271,
      "e": 45911,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 59359,
      "e": 45999,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 59367,
      "e": 46007,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 59367,
      "e": 46007,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 59446,
      "e": 46086,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 59455,
      "e": 46095,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 59455,
      "e": 46095,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 59574,
      "e": 46214,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 59574,
      "e": 46214,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 59590,
      "e": 46230,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||hi"
    },
    {
      "t": 59647,
      "e": 46287,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 60166,
      "e": 46806,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 60214,
      "e": 46854,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "determine where 12pm is on the chart, and travel up on a h"
    },
    {
      "t": 60366,
      "e": 47006,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 60367,
      "e": 47007,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 60438,
      "e": 47078,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 60984,
      "e": 47624,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 60984,
      "e": 47624,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 61038,
      "e": 47678,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 61199,
      "e": 47839,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "90"
    },
    {
      "t": 61200,
      "e": 47840,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 61270,
      "e": 47910,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||z"
    },
    {
      "t": 61551,
      "e": 48191,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 61607,
      "e": 48247,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "determine where 12pm is on the chart, and travel up on a hor"
    },
    {
      "t": 61750,
      "e": 48390,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 61751,
      "e": 48391,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 61815,
      "e": 48455,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 61887,
      "e": 48527,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "90"
    },
    {
      "t": 61888,
      "e": 48528,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 61999,
      "e": 48639,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||z"
    },
    {
      "t": 62103,
      "e": 48743,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 62104,
      "e": 48744,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 62150,
      "e": 48790,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 62262,
      "e": 48902,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 62262,
      "e": 48902,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 62327,
      "e": 48967,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 62687,
      "e": 49327,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 62687,
      "e": 49327,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 62775,
      "e": 49415,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 62811,
      "e": 49451,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 62811,
      "e": 49451,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 62898,
      "e": 49538,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 62971,
      "e": 49611,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 62971,
      "e": 49611,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 63059,
      "e": 49699,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 63578,
      "e": 50218,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "190"
    },
    {
      "t": 63579,
      "e": 50219,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 63699,
      "e": 50339,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||."
    },
    {
      "t": 63706,
      "e": 50346,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 63707,
      "e": 50347,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 63802,
      "e": 50442,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 64082,
      "e": 50722,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 64082,
      "e": 50722,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 64170,
      "e": 50810,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 64299,
      "e": 50939,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "86"
    },
    {
      "t": 64299,
      "e": 50939,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 64354,
      "e": 50994,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||v"
    },
    {
      "t": 64491,
      "e": 50995,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 64492,
      "e": 50996,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 64609,
      "e": 51113,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "determine where 12pm is on the chart, and travel up on a horizontal. eve"
    },
    {
      "t": 64618,
      "e": 51122,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 64618,
      "e": 51122,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 64642,
      "e": 51146,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||er"
    },
    {
      "t": 64699,
      "e": 51203,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 64811,
      "e": 51315,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "determine where 12pm is on the chart, and travel up on a horizontal. ever"
    },
    {
      "t": 64827,
      "e": 51331,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 64827,
      "e": 51331,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 64898,
      "e": 51402,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||y"
    },
    {
      "t": 65010,
      "e": 51514,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "determine where 12pm is on the chart, and travel up on a horizontal. every"
    },
    {
      "t": 66066,
      "e": 52570,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 66130,
      "e": 52634,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "determine where 12pm is on the chart, and travel up on a horizontal. ever"
    },
    {
      "t": 66250,
      "e": 52754,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 66298,
      "e": 52802,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "determine where 12pm is on the chart, and travel up on a horizontal. eve"
    },
    {
      "t": 66410,
      "e": 52914,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "determine where 12pm is on the chart, and travel up on a horizontal. eve"
    },
    {
      "t": 66426,
      "e": 52930,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 66474,
      "e": 52978,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "determine where 12pm is on the chart, and travel up on a horizontal. ev"
    },
    {
      "t": 66587,
      "e": 53091,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 66659,
      "e": 53163,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "determine where 12pm is on the chart, and travel up on a horizontal. e"
    },
    {
      "t": 66699,
      "e": 53203,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 66802,
      "e": 53306,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "determine where 12pm is on the chart, and travel up on a horizontal. "
    },
    {
      "t": 67042,
      "e": 53546,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 67043,
      "e": 53547,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 67122,
      "e": 53626,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 67178,
      "e": 53682,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "86"
    },
    {
      "t": 67179,
      "e": 53683,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 67346,
      "e": 53850,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||v"
    },
    {
      "t": 67523,
      "e": 54027,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 67524,
      "e": 54028,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 67610,
      "e": 54114,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 67610,
      "e": 54114,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 67658,
      "e": 54162,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||er"
    },
    {
      "t": 67714,
      "e": 54218,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 67851,
      "e": 54355,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 67852,
      "e": 54356,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 67921,
      "e": 54425,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||y"
    },
    {
      "t": 68002,
      "e": 54506,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 68003,
      "e": 54507,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 68097,
      "e": 54601,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 68299,
      "e": 54803,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 68299,
      "e": 54803,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 68378,
      "e": 54882,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 68386,
      "e": 54890,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 68386,
      "e": 54890,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 68458,
      "e": 54962,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 68531,
      "e": 55035,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 68532,
      "e": 55035,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 68586,
      "e": 55089,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 68594,
      "e": 55097,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 68594,
      "e": 55097,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 68682,
      "e": 55185,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 68722,
      "e": 55225,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 68723,
      "e": 55226,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 68810,
      "e": 55313,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 68825,
      "e": 55328,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 68826,
      "e": 55329,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 68882,
      "e": 55385,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 68890,
      "e": 55393,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 68890,
      "e": 55393,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 68986,
      "e": 55489,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 68986,
      "e": 55489,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 69042,
      "e": 55545,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||at"
    },
    {
      "t": 69090,
      "e": 55593,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 69139,
      "e": 55642,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 69139,
      "e": 55642,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 69226,
      "e": 55729,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 69290,
      "e": 55793,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 69290,
      "e": 55793,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 69362,
      "e": 55865,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 69419,
      "e": 55922,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 69419,
      "e": 55922,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 69538,
      "e": 56041,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 69539,
      "e": 56042,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 69540,
      "e": 56043,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 69610,
      "e": 56113,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 69666,
      "e": 56169,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 69666,
      "e": 56169,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 69738,
      "e": 56241,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 69806,
      "e": 56309,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 69806,
      "e": 56309,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 69890,
      "e": 56393,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 69890,
      "e": 56393,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 69914,
      "e": 56417,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n "
    },
    {
      "t": 70017,
      "e": 56520,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 70187,
      "e": 56690,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 70188,
      "e": 56691,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 70282,
      "e": 56785,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 70346,
      "e": 56849,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 70347,
      "e": 56850,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 70434,
      "e": 56937,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 70490,
      "e": 56993,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 70490,
      "e": 56993,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 70594,
      "e": 57097,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 70595,
      "e": 57098,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 70610,
      "e": 57113,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||at"
    },
    {
      "t": 70699,
      "e": 57202,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 70723,
      "e": 57226,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 70724,
      "e": 57227,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 70810,
      "e": 57313,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 70938,
      "e": 57441,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "86"
    },
    {
      "t": 70939,
      "e": 57442,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 71025,
      "e": 57528,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||v"
    },
    {
      "t": 71107,
      "e": 57610,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 71107,
      "e": 57610,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 71211,
      "e": 57714,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "determine where 12pm is on the chart, and travel up on a horizontal. every dot that is on that ve"
    },
    {
      "t": 71218,
      "e": 57721,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 71307,
      "e": 57810,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 71307,
      "e": 57810,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 71370,
      "e": 57873,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 71715,
      "e": 58218,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 71793,
      "e": 58296,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 71794,
      "e": 58297,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 71802,
      "e": 58305,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "determine where 12pm is on the chart, and travel up on a horizontal. every dot that is on that ver"
    },
    {
      "t": 71876,
      "e": 58379,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 71954,
      "e": 58457,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 71954,
      "e": 58457,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 72025,
      "e": 58528,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 72033,
      "e": 58536,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 72034,
      "e": 58537,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 72106,
      "e": 58609,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 72194,
      "e": 58697,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 72195,
      "e": 58698,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 72322,
      "e": 58825,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 72323,
      "e": 58826,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 72330,
      "e": 58833,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ca"
    },
    {
      "t": 72410,
      "e": 58913,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 72426,
      "e": 58929,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 72426,
      "e": 58929,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 72530,
      "e": 59033,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 72539,
      "e": 59042,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 72540,
      "e": 59043,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 72666,
      "e": 59169,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 72690,
      "e": 59193,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 72691,
      "e": 59194,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 72769,
      "e": 59272,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 72770,
      "e": 59273,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 72810,
      "e": 59313,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||li"
    },
    {
      "t": 72858,
      "e": 59361,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 72946,
      "e": 59449,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 72947,
      "e": 59450,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 73010,
      "e": 59513,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 73010,
      "e": 59513,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 73010,
      "e": 59513,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 73130,
      "e": 59633,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 73146,
      "e": 59649,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 73147,
      "e": 59650,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 73234,
      "e": 59737,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 73235,
      "e": 59738,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 73242,
      "e": 59745,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| i"
    },
    {
      "t": 73329,
      "e": 59832,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 73361,
      "e": 59864,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 73362,
      "e": 59865,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 73458,
      "e": 59961,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 73483,
      "e": 59962,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 73484,
      "e": 59963,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 73569,
      "e": 60048,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 73834,
      "e": 60313,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 73923,
      "e": 60402,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "determine where 12pm is on the chart, and travel up on a horizontal. every dot that is on that vertical line is"
    },
    {
      "t": 74025,
      "e": 60504,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 74081,
      "e": 60560,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "determine where 12pm is on the chart, and travel up on a horizontal. every dot that is on that vertical line i"
    },
    {
      "t": 74186,
      "e": 60665,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 74250,
      "e": 60729,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "determine where 12pm is on the chart, and travel up on a horizontal. every dot that is on that vertical line "
    },
    {
      "t": 74394,
      "e": 60873,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 74410,
      "e": 60889,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "determine where 12pm is on the chart, and travel up on a horizontal. every dot that is on that vertical line"
    },
    {
      "t": 74594,
      "e": 61073,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 74595,
      "e": 61074,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 74698,
      "e": 61177,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 74700,
      "e": 61179,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 74729,
      "e": 61208,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||st"
    },
    {
      "t": 74802,
      "e": 61281,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 75138,
      "e": 61617,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 75210,
      "e": 61689,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "determine where 12pm is on the chart, and travel up on a horizontal. every dot that is on that vertical lines"
    },
    {
      "t": 75306,
      "e": 61785,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 75354,
      "e": 61833,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "determine where 12pm is on the chart, and travel up on a horizontal. every dot that is on that vertical line"
    },
    {
      "t": 75451,
      "e": 61930,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 75451,
      "e": 61930,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 75513,
      "e": 61992,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 75514,
      "e": 61993,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 75538,
      "e": 62017,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| r"
    },
    {
      "t": 75626,
      "e": 62105,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 75626,
      "e": 62105,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 75674,
      "e": 62153,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 75730,
      "e": 62209,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 75731,
      "e": 62210,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 75753,
      "e": 62232,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 75826,
      "e": 62305,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 75826,
      "e": 62305,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 75834,
      "e": 62313,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 75922,
      "e": 62401,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 75922,
      "e": 62401,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 75978,
      "e": 62457,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 76026,
      "e": 62505,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 76026,
      "e": 62505,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 76058,
      "e": 62537,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 76146,
      "e": 62625,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 76147,
      "e": 62626,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 76194,
      "e": 62673,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 76273,
      "e": 62752,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 76306,
      "e": 62785,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 76306,
      "e": 62785,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 76362,
      "e": 62785,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 77338,
      "e": 63761,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 77339,
      "e": 63762,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 77410,
      "e": 63833,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 77514,
      "e": 63937,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 77514,
      "e": 63937,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 77585,
      "e": 64008,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 77714,
      "e": 64137,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 77715,
      "e": 64138,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 77762,
      "e": 64185,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 77785,
      "e": 64208,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 77786,
      "e": 64209,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 77857,
      "e": 64280,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 78012,
      "e": 64435,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 78013,
      "e": 64436,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 78130,
      "e": 64553,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 78322,
      "e": 64745,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 78323,
      "e": 64746,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 78458,
      "e": 64881,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 78682,
      "e": 65105,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 78753,
      "e": 65176,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "determine where 12pm is on the chart, and travel up on a horizontal. every dot that is on that vertical line represents  a"
    },
    {
      "t": 78842,
      "e": 65265,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 78914,
      "e": 65337,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "determine where 12pm is on the chart, and travel up on a horizontal. every dot that is on that vertical line represents  "
    },
    {
      "t": 79019,
      "e": 65442,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 79081,
      "e": 65504,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "determine where 12pm is on the chart, and travel up on a horizontal. every dot that is on that vertical line represents "
    },
    {
      "t": 79146,
      "e": 65569,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 79146,
      "e": 65569,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 79225,
      "e": 65648,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 79282,
      "e": 65705,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 79282,
      "e": 65705,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 79411,
      "e": 65834,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "determine where 12pm is on the chart, and travel up on a horizontal. every dot that is on that vertical line represents an"
    },
    {
      "t": 79412,
      "e": 65835,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 79425,
      "e": 65848,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 79425,
      "e": 65848,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 79434,
      "e": 65857,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 79434,
      "e": 65857,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 79522,
      "e": 65945,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| e"
    },
    {
      "t": 79570,
      "e": 65993,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 79635,
      "e": 66058,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "86"
    },
    {
      "t": 79636,
      "e": 66059,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 79738,
      "e": 66161,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 79738,
      "e": 66161,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 79753,
      "e": 66176,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ve"
    },
    {
      "t": 79818,
      "e": 66241,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 79818,
      "e": 66241,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 79834,
      "e": 66257,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 79890,
      "e": 66313,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 80012,
      "e": 66435,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "determine where 12pm is on the chart, and travel up on a horizontal. every dot that is on that vertical line represents an even"
    },
    {
      "t": 80013,
      "e": 66436,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 80013,
      "e": 66436,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 80074,
      "e": 66497,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 80115,
      "e": 66498,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 80117,
      "e": 66500,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 80217,
      "e": 66600,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 80274,
      "e": 66657,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 80274,
      "e": 66657,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 80354,
      "e": 66737,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 80362,
      "e": 66745,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 80363,
      "e": 66746,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 80441,
      "e": 66824,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 80441,
      "e": 66824,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 80458,
      "e": 66841,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ha"
    },
    {
      "t": 80530,
      "e": 66913,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 80530,
      "e": 66913,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 80537,
      "e": 66920,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 80642,
      "e": 67025,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 80650,
      "e": 67033,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 80651,
      "e": 67034,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 80738,
      "e": 67121,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 80882,
      "e": 67265,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 80883,
      "e": 67266,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 80954,
      "e": 67337,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 81042,
      "e": 67425,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 81042,
      "e": 67425,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 81106,
      "e": 67489,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 81179,
      "e": 67562,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 81179,
      "e": 67562,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 81322,
      "e": 67705,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 81411,
      "e": 67794,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 81412,
      "e": 67795,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 81490,
      "e": 67873,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 81570,
      "e": 67953,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 81570,
      "e": 67953,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 81650,
      "e": 68033,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 81690,
      "e": 68073,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 81691,
      "e": 68074,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 81785,
      "e": 68168,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 81785,
      "e": 68168,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 81785,
      "e": 68168,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 81865,
      "e": 68248,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 81866,
      "e": 68249,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 81906,
      "e": 68289,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||at"
    },
    {
      "t": 81978,
      "e": 68361,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 82042,
      "e": 68425,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 82043,
      "e": 68426,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 82114,
      "e": 68497,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 82651,
      "e": 69034,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 82722,
      "e": 69105,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "determine where 12pm is on the chart, and travel up on a horizontal. every dot that is on that vertical line represents an event that stats at"
    },
    {
      "t": 82826,
      "e": 69209,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 82891,
      "e": 69274,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "determine where 12pm is on the chart, and travel up on a horizontal. every dot that is on that vertical line represents an event that stats a"
    },
    {
      "t": 82986,
      "e": 69369,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 83057,
      "e": 69440,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "determine where 12pm is on the chart, and travel up on a horizontal. every dot that is on that vertical line represents an event that stats "
    },
    {
      "t": 83153,
      "e": 69536,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 83218,
      "e": 69601,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "determine where 12pm is on the chart, and travel up on a horizontal. every dot that is on that vertical line represents an event that stats"
    },
    {
      "t": 83339,
      "e": 69722,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 83402,
      "e": 69723,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "determine where 12pm is on the chart, and travel up on a horizontal. every dot that is on that vertical line represents an event that stat"
    },
    {
      "t": 83506,
      "e": 69827,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 83602,
      "e": 69923,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "determine where 12pm is on the chart, and travel up on a horizontal. every dot that is on that vertical line represents an event that sta"
    },
    {
      "t": 83618,
      "e": 69939,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 83619,
      "e": 69940,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 83666,
      "e": 69987,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 83769,
      "e": 70090,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 83770,
      "e": 70091,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 83850,
      "e": 70171,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 83907,
      "e": 70228,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 83907,
      "e": 70228,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 83993,
      "e": 70314,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 83994,
      "e": 70315,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 84009,
      "e": 70330,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s "
    },
    {
      "t": 84082,
      "e": 70403,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 84106,
      "e": 70427,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 84106,
      "e": 70427,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 84153,
      "e": 70474,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 84153,
      "e": 70474,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 84186,
      "e": 70507,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||at"
    },
    {
      "t": 84250,
      "e": 70571,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 84282,
      "e": 70603,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 84283,
      "e": 70604,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 84353,
      "e": 70674,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 84354,
      "e": 70675,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 84370,
      "e": 70691,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| 1"
    },
    {
      "t": 84482,
      "e": 70803,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 84482,
      "e": 70803,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 84539,
      "e": 70860,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||2"
    },
    {
      "t": 84626,
      "e": 70947,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 84746,
      "e": 71067,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 84747,
      "e": 71068,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 84842,
      "e": 71163,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 84938,
      "e": 71259,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 84938,
      "e": 71259,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 85018,
      "e": 71339,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 85227,
      "e": 71548,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "190"
    },
    {
      "t": 85233,
      "e": 71554,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 85361,
      "e": 71682,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||."
    },
    {
      "t": 86131,
      "e": 72452,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "38"
    },
    {
      "t": 86265,
      "e": 72586,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 86338,
      "e": 72659,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "37"
    },
    {
      "t": 86546,
      "e": 72867,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 86682,
      "e": 73003,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "37"
    },
    {
      "t": 86785,
      "e": 73106,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 86898,
      "e": 73219,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "37"
    },
    {
      "t": 86985,
      "e": 73306,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 87459,
      "e": 73780,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 87611,
      "e": 73932,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "determine where 12pm is on the chart, and travel up on a horizonta. every dot that is on that vertical line represents an event that starts at 12pm."
    },
    {
      "t": 87958,
      "e": 74279,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 87990,
      "e": 74311,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 88024,
      "e": 74345,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 88056,
      "e": 74377,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 88089,
      "e": 74410,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 88122,
      "e": 74443,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 88129,
      "e": 74450,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "determine where 12pm is on the chart, and travel up on a hor. every dot that is on that vertical line represents an event that starts at 12pm."
    },
    {
      "t": 88250,
      "e": 74571,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 88322,
      "e": 74572,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "determine where 12pm is on the chart, and travel up on a ho. every dot that is on that vertical line represents an event that starts at 12pm."
    },
    {
      "t": 88665,
      "e": 74915,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 88714,
      "e": 74964,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "determine where 12pm is on the chart, and travel up on a h. every dot that is on that vertical line represents an event that starts at 12pm."
    },
    {
      "t": 88954,
      "e": 75204,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 89009,
      "e": 75259,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "determine where 12pm is on the chart, and travel up on a . every dot that is on that vertical line represents an event that starts at 12pm."
    },
    {
      "t": 89073,
      "e": 75323,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "86"
    },
    {
      "t": 89074,
      "e": 75324,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 89137,
      "e": 75387,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "determine where 12pm is on the chart, and travel up on a v. every dot that is on that vertical line represents an event that starts at 12pm."
    },
    {
      "t": 89234,
      "e": 75484,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 89234,
      "e": 75484,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 89297,
      "e": 75547,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 89298,
      "e": 75548,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 89329,
      "e": 75579,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "determine where 12pm is on the chart, and travel up on a ver. every dot that is on that vertical line represents an event that starts at 12pm."
    },
    {
      "t": 89353,
      "e": 75603,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 89449,
      "e": 75699,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 89450,
      "e": 75700,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 89530,
      "e": 75780,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 89531,
      "e": 75781,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 89538,
      "e": 75788,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "determine where 12pm is on the chart, and travel up on a verti. every dot that is on that vertical line represents an event that starts at 12pm."
    },
    {
      "t": 89618,
      "e": 75868,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 89721,
      "e": 75971,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 89722,
      "e": 75972,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 89810,
      "e": 76060,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 89810,
      "e": 76060,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 89826,
      "e": 76060,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "determine where 12pm is on the chart, and travel up on a vertica. every dot that is on that vertical line represents an event that starts at 12pm."
    },
    {
      "t": 89889,
      "e": 76123,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 89929,
      "e": 76163,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 89929,
      "e": 76163,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 90011,
      "e": 76245,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "determine where 12pm is on the chart, and travel up on a vertical. every dot that is on that vertical line represents an event that starts at 12pm."
    },
    {
      "t": 90026,
      "e": 76260,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 90026,
      "e": 76260,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 90153,
      "e": 76387,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 90154,
      "e": 76388,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 90169,
      "e": 76403,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "determine where 12pm is on the chart, and travel up on a vertical l. every dot that is on that vertical line represents an event that starts at 12pm."
    },
    {
      "t": 90233,
      "e": 76467,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 90234,
      "e": 76468,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 90281,
      "e": 76515,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "determine where 12pm is on the chart, and travel up on a vertical li. every dot that is on that vertical line represents an event that starts at 12pm."
    },
    {
      "t": 90322,
      "e": 76556,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 90394,
      "e": 76628,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 90395,
      "e": 76629,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 90481,
      "e": 76715,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "determine where 12pm is on the chart, and travel up on a vertical lin. every dot that is on that vertical line represents an event that starts at 12pm."
    },
    {
      "t": 90513,
      "e": 76747,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 90513,
      "e": 76747,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 90562,
      "e": 76748,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "determine where 12pm is on the chart, and travel up on a vertical line. every dot that is on that vertical line represents an event that starts at 12pm."
    },
    {
      "t": 91447,
      "e": 77633,
      "ty": 7,
      "x": 483,
      "y": 604,
      "ta": "#strategyAnswer"
    },
    {
      "t": 91496,
      "e": 77682,
      "ty": 6,
      "x": 451,
      "y": 662,
      "ta": "#strategyButton"
    },
    {
      "t": 91509,
      "e": 77695,
      "ty": 2,
      "x": 451,
      "y": 662
    },
    {
      "t": 91509,
      "e": 77695,
      "ty": 41,
      "x": 61387,
      "y": 14004,
      "ta": "#strategyButton"
    },
    {
      "t": 91579,
      "e": 77765,
      "ty": 7,
      "x": 414,
      "y": 694,
      "ta": "#strategyButton"
    },
    {
      "t": 91608,
      "e": 77794,
      "ty": 2,
      "x": 403,
      "y": 704
    },
    {
      "t": 91709,
      "e": 77895,
      "ty": 2,
      "x": 384,
      "y": 700
    },
    {
      "t": 91714,
      "e": 77900,
      "ty": 6,
      "x": 378,
      "y": 688,
      "ta": "#strategyButton"
    },
    {
      "t": 91759,
      "e": 77945,
      "ty": 41,
      "x": 18243,
      "y": 35206,
      "ta": "#strategyButton"
    },
    {
      "t": 91809,
      "e": 77995,
      "ty": 2,
      "x": 372,
      "y": 671
    },
    {
      "t": 91911,
      "e": 78097,
      "ty": 3,
      "x": 372,
      "y": 671,
      "ta": "#strategyButton"
    },
    {
      "t": 91913,
      "e": 78099,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "determine where 12pm is on the chart, and travel up on a vertical line. every dot that is on that vertical line represents an event that starts at 12pm."
    },
    {
      "t": 91913,
      "e": 78099,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 91914,
      "e": 78100,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 91982,
      "e": 78168,
      "ty": 4,
      "x": 18243,
      "y": 31351,
      "ta": "#strategyButton"
    },
    {
      "t": 91991,
      "e": 78177,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 91993,
      "e": 78179,
      "ty": 5,
      "x": 372,
      "y": 671,
      "ta": "#strategyButton"
    },
    {
      "t": 91998,
      "e": 78184,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 92009,
      "e": 78195,
      "ty": 41,
      "x": 12535,
      "y": 36728,
      "ta": "html > body"
    },
    {
      "t": 93000,
      "e": 79186,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 93708,
      "e": 79894,
      "ty": 2,
      "x": 485,
      "y": 613
    },
    {
      "t": 93759,
      "e": 79945,
      "ty": 41,
      "x": 16654,
      "y": 41575,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 93809,
      "e": 79995,
      "ty": 2,
      "x": 1294,
      "y": 537
    },
    {
      "t": 93909,
      "e": 80095,
      "ty": 2,
      "x": 1368,
      "y": 537
    },
    {
      "t": 94009,
      "e": 80195,
      "ty": 2,
      "x": 1197,
      "y": 565
    },
    {
      "t": 94009,
      "e": 80195,
      "ty": 41,
      "x": 40946,
      "y": 30856,
      "ta": "html > body"
    },
    {
      "t": 94109,
      "e": 80295,
      "ty": 2,
      "x": 1079,
      "y": 576
    },
    {
      "t": 94149,
      "e": 80335,
      "ty": 6,
      "x": 1060,
      "y": 572,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 94208,
      "e": 80394,
      "ty": 2,
      "x": 1055,
      "y": 569
    },
    {
      "t": 94259,
      "e": 80445,
      "ty": 41,
      "x": 52990,
      "y": 37448,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 94309,
      "e": 80495,
      "ty": 2,
      "x": 1053,
      "y": 566
    },
    {
      "t": 94327,
      "e": 80513,
      "ty": 3,
      "x": 1053,
      "y": 566,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 94327,
      "e": 80513,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 94389,
      "e": 80575,
      "ty": 4,
      "x": 52990,
      "y": 37448,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 94390,
      "e": 80576,
      "ty": 5,
      "x": 1053,
      "y": 566,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 95122,
      "e": 81308,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "49"
    },
    {
      "t": 95123,
      "e": 81309,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 95217,
      "e": 81403,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "1"
    },
    {
      "t": 95330,
      "e": 81516,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "57"
    },
    {
      "t": 95331,
      "e": 81517,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 95409,
      "e": 81595,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "19"
    },
    {
      "t": 95554,
      "e": 81740,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "9"
    },
    {
      "t": 95555,
      "e": 81741,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "19"
    },
    {
      "t": 95556,
      "e": 81742,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 95557,
      "e": 81743,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 95617,
      "e": 81803,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": ""
    },
    {
      "t": 96338,
      "e": 82524,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 96837,
      "e": 83023,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 96870,
      "e": 83056,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 96903,
      "e": 83089,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 96936,
      "e": 83122,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 96969,
      "e": 83155,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 97002,
      "e": 83188,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 97034,
      "e": 83220,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "85"
    },
    {
      "t": 97034,
      "e": 83220,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 97121,
      "e": 83307,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "U"
    },
    {
      "t": 97138,
      "e": 83324,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "U"
    },
    {
      "t": 97242,
      "e": 83428,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "78"
    },
    {
      "t": 97242,
      "e": 83428,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 97338,
      "e": 83524,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "73"
    },
    {
      "t": 97339,
      "e": 83525,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 97354,
      "e": 83540,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Uni"
    },
    {
      "t": 97441,
      "e": 83627,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Uni"
    },
    {
      "t": 97441,
      "e": 83627,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "84"
    },
    {
      "t": 97441,
      "e": 83627,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 97513,
      "e": 83699,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "69"
    },
    {
      "t": 97514,
      "e": 83700,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 97578,
      "e": 83764,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Unite"
    },
    {
      "t": 97610,
      "e": 83796,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 97826,
      "e": 84012,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "8"
    },
    {
      "t": 97873,
      "e": 84059,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Unit"
    },
    {
      "t": 97969,
      "e": 84155,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "8"
    },
    {
      "t": 98033,
      "e": 84219,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Uni"
    },
    {
      "t": 98129,
      "e": 84315,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "8"
    },
    {
      "t": 98186,
      "e": 84372,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Un"
    },
    {
      "t": 98370,
      "e": 84556,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 98562,
      "e": 84748,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Un"
    },
    {
      "t": 98594,
      "e": 84780,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "8"
    },
    {
      "t": 98642,
      "e": 84828,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "U"
    },
    {
      "t": 98674,
      "e": 84860,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 98762,
      "e": 84948,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "83"
    },
    {
      "t": 98762,
      "e": 84948,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 98801,
      "e": 84987,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "US"
    },
    {
      "t": 98865,
      "e": 84987,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "US"
    },
    {
      "t": 99026,
      "e": 85148,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "13"
    },
    {
      "t": 99027,
      "e": 85149,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 99074,
      "e": 85196,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "US\n"
    },
    {
      "t": 99210,
      "e": 85332,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "US\n"
    },
    {
      "t": 99786,
      "e": 85908,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "8"
    },
    {
      "t": 99817,
      "e": 85939,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "US"
    },
    {
      "t": 100703,
      "e": 86825,
      "ty": 7,
      "x": 1049,
      "y": 585,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 100708,
      "e": 86830,
      "ty": 2,
      "x": 1049,
      "y": 585
    },
    {
      "t": 100758,
      "e": 86880,
      "ty": 41,
      "x": 49962,
      "y": 11702,
      "ta": "#jspsych-survey-text-1 > p"
    },
    {
      "t": 100808,
      "e": 86930,
      "ty": 2,
      "x": 1030,
      "y": 624
    },
    {
      "t": 100904,
      "e": 87026,
      "ty": 6,
      "x": 1013,
      "y": 648,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 100907,
      "e": 87029,
      "ty": 2,
      "x": 1013,
      "y": 648
    },
    {
      "t": 101009,
      "e": 87131,
      "ty": 41,
      "x": 44338,
      "y": 3120,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 101259,
      "e": 87381,
      "ty": 41,
      "x": 44122,
      "y": 3120,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 101308,
      "e": 87430,
      "ty": 2,
      "x": 1012,
      "y": 648
    },
    {
      "t": 101545,
      "e": 87667,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "8"
    },
    {
      "t": 101617,
      "e": 87739,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "U"
    },
    {
      "t": 101954,
      "e": 88076,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 102042,
      "e": 88164,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "78"
    },
    {
      "t": 102043,
      "e": 88165,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 102170,
      "e": 88292,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "UN"
    },
    {
      "t": 102177,
      "e": 88299,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "UN"
    },
    {
      "t": 102177,
      "e": 88299,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "73"
    },
    {
      "t": 102177,
      "e": 88299,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 102209,
      "e": 88331,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "84"
    },
    {
      "t": 102209,
      "e": 88331,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 102257,
      "e": 88379,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "UNit"
    },
    {
      "t": 102306,
      "e": 88428,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "69"
    },
    {
      "t": 102307,
      "e": 88429,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 102337,
      "e": 88459,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||e"
    },
    {
      "t": 102369,
      "e": 88491,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 102481,
      "e": 88603,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "68"
    },
    {
      "t": 102482,
      "e": 88604,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 102537,
      "e": 88659,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||d"
    },
    {
      "t": 102921,
      "e": 89043,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "8"
    },
    {
      "t": 102977,
      "e": 89099,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "UNite"
    },
    {
      "t": 103081,
      "e": 89203,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "8"
    },
    {
      "t": 103145,
      "e": 89267,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "UNit"
    },
    {
      "t": 103233,
      "e": 89355,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "8"
    },
    {
      "t": 103313,
      "e": 89435,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "UNi"
    },
    {
      "t": 103409,
      "e": 89531,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "8"
    },
    {
      "t": 103482,
      "e": 89604,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "UN"
    },
    {
      "t": 103697,
      "e": 89819,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "8"
    },
    {
      "t": 103769,
      "e": 89891,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "U"
    },
    {
      "t": 103930,
      "e": 90052,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "78"
    },
    {
      "t": 103932,
      "e": 90054,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 104057,
      "e": 90179,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Un"
    },
    {
      "t": 104065,
      "e": 90187,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "73"
    },
    {
      "t": 104065,
      "e": 90187,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 104121,
      "e": 90243,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "84"
    },
    {
      "t": 104121,
      "e": 90243,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 104170,
      "e": 90292,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Unit"
    },
    {
      "t": 104186,
      "e": 90308,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "69"
    },
    {
      "t": 104186,
      "e": 90308,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 104233,
      "e": 90355,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||e"
    },
    {
      "t": 104274,
      "e": 90396,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 104354,
      "e": 90476,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "68"
    },
    {
      "t": 104354,
      "e": 90476,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 104418,
      "e": 90540,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "32"
    },
    {
      "t": 104419,
      "e": 90541,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 104441,
      "e": 90563,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||d "
    },
    {
      "t": 104497,
      "e": 90619,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 104561,
      "e": 90683,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 104601,
      "e": 90723,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "83"
    },
    {
      "t": 104601,
      "e": 90723,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 104649,
      "e": 90771,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||S"
    },
    {
      "t": 104689,
      "e": 90811,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "84"
    },
    {
      "t": 104689,
      "e": 90811,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 104729,
      "e": 90851,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||t"
    },
    {
      "t": 104809,
      "e": 90931,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "65"
    },
    {
      "t": 104810,
      "e": 90932,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 104825,
      "e": 90947,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||a"
    },
    {
      "t": 104937,
      "e": 91059,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "84"
    },
    {
      "t": 104937,
      "e": 91059,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 104961,
      "e": 91083,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||t"
    },
    {
      "t": 104984,
      "e": 91106,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "69"
    },
    {
      "t": 104985,
      "e": 91107,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 105089,
      "e": 91211,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||e"
    },
    {
      "t": 105121,
      "e": 91243,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "83"
    },
    {
      "t": 105122,
      "e": 91244,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 105202,
      "e": 91324,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||s"
    },
    {
      "t": 105242,
      "e": 91364,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 105875,
      "e": 91997,
      "ty": 7,
      "x": 1005,
      "y": 673,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 105892,
      "e": 92014,
      "ty": 6,
      "x": 1003,
      "y": 680,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 105908,
      "e": 92030,
      "ty": 2,
      "x": 1000,
      "y": 685
    },
    {
      "t": 106008,
      "e": 92130,
      "ty": 2,
      "x": 991,
      "y": 706
    },
    {
      "t": 106008,
      "e": 92130,
      "ty": 41,
      "x": 49002,
      "y": 59577,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 106110,
      "e": 92232,
      "ty": 3,
      "x": 991,
      "y": 706,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 106111,
      "e": 92233,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "United States"
    },
    {
      "t": 106112,
      "e": 92234,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 106112,
      "e": 92234,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 106190,
      "e": 92312,
      "ty": 4,
      "x": 49002,
      "y": 59577,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 106192,
      "e": 92314,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 106193,
      "e": 92315,
      "ty": 5,
      "x": 991,
      "y": 706,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 106194,
      "e": 92316,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 107215,
      "e": 93337,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 107808,
      "e": 93930,
      "ty": 2,
      "x": 991,
      "y": 705
    },
    {
      "t": 107908,
      "e": 94030,
      "ty": 2,
      "x": 991,
      "y": 698
    },
    {
      "t": 108009,
      "e": 94131,
      "ty": 2,
      "x": 986,
      "y": 604
    },
    {
      "t": 108009,
      "e": 94131,
      "ty": 41,
      "x": 39058,
      "y": 33103,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 108309,
      "e": 94431,
      "ty": 2,
      "x": 972,
      "y": 585
    },
    {
      "t": 108408,
      "e": 94530,
      "ty": 2,
      "x": 960,
      "y": 362
    },
    {
      "t": 108508,
      "e": 94630,
      "ty": 2,
      "x": 953,
      "y": 300
    },
    {
      "t": 108508,
      "e": 94630,
      "ty": 41,
      "x": 41236,
      "y": 49151,
      "ta": "#jspsych-survey-multi-choice-option-0-2 > label"
    },
    {
      "t": 108608,
      "e": 94730,
      "ty": 2,
      "x": 934,
      "y": 266
    },
    {
      "t": 108709,
      "e": 94831,
      "ty": 2,
      "x": 897,
      "y": 254
    },
    {
      "t": 108761,
      "e": 94833,
      "ty": 41,
      "x": 16037,
      "y": 58513,
      "ta": "#jspsych-survey-multi-choice-option-0-0"
    },
    {
      "t": 108808,
      "e": 94880,
      "ty": 2,
      "x": 886,
      "y": 248
    },
    {
      "t": 108908,
      "e": 94980,
      "ty": 2,
      "x": 875,
      "y": 243
    },
    {
      "t": 108950,
      "e": 95022,
      "ty": 3,
      "x": 875,
      "y": 243,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 109008,
      "e": 95080,
      "ty": 41,
      "x": 43873,
      "y": 45874,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 109029,
      "e": 95101,
      "ty": 4,
      "x": 43873,
      "y": 45874,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 109030,
      "e": 95102,
      "ty": 5,
      "x": 875,
      "y": 243,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 109031,
      "e": 95103,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 109034,
      "e": 95106,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf",
      "v": "English"
    },
    {
      "t": 109308,
      "e": 95380,
      "ty": 2,
      "x": 874,
      "y": 244
    },
    {
      "t": 109408,
      "e": 95480,
      "ty": 2,
      "x": 882,
      "y": 293
    },
    {
      "t": 109508,
      "e": 95580,
      "ty": 2,
      "x": 885,
      "y": 318
    },
    {
      "t": 109509,
      "e": 95581,
      "ty": 41,
      "x": 63115,
      "y": 16383,
      "ta": "#jspsych-survey-multi-choice-option-0-3 > label"
    },
    {
      "t": 109608,
      "e": 95680,
      "ty": 2,
      "x": 882,
      "y": 378
    },
    {
      "t": 109709,
      "e": 95781,
      "ty": 2,
      "x": 874,
      "y": 403
    },
    {
      "t": 109758,
      "e": 95830,
      "ty": 41,
      "x": 53353,
      "y": 58981,
      "ta": "#jspsych-survey-multi-choice-option-1-0 > label"
    },
    {
      "t": 109809,
      "e": 95881,
      "ty": 2,
      "x": 865,
      "y": 431
    },
    {
      "t": 110008,
      "e": 96080,
      "ty": 2,
      "x": 863,
      "y": 442
    },
    {
      "t": 110008,
      "e": 96080,
      "ty": 41,
      "x": 33210,
      "y": 29490,
      "ta": "#jspsych-survey-multi-choice-option-1-1 > label"
    },
    {
      "t": 110150,
      "e": 96222,
      "ty": 3,
      "x": 863,
      "y": 442,
      "ta": "#jspsych-survey-multi-choice-option-1-1 > label"
    },
    {
      "t": 110151,
      "e": 96223,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 110205,
      "e": 96277,
      "ty": 4,
      "x": 33210,
      "y": 29490,
      "ta": "#jspsych-survey-multi-choice-option-1-1 > label"
    },
    {
      "t": 110205,
      "e": 96277,
      "ty": 5,
      "x": 863,
      "y": 442,
      "ta": "#jspsych-survey-multi-choice-option-1-1 > label"
    },
    {
      "t": 110205,
      "e": 96277,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 110206,
      "e": 96278,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf",
      "v": "Second"
    },
    {
      "t": 110509,
      "e": 96581,
      "ty": 2,
      "x": 878,
      "y": 479
    },
    {
      "t": 110509,
      "e": 96581,
      "ty": 41,
      "x": 59803,
      "y": 58981,
      "ta": "#jspsych-survey-multi-choice-option-1-2 > label"
    },
    {
      "t": 110609,
      "e": 96681,
      "ty": 2,
      "x": 935,
      "y": 586
    },
    {
      "t": 110709,
      "e": 96781,
      "ty": 2,
      "x": 937,
      "y": 608
    },
    {
      "t": 110759,
      "e": 96831,
      "ty": 41,
      "x": 27192,
      "y": 56172,
      "ta": "#jspsych-survey-multi-choice-2 > p"
    },
    {
      "t": 110809,
      "e": 96881,
      "ty": 2,
      "x": 931,
      "y": 668
    },
    {
      "t": 110908,
      "e": 96980,
      "ty": 2,
      "x": 925,
      "y": 686
    },
    {
      "t": 111009,
      "e": 97081,
      "ty": 2,
      "x": 914,
      "y": 714
    },
    {
      "t": 111009,
      "e": 97081,
      "ty": 41,
      "x": 21971,
      "y": 58513,
      "ta": "#jspsych-survey-multi-choice-option-2-1"
    },
    {
      "t": 111108,
      "e": 97180,
      "ty": 2,
      "x": 911,
      "y": 723
    },
    {
      "t": 111208,
      "e": 97280,
      "ty": 2,
      "x": 906,
      "y": 736
    },
    {
      "t": 111261,
      "e": 97282,
      "ty": 41,
      "x": 20977,
      "y": 58981,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 111309,
      "e": 97330,
      "ty": 2,
      "x": 900,
      "y": 750
    },
    {
      "t": 111408,
      "e": 97429,
      "ty": 2,
      "x": 896,
      "y": 759
    },
    {
      "t": 111509,
      "e": 97530,
      "ty": 2,
      "x": 893,
      "y": 763
    },
    {
      "t": 111509,
      "e": 97530,
      "ty": 41,
      "x": 29866,
      "y": 45874,
      "ta": "#jspsych-survey-multi-choice-option-2-3 > label"
    },
    {
      "t": 111909,
      "e": 97930,
      "ty": 2,
      "x": 897,
      "y": 751
    },
    {
      "t": 112008,
      "e": 98029,
      "ty": 2,
      "x": 899,
      "y": 742
    },
    {
      "t": 112009,
      "e": 98030,
      "ty": 41,
      "x": 18411,
      "y": 58513,
      "ta": "#jspsych-survey-multi-choice-option-2-2"
    },
    {
      "t": 112108,
      "e": 98129,
      "ty": 2,
      "x": 902,
      "y": 737
    },
    {
      "t": 112208,
      "e": 98229,
      "ty": 2,
      "x": 904,
      "y": 732
    },
    {
      "t": 112259,
      "e": 98280,
      "ty": 41,
      "x": 20726,
      "y": 36044,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 112534,
      "e": 98555,
      "ty": 3,
      "x": 904,
      "y": 732,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 112534,
      "e": 98555,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 112645,
      "e": 98666,
      "ty": 4,
      "x": 20726,
      "y": 36044,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 112646,
      "e": 98667,
      "ty": 5,
      "x": 904,
      "y": 732,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 112647,
      "e": 98668,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 112649,
      "e": 98670,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf",
      "v": "Biomedical & Health Sciences"
    },
    {
      "t": 113759,
      "e": 99780,
      "ty": 41,
      "x": 20726,
      "y": 58981,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 113809,
      "e": 99830,
      "ty": 2,
      "x": 914,
      "y": 761
    },
    {
      "t": 113909,
      "e": 99930,
      "ty": 2,
      "x": 921,
      "y": 786
    },
    {
      "t": 114008,
      "e": 100029,
      "ty": 2,
      "x": 935,
      "y": 828
    },
    {
      "t": 114008,
      "e": 100029,
      "ty": 41,
      "x": 26954,
      "y": 63194,
      "ta": "#jspsych-survey-multi-choice-option-2-5"
    },
    {
      "t": 114108,
      "e": 100129,
      "ty": 2,
      "x": 932,
      "y": 837
    },
    {
      "t": 114209,
      "e": 100230,
      "ty": 2,
      "x": 923,
      "y": 866
    },
    {
      "t": 114259,
      "e": 100280,
      "ty": 41,
      "x": 21733,
      "y": 23405,
      "ta": "#jspsych-survey-multi-choice-3 > p"
    },
    {
      "t": 114309,
      "e": 100330,
      "ty": 2,
      "x": 906,
      "y": 896
    },
    {
      "t": 114408,
      "e": 100429,
      "ty": 2,
      "x": 885,
      "y": 945
    },
    {
      "t": 114509,
      "e": 100530,
      "ty": 2,
      "x": 855,
      "y": 981
    },
    {
      "t": 114509,
      "e": 100530,
      "ty": 41,
      "x": 33333,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-3-2 > label"
    },
    {
      "t": 114609,
      "e": 100630,
      "ty": 2,
      "x": 862,
      "y": 961
    },
    {
      "t": 114708,
      "e": 100729,
      "ty": 2,
      "x": 872,
      "y": 932
    },
    {
      "t": 114759,
      "e": 100780,
      "ty": 41,
      "x": 56336,
      "y": 3276,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 114809,
      "e": 100830,
      "ty": 2,
      "x": 873,
      "y": 926
    },
    {
      "t": 114814,
      "e": 100835,
      "ty": 3,
      "x": 873,
      "y": 926,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 114815,
      "e": 100836,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 114917,
      "e": 100938,
      "ty": 4,
      "x": 56336,
      "y": 3276,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 114917,
      "e": 100938,
      "ty": 5,
      "x": 873,
      "y": 926,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 114917,
      "e": 100938,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 114918,
      "e": 100939,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf",
      "v": "Male"
    },
    {
      "t": 115009,
      "e": 101030,
      "ty": 2,
      "x": 874,
      "y": 921
    },
    {
      "t": 115009,
      "e": 101030,
      "ty": 41,
      "x": 12478,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-3-0"
    },
    {
      "t": 115108,
      "e": 101129,
      "ty": 2,
      "x": 871,
      "y": 936
    },
    {
      "t": 115208,
      "e": 101229,
      "ty": 2,
      "x": 891,
      "y": 975
    },
    {
      "t": 115259,
      "e": 101229,
      "ty": 41,
      "x": 16749,
      "y": 58513,
      "ta": "#jspsych-survey-multi-choice-option-3-2"
    },
    {
      "t": 115265,
      "e": 101235,
      "ty": 6,
      "x": 892,
      "y": 1008,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 115308,
      "e": 101278,
      "ty": 2,
      "x": 892,
      "y": 1019
    },
    {
      "t": 115349,
      "e": 101319,
      "ty": 7,
      "x": 897,
      "y": 1043,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 115408,
      "e": 101378,
      "ty": 2,
      "x": 898,
      "y": 1045
    },
    {
      "t": 115483,
      "e": 101453,
      "ty": 6,
      "x": 899,
      "y": 1036,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 115508,
      "e": 101478,
      "ty": 2,
      "x": 899,
      "y": 1031
    },
    {
      "t": 115508,
      "e": 101478,
      "ty": 41,
      "x": 35859,
      "y": 51633,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 115609,
      "e": 101579,
      "ty": 2,
      "x": 899,
      "y": 1023
    },
    {
      "t": 115654,
      "e": 101624,
      "ty": 3,
      "x": 899,
      "y": 1023,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 115656,
      "e": 101626,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 115656,
      "e": 101626,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 115725,
      "e": 101695,
      "ty": 4,
      "x": 35859,
      "y": 35746,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 115725,
      "e": 101695,
      "ty": 5,
      "x": 899,
      "y": 1023,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 115728,
      "e": 101698,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 115728,
      "e": 101698,
      "ty": 13,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 115729,
      "e": 101699,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 115758,
      "e": 101728,
      "ty": 41,
      "x": 30684,
      "y": 56172,
      "ta": "html > body"
    },
    {
      "t": 115809,
      "e": 101779,
      "ty": 2,
      "x": 899,
      "y": 1021
    },
    {
      "t": 115908,
      "e": 101878,
      "ty": 2,
      "x": 948,
      "y": 999
    },
    {
      "t": 116008,
      "e": 101978,
      "ty": 2,
      "x": 1114,
      "y": 833
    },
    {
      "t": 116009,
      "e": 101979,
      "ty": 41,
      "x": 38088,
      "y": 45702,
      "ta": "html > body"
    },
    {
      "t": 116108,
      "e": 102078,
      "ty": 2,
      "x": 1039,
      "y": 624
    },
    {
      "t": 116209,
      "e": 102179,
      "ty": 2,
      "x": 846,
      "y": 506
    },
    {
      "t": 116259,
      "e": 102229,
      "ty": 41,
      "x": 28824,
      "y": 27532,
      "ta": "html > body"
    },
    {
      "t": 116309,
      "e": 102279,
      "ty": 2,
      "x": 845,
      "y": 505
    },
    {
      "t": 117063,
      "e": 103033,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 123614,
      "e": 107279,
      "ty": 2,
      "x": 840,
      "y": 504
    },
    {
      "t": 123714,
      "e": 107379,
      "ty": 2,
      "x": 754,
      "y": 483
    },
    {
      "t": 123764,
      "e": 107429,
      "ty": 41,
      "x": 21378,
      "y": 16501,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 123813,
      "e": 107478,
      "ty": 2,
      "x": 717,
      "y": 475
    },
    {
      "t": 123913,
      "e": 107578,
      "ty": 2,
      "x": 611,
      "y": 469
    },
    {
      "t": 124013,
      "e": 107678,
      "ty": 2,
      "x": 458,
      "y": 440
    },
    {
      "t": 124015,
      "e": 107680,
      "ty": 41,
      "x": 8095,
      "y": 46432,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 124113,
      "e": 107778,
      "ty": 2,
      "x": 411,
      "y": 436
    },
    {
      "t": 124214,
      "e": 107879,
      "ty": 2,
      "x": 388,
      "y": 436
    },
    {
      "t": 124264,
      "e": 107929,
      "ty": 41,
      "x": 3913,
      "y": 43312,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 124314,
      "e": 107979,
      "ty": 2,
      "x": 370,
      "y": 436
    },
    {
      "t": 124514,
      "e": 108179,
      "ty": 41,
      "x": 3765,
      "y": 43312,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 129264,
      "e": 112929,
      "ty": 41,
      "x": 2929,
      "y": 54234,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 129313,
      "e": 112978,
      "ty": 2,
      "x": 349,
      "y": 453
    },
    {
      "t": 129414,
      "e": 113079,
      "ty": 2,
      "x": 371,
      "y": 496
    },
    {
      "t": 129514,
      "e": 113179,
      "ty": 2,
      "x": 712,
      "y": 671
    },
    {
      "t": 129514,
      "e": 113179,
      "ty": 41,
      "x": 20591,
      "y": 1471,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 129614,
      "e": 113279,
      "ty": 2,
      "x": 909,
      "y": 830
    },
    {
      "t": 129714,
      "e": 113379,
      "ty": 2,
      "x": 921,
      "y": 878
    },
    {
      "t": 129764,
      "e": 113429,
      "ty": 41,
      "x": 30725,
      "y": 53784,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 129814,
      "e": 113479,
      "ty": 2,
      "x": 918,
      "y": 953
    },
    {
      "t": 129913,
      "e": 113578,
      "ty": 2,
      "x": 920,
      "y": 994
    },
    {
      "t": 130014,
      "e": 113679,
      "ty": 2,
      "x": 943,
      "y": 1052
    },
    {
      "t": 130015,
      "e": 113680,
      "ty": 41,
      "x": 31955,
      "y": 64102,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 130015,
      "e": 113680,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 130114,
      "e": 113779,
      "ty": 2,
      "x": 943,
      "y": 1053
    },
    {
      "t": 130211,
      "e": 113876,
      "ty": 6,
      "x": 944,
      "y": 1072,
      "ta": "#start"
    },
    {
      "t": 130213,
      "e": 113878,
      "ty": 2,
      "x": 944,
      "y": 1072
    },
    {
      "t": 130264,
      "e": 113929,
      "ty": 41,
      "x": 19387,
      "y": 4457,
      "ta": "#start"
    },
    {
      "t": 130313,
      "e": 113978,
      "ty": 2,
      "x": 945,
      "y": 1075
    },
    {
      "t": 130412,
      "e": 114077,
      "ty": 2,
      "x": 948,
      "y": 1080
    },
    {
      "t": 130512,
      "e": 114177,
      "ty": 2,
      "x": 948,
      "y": 1081
    },
    {
      "t": 130513,
      "e": 114178,
      "ty": 41,
      "x": 21025,
      "y": 16022,
      "ta": "#start"
    },
    {
      "t": 130613,
      "e": 114278,
      "ty": 2,
      "x": 949,
      "y": 1084
    },
    {
      "t": 130707,
      "e": 114372,
      "ty": 3,
      "x": 950,
      "y": 1089,
      "ta": "#start"
    },
    {
      "t": 130708,
      "e": 114373,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 130714,
      "e": 114379,
      "ty": 2,
      "x": 950,
      "y": 1089
    },
    {
      "t": 130763,
      "e": 114428,
      "ty": 41,
      "x": 22664,
      "y": 31442,
      "ta": "#start"
    },
    {
      "t": 130814,
      "e": 114479,
      "ty": 2,
      "x": 951,
      "y": 1089
    },
    {
      "t": 130841,
      "e": 114506,
      "ty": 4,
      "x": 22664,
      "y": 31442,
      "ta": "#start"
    },
    {
      "t": 130843,
      "e": 114508,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 130844,
      "e": 114509,
      "ty": 5,
      "x": 951,
      "y": 1089,
      "ta": "#start"
    },
    {
      "t": 130844,
      "e": 114509,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 131413,
      "e": 115078,
      "ty": 2,
      "x": 953,
      "y": 1085
    },
    {
      "t": 131513,
      "e": 115178,
      "ty": 2,
      "x": 946,
      "y": 992
    },
    {
      "t": 131513,
      "e": 115178,
      "ty": 41,
      "x": 32302,
      "y": 54510,
      "ta": "html > body"
    },
    {
      "t": 131612,
      "e": 115277,
      "ty": 2,
      "x": 918,
      "y": 791
    },
    {
      "t": 131712,
      "e": 115377,
      "ty": 2,
      "x": 903,
      "y": 661
    },
    {
      "t": 131763,
      "e": 115428,
      "ty": 41,
      "x": 30821,
      "y": 36174,
      "ta": "html > body"
    },
    {
      "t": 131877,
      "e": 115542,
      "ty": 38,
      "x": 8,
      "y": 0
    },
    {
      "t": 132869,
      "e": 116534,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":56},{\"id\":57},{\"id\":58},{\"id\":59},{\"id\":60},{\"id\":61},{\"id\":62},{\"id\":63},{\"id\":64},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":72},{\"id\":73},{\"id\":74},{\"id\":75},{\"id\":76},{\"id\":77},{\"id\":78},{\"id\":79},{\"id\":80},{\"id\":81},{\"id\":82},{\"id\":83},{\"id\":84},{\"id\":85},{\"id\":86},{\"id\":87},{\"id\":88},{\"id\":89},{\"id\":90},{\"id\":91},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":96},{\"id\":97},{\"id\":98},{\"id\":99},{\"id\":100},{\"id\":101},{\"id\":102},{\"id\":103},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":109},{\"id\":110},{\"id\":111},{\"id\":112},{\"id\":113},{\"id\":114},{\"id\":115},{\"id\":116},{\"id\":117},{\"id\":118},{\"id\":119},{\"id\":120},{\"id\":121},{\"id\":122},{\"id\":123},{\"id\":124},{\"id\":125},{\"id\":126},{\"id\":127},{\"id\":128},{\"id\":129},{\"id\":130},{\"id\":131},{\"id\":132},{\"id\":133},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":141},{\"id\":142},{\"id\":143},{\"id\":144},{\"id\":145},{\"id\":146},{\"id\":147},{\"id\":148},{\"id\":149},{\"id\":150},{\"id\":151},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":155},{\"id\":156},{\"id\":157},{\"id\":158},{\"id\":159},{\"id\":160},{\"id\":161},{\"id\":162},{\"id\":163},{\"id\":164},{\"id\":165},{\"id\":166},{\"id\":167},{\"id\":168},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":172},{\"id\":173},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":178},{\"id\":179},{\"id\":180},{\"id\":181},{\"id\":182},{\"id\":183},{\"id\":184},{\"id\":185},{\"id\":186},{\"id\":187},{\"id\":188},{\"id\":189},{\"id\":190},{\"id\":191},{\"id\":192},{\"id\":193},{\"id\":194},{\"id\":195},{\"id\":196},{\"id\":197},{\"id\":198},{\"id\":199},{\"id\":200},{\"id\":201},{\"id\":202},{\"id\":203},{\"id\":204},{\"id\":205},{\"id\":206},{\"id\":207},{\"id\":208},{\"id\":209},{\"id\":210},{\"id\":211},{\"id\":212},{\"id\":213},{\"id\":214},{\"id\":215},{\"id\":216},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":220},{\"id\":221},{\"id\":222},{\"id\":223},{\"id\":224},{\"id\":225},{\"id\":226},{\"id\":227},{\"id\":228},{\"id\":229},{\"id\":230},{\"id\":231},{\"id\":232},{\"id\":233},{\"id\":234},{\"id\":235},{\"id\":236},{\"id\":237},{\"id\":238},{\"id\":239},{\"id\":240},{\"id\":241},{\"id\":242},{\"id\":243},{\"id\":244},{\"id\":245},{\"id\":246},{\"id\":247},{\"id\":248},{\"id\":249},{\"id\":250},{\"id\":251},{\"id\":252},{\"id\":253},{\"id\":254},{\"id\":255},{\"id\":256},{\"id\":257},{\"id\":258},{\"id\":259},{\"id\":260},{\"id\":261},{\"id\":262},{\"id\":263},{\"id\":264},{\"id\":265},{\"id\":266},{\"id\":267},{\"id\":268},{\"id\":269},{\"id\":270},{\"id\":271},{\"id\":272},{\"id\":273},{\"id\":274},{\"id\":275},{\"id\":276},{\"id\":277},{\"id\":278},{\"id\":279},{\"id\":280},{\"id\":281},{\"id\":282},{\"id\":283},{\"id\":284},{\"id\":285},{\"id\":286},{\"id\":287},{\"id\":288},{\"id\":289},{\"id\":290},{\"id\":291},{\"id\":292},{\"id\":293},{\"id\":294},{\"id\":295},{\"id\":296},{\"id\":297},{\"id\":298},{\"id\":299},{\"id\":300},{\"id\":301},{\"id\":302},{\"id\":303},{\"id\":304},{\"id\":305},{\"id\":306},{\"id\":307},{\"id\":308},{\"id\":309},{\"id\":310},{\"id\":311},{\"id\":312},{\"id\":313},{\"id\":314},{\"id\":315},{\"id\":316},{\"id\":317},{\"id\":318},{\"id\":319},{\"id\":320},{\"id\":321},{\"id\":322},{\"id\":323},{\"id\":324},{\"id\":325},{\"id\":326},{\"id\":327},{\"id\":328},{\"id\":329},{\"id\":330},{\"id\":331},{\"id\":332},{\"id\":333},{\"id\":334},{\"id\":335},{\"id\":336},{\"id\":337},{\"id\":338},{\"id\":339},{\"id\":340},{\"id\":341},{\"id\":342},{\"id\":343},{\"id\":344},{\"id\":345},{\"id\":346},{\"id\":347},{\"id\":348},{\"id\":349},{\"id\":350},{\"id\":351},{\"id\":352},{\"id\":353},{\"id\":354},{\"id\":355},{\"id\":356},{\"id\":357},{\"id\":358},{\"id\":359},{\"id\":360},{\"id\":361},{\"id\":362},{\"id\":363},{\"id\":364},{\"id\":365},{\"id\":366},{\"id\":367},{\"id\":368},{\"id\":369},{\"id\":370},{\"id\":371},{\"id\":372},{\"id\":373},{\"id\":374},{\"id\":375},{\"id\":376},{\"id\":377},{\"id\":378},{\"id\":379},{\"id\":380},{\"id\":381},{\"id\":382},{\"id\":383},{\"id\":384},{\"id\":385},{\"id\":386},{\"id\":387},{\"id\":388},{\"id\":389},{\"id\":390},{\"id\":391},{\"id\":392},{\"id\":393},{\"id\":394},{\"id\":395},{\"id\":396},{\"id\":397},{\"id\":398},{\"id\":399},{\"id\":400},{\"id\":401},{\"id\":402},{\"id\":403},{\"id\":404},{\"id\":405},{\"id\":406},{\"id\":407},{\"id\":408},{\"id\":409},{\"id\":410},{\"id\":411},{\"id\":412},{\"id\":413},{\"id\":414},{\"id\":415},{\"id\":416},{\"id\":417},{\"id\":418},{\"id\":419},{\"id\":420},{\"id\":421},{\"id\":422},{\"id\":423},{\"id\":424},{\"id\":425},{\"id\":426},{\"id\":427},{\"id\":428},{\"id\":429},{\"id\":430},{\"id\":431},{\"id\":432},{\"id\":433},{\"id\":434},{\"id\":435},{\"id\":436},{\"id\":437},{\"id\":438},{\"id\":439},{\"id\":440},{\"id\":441},{\"id\":442},{\"id\":443},{\"id\":444},{\"id\":445},{\"id\":446},{\"id\":447},{\"id\":448},{\"id\":449},{\"id\":450},{\"id\":451},{\"id\":452},{\"id\":453},{\"id\":454},{\"id\":455},{\"id\":456},{\"id\":457},{\"id\":458},{\"id\":459},{\"id\":460},{\"id\":461},{\"id\":462},{\"id\":463},{\"id\":464},{\"id\":465},{\"id\":466},{\"id\":467},{\"id\":468},{\"id\":469},{\"id\":470},{\"id\":471},{\"id\":472},{\"id\":473},{\"id\":474},{\"id\":475},{\"id\":476},{\"id\":477},{\"id\":478},{\"id\":479},{\"id\":480},{\"id\":481},{\"id\":482},{\"id\":483},{\"id\":484},{\"id\":485},{\"id\":486},{\"id\":487},{\"id\":488},{\"id\":489},{\"id\":490},{\"id\":491},{\"id\":492},{\"id\":493},{\"id\":494},{\"id\":495},{\"id\":496},{\"id\":497},{\"id\":498},{\"id\":499},{\"id\":500},{\"id\":501},{\"id\":502},{\"id\":503},{\"id\":504},{\"id\":505},{\"id\":506},{\"id\":507},{\"id\":508},{\"id\":509},{\"id\":510},{\"id\":511},{\"id\":512},{\"id\":513},{\"id\":514},{\"id\":515},{\"id\":516},{\"id\":517},{\"id\":518},{\"id\":519},{\"id\":520},{\"id\":521},{\"id\":522},{\"id\":523},{\"id\":524},{\"id\":525},{\"id\":526},{\"id\":527},{\"id\":528},{\"id\":529},{\"id\":530},{\"id\":531},{\"id\":532},{\"id\":533},{\"id\":534},{\"id\":535},{\"id\":536},{\"id\":537},{\"id\":538},{\"id\":539},{\"id\":540},{\"id\":541},{\"id\":542},{\"id\":543},{\"id\":544},{\"id\":545},{\"id\":546},{\"id\":547},{\"id\":548},{\"id\":549},{\"id\":550},{\"id\":551},{\"id\":552},{\"id\":553},{\"id\":554},{\"id\":555},{\"id\":556},{\"id\":557},{\"id\":558},{\"id\":559},{\"id\":560},{\"id\":561},{\"id\":562},{\"id\":563},{\"id\":564},{\"id\":565},{\"id\":566},{\"id\":567},{\"id\":568},{\"id\":569},{\"id\":570},{\"id\":571},{\"id\":572},{\"id\":573},{\"id\":574},{\"id\":575},{\"id\":576},{\"id\":577},{\"id\":578},{\"id\":579},{\"id\":580},{\"id\":581},{\"id\":582},{\"id\":583},{\"id\":584},{\"id\":585},{\"id\":586},{\"id\":587},{\"id\":588},{\"id\":589},{\"id\":590},{\"id\":591},{\"id\":592},{\"id\":593},{\"id\":594},{\"id\":595},{\"id\":596},{\"id\":597},{\"id\":598},{\"id\":599},{\"id\":600},{\"id\":601},{\"id\":602},{\"id\":603},{\"id\":604},{\"id\":605},{\"id\":606},{\"id\":607},{\"id\":608},{\"id\":609},{\"id\":610},{\"id\":611},{\"id\":612},{\"id\":613},{\"id\":614},{\"id\":615},{\"id\":616},{\"id\":617},{\"id\":618},{\"id\":619},{\"id\":620},{\"id\":621},{\"id\":622},{\"id\":623},{\"id\":624},{\"id\":625},{\"id\":626},{\"id\":627},{\"id\":628},{\"id\":629},{\"id\":630},{\"id\":631},{\"id\":632},{\"id\":633},{\"id\":634},{\"id\":635},{\"id\":636},{\"id\":637},{\"id\":638},{\"id\":639},{\"id\":640},{\"id\":641},{\"id\":642},{\"id\":643},{\"id\":644},{\"id\":645},{\"id\":646},{\"id\":647},{\"id\":648},{\"id\":649},{\"id\":650},{\"id\":651},{\"id\":652},{\"id\":653},{\"id\":654},{\"id\":655},{\"id\":656},{\"id\":657},{\"id\":658},{\"id\":659},{\"id\":660},{\"id\":661},{\"id\":662},{\"id\":663},{\"id\":664},{\"id\":665},{\"id\":666},{\"id\":667},{\"id\":668},{\"id\":669},{\"id\":670},{\"id\":671},{\"id\":672},{\"id\":673},{\"id\":674},{\"id\":675},{\"id\":676},{\"id\":677},{\"id\":678},{\"id\":679},{\"id\":680},{\"id\":681},{\"id\":682},{\"id\":683},{\"id\":684},{\"id\":685},{\"id\":686},{\"id\":687},{\"id\":688},{\"id\":689},{\"id\":690},{\"id\":691},{\"id\":692},{\"id\":693},{\"id\":694},{\"id\":695},{\"id\":696},{\"id\":697},{\"id\":698},{\"id\":699},{\"id\":700},{\"id\":701},{\"id\":702},{\"id\":703},{\"id\":704},{\"id\":705},{\"id\":706},{\"id\":707},{\"id\":708},{\"id\":709},{\"id\":710},{\"id\":711},{\"id\":712},{\"id\":713},{\"id\":714},{\"id\":715},{\"id\":716},{\"id\":717},{\"id\":718},{\"id\":719},{\"id\":720},{\"id\":721},{\"id\":722},{\"id\":723},{\"id\":724},{\"id\":725},{\"id\":726},{\"id\":727},{\"id\":728},{\"id\":729},{\"id\":730},{\"id\":731},{\"id\":732},{\"id\":733},{\"id\":734},{\"id\":735},{\"id\":736},{\"id\":737},{\"id\":738},{\"id\":739},{\"id\":740},{\"id\":741},{\"id\":742},{\"id\":743},{\"id\":744},{\"id\":745},{\"id\":746},{\"id\":747},{\"id\":748},{\"id\":749},{\"id\":750},{\"id\":751},{\"id\":752},{\"id\":753},{\"id\":754},{\"id\":755},{\"id\":756},{\"id\":757},{\"id\":758},{\"id\":759},{\"id\":760},{\"id\":761},{\"id\":762},{\"id\":763},{\"id\":764},{\"id\":765},{\"id\":766},{\"id\":767},{\"id\":768},{\"id\":769},{\"id\":770},{\"id\":771},{\"id\":772},{\"id\":773},{\"id\":774},{\"id\":775},{\"id\":776},{\"id\":777},{\"id\":778},{\"id\":779},{\"id\":780},{\"id\":781},{\"id\":782},{\"id\":783},{\"id\":784},{\"id\":785},{\"id\":786},{\"id\":787},{\"id\":788},{\"id\":789},{\"id\":790},{\"id\":791},{\"id\":792},{\"id\":793},{\"id\":794},{\"id\":795},{\"id\":796},{\"id\":797},{\"id\":798},{\"id\":799},{\"id\":800},{\"id\":801},{\"id\":802},{\"id\":803},{\"id\":804},{\"id\":805},{\"id\":806},{\"id\":807},{\"id\":808},{\"id\":809},{\"id\":810},{\"id\":811},{\"id\":812},{\"id\":813},{\"id\":814},{\"id\":815},{\"id\":816},{\"id\":817},{\"id\":818},{\"id\":819},{\"id\":820},{\"id\":821},{\"id\":822},{\"id\":823},{\"id\":824},{\"id\":825},{\"id\":826},{\"id\":827},{\"id\":828},{\"id\":829},{\"id\":830},{\"id\":831},{\"id\":832},{\"id\":833},{\"id\":834},{\"id\":835},{\"id\":836},{\"id\":837},{\"id\":838},{\"id\":839},{\"id\":840},{\"id\":841},{\"id\":842},{\"id\":843},{\"id\":844},{\"id\":845},{\"id\":846},{\"id\":847},{\"id\":848},{\"id\":849},{\"id\":850},{\"id\":851},{\"id\":852},{\"id\":853},{\"id\":854},{\"id\":855},{\"id\":856},{\"id\":857},{\"id\":858},{\"id\":859},{\"id\":860},{\"id\":861},{\"id\":862},{\"id\":863},{\"id\":864},{\"id\":865},{\"id\":866},{\"id\":867},{\"id\":868},{\"id\":869},{\"id\":870},{\"id\":871},{\"id\":872},{\"id\":873},{\"id\":874},{\"id\":875},{\"id\":876},{\"id\":877},{\"id\":878},{\"id\":879},{\"id\":880},{\"id\":881},{\"id\":882},{\"id\":883},{\"id\":884},{\"id\":885},{\"id\":886},{\"id\":887},{\"id\":888},{\"id\":889},{\"id\":890},{\"id\":891},{\"id\":892},{\"id\":893},{\"id\":894},{\"id\":895},{\"id\":896},{\"id\":897},{\"id\":898},{\"id\":899},{\"id\":900},{\"id\":901},{\"id\":902},{\"id\":903},{\"id\":904},{\"id\":905},{\"id\":906},{\"id\":907},{\"id\":908},{\"id\":909},{\"id\":910},{\"id\":911},{\"id\":912},{\"id\":913},{\"id\":914},{\"id\":915},{\"id\":916},{\"id\":917},{\"id\":918},{\"id\":919},{\"id\":920},{\"id\":921},{\"id\":922},{\"id\":923},{\"id\":924},{\"id\":925},{\"id\":926},{\"id\":927},{\"id\":928},{\"id\":929},{\"id\":930},{\"id\":931},{\"id\":932},{\"id\":933},{\"id\":934},{\"id\":935},{\"id\":936},{\"id\":937},{\"id\":938},{\"id\":939},{\"id\":940},{\"id\":941},{\"id\":942},{\"id\":943},{\"id\":944},{\"id\":945},{\"id\":946},{\"id\":947},{\"id\":948},{\"id\":949},{\"id\":950},{\"id\":951},{\"id\":952},{\"id\":953},{\"id\":954},{\"id\":955},{\"id\":956},{\"id\":957},{\"id\":958},{\"id\":959},{\"id\":960},{\"id\":961},{\"id\":962},{\"id\":963},{\"id\":964},{\"id\":965},{\"id\":966},{\"id\":967},{\"id\":968},{\"id\":969},{\"id\":970},{\"id\":971},{\"id\":972},{\"id\":973},{\"id\":974},{\"id\":975},{\"id\":976},{\"id\":977},{\"id\":978},{\"id\":979},{\"id\":980},{\"id\":981},{\"id\":982},{\"id\":983},{\"id\":984},{\"id\":985},{\"id\":986},{\"id\":987},{\"id\":988},{\"id\":989},{\"id\":990},{\"id\":991},{\"id\":992},{\"id\":993},{\"id\":994},{\"id\":995},{\"id\":996},{\"id\":997},{\"id\":998},{\"id\":999},{\"id\":1000},{\"id\":1001},{\"id\":1002},{\"id\":1003},{\"id\":1004},{\"id\":1005},{\"id\":1006},{\"id\":1007},{\"id\":1008},{\"id\":1009},{\"id\":1010},{\"id\":1011},{\"id\":1012},{\"id\":1013},{\"id\":1014},{\"id\":1015},{\"id\":1016},{\"id\":1017},{\"id\":1018},{\"id\":1019},{\"id\":1020},{\"id\":1021},{\"id\":1022},{\"id\":1023},{\"id\":1024},{\"id\":1025},{\"id\":1026},{\"id\":1027},{\"id\":1028},{\"id\":1029},{\"id\":1030},{\"id\":1031},{\"id\":1032},{\"id\":1033},{\"id\":1034},{\"id\":1035},{\"id\":1036},{\"id\":1037},{\"id\":1038},{\"id\":1039},{\"id\":1040},{\"id\":1041},{\"id\":1042},{\"id\":1043},{\"id\":1044},{\"id\":1045},{\"id\":1046},{\"id\":1047},{\"id\":1048},{\"id\":1049},{\"id\":1050},{\"id\":1051},{\"id\":1052},{\"id\":1053},{\"id\":1054},{\"id\":1055},{\"id\":1056},{\"id\":1057},{\"id\":1058},{\"id\":1059},{\"id\":1060},{\"id\":1061},{\"id\":1062},{\"id\":1063},{\"id\":1064},{\"id\":1065},{\"id\":1066},{\"id\":1067},{\"id\":1068},{\"id\":1069},{\"id\":1070},{\"id\":1071},{\"id\":1072},{\"id\":1073},{\"id\":1074},{\"id\":1075},{\"id\":1076},{\"id\":1077},{\"id\":1078},{\"id\":1079},{\"id\":1080},{\"id\":1081},{\"id\":1082},{\"id\":1083},{\"id\":1084},{\"id\":1085},{\"id\":1086},{\"id\":1087},{\"id\":1088},{\"id\":1089},{\"id\":1090},{\"id\":1091},{\"id\":1092},{\"id\":1093},{\"id\":1094},{\"id\":1095},{\"id\":1096},{\"id\":1097},{\"id\":1098},{\"id\":1099},{\"id\":1100},{\"id\":1101},{\"id\":1102},{\"id\":1103},{\"id\":1104},{\"id\":1105},{\"id\":1106},{\"id\":1107},{\"id\":1108},{\"id\":1109},{\"id\":1110},{\"id\":1111},{\"id\":1112},{\"id\":1113},{\"id\":1114},{\"id\":1115},{\"id\":1116},{\"id\":1117},{\"id\":1118},{\"id\":1119},{\"id\":1120},{\"id\":1121},{\"id\":1122},{\"id\":1123},{\"id\":1124},{\"id\":1125},{\"id\":1126},{\"id\":1127},{\"id\":1128},{\"id\":1129},{\"id\":1130},{\"id\":1131},{\"id\":1132},{\"id\":1133},{\"id\":1134},{\"id\":1135},{\"id\":1136},{\"id\":1137},{\"id\":1138},{\"id\":1139},{\"id\":1140},{\"id\":1141},{\"id\":1142},{\"id\":1143},{\"id\":1144},{\"id\":1145},{\"id\":1146},{\"id\":1147},{\"id\":1148},{\"id\":1149},{\"id\":1150},{\"id\":1151},{\"id\":1152},{\"id\":1153},{\"id\":1154},{\"id\":1155},{\"id\":1156},{\"id\":1157},{\"id\":1158},{\"id\":1159},{\"id\":1160},{\"id\":1161},{\"id\":1162},{\"id\":1163},{\"id\":1164},{\"id\":1165},{\"id\":1166},{\"id\":1167},{\"id\":1168},{\"id\":1169},{\"id\":1170},{\"id\":1171},{\"id\":1172},{\"id\":1173},{\"id\":1174},{\"id\":1175},{\"id\":1176},{\"id\":1177},{\"id\":1178},{\"id\":1179},{\"id\":1180},{\"id\":1181},{\"id\":1182},{\"id\":1183},{\"id\":1184},{\"id\":1185},{\"id\":1186},{\"id\":1187},{\"id\":1188},{\"id\":1189},{\"id\":1190},{\"id\":1191},{\"id\":1192},{\"id\":1193},{\"id\":1194},{\"id\":1195},{\"id\":1196},{\"id\":1197},{\"id\":1198},{\"id\":1199},{\"id\":1200},{\"id\":1201},{\"id\":1202},{\"id\":1203},{\"id\":1204},{\"id\":1205},{\"id\":1206},{\"id\":1207},{\"id\":1208},{\"id\":1209},{\"id\":1210},{\"id\":1211},{\"id\":1212},{\"id\":1213},{\"id\":1214},{\"id\":1215},{\"id\":1216},{\"id\":1217},{\"id\":1218},{\"id\":1219},{\"id\":1220},{\"id\":1221},{\"id\":1222},{\"id\":1223},{\"id\":1224},{\"id\":1225},{\"id\":1226},{\"id\":1227},{\"id\":1228},{\"id\":1229},{\"id\":1230},{\"id\":1231},{\"id\":1232},{\"id\":1233},{\"id\":1234},{\"id\":1235},{\"id\":1236},{\"id\":1237},{\"id\":1238},{\"id\":1239},{\"id\":1240},{\"id\":1241},{\"id\":1242},{\"id\":1243},{\"id\":1244},{\"id\":1245},{\"id\":1246},{\"id\":1247},{\"id\":1248},{\"id\":1249},{\"id\":1250},{\"id\":1251},{\"id\":1252},{\"id\":1253},{\"id\":1254},{\"id\":1255},{\"id\":1256},{\"id\":1257},{\"id\":1258},{\"id\":1259},{\"id\":1260},{\"id\":1261},{\"id\":1262},{\"id\":1263},{\"id\":1264},{\"id\":1265},{\"id\":1266},{\"id\":1267},{\"id\":1268},{\"id\":1269},{\"id\":1270},{\"id\":1271},{\"id\":1272},{\"id\":1273},{\"id\":1274},{\"id\":1275},{\"id\":1276},{\"id\":1277},{\"id\":1278},{\"id\":1279},{\"id\":1280},{\"id\":1281},{\"id\":1282},{\"id\":1283},{\"id\":1284},{\"id\":1285},{\"id\":1286},{\"id\":1287},{\"id\":1288},{\"id\":1289},{\"id\":1290},{\"id\":1291},{\"id\":1292},{\"id\":1293},{\"id\":1294},{\"id\":1295},{\"id\":1296},{\"id\":1297},{\"id\":1298},{\"id\":1299},{\"id\":1300},{\"id\":1301},{\"id\":1302},{\"id\":1303},{\"id\":1304},{\"id\":1305},{\"id\":1306},{\"id\":1307},{\"id\":1308},{\"id\":1309},{\"id\":1310},{\"id\":1311},{\"id\":1312},{\"id\":1313},{\"id\":1314},{\"id\":1315},{\"id\":1316},{\"id\":1317},{\"id\":1318},{\"id\":1319},{\"id\":1320},{\"id\":1321},{\"id\":1322},{\"id\":1323},{\"id\":1324},{\"id\":1325},{\"id\":1326},{\"id\":1327},{\"id\":1328},{\"id\":1329},{\"id\":1330},{\"id\":1331},{\"id\":1332},{\"id\":1333},{\"id\":1334},{\"id\":1335},{\"id\":1336},{\"id\":1337},{\"id\":1338},{\"id\":1339},{\"id\":1340},{\"id\":1341},{\"id\":1342},{\"id\":1343},{\"id\":1344},{\"id\":1345},{\"id\":1346},{\"id\":1347},{\"id\":1348},{\"id\":1349},{\"id\":1350},{\"id\":1351},{\"id\":1352},{\"id\":1353},{\"id\":1354},{\"id\":1355},{\"id\":1356},{\"id\":1357},{\"id\":1358},{\"id\":1359},{\"id\":1360},{\"id\":1361},{\"id\":1362},{\"id\":1363},{\"id\":1364},{\"id\":1365},{\"id\":1366},{\"id\":1367},{\"id\":1368},{\"id\":1369},{\"id\":1370},{\"id\":1371},{\"id\":1372},{\"id\":1373},{\"id\":1374},{\"id\":1375},{\"id\":1376},{\"id\":1377},{\"id\":1378},{\"id\":1379},{\"id\":1380},{\"id\":1381},{\"id\":1382},{\"id\":1383},{\"id\":1384},{\"id\":1385},{\"id\":1386},{\"id\":1387},{\"id\":1388},{\"id\":1389},{\"id\":1390},{\"id\":1391},{\"id\":1392},{\"id\":1393},{\"id\":1394},{\"id\":1395},{\"id\":1396},{\"id\":1397},{\"id\":1398},{\"id\":1399},{\"id\":1400},{\"id\":1401},{\"id\":1402},{\"id\":1403},{\"id\":1404},{\"id\":1405},{\"id\":1406},{\"id\":1407},{\"id\":1408},{\"id\":1409},{\"id\":1410},{\"id\":1411},{\"id\":1412},{\"id\":1413},{\"id\":1414},{\"id\":1415},{\"id\":1416},{\"id\":1417},{\"id\":1418},{\"id\":1419},{\"id\":1420},{\"id\":1421},{\"id\":1422},{\"id\":1423},{\"id\":1424},{\"id\":1425},{\"id\":1426},{\"id\":1427},{\"id\":1428},{\"id\":1429},{\"id\":1430},{\"id\":1431},{\"id\":1432},{\"id\":1433},{\"id\":1434},{\"id\":1435},{\"id\":1436},{\"id\":1437},{\"id\":1438},{\"id\":1439},{\"id\":1440},{\"id\":1441},{\"id\":1442},{\"id\":1443},{\"id\":1444},{\"id\":1445},{\"id\":1446},{\"id\":1447},{\"id\":1448},{\"id\":1449},{\"id\":1450},{\"id\":1451},{\"id\":1452},{\"id\":1453},{\"id\":1454},{\"id\":1455},{\"id\":1456},{\"id\":1457},{\"id\":1458},{\"id\":1459},{\"id\":1460},{\"id\":1461},{\"id\":1462},{\"id\":1463},{\"id\":1464},{\"id\":1465},{\"id\":1466},{\"id\":1467},{\"id\":1468},{\"id\":1469},{\"id\":1470},{\"id\":1471},{\"id\":1472},{\"id\":1473},{\"id\":1474},{\"id\":1475},{\"id\":1476},{\"id\":1477},{\"id\":1478},{\"id\":1479},{\"id\":1480},{\"id\":1481},{\"id\":1482},{\"id\":1483},{\"id\":1484},{\"id\":1485},{\"id\":1486},{\"id\":1487},{\"id\":1488},{\"id\":1489},{\"id\":1490},{\"id\":1491},{\"id\":1492},{\"id\":1493},{\"id\":1494},{\"id\":1495},{\"id\":1496},{\"id\":1497},{\"id\":1498},{\"id\":1499},{\"id\":1500},{\"id\":1501},{\"id\":1502},{\"id\":1503},{\"id\":1504},{\"id\":1505},{\"id\":1506},{\"id\":1507},{\"id\":1508},{\"id\":1509},{\"id\":1510},{\"id\":1511},{\"id\":1512},{\"id\":1513},{\"id\":1514},{\"id\":1515},{\"id\":1516},{\"id\":1517},{\"id\":1518},{\"id\":1519},{\"id\":1520},{\"id\":1521},{\"id\":1522},{\"id\":1523},{\"id\":1524},{\"id\":1525},{\"id\":1526},{\"id\":1527},{\"id\":1528},{\"id\":1529},{\"id\":1530},{\"id\":1531},{\"id\":1532},{\"id\":1533},{\"id\":1534},{\"id\":1535},{\"id\":1536},{\"id\":1537},{\"id\":1538},{\"id\":1539},{\"id\":1540},{\"id\":1541},{\"id\":1542},{\"id\":1543},{\"id\":1544},{\"id\":1545},{\"id\":1546},{\"id\":1547},{\"id\":1548},{\"id\":1549},{\"id\":1550},{\"id\":1551},{\"id\":1552},{\"id\":1553},{\"id\":1554},{\"id\":1555},{\"id\":1556},{\"id\":1557},{\"id\":1558},{\"id\":1559},{\"id\":1560},{\"id\":1561},{\"id\":1562},{\"id\":1563},{\"id\":1564},{\"id\":1565},{\"id\":1566},{\"id\":1567},{\"id\":1568},{\"id\":1569},{\"id\":1570},{\"id\":1571},{\"id\":1572},{\"id\":1573},{\"id\":1574},{\"id\":1575},{\"id\":1576},{\"id\":1577},{\"id\":1578},{\"id\":1579},{\"id\":1580},{\"id\":1581},{\"id\":1582},{\"id\":1583},{\"id\":1584},{\"id\":1585},{\"id\":1586},{\"id\":1587},{\"id\":1588},{\"id\":1589},{\"id\":1590},{\"id\":1591},{\"id\":1592},{\"id\":1593},{\"id\":1594},{\"id\":1595},{\"id\":1596},{\"id\":1597},{\"id\":1598},{\"id\":1599},{\"id\":1600},{\"id\":1601},{\"id\":1602},{\"id\":1603},{\"id\":1604},{\"id\":1605},{\"id\":1606},{\"id\":1607},{\"id\":1608},{\"id\":1609},{\"id\":1610},{\"id\":1611},{\"id\":1612},{\"id\":1613},{\"id\":1614},{\"id\":1615},{\"id\":1616},{\"id\":1617},{\"id\":1618},{\"id\":1619},{\"id\":1620},{\"id\":1621},{\"id\":1622},{\"id\":1623},{\"id\":1624},{\"id\":1625},{\"id\":1626},{\"id\":1627},{\"id\":1628},{\"id\":1629},{\"id\":1630},{\"id\":1631},{\"id\":1632},{\"id\":1633},{\"id\":1634},{\"id\":1635},{\"id\":1636},{\"id\":1637},{\"id\":1638},{\"id\":1639},{\"id\":1640},{\"id\":1641},{\"id\":1642},{\"id\":1643},{\"id\":1644},{\"id\":1645},{\"id\":1646},{\"id\":1647},{\"id\":1648},{\"id\":1649},{\"id\":1650},{\"id\":1651},{\"id\":1652},{\"id\":1653},{\"id\":1654},{\"id\":1655},{\"id\":1656},{\"id\":1657},{\"id\":1658},{\"id\":1659},{\"id\":1660},{\"id\":1661},{\"id\":1662},{\"id\":1663},{\"id\":1664},{\"id\":1665},{\"id\":1666},{\"id\":1667},{\"id\":1668},{\"id\":1669},{\"id\":1670},{\"id\":1671},{\"id\":1672},{\"id\":1673},{\"id\":1674},{\"id\":1675},{\"id\":1676},{\"id\":1677},{\"id\":1678},{\"id\":1679},{\"id\":1680},{\"id\":1681},{\"id\":1682},{\"id\":1683},{\"id\":1684},{\"id\":1685},{\"id\":1686},{\"id\":1687},{\"id\":1688},{\"id\":1689},{\"id\":1690},{\"id\":1691},{\"id\":1692},{\"id\":1693},{\"id\":1694},{\"id\":1695},{\"id\":1696},{\"id\":1697},{\"id\":1698},{\"id\":1699},{\"id\":1700},{\"id\":1701},{\"id\":1702},{\"id\":1703},{\"id\":1704},{\"id\":1705},{\"id\":1706},{\"id\":1707},{\"id\":1708},{\"id\":1709},{\"id\":1710},{\"id\":1711},{\"id\":1712},{\"id\":1713},{\"id\":1714},{\"id\":1715},{\"id\":1716},{\"id\":1717},{\"id\":1718},{\"id\":1719},{\"id\":1720},{\"id\":1721},{\"id\":1722},{\"id\":1723},{\"id\":1724},{\"id\":1725},{\"id\":1726},{\"id\":1727},{\"id\":1728},{\"id\":1729},{\"id\":1730},{\"id\":1731},{\"id\":1732},{\"id\":1733},{\"id\":1734},{\"id\":1735},{\"id\":1736},{\"id\":1737},{\"id\":1738},{\"id\":1739},{\"id\":1740},{\"id\":1741},{\"id\":1742},{\"id\":1743},{\"id\":1744},{\"id\":1745},{\"id\":1746},{\"id\":1747},{\"id\":1748},{\"id\":1749},{\"id\":1750},{\"id\":1751},{\"id\":1752},{\"id\":1753},{\"id\":1754},{\"id\":1755},{\"id\":1756},{\"id\":1757},{\"id\":1758},{\"id\":1759},{\"id\":1760},{\"id\":1761},{\"id\":1762},{\"id\":1763},{\"id\":1764},{\"id\":1765},{\"id\":1766},{\"id\":1767},{\"id\":1768},{\"id\":1769},{\"id\":1770},{\"id\":1771},{\"id\":1772},{\"id\":1773},{\"id\":1774},{\"id\":1775},{\"id\":1776},{\"id\":1777},{\"id\":1778},{\"id\":1779},{\"id\":1780},{\"id\":1781},{\"id\":1782},{\"id\":1783},{\"id\":1784},{\"id\":1785},{\"id\":1786},{\"id\":1787},{\"id\":1788},{\"id\":1789},{\"id\":1790},{\"id\":1791},{\"id\":1792},{\"id\":1793},{\"id\":1794},{\"id\":1795},{\"id\":1796},{\"id\":1797},{\"id\":1798},{\"id\":1799},{\"id\":1800},{\"id\":1801},{\"id\":1802},{\"id\":1803},{\"id\":1804},{\"id\":1805},{\"id\":1806},{\"id\":1807},{\"id\":1808},{\"id\":1809},{\"id\":1810},{\"id\":1811},{\"id\":1812},{\"id\":1813},{\"id\":1814},{\"id\":1815},{\"id\":1816},{\"id\":1817},{\"id\":1818},{\"id\":1819},{\"id\":1820},{\"id\":1821},{\"id\":1822},{\"id\":1823},{\"id\":1824},{\"id\":1825},{\"id\":1826},{\"id\":1827},{\"id\":1828},{\"id\":1829},{\"id\":1830},{\"id\":1831},{\"id\":1832},{\"id\":1833},{\"id\":1834},{\"id\":1835},{\"id\":1836},{\"id\":1837},{\"id\":1838},{\"id\":1839},{\"id\":1840},{\"id\":1841},{\"id\":1842},{\"id\":1843},{\"id\":1844},{\"id\":1845},{\"id\":1846},{\"id\":1847},{\"id\":1848},{\"id\":1849},{\"id\":1850},{\"id\":1851},{\"id\":1852},{\"id\":1853},{\"id\":1854},{\"id\":1855},{\"id\":1856},{\"id\":1857},{\"id\":1858},{\"id\":1859},{\"id\":1860},{\"id\":1861},{\"id\":1862},{\"id\":1863},{\"id\":1864},{\"id\":1865},{\"id\":1866},{\"id\":1867},{\"id\":1868},{\"id\":1869},{\"id\":1870},{\"id\":1871},{\"id\":1872},{\"id\":1873},{\"id\":1874},{\"id\":1875},{\"id\":1876},{\"id\":1877},{\"id\":1878},{\"id\":1879},{\"id\":1880},{\"id\":1881},{\"id\":1882},{\"id\":1883},{\"id\":1884},{\"id\":1885},{\"id\":1886},{\"id\":1887},{\"id\":1888},{\"id\":1889},{\"id\":1890},{\"id\":1891},{\"id\":1892},{\"id\":1893},{\"id\":1894},{\"id\":1895},{\"id\":1896},{\"id\":1897},{\"id\":1898},{\"id\":1899},{\"id\":1900},{\"id\":1901},{\"id\":1902},{\"id\":1903},{\"id\":1904},{\"id\":1905},{\"id\":1906},{\"id\":1907},{\"id\":1908},{\"id\":1909},{\"id\":1910},{\"id\":1911},{\"id\":1912},{\"id\":1913},{\"id\":1914},{\"id\":1915},{\"id\":1916},{\"id\":1917},{\"id\":1918},{\"id\":1919},{\"id\":1920},{\"id\":1921},{\"id\":1922},{\"id\":1923},{\"id\":1924},{\"id\":1925},{\"id\":1926},{\"id\":1927},{\"id\":1928},{\"id\":1929},{\"id\":1930},{\"id\":1931},{\"id\":1932},{\"id\":1933},{\"id\":1934},{\"id\":1935},{\"id\":1936},{\"id\":1937},{\"id\":1938},{\"id\":1939},{\"id\":1940},{\"id\":1941},{\"id\":1942},{\"id\":1943},{\"id\":1944},{\"id\":1945},{\"id\":1946},{\"id\":1947},{\"id\":1948},{\"id\":1949},{\"id\":1950},{\"id\":1951},{\"id\":1952},{\"id\":1953},{\"id\":1954},{\"id\":1955},{\"id\":1956},{\"id\":1957},{\"id\":1958},{\"id\":1959},{\"id\":1960},{\"id\":1961},{\"id\":1962},{\"id\":1963},{\"id\":1964},{\"id\":1965},{\"id\":1966},{\"id\":1967},{\"id\":1968},{\"id\":1969},{\"id\":1970},{\"id\":1971},{\"id\":1972},{\"id\":1973},{\"id\":1974},{\"id\":1975},{\"id\":1976},{\"id\":1977},{\"id\":1978},{\"id\":1979},{\"id\":1980},{\"id\":1981},{\"id\":1982},{\"id\":1983},{\"id\":1984},{\"id\":1985},{\"id\":1986},{\"id\":1987},{\"id\":1988},{\"id\":1989},{\"id\":1990},{\"id\":1991},{\"id\":1992},{\"id\":1993},{\"id\":1994},{\"id\":1995},{\"id\":1996},{\"id\":1997},{\"id\":1998},{\"id\":1999},{\"id\":2000},{\"id\":2001},{\"id\":2002},{\"id\":2003},{\"id\":2004},{\"id\":2005},{\"id\":2006},{\"id\":2007},{\"id\":2008},{\"id\":2009},{\"id\":2010},{\"id\":2011},{\"id\":2012},{\"id\":2013},{\"id\":2014},{\"id\":2015},{\"id\":2016},{\"id\":2017},{\"id\":2018},{\"id\":2019},{\"id\":2020},{\"id\":2021},{\"id\":2022},{\"id\":2023},{\"id\":2024},{\"id\":2025},{\"id\":2026},{\"id\":2027},{\"id\":2028},{\"id\":2029},{\"id\":2030},{\"id\":2031},{\"id\":2032},{\"id\":2033},{\"id\":2034},{\"id\":2035},{\"id\":2036},{\"id\":2037},{\"id\":2038},{\"id\":2039},{\"id\":2040},{\"id\":2041},{\"id\":2042},{\"id\":2043},{\"id\":2044},{\"id\":2045},{\"id\":2046},{\"id\":2047},{\"id\":2048},{\"id\":2049},{\"id\":2050},{\"id\":2051},{\"id\":2052},{\"id\":2053},{\"id\":2054},{\"id\":2055},{\"id\":2056},{\"id\":2057},{\"id\":2058},{\"id\":2059},{\"id\":2060},{\"id\":2061},{\"id\":2062},{\"id\":2063},{\"id\":2064},{\"id\":2065},{\"id\":2066},{\"id\":2067},{\"id\":2068},{\"id\":2069},{\"id\":2070},{\"id\":2071},{\"id\":2072},{\"id\":2073},{\"id\":2074},{\"id\":2075},{\"id\":2076},{\"id\":2077},{\"id\":2078},{\"id\":2079},{\"id\":2080},{\"id\":2081},{\"id\":2082},{\"id\":2083},{\"id\":2084},{\"id\":2085},{\"id\":2086},{\"id\":2087},{\"id\":2088},{\"id\":2089},{\"id\":2090},{\"id\":2091},{\"id\":2092},{\"id\":2093},{\"id\":2094},{\"id\":2095},{\"id\":2096},{\"id\":2097},{\"id\":2098},{\"id\":2099},{\"id\":2100},{\"id\":2101},{\"id\":2102},{\"id\":2103},{\"id\":2104},{\"id\":2105},{\"id\":2106},{\"id\":2107},{\"id\":2108},{\"id\":2109},{\"id\":2110},{\"id\":2111},{\"id\":2112},{\"id\":2113},{\"id\":2114},{\"id\":2115},{\"id\":2116},{\"id\":2117},{\"id\":2118},{\"id\":2119},{\"id\":2120},{\"id\":2121},{\"id\":2122},{\"id\":2123},{\"id\":2124},{\"id\":2125},{\"id\":2126},{\"id\":2127},{\"id\":2128},{\"id\":2129},{\"id\":2130},{\"id\":2131},{\"id\":2132},{\"id\":2133},{\"id\":2134},{\"id\":2135},{\"id\":2136},{\"id\":2137},{\"id\":2138},{\"id\":2139},{\"id\":2140},{\"id\":2141},{\"id\":2142},{\"id\":2143},{\"id\":2144},{\"id\":2145},{\"id\":2146},{\"id\":2147},{\"id\":2148},{\"id\":2149},{\"id\":2150},{\"id\":2151},{\"id\":2152},{\"id\":2153},{\"id\":2154},{\"id\":2155},{\"id\":2156},{\"id\":2157},{\"id\":2158},{\"id\":2159},{\"id\":2160},{\"id\":2161},{\"id\":2162},{\"id\":2163},{\"id\":2164},{\"id\":2165},{\"id\":2166},{\"id\":2167},{\"id\":2168},{\"id\":2169},{\"id\":2170},{\"id\":2171},{\"id\":2172},{\"id\":2173},{\"id\":2174},{\"id\":2175},{\"id\":2176},{\"id\":2177},{\"id\":2178},{\"id\":2179},{\"id\":2180},{\"id\":2181},{\"id\":2182},{\"id\":2183},{\"id\":2184},{\"id\":2185},{\"id\":2186},{\"id\":2187},{\"id\":2188},{\"id\":2189},{\"id\":2190},{\"id\":2191},{\"id\":2192},{\"id\":2193},{\"id\":2194},{\"id\":2195},{\"id\":2196},{\"id\":2197},{\"id\":2198},{\"id\":2199},{\"id\":2200},{\"id\":2201},{\"id\":2202},{\"id\":2203},{\"id\":2204},{\"id\":2205},{\"id\":2206},{\"id\":2207},{\"id\":2208},{\"id\":2209},{\"id\":2210},{\"id\":2211},{\"id\":2212},{\"id\":2213},{\"id\":2214},{\"id\":2215},{\"id\":2216},{\"id\":2217},{\"id\":2218},{\"id\":2219},{\"id\":2220},{\"id\":2221},{\"id\":2222},{\"id\":2223},{\"id\":2224},{\"id\":2225},{\"id\":2226},{\"id\":2227},{\"id\":2228},{\"id\":2229},{\"id\":2230},{\"id\":2231},{\"id\":2232},{\"id\":2233},{\"id\":2234},{\"id\":2235},{\"id\":2236},{\"id\":2237},{\"id\":2238},{\"id\":2239},{\"id\":2240},{\"id\":2241},{\"id\":2242},{\"id\":2243},{\"id\":2244},{\"id\":2245},{\"id\":2246},{\"id\":2247},{\"id\":2248},{\"id\":2249},{\"id\":2250},{\"id\":2251},{\"id\":2252},{\"id\":2253},{\"id\":2254},{\"id\":2255},{\"id\":2256},{\"id\":2257},{\"id\":2258},{\"id\":2259},{\"id\":2260},{\"id\":2261},{\"id\":2262},{\"id\":2263},{\"id\":2264},{\"id\":2265},{\"id\":2266},{\"id\":2267},{\"id\":2268},{\"id\":2269},{\"id\":2270},{\"id\":2271},{\"id\":2272},{\"id\":2273},{\"id\":2274},{\"id\":2275},{\"id\":2276},{\"id\":2277},{\"id\":2278},{\"id\":2279},{\"id\":2280},{\"id\":2281},{\"id\":2282},{\"id\":2283},{\"id\":2284},{\"id\":2285},{\"id\":2286},{\"id\":2287},{\"id\":2288},{\"id\":2289},{\"id\":2290},{\"id\":2291},{\"id\":2292},{\"id\":2293},{\"id\":2294},{\"id\":2295},{\"id\":2296},{\"id\":2297},{\"id\":2298},{\"id\":2299},{\"id\":2300},{\"id\":2301},{\"id\":2302},{\"id\":2303},{\"id\":2304},{\"id\":2305},{\"id\":2306},{\"id\":2307},{\"id\":2308},{\"id\":2309},{\"id\":2310},{\"id\":2311},{\"id\":2312},{\"id\":2313},{\"id\":2314},{\"id\":2315},{\"id\":2316},{\"id\":2317},{\"id\":2318},{\"id\":2319},{\"id\":2320},{\"id\":2321},{\"id\":2322},{\"id\":2323},{\"id\":2324},{\"id\":2325},{\"id\":2326},{\"id\":2327},{\"id\":2328},{\"id\":2329},{\"id\":2330},{\"id\":2331},{\"id\":2332},{\"id\":2333},{\"id\":2334},{\"id\":2335},{\"id\":2336},{\"id\":2337},{\"id\":2338},{\"id\":2339},{\"id\":2340},{\"id\":2341},{\"id\":2342},{\"id\":2343},{\"id\":2344},{\"id\":2345},{\"id\":2346},{\"id\":2347},{\"id\":2348},{\"id\":2349},{\"id\":2350},{\"id\":2351},{\"id\":2352},{\"id\":2353},{\"id\":2354},{\"id\":2355},{\"id\":2356},{\"id\":2357},{\"id\":2358},{\"id\":2359},{\"id\":2360},{\"id\":2361},{\"id\":2362},{\"id\":2363},{\"id\":2364},{\"id\":2365},{\"id\":2366},{\"id\":2367},{\"id\":2368},{\"id\":2369},{\"id\":2370},{\"id\":2371},{\"id\":2372},{\"id\":2373},{\"id\":2374},{\"id\":2375},{\"id\":2376},{\"id\":2377},{\"id\":2378},{\"id\":2379},{\"id\":2380},{\"id\":2381},{\"id\":2382},{\"id\":2383},{\"id\":2384},{\"id\":2385},{\"id\":2386},{\"id\":2387},{\"id\":2388},{\"id\":2389},{\"id\":2390},{\"id\":2391},{\"id\":2392},{\"id\":2393},{\"id\":2394},{\"id\":2395},{\"id\":2396},{\"id\":2397},{\"id\":2398},{\"id\":2399},{\"id\":2400},{\"id\":2401},{\"id\":2402},{\"id\":2403},{\"id\":2404},{\"id\":2405},{\"id\":2406},{\"id\":2407},{\"id\":2408},{\"id\":2409},{\"id\":2410},{\"id\":2411},{\"id\":2412},{\"id\":2413},{\"id\":2414},{\"id\":2415},{\"id\":2416},{\"id\":2417},{\"id\":2418},{\"id\":2419},{\"id\":2420},{\"id\":2421},{\"id\":2422},{\"id\":2423},{\"id\":2424},{\"id\":2425},{\"id\":2426},{\"id\":2427},{\"id\":2428},{\"id\":2429},{\"id\":2430},{\"id\":2431},{\"id\":2432},{\"id\":2433},{\"id\":2434},{\"id\":2435},{\"id\":2436},{\"id\":2437},{\"id\":2438},{\"id\":2439},{\"id\":2440},{\"id\":2441},{\"id\":2442},{\"id\":2443},{\"id\":2444},{\"id\":2445},{\"id\":2446},{\"id\":2447},{\"id\":2448},{\"id\":2449},{\"id\":2450},{\"id\":2451},{\"id\":2452},{\"id\":2453},{\"id\":2454},{\"id\":2455},{\"id\":2456},{\"id\":2457},{\"id\":2458},{\"id\":2459},{\"id\":2460},{\"id\":2461},{\"id\":2462},{\"id\":2463},{\"id\":2464},{\"id\":2465},{\"id\":2466},{\"id\":2467},{\"id\":2468},{\"id\":2469},{\"id\":2470},{\"id\":2471},{\"id\":2472},{\"id\":2473},{\"id\":2474},{\"id\":2475},{\"id\":2476},{\"id\":2477},{\"id\":2478},{\"id\":2479},{\"id\":2480},{\"id\":2481},{\"id\":2482},{\"id\":2483},{\"id\":2484},{\"id\":2485},{\"id\":2486},{\"id\":2487},{\"id\":2488},{\"id\":2489},{\"id\":2490},{\"id\":2491},{\"id\":2492},{\"id\":2493},{\"id\":2494},{\"id\":2495},{\"id\":2496},{\"id\":2497},{\"id\":2498},{\"id\":2499},{\"id\":2500},{\"id\":2501},{\"id\":2502},{\"id\":2503},{\"id\":2504},{\"id\":2505},{\"id\":2506},{\"id\":2507},{\"id\":2508},{\"id\":2509},{\"id\":2510},{\"id\":2511},{\"id\":2512},{\"id\":2513},{\"id\":2514},{\"id\":2515},{\"id\":2516},{\"id\":2517},{\"id\":2518},{\"id\":2519},{\"id\":2520},{\"id\":2521},{\"id\":2522},{\"id\":2523},{\"id\":2524},{\"id\":2525},{\"id\":2526},{\"id\":2527},{\"id\":2528},{\"id\":2529},{\"id\":2530},{\"id\":2531},{\"id\":2532},{\"id\":2533},{\"id\":2534},{\"id\":2535},{\"id\":2536},{\"id\":2537},{\"id\":2538},{\"id\":2539},{\"id\":2540},{\"id\":2541},{\"id\":2542},{\"id\":2543},{\"id\":2544},{\"id\":2545},{\"id\":2546},{\"id\":2547},{\"id\":2548},{\"id\":2549},{\"id\":2550},{\"id\":2551},{\"id\":2552},{\"id\":2553},{\"id\":2554},{\"id\":2555},{\"id\":2556},{\"id\":2557},{\"id\":2558},{\"id\":2559},{\"id\":2560},{\"id\":2561},{\"id\":2562},{\"id\":2563},{\"id\":2564},{\"id\":2565},{\"id\":2566},{\"id\":2567},{\"id\":2568},{\"id\":2569},{\"id\":2570},{\"id\":2571},{\"id\":2572},{\"id\":2573},{\"id\":2574},{\"id\":2575},{\"id\":2576},{\"id\":2577},{\"id\":2578},{\"id\":2579},{\"id\":2580},{\"id\":2581},{\"id\":2582},{\"id\":2583},{\"id\":2584},{\"id\":2585},{\"id\":2586},{\"id\":2587},{\"id\":2588},{\"id\":2589},{\"id\":2590},{\"id\":2591},{\"id\":2592},{\"nodeType\":3,\"id\":2596,\"textContent\":\" // Track clicks on page $(document).ready(function() { $(\\\".control\\\").click(function(e) { e.stopImmediatePropagation(); clicks = clicks + 1; console.log(clicks); }); }); $('.userid').html(sid); // console.log(\\\"start of clicked array: \\\"+clicked); // console.log(\\\"start of hovered string: \\\"+hovered); //set correct answers for each question var triangular_answers = { \\\"acme.starttime.1\\\" : [\\\"F\\\"], \\\"acme.starts.1\\\" : [\\\"K\\\"], \\\"acme.meets.1\\\" : [\\\"F\\\"], \\\"acme.endtime.1\\\" : [\\\"H\\\"], \\\"acme.midpoint.1\\\" : [\\\"O\\\"], \\\"acme.starttime.2\\\" : [\\\"F\\\"], \\\"acme.starts.2\\\" : [\\\"K\\\"], \\\"acme.meets.2\\\" : [\\\"F\\\"], \\\"acme.endtime.2\\\" : [\\\"H\\\"], \\\"acme.midpoint.2\\\" : [\\\"A\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"E\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"E\\\"], \\\"bigset.starttime.1\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.1\\\" : [\\\"G\\\"], \\\"bigset.meets.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.1\\\" : [\\\"X\\\"], \\\"bigset.midpoint.1\\\" : [\\\"K\\\",\\\"X\\\"], \\\"bigset.starttime.2\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.2\\\" : [\\\"G\\\"], \\\"bigset.meets.2\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.2\\\" : [\\\"X\\\"], \\\"bigset.midpoint.2\\\" : [\\\"K\\\",\\\"X\\\"] } var orthogonal_answers = { \\\"acme.starttime.1\\\" : [\\\"A\\\"], \\\"acme.starts.1\\\" : [\\\"E\\\"], \\\"acme.meets.1\\\" : [\\\"Z\\\"], \\\"acme.endtime.1\\\" : [\\\"U\\\"], \\\"acme.midpoint.1\\\" : [\\\"U\\\"], \\\"acme.starttime.2\\\" : [\\\"0\\\"], \\\"acme.starts.2\\\" : [\\\"0\\\"], \\\"acme.meets.2\\\" : [\\\"0\\\"], \\\"acme.endtime.2\\\" : [\\\"0\\\"], \\\"acme.midpoint.2\\\" : [\\\"0\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"X\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"X\\\"], \\\"bigset.starttime.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.1\\\" : [\\\"B\\\"], \\\"bigset.meets.1\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.1\\\" : [\\\"B\\\"], \\\"bigset.midpoint.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.starttime.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.2\\\" : [\\\"B\\\"], \\\"bigset.meets.2\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.2\\\" : [\\\"B\\\"], \\\"bigset.midpoint.2\\\" : [\\\"E\\\",\\\"F\\\"] } //display the question and answer buttons based on input values from jsPsych document.getElementById(scenario+\\\".\\\"+question).style.display = \\\"block\\\"; if (question == \\\"strategy\\\") {document.getElementById(\\\"strategyButton\\\").style.display = \\\"block\\\";} else {document.getElementById(\\\"testingButton\\\").style.display = \\\"block\\\";} //---------SET PROPERTIES OF THE GRAPH -------------// // set the dimensions and margins of the graph var margin = {top: 25, right: 30, bottom: 90, left: 100}, width = 800, height = 800; var intersects = false; //default value for intersects scaffold var xAxisTitle, yAxisTitle; var datafile =\\\"\\\"; // SET AXIS VALUES if (axis == 1){ axis = \\\"Orthogonal-XInside-YFull\\\"; } else if (axis == 2){ axis = \\\"Orthogonal-XInside-YPartial\\\"; } else if (axis ==3){ axis = \\\"Triangular-XInside-YInside\\\"; } else if (axis ==4){ axis = \\\"Orthogonal-XInside-YInside\\\"; } else if (axis ==5){ axis = \\\"Orthogonal-XFull-YFull\\\"; } // SET EXPLICIT SCAFFOLD FEATURES if (explicit ==2 && axis != \\\"diagonal\\\"){ scaffold = 2; intersects = false; } else if (explicit == 2 && axis == \\\"diagonal\\\"){ scaffold = 2; intersects = false; } //TODO: not sure if above two lines are still valid since leaders are now generated on the fly else if (explicit == 3){ $('#hint-interactive').css(\\\"display\\\",\\\"block\\\"); //display textimage scaffold intersects = true; } //SET DATA FILE FOR IMPLICIT SCAFFOLD if (impasse == 1){ datafile = \\\"../views/src/data/acme_nonimpasse.csv\\\"; } else if (impasse == 2){ datafile = \\\"../views/src/data/acme_impasse.csv\\\"; } //OVERRIDE DATA FILE FOR NON-SCAFFOLD QUESTIONS if (q > 5) { //override data file if q# is greater than 5 datafile = \\\"../views/src/data/bigset.csv\\\"; console.log(\\\"override data file\\\"); $('#orthogonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#diagonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#hint-interactive').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold intersects = false; } // //---------CREATE THE SVG ------------------------// var svg = d3.select(\\\".d3container\\\").append(\\\"svg\\\") .attr(\\\"width\\\", width + margin.left + margin.right) .attr(\\\"height\\\", height + margin.top + margin.bottom) .append(\\\"g\\\") .attr(\\\"transform\\\", \\\"translate(\\\" + margin.left + \\\",\\\" + margin.top + \\\")\\\"); //---------DRAW THE GRAPH ------------------------// xAxisTitle = \\\"START & END TIME (time of day)\\\"; yAxisTitle = \\\"DURATION (in hours)\\\"; drawTriangleModel(datafile,intersects,axis,scaffold,q); \"},{\"id\":2593},{\"id\":2594},{\"nodeType\":3,\"id\":2597,\"textContent\":\" //MOUSE LOGGING SCRIPT var mouseLog = [] var xwidth = $(document).width(); var xheight = $(document).width(); mouseLog.push(\\\"{x:\\\"+xwidth+\\\",y:\\\"+xheight+\\\",t:\\\"+\\\"0};\\\") document.onmousemove = function(e){ var pageCoords = \\\"{x:\\\" + e.pageX + \\\",y:\\\"+ e.pageY +\\\",t:\\\"+ Date.now()+ \\\"};\\\" ; mouseLog.push(pageCoords); // console.log(pageCoords); }; \"},{\"id\":2595}],[],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2598,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2599,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2598},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2600,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2599},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2601,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":2600},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2602,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2599}},{\"nodeType\":1,\"id\":2603,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2602},\"parentNode\":{\"id\":2599}},{\"nodeType\":3,\"id\":2604,\"textContent\":\"What is your age?\",\"parentNode\":{\"id\":2602}},{\"nodeType\":1,\"id\":2605,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2600}},{\"nodeType\":1,\"id\":2606,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2605},\"parentNode\":{\"id\":2600}},{\"nodeType\":3,\"id\":2607,\"textContent\":\"In what country were you born?\",\"parentNode\":{\"id\":2605}},{\"nodeType\":3,\"id\":2608,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":2601}}],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2598},{\"id\":2599},{\"id\":2602},{\"id\":2604},{\"id\":2603},{\"id\":2600},{\"id\":2605},{\"id\":2607},{\"id\":2606},{\"id\":2601},{\"id\":2608}],[],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2609,\"tagName\":\"FORM\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-form\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2610,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-preamble\",\"class\":\"jspsych-survey-multi-choice-preamble\"},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2611,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-0\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2610},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2612,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-1\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2611},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2613,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-2\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2612},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2614,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-3\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2613},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2615,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"submit\",\"id\":\"jspsych-survey-multi-choice-next\",\"class\":\"jspsych-survey-multi-choice jspsych-btn\",\"value\":\"Submit Answers\"},\"previousSibling\":{\"id\":2614},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2616,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2617,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2616},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2618,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2617},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2619,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2618},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2620,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2619},\"parentNode\":{\"id\":2611}},{\"nodeType\":3,\"id\":2621,\"textContent\":\"What is your first language?\",\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2622,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2621},\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2623,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2624,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2623}},{\"nodeType\":3,\"id\":2625,\"textContent\":\"English\",\"previousSibling\":{\"id\":2624},\"parentNode\":{\"id\":2623}},{\"nodeType\":1,\"id\":2626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2618}},{\"nodeType\":1,\"id\":2627,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2626}},{\"nodeType\":3,\"id\":2628,\"textContent\":\"Spanish\",\"previousSibling\":{\"id\":2627},\"parentNode\":{\"id\":2626}},{\"nodeType\":1,\"id\":2629,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2619}},{\"nodeType\":1,\"id\":2630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2629}},{\"nodeType\":3,\"id\":2631,\"textContent\":\"Mandarin or Cantonese\",\"previousSibling\":{\"id\":2630},\"parentNode\":{\"id\":2629}},{\"nodeType\":1,\"id\":2632,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2633,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2634,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2633},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2635,\"textContent\":\"*\",\"parentNode\":{\"id\":2622}},{\"nodeType\":1,\"id\":2636,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2637,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2636},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2638,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2637},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2639,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2638},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2640,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2639},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2641,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2640},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2642,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2641},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2643,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2642},\"parentNode\":{\"id\":2612}},{\"nodeType\":3,\"id\":2644,\"textContent\":\"What is your year in school?\",\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2645,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2644},\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2646,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2637}},{\"nodeType\":1,\"id\":2647,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2646}},{\"nodeType\":3,\"id\":2648,\"textContent\":\"First\",\"previousSibling\":{\"id\":2647},\"parentNode\":{\"id\":2646}},{\"nodeType\":1,\"id\":2649,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2638}},{\"nodeType\":1,\"id\":2650,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2649}},{\"nodeType\":3,\"id\":2651,\"textContent\":\"Second\",\"previousSibling\":{\"id\":2650},\"parentNode\":{\"id\":2649}},{\"nodeType\":1,\"id\":2652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2639}},{\"nodeType\":1,\"id\":2653,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2652}},{\"nodeType\":3,\"id\":2654,\"textContent\":\"Third\",\"previousSibling\":{\"id\":2653},\"parentNode\":{\"id\":2652}},{\"nodeType\":1,\"id\":2655,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2640}},{\"nodeType\":1,\"id\":2656,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2655}},{\"nodeType\":3,\"id\":2657,\"textContent\":\"Fourth\",\"previousSibling\":{\"id\":2656},\"parentNode\":{\"id\":2655}},{\"nodeType\":1,\"id\":2658,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2641}},{\"nodeType\":1,\"id\":2659,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2658}},{\"nodeType\":3,\"id\":2660,\"textContent\":\"Fifth\",\"previousSibling\":{\"id\":2659},\"parentNode\":{\"id\":2658}},{\"nodeType\":1,\"id\":2661,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2642}},{\"nodeType\":1,\"id\":2662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2661}},{\"nodeType\":3,\"id\":2663,\"textContent\":\"Graduate\",\"previousSibling\":{\"id\":2662},\"parentNode\":{\"id\":2661}},{\"nodeType\":1,\"id\":2664,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2643}},{\"nodeType\":1,\"id\":2665,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2666,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2665},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2667,\"textContent\":\"*\",\"parentNode\":{\"id\":2645}},{\"nodeType\":1,\"id\":2668,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2669,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2668},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2670,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2669},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2671,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2670},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2672,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2671},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2673,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2672},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2674,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2673},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2675,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2674},\"parentNode\":{\"id\":2613}},{\"nodeType\":3,\"id\":2676,\"textContent\":\"What is your major area of study?\",\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2677,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2676},\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2678,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2669}},{\"nodeType\":1,\"id\":2679,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2678}},{\"nodeType\":3,\"id\":2680,\"textContent\":\"Math or Computer Sciences\",\"previousSibling\":{\"id\":2679},\"parentNode\":{\"id\":2678}},{\"nodeType\":1,\"id\":2681,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2670}},{\"nodeType\":1,\"id\":2682,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2681}},{\"nodeType\":3,\"id\":2683,\"textContent\":\"Social Sciences (incl. CogSci)\",\"previousSibling\":{\"id\":2682},\"parentNode\":{\"id\":2681}},{\"nodeType\":1,\"id\":2684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2671}},{\"nodeType\":1,\"id\":2685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2684}},{\"nodeType\":3,\"id\":2686,\"textContent\":\"Biomedical & Health Sciences\",\"previousSibling\":{\"id\":2685},\"parentNode\":{\"id\":2684}},{\"nodeType\":1,\"id\":2687,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2672}},{\"nodeType\":1,\"id\":2688,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2687}},{\"nodeType\":3,\"id\":2689,\"textContent\":\"Natural Sciences\",\"previousSibling\":{\"id\":2688},\"parentNode\":{\"id\":2687}},{\"nodeType\":1,\"id\":2690,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2673}},{\"nodeType\":1,\"id\":2691,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2690}},{\"nodeType\":3,\"id\":2692,\"textContent\":\"Engineering\",\"previousSibling\":{\"id\":2691},\"parentNode\":{\"id\":2690}},{\"nodeType\":1,\"id\":2693,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2674}},{\"nodeType\":1,\"id\":2694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2693}},{\"nodeType\":3,\"id\":2695,\"textContent\":\"Humanities\",\"previousSibling\":{\"id\":2694},\"parentNode\":{\"id\":2693}},{\"nodeType\":1,\"id\":2696,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2675}},{\"nodeType\":1,\"id\":2697,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2698,\"textContent\":\"Fine Arts\",\"previousSibling\":{\"id\":2697},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2699,\"textContent\":\"*\",\"parentNode\":{\"id\":2677}},{\"nodeType\":1,\"id\":2700,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2701,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2700},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2702,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2701},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2703,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2702},\"parentNode\":{\"id\":2614}},{\"nodeType\":3,\"id\":2704,\"textContent\":\"What is your gender?\",\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2705,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2704},\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2706,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2701}},{\"nodeType\":1,\"id\":2707,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2706}},{\"nodeType\":3,\"id\":2708,\"textContent\":\"Male\",\"previousSibling\":{\"id\":2707},\"parentNode\":{\"id\":2706}},{\"nodeType\":1,\"id\":2709,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2702}},{\"nodeType\":1,\"id\":2710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2709}},{\"nodeType\":3,\"id\":2711,\"textContent\":\"Female\",\"previousSibling\":{\"id\":2710},\"parentNode\":{\"id\":2709}},{\"nodeType\":1,\"id\":2712,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2703}},{\"nodeType\":1,\"id\":2713,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2714,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2713},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2715,\"textContent\":\"*\",\"parentNode\":{\"id\":2705}}],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2609},{\"id\":2610},{\"id\":2611},{\"id\":2616},{\"id\":2621},{\"id\":2622},{\"id\":2635},{\"id\":2617},{\"id\":2623},{\"id\":2624},{\"id\":2625},{\"id\":2618},{\"id\":2626},{\"id\":2627},{\"id\":2628},{\"id\":2619},{\"id\":2629},{\"id\":2630},{\"id\":2631},{\"id\":2620},{\"id\":2632},{\"id\":2633},{\"id\":2634},{\"id\":2612},{\"id\":2636},{\"id\":2644},{\"id\":2645},{\"id\":2667},{\"id\":2637},{\"id\":2646},{\"id\":2647},{\"id\":2648},{\"id\":2638},{\"id\":2649},{\"id\":2650},{\"id\":2651},{\"id\":2639},{\"id\":2652},{\"id\":2653},{\"id\":2654},{\"id\":2640},{\"id\":2655},{\"id\":2656},{\"id\":2657},{\"id\":2641},{\"id\":2658},{\"id\":2659},{\"id\":2660},{\"id\":2642},{\"id\":2661},{\"id\":2662},{\"id\":2663},{\"id\":2643},{\"id\":2664},{\"id\":2665},{\"id\":2666},{\"id\":2613},{\"id\":2668},{\"id\":2676},{\"id\":2677},{\"id\":2699},{\"id\":2669},{\"id\":2678},{\"id\":2679},{\"id\":2680},{\"id\":2670},{\"id\":2681},{\"id\":2682},{\"id\":2683},{\"id\":2671},{\"id\":2684},{\"id\":2685},{\"id\":2686},{\"id\":2672},{\"id\":2687},{\"id\":2688},{\"id\":2689},{\"id\":2673},{\"id\":2690},{\"id\":2691},{\"id\":2692},{\"id\":2674},{\"id\":2693},{\"id\":2694},{\"id\":2695},{\"id\":2675},{\"id\":2696},{\"id\":2697},{\"id\":2698},{\"id\":2614},{\"id\":2700},{\"id\":2704},{\"id\":2705},{\"id\":2715},{\"id\":2701},{\"id\":2706},{\"id\":2707},{\"id\":2708},{\"id\":2702},{\"id\":2709},{\"id\":2710},{\"id\":2711},{\"id\":2703},{\"id\":2712},{\"id\":2713},{\"id\":2714},{\"id\":2615}],[],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2716,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2717,\"textContent\":\" \",\"previousSibling\":{\"id\":2716},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2718,\"textContent\":\" \",\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":2718},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2720,\"textContent\":\" \",\"previousSibling\":{\"id\":2719},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2721,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":2720},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2722,\"textContent\":\" \",\"previousSibling\":{\"id\":2721},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2723,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":2722},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2724,\"textContent\":\" \",\"previousSibling\":{\"id\":2723},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2725,\"textContent\":\" \",\"parentNode\":{\"id\":2719}},{\"nodeType\":1,\"id\":2726,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":2725},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2727,\"textContent\":\" \",\"previousSibling\":{\"id\":2726},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2728,\"textContent\":\" \",\"parentNode\":{\"id\":2726}},{\"nodeType\":1,\"id\":2729,\"tagName\":\"H3\",\"attributes\":{},\"previousSibling\":{\"id\":2728},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2730,\"textContent\":\" \",\"previousSibling\":{\"id\":2729},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2731,\"textContent\":\"DEBRIEFING\",\"parentNode\":{\"id\":2729}},{\"nodeType\":3,\"id\":2732,\"textContent\":\" \",\"parentNode\":{\"id\":2721}},{\"nodeType\":1,\"id\":2733,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":2732},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2734,\"textContent\":\" \",\"previousSibling\":{\"id\":2733},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2735,\"textContent\":\" \",\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2736,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic\"},\"previousSibling\":{\"id\":2735},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2737,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2736},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2738,\"textContent\":\" \",\"previousSibling\":{\"id\":2737},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2739,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2738},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2740,\"textContent\":\" \",\"previousSibling\":{\"id\":2739},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2741,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2740},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2742,\"textContent\":\" \",\"previousSibling\":{\"id\":2741},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2743,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:bold;\"},\"previousSibling\":{\"id\":2742},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2744,\"textContent\":\" \",\"previousSibling\":{\"id\":2743},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2745,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":2744},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2746,\"textContent\":\" \",\"previousSibling\":{\"id\":2745},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2747,\"textContent\":\"Thank you very much for your participation! This debriefing will tell you more about the study, what you did, and why. \",\"parentNode\":{\"id\":2736}},{\"nodeType\":3,\"id\":2748,\"textContent\":\" \",\"parentNode\":{\"id\":2737}},{\"nodeType\":1,\"id\":2749,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2748},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2750,\"textContent\":\" You have just used a series of pictures (charts, graphs and diagrams) accompanied by different types of instructions to answer a series of problem solving questions. While you were using the pictures, we measured where you clicked, scrolled and pointed with the computer mouse. We also measured the accuracy of your responses and the time it took to complete each question.\",\"previousSibling\":{\"id\":2749},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2751,\"textContent\":\"What did you just do?\",\"parentNode\":{\"id\":2749}},{\"nodeType\":3,\"id\":2752,\"textContent\":\" \",\"parentNode\":{\"id\":2739}},{\"nodeType\":1,\"id\":2753,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2752},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2754,\"textContent\":\" Researchers of learning and cognition have long been interested in how graphic displays of information can be used to communicate, solve problems, and generate insights. As powerful as graphics may be in their communicative efficiency, they're not always immediately intuitive to understand. In short, we know a great deal more about learning with representations than we do about the learning of representations. In this project we are building upon previous research on reading and graph comprehension to explore how readers make sense of unfamiliar representations. The instructions you saw for each type of graph are known as “scaffolding techniques”, and we will compare your performance with the scaffolding techniques you saw with the performance of other participants to determine which types of instructions are most effective in helping humans to make sense of unfamiliar graphs. \",\"previousSibling\":{\"id\":2753},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2755,\"textContent\":\"Why did we have you do it?\",\"parentNode\":{\"id\":2753}},{\"nodeType\":1,\"id\":2756,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2757,\"textContent\":\" We expect that you will have found some of the graphics more difficult to use than others. We also expect that with the assistance of the instructions, after solving several problems you will learn to use the difficult graphics so that you can answer the questions even more quickly than without. If you would like to receive a copy of the results of the study, or have any further questions, please contact the researchers Primary Researcher: Amy Fox : a2fox@ucsd.edu Faculty Advisor : Dr. Jim Hollan : hollan@ucsd.edu \",\"previousSibling\":{\"id\":2756},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2758,\"textContent\":\"What do we expect to find?\",\"parentNode\":{\"id\":2756}},{\"nodeType\":3,\"id\":2759,\"textContent\":\"It is important that you do not discuss this experiment with other students who might participate after you. They must participate in the same way as you did, without any knowledge of what the experiment entails, or the reasoning behind it.\",\"parentNode\":{\"id\":2743}},{\"nodeType\":3,\"id\":2760,\"textContent\":\"Thank you for your time! We hope you enjoyed participating in this study as much as we enjoyed designing it.\",\"parentNode\":{\"id\":2745}},{\"nodeType\":3,\"id\":2761,\"textContent\":\" \",\"parentNode\":{\"id\":2723}},{\"nodeType\":1,\"id\":2762,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":2761},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2763,\"textContent\":\" \",\"previousSibling\":{\"id\":2762},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2764,\"textContent\":\"FINISH\",\"parentNode\":{\"id\":2762}}],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2716},{\"id\":2718},{\"id\":2719},{\"id\":2725},{\"id\":2726},{\"id\":2728},{\"id\":2729},{\"id\":2731},{\"id\":2730},{\"id\":2727},{\"id\":2720},{\"id\":2721},{\"id\":2732},{\"id\":2733},{\"id\":2735},{\"id\":2736},{\"id\":2747},{\"id\":2737},{\"id\":2748},{\"id\":2749},{\"id\":2751},{\"id\":2750},{\"id\":2738},{\"id\":2739},{\"id\":2752},{\"id\":2753},{\"id\":2755},{\"id\":2754},{\"id\":2740},{\"id\":2741},{\"id\":2756},{\"id\":2758},{\"id\":2757},{\"id\":2742},{\"id\":2743},{\"id\":2759},{\"id\":2744},{\"id\":2745},{\"id\":2760},{\"id\":2746},{\"id\":2734},{\"id\":2722},{\"id\":2723},{\"id\":2761},{\"id\":2762},{\"id\":2764},{\"id\":2763},{\"id\":2724},{\"id\":2717}],[],[],[]]}"
    },
    {
      "sequence": 8,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2765,\"tagName\":\"PRE\",\"attributes\":{\"id\":\"jspsych-data-display\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2766,\"textContent\":\"[ { \\\"rt\\\": 74262, \\\"stimulus\\\": \\\"img/phone.png\\\", \\\"key_press\\\": 32, \\\"block\\\": \\\"phone\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 0, \\\"time_elapsed\\\": 74265, \\\"internal_node_id\\\": \\\"0.0-0.0\\\", \\\"subject\\\": \\\"DZD6F\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"victor\\\", \\\"condition\\\": \\\"114\\\" }, { \\\"rt\\\": 3205, \\\"url\\\": \\\"../views/src/external/consent.html\\\", \\\"block\\\": \\\"consent\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 1, \\\"time_elapsed\\\": 78845, \\\"internal_node_id\\\": \\\"0.0-1.0\\\", \\\"subject\\\": \\\"DZD6F\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"victor\\\", \\\"condition\\\": \\\"114\\\" }, { \\\"rt\\\": 10161, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"VICTOR\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"114\\\\\\\"}\\\", \\\"block\\\": \\\"codes\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 2, \\\"time_elapsed\\\": 90013, \\\"internal_node_id\\\": \\\"0.0-2.0\\\", \\\"subject\\\": \\\"DZD6F\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"victor\\\", \\\"condition\\\": \\\"114\\\" }, { \\\"rt\\\": 6261, \\\"url\\\": \\\"../views/src/external/instructions_lab.html\\\", \\\"block\\\": \\\"instructions_lab\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 3, \\\"time_elapsed\\\": 97364, \\\"internal_node_id\\\": \\\"0.0-3.0\\\", \\\"subject\\\": \\\"DZD6F\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"victor\\\", \\\"condition\\\": \\\"114\\\" }, { \\\"rt\\\": 7000, \\\"stimulus\\\": \\\"img/acme.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"scenario\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 4, \\\"time_elapsed\\\": 105368, \\\"internal_node_id\\\": \\\"0.0-4.0\\\", \\\"subject\\\": \\\"DZD6F\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"victor\\\", \\\"condition\\\": \\\"114\\\" }, { \\\"rt\\\": 92446, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 5, \\\"time_elapsed\\\": 199188, \\\"internal_node_id\\\": \\\"0.0-5.0-0.0\\\", \\\"subject\\\": \\\"DZD6F\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"victor\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 1, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"Z\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:955,y:1041,t:1527869461901};\\\", \\\"{x:940,y:1019,t:1527869461914};\\\", \\\"{x:830,y:922,t:1527869461930};\\\", \\\"{x:691,y:824,t:1527869461948};\\\", \\\"{x:516,y:661,t:1527869461964};\\\", \\\"{x:382,y:535,t:1527869461982};\\\", \\\"{x:259,y:433,t:1527869461997};\\\", \\\"{x:167,y:366,t:1527869462013};\\\", \\\"{x:112,y:342,t:1527869462032};\\\", \\\"{x:65,y:338,t:1527869462050};\\\", \\\"{x:2,y:342,t:1527869462067};\\\", \\\"{x:0,y:389,t:1527869462082};\\\", \\\"{x:0,y:423,t:1527869462099};\\\", \\\"{x:0,y:446,t:1527869462116};\\\", \\\"{x:0,y:466,t:1527869462132};\\\", \\\"{x:0,y:484,t:1527869462150};\\\", \\\"{x:0,y:496,t:1527869462167};\\\", \\\"{x:0,y:500,t:1527869462183};\\\", \\\"{x:0,y:501,t:1527869462199};\\\", \\\"{x:0,y:502,t:1527869462216};\\\", \\\"{x:7,y:506,t:1527869462233};\\\", \\\"{x:30,y:512,t:1527869462250};\\\", \\\"{x:51,y:518,t:1527869462268};\\\", \\\"{x:73,y:529,t:1527869462283};\\\", \\\"{x:102,y:542,t:1527869462300};\\\", \\\"{x:125,y:553,t:1527869462318};\\\", \\\"{x:152,y:563,t:1527869462333};\\\", \\\"{x:174,y:574,t:1527869462350};\\\", \\\"{x:192,y:583,t:1527869462368};\\\", \\\"{x:200,y:587,t:1527869462382};\\\", \\\"{x:200,y:588,t:1527869462400};\\\", \\\"{x:200,y:589,t:1527869462451};\\\", \\\"{x:200,y:588,t:1527869462466};\\\", \\\"{x:199,y:585,t:1527869462483};\\\", \\\"{x:198,y:585,t:1527869462500};\\\", \\\"{x:194,y:584,t:1527869462531};\\\", \\\"{x:192,y:584,t:1527869462539};\\\", \\\"{x:190,y:584,t:1527869462551};\\\", \\\"{x:186,y:584,t:1527869462567};\\\", \\\"{x:184,y:584,t:1527869462583};\\\", \\\"{x:183,y:584,t:1527869462601};\\\", \\\"{x:181,y:584,t:1527869462616};\\\", \\\"{x:180,y:586,t:1527869462634};\\\", \\\"{x:179,y:586,t:1527869462651};\\\", \\\"{x:175,y:586,t:1527869462667};\\\", \\\"{x:170,y:586,t:1527869462683};\\\", \\\"{x:168,y:587,t:1527869462700};\\\", \\\"{x:167,y:587,t:1527869462788};\\\", \\\"{x:166,y:587,t:1527869462804};\\\", \\\"{x:165,y:586,t:1527869462817};\\\", \\\"{x:160,y:581,t:1527869462835};\\\", \\\"{x:156,y:577,t:1527869462849};\\\", \\\"{x:156,y:574,t:1527869462867};\\\", \\\"{x:156,y:573,t:1527869462898};\\\", \\\"{x:156,y:572,t:1527869462907};\\\", \\\"{x:156,y:571,t:1527869462917};\\\", \\\"{x:156,y:569,t:1527869462934};\\\", \\\"{x:155,y:567,t:1527869462950};\\\", \\\"{x:155,y:566,t:1527869463387};\\\", \\\"{x:153,y:566,t:1527869463401};\\\", \\\"{x:145,y:581,t:1527869463417};\\\", \\\"{x:134,y:605,t:1527869463433};\\\", \\\"{x:102,y:679,t:1527869463451};\\\", \\\"{x:71,y:745,t:1527869463467};\\\", \\\"{x:37,y:798,t:1527869463483};\\\", \\\"{x:4,y:848,t:1527869463501};\\\", \\\"{x:0,y:883,t:1527869463517};\\\", \\\"{x:0,y:905,t:1527869463534};\\\", \\\"{x:0,y:920,t:1527869463551};\\\", \\\"{x:0,y:929,t:1527869463568};\\\", \\\"{x:0,y:933,t:1527869463584};\\\", \\\"{x:0,y:936,t:1527869463601};\\\", \\\"{x:0,y:935,t:1527869505264};\\\", \\\"{x:0,y:942,t:1527869505287};\\\", \\\"{x:0,y:982,t:1527869505302};\\\", \\\"{x:0,y:1049,t:1527869505319};\\\", \\\"{x:0,y:1128,t:1527869505335};\\\", \\\"{x:0,y:1209,t:1527869505352};\\\", \\\"{x:0,y:1215,t:1527869505369};\\\", \\\"{x:5,y:1211,t:1527869505519};\\\", \\\"{x:13,y:1200,t:1527869505532};\\\", \\\"{x:34,y:1168,t:1527869505549};\\\", \\\"{x:62,y:1126,t:1527869505566};\\\", \\\"{x:123,y:1060,t:1527869505589};\\\", \\\"{x:193,y:1025,t:1527869505605};\\\", \\\"{x:259,y:996,t:1527869505622};\\\", \\\"{x:346,y:961,t:1527869505639};\\\", \\\"{x:390,y:942,t:1527869505656};\\\", \\\"{x:416,y:934,t:1527869505672};\\\", \\\"{x:436,y:929,t:1527869505688};\\\", \\\"{x:449,y:924,t:1527869505706};\\\", \\\"{x:453,y:921,t:1527869505722};\\\", \\\"{x:456,y:917,t:1527869505739};\\\", \\\"{x:460,y:903,t:1527869505755};\\\", \\\"{x:463,y:892,t:1527869505772};\\\", \\\"{x:466,y:868,t:1527869505789};\\\", \\\"{x:473,y:842,t:1527869505806};\\\", \\\"{x:489,y:808,t:1527869505822};\\\", \\\"{x:503,y:784,t:1527869505839};\\\", \\\"{x:517,y:763,t:1527869505856};\\\", \\\"{x:528,y:746,t:1527869505872};\\\", \\\"{x:536,y:730,t:1527869505890};\\\", \\\"{x:541,y:719,t:1527869505905};\\\", \\\"{x:543,y:714,t:1527869505921};\\\", \\\"{x:543,y:712,t:1527869505938};\\\", \\\"{x:544,y:711,t:1527869505955};\\\" ] }, { \\\"rt\\\": 20336, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 6, \\\"time_elapsed\\\": 221118, \\\"internal_node_id\\\": \\\"0.0-5.0-1.0\\\", \\\"subject\\\": \\\"DZD6F\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"victor\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 2, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"C\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:543,y:711,t:1527869525047};\\\", \\\"{x:526,y:709,t:1527869525059};\\\", \\\"{x:412,y:674,t:1527869525077};\\\", \\\"{x:249,y:634,t:1527869525093};\\\", \\\"{x:75,y:605,t:1527869525109};\\\", \\\"{x:0,y:569,t:1527869525132};\\\", \\\"{x:0,y:567,t:1527869525148};\\\", \\\"{x:0,y:583,t:1527869525170};\\\", \\\"{x:0,y:609,t:1527869525186};\\\", \\\"{x:0,y:637,t:1527869525203};\\\", \\\"{x:0,y:680,t:1527869525221};\\\", \\\"{x:0,y:691,t:1527869525236};\\\", \\\"{x:0,y:725,t:1527869525253};\\\", \\\"{x:0,y:735,t:1527869525271};\\\", \\\"{x:0,y:741,t:1527869525287};\\\", \\\"{x:1,y:743,t:1527869525303};\\\", \\\"{x:7,y:743,t:1527869525320};\\\", \\\"{x:18,y:743,t:1527869525336};\\\", \\\"{x:34,y:738,t:1527869525354};\\\", \\\"{x:48,y:731,t:1527869525370};\\\", \\\"{x:52,y:727,t:1527869525387};\\\", \\\"{x:54,y:725,t:1527869525404};\\\", \\\"{x:63,y:717,t:1527869525422};\\\", \\\"{x:69,y:713,t:1527869525437};\\\", \\\"{x:89,y:700,t:1527869525454};\\\", \\\"{x:100,y:691,t:1527869525470};\\\", \\\"{x:112,y:682,t:1527869525487};\\\", \\\"{x:125,y:668,t:1527869525504};\\\", \\\"{x:133,y:657,t:1527869525520};\\\", \\\"{x:140,y:646,t:1527869525539};\\\", \\\"{x:145,y:635,t:1527869525554};\\\", \\\"{x:148,y:629,t:1527869525570};\\\", \\\"{x:150,y:625,t:1527869525587};\\\", \\\"{x:151,y:624,t:1527869525603};\\\", \\\"{x:151,y:623,t:1527869525637};\\\", \\\"{x:152,y:621,t:1527869525975};\\\", \\\"{x:153,y:617,t:1527869525988};\\\", \\\"{x:155,y:612,t:1527869526004};\\\", \\\"{x:157,y:606,t:1527869526021};\\\", \\\"{x:157,y:603,t:1527869526037};\\\", \\\"{x:159,y:599,t:1527869526055};\\\", \\\"{x:160,y:597,t:1527869526070};\\\", \\\"{x:160,y:596,t:1527869526087};\\\", \\\"{x:161,y:593,t:1527869526105};\\\", \\\"{x:164,y:588,t:1527869526122};\\\", \\\"{x:166,y:582,t:1527869526138};\\\", \\\"{x:169,y:576,t:1527869526155};\\\", \\\"{x:172,y:572,t:1527869526171};\\\", \\\"{x:175,y:566,t:1527869526188};\\\", \\\"{x:179,y:559,t:1527869526204};\\\", \\\"{x:182,y:553,t:1527869526220};\\\", \\\"{x:184,y:550,t:1527869526237};\\\", \\\"{x:185,y:548,t:1527869526254};\\\", \\\"{x:185,y:546,t:1527869526366};\\\", \\\"{x:184,y:545,t:1527869526373};\\\", \\\"{x:183,y:544,t:1527869526388};\\\", \\\"{x:181,y:540,t:1527869526405};\\\", \\\"{x:178,y:530,t:1527869526423};\\\", \\\"{x:175,y:522,t:1527869526437};\\\", \\\"{x:174,y:515,t:1527869526454};\\\", \\\"{x:174,y:512,t:1527869526472};\\\", \\\"{x:174,y:511,t:1527869526839};\\\", \\\"{x:191,y:524,t:1527869526855};\\\", \\\"{x:227,y:546,t:1527869526874};\\\", \\\"{x:273,y:572,t:1527869526889};\\\", \\\"{x:322,y:601,t:1527869526905};\\\", \\\"{x:392,y:634,t:1527869526922};\\\", \\\"{x:455,y:661,t:1527869526939};\\\", \\\"{x:503,y:684,t:1527869526954};\\\", \\\"{x:535,y:696,t:1527869526971};\\\", \\\"{x:557,y:705,t:1527869526989};\\\", \\\"{x:575,y:715,t:1527869527005};\\\", \\\"{x:591,y:725,t:1527869527021};\\\", \\\"{x:595,y:728,t:1527869527039};\\\", \\\"{x:596,y:728,t:1527869527054};\\\", \\\"{x:593,y:729,t:1527869527158};\\\", \\\"{x:585,y:731,t:1527869527172};\\\", \\\"{x:574,y:734,t:1527869527189};\\\", \\\"{x:560,y:737,t:1527869527206};\\\", \\\"{x:535,y:738,t:1527869527222};\\\", \\\"{x:525,y:739,t:1527869527239};\\\", \\\"{x:524,y:739,t:1527869527256};\\\", \\\"{x:522,y:739,t:1527869527272};\\\", \\\"{x:522,y:738,t:1527869527398};\\\", \\\"{x:522,y:737,t:1527869527405};\\\", \\\"{x:522,y:731,t:1527869527422};\\\", \\\"{x:522,y:730,t:1527869527446};\\\", \\\"{x:522,y:728,t:1527869527590};\\\" ] }, { \\\"rt\\\": 117659, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 7, \\\"time_elapsed\\\": 340029, \\\"internal_node_id\\\": \\\"0.0-5.0-2.0\\\", \\\"subject\\\": \\\"DZD6F\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"victor\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 3, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"Z\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-K -E -G -G -G -B -F \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:522,y:726,t:1527869618469};\\\", \\\"{x:548,y:710,t:1527869618486};\\\", \\\"{x:573,y:695,t:1527869618503};\\\", \\\"{x:591,y:682,t:1527869618519};\\\", \\\"{x:606,y:671,t:1527869618536};\\\", \\\"{x:624,y:657,t:1527869618553};\\\", \\\"{x:647,y:641,t:1527869618570};\\\", \\\"{x:675,y:620,t:1527869618585};\\\", \\\"{x:695,y:603,t:1527869618603};\\\", \\\"{x:730,y:583,t:1527869618620};\\\", \\\"{x:756,y:570,t:1527869618636};\\\", \\\"{x:771,y:564,t:1527869618652};\\\", \\\"{x:781,y:562,t:1527869618668};\\\", \\\"{x:784,y:561,t:1527869618686};\\\", \\\"{x:794,y:558,t:1527869618702};\\\", \\\"{x:804,y:553,t:1527869618720};\\\", \\\"{x:808,y:553,t:1527869618736};\\\", \\\"{x:810,y:553,t:1527869618752};\\\", \\\"{x:811,y:553,t:1527869618771};\\\", \\\"{x:819,y:553,t:1527869618786};\\\", \\\"{x:820,y:553,t:1527869618803};\\\", \\\"{x:823,y:553,t:1527869618819};\\\", \\\"{x:825,y:553,t:1527869618843};\\\", \\\"{x:826,y:553,t:1527869618883};\\\", \\\"{x:827,y:553,t:1527869618908};\\\", \\\"{x:830,y:553,t:1527869618919};\\\", \\\"{x:840,y:558,t:1527869618936};\\\", \\\"{x:850,y:563,t:1527869618952};\\\", \\\"{x:863,y:566,t:1527869618968};\\\", \\\"{x:876,y:573,t:1527869618985};\\\", \\\"{x:899,y:579,t:1527869619002};\\\", \\\"{x:922,y:582,t:1527869619021};\\\", \\\"{x:944,y:583,t:1527869619037};\\\", \\\"{x:959,y:583,t:1527869619053};\\\", \\\"{x:993,y:583,t:1527869619070};\\\", \\\"{x:1020,y:583,t:1527869619087};\\\", \\\"{x:1043,y:583,t:1527869619103};\\\", \\\"{x:1097,y:590,t:1527869619120};\\\", \\\"{x:1178,y:593,t:1527869619137};\\\", \\\"{x:1251,y:606,t:1527869619154};\\\", \\\"{x:1308,y:615,t:1527869619170};\\\", \\\"{x:1363,y:624,t:1527869619188};\\\", \\\"{x:1459,y:634,t:1527869619203};\\\", \\\"{x:1517,y:634,t:1527869619224};\\\", \\\"{x:1562,y:634,t:1527869619237};\\\", \\\"{x:1599,y:634,t:1527869619254};\\\", \\\"{x:1626,y:634,t:1527869619271};\\\", \\\"{x:1648,y:634,t:1527869619287};\\\", \\\"{x:1666,y:634,t:1527869619303};\\\", \\\"{x:1674,y:634,t:1527869619321};\\\", \\\"{x:1676,y:634,t:1527869619338};\\\", \\\"{x:1677,y:634,t:1527869619353};\\\", \\\"{x:1683,y:632,t:1527869619371};\\\", \\\"{x:1699,y:631,t:1527869619387};\\\", \\\"{x:1707,y:627,t:1527869619404};\\\", \\\"{x:1711,y:624,t:1527869619421};\\\", \\\"{x:1714,y:618,t:1527869619439};\\\", \\\"{x:1714,y:607,t:1527869619455};\\\", \\\"{x:1700,y:589,t:1527869619471};\\\", \\\"{x:1677,y:572,t:1527869619488};\\\", \\\"{x:1657,y:563,t:1527869619505};\\\", \\\"{x:1643,y:555,t:1527869619522};\\\", \\\"{x:1639,y:552,t:1527869619538};\\\", \\\"{x:1639,y:551,t:1527869619555};\\\", \\\"{x:1638,y:551,t:1527869619572};\\\", \\\"{x:1638,y:550,t:1527869619588};\\\", \\\"{x:1637,y:550,t:1527869619636};\\\", \\\"{x:1636,y:550,t:1527869619644};\\\", \\\"{x:1635,y:550,t:1527869619655};\\\", \\\"{x:1633,y:550,t:1527869619672};\\\", \\\"{x:1632,y:550,t:1527869619689};\\\", \\\"{x:1631,y:550,t:1527869619707};\\\", \\\"{x:1629,y:550,t:1527869619724};\\\", \\\"{x:1628,y:550,t:1527869619748};\\\", \\\"{x:1626,y:551,t:1527869619764};\\\", \\\"{x:1626,y:552,t:1527869619772};\\\", \\\"{x:1624,y:553,t:1527869619789};\\\", \\\"{x:1624,y:554,t:1527869619806};\\\", \\\"{x:1624,y:555,t:1527869619823};\\\", \\\"{x:1623,y:557,t:1527869619956};\\\", \\\"{x:1621,y:559,t:1527869619973};\\\", \\\"{x:1619,y:561,t:1527869619991};\\\", \\\"{x:1618,y:561,t:1527869620007};\\\", \\\"{x:1617,y:562,t:1527869620027};\\\", \\\"{x:1616,y:565,t:1527869620588};\\\", \\\"{x:1614,y:571,t:1527869620597};\\\", \\\"{x:1614,y:577,t:1527869620610};\\\", \\\"{x:1609,y:591,t:1527869620626};\\\", \\\"{x:1607,y:611,t:1527869620643};\\\", \\\"{x:1604,y:627,t:1527869620659};\\\", \\\"{x:1600,y:649,t:1527869620676};\\\", \\\"{x:1598,y:661,t:1527869620692};\\\", \\\"{x:1597,y:670,t:1527869620709};\\\", \\\"{x:1595,y:679,t:1527869620726};\\\", \\\"{x:1595,y:686,t:1527869620743};\\\", \\\"{x:1595,y:696,t:1527869620760};\\\", \\\"{x:1595,y:707,t:1527869620776};\\\", \\\"{x:1595,y:719,t:1527869620793};\\\", \\\"{x:1594,y:731,t:1527869620809};\\\", \\\"{x:1594,y:746,t:1527869620826};\\\", \\\"{x:1594,y:758,t:1527869620842};\\\", \\\"{x:1594,y:770,t:1527869620859};\\\", \\\"{x:1594,y:775,t:1527869620875};\\\", \\\"{x:1594,y:777,t:1527869620893};\\\", \\\"{x:1594,y:778,t:1527869620923};\\\", \\\"{x:1595,y:777,t:1527869621068};\\\", \\\"{x:1597,y:774,t:1527869621277};\\\", \\\"{x:1599,y:772,t:1527869621292};\\\", \\\"{x:1599,y:771,t:1527869621299};\\\", \\\"{x:1601,y:768,t:1527869621311};\\\", \\\"{x:1603,y:766,t:1527869621329};\\\", \\\"{x:1605,y:763,t:1527869621345};\\\", \\\"{x:1606,y:763,t:1527869621420};\\\", \\\"{x:1606,y:765,t:1527869621428};\\\", \\\"{x:1609,y:773,t:1527869621445};\\\", \\\"{x:1610,y:782,t:1527869621462};\\\", \\\"{x:1611,y:793,t:1527869621479};\\\", \\\"{x:1611,y:804,t:1527869621495};\\\", \\\"{x:1611,y:814,t:1527869621512};\\\", \\\"{x:1611,y:819,t:1527869621530};\\\", \\\"{x:1611,y:823,t:1527869621545};\\\", \\\"{x:1611,y:825,t:1527869621563};\\\", \\\"{x:1611,y:830,t:1527869621579};\\\", \\\"{x:1611,y:835,t:1527869621597};\\\", \\\"{x:1611,y:841,t:1527869621612};\\\", \\\"{x:1612,y:845,t:1527869621629};\\\", \\\"{x:1612,y:850,t:1527869621646};\\\", \\\"{x:1612,y:857,t:1527869621663};\\\", \\\"{x:1612,y:866,t:1527869621680};\\\", \\\"{x:1612,y:874,t:1527869621696};\\\", \\\"{x:1612,y:876,t:1527869621713};\\\", \\\"{x:1612,y:880,t:1527869621730};\\\", \\\"{x:1612,y:881,t:1527869621748};\\\", \\\"{x:1612,y:882,t:1527869621764};\\\", \\\"{x:1613,y:887,t:1527869621779};\\\", \\\"{x:1614,y:891,t:1527869621797};\\\", \\\"{x:1614,y:895,t:1527869621813};\\\", \\\"{x:1614,y:899,t:1527869621830};\\\", \\\"{x:1614,y:905,t:1527869621847};\\\", \\\"{x:1614,y:912,t:1527869621863};\\\", \\\"{x:1614,y:920,t:1527869621880};\\\", \\\"{x:1614,y:927,t:1527869621898};\\\", \\\"{x:1614,y:931,t:1527869621914};\\\", \\\"{x:1614,y:932,t:1527869621930};\\\", \\\"{x:1614,y:933,t:1527869621948};\\\", \\\"{x:1614,y:934,t:1527869621964};\\\", \\\"{x:1614,y:936,t:1527869621980};\\\", \\\"{x:1614,y:938,t:1527869621997};\\\", \\\"{x:1613,y:940,t:1527869622015};\\\", \\\"{x:1613,y:942,t:1527869622032};\\\", \\\"{x:1613,y:946,t:1527869622047};\\\", \\\"{x:1613,y:950,t:1527869622064};\\\", \\\"{x:1613,y:952,t:1527869622081};\\\", \\\"{x:1612,y:953,t:1527869622097};\\\", \\\"{x:1612,y:955,t:1527869622115};\\\", \\\"{x:1611,y:956,t:1527869622131};\\\", \\\"{x:1611,y:957,t:1527869622316};\\\", \\\"{x:1611,y:955,t:1527869622556};\\\", \\\"{x:1611,y:951,t:1527869622567};\\\", \\\"{x:1615,y:937,t:1527869622584};\\\", \\\"{x:1618,y:921,t:1527869622599};\\\", \\\"{x:1622,y:901,t:1527869622616};\\\", \\\"{x:1626,y:880,t:1527869622633};\\\", \\\"{x:1629,y:858,t:1527869622649};\\\", \\\"{x:1632,y:840,t:1527869622666};\\\", \\\"{x:1635,y:827,t:1527869622684};\\\", \\\"{x:1636,y:819,t:1527869622700};\\\", \\\"{x:1637,y:818,t:1527869622716};\\\", \\\"{x:1638,y:814,t:1527869622734};\\\", \\\"{x:1639,y:811,t:1527869622750};\\\", \\\"{x:1640,y:801,t:1527869622766};\\\", \\\"{x:1641,y:790,t:1527869622784};\\\", \\\"{x:1643,y:782,t:1527869622801};\\\", \\\"{x:1643,y:773,t:1527869622818};\\\", \\\"{x:1645,y:767,t:1527869622833};\\\", \\\"{x:1645,y:759,t:1527869622850};\\\", \\\"{x:1645,y:753,t:1527869622868};\\\", \\\"{x:1647,y:741,t:1527869622885};\\\", \\\"{x:1648,y:731,t:1527869622901};\\\", \\\"{x:1649,y:729,t:1527869622917};\\\", \\\"{x:1650,y:729,t:1527869622934};\\\", \\\"{x:1651,y:729,t:1527869623125};\\\", \\\"{x:1651,y:730,t:1527869623134};\\\", \\\"{x:1652,y:735,t:1527869623152};\\\", \\\"{x:1652,y:740,t:1527869623168};\\\", \\\"{x:1654,y:745,t:1527869623185};\\\", \\\"{x:1654,y:748,t:1527869623202};\\\", \\\"{x:1654,y:752,t:1527869623218};\\\", \\\"{x:1655,y:756,t:1527869623236};\\\", \\\"{x:1655,y:757,t:1527869623253};\\\", \\\"{x:1655,y:758,t:1527869623269};\\\", \\\"{x:1655,y:760,t:1527869623308};\\\", \\\"{x:1655,y:763,t:1527869623319};\\\", \\\"{x:1653,y:771,t:1527869623334};\\\", \\\"{x:1652,y:783,t:1527869623351};\\\", \\\"{x:1650,y:795,t:1527869623369};\\\", \\\"{x:1648,y:811,t:1527869623385};\\\", \\\"{x:1644,y:826,t:1527869623401};\\\", \\\"{x:1639,y:854,t:1527869623419};\\\", \\\"{x:1636,y:875,t:1527869623435};\\\", \\\"{x:1632,y:889,t:1527869623452};\\\", \\\"{x:1628,y:904,t:1527869623469};\\\", \\\"{x:1626,y:909,t:1527869623486};\\\", \\\"{x:1625,y:913,t:1527869623502};\\\", \\\"{x:1624,y:915,t:1527869623519};\\\", \\\"{x:1624,y:917,t:1527869623536};\\\", \\\"{x:1624,y:918,t:1527869623553};\\\", \\\"{x:1623,y:921,t:1527869623569};\\\", \\\"{x:1622,y:927,t:1527869623586};\\\", \\\"{x:1620,y:939,t:1527869623603};\\\", \\\"{x:1619,y:947,t:1527869623620};\\\", \\\"{x:1618,y:951,t:1527869623636};\\\", \\\"{x:1617,y:956,t:1527869623653};\\\", \\\"{x:1617,y:954,t:1527869623740};\\\", \\\"{x:1617,y:951,t:1527869623753};\\\", \\\"{x:1621,y:940,t:1527869623770};\\\", \\\"{x:1628,y:926,t:1527869623787};\\\", \\\"{x:1631,y:922,t:1527869623804};\\\", \\\"{x:1633,y:920,t:1527869623820};\\\", \\\"{x:1634,y:920,t:1527869623876};\\\", \\\"{x:1636,y:922,t:1527869623887};\\\", \\\"{x:1639,y:932,t:1527869623904};\\\", \\\"{x:1644,y:941,t:1527869623921};\\\", \\\"{x:1647,y:950,t:1527869623938};\\\", \\\"{x:1647,y:957,t:1527869623954};\\\", \\\"{x:1647,y:960,t:1527869623972};\\\", \\\"{x:1647,y:962,t:1527869624053};\\\", \\\"{x:1647,y:963,t:1527869624068};\\\", \\\"{x:1647,y:965,t:1527869624076};\\\", \\\"{x:1647,y:964,t:1527869624437};\\\", \\\"{x:1647,y:962,t:1527869624444};\\\", \\\"{x:1647,y:959,t:1527869624460};\\\", \\\"{x:1647,y:957,t:1527869624473};\\\", \\\"{x:1647,y:953,t:1527869624489};\\\", \\\"{x:1648,y:949,t:1527869624506};\\\", \\\"{x:1650,y:940,t:1527869624523};\\\", \\\"{x:1650,y:934,t:1527869624539};\\\", \\\"{x:1648,y:924,t:1527869624557};\\\", \\\"{x:1643,y:913,t:1527869624573};\\\", \\\"{x:1641,y:910,t:1527869624591};\\\", \\\"{x:1640,y:901,t:1527869624607};\\\", \\\"{x:1640,y:893,t:1527869624623};\\\", \\\"{x:1640,y:887,t:1527869624640};\\\", \\\"{x:1640,y:880,t:1527869624657};\\\", \\\"{x:1640,y:868,t:1527869624674};\\\", \\\"{x:1640,y:861,t:1527869624691};\\\", \\\"{x:1640,y:850,t:1527869624707};\\\", \\\"{x:1640,y:836,t:1527869624724};\\\", \\\"{x:1640,y:827,t:1527869624740};\\\", \\\"{x:1640,y:824,t:1527869624758};\\\", \\\"{x:1641,y:820,t:1527869624774};\\\", \\\"{x:1641,y:817,t:1527869624791};\\\", \\\"{x:1642,y:814,t:1527869624808};\\\", \\\"{x:1643,y:811,t:1527869624824};\\\", \\\"{x:1643,y:808,t:1527869624842};\\\", \\\"{x:1644,y:805,t:1527869624857};\\\", \\\"{x:1644,y:799,t:1527869624875};\\\", \\\"{x:1645,y:793,t:1527869624892};\\\", \\\"{x:1646,y:787,t:1527869624907};\\\", \\\"{x:1647,y:782,t:1527869624924};\\\", \\\"{x:1648,y:779,t:1527869624942};\\\", \\\"{x:1648,y:778,t:1527869624958};\\\", \\\"{x:1648,y:777,t:1527869625116};\\\", \\\"{x:1648,y:776,t:1527869625131};\\\", \\\"{x:1648,y:775,t:1527869625163};\\\", \\\"{x:1648,y:773,t:1527869625332};\\\", \\\"{x:1648,y:772,t:1527869625342};\\\", \\\"{x:1648,y:769,t:1527869625359};\\\", \\\"{x:1648,y:765,t:1527869625377};\\\", \\\"{x:1649,y:762,t:1527869625393};\\\", \\\"{x:1649,y:759,t:1527869625409};\\\", \\\"{x:1649,y:758,t:1527869625426};\\\", \\\"{x:1650,y:758,t:1527869626068};\\\", \\\"{x:1652,y:759,t:1527869626078};\\\", \\\"{x:1657,y:769,t:1527869626096};\\\", \\\"{x:1662,y:785,t:1527869626113};\\\", \\\"{x:1667,y:805,t:1527869626129};\\\", \\\"{x:1676,y:826,t:1527869626145};\\\", \\\"{x:1684,y:843,t:1527869626162};\\\", \\\"{x:1689,y:854,t:1527869626179};\\\", \\\"{x:1689,y:852,t:1527869626436};\\\", \\\"{x:1689,y:849,t:1527869626446};\\\", \\\"{x:1689,y:844,t:1527869626463};\\\", \\\"{x:1689,y:838,t:1527869626480};\\\", \\\"{x:1689,y:833,t:1527869626496};\\\", \\\"{x:1689,y:828,t:1527869626513};\\\", \\\"{x:1689,y:827,t:1527869626530};\\\", \\\"{x:1689,y:826,t:1527869631940};\\\", \\\"{x:1688,y:825,t:1527869631950};\\\", \\\"{x:1685,y:824,t:1527869631967};\\\", \\\"{x:1683,y:823,t:1527869631984};\\\", \\\"{x:1682,y:823,t:1527869631999};\\\", \\\"{x:1681,y:823,t:1527869632828};\\\", \\\"{x:1680,y:823,t:1527869632851};\\\", \\\"{x:1679,y:823,t:1527869633819};\\\", \\\"{x:1678,y:824,t:1527869633826};\\\", \\\"{x:1677,y:824,t:1527869633839};\\\", \\\"{x:1675,y:824,t:1527869633856};\\\", \\\"{x:1672,y:825,t:1527869633873};\\\", \\\"{x:1671,y:825,t:1527869633890};\\\", \\\"{x:1671,y:826,t:1527869633906};\\\", \\\"{x:1670,y:827,t:1527869634900};\\\", \\\"{x:1668,y:827,t:1527869634911};\\\", \\\"{x:1662,y:827,t:1527869634928};\\\", \\\"{x:1656,y:830,t:1527869634944};\\\", \\\"{x:1648,y:832,t:1527869634961};\\\", \\\"{x:1638,y:833,t:1527869634978};\\\", \\\"{x:1629,y:834,t:1527869634995};\\\", \\\"{x:1619,y:836,t:1527869635010};\\\", \\\"{x:1610,y:837,t:1527869635027};\\\", \\\"{x:1602,y:839,t:1527869635045};\\\", \\\"{x:1594,y:840,t:1527869635061};\\\", \\\"{x:1588,y:840,t:1527869635078};\\\", \\\"{x:1580,y:840,t:1527869635095};\\\", \\\"{x:1571,y:840,t:1527869635112};\\\", \\\"{x:1563,y:840,t:1527869635128};\\\", \\\"{x:1550,y:840,t:1527869635144};\\\", \\\"{x:1538,y:840,t:1527869635162};\\\", \\\"{x:1526,y:840,t:1527869635179};\\\", \\\"{x:1509,y:840,t:1527869635195};\\\", \\\"{x:1490,y:840,t:1527869635211};\\\", \\\"{x:1475,y:840,t:1527869635229};\\\", \\\"{x:1460,y:840,t:1527869635245};\\\", \\\"{x:1446,y:840,t:1527869635262};\\\", \\\"{x:1436,y:840,t:1527869635279};\\\", \\\"{x:1432,y:840,t:1527869635296};\\\", \\\"{x:1430,y:840,t:1527869635312};\\\", \\\"{x:1429,y:840,t:1527869637196};\\\", \\\"{x:1428,y:840,t:1527869637203};\\\", \\\"{x:1426,y:840,t:1527869637219};\\\", \\\"{x:1422,y:840,t:1527869637236};\\\", \\\"{x:1420,y:840,t:1527869637253};\\\", \\\"{x:1419,y:840,t:1527869637508};\\\", \\\"{x:1418,y:839,t:1527869637520};\\\", \\\"{x:1418,y:837,t:1527869637536};\\\", \\\"{x:1416,y:833,t:1527869637553};\\\", \\\"{x:1416,y:830,t:1527869637570};\\\", \\\"{x:1416,y:827,t:1527869637586};\\\", \\\"{x:1416,y:823,t:1527869637603};\\\", \\\"{x:1415,y:818,t:1527869637620};\\\", \\\"{x:1415,y:817,t:1527869637636};\\\", \\\"{x:1414,y:816,t:1527869637653};\\\", \\\"{x:1411,y:810,t:1527869637671};\\\", \\\"{x:1410,y:807,t:1527869637686};\\\", \\\"{x:1410,y:803,t:1527869637703};\\\", \\\"{x:1408,y:800,t:1527869637721};\\\", \\\"{x:1405,y:792,t:1527869637737};\\\", \\\"{x:1402,y:788,t:1527869637754};\\\", \\\"{x:1400,y:781,t:1527869637771};\\\", \\\"{x:1399,y:776,t:1527869637786};\\\", \\\"{x:1396,y:772,t:1527869637804};\\\", \\\"{x:1395,y:768,t:1527869637820};\\\", \\\"{x:1393,y:764,t:1527869637838};\\\", \\\"{x:1392,y:762,t:1527869637855};\\\", \\\"{x:1391,y:761,t:1527869637870};\\\", \\\"{x:1391,y:760,t:1527869637888};\\\", \\\"{x:1389,y:758,t:1527869637904};\\\", \\\"{x:1388,y:756,t:1527869637924};\\\", \\\"{x:1387,y:756,t:1527869637940};\\\", \\\"{x:1386,y:755,t:1527869637955};\\\", \\\"{x:1384,y:755,t:1527869638011};\\\", \\\"{x:1383,y:755,t:1527869638076};\\\", \\\"{x:1381,y:755,t:1527869638156};\\\", \\\"{x:1380,y:755,t:1527869639036};\\\", \\\"{x:1379,y:755,t:1527869639051};\\\", \\\"{x:1378,y:755,t:1527869639059};\\\", \\\"{x:1377,y:756,t:1527869639075};\\\", \\\"{x:1375,y:757,t:1527869639092};\\\", \\\"{x:1373,y:759,t:1527869639109};\\\", \\\"{x:1372,y:760,t:1527869639129};\\\", \\\"{x:1372,y:759,t:1527869641988};\\\", \\\"{x:1371,y:759,t:1527869642114};\\\", \\\"{x:1369,y:760,t:1527869642130};\\\", \\\"{x:1368,y:761,t:1527869642138};\\\", \\\"{x:1367,y:762,t:1527869642153};\\\", \\\"{x:1367,y:763,t:1527869642169};\\\", \\\"{x:1363,y:766,t:1527869642187};\\\", \\\"{x:1362,y:766,t:1527869642202};\\\", \\\"{x:1362,y:767,t:1527869642298};\\\", \\\"{x:1361,y:767,t:1527869642955};\\\", \\\"{x:1360,y:767,t:1527869642971};\\\", \\\"{x:1360,y:768,t:1527869642979};\\\", \\\"{x:1359,y:769,t:1527869642990};\\\", \\\"{x:1358,y:770,t:1527869643011};\\\", \\\"{x:1357,y:770,t:1527869643027};\\\", \\\"{x:1357,y:771,t:1527869643051};\\\", \\\"{x:1356,y:773,t:1527869643066};\\\", \\\"{x:1355,y:773,t:1527869643074};\\\", \\\"{x:1354,y:775,t:1527869643090};\\\", \\\"{x:1351,y:779,t:1527869643107};\\\", \\\"{x:1351,y:780,t:1527869643124};\\\", \\\"{x:1350,y:781,t:1527869643139};\\\", \\\"{x:1350,y:782,t:1527869643156};\\\", \\\"{x:1348,y:782,t:1527869644228};\\\", \\\"{x:1329,y:784,t:1527869644244};\\\", \\\"{x:1299,y:787,t:1527869644261};\\\", \\\"{x:1250,y:791,t:1527869644278};\\\", \\\"{x:1177,y:795,t:1527869644294};\\\", \\\"{x:1096,y:795,t:1527869644311};\\\", \\\"{x:1016,y:795,t:1527869644328};\\\", \\\"{x:935,y:795,t:1527869644345};\\\", \\\"{x:865,y:795,t:1527869644360};\\\", \\\"{x:799,y:795,t:1527869644378};\\\", \\\"{x:729,y:795,t:1527869644395};\\\", \\\"{x:689,y:795,t:1527869644411};\\\", \\\"{x:662,y:795,t:1527869644428};\\\", \\\"{x:646,y:795,t:1527869644445};\\\", \\\"{x:635,y:795,t:1527869644462};\\\", \\\"{x:624,y:795,t:1527869644478};\\\", \\\"{x:611,y:795,t:1527869644495};\\\", \\\"{x:592,y:795,t:1527869644512};\\\", \\\"{x:564,y:790,t:1527869644528};\\\", \\\"{x:526,y:783,t:1527869644544};\\\", \\\"{x:473,y:776,t:1527869644562};\\\", \\\"{x:417,y:763,t:1527869644579};\\\", \\\"{x:386,y:753,t:1527869644595};\\\", \\\"{x:359,y:741,t:1527869644612};\\\", \\\"{x:322,y:730,t:1527869644628};\\\", \\\"{x:284,y:720,t:1527869644646};\\\", \\\"{x:247,y:708,t:1527869644661};\\\", \\\"{x:220,y:700,t:1527869644679};\\\", \\\"{x:204,y:696,t:1527869644695};\\\", \\\"{x:200,y:693,t:1527869644713};\\\", \\\"{x:195,y:692,t:1527869644729};\\\", \\\"{x:188,y:688,t:1527869644746};\\\", \\\"{x:184,y:685,t:1527869644763};\\\", \\\"{x:183,y:680,t:1527869644779};\\\", \\\"{x:183,y:675,t:1527869644796};\\\", \\\"{x:183,y:671,t:1527869644813};\\\", \\\"{x:183,y:665,t:1527869644830};\\\", \\\"{x:183,y:658,t:1527869644846};\\\", \\\"{x:187,y:649,t:1527869644865};\\\", \\\"{x:192,y:642,t:1527869644880};\\\", \\\"{x:200,y:636,t:1527869644896};\\\", \\\"{x:203,y:633,t:1527869644905};\\\", \\\"{x:206,y:628,t:1527869644921};\\\", \\\"{x:210,y:624,t:1527869644938};\\\", \\\"{x:210,y:622,t:1527869644955};\\\", \\\"{x:210,y:621,t:1527869645139};\\\", \\\"{x:209,y:616,t:1527869645157};\\\", \\\"{x:204,y:608,t:1527869645172};\\\", \\\"{x:199,y:597,t:1527869645191};\\\", \\\"{x:196,y:587,t:1527869645206};\\\", \\\"{x:194,y:576,t:1527869645224};\\\", \\\"{x:193,y:567,t:1527869645240};\\\", \\\"{x:189,y:555,t:1527869645257};\\\", \\\"{x:187,y:548,t:1527869645273};\\\", \\\"{x:184,y:537,t:1527869645291};\\\", \\\"{x:182,y:533,t:1527869645308};\\\", \\\"{x:182,y:529,t:1527869645324};\\\", \\\"{x:181,y:527,t:1527869645340};\\\", \\\"{x:180,y:527,t:1527869645460};\\\", \\\"{x:179,y:528,t:1527869645473};\\\", \\\"{x:178,y:534,t:1527869645491};\\\", \\\"{x:178,y:539,t:1527869645508};\\\", \\\"{x:177,y:541,t:1527869645523};\\\", \\\"{x:177,y:546,t:1527869645541};\\\", \\\"{x:177,y:547,t:1527869645556};\\\", \\\"{x:177,y:551,t:1527869645574};\\\", \\\"{x:177,y:552,t:1527869645591};\\\", \\\"{x:177,y:553,t:1527869645607};\\\", \\\"{x:177,y:554,t:1527869645843};\\\", \\\"{x:185,y:554,t:1527869646074};\\\", \\\"{x:238,y:567,t:1527869646091};\\\", \\\"{x:311,y:577,t:1527869646108};\\\", \\\"{x:403,y:595,t:1527869646125};\\\", \\\"{x:492,y:606,t:1527869646141};\\\", \\\"{x:575,y:629,t:1527869646158};\\\", \\\"{x:635,y:651,t:1527869646175};\\\", \\\"{x:691,y:678,t:1527869646191};\\\", \\\"{x:731,y:700,t:1527869646207};\\\", \\\"{x:757,y:717,t:1527869646225};\\\", \\\"{x:766,y:727,t:1527869646242};\\\", \\\"{x:767,y:733,t:1527869646258};\\\", \\\"{x:763,y:740,t:1527869646274};\\\", \\\"{x:750,y:741,t:1527869646291};\\\", \\\"{x:732,y:744,t:1527869646307};\\\", \\\"{x:722,y:745,t:1527869646326};\\\", \\\"{x:717,y:746,t:1527869646341};\\\", \\\"{x:714,y:746,t:1527869646358};\\\", \\\"{x:706,y:746,t:1527869646374};\\\", \\\"{x:689,y:746,t:1527869646392};\\\", \\\"{x:665,y:746,t:1527869646408};\\\", \\\"{x:639,y:742,t:1527869646424};\\\", \\\"{x:617,y:735,t:1527869646441};\\\", \\\"{x:599,y:727,t:1527869646457};\\\", \\\"{x:572,y:714,t:1527869646474};\\\", \\\"{x:562,y:706,t:1527869646493};\\\", \\\"{x:557,y:702,t:1527869646507};\\\", \\\"{x:554,y:698,t:1527869646525};\\\", \\\"{x:554,y:697,t:1527869646542};\\\", \\\"{x:554,y:695,t:1527869646559};\\\", \\\"{x:552,y:696,t:1527869646788};\\\", \\\"{x:551,y:700,t:1527869646795};\\\", \\\"{x:551,y:703,t:1527869646810};\\\", \\\"{x:550,y:707,t:1527869646824};\\\", \\\"{x:549,y:709,t:1527869646841};\\\", \\\"{x:548,y:711,t:1527869646857};\\\", \\\"{x:548,y:712,t:1527869646875};\\\" ] }, { \\\"rt\\\": 39826, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 8, \\\"time_elapsed\\\": 381427, \\\"internal_node_id\\\": \\\"0.0-5.0-3.0\\\", \\\"subject\\\": \\\"DZD6F\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"victor\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 4, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"U\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:548,y:714,t:1527869649275};\\\", \\\"{x:549,y:717,t:1527869649290};\\\", \\\"{x:564,y:722,t:1527869649308};\\\", \\\"{x:581,y:726,t:1527869649325};\\\", \\\"{x:600,y:733,t:1527869649340};\\\", \\\"{x:616,y:739,t:1527869649361};\\\", \\\"{x:622,y:743,t:1527869649377};\\\", \\\"{x:643,y:749,t:1527869649394};\\\", \\\"{x:661,y:757,t:1527869649410};\\\", \\\"{x:666,y:759,t:1527869649426};\\\", \\\"{x:676,y:760,t:1527869649443};\\\", \\\"{x:679,y:762,t:1527869649461};\\\", \\\"{x:682,y:762,t:1527869649476};\\\", \\\"{x:681,y:758,t:1527869659267};\\\", \\\"{x:680,y:748,t:1527869659285};\\\", \\\"{x:686,y:732,t:1527869659302};\\\", \\\"{x:694,y:726,t:1527869659319};\\\", \\\"{x:697,y:723,t:1527869659336};\\\", \\\"{x:697,y:721,t:1527869659355};\\\", \\\"{x:698,y:719,t:1527869659368};\\\", \\\"{x:701,y:711,t:1527869659386};\\\", \\\"{x:712,y:688,t:1527869659402};\\\", \\\"{x:717,y:678,t:1527869659418};\\\", \\\"{x:724,y:655,t:1527869659435};\\\", \\\"{x:724,y:645,t:1527869659454};\\\", \\\"{x:724,y:637,t:1527869659468};\\\", \\\"{x:720,y:630,t:1527869659485};\\\", \\\"{x:714,y:622,t:1527869659502};\\\", \\\"{x:702,y:614,t:1527869659519};\\\", \\\"{x:688,y:607,t:1527869659535};\\\", \\\"{x:671,y:601,t:1527869659551};\\\", \\\"{x:650,y:595,t:1527869659568};\\\", \\\"{x:633,y:591,t:1527869659585};\\\", \\\"{x:620,y:589,t:1527869659602};\\\", \\\"{x:617,y:589,t:1527869659618};\\\", \\\"{x:616,y:589,t:1527869659635};\\\", \\\"{x:615,y:589,t:1527869659674};\\\", \\\"{x:614,y:589,t:1527869659685};\\\", \\\"{x:613,y:589,t:1527869659702};\\\", \\\"{x:612,y:590,t:1527869659719};\\\", \\\"{x:612,y:591,t:1527869659858};\\\", \\\"{x:612,y:591,t:1527869659878};\\\", \\\"{x:612,y:592,t:1527869685902};\\\", \\\"{x:607,y:608,t:1527869685915};\\\", \\\"{x:595,y:650,t:1527869685934};\\\", \\\"{x:587,y:676,t:1527869685948};\\\", \\\"{x:582,y:691,t:1527869685965};\\\", \\\"{x:578,y:706,t:1527869685976};\\\", \\\"{x:573,y:718,t:1527869685993};\\\", \\\"{x:572,y:726,t:1527869686010};\\\", \\\"{x:570,y:732,t:1527869686027};\\\", \\\"{x:569,y:734,t:1527869686044};\\\", \\\"{x:566,y:738,t:1527869686060};\\\", \\\"{x:564,y:743,t:1527869686077};\\\", \\\"{x:562,y:749,t:1527869686094};\\\", \\\"{x:561,y:750,t:1527869686110};\\\", \\\"{x:560,y:750,t:1527869686198};\\\", \\\"{x:559,y:750,t:1527869686210};\\\", \\\"{x:554,y:748,t:1527869686227};\\\", \\\"{x:550,y:742,t:1527869686244};\\\", \\\"{x:546,y:737,t:1527869686260};\\\", \\\"{x:543,y:732,t:1527869686278};\\\", \\\"{x:538,y:727,t:1527869686294};\\\", \\\"{x:534,y:724,t:1527869686310};\\\", \\\"{x:531,y:722,t:1527869686326};\\\", \\\"{x:528,y:719,t:1527869686343};\\\", \\\"{x:524,y:713,t:1527869686360};\\\", \\\"{x:520,y:705,t:1527869686376};\\\", \\\"{x:519,y:702,t:1527869686393};\\\", \\\"{x:518,y:700,t:1527869686411};\\\", \\\"{x:518,y:701,t:1527869688159};\\\", \\\"{x:518,y:709,t:1527869688178};\\\", \\\"{x:521,y:713,t:1527869688195};\\\", \\\"{x:522,y:717,t:1527869688212};\\\", \\\"{x:524,y:720,t:1527869688229};\\\", \\\"{x:524,y:721,t:1527869688245};\\\", \\\"{x:524,y:723,t:1527869688261};\\\", \\\"{x:524,y:724,t:1527869688293};\\\", \\\"{x:525,y:724,t:1527869688325};\\\", \\\"{x:525,y:724,t:1527869688409};\\\" ] }, { \\\"rt\\\": 82976, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 9, \\\"time_elapsed\\\": 465620, \\\"internal_node_id\\\": \\\"0.0-5.0-4.0\\\", \\\"subject\\\": \\\"DZD6F\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"victor\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 5, \\\"clicks\\\": 1.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"U\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-09 AM-07 PM-06 PM-07 PM-06 PM-01 PM-02 PM-03 PM-05 PM-02 PM-01 PM-F -F -F -F -F -F -01 PM\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:526,y:719,t:1527869690317};\\\", \\\"{x:527,y:714,t:1527869690331};\\\", \\\"{x:529,y:707,t:1527869690347};\\\", \\\"{x:530,y:698,t:1527869690364};\\\", \\\"{x:532,y:689,t:1527869690380};\\\", \\\"{x:533,y:683,t:1527869690397};\\\", \\\"{x:533,y:679,t:1527869690413};\\\", \\\"{x:533,y:678,t:1527869690430};\\\", \\\"{x:534,y:675,t:1527869690447};\\\", \\\"{x:534,y:672,t:1527869690465};\\\", \\\"{x:534,y:669,t:1527869690480};\\\", \\\"{x:534,y:666,t:1527869690497};\\\", \\\"{x:534,y:665,t:1527869690514};\\\", \\\"{x:535,y:662,t:1527869690532};\\\", \\\"{x:535,y:661,t:1527869690547};\\\", \\\"{x:533,y:661,t:1527869690629};\\\", \\\"{x:532,y:661,t:1527869690637};\\\", \\\"{x:529,y:661,t:1527869690661};\\\", \\\"{x:527,y:661,t:1527869690678};\\\", \\\"{x:526,y:661,t:1527869690693};\\\", \\\"{x:526,y:660,t:1527869690710};\\\", \\\"{x:535,y:661,t:1527869718950};\\\", \\\"{x:555,y:671,t:1527869718958};\\\", \\\"{x:581,y:679,t:1527869718969};\\\", \\\"{x:683,y:705,t:1527869718985};\\\", \\\"{x:769,y:734,t:1527869719003};\\\", \\\"{x:834,y:768,t:1527869719020};\\\", \\\"{x:932,y:825,t:1527869719036};\\\", \\\"{x:987,y:855,t:1527869719053};\\\", \\\"{x:1028,y:881,t:1527869719070};\\\", \\\"{x:1078,y:915,t:1527869719087};\\\", \\\"{x:1121,y:946,t:1527869719103};\\\", \\\"{x:1165,y:983,t:1527869719121};\\\", \\\"{x:1198,y:1012,t:1527869719138};\\\", \\\"{x:1232,y:1051,t:1527869719153};\\\", \\\"{x:1268,y:1084,t:1527869719171};\\\", \\\"{x:1298,y:1116,t:1527869719186};\\\", \\\"{x:1319,y:1132,t:1527869719203};\\\", \\\"{x:1333,y:1145,t:1527869719220};\\\", \\\"{x:1361,y:1160,t:1527869719237};\\\", \\\"{x:1384,y:1164,t:1527869719253};\\\", \\\"{x:1413,y:1160,t:1527869719270};\\\", \\\"{x:1445,y:1145,t:1527869719287};\\\", \\\"{x:1507,y:1122,t:1527869719303};\\\", \\\"{x:1586,y:1096,t:1527869719320};\\\", \\\"{x:1666,y:1074,t:1527869719337};\\\", \\\"{x:1737,y:1046,t:1527869719354};\\\", \\\"{x:1786,y:1029,t:1527869719371};\\\", \\\"{x:1813,y:1018,t:1527869719387};\\\", \\\"{x:1826,y:1008,t:1527869719403};\\\", \\\"{x:1828,y:1005,t:1527869719420};\\\", \\\"{x:1828,y:999,t:1527869719438};\\\", \\\"{x:1828,y:998,t:1527869719454};\\\", \\\"{x:1828,y:996,t:1527869719470};\\\", \\\"{x:1828,y:992,t:1527869719488};\\\", \\\"{x:1830,y:986,t:1527869719504};\\\", \\\"{x:1830,y:979,t:1527869719520};\\\", \\\"{x:1829,y:970,t:1527869719538};\\\", \\\"{x:1815,y:963,t:1527869719555};\\\", \\\"{x:1799,y:957,t:1527869719571};\\\", \\\"{x:1790,y:954,t:1527869719587};\\\", \\\"{x:1783,y:953,t:1527869719604};\\\", \\\"{x:1776,y:953,t:1527869719620};\\\", \\\"{x:1765,y:951,t:1527869719637};\\\", \\\"{x:1758,y:953,t:1527869719654};\\\", \\\"{x:1752,y:955,t:1527869719671};\\\", \\\"{x:1742,y:959,t:1527869719688};\\\", \\\"{x:1736,y:961,t:1527869719704};\\\", \\\"{x:1727,y:961,t:1527869719721};\\\", \\\"{x:1724,y:961,t:1527869719737};\\\", \\\"{x:1723,y:961,t:1527869719754};\\\", \\\"{x:1722,y:963,t:1527869719770};\\\", \\\"{x:1720,y:964,t:1527869719787};\\\", \\\"{x:1718,y:966,t:1527869719804};\\\", \\\"{x:1711,y:970,t:1527869719821};\\\", \\\"{x:1708,y:973,t:1527869719838};\\\", \\\"{x:1708,y:974,t:1527869719870};\\\", \\\"{x:1707,y:974,t:1527869719950};\\\", \\\"{x:1707,y:973,t:1527869720022};\\\", \\\"{x:1707,y:972,t:1527869720037};\\\", \\\"{x:1707,y:971,t:1527869720055};\\\", \\\"{x:1707,y:970,t:1527869720071};\\\", \\\"{x:1708,y:970,t:1527869720088};\\\", \\\"{x:1709,y:970,t:1527869720158};\\\", \\\"{x:1710,y:970,t:1527869720173};\\\", \\\"{x:1712,y:970,t:1527869720188};\\\", \\\"{x:1713,y:970,t:1527869720204};\\\", \\\"{x:1716,y:970,t:1527869720221};\\\", \\\"{x:1718,y:970,t:1527869720238};\\\", \\\"{x:1720,y:970,t:1527869720254};\\\", \\\"{x:1721,y:970,t:1527869720272};\\\", \\\"{x:1724,y:970,t:1527869721782};\\\", \\\"{x:1735,y:970,t:1527869721789};\\\", \\\"{x:1753,y:969,t:1527869721806};\\\", \\\"{x:1777,y:967,t:1527869721823};\\\", \\\"{x:1797,y:966,t:1527869721839};\\\", \\\"{x:1808,y:966,t:1527869721857};\\\", \\\"{x:1813,y:966,t:1527869721873};\\\", \\\"{x:1812,y:966,t:1527869722158};\\\", \\\"{x:1811,y:966,t:1527869722173};\\\", \\\"{x:1806,y:968,t:1527869722190};\\\", \\\"{x:1804,y:969,t:1527869722207};\\\", \\\"{x:1798,y:970,t:1527869722223};\\\", \\\"{x:1786,y:971,t:1527869722240};\\\", \\\"{x:1771,y:975,t:1527869722256};\\\", \\\"{x:1765,y:978,t:1527869722274};\\\", \\\"{x:1761,y:978,t:1527869722290};\\\", \\\"{x:1759,y:979,t:1527869722306};\\\", \\\"{x:1758,y:979,t:1527869722325};\\\", \\\"{x:1759,y:979,t:1527869722478};\\\", \\\"{x:1761,y:979,t:1527869722490};\\\", \\\"{x:1763,y:979,t:1527869722506};\\\", \\\"{x:1766,y:979,t:1527869722523};\\\", \\\"{x:1770,y:977,t:1527869722540};\\\", \\\"{x:1771,y:977,t:1527869722557};\\\", \\\"{x:1774,y:975,t:1527869722573};\\\", \\\"{x:1775,y:975,t:1527869722598};\\\", \\\"{x:1776,y:975,t:1527869722644};\\\", \\\"{x:1777,y:975,t:1527869722660};\\\", \\\"{x:1778,y:975,t:1527869722684};\\\", \\\"{x:1779,y:974,t:1527869722701};\\\", \\\"{x:1780,y:973,t:1527869722974};\\\", \\\"{x:1781,y:971,t:1527869722991};\\\", \\\"{x:1782,y:970,t:1527869723021};\\\", \\\"{x:1782,y:969,t:1527869723061};\\\", \\\"{x:1774,y:962,t:1527869737866};\\\", \\\"{x:1744,y:947,t:1527869737874};\\\", \\\"{x:1677,y:936,t:1527869737890};\\\", \\\"{x:1605,y:936,t:1527869737907};\\\", \\\"{x:1534,y:939,t:1527869737924};\\\", \\\"{x:1452,y:960,t:1527869737940};\\\", \\\"{x:1392,y:980,t:1527869737957};\\\", \\\"{x:1350,y:1001,t:1527869737975};\\\", \\\"{x:1327,y:1019,t:1527869737991};\\\", \\\"{x:1310,y:1037,t:1527869738008};\\\", \\\"{x:1298,y:1053,t:1527869738025};\\\", \\\"{x:1290,y:1068,t:1527869738042};\\\", \\\"{x:1289,y:1070,t:1527869738057};\\\", \\\"{x:1289,y:1071,t:1527869738074};\\\", \\\"{x:1289,y:1070,t:1527869738097};\\\", \\\"{x:1291,y:1068,t:1527869738113};\\\", \\\"{x:1293,y:1065,t:1527869738124};\\\", \\\"{x:1296,y:1058,t:1527869738142};\\\", \\\"{x:1297,y:1048,t:1527869738157};\\\", \\\"{x:1298,y:1041,t:1527869738174};\\\", \\\"{x:1301,y:1030,t:1527869738192};\\\", \\\"{x:1305,y:1021,t:1527869738207};\\\", \\\"{x:1307,y:1012,t:1527869738224};\\\", \\\"{x:1309,y:1003,t:1527869738241};\\\", \\\"{x:1309,y:1001,t:1527869738257};\\\", \\\"{x:1309,y:1000,t:1527869738329};\\\", \\\"{x:1310,y:998,t:1527869738341};\\\", \\\"{x:1313,y:991,t:1527869738357};\\\", \\\"{x:1314,y:989,t:1527869738374};\\\", \\\"{x:1314,y:987,t:1527869738391};\\\", \\\"{x:1315,y:986,t:1527869738408};\\\", \\\"{x:1315,y:984,t:1527869738424};\\\", \\\"{x:1315,y:977,t:1527869738442};\\\", \\\"{x:1316,y:972,t:1527869738458};\\\", \\\"{x:1316,y:969,t:1527869738474};\\\", \\\"{x:1316,y:968,t:1527869738491};\\\", \\\"{x:1316,y:967,t:1527869738509};\\\", \\\"{x:1317,y:966,t:1527869738682};\\\", \\\"{x:1318,y:966,t:1527869738697};\\\", \\\"{x:1319,y:966,t:1527869738709};\\\", \\\"{x:1323,y:966,t:1527869738725};\\\", \\\"{x:1329,y:966,t:1527869738741};\\\", \\\"{x:1334,y:966,t:1527869738758};\\\", \\\"{x:1342,y:966,t:1527869738774};\\\", \\\"{x:1347,y:966,t:1527869738791};\\\", \\\"{x:1351,y:966,t:1527869738808};\\\", \\\"{x:1353,y:966,t:1527869738825};\\\", \\\"{x:1354,y:966,t:1527869738849};\\\", \\\"{x:1357,y:966,t:1527869739538};\\\", \\\"{x:1360,y:966,t:1527869739545};\\\", \\\"{x:1361,y:967,t:1527869739558};\\\", \\\"{x:1366,y:967,t:1527869739575};\\\", \\\"{x:1369,y:969,t:1527869739592};\\\", \\\"{x:1376,y:970,t:1527869739609};\\\", \\\"{x:1377,y:970,t:1527869739641};\\\", \\\"{x:1378,y:970,t:1527869739673};\\\", \\\"{x:1379,y:970,t:1527869739680};\\\", \\\"{x:1380,y:970,t:1527869739692};\\\", \\\"{x:1387,y:970,t:1527869739709};\\\", \\\"{x:1399,y:970,t:1527869739725};\\\", \\\"{x:1409,y:970,t:1527869739741};\\\", \\\"{x:1410,y:970,t:1527869739759};\\\", \\\"{x:1412,y:970,t:1527869739775};\\\", \\\"{x:1413,y:970,t:1527869739921};\\\", \\\"{x:1415,y:970,t:1527869740097};\\\", \\\"{x:1417,y:970,t:1527869740110};\\\", \\\"{x:1422,y:970,t:1527869740126};\\\", \\\"{x:1424,y:970,t:1527869740142};\\\", \\\"{x:1427,y:970,t:1527869740159};\\\", \\\"{x:1428,y:970,t:1527869740235};\\\", \\\"{x:1429,y:970,t:1527869740242};\\\", \\\"{x:1430,y:970,t:1527869740259};\\\", \\\"{x:1433,y:970,t:1527869740276};\\\", \\\"{x:1439,y:970,t:1527869740292};\\\", \\\"{x:1441,y:970,t:1527869740309};\\\", \\\"{x:1444,y:970,t:1527869740326};\\\", \\\"{x:1446,y:970,t:1527869740342};\\\", \\\"{x:1447,y:970,t:1527869740359};\\\", \\\"{x:1448,y:970,t:1527869740377};\\\", \\\"{x:1450,y:970,t:1527869740392};\\\", \\\"{x:1456,y:970,t:1527869740409};\\\", \\\"{x:1461,y:970,t:1527869740426};\\\", \\\"{x:1463,y:970,t:1527869740530};\\\", \\\"{x:1464,y:970,t:1527869740553};\\\", \\\"{x:1466,y:970,t:1527869740569};\\\", \\\"{x:1467,y:970,t:1527869740642};\\\", \\\"{x:1469,y:970,t:1527869740649};\\\", \\\"{x:1470,y:970,t:1527869740659};\\\", \\\"{x:1476,y:969,t:1527869740677};\\\", \\\"{x:1477,y:969,t:1527869740693};\\\", \\\"{x:1478,y:969,t:1527869740842};\\\", \\\"{x:1479,y:969,t:1527869740873};\\\", \\\"{x:1480,y:969,t:1527869740881};\\\", \\\"{x:1481,y:969,t:1527869740894};\\\", \\\"{x:1486,y:969,t:1527869740910};\\\", \\\"{x:1492,y:969,t:1527869740926};\\\", \\\"{x:1499,y:968,t:1527869740944};\\\", \\\"{x:1505,y:967,t:1527869740960};\\\", \\\"{x:1509,y:967,t:1527869740976};\\\", \\\"{x:1514,y:966,t:1527869740993};\\\", \\\"{x:1520,y:965,t:1527869741010};\\\", \\\"{x:1526,y:964,t:1527869741026};\\\", \\\"{x:1530,y:964,t:1527869741043};\\\", \\\"{x:1534,y:964,t:1527869741061};\\\", \\\"{x:1535,y:964,t:1527869741097};\\\", \\\"{x:1536,y:964,t:1527869741113};\\\", \\\"{x:1537,y:964,t:1527869741126};\\\", \\\"{x:1544,y:964,t:1527869741143};\\\", \\\"{x:1549,y:964,t:1527869741161};\\\", \\\"{x:1550,y:964,t:1527869741176};\\\", \\\"{x:1551,y:963,t:1527869741193};\\\", \\\"{x:1550,y:963,t:1527869741450};\\\", \\\"{x:1550,y:964,t:1527869741473};\\\", \\\"{x:1548,y:964,t:1527869743546};\\\", \\\"{x:1548,y:963,t:1527869743610};\\\", \\\"{x:1547,y:962,t:1527869743850};\\\", \\\"{x:1547,y:963,t:1527869743862};\\\", \\\"{x:1547,y:965,t:1527869743879};\\\", \\\"{x:1547,y:967,t:1527869743894};\\\", \\\"{x:1547,y:968,t:1527869743911};\\\", \\\"{x:1546,y:970,t:1527869743929};\\\", \\\"{x:1545,y:970,t:1527869743945};\\\", \\\"{x:1545,y:969,t:1527869744145};\\\", \\\"{x:1545,y:968,t:1527869744163};\\\", \\\"{x:1545,y:966,t:1527869744185};\\\", \\\"{x:1545,y:965,t:1527869744209};\\\", \\\"{x:1545,y:963,t:1527869744297};\\\", \\\"{x:1545,y:962,t:1527869744369};\\\", \\\"{x:1544,y:962,t:1527869753384};\\\", \\\"{x:1543,y:962,t:1527869753392};\\\", \\\"{x:1541,y:962,t:1527869753403};\\\", \\\"{x:1535,y:961,t:1527869753420};\\\", \\\"{x:1528,y:957,t:1527869753437};\\\", \\\"{x:1516,y:951,t:1527869753453};\\\", \\\"{x:1507,y:944,t:1527869753470};\\\", \\\"{x:1494,y:937,t:1527869753487};\\\", \\\"{x:1481,y:926,t:1527869753503};\\\", \\\"{x:1465,y:915,t:1527869753520};\\\", \\\"{x:1452,y:903,t:1527869753537};\\\", \\\"{x:1436,y:890,t:1527869753553};\\\", \\\"{x:1414,y:877,t:1527869753570};\\\", \\\"{x:1389,y:860,t:1527869753587};\\\", \\\"{x:1367,y:851,t:1527869753603};\\\", \\\"{x:1347,y:842,t:1527869753620};\\\", \\\"{x:1332,y:838,t:1527869753637};\\\", \\\"{x:1320,y:833,t:1527869753654};\\\", \\\"{x:1303,y:827,t:1527869753670};\\\", \\\"{x:1294,y:824,t:1527869753687};\\\", \\\"{x:1271,y:818,t:1527869753703};\\\", \\\"{x:1249,y:812,t:1527869753720};\\\", \\\"{x:1233,y:807,t:1527869753737};\\\", \\\"{x:1216,y:803,t:1527869753754};\\\", \\\"{x:1197,y:801,t:1527869753770};\\\", \\\"{x:1171,y:798,t:1527869753787};\\\", \\\"{x:1125,y:797,t:1527869753804};\\\", \\\"{x:1074,y:797,t:1527869753820};\\\", \\\"{x:999,y:797,t:1527869753837};\\\", \\\"{x:926,y:793,t:1527869753854};\\\", \\\"{x:851,y:793,t:1527869753870};\\\", \\\"{x:751,y:778,t:1527869753887};\\\", \\\"{x:590,y:749,t:1527869753904};\\\", \\\"{x:493,y:734,t:1527869753920};\\\", \\\"{x:410,y:711,t:1527869753937};\\\", \\\"{x:378,y:706,t:1527869753951};\\\", \\\"{x:317,y:692,t:1527869753967};\\\", \\\"{x:277,y:686,t:1527869753985};\\\", \\\"{x:249,y:686,t:1527869754001};\\\", \\\"{x:231,y:686,t:1527869754018};\\\", \\\"{x:225,y:686,t:1527869754035};\\\", \\\"{x:221,y:685,t:1527869754051};\\\", \\\"{x:216,y:684,t:1527869754068};\\\", \\\"{x:214,y:682,t:1527869754085};\\\", \\\"{x:211,y:677,t:1527869754101};\\\", \\\"{x:210,y:669,t:1527869754118};\\\", \\\"{x:210,y:658,t:1527869754135};\\\", \\\"{x:221,y:632,t:1527869754152};\\\", \\\"{x:237,y:615,t:1527869754169};\\\", \\\"{x:256,y:601,t:1527869754185};\\\", \\\"{x:286,y:586,t:1527869754202};\\\", \\\"{x:314,y:573,t:1527869754218};\\\", \\\"{x:344,y:564,t:1527869754235};\\\", \\\"{x:369,y:558,t:1527869754252};\\\", \\\"{x:392,y:558,t:1527869754268};\\\", \\\"{x:424,y:558,t:1527869754285};\\\", \\\"{x:451,y:558,t:1527869754302};\\\", \\\"{x:469,y:558,t:1527869754318};\\\", \\\"{x:491,y:560,t:1527869754335};\\\", \\\"{x:518,y:569,t:1527869754352};\\\", \\\"{x:533,y:576,t:1527869754367};\\\", \\\"{x:541,y:583,t:1527869754385};\\\", \\\"{x:546,y:586,t:1527869754402};\\\", \\\"{x:551,y:589,t:1527869754420};\\\", \\\"{x:552,y:590,t:1527869754435};\\\", \\\"{x:553,y:590,t:1527869754496};\\\", \\\"{x:554,y:591,t:1527869754503};\\\", \\\"{x:557,y:592,t:1527869754519};\\\", \\\"{x:560,y:594,t:1527869754535};\\\", \\\"{x:569,y:597,t:1527869754552};\\\", \\\"{x:573,y:598,t:1527869754569};\\\", \\\"{x:575,y:598,t:1527869754585};\\\", \\\"{x:576,y:598,t:1527869754602};\\\", \\\"{x:577,y:598,t:1527869754623};\\\", \\\"{x:579,y:600,t:1527869754635};\\\", \\\"{x:580,y:601,t:1527869754652};\\\", \\\"{x:581,y:601,t:1527869754669};\\\", \\\"{x:583,y:601,t:1527869754685};\\\", \\\"{x:585,y:601,t:1527869754704};\\\", \\\"{x:586,y:602,t:1527869754719};\\\", \\\"{x:589,y:603,t:1527869754735};\\\", \\\"{x:591,y:604,t:1527869754752};\\\", \\\"{x:593,y:604,t:1527869754770};\\\", \\\"{x:594,y:604,t:1527869754786};\\\", \\\"{x:594,y:604,t:1527869754858};\\\", \\\"{x:595,y:604,t:1527869755104};\\\", \\\"{x:599,y:604,t:1527869755119};\\\", \\\"{x:607,y:604,t:1527869755136};\\\", \\\"{x:611,y:605,t:1527869755152};\\\", \\\"{x:620,y:605,t:1527869755169};\\\", \\\"{x:628,y:607,t:1527869755186};\\\", \\\"{x:635,y:608,t:1527869755202};\\\", \\\"{x:640,y:610,t:1527869755219};\\\", \\\"{x:649,y:613,t:1527869755236};\\\", \\\"{x:664,y:618,t:1527869755253};\\\", \\\"{x:674,y:624,t:1527869755269};\\\", \\\"{x:686,y:629,t:1527869755287};\\\", \\\"{x:696,y:633,t:1527869755302};\\\", \\\"{x:700,y:634,t:1527869755319};\\\", \\\"{x:702,y:635,t:1527869755336};\\\", \\\"{x:703,y:635,t:1527869755440};\\\", \\\"{x:704,y:635,t:1527869755453};\\\", \\\"{x:706,y:636,t:1527869755469};\\\", \\\"{x:708,y:637,t:1527869755486};\\\", \\\"{x:711,y:639,t:1527869755503};\\\", \\\"{x:712,y:640,t:1527869755519};\\\", \\\"{x:714,y:642,t:1527869755536};\\\", \\\"{x:715,y:642,t:1527869755553};\\\", \\\"{x:713,y:642,t:1527869755832};\\\", \\\"{x:711,y:642,t:1527869755839};\\\", \\\"{x:710,y:642,t:1527869755853};\\\", \\\"{x:707,y:642,t:1527869755888};\\\", \\\"{x:702,y:642,t:1527869755903};\\\", \\\"{x:677,y:640,t:1527869755920};\\\", \\\"{x:663,y:639,t:1527869755936};\\\", \\\"{x:651,y:635,t:1527869755953};\\\", \\\"{x:638,y:631,t:1527869755971};\\\", \\\"{x:624,y:626,t:1527869755986};\\\", \\\"{x:617,y:623,t:1527869756003};\\\", \\\"{x:614,y:621,t:1527869756020};\\\", \\\"{x:612,y:619,t:1527869756056};\\\", \\\"{x:611,y:619,t:1527869756070};\\\", \\\"{x:610,y:619,t:1527869756087};\\\", \\\"{x:608,y:618,t:1527869756103};\\\", \\\"{x:610,y:618,t:1527869756464};\\\", \\\"{x:615,y:618,t:1527869756471};\\\", \\\"{x:625,y:618,t:1527869756488};\\\", \\\"{x:649,y:619,t:1527869756503};\\\", \\\"{x:733,y:639,t:1527869756521};\\\", \\\"{x:827,y:667,t:1527869756537};\\\", \\\"{x:927,y:695,t:1527869756553};\\\", \\\"{x:1043,y:728,t:1527869756570};\\\", \\\"{x:1170,y:764,t:1527869756587};\\\", \\\"{x:1293,y:802,t:1527869756603};\\\", \\\"{x:1395,y:830,t:1527869756620};\\\", \\\"{x:1481,y:855,t:1527869756637};\\\", \\\"{x:1551,y:878,t:1527869756653};\\\", \\\"{x:1590,y:888,t:1527869756670};\\\", \\\"{x:1620,y:898,t:1527869756687};\\\", \\\"{x:1645,y:908,t:1527869756703};\\\", \\\"{x:1658,y:914,t:1527869756720};\\\", \\\"{x:1670,y:919,t:1527869756737};\\\", \\\"{x:1680,y:926,t:1527869756755};\\\", \\\"{x:1686,y:932,t:1527869756770};\\\", \\\"{x:1688,y:935,t:1527869756787};\\\", \\\"{x:1690,y:939,t:1527869756804};\\\", \\\"{x:1690,y:944,t:1527869756820};\\\", \\\"{x:1692,y:946,t:1527869756838};\\\", \\\"{x:1692,y:947,t:1527869756853};\\\", \\\"{x:1692,y:949,t:1527869756870};\\\", \\\"{x:1692,y:950,t:1527869756887};\\\", \\\"{x:1692,y:952,t:1527869756904};\\\", \\\"{x:1692,y:953,t:1527869756920};\\\", \\\"{x:1691,y:954,t:1527869756937};\\\", \\\"{x:1690,y:955,t:1527869756954};\\\", \\\"{x:1689,y:956,t:1527869756970};\\\", \\\"{x:1687,y:958,t:1527869756987};\\\", \\\"{x:1685,y:961,t:1527869757004};\\\", \\\"{x:1681,y:967,t:1527869757020};\\\", \\\"{x:1677,y:971,t:1527869757037};\\\", \\\"{x:1674,y:975,t:1527869757054};\\\", \\\"{x:1670,y:980,t:1527869757071};\\\", \\\"{x:1662,y:984,t:1527869757087};\\\", \\\"{x:1650,y:987,t:1527869757103};\\\", \\\"{x:1642,y:988,t:1527869757121};\\\", \\\"{x:1634,y:988,t:1527869757136};\\\", \\\"{x:1624,y:988,t:1527869757154};\\\", \\\"{x:1616,y:988,t:1527869757171};\\\", \\\"{x:1609,y:988,t:1527869757188};\\\", \\\"{x:1600,y:988,t:1527869757204};\\\", \\\"{x:1591,y:988,t:1527869757221};\\\", \\\"{x:1583,y:991,t:1527869757237};\\\", \\\"{x:1574,y:991,t:1527869757254};\\\", \\\"{x:1568,y:993,t:1527869757271};\\\", \\\"{x:1564,y:995,t:1527869757287};\\\", \\\"{x:1557,y:995,t:1527869757304};\\\", \\\"{x:1552,y:995,t:1527869757321};\\\", \\\"{x:1550,y:995,t:1527869757337};\\\", \\\"{x:1546,y:995,t:1527869757355};\\\", \\\"{x:1541,y:993,t:1527869757372};\\\", \\\"{x:1536,y:991,t:1527869757387};\\\", \\\"{x:1534,y:990,t:1527869757404};\\\", \\\"{x:1533,y:990,t:1527869757421};\\\", \\\"{x:1532,y:990,t:1527869757528};\\\", \\\"{x:1530,y:990,t:1527869757538};\\\", \\\"{x:1522,y:990,t:1527869757554};\\\", \\\"{x:1511,y:986,t:1527869757571};\\\", \\\"{x:1499,y:982,t:1527869757588};\\\", \\\"{x:1486,y:978,t:1527869757604};\\\", \\\"{x:1469,y:976,t:1527869757621};\\\", \\\"{x:1448,y:972,t:1527869757638};\\\", \\\"{x:1431,y:970,t:1527869757654};\\\", \\\"{x:1423,y:969,t:1527869757672};\\\", \\\"{x:1416,y:969,t:1527869757688};\\\", \\\"{x:1414,y:969,t:1527869757703};\\\", \\\"{x:1413,y:969,t:1527869757728};\\\", \\\"{x:1412,y:969,t:1527869757744};\\\", \\\"{x:1410,y:968,t:1527869757760};\\\", \\\"{x:1409,y:967,t:1527869757771};\\\", \\\"{x:1403,y:964,t:1527869757788};\\\", \\\"{x:1395,y:959,t:1527869757804};\\\", \\\"{x:1388,y:954,t:1527869757821};\\\", \\\"{x:1386,y:952,t:1527869757838};\\\", \\\"{x:1384,y:950,t:1527869757854};\\\", \\\"{x:1384,y:949,t:1527869757871};\\\", \\\"{x:1384,y:945,t:1527869757887};\\\", \\\"{x:1384,y:941,t:1527869757904};\\\", \\\"{x:1384,y:934,t:1527869757921};\\\", \\\"{x:1384,y:925,t:1527869757938};\\\", \\\"{x:1384,y:911,t:1527869757955};\\\", \\\"{x:1387,y:894,t:1527869757971};\\\", \\\"{x:1390,y:886,t:1527869757988};\\\", \\\"{x:1392,y:882,t:1527869758005};\\\", \\\"{x:1395,y:871,t:1527869758021};\\\", \\\"{x:1398,y:859,t:1527869758038};\\\", \\\"{x:1400,y:854,t:1527869758055};\\\", \\\"{x:1401,y:852,t:1527869758071};\\\", \\\"{x:1403,y:852,t:1527869758089};\\\", \\\"{x:1404,y:852,t:1527869758105};\\\", \\\"{x:1407,y:850,t:1527869758335};\\\", \\\"{x:1407,y:843,t:1527869758343};\\\", \\\"{x:1408,y:834,t:1527869758355};\\\", \\\"{x:1408,y:813,t:1527869758371};\\\", \\\"{x:1408,y:791,t:1527869758388};\\\", \\\"{x:1408,y:770,t:1527869758406};\\\", \\\"{x:1408,y:743,t:1527869758422};\\\", \\\"{x:1408,y:711,t:1527869758438};\\\", \\\"{x:1408,y:684,t:1527869758455};\\\", \\\"{x:1408,y:652,t:1527869758471};\\\", \\\"{x:1408,y:633,t:1527869758488};\\\", \\\"{x:1408,y:621,t:1527869758505};\\\", \\\"{x:1407,y:611,t:1527869758522};\\\", \\\"{x:1407,y:607,t:1527869758538};\\\", \\\"{x:1407,y:604,t:1527869758555};\\\", \\\"{x:1407,y:603,t:1527869758572};\\\", \\\"{x:1407,y:601,t:1527869758588};\\\", \\\"{x:1407,y:600,t:1527869758606};\\\", \\\"{x:1407,y:598,t:1527869758622};\\\", \\\"{x:1407,y:596,t:1527869758638};\\\", \\\"{x:1406,y:592,t:1527869758655};\\\", \\\"{x:1405,y:589,t:1527869758672};\\\", \\\"{x:1404,y:584,t:1527869758688};\\\", \\\"{x:1404,y:580,t:1527869758705};\\\", \\\"{x:1404,y:574,t:1527869758722};\\\", \\\"{x:1404,y:570,t:1527869758738};\\\", \\\"{x:1404,y:565,t:1527869758755};\\\", \\\"{x:1404,y:563,t:1527869758772};\\\", \\\"{x:1404,y:562,t:1527869758789};\\\", \\\"{x:1404,y:563,t:1527869759456};\\\", \\\"{x:1404,y:565,t:1527869759473};\\\", \\\"{x:1404,y:566,t:1527869759489};\\\", \\\"{x:1404,y:567,t:1527869759624};\\\", \\\"{x:1404,y:568,t:1527869759639};\\\", \\\"{x:1404,y:575,t:1527869759657};\\\", \\\"{x:1404,y:579,t:1527869759672};\\\", \\\"{x:1404,y:584,t:1527869759690};\\\", \\\"{x:1404,y:586,t:1527869759706};\\\", \\\"{x:1404,y:590,t:1527869759723};\\\", \\\"{x:1404,y:593,t:1527869759739};\\\", \\\"{x:1404,y:597,t:1527869759756};\\\", \\\"{x:1404,y:604,t:1527869759773};\\\", \\\"{x:1404,y:614,t:1527869759789};\\\", \\\"{x:1403,y:626,t:1527869759806};\\\", \\\"{x:1402,y:635,t:1527869759823};\\\", \\\"{x:1401,y:641,t:1527869759839};\\\", \\\"{x:1401,y:655,t:1527869759856};\\\", \\\"{x:1399,y:666,t:1527869759873};\\\", \\\"{x:1397,y:678,t:1527869759889};\\\", \\\"{x:1394,y:692,t:1527869759906};\\\", \\\"{x:1392,y:707,t:1527869759923};\\\", \\\"{x:1391,y:717,t:1527869759939};\\\", \\\"{x:1389,y:726,t:1527869759956};\\\", \\\"{x:1389,y:732,t:1527869759973};\\\", \\\"{x:1388,y:736,t:1527869759989};\\\", \\\"{x:1387,y:739,t:1527869760006};\\\", \\\"{x:1386,y:744,t:1527869760023};\\\", \\\"{x:1386,y:747,t:1527869760039};\\\", \\\"{x:1384,y:756,t:1527869760056};\\\", \\\"{x:1383,y:763,t:1527869760073};\\\", \\\"{x:1383,y:770,t:1527869760090};\\\", \\\"{x:1381,y:775,t:1527869760106};\\\", \\\"{x:1381,y:778,t:1527869760123};\\\", \\\"{x:1381,y:781,t:1527869760140};\\\", \\\"{x:1381,y:782,t:1527869760156};\\\", \\\"{x:1381,y:783,t:1527869760173};\\\", \\\"{x:1380,y:784,t:1527869760191};\\\", \\\"{x:1380,y:783,t:1527869760592};\\\", \\\"{x:1380,y:782,t:1527869760607};\\\", \\\"{x:1380,y:781,t:1527869760623};\\\", \\\"{x:1380,y:779,t:1527869760768};\\\", \\\"{x:1380,y:778,t:1527869760784};\\\", \\\"{x:1380,y:776,t:1527869760808};\\\", \\\"{x:1380,y:775,t:1527869760824};\\\", \\\"{x:1380,y:773,t:1527869760855};\\\", \\\"{x:1380,y:772,t:1527869760920};\\\", \\\"{x:1381,y:771,t:1527869760927};\\\", \\\"{x:1381,y:770,t:1527869760940};\\\", \\\"{x:1381,y:769,t:1527869760960};\\\", \\\"{x:1381,y:768,t:1527869760973};\\\", \\\"{x:1381,y:766,t:1527869760991};\\\", \\\"{x:1383,y:765,t:1527869764200};\\\", \\\"{x:1384,y:765,t:1527869764209};\\\", \\\"{x:1386,y:766,t:1527869764226};\\\", \\\"{x:1388,y:766,t:1527869764243};\\\", \\\"{x:1391,y:768,t:1527869764260};\\\", \\\"{x:1393,y:769,t:1527869764277};\\\", \\\"{x:1394,y:770,t:1527869764293};\\\", \\\"{x:1395,y:770,t:1527869764311};\\\", \\\"{x:1396,y:771,t:1527869764327};\\\", \\\"{x:1396,y:772,t:1527869764344};\\\", \\\"{x:1397,y:775,t:1527869764359};\\\", \\\"{x:1397,y:776,t:1527869764376};\\\", \\\"{x:1397,y:779,t:1527869764393};\\\", \\\"{x:1397,y:780,t:1527869764410};\\\", \\\"{x:1397,y:782,t:1527869764426};\\\", \\\"{x:1397,y:784,t:1527869764443};\\\", \\\"{x:1397,y:788,t:1527869764460};\\\", \\\"{x:1397,y:791,t:1527869764476};\\\", \\\"{x:1397,y:793,t:1527869764493};\\\", \\\"{x:1397,y:796,t:1527869764510};\\\", \\\"{x:1396,y:798,t:1527869764526};\\\", \\\"{x:1396,y:799,t:1527869764543};\\\", \\\"{x:1395,y:799,t:1527869764704};\\\", \\\"{x:1395,y:798,t:1527869764711};\\\", \\\"{x:1395,y:796,t:1527869764728};\\\", \\\"{x:1393,y:792,t:1527869764743};\\\", \\\"{x:1391,y:785,t:1527869764761};\\\", \\\"{x:1389,y:777,t:1527869764776};\\\", \\\"{x:1385,y:767,t:1527869764793};\\\", \\\"{x:1383,y:762,t:1527869764810};\\\", \\\"{x:1381,y:754,t:1527869764827};\\\", \\\"{x:1379,y:748,t:1527869764843};\\\", \\\"{x:1378,y:744,t:1527869764860};\\\", \\\"{x:1378,y:743,t:1527869764896};\\\", \\\"{x:1377,y:743,t:1527869765144};\\\", \\\"{x:1377,y:745,t:1527869765160};\\\", \\\"{x:1377,y:746,t:1527869765178};\\\", \\\"{x:1377,y:748,t:1527869765194};\\\", \\\"{x:1377,y:749,t:1527869765210};\\\", \\\"{x:1377,y:751,t:1527869765320};\\\", \\\"{x:1377,y:752,t:1527869765336};\\\", \\\"{x:1377,y:753,t:1527869765344};\\\", \\\"{x:1376,y:758,t:1527869765361};\\\", \\\"{x:1376,y:761,t:1527869765378};\\\", \\\"{x:1374,y:767,t:1527869765395};\\\", \\\"{x:1374,y:771,t:1527869765410};\\\", \\\"{x:1373,y:776,t:1527869765428};\\\", \\\"{x:1372,y:778,t:1527869765445};\\\", \\\"{x:1372,y:779,t:1527869765583};\\\", \\\"{x:1372,y:781,t:1527869765599};\\\", \\\"{x:1372,y:783,t:1527869765640};\\\", \\\"{x:1372,y:782,t:1527869766167};\\\", \\\"{x:1372,y:781,t:1527869766178};\\\", \\\"{x:1373,y:783,t:1527869766552};\\\", \\\"{x:1373,y:785,t:1527869766562};\\\", \\\"{x:1373,y:792,t:1527869766578};\\\", \\\"{x:1373,y:800,t:1527869766594};\\\", \\\"{x:1373,y:811,t:1527869766611};\\\", \\\"{x:1373,y:825,t:1527869766628};\\\", \\\"{x:1373,y:848,t:1527869766645};\\\", \\\"{x:1373,y:875,t:1527869766661};\\\", \\\"{x:1375,y:902,t:1527869766678};\\\", \\\"{x:1377,y:938,t:1527869766696};\\\", \\\"{x:1380,y:959,t:1527869766711};\\\", \\\"{x:1382,y:973,t:1527869766728};\\\", \\\"{x:1384,y:979,t:1527869766745};\\\", \\\"{x:1386,y:981,t:1527869766761};\\\", \\\"{x:1386,y:982,t:1527869766778};\\\", \\\"{x:1387,y:983,t:1527869766840};\\\", \\\"{x:1389,y:983,t:1527869766855};\\\", \\\"{x:1391,y:983,t:1527869766871};\\\", \\\"{x:1393,y:982,t:1527869766879};\\\", \\\"{x:1395,y:979,t:1527869766895};\\\", \\\"{x:1397,y:972,t:1527869766912};\\\", \\\"{x:1400,y:957,t:1527869766928};\\\", \\\"{x:1401,y:937,t:1527869766945};\\\", \\\"{x:1401,y:914,t:1527869766961};\\\", \\\"{x:1401,y:886,t:1527869766978};\\\", \\\"{x:1401,y:857,t:1527869766995};\\\", \\\"{x:1399,y:834,t:1527869767011};\\\", \\\"{x:1399,y:812,t:1527869767028};\\\", \\\"{x:1397,y:797,t:1527869767045};\\\", \\\"{x:1395,y:788,t:1527869767062};\\\", \\\"{x:1394,y:785,t:1527869767078};\\\", \\\"{x:1394,y:784,t:1527869767096};\\\", \\\"{x:1394,y:782,t:1527869767223};\\\", \\\"{x:1394,y:781,t:1527869767231};\\\", \\\"{x:1394,y:780,t:1527869767255};\\\", \\\"{x:1394,y:779,t:1527869767295};\\\", \\\"{x:1394,y:778,t:1527869767312};\\\", \\\"{x:1394,y:777,t:1527869767343};\\\", \\\"{x:1394,y:776,t:1527869767359};\\\", \\\"{x:1393,y:775,t:1527869767367};\\\", \\\"{x:1392,y:775,t:1527869767383};\\\", \\\"{x:1391,y:775,t:1527869767396};\\\", \\\"{x:1389,y:774,t:1527869767412};\\\", \\\"{x:1388,y:773,t:1527869767440};\\\", \\\"{x:1388,y:772,t:1527869767543};\\\", \\\"{x:1388,y:771,t:1527869767960};\\\", \\\"{x:1389,y:769,t:1527869767967};\\\", \\\"{x:1389,y:768,t:1527869767980};\\\", \\\"{x:1392,y:768,t:1527869767996};\\\", \\\"{x:1393,y:767,t:1527869768013};\\\", \\\"{x:1393,y:766,t:1527869768029};\\\", \\\"{x:1394,y:766,t:1527869768046};\\\", \\\"{x:1396,y:766,t:1527869768062};\\\", \\\"{x:1400,y:767,t:1527869768079};\\\", \\\"{x:1402,y:767,t:1527869768097};\\\", \\\"{x:1404,y:767,t:1527869768112};\\\", \\\"{x:1405,y:767,t:1527869768129};\\\", \\\"{x:1408,y:767,t:1527869768146};\\\", \\\"{x:1410,y:766,t:1527869768162};\\\", \\\"{x:1411,y:766,t:1527869768179};\\\", \\\"{x:1412,y:766,t:1527869768240};\\\", \\\"{x:1413,y:766,t:1527869768247};\\\", \\\"{x:1414,y:766,t:1527869768296};\\\", \\\"{x:1415,y:766,t:1527869768319};\\\", \\\"{x:1416,y:766,t:1527869768343};\\\", \\\"{x:1417,y:766,t:1527869768352};\\\", \\\"{x:1418,y:766,t:1527869768364};\\\", \\\"{x:1419,y:766,t:1527869768383};\\\", \\\"{x:1421,y:765,t:1527869768396};\\\", \\\"{x:1423,y:765,t:1527869768414};\\\", \\\"{x:1424,y:765,t:1527869768429};\\\", \\\"{x:1426,y:765,t:1527869768446};\\\", \\\"{x:1427,y:764,t:1527869768463};\\\", \\\"{x:1429,y:764,t:1527869768480};\\\", \\\"{x:1434,y:763,t:1527869768497};\\\", \\\"{x:1436,y:763,t:1527869768519};\\\", \\\"{x:1437,y:763,t:1527869768599};\\\", \\\"{x:1437,y:762,t:1527869768613};\\\", \\\"{x:1439,y:762,t:1527869768629};\\\", \\\"{x:1439,y:761,t:1527869768646};\\\", \\\"{x:1442,y:760,t:1527869768663};\\\", \\\"{x:1443,y:760,t:1527869768952};\\\", \\\"{x:1443,y:761,t:1527869768964};\\\", \\\"{x:1443,y:762,t:1527869768980};\\\", \\\"{x:1443,y:763,t:1527869768996};\\\", \\\"{x:1443,y:764,t:1527869769013};\\\", \\\"{x:1444,y:765,t:1527869769031};\\\", \\\"{x:1445,y:765,t:1527869769047};\\\", \\\"{x:1446,y:765,t:1527869769063};\\\", \\\"{x:1447,y:766,t:1527869769127};\\\", \\\"{x:1448,y:766,t:1527869769327};\\\", \\\"{x:1449,y:766,t:1527869769335};\\\", \\\"{x:1449,y:764,t:1527869769348};\\\", \\\"{x:1453,y:759,t:1527869769364};\\\", \\\"{x:1463,y:754,t:1527869769380};\\\", \\\"{x:1472,y:750,t:1527869769398};\\\", \\\"{x:1479,y:747,t:1527869769413};\\\", \\\"{x:1484,y:744,t:1527869769431};\\\", \\\"{x:1486,y:743,t:1527869769447};\\\", \\\"{x:1487,y:743,t:1527869769519};\\\", \\\"{x:1493,y:741,t:1527869769535};\\\", \\\"{x:1497,y:741,t:1527869769548};\\\", \\\"{x:1509,y:741,t:1527869769564};\\\", \\\"{x:1517,y:741,t:1527869769581};\\\", \\\"{x:1520,y:741,t:1527869769597};\\\", \\\"{x:1526,y:747,t:1527869769613};\\\", \\\"{x:1530,y:750,t:1527869769631};\\\", \\\"{x:1539,y:760,t:1527869769647};\\\", \\\"{x:1541,y:763,t:1527869769665};\\\", \\\"{x:1543,y:765,t:1527869769680};\\\", \\\"{x:1545,y:767,t:1527869769697};\\\", \\\"{x:1546,y:766,t:1527869770048};\\\", \\\"{x:1547,y:766,t:1527869770064};\\\", \\\"{x:1549,y:765,t:1527869770081};\\\", \\\"{x:1550,y:764,t:1527869770098};\\\", \\\"{x:1551,y:763,t:1527869770119};\\\", \\\"{x:1551,y:762,t:1527869770144};\\\", \\\"{x:1553,y:761,t:1527869770151};\\\", \\\"{x:1553,y:759,t:1527869770167};\\\", \\\"{x:1554,y:758,t:1527869770182};\\\", \\\"{x:1555,y:756,t:1527869770198};\\\", \\\"{x:1555,y:755,t:1527869770214};\\\", \\\"{x:1557,y:753,t:1527869770231};\\\", \\\"{x:1558,y:752,t:1527869770248};\\\", \\\"{x:1559,y:752,t:1527869770343};\\\", \\\"{x:1560,y:752,t:1527869770535};\\\", \\\"{x:1561,y:752,t:1527869770567};\\\", \\\"{x:1562,y:752,t:1527869770582};\\\", \\\"{x:1563,y:752,t:1527869770663};\\\", \\\"{x:1564,y:752,t:1527869770679};\\\", \\\"{x:1565,y:752,t:1527869770751};\\\", \\\"{x:1566,y:753,t:1527869770775};\\\", \\\"{x:1567,y:753,t:1527869770800};\\\", \\\"{x:1568,y:753,t:1527869770863};\\\", \\\"{x:1569,y:753,t:1527869770911};\\\", \\\"{x:1570,y:753,t:1527869770927};\\\", \\\"{x:1571,y:753,t:1527869770951};\\\", \\\"{x:1572,y:753,t:1527869770999};\\\", \\\"{x:1572,y:754,t:1527869771016};\\\", \\\"{x:1573,y:754,t:1527869771031};\\\", \\\"{x:1574,y:755,t:1527869771055};\\\", \\\"{x:1575,y:755,t:1527869771111};\\\", \\\"{x:1577,y:756,t:1527869771135};\\\", \\\"{x:1578,y:756,t:1527869771191};\\\", \\\"{x:1578,y:757,t:1527869771231};\\\", \\\"{x:1579,y:758,t:1527869771239};\\\", \\\"{x:1580,y:759,t:1527869771255};\\\", \\\"{x:1581,y:760,t:1527869771279};\\\", \\\"{x:1581,y:761,t:1527869771304};\\\", \\\"{x:1581,y:762,t:1527869771864};\\\", \\\"{x:1560,y:762,t:1527869771871};\\\", \\\"{x:1529,y:762,t:1527869771882};\\\", \\\"{x:1431,y:764,t:1527869771899};\\\", \\\"{x:1314,y:772,t:1527869771915};\\\", \\\"{x:1177,y:780,t:1527869771933};\\\", \\\"{x:1058,y:795,t:1527869771950};\\\", \\\"{x:947,y:809,t:1527869771966};\\\", \\\"{x:852,y:814,t:1527869771983};\\\", \\\"{x:764,y:818,t:1527869771999};\\\", \\\"{x:734,y:818,t:1527869772015};\\\", \\\"{x:715,y:819,t:1527869772032};\\\", \\\"{x:708,y:821,t:1527869772050};\\\", \\\"{x:707,y:822,t:1527869772066};\\\", \\\"{x:705,y:823,t:1527869772082};\\\", \\\"{x:704,y:825,t:1527869772099};\\\", \\\"{x:703,y:828,t:1527869772115};\\\", \\\"{x:699,y:833,t:1527869772132};\\\", \\\"{x:694,y:837,t:1527869772149};\\\", \\\"{x:689,y:839,t:1527869772166};\\\", \\\"{x:686,y:840,t:1527869772182};\\\", \\\"{x:679,y:839,t:1527869772199};\\\", \\\"{x:666,y:821,t:1527869772216};\\\", \\\"{x:647,y:802,t:1527869772233};\\\", \\\"{x:623,y:781,t:1527869772250};\\\", \\\"{x:585,y:759,t:1527869772266};\\\", \\\"{x:551,y:747,t:1527869772283};\\\", \\\"{x:528,y:737,t:1527869772300};\\\", \\\"{x:523,y:735,t:1527869772316};\\\", \\\"{x:522,y:734,t:1527869772343};\\\", \\\"{x:521,y:734,t:1527869772351};\\\", \\\"{x:521,y:733,t:1527869772365};\\\", \\\"{x:520,y:733,t:1527869772383};\\\", \\\"{x:519,y:733,t:1527869773007};\\\", \\\"{x:519,y:734,t:1527869773016};\\\", \\\"{x:518,y:743,t:1527869773033};\\\", \\\"{x:517,y:750,t:1527869773049};\\\", \\\"{x:515,y:757,t:1527869773067};\\\", \\\"{x:515,y:760,t:1527869773084};\\\", \\\"{x:515,y:762,t:1527869773099};\\\", \\\"{x:515,y:763,t:1527869773116};\\\", \\\"{x:514,y:763,t:1527869773287};\\\" ] }, { \\\"rt\\\": 8883, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 10, \\\"time_elapsed\\\": 476069, \\\"internal_node_id\\\": \\\"0.0-6.0-0.0\\\", \\\"subject\\\": \\\"DZD6F\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"victor\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration\\\", \\\"q\\\": 6, \\\"clicks\\\": 2.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\", \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:512,y:763,t:1527869779183};\\\", \\\"{x:509,y:763,t:1527869779191};\\\", \\\"{x:507,y:763,t:1527869779205};\\\", \\\"{x:506,y:762,t:1527869779221};\\\", \\\"{x:506,y:760,t:1527869779559};\\\", \\\"{x:506,y:756,t:1527869779571};\\\", \\\"{x:509,y:749,t:1527869779588};\\\", \\\"{x:514,y:741,t:1527869779605};\\\", \\\"{x:517,y:731,t:1527869779621};\\\", \\\"{x:525,y:719,t:1527869779638};\\\", \\\"{x:533,y:698,t:1527869779655};\\\", \\\"{x:537,y:682,t:1527869779672};\\\", \\\"{x:539,y:673,t:1527869779689};\\\", \\\"{x:539,y:667,t:1527869779705};\\\", \\\"{x:539,y:662,t:1527869779722};\\\", \\\"{x:541,y:648,t:1527869779738};\\\", \\\"{x:546,y:635,t:1527869779755};\\\", \\\"{x:555,y:616,t:1527869779772};\\\", \\\"{x:565,y:597,t:1527869779789};\\\", \\\"{x:579,y:571,t:1527869779806};\\\", \\\"{x:598,y:545,t:1527869779823};\\\", \\\"{x:613,y:520,t:1527869779839};\\\", \\\"{x:628,y:498,t:1527869779857};\\\", \\\"{x:639,y:488,t:1527869779872};\\\", \\\"{x:645,y:482,t:1527869779889};\\\", \\\"{x:646,y:480,t:1527869779905};\\\", \\\"{x:648,y:477,t:1527869779922};\\\", \\\"{x:646,y:479,t:1527869780119};\\\", \\\"{x:646,y:481,t:1527869780127};\\\", \\\"{x:644,y:484,t:1527869780139};\\\", \\\"{x:640,y:490,t:1527869780156};\\\", \\\"{x:639,y:492,t:1527869780171};\\\", \\\"{x:638,y:495,t:1527869780188};\\\", \\\"{x:636,y:498,t:1527869780206};\\\", \\\"{x:636,y:499,t:1527869780223};\\\", \\\"{x:639,y:499,t:1527869780575};\\\", \\\"{x:644,y:499,t:1527869780589};\\\", \\\"{x:655,y:501,t:1527869780606};\\\", \\\"{x:690,y:511,t:1527869780623};\\\", \\\"{x:721,y:519,t:1527869780639};\\\", \\\"{x:748,y:528,t:1527869780656};\\\", \\\"{x:770,y:535,t:1527869780673};\\\", \\\"{x:793,y:539,t:1527869780689};\\\", \\\"{x:809,y:540,t:1527869780705};\\\", \\\"{x:817,y:540,t:1527869780723};\\\", \\\"{x:818,y:540,t:1527869780740};\\\", \\\"{x:817,y:542,t:1527869781183};\\\", \\\"{x:815,y:543,t:1527869781190};\\\", \\\"{x:814,y:544,t:1527869781206};\\\", \\\"{x:810,y:547,t:1527869781223};\\\", \\\"{x:808,y:548,t:1527869781240};\\\", \\\"{x:804,y:554,t:1527869781257};\\\", \\\"{x:794,y:565,t:1527869781274};\\\", \\\"{x:778,y:583,t:1527869781290};\\\", \\\"{x:757,y:606,t:1527869781307};\\\", \\\"{x:738,y:624,t:1527869781323};\\\", \\\"{x:721,y:642,t:1527869781340};\\\", \\\"{x:703,y:656,t:1527869781357};\\\", \\\"{x:691,y:667,t:1527869781372};\\\", \\\"{x:675,y:674,t:1527869781390};\\\", \\\"{x:660,y:680,t:1527869781407};\\\", \\\"{x:658,y:681,t:1527869781422};\\\", \\\"{x:657,y:681,t:1527869781440};\\\", \\\"{x:657,y:678,t:1527869781457};\\\", \\\"{x:661,y:669,t:1527869781473};\\\", \\\"{x:672,y:655,t:1527869781489};\\\", \\\"{x:699,y:633,t:1527869781506};\\\", \\\"{x:741,y:602,t:1527869781523};\\\", \\\"{x:782,y:579,t:1527869781541};\\\", \\\"{x:804,y:569,t:1527869781557};\\\", \\\"{x:823,y:560,t:1527869781574};\\\", \\\"{x:831,y:557,t:1527869781590};\\\", \\\"{x:833,y:557,t:1527869781607};\\\", \\\"{x:834,y:556,t:1527869781623};\\\", \\\"{x:837,y:554,t:1527869781640};\\\", \\\"{x:841,y:550,t:1527869781657};\\\", \\\"{x:847,y:545,t:1527869781674};\\\", \\\"{x:857,y:539,t:1527869781690};\\\", \\\"{x:864,y:535,t:1527869781707};\\\", \\\"{x:867,y:534,t:1527869781723};\\\", \\\"{x:864,y:534,t:1527869782071};\\\", \\\"{x:859,y:536,t:1527869782079};\\\", \\\"{x:853,y:540,t:1527869782090};\\\", \\\"{x:834,y:553,t:1527869782107};\\\", \\\"{x:812,y:568,t:1527869782125};\\\", \\\"{x:778,y:587,t:1527869782141};\\\", \\\"{x:733,y:609,t:1527869782157};\\\", \\\"{x:661,y:638,t:1527869782174};\\\", \\\"{x:560,y:683,t:1527869782191};\\\", \\\"{x:497,y:711,t:1527869782207};\\\", \\\"{x:465,y:729,t:1527869782225};\\\", \\\"{x:443,y:741,t:1527869782241};\\\", \\\"{x:431,y:750,t:1527869782257};\\\", \\\"{x:419,y:756,t:1527869782274};\\\", \\\"{x:406,y:760,t:1527869782291};\\\", \\\"{x:393,y:763,t:1527869782306};\\\", \\\"{x:381,y:768,t:1527869782324};\\\", \\\"{x:370,y:773,t:1527869782341};\\\", \\\"{x:359,y:773,t:1527869782357};\\\", \\\"{x:347,y:776,t:1527869782373};\\\", \\\"{x:329,y:783,t:1527869782390};\\\", \\\"{x:324,y:786,t:1527869782407};\\\", \\\"{x:320,y:789,t:1527869782424};\\\", \\\"{x:322,y:784,t:1527869782542};\\\", \\\"{x:326,y:779,t:1527869782558};\\\", \\\"{x:344,y:768,t:1527869782574};\\\", \\\"{x:391,y:755,t:1527869782591};\\\", \\\"{x:419,y:754,t:1527869782608};\\\", \\\"{x:445,y:752,t:1527869782623};\\\", \\\"{x:467,y:753,t:1527869782641};\\\", \\\"{x:481,y:757,t:1527869782658};\\\", \\\"{x:484,y:758,t:1527869782674};\\\", \\\"{x:489,y:759,t:1527869782691};\\\", \\\"{x:493,y:758,t:1527869782823};\\\", \\\"{x:495,y:756,t:1527869782831};\\\", \\\"{x:496,y:755,t:1527869782841};\\\", \\\"{x:497,y:754,t:1527869782858};\\\", \\\"{x:498,y:754,t:1527869782887};\\\", \\\"{x:498,y:753,t:1527869782910};\\\", \\\"{x:501,y:753,t:1527869783095};\\\", \\\"{x:502,y:753,t:1527869783108};\\\", \\\"{x:512,y:748,t:1527869783125};\\\", \\\"{x:518,y:743,t:1527869783141};\\\", \\\"{x:522,y:740,t:1527869783158};\\\", \\\"{x:523,y:739,t:1527869783175};\\\", \\\"{x:523,y:738,t:1527869783191};\\\", \\\"{x:523,y:737,t:1527869783208};\\\", \\\"{x:523,y:736,t:1527869783225};\\\", \\\"{x:523,y:735,t:1527869783241};\\\", \\\"{x:524,y:735,t:1527869783295};\\\", \\\"{x:524,y:734,t:1527869783854};\\\" ] }, { \\\"rt\\\": 21301, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 11, \\\"time_elapsed\\\": 498584, \\\"internal_node_id\\\": \\\"0.0-6.0-1.0\\\", \\\"subject\\\": \\\"DZD6F\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"victor\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+starts\\\", \\\"q\\\": 7, \\\"clicks\\\": 3, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:523,y:734,t:1527869791411};\\\", \\\"{x:523,y:733,t:1527869792683};\\\", \\\"{x:523,y:731,t:1527869792691};\\\", \\\"{x:523,y:727,t:1527869792703};\\\", \\\"{x:523,y:718,t:1527869792719};\\\", \\\"{x:523,y:711,t:1527869792735};\\\", \\\"{x:523,y:707,t:1527869792753};\\\", \\\"{x:523,y:701,t:1527869792770};\\\", \\\"{x:523,y:698,t:1527869792786};\\\", \\\"{x:523,y:693,t:1527869792802};\\\", \\\"{x:523,y:690,t:1527869792820};\\\", \\\"{x:523,y:688,t:1527869792843};\\\", \\\"{x:523,y:687,t:1527869792853};\\\", \\\"{x:523,y:685,t:1527869792871};\\\", \\\"{x:523,y:681,t:1527869792886};\\\", \\\"{x:523,y:672,t:1527869792903};\\\", \\\"{x:524,y:667,t:1527869792921};\\\", \\\"{x:525,y:663,t:1527869792936};\\\", \\\"{x:526,y:655,t:1527869792953};\\\", \\\"{x:526,y:651,t:1527869792971};\\\", \\\"{x:526,y:650,t:1527869792987};\\\", \\\"{x:526,y:646,t:1527869793004};\\\", \\\"{x:526,y:641,t:1527869793020};\\\", \\\"{x:526,y:639,t:1527869793066};\\\", \\\"{x:525,y:638,t:1527869793075};\\\", \\\"{x:524,y:638,t:1527869793087};\\\", \\\"{x:520,y:637,t:1527869793103};\\\", \\\"{x:513,y:634,t:1527869793120};\\\", \\\"{x:499,y:627,t:1527869793138};\\\", \\\"{x:479,y:617,t:1527869793154};\\\", \\\"{x:442,y:603,t:1527869793170};\\\", \\\"{x:384,y:581,t:1527869793187};\\\", \\\"{x:292,y:552,t:1527869793204};\\\", \\\"{x:242,y:538,t:1527869793221};\\\", \\\"{x:212,y:529,t:1527869793236};\\\", \\\"{x:193,y:525,t:1527869793253};\\\", \\\"{x:185,y:524,t:1527869793271};\\\", \\\"{x:184,y:524,t:1527869793287};\\\", \\\"{x:184,y:523,t:1527869793323};\\\", \\\"{x:184,y:522,t:1527869793338};\\\", \\\"{x:187,y:521,t:1527869793353};\\\", \\\"{x:206,y:515,t:1527869793371};\\\", \\\"{x:257,y:509,t:1527869793387};\\\", \\\"{x:308,y:502,t:1527869793404};\\\", \\\"{x:382,y:495,t:1527869793421};\\\", \\\"{x:455,y:493,t:1527869793437};\\\", \\\"{x:510,y:486,t:1527869793454};\\\", \\\"{x:542,y:486,t:1527869793470};\\\", \\\"{x:559,y:486,t:1527869793488};\\\", \\\"{x:562,y:486,t:1527869793503};\\\", \\\"{x:563,y:486,t:1527869793523};\\\", \\\"{x:564,y:486,t:1527869793537};\\\", \\\"{x:564,y:487,t:1527869793572};\\\", \\\"{x:565,y:487,t:1527869793643};\\\", \\\"{x:566,y:487,t:1527869793666};\\\", \\\"{x:567,y:487,t:1527869793683};\\\", \\\"{x:568,y:487,t:1527869793699};\\\", \\\"{x:570,y:487,t:1527869793707};\\\", \\\"{x:571,y:487,t:1527869793720};\\\", \\\"{x:575,y:488,t:1527869793738};\\\", \\\"{x:589,y:493,t:1527869793753};\\\", \\\"{x:609,y:498,t:1527869793771};\\\", \\\"{x:645,y:511,t:1527869793787};\\\", \\\"{x:669,y:519,t:1527869793805};\\\", \\\"{x:690,y:522,t:1527869793820};\\\", \\\"{x:712,y:525,t:1527869793838};\\\", \\\"{x:730,y:525,t:1527869793855};\\\", \\\"{x:736,y:525,t:1527869793870};\\\", \\\"{x:742,y:524,t:1527869793888};\\\", \\\"{x:747,y:520,t:1527869793905};\\\", \\\"{x:753,y:516,t:1527869793921};\\\", \\\"{x:758,y:513,t:1527869793938};\\\", \\\"{x:765,y:511,t:1527869793954};\\\", \\\"{x:772,y:508,t:1527869793970};\\\", \\\"{x:778,y:507,t:1527869793988};\\\", \\\"{x:788,y:507,t:1527869794004};\\\", \\\"{x:795,y:507,t:1527869794020};\\\", \\\"{x:800,y:507,t:1527869794037};\\\", \\\"{x:805,y:507,t:1527869794054};\\\", \\\"{x:813,y:507,t:1527869794070};\\\", \\\"{x:819,y:507,t:1527869794088};\\\", \\\"{x:818,y:507,t:1527869797163};\\\", \\\"{x:814,y:509,t:1527869797174};\\\", \\\"{x:805,y:517,t:1527869797190};\\\", \\\"{x:797,y:523,t:1527869797207};\\\", \\\"{x:786,y:531,t:1527869797224};\\\", \\\"{x:776,y:539,t:1527869797240};\\\", \\\"{x:761,y:549,t:1527869797256};\\\", \\\"{x:745,y:557,t:1527869797273};\\\", \\\"{x:730,y:564,t:1527869797290};\\\", \\\"{x:709,y:571,t:1527869797307};\\\", \\\"{x:690,y:575,t:1527869797324};\\\", \\\"{x:674,y:576,t:1527869797341};\\\", \\\"{x:656,y:577,t:1527869797357};\\\", \\\"{x:637,y:577,t:1527869797374};\\\", \\\"{x:619,y:578,t:1527869797391};\\\", \\\"{x:597,y:581,t:1527869797407};\\\", \\\"{x:568,y:584,t:1527869797424};\\\", \\\"{x:540,y:588,t:1527869797440};\\\", \\\"{x:513,y:593,t:1527869797456};\\\", \\\"{x:495,y:594,t:1527869797474};\\\", \\\"{x:474,y:599,t:1527869797490};\\\", \\\"{x:460,y:600,t:1527869797506};\\\", \\\"{x:451,y:600,t:1527869797523};\\\", \\\"{x:431,y:600,t:1527869797541};\\\", \\\"{x:408,y:600,t:1527869797557};\\\", \\\"{x:381,y:600,t:1527869797573};\\\", \\\"{x:356,y:600,t:1527869797591};\\\", \\\"{x:330,y:595,t:1527869797607};\\\", \\\"{x:307,y:594,t:1527869797624};\\\", \\\"{x:293,y:594,t:1527869797640};\\\", \\\"{x:286,y:594,t:1527869797656};\\\", \\\"{x:279,y:594,t:1527869797673};\\\", \\\"{x:267,y:596,t:1527869797690};\\\", \\\"{x:259,y:598,t:1527869797707};\\\", \\\"{x:250,y:601,t:1527869797724};\\\", \\\"{x:241,y:602,t:1527869797740};\\\", \\\"{x:231,y:603,t:1527869797758};\\\", \\\"{x:225,y:605,t:1527869797773};\\\", \\\"{x:220,y:605,t:1527869797791};\\\", \\\"{x:213,y:605,t:1527869797807};\\\", \\\"{x:210,y:605,t:1527869797823};\\\", \\\"{x:208,y:605,t:1527869797841};\\\", \\\"{x:207,y:605,t:1527869797859};\\\", \\\"{x:205,y:606,t:1527869797875};\\\", \\\"{x:199,y:610,t:1527869797890};\\\", \\\"{x:188,y:616,t:1527869797908};\\\", \\\"{x:178,y:625,t:1527869797923};\\\", \\\"{x:174,y:628,t:1527869797941};\\\", \\\"{x:173,y:628,t:1527869797957};\\\", \\\"{x:173,y:629,t:1527869797973};\\\", \\\"{x:177,y:628,t:1527869798107};\\\", \\\"{x:183,y:627,t:1527869798114};\\\", \\\"{x:191,y:626,t:1527869798124};\\\", \\\"{x:223,y:625,t:1527869798141};\\\", \\\"{x:270,y:629,t:1527869798158};\\\", \\\"{x:326,y:637,t:1527869798175};\\\", \\\"{x:382,y:645,t:1527869798191};\\\", \\\"{x:422,y:652,t:1527869798208};\\\", \\\"{x:448,y:655,t:1527869798225};\\\", \\\"{x:454,y:655,t:1527869798240};\\\", \\\"{x:456,y:655,t:1527869798257};\\\", \\\"{x:457,y:655,t:1527869798378};\\\", \\\"{x:457,y:654,t:1527869798395};\\\", \\\"{x:456,y:653,t:1527869798408};\\\", \\\"{x:452,y:648,t:1527869798425};\\\", \\\"{x:442,y:639,t:1527869798441};\\\", \\\"{x:428,y:630,t:1527869798458};\\\", \\\"{x:395,y:612,t:1527869798475};\\\", \\\"{x:383,y:606,t:1527869798491};\\\", \\\"{x:347,y:587,t:1527869798508};\\\", \\\"{x:325,y:574,t:1527869798524};\\\", \\\"{x:308,y:566,t:1527869798541};\\\", \\\"{x:297,y:560,t:1527869798558};\\\", \\\"{x:289,y:557,t:1527869798575};\\\", \\\"{x:284,y:556,t:1527869798591};\\\", \\\"{x:280,y:554,t:1527869798608};\\\", \\\"{x:279,y:554,t:1527869798624};\\\", \\\"{x:278,y:554,t:1527869798642};\\\", \\\"{x:273,y:554,t:1527869798658};\\\", \\\"{x:263,y:551,t:1527869798675};\\\", \\\"{x:259,y:550,t:1527869798691};\\\", \\\"{x:253,y:547,t:1527869798707};\\\", \\\"{x:247,y:543,t:1527869798724};\\\", \\\"{x:241,y:540,t:1527869798742};\\\", \\\"{x:234,y:537,t:1527869798757};\\\", \\\"{x:232,y:536,t:1527869798775};\\\", \\\"{x:224,y:538,t:1527869799411};\\\", \\\"{x:218,y:539,t:1527869799424};\\\", \\\"{x:200,y:541,t:1527869799441};\\\", \\\"{x:176,y:541,t:1527869799459};\\\", \\\"{x:169,y:541,t:1527869799475};\\\", \\\"{x:167,y:541,t:1527869799492};\\\", \\\"{x:172,y:538,t:1527869800019};\\\", \\\"{x:186,y:535,t:1527869800026};\\\", \\\"{x:227,y:535,t:1527869800043};\\\", \\\"{x:294,y:533,t:1527869800059};\\\", \\\"{x:386,y:533,t:1527869800076};\\\", \\\"{x:489,y:533,t:1527869800093};\\\", \\\"{x:597,y:533,t:1527869800109};\\\", \\\"{x:685,y:533,t:1527869800125};\\\", \\\"{x:752,y:533,t:1527869800143};\\\", \\\"{x:790,y:532,t:1527869800159};\\\", \\\"{x:815,y:532,t:1527869800175};\\\", \\\"{x:828,y:529,t:1527869800193};\\\", \\\"{x:836,y:527,t:1527869800209};\\\", \\\"{x:843,y:525,t:1527869800226};\\\", \\\"{x:851,y:521,t:1527869800243};\\\", \\\"{x:857,y:520,t:1527869800258};\\\", \\\"{x:866,y:516,t:1527869800276};\\\", \\\"{x:881,y:511,t:1527869800292};\\\", \\\"{x:891,y:509,t:1527869800309};\\\", \\\"{x:892,y:509,t:1527869800326};\\\", \\\"{x:893,y:509,t:1527869800343};\\\", \\\"{x:891,y:509,t:1527869800394};\\\", \\\"{x:889,y:509,t:1527869800409};\\\", \\\"{x:884,y:506,t:1527869800425};\\\", \\\"{x:874,y:501,t:1527869800442};\\\", \\\"{x:870,y:499,t:1527869800459};\\\", \\\"{x:863,y:497,t:1527869800476};\\\", \\\"{x:860,y:497,t:1527869800493};\\\", \\\"{x:859,y:497,t:1527869800595};\\\", \\\"{x:858,y:497,t:1527869800611};\\\", \\\"{x:856,y:497,t:1527869800626};\\\", \\\"{x:854,y:497,t:1527869800643};\\\", \\\"{x:853,y:497,t:1527869800660};\\\", \\\"{x:851,y:497,t:1527869800676};\\\", \\\"{x:850,y:497,t:1527869800693};\\\", \\\"{x:849,y:497,t:1527869800710};\\\", \\\"{x:847,y:497,t:1527869800726};\\\", \\\"{x:846,y:497,t:1527869800743};\\\", \\\"{x:843,y:497,t:1527869800760};\\\", \\\"{x:842,y:498,t:1527869800776};\\\", \\\"{x:840,y:500,t:1527869800793};\\\", \\\"{x:837,y:503,t:1527869800810};\\\", \\\"{x:833,y:506,t:1527869800826};\\\", \\\"{x:830,y:507,t:1527869800843};\\\", \\\"{x:829,y:508,t:1527869800860};\\\", \\\"{x:829,y:509,t:1527869800995};\\\", \\\"{x:829,y:509,t:1527869801011};\\\", \\\"{x:829,y:511,t:1527869801539};\\\", \\\"{x:829,y:512,t:1527869801571};\\\", \\\"{x:829,y:514,t:1527869801731};\\\", \\\"{x:829,y:515,t:1527869801744};\\\", \\\"{x:829,y:517,t:1527869801761};\\\", \\\"{x:829,y:518,t:1527869801777};\\\", \\\"{x:828,y:520,t:1527869801947};\\\", \\\"{x:828,y:521,t:1527869801962};\\\", \\\"{x:827,y:521,t:1527869802123};\\\", \\\"{x:826,y:522,t:1527869802131};\\\", \\\"{x:825,y:523,t:1527869802144};\\\", \\\"{x:823,y:526,t:1527869802162};\\\", \\\"{x:820,y:533,t:1527869802178};\\\", \\\"{x:812,y:542,t:1527869802194};\\\", \\\"{x:790,y:569,t:1527869802211};\\\", \\\"{x:759,y:598,t:1527869802228};\\\", \\\"{x:709,y:641,t:1527869802244};\\\", \\\"{x:669,y:672,t:1527869802261};\\\", \\\"{x:638,y:694,t:1527869802278};\\\", \\\"{x:614,y:712,t:1527869802294};\\\", \\\"{x:595,y:726,t:1527869802311};\\\", \\\"{x:583,y:741,t:1527869802328};\\\", \\\"{x:572,y:758,t:1527869802344};\\\", \\\"{x:566,y:768,t:1527869802360};\\\", \\\"{x:560,y:778,t:1527869802378};\\\", \\\"{x:557,y:784,t:1527869802394};\\\", \\\"{x:552,y:790,t:1527869802411};\\\", \\\"{x:551,y:791,t:1527869802428};\\\", \\\"{x:549,y:793,t:1527869802443};\\\", \\\"{x:548,y:794,t:1527869802461};\\\", \\\"{x:546,y:797,t:1527869802478};\\\", \\\"{x:545,y:798,t:1527869802494};\\\", \\\"{x:543,y:801,t:1527869802511};\\\", \\\"{x:540,y:805,t:1527869802528};\\\", \\\"{x:539,y:807,t:1527869802544};\\\", \\\"{x:535,y:811,t:1527869802561};\\\", \\\"{x:533,y:812,t:1527869802577};\\\", \\\"{x:532,y:812,t:1527869802595};\\\", \\\"{x:529,y:812,t:1527869802659};\\\", \\\"{x:526,y:812,t:1527869802667};\\\", \\\"{x:522,y:813,t:1527869802677};\\\", \\\"{x:513,y:813,t:1527869802694};\\\", \\\"{x:503,y:813,t:1527869802711};\\\", \\\"{x:497,y:813,t:1527869802728};\\\", \\\"{x:490,y:810,t:1527869802745};\\\", \\\"{x:486,y:808,t:1527869802761};\\\", \\\"{x:484,y:806,t:1527869802778};\\\", \\\"{x:484,y:804,t:1527869802794};\\\", \\\"{x:484,y:802,t:1527869802827};\\\", \\\"{x:484,y:801,t:1527869802907};\\\", \\\"{x:484,y:799,t:1527869802914};\\\", \\\"{x:483,y:798,t:1527869802947};\\\", \\\"{x:483,y:797,t:1527869802961};\\\", \\\"{x:483,y:796,t:1527869802978};\\\", \\\"{x:483,y:795,t:1527869803171};\\\", \\\"{x:483,y:794,t:1527869803347};\\\", \\\"{x:483,y:793,t:1527869803363};\\\", \\\"{x:483,y:792,t:1527869803387};\\\", \\\"{x:483,y:791,t:1527869803483};\\\", \\\"{x:483,y:790,t:1527869803495};\\\", \\\"{x:485,y:786,t:1527869803512};\\\", \\\"{x:485,y:782,t:1527869803528};\\\", \\\"{x:488,y:776,t:1527869803544};\\\", \\\"{x:489,y:770,t:1527869803562};\\\", \\\"{x:492,y:764,t:1527869803578};\\\", \\\"{x:492,y:761,t:1527869803595};\\\", \\\"{x:493,y:757,t:1527869803612};\\\", \\\"{x:493,y:753,t:1527869803629};\\\", \\\"{x:495,y:751,t:1527869803645};\\\", \\\"{x:496,y:748,t:1527869803663};\\\", \\\"{x:496,y:745,t:1527869803679};\\\", \\\"{x:496,y:744,t:1527869803696};\\\", \\\"{x:497,y:742,t:1527869803712};\\\", \\\"{x:498,y:740,t:1527869803729};\\\" ] }, { \\\"rt\\\": 35645, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 12, \\\"time_elapsed\\\": 535471, \\\"internal_node_id\\\": \\\"0.0-6.0-2.0\\\", \\\"subject\\\": \\\"DZD6F\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"victor\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+contained\\\", \\\"q\\\": 8, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-X -04 PM-G -G -E -E \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:491,y:731,t:1527869816963};\\\", \\\"{x:470,y:709,t:1527869816972};\\\", \\\"{x:449,y:682,t:1527869816989};\\\", \\\"{x:447,y:681,t:1527869817006};\\\", \\\"{x:450,y:676,t:1527869817243};\\\", \\\"{x:464,y:670,t:1527869817257};\\\", \\\"{x:498,y:660,t:1527869817273};\\\", \\\"{x:543,y:648,t:1527869817290};\\\", \\\"{x:616,y:626,t:1527869817307};\\\", \\\"{x:674,y:618,t:1527869817323};\\\", \\\"{x:736,y:608,t:1527869817339};\\\", \\\"{x:802,y:601,t:1527869817356};\\\", \\\"{x:882,y:592,t:1527869817373};\\\", \\\"{x:937,y:588,t:1527869817390};\\\", \\\"{x:1001,y:588,t:1527869817407};\\\", \\\"{x:1052,y:588,t:1527869817423};\\\", \\\"{x:1096,y:588,t:1527869817439};\\\", \\\"{x:1136,y:588,t:1527869817456};\\\", \\\"{x:1164,y:588,t:1527869817473};\\\", \\\"{x:1190,y:588,t:1527869817489};\\\", \\\"{x:1220,y:588,t:1527869817507};\\\", \\\"{x:1236,y:588,t:1527869817524};\\\", \\\"{x:1251,y:591,t:1527869817539};\\\", \\\"{x:1260,y:599,t:1527869817556};\\\", \\\"{x:1266,y:608,t:1527869817573};\\\", \\\"{x:1275,y:632,t:1527869817590};\\\", \\\"{x:1282,y:659,t:1527869817607};\\\", \\\"{x:1287,y:681,t:1527869817623};\\\", \\\"{x:1292,y:698,t:1527869817639};\\\", \\\"{x:1292,y:710,t:1527869817657};\\\", \\\"{x:1292,y:721,t:1527869817673};\\\", \\\"{x:1292,y:730,t:1527869817689};\\\", \\\"{x:1291,y:736,t:1527869817706};\\\", \\\"{x:1291,y:737,t:1527869817723};\\\", \\\"{x:1291,y:740,t:1527869817779};\\\", \\\"{x:1291,y:741,t:1527869817789};\\\", \\\"{x:1291,y:747,t:1527869817806};\\\", \\\"{x:1291,y:748,t:1527869817824};\\\", \\\"{x:1290,y:756,t:1527869817840};\\\", \\\"{x:1289,y:756,t:1527869817856};\\\", \\\"{x:1288,y:759,t:1527869817874};\\\", \\\"{x:1288,y:758,t:1527869817979};\\\", \\\"{x:1288,y:757,t:1527869817990};\\\", \\\"{x:1289,y:756,t:1527869818006};\\\", \\\"{x:1289,y:753,t:1527869818024};\\\", \\\"{x:1290,y:752,t:1527869818040};\\\", \\\"{x:1291,y:751,t:1527869818059};\\\", \\\"{x:1292,y:751,t:1527869818082};\\\", \\\"{x:1292,y:750,t:1527869818107};\\\", \\\"{x:1293,y:750,t:1527869818123};\\\", \\\"{x:1293,y:749,t:1527869818141};\\\", \\\"{x:1294,y:749,t:1527869818156};\\\", \\\"{x:1295,y:749,t:1527869818173};\\\", \\\"{x:1298,y:748,t:1527869818191};\\\", \\\"{x:1299,y:747,t:1527869818206};\\\", \\\"{x:1302,y:746,t:1527869818223};\\\", \\\"{x:1304,y:746,t:1527869818241};\\\", \\\"{x:1307,y:746,t:1527869818257};\\\", \\\"{x:1311,y:746,t:1527869818273};\\\", \\\"{x:1319,y:747,t:1527869818290};\\\", \\\"{x:1323,y:748,t:1527869818306};\\\", \\\"{x:1328,y:750,t:1527869818323};\\\", \\\"{x:1332,y:753,t:1527869818341};\\\", \\\"{x:1334,y:754,t:1527869818356};\\\", \\\"{x:1334,y:755,t:1527869818427};\\\", \\\"{x:1334,y:751,t:1527869819530};\\\", \\\"{x:1334,y:749,t:1527869819540};\\\", \\\"{x:1335,y:743,t:1527869819558};\\\", \\\"{x:1336,y:738,t:1527869819574};\\\", \\\"{x:1337,y:734,t:1527869819591};\\\", \\\"{x:1338,y:727,t:1527869819608};\\\", \\\"{x:1338,y:724,t:1527869819624};\\\", \\\"{x:1338,y:720,t:1527869819641};\\\", \\\"{x:1340,y:712,t:1527869819657};\\\", \\\"{x:1341,y:703,t:1527869819675};\\\", \\\"{x:1341,y:692,t:1527869819690};\\\", \\\"{x:1341,y:682,t:1527869819708};\\\", \\\"{x:1341,y:672,t:1527869819725};\\\", \\\"{x:1338,y:663,t:1527869819740};\\\", \\\"{x:1337,y:655,t:1527869819758};\\\", \\\"{x:1335,y:646,t:1527869819774};\\\", \\\"{x:1334,y:636,t:1527869819791};\\\", \\\"{x:1333,y:629,t:1527869819808};\\\", \\\"{x:1332,y:625,t:1527869819825};\\\", \\\"{x:1331,y:620,t:1527869819841};\\\", \\\"{x:1331,y:617,t:1527869819857};\\\", \\\"{x:1329,y:614,t:1527869819875};\\\", \\\"{x:1329,y:613,t:1527869819891};\\\", \\\"{x:1329,y:609,t:1527869819907};\\\", \\\"{x:1327,y:606,t:1527869819924};\\\", \\\"{x:1324,y:601,t:1527869819941};\\\", \\\"{x:1322,y:598,t:1527869819957};\\\", \\\"{x:1319,y:594,t:1527869819975};\\\", \\\"{x:1315,y:589,t:1527869819991};\\\", \\\"{x:1313,y:586,t:1527869820007};\\\", \\\"{x:1311,y:584,t:1527869820025};\\\", \\\"{x:1310,y:581,t:1527869820040};\\\", \\\"{x:1308,y:579,t:1527869820058};\\\", \\\"{x:1307,y:577,t:1527869820075};\\\", \\\"{x:1306,y:576,t:1527869820091};\\\", \\\"{x:1305,y:574,t:1527869820115};\\\", \\\"{x:1304,y:574,t:1527869820124};\\\", \\\"{x:1303,y:573,t:1527869820141};\\\", \\\"{x:1302,y:571,t:1527869820157};\\\", \\\"{x:1300,y:567,t:1527869820175};\\\", \\\"{x:1296,y:564,t:1527869820190};\\\", \\\"{x:1292,y:560,t:1527869820207};\\\", \\\"{x:1290,y:558,t:1527869820224};\\\", \\\"{x:1289,y:557,t:1527869820241};\\\", \\\"{x:1288,y:557,t:1527869820258};\\\", \\\"{x:1287,y:557,t:1527869824371};\\\", \\\"{x:1287,y:560,t:1527869824379};\\\", \\\"{x:1292,y:566,t:1527869824393};\\\", \\\"{x:1302,y:575,t:1527869824410};\\\", \\\"{x:1313,y:582,t:1527869824427};\\\", \\\"{x:1319,y:585,t:1527869824443};\\\", \\\"{x:1321,y:588,t:1527869824459};\\\", \\\"{x:1324,y:589,t:1527869824477};\\\", \\\"{x:1330,y:593,t:1527869824493};\\\", \\\"{x:1337,y:601,t:1527869824509};\\\", \\\"{x:1349,y:615,t:1527869824527};\\\", \\\"{x:1362,y:633,t:1527869824542};\\\", \\\"{x:1372,y:644,t:1527869824559};\\\", \\\"{x:1383,y:659,t:1527869824576};\\\", \\\"{x:1391,y:670,t:1527869824593};\\\", \\\"{x:1398,y:681,t:1527869824610};\\\", \\\"{x:1406,y:701,t:1527869824626};\\\", \\\"{x:1410,y:714,t:1527869824643};\\\", \\\"{x:1416,y:728,t:1527869824660};\\\", \\\"{x:1420,y:740,t:1527869824676};\\\", \\\"{x:1423,y:749,t:1527869824693};\\\", \\\"{x:1426,y:754,t:1527869824710};\\\", \\\"{x:1427,y:756,t:1527869824726};\\\", \\\"{x:1427,y:757,t:1527869824743};\\\", \\\"{x:1428,y:760,t:1527869824759};\\\", \\\"{x:1429,y:768,t:1527869824777};\\\", \\\"{x:1432,y:776,t:1527869824794};\\\", \\\"{x:1434,y:785,t:1527869824809};\\\", \\\"{x:1442,y:801,t:1527869824827};\\\", \\\"{x:1443,y:806,t:1527869824843};\\\", \\\"{x:1446,y:809,t:1527869824860};\\\", \\\"{x:1447,y:812,t:1527869824877};\\\", \\\"{x:1447,y:813,t:1527869824922};\\\", \\\"{x:1448,y:813,t:1527869824954};\\\", \\\"{x:1449,y:814,t:1527869824986};\\\", \\\"{x:1450,y:815,t:1527869824994};\\\", \\\"{x:1450,y:817,t:1527869825010};\\\", \\\"{x:1456,y:824,t:1527869825026};\\\", \\\"{x:1460,y:829,t:1527869825044};\\\", \\\"{x:1463,y:833,t:1527869825059};\\\", \\\"{x:1465,y:837,t:1527869825077};\\\", \\\"{x:1466,y:838,t:1527869825139};\\\", \\\"{x:1467,y:839,t:1527869825259};\\\", \\\"{x:1468,y:839,t:1527869825282};\\\", \\\"{x:1470,y:839,t:1527869825294};\\\", \\\"{x:1472,y:840,t:1527869825310};\\\", \\\"{x:1474,y:840,t:1527869825467};\\\", \\\"{x:1475,y:840,t:1527869825506};\\\", \\\"{x:1477,y:839,t:1527869825547};\\\", \\\"{x:1477,y:838,t:1527869825560};\\\", \\\"{x:1479,y:838,t:1527869825577};\\\", \\\"{x:1480,y:836,t:1527869825593};\\\", \\\"{x:1482,y:833,t:1527869825611};\\\", \\\"{x:1483,y:831,t:1527869825627};\\\", \\\"{x:1485,y:828,t:1527869825644};\\\", \\\"{x:1486,y:826,t:1527869825675};\\\", \\\"{x:1487,y:825,t:1527869825715};\\\", \\\"{x:1488,y:825,t:1527869825738};\\\", \\\"{x:1490,y:825,t:1527869825746};\\\", \\\"{x:1491,y:825,t:1527869826170};\\\", \\\"{x:1491,y:830,t:1527869826178};\\\", \\\"{x:1491,y:841,t:1527869826193};\\\", \\\"{x:1491,y:864,t:1527869826210};\\\", \\\"{x:1492,y:877,t:1527869826228};\\\", \\\"{x:1492,y:893,t:1527869826244};\\\", \\\"{x:1492,y:910,t:1527869826261};\\\", \\\"{x:1489,y:923,t:1527869826277};\\\", \\\"{x:1488,y:929,t:1527869826293};\\\", \\\"{x:1486,y:932,t:1527869826311};\\\", \\\"{x:1486,y:933,t:1527869826328};\\\", \\\"{x:1485,y:933,t:1527869826386};\\\", \\\"{x:1485,y:931,t:1527869826394};\\\", \\\"{x:1485,y:925,t:1527869826411};\\\", \\\"{x:1485,y:916,t:1527869826428};\\\", \\\"{x:1485,y:909,t:1527869826444};\\\", \\\"{x:1488,y:899,t:1527869826461};\\\", \\\"{x:1496,y:884,t:1527869826478};\\\", \\\"{x:1504,y:874,t:1527869826493};\\\", \\\"{x:1510,y:865,t:1527869826510};\\\", \\\"{x:1516,y:860,t:1527869826527};\\\", \\\"{x:1526,y:851,t:1527869826544};\\\", \\\"{x:1540,y:844,t:1527869826560};\\\", \\\"{x:1551,y:840,t:1527869826578};\\\", \\\"{x:1555,y:840,t:1527869826594};\\\", \\\"{x:1558,y:840,t:1527869826611};\\\", \\\"{x:1562,y:840,t:1527869826627};\\\", \\\"{x:1567,y:844,t:1527869826643};\\\", \\\"{x:1572,y:855,t:1527869826661};\\\", \\\"{x:1583,y:876,t:1527869826678};\\\", \\\"{x:1600,y:914,t:1527869826694};\\\", \\\"{x:1608,y:940,t:1527869826711};\\\", \\\"{x:1612,y:958,t:1527869826727};\\\", \\\"{x:1616,y:970,t:1527869826745};\\\", \\\"{x:1616,y:973,t:1527869826761};\\\", \\\"{x:1616,y:975,t:1527869826777};\\\", \\\"{x:1615,y:977,t:1527869826795};\\\", \\\"{x:1614,y:978,t:1527869826810};\\\", \\\"{x:1613,y:979,t:1527869826842};\\\", \\\"{x:1613,y:980,t:1527869826874};\\\", \\\"{x:1613,y:978,t:1527869826994};\\\", \\\"{x:1612,y:971,t:1527869827010};\\\", \\\"{x:1609,y:953,t:1527869827028};\\\", \\\"{x:1601,y:915,t:1527869827045};\\\", \\\"{x:1575,y:837,t:1527869827061};\\\", \\\"{x:1545,y:763,t:1527869827077};\\\", \\\"{x:1510,y:693,t:1527869827095};\\\", \\\"{x:1473,y:639,t:1527869827111};\\\", \\\"{x:1448,y:610,t:1527869827128};\\\", \\\"{x:1435,y:592,t:1527869827145};\\\", \\\"{x:1428,y:582,t:1527869827161};\\\", \\\"{x:1425,y:574,t:1527869827178};\\\", \\\"{x:1417,y:562,t:1527869827195};\\\", \\\"{x:1412,y:556,t:1527869827211};\\\", \\\"{x:1407,y:553,t:1527869827228};\\\", \\\"{x:1401,y:551,t:1527869827245};\\\", \\\"{x:1394,y:550,t:1527869827261};\\\", \\\"{x:1387,y:550,t:1527869827278};\\\", \\\"{x:1379,y:550,t:1527869827295};\\\", \\\"{x:1370,y:550,t:1527869827311};\\\", \\\"{x:1364,y:551,t:1527869827328};\\\", \\\"{x:1356,y:554,t:1527869827345};\\\", \\\"{x:1352,y:555,t:1527869827362};\\\", \\\"{x:1346,y:558,t:1527869827378};\\\", \\\"{x:1335,y:564,t:1527869827394};\\\", \\\"{x:1329,y:566,t:1527869827412};\\\", \\\"{x:1322,y:567,t:1527869827427};\\\", \\\"{x:1318,y:568,t:1527869827444};\\\", \\\"{x:1317,y:568,t:1527869827461};\\\", \\\"{x:1317,y:569,t:1527869827498};\\\", \\\"{x:1316,y:570,t:1527869827514};\\\", \\\"{x:1315,y:570,t:1527869827530};\\\", \\\"{x:1314,y:570,t:1527869827545};\\\", \\\"{x:1314,y:571,t:1527869827562};\\\", \\\"{x:1313,y:571,t:1527869827619};\\\", \\\"{x:1312,y:571,t:1527869827628};\\\", \\\"{x:1311,y:570,t:1527869827650};\\\", \\\"{x:1310,y:569,t:1527869827698};\\\", \\\"{x:1309,y:567,t:1527869827722};\\\", \\\"{x:1308,y:567,t:1527869827778};\\\", \\\"{x:1307,y:567,t:1527869827818};\\\", \\\"{x:1306,y:567,t:1527869827834};\\\", \\\"{x:1304,y:567,t:1527869827845};\\\", \\\"{x:1303,y:567,t:1527869827862};\\\", \\\"{x:1298,y:566,t:1527869827878};\\\", \\\"{x:1290,y:566,t:1527869827895};\\\", \\\"{x:1281,y:566,t:1527869827912};\\\", \\\"{x:1270,y:569,t:1527869827928};\\\", \\\"{x:1260,y:571,t:1527869827945};\\\", \\\"{x:1257,y:572,t:1527869827961};\\\", \\\"{x:1256,y:572,t:1527869828098};\\\", \\\"{x:1257,y:571,t:1527869828122};\\\", \\\"{x:1258,y:570,t:1527869828130};\\\", \\\"{x:1260,y:569,t:1527869828145};\\\", \\\"{x:1267,y:563,t:1527869828162};\\\", \\\"{x:1272,y:560,t:1527869828179};\\\", \\\"{x:1276,y:558,t:1527869828195};\\\", \\\"{x:1277,y:556,t:1527869828212};\\\", \\\"{x:1278,y:555,t:1527869828371};\\\", \\\"{x:1279,y:554,t:1527869829410};\\\", \\\"{x:1275,y:554,t:1527869830211};\\\", \\\"{x:1268,y:556,t:1527869830218};\\\", \\\"{x:1259,y:560,t:1527869830230};\\\", \\\"{x:1232,y:572,t:1527869830246};\\\", \\\"{x:1208,y:582,t:1527869830263};\\\", \\\"{x:1184,y:594,t:1527869830280};\\\", \\\"{x:1159,y:602,t:1527869830296};\\\", \\\"{x:1137,y:607,t:1527869830313};\\\", \\\"{x:1119,y:612,t:1527869830330};\\\", \\\"{x:1095,y:616,t:1527869830345};\\\", \\\"{x:1051,y:616,t:1527869830363};\\\", \\\"{x:1023,y:615,t:1527869830380};\\\", \\\"{x:998,y:610,t:1527869830396};\\\", \\\"{x:979,y:607,t:1527869830412};\\\", \\\"{x:963,y:604,t:1527869830430};\\\", \\\"{x:952,y:603,t:1527869830445};\\\", \\\"{x:944,y:603,t:1527869830463};\\\", \\\"{x:941,y:603,t:1527869830480};\\\", \\\"{x:933,y:603,t:1527869830496};\\\", \\\"{x:919,y:603,t:1527869830513};\\\", \\\"{x:900,y:603,t:1527869830530};\\\", \\\"{x:856,y:597,t:1527869830547};\\\", \\\"{x:819,y:591,t:1527869830563};\\\", \\\"{x:777,y:577,t:1527869830584};\\\", \\\"{x:735,y:564,t:1527869830600};\\\", \\\"{x:703,y:557,t:1527869830618};\\\", \\\"{x:685,y:551,t:1527869830634};\\\", \\\"{x:673,y:546,t:1527869830649};\\\", \\\"{x:665,y:541,t:1527869830667};\\\", \\\"{x:664,y:541,t:1527869830786};\\\", \\\"{x:662,y:541,t:1527869830802};\\\", \\\"{x:660,y:540,t:1527869830817};\\\", \\\"{x:658,y:536,t:1527869830834};\\\", \\\"{x:656,y:531,t:1527869830850};\\\", \\\"{x:656,y:529,t:1527869830866};\\\", \\\"{x:656,y:528,t:1527869830884};\\\", \\\"{x:656,y:527,t:1527869830970};\\\", \\\"{x:656,y:526,t:1527869830984};\\\", \\\"{x:656,y:524,t:1527869831001};\\\", \\\"{x:656,y:521,t:1527869831018};\\\", \\\"{x:656,y:518,t:1527869831034};\\\", \\\"{x:656,y:516,t:1527869831051};\\\", \\\"{x:656,y:515,t:1527869831068};\\\", \\\"{x:654,y:513,t:1527869831084};\\\", \\\"{x:654,y:512,t:1527869831101};\\\", \\\"{x:651,y:512,t:1527869831131};\\\", \\\"{x:647,y:511,t:1527869831138};\\\", \\\"{x:646,y:511,t:1527869831151};\\\", \\\"{x:642,y:511,t:1527869831167};\\\", \\\"{x:634,y:512,t:1527869831184};\\\", \\\"{x:626,y:514,t:1527869831201};\\\", \\\"{x:617,y:521,t:1527869831218};\\\", \\\"{x:616,y:522,t:1527869831234};\\\", \\\"{x:614,y:522,t:1527869831251};\\\", \\\"{x:613,y:522,t:1527869831482};\\\", \\\"{x:612,y:519,t:1527869831490};\\\", \\\"{x:611,y:516,t:1527869831501};\\\", \\\"{x:610,y:513,t:1527869831518};\\\", \\\"{x:609,y:510,t:1527869831534};\\\", \\\"{x:606,y:505,t:1527869831549};\\\", \\\"{x:605,y:502,t:1527869831567};\\\", \\\"{x:605,y:500,t:1527869831584};\\\", \\\"{x:604,y:500,t:1527869831714};\\\", \\\"{x:604,y:501,t:1527869833074};\\\", \\\"{x:604,y:501,t:1527869833135};\\\", \\\"{x:604,y:502,t:1527869834379};\\\", \\\"{x:604,y:505,t:1527869834386};\\\", \\\"{x:604,y:517,t:1527869834403};\\\", \\\"{x:600,y:539,t:1527869834421};\\\", \\\"{x:588,y:582,t:1527869834436};\\\", \\\"{x:575,y:634,t:1527869834454};\\\", \\\"{x:563,y:681,t:1527869834470};\\\", \\\"{x:550,y:724,t:1527869834487};\\\", \\\"{x:547,y:747,t:1527869834503};\\\", \\\"{x:541,y:764,t:1527869834520};\\\", \\\"{x:537,y:777,t:1527869834537};\\\", \\\"{x:536,y:782,t:1527869834553};\\\", \\\"{x:535,y:785,t:1527869834570};\\\", \\\"{x:534,y:786,t:1527869834587};\\\", \\\"{x:534,y:788,t:1527869834675};\\\", \\\"{x:534,y:783,t:1527869834803};\\\", \\\"{x:534,y:779,t:1527869834810};\\\", \\\"{x:533,y:770,t:1527869834820};\\\", \\\"{x:532,y:760,t:1527869834836};\\\", \\\"{x:531,y:751,t:1527869834853};\\\", \\\"{x:531,y:749,t:1527869834870};\\\", \\\"{x:531,y:748,t:1527869834987};\\\", \\\"{x:531,y:746,t:1527869835003};\\\", \\\"{x:531,y:745,t:1527869835019};\\\", \\\"{x:531,y:743,t:1527869835037};\\\", \\\"{x:531,y:742,t:1527869835595};\\\", \\\"{x:531,y:741,t:1527869835659};\\\", \\\"{x:531,y:740,t:1527869835690};\\\", \\\"{x:531,y:739,t:1527869835810};\\\", \\\"{x:531,y:737,t:1527869835842};\\\", \\\"{x:531,y:736,t:1527869835874};\\\", \\\"{x:531,y:739,t:1527869841674};\\\", \\\"{x:531,y:744,t:1527869841690};\\\", \\\"{x:529,y:753,t:1527869841706};\\\", \\\"{x:527,y:760,t:1527869841722};\\\", \\\"{x:527,y:763,t:1527869841739};\\\", \\\"{x:526,y:765,t:1527869841756};\\\", \\\"{x:526,y:767,t:1527869841777};\\\", \\\"{x:526,y:765,t:1527869841898};\\\", \\\"{x:526,y:763,t:1527869841909};\\\", \\\"{x:526,y:758,t:1527869841926};\\\", \\\"{x:526,y:755,t:1527869841942};\\\", \\\"{x:526,y:750,t:1527869841960};\\\", \\\"{x:526,y:747,t:1527869841976};\\\", \\\"{x:526,y:745,t:1527869841992};\\\", \\\"{x:526,y:744,t:1527869842009};\\\", \\\"{x:526,y:743,t:1527869842026};\\\" ] }, { \\\"rt\\\": 24361, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 13, \\\"time_elapsed\\\": 561075, \\\"internal_node_id\\\": \\\"0.0-6.0-3.0\\\", \\\"subject\\\": \\\"DZD6F\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"victor\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime+before+endtime+during\\\", \\\"q\\\": 9, \\\"clicks\\\": 1.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"I\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:528,y:742,t:1527869845994};\\\", \\\"{x:529,y:738,t:1527869846004};\\\", \\\"{x:530,y:726,t:1527869846022};\\\", \\\"{x:531,y:722,t:1527869846038};\\\", \\\"{x:531,y:721,t:1527869846250};\\\", \\\"{x:532,y:721,t:1527869846266};\\\", \\\"{x:533,y:720,t:1527869846274};\\\", \\\"{x:533,y:718,t:1527869846290};\\\", \\\"{x:533,y:717,t:1527869846314};\\\", \\\"{x:534,y:716,t:1527869846354};\\\", \\\"{x:534,y:715,t:1527869846362};\\\", \\\"{x:535,y:715,t:1527869846402};\\\", \\\"{x:536,y:714,t:1527869846413};\\\", \\\"{x:538,y:712,t:1527869846482};\\\", \\\"{x:539,y:711,t:1527869846514};\\\", \\\"{x:539,y:710,t:1527869846529};\\\", \\\"{x:539,y:709,t:1527869846546};\\\", \\\"{x:538,y:710,t:1527869848246};\\\", \\\"{x:538,y:713,t:1527869848254};\\\", \\\"{x:538,y:716,t:1527869848268};\\\", \\\"{x:538,y:718,t:1527869848285};\\\", \\\"{x:538,y:719,t:1527869863806};\\\", \\\"{x:543,y:719,t:1527869863814};\\\", \\\"{x:551,y:719,t:1527869863831};\\\", \\\"{x:552,y:719,t:1527869863854};\\\", \\\"{x:552,y:718,t:1527869863864};\\\", \\\"{x:552,y:717,t:1527869864477};\\\", \\\"{x:552,y:714,t:1527869864485};\\\", \\\"{x:552,y:713,t:1527869864498};\\\", \\\"{x:554,y:711,t:1527869864515};\\\", \\\"{x:555,y:711,t:1527869864531};\\\", \\\"{x:556,y:709,t:1527869864548};\\\", \\\"{x:557,y:708,t:1527869864566};\\\", \\\"{x:559,y:707,t:1527869864581};\\\", \\\"{x:560,y:707,t:1527869864598};\\\", \\\"{x:560,y:705,t:1527869864638};\\\", \\\"{x:561,y:704,t:1527869864649};\\\", \\\"{x:561,y:702,t:1527869864665};\\\", \\\"{x:561,y:699,t:1527869864681};\\\", \\\"{x:561,y:694,t:1527869864698};\\\", \\\"{x:561,y:690,t:1527869864715};\\\", \\\"{x:561,y:687,t:1527869864731};\\\", \\\"{x:561,y:684,t:1527869864748};\\\", \\\"{x:561,y:683,t:1527869864765};\\\", \\\"{x:561,y:682,t:1527869864797};\\\", \\\"{x:561,y:681,t:1527869864878};\\\", \\\"{x:561,y:679,t:1527869864893};\\\", \\\"{x:561,y:676,t:1527869864902};\\\", \\\"{x:559,y:675,t:1527869864915};\\\", \\\"{x:556,y:671,t:1527869864932};\\\", \\\"{x:552,y:666,t:1527869864949};\\\", \\\"{x:544,y:660,t:1527869864965};\\\", \\\"{x:531,y:651,t:1527869864981};\\\", \\\"{x:526,y:650,t:1527869864998};\\\", \\\"{x:519,y:646,t:1527869865015};\\\", \\\"{x:512,y:643,t:1527869865032};\\\", \\\"{x:505,y:641,t:1527869865048};\\\", \\\"{x:498,y:637,t:1527869865065};\\\", \\\"{x:487,y:627,t:1527869865083};\\\", \\\"{x:473,y:613,t:1527869865098};\\\", \\\"{x:457,y:591,t:1527869865116};\\\", \\\"{x:446,y:575,t:1527869865132};\\\", \\\"{x:434,y:557,t:1527869865148};\\\", \\\"{x:425,y:542,t:1527869865165};\\\", \\\"{x:417,y:528,t:1527869865181};\\\", \\\"{x:417,y:525,t:1527869865199};\\\", \\\"{x:416,y:524,t:1527869865215};\\\", \\\"{x:415,y:522,t:1527869865232};\\\", \\\"{x:415,y:520,t:1527869865248};\\\", \\\"{x:414,y:518,t:1527869865277};\\\", \\\"{x:413,y:517,t:1527869865286};\\\", \\\"{x:413,y:516,t:1527869865298};\\\", \\\"{x:413,y:515,t:1527869865317};\\\", \\\"{x:412,y:515,t:1527869865332};\\\", \\\"{x:412,y:514,t:1527869865365};\\\", \\\"{x:406,y:514,t:1527869865381};\\\", \\\"{x:388,y:515,t:1527869865398};\\\", \\\"{x:363,y:523,t:1527869865416};\\\", \\\"{x:323,y:536,t:1527869865432};\\\", \\\"{x:281,y:549,t:1527869865448};\\\", \\\"{x:242,y:559,t:1527869865465};\\\", \\\"{x:208,y:569,t:1527869865483};\\\", \\\"{x:188,y:573,t:1527869865498};\\\", \\\"{x:177,y:574,t:1527869865515};\\\", \\\"{x:170,y:574,t:1527869865532};\\\", \\\"{x:165,y:574,t:1527869865549};\\\", \\\"{x:160,y:569,t:1527869865565};\\\", \\\"{x:153,y:561,t:1527869865582};\\\", \\\"{x:146,y:547,t:1527869865599};\\\", \\\"{x:135,y:535,t:1527869865615};\\\", \\\"{x:128,y:528,t:1527869865632};\\\", \\\"{x:123,y:522,t:1527869865649};\\\", \\\"{x:122,y:518,t:1527869865666};\\\", \\\"{x:122,y:515,t:1527869865683};\\\", \\\"{x:122,y:512,t:1527869865699};\\\", \\\"{x:123,y:508,t:1527869865715};\\\", \\\"{x:127,y:505,t:1527869865733};\\\", \\\"{x:128,y:503,t:1527869865750};\\\", \\\"{x:129,y:500,t:1527869865765};\\\", \\\"{x:130,y:496,t:1527869865782};\\\", \\\"{x:131,y:495,t:1527869865799};\\\", \\\"{x:131,y:494,t:1527869865830};\\\", \\\"{x:132,y:495,t:1527869865894};\\\", \\\"{x:133,y:495,t:1527869865901};\\\", \\\"{x:135,y:497,t:1527869865933};\\\", \\\"{x:136,y:497,t:1527869865950};\\\", \\\"{x:137,y:498,t:1527869865965};\\\", \\\"{x:138,y:498,t:1527869865989};\\\", \\\"{x:139,y:498,t:1527869866013};\\\", \\\"{x:140,y:498,t:1527869866029};\\\", \\\"{x:141,y:499,t:1527869866037};\\\", \\\"{x:141,y:500,t:1527869866049};\\\", \\\"{x:143,y:500,t:1527869866065};\\\", \\\"{x:146,y:500,t:1527869866082};\\\", \\\"{x:147,y:501,t:1527869866099};\\\", \\\"{x:148,y:501,t:1527869866166};\\\", \\\"{x:149,y:501,t:1527869866198};\\\", \\\"{x:150,y:501,t:1527869866205};\\\", \\\"{x:152,y:502,t:1527869866238};\\\", \\\"{x:153,y:503,t:1527869866878};\\\", \\\"{x:153,y:504,t:1527869866885};\\\", \\\"{x:154,y:506,t:1527869866899};\\\", \\\"{x:156,y:508,t:1527869866916};\\\", \\\"{x:157,y:510,t:1527869866933};\\\", \\\"{x:160,y:512,t:1527869867334};\\\", \\\"{x:184,y:527,t:1527869867351};\\\", \\\"{x:222,y:547,t:1527869867367};\\\", \\\"{x:266,y:575,t:1527869867383};\\\", \\\"{x:327,y:613,t:1527869867401};\\\", \\\"{x:405,y:655,t:1527869867419};\\\", \\\"{x:482,y:699,t:1527869867434};\\\", \\\"{x:547,y:733,t:1527869867450};\\\", \\\"{x:592,y:759,t:1527869867468};\\\", \\\"{x:615,y:774,t:1527869867483};\\\", \\\"{x:624,y:779,t:1527869867500};\\\", \\\"{x:626,y:781,t:1527869867517};\\\", \\\"{x:619,y:781,t:1527869867638};\\\", \\\"{x:610,y:775,t:1527869867650};\\\", \\\"{x:581,y:758,t:1527869867667};\\\", \\\"{x:565,y:751,t:1527869867684};\\\", \\\"{x:553,y:744,t:1527869867700};\\\", \\\"{x:540,y:735,t:1527869867717};\\\", \\\"{x:533,y:731,t:1527869867733};\\\", \\\"{x:527,y:728,t:1527869867750};\\\", \\\"{x:526,y:728,t:1527869867885};\\\" ] }, { \\\"rt\\\": 20997, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 14, \\\"time_elapsed\\\": 583297, \\\"internal_node_id\\\": \\\"0.0-6.0-4.0\\\", \\\"subject\\\": \\\"DZD6F\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"victor\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"ends\\\", \\\"q\\\": 10, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-04 PM-04 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:525,y:728,t:1527869870541};\\\", \\\"{x:527,y:728,t:1527869872309};\\\", \\\"{x:539,y:728,t:1527869872324};\\\", \\\"{x:590,y:728,t:1527869872340};\\\", \\\"{x:668,y:728,t:1527869872357};\\\", \\\"{x:751,y:728,t:1527869872371};\\\", \\\"{x:845,y:728,t:1527869872387};\\\", \\\"{x:937,y:728,t:1527869872404};\\\", \\\"{x:1076,y:727,t:1527869872421};\\\", \\\"{x:1165,y:714,t:1527869872437};\\\", \\\"{x:1237,y:705,t:1527869872454};\\\", \\\"{x:1298,y:699,t:1527869872471};\\\", \\\"{x:1341,y:690,t:1527869872488};\\\", \\\"{x:1364,y:686,t:1527869872504};\\\", \\\"{x:1381,y:679,t:1527869872521};\\\", \\\"{x:1398,y:675,t:1527869872537};\\\", \\\"{x:1412,y:674,t:1527869872554};\\\", \\\"{x:1415,y:674,t:1527869872571};\\\", \\\"{x:1417,y:674,t:1527869872589};\\\", \\\"{x:1418,y:674,t:1527869872614};\\\", \\\"{x:1420,y:674,t:1527869872629};\\\", \\\"{x:1423,y:674,t:1527869872638};\\\", \\\"{x:1430,y:674,t:1527869872655};\\\", \\\"{x:1434,y:674,t:1527869872671};\\\", \\\"{x:1437,y:674,t:1527869872689};\\\", \\\"{x:1437,y:675,t:1527869872704};\\\", \\\"{x:1435,y:679,t:1527869872722};\\\", \\\"{x:1424,y:686,t:1527869872739};\\\", \\\"{x:1411,y:694,t:1527869872754};\\\", \\\"{x:1396,y:700,t:1527869872771};\\\", \\\"{x:1383,y:704,t:1527869872788};\\\", \\\"{x:1370,y:706,t:1527869872805};\\\", \\\"{x:1346,y:710,t:1527869872822};\\\", \\\"{x:1335,y:714,t:1527869872838};\\\", \\\"{x:1327,y:716,t:1527869872854};\\\", \\\"{x:1321,y:718,t:1527869872872};\\\", \\\"{x:1320,y:719,t:1527869872888};\\\", \\\"{x:1319,y:719,t:1527869872933};\\\", \\\"{x:1319,y:718,t:1527869872957};\\\", \\\"{x:1319,y:716,t:1527869872971};\\\", \\\"{x:1323,y:711,t:1527869872988};\\\", \\\"{x:1327,y:707,t:1527869873005};\\\", \\\"{x:1331,y:705,t:1527869873021};\\\", \\\"{x:1332,y:704,t:1527869873038};\\\", \\\"{x:1334,y:703,t:1527869873055};\\\", \\\"{x:1335,y:703,t:1527869873142};\\\", \\\"{x:1337,y:704,t:1527869873198};\\\", \\\"{x:1337,y:705,t:1527869873213};\\\", \\\"{x:1337,y:706,t:1527869873229};\\\", \\\"{x:1337,y:707,t:1527869873246};\\\", \\\"{x:1338,y:708,t:1527869873255};\\\", \\\"{x:1338,y:710,t:1527869873273};\\\", \\\"{x:1338,y:713,t:1527869873288};\\\", \\\"{x:1338,y:717,t:1527869873305};\\\", \\\"{x:1338,y:724,t:1527869873323};\\\", \\\"{x:1338,y:730,t:1527869873339};\\\", \\\"{x:1339,y:740,t:1527869873355};\\\", \\\"{x:1341,y:751,t:1527869873372};\\\", \\\"{x:1341,y:764,t:1527869873389};\\\", \\\"{x:1341,y:774,t:1527869873405};\\\", \\\"{x:1341,y:782,t:1527869873422};\\\", \\\"{x:1341,y:791,t:1527869873439};\\\", \\\"{x:1341,y:798,t:1527869873455};\\\", \\\"{x:1341,y:805,t:1527869873472};\\\", \\\"{x:1341,y:815,t:1527869873489};\\\", \\\"{x:1341,y:827,t:1527869873506};\\\", \\\"{x:1341,y:845,t:1527869873523};\\\", \\\"{x:1341,y:861,t:1527869873539};\\\", \\\"{x:1341,y:875,t:1527869873556};\\\", \\\"{x:1341,y:889,t:1527869873572};\\\", \\\"{x:1341,y:908,t:1527869873589};\\\", \\\"{x:1341,y:915,t:1527869873606};\\\", \\\"{x:1341,y:920,t:1527869873622};\\\", \\\"{x:1341,y:918,t:1527869873694};\\\", \\\"{x:1341,y:913,t:1527869873706};\\\", \\\"{x:1341,y:898,t:1527869873722};\\\", \\\"{x:1341,y:874,t:1527869873739};\\\", \\\"{x:1341,y:849,t:1527869873756};\\\", \\\"{x:1338,y:818,t:1527869873773};\\\", \\\"{x:1337,y:785,t:1527869873789};\\\", \\\"{x:1338,y:768,t:1527869873806};\\\", \\\"{x:1340,y:754,t:1527869873824};\\\", \\\"{x:1340,y:746,t:1527869873840};\\\", \\\"{x:1340,y:736,t:1527869873856};\\\", \\\"{x:1339,y:729,t:1527869873874};\\\", \\\"{x:1339,y:728,t:1527869873889};\\\", \\\"{x:1339,y:726,t:1527869873906};\\\", \\\"{x:1339,y:725,t:1527869873949};\\\", \\\"{x:1339,y:723,t:1527869873982};\\\", \\\"{x:1339,y:722,t:1527869873989};\\\", \\\"{x:1340,y:719,t:1527869874006};\\\", \\\"{x:1344,y:713,t:1527869874023};\\\", \\\"{x:1345,y:707,t:1527869874040};\\\", \\\"{x:1348,y:704,t:1527869874057};\\\", \\\"{x:1352,y:701,t:1527869874074};\\\", \\\"{x:1353,y:700,t:1527869874091};\\\", \\\"{x:1356,y:701,t:1527869874141};\\\", \\\"{x:1358,y:705,t:1527869874157};\\\", \\\"{x:1372,y:721,t:1527869874173};\\\", \\\"{x:1384,y:733,t:1527869874190};\\\", \\\"{x:1395,y:743,t:1527869874206};\\\", \\\"{x:1405,y:752,t:1527869874223};\\\", \\\"{x:1412,y:760,t:1527869874240};\\\", \\\"{x:1416,y:768,t:1527869874258};\\\", \\\"{x:1422,y:778,t:1527869874274};\\\", \\\"{x:1426,y:788,t:1527869874290};\\\", \\\"{x:1432,y:801,t:1527869874307};\\\", \\\"{x:1436,y:810,t:1527869874323};\\\", \\\"{x:1440,y:818,t:1527869874340};\\\", \\\"{x:1456,y:840,t:1527869874358};\\\", \\\"{x:1471,y:857,t:1527869874373};\\\", \\\"{x:1481,y:871,t:1527869874390};\\\", \\\"{x:1492,y:882,t:1527869874408};\\\", \\\"{x:1505,y:897,t:1527869874423};\\\", \\\"{x:1520,y:912,t:1527869874441};\\\", \\\"{x:1537,y:925,t:1527869874457};\\\", \\\"{x:1554,y:937,t:1527869874474};\\\", \\\"{x:1573,y:947,t:1527869874490};\\\", \\\"{x:1590,y:954,t:1527869874507};\\\", \\\"{x:1600,y:958,t:1527869874524};\\\", \\\"{x:1607,y:964,t:1527869874540};\\\", \\\"{x:1622,y:973,t:1527869874557};\\\", \\\"{x:1631,y:979,t:1527869874574};\\\", \\\"{x:1636,y:982,t:1527869874591};\\\", \\\"{x:1639,y:984,t:1527869874607};\\\", \\\"{x:1640,y:985,t:1527869874624};\\\", \\\"{x:1641,y:985,t:1527869874742};\\\", \\\"{x:1641,y:983,t:1527869874758};\\\", \\\"{x:1641,y:981,t:1527869874774};\\\", \\\"{x:1641,y:977,t:1527869874791};\\\", \\\"{x:1639,y:976,t:1527869874807};\\\", \\\"{x:1638,y:974,t:1527869874825};\\\", \\\"{x:1637,y:974,t:1527869874841};\\\", \\\"{x:1636,y:974,t:1527869874857};\\\", \\\"{x:1635,y:974,t:1527869874875};\\\", \\\"{x:1633,y:973,t:1527869874891};\\\", \\\"{x:1631,y:971,t:1527869874907};\\\", \\\"{x:1630,y:971,t:1527869874925};\\\", \\\"{x:1628,y:970,t:1527869874941};\\\", \\\"{x:1627,y:970,t:1527869874973};\\\", \\\"{x:1626,y:970,t:1527869874989};\\\", \\\"{x:1625,y:970,t:1527869874997};\\\", \\\"{x:1624,y:970,t:1527869875085};\\\", \\\"{x:1622,y:970,t:1527869875109};\\\", \\\"{x:1621,y:970,t:1527869875125};\\\", \\\"{x:1619,y:970,t:1527869875141};\\\", \\\"{x:1618,y:970,t:1527869875159};\\\", \\\"{x:1617,y:970,t:1527869875189};\\\", \\\"{x:1616,y:970,t:1527869875205};\\\", \\\"{x:1614,y:970,t:1527869875301};\\\", \\\"{x:1612,y:971,t:1527869875317};\\\", \\\"{x:1612,y:972,t:1527869875325};\\\", \\\"{x:1608,y:974,t:1527869875341};\\\", \\\"{x:1608,y:975,t:1527869875358};\\\", \\\"{x:1606,y:976,t:1527869875376};\\\", \\\"{x:1605,y:975,t:1527869875661};\\\", \\\"{x:1605,y:973,t:1527869875676};\\\", \\\"{x:1605,y:970,t:1527869875693};\\\", \\\"{x:1606,y:966,t:1527869875709};\\\", \\\"{x:1606,y:963,t:1527869875726};\\\", \\\"{x:1606,y:962,t:1527869875743};\\\", \\\"{x:1608,y:961,t:1527869875933};\\\", \\\"{x:1609,y:961,t:1527869875981};\\\", \\\"{x:1610,y:961,t:1527869876006};\\\", \\\"{x:1612,y:962,t:1527869876014};\\\", \\\"{x:1612,y:963,t:1527869876029};\\\", \\\"{x:1612,y:964,t:1527869876042};\\\", \\\"{x:1612,y:965,t:1527869876060};\\\", \\\"{x:1612,y:967,t:1527869876077};\\\", \\\"{x:1613,y:968,t:1527869876205};\\\", \\\"{x:1613,y:966,t:1527869876429};\\\", \\\"{x:1613,y:964,t:1527869876445};\\\", \\\"{x:1614,y:962,t:1527869876460};\\\", \\\"{x:1614,y:960,t:1527869876533};\\\", \\\"{x:1614,y:959,t:1527869876543};\\\", \\\"{x:1614,y:953,t:1527869876560};\\\", \\\"{x:1614,y:952,t:1527869876576};\\\", \\\"{x:1614,y:948,t:1527869876593};\\\", \\\"{x:1615,y:942,t:1527869876611};\\\", \\\"{x:1616,y:941,t:1527869876627};\\\", \\\"{x:1616,y:938,t:1527869876643};\\\", \\\"{x:1617,y:935,t:1527869876660};\\\", \\\"{x:1617,y:933,t:1527869876677};\\\", \\\"{x:1617,y:932,t:1527869877245};\\\", \\\"{x:1617,y:935,t:1527869877261};\\\", \\\"{x:1617,y:938,t:1527869877278};\\\", \\\"{x:1617,y:941,t:1527869877295};\\\", \\\"{x:1617,y:943,t:1527869877312};\\\", \\\"{x:1617,y:944,t:1527869877328};\\\", \\\"{x:1617,y:945,t:1527869877349};\\\", \\\"{x:1617,y:946,t:1527869877381};\\\", \\\"{x:1617,y:947,t:1527869877395};\\\", \\\"{x:1616,y:949,t:1527869877412};\\\", \\\"{x:1615,y:952,t:1527869877429};\\\", \\\"{x:1615,y:955,t:1527869877445};\\\", \\\"{x:1613,y:960,t:1527869877461};\\\", \\\"{x:1613,y:961,t:1527869877479};\\\", \\\"{x:1613,y:962,t:1527869877495};\\\", \\\"{x:1612,y:963,t:1527869877511};\\\", \\\"{x:1612,y:962,t:1527869879558};\\\", \\\"{x:1612,y:961,t:1527869879565};\\\", \\\"{x:1612,y:960,t:1527869879637};\\\", \\\"{x:1612,y:959,t:1527869879653};\\\", \\\"{x:1612,y:958,t:1527869879669};\\\", \\\"{x:1612,y:956,t:1527869879685};\\\", \\\"{x:1612,y:955,t:1527869879699};\\\", \\\"{x:1612,y:952,t:1527869879715};\\\", \\\"{x:1612,y:948,t:1527869879732};\\\", \\\"{x:1612,y:947,t:1527869879750};\\\", \\\"{x:1612,y:946,t:1527869879764};\\\", \\\"{x:1612,y:945,t:1527869879814};\\\", \\\"{x:1612,y:943,t:1527869879869};\\\", \\\"{x:1611,y:941,t:1527869879882};\\\", \\\"{x:1611,y:936,t:1527869879898};\\\", \\\"{x:1611,y:934,t:1527869879915};\\\", \\\"{x:1611,y:928,t:1527869879931};\\\", \\\"{x:1608,y:922,t:1527869879949};\\\", \\\"{x:1607,y:917,t:1527869879965};\\\", \\\"{x:1607,y:913,t:1527869879981};\\\", \\\"{x:1607,y:910,t:1527869879998};\\\", \\\"{x:1607,y:909,t:1527869880016};\\\", \\\"{x:1607,y:908,t:1527869880031};\\\", \\\"{x:1607,y:907,t:1527869880061};\\\", \\\"{x:1607,y:905,t:1527869880109};\\\", \\\"{x:1607,y:902,t:1527869880117};\\\", \\\"{x:1605,y:899,t:1527869880133};\\\", \\\"{x:1605,y:896,t:1527869880149};\\\", \\\"{x:1604,y:885,t:1527869880166};\\\", \\\"{x:1604,y:880,t:1527869880183};\\\", \\\"{x:1604,y:874,t:1527869880199};\\\", \\\"{x:1604,y:868,t:1527869880216};\\\", \\\"{x:1604,y:864,t:1527869880232};\\\", \\\"{x:1604,y:860,t:1527869880249};\\\", \\\"{x:1604,y:859,t:1527869880265};\\\", \\\"{x:1604,y:858,t:1527869880283};\\\", \\\"{x:1604,y:857,t:1527869880298};\\\", \\\"{x:1604,y:854,t:1527869880349};\\\", \\\"{x:1604,y:852,t:1527869880366};\\\", \\\"{x:1604,y:848,t:1527869880382};\\\", \\\"{x:1604,y:844,t:1527869880400};\\\", \\\"{x:1604,y:839,t:1527869880415};\\\", \\\"{x:1604,y:836,t:1527869880433};\\\", \\\"{x:1605,y:831,t:1527869880450};\\\", \\\"{x:1606,y:827,t:1527869880465};\\\", \\\"{x:1608,y:825,t:1527869880482};\\\", \\\"{x:1608,y:824,t:1527869880499};\\\", \\\"{x:1610,y:824,t:1527869880605};\\\", \\\"{x:1612,y:824,t:1527869880654};\\\", \\\"{x:1614,y:824,t:1527869880678};\\\", \\\"{x:1615,y:824,t:1527869880701};\\\", \\\"{x:1616,y:824,t:1527869880717};\\\", \\\"{x:1616,y:825,t:1527869880758};\\\", \\\"{x:1616,y:826,t:1527869880782};\\\", \\\"{x:1616,y:828,t:1527869880798};\\\", \\\"{x:1616,y:829,t:1527869880813};\\\", \\\"{x:1616,y:830,t:1527869880822};\\\", \\\"{x:1616,y:831,t:1527869880833};\\\", \\\"{x:1616,y:832,t:1527869880850};\\\", \\\"{x:1616,y:834,t:1527869880866};\\\", \\\"{x:1616,y:835,t:1527869880885};\\\", \\\"{x:1616,y:837,t:1527869880910};\\\", \\\"{x:1615,y:837,t:1527869881678};\\\", \\\"{x:1608,y:837,t:1527869883318};\\\", \\\"{x:1595,y:837,t:1527869883324};\\\", \\\"{x:1581,y:835,t:1527869883337};\\\", \\\"{x:1527,y:823,t:1527869883354};\\\", \\\"{x:1436,y:800,t:1527869883370};\\\", \\\"{x:1332,y:775,t:1527869883387};\\\", \\\"{x:1223,y:759,t:1527869883404};\\\", \\\"{x:1114,y:735,t:1527869883421};\\\", \\\"{x:1022,y:722,t:1527869883437};\\\", \\\"{x:866,y:702,t:1527869883454};\\\", \\\"{x:758,y:690,t:1527869883471};\\\", \\\"{x:666,y:690,t:1527869883487};\\\", \\\"{x:593,y:685,t:1527869883503};\\\", \\\"{x:548,y:685,t:1527869883520};\\\", \\\"{x:515,y:683,t:1527869883537};\\\", \\\"{x:493,y:682,t:1527869883554};\\\", \\\"{x:469,y:679,t:1527869883570};\\\", \\\"{x:448,y:675,t:1527869883587};\\\", \\\"{x:429,y:672,t:1527869883604};\\\", \\\"{x:408,y:668,t:1527869883621};\\\", \\\"{x:359,y:662,t:1527869883637};\\\", \\\"{x:341,y:659,t:1527869883646};\\\", \\\"{x:315,y:656,t:1527869883662};\\\", \\\"{x:298,y:653,t:1527869883680};\\\", \\\"{x:291,y:652,t:1527869883696};\\\", \\\"{x:290,y:651,t:1527869883713};\\\", \\\"{x:291,y:649,t:1527869883729};\\\", \\\"{x:297,y:646,t:1527869883747};\\\", \\\"{x:309,y:639,t:1527869883763};\\\", \\\"{x:324,y:631,t:1527869883781};\\\", \\\"{x:344,y:619,t:1527869883796};\\\", \\\"{x:365,y:608,t:1527869883813};\\\", \\\"{x:400,y:592,t:1527869883830};\\\", \\\"{x:434,y:584,t:1527869883847};\\\", \\\"{x:463,y:580,t:1527869883863};\\\", \\\"{x:490,y:576,t:1527869883880};\\\", \\\"{x:515,y:576,t:1527869883897};\\\", \\\"{x:541,y:575,t:1527869883914};\\\", \\\"{x:560,y:575,t:1527869883929};\\\", \\\"{x:577,y:577,t:1527869883947};\\\", \\\"{x:594,y:580,t:1527869883963};\\\", \\\"{x:606,y:583,t:1527869883980};\\\", \\\"{x:620,y:586,t:1527869883997};\\\", \\\"{x:634,y:587,t:1527869884013};\\\", \\\"{x:635,y:587,t:1527869884037};\\\", \\\"{x:638,y:590,t:1527869884047};\\\", \\\"{x:641,y:595,t:1527869884064};\\\", \\\"{x:642,y:602,t:1527869884080};\\\", \\\"{x:644,y:605,t:1527869884096};\\\", \\\"{x:645,y:606,t:1527869884114};\\\", \\\"{x:646,y:608,t:1527869884133};\\\", \\\"{x:645,y:609,t:1527869884173};\\\", \\\"{x:644,y:609,t:1527869884205};\\\", \\\"{x:642,y:609,t:1527869884214};\\\", \\\"{x:638,y:609,t:1527869884231};\\\", \\\"{x:634,y:606,t:1527869884246};\\\", \\\"{x:630,y:602,t:1527869884264};\\\", \\\"{x:625,y:597,t:1527869884280};\\\", \\\"{x:623,y:596,t:1527869884297};\\\", \\\"{x:621,y:594,t:1527869884313};\\\", \\\"{x:618,y:591,t:1527869884331};\\\", \\\"{x:615,y:588,t:1527869884347};\\\", \\\"{x:614,y:588,t:1527869884364};\\\", \\\"{x:614,y:587,t:1527869884381};\\\", \\\"{x:613,y:587,t:1527869884397};\\\", \\\"{x:612,y:587,t:1527869884517};\\\", \\\"{x:612,y:586,t:1527869884533};\\\", \\\"{x:612,y:590,t:1527869889277};\\\", \\\"{x:612,y:611,t:1527869889286};\\\", \\\"{x:610,y:654,t:1527869889301};\\\", \\\"{x:600,y:733,t:1527869889335};\\\", \\\"{x:593,y:754,t:1527869889351};\\\", \\\"{x:584,y:771,t:1527869889368};\\\", \\\"{x:581,y:776,t:1527869889385};\\\", \\\"{x:575,y:781,t:1527869889401};\\\", \\\"{x:572,y:785,t:1527869889418};\\\", \\\"{x:568,y:789,t:1527869889435};\\\", \\\"{x:563,y:792,t:1527869889451};\\\", \\\"{x:558,y:793,t:1527869889468};\\\", \\\"{x:555,y:793,t:1527869889484};\\\", \\\"{x:542,y:789,t:1527869889501};\\\", \\\"{x:535,y:777,t:1527869889518};\\\", \\\"{x:531,y:768,t:1527869889535};\\\", \\\"{x:529,y:757,t:1527869889551};\\\", \\\"{x:528,y:749,t:1527869889568};\\\", \\\"{x:527,y:736,t:1527869889584};\\\", \\\"{x:524,y:725,t:1527869889600};\\\", \\\"{x:523,y:720,t:1527869889618};\\\", \\\"{x:522,y:720,t:1527869889837};\\\", \\\"{x:522,y:721,t:1527869889853};\\\", \\\"{x:522,y:723,t:1527869889869};\\\", \\\"{x:522,y:725,t:1527869889885};\\\", \\\"{x:523,y:727,t:1527869889902};\\\", \\\"{x:523,y:729,t:1527869889919};\\\", \\\"{x:523,y:731,t:1527869889936};\\\", \\\"{x:523,y:734,t:1527869889952};\\\", \\\"{x:523,y:735,t:1527869889989};\\\" ] }, { \\\"rt\\\": 13620, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 15, \\\"time_elapsed\\\": 598120, \\\"internal_node_id\\\": \\\"0.0-6.0-5.0\\\", \\\"subject\\\": \\\"DZD6F\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"victor\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 11, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-09 AM-12 PM-12 PM-B \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:526,y:744,t:1527869892589};\\\", \\\"{x:530,y:757,t:1527869892605};\\\", \\\"{x:538,y:790,t:1527869892620};\\\", \\\"{x:569,y:871,t:1527869892637};\\\", \\\"{x:593,y:919,t:1527869892652};\\\", \\\"{x:606,y:948,t:1527869892670};\\\", \\\"{x:616,y:971,t:1527869892687};\\\", \\\"{x:619,y:983,t:1527869892703};\\\", \\\"{x:620,y:984,t:1527869892720};\\\", \\\"{x:620,y:985,t:1527869892737};\\\", \\\"{x:620,y:984,t:1527869893261};\\\", \\\"{x:618,y:984,t:1527869893285};\\\", \\\"{x:618,y:983,t:1527869893292};\\\", \\\"{x:617,y:983,t:1527869893597};\\\", \\\"{x:618,y:983,t:1527869894533};\\\", \\\"{x:640,y:981,t:1527869894541};\\\", \\\"{x:654,y:981,t:1527869894554};\\\", \\\"{x:697,y:981,t:1527869894571};\\\", \\\"{x:787,y:977,t:1527869894587};\\\", \\\"{x:887,y:977,t:1527869894605};\\\", \\\"{x:1031,y:977,t:1527869894621};\\\", \\\"{x:1103,y:977,t:1527869894637};\\\", \\\"{x:1152,y:979,t:1527869894654};\\\", \\\"{x:1188,y:987,t:1527869894672};\\\", \\\"{x:1210,y:997,t:1527869894688};\\\", \\\"{x:1225,y:1005,t:1527869894704};\\\", \\\"{x:1231,y:1010,t:1527869894721};\\\", \\\"{x:1235,y:1014,t:1527869894737};\\\", \\\"{x:1240,y:1015,t:1527869894754};\\\", \\\"{x:1246,y:1016,t:1527869894771};\\\", \\\"{x:1252,y:1016,t:1527869894788};\\\", \\\"{x:1258,y:1016,t:1527869894804};\\\", \\\"{x:1272,y:1007,t:1527869894821};\\\", \\\"{x:1285,y:999,t:1527869894838};\\\", \\\"{x:1296,y:992,t:1527869894854};\\\", \\\"{x:1310,y:987,t:1527869894871};\\\", \\\"{x:1320,y:981,t:1527869894887};\\\", \\\"{x:1323,y:979,t:1527869894904};\\\", \\\"{x:1326,y:978,t:1527869894921};\\\", \\\"{x:1328,y:976,t:1527869894941};\\\", \\\"{x:1328,y:975,t:1527869894997};\\\", \\\"{x:1328,y:974,t:1527869895005};\\\", \\\"{x:1330,y:971,t:1527869895021};\\\", \\\"{x:1330,y:969,t:1527869895045};\\\", \\\"{x:1330,y:968,t:1527869895061};\\\", \\\"{x:1333,y:968,t:1527869896221};\\\", \\\"{x:1337,y:966,t:1527869896238};\\\", \\\"{x:1340,y:964,t:1527869896255};\\\", \\\"{x:1342,y:962,t:1527869896271};\\\", \\\"{x:1344,y:958,t:1527869896288};\\\", \\\"{x:1345,y:955,t:1527869896305};\\\", \\\"{x:1345,y:953,t:1527869896321};\\\", \\\"{x:1343,y:955,t:1527869896710};\\\", \\\"{x:1342,y:957,t:1527869896721};\\\", \\\"{x:1338,y:963,t:1527869896738};\\\", \\\"{x:1337,y:967,t:1527869896755};\\\", \\\"{x:1337,y:970,t:1527869896773};\\\", \\\"{x:1337,y:972,t:1527869896788};\\\", \\\"{x:1337,y:974,t:1527869896805};\\\", \\\"{x:1337,y:975,t:1527869896822};\\\", \\\"{x:1337,y:976,t:1527869896877};\\\", \\\"{x:1338,y:976,t:1527869897021};\\\", \\\"{x:1339,y:976,t:1527869897028};\\\", \\\"{x:1340,y:976,t:1527869897093};\\\", \\\"{x:1340,y:975,t:1527869897105};\\\", \\\"{x:1340,y:973,t:1527869897122};\\\", \\\"{x:1340,y:971,t:1527869897138};\\\", \\\"{x:1340,y:970,t:1527869897156};\\\", \\\"{x:1340,y:968,t:1527869897198};\\\", \\\"{x:1341,y:968,t:1527869897245};\\\", \\\"{x:1341,y:967,t:1527869898237};\\\", \\\"{x:1341,y:965,t:1527869898253};\\\", \\\"{x:1341,y:964,t:1527869898261};\\\", \\\"{x:1342,y:961,t:1527869898273};\\\", \\\"{x:1342,y:960,t:1527869898293};\\\", \\\"{x:1342,y:959,t:1527869898306};\\\", \\\"{x:1343,y:955,t:1527869898322};\\\", \\\"{x:1343,y:947,t:1527869898339};\\\", \\\"{x:1343,y:932,t:1527869898355};\\\", \\\"{x:1343,y:913,t:1527869898373};\\\", \\\"{x:1343,y:883,t:1527869898389};\\\", \\\"{x:1341,y:871,t:1527869898406};\\\", \\\"{x:1337,y:862,t:1527869898423};\\\", \\\"{x:1336,y:857,t:1527869898440};\\\", \\\"{x:1333,y:850,t:1527869898456};\\\", \\\"{x:1333,y:846,t:1527869898473};\\\", \\\"{x:1333,y:843,t:1527869898489};\\\", \\\"{x:1333,y:840,t:1527869898506};\\\", \\\"{x:1333,y:837,t:1527869898522};\\\", \\\"{x:1333,y:834,t:1527869898540};\\\", \\\"{x:1332,y:832,t:1527869898556};\\\", \\\"{x:1331,y:830,t:1527869898572};\\\", \\\"{x:1330,y:820,t:1527869898589};\\\", \\\"{x:1329,y:816,t:1527869898606};\\\", \\\"{x:1329,y:812,t:1527869898622};\\\", \\\"{x:1328,y:810,t:1527869898639};\\\", \\\"{x:1328,y:809,t:1527869898657};\\\", \\\"{x:1328,y:807,t:1527869899165};\\\", \\\"{x:1329,y:806,t:1527869899173};\\\", \\\"{x:1332,y:803,t:1527869899189};\\\", \\\"{x:1334,y:801,t:1527869899206};\\\", \\\"{x:1336,y:800,t:1527869899224};\\\", \\\"{x:1341,y:797,t:1527869899240};\\\", \\\"{x:1343,y:795,t:1527869899257};\\\", \\\"{x:1344,y:792,t:1527869899273};\\\", \\\"{x:1345,y:790,t:1527869899290};\\\", \\\"{x:1346,y:785,t:1527869899307};\\\", \\\"{x:1348,y:781,t:1527869899323};\\\", \\\"{x:1348,y:776,t:1527869899340};\\\", \\\"{x:1348,y:773,t:1527869899356};\\\", \\\"{x:1348,y:769,t:1527869899373};\\\", \\\"{x:1348,y:768,t:1527869899397};\\\", \\\"{x:1348,y:767,t:1527869899423};\\\", \\\"{x:1345,y:764,t:1527869899439};\\\", \\\"{x:1333,y:758,t:1527869899456};\\\", \\\"{x:1313,y:750,t:1527869899474};\\\", \\\"{x:1278,y:745,t:1527869899490};\\\", \\\"{x:1219,y:735,t:1527869899506};\\\", \\\"{x:1143,y:721,t:1527869899523};\\\", \\\"{x:1044,y:697,t:1527869899540};\\\", \\\"{x:947,y:669,t:1527869899556};\\\", \\\"{x:795,y:627,t:1527869899573};\\\", \\\"{x:704,y:606,t:1527869899590};\\\", \\\"{x:632,y:584,t:1527869899610};\\\", \\\"{x:577,y:571,t:1527869899626};\\\", \\\"{x:529,y:563,t:1527869899643};\\\", \\\"{x:490,y:563,t:1527869899659};\\\", \\\"{x:460,y:563,t:1527869899676};\\\", \\\"{x:433,y:563,t:1527869899692};\\\", \\\"{x:395,y:563,t:1527869899709};\\\", \\\"{x:368,y:563,t:1527869899726};\\\", \\\"{x:340,y:563,t:1527869899742};\\\", \\\"{x:315,y:559,t:1527869899760};\\\", \\\"{x:290,y:552,t:1527869899777};\\\", \\\"{x:266,y:544,t:1527869899793};\\\", \\\"{x:249,y:539,t:1527869899809};\\\", \\\"{x:240,y:535,t:1527869899826};\\\", \\\"{x:234,y:534,t:1527869899842};\\\", \\\"{x:229,y:534,t:1527869899859};\\\", \\\"{x:227,y:534,t:1527869899876};\\\", \\\"{x:224,y:534,t:1527869899893};\\\", \\\"{x:222,y:534,t:1527869899909};\\\", \\\"{x:221,y:534,t:1527869899926};\\\", \\\"{x:219,y:534,t:1527869899957};\\\", \\\"{x:217,y:534,t:1527869899965};\\\", \\\"{x:213,y:534,t:1527869899976};\\\", \\\"{x:204,y:535,t:1527869899993};\\\", \\\"{x:191,y:535,t:1527869900010};\\\", \\\"{x:181,y:535,t:1527869900026};\\\", \\\"{x:168,y:533,t:1527869900042};\\\", \\\"{x:158,y:533,t:1527869900059};\\\", \\\"{x:154,y:533,t:1527869900075};\\\", \\\"{x:152,y:533,t:1527869900092};\\\", \\\"{x:150,y:534,t:1527869900108};\\\", \\\"{x:147,y:536,t:1527869900126};\\\", \\\"{x:144,y:539,t:1527869900142};\\\", \\\"{x:142,y:541,t:1527869900159};\\\", \\\"{x:143,y:541,t:1527869900573};\\\", \\\"{x:144,y:542,t:1527869900580};\\\", \\\"{x:145,y:542,t:1527869900653};\\\", \\\"{x:147,y:542,t:1527869900668};\\\", \\\"{x:148,y:542,t:1527869900676};\\\", \\\"{x:149,y:542,t:1527869900693};\\\", \\\"{x:150,y:541,t:1527869900709};\\\", \\\"{x:151,y:541,t:1527869900726};\\\", \\\"{x:151,y:541,t:1527869900801};\\\", \\\"{x:158,y:541,t:1527869900973};\\\", \\\"{x:170,y:541,t:1527869900981};\\\", \\\"{x:185,y:539,t:1527869900993};\\\", \\\"{x:219,y:533,t:1527869901011};\\\", \\\"{x:270,y:532,t:1527869901027};\\\", \\\"{x:324,y:530,t:1527869901044};\\\", \\\"{x:366,y:530,t:1527869901060};\\\", \\\"{x:423,y:530,t:1527869901077};\\\", \\\"{x:447,y:530,t:1527869901093};\\\", \\\"{x:471,y:530,t:1527869901110};\\\", \\\"{x:497,y:530,t:1527869901128};\\\", \\\"{x:522,y:526,t:1527869901145};\\\", \\\"{x:540,y:524,t:1527869901161};\\\", \\\"{x:563,y:520,t:1527869901178};\\\", \\\"{x:600,y:518,t:1527869901193};\\\", \\\"{x:630,y:515,t:1527869901211};\\\", \\\"{x:664,y:515,t:1527869901226};\\\", \\\"{x:700,y:515,t:1527869901244};\\\", \\\"{x:732,y:515,t:1527869901261};\\\", \\\"{x:793,y:521,t:1527869901277};\\\", \\\"{x:830,y:528,t:1527869901295};\\\", \\\"{x:860,y:534,t:1527869901310};\\\", \\\"{x:883,y:536,t:1527869901328};\\\", \\\"{x:900,y:537,t:1527869901344};\\\", \\\"{x:904,y:537,t:1527869901360};\\\", \\\"{x:905,y:537,t:1527869901377};\\\", \\\"{x:907,y:537,t:1527869901397};\\\", \\\"{x:907,y:536,t:1527869901412};\\\", \\\"{x:907,y:535,t:1527869901427};\\\", \\\"{x:907,y:533,t:1527869901444};\\\", \\\"{x:907,y:529,t:1527869901461};\\\", \\\"{x:907,y:526,t:1527869901476};\\\", \\\"{x:907,y:525,t:1527869901493};\\\", \\\"{x:906,y:524,t:1527869901526};\\\", \\\"{x:906,y:523,t:1527869901544};\\\", \\\"{x:904,y:523,t:1527869901560};\\\", \\\"{x:903,y:523,t:1527869901578};\\\", \\\"{x:899,y:523,t:1527869901594};\\\", \\\"{x:894,y:523,t:1527869901611};\\\", \\\"{x:891,y:521,t:1527869901628};\\\", \\\"{x:880,y:517,t:1527869901645};\\\", \\\"{x:865,y:511,t:1527869901661};\\\", \\\"{x:861,y:509,t:1527869901677};\\\", \\\"{x:858,y:508,t:1527869901694};\\\", \\\"{x:858,y:507,t:1527869901711};\\\", \\\"{x:857,y:506,t:1527869901728};\\\", \\\"{x:855,y:506,t:1527869901797};\\\", \\\"{x:854,y:505,t:1527869901811};\\\", \\\"{x:853,y:505,t:1527869901827};\\\", \\\"{x:852,y:505,t:1527869901908};\\\", \\\"{x:850,y:505,t:1527869901940};\\\", \\\"{x:848,y:503,t:1527869901981};\\\", \\\"{x:847,y:503,t:1527869902029};\\\", \\\"{x:846,y:503,t:1527869902085};\\\", \\\"{x:845,y:503,t:1527869902100};\\\", \\\"{x:844,y:503,t:1527869902111};\\\", \\\"{x:842,y:503,t:1527869902127};\\\", \\\"{x:840,y:502,t:1527869902144};\\\", \\\"{x:837,y:501,t:1527869902161};\\\", \\\"{x:836,y:500,t:1527869902177};\\\", \\\"{x:835,y:499,t:1527869902389};\\\", \\\"{x:834,y:499,t:1527869902404};\\\", \\\"{x:832,y:498,t:1527869902421};\\\", \\\"{x:831,y:498,t:1527869902428};\\\", \\\"{x:829,y:496,t:1527869902445};\\\", \\\"{x:828,y:496,t:1527869903188};\\\", \\\"{x:826,y:497,t:1527869903196};\\\", \\\"{x:826,y:500,t:1527869903212};\\\", \\\"{x:821,y:506,t:1527869903228};\\\", \\\"{x:818,y:512,t:1527869903245};\\\", \\\"{x:817,y:514,t:1527869903262};\\\", \\\"{x:817,y:516,t:1527869903278};\\\", \\\"{x:813,y:519,t:1527869903296};\\\", \\\"{x:810,y:523,t:1527869903313};\\\", \\\"{x:809,y:529,t:1527869903329};\\\", \\\"{x:803,y:536,t:1527869903345};\\\", \\\"{x:796,y:546,t:1527869903362};\\\", \\\"{x:791,y:557,t:1527869903379};\\\", \\\"{x:783,y:567,t:1527869903396};\\\", \\\"{x:773,y:581,t:1527869903412};\\\", \\\"{x:761,y:595,t:1527869903429};\\\", \\\"{x:758,y:600,t:1527869903446};\\\", \\\"{x:757,y:601,t:1527869903463};\\\", \\\"{x:756,y:602,t:1527869903525};\\\", \\\"{x:755,y:603,t:1527869903533};\\\", \\\"{x:754,y:603,t:1527869903545};\\\", \\\"{x:748,y:610,t:1527869903562};\\\", \\\"{x:740,y:619,t:1527869903579};\\\", \\\"{x:725,y:632,t:1527869903596};\\\", \\\"{x:712,y:642,t:1527869903612};\\\", \\\"{x:688,y:661,t:1527869903629};\\\", \\\"{x:677,y:669,t:1527869903645};\\\", \\\"{x:669,y:677,t:1527869903663};\\\", \\\"{x:663,y:681,t:1527869903680};\\\", \\\"{x:659,y:682,t:1527869903696};\\\", \\\"{x:658,y:682,t:1527869903713};\\\", \\\"{x:657,y:683,t:1527869903732};\\\", \\\"{x:655,y:684,t:1527869903756};\\\", \\\"{x:654,y:685,t:1527869903764};\\\", \\\"{x:653,y:686,t:1527869903781};\\\", \\\"{x:653,y:687,t:1527869903797};\\\", \\\"{x:652,y:687,t:1527869903813};\\\", \\\"{x:651,y:689,t:1527869903829};\\\", \\\"{x:650,y:691,t:1527869903845};\\\", \\\"{x:650,y:692,t:1527869903863};\\\", \\\"{x:649,y:692,t:1527869904053};\\\", \\\"{x:649,y:694,t:1527869904063};\\\", \\\"{x:648,y:695,t:1527869904080};\\\", \\\"{x:648,y:696,t:1527869904101};\\\", \\\"{x:647,y:696,t:1527869904276};\\\", \\\"{x:644,y:696,t:1527869904285};\\\", \\\"{x:643,y:699,t:1527869904296};\\\", \\\"{x:637,y:702,t:1527869904312};\\\", \\\"{x:632,y:703,t:1527869904329};\\\", \\\"{x:625,y:706,t:1527869904346};\\\", \\\"{x:616,y:710,t:1527869904362};\\\", \\\"{x:606,y:711,t:1527869904380};\\\", \\\"{x:592,y:712,t:1527869904396};\\\", \\\"{x:568,y:713,t:1527869904413};\\\", \\\"{x:548,y:717,t:1527869904430};\\\", \\\"{x:533,y:718,t:1527869904447};\\\", \\\"{x:521,y:721,t:1527869904464};\\\", \\\"{x:518,y:722,t:1527869904480};\\\", \\\"{x:518,y:723,t:1527869904496};\\\", \\\"{x:518,y:724,t:1527869904514};\\\", \\\"{x:518,y:725,t:1527869904533};\\\", \\\"{x:518,y:726,t:1527869904547};\\\", \\\"{x:518,y:727,t:1527869904563};\\\", \\\"{x:517,y:729,t:1527869904580};\\\", \\\"{x:514,y:731,t:1527869904596};\\\", \\\"{x:513,y:732,t:1527869904629};\\\", \\\"{x:513,y:733,t:1527869904653};\\\", \\\"{x:513,y:734,t:1527869904669};\\\", \\\"{x:513,y:735,t:1527869904680};\\\", \\\"{x:513,y:736,t:1527869904697};\\\", \\\"{x:513,y:737,t:1527869904713};\\\", \\\"{x:513,y:738,t:1527869904729};\\\", \\\"{x:513,y:740,t:1527869904748};\\\" ] }, { \\\"rt\\\": 12302, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 16, \\\"time_elapsed\\\": 611637, \\\"internal_node_id\\\": \\\"0.0-6.0-6.0\\\", \\\"subject\\\": \\\"DZD6F\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"victor\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 12, \\\"clicks\\\": 1.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:514,y:739,t:1527869912760};\\\", \\\"{x:514,y:738,t:1527869912770};\\\", \\\"{x:514,y:734,t:1527869912786};\\\", \\\"{x:514,y:733,t:1527869912803};\\\", \\\"{x:514,y:731,t:1527869912820};\\\", \\\"{x:513,y:730,t:1527869912835};\\\", \\\"{x:503,y:726,t:1527869912853};\\\", \\\"{x:495,y:724,t:1527869912869};\\\", \\\"{x:480,y:719,t:1527869912886};\\\", \\\"{x:457,y:708,t:1527869912902};\\\", \\\"{x:431,y:697,t:1527869912920};\\\", \\\"{x:384,y:677,t:1527869912939};\\\", \\\"{x:347,y:659,t:1527869912956};\\\", \\\"{x:313,y:643,t:1527869912971};\\\", \\\"{x:289,y:631,t:1527869912991};\\\", \\\"{x:271,y:624,t:1527869913007};\\\", \\\"{x:260,y:618,t:1527869913024};\\\", \\\"{x:244,y:607,t:1527869913041};\\\", \\\"{x:233,y:601,t:1527869913058};\\\", \\\"{x:231,y:600,t:1527869913074};\\\", \\\"{x:230,y:599,t:1527869913091};\\\", \\\"{x:229,y:598,t:1527869913108};\\\", \\\"{x:228,y:594,t:1527869913124};\\\", \\\"{x:226,y:592,t:1527869913142};\\\", \\\"{x:224,y:590,t:1527869913158};\\\", \\\"{x:222,y:587,t:1527869913174};\\\", \\\"{x:218,y:581,t:1527869913190};\\\", \\\"{x:213,y:574,t:1527869913207};\\\", \\\"{x:211,y:571,t:1527869913224};\\\", \\\"{x:210,y:568,t:1527869913240};\\\", \\\"{x:209,y:568,t:1527869913264};\\\", \\\"{x:208,y:568,t:1527869913274};\\\", \\\"{x:205,y:567,t:1527869913290};\\\", \\\"{x:201,y:566,t:1527869913308};\\\", \\\"{x:197,y:563,t:1527869913324};\\\", \\\"{x:192,y:562,t:1527869913340};\\\", \\\"{x:189,y:560,t:1527869913357};\\\", \\\"{x:187,y:560,t:1527869913373};\\\", \\\"{x:183,y:558,t:1527869913390};\\\", \\\"{x:180,y:557,t:1527869913407};\\\", \\\"{x:179,y:556,t:1527869913423};\\\", \\\"{x:176,y:554,t:1527869913441};\\\", \\\"{x:175,y:554,t:1527869913624};\\\", \\\"{x:174,y:553,t:1527869913640};\\\", \\\"{x:172,y:552,t:1527869913657};\\\", \\\"{x:169,y:550,t:1527869913675};\\\", \\\"{x:167,y:549,t:1527869913691};\\\", \\\"{x:163,y:546,t:1527869913708};\\\", \\\"{x:161,y:545,t:1527869913725};\\\", \\\"{x:159,y:544,t:1527869913740};\\\", \\\"{x:158,y:544,t:1527869913801};\\\", \\\"{x:156,y:544,t:1527869913824};\\\", \\\"{x:156,y:543,t:1527869913841};\\\", \\\"{x:154,y:543,t:1527869913857};\\\", \\\"{x:153,y:543,t:1527869913875};\\\", \\\"{x:151,y:542,t:1527869913891};\\\", \\\"{x:150,y:542,t:1527869913907};\\\", \\\"{x:150,y:541,t:1527869913924};\\\", \\\"{x:149,y:541,t:1527869914065};\\\", \\\"{x:147,y:540,t:1527869914089};\\\", \\\"{x:146,y:540,t:1527869914104};\\\", \\\"{x:145,y:540,t:1527869914152};\\\", \\\"{x:144,y:540,t:1527869914184};\\\", \\\"{x:143,y:539,t:1527869914193};\\\", \\\"{x:145,y:540,t:1527869914721};\\\", \\\"{x:151,y:544,t:1527869914729};\\\", \\\"{x:156,y:547,t:1527869914742};\\\", \\\"{x:175,y:560,t:1527869914759};\\\", \\\"{x:194,y:576,t:1527869914775};\\\", \\\"{x:219,y:589,t:1527869914792};\\\", \\\"{x:253,y:609,t:1527869914809};\\\", \\\"{x:266,y:618,t:1527869914825};\\\", \\\"{x:280,y:627,t:1527869914842};\\\", \\\"{x:289,y:632,t:1527869914859};\\\", \\\"{x:294,y:635,t:1527869914875};\\\", \\\"{x:295,y:635,t:1527869914896};\\\", \\\"{x:298,y:635,t:1527869914908};\\\", \\\"{x:306,y:641,t:1527869914926};\\\", \\\"{x:322,y:647,t:1527869914941};\\\", \\\"{x:342,y:658,t:1527869914958};\\\", \\\"{x:371,y:675,t:1527869914975};\\\", \\\"{x:404,y:694,t:1527869914992};\\\", \\\"{x:440,y:716,t:1527869915008};\\\", \\\"{x:469,y:731,t:1527869915026};\\\", \\\"{x:491,y:742,t:1527869915042};\\\", \\\"{x:507,y:749,t:1527869915059};\\\", \\\"{x:517,y:754,t:1527869915076};\\\", \\\"{x:518,y:754,t:1527869915092};\\\", \\\"{x:516,y:753,t:1527869915193};\\\", \\\"{x:489,y:740,t:1527869915208};\\\", \\\"{x:458,y:726,t:1527869915226};\\\", \\\"{x:429,y:715,t:1527869915243};\\\", \\\"{x:387,y:695,t:1527869915259};\\\", \\\"{x:347,y:675,t:1527869915276};\\\", \\\"{x:326,y:660,t:1527869915293};\\\", \\\"{x:316,y:651,t:1527869915308};\\\", \\\"{x:311,y:644,t:1527869915325};\\\", \\\"{x:308,y:635,t:1527869915343};\\\", \\\"{x:305,y:630,t:1527869915359};\\\", \\\"{x:302,y:625,t:1527869915376};\\\", \\\"{x:298,y:619,t:1527869915393};\\\", \\\"{x:298,y:615,t:1527869915409};\\\", \\\"{x:294,y:610,t:1527869915426};\\\", \\\"{x:287,y:606,t:1527869915443};\\\", \\\"{x:270,y:600,t:1527869915459};\\\", \\\"{x:247,y:594,t:1527869915475};\\\", \\\"{x:224,y:585,t:1527869915492};\\\", \\\"{x:197,y:579,t:1527869915509};\\\", \\\"{x:179,y:571,t:1527869915526};\\\", \\\"{x:157,y:562,t:1527869915543};\\\", \\\"{x:141,y:550,t:1527869915560};\\\", \\\"{x:131,y:544,t:1527869915575};\\\", \\\"{x:128,y:540,t:1527869915593};\\\", \\\"{x:128,y:539,t:1527869915609};\\\", \\\"{x:128,y:538,t:1527869915626};\\\", \\\"{x:128,y:537,t:1527869915664};\\\", \\\"{x:129,y:537,t:1527869915696};\\\", \\\"{x:131,y:537,t:1527869915708};\\\", \\\"{x:136,y:537,t:1527869915726};\\\", \\\"{x:144,y:540,t:1527869915743};\\\", \\\"{x:152,y:544,t:1527869915760};\\\", \\\"{x:155,y:544,t:1527869915776};\\\", \\\"{x:156,y:544,t:1527869915840};\\\", \\\"{x:157,y:544,t:1527869915856};\\\", \\\"{x:159,y:544,t:1527869915873};\\\", \\\"{x:160,y:543,t:1527869915896};\\\", \\\"{x:162,y:543,t:1527869916401};\\\", \\\"{x:172,y:543,t:1527869916409};\\\", \\\"{x:212,y:555,t:1527869916427};\\\", \\\"{x:248,y:568,t:1527869916443};\\\", \\\"{x:295,y:583,t:1527869916460};\\\", \\\"{x:355,y:605,t:1527869916477};\\\", \\\"{x:398,y:628,t:1527869916493};\\\", \\\"{x:429,y:648,t:1527869916510};\\\", \\\"{x:453,y:663,t:1527869916527};\\\", \\\"{x:472,y:675,t:1527869916543};\\\", \\\"{x:491,y:685,t:1527869916560};\\\", \\\"{x:508,y:694,t:1527869916576};\\\", \\\"{x:511,y:695,t:1527869916592};\\\", \\\"{x:513,y:696,t:1527869916648};\\\", \\\"{x:515,y:699,t:1527869916659};\\\", \\\"{x:521,y:706,t:1527869916676};\\\", \\\"{x:529,y:714,t:1527869916693};\\\", \\\"{x:534,y:723,t:1527869916709};\\\", \\\"{x:538,y:728,t:1527869916726};\\\", \\\"{x:538,y:733,t:1527869916743};\\\", \\\"{x:539,y:738,t:1527869916760};\\\", \\\"{x:541,y:742,t:1527869916776};\\\", \\\"{x:541,y:743,t:1527869917009};\\\", \\\"{x:541,y:744,t:1527869917048};\\\", \\\"{x:541,y:745,t:1527869917152};\\\", \\\"{x:541,y:746,t:1527869917168};\\\", \\\"{x:541,y:748,t:1527869917184};\\\", \\\"{x:541,y:750,t:1527869917200};\\\", \\\"{x:541,y:751,t:1527869917216};\\\", \\\"{x:541,y:752,t:1527869917228};\\\", \\\"{x:541,y:754,t:1527869917244};\\\", \\\"{x:541,y:755,t:1527869917272};\\\", \\\"{x:541,y:756,t:1527869917440};\\\", \\\"{x:541,y:758,t:1527869917448};\\\", \\\"{x:541,y:759,t:1527869917464};\\\", \\\"{x:540,y:761,t:1527869917477};\\\", \\\"{x:540,y:762,t:1527869917494};\\\", \\\"{x:539,y:763,t:1527869918080};\\\", \\\"{x:538,y:762,t:1527869918121};\\\", \\\"{x:538,y:761,t:1527869918160};\\\", \\\"{x:537,y:761,t:1527869918177};\\\", \\\"{x:537,y:760,t:1527869918195};\\\", \\\"{x:537,y:759,t:1527869918210};\\\", \\\"{x:536,y:758,t:1527869918228};\\\", \\\"{x:535,y:757,t:1527869918256};\\\", \\\"{x:535,y:755,t:1527869918272};\\\", \\\"{x:534,y:753,t:1527869918280};\\\", \\\"{x:534,y:751,t:1527869918295};\\\", \\\"{x:534,y:746,t:1527869918311};\\\", \\\"{x:534,y:740,t:1527869918328};\\\", \\\"{x:534,y:733,t:1527869918344};\\\", \\\"{x:534,y:730,t:1527869918361};\\\", \\\"{x:534,y:729,t:1527869918384};\\\" ] }, { \\\"rt\\\": 30622, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 17, \\\"time_elapsed\\\": 643475, \\\"internal_node_id\\\": \\\"0.0-6.0-7.0\\\", \\\"subject\\\": \\\"DZD6F\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"victor\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 13, \\\"clicks\\\": 3, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-02 PM-X -F \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:534,y:730,t:1527869921560};\\\", \\\"{x:534,y:731,t:1527869922937};\\\", \\\"{x:534,y:732,t:1527869923129};\\\", \\\"{x:533,y:736,t:1527869929093};\\\", \\\"{x:532,y:737,t:1527869929105};\\\", \\\"{x:530,y:739,t:1527869929280};\\\", \\\"{x:529,y:740,t:1527869929288};\\\", \\\"{x:528,y:740,t:1527869929305};\\\", \\\"{x:528,y:742,t:1527869929322};\\\", \\\"{x:527,y:743,t:1527869929512};\\\", \\\"{x:526,y:744,t:1527869929728};\\\", \\\"{x:525,y:744,t:1527869929768};\\\", \\\"{x:525,y:745,t:1527869929936};\\\", \\\"{x:526,y:750,t:1527869932184};\\\", \\\"{x:534,y:754,t:1527869932192};\\\", \\\"{x:545,y:763,t:1527869932208};\\\", \\\"{x:558,y:774,t:1527869932224};\\\", \\\"{x:572,y:785,t:1527869932241};\\\", \\\"{x:582,y:792,t:1527869932265};\\\", \\\"{x:582,y:793,t:1527869932368};\\\", \\\"{x:583,y:794,t:1527869932382};\\\", \\\"{x:586,y:798,t:1527869932400};\\\", \\\"{x:592,y:813,t:1527869932415};\\\", \\\"{x:594,y:823,t:1527869932433};\\\", \\\"{x:594,y:836,t:1527869932449};\\\", \\\"{x:594,y:846,t:1527869932466};\\\", \\\"{x:594,y:853,t:1527869932482};\\\", \\\"{x:594,y:856,t:1527869932499};\\\", \\\"{x:594,y:857,t:1527869932516};\\\", \\\"{x:595,y:858,t:1527869932584};\\\", \\\"{x:602,y:860,t:1527869932599};\\\", \\\"{x:629,y:867,t:1527869932616};\\\", \\\"{x:670,y:871,t:1527869932634};\\\", \\\"{x:728,y:871,t:1527869932649};\\\", \\\"{x:806,y:871,t:1527869932666};\\\", \\\"{x:886,y:871,t:1527869932684};\\\", \\\"{x:970,y:871,t:1527869932700};\\\", \\\"{x:1045,y:871,t:1527869932716};\\\", \\\"{x:1120,y:871,t:1527869932733};\\\", \\\"{x:1187,y:871,t:1527869932751};\\\", \\\"{x:1232,y:871,t:1527869932766};\\\", \\\"{x:1262,y:871,t:1527869932784};\\\", \\\"{x:1295,y:871,t:1527869932800};\\\", \\\"{x:1314,y:871,t:1527869932816};\\\", \\\"{x:1329,y:871,t:1527869932834};\\\", \\\"{x:1343,y:871,t:1527869932851};\\\", \\\"{x:1360,y:871,t:1527869932867};\\\", \\\"{x:1382,y:871,t:1527869932883};\\\", \\\"{x:1401,y:871,t:1527869932900};\\\", \\\"{x:1420,y:871,t:1527869932916};\\\", \\\"{x:1430,y:871,t:1527869932933};\\\", \\\"{x:1435,y:872,t:1527869932951};\\\", \\\"{x:1440,y:873,t:1527869932966};\\\", \\\"{x:1446,y:877,t:1527869932983};\\\", \\\"{x:1478,y:886,t:1527869933000};\\\", \\\"{x:1499,y:891,t:1527869933017};\\\", \\\"{x:1508,y:891,t:1527869933034};\\\", \\\"{x:1508,y:890,t:1527869933424};\\\", \\\"{x:1508,y:888,t:1527869933434};\\\", \\\"{x:1508,y:885,t:1527869933452};\\\", \\\"{x:1508,y:884,t:1527869933468};\\\", \\\"{x:1507,y:882,t:1527869933485};\\\", \\\"{x:1504,y:879,t:1527869933501};\\\", \\\"{x:1501,y:875,t:1527869933518};\\\", \\\"{x:1500,y:874,t:1527869933536};\\\", \\\"{x:1499,y:872,t:1527869933552};\\\", \\\"{x:1498,y:871,t:1527869933568};\\\", \\\"{x:1494,y:865,t:1527869933584};\\\", \\\"{x:1491,y:858,t:1527869933602};\\\", \\\"{x:1486,y:852,t:1527869933618};\\\", \\\"{x:1481,y:844,t:1527869933635};\\\", \\\"{x:1479,y:841,t:1527869933651};\\\", \\\"{x:1477,y:837,t:1527869933669};\\\", \\\"{x:1476,y:835,t:1527869933685};\\\", \\\"{x:1474,y:830,t:1527869933702};\\\", \\\"{x:1474,y:829,t:1527869933718};\\\", \\\"{x:1475,y:836,t:1527869933800};\\\", \\\"{x:1475,y:848,t:1527869933807};\\\", \\\"{x:1475,y:865,t:1527869933818};\\\", \\\"{x:1475,y:892,t:1527869933835};\\\", \\\"{x:1475,y:915,t:1527869933851};\\\", \\\"{x:1476,y:944,t:1527869933869};\\\", \\\"{x:1478,y:966,t:1527869933885};\\\", \\\"{x:1478,y:969,t:1527869933902};\\\", \\\"{x:1478,y:971,t:1527869933918};\\\", \\\"{x:1478,y:972,t:1527869933935};\\\", \\\"{x:1478,y:968,t:1527869934000};\\\", \\\"{x:1476,y:959,t:1527869934007};\\\", \\\"{x:1474,y:947,t:1527869934018};\\\", \\\"{x:1472,y:920,t:1527869934035};\\\", \\\"{x:1467,y:894,t:1527869934051};\\\", \\\"{x:1466,y:873,t:1527869934068};\\\", \\\"{x:1466,y:850,t:1527869934085};\\\", \\\"{x:1466,y:831,t:1527869934102};\\\", \\\"{x:1466,y:823,t:1527869934118};\\\", \\\"{x:1469,y:816,t:1527869934135};\\\", \\\"{x:1469,y:814,t:1527869934152};\\\", \\\"{x:1470,y:814,t:1527869934240};\\\", \\\"{x:1472,y:814,t:1527869934253};\\\", \\\"{x:1483,y:814,t:1527869934268};\\\", \\\"{x:1506,y:816,t:1527869934286};\\\", \\\"{x:1539,y:821,t:1527869934302};\\\", \\\"{x:1573,y:821,t:1527869934319};\\\", \\\"{x:1597,y:821,t:1527869934335};\\\", \\\"{x:1615,y:821,t:1527869934352};\\\", \\\"{x:1618,y:821,t:1527869934480};\\\", \\\"{x:1619,y:821,t:1527869934504};\\\", \\\"{x:1620,y:822,t:1527869934520};\\\", \\\"{x:1621,y:822,t:1527869934544};\\\", \\\"{x:1622,y:824,t:1527869934568};\\\", \\\"{x:1622,y:827,t:1527869934576};\\\", \\\"{x:1623,y:831,t:1527869934587};\\\", \\\"{x:1624,y:839,t:1527869934602};\\\", \\\"{x:1627,y:849,t:1527869934619};\\\", \\\"{x:1630,y:858,t:1527869934636};\\\", \\\"{x:1631,y:867,t:1527869934652};\\\", \\\"{x:1633,y:874,t:1527869934669};\\\", \\\"{x:1633,y:888,t:1527869934686};\\\", \\\"{x:1633,y:906,t:1527869934704};\\\", \\\"{x:1633,y:922,t:1527869934719};\\\", \\\"{x:1633,y:938,t:1527869934737};\\\", \\\"{x:1633,y:947,t:1527869934753};\\\", \\\"{x:1633,y:955,t:1527869934769};\\\", \\\"{x:1633,y:961,t:1527869934786};\\\", \\\"{x:1633,y:965,t:1527869934803};\\\", \\\"{x:1633,y:966,t:1527869934819};\\\", \\\"{x:1633,y:965,t:1527869934904};\\\", \\\"{x:1633,y:960,t:1527869934920};\\\", \\\"{x:1630,y:936,t:1527869934936};\\\", \\\"{x:1628,y:920,t:1527869934953};\\\", \\\"{x:1624,y:900,t:1527869934970};\\\", \\\"{x:1623,y:883,t:1527869934986};\\\", \\\"{x:1619,y:870,t:1527869935003};\\\", \\\"{x:1619,y:863,t:1527869935020};\\\", \\\"{x:1619,y:860,t:1527869935037};\\\", \\\"{x:1619,y:856,t:1527869935053};\\\", \\\"{x:1617,y:856,t:1527869935336};\\\", \\\"{x:1616,y:856,t:1527869935344};\\\", \\\"{x:1612,y:856,t:1527869935354};\\\", \\\"{x:1598,y:856,t:1527869935370};\\\", \\\"{x:1584,y:858,t:1527869935387};\\\", \\\"{x:1561,y:858,t:1527869935405};\\\", \\\"{x:1541,y:858,t:1527869935421};\\\", \\\"{x:1519,y:858,t:1527869935438};\\\", \\\"{x:1496,y:858,t:1527869935454};\\\", \\\"{x:1477,y:858,t:1527869935471};\\\", \\\"{x:1454,y:858,t:1527869935487};\\\", \\\"{x:1416,y:858,t:1527869935504};\\\", \\\"{x:1382,y:858,t:1527869935520};\\\", \\\"{x:1342,y:857,t:1527869935537};\\\", \\\"{x:1285,y:846,t:1527869935554};\\\", \\\"{x:1204,y:831,t:1527869935571};\\\", \\\"{x:1126,y:818,t:1527869935588};\\\", \\\"{x:1057,y:803,t:1527869935604};\\\", \\\"{x:1001,y:786,t:1527869935622};\\\", \\\"{x:972,y:779,t:1527869935638};\\\", \\\"{x:957,y:771,t:1527869935654};\\\", \\\"{x:948,y:767,t:1527869935671};\\\", \\\"{x:946,y:763,t:1527869935687};\\\", \\\"{x:944,y:753,t:1527869935705};\\\", \\\"{x:942,y:738,t:1527869935721};\\\", \\\"{x:940,y:724,t:1527869935737};\\\", \\\"{x:935,y:701,t:1527869935754};\\\", \\\"{x:924,y:679,t:1527869935771};\\\", \\\"{x:914,y:657,t:1527869935788};\\\", \\\"{x:911,y:643,t:1527869935804};\\\", \\\"{x:904,y:627,t:1527869935821};\\\", \\\"{x:902,y:613,t:1527869935838};\\\", \\\"{x:889,y:588,t:1527869935859};\\\", \\\"{x:881,y:579,t:1527869935875};\\\", \\\"{x:876,y:569,t:1527869935892};\\\", \\\"{x:871,y:560,t:1527869935909};\\\", \\\"{x:866,y:557,t:1527869935926};\\\", \\\"{x:858,y:552,t:1527869935943};\\\", \\\"{x:848,y:550,t:1527869935958};\\\", \\\"{x:841,y:548,t:1527869935976};\\\", \\\"{x:820,y:539,t:1527869935992};\\\", \\\"{x:801,y:534,t:1527869936009};\\\", \\\"{x:784,y:531,t:1527869936025};\\\", \\\"{x:779,y:531,t:1527869936042};\\\", \\\"{x:778,y:531,t:1527869936059};\\\", \\\"{x:778,y:530,t:1527869936075};\\\", \\\"{x:777,y:530,t:1527869936093};\\\", \\\"{x:768,y:532,t:1527869936109};\\\", \\\"{x:754,y:538,t:1527869936125};\\\", \\\"{x:738,y:547,t:1527869936142};\\\", \\\"{x:723,y:553,t:1527869936160};\\\", \\\"{x:716,y:557,t:1527869936176};\\\", \\\"{x:710,y:561,t:1527869936193};\\\", \\\"{x:707,y:562,t:1527869936209};\\\", \\\"{x:705,y:563,t:1527869936226};\\\", \\\"{x:702,y:564,t:1527869936243};\\\", \\\"{x:696,y:565,t:1527869936260};\\\", \\\"{x:690,y:568,t:1527869936275};\\\", \\\"{x:685,y:569,t:1527869936293};\\\", \\\"{x:681,y:569,t:1527869936309};\\\", \\\"{x:670,y:570,t:1527869936325};\\\", \\\"{x:659,y:573,t:1527869936343};\\\", \\\"{x:653,y:575,t:1527869936359};\\\", \\\"{x:648,y:575,t:1527869936376};\\\", \\\"{x:643,y:575,t:1527869936392};\\\", \\\"{x:639,y:575,t:1527869936410};\\\", \\\"{x:636,y:575,t:1527869936425};\\\", \\\"{x:633,y:575,t:1527869936442};\\\", \\\"{x:630,y:576,t:1527869936459};\\\", \\\"{x:629,y:576,t:1527869936475};\\\", \\\"{x:628,y:576,t:1527869936492};\\\", \\\"{x:625,y:576,t:1527869936560};\\\", \\\"{x:624,y:576,t:1527869936583};\\\", \\\"{x:622,y:577,t:1527869936592};\\\", \\\"{x:621,y:577,t:1527869936615};\\\", \\\"{x:620,y:577,t:1527869936640};\\\", \\\"{x:619,y:577,t:1527869936656};\\\", \\\"{x:618,y:577,t:1527869936672};\\\", \\\"{x:617,y:577,t:1527869936712};\\\", \\\"{x:616,y:578,t:1527869936726};\\\", \\\"{x:615,y:578,t:1527869936743};\\\", \\\"{x:612,y:579,t:1527869936760};\\\", \\\"{x:610,y:579,t:1527869936808};\\\", \\\"{x:619,y:579,t:1527869938464};\\\", \\\"{x:636,y:579,t:1527869938477};\\\", \\\"{x:697,y:579,t:1527869938494};\\\", \\\"{x:777,y:579,t:1527869938511};\\\", \\\"{x:864,y:579,t:1527869938528};\\\", \\\"{x:983,y:579,t:1527869938544};\\\", \\\"{x:1039,y:581,t:1527869938561};\\\", \\\"{x:1094,y:584,t:1527869938577};\\\", \\\"{x:1144,y:590,t:1527869938594};\\\", \\\"{x:1175,y:595,t:1527869938610};\\\", \\\"{x:1204,y:597,t:1527869938627};\\\", \\\"{x:1234,y:602,t:1527869938644};\\\", \\\"{x:1274,y:609,t:1527869938661};\\\", \\\"{x:1304,y:614,t:1527869938677};\\\", \\\"{x:1327,y:616,t:1527869938693};\\\", \\\"{x:1349,y:620,t:1527869938710};\\\", \\\"{x:1370,y:625,t:1527869938728};\\\", \\\"{x:1393,y:631,t:1527869938744};\\\", \\\"{x:1413,y:637,t:1527869938760};\\\", \\\"{x:1421,y:641,t:1527869938777};\\\", \\\"{x:1425,y:643,t:1527869938793};\\\", \\\"{x:1426,y:644,t:1527869938816};\\\", \\\"{x:1427,y:644,t:1527869938832};\\\", \\\"{x:1428,y:645,t:1527869938844};\\\", \\\"{x:1429,y:646,t:1527869938860};\\\", \\\"{x:1430,y:646,t:1527869938877};\\\", \\\"{x:1431,y:646,t:1527869938992};\\\", \\\"{x:1432,y:646,t:1527869938999};\\\", \\\"{x:1434,y:646,t:1527869939032};\\\", \\\"{x:1437,y:646,t:1527869939043};\\\", \\\"{x:1440,y:646,t:1527869939059};\\\", \\\"{x:1443,y:645,t:1527869939077};\\\", \\\"{x:1445,y:644,t:1527869939093};\\\", \\\"{x:1445,y:643,t:1527869939110};\\\", \\\"{x:1446,y:643,t:1527869939135};\\\", \\\"{x:1446,y:641,t:1527869939160};\\\", \\\"{x:1446,y:640,t:1527869939176};\\\", \\\"{x:1446,y:638,t:1527869939199};\\\", \\\"{x:1446,y:637,t:1527869940272};\\\", \\\"{x:1445,y:638,t:1527869940552};\\\", \\\"{x:1439,y:643,t:1527869940560};\\\", \\\"{x:1433,y:648,t:1527869940574};\\\", \\\"{x:1414,y:658,t:1527869940591};\\\", \\\"{x:1396,y:665,t:1527869940608};\\\", \\\"{x:1390,y:668,t:1527869940624};\\\", \\\"{x:1386,y:672,t:1527869940640};\\\", \\\"{x:1381,y:675,t:1527869940657};\\\", \\\"{x:1377,y:677,t:1527869940673};\\\", \\\"{x:1374,y:679,t:1527869940691};\\\", \\\"{x:1370,y:681,t:1527869940706};\\\", \\\"{x:1365,y:684,t:1527869940724};\\\", \\\"{x:1361,y:687,t:1527869940740};\\\", \\\"{x:1360,y:687,t:1527869940757};\\\", \\\"{x:1359,y:688,t:1527869940848};\\\", \\\"{x:1358,y:690,t:1527869940880};\\\", \\\"{x:1356,y:691,t:1527869940896};\\\", \\\"{x:1355,y:692,t:1527869940907};\\\", \\\"{x:1351,y:694,t:1527869940924};\\\", \\\"{x:1349,y:695,t:1527869940940};\\\", \\\"{x:1347,y:697,t:1527869940956};\\\", \\\"{x:1346,y:699,t:1527869940974};\\\", \\\"{x:1347,y:698,t:1527869943264};\\\", \\\"{x:1349,y:697,t:1527869943272};\\\", \\\"{x:1352,y:696,t:1527869943286};\\\", \\\"{x:1361,y:695,t:1527869943303};\\\", \\\"{x:1379,y:693,t:1527869943318};\\\", \\\"{x:1400,y:693,t:1527869943336};\\\", \\\"{x:1406,y:693,t:1527869943352};\\\", \\\"{x:1412,y:693,t:1527869943368};\\\", \\\"{x:1417,y:694,t:1527869943386};\\\", \\\"{x:1422,y:698,t:1527869943403};\\\", \\\"{x:1426,y:698,t:1527869943419};\\\", \\\"{x:1425,y:698,t:1527869943720};\\\", \\\"{x:1423,y:698,t:1527869943735};\\\", \\\"{x:1420,y:697,t:1527869943752};\\\", \\\"{x:1419,y:697,t:1527869943769};\\\", \\\"{x:1419,y:696,t:1527869943785};\\\", \\\"{x:1417,y:696,t:1527869943801};\\\", \\\"{x:1416,y:695,t:1527869943819};\\\", \\\"{x:1414,y:695,t:1527869943960};\\\", \\\"{x:1413,y:693,t:1527869943975};\\\", \\\"{x:1412,y:693,t:1527869944008};\\\", \\\"{x:1413,y:693,t:1527869944191};\\\", \\\"{x:1415,y:693,t:1527869944201};\\\", \\\"{x:1419,y:692,t:1527869944218};\\\", \\\"{x:1424,y:690,t:1527869944235};\\\", \\\"{x:1428,y:688,t:1527869944250};\\\", \\\"{x:1434,y:687,t:1527869944268};\\\", \\\"{x:1442,y:686,t:1527869944284};\\\", \\\"{x:1448,y:686,t:1527869944300};\\\", \\\"{x:1453,y:686,t:1527869944317};\\\", \\\"{x:1457,y:686,t:1527869944334};\\\", \\\"{x:1459,y:688,t:1527869944351};\\\", \\\"{x:1463,y:688,t:1527869944368};\\\", \\\"{x:1465,y:689,t:1527869944383};\\\", \\\"{x:1467,y:690,t:1527869944400};\\\", \\\"{x:1470,y:690,t:1527869944417};\\\", \\\"{x:1471,y:691,t:1527869944433};\\\", \\\"{x:1474,y:691,t:1527869944451};\\\", \\\"{x:1478,y:692,t:1527869944467};\\\", \\\"{x:1479,y:692,t:1527869944512};\\\", \\\"{x:1480,y:692,t:1527869944528};\\\", \\\"{x:1482,y:694,t:1527869944552};\\\", \\\"{x:1483,y:694,t:1527869944567};\\\", \\\"{x:1485,y:698,t:1527869944584};\\\", \\\"{x:1486,y:699,t:1527869944601};\\\", \\\"{x:1487,y:699,t:1527869944616};\\\", \\\"{x:1488,y:699,t:1527869945097};\\\", \\\"{x:1490,y:699,t:1527869945112};\\\", \\\"{x:1493,y:699,t:1527869945120};\\\", \\\"{x:1495,y:699,t:1527869945133};\\\", \\\"{x:1501,y:699,t:1527869945150};\\\", \\\"{x:1507,y:697,t:1527869945166};\\\", \\\"{x:1512,y:696,t:1527869945183};\\\", \\\"{x:1518,y:695,t:1527869945200};\\\", \\\"{x:1521,y:694,t:1527869945216};\\\", \\\"{x:1523,y:694,t:1527869945233};\\\", \\\"{x:1524,y:694,t:1527869945264};\\\", \\\"{x:1525,y:694,t:1527869945288};\\\", \\\"{x:1526,y:694,t:1527869945344};\\\", \\\"{x:1527,y:694,t:1527869945352};\\\", \\\"{x:1529,y:694,t:1527869945365};\\\", \\\"{x:1535,y:694,t:1527869945382};\\\", \\\"{x:1543,y:694,t:1527869945399};\\\", \\\"{x:1551,y:694,t:1527869945416};\\\", \\\"{x:1557,y:696,t:1527869945432};\\\", \\\"{x:1564,y:697,t:1527869945449};\\\", \\\"{x:1569,y:697,t:1527869945466};\\\", \\\"{x:1576,y:699,t:1527869945482};\\\", \\\"{x:1580,y:699,t:1527869945499};\\\", \\\"{x:1582,y:699,t:1527869945516};\\\", \\\"{x:1583,y:699,t:1527869945560};\\\", \\\"{x:1584,y:699,t:1527869945576};\\\", \\\"{x:1585,y:699,t:1527869945601};\\\", \\\"{x:1586,y:699,t:1527869945712};\\\", \\\"{x:1587,y:699,t:1527869945728};\\\", \\\"{x:1588,y:699,t:1527869945768};\\\", \\\"{x:1589,y:697,t:1527869945800};\\\", \\\"{x:1590,y:697,t:1527869945816};\\\", \\\"{x:1592,y:696,t:1527869945832};\\\", \\\"{x:1594,y:696,t:1527869945856};\\\", \\\"{x:1595,y:696,t:1527869945865};\\\", \\\"{x:1596,y:695,t:1527869945882};\\\", \\\"{x:1597,y:695,t:1527869945898};\\\", \\\"{x:1598,y:695,t:1527869945915};\\\", \\\"{x:1600,y:695,t:1527869945932};\\\", \\\"{x:1599,y:695,t:1527869946064};\\\", \\\"{x:1590,y:694,t:1527869946071};\\\", \\\"{x:1580,y:691,t:1527869946080};\\\", \\\"{x:1525,y:682,t:1527869946098};\\\", \\\"{x:1422,y:666,t:1527869946115};\\\", \\\"{x:1309,y:652,t:1527869946131};\\\", \\\"{x:1174,y:642,t:1527869946147};\\\", \\\"{x:1038,y:635,t:1527869946165};\\\", \\\"{x:914,y:623,t:1527869946181};\\\", \\\"{x:805,y:617,t:1527869946198};\\\", \\\"{x:735,y:617,t:1527869946213};\\\", \\\"{x:690,y:615,t:1527869946234};\\\", \\\"{x:670,y:609,t:1527869946249};\\\", \\\"{x:657,y:605,t:1527869946266};\\\", \\\"{x:642,y:599,t:1527869946284};\\\", \\\"{x:623,y:590,t:1527869946301};\\\", \\\"{x:599,y:584,t:1527869946317};\\\", \\\"{x:580,y:581,t:1527869946333};\\\", \\\"{x:561,y:577,t:1527869946349};\\\", \\\"{x:549,y:576,t:1527869946367};\\\", \\\"{x:527,y:576,t:1527869946383};\\\", \\\"{x:515,y:578,t:1527869946399};\\\", \\\"{x:506,y:580,t:1527869946417};\\\", \\\"{x:496,y:581,t:1527869946434};\\\", \\\"{x:486,y:582,t:1527869946450};\\\", \\\"{x:467,y:582,t:1527869946467};\\\", \\\"{x:449,y:581,t:1527869946483};\\\", \\\"{x:428,y:576,t:1527869946500};\\\", \\\"{x:411,y:568,t:1527869946517};\\\", \\\"{x:392,y:559,t:1527869946534};\\\", \\\"{x:372,y:554,t:1527869946551};\\\", \\\"{x:351,y:548,t:1527869946567};\\\", \\\"{x:332,y:547,t:1527869946583};\\\", \\\"{x:328,y:547,t:1527869946601};\\\", \\\"{x:327,y:547,t:1527869946616};\\\", \\\"{x:325,y:547,t:1527869946639};\\\", \\\"{x:325,y:548,t:1527869946650};\\\", \\\"{x:324,y:552,t:1527869946667};\\\", \\\"{x:323,y:554,t:1527869946684};\\\", \\\"{x:321,y:553,t:1527869946752};\\\", \\\"{x:319,y:552,t:1527869946767};\\\", \\\"{x:312,y:549,t:1527869946784};\\\", \\\"{x:310,y:549,t:1527869946801};\\\", \\\"{x:307,y:549,t:1527869946817};\\\", \\\"{x:305,y:549,t:1527869946833};\\\", \\\"{x:305,y:550,t:1527869946888};\\\", \\\"{x:312,y:552,t:1527869946901};\\\", \\\"{x:332,y:556,t:1527869946918};\\\", \\\"{x:371,y:556,t:1527869946933};\\\", \\\"{x:398,y:558,t:1527869946951};\\\", \\\"{x:407,y:558,t:1527869946966};\\\", \\\"{x:408,y:558,t:1527869946984};\\\", \\\"{x:410,y:558,t:1527869947064};\\\", \\\"{x:413,y:558,t:1527869947071};\\\", \\\"{x:414,y:558,t:1527869947084};\\\", \\\"{x:433,y:556,t:1527869947100};\\\", \\\"{x:459,y:556,t:1527869947118};\\\", \\\"{x:474,y:556,t:1527869947133};\\\", \\\"{x:483,y:553,t:1527869947151};\\\", \\\"{x:498,y:553,t:1527869947168};\\\", \\\"{x:504,y:553,t:1527869947185};\\\", \\\"{x:517,y:551,t:1527869947200};\\\", \\\"{x:525,y:545,t:1527869947218};\\\", \\\"{x:533,y:539,t:1527869947234};\\\", \\\"{x:534,y:535,t:1527869947251};\\\", \\\"{x:537,y:531,t:1527869947268};\\\", \\\"{x:541,y:529,t:1527869947284};\\\", \\\"{x:546,y:527,t:1527869947304};\\\", \\\"{x:551,y:526,t:1527869947317};\\\", \\\"{x:568,y:526,t:1527869947334};\\\", \\\"{x:595,y:526,t:1527869947351};\\\", \\\"{x:634,y:526,t:1527869947367};\\\", \\\"{x:666,y:525,t:1527869947384};\\\", \\\"{x:702,y:523,t:1527869947401};\\\", \\\"{x:725,y:518,t:1527869947418};\\\", \\\"{x:729,y:518,t:1527869947435};\\\", \\\"{x:737,y:515,t:1527869947452};\\\", \\\"{x:744,y:512,t:1527869947468};\\\", \\\"{x:746,y:511,t:1527869947485};\\\", \\\"{x:747,y:511,t:1527869947501};\\\", \\\"{x:748,y:510,t:1527869947517};\\\", \\\"{x:750,y:510,t:1527869947534};\\\", \\\"{x:763,y:510,t:1527869947552};\\\", \\\"{x:790,y:510,t:1527869947568};\\\", \\\"{x:820,y:516,t:1527869947585};\\\", \\\"{x:844,y:519,t:1527869947602};\\\", \\\"{x:861,y:520,t:1527869947618};\\\", \\\"{x:864,y:521,t:1527869947634};\\\", \\\"{x:862,y:520,t:1527869947791};\\\", \\\"{x:861,y:520,t:1527869947801};\\\", \\\"{x:859,y:519,t:1527869947817};\\\", \\\"{x:857,y:518,t:1527869947835};\\\", \\\"{x:853,y:517,t:1527869947853};\\\", \\\"{x:848,y:515,t:1527869947867};\\\", \\\"{x:844,y:513,t:1527869947884};\\\", \\\"{x:839,y:511,t:1527869947902};\\\", \\\"{x:834,y:508,t:1527869947918};\\\", \\\"{x:830,y:507,t:1527869947935};\\\", \\\"{x:826,y:504,t:1527869947952};\\\", \\\"{x:825,y:503,t:1527869947968};\\\", \\\"{x:824,y:504,t:1527869948295};\\\", \\\"{x:821,y:508,t:1527869948304};\\\", \\\"{x:818,y:511,t:1527869948318};\\\", \\\"{x:810,y:517,t:1527869948335};\\\", \\\"{x:805,y:527,t:1527869948352};\\\", \\\"{x:805,y:528,t:1527869948400};\\\", \\\"{x:803,y:530,t:1527869948408};\\\", \\\"{x:802,y:531,t:1527869948419};\\\", \\\"{x:794,y:536,t:1527869948436};\\\", \\\"{x:783,y:549,t:1527869948451};\\\", \\\"{x:773,y:566,t:1527869948469};\\\", \\\"{x:771,y:573,t:1527869948485};\\\", \\\"{x:769,y:576,t:1527869948502};\\\", \\\"{x:769,y:577,t:1527869948518};\\\", \\\"{x:771,y:574,t:1527869948543};\\\", \\\"{x:776,y:570,t:1527869948552};\\\", \\\"{x:785,y:559,t:1527869948570};\\\", \\\"{x:793,y:548,t:1527869948586};\\\", \\\"{x:801,y:534,t:1527869948602};\\\", \\\"{x:809,y:527,t:1527869948619};\\\", \\\"{x:813,y:520,t:1527869948636};\\\", \\\"{x:817,y:514,t:1527869948652};\\\", \\\"{x:822,y:509,t:1527869948669};\\\", \\\"{x:823,y:507,t:1527869948686};\\\", \\\"{x:825,y:506,t:1527869948701};\\\", \\\"{x:825,y:505,t:1527869948816};\\\", \\\"{x:825,y:504,t:1527869948823};\\\", \\\"{x:826,y:504,t:1527869949208};\\\", \\\"{x:828,y:507,t:1527869949223};\\\", \\\"{x:829,y:507,t:1527869949264};\\\", \\\"{x:831,y:507,t:1527869949279};\\\", \\\"{x:832,y:507,t:1527869949287};\\\", \\\"{x:834,y:507,t:1527869949301};\\\", \\\"{x:838,y:505,t:1527869949319};\\\", \\\"{x:840,y:501,t:1527869949335};\\\", \\\"{x:842,y:499,t:1527869949352};\\\", \\\"{x:841,y:501,t:1527869949728};\\\", \\\"{x:836,y:508,t:1527869949737};\\\", \\\"{x:829,y:517,t:1527869949753};\\\", \\\"{x:818,y:529,t:1527869949770};\\\", \\\"{x:799,y:545,t:1527869949786};\\\", \\\"{x:769,y:565,t:1527869949803};\\\", \\\"{x:725,y:595,t:1527869949820};\\\", \\\"{x:649,y:635,t:1527869949837};\\\", \\\"{x:564,y:670,t:1527869949852};\\\", \\\"{x:484,y:704,t:1527869949870};\\\", \\\"{x:415,y:735,t:1527869949887};\\\", \\\"{x:393,y:750,t:1527869949903};\\\", \\\"{x:381,y:765,t:1527869949920};\\\", \\\"{x:381,y:769,t:1527869949937};\\\", \\\"{x:380,y:771,t:1527869949952};\\\", \\\"{x:380,y:773,t:1527869949983};\\\", \\\"{x:381,y:773,t:1527869950032};\\\", \\\"{x:382,y:773,t:1527869950039};\\\", \\\"{x:385,y:773,t:1527869950053};\\\", \\\"{x:392,y:769,t:1527869950070};\\\", \\\"{x:406,y:759,t:1527869950087};\\\", \\\"{x:421,y:751,t:1527869950103};\\\", \\\"{x:449,y:740,t:1527869950120};\\\", \\\"{x:463,y:738,t:1527869950136};\\\", \\\"{x:467,y:738,t:1527869950153};\\\", \\\"{x:469,y:738,t:1527869950169};\\\", \\\"{x:471,y:739,t:1527869950185};\\\", \\\"{x:472,y:740,t:1527869950202};\\\", \\\"{x:473,y:740,t:1527869950296};\\\", \\\"{x:474,y:740,t:1527869950311};\\\", \\\"{x:474,y:741,t:1527869950656};\\\", \\\"{x:474,y:745,t:1527869950669};\\\", \\\"{x:474,y:758,t:1527869950687};\\\", \\\"{x:474,y:764,t:1527869950703};\\\", \\\"{x:474,y:766,t:1527869950721};\\\" ] }, { \\\"rt\\\": 19940, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 18, \\\"time_elapsed\\\": 664688, \\\"internal_node_id\\\": \\\"0.0-6.0-8.0\\\", \\\"subject\\\": \\\"DZD6F\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"victor\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 14, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-O -M -M -B -4-4\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:474,y:765,t:1527869952303};\\\", \\\"{x:474,y:763,t:1527869952312};\\\", \\\"{x:474,y:760,t:1527869952322};\\\", \\\"{x:474,y:755,t:1527869952338};\\\", \\\"{x:474,y:752,t:1527869952356};\\\", \\\"{x:474,y:749,t:1527869952371};\\\", \\\"{x:474,y:745,t:1527869952388};\\\", \\\"{x:474,y:744,t:1527869952405};\\\", \\\"{x:476,y:743,t:1527869952422};\\\", \\\"{x:476,y:742,t:1527869952439};\\\", \\\"{x:476,y:739,t:1527869952455};\\\", \\\"{x:476,y:734,t:1527869952472};\\\", \\\"{x:476,y:730,t:1527869952489};\\\", \\\"{x:476,y:726,t:1527869952505};\\\", \\\"{x:476,y:723,t:1527869952522};\\\", \\\"{x:476,y:720,t:1527869952539};\\\", \\\"{x:475,y:720,t:1527869953088};\\\", \\\"{x:475,y:721,t:1527869953095};\\\", \\\"{x:473,y:722,t:1527869953106};\\\", \\\"{x:472,y:724,t:1527869953123};\\\", \\\"{x:471,y:726,t:1527869953138};\\\", \\\"{x:470,y:726,t:1527869953156};\\\", \\\"{x:470,y:727,t:1527869953173};\\\", \\\"{x:469,y:727,t:1527869953189};\\\", \\\"{x:465,y:730,t:1527869953206};\\\", \\\"{x:460,y:736,t:1527869953223};\\\", \\\"{x:451,y:748,t:1527869953239};\\\", \\\"{x:428,y:782,t:1527869953256};\\\", \\\"{x:405,y:821,t:1527869953273};\\\", \\\"{x:373,y:871,t:1527869953288};\\\", \\\"{x:332,y:935,t:1527869953306};\\\", \\\"{x:293,y:1003,t:1527869953323};\\\", \\\"{x:245,y:1068,t:1527869953339};\\\", \\\"{x:194,y:1128,t:1527869953356};\\\", \\\"{x:139,y:1184,t:1527869953372};\\\", \\\"{x:84,y:1215,t:1527869953389};\\\", \\\"{x:38,y:1215,t:1527869953406};\\\", \\\"{x:0,y:1215,t:1527869953423};\\\", \\\"{x:1,y:1215,t:1527869954400};\\\", \\\"{x:13,y:1215,t:1527869954408};\\\", \\\"{x:21,y:1215,t:1527869954423};\\\", \\\"{x:50,y:1215,t:1527869954440};\\\", \\\"{x:72,y:1215,t:1527869954457};\\\", \\\"{x:98,y:1215,t:1527869954472};\\\", \\\"{x:122,y:1215,t:1527869954490};\\\", \\\"{x:135,y:1215,t:1527869954507};\\\", \\\"{x:147,y:1213,t:1527869954524};\\\", \\\"{x:168,y:1203,t:1527869954539};\\\", \\\"{x:198,y:1189,t:1527869954557};\\\", \\\"{x:248,y:1168,t:1527869954573};\\\", \\\"{x:307,y:1137,t:1527869954590};\\\", \\\"{x:387,y:1105,t:1527869954606};\\\", \\\"{x:473,y:1066,t:1527869954622};\\\", \\\"{x:607,y:1023,t:1527869954640};\\\", \\\"{x:693,y:994,t:1527869954657};\\\", \\\"{x:770,y:976,t:1527869954674};\\\", \\\"{x:840,y:956,t:1527869954690};\\\", \\\"{x:908,y:940,t:1527869954707};\\\", \\\"{x:967,y:922,t:1527869954724};\\\", \\\"{x:1026,y:905,t:1527869954740};\\\", \\\"{x:1077,y:886,t:1527869954757};\\\", \\\"{x:1136,y:869,t:1527869954774};\\\", \\\"{x:1187,y:852,t:1527869954790};\\\", \\\"{x:1238,y:836,t:1527869954806};\\\", \\\"{x:1276,y:822,t:1527869954823};\\\", \\\"{x:1301,y:812,t:1527869954840};\\\", \\\"{x:1325,y:801,t:1527869954857};\\\", \\\"{x:1343,y:794,t:1527869954874};\\\", \\\"{x:1355,y:790,t:1527869954890};\\\", \\\"{x:1358,y:789,t:1527869954907};\\\", \\\"{x:1359,y:788,t:1527869955063};\\\", \\\"{x:1360,y:786,t:1527869955079};\\\", \\\"{x:1363,y:785,t:1527869955090};\\\", \\\"{x:1377,y:782,t:1527869955107};\\\", \\\"{x:1391,y:781,t:1527869955124};\\\", \\\"{x:1401,y:779,t:1527869955140};\\\", \\\"{x:1408,y:777,t:1527869955157};\\\", \\\"{x:1416,y:774,t:1527869955174};\\\", \\\"{x:1426,y:773,t:1527869955191};\\\", \\\"{x:1432,y:772,t:1527869955207};\\\", \\\"{x:1440,y:768,t:1527869955224};\\\", \\\"{x:1445,y:764,t:1527869955242};\\\", \\\"{x:1454,y:760,t:1527869955257};\\\", \\\"{x:1459,y:756,t:1527869955274};\\\", \\\"{x:1466,y:752,t:1527869955291};\\\", \\\"{x:1470,y:749,t:1527869955307};\\\", \\\"{x:1475,y:747,t:1527869955324};\\\", \\\"{x:1479,y:746,t:1527869955341};\\\", \\\"{x:1489,y:746,t:1527869955357};\\\", \\\"{x:1499,y:746,t:1527869955374};\\\", \\\"{x:1505,y:746,t:1527869955391};\\\", \\\"{x:1511,y:746,t:1527869955407};\\\", \\\"{x:1512,y:746,t:1527869955424};\\\", \\\"{x:1513,y:746,t:1527869955479};\\\", \\\"{x:1514,y:746,t:1527869955503};\\\", \\\"{x:1514,y:747,t:1527869955511};\\\", \\\"{x:1517,y:749,t:1527869955524};\\\", \\\"{x:1518,y:752,t:1527869955541};\\\", \\\"{x:1520,y:756,t:1527869955559};\\\", \\\"{x:1521,y:759,t:1527869955574};\\\", \\\"{x:1524,y:763,t:1527869955592};\\\", \\\"{x:1526,y:766,t:1527869955608};\\\", \\\"{x:1529,y:772,t:1527869955624};\\\", \\\"{x:1532,y:777,t:1527869955641};\\\", \\\"{x:1532,y:778,t:1527869955658};\\\", \\\"{x:1532,y:779,t:1527869955674};\\\", \\\"{x:1532,y:780,t:1527869955719};\\\", \\\"{x:1532,y:781,t:1527869955791};\\\", \\\"{x:1532,y:784,t:1527869955808};\\\", \\\"{x:1532,y:786,t:1527869955824};\\\", \\\"{x:1531,y:789,t:1527869955841};\\\", \\\"{x:1529,y:792,t:1527869955858};\\\", \\\"{x:1527,y:792,t:1527869955874};\\\", \\\"{x:1526,y:793,t:1527869955892};\\\", \\\"{x:1524,y:794,t:1527869955908};\\\", \\\"{x:1523,y:795,t:1527869955928};\\\", \\\"{x:1522,y:795,t:1527869955941};\\\", \\\"{x:1519,y:798,t:1527869955958};\\\", \\\"{x:1514,y:803,t:1527869955974};\\\", \\\"{x:1505,y:815,t:1527869955991};\\\", \\\"{x:1501,y:820,t:1527869956008};\\\", \\\"{x:1497,y:825,t:1527869956024};\\\", \\\"{x:1494,y:830,t:1527869956041};\\\", \\\"{x:1491,y:834,t:1527869956058};\\\", \\\"{x:1486,y:840,t:1527869956075};\\\", \\\"{x:1484,y:841,t:1527869956091};\\\", \\\"{x:1482,y:843,t:1527869956108};\\\", \\\"{x:1480,y:843,t:1527869956126};\\\", \\\"{x:1479,y:843,t:1527869956176};\\\", \\\"{x:1478,y:843,t:1527869956191};\\\", \\\"{x:1477,y:843,t:1527869956239};\\\", \\\"{x:1476,y:843,t:1527869956256};\\\", \\\"{x:1475,y:842,t:1527869956271};\\\", \\\"{x:1474,y:842,t:1527869956288};\\\", \\\"{x:1474,y:841,t:1527869956296};\\\", \\\"{x:1474,y:840,t:1527869956308};\\\", \\\"{x:1474,y:837,t:1527869956326};\\\", \\\"{x:1474,y:836,t:1527869956341};\\\", \\\"{x:1474,y:833,t:1527869956358};\\\", \\\"{x:1474,y:829,t:1527869956375};\\\", \\\"{x:1474,y:827,t:1527869956391};\\\", \\\"{x:1474,y:826,t:1527869956408};\\\", \\\"{x:1472,y:826,t:1527869956983};\\\", \\\"{x:1470,y:829,t:1527869956991};\\\", \\\"{x:1465,y:835,t:1527869957009};\\\", \\\"{x:1460,y:840,t:1527869957026};\\\", \\\"{x:1449,y:848,t:1527869957042};\\\", \\\"{x:1441,y:853,t:1527869957059};\\\", \\\"{x:1435,y:857,t:1527869957075};\\\", \\\"{x:1431,y:862,t:1527869957092};\\\", \\\"{x:1421,y:877,t:1527869957109};\\\", \\\"{x:1410,y:892,t:1527869957125};\\\", \\\"{x:1398,y:907,t:1527869957142};\\\", \\\"{x:1387,y:920,t:1527869957159};\\\", \\\"{x:1379,y:928,t:1527869957175};\\\", \\\"{x:1373,y:932,t:1527869957192};\\\", \\\"{x:1372,y:932,t:1527869957209};\\\", \\\"{x:1371,y:931,t:1527869957424};\\\", \\\"{x:1371,y:929,t:1527869957431};\\\", \\\"{x:1371,y:926,t:1527869957442};\\\", \\\"{x:1371,y:921,t:1527869957459};\\\", \\\"{x:1372,y:915,t:1527869957476};\\\", \\\"{x:1373,y:910,t:1527869957493};\\\", \\\"{x:1374,y:907,t:1527869957509};\\\", \\\"{x:1374,y:905,t:1527869957526};\\\", \\\"{x:1374,y:904,t:1527869957542};\\\", \\\"{x:1375,y:904,t:1527869957615};\\\", \\\"{x:1375,y:903,t:1527869957626};\\\", \\\"{x:1376,y:900,t:1527869957642};\\\", \\\"{x:1377,y:893,t:1527869957660};\\\", \\\"{x:1378,y:885,t:1527869957676};\\\", \\\"{x:1380,y:872,t:1527869957693};\\\", \\\"{x:1380,y:858,t:1527869957709};\\\", \\\"{x:1380,y:846,t:1527869957726};\\\", \\\"{x:1380,y:834,t:1527869957742};\\\", \\\"{x:1376,y:822,t:1527869957759};\\\", \\\"{x:1374,y:813,t:1527869957775};\\\", \\\"{x:1371,y:805,t:1527869957792};\\\", \\\"{x:1369,y:800,t:1527869957809};\\\", \\\"{x:1367,y:796,t:1527869957826};\\\", \\\"{x:1366,y:792,t:1527869957842};\\\", \\\"{x:1364,y:787,t:1527869957859};\\\", \\\"{x:1363,y:782,t:1527869957877};\\\", \\\"{x:1360,y:774,t:1527869957892};\\\", \\\"{x:1358,y:768,t:1527869957909};\\\", \\\"{x:1356,y:765,t:1527869957926};\\\", \\\"{x:1355,y:762,t:1527869957943};\\\", \\\"{x:1355,y:760,t:1527869957959};\\\", \\\"{x:1354,y:759,t:1527869957976};\\\", \\\"{x:1352,y:757,t:1527869960415};\\\", \\\"{x:1344,y:755,t:1527869960428};\\\", \\\"{x:1330,y:748,t:1527869960444};\\\", \\\"{x:1307,y:737,t:1527869960461};\\\", \\\"{x:1266,y:721,t:1527869960478};\\\", \\\"{x:1219,y:709,t:1527869960494};\\\", \\\"{x:1142,y:700,t:1527869960511};\\\", \\\"{x:1103,y:700,t:1527869960528};\\\", \\\"{x:1086,y:700,t:1527869960544};\\\", \\\"{x:1077,y:700,t:1527869960562};\\\", \\\"{x:1072,y:699,t:1527869960579};\\\", \\\"{x:1066,y:697,t:1527869960594};\\\", \\\"{x:1061,y:695,t:1527869960611};\\\", \\\"{x:1058,y:693,t:1527869960629};\\\", \\\"{x:1056,y:692,t:1527869960644};\\\", \\\"{x:1056,y:693,t:1527869960776};\\\", \\\"{x:1058,y:693,t:1527869960783};\\\", \\\"{x:1061,y:694,t:1527869960794};\\\", \\\"{x:1063,y:695,t:1527869960811};\\\", \\\"{x:1064,y:695,t:1527869960864};\\\", \\\"{x:1065,y:695,t:1527869960887};\\\", \\\"{x:1066,y:695,t:1527869960936};\\\", \\\"{x:1068,y:695,t:1527869960951};\\\", \\\"{x:1071,y:695,t:1527869960961};\\\", \\\"{x:1081,y:703,t:1527869960978};\\\", \\\"{x:1088,y:707,t:1527869960996};\\\", \\\"{x:1095,y:711,t:1527869961011};\\\", \\\"{x:1094,y:711,t:1527869961567};\\\", \\\"{x:1094,y:710,t:1527869961579};\\\", \\\"{x:1093,y:708,t:1527869961595};\\\", \\\"{x:1092,y:707,t:1527869961612};\\\", \\\"{x:1092,y:706,t:1527869961629};\\\", \\\"{x:1092,y:705,t:1527869961645};\\\", \\\"{x:1086,y:705,t:1527869961759};\\\", \\\"{x:1078,y:702,t:1527869961767};\\\", \\\"{x:1062,y:698,t:1527869961779};\\\", \\\"{x:1009,y:683,t:1527869961796};\\\", \\\"{x:934,y:674,t:1527869961812};\\\", \\\"{x:839,y:657,t:1527869961829};\\\", \\\"{x:753,y:646,t:1527869961845};\\\", \\\"{x:681,y:635,t:1527869961862};\\\", \\\"{x:630,y:627,t:1527869961880};\\\", \\\"{x:620,y:627,t:1527869961896};\\\", \\\"{x:618,y:627,t:1527869961912};\\\", \\\"{x:616,y:627,t:1527869961928};\\\", \\\"{x:614,y:627,t:1527869961945};\\\", \\\"{x:607,y:628,t:1527869961962};\\\", \\\"{x:599,y:628,t:1527869961978};\\\", \\\"{x:592,y:628,t:1527869961997};\\\", \\\"{x:582,y:628,t:1527869962012};\\\", \\\"{x:566,y:626,t:1527869962029};\\\", \\\"{x:551,y:622,t:1527869962046};\\\", \\\"{x:539,y:618,t:1527869962062};\\\", \\\"{x:526,y:616,t:1527869962079};\\\", \\\"{x:518,y:614,t:1527869962097};\\\", \\\"{x:508,y:614,t:1527869962112};\\\", \\\"{x:489,y:614,t:1527869962130};\\\", \\\"{x:474,y:614,t:1527869962146};\\\", \\\"{x:460,y:614,t:1527869962163};\\\", \\\"{x:444,y:614,t:1527869962179};\\\", \\\"{x:429,y:613,t:1527869962196};\\\", \\\"{x:417,y:611,t:1527869962213};\\\", \\\"{x:404,y:607,t:1527869962229};\\\", \\\"{x:392,y:602,t:1527869962246};\\\", \\\"{x:372,y:597,t:1527869962264};\\\", \\\"{x:359,y:594,t:1527869962279};\\\", \\\"{x:349,y:594,t:1527869962296};\\\", \\\"{x:335,y:594,t:1527869962313};\\\", \\\"{x:319,y:594,t:1527869962329};\\\", \\\"{x:305,y:596,t:1527869962346};\\\", \\\"{x:293,y:600,t:1527869962363};\\\", \\\"{x:280,y:604,t:1527869962379};\\\", \\\"{x:271,y:606,t:1527869962396};\\\", \\\"{x:267,y:606,t:1527869962413};\\\", \\\"{x:265,y:606,t:1527869962429};\\\", \\\"{x:263,y:606,t:1527869962446};\\\", \\\"{x:262,y:606,t:1527869962462};\\\", \\\"{x:259,y:605,t:1527869962479};\\\", \\\"{x:258,y:605,t:1527869962496};\\\", \\\"{x:257,y:604,t:1527869962591};\\\", \\\"{x:257,y:601,t:1527869962615};\\\", \\\"{x:259,y:600,t:1527869962629};\\\", \\\"{x:261,y:597,t:1527869962646};\\\", \\\"{x:262,y:591,t:1527869962663};\\\", \\\"{x:264,y:586,t:1527869962680};\\\", \\\"{x:266,y:581,t:1527869962696};\\\", \\\"{x:266,y:576,t:1527869962713};\\\", \\\"{x:268,y:572,t:1527869962730};\\\", \\\"{x:268,y:571,t:1527869962751};\\\", \\\"{x:268,y:570,t:1527869962763};\\\", \\\"{x:268,y:569,t:1527869962780};\\\", \\\"{x:265,y:569,t:1527869962797};\\\", \\\"{x:261,y:569,t:1527869962813};\\\", \\\"{x:258,y:569,t:1527869962830};\\\", \\\"{x:255,y:569,t:1527869962847};\\\", \\\"{x:254,y:569,t:1527869962863};\\\", \\\"{x:251,y:569,t:1527869962880};\\\", \\\"{x:249,y:569,t:1527869962897};\\\", \\\"{x:243,y:568,t:1527869962913};\\\", \\\"{x:236,y:568,t:1527869962930};\\\", \\\"{x:225,y:568,t:1527869962947};\\\", \\\"{x:212,y:567,t:1527869962963};\\\", \\\"{x:202,y:567,t:1527869962980};\\\", \\\"{x:199,y:567,t:1527869962997};\\\", \\\"{x:198,y:566,t:1527869963079};\\\", \\\"{x:198,y:564,t:1527869963103};\\\", \\\"{x:195,y:562,t:1527869963114};\\\", \\\"{x:191,y:558,t:1527869963130};\\\", \\\"{x:188,y:554,t:1527869963147};\\\", \\\"{x:182,y:550,t:1527869963163};\\\", \\\"{x:174,y:546,t:1527869963180};\\\", \\\"{x:166,y:543,t:1527869963197};\\\", \\\"{x:163,y:543,t:1527869963213};\\\", \\\"{x:161,y:542,t:1527869963231};\\\", \\\"{x:160,y:542,t:1527869963247};\\\", \\\"{x:158,y:542,t:1527869963263};\\\", \\\"{x:157,y:542,t:1527869963288};\\\", \\\"{x:155,y:542,t:1527869970868};\\\", \\\"{x:160,y:547,t:1527869970884};\\\", \\\"{x:170,y:554,t:1527869970892};\\\", \\\"{x:182,y:563,t:1527869970907};\\\", \\\"{x:255,y:617,t:1527869970940};\\\", \\\"{x:303,y:641,t:1527869970957};\\\", \\\"{x:341,y:661,t:1527869970974};\\\", \\\"{x:364,y:672,t:1527869970991};\\\", \\\"{x:379,y:680,t:1527869971007};\\\", \\\"{x:389,y:686,t:1527869971023};\\\", \\\"{x:400,y:693,t:1527869971041};\\\", \\\"{x:409,y:700,t:1527869971058};\\\", \\\"{x:416,y:704,t:1527869971073};\\\", \\\"{x:419,y:707,t:1527869971090};\\\", \\\"{x:422,y:710,t:1527869971107};\\\", \\\"{x:424,y:713,t:1527869971123};\\\", \\\"{x:426,y:716,t:1527869971141};\\\", \\\"{x:428,y:717,t:1527869971157};\\\", \\\"{x:429,y:718,t:1527869971212};\\\", \\\"{x:430,y:718,t:1527869971224};\\\", \\\"{x:431,y:719,t:1527869971241};\\\", \\\"{x:433,y:719,t:1527869971258};\\\", \\\"{x:437,y:721,t:1527869971275};\\\", \\\"{x:440,y:723,t:1527869971291};\\\", \\\"{x:447,y:726,t:1527869971309};\\\", \\\"{x:453,y:728,t:1527869971325};\\\", \\\"{x:458,y:733,t:1527869971341};\\\", \\\"{x:462,y:735,t:1527869971358};\\\", \\\"{x:465,y:737,t:1527869971375};\\\", \\\"{x:469,y:739,t:1527869971390};\\\", \\\"{x:471,y:741,t:1527869971408};\\\", \\\"{x:474,y:743,t:1527869971424};\\\", \\\"{x:478,y:746,t:1527869971441};\\\", \\\"{x:479,y:747,t:1527869971683};\\\" ] }, { \\\"rt\\\": 50330, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 19, \\\"time_elapsed\\\": 716250, \\\"internal_node_id\\\": \\\"0.0-6.0-9.0\\\", \\\"subject\\\": \\\"DZD6F\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"victor\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 15, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\", \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-01 PM-02 PM-B -O -O -B -B -B -12 PM-02 PM-02 PM-Z -Z -5-G -G -E -G \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:478,y:747,t:1527869973163};\\\", \\\"{x:475,y:746,t:1527869973812};\\\", \\\"{x:471,y:746,t:1527869973827};\\\", \\\"{x:464,y:746,t:1527869973844};\\\", \\\"{x:463,y:746,t:1527869974228};\\\", \\\"{x:461,y:746,t:1527869974244};\\\", \\\"{x:460,y:746,t:1527869974262};\\\", \\\"{x:458,y:746,t:1527869974278};\\\", \\\"{x:453,y:747,t:1527869974294};\\\", \\\"{x:450,y:749,t:1527869974311};\\\", \\\"{x:445,y:751,t:1527869974328};\\\", \\\"{x:436,y:754,t:1527869974346};\\\", \\\"{x:428,y:757,t:1527869974361};\\\", \\\"{x:426,y:758,t:1527869974377};\\\", \\\"{x:424,y:760,t:1527869974394};\\\", \\\"{x:423,y:760,t:1527869974410};\\\", \\\"{x:421,y:760,t:1527869974588};\\\", \\\"{x:420,y:760,t:1527869974596};\\\", \\\"{x:418,y:760,t:1527869974610};\\\", \\\"{x:415,y:760,t:1527869974627};\\\", \\\"{x:408,y:760,t:1527869974644};\\\", \\\"{x:401,y:760,t:1527869974659};\\\", \\\"{x:396,y:760,t:1527869974677};\\\", \\\"{x:394,y:760,t:1527869974694};\\\", \\\"{x:393,y:760,t:1527869974716};\\\", \\\"{x:392,y:760,t:1527869974727};\\\", \\\"{x:391,y:760,t:1527869974744};\\\", \\\"{x:390,y:760,t:1527869974948};\\\", \\\"{x:389,y:760,t:1527869975020};\\\", \\\"{x:388,y:760,t:1527869975036};\\\", \\\"{x:386,y:760,t:1527869975060};\\\", \\\"{x:384,y:760,t:1527869975091};\\\", \\\"{x:383,y:760,t:1527869975100};\\\", \\\"{x:382,y:760,t:1527869975111};\\\", \\\"{x:381,y:760,t:1527869975127};\\\", \\\"{x:380,y:760,t:1527869975147};\\\", \\\"{x:379,y:759,t:1527869975172};\\\", \\\"{x:379,y:758,t:1527869975202};\\\", \\\"{x:377,y:757,t:1527869975379};\\\", \\\"{x:376,y:756,t:1527869975396};\\\", \\\"{x:375,y:756,t:1527869975411};\\\", \\\"{x:374,y:755,t:1527869975428};\\\", \\\"{x:372,y:755,t:1527869975452};\\\", \\\"{x:371,y:755,t:1527869975476};\\\", \\\"{x:369,y:755,t:1527869975507};\\\", \\\"{x:368,y:754,t:1527869975580};\\\", \\\"{x:366,y:753,t:1527869975596};\\\", \\\"{x:366,y:752,t:1527869975611};\\\", \\\"{x:365,y:751,t:1527869975627};\\\", \\\"{x:364,y:751,t:1527869975644};\\\", \\\"{x:364,y:750,t:1527869975661};\\\", \\\"{x:363,y:750,t:1527869975678};\\\", \\\"{x:362,y:749,t:1527869975694};\\\", \\\"{x:360,y:749,t:1527869976108};\\\", \\\"{x:359,y:749,t:1527869976116};\\\", \\\"{x:359,y:750,t:1527869976128};\\\", \\\"{x:382,y:711,t:1527869976524};\\\", \\\"{x:407,y:612,t:1527869976532};\\\", \\\"{x:434,y:526,t:1527869976546};\\\", \\\"{x:476,y:310,t:1527869976563};\\\", \\\"{x:543,y:16,t:1527869976579};\\\", \\\"{x:595,y:16,t:1527869976595};\\\", \\\"{x:648,y:16,t:1527869976612};\\\", \\\"{x:727,y:16,t:1527869976629};\\\", \\\"{x:802,y:16,t:1527869976645};\\\", \\\"{x:875,y:16,t:1527869976661};\\\", \\\"{x:952,y:16,t:1527869976679};\\\", \\\"{x:1025,y:16,t:1527869976695};\\\", \\\"{x:1081,y:16,t:1527869976711};\\\", \\\"{x:1141,y:16,t:1527869976728};\\\", \\\"{x:1192,y:16,t:1527869976744};\\\", \\\"{x:1245,y:16,t:1527869976762};\\\", \\\"{x:1328,y:46,t:1527869976779};\\\", \\\"{x:1361,y:70,t:1527869976795};\\\", \\\"{x:1526,y:194,t:1527869976813};\\\", \\\"{x:1674,y:308,t:1527869976829};\\\", \\\"{x:1815,y:414,t:1527869976846};\\\", \\\"{x:1919,y:503,t:1527869976862};\\\", \\\"{x:1919,y:566,t:1527869976879};\\\", \\\"{x:1919,y:598,t:1527869976894};\\\", \\\"{x:1915,y:602,t:1527869977140};\\\", \\\"{x:1898,y:613,t:1527869977147};\\\", \\\"{x:1870,y:632,t:1527869977160};\\\", \\\"{x:1783,y:694,t:1527869977179};\\\", \\\"{x:1749,y:725,t:1527869977195};\\\", \\\"{x:1721,y:748,t:1527869977212};\\\", \\\"{x:1701,y:762,t:1527869977229};\\\", \\\"{x:1682,y:778,t:1527869977246};\\\", \\\"{x:1662,y:798,t:1527869977261};\\\", \\\"{x:1642,y:827,t:1527869977279};\\\", \\\"{x:1612,y:876,t:1527869977295};\\\", \\\"{x:1593,y:925,t:1527869977313};\\\", \\\"{x:1585,y:951,t:1527869977328};\\\", \\\"{x:1577,y:973,t:1527869977346};\\\", \\\"{x:1569,y:995,t:1527869977362};\\\", \\\"{x:1565,y:1015,t:1527869977379};\\\", \\\"{x:1565,y:1018,t:1527869977395};\\\", \\\"{x:1565,y:1019,t:1527869977436};\\\", \\\"{x:1565,y:1020,t:1527869977484};\\\", \\\"{x:1562,y:1020,t:1527869977507};\\\", \\\"{x:1556,y:1020,t:1527869977515};\\\", \\\"{x:1546,y:1020,t:1527869977529};\\\", \\\"{x:1506,y:1018,t:1527869977546};\\\", \\\"{x:1464,y:1013,t:1527869977563};\\\", \\\"{x:1433,y:1008,t:1527869977579};\\\", \\\"{x:1408,y:1002,t:1527869977596};\\\", \\\"{x:1399,y:1002,t:1527869977613};\\\", \\\"{x:1398,y:1001,t:1527869977629};\\\", \\\"{x:1398,y:998,t:1527869977660};\\\", \\\"{x:1398,y:994,t:1527869977667};\\\", \\\"{x:1398,y:991,t:1527869977680};\\\", \\\"{x:1398,y:987,t:1527869977697};\\\", \\\"{x:1400,y:984,t:1527869977713};\\\", \\\"{x:1405,y:981,t:1527869977729};\\\", \\\"{x:1417,y:977,t:1527869977746};\\\", \\\"{x:1446,y:973,t:1527869977765};\\\", \\\"{x:1463,y:969,t:1527869977780};\\\", \\\"{x:1480,y:966,t:1527869977797};\\\", \\\"{x:1490,y:962,t:1527869977813};\\\", \\\"{x:1491,y:962,t:1527869977829};\\\", \\\"{x:1492,y:961,t:1527869977885};\\\", \\\"{x:1492,y:960,t:1527869977908};\\\", \\\"{x:1492,y:959,t:1527869977916};\\\", \\\"{x:1493,y:959,t:1527869977931};\\\", \\\"{x:1494,y:958,t:1527869977948};\\\", \\\"{x:1492,y:958,t:1527869978092};\\\", \\\"{x:1491,y:959,t:1527869978100};\\\", \\\"{x:1489,y:959,t:1527869978132};\\\", \\\"{x:1488,y:959,t:1527869978188};\\\", \\\"{x:1486,y:960,t:1527869978220};\\\", \\\"{x:1484,y:960,t:1527869978677};\\\", \\\"{x:1483,y:961,t:1527869978692};\\\", \\\"{x:1482,y:961,t:1527869978707};\\\", \\\"{x:1481,y:962,t:1527869978716};\\\", \\\"{x:1480,y:962,t:1527869978772};\\\", \\\"{x:1479,y:963,t:1527869978781};\\\", \\\"{x:1478,y:963,t:1527869982924};\\\", \\\"{x:1474,y:956,t:1527869985917};\\\", \\\"{x:1467,y:947,t:1527869985923};\\\", \\\"{x:1459,y:937,t:1527869985937};\\\", \\\"{x:1445,y:911,t:1527869985953};\\\", \\\"{x:1415,y:859,t:1527869985969};\\\", \\\"{x:1389,y:822,t:1527869985987};\\\", \\\"{x:1370,y:801,t:1527869986003};\\\", \\\"{x:1359,y:792,t:1527869986020};\\\", \\\"{x:1357,y:791,t:1527869986037};\\\", \\\"{x:1357,y:789,t:1527869986054};\\\", \\\"{x:1355,y:789,t:1527869986069};\\\", \\\"{x:1355,y:784,t:1527869986086};\\\", \\\"{x:1354,y:780,t:1527869986104};\\\", \\\"{x:1354,y:778,t:1527869986120};\\\", \\\"{x:1354,y:777,t:1527869986137};\\\", \\\"{x:1353,y:776,t:1527869986154};\\\", \\\"{x:1353,y:775,t:1527869986180};\\\", \\\"{x:1353,y:774,t:1527869986187};\\\", \\\"{x:1353,y:772,t:1527869986203};\\\", \\\"{x:1353,y:769,t:1527869986219};\\\", \\\"{x:1354,y:767,t:1527869986235};\\\", \\\"{x:1354,y:766,t:1527869986253};\\\", \\\"{x:1354,y:764,t:1527869986307};\\\", \\\"{x:1354,y:763,t:1527869986323};\\\", \\\"{x:1354,y:762,t:1527869986347};\\\", \\\"{x:1354,y:761,t:1527869986364};\\\", \\\"{x:1355,y:761,t:1527869986508};\\\", \\\"{x:1358,y:761,t:1527869986521};\\\", \\\"{x:1362,y:762,t:1527869986536};\\\", \\\"{x:1370,y:764,t:1527869986553};\\\", \\\"{x:1371,y:764,t:1527869986571};\\\", \\\"{x:1373,y:764,t:1527869986586};\\\", \\\"{x:1376,y:764,t:1527869986603};\\\", \\\"{x:1380,y:764,t:1527869986620};\\\", \\\"{x:1390,y:764,t:1527869986636};\\\", \\\"{x:1395,y:764,t:1527869986653};\\\", \\\"{x:1399,y:766,t:1527869986670};\\\", \\\"{x:1400,y:766,t:1527869986686};\\\", \\\"{x:1401,y:766,t:1527869986885};\\\", \\\"{x:1400,y:767,t:1527869986900};\\\", \\\"{x:1399,y:768,t:1527869986908};\\\", \\\"{x:1396,y:769,t:1527869986921};\\\", \\\"{x:1389,y:772,t:1527869986937};\\\", \\\"{x:1383,y:775,t:1527869986954};\\\", \\\"{x:1375,y:778,t:1527869986971};\\\", \\\"{x:1369,y:779,t:1527869986987};\\\", \\\"{x:1368,y:779,t:1527869987027};\\\", \\\"{x:1367,y:779,t:1527869987038};\\\", \\\"{x:1363,y:779,t:1527869987054};\\\", \\\"{x:1362,y:779,t:1527869987071};\\\", \\\"{x:1361,y:779,t:1527869987087};\\\", \\\"{x:1360,y:779,t:1527869987103};\\\", \\\"{x:1360,y:778,t:1527869987156};\\\", \\\"{x:1360,y:777,t:1527869987188};\\\", \\\"{x:1360,y:776,t:1527869987204};\\\", \\\"{x:1360,y:775,t:1527869987227};\\\", \\\"{x:1358,y:773,t:1527869987276};\\\", \\\"{x:1357,y:772,t:1527869987288};\\\", \\\"{x:1352,y:771,t:1527869987304};\\\", \\\"{x:1350,y:771,t:1527869987321};\\\", \\\"{x:1348,y:769,t:1527869987338};\\\", \\\"{x:1347,y:769,t:1527869987355};\\\", \\\"{x:1346,y:769,t:1527869987371};\\\", \\\"{x:1345,y:769,t:1527869987387};\\\", \\\"{x:1345,y:768,t:1527869987408};\\\", \\\"{x:1345,y:766,t:1527869987756};\\\", \\\"{x:1346,y:766,t:1527869987995};\\\", \\\"{x:1347,y:766,t:1527869988005};\\\", \\\"{x:1348,y:766,t:1527869988371};\\\", \\\"{x:1348,y:765,t:1527869988388};\\\", \\\"{x:1350,y:765,t:1527869988404};\\\", \\\"{x:1351,y:765,t:1527869988421};\\\", \\\"{x:1353,y:765,t:1527869988444};\\\", \\\"{x:1354,y:765,t:1527869988456};\\\", \\\"{x:1355,y:765,t:1527869988471};\\\", \\\"{x:1356,y:764,t:1527869988489};\\\", \\\"{x:1357,y:764,t:1527869988504};\\\", \\\"{x:1358,y:764,t:1527869988522};\\\", \\\"{x:1360,y:763,t:1527869988539};\\\", \\\"{x:1362,y:763,t:1527869988555};\\\", \\\"{x:1367,y:763,t:1527869988571};\\\", \\\"{x:1370,y:763,t:1527869988589};\\\", \\\"{x:1371,y:763,t:1527869988606};\\\", \\\"{x:1373,y:763,t:1527869988622};\\\", \\\"{x:1376,y:763,t:1527869988639};\\\", \\\"{x:1379,y:763,t:1527869988656};\\\", \\\"{x:1382,y:763,t:1527869988671};\\\", \\\"{x:1384,y:763,t:1527869988689};\\\", \\\"{x:1387,y:763,t:1527869988706};\\\", \\\"{x:1389,y:763,t:1527869988724};\\\", \\\"{x:1390,y:763,t:1527869988756};\\\", \\\"{x:1391,y:763,t:1527869988780};\\\", \\\"{x:1393,y:763,t:1527869988788};\\\", \\\"{x:1394,y:763,t:1527869988806};\\\", \\\"{x:1396,y:763,t:1527869988821};\\\", \\\"{x:1398,y:763,t:1527869988838};\\\", \\\"{x:1402,y:763,t:1527869988855};\\\", \\\"{x:1407,y:763,t:1527869988872};\\\", \\\"{x:1413,y:763,t:1527869988888};\\\", \\\"{x:1418,y:763,t:1527869988906};\\\", \\\"{x:1422,y:763,t:1527869988921};\\\", \\\"{x:1425,y:763,t:1527869988939};\\\", \\\"{x:1433,y:765,t:1527869988957};\\\", \\\"{x:1433,y:766,t:1527869989164};\\\", \\\"{x:1433,y:767,t:1527869989172};\\\", \\\"{x:1432,y:768,t:1527869989188};\\\", \\\"{x:1430,y:769,t:1527869989206};\\\", \\\"{x:1427,y:770,t:1527869989223};\\\", \\\"{x:1425,y:771,t:1527869989239};\\\", \\\"{x:1423,y:771,t:1527869989256};\\\", \\\"{x:1424,y:770,t:1527869989316};\\\", \\\"{x:1425,y:769,t:1527869989324};\\\", \\\"{x:1426,y:769,t:1527869989339};\\\", \\\"{x:1430,y:768,t:1527869989356};\\\", \\\"{x:1434,y:768,t:1527869989372};\\\", \\\"{x:1442,y:768,t:1527869989389};\\\", \\\"{x:1448,y:770,t:1527869989405};\\\", \\\"{x:1456,y:770,t:1527869989423};\\\", \\\"{x:1460,y:771,t:1527869989438};\\\", \\\"{x:1464,y:772,t:1527869989456};\\\", \\\"{x:1466,y:772,t:1527869989491};\\\", \\\"{x:1467,y:772,t:1527869989506};\\\", \\\"{x:1473,y:770,t:1527869989523};\\\", \\\"{x:1483,y:764,t:1527869989539};\\\", \\\"{x:1487,y:762,t:1527869989556};\\\", \\\"{x:1489,y:761,t:1527869989572};\\\", \\\"{x:1491,y:760,t:1527869989590};\\\", \\\"{x:1491,y:759,t:1527869989606};\\\", \\\"{x:1492,y:758,t:1527869989622};\\\", \\\"{x:1492,y:759,t:1527869989900};\\\", \\\"{x:1492,y:761,t:1527869989908};\\\", \\\"{x:1490,y:762,t:1527869989922};\\\", \\\"{x:1488,y:763,t:1527869989940};\\\", \\\"{x:1486,y:764,t:1527869990132};\\\", \\\"{x:1487,y:764,t:1527869990451};\\\", \\\"{x:1488,y:764,t:1527869990459};\\\", \\\"{x:1490,y:764,t:1527869990474};\\\", \\\"{x:1495,y:764,t:1527869990490};\\\", \\\"{x:1499,y:764,t:1527869990506};\\\", \\\"{x:1502,y:764,t:1527869990522};\\\", \\\"{x:1508,y:764,t:1527869990539};\\\", \\\"{x:1512,y:764,t:1527869990557};\\\", \\\"{x:1521,y:766,t:1527869990574};\\\", \\\"{x:1531,y:771,t:1527869990590};\\\", \\\"{x:1533,y:771,t:1527869990607};\\\", \\\"{x:1534,y:771,t:1527869990624};\\\", \\\"{x:1537,y:771,t:1527869990639};\\\", \\\"{x:1538,y:771,t:1527869990657};\\\", \\\"{x:1541,y:771,t:1527869990674};\\\", \\\"{x:1547,y:771,t:1527869990689};\\\", \\\"{x:1552,y:770,t:1527869990707};\\\", \\\"{x:1555,y:769,t:1527869990724};\\\", \\\"{x:1557,y:768,t:1527869990740};\\\", \\\"{x:1558,y:768,t:1527869990771};\\\", \\\"{x:1558,y:767,t:1527869990868};\\\", \\\"{x:1558,y:765,t:1527869990899};\\\", \\\"{x:1558,y:764,t:1527869990940};\\\", \\\"{x:1558,y:763,t:1527869991020};\\\", \\\"{x:1556,y:762,t:1527869991060};\\\", \\\"{x:1555,y:761,t:1527869991091};\\\", \\\"{x:1553,y:760,t:1527869991108};\\\", \\\"{x:1552,y:760,t:1527869991123};\\\", \\\"{x:1552,y:759,t:1527869991141};\\\", \\\"{x:1552,y:758,t:1527869991467};\\\", \\\"{x:1551,y:758,t:1527869991499};\\\", \\\"{x:1550,y:758,t:1527869991556};\\\", \\\"{x:1549,y:758,t:1527869991572};\\\", \\\"{x:1548,y:758,t:1527869991595};\\\", \\\"{x:1547,y:758,t:1527869991660};\\\", \\\"{x:1546,y:758,t:1527869991740};\\\", \\\"{x:1544,y:757,t:1527869991812};\\\", \\\"{x:1545,y:758,t:1527869994485};\\\", \\\"{x:1545,y:759,t:1527869994995};\\\", \\\"{x:1545,y:760,t:1527869995009};\\\", \\\"{x:1535,y:766,t:1527869995027};\\\", \\\"{x:1527,y:766,t:1527869995043};\\\", \\\"{x:1512,y:766,t:1527869995059};\\\", \\\"{x:1494,y:766,t:1527869995077};\\\", \\\"{x:1478,y:766,t:1527869995094};\\\", \\\"{x:1460,y:766,t:1527869995111};\\\", \\\"{x:1443,y:766,t:1527869995126};\\\", \\\"{x:1432,y:766,t:1527869995143};\\\", \\\"{x:1424,y:766,t:1527869995161};\\\", \\\"{x:1415,y:766,t:1527869995176};\\\", \\\"{x:1402,y:766,t:1527869995193};\\\", \\\"{x:1381,y:766,t:1527869995211};\\\", \\\"{x:1359,y:766,t:1527869995226};\\\", \\\"{x:1342,y:766,t:1527869995243};\\\", \\\"{x:1332,y:766,t:1527869995261};\\\", \\\"{x:1330,y:766,t:1527869995276};\\\", \\\"{x:1331,y:766,t:1527869995460};\\\", \\\"{x:1333,y:766,t:1527869995477};\\\", \\\"{x:1334,y:766,t:1527869995494};\\\", \\\"{x:1339,y:766,t:1527869995511};\\\", \\\"{x:1344,y:766,t:1527869995527};\\\", \\\"{x:1352,y:765,t:1527869995544};\\\", \\\"{x:1365,y:764,t:1527869995562};\\\", \\\"{x:1379,y:762,t:1527869995577};\\\", \\\"{x:1387,y:762,t:1527869995594};\\\", \\\"{x:1392,y:762,t:1527869995611};\\\", \\\"{x:1393,y:762,t:1527869995659};\\\", \\\"{x:1394,y:762,t:1527869995700};\\\", \\\"{x:1395,y:762,t:1527869995723};\\\", \\\"{x:1396,y:762,t:1527869995739};\\\", \\\"{x:1397,y:762,t:1527869995748};\\\", \\\"{x:1398,y:762,t:1527869995820};\\\", \\\"{x:1399,y:762,t:1527869995827};\\\", \\\"{x:1401,y:762,t:1527869995844};\\\", \\\"{x:1404,y:762,t:1527869995861};\\\", \\\"{x:1408,y:762,t:1527869995878};\\\", \\\"{x:1409,y:762,t:1527869995894};\\\", \\\"{x:1410,y:762,t:1527869995911};\\\", \\\"{x:1411,y:762,t:1527869995928};\\\", \\\"{x:1412,y:762,t:1527869995963};\\\", \\\"{x:1413,y:762,t:1527869996012};\\\", \\\"{x:1414,y:764,t:1527869998636};\\\", \\\"{x:1413,y:768,t:1527869998647};\\\", \\\"{x:1411,y:769,t:1527869998663};\\\", \\\"{x:1410,y:770,t:1527869998680};\\\", \\\"{x:1408,y:772,t:1527869998696};\\\", \\\"{x:1407,y:772,t:1527869998713};\\\", \\\"{x:1406,y:772,t:1527869998772};\\\", \\\"{x:1404,y:772,t:1527869998780};\\\", \\\"{x:1401,y:772,t:1527869998797};\\\", \\\"{x:1398,y:772,t:1527869998813};\\\", \\\"{x:1394,y:770,t:1527869998830};\\\", \\\"{x:1392,y:769,t:1527869998847};\\\", \\\"{x:1390,y:767,t:1527869998863};\\\", \\\"{x:1385,y:766,t:1527869998880};\\\", \\\"{x:1382,y:765,t:1527869998897};\\\", \\\"{x:1376,y:764,t:1527869998914};\\\", \\\"{x:1371,y:763,t:1527869998930};\\\", \\\"{x:1357,y:763,t:1527869998947};\\\", \\\"{x:1343,y:761,t:1527869998963};\\\", \\\"{x:1336,y:761,t:1527869998981};\\\", \\\"{x:1331,y:761,t:1527869998997};\\\", \\\"{x:1327,y:760,t:1527869999013};\\\", \\\"{x:1323,y:759,t:1527869999030};\\\", \\\"{x:1325,y:760,t:1527869999291};\\\", \\\"{x:1326,y:760,t:1527869999315};\\\", \\\"{x:1327,y:760,t:1527869999332};\\\", \\\"{x:1329,y:760,t:1527869999356};\\\", \\\"{x:1330,y:760,t:1527869999379};\\\", \\\"{x:1331,y:760,t:1527869999404};\\\", \\\"{x:1332,y:760,t:1527869999414};\\\", \\\"{x:1333,y:760,t:1527869999430};\\\", \\\"{x:1334,y:760,t:1527869999459};\\\", \\\"{x:1336,y:760,t:1527869999467};\\\", \\\"{x:1337,y:760,t:1527869999523};\\\", \\\"{x:1338,y:760,t:1527869999531};\\\", \\\"{x:1339,y:760,t:1527869999564};\\\", \\\"{x:1340,y:760,t:1527869999740};\\\", \\\"{x:1341,y:760,t:1527869999788};\\\", \\\"{x:1342,y:760,t:1527869999819};\\\", \\\"{x:1343,y:761,t:1527869999980};\\\", \\\"{x:1343,y:762,t:1527870000014};\\\", \\\"{x:1343,y:763,t:1527870000043};\\\", \\\"{x:1343,y:765,t:1527870000051};\\\", \\\"{x:1343,y:766,t:1527870000063};\\\", \\\"{x:1343,y:768,t:1527870000082};\\\", \\\"{x:1343,y:772,t:1527870000098};\\\", \\\"{x:1343,y:778,t:1527870000114};\\\", \\\"{x:1345,y:787,t:1527870000130};\\\", \\\"{x:1346,y:792,t:1527870000147};\\\", \\\"{x:1348,y:797,t:1527870000164};\\\", \\\"{x:1350,y:810,t:1527870000181};\\\", \\\"{x:1355,y:825,t:1527870000197};\\\", \\\"{x:1359,y:838,t:1527870000214};\\\", \\\"{x:1361,y:849,t:1527870000231};\\\", \\\"{x:1362,y:865,t:1527870000248};\\\", \\\"{x:1362,y:881,t:1527870000264};\\\", \\\"{x:1365,y:898,t:1527870000281};\\\", \\\"{x:1366,y:905,t:1527870000297};\\\", \\\"{x:1366,y:911,t:1527870000314};\\\", \\\"{x:1367,y:917,t:1527870000331};\\\", \\\"{x:1367,y:922,t:1527870000348};\\\", \\\"{x:1367,y:928,t:1527870000365};\\\", \\\"{x:1367,y:936,t:1527870000381};\\\", \\\"{x:1367,y:945,t:1527870000398};\\\", \\\"{x:1367,y:950,t:1527870000415};\\\", \\\"{x:1367,y:953,t:1527870000431};\\\", \\\"{x:1367,y:955,t:1527870000448};\\\", \\\"{x:1366,y:958,t:1527870000465};\\\", \\\"{x:1365,y:960,t:1527870000481};\\\", \\\"{x:1364,y:964,t:1527870000499};\\\", \\\"{x:1359,y:971,t:1527870000515};\\\", \\\"{x:1356,y:974,t:1527870000530};\\\", \\\"{x:1355,y:976,t:1527870000547};\\\", \\\"{x:1354,y:977,t:1527870000659};\\\", \\\"{x:1352,y:977,t:1527870000885};\\\", \\\"{x:1351,y:977,t:1527870000899};\\\", \\\"{x:1350,y:977,t:1527870000915};\\\", \\\"{x:1349,y:977,t:1527870000932};\\\", \\\"{x:1349,y:976,t:1527870000955};\\\", \\\"{x:1348,y:976,t:1527870000987};\\\", \\\"{x:1347,y:976,t:1527870000998};\\\", \\\"{x:1347,y:975,t:1527870001028};\\\", \\\"{x:1347,y:974,t:1527870001076};\\\", \\\"{x:1347,y:973,t:1527870001084};\\\", \\\"{x:1347,y:971,t:1527870001098};\\\", \\\"{x:1348,y:970,t:1527870001114};\\\", \\\"{x:1350,y:968,t:1527870001132};\\\", \\\"{x:1351,y:968,t:1527870001147};\\\", \\\"{x:1355,y:965,t:1527870001164};\\\", \\\"{x:1358,y:964,t:1527870001182};\\\", \\\"{x:1361,y:963,t:1527870001199};\\\", \\\"{x:1366,y:962,t:1527870001215};\\\", \\\"{x:1371,y:961,t:1527870001232};\\\", \\\"{x:1377,y:961,t:1527870001249};\\\", \\\"{x:1379,y:960,t:1527870001265};\\\", \\\"{x:1381,y:960,t:1527870001307};\\\", \\\"{x:1382,y:960,t:1527870001331};\\\", \\\"{x:1383,y:959,t:1527870001348};\\\", \\\"{x:1384,y:959,t:1527870001365};\\\", \\\"{x:1385,y:959,t:1527870001382};\\\", \\\"{x:1388,y:959,t:1527870001399};\\\", \\\"{x:1390,y:959,t:1527870001415};\\\", \\\"{x:1391,y:959,t:1527870001433};\\\", \\\"{x:1393,y:959,t:1527870001449};\\\", \\\"{x:1394,y:959,t:1527870001491};\\\", \\\"{x:1396,y:959,t:1527870001507};\\\", \\\"{x:1397,y:959,t:1527870001531};\\\", \\\"{x:1399,y:959,t:1527870001620};\\\", \\\"{x:1400,y:959,t:1527870001636};\\\", \\\"{x:1402,y:959,t:1527870001651};\\\", \\\"{x:1403,y:959,t:1527870001723};\\\", \\\"{x:1405,y:960,t:1527870001739};\\\", \\\"{x:1406,y:960,t:1527870001749};\\\", \\\"{x:1407,y:960,t:1527870001779};\\\", \\\"{x:1407,y:961,t:1527870001795};\\\", \\\"{x:1408,y:961,t:1527870001868};\\\", \\\"{x:1410,y:961,t:1527870001891};\\\", \\\"{x:1413,y:962,t:1527870001899};\\\", \\\"{x:1423,y:963,t:1527870001915};\\\", \\\"{x:1437,y:966,t:1527870001933};\\\", \\\"{x:1446,y:967,t:1527870001950};\\\", \\\"{x:1455,y:968,t:1527870001966};\\\", \\\"{x:1458,y:969,t:1527870001982};\\\", \\\"{x:1459,y:969,t:1527870001999};\\\", \\\"{x:1460,y:969,t:1527870002016};\\\", \\\"{x:1461,y:970,t:1527870002085};\\\", \\\"{x:1462,y:970,t:1527870002164};\\\", \\\"{x:1464,y:970,t:1527870002179};\\\", \\\"{x:1466,y:970,t:1527870002219};\\\", \\\"{x:1467,y:970,t:1527870002233};\\\", \\\"{x:1470,y:970,t:1527870002249};\\\", \\\"{x:1472,y:970,t:1527870002266};\\\", \\\"{x:1473,y:970,t:1527870002284};\\\", \\\"{x:1474,y:970,t:1527870002379};\\\", \\\"{x:1475,y:969,t:1527870002395};\\\", \\\"{x:1476,y:969,t:1527870002419};\\\", \\\"{x:1477,y:969,t:1527870002435};\\\", \\\"{x:1478,y:968,t:1527870002452};\\\", \\\"{x:1479,y:968,t:1527870002466};\\\", \\\"{x:1482,y:967,t:1527870002484};\\\", \\\"{x:1484,y:966,t:1527870002499};\\\", \\\"{x:1490,y:965,t:1527870002516};\\\", \\\"{x:1494,y:965,t:1527870002533};\\\", \\\"{x:1495,y:965,t:1527870002550};\\\", \\\"{x:1496,y:965,t:1527870002566};\\\", \\\"{x:1498,y:965,t:1527870002603};\\\", \\\"{x:1500,y:965,t:1527870002616};\\\", \\\"{x:1504,y:963,t:1527870002633};\\\", \\\"{x:1509,y:962,t:1527870002651};\\\", \\\"{x:1512,y:962,t:1527870002666};\\\", \\\"{x:1514,y:962,t:1527870002686};\\\", \\\"{x:1515,y:962,t:1527870002714};\\\", \\\"{x:1517,y:962,t:1527870002738};\\\", \\\"{x:1519,y:962,t:1527870002749};\\\", \\\"{x:1525,y:962,t:1527870002765};\\\", \\\"{x:1528,y:962,t:1527870002783};\\\", \\\"{x:1534,y:962,t:1527870002799};\\\", \\\"{x:1540,y:962,t:1527870002815};\\\", \\\"{x:1543,y:962,t:1527870002832};\\\", \\\"{x:1544,y:962,t:1527870002850};\\\", \\\"{x:1545,y:962,t:1527870002907};\\\", \\\"{x:1547,y:962,t:1527870002922};\\\", \\\"{x:1548,y:962,t:1527870002933};\\\", \\\"{x:1550,y:962,t:1527870002950};\\\", \\\"{x:1551,y:962,t:1527870003411};\\\", \\\"{x:1552,y:962,t:1527870003419};\\\", \\\"{x:1553,y:962,t:1527870003492};\\\", \\\"{x:1549,y:962,t:1527870003916};\\\", \\\"{x:1540,y:962,t:1527870003924};\\\", \\\"{x:1529,y:962,t:1527870003934};\\\", \\\"{x:1514,y:962,t:1527870003951};\\\", \\\"{x:1500,y:962,t:1527870003967};\\\", \\\"{x:1490,y:962,t:1527870003983};\\\", \\\"{x:1488,y:962,t:1527870004000};\\\", \\\"{x:1487,y:962,t:1527870004017};\\\", \\\"{x:1484,y:962,t:1527870004033};\\\", \\\"{x:1471,y:962,t:1527870004051};\\\", \\\"{x:1458,y:962,t:1527870004066};\\\", \\\"{x:1441,y:962,t:1527870004084};\\\", \\\"{x:1427,y:962,t:1527870004101};\\\", \\\"{x:1421,y:962,t:1527870004116};\\\", \\\"{x:1418,y:962,t:1527870004134};\\\", \\\"{x:1416,y:962,t:1527870004151};\\\", \\\"{x:1412,y:962,t:1527870004166};\\\", \\\"{x:1407,y:962,t:1527870004184};\\\", \\\"{x:1404,y:962,t:1527870004201};\\\", \\\"{x:1401,y:962,t:1527870004218};\\\", \\\"{x:1400,y:962,t:1527870004243};\\\", \\\"{x:1401,y:963,t:1527870005308};\\\", \\\"{x:1408,y:963,t:1527870005319};\\\", \\\"{x:1422,y:964,t:1527870005335};\\\", \\\"{x:1437,y:967,t:1527870005353};\\\", \\\"{x:1453,y:970,t:1527870005368};\\\", \\\"{x:1464,y:971,t:1527870005386};\\\", \\\"{x:1469,y:971,t:1527870005403};\\\", \\\"{x:1470,y:971,t:1527870005418};\\\", \\\"{x:1472,y:971,t:1527870005684};\\\", \\\"{x:1473,y:971,t:1527870005702};\\\", \\\"{x:1474,y:971,t:1527870005719};\\\", \\\"{x:1475,y:971,t:1527870005735};\\\", \\\"{x:1475,y:970,t:1527870005752};\\\", \\\"{x:1476,y:969,t:1527870005769};\\\", \\\"{x:1476,y:967,t:1527870005786};\\\", \\\"{x:1478,y:966,t:1527870005802};\\\", \\\"{x:1480,y:963,t:1527870005820};\\\", \\\"{x:1482,y:963,t:1527870005836};\\\", \\\"{x:1483,y:962,t:1527870005860};\\\", \\\"{x:1484,y:962,t:1527870005875};\\\", \\\"{x:1484,y:961,t:1527870006068};\\\", \\\"{x:1486,y:960,t:1527870006076};\\\", \\\"{x:1489,y:959,t:1527870006086};\\\", \\\"{x:1495,y:958,t:1527870006102};\\\", \\\"{x:1501,y:958,t:1527870006119};\\\", \\\"{x:1504,y:958,t:1527870006136};\\\", \\\"{x:1505,y:958,t:1527870006163};\\\", \\\"{x:1508,y:958,t:1527870006171};\\\", \\\"{x:1512,y:956,t:1527870006186};\\\", \\\"{x:1520,y:956,t:1527870006202};\\\", \\\"{x:1537,y:956,t:1527870006219};\\\", \\\"{x:1547,y:956,t:1527870006235};\\\", \\\"{x:1549,y:956,t:1527870006252};\\\", \\\"{x:1550,y:956,t:1527870006269};\\\", \\\"{x:1550,y:953,t:1527870006915};\\\", \\\"{x:1547,y:949,t:1527870006923};\\\", \\\"{x:1540,y:944,t:1527870006936};\\\", \\\"{x:1517,y:927,t:1527870006954};\\\", \\\"{x:1482,y:901,t:1527870006971};\\\", \\\"{x:1453,y:878,t:1527870006986};\\\", \\\"{x:1406,y:845,t:1527870007003};\\\", \\\"{x:1386,y:830,t:1527870007019};\\\", \\\"{x:1380,y:825,t:1527870007037};\\\", \\\"{x:1378,y:823,t:1527870007054};\\\", \\\"{x:1376,y:820,t:1527870007070};\\\", \\\"{x:1375,y:816,t:1527870007086};\\\", \\\"{x:1375,y:811,t:1527870007104};\\\", \\\"{x:1373,y:808,t:1527870007121};\\\", \\\"{x:1373,y:803,t:1527870007137};\\\", \\\"{x:1373,y:796,t:1527870007153};\\\", \\\"{x:1372,y:791,t:1527870007170};\\\", \\\"{x:1371,y:787,t:1527870007186};\\\", \\\"{x:1369,y:780,t:1527870007203};\\\", \\\"{x:1369,y:776,t:1527870007221};\\\", \\\"{x:1366,y:768,t:1527870007237};\\\", \\\"{x:1365,y:764,t:1527870007254};\\\", \\\"{x:1363,y:758,t:1527870007270};\\\", \\\"{x:1361,y:755,t:1527870007286};\\\", \\\"{x:1361,y:753,t:1527870007303};\\\", \\\"{x:1361,y:752,t:1527870007320};\\\", \\\"{x:1361,y:748,t:1527870007337};\\\", \\\"{x:1361,y:744,t:1527870007353};\\\", \\\"{x:1361,y:743,t:1527870007370};\\\", \\\"{x:1361,y:741,t:1527870007395};\\\", \\\"{x:1361,y:740,t:1527870007411};\\\", \\\"{x:1361,y:739,t:1527870007435};\\\", \\\"{x:1361,y:738,t:1527870007459};\\\", \\\"{x:1361,y:737,t:1527870007539};\\\", \\\"{x:1361,y:736,t:1527870007636};\\\", \\\"{x:1361,y:734,t:1527870007643};\\\", \\\"{x:1361,y:732,t:1527870007654};\\\", \\\"{x:1361,y:730,t:1527870007670};\\\", \\\"{x:1361,y:726,t:1527870007687};\\\", \\\"{x:1360,y:722,t:1527870007703};\\\", \\\"{x:1360,y:719,t:1527870007721};\\\", \\\"{x:1358,y:715,t:1527870007737};\\\", \\\"{x:1357,y:715,t:1527870007754};\\\", \\\"{x:1357,y:714,t:1527870007811};\\\", \\\"{x:1357,y:713,t:1527870007821};\\\", \\\"{x:1357,y:712,t:1527870007837};\\\", \\\"{x:1357,y:711,t:1527870007891};\\\", \\\"{x:1357,y:710,t:1527870007907};\\\", \\\"{x:1357,y:709,t:1527870007920};\\\", \\\"{x:1357,y:708,t:1527870007939};\\\", \\\"{x:1357,y:707,t:1527870007955};\\\", \\\"{x:1357,y:706,t:1527870007970};\\\", \\\"{x:1357,y:705,t:1527870007988};\\\", \\\"{x:1357,y:704,t:1527870008067};\\\", \\\"{x:1357,y:703,t:1527870008099};\\\", \\\"{x:1357,y:702,t:1527870008139};\\\", \\\"{x:1357,y:700,t:1527870008323};\\\", \\\"{x:1358,y:699,t:1527870008347};\\\", \\\"{x:1360,y:699,t:1527870008355};\\\", \\\"{x:1361,y:698,t:1527870008371};\\\", \\\"{x:1362,y:697,t:1527870008387};\\\", \\\"{x:1363,y:697,t:1527870008404};\\\", \\\"{x:1365,y:697,t:1527870008422};\\\", \\\"{x:1368,y:696,t:1527870008438};\\\", \\\"{x:1371,y:696,t:1527870008454};\\\", \\\"{x:1378,y:696,t:1527870008471};\\\", \\\"{x:1384,y:694,t:1527870008488};\\\", \\\"{x:1391,y:693,t:1527870008504};\\\", \\\"{x:1398,y:692,t:1527870008522};\\\", \\\"{x:1403,y:692,t:1527870008537};\\\", \\\"{x:1406,y:692,t:1527870008555};\\\", \\\"{x:1407,y:692,t:1527870008572};\\\", \\\"{x:1409,y:692,t:1527870008589};\\\", \\\"{x:1410,y:692,t:1527870008604};\\\", \\\"{x:1411,y:692,t:1527870008621};\\\", \\\"{x:1412,y:692,t:1527870008651};\\\", \\\"{x:1413,y:692,t:1527870008660};\\\", \\\"{x:1414,y:693,t:1527870008699};\\\", \\\"{x:1414,y:694,t:1527870008708};\\\", \\\"{x:1416,y:694,t:1527870008722};\\\", \\\"{x:1418,y:696,t:1527870008738};\\\", \\\"{x:1419,y:697,t:1527870008755};\\\", \\\"{x:1420,y:697,t:1527870008771};\\\", \\\"{x:1421,y:698,t:1527870008787};\\\", \\\"{x:1422,y:698,t:1527870009468};\\\", \\\"{x:1424,y:698,t:1527870009475};\\\", \\\"{x:1427,y:698,t:1527870009489};\\\", \\\"{x:1432,y:698,t:1527870009505};\\\", \\\"{x:1439,y:698,t:1527870009522};\\\", \\\"{x:1446,y:693,t:1527870009538};\\\", \\\"{x:1452,y:693,t:1527870009555};\\\", \\\"{x:1453,y:693,t:1527870009571};\\\", \\\"{x:1454,y:693,t:1527870009589};\\\", \\\"{x:1455,y:693,t:1527870009605};\\\", \\\"{x:1456,y:693,t:1527870009622};\\\", \\\"{x:1457,y:693,t:1527870009643};\\\", \\\"{x:1458,y:693,t:1527870009668};\\\", \\\"{x:1459,y:693,t:1527870009675};\\\", \\\"{x:1461,y:693,t:1527870009688};\\\", \\\"{x:1464,y:694,t:1527870009704};\\\", \\\"{x:1465,y:694,t:1527870009721};\\\", \\\"{x:1467,y:694,t:1527870009738};\\\", \\\"{x:1468,y:694,t:1527870009755};\\\", \\\"{x:1469,y:694,t:1527870009811};\\\", \\\"{x:1470,y:694,t:1527870009851};\\\", \\\"{x:1471,y:694,t:1527870009867};\\\", \\\"{x:1472,y:694,t:1527870009875};\\\", \\\"{x:1473,y:694,t:1527870009889};\\\", \\\"{x:1475,y:694,t:1527870009905};\\\", \\\"{x:1477,y:694,t:1527870009922};\\\", \\\"{x:1478,y:694,t:1527870009964};\\\", \\\"{x:1479,y:695,t:1527870009979};\\\", \\\"{x:1480,y:695,t:1527870009995};\\\", \\\"{x:1481,y:695,t:1527870010006};\\\", \\\"{x:1482,y:695,t:1527870010540};\\\", \\\"{x:1489,y:695,t:1527870010557};\\\", \\\"{x:1496,y:695,t:1527870010572};\\\", \\\"{x:1509,y:695,t:1527870010589};\\\", \\\"{x:1524,y:695,t:1527870010606};\\\", \\\"{x:1533,y:695,t:1527870010622};\\\", \\\"{x:1535,y:695,t:1527870010639};\\\", \\\"{x:1536,y:695,t:1527870010656};\\\", \\\"{x:1537,y:695,t:1527870010723};\\\", \\\"{x:1538,y:695,t:1527870010748};\\\", \\\"{x:1540,y:696,t:1527870010757};\\\", \\\"{x:1541,y:697,t:1527870010774};\\\", \\\"{x:1544,y:699,t:1527870010789};\\\", \\\"{x:1546,y:700,t:1527870010806};\\\", \\\"{x:1547,y:700,t:1527870010823};\\\", \\\"{x:1548,y:700,t:1527870010874};\\\", \\\"{x:1549,y:700,t:1527870010890};\\\", \\\"{x:1550,y:700,t:1527870010905};\\\", \\\"{x:1561,y:700,t:1527870010922};\\\", \\\"{x:1569,y:700,t:1527870010939};\\\", \\\"{x:1575,y:700,t:1527870010956};\\\", \\\"{x:1580,y:699,t:1527870010973};\\\", \\\"{x:1582,y:699,t:1527870010989};\\\", \\\"{x:1584,y:699,t:1527870011006};\\\", \\\"{x:1591,y:697,t:1527870011023};\\\", \\\"{x:1600,y:697,t:1527870011040};\\\", \\\"{x:1606,y:697,t:1527870011056};\\\", \\\"{x:1613,y:697,t:1527870011074};\\\", \\\"{x:1620,y:698,t:1527870011089};\\\", \\\"{x:1625,y:698,t:1527870011107};\\\", \\\"{x:1626,y:698,t:1527870011124};\\\", \\\"{x:1626,y:699,t:1527870011163};\\\", \\\"{x:1624,y:700,t:1527870011219};\\\", \\\"{x:1613,y:700,t:1527870011227};\\\", \\\"{x:1599,y:700,t:1527870011241};\\\", \\\"{x:1549,y:697,t:1527870011256};\\\", \\\"{x:1461,y:688,t:1527870011274};\\\", \\\"{x:1352,y:668,t:1527870011290};\\\", \\\"{x:1192,y:642,t:1527870011306};\\\", \\\"{x:1056,y:622,t:1527870011323};\\\", \\\"{x:943,y:608,t:1527870011340};\\\", \\\"{x:837,y:592,t:1527870011356};\\\", \\\"{x:748,y:579,t:1527870011373};\\\", \\\"{x:692,y:571,t:1527870011390};\\\", \\\"{x:637,y:557,t:1527870011406};\\\", \\\"{x:600,y:551,t:1527870011423};\\\", \\\"{x:581,y:551,t:1527870011440};\\\", \\\"{x:559,y:550,t:1527870011455};\\\", \\\"{x:540,y:550,t:1527870011473};\\\", \\\"{x:520,y:550,t:1527870011488};\\\", \\\"{x:490,y:550,t:1527870011506};\\\", \\\"{x:464,y:549,t:1527870011522};\\\", \\\"{x:442,y:549,t:1527870011539};\\\", \\\"{x:426,y:549,t:1527870011556};\\\", \\\"{x:410,y:549,t:1527870011574};\\\", \\\"{x:399,y:549,t:1527870011589};\\\", \\\"{x:397,y:550,t:1527870011606};\\\", \\\"{x:395,y:550,t:1527870011623};\\\", \\\"{x:392,y:553,t:1527870011640};\\\", \\\"{x:387,y:555,t:1527870011656};\\\", \\\"{x:381,y:556,t:1527870011673};\\\", \\\"{x:374,y:559,t:1527870011690};\\\", \\\"{x:371,y:559,t:1527870011706};\\\", \\\"{x:370,y:559,t:1527870011787};\\\", \\\"{x:370,y:558,t:1527870011795};\\\", \\\"{x:373,y:556,t:1527870011808};\\\", \\\"{x:385,y:549,t:1527870011822};\\\", \\\"{x:403,y:540,t:1527870011841};\\\", \\\"{x:428,y:526,t:1527870011858};\\\", \\\"{x:446,y:515,t:1527870011873};\\\", \\\"{x:465,y:510,t:1527870011890};\\\", \\\"{x:493,y:504,t:1527870011907};\\\", \\\"{x:513,y:504,t:1527870011924};\\\", \\\"{x:544,y:504,t:1527870011939};\\\", \\\"{x:564,y:504,t:1527870011957};\\\", \\\"{x:587,y:504,t:1527870011973};\\\", \\\"{x:611,y:512,t:1527870011990};\\\", \\\"{x:629,y:522,t:1527870012007};\\\", \\\"{x:643,y:532,t:1527870012023};\\\", \\\"{x:652,y:539,t:1527870012040};\\\", \\\"{x:658,y:545,t:1527870012057};\\\", \\\"{x:661,y:549,t:1527870012073};\\\", \\\"{x:664,y:556,t:1527870012090};\\\", \\\"{x:664,y:559,t:1527870012106};\\\", \\\"{x:665,y:559,t:1527870012123};\\\", \\\"{x:666,y:559,t:1527870012140};\\\", \\\"{x:670,y:559,t:1527870012157};\\\", \\\"{x:673,y:559,t:1527870012174};\\\", \\\"{x:681,y:559,t:1527870012190};\\\", \\\"{x:700,y:558,t:1527870012207};\\\", \\\"{x:724,y:555,t:1527870012224};\\\", \\\"{x:751,y:551,t:1527870012240};\\\", \\\"{x:778,y:547,t:1527870012257};\\\", \\\"{x:807,y:546,t:1527870012273};\\\", \\\"{x:834,y:543,t:1527870012290};\\\", \\\"{x:842,y:542,t:1527870012307};\\\", \\\"{x:843,y:541,t:1527870012363};\\\", \\\"{x:844,y:540,t:1527870012374};\\\", \\\"{x:844,y:539,t:1527870012390};\\\", \\\"{x:845,y:537,t:1527870012407};\\\", \\\"{x:846,y:534,t:1527870012423};\\\", \\\"{x:846,y:532,t:1527870012440};\\\", \\\"{x:846,y:531,t:1527870012459};\\\", \\\"{x:846,y:529,t:1527870012473};\\\", \\\"{x:846,y:527,t:1527870012490};\\\", \\\"{x:846,y:525,t:1527870012507};\\\", \\\"{x:846,y:523,t:1527870012524};\\\", \\\"{x:846,y:521,t:1527870012540};\\\", \\\"{x:846,y:520,t:1527870012562};\\\", \\\"{x:846,y:519,t:1527870012610};\\\", \\\"{x:846,y:518,t:1527870012634};\\\", \\\"{x:845,y:517,t:1527870012658};\\\", \\\"{x:844,y:517,t:1527870012675};\\\", \\\"{x:842,y:517,t:1527870012690};\\\", \\\"{x:841,y:517,t:1527870012707};\\\", \\\"{x:840,y:517,t:1527870012724};\\\", \\\"{x:838,y:516,t:1527870012740};\\\", \\\"{x:836,y:515,t:1527870012771};\\\", \\\"{x:838,y:514,t:1527870014131};\\\", \\\"{x:851,y:517,t:1527870014142};\\\", \\\"{x:882,y:521,t:1527870014159};\\\", \\\"{x:925,y:528,t:1527870014175};\\\", \\\"{x:981,y:536,t:1527870014192};\\\", \\\"{x:1023,y:541,t:1527870014208};\\\", \\\"{x:1076,y:549,t:1527870014225};\\\", \\\"{x:1127,y:556,t:1527870014242};\\\", \\\"{x:1154,y:558,t:1527870014258};\\\", \\\"{x:1175,y:562,t:1527870014275};\\\", \\\"{x:1194,y:564,t:1527870014293};\\\", \\\"{x:1214,y:568,t:1527870014308};\\\", \\\"{x:1224,y:569,t:1527870014325};\\\", \\\"{x:1225,y:569,t:1527870014342};\\\", \\\"{x:1227,y:569,t:1527870014358};\\\", \\\"{x:1228,y:571,t:1527870014379};\\\", \\\"{x:1230,y:571,t:1527870014395};\\\", \\\"{x:1232,y:571,t:1527870014408};\\\", \\\"{x:1233,y:571,t:1527870014425};\\\", \\\"{x:1234,y:571,t:1527870014491};\\\", \\\"{x:1237,y:571,t:1527870014508};\\\", \\\"{x:1248,y:571,t:1527870014525};\\\", \\\"{x:1262,y:571,t:1527870014542};\\\", \\\"{x:1274,y:571,t:1527870014560};\\\", \\\"{x:1284,y:571,t:1527870014575};\\\", \\\"{x:1288,y:571,t:1527870014593};\\\", \\\"{x:1290,y:571,t:1527870014609};\\\", \\\"{x:1291,y:571,t:1527870014625};\\\", \\\"{x:1292,y:570,t:1527870014700};\\\", \\\"{x:1293,y:569,t:1527870014715};\\\", \\\"{x:1293,y:568,t:1527870014763};\\\", \\\"{x:1294,y:568,t:1527870014867};\\\", \\\"{x:1295,y:568,t:1527870014875};\\\", \\\"{x:1298,y:566,t:1527870014893};\\\", \\\"{x:1301,y:564,t:1527870014909};\\\", \\\"{x:1303,y:562,t:1527870014926};\\\", \\\"{x:1310,y:560,t:1527870014943};\\\", \\\"{x:1313,y:557,t:1527870014959};\\\", \\\"{x:1314,y:557,t:1527870014976};\\\", \\\"{x:1315,y:557,t:1527870015035};\\\", \\\"{x:1317,y:557,t:1527870015051};\\\", \\\"{x:1319,y:557,t:1527870015059};\\\", \\\"{x:1325,y:559,t:1527870015076};\\\", \\\"{x:1340,y:570,t:1527870015092};\\\", \\\"{x:1349,y:577,t:1527870015110};\\\", \\\"{x:1356,y:581,t:1527870015126};\\\", \\\"{x:1358,y:582,t:1527870015143};\\\", \\\"{x:1361,y:583,t:1527870015159};\\\", \\\"{x:1362,y:583,t:1527870015276};\\\", \\\"{x:1364,y:583,t:1527870015293};\\\", \\\"{x:1369,y:582,t:1527870015310};\\\", \\\"{x:1373,y:580,t:1527870015326};\\\", \\\"{x:1379,y:577,t:1527870015342};\\\", \\\"{x:1387,y:575,t:1527870015359};\\\", \\\"{x:1391,y:574,t:1527870015377};\\\", \\\"{x:1393,y:573,t:1527870015393};\\\", \\\"{x:1398,y:572,t:1527870015409};\\\", \\\"{x:1405,y:572,t:1527870015426};\\\", \\\"{x:1411,y:569,t:1527870015443};\\\", \\\"{x:1414,y:569,t:1527870015460};\\\", \\\"{x:1416,y:568,t:1527870015477};\\\", \\\"{x:1417,y:568,t:1527870015547};\\\", \\\"{x:1418,y:568,t:1527870015571};\\\", \\\"{x:1419,y:568,t:1527870015595};\\\", \\\"{x:1420,y:568,t:1527870015610};\\\", \\\"{x:1420,y:567,t:1527870015828};\\\", \\\"{x:1422,y:565,t:1527870015843};\\\", \\\"{x:1426,y:563,t:1527870015860};\\\", \\\"{x:1428,y:562,t:1527870015877};\\\", \\\"{x:1430,y:562,t:1527870015893};\\\", \\\"{x:1431,y:561,t:1527870015910};\\\", \\\"{x:1434,y:560,t:1527870015927};\\\", \\\"{x:1440,y:558,t:1527870015944};\\\", \\\"{x:1450,y:558,t:1527870015960};\\\", \\\"{x:1458,y:556,t:1527870015977};\\\", \\\"{x:1465,y:555,t:1527870015994};\\\", \\\"{x:1467,y:554,t:1527870016011};\\\", \\\"{x:1469,y:554,t:1527870016035};\\\", \\\"{x:1470,y:555,t:1527870016043};\\\", \\\"{x:1472,y:558,t:1527870016061};\\\", \\\"{x:1475,y:560,t:1527870016077};\\\", \\\"{x:1478,y:562,t:1527870016093};\\\", \\\"{x:1478,y:563,t:1527870016115};\\\", \\\"{x:1479,y:564,t:1527870016131};\\\", \\\"{x:1481,y:564,t:1527870016144};\\\", \\\"{x:1481,y:565,t:1527870016161};\\\", \\\"{x:1482,y:568,t:1527870016177};\\\", \\\"{x:1483,y:569,t:1527870016219};\\\", \\\"{x:1484,y:569,t:1527870016307};\\\", \\\"{x:1485,y:569,t:1527870016315};\\\", \\\"{x:1488,y:569,t:1527870016327};\\\", \\\"{x:1495,y:567,t:1527870016344};\\\", \\\"{x:1502,y:564,t:1527870016361};\\\", \\\"{x:1508,y:563,t:1527870016377};\\\", \\\"{x:1509,y:562,t:1527870016394};\\\", \\\"{x:1512,y:561,t:1527870016411};\\\", \\\"{x:1513,y:561,t:1527870016427};\\\", \\\"{x:1514,y:561,t:1527870016444};\\\", \\\"{x:1515,y:560,t:1527870016461};\\\", \\\"{x:1516,y:560,t:1527870016477};\\\", \\\"{x:1518,y:559,t:1527870016494};\\\", \\\"{x:1519,y:559,t:1527870016511};\\\", \\\"{x:1521,y:559,t:1527870016555};\\\", \\\"{x:1522,y:559,t:1527870016563};\\\", \\\"{x:1523,y:559,t:1527870016579};\\\", \\\"{x:1524,y:559,t:1527870016593};\\\", \\\"{x:1525,y:559,t:1527870016610};\\\", \\\"{x:1527,y:559,t:1527870016627};\\\", \\\"{x:1529,y:561,t:1527870016643};\\\", \\\"{x:1532,y:563,t:1527870016660};\\\", \\\"{x:1535,y:566,t:1527870016677};\\\", \\\"{x:1536,y:567,t:1527870016693};\\\", \\\"{x:1539,y:569,t:1527870016710};\\\", \\\"{x:1539,y:570,t:1527870016727};\\\", \\\"{x:1539,y:571,t:1527870016743};\\\", \\\"{x:1540,y:571,t:1527870016760};\\\", \\\"{x:1541,y:571,t:1527870016899};\\\", \\\"{x:1545,y:571,t:1527870016910};\\\", \\\"{x:1559,y:571,t:1527870016927};\\\", \\\"{x:1571,y:567,t:1527870016945};\\\", \\\"{x:1587,y:559,t:1527870016961};\\\", \\\"{x:1598,y:555,t:1527870016977};\\\", \\\"{x:1601,y:554,t:1527870016994};\\\", \\\"{x:1602,y:554,t:1527870017019};\\\", \\\"{x:1603,y:553,t:1527870017027};\\\", \\\"{x:1604,y:553,t:1527870017050};\\\", \\\"{x:1605,y:553,t:1527870017107};\\\", \\\"{x:1606,y:553,t:1527870017123};\\\", \\\"{x:1607,y:553,t:1527870017131};\\\", \\\"{x:1609,y:553,t:1527870017145};\\\", \\\"{x:1611,y:553,t:1527870017163};\\\", \\\"{x:1612,y:553,t:1527870017179};\\\", \\\"{x:1613,y:553,t:1527870017203};\\\", \\\"{x:1614,y:555,t:1527870017211};\\\", \\\"{x:1616,y:555,t:1527870017331};\\\", \\\"{x:1618,y:555,t:1527870017345};\\\", \\\"{x:1627,y:555,t:1527870017361};\\\", \\\"{x:1640,y:553,t:1527870017377};\\\", \\\"{x:1655,y:549,t:1527870017395};\\\", \\\"{x:1660,y:547,t:1527870017410};\\\", \\\"{x:1663,y:545,t:1527870017427};\\\", \\\"{x:1666,y:544,t:1527870017445};\\\", \\\"{x:1667,y:544,t:1527870017484};\\\", \\\"{x:1668,y:544,t:1527870017495};\\\", \\\"{x:1672,y:544,t:1527870017512};\\\", \\\"{x:1674,y:544,t:1527870017528};\\\", \\\"{x:1675,y:544,t:1527870017545};\\\", \\\"{x:1679,y:545,t:1527870017562};\\\", \\\"{x:1682,y:548,t:1527870017577};\\\", \\\"{x:1687,y:553,t:1527870017595};\\\", \\\"{x:1691,y:558,t:1527870017611};\\\", \\\"{x:1694,y:562,t:1527870017628};\\\", \\\"{x:1696,y:566,t:1527870017645};\\\", \\\"{x:1699,y:570,t:1527870017662};\\\", \\\"{x:1700,y:572,t:1527870017678};\\\", \\\"{x:1701,y:572,t:1527870017698};\\\", \\\"{x:1701,y:573,t:1527870018115};\\\", \\\"{x:1694,y:575,t:1527870018131};\\\", \\\"{x:1681,y:575,t:1527870018145};\\\", \\\"{x:1632,y:575,t:1527870018162};\\\", \\\"{x:1571,y:575,t:1527870018179};\\\", \\\"{x:1545,y:575,t:1527870018194};\\\", \\\"{x:1528,y:575,t:1527870018212};\\\", \\\"{x:1517,y:575,t:1527870018229};\\\", \\\"{x:1512,y:575,t:1527870018244};\\\", \\\"{x:1502,y:575,t:1527870018261};\\\", \\\"{x:1487,y:573,t:1527870018278};\\\", \\\"{x:1469,y:569,t:1527870018295};\\\", \\\"{x:1448,y:566,t:1527870018312};\\\", \\\"{x:1431,y:564,t:1527870018328};\\\", \\\"{x:1416,y:562,t:1527870018346};\\\", \\\"{x:1405,y:562,t:1527870018363};\\\", \\\"{x:1388,y:562,t:1527870018379};\\\", \\\"{x:1380,y:563,t:1527870018395};\\\", \\\"{x:1375,y:567,t:1527870018412};\\\", \\\"{x:1372,y:568,t:1527870018429};\\\", \\\"{x:1370,y:568,t:1527870018445};\\\", \\\"{x:1366,y:568,t:1527870018462};\\\", \\\"{x:1359,y:568,t:1527870018478};\\\", \\\"{x:1352,y:568,t:1527870018496};\\\", \\\"{x:1340,y:564,t:1527870018512};\\\", \\\"{x:1330,y:562,t:1527870018528};\\\", \\\"{x:1315,y:560,t:1527870018546};\\\", \\\"{x:1305,y:560,t:1527870018562};\\\", \\\"{x:1297,y:560,t:1527870018578};\\\", \\\"{x:1295,y:561,t:1527870018596};\\\", \\\"{x:1293,y:564,t:1527870018612};\\\", \\\"{x:1287,y:567,t:1527870018629};\\\", \\\"{x:1283,y:569,t:1527870018646};\\\", \\\"{x:1282,y:570,t:1527870018662};\\\", \\\"{x:1281,y:571,t:1527870018678};\\\", \\\"{x:1280,y:571,t:1527870018706};\\\", \\\"{x:1280,y:569,t:1527870018763};\\\", \\\"{x:1283,y:566,t:1527870018779};\\\", \\\"{x:1287,y:565,t:1527870018797};\\\", \\\"{x:1292,y:563,t:1527870018813};\\\", \\\"{x:1298,y:562,t:1527870018829};\\\", \\\"{x:1313,y:561,t:1527870018845};\\\", \\\"{x:1336,y:561,t:1527870018863};\\\", \\\"{x:1355,y:561,t:1527870018879};\\\", \\\"{x:1364,y:561,t:1527870018896};\\\", \\\"{x:1366,y:563,t:1527870018913};\\\", \\\"{x:1367,y:563,t:1527870018947};\\\", \\\"{x:1368,y:563,t:1527870018963};\\\", \\\"{x:1369,y:563,t:1527870019003};\\\", \\\"{x:1369,y:564,t:1527870019019};\\\", \\\"{x:1370,y:564,t:1527870019029};\\\", \\\"{x:1371,y:565,t:1527870019045};\\\", \\\"{x:1371,y:566,t:1527870019062};\\\", \\\"{x:1370,y:568,t:1527870019078};\\\", \\\"{x:1369,y:569,t:1527870019095};\\\", \\\"{x:1368,y:571,t:1527870019112};\\\", \\\"{x:1367,y:571,t:1527870019154};\\\", \\\"{x:1365,y:571,t:1527870019162};\\\", \\\"{x:1363,y:568,t:1527870019178};\\\", \\\"{x:1360,y:565,t:1527870019196};\\\", \\\"{x:1360,y:563,t:1527870019213};\\\", \\\"{x:1361,y:562,t:1527870019267};\\\", \\\"{x:1362,y:561,t:1527870019280};\\\", \\\"{x:1364,y:561,t:1527870019295};\\\", \\\"{x:1367,y:559,t:1527870019313};\\\", \\\"{x:1372,y:557,t:1527870019330};\\\", \\\"{x:1378,y:553,t:1527870019345};\\\", \\\"{x:1383,y:551,t:1527870019363};\\\", \\\"{x:1386,y:549,t:1527870019379};\\\", \\\"{x:1388,y:550,t:1527870019459};\\\", \\\"{x:1391,y:551,t:1527870019467};\\\", \\\"{x:1393,y:554,t:1527870019480};\\\", \\\"{x:1398,y:557,t:1527870019496};\\\", \\\"{x:1401,y:562,t:1527870019512};\\\", \\\"{x:1404,y:565,t:1527870019529};\\\", \\\"{x:1406,y:566,t:1527870019545};\\\", \\\"{x:1407,y:566,t:1527870019563};\\\", \\\"{x:1408,y:566,t:1527870019580};\\\", \\\"{x:1409,y:566,t:1527870019699};\\\", \\\"{x:1412,y:566,t:1527870019713};\\\", \\\"{x:1420,y:566,t:1527870019730};\\\", \\\"{x:1431,y:564,t:1527870019747};\\\", \\\"{x:1438,y:562,t:1527870019762};\\\", \\\"{x:1443,y:560,t:1527870019780};\\\", \\\"{x:1444,y:559,t:1527870019797};\\\", \\\"{x:1445,y:557,t:1527870019813};\\\", \\\"{x:1446,y:557,t:1527870019829};\\\", \\\"{x:1449,y:555,t:1527870019847};\\\", \\\"{x:1450,y:555,t:1527870019863};\\\", \\\"{x:1453,y:554,t:1527870019879};\\\", \\\"{x:1454,y:554,t:1527870019897};\\\", \\\"{x:1456,y:554,t:1527870019987};\\\", \\\"{x:1457,y:554,t:1527870020019};\\\", \\\"{x:1459,y:554,t:1527870020035};\\\", \\\"{x:1460,y:554,t:1527870020047};\\\", \\\"{x:1461,y:554,t:1527870020063};\\\", \\\"{x:1463,y:554,t:1527870020080};\\\", \\\"{x:1464,y:555,t:1527870020097};\\\", \\\"{x:1466,y:556,t:1527870020113};\\\", \\\"{x:1467,y:557,t:1527870020130};\\\", \\\"{x:1469,y:560,t:1527870020146};\\\", \\\"{x:1470,y:560,t:1527870020171};\\\", \\\"{x:1471,y:560,t:1527870020644};\\\", \\\"{x:1472,y:560,t:1527870020667};\\\", \\\"{x:1469,y:564,t:1527870021067};\\\", \\\"{x:1456,y:566,t:1527870021081};\\\", \\\"{x:1414,y:579,t:1527870021097};\\\", \\\"{x:1334,y:586,t:1527870021114};\\\", \\\"{x:1197,y:589,t:1527870021131};\\\", \\\"{x:1092,y:589,t:1527870021148};\\\", \\\"{x:981,y:589,t:1527870021164};\\\", \\\"{x:875,y:588,t:1527870021182};\\\", \\\"{x:775,y:575,t:1527870021197};\\\", \\\"{x:695,y:564,t:1527870021214};\\\", \\\"{x:631,y:555,t:1527870021231};\\\", \\\"{x:574,y:554,t:1527870021247};\\\", \\\"{x:532,y:554,t:1527870021264};\\\", \\\"{x:490,y:554,t:1527870021281};\\\", \\\"{x:457,y:554,t:1527870021297};\\\", \\\"{x:384,y:558,t:1527870021314};\\\", \\\"{x:328,y:565,t:1527870021330};\\\", \\\"{x:282,y:568,t:1527870021347};\\\", \\\"{x:235,y:568,t:1527870021364};\\\", \\\"{x:190,y:568,t:1527870021381};\\\", \\\"{x:140,y:568,t:1527870021397};\\\", \\\"{x:92,y:568,t:1527870021414};\\\", \\\"{x:55,y:568,t:1527870021431};\\\", \\\"{x:37,y:568,t:1527870021447};\\\", \\\"{x:36,y:568,t:1527870021464};\\\", \\\"{x:35,y:569,t:1527870021522};\\\", \\\"{x:35,y:571,t:1527870021531};\\\", \\\"{x:39,y:572,t:1527870021547};\\\", \\\"{x:56,y:574,t:1527870021564};\\\", \\\"{x:78,y:574,t:1527870021581};\\\", \\\"{x:108,y:574,t:1527870021597};\\\", \\\"{x:135,y:574,t:1527870021615};\\\", \\\"{x:165,y:574,t:1527870021631};\\\", \\\"{x:194,y:574,t:1527870021647};\\\", \\\"{x:219,y:574,t:1527870021664};\\\", \\\"{x:243,y:576,t:1527870021681};\\\", \\\"{x:268,y:583,t:1527870021699};\\\", \\\"{x:301,y:588,t:1527870021714};\\\", \\\"{x:319,y:593,t:1527870021731};\\\", \\\"{x:336,y:594,t:1527870021747};\\\", \\\"{x:358,y:596,t:1527870021764};\\\", \\\"{x:382,y:596,t:1527870021781};\\\", \\\"{x:411,y:595,t:1527870021798};\\\", \\\"{x:446,y:583,t:1527870021814};\\\", \\\"{x:480,y:571,t:1527870021832};\\\", \\\"{x:504,y:563,t:1527870021849};\\\", \\\"{x:521,y:559,t:1527870021864};\\\", \\\"{x:532,y:554,t:1527870021881};\\\", \\\"{x:543,y:551,t:1527870021897};\\\", \\\"{x:554,y:549,t:1527870021914};\\\", \\\"{x:555,y:549,t:1527870021931};\\\", \\\"{x:557,y:547,t:1527870021987};\\\", \\\"{x:562,y:544,t:1527870021999};\\\", \\\"{x:572,y:539,t:1527870022015};\\\", \\\"{x:577,y:535,t:1527870022032};\\\", \\\"{x:581,y:532,t:1527870022048};\\\", \\\"{x:583,y:531,t:1527870022065};\\\", \\\"{x:584,y:529,t:1527870022081};\\\", \\\"{x:585,y:527,t:1527870022098};\\\", \\\"{x:586,y:527,t:1527870022114};\\\", \\\"{x:587,y:525,t:1527870022131};\\\", \\\"{x:589,y:525,t:1527870022149};\\\", \\\"{x:590,y:524,t:1527870022164};\\\", \\\"{x:592,y:524,t:1527870022181};\\\", \\\"{x:593,y:523,t:1527870022198};\\\", \\\"{x:594,y:522,t:1527870022214};\\\", \\\"{x:595,y:521,t:1527870022231};\\\", \\\"{x:598,y:519,t:1527870022249};\\\", \\\"{x:601,y:516,t:1527870022265};\\\", \\\"{x:604,y:514,t:1527870022281};\\\", \\\"{x:608,y:511,t:1527870022298};\\\", \\\"{x:605,y:513,t:1527870022562};\\\", \\\"{x:602,y:518,t:1527870022570};\\\", \\\"{x:595,y:525,t:1527870022581};\\\", \\\"{x:587,y:539,t:1527870022599};\\\", \\\"{x:575,y:557,t:1527870022615};\\\", \\\"{x:559,y:584,t:1527870022632};\\\", \\\"{x:547,y:610,t:1527870022649};\\\", \\\"{x:541,y:640,t:1527870022666};\\\", \\\"{x:540,y:677,t:1527870022682};\\\", \\\"{x:540,y:690,t:1527870022697};\\\", \\\"{x:544,y:699,t:1527870022715};\\\", \\\"{x:546,y:703,t:1527870022731};\\\", \\\"{x:547,y:706,t:1527870022748};\\\", \\\"{x:547,y:716,t:1527870022765};\\\", \\\"{x:547,y:727,t:1527870022783};\\\", \\\"{x:547,y:731,t:1527870022799};\\\", \\\"{x:547,y:734,t:1527870022816};\\\", \\\"{x:547,y:736,t:1527870022833};\\\", \\\"{x:547,y:734,t:1527870022899};\\\", \\\"{x:546,y:733,t:1527870022916};\\\", \\\"{x:546,y:732,t:1527870022938};\\\", \\\"{x:545,y:732,t:1527870022970};\\\", \\\"{x:545,y:736,t:1527870022982};\\\", \\\"{x:541,y:747,t:1527870022998};\\\", \\\"{x:538,y:757,t:1527870023015};\\\", \\\"{x:537,y:760,t:1527870023032};\\\", \\\"{x:537,y:761,t:1527870023048};\\\", \\\"{x:536,y:762,t:1527870023266};\\\", \\\"{x:536,y:761,t:1527870023338};\\\", \\\"{x:536,y:760,t:1527870023349};\\\", \\\"{x:536,y:758,t:1527870023365};\\\", \\\"{x:536,y:755,t:1527870023382};\\\", \\\"{x:536,y:751,t:1527870023400};\\\", \\\"{x:536,y:747,t:1527870023415};\\\", \\\"{x:546,y:742,t:1527870023432};\\\", \\\"{x:559,y:735,t:1527870023449};\\\", \\\"{x:573,y:725,t:1527870023465};\\\", \\\"{x:596,y:711,t:1527870023482};\\\", \\\"{x:608,y:702,t:1527870023500};\\\", \\\"{x:612,y:690,t:1527870023515};\\\", \\\"{x:616,y:676,t:1527870023532};\\\", \\\"{x:616,y:666,t:1527870023550};\\\", \\\"{x:615,y:656,t:1527870023566};\\\", \\\"{x:610,y:649,t:1527870023582};\\\", \\\"{x:603,y:645,t:1527870023599};\\\", \\\"{x:592,y:643,t:1527870023615};\\\", \\\"{x:579,y:643,t:1527870023632};\\\", \\\"{x:563,y:643,t:1527870023649};\\\", \\\"{x:549,y:647,t:1527870023665};\\\", \\\"{x:526,y:654,t:1527870023682};\\\", \\\"{x:514,y:657,t:1527870023699};\\\", \\\"{x:510,y:657,t:1527870023716};\\\", \\\"{x:509,y:657,t:1527870023732};\\\", \\\"{x:508,y:657,t:1527870023779};\\\", \\\"{x:508,y:658,t:1527870023851};\\\", \\\"{x:508,y:666,t:1527870023867};\\\", \\\"{x:508,y:667,t:1527870023882};\\\", \\\"{x:508,y:668,t:1527870023899};\\\" ] }, { \\\"rt\\\": 91811, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 20, \\\"time_elapsed\\\": 809254, \\\"internal_node_id\\\": \\\"0.0-7.0-0.0\\\", \\\"subject\\\": \\\"DZD6F\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"victor\\\", \\\"condition\\\": \\\"114\\\", \\\"q\\\": 16, \\\"answer\\\": \\\"determine where 12pm is on the chart, and travel up on a vertical line. every dot that is on that vertical line represents an event that starts at 12pm.\\\", \\\"block\\\": \\\"triangular_testing\\\" }, { \\\"rt\\\": 13193, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"19\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"United States\\\\\\\"}\\\", \\\"block\\\": \\\"demo-1\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 21, \\\"time_elapsed\\\": 823454, \\\"internal_node_id\\\": \\\"0.0-8.0\\\", \\\"subject\\\": \\\"DZD6F\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"victor\\\", \\\"condition\\\": \\\"114\\\" }, { \\\"rt\\\": 8514, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"English\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"Second\\\\\\\",\\\\\\\"Q2\\\\\\\":\\\\\\\"Biomedical & Health Sciences\\\\\\\",\\\\\\\"Q3\\\\\\\":\\\\\\\"Male\\\\\\\"}\\\", \\\"block\\\": \\\"demo-2\\\", \\\"trial_type\\\": \\\"survey-multi-choice\\\", \\\"trial_index\\\": 22, \\\"time_elapsed\\\": 832989, \\\"internal_node_id\\\": \\\"0.0-9.0\\\", \\\"subject\\\": \\\"DZD6F\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"victor\\\", \\\"condition\\\": \\\"114\\\" }, { \\\"rt\\\": 13784, \\\"url\\\": \\\"../views/src/external/debrief.html\\\", \\\"block\\\": \\\"debrief\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 23, \\\"time_elapsed\\\": 848105, \\\"internal_node_id\\\": \\\"0.0-10.0\\\", \\\"subject\\\": \\\"DZD6F\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"victor\\\", \\\"condition\\\": \\\"114\\\" } ]\",\"parentNode\":{\"id\":2765}}],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"META\",\"attributes\":{\"charset\":\"utf-8\"}},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":8,\"id\":59},{\"nodeType\":3,\"id\":60,\"textContent\":\" \"},{\"nodeType\":1,\"id\":61,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":62,\"textContent\":\" \"},{\"nodeType\":1,\"id\":63,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":64,\"textContent\":\" \"},{\"nodeType\":1,\"id\":65,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":66,\"textContent\":\" \"},{\"nodeType\":1,\"id\":67,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":68,\"textContent\":\" \"},{\"nodeType\":1,\"id\":69,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":70,\"textContent\":\" \"},{\"nodeType\":1,\"id\":71,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":72,\"textContent\":\" \"},{\"nodeType\":1,\"id\":73,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"stimulus\"},\"childNodes\":[{\"nodeType\":3,\"id\":74,\"textContent\":\" \"},{\"nodeType\":1,\"id\":75,\"tagName\":\"P\",\"attributes\":{\"class\":\"userid\",\"id\":\"userid\"},\"childNodes\":[{\"nodeType\":3,\"id\":76,\"textContent\":\"DZD6F\"}]},{\"nodeType\":3,\"id\":77,\"textContent\":\" \"},{\"nodeType\":1,\"id\":78,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"userinput\"},\"childNodes\":[{\"nodeType\":3,\"id\":79,\"textContent\":\" \"},{\"nodeType\":8,\"id\":80},{\"nodeType\":3,\"id\":81,\"textContent\":\" \"},{\"nodeType\":1,\"id\":82,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"legend\",\"id\":\"hint-interactive\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":83,\"textContent\":\" \"},{\"nodeType\":1,\"id\":84,\"tagName\":\"P\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":85,\"textContent\":\"Hint: Hover your mouse over the data points in the graph\"}]},{\"nodeType\":3,\"id\":86,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":87,\"textContent\":\" \"},{\"nodeType\":8,\"id\":88},{\"nodeType\":3,\"id\":89,\"textContent\":\" \"},{\"nodeType\":8,\"id\":90},{\"nodeType\":3,\"id\":91,\"textContent\":\" \"},{\"nodeType\":1,\"id\":92,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"test\"},\"childNodes\":[{\"nodeType\":3,\"id\":93,\"textContent\":\" \"},{\"nodeType\":1,\"id\":94,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":95,\"textContent\":\" \"},{\"nodeType\":1,\"id\":96,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":97,\"textContent\":\"Which shift(s) start at 11 am? \"}]},{\"nodeType\":3,\"id\":98,\"textContent\":\" \"},{\"nodeType\":1,\"id\":99,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":100,\"textContent\":\" \"},{\"nodeType\":1,\"id\":101,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":102,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":103,\"textContent\":\" \"},{\"nodeType\":1,\"id\":104,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":105,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":106,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":107,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":108,\"textContent\":\" \"},{\"nodeType\":1,\"id\":109,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":110,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":111,\"textContent\":\" \"},{\"nodeType\":1,\"id\":112,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":113,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":115,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":116,\"textContent\":\" \"},{\"nodeType\":1,\"id\":117,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":118,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":120,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":121,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":122,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":123,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":125,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":126,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":127,\"textContent\":\" \"},{\"nodeType\":1,\"id\":128,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":129,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":130,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":132,\"textContent\":\" \"},{\"nodeType\":1,\"id\":133,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":134,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":135,\"textContent\":\" \"},{\"nodeType\":1,\"id\":136,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":137,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":138,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":140,\"textContent\":\" \"},{\"nodeType\":1,\"id\":141,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":142,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":143,\"textContent\":\" \"},{\"nodeType\":1,\"id\":144,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":145,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":146,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":147,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":148,\"textContent\":\" \"},{\"nodeType\":1,\"id\":149,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":150,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":151,\"textContent\":\" \"},{\"nodeType\":1,\"id\":152,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":153,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":154,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":156,\"textContent\":\" \"},{\"nodeType\":1,\"id\":157,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":158,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":159,\"textContent\":\" \"},{\"nodeType\":1,\"id\":160,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":161,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":162,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":163,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":164,\"textContent\":\" \"},{\"nodeType\":1,\"id\":165,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":166,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":167,\"textContent\":\" \"},{\"nodeType\":1,\"id\":168,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":169,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":170,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":171,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":172,\"textContent\":\" \"},{\"nodeType\":1,\"id\":173,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":174,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":175,\"textContent\":\" \"},{\"nodeType\":1,\"id\":176,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":177,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":178,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":179,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":180,\"textContent\":\" \"},{\"nodeType\":1,\"id\":181,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":182,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":183,\"textContent\":\" \"},{\"nodeType\":1,\"id\":184,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":185,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":186,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":187,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":188,\"textContent\":\" \"},{\"nodeType\":1,\"id\":189,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":190,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":191,\"textContent\":\" \"},{\"nodeType\":1,\"id\":192,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":193,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":194,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":196,\"textContent\":\" \"},{\"nodeType\":1,\"id\":197,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":198,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":200,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":201,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":202,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":203,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":205,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":206,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":207,\"textContent\":\" \"},{\"nodeType\":1,\"id\":208,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":209,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":210,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":211,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":212,\"textContent\":\" \"},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":214,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":215,\"textContent\":\" \"},{\"nodeType\":1,\"id\":216,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":217,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":218,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":219,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":220,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":221,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":223,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":224,\"textContent\":\" \"},{\"nodeType\":1,\"id\":225,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":226,\"textContent\":\"Which shift(s) start at the same time as D?\"}]},{\"nodeType\":3,\"id\":227,\"textContent\":\" \"},{\"nodeType\":1,\"id\":228,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":229,\"textContent\":\" \"},{\"nodeType\":1,\"id\":230,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":231,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":232,\"textContent\":\" \"},{\"nodeType\":1,\"id\":233,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":234,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":235,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":236,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":237,\"textContent\":\" \"},{\"nodeType\":1,\"id\":238,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":239,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":240,\"textContent\":\" \"},{\"nodeType\":1,\"id\":241,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":242,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":243,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":244,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":245,\"textContent\":\" \"},{\"nodeType\":1,\"id\":246,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":247,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":248,\"textContent\":\" \"},{\"nodeType\":1,\"id\":249,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":250,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":251,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":252,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":253,\"textContent\":\" \"},{\"nodeType\":1,\"id\":254,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":255,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":256,\"textContent\":\" \"},{\"nodeType\":1,\"id\":257,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":258,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":259,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":260,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":261,\"textContent\":\" \"},{\"nodeType\":1,\"id\":262,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":263,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":264,\"textContent\":\" \"},{\"nodeType\":1,\"id\":265,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":266,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":267,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":268,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":269,\"textContent\":\" \"},{\"nodeType\":1,\"id\":270,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":271,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":273,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":274,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":275,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":276,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":278,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":279,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":280,\"textContent\":\" \"},{\"nodeType\":1,\"id\":281,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":282,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":283,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":284,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":286,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":287,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":288,\"textContent\":\" \"},{\"nodeType\":1,\"id\":289,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":290,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":291,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":292,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":293,\"textContent\":\" \"},{\"nodeType\":1,\"id\":294,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":295,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":296,\"textContent\":\" \"},{\"nodeType\":1,\"id\":297,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":298,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":299,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":300,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":301,\"textContent\":\" \"},{\"nodeType\":1,\"id\":302,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":303,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":304,\"textContent\":\" \"},{\"nodeType\":1,\"id\":305,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":306,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":307,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":308,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":309,\"textContent\":\" \"},{\"nodeType\":1,\"id\":310,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":311,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":312,\"textContent\":\" \"},{\"nodeType\":1,\"id\":313,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":314,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":315,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":316,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":317,\"textContent\":\" \"},{\"nodeType\":1,\"id\":318,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":319,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":320,\"textContent\":\" \"},{\"nodeType\":1,\"id\":321,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":322,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":323,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":324,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":325,\"textContent\":\" \"},{\"nodeType\":1,\"id\":326,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":327,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":328,\"textContent\":\" \"},{\"nodeType\":1,\"id\":329,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":330,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":331,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":332,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":333,\"textContent\":\" \"},{\"nodeType\":1,\"id\":334,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":335,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":336,\"textContent\":\" \"},{\"nodeType\":1,\"id\":337,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":338,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":339,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":340,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":341,\"textContent\":\" \"},{\"nodeType\":1,\"id\":342,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":343,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":344,\"textContent\":\" \"},{\"nodeType\":1,\"id\":345,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":346,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":347,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":348,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":349,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":351,\"textContent\":\" \"},{\"nodeType\":1,\"id\":352,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":353,\"textContent\":\" \"},{\"nodeType\":1,\"id\":354,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":355,\"textContent\":\"Which shift(s) begin when C ends?\"}]},{\"nodeType\":3,\"id\":356,\"textContent\":\" \"},{\"nodeType\":1,\"id\":357,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":358,\"textContent\":\" \"},{\"nodeType\":1,\"id\":359,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":360,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":361,\"textContent\":\" \"},{\"nodeType\":1,\"id\":362,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":363,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":364,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":365,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":366,\"textContent\":\" \"},{\"nodeType\":1,\"id\":367,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":368,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":369,\"textContent\":\" \"},{\"nodeType\":1,\"id\":370,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":371,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":372,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":373,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":374,\"textContent\":\" \"},{\"nodeType\":1,\"id\":375,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":376,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":377,\"textContent\":\" \"},{\"nodeType\":1,\"id\":378,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":379,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":380,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":381,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":382,\"textContent\":\" \"},{\"nodeType\":1,\"id\":383,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":384,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":385,\"textContent\":\" \"},{\"nodeType\":1,\"id\":386,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":387,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":388,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":389,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":390,\"textContent\":\" \"},{\"nodeType\":1,\"id\":391,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":392,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":393,\"textContent\":\" \"},{\"nodeType\":1,\"id\":394,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":395,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":396,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":397,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":398,\"textContent\":\" \"},{\"nodeType\":1,\"id\":399,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":400,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":401,\"textContent\":\" \"},{\"nodeType\":1,\"id\":402,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":403,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":404,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":405,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":406,\"textContent\":\" \"},{\"nodeType\":1,\"id\":407,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":408,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":409,\"textContent\":\" \"},{\"nodeType\":1,\"id\":410,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":411,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":412,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":413,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":414,\"textContent\":\" \"},{\"nodeType\":1,\"id\":415,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":416,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":417,\"textContent\":\" \"},{\"nodeType\":1,\"id\":418,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":419,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":420,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":421,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":422,\"textContent\":\" \"},{\"nodeType\":1,\"id\":423,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":424,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":425,\"textContent\":\" \"},{\"nodeType\":1,\"id\":426,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":427,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":428,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":429,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":430,\"textContent\":\" \"},{\"nodeType\":1,\"id\":431,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":432,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":433,\"textContent\":\" \"},{\"nodeType\":1,\"id\":434,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":435,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":436,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":437,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":438,\"textContent\":\" \"},{\"nodeType\":1,\"id\":439,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":440,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":441,\"textContent\":\" \"},{\"nodeType\":1,\"id\":442,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":443,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":444,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":445,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":446,\"textContent\":\" \"},{\"nodeType\":1,\"id\":447,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":448,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":449,\"textContent\":\" \"},{\"nodeType\":1,\"id\":450,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":451,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":452,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":453,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":454,\"textContent\":\" \"},{\"nodeType\":1,\"id\":455,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":456,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":457,\"textContent\":\" \"},{\"nodeType\":1,\"id\":458,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":459,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":460,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":461,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":462,\"textContent\":\" \"},{\"nodeType\":1,\"id\":463,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":464,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":465,\"textContent\":\" \"},{\"nodeType\":1,\"id\":466,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":467,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":468,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":469,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":470,\"textContent\":\" \"},{\"nodeType\":1,\"id\":471,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":472,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":473,\"textContent\":\" \"},{\"nodeType\":1,\"id\":474,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":475,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":476,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":477,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":478,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":479,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":480,\"textContent\":\" \"},{\"nodeType\":1,\"id\":481,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":483,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":484,\"textContent\":\" Which shift(s) end at 4 pm?\"}]},{\"nodeType\":3,\"id\":485,\"textContent\":\" \"},{\"nodeType\":1,\"id\":486,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":492,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":500,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":503,\"textContent\":\" \"},{\"nodeType\":1,\"id\":504,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":505,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":506,\"textContent\":\" \"},{\"nodeType\":1,\"id\":507,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":508,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":509,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":510,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":511,\"textContent\":\" \"},{\"nodeType\":1,\"id\":512,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":513,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":514,\"textContent\":\" \"},{\"nodeType\":1,\"id\":515,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":516,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":517,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":518,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":519,\"textContent\":\" \"},{\"nodeType\":1,\"id\":520,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":521,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":522,\"textContent\":\" \"},{\"nodeType\":1,\"id\":523,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":524,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":525,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":526,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":527,\"textContent\":\" \"},{\"nodeType\":1,\"id\":528,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":529,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":530,\"textContent\":\" \"},{\"nodeType\":1,\"id\":531,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":532,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":533,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":534,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":535,\"textContent\":\" \"},{\"nodeType\":1,\"id\":536,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":537,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":538,\"textContent\":\" \"},{\"nodeType\":1,\"id\":539,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":540,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":541,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":542,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":543,\"textContent\":\" \"},{\"nodeType\":1,\"id\":544,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":545,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":546,\"textContent\":\" \"},{\"nodeType\":1,\"id\":547,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":548,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":549,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":550,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":551,\"textContent\":\" \"},{\"nodeType\":1,\"id\":552,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":553,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":554,\"textContent\":\" \"},{\"nodeType\":1,\"id\":555,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":556,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":557,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":558,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":559,\"textContent\":\" \"},{\"nodeType\":1,\"id\":560,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":561,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":562,\"textContent\":\" \"},{\"nodeType\":1,\"id\":563,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":564,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":565,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":566,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":567,\"textContent\":\" \"},{\"nodeType\":1,\"id\":568,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":569,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":570,\"textContent\":\" \"},{\"nodeType\":1,\"id\":571,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":572,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":573,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":574,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":575,\"textContent\":\" \"},{\"nodeType\":1,\"id\":576,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":577,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":578,\"textContent\":\" \"},{\"nodeType\":1,\"id\":579,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":580,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":581,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":582,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":583,\"textContent\":\" \"},{\"nodeType\":1,\"id\":584,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":585,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":586,\"textContent\":\" \"},{\"nodeType\":1,\"id\":587,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":588,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":589,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":590,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":592,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":593,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":594,\"textContent\":\" \"},{\"nodeType\":1,\"id\":595,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":596,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":597,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":598,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":599,\"textContent\":\" \"},{\"nodeType\":1,\"id\":600,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":601,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":602,\"textContent\":\" \"},{\"nodeType\":1,\"id\":603,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":604,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":605,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":606,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":607,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":608,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":609,\"textContent\":\" \"},{\"nodeType\":1,\"id\":610,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":612,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":613,\"textContent\":\"Coffee breaks happen halfway through a shift.\"},{\"nodeType\":1,\"id\":614,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":615,\"textContent\":\" Which shift(s) share a break with I?\"}]},{\"nodeType\":3,\"id\":616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":617,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":618,\"textContent\":\" \"},{\"nodeType\":1,\"id\":619,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":620,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":621,\"textContent\":\" \"},{\"nodeType\":1,\"id\":622,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":623,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":624,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":625,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":626,\"textContent\":\" \"},{\"nodeType\":1,\"id\":627,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":628,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":629,\"textContent\":\" \"},{\"nodeType\":1,\"id\":630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":631,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":632,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":633,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":634,\"textContent\":\" \"},{\"nodeType\":1,\"id\":635,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":636,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":637,\"textContent\":\" \"},{\"nodeType\":1,\"id\":638,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":639,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":640,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":641,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":642,\"textContent\":\" \"},{\"nodeType\":1,\"id\":643,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":644,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":645,\"textContent\":\" \"},{\"nodeType\":1,\"id\":646,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":647,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":648,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":649,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":650,\"textContent\":\" \"},{\"nodeType\":1,\"id\":651,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":653,\"textContent\":\" \"},{\"nodeType\":1,\"id\":654,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":655,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":656,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":657,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":659,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":660,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":661,\"textContent\":\" \"},{\"nodeType\":1,\"id\":662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":663,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":664,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":665,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":666,\"textContent\":\" \"},{\"nodeType\":1,\"id\":667,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":668,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":669,\"textContent\":\" \"},{\"nodeType\":1,\"id\":670,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":671,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":672,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":673,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":674,\"textContent\":\" \"},{\"nodeType\":1,\"id\":675,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":676,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":677,\"textContent\":\" \"},{\"nodeType\":1,\"id\":678,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":679,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":680,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":681,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":682,\"textContent\":\" \"},{\"nodeType\":1,\"id\":683,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":685,\"textContent\":\" \"},{\"nodeType\":1,\"id\":686,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":687,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":688,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":689,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":690,\"textContent\":\" \"},{\"nodeType\":1,\"id\":691,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":692,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":693,\"textContent\":\" \"},{\"nodeType\":1,\"id\":694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":695,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":696,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":697,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":698,\"textContent\":\" \"},{\"nodeType\":1,\"id\":699,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":700,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":701,\"textContent\":\" \"},{\"nodeType\":1,\"id\":702,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":703,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":704,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":705,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":706,\"textContent\":\" \"},{\"nodeType\":1,\"id\":707,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":708,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":709,\"textContent\":\" \"},{\"nodeType\":1,\"id\":710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":711,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":712,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":713,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":714,\"textContent\":\" \"},{\"nodeType\":1,\"id\":715,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":716,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":717,\"textContent\":\" \"},{\"nodeType\":1,\"id\":718,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":719,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":720,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":721,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":722,\"textContent\":\" \"},{\"nodeType\":1,\"id\":723,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":724,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":725,\"textContent\":\" \"},{\"nodeType\":1,\"id\":726,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":727,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":728,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":729,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":730,\"textContent\":\" \"},{\"nodeType\":1,\"id\":731,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":732,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":733,\"textContent\":\" \"},{\"nodeType\":1,\"id\":734,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":735,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":736,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":737,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":738,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":739,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":741,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":742,\"textContent\":\" \"},{\"nodeType\":1,\"id\":743,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":744,\"textContent\":\"Which shift(s) are six hours long?\"}]},{\"nodeType\":3,\"id\":745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":746,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":747,\"textContent\":\" \"},{\"nodeType\":1,\"id\":748,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":749,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":750,\"textContent\":\" \"},{\"nodeType\":1,\"id\":751,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":752,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":753,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":754,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":755,\"textContent\":\" \"},{\"nodeType\":1,\"id\":756,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":757,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":758,\"textContent\":\" \"},{\"nodeType\":1,\"id\":759,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":760,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":761,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":762,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":763,\"textContent\":\" \"},{\"nodeType\":1,\"id\":764,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":765,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":766,\"textContent\":\" \"},{\"nodeType\":1,\"id\":767,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":768,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":769,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":770,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":771,\"textContent\":\" \"},{\"nodeType\":1,\"id\":772,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":773,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":774,\"textContent\":\" \"},{\"nodeType\":1,\"id\":775,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":776,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":777,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":778,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":779,\"textContent\":\" \"},{\"nodeType\":1,\"id\":780,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":781,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":782,\"textContent\":\" \"},{\"nodeType\":1,\"id\":783,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":784,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":785,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":786,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":787,\"textContent\":\" \"},{\"nodeType\":1,\"id\":788,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":789,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":790,\"textContent\":\" \"},{\"nodeType\":1,\"id\":791,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":792,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":793,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":794,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":795,\"textContent\":\" \"},{\"nodeType\":1,\"id\":796,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":797,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":798,\"textContent\":\" \"},{\"nodeType\":1,\"id\":799,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":800,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":801,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":802,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":803,\"textContent\":\" \"},{\"nodeType\":1,\"id\":804,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":805,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":806,\"textContent\":\" \"},{\"nodeType\":1,\"id\":807,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":808,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":809,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":810,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":812,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":813,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":814,\"textContent\":\" \"},{\"nodeType\":1,\"id\":815,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":816,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":817,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":818,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":819,\"textContent\":\" \"},{\"nodeType\":1,\"id\":820,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":821,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":822,\"textContent\":\" \"},{\"nodeType\":1,\"id\":823,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":824,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":825,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":826,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":827,\"textContent\":\" \"},{\"nodeType\":1,\"id\":828,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":829,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":830,\"textContent\":\" \"},{\"nodeType\":1,\"id\":831,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":832,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":833,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":834,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":835,\"textContent\":\" \"},{\"nodeType\":1,\"id\":836,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":837,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":838,\"textContent\":\" \"},{\"nodeType\":1,\"id\":839,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":840,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":841,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":842,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":843,\"textContent\":\" \"},{\"nodeType\":1,\"id\":844,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":845,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":846,\"textContent\":\" \"},{\"nodeType\":1,\"id\":847,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":848,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":849,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":850,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":851,\"textContent\":\" \"},{\"nodeType\":1,\"id\":852,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":853,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":854,\"textContent\":\" \"},{\"nodeType\":1,\"id\":855,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":856,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":857,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":858,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":859,\"textContent\":\" \"},{\"nodeType\":1,\"id\":860,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":861,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":862,\"textContent\":\" \"},{\"nodeType\":1,\"id\":863,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":864,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":865,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":866,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":867,\"textContent\":\" \"},{\"nodeType\":1,\"id\":868,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":869,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":870,\"textContent\":\" \"},{\"nodeType\":1,\"id\":871,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":872,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":873,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":874,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":875,\"textContent\":\" \"},{\"nodeType\":1,\"id\":876,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":877,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":878,\"textContent\":\" \"},{\"nodeType\":1,\"id\":879,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":880,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":881,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":882,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":883,\"textContent\":\" \"},{\"nodeType\":1,\"id\":884,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":885,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":886,\"textContent\":\" \"},{\"nodeType\":1,\"id\":887,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":888,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":889,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":890,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":891,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":892,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":894,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":895,\"textContent\":\" \"},{\"nodeType\":1,\"id\":896,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":897,\"textContent\":\"Which 2 shifts less than 5 hours long start at the same time?\"}]},{\"nodeType\":3,\"id\":898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":899,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":900,\"textContent\":\" \"},{\"nodeType\":1,\"id\":901,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":902,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":903,\"textContent\":\" \"},{\"nodeType\":1,\"id\":904,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":905,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":906,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":907,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":908,\"textContent\":\" \"},{\"nodeType\":1,\"id\":909,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":910,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":911,\"textContent\":\" \"},{\"nodeType\":1,\"id\":912,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":913,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":914,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":915,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":916,\"textContent\":\" \"},{\"nodeType\":1,\"id\":917,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":918,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":919,\"textContent\":\" \"},{\"nodeType\":1,\"id\":920,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":921,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":922,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":923,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":924,\"textContent\":\" \"},{\"nodeType\":1,\"id\":925,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":926,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":927,\"textContent\":\" \"},{\"nodeType\":1,\"id\":928,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":929,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":930,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":931,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":932,\"textContent\":\" \"},{\"nodeType\":1,\"id\":933,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":934,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":935,\"textContent\":\" \"},{\"nodeType\":1,\"id\":936,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":937,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":938,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":939,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":940,\"textContent\":\" \"},{\"nodeType\":1,\"id\":941,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":942,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":943,\"textContent\":\" \"},{\"nodeType\":1,\"id\":944,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":945,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":946,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":947,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":948,\"textContent\":\" \"},{\"nodeType\":1,\"id\":949,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":950,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":951,\"textContent\":\" \"},{\"nodeType\":1,\"id\":952,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":953,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":954,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":955,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":956,\"textContent\":\" \"},{\"nodeType\":1,\"id\":957,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":958,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":959,\"textContent\":\" \"},{\"nodeType\":1,\"id\":960,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":961,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":962,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":963,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":965,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":966,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":967,\"textContent\":\" \"},{\"nodeType\":1,\"id\":968,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":969,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":970,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":971,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":972,\"textContent\":\" \"},{\"nodeType\":1,\"id\":973,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":974,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":975,\"textContent\":\" \"},{\"nodeType\":1,\"id\":976,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":977,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":978,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":979,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":980,\"textContent\":\" \"},{\"nodeType\":1,\"id\":981,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":982,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":983,\"textContent\":\" \"},{\"nodeType\":1,\"id\":984,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":985,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":986,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":987,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":988,\"textContent\":\" \"},{\"nodeType\":1,\"id\":989,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":990,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":991,\"textContent\":\" \"},{\"nodeType\":1,\"id\":992,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":993,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":994,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":995,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":996,\"textContent\":\" \"},{\"nodeType\":1,\"id\":997,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":998,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":999,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1000,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1001,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1002,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1003,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1004,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1005,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1006,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1007,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1008,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1009,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1010,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1011,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1012,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1013,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1014,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1015,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1016,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1017,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1018,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1019,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1020,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1021,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1022,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1023,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1024,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1025,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1026,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1027,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1028,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1029,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1030,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1031,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1032,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1033,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1034,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1035,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1036,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1037,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1038,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1039,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1040,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1041,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1042,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1043,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1044,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1045,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1047,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+contained\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1048,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1049,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1050,\"textContent\":\"Which shift(s) under 7 hours long starts before B starts, and ends after X ends?\"}]},{\"nodeType\":3,\"id\":1051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1052,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1053,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1054,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1055,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1056,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1057,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1058,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1059,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1060,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1061,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1062,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1063,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1064,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1065,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1066,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1067,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1068,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1069,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1070,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1071,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1072,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1073,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1074,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1075,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1076,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1077,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1078,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1079,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1080,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1081,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1082,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1083,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1084,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1085,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1086,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1087,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1088,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1089,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1090,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1091,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1092,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1093,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1094,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1095,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1096,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1097,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1098,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1099,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1100,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1101,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1102,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1103,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1104,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1105,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1106,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1107,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1108,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1109,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1110,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1111,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1112,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1113,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1114,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1115,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1116,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1118,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1119,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1120,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1121,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1122,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1123,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1124,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1125,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1126,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1127,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1128,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1129,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1130,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1131,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1132,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1133,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1134,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1135,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1136,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1137,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1138,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1139,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1140,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1141,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1142,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1143,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1144,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1145,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1146,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1147,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1148,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1149,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1150,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1151,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1152,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1153,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1154,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1155,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1156,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1157,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1158,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1159,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1160,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1161,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1162,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1163,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1164,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1165,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1166,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1167,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1168,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1169,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1170,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1171,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1172,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1173,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1174,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1175,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1176,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1177,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1178,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1179,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1180,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1181,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1182,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1183,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1184,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1185,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1186,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1187,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1188,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1189,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1190,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1191,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1192,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1193,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1194,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1195,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1196,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1197,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1198,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1200,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime+before+endtime+during\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1202,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1203,\"textContent\":\"Which shift(s) begins before J begins and ends during B?\"}]},{\"nodeType\":3,\"id\":1204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1205,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1211,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1219,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1227,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1235,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1243,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1251,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1259,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1267,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1270,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1271,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1272,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1273,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1274,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1275,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1276,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1277,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1278,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1279,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1280,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1281,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1282,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1283,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1284,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1285,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1286,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1287,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1288,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1289,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1290,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1291,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1292,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1293,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1294,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1295,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1296,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1298,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1299,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1300,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1301,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1302,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1303,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1304,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1305,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1306,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1307,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1308,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1309,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1310,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1311,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1312,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1313,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1314,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1315,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1316,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1317,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1318,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1319,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1320,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1321,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1322,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1323,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1324,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1325,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1326,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1327,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1328,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1329,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1330,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1331,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1332,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1333,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1334,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1335,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1336,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1337,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1338,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1339,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1340,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1341,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1342,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1343,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1344,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1345,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1346,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1347,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1348,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1349,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1351,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1352,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1353,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.ends\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1354,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1355,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1356,\"textContent\":\"Which shift(s) end at the same time as F?\"}]},{\"nodeType\":3,\"id\":1357,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1358,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1359,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1360,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1361,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1362,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1363,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1364,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1365,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1366,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1367,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1368,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1369,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1370,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1371,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1372,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1373,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1374,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1375,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1376,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1377,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1378,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1379,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1380,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1381,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1382,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1383,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1384,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1385,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1386,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1387,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1388,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1389,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1390,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1391,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1392,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1393,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1394,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1395,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1396,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1397,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1398,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1399,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1400,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1401,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1402,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1403,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1404,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1405,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1406,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1407,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1408,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1409,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1410,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1411,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1412,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1413,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1414,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1415,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1416,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1417,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1418,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1419,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1420,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1421,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1422,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1423,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1424,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1425,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1426,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1427,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1428,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1429,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1430,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1431,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1432,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1433,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1434,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1435,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1436,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1437,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1438,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1439,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1440,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1441,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1442,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1443,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1444,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1445,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1446,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1447,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1448,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1449,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1450,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1451,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1452,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1453,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1454,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1455,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1456,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1457,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1458,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1459,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1460,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1461,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1462,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1463,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1464,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1465,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1466,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1467,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1468,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1469,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1470,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1471,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1472,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1473,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1474,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1475,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1476,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1477,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1478,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1479,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1480,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1481,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1483,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1484,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1485,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1486,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1492,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1500,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1503,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1504,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1505,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1506,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1507,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1508,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1509,\"textContent\":\"Which shift(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":1510,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1511,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1512,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1513,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1514,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1515,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1516,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1517,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1518,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1519,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1520,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1521,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1522,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1523,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1524,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1525,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1526,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1527,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1528,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1529,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1530,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1531,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1532,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1533,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1534,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1535,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1536,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1537,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1538,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1539,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1540,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1541,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1542,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1543,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1544,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1545,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1546,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1547,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1548,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1549,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1550,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1551,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1552,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1553,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1554,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1555,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1556,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1557,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1558,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1559,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1560,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1561,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1562,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1563,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1564,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1565,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1566,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1567,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1568,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1569,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1570,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1571,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1572,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1573,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1574,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1575,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1576,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1577,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1578,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1579,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1580,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1581,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1582,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1583,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1584,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1585,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1586,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1587,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1588,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1589,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1590,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1591,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1592,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1593,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1594,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1595,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1596,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1597,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1598,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1599,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1600,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1601,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1602,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1603,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1604,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1605,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1606,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1607,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1608,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1609,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1610,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1612,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1613,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1614,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1615,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1617,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1618,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1619,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1620,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1621,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1622,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1623,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1624,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1625,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1627,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1628,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1629,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1630,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1631,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1632,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1633,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1634,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1635,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1636,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1637,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1638,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1639,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1640,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1641,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1642,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1643,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1644,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1645,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1646,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1647,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1648,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1649,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1650,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1651,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1652,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1653,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1654,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1655,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1656,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1657,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1659,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1660,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1661,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1662,\"textContent\":\"Which shift(s) start at the same time as F?\"}]},{\"nodeType\":3,\"id\":1663,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1664,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1665,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1666,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1667,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1668,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1669,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1670,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1671,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1672,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1673,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1674,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1675,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1676,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1677,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1678,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1679,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1680,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1681,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1682,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1683,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1684,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1686,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1687,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1688,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1689,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1690,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1691,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1692,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1693,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1694,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1695,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1696,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1697,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1698,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1699,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1700,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1701,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1702,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1703,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1704,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1705,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1706,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1707,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1708,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1709,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1710,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1711,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1712,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1713,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1714,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1715,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1716,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1717,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1718,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1720,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1721,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1722,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1723,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1724,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1725,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1726,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1727,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1728,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1729,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1730,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1731,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1732,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1733,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1734,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1735,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1736,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1737,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1738,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1739,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1741,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1742,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1743,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1744,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1746,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1747,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1748,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1749,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1750,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1751,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1752,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1753,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1754,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1755,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1756,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1757,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1758,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1759,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1760,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1761,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1762,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1763,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1764,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1765,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1766,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1767,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1768,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1769,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1770,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1771,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1772,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1773,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1774,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1775,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1776,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1777,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1778,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1779,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1780,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1781,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1782,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1783,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1784,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1785,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1786,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1787,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1788,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1789,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1790,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1791,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1792,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1793,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1794,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1795,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1796,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1797,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1798,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1799,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1800,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1801,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1802,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1803,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1804,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1805,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1806,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1807,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1808,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1809,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1810,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1812,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1813,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1814,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1815,\"textContent\":\"Which 2 shifts end when Z begins?\"}]},{\"nodeType\":3,\"id\":1816,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1817,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1818,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1819,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1820,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1821,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1822,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1823,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1824,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1825,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1826,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1827,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1828,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1829,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1830,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1831,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1832,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1833,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1834,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1835,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1836,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1837,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1838,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1839,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1840,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1841,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1842,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1843,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1844,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1845,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1846,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1847,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1848,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1849,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1850,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1851,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1852,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1853,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1854,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1855,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1856,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1857,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1858,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1859,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1860,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1861,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1862,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1863,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1864,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1865,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1866,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1867,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1868,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1869,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1870,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1871,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1872,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1873,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1874,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1875,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1876,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1877,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1878,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1879,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1880,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1881,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1882,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1883,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1884,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1885,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1886,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1887,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1888,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1889,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1890,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1891,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1892,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1894,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1895,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1896,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1897,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1899,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1900,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1901,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1902,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1903,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1904,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1905,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1906,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1907,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1908,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1909,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1910,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1911,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1912,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1913,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1914,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1915,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1916,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1917,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1918,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1919,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1920,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1921,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1922,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1923,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1924,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1925,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1926,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1927,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1928,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1929,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1930,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1931,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1932,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1933,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1934,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1935,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1936,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1937,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1938,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1939,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1940,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1941,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1942,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1943,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1944,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1945,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1946,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1947,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1948,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1949,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1950,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1951,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1952,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1953,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1954,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1955,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1956,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1957,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1958,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1959,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1960,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1961,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1962,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1963,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1965,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1966,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1967,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1968,\"textContent\":\"Which shift(s) end at 3pm?\"}]},{\"nodeType\":3,\"id\":1969,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1970,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1971,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1972,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1973,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1974,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1975,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1976,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1977,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1978,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1979,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1980,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1981,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1982,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1983,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1984,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1985,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1986,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1987,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1988,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1989,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1990,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1991,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1992,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1993,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1994,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1995,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1996,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1997,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1998,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1999,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2000,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2001,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2002,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2003,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2004,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2005,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2006,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2007,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2008,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2009,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2010,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2011,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2012,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2013,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2014,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2015,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2016,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2017,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2018,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2019,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2020,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2021,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2022,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2023,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2024,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2025,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2026,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2027,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2028,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2029,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2030,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2031,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2032,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2033,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2034,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2035,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2036,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2037,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2038,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2039,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2040,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2041,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2042,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2043,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2044,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2045,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2047,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2048,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2049,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2050,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2052,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2053,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2054,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2055,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2056,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2057,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2058,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2059,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2060,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2061,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2062,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2063,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2064,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2065,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2066,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2067,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2068,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2069,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2070,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2071,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2072,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2073,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2074,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2075,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2076,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2077,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2078,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2079,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2080,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2081,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2082,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2083,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2084,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2085,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2086,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2087,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2088,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2089,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2090,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2091,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2092,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2093,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2094,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2095,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2096,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2097,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2098,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2099,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2100,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2101,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2102,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2103,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2104,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2105,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2106,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2107,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2108,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2109,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2110,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2111,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2112,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2113,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2114,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2115,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2116,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2118,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":2119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2120,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2121,\"textContent\":\"Coffee breaks happen halfway through a shift. \"},{\"nodeType\":1,\"id\":2122,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":2123,\"textContent\":\"Which shifts share a break at 2pm?\"}]},{\"nodeType\":3,\"id\":2124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2125,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":2126,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2127,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2128,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2129,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2130,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2131,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":2132,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2133,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2134,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2135,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2136,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2137,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2138,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2139,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":2140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2141,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2142,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2143,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2144,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2145,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2146,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2147,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":2148,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2149,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2150,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2151,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2152,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2153,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2154,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2155,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2156,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2157,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2158,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2159,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2160,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2161,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2162,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2163,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2164,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2165,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2166,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2167,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2168,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2169,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2170,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2171,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2172,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2173,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2174,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2175,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2176,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2177,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2178,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2179,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2180,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2181,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2182,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2183,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2184,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2185,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2186,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2187,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2188,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2189,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2190,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2191,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2192,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2193,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2194,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2195,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2196,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2197,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2198,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2199,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2200,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2202,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2203,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2204,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2205,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2211,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2219,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2227,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2235,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2243,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2251,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2259,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2267,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2270,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2271,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2273,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\".strategy\",\"style\":\"display: block;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2274,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2275,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2276,\"textContent\":\"Please describe how to determine what event(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":2277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2278,\"tagName\":\"TEXTAREA\",\"attributes\":{\"id\":\"strategyAnswer\",\"rows\":\"5\",\"cols\":\"80\"}},{\"nodeType\":3,\"id\":2279,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2280,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2281,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2282},{\"nodeType\":3,\"id\":2283,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2284},{\"nodeType\":3,\"id\":2285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2286,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"fixbottom\"},\"childNodes\":[{\"nodeType\":3,\"id\":2287,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2288,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"testingButton\",\"style\":\"display:none;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2289,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2290,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2291,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"strategyButton\",\"style\":\"display: block;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2292,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2293,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2294,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2295,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2296},{\"nodeType\":3,\"id\":2297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2298,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"d3container\"},\"childNodes\":[{\"nodeType\":1,\"id\":2299,\"tagName\":\"svg\",\"attributes\":{\"width\":\"930\",\"height\":\"915\"},\"childNodes\":[{\"nodeType\":1,\"id\":2300,\"tagName\":\"g\",\"attributes\":{\"transform\":\"translate(100,25)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2301,\"tagName\":\"g\",\"attributes\":{\"class\":\"leaders\"}},{\"nodeType\":1,\"id\":2302,\"tagName\":\"g\",\"attributes\":{\"class\":\"static-scaffold\"}},{\"nodeType\":1,\"id\":2303,\"tagName\":\"g\",\"attributes\":{\"class\":\"xaxis\",\"transform\":\"translate(0,800)\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"middle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2304,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M0.5,6V0.5H800.5V6\"}},{\"nodeType\":1,\"id\":2305,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2306,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2307,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2308,\"textContent\":\"08 AM\"}]}]},{\"nodeType\":1,\"id\":2309,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(33.83333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2310,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2311,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2312,\"textContent\":\"08:30\"}]}]},{\"nodeType\":1,\"id\":2313,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(67.16666666666666,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2314,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2315,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2316,\"textContent\":\"09 AM\"}]}]},{\"nodeType\":1,\"id\":2317,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(100.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2318,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2319,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2320,\"textContent\":\"09:30\"}]}]},{\"nodeType\":1,\"id\":2321,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(133.83333333333331,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2322,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2323,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2324,\"textContent\":\"10 AM\"}]}]},{\"nodeType\":1,\"id\":2325,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(167.16666666666669,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2326,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2327,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2328,\"textContent\":\"10:30\"}]}]},{\"nodeType\":1,\"id\":2329,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(200.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2330,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2331,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2332,\"textContent\":\"11 AM\"}]}]},{\"nodeType\":1,\"id\":2333,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(233.83333333333334,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2334,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2335,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2336,\"textContent\":\"11:30\"}]}]},{\"nodeType\":1,\"id\":2337,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(267.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2338,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2339,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2340,\"textContent\":\"12 PM\"}]}]},{\"nodeType\":1,\"id\":2341,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(300.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2342,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2343,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2344,\"textContent\":\"12:30\"}]}]},{\"nodeType\":1,\"id\":2345,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(333.83333333333337,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2346,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2347,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2348,\"textContent\":\"01 PM\"}]}]},{\"nodeType\":1,\"id\":2349,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(367.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2350,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2351,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2352,\"textContent\":\"01:30\"}]}]},{\"nodeType\":1,\"id\":2353,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(400.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2354,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2355,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2356,\"textContent\":\"02 PM\"}]}]},{\"nodeType\":1,\"id\":2357,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(433.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2358,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2359,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2360,\"textContent\":\"02:30\"}]}]},{\"nodeType\":1,\"id\":2361,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(467.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2362,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2363,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2364,\"textContent\":\"03 PM\"}]}]},{\"nodeType\":1,\"id\":2365,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(500.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2366,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2367,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2368,\"textContent\":\"03:30\"}]}]},{\"nodeType\":1,\"id\":2369,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(533.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2370,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2371,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2372,\"textContent\":\"04 PM\"}]}]},{\"nodeType\":1,\"id\":2373,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(567.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2374,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2375,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2376,\"textContent\":\"04:30\"}]}]},{\"nodeType\":1,\"id\":2377,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(600.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2378,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2379,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2380,\"textContent\":\"05 PM\"}]}]},{\"nodeType\":1,\"id\":2381,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(633.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2382,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2383,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2384,\"textContent\":\"05:30\"}]}]},{\"nodeType\":1,\"id\":2385,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(667.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2386,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2387,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2388,\"textContent\":\"06 PM\"}]}]},{\"nodeType\":1,\"id\":2389,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(700.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2390,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2391,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2392,\"textContent\":\"06:30\"}]}]},{\"nodeType\":1,\"id\":2393,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(733.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2394,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2395,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2396,\"textContent\":\"07 PM\"}]}]},{\"nodeType\":1,\"id\":2397,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(767.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2398,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2399,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2400,\"textContent\":\"07:30\"}]}]},{\"nodeType\":1,\"id\":2401,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(800.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2402,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2403,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2404,\"textContent\":\"08 PM\"}]}]},{\"nodeType\":1,\"id\":2405,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2406,\"tagName\":\"text\",\"attributes\":{\"x\":\"533.3333333333334\",\"y\":\"80\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2407,\"textContent\":\"START & END TIME (time of day)\"}]}]}]},{\"nodeType\":1,\"id\":2408,\"tagName\":\"g\",\"attributes\":{\"class\":\"yaxis\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"end\"},\"childNodes\":[{\"nodeType\":1,\"id\":2409,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M-15,800.5H0.5V0.5H-15\"}},{\"nodeType\":1,\"id\":2410,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,800.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2411,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2412,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2413,\"textContent\":\"0\"}]}]},{\"nodeType\":1,\"id\":2414,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,733.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2415,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2416,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2417,\"textContent\":\"1\"}]}]},{\"nodeType\":1,\"id\":2418,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,667.1666666666667)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2419,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2420,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2421,\"textContent\":\"2\"}]}]},{\"nodeType\":1,\"id\":2422,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,600.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2423,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2424,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2425,\"textContent\":\"3\"}]}]},{\"nodeType\":1,\"id\":2426,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,533.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2427,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2428,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2429,\"textContent\":\"4\"}]}]},{\"nodeType\":1,\"id\":2430,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,467.16666666666663)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2431,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2432,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2433,\"textContent\":\"5\"}]}]},{\"nodeType\":1,\"id\":2434,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,400.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2435,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2436,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2437,\"textContent\":\"6\"}]}]},{\"nodeType\":1,\"id\":2438,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,333.8333333333333)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2439,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2440,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2441,\"textContent\":\"7\"}]}]},{\"nodeType\":1,\"id\":2442,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,267.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2443,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2444,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2445,\"textContent\":\"8\"}]}]},{\"nodeType\":1,\"id\":2446,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,200.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2447,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2448,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2449,\"textContent\":\"9\"}]}]},{\"nodeType\":1,\"id\":2450,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,133.83333333333326)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2451,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2452,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2453,\"textContent\":\"10\"}]}]},{\"nodeType\":1,\"id\":2454,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,67.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2455,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2456,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2457,\"textContent\":\"11\"}]}]},{\"nodeType\":1,\"id\":2458,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,0.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2459,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2460,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2461,\"textContent\":\"12\"}]}]},{\"nodeType\":1,\"id\":2462,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2463,\"tagName\":\"text\",\"attributes\":{\"transform\":\"rotate(-90)\",\"x\":\"-350\",\"y\":\"-60\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2464,\"textContent\":\"DURATION (in hours)\"}]}]}]},{\"nodeType\":1,\"id\":2465,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2466,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2467,\"tagName\":\"line\",\"attributes\":{\"x1\":\"13.333333333333329\",\"x2\":\"766.6666666666667\",\"y1\":\"733.3333333333334\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2468,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2469,\"tagName\":\"line\",\"attributes\":{\"x1\":\"46.66666666666666\",\"x2\":\"733.3333333333333\",\"y1\":\"666.6666666666667\",\"y2\":\"666.6666666666667\"}}]},{\"nodeType\":1,\"id\":2470,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2471,\"tagName\":\"line\",\"attributes\":{\"x1\":\"80\",\"x2\":\"700\",\"y1\":\"600\",\"y2\":\"600\"}}]},{\"nodeType\":1,\"id\":2472,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2473,\"tagName\":\"line\",\"attributes\":{\"x1\":\"113.33333333333331\",\"x2\":\"666.6666666666667\",\"y1\":\"533.3333333333334\",\"y2\":\"533.3333333333334\"}}]},{\"nodeType\":1,\"id\":2474,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2475,\"tagName\":\"line\",\"attributes\":{\"x1\":\"146.66666666666669\",\"x2\":\"633.3333333333333\",\"y1\":\"466.66666666666663\",\"y2\":\"466.66666666666663\"}}]},{\"nodeType\":1,\"id\":2476,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2477,\"tagName\":\"line\",\"attributes\":{\"x1\":\"180\",\"x2\":\"600\",\"y1\":\"400\",\"y2\":\"400\"}}]},{\"nodeType\":1,\"id\":2478,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2479,\"tagName\":\"line\",\"attributes\":{\"x1\":\"213.33333333333334\",\"x2\":\"566.6666666666667\",\"y1\":\"333.3333333333333\",\"y2\":\"333.3333333333333\"}}]},{\"nodeType\":1,\"id\":2480,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2481,\"tagName\":\"line\",\"attributes\":{\"x1\":\"246.66666666666663\",\"x2\":\"533.3333333333333\",\"y1\":\"266.66666666666674\",\"y2\":\"266.66666666666674\"}}]},{\"nodeType\":1,\"id\":2482,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2483,\"tagName\":\"line\",\"attributes\":{\"x1\":\"280\",\"x2\":\"500\",\"y1\":\"200\",\"y2\":\"200\"}}]},{\"nodeType\":1,\"id\":2484,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2485,\"tagName\":\"line\",\"attributes\":{\"x1\":\"313.33333333333337\",\"x2\":\"466.6666666666667\",\"y1\":\"133.33333333333326\",\"y2\":\"133.33333333333326\"}}]},{\"nodeType\":1,\"id\":2486,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2487,\"tagName\":\"line\",\"attributes\":{\"x1\":\"346.66666666666663\",\"x2\":\"433.3333333333333\",\"y1\":\"66.66666666666674\",\"y2\":\"66.66666666666674\"}}]},{\"nodeType\":1,\"id\":2488,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2489,\"tagName\":\"line\",\"attributes\":{\"x1\":\"380\",\"x2\":\"400\",\"y1\":\"0\",\"y2\":\"0\"}}]}]},{\"nodeType\":1,\"id\":2490,\"tagName\":\"g\",\"attributes\":{\"class\":\"xgrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2491,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"0\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2492,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"800\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2493,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"433.3333333333333\",\"y2\":\"66.66666666666674\"}},{\"nodeType\":1,\"id\":2494,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"366.66666666666663\",\"y2\":\"66.66666666666674\"}},{\"nodeType\":1,\"id\":2495,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"466.6666666666667\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2496,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"333.33333333333337\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2497,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"500\",\"y2\":\"200\"}},{\"nodeType\":1,\"id\":2498,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"300\",\"y2\":\"200\"}},{\"nodeType\":1,\"id\":2499,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"533.3333333333333\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2500,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"266.66666666666663\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2501,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"566.6666666666667\",\"y2\":\"333.3333333333333\"}},{\"nodeType\":1,\"id\":2502,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"233.33333333333334\",\"y2\":\"333.3333333333333\"}},{\"nodeType\":1,\"id\":2503,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"600\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2504,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"200\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2505,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"633.3333333333333\",\"y2\":\"466.66666666666663\"}},{\"nodeType\":1,\"id\":2506,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"166.66666666666669\",\"y2\":\"466.66666666666663\"}},{\"nodeType\":1,\"id\":2507,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"666.6666666666667\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2508,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"133.33333333333331\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2509,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"700\",\"y2\":\"600\"}},{\"nodeType\":1,\"id\":2510,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"100\",\"y2\":\"600\"}},{\"nodeType\":1,\"id\":2511,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"733.3333333333333\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2512,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"66.66666666666666\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2513,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"766.6666666666667\",\"y2\":\"733.3333333333334\"}},{\"nodeType\":1,\"id\":2514,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"33.33333333333333\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2515,\"tagName\":\"g\",\"attributes\":{\"class\":\"data\"},\"childNodes\":[{\"nodeType\":1,\"id\":2516,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2517,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"266.66666666666674\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2518,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"258.66666666666674\"},\"childNodes\":[{\"nodeType\":3,\"id\":2519,\"textContent\":\"A \"}]}]},{\"nodeType\":1,\"id\":2520,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2521,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2522,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2523,\"textContent\":\"B \"}]}]},{\"nodeType\":1,\"id\":2524,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2525,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"366.66666666666663\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2526,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"361.66666666666663\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2527,\"textContent\":\"C \"}]}]},{\"nodeType\":1,\"id\":2528,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2529,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"666.6666666666667\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2530,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"661.6666666666667\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2531,\"textContent\":\"D \"}]}]},{\"nodeType\":1,\"id\":2532,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2533,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"200\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2534,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"195\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2535,\"textContent\":\"E \"}]}]},{\"nodeType\":1,\"id\":2536,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2537,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2538,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2539,\"textContent\":\"F \"}]}]},{\"nodeType\":1,\"id\":2540,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2541,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2542,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2543,\"textContent\":\"G \"}]}]},{\"nodeType\":1,\"id\":2544,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2545,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2546,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2547,\"textContent\":\"H \"}]}]},{\"nodeType\":1,\"id\":2548,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2549,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"100\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2550,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"95\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2551,\"textContent\":\"I \"}]}]},{\"nodeType\":1,\"id\":2552,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2553,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"133.33333333333331\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2554,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"128.33333333333331\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2555,\"textContent\":\"J \"}]}]},{\"nodeType\":1,\"id\":2556,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2557,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"133.33333333333326\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2558,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"125.33333333333326\"},\"childNodes\":[{\"nodeType\":3,\"id\":2559,\"textContent\":\"K \"}]}]},{\"nodeType\":1,\"id\":2560,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2561,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"333.3333333333333\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2562,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"325.3333333333333\"},\"childNodes\":[{\"nodeType\":3,\"id\":2563,\"textContent\":\"L \"}]}]},{\"nodeType\":1,\"id\":2564,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2565,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"300\",\"cy\":\"733.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2566,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"295\",\"y\":\"725.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2567,\"textContent\":\"M \"}]}]},{\"nodeType\":1,\"id\":2568,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2569,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"600\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2570,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"595\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2571,\"textContent\":\"N \"}]}]},{\"nodeType\":1,\"id\":2572,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2573,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"433.3333333333333\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2574,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"428.3333333333333\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2575,\"textContent\":\"O \"}]}]},{\"nodeType\":1,\"id\":2576,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2577,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"200\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2578,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"192\"},\"childNodes\":[{\"nodeType\":3,\"id\":2579,\"textContent\":\"P \"}]}]},{\"nodeType\":1,\"id\":2580,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2581,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"533.3333333333333\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2582,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"528.3333333333333\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2583,\"textContent\":\"Z \"}]}]},{\"nodeType\":1,\"id\":2584,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2585,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2586,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2587,\"textContent\":\"X \"}]}]}]}]}]}]},{\"nodeType\":3,\"id\":2588,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2589,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2590},{\"nodeType\":3,\"id\":2591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2592,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2593,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2594,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2595,\"textContent\":\" \"}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 204, dom: 689, initialDom: 777",
  "javascriptErrors": []
}