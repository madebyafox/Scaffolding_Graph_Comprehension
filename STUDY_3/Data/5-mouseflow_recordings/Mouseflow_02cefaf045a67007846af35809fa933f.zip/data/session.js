var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "02cefaf045a67007846af35809fa933f",
  "created": "2018-05-18T11:15:15.870824-07:00",
  "lastActivity": "2018-05-18T11:16:48.059824-07:00",
  "pageViews": [
    {
      "id": "051816297ad3a622d9a76c3485cb8794baeb02a5",
      "startTime": "2018-05-18T11:15:15.870824-07:00",
      "endTime": "2018-05-18T11:16:48.059824-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/5",
      "visitTime": 92189,
      "engagementTime": 49587,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 92189,
  "engagementTime": 49587,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.39",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=OY8PV",
    "CONDITION=113",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "9e19c5e2e57116b2b8598b0a2fbd4eb8",
  "gdpr": false
}