var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "d2d4645572347b78312abdabf1b53c41",
  "created": "2018-05-21T12:07:29.0164431-07:00",
  "lastActivity": "2018-05-21T12:10:52.2974431-07:00",
  "pageViews": [
    {
      "id": "05212921ccd90865eca8b044f8afc5ee18365087",
      "startTime": "2018-05-21T12:07:29.0164431-07:00",
      "endTime": "2018-05-21T12:10:52.2974431-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/",
      "visitTime": 203281,
      "engagementTime": 138619,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 203281,
  "engagementTime": 138619,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.28",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "d207dd96abb0aeb6a0a6fb08cfcb8894",
  "gdpr": false
}