var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "420b55355fba25725cd636f07ce2e260",
  "created": "2018-05-25T09:06:55.4183205-07:00",
  "lastActivity": "2018-05-25T09:08:59.0212815-07:00",
  "pageViews": [
    {
      "id": "05255555426af560a1cd2e0e7a144c0c2a88e42b",
      "startTime": "2018-05-25T09:06:55.4183205-07:00",
      "endTime": "2018-05-25T09:08:59.0212815-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/",
      "visitTime": 123788,
      "engagementTime": 43910,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 123788,
  "engagementTime": 43910,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.26",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "43e7e1e39aff78571630cc56b5c8a79c",
  "gdpr": false
}