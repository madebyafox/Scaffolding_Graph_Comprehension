var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["06040099d7cb49bd68fde93aed576ccc25010381"] = {
  "startTime": "2018-06-04T19:19:00.3623733Z",
  "websitePageUrl": "/16",
  "visitTime": 66075,
  "engagementTime": 65893,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1200,
  "tags": [
    "form-interact",
    "submit"
  ],
  "session": {
    "id": "5003a373911b77a05574f36971e81c56",
    "created": "2018-06-04T19:19:00.3340122+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.181",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/16",
    "tags": [
      "form-interact",
      "submit"
    ],
    "variables": [
      "SID=S6D2F",
      "CONDITION=311"
    ],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "fb401899fbed6712275626215aad3760",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/5003a373911b77a05574f36971e81c56/play"
  },
  "events": [
    {
      "t": 2,
      "e": 2,
      "ty": 14,
      "x": 0,
      "y": 1199
    },
    {
      "t": 102,
      "e": 102,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 102,
      "e": 102,
      "ty": 1,
      "x": 0,
      "y": 16
    },
    {
      "t": 671,
      "e": 671,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 1201,
      "e": 1201,
      "ty": 2,
      "x": 493,
      "y": 730
    },
    {
      "t": 1252,
      "e": 1252,
      "ty": 41,
      "x": 43154,
      "y": 39221,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 1273,
      "e": 1273,
      "ty": 6,
      "x": 450,
      "y": 665,
      "ta": "#strategyButton"
    },
    {
      "t": 1290,
      "e": 1290,
      "ty": 7,
      "x": 428,
      "y": 639,
      "ta": "#strategyButton"
    },
    {
      "t": 1301,
      "e": 1301,
      "ty": 2,
      "x": 428,
      "y": 639
    },
    {
      "t": 1323,
      "e": 1323,
      "ty": 6,
      "x": 404,
      "y": 594,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1402,
      "e": 1402,
      "ty": 2,
      "x": 391,
      "y": 565
    },
    {
      "t": 1501,
      "e": 1501,
      "ty": 2,
      "x": 389,
      "y": 561
    },
    {
      "t": 1501,
      "e": 1501,
      "ty": 41,
      "x": 32813,
      "y": 30959,
      "ta": "#strategyAnswer"
    },
    {
      "t": 4683,
      "e": 4683,
      "ty": 7,
      "x": 523,
      "y": 627,
      "ta": "#strategyAnswer"
    },
    {
      "t": 4700,
      "e": 4700,
      "ty": 2,
      "x": 733,
      "y": 721
    },
    {
      "t": 4752,
      "e": 4752,
      "ty": 41,
      "x": 46368,
      "y": 55651,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 4802,
      "e": 4802,
      "ty": 2,
      "x": 1874,
      "y": 1018
    },
    {
      "t": 4901,
      "e": 4901,
      "ty": 2,
      "x": 1850,
      "y": 1019
    },
    {
      "t": 5001,
      "e": 5001,
      "ty": 2,
      "x": 1541,
      "y": 996
    },
    {
      "t": 5002,
      "e": 5002,
      "ty": 41,
      "x": 53204,
      "y": 61452,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 5102,
      "e": 5102,
      "ty": 2,
      "x": 1168,
      "y": 955
    },
    {
      "t": 5202,
      "e": 5202,
      "ty": 2,
      "x": 1109,
      "y": 955
    },
    {
      "t": 5252,
      "e": 5252,
      "ty": 41,
      "x": 22621,
      "y": 58515,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 5302,
      "e": 5302,
      "ty": 2,
      "x": 1107,
      "y": 955
    },
    {
      "t": 5400,
      "e": 5400,
      "ty": 2,
      "x": 1171,
      "y": 949
    },
    {
      "t": 5502,
      "e": 5502,
      "ty": 2,
      "x": 1212,
      "y": 949
    },
    {
      "t": 5502,
      "e": 5502,
      "ty": 41,
      "x": 62657,
      "y": 62782,
      "ta": "> div.stimulus > div:[2] > svg > g > g:[6] > line:[16]"
    },
    {
      "t": 5602,
      "e": 5602,
      "ty": 2,
      "x": 1181,
      "y": 946
    },
    {
      "t": 5701,
      "e": 5701,
      "ty": 2,
      "x": 1139,
      "y": 946
    },
    {
      "t": 5751,
      "e": 5751,
      "ty": 41,
      "x": 24876,
      "y": 57871,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 5901,
      "e": 5901,
      "ty": 2,
      "x": 1138,
      "y": 943
    },
    {
      "t": 6000,
      "e": 6000,
      "ty": 2,
      "x": 1124,
      "y": 921
    },
    {
      "t": 6001,
      "e": 6001,
      "ty": 41,
      "x": 23819,
      "y": 56080,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 6102,
      "e": 6102,
      "ty": 2,
      "x": 1142,
      "y": 877
    },
    {
      "t": 6200,
      "e": 6200,
      "ty": 2,
      "x": 1175,
      "y": 783
    },
    {
      "t": 6251,
      "e": 6251,
      "ty": 41,
      "x": 27624,
      "y": 45194,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 6300,
      "e": 6300,
      "ty": 2,
      "x": 1178,
      "y": 764
    },
    {
      "t": 6401,
      "e": 6401,
      "ty": 2,
      "x": 1171,
      "y": 729
    },
    {
      "t": 6501,
      "e": 6501,
      "ty": 2,
      "x": 1165,
      "y": 704
    },
    {
      "t": 6501,
      "e": 6501,
      "ty": 41,
      "x": 26708,
      "y": 40538,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 6601,
      "e": 6601,
      "ty": 2,
      "x": 1162,
      "y": 698
    },
    {
      "t": 6700,
      "e": 6700,
      "ty": 2,
      "x": 1159,
      "y": 685
    },
    {
      "t": 6751,
      "e": 6751,
      "ty": 41,
      "x": 26215,
      "y": 38962,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 6801,
      "e": 6801,
      "ty": 2,
      "x": 1158,
      "y": 682
    },
    {
      "t": 7201,
      "e": 7201,
      "ty": 2,
      "x": 1130,
      "y": 689
    },
    {
      "t": 7251,
      "e": 7251,
      "ty": 41,
      "x": 3524,
      "y": 42544,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 7301,
      "e": 7301,
      "ty": 2,
      "x": 497,
      "y": 729
    },
    {
      "t": 7400,
      "e": 7400,
      "ty": 2,
      "x": 64,
      "y": 701
    },
    {
      "t": 7501,
      "e": 7501,
      "ty": 2,
      "x": 61,
      "y": 701
    },
    {
      "t": 7501,
      "e": 7501,
      "ty": 41,
      "x": 1825,
      "y": 38390,
      "ta": "> div.stimulus"
    },
    {
      "t": 7801,
      "e": 7801,
      "ty": 2,
      "x": 72,
      "y": 695
    },
    {
      "t": 7901,
      "e": 7901,
      "ty": 2,
      "x": 158,
      "y": 640
    },
    {
      "t": 7964,
      "e": 7964,
      "ty": 6,
      "x": 189,
      "y": 603,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8000,
      "e": 8000,
      "ty": 2,
      "x": 192,
      "y": 595
    },
    {
      "t": 8000,
      "e": 8000,
      "ty": 41,
      "x": 10668,
      "y": 58468,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8100,
      "e": 8100,
      "ty": 2,
      "x": 199,
      "y": 572
    },
    {
      "t": 8201,
      "e": 8201,
      "ty": 2,
      "x": 200,
      "y": 568
    },
    {
      "t": 8251,
      "e": 8251,
      "ty": 41,
      "x": 11567,
      "y": 36623,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8281,
      "e": 8281,
      "ty": 3,
      "x": 200,
      "y": 568,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8282,
      "e": 8282,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8391,
      "e": 8391,
      "ty": 4,
      "x": 11567,
      "y": 36623,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8391,
      "e": 8391,
      "ty": 5,
      "x": 200,
      "y": 568,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8700,
      "e": 8700,
      "ty": 2,
      "x": 201,
      "y": 567
    },
    {
      "t": 8751,
      "e": 8751,
      "ty": 41,
      "x": 11680,
      "y": 35814,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9236,
      "e": 9236,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 9340,
      "e": 9340,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "66"
    },
    {
      "t": 9341,
      "e": 9341,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9411,
      "e": 9411,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "B"
    },
    {
      "t": 9427,
      "e": 9427,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "B"
    },
    {
      "t": 9491,
      "e": 9491,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 9491,
      "e": 9491,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9563,
      "e": 9563,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "By"
    },
    {
      "t": 9660,
      "e": 9660,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 9661,
      "e": 9661,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9739,
      "e": 9739,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "By "
    },
    {
      "t": 9884,
      "e": 9884,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 9884,
      "e": 9884,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9963,
      "e": 9963,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "By l"
    },
    {
      "t": 10000,
      "e": 10000,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 10067,
      "e": 10067,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 10067,
      "e": 10067,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10123,
      "e": 10123,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 10220,
      "e": 10220,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 10221,
      "e": 10221,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10332,
      "e": 10332,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 10388,
      "e": 10388,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "75"
    },
    {
      "t": 10388,
      "e": 10388,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10508,
      "e": 10508,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||k"
    },
    {
      "t": 10555,
      "e": 10555,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 10555,
      "e": 10555,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10684,
      "e": 10684,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 10764,
      "e": 10764,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 10765,
      "e": 10765,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10867,
      "e": 10867,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 10875,
      "e": 10875,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 10875,
      "e": 10875,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10964,
      "e": 10964,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 11028,
      "e": 11028,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 11029,
      "e": 11029,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11131,
      "e": 11131,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 11324,
      "e": 11324,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 11324,
      "e": 11324,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11483,
      "e": 11483,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 12027,
      "e": 12027,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 12028,
      "e": 12028,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12099,
      "e": 12099,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 12171,
      "e": 12171,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 12171,
      "e": 12171,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12260,
      "e": 12260,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 12267,
      "e": 12267,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 12268,
      "e": 12268,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12339,
      "e": 12339,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 12371,
      "e": 12371,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 12371,
      "e": 12371,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12436,
      "e": 12436,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 12492,
      "e": 12492,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 12492,
      "e": 12492,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12556,
      "e": 12556,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 12605,
      "e": 12605,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 12606,
      "e": 12606,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12707,
      "e": 12707,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 12859,
      "e": 12859,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 12860,
      "e": 12860,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12955,
      "e": 12955,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||x"
    },
    {
      "t": 13259,
      "e": 13259,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "189"
    },
    {
      "t": 13261,
      "e": 13261,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13347,
      "e": 13347,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||-"
    },
    {
      "t": 13395,
      "e": 13395,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 13396,
      "e": 13396,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13508,
      "e": 13508,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 13700,
      "e": 13700,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 13701,
      "e": 13701,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13803,
      "e": 13803,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "By looking at the x-ax"
    },
    {
      "t": 13803,
      "e": 13803,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||x"
    },
    {
      "t": 13891,
      "e": 13891,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 13892,
      "e": 13892,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13963,
      "e": 13963,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 14003,
      "e": 14003,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 14004,
      "e": 14004,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14084,
      "e": 14084,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 14140,
      "e": 14140,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 14140,
      "e": 14140,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14197,
      "e": 14197,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 14772,
      "e": 14772,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 14773,
      "e": 14773,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14875,
      "e": 14875,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||w"
    },
    {
      "t": 14899,
      "e": 14899,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 14899,
      "e": 14899,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14979,
      "e": 14979,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 15027,
      "e": 15027,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 15029,
      "e": 15029,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15107,
      "e": 15107,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 15147,
      "e": 15147,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 15148,
      "e": 15148,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15259,
      "e": 15259,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 15284,
      "e": 15284,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 15284,
      "e": 15284,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15355,
      "e": 15355,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 15419,
      "e": 15419,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 15420,
      "e": 15420,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15492,
      "e": 15492,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 15604,
      "e": 15604,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "By looking at the x-axis where "
    },
    {
      "t": 16171,
      "e": 16171,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 16172,
      "e": 16172,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16307,
      "e": 16307,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||1"
    },
    {
      "t": 16323,
      "e": 16323,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 16324,
      "e": 16324,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16411,
      "e": 16411,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||2"
    },
    {
      "t": 16652,
      "e": 16652,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 16652,
      "e": 16652,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16763,
      "e": 16763,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 16868,
      "e": 16868,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 16869,
      "e": 16869,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16923,
      "e": 16923,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 17052,
      "e": 17052,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 17052,
      "e": 17052,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17123,
      "e": 17123,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 18636,
      "e": 18636,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 18638,
      "e": 18638,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18755,
      "e": 18755,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 18971,
      "e": 18971,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 18973,
      "e": 18973,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19092,
      "e": 19092,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 19867,
      "e": 19867,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 19955,
      "e": 19955,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "By looking at the x-axis where 12pm l"
    },
    {
      "t": 20001,
      "e": 20001,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 20051,
      "e": 20051,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 20131,
      "e": 20131,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "By looking at the x-axis where 12pm "
    },
    {
      "t": 20644,
      "e": 20644,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 20645,
      "e": 20645,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20731,
      "e": 20731,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 20739,
      "e": 20739,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 20739,
      "e": 20739,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20811,
      "e": 20811,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 20859,
      "e": 20859,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 20860,
      "e": 20860,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20922,
      "e": 20922,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 21003,
      "e": 21003,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 21003,
      "e": 21003,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21123,
      "e": 21123,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 21124,
      "e": 21124,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21132,
      "e": 21132,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||la"
    },
    {
      "t": 21203,
      "e": 21203,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 21251,
      "e": 21251,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "66"
    },
    {
      "t": 21251,
      "e": 21251,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21323,
      "e": 21323,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||b"
    },
    {
      "t": 21372,
      "e": 21372,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 21372,
      "e": 21372,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21451,
      "e": 21451,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 21508,
      "e": 21508,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 21508,
      "e": 21508,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21619,
      "e": 21619,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 21621,
      "e": 21621,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21627,
      "e": 21627,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||le"
    },
    {
      "t": 21675,
      "e": 21675,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 21747,
      "e": 21747,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 21747,
      "e": 21747,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21859,
      "e": 21859,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 21883,
      "e": 21883,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 21884,
      "e": 21884,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21971,
      "e": 21971,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 22043,
      "e": 22043,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 22043,
      "e": 22043,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22083,
      "e": 22083,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 22148,
      "e": 22148,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 22148,
      "e": 22148,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22212,
      "e": 22212,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 22244,
      "e": 22244,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 22245,
      "e": 22245,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22314,
      "e": 22314,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 22347,
      "e": 22347,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 22347,
      "e": 22347,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22419,
      "e": 22419,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 22524,
      "e": 22524,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 22525,
      "e": 22525,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22594,
      "e": 22594,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 23205,
      "e": 23205,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 23205,
      "e": 23205,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23267,
      "e": 23267,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 23307,
      "e": 23307,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 23307,
      "e": 23307,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23379,
      "e": 23379,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 23492,
      "e": 23492,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 23493,
      "e": 23493,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23547,
      "e": 23547,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 23643,
      "e": 23643,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 23643,
      "e": 23643,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23708,
      "e": 23708,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 23708,
      "e": 23708,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 23709,
      "e": 23709,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23779,
      "e": 23779,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 23819,
      "e": 23819,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 23820,
      "e": 23820,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23875,
      "e": 23875,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 23987,
      "e": 23987,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 23988,
      "e": 23988,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24043,
      "e": 24043,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||u"
    },
    {
      "t": 24220,
      "e": 24220,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 24220,
      "e": 24220,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24323,
      "e": 24323,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 24444,
      "e": 24444,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 24444,
      "e": 24444,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24532,
      "e": 24532,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||w"
    },
    {
      "t": 24652,
      "e": 24652,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 24653,
      "e": 24653,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24755,
      "e": 24755,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 24883,
      "e": 24883,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 24883,
      "e": 24883,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24971,
      "e": 24971,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 25099,
      "e": 25099,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 25100,
      "e": 25100,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25172,
      "e": 25172,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 25476,
      "e": 25476,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 25476,
      "e": 25476,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25539,
      "e": 25539,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 25579,
      "e": 25579,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 25579,
      "e": 25579,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25651,
      "e": 25651,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 25675,
      "e": 25675,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 25675,
      "e": 25675,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25739,
      "e": 25739,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 25851,
      "e": 25851,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 25853,
      "e": 25853,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25930,
      "e": 25930,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 26020,
      "e": 26020,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 26020,
      "e": 26020,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26099,
      "e": 26099,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 26204,
      "e": 26204,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "By looking at the x-axis where 12pm is labeled then going upward to s"
    },
    {
      "t": 26252,
      "e": 26252,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 26252,
      "e": 26252,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26306,
      "e": 26306,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 26427,
      "e": 26427,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 26427,
      "e": 26427,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26475,
      "e": 26475,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 26515,
      "e": 26515,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 26516,
      "e": 26516,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26627,
      "e": 26627,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 26667,
      "e": 26667,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 26667,
      "e": 26667,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26715,
      "e": 26715,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||w"
    },
    {
      "t": 26811,
      "e": 26811,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 26813,
      "e": 26813,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26883,
      "e": 26883,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 26964,
      "e": 26884,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 26964,
      "e": 26884,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27058,
      "e": 26978,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 27131,
      "e": 27051,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 27131,
      "e": 27051,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27219,
      "e": 27139,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 27347,
      "e": 27267,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 27348,
      "e": 27268,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27418,
      "e": 27338,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 27612,
      "e": 27532,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 27612,
      "e": 27532,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27619,
      "e": 27539,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 27619,
      "e": 27539,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27650,
      "e": 27570,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ol"
    },
    {
      "t": 27667,
      "e": 27587,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 27803,
      "e": 27723,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "By looking at the x-axis where 12pm is labeled then going upward to see what ol"
    },
    {
      "t": 28323,
      "e": 28243,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 28405,
      "e": 28325,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "By looking at the x-axis where 12pm is labeled then going upward to see what o"
    },
    {
      "t": 28595,
      "e": 28515,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 28675,
      "e": 28595,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "By looking at the x-axis where 12pm is labeled then going upward to see what "
    },
    {
      "t": 29444,
      "e": 29364,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 29445,
      "e": 29365,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29506,
      "e": 29426,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 29755,
      "e": 29675,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 29755,
      "e": 29675,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29827,
      "e": 29747,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 29948,
      "e": 29868,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 29948,
      "e": 29868,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30026,
      "e": 29946,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 30099,
      "e": 30019,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 30099,
      "e": 30019,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30171,
      "e": 30091,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 30172,
      "e": 30092,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30195,
      "e": 30115,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||nt"
    },
    {
      "t": 30243,
      "e": 30163,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 30404,
      "e": 30324,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 30405,
      "e": 30325,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30499,
      "e": 30419,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 30578,
      "e": 30498,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 30580,
      "e": 30500,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30650,
      "e": 30570,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 30659,
      "e": 30579,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 30659,
      "e": 30579,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30715,
      "e": 30635,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 30820,
      "e": 30740,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 30823,
      "e": 30743,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30898,
      "e": 30818,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 30947,
      "e": 30867,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 30947,
      "e": 30867,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31027,
      "e": 30947,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 31059,
      "e": 30979,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 31060,
      "e": 30980,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31132,
      "e": 31052,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 31243,
      "e": 31163,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 31244,
      "e": 31164,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31339,
      "e": 31259,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 31379,
      "e": 31299,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 31379,
      "e": 31299,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31475,
      "e": 31395,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 31548,
      "e": 31468,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 31550,
      "e": 31470,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31659,
      "e": 31579,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 31675,
      "e": 31595,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 31675,
      "e": 31595,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31739,
      "e": 31659,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 31860,
      "e": 31780,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 31860,
      "e": 31780,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31907,
      "e": 31827,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 32011,
      "e": 31931,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 32011,
      "e": 31931,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32091,
      "e": 32011,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 32203,
      "e": 32123,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "By looking at the x-axis where 12pm is labeled then going upward to see what points are plotte"
    },
    {
      "t": 32252,
      "e": 32172,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 32252,
      "e": 32172,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32323,
      "e": 32243,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 32866,
      "e": 32786,
      "ty": 7,
      "x": 229,
      "y": 609,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32901,
      "e": 32821,
      "ty": 2,
      "x": 278,
      "y": 643
    },
    {
      "t": 33002,
      "e": 32922,
      "ty": 2,
      "x": 317,
      "y": 643
    },
    {
      "t": 33002,
      "e": 32922,
      "ty": 41,
      "x": 24719,
      "y": 35177,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 33101,
      "e": 33021,
      "ty": 2,
      "x": 341,
      "y": 633
    },
    {
      "t": 33201,
      "e": 33121,
      "ty": 2,
      "x": 370,
      "y": 645
    },
    {
      "t": 33217,
      "e": 33137,
      "ty": 6,
      "x": 383,
      "y": 658,
      "ta": "#strategyButton"
    },
    {
      "t": 33251,
      "e": 33171,
      "ty": 41,
      "x": 32989,
      "y": 42916,
      "ta": "#strategyButton"
    },
    {
      "t": 33302,
      "e": 33222,
      "ty": 2,
      "x": 401,
      "y": 680
    },
    {
      "t": 33448,
      "e": 33368,
      "ty": 3,
      "x": 401,
      "y": 680,
      "ta": "#strategyButton"
    },
    {
      "t": 33450,
      "e": 33368,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "By looking at the x-axis where 12pm is labeled then going upward to see what points are plotted"
    },
    {
      "t": 33453,
      "e": 33371,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33453,
      "e": 33371,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 33502,
      "e": 33420,
      "ty": 41,
      "x": 34081,
      "y": 48699,
      "ta": "#strategyButton"
    },
    {
      "t": 33558,
      "e": 33476,
      "ty": 4,
      "x": 34081,
      "y": 48699,
      "ta": "#strategyButton"
    },
    {
      "t": 33569,
      "e": 33487,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 33571,
      "e": 33489,
      "ty": 5,
      "x": 401,
      "y": 680,
      "ta": "#strategyButton"
    },
    {
      "t": 33574,
      "e": 33492,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 34001,
      "e": 33919,
      "ty": 2,
      "x": 402,
      "y": 680
    },
    {
      "t": 34002,
      "e": 33920,
      "ty": 41,
      "x": 13568,
      "y": 37226,
      "ta": "html > body"
    },
    {
      "t": 34578,
      "e": 34496,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 35201,
      "e": 35119,
      "ty": 2,
      "x": 444,
      "y": 657
    },
    {
      "t": 35251,
      "e": 35169,
      "ty": 41,
      "x": 16977,
      "y": 34401,
      "ta": "html > body"
    },
    {
      "t": 35301,
      "e": 35219,
      "ty": 2,
      "x": 665,
      "y": 554
    },
    {
      "t": 35402,
      "e": 35320,
      "ty": 2,
      "x": 800,
      "y": 497
    },
    {
      "t": 35502,
      "e": 35420,
      "ty": 41,
      "x": 29823,
      "y": 26646,
      "ta": "html > body"
    },
    {
      "t": 35502,
      "e": 35420,
      "ty": 2,
      "x": 874,
      "y": 489
    },
    {
      "t": 35601,
      "e": 35519,
      "ty": 2,
      "x": 906,
      "y": 540
    },
    {
      "t": 35619,
      "e": 35537,
      "ty": 6,
      "x": 906,
      "y": 560,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 35700,
      "e": 35618,
      "ty": 2,
      "x": 907,
      "y": 568
    },
    {
      "t": 35751,
      "e": 35669,
      "ty": 41,
      "x": 21412,
      "y": 43690,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 35791,
      "e": 35709,
      "ty": 3,
      "x": 907,
      "y": 568,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 35792,
      "e": 35710,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 35870,
      "e": 35788,
      "ty": 4,
      "x": 21412,
      "y": 43690,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 35870,
      "e": 35788,
      "ty": 5,
      "x": 907,
      "y": 568,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 36002,
      "e": 35920,
      "ty": 2,
      "x": 905,
      "y": 568
    },
    {
      "t": 36002,
      "e": 35920,
      "ty": 41,
      "x": 20979,
      "y": 43690,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 36748,
      "e": 36666,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "49"
    },
    {
      "t": 36748,
      "e": 36666,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 36850,
      "e": 36768,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "1"
    },
    {
      "t": 36939,
      "e": 36857,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "56"
    },
    {
      "t": 36939,
      "e": 36857,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 36996,
      "e": 36914,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "18"
    },
    {
      "t": 37587,
      "e": 37505,
      "ty": 7,
      "x": 900,
      "y": 581,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 37601,
      "e": 37519,
      "ty": 2,
      "x": 900,
      "y": 581
    },
    {
      "t": 37637,
      "e": 37555,
      "ty": 6,
      "x": 867,
      "y": 661,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 37652,
      "e": 37570,
      "ty": 7,
      "x": 866,
      "y": 672,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 37701,
      "e": 37619,
      "ty": 2,
      "x": 864,
      "y": 676
    },
    {
      "t": 37751,
      "e": 37669,
      "ty": 41,
      "x": 29444,
      "y": 37060,
      "ta": "html > body"
    },
    {
      "t": 37800,
      "e": 37718,
      "ty": 2,
      "x": 860,
      "y": 677
    },
    {
      "t": 37900,
      "e": 37818,
      "ty": 2,
      "x": 844,
      "y": 668
    },
    {
      "t": 37905,
      "e": 37823,
      "ty": 6,
      "x": 837,
      "y": 663,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 38001,
      "e": 37919,
      "ty": 2,
      "x": 831,
      "y": 656
    },
    {
      "t": 38001,
      "e": 37919,
      "ty": 41,
      "x": 4974,
      "y": 28086,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 38072,
      "e": 37990,
      "ty": 3,
      "x": 831,
      "y": 656,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 38073,
      "e": 37991,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "18"
    },
    {
      "t": 38073,
      "e": 37991,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 38074,
      "e": 37992,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 38198,
      "e": 38116,
      "ty": 4,
      "x": 4974,
      "y": 28086,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 38199,
      "e": 38117,
      "ty": 5,
      "x": 831,
      "y": 656,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 38947,
      "e": 38865,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 39448,
      "e": 39366,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 39480,
      "e": 39398,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 39512,
      "e": 39430,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 39546,
      "e": 39464,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 39579,
      "e": 39497,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 39612,
      "e": 39530,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 39644,
      "e": 39562,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 39677,
      "e": 39595,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 39710,
      "e": 39628,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 39743,
      "e": 39661,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 39776,
      "e": 39694,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 39810,
      "e": 39728,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 39843,
      "e": 39761,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 39876,
      "e": 39794,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 39908,
      "e": 39826,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 39942,
      "e": 39860,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 39947,
      "e": 39865,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": ""
    },
    {
      "t": 40000,
      "e": 39918,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 40156,
      "e": 40074,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 40387,
      "e": 40305,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "85"
    },
    {
      "t": 40388,
      "e": 40306,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 40466,
      "e": 40384,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "U"
    },
    {
      "t": 41147,
      "e": 41065,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "U"
    },
    {
      "t": 41444,
      "e": 41362,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "8"
    },
    {
      "t": 41578,
      "e": 41496,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": ""
    },
    {
      "t": 41586,
      "e": 41504,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 41795,
      "e": 41713,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "65"
    },
    {
      "t": 41796,
      "e": 41714,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 41826,
      "e": 41744,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "A"
    },
    {
      "t": 41906,
      "e": 41824,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "A"
    },
    {
      "t": 42491,
      "e": 42409,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "77"
    },
    {
      "t": 42492,
      "e": 42410,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 42601,
      "e": 42519,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Am"
    },
    {
      "t": 42627,
      "e": 42545,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Am"
    },
    {
      "t": 42635,
      "e": 42553,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "69"
    },
    {
      "t": 42635,
      "e": 42553,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 42706,
      "e": 42624,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Ame"
    },
    {
      "t": 42739,
      "e": 42657,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "82"
    },
    {
      "t": 42739,
      "e": 42657,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 42827,
      "e": 42745,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Amer"
    },
    {
      "t": 42851,
      "e": 42769,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "73"
    },
    {
      "t": 42851,
      "e": 42769,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 42947,
      "e": 42865,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||i"
    },
    {
      "t": 42987,
      "e": 42905,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "67"
    },
    {
      "t": 42989,
      "e": 42907,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 43099,
      "e": 43017,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||c"
    },
    {
      "t": 43219,
      "e": 43137,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "65"
    },
    {
      "t": 43220,
      "e": 43138,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 43291,
      "e": 43209,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||a"
    },
    {
      "t": 43401,
      "e": 43319,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "America"
    },
    {
      "t": 43574,
      "e": 43492,
      "ty": 7,
      "x": 857,
      "y": 644,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 43601,
      "e": 43519,
      "ty": 2,
      "x": 951,
      "y": 630
    },
    {
      "t": 43700,
      "e": 43618,
      "ty": 2,
      "x": 1045,
      "y": 637
    },
    {
      "t": 43751,
      "e": 43669,
      "ty": 41,
      "x": 52557,
      "y": 38757,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 43792,
      "e": 43710,
      "ty": 6,
      "x": 1048,
      "y": 654,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 43801,
      "e": 43719,
      "ty": 2,
      "x": 1048,
      "y": 654
    },
    {
      "t": 43808,
      "e": 43726,
      "ty": 7,
      "x": 1037,
      "y": 685,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 43901,
      "e": 43819,
      "ty": 2,
      "x": 1003,
      "y": 745
    },
    {
      "t": 44001,
      "e": 43919,
      "ty": 2,
      "x": 999,
      "y": 722
    },
    {
      "t": 44001,
      "e": 43919,
      "ty": 41,
      "x": 34127,
      "y": 39553,
      "ta": "html > body"
    },
    {
      "t": 44009,
      "e": 43927,
      "ty": 6,
      "x": 990,
      "y": 707,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 44101,
      "e": 44019,
      "ty": 2,
      "x": 979,
      "y": 683
    },
    {
      "t": 44215,
      "e": 44133,
      "ty": 3,
      "x": 979,
      "y": 683,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 44217,
      "e": 44135,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "America"
    },
    {
      "t": 44217,
      "e": 44135,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 44221,
      "e": 44139,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 44251,
      "e": 44169,
      "ty": 41,
      "x": 42817,
      "y": 13901,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 44318,
      "e": 44236,
      "ty": 4,
      "x": 42817,
      "y": 13901,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 44319,
      "e": 44237,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 44319,
      "e": 44237,
      "ty": 5,
      "x": 979,
      "y": 683,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 44319,
      "e": 44237,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 44601,
      "e": 44519,
      "ty": 2,
      "x": 978,
      "y": 684
    },
    {
      "t": 44700,
      "e": 44618,
      "ty": 2,
      "x": 985,
      "y": 691
    },
    {
      "t": 44751,
      "e": 44669,
      "ty": 41,
      "x": 33645,
      "y": 37836,
      "ta": "html > body"
    },
    {
      "t": 45335,
      "e": 45253,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 46201,
      "e": 46119,
      "ty": 2,
      "x": 981,
      "y": 681
    },
    {
      "t": 46251,
      "e": 46169,
      "ty": 41,
      "x": 24581,
      "y": 56172,
      "ta": "#jspsych-survey-multi-choice-option-1-6"
    },
    {
      "t": 46301,
      "e": 46219,
      "ty": 2,
      "x": 894,
      "y": 537
    },
    {
      "t": 46401,
      "e": 46319,
      "ty": 2,
      "x": 892,
      "y": 536
    },
    {
      "t": 46501,
      "e": 46419,
      "ty": 2,
      "x": 613,
      "y": 16
    },
    {
      "t": 46501,
      "e": 46419,
      "ty": 41,
      "x": 20834,
      "y": 443,
      "ta": "html > body"
    },
    {
      "t": 46601,
      "e": 46519,
      "ty": 2,
      "x": 510,
      "y": 16
    },
    {
      "t": 46751,
      "e": 46669,
      "ty": 41,
      "x": 20593,
      "y": 10026,
      "ta": "html > body"
    },
    {
      "t": 46801,
      "e": 46719,
      "ty": 2,
      "x": 798,
      "y": 332
    },
    {
      "t": 46900,
      "e": 46818,
      "ty": 2,
      "x": 915,
      "y": 333
    },
    {
      "t": 47001,
      "e": 46919,
      "ty": 2,
      "x": 902,
      "y": 272
    },
    {
      "t": 47001,
      "e": 46919,
      "ty": 41,
      "x": 61369,
      "y": 49151,
      "ta": "#jspsych-survey-multi-choice-option-0-1 > label"
    },
    {
      "t": 47100,
      "e": 47018,
      "ty": 2,
      "x": 868,
      "y": 250
    },
    {
      "t": 47201,
      "e": 47119,
      "ty": 2,
      "x": 867,
      "y": 250
    },
    {
      "t": 47251,
      "e": 47169,
      "ty": 41,
      "x": 10816,
      "y": 58513,
      "ta": "#jspsych-survey-multi-choice-option-0-0"
    },
    {
      "t": 47301,
      "e": 47219,
      "ty": 2,
      "x": 865,
      "y": 249
    },
    {
      "t": 47401,
      "e": 47319,
      "ty": 2,
      "x": 852,
      "y": 240
    },
    {
      "t": 47502,
      "e": 47420,
      "ty": 41,
      "x": 25039,
      "y": 36044,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 47705,
      "e": 47623,
      "ty": 2,
      "x": 857,
      "y": 246
    },
    {
      "t": 47755,
      "e": 47673,
      "ty": 41,
      "x": 33189,
      "y": 29490,
      "ta": "#jspsych-survey-multi-choice-option-0-1 > label"
    },
    {
      "t": 47805,
      "e": 47723,
      "ty": 2,
      "x": 871,
      "y": 313
    },
    {
      "t": 47906,
      "e": 47824,
      "ty": 2,
      "x": 873,
      "y": 325
    },
    {
      "t": 48006,
      "e": 47924,
      "ty": 2,
      "x": 847,
      "y": 331
    },
    {
      "t": 48006,
      "e": 47924,
      "ty": 41,
      "x": 25391,
      "y": 58981,
      "ta": "#jspsych-survey-multi-choice-option-0-3 > label"
    },
    {
      "t": 48105,
      "e": 48023,
      "ty": 2,
      "x": 841,
      "y": 329
    },
    {
      "t": 48255,
      "e": 48173,
      "ty": 41,
      "x": 19435,
      "y": 52428,
      "ta": "#jspsych-survey-multi-choice-option-0-3 > label"
    },
    {
      "t": 48305,
      "e": 48223,
      "ty": 2,
      "x": 841,
      "y": 322
    },
    {
      "t": 48406,
      "e": 48324,
      "ty": 2,
      "x": 845,
      "y": 198
    },
    {
      "t": 48506,
      "e": 48424,
      "ty": 2,
      "x": 842,
      "y": 193
    },
    {
      "t": 48507,
      "e": 48425,
      "ty": 41,
      "x": 4883,
      "y": 32767,
      "ta": "#jspsych-survey-multi-choice-0 > p"
    },
    {
      "t": 48605,
      "e": 48523,
      "ty": 2,
      "x": 852,
      "y": 196
    },
    {
      "t": 48705,
      "e": 48623,
      "ty": 2,
      "x": 847,
      "y": 224
    },
    {
      "t": 48755,
      "e": 48673,
      "ty": 41,
      "x": 6070,
      "y": 2340,
      "ta": "#jspsych-survey-multi-choice-option-0-0"
    },
    {
      "t": 48805,
      "e": 48723,
      "ty": 2,
      "x": 847,
      "y": 226
    },
    {
      "t": 48905,
      "e": 48823,
      "ty": 2,
      "x": 849,
      "y": 230
    },
    {
      "t": 49006,
      "e": 48924,
      "ty": 41,
      "x": 22582,
      "y": 3276,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 49706,
      "e": 49624,
      "ty": 2,
      "x": 853,
      "y": 232
    },
    {
      "t": 49756,
      "e": 49674,
      "ty": 41,
      "x": 25858,
      "y": 9830,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 49949,
      "e": 49867,
      "ty": 3,
      "x": 853,
      "y": 232,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 50051,
      "e": 49969,
      "ty": 4,
      "x": 25858,
      "y": 9830,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 50052,
      "e": 49970,
      "ty": 5,
      "x": 853,
      "y": 232,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 50053,
      "e": 49971,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 50055,
      "e": 49973,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf",
      "v": "English"
    },
    {
      "t": 50405,
      "e": 50323,
      "ty": 2,
      "x": 873,
      "y": 291
    },
    {
      "t": 50505,
      "e": 50423,
      "ty": 2,
      "x": 897,
      "y": 341
    },
    {
      "t": 50506,
      "e": 50424,
      "ty": 41,
      "x": 17936,
      "y": 13450,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 50605,
      "e": 50523,
      "ty": 2,
      "x": 897,
      "y": 403
    },
    {
      "t": 50705,
      "e": 50623,
      "ty": 2,
      "x": 899,
      "y": 472
    },
    {
      "t": 50755,
      "e": 50673,
      "ty": 41,
      "x": 18411,
      "y": 39789,
      "ta": "#jspsych-survey-multi-choice-option-1-2"
    },
    {
      "t": 50805,
      "e": 50723,
      "ty": 2,
      "x": 899,
      "y": 474
    },
    {
      "t": 51305,
      "e": 51223,
      "ty": 2,
      "x": 898,
      "y": 473
    },
    {
      "t": 51405,
      "e": 51323,
      "ty": 2,
      "x": 882,
      "y": 435
    },
    {
      "t": 51506,
      "e": 51424,
      "ty": 2,
      "x": 796,
      "y": 368
    },
    {
      "t": 51506,
      "e": 51424,
      "ty": 41,
      "x": 27136,
      "y": 19943,
      "ta": "html > body"
    },
    {
      "t": 51606,
      "e": 51524,
      "ty": 2,
      "x": 794,
      "y": 366
    },
    {
      "t": 51705,
      "e": 51623,
      "ty": 2,
      "x": 833,
      "y": 370
    },
    {
      "t": 51756,
      "e": 51674,
      "ty": 41,
      "x": 6070,
      "y": 60853,
      "ta": "#jspsych-survey-multi-choice-1 > p"
    },
    {
      "t": 51805,
      "e": 51723,
      "ty": 2,
      "x": 851,
      "y": 391
    },
    {
      "t": 51905,
      "e": 51823,
      "ty": 2,
      "x": 852,
      "y": 392
    },
    {
      "t": 52006,
      "e": 51924,
      "ty": 2,
      "x": 853,
      "y": 400
    },
    {
      "t": 52006,
      "e": 51924,
      "ty": 41,
      "x": 7494,
      "y": 12186,
      "ta": "#jspsych-survey-multi-choice-1"
    },
    {
      "t": 52105,
      "e": 52023,
      "ty": 2,
      "x": 853,
      "y": 401
    },
    {
      "t": 52206,
      "e": 52124,
      "ty": 2,
      "x": 851,
      "y": 410
    },
    {
      "t": 52255,
      "e": 52173,
      "ty": 41,
      "x": 34623,
      "y": 39321,
      "ta": "#jspsych-survey-multi-choice-option-1-0 > label"
    },
    {
      "t": 52305,
      "e": 52223,
      "ty": 2,
      "x": 851,
      "y": 417
    },
    {
      "t": 52347,
      "e": 52265,
      "ty": 3,
      "x": 851,
      "y": 417,
      "ta": "#jspsych-survey-multi-choice-option-1-0 > label"
    },
    {
      "t": 52348,
      "e": 52266,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 52491,
      "e": 52409,
      "ty": 4,
      "x": 34623,
      "y": 39321,
      "ta": "#jspsych-survey-multi-choice-option-1-0 > label"
    },
    {
      "t": 52491,
      "e": 52409,
      "ty": 5,
      "x": 851,
      "y": 417,
      "ta": "#jspsych-survey-multi-choice-option-1-0 > label"
    },
    {
      "t": 52492,
      "e": 52410,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 52494,
      "e": 52412,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf",
      "v": "First"
    },
    {
      "t": 52906,
      "e": 52824,
      "ty": 2,
      "x": 867,
      "y": 553
    },
    {
      "t": 53005,
      "e": 52923,
      "ty": 41,
      "x": 31099,
      "y": 26214,
      "ta": "#jspsych-survey-multi-choice-option-1-5 > label"
    },
    {
      "t": 53106,
      "e": 53024,
      "ty": 2,
      "x": 868,
      "y": 555
    },
    {
      "t": 53172,
      "e": 53090,
      "ty": 6,
      "x": 838,
      "y": 577,
      "ta": "jspsych-survey-multi-choice-response-1[6]_mf"
    },
    {
      "t": 53204,
      "e": 53122,
      "ty": 7,
      "x": 819,
      "y": 591,
      "ta": "jspsych-survey-multi-choice-response-1[6]_mf"
    },
    {
      "t": 53205,
      "e": 53123,
      "ty": 2,
      "x": 819,
      "y": 591
    },
    {
      "t": 53256,
      "e": 53174,
      "ty": 41,
      "x": 26758,
      "y": 33515,
      "ta": "html > body"
    },
    {
      "t": 53306,
      "e": 53224,
      "ty": 2,
      "x": 774,
      "y": 616
    },
    {
      "t": 53406,
      "e": 53324,
      "ty": 2,
      "x": 779,
      "y": 620
    },
    {
      "t": 53505,
      "e": 53423,
      "ty": 2,
      "x": 891,
      "y": 629
    },
    {
      "t": 53506,
      "e": 53424,
      "ty": 41,
      "x": 16512,
      "y": 32767,
      "ta": "#jspsych-survey-multi-choice-2 > p"
    },
    {
      "t": 53606,
      "e": 53524,
      "ty": 2,
      "x": 1083,
      "y": 646
    },
    {
      "t": 53706,
      "e": 53624,
      "ty": 2,
      "x": 1069,
      "y": 673
    },
    {
      "t": 53758,
      "e": 53626,
      "ty": 41,
      "x": 50593,
      "y": 39321,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 53806,
      "e": 53674,
      "ty": 2,
      "x": 1000,
      "y": 772
    },
    {
      "t": 53906,
      "e": 53774,
      "ty": 2,
      "x": 978,
      "y": 773
    },
    {
      "t": 54005,
      "e": 53873,
      "ty": 2,
      "x": 939,
      "y": 765
    },
    {
      "t": 54006,
      "e": 53874,
      "ty": 41,
      "x": 49059,
      "y": 52428,
      "ta": "#jspsych-survey-multi-choice-option-2-3 > label"
    },
    {
      "t": 54105,
      "e": 53973,
      "ty": 2,
      "x": 924,
      "y": 767
    },
    {
      "t": 54206,
      "e": 54074,
      "ty": 2,
      "x": 902,
      "y": 779
    },
    {
      "t": 54256,
      "e": 54124,
      "ty": 41,
      "x": 18173,
      "y": 56172,
      "ta": "#jspsych-survey-multi-choice-option-2-3"
    },
    {
      "t": 54306,
      "e": 54174,
      "ty": 2,
      "x": 895,
      "y": 753
    },
    {
      "t": 54407,
      "e": 54275,
      "ty": 2,
      "x": 892,
      "y": 740
    },
    {
      "t": 54505,
      "e": 54373,
      "ty": 2,
      "x": 877,
      "y": 725
    },
    {
      "t": 54505,
      "e": 54373,
      "ty": 41,
      "x": 13949,
      "y": 13107,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 54605,
      "e": 54473,
      "ty": 2,
      "x": 864,
      "y": 697
    },
    {
      "t": 54705,
      "e": 54573,
      "ty": 2,
      "x": 863,
      "y": 695
    },
    {
      "t": 54757,
      "e": 54625,
      "ty": 41,
      "x": 11528,
      "y": 58513,
      "ta": "#jspsych-survey-multi-choice-option-2-1"
    },
    {
      "t": 54806,
      "e": 54674,
      "ty": 2,
      "x": 871,
      "y": 721
    },
    {
      "t": 54905,
      "e": 54773,
      "ty": 2,
      "x": 871,
      "y": 723
    },
    {
      "t": 55005,
      "e": 54873,
      "ty": 2,
      "x": 872,
      "y": 727
    },
    {
      "t": 55006,
      "e": 54874,
      "ty": 41,
      "x": 12694,
      "y": 19660,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 55106,
      "e": 54974,
      "ty": 2,
      "x": 876,
      "y": 727
    },
    {
      "t": 55205,
      "e": 55073,
      "ty": 2,
      "x": 888,
      "y": 733
    },
    {
      "t": 55256,
      "e": 55124,
      "ty": 41,
      "x": 16710,
      "y": 39321,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 55705,
      "e": 55573,
      "ty": 2,
      "x": 890,
      "y": 768
    },
    {
      "t": 55756,
      "e": 55624,
      "ty": 41,
      "x": 39887,
      "y": 13107,
      "ta": "#jspsych-survey-multi-choice-option-2-5 > label"
    },
    {
      "t": 55805,
      "e": 55673,
      "ty": 2,
      "x": 886,
      "y": 832
    },
    {
      "t": 55905,
      "e": 55773,
      "ty": 2,
      "x": 883,
      "y": 845
    },
    {
      "t": 56006,
      "e": 55874,
      "ty": 2,
      "x": 881,
      "y": 814
    },
    {
      "t": 56006,
      "e": 55874,
      "ty": 41,
      "x": 35165,
      "y": 29490,
      "ta": "#jspsych-survey-multi-choice-option-2-5 > label"
    },
    {
      "t": 56105,
      "e": 55973,
      "ty": 2,
      "x": 864,
      "y": 731
    },
    {
      "t": 56206,
      "e": 56074,
      "ty": 2,
      "x": 861,
      "y": 693
    },
    {
      "t": 56256,
      "e": 56124,
      "ty": 41,
      "x": 11969,
      "y": 52428,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 56306,
      "e": 56174,
      "ty": 2,
      "x": 873,
      "y": 675
    },
    {
      "t": 56406,
      "e": 56274,
      "ty": 2,
      "x": 889,
      "y": 668
    },
    {
      "t": 56506,
      "e": 56374,
      "ty": 2,
      "x": 920,
      "y": 666
    },
    {
      "t": 56506,
      "e": 56374,
      "ty": 41,
      "x": 26468,
      "y": 3276,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 56605,
      "e": 56473,
      "ty": 2,
      "x": 980,
      "y": 681
    },
    {
      "t": 56706,
      "e": 56574,
      "ty": 2,
      "x": 1040,
      "y": 692
    },
    {
      "t": 56756,
      "e": 56624,
      "ty": 41,
      "x": 51873,
      "y": 7021,
      "ta": "#jspsych-survey-multi-choice-option-2-1"
    },
    {
      "t": 56905,
      "e": 56773,
      "ty": 2,
      "x": 989,
      "y": 673
    },
    {
      "t": 57005,
      "e": 56873,
      "ty": 2,
      "x": 929,
      "y": 668
    },
    {
      "t": 57006,
      "e": 56874,
      "ty": 41,
      "x": 28884,
      "y": 9830,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 57106,
      "e": 56974,
      "ty": 2,
      "x": 919,
      "y": 680
    },
    {
      "t": 57206,
      "e": 57074,
      "ty": 2,
      "x": 903,
      "y": 716
    },
    {
      "t": 57255,
      "e": 57123,
      "ty": 41,
      "x": 18969,
      "y": 26214,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 57306,
      "e": 57174,
      "ty": 2,
      "x": 894,
      "y": 735
    },
    {
      "t": 57405,
      "e": 57273,
      "ty": 2,
      "x": 894,
      "y": 736
    },
    {
      "t": 57506,
      "e": 57374,
      "ty": 41,
      "x": 18216,
      "y": 49151,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 57755,
      "e": 57623,
      "ty": 3,
      "x": 894,
      "y": 736,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 57756,
      "e": 57624,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 57915,
      "e": 57783,
      "ty": 4,
      "x": 18216,
      "y": 49151,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 57915,
      "e": 57783,
      "ty": 5,
      "x": 894,
      "y": 736,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 57916,
      "e": 57784,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 57916,
      "e": 57784,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf",
      "v": "Biomedical & Health Sciences"
    },
    {
      "t": 58256,
      "e": 58124,
      "ty": 41,
      "x": 17224,
      "y": 63194,
      "ta": "#jspsych-survey-multi-choice-option-2-2"
    },
    {
      "t": 58305,
      "e": 58173,
      "ty": 2,
      "x": 935,
      "y": 820
    },
    {
      "t": 58406,
      "e": 58274,
      "ty": 2,
      "x": 928,
      "y": 949
    },
    {
      "t": 58506,
      "e": 58374,
      "ty": 2,
      "x": 923,
      "y": 961
    },
    {
      "t": 58506,
      "e": 58374,
      "ty": 41,
      "x": 24107,
      "y": 28086,
      "ta": "#jspsych-survey-multi-choice-option-3-1"
    },
    {
      "t": 58605,
      "e": 58473,
      "ty": 2,
      "x": 916,
      "y": 964
    },
    {
      "t": 58706,
      "e": 58574,
      "ty": 2,
      "x": 880,
      "y": 962
    },
    {
      "t": 58759,
      "e": 58577,
      "ty": 41,
      "x": 43340,
      "y": 26214,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 58806,
      "e": 58624,
      "ty": 2,
      "x": 867,
      "y": 959
    },
    {
      "t": 58906,
      "e": 58724,
      "ty": 2,
      "x": 864,
      "y": 958
    },
    {
      "t": 59006,
      "e": 58824,
      "ty": 2,
      "x": 864,
      "y": 949
    },
    {
      "t": 59006,
      "e": 58824,
      "ty": 41,
      "x": 10104,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-3-1"
    },
    {
      "t": 59105,
      "e": 58923,
      "ty": 2,
      "x": 864,
      "y": 947
    },
    {
      "t": 59205,
      "e": 59023,
      "ty": 2,
      "x": 864,
      "y": 946
    },
    {
      "t": 59256,
      "e": 59074,
      "ty": 41,
      "x": 10104,
      "y": 4681,
      "ta": "#jspsych-survey-multi-choice-option-3-1"
    },
    {
      "t": 59305,
      "e": 59123,
      "ty": 2,
      "x": 864,
      "y": 964
    },
    {
      "t": 59412,
      "e": 59230,
      "ty": 3,
      "x": 864,
      "y": 964,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 59413,
      "e": 59231,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 59506,
      "e": 59324,
      "ty": 41,
      "x": 34442,
      "y": 36044,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 59523,
      "e": 59341,
      "ty": 4,
      "x": 34442,
      "y": 36044,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 59523,
      "e": 59341,
      "ty": 5,
      "x": 864,
      "y": 964,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 59523,
      "e": 59341,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 59524,
      "e": 59342,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf",
      "v": "Female"
    },
    {
      "t": 59706,
      "e": 59524,
      "ty": 2,
      "x": 881,
      "y": 993
    },
    {
      "t": 59756,
      "e": 59574,
      "ty": 41,
      "x": 60137,
      "y": 49151,
      "ta": "#jspsych-survey-multi-choice-option-3-2 > label"
    },
    {
      "t": 59806,
      "e": 59624,
      "ty": 2,
      "x": 886,
      "y": 1004
    },
    {
      "t": 59810,
      "e": 59628,
      "ty": 6,
      "x": 887,
      "y": 1009,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 59906,
      "e": 59724,
      "ty": 2,
      "x": 891,
      "y": 1013
    },
    {
      "t": 60006,
      "e": 59824,
      "ty": 2,
      "x": 893,
      "y": 1013
    },
    {
      "t": 60006,
      "e": 59824,
      "ty": 41,
      "x": 32767,
      "y": 15887,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 60068,
      "e": 59886,
      "ty": 3,
      "x": 894,
      "y": 1014,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 60070,
      "e": 59888,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 60070,
      "e": 59888,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 60106,
      "e": 59924,
      "ty": 2,
      "x": 894,
      "y": 1014
    },
    {
      "t": 60178,
      "e": 59996,
      "ty": 4,
      "x": 33282,
      "y": 17873,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 60178,
      "e": 59996,
      "ty": 5,
      "x": 894,
      "y": 1014,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 60181,
      "e": 59999,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 60182,
      "e": 60000,
      "ty": 13,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 60183,
      "e": 60001,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 60256,
      "e": 60074,
      "ty": 41,
      "x": 30511,
      "y": 55729,
      "ta": "html > body"
    },
    {
      "t": 61518,
      "e": 61336,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 62305,
      "e": 62123,
      "ty": 2,
      "x": 894,
      "y": 1017
    },
    {
      "t": 62406,
      "e": 62224,
      "ty": 2,
      "x": 893,
      "y": 969
    },
    {
      "t": 62506,
      "e": 62324,
      "ty": 2,
      "x": 882,
      "y": 943
    },
    {
      "t": 62506,
      "e": 62324,
      "ty": 41,
      "x": 28954,
      "y": 56554,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 62606,
      "e": 62424,
      "ty": 2,
      "x": 886,
      "y": 943
    },
    {
      "t": 62706,
      "e": 62524,
      "ty": 2,
      "x": 942,
      "y": 968
    },
    {
      "t": 62756,
      "e": 62574,
      "ty": 41,
      "x": 34759,
      "y": 60016,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 62806,
      "e": 62624,
      "ty": 2,
      "x": 1024,
      "y": 1008
    },
    {
      "t": 62906,
      "e": 62724,
      "ty": 2,
      "x": 1017,
      "y": 1055
    },
    {
      "t": 62929,
      "e": 62747,
      "ty": 6,
      "x": 1006,
      "y": 1083,
      "ta": "#start"
    },
    {
      "t": 62963,
      "e": 62781,
      "ty": 7,
      "x": 996,
      "y": 1109,
      "ta": "#start"
    },
    {
      "t": 63006,
      "e": 62824,
      "ty": 2,
      "x": 988,
      "y": 1133
    },
    {
      "t": 63006,
      "e": 62824,
      "ty": 41,
      "x": 46108,
      "y": 33412,
      "ta": "> div.masterdiv > div:[3]"
    },
    {
      "t": 63106,
      "e": 62924,
      "ty": 2,
      "x": 987,
      "y": 1144
    },
    {
      "t": 63206,
      "e": 63024,
      "ty": 2,
      "x": 978,
      "y": 1131
    },
    {
      "t": 63246,
      "e": 63064,
      "ty": 6,
      "x": 962,
      "y": 1106,
      "ta": "#start"
    },
    {
      "t": 63256,
      "e": 63074,
      "ty": 41,
      "x": 28671,
      "y": 64209,
      "ta": "#start"
    },
    {
      "t": 63306,
      "e": 63124,
      "ty": 2,
      "x": 959,
      "y": 1094
    },
    {
      "t": 63506,
      "e": 63324,
      "ty": 41,
      "x": 27033,
      "y": 41079,
      "ta": "#start"
    },
    {
      "t": 63748,
      "e": 63566,
      "ty": 3,
      "x": 959,
      "y": 1094,
      "ta": "#start"
    },
    {
      "t": 63749,
      "e": 63567,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 63931,
      "e": 63749,
      "ty": 4,
      "x": 27033,
      "y": 41079,
      "ta": "#start"
    },
    {
      "t": 63933,
      "e": 63751,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 63933,
      "e": 63751,
      "ty": 5,
      "x": 959,
      "y": 1094,
      "ta": "#start"
    },
    {
      "t": 63935,
      "e": 63753,
      "ty": 38,
      "x": 8,
      "y": 0
    },
    {
      "t": 64706,
      "e": 64524,
      "ty": 2,
      "x": 959,
      "y": 1093
    },
    {
      "t": 64757,
      "e": 64575,
      "ty": 41,
      "x": 32750,
      "y": 60106,
      "ta": "html > body"
    },
    {
      "t": 64964,
      "e": 64782,
      "ty": 38,
      "x": 9,
      "y": 0
    },
    {
      "t": 65906,
      "e": 65724,
      "ty": 2,
      "x": 959,
      "y": 1091
    },
    {
      "t": 66005,
      "e": 65823,
      "ty": 2,
      "x": 959,
      "y": 1088
    },
    {
      "t": 66005,
      "e": 65823,
      "ty": 41,
      "x": 32739,
      "y": 32910,
      "ta": "#jspsych-data-display"
    },
    {
      "t": 66075,
      "e": 65893,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2311,\"tagName\":\"g\",\"attributes\":{\"class\":\"xaxis\",\"transform\":\"translate(0,800)\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"middle\"},\"previousSibling\":{\"id\":2302},\"parentNode\":{\"id\":2300}},{\"nodeType\":1,\"id\":2312,\"tagName\":\"g\",\"attributes\":{\"class\":\"yaxis\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"end\"},\"previousSibling\":{\"id\":2311},\"parentNode\":{\"id\":2300}},{\"nodeType\":1,\"id\":2313,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2312},\"parentNode\":{\"id\":2300}},{\"nodeType\":1,\"id\":2314,\"tagName\":\"g\",\"attributes\":{\"class\":\"xgrid\"},\"previousSibling\":{\"id\":2313},\"parentNode\":{\"id\":2300}},{\"nodeType\":1,\"id\":2315,\"tagName\":\"g\",\"attributes\":{\"class\":\"data\"},\"previousSibling\":{\"id\":2314},\"parentNode\":{\"id\":2300}},{\"nodeType\":1,\"id\":2316,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M0.5,6V0.5H800.5V6\"},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2317,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0.5,0)\"},\"previousSibling\":{\"id\":2316},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2318,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(33.83333333333333,0)\"},\"previousSibling\":{\"id\":2317},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2319,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(67.16666666666666,0)\"},\"previousSibling\":{\"id\":2318},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2320,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(100.5,0)\"},\"previousSibling\":{\"id\":2319},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2321,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(133.83333333333331,0)\"},\"previousSibling\":{\"id\":2320},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2322,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(167.16666666666669,0)\"},\"previousSibling\":{\"id\":2321},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2323,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(200.5,0)\"},\"previousSibling\":{\"id\":2322},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2324,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(233.83333333333334,0)\"},\"previousSibling\":{\"id\":2323},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2325,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(267.16666666666663,0)\"},\"previousSibling\":{\"id\":2324},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2326,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(300.5,0)\"},\"previousSibling\":{\"id\":2325},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2327,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(333.83333333333337,0)\"},\"previousSibling\":{\"id\":2326},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2328,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(367.16666666666663,0)\"},\"previousSibling\":{\"id\":2327},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2329,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(400.5,0)\"},\"previousSibling\":{\"id\":2328},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2330,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(433.8333333333333,0)\"},\"previousSibling\":{\"id\":2329},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2331,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(467.1666666666667,0)\"},\"previousSibling\":{\"id\":2330},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2332,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(500.5,0)\"},\"previousSibling\":{\"id\":2331},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2333,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(533.8333333333333,0)\"},\"previousSibling\":{\"id\":2332},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2334,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(567.1666666666667,0)\"},\"previousSibling\":{\"id\":2333},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2335,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(600.5,0)\"},\"previousSibling\":{\"id\":2334},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2336,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(633.8333333333333,0)\"},\"previousSibling\":{\"id\":2335},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2337,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(667.1666666666667,0)\"},\"previousSibling\":{\"id\":2336},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2338,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(700.5,0)\"},\"previousSibling\":{\"id\":2337},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2339,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(733.8333333333333,0)\"},\"previousSibling\":{\"id\":2338},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2340,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(767.1666666666667,0)\"},\"previousSibling\":{\"id\":2339},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2341,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(800.5,0)\"},\"previousSibling\":{\"id\":2340},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2342,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"previousSibling\":{\"id\":2341},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2343,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2317}},{\"nodeType\":1,\"id\":2344,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2343},\"parentNode\":{\"id\":2317}},{\"nodeType\":1,\"id\":2345,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2318}},{\"nodeType\":1,\"id\":2346,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2345},\"parentNode\":{\"id\":2318}},{\"nodeType\":1,\"id\":2347,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2319}},{\"nodeType\":1,\"id\":2348,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2347},\"parentNode\":{\"id\":2319}},{\"nodeType\":1,\"id\":2349,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2320}},{\"nodeType\":1,\"id\":2350,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2349},\"parentNode\":{\"id\":2320}},{\"nodeType\":1,\"id\":2351,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2321}},{\"nodeType\":1,\"id\":2352,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2351},\"parentNode\":{\"id\":2321}},{\"nodeType\":1,\"id\":2353,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2322}},{\"nodeType\":1,\"id\":2354,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2353},\"parentNode\":{\"id\":2322}},{\"nodeType\":1,\"id\":2355,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2323}},{\"nodeType\":1,\"id\":2356,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2355},\"parentNode\":{\"id\":2323}},{\"nodeType\":1,\"id\":2357,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2324}},{\"nodeType\":1,\"id\":2358,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2357},\"parentNode\":{\"id\":2324}},{\"nodeType\":1,\"id\":2359,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2325}},{\"nodeType\":1,\"id\":2360,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2359},\"parentNode\":{\"id\":2325}},{\"nodeType\":1,\"id\":2361,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2326}},{\"nodeType\":1,\"id\":2362,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2361},\"parentNode\":{\"id\":2326}},{\"nodeType\":1,\"id\":2363,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2327}},{\"nodeType\":1,\"id\":2364,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2363},\"parentNode\":{\"id\":2327}},{\"nodeType\":1,\"id\":2365,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2328}},{\"nodeType\":1,\"id\":2366,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2365},\"parentNode\":{\"id\":2328}},{\"nodeType\":1,\"id\":2367,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2329}},{\"nodeType\":1,\"id\":2368,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2367},\"parentNode\":{\"id\":2329}},{\"nodeType\":1,\"id\":2369,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2330}},{\"nodeType\":1,\"id\":2370,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2369},\"parentNode\":{\"id\":2330}},{\"nodeType\":1,\"id\":2371,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2331}},{\"nodeType\":1,\"id\":2372,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2371},\"parentNode\":{\"id\":2331}},{\"nodeType\":1,\"id\":2373,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2332}},{\"nodeType\":1,\"id\":2374,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2373},\"parentNode\":{\"id\":2332}},{\"nodeType\":1,\"id\":2375,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2333}},{\"nodeType\":1,\"id\":2376,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2375},\"parentNode\":{\"id\":2333}},{\"nodeType\":1,\"id\":2377,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2334}},{\"nodeType\":1,\"id\":2378,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2377},\"parentNode\":{\"id\":2334}},{\"nodeType\":1,\"id\":2379,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2335}},{\"nodeType\":1,\"id\":2380,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2379},\"parentNode\":{\"id\":2335}},{\"nodeType\":1,\"id\":2381,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2336}},{\"nodeType\":1,\"id\":2382,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2381},\"parentNode\":{\"id\":2336}},{\"nodeType\":1,\"id\":2383,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2337}},{\"nodeType\":1,\"id\":2384,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2383},\"parentNode\":{\"id\":2337}},{\"nodeType\":1,\"id\":2385,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2338}},{\"nodeType\":1,\"id\":2386,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2385},\"parentNode\":{\"id\":2338}},{\"nodeType\":1,\"id\":2387,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2339}},{\"nodeType\":1,\"id\":2388,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2387},\"parentNode\":{\"id\":2339}},{\"nodeType\":1,\"id\":2389,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2340}},{\"nodeType\":1,\"id\":2390,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2389},\"parentNode\":{\"id\":2340}},{\"nodeType\":1,\"id\":2391,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2341}},{\"nodeType\":1,\"id\":2392,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2391},\"parentNode\":{\"id\":2341}},{\"nodeType\":3,\"id\":2393,\"textContent\":\"08 AM\",\"parentNode\":{\"id\":2344}},{\"nodeType\":3,\"id\":2394,\"textContent\":\"08:30\",\"parentNode\":{\"id\":2346}},{\"nodeType\":3,\"id\":2395,\"textContent\":\"09 AM\",\"parentNode\":{\"id\":2348}},{\"nodeType\":3,\"id\":2396,\"textContent\":\"09:30\",\"parentNode\":{\"id\":2350}},{\"nodeType\":3,\"id\":2397,\"textContent\":\"10 AM\",\"parentNode\":{\"id\":2352}},{\"nodeType\":3,\"id\":2398,\"textContent\":\"10:30\",\"parentNode\":{\"id\":2354}},{\"nodeType\":3,\"id\":2399,\"textContent\":\"11 AM\",\"parentNode\":{\"id\":2356}},{\"nodeType\":3,\"id\":2400,\"textContent\":\"11:30\",\"parentNode\":{\"id\":2358}},{\"nodeType\":3,\"id\":2401,\"textContent\":\"12 PM\",\"parentNode\":{\"id\":2360}},{\"nodeType\":3,\"id\":2402,\"textContent\":\"12:30\",\"parentNode\":{\"id\":2362}},{\"nodeType\":3,\"id\":2403,\"textContent\":\"01 PM\",\"parentNode\":{\"id\":2364}},{\"nodeType\":3,\"id\":2404,\"textContent\":\"01:30\",\"parentNode\":{\"id\":2366}},{\"nodeType\":3,\"id\":2405,\"textContent\":\"02 PM\",\"parentNode\":{\"id\":2368}},{\"nodeType\":3,\"id\":2406,\"textContent\":\"02:30\",\"parentNode\":{\"id\":2370}},{\"nodeType\":3,\"id\":2407,\"textContent\":\"03 PM\",\"parentNode\":{\"id\":2372}},{\"nodeType\":3,\"id\":2408,\"textContent\":\"03:30\",\"parentNode\":{\"id\":2374}},{\"nodeType\":3,\"id\":2409,\"textContent\":\"04 PM\",\"parentNode\":{\"id\":2376}},{\"nodeType\":3,\"id\":2410,\"textContent\":\"04:30\",\"parentNode\":{\"id\":2378}},{\"nodeType\":3,\"id\":2411,\"textContent\":\"05 PM\",\"parentNode\":{\"id\":2380}},{\"nodeType\":3,\"id\":2412,\"textContent\":\"05:30\",\"parentNode\":{\"id\":2382}},{\"nodeType\":3,\"id\":2413,\"textContent\":\"06 PM\",\"parentNode\":{\"id\":2384}},{\"nodeType\":3,\"id\":2414,\"textContent\":\"06:30\",\"parentNode\":{\"id\":2386}},{\"nodeType\":3,\"id\":2415,\"textContent\":\"07 PM\",\"parentNode\":{\"id\":2388}},{\"nodeType\":3,\"id\":2416,\"textContent\":\"07:30\",\"parentNode\":{\"id\":2390}},{\"nodeType\":3,\"id\":2417,\"textContent\":\"08 PM\",\"parentNode\":{\"id\":2392}},{\"nodeType\":1,\"id\":2418,\"tagName\":\"text\",\"attributes\":{\"x\":\"533.3333333333334\",\"y\":\"80\",\"style\":\"text-anchor: end;\"},\"parentNode\":{\"id\":2342}},{\"nodeType\":3,\"id\":2419,\"textContent\":\"START & END TIME (time of day)\",\"parentNode\":{\"id\":2418}},{\"nodeType\":1,\"id\":2420,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M-15,800.5H0.5V0.5H-15\"},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2421,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,800.5)\"},\"previousSibling\":{\"id\":2420},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2422,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,733.8333333333334)\"},\"previousSibling\":{\"id\":2421},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2423,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,667.1666666666667)\"},\"previousSibling\":{\"id\":2422},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2424,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,600.5)\"},\"previousSibling\":{\"id\":2423},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2425,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,533.8333333333334)\"},\"previousSibling\":{\"id\":2424},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2426,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,467.16666666666663)\"},\"previousSibling\":{\"id\":2425},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2427,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,400.5)\"},\"previousSibling\":{\"id\":2426},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2428,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,333.8333333333333)\"},\"previousSibling\":{\"id\":2427},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2429,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,267.16666666666674)\"},\"previousSibling\":{\"id\":2428},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2430,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,200.5)\"},\"previousSibling\":{\"id\":2429},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2431,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,133.83333333333326)\"},\"previousSibling\":{\"id\":2430},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2432,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,67.16666666666674)\"},\"previousSibling\":{\"id\":2431},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2433,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,0.5)\"},\"previousSibling\":{\"id\":2432},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2434,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"previousSibling\":{\"id\":2433},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2435,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2421}},{\"nodeType\":1,\"id\":2436,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2435},\"parentNode\":{\"id\":2421}},{\"nodeType\":1,\"id\":2437,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2422}},{\"nodeType\":1,\"id\":2438,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2437},\"parentNode\":{\"id\":2422}},{\"nodeType\":1,\"id\":2439,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2423}},{\"nodeType\":1,\"id\":2440,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2439},\"parentNode\":{\"id\":2423}},{\"nodeType\":1,\"id\":2441,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2424}},{\"nodeType\":1,\"id\":2442,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2441},\"parentNode\":{\"id\":2424}},{\"nodeType\":1,\"id\":2443,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2425}},{\"nodeType\":1,\"id\":2444,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2443},\"parentNode\":{\"id\":2425}},{\"nodeType\":1,\"id\":2445,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2426}},{\"nodeType\":1,\"id\":2446,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2445},\"parentNode\":{\"id\":2426}},{\"nodeType\":1,\"id\":2447,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2427}},{\"nodeType\":1,\"id\":2448,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2447},\"parentNode\":{\"id\":2427}},{\"nodeType\":1,\"id\":2449,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2428}},{\"nodeType\":1,\"id\":2450,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2449},\"parentNode\":{\"id\":2428}},{\"nodeType\":1,\"id\":2451,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2429}},{\"nodeType\":1,\"id\":2452,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2451},\"parentNode\":{\"id\":2429}},{\"nodeType\":1,\"id\":2453,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2430}},{\"nodeType\":1,\"id\":2454,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2453},\"parentNode\":{\"id\":2430}},{\"nodeType\":1,\"id\":2455,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2431}},{\"nodeType\":1,\"id\":2456,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2455},\"parentNode\":{\"id\":2431}},{\"nodeType\":1,\"id\":2457,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2432}},{\"nodeType\":1,\"id\":2458,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2457},\"parentNode\":{\"id\":2432}},{\"nodeType\":1,\"id\":2459,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2433}},{\"nodeType\":1,\"id\":2460,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2459},\"parentNode\":{\"id\":2433}},{\"nodeType\":3,\"id\":2461,\"textContent\":\"0\",\"parentNode\":{\"id\":2436}},{\"nodeType\":3,\"id\":2462,\"textContent\":\"1\",\"parentNode\":{\"id\":2438}},{\"nodeType\":3,\"id\":2463,\"textContent\":\"2\",\"parentNode\":{\"id\":2440}},{\"nodeType\":3,\"id\":2464,\"textContent\":\"3\",\"parentNode\":{\"id\":2442}},{\"nodeType\":3,\"id\":2465,\"textContent\":\"4\",\"parentNode\":{\"id\":2444}},{\"nodeType\":3,\"id\":2466,\"textContent\":\"5\",\"parentNode\":{\"id\":2446}},{\"nodeType\":3,\"id\":2467,\"textContent\":\"6\",\"parentNode\":{\"id\":2448}},{\"nodeType\":3,\"id\":2468,\"textContent\":\"7\",\"parentNode\":{\"id\":2450}},{\"nodeType\":3,\"id\":2469,\"textContent\":\"8\",\"parentNode\":{\"id\":2452}},{\"nodeType\":3,\"id\":2470,\"textContent\":\"9\",\"parentNode\":{\"id\":2454}},{\"nodeType\":3,\"id\":2471,\"textContent\":\"10\",\"parentNode\":{\"id\":2456}},{\"nodeType\":3,\"id\":2472,\"textContent\":\"11\",\"parentNode\":{\"id\":2458}},{\"nodeType\":3,\"id\":2473,\"textContent\":\"12\",\"parentNode\":{\"id\":2460}},{\"nodeType\":1,\"id\":2474,\"tagName\":\"text\",\"attributes\":{\"transform\":\"rotate(-90)\",\"x\":\"-350\",\"y\":\"-60\",\"style\":\"text-anchor: end;\"},\"parentNode\":{\"id\":2434}},{\"nodeType\":3,\"id\":2475,\"textContent\":\"DURATION (in hours)\",\"parentNode\":{\"id\":2474}},{\"nodeType\":1,\"id\":2476,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2477,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2476},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2478,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2477},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2479,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2478},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2480,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2479},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2481,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2480},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2482,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2481},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2483,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2482},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2484,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2483},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2485,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2484},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2486,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2485},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2487,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2486},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2488,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"733.3333333333334\",\"y2\":\"733.3333333333334\"},\"parentNode\":{\"id\":2476}},{\"nodeType\":1,\"id\":2489,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"666.6666666666667\",\"y2\":\"666.6666666666667\"},\"parentNode\":{\"id\":2477}},{\"nodeType\":1,\"id\":2490,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"600\",\"y2\":\"600\"},\"parentNode\":{\"id\":2478}},{\"nodeType\":1,\"id\":2491,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"533.3333333333334\",\"y2\":\"533.3333333333334\"},\"parentNode\":{\"id\":2479}},{\"nodeType\":1,\"id\":2492,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"466.66666666666663\",\"y2\":\"466.66666666666663\"},\"parentNode\":{\"id\":2480}},{\"nodeType\":1,\"id\":2493,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"400\",\"y2\":\"400\"},\"parentNode\":{\"id\":2481}},{\"nodeType\":1,\"id\":2494,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"333.3333333333333\",\"y2\":\"333.3333333333333\"},\"parentNode\":{\"id\":2482}},{\"nodeType\":1,\"id\":2495,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"266.66666666666674\",\"y2\":\"266.66666666666674\"},\"parentNode\":{\"id\":2483}},{\"nodeType\":1,\"id\":2496,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"200\",\"y2\":\"200\"},\"parentNode\":{\"id\":2484}},{\"nodeType\":1,\"id\":2497,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"133.33333333333326\",\"y2\":\"133.33333333333326\"},\"parentNode\":{\"id\":2485}},{\"nodeType\":1,\"id\":2498,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"66.66666666666674\",\"y2\":\"66.66666666666674\"},\"parentNode\":{\"id\":2486}},{\"nodeType\":1,\"id\":2499,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"0\",\"y2\":\"0\"},\"parentNode\":{\"id\":2487}},{\"nodeType\":1,\"id\":2500,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"0\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2501,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"800\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"},\"previousSibling\":{\"id\":2500},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2502,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"433.3333333333333\",\"y2\":\"66.66666666666674\"},\"previousSibling\":{\"id\":2501},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2503,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"366.66666666666663\",\"y2\":\"66.66666666666674\"},\"previousSibling\":{\"id\":2502},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2504,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"466.6666666666667\",\"y2\":\"133.33333333333326\"},\"previousSibling\":{\"id\":2503},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2505,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"333.33333333333337\",\"y2\":\"133.33333333333326\"},\"previousSibling\":{\"id\":2504},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2506,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"500\",\"y2\":\"200\"},\"previousSibling\":{\"id\":2505},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2507,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"300\",\"y2\":\"200\"},\"previousSibling\":{\"id\":2506},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2508,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"533.3333333333333\",\"y2\":\"266.66666666666674\"},\"previousSibling\":{\"id\":2507},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2509,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"266.66666666666663\",\"y2\":\"266.66666666666674\"},\"previousSibling\":{\"id\":2508},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2510,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"566.6666666666667\",\"y2\":\"333.3333333333333\"},\"previousSibling\":{\"id\":2509},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2511,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"233.33333333333334\",\"y2\":\"333.3333333333333\"},\"previousSibling\":{\"id\":2510},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2512,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"600\",\"y2\":\"400\"},\"previousSibling\":{\"id\":2511},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2513,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"200\",\"y2\":\"400\"},\"previousSibling\":{\"id\":2512},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2514,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"633.3333333333333\",\"y2\":\"466.66666666666663\"},\"previousSibling\":{\"id\":2513},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2515,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"166.66666666666669\",\"y2\":\"466.66666666666663\"},\"previousSibling\":{\"id\":2514},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2516,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"666.6666666666667\",\"y2\":\"533.3333333333334\"},\"previousSibling\":{\"id\":2515},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2517,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"133.33333333333331\",\"y2\":\"533.3333333333334\"},\"previousSibling\":{\"id\":2516},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2518,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"700\",\"y2\":\"600\"},\"previousSibling\":{\"id\":2517},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2519,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"100\",\"y2\":\"600\"},\"previousSibling\":{\"id\":2518},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2520,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"733.3333333333333\",\"y2\":\"666.6666666666667\"},\"previousSibling\":{\"id\":2519},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2521,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"66.66666666666666\",\"y2\":\"666.6666666666667\"},\"previousSibling\":{\"id\":2520},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2522,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"766.6666666666667\",\"y2\":\"733.3333333333334\"},\"previousSibling\":{\"id\":2521},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2523,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"33.33333333333333\",\"y2\":\"733.3333333333334\"},\"previousSibling\":{\"id\":2522},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2524,\"tagName\":\"g\",\"attributes\":{},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2525,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2524},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2526,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2525},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2527,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2526},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2528,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2527},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2529,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2528},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2530,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2529},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2531,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2530},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2532,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2531},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2533,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2532},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2534,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2533},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2535,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2534},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2536,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2535},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2537,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2536},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2538,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2537},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2539,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2538},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2540,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2539},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2541,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2540},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2542,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"266.66666666666674\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2524}},{\"nodeType\":1,\"id\":2543,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"258.66666666666674\"},\"previousSibling\":{\"id\":2542},\"parentNode\":{\"id\":2524}},{\"nodeType\":1,\"id\":2544,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2525}},{\"nodeType\":1,\"id\":2545,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"592\"},\"previousSibling\":{\"id\":2544},\"parentNode\":{\"id\":2525}},{\"nodeType\":1,\"id\":2546,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"366.66666666666663\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2526}},{\"nodeType\":1,\"id\":2547,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"361.66666666666663\",\"y\":\"458.66666666666663\"},\"previousSibling\":{\"id\":2546},\"parentNode\":{\"id\":2526}},{\"nodeType\":1,\"id\":2548,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"666.6666666666667\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2527}},{\"nodeType\":1,\"id\":2549,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"661.6666666666667\",\"y\":\"658.6666666666667\"},\"previousSibling\":{\"id\":2548},\"parentNode\":{\"id\":2527}},{\"nodeType\":1,\"id\":2550,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"200\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2528}},{\"nodeType\":1,\"id\":2551,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"195\",\"y\":\"392\"},\"previousSibling\":{\"id\":2550},\"parentNode\":{\"id\":2528}},{\"nodeType\":1,\"id\":2552,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2529}},{\"nodeType\":1,\"id\":2553,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"525.3333333333334\"},\"previousSibling\":{\"id\":2552},\"parentNode\":{\"id\":2529}},{\"nodeType\":1,\"id\":2554,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2530}},{\"nodeType\":1,\"id\":2555,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"392\"},\"previousSibling\":{\"id\":2554},\"parentNode\":{\"id\":2530}},{\"nodeType\":1,\"id\":2556,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2531}},{\"nodeType\":1,\"id\":2557,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"458.66666666666663\"},\"previousSibling\":{\"id\":2556},\"parentNode\":{\"id\":2531}},{\"nodeType\":1,\"id\":2558,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"100\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2532}},{\"nodeType\":1,\"id\":2559,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"95\",\"y\":\"592\"},\"previousSibling\":{\"id\":2558},\"parentNode\":{\"id\":2532}},{\"nodeType\":1,\"id\":2560,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"133.33333333333331\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2533}},{\"nodeType\":1,\"id\":2561,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"128.33333333333331\",\"y\":\"658.6666666666667\"},\"previousSibling\":{\"id\":2560},\"parentNode\":{\"id\":2533}},{\"nodeType\":1,\"id\":2562,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"133.33333333333326\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2534}},{\"nodeType\":1,\"id\":2563,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"125.33333333333326\"},\"previousSibling\":{\"id\":2562},\"parentNode\":{\"id\":2534}},{\"nodeType\":1,\"id\":2564,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"333.3333333333333\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2535}},{\"nodeType\":1,\"id\":2565,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"325.3333333333333\"},\"previousSibling\":{\"id\":2564},\"parentNode\":{\"id\":2535}},{\"nodeType\":1,\"id\":2566,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"300\",\"cy\":\"733.3333333333334\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2536}},{\"nodeType\":1,\"id\":2567,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"295\",\"y\":\"725.3333333333334\"},\"previousSibling\":{\"id\":2566},\"parentNode\":{\"id\":2536}},{\"nodeType\":1,\"id\":2568,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"600\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2537}},{\"nodeType\":1,\"id\":2569,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"595\",\"y\":\"658.6666666666667\"},\"previousSibling\":{\"id\":2568},\"parentNode\":{\"id\":2537}},{\"nodeType\":1,\"id\":2570,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"433.3333333333333\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2538}},{\"nodeType\":1,\"id\":2571,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"428.3333333333333\",\"y\":\"592\"},\"previousSibling\":{\"id\":2570},\"parentNode\":{\"id\":2538}},{\"nodeType\":1,\"id\":2572,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"200\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2539}},{\"nodeType\":1,\"id\":2573,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"192\"},\"previousSibling\":{\"id\":2572},\"parentNode\":{\"id\":2539}},{\"nodeType\":1,\"id\":2574,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"533.3333333333333\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2540}},{\"nodeType\":1,\"id\":2575,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"528.3333333333333\",\"y\":\"525.3333333333334\"},\"previousSibling\":{\"id\":2574},\"parentNode\":{\"id\":2540}},{\"nodeType\":1,\"id\":2576,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2541}},{\"nodeType\":1,\"id\":2577,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"658.6666666666667\"},\"previousSibling\":{\"id\":2576},\"parentNode\":{\"id\":2541}},{\"nodeType\":3,\"id\":2578,\"textContent\":\"A \",\"parentNode\":{\"id\":2543}},{\"nodeType\":3,\"id\":2579,\"textContent\":\"B \",\"parentNode\":{\"id\":2545}},{\"nodeType\":3,\"id\":2580,\"textContent\":\"C \",\"parentNode\":{\"id\":2547}},{\"nodeType\":3,\"id\":2581,\"textContent\":\"D \",\"parentNode\":{\"id\":2549}},{\"nodeType\":3,\"id\":2582,\"textContent\":\"E \",\"parentNode\":{\"id\":2551}},{\"nodeType\":3,\"id\":2583,\"textContent\":\"F \",\"parentNode\":{\"id\":2553}},{\"nodeType\":3,\"id\":2584,\"textContent\":\"G \",\"parentNode\":{\"id\":2555}},{\"nodeType\":3,\"id\":2585,\"textContent\":\"H \",\"parentNode\":{\"id\":2557}},{\"nodeType\":3,\"id\":2586,\"textContent\":\"I \",\"parentNode\":{\"id\":2559}},{\"nodeType\":3,\"id\":2587,\"textContent\":\"J \",\"parentNode\":{\"id\":2561}},{\"nodeType\":3,\"id\":2588,\"textContent\":\"K \",\"parentNode\":{\"id\":2563}},{\"nodeType\":3,\"id\":2589,\"textContent\":\"L \",\"parentNode\":{\"id\":2565}},{\"nodeType\":3,\"id\":2590,\"textContent\":\"M \",\"parentNode\":{\"id\":2567}},{\"nodeType\":3,\"id\":2591,\"textContent\":\"N \",\"parentNode\":{\"id\":2569}},{\"nodeType\":3,\"id\":2592,\"textContent\":\"O \",\"parentNode\":{\"id\":2571}},{\"nodeType\":3,\"id\":2593,\"textContent\":\"P \",\"parentNode\":{\"id\":2573}},{\"nodeType\":3,\"id\":2594,\"textContent\":\"Z \",\"parentNode\":{\"id\":2575}},{\"nodeType\":3,\"id\":2595,\"textContent\":\"X \",\"parentNode\":{\"id\":2577}}],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":56},{\"id\":57},{\"id\":58},{\"id\":59},{\"id\":60},{\"id\":61},{\"id\":62},{\"id\":63},{\"id\":64},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":72},{\"id\":73},{\"id\":74},{\"id\":75},{\"id\":76},{\"id\":77},{\"id\":78},{\"id\":79},{\"id\":80},{\"id\":81},{\"id\":82},{\"id\":83},{\"id\":84},{\"id\":85},{\"id\":86},{\"id\":87},{\"id\":88},{\"id\":89},{\"id\":90},{\"id\":91},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":96},{\"id\":97},{\"id\":98},{\"id\":99},{\"id\":100},{\"id\":101},{\"id\":102},{\"id\":103},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":109},{\"id\":110},{\"id\":111},{\"id\":112},{\"id\":113},{\"id\":114},{\"id\":115},{\"id\":116},{\"id\":117},{\"id\":118},{\"id\":119},{\"id\":120},{\"id\":121},{\"id\":122},{\"id\":123},{\"id\":124},{\"id\":125},{\"id\":126},{\"id\":127},{\"id\":128},{\"id\":129},{\"id\":130},{\"id\":131},{\"id\":132},{\"id\":133},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":141},{\"id\":142},{\"id\":143},{\"id\":144},{\"id\":145},{\"id\":146},{\"id\":147},{\"id\":148},{\"id\":149},{\"id\":150},{\"id\":151},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":155},{\"id\":156},{\"id\":157},{\"id\":158},{\"id\":159},{\"id\":160},{\"id\":161},{\"id\":162},{\"id\":163},{\"id\":164},{\"id\":165},{\"id\":166},{\"id\":167},{\"id\":168},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":172},{\"id\":173},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":178},{\"id\":179},{\"id\":180},{\"id\":181},{\"id\":182},{\"id\":183},{\"id\":184},{\"id\":185},{\"id\":186},{\"id\":187},{\"id\":188},{\"id\":189},{\"id\":190},{\"id\":191},{\"id\":192},{\"id\":193},{\"id\":194},{\"id\":195},{\"id\":196},{\"id\":197},{\"id\":198},{\"id\":199},{\"id\":200},{\"id\":201},{\"id\":202},{\"id\":203},{\"id\":204},{\"id\":205},{\"id\":206},{\"id\":207},{\"id\":208},{\"id\":209},{\"id\":210},{\"id\":211},{\"id\":212},{\"id\":213},{\"id\":214},{\"id\":215},{\"id\":216},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":220},{\"id\":221},{\"id\":222},{\"id\":223},{\"id\":224},{\"id\":225},{\"id\":226},{\"id\":227},{\"id\":228},{\"id\":229},{\"id\":230},{\"id\":231},{\"id\":232},{\"id\":233},{\"id\":234},{\"id\":235},{\"id\":236},{\"id\":237},{\"id\":238},{\"id\":239},{\"id\":240},{\"id\":241},{\"id\":242},{\"id\":243},{\"id\":244},{\"id\":245},{\"id\":246},{\"id\":247},{\"id\":248},{\"id\":249},{\"id\":250},{\"id\":251},{\"id\":252},{\"id\":253},{\"id\":254},{\"id\":255},{\"id\":256},{\"id\":257},{\"id\":258},{\"id\":259},{\"id\":260},{\"id\":261},{\"id\":262},{\"id\":263},{\"id\":264},{\"id\":265},{\"id\":266},{\"id\":267},{\"id\":268},{\"id\":269},{\"id\":270},{\"id\":271},{\"id\":272},{\"id\":273},{\"id\":274},{\"id\":275},{\"id\":276},{\"id\":277},{\"id\":278},{\"id\":279},{\"id\":280},{\"id\":281},{\"id\":282},{\"id\":283},{\"id\":284},{\"id\":285},{\"id\":286},{\"id\":287},{\"id\":288},{\"id\":289},{\"id\":290},{\"id\":291},{\"id\":292},{\"id\":293},{\"id\":294},{\"id\":295},{\"id\":296},{\"id\":297},{\"id\":298},{\"id\":299},{\"id\":300},{\"id\":301},{\"id\":302},{\"id\":303},{\"id\":304},{\"id\":305},{\"id\":306},{\"id\":307},{\"id\":308},{\"id\":309},{\"id\":310},{\"id\":311},{\"id\":312},{\"id\":313},{\"id\":314},{\"id\":315},{\"id\":316},{\"id\":317},{\"id\":318},{\"id\":319},{\"id\":320},{\"id\":321},{\"id\":322},{\"id\":323},{\"id\":324},{\"id\":325},{\"id\":326},{\"id\":327},{\"id\":328},{\"id\":329},{\"id\":330},{\"id\":331},{\"id\":332},{\"id\":333},{\"id\":334},{\"id\":335},{\"id\":336},{\"id\":337},{\"id\":338},{\"id\":339},{\"id\":340},{\"id\":341},{\"id\":342},{\"id\":343},{\"id\":344},{\"id\":345},{\"id\":346},{\"id\":347},{\"id\":348},{\"id\":349},{\"id\":350},{\"id\":351},{\"id\":352},{\"id\":353},{\"id\":354},{\"id\":355},{\"id\":356},{\"id\":357},{\"id\":358},{\"id\":359},{\"id\":360},{\"id\":361},{\"id\":362},{\"id\":363},{\"id\":364},{\"id\":365},{\"id\":366},{\"id\":367},{\"id\":368},{\"id\":369},{\"id\":370},{\"id\":371},{\"id\":372},{\"id\":373},{\"id\":374},{\"id\":375},{\"id\":376},{\"id\":377},{\"id\":378},{\"id\":379},{\"id\":380},{\"id\":381},{\"id\":382},{\"id\":383},{\"id\":384},{\"id\":385},{\"id\":386},{\"id\":387},{\"id\":388},{\"id\":389},{\"id\":390},{\"id\":391},{\"id\":392},{\"id\":393},{\"id\":394},{\"id\":395},{\"id\":396},{\"id\":397},{\"id\":398},{\"id\":399},{\"id\":400},{\"id\":401},{\"id\":402},{\"id\":403},{\"id\":404},{\"id\":405},{\"id\":406},{\"id\":407},{\"id\":408},{\"id\":409},{\"id\":410},{\"id\":411},{\"id\":412},{\"id\":413},{\"id\":414},{\"id\":415},{\"id\":416},{\"id\":417},{\"id\":418},{\"id\":419},{\"id\":420},{\"id\":421},{\"id\":422},{\"id\":423},{\"id\":424},{\"id\":425},{\"id\":426},{\"id\":427},{\"id\":428},{\"id\":429},{\"id\":430},{\"id\":431},{\"id\":432},{\"id\":433},{\"id\":434},{\"id\":435},{\"id\":436},{\"id\":437},{\"id\":438},{\"id\":439},{\"id\":440},{\"id\":441},{\"id\":442},{\"id\":443},{\"id\":444},{\"id\":445},{\"id\":446},{\"id\":447},{\"id\":448},{\"id\":449},{\"id\":450},{\"id\":451},{\"id\":452},{\"id\":453},{\"id\":454},{\"id\":455},{\"id\":456},{\"id\":457},{\"id\":458},{\"id\":459},{\"id\":460},{\"id\":461},{\"id\":462},{\"id\":463},{\"id\":464},{\"id\":465},{\"id\":466},{\"id\":467},{\"id\":468},{\"id\":469},{\"id\":470},{\"id\":471},{\"id\":472},{\"id\":473},{\"id\":474},{\"id\":475},{\"id\":476},{\"id\":477},{\"id\":478},{\"id\":479},{\"id\":480},{\"id\":481},{\"id\":482},{\"id\":483},{\"id\":484},{\"id\":485},{\"id\":486},{\"id\":487},{\"id\":488},{\"id\":489},{\"id\":490},{\"id\":491},{\"id\":492},{\"id\":493},{\"id\":494},{\"id\":495},{\"id\":496},{\"id\":497},{\"id\":498},{\"id\":499},{\"id\":500},{\"id\":501},{\"id\":502},{\"id\":503},{\"id\":504},{\"id\":505},{\"id\":506},{\"id\":507},{\"id\":508},{\"id\":509},{\"id\":510},{\"id\":511},{\"id\":512},{\"id\":513},{\"id\":514},{\"id\":515},{\"id\":516},{\"id\":517},{\"id\":518},{\"id\":519},{\"id\":520},{\"id\":521},{\"id\":522},{\"id\":523},{\"id\":524},{\"id\":525},{\"id\":526},{\"id\":527},{\"id\":528},{\"id\":529},{\"id\":530},{\"id\":531},{\"id\":532},{\"id\":533},{\"id\":534},{\"id\":535},{\"id\":536},{\"id\":537},{\"id\":538},{\"id\":539},{\"id\":540},{\"id\":541},{\"id\":542},{\"id\":543},{\"id\":544},{\"id\":545},{\"id\":546},{\"id\":547},{\"id\":548},{\"id\":549},{\"id\":550},{\"id\":551},{\"id\":552},{\"id\":553},{\"id\":554},{\"id\":555},{\"id\":556},{\"id\":557},{\"id\":558},{\"id\":559},{\"id\":560},{\"id\":561},{\"id\":562},{\"id\":563},{\"id\":564},{\"id\":565},{\"id\":566},{\"id\":567},{\"id\":568},{\"id\":569},{\"id\":570},{\"id\":571},{\"id\":572},{\"id\":573},{\"id\":574},{\"id\":575},{\"id\":576},{\"id\":577},{\"id\":578},{\"id\":579},{\"id\":580},{\"id\":581},{\"id\":582},{\"id\":583},{\"id\":584},{\"id\":585},{\"id\":586},{\"id\":587},{\"id\":588},{\"id\":589},{\"id\":590},{\"id\":591},{\"id\":592},{\"id\":593},{\"id\":594},{\"id\":595},{\"id\":596},{\"id\":597},{\"id\":598},{\"id\":599},{\"id\":600},{\"id\":601},{\"id\":602},{\"id\":603},{\"id\":604},{\"id\":605},{\"id\":606},{\"id\":607},{\"id\":608},{\"id\":609},{\"id\":610},{\"id\":611},{\"id\":612},{\"id\":613},{\"id\":614},{\"id\":615},{\"id\":616},{\"id\":617},{\"id\":618},{\"id\":619},{\"id\":620},{\"id\":621},{\"id\":622},{\"id\":623},{\"id\":624},{\"id\":625},{\"id\":626},{\"id\":627},{\"id\":628},{\"id\":629},{\"id\":630},{\"id\":631},{\"id\":632},{\"id\":633},{\"id\":634},{\"id\":635},{\"id\":636},{\"id\":637},{\"id\":638},{\"id\":639},{\"id\":640},{\"id\":641},{\"id\":642},{\"id\":643},{\"id\":644},{\"id\":645},{\"id\":646},{\"id\":647},{\"id\":648},{\"id\":649},{\"id\":650},{\"id\":651},{\"id\":652},{\"id\":653},{\"id\":654},{\"id\":655},{\"id\":656},{\"id\":657},{\"id\":658},{\"id\":659},{\"id\":660},{\"id\":661},{\"id\":662},{\"id\":663},{\"id\":664},{\"id\":665},{\"id\":666},{\"id\":667},{\"id\":668},{\"id\":669},{\"id\":670},{\"id\":671},{\"id\":672},{\"id\":673},{\"id\":674},{\"id\":675},{\"id\":676},{\"id\":677},{\"id\":678},{\"id\":679},{\"id\":680},{\"id\":681},{\"id\":682},{\"id\":683},{\"id\":684},{\"id\":685},{\"id\":686},{\"id\":687},{\"id\":688},{\"id\":689},{\"id\":690},{\"id\":691},{\"id\":692},{\"id\":693},{\"id\":694},{\"id\":695},{\"id\":696},{\"id\":697},{\"id\":698},{\"id\":699},{\"id\":700},{\"id\":701},{\"id\":702},{\"id\":703},{\"id\":704},{\"id\":705},{\"id\":706},{\"id\":707},{\"id\":708},{\"id\":709},{\"id\":710},{\"id\":711},{\"id\":712},{\"id\":713},{\"id\":714},{\"id\":715},{\"id\":716},{\"id\":717},{\"id\":718},{\"id\":719},{\"id\":720},{\"id\":721},{\"id\":722},{\"id\":723},{\"id\":724},{\"id\":725},{\"id\":726},{\"id\":727},{\"id\":728},{\"id\":729},{\"id\":730},{\"id\":731},{\"id\":732},{\"id\":733},{\"id\":734},{\"id\":735},{\"id\":736},{\"id\":737},{\"id\":738},{\"id\":739},{\"id\":740},{\"id\":741},{\"id\":742},{\"id\":743},{\"id\":744},{\"id\":745},{\"id\":746},{\"id\":747},{\"id\":748},{\"id\":749},{\"id\":750},{\"id\":751},{\"id\":752},{\"id\":753},{\"id\":754},{\"id\":755},{\"id\":756},{\"id\":757},{\"id\":758},{\"id\":759},{\"id\":760},{\"id\":761},{\"id\":762},{\"id\":763},{\"id\":764},{\"id\":765},{\"id\":766},{\"id\":767},{\"id\":768},{\"id\":769},{\"id\":770},{\"id\":771},{\"id\":772},{\"id\":773},{\"id\":774},{\"id\":775},{\"id\":776},{\"id\":777},{\"id\":778},{\"id\":779},{\"id\":780},{\"id\":781},{\"id\":782},{\"id\":783},{\"id\":784},{\"id\":785},{\"id\":786},{\"id\":787},{\"id\":788},{\"id\":789},{\"id\":790},{\"id\":791},{\"id\":792},{\"id\":793},{\"id\":794},{\"id\":795},{\"id\":796},{\"id\":797},{\"id\":798},{\"id\":799},{\"id\":800},{\"id\":801},{\"id\":802},{\"id\":803},{\"id\":804},{\"id\":805},{\"id\":806},{\"id\":807},{\"id\":808},{\"id\":809},{\"id\":810},{\"id\":811},{\"id\":812},{\"id\":813},{\"id\":814},{\"id\":815},{\"id\":816},{\"id\":817},{\"id\":818},{\"id\":819},{\"id\":820},{\"id\":821},{\"id\":822},{\"id\":823},{\"id\":824},{\"id\":825},{\"id\":826},{\"id\":827},{\"id\":828},{\"id\":829},{\"id\":830},{\"id\":831},{\"id\":832},{\"id\":833},{\"id\":834},{\"id\":835},{\"id\":836},{\"id\":837},{\"id\":838},{\"id\":839},{\"id\":840},{\"id\":841},{\"id\":842},{\"id\":843},{\"id\":844},{\"id\":845},{\"id\":846},{\"id\":847},{\"id\":848},{\"id\":849},{\"id\":850},{\"id\":851},{\"id\":852},{\"id\":853},{\"id\":854},{\"id\":855},{\"id\":856},{\"id\":857},{\"id\":858},{\"id\":859},{\"id\":860},{\"id\":861},{\"id\":862},{\"id\":863},{\"id\":864},{\"id\":865},{\"id\":866},{\"id\":867},{\"id\":868},{\"id\":869},{\"id\":870},{\"id\":871},{\"id\":872},{\"id\":873},{\"id\":874},{\"id\":875},{\"id\":876},{\"id\":877},{\"id\":878},{\"id\":879},{\"id\":880},{\"id\":881},{\"id\":882},{\"id\":883},{\"id\":884},{\"id\":885},{\"id\":886},{\"id\":887},{\"id\":888},{\"id\":889},{\"id\":890},{\"id\":891},{\"id\":892},{\"id\":893},{\"id\":894},{\"id\":895},{\"id\":896},{\"id\":897},{\"id\":898},{\"id\":899},{\"id\":900},{\"id\":901},{\"id\":902},{\"id\":903},{\"id\":904},{\"id\":905},{\"id\":906},{\"id\":907},{\"id\":908},{\"id\":909},{\"id\":910},{\"id\":911},{\"id\":912},{\"id\":913},{\"id\":914},{\"id\":915},{\"id\":916},{\"id\":917},{\"id\":918},{\"id\":919},{\"id\":920},{\"id\":921},{\"id\":922},{\"id\":923},{\"id\":924},{\"id\":925},{\"id\":926},{\"id\":927},{\"id\":928},{\"id\":929},{\"id\":930},{\"id\":931},{\"id\":932},{\"id\":933},{\"id\":934},{\"id\":935},{\"id\":936},{\"id\":937},{\"id\":938},{\"id\":939},{\"id\":940},{\"id\":941},{\"id\":942},{\"id\":943},{\"id\":944},{\"id\":945},{\"id\":946},{\"id\":947},{\"id\":948},{\"id\":949},{\"id\":950},{\"id\":951},{\"id\":952},{\"id\":953},{\"id\":954},{\"id\":955},{\"id\":956},{\"id\":957},{\"id\":958},{\"id\":959},{\"id\":960},{\"id\":961},{\"id\":962},{\"id\":963},{\"id\":964},{\"id\":965},{\"id\":966},{\"id\":967},{\"id\":968},{\"id\":969},{\"id\":970},{\"id\":971},{\"id\":972},{\"id\":973},{\"id\":974},{\"id\":975},{\"id\":976},{\"id\":977},{\"id\":978},{\"id\":979},{\"id\":980},{\"id\":981},{\"id\":982},{\"id\":983},{\"id\":984},{\"id\":985},{\"id\":986},{\"id\":987},{\"id\":988},{\"id\":989},{\"id\":990},{\"id\":991},{\"id\":992},{\"id\":993},{\"id\":994},{\"id\":995},{\"id\":996},{\"id\":997},{\"id\":998},{\"id\":999},{\"id\":1000},{\"id\":1001},{\"id\":1002},{\"id\":1003},{\"id\":1004},{\"id\":1005},{\"id\":1006},{\"id\":1007},{\"id\":1008},{\"id\":1009},{\"id\":1010},{\"id\":1011},{\"id\":1012},{\"id\":1013},{\"id\":1014},{\"id\":1015},{\"id\":1016},{\"id\":1017},{\"id\":1018},{\"id\":1019},{\"id\":1020},{\"id\":1021},{\"id\":1022},{\"id\":1023},{\"id\":1024},{\"id\":1025},{\"id\":1026},{\"id\":1027},{\"id\":1028},{\"id\":1029},{\"id\":1030},{\"id\":1031},{\"id\":1032},{\"id\":1033},{\"id\":1034},{\"id\":1035},{\"id\":1036},{\"id\":1037},{\"id\":1038},{\"id\":1039},{\"id\":1040},{\"id\":1041},{\"id\":1042},{\"id\":1043},{\"id\":1044},{\"id\":1045},{\"id\":1046},{\"id\":1047},{\"id\":1048},{\"id\":1049},{\"id\":1050},{\"id\":1051},{\"id\":1052},{\"id\":1053},{\"id\":1054},{\"id\":1055},{\"id\":1056},{\"id\":1057},{\"id\":1058},{\"id\":1059},{\"id\":1060},{\"id\":1061},{\"id\":1062},{\"id\":1063},{\"id\":1064},{\"id\":1065},{\"id\":1066},{\"id\":1067},{\"id\":1068},{\"id\":1069},{\"id\":1070},{\"id\":1071},{\"id\":1072},{\"id\":1073},{\"id\":1074},{\"id\":1075},{\"id\":1076},{\"id\":1077},{\"id\":1078},{\"id\":1079},{\"id\":1080},{\"id\":1081},{\"id\":1082},{\"id\":1083},{\"id\":1084},{\"id\":1085},{\"id\":1086},{\"id\":1087},{\"id\":1088},{\"id\":1089},{\"id\":1090},{\"id\":1091},{\"id\":1092},{\"id\":1093},{\"id\":1094},{\"id\":1095},{\"id\":1096},{\"id\":1097},{\"id\":1098},{\"id\":1099},{\"id\":1100},{\"id\":1101},{\"id\":1102},{\"id\":1103},{\"id\":1104},{\"id\":1105},{\"id\":1106},{\"id\":1107},{\"id\":1108},{\"id\":1109},{\"id\":1110},{\"id\":1111},{\"id\":1112},{\"id\":1113},{\"id\":1114},{\"id\":1115},{\"id\":1116},{\"id\":1117},{\"id\":1118},{\"id\":1119},{\"id\":1120},{\"id\":1121},{\"id\":1122},{\"id\":1123},{\"id\":1124},{\"id\":1125},{\"id\":1126},{\"id\":1127},{\"id\":1128},{\"id\":1129},{\"id\":1130},{\"id\":1131},{\"id\":1132},{\"id\":1133},{\"id\":1134},{\"id\":1135},{\"id\":1136},{\"id\":1137},{\"id\":1138},{\"id\":1139},{\"id\":1140},{\"id\":1141},{\"id\":1142},{\"id\":1143},{\"id\":1144},{\"id\":1145},{\"id\":1146},{\"id\":1147},{\"id\":1148},{\"id\":1149},{\"id\":1150},{\"id\":1151},{\"id\":1152},{\"id\":1153},{\"id\":1154},{\"id\":1155},{\"id\":1156},{\"id\":1157},{\"id\":1158},{\"id\":1159},{\"id\":1160},{\"id\":1161},{\"id\":1162},{\"id\":1163},{\"id\":1164},{\"id\":1165},{\"id\":1166},{\"id\":1167},{\"id\":1168},{\"id\":1169},{\"id\":1170},{\"id\":1171},{\"id\":1172},{\"id\":1173},{\"id\":1174},{\"id\":1175},{\"id\":1176},{\"id\":1177},{\"id\":1178},{\"id\":1179},{\"id\":1180},{\"id\":1181},{\"id\":1182},{\"id\":1183},{\"id\":1184},{\"id\":1185},{\"id\":1186},{\"id\":1187},{\"id\":1188},{\"id\":1189},{\"id\":1190},{\"id\":1191},{\"id\":1192},{\"id\":1193},{\"id\":1194},{\"id\":1195},{\"id\":1196},{\"id\":1197},{\"id\":1198},{\"id\":1199},{\"id\":1200},{\"id\":1201},{\"id\":1202},{\"id\":1203},{\"id\":1204},{\"id\":1205},{\"id\":1206},{\"id\":1207},{\"id\":1208},{\"id\":1209},{\"id\":1210},{\"id\":1211},{\"id\":1212},{\"id\":1213},{\"id\":1214},{\"id\":1215},{\"id\":1216},{\"id\":1217},{\"id\":1218},{\"id\":1219},{\"id\":1220},{\"id\":1221},{\"id\":1222},{\"id\":1223},{\"id\":1224},{\"id\":1225},{\"id\":1226},{\"id\":1227},{\"id\":1228},{\"id\":1229},{\"id\":1230},{\"id\":1231},{\"id\":1232},{\"id\":1233},{\"id\":1234},{\"id\":1235},{\"id\":1236},{\"id\":1237},{\"id\":1238},{\"id\":1239},{\"id\":1240},{\"id\":1241},{\"id\":1242},{\"id\":1243},{\"id\":1244},{\"id\":1245},{\"id\":1246},{\"id\":1247},{\"id\":1248},{\"id\":1249},{\"id\":1250},{\"id\":1251},{\"id\":1252},{\"id\":1253},{\"id\":1254},{\"id\":1255},{\"id\":1256},{\"id\":1257},{\"id\":1258},{\"id\":1259},{\"id\":1260},{\"id\":1261},{\"id\":1262},{\"id\":1263},{\"id\":1264},{\"id\":1265},{\"id\":1266},{\"id\":1267},{\"id\":1268},{\"id\":1269},{\"id\":1270},{\"id\":1271},{\"id\":1272},{\"id\":1273},{\"id\":1274},{\"id\":1275},{\"id\":1276},{\"id\":1277},{\"id\":1278},{\"id\":1279},{\"id\":1280},{\"id\":1281},{\"id\":1282},{\"id\":1283},{\"id\":1284},{\"id\":1285},{\"id\":1286},{\"id\":1287},{\"id\":1288},{\"id\":1289},{\"id\":1290},{\"id\":1291},{\"id\":1292},{\"id\":1293},{\"id\":1294},{\"id\":1295},{\"id\":1296},{\"id\":1297},{\"id\":1298},{\"id\":1299},{\"id\":1300},{\"id\":1301},{\"id\":1302},{\"id\":1303},{\"id\":1304},{\"id\":1305},{\"id\":1306},{\"id\":1307},{\"id\":1308},{\"id\":1309},{\"id\":1310},{\"id\":1311},{\"id\":1312},{\"id\":1313},{\"id\":1314},{\"id\":1315},{\"id\":1316},{\"id\":1317},{\"id\":1318},{\"id\":1319},{\"id\":1320},{\"id\":1321},{\"id\":1322},{\"id\":1323},{\"id\":1324},{\"id\":1325},{\"id\":1326},{\"id\":1327},{\"id\":1328},{\"id\":1329},{\"id\":1330},{\"id\":1331},{\"id\":1332},{\"id\":1333},{\"id\":1334},{\"id\":1335},{\"id\":1336},{\"id\":1337},{\"id\":1338},{\"id\":1339},{\"id\":1340},{\"id\":1341},{\"id\":1342},{\"id\":1343},{\"id\":1344},{\"id\":1345},{\"id\":1346},{\"id\":1347},{\"id\":1348},{\"id\":1349},{\"id\":1350},{\"id\":1351},{\"id\":1352},{\"id\":1353},{\"id\":1354},{\"id\":1355},{\"id\":1356},{\"id\":1357},{\"id\":1358},{\"id\":1359},{\"id\":1360},{\"id\":1361},{\"id\":1362},{\"id\":1363},{\"id\":1364},{\"id\":1365},{\"id\":1366},{\"id\":1367},{\"id\":1368},{\"id\":1369},{\"id\":1370},{\"id\":1371},{\"id\":1372},{\"id\":1373},{\"id\":1374},{\"id\":1375},{\"id\":1376},{\"id\":1377},{\"id\":1378},{\"id\":1379},{\"id\":1380},{\"id\":1381},{\"id\":1382},{\"id\":1383},{\"id\":1384},{\"id\":1385},{\"id\":1386},{\"id\":1387},{\"id\":1388},{\"id\":1389},{\"id\":1390},{\"id\":1391},{\"id\":1392},{\"id\":1393},{\"id\":1394},{\"id\":1395},{\"id\":1396},{\"id\":1397},{\"id\":1398},{\"id\":1399},{\"id\":1400},{\"id\":1401},{\"id\":1402},{\"id\":1403},{\"id\":1404},{\"id\":1405},{\"id\":1406},{\"id\":1407},{\"id\":1408},{\"id\":1409},{\"id\":1410},{\"id\":1411},{\"id\":1412},{\"id\":1413},{\"id\":1414},{\"id\":1415},{\"id\":1416},{\"id\":1417},{\"id\":1418},{\"id\":1419},{\"id\":1420},{\"id\":1421},{\"id\":1422},{\"id\":1423},{\"id\":1424},{\"id\":1425},{\"id\":1426},{\"id\":1427},{\"id\":1428},{\"id\":1429},{\"id\":1430},{\"id\":1431},{\"id\":1432},{\"id\":1433},{\"id\":1434},{\"id\":1435},{\"id\":1436},{\"id\":1437},{\"id\":1438},{\"id\":1439},{\"id\":1440},{\"id\":1441},{\"id\":1442},{\"id\":1443},{\"id\":1444},{\"id\":1445},{\"id\":1446},{\"id\":1447},{\"id\":1448},{\"id\":1449},{\"id\":1450},{\"id\":1451},{\"id\":1452},{\"id\":1453},{\"id\":1454},{\"id\":1455},{\"id\":1456},{\"id\":1457},{\"id\":1458},{\"id\":1459},{\"id\":1460},{\"id\":1461},{\"id\":1462},{\"id\":1463},{\"id\":1464},{\"id\":1465},{\"id\":1466},{\"id\":1467},{\"id\":1468},{\"id\":1469},{\"id\":1470},{\"id\":1471},{\"id\":1472},{\"id\":1473},{\"id\":1474},{\"id\":1475},{\"id\":1476},{\"id\":1477},{\"id\":1478},{\"id\":1479},{\"id\":1480},{\"id\":1481},{\"id\":1482},{\"id\":1483},{\"id\":1484},{\"id\":1485},{\"id\":1486},{\"id\":1487},{\"id\":1488},{\"id\":1489},{\"id\":1490},{\"id\":1491},{\"id\":1492},{\"id\":1493},{\"id\":1494},{\"id\":1495},{\"id\":1496},{\"id\":1497},{\"id\":1498},{\"id\":1499},{\"id\":1500},{\"id\":1501},{\"id\":1502},{\"id\":1503},{\"id\":1504},{\"id\":1505},{\"id\":1506},{\"id\":1507},{\"id\":1508},{\"id\":1509},{\"id\":1510},{\"id\":1511},{\"id\":1512},{\"id\":1513},{\"id\":1514},{\"id\":1515},{\"id\":1516},{\"id\":1517},{\"id\":1518},{\"id\":1519},{\"id\":1520},{\"id\":1521},{\"id\":1522},{\"id\":1523},{\"id\":1524},{\"id\":1525},{\"id\":1526},{\"id\":1527},{\"id\":1528},{\"id\":1529},{\"id\":1530},{\"id\":1531},{\"id\":1532},{\"id\":1533},{\"id\":1534},{\"id\":1535},{\"id\":1536},{\"id\":1537},{\"id\":1538},{\"id\":1539},{\"id\":1540},{\"id\":1541},{\"id\":1542},{\"id\":1543},{\"id\":1544},{\"id\":1545},{\"id\":1546},{\"id\":1547},{\"id\":1548},{\"id\":1549},{\"id\":1550},{\"id\":1551},{\"id\":1552},{\"id\":1553},{\"id\":1554},{\"id\":1555},{\"id\":1556},{\"id\":1557},{\"id\":1558},{\"id\":1559},{\"id\":1560},{\"id\":1561},{\"id\":1562},{\"id\":1563},{\"id\":1564},{\"id\":1565},{\"id\":1566},{\"id\":1567},{\"id\":1568},{\"id\":1569},{\"id\":1570},{\"id\":1571},{\"id\":1572},{\"id\":1573},{\"id\":1574},{\"id\":1575},{\"id\":1576},{\"id\":1577},{\"id\":1578},{\"id\":1579},{\"id\":1580},{\"id\":1581},{\"id\":1582},{\"id\":1583},{\"id\":1584},{\"id\":1585},{\"id\":1586},{\"id\":1587},{\"id\":1588},{\"id\":1589},{\"id\":1590},{\"id\":1591},{\"id\":1592},{\"id\":1593},{\"id\":1594},{\"id\":1595},{\"id\":1596},{\"id\":1597},{\"id\":1598},{\"id\":1599},{\"id\":1600},{\"id\":1601},{\"id\":1602},{\"id\":1603},{\"id\":1604},{\"id\":1605},{\"id\":1606},{\"id\":1607},{\"id\":1608},{\"id\":1609},{\"id\":1610},{\"id\":1611},{\"id\":1612},{\"id\":1613},{\"id\":1614},{\"id\":1615},{\"id\":1616},{\"id\":1617},{\"id\":1618},{\"id\":1619},{\"id\":1620},{\"id\":1621},{\"id\":1622},{\"id\":1623},{\"id\":1624},{\"id\":1625},{\"id\":1626},{\"id\":1627},{\"id\":1628},{\"id\":1629},{\"id\":1630},{\"id\":1631},{\"id\":1632},{\"id\":1633},{\"id\":1634},{\"id\":1635},{\"id\":1636},{\"id\":1637},{\"id\":1638},{\"id\":1639},{\"id\":1640},{\"id\":1641},{\"id\":1642},{\"id\":1643},{\"id\":1644},{\"id\":1645},{\"id\":1646},{\"id\":1647},{\"id\":1648},{\"id\":1649},{\"id\":1650},{\"id\":1651},{\"id\":1652},{\"id\":1653},{\"id\":1654},{\"id\":1655},{\"id\":1656},{\"id\":1657},{\"id\":1658},{\"id\":1659},{\"id\":1660},{\"id\":1661},{\"id\":1662},{\"id\":1663},{\"id\":1664},{\"id\":1665},{\"id\":1666},{\"id\":1667},{\"id\":1668},{\"id\":1669},{\"id\":1670},{\"id\":1671},{\"id\":1672},{\"id\":1673},{\"id\":1674},{\"id\":1675},{\"id\":1676},{\"id\":1677},{\"id\":1678},{\"id\":1679},{\"id\":1680},{\"id\":1681},{\"id\":1682},{\"id\":1683},{\"id\":1684},{\"id\":1685},{\"id\":1686},{\"id\":1687},{\"id\":1688},{\"id\":1689},{\"id\":1690},{\"id\":1691},{\"id\":1692},{\"id\":1693},{\"id\":1694},{\"id\":1695},{\"id\":1696},{\"id\":1697},{\"id\":1698},{\"id\":1699},{\"id\":1700},{\"id\":1701},{\"id\":1702},{\"id\":1703},{\"id\":1704},{\"id\":1705},{\"id\":1706},{\"id\":1707},{\"id\":1708},{\"id\":1709},{\"id\":1710},{\"id\":1711},{\"id\":1712},{\"id\":1713},{\"id\":1714},{\"id\":1715},{\"id\":1716},{\"id\":1717},{\"id\":1718},{\"id\":1719},{\"id\":1720},{\"id\":1721},{\"id\":1722},{\"id\":1723},{\"id\":1724},{\"id\":1725},{\"id\":1726},{\"id\":1727},{\"id\":1728},{\"id\":1729},{\"id\":1730},{\"id\":1731},{\"id\":1732},{\"id\":1733},{\"id\":1734},{\"id\":1735},{\"id\":1736},{\"id\":1737},{\"id\":1738},{\"id\":1739},{\"id\":1740},{\"id\":1741},{\"id\":1742},{\"id\":1743},{\"id\":1744},{\"id\":1745},{\"id\":1746},{\"id\":1747},{\"id\":1748},{\"id\":1749},{\"id\":1750},{\"id\":1751},{\"id\":1752},{\"id\":1753},{\"id\":1754},{\"id\":1755},{\"id\":1756},{\"id\":1757},{\"id\":1758},{\"id\":1759},{\"id\":1760},{\"id\":1761},{\"id\":1762},{\"id\":1763},{\"id\":1764},{\"id\":1765},{\"id\":1766},{\"id\":1767},{\"id\":1768},{\"id\":1769},{\"id\":1770},{\"id\":1771},{\"id\":1772},{\"id\":1773},{\"id\":1774},{\"id\":1775},{\"id\":1776},{\"id\":1777},{\"id\":1778},{\"id\":1779},{\"id\":1780},{\"id\":1781},{\"id\":1782},{\"id\":1783},{\"id\":1784},{\"id\":1785},{\"id\":1786},{\"id\":1787},{\"id\":1788},{\"id\":1789},{\"id\":1790},{\"id\":1791},{\"id\":1792},{\"id\":1793},{\"id\":1794},{\"id\":1795},{\"id\":1796},{\"id\":1797},{\"id\":1798},{\"id\":1799},{\"id\":1800},{\"id\":1801},{\"id\":1802},{\"id\":1803},{\"id\":1804},{\"id\":1805},{\"id\":1806},{\"id\":1807},{\"id\":1808},{\"id\":1809},{\"id\":1810},{\"id\":1811},{\"id\":1812},{\"id\":1813},{\"id\":1814},{\"id\":1815},{\"id\":1816},{\"id\":1817},{\"id\":1818},{\"id\":1819},{\"id\":1820},{\"id\":1821},{\"id\":1822},{\"id\":1823},{\"id\":1824},{\"id\":1825},{\"id\":1826},{\"id\":1827},{\"id\":1828},{\"id\":1829},{\"id\":1830},{\"id\":1831},{\"id\":1832},{\"id\":1833},{\"id\":1834},{\"id\":1835},{\"id\":1836},{\"id\":1837},{\"id\":1838},{\"id\":1839},{\"id\":1840},{\"id\":1841},{\"id\":1842},{\"id\":1843},{\"id\":1844},{\"id\":1845},{\"id\":1846},{\"id\":1847},{\"id\":1848},{\"id\":1849},{\"id\":1850},{\"id\":1851},{\"id\":1852},{\"id\":1853},{\"id\":1854},{\"id\":1855},{\"id\":1856},{\"id\":1857},{\"id\":1858},{\"id\":1859},{\"id\":1860},{\"id\":1861},{\"id\":1862},{\"id\":1863},{\"id\":1864},{\"id\":1865},{\"id\":1866},{\"id\":1867},{\"id\":1868},{\"id\":1869},{\"id\":1870},{\"id\":1871},{\"id\":1872},{\"id\":1873},{\"id\":1874},{\"id\":1875},{\"id\":1876},{\"id\":1877},{\"id\":1878},{\"id\":1879},{\"id\":1880},{\"id\":1881},{\"id\":1882},{\"id\":1883},{\"id\":1884},{\"id\":1885},{\"id\":1886},{\"id\":1887},{\"id\":1888},{\"id\":1889},{\"id\":1890},{\"id\":1891},{\"id\":1892},{\"id\":1893},{\"id\":1894},{\"id\":1895},{\"id\":1896},{\"id\":1897},{\"id\":1898},{\"id\":1899},{\"id\":1900},{\"id\":1901},{\"id\":1902},{\"id\":1903},{\"id\":1904},{\"id\":1905},{\"id\":1906},{\"id\":1907},{\"id\":1908},{\"id\":1909},{\"id\":1910},{\"id\":1911},{\"id\":1912},{\"id\":1913},{\"id\":1914},{\"id\":1915},{\"id\":1916},{\"id\":1917},{\"id\":1918},{\"id\":1919},{\"id\":1920},{\"id\":1921},{\"id\":1922},{\"id\":1923},{\"id\":1924},{\"id\":1925},{\"id\":1926},{\"id\":1927},{\"id\":1928},{\"id\":1929},{\"id\":1930},{\"id\":1931},{\"id\":1932},{\"id\":1933},{\"id\":1934},{\"id\":1935},{\"id\":1936},{\"id\":1937},{\"id\":1938},{\"id\":1939},{\"id\":1940},{\"id\":1941},{\"id\":1942},{\"id\":1943},{\"id\":1944},{\"id\":1945},{\"id\":1946},{\"id\":1947},{\"id\":1948},{\"id\":1949},{\"id\":1950},{\"id\":1951},{\"id\":1952},{\"id\":1953},{\"id\":1954},{\"id\":1955},{\"id\":1956},{\"id\":1957},{\"id\":1958},{\"id\":1959},{\"id\":1960},{\"id\":1961},{\"id\":1962},{\"id\":1963},{\"id\":1964},{\"id\":1965},{\"id\":1966},{\"id\":1967},{\"id\":1968},{\"id\":1969},{\"id\":1970},{\"id\":1971},{\"id\":1972},{\"id\":1973},{\"id\":1974},{\"id\":1975},{\"id\":1976},{\"id\":1977},{\"id\":1978},{\"id\":1979},{\"id\":1980},{\"id\":1981},{\"id\":1982},{\"id\":1983},{\"id\":1984},{\"id\":1985},{\"id\":1986},{\"id\":1987},{\"id\":1988},{\"id\":1989},{\"id\":1990},{\"id\":1991},{\"id\":1992},{\"id\":1993},{\"id\":1994},{\"id\":1995},{\"id\":1996},{\"id\":1997},{\"id\":1998},{\"id\":1999},{\"id\":2000},{\"id\":2001},{\"id\":2002},{\"id\":2003},{\"id\":2004},{\"id\":2005},{\"id\":2006},{\"id\":2007},{\"id\":2008},{\"id\":2009},{\"id\":2010},{\"id\":2011},{\"id\":2012},{\"id\":2013},{\"id\":2014},{\"id\":2015},{\"id\":2016},{\"id\":2017},{\"id\":2018},{\"id\":2019},{\"id\":2020},{\"id\":2021},{\"id\":2022},{\"id\":2023},{\"id\":2024},{\"id\":2025},{\"id\":2026},{\"id\":2027},{\"id\":2028},{\"id\":2029},{\"id\":2030},{\"id\":2031},{\"id\":2032},{\"id\":2033},{\"id\":2034},{\"id\":2035},{\"id\":2036},{\"id\":2037},{\"id\":2038},{\"id\":2039},{\"id\":2040},{\"id\":2041},{\"id\":2042},{\"id\":2043},{\"id\":2044},{\"id\":2045},{\"id\":2046},{\"id\":2047},{\"id\":2048},{\"id\":2049},{\"id\":2050},{\"id\":2051},{\"id\":2052},{\"id\":2053},{\"id\":2054},{\"id\":2055},{\"id\":2056},{\"id\":2057},{\"id\":2058},{\"id\":2059},{\"id\":2060},{\"id\":2061},{\"id\":2062},{\"id\":2063},{\"id\":2064},{\"id\":2065},{\"id\":2066},{\"id\":2067},{\"id\":2068},{\"id\":2069},{\"id\":2070},{\"id\":2071},{\"id\":2072},{\"id\":2073},{\"id\":2074},{\"id\":2075},{\"id\":2076},{\"id\":2077},{\"id\":2078},{\"id\":2079},{\"id\":2080},{\"id\":2081},{\"id\":2082},{\"id\":2083},{\"id\":2084},{\"id\":2085},{\"id\":2086},{\"id\":2087},{\"id\":2088},{\"id\":2089},{\"id\":2090},{\"id\":2091},{\"id\":2092},{\"id\":2093},{\"id\":2094},{\"id\":2095},{\"id\":2096},{\"id\":2097},{\"id\":2098},{\"id\":2099},{\"id\":2100},{\"id\":2101},{\"id\":2102},{\"id\":2103},{\"id\":2104},{\"id\":2105},{\"id\":2106},{\"id\":2107},{\"id\":2108},{\"id\":2109},{\"id\":2110},{\"id\":2111},{\"id\":2112},{\"id\":2113},{\"id\":2114},{\"id\":2115},{\"id\":2116},{\"id\":2117},{\"id\":2118},{\"id\":2119},{\"id\":2120},{\"id\":2121},{\"id\":2122},{\"id\":2123},{\"id\":2124},{\"id\":2125},{\"id\":2126},{\"id\":2127},{\"id\":2128},{\"id\":2129},{\"id\":2130},{\"id\":2131},{\"id\":2132},{\"id\":2133},{\"id\":2134},{\"id\":2135},{\"id\":2136},{\"id\":2137},{\"id\":2138},{\"id\":2139},{\"id\":2140},{\"id\":2141},{\"id\":2142},{\"id\":2143},{\"id\":2144},{\"id\":2145},{\"id\":2146},{\"id\":2147},{\"id\":2148},{\"id\":2149},{\"id\":2150},{\"id\":2151},{\"id\":2152},{\"id\":2153},{\"id\":2154},{\"id\":2155},{\"id\":2156},{\"id\":2157},{\"id\":2158},{\"id\":2159},{\"id\":2160},{\"id\":2161},{\"id\":2162},{\"id\":2163},{\"id\":2164},{\"id\":2165},{\"id\":2166},{\"id\":2167},{\"id\":2168},{\"id\":2169},{\"id\":2170},{\"id\":2171},{\"id\":2172},{\"id\":2173},{\"id\":2174},{\"id\":2175},{\"id\":2176},{\"id\":2177},{\"id\":2178},{\"id\":2179},{\"id\":2180},{\"id\":2181},{\"id\":2182},{\"id\":2183},{\"id\":2184},{\"id\":2185},{\"id\":2186},{\"id\":2187},{\"id\":2188},{\"id\":2189},{\"id\":2190},{\"id\":2191},{\"id\":2192},{\"id\":2193},{\"id\":2194},{\"id\":2195},{\"id\":2196},{\"id\":2197},{\"id\":2198},{\"id\":2199},{\"id\":2200},{\"id\":2201},{\"id\":2202},{\"id\":2203},{\"id\":2204},{\"id\":2205},{\"id\":2206},{\"id\":2207},{\"id\":2208},{\"id\":2209},{\"id\":2210},{\"id\":2211},{\"id\":2212},{\"id\":2213},{\"id\":2214},{\"id\":2215},{\"id\":2216},{\"id\":2217},{\"id\":2218},{\"id\":2219},{\"id\":2220},{\"id\":2221},{\"id\":2222},{\"id\":2223},{\"id\":2224},{\"id\":2225},{\"id\":2226},{\"id\":2227},{\"id\":2228},{\"id\":2229},{\"id\":2230},{\"id\":2231},{\"id\":2232},{\"id\":2233},{\"id\":2234},{\"id\":2235},{\"id\":2236},{\"id\":2237},{\"id\":2238},{\"id\":2239},{\"id\":2240},{\"id\":2241},{\"id\":2242},{\"id\":2243},{\"id\":2244},{\"id\":2245},{\"id\":2246},{\"id\":2247},{\"id\":2248},{\"id\":2249},{\"id\":2250},{\"id\":2251},{\"id\":2252},{\"id\":2253},{\"id\":2254},{\"id\":2255},{\"id\":2256},{\"id\":2257},{\"id\":2258},{\"id\":2259},{\"id\":2260},{\"id\":2261},{\"id\":2262},{\"id\":2263},{\"id\":2264},{\"id\":2265},{\"id\":2266},{\"id\":2267},{\"id\":2268},{\"id\":2269},{\"id\":2270},{\"id\":2271},{\"id\":2272},{\"id\":2273},{\"id\":2274},{\"id\":2275},{\"id\":2276},{\"id\":2277},{\"id\":2278},{\"id\":2279},{\"id\":2280},{\"id\":2281},{\"id\":2282},{\"id\":2283},{\"id\":2284},{\"id\":2285},{\"id\":2286},{\"id\":2287},{\"id\":2288},{\"id\":2289},{\"id\":2290},{\"id\":2291},{\"id\":2292},{\"id\":2293},{\"id\":2294},{\"id\":2295},{\"id\":2296},{\"id\":2297},{\"id\":2298},{\"id\":2299},{\"id\":2300},{\"id\":2301},{\"id\":2302},{\"id\":2311},{\"id\":2316},{\"id\":2317},{\"id\":2343},{\"id\":2344},{\"id\":2393},{\"id\":2318},{\"id\":2345},{\"id\":2346},{\"id\":2394},{\"id\":2319},{\"id\":2347},{\"id\":2348},{\"id\":2395},{\"id\":2320},{\"id\":2349},{\"id\":2350},{\"id\":2396},{\"id\":2321},{\"id\":2351},{\"id\":2352},{\"id\":2397},{\"id\":2322},{\"id\":2353},{\"id\":2354},{\"id\":2398},{\"id\":2323},{\"id\":2355},{\"id\":2356},{\"id\":2399},{\"id\":2324},{\"id\":2357},{\"id\":2358},{\"id\":2400},{\"id\":2325},{\"id\":2359},{\"id\":2360},{\"id\":2401},{\"id\":2326},{\"id\":2361},{\"id\":2362},{\"id\":2402},{\"id\":2327},{\"id\":2363},{\"id\":2364},{\"id\":2403},{\"id\":2328},{\"id\":2365},{\"id\":2366},{\"id\":2404},{\"id\":2329},{\"id\":2367},{\"id\":2368},{\"id\":2405},{\"id\":2330},{\"id\":2369},{\"id\":2370},{\"id\":2406},{\"id\":2331},{\"id\":2371},{\"id\":2372},{\"id\":2407},{\"id\":2332},{\"id\":2373},{\"id\":2374},{\"id\":2408},{\"id\":2333},{\"id\":2375},{\"id\":2376},{\"id\":2409},{\"id\":2334},{\"id\":2377},{\"id\":2378},{\"id\":2410},{\"id\":2335},{\"id\":2379},{\"id\":2380},{\"id\":2411},{\"id\":2336},{\"id\":2381},{\"id\":2382},{\"id\":2412},{\"id\":2337},{\"id\":2383},{\"id\":2384},{\"id\":2413},{\"id\":2338},{\"id\":2385},{\"id\":2386},{\"id\":2414},{\"id\":2339},{\"id\":2387},{\"id\":2388},{\"id\":2415},{\"id\":2340},{\"id\":2389},{\"id\":2390},{\"id\":2416},{\"id\":2341},{\"id\":2391},{\"id\":2392},{\"id\":2417},{\"id\":2342},{\"id\":2418},{\"id\":2419},{\"id\":2312},{\"id\":2420},{\"id\":2421},{\"id\":2435},{\"id\":2436},{\"id\":2461},{\"id\":2422},{\"id\":2437},{\"id\":2438},{\"id\":2462},{\"id\":2423},{\"id\":2439},{\"id\":2440},{\"id\":2463},{\"id\":2424},{\"id\":2441},{\"id\":2442},{\"id\":2464},{\"id\":2425},{\"id\":2443},{\"id\":2444},{\"id\":2465},{\"id\":2426},{\"id\":2445},{\"id\":2446},{\"id\":2466},{\"id\":2427},{\"id\":2447},{\"id\":2448},{\"id\":2467},{\"id\":2428},{\"id\":2449},{\"id\":2450},{\"id\":2468},{\"id\":2429},{\"id\":2451},{\"id\":2452},{\"id\":2469},{\"id\":2430},{\"id\":2453},{\"id\":2454},{\"id\":2470},{\"id\":2431},{\"id\":2455},{\"id\":2456},{\"id\":2471},{\"id\":2432},{\"id\":2457},{\"id\":2458},{\"id\":2472},{\"id\":2433},{\"id\":2459},{\"id\":2460},{\"id\":2473},{\"id\":2434},{\"id\":2474},{\"id\":2475},{\"id\":2313},{\"id\":2476},{\"id\":2488},{\"id\":2477},{\"id\":2489},{\"id\":2478},{\"id\":2490},{\"id\":2479},{\"id\":2491},{\"id\":2480},{\"id\":2492},{\"id\":2481},{\"id\":2493},{\"id\":2482},{\"id\":2494},{\"id\":2483},{\"id\":2495},{\"id\":2484},{\"id\":2496},{\"id\":2485},{\"id\":2497},{\"id\":2486},{\"id\":2498},{\"id\":2487},{\"id\":2499},{\"id\":2314},{\"id\":2500},{\"id\":2501},{\"id\":2502},{\"id\":2503},{\"id\":2504},{\"id\":2505},{\"id\":2506},{\"id\":2507},{\"id\":2508},{\"id\":2509},{\"id\":2510},{\"id\":2511},{\"id\":2512},{\"id\":2513},{\"id\":2514},{\"id\":2515},{\"id\":2516},{\"id\":2517},{\"id\":2518},{\"id\":2519},{\"id\":2520},{\"id\":2521},{\"id\":2522},{\"id\":2523},{\"id\":2315},{\"id\":2524},{\"id\":2542},{\"id\":2543},{\"id\":2578},{\"id\":2525},{\"id\":2544},{\"id\":2545},{\"id\":2579},{\"id\":2526},{\"id\":2546},{\"id\":2547},{\"id\":2580},{\"id\":2527},{\"id\":2548},{\"id\":2549},{\"id\":2581},{\"id\":2528},{\"id\":2550},{\"id\":2551},{\"id\":2582},{\"id\":2529},{\"id\":2552},{\"id\":2553},{\"id\":2583},{\"id\":2530},{\"id\":2554},{\"id\":2555},{\"id\":2584},{\"id\":2531},{\"id\":2556},{\"id\":2557},{\"id\":2585},{\"id\":2532},{\"id\":2558},{\"id\":2559},{\"id\":2586},{\"id\":2533},{\"id\":2560},{\"id\":2561},{\"id\":2587},{\"id\":2534},{\"id\":2562},{\"id\":2563},{\"id\":2588},{\"id\":2535},{\"id\":2564},{\"id\":2565},{\"id\":2589},{\"id\":2536},{\"id\":2566},{\"id\":2567},{\"id\":2590},{\"id\":2537},{\"id\":2568},{\"id\":2569},{\"id\":2591},{\"id\":2538},{\"id\":2570},{\"id\":2571},{\"id\":2592},{\"id\":2539},{\"id\":2572},{\"id\":2573},{\"id\":2593},{\"id\":2540},{\"id\":2574},{\"id\":2575},{\"id\":2594},{\"id\":2541},{\"id\":2576},{\"id\":2577},{\"id\":2595},{\"id\":2303},{\"id\":2304},{\"id\":2305},{\"id\":2306},{\"id\":2307},{\"nodeType\":3,\"id\":2596,\"textContent\":\" // Track clicks on page $(document).ready(function() { $(\\\".control\\\").click(function(e) { e.stopImmediatePropagation(); clicks = clicks + 1; console.log(clicks); }); }); $('.userid').html(sid); // console.log(\\\"start of clicked array: \\\"+clicked); // console.log(\\\"start of hovered string: \\\"+hovered); //set correct answers for each question var triangular_answers = { \\\"acme.starttime.1\\\" : [\\\"F\\\"], \\\"acme.starts.1\\\" : [\\\"K\\\"], \\\"acme.meets.1\\\" : [\\\"F\\\"], \\\"acme.endtime.1\\\" : [\\\"H\\\"], \\\"acme.midpoint.1\\\" : [\\\"O\\\"], \\\"acme.starttime.2\\\" : [\\\"F\\\"], \\\"acme.starts.2\\\" : [\\\"K\\\"], \\\"acme.meets.2\\\" : [\\\"F\\\"], \\\"acme.endtime.2\\\" : [\\\"H\\\"], \\\"acme.midpoint.2\\\" : [\\\"A\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"E\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"E\\\"], \\\"bigset.starttime.1\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.1\\\" : [\\\"G\\\"], \\\"bigset.meets.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.1\\\" : [\\\"X\\\"], \\\"bigset.midpoint.1\\\" : [\\\"K\\\",\\\"X\\\"], \\\"bigset.starttime.2\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.2\\\" : [\\\"G\\\"], \\\"bigset.meets.2\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.2\\\" : [\\\"X\\\"], \\\"bigset.midpoint.2\\\" : [\\\"K\\\",\\\"X\\\"] } var orthogonal_answers = { \\\"acme.starttime.1\\\" : [\\\"A\\\"], \\\"acme.starts.1\\\" : [\\\"E\\\"], \\\"acme.meets.1\\\" : [\\\"Z\\\"], \\\"acme.endtime.1\\\" : [\\\"U\\\"], \\\"acme.midpoint.1\\\" : [\\\"U\\\"], \\\"acme.starttime.2\\\" : [\\\"0\\\"], \\\"acme.starts.2\\\" : [\\\"0\\\"], \\\"acme.meets.2\\\" : [\\\"0\\\"], \\\"acme.endtime.2\\\" : [\\\"0\\\"], \\\"acme.midpoint.2\\\" : [\\\"0\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"X\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"X\\\"], \\\"bigset.starttime.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.1\\\" : [\\\"B\\\"], \\\"bigset.meets.1\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.1\\\" : [\\\"B\\\"], \\\"bigset.midpoint.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.starttime.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.2\\\" : [\\\"B\\\"], \\\"bigset.meets.2\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.2\\\" : [\\\"B\\\"], \\\"bigset.midpoint.2\\\" : [\\\"E\\\",\\\"F\\\"] } //display the question and answer buttons based on input values from jsPsych document.getElementById(scenario+\\\".\\\"+question).style.display = \\\"block\\\"; if (question == \\\"strategy\\\") {document.getElementById(\\\"strategyButton\\\").style.display = \\\"block\\\";} else {document.getElementById(\\\"testingButton\\\").style.display = \\\"block\\\";} //---------SET PROPERTIES OF THE GRAPH -------------// // set the dimensions and margins of the graph var margin = {top: 25, right: 30, bottom: 90, left: 100}, width = 800, height = 800; var intersects = false; //default value for intersects scaffold var xAxisTitle, yAxisTitle; var datafile =\\\"\\\"; // SET AXIS VALUES if (axis == 1){ axis = \\\"Orthogonal-XInside-YFull\\\"; } else if (axis == 2){ axis = \\\"Orthogonal-XInside-YPartial\\\"; } else if (axis ==3){ axis = \\\"Triangular-XInside-YInside\\\"; } else if (axis ==4){ axis = \\\"Orthogonal-XInside-YInside\\\"; } else if (axis ==5){ axis = \\\"Orthogonal-XFull-YFull\\\"; } // SET EXPLICIT SCAFFOLD FEATURES if (explicit ==2 && axis != \\\"diagonal\\\"){ scaffold = 2; intersects = false; } else if (explicit == 2 && axis == \\\"diagonal\\\"){ scaffold = 2; intersects = false; } //TODO: not sure if above two lines are still valid since leaders are now generated on the fly else if (explicit == 3){ $('#hint-interactive').css(\\\"display\\\",\\\"block\\\"); //display textimage scaffold intersects = true; } //SET DATA FILE FOR IMPLICIT SCAFFOLD if (impasse == 1){ datafile = \\\"../views/src/data/acme_nonimpasse.csv\\\"; } else if (impasse == 2){ datafile = \\\"../views/src/data/acme_impasse.csv\\\"; } //OVERRIDE DATA FILE FOR NON-SCAFFOLD QUESTIONS if (q > 5) { //override data file if q# is greater than 5 datafile = \\\"../views/src/data/bigset.csv\\\"; console.log(\\\"override data file\\\"); $('#orthogonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#diagonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#hint-interactive').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold intersects = false; } // //---------CREATE THE SVG ------------------------// var svg = d3.select(\\\".d3container\\\").append(\\\"svg\\\") .attr(\\\"width\\\", width + margin.left + margin.right) .attr(\\\"height\\\", height + margin.top + margin.bottom) .append(\\\"g\\\") .attr(\\\"transform\\\", \\\"translate(\\\" + margin.left + \\\",\\\" + margin.top + \\\")\\\"); //---------DRAW THE GRAPH ------------------------// xAxisTitle = \\\"START & END TIME (time of day)\\\"; yAxisTitle = \\\"DURATION (in hours)\\\"; drawTriangleModel(datafile,intersects,axis,scaffold,q); \"},{\"id\":2308},{\"id\":2309},{\"nodeType\":3,\"id\":2597,\"textContent\":\" //MOUSE LOGGING SCRIPT var mouseLog = [] var xwidth = $(document).width(); var xheight = $(document).width(); mouseLog.push(\\\"{x:\\\"+xwidth+\\\",y:\\\"+xheight+\\\",t:\\\"+\\\"0};\\\") document.onmousemove = function(e){ var pageCoords = \\\"{x:\\\" + e.pageX + \\\",y:\\\"+ e.pageY +\\\",t:\\\"+ Date.now()+ \\\"};\\\" ; mouseLog.push(pageCoords); // console.log(pageCoords); }; \"},{\"id\":2310}],[],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2598,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2599,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2598},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2600,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2599},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2601,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":2600},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2602,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2599}},{\"nodeType\":1,\"id\":2603,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2602},\"parentNode\":{\"id\":2599}},{\"nodeType\":3,\"id\":2604,\"textContent\":\"What is your age?\",\"parentNode\":{\"id\":2602}},{\"nodeType\":1,\"id\":2605,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2600}},{\"nodeType\":1,\"id\":2606,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2605},\"parentNode\":{\"id\":2600}},{\"nodeType\":3,\"id\":2607,\"textContent\":\"In what country were you born?\",\"parentNode\":{\"id\":2605}},{\"nodeType\":3,\"id\":2608,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":2601}}],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2598},{\"id\":2599},{\"id\":2602},{\"id\":2604},{\"id\":2603},{\"id\":2600},{\"id\":2605},{\"id\":2607},{\"id\":2606},{\"id\":2601},{\"id\":2608}],[],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2609,\"tagName\":\"FORM\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-form\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2610,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-preamble\",\"class\":\"jspsych-survey-multi-choice-preamble\"},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2611,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-0\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2610},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2612,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-1\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2611},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2613,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-2\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2612},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2614,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-3\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2613},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2615,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"submit\",\"id\":\"jspsych-survey-multi-choice-next\",\"class\":\"jspsych-survey-multi-choice jspsych-btn\",\"value\":\"Submit Answers\"},\"previousSibling\":{\"id\":2614},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2616,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2617,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2616},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2618,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2617},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2619,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2618},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2620,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2619},\"parentNode\":{\"id\":2611}},{\"nodeType\":3,\"id\":2621,\"textContent\":\"What is your first language?\",\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2622,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2621},\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2623,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2624,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2623}},{\"nodeType\":3,\"id\":2625,\"textContent\":\"English\",\"previousSibling\":{\"id\":2624},\"parentNode\":{\"id\":2623}},{\"nodeType\":1,\"id\":2626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2618}},{\"nodeType\":1,\"id\":2627,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2626}},{\"nodeType\":3,\"id\":2628,\"textContent\":\"Spanish\",\"previousSibling\":{\"id\":2627},\"parentNode\":{\"id\":2626}},{\"nodeType\":1,\"id\":2629,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2619}},{\"nodeType\":1,\"id\":2630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2629}},{\"nodeType\":3,\"id\":2631,\"textContent\":\"Mandarin or Cantonese\",\"previousSibling\":{\"id\":2630},\"parentNode\":{\"id\":2629}},{\"nodeType\":1,\"id\":2632,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2633,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2634,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2633},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2635,\"textContent\":\"*\",\"parentNode\":{\"id\":2622}},{\"nodeType\":1,\"id\":2636,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2637,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2636},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2638,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2637},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2639,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2638},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2640,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2639},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2641,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2640},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2642,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2641},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2643,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2642},\"parentNode\":{\"id\":2612}},{\"nodeType\":3,\"id\":2644,\"textContent\":\"What is your year in school?\",\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2645,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2644},\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2646,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2637}},{\"nodeType\":1,\"id\":2647,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2646}},{\"nodeType\":3,\"id\":2648,\"textContent\":\"First\",\"previousSibling\":{\"id\":2647},\"parentNode\":{\"id\":2646}},{\"nodeType\":1,\"id\":2649,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2638}},{\"nodeType\":1,\"id\":2650,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2649}},{\"nodeType\":3,\"id\":2651,\"textContent\":\"Second\",\"previousSibling\":{\"id\":2650},\"parentNode\":{\"id\":2649}},{\"nodeType\":1,\"id\":2652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2639}},{\"nodeType\":1,\"id\":2653,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2652}},{\"nodeType\":3,\"id\":2654,\"textContent\":\"Third\",\"previousSibling\":{\"id\":2653},\"parentNode\":{\"id\":2652}},{\"nodeType\":1,\"id\":2655,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2640}},{\"nodeType\":1,\"id\":2656,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2655}},{\"nodeType\":3,\"id\":2657,\"textContent\":\"Fourth\",\"previousSibling\":{\"id\":2656},\"parentNode\":{\"id\":2655}},{\"nodeType\":1,\"id\":2658,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2641}},{\"nodeType\":1,\"id\":2659,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2658}},{\"nodeType\":3,\"id\":2660,\"textContent\":\"Fifth\",\"previousSibling\":{\"id\":2659},\"parentNode\":{\"id\":2658}},{\"nodeType\":1,\"id\":2661,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2642}},{\"nodeType\":1,\"id\":2662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2661}},{\"nodeType\":3,\"id\":2663,\"textContent\":\"Graduate\",\"previousSibling\":{\"id\":2662},\"parentNode\":{\"id\":2661}},{\"nodeType\":1,\"id\":2664,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2643}},{\"nodeType\":1,\"id\":2665,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2666,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2665},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2667,\"textContent\":\"*\",\"parentNode\":{\"id\":2645}},{\"nodeType\":1,\"id\":2668,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2669,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2668},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2670,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2669},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2671,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2670},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2672,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2671},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2673,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2672},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2674,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2673},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2675,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2674},\"parentNode\":{\"id\":2613}},{\"nodeType\":3,\"id\":2676,\"textContent\":\"What is your major area of study?\",\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2677,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2676},\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2678,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2669}},{\"nodeType\":1,\"id\":2679,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2678}},{\"nodeType\":3,\"id\":2680,\"textContent\":\"Math or Computer Sciences\",\"previousSibling\":{\"id\":2679},\"parentNode\":{\"id\":2678}},{\"nodeType\":1,\"id\":2681,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2670}},{\"nodeType\":1,\"id\":2682,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2681}},{\"nodeType\":3,\"id\":2683,\"textContent\":\"Social Sciences (incl. CogSci)\",\"previousSibling\":{\"id\":2682},\"parentNode\":{\"id\":2681}},{\"nodeType\":1,\"id\":2684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2671}},{\"nodeType\":1,\"id\":2685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2684}},{\"nodeType\":3,\"id\":2686,\"textContent\":\"Biomedical & Health Sciences\",\"previousSibling\":{\"id\":2685},\"parentNode\":{\"id\":2684}},{\"nodeType\":1,\"id\":2687,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2672}},{\"nodeType\":1,\"id\":2688,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2687}},{\"nodeType\":3,\"id\":2689,\"textContent\":\"Natural Sciences\",\"previousSibling\":{\"id\":2688},\"parentNode\":{\"id\":2687}},{\"nodeType\":1,\"id\":2690,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2673}},{\"nodeType\":1,\"id\":2691,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2690}},{\"nodeType\":3,\"id\":2692,\"textContent\":\"Engineering\",\"previousSibling\":{\"id\":2691},\"parentNode\":{\"id\":2690}},{\"nodeType\":1,\"id\":2693,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2674}},{\"nodeType\":1,\"id\":2694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2693}},{\"nodeType\":3,\"id\":2695,\"textContent\":\"Humanities\",\"previousSibling\":{\"id\":2694},\"parentNode\":{\"id\":2693}},{\"nodeType\":1,\"id\":2696,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2675}},{\"nodeType\":1,\"id\":2697,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2698,\"textContent\":\"Fine Arts\",\"previousSibling\":{\"id\":2697},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2699,\"textContent\":\"*\",\"parentNode\":{\"id\":2677}},{\"nodeType\":1,\"id\":2700,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2701,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2700},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2702,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2701},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2703,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2702},\"parentNode\":{\"id\":2614}},{\"nodeType\":3,\"id\":2704,\"textContent\":\"What is your gender?\",\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2705,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2704},\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2706,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2701}},{\"nodeType\":1,\"id\":2707,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2706}},{\"nodeType\":3,\"id\":2708,\"textContent\":\"Male\",\"previousSibling\":{\"id\":2707},\"parentNode\":{\"id\":2706}},{\"nodeType\":1,\"id\":2709,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2702}},{\"nodeType\":1,\"id\":2710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2709}},{\"nodeType\":3,\"id\":2711,\"textContent\":\"Female\",\"previousSibling\":{\"id\":2710},\"parentNode\":{\"id\":2709}},{\"nodeType\":1,\"id\":2712,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2703}},{\"nodeType\":1,\"id\":2713,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2714,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2713},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2715,\"textContent\":\"*\",\"parentNode\":{\"id\":2705}}],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2609},{\"id\":2610},{\"id\":2611},{\"id\":2616},{\"id\":2621},{\"id\":2622},{\"id\":2635},{\"id\":2617},{\"id\":2623},{\"id\":2624},{\"id\":2625},{\"id\":2618},{\"id\":2626},{\"id\":2627},{\"id\":2628},{\"id\":2619},{\"id\":2629},{\"id\":2630},{\"id\":2631},{\"id\":2620},{\"id\":2632},{\"id\":2633},{\"id\":2634},{\"id\":2612},{\"id\":2636},{\"id\":2644},{\"id\":2645},{\"id\":2667},{\"id\":2637},{\"id\":2646},{\"id\":2647},{\"id\":2648},{\"id\":2638},{\"id\":2649},{\"id\":2650},{\"id\":2651},{\"id\":2639},{\"id\":2652},{\"id\":2653},{\"id\":2654},{\"id\":2640},{\"id\":2655},{\"id\":2656},{\"id\":2657},{\"id\":2641},{\"id\":2658},{\"id\":2659},{\"id\":2660},{\"id\":2642},{\"id\":2661},{\"id\":2662},{\"id\":2663},{\"id\":2643},{\"id\":2664},{\"id\":2665},{\"id\":2666},{\"id\":2613},{\"id\":2668},{\"id\":2676},{\"id\":2677},{\"id\":2699},{\"id\":2669},{\"id\":2678},{\"id\":2679},{\"id\":2680},{\"id\":2670},{\"id\":2681},{\"id\":2682},{\"id\":2683},{\"id\":2671},{\"id\":2684},{\"id\":2685},{\"id\":2686},{\"id\":2672},{\"id\":2687},{\"id\":2688},{\"id\":2689},{\"id\":2673},{\"id\":2690},{\"id\":2691},{\"id\":2692},{\"id\":2674},{\"id\":2693},{\"id\":2694},{\"id\":2695},{\"id\":2675},{\"id\":2696},{\"id\":2697},{\"id\":2698},{\"id\":2614},{\"id\":2700},{\"id\":2704},{\"id\":2705},{\"id\":2715},{\"id\":2701},{\"id\":2706},{\"id\":2707},{\"id\":2708},{\"id\":2702},{\"id\":2709},{\"id\":2710},{\"id\":2711},{\"id\":2703},{\"id\":2712},{\"id\":2713},{\"id\":2714},{\"id\":2615}],[],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2716,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2717,\"textContent\":\" \",\"previousSibling\":{\"id\":2716},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2718,\"textContent\":\" \",\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":2718},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2720,\"textContent\":\" \",\"previousSibling\":{\"id\":2719},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2721,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":2720},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2722,\"textContent\":\" \",\"previousSibling\":{\"id\":2721},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2723,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":2722},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2724,\"textContent\":\" \",\"previousSibling\":{\"id\":2723},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2725,\"textContent\":\" \",\"parentNode\":{\"id\":2719}},{\"nodeType\":1,\"id\":2726,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":2725},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2727,\"textContent\":\" \",\"previousSibling\":{\"id\":2726},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2728,\"textContent\":\" \",\"parentNode\":{\"id\":2726}},{\"nodeType\":1,\"id\":2729,\"tagName\":\"H3\",\"attributes\":{},\"previousSibling\":{\"id\":2728},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2730,\"textContent\":\" \",\"previousSibling\":{\"id\":2729},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2731,\"textContent\":\"DEBRIEFING\",\"parentNode\":{\"id\":2729}},{\"nodeType\":3,\"id\":2732,\"textContent\":\" \",\"parentNode\":{\"id\":2721}},{\"nodeType\":1,\"id\":2733,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":2732},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2734,\"textContent\":\" \",\"previousSibling\":{\"id\":2733},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2735,\"textContent\":\" \",\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2736,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic\"},\"previousSibling\":{\"id\":2735},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2737,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2736},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2738,\"textContent\":\" \",\"previousSibling\":{\"id\":2737},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2739,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2738},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2740,\"textContent\":\" \",\"previousSibling\":{\"id\":2739},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2741,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2740},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2742,\"textContent\":\" \",\"previousSibling\":{\"id\":2741},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2743,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:bold;\"},\"previousSibling\":{\"id\":2742},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2744,\"textContent\":\" \",\"previousSibling\":{\"id\":2743},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2745,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":2744},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2746,\"textContent\":\" \",\"previousSibling\":{\"id\":2745},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2747,\"textContent\":\"Thank you very much for your participation! This debriefing will tell you more about the study, what you did, and why. \",\"parentNode\":{\"id\":2736}},{\"nodeType\":3,\"id\":2748,\"textContent\":\" \",\"parentNode\":{\"id\":2737}},{\"nodeType\":1,\"id\":2749,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2748},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2750,\"textContent\":\" You have just used a series of pictures (charts, graphs and diagrams) accompanied by different types of instructions to answer a series of problem solving questions. While you were using the pictures, we measured where you clicked, scrolled and pointed with the computer mouse. We also measured the accuracy of your responses and the time it took to complete each question.\",\"previousSibling\":{\"id\":2749},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2751,\"textContent\":\"What did you just do?\",\"parentNode\":{\"id\":2749}},{\"nodeType\":3,\"id\":2752,\"textContent\":\" \",\"parentNode\":{\"id\":2739}},{\"nodeType\":1,\"id\":2753,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2752},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2754,\"textContent\":\" Researchers of learning and cognition have long been interested in how graphic displays of information can be used to communicate, solve problems, and generate insights. As powerful as graphics may be in their communicative efficiency, they're not always immediately intuitive to understand. In short, we know a great deal more about learning with representations than we do about the learning of representations. In this project we are building upon previous research on reading and graph comprehension to explore how readers make sense of unfamiliar representations. The instructions you saw for each type of graph are known as “scaffolding techniques”, and we will compare your performance with the scaffolding techniques you saw with the performance of other participants to determine which types of instructions are most effective in helping humans to make sense of unfamiliar graphs. \",\"previousSibling\":{\"id\":2753},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2755,\"textContent\":\"Why did we have you do it?\",\"parentNode\":{\"id\":2753}},{\"nodeType\":1,\"id\":2756,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2757,\"textContent\":\" We expect that you will have found some of the graphics more difficult to use than others. We also expect that with the assistance of the instructions, after solving several problems you will learn to use the difficult graphics so that you can answer the questions even more quickly than without. If you would like to receive a copy of the results of the study, or have any further questions, please contact the researchers Primary Researcher: Amy Fox : a2fox@ucsd.edu Faculty Advisor : Dr. Jim Hollan : hollan@ucsd.edu \",\"previousSibling\":{\"id\":2756},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2758,\"textContent\":\"What do we expect to find?\",\"parentNode\":{\"id\":2756}},{\"nodeType\":3,\"id\":2759,\"textContent\":\"It is important that you do not discuss this experiment with other students who might participate after you. They must participate in the same way as you did, without any knowledge of what the experiment entails, or the reasoning behind it.\",\"parentNode\":{\"id\":2743}},{\"nodeType\":3,\"id\":2760,\"textContent\":\"Thank you for your time! We hope you enjoyed participating in this study as much as we enjoyed designing it.\",\"parentNode\":{\"id\":2745}},{\"nodeType\":3,\"id\":2761,\"textContent\":\" \",\"parentNode\":{\"id\":2723}},{\"nodeType\":1,\"id\":2762,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":2761},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2763,\"textContent\":\" \",\"previousSibling\":{\"id\":2762},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2764,\"textContent\":\"FINISH\",\"parentNode\":{\"id\":2762}}],[],[]]}"
    },
    {
      "sequence": 8,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2716},{\"id\":2718},{\"id\":2719},{\"id\":2725},{\"id\":2726},{\"id\":2728},{\"id\":2729},{\"id\":2731},{\"id\":2730},{\"id\":2727},{\"id\":2720},{\"id\":2721},{\"id\":2732},{\"id\":2733},{\"id\":2735},{\"id\":2736},{\"id\":2747},{\"id\":2737},{\"id\":2748},{\"id\":2749},{\"id\":2751},{\"id\":2750},{\"id\":2738},{\"id\":2739},{\"id\":2752},{\"id\":2753},{\"id\":2755},{\"id\":2754},{\"id\":2740},{\"id\":2741},{\"id\":2756},{\"id\":2758},{\"id\":2757},{\"id\":2742},{\"id\":2743},{\"id\":2759},{\"id\":2744},{\"id\":2745},{\"id\":2760},{\"id\":2746},{\"id\":2734},{\"id\":2722},{\"id\":2723},{\"id\":2761},{\"id\":2762},{\"id\":2764},{\"id\":2763},{\"id\":2724},{\"id\":2717}],[],[],[]]}"
    },
    {
      "sequence": 9,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2765,\"tagName\":\"PRE\",\"attributes\":{\"id\":\"jspsych-data-display\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2766,\"textContent\":\"[ { \\\"rt\\\": 293019, \\\"stimulus\\\": \\\"img/phone.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"phone\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 0, \\\"time_elapsed\\\": 293024, \\\"internal_node_id\\\": \\\"0.0-0.0\\\", \\\"subject\\\": \\\"S6D2F\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\" }, { \\\"rt\\\": 10115, \\\"url\\\": \\\"../views/src/external/consent.html\\\", \\\"block\\\": \\\"consent\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 1, \\\"time_elapsed\\\": 304495, \\\"internal_node_id\\\": \\\"0.0-1.0\\\", \\\"subject\\\": \\\"S6D2F\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\" }, { \\\"rt\\\": 13102, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"YANKEE\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"311\\\\\\\"}\\\", \\\"block\\\": \\\"codes\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 2, \\\"time_elapsed\\\": 318605, \\\"internal_node_id\\\": \\\"0.0-2.0\\\", \\\"subject\\\": \\\"S6D2F\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\" }, { \\\"rt\\\": 7985, \\\"url\\\": \\\"../views/src/external/instructions_lab.html\\\", \\\"block\\\": \\\"instructions_lab\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 3, \\\"time_elapsed\\\": 327677, \\\"internal_node_id\\\": \\\"0.0-3.0\\\", \\\"subject\\\": \\\"S6D2F\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\" }, { \\\"rt\\\": 22647, \\\"stimulus\\\": \\\"img/acme.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"scenario\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 4, \\\"time_elapsed\\\": 351327, \\\"internal_node_id\\\": \\\"0.0-4.0\\\", \\\"subject\\\": \\\"S6D2F\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\" }, { \\\"rt\\\": 15636, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 5, \\\"time_elapsed\\\": 368337, \\\"internal_node_id\\\": \\\"0.0-5.0-0.0\\\", \\\"subject\\\": \\\"S6D2F\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 1, \\\"clicks\\\": 1, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"A\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-09 AM-Z -11 AM-A -A -A -A -A \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:998,y:1089,t:1528139563833};\\\", \\\"{x:1019,y:1070,t:1528139563840};\\\", \\\"{x:1034,y:1053,t:1528139563851};\\\", \\\"{x:1073,y:1025,t:1528139563867};\\\", \\\"{x:1109,y:1004,t:1528139563885};\\\", \\\"{x:1163,y:975,t:1528139563901};\\\", \\\"{x:1232,y:940,t:1528139563918};\\\", \\\"{x:1294,y:911,t:1528139563934};\\\", \\\"{x:1345,y:887,t:1528139563951};\\\", \\\"{x:1393,y:860,t:1528139563969};\\\", \\\"{x:1400,y:854,t:1528139563985};\\\", \\\"{x:1400,y:851,t:1528139564001};\\\", \\\"{x:1400,y:849,t:1528139564017};\\\", \\\"{x:1399,y:848,t:1528139564035};\\\", \\\"{x:1398,y:847,t:1528139564052};\\\", \\\"{x:1397,y:846,t:1528139564080};\\\", \\\"{x:1396,y:846,t:1528139564088};\\\", \\\"{x:1394,y:846,t:1528139564101};\\\", \\\"{x:1392,y:846,t:1528139564118};\\\", \\\"{x:1388,y:846,t:1528139564135};\\\", \\\"{x:1375,y:854,t:1528139564151};\\\", \\\"{x:1332,y:896,t:1528139564168};\\\", \\\"{x:1282,y:943,t:1528139564185};\\\", \\\"{x:1232,y:986,t:1528139564201};\\\", \\\"{x:1188,y:1023,t:1528139564218};\\\", \\\"{x:1161,y:1052,t:1528139564236};\\\", \\\"{x:1150,y:1069,t:1528139564250};\\\", \\\"{x:1149,y:1081,t:1528139564267};\\\", \\\"{x:1149,y:1086,t:1528139564284};\\\", \\\"{x:1154,y:1090,t:1528139564300};\\\", \\\"{x:1157,y:1092,t:1528139564317};\\\", \\\"{x:1159,y:1093,t:1528139564334};\\\", \\\"{x:1174,y:1095,t:1528139564351};\\\", \\\"{x:1180,y:1094,t:1528139564368};\\\", \\\"{x:1188,y:1090,t:1528139564384};\\\", \\\"{x:1192,y:1087,t:1528139564400};\\\", \\\"{x:1196,y:1083,t:1528139564418};\\\", \\\"{x:1199,y:1079,t:1528139564436};\\\", \\\"{x:1203,y:1071,t:1528139564451};\\\", \\\"{x:1207,y:1065,t:1528139564468};\\\", \\\"{x:1212,y:1059,t:1528139564483};\\\", \\\"{x:1215,y:1054,t:1528139564500};\\\", \\\"{x:1222,y:1049,t:1528139564517};\\\", \\\"{x:1227,y:1042,t:1528139564534};\\\", \\\"{x:1228,y:1039,t:1528139564550};\\\", \\\"{x:1229,y:1035,t:1528139564568};\\\", \\\"{x:1230,y:1031,t:1528139564585};\\\", \\\"{x:1231,y:1029,t:1528139564600};\\\", \\\"{x:1233,y:1027,t:1528139564618};\\\", \\\"{x:1237,y:1024,t:1528139564635};\\\", \\\"{x:1238,y:1023,t:1528139564650};\\\", \\\"{x:1243,y:1020,t:1528139564668};\\\", \\\"{x:1249,y:1015,t:1528139564685};\\\", \\\"{x:1256,y:1008,t:1528139564701};\\\", \\\"{x:1263,y:1002,t:1528139564718};\\\", \\\"{x:1272,y:994,t:1528139564736};\\\", \\\"{x:1275,y:991,t:1528139564752};\\\", \\\"{x:1276,y:989,t:1528139564768};\\\", \\\"{x:1277,y:988,t:1528139564785};\\\", \\\"{x:1277,y:985,t:1528139564801};\\\", \\\"{x:1277,y:978,t:1528139564818};\\\", \\\"{x:1277,y:969,t:1528139564836};\\\", \\\"{x:1277,y:960,t:1528139564851};\\\", \\\"{x:1277,y:948,t:1528139564869};\\\", \\\"{x:1275,y:939,t:1528139564886};\\\", \\\"{x:1273,y:924,t:1528139564902};\\\", \\\"{x:1268,y:911,t:1528139564918};\\\", \\\"{x:1264,y:895,t:1528139564936};\\\", \\\"{x:1260,y:881,t:1528139564952};\\\", \\\"{x:1258,y:873,t:1528139564968};\\\", \\\"{x:1256,y:864,t:1528139564985};\\\", \\\"{x:1256,y:859,t:1528139565003};\\\", \\\"{x:1256,y:855,t:1528139565018};\\\", \\\"{x:1256,y:848,t:1528139565036};\\\", \\\"{x:1256,y:844,t:1528139565051};\\\", \\\"{x:1256,y:841,t:1528139565067};\\\", \\\"{x:1256,y:837,t:1528139565084};\\\", \\\"{x:1256,y:833,t:1528139565101};\\\", \\\"{x:1256,y:829,t:1528139565117};\\\", \\\"{x:1257,y:826,t:1528139565135};\\\", \\\"{x:1259,y:823,t:1528139565152};\\\", \\\"{x:1262,y:821,t:1528139565167};\\\", \\\"{x:1264,y:819,t:1528139565185};\\\", \\\"{x:1266,y:819,t:1528139565202};\\\", \\\"{x:1269,y:817,t:1528139565218};\\\", \\\"{x:1272,y:816,t:1528139565235};\\\", \\\"{x:1274,y:815,t:1528139565252};\\\", \\\"{x:1275,y:813,t:1528139565268};\\\", \\\"{x:1277,y:813,t:1528139565287};\\\", \\\"{x:1279,y:813,t:1528139565456};\\\", \\\"{x:1281,y:813,t:1528139565504};\\\", \\\"{x:1281,y:814,t:1528139565800};\\\", \\\"{x:1281,y:816,t:1528139565808};\\\", \\\"{x:1281,y:819,t:1528139565824};\\\", \\\"{x:1281,y:820,t:1528139565836};\\\", \\\"{x:1281,y:823,t:1528139565852};\\\", \\\"{x:1280,y:827,t:1528139565871};\\\", \\\"{x:1279,y:830,t:1528139565902};\\\", \\\"{x:1279,y:832,t:1528139565919};\\\", \\\"{x:1279,y:833,t:1528139566055};\\\", \\\"{x:1278,y:831,t:1528139567127};\\\", \\\"{x:1276,y:829,t:1528139567136};\\\", \\\"{x:1270,y:826,t:1528139567155};\\\", \\\"{x:1264,y:824,t:1528139567170};\\\", \\\"{x:1259,y:824,t:1528139567187};\\\", \\\"{x:1238,y:826,t:1528139567203};\\\", \\\"{x:1192,y:851,t:1528139567221};\\\", \\\"{x:1114,y:889,t:1528139567237};\\\", \\\"{x:1049,y:927,t:1528139567254};\\\", \\\"{x:986,y:979,t:1528139567270};\\\", \\\"{x:954,y:1006,t:1528139567286};\\\", \\\"{x:954,y:1010,t:1528139567303};\\\", \\\"{x:955,y:1003,t:1528139567495};\\\", \\\"{x:980,y:987,t:1528139567512};\\\", \\\"{x:1021,y:973,t:1528139567529};\\\", \\\"{x:1068,y:951,t:1528139567544};\\\", \\\"{x:1095,y:935,t:1528139567562};\\\", \\\"{x:1132,y:915,t:1528139567579};\\\", \\\"{x:1169,y:897,t:1528139567594};\\\", \\\"{x:1192,y:888,t:1528139567612};\\\", \\\"{x:1212,y:876,t:1528139567629};\\\", \\\"{x:1231,y:866,t:1528139567644};\\\", \\\"{x:1240,y:862,t:1528139567662};\\\", \\\"{x:1254,y:852,t:1528139567679};\\\", \\\"{x:1264,y:846,t:1528139567695};\\\", \\\"{x:1274,y:838,t:1528139567712};\\\", \\\"{x:1283,y:830,t:1528139567734};\\\", \\\"{x:1292,y:821,t:1528139567747};\\\", \\\"{x:1300,y:810,t:1528139567761};\\\", \\\"{x:1307,y:800,t:1528139567778};\\\", \\\"{x:1316,y:792,t:1528139567795};\\\", \\\"{x:1320,y:787,t:1528139567812};\\\", \\\"{x:1320,y:786,t:1528139567829};\\\", \\\"{x:1318,y:787,t:1528139567919};\\\", \\\"{x:1313,y:792,t:1528139567929};\\\", \\\"{x:1302,y:805,t:1528139567946};\\\", \\\"{x:1288,y:821,t:1528139567961};\\\", \\\"{x:1280,y:832,t:1528139567981};\\\", \\\"{x:1273,y:839,t:1528139567997};\\\", \\\"{x:1271,y:844,t:1528139568012};\\\", \\\"{x:1269,y:847,t:1528139568028};\\\", \\\"{x:1268,y:849,t:1528139568046};\\\", \\\"{x:1271,y:847,t:1528139568192};\\\", \\\"{x:1274,y:843,t:1528139568200};\\\", \\\"{x:1281,y:838,t:1528139568213};\\\", \\\"{x:1289,y:833,t:1528139568229};\\\", \\\"{x:1295,y:828,t:1528139568246};\\\", \\\"{x:1297,y:825,t:1528139568263};\\\", \\\"{x:1299,y:824,t:1528139568279};\\\", \\\"{x:1297,y:824,t:1528139568448};\\\", \\\"{x:1293,y:827,t:1528139568463};\\\", \\\"{x:1292,y:828,t:1528139568480};\\\", \\\"{x:1291,y:828,t:1528139568496};\\\", \\\"{x:1290,y:828,t:1528139568514};\\\", \\\"{x:1289,y:829,t:1528139568598};\\\", \\\"{x:1288,y:830,t:1528139568623};\\\", \\\"{x:1287,y:830,t:1528139568638};\\\", \\\"{x:1286,y:831,t:1528139568673};\\\", \\\"{x:1284,y:831,t:1528139568695};\\\", \\\"{x:1282,y:833,t:1528139568712};\\\", \\\"{x:1281,y:833,t:1528139568730};\\\", \\\"{x:1280,y:833,t:1528139569088};\\\", \\\"{x:1249,y:835,t:1528139572298};\\\", \\\"{x:1208,y:835,t:1528139572314};\\\", \\\"{x:1152,y:835,t:1528139572331};\\\", \\\"{x:1083,y:835,t:1528139572348};\\\", \\\"{x:997,y:835,t:1528139572365};\\\", \\\"{x:911,y:835,t:1528139572381};\\\", \\\"{x:783,y:835,t:1528139572398};\\\", \\\"{x:705,y:835,t:1528139572416};\\\", \\\"{x:661,y:830,t:1528139572432};\\\", \\\"{x:618,y:822,t:1528139572449};\\\", \\\"{x:598,y:817,t:1528139572466};\\\", \\\"{x:581,y:812,t:1528139572483};\\\", \\\"{x:568,y:805,t:1528139572499};\\\", \\\"{x:555,y:799,t:1528139572516};\\\", \\\"{x:545,y:795,t:1528139572533};\\\", \\\"{x:536,y:792,t:1528139572549};\\\", \\\"{x:528,y:788,t:1528139572566};\\\", \\\"{x:509,y:780,t:1528139572583};\\\", \\\"{x:494,y:775,t:1528139572599};\\\", \\\"{x:478,y:767,t:1528139572617};\\\", \\\"{x:470,y:763,t:1528139572633};\\\", \\\"{x:462,y:757,t:1528139572649};\\\", \\\"{x:457,y:752,t:1528139572666};\\\", \\\"{x:454,y:749,t:1528139572683};\\\", \\\"{x:451,y:741,t:1528139572699};\\\", \\\"{x:450,y:739,t:1528139572716};\\\", \\\"{x:450,y:736,t:1528139572734};\\\", \\\"{x:450,y:733,t:1528139572751};\\\", \\\"{x:449,y:729,t:1528139572767};\\\", \\\"{x:448,y:726,t:1528139572784};\\\", \\\"{x:447,y:724,t:1528139572800};\\\", \\\"{x:446,y:721,t:1528139572816};\\\", \\\"{x:445,y:716,t:1528139572833};\\\", \\\"{x:444,y:712,t:1528139572850};\\\", \\\"{x:442,y:707,t:1528139572866};\\\", \\\"{x:439,y:702,t:1528139572884};\\\", \\\"{x:432,y:692,t:1528139572900};\\\", \\\"{x:419,y:681,t:1528139572918};\\\", \\\"{x:404,y:669,t:1528139572933};\\\", \\\"{x:389,y:656,t:1528139572950};\\\", \\\"{x:367,y:638,t:1528139572966};\\\", \\\"{x:356,y:623,t:1528139572983};\\\", \\\"{x:347,y:609,t:1528139573000};\\\", \\\"{x:337,y:596,t:1528139573016};\\\", \\\"{x:333,y:588,t:1528139573033};\\\", \\\"{x:328,y:580,t:1528139573050};\\\", \\\"{x:326,y:578,t:1528139573067};\\\", \\\"{x:326,y:577,t:1528139573082};\\\", \\\"{x:326,y:576,t:1528139573119};\\\", \\\"{x:327,y:576,t:1528139573207};\\\", \\\"{x:330,y:576,t:1528139573217};\\\", \\\"{x:336,y:576,t:1528139573233};\\\", \\\"{x:341,y:576,t:1528139573250};\\\", \\\"{x:346,y:576,t:1528139573268};\\\", \\\"{x:352,y:577,t:1528139573283};\\\", \\\"{x:357,y:578,t:1528139573301};\\\", \\\"{x:368,y:580,t:1528139573318};\\\", \\\"{x:377,y:581,t:1528139573334};\\\", \\\"{x:386,y:584,t:1528139573351};\\\", \\\"{x:395,y:586,t:1528139573367};\\\", \\\"{x:398,y:587,t:1528139573383};\\\", \\\"{x:400,y:588,t:1528139573400};\\\", \\\"{x:400,y:589,t:1528139573567};\\\", \\\"{x:400,y:590,t:1528139573656};\\\", \\\"{x:400,y:592,t:1528139573671};\\\", \\\"{x:400,y:593,t:1528139573687};\\\", \\\"{x:400,y:594,t:1528139573700};\\\", \\\"{x:400,y:595,t:1528139573718};\\\", \\\"{x:400,y:597,t:1528139573744};\\\", \\\"{x:399,y:597,t:1528139573789};\\\", \\\"{x:398,y:598,t:1528139573814};\\\", \\\"{x:397,y:598,t:1528139573879};\\\", \\\"{x:396,y:598,t:1528139573902};\\\", \\\"{x:395,y:598,t:1528139573926};\\\", \\\"{x:394,y:598,t:1528139573959};\\\", \\\"{x:393,y:598,t:1528139573975};\\\", \\\"{x:392,y:598,t:1528139573984};\\\", \\\"{x:385,y:598,t:1528139574001};\\\", \\\"{x:376,y:596,t:1528139574017};\\\", \\\"{x:363,y:592,t:1528139574034};\\\", \\\"{x:351,y:588,t:1528139574051};\\\", \\\"{x:337,y:586,t:1528139574066};\\\", \\\"{x:325,y:582,t:1528139574083};\\\", \\\"{x:319,y:582,t:1528139574100};\\\", \\\"{x:310,y:580,t:1528139574116};\\\", \\\"{x:300,y:578,t:1528139574134};\\\", \\\"{x:285,y:577,t:1528139574149};\\\", \\\"{x:264,y:573,t:1528139574166};\\\", \\\"{x:253,y:573,t:1528139574184};\\\", \\\"{x:248,y:573,t:1528139574201};\\\", \\\"{x:247,y:573,t:1528139574217};\\\", \\\"{x:248,y:572,t:1528139574263};\\\", \\\"{x:255,y:570,t:1528139574270};\\\", \\\"{x:263,y:569,t:1528139574284};\\\", \\\"{x:273,y:566,t:1528139574303};\\\", \\\"{x:282,y:562,t:1528139574318};\\\", \\\"{x:293,y:558,t:1528139574334};\\\", \\\"{x:310,y:553,t:1528139574351};\\\", \\\"{x:319,y:552,t:1528139574367};\\\", \\\"{x:327,y:548,t:1528139574384};\\\", \\\"{x:333,y:547,t:1528139574402};\\\", \\\"{x:337,y:546,t:1528139574418};\\\", \\\"{x:342,y:545,t:1528139574434};\\\", \\\"{x:356,y:545,t:1528139574451};\\\", \\\"{x:374,y:545,t:1528139574468};\\\", \\\"{x:389,y:545,t:1528139574485};\\\", \\\"{x:399,y:544,t:1528139574501};\\\", \\\"{x:402,y:544,t:1528139574517};\\\", \\\"{x:403,y:544,t:1528139574534};\\\", \\\"{x:402,y:544,t:1528139574776};\\\", \\\"{x:399,y:544,t:1528139574785};\\\", \\\"{x:398,y:545,t:1528139574802};\\\", \\\"{x:396,y:546,t:1528139574818};\\\", \\\"{x:396,y:549,t:1528139575174};\\\", \\\"{x:415,y:561,t:1528139575185};\\\", \\\"{x:459,y:588,t:1528139575202};\\\", \\\"{x:508,y:618,t:1528139575219};\\\", \\\"{x:555,y:645,t:1528139575235};\\\", \\\"{x:586,y:667,t:1528139575253};\\\", \\\"{x:605,y:685,t:1528139575268};\\\", \\\"{x:618,y:698,t:1528139575285};\\\", \\\"{x:623,y:711,t:1528139575302};\\\", \\\"{x:625,y:718,t:1528139575318};\\\", \\\"{x:623,y:723,t:1528139575335};\\\", \\\"{x:616,y:725,t:1528139575351};\\\", \\\"{x:600,y:726,t:1528139575368};\\\", \\\"{x:584,y:729,t:1528139575385};\\\", \\\"{x:568,y:731,t:1528139575402};\\\", \\\"{x:548,y:739,t:1528139575420};\\\", \\\"{x:527,y:745,t:1528139575435};\\\", \\\"{x:516,y:750,t:1528139575452};\\\", \\\"{x:513,y:752,t:1528139575468};\\\", \\\"{x:511,y:753,t:1528139575484};\\\", \\\"{x:511,y:755,t:1528139575518};\\\", \\\"{x:509,y:756,t:1528139575535};\\\", \\\"{x:506,y:758,t:1528139575552};\\\", \\\"{x:505,y:759,t:1528139575568};\\\", \\\"{x:505,y:761,t:1528139575585};\\\", \\\"{x:507,y:761,t:1528139576160};\\\", \\\"{x:525,y:760,t:1528139576170};\\\", \\\"{x:619,y:769,t:1528139576186};\\\", \\\"{x:713,y:783,t:1528139576202};\\\", \\\"{x:804,y:792,t:1528139576219};\\\", \\\"{x:895,y:800,t:1528139576236};\\\", \\\"{x:961,y:807,t:1528139576252};\\\", \\\"{x:979,y:808,t:1528139576269};\\\", \\\"{x:981,y:808,t:1528139576286};\\\" ] }, { \\\"rt\\\": 21589, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 6, \\\"time_elapsed\\\": 391154, \\\"internal_node_id\\\": \\\"0.0-5.0-1.0\\\", \\\"subject\\\": \\\"S6D2F\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 2, \\\"clicks\\\": 1.5, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-D -D -D -D -E \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:982,y:808,t:1528139588999};\\\", \\\"{x:1013,y:795,t:1528139589013};\\\", \\\"{x:1185,y:708,t:1528139589030};\\\", \\\"{x:1523,y:548,t:1528139589047};\\\", \\\"{x:1704,y:475,t:1528139589063};\\\", \\\"{x:1861,y:384,t:1528139589080};\\\", \\\"{x:1919,y:298,t:1528139589097};\\\", \\\"{x:1919,y:233,t:1528139589112};\\\", \\\"{x:1919,y:202,t:1528139589129};\\\", \\\"{x:1919,y:184,t:1528139589147};\\\", \\\"{x:1919,y:178,t:1528139589163};\\\", \\\"{x:1915,y:174,t:1528139589179};\\\", \\\"{x:1910,y:170,t:1528139589196};\\\", \\\"{x:1905,y:168,t:1528139589212};\\\", \\\"{x:1897,y:165,t:1528139589229};\\\", \\\"{x:1866,y:162,t:1528139589246};\\\", \\\"{x:1816,y:162,t:1528139589263};\\\", \\\"{x:1732,y:175,t:1528139589279};\\\", \\\"{x:1643,y:204,t:1528139589296};\\\", \\\"{x:1566,y:238,t:1528139589314};\\\", \\\"{x:1508,y:275,t:1528139589330};\\\", \\\"{x:1466,y:311,t:1528139589347};\\\", \\\"{x:1420,y:355,t:1528139589364};\\\", \\\"{x:1386,y:410,t:1528139589381};\\\", \\\"{x:1368,y:477,t:1528139589397};\\\", \\\"{x:1363,y:534,t:1528139589413};\\\", \\\"{x:1379,y:575,t:1528139589430};\\\", \\\"{x:1412,y:607,t:1528139589447};\\\", \\\"{x:1439,y:620,t:1528139589463};\\\", \\\"{x:1459,y:625,t:1528139589481};\\\", \\\"{x:1472,y:628,t:1528139589496};\\\", \\\"{x:1490,y:628,t:1528139589513};\\\", \\\"{x:1508,y:625,t:1528139589531};\\\", \\\"{x:1526,y:615,t:1528139589547};\\\", \\\"{x:1538,y:605,t:1528139589563};\\\", \\\"{x:1548,y:596,t:1528139589581};\\\", \\\"{x:1556,y:587,t:1528139589597};\\\", \\\"{x:1558,y:580,t:1528139589614};\\\", \\\"{x:1561,y:566,t:1528139589631};\\\", \\\"{x:1562,y:557,t:1528139589647};\\\", \\\"{x:1564,y:551,t:1528139589664};\\\", \\\"{x:1565,y:543,t:1528139589681};\\\", \\\"{x:1569,y:538,t:1528139589696};\\\", \\\"{x:1570,y:533,t:1528139589714};\\\", \\\"{x:1573,y:529,t:1528139589731};\\\", \\\"{x:1577,y:523,t:1528139589747};\\\", \\\"{x:1581,y:518,t:1528139589764};\\\", \\\"{x:1585,y:511,t:1528139589781};\\\", \\\"{x:1589,y:505,t:1528139589797};\\\", \\\"{x:1594,y:499,t:1528139589814};\\\", \\\"{x:1601,y:488,t:1528139589831};\\\", \\\"{x:1605,y:484,t:1528139589847};\\\", \\\"{x:1607,y:481,t:1528139589864};\\\", \\\"{x:1610,y:479,t:1528139589881};\\\", \\\"{x:1613,y:475,t:1528139589897};\\\", \\\"{x:1614,y:473,t:1528139589914};\\\", \\\"{x:1614,y:472,t:1528139589931};\\\", \\\"{x:1615,y:471,t:1528139589948};\\\", \\\"{x:1615,y:469,t:1528139589983};\\\", \\\"{x:1615,y:468,t:1528139589998};\\\", \\\"{x:1616,y:465,t:1528139590014};\\\", \\\"{x:1616,y:458,t:1528139590031};\\\", \\\"{x:1616,y:457,t:1528139590047};\\\", \\\"{x:1616,y:455,t:1528139590064};\\\", \\\"{x:1617,y:452,t:1528139590081};\\\", \\\"{x:1617,y:451,t:1528139590103};\\\", \\\"{x:1617,y:450,t:1528139590114};\\\", \\\"{x:1617,y:448,t:1528139590130};\\\", \\\"{x:1617,y:447,t:1528139590255};\\\", \\\"{x:1617,y:446,t:1528139590264};\\\", \\\"{x:1617,y:445,t:1528139590281};\\\", \\\"{x:1617,y:443,t:1528139590298};\\\", \\\"{x:1617,y:442,t:1528139590314};\\\", \\\"{x:1619,y:438,t:1528139590331};\\\", \\\"{x:1619,y:437,t:1528139590348};\\\", \\\"{x:1620,y:435,t:1528139590365};\\\", \\\"{x:1620,y:433,t:1528139590380};\\\", \\\"{x:1620,y:432,t:1528139590398};\\\", \\\"{x:1620,y:430,t:1528139590422};\\\", \\\"{x:1620,y:428,t:1528139590430};\\\", \\\"{x:1620,y:427,t:1528139590448};\\\", \\\"{x:1619,y:426,t:1528139590465};\\\", \\\"{x:1619,y:425,t:1528139590615};\\\", \\\"{x:1618,y:425,t:1528139590655};\\\", \\\"{x:1617,y:425,t:1528139590710};\\\", \\\"{x:1616,y:425,t:1528139590734};\\\", \\\"{x:1614,y:425,t:1528139590750};\\\", \\\"{x:1612,y:425,t:1528139590765};\\\", \\\"{x:1609,y:426,t:1528139590782};\\\", \\\"{x:1606,y:427,t:1528139590798};\\\", \\\"{x:1604,y:428,t:1528139590814};\\\", \\\"{x:1603,y:429,t:1528139590832};\\\", \\\"{x:1604,y:429,t:1528139591232};\\\", \\\"{x:1607,y:429,t:1528139591249};\\\", \\\"{x:1609,y:428,t:1528139591268};\\\", \\\"{x:1610,y:427,t:1528139591281};\\\", \\\"{x:1610,y:426,t:1528139591298};\\\", \\\"{x:1611,y:426,t:1528139591950};\\\", \\\"{x:1611,y:431,t:1528139591966};\\\", \\\"{x:1614,y:449,t:1528139591982};\\\", \\\"{x:1616,y:461,t:1528139591998};\\\", \\\"{x:1618,y:474,t:1528139592015};\\\", \\\"{x:1619,y:482,t:1528139592032};\\\", \\\"{x:1620,y:490,t:1528139592049};\\\", \\\"{x:1621,y:499,t:1528139592066};\\\", \\\"{x:1623,y:507,t:1528139592082};\\\", \\\"{x:1625,y:517,t:1528139592098};\\\", \\\"{x:1625,y:525,t:1528139592116};\\\", \\\"{x:1628,y:537,t:1528139592133};\\\", \\\"{x:1630,y:545,t:1528139592148};\\\", \\\"{x:1632,y:552,t:1528139592165};\\\", \\\"{x:1633,y:560,t:1528139592182};\\\", \\\"{x:1634,y:564,t:1528139592198};\\\", \\\"{x:1635,y:569,t:1528139592216};\\\", \\\"{x:1636,y:574,t:1528139592233};\\\", \\\"{x:1636,y:577,t:1528139592248};\\\", \\\"{x:1636,y:581,t:1528139592266};\\\", \\\"{x:1636,y:584,t:1528139592282};\\\", \\\"{x:1636,y:586,t:1528139592299};\\\", \\\"{x:1636,y:588,t:1528139592315};\\\", \\\"{x:1636,y:591,t:1528139592333};\\\", \\\"{x:1636,y:592,t:1528139592349};\\\", \\\"{x:1636,y:593,t:1528139592365};\\\", \\\"{x:1633,y:593,t:1528139592382};\\\", \\\"{x:1631,y:593,t:1528139592399};\\\", \\\"{x:1630,y:593,t:1528139592415};\\\", \\\"{x:1628,y:593,t:1528139592447};\\\", \\\"{x:1626,y:592,t:1528139592462};\\\", \\\"{x:1626,y:591,t:1528139592471};\\\", \\\"{x:1626,y:590,t:1528139592483};\\\", \\\"{x:1625,y:589,t:1528139592499};\\\", \\\"{x:1624,y:585,t:1528139592516};\\\", \\\"{x:1622,y:582,t:1528139592533};\\\", \\\"{x:1620,y:580,t:1528139592550};\\\", \\\"{x:1620,y:579,t:1528139592567};\\\", \\\"{x:1620,y:578,t:1528139592599};\\\", \\\"{x:1619,y:577,t:1528139592616};\\\", \\\"{x:1619,y:575,t:1528139592632};\\\", \\\"{x:1617,y:572,t:1528139592649};\\\", \\\"{x:1617,y:570,t:1528139592666};\\\", \\\"{x:1616,y:569,t:1528139592695};\\\", \\\"{x:1616,y:567,t:1528139592722};\\\", \\\"{x:1616,y:566,t:1528139592766};\\\", \\\"{x:1604,y:579,t:1528139594938};\\\", \\\"{x:1454,y:662,t:1528139594952};\\\", \\\"{x:1284,y:720,t:1528139594967};\\\", \\\"{x:1109,y:752,t:1528139594985};\\\", \\\"{x:904,y:789,t:1528139595001};\\\", \\\"{x:684,y:835,t:1528139595017};\\\", \\\"{x:459,y:882,t:1528139595035};\\\", \\\"{x:278,y:925,t:1528139595051};\\\", \\\"{x:131,y:947,t:1528139595067};\\\", \\\"{x:40,y:958,t:1528139595085};\\\", \\\"{x:1,y:961,t:1528139595101};\\\", \\\"{x:0,y:958,t:1528139595117};\\\", \\\"{x:0,y:943,t:1528139595134};\\\", \\\"{x:0,y:931,t:1528139595151};\\\", \\\"{x:0,y:915,t:1528139595167};\\\", \\\"{x:0,y:896,t:1528139595184};\\\", \\\"{x:0,y:870,t:1528139595202};\\\", \\\"{x:0,y:846,t:1528139595217};\\\", \\\"{x:0,y:824,t:1528139595235};\\\", \\\"{x:0,y:795,t:1528139595252};\\\", \\\"{x:1,y:765,t:1528139595267};\\\", \\\"{x:20,y:730,t:1528139595285};\\\", \\\"{x:66,y:686,t:1528139595302};\\\", \\\"{x:174,y:612,t:1528139595319};\\\", \\\"{x:237,y:574,t:1528139595334};\\\", \\\"{x:269,y:551,t:1528139595352};\\\", \\\"{x:289,y:543,t:1528139595369};\\\", \\\"{x:297,y:540,t:1528139595385};\\\", \\\"{x:298,y:540,t:1528139595402};\\\", \\\"{x:293,y:542,t:1528139595439};\\\", \\\"{x:291,y:547,t:1528139595452};\\\", \\\"{x:284,y:557,t:1528139595468};\\\", \\\"{x:277,y:569,t:1528139595485};\\\", \\\"{x:269,y:580,t:1528139595503};\\\", \\\"{x:256,y:595,t:1528139595518};\\\", \\\"{x:245,y:603,t:1528139595535};\\\", \\\"{x:235,y:609,t:1528139595552};\\\", \\\"{x:227,y:612,t:1528139595569};\\\", \\\"{x:220,y:614,t:1528139595585};\\\", \\\"{x:217,y:615,t:1528139595601};\\\", \\\"{x:215,y:615,t:1528139595618};\\\", \\\"{x:212,y:615,t:1528139595635};\\\", \\\"{x:211,y:615,t:1528139595651};\\\", \\\"{x:208,y:615,t:1528139595669};\\\", \\\"{x:202,y:608,t:1528139595686};\\\", \\\"{x:196,y:602,t:1528139595702};\\\", \\\"{x:189,y:592,t:1528139595718};\\\", \\\"{x:183,y:589,t:1528139595735};\\\", \\\"{x:175,y:585,t:1528139595751};\\\", \\\"{x:168,y:584,t:1528139595769};\\\", \\\"{x:162,y:583,t:1528139595785};\\\", \\\"{x:157,y:584,t:1528139595801};\\\", \\\"{x:150,y:588,t:1528139595819};\\\", \\\"{x:142,y:600,t:1528139595836};\\\", \\\"{x:134,y:613,t:1528139595852};\\\", \\\"{x:128,y:626,t:1528139595869};\\\", \\\"{x:126,y:642,t:1528139595885};\\\", \\\"{x:124,y:653,t:1528139595901};\\\", \\\"{x:124,y:666,t:1528139595919};\\\", \\\"{x:124,y:669,t:1528139595936};\\\", \\\"{x:124,y:670,t:1528139595953};\\\", \\\"{x:124,y:671,t:1528139595969};\\\", \\\"{x:126,y:673,t:1528139596151};\\\", \\\"{x:129,y:674,t:1528139596158};\\\", \\\"{x:131,y:675,t:1528139596169};\\\", \\\"{x:133,y:676,t:1528139596186};\\\", \\\"{x:134,y:676,t:1528139596367};\\\", \\\"{x:136,y:676,t:1528139596374};\\\", \\\"{x:137,y:676,t:1528139596385};\\\", \\\"{x:139,y:676,t:1528139596710};\\\", \\\"{x:150,y:676,t:1528139596720};\\\", \\\"{x:191,y:681,t:1528139596737};\\\", \\\"{x:269,y:692,t:1528139596753};\\\", \\\"{x:351,y:699,t:1528139596769};\\\", \\\"{x:400,y:703,t:1528139596787};\\\", \\\"{x:421,y:706,t:1528139596803};\\\", \\\"{x:424,y:707,t:1528139596820};\\\", \\\"{x:422,y:707,t:1528139596853};\\\", \\\"{x:411,y:707,t:1528139596871};\\\", \\\"{x:396,y:707,t:1528139596886};\\\", \\\"{x:389,y:707,t:1528139596903};\\\", \\\"{x:381,y:707,t:1528139596919};\\\", \\\"{x:379,y:707,t:1528139596936};\\\", \\\"{x:373,y:707,t:1528139596952};\\\", \\\"{x:356,y:705,t:1528139596969};\\\", \\\"{x:311,y:702,t:1528139596987};\\\", \\\"{x:256,y:698,t:1528139597002};\\\", \\\"{x:174,y:698,t:1528139597019};\\\", \\\"{x:125,y:698,t:1528139597036};\\\", \\\"{x:103,y:693,t:1528139597053};\\\", \\\"{x:91,y:692,t:1528139597070};\\\", \\\"{x:91,y:690,t:1528139597151};\\\", \\\"{x:91,y:689,t:1528139597159};\\\", \\\"{x:91,y:688,t:1528139597170};\\\", \\\"{x:99,y:681,t:1528139597188};\\\", \\\"{x:112,y:674,t:1528139597203};\\\", \\\"{x:131,y:668,t:1528139597220};\\\", \\\"{x:146,y:663,t:1528139597237};\\\", \\\"{x:162,y:661,t:1528139597253};\\\", \\\"{x:170,y:660,t:1528139597269};\\\", \\\"{x:172,y:660,t:1528139597286};\\\", \\\"{x:172,y:661,t:1528139597342};\\\", \\\"{x:171,y:663,t:1528139597359};\\\", \\\"{x:170,y:663,t:1528139597370};\\\", \\\"{x:169,y:664,t:1528139597387};\\\", \\\"{x:166,y:665,t:1528139597403};\\\", \\\"{x:166,y:666,t:1528139597419};\\\", \\\"{x:166,y:667,t:1528139597437};\\\", \\\"{x:166,y:668,t:1528139597487};\\\", \\\"{x:166,y:669,t:1528139597504};\\\", \\\"{x:172,y:669,t:1528139597814};\\\", \\\"{x:186,y:670,t:1528139597822};\\\", \\\"{x:207,y:672,t:1528139597837};\\\", \\\"{x:314,y:688,t:1528139597854};\\\", \\\"{x:381,y:699,t:1528139597870};\\\", \\\"{x:433,y:709,t:1528139597887};\\\", \\\"{x:451,y:715,t:1528139597904};\\\", \\\"{x:462,y:717,t:1528139597921};\\\", \\\"{x:463,y:717,t:1528139597937};\\\", \\\"{x:466,y:720,t:1528139598150};\\\", \\\"{x:466,y:722,t:1528139598159};\\\", \\\"{x:466,y:723,t:1528139598171};\\\", \\\"{x:471,y:737,t:1528139598189};\\\", \\\"{x:479,y:748,t:1528139598204};\\\", \\\"{x:481,y:758,t:1528139598221};\\\", \\\"{x:483,y:761,t:1528139598236};\\\", \\\"{x:483,y:762,t:1528139598253};\\\", \\\"{x:482,y:762,t:1528139598431};\\\", \\\"{x:501,y:753,t:1528139598967};\\\", \\\"{x:542,y:745,t:1528139598974};\\\", \\\"{x:585,y:738,t:1528139598988};\\\", \\\"{x:688,y:724,t:1528139599005};\\\", \\\"{x:814,y:716,t:1528139599020};\\\", \\\"{x:950,y:707,t:1528139599038};\\\", \\\"{x:1133,y:695,t:1528139599054};\\\", \\\"{x:1227,y:693,t:1528139599071};\\\", \\\"{x:1275,y:687,t:1528139599087};\\\", \\\"{x:1283,y:685,t:1528139599105};\\\", \\\"{x:1284,y:685,t:1528139599199};\\\", \\\"{x:1284,y:684,t:1528139599206};\\\", \\\"{x:1284,y:683,t:1528139599222};\\\" ] }, { \\\"rt\\\": 23642, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 7, \\\"time_elapsed\\\": 416034, \\\"internal_node_id\\\": \\\"0.0-5.0-2.0\\\", \\\"subject\\\": \\\"S6D2F\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 3, \\\"clicks\\\": 1, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"Z\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-C -10 AM-C \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:1285,y:682,t:1528139603023};\\\", \\\"{x:1294,y:689,t:1528139603042};\\\", \\\"{x:1302,y:700,t:1528139603059};\\\", \\\"{x:1307,y:715,t:1528139603075};\\\", \\\"{x:1309,y:729,t:1528139603091};\\\", \\\"{x:1312,y:746,t:1528139603109};\\\", \\\"{x:1312,y:761,t:1528139603125};\\\", \\\"{x:1312,y:770,t:1528139603141};\\\", \\\"{x:1312,y:777,t:1528139603158};\\\", \\\"{x:1312,y:780,t:1528139603175};\\\", \\\"{x:1312,y:781,t:1528139603191};\\\", \\\"{x:1311,y:787,t:1528139603208};\\\", \\\"{x:1307,y:792,t:1528139603225};\\\", \\\"{x:1298,y:804,t:1528139603242};\\\", \\\"{x:1293,y:814,t:1528139603258};\\\", \\\"{x:1291,y:822,t:1528139603275};\\\", \\\"{x:1289,y:830,t:1528139603292};\\\", \\\"{x:1287,y:841,t:1528139603308};\\\", \\\"{x:1286,y:852,t:1528139603326};\\\", \\\"{x:1286,y:862,t:1528139603341};\\\", \\\"{x:1289,y:882,t:1528139603358};\\\", \\\"{x:1290,y:896,t:1528139603375};\\\", \\\"{x:1291,y:903,t:1528139603391};\\\", \\\"{x:1293,y:908,t:1528139603408};\\\", \\\"{x:1293,y:911,t:1528139603426};\\\", \\\"{x:1294,y:914,t:1528139603442};\\\", \\\"{x:1295,y:914,t:1528139603470};\\\", \\\"{x:1296,y:917,t:1528139603502};\\\", \\\"{x:1297,y:919,t:1528139603510};\\\", \\\"{x:1298,y:923,t:1528139603525};\\\", \\\"{x:1308,y:935,t:1528139603541};\\\", \\\"{x:1313,y:950,t:1528139603558};\\\", \\\"{x:1313,y:952,t:1528139603574};\\\", \\\"{x:1313,y:953,t:1528139603591};\\\", \\\"{x:1313,y:951,t:1528139603959};\\\", \\\"{x:1306,y:943,t:1528139603975};\\\", \\\"{x:1301,y:939,t:1528139603992};\\\", \\\"{x:1298,y:936,t:1528139604008};\\\", \\\"{x:1298,y:935,t:1528139604025};\\\", \\\"{x:1298,y:933,t:1528139604042};\\\", \\\"{x:1296,y:930,t:1528139604058};\\\", \\\"{x:1295,y:925,t:1528139604076};\\\", \\\"{x:1291,y:919,t:1528139604093};\\\", \\\"{x:1285,y:912,t:1528139604109};\\\", \\\"{x:1278,y:907,t:1528139604125};\\\", \\\"{x:1270,y:898,t:1528139604142};\\\", \\\"{x:1264,y:895,t:1528139604158};\\\", \\\"{x:1261,y:892,t:1528139604175};\\\", \\\"{x:1257,y:889,t:1528139604193};\\\", \\\"{x:1248,y:885,t:1528139604210};\\\", \\\"{x:1240,y:880,t:1528139604226};\\\", \\\"{x:1229,y:874,t:1528139604242};\\\", \\\"{x:1220,y:868,t:1528139604260};\\\", \\\"{x:1215,y:864,t:1528139604276};\\\", \\\"{x:1213,y:862,t:1528139604292};\\\", \\\"{x:1210,y:860,t:1528139604309};\\\", \\\"{x:1210,y:859,t:1528139604325};\\\", \\\"{x:1210,y:856,t:1528139604343};\\\", \\\"{x:1210,y:851,t:1528139604358};\\\", \\\"{x:1210,y:850,t:1528139604375};\\\", \\\"{x:1210,y:848,t:1528139604393};\\\", \\\"{x:1210,y:847,t:1528139604409};\\\", \\\"{x:1210,y:846,t:1528139604455};\\\", \\\"{x:1210,y:844,t:1528139604463};\\\", \\\"{x:1210,y:843,t:1528139604510};\\\", \\\"{x:1210,y:841,t:1528139604526};\\\", \\\"{x:1210,y:839,t:1528139604551};\\\", \\\"{x:1211,y:837,t:1528139604559};\\\", \\\"{x:1211,y:835,t:1528139604576};\\\", \\\"{x:1211,y:834,t:1528139604598};\\\", \\\"{x:1212,y:832,t:1528139604609};\\\", \\\"{x:1212,y:831,t:1528139604626};\\\", \\\"{x:1213,y:828,t:1528139604643};\\\", \\\"{x:1213,y:827,t:1528139604670};\\\", \\\"{x:1213,y:826,t:1528139604685};\\\", \\\"{x:1214,y:825,t:1528139604710};\\\", \\\"{x:1214,y:826,t:1528139613543};\\\", \\\"{x:1214,y:827,t:1528139614054};\\\", \\\"{x:1214,y:828,t:1528139614078};\\\", \\\"{x:1214,y:830,t:1528139614089};\\\", \\\"{x:1214,y:831,t:1528139614105};\\\", \\\"{x:1216,y:834,t:1528139614123};\\\", \\\"{x:1220,y:841,t:1528139614155};\\\", \\\"{x:1221,y:845,t:1528139614172};\\\", \\\"{x:1224,y:853,t:1528139614184};\\\", \\\"{x:1225,y:858,t:1528139614200};\\\", \\\"{x:1228,y:866,t:1528139614217};\\\", \\\"{x:1230,y:876,t:1528139614234};\\\", \\\"{x:1233,y:889,t:1528139614249};\\\", \\\"{x:1235,y:903,t:1528139614267};\\\", \\\"{x:1237,y:920,t:1528139614284};\\\", \\\"{x:1239,y:934,t:1528139614300};\\\", \\\"{x:1243,y:951,t:1528139614317};\\\", \\\"{x:1243,y:970,t:1528139614334};\\\", \\\"{x:1243,y:984,t:1528139614350};\\\", \\\"{x:1241,y:996,t:1528139614367};\\\", \\\"{x:1241,y:1003,t:1528139614384};\\\", \\\"{x:1238,y:1012,t:1528139614400};\\\", \\\"{x:1238,y:1016,t:1528139614417};\\\", \\\"{x:1238,y:1017,t:1528139614434};\\\", \\\"{x:1238,y:1018,t:1528139614462};\\\", \\\"{x:1237,y:1018,t:1528139614533};\\\", \\\"{x:1237,y:1014,t:1528139614551};\\\", \\\"{x:1234,y:1008,t:1528139614567};\\\", \\\"{x:1232,y:1001,t:1528139614584};\\\", \\\"{x:1230,y:996,t:1528139614601};\\\", \\\"{x:1228,y:989,t:1528139614617};\\\", \\\"{x:1226,y:985,t:1528139614634};\\\", \\\"{x:1224,y:983,t:1528139614651};\\\", \\\"{x:1223,y:982,t:1528139614668};\\\", \\\"{x:1223,y:981,t:1528139614684};\\\", \\\"{x:1223,y:979,t:1528139614701};\\\", \\\"{x:1223,y:978,t:1528139614750};\\\", \\\"{x:1222,y:976,t:1528139614790};\\\", \\\"{x:1221,y:975,t:1528139614806};\\\", \\\"{x:1220,y:974,t:1528139614817};\\\", \\\"{x:1219,y:973,t:1528139614835};\\\", \\\"{x:1216,y:972,t:1528139614852};\\\", \\\"{x:1214,y:970,t:1528139614869};\\\", \\\"{x:1214,y:969,t:1528139614885};\\\", \\\"{x:1213,y:968,t:1528139614902};\\\", \\\"{x:1212,y:966,t:1528139614919};\\\", \\\"{x:1212,y:965,t:1528139614935};\\\", \\\"{x:1212,y:964,t:1528139614952};\\\", \\\"{x:1211,y:963,t:1528139614969};\\\", \\\"{x:1211,y:962,t:1528139614985};\\\", \\\"{x:1210,y:961,t:1528139615007};\\\", \\\"{x:1210,y:960,t:1528139615030};\\\", \\\"{x:1210,y:959,t:1528139615079};\\\", \\\"{x:1210,y:958,t:1528139615119};\\\", \\\"{x:1210,y:957,t:1528139615150};\\\", \\\"{x:1210,y:956,t:1528139615214};\\\", \\\"{x:1210,y:955,t:1528139615591};\\\", \\\"{x:1210,y:953,t:1528139615602};\\\", \\\"{x:1210,y:947,t:1528139615619};\\\", \\\"{x:1210,y:942,t:1528139615636};\\\", \\\"{x:1210,y:933,t:1528139615652};\\\", \\\"{x:1208,y:924,t:1528139615669};\\\", \\\"{x:1206,y:916,t:1528139615686};\\\", \\\"{x:1205,y:905,t:1528139615702};\\\", \\\"{x:1204,y:901,t:1528139615718};\\\", \\\"{x:1204,y:897,t:1528139615736};\\\", \\\"{x:1204,y:894,t:1528139615752};\\\", \\\"{x:1204,y:889,t:1528139615769};\\\", \\\"{x:1204,y:885,t:1528139615786};\\\", \\\"{x:1204,y:879,t:1528139615803};\\\", \\\"{x:1204,y:874,t:1528139615819};\\\", \\\"{x:1204,y:870,t:1528139615836};\\\", \\\"{x:1204,y:865,t:1528139615852};\\\", \\\"{x:1204,y:861,t:1528139615869};\\\", \\\"{x:1204,y:857,t:1528139615886};\\\", \\\"{x:1204,y:854,t:1528139615902};\\\", \\\"{x:1204,y:851,t:1528139615919};\\\", \\\"{x:1204,y:849,t:1528139615936};\\\", \\\"{x:1204,y:846,t:1528139615953};\\\", \\\"{x:1204,y:843,t:1528139615969};\\\", \\\"{x:1204,y:841,t:1528139615986};\\\", \\\"{x:1204,y:838,t:1528139616003};\\\", \\\"{x:1204,y:836,t:1528139616019};\\\", \\\"{x:1204,y:833,t:1528139616036};\\\", \\\"{x:1204,y:829,t:1528139616053};\\\", \\\"{x:1204,y:826,t:1528139616070};\\\", \\\"{x:1204,y:823,t:1528139616086};\\\", \\\"{x:1204,y:821,t:1528139616103};\\\", \\\"{x:1204,y:820,t:1528139616126};\\\", \\\"{x:1205,y:820,t:1528139616815};\\\", \\\"{x:1205,y:821,t:1528139616983};\\\", \\\"{x:1206,y:821,t:1528139617087};\\\", \\\"{x:1206,y:822,t:1528139617111};\\\", \\\"{x:1207,y:823,t:1528139617214};\\\", \\\"{x:1209,y:824,t:1528139618430};\\\", \\\"{x:1211,y:826,t:1528139619091};\\\", \\\"{x:1219,y:831,t:1528139619104};\\\", \\\"{x:1231,y:837,t:1528139619122};\\\", \\\"{x:1247,y:843,t:1528139619139};\\\", \\\"{x:1256,y:847,t:1528139619154};\\\", \\\"{x:1267,y:851,t:1528139619171};\\\", \\\"{x:1270,y:852,t:1528139619189};\\\", \\\"{x:1274,y:854,t:1528139619204};\\\", \\\"{x:1277,y:856,t:1528139619221};\\\", \\\"{x:1279,y:856,t:1528139619238};\\\", \\\"{x:1281,y:858,t:1528139619255};\\\", \\\"{x:1283,y:858,t:1528139619272};\\\", \\\"{x:1287,y:859,t:1528139619288};\\\", \\\"{x:1295,y:860,t:1528139619304};\\\", \\\"{x:1307,y:863,t:1528139619321};\\\", \\\"{x:1318,y:864,t:1528139619338};\\\", \\\"{x:1330,y:867,t:1528139619354};\\\", \\\"{x:1333,y:867,t:1528139619372};\\\", \\\"{x:1327,y:867,t:1528139619446};\\\", \\\"{x:1314,y:867,t:1528139619455};\\\", \\\"{x:1262,y:867,t:1528139619472};\\\", \\\"{x:1153,y:862,t:1528139619490};\\\", \\\"{x:1006,y:843,t:1528139619506};\\\", \\\"{x:847,y:827,t:1528139619522};\\\", \\\"{x:708,y:806,t:1528139619538};\\\", \\\"{x:586,y:785,t:1528139619556};\\\", \\\"{x:505,y:763,t:1528139619574};\\\", \\\"{x:489,y:756,t:1528139619588};\\\", \\\"{x:479,y:748,t:1528139619605};\\\", \\\"{x:477,y:744,t:1528139619621};\\\", \\\"{x:477,y:741,t:1528139619638};\\\", \\\"{x:477,y:738,t:1528139619655};\\\", \\\"{x:474,y:732,t:1528139619671};\\\", \\\"{x:470,y:725,t:1528139619688};\\\", \\\"{x:465,y:719,t:1528139619706};\\\", \\\"{x:458,y:711,t:1528139619721};\\\", \\\"{x:452,y:702,t:1528139619739};\\\", \\\"{x:444,y:692,t:1528139619755};\\\", \\\"{x:442,y:689,t:1528139619771};\\\", \\\"{x:440,y:685,t:1528139619789};\\\", \\\"{x:439,y:681,t:1528139619805};\\\", \\\"{x:435,y:676,t:1528139619822};\\\", \\\"{x:429,y:672,t:1528139619838};\\\", \\\"{x:423,y:670,t:1528139619855};\\\", \\\"{x:417,y:665,t:1528139619873};\\\", \\\"{x:410,y:660,t:1528139619888};\\\", \\\"{x:402,y:656,t:1528139619905};\\\", \\\"{x:389,y:651,t:1528139619922};\\\", \\\"{x:377,y:646,t:1528139619939};\\\", \\\"{x:364,y:641,t:1528139619955};\\\", \\\"{x:359,y:640,t:1528139619972};\\\", \\\"{x:359,y:639,t:1528139619988};\\\", \\\"{x:358,y:639,t:1528139620005};\\\", \\\"{x:358,y:638,t:1528139620158};\\\", \\\"{x:358,y:637,t:1528139620190};\\\", \\\"{x:363,y:635,t:1528139620206};\\\", \\\"{x:366,y:634,t:1528139620222};\\\", \\\"{x:371,y:632,t:1528139620238};\\\", \\\"{x:372,y:632,t:1528139620255};\\\", \\\"{x:375,y:631,t:1528139620274};\\\", \\\"{x:380,y:631,t:1528139620289};\\\", \\\"{x:387,y:630,t:1528139620305};\\\", \\\"{x:401,y:627,t:1528139620321};\\\", \\\"{x:413,y:627,t:1528139620338};\\\", \\\"{x:430,y:627,t:1528139620356};\\\", \\\"{x:443,y:627,t:1528139620371};\\\", \\\"{x:462,y:627,t:1528139620389};\\\", \\\"{x:475,y:627,t:1528139620405};\\\", \\\"{x:478,y:627,t:1528139620423};\\\", \\\"{x:480,y:627,t:1528139620439};\\\", \\\"{x:480,y:628,t:1528139620462};\\\", \\\"{x:480,y:629,t:1528139620477};\\\", \\\"{x:480,y:630,t:1528139620489};\\\", \\\"{x:480,y:633,t:1528139620506};\\\", \\\"{x:477,y:636,t:1528139620522};\\\", \\\"{x:470,y:648,t:1528139620539};\\\", \\\"{x:464,y:664,t:1528139620557};\\\", \\\"{x:460,y:672,t:1528139620572};\\\", \\\"{x:460,y:673,t:1528139620589};\\\", \\\"{x:463,y:675,t:1528139620604};\\\", \\\"{x:465,y:675,t:1528139620622};\\\", \\\"{x:473,y:670,t:1528139620639};\\\", \\\"{x:492,y:660,t:1528139620655};\\\", \\\"{x:513,y:652,t:1528139620673};\\\", \\\"{x:536,y:647,t:1528139620689};\\\", \\\"{x:566,y:640,t:1528139620706};\\\", \\\"{x:595,y:637,t:1528139620722};\\\", \\\"{x:614,y:637,t:1528139620740};\\\", \\\"{x:641,y:637,t:1528139620756};\\\", \\\"{x:656,y:637,t:1528139620772};\\\", \\\"{x:661,y:637,t:1528139620789};\\\", \\\"{x:662,y:637,t:1528139620846};\\\", \\\"{x:663,y:637,t:1528139620870};\\\", \\\"{x:663,y:640,t:1528139620894};\\\", \\\"{x:660,y:644,t:1528139620906};\\\", \\\"{x:647,y:652,t:1528139620924};\\\", \\\"{x:630,y:664,t:1528139620940};\\\", \\\"{x:600,y:674,t:1528139620956};\\\", \\\"{x:569,y:678,t:1528139620973};\\\", \\\"{x:503,y:689,t:1528139620989};\\\", \\\"{x:458,y:689,t:1528139621006};\\\", \\\"{x:418,y:689,t:1528139621022};\\\", \\\"{x:398,y:685,t:1528139621039};\\\", \\\"{x:383,y:677,t:1528139621056};\\\", \\\"{x:380,y:675,t:1528139621073};\\\", \\\"{x:378,y:675,t:1528139621089};\\\", \\\"{x:377,y:673,t:1528139621106};\\\", \\\"{x:375,y:673,t:1528139621123};\\\", \\\"{x:372,y:673,t:1528139621140};\\\", \\\"{x:364,y:672,t:1528139621156};\\\", \\\"{x:358,y:669,t:1528139621174};\\\", \\\"{x:342,y:667,t:1528139621190};\\\", \\\"{x:309,y:667,t:1528139621206};\\\", \\\"{x:286,y:667,t:1528139621224};\\\", \\\"{x:266,y:667,t:1528139621242};\\\", \\\"{x:249,y:667,t:1528139621256};\\\", \\\"{x:233,y:667,t:1528139621273};\\\", \\\"{x:222,y:667,t:1528139621289};\\\", \\\"{x:215,y:668,t:1528139621307};\\\", \\\"{x:211,y:669,t:1528139621323};\\\", \\\"{x:206,y:670,t:1528139621339};\\\", \\\"{x:201,y:673,t:1528139621356};\\\", \\\"{x:190,y:676,t:1528139621374};\\\", \\\"{x:181,y:678,t:1528139621389};\\\", \\\"{x:170,y:681,t:1528139621406};\\\", \\\"{x:165,y:681,t:1528139621424};\\\", \\\"{x:163,y:681,t:1528139621440};\\\", \\\"{x:162,y:681,t:1528139621456};\\\", \\\"{x:160,y:681,t:1528139621501};\\\", \\\"{x:159,y:681,t:1528139621509};\\\", \\\"{x:156,y:681,t:1528139621523};\\\", \\\"{x:153,y:678,t:1528139621540};\\\", \\\"{x:151,y:674,t:1528139621557};\\\", \\\"{x:147,y:664,t:1528139621574};\\\", \\\"{x:147,y:656,t:1528139621590};\\\", \\\"{x:146,y:646,t:1528139621608};\\\", \\\"{x:144,y:638,t:1528139621623};\\\", \\\"{x:144,y:633,t:1528139621640};\\\", \\\"{x:144,y:627,t:1528139621656};\\\", \\\"{x:144,y:622,t:1528139621673};\\\", \\\"{x:144,y:618,t:1528139621691};\\\", \\\"{x:144,y:615,t:1528139621707};\\\", \\\"{x:144,y:613,t:1528139621724};\\\", \\\"{x:145,y:610,t:1528139621741};\\\", \\\"{x:147,y:609,t:1528139621756};\\\", \\\"{x:154,y:606,t:1528139621774};\\\", \\\"{x:164,y:603,t:1528139621791};\\\", \\\"{x:168,y:602,t:1528139621806};\\\", \\\"{x:170,y:601,t:1528139621824};\\\", \\\"{x:171,y:601,t:1528139621894};\\\", \\\"{x:172,y:601,t:1528139621926};\\\", \\\"{x:171,y:603,t:1528139621958};\\\", \\\"{x:169,y:603,t:1528139622199};\\\", \\\"{x:167,y:603,t:1528139622207};\\\", \\\"{x:162,y:601,t:1528139622223};\\\", \\\"{x:161,y:601,t:1528139622239};\\\", \\\"{x:160,y:601,t:1528139622366};\\\", \\\"{x:158,y:601,t:1528139622421};\\\", \\\"{x:158,y:601,t:1528139622434};\\\", \\\"{x:157,y:601,t:1528139622445};\\\", \\\"{x:156,y:601,t:1528139622458};\\\", \\\"{x:156,y:602,t:1528139622525};\\\", \\\"{x:157,y:603,t:1528139622541};\\\", \\\"{x:165,y:606,t:1528139622557};\\\", \\\"{x:181,y:610,t:1528139622575};\\\", \\\"{x:204,y:615,t:1528139622591};\\\", \\\"{x:237,y:625,t:1528139622608};\\\", \\\"{x:283,y:635,t:1528139622625};\\\", \\\"{x:332,y:646,t:1528139622641};\\\", \\\"{x:388,y:656,t:1528139622658};\\\", \\\"{x:442,y:664,t:1528139622674};\\\", \\\"{x:477,y:671,t:1528139622691};\\\", \\\"{x:502,y:677,t:1528139622707};\\\", \\\"{x:521,y:680,t:1528139622724};\\\", \\\"{x:530,y:682,t:1528139622741};\\\", \\\"{x:530,y:683,t:1528139622797};\\\", \\\"{x:530,y:685,t:1528139622813};\\\", \\\"{x:531,y:687,t:1528139622825};\\\", \\\"{x:532,y:694,t:1528139622841};\\\", \\\"{x:532,y:698,t:1528139622858};\\\", \\\"{x:532,y:702,t:1528139622875};\\\", \\\"{x:528,y:709,t:1528139622891};\\\", \\\"{x:526,y:715,t:1528139622907};\\\", \\\"{x:519,y:725,t:1528139622925};\\\", \\\"{x:518,y:732,t:1528139622941};\\\", \\\"{x:516,y:735,t:1528139622958};\\\", \\\"{x:516,y:736,t:1528139622974};\\\", \\\"{x:515,y:738,t:1528139622992};\\\", \\\"{x:513,y:742,t:1528139623007};\\\", \\\"{x:512,y:742,t:1528139623025};\\\", \\\"{x:512,y:745,t:1528139623042};\\\", \\\"{x:511,y:747,t:1528139623058};\\\", \\\"{x:509,y:751,t:1528139623074};\\\", \\\"{x:508,y:753,t:1528139623092};\\\", \\\"{x:508,y:755,t:1528139623109};\\\", \\\"{x:507,y:756,t:1528139623125};\\\", \\\"{x:506,y:757,t:1528139623142};\\\", \\\"{x:505,y:758,t:1528139623159};\\\", \\\"{x:505,y:759,t:1528139623182};\\\", \\\"{x:505,y:760,t:1528139623197};\\\" ] }, { \\\"rt\\\": 17691, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 8, \\\"time_elapsed\\\": 434996, \\\"internal_node_id\\\": \\\"0.0-5.0-3.0\\\", \\\"subject\\\": \\\"S6D2F\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 4, \\\"clicks\\\": 2, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"X\\\", \\\"U\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-12 PM-04 PM-04 PM-04 PM-03 PM-02 PM-U -U -U -J -02 PM-U -X \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:504,y:760,t:1528139624815};\\\", \\\"{x:512,y:761,t:1528139625678};\\\", \\\"{x:548,y:766,t:1528139625695};\\\", \\\"{x:581,y:772,t:1528139625714};\\\", \\\"{x:641,y:784,t:1528139625729};\\\", \\\"{x:721,y:795,t:1528139625743};\\\", \\\"{x:791,y:804,t:1528139625760};\\\", \\\"{x:826,y:810,t:1528139625777};\\\", \\\"{x:844,y:816,t:1528139625793};\\\", \\\"{x:855,y:820,t:1528139625809};\\\", \\\"{x:857,y:820,t:1528139625826};\\\", \\\"{x:858,y:820,t:1528139626958};\\\", \\\"{x:863,y:820,t:1528139626966};\\\", \\\"{x:873,y:820,t:1528139626976};\\\", \\\"{x:896,y:817,t:1528139626993};\\\", \\\"{x:945,y:816,t:1528139627010};\\\", \\\"{x:998,y:816,t:1528139627027};\\\", \\\"{x:1040,y:816,t:1528139627043};\\\", \\\"{x:1084,y:819,t:1528139627060};\\\", \\\"{x:1127,y:826,t:1528139627077};\\\", \\\"{x:1169,y:832,t:1528139627093};\\\", \\\"{x:1212,y:839,t:1528139627110};\\\", \\\"{x:1227,y:841,t:1528139627127};\\\", \\\"{x:1237,y:846,t:1528139627144};\\\", \\\"{x:1240,y:849,t:1528139627160};\\\", \\\"{x:1243,y:851,t:1528139627177};\\\", \\\"{x:1244,y:851,t:1528139627193};\\\", \\\"{x:1244,y:852,t:1528139627768};\\\", \\\"{x:1244,y:854,t:1528139627784};\\\", \\\"{x:1241,y:856,t:1528139627792};\\\", \\\"{x:1234,y:860,t:1528139627805};\\\", \\\"{x:1219,y:869,t:1528139627820};\\\", \\\"{x:1201,y:881,t:1528139627837};\\\", \\\"{x:1187,y:892,t:1528139627854};\\\", \\\"{x:1176,y:903,t:1528139627870};\\\", \\\"{x:1170,y:912,t:1528139627887};\\\", \\\"{x:1166,y:926,t:1528139627904};\\\", \\\"{x:1167,y:940,t:1528139627921};\\\", \\\"{x:1176,y:951,t:1528139627937};\\\", \\\"{x:1199,y:963,t:1528139627955};\\\", \\\"{x:1257,y:975,t:1528139627971};\\\", \\\"{x:1350,y:980,t:1528139627987};\\\", \\\"{x:1444,y:980,t:1528139628005};\\\", \\\"{x:1525,y:980,t:1528139628020};\\\", \\\"{x:1572,y:984,t:1528139628037};\\\", \\\"{x:1607,y:980,t:1528139628055};\\\", \\\"{x:1632,y:976,t:1528139628070};\\\", \\\"{x:1652,y:972,t:1528139628088};\\\", \\\"{x:1669,y:967,t:1528139628104};\\\", \\\"{x:1681,y:964,t:1528139628119};\\\", \\\"{x:1692,y:957,t:1528139628137};\\\", \\\"{x:1703,y:955,t:1528139628154};\\\", \\\"{x:1718,y:950,t:1528139628170};\\\", \\\"{x:1733,y:945,t:1528139628187};\\\", \\\"{x:1743,y:941,t:1528139628204};\\\", \\\"{x:1747,y:940,t:1528139628220};\\\", \\\"{x:1748,y:940,t:1528139628272};\\\", \\\"{x:1747,y:938,t:1528139628288};\\\", \\\"{x:1736,y:939,t:1528139628304};\\\", \\\"{x:1721,y:943,t:1528139628320};\\\", \\\"{x:1684,y:953,t:1528139628337};\\\", \\\"{x:1644,y:965,t:1528139628354};\\\", \\\"{x:1592,y:980,t:1528139628370};\\\", \\\"{x:1563,y:986,t:1528139628388};\\\", \\\"{x:1541,y:994,t:1528139628404};\\\", \\\"{x:1529,y:998,t:1528139628420};\\\", \\\"{x:1521,y:1001,t:1528139628437};\\\", \\\"{x:1518,y:1002,t:1528139628454};\\\", \\\"{x:1523,y:1002,t:1528139628584};\\\", \\\"{x:1534,y:1000,t:1528139628591};\\\", \\\"{x:1537,y:999,t:1528139628604};\\\", \\\"{x:1560,y:992,t:1528139628620};\\\", \\\"{x:1588,y:981,t:1528139628637};\\\", \\\"{x:1600,y:975,t:1528139628654};\\\", \\\"{x:1608,y:970,t:1528139628670};\\\", \\\"{x:1610,y:968,t:1528139628687};\\\", \\\"{x:1611,y:966,t:1528139628704};\\\", \\\"{x:1611,y:965,t:1528139628751};\\\", \\\"{x:1612,y:965,t:1528139628760};\\\", \\\"{x:1613,y:964,t:1528139628776};\\\", \\\"{x:1613,y:963,t:1528139628792};\\\", \\\"{x:1613,y:962,t:1528139628808};\\\", \\\"{x:1614,y:962,t:1528139628821};\\\", \\\"{x:1614,y:961,t:1528139628848};\\\", \\\"{x:1612,y:964,t:1528139629943};\\\", \\\"{x:1612,y:965,t:1528139629954};\\\", \\\"{x:1612,y:967,t:1528139629969};\\\", \\\"{x:1611,y:969,t:1528139629987};\\\", \\\"{x:1611,y:970,t:1528139630024};\\\", \\\"{x:1611,y:969,t:1528139630272};\\\", \\\"{x:1611,y:967,t:1528139630288};\\\", \\\"{x:1611,y:966,t:1528139630304};\\\", \\\"{x:1611,y:964,t:1528139630328};\\\", \\\"{x:1611,y:963,t:1528139630343};\\\", \\\"{x:1611,y:961,t:1528139630368};\\\", \\\"{x:1609,y:959,t:1528139630673};\\\", \\\"{x:1607,y:959,t:1528139630687};\\\", \\\"{x:1598,y:963,t:1528139630705};\\\", \\\"{x:1588,y:969,t:1528139630722};\\\", \\\"{x:1572,y:972,t:1528139630737};\\\", \\\"{x:1554,y:975,t:1528139630754};\\\", \\\"{x:1516,y:977,t:1528139630771};\\\", \\\"{x:1466,y:977,t:1528139630787};\\\", \\\"{x:1369,y:977,t:1528139630805};\\\", \\\"{x:1247,y:977,t:1528139630822};\\\", \\\"{x:1111,y:961,t:1528139630837};\\\", \\\"{x:970,y:940,t:1528139630854};\\\", \\\"{x:826,y:918,t:1528139630871};\\\", \\\"{x:668,y:896,t:1528139630887};\\\", \\\"{x:415,y:879,t:1528139630904};\\\", \\\"{x:241,y:856,t:1528139630921};\\\", \\\"{x:68,y:841,t:1528139630937};\\\", \\\"{x:0,y:824,t:1528139630954};\\\", \\\"{x:0,y:814,t:1528139630971};\\\", \\\"{x:0,y:802,t:1528139630987};\\\", \\\"{x:0,y:800,t:1528139631004};\\\", \\\"{x:0,y:798,t:1528139631022};\\\", \\\"{x:0,y:797,t:1528139631039};\\\", \\\"{x:0,y:794,t:1528139631054};\\\", \\\"{x:5,y:788,t:1528139631071};\\\", \\\"{x:26,y:776,t:1528139631087};\\\", \\\"{x:103,y:749,t:1528139631104};\\\", \\\"{x:170,y:729,t:1528139631121};\\\", \\\"{x:250,y:711,t:1528139631137};\\\", \\\"{x:340,y:692,t:1528139631155};\\\", \\\"{x:425,y:684,t:1528139631173};\\\", \\\"{x:508,y:675,t:1528139631188};\\\", \\\"{x:569,y:675,t:1528139631204};\\\", \\\"{x:613,y:675,t:1528139631225};\\\", \\\"{x:622,y:675,t:1528139631242};\\\", \\\"{x:623,y:675,t:1528139631258};\\\", \\\"{x:626,y:674,t:1528139631351};\\\", \\\"{x:627,y:673,t:1528139631383};\\\", \\\"{x:627,y:672,t:1528139631399};\\\", \\\"{x:627,y:671,t:1528139631409};\\\", \\\"{x:630,y:664,t:1528139631425};\\\", \\\"{x:632,y:659,t:1528139631442};\\\", \\\"{x:632,y:652,t:1528139631460};\\\", \\\"{x:631,y:642,t:1528139631475};\\\", \\\"{x:627,y:637,t:1528139631492};\\\", \\\"{x:625,y:634,t:1528139631508};\\\", \\\"{x:624,y:634,t:1528139631632};\\\", \\\"{x:623,y:637,t:1528139631871};\\\", \\\"{x:617,y:648,t:1528139631879};\\\", \\\"{x:612,y:658,t:1528139631893};\\\", \\\"{x:604,y:672,t:1528139631909};\\\", \\\"{x:593,y:689,t:1528139631926};\\\", \\\"{x:585,y:707,t:1528139631941};\\\", \\\"{x:580,y:717,t:1528139631959};\\\", \\\"{x:577,y:727,t:1528139631974};\\\", \\\"{x:576,y:730,t:1528139631992};\\\", \\\"{x:576,y:731,t:1528139632008};\\\", \\\"{x:576,y:733,t:1528139632031};\\\", \\\"{x:576,y:734,t:1528139632071};\\\", \\\"{x:576,y:736,t:1528139632176};\\\", \\\"{x:576,y:737,t:1528139632190};\\\", \\\"{x:579,y:742,t:1528139632208};\\\", \\\"{x:606,y:748,t:1528139632225};\\\", \\\"{x:704,y:763,t:1528139632240};\\\", \\\"{x:905,y:784,t:1528139632258};\\\", \\\"{x:1156,y:784,t:1528139632275};\\\", \\\"{x:1446,y:786,t:1528139632291};\\\", \\\"{x:1747,y:786,t:1528139632308};\\\", \\\"{x:1919,y:786,t:1528139632325};\\\", \\\"{x:1919,y:787,t:1528139632424};\\\", \\\"{x:1919,y:789,t:1528139632432};\\\", \\\"{x:1917,y:790,t:1528139632443};\\\", \\\"{x:1903,y:797,t:1528139632459};\\\", \\\"{x:1858,y:809,t:1528139632477};\\\", \\\"{x:1775,y:831,t:1528139632493};\\\", \\\"{x:1678,y:847,t:1528139632508};\\\", \\\"{x:1576,y:859,t:1528139632526};\\\", \\\"{x:1483,y:874,t:1528139632544};\\\", \\\"{x:1433,y:881,t:1528139632559};\\\", \\\"{x:1399,y:888,t:1528139632576};\\\", \\\"{x:1389,y:892,t:1528139632593};\\\", \\\"{x:1386,y:893,t:1528139632609};\\\", \\\"{x:1384,y:894,t:1528139632627};\\\", \\\"{x:1381,y:895,t:1528139632644};\\\", \\\"{x:1380,y:895,t:1528139632659};\\\", \\\"{x:1379,y:895,t:1528139632688};\\\", \\\"{x:1378,y:895,t:1528139632712};\\\", \\\"{x:1380,y:893,t:1528139632726};\\\", \\\"{x:1384,y:888,t:1528139632743};\\\", \\\"{x:1404,y:877,t:1528139632760};\\\", \\\"{x:1421,y:871,t:1528139632776};\\\", \\\"{x:1434,y:866,t:1528139632794};\\\", \\\"{x:1442,y:862,t:1528139632809};\\\", \\\"{x:1453,y:857,t:1528139632826};\\\", \\\"{x:1457,y:856,t:1528139632843};\\\", \\\"{x:1461,y:853,t:1528139632860};\\\", \\\"{x:1465,y:850,t:1528139632877};\\\", \\\"{x:1468,y:848,t:1528139632893};\\\", \\\"{x:1471,y:846,t:1528139632911};\\\", \\\"{x:1473,y:844,t:1528139632927};\\\", \\\"{x:1475,y:842,t:1528139632943};\\\", \\\"{x:1476,y:840,t:1528139632960};\\\", \\\"{x:1477,y:837,t:1528139632976};\\\", \\\"{x:1477,y:836,t:1528139633008};\\\", \\\"{x:1477,y:835,t:1528139633016};\\\", \\\"{x:1477,y:834,t:1528139633031};\\\", \\\"{x:1477,y:833,t:1528139633060};\\\", \\\"{x:1476,y:833,t:1528139633077};\\\", \\\"{x:1474,y:831,t:1528139633093};\\\", \\\"{x:1471,y:829,t:1528139633110};\\\", \\\"{x:1468,y:828,t:1528139633126};\\\", \\\"{x:1467,y:828,t:1528139633143};\\\", \\\"{x:1468,y:828,t:1528139633320};\\\", \\\"{x:1470,y:828,t:1528139633352};\\\", \\\"{x:1471,y:828,t:1528139633368};\\\", \\\"{x:1473,y:828,t:1528139633383};\\\", \\\"{x:1474,y:828,t:1528139633399};\\\", \\\"{x:1476,y:828,t:1528139633419};\\\", \\\"{x:1478,y:828,t:1528139633426};\\\", \\\"{x:1479,y:828,t:1528139633443};\\\", \\\"{x:1480,y:828,t:1528139633459};\\\", \\\"{x:1481,y:827,t:1528139633502};\\\", \\\"{x:1482,y:827,t:1528139633535};\\\", \\\"{x:1482,y:826,t:1528139633543};\\\", \\\"{x:1484,y:821,t:1528139633561};\\\", \\\"{x:1485,y:817,t:1528139633577};\\\", \\\"{x:1487,y:812,t:1528139633593};\\\", \\\"{x:1487,y:808,t:1528139633610};\\\", \\\"{x:1487,y:803,t:1528139633627};\\\", \\\"{x:1487,y:799,t:1528139633644};\\\", \\\"{x:1487,y:796,t:1528139633660};\\\", \\\"{x:1487,y:792,t:1528139633677};\\\", \\\"{x:1487,y:788,t:1528139633694};\\\", \\\"{x:1487,y:785,t:1528139633710};\\\", \\\"{x:1486,y:777,t:1528139633728};\\\", \\\"{x:1484,y:774,t:1528139633743};\\\", \\\"{x:1484,y:771,t:1528139633760};\\\", \\\"{x:1482,y:769,t:1528139633777};\\\", \\\"{x:1480,y:764,t:1528139633794};\\\", \\\"{x:1479,y:758,t:1528139633811};\\\", \\\"{x:1477,y:754,t:1528139633827};\\\", \\\"{x:1475,y:747,t:1528139633845};\\\", \\\"{x:1473,y:740,t:1528139633860};\\\", \\\"{x:1472,y:733,t:1528139633877};\\\", \\\"{x:1470,y:724,t:1528139633895};\\\", \\\"{x:1468,y:713,t:1528139633910};\\\", \\\"{x:1466,y:694,t:1528139633928};\\\", \\\"{x:1464,y:683,t:1528139633945};\\\", \\\"{x:1464,y:674,t:1528139633961};\\\", \\\"{x:1464,y:661,t:1528139633976};\\\", \\\"{x:1464,y:649,t:1528139633994};\\\", \\\"{x:1465,y:638,t:1528139634011};\\\", \\\"{x:1467,y:628,t:1528139634026};\\\", \\\"{x:1469,y:621,t:1528139634044};\\\", \\\"{x:1470,y:613,t:1528139634060};\\\", \\\"{x:1472,y:607,t:1528139634076};\\\", \\\"{x:1472,y:602,t:1528139634093};\\\", \\\"{x:1474,y:593,t:1528139634111};\\\", \\\"{x:1474,y:592,t:1528139634127};\\\", \\\"{x:1476,y:586,t:1528139634144};\\\", \\\"{x:1477,y:582,t:1528139634160};\\\", \\\"{x:1477,y:579,t:1528139634177};\\\", \\\"{x:1478,y:575,t:1528139634194};\\\", \\\"{x:1478,y:572,t:1528139634211};\\\", \\\"{x:1478,y:568,t:1528139634227};\\\", \\\"{x:1478,y:565,t:1528139634244};\\\", \\\"{x:1478,y:562,t:1528139634261};\\\", \\\"{x:1478,y:559,t:1528139634278};\\\", \\\"{x:1478,y:554,t:1528139634294};\\\", \\\"{x:1475,y:543,t:1528139634311};\\\", \\\"{x:1474,y:536,t:1528139634327};\\\", \\\"{x:1471,y:529,t:1528139634343};\\\", \\\"{x:1470,y:520,t:1528139634361};\\\", \\\"{x:1469,y:512,t:1528139634378};\\\", \\\"{x:1469,y:505,t:1528139634394};\\\", \\\"{x:1467,y:496,t:1528139634411};\\\", \\\"{x:1467,y:493,t:1528139634428};\\\", \\\"{x:1465,y:485,t:1528139634444};\\\", \\\"{x:1465,y:481,t:1528139634461};\\\", \\\"{x:1464,y:476,t:1528139634478};\\\", \\\"{x:1463,y:474,t:1528139634494};\\\", \\\"{x:1463,y:472,t:1528139634512};\\\", \\\"{x:1462,y:471,t:1528139634599};\\\", \\\"{x:1460,y:471,t:1528139634623};\\\", \\\"{x:1456,y:476,t:1528139634631};\\\", \\\"{x:1453,y:482,t:1528139634644};\\\", \\\"{x:1441,y:496,t:1528139634661};\\\", \\\"{x:1426,y:512,t:1528139634678};\\\", \\\"{x:1407,y:530,t:1528139634694};\\\", \\\"{x:1384,y:552,t:1528139634711};\\\", \\\"{x:1375,y:562,t:1528139634728};\\\", \\\"{x:1372,y:565,t:1528139634745};\\\", \\\"{x:1373,y:564,t:1528139634824};\\\", \\\"{x:1375,y:560,t:1528139634831};\\\", \\\"{x:1380,y:552,t:1528139634845};\\\", \\\"{x:1387,y:537,t:1528139634862};\\\", \\\"{x:1396,y:521,t:1528139634879};\\\", \\\"{x:1407,y:490,t:1528139634896};\\\", \\\"{x:1409,y:482,t:1528139634912};\\\", \\\"{x:1413,y:449,t:1528139634928};\\\", \\\"{x:1413,y:425,t:1528139634949};\\\", \\\"{x:1414,y:404,t:1528139634961};\\\", \\\"{x:1414,y:376,t:1528139634977};\\\", \\\"{x:1414,y:345,t:1528139634994};\\\", \\\"{x:1414,y:319,t:1528139635011};\\\", \\\"{x:1414,y:298,t:1528139635027};\\\", \\\"{x:1414,y:282,t:1528139635044};\\\", \\\"{x:1414,y:277,t:1528139635061};\\\", \\\"{x:1414,y:276,t:1528139635077};\\\", \\\"{x:1415,y:275,t:1528139635111};\\\", \\\"{x:1422,y:286,t:1528139635127};\\\", \\\"{x:1430,y:315,t:1528139635144};\\\", \\\"{x:1438,y:374,t:1528139635161};\\\", \\\"{x:1455,y:464,t:1528139635178};\\\", \\\"{x:1485,y:564,t:1528139635194};\\\", \\\"{x:1522,y:673,t:1528139635211};\\\", \\\"{x:1556,y:781,t:1528139635227};\\\", \\\"{x:1598,y:872,t:1528139635244};\\\", \\\"{x:1627,y:941,t:1528139635261};\\\", \\\"{x:1646,y:990,t:1528139635277};\\\", \\\"{x:1655,y:1018,t:1528139635294};\\\", \\\"{x:1657,y:1032,t:1528139635311};\\\", \\\"{x:1654,y:1034,t:1528139635327};\\\", \\\"{x:1649,y:1034,t:1528139635344};\\\", \\\"{x:1635,y:1033,t:1528139635361};\\\", \\\"{x:1612,y:1026,t:1528139635378};\\\", \\\"{x:1589,y:1019,t:1528139635394};\\\", \\\"{x:1561,y:1009,t:1528139635411};\\\", \\\"{x:1527,y:994,t:1528139635428};\\\", \\\"{x:1509,y:983,t:1528139635444};\\\", \\\"{x:1500,y:974,t:1528139635461};\\\", \\\"{x:1497,y:960,t:1528139635478};\\\", \\\"{x:1494,y:942,t:1528139635495};\\\", \\\"{x:1498,y:912,t:1528139635511};\\\", \\\"{x:1503,y:895,t:1528139635528};\\\", \\\"{x:1504,y:881,t:1528139635545};\\\", \\\"{x:1507,y:866,t:1528139635560};\\\", \\\"{x:1508,y:858,t:1528139635578};\\\", \\\"{x:1509,y:848,t:1528139635594};\\\", \\\"{x:1511,y:836,t:1528139635611};\\\", \\\"{x:1511,y:817,t:1528139635628};\\\", \\\"{x:1510,y:799,t:1528139635644};\\\", \\\"{x:1501,y:779,t:1528139635660};\\\", \\\"{x:1493,y:767,t:1528139635678};\\\", \\\"{x:1483,y:752,t:1528139635694};\\\", \\\"{x:1474,y:742,t:1528139635712};\\\", \\\"{x:1471,y:738,t:1528139635727};\\\", \\\"{x:1470,y:737,t:1528139635744};\\\", \\\"{x:1468,y:737,t:1528139635761};\\\", \\\"{x:1468,y:736,t:1528139635779};\\\", \\\"{x:1467,y:735,t:1528139635799};\\\", \\\"{x:1467,y:733,t:1528139635831};\\\", \\\"{x:1467,y:732,t:1528139635847};\\\", \\\"{x:1467,y:731,t:1528139635953};\\\", \\\"{x:1467,y:728,t:1528139635968};\\\", \\\"{x:1467,y:727,t:1528139635979};\\\", \\\"{x:1467,y:723,t:1528139635994};\\\", \\\"{x:1467,y:718,t:1528139636012};\\\", \\\"{x:1467,y:711,t:1528139636028};\\\", \\\"{x:1467,y:706,t:1528139636044};\\\", \\\"{x:1468,y:700,t:1528139636061};\\\", \\\"{x:1468,y:696,t:1528139636079};\\\", \\\"{x:1469,y:693,t:1528139636095};\\\", \\\"{x:1469,y:692,t:1528139636120};\\\", \\\"{x:1470,y:691,t:1528139636273};\\\", \\\"{x:1471,y:689,t:1528139636279};\\\", \\\"{x:1472,y:688,t:1528139636296};\\\", \\\"{x:1475,y:684,t:1528139636311};\\\", \\\"{x:1476,y:679,t:1528139636329};\\\", \\\"{x:1480,y:672,t:1528139636346};\\\", \\\"{x:1481,y:666,t:1528139636362};\\\", \\\"{x:1483,y:661,t:1528139636379};\\\", \\\"{x:1484,y:656,t:1528139636395};\\\", \\\"{x:1484,y:653,t:1528139636411};\\\", \\\"{x:1485,y:649,t:1528139636428};\\\", \\\"{x:1487,y:646,t:1528139636446};\\\", \\\"{x:1487,y:644,t:1528139636462};\\\", \\\"{x:1488,y:640,t:1528139636478};\\\", \\\"{x:1490,y:635,t:1528139636495};\\\", \\\"{x:1490,y:634,t:1528139636512};\\\", \\\"{x:1490,y:633,t:1528139636528};\\\", \\\"{x:1491,y:630,t:1528139636546};\\\", \\\"{x:1491,y:628,t:1528139636562};\\\", \\\"{x:1491,y:625,t:1528139636579};\\\", \\\"{x:1492,y:621,t:1528139636596};\\\", \\\"{x:1494,y:615,t:1528139636612};\\\", \\\"{x:1494,y:612,t:1528139636628};\\\", \\\"{x:1494,y:606,t:1528139636645};\\\", \\\"{x:1494,y:601,t:1528139636662};\\\", \\\"{x:1494,y:597,t:1528139636678};\\\", \\\"{x:1494,y:590,t:1528139636696};\\\", \\\"{x:1494,y:586,t:1528139636712};\\\", \\\"{x:1495,y:583,t:1528139636728};\\\", \\\"{x:1495,y:579,t:1528139636745};\\\", \\\"{x:1495,y:577,t:1528139636762};\\\", \\\"{x:1495,y:574,t:1528139636779};\\\", \\\"{x:1495,y:571,t:1528139636796};\\\", \\\"{x:1495,y:569,t:1528139636812};\\\", \\\"{x:1495,y:567,t:1528139636829};\\\", \\\"{x:1495,y:564,t:1528139636846};\\\", \\\"{x:1495,y:563,t:1528139636862};\\\", \\\"{x:1495,y:561,t:1528139636882};\\\", \\\"{x:1495,y:559,t:1528139636895};\\\", \\\"{x:1495,y:558,t:1528139636911};\\\", \\\"{x:1495,y:557,t:1528139636928};\\\", \\\"{x:1495,y:555,t:1528139636945};\\\", \\\"{x:1494,y:555,t:1528139636961};\\\", \\\"{x:1494,y:554,t:1528139637056};\\\", \\\"{x:1491,y:555,t:1528139637072};\\\", \\\"{x:1489,y:564,t:1528139637079};\\\", \\\"{x:1481,y:587,t:1528139637095};\\\", \\\"{x:1472,y:620,t:1528139637111};\\\", \\\"{x:1458,y:660,t:1528139637128};\\\", \\\"{x:1454,y:687,t:1528139637145};\\\", \\\"{x:1452,y:709,t:1528139637161};\\\", \\\"{x:1451,y:727,t:1528139637178};\\\", \\\"{x:1451,y:748,t:1528139637195};\\\", \\\"{x:1451,y:763,t:1528139637211};\\\", \\\"{x:1454,y:773,t:1528139637229};\\\", \\\"{x:1458,y:779,t:1528139637245};\\\", \\\"{x:1459,y:784,t:1528139637261};\\\", \\\"{x:1460,y:786,t:1528139637279};\\\", \\\"{x:1461,y:788,t:1528139637295};\\\", \\\"{x:1462,y:788,t:1528139637327};\\\", \\\"{x:1464,y:788,t:1528139637359};\\\", \\\"{x:1465,y:788,t:1528139637367};\\\", \\\"{x:1467,y:789,t:1528139637425};\\\", \\\"{x:1469,y:790,t:1528139637431};\\\", \\\"{x:1470,y:792,t:1528139637445};\\\", \\\"{x:1473,y:799,t:1528139637462};\\\", \\\"{x:1474,y:804,t:1528139637478};\\\", \\\"{x:1479,y:813,t:1528139637496};\\\", \\\"{x:1483,y:818,t:1528139637511};\\\", \\\"{x:1487,y:821,t:1528139637529};\\\", \\\"{x:1489,y:822,t:1528139637545};\\\", \\\"{x:1490,y:823,t:1528139637563};\\\", \\\"{x:1490,y:822,t:1528139637672};\\\", \\\"{x:1490,y:819,t:1528139637680};\\\", \\\"{x:1490,y:813,t:1528139637695};\\\", \\\"{x:1487,y:803,t:1528139637712};\\\", \\\"{x:1485,y:792,t:1528139637729};\\\", \\\"{x:1481,y:779,t:1528139637745};\\\", \\\"{x:1480,y:764,t:1528139637762};\\\", \\\"{x:1477,y:751,t:1528139637778};\\\", \\\"{x:1477,y:739,t:1528139637796};\\\", \\\"{x:1477,y:729,t:1528139637812};\\\", \\\"{x:1477,y:722,t:1528139637829};\\\", \\\"{x:1477,y:716,t:1528139637846};\\\", \\\"{x:1477,y:711,t:1528139637863};\\\", \\\"{x:1477,y:709,t:1528139637879};\\\", \\\"{x:1475,y:705,t:1528139637896};\\\", \\\"{x:1474,y:704,t:1528139637912};\\\", \\\"{x:1473,y:701,t:1528139637928};\\\", \\\"{x:1473,y:699,t:1528139637946};\\\", \\\"{x:1471,y:695,t:1528139637962};\\\", \\\"{x:1471,y:693,t:1528139637979};\\\", \\\"{x:1471,y:691,t:1528139637995};\\\", \\\"{x:1471,y:688,t:1528139638012};\\\", \\\"{x:1470,y:686,t:1528139638028};\\\", \\\"{x:1470,y:684,t:1528139638046};\\\", \\\"{x:1470,y:682,t:1528139638062};\\\", \\\"{x:1470,y:681,t:1528139638079};\\\", \\\"{x:1470,y:676,t:1528139638095};\\\", \\\"{x:1470,y:672,t:1528139638112};\\\", \\\"{x:1470,y:667,t:1528139638128};\\\", \\\"{x:1470,y:661,t:1528139638145};\\\", \\\"{x:1470,y:658,t:1528139638163};\\\", \\\"{x:1470,y:656,t:1528139638178};\\\", \\\"{x:1470,y:652,t:1528139638195};\\\", \\\"{x:1471,y:648,t:1528139638212};\\\", \\\"{x:1472,y:645,t:1528139638229};\\\", \\\"{x:1473,y:643,t:1528139638246};\\\", \\\"{x:1474,y:639,t:1528139638262};\\\", \\\"{x:1475,y:633,t:1528139638280};\\\", \\\"{x:1476,y:631,t:1528139638295};\\\", \\\"{x:1478,y:628,t:1528139638312};\\\", \\\"{x:1480,y:625,t:1528139638329};\\\", \\\"{x:1482,y:619,t:1528139638346};\\\", \\\"{x:1485,y:612,t:1528139638362};\\\", \\\"{x:1486,y:606,t:1528139638380};\\\", \\\"{x:1487,y:601,t:1528139638395};\\\", \\\"{x:1488,y:593,t:1528139638413};\\\", \\\"{x:1488,y:584,t:1528139638430};\\\", \\\"{x:1488,y:577,t:1528139638446};\\\", \\\"{x:1490,y:569,t:1528139638464};\\\", \\\"{x:1490,y:560,t:1528139638480};\\\", \\\"{x:1490,y:553,t:1528139638495};\\\", \\\"{x:1489,y:548,t:1528139638512};\\\", \\\"{x:1488,y:542,t:1528139638530};\\\", \\\"{x:1486,y:536,t:1528139638546};\\\", \\\"{x:1485,y:531,t:1528139638563};\\\", \\\"{x:1484,y:525,t:1528139638579};\\\", \\\"{x:1483,y:517,t:1528139638596};\\\", \\\"{x:1481,y:508,t:1528139638612};\\\", \\\"{x:1480,y:501,t:1528139638630};\\\", \\\"{x:1478,y:492,t:1528139638645};\\\", \\\"{x:1478,y:484,t:1528139638663};\\\", \\\"{x:1478,y:474,t:1528139638680};\\\", \\\"{x:1477,y:468,t:1528139638695};\\\", \\\"{x:1476,y:461,t:1528139638713};\\\", \\\"{x:1474,y:454,t:1528139638729};\\\", \\\"{x:1473,y:450,t:1528139638746};\\\", \\\"{x:1472,y:445,t:1528139638762};\\\", \\\"{x:1472,y:441,t:1528139638780};\\\", \\\"{x:1470,y:437,t:1528139638796};\\\", \\\"{x:1470,y:433,t:1528139638813};\\\", \\\"{x:1470,y:429,t:1528139638830};\\\", \\\"{x:1469,y:426,t:1528139638846};\\\", \\\"{x:1469,y:423,t:1528139638863};\\\", \\\"{x:1469,y:420,t:1528139638880};\\\", \\\"{x:1469,y:416,t:1528139638895};\\\", \\\"{x:1469,y:414,t:1528139638913};\\\", \\\"{x:1469,y:412,t:1528139638930};\\\", \\\"{x:1469,y:409,t:1528139638946};\\\", \\\"{x:1469,y:407,t:1528139638963};\\\", \\\"{x:1469,y:404,t:1528139638979};\\\", \\\"{x:1470,y:403,t:1528139638995};\\\", \\\"{x:1470,y:400,t:1528139639013};\\\", \\\"{x:1471,y:398,t:1528139639029};\\\", \\\"{x:1473,y:396,t:1528139639046};\\\", \\\"{x:1474,y:395,t:1528139639063};\\\", \\\"{x:1474,y:394,t:1528139639079};\\\", \\\"{x:1474,y:393,t:1528139639095};\\\", \\\"{x:1475,y:391,t:1528139639127};\\\", \\\"{x:1475,y:390,t:1528139639135};\\\", \\\"{x:1476,y:390,t:1528139639146};\\\", \\\"{x:1476,y:388,t:1528139639162};\\\", \\\"{x:1477,y:387,t:1528139639179};\\\", \\\"{x:1477,y:383,t:1528139639197};\\\", \\\"{x:1479,y:379,t:1528139639213};\\\", \\\"{x:1479,y:373,t:1528139639230};\\\", \\\"{x:1480,y:368,t:1528139639247};\\\", \\\"{x:1480,y:362,t:1528139639263};\\\", \\\"{x:1480,y:354,t:1528139639280};\\\", \\\"{x:1480,y:351,t:1528139639296};\\\", \\\"{x:1480,y:345,t:1528139639312};\\\", \\\"{x:1481,y:339,t:1528139639329};\\\", \\\"{x:1481,y:334,t:1528139639347};\\\", \\\"{x:1481,y:328,t:1528139639363};\\\", \\\"{x:1481,y:321,t:1528139639380};\\\", \\\"{x:1481,y:317,t:1528139639396};\\\", \\\"{x:1481,y:312,t:1528139639412};\\\", \\\"{x:1481,y:308,t:1528139639430};\\\", \\\"{x:1481,y:304,t:1528139639447};\\\", \\\"{x:1483,y:298,t:1528139639462};\\\", \\\"{x:1483,y:292,t:1528139639479};\\\", \\\"{x:1484,y:286,t:1528139639496};\\\", \\\"{x:1485,y:281,t:1528139639513};\\\", \\\"{x:1487,y:276,t:1528139639530};\\\", \\\"{x:1487,y:272,t:1528139639546};\\\", \\\"{x:1487,y:267,t:1528139639563};\\\", \\\"{x:1487,y:263,t:1528139639579};\\\", \\\"{x:1487,y:256,t:1528139639596};\\\", \\\"{x:1487,y:253,t:1528139639613};\\\", \\\"{x:1487,y:249,t:1528139639629};\\\", \\\"{x:1487,y:245,t:1528139639646};\\\", \\\"{x:1486,y:242,t:1528139639662};\\\", \\\"{x:1486,y:239,t:1528139639680};\\\", \\\"{x:1484,y:236,t:1528139639696};\\\", \\\"{x:1483,y:234,t:1528139639713};\\\", \\\"{x:1483,y:231,t:1528139639730};\\\", \\\"{x:1480,y:227,t:1528139639747};\\\", \\\"{x:1478,y:224,t:1528139639763};\\\", \\\"{x:1474,y:216,t:1528139639780};\\\", \\\"{x:1472,y:211,t:1528139639797};\\\", \\\"{x:1470,y:204,t:1528139639813};\\\", \\\"{x:1468,y:197,t:1528139639830};\\\", \\\"{x:1468,y:193,t:1528139639847};\\\", \\\"{x:1468,y:186,t:1528139639863};\\\", \\\"{x:1469,y:175,t:1528139639879};\\\", \\\"{x:1471,y:166,t:1528139639896};\\\", \\\"{x:1473,y:163,t:1528139639913};\\\", \\\"{x:1473,y:160,t:1528139639930};\\\", \\\"{x:1474,y:157,t:1528139639947};\\\", \\\"{x:1476,y:154,t:1528139639962};\\\", \\\"{x:1477,y:154,t:1528139639979};\\\", \\\"{x:1477,y:153,t:1528139639996};\\\", \\\"{x:1477,y:152,t:1528139640056};\\\", \\\"{x:1476,y:152,t:1528139640063};\\\", \\\"{x:1431,y:177,t:1528139640080};\\\", \\\"{x:1326,y:251,t:1528139640097};\\\", \\\"{x:1168,y:361,t:1528139640113};\\\", \\\"{x:996,y:482,t:1528139640130};\\\", \\\"{x:838,y:599,t:1528139640148};\\\", \\\"{x:730,y:670,t:1528139640163};\\\", \\\"{x:684,y:697,t:1528139640178};\\\", \\\"{x:674,y:700,t:1528139640196};\\\", \\\"{x:674,y:697,t:1528139640214};\\\", \\\"{x:674,y:686,t:1528139640230};\\\", \\\"{x:674,y:663,t:1528139640246};\\\", \\\"{x:673,y:623,t:1528139640265};\\\", \\\"{x:672,y:596,t:1528139640283};\\\", \\\"{x:668,y:573,t:1528139640299};\\\", \\\"{x:664,y:564,t:1528139640316};\\\", \\\"{x:662,y:564,t:1528139640374};\\\", \\\"{x:658,y:569,t:1528139640383};\\\", \\\"{x:636,y:582,t:1528139640400};\\\", \\\"{x:591,y:620,t:1528139640417};\\\", \\\"{x:535,y:657,t:1528139640433};\\\", \\\"{x:485,y:690,t:1528139640449};\\\", \\\"{x:454,y:711,t:1528139640466};\\\", \\\"{x:431,y:722,t:1528139640481};\\\", \\\"{x:410,y:726,t:1528139640499};\\\", \\\"{x:391,y:730,t:1528139640517};\\\", \\\"{x:376,y:729,t:1528139640533};\\\", \\\"{x:364,y:728,t:1528139640549};\\\", \\\"{x:361,y:726,t:1528139640567};\\\", \\\"{x:360,y:724,t:1528139640582};\\\", \\\"{x:359,y:716,t:1528139640599};\\\", \\\"{x:358,y:712,t:1528139640617};\\\", \\\"{x:355,y:706,t:1528139640633};\\\", \\\"{x:354,y:701,t:1528139640649};\\\", \\\"{x:354,y:697,t:1528139640667};\\\", \\\"{x:354,y:695,t:1528139640682};\\\", \\\"{x:355,y:692,t:1528139640699};\\\", \\\"{x:359,y:684,t:1528139640718};\\\", \\\"{x:366,y:676,t:1528139640732};\\\", \\\"{x:370,y:671,t:1528139640749};\\\", \\\"{x:375,y:665,t:1528139640766};\\\", \\\"{x:378,y:660,t:1528139640782};\\\", \\\"{x:380,y:659,t:1528139640799};\\\", \\\"{x:385,y:657,t:1528139640816};\\\", \\\"{x:389,y:654,t:1528139640834};\\\", \\\"{x:390,y:652,t:1528139640850};\\\", \\\"{x:391,y:652,t:1528139640866};\\\", \\\"{x:390,y:649,t:1528139640894};\\\", \\\"{x:386,y:648,t:1528139640904};\\\", \\\"{x:380,y:645,t:1528139640916};\\\", \\\"{x:353,y:642,t:1528139640933};\\\", \\\"{x:303,y:641,t:1528139640949};\\\", \\\"{x:231,y:641,t:1528139640967};\\\", \\\"{x:116,y:645,t:1528139640983};\\\", \\\"{x:70,y:650,t:1528139640999};\\\", \\\"{x:63,y:650,t:1528139641016};\\\", \\\"{x:66,y:650,t:1528139641128};\\\", \\\"{x:68,y:650,t:1528139641135};\\\", \\\"{x:76,y:648,t:1528139641152};\\\", \\\"{x:80,y:648,t:1528139641166};\\\", \\\"{x:98,y:648,t:1528139641182};\\\", \\\"{x:112,y:648,t:1528139641200};\\\", \\\"{x:119,y:648,t:1528139641216};\\\", \\\"{x:128,y:648,t:1528139641233};\\\", \\\"{x:141,y:647,t:1528139641250};\\\", \\\"{x:156,y:643,t:1528139641267};\\\", \\\"{x:170,y:641,t:1528139641283};\\\", \\\"{x:174,y:641,t:1528139641300};\\\", \\\"{x:175,y:640,t:1528139641316};\\\", \\\"{x:175,y:639,t:1528139641407};\\\", \\\"{x:175,y:638,t:1528139641432};\\\", \\\"{x:175,y:637,t:1528139641439};\\\", \\\"{x:174,y:635,t:1528139641450};\\\", \\\"{x:169,y:633,t:1528139641467};\\\", \\\"{x:170,y:633,t:1528139641734};\\\", \\\"{x:177,y:633,t:1528139641750};\\\", \\\"{x:236,y:651,t:1528139641767};\\\", \\\"{x:302,y:666,t:1528139641785};\\\", \\\"{x:367,y:678,t:1528139641800};\\\", \\\"{x:408,y:688,t:1528139641818};\\\", \\\"{x:445,y:694,t:1528139641833};\\\", \\\"{x:459,y:696,t:1528139641850};\\\", \\\"{x:468,y:698,t:1528139641867};\\\", \\\"{x:470,y:698,t:1528139641943};\\\", \\\"{x:470,y:700,t:1528139642112};\\\", \\\"{x:470,y:704,t:1528139642119};\\\", \\\"{x:470,y:708,t:1528139642135};\\\", \\\"{x:470,y:724,t:1528139642151};\\\", \\\"{x:470,y:731,t:1528139642167};\\\", \\\"{x:470,y:739,t:1528139642186};\\\", \\\"{x:470,y:744,t:1528139642201};\\\", \\\"{x:470,y:749,t:1528139642217};\\\", \\\"{x:470,y:751,t:1528139642234};\\\", \\\"{x:471,y:752,t:1528139642251};\\\", \\\"{x:470,y:752,t:1528139642720};\\\", \\\"{x:466,y:752,t:1528139642734};\\\", \\\"{x:463,y:753,t:1528139642752};\\\", \\\"{x:462,y:754,t:1528139642768};\\\", \\\"{x:460,y:755,t:1528139642784};\\\", \\\"{x:458,y:757,t:1528139642802};\\\", \\\"{x:454,y:762,t:1528139642818};\\\", \\\"{x:451,y:766,t:1528139642834};\\\", \\\"{x:449,y:769,t:1528139642851};\\\", \\\"{x:448,y:769,t:1528139642912};\\\", \\\"{x:447,y:769,t:1528139642952};\\\", \\\"{x:440,y:768,t:1528139642968};\\\", \\\"{x:427,y:763,t:1528139642985};\\\", \\\"{x:403,y:762,t:1528139643002};\\\", \\\"{x:363,y:760,t:1528139643019};\\\", \\\"{x:331,y:764,t:1528139643034};\\\", \\\"{x:281,y:764,t:1528139643052};\\\", \\\"{x:248,y:764,t:1528139643068};\\\", \\\"{x:231,y:764,t:1528139643084};\\\", \\\"{x:227,y:764,t:1528139643101};\\\", \\\"{x:226,y:765,t:1528139643119};\\\" ] }, { \\\"rt\\\": 26913, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 9, \\\"time_elapsed\\\": 463184, \\\"internal_node_id\\\": \\\"0.0-5.0-4.0\\\", \\\"subject\\\": \\\"S6D2F\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 5, \\\"clicks\\\": 1, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"O\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F -I -I -O -O -O -I -I -O \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:236,y:765,t:1528139650991};\\\", \\\"{x:329,y:761,t:1528139651007};\\\", \\\"{x:471,y:759,t:1528139651027};\\\", \\\"{x:640,y:757,t:1528139651042};\\\", \\\"{x:812,y:756,t:1528139651058};\\\", \\\"{x:981,y:756,t:1528139651075};\\\", \\\"{x:1131,y:762,t:1528139651091};\\\", \\\"{x:1234,y:764,t:1528139651108};\\\", \\\"{x:1281,y:764,t:1528139651124};\\\", \\\"{x:1296,y:764,t:1528139651141};\\\", \\\"{x:1298,y:764,t:1528139651158};\\\", \\\"{x:1299,y:764,t:1528139651199};\\\", \\\"{x:1302,y:764,t:1528139651209};\\\", \\\"{x:1310,y:764,t:1528139651224};\\\", \\\"{x:1324,y:761,t:1528139651241};\\\", \\\"{x:1344,y:756,t:1528139651259};\\\", \\\"{x:1359,y:752,t:1528139651275};\\\", \\\"{x:1379,y:751,t:1528139651292};\\\", \\\"{x:1396,y:751,t:1528139651309};\\\", \\\"{x:1411,y:751,t:1528139651325};\\\", \\\"{x:1428,y:752,t:1528139651342};\\\", \\\"{x:1451,y:759,t:1528139651358};\\\", \\\"{x:1461,y:761,t:1528139651375};\\\", \\\"{x:1467,y:765,t:1528139651392};\\\", \\\"{x:1469,y:767,t:1528139651409};\\\", \\\"{x:1470,y:769,t:1528139651425};\\\", \\\"{x:1470,y:773,t:1528139651442};\\\", \\\"{x:1470,y:775,t:1528139651459};\\\", \\\"{x:1470,y:778,t:1528139651475};\\\", \\\"{x:1470,y:780,t:1528139651491};\\\", \\\"{x:1469,y:782,t:1528139651509};\\\", \\\"{x:1468,y:784,t:1528139651525};\\\", \\\"{x:1466,y:786,t:1528139651542};\\\", \\\"{x:1464,y:786,t:1528139651559};\\\", \\\"{x:1458,y:788,t:1528139651575};\\\", \\\"{x:1452,y:790,t:1528139651591};\\\", \\\"{x:1440,y:790,t:1528139651609};\\\", \\\"{x:1424,y:790,t:1528139651625};\\\", \\\"{x:1405,y:790,t:1528139651643};\\\", \\\"{x:1387,y:789,t:1528139651659};\\\", \\\"{x:1366,y:784,t:1528139651675};\\\", \\\"{x:1349,y:777,t:1528139651693};\\\", \\\"{x:1337,y:771,t:1528139651709};\\\", \\\"{x:1323,y:762,t:1528139651726};\\\", \\\"{x:1317,y:740,t:1528139651743};\\\", \\\"{x:1317,y:717,t:1528139651759};\\\", \\\"{x:1326,y:692,t:1528139651776};\\\", \\\"{x:1338,y:660,t:1528139651793};\\\", \\\"{x:1347,y:627,t:1528139651809};\\\", \\\"{x:1355,y:586,t:1528139651826};\\\", \\\"{x:1368,y:544,t:1528139651843};\\\", \\\"{x:1376,y:499,t:1528139651859};\\\", \\\"{x:1377,y:473,t:1528139651876};\\\", \\\"{x:1377,y:451,t:1528139651893};\\\", \\\"{x:1369,y:436,t:1528139651910};\\\", \\\"{x:1359,y:429,t:1528139651926};\\\", \\\"{x:1344,y:426,t:1528139651944};\\\", \\\"{x:1335,y:426,t:1528139651960};\\\", \\\"{x:1326,y:426,t:1528139651976};\\\", \\\"{x:1320,y:426,t:1528139651993};\\\", \\\"{x:1314,y:428,t:1528139652010};\\\", \\\"{x:1309,y:431,t:1528139652026};\\\", \\\"{x:1306,y:434,t:1528139652043};\\\", \\\"{x:1303,y:438,t:1528139652060};\\\", \\\"{x:1303,y:443,t:1528139652076};\\\", \\\"{x:1303,y:454,t:1528139652093};\\\", \\\"{x:1312,y:466,t:1528139652110};\\\", \\\"{x:1324,y:474,t:1528139652126};\\\", \\\"{x:1342,y:487,t:1528139652143};\\\", \\\"{x:1351,y:492,t:1528139652159};\\\", \\\"{x:1355,y:494,t:1528139652176};\\\", \\\"{x:1357,y:497,t:1528139652193};\\\", \\\"{x:1357,y:499,t:1528139652210};\\\", \\\"{x:1357,y:500,t:1528139652247};\\\", \\\"{x:1357,y:501,t:1528139652368};\\\", \\\"{x:1357,y:502,t:1528139652383};\\\", \\\"{x:1357,y:503,t:1528139652393};\\\", \\\"{x:1348,y:503,t:1528139652410};\\\", \\\"{x:1340,y:503,t:1528139652427};\\\", \\\"{x:1333,y:503,t:1528139652443};\\\", \\\"{x:1325,y:502,t:1528139652460};\\\", \\\"{x:1321,y:502,t:1528139652477};\\\", \\\"{x:1316,y:502,t:1528139652499};\\\", \\\"{x:1313,y:502,t:1528139652509};\\\", \\\"{x:1308,y:502,t:1528139652543};\\\", \\\"{x:1307,y:502,t:1528139652559};\\\", \\\"{x:1305,y:502,t:1528139652575};\\\", \\\"{x:1306,y:502,t:1528139652847};\\\", \\\"{x:1307,y:501,t:1528139652863};\\\", \\\"{x:1308,y:501,t:1528139652877};\\\", \\\"{x:1310,y:500,t:1528139652897};\\\", \\\"{x:1310,y:499,t:1528139652909};\\\", \\\"{x:1311,y:499,t:1528139652926};\\\", \\\"{x:1312,y:498,t:1528139652943};\\\", \\\"{x:1313,y:498,t:1528139652959};\\\", \\\"{x:1316,y:498,t:1528139652976};\\\", \\\"{x:1318,y:497,t:1528139652994};\\\", \\\"{x:1319,y:497,t:1528139653023};\\\", \\\"{x:1319,y:501,t:1528139656650};\\\", \\\"{x:1317,y:515,t:1528139656663};\\\", \\\"{x:1314,y:526,t:1528139656680};\\\", \\\"{x:1311,y:539,t:1528139656695};\\\", \\\"{x:1311,y:546,t:1528139656711};\\\", \\\"{x:1311,y:556,t:1528139656729};\\\", \\\"{x:1310,y:563,t:1528139656745};\\\", \\\"{x:1310,y:567,t:1528139656762};\\\", \\\"{x:1310,y:571,t:1528139656778};\\\", \\\"{x:1310,y:575,t:1528139656796};\\\", \\\"{x:1310,y:577,t:1528139656812};\\\", \\\"{x:1310,y:580,t:1528139656828};\\\", \\\"{x:1310,y:585,t:1528139656845};\\\", \\\"{x:1310,y:592,t:1528139656862};\\\", \\\"{x:1311,y:597,t:1528139656879};\\\", \\\"{x:1311,y:599,t:1528139656896};\\\", \\\"{x:1311,y:603,t:1528139656913};\\\", \\\"{x:1312,y:606,t:1528139656929};\\\", \\\"{x:1312,y:609,t:1528139656946};\\\", \\\"{x:1312,y:612,t:1528139656963};\\\", \\\"{x:1312,y:613,t:1528139656979};\\\", \\\"{x:1312,y:615,t:1528139656996};\\\", \\\"{x:1312,y:616,t:1528139657013};\\\", \\\"{x:1312,y:618,t:1528139657029};\\\", \\\"{x:1312,y:620,t:1528139657046};\\\", \\\"{x:1312,y:621,t:1528139657063};\\\", \\\"{x:1312,y:623,t:1528139657079};\\\", \\\"{x:1312,y:624,t:1528139657096};\\\", \\\"{x:1312,y:625,t:1528139657116};\\\", \\\"{x:1312,y:627,t:1528139657128};\\\", \\\"{x:1312,y:628,t:1528139657263};\\\", \\\"{x:1312,y:627,t:1528139660247};\\\", \\\"{x:1312,y:625,t:1528139660255};\\\", \\\"{x:1312,y:624,t:1528139660269};\\\", \\\"{x:1312,y:620,t:1528139660283};\\\", \\\"{x:1311,y:619,t:1528139661495};\\\", \\\"{x:1309,y:619,t:1528139661519};\\\", \\\"{x:1307,y:620,t:1528139661534};\\\", \\\"{x:1306,y:621,t:1528139661550};\\\", \\\"{x:1304,y:624,t:1528139661567};\\\", \\\"{x:1302,y:627,t:1528139661584};\\\", \\\"{x:1300,y:630,t:1528139661601};\\\", \\\"{x:1299,y:633,t:1528139661618};\\\", \\\"{x:1298,y:635,t:1528139661634};\\\", \\\"{x:1297,y:637,t:1528139661650};\\\", \\\"{x:1296,y:638,t:1528139661668};\\\", \\\"{x:1296,y:641,t:1528139661685};\\\", \\\"{x:1295,y:642,t:1528139661701};\\\", \\\"{x:1295,y:643,t:1528139661943};\\\", \\\"{x:1295,y:644,t:1528139661951};\\\", \\\"{x:1294,y:646,t:1528139661968};\\\", \\\"{x:1292,y:650,t:1528139661984};\\\", \\\"{x:1290,y:651,t:1528139662001};\\\", \\\"{x:1288,y:653,t:1528139662018};\\\", \\\"{x:1286,y:655,t:1528139662034};\\\", \\\"{x:1285,y:655,t:1528139662071};\\\", \\\"{x:1284,y:655,t:1528139662167};\\\", \\\"{x:1284,y:654,t:1528139662191};\\\", \\\"{x:1284,y:652,t:1528139662201};\\\", \\\"{x:1284,y:647,t:1528139662218};\\\", \\\"{x:1284,y:640,t:1528139662234};\\\", \\\"{x:1285,y:626,t:1528139662251};\\\", \\\"{x:1290,y:608,t:1528139662268};\\\", \\\"{x:1292,y:592,t:1528139662285};\\\", \\\"{x:1295,y:574,t:1528139662301};\\\", \\\"{x:1297,y:560,t:1528139662318};\\\", \\\"{x:1301,y:547,t:1528139662334};\\\", \\\"{x:1302,y:534,t:1528139662351};\\\", \\\"{x:1305,y:527,t:1528139662368};\\\", \\\"{x:1305,y:522,t:1528139662384};\\\", \\\"{x:1306,y:518,t:1528139662401};\\\", \\\"{x:1306,y:515,t:1528139662418};\\\", \\\"{x:1306,y:511,t:1528139662434};\\\", \\\"{x:1306,y:509,t:1528139662451};\\\", \\\"{x:1306,y:507,t:1528139662469};\\\", \\\"{x:1306,y:506,t:1528139662484};\\\", \\\"{x:1306,y:505,t:1528139662543};\\\", \\\"{x:1306,y:504,t:1528139662551};\\\", \\\"{x:1306,y:501,t:1528139662568};\\\", \\\"{x:1307,y:496,t:1528139662585};\\\", \\\"{x:1309,y:490,t:1528139662602};\\\", \\\"{x:1310,y:483,t:1528139662618};\\\", \\\"{x:1313,y:478,t:1528139662635};\\\", \\\"{x:1314,y:471,t:1528139662651};\\\", \\\"{x:1315,y:467,t:1528139662668};\\\", \\\"{x:1316,y:463,t:1528139662684};\\\", \\\"{x:1316,y:461,t:1528139662701};\\\", \\\"{x:1316,y:463,t:1528139662847};\\\", \\\"{x:1316,y:464,t:1528139662855};\\\", \\\"{x:1316,y:467,t:1528139662868};\\\", \\\"{x:1315,y:474,t:1528139662886};\\\", \\\"{x:1313,y:480,t:1528139662901};\\\", \\\"{x:1312,y:486,t:1528139662919};\\\", \\\"{x:1308,y:493,t:1528139662936};\\\", \\\"{x:1307,y:498,t:1528139662952};\\\", \\\"{x:1305,y:502,t:1528139662969};\\\", \\\"{x:1304,y:506,t:1528139662985};\\\", \\\"{x:1303,y:509,t:1528139663001};\\\", \\\"{x:1303,y:511,t:1528139663024};\\\", \\\"{x:1302,y:511,t:1528139663036};\\\", \\\"{x:1302,y:512,t:1528139663119};\\\", \\\"{x:1304,y:512,t:1528139663408};\\\", \\\"{x:1306,y:511,t:1528139663418};\\\", \\\"{x:1309,y:510,t:1528139663435};\\\", \\\"{x:1311,y:508,t:1528139663452};\\\", \\\"{x:1314,y:507,t:1528139663468};\\\", \\\"{x:1316,y:505,t:1528139663486};\\\", \\\"{x:1318,y:504,t:1528139663502};\\\", \\\"{x:1319,y:504,t:1528139663519};\\\", \\\"{x:1321,y:503,t:1528139663535};\\\", \\\"{x:1321,y:502,t:1528139663783};\\\", \\\"{x:1322,y:501,t:1528139663799};\\\", \\\"{x:1323,y:501,t:1528139665015};\\\", \\\"{x:1323,y:502,t:1528139666391};\\\", \\\"{x:1323,y:503,t:1528139666404};\\\", \\\"{x:1322,y:504,t:1528139666421};\\\", \\\"{x:1322,y:508,t:1528139666438};\\\", \\\"{x:1320,y:511,t:1528139666454};\\\", \\\"{x:1319,y:516,t:1528139666471};\\\", \\\"{x:1318,y:520,t:1528139666488};\\\", \\\"{x:1317,y:524,t:1528139666505};\\\", \\\"{x:1317,y:527,t:1528139666521};\\\", \\\"{x:1317,y:531,t:1528139666538};\\\", \\\"{x:1317,y:534,t:1528139666555};\\\", \\\"{x:1317,y:538,t:1528139666571};\\\", \\\"{x:1317,y:541,t:1528139666587};\\\", \\\"{x:1316,y:546,t:1528139666604};\\\", \\\"{x:1316,y:551,t:1528139666621};\\\", \\\"{x:1316,y:555,t:1528139666637};\\\", \\\"{x:1316,y:558,t:1528139666655};\\\", \\\"{x:1316,y:564,t:1528139666671};\\\", \\\"{x:1316,y:566,t:1528139666687};\\\", \\\"{x:1316,y:570,t:1528139666704};\\\", \\\"{x:1316,y:572,t:1528139666721};\\\", \\\"{x:1316,y:576,t:1528139666737};\\\", \\\"{x:1317,y:579,t:1528139666754};\\\", \\\"{x:1318,y:582,t:1528139666772};\\\", \\\"{x:1318,y:585,t:1528139666789};\\\", \\\"{x:1319,y:588,t:1528139666805};\\\", \\\"{x:1319,y:589,t:1528139666821};\\\", \\\"{x:1319,y:592,t:1528139666838};\\\", \\\"{x:1319,y:594,t:1528139666854};\\\", \\\"{x:1320,y:596,t:1528139666871};\\\", \\\"{x:1320,y:598,t:1528139666889};\\\", \\\"{x:1321,y:599,t:1528139666911};\\\", \\\"{x:1321,y:600,t:1528139666927};\\\", \\\"{x:1321,y:601,t:1528139666943};\\\", \\\"{x:1321,y:602,t:1528139666967};\\\", \\\"{x:1322,y:602,t:1528139666975};\\\", \\\"{x:1322,y:603,t:1528139666989};\\\", \\\"{x:1322,y:604,t:1528139667004};\\\", \\\"{x:1322,y:605,t:1528139667023};\\\", \\\"{x:1322,y:606,t:1528139667038};\\\", \\\"{x:1322,y:607,t:1528139667055};\\\", \\\"{x:1322,y:610,t:1528139667072};\\\", \\\"{x:1322,y:612,t:1528139667089};\\\", \\\"{x:1321,y:614,t:1528139667104};\\\", \\\"{x:1321,y:617,t:1528139667121};\\\", \\\"{x:1319,y:620,t:1528139667138};\\\", \\\"{x:1319,y:622,t:1528139667155};\\\", \\\"{x:1319,y:623,t:1528139667171};\\\", \\\"{x:1318,y:625,t:1528139667192};\\\", \\\"{x:1318,y:626,t:1528139667221};\\\", \\\"{x:1318,y:628,t:1528139667238};\\\", \\\"{x:1318,y:629,t:1528139667262};\\\", \\\"{x:1318,y:630,t:1528139667286};\\\", \\\"{x:1317,y:632,t:1528139667302};\\\", \\\"{x:1317,y:633,t:1528139667367};\\\", \\\"{x:1315,y:633,t:1528139667496};\\\", \\\"{x:1314,y:633,t:1528139667759};\\\", \\\"{x:1312,y:634,t:1528139667783};\\\", \\\"{x:1308,y:636,t:1528139667822};\\\", \\\"{x:1292,y:642,t:1528139667838};\\\", \\\"{x:1255,y:653,t:1528139667854};\\\", \\\"{x:1193,y:665,t:1528139667872};\\\", \\\"{x:1080,y:681,t:1528139667889};\\\", \\\"{x:958,y:681,t:1528139667905};\\\", \\\"{x:847,y:681,t:1528139667922};\\\", \\\"{x:755,y:681,t:1528139667938};\\\", \\\"{x:705,y:681,t:1528139667956};\\\", \\\"{x:686,y:681,t:1528139667971};\\\", \\\"{x:680,y:682,t:1528139667989};\\\", \\\"{x:677,y:682,t:1528139668007};\\\", \\\"{x:676,y:683,t:1528139668055};\\\", \\\"{x:675,y:684,t:1528139668072};\\\", \\\"{x:674,y:685,t:1528139668089};\\\", \\\"{x:674,y:684,t:1528139668231};\\\", \\\"{x:672,y:680,t:1528139668239};\\\", \\\"{x:665,y:675,t:1528139668256};\\\", \\\"{x:643,y:665,t:1528139668273};\\\", \\\"{x:618,y:653,t:1528139668289};\\\", \\\"{x:580,y:642,t:1528139668306};\\\", \\\"{x:556,y:636,t:1528139668321};\\\", \\\"{x:541,y:635,t:1528139668339};\\\", \\\"{x:539,y:635,t:1528139668356};\\\", \\\"{x:538,y:635,t:1528139668371};\\\", \\\"{x:534,y:637,t:1528139668388};\\\", \\\"{x:525,y:646,t:1528139668406};\\\", \\\"{x:519,y:652,t:1528139668421};\\\", \\\"{x:492,y:672,t:1528139668440};\\\", \\\"{x:469,y:685,t:1528139668455};\\\", \\\"{x:442,y:698,t:1528139668472};\\\", \\\"{x:390,y:712,t:1528139668490};\\\", \\\"{x:371,y:720,t:1528139668506};\\\", \\\"{x:361,y:721,t:1528139668522};\\\", \\\"{x:356,y:721,t:1528139668538};\\\", \\\"{x:354,y:721,t:1528139668556};\\\", \\\"{x:354,y:720,t:1528139668582};\\\", \\\"{x:381,y:716,t:1528139668623};\\\", \\\"{x:507,y:710,t:1528139668639};\\\", \\\"{x:627,y:702,t:1528139668656};\\\", \\\"{x:739,y:684,t:1528139668673};\\\", \\\"{x:808,y:676,t:1528139668689};\\\", \\\"{x:842,y:669,t:1528139668706};\\\", \\\"{x:850,y:668,t:1528139668723};\\\", \\\"{x:851,y:667,t:1528139668759};\\\", \\\"{x:850,y:666,t:1528139668774};\\\", \\\"{x:848,y:665,t:1528139668789};\\\", \\\"{x:847,y:665,t:1528139668806};\\\", \\\"{x:846,y:664,t:1528139668839};\\\", \\\"{x:846,y:663,t:1528139668855};\\\", \\\"{x:845,y:659,t:1528139668873};\\\", \\\"{x:844,y:655,t:1528139668890};\\\", \\\"{x:844,y:648,t:1528139668906};\\\", \\\"{x:844,y:643,t:1528139668923};\\\", \\\"{x:845,y:632,t:1528139668939};\\\", \\\"{x:848,y:627,t:1528139668956};\\\", \\\"{x:849,y:619,t:1528139668973};\\\", \\\"{x:849,y:612,t:1528139668990};\\\", \\\"{x:851,y:608,t:1528139669006};\\\", \\\"{x:851,y:607,t:1528139669023};\\\", \\\"{x:852,y:604,t:1528139669039};\\\", \\\"{x:852,y:600,t:1528139669056};\\\", \\\"{x:852,y:599,t:1528139669073};\\\", \\\"{x:852,y:595,t:1528139669089};\\\", \\\"{x:852,y:593,t:1528139669106};\\\", \\\"{x:852,y:591,t:1528139669123};\\\", \\\"{x:852,y:588,t:1528139669139};\\\", \\\"{x:852,y:585,t:1528139669157};\\\", \\\"{x:851,y:582,t:1528139669173};\\\", \\\"{x:850,y:580,t:1528139669190};\\\", \\\"{x:848,y:578,t:1528139669238};\\\", \\\"{x:848,y:577,t:1528139669255};\\\", \\\"{x:847,y:576,t:1528139669262};\\\", \\\"{x:846,y:576,t:1528139669294};\\\", \\\"{x:843,y:578,t:1528139669646};\\\", \\\"{x:842,y:579,t:1528139669656};\\\", \\\"{x:837,y:585,t:1528139669673};\\\", \\\"{x:830,y:592,t:1528139669690};\\\", \\\"{x:818,y:602,t:1528139669707};\\\", \\\"{x:805,y:614,t:1528139669724};\\\", \\\"{x:792,y:626,t:1528139669740};\\\", \\\"{x:776,y:639,t:1528139669758};\\\", \\\"{x:752,y:655,t:1528139669774};\\\", \\\"{x:733,y:667,t:1528139669790};\\\", \\\"{x:713,y:679,t:1528139669807};\\\", \\\"{x:695,y:689,t:1528139669823};\\\", \\\"{x:680,y:698,t:1528139669840};\\\", \\\"{x:660,y:709,t:1528139669857};\\\", \\\"{x:638,y:719,t:1528139669874};\\\", \\\"{x:610,y:731,t:1528139669890};\\\", \\\"{x:590,y:741,t:1528139669907};\\\", \\\"{x:569,y:754,t:1528139669924};\\\", \\\"{x:553,y:762,t:1528139669942};\\\", \\\"{x:539,y:771,t:1528139669957};\\\", \\\"{x:529,y:779,t:1528139669973};\\\", \\\"{x:524,y:783,t:1528139669990};\\\", \\\"{x:523,y:785,t:1528139670006};\\\", \\\"{x:519,y:789,t:1528139670024};\\\", \\\"{x:519,y:790,t:1528139670039};\\\", \\\"{x:518,y:791,t:1528139670057};\\\", \\\"{x:518,y:792,t:1528139670086};\\\", \\\"{x:518,y:793,t:1528139670094};\\\", \\\"{x:516,y:794,t:1528139670110};\\\", \\\"{x:516,y:793,t:1528139670223};\\\", \\\"{x:517,y:791,t:1528139670231};\\\", \\\"{x:518,y:788,t:1528139670240};\\\", \\\"{x:521,y:783,t:1528139670258};\\\", \\\"{x:524,y:778,t:1528139670273};\\\", \\\"{x:525,y:776,t:1528139670290};\\\", \\\"{x:525,y:775,t:1528139670307};\\\", \\\"{x:525,y:774,t:1528139670324};\\\", \\\"{x:526,y:774,t:1528139670340};\\\", \\\"{x:526,y:773,t:1528139670358};\\\", \\\"{x:527,y:773,t:1528139670374};\\\" ] }, { \\\"rt\\\": 8573, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 10, \\\"time_elapsed\\\": 472965, \\\"internal_node_id\\\": \\\"0.0-6.0-0.0\\\", \\\"subject\\\": \\\"S6D2F\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration\\\", \\\"q\\\": 6, \\\"clicks\\\": 2.5, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\", \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:528,y:771,t:1528139671902};\\\", \\\"{x:531,y:769,t:1528139671910};\\\", \\\"{x:534,y:765,t:1528139671925};\\\", \\\"{x:532,y:755,t:1528139671941};\\\", \\\"{x:530,y:755,t:1528139671959};\\\", \\\"{x:530,y:754,t:1528139676233};\\\", \\\"{x:537,y:732,t:1528139676245};\\\", \\\"{x:564,y:657,t:1528139676262};\\\", \\\"{x:587,y:639,t:1528139676279};\\\", \\\"{x:605,y:629,t:1528139676295};\\\", \\\"{x:617,y:614,t:1528139676311};\\\", \\\"{x:618,y:594,t:1528139676329};\\\", \\\"{x:617,y:576,t:1528139676346};\\\", \\\"{x:616,y:562,t:1528139676362};\\\", \\\"{x:616,y:551,t:1528139676380};\\\", \\\"{x:617,y:543,t:1528139676395};\\\", \\\"{x:618,y:538,t:1528139676412};\\\", \\\"{x:621,y:534,t:1528139676429};\\\", \\\"{x:624,y:532,t:1528139676445};\\\", \\\"{x:627,y:528,t:1528139676461};\\\", \\\"{x:628,y:526,t:1528139676480};\\\", \\\"{x:628,y:525,t:1528139676606};\\\", \\\"{x:627,y:523,t:1528139676622};\\\", \\\"{x:625,y:522,t:1528139676630};\\\", \\\"{x:621,y:519,t:1528139676646};\\\", \\\"{x:618,y:517,t:1528139676663};\\\", \\\"{x:616,y:515,t:1528139676679};\\\", \\\"{x:613,y:514,t:1528139676696};\\\", \\\"{x:612,y:513,t:1528139677088};\\\", \\\"{x:612,y:512,t:1528139677096};\\\", \\\"{x:625,y:511,t:1528139677113};\\\", \\\"{x:638,y:511,t:1528139677130};\\\", \\\"{x:639,y:511,t:1528139677146};\\\", \\\"{x:641,y:513,t:1528139677163};\\\", \\\"{x:637,y:513,t:1528139677423};\\\", \\\"{x:634,y:513,t:1528139677430};\\\", \\\"{x:633,y:513,t:1528139677447};\\\", \\\"{x:631,y:513,t:1528139677479};\\\", \\\"{x:630,y:513,t:1528139677599};\\\", \\\"{x:627,y:513,t:1528139677614};\\\", \\\"{x:623,y:513,t:1528139677631};\\\", \\\"{x:619,y:513,t:1528139677647};\\\", \\\"{x:616,y:513,t:1528139677663};\\\", \\\"{x:609,y:513,t:1528139677680};\\\", \\\"{x:605,y:513,t:1528139677697};\\\", \\\"{x:601,y:513,t:1528139677713};\\\", \\\"{x:599,y:514,t:1528139677731};\\\", \\\"{x:600,y:514,t:1528139677918};\\\", \\\"{x:601,y:514,t:1528139677930};\\\", \\\"{x:602,y:513,t:1528139677947};\\\", \\\"{x:603,y:512,t:1528139677963};\\\", \\\"{x:605,y:512,t:1528139678871};\\\", \\\"{x:615,y:512,t:1528139678881};\\\", \\\"{x:637,y:513,t:1528139678899};\\\", \\\"{x:666,y:516,t:1528139678914};\\\", \\\"{x:686,y:516,t:1528139678931};\\\", \\\"{x:713,y:519,t:1528139678948};\\\", \\\"{x:739,y:522,t:1528139678964};\\\", \\\"{x:764,y:526,t:1528139678983};\\\", \\\"{x:785,y:527,t:1528139678997};\\\", \\\"{x:807,y:531,t:1528139679014};\\\", \\\"{x:817,y:531,t:1528139679031};\\\", \\\"{x:824,y:533,t:1528139679049};\\\", \\\"{x:827,y:533,t:1528139679065};\\\", \\\"{x:831,y:534,t:1528139679081};\\\", \\\"{x:835,y:534,t:1528139679099};\\\", \\\"{x:841,y:536,t:1528139679115};\\\", \\\"{x:854,y:540,t:1528139679132};\\\", \\\"{x:863,y:543,t:1528139679149};\\\", \\\"{x:869,y:544,t:1528139679164};\\\", \\\"{x:863,y:543,t:1528139679271};\\\", \\\"{x:859,y:541,t:1528139679281};\\\", \\\"{x:852,y:539,t:1528139679298};\\\", \\\"{x:850,y:539,t:1528139679315};\\\", \\\"{x:848,y:539,t:1528139679366};\\\", \\\"{x:847,y:539,t:1528139679381};\\\", \\\"{x:841,y:536,t:1528139679399};\\\", \\\"{x:838,y:536,t:1528139679677};\\\", \\\"{x:829,y:540,t:1528139679685};\\\", \\\"{x:822,y:546,t:1528139679698};\\\", \\\"{x:796,y:573,t:1528139679716};\\\", \\\"{x:716,y:641,t:1528139679733};\\\", \\\"{x:615,y:723,t:1528139679749};\\\", \\\"{x:522,y:800,t:1528139679765};\\\", \\\"{x:456,y:858,t:1528139679781};\\\", \\\"{x:405,y:911,t:1528139679798};\\\", \\\"{x:401,y:924,t:1528139679815};\\\", \\\"{x:400,y:928,t:1528139679832};\\\", \\\"{x:399,y:928,t:1528139679935};\\\", \\\"{x:399,y:927,t:1528139679948};\\\", \\\"{x:399,y:920,t:1528139679966};\\\", \\\"{x:404,y:905,t:1528139679983};\\\", \\\"{x:411,y:890,t:1528139679999};\\\", \\\"{x:416,y:874,t:1528139680016};\\\", \\\"{x:423,y:854,t:1528139680033};\\\", \\\"{x:431,y:834,t:1528139680048};\\\", \\\"{x:442,y:819,t:1528139680066};\\\", \\\"{x:453,y:801,t:1528139680083};\\\", \\\"{x:468,y:778,t:1528139680099};\\\", \\\"{x:479,y:763,t:1528139680116};\\\", \\\"{x:489,y:751,t:1528139680133};\\\", \\\"{x:506,y:739,t:1528139680150};\\\", \\\"{x:514,y:731,t:1528139680165};\\\", \\\"{x:519,y:728,t:1528139680182};\\\" ] }, { \\\"rt\\\": 18413, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 11, \\\"time_elapsed\\\": 492685, \\\"internal_node_id\\\": \\\"0.0-6.0-1.0\\\", \\\"subject\\\": \\\"S6D2F\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+starts\\\", \\\"q\\\": 7, \\\"clicks\\\": 2.5, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:519,y:727,t:1528139695488};\\\", \\\"{x:541,y:685,t:1528139695505};\\\", \\\"{x:578,y:614,t:1528139695521};\\\", \\\"{x:612,y:562,t:1528139695538};\\\", \\\"{x:639,y:520,t:1528139695553};\\\", \\\"{x:672,y:491,t:1528139695571};\\\", \\\"{x:682,y:481,t:1528139695587};\\\", \\\"{x:684,y:479,t:1528139695605};\\\", \\\"{x:684,y:478,t:1528139695621};\\\", \\\"{x:685,y:478,t:1528139695671};\\\", \\\"{x:693,y:477,t:1528139695687};\\\", \\\"{x:702,y:475,t:1528139695704};\\\", \\\"{x:709,y:473,t:1528139695721};\\\", \\\"{x:712,y:473,t:1528139695737};\\\", \\\"{x:710,y:473,t:1528139695832};\\\", \\\"{x:705,y:476,t:1528139695840};\\\", \\\"{x:700,y:481,t:1528139695855};\\\", \\\"{x:682,y:500,t:1528139695872};\\\", \\\"{x:665,y:516,t:1528139695888};\\\", \\\"{x:653,y:526,t:1528139695906};\\\", \\\"{x:639,y:538,t:1528139695922};\\\", \\\"{x:627,y:546,t:1528139695938};\\\", \\\"{x:610,y:561,t:1528139695954};\\\", \\\"{x:588,y:579,t:1528139695972};\\\", \\\"{x:567,y:597,t:1528139695988};\\\", \\\"{x:547,y:612,t:1528139696006};\\\", \\\"{x:527,y:623,t:1528139696021};\\\", \\\"{x:511,y:629,t:1528139696038};\\\", \\\"{x:502,y:633,t:1528139696055};\\\", \\\"{x:477,y:636,t:1528139696071};\\\", \\\"{x:468,y:639,t:1528139696089};\\\", \\\"{x:458,y:640,t:1528139696105};\\\", \\\"{x:455,y:640,t:1528139696121};\\\", \\\"{x:451,y:640,t:1528139696138};\\\", \\\"{x:448,y:640,t:1528139696154};\\\", \\\"{x:443,y:640,t:1528139696171};\\\", \\\"{x:437,y:638,t:1528139696189};\\\", \\\"{x:433,y:638,t:1528139696205};\\\", \\\"{x:432,y:638,t:1528139696221};\\\", \\\"{x:432,y:637,t:1528139696279};\\\", \\\"{x:434,y:633,t:1528139696288};\\\", \\\"{x:455,y:622,t:1528139696306};\\\", \\\"{x:482,y:608,t:1528139696322};\\\", \\\"{x:515,y:591,t:1528139696338};\\\", \\\"{x:558,y:570,t:1528139696355};\\\", \\\"{x:610,y:540,t:1528139696372};\\\", \\\"{x:646,y:526,t:1528139696389};\\\", \\\"{x:654,y:522,t:1528139696406};\\\", \\\"{x:655,y:522,t:1528139696423};\\\", \\\"{x:657,y:522,t:1528139696455};\\\", \\\"{x:664,y:519,t:1528139696472};\\\", \\\"{x:679,y:513,t:1528139696489};\\\", \\\"{x:688,y:509,t:1528139696505};\\\", \\\"{x:696,y:506,t:1528139696523};\\\", \\\"{x:703,y:504,t:1528139696538};\\\", \\\"{x:707,y:502,t:1528139696556};\\\", \\\"{x:712,y:500,t:1528139696573};\\\", \\\"{x:719,y:499,t:1528139696588};\\\", \\\"{x:729,y:498,t:1528139696607};\\\", \\\"{x:736,y:498,t:1528139696622};\\\", \\\"{x:742,y:498,t:1528139696638};\\\", \\\"{x:744,y:498,t:1528139696656};\\\", \\\"{x:745,y:498,t:1528139696679};\\\", \\\"{x:747,y:498,t:1528139696688};\\\", \\\"{x:755,y:498,t:1528139696705};\\\", \\\"{x:768,y:498,t:1528139696723};\\\", \\\"{x:778,y:498,t:1528139696738};\\\", \\\"{x:782,y:498,t:1528139696756};\\\", \\\"{x:787,y:498,t:1528139696773};\\\", \\\"{x:795,y:500,t:1528139696788};\\\", \\\"{x:797,y:500,t:1528139696807};\\\", \\\"{x:798,y:500,t:1528139696824};\\\", \\\"{x:800,y:500,t:1528139696839};\\\", \\\"{x:804,y:500,t:1528139696856};\\\", \\\"{x:806,y:500,t:1528139696872};\\\", \\\"{x:807,y:500,t:1528139696895};\\\", \\\"{x:807,y:499,t:1528139696960};\\\", \\\"{x:806,y:499,t:1528139697264};\\\", \\\"{x:805,y:500,t:1528139697272};\\\", \\\"{x:800,y:501,t:1528139697289};\\\", \\\"{x:798,y:503,t:1528139697305};\\\", \\\"{x:794,y:505,t:1528139697322};\\\", \\\"{x:791,y:505,t:1528139697339};\\\", \\\"{x:787,y:508,t:1528139697356};\\\", \\\"{x:784,y:509,t:1528139697373};\\\", \\\"{x:785,y:509,t:1528139697440};\\\", \\\"{x:789,y:509,t:1528139697456};\\\", \\\"{x:805,y:504,t:1528139697473};\\\", \\\"{x:830,y:494,t:1528139697490};\\\", \\\"{x:859,y:489,t:1528139697505};\\\", \\\"{x:875,y:485,t:1528139697524};\\\", \\\"{x:878,y:484,t:1528139697539};\\\", \\\"{x:879,y:484,t:1528139697556};\\\", \\\"{x:878,y:484,t:1528139697574};\\\", \\\"{x:875,y:484,t:1528139697589};\\\", \\\"{x:869,y:487,t:1528139697607};\\\", \\\"{x:862,y:490,t:1528139697622};\\\", \\\"{x:849,y:495,t:1528139697639};\\\", \\\"{x:846,y:498,t:1528139697657};\\\", \\\"{x:844,y:499,t:1528139697674};\\\", \\\"{x:840,y:501,t:1528139697690};\\\", \\\"{x:839,y:502,t:1528139697707};\\\", \\\"{x:836,y:505,t:1528139697722};\\\", \\\"{x:833,y:506,t:1528139697739};\\\", \\\"{x:829,y:507,t:1528139697756};\\\", \\\"{x:828,y:508,t:1528139697773};\\\", \\\"{x:828,y:511,t:1528139698111};\\\", \\\"{x:821,y:515,t:1528139698124};\\\", \\\"{x:801,y:520,t:1528139698142};\\\", \\\"{x:772,y:528,t:1528139698157};\\\", \\\"{x:724,y:535,t:1528139698173};\\\", \\\"{x:633,y:547,t:1528139698190};\\\", \\\"{x:542,y:556,t:1528139698207};\\\", \\\"{x:410,y:573,t:1528139698224};\\\", \\\"{x:355,y:579,t:1528139698240};\\\", \\\"{x:307,y:579,t:1528139698256};\\\", \\\"{x:278,y:579,t:1528139698273};\\\", \\\"{x:255,y:579,t:1528139698291};\\\", \\\"{x:240,y:579,t:1528139698307};\\\", \\\"{x:232,y:580,t:1528139698323};\\\", \\\"{x:231,y:581,t:1528139698340};\\\", \\\"{x:235,y:580,t:1528139698431};\\\", \\\"{x:245,y:573,t:1528139698441};\\\", \\\"{x:263,y:562,t:1528139698459};\\\", \\\"{x:276,y:553,t:1528139698474};\\\", \\\"{x:282,y:546,t:1528139698490};\\\", \\\"{x:284,y:543,t:1528139698507};\\\", \\\"{x:280,y:543,t:1528139698567};\\\", \\\"{x:272,y:543,t:1528139698576};\\\", \\\"{x:265,y:543,t:1528139698590};\\\", \\\"{x:231,y:543,t:1528139698607};\\\", \\\"{x:205,y:544,t:1528139698623};\\\", \\\"{x:186,y:546,t:1528139698641};\\\", \\\"{x:182,y:547,t:1528139698657};\\\", \\\"{x:181,y:547,t:1528139698674};\\\", \\\"{x:179,y:547,t:1528139698691};\\\", \\\"{x:177,y:547,t:1528139698708};\\\", \\\"{x:173,y:548,t:1528139698723};\\\", \\\"{x:171,y:549,t:1528139698740};\\\", \\\"{x:170,y:549,t:1528139698758};\\\", \\\"{x:169,y:549,t:1528139698775};\\\", \\\"{x:168,y:549,t:1528139698807};\\\", \\\"{x:167,y:549,t:1528139698839};\\\", \\\"{x:166,y:549,t:1528139698855};\\\", \\\"{x:165,y:549,t:1528139698887};\\\", \\\"{x:164,y:549,t:1528139698896};\\\", \\\"{x:163,y:549,t:1528139698920};\\\", \\\"{x:166,y:549,t:1528139699215};\\\", \\\"{x:173,y:553,t:1528139699225};\\\", \\\"{x:188,y:560,t:1528139699241};\\\", \\\"{x:214,y:581,t:1528139699258};\\\", \\\"{x:252,y:610,t:1528139699275};\\\", \\\"{x:292,y:641,t:1528139699291};\\\", \\\"{x:341,y:680,t:1528139699308};\\\", \\\"{x:403,y:727,t:1528139699324};\\\", \\\"{x:472,y:784,t:1528139699340};\\\", \\\"{x:529,y:831,t:1528139699358};\\\", \\\"{x:563,y:870,t:1528139699375};\\\", \\\"{x:584,y:887,t:1528139699390};\\\", \\\"{x:588,y:892,t:1528139699407};\\\", \\\"{x:588,y:894,t:1528139699431};\\\", \\\"{x:587,y:894,t:1528139699464};\\\", \\\"{x:585,y:894,t:1528139699475};\\\", \\\"{x:582,y:894,t:1528139699491};\\\", \\\"{x:580,y:893,t:1528139699508};\\\", \\\"{x:577,y:890,t:1528139699525};\\\", \\\"{x:573,y:873,t:1528139699541};\\\", \\\"{x:571,y:857,t:1528139699558};\\\", \\\"{x:566,y:838,t:1528139699575};\\\", \\\"{x:553,y:810,t:1528139699591};\\\", \\\"{x:542,y:794,t:1528139699608};\\\", \\\"{x:539,y:784,t:1528139699625};\\\", \\\"{x:539,y:775,t:1528139699641};\\\", \\\"{x:539,y:768,t:1528139699658};\\\", \\\"{x:539,y:765,t:1528139699674};\\\", \\\"{x:539,y:764,t:1528139699692};\\\", \\\"{x:539,y:762,t:1528139699708};\\\", \\\"{x:539,y:761,t:1528139699725};\\\", \\\"{x:537,y:760,t:1528139699800};\\\", \\\"{x:536,y:758,t:1528139699815};\\\", \\\"{x:534,y:757,t:1528139699825};\\\", \\\"{x:530,y:753,t:1528139699843};\\\", \\\"{x:529,y:753,t:1528139699857};\\\", \\\"{x:527,y:751,t:1528139699895};\\\", \\\"{x:525,y:749,t:1528139699908};\\\", \\\"{x:519,y:743,t:1528139699925};\\\", \\\"{x:518,y:743,t:1528139699942};\\\", \\\"{x:517,y:742,t:1528139699958};\\\" ] }, { \\\"rt\\\": 34535, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 12, \\\"time_elapsed\\\": 528435, \\\"internal_node_id\\\": \\\"0.0-6.0-2.0\\\", \\\"subject\\\": \\\"S6D2F\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+contained\\\", \\\"q\\\": 8, \\\"clicks\\\": 1, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:517,y:731,t:1528139733824};\\\", \\\"{x:517,y:605,t:1528139733848};\\\", \\\"{x:519,y:582,t:1528139733859};\\\", \\\"{x:529,y:512,t:1528139733875};\\\", \\\"{x:530,y:511,t:1528139733903};\\\", \\\"{x:530,y:516,t:1528139734119};\\\", \\\"{x:528,y:520,t:1528139734138};\\\", \\\"{x:527,y:520,t:1528139734154};\\\", \\\"{x:530,y:520,t:1528139734326};\\\", \\\"{x:534,y:520,t:1528139734337};\\\", \\\"{x:551,y:518,t:1528139734354};\\\", \\\"{x:569,y:514,t:1528139734370};\\\", \\\"{x:585,y:512,t:1528139734386};\\\", \\\"{x:604,y:509,t:1528139734403};\\\", \\\"{x:618,y:508,t:1528139734421};\\\", \\\"{x:623,y:507,t:1528139734436};\\\", \\\"{x:626,y:506,t:1528139734470};\\\", \\\"{x:627,y:506,t:1528139734487};\\\", \\\"{x:629,y:505,t:1528139734503};\\\", \\\"{x:627,y:505,t:1528139734910};\\\", \\\"{x:617,y:514,t:1528139734921};\\\", \\\"{x:585,y:552,t:1528139734939};\\\", \\\"{x:535,y:595,t:1528139734954};\\\", \\\"{x:471,y:655,t:1528139734971};\\\", \\\"{x:411,y:717,t:1528139734988};\\\", \\\"{x:361,y:782,t:1528139735003};\\\", \\\"{x:330,y:825,t:1528139735020};\\\", \\\"{x:312,y:851,t:1528139735038};\\\", \\\"{x:306,y:865,t:1528139735054};\\\", \\\"{x:303,y:872,t:1528139735070};\\\", \\\"{x:305,y:872,t:1528139735127};\\\", \\\"{x:308,y:870,t:1528139735137};\\\", \\\"{x:313,y:866,t:1528139735154};\\\", \\\"{x:320,y:859,t:1528139735171};\\\", \\\"{x:333,y:852,t:1528139735187};\\\", \\\"{x:346,y:846,t:1528139735204};\\\", \\\"{x:355,y:844,t:1528139735221};\\\", \\\"{x:363,y:841,t:1528139735236};\\\", \\\"{x:367,y:840,t:1528139735254};\\\", \\\"{x:379,y:835,t:1528139735270};\\\", \\\"{x:392,y:829,t:1528139735287};\\\", \\\"{x:406,y:823,t:1528139735304};\\\", \\\"{x:414,y:816,t:1528139735321};\\\", \\\"{x:425,y:807,t:1528139735337};\\\", \\\"{x:428,y:803,t:1528139735354};\\\", \\\"{x:432,y:793,t:1528139735371};\\\", \\\"{x:435,y:785,t:1528139735387};\\\", \\\"{x:436,y:779,t:1528139735404};\\\", \\\"{x:438,y:773,t:1528139735421};\\\", \\\"{x:440,y:766,t:1528139735438};\\\", \\\"{x:440,y:761,t:1528139735454};\\\", \\\"{x:442,y:756,t:1528139735471};\\\", \\\"{x:442,y:755,t:1528139735535};\\\", \\\"{x:442,y:754,t:1528139735543};\\\", \\\"{x:444,y:753,t:1528139735554};\\\", \\\"{x:444,y:751,t:1528139735570};\\\", \\\"{x:446,y:749,t:1528139735588};\\\", \\\"{x:448,y:747,t:1528139735603};\\\", \\\"{x:453,y:746,t:1528139735621};\\\", \\\"{x:456,y:744,t:1528139735637};\\\", \\\"{x:471,y:739,t:1528139735654};\\\", \\\"{x:479,y:736,t:1528139735671};\\\", \\\"{x:482,y:735,t:1528139735688};\\\", \\\"{x:485,y:735,t:1528139735704};\\\", \\\"{x:485,y:734,t:1528139735726};\\\", \\\"{x:486,y:734,t:1528139735766};\\\", \\\"{x:485,y:734,t:1528139736279};\\\", \\\"{x:484,y:734,t:1528139736294};\\\", \\\"{x:482,y:734,t:1528139736305};\\\", \\\"{x:479,y:736,t:1528139736321};\\\", \\\"{x:473,y:740,t:1528139736339};\\\", \\\"{x:467,y:745,t:1528139736355};\\\", \\\"{x:463,y:747,t:1528139736371};\\\", \\\"{x:460,y:750,t:1528139736389};\\\", \\\"{x:458,y:752,t:1528139736404};\\\", \\\"{x:457,y:753,t:1528139736422};\\\", \\\"{x:455,y:755,t:1528139736439};\\\", \\\"{x:454,y:756,t:1528139736455};\\\", \\\"{x:453,y:757,t:1528139736472};\\\", \\\"{x:452,y:758,t:1528139736615};\\\", \\\"{x:451,y:758,t:1528139736663};\\\", \\\"{x:449,y:759,t:1528139736672};\\\", \\\"{x:446,y:760,t:1528139736688};\\\", \\\"{x:443,y:762,t:1528139736706};\\\", \\\"{x:442,y:762,t:1528139736721};\\\", \\\"{x:441,y:763,t:1528139736739};\\\", \\\"{x:438,y:764,t:1528139736756};\\\", \\\"{x:437,y:765,t:1528139736772};\\\", \\\"{x:437,y:766,t:1528139736789};\\\", \\\"{x:435,y:766,t:1528139736806};\\\" ] }, { \\\"rt\\\": 18080, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 13, \\\"time_elapsed\\\": 547822, \\\"internal_node_id\\\": \\\"0.0-6.0-3.0\\\", \\\"subject\\\": \\\"S6D2F\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime+before+endtime+during\\\", \\\"q\\\": 9, \\\"clicks\\\": 1, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"I\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:434,y:766,t:1528139737871};\\\", \\\"{x:436,y:763,t:1528139752256};\\\", \\\"{x:444,y:759,t:1528139752264};\\\", \\\"{x:453,y:756,t:1528139752278};\\\", \\\"{x:466,y:750,t:1528139752296};\\\", \\\"{x:474,y:744,t:1528139752312};\\\", \\\"{x:483,y:711,t:1528139752327};\\\", \\\"{x:486,y:676,t:1528139752345};\\\", \\\"{x:491,y:645,t:1528139752362};\\\", \\\"{x:496,y:611,t:1528139752378};\\\", \\\"{x:501,y:586,t:1528139752396};\\\", \\\"{x:504,y:561,t:1528139752411};\\\", \\\"{x:512,y:540,t:1528139752428};\\\", \\\"{x:515,y:522,t:1528139752445};\\\", \\\"{x:521,y:506,t:1528139752462};\\\", \\\"{x:521,y:495,t:1528139752478};\\\", \\\"{x:523,y:488,t:1528139752495};\\\", \\\"{x:523,y:486,t:1528139752513};\\\", \\\"{x:524,y:485,t:1528139752527};\\\", \\\"{x:529,y:485,t:1528139752784};\\\", \\\"{x:535,y:487,t:1528139752797};\\\", \\\"{x:549,y:494,t:1528139752812};\\\", \\\"{x:566,y:501,t:1528139752829};\\\", \\\"{x:587,y:510,t:1528139752845};\\\", \\\"{x:610,y:518,t:1528139752862};\\\", \\\"{x:625,y:523,t:1528139752879};\\\", \\\"{x:633,y:525,t:1528139752895};\\\", \\\"{x:632,y:525,t:1528139752976};\\\", \\\"{x:628,y:525,t:1528139752983};\\\", \\\"{x:626,y:524,t:1528139752995};\\\", \\\"{x:618,y:520,t:1528139753012};\\\", \\\"{x:606,y:514,t:1528139753030};\\\", \\\"{x:595,y:512,t:1528139753045};\\\", \\\"{x:586,y:510,t:1528139753062};\\\", \\\"{x:572,y:509,t:1528139753080};\\\", \\\"{x:558,y:507,t:1528139753095};\\\", \\\"{x:539,y:504,t:1528139753112};\\\", \\\"{x:535,y:504,t:1528139753129};\\\", \\\"{x:532,y:504,t:1528139753146};\\\", \\\"{x:531,y:504,t:1528139753176};\\\", \\\"{x:530,y:507,t:1528139753233};\\\", \\\"{x:528,y:510,t:1528139753246};\\\", \\\"{x:527,y:517,t:1528139753263};\\\", \\\"{x:522,y:525,t:1528139753281};\\\", \\\"{x:514,y:536,t:1528139753296};\\\", \\\"{x:508,y:542,t:1528139753312};\\\", \\\"{x:501,y:548,t:1528139753329};\\\", \\\"{x:495,y:550,t:1528139753346};\\\", \\\"{x:488,y:552,t:1528139753362};\\\", \\\"{x:484,y:554,t:1528139753379};\\\", \\\"{x:481,y:554,t:1528139753396};\\\", \\\"{x:476,y:554,t:1528139753411};\\\", \\\"{x:472,y:554,t:1528139753429};\\\", \\\"{x:468,y:553,t:1528139753446};\\\", \\\"{x:461,y:551,t:1528139753462};\\\", \\\"{x:450,y:549,t:1528139753479};\\\", \\\"{x:428,y:541,t:1528139753495};\\\", \\\"{x:405,y:535,t:1528139753512};\\\", \\\"{x:382,y:529,t:1528139753529};\\\", \\\"{x:353,y:524,t:1528139753547};\\\", \\\"{x:331,y:522,t:1528139753563};\\\", \\\"{x:311,y:517,t:1528139753580};\\\", \\\"{x:302,y:516,t:1528139753596};\\\", \\\"{x:298,y:516,t:1528139753613};\\\", \\\"{x:302,y:517,t:1528139753705};\\\", \\\"{x:305,y:517,t:1528139753713};\\\", \\\"{x:315,y:518,t:1528139753730};\\\", \\\"{x:328,y:519,t:1528139753746};\\\", \\\"{x:341,y:522,t:1528139753762};\\\", \\\"{x:359,y:524,t:1528139753779};\\\", \\\"{x:378,y:530,t:1528139753796};\\\", \\\"{x:403,y:537,t:1528139753812};\\\", \\\"{x:430,y:543,t:1528139753829};\\\", \\\"{x:450,y:547,t:1528139753846};\\\", \\\"{x:460,y:548,t:1528139753863};\\\", \\\"{x:462,y:550,t:1528139753879};\\\", \\\"{x:460,y:550,t:1528139753896};\\\", \\\"{x:450,y:551,t:1528139753913};\\\", \\\"{x:429,y:547,t:1528139753930};\\\", \\\"{x:394,y:536,t:1528139753947};\\\", \\\"{x:355,y:525,t:1528139753963};\\\", \\\"{x:324,y:519,t:1528139753981};\\\", \\\"{x:292,y:515,t:1528139753997};\\\", \\\"{x:259,y:510,t:1528139754014};\\\", \\\"{x:211,y:503,t:1528139754030};\\\", \\\"{x:180,y:497,t:1528139754046};\\\", \\\"{x:165,y:496,t:1528139754063};\\\", \\\"{x:162,y:495,t:1528139754080};\\\", \\\"{x:161,y:495,t:1528139754217};\\\", \\\"{x:163,y:496,t:1528139754503};\\\", \\\"{x:167,y:497,t:1528139754513};\\\", \\\"{x:179,y:505,t:1528139754531};\\\", \\\"{x:198,y:517,t:1528139754547};\\\", \\\"{x:227,y:536,t:1528139754564};\\\", \\\"{x:265,y:558,t:1528139754581};\\\", \\\"{x:300,y:577,t:1528139754598};\\\", \\\"{x:337,y:596,t:1528139754613};\\\", \\\"{x:388,y:624,t:1528139754631};\\\", \\\"{x:449,y:648,t:1528139754647};\\\", \\\"{x:491,y:667,t:1528139754663};\\\", \\\"{x:527,y:680,t:1528139754680};\\\", \\\"{x:541,y:687,t:1528139754697};\\\", \\\"{x:546,y:691,t:1528139754713};\\\", \\\"{x:549,y:696,t:1528139754730};\\\", \\\"{x:552,y:703,t:1528139754747};\\\", \\\"{x:555,y:709,t:1528139754763};\\\", \\\"{x:559,y:717,t:1528139754780};\\\", \\\"{x:563,y:730,t:1528139754798};\\\", \\\"{x:571,y:749,t:1528139754813};\\\", \\\"{x:575,y:762,t:1528139754830};\\\", \\\"{x:577,y:772,t:1528139754848};\\\", \\\"{x:578,y:777,t:1528139754864};\\\", \\\"{x:578,y:779,t:1528139754880};\\\", \\\"{x:578,y:776,t:1528139754952};\\\", \\\"{x:577,y:772,t:1528139754964};\\\", \\\"{x:569,y:764,t:1528139754981};\\\", \\\"{x:563,y:758,t:1528139754998};\\\", \\\"{x:558,y:753,t:1528139755015};\\\", \\\"{x:553,y:750,t:1528139755031};\\\", \\\"{x:552,y:749,t:1528139755047};\\\", \\\"{x:550,y:748,t:1528139755064};\\\", \\\"{x:550,y:747,t:1528139755529};\\\" ] }, { \\\"rt\\\": 25859, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 14, \\\"time_elapsed\\\": 574951, \\\"internal_node_id\\\": \\\"0.0-6.0-4.0\\\", \\\"subject\\\": \\\"S6D2F\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"ends\\\", \\\"q\\\": 10, \\\"clicks\\\": 1, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-M -F -12 PM-12 PM-F -F -F -Z \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:555,y:746,t:1528139766081};\\\", \\\"{x:584,y:740,t:1528139766096};\\\", \\\"{x:611,y:734,t:1528139766113};\\\", \\\"{x:615,y:731,t:1528139766128};\\\", \\\"{x:617,y:729,t:1528139766139};\\\", \\\"{x:631,y:703,t:1528139766156};\\\", \\\"{x:651,y:656,t:1528139766174};\\\", \\\"{x:670,y:607,t:1528139766190};\\\", \\\"{x:694,y:529,t:1528139766207};\\\", \\\"{x:735,y:416,t:1528139766223};\\\", \\\"{x:747,y:369,t:1528139766239};\\\", \\\"{x:762,y:326,t:1528139766256};\\\", \\\"{x:766,y:313,t:1528139766273};\\\", \\\"{x:768,y:309,t:1528139766289};\\\", \\\"{x:770,y:308,t:1528139766306};\\\", \\\"{x:773,y:308,t:1528139766324};\\\", \\\"{x:782,y:308,t:1528139766339};\\\", \\\"{x:845,y:328,t:1528139766357};\\\", \\\"{x:958,y:359,t:1528139766373};\\\", \\\"{x:1111,y:415,t:1528139766390};\\\", \\\"{x:1297,y:477,t:1528139766406};\\\", \\\"{x:1578,y:545,t:1528139766424};\\\", \\\"{x:1731,y:580,t:1528139766440};\\\", \\\"{x:1838,y:617,t:1528139766456};\\\", \\\"{x:1889,y:643,t:1528139766474};\\\", \\\"{x:1900,y:653,t:1528139766490};\\\", \\\"{x:1901,y:659,t:1528139766506};\\\", \\\"{x:1901,y:665,t:1528139766523};\\\", \\\"{x:1898,y:674,t:1528139766539};\\\", \\\"{x:1891,y:682,t:1528139766557};\\\", \\\"{x:1885,y:692,t:1528139766573};\\\", \\\"{x:1875,y:704,t:1528139766589};\\\", \\\"{x:1863,y:726,t:1528139766606};\\\", \\\"{x:1843,y:764,t:1528139766624};\\\", \\\"{x:1827,y:792,t:1528139766640};\\\", \\\"{x:1803,y:826,t:1528139766656};\\\", \\\"{x:1777,y:852,t:1528139766674};\\\", \\\"{x:1751,y:869,t:1528139766689};\\\", \\\"{x:1746,y:872,t:1528139766707};\\\", \\\"{x:1746,y:876,t:1528139766724};\\\", \\\"{x:1720,y:884,t:1528139766741};\\\", \\\"{x:1716,y:886,t:1528139766757};\\\", \\\"{x:1714,y:886,t:1528139766773};\\\", \\\"{x:1713,y:886,t:1528139766790};\\\", \\\"{x:1712,y:884,t:1528139766807};\\\", \\\"{x:1712,y:883,t:1528139766856};\\\", \\\"{x:1709,y:881,t:1528139766874};\\\", \\\"{x:1703,y:875,t:1528139766891};\\\", \\\"{x:1689,y:864,t:1528139766907};\\\", \\\"{x:1671,y:852,t:1528139766924};\\\", \\\"{x:1649,y:847,t:1528139766941};\\\", \\\"{x:1624,y:846,t:1528139766957};\\\", \\\"{x:1605,y:846,t:1528139766974};\\\", \\\"{x:1582,y:846,t:1528139766991};\\\", \\\"{x:1544,y:854,t:1528139767007};\\\", \\\"{x:1491,y:874,t:1528139767024};\\\", \\\"{x:1448,y:881,t:1528139767041};\\\", \\\"{x:1415,y:883,t:1528139767057};\\\", \\\"{x:1383,y:883,t:1528139767074};\\\", \\\"{x:1366,y:882,t:1528139767092};\\\", \\\"{x:1366,y:880,t:1528139767107};\\\", \\\"{x:1366,y:878,t:1528139767416};\\\", \\\"{x:1369,y:871,t:1528139767424};\\\", \\\"{x:1374,y:854,t:1528139767441};\\\", \\\"{x:1374,y:838,t:1528139767457};\\\", \\\"{x:1372,y:822,t:1528139767474};\\\", \\\"{x:1370,y:806,t:1528139767491};\\\", \\\"{x:1364,y:785,t:1528139767508};\\\", \\\"{x:1358,y:762,t:1528139767524};\\\", \\\"{x:1349,y:737,t:1528139767541};\\\", \\\"{x:1347,y:726,t:1528139767558};\\\", \\\"{x:1343,y:714,t:1528139767574};\\\", \\\"{x:1342,y:708,t:1528139767592};\\\", \\\"{x:1340,y:704,t:1528139767608};\\\", \\\"{x:1340,y:703,t:1528139767624};\\\", \\\"{x:1340,y:701,t:1528139767704};\\\", \\\"{x:1340,y:700,t:1528139767752};\\\", \\\"{x:1341,y:700,t:1528139767816};\\\", \\\"{x:1342,y:700,t:1528139767824};\\\", \\\"{x:1347,y:703,t:1528139767841};\\\", \\\"{x:1352,y:709,t:1528139767858};\\\", \\\"{x:1354,y:711,t:1528139767874};\\\", \\\"{x:1355,y:711,t:1528139767891};\\\", \\\"{x:1356,y:712,t:1528139767908};\\\", \\\"{x:1354,y:711,t:1528139768032};\\\", \\\"{x:1352,y:709,t:1528139768041};\\\", \\\"{x:1347,y:705,t:1528139768058};\\\", \\\"{x:1346,y:705,t:1528139768074};\\\", \\\"{x:1345,y:704,t:1528139768092};\\\", \\\"{x:1344,y:704,t:1528139768108};\\\", \\\"{x:1344,y:703,t:1528139768136};\\\", \\\"{x:1344,y:702,t:1528139768144};\\\", \\\"{x:1344,y:701,t:1528139768162};\\\", \\\"{x:1344,y:700,t:1528139768174};\\\", \\\"{x:1344,y:699,t:1528139768190};\\\", \\\"{x:1345,y:696,t:1528139768207};\\\", \\\"{x:1345,y:695,t:1528139768239};\\\", \\\"{x:1346,y:694,t:1528139768287};\\\", \\\"{x:1346,y:693,t:1528139768311};\\\", \\\"{x:1346,y:695,t:1528139770312};\\\", \\\"{x:1346,y:706,t:1528139770327};\\\", \\\"{x:1341,y:738,t:1528139770342};\\\", \\\"{x:1336,y:785,t:1528139770359};\\\", \\\"{x:1321,y:876,t:1528139770376};\\\", \\\"{x:1320,y:924,t:1528139770393};\\\", \\\"{x:1320,y:954,t:1528139770409};\\\", \\\"{x:1320,y:983,t:1528139770426};\\\", \\\"{x:1320,y:1003,t:1528139770442};\\\", \\\"{x:1320,y:1013,t:1528139770459};\\\", \\\"{x:1320,y:1019,t:1528139770476};\\\", \\\"{x:1320,y:1023,t:1528139770492};\\\", \\\"{x:1321,y:1024,t:1528139770509};\\\", \\\"{x:1321,y:1025,t:1528139770526};\\\", \\\"{x:1321,y:1026,t:1528139770542};\\\", \\\"{x:1322,y:1027,t:1528139770559};\\\", \\\"{x:1325,y:1029,t:1528139770577};\\\", \\\"{x:1328,y:1030,t:1528139770592};\\\", \\\"{x:1328,y:1027,t:1528139770712};\\\", \\\"{x:1328,y:1022,t:1528139770727};\\\", \\\"{x:1329,y:1011,t:1528139770742};\\\", \\\"{x:1330,y:999,t:1528139770760};\\\", \\\"{x:1332,y:983,t:1528139770776};\\\", \\\"{x:1334,y:969,t:1528139770792};\\\", \\\"{x:1335,y:960,t:1528139770811};\\\", \\\"{x:1337,y:950,t:1528139770826};\\\", \\\"{x:1339,y:943,t:1528139770843};\\\", \\\"{x:1340,y:939,t:1528139770860};\\\", \\\"{x:1341,y:937,t:1528139770876};\\\", \\\"{x:1341,y:936,t:1528139770904};\\\", \\\"{x:1343,y:936,t:1528139770984};\\\", \\\"{x:1345,y:936,t:1528139770992};\\\", \\\"{x:1349,y:939,t:1528139771010};\\\", \\\"{x:1349,y:941,t:1528139771027};\\\", \\\"{x:1349,y:943,t:1528139771043};\\\", \\\"{x:1349,y:946,t:1528139771059};\\\", \\\"{x:1349,y:949,t:1528139771076};\\\", \\\"{x:1349,y:952,t:1528139771093};\\\", \\\"{x:1349,y:954,t:1528139771109};\\\", \\\"{x:1349,y:956,t:1528139771127};\\\", \\\"{x:1349,y:958,t:1528139771143};\\\", \\\"{x:1349,y:960,t:1528139771159};\\\", \\\"{x:1349,y:963,t:1528139771176};\\\", \\\"{x:1349,y:967,t:1528139771193};\\\", \\\"{x:1349,y:969,t:1528139771210};\\\", \\\"{x:1350,y:972,t:1528139771226};\\\", \\\"{x:1351,y:974,t:1528139771243};\\\", \\\"{x:1351,y:975,t:1528139771259};\\\", \\\"{x:1351,y:974,t:1528139771488};\\\", \\\"{x:1351,y:973,t:1528139771496};\\\", \\\"{x:1351,y:972,t:1528139771509};\\\", \\\"{x:1351,y:970,t:1528139771526};\\\", \\\"{x:1352,y:968,t:1528139771544};\\\", \\\"{x:1352,y:966,t:1528139771559};\\\", \\\"{x:1352,y:964,t:1528139771576};\\\", \\\"{x:1352,y:963,t:1528139771593};\\\", \\\"{x:1352,y:960,t:1528139771609};\\\", \\\"{x:1353,y:960,t:1528139771627};\\\", \\\"{x:1353,y:959,t:1528139771643};\\\", \\\"{x:1353,y:958,t:1528139771659};\\\", \\\"{x:1353,y:956,t:1528139771676};\\\", \\\"{x:1353,y:954,t:1528139771693};\\\", \\\"{x:1353,y:952,t:1528139771709};\\\", \\\"{x:1353,y:950,t:1528139771726};\\\", \\\"{x:1353,y:948,t:1528139771744};\\\", \\\"{x:1353,y:946,t:1528139771760};\\\", \\\"{x:1353,y:944,t:1528139771776};\\\", \\\"{x:1353,y:941,t:1528139771794};\\\", \\\"{x:1353,y:938,t:1528139771809};\\\", \\\"{x:1351,y:934,t:1528139771826};\\\", \\\"{x:1350,y:930,t:1528139771843};\\\", \\\"{x:1348,y:923,t:1528139771860};\\\", \\\"{x:1347,y:917,t:1528139771877};\\\", \\\"{x:1346,y:909,t:1528139771893};\\\", \\\"{x:1345,y:902,t:1528139771910};\\\", \\\"{x:1345,y:895,t:1528139771926};\\\", \\\"{x:1344,y:888,t:1528139771943};\\\", \\\"{x:1342,y:877,t:1528139771959};\\\", \\\"{x:1342,y:873,t:1528139771976};\\\", \\\"{x:1342,y:867,t:1528139771993};\\\", \\\"{x:1341,y:863,t:1528139772011};\\\", \\\"{x:1341,y:858,t:1528139772026};\\\", \\\"{x:1341,y:854,t:1528139772044};\\\", \\\"{x:1341,y:847,t:1528139772061};\\\", \\\"{x:1340,y:839,t:1528139772076};\\\", \\\"{x:1338,y:832,t:1528139772093};\\\", \\\"{x:1337,y:827,t:1528139772110};\\\", \\\"{x:1337,y:819,t:1528139772126};\\\", \\\"{x:1337,y:814,t:1528139772144};\\\", \\\"{x:1337,y:803,t:1528139772160};\\\", \\\"{x:1337,y:797,t:1528139772176};\\\", \\\"{x:1337,y:791,t:1528139772193};\\\", \\\"{x:1337,y:785,t:1528139772210};\\\", \\\"{x:1337,y:780,t:1528139772227};\\\", \\\"{x:1337,y:775,t:1528139772244};\\\", \\\"{x:1337,y:770,t:1528139772260};\\\", \\\"{x:1337,y:765,t:1528139772276};\\\", \\\"{x:1337,y:761,t:1528139772293};\\\", \\\"{x:1337,y:754,t:1528139772310};\\\", \\\"{x:1337,y:751,t:1528139772326};\\\", \\\"{x:1337,y:747,t:1528139772343};\\\", \\\"{x:1339,y:740,t:1528139772359};\\\", \\\"{x:1339,y:737,t:1528139772376};\\\", \\\"{x:1340,y:734,t:1528139772393};\\\", \\\"{x:1342,y:731,t:1528139772410};\\\", \\\"{x:1343,y:729,t:1528139772427};\\\", \\\"{x:1344,y:725,t:1528139772443};\\\", \\\"{x:1347,y:719,t:1528139772460};\\\", \\\"{x:1349,y:714,t:1528139772477};\\\", \\\"{x:1351,y:706,t:1528139772493};\\\", \\\"{x:1352,y:703,t:1528139772510};\\\", \\\"{x:1353,y:697,t:1528139772527};\\\", \\\"{x:1353,y:691,t:1528139772544};\\\", \\\"{x:1353,y:683,t:1528139772559};\\\", \\\"{x:1351,y:680,t:1528139772578};\\\", \\\"{x:1348,y:675,t:1528139772593};\\\", \\\"{x:1347,y:672,t:1528139772611};\\\", \\\"{x:1347,y:671,t:1528139772792};\\\", \\\"{x:1347,y:672,t:1528139772872};\\\", \\\"{x:1346,y:672,t:1528139772888};\\\", \\\"{x:1346,y:674,t:1528139772896};\\\", \\\"{x:1346,y:675,t:1528139772911};\\\", \\\"{x:1346,y:677,t:1528139772927};\\\", \\\"{x:1346,y:678,t:1528139772960};\\\", \\\"{x:1346,y:679,t:1528139772992};\\\", \\\"{x:1346,y:680,t:1528139773000};\\\", \\\"{x:1346,y:681,t:1528139773016};\\\", \\\"{x:1346,y:682,t:1528139773027};\\\", \\\"{x:1346,y:683,t:1528139773043};\\\", \\\"{x:1346,y:684,t:1528139773060};\\\", \\\"{x:1346,y:685,t:1528139773096};\\\", \\\"{x:1346,y:686,t:1528139773120};\\\", \\\"{x:1346,y:687,t:1528139773144};\\\", \\\"{x:1346,y:689,t:1528139773160};\\\", \\\"{x:1346,y:691,t:1528139773177};\\\", \\\"{x:1346,y:694,t:1528139773194};\\\", \\\"{x:1347,y:698,t:1528139773209};\\\", \\\"{x:1347,y:699,t:1528139773239};\\\", \\\"{x:1347,y:700,t:1528139773336};\\\", \\\"{x:1348,y:700,t:1528139773343};\\\", \\\"{x:1359,y:705,t:1528139773361};\\\", \\\"{x:1386,y:713,t:1528139773377};\\\", \\\"{x:1434,y:727,t:1528139773394};\\\", \\\"{x:1496,y:747,t:1528139773411};\\\", \\\"{x:1560,y:768,t:1528139773427};\\\", \\\"{x:1607,y:780,t:1528139773444};\\\", \\\"{x:1641,y:797,t:1528139773460};\\\", \\\"{x:1656,y:808,t:1528139773477};\\\", \\\"{x:1664,y:816,t:1528139773494};\\\", \\\"{x:1666,y:825,t:1528139773510};\\\", \\\"{x:1666,y:835,t:1528139773527};\\\", \\\"{x:1657,y:854,t:1528139773543};\\\", \\\"{x:1648,y:867,t:1528139773560};\\\", \\\"{x:1640,y:879,t:1528139773577};\\\", \\\"{x:1633,y:890,t:1528139773595};\\\", \\\"{x:1625,y:902,t:1528139773610};\\\", \\\"{x:1615,y:916,t:1528139773628};\\\", \\\"{x:1613,y:921,t:1528139773645};\\\", \\\"{x:1613,y:922,t:1528139773660};\\\", \\\"{x:1613,y:925,t:1528139773678};\\\", \\\"{x:1613,y:928,t:1528139773695};\\\", \\\"{x:1613,y:934,t:1528139773711};\\\", \\\"{x:1613,y:939,t:1528139773727};\\\", \\\"{x:1614,y:948,t:1528139773744};\\\", \\\"{x:1615,y:951,t:1528139773760};\\\", \\\"{x:1615,y:952,t:1528139773778};\\\", \\\"{x:1615,y:954,t:1528139773794};\\\", \\\"{x:1615,y:958,t:1528139773810};\\\", \\\"{x:1615,y:960,t:1528139773827};\\\", \\\"{x:1615,y:961,t:1528139773968};\\\", \\\"{x:1615,y:960,t:1528139774128};\\\", \\\"{x:1615,y:956,t:1528139774144};\\\", \\\"{x:1615,y:949,t:1528139774161};\\\", \\\"{x:1615,y:941,t:1528139774177};\\\", \\\"{x:1615,y:933,t:1528139774195};\\\", \\\"{x:1615,y:926,t:1528139774211};\\\", \\\"{x:1615,y:918,t:1528139774227};\\\", \\\"{x:1615,y:916,t:1528139774244};\\\", \\\"{x:1615,y:912,t:1528139774262};\\\", \\\"{x:1614,y:910,t:1528139774277};\\\", \\\"{x:1614,y:907,t:1528139774294};\\\", \\\"{x:1613,y:903,t:1528139774311};\\\", \\\"{x:1613,y:900,t:1528139774327};\\\", \\\"{x:1613,y:895,t:1528139774344};\\\", \\\"{x:1613,y:889,t:1528139774362};\\\", \\\"{x:1613,y:883,t:1528139774377};\\\", \\\"{x:1613,y:878,t:1528139774394};\\\", \\\"{x:1612,y:871,t:1528139774411};\\\", \\\"{x:1612,y:862,t:1528139774427};\\\", \\\"{x:1612,y:852,t:1528139774444};\\\", \\\"{x:1612,y:837,t:1528139774462};\\\", \\\"{x:1610,y:815,t:1528139774477};\\\", \\\"{x:1610,y:800,t:1528139774494};\\\", \\\"{x:1610,y:789,t:1528139774511};\\\", \\\"{x:1612,y:781,t:1528139774528};\\\", \\\"{x:1612,y:775,t:1528139774544};\\\", \\\"{x:1612,y:771,t:1528139774561};\\\", \\\"{x:1612,y:764,t:1528139774579};\\\", \\\"{x:1613,y:758,t:1528139774594};\\\", \\\"{x:1614,y:754,t:1528139774611};\\\", \\\"{x:1614,y:749,t:1528139774628};\\\", \\\"{x:1614,y:746,t:1528139774645};\\\", \\\"{x:1614,y:742,t:1528139774661};\\\", \\\"{x:1614,y:738,t:1528139774679};\\\", \\\"{x:1614,y:737,t:1528139774695};\\\", \\\"{x:1614,y:736,t:1528139774711};\\\", \\\"{x:1614,y:735,t:1528139774729};\\\", \\\"{x:1614,y:734,t:1528139774744};\\\", \\\"{x:1614,y:733,t:1528139774776};\\\", \\\"{x:1614,y:732,t:1528139774792};\\\", \\\"{x:1614,y:731,t:1528139774800};\\\", \\\"{x:1614,y:729,t:1528139774812};\\\", \\\"{x:1614,y:728,t:1528139774829};\\\", \\\"{x:1614,y:726,t:1528139774844};\\\", \\\"{x:1614,y:725,t:1528139774862};\\\", \\\"{x:1615,y:723,t:1528139774878};\\\", \\\"{x:1615,y:720,t:1528139774895};\\\", \\\"{x:1615,y:718,t:1528139774911};\\\", \\\"{x:1615,y:713,t:1528139774928};\\\", \\\"{x:1615,y:712,t:1528139774944};\\\", \\\"{x:1615,y:710,t:1528139774961};\\\", \\\"{x:1615,y:708,t:1528139774979};\\\", \\\"{x:1616,y:706,t:1528139774995};\\\", \\\"{x:1617,y:705,t:1528139775011};\\\", \\\"{x:1617,y:703,t:1528139775028};\\\", \\\"{x:1617,y:702,t:1528139775056};\\\", \\\"{x:1617,y:701,t:1528139775176};\\\", \\\"{x:1617,y:700,t:1528139775224};\\\", \\\"{x:1617,y:699,t:1528139775240};\\\", \\\"{x:1617,y:698,t:1528139775288};\\\", \\\"{x:1617,y:697,t:1528139775528};\\\", \\\"{x:1614,y:696,t:1528139775545};\\\", \\\"{x:1613,y:694,t:1528139775561};\\\", \\\"{x:1610,y:693,t:1528139779448};\\\", \\\"{x:1543,y:676,t:1528139779464};\\\", \\\"{x:1418,y:658,t:1528139779480};\\\", \\\"{x:1228,y:642,t:1528139779497};\\\", \\\"{x:996,y:646,t:1528139779513};\\\", \\\"{x:760,y:660,t:1528139779531};\\\", \\\"{x:534,y:695,t:1528139779547};\\\", \\\"{x:357,y:717,t:1528139779564};\\\", \\\"{x:262,y:731,t:1528139779581};\\\", \\\"{x:241,y:734,t:1528139779596};\\\", \\\"{x:240,y:734,t:1528139779614};\\\", \\\"{x:244,y:730,t:1528139779880};\\\", \\\"{x:278,y:707,t:1528139779897};\\\", \\\"{x:316,y:683,t:1528139779914};\\\", \\\"{x:373,y:652,t:1528139779932};\\\", \\\"{x:420,y:634,t:1528139779948};\\\", \\\"{x:449,y:617,t:1528139779963};\\\", \\\"{x:485,y:595,t:1528139779986};\\\", \\\"{x:500,y:585,t:1528139780002};\\\", \\\"{x:511,y:577,t:1528139780018};\\\", \\\"{x:526,y:567,t:1528139780035};\\\", \\\"{x:541,y:560,t:1528139780051};\\\", \\\"{x:553,y:553,t:1528139780068};\\\", \\\"{x:568,y:547,t:1528139780084};\\\", \\\"{x:583,y:540,t:1528139780101};\\\", \\\"{x:593,y:536,t:1528139780118};\\\", \\\"{x:602,y:533,t:1528139780135};\\\", \\\"{x:608,y:533,t:1528139780152};\\\", \\\"{x:617,y:534,t:1528139780168};\\\", \\\"{x:626,y:537,t:1528139780185};\\\", \\\"{x:632,y:538,t:1528139780200};\\\", \\\"{x:632,y:539,t:1528139780217};\\\", \\\"{x:632,y:541,t:1528139780235};\\\", \\\"{x:635,y:547,t:1528139780251};\\\", \\\"{x:635,y:552,t:1528139780269};\\\", \\\"{x:636,y:559,t:1528139780286};\\\", \\\"{x:636,y:562,t:1528139780301};\\\", \\\"{x:636,y:563,t:1528139780319};\\\", \\\"{x:635,y:565,t:1528139780334};\\\", \\\"{x:634,y:566,t:1528139780352};\\\", \\\"{x:633,y:567,t:1528139780368};\\\", \\\"{x:632,y:567,t:1528139780391};\\\", \\\"{x:631,y:567,t:1528139780402};\\\", \\\"{x:630,y:567,t:1528139780418};\\\", \\\"{x:629,y:568,t:1528139780435};\\\", \\\"{x:626,y:568,t:1528139780452};\\\", \\\"{x:625,y:568,t:1528139780469};\\\", \\\"{x:622,y:568,t:1528139780485};\\\", \\\"{x:619,y:568,t:1528139780503};\\\", \\\"{x:618,y:568,t:1528139780518};\\\", \\\"{x:615,y:567,t:1528139780535};\\\", \\\"{x:614,y:567,t:1528139780656};\\\", \\\"{x:613,y:567,t:1528139780671};\\\", \\\"{x:613,y:568,t:1528139781046};\\\", \\\"{x:611,y:578,t:1528139781055};\\\", \\\"{x:606,y:587,t:1528139781069};\\\", \\\"{x:595,y:608,t:1528139781086};\\\", \\\"{x:580,y:645,t:1528139781102};\\\", \\\"{x:555,y:697,t:1528139781119};\\\", \\\"{x:545,y:724,t:1528139781136};\\\", \\\"{x:539,y:742,t:1528139781152};\\\", \\\"{x:536,y:753,t:1528139781169};\\\", \\\"{x:532,y:761,t:1528139781186};\\\", \\\"{x:529,y:766,t:1528139781202};\\\", \\\"{x:527,y:769,t:1528139781219};\\\", \\\"{x:526,y:769,t:1528139781236};\\\", \\\"{x:524,y:769,t:1528139781253};\\\", \\\"{x:522,y:769,t:1528139781269};\\\", \\\"{x:519,y:769,t:1528139781286};\\\", \\\"{x:513,y:769,t:1528139781303};\\\", \\\"{x:512,y:768,t:1528139781319};\\\", \\\"{x:511,y:767,t:1528139781432};\\\", \\\"{x:510,y:765,t:1528139781440};\\\", \\\"{x:510,y:762,t:1528139781453};\\\", \\\"{x:509,y:757,t:1528139781470};\\\", \\\"{x:509,y:752,t:1528139781488};\\\", \\\"{x:508,y:745,t:1528139781503};\\\", \\\"{x:508,y:743,t:1528139781518};\\\", \\\"{x:506,y:741,t:1528139783023};\\\", \\\"{x:502,y:739,t:1528139783037};\\\", \\\"{x:492,y:739,t:1528139783054};\\\", \\\"{x:484,y:739,t:1528139783070};\\\", \\\"{x:477,y:739,t:1528139783087};\\\", \\\"{x:474,y:739,t:1528139783104};\\\", \\\"{x:473,y:739,t:1528139783143};\\\", \\\"{x:471,y:739,t:1528139783264};\\\", \\\"{x:470,y:739,t:1528139783271};\\\", \\\"{x:469,y:739,t:1528139783288};\\\" ] }, { \\\"rt\\\": 10055, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 15, \\\"time_elapsed\\\": 586372, \\\"internal_node_id\\\": \\\"0.0-6.0-5.0\\\", \\\"subject\\\": \\\"S6D2F\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 11, \\\"clicks\\\": 2, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-04 PM-J \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:467,y:739,t:1528139784768};\\\", \\\"{x:466,y:738,t:1528139784796};\\\", \\\"{x:466,y:737,t:1528139784846};\\\", \\\"{x:467,y:736,t:1528139784856};\\\", \\\"{x:478,y:731,t:1528139784873};\\\", \\\"{x:499,y:726,t:1528139784890};\\\", \\\"{x:527,y:718,t:1528139784906};\\\", \\\"{x:566,y:706,t:1528139784923};\\\", \\\"{x:610,y:696,t:1528139784939};\\\", \\\"{x:639,y:687,t:1528139784955};\\\", \\\"{x:692,y:677,t:1528139784972};\\\", \\\"{x:746,y:667,t:1528139784989};\\\", \\\"{x:789,y:657,t:1528139785005};\\\", \\\"{x:850,y:652,t:1528139785023};\\\", \\\"{x:879,y:647,t:1528139785038};\\\", \\\"{x:895,y:647,t:1528139785055};\\\", \\\"{x:918,y:647,t:1528139785072};\\\", \\\"{x:943,y:647,t:1528139785089};\\\", \\\"{x:961,y:649,t:1528139785105};\\\", \\\"{x:970,y:652,t:1528139785123};\\\", \\\"{x:975,y:653,t:1528139785139};\\\", \\\"{x:977,y:655,t:1528139785156};\\\", \\\"{x:977,y:656,t:1528139785172};\\\", \\\"{x:978,y:657,t:1528139785189};\\\", \\\"{x:978,y:658,t:1528139785206};\\\", \\\"{x:978,y:663,t:1528139785222};\\\", \\\"{x:978,y:688,t:1528139785240};\\\", \\\"{x:976,y:719,t:1528139785256};\\\", \\\"{x:965,y:756,t:1528139785272};\\\", \\\"{x:957,y:787,t:1528139785290};\\\", \\\"{x:953,y:803,t:1528139785306};\\\", \\\"{x:946,y:822,t:1528139785323};\\\", \\\"{x:940,y:839,t:1528139785340};\\\", \\\"{x:933,y:856,t:1528139785357};\\\", \\\"{x:925,y:874,t:1528139785372};\\\", \\\"{x:921,y:882,t:1528139785389};\\\", \\\"{x:920,y:887,t:1528139785406};\\\", \\\"{x:919,y:889,t:1528139785422};\\\", \\\"{x:919,y:890,t:1528139785447};\\\", \\\"{x:919,y:891,t:1528139785470};\\\", \\\"{x:919,y:893,t:1528139785503};\\\", \\\"{x:921,y:893,t:1528139785527};\\\", \\\"{x:923,y:893,t:1528139785539};\\\", \\\"{x:933,y:893,t:1528139785556};\\\", \\\"{x:950,y:893,t:1528139785572};\\\", \\\"{x:980,y:893,t:1528139785589};\\\", \\\"{x:1034,y:886,t:1528139785606};\\\", \\\"{x:1098,y:878,t:1528139785622};\\\", \\\"{x:1211,y:869,t:1528139785639};\\\", \\\"{x:1293,y:865,t:1528139785656};\\\", \\\"{x:1351,y:865,t:1528139785673};\\\", \\\"{x:1413,y:864,t:1528139785689};\\\", \\\"{x:1445,y:866,t:1528139785707};\\\", \\\"{x:1466,y:873,t:1528139785723};\\\", \\\"{x:1488,y:883,t:1528139785740};\\\", \\\"{x:1512,y:896,t:1528139785757};\\\", \\\"{x:1547,y:915,t:1528139785774};\\\", \\\"{x:1590,y:936,t:1528139785790};\\\", \\\"{x:1625,y:950,t:1528139785807};\\\", \\\"{x:1653,y:962,t:1528139785824};\\\", \\\"{x:1657,y:963,t:1528139785840};\\\", \\\"{x:1652,y:965,t:1528139785944};\\\", \\\"{x:1635,y:970,t:1528139785956};\\\", \\\"{x:1585,y:978,t:1528139785975};\\\", \\\"{x:1518,y:987,t:1528139785990};\\\", \\\"{x:1464,y:997,t:1528139786007};\\\", \\\"{x:1448,y:1002,t:1528139786023};\\\", \\\"{x:1448,y:1003,t:1528139786040};\\\", \\\"{x:1447,y:1004,t:1528139786057};\\\", \\\"{x:1448,y:1004,t:1528139786160};\\\", \\\"{x:1452,y:1003,t:1528139786173};\\\", \\\"{x:1461,y:999,t:1528139786191};\\\", \\\"{x:1474,y:994,t:1528139786206};\\\", \\\"{x:1488,y:988,t:1528139786224};\\\", \\\"{x:1502,y:982,t:1528139786240};\\\", \\\"{x:1516,y:976,t:1528139786256};\\\", \\\"{x:1523,y:973,t:1528139786274};\\\", \\\"{x:1526,y:972,t:1528139786290};\\\", \\\"{x:1522,y:970,t:1528139786352};\\\", \\\"{x:1517,y:967,t:1528139786359};\\\", \\\"{x:1512,y:966,t:1528139786373};\\\", \\\"{x:1494,y:965,t:1528139786391};\\\", \\\"{x:1451,y:965,t:1528139786408};\\\", \\\"{x:1428,y:965,t:1528139786423};\\\", \\\"{x:1412,y:965,t:1528139786441};\\\", \\\"{x:1409,y:965,t:1528139786457};\\\", \\\"{x:1408,y:965,t:1528139786584};\\\", \\\"{x:1408,y:966,t:1528139786641};\\\", \\\"{x:1409,y:966,t:1528139786688};\\\", \\\"{x:1410,y:967,t:1528139786719};\\\", \\\"{x:1411,y:967,t:1528139786736};\\\", \\\"{x:1413,y:967,t:1528139786752};\\\", \\\"{x:1417,y:967,t:1528139786760};\\\", \\\"{x:1421,y:967,t:1528139786774};\\\", \\\"{x:1427,y:967,t:1528139786791};\\\", \\\"{x:1428,y:967,t:1528139786807};\\\", \\\"{x:1427,y:967,t:1528139786863};\\\", \\\"{x:1425,y:967,t:1528139786874};\\\", \\\"{x:1414,y:967,t:1528139786891};\\\", \\\"{x:1399,y:967,t:1528139786908};\\\", \\\"{x:1380,y:967,t:1528139786924};\\\", \\\"{x:1361,y:967,t:1528139786940};\\\", \\\"{x:1340,y:967,t:1528139786957};\\\", \\\"{x:1331,y:967,t:1528139786975};\\\", \\\"{x:1324,y:969,t:1528139786991};\\\", \\\"{x:1321,y:969,t:1528139787008};\\\", \\\"{x:1320,y:969,t:1528139787032};\\\", \\\"{x:1320,y:968,t:1528139787136};\\\", \\\"{x:1321,y:967,t:1528139787151};\\\", \\\"{x:1322,y:967,t:1528139787158};\\\", \\\"{x:1323,y:965,t:1528139787174};\\\", \\\"{x:1329,y:961,t:1528139787190};\\\", \\\"{x:1331,y:958,t:1528139787207};\\\", \\\"{x:1334,y:955,t:1528139787224};\\\", \\\"{x:1336,y:953,t:1528139787241};\\\", \\\"{x:1339,y:950,t:1528139787257};\\\", \\\"{x:1342,y:946,t:1528139787274};\\\", \\\"{x:1347,y:943,t:1528139787291};\\\", \\\"{x:1349,y:941,t:1528139787307};\\\", \\\"{x:1351,y:940,t:1528139787324};\\\", \\\"{x:1351,y:939,t:1528139787343};\\\", \\\"{x:1351,y:938,t:1528139787367};\\\", \\\"{x:1351,y:940,t:1528139787504};\\\", \\\"{x:1350,y:942,t:1528139787512};\\\", \\\"{x:1350,y:943,t:1528139787525};\\\", \\\"{x:1349,y:945,t:1528139787542};\\\", \\\"{x:1349,y:947,t:1528139787558};\\\", \\\"{x:1349,y:950,t:1528139787575};\\\", \\\"{x:1349,y:954,t:1528139787591};\\\", \\\"{x:1348,y:956,t:1528139787609};\\\", \\\"{x:1348,y:957,t:1528139787625};\\\", \\\"{x:1348,y:958,t:1528139787642};\\\", \\\"{x:1348,y:959,t:1528139787658};\\\", \\\"{x:1348,y:960,t:1528139787675};\\\", \\\"{x:1348,y:962,t:1528139787720};\\\", \\\"{x:1347,y:963,t:1528139787735};\\\", \\\"{x:1346,y:964,t:1528139787744};\\\", \\\"{x:1346,y:965,t:1528139787759};\\\", \\\"{x:1346,y:966,t:1528139787775};\\\", \\\"{x:1346,y:962,t:1528139787912};\\\", \\\"{x:1346,y:959,t:1528139787925};\\\", \\\"{x:1348,y:954,t:1528139787942};\\\", \\\"{x:1350,y:947,t:1528139787959};\\\", \\\"{x:1352,y:943,t:1528139787975};\\\", \\\"{x:1353,y:939,t:1528139787991};\\\", \\\"{x:1354,y:937,t:1528139788008};\\\", \\\"{x:1354,y:936,t:1528139788048};\\\", \\\"{x:1355,y:934,t:1528139788480};\\\", \\\"{x:1357,y:932,t:1528139788494};\\\", \\\"{x:1356,y:924,t:1528139789208};\\\", \\\"{x:1345,y:912,t:1528139789216};\\\", \\\"{x:1337,y:904,t:1528139789227};\\\", \\\"{x:1310,y:881,t:1528139789243};\\\", \\\"{x:1265,y:849,t:1528139789260};\\\", \\\"{x:1212,y:813,t:1528139789277};\\\", \\\"{x:1111,y:772,t:1528139789294};\\\", \\\"{x:968,y:718,t:1528139789310};\\\", \\\"{x:793,y:652,t:1528139789327};\\\", \\\"{x:577,y:591,t:1528139789344};\\\", \\\"{x:260,y:497,t:1528139789360};\\\", \\\"{x:0,y:389,t:1528139789393};\\\", \\\"{x:0,y:354,t:1528139789409};\\\", \\\"{x:0,y:340,t:1528139789425};\\\", \\\"{x:0,y:338,t:1528139789442};\\\", \\\"{x:0,y:337,t:1528139789459};\\\", \\\"{x:2,y:337,t:1528139789475};\\\", \\\"{x:16,y:338,t:1528139789492};\\\", \\\"{x:42,y:345,t:1528139789509};\\\", \\\"{x:111,y:365,t:1528139789525};\\\", \\\"{x:224,y:395,t:1528139789542};\\\", \\\"{x:399,y:428,t:1528139789558};\\\", \\\"{x:504,y:454,t:1528139789576};\\\", \\\"{x:601,y:484,t:1528139789593};\\\", \\\"{x:680,y:512,t:1528139789610};\\\", \\\"{x:732,y:533,t:1528139789627};\\\", \\\"{x:756,y:544,t:1528139789643};\\\", \\\"{x:765,y:549,t:1528139789659};\\\", \\\"{x:769,y:551,t:1528139789677};\\\", \\\"{x:769,y:552,t:1528139789694};\\\", \\\"{x:769,y:554,t:1528139789709};\\\", \\\"{x:766,y:555,t:1528139789727};\\\", \\\"{x:744,y:559,t:1528139789744};\\\", \\\"{x:716,y:559,t:1528139789761};\\\", \\\"{x:680,y:559,t:1528139789776};\\\", \\\"{x:618,y:559,t:1528139789792};\\\", \\\"{x:546,y:559,t:1528139789809};\\\", \\\"{x:527,y:556,t:1528139789826};\\\", \\\"{x:506,y:551,t:1528139789843};\\\", \\\"{x:496,y:546,t:1528139789860};\\\", \\\"{x:490,y:544,t:1528139789876};\\\", \\\"{x:482,y:545,t:1528139789894};\\\", \\\"{x:479,y:547,t:1528139789909};\\\", \\\"{x:470,y:551,t:1528139789927};\\\", \\\"{x:451,y:558,t:1528139789943};\\\", \\\"{x:430,y:563,t:1528139789959};\\\", \\\"{x:414,y:570,t:1528139789977};\\\", \\\"{x:390,y:573,t:1528139789993};\\\", \\\"{x:365,y:574,t:1528139790009};\\\", \\\"{x:339,y:575,t:1528139790026};\\\", \\\"{x:315,y:576,t:1528139790043};\\\", \\\"{x:279,y:580,t:1528139790060};\\\", \\\"{x:234,y:580,t:1528139790076};\\\", \\\"{x:176,y:580,t:1528139790094};\\\", \\\"{x:115,y:580,t:1528139790109};\\\", \\\"{x:64,y:580,t:1528139790126};\\\", \\\"{x:15,y:580,t:1528139790143};\\\", \\\"{x:0,y:580,t:1528139790160};\\\", \\\"{x:0,y:582,t:1528139790176};\\\", \\\"{x:0,y:583,t:1528139790279};\\\", \\\"{x:7,y:585,t:1528139790295};\\\", \\\"{x:16,y:586,t:1528139790310};\\\", \\\"{x:41,y:589,t:1528139790325};\\\", \\\"{x:63,y:592,t:1528139790343};\\\", \\\"{x:98,y:597,t:1528139790359};\\\", \\\"{x:117,y:600,t:1528139790376};\\\", \\\"{x:131,y:603,t:1528139790394};\\\", \\\"{x:146,y:606,t:1528139790410};\\\", \\\"{x:162,y:608,t:1528139790426};\\\", \\\"{x:180,y:611,t:1528139790444};\\\", \\\"{x:193,y:612,t:1528139790460};\\\", \\\"{x:208,y:613,t:1528139790476};\\\", \\\"{x:222,y:615,t:1528139790494};\\\", \\\"{x:239,y:616,t:1528139790510};\\\", \\\"{x:262,y:618,t:1528139790526};\\\", \\\"{x:306,y:622,t:1528139790544};\\\", \\\"{x:336,y:622,t:1528139790560};\\\", \\\"{x:354,y:622,t:1528139790576};\\\", \\\"{x:363,y:622,t:1528139790593};\\\", \\\"{x:364,y:622,t:1528139790610};\\\", \\\"{x:365,y:622,t:1528139790631};\\\", \\\"{x:366,y:622,t:1528139790643};\\\", \\\"{x:369,y:622,t:1528139790660};\\\", \\\"{x:372,y:622,t:1528139790676};\\\", \\\"{x:378,y:622,t:1528139790694};\\\", \\\"{x:383,y:620,t:1528139790710};\\\", \\\"{x:392,y:617,t:1528139790727};\\\", \\\"{x:398,y:615,t:1528139790744};\\\", \\\"{x:403,y:612,t:1528139790761};\\\", \\\"{x:405,y:612,t:1528139790778};\\\", \\\"{x:405,y:610,t:1528139790839};\\\", \\\"{x:407,y:609,t:1528139790855};\\\", \\\"{x:407,y:608,t:1528139790864};\\\", \\\"{x:408,y:607,t:1528139790878};\\\", \\\"{x:412,y:603,t:1528139790896};\\\", \\\"{x:416,y:598,t:1528139790910};\\\", \\\"{x:429,y:590,t:1528139790927};\\\", \\\"{x:447,y:584,t:1528139790943};\\\", \\\"{x:479,y:576,t:1528139790960};\\\", \\\"{x:528,y:567,t:1528139790978};\\\", \\\"{x:575,y:555,t:1528139790994};\\\", \\\"{x:631,y:545,t:1528139791011};\\\", \\\"{x:692,y:539,t:1528139791027};\\\", \\\"{x:741,y:530,t:1528139791043};\\\", \\\"{x:768,y:525,t:1528139791060};\\\", \\\"{x:786,y:524,t:1528139791078};\\\", \\\"{x:795,y:521,t:1528139791094};\\\", \\\"{x:797,y:521,t:1528139791110};\\\", \\\"{x:798,y:521,t:1528139791214};\\\", \\\"{x:800,y:521,t:1528139791230};\\\", \\\"{x:806,y:516,t:1528139791244};\\\", \\\"{x:820,y:512,t:1528139791260};\\\", \\\"{x:831,y:508,t:1528139791278};\\\", \\\"{x:834,y:506,t:1528139791295};\\\", \\\"{x:835,y:505,t:1528139791383};\\\", \\\"{x:837,y:505,t:1528139791710};\\\", \\\"{x:833,y:505,t:1528139791727};\\\", \\\"{x:807,y:517,t:1528139791745};\\\", \\\"{x:723,y:543,t:1528139791761};\\\", \\\"{x:583,y:578,t:1528139791778};\\\", \\\"{x:407,y:618,t:1528139791795};\\\", \\\"{x:238,y:643,t:1528139791812};\\\", \\\"{x:59,y:661,t:1528139791827};\\\", \\\"{x:0,y:661,t:1528139791844};\\\", \\\"{x:0,y:656,t:1528139791861};\\\", \\\"{x:0,y:650,t:1528139791877};\\\", \\\"{x:0,y:645,t:1528139791894};\\\", \\\"{x:2,y:638,t:1528139791911};\\\", \\\"{x:9,y:630,t:1528139791927};\\\", \\\"{x:23,y:622,t:1528139791944};\\\", \\\"{x:35,y:614,t:1528139791961};\\\", \\\"{x:50,y:606,t:1528139791978};\\\", \\\"{x:62,y:601,t:1528139791994};\\\", \\\"{x:76,y:597,t:1528139792012};\\\", \\\"{x:89,y:594,t:1528139792028};\\\", \\\"{x:105,y:590,t:1528139792045};\\\", \\\"{x:120,y:585,t:1528139792061};\\\", \\\"{x:137,y:582,t:1528139792078};\\\", \\\"{x:157,y:577,t:1528139792095};\\\", \\\"{x:162,y:575,t:1528139792112};\\\", \\\"{x:163,y:574,t:1528139792128};\\\", \\\"{x:163,y:572,t:1528139792150};\\\", \\\"{x:163,y:571,t:1528139792161};\\\", \\\"{x:159,y:569,t:1528139792178};\\\", \\\"{x:157,y:568,t:1528139792194};\\\", \\\"{x:157,y:566,t:1528139792215};\\\", \\\"{x:157,y:565,t:1528139792229};\\\", \\\"{x:158,y:562,t:1528139792245};\\\", \\\"{x:161,y:559,t:1528139792261};\\\", \\\"{x:163,y:558,t:1528139792278};\\\", \\\"{x:164,y:556,t:1528139792294};\\\", \\\"{x:165,y:555,t:1528139792312};\\\", \\\"{x:166,y:554,t:1528139792329};\\\", \\\"{x:166,y:553,t:1528139792345};\\\", \\\"{x:167,y:552,t:1528139792361};\\\", \\\"{x:167,y:551,t:1528139792379};\\\", \\\"{x:167,y:550,t:1528139792395};\\\", \\\"{x:167,y:549,t:1528139792411};\\\", \\\"{x:167,y:548,t:1528139792428};\\\", \\\"{x:165,y:547,t:1528139792445};\\\", \\\"{x:164,y:547,t:1528139792461};\\\", \\\"{x:163,y:546,t:1528139792478};\\\", \\\"{x:162,y:546,t:1528139792510};\\\", \\\"{x:161,y:546,t:1528139792519};\\\", \\\"{x:160,y:545,t:1528139792528};\\\", \\\"{x:159,y:545,t:1528139792545};\\\", \\\"{x:160,y:546,t:1528139792951};\\\", \\\"{x:171,y:559,t:1528139792963};\\\", \\\"{x:227,y:595,t:1528139792979};\\\", \\\"{x:324,y:646,t:1528139792997};\\\", \\\"{x:438,y:698,t:1528139793013};\\\", \\\"{x:543,y:743,t:1528139793029};\\\", \\\"{x:630,y:776,t:1528139793046};\\\", \\\"{x:693,y:798,t:1528139793062};\\\", \\\"{x:705,y:803,t:1528139793078};\\\", \\\"{x:706,y:804,t:1528139793095};\\\", \\\"{x:699,y:802,t:1528139793263};\\\", \\\"{x:674,y:795,t:1528139793279};\\\", \\\"{x:636,y:784,t:1528139793296};\\\", \\\"{x:601,y:776,t:1528139793312};\\\", \\\"{x:551,y:770,t:1528139793329};\\\", \\\"{x:497,y:759,t:1528139793345};\\\", \\\"{x:473,y:756,t:1528139793363};\\\", \\\"{x:465,y:755,t:1528139793380};\\\", \\\"{x:470,y:755,t:1528139793550};\\\", \\\"{x:477,y:755,t:1528139793563};\\\", \\\"{x:492,y:755,t:1528139793579};\\\", \\\"{x:502,y:754,t:1528139793595};\\\", \\\"{x:510,y:751,t:1528139793612};\\\", \\\"{x:511,y:751,t:1528139793628};\\\" ] }, { \\\"rt\\\": 7867, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 16, \\\"time_elapsed\\\": 595461, \\\"internal_node_id\\\": \\\"0.0-6.0-6.0\\\", \\\"subject\\\": \\\"S6D2F\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 12, \\\"clicks\\\": 1.5, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:510,y:752,t:1528139796136};\\\", \\\"{x:508,y:754,t:1528139796149};\\\", \\\"{x:504,y:762,t:1528139796173};\\\", \\\"{x:502,y:769,t:1528139796182};\\\", \\\"{x:501,y:774,t:1528139796198};\\\", \\\"{x:499,y:779,t:1528139796215};\\\", \\\"{x:498,y:782,t:1528139796231};\\\", \\\"{x:498,y:784,t:1528139796249};\\\", \\\"{x:497,y:785,t:1528139796264};\\\", \\\"{x:497,y:786,t:1528139796281};\\\", \\\"{x:497,y:789,t:1528139796298};\\\", \\\"{x:495,y:791,t:1528139796314};\\\", \\\"{x:495,y:795,t:1528139796331};\\\", \\\"{x:493,y:799,t:1528139796348};\\\", \\\"{x:486,y:817,t:1528139796365};\\\", \\\"{x:470,y:834,t:1528139796381};\\\", \\\"{x:469,y:834,t:1528139796398};\\\", \\\"{x:469,y:831,t:1528139800608};\\\", \\\"{x:469,y:808,t:1528139800619};\\\", \\\"{x:470,y:779,t:1528139800635};\\\", \\\"{x:475,y:747,t:1528139800653};\\\", \\\"{x:477,y:715,t:1528139800669};\\\", \\\"{x:475,y:669,t:1528139800702};\\\", \\\"{x:475,y:647,t:1528139800718};\\\", \\\"{x:475,y:637,t:1528139800735};\\\", \\\"{x:474,y:631,t:1528139800752};\\\", \\\"{x:473,y:626,t:1528139800768};\\\", \\\"{x:472,y:618,t:1528139800785};\\\", \\\"{x:468,y:609,t:1528139800801};\\\", \\\"{x:459,y:596,t:1528139800818};\\\", \\\"{x:438,y:580,t:1528139800836};\\\", \\\"{x:395,y:558,t:1528139800851};\\\", \\\"{x:332,y:532,t:1528139800869};\\\", \\\"{x:249,y:508,t:1528139800886};\\\", \\\"{x:159,y:481,t:1528139800902};\\\", \\\"{x:36,y:466,t:1528139800918};\\\", \\\"{x:0,y:459,t:1528139800936};\\\", \\\"{x:0,y:460,t:1528139800951};\\\", \\\"{x:0,y:465,t:1528139800969};\\\", \\\"{x:0,y:471,t:1528139800986};\\\", \\\"{x:0,y:474,t:1528139801002};\\\", \\\"{x:0,y:478,t:1528139801019};\\\", \\\"{x:0,y:484,t:1528139801036};\\\", \\\"{x:1,y:490,t:1528139801052};\\\", \\\"{x:3,y:498,t:1528139801068};\\\", \\\"{x:7,y:507,t:1528139801086};\\\", \\\"{x:12,y:520,t:1528139801103};\\\", \\\"{x:18,y:526,t:1528139801119};\\\", \\\"{x:29,y:534,t:1528139801136};\\\", \\\"{x:43,y:538,t:1528139801152};\\\", \\\"{x:56,y:540,t:1528139801170};\\\", \\\"{x:70,y:541,t:1528139801186};\\\", \\\"{x:78,y:543,t:1528139801203};\\\", \\\"{x:82,y:544,t:1528139801219};\\\", \\\"{x:87,y:545,t:1528139801235};\\\", \\\"{x:103,y:548,t:1528139801252};\\\", \\\"{x:117,y:550,t:1528139801269};\\\", \\\"{x:136,y:553,t:1528139801286};\\\", \\\"{x:148,y:554,t:1528139801302};\\\", \\\"{x:150,y:554,t:1528139801320};\\\", \\\"{x:151,y:554,t:1528139801375};\\\", \\\"{x:151,y:555,t:1528139801386};\\\", \\\"{x:152,y:555,t:1528139801431};\\\", \\\"{x:153,y:555,t:1528139801439};\\\", \\\"{x:154,y:555,t:1528139801455};\\\", \\\"{x:155,y:555,t:1528139801469};\\\", \\\"{x:156,y:555,t:1528139801824};\\\", \\\"{x:158,y:554,t:1528139801837};\\\", \\\"{x:159,y:549,t:1528139801855};\\\", \\\"{x:163,y:541,t:1528139801871};\\\", \\\"{x:165,y:538,t:1528139801886};\\\", \\\"{x:165,y:535,t:1528139801902};\\\", \\\"{x:167,y:534,t:1528139802182};\\\", \\\"{x:168,y:534,t:1528139802190};\\\", \\\"{x:172,y:534,t:1528139802203};\\\", \\\"{x:188,y:541,t:1528139802219};\\\", \\\"{x:210,y:553,t:1528139802237};\\\", \\\"{x:243,y:566,t:1528139802253};\\\", \\\"{x:286,y:583,t:1528139802270};\\\", \\\"{x:392,y:628,t:1528139802286};\\\", \\\"{x:480,y:663,t:1528139802305};\\\", \\\"{x:564,y:692,t:1528139802320};\\\", \\\"{x:621,y:712,t:1528139802336};\\\", \\\"{x:652,y:726,t:1528139802353};\\\", \\\"{x:668,y:735,t:1528139802369};\\\", \\\"{x:675,y:741,t:1528139802387};\\\", \\\"{x:681,y:745,t:1528139802403};\\\", \\\"{x:685,y:749,t:1528139802420};\\\", \\\"{x:689,y:752,t:1528139802436};\\\", \\\"{x:689,y:753,t:1528139802454};\\\", \\\"{x:687,y:753,t:1528139802495};\\\", \\\"{x:675,y:753,t:1528139802504};\\\", \\\"{x:650,y:748,t:1528139802521};\\\", \\\"{x:624,y:744,t:1528139802537};\\\", \\\"{x:605,y:739,t:1528139802554};\\\", \\\"{x:586,y:736,t:1528139802571};\\\", \\\"{x:571,y:732,t:1528139802587};\\\", \\\"{x:567,y:732,t:1528139802604};\\\", \\\"{x:566,y:732,t:1528139802623};\\\", \\\"{x:566,y:733,t:1528139802646};\\\", \\\"{x:566,y:734,t:1528139802655};\\\", \\\"{x:565,y:737,t:1528139802670};\\\", \\\"{x:564,y:740,t:1528139802689};\\\", \\\"{x:563,y:743,t:1528139802704};\\\", \\\"{x:562,y:746,t:1528139802720};\\\", \\\"{x:561,y:747,t:1528139802735};\\\", \\\"{x:560,y:748,t:1528139802766};\\\", \\\"{x:559,y:748,t:1528139803255};\\\", \\\"{x:584,y:748,t:1528139803271};\\\", \\\"{x:628,y:748,t:1528139803288};\\\", \\\"{x:687,y:748,t:1528139803304};\\\", \\\"{x:764,y:748,t:1528139803321};\\\", \\\"{x:828,y:748,t:1528139803338};\\\", \\\"{x:882,y:748,t:1528139803354};\\\", \\\"{x:919,y:748,t:1528139803371};\\\", \\\"{x:942,y:748,t:1528139803387};\\\", \\\"{x:961,y:748,t:1528139803404};\\\", \\\"{x:974,y:748,t:1528139803421};\\\", \\\"{x:985,y:746,t:1528139803438};\\\", \\\"{x:990,y:745,t:1528139803454};\\\", \\\"{x:993,y:744,t:1528139803471};\\\", \\\"{x:994,y:744,t:1528139803488};\\\" ] }, { \\\"rt\\\": 29099, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 17, \\\"time_elapsed\\\": 625800, \\\"internal_node_id\\\": \\\"0.0-6.0-7.0\\\", \\\"subject\\\": \\\"S6D2F\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 13, \\\"clicks\\\": 2, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-04 PM-04 PM-01 PM-01 PM-X -B -F -F \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:990,y:744,t:1528139804783};\\\", \\\"{x:989,y:745,t:1528139804798};\\\", \\\"{x:987,y:746,t:1528139804807};\\\", \\\"{x:986,y:746,t:1528139804822};\\\", \\\"{x:984,y:748,t:1528139804838};\\\", \\\"{x:983,y:748,t:1528139804856};\\\", \\\"{x:982,y:749,t:1528139804872};\\\", \\\"{x:981,y:749,t:1528139804889};\\\", \\\"{x:986,y:748,t:1528139806247};\\\", \\\"{x:1000,y:745,t:1528139806257};\\\", \\\"{x:1029,y:734,t:1528139806273};\\\", \\\"{x:1115,y:725,t:1528139806290};\\\", \\\"{x:1196,y:723,t:1528139806307};\\\", \\\"{x:1279,y:723,t:1528139806323};\\\", \\\"{x:1357,y:723,t:1528139806340};\\\", \\\"{x:1413,y:730,t:1528139806358};\\\", \\\"{x:1454,y:746,t:1528139806373};\\\", \\\"{x:1479,y:758,t:1528139806390};\\\", \\\"{x:1501,y:778,t:1528139806407};\\\", \\\"{x:1509,y:790,t:1528139806424};\\\", \\\"{x:1513,y:798,t:1528139806440};\\\", \\\"{x:1520,y:808,t:1528139806457};\\\", \\\"{x:1529,y:817,t:1528139806473};\\\", \\\"{x:1543,y:833,t:1528139806490};\\\", \\\"{x:1564,y:850,t:1528139806508};\\\", \\\"{x:1587,y:870,t:1528139806524};\\\", \\\"{x:1620,y:897,t:1528139806541};\\\", \\\"{x:1655,y:918,t:1528139806558};\\\", \\\"{x:1693,y:940,t:1528139806574};\\\", \\\"{x:1723,y:962,t:1528139806591};\\\", \\\"{x:1759,y:990,t:1528139806607};\\\", \\\"{x:1778,y:1007,t:1528139806624};\\\", \\\"{x:1791,y:1016,t:1528139806640};\\\", \\\"{x:1795,y:1019,t:1528139806658};\\\", \\\"{x:1797,y:1019,t:1528139806674};\\\", \\\"{x:1797,y:1020,t:1528139806719};\\\", \\\"{x:1798,y:1020,t:1528139806735};\\\", \\\"{x:1799,y:1020,t:1528139806743};\\\", \\\"{x:1801,y:1020,t:1528139806759};\\\", \\\"{x:1803,y:1020,t:1528139806774};\\\", \\\"{x:1806,y:1019,t:1528139806791};\\\", \\\"{x:1817,y:1012,t:1528139806807};\\\", \\\"{x:1822,y:1009,t:1528139806824};\\\", \\\"{x:1823,y:1008,t:1528139806840};\\\", \\\"{x:1824,y:1007,t:1528139806857};\\\", \\\"{x:1825,y:1004,t:1528139806874};\\\", \\\"{x:1825,y:1002,t:1528139806890};\\\", \\\"{x:1825,y:999,t:1528139806907};\\\", \\\"{x:1825,y:997,t:1528139806924};\\\", \\\"{x:1817,y:994,t:1528139806940};\\\", \\\"{x:1805,y:990,t:1528139806957};\\\", \\\"{x:1797,y:989,t:1528139806975};\\\", \\\"{x:1774,y:989,t:1528139806991};\\\", \\\"{x:1756,y:992,t:1528139807007};\\\", \\\"{x:1745,y:996,t:1528139807025};\\\", \\\"{x:1736,y:997,t:1528139807042};\\\", \\\"{x:1729,y:999,t:1528139807058};\\\", \\\"{x:1722,y:1001,t:1528139807074};\\\", \\\"{x:1719,y:1003,t:1528139807091};\\\", \\\"{x:1714,y:1004,t:1528139807108};\\\", \\\"{x:1712,y:1005,t:1528139807135};\\\", \\\"{x:1711,y:1005,t:1528139807151};\\\", \\\"{x:1710,y:1005,t:1528139807167};\\\", \\\"{x:1709,y:1005,t:1528139807175};\\\", \\\"{x:1704,y:1005,t:1528139807191};\\\", \\\"{x:1697,y:1005,t:1528139807207};\\\", \\\"{x:1681,y:1005,t:1528139807224};\\\", \\\"{x:1672,y:1005,t:1528139807242};\\\", \\\"{x:1654,y:1002,t:1528139807257};\\\", \\\"{x:1641,y:1000,t:1528139807275};\\\", \\\"{x:1624,y:995,t:1528139807292};\\\", \\\"{x:1615,y:993,t:1528139807307};\\\", \\\"{x:1609,y:991,t:1528139807324};\\\", \\\"{x:1610,y:989,t:1528139807520};\\\", \\\"{x:1611,y:989,t:1528139807527};\\\", \\\"{x:1612,y:988,t:1528139807541};\\\", \\\"{x:1619,y:984,t:1528139807559};\\\", \\\"{x:1619,y:983,t:1528139808178};\\\", \\\"{x:1613,y:983,t:1528139808185};\\\", \\\"{x:1602,y:983,t:1528139808201};\\\", \\\"{x:1598,y:983,t:1528139808218};\\\", \\\"{x:1597,y:983,t:1528139808236};\\\", \\\"{x:1596,y:985,t:1528139808252};\\\", \\\"{x:1594,y:987,t:1528139808268};\\\", \\\"{x:1593,y:987,t:1528139808314};\\\", \\\"{x:1592,y:987,t:1528139808402};\\\", \\\"{x:1592,y:986,t:1528139808426};\\\", \\\"{x:1592,y:985,t:1528139808436};\\\", \\\"{x:1592,y:984,t:1528139808466};\\\", \\\"{x:1592,y:983,t:1528139808481};\\\", \\\"{x:1592,y:982,t:1528139808489};\\\", \\\"{x:1593,y:979,t:1528139808505};\\\", \\\"{x:1594,y:978,t:1528139808521};\\\", \\\"{x:1595,y:976,t:1528139808536};\\\", \\\"{x:1596,y:974,t:1528139808553};\\\", \\\"{x:1599,y:972,t:1528139808568};\\\", \\\"{x:1605,y:966,t:1528139808586};\\\", \\\"{x:1609,y:962,t:1528139808603};\\\", \\\"{x:1613,y:960,t:1528139808619};\\\", \\\"{x:1619,y:956,t:1528139808636};\\\", \\\"{x:1626,y:952,t:1528139808653};\\\", \\\"{x:1635,y:948,t:1528139808669};\\\", \\\"{x:1641,y:947,t:1528139808685};\\\", \\\"{x:1643,y:945,t:1528139808703};\\\", \\\"{x:1643,y:948,t:1528139808802};\\\", \\\"{x:1641,y:948,t:1528139808820};\\\", \\\"{x:1631,y:948,t:1528139808836};\\\", \\\"{x:1613,y:948,t:1528139808853};\\\", \\\"{x:1596,y:947,t:1528139808870};\\\", \\\"{x:1574,y:942,t:1528139808886};\\\", \\\"{x:1534,y:934,t:1528139808903};\\\", \\\"{x:1492,y:928,t:1528139808919};\\\", \\\"{x:1435,y:917,t:1528139808936};\\\", \\\"{x:1368,y:904,t:1528139808952};\\\", \\\"{x:1285,y:893,t:1528139808969};\\\", \\\"{x:1254,y:887,t:1528139808987};\\\", \\\"{x:1226,y:882,t:1528139809003};\\\", \\\"{x:1201,y:878,t:1528139809020};\\\", \\\"{x:1177,y:871,t:1528139809036};\\\", \\\"{x:1145,y:864,t:1528139809052};\\\", \\\"{x:1110,y:851,t:1528139809070};\\\", \\\"{x:1068,y:839,t:1528139809086};\\\", \\\"{x:1035,y:832,t:1528139809103};\\\", \\\"{x:1015,y:822,t:1528139809120};\\\", \\\"{x:1008,y:817,t:1528139809136};\\\", \\\"{x:1010,y:814,t:1528139809153};\\\", \\\"{x:1020,y:808,t:1528139809170};\\\", \\\"{x:1042,y:798,t:1528139809185};\\\", \\\"{x:1070,y:789,t:1528139809203};\\\", \\\"{x:1122,y:767,t:1528139809220};\\\", \\\"{x:1180,y:741,t:1528139809237};\\\", \\\"{x:1220,y:728,t:1528139809253};\\\", \\\"{x:1256,y:713,t:1528139809270};\\\", \\\"{x:1283,y:701,t:1528139809287};\\\", \\\"{x:1303,y:691,t:1528139809303};\\\", \\\"{x:1315,y:683,t:1528139809320};\\\", \\\"{x:1322,y:675,t:1528139809337};\\\", \\\"{x:1324,y:673,t:1528139809353};\\\", \\\"{x:1326,y:671,t:1528139809369};\\\", \\\"{x:1327,y:668,t:1528139809389};\\\", \\\"{x:1328,y:665,t:1528139809403};\\\", \\\"{x:1330,y:662,t:1528139809420};\\\", \\\"{x:1331,y:659,t:1528139809437};\\\", \\\"{x:1331,y:658,t:1528139809458};\\\", \\\"{x:1332,y:658,t:1528139809666};\\\", \\\"{x:1334,y:656,t:1528139809673};\\\", \\\"{x:1340,y:649,t:1528139809687};\\\", \\\"{x:1359,y:638,t:1528139809704};\\\", \\\"{x:1384,y:628,t:1528139809720};\\\", \\\"{x:1407,y:619,t:1528139809737};\\\", \\\"{x:1453,y:596,t:1528139809753};\\\", \\\"{x:1474,y:586,t:1528139809770};\\\", \\\"{x:1490,y:576,t:1528139809788};\\\", \\\"{x:1496,y:571,t:1528139809804};\\\", \\\"{x:1497,y:567,t:1528139809820};\\\", \\\"{x:1498,y:562,t:1528139809837};\\\", \\\"{x:1499,y:553,t:1528139809853};\\\", \\\"{x:1499,y:541,t:1528139809870};\\\", \\\"{x:1498,y:530,t:1528139809887};\\\", \\\"{x:1496,y:521,t:1528139809904};\\\", \\\"{x:1493,y:517,t:1528139809920};\\\", \\\"{x:1490,y:513,t:1528139809937};\\\", \\\"{x:1489,y:511,t:1528139809954};\\\", \\\"{x:1490,y:511,t:1528139810001};\\\", \\\"{x:1493,y:512,t:1528139810010};\\\", \\\"{x:1498,y:517,t:1528139810020};\\\", \\\"{x:1513,y:534,t:1528139810037};\\\", \\\"{x:1532,y:564,t:1528139810054};\\\", \\\"{x:1563,y:611,t:1528139810070};\\\", \\\"{x:1594,y:651,t:1528139810087};\\\", \\\"{x:1624,y:687,t:1528139810104};\\\", \\\"{x:1653,y:722,t:1528139810120};\\\", \\\"{x:1669,y:740,t:1528139810137};\\\", \\\"{x:1679,y:750,t:1528139810153};\\\", \\\"{x:1680,y:750,t:1528139810202};\\\", \\\"{x:1680,y:744,t:1528139810209};\\\", \\\"{x:1682,y:739,t:1528139810221};\\\", \\\"{x:1682,y:733,t:1528139810236};\\\", \\\"{x:1683,y:731,t:1528139810254};\\\", \\\"{x:1683,y:730,t:1528139810321};\\\", \\\"{x:1683,y:729,t:1528139810337};\\\", \\\"{x:1670,y:723,t:1528139810354};\\\", \\\"{x:1655,y:721,t:1528139810371};\\\", \\\"{x:1640,y:720,t:1528139810389};\\\", \\\"{x:1626,y:720,t:1528139810404};\\\", \\\"{x:1616,y:718,t:1528139810421};\\\", \\\"{x:1611,y:718,t:1528139810437};\\\", \\\"{x:1608,y:718,t:1528139810454};\\\", \\\"{x:1605,y:718,t:1528139810471};\\\", \\\"{x:1604,y:718,t:1528139810674};\\\", \\\"{x:1604,y:717,t:1528139810688};\\\", \\\"{x:1604,y:713,t:1528139810704};\\\", \\\"{x:1604,y:711,t:1528139810721};\\\", \\\"{x:1604,y:710,t:1528139810737};\\\", \\\"{x:1604,y:708,t:1528139810786};\\\", \\\"{x:1604,y:707,t:1528139811001};\\\", \\\"{x:1604,y:705,t:1528139814825};\\\", \\\"{x:1606,y:703,t:1528139814840};\\\", \\\"{x:1608,y:702,t:1528139814856};\\\", \\\"{x:1609,y:701,t:1528139814874};\\\", \\\"{x:1601,y:712,t:1528139816290};\\\", \\\"{x:1576,y:748,t:1528139816297};\\\", \\\"{x:1551,y:784,t:1528139816309};\\\", \\\"{x:1494,y:868,t:1528139816325};\\\", \\\"{x:1442,y:931,t:1528139816342};\\\", \\\"{x:1410,y:967,t:1528139816359};\\\", \\\"{x:1397,y:983,t:1528139816376};\\\", \\\"{x:1393,y:988,t:1528139816392};\\\", \\\"{x:1393,y:986,t:1528139816513};\\\", \\\"{x:1393,y:983,t:1528139816525};\\\", \\\"{x:1396,y:973,t:1528139816542};\\\", \\\"{x:1400,y:961,t:1528139816560};\\\", \\\"{x:1405,y:947,t:1528139816576};\\\", \\\"{x:1411,y:931,t:1528139816591};\\\", \\\"{x:1420,y:910,t:1528139816608};\\\", \\\"{x:1425,y:901,t:1528139816625};\\\", \\\"{x:1431,y:891,t:1528139816642};\\\", \\\"{x:1436,y:881,t:1528139816658};\\\", \\\"{x:1441,y:876,t:1528139816676};\\\", \\\"{x:1444,y:869,t:1528139816692};\\\", \\\"{x:1446,y:864,t:1528139816708};\\\", \\\"{x:1448,y:857,t:1528139816725};\\\", \\\"{x:1449,y:853,t:1528139816741};\\\", \\\"{x:1450,y:850,t:1528139816759};\\\", \\\"{x:1450,y:847,t:1528139816775};\\\", \\\"{x:1451,y:843,t:1528139816792};\\\", \\\"{x:1452,y:836,t:1528139816809};\\\", \\\"{x:1452,y:834,t:1528139816825};\\\", \\\"{x:1453,y:833,t:1528139816842};\\\", \\\"{x:1453,y:832,t:1528139816865};\\\", \\\"{x:1454,y:831,t:1528139816881};\\\", \\\"{x:1455,y:831,t:1528139816892};\\\", \\\"{x:1457,y:829,t:1528139816909};\\\", \\\"{x:1459,y:828,t:1528139816926};\\\", \\\"{x:1462,y:825,t:1528139816942};\\\", \\\"{x:1465,y:825,t:1528139816959};\\\", \\\"{x:1466,y:824,t:1528139816976};\\\", \\\"{x:1467,y:824,t:1528139816993};\\\", \\\"{x:1469,y:823,t:1528139817041};\\\", \\\"{x:1470,y:823,t:1528139817130};\\\", \\\"{x:1471,y:822,t:1528139817146};\\\", \\\"{x:1472,y:822,t:1528139817186};\\\", \\\"{x:1473,y:822,t:1528139817193};\\\", \\\"{x:1474,y:822,t:1528139817208};\\\", \\\"{x:1475,y:822,t:1528139817273};\\\", \\\"{x:1476,y:822,t:1528139817328};\\\", \\\"{x:1477,y:821,t:1528139817361};\\\", \\\"{x:1478,y:820,t:1528139817385};\\\", \\\"{x:1479,y:820,t:1528139817392};\\\", \\\"{x:1481,y:819,t:1528139817408};\\\", \\\"{x:1483,y:819,t:1528139817426};\\\", \\\"{x:1484,y:818,t:1528139817449};\\\", \\\"{x:1483,y:819,t:1528139818145};\\\", \\\"{x:1482,y:820,t:1528139818160};\\\", \\\"{x:1481,y:820,t:1528139818176};\\\", \\\"{x:1481,y:821,t:1528139818193};\\\", \\\"{x:1480,y:821,t:1528139818234};\\\", \\\"{x:1479,y:821,t:1528139818249};\\\", \\\"{x:1477,y:822,t:1528139818410};\\\", \\\"{x:1477,y:823,t:1528139818427};\\\", \\\"{x:1476,y:823,t:1528139818457};\\\", \\\"{x:1476,y:824,t:1528139818545};\\\", \\\"{x:1476,y:825,t:1528139819154};\\\", \\\"{x:1474,y:826,t:1528139819161};\\\", \\\"{x:1447,y:818,t:1528139819178};\\\", \\\"{x:1358,y:790,t:1528139819194};\\\", \\\"{x:1214,y:751,t:1528139819211};\\\", \\\"{x:1037,y:702,t:1528139819228};\\\", \\\"{x:837,y:655,t:1528139819244};\\\", \\\"{x:612,y:609,t:1528139819262};\\\", \\\"{x:418,y:572,t:1528139819279};\\\", \\\"{x:245,y:538,t:1528139819294};\\\", \\\"{x:147,y:518,t:1528139819312};\\\", \\\"{x:115,y:510,t:1528139819328};\\\", \\\"{x:108,y:508,t:1528139819344};\\\", \\\"{x:107,y:508,t:1528139819360};\\\", \\\"{x:106,y:508,t:1528139819377};\\\", \\\"{x:105,y:508,t:1528139819394};\\\", \\\"{x:103,y:508,t:1528139819410};\\\", \\\"{x:96,y:508,t:1528139819427};\\\", \\\"{x:92,y:508,t:1528139819444};\\\", \\\"{x:87,y:510,t:1528139819461};\\\", \\\"{x:84,y:511,t:1528139819477};\\\", \\\"{x:83,y:513,t:1528139819494};\\\", \\\"{x:83,y:518,t:1528139819511};\\\", \\\"{x:83,y:524,t:1528139819527};\\\", \\\"{x:88,y:532,t:1528139819545};\\\", \\\"{x:99,y:541,t:1528139819562};\\\", \\\"{x:113,y:549,t:1528139819577};\\\", \\\"{x:128,y:557,t:1528139819595};\\\", \\\"{x:138,y:559,t:1528139819611};\\\", \\\"{x:152,y:564,t:1528139819628};\\\", \\\"{x:172,y:570,t:1528139819645};\\\", \\\"{x:193,y:573,t:1528139819662};\\\", \\\"{x:217,y:579,t:1528139819678};\\\", \\\"{x:244,y:579,t:1528139819695};\\\", \\\"{x:280,y:579,t:1528139819712};\\\", \\\"{x:322,y:579,t:1528139819728};\\\", \\\"{x:363,y:578,t:1528139819745};\\\", \\\"{x:373,y:573,t:1528139819762};\\\", \\\"{x:376,y:572,t:1528139819779};\\\", \\\"{x:377,y:571,t:1528139819865};\\\", \\\"{x:376,y:569,t:1528139819945};\\\", \\\"{x:363,y:568,t:1528139819963};\\\", \\\"{x:352,y:568,t:1528139819977};\\\", \\\"{x:342,y:568,t:1528139819994};\\\", \\\"{x:334,y:572,t:1528139820012};\\\", \\\"{x:331,y:575,t:1528139820028};\\\", \\\"{x:330,y:575,t:1528139820048};\\\", \\\"{x:330,y:577,t:1528139820072};\\\", \\\"{x:330,y:578,t:1528139820096};\\\", \\\"{x:332,y:578,t:1528139820112};\\\", \\\"{x:343,y:578,t:1528139820128};\\\", \\\"{x:352,y:573,t:1528139820145};\\\", \\\"{x:359,y:568,t:1528139820162};\\\", \\\"{x:363,y:564,t:1528139820178};\\\", \\\"{x:365,y:562,t:1528139820196};\\\", \\\"{x:365,y:561,t:1528139820233};\\\", \\\"{x:360,y:560,t:1528139820249};\\\", \\\"{x:350,y:560,t:1528139820262};\\\", \\\"{x:334,y:560,t:1528139820278};\\\", \\\"{x:311,y:563,t:1528139820295};\\\", \\\"{x:294,y:570,t:1528139820312};\\\", \\\"{x:268,y:585,t:1528139820329};\\\", \\\"{x:257,y:592,t:1528139820345};\\\", \\\"{x:248,y:601,t:1528139820362};\\\", \\\"{x:243,y:605,t:1528139820379};\\\", \\\"{x:240,y:608,t:1528139820396};\\\", \\\"{x:239,y:611,t:1528139820411};\\\", \\\"{x:235,y:614,t:1528139820429};\\\", \\\"{x:230,y:616,t:1528139820446};\\\", \\\"{x:223,y:619,t:1528139820463};\\\", \\\"{x:215,y:624,t:1528139820479};\\\", \\\"{x:202,y:628,t:1528139820495};\\\", \\\"{x:191,y:633,t:1528139820513};\\\", \\\"{x:179,y:633,t:1528139820528};\\\", \\\"{x:169,y:633,t:1528139820545};\\\", \\\"{x:157,y:631,t:1528139820563};\\\", \\\"{x:147,y:627,t:1528139820579};\\\", \\\"{x:136,y:621,t:1528139820596};\\\", \\\"{x:127,y:613,t:1528139820612};\\\", \\\"{x:122,y:608,t:1528139820629};\\\", \\\"{x:118,y:603,t:1528139820646};\\\", \\\"{x:116,y:599,t:1528139820662};\\\", \\\"{x:114,y:596,t:1528139820679};\\\", \\\"{x:114,y:595,t:1528139820696};\\\", \\\"{x:114,y:593,t:1528139820714};\\\", \\\"{x:115,y:590,t:1528139820729};\\\", \\\"{x:127,y:585,t:1528139820745};\\\", \\\"{x:144,y:578,t:1528139820762};\\\", \\\"{x:169,y:572,t:1528139820779};\\\", \\\"{x:208,y:559,t:1528139820796};\\\", \\\"{x:241,y:549,t:1528139820813};\\\", \\\"{x:278,y:542,t:1528139820829};\\\", \\\"{x:308,y:539,t:1528139820845};\\\", \\\"{x:333,y:535,t:1528139820863};\\\", \\\"{x:352,y:533,t:1528139820878};\\\", \\\"{x:368,y:530,t:1528139820895};\\\", \\\"{x:381,y:526,t:1528139820912};\\\", \\\"{x:383,y:525,t:1528139820929};\\\", \\\"{x:388,y:524,t:1528139820946};\\\", \\\"{x:392,y:523,t:1528139820962};\\\", \\\"{x:401,y:520,t:1528139820980};\\\", \\\"{x:411,y:518,t:1528139820996};\\\", \\\"{x:421,y:518,t:1528139821012};\\\", \\\"{x:432,y:518,t:1528139821030};\\\", \\\"{x:437,y:518,t:1528139821046};\\\", \\\"{x:440,y:518,t:1528139821063};\\\", \\\"{x:441,y:518,t:1528139821105};\\\", \\\"{x:443,y:518,t:1528139821209};\\\", \\\"{x:446,y:518,t:1528139821217};\\\", \\\"{x:450,y:518,t:1528139821230};\\\", \\\"{x:455,y:518,t:1528139821247};\\\", \\\"{x:459,y:518,t:1528139821263};\\\", \\\"{x:462,y:518,t:1528139821281};\\\", \\\"{x:463,y:520,t:1528139821297};\\\", \\\"{x:463,y:521,t:1528139821313};\\\", \\\"{x:464,y:524,t:1528139821330};\\\", \\\"{x:466,y:526,t:1528139821348};\\\", \\\"{x:472,y:530,t:1528139821363};\\\", \\\"{x:478,y:533,t:1528139821379};\\\", \\\"{x:496,y:535,t:1528139821395};\\\", \\\"{x:517,y:539,t:1528139821413};\\\", \\\"{x:538,y:542,t:1528139821430};\\\", \\\"{x:574,y:549,t:1528139821445};\\\", \\\"{x:634,y:553,t:1528139821463};\\\", \\\"{x:690,y:560,t:1528139821480};\\\", \\\"{x:743,y:568,t:1528139821496};\\\", \\\"{x:799,y:576,t:1528139821513};\\\", \\\"{x:825,y:579,t:1528139821529};\\\", \\\"{x:840,y:579,t:1528139821546};\\\", \\\"{x:846,y:579,t:1528139821563};\\\", \\\"{x:848,y:579,t:1528139821580};\\\", \\\"{x:850,y:579,t:1528139821600};\\\", \\\"{x:851,y:579,t:1528139821624};\\\", \\\"{x:851,y:578,t:1528139821769};\\\", \\\"{x:844,y:577,t:1528139821780};\\\", \\\"{x:818,y:574,t:1528139821798};\\\", \\\"{x:766,y:571,t:1528139821814};\\\", \\\"{x:705,y:571,t:1528139821832};\\\", \\\"{x:642,y:567,t:1528139821847};\\\", \\\"{x:586,y:567,t:1528139821863};\\\", \\\"{x:561,y:567,t:1528139821880};\\\", \\\"{x:549,y:567,t:1528139821896};\\\", \\\"{x:547,y:567,t:1528139821913};\\\", \\\"{x:547,y:568,t:1528139821952};\\\", \\\"{x:549,y:568,t:1528139822017};\\\", \\\"{x:550,y:568,t:1528139822030};\\\", \\\"{x:556,y:570,t:1528139822047};\\\", \\\"{x:568,y:572,t:1528139822064};\\\", \\\"{x:581,y:573,t:1528139822080};\\\", \\\"{x:602,y:575,t:1528139822098};\\\", \\\"{x:611,y:576,t:1528139822114};\\\", \\\"{x:615,y:576,t:1528139822130};\\\", \\\"{x:616,y:576,t:1528139822608};\\\", \\\"{x:621,y:579,t:1528139823257};\\\", \\\"{x:653,y:582,t:1528139823266};\\\", \\\"{x:748,y:599,t:1528139823281};\\\", \\\"{x:860,y:624,t:1528139823298};\\\", \\\"{x:988,y:662,t:1528139823314};\\\", \\\"{x:1117,y:694,t:1528139823331};\\\", \\\"{x:1228,y:725,t:1528139823348};\\\", \\\"{x:1309,y:751,t:1528139823365};\\\", \\\"{x:1361,y:770,t:1528139823381};\\\", \\\"{x:1389,y:790,t:1528139823397};\\\", \\\"{x:1414,y:805,t:1528139823415};\\\", \\\"{x:1433,y:820,t:1528139823430};\\\", \\\"{x:1452,y:834,t:1528139823447};\\\", \\\"{x:1482,y:857,t:1528139823464};\\\", \\\"{x:1507,y:871,t:1528139823481};\\\", \\\"{x:1523,y:882,t:1528139823497};\\\", \\\"{x:1536,y:890,t:1528139823514};\\\", \\\"{x:1538,y:891,t:1528139823531};\\\", \\\"{x:1538,y:892,t:1528139823548};\\\", \\\"{x:1538,y:893,t:1528139823576};\\\", \\\"{x:1537,y:894,t:1528139823593};\\\", \\\"{x:1535,y:896,t:1528139823601};\\\", \\\"{x:1531,y:896,t:1528139823615};\\\", \\\"{x:1521,y:896,t:1528139823631};\\\", \\\"{x:1509,y:896,t:1528139823648};\\\", \\\"{x:1486,y:893,t:1528139823665};\\\", \\\"{x:1475,y:887,t:1528139823683};\\\", \\\"{x:1468,y:884,t:1528139823698};\\\", \\\"{x:1454,y:877,t:1528139823715};\\\", \\\"{x:1439,y:868,t:1528139823732};\\\", \\\"{x:1426,y:860,t:1528139823748};\\\", \\\"{x:1407,y:850,t:1528139823765};\\\", \\\"{x:1382,y:837,t:1528139823782};\\\", \\\"{x:1349,y:823,t:1528139823798};\\\", \\\"{x:1303,y:808,t:1528139823815};\\\", \\\"{x:1262,y:792,t:1528139823833};\\\", \\\"{x:1225,y:779,t:1528139823848};\\\", \\\"{x:1184,y:770,t:1528139823865};\\\", \\\"{x:1162,y:767,t:1528139823882};\\\", \\\"{x:1134,y:762,t:1528139823898};\\\", \\\"{x:1116,y:760,t:1528139823915};\\\", \\\"{x:1102,y:760,t:1528139823932};\\\", \\\"{x:1096,y:760,t:1528139823949};\\\", \\\"{x:1093,y:760,t:1528139823965};\\\", \\\"{x:1093,y:762,t:1528139824017};\\\", \\\"{x:1096,y:766,t:1528139824033};\\\", \\\"{x:1114,y:773,t:1528139824049};\\\", \\\"{x:1130,y:781,t:1528139824065};\\\", \\\"{x:1152,y:788,t:1528139824082};\\\", \\\"{x:1185,y:799,t:1528139824099};\\\", \\\"{x:1219,y:803,t:1528139824115};\\\", \\\"{x:1255,y:808,t:1528139824131};\\\", \\\"{x:1280,y:809,t:1528139824148};\\\", \\\"{x:1289,y:811,t:1528139824164};\\\", \\\"{x:1291,y:811,t:1528139824182};\\\", \\\"{x:1291,y:808,t:1528139824200};\\\", \\\"{x:1291,y:804,t:1528139824215};\\\", \\\"{x:1291,y:799,t:1528139824232};\\\", \\\"{x:1283,y:784,t:1528139824248};\\\", \\\"{x:1271,y:775,t:1528139824265};\\\", \\\"{x:1255,y:765,t:1528139824282};\\\", \\\"{x:1240,y:757,t:1528139824298};\\\", \\\"{x:1229,y:754,t:1528139824315};\\\", \\\"{x:1224,y:752,t:1528139824332};\\\", \\\"{x:1223,y:752,t:1528139824348};\\\", \\\"{x:1224,y:752,t:1528139824401};\\\", \\\"{x:1229,y:752,t:1528139824416};\\\", \\\"{x:1245,y:752,t:1528139824432};\\\", \\\"{x:1281,y:752,t:1528139824449};\\\", \\\"{x:1308,y:752,t:1528139824465};\\\", \\\"{x:1346,y:752,t:1528139824482};\\\", \\\"{x:1380,y:752,t:1528139824500};\\\", \\\"{x:1414,y:752,t:1528139824517};\\\", \\\"{x:1439,y:752,t:1528139824532};\\\", \\\"{x:1458,y:752,t:1528139824549};\\\", \\\"{x:1463,y:752,t:1528139824566};\\\", \\\"{x:1464,y:752,t:1528139824582};\\\", \\\"{x:1459,y:752,t:1528139824674};\\\", \\\"{x:1454,y:752,t:1528139824682};\\\", \\\"{x:1441,y:752,t:1528139824699};\\\", \\\"{x:1429,y:752,t:1528139824716};\\\", \\\"{x:1422,y:752,t:1528139824732};\\\", \\\"{x:1415,y:753,t:1528139824750};\\\", \\\"{x:1411,y:753,t:1528139824766};\\\", \\\"{x:1408,y:753,t:1528139824782};\\\", \\\"{x:1407,y:753,t:1528139824799};\\\", \\\"{x:1405,y:753,t:1528139824833};\\\", \\\"{x:1401,y:753,t:1528139824849};\\\", \\\"{x:1395,y:750,t:1528139824866};\\\", \\\"{x:1392,y:746,t:1528139824882};\\\", \\\"{x:1387,y:741,t:1528139824900};\\\", \\\"{x:1379,y:733,t:1528139824916};\\\", \\\"{x:1373,y:726,t:1528139824932};\\\", \\\"{x:1366,y:719,t:1528139824950};\\\", \\\"{x:1361,y:713,t:1528139824966};\\\", \\\"{x:1360,y:710,t:1528139824982};\\\", \\\"{x:1358,y:708,t:1528139824999};\\\", \\\"{x:1357,y:708,t:1528139825016};\\\", \\\"{x:1357,y:706,t:1528139825033};\\\", \\\"{x:1356,y:706,t:1528139825050};\\\", \\\"{x:1355,y:706,t:1528139825066};\\\", \\\"{x:1353,y:705,t:1528139825084};\\\", \\\"{x:1352,y:705,t:1528139825099};\\\", \\\"{x:1351,y:705,t:1528139825117};\\\", \\\"{x:1349,y:703,t:1528139825134};\\\", \\\"{x:1346,y:703,t:1528139825150};\\\", \\\"{x:1341,y:703,t:1528139825166};\\\", \\\"{x:1337,y:702,t:1528139825184};\\\", \\\"{x:1334,y:702,t:1528139825199};\\\", \\\"{x:1333,y:701,t:1528139825225};\\\", \\\"{x:1334,y:699,t:1528139825298};\\\", \\\"{x:1335,y:699,t:1528139825305};\\\", \\\"{x:1335,y:698,t:1528139825317};\\\", \\\"{x:1335,y:697,t:1528139825353};\\\", \\\"{x:1336,y:696,t:1528139825367};\\\", \\\"{x:1337,y:696,t:1528139825689};\\\", \\\"{x:1338,y:696,t:1528139825701};\\\", \\\"{x:1341,y:695,t:1528139825717};\\\", \\\"{x:1342,y:695,t:1528139825748};\\\", \\\"{x:1343,y:695,t:1528139825985};\\\", \\\"{x:1344,y:695,t:1528139826001};\\\", \\\"{x:1344,y:697,t:1528139826017};\\\", \\\"{x:1344,y:699,t:1528139826033};\\\", \\\"{x:1346,y:701,t:1528139826050};\\\", \\\"{x:1346,y:702,t:1528139826067};\\\", \\\"{x:1346,y:704,t:1528139826085};\\\", \\\"{x:1348,y:704,t:1528139826457};\\\", \\\"{x:1349,y:703,t:1528139826481};\\\", \\\"{x:1349,y:701,t:1528139826490};\\\", \\\"{x:1350,y:701,t:1528139826500};\\\", \\\"{x:1351,y:699,t:1528139826517};\\\", \\\"{x:1351,y:698,t:1528139826553};\\\", \\\"{x:1351,y:697,t:1528139827273};\\\", \\\"{x:1350,y:697,t:1528139827385};\\\", \\\"{x:1347,y:697,t:1528139830530};\\\", \\\"{x:1341,y:697,t:1528139830538};\\\", \\\"{x:1333,y:697,t:1528139830554};\\\", \\\"{x:1320,y:697,t:1528139830571};\\\", \\\"{x:1302,y:694,t:1528139830589};\\\", \\\"{x:1266,y:689,t:1528139830605};\\\", \\\"{x:1191,y:679,t:1528139830621};\\\", \\\"{x:1098,y:663,t:1528139830637};\\\", \\\"{x:995,y:643,t:1528139830654};\\\", \\\"{x:899,y:620,t:1528139830671};\\\", \\\"{x:807,y:593,t:1528139830688};\\\", \\\"{x:743,y:567,t:1528139830703};\\\", \\\"{x:732,y:560,t:1528139830720};\\\", \\\"{x:730,y:559,t:1528139830737};\\\", \\\"{x:728,y:557,t:1528139830753};\\\", \\\"{x:728,y:556,t:1528139830776};\\\", \\\"{x:728,y:555,t:1528139830787};\\\", \\\"{x:727,y:554,t:1528139830804};\\\", \\\"{x:726,y:553,t:1528139830821};\\\", \\\"{x:726,y:551,t:1528139830837};\\\", \\\"{x:726,y:548,t:1528139830854};\\\", \\\"{x:734,y:542,t:1528139830871};\\\", \\\"{x:742,y:535,t:1528139830887};\\\", \\\"{x:757,y:524,t:1528139830905};\\\", \\\"{x:769,y:519,t:1528139830921};\\\", \\\"{x:772,y:518,t:1528139830937};\\\", \\\"{x:776,y:517,t:1528139830955};\\\", \\\"{x:777,y:516,t:1528139830971};\\\", \\\"{x:778,y:515,t:1528139830987};\\\", \\\"{x:781,y:514,t:1528139831008};\\\", \\\"{x:781,y:513,t:1528139831021};\\\", \\\"{x:785,y:511,t:1528139831037};\\\", \\\"{x:790,y:508,t:1528139831054};\\\", \\\"{x:793,y:507,t:1528139831071};\\\", \\\"{x:797,y:504,t:1528139831088};\\\", \\\"{x:798,y:504,t:1528139831128};\\\", \\\"{x:799,y:504,t:1528139831138};\\\", \\\"{x:802,y:503,t:1528139831154};\\\", \\\"{x:804,y:503,t:1528139831172};\\\", \\\"{x:806,y:502,t:1528139831188};\\\", \\\"{x:807,y:502,t:1528139831208};\\\", \\\"{x:808,y:502,t:1528139831232};\\\", \\\"{x:810,y:502,t:1528139831241};\\\", \\\"{x:811,y:501,t:1528139831254};\\\", \\\"{x:814,y:501,t:1528139831271};\\\", \\\"{x:816,y:501,t:1528139831288};\\\", \\\"{x:817,y:501,t:1528139831312};\\\", \\\"{x:819,y:501,t:1528139831329};\\\", \\\"{x:820,y:501,t:1528139831345};\\\", \\\"{x:822,y:500,t:1528139831368};\\\", \\\"{x:825,y:498,t:1528139831385};\\\", \\\"{x:826,y:498,t:1528139831466};\\\", \\\"{x:824,y:498,t:1528139832025};\\\", \\\"{x:821,y:499,t:1528139832038};\\\", \\\"{x:816,y:502,t:1528139832055};\\\", \\\"{x:809,y:507,t:1528139832072};\\\", \\\"{x:804,y:520,t:1528139832089};\\\", \\\"{x:799,y:537,t:1528139832106};\\\", \\\"{x:792,y:557,t:1528139832122};\\\", \\\"{x:781,y:578,t:1528139832138};\\\", \\\"{x:767,y:601,t:1528139832156};\\\", \\\"{x:739,y:635,t:1528139832172};\\\", \\\"{x:703,y:668,t:1528139832188};\\\", \\\"{x:664,y:704,t:1528139832205};\\\", \\\"{x:627,y:729,t:1528139832222};\\\", \\\"{x:608,y:746,t:1528139832238};\\\", \\\"{x:600,y:751,t:1528139832255};\\\", \\\"{x:592,y:759,t:1528139832272};\\\", \\\"{x:588,y:761,t:1528139832288};\\\", \\\"{x:583,y:763,t:1528139832305};\\\", \\\"{x:576,y:765,t:1528139832321};\\\", \\\"{x:567,y:766,t:1528139832338};\\\", \\\"{x:560,y:766,t:1528139832355};\\\", \\\"{x:554,y:766,t:1528139832372};\\\", \\\"{x:548,y:761,t:1528139832388};\\\", \\\"{x:545,y:756,t:1528139832405};\\\", \\\"{x:542,y:748,t:1528139832423};\\\", \\\"{x:538,y:738,t:1528139832439};\\\", \\\"{x:532,y:729,t:1528139832456};\\\", \\\"{x:528,y:722,t:1528139832472};\\\", \\\"{x:525,y:718,t:1528139832489};\\\", \\\"{x:524,y:717,t:1528139832506};\\\", \\\"{x:523,y:717,t:1528139832545};\\\", \\\"{x:522,y:717,t:1528139832560};\\\", \\\"{x:521,y:717,t:1528139832577};\\\", \\\"{x:520,y:717,t:1528139832593};\\\", \\\"{x:519,y:717,t:1528139832605};\\\", \\\"{x:519,y:718,t:1528139832841};\\\", \\\"{x:518,y:721,t:1528139832858};\\\", \\\"{x:518,y:724,t:1528139832872};\\\", \\\"{x:518,y:727,t:1528139832889};\\\", \\\"{x:518,y:728,t:1528139832906};\\\" ] }, { \\\"rt\\\": 45037, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 18, \\\"time_elapsed\\\": 672122, \\\"internal_node_id\\\": \\\"0.0-6.0-8.0\\\", \\\"subject\\\": \\\"S6D2F\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 14, \\\"clicks\\\": 1, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-05 PM-03 PM-03 PM-03 PM-O -O -O -O -03 PM-E -11 AM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:518,y:729,t:1528139835056};\\\", \\\"{x:517,y:729,t:1528139835337};\\\", \\\"{x:517,y:730,t:1528139835345};\\\", \\\"{x:518,y:730,t:1528139837593};\\\", \\\"{x:519,y:730,t:1528139837609};\\\", \\\"{x:523,y:730,t:1528139837626};\\\", \\\"{x:527,y:731,t:1528139837642};\\\", \\\"{x:536,y:732,t:1528139837659};\\\", \\\"{x:543,y:732,t:1528139837675};\\\", \\\"{x:551,y:732,t:1528139837692};\\\", \\\"{x:559,y:732,t:1528139837708};\\\", \\\"{x:566,y:732,t:1528139837727};\\\", \\\"{x:575,y:732,t:1528139837741};\\\", \\\"{x:584,y:732,t:1528139837758};\\\", \\\"{x:594,y:734,t:1528139837776};\\\", \\\"{x:613,y:734,t:1528139837793};\\\", \\\"{x:622,y:735,t:1528139837810};\\\", \\\"{x:632,y:736,t:1528139837826};\\\", \\\"{x:638,y:737,t:1528139837843};\\\", \\\"{x:643,y:739,t:1528139837860};\\\", \\\"{x:650,y:741,t:1528139837876};\\\", \\\"{x:658,y:743,t:1528139837893};\\\", \\\"{x:671,y:744,t:1528139837910};\\\", \\\"{x:679,y:747,t:1528139837926};\\\", \\\"{x:680,y:747,t:1528139837944};\\\", \\\"{x:682,y:748,t:1528139839216};\\\", \\\"{x:693,y:748,t:1528139839228};\\\", \\\"{x:729,y:752,t:1528139839246};\\\", \\\"{x:774,y:759,t:1528139839263};\\\", \\\"{x:840,y:764,t:1528139839278};\\\", \\\"{x:916,y:780,t:1528139839295};\\\", \\\"{x:1062,y:800,t:1528139839313};\\\", \\\"{x:1181,y:816,t:1528139839329};\\\", \\\"{x:1300,y:831,t:1528139839346};\\\", \\\"{x:1402,y:842,t:1528139839363};\\\", \\\"{x:1484,y:850,t:1528139839380};\\\", \\\"{x:1543,y:860,t:1528139839396};\\\", \\\"{x:1608,y:872,t:1528139839412};\\\", \\\"{x:1670,y:880,t:1528139839430};\\\", \\\"{x:1715,y:887,t:1528139839446};\\\", \\\"{x:1755,y:889,t:1528139839463};\\\", \\\"{x:1776,y:889,t:1528139839480};\\\", \\\"{x:1790,y:889,t:1528139839496};\\\", \\\"{x:1803,y:892,t:1528139839513};\\\", \\\"{x:1804,y:892,t:1528139839529};\\\", \\\"{x:1804,y:893,t:1528139839657};\\\", \\\"{x:1804,y:896,t:1528139839680};\\\", \\\"{x:1800,y:898,t:1528139839697};\\\", \\\"{x:1796,y:901,t:1528139839713};\\\", \\\"{x:1793,y:904,t:1528139839729};\\\", \\\"{x:1791,y:907,t:1528139839747};\\\", \\\"{x:1786,y:910,t:1528139839764};\\\", \\\"{x:1782,y:913,t:1528139839779};\\\", \\\"{x:1776,y:918,t:1528139839797};\\\", \\\"{x:1770,y:923,t:1528139839813};\\\", \\\"{x:1764,y:927,t:1528139839830};\\\", \\\"{x:1758,y:931,t:1528139839846};\\\", \\\"{x:1755,y:933,t:1528139839864};\\\", \\\"{x:1747,y:936,t:1528139839880};\\\", \\\"{x:1735,y:941,t:1528139839897};\\\", \\\"{x:1732,y:944,t:1528139839914};\\\", \\\"{x:1731,y:944,t:1528139839930};\\\", \\\"{x:1731,y:945,t:1528139839961};\\\", \\\"{x:1731,y:946,t:1528139840017};\\\", \\\"{x:1731,y:947,t:1528139840031};\\\", \\\"{x:1731,y:949,t:1528139840047};\\\", \\\"{x:1730,y:951,t:1528139840064};\\\", \\\"{x:1728,y:957,t:1528139840081};\\\", \\\"{x:1726,y:961,t:1528139840097};\\\", \\\"{x:1720,y:966,t:1528139840113};\\\", \\\"{x:1707,y:971,t:1528139840130};\\\", \\\"{x:1683,y:982,t:1528139840147};\\\", \\\"{x:1658,y:998,t:1528139840164};\\\", \\\"{x:1636,y:1011,t:1528139840181};\\\", \\\"{x:1622,y:1018,t:1528139840198};\\\", \\\"{x:1616,y:1020,t:1528139840213};\\\", \\\"{x:1614,y:1021,t:1528139840231};\\\", \\\"{x:1613,y:1021,t:1528139840247};\\\", \\\"{x:1612,y:1021,t:1528139840297};\\\", \\\"{x:1611,y:1021,t:1528139840320};\\\", \\\"{x:1609,y:1021,t:1528139840331};\\\", \\\"{x:1604,y:1020,t:1528139840348};\\\", \\\"{x:1596,y:1019,t:1528139840363};\\\", \\\"{x:1583,y:1016,t:1528139840381};\\\", \\\"{x:1573,y:1010,t:1528139840398};\\\", \\\"{x:1559,y:1005,t:1528139840414};\\\", \\\"{x:1552,y:1003,t:1528139840430};\\\", \\\"{x:1547,y:998,t:1528139840448};\\\", \\\"{x:1540,y:992,t:1528139840465};\\\", \\\"{x:1540,y:988,t:1528139840480};\\\", \\\"{x:1540,y:985,t:1528139840498};\\\", \\\"{x:1540,y:982,t:1528139840516};\\\", \\\"{x:1540,y:980,t:1528139840531};\\\", \\\"{x:1539,y:978,t:1528139840548};\\\", \\\"{x:1539,y:976,t:1528139840565};\\\", \\\"{x:1539,y:974,t:1528139840585};\\\", \\\"{x:1539,y:973,t:1528139840598};\\\", \\\"{x:1540,y:971,t:1528139840614};\\\", \\\"{x:1541,y:969,t:1528139840631};\\\", \\\"{x:1542,y:968,t:1528139840648};\\\", \\\"{x:1543,y:967,t:1528139840665};\\\", \\\"{x:1543,y:965,t:1528139841217};\\\", \\\"{x:1543,y:964,t:1528139841232};\\\", \\\"{x:1543,y:963,t:1528139841249};\\\", \\\"{x:1543,y:962,t:1528139841266};\\\", \\\"{x:1543,y:961,t:1528139841353};\\\", \\\"{x:1543,y:960,t:1528139841369};\\\", \\\"{x:1543,y:959,t:1528139841384};\\\", \\\"{x:1546,y:957,t:1528139841399};\\\", \\\"{x:1552,y:955,t:1528139841416};\\\", \\\"{x:1553,y:955,t:1528139841433};\\\", \\\"{x:1554,y:955,t:1528139841497};\\\", \\\"{x:1554,y:954,t:1528139841513};\\\", \\\"{x:1554,y:953,t:1528139841657};\\\", \\\"{x:1552,y:953,t:1528139841672};\\\", \\\"{x:1551,y:954,t:1528139841682};\\\", \\\"{x:1548,y:955,t:1528139841700};\\\", \\\"{x:1546,y:956,t:1528139841716};\\\", \\\"{x:1545,y:957,t:1528139842257};\\\", \\\"{x:1545,y:955,t:1528139842272};\\\", \\\"{x:1545,y:950,t:1528139842283};\\\", \\\"{x:1547,y:944,t:1528139842300};\\\", \\\"{x:1549,y:936,t:1528139842316};\\\", \\\"{x:1549,y:932,t:1528139842334};\\\", \\\"{x:1549,y:925,t:1528139842350};\\\", \\\"{x:1549,y:921,t:1528139842366};\\\", \\\"{x:1549,y:918,t:1528139842384};\\\", \\\"{x:1549,y:914,t:1528139842399};\\\", \\\"{x:1549,y:912,t:1528139842416};\\\", \\\"{x:1549,y:911,t:1528139842434};\\\", \\\"{x:1549,y:909,t:1528139842451};\\\", \\\"{x:1549,y:904,t:1528139842468};\\\", \\\"{x:1548,y:900,t:1528139842484};\\\", \\\"{x:1547,y:893,t:1528139842501};\\\", \\\"{x:1546,y:885,t:1528139842518};\\\", \\\"{x:1545,y:876,t:1528139842534};\\\", \\\"{x:1545,y:870,t:1528139842551};\\\", \\\"{x:1544,y:864,t:1528139842567};\\\", \\\"{x:1544,y:855,t:1528139842583};\\\", \\\"{x:1541,y:841,t:1528139842601};\\\", \\\"{x:1540,y:831,t:1528139842618};\\\", \\\"{x:1540,y:817,t:1528139842634};\\\", \\\"{x:1540,y:806,t:1528139842650};\\\", \\\"{x:1540,y:792,t:1528139842668};\\\", \\\"{x:1542,y:783,t:1528139842685};\\\", \\\"{x:1543,y:776,t:1528139842701};\\\", \\\"{x:1544,y:770,t:1528139842718};\\\", \\\"{x:1544,y:765,t:1528139842735};\\\", \\\"{x:1544,y:758,t:1528139842751};\\\", \\\"{x:1544,y:750,t:1528139842768};\\\", \\\"{x:1544,y:741,t:1528139842785};\\\", \\\"{x:1543,y:736,t:1528139842800};\\\", \\\"{x:1543,y:730,t:1528139842818};\\\", \\\"{x:1543,y:727,t:1528139842835};\\\", \\\"{x:1543,y:725,t:1528139842851};\\\", \\\"{x:1543,y:721,t:1528139842868};\\\", \\\"{x:1543,y:718,t:1528139842885};\\\", \\\"{x:1543,y:715,t:1528139842902};\\\", \\\"{x:1543,y:711,t:1528139842918};\\\", \\\"{x:1544,y:706,t:1528139842934};\\\", \\\"{x:1545,y:701,t:1528139842951};\\\", \\\"{x:1546,y:698,t:1528139842967};\\\", \\\"{x:1546,y:695,t:1528139842985};\\\", \\\"{x:1546,y:694,t:1528139843001};\\\", \\\"{x:1546,y:693,t:1528139843017};\\\", \\\"{x:1546,y:691,t:1528139843034};\\\", \\\"{x:1546,y:687,t:1528139843052};\\\", \\\"{x:1546,y:683,t:1528139843067};\\\", \\\"{x:1549,y:678,t:1528139843085};\\\", \\\"{x:1550,y:674,t:1528139843101};\\\", \\\"{x:1550,y:670,t:1528139843118};\\\", \\\"{x:1552,y:669,t:1528139843135};\\\", \\\"{x:1552,y:667,t:1528139843152};\\\", \\\"{x:1553,y:663,t:1528139843168};\\\", \\\"{x:1556,y:657,t:1528139843185};\\\", \\\"{x:1557,y:650,t:1528139843202};\\\", \\\"{x:1557,y:642,t:1528139843219};\\\", \\\"{x:1557,y:632,t:1528139843235};\\\", \\\"{x:1557,y:619,t:1528139843252};\\\", \\\"{x:1557,y:615,t:1528139843269};\\\", \\\"{x:1557,y:612,t:1528139843285};\\\", \\\"{x:1557,y:611,t:1528139843302};\\\", \\\"{x:1557,y:610,t:1528139843318};\\\", \\\"{x:1557,y:609,t:1528139843489};\\\", \\\"{x:1557,y:608,t:1528139843505};\\\", \\\"{x:1557,y:607,t:1528139843519};\\\", \\\"{x:1557,y:602,t:1528139843536};\\\", \\\"{x:1557,y:600,t:1528139843552};\\\", \\\"{x:1555,y:597,t:1528139843569};\\\", \\\"{x:1555,y:596,t:1528139843592};\\\", \\\"{x:1555,y:595,t:1528139843609};\\\", \\\"{x:1554,y:595,t:1528139843665};\\\", \\\"{x:1554,y:594,t:1528139843705};\\\", \\\"{x:1552,y:594,t:1528139843753};\\\", \\\"{x:1550,y:593,t:1528139843770};\\\", \\\"{x:1550,y:592,t:1528139843793};\\\", \\\"{x:1549,y:592,t:1528139843921};\\\", \\\"{x:1548,y:591,t:1528139843936};\\\", \\\"{x:1548,y:587,t:1528139843953};\\\", \\\"{x:1548,y:585,t:1528139843970};\\\", \\\"{x:1548,y:583,t:1528139843986};\\\", \\\"{x:1548,y:582,t:1528139844003};\\\", \\\"{x:1548,y:579,t:1528139844020};\\\", \\\"{x:1547,y:578,t:1528139844036};\\\", \\\"{x:1547,y:577,t:1528139844336};\\\", \\\"{x:1546,y:577,t:1528139844359};\\\", \\\"{x:1545,y:577,t:1528139844448};\\\", \\\"{x:1544,y:577,t:1528139844455};\\\", \\\"{x:1544,y:579,t:1528139844470};\\\", \\\"{x:1542,y:589,t:1528139844486};\\\", \\\"{x:1542,y:595,t:1528139844504};\\\", \\\"{x:1540,y:600,t:1528139844519};\\\", \\\"{x:1540,y:604,t:1528139844537};\\\", \\\"{x:1540,y:607,t:1528139844553};\\\", \\\"{x:1540,y:611,t:1528139844570};\\\", \\\"{x:1540,y:618,t:1528139844587};\\\", \\\"{x:1540,y:633,t:1528139844603};\\\", \\\"{x:1540,y:649,t:1528139844620};\\\", \\\"{x:1540,y:668,t:1528139844636};\\\", \\\"{x:1542,y:686,t:1528139844654};\\\", \\\"{x:1548,y:707,t:1528139844671};\\\", \\\"{x:1552,y:726,t:1528139844687};\\\", \\\"{x:1555,y:741,t:1528139844703};\\\", \\\"{x:1563,y:767,t:1528139844720};\\\", \\\"{x:1567,y:781,t:1528139844738};\\\", \\\"{x:1571,y:796,t:1528139844754};\\\", \\\"{x:1573,y:804,t:1528139844771};\\\", \\\"{x:1574,y:811,t:1528139844788};\\\", \\\"{x:1575,y:820,t:1528139844804};\\\", \\\"{x:1576,y:828,t:1528139844821};\\\", \\\"{x:1576,y:839,t:1528139844838};\\\", \\\"{x:1576,y:851,t:1528139844854};\\\", \\\"{x:1574,y:870,t:1528139844871};\\\", \\\"{x:1571,y:891,t:1528139844888};\\\", \\\"{x:1564,y:929,t:1528139844904};\\\", \\\"{x:1562,y:951,t:1528139844920};\\\", \\\"{x:1557,y:973,t:1528139844938};\\\", \\\"{x:1554,y:994,t:1528139844955};\\\", \\\"{x:1553,y:1013,t:1528139844971};\\\", \\\"{x:1553,y:1026,t:1528139844988};\\\", \\\"{x:1553,y:1035,t:1528139845005};\\\", \\\"{x:1553,y:1037,t:1528139845021};\\\", \\\"{x:1553,y:1031,t:1528139845200};\\\", \\\"{x:1553,y:1025,t:1528139845209};\\\", \\\"{x:1553,y:1018,t:1528139845222};\\\", \\\"{x:1553,y:999,t:1528139845238};\\\", \\\"{x:1553,y:983,t:1528139845255};\\\", \\\"{x:1551,y:969,t:1528139845272};\\\", \\\"{x:1549,y:965,t:1528139845288};\\\", \\\"{x:1549,y:963,t:1528139845305};\\\", \\\"{x:1548,y:963,t:1528139846241};\\\", \\\"{x:1547,y:963,t:1528139846257};\\\", \\\"{x:1546,y:963,t:1528139846273};\\\", \\\"{x:1546,y:964,t:1528139853073};\\\", \\\"{x:1547,y:965,t:1528139853729};\\\", \\\"{x:1548,y:965,t:1528139853761};\\\", \\\"{x:1533,y:965,t:1528139854105};\\\", \\\"{x:1463,y:960,t:1528139854119};\\\", \\\"{x:1273,y:912,t:1528139854136};\\\", \\\"{x:1016,y:844,t:1528139854152};\\\", \\\"{x:579,y:730,t:1528139854168};\\\", \\\"{x:338,y:647,t:1528139854187};\\\", \\\"{x:170,y:576,t:1528139854203};\\\", \\\"{x:85,y:528,t:1528139854218};\\\", \\\"{x:64,y:497,t:1528139854240};\\\", \\\"{x:64,y:489,t:1528139854256};\\\", \\\"{x:64,y:478,t:1528139854274};\\\", \\\"{x:70,y:466,t:1528139854289};\\\", \\\"{x:75,y:452,t:1528139854307};\\\", \\\"{x:86,y:433,t:1528139854324};\\\", \\\"{x:96,y:418,t:1528139854339};\\\", \\\"{x:109,y:407,t:1528139854357};\\\", \\\"{x:122,y:402,t:1528139854373};\\\", \\\"{x:159,y:395,t:1528139854391};\\\", \\\"{x:221,y:392,t:1528139854407};\\\", \\\"{x:327,y:400,t:1528139854424};\\\", \\\"{x:405,y:411,t:1528139854441};\\\", \\\"{x:486,y:428,t:1528139854456};\\\", \\\"{x:549,y:441,t:1528139854474};\\\", \\\"{x:591,y:459,t:1528139854490};\\\", \\\"{x:613,y:468,t:1528139854507};\\\", \\\"{x:622,y:476,t:1528139854524};\\\", \\\"{x:623,y:479,t:1528139854540};\\\", \\\"{x:623,y:484,t:1528139854557};\\\", \\\"{x:622,y:492,t:1528139854574};\\\", \\\"{x:618,y:502,t:1528139854591};\\\", \\\"{x:606,y:514,t:1528139854607};\\\", \\\"{x:562,y:531,t:1528139854624};\\\", \\\"{x:496,y:549,t:1528139854642};\\\", \\\"{x:411,y:554,t:1528139854657};\\\", \\\"{x:322,y:554,t:1528139854674};\\\", \\\"{x:242,y:554,t:1528139854691};\\\", \\\"{x:183,y:554,t:1528139854706};\\\", \\\"{x:154,y:554,t:1528139854723};\\\", \\\"{x:136,y:554,t:1528139854741};\\\", \\\"{x:134,y:555,t:1528139854756};\\\", \\\"{x:135,y:555,t:1528139854944};\\\", \\\"{x:137,y:555,t:1528139854959};\\\", \\\"{x:143,y:554,t:1528139854974};\\\", \\\"{x:147,y:552,t:1528139854991};\\\", \\\"{x:151,y:551,t:1528139855009};\\\", \\\"{x:152,y:551,t:1528139855104};\\\", \\\"{x:153,y:550,t:1528139855184};\\\", \\\"{x:154,y:550,t:1528139855576};\\\", \\\"{x:185,y:555,t:1528139855591};\\\", \\\"{x:438,y:610,t:1528139855608};\\\", \\\"{x:668,y:655,t:1528139855626};\\\", \\\"{x:936,y:701,t:1528139855641};\\\", \\\"{x:1199,y:739,t:1528139855657};\\\", \\\"{x:1426,y:776,t:1528139855675};\\\", \\\"{x:1583,y:798,t:1528139855691};\\\", \\\"{x:1689,y:814,t:1528139855708};\\\", \\\"{x:1722,y:819,t:1528139855725};\\\", \\\"{x:1729,y:819,t:1528139855741};\\\", \\\"{x:1727,y:819,t:1528139855880};\\\", \\\"{x:1721,y:818,t:1528139855892};\\\", \\\"{x:1704,y:813,t:1528139855909};\\\", \\\"{x:1679,y:809,t:1528139855925};\\\", \\\"{x:1654,y:804,t:1528139855942};\\\", \\\"{x:1623,y:798,t:1528139855958};\\\", \\\"{x:1584,y:794,t:1528139855975};\\\", \\\"{x:1527,y:787,t:1528139855992};\\\", \\\"{x:1504,y:784,t:1528139856008};\\\", \\\"{x:1493,y:784,t:1528139856025};\\\", \\\"{x:1487,y:784,t:1528139856042};\\\", \\\"{x:1486,y:784,t:1528139856058};\\\", \\\"{x:1484,y:785,t:1528139856075};\\\", \\\"{x:1479,y:785,t:1528139856092};\\\", \\\"{x:1466,y:786,t:1528139856110};\\\", \\\"{x:1447,y:789,t:1528139856125};\\\", \\\"{x:1411,y:789,t:1528139856142};\\\", \\\"{x:1369,y:791,t:1528139856159};\\\", \\\"{x:1324,y:791,t:1528139856175};\\\", \\\"{x:1294,y:791,t:1528139856192};\\\", \\\"{x:1290,y:791,t:1528139856209};\\\", \\\"{x:1289,y:791,t:1528139856225};\\\", \\\"{x:1291,y:791,t:1528139856280};\\\", \\\"{x:1295,y:791,t:1528139856292};\\\", \\\"{x:1309,y:791,t:1528139856309};\\\", \\\"{x:1331,y:790,t:1528139856325};\\\", \\\"{x:1354,y:786,t:1528139856342};\\\", \\\"{x:1378,y:781,t:1528139856359};\\\", \\\"{x:1394,y:773,t:1528139856376};\\\", \\\"{x:1412,y:766,t:1528139856392};\\\", \\\"{x:1418,y:763,t:1528139856410};\\\", \\\"{x:1418,y:762,t:1528139856426};\\\", \\\"{x:1418,y:760,t:1528139856489};\\\", \\\"{x:1414,y:760,t:1528139856496};\\\", \\\"{x:1404,y:758,t:1528139856509};\\\", \\\"{x:1384,y:755,t:1528139856526};\\\", \\\"{x:1369,y:752,t:1528139856543};\\\", \\\"{x:1351,y:749,t:1528139856560};\\\", \\\"{x:1342,y:747,t:1528139856576};\\\", \\\"{x:1341,y:747,t:1528139856600};\\\", \\\"{x:1339,y:747,t:1528139856616};\\\", \\\"{x:1338,y:747,t:1528139856640};\\\", \\\"{x:1337,y:748,t:1528139856648};\\\", \\\"{x:1336,y:749,t:1528139856672};\\\", \\\"{x:1336,y:751,t:1528139856752};\\\", \\\"{x:1338,y:754,t:1528139856760};\\\", \\\"{x:1355,y:762,t:1528139856777};\\\", \\\"{x:1382,y:771,t:1528139856793};\\\", \\\"{x:1427,y:789,t:1528139856810};\\\", \\\"{x:1478,y:796,t:1528139856826};\\\", \\\"{x:1523,y:804,t:1528139856843};\\\", \\\"{x:1564,y:808,t:1528139856860};\\\", \\\"{x:1592,y:811,t:1528139856876};\\\", \\\"{x:1608,y:811,t:1528139856892};\\\", \\\"{x:1612,y:811,t:1528139856910};\\\", \\\"{x:1606,y:809,t:1528139857009};\\\", \\\"{x:1585,y:799,t:1528139857026};\\\", \\\"{x:1563,y:794,t:1528139857044};\\\", \\\"{x:1535,y:789,t:1528139857059};\\\", \\\"{x:1514,y:787,t:1528139857077};\\\", \\\"{x:1503,y:785,t:1528139857093};\\\", \\\"{x:1499,y:784,t:1528139857109};\\\", \\\"{x:1498,y:784,t:1528139857169};\\\", \\\"{x:1499,y:784,t:1528139857312};\\\", \\\"{x:1501,y:784,t:1528139857326};\\\", \\\"{x:1504,y:783,t:1528139857344};\\\", \\\"{x:1513,y:782,t:1528139857360};\\\", \\\"{x:1515,y:781,t:1528139857377};\\\", \\\"{x:1516,y:780,t:1528139857393};\\\", \\\"{x:1517,y:779,t:1528139857410};\\\", \\\"{x:1520,y:774,t:1528139857427};\\\", \\\"{x:1522,y:771,t:1528139857444};\\\", \\\"{x:1524,y:769,t:1528139857460};\\\", \\\"{x:1526,y:767,t:1528139857476};\\\", \\\"{x:1521,y:766,t:1528139857600};\\\", \\\"{x:1513,y:766,t:1528139857613};\\\", \\\"{x:1500,y:766,t:1528139857626};\\\", \\\"{x:1479,y:766,t:1528139857643};\\\", \\\"{x:1466,y:766,t:1528139857660};\\\", \\\"{x:1465,y:766,t:1528139857677};\\\", \\\"{x:1468,y:765,t:1528139857752};\\\", \\\"{x:1474,y:765,t:1528139857760};\\\", \\\"{x:1489,y:766,t:1528139857777};\\\", \\\"{x:1510,y:769,t:1528139857793};\\\", \\\"{x:1529,y:770,t:1528139857810};\\\", \\\"{x:1545,y:773,t:1528139857827};\\\", \\\"{x:1551,y:774,t:1528139857843};\\\", \\\"{x:1552,y:774,t:1528139857860};\\\", \\\"{x:1554,y:774,t:1528139857968};\\\", \\\"{x:1555,y:774,t:1528139857977};\\\", \\\"{x:1557,y:772,t:1528139857993};\\\", \\\"{x:1559,y:768,t:1528139858010};\\\", \\\"{x:1561,y:765,t:1528139858027};\\\", \\\"{x:1563,y:763,t:1528139858044};\\\", \\\"{x:1563,y:762,t:1528139858061};\\\", \\\"{x:1564,y:761,t:1528139858078};\\\", \\\"{x:1564,y:760,t:1528139858185};\\\", \\\"{x:1564,y:759,t:1528139858194};\\\", \\\"{x:1558,y:759,t:1528139858211};\\\", \\\"{x:1550,y:758,t:1528139858228};\\\", \\\"{x:1543,y:756,t:1528139858245};\\\", \\\"{x:1535,y:754,t:1528139858260};\\\", \\\"{x:1526,y:749,t:1528139858278};\\\", \\\"{x:1516,y:744,t:1528139858294};\\\", \\\"{x:1501,y:736,t:1528139858310};\\\", \\\"{x:1487,y:730,t:1528139858327};\\\", \\\"{x:1465,y:726,t:1528139858344};\\\", \\\"{x:1457,y:725,t:1528139858360};\\\", \\\"{x:1452,y:723,t:1528139858377};\\\", \\\"{x:1451,y:723,t:1528139858448};\\\", \\\"{x:1451,y:722,t:1528139858488};\\\", \\\"{x:1450,y:722,t:1528139858504};\\\", \\\"{x:1448,y:720,t:1528139858537};\\\", \\\"{x:1448,y:719,t:1528139858568};\\\", \\\"{x:1447,y:718,t:1528139858593};\\\", \\\"{x:1446,y:717,t:1528139858608};\\\", \\\"{x:1445,y:717,t:1528139858632};\\\", \\\"{x:1444,y:717,t:1528139858645};\\\", \\\"{x:1443,y:717,t:1528139860056};\\\", \\\"{x:1442,y:716,t:1528139860065};\\\", \\\"{x:1440,y:716,t:1528139860080};\\\", \\\"{x:1439,y:716,t:1528139860096};\\\", \\\"{x:1437,y:714,t:1528139860112};\\\", \\\"{x:1436,y:714,t:1528139860129};\\\", \\\"{x:1435,y:713,t:1528139860145};\\\", \\\"{x:1435,y:712,t:1528139860162};\\\", \\\"{x:1434,y:711,t:1528139860193};\\\", \\\"{x:1434,y:709,t:1528139860208};\\\", \\\"{x:1433,y:709,t:1528139860224};\\\", \\\"{x:1432,y:708,t:1528139860232};\\\", \\\"{x:1431,y:708,t:1528139860248};\\\", \\\"{x:1431,y:707,t:1528139860263};\\\", \\\"{x:1431,y:710,t:1528139860401};\\\", \\\"{x:1434,y:711,t:1528139860413};\\\", \\\"{x:1443,y:716,t:1528139860430};\\\", \\\"{x:1459,y:722,t:1528139860445};\\\", \\\"{x:1477,y:730,t:1528139860463};\\\", \\\"{x:1494,y:737,t:1528139860480};\\\", \\\"{x:1512,y:748,t:1528139860496};\\\", \\\"{x:1516,y:751,t:1528139860512};\\\", \\\"{x:1517,y:755,t:1528139860529};\\\", \\\"{x:1518,y:758,t:1528139860547};\\\", \\\"{x:1519,y:762,t:1528139860563};\\\", \\\"{x:1522,y:768,t:1528139860581};\\\", \\\"{x:1524,y:774,t:1528139860597};\\\", \\\"{x:1526,y:778,t:1528139860613};\\\", \\\"{x:1526,y:781,t:1528139860629};\\\", \\\"{x:1526,y:782,t:1528139860665};\\\", \\\"{x:1527,y:783,t:1528139860680};\\\", \\\"{x:1531,y:794,t:1528139860697};\\\", \\\"{x:1535,y:807,t:1528139860713};\\\", \\\"{x:1540,y:823,t:1528139860729};\\\", \\\"{x:1546,y:835,t:1528139860747};\\\", \\\"{x:1551,y:848,t:1528139860762};\\\", \\\"{x:1556,y:860,t:1528139860780};\\\", \\\"{x:1560,y:872,t:1528139860797};\\\", \\\"{x:1560,y:882,t:1528139860813};\\\", \\\"{x:1552,y:894,t:1528139860830};\\\", \\\"{x:1548,y:898,t:1528139860846};\\\", \\\"{x:1546,y:899,t:1528139860865};\\\", \\\"{x:1545,y:901,t:1528139860879};\\\", \\\"{x:1543,y:907,t:1528139860897};\\\", \\\"{x:1543,y:909,t:1528139860913};\\\", \\\"{x:1548,y:913,t:1528139860930};\\\", \\\"{x:1552,y:915,t:1528139860946};\\\", \\\"{x:1553,y:915,t:1528139861057};\\\", \\\"{x:1553,y:916,t:1528139861073};\\\", \\\"{x:1553,y:918,t:1528139861088};\\\", \\\"{x:1553,y:920,t:1528139861097};\\\", \\\"{x:1553,y:924,t:1528139861113};\\\", \\\"{x:1553,y:931,t:1528139861129};\\\", \\\"{x:1553,y:940,t:1528139861146};\\\", \\\"{x:1553,y:951,t:1528139861164};\\\", \\\"{x:1553,y:958,t:1528139861179};\\\", \\\"{x:1553,y:966,t:1528139861197};\\\", \\\"{x:1551,y:970,t:1528139861214};\\\", \\\"{x:1551,y:973,t:1528139861229};\\\", \\\"{x:1550,y:974,t:1528139861246};\\\", \\\"{x:1549,y:977,t:1528139861263};\\\", \\\"{x:1549,y:978,t:1528139861280};\\\", \\\"{x:1549,y:977,t:1528139861400};\\\", \\\"{x:1549,y:975,t:1528139861414};\\\", \\\"{x:1545,y:967,t:1528139861430};\\\", \\\"{x:1542,y:959,t:1528139861446};\\\", \\\"{x:1538,y:950,t:1528139861464};\\\", \\\"{x:1530,y:934,t:1528139861480};\\\", \\\"{x:1528,y:927,t:1528139861497};\\\", \\\"{x:1526,y:921,t:1528139861513};\\\", \\\"{x:1526,y:916,t:1528139861530};\\\", \\\"{x:1525,y:913,t:1528139861547};\\\", \\\"{x:1525,y:912,t:1528139861563};\\\", \\\"{x:1525,y:911,t:1528139861581};\\\", \\\"{x:1524,y:908,t:1528139861597};\\\", \\\"{x:1524,y:906,t:1528139861614};\\\", \\\"{x:1524,y:905,t:1528139861631};\\\", \\\"{x:1524,y:903,t:1528139861646};\\\", \\\"{x:1524,y:902,t:1528139861664};\\\", \\\"{x:1524,y:896,t:1528139861681};\\\", \\\"{x:1524,y:894,t:1528139861698};\\\", \\\"{x:1524,y:893,t:1528139861714};\\\", \\\"{x:1524,y:892,t:1528139861731};\\\", \\\"{x:1524,y:891,t:1528139861748};\\\", \\\"{x:1524,y:890,t:1528139861776};\\\", \\\"{x:1525,y:889,t:1528139861857};\\\", \\\"{x:1526,y:889,t:1528139861872};\\\", \\\"{x:1527,y:888,t:1528139861880};\\\", \\\"{x:1528,y:888,t:1528139861905};\\\", \\\"{x:1529,y:888,t:1528139861944};\\\", \\\"{x:1531,y:890,t:1528139861953};\\\", \\\"{x:1531,y:891,t:1528139861963};\\\", \\\"{x:1535,y:901,t:1528139861981};\\\", \\\"{x:1540,y:911,t:1528139861998};\\\", \\\"{x:1541,y:915,t:1528139862013};\\\", \\\"{x:1544,y:920,t:1528139862030};\\\", \\\"{x:1544,y:921,t:1528139862057};\\\", \\\"{x:1544,y:922,t:1528139862064};\\\", \\\"{x:1544,y:923,t:1528139862081};\\\", \\\"{x:1544,y:924,t:1528139862098};\\\", \\\"{x:1547,y:923,t:1528139862336};\\\", \\\"{x:1547,y:921,t:1528139862347};\\\", \\\"{x:1548,y:914,t:1528139862365};\\\", \\\"{x:1552,y:905,t:1528139862381};\\\", \\\"{x:1553,y:898,t:1528139862398};\\\", \\\"{x:1553,y:893,t:1528139862414};\\\", \\\"{x:1553,y:887,t:1528139862430};\\\", \\\"{x:1553,y:883,t:1528139862447};\\\", \\\"{x:1553,y:876,t:1528139862465};\\\", \\\"{x:1553,y:872,t:1528139862482};\\\", \\\"{x:1553,y:868,t:1528139862498};\\\", \\\"{x:1553,y:865,t:1528139862515};\\\", \\\"{x:1553,y:864,t:1528139862532};\\\", \\\"{x:1552,y:861,t:1528139862548};\\\", \\\"{x:1552,y:859,t:1528139862567};\\\", \\\"{x:1552,y:856,t:1528139862581};\\\", \\\"{x:1549,y:852,t:1528139862597};\\\", \\\"{x:1546,y:846,t:1528139862614};\\\", \\\"{x:1542,y:839,t:1528139862631};\\\", \\\"{x:1533,y:828,t:1528139862647};\\\", \\\"{x:1530,y:821,t:1528139862664};\\\", \\\"{x:1527,y:813,t:1528139862681};\\\", \\\"{x:1525,y:806,t:1528139862697};\\\", \\\"{x:1522,y:801,t:1528139862714};\\\", \\\"{x:1522,y:797,t:1528139862731};\\\", \\\"{x:1523,y:793,t:1528139862747};\\\", \\\"{x:1525,y:788,t:1528139862765};\\\", \\\"{x:1528,y:782,t:1528139862781};\\\", \\\"{x:1530,y:776,t:1528139862797};\\\", \\\"{x:1532,y:769,t:1528139862815};\\\", \\\"{x:1532,y:763,t:1528139862831};\\\", \\\"{x:1535,y:755,t:1528139862848};\\\", \\\"{x:1536,y:739,t:1528139862864};\\\", \\\"{x:1537,y:729,t:1528139862881};\\\", \\\"{x:1537,y:722,t:1528139862898};\\\", \\\"{x:1537,y:717,t:1528139862914};\\\", \\\"{x:1537,y:710,t:1528139862932};\\\", \\\"{x:1537,y:702,t:1528139862948};\\\", \\\"{x:1537,y:696,t:1528139862964};\\\", \\\"{x:1537,y:690,t:1528139862981};\\\", \\\"{x:1537,y:684,t:1528139862998};\\\", \\\"{x:1537,y:678,t:1528139863014};\\\", \\\"{x:1535,y:671,t:1528139863031};\\\", \\\"{x:1531,y:660,t:1528139863048};\\\", \\\"{x:1529,y:657,t:1528139863064};\\\", \\\"{x:1529,y:653,t:1528139863081};\\\", \\\"{x:1529,y:651,t:1528139863098};\\\", \\\"{x:1528,y:647,t:1528139863115};\\\", \\\"{x:1527,y:647,t:1528139863131};\\\", \\\"{x:1527,y:646,t:1528139863151};\\\", \\\"{x:1527,y:645,t:1528139863176};\\\", \\\"{x:1527,y:644,t:1528139863641};\\\", \\\"{x:1528,y:641,t:1528139863649};\\\", \\\"{x:1528,y:639,t:1528139863665};\\\", \\\"{x:1531,y:635,t:1528139863681};\\\", \\\"{x:1532,y:633,t:1528139863699};\\\", \\\"{x:1533,y:632,t:1528139863744};\\\", \\\"{x:1533,y:631,t:1528139863768};\\\", \\\"{x:1531,y:631,t:1528139864769};\\\", \\\"{x:1529,y:633,t:1528139864783};\\\", \\\"{x:1523,y:635,t:1528139864800};\\\", \\\"{x:1519,y:636,t:1528139864816};\\\", \\\"{x:1515,y:637,t:1528139864833};\\\", \\\"{x:1512,y:638,t:1528139864849};\\\", \\\"{x:1509,y:638,t:1528139864867};\\\", \\\"{x:1508,y:638,t:1528139864883};\\\", \\\"{x:1507,y:640,t:1528139864900};\\\", \\\"{x:1506,y:640,t:1528139865009};\\\", \\\"{x:1505,y:640,t:1528139865065};\\\", \\\"{x:1502,y:640,t:1528139865072};\\\", \\\"{x:1497,y:640,t:1528139865083};\\\", \\\"{x:1479,y:640,t:1528139865100};\\\", \\\"{x:1460,y:640,t:1528139865116};\\\", \\\"{x:1438,y:640,t:1528139865133};\\\", \\\"{x:1418,y:640,t:1528139865150};\\\", \\\"{x:1408,y:640,t:1528139865166};\\\", \\\"{x:1405,y:640,t:1528139865183};\\\", \\\"{x:1404,y:640,t:1528139865569};\\\", \\\"{x:1396,y:644,t:1528139865584};\\\", \\\"{x:1388,y:647,t:1528139865600};\\\", \\\"{x:1371,y:651,t:1528139865616};\\\", \\\"{x:1353,y:654,t:1528139865634};\\\", \\\"{x:1340,y:656,t:1528139865650};\\\", \\\"{x:1332,y:660,t:1528139865666};\\\", \\\"{x:1328,y:661,t:1528139865683};\\\", \\\"{x:1325,y:663,t:1528139865701};\\\", \\\"{x:1324,y:665,t:1528139865720};\\\", \\\"{x:1324,y:666,t:1528139865736};\\\", \\\"{x:1324,y:668,t:1528139865760};\\\", \\\"{x:1324,y:669,t:1528139865785};\\\", \\\"{x:1324,y:670,t:1528139865800};\\\", \\\"{x:1324,y:671,t:1528139865818};\\\", \\\"{x:1327,y:671,t:1528139865834};\\\", \\\"{x:1334,y:674,t:1528139865850};\\\", \\\"{x:1345,y:675,t:1528139865868};\\\", \\\"{x:1354,y:677,t:1528139865884};\\\", \\\"{x:1362,y:677,t:1528139865900};\\\", \\\"{x:1363,y:677,t:1528139865918};\\\", \\\"{x:1359,y:677,t:1528139866048};\\\", \\\"{x:1349,y:677,t:1528139866056};\\\", \\\"{x:1342,y:677,t:1528139866067};\\\", \\\"{x:1328,y:677,t:1528139866084};\\\", \\\"{x:1313,y:677,t:1528139866101};\\\", \\\"{x:1298,y:677,t:1528139866118};\\\", \\\"{x:1288,y:677,t:1528139866134};\\\", \\\"{x:1280,y:682,t:1528139866150};\\\", \\\"{x:1274,y:691,t:1528139866168};\\\", \\\"{x:1269,y:703,t:1528139866184};\\\", \\\"{x:1265,y:714,t:1528139866201};\\\", \\\"{x:1261,y:723,t:1528139866217};\\\", \\\"{x:1258,y:732,t:1528139866235};\\\", \\\"{x:1256,y:739,t:1528139866250};\\\", \\\"{x:1256,y:741,t:1528139866267};\\\", \\\"{x:1256,y:743,t:1528139866285};\\\", \\\"{x:1254,y:742,t:1528139866409};\\\", \\\"{x:1250,y:741,t:1528139866418};\\\", \\\"{x:1244,y:739,t:1528139866435};\\\", \\\"{x:1233,y:733,t:1528139866451};\\\", \\\"{x:1226,y:729,t:1528139866468};\\\", \\\"{x:1222,y:726,t:1528139866484};\\\", \\\"{x:1221,y:724,t:1528139866500};\\\", \\\"{x:1221,y:720,t:1528139866518};\\\", \\\"{x:1221,y:713,t:1528139866534};\\\", \\\"{x:1221,y:699,t:1528139866552};\\\", \\\"{x:1223,y:686,t:1528139866568};\\\", \\\"{x:1228,y:675,t:1528139866584};\\\", \\\"{x:1235,y:660,t:1528139866601};\\\", \\\"{x:1241,y:645,t:1528139866617};\\\", \\\"{x:1246,y:636,t:1528139866635};\\\", \\\"{x:1249,y:628,t:1528139866652};\\\", \\\"{x:1251,y:623,t:1528139866668};\\\", \\\"{x:1254,y:619,t:1528139866685};\\\", \\\"{x:1254,y:618,t:1528139866702};\\\", \\\"{x:1254,y:616,t:1528139866718};\\\", \\\"{x:1254,y:615,t:1528139866801};\\\", \\\"{x:1254,y:614,t:1528139866832};\\\", \\\"{x:1254,y:612,t:1528139866848};\\\", \\\"{x:1254,y:610,t:1528139866864};\\\", \\\"{x:1255,y:609,t:1528139866872};\\\", \\\"{x:1256,y:607,t:1528139866885};\\\", \\\"{x:1257,y:605,t:1528139866902};\\\", \\\"{x:1262,y:597,t:1528139866918};\\\", \\\"{x:1266,y:587,t:1528139866934};\\\", \\\"{x:1271,y:579,t:1528139866952};\\\", \\\"{x:1274,y:575,t:1528139866969};\\\", \\\"{x:1278,y:569,t:1528139866985};\\\", \\\"{x:1279,y:565,t:1528139867002};\\\", \\\"{x:1280,y:563,t:1528139867018};\\\", \\\"{x:1281,y:562,t:1528139867035};\\\", \\\"{x:1281,y:561,t:1528139867096};\\\", \\\"{x:1282,y:560,t:1528139867128};\\\", \\\"{x:1282,y:559,t:1528139867152};\\\", \\\"{x:1282,y:562,t:1528139869341};\\\", \\\"{x:1282,y:570,t:1528139869360};\\\", \\\"{x:1282,y:575,t:1528139869376};\\\", \\\"{x:1282,y:580,t:1528139869392};\\\", \\\"{x:1281,y:584,t:1528139869409};\\\", \\\"{x:1281,y:585,t:1528139869426};\\\", \\\"{x:1281,y:587,t:1528139869442};\\\", \\\"{x:1281,y:588,t:1528139869459};\\\", \\\"{x:1281,y:590,t:1528139869477};\\\", \\\"{x:1281,y:593,t:1528139869492};\\\", \\\"{x:1281,y:597,t:1528139869509};\\\", \\\"{x:1281,y:600,t:1528139869525};\\\", \\\"{x:1280,y:602,t:1528139869542};\\\", \\\"{x:1280,y:606,t:1528139869559};\\\", \\\"{x:1279,y:613,t:1528139869576};\\\", \\\"{x:1279,y:620,t:1528139869592};\\\", \\\"{x:1277,y:627,t:1528139869609};\\\", \\\"{x:1276,y:636,t:1528139869626};\\\", \\\"{x:1274,y:645,t:1528139869642};\\\", \\\"{x:1274,y:651,t:1528139869659};\\\", \\\"{x:1273,y:656,t:1528139869676};\\\", \\\"{x:1272,y:662,t:1528139869692};\\\", \\\"{x:1272,y:669,t:1528139869709};\\\", \\\"{x:1272,y:672,t:1528139869725};\\\", \\\"{x:1272,y:675,t:1528139869742};\\\", \\\"{x:1272,y:679,t:1528139869759};\\\", \\\"{x:1272,y:682,t:1528139869776};\\\", \\\"{x:1272,y:685,t:1528139869793};\\\", \\\"{x:1272,y:687,t:1528139869809};\\\", \\\"{x:1272,y:689,t:1528139869826};\\\", \\\"{x:1272,y:691,t:1528139869844};\\\", \\\"{x:1272,y:694,t:1528139869858};\\\", \\\"{x:1272,y:698,t:1528139869876};\\\", \\\"{x:1272,y:702,t:1528139869893};\\\", \\\"{x:1272,y:705,t:1528139869909};\\\", \\\"{x:1272,y:709,t:1528139869926};\\\", \\\"{x:1272,y:713,t:1528139869943};\\\", \\\"{x:1272,y:718,t:1528139869959};\\\", \\\"{x:1272,y:723,t:1528139869976};\\\", \\\"{x:1272,y:728,t:1528139869993};\\\", \\\"{x:1272,y:735,t:1528139870009};\\\", \\\"{x:1272,y:741,t:1528139870026};\\\", \\\"{x:1272,y:747,t:1528139870043};\\\", \\\"{x:1276,y:753,t:1528139870059};\\\", \\\"{x:1276,y:755,t:1528139870076};\\\", \\\"{x:1277,y:761,t:1528139870093};\\\", \\\"{x:1277,y:764,t:1528139870109};\\\", \\\"{x:1277,y:767,t:1528139870126};\\\", \\\"{x:1277,y:769,t:1528139870143};\\\", \\\"{x:1278,y:771,t:1528139870159};\\\", \\\"{x:1278,y:773,t:1528139870176};\\\", \\\"{x:1278,y:774,t:1528139870193};\\\", \\\"{x:1279,y:776,t:1528139870210};\\\", \\\"{x:1279,y:777,t:1528139870226};\\\", \\\"{x:1279,y:778,t:1528139870254};\\\", \\\"{x:1279,y:779,t:1528139870261};\\\", \\\"{x:1280,y:780,t:1528139870276};\\\", \\\"{x:1280,y:783,t:1528139870293};\\\", \\\"{x:1281,y:786,t:1528139870309};\\\", \\\"{x:1281,y:790,t:1528139870326};\\\", \\\"{x:1281,y:794,t:1528139870343};\\\", \\\"{x:1281,y:799,t:1528139870360};\\\", \\\"{x:1283,y:807,t:1528139870376};\\\", \\\"{x:1284,y:814,t:1528139870393};\\\", \\\"{x:1284,y:822,t:1528139870410};\\\", \\\"{x:1285,y:832,t:1528139870426};\\\", \\\"{x:1285,y:839,t:1528139870443};\\\", \\\"{x:1285,y:845,t:1528139870461};\\\", \\\"{x:1285,y:851,t:1528139870476};\\\", \\\"{x:1285,y:858,t:1528139870493};\\\", \\\"{x:1285,y:860,t:1528139870510};\\\", \\\"{x:1285,y:862,t:1528139870526};\\\", \\\"{x:1285,y:865,t:1528139870543};\\\", \\\"{x:1285,y:867,t:1528139870560};\\\", \\\"{x:1285,y:869,t:1528139870576};\\\", \\\"{x:1285,y:870,t:1528139870593};\\\", \\\"{x:1285,y:871,t:1528139870610};\\\", \\\"{x:1285,y:874,t:1528139870627};\\\", \\\"{x:1285,y:875,t:1528139870643};\\\", \\\"{x:1285,y:877,t:1528139870660};\\\", \\\"{x:1285,y:880,t:1528139870678};\\\", \\\"{x:1285,y:884,t:1528139870693};\\\", \\\"{x:1285,y:887,t:1528139870710};\\\", \\\"{x:1285,y:890,t:1528139870727};\\\", \\\"{x:1285,y:891,t:1528139870744};\\\", \\\"{x:1285,y:894,t:1528139870760};\\\", \\\"{x:1285,y:897,t:1528139870777};\\\", \\\"{x:1285,y:900,t:1528139870793};\\\", \\\"{x:1285,y:903,t:1528139870810};\\\", \\\"{x:1285,y:905,t:1528139870827};\\\", \\\"{x:1285,y:906,t:1528139870843};\\\", \\\"{x:1285,y:910,t:1528139870860};\\\", \\\"{x:1285,y:915,t:1528139870877};\\\", \\\"{x:1285,y:917,t:1528139870893};\\\", \\\"{x:1285,y:920,t:1528139870910};\\\", \\\"{x:1285,y:922,t:1528139870927};\\\", \\\"{x:1285,y:924,t:1528139870943};\\\", \\\"{x:1285,y:926,t:1528139870960};\\\", \\\"{x:1285,y:928,t:1528139870978};\\\", \\\"{x:1285,y:929,t:1528139871021};\\\", \\\"{x:1285,y:930,t:1528139871045};\\\", \\\"{x:1285,y:931,t:1528139871060};\\\", \\\"{x:1285,y:934,t:1528139871077};\\\", \\\"{x:1284,y:937,t:1528139871094};\\\", \\\"{x:1284,y:941,t:1528139871110};\\\", \\\"{x:1284,y:946,t:1528139871127};\\\", \\\"{x:1284,y:953,t:1528139871144};\\\", \\\"{x:1284,y:963,t:1528139871160};\\\", \\\"{x:1284,y:971,t:1528139871177};\\\", \\\"{x:1284,y:976,t:1528139871194};\\\", \\\"{x:1284,y:978,t:1528139871210};\\\", \\\"{x:1283,y:975,t:1528139871573};\\\", \\\"{x:1283,y:974,t:1528139871581};\\\", \\\"{x:1282,y:973,t:1528139871597};\\\", \\\"{x:1282,y:972,t:1528139871629};\\\", \\\"{x:1282,y:971,t:1528139871781};\\\", \\\"{x:1281,y:970,t:1528139871966};\\\", \\\"{x:1275,y:962,t:1528139878638};\\\", \\\"{x:1226,y:947,t:1528139878651};\\\", \\\"{x:1117,y:936,t:1528139878667};\\\", \\\"{x:1016,y:942,t:1528139878683};\\\", \\\"{x:903,y:966,t:1528139878700};\\\", \\\"{x:710,y:995,t:1528139878717};\\\", \\\"{x:600,y:995,t:1528139878733};\\\", \\\"{x:543,y:997,t:1528139878750};\\\", \\\"{x:536,y:997,t:1528139878767};\\\", \\\"{x:535,y:995,t:1528139878783};\\\", \\\"{x:532,y:987,t:1528139878801};\\\", \\\"{x:531,y:972,t:1528139878817};\\\", \\\"{x:546,y:952,t:1528139878833};\\\", \\\"{x:573,y:926,t:1528139878850};\\\", \\\"{x:604,y:896,t:1528139878867};\\\", \\\"{x:636,y:871,t:1528139878883};\\\", \\\"{x:661,y:846,t:1528139878900};\\\", \\\"{x:673,y:819,t:1528139878917};\\\", \\\"{x:677,y:807,t:1528139878933};\\\", \\\"{x:677,y:792,t:1528139878950};\\\", \\\"{x:677,y:778,t:1528139878967};\\\", \\\"{x:677,y:769,t:1528139878983};\\\", \\\"{x:674,y:761,t:1528139879000};\\\", \\\"{x:671,y:753,t:1528139879018};\\\", \\\"{x:665,y:745,t:1528139879033};\\\", \\\"{x:656,y:740,t:1528139879050};\\\", \\\"{x:649,y:735,t:1528139879067};\\\", \\\"{x:647,y:734,t:1528139879085};\\\", \\\"{x:646,y:734,t:1528139879108};\\\", \\\"{x:643,y:734,t:1528139879125};\\\", \\\"{x:641,y:734,t:1528139879135};\\\", \\\"{x:633,y:736,t:1528139879150};\\\", \\\"{x:629,y:738,t:1528139879167};\\\", \\\"{x:628,y:739,t:1528139879189};\\\", \\\"{x:625,y:739,t:1528139879213};\\\", \\\"{x:624,y:740,t:1528139879220};\\\", \\\"{x:621,y:740,t:1528139879234};\\\", \\\"{x:610,y:743,t:1528139879250};\\\", \\\"{x:594,y:745,t:1528139879267};\\\", \\\"{x:579,y:745,t:1528139879285};\\\", \\\"{x:567,y:745,t:1528139879300};\\\", \\\"{x:559,y:745,t:1528139879318};\\\", \\\"{x:555,y:745,t:1528139879333};\\\", \\\"{x:548,y:745,t:1528139879349};\\\", \\\"{x:539,y:745,t:1528139879365};\\\", \\\"{x:534,y:745,t:1528139879383};\\\", \\\"{x:531,y:745,t:1528139879399};\\\" ] }, { \\\"rt\\\": 58467, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 19, \\\"time_elapsed\\\": 731884, \\\"internal_node_id\\\": \\\"0.0-6.0-9.0\\\", \\\"subject\\\": \\\"S6D2F\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 15, \\\"clicks\\\": 2.5, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\", \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-03 PM-12 PM-02 PM-02 PM-X -X -X -02 PM-03 PM-02 PM-01 PM-X -B -O -O -F -F -F -J -J -E -E -E -G -G \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:535,y:745,t:1528139881509};\\\", \\\"{x:541,y:745,t:1528139881518};\\\", \\\"{x:548,y:745,t:1528139881536};\\\", \\\"{x:555,y:745,t:1528139881552};\\\", \\\"{x:562,y:745,t:1528139881568};\\\", \\\"{x:565,y:745,t:1528139881587};\\\", \\\"{x:568,y:743,t:1528139881601};\\\", \\\"{x:571,y:741,t:1528139881617};\\\", \\\"{x:573,y:736,t:1528139881634};\\\", \\\"{x:576,y:720,t:1528139881651};\\\", \\\"{x:576,y:697,t:1528139881668};\\\", \\\"{x:572,y:661,t:1528139881685};\\\", \\\"{x:561,y:606,t:1528139881703};\\\", \\\"{x:546,y:536,t:1528139881718};\\\", \\\"{x:522,y:458,t:1528139881735};\\\", \\\"{x:500,y:374,t:1528139881752};\\\", \\\"{x:466,y:297,t:1528139881768};\\\", \\\"{x:432,y:235,t:1528139881785};\\\", \\\"{x:403,y:178,t:1528139881802};\\\", \\\"{x:384,y:146,t:1528139881817};\\\", \\\"{x:370,y:130,t:1528139881835};\\\", \\\"{x:360,y:124,t:1528139881852};\\\", \\\"{x:355,y:126,t:1528139881868};\\\", \\\"{x:349,y:133,t:1528139881885};\\\", \\\"{x:340,y:145,t:1528139881902};\\\", \\\"{x:330,y:168,t:1528139881918};\\\", \\\"{x:323,y:189,t:1528139881935};\\\", \\\"{x:315,y:217,t:1528139881952};\\\", \\\"{x:306,y:248,t:1528139881968};\\\", \\\"{x:296,y:280,t:1528139881985};\\\", \\\"{x:282,y:315,t:1528139882002};\\\", \\\"{x:271,y:347,t:1528139882019};\\\", \\\"{x:267,y:361,t:1528139882035};\\\", \\\"{x:267,y:362,t:1528139882052};\\\", \\\"{x:267,y:364,t:1528139883277};\\\", \\\"{x:273,y:366,t:1528139883286};\\\", \\\"{x:277,y:366,t:1528139883303};\\\", \\\"{x:294,y:370,t:1528139883320};\\\", \\\"{x:308,y:374,t:1528139883335};\\\", \\\"{x:309,y:380,t:1528139883352};\\\", \\\"{x:309,y:382,t:1528139883370};\\\", \\\"{x:309,y:383,t:1528139884573};\\\", \\\"{x:309,y:384,t:1528139884749};\\\", \\\"{x:312,y:384,t:1528139884764};\\\", \\\"{x:314,y:385,t:1528139884772};\\\", \\\"{x:316,y:385,t:1528139884787};\\\", \\\"{x:332,y:387,t:1528139884805};\\\", \\\"{x:353,y:388,t:1528139884820};\\\", \\\"{x:380,y:392,t:1528139884838};\\\", \\\"{x:413,y:397,t:1528139884855};\\\", \\\"{x:448,y:405,t:1528139884871};\\\", \\\"{x:479,y:411,t:1528139884888};\\\", \\\"{x:526,y:417,t:1528139884904};\\\", \\\"{x:579,y:425,t:1528139884922};\\\", \\\"{x:644,y:435,t:1528139884938};\\\", \\\"{x:710,y:442,t:1528139884955};\\\", \\\"{x:782,y:451,t:1528139884971};\\\", \\\"{x:889,y:467,t:1528139884989};\\\", \\\"{x:967,y:478,t:1528139885004};\\\", \\\"{x:1039,y:487,t:1528139885021};\\\", \\\"{x:1101,y:497,t:1528139885039};\\\", \\\"{x:1165,y:505,t:1528139885055};\\\", \\\"{x:1227,y:515,t:1528139885071};\\\", \\\"{x:1296,y:524,t:1528139885089};\\\", \\\"{x:1378,y:542,t:1528139885104};\\\", \\\"{x:1476,y:556,t:1528139885121};\\\", \\\"{x:1576,y:586,t:1528139885138};\\\", \\\"{x:1670,y:616,t:1528139885154};\\\", \\\"{x:1671,y:617,t:1528139885173};\\\", \\\"{x:1719,y:644,t:1528139885188};\\\", \\\"{x:1761,y:681,t:1528139885205};\\\", \\\"{x:1776,y:703,t:1528139885222};\\\", \\\"{x:1793,y:720,t:1528139885238};\\\", \\\"{x:1798,y:745,t:1528139885255};\\\", \\\"{x:1798,y:767,t:1528139885271};\\\", \\\"{x:1798,y:786,t:1528139885289};\\\", \\\"{x:1796,y:805,t:1528139885305};\\\", \\\"{x:1786,y:827,t:1528139885322};\\\", \\\"{x:1767,y:849,t:1528139885339};\\\", \\\"{x:1749,y:871,t:1528139885355};\\\", \\\"{x:1733,y:890,t:1528139885371};\\\", \\\"{x:1713,y:916,t:1528139885389};\\\", \\\"{x:1699,y:926,t:1528139885405};\\\", \\\"{x:1688,y:933,t:1528139885421};\\\", \\\"{x:1676,y:938,t:1528139885439};\\\", \\\"{x:1662,y:943,t:1528139885456};\\\", \\\"{x:1654,y:944,t:1528139885472};\\\", \\\"{x:1645,y:948,t:1528139885489};\\\", \\\"{x:1633,y:950,t:1528139885505};\\\", \\\"{x:1620,y:954,t:1528139885522};\\\", \\\"{x:1602,y:960,t:1528139885539};\\\", \\\"{x:1584,y:963,t:1528139885556};\\\", \\\"{x:1567,y:968,t:1528139885572};\\\", \\\"{x:1540,y:976,t:1528139885589};\\\", \\\"{x:1519,y:981,t:1528139885606};\\\", \\\"{x:1497,y:986,t:1528139885622};\\\", \\\"{x:1472,y:988,t:1528139885638};\\\", \\\"{x:1445,y:993,t:1528139885656};\\\", \\\"{x:1420,y:996,t:1528139885671};\\\", \\\"{x:1397,y:997,t:1528139885688};\\\", \\\"{x:1371,y:997,t:1528139885705};\\\", \\\"{x:1353,y:997,t:1528139885721};\\\", \\\"{x:1341,y:997,t:1528139885739};\\\", \\\"{x:1335,y:997,t:1528139885756};\\\", \\\"{x:1333,y:997,t:1528139885771};\\\", \\\"{x:1333,y:996,t:1528139885797};\\\", \\\"{x:1333,y:993,t:1528139885805};\\\", \\\"{x:1338,y:985,t:1528139885822};\\\", \\\"{x:1344,y:979,t:1528139885838};\\\", \\\"{x:1357,y:966,t:1528139885856};\\\", \\\"{x:1368,y:957,t:1528139885872};\\\", \\\"{x:1387,y:944,t:1528139885888};\\\", \\\"{x:1410,y:935,t:1528139885906};\\\", \\\"{x:1429,y:927,t:1528139885922};\\\", \\\"{x:1447,y:920,t:1528139885939};\\\", \\\"{x:1465,y:916,t:1528139885956};\\\", \\\"{x:1490,y:914,t:1528139885972};\\\", \\\"{x:1503,y:914,t:1528139885989};\\\", \\\"{x:1515,y:914,t:1528139886005};\\\", \\\"{x:1524,y:914,t:1528139886023};\\\", \\\"{x:1534,y:917,t:1528139886039};\\\", \\\"{x:1539,y:920,t:1528139886055};\\\", \\\"{x:1540,y:921,t:1528139886076};\\\", \\\"{x:1540,y:922,t:1528139886092};\\\", \\\"{x:1540,y:924,t:1528139886106};\\\", \\\"{x:1540,y:926,t:1528139886122};\\\", \\\"{x:1538,y:932,t:1528139886138};\\\", \\\"{x:1534,y:940,t:1528139886156};\\\", \\\"{x:1527,y:954,t:1528139886172};\\\", \\\"{x:1522,y:961,t:1528139886189};\\\", \\\"{x:1514,y:969,t:1528139886206};\\\", \\\"{x:1506,y:973,t:1528139886222};\\\", \\\"{x:1495,y:979,t:1528139886239};\\\", \\\"{x:1488,y:986,t:1528139886256};\\\", \\\"{x:1484,y:986,t:1528139886272};\\\", \\\"{x:1479,y:987,t:1528139886290};\\\", \\\"{x:1476,y:987,t:1528139886306};\\\", \\\"{x:1475,y:987,t:1528139886322};\\\", \\\"{x:1475,y:985,t:1528139886422};\\\", \\\"{x:1475,y:983,t:1528139886440};\\\", \\\"{x:1475,y:981,t:1528139886456};\\\", \\\"{x:1475,y:979,t:1528139886473};\\\", \\\"{x:1475,y:975,t:1528139886489};\\\", \\\"{x:1475,y:973,t:1528139886506};\\\", \\\"{x:1475,y:970,t:1528139886522};\\\", \\\"{x:1475,y:964,t:1528139886540};\\\", \\\"{x:1475,y:960,t:1528139886556};\\\", \\\"{x:1475,y:956,t:1528139886573};\\\", \\\"{x:1475,y:955,t:1528139886596};\\\", \\\"{x:1475,y:954,t:1528139886605};\\\", \\\"{x:1475,y:953,t:1528139886623};\\\", \\\"{x:1475,y:950,t:1528139886640};\\\", \\\"{x:1475,y:948,t:1528139886656};\\\", \\\"{x:1475,y:944,t:1528139886673};\\\", \\\"{x:1475,y:942,t:1528139886689};\\\", \\\"{x:1475,y:940,t:1528139886706};\\\", \\\"{x:1475,y:939,t:1528139886723};\\\", \\\"{x:1475,y:935,t:1528139886739};\\\", \\\"{x:1475,y:933,t:1528139886757};\\\", \\\"{x:1475,y:930,t:1528139886773};\\\", \\\"{x:1475,y:929,t:1528139886789};\\\", \\\"{x:1475,y:928,t:1528139886807};\\\", \\\"{x:1475,y:926,t:1528139886823};\\\", \\\"{x:1475,y:925,t:1528139886845};\\\", \\\"{x:1475,y:924,t:1528139886861};\\\", \\\"{x:1475,y:923,t:1528139886873};\\\", \\\"{x:1475,y:920,t:1528139886890};\\\", \\\"{x:1475,y:918,t:1528139886906};\\\", \\\"{x:1474,y:913,t:1528139886923};\\\", \\\"{x:1474,y:906,t:1528139886940};\\\", \\\"{x:1474,y:892,t:1528139886957};\\\", \\\"{x:1474,y:882,t:1528139886973};\\\", \\\"{x:1474,y:870,t:1528139886990};\\\", \\\"{x:1474,y:860,t:1528139887006};\\\", \\\"{x:1478,y:847,t:1528139887022};\\\", \\\"{x:1479,y:838,t:1528139887040};\\\", \\\"{x:1481,y:830,t:1528139887059};\\\", \\\"{x:1482,y:824,t:1528139887072};\\\", \\\"{x:1483,y:817,t:1528139887089};\\\", \\\"{x:1483,y:814,t:1528139887106};\\\", \\\"{x:1483,y:813,t:1528139887122};\\\", \\\"{x:1485,y:809,t:1528139887140};\\\", \\\"{x:1485,y:810,t:1528139887382};\\\", \\\"{x:1485,y:811,t:1528139887397};\\\", \\\"{x:1485,y:812,t:1528139887407};\\\", \\\"{x:1484,y:813,t:1528139887424};\\\", \\\"{x:1484,y:815,t:1528139887441};\\\", \\\"{x:1484,y:814,t:1528139887613};\\\", \\\"{x:1482,y:812,t:1528139887623};\\\", \\\"{x:1482,y:808,t:1528139887643};\\\", \\\"{x:1481,y:802,t:1528139887657};\\\", \\\"{x:1480,y:799,t:1528139887673};\\\", \\\"{x:1479,y:795,t:1528139887691};\\\", \\\"{x:1478,y:791,t:1528139887706};\\\", \\\"{x:1478,y:787,t:1528139887723};\\\", \\\"{x:1478,y:784,t:1528139887741};\\\", \\\"{x:1478,y:783,t:1528139887757};\\\", \\\"{x:1477,y:782,t:1528139887774};\\\", \\\"{x:1477,y:781,t:1528139887804};\\\", \\\"{x:1477,y:780,t:1528139887829};\\\", \\\"{x:1477,y:778,t:1528139887869};\\\", \\\"{x:1477,y:777,t:1528139887893};\\\", \\\"{x:1477,y:775,t:1528139887909};\\\", \\\"{x:1475,y:774,t:1528139887925};\\\", \\\"{x:1475,y:771,t:1528139887940};\\\", \\\"{x:1475,y:770,t:1528139887956};\\\", \\\"{x:1475,y:768,t:1528139887973};\\\", \\\"{x:1475,y:767,t:1528139887990};\\\", \\\"{x:1475,y:765,t:1528139888007};\\\", \\\"{x:1475,y:764,t:1528139888029};\\\", \\\"{x:1475,y:763,t:1528139888042};\\\", \\\"{x:1475,y:762,t:1528139888061};\\\", \\\"{x:1475,y:761,t:1528139888197};\\\", \\\"{x:1475,y:758,t:1528139889821};\\\", \\\"{x:1475,y:755,t:1528139889829};\\\", \\\"{x:1475,y:752,t:1528139889841};\\\", \\\"{x:1474,y:744,t:1528139889859};\\\", \\\"{x:1474,y:739,t:1528139889876};\\\", \\\"{x:1474,y:735,t:1528139889892};\\\", \\\"{x:1472,y:729,t:1528139889909};\\\", \\\"{x:1472,y:728,t:1528139889926};\\\", \\\"{x:1472,y:726,t:1528139890077};\\\", \\\"{x:1472,y:725,t:1528139890091};\\\", \\\"{x:1472,y:718,t:1528139890109};\\\", \\\"{x:1472,y:711,t:1528139890125};\\\", \\\"{x:1472,y:708,t:1528139890142};\\\", \\\"{x:1472,y:704,t:1528139890158};\\\", \\\"{x:1471,y:700,t:1528139890176};\\\", \\\"{x:1471,y:699,t:1528139890192};\\\", \\\"{x:1471,y:698,t:1528139890208};\\\", \\\"{x:1470,y:697,t:1528139890225};\\\", \\\"{x:1470,y:696,t:1528139890325};\\\", \\\"{x:1474,y:697,t:1528139890343};\\\", \\\"{x:1475,y:697,t:1528139890359};\\\", \\\"{x:1476,y:698,t:1528139890376};\\\", \\\"{x:1477,y:698,t:1528139890397};\\\", \\\"{x:1478,y:698,t:1528139891125};\\\", \\\"{x:1479,y:698,t:1528139891133};\\\", \\\"{x:1480,y:698,t:1528139891143};\\\", \\\"{x:1481,y:698,t:1528139891160};\\\", \\\"{x:1477,y:697,t:1528139897093};\\\", \\\"{x:1460,y:697,t:1528139897100};\\\", \\\"{x:1445,y:697,t:1528139897114};\\\", \\\"{x:1371,y:697,t:1528139897131};\\\", \\\"{x:1261,y:697,t:1528139897148};\\\", \\\"{x:1045,y:697,t:1528139897164};\\\", \\\"{x:900,y:693,t:1528139897182};\\\", \\\"{x:751,y:673,t:1528139897198};\\\", \\\"{x:627,y:661,t:1528139897214};\\\", \\\"{x:534,y:653,t:1528139897231};\\\", \\\"{x:488,y:650,t:1528139897248};\\\", \\\"{x:463,y:647,t:1528139897265};\\\", \\\"{x:454,y:645,t:1528139897282};\\\", \\\"{x:453,y:645,t:1528139897298};\\\", \\\"{x:452,y:644,t:1528139897404};\\\", \\\"{x:452,y:641,t:1528139897414};\\\", \\\"{x:452,y:632,t:1528139897432};\\\", \\\"{x:452,y:619,t:1528139897449};\\\", \\\"{x:453,y:602,t:1528139897465};\\\", \\\"{x:456,y:582,t:1528139897481};\\\", \\\"{x:460,y:559,t:1528139897499};\\\", \\\"{x:461,y:535,t:1528139897515};\\\", \\\"{x:479,y:491,t:1528139897532};\\\", \\\"{x:482,y:471,t:1528139897548};\\\", \\\"{x:491,y:459,t:1528139897564};\\\", \\\"{x:493,y:455,t:1528139897581};\\\", \\\"{x:496,y:452,t:1528139897599};\\\", \\\"{x:501,y:452,t:1528139897614};\\\", \\\"{x:512,y:452,t:1528139897632};\\\", \\\"{x:531,y:452,t:1528139897648};\\\", \\\"{x:554,y:452,t:1528139897665};\\\", \\\"{x:581,y:452,t:1528139897681};\\\", \\\"{x:612,y:452,t:1528139897699};\\\", \\\"{x:641,y:452,t:1528139897715};\\\", \\\"{x:675,y:452,t:1528139897732};\\\", \\\"{x:704,y:453,t:1528139897748};\\\", \\\"{x:717,y:458,t:1528139897765};\\\", \\\"{x:725,y:461,t:1528139897782};\\\", \\\"{x:731,y:465,t:1528139897799};\\\", \\\"{x:732,y:466,t:1528139897815};\\\", \\\"{x:734,y:468,t:1528139897831};\\\", \\\"{x:735,y:470,t:1528139897848};\\\", \\\"{x:737,y:475,t:1528139897866};\\\", \\\"{x:737,y:478,t:1528139897882};\\\", \\\"{x:738,y:482,t:1528139897899};\\\", \\\"{x:738,y:486,t:1528139897916};\\\", \\\"{x:738,y:491,t:1528139897932};\\\", \\\"{x:735,y:498,t:1528139897949};\\\", \\\"{x:732,y:501,t:1528139897968};\\\", \\\"{x:730,y:502,t:1528139897981};\\\", \\\"{x:728,y:503,t:1528139897997};\\\", \\\"{x:723,y:506,t:1528139898015};\\\", \\\"{x:713,y:511,t:1528139898030};\\\", \\\"{x:704,y:515,t:1528139898048};\\\", \\\"{x:687,y:520,t:1528139898065};\\\", \\\"{x:670,y:523,t:1528139898081};\\\", \\\"{x:650,y:529,t:1528139898099};\\\", \\\"{x:621,y:534,t:1528139898116};\\\", \\\"{x:591,y:538,t:1528139898131};\\\", \\\"{x:514,y:538,t:1528139898148};\\\", \\\"{x:456,y:538,t:1528139898166};\\\", \\\"{x:402,y:540,t:1528139898182};\\\", \\\"{x:365,y:541,t:1528139898198};\\\", \\\"{x:343,y:541,t:1528139898215};\\\", \\\"{x:329,y:541,t:1528139898233};\\\", \\\"{x:323,y:543,t:1528139898248};\\\", \\\"{x:320,y:544,t:1528139898266};\\\", \\\"{x:318,y:544,t:1528139898282};\\\", \\\"{x:317,y:545,t:1528139898299};\\\", \\\"{x:316,y:545,t:1528139898315};\\\", \\\"{x:316,y:546,t:1528139898364};\\\", \\\"{x:316,y:547,t:1528139898380};\\\", \\\"{x:317,y:549,t:1528139898388};\\\", \\\"{x:322,y:549,t:1528139898398};\\\", \\\"{x:337,y:549,t:1528139898415};\\\", \\\"{x:356,y:549,t:1528139898432};\\\", \\\"{x:382,y:549,t:1528139898449};\\\", \\\"{x:408,y:549,t:1528139898466};\\\", \\\"{x:435,y:549,t:1528139898483};\\\", \\\"{x:454,y:548,t:1528139898498};\\\", \\\"{x:473,y:544,t:1528139898516};\\\", \\\"{x:476,y:544,t:1528139898532};\\\", \\\"{x:476,y:542,t:1528139898572};\\\", \\\"{x:475,y:541,t:1528139898597};\\\", \\\"{x:473,y:540,t:1528139898604};\\\", \\\"{x:471,y:539,t:1528139898615};\\\", \\\"{x:467,y:537,t:1528139898633};\\\", \\\"{x:466,y:537,t:1528139898649};\\\", \\\"{x:457,y:537,t:1528139898665};\\\", \\\"{x:442,y:535,t:1528139898683};\\\", \\\"{x:428,y:535,t:1528139898699};\\\", \\\"{x:422,y:535,t:1528139898716};\\\", \\\"{x:417,y:535,t:1528139898733};\\\", \\\"{x:416,y:535,t:1528139898796};\\\", \\\"{x:415,y:535,t:1528139898820};\\\", \\\"{x:415,y:536,t:1528139899317};\\\", \\\"{x:414,y:539,t:1528139899550};\\\", \\\"{x:411,y:541,t:1528139899567};\\\", \\\"{x:407,y:543,t:1528139899584};\\\", \\\"{x:396,y:546,t:1528139899599};\\\", \\\"{x:382,y:547,t:1528139899616};\\\", \\\"{x:368,y:550,t:1528139899633};\\\", \\\"{x:351,y:552,t:1528139899650};\\\", \\\"{x:331,y:553,t:1528139899667};\\\", \\\"{x:297,y:555,t:1528139899683};\\\", \\\"{x:274,y:555,t:1528139899700};\\\", \\\"{x:248,y:555,t:1528139899717};\\\", \\\"{x:226,y:555,t:1528139899733};\\\", \\\"{x:209,y:554,t:1528139899749};\\\", \\\"{x:195,y:551,t:1528139899766};\\\", \\\"{x:185,y:549,t:1528139899783};\\\", \\\"{x:176,y:545,t:1528139899800};\\\", \\\"{x:171,y:544,t:1528139899817};\\\", \\\"{x:167,y:544,t:1528139899833};\\\", \\\"{x:163,y:541,t:1528139899850};\\\", \\\"{x:161,y:541,t:1528139899867};\\\", \\\"{x:160,y:541,t:1528139899883};\\\", \\\"{x:158,y:541,t:1528139899957};\\\", \\\"{x:158,y:542,t:1528139900005};\\\", \\\"{x:158,y:543,t:1528139900019};\\\", \\\"{x:158,y:545,t:1528139900034};\\\", \\\"{x:159,y:546,t:1528139900050};\\\", \\\"{x:162,y:549,t:1528139900066};\\\", \\\"{x:177,y:561,t:1528139900084};\\\", \\\"{x:196,y:575,t:1528139900101};\\\", \\\"{x:218,y:581,t:1528139900118};\\\", \\\"{x:250,y:587,t:1528139900134};\\\", \\\"{x:301,y:595,t:1528139900151};\\\", \\\"{x:367,y:601,t:1528139900167};\\\", \\\"{x:442,y:612,t:1528139900183};\\\", \\\"{x:501,y:612,t:1528139900200};\\\", \\\"{x:557,y:612,t:1528139900216};\\\", \\\"{x:601,y:612,t:1528139900233};\\\", \\\"{x:625,y:612,t:1528139900251};\\\", \\\"{x:645,y:612,t:1528139900267};\\\", \\\"{x:654,y:612,t:1528139900284};\\\", \\\"{x:663,y:612,t:1528139900300};\\\", \\\"{x:674,y:612,t:1528139900318};\\\", \\\"{x:689,y:612,t:1528139900334};\\\", \\\"{x:700,y:612,t:1528139900351};\\\", \\\"{x:707,y:612,t:1528139900368};\\\", \\\"{x:708,y:612,t:1528139900383};\\\", \\\"{x:709,y:612,t:1528139900400};\\\", \\\"{x:709,y:611,t:1528139900437};\\\", \\\"{x:709,y:610,t:1528139900452};\\\", \\\"{x:705,y:608,t:1528139900468};\\\", \\\"{x:702,y:607,t:1528139900485};\\\", \\\"{x:699,y:605,t:1528139900500};\\\", \\\"{x:696,y:604,t:1528139900587};\\\", \\\"{x:695,y:603,t:1528139900603};\\\", \\\"{x:693,y:602,t:1528139900617};\\\", \\\"{x:687,y:600,t:1528139900635};\\\", \\\"{x:679,y:597,t:1528139900650};\\\", \\\"{x:639,y:592,t:1528139900668};\\\", \\\"{x:570,y:583,t:1528139900684};\\\", \\\"{x:509,y:576,t:1528139900701};\\\", \\\"{x:466,y:575,t:1528139900718};\\\", \\\"{x:440,y:575,t:1528139900734};\\\", \\\"{x:428,y:575,t:1528139900750};\\\", \\\"{x:427,y:575,t:1528139900768};\\\", \\\"{x:425,y:575,t:1528139900821};\\\", \\\"{x:423,y:577,t:1528139900836};\\\", \\\"{x:418,y:580,t:1528139900850};\\\", \\\"{x:410,y:584,t:1528139900867};\\\", \\\"{x:406,y:586,t:1528139900884};\\\", \\\"{x:401,y:589,t:1528139900900};\\\", \\\"{x:394,y:593,t:1528139900918};\\\", \\\"{x:381,y:598,t:1528139900934};\\\", \\\"{x:366,y:603,t:1528139900951};\\\", \\\"{x:346,y:608,t:1528139900967};\\\", \\\"{x:323,y:611,t:1528139900984};\\\", \\\"{x:299,y:613,t:1528139901000};\\\", \\\"{x:283,y:613,t:1528139901017};\\\", \\\"{x:276,y:613,t:1528139901034};\\\", \\\"{x:273,y:613,t:1528139901068};\\\", \\\"{x:271,y:613,t:1528139901091};\\\", \\\"{x:267,y:612,t:1528139901101};\\\", \\\"{x:266,y:612,t:1528139901118};\\\", \\\"{x:263,y:612,t:1528139901134};\\\", \\\"{x:262,y:612,t:1528139901150};\\\", \\\"{x:262,y:613,t:1528139902101};\\\", \\\"{x:263,y:617,t:1528139902120};\\\", \\\"{x:264,y:619,t:1528139902135};\\\", \\\"{x:267,y:623,t:1528139902151};\\\", \\\"{x:267,y:625,t:1528139902168};\\\", \\\"{x:267,y:629,t:1528139902186};\\\", \\\"{x:267,y:632,t:1528139902202};\\\", \\\"{x:267,y:634,t:1528139902219};\\\", \\\"{x:268,y:634,t:1528139902405};\\\", \\\"{x:269,y:634,t:1528139902420};\\\", \\\"{x:269,y:633,t:1528139902444};\\\", \\\"{x:271,y:631,t:1528139902452};\\\", \\\"{x:273,y:628,t:1528139902472};\\\", \\\"{x:275,y:625,t:1528139902485};\\\", \\\"{x:276,y:624,t:1528139902502};\\\", \\\"{x:280,y:619,t:1528139902518};\\\", \\\"{x:286,y:616,t:1528139902536};\\\", \\\"{x:293,y:610,t:1528139902553};\\\", \\\"{x:297,y:606,t:1528139902569};\\\", \\\"{x:306,y:598,t:1528139902586};\\\", \\\"{x:315,y:590,t:1528139902603};\\\", \\\"{x:325,y:581,t:1528139902618};\\\", \\\"{x:340,y:563,t:1528139902636};\\\", \\\"{x:355,y:551,t:1528139902652};\\\", \\\"{x:369,y:539,t:1528139902668};\\\", \\\"{x:384,y:522,t:1528139902686};\\\", \\\"{x:400,y:507,t:1528139902703};\\\", \\\"{x:414,y:493,t:1528139902719};\\\", \\\"{x:429,y:476,t:1528139902735};\\\", \\\"{x:437,y:465,t:1528139902753};\\\", \\\"{x:441,y:458,t:1528139902768};\\\", \\\"{x:440,y:459,t:1528139902829};\\\", \\\"{x:434,y:463,t:1528139902836};\\\", \\\"{x:427,y:467,t:1528139902852};\\\", \\\"{x:422,y:477,t:1528139902870};\\\", \\\"{x:414,y:489,t:1528139902886};\\\", \\\"{x:406,y:498,t:1528139902903};\\\", \\\"{x:392,y:507,t:1528139902921};\\\", \\\"{x:380,y:514,t:1528139902935};\\\", \\\"{x:366,y:521,t:1528139902953};\\\", \\\"{x:357,y:526,t:1528139902970};\\\", \\\"{x:349,y:529,t:1528139902985};\\\", \\\"{x:343,y:531,t:1528139903002};\\\", \\\"{x:336,y:532,t:1528139903020};\\\", \\\"{x:329,y:534,t:1528139903036};\\\", \\\"{x:322,y:534,t:1528139903052};\\\", \\\"{x:317,y:536,t:1528139903070};\\\", \\\"{x:310,y:537,t:1528139903085};\\\", \\\"{x:303,y:539,t:1528139903103};\\\", \\\"{x:300,y:540,t:1528139903120};\\\", \\\"{x:297,y:542,t:1528139903137};\\\", \\\"{x:296,y:543,t:1528139903153};\\\", \\\"{x:295,y:544,t:1528139903172};\\\", \\\"{x:295,y:545,t:1528139903196};\\\", \\\"{x:293,y:546,t:1528139903204};\\\", \\\"{x:292,y:549,t:1528139903220};\\\", \\\"{x:290,y:550,t:1528139903236};\\\", \\\"{x:286,y:554,t:1528139903253};\\\", \\\"{x:277,y:559,t:1528139903270};\\\", \\\"{x:259,y:566,t:1528139903289};\\\", \\\"{x:238,y:573,t:1528139903303};\\\", \\\"{x:213,y:579,t:1528139903320};\\\", \\\"{x:186,y:583,t:1528139903337};\\\", \\\"{x:169,y:584,t:1528139903352};\\\", \\\"{x:150,y:585,t:1528139903369};\\\", \\\"{x:140,y:588,t:1528139903387};\\\", \\\"{x:134,y:589,t:1528139903402};\\\", \\\"{x:132,y:589,t:1528139903419};\\\", \\\"{x:131,y:589,t:1528139903516};\\\", \\\"{x:131,y:591,t:1528139903548};\\\", \\\"{x:131,y:592,t:1528139903564};\\\", \\\"{x:133,y:595,t:1528139903580};\\\", \\\"{x:135,y:595,t:1528139903596};\\\", \\\"{x:138,y:595,t:1528139903604};\\\", \\\"{x:145,y:596,t:1528139903620};\\\", \\\"{x:151,y:596,t:1528139903638};\\\", \\\"{x:156,y:596,t:1528139903653};\\\", \\\"{x:165,y:596,t:1528139903669};\\\", \\\"{x:186,y:596,t:1528139903686};\\\", \\\"{x:207,y:596,t:1528139903703};\\\", \\\"{x:232,y:599,t:1528139903719};\\\", \\\"{x:278,y:602,t:1528139903739};\\\", \\\"{x:326,y:609,t:1528139903753};\\\", \\\"{x:385,y:619,t:1528139903770};\\\", \\\"{x:463,y:628,t:1528139903787};\\\", \\\"{x:542,y:637,t:1528139903804};\\\", \\\"{x:582,y:643,t:1528139903819};\\\", \\\"{x:622,y:643,t:1528139903836};\\\", \\\"{x:648,y:640,t:1528139903854};\\\", \\\"{x:679,y:634,t:1528139903869};\\\", \\\"{x:705,y:625,t:1528139903886};\\\", \\\"{x:721,y:618,t:1528139903904};\\\", \\\"{x:737,y:607,t:1528139903920};\\\", \\\"{x:756,y:596,t:1528139903937};\\\", \\\"{x:768,y:588,t:1528139903953};\\\", \\\"{x:777,y:580,t:1528139903970};\\\", \\\"{x:782,y:575,t:1528139903987};\\\", \\\"{x:785,y:567,t:1528139904004};\\\", \\\"{x:785,y:564,t:1528139904020};\\\", \\\"{x:784,y:561,t:1528139904036};\\\", \\\"{x:777,y:557,t:1528139904054};\\\", \\\"{x:768,y:555,t:1528139904070};\\\", \\\"{x:756,y:550,t:1528139904087};\\\", \\\"{x:738,y:547,t:1528139904103};\\\", \\\"{x:716,y:544,t:1528139904122};\\\", \\\"{x:695,y:542,t:1528139904137};\\\", \\\"{x:677,y:542,t:1528139904154};\\\", \\\"{x:664,y:542,t:1528139904171};\\\", \\\"{x:657,y:542,t:1528139904188};\\\", \\\"{x:656,y:542,t:1528139904204};\\\", \\\"{x:655,y:542,t:1528139904221};\\\", \\\"{x:654,y:542,t:1528139904252};\\\", \\\"{x:653,y:542,t:1528139904293};\\\", \\\"{x:657,y:542,t:1528139904437};\\\", \\\"{x:662,y:542,t:1528139904444};\\\", \\\"{x:669,y:543,t:1528139904455};\\\", \\\"{x:685,y:543,t:1528139904471};\\\", \\\"{x:704,y:548,t:1528139904489};\\\", \\\"{x:745,y:556,t:1528139904507};\\\", \\\"{x:840,y:575,t:1528139904522};\\\", \\\"{x:929,y:601,t:1528139904538};\\\", \\\"{x:983,y:612,t:1528139904554};\\\", \\\"{x:1026,y:633,t:1528139904570};\\\", \\\"{x:1083,y:657,t:1528139904587};\\\", \\\"{x:1089,y:662,t:1528139904604};\\\", \\\"{x:1089,y:664,t:1528139904621};\\\", \\\"{x:1086,y:667,t:1528139904638};\\\", \\\"{x:1084,y:667,t:1528139904653};\\\", \\\"{x:1078,y:668,t:1528139904671};\\\", \\\"{x:1065,y:668,t:1528139904688};\\\", \\\"{x:1042,y:668,t:1528139904705};\\\", \\\"{x:1011,y:668,t:1528139904721};\\\", \\\"{x:942,y:660,t:1528139904737};\\\", \\\"{x:825,y:642,t:1528139904755};\\\", \\\"{x:707,y:630,t:1528139904772};\\\", \\\"{x:549,y:604,t:1528139904789};\\\", \\\"{x:493,y:596,t:1528139904804};\\\", \\\"{x:479,y:590,t:1528139904821};\\\", \\\"{x:478,y:589,t:1528139904838};\\\", \\\"{x:481,y:582,t:1528139904854};\\\", \\\"{x:496,y:573,t:1528139904872};\\\", \\\"{x:514,y:564,t:1528139904888};\\\", \\\"{x:532,y:553,t:1528139904905};\\\", \\\"{x:553,y:542,t:1528139904920};\\\", \\\"{x:578,y:532,t:1528139904939};\\\", \\\"{x:598,y:522,t:1528139904956};\\\", \\\"{x:618,y:515,t:1528139904971};\\\", \\\"{x:629,y:509,t:1528139904988};\\\", \\\"{x:630,y:507,t:1528139905005};\\\", \\\"{x:631,y:507,t:1528139905028};\\\", \\\"{x:634,y:506,t:1528139905068};\\\", \\\"{x:639,y:503,t:1528139905077};\\\", \\\"{x:647,y:503,t:1528139905087};\\\", \\\"{x:672,y:502,t:1528139905104};\\\", \\\"{x:709,y:502,t:1528139905120};\\\", \\\"{x:762,y:502,t:1528139905138};\\\", \\\"{x:804,y:502,t:1528139905154};\\\", \\\"{x:848,y:507,t:1528139905171};\\\", \\\"{x:924,y:528,t:1528139905188};\\\", \\\"{x:952,y:535,t:1528139905205};\\\", \\\"{x:967,y:542,t:1528139905222};\\\", \\\"{x:972,y:545,t:1528139905238};\\\", \\\"{x:971,y:545,t:1528139905284};\\\", \\\"{x:967,y:544,t:1528139905292};\\\", \\\"{x:966,y:544,t:1528139905304};\\\", \\\"{x:962,y:544,t:1528139905322};\\\", \\\"{x:953,y:544,t:1528139905338};\\\", \\\"{x:934,y:544,t:1528139905356};\\\", \\\"{x:898,y:544,t:1528139905371};\\\", \\\"{x:865,y:542,t:1528139905387};\\\", \\\"{x:843,y:542,t:1528139905404};\\\", \\\"{x:828,y:540,t:1528139905422};\\\", \\\"{x:822,y:540,t:1528139905437};\\\", \\\"{x:821,y:539,t:1528139905455};\\\", \\\"{x:820,y:539,t:1528139905491};\\\", \\\"{x:820,y:538,t:1528139905588};\\\", \\\"{x:822,y:535,t:1528139905604};\\\", \\\"{x:827,y:532,t:1528139905622};\\\", \\\"{x:829,y:531,t:1528139905639};\\\", \\\"{x:831,y:530,t:1528139905654};\\\", \\\"{x:831,y:529,t:1528139905692};\\\", \\\"{x:833,y:528,t:1528139905772};\\\", \\\"{x:833,y:527,t:1528139906797};\\\", \\\"{x:834,y:526,t:1528139906838};\\\", \\\"{x:835,y:525,t:1528139906859};\\\", \\\"{x:835,y:524,t:1528139906891};\\\", \\\"{x:836,y:524,t:1528139906907};\\\", \\\"{x:836,y:523,t:1528139906923};\\\", \\\"{x:837,y:523,t:1528139906938};\\\", \\\"{x:839,y:519,t:1528139906955};\\\", \\\"{x:840,y:517,t:1528139906972};\\\", \\\"{x:841,y:514,t:1528139906989};\\\", \\\"{x:843,y:512,t:1528139907006};\\\", \\\"{x:843,y:511,t:1528139907022};\\\", \\\"{x:843,y:510,t:1528139907044};\\\", \\\"{x:847,y:510,t:1528139907749};\\\", \\\"{x:859,y:510,t:1528139907756};\\\", \\\"{x:907,y:510,t:1528139907774};\\\", \\\"{x:966,y:519,t:1528139907790};\\\", \\\"{x:1030,y:527,t:1528139907807};\\\", \\\"{x:1095,y:537,t:1528139907823};\\\", \\\"{x:1179,y:550,t:1528139907840};\\\", \\\"{x:1262,y:575,t:1528139907856};\\\", \\\"{x:1330,y:600,t:1528139907874};\\\", \\\"{x:1392,y:619,t:1528139907890};\\\", \\\"{x:1435,y:637,t:1528139907907};\\\", \\\"{x:1481,y:660,t:1528139907923};\\\", \\\"{x:1501,y:673,t:1528139907940};\\\", \\\"{x:1521,y:686,t:1528139907957};\\\", \\\"{x:1538,y:703,t:1528139907973};\\\", \\\"{x:1550,y:715,t:1528139907990};\\\", \\\"{x:1559,y:728,t:1528139908007};\\\", \\\"{x:1567,y:743,t:1528139908024};\\\", \\\"{x:1574,y:757,t:1528139908041};\\\", \\\"{x:1582,y:777,t:1528139908057};\\\", \\\"{x:1587,y:787,t:1528139908074};\\\", \\\"{x:1588,y:792,t:1528139908090};\\\", \\\"{x:1589,y:793,t:1528139909837};\\\", \\\"{x:1590,y:793,t:1528139910028};\\\", \\\"{x:1591,y:796,t:1528139910042};\\\", \\\"{x:1593,y:799,t:1528139910059};\\\", \\\"{x:1594,y:802,t:1528139910075};\\\", \\\"{x:1599,y:810,t:1528139910092};\\\", \\\"{x:1601,y:815,t:1528139910108};\\\", \\\"{x:1607,y:822,t:1528139910126};\\\", \\\"{x:1609,y:827,t:1528139910143};\\\", \\\"{x:1611,y:832,t:1528139910159};\\\", \\\"{x:1615,y:840,t:1528139910176};\\\", \\\"{x:1618,y:847,t:1528139910193};\\\", \\\"{x:1622,y:852,t:1528139910208};\\\", \\\"{x:1627,y:860,t:1528139910225};\\\", \\\"{x:1632,y:869,t:1528139910243};\\\", \\\"{x:1637,y:874,t:1528139910259};\\\", \\\"{x:1639,y:878,t:1528139910275};\\\", \\\"{x:1641,y:884,t:1528139910292};\\\", \\\"{x:1643,y:886,t:1528139910309};\\\", \\\"{x:1644,y:889,t:1528139910325};\\\", \\\"{x:1645,y:892,t:1528139910342};\\\", \\\"{x:1645,y:894,t:1528139910358};\\\", \\\"{x:1645,y:898,t:1528139910375};\\\", \\\"{x:1645,y:901,t:1528139910393};\\\", \\\"{x:1645,y:905,t:1528139910408};\\\", \\\"{x:1645,y:910,t:1528139910425};\\\", \\\"{x:1645,y:916,t:1528139910443};\\\", \\\"{x:1645,y:920,t:1528139910459};\\\", \\\"{x:1643,y:928,t:1528139910476};\\\", \\\"{x:1635,y:952,t:1528139910492};\\\", \\\"{x:1625,y:987,t:1528139910509};\\\", \\\"{x:1610,y:1015,t:1528139910526};\\\", \\\"{x:1587,y:1041,t:1528139910542};\\\", \\\"{x:1567,y:1062,t:1528139910559};\\\", \\\"{x:1552,y:1074,t:1528139910575};\\\", \\\"{x:1540,y:1083,t:1528139910592};\\\", \\\"{x:1535,y:1084,t:1528139910609};\\\", \\\"{x:1534,y:1085,t:1528139910625};\\\", \\\"{x:1534,y:1084,t:1528139910788};\\\", \\\"{x:1532,y:1079,t:1528139910795};\\\", \\\"{x:1532,y:1070,t:1528139910809};\\\", \\\"{x:1531,y:1055,t:1528139910825};\\\", \\\"{x:1530,y:1040,t:1528139910843};\\\", \\\"{x:1527,y:1024,t:1528139910860};\\\", \\\"{x:1525,y:1014,t:1528139910875};\\\", \\\"{x:1520,y:995,t:1528139910892};\\\", \\\"{x:1516,y:989,t:1528139910909};\\\", \\\"{x:1514,y:985,t:1528139910925};\\\", \\\"{x:1512,y:983,t:1528139910942};\\\", \\\"{x:1512,y:982,t:1528139910959};\\\", \\\"{x:1511,y:981,t:1528139910976};\\\", \\\"{x:1510,y:981,t:1528139910992};\\\", \\\"{x:1509,y:980,t:1528139911010};\\\", \\\"{x:1508,y:979,t:1528139911028};\\\", \\\"{x:1506,y:978,t:1528139911043};\\\", \\\"{x:1503,y:978,t:1528139911060};\\\", \\\"{x:1493,y:974,t:1528139911076};\\\", \\\"{x:1487,y:972,t:1528139911092};\\\", \\\"{x:1480,y:970,t:1528139911109};\\\", \\\"{x:1473,y:968,t:1528139911126};\\\", \\\"{x:1462,y:967,t:1528139911142};\\\", \\\"{x:1449,y:966,t:1528139911159};\\\", \\\"{x:1437,y:965,t:1528139911176};\\\", \\\"{x:1424,y:965,t:1528139911192};\\\", \\\"{x:1413,y:965,t:1528139911209};\\\", \\\"{x:1406,y:965,t:1528139911226};\\\", \\\"{x:1401,y:965,t:1528139911242};\\\", \\\"{x:1400,y:965,t:1528139911259};\\\", \\\"{x:1401,y:963,t:1528139911412};\\\", \\\"{x:1403,y:963,t:1528139911427};\\\", \\\"{x:1405,y:961,t:1528139911443};\\\", \\\"{x:1410,y:959,t:1528139911460};\\\", \\\"{x:1411,y:959,t:1528139911477};\\\", \\\"{x:1414,y:958,t:1528139911557};\\\", \\\"{x:1417,y:955,t:1528139911572};\\\", \\\"{x:1418,y:955,t:1528139911580};\\\", \\\"{x:1419,y:955,t:1528139911701};\\\", \\\"{x:1420,y:955,t:1528139911710};\\\", \\\"{x:1428,y:954,t:1528139911726};\\\", \\\"{x:1440,y:950,t:1528139911743};\\\", \\\"{x:1461,y:950,t:1528139911758};\\\", \\\"{x:1485,y:950,t:1528139911775};\\\", \\\"{x:1503,y:951,t:1528139911793};\\\", \\\"{x:1521,y:953,t:1528139911808};\\\", \\\"{x:1539,y:957,t:1528139911825};\\\", \\\"{x:1544,y:957,t:1528139911842};\\\", \\\"{x:1545,y:957,t:1528139911858};\\\", \\\"{x:1546,y:957,t:1528139911876};\\\", \\\"{x:1548,y:958,t:1528139911939};\\\", \\\"{x:1549,y:958,t:1528139911947};\\\", \\\"{x:1550,y:960,t:1528139911959};\\\", \\\"{x:1551,y:962,t:1528139911979};\\\", \\\"{x:1552,y:964,t:1528139911993};\\\", \\\"{x:1552,y:969,t:1528139912010};\\\", \\\"{x:1554,y:974,t:1528139912026};\\\", \\\"{x:1556,y:975,t:1528139912043};\\\", \\\"{x:1556,y:979,t:1528139912060};\\\", \\\"{x:1556,y:980,t:1528139912077};\\\", \\\"{x:1556,y:983,t:1528139912094};\\\", \\\"{x:1554,y:985,t:1528139912111};\\\", \\\"{x:1552,y:986,t:1528139912127};\\\", \\\"{x:1550,y:987,t:1528139912143};\\\", \\\"{x:1549,y:988,t:1528139912160};\\\", \\\"{x:1547,y:988,t:1528139912177};\\\", \\\"{x:1545,y:990,t:1528139912194};\\\", \\\"{x:1543,y:992,t:1528139912210};\\\", \\\"{x:1542,y:992,t:1528139912235};\\\", \\\"{x:1542,y:994,t:1528139912259};\\\", \\\"{x:1542,y:996,t:1528139912276};\\\", \\\"{x:1543,y:1000,t:1528139912292};\\\", \\\"{x:1545,y:1004,t:1528139912310};\\\", \\\"{x:1549,y:1011,t:1528139912326};\\\", \\\"{x:1553,y:1018,t:1528139912343};\\\", \\\"{x:1556,y:1025,t:1528139912360};\\\", \\\"{x:1561,y:1035,t:1528139912376};\\\", \\\"{x:1564,y:1041,t:1528139912393};\\\", \\\"{x:1566,y:1048,t:1528139912410};\\\", \\\"{x:1566,y:1049,t:1528139912426};\\\", \\\"{x:1568,y:1051,t:1528139912443};\\\", \\\"{x:1568,y:1052,t:1528139912460};\\\", \\\"{x:1568,y:1054,t:1528139912476};\\\", \\\"{x:1566,y:1055,t:1528139912812};\\\", \\\"{x:1565,y:1056,t:1528139912828};\\\", \\\"{x:1562,y:1057,t:1528139912843};\\\", \\\"{x:1559,y:1058,t:1528139912860};\\\", \\\"{x:1554,y:1060,t:1528139912877};\\\", \\\"{x:1552,y:1062,t:1528139912899};\\\", \\\"{x:1547,y:1063,t:1528139912910};\\\", \\\"{x:1543,y:1065,t:1528139912926};\\\", \\\"{x:1539,y:1067,t:1528139912943};\\\", \\\"{x:1536,y:1069,t:1528139912960};\\\", \\\"{x:1535,y:1070,t:1528139912976};\\\", \\\"{x:1530,y:1072,t:1528139912993};\\\", \\\"{x:1529,y:1073,t:1528139913010};\\\", \\\"{x:1526,y:1074,t:1528139913027};\\\", \\\"{x:1524,y:1076,t:1528139913044};\\\", \\\"{x:1522,y:1077,t:1528139913060};\\\", \\\"{x:1521,y:1077,t:1528139913083};\\\", \\\"{x:1519,y:1077,t:1528139915348};\\\", \\\"{x:1518,y:1076,t:1528139915363};\\\", \\\"{x:1517,y:1067,t:1528139915379};\\\", \\\"{x:1508,y:1051,t:1528139915396};\\\", \\\"{x:1498,y:1025,t:1528139915412};\\\", \\\"{x:1490,y:1006,t:1528139915428};\\\", \\\"{x:1481,y:984,t:1528139915446};\\\", \\\"{x:1474,y:959,t:1528139915463};\\\", \\\"{x:1470,y:942,t:1528139915479};\\\", \\\"{x:1463,y:920,t:1528139915495};\\\", \\\"{x:1461,y:903,t:1528139915512};\\\", \\\"{x:1457,y:887,t:1528139915528};\\\", \\\"{x:1456,y:877,t:1528139915545};\\\", \\\"{x:1455,y:871,t:1528139915562};\\\", \\\"{x:1454,y:870,t:1528139915579};\\\", \\\"{x:1454,y:869,t:1528139915916};\\\", \\\"{x:1454,y:868,t:1528139915930};\\\", \\\"{x:1455,y:867,t:1528139915964};\\\", \\\"{x:1458,y:860,t:1528139915979};\\\", \\\"{x:1458,y:859,t:1528139915996};\\\", \\\"{x:1459,y:851,t:1528139916012};\\\", \\\"{x:1459,y:843,t:1528139916029};\\\", \\\"{x:1459,y:831,t:1528139916046};\\\", \\\"{x:1459,y:821,t:1528139916063};\\\", \\\"{x:1462,y:807,t:1528139916080};\\\", \\\"{x:1463,y:795,t:1528139916097};\\\", \\\"{x:1464,y:784,t:1528139916113};\\\", \\\"{x:1464,y:776,t:1528139916130};\\\", \\\"{x:1464,y:770,t:1528139916147};\\\", \\\"{x:1464,y:768,t:1528139916163};\\\", \\\"{x:1466,y:768,t:1528139916236};\\\", \\\"{x:1467,y:768,t:1528139916246};\\\", \\\"{x:1474,y:772,t:1528139916263};\\\", \\\"{x:1482,y:780,t:1528139916280};\\\", \\\"{x:1485,y:793,t:1528139916297};\\\", \\\"{x:1492,y:817,t:1528139916313};\\\", \\\"{x:1499,y:845,t:1528139916330};\\\", \\\"{x:1504,y:871,t:1528139916346};\\\", \\\"{x:1508,y:895,t:1528139916363};\\\", \\\"{x:1509,y:913,t:1528139916379};\\\", \\\"{x:1510,y:923,t:1528139916396};\\\", \\\"{x:1511,y:926,t:1528139916413};\\\", \\\"{x:1512,y:928,t:1528139916429};\\\", \\\"{x:1511,y:928,t:1528139916549};\\\", \\\"{x:1510,y:928,t:1528139916563};\\\", \\\"{x:1504,y:924,t:1528139916579};\\\", \\\"{x:1497,y:921,t:1528139916596};\\\", \\\"{x:1491,y:918,t:1528139916613};\\\", \\\"{x:1480,y:913,t:1528139916630};\\\", \\\"{x:1476,y:912,t:1528139916647};\\\", \\\"{x:1474,y:912,t:1528139916663};\\\", \\\"{x:1474,y:911,t:1528139916679};\\\", \\\"{x:1474,y:910,t:1528139918844};\\\", \\\"{x:1471,y:898,t:1528139918852};\\\", \\\"{x:1468,y:883,t:1528139918864};\\\", \\\"{x:1457,y:838,t:1528139918881};\\\", \\\"{x:1448,y:795,t:1528139918897};\\\", \\\"{x:1438,y:756,t:1528139918914};\\\", \\\"{x:1434,y:738,t:1528139918931};\\\", \\\"{x:1430,y:729,t:1528139918947};\\\", \\\"{x:1430,y:727,t:1528139918964};\\\", \\\"{x:1430,y:726,t:1528139918981};\\\", \\\"{x:1430,y:725,t:1528139919036};\\\", \\\"{x:1431,y:725,t:1528139919164};\\\", \\\"{x:1436,y:723,t:1528139919182};\\\", \\\"{x:1441,y:722,t:1528139919199};\\\", \\\"{x:1447,y:718,t:1528139919214};\\\", \\\"{x:1452,y:717,t:1528139919232};\\\", \\\"{x:1462,y:712,t:1528139919249};\\\", \\\"{x:1471,y:705,t:1528139919265};\\\", \\\"{x:1486,y:694,t:1528139919282};\\\", \\\"{x:1495,y:687,t:1528139919298};\\\", \\\"{x:1506,y:678,t:1528139919315};\\\", \\\"{x:1520,y:664,t:1528139919332};\\\", \\\"{x:1527,y:655,t:1528139919348};\\\", \\\"{x:1530,y:650,t:1528139919365};\\\", \\\"{x:1532,y:647,t:1528139919381};\\\", \\\"{x:1532,y:645,t:1528139919399};\\\", \\\"{x:1532,y:643,t:1528139919415};\\\", \\\"{x:1532,y:640,t:1528139919431};\\\", \\\"{x:1532,y:639,t:1528139919449};\\\", \\\"{x:1531,y:641,t:1528139920436};\\\", \\\"{x:1530,y:658,t:1528139920449};\\\", \\\"{x:1537,y:693,t:1528139920466};\\\", \\\"{x:1545,y:749,t:1528139920483};\\\", \\\"{x:1545,y:816,t:1528139920499};\\\", \\\"{x:1534,y:946,t:1528139920515};\\\", \\\"{x:1515,y:1031,t:1528139920532};\\\", \\\"{x:1502,y:1112,t:1528139920549};\\\", \\\"{x:1493,y:1158,t:1528139920565};\\\", \\\"{x:1489,y:1188,t:1528139920583};\\\", \\\"{x:1486,y:1201,t:1528139920599};\\\", \\\"{x:1480,y:1203,t:1528139920615};\\\", \\\"{x:1467,y:1198,t:1528139920634};\\\", \\\"{x:1447,y:1182,t:1528139920650};\\\", \\\"{x:1406,y:1146,t:1528139920667};\\\", \\\"{x:1389,y:1124,t:1528139920684};\\\", \\\"{x:1373,y:1101,t:1528139920700};\\\", \\\"{x:1361,y:1079,t:1528139920717};\\\", \\\"{x:1357,y:1060,t:1528139920734};\\\", \\\"{x:1356,y:1051,t:1528139920751};\\\", \\\"{x:1355,y:1044,t:1528139920768};\\\", \\\"{x:1355,y:1042,t:1528139920784};\\\", \\\"{x:1355,y:1041,t:1528139920801};\\\", \\\"{x:1356,y:1040,t:1528139920817};\\\", \\\"{x:1358,y:1039,t:1528139920834};\\\", \\\"{x:1367,y:1033,t:1528139920851};\\\", \\\"{x:1374,y:1028,t:1528139920867};\\\", \\\"{x:1381,y:1022,t:1528139920885};\\\", \\\"{x:1389,y:1014,t:1528139920901};\\\", \\\"{x:1397,y:1005,t:1528139920917};\\\", \\\"{x:1405,y:999,t:1528139920934};\\\", \\\"{x:1416,y:989,t:1528139920951};\\\", \\\"{x:1421,y:980,t:1528139920967};\\\", \\\"{x:1429,y:972,t:1528139920984};\\\", \\\"{x:1436,y:961,t:1528139921002};\\\", \\\"{x:1443,y:953,t:1528139921018};\\\", \\\"{x:1451,y:945,t:1528139921035};\\\", \\\"{x:1470,y:930,t:1528139921051};\\\", \\\"{x:1489,y:918,t:1528139921068};\\\", \\\"{x:1502,y:908,t:1528139921084};\\\", \\\"{x:1504,y:906,t:1528139921212};\\\", \\\"{x:1504,y:905,t:1528139921220};\\\", \\\"{x:1504,y:904,t:1528139921236};\\\", \\\"{x:1503,y:903,t:1528139921252};\\\", \\\"{x:1501,y:902,t:1528139921269};\\\", \\\"{x:1498,y:902,t:1528139921285};\\\", \\\"{x:1496,y:901,t:1528139921302};\\\", \\\"{x:1489,y:898,t:1528139921319};\\\", \\\"{x:1486,y:895,t:1528139921334};\\\", \\\"{x:1485,y:894,t:1528139921352};\\\", \\\"{x:1484,y:892,t:1528139921369};\\\", \\\"{x:1483,y:892,t:1528139921384};\\\", \\\"{x:1482,y:889,t:1528139921402};\\\", \\\"{x:1481,y:885,t:1528139921419};\\\", \\\"{x:1480,y:880,t:1528139921435};\\\", \\\"{x:1480,y:873,t:1528139921453};\\\", \\\"{x:1480,y:867,t:1528139921469};\\\", \\\"{x:1480,y:860,t:1528139921485};\\\", \\\"{x:1480,y:853,t:1528139921501};\\\", \\\"{x:1480,y:848,t:1528139921519};\\\", \\\"{x:1480,y:845,t:1528139921535};\\\", \\\"{x:1480,y:843,t:1528139921552};\\\", \\\"{x:1480,y:839,t:1528139921569};\\\", \\\"{x:1479,y:837,t:1528139921585};\\\", \\\"{x:1479,y:835,t:1528139921602};\\\", \\\"{x:1478,y:834,t:1528139921618};\\\", \\\"{x:1478,y:832,t:1528139921636};\\\", \\\"{x:1478,y:831,t:1528139921781};\\\", \\\"{x:1479,y:830,t:1528139921804};\\\", \\\"{x:1480,y:829,t:1528139921868};\\\", \\\"{x:1481,y:828,t:1528139921899};\\\", \\\"{x:1482,y:827,t:1528139921949};\\\", \\\"{x:1481,y:827,t:1528139923348};\\\", \\\"{x:1480,y:827,t:1528139923372};\\\", \\\"{x:1479,y:827,t:1528139923387};\\\", \\\"{x:1478,y:827,t:1528139923404};\\\", \\\"{x:1473,y:828,t:1528139923421};\\\", \\\"{x:1468,y:829,t:1528139923437};\\\", \\\"{x:1464,y:829,t:1528139923454};\\\", \\\"{x:1463,y:829,t:1528139923470};\\\", \\\"{x:1462,y:829,t:1528139923487};\\\", \\\"{x:1460,y:829,t:1528139923504};\\\", \\\"{x:1459,y:828,t:1528139923520};\\\", \\\"{x:1458,y:827,t:1528139923536};\\\", \\\"{x:1458,y:825,t:1528139923554};\\\", \\\"{x:1457,y:823,t:1528139923570};\\\", \\\"{x:1457,y:819,t:1528139923587};\\\", \\\"{x:1456,y:817,t:1528139923604};\\\", \\\"{x:1456,y:815,t:1528139923619};\\\", \\\"{x:1456,y:812,t:1528139923637};\\\", \\\"{x:1458,y:811,t:1528139923654};\\\", \\\"{x:1458,y:810,t:1528139923684};\\\", \\\"{x:1459,y:810,t:1528139923700};\\\", \\\"{x:1460,y:809,t:1528139923716};\\\", \\\"{x:1460,y:808,t:1528139923732};\\\", \\\"{x:1461,y:808,t:1528139923748};\\\", \\\"{x:1461,y:807,t:1528139923772};\\\", \\\"{x:1461,y:805,t:1528139923787};\\\", \\\"{x:1454,y:796,t:1528139923804};\\\", \\\"{x:1427,y:780,t:1528139923820};\\\", \\\"{x:1391,y:765,t:1528139923837};\\\", \\\"{x:1368,y:757,t:1528139923854};\\\", \\\"{x:1347,y:748,t:1528139923871};\\\", \\\"{x:1334,y:740,t:1528139923887};\\\", \\\"{x:1331,y:739,t:1528139923904};\\\", \\\"{x:1331,y:738,t:1528139923921};\\\", \\\"{x:1332,y:737,t:1528139923996};\\\", \\\"{x:1334,y:737,t:1528139924004};\\\", \\\"{x:1338,y:735,t:1528139924020};\\\", \\\"{x:1345,y:735,t:1528139924037};\\\", \\\"{x:1354,y:735,t:1528139924054};\\\", \\\"{x:1369,y:735,t:1528139924070};\\\", \\\"{x:1386,y:736,t:1528139924087};\\\", \\\"{x:1410,y:738,t:1528139924104};\\\", \\\"{x:1437,y:744,t:1528139924121};\\\", \\\"{x:1468,y:747,t:1528139924136};\\\", \\\"{x:1492,y:752,t:1528139924154};\\\", \\\"{x:1513,y:755,t:1528139924171};\\\", \\\"{x:1523,y:758,t:1528139924188};\\\", \\\"{x:1524,y:758,t:1528139924204};\\\", \\\"{x:1525,y:758,t:1528139924221};\\\", \\\"{x:1525,y:759,t:1528139924292};\\\", \\\"{x:1524,y:761,t:1528139924304};\\\", \\\"{x:1515,y:761,t:1528139924321};\\\", \\\"{x:1493,y:757,t:1528139924339};\\\", \\\"{x:1469,y:751,t:1528139924354};\\\", \\\"{x:1441,y:747,t:1528139924371};\\\", \\\"{x:1398,y:743,t:1528139924388};\\\", \\\"{x:1374,y:741,t:1528139924404};\\\", \\\"{x:1361,y:737,t:1528139924421};\\\", \\\"{x:1342,y:736,t:1528139924438};\\\", \\\"{x:1330,y:732,t:1528139924454};\\\", \\\"{x:1327,y:732,t:1528139924471};\\\", \\\"{x:1327,y:731,t:1528139924557};\\\", \\\"{x:1328,y:730,t:1528139924572};\\\", \\\"{x:1331,y:728,t:1528139924588};\\\", \\\"{x:1335,y:726,t:1528139924604};\\\", \\\"{x:1337,y:724,t:1528139924621};\\\", \\\"{x:1341,y:721,t:1528139924638};\\\", \\\"{x:1343,y:719,t:1528139924654};\\\", \\\"{x:1346,y:714,t:1528139924671};\\\", \\\"{x:1347,y:712,t:1528139924688};\\\", \\\"{x:1348,y:709,t:1528139924705};\\\", \\\"{x:1348,y:705,t:1528139924721};\\\", \\\"{x:1348,y:701,t:1528139924739};\\\", \\\"{x:1348,y:697,t:1528139924755};\\\", \\\"{x:1348,y:694,t:1528139924771};\\\", \\\"{x:1348,y:688,t:1528139924788};\\\", \\\"{x:1348,y:687,t:1528139924804};\\\", \\\"{x:1348,y:686,t:1528139924821};\\\", \\\"{x:1348,y:685,t:1528139924843};\\\", \\\"{x:1349,y:684,t:1528139925100};\\\", \\\"{x:1351,y:684,t:1528139925108};\\\", \\\"{x:1351,y:686,t:1528139925124};\\\", \\\"{x:1351,y:688,t:1528139925141};\\\", \\\"{x:1351,y:689,t:1528139925156};\\\", \\\"{x:1351,y:690,t:1528139925172};\\\", \\\"{x:1350,y:692,t:1528139925188};\\\", \\\"{x:1349,y:693,t:1528139925221};\\\", \\\"{x:1348,y:694,t:1528139925244};\\\", \\\"{x:1347,y:695,t:1528139925260};\\\", \\\"{x:1346,y:696,t:1528139925484};\\\", \\\"{x:1338,y:696,t:1528139925861};\\\", \\\"{x:1327,y:697,t:1528139925872};\\\", \\\"{x:1300,y:702,t:1528139925889};\\\", \\\"{x:1269,y:704,t:1528139925905};\\\", \\\"{x:1246,y:704,t:1528139925922};\\\", \\\"{x:1234,y:704,t:1528139925939};\\\", \\\"{x:1233,y:704,t:1528139925956};\\\", \\\"{x:1234,y:704,t:1528139926052};\\\", \\\"{x:1236,y:704,t:1528139926060};\\\", \\\"{x:1239,y:704,t:1528139926071};\\\", \\\"{x:1241,y:704,t:1528139926089};\\\", \\\"{x:1244,y:704,t:1528139926106};\\\", \\\"{x:1248,y:706,t:1528139926121};\\\", \\\"{x:1251,y:706,t:1528139926138};\\\", \\\"{x:1254,y:707,t:1528139926156};\\\", \\\"{x:1254,y:708,t:1528139926180};\\\", \\\"{x:1254,y:710,t:1528139926204};\\\", \\\"{x:1250,y:712,t:1528139926212};\\\", \\\"{x:1245,y:716,t:1528139926222};\\\", \\\"{x:1235,y:721,t:1528139926239};\\\", \\\"{x:1220,y:728,t:1528139926256};\\\", \\\"{x:1209,y:730,t:1528139926272};\\\", \\\"{x:1197,y:733,t:1528139926289};\\\", \\\"{x:1192,y:734,t:1528139926306};\\\", \\\"{x:1189,y:734,t:1528139926323};\\\", \\\"{x:1188,y:735,t:1528139926549};\\\", \\\"{x:1188,y:738,t:1528139926556};\\\", \\\"{x:1189,y:750,t:1528139926572};\\\", \\\"{x:1190,y:761,t:1528139926589};\\\", \\\"{x:1190,y:771,t:1528139926606};\\\", \\\"{x:1190,y:783,t:1528139926622};\\\", \\\"{x:1190,y:789,t:1528139926639};\\\", \\\"{x:1189,y:795,t:1528139926655};\\\", \\\"{x:1189,y:796,t:1528139926672};\\\", \\\"{x:1189,y:797,t:1528139926689};\\\", \\\"{x:1189,y:798,t:1528139926706};\\\", \\\"{x:1189,y:799,t:1528139926732};\\\", \\\"{x:1190,y:799,t:1528139926796};\\\", \\\"{x:1192,y:799,t:1528139926806};\\\", \\\"{x:1199,y:799,t:1528139926823};\\\", \\\"{x:1209,y:803,t:1528139926840};\\\", \\\"{x:1218,y:809,t:1528139926856};\\\", \\\"{x:1229,y:817,t:1528139926873};\\\", \\\"{x:1236,y:823,t:1528139926890};\\\", \\\"{x:1240,y:830,t:1528139926906};\\\", \\\"{x:1242,y:836,t:1528139926923};\\\", \\\"{x:1243,y:843,t:1528139926940};\\\", \\\"{x:1243,y:845,t:1528139926956};\\\", \\\"{x:1243,y:846,t:1528139926973};\\\", \\\"{x:1243,y:847,t:1528139927036};\\\", \\\"{x:1243,y:849,t:1528139927043};\\\", \\\"{x:1242,y:850,t:1528139927056};\\\", \\\"{x:1235,y:850,t:1528139927073};\\\", \\\"{x:1226,y:850,t:1528139927090};\\\", \\\"{x:1218,y:850,t:1528139927106};\\\", \\\"{x:1215,y:850,t:1528139927123};\\\", \\\"{x:1214,y:850,t:1528139927141};\\\", \\\"{x:1212,y:849,t:1528139927156};\\\", \\\"{x:1212,y:847,t:1528139927180};\\\", \\\"{x:1212,y:846,t:1528139927190};\\\", \\\"{x:1212,y:843,t:1528139927206};\\\", \\\"{x:1212,y:838,t:1528139927223};\\\", \\\"{x:1212,y:832,t:1528139927241};\\\", \\\"{x:1212,y:827,t:1528139927257};\\\", \\\"{x:1212,y:823,t:1528139927274};\\\", \\\"{x:1213,y:815,t:1528139927290};\\\", \\\"{x:1213,y:812,t:1528139927307};\\\", \\\"{x:1214,y:807,t:1528139927324};\\\", \\\"{x:1215,y:797,t:1528139927339};\\\", \\\"{x:1216,y:792,t:1528139927357};\\\", \\\"{x:1217,y:785,t:1528139927373};\\\", \\\"{x:1220,y:776,t:1528139927391};\\\", \\\"{x:1226,y:765,t:1528139927406};\\\", \\\"{x:1230,y:752,t:1528139927423};\\\", \\\"{x:1234,y:736,t:1528139927442};\\\", \\\"{x:1240,y:720,t:1528139927457};\\\", \\\"{x:1244,y:701,t:1528139927473};\\\", \\\"{x:1248,y:685,t:1528139927489};\\\", \\\"{x:1250,y:670,t:1528139927508};\\\", \\\"{x:1250,y:656,t:1528139927523};\\\", \\\"{x:1251,y:637,t:1528139927540};\\\", \\\"{x:1253,y:622,t:1528139927557};\\\", \\\"{x:1256,y:608,t:1528139927573};\\\", \\\"{x:1260,y:592,t:1528139927590};\\\", \\\"{x:1262,y:578,t:1528139927607};\\\", \\\"{x:1266,y:568,t:1528139927624};\\\", \\\"{x:1267,y:565,t:1528139927642};\\\", \\\"{x:1269,y:562,t:1528139927657};\\\", \\\"{x:1270,y:562,t:1528139927674};\\\", \\\"{x:1270,y:561,t:1528139927691};\\\", \\\"{x:1271,y:560,t:1528139927707};\\\", \\\"{x:1276,y:558,t:1528139927724};\\\", \\\"{x:1280,y:556,t:1528139927740};\\\", \\\"{x:1284,y:555,t:1528139927757};\\\", \\\"{x:1286,y:555,t:1528139927774};\\\", \\\"{x:1287,y:555,t:1528139927789};\\\", \\\"{x:1288,y:555,t:1528139927820};\\\", \\\"{x:1287,y:556,t:1528139928047};\\\", \\\"{x:1287,y:557,t:1528139928079};\\\", \\\"{x:1286,y:557,t:1528139928103};\\\", \\\"{x:1286,y:559,t:1528139928111};\\\", \\\"{x:1284,y:560,t:1528139928127};\\\", \\\"{x:1283,y:561,t:1528139928167};\\\", \\\"{x:1283,y:562,t:1528139928191};\\\", \\\"{x:1282,y:562,t:1528139928199};\\\", \\\"{x:1281,y:563,t:1528139928210};\\\", \\\"{x:1281,y:565,t:1528139928232};\\\", \\\"{x:1280,y:566,t:1528139928245};\\\", \\\"{x:1280,y:567,t:1528139928260};\\\", \\\"{x:1280,y:568,t:1528139928278};\\\", \\\"{x:1280,y:569,t:1528139928593};\\\", \\\"{x:1281,y:569,t:1528139928632};\\\", \\\"{x:1282,y:569,t:1528139928647};\\\", \\\"{x:1284,y:569,t:1528139928661};\\\", \\\"{x:1285,y:569,t:1528139928744};\\\", \\\"{x:1286,y:569,t:1528139928759};\\\", \\\"{x:1287,y:568,t:1528139928800};\\\", \\\"{x:1288,y:568,t:1528139928904};\\\", \\\"{x:1289,y:568,t:1528139928968};\\\", \\\"{x:1290,y:568,t:1528139929304};\\\", \\\"{x:1291,y:568,t:1528139929311};\\\", \\\"{x:1295,y:570,t:1528139929329};\\\", \\\"{x:1296,y:572,t:1528139929345};\\\", \\\"{x:1297,y:573,t:1528139929362};\\\", \\\"{x:1298,y:574,t:1528139929379};\\\", \\\"{x:1299,y:575,t:1528139929396};\\\", \\\"{x:1300,y:576,t:1528139929412};\\\", \\\"{x:1301,y:576,t:1528139929448};\\\", \\\"{x:1302,y:576,t:1528139929472};\\\", \\\"{x:1303,y:576,t:1528139929487};\\\", \\\"{x:1304,y:577,t:1528139929496};\\\", \\\"{x:1305,y:577,t:1528139929511};\\\", \\\"{x:1307,y:578,t:1528139929528};\\\", \\\"{x:1312,y:579,t:1528139929546};\\\", \\\"{x:1317,y:581,t:1528139929562};\\\", \\\"{x:1321,y:581,t:1528139929579};\\\", \\\"{x:1323,y:582,t:1528139929596};\\\", \\\"{x:1324,y:582,t:1528139929611};\\\", \\\"{x:1325,y:582,t:1528139929639};\\\", \\\"{x:1326,y:582,t:1528139929712};\\\", \\\"{x:1327,y:582,t:1528139929729};\\\", \\\"{x:1330,y:581,t:1528139929746};\\\", \\\"{x:1332,y:581,t:1528139929762};\\\", \\\"{x:1334,y:579,t:1528139929779};\\\", \\\"{x:1336,y:579,t:1528139929799};\\\", \\\"{x:1337,y:578,t:1528139929824};\\\", \\\"{x:1339,y:578,t:1528139929847};\\\", \\\"{x:1340,y:577,t:1528139929864};\\\", \\\"{x:1341,y:576,t:1528139929880};\\\", \\\"{x:1343,y:576,t:1528139929904};\\\", \\\"{x:1343,y:575,t:1528139929928};\\\", \\\"{x:1345,y:574,t:1528139929968};\\\", \\\"{x:1346,y:574,t:1528139929991};\\\", \\\"{x:1346,y:573,t:1528139930008};\\\", \\\"{x:1347,y:573,t:1528139930031};\\\", \\\"{x:1347,y:572,t:1528139930047};\\\", \\\"{x:1349,y:571,t:1528139930064};\\\", \\\"{x:1349,y:570,t:1528139930079};\\\", \\\"{x:1349,y:569,t:1528139930096};\\\", \\\"{x:1349,y:568,t:1528139930113};\\\", \\\"{x:1349,y:567,t:1528139930129};\\\", \\\"{x:1349,y:566,t:1528139930184};\\\", \\\"{x:1349,y:565,t:1528139930208};\\\", \\\"{x:1349,y:564,t:1528139930240};\\\", \\\"{x:1348,y:564,t:1528139930255};\\\", \\\"{x:1347,y:563,t:1528139930279};\\\", \\\"{x:1346,y:563,t:1528139930335};\\\", \\\"{x:1345,y:561,t:1528139930345};\\\", \\\"{x:1344,y:561,t:1528139930362};\\\", \\\"{x:1345,y:561,t:1528139930943};\\\", \\\"{x:1346,y:561,t:1528139930952};\\\", \\\"{x:1347,y:562,t:1528139930964};\\\", \\\"{x:1351,y:565,t:1528139930980};\\\", \\\"{x:1354,y:568,t:1528139930997};\\\", \\\"{x:1357,y:574,t:1528139931013};\\\", \\\"{x:1361,y:577,t:1528139931030};\\\", \\\"{x:1363,y:579,t:1528139931047};\\\", \\\"{x:1367,y:582,t:1528139931063};\\\", \\\"{x:1373,y:585,t:1528139931080};\\\", \\\"{x:1374,y:585,t:1528139931104};\\\", \\\"{x:1375,y:585,t:1528139931120};\\\", \\\"{x:1376,y:585,t:1528139931130};\\\", \\\"{x:1377,y:586,t:1528139931147};\\\", \\\"{x:1379,y:586,t:1528139931164};\\\", \\\"{x:1381,y:586,t:1528139931180};\\\", \\\"{x:1384,y:586,t:1528139931197};\\\", \\\"{x:1385,y:586,t:1528139931214};\\\", \\\"{x:1386,y:586,t:1528139931230};\\\", \\\"{x:1387,y:586,t:1528139931247};\\\", \\\"{x:1395,y:585,t:1528139931264};\\\", \\\"{x:1400,y:584,t:1528139931280};\\\", \\\"{x:1406,y:582,t:1528139931297};\\\", \\\"{x:1408,y:581,t:1528139931314};\\\", \\\"{x:1410,y:581,t:1528139931330};\\\", \\\"{x:1412,y:580,t:1528139931347};\\\", \\\"{x:1412,y:579,t:1528139931364};\\\", \\\"{x:1414,y:579,t:1528139931380};\\\", \\\"{x:1414,y:578,t:1528139931408};\\\", \\\"{x:1415,y:577,t:1528139931423};\\\", \\\"{x:1415,y:576,t:1528139931472};\\\", \\\"{x:1415,y:575,t:1528139931496};\\\", \\\"{x:1415,y:573,t:1528139931514};\\\", \\\"{x:1418,y:571,t:1528139931531};\\\", \\\"{x:1421,y:568,t:1528139931547};\\\", \\\"{x:1424,y:566,t:1528139931564};\\\", \\\"{x:1424,y:565,t:1528139931584};\\\", \\\"{x:1424,y:564,t:1528139931597};\\\", \\\"{x:1424,y:563,t:1528139931614};\\\", \\\"{x:1424,y:562,t:1528139931632};\\\", \\\"{x:1424,y:561,t:1528139931648};\\\", \\\"{x:1424,y:558,t:1528139931664};\\\", \\\"{x:1420,y:556,t:1528139931681};\\\", \\\"{x:1418,y:556,t:1528139931856};\\\", \\\"{x:1417,y:556,t:1528139931879};\\\", \\\"{x:1414,y:557,t:1528139931897};\\\", \\\"{x:1413,y:557,t:1528139931914};\\\", \\\"{x:1411,y:559,t:1528139931931};\\\", \\\"{x:1410,y:560,t:1528139931964};\\\", \\\"{x:1410,y:561,t:1528139931981};\\\", \\\"{x:1410,y:562,t:1528139932056};\\\", \\\"{x:1411,y:563,t:1528139932688};\\\", \\\"{x:1413,y:563,t:1528139932711};\\\", \\\"{x:1414,y:565,t:1528139932719};\\\", \\\"{x:1415,y:565,t:1528139932731};\\\", \\\"{x:1417,y:566,t:1528139932748};\\\", \\\"{x:1419,y:567,t:1528139932766};\\\", \\\"{x:1421,y:569,t:1528139932781};\\\", \\\"{x:1423,y:569,t:1528139932798};\\\", \\\"{x:1430,y:573,t:1528139932815};\\\", \\\"{x:1437,y:574,t:1528139932832};\\\", \\\"{x:1442,y:576,t:1528139932848};\\\", \\\"{x:1443,y:576,t:1528139932865};\\\", \\\"{x:1444,y:576,t:1528139932882};\\\", \\\"{x:1446,y:576,t:1528139932898};\\\", \\\"{x:1448,y:576,t:1528139932915};\\\", \\\"{x:1455,y:576,t:1528139932932};\\\", \\\"{x:1468,y:576,t:1528139932948};\\\", \\\"{x:1481,y:575,t:1528139932965};\\\", \\\"{x:1488,y:574,t:1528139932982};\\\", \\\"{x:1496,y:573,t:1528139932998};\\\", \\\"{x:1500,y:572,t:1528139933015};\\\", \\\"{x:1501,y:571,t:1528139933032};\\\", \\\"{x:1502,y:571,t:1528139933048};\\\", \\\"{x:1502,y:569,t:1528139933112};\\\", \\\"{x:1502,y:568,t:1528139933136};\\\", \\\"{x:1502,y:567,t:1528139933148};\\\", \\\"{x:1501,y:566,t:1528139933165};\\\", \\\"{x:1500,y:566,t:1528139933182};\\\", \\\"{x:1497,y:565,t:1528139933198};\\\", \\\"{x:1496,y:564,t:1528139933215};\\\", \\\"{x:1495,y:564,t:1528139933232};\\\", \\\"{x:1494,y:564,t:1528139933248};\\\", \\\"{x:1493,y:563,t:1528139933265};\\\", \\\"{x:1491,y:563,t:1528139933384};\\\", \\\"{x:1491,y:562,t:1528139933400};\\\", \\\"{x:1490,y:562,t:1528139933448};\\\", \\\"{x:1490,y:561,t:1528139933465};\\\", \\\"{x:1488,y:561,t:1528139933482};\\\", \\\"{x:1486,y:560,t:1528139933499};\\\", \\\"{x:1483,y:559,t:1528139933515};\\\", \\\"{x:1480,y:557,t:1528139933532};\\\", \\\"{x:1479,y:557,t:1528139933549};\\\", \\\"{x:1480,y:558,t:1528139935120};\\\", \\\"{x:1480,y:559,t:1528139935134};\\\", \\\"{x:1480,y:561,t:1528139935151};\\\", \\\"{x:1480,y:562,t:1528139935167};\\\", \\\"{x:1480,y:564,t:1528139935184};\\\", \\\"{x:1480,y:567,t:1528139936456};\\\", \\\"{x:1474,y:570,t:1528139936469};\\\", \\\"{x:1452,y:575,t:1528139936484};\\\", \\\"{x:1411,y:580,t:1528139936502};\\\", \\\"{x:1344,y:589,t:1528139936518};\\\", \\\"{x:1228,y:601,t:1528139936534};\\\", \\\"{x:938,y:608,t:1528139936552};\\\", \\\"{x:692,y:606,t:1528139936568};\\\", \\\"{x:430,y:606,t:1528139936584};\\\", \\\"{x:173,y:606,t:1528139936601};\\\", \\\"{x:54,y:606,t:1528139936611};\\\", \\\"{x:0,y:604,t:1528139936629};\\\", \\\"{x:0,y:602,t:1528139936679};\\\", \\\"{x:3,y:600,t:1528139936718};\\\", \\\"{x:43,y:594,t:1528139936735};\\\", \\\"{x:131,y:583,t:1528139936751};\\\", \\\"{x:240,y:565,t:1528139936768};\\\", \\\"{x:356,y:548,t:1528139936785};\\\", \\\"{x:472,y:534,t:1528139936802};\\\", \\\"{x:562,y:519,t:1528139936818};\\\", \\\"{x:611,y:514,t:1528139936834};\\\", \\\"{x:636,y:511,t:1528139936852};\\\", \\\"{x:649,y:509,t:1528139936868};\\\", \\\"{x:654,y:509,t:1528139936885};\\\", \\\"{x:659,y:509,t:1528139936902};\\\", \\\"{x:663,y:509,t:1528139936917};\\\", \\\"{x:683,y:514,t:1528139936935};\\\", \\\"{x:701,y:520,t:1528139936952};\\\", \\\"{x:724,y:525,t:1528139936969};\\\", \\\"{x:737,y:529,t:1528139936984};\\\", \\\"{x:738,y:529,t:1528139937001};\\\", \\\"{x:733,y:529,t:1528139937023};\\\", \\\"{x:732,y:527,t:1528139937035};\\\", \\\"{x:730,y:523,t:1528139937052};\\\", \\\"{x:730,y:521,t:1528139937232};\\\", \\\"{x:729,y:519,t:1528139937239};\\\", \\\"{x:726,y:518,t:1528139937251};\\\", \\\"{x:707,y:517,t:1528139937270};\\\", \\\"{x:681,y:516,t:1528139937284};\\\", \\\"{x:645,y:513,t:1528139937301};\\\", \\\"{x:587,y:513,t:1528139937318};\\\", \\\"{x:562,y:513,t:1528139937334};\\\", \\\"{x:552,y:513,t:1528139937351};\\\", \\\"{x:551,y:513,t:1528139937368};\\\", \\\"{x:550,y:513,t:1528139937384};\\\", \\\"{x:553,y:512,t:1528139937487};\\\", \\\"{x:558,y:512,t:1528139937502};\\\", \\\"{x:574,y:509,t:1528139937519};\\\", \\\"{x:582,y:507,t:1528139937535};\\\", \\\"{x:587,y:507,t:1528139937552};\\\", \\\"{x:590,y:507,t:1528139937569};\\\", \\\"{x:594,y:507,t:1528139937586};\\\", \\\"{x:601,y:507,t:1528139937603};\\\", \\\"{x:609,y:507,t:1528139937619};\\\", \\\"{x:616,y:507,t:1528139937636};\\\", \\\"{x:619,y:507,t:1528139937651};\\\", \\\"{x:620,y:507,t:1528139937668};\\\", \\\"{x:618,y:507,t:1528139937991};\\\", \\\"{x:617,y:508,t:1528139938003};\\\", \\\"{x:610,y:523,t:1528139938019};\\\", \\\"{x:603,y:544,t:1528139938036};\\\", \\\"{x:591,y:577,t:1528139938053};\\\", \\\"{x:583,y:608,t:1528139938069};\\\", \\\"{x:577,y:630,t:1528139938086};\\\", \\\"{x:573,y:650,t:1528139938103};\\\", \\\"{x:572,y:658,t:1528139938119};\\\", \\\"{x:570,y:662,t:1528139938135};\\\", \\\"{x:569,y:669,t:1528139938153};\\\", \\\"{x:565,y:678,t:1528139938168};\\\", \\\"{x:561,y:686,t:1528139938185};\\\", \\\"{x:559,y:696,t:1528139938203};\\\", \\\"{x:556,y:705,t:1528139938219};\\\", \\\"{x:554,y:711,t:1528139938236};\\\", \\\"{x:553,y:715,t:1528139938253};\\\", \\\"{x:552,y:716,t:1528139938269};\\\", \\\"{x:551,y:718,t:1528139938286};\\\", \\\"{x:549,y:720,t:1528139938303};\\\", \\\"{x:546,y:725,t:1528139938320};\\\", \\\"{x:542,y:728,t:1528139938336};\\\", \\\"{x:538,y:732,t:1528139938353};\\\", \\\"{x:530,y:741,t:1528139938371};\\\", \\\"{x:524,y:751,t:1528139938386};\\\", \\\"{x:516,y:765,t:1528139938403};\\\", \\\"{x:514,y:771,t:1528139938421};\\\", \\\"{x:513,y:773,t:1528139938436};\\\", \\\"{x:513,y:774,t:1528139938462};\\\", \\\"{x:513,y:773,t:1528139938696};\\\", \\\"{x:513,y:768,t:1528139938703};\\\", \\\"{x:513,y:755,t:1528139938719};\\\", \\\"{x:513,y:744,t:1528139938736};\\\", \\\"{x:513,y:736,t:1528139938753};\\\", \\\"{x:514,y:731,t:1528139938771};\\\", \\\"{x:514,y:735,t:1528139939033};\\\", \\\"{x:515,y:741,t:1528139939052};\\\", \\\"{x:516,y:746,t:1528139939069};\\\", \\\"{x:518,y:753,t:1528139939086};\\\", \\\"{x:518,y:754,t:1528139939103};\\\", \\\"{x:519,y:754,t:1528139939120};\\\" ] }, { \\\"rt\\\": 33049, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 20, \\\"time_elapsed\\\": 766475, \\\"internal_node_id\\\": \\\"0.0-7.0-0.0\\\", \\\"subject\\\": \\\"S6D2F\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"q\\\": 16, \\\"answer\\\": \\\"By looking at the x-axis where 12pm is labeled then going upward to see what points are plotted\\\", \\\"block\\\": \\\"triangular_testing\\\" }, { \\\"rt\\\": 9742, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"18\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"America\\\\\\\"}\\\", \\\"block\\\": \\\"demo-1\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 21, \\\"time_elapsed\\\": 777224, \\\"internal_node_id\\\": \\\"0.0-8.0\\\", \\\"subject\\\": \\\"S6D2F\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\" }, { \\\"rt\\\": 14847, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"English\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"First\\\\\\\",\\\\\\\"Q2\\\\\\\":\\\\\\\"Biomedical & Health Sciences\\\\\\\",\\\\\\\"Q3\\\\\\\":\\\\\\\"Female\\\\\\\"}\\\", \\\"block\\\": \\\"demo-2\\\", \\\"trial_type\\\": \\\"survey-multi-choice\\\", \\\"trial_index\\\": 22, \\\"time_elapsed\\\": 793086, \\\"internal_node_id\\\": \\\"0.0-9.0\\\", \\\"subject\\\": \\\"S6D2F\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\" }, { \\\"rt\\\": 2421, \\\"url\\\": \\\"../views/src/external/debrief.html\\\", \\\"block\\\": \\\"debrief\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 23, \\\"time_elapsed\\\": 796838, \\\"internal_node_id\\\": \\\"0.0-10.0\\\", \\\"subject\\\": \\\"S6D2F\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\" } ]\",\"parentNode\":{\"id\":2765}}],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"META\",\"attributes\":{\"charset\":\"utf-8\"}},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":8,\"id\":59},{\"nodeType\":3,\"id\":60,\"textContent\":\" \"},{\"nodeType\":1,\"id\":61,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":62,\"textContent\":\" \"},{\"nodeType\":1,\"id\":63,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":64,\"textContent\":\" \"},{\"nodeType\":1,\"id\":65,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":66,\"textContent\":\" \"},{\"nodeType\":1,\"id\":67,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":68,\"textContent\":\" \"},{\"nodeType\":1,\"id\":69,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":70,\"textContent\":\" \"},{\"nodeType\":1,\"id\":71,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":72,\"textContent\":\" \"},{\"nodeType\":1,\"id\":73,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"stimulus\"},\"childNodes\":[{\"nodeType\":3,\"id\":74,\"textContent\":\" \"},{\"nodeType\":1,\"id\":75,\"tagName\":\"P\",\"attributes\":{\"class\":\"userid\",\"id\":\"userid\"},\"childNodes\":[{\"nodeType\":3,\"id\":76,\"textContent\":\"S6D2F\"}]},{\"nodeType\":3,\"id\":77,\"textContent\":\" \"},{\"nodeType\":1,\"id\":78,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"userinput\"},\"childNodes\":[{\"nodeType\":3,\"id\":79,\"textContent\":\" \"},{\"nodeType\":8,\"id\":80},{\"nodeType\":3,\"id\":81,\"textContent\":\" \"},{\"nodeType\":1,\"id\":82,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"legend\",\"id\":\"hint-interactive\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":83,\"textContent\":\" \"},{\"nodeType\":1,\"id\":84,\"tagName\":\"P\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":85,\"textContent\":\"Hint: Hover your mouse over the data points in the graph\"}]},{\"nodeType\":3,\"id\":86,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":87,\"textContent\":\" \"},{\"nodeType\":8,\"id\":88},{\"nodeType\":3,\"id\":89,\"textContent\":\" \"},{\"nodeType\":8,\"id\":90},{\"nodeType\":3,\"id\":91,\"textContent\":\" \"},{\"nodeType\":1,\"id\":92,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"test\"},\"childNodes\":[{\"nodeType\":3,\"id\":93,\"textContent\":\" \"},{\"nodeType\":1,\"id\":94,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":95,\"textContent\":\" \"},{\"nodeType\":1,\"id\":96,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":97,\"textContent\":\"Which shift(s) start at 11 am? \"}]},{\"nodeType\":3,\"id\":98,\"textContent\":\" \"},{\"nodeType\":1,\"id\":99,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":100,\"textContent\":\" \"},{\"nodeType\":1,\"id\":101,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":102,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":103,\"textContent\":\" \"},{\"nodeType\":1,\"id\":104,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":105,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":106,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":107,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":108,\"textContent\":\" \"},{\"nodeType\":1,\"id\":109,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":110,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":111,\"textContent\":\" \"},{\"nodeType\":1,\"id\":112,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":113,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":115,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":116,\"textContent\":\" \"},{\"nodeType\":1,\"id\":117,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":118,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":120,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":121,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":122,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":123,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":125,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":126,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":127,\"textContent\":\" \"},{\"nodeType\":1,\"id\":128,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":129,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":130,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":132,\"textContent\":\" \"},{\"nodeType\":1,\"id\":133,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":134,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":135,\"textContent\":\" \"},{\"nodeType\":1,\"id\":136,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":137,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":138,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":140,\"textContent\":\" \"},{\"nodeType\":1,\"id\":141,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":142,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":143,\"textContent\":\" \"},{\"nodeType\":1,\"id\":144,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":145,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":146,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":147,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":148,\"textContent\":\" \"},{\"nodeType\":1,\"id\":149,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":150,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":151,\"textContent\":\" \"},{\"nodeType\":1,\"id\":152,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":153,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":154,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":156,\"textContent\":\" \"},{\"nodeType\":1,\"id\":157,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":158,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":159,\"textContent\":\" \"},{\"nodeType\":1,\"id\":160,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":161,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":162,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":163,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":164,\"textContent\":\" \"},{\"nodeType\":1,\"id\":165,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":166,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":167,\"textContent\":\" \"},{\"nodeType\":1,\"id\":168,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":169,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":170,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":171,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":172,\"textContent\":\" \"},{\"nodeType\":1,\"id\":173,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":174,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":175,\"textContent\":\" \"},{\"nodeType\":1,\"id\":176,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":177,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":178,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":179,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":180,\"textContent\":\" \"},{\"nodeType\":1,\"id\":181,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":182,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":183,\"textContent\":\" \"},{\"nodeType\":1,\"id\":184,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":185,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":186,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":187,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":188,\"textContent\":\" \"},{\"nodeType\":1,\"id\":189,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":190,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":191,\"textContent\":\" \"},{\"nodeType\":1,\"id\":192,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":193,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":194,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":196,\"textContent\":\" \"},{\"nodeType\":1,\"id\":197,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":198,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":200,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":201,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":202,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":203,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":205,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":206,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":207,\"textContent\":\" \"},{\"nodeType\":1,\"id\":208,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":209,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":210,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":211,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":212,\"textContent\":\" \"},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":214,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":215,\"textContent\":\" \"},{\"nodeType\":1,\"id\":216,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":217,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":218,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":219,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":220,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":221,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":223,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":224,\"textContent\":\" \"},{\"nodeType\":1,\"id\":225,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":226,\"textContent\":\"Which shift(s) start at the same time as D?\"}]},{\"nodeType\":3,\"id\":227,\"textContent\":\" \"},{\"nodeType\":1,\"id\":228,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":229,\"textContent\":\" \"},{\"nodeType\":1,\"id\":230,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":231,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":232,\"textContent\":\" \"},{\"nodeType\":1,\"id\":233,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":234,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":235,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":236,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":237,\"textContent\":\" \"},{\"nodeType\":1,\"id\":238,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":239,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":240,\"textContent\":\" \"},{\"nodeType\":1,\"id\":241,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":242,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":243,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":244,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":245,\"textContent\":\" \"},{\"nodeType\":1,\"id\":246,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":247,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":248,\"textContent\":\" \"},{\"nodeType\":1,\"id\":249,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":250,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":251,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":252,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":253,\"textContent\":\" \"},{\"nodeType\":1,\"id\":254,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":255,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":256,\"textContent\":\" \"},{\"nodeType\":1,\"id\":257,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":258,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":259,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":260,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":261,\"textContent\":\" \"},{\"nodeType\":1,\"id\":262,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":263,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":264,\"textContent\":\" \"},{\"nodeType\":1,\"id\":265,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":266,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":267,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":268,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":269,\"textContent\":\" \"},{\"nodeType\":1,\"id\":270,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":271,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":273,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":274,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":275,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":276,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":278,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":279,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":280,\"textContent\":\" \"},{\"nodeType\":1,\"id\":281,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":282,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":283,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":284,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":286,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":287,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":288,\"textContent\":\" \"},{\"nodeType\":1,\"id\":289,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":290,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":291,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":292,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":293,\"textContent\":\" \"},{\"nodeType\":1,\"id\":294,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":295,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":296,\"textContent\":\" \"},{\"nodeType\":1,\"id\":297,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":298,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":299,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":300,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":301,\"textContent\":\" \"},{\"nodeType\":1,\"id\":302,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":303,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":304,\"textContent\":\" \"},{\"nodeType\":1,\"id\":305,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":306,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":307,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":308,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":309,\"textContent\":\" \"},{\"nodeType\":1,\"id\":310,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":311,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":312,\"textContent\":\" \"},{\"nodeType\":1,\"id\":313,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":314,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":315,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":316,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":317,\"textContent\":\" \"},{\"nodeType\":1,\"id\":318,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":319,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":320,\"textContent\":\" \"},{\"nodeType\":1,\"id\":321,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":322,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":323,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":324,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":325,\"textContent\":\" \"},{\"nodeType\":1,\"id\":326,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":327,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":328,\"textContent\":\" \"},{\"nodeType\":1,\"id\":329,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":330,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":331,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":332,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":333,\"textContent\":\" \"},{\"nodeType\":1,\"id\":334,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":335,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":336,\"textContent\":\" \"},{\"nodeType\":1,\"id\":337,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":338,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":339,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":340,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":341,\"textContent\":\" \"},{\"nodeType\":1,\"id\":342,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":343,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":344,\"textContent\":\" \"},{\"nodeType\":1,\"id\":345,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":346,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":347,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":348,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":349,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":351,\"textContent\":\" \"},{\"nodeType\":1,\"id\":352,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":353,\"textContent\":\" \"},{\"nodeType\":1,\"id\":354,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":355,\"textContent\":\"Which shift(s) begin when C ends?\"}]},{\"nodeType\":3,\"id\":356,\"textContent\":\" \"},{\"nodeType\":1,\"id\":357,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":358,\"textContent\":\" \"},{\"nodeType\":1,\"id\":359,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":360,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":361,\"textContent\":\" \"},{\"nodeType\":1,\"id\":362,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":363,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":364,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":365,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":366,\"textContent\":\" \"},{\"nodeType\":1,\"id\":367,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":368,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":369,\"textContent\":\" \"},{\"nodeType\":1,\"id\":370,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":371,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":372,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":373,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":374,\"textContent\":\" \"},{\"nodeType\":1,\"id\":375,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":376,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":377,\"textContent\":\" \"},{\"nodeType\":1,\"id\":378,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":379,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":380,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":381,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":382,\"textContent\":\" \"},{\"nodeType\":1,\"id\":383,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":384,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":385,\"textContent\":\" \"},{\"nodeType\":1,\"id\":386,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":387,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":388,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":389,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":390,\"textContent\":\" \"},{\"nodeType\":1,\"id\":391,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":392,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":393,\"textContent\":\" \"},{\"nodeType\":1,\"id\":394,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":395,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":396,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":397,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":398,\"textContent\":\" \"},{\"nodeType\":1,\"id\":399,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":400,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":401,\"textContent\":\" \"},{\"nodeType\":1,\"id\":402,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":403,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":404,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":405,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":406,\"textContent\":\" \"},{\"nodeType\":1,\"id\":407,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":408,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":409,\"textContent\":\" \"},{\"nodeType\":1,\"id\":410,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":411,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":412,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":413,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":414,\"textContent\":\" \"},{\"nodeType\":1,\"id\":415,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":416,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":417,\"textContent\":\" \"},{\"nodeType\":1,\"id\":418,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":419,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":420,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":421,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":422,\"textContent\":\" \"},{\"nodeType\":1,\"id\":423,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":424,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":425,\"textContent\":\" \"},{\"nodeType\":1,\"id\":426,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":427,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":428,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":429,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":430,\"textContent\":\" \"},{\"nodeType\":1,\"id\":431,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":432,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":433,\"textContent\":\" \"},{\"nodeType\":1,\"id\":434,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":435,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":436,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":437,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":438,\"textContent\":\" \"},{\"nodeType\":1,\"id\":439,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":440,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":441,\"textContent\":\" \"},{\"nodeType\":1,\"id\":442,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":443,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":444,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":445,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":446,\"textContent\":\" \"},{\"nodeType\":1,\"id\":447,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":448,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":449,\"textContent\":\" \"},{\"nodeType\":1,\"id\":450,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":451,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":452,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":453,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":454,\"textContent\":\" \"},{\"nodeType\":1,\"id\":455,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":456,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":457,\"textContent\":\" \"},{\"nodeType\":1,\"id\":458,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":459,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":460,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":461,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":462,\"textContent\":\" \"},{\"nodeType\":1,\"id\":463,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":464,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":465,\"textContent\":\" \"},{\"nodeType\":1,\"id\":466,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":467,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":468,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":469,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":470,\"textContent\":\" \"},{\"nodeType\":1,\"id\":471,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":472,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":473,\"textContent\":\" \"},{\"nodeType\":1,\"id\":474,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":475,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":476,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":477,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":478,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":479,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":480,\"textContent\":\" \"},{\"nodeType\":1,\"id\":481,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":483,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":484,\"textContent\":\" Which shift(s) end at 4 pm?\"}]},{\"nodeType\":3,\"id\":485,\"textContent\":\" \"},{\"nodeType\":1,\"id\":486,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":492,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":500,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":503,\"textContent\":\" \"},{\"nodeType\":1,\"id\":504,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":505,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":506,\"textContent\":\" \"},{\"nodeType\":1,\"id\":507,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":508,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":509,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":510,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":511,\"textContent\":\" \"},{\"nodeType\":1,\"id\":512,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":513,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":514,\"textContent\":\" \"},{\"nodeType\":1,\"id\":515,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":516,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":517,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":518,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":519,\"textContent\":\" \"},{\"nodeType\":1,\"id\":520,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":521,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":522,\"textContent\":\" \"},{\"nodeType\":1,\"id\":523,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":524,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":525,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":526,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":527,\"textContent\":\" \"},{\"nodeType\":1,\"id\":528,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":529,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":530,\"textContent\":\" \"},{\"nodeType\":1,\"id\":531,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":532,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":533,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":534,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":535,\"textContent\":\" \"},{\"nodeType\":1,\"id\":536,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":537,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":538,\"textContent\":\" \"},{\"nodeType\":1,\"id\":539,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":540,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":541,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":542,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":543,\"textContent\":\" \"},{\"nodeType\":1,\"id\":544,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":545,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":546,\"textContent\":\" \"},{\"nodeType\":1,\"id\":547,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":548,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":549,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":550,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":551,\"textContent\":\" \"},{\"nodeType\":1,\"id\":552,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":553,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":554,\"textContent\":\" \"},{\"nodeType\":1,\"id\":555,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":556,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":557,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":558,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":559,\"textContent\":\" \"},{\"nodeType\":1,\"id\":560,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":561,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":562,\"textContent\":\" \"},{\"nodeType\":1,\"id\":563,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":564,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":565,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":566,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":567,\"textContent\":\" \"},{\"nodeType\":1,\"id\":568,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":569,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":570,\"textContent\":\" \"},{\"nodeType\":1,\"id\":571,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":572,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":573,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":574,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":575,\"textContent\":\" \"},{\"nodeType\":1,\"id\":576,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":577,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":578,\"textContent\":\" \"},{\"nodeType\":1,\"id\":579,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":580,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":581,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":582,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":583,\"textContent\":\" \"},{\"nodeType\":1,\"id\":584,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":585,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":586,\"textContent\":\" \"},{\"nodeType\":1,\"id\":587,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":588,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":589,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":590,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":592,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":593,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":594,\"textContent\":\" \"},{\"nodeType\":1,\"id\":595,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":596,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":597,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":598,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":599,\"textContent\":\" \"},{\"nodeType\":1,\"id\":600,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":601,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":602,\"textContent\":\" \"},{\"nodeType\":1,\"id\":603,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":604,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":605,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":606,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":607,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":608,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":609,\"textContent\":\" \"},{\"nodeType\":1,\"id\":610,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":612,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":613,\"textContent\":\"Coffee breaks happen halfway through a shift.\"},{\"nodeType\":1,\"id\":614,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":615,\"textContent\":\" Which shift(s) share a break with I?\"}]},{\"nodeType\":3,\"id\":616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":617,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":618,\"textContent\":\" \"},{\"nodeType\":1,\"id\":619,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":620,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":621,\"textContent\":\" \"},{\"nodeType\":1,\"id\":622,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":623,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":624,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":625,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":626,\"textContent\":\" \"},{\"nodeType\":1,\"id\":627,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":628,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":629,\"textContent\":\" \"},{\"nodeType\":1,\"id\":630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":631,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":632,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":633,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":634,\"textContent\":\" \"},{\"nodeType\":1,\"id\":635,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":636,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":637,\"textContent\":\" \"},{\"nodeType\":1,\"id\":638,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":639,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":640,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":641,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":642,\"textContent\":\" \"},{\"nodeType\":1,\"id\":643,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":644,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":645,\"textContent\":\" \"},{\"nodeType\":1,\"id\":646,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":647,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":648,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":649,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":650,\"textContent\":\" \"},{\"nodeType\":1,\"id\":651,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":653,\"textContent\":\" \"},{\"nodeType\":1,\"id\":654,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":655,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":656,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":657,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":659,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":660,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":661,\"textContent\":\" \"},{\"nodeType\":1,\"id\":662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":663,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":664,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":665,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":666,\"textContent\":\" \"},{\"nodeType\":1,\"id\":667,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":668,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":669,\"textContent\":\" \"},{\"nodeType\":1,\"id\":670,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":671,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":672,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":673,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":674,\"textContent\":\" \"},{\"nodeType\":1,\"id\":675,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":676,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":677,\"textContent\":\" \"},{\"nodeType\":1,\"id\":678,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":679,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":680,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":681,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":682,\"textContent\":\" \"},{\"nodeType\":1,\"id\":683,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":685,\"textContent\":\" \"},{\"nodeType\":1,\"id\":686,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":687,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":688,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":689,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":690,\"textContent\":\" \"},{\"nodeType\":1,\"id\":691,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":692,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":693,\"textContent\":\" \"},{\"nodeType\":1,\"id\":694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":695,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":696,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":697,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":698,\"textContent\":\" \"},{\"nodeType\":1,\"id\":699,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":700,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":701,\"textContent\":\" \"},{\"nodeType\":1,\"id\":702,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":703,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":704,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":705,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":706,\"textContent\":\" \"},{\"nodeType\":1,\"id\":707,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":708,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":709,\"textContent\":\" \"},{\"nodeType\":1,\"id\":710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":711,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":712,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":713,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":714,\"textContent\":\" \"},{\"nodeType\":1,\"id\":715,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":716,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":717,\"textContent\":\" \"},{\"nodeType\":1,\"id\":718,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":719,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":720,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":721,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":722,\"textContent\":\" \"},{\"nodeType\":1,\"id\":723,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":724,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":725,\"textContent\":\" \"},{\"nodeType\":1,\"id\":726,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":727,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":728,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":729,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":730,\"textContent\":\" \"},{\"nodeType\":1,\"id\":731,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":732,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":733,\"textContent\":\" \"},{\"nodeType\":1,\"id\":734,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":735,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":736,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":737,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":738,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":739,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":741,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":742,\"textContent\":\" \"},{\"nodeType\":1,\"id\":743,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":744,\"textContent\":\"Which shift(s) are six hours long?\"}]},{\"nodeType\":3,\"id\":745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":746,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":747,\"textContent\":\" \"},{\"nodeType\":1,\"id\":748,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":749,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":750,\"textContent\":\" \"},{\"nodeType\":1,\"id\":751,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":752,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":753,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":754,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":755,\"textContent\":\" \"},{\"nodeType\":1,\"id\":756,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":757,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":758,\"textContent\":\" \"},{\"nodeType\":1,\"id\":759,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":760,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":761,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":762,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":763,\"textContent\":\" \"},{\"nodeType\":1,\"id\":764,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":765,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":766,\"textContent\":\" \"},{\"nodeType\":1,\"id\":767,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":768,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":769,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":770,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":771,\"textContent\":\" \"},{\"nodeType\":1,\"id\":772,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":773,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":774,\"textContent\":\" \"},{\"nodeType\":1,\"id\":775,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":776,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":777,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":778,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":779,\"textContent\":\" \"},{\"nodeType\":1,\"id\":780,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":781,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":782,\"textContent\":\" \"},{\"nodeType\":1,\"id\":783,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":784,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":785,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":786,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":787,\"textContent\":\" \"},{\"nodeType\":1,\"id\":788,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":789,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":790,\"textContent\":\" \"},{\"nodeType\":1,\"id\":791,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":792,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":793,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":794,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":795,\"textContent\":\" \"},{\"nodeType\":1,\"id\":796,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":797,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":798,\"textContent\":\" \"},{\"nodeType\":1,\"id\":799,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":800,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":801,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":802,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":803,\"textContent\":\" \"},{\"nodeType\":1,\"id\":804,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":805,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":806,\"textContent\":\" \"},{\"nodeType\":1,\"id\":807,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":808,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":809,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":810,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":812,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":813,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":814,\"textContent\":\" \"},{\"nodeType\":1,\"id\":815,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":816,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":817,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":818,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":819,\"textContent\":\" \"},{\"nodeType\":1,\"id\":820,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":821,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":822,\"textContent\":\" \"},{\"nodeType\":1,\"id\":823,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":824,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":825,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":826,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":827,\"textContent\":\" \"},{\"nodeType\":1,\"id\":828,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":829,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":830,\"textContent\":\" \"},{\"nodeType\":1,\"id\":831,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":832,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":833,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":834,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":835,\"textContent\":\" \"},{\"nodeType\":1,\"id\":836,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":837,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":838,\"textContent\":\" \"},{\"nodeType\":1,\"id\":839,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":840,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":841,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":842,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":843,\"textContent\":\" \"},{\"nodeType\":1,\"id\":844,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":845,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":846,\"textContent\":\" \"},{\"nodeType\":1,\"id\":847,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":848,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":849,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":850,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":851,\"textContent\":\" \"},{\"nodeType\":1,\"id\":852,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":853,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":854,\"textContent\":\" \"},{\"nodeType\":1,\"id\":855,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":856,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":857,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":858,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":859,\"textContent\":\" \"},{\"nodeType\":1,\"id\":860,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":861,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":862,\"textContent\":\" \"},{\"nodeType\":1,\"id\":863,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":864,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":865,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":866,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":867,\"textContent\":\" \"},{\"nodeType\":1,\"id\":868,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":869,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":870,\"textContent\":\" \"},{\"nodeType\":1,\"id\":871,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":872,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":873,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":874,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":875,\"textContent\":\" \"},{\"nodeType\":1,\"id\":876,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":877,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":878,\"textContent\":\" \"},{\"nodeType\":1,\"id\":879,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":880,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":881,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":882,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":883,\"textContent\":\" \"},{\"nodeType\":1,\"id\":884,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":885,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":886,\"textContent\":\" \"},{\"nodeType\":1,\"id\":887,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":888,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":889,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":890,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":891,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":892,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":894,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":895,\"textContent\":\" \"},{\"nodeType\":1,\"id\":896,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":897,\"textContent\":\"Which 2 shifts less than 5 hours long start at the same time?\"}]},{\"nodeType\":3,\"id\":898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":899,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":900,\"textContent\":\" \"},{\"nodeType\":1,\"id\":901,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":902,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":903,\"textContent\":\" \"},{\"nodeType\":1,\"id\":904,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":905,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":906,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":907,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":908,\"textContent\":\" \"},{\"nodeType\":1,\"id\":909,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":910,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":911,\"textContent\":\" \"},{\"nodeType\":1,\"id\":912,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":913,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":914,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":915,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":916,\"textContent\":\" \"},{\"nodeType\":1,\"id\":917,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":918,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":919,\"textContent\":\" \"},{\"nodeType\":1,\"id\":920,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":921,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":922,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":923,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":924,\"textContent\":\" \"},{\"nodeType\":1,\"id\":925,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":926,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":927,\"textContent\":\" \"},{\"nodeType\":1,\"id\":928,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":929,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":930,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":931,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":932,\"textContent\":\" \"},{\"nodeType\":1,\"id\":933,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":934,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":935,\"textContent\":\" \"},{\"nodeType\":1,\"id\":936,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":937,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":938,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":939,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":940,\"textContent\":\" \"},{\"nodeType\":1,\"id\":941,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":942,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":943,\"textContent\":\" \"},{\"nodeType\":1,\"id\":944,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":945,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":946,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":947,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":948,\"textContent\":\" \"},{\"nodeType\":1,\"id\":949,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":950,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":951,\"textContent\":\" \"},{\"nodeType\":1,\"id\":952,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":953,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":954,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":955,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":956,\"textContent\":\" \"},{\"nodeType\":1,\"id\":957,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":958,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":959,\"textContent\":\" \"},{\"nodeType\":1,\"id\":960,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":961,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":962,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":963,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":965,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":966,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":967,\"textContent\":\" \"},{\"nodeType\":1,\"id\":968,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":969,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":970,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":971,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":972,\"textContent\":\" \"},{\"nodeType\":1,\"id\":973,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":974,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":975,\"textContent\":\" \"},{\"nodeType\":1,\"id\":976,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":977,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":978,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":979,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":980,\"textContent\":\" \"},{\"nodeType\":1,\"id\":981,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":982,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":983,\"textContent\":\" \"},{\"nodeType\":1,\"id\":984,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":985,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":986,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":987,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":988,\"textContent\":\" \"},{\"nodeType\":1,\"id\":989,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":990,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":991,\"textContent\":\" \"},{\"nodeType\":1,\"id\":992,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":993,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":994,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":995,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":996,\"textContent\":\" \"},{\"nodeType\":1,\"id\":997,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":998,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":999,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1000,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1001,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1002,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1003,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1004,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1005,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1006,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1007,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1008,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1009,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1010,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1011,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1012,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1013,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1014,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1015,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1016,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1017,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1018,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1019,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1020,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1021,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1022,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1023,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1024,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1025,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1026,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1027,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1028,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1029,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1030,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1031,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1032,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1033,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1034,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1035,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1036,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1037,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1038,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1039,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1040,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1041,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1042,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1043,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1044,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1045,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1047,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+contained\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1048,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1049,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1050,\"textContent\":\"Which shift(s) under 7 hours long starts before B starts, and ends after X ends?\"}]},{\"nodeType\":3,\"id\":1051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1052,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1053,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1054,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1055,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1056,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1057,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1058,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1059,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1060,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1061,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1062,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1063,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1064,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1065,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1066,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1067,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1068,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1069,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1070,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1071,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1072,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1073,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1074,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1075,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1076,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1077,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1078,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1079,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1080,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1081,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1082,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1083,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1084,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1085,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1086,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1087,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1088,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1089,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1090,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1091,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1092,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1093,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1094,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1095,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1096,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1097,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1098,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1099,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1100,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1101,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1102,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1103,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1104,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1105,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1106,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1107,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1108,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1109,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1110,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1111,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1112,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1113,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1114,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1115,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1116,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1118,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1119,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1120,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1121,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1122,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1123,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1124,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1125,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1126,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1127,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1128,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1129,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1130,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1131,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1132,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1133,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1134,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1135,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1136,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1137,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1138,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1139,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1140,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1141,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1142,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1143,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1144,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1145,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1146,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1147,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1148,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1149,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1150,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1151,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1152,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1153,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1154,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1155,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1156,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1157,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1158,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1159,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1160,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1161,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1162,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1163,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1164,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1165,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1166,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1167,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1168,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1169,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1170,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1171,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1172,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1173,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1174,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1175,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1176,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1177,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1178,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1179,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1180,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1181,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1182,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1183,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1184,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1185,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1186,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1187,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1188,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1189,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1190,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1191,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1192,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1193,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1194,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1195,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1196,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1197,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1198,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1200,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime+before+endtime+during\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1202,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1203,\"textContent\":\"Which shift(s) begins before J begins and ends during B?\"}]},{\"nodeType\":3,\"id\":1204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1205,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1211,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1219,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1227,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1235,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1243,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1251,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1259,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1267,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1270,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1271,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1272,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1273,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1274,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1275,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1276,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1277,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1278,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1279,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1280,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1281,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1282,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1283,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1284,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1285,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1286,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1287,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1288,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1289,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1290,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1291,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1292,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1293,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1294,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1295,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1296,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1298,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1299,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1300,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1301,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1302,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1303,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1304,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1305,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1306,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1307,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1308,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1309,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1310,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1311,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1312,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1313,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1314,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1315,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1316,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1317,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1318,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1319,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1320,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1321,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1322,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1323,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1324,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1325,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1326,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1327,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1328,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1329,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1330,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1331,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1332,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1333,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1334,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1335,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1336,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1337,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1338,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1339,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1340,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1341,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1342,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1343,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1344,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1345,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1346,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1347,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1348,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1349,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1351,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1352,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1353,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.ends\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1354,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1355,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1356,\"textContent\":\"Which shift(s) end at the same time as F?\"}]},{\"nodeType\":3,\"id\":1357,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1358,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1359,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1360,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1361,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1362,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1363,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1364,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1365,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1366,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1367,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1368,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1369,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1370,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1371,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1372,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1373,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1374,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1375,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1376,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1377,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1378,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1379,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1380,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1381,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1382,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1383,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1384,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1385,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1386,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1387,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1388,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1389,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1390,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1391,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1392,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1393,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1394,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1395,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1396,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1397,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1398,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1399,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1400,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1401,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1402,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1403,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1404,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1405,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1406,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1407,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1408,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1409,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1410,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1411,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1412,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1413,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1414,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1415,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1416,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1417,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1418,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1419,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1420,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1421,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1422,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1423,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1424,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1425,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1426,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1427,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1428,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1429,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1430,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1431,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1432,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1433,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1434,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1435,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1436,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1437,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1438,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1439,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1440,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1441,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1442,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1443,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1444,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1445,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1446,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1447,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1448,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1449,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1450,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1451,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1452,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1453,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1454,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1455,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1456,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1457,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1458,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1459,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1460,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1461,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1462,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1463,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1464,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1465,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1466,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1467,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1468,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1469,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1470,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1471,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1472,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1473,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1474,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1475,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1476,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1477,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1478,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1479,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1480,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1481,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1483,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1484,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1485,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1486,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1492,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1500,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1503,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1504,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1505,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1506,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1507,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1508,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1509,\"textContent\":\"Which shift(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":1510,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1511,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1512,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1513,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1514,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1515,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1516,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1517,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1518,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1519,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1520,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1521,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1522,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1523,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1524,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1525,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1526,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1527,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1528,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1529,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1530,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1531,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1532,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1533,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1534,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1535,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1536,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1537,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1538,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1539,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1540,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1541,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1542,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1543,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1544,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1545,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1546,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1547,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1548,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1549,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1550,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1551,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1552,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1553,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1554,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1555,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1556,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1557,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1558,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1559,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1560,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1561,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1562,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1563,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1564,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1565,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1566,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1567,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1568,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1569,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1570,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1571,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1572,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1573,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1574,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1575,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1576,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1577,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1578,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1579,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1580,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1581,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1582,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1583,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1584,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1585,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1586,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1587,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1588,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1589,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1590,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1591,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1592,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1593,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1594,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1595,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1596,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1597,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1598,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1599,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1600,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1601,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1602,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1603,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1604,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1605,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1606,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1607,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1608,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1609,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1610,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1612,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1613,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1614,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1615,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1617,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1618,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1619,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1620,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1621,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1622,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1623,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1624,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1625,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1627,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1628,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1629,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1630,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1631,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1632,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1633,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1634,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1635,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1636,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1637,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1638,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1639,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1640,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1641,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1642,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1643,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1644,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1645,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1646,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1647,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1648,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1649,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1650,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1651,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1652,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1653,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1654,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1655,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1656,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1657,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1659,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1660,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1661,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1662,\"textContent\":\"Which shift(s) start at the same time as F?\"}]},{\"nodeType\":3,\"id\":1663,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1664,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1665,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1666,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1667,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1668,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1669,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1670,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1671,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1672,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1673,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1674,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1675,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1676,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1677,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1678,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1679,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1680,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1681,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1682,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1683,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1684,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1686,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1687,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1688,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1689,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1690,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1691,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1692,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1693,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1694,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1695,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1696,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1697,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1698,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1699,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1700,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1701,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1702,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1703,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1704,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1705,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1706,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1707,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1708,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1709,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1710,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1711,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1712,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1713,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1714,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1715,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1716,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1717,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1718,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1720,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1721,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1722,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1723,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1724,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1725,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1726,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1727,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1728,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1729,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1730,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1731,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1732,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1733,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1734,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1735,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1736,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1737,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1738,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1739,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1741,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1742,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1743,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1744,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1746,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1747,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1748,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1749,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1750,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1751,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1752,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1753,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1754,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1755,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1756,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1757,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1758,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1759,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1760,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1761,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1762,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1763,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1764,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1765,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1766,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1767,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1768,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1769,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1770,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1771,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1772,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1773,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1774,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1775,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1776,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1777,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1778,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1779,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1780,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1781,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1782,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1783,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1784,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1785,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1786,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1787,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1788,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1789,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1790,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1791,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1792,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1793,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1794,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1795,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1796,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1797,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1798,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1799,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1800,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1801,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1802,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1803,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1804,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1805,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1806,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1807,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1808,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1809,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1810,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1812,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1813,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1814,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1815,\"textContent\":\"Which 2 shifts end when Z begins?\"}]},{\"nodeType\":3,\"id\":1816,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1817,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1818,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1819,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1820,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1821,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1822,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1823,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1824,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1825,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1826,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1827,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1828,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1829,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1830,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1831,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1832,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1833,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1834,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1835,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1836,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1837,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1838,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1839,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1840,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1841,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1842,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1843,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1844,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1845,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1846,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1847,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1848,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1849,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1850,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1851,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1852,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1853,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1854,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1855,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1856,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1857,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1858,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1859,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1860,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1861,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1862,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1863,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1864,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1865,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1866,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1867,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1868,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1869,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1870,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1871,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1872,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1873,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1874,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1875,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1876,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1877,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1878,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1879,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1880,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1881,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1882,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1883,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1884,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1885,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1886,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1887,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1888,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1889,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1890,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1891,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1892,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1894,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1895,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1896,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1897,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1899,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1900,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1901,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1902,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1903,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1904,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1905,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1906,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1907,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1908,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1909,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1910,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1911,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1912,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1913,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1914,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1915,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1916,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1917,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1918,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1919,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1920,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1921,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1922,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1923,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1924,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1925,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1926,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1927,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1928,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1929,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1930,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1931,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1932,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1933,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1934,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1935,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1936,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1937,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1938,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1939,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1940,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1941,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1942,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1943,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1944,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1945,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1946,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1947,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1948,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1949,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1950,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1951,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1952,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1953,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1954,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1955,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1956,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1957,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1958,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1959,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1960,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1961,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1962,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1963,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1965,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1966,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1967,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1968,\"textContent\":\"Which shift(s) end at 3pm?\"}]},{\"nodeType\":3,\"id\":1969,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1970,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1971,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1972,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1973,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1974,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1975,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1976,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1977,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1978,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1979,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1980,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1981,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1982,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1983,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1984,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1985,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1986,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1987,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1988,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1989,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1990,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1991,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1992,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1993,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1994,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1995,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1996,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1997,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1998,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1999,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2000,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2001,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2002,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2003,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2004,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2005,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2006,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2007,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2008,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2009,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2010,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2011,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2012,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2013,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2014,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2015,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2016,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2017,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2018,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2019,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2020,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2021,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2022,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2023,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2024,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2025,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2026,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2027,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2028,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2029,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2030,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2031,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2032,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2033,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2034,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2035,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2036,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2037,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2038,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2039,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2040,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2041,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2042,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2043,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2044,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2045,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2047,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2048,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2049,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2050,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2052,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2053,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2054,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2055,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2056,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2057,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2058,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2059,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2060,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2061,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2062,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2063,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2064,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2065,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2066,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2067,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2068,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2069,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2070,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2071,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2072,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2073,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2074,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2075,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2076,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2077,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2078,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2079,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2080,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2081,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2082,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2083,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2084,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2085,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2086,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2087,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2088,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2089,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2090,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2091,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2092,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2093,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2094,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2095,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2096,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2097,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2098,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2099,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2100,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2101,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2102,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2103,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2104,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2105,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2106,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2107,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2108,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2109,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2110,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2111,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2112,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2113,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2114,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2115,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2116,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2118,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":2119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2120,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2121,\"textContent\":\"Coffee breaks happen halfway through a shift. \"},{\"nodeType\":1,\"id\":2122,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":2123,\"textContent\":\"Which shifts share a break at 2pm?\"}]},{\"nodeType\":3,\"id\":2124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2125,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":2126,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2127,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2128,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2129,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2130,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2131,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":2132,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2133,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2134,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2135,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2136,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2137,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2138,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2139,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":2140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2141,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2142,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2143,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2144,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2145,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2146,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2147,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":2148,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2149,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2150,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2151,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2152,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2153,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2154,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2155,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2156,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2157,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2158,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2159,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2160,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2161,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2162,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2163,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2164,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2165,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2166,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2167,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2168,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2169,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2170,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2171,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2172,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2173,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2174,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2175,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2176,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2177,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2178,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2179,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2180,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2181,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2182,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2183,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2184,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2185,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2186,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2187,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2188,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2189,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2190,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2191,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2192,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2193,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2194,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2195,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2196,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2197,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2198,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2199,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2200,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2202,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2203,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2204,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2205,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2211,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2219,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2227,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2235,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2243,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2251,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2259,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2267,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2270,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2271,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2273,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\".strategy\",\"style\":\"display: block;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2274,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2275,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2276,\"textContent\":\"Please describe how to determine what event(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":2277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2278,\"tagName\":\"TEXTAREA\",\"attributes\":{\"id\":\"strategyAnswer\",\"rows\":\"5\",\"cols\":\"80\"}},{\"nodeType\":3,\"id\":2279,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2280,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2281,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2282},{\"nodeType\":3,\"id\":2283,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2284},{\"nodeType\":3,\"id\":2285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2286,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"fixbottom\"},\"childNodes\":[{\"nodeType\":3,\"id\":2287,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2288,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"testingButton\",\"style\":\"display:none;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2289,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2290,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2291,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"strategyButton\",\"style\":\"display: block;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2292,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2293,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2294,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2295,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2296},{\"nodeType\":3,\"id\":2297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2298,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"d3container\"},\"childNodes\":[{\"nodeType\":1,\"id\":2299,\"tagName\":\"svg\",\"attributes\":{\"width\":\"930\",\"height\":\"915\"},\"childNodes\":[{\"nodeType\":1,\"id\":2300,\"tagName\":\"g\",\"attributes\":{\"transform\":\"translate(100,25)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2301,\"tagName\":\"g\",\"attributes\":{\"class\":\"leaders\"}},{\"nodeType\":1,\"id\":2302,\"tagName\":\"g\",\"attributes\":{\"class\":\"static-scaffold\"}}]}]}]},{\"nodeType\":3,\"id\":2303,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2304,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2305},{\"nodeType\":3,\"id\":2306,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2307,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2308,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2309,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2310,\"textContent\":\" \"}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 126, dom: 609, initialDom: 700",
  "javascriptErrors": []
}