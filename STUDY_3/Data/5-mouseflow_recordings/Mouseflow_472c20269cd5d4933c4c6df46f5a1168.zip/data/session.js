var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "472c20269cd5d4933c4c6df46f5a1168",
  "created": "2018-05-25T11:18:16.9338067-07:00",
  "lastActivity": "2018-05-25T11:19:45.3498067-07:00",
  "pageViews": [
    {
      "id": "05251702428ef74d0be7a31a0431008d84967a6c",
      "startTime": "2018-05-25T11:18:16.9338067-07:00",
      "endTime": "2018-05-25T11:19:45.3498067-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/16",
      "visitTime": 88416,
      "engagementTime": 85552,
      "scroll": 100.0,
      "tags": [
        "form-interact",
        "submit"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 88416,
  "engagementTime": 85552,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.31",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact",
    "submit"
  ],
  "variables": [
    "SID=KYY96",
    "CONDITION=114"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "51b50c0ba1b9fe782826f0c415eb9571",
  "gdpr": false
}