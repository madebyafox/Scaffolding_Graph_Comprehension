var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "fab83c8b755fe0840ce650faea7c2a46",
  "created": "2018-05-22T13:08:04.4598549-07:00",
  "lastActivity": "2018-05-22T13:09:00.2778549-07:00",
  "pageViews": [
    {
      "id": "05220444fda39fce5e0bc60b08e3fb5b779e932c",
      "startTime": "2018-05-22T13:08:04.4598549-07:00",
      "endTime": "2018-05-22T13:09:00.2778549-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/8",
      "visitTime": 55818,
      "engagementTime": 43518,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 55818,
  "engagementTime": 43518,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.25",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=H1RGT",
    "CONDITION=121",
    "TRI_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "fbbb3f6e0b711a6632c5c973c7ecf56e",
  "gdpr": false
}