var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "2fb8e3d4f29cd8fcdb2e5e06723d407f",
  "created": "2018-05-24T12:16:35.9003047-07:00",
  "lastActivity": "2018-05-24T12:16:45.1208115-07:00",
  "pageViews": [
    {
      "id": "05243682209e45334a8f334d75ad6411a5ac4706",
      "startTime": "2018-05-24T12:16:36.0241837-07:00",
      "endTime": "2018-05-24T12:16:45.1208115-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/12",
      "visitTime": 9388,
      "engagementTime": 9386,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 9388,
  "engagementTime": 9386,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.27",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=HZWEH",
    "CONDITION=113",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "6a67b9c411e4c09bd2d5b3e698858713",
  "gdpr": false
}