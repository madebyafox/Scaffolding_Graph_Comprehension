var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "95cff7ee6b1eea3f843da4550434fd72",
  "created": "2018-05-22T16:05:43.2652932-07:00",
  "lastActivity": "2018-05-22T16:07:49.0035238-07:00",
  "pageViews": [
    {
      "id": "052243878dcbb056114ecb593e7ce23151a31cd9",
      "startTime": "2018-05-22T16:05:43.4147085-07:00",
      "endTime": "2018-05-22T16:07:49.0035238-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/1",
      "visitTime": 126106,
      "engagementTime": 116504,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 126106,
  "engagementTime": 116504,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.30",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=PRRKJ",
    "CONDITION=115"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "ef1c245c1bc39483bb3af0d58f5d36e7",
  "gdpr": false
}