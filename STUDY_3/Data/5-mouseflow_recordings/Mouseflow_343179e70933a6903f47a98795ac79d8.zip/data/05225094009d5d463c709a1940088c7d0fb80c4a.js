var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["05225094009d5d463c709a1940088c7d0fb80c4a"] = {
  "startTime": "2018-05-22T17:14:50.4517255Z",
  "websitePageUrl": "/16",
  "visitTime": 122535,
  "engagementTime": 121031,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1200,
  "tags": [
    "form-interact",
    "submit"
  ],
  "session": {
    "id": "343179e70933a6903f47a98795ac79d8",
    "created": "2018-05-22T17:14:50.4517255+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.181",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/16",
    "tags": [
      "form-interact",
      "submit"
    ],
    "variables": [
      "SID=38NFJ",
      "CONDITION=121"
    ],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "9a2f8312a0ea0bd9c16cb6566ec3fe4c",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/343179e70933a6903f47a98795ac79d8/play"
  },
  "events": [
    {
      "t": 1,
      "e": 1,
      "ty": 14,
      "x": 0,
      "y": 1199
    },
    {
      "t": 201,
      "e": 201,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 701,
      "e": 701,
      "ty": 2,
      "x": 512,
      "y": 752
    },
    {
      "t": 751,
      "e": 751,
      "ty": 41,
      "x": 48100,
      "y": 37780,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 801,
      "e": 801,
      "ty": 2,
      "x": 539,
      "y": 642
    },
    {
      "t": 835,
      "e": 835,
      "ty": 6,
      "x": 550,
      "y": 598,
      "ta": "#strategyAnswer"
    },
    {
      "t": 900,
      "e": 900,
      "ty": 2,
      "x": 550,
      "y": 588
    },
    {
      "t": 1000,
      "e": 1000,
      "ty": 2,
      "x": 549,
      "y": 566
    },
    {
      "t": 1002,
      "e": 1002,
      "ty": 41,
      "x": 50798,
      "y": 35005,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1101,
      "e": 1101,
      "ty": 2,
      "x": 548,
      "y": 546
    },
    {
      "t": 1251,
      "e": 1251,
      "ty": 41,
      "x": 50686,
      "y": 18823,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1408,
      "e": 1408,
      "ty": 3,
      "x": 548,
      "y": 546,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1410,
      "e": 1410,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1527,
      "e": 1527,
      "ty": 4,
      "x": 50686,
      "y": 18823,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1527,
      "e": 1527,
      "ty": 5,
      "x": 548,
      "y": 546,
      "ta": "#strategyAnswer"
    },
    {
      "t": 4901,
      "e": 4901,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 4901,
      "e": 4901,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 4996,
      "e": 4996,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "t"
    },
    {
      "t": 5004,
      "e": 5004,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 5005,
      "e": 5005,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 5085,
      "e": 5085,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "th"
    },
    {
      "t": 5101,
      "e": 5101,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 5101,
      "e": 5101,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 5187,
      "e": 5187,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "the"
    },
    {
      "t": 5227,
      "e": 5227,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 5227,
      "e": 5227,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 5291,
      "e": 5291,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "the "
    },
    {
      "t": 5402,
      "e": 5402,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "the "
    },
    {
      "t": 5708,
      "e": 5708,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 5709,
      "e": 5709,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 5779,
      "e": 5779,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 5804,
      "e": 5804,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 5804,
      "e": 5804,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 5908,
      "e": 5908,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 5963,
      "e": 5963,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 5964,
      "e": 5964,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 6051,
      "e": 6051,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||f"
    },
    {
      "t": 6147,
      "e": 6147,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 6148,
      "e": 6148,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 6236,
      "e": 6236,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 6284,
      "e": 6284,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 6285,
      "e": 6285,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 6355,
      "e": 6355,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 6788,
      "e": 6788,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 6789,
      "e": 6789,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 6868,
      "e": 6868,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||c"
    },
    {
      "t": 6893,
      "e": 6893,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 6893,
      "e": 6893,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 6948,
      "e": 6948,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 7044,
      "e": 7044,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 7044,
      "e": 7044,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 7132,
      "e": 7132,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 7436,
      "e": 7436,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 7602,
      "e": 7602,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "the left co"
    },
    {
      "t": 7636,
      "e": 7636,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "the left co"
    },
    {
      "t": 7772,
      "e": 7772,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 8271,
      "e": 8271,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 8304,
      "e": 8304,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 8337,
      "e": 8337,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 8369,
      "e": 8369,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 8402,
      "e": 8402,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 8435,
      "e": 8435,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 8468,
      "e": 8468,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 8501,
      "e": 8501,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 8535,
      "e": 8535,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 8568,
      "e": 8568,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 8601,
      "e": 8601,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 8634,
      "e": 8634,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 8667,
      "e": 8667,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 8668,
      "e": 8668,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": ""
    },
    {
      "t": 9188,
      "e": 9188,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 9188,
      "e": 9188,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9300,
      "e": 9300,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "t"
    },
    {
      "t": 9372,
      "e": 9372,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 9373,
      "e": 9373,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9435,
      "e": 9435,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "to"
    },
    {
      "t": 9507,
      "e": 9507,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 9507,
      "e": 9507,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9563,
      "e": 9563,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "too"
    },
    {
      "t": 9668,
      "e": 9668,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "75"
    },
    {
      "t": 9669,
      "e": 9669,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9748,
      "e": 9748,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "took"
    },
    {
      "t": 9788,
      "e": 9788,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 9789,
      "e": 9789,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9860,
      "e": 9860,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 9964,
      "e": 9964,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 9965,
      "e": 9965,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10001,
      "e": 10001,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 10027,
      "e": 10027,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 10068,
      "e": 10068,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 10068,
      "e": 10068,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10171,
      "e": 10171,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 10179,
      "e": 10179,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 10180,
      "e": 10180,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10235,
      "e": 10235,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 10284,
      "e": 10284,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 10284,
      "e": 10284,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10372,
      "e": 10372,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 10373,
      "e": 10373,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10380,
      "e": 10380,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a "
    },
    {
      "t": 10436,
      "e": 10436,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 10508,
      "e": 10508,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 10509,
      "e": 10509,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10612,
      "e": 10612,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||f"
    },
    {
      "t": 10836,
      "e": 10836,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 10837,
      "e": 10837,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10948,
      "e": 10948,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 10948,
      "e": 10948,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10971,
      "e": 10971,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ew"
    },
    {
      "t": 11060,
      "e": 11060,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 11101,
      "e": 11101,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 11101,
      "e": 11101,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11171,
      "e": 11171,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 11524,
      "e": 11524,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "81"
    },
    {
      "t": 11525,
      "e": 11525,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11603,
      "e": 11603,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||q"
    },
    {
      "t": 11644,
      "e": 11644,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 11644,
      "e": 11644,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11740,
      "e": 11740,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||u"
    },
    {
      "t": 11780,
      "e": 11780,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 11781,
      "e": 11781,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11876,
      "e": 11876,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 11884,
      "e": 11884,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 11884,
      "e": 11884,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11980,
      "e": 11980,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 11980,
      "e": 11980,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12044,
      "e": 12044,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||st"
    },
    {
      "t": 12075,
      "e": 12075,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 12083,
      "e": 12083,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 12083,
      "e": 12083,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12180,
      "e": 12180,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 12252,
      "e": 12252,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 12252,
      "e": 12252,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12316,
      "e": 12316,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 12356,
      "e": 12356,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 12357,
      "e": 12357,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12428,
      "e": 12428,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 12428,
      "e": 12428,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12451,
      "e": 12451,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ns"
    },
    {
      "t": 12523,
      "e": 12523,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 12572,
      "e": 12572,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 12572,
      "e": 12572,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12651,
      "e": 12651,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 12755,
      "e": 12755,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 12756,
      "e": 12756,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12852,
      "e": 12852,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 12868,
      "e": 12868,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 12868,
      "e": 12868,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12939,
      "e": 12939,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 12940,
      "e": 12940,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12947,
      "e": 12947,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o "
    },
    {
      "t": 13011,
      "e": 13011,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 13124,
      "e": 13124,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 13125,
      "e": 13125,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13227,
      "e": 13227,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||f"
    },
    {
      "t": 13586,
      "e": 13586,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 13587,
      "e": 13587,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13643,
      "e": 13643,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 13699,
      "e": 13699,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 13699,
      "e": 13699,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13779,
      "e": 13779,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 13836,
      "e": 13836,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 13836,
      "e": 13836,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13932,
      "e": 13932,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 14472,
      "e": 14472,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 14576,
      "e": 14576,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "took me a few questions to fig"
    },
    {
      "t": 14672,
      "e": 14672,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 14673,
      "e": 14673,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14783,
      "e": 14783,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||u"
    },
    {
      "t": 14880,
      "e": 14880,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 14880,
      "e": 14880,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14968,
      "e": 14968,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 14968,
      "e": 14968,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15015,
      "e": 15015,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||re"
    },
    {
      "t": 15056,
      "e": 15056,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 15072,
      "e": 15072,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 15072,
      "e": 15072,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15152,
      "e": 15152,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 15255,
      "e": 15255,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 15256,
      "e": 15256,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15311,
      "e": 15311,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 15311,
      "e": 15311,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15391,
      "e": 15391,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ou"
    },
    {
      "t": 15447,
      "e": 15447,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 15479,
      "e": 15479,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 15479,
      "e": 15479,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15559,
      "e": 15559,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 15607,
      "e": 15607,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "188"
    },
    {
      "t": 15608,
      "e": 15608,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15703,
      "e": 15703,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 15703,
      "e": 15703,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15719,
      "e": 15719,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||, "
    },
    {
      "t": 15783,
      "e": 15783,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 15896,
      "e": 15896,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "66"
    },
    {
      "t": 15896,
      "e": 15896,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15959,
      "e": 15959,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||b"
    },
    {
      "t": 16079,
      "e": 16079,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 16079,
      "e": 16079,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16151,
      "e": 16151,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||u"
    },
    {
      "t": 16192,
      "e": 16192,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 16192,
      "e": 16192,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16272,
      "e": 16272,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 16279,
      "e": 16279,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 16280,
      "e": 16280,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16351,
      "e": 16351,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 16399,
      "e": 16399,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 16399,
      "e": 16399,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16439,
      "e": 16439,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 16439,
      "e": 16439,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16495,
      "e": 16495,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 16495,
      "e": 16495,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16543,
      "e": 16543,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||the"
    },
    {
      "t": 16552,
      "e": 16552,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 16568,
      "e": 16568,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 16568,
      "e": 16568,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16583,
      "e": 16583,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 16639,
      "e": 16639,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 16969,
      "e": 16640,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 16970,
      "e": 16641,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17038,
      "e": 16709,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 17079,
      "e": 16750,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 17079,
      "e": 16750,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17151,
      "e": 16822,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 17216,
      "e": 16887,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 17216,
      "e": 16887,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17303,
      "e": 16974,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||f"
    },
    {
      "t": 17406,
      "e": 17077,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "took me a few questions to figure out, but the lef"
    },
    {
      "t": 17407,
      "e": 17078,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 17407,
      "e": 17078,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17487,
      "e": 17158,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 17535,
      "e": 17206,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 17536,
      "e": 17207,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17607,
      "e": 17278,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 18271,
      "e": 17942,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 18274,
      "e": 17945,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18327,
      "e": 17998,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||c"
    },
    {
      "t": 18407,
      "e": 18078,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 18407,
      "e": 18078,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18463,
      "e": 18134,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 18607,
      "e": 18278,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "took me a few questions to figure out, but the left co"
    },
    {
      "t": 18623,
      "e": 18294,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 18625,
      "e": 18296,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18686,
      "e": 18357,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 18806,
      "e": 18477,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "took me a few questions to figure out, but the left cor"
    },
    {
      "t": 18999,
      "e": 18670,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 19000,
      "e": 18671,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19064,
      "e": 18735,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 19096,
      "e": 18767,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 19096,
      "e": 18767,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19151,
      "e": 18822,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 19151,
      "e": 18822,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19191,
      "e": 18862,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||er"
    },
    {
      "t": 19254,
      "e": 18925,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 19263,
      "e": 18934,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 19263,
      "e": 18934,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19335,
      "e": 19006,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 19383,
      "e": 19054,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 19384,
      "e": 19055,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19463,
      "e": 19134,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 19503,
      "e": 19174,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 19503,
      "e": 19174,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19558,
      "e": 19229,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 19560,
      "e": 19231,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19567,
      "e": 19238,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||f "
    },
    {
      "t": 19647,
      "e": 19318,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 19649,
      "e": 19320,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19655,
      "e": 19326,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 19703,
      "e": 19374,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 19704,
      "e": 19375,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19751,
      "e": 19422,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 19751,
      "e": 19422,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19799,
      "e": 19470,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||he"
    },
    {
      "t": 19806,
      "e": 19477,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 19815,
      "e": 19486,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 19815,
      "e": 19486,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19823,
      "e": 19494,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 19912,
      "e": 19583,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 20072,
      "e": 19743,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 20073,
      "e": 19744,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20135,
      "e": 19806,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 20231,
      "e": 19902,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 20231,
      "e": 19902,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20336,
      "e": 20007,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 20463,
      "e": 20134,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 20463,
      "e": 20134,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20494,
      "e": 20165,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 20606,
      "e": 20277,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "took me a few questions to figure out, but the left corner of the tri"
    },
    {
      "t": 20639,
      "e": 20310,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 20640,
      "e": 20311,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20735,
      "e": 20406,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 20903,
      "e": 20574,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 20905,
      "e": 20576,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20990,
      "e": 20661,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 21128,
      "e": 20799,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 21129,
      "e": 20800,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21214,
      "e": 20885,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 21255,
      "e": 20926,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 21255,
      "e": 20926,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21335,
      "e": 21006,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 21375,
      "e": 21046,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 21377,
      "e": 21048,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21447,
      "e": 21118,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 21455,
      "e": 21126,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 21455,
      "e": 21126,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21543,
      "e": 21214,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 21584,
      "e": 21255,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 21696,
      "e": 21367,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "57"
    },
    {
      "t": 21697,
      "e": 21368,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21782,
      "e": 21453,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||("
    },
    {
      "t": 21830,
      "e": 21501,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 23087,
      "e": 22758,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 23089,
      "e": 22760,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23183,
      "e": 22854,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 23255,
      "e": 22926,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 23256,
      "e": 22927,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23344,
      "e": 23015,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 23440,
      "e": 23111,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 23440,
      "e": 23111,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23511,
      "e": 23111,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 23663,
      "e": 23263,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 23664,
      "e": 23264,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23736,
      "e": 23336,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 23848,
      "e": 23448,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 23848,
      "e": 23448,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23928,
      "e": 23528,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 23935,
      "e": 23535,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 23936,
      "e": 23536,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24014,
      "e": 23614,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 24103,
      "e": 23703,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 24103,
      "e": 23703,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24167,
      "e": 23767,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 24231,
      "e": 23831,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 24232,
      "e": 23832,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24311,
      "e": 23911,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 24375,
      "e": 23975,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 24375,
      "e": 23975,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24471,
      "e": 24071,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 24472,
      "e": 24072,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24527,
      "e": 24127,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||in"
    },
    {
      "t": 24535,
      "e": 24135,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 24536,
      "e": 24136,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24559,
      "e": 24159,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 24615,
      "e": 24215,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 24647,
      "e": 24247,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 24647,
      "e": 24247,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24719,
      "e": 24319,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 24719,
      "e": 24319,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24727,
      "e": 24327,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| t"
    },
    {
      "t": 24775,
      "e": 24375,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 24775,
      "e": 24375,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24823,
      "e": 24423,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 24823,
      "e": 24423,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24879,
      "e": 24479,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||he"
    },
    {
      "t": 24904,
      "e": 24504,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 24911,
      "e": 24511,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 24927,
      "e": 24527,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 24928,
      "e": 24528,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25008,
      "e": 24608,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 26272,
      "e": 25872,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 26273,
      "e": 25873,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26343,
      "e": 25943,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 26455,
      "e": 26055,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 26455,
      "e": 26055,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26519,
      "e": 26119,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 26592,
      "e": 26192,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 26593,
      "e": 26193,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26663,
      "e": 26263,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 26767,
      "e": 26367,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 26768,
      "e": 26368,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26815,
      "e": 26415,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 26887,
      "e": 26487,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 26887,
      "e": 26487,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26943,
      "e": 26543,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 26943,
      "e": 26543,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26975,
      "e": 26575,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||er"
    },
    {
      "t": 27039,
      "e": 26639,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 27047,
      "e": 26647,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 27048,
      "e": 26648,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27126,
      "e": 26726,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 27183,
      "e": 26783,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 27183,
      "e": 26783,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27264,
      "e": 26864,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 27264,
      "e": 26864,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27270,
      "e": 26870,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||at"
    },
    {
      "t": 27335,
      "e": 26935,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 27350,
      "e": 26950,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 27351,
      "e": 26951,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27415,
      "e": 27015,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 27423,
      "e": 27023,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 27423,
      "e": 27023,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27511,
      "e": 27111,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 27513,
      "e": 27113,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27520,
      "e": 27120,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 27520,
      "e": 27120,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27575,
      "e": 27175,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||the"
    },
    {
      "t": 27598,
      "e": 27198,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 27607,
      "e": 27207,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 27607,
      "e": 27207,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27615,
      "e": 27215,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 27687,
      "e": 27287,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 27807,
      "e": 27407,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "took me a few questions to figure out, but the left corner of the triangle (positioning the letter at the "
    },
    {
      "t": 27831,
      "e": 27431,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 27833,
      "e": 27433,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27919,
      "e": 27519,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 27950,
      "e": 27550,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 27950,
      "e": 27550,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28014,
      "e": 27614,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 28023,
      "e": 27623,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 28024,
      "e": 27624,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28135,
      "e": 27735,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 28320,
      "e": 27920,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 28400,
      "e": 28000,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "48"
    },
    {
      "t": 28400,
      "e": 28000,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28479,
      "e": 28079,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||)"
    },
    {
      "t": 28559,
      "e": 28159,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 28632,
      "e": 28232,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 28633,
      "e": 28233,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28720,
      "e": 28320,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 29295,
      "e": 28895,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 29296,
      "e": 28896,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29383,
      "e": 28983,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 29430,
      "e": 29030,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 29431,
      "e": 29031,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29503,
      "e": 29103,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 29551,
      "e": 29151,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 29552,
      "e": 29152,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29622,
      "e": 29222,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 30005,
      "e": 29605,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 31287,
      "e": 30887,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 31288,
      "e": 30888,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31399,
      "e": 30999,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 31400,
      "e": 31000,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31430,
      "e": 31030,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||wh"
    },
    {
      "t": 31495,
      "e": 31095,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 31567,
      "e": 31167,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 31567,
      "e": 31167,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31680,
      "e": 31280,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 31680,
      "e": 31280,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31687,
      "e": 31287,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||er"
    },
    {
      "t": 31774,
      "e": 31374,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 31774,
      "e": 31374,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31831,
      "e": 31431,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 31870,
      "e": 31470,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 31943,
      "e": 31543,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 31944,
      "e": 31544,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32006,
      "e": 31606,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 32704,
      "e": 32304,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 32704,
      "e": 32304,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32806,
      "e": 32406,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "took me a few questions to figure out, but the left corner of the triangle (positioning the letter at the top) is where t"
    },
    {
      "t": 32806,
      "e": 32406,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 32815,
      "e": 32415,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 32815,
      "e": 32415,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32847,
      "e": 32447,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 32847,
      "e": 32447,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32887,
      "e": 32487,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||he"
    },
    {
      "t": 32935,
      "e": 32535,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 32991,
      "e": 32591,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 32992,
      "e": 32592,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33054,
      "e": 32654,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 33183,
      "e": 32783,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 33184,
      "e": 32784,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33279,
      "e": 32879,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 33303,
      "e": 32903,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 33303,
      "e": 32903,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33351,
      "e": 32951,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 33456,
      "e": 33056,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 33456,
      "e": 33056,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33518,
      "e": 33118,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 33519,
      "e": 33119,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33526,
      "e": 33126,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||me"
    },
    {
      "t": 33591,
      "e": 33191,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 33646,
      "e": 33246,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 33647,
      "e": 33247,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33727,
      "e": 33327,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 33839,
      "e": 33439,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 33840,
      "e": 33440,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33910,
      "e": 33510,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 33974,
      "e": 33574,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 33975,
      "e": 33575,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34055,
      "e": 33655,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 34127,
      "e": 33727,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 34128,
      "e": 33728,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34198,
      "e": 33798,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 34198,
      "e": 33798,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34262,
      "e": 33862,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ar"
    },
    {
      "t": 34311,
      "e": 33911,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 34399,
      "e": 33999,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 34400,
      "e": 34000,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34486,
      "e": 34086,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 34575,
      "e": 34175,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 34576,
      "e": 34176,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34671,
      "e": 34271,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 34695,
      "e": 34295,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 34696,
      "e": 34296,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34775,
      "e": 34375,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 34815,
      "e": 34415,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 34815,
      "e": 34415,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34903,
      "e": 34503,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 34911,
      "e": 34511,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 34912,
      "e": 34512,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34983,
      "e": 34583,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 35007,
      "e": 34607,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 35008,
      "e": 34608,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35079,
      "e": 34679,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 35110,
      "e": 34710,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 35110,
      "e": 34710,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35175,
      "e": 34775,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 35191,
      "e": 34791,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 35192,
      "e": 34792,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35271,
      "e": 34871,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 35272,
      "e": 34872,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35279,
      "e": 34879,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 35279,
      "e": 34879,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35334,
      "e": 34934,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||teh"
    },
    {
      "t": 35359,
      "e": 34959,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 35367,
      "e": 34967,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 35367,
      "e": 34967,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 35367,
      "e": 34967,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35446,
      "e": 35046,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 35584,
      "e": 35184,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 35584,
      "e": 35184,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35654,
      "e": 35254,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 35678,
      "e": 35278,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 35678,
      "e": 35278,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35743,
      "e": 35343,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 35783,
      "e": 35383,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 35784,
      "e": 35384,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35879,
      "e": 35479,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 36055,
      "e": 35655,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 36144,
      "e": 35656,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "took me a few questions to figure out, but the left corner of the triangle (positioning the letter at the top) is where the time starts and teh ri"
    },
    {
      "t": 36223,
      "e": 35735,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 36287,
      "e": 35799,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "took me a few questions to figure out, but the left corner of the triangle (positioning the letter at the top) is where the time starts and teh r"
    },
    {
      "t": 36367,
      "e": 35879,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 36439,
      "e": 35951,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "took me a few questions to figure out, but the left corner of the triangle (positioning the letter at the top) is where the time starts and teh "
    },
    {
      "t": 36519,
      "e": 36031,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 36590,
      "e": 36102,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "took me a few questions to figure out, but the left corner of the triangle (positioning the letter at the top) is where the time starts and teh"
    },
    {
      "t": 36662,
      "e": 36174,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 36727,
      "e": 36239,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "took me a few questions to figure out, but the left corner of the triangle (positioning the letter at the top) is where the time starts and te"
    },
    {
      "t": 36855,
      "e": 36367,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 36911,
      "e": 36423,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "took me a few questions to figure out, but the left corner of the triangle (positioning the letter at the top) is where the time starts and t"
    },
    {
      "t": 37199,
      "e": 36711,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 37200,
      "e": 36712,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37278,
      "e": 36790,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 37311,
      "e": 36823,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 37311,
      "e": 36823,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37375,
      "e": 36887,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 37407,
      "e": 36919,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 37408,
      "e": 36920,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37488,
      "e": 36921,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 37591,
      "e": 37024,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 37592,
      "e": 37025,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37671,
      "e": 37104,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||f"
    },
    {
      "t": 37671,
      "e": 37104,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 37671,
      "e": 37104,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37743,
      "e": 37176,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 37831,
      "e": 37264,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 37832,
      "e": 37265,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37870,
      "e": 37303,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 37886,
      "e": 37319,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 37886,
      "e": 37319,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37951,
      "e": 37384,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 38327,
      "e": 37760,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 38422,
      "e": 37855,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "took me a few questions to figure out, but the left corner of the triangle (positioning the letter at the top) is where the time starts and the fig"
    },
    {
      "t": 38495,
      "e": 37928,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 38575,
      "e": 38008,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "took me a few questions to figure out, but the left corner of the triangle (positioning the letter at the top) is where the time starts and the fi"
    },
    {
      "t": 38631,
      "e": 38064,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 38758,
      "e": 38191,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "took me a few questions to figure out, but the left corner of the triangle (positioning the letter at the top) is where the time starts and the f"
    },
    {
      "t": 38814,
      "e": 38247,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 38903,
      "e": 38336,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "took me a few questions to figure out, but the left corner of the triangle (positioning the letter at the top) is where the time starts and the "
    },
    {
      "t": 38999,
      "e": 38432,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 39000,
      "e": 38433,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39079,
      "e": 38512,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 39166,
      "e": 38599,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 39167,
      "e": 38600,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39255,
      "e": 38688,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 39367,
      "e": 38800,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 39368,
      "e": 38801,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39439,
      "e": 38872,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 39447,
      "e": 38880,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 39449,
      "e": 38882,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39519,
      "e": 38952,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 39567,
      "e": 39000,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 39568,
      "e": 39001,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39647,
      "e": 39080,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 39663,
      "e": 39096,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 39664,
      "e": 39097,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39734,
      "e": 39167,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 40039,
      "e": 39472,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 40040,
      "e": 39473,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40119,
      "e": 39552,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 40119,
      "e": 39552,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40126,
      "e": 39559,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||co"
    },
    {
      "t": 40182,
      "e": 39615,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 40247,
      "e": 39680,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 40247,
      "e": 39680,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40351,
      "e": 39784,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 40439,
      "e": 39872,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 40439,
      "e": 39872,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40502,
      "e": 39935,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 40518,
      "e": 39951,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 40518,
      "e": 39951,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40590,
      "e": 40023,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 40590,
      "e": 40023,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40639,
      "e": 40024,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||er"
    },
    {
      "t": 40670,
      "e": 40055,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 40679,
      "e": 40064,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 40679,
      "e": 40064,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40743,
      "e": 40128,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 40871,
      "e": 40256,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 40872,
      "e": 40257,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40919,
      "e": 40304,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 40927,
      "e": 40312,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 40928,
      "e": 40313,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41031,
      "e": 40416,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 41135,
      "e": 40520,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 41135,
      "e": 40520,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41214,
      "e": 40599,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 41311,
      "e": 40696,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 41313,
      "e": 40698,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41431,
      "e": 40816,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 41431,
      "e": 40816,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41463,
      "e": 40848,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 41463,
      "e": 40848,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41470,
      "e": 40855,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||whe"
    },
    {
      "t": 41494,
      "e": 40879,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 41535,
      "e": 40920,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 41535,
      "e": 40920,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41582,
      "e": 40967,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 41663,
      "e": 41048,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 41663,
      "e": 41048,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41727,
      "e": 41112,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 41735,
      "e": 41120,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 41736,
      "e": 41121,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41767,
      "e": 41152,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 41814,
      "e": 41199,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 41846,
      "e": 41231,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 41846,
      "e": 41231,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41926,
      "e": 41311,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 41927,
      "e": 41312,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41958,
      "e": 41343,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ti"
    },
    {
      "t": 42022,
      "e": 41407,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 42303,
      "e": 41688,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 42304,
      "e": 41689,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42366,
      "e": 41751,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 42591,
      "e": 41976,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 42678,
      "e": 42063,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "took me a few questions to figure out, but the left corner of the triangle (positioning the letter at the top) is where the time starts and the right corner is where ti"
    },
    {
      "t": 42759,
      "e": 42144,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 42838,
      "e": 42223,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "took me a few questions to figure out, but the left corner of the triangle (positioning the letter at the top) is where the time starts and the right corner is where t"
    },
    {
      "t": 42983,
      "e": 42368,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 42983,
      "e": 42368,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43022,
      "e": 42407,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 43023,
      "e": 42408,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43079,
      "e": 42464,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||he"
    },
    {
      "t": 43102,
      "e": 42487,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 43151,
      "e": 42536,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 43152,
      "e": 42537,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43223,
      "e": 42608,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 43263,
      "e": 42648,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 43264,
      "e": 42649,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43366,
      "e": 42751,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 43366,
      "e": 42751,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 43367,
      "e": 42752,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43430,
      "e": 42815,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 43527,
      "e": 42912,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 43528,
      "e": 42913,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43590,
      "e": 42975,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 43590,
      "e": 42975,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43598,
      "e": 42983,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||me"
    },
    {
      "t": 43678,
      "e": 43063,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 43807,
      "e": 43192,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 43808,
      "e": 43193,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43878,
      "e": 43263,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 44007,
      "e": 43263,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "took me a few questions to figure out, but the left corner of the triangle (positioning the letter at the top) is where the time starts and the right corner is where the time "
    },
    {
      "t": 44078,
      "e": 43334,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 44079,
      "e": 43335,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44175,
      "e": 43431,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 44199,
      "e": 43455,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 44200,
      "e": 43456,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44263,
      "e": 43519,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 44319,
      "e": 43575,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 44320,
      "e": 43576,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44383,
      "e": 43639,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 44383,
      "e": 43639,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44422,
      "e": 43678,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ds"
    },
    {
      "t": 44470,
      "e": 43726,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 44583,
      "e": 43839,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "190"
    },
    {
      "t": 44584,
      "e": 43840,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44686,
      "e": 43942,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||."
    },
    {
      "t": 44695,
      "e": 43951,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 44695,
      "e": 43951,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44758,
      "e": 44014,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 45804,
      "e": 45060,
      "ty": 2,
      "x": 563,
      "y": 538
    },
    {
      "t": 45904,
      "e": 45160,
      "ty": 2,
      "x": 573,
      "y": 530
    },
    {
      "t": 46005,
      "e": 45261,
      "ty": 2,
      "x": 573,
      "y": 528
    },
    {
      "t": 46005,
      "e": 45261,
      "ty": 41,
      "x": 53496,
      "y": 4260,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46104,
      "e": 45360,
      "ty": 2,
      "x": 578,
      "y": 530
    },
    {
      "t": 46204,
      "e": 45460,
      "ty": 2,
      "x": 580,
      "y": 531
    },
    {
      "t": 46255,
      "e": 45511,
      "ty": 41,
      "x": 54508,
      "y": 6687,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46304,
      "e": 45560,
      "ty": 2,
      "x": 582,
      "y": 531
    },
    {
      "t": 46330,
      "e": 45586,
      "ty": 3,
      "x": 582,
      "y": 531,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46435,
      "e": 45691,
      "ty": 4,
      "x": 54508,
      "y": 6687,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46435,
      "e": 45691,
      "ty": 5,
      "x": 582,
      "y": 531,
      "ta": "#strategyAnswer"
    },
    {
      "t": 47495,
      "e": 46751,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 47497,
      "e": 46753,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 47598,
      "e": 46854,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "took me a few questions to figure out, but the left corner of the etriangle (positioning the letter at the top) is where the time starts and the right corner is where the time ends. "
    },
    {
      "t": 47695,
      "e": 46951,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "81"
    },
    {
      "t": 47696,
      "e": 46952,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 47783,
      "e": 47039,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "took me a few questions to figure out, but the left corner of the eqtriangle (positioning the letter at the top) is where the time starts and the right corner is where the time ends. "
    },
    {
      "t": 47823,
      "e": 47079,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 47832,
      "e": 47088,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 47926,
      "e": 47182,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "took me a few questions to figure out, but the left corner of the equtriangle (positioning the letter at the top) is where the time starts and the right corner is where the time ends. "
    },
    {
      "t": 47943,
      "e": 47199,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 47943,
      "e": 47199,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48103,
      "e": 47199,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "took me a few questions to figure out, but the left corner of the equitriangle (positioning the letter at the top) is where the time starts and the right corner is where the time ends. "
    },
    {
      "t": 48142,
      "e": 47238,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 48142,
      "e": 47238,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48246,
      "e": 47342,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "took me a few questions to figure out, but the left corner of the equiltriangle (positioning the letter at the top) is where the time starts and the right corner is where the time ends. "
    },
    {
      "t": 48279,
      "e": 47375,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 48279,
      "e": 47375,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48367,
      "e": 47463,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "took me a few questions to figure out, but the left corner of the equilatriangle (positioning the letter at the top) is where the time starts and the right corner is where the time ends. "
    },
    {
      "t": 48447,
      "e": 47543,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 48448,
      "e": 47544,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48535,
      "e": 47631,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "took me a few questions to figure out, but the left corner of the equilattriangle (positioning the letter at the top) is where the time starts and the right corner is where the time ends. "
    },
    {
      "t": 48615,
      "e": 47711,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 48616,
      "e": 47712,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48694,
      "e": 47790,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 48694,
      "e": 47790,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48719,
      "e": 47790,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "took me a few questions to figure out, but the left corner of the equilatertriangle (positioning the letter at the top) is where the time starts and the right corner is where the time ends. "
    },
    {
      "t": 48774,
      "e": 47845,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 48863,
      "e": 47934,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 48863,
      "e": 47934,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48951,
      "e": 48022,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "took me a few questions to figure out, but the left corner of the equilateratriangle (positioning the letter at the top) is where the time starts and the right corner is where the time ends. "
    },
    {
      "t": 48999,
      "e": 48070,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 48999,
      "e": 48070,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49070,
      "e": 48141,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "took me a few questions to figure out, but the left corner of the equilateraltriangle (positioning the letter at the top) is where the time starts and the right corner is where the time ends. "
    },
    {
      "t": 49943,
      "e": 49014,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 49943,
      "e": 49014,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50038,
      "e": 49109,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "took me a few questions to figure out, but the left corner of the equilateral triangle (positioning the letter at the top) is where the time starts and the right corner is where the time ends. "
    },
    {
      "t": 50255,
      "e": 49326,
      "ty": 41,
      "x": 54620,
      "y": 5069,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50262,
      "e": 49333,
      "ty": 7,
      "x": 565,
      "y": 482,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50304,
      "e": 49375,
      "ty": 2,
      "x": 393,
      "y": 191
    },
    {
      "t": 50404,
      "e": 49475,
      "ty": 2,
      "x": 310,
      "y": 27
    },
    {
      "t": 50505,
      "e": 49576,
      "ty": 2,
      "x": 334,
      "y": 311
    },
    {
      "t": 50505,
      "e": 49576,
      "ty": 41,
      "x": 26630,
      "y": 16785,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 50563,
      "e": 49634,
      "ty": 6,
      "x": 339,
      "y": 549,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50595,
      "e": 49666,
      "ty": 7,
      "x": 337,
      "y": 621,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50605,
      "e": 49676,
      "ty": 2,
      "x": 337,
      "y": 621
    },
    {
      "t": 50678,
      "e": 49749,
      "ty": 6,
      "x": 342,
      "y": 664,
      "ta": "#strategyButton"
    },
    {
      "t": 50704,
      "e": 49775,
      "ty": 2,
      "x": 349,
      "y": 661
    },
    {
      "t": 50754,
      "e": 49825,
      "ty": 41,
      "x": 10052,
      "y": 511,
      "ta": "#strategyButton"
    },
    {
      "t": 50762,
      "e": 49833,
      "ty": 7,
      "x": 362,
      "y": 647,
      "ta": "#strategyButton"
    },
    {
      "t": 50796,
      "e": 49867,
      "ty": 6,
      "x": 372,
      "y": 602,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50804,
      "e": 49875,
      "ty": 2,
      "x": 372,
      "y": 602
    },
    {
      "t": 50904,
      "e": 49975,
      "ty": 2,
      "x": 384,
      "y": 556
    },
    {
      "t": 51004,
      "e": 50075,
      "ty": 2,
      "x": 384,
      "y": 552
    },
    {
      "t": 51004,
      "e": 50075,
      "ty": 41,
      "x": 32251,
      "y": 23678,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51104,
      "e": 50175,
      "ty": 2,
      "x": 384,
      "y": 557
    },
    {
      "t": 51203,
      "e": 50274,
      "ty": 3,
      "x": 384,
      "y": 561,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51206,
      "e": 50277,
      "ty": 2,
      "x": 384,
      "y": 561
    },
    {
      "t": 51255,
      "e": 50326,
      "ty": 41,
      "x": 32251,
      "y": 30959,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51404,
      "e": 50475,
      "ty": 2,
      "x": 202,
      "y": 526
    },
    {
      "t": 51412,
      "e": 50483,
      "ty": 7,
      "x": 186,
      "y": 520,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51504,
      "e": 50483,
      "ty": 2,
      "x": 124,
      "y": 480
    },
    {
      "t": 51505,
      "e": 50484,
      "ty": 41,
      "x": 3024,
      "y": 1247,
      "ta": "> div.stimulus > div > div:[2]"
    },
    {
      "t": 51604,
      "e": 50583,
      "ty": 2,
      "x": 96,
      "y": 464
    },
    {
      "t": 51704,
      "e": 50683,
      "ty": 2,
      "x": 95,
      "y": 464
    },
    {
      "t": 51755,
      "e": 50734,
      "ty": 41,
      "x": 2996,
      "y": 25261,
      "ta": "> div.stimulus"
    },
    {
      "t": 51804,
      "e": 50783,
      "ty": 2,
      "x": 94,
      "y": 464
    },
    {
      "t": 51811,
      "e": 50790,
      "ty": 4,
      "x": 2961,
      "y": 25261,
      "ta": "> div.stimulus"
    },
    {
      "t": 51904,
      "e": 50883,
      "ty": 2,
      "x": 92,
      "y": 464
    },
    {
      "t": 52005,
      "e": 50984,
      "ty": 41,
      "x": 2892,
      "y": 25261,
      "ta": "> div.stimulus"
    },
    {
      "t": 52239,
      "e": 51218,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "18"
    },
    {
      "t": 52487,
      "e": 51466,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 52631,
      "e": 51610,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 52663,
      "e": 51642,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 53304,
      "e": 52283,
      "ty": 2,
      "x": 93,
      "y": 463
    },
    {
      "t": 53505,
      "e": 52484,
      "ty": 41,
      "x": 2927,
      "y": 25205,
      "ta": "> div.stimulus"
    },
    {
      "t": 53755,
      "e": 52734,
      "ty": 41,
      "x": 2996,
      "y": 25150,
      "ta": "> div.stimulus"
    },
    {
      "t": 53805,
      "e": 52784,
      "ty": 2,
      "x": 95,
      "y": 462
    },
    {
      "t": 54199,
      "e": 53178,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "17"
    },
    {
      "t": 54559,
      "e": 53538,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 54678,
      "e": 53657,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": ""
    },
    {
      "t": 54718,
      "e": 53697,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": ""
    },
    {
      "t": 55430,
      "e": 54409,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "18"
    },
    {
      "t": 55479,
      "e": 54458,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": ""
    },
    {
      "t": 55766,
      "e": 54745,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "17"
    },
    {
      "t": 56000,
      "e": 54979,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "86"
    },
    {
      "t": 56086,
      "e": 55065,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "took me a few questions to figure out, but the left corner of the equilateral triangle (positioning the letter at the top) is where the time starts and the right corner is where the time ends. "
    },
    {
      "t": 56102,
      "e": 55081,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 56250,
      "e": 55229,
      "ty": 6,
      "x": 226,
      "y": 591,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56254,
      "e": 55233,
      "ty": 41,
      "x": 14490,
      "y": 55231,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56266,
      "e": 55245,
      "ty": 7,
      "x": 268,
      "y": 626,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56305,
      "e": 55284,
      "ty": 2,
      "x": 293,
      "y": 656
    },
    {
      "t": 56405,
      "e": 55384,
      "ty": 2,
      "x": 291,
      "y": 657
    },
    {
      "t": 56466,
      "e": 55445,
      "ty": 6,
      "x": 267,
      "y": 597,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56505,
      "e": 55484,
      "ty": 2,
      "x": 256,
      "y": 575
    },
    {
      "t": 56505,
      "e": 55484,
      "ty": 41,
      "x": 17862,
      "y": 42286,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56604,
      "e": 55583,
      "ty": 2,
      "x": 301,
      "y": 558
    },
    {
      "t": 56704,
      "e": 55683,
      "ty": 2,
      "x": 412,
      "y": 576
    },
    {
      "t": 56734,
      "e": 55713,
      "ty": 7,
      "x": 430,
      "y": 615,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56754,
      "e": 55733,
      "ty": 41,
      "x": 57767,
      "y": 16557,
      "ta": "> div.stimulus > div > div:[3]"
    },
    {
      "t": 56767,
      "e": 55746,
      "ty": 6,
      "x": 447,
      "y": 664,
      "ta": "#strategyButton"
    },
    {
      "t": 56804,
      "e": 55783,
      "ty": 2,
      "x": 448,
      "y": 673
    },
    {
      "t": 56905,
      "e": 55884,
      "ty": 2,
      "x": 448,
      "y": 676
    },
    {
      "t": 57007,
      "e": 55986,
      "ty": 2,
      "x": 439,
      "y": 683
    },
    {
      "t": 57007,
      "e": 55986,
      "ty": 41,
      "x": 54834,
      "y": 54481,
      "ta": "#strategyButton"
    },
    {
      "t": 57105,
      "e": 56084,
      "ty": 2,
      "x": 432,
      "y": 683
    },
    {
      "t": 57205,
      "e": 56184,
      "ty": 2,
      "x": 430,
      "y": 682
    },
    {
      "t": 57255,
      "e": 56234,
      "ty": 41,
      "x": 49919,
      "y": 52554,
      "ta": "#strategyButton"
    },
    {
      "t": 57305,
      "e": 56284,
      "ty": 2,
      "x": 428,
      "y": 678
    },
    {
      "t": 57405,
      "e": 56384,
      "ty": 2,
      "x": 420,
      "y": 674
    },
    {
      "t": 57504,
      "e": 56483,
      "ty": 2,
      "x": 416,
      "y": 672
    },
    {
      "t": 57505,
      "e": 56484,
      "ty": 41,
      "x": 42273,
      "y": 33279,
      "ta": "#strategyButton"
    },
    {
      "t": 58304,
      "e": 57283,
      "ty": 2,
      "x": 416,
      "y": 668
    },
    {
      "t": 58335,
      "e": 57314,
      "ty": 7,
      "x": 416,
      "y": 643,
      "ta": "#strategyButton"
    },
    {
      "t": 58401,
      "e": 57380,
      "ty": 6,
      "x": 429,
      "y": 601,
      "ta": "#strategyAnswer"
    },
    {
      "t": 58405,
      "e": 57384,
      "ty": 2,
      "x": 429,
      "y": 601
    },
    {
      "t": 58505,
      "e": 57484,
      "ty": 2,
      "x": 477,
      "y": 529
    },
    {
      "t": 58505,
      "e": 57484,
      "ty": 41,
      "x": 42705,
      "y": 5069,
      "ta": "#strategyAnswer"
    },
    {
      "t": 58605,
      "e": 57584,
      "ty": 2,
      "x": 478,
      "y": 527
    },
    {
      "t": 58704,
      "e": 57683,
      "ty": 2,
      "x": 475,
      "y": 537
    },
    {
      "t": 58755,
      "e": 57734,
      "ty": 41,
      "x": 41243,
      "y": 34196,
      "ta": "#strategyAnswer"
    },
    {
      "t": 58805,
      "e": 57784,
      "ty": 2,
      "x": 461,
      "y": 573
    },
    {
      "t": 59004,
      "e": 57983,
      "ty": 2,
      "x": 438,
      "y": 580
    },
    {
      "t": 59005,
      "e": 57984,
      "ty": 41,
      "x": 38321,
      "y": 46332,
      "ta": "#strategyAnswer"
    },
    {
      "t": 59105,
      "e": 58084,
      "ty": 2,
      "x": 417,
      "y": 585
    },
    {
      "t": 59204,
      "e": 58183,
      "ty": 2,
      "x": 414,
      "y": 576
    },
    {
      "t": 59255,
      "e": 58234,
      "ty": 41,
      "x": 35511,
      "y": 42286,
      "ta": "#strategyAnswer"
    },
    {
      "t": 59305,
      "e": 58284,
      "ty": 2,
      "x": 413,
      "y": 575
    },
    {
      "t": 59332,
      "e": 58311,
      "ty": 3,
      "x": 413,
      "y": 575,
      "ta": "#strategyAnswer"
    },
    {
      "t": 59402,
      "e": 58381,
      "ty": 4,
      "x": 35511,
      "y": 42286,
      "ta": "#strategyAnswer"
    },
    {
      "t": 59402,
      "e": 58381,
      "ty": 5,
      "x": 413,
      "y": 575,
      "ta": "#strategyAnswer"
    },
    {
      "t": 59703,
      "e": 58682,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 59895,
      "e": 58874,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 59895,
      "e": 58874,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 60004,
      "e": 58983,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 60006,
      "e": 58985,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "took me a few questions to figure out, but the left corner of the equilateral triangle (positioning the letter at the top) is where the time starts and the right corner is where the time ends. S"
    },
    {
      "t": 60006,
      "e": 58985,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||S"
    },
    {
      "t": 60014,
      "e": 58993,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 60990,
      "e": 59969,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 60992,
      "e": 59971,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 61062,
      "e": 60041,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 61142,
      "e": 60121,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 61143,
      "e": 60122,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 61222,
      "e": 60201,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 61495,
      "e": 60474,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 61687,
      "e": 60666,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 61687,
      "e": 60666,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 61783,
      "e": 60762,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||I"
    },
    {
      "t": 61799,
      "e": 60778,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 61807,
      "e": 60786,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 61808,
      "e": 60787,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 61894,
      "e": 60873,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 62006,
      "e": 60985,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "took me a few questions to figure out, but the left corner of the equilateral triangle (positioning the letter at the top) is where the time starts and the right corner is where the time ends. So I "
    },
    {
      "t": 66190,
      "e": 65169,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 66191,
      "e": 65170,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 66262,
      "e": 65241,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 66263,
      "e": 65242,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 66286,
      "e": 65265,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||fi"
    },
    {
      "t": 66358,
      "e": 65337,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 66423,
      "e": 65402,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 66423,
      "e": 65402,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 66550,
      "e": 65529,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 66566,
      "e": 65545,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 66566,
      "e": 65545,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 66638,
      "e": 65617,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 66686,
      "e": 65665,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 66687,
      "e": 65666,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 66790,
      "e": 65769,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 67470,
      "e": 66449,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 67550,
      "e": 66529,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "took me a few questions to figure out, but the left corner of the equilateral triangle (positioning the letter at the top) is where the time starts and the right corner is where the time ends. So I figh"
    },
    {
      "t": 67679,
      "e": 66658,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 67783,
      "e": 66659,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "took me a few questions to figure out, but the left corner of the equilateral triangle (positioning the letter at the top) is where the time starts and the right corner is where the time ends. So I fig"
    },
    {
      "t": 67894,
      "e": 66770,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 67966,
      "e": 66842,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "took me a few questions to figure out, but the left corner of the equilateral triangle (positioning the letter at the top) is where the time starts and the right corner is where the time ends. So I fi"
    },
    {
      "t": 68486,
      "e": 67362,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 68486,
      "e": 67362,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 68566,
      "e": 67442,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 68702,
      "e": 67578,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 68703,
      "e": 67579,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 68790,
      "e": 67666,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||u"
    },
    {
      "t": 68806,
      "e": 67682,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 68806,
      "e": 67682,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 68902,
      "e": 67778,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 68902,
      "e": 67778,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 68974,
      "e": 67850,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||re"
    },
    {
      "t": 69006,
      "e": 67882,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 69006,
      "e": 67882,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 69014,
      "e": 67890,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 69095,
      "e": 67971,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 69127,
      "e": 68003,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 69128,
      "e": 68004,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 69205,
      "e": 68081,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 69206,
      "e": 68082,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 69254,
      "e": 68130,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ou"
    },
    {
      "t": 69319,
      "e": 68195,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 69319,
      "e": 68195,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 69326,
      "e": 68202,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 69398,
      "e": 68274,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 69430,
      "e": 68306,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 69431,
      "e": 68307,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 69510,
      "e": 68386,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 69566,
      "e": 68442,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 69567,
      "e": 68443,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 69631,
      "e": 68507,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 69631,
      "e": 68507,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 69662,
      "e": 68538,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||wh"
    },
    {
      "t": 69711,
      "e": 68587,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 69830,
      "e": 68706,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 69831,
      "e": 68707,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 69942,
      "e": 68818,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 69942,
      "e": 68818,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 69974,
      "e": 68850,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||at"
    },
    {
      "t": 70046,
      "e": 68922,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 70070,
      "e": 68946,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 70070,
      "e": 68946,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 70150,
      "e": 69026,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 70318,
      "e": 69194,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 70319,
      "e": 69195,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 70405,
      "e": 69281,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 70494,
      "e": 69370,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 70494,
      "e": 69370,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 70606,
      "e": 69482,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "took me a few questions to figure out, but the left corner of the equilateral triangle (positioning the letter at the top) is where the time starts and the right corner is where the time ends. So I figure out what tr"
    },
    {
      "t": 70608,
      "e": 69484,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 70610,
      "e": 69486,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 70612,
      "e": 69488,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 70678,
      "e": 69554,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 70798,
      "e": 69674,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 70798,
      "e": 69674,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 70894,
      "e": 69770,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 70951,
      "e": 69827,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 70951,
      "e": 69827,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 71022,
      "e": 69898,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 71134,
      "e": 70010,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 71134,
      "e": 70010,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 71238,
      "e": 70114,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 71278,
      "e": 70154,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 71279,
      "e": 70155,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 71350,
      "e": 70226,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 71381,
      "e": 70257,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 71381,
      "e": 70257,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 71470,
      "e": 70346,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 71470,
      "e": 70346,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 71527,
      "e": 70403,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||es"
    },
    {
      "t": 71574,
      "e": 70450,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 71639,
      "e": 70515,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 71639,
      "e": 70515,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 71718,
      "e": 70594,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 75851,
      "e": 74727,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 75962,
      "e": 74838,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "took me a few questions to figure out, but the left corner of the equilateral triangle (positioning the letter at the top) is where the time starts and the right corner is where the time ends. So I figure out what triangles"
    },
    {
      "t": 76050,
      "e": 74926,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 76138,
      "e": 75014,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "took me a few questions to figure out, but the left corner of the equilateral triangle (positioning the letter at the top) is where the time starts and the right corner is where the time ends. So I figure out what triangle"
    },
    {
      "t": 76346,
      "e": 75222,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "222"
    },
    {
      "t": 76347,
      "e": 75223,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 76418,
      "e": 75294,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||'"
    },
    {
      "t": 76722,
      "e": 75598,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 76834,
      "e": 75710,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "took me a few questions to figure out, but the left corner of the equilateral triangle (positioning the letter at the top) is where the time starts and the right corner is where the time ends. So I figure out what triangle"
    },
    {
      "t": 76874,
      "e": 75750,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 76874,
      "e": 75750,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 76970,
      "e": 75846,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 77074,
      "e": 75950,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "222"
    },
    {
      "t": 77075,
      "e": 75951,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 77169,
      "e": 76045,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||'"
    },
    {
      "t": 77330,
      "e": 76206,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 77331,
      "e": 76207,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 77410,
      "e": 76286,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 78234,
      "e": 77110,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 78235,
      "e": 77111,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 78298,
      "e": 77111,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 78410,
      "e": 77223,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "took me a few questions to figure out, but the left corner of the equilateral triangle (positioning the letter at the top) is where the time starts and the right corner is where the time ends. So I figure out what triangles' l"
    },
    {
      "t": 78411,
      "e": 77224,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 78411,
      "e": 77224,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 78490,
      "e": 77303,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 78513,
      "e": 77326,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 78514,
      "e": 77327,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 78626,
      "e": 77439,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 78626,
      "e": 77439,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 78642,
      "e": 77455,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||we"
    },
    {
      "t": 78762,
      "e": 77575,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 78763,
      "e": 77576,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 78794,
      "e": 77607,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 78825,
      "e": 77638,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 78882,
      "e": 77695,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 78882,
      "e": 77695,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 78961,
      "e": 77774,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 79338,
      "e": 78151,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 79339,
      "e": 78152,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 79425,
      "e": 78238,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||c"
    },
    {
      "t": 79466,
      "e": 78279,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 79466,
      "e": 78279,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 79538,
      "e": 78351,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 79570,
      "e": 78383,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 79571,
      "e": 78384,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 79682,
      "e": 78495,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 79819,
      "e": 78632,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 79819,
      "e": 78632,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 79889,
      "e": 78702,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 79905,
      "e": 78718,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 79905,
      "e": 78718,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 79953,
      "e": 78766,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 79953,
      "e": 78766,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 80002,
      "e": 78815,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||er"
    },
    {
      "t": 80066,
      "e": 78879,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 80067,
      "e": 78880,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 80073,
      "e": 78886,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 80153,
      "e": 78966,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 80258,
      "e": 79071,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 80258,
      "e": 79071,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 80330,
      "e": 79143,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 80555,
      "e": 79368,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 80555,
      "e": 79368,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 80658,
      "e": 79471,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 80689,
      "e": 79502,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 80690,
      "e": 79503,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 80753,
      "e": 79566,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 80978,
      "e": 79791,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 80979,
      "e": 79792,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 81057,
      "e": 79870,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 81122,
      "e": 79935,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 81122,
      "e": 79935,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 81202,
      "e": 80015,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 81235,
      "e": 80048,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 81235,
      "e": 80048,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 81305,
      "e": 80118,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 81362,
      "e": 80175,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 81362,
      "e": 80175,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 81442,
      "e": 80255,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 81491,
      "e": 80304,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 81491,
      "e": 80304,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 81570,
      "e": 80383,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 81572,
      "e": 80385,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 81577,
      "e": 80390,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ti"
    },
    {
      "t": 81650,
      "e": 80463,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 81722,
      "e": 80535,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 81723,
      "e": 80536,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 81785,
      "e": 80598,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 81922,
      "e": 80735,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 81923,
      "e": 80736,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 82033,
      "e": 80846,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 82074,
      "e": 80887,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 82074,
      "e": 80887,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 82170,
      "e": 80983,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 82243,
      "e": 81056,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 82243,
      "e": 81056,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 82338,
      "e": 81151,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 82386,
      "e": 81199,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 82387,
      "e": 81200,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 82473,
      "e": 81286,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 82579,
      "e": 81392,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 82579,
      "e": 81392,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 82674,
      "e": 81487,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 82681,
      "e": 81494,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 82681,
      "e": 81494,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 82778,
      "e": 81591,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 82818,
      "e": 81631,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 82819,
      "e": 81632,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 82890,
      "e": 81703,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 83011,
      "e": 81703,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "took me a few questions to figure out, but the left corner of the equilateral triangle (positioning the letter at the top) is where the time starts and the right corner is where the time ends. So I figure out what triangles' lower corner is positioned at "
    },
    {
      "t": 83418,
      "e": 82110,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 83419,
      "e": 82111,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 83578,
      "e": 82270,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 83578,
      "e": 82270,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 83642,
      "e": 82334,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||12"
    },
    {
      "t": 83698,
      "e": 82390,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 84819,
      "e": 83511,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 84819,
      "e": 83511,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 84929,
      "e": 83621,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 85041,
      "e": 83733,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 85042,
      "e": 83734,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 85129,
      "e": 83821,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 86009,
      "e": 84701,
      "ty": 2,
      "x": 413,
      "y": 574
    },
    {
      "t": 86009,
      "e": 84701,
      "ty": 41,
      "x": 35511,
      "y": 41477,
      "ta": "#strategyAnswer"
    },
    {
      "t": 86043,
      "e": 84735,
      "ty": 7,
      "x": 738,
      "y": 670,
      "ta": "#strategyAnswer"
    },
    {
      "t": 86108,
      "e": 84800,
      "ty": 2,
      "x": 1281,
      "y": 966
    },
    {
      "t": 86208,
      "e": 84900,
      "ty": 2,
      "x": 1284,
      "y": 966
    },
    {
      "t": 86259,
      "e": 84951,
      "ty": 41,
      "x": 35094,
      "y": 59303,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 86309,
      "e": 85001,
      "ty": 2,
      "x": 1284,
      "y": 967
    },
    {
      "t": 86408,
      "e": 85100,
      "ty": 2,
      "x": 1351,
      "y": 1042
    },
    {
      "t": 86509,
      "e": 85201,
      "ty": 2,
      "x": 1176,
      "y": 1108
    },
    {
      "t": 86509,
      "e": 85201,
      "ty": 41,
      "x": 40223,
      "y": 60937,
      "ta": "> div.stimulus"
    },
    {
      "t": 86608,
      "e": 85300,
      "ty": 2,
      "x": 785,
      "y": 1039
    },
    {
      "t": 86708,
      "e": 85400,
      "ty": 2,
      "x": 586,
      "y": 883
    },
    {
      "t": 86759,
      "e": 85451,
      "ty": 41,
      "x": 53721,
      "y": 45647,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 86809,
      "e": 85501,
      "ty": 2,
      "x": 553,
      "y": 817
    },
    {
      "t": 86909,
      "e": 85601,
      "ty": 2,
      "x": 439,
      "y": 733
    },
    {
      "t": 87009,
      "e": 85701,
      "ty": 2,
      "x": 333,
      "y": 673
    },
    {
      "t": 87009,
      "e": 85701,
      "ty": 41,
      "x": 6743,
      "y": 33596,
      "ta": "> div.stimulus > div > div:[3]"
    },
    {
      "t": 87109,
      "e": 85801,
      "ty": 2,
      "x": 332,
      "y": 669
    },
    {
      "t": 87146,
      "e": 85838,
      "ty": 6,
      "x": 340,
      "y": 669,
      "ta": "#strategyButton"
    },
    {
      "t": 87209,
      "e": 85901,
      "ty": 2,
      "x": 355,
      "y": 673
    },
    {
      "t": 87259,
      "e": 85951,
      "ty": 41,
      "x": 11144,
      "y": 35206,
      "ta": "#strategyButton"
    },
    {
      "t": 87308,
      "e": 86000,
      "ty": 2,
      "x": 365,
      "y": 673
    },
    {
      "t": 87367,
      "e": 86059,
      "ty": 3,
      "x": 368,
      "y": 673,
      "ta": "#strategyButton"
    },
    {
      "t": 87367,
      "e": 86059,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "took me a few questions to figure out, but the left corner of the equilateral triangle (positioning the letter at the top) is where the time starts and the right corner is where the time ends. So I figure out what triangles' lower corner is positioned at 12pm"
    },
    {
      "t": 87369,
      "e": 86061,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 87369,
      "e": 86061,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 87408,
      "e": 86100,
      "ty": 2,
      "x": 368,
      "y": 673
    },
    {
      "t": 87477,
      "e": 86169,
      "ty": 4,
      "x": 16059,
      "y": 35206,
      "ta": "#strategyButton"
    },
    {
      "t": 87487,
      "e": 86179,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 87488,
      "e": 86180,
      "ty": 5,
      "x": 368,
      "y": 673,
      "ta": "#strategyButton"
    },
    {
      "t": 87492,
      "e": 86184,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 87509,
      "e": 86201,
      "ty": 2,
      "x": 369,
      "y": 673
    },
    {
      "t": 87509,
      "e": 86201,
      "ty": 41,
      "x": 12432,
      "y": 36839,
      "ta": "html > body"
    },
    {
      "t": 88109,
      "e": 86801,
      "ty": 2,
      "x": 536,
      "y": 645
    },
    {
      "t": 88209,
      "e": 86901,
      "ty": 2,
      "x": 893,
      "y": 590
    },
    {
      "t": 88259,
      "e": 86951,
      "ty": 41,
      "x": 31028,
      "y": 31742,
      "ta": "html > body"
    },
    {
      "t": 88309,
      "e": 87001,
      "ty": 2,
      "x": 909,
      "y": 581
    },
    {
      "t": 88495,
      "e": 87187,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 89011,
      "e": 87703,
      "ty": 2,
      "x": 917,
      "y": 606
    },
    {
      "t": 89011,
      "e": 87703,
      "ty": 41,
      "x": 23575,
      "y": 11702,
      "ta": "#jspsych-survey-text-1 > p"
    },
    {
      "t": 89108,
      "e": 87800,
      "ty": 2,
      "x": 914,
      "y": 583
    },
    {
      "t": 89113,
      "e": 87805,
      "ty": 6,
      "x": 907,
      "y": 574,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 89209,
      "e": 87901,
      "ty": 2,
      "x": 907,
      "y": 568
    },
    {
      "t": 89230,
      "e": 87922,
      "ty": 7,
      "x": 898,
      "y": 549,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 89260,
      "e": 87923,
      "ty": 41,
      "x": 19465,
      "y": 40871,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 89308,
      "e": 87971,
      "ty": 2,
      "x": 898,
      "y": 548
    },
    {
      "t": 89409,
      "e": 88072,
      "ty": 2,
      "x": 904,
      "y": 552
    },
    {
      "t": 89413,
      "e": 88076,
      "ty": 6,
      "x": 905,
      "y": 555,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 89509,
      "e": 88172,
      "ty": 2,
      "x": 906,
      "y": 557
    },
    {
      "t": 89509,
      "e": 88172,
      "ty": 41,
      "x": 21196,
      "y": 9362,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 89609,
      "e": 88272,
      "ty": 2,
      "x": 907,
      "y": 558
    },
    {
      "t": 89615,
      "e": 88278,
      "ty": 3,
      "x": 907,
      "y": 558,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 89616,
      "e": 88279,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 89742,
      "e": 88405,
      "ty": 4,
      "x": 21412,
      "y": 12482,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 89742,
      "e": 88405,
      "ty": 5,
      "x": 907,
      "y": 558,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 89759,
      "e": 88422,
      "ty": 41,
      "x": 21412,
      "y": 12482,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 90026,
      "e": 88689,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "49"
    },
    {
      "t": 90026,
      "e": 88689,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 90114,
      "e": 88777,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "1"
    },
    {
      "t": 90482,
      "e": 89145,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "57"
    },
    {
      "t": 90482,
      "e": 89145,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 90593,
      "e": 89256,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "19"
    },
    {
      "t": 90682,
      "e": 89345,
      "ty": 7,
      "x": 909,
      "y": 585,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 90709,
      "e": 89372,
      "ty": 2,
      "x": 912,
      "y": 599
    },
    {
      "t": 90759,
      "e": 89422,
      "ty": 41,
      "x": 24007,
      "y": 49151,
      "ta": "#jspsych-survey-text-1 > p"
    },
    {
      "t": 90808,
      "e": 89471,
      "ty": 2,
      "x": 919,
      "y": 635
    },
    {
      "t": 90909,
      "e": 89572,
      "ty": 2,
      "x": 923,
      "y": 644
    },
    {
      "t": 90915,
      "e": 89578,
      "ty": 6,
      "x": 925,
      "y": 650,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 91009,
      "e": 89672,
      "ty": 2,
      "x": 926,
      "y": 664
    },
    {
      "t": 91009,
      "e": 89672,
      "ty": 41,
      "x": 25521,
      "y": 53052,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 91209,
      "e": 89872,
      "ty": 2,
      "x": 926,
      "y": 662
    },
    {
      "t": 91259,
      "e": 89922,
      "ty": 41,
      "x": 25521,
      "y": 46810,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 91422,
      "e": 90085,
      "ty": 3,
      "x": 926,
      "y": 662,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 91424,
      "e": 90087,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "19"
    },
    {
      "t": 91424,
      "e": 90087,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 91425,
      "e": 90088,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 91541,
      "e": 90204,
      "ty": 4,
      "x": 25521,
      "y": 46810,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 91542,
      "e": 90205,
      "ty": 5,
      "x": 926,
      "y": 662,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 91732,
      "e": 90395,
      "ty": 7,
      "x": 920,
      "y": 644,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 91759,
      "e": 90422,
      "ty": 41,
      "x": 23142,
      "y": 36643,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 91808,
      "e": 90471,
      "ty": 2,
      "x": 906,
      "y": 602
    },
    {
      "t": 91909,
      "e": 90572,
      "ty": 2,
      "x": 891,
      "y": 583
    },
    {
      "t": 91916,
      "e": 90579,
      "ty": 6,
      "x": 884,
      "y": 569,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 91949,
      "e": 90612,
      "ty": 7,
      "x": 875,
      "y": 548,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 92009,
      "e": 90672,
      "ty": 2,
      "x": 873,
      "y": 543
    },
    {
      "t": 92009,
      "e": 90672,
      "ty": 41,
      "x": 14058,
      "y": 37347,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 92209,
      "e": 90872,
      "ty": 2,
      "x": 873,
      "y": 552
    },
    {
      "t": 92232,
      "e": 90895,
      "ty": 6,
      "x": 875,
      "y": 554,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 92259,
      "e": 90922,
      "ty": 41,
      "x": 14491,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 92309,
      "e": 90972,
      "ty": 2,
      "x": 876,
      "y": 554
    },
    {
      "t": 92409,
      "e": 91072,
      "ty": 2,
      "x": 878,
      "y": 555
    },
    {
      "t": 92508,
      "e": 91171,
      "ty": 2,
      "x": 883,
      "y": 570
    },
    {
      "t": 92509,
      "e": 91172,
      "ty": 41,
      "x": 16221,
      "y": 49931,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 92534,
      "e": 91197,
      "ty": 3,
      "x": 883,
      "y": 570,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 92535,
      "e": 91198,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 92536,
      "e": 91199,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 92622,
      "e": 91285,
      "ty": 4,
      "x": 16221,
      "y": 49931,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 92623,
      "e": 91286,
      "ty": 5,
      "x": 883,
      "y": 570,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 93265,
      "e": 91928,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "8"
    },
    {
      "t": 93338,
      "e": 92001,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "1"
    },
    {
      "t": 93394,
      "e": 92057,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "8"
    },
    {
      "t": 93465,
      "e": 92128,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": ""
    },
    {
      "t": 93577,
      "e": 92240,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "50"
    },
    {
      "t": 93577,
      "e": 92240,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 93666,
      "e": 92329,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "2"
    },
    {
      "t": 93874,
      "e": 92537,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "48"
    },
    {
      "t": 93875,
      "e": 92538,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 93922,
      "e": 92585,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "20"
    },
    {
      "t": 94568,
      "e": 93231,
      "ty": 7,
      "x": 713,
      "y": 527,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 94608,
      "e": 93271,
      "ty": 2,
      "x": 567,
      "y": 508
    },
    {
      "t": 94707,
      "e": 93370,
      "ty": 2,
      "x": 624,
      "y": 568
    },
    {
      "t": 94758,
      "e": 93421,
      "ty": 41,
      "x": 21730,
      "y": 32296,
      "ta": "html > body"
    },
    {
      "t": 94808,
      "e": 93471,
      "ty": 2,
      "x": 689,
      "y": 609
    },
    {
      "t": 94908,
      "e": 93571,
      "ty": 2,
      "x": 813,
      "y": 636
    },
    {
      "t": 94935,
      "e": 93598,
      "ty": 6,
      "x": 842,
      "y": 655,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 94968,
      "e": 93631,
      "ty": 7,
      "x": 855,
      "y": 674,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 95008,
      "e": 93671,
      "ty": 2,
      "x": 855,
      "y": 677
    },
    {
      "t": 95008,
      "e": 93671,
      "ty": 41,
      "x": 29168,
      "y": 37060,
      "ta": "html > body"
    },
    {
      "t": 95186,
      "e": 93849,
      "ty": 6,
      "x": 862,
      "y": 667,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 95208,
      "e": 93871,
      "ty": 2,
      "x": 862,
      "y": 667
    },
    {
      "t": 95259,
      "e": 93922,
      "ty": 41,
      "x": 11679,
      "y": 62414,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 95308,
      "e": 93971,
      "ty": 2,
      "x": 862,
      "y": 662
    },
    {
      "t": 95408,
      "e": 94071,
      "ty": 2,
      "x": 862,
      "y": 655
    },
    {
      "t": 95415,
      "e": 94078,
      "ty": 3,
      "x": 862,
      "y": 655,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 95415,
      "e": 94078,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "20"
    },
    {
      "t": 95416,
      "e": 94079,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 95417,
      "e": 94080,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 95502,
      "e": 94165,
      "ty": 4,
      "x": 11679,
      "y": 24965,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 95503,
      "e": 94166,
      "ty": 5,
      "x": 862,
      "y": 655,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 95508,
      "e": 94171,
      "ty": 41,
      "x": 11679,
      "y": 24965,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 95914,
      "e": 94577,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 96413,
      "e": 95076,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 96446,
      "e": 95109,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 96479,
      "e": 95142,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 96512,
      "e": 95175,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 96545,
      "e": 95208,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 96578,
      "e": 95241,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 96611,
      "e": 95274,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 96644,
      "e": 95307,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 96677,
      "e": 95340,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 96710,
      "e": 95373,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 96743,
      "e": 95406,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 96776,
      "e": 95439,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 96809,
      "e": 95472,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 96842,
      "e": 95505,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 96875,
      "e": 95538,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 96908,
      "e": 95571,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 96941,
      "e": 95604,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 96974,
      "e": 95637,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 97007,
      "e": 95670,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 97040,
      "e": 95703,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 97073,
      "e": 95736,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 97106,
      "e": 95769,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 97139,
      "e": 95802,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 97172,
      "e": 95835,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 97205,
      "e": 95868,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 97238,
      "e": 95901,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 97271,
      "e": 95934,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 97304,
      "e": 95967,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 97338,
      "e": 96001,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 97370,
      "e": 96033,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 97403,
      "e": 96066,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 97436,
      "e": 96099,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 97442,
      "e": 96105,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "85"
    },
    {
      "t": 97442,
      "e": 96105,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 97513,
      "e": 96176,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "U"
    },
    {
      "t": 97601,
      "e": 96264,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "U"
    },
    {
      "t": 97913,
      "e": 96576,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "78"
    },
    {
      "t": 97915,
      "e": 96578,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 97977,
      "e": 96640,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Un"
    },
    {
      "t": 98049,
      "e": 96712,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "73"
    },
    {
      "t": 98050,
      "e": 96713,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 98138,
      "e": 96801,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Uni"
    },
    {
      "t": 98154,
      "e": 96817,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "84"
    },
    {
      "t": 98155,
      "e": 96818,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 98241,
      "e": 96904,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Unit"
    },
    {
      "t": 98289,
      "e": 96952,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "69"
    },
    {
      "t": 98290,
      "e": 96953,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 98387,
      "e": 96954,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||e"
    },
    {
      "t": 98546,
      "e": 97113,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "68"
    },
    {
      "t": 98546,
      "e": 97113,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 98642,
      "e": 97209,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||d"
    },
    {
      "t": 98674,
      "e": 97241,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "32"
    },
    {
      "t": 98674,
      "e": 97241,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 98745,
      "e": 97312,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+|| "
    },
    {
      "t": 98833,
      "e": 97400,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 99106,
      "e": 97673,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "83"
    },
    {
      "t": 99106,
      "e": 97673,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 99185,
      "e": 97752,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||S"
    },
    {
      "t": 99193,
      "e": 97760,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 99321,
      "e": 97888,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "84"
    },
    {
      "t": 99322,
      "e": 97889,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 99425,
      "e": 97992,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||t"
    },
    {
      "t": 99449,
      "e": 98016,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "65"
    },
    {
      "t": 99449,
      "e": 98016,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 99529,
      "e": 98096,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||a"
    },
    {
      "t": 99667,
      "e": 98234,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "84"
    },
    {
      "t": 99667,
      "e": 98234,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 99777,
      "e": 98344,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||t"
    },
    {
      "t": 99834,
      "e": 98401,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "69"
    },
    {
      "t": 99834,
      "e": 98401,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 99881,
      "e": 98448,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "83"
    },
    {
      "t": 99882,
      "e": 98449,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 99938,
      "e": 98505,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||es"
    },
    {
      "t": 99977,
      "e": 98544,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 100042,
      "e": 98609,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "32"
    },
    {
      "t": 100042,
      "e": 98609,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 100121,
      "e": 98688,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+|| "
    },
    {
      "t": 100185,
      "e": 98752,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "79"
    },
    {
      "t": 100185,
      "e": 98752,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 100250,
      "e": 98817,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||o"
    },
    {
      "t": 100273,
      "e": 98840,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "70"
    },
    {
      "t": 100274,
      "e": 98841,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 100354,
      "e": 98921,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||f"
    },
    {
      "t": 100370,
      "e": 98937,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "32"
    },
    {
      "t": 100370,
      "e": 98937,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 100449,
      "e": 99016,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+|| "
    },
    {
      "t": 100458,
      "e": 99025,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 100626,
      "e": 99193,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "65"
    },
    {
      "t": 100626,
      "e": 99193,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 100697,
      "e": 99264,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||A"
    },
    {
      "t": 100713,
      "e": 99280,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 100745,
      "e": 99312,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "77"
    },
    {
      "t": 100745,
      "e": 99312,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 100809,
      "e": 99376,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||m"
    },
    {
      "t": 100857,
      "e": 99424,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "69"
    },
    {
      "t": 100858,
      "e": 99425,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 100945,
      "e": 99512,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "82"
    },
    {
      "t": 100945,
      "e": 99512,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 100986,
      "e": 99553,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||er"
    },
    {
      "t": 101034,
      "e": 99601,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 101073,
      "e": 99640,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "73"
    },
    {
      "t": 101073,
      "e": 99640,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 101161,
      "e": 99728,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||i"
    },
    {
      "t": 101322,
      "e": 99889,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "67"
    },
    {
      "t": 101322,
      "e": 99889,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 101409,
      "e": 99976,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||c"
    },
    {
      "t": 101425,
      "e": 99992,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "65"
    },
    {
      "t": 101425,
      "e": 99992,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 101490,
      "e": 100057,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||a"
    },
    {
      "t": 101609,
      "e": 100176,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "United States of America"
    },
    {
      "t": 102041,
      "e": 100608,
      "ty": 7,
      "x": 947,
      "y": 680,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 102042,
      "e": 100609,
      "ty": 6,
      "x": 947,
      "y": 680,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 102057,
      "e": 100624,
      "ty": 7,
      "x": 1092,
      "y": 753,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 102108,
      "e": 100675,
      "ty": 2,
      "x": 1440,
      "y": 958
    },
    {
      "t": 102208,
      "e": 100775,
      "ty": 2,
      "x": 1444,
      "y": 960
    },
    {
      "t": 102259,
      "e": 100826,
      "ty": 41,
      "x": 49452,
      "y": 52738,
      "ta": "html > body"
    },
    {
      "t": 102308,
      "e": 100875,
      "ty": 2,
      "x": 1422,
      "y": 957
    },
    {
      "t": 102408,
      "e": 100975,
      "ty": 2,
      "x": 1361,
      "y": 888
    },
    {
      "t": 102508,
      "e": 101075,
      "ty": 2,
      "x": 1255,
      "y": 876
    },
    {
      "t": 102508,
      "e": 101075,
      "ty": 41,
      "x": 42943,
      "y": 48084,
      "ta": "html > body"
    },
    {
      "t": 102608,
      "e": 101175,
      "ty": 2,
      "x": 792,
      "y": 686
    },
    {
      "t": 102708,
      "e": 101275,
      "ty": 2,
      "x": 806,
      "y": 650
    },
    {
      "t": 102724,
      "e": 101291,
      "ty": 6,
      "x": 822,
      "y": 650,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 102758,
      "e": 101325,
      "ty": 41,
      "x": 9300,
      "y": 24965,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 102791,
      "e": 101358,
      "ty": 7,
      "x": 927,
      "y": 677,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 102792,
      "e": 101359,
      "ty": 6,
      "x": 927,
      "y": 677,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 102808,
      "e": 101375,
      "ty": 2,
      "x": 980,
      "y": 691
    },
    {
      "t": 102842,
      "e": 101409,
      "ty": 7,
      "x": 1038,
      "y": 718,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 102909,
      "e": 101476,
      "ty": 2,
      "x": 1041,
      "y": 721
    },
    {
      "t": 103009,
      "e": 101576,
      "ty": 2,
      "x": 1008,
      "y": 710
    },
    {
      "t": 103009,
      "e": 101576,
      "ty": 41,
      "x": 34437,
      "y": 38888,
      "ta": "html > body"
    },
    {
      "t": 103026,
      "e": 101593,
      "ty": 6,
      "x": 993,
      "y": 700,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 103108,
      "e": 101675,
      "ty": 2,
      "x": 980,
      "y": 690
    },
    {
      "t": 103208,
      "e": 101775,
      "ty": 2,
      "x": 978,
      "y": 689
    },
    {
      "t": 103259,
      "e": 101826,
      "ty": 41,
      "x": 42302,
      "y": 25816,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 103286,
      "e": 101853,
      "ty": 3,
      "x": 978,
      "y": 689,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 103287,
      "e": 101854,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "United States of America"
    },
    {
      "t": 103288,
      "e": 101855,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 103289,
      "e": 101856,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 103373,
      "e": 101940,
      "ty": 4,
      "x": 42302,
      "y": 25816,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 103374,
      "e": 101941,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 103374,
      "e": 101941,
      "ty": 5,
      "x": 978,
      "y": 689,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 103375,
      "e": 101942,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 104395,
      "e": 102962,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 105008,
      "e": 103575,
      "ty": 2,
      "x": 978,
      "y": 688
    },
    {
      "t": 105008,
      "e": 103575,
      "ty": 41,
      "x": 37159,
      "y": 63194,
      "ta": "#jspsych-survey-multi-choice-option-2-0"
    },
    {
      "t": 105109,
      "e": 103676,
      "ty": 2,
      "x": 1142,
      "y": 488
    },
    {
      "t": 105209,
      "e": 103776,
      "ty": 2,
      "x": 1135,
      "y": 354
    },
    {
      "t": 105258,
      "e": 103825,
      "ty": 41,
      "x": 64452,
      "y": 14043,
      "ta": "#jspsych-survey-multi-choice-option-0-1"
    },
    {
      "t": 105308,
      "e": 103875,
      "ty": 2,
      "x": 1004,
      "y": 257
    },
    {
      "t": 105408,
      "e": 103975,
      "ty": 2,
      "x": 934,
      "y": 285
    },
    {
      "t": 105509,
      "e": 104076,
      "ty": 2,
      "x": 899,
      "y": 283
    },
    {
      "t": 105509,
      "e": 104076,
      "ty": 41,
      "x": 18411,
      "y": 4681,
      "ta": "#jspsych-survey-multi-choice-option-0-2"
    },
    {
      "t": 105609,
      "e": 104176,
      "ty": 2,
      "x": 851,
      "y": 269
    },
    {
      "t": 105708,
      "e": 104275,
      "ty": 2,
      "x": 846,
      "y": 263
    },
    {
      "t": 105760,
      "e": 104277,
      "ty": 41,
      "x": 18719,
      "y": 3276,
      "ta": "#jspsych-survey-multi-choice-option-0-1 > label"
    },
    {
      "t": 105808,
      "e": 104325,
      "ty": 2,
      "x": 846,
      "y": 254
    },
    {
      "t": 105908,
      "e": 104425,
      "ty": 2,
      "x": 845,
      "y": 245
    },
    {
      "t": 105950,
      "e": 104467,
      "ty": 6,
      "x": 839,
      "y": 242,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 106009,
      "e": 104526,
      "ty": 2,
      "x": 836,
      "y": 241
    },
    {
      "t": 106009,
      "e": 104526,
      "ty": 41,
      "x": 48284,
      "y": 45370,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 106109,
      "e": 104626,
      "ty": 2,
      "x": 833,
      "y": 240
    },
    {
      "t": 106182,
      "e": 104699,
      "ty": 3,
      "x": 832,
      "y": 239,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 106183,
      "e": 104700,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 106208,
      "e": 104725,
      "ty": 2,
      "x": 832,
      "y": 239
    },
    {
      "t": 106258,
      "e": 104775,
      "ty": 41,
      "x": 28120,
      "y": 35288,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 106285,
      "e": 104802,
      "ty": 4,
      "x": 28120,
      "y": 35288,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 106285,
      "e": 104802,
      "ty": 5,
      "x": 832,
      "y": 239,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 106286,
      "e": 104803,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf",
      "v": "English"
    },
    {
      "t": 106626,
      "e": 105143,
      "ty": 7,
      "x": 829,
      "y": 247,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 106644,
      "e": 105161,
      "ty": 6,
      "x": 828,
      "y": 264,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 106661,
      "e": 105178,
      "ty": 7,
      "x": 828,
      "y": 279,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 106677,
      "e": 105194,
      "ty": 6,
      "x": 828,
      "y": 295,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 106693,
      "e": 105210,
      "ty": 7,
      "x": 828,
      "y": 322,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 106693,
      "e": 105210,
      "ty": 6,
      "x": 828,
      "y": 322,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 106708,
      "e": 105225,
      "ty": 2,
      "x": 828,
      "y": 322
    },
    {
      "t": 106711,
      "e": 105228,
      "ty": 7,
      "x": 828,
      "y": 339,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 106759,
      "e": 105276,
      "ty": 41,
      "x": 849,
      "y": 7021,
      "ta": "#jspsych-survey-multi-choice-1 > p"
    },
    {
      "t": 106809,
      "e": 105326,
      "ty": 2,
      "x": 825,
      "y": 370
    },
    {
      "t": 106909,
      "e": 105426,
      "ty": 2,
      "x": 824,
      "y": 394
    },
    {
      "t": 106962,
      "e": 105479,
      "ty": 6,
      "x": 827,
      "y": 409,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 107009,
      "e": 105526,
      "ty": 2,
      "x": 829,
      "y": 415
    },
    {
      "t": 107009,
      "e": 105526,
      "ty": 41,
      "x": 12996,
      "y": 35288,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 107062,
      "e": 105579,
      "ty": 7,
      "x": 829,
      "y": 425,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 107109,
      "e": 105626,
      "ty": 2,
      "x": 829,
      "y": 433
    },
    {
      "t": 107110,
      "e": 105627,
      "ty": 6,
      "x": 830,
      "y": 436,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 107209,
      "e": 105726,
      "ty": 2,
      "x": 830,
      "y": 439
    },
    {
      "t": 107259,
      "e": 105776,
      "ty": 41,
      "x": 23079,
      "y": 20164,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 107309,
      "e": 105826,
      "ty": 2,
      "x": 832,
      "y": 440
    },
    {
      "t": 107508,
      "e": 106025,
      "ty": 41,
      "x": 28120,
      "y": 20164,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 107558,
      "e": 106075,
      "ty": 3,
      "x": 832,
      "y": 440,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 107559,
      "e": 106076,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 107560,
      "e": 106077,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 107678,
      "e": 106195,
      "ty": 4,
      "x": 28120,
      "y": 20164,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 107678,
      "e": 106195,
      "ty": 5,
      "x": 832,
      "y": 440,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 107678,
      "e": 106195,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf",
      "v": "Second"
    },
    {
      "t": 107909,
      "e": 106426,
      "ty": 2,
      "x": 832,
      "y": 445
    },
    {
      "t": 107912,
      "e": 106429,
      "ty": 7,
      "x": 832,
      "y": 449,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 107962,
      "e": 106479,
      "ty": 6,
      "x": 832,
      "y": 472,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 107979,
      "e": 106480,
      "ty": 7,
      "x": 833,
      "y": 483,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 107995,
      "e": 106496,
      "ty": 6,
      "x": 837,
      "y": 502,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 108008,
      "e": 106509,
      "ty": 2,
      "x": 837,
      "y": 502
    },
    {
      "t": 108008,
      "e": 106509,
      "ty": 41,
      "x": 53325,
      "y": 50411,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 108012,
      "e": 106513,
      "ty": 7,
      "x": 839,
      "y": 517,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 108108,
      "e": 106609,
      "ty": 2,
      "x": 843,
      "y": 554
    },
    {
      "t": 108209,
      "e": 106710,
      "ty": 2,
      "x": 841,
      "y": 573
    },
    {
      "t": 108212,
      "e": 106713,
      "ty": 6,
      "x": 839,
      "y": 577,
      "ta": "jspsych-survey-multi-choice-response-1[6]_mf"
    },
    {
      "t": 108258,
      "e": 106759,
      "ty": 41,
      "x": 63408,
      "y": 60493,
      "ta": "jspsych-survey-multi-choice-response-1[6]_mf"
    },
    {
      "t": 108261,
      "e": 106762,
      "ty": 7,
      "x": 837,
      "y": 595,
      "ta": "jspsych-survey-multi-choice-response-1[6]_mf"
    },
    {
      "t": 108308,
      "e": 106809,
      "ty": 2,
      "x": 835,
      "y": 606
    },
    {
      "t": 108408,
      "e": 106909,
      "ty": 2,
      "x": 830,
      "y": 628
    },
    {
      "t": 108509,
      "e": 107010,
      "ty": 2,
      "x": 830,
      "y": 645
    },
    {
      "t": 108509,
      "e": 107010,
      "ty": 41,
      "x": 2035,
      "y": 8124,
      "ta": "#jspsych-survey-multi-choice-2"
    },
    {
      "t": 108709,
      "e": 107210,
      "ty": 2,
      "x": 830,
      "y": 652
    },
    {
      "t": 108759,
      "e": 107260,
      "ty": 41,
      "x": 1497,
      "y": 6553,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 108762,
      "e": 107263,
      "ty": 6,
      "x": 827,
      "y": 674,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 108779,
      "e": 107280,
      "ty": 7,
      "x": 824,
      "y": 681,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 108808,
      "e": 107309,
      "ty": 2,
      "x": 824,
      "y": 686
    },
    {
      "t": 108909,
      "e": 107410,
      "ty": 2,
      "x": 824,
      "y": 692
    },
    {
      "t": 109009,
      "e": 107510,
      "ty": 41,
      "x": 611,
      "y": 7021,
      "ta": "#jspsych-survey-multi-choice-option-2-1"
    },
    {
      "t": 109108,
      "e": 107609,
      "ty": 2,
      "x": 824,
      "y": 693
    },
    {
      "t": 109209,
      "e": 107710,
      "ty": 2,
      "x": 824,
      "y": 706
    },
    {
      "t": 109259,
      "e": 107760,
      "ty": 41,
      "x": 611,
      "y": 56172,
      "ta": "#jspsych-survey-multi-choice-option-2-1"
    },
    {
      "t": 109309,
      "e": 107810,
      "ty": 2,
      "x": 824,
      "y": 718
    },
    {
      "t": 109408,
      "e": 107909,
      "ty": 2,
      "x": 824,
      "y": 722
    },
    {
      "t": 109509,
      "e": 108010,
      "ty": 2,
      "x": 823,
      "y": 728
    },
    {
      "t": 109509,
      "e": 108010,
      "ty": 41,
      "x": 396,
      "y": 22937,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 109609,
      "e": 108110,
      "ty": 2,
      "x": 823,
      "y": 730
    },
    {
      "t": 109708,
      "e": 108209,
      "ty": 2,
      "x": 824,
      "y": 733
    },
    {
      "t": 109759,
      "e": 108260,
      "ty": 41,
      "x": 647,
      "y": 42597,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 109808,
      "e": 108309,
      "ty": 2,
      "x": 825,
      "y": 734
    },
    {
      "t": 109823,
      "e": 108324,
      "ty": 6,
      "x": 826,
      "y": 734,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 109908,
      "e": 108409,
      "ty": 2,
      "x": 828,
      "y": 733
    },
    {
      "t": 110009,
      "e": 108510,
      "ty": 2,
      "x": 829,
      "y": 732
    },
    {
      "t": 110009,
      "e": 108510,
      "ty": 41,
      "x": 12996,
      "y": 40329,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 110062,
      "e": 108563,
      "ty": 3,
      "x": 829,
      "y": 732,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 110063,
      "e": 108564,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 110065,
      "e": 108566,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 110109,
      "e": 108610,
      "ty": 2,
      "x": 830,
      "y": 732
    },
    {
      "t": 110165,
      "e": 108666,
      "ty": 4,
      "x": 18037,
      "y": 40329,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 110165,
      "e": 108666,
      "ty": 5,
      "x": 830,
      "y": 732,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 110166,
      "e": 108667,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf",
      "v": "Biomedical & Health Sciences"
    },
    {
      "t": 110259,
      "e": 108760,
      "ty": 41,
      "x": 18037,
      "y": 40329,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 110548,
      "e": 109049,
      "ty": 7,
      "x": 830,
      "y": 744,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 110609,
      "e": 109110,
      "ty": 2,
      "x": 774,
      "y": 870
    },
    {
      "t": 110709,
      "e": 109210,
      "ty": 2,
      "x": 783,
      "y": 937
    },
    {
      "t": 110758,
      "e": 109259,
      "ty": 41,
      "x": 0,
      "y": 16383,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 110764,
      "e": 109260,
      "ty": 6,
      "x": 829,
      "y": 962,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 110808,
      "e": 109304,
      "ty": 2,
      "x": 834,
      "y": 962
    },
    {
      "t": 110909,
      "e": 109405,
      "ty": 2,
      "x": 839,
      "y": 962
    },
    {
      "t": 111009,
      "e": 109505,
      "ty": 41,
      "x": 63408,
      "y": 30246,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 111206,
      "e": 109702,
      "ty": 3,
      "x": 838,
      "y": 962,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 111207,
      "e": 109703,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 111208,
      "e": 109704,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 111210,
      "e": 109706,
      "ty": 2,
      "x": 838,
      "y": 962
    },
    {
      "t": 111259,
      "e": 109755,
      "ty": 41,
      "x": 58367,
      "y": 30246,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 111308,
      "e": 109804,
      "ty": 2,
      "x": 837,
      "y": 962
    },
    {
      "t": 111309,
      "e": 109805,
      "ty": 4,
      "x": 53325,
      "y": 30246,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 111309,
      "e": 109805,
      "ty": 5,
      "x": 837,
      "y": 962,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 111310,
      "e": 109806,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf",
      "v": "Female"
    },
    {
      "t": 111408,
      "e": 109904,
      "ty": 2,
      "x": 835,
      "y": 962
    },
    {
      "t": 111508,
      "e": 110004,
      "ty": 2,
      "x": 832,
      "y": 967
    },
    {
      "t": 111509,
      "e": 110005,
      "ty": 41,
      "x": 28120,
      "y": 55452,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 111531,
      "e": 110027,
      "ty": 7,
      "x": 832,
      "y": 970,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 111609,
      "e": 110105,
      "ty": 2,
      "x": 856,
      "y": 993
    },
    {
      "t": 111649,
      "e": 110145,
      "ty": 6,
      "x": 874,
      "y": 1006,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 111709,
      "e": 110205,
      "ty": 2,
      "x": 881,
      "y": 1010
    },
    {
      "t": 111759,
      "e": 110255,
      "ty": 41,
      "x": 34313,
      "y": 23830,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 111808,
      "e": 110304,
      "ty": 2,
      "x": 896,
      "y": 1030
    },
    {
      "t": 111908,
      "e": 110404,
      "ty": 2,
      "x": 895,
      "y": 1034
    },
    {
      "t": 112008,
      "e": 110504,
      "ty": 2,
      "x": 891,
      "y": 1034
    },
    {
      "t": 112009,
      "e": 110505,
      "ty": 41,
      "x": 31736,
      "y": 57591,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 112109,
      "e": 110605,
      "ty": 2,
      "x": 890,
      "y": 1031
    },
    {
      "t": 112208,
      "e": 110704,
      "ty": 2,
      "x": 890,
      "y": 1024
    },
    {
      "t": 112259,
      "e": 110755,
      "ty": 41,
      "x": 31221,
      "y": 33760,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 112308,
      "e": 110804,
      "ty": 2,
      "x": 890,
      "y": 1022
    },
    {
      "t": 112310,
      "e": 110806,
      "ty": 3,
      "x": 890,
      "y": 1022,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 112311,
      "e": 110807,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 112312,
      "e": 110808,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 112414,
      "e": 110910,
      "ty": 4,
      "x": 31221,
      "y": 33760,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 112414,
      "e": 110910,
      "ty": 5,
      "x": 890,
      "y": 1022,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 112415,
      "e": 110911,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 112417,
      "e": 110913,
      "ty": 13,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 112418,
      "e": 110914,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 113756,
      "e": 112252,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 114509,
      "e": 113005,
      "ty": 2,
      "x": 930,
      "y": 961
    },
    {
      "t": 114510,
      "e": 113006,
      "ty": 41,
      "x": 31316,
      "y": 57800,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 114609,
      "e": 113105,
      "ty": 2,
      "x": 945,
      "y": 940
    },
    {
      "t": 114709,
      "e": 113205,
      "ty": 2,
      "x": 950,
      "y": 927
    },
    {
      "t": 114759,
      "e": 113255,
      "ty": 41,
      "x": 32250,
      "y": 55100,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 114809,
      "e": 113305,
      "ty": 2,
      "x": 948,
      "y": 912
    },
    {
      "t": 114909,
      "e": 113405,
      "ty": 2,
      "x": 945,
      "y": 907
    },
    {
      "t": 115009,
      "e": 113505,
      "ty": 2,
      "x": 943,
      "y": 903
    },
    {
      "t": 115009,
      "e": 113505,
      "ty": 41,
      "x": 31955,
      "y": 53784,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 118908,
      "e": 117404,
      "ty": 2,
      "x": 950,
      "y": 908
    },
    {
      "t": 119008,
      "e": 117504,
      "ty": 2,
      "x": 985,
      "y": 974
    },
    {
      "t": 119010,
      "e": 117506,
      "ty": 41,
      "x": 34022,
      "y": 58701,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 119108,
      "e": 117604,
      "ty": 2,
      "x": 981,
      "y": 1011
    },
    {
      "t": 119208,
      "e": 117704,
      "ty": 2,
      "x": 965,
      "y": 1061
    },
    {
      "t": 119258,
      "e": 117754,
      "ty": 41,
      "x": 33038,
      "y": 65279,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 119267,
      "e": 117763,
      "ty": 6,
      "x": 965,
      "y": 1072,
      "ta": "#start"
    },
    {
      "t": 119308,
      "e": 117804,
      "ty": 2,
      "x": 965,
      "y": 1078
    },
    {
      "t": 119408,
      "e": 117904,
      "ty": 2,
      "x": 974,
      "y": 1100
    },
    {
      "t": 119454,
      "e": 117950,
      "ty": 7,
      "x": 977,
      "y": 1108,
      "ta": "#start"
    },
    {
      "t": 119508,
      "e": 118004,
      "ty": 2,
      "x": 978,
      "y": 1110
    },
    {
      "t": 119509,
      "e": 118005,
      "ty": 41,
      "x": 41427,
      "y": 20670,
      "ta": "> div.masterdiv > div:[3]"
    },
    {
      "t": 119758,
      "e": 118254,
      "ty": 41,
      "x": 41427,
      "y": 19562,
      "ta": "> div.masterdiv > div:[3]"
    },
    {
      "t": 119788,
      "e": 118284,
      "ty": 6,
      "x": 978,
      "y": 1106,
      "ta": "#start"
    },
    {
      "t": 119808,
      "e": 118304,
      "ty": 2,
      "x": 976,
      "y": 1104
    },
    {
      "t": 119908,
      "e": 118404,
      "ty": 2,
      "x": 976,
      "y": 1103
    },
    {
      "t": 120008,
      "e": 118504,
      "ty": 2,
      "x": 976,
      "y": 1098
    },
    {
      "t": 120009,
      "e": 118505,
      "ty": 41,
      "x": 36317,
      "y": 48789,
      "ta": "#start"
    },
    {
      "t": 120009,
      "e": 118505,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 120108,
      "e": 118604,
      "ty": 2,
      "x": 975,
      "y": 1092
    },
    {
      "t": 120258,
      "e": 118754,
      "ty": 41,
      "x": 35771,
      "y": 37224,
      "ta": "#start"
    },
    {
      "t": 120262,
      "e": 118758,
      "ty": 3,
      "x": 975,
      "y": 1092,
      "ta": "#start"
    },
    {
      "t": 120263,
      "e": 118759,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 120308,
      "e": 118804,
      "ty": 2,
      "x": 975,
      "y": 1091
    },
    {
      "t": 120365,
      "e": 118861,
      "ty": 4,
      "x": 35771,
      "y": 35297,
      "ta": "#start"
    },
    {
      "t": 120365,
      "e": 118861,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 120365,
      "e": 118861,
      "ty": 5,
      "x": 975,
      "y": 1091,
      "ta": "#start"
    },
    {
      "t": 120366,
      "e": 118862,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 120508,
      "e": 119004,
      "ty": 41,
      "x": 33301,
      "y": 59995,
      "ta": "html > body"
    },
    {
      "t": 121400,
      "e": 119896,
      "ty": 38,
      "x": 8,
      "y": 0
    },
    {
      "t": 122535,
      "e": 121031,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":56},{\"id\":57},{\"id\":58},{\"id\":59},{\"id\":60},{\"id\":61},{\"id\":62},{\"id\":63},{\"id\":64},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":72},{\"id\":73},{\"id\":74},{\"id\":75},{\"id\":76},{\"id\":77},{\"id\":78},{\"id\":79},{\"id\":80},{\"id\":81},{\"id\":82},{\"id\":83},{\"id\":84},{\"id\":85},{\"id\":86},{\"id\":87},{\"id\":88},{\"id\":89},{\"id\":90},{\"id\":91},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":96},{\"id\":97},{\"id\":98},{\"id\":99},{\"id\":100},{\"id\":101},{\"id\":102},{\"id\":103},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":109},{\"id\":110},{\"id\":111},{\"id\":112},{\"id\":113},{\"id\":114},{\"id\":115},{\"id\":116},{\"id\":117},{\"id\":118},{\"id\":119},{\"id\":120},{\"id\":121},{\"id\":122},{\"id\":123},{\"id\":124},{\"id\":125},{\"id\":126},{\"id\":127},{\"id\":128},{\"id\":129},{\"id\":130},{\"id\":131},{\"id\":132},{\"id\":133},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":141},{\"id\":142},{\"id\":143},{\"id\":144},{\"id\":145},{\"id\":146},{\"id\":147},{\"id\":148},{\"id\":149},{\"id\":150},{\"id\":151},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":155},{\"id\":156},{\"id\":157},{\"id\":158},{\"id\":159},{\"id\":160},{\"id\":161},{\"id\":162},{\"id\":163},{\"id\":164},{\"id\":165},{\"id\":166},{\"id\":167},{\"id\":168},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":172},{\"id\":173},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":178},{\"id\":179},{\"id\":180},{\"id\":181},{\"id\":182},{\"id\":183},{\"id\":184},{\"id\":185},{\"id\":186},{\"id\":187},{\"id\":188},{\"id\":189},{\"id\":190},{\"id\":191},{\"id\":192},{\"id\":193},{\"id\":194},{\"id\":195},{\"id\":196},{\"id\":197},{\"id\":198},{\"id\":199},{\"id\":200},{\"id\":201},{\"id\":202},{\"id\":203},{\"id\":204},{\"id\":205},{\"id\":206},{\"id\":207},{\"id\":208},{\"id\":209},{\"id\":210},{\"id\":211},{\"id\":212},{\"id\":213},{\"id\":214},{\"id\":215},{\"id\":216},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":220},{\"id\":221},{\"id\":222},{\"id\":223},{\"id\":224},{\"id\":225},{\"id\":226},{\"id\":227},{\"id\":228},{\"id\":229},{\"id\":230},{\"id\":231},{\"id\":232},{\"id\":233},{\"id\":234},{\"id\":235},{\"id\":236},{\"id\":237},{\"id\":238},{\"id\":239},{\"id\":240},{\"id\":241},{\"id\":242},{\"id\":243},{\"id\":244},{\"id\":245},{\"id\":246},{\"id\":247},{\"id\":248},{\"id\":249},{\"id\":250},{\"id\":251},{\"id\":252},{\"id\":253},{\"id\":254},{\"id\":255},{\"id\":256},{\"id\":257},{\"id\":258},{\"id\":259},{\"id\":260},{\"id\":261},{\"id\":262},{\"id\":263},{\"id\":264},{\"id\":265},{\"id\":266},{\"id\":267},{\"id\":268},{\"id\":269},{\"id\":270},{\"id\":271},{\"id\":272},{\"id\":273},{\"id\":274},{\"id\":275},{\"id\":276},{\"id\":277},{\"id\":278},{\"id\":279},{\"id\":280},{\"id\":281},{\"id\":282},{\"id\":283},{\"id\":284},{\"id\":285},{\"id\":286},{\"id\":287},{\"id\":288},{\"id\":289},{\"id\":290},{\"id\":291},{\"id\":292},{\"id\":293},{\"id\":294},{\"id\":295},{\"id\":296},{\"id\":297},{\"id\":298},{\"id\":299},{\"id\":300},{\"id\":301},{\"id\":302},{\"id\":303},{\"id\":304},{\"id\":305},{\"id\":306},{\"id\":307},{\"id\":308},{\"id\":309},{\"id\":310},{\"id\":311},{\"id\":312},{\"id\":313},{\"id\":314},{\"id\":315},{\"id\":316},{\"id\":317},{\"id\":318},{\"id\":319},{\"id\":320},{\"id\":321},{\"id\":322},{\"id\":323},{\"id\":324},{\"id\":325},{\"id\":326},{\"id\":327},{\"id\":328},{\"id\":329},{\"id\":330},{\"id\":331},{\"id\":332},{\"id\":333},{\"id\":334},{\"id\":335},{\"id\":336},{\"id\":337},{\"id\":338},{\"id\":339},{\"id\":340},{\"id\":341},{\"id\":342},{\"id\":343},{\"id\":344},{\"id\":345},{\"id\":346},{\"id\":347},{\"id\":348},{\"id\":349},{\"id\":350},{\"id\":351},{\"id\":352},{\"id\":353},{\"id\":354},{\"id\":355},{\"id\":356},{\"id\":357},{\"id\":358},{\"id\":359},{\"id\":360},{\"id\":361},{\"id\":362},{\"id\":363},{\"id\":364},{\"id\":365},{\"id\":366},{\"id\":367},{\"id\":368},{\"id\":369},{\"id\":370},{\"id\":371},{\"id\":372},{\"id\":373},{\"id\":374},{\"id\":375},{\"id\":376},{\"id\":377},{\"id\":378},{\"id\":379},{\"id\":380},{\"id\":381},{\"id\":382},{\"id\":383},{\"id\":384},{\"id\":385},{\"id\":386},{\"id\":387},{\"id\":388},{\"id\":389},{\"id\":390},{\"id\":391},{\"id\":392},{\"id\":393},{\"id\":394},{\"id\":395},{\"id\":396},{\"id\":397},{\"id\":398},{\"id\":399},{\"id\":400},{\"id\":401},{\"id\":402},{\"id\":403},{\"id\":404},{\"id\":405},{\"id\":406},{\"id\":407},{\"id\":408},{\"id\":409},{\"id\":410},{\"id\":411},{\"id\":412},{\"id\":413},{\"id\":414},{\"id\":415},{\"id\":416},{\"id\":417},{\"id\":418},{\"id\":419},{\"id\":420},{\"id\":421},{\"id\":422},{\"id\":423},{\"id\":424},{\"id\":425},{\"id\":426},{\"id\":427},{\"id\":428},{\"id\":429},{\"id\":430},{\"id\":431},{\"id\":432},{\"id\":433},{\"id\":434},{\"id\":435},{\"id\":436},{\"id\":437},{\"id\":438},{\"id\":439},{\"id\":440},{\"id\":441},{\"id\":442},{\"id\":443},{\"id\":444},{\"id\":445},{\"id\":446},{\"id\":447},{\"id\":448},{\"id\":449},{\"id\":450},{\"id\":451},{\"id\":452},{\"id\":453},{\"id\":454},{\"id\":455},{\"id\":456},{\"id\":457},{\"id\":458},{\"id\":459},{\"id\":460},{\"id\":461},{\"id\":462},{\"id\":463},{\"id\":464},{\"id\":465},{\"id\":466},{\"id\":467},{\"id\":468},{\"id\":469},{\"id\":470},{\"id\":471},{\"id\":472},{\"id\":473},{\"id\":474},{\"id\":475},{\"id\":476},{\"id\":477},{\"id\":478},{\"id\":479},{\"id\":480},{\"id\":481},{\"id\":482},{\"id\":483},{\"id\":484},{\"id\":485},{\"id\":486},{\"id\":487},{\"id\":488},{\"id\":489},{\"id\":490},{\"id\":491},{\"id\":492},{\"id\":493},{\"id\":494},{\"id\":495},{\"id\":496},{\"id\":497},{\"id\":498},{\"id\":499},{\"id\":500},{\"id\":501},{\"id\":502},{\"id\":503},{\"id\":504},{\"id\":505},{\"id\":506},{\"id\":507},{\"id\":508},{\"id\":509},{\"id\":510},{\"id\":511},{\"id\":512},{\"id\":513},{\"id\":514},{\"id\":515},{\"id\":516},{\"id\":517},{\"id\":518},{\"id\":519},{\"id\":520},{\"id\":521},{\"id\":522},{\"id\":523},{\"id\":524},{\"id\":525},{\"id\":526},{\"id\":527},{\"id\":528},{\"id\":529},{\"id\":530},{\"id\":531},{\"id\":532},{\"id\":533},{\"id\":534},{\"id\":535},{\"id\":536},{\"id\":537},{\"id\":538},{\"id\":539},{\"id\":540},{\"id\":541},{\"id\":542},{\"id\":543},{\"id\":544},{\"id\":545},{\"id\":546},{\"id\":547},{\"id\":548},{\"id\":549},{\"id\":550},{\"id\":551},{\"id\":552},{\"id\":553},{\"id\":554},{\"id\":555},{\"id\":556},{\"id\":557},{\"id\":558},{\"id\":559},{\"id\":560},{\"id\":561},{\"id\":562},{\"id\":563},{\"id\":564},{\"id\":565},{\"id\":566},{\"id\":567},{\"id\":568},{\"id\":569},{\"id\":570},{\"id\":571},{\"id\":572},{\"id\":573},{\"id\":574},{\"id\":575},{\"id\":576},{\"id\":577},{\"id\":578},{\"id\":579},{\"id\":580},{\"id\":581},{\"id\":582},{\"id\":583},{\"id\":584},{\"id\":585},{\"id\":586},{\"id\":587},{\"id\":588},{\"id\":589},{\"id\":590},{\"id\":591},{\"id\":592},{\"id\":593},{\"id\":594},{\"id\":595},{\"id\":596},{\"id\":597},{\"id\":598},{\"id\":599},{\"id\":600},{\"id\":601},{\"id\":602},{\"id\":603},{\"id\":604},{\"id\":605},{\"id\":606},{\"id\":607},{\"id\":608},{\"id\":609},{\"id\":610},{\"id\":611},{\"id\":612},{\"id\":613},{\"id\":614},{\"id\":615},{\"id\":616},{\"id\":617},{\"id\":618},{\"id\":619},{\"id\":620},{\"id\":621},{\"id\":622},{\"id\":623},{\"id\":624},{\"id\":625},{\"id\":626},{\"id\":627},{\"id\":628},{\"id\":629},{\"id\":630},{\"id\":631},{\"id\":632},{\"id\":633},{\"id\":634},{\"id\":635},{\"id\":636},{\"id\":637},{\"id\":638},{\"id\":639},{\"id\":640},{\"id\":641},{\"id\":642},{\"id\":643},{\"id\":644},{\"id\":645},{\"id\":646},{\"id\":647},{\"id\":648},{\"id\":649},{\"id\":650},{\"id\":651},{\"id\":652},{\"id\":653},{\"id\":654},{\"id\":655},{\"id\":656},{\"id\":657},{\"id\":658},{\"id\":659},{\"id\":660},{\"id\":661},{\"id\":662},{\"id\":663},{\"id\":664},{\"id\":665},{\"id\":666},{\"id\":667},{\"id\":668},{\"id\":669},{\"id\":670},{\"id\":671},{\"id\":672},{\"id\":673},{\"id\":674},{\"id\":675},{\"id\":676},{\"id\":677},{\"id\":678},{\"id\":679},{\"id\":680},{\"id\":681},{\"id\":682},{\"id\":683},{\"id\":684},{\"id\":685},{\"id\":686},{\"id\":687},{\"id\":688},{\"id\":689},{\"id\":690},{\"id\":691},{\"id\":692},{\"id\":693},{\"id\":694},{\"id\":695},{\"id\":696},{\"id\":697},{\"id\":698},{\"id\":699},{\"id\":700},{\"id\":701},{\"id\":702},{\"id\":703},{\"id\":704},{\"id\":705},{\"id\":706},{\"id\":707},{\"id\":708},{\"id\":709},{\"id\":710},{\"id\":711},{\"id\":712},{\"id\":713},{\"id\":714},{\"id\":715},{\"id\":716},{\"id\":717},{\"id\":718},{\"id\":719},{\"id\":720},{\"id\":721},{\"id\":722},{\"id\":723},{\"id\":724},{\"id\":725},{\"id\":726},{\"id\":727},{\"id\":728},{\"id\":729},{\"id\":730},{\"id\":731},{\"id\":732},{\"id\":733},{\"id\":734},{\"id\":735},{\"id\":736},{\"id\":737},{\"id\":738},{\"id\":739},{\"id\":740},{\"id\":741},{\"id\":742},{\"id\":743},{\"id\":744},{\"id\":745},{\"id\":746},{\"id\":747},{\"id\":748},{\"id\":749},{\"id\":750},{\"id\":751},{\"id\":752},{\"id\":753},{\"id\":754},{\"id\":755},{\"id\":756},{\"id\":757},{\"id\":758},{\"id\":759},{\"id\":760},{\"id\":761},{\"id\":762},{\"id\":763},{\"id\":764},{\"id\":765},{\"id\":766},{\"id\":767},{\"id\":768},{\"id\":769},{\"id\":770},{\"id\":771},{\"id\":772},{\"id\":773},{\"id\":774},{\"id\":775},{\"id\":776},{\"id\":777},{\"id\":778},{\"id\":779},{\"id\":780},{\"id\":781},{\"id\":782},{\"id\":783},{\"id\":784},{\"id\":785},{\"id\":786},{\"id\":787},{\"id\":788},{\"id\":789},{\"id\":790},{\"id\":791},{\"id\":792},{\"id\":793},{\"id\":794},{\"id\":795},{\"id\":796},{\"id\":797},{\"id\":798},{\"id\":799},{\"id\":800},{\"id\":801},{\"id\":802},{\"id\":803},{\"id\":804},{\"id\":805},{\"id\":806},{\"id\":807},{\"id\":808},{\"id\":809},{\"id\":810},{\"id\":811},{\"id\":812},{\"id\":813},{\"id\":814},{\"id\":815},{\"id\":816},{\"id\":817},{\"id\":818},{\"id\":819},{\"id\":820},{\"id\":821},{\"id\":822},{\"id\":823},{\"id\":824},{\"id\":825},{\"id\":826},{\"id\":827},{\"id\":828},{\"id\":829},{\"id\":830},{\"id\":831},{\"id\":832},{\"id\":833},{\"id\":834},{\"id\":835},{\"id\":836},{\"id\":837},{\"id\":838},{\"id\":839},{\"id\":840},{\"id\":841},{\"id\":842},{\"id\":843},{\"id\":844},{\"id\":845},{\"id\":846},{\"id\":847},{\"id\":848},{\"id\":849},{\"id\":850},{\"id\":851},{\"id\":852},{\"id\":853},{\"id\":854},{\"id\":855},{\"id\":856},{\"id\":857},{\"id\":858},{\"id\":859},{\"id\":860},{\"id\":861},{\"id\":862},{\"id\":863},{\"id\":864},{\"id\":865},{\"id\":866},{\"id\":867},{\"id\":868},{\"id\":869},{\"id\":870},{\"id\":871},{\"id\":872},{\"id\":873},{\"id\":874},{\"id\":875},{\"id\":876},{\"id\":877},{\"id\":878},{\"id\":879},{\"id\":880},{\"id\":881},{\"id\":882},{\"id\":883},{\"id\":884},{\"id\":885},{\"id\":886},{\"id\":887},{\"id\":888},{\"id\":889},{\"id\":890},{\"id\":891},{\"id\":892},{\"id\":893},{\"id\":894},{\"id\":895},{\"id\":896},{\"id\":897},{\"id\":898},{\"id\":899},{\"id\":900},{\"id\":901},{\"id\":902},{\"id\":903},{\"id\":904},{\"id\":905},{\"id\":906},{\"id\":907},{\"id\":908},{\"id\":909},{\"id\":910},{\"id\":911},{\"id\":912},{\"id\":913},{\"id\":914},{\"id\":915},{\"id\":916},{\"id\":917},{\"id\":918},{\"id\":919},{\"id\":920},{\"id\":921},{\"id\":922},{\"id\":923},{\"id\":924},{\"id\":925},{\"id\":926},{\"id\":927},{\"id\":928},{\"id\":929},{\"id\":930},{\"id\":931},{\"id\":932},{\"id\":933},{\"id\":934},{\"id\":935},{\"id\":936},{\"id\":937},{\"id\":938},{\"id\":939},{\"id\":940},{\"id\":941},{\"id\":942},{\"id\":943},{\"id\":944},{\"id\":945},{\"id\":946},{\"id\":947},{\"id\":948},{\"id\":949},{\"id\":950},{\"id\":951},{\"id\":952},{\"id\":953},{\"id\":954},{\"id\":955},{\"id\":956},{\"id\":957},{\"id\":958},{\"id\":959},{\"id\":960},{\"id\":961},{\"id\":962},{\"id\":963},{\"id\":964},{\"id\":965},{\"id\":966},{\"id\":967},{\"id\":968},{\"id\":969},{\"id\":970},{\"id\":971},{\"id\":972},{\"id\":973},{\"id\":974},{\"id\":975},{\"id\":976},{\"id\":977},{\"id\":978},{\"id\":979},{\"id\":980},{\"id\":981},{\"id\":982},{\"id\":983},{\"id\":984},{\"id\":985},{\"id\":986},{\"id\":987},{\"id\":988},{\"id\":989},{\"id\":990},{\"id\":991},{\"id\":992},{\"id\":993},{\"id\":994},{\"id\":995},{\"id\":996},{\"id\":997},{\"id\":998},{\"id\":999},{\"id\":1000},{\"id\":1001},{\"id\":1002},{\"id\":1003},{\"id\":1004},{\"id\":1005},{\"id\":1006},{\"id\":1007},{\"id\":1008},{\"id\":1009},{\"id\":1010},{\"id\":1011},{\"id\":1012},{\"id\":1013},{\"id\":1014},{\"id\":1015},{\"id\":1016},{\"id\":1017},{\"id\":1018},{\"id\":1019},{\"id\":1020},{\"id\":1021},{\"id\":1022},{\"id\":1023},{\"id\":1024},{\"id\":1025},{\"id\":1026},{\"id\":1027},{\"id\":1028},{\"id\":1029},{\"id\":1030},{\"id\":1031},{\"id\":1032},{\"id\":1033},{\"id\":1034},{\"id\":1035},{\"id\":1036},{\"id\":1037},{\"id\":1038},{\"id\":1039},{\"id\":1040},{\"id\":1041},{\"id\":1042},{\"id\":1043},{\"id\":1044},{\"id\":1045},{\"id\":1046},{\"id\":1047},{\"id\":1048},{\"id\":1049},{\"id\":1050},{\"id\":1051},{\"id\":1052},{\"id\":1053},{\"id\":1054},{\"id\":1055},{\"id\":1056},{\"id\":1057},{\"id\":1058},{\"id\":1059},{\"id\":1060},{\"id\":1061},{\"id\":1062},{\"id\":1063},{\"id\":1064},{\"id\":1065},{\"id\":1066},{\"id\":1067},{\"id\":1068},{\"id\":1069},{\"id\":1070},{\"id\":1071},{\"id\":1072},{\"id\":1073},{\"id\":1074},{\"id\":1075},{\"id\":1076},{\"id\":1077},{\"id\":1078},{\"id\":1079},{\"id\":1080},{\"id\":1081},{\"id\":1082},{\"id\":1083},{\"id\":1084},{\"id\":1085},{\"id\":1086},{\"id\":1087},{\"id\":1088},{\"id\":1089},{\"id\":1090},{\"id\":1091},{\"id\":1092},{\"id\":1093},{\"id\":1094},{\"id\":1095},{\"id\":1096},{\"id\":1097},{\"id\":1098},{\"id\":1099},{\"id\":1100},{\"id\":1101},{\"id\":1102},{\"id\":1103},{\"id\":1104},{\"id\":1105},{\"id\":1106},{\"id\":1107},{\"id\":1108},{\"id\":1109},{\"id\":1110},{\"id\":1111},{\"id\":1112},{\"id\":1113},{\"id\":1114},{\"id\":1115},{\"id\":1116},{\"id\":1117},{\"id\":1118},{\"id\":1119},{\"id\":1120},{\"id\":1121},{\"id\":1122},{\"id\":1123},{\"id\":1124},{\"id\":1125},{\"id\":1126},{\"id\":1127},{\"id\":1128},{\"id\":1129},{\"id\":1130},{\"id\":1131},{\"id\":1132},{\"id\":1133},{\"id\":1134},{\"id\":1135},{\"id\":1136},{\"id\":1137},{\"id\":1138},{\"id\":1139},{\"id\":1140},{\"id\":1141},{\"id\":1142},{\"id\":1143},{\"id\":1144},{\"id\":1145},{\"id\":1146},{\"id\":1147},{\"id\":1148},{\"id\":1149},{\"id\":1150},{\"id\":1151},{\"id\":1152},{\"id\":1153},{\"id\":1154},{\"id\":1155},{\"id\":1156},{\"id\":1157},{\"id\":1158},{\"id\":1159},{\"id\":1160},{\"id\":1161},{\"id\":1162},{\"id\":1163},{\"id\":1164},{\"id\":1165},{\"id\":1166},{\"id\":1167},{\"id\":1168},{\"id\":1169},{\"id\":1170},{\"id\":1171},{\"id\":1172},{\"id\":1173},{\"id\":1174},{\"id\":1175},{\"id\":1176},{\"id\":1177},{\"id\":1178},{\"id\":1179},{\"id\":1180},{\"id\":1181},{\"id\":1182},{\"id\":1183},{\"id\":1184},{\"id\":1185},{\"id\":1186},{\"id\":1187},{\"id\":1188},{\"id\":1189},{\"id\":1190},{\"id\":1191},{\"id\":1192},{\"id\":1193},{\"id\":1194},{\"id\":1195},{\"id\":1196},{\"id\":1197},{\"id\":1198},{\"id\":1199},{\"id\":1200},{\"id\":1201},{\"id\":1202},{\"id\":1203},{\"id\":1204},{\"id\":1205},{\"id\":1206},{\"id\":1207},{\"id\":1208},{\"id\":1209},{\"id\":1210},{\"id\":1211},{\"id\":1212},{\"id\":1213},{\"id\":1214},{\"id\":1215},{\"id\":1216},{\"id\":1217},{\"id\":1218},{\"id\":1219},{\"id\":1220},{\"id\":1221},{\"id\":1222},{\"id\":1223},{\"id\":1224},{\"id\":1225},{\"id\":1226},{\"id\":1227},{\"id\":1228},{\"id\":1229},{\"id\":1230},{\"id\":1231},{\"id\":1232},{\"id\":1233},{\"id\":1234},{\"id\":1235},{\"id\":1236},{\"id\":1237},{\"id\":1238},{\"id\":1239},{\"id\":1240},{\"id\":1241},{\"id\":1242},{\"id\":1243},{\"id\":1244},{\"id\":1245},{\"id\":1246},{\"id\":1247},{\"id\":1248},{\"id\":1249},{\"id\":1250},{\"id\":1251},{\"id\":1252},{\"id\":1253},{\"id\":1254},{\"id\":1255},{\"id\":1256},{\"id\":1257},{\"id\":1258},{\"id\":1259},{\"id\":1260},{\"id\":1261},{\"id\":1262},{\"id\":1263},{\"id\":1264},{\"id\":1265},{\"id\":1266},{\"id\":1267},{\"id\":1268},{\"id\":1269},{\"id\":1270},{\"id\":1271},{\"id\":1272},{\"id\":1273},{\"id\":1274},{\"id\":1275},{\"id\":1276},{\"id\":1277},{\"id\":1278},{\"id\":1279},{\"id\":1280},{\"id\":1281},{\"id\":1282},{\"id\":1283},{\"id\":1284},{\"id\":1285},{\"id\":1286},{\"id\":1287},{\"id\":1288},{\"id\":1289},{\"id\":1290},{\"id\":1291},{\"id\":1292},{\"id\":1293},{\"id\":1294},{\"id\":1295},{\"id\":1296},{\"id\":1297},{\"id\":1298},{\"id\":1299},{\"id\":1300},{\"id\":1301},{\"id\":1302},{\"id\":1303},{\"id\":1304},{\"id\":1305},{\"id\":1306},{\"id\":1307},{\"id\":1308},{\"id\":1309},{\"id\":1310},{\"id\":1311},{\"id\":1312},{\"id\":1313},{\"id\":1314},{\"id\":1315},{\"id\":1316},{\"id\":1317},{\"id\":1318},{\"id\":1319},{\"id\":1320},{\"id\":1321},{\"id\":1322},{\"id\":1323},{\"id\":1324},{\"id\":1325},{\"id\":1326},{\"id\":1327},{\"id\":1328},{\"id\":1329},{\"id\":1330},{\"id\":1331},{\"id\":1332},{\"id\":1333},{\"id\":1334},{\"id\":1335},{\"id\":1336},{\"id\":1337},{\"id\":1338},{\"id\":1339},{\"id\":1340},{\"id\":1341},{\"id\":1342},{\"id\":1343},{\"id\":1344},{\"id\":1345},{\"id\":1346},{\"id\":1347},{\"id\":1348},{\"id\":1349},{\"id\":1350},{\"id\":1351},{\"id\":1352},{\"id\":1353},{\"id\":1354},{\"id\":1355},{\"id\":1356},{\"id\":1357},{\"id\":1358},{\"id\":1359},{\"id\":1360},{\"id\":1361},{\"id\":1362},{\"id\":1363},{\"id\":1364},{\"id\":1365},{\"id\":1366},{\"id\":1367},{\"id\":1368},{\"id\":1369},{\"id\":1370},{\"id\":1371},{\"id\":1372},{\"id\":1373},{\"id\":1374},{\"id\":1375},{\"id\":1376},{\"id\":1377},{\"id\":1378},{\"id\":1379},{\"id\":1380},{\"id\":1381},{\"id\":1382},{\"id\":1383},{\"id\":1384},{\"id\":1385},{\"id\":1386},{\"id\":1387},{\"id\":1388},{\"id\":1389},{\"id\":1390},{\"id\":1391},{\"id\":1392},{\"id\":1393},{\"id\":1394},{\"id\":1395},{\"id\":1396},{\"id\":1397},{\"id\":1398},{\"id\":1399},{\"id\":1400},{\"id\":1401},{\"id\":1402},{\"id\":1403},{\"id\":1404},{\"id\":1405},{\"id\":1406},{\"id\":1407},{\"id\":1408},{\"id\":1409},{\"id\":1410},{\"id\":1411},{\"id\":1412},{\"id\":1413},{\"id\":1414},{\"id\":1415},{\"id\":1416},{\"id\":1417},{\"id\":1418},{\"id\":1419},{\"id\":1420},{\"id\":1421},{\"id\":1422},{\"id\":1423},{\"id\":1424},{\"id\":1425},{\"id\":1426},{\"id\":1427},{\"id\":1428},{\"id\":1429},{\"id\":1430},{\"id\":1431},{\"id\":1432},{\"id\":1433},{\"id\":1434},{\"id\":1435},{\"id\":1436},{\"id\":1437},{\"id\":1438},{\"id\":1439},{\"id\":1440},{\"id\":1441},{\"id\":1442},{\"id\":1443},{\"id\":1444},{\"id\":1445},{\"id\":1446},{\"id\":1447},{\"id\":1448},{\"id\":1449},{\"id\":1450},{\"id\":1451},{\"id\":1452},{\"id\":1453},{\"id\":1454},{\"id\":1455},{\"id\":1456},{\"id\":1457},{\"id\":1458},{\"id\":1459},{\"id\":1460},{\"id\":1461},{\"id\":1462},{\"id\":1463},{\"id\":1464},{\"id\":1465},{\"id\":1466},{\"id\":1467},{\"id\":1468},{\"id\":1469},{\"id\":1470},{\"id\":1471},{\"id\":1472},{\"id\":1473},{\"id\":1474},{\"id\":1475},{\"id\":1476},{\"id\":1477},{\"id\":1478},{\"id\":1479},{\"id\":1480},{\"id\":1481},{\"id\":1482},{\"id\":1483},{\"id\":1484},{\"id\":1485},{\"id\":1486},{\"id\":1487},{\"id\":1488},{\"id\":1489},{\"id\":1490},{\"id\":1491},{\"id\":1492},{\"id\":1493},{\"id\":1494},{\"id\":1495},{\"id\":1496},{\"id\":1497},{\"id\":1498},{\"id\":1499},{\"id\":1500},{\"id\":1501},{\"id\":1502},{\"id\":1503},{\"id\":1504},{\"id\":1505},{\"id\":1506},{\"id\":1507},{\"id\":1508},{\"id\":1509},{\"id\":1510},{\"id\":1511},{\"id\":1512},{\"id\":1513},{\"id\":1514},{\"id\":1515},{\"id\":1516},{\"id\":1517},{\"id\":1518},{\"id\":1519},{\"id\":1520},{\"id\":1521},{\"id\":1522},{\"id\":1523},{\"id\":1524},{\"id\":1525},{\"id\":1526},{\"id\":1527},{\"id\":1528},{\"id\":1529},{\"id\":1530},{\"id\":1531},{\"id\":1532},{\"id\":1533},{\"id\":1534},{\"id\":1535},{\"id\":1536},{\"id\":1537},{\"id\":1538},{\"id\":1539},{\"id\":1540},{\"id\":1541},{\"id\":1542},{\"id\":1543},{\"id\":1544},{\"id\":1545},{\"id\":1546},{\"id\":1547},{\"id\":1548},{\"id\":1549},{\"id\":1550},{\"id\":1551},{\"id\":1552},{\"id\":1553},{\"id\":1554},{\"id\":1555},{\"id\":1556},{\"id\":1557},{\"id\":1558},{\"id\":1559},{\"id\":1560},{\"id\":1561},{\"id\":1562},{\"id\":1563},{\"id\":1564},{\"id\":1565},{\"id\":1566},{\"id\":1567},{\"id\":1568},{\"id\":1569},{\"id\":1570},{\"id\":1571},{\"id\":1572},{\"id\":1573},{\"id\":1574},{\"id\":1575},{\"id\":1576},{\"id\":1577},{\"id\":1578},{\"id\":1579},{\"id\":1580},{\"id\":1581},{\"id\":1582},{\"id\":1583},{\"id\":1584},{\"id\":1585},{\"id\":1586},{\"id\":1587},{\"id\":1588},{\"id\":1589},{\"id\":1590},{\"id\":1591},{\"id\":1592},{\"id\":1593},{\"id\":1594},{\"id\":1595},{\"id\":1596},{\"id\":1597},{\"id\":1598},{\"id\":1599},{\"id\":1600},{\"id\":1601},{\"id\":1602},{\"id\":1603},{\"id\":1604},{\"id\":1605},{\"id\":1606},{\"id\":1607},{\"id\":1608},{\"id\":1609},{\"id\":1610},{\"id\":1611},{\"id\":1612},{\"id\":1613},{\"id\":1614},{\"id\":1615},{\"id\":1616},{\"id\":1617},{\"id\":1618},{\"id\":1619},{\"id\":1620},{\"id\":1621},{\"id\":1622},{\"id\":1623},{\"id\":1624},{\"id\":1625},{\"id\":1626},{\"id\":1627},{\"id\":1628},{\"id\":1629},{\"id\":1630},{\"id\":1631},{\"id\":1632},{\"id\":1633},{\"id\":1634},{\"id\":1635},{\"id\":1636},{\"id\":1637},{\"id\":1638},{\"id\":1639},{\"id\":1640},{\"id\":1641},{\"id\":1642},{\"id\":1643},{\"id\":1644},{\"id\":1645},{\"id\":1646},{\"id\":1647},{\"id\":1648},{\"id\":1649},{\"id\":1650},{\"id\":1651},{\"id\":1652},{\"id\":1653},{\"id\":1654},{\"id\":1655},{\"id\":1656},{\"id\":1657},{\"id\":1658},{\"id\":1659},{\"id\":1660},{\"id\":1661},{\"id\":1662},{\"id\":1663},{\"id\":1664},{\"id\":1665},{\"id\":1666},{\"id\":1667},{\"id\":1668},{\"id\":1669},{\"id\":1670},{\"id\":1671},{\"id\":1672},{\"id\":1673},{\"id\":1674},{\"id\":1675},{\"id\":1676},{\"id\":1677},{\"id\":1678},{\"id\":1679},{\"id\":1680},{\"id\":1681},{\"id\":1682},{\"id\":1683},{\"id\":1684},{\"id\":1685},{\"id\":1686},{\"id\":1687},{\"id\":1688},{\"id\":1689},{\"id\":1690},{\"id\":1691},{\"id\":1692},{\"id\":1693},{\"id\":1694},{\"id\":1695},{\"id\":1696},{\"id\":1697},{\"id\":1698},{\"id\":1699},{\"id\":1700},{\"id\":1701},{\"id\":1702},{\"id\":1703},{\"id\":1704},{\"id\":1705},{\"id\":1706},{\"id\":1707},{\"id\":1708},{\"id\":1709},{\"id\":1710},{\"id\":1711},{\"id\":1712},{\"id\":1713},{\"id\":1714},{\"id\":1715},{\"id\":1716},{\"id\":1717},{\"id\":1718},{\"id\":1719},{\"id\":1720},{\"id\":1721},{\"id\":1722},{\"id\":1723},{\"id\":1724},{\"id\":1725},{\"id\":1726},{\"id\":1727},{\"id\":1728},{\"id\":1729},{\"id\":1730},{\"id\":1731},{\"id\":1732},{\"id\":1733},{\"id\":1734},{\"id\":1735},{\"id\":1736},{\"id\":1737},{\"id\":1738},{\"id\":1739},{\"id\":1740},{\"id\":1741},{\"id\":1742},{\"id\":1743},{\"id\":1744},{\"id\":1745},{\"id\":1746},{\"id\":1747},{\"id\":1748},{\"id\":1749},{\"id\":1750},{\"id\":1751},{\"id\":1752},{\"id\":1753},{\"id\":1754},{\"id\":1755},{\"id\":1756},{\"id\":1757},{\"id\":1758},{\"id\":1759},{\"id\":1760},{\"id\":1761},{\"id\":1762},{\"id\":1763},{\"id\":1764},{\"id\":1765},{\"id\":1766},{\"id\":1767},{\"id\":1768},{\"id\":1769},{\"id\":1770},{\"id\":1771},{\"id\":1772},{\"id\":1773},{\"id\":1774},{\"id\":1775},{\"id\":1776},{\"id\":1777},{\"id\":1778},{\"id\":1779},{\"id\":1780},{\"id\":1781},{\"id\":1782},{\"id\":1783},{\"id\":1784},{\"id\":1785},{\"id\":1786},{\"id\":1787},{\"id\":1788},{\"id\":1789},{\"id\":1790},{\"id\":1791},{\"id\":1792},{\"id\":1793},{\"id\":1794},{\"id\":1795},{\"id\":1796},{\"id\":1797},{\"id\":1798},{\"id\":1799},{\"id\":1800},{\"id\":1801},{\"id\":1802},{\"id\":1803},{\"id\":1804},{\"id\":1805},{\"id\":1806},{\"id\":1807},{\"id\":1808},{\"id\":1809},{\"id\":1810},{\"id\":1811},{\"id\":1812},{\"id\":1813},{\"id\":1814},{\"id\":1815},{\"id\":1816},{\"id\":1817},{\"id\":1818},{\"id\":1819},{\"id\":1820},{\"id\":1821},{\"id\":1822},{\"id\":1823},{\"id\":1824},{\"id\":1825},{\"id\":1826},{\"id\":1827},{\"id\":1828},{\"id\":1829},{\"id\":1830},{\"id\":1831},{\"id\":1832},{\"id\":1833},{\"id\":1834},{\"id\":1835},{\"id\":1836},{\"id\":1837},{\"id\":1838},{\"id\":1839},{\"id\":1840},{\"id\":1841},{\"id\":1842},{\"id\":1843},{\"id\":1844},{\"id\":1845},{\"id\":1846},{\"id\":1847},{\"id\":1848},{\"id\":1849},{\"id\":1850},{\"id\":1851},{\"id\":1852},{\"id\":1853},{\"id\":1854},{\"id\":1855},{\"id\":1856},{\"id\":1857},{\"id\":1858},{\"id\":1859},{\"id\":1860},{\"id\":1861},{\"id\":1862},{\"id\":1863},{\"id\":1864},{\"id\":1865},{\"id\":1866},{\"id\":1867},{\"id\":1868},{\"id\":1869},{\"id\":1870},{\"id\":1871},{\"id\":1872},{\"id\":1873},{\"id\":1874},{\"id\":1875},{\"id\":1876},{\"id\":1877},{\"id\":1878},{\"id\":1879},{\"id\":1880},{\"id\":1881},{\"id\":1882},{\"id\":1883},{\"id\":1884},{\"id\":1885},{\"id\":1886},{\"id\":1887},{\"id\":1888},{\"id\":1889},{\"id\":1890},{\"id\":1891},{\"id\":1892},{\"id\":1893},{\"id\":1894},{\"id\":1895},{\"id\":1896},{\"id\":1897},{\"id\":1898},{\"id\":1899},{\"id\":1900},{\"id\":1901},{\"id\":1902},{\"id\":1903},{\"id\":1904},{\"id\":1905},{\"id\":1906},{\"id\":1907},{\"id\":1908},{\"id\":1909},{\"id\":1910},{\"id\":1911},{\"id\":1912},{\"id\":1913},{\"id\":1914},{\"id\":1915},{\"id\":1916},{\"id\":1917},{\"id\":1918},{\"id\":1919},{\"id\":1920},{\"id\":1921},{\"id\":1922},{\"id\":1923},{\"id\":1924},{\"id\":1925},{\"id\":1926},{\"id\":1927},{\"id\":1928},{\"id\":1929},{\"id\":1930},{\"id\":1931},{\"id\":1932},{\"id\":1933},{\"id\":1934},{\"id\":1935},{\"id\":1936},{\"id\":1937},{\"id\":1938},{\"id\":1939},{\"id\":1940},{\"id\":1941},{\"id\":1942},{\"id\":1943},{\"id\":1944},{\"id\":1945},{\"id\":1946},{\"id\":1947},{\"id\":1948},{\"id\":1949},{\"id\":1950},{\"id\":1951},{\"id\":1952},{\"id\":1953},{\"id\":1954},{\"id\":1955},{\"id\":1956},{\"id\":1957},{\"id\":1958},{\"id\":1959},{\"id\":1960},{\"id\":1961},{\"id\":1962},{\"id\":1963},{\"id\":1964},{\"id\":1965},{\"id\":1966},{\"id\":1967},{\"id\":1968},{\"id\":1969},{\"id\":1970},{\"id\":1971},{\"id\":1972},{\"id\":1973},{\"id\":1974},{\"id\":1975},{\"id\":1976},{\"id\":1977},{\"id\":1978},{\"id\":1979},{\"id\":1980},{\"id\":1981},{\"id\":1982},{\"id\":1983},{\"id\":1984},{\"id\":1985},{\"id\":1986},{\"id\":1987},{\"id\":1988},{\"id\":1989},{\"id\":1990},{\"id\":1991},{\"id\":1992},{\"id\":1993},{\"id\":1994},{\"id\":1995},{\"id\":1996},{\"id\":1997},{\"id\":1998},{\"id\":1999},{\"id\":2000},{\"id\":2001},{\"id\":2002},{\"id\":2003},{\"id\":2004},{\"id\":2005},{\"id\":2006},{\"id\":2007},{\"id\":2008},{\"id\":2009},{\"id\":2010},{\"id\":2011},{\"id\":2012},{\"id\":2013},{\"id\":2014},{\"id\":2015},{\"id\":2016},{\"id\":2017},{\"id\":2018},{\"id\":2019},{\"id\":2020},{\"id\":2021},{\"id\":2022},{\"id\":2023},{\"id\":2024},{\"id\":2025},{\"id\":2026},{\"id\":2027},{\"id\":2028},{\"id\":2029},{\"id\":2030},{\"id\":2031},{\"id\":2032},{\"id\":2033},{\"id\":2034},{\"id\":2035},{\"id\":2036},{\"id\":2037},{\"id\":2038},{\"id\":2039},{\"id\":2040},{\"id\":2041},{\"id\":2042},{\"id\":2043},{\"id\":2044},{\"id\":2045},{\"id\":2046},{\"id\":2047},{\"id\":2048},{\"id\":2049},{\"id\":2050},{\"id\":2051},{\"id\":2052},{\"id\":2053},{\"id\":2054},{\"id\":2055},{\"id\":2056},{\"id\":2057},{\"id\":2058},{\"id\":2059},{\"id\":2060},{\"id\":2061},{\"id\":2062},{\"id\":2063},{\"id\":2064},{\"id\":2065},{\"id\":2066},{\"id\":2067},{\"id\":2068},{\"id\":2069},{\"id\":2070},{\"id\":2071},{\"id\":2072},{\"id\":2073},{\"id\":2074},{\"id\":2075},{\"id\":2076},{\"id\":2077},{\"id\":2078},{\"id\":2079},{\"id\":2080},{\"id\":2081},{\"id\":2082},{\"id\":2083},{\"id\":2084},{\"id\":2085},{\"id\":2086},{\"id\":2087},{\"id\":2088},{\"id\":2089},{\"id\":2090},{\"id\":2091},{\"id\":2092},{\"id\":2093},{\"id\":2094},{\"id\":2095},{\"id\":2096},{\"id\":2097},{\"id\":2098},{\"id\":2099},{\"id\":2100},{\"id\":2101},{\"id\":2102},{\"id\":2103},{\"id\":2104},{\"id\":2105},{\"id\":2106},{\"id\":2107},{\"id\":2108},{\"id\":2109},{\"id\":2110},{\"id\":2111},{\"id\":2112},{\"id\":2113},{\"id\":2114},{\"id\":2115},{\"id\":2116},{\"id\":2117},{\"id\":2118},{\"id\":2119},{\"id\":2120},{\"id\":2121},{\"id\":2122},{\"id\":2123},{\"id\":2124},{\"id\":2125},{\"id\":2126},{\"id\":2127},{\"id\":2128},{\"id\":2129},{\"id\":2130},{\"id\":2131},{\"id\":2132},{\"id\":2133},{\"id\":2134},{\"id\":2135},{\"id\":2136},{\"id\":2137},{\"id\":2138},{\"id\":2139},{\"id\":2140},{\"id\":2141},{\"id\":2142},{\"id\":2143},{\"id\":2144},{\"id\":2145},{\"id\":2146},{\"id\":2147},{\"id\":2148},{\"id\":2149},{\"id\":2150},{\"id\":2151},{\"id\":2152},{\"id\":2153},{\"id\":2154},{\"id\":2155},{\"id\":2156},{\"id\":2157},{\"id\":2158},{\"id\":2159},{\"id\":2160},{\"id\":2161},{\"id\":2162},{\"id\":2163},{\"id\":2164},{\"id\":2165},{\"id\":2166},{\"id\":2167},{\"id\":2168},{\"id\":2169},{\"id\":2170},{\"id\":2171},{\"id\":2172},{\"id\":2173},{\"id\":2174},{\"id\":2175},{\"id\":2176},{\"id\":2177},{\"id\":2178},{\"id\":2179},{\"id\":2180},{\"id\":2181},{\"id\":2182},{\"id\":2183},{\"id\":2184},{\"id\":2185},{\"id\":2186},{\"id\":2187},{\"id\":2188},{\"id\":2189},{\"id\":2190},{\"id\":2191},{\"id\":2192},{\"id\":2193},{\"id\":2194},{\"id\":2195},{\"id\":2196},{\"id\":2197},{\"id\":2198},{\"id\":2199},{\"id\":2200},{\"id\":2201},{\"id\":2202},{\"id\":2203},{\"id\":2204},{\"id\":2205},{\"id\":2206},{\"id\":2207},{\"id\":2208},{\"id\":2209},{\"id\":2210},{\"id\":2211},{\"id\":2212},{\"id\":2213},{\"id\":2214},{\"id\":2215},{\"id\":2216},{\"id\":2217},{\"id\":2218},{\"id\":2219},{\"id\":2220},{\"id\":2221},{\"id\":2222},{\"id\":2223},{\"id\":2224},{\"id\":2225},{\"id\":2226},{\"id\":2227},{\"id\":2228},{\"id\":2229},{\"id\":2230},{\"id\":2231},{\"id\":2232},{\"id\":2233},{\"id\":2234},{\"id\":2235},{\"id\":2236},{\"id\":2237},{\"id\":2238},{\"id\":2239},{\"id\":2240},{\"id\":2241},{\"id\":2242},{\"id\":2243},{\"id\":2244},{\"id\":2245},{\"id\":2246},{\"id\":2247},{\"id\":2248},{\"id\":2249},{\"id\":2250},{\"id\":2251},{\"id\":2252},{\"id\":2253},{\"id\":2254},{\"id\":2255},{\"id\":2256},{\"id\":2257},{\"id\":2258},{\"id\":2259},{\"id\":2260},{\"id\":2261},{\"id\":2262},{\"id\":2263},{\"id\":2264},{\"id\":2265},{\"id\":2266},{\"id\":2267},{\"id\":2268},{\"id\":2269},{\"id\":2270},{\"id\":2271},{\"id\":2272},{\"id\":2273},{\"id\":2274},{\"id\":2275},{\"id\":2276},{\"id\":2277},{\"id\":2278},{\"id\":2279},{\"id\":2280},{\"id\":2281},{\"id\":2282},{\"id\":2283},{\"id\":2284},{\"id\":2285},{\"id\":2286},{\"id\":2287},{\"id\":2288},{\"id\":2289},{\"id\":2290},{\"id\":2291},{\"id\":2292},{\"id\":2293},{\"id\":2294},{\"id\":2295},{\"id\":2296},{\"id\":2297},{\"id\":2298},{\"id\":2299},{\"id\":2300},{\"id\":2301},{\"id\":2302},{\"id\":2303},{\"id\":2304},{\"id\":2305},{\"id\":2306},{\"id\":2307},{\"id\":2308},{\"id\":2309},{\"id\":2310},{\"id\":2311},{\"id\":2312},{\"id\":2313},{\"id\":2314},{\"id\":2315},{\"id\":2316},{\"id\":2317},{\"id\":2318},{\"id\":2319},{\"id\":2320},{\"id\":2321},{\"id\":2322},{\"id\":2323},{\"id\":2324},{\"id\":2325},{\"id\":2326},{\"id\":2327},{\"id\":2328},{\"id\":2329},{\"id\":2330},{\"id\":2331},{\"id\":2332},{\"id\":2333},{\"id\":2334},{\"id\":2335},{\"id\":2336},{\"id\":2337},{\"id\":2338},{\"id\":2339},{\"id\":2340},{\"id\":2341},{\"id\":2342},{\"id\":2343},{\"id\":2344},{\"id\":2345},{\"id\":2346},{\"id\":2347},{\"id\":2348},{\"id\":2349},{\"id\":2350},{\"id\":2351},{\"id\":2352},{\"id\":2353},{\"id\":2354},{\"id\":2355},{\"id\":2356},{\"id\":2357},{\"id\":2358},{\"id\":2359},{\"id\":2360},{\"id\":2361},{\"id\":2362},{\"id\":2363},{\"id\":2364},{\"id\":2365},{\"id\":2366},{\"id\":2367},{\"id\":2368},{\"id\":2369},{\"id\":2370},{\"id\":2371},{\"id\":2372},{\"id\":2373},{\"id\":2374},{\"id\":2375},{\"id\":2376},{\"id\":2377},{\"id\":2378},{\"id\":2379},{\"id\":2380},{\"id\":2381},{\"id\":2382},{\"id\":2383},{\"id\":2384},{\"id\":2385},{\"id\":2386},{\"id\":2387},{\"id\":2388},{\"id\":2389},{\"id\":2390},{\"id\":2391},{\"id\":2392},{\"id\":2393},{\"id\":2394},{\"id\":2395},{\"id\":2396},{\"id\":2397},{\"id\":2398},{\"id\":2399},{\"id\":2400},{\"id\":2401},{\"id\":2402},{\"id\":2403},{\"id\":2404},{\"id\":2405},{\"id\":2406},{\"id\":2407},{\"id\":2408},{\"id\":2409},{\"id\":2410},{\"id\":2411},{\"id\":2412},{\"id\":2413},{\"id\":2414},{\"id\":2415},{\"id\":2416},{\"id\":2417},{\"id\":2418},{\"id\":2419},{\"id\":2420},{\"id\":2421},{\"id\":2422},{\"id\":2423},{\"id\":2424},{\"id\":2425},{\"id\":2426},{\"id\":2427},{\"id\":2428},{\"id\":2429},{\"id\":2430},{\"id\":2431},{\"id\":2432},{\"id\":2433},{\"id\":2434},{\"id\":2435},{\"id\":2436},{\"id\":2437},{\"id\":2438},{\"id\":2439},{\"id\":2440},{\"id\":2441},{\"id\":2442},{\"id\":2443},{\"id\":2444},{\"id\":2445},{\"id\":2446},{\"id\":2447},{\"id\":2448},{\"id\":2449},{\"id\":2450},{\"id\":2451},{\"id\":2452},{\"id\":2453},{\"id\":2454},{\"id\":2455},{\"id\":2456},{\"id\":2457},{\"id\":2458},{\"id\":2459},{\"id\":2460},{\"id\":2461},{\"id\":2462},{\"id\":2463},{\"id\":2464},{\"id\":2465},{\"id\":2466},{\"id\":2467},{\"id\":2468},{\"id\":2469},{\"id\":2470},{\"id\":2471},{\"id\":2472},{\"id\":2473},{\"id\":2474},{\"id\":2475},{\"id\":2476},{\"id\":2477},{\"id\":2478},{\"id\":2479},{\"id\":2480},{\"id\":2481},{\"id\":2482},{\"id\":2483},{\"id\":2484},{\"id\":2485},{\"id\":2486},{\"id\":2487},{\"id\":2488},{\"id\":2489},{\"id\":2490},{\"id\":2491},{\"id\":2492},{\"id\":2493},{\"id\":2494},{\"id\":2495},{\"id\":2496},{\"id\":2497},{\"id\":2498},{\"id\":2499},{\"id\":2500},{\"id\":2501},{\"id\":2502},{\"id\":2503},{\"id\":2504},{\"id\":2505},{\"id\":2506},{\"id\":2507},{\"id\":2508},{\"id\":2509},{\"id\":2510},{\"id\":2511},{\"id\":2512},{\"id\":2513},{\"id\":2514},{\"id\":2515},{\"id\":2516},{\"id\":2517},{\"id\":2518},{\"id\":2519},{\"id\":2520},{\"id\":2521},{\"id\":2522},{\"id\":2523},{\"id\":2524},{\"id\":2525},{\"id\":2526},{\"id\":2527},{\"id\":2528},{\"id\":2529},{\"id\":2530},{\"id\":2531},{\"id\":2532},{\"id\":2533},{\"id\":2534},{\"id\":2535},{\"id\":2536},{\"id\":2537},{\"id\":2538},{\"id\":2539},{\"id\":2540},{\"id\":2541},{\"id\":2542},{\"id\":2543},{\"id\":2544},{\"id\":2545},{\"id\":2546},{\"id\":2547},{\"id\":2548},{\"id\":2549},{\"id\":2550},{\"id\":2551},{\"id\":2552},{\"id\":2553},{\"id\":2554},{\"id\":2555},{\"id\":2556},{\"id\":2557},{\"id\":2558},{\"id\":2559},{\"id\":2560},{\"id\":2561},{\"id\":2562},{\"id\":2563},{\"id\":2564},{\"id\":2565},{\"id\":2566},{\"id\":2567},{\"id\":2568},{\"id\":2569},{\"id\":2570},{\"id\":2571},{\"id\":2572},{\"id\":2573},{\"id\":2574},{\"id\":2575},{\"id\":2576},{\"id\":2577},{\"id\":2578},{\"id\":2579},{\"id\":2580},{\"id\":2581},{\"id\":2582},{\"id\":2583},{\"id\":2584},{\"id\":2585},{\"id\":2586},{\"id\":2587},{\"id\":2588},{\"id\":2589},{\"id\":2590},{\"id\":2591},{\"id\":2592},{\"nodeType\":3,\"id\":2596,\"textContent\":\" // Track clicks on page $(document).ready(function() { $(\\\".control\\\").click(function(e) { e.stopImmediatePropagation(); clicks = clicks + 1; console.log(clicks); }); }); $('.userid').html(sid); // console.log(\\\"start of clicked array: \\\"+clicked); // console.log(\\\"start of hovered string: \\\"+hovered); //set correct answers for each question var triangular_answers = { \\\"acme.starttime.1\\\" : [\\\"F\\\"], \\\"acme.starts.1\\\" : [\\\"K\\\"], \\\"acme.meets.1\\\" : [\\\"F\\\"], \\\"acme.endtime.1\\\" : [\\\"H\\\"], \\\"acme.midpoint.1\\\" : [\\\"O\\\"], \\\"acme.starttime.2\\\" : [\\\"F\\\"], \\\"acme.starts.2\\\" : [\\\"K\\\"], \\\"acme.meets.2\\\" : [\\\"F\\\"], \\\"acme.endtime.2\\\" : [\\\"H\\\"], \\\"acme.midpoint.2\\\" : [\\\"A\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"E\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"E\\\"], \\\"bigset.starttime.1\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.1\\\" : [\\\"G\\\"], \\\"bigset.meets.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.1\\\" : [\\\"X\\\"], \\\"bigset.midpoint.1\\\" : [\\\"K\\\",\\\"X\\\"], \\\"bigset.starttime.2\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.2\\\" : [\\\"G\\\"], \\\"bigset.meets.2\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.2\\\" : [\\\"X\\\"], \\\"bigset.midpoint.2\\\" : [\\\"K\\\",\\\"X\\\"] } var orthogonal_answers = { \\\"acme.starttime.1\\\" : [\\\"A\\\"], \\\"acme.starts.1\\\" : [\\\"E\\\"], \\\"acme.meets.1\\\" : [\\\"Z\\\"], \\\"acme.endtime.1\\\" : [\\\"U\\\"], \\\"acme.midpoint.1\\\" : [\\\"U\\\"], \\\"acme.starttime.2\\\" : [\\\"0\\\"], \\\"acme.starts.2\\\" : [\\\"0\\\"], \\\"acme.meets.2\\\" : [\\\"0\\\"], \\\"acme.endtime.2\\\" : [\\\"0\\\"], \\\"acme.midpoint.2\\\" : [\\\"0\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"X\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"X\\\"], \\\"bigset.starttime.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.1\\\" : [\\\"B\\\"], \\\"bigset.meets.1\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.1\\\" : [\\\"B\\\"], \\\"bigset.midpoint.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.starttime.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.2\\\" : [\\\"B\\\"], \\\"bigset.meets.2\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.2\\\" : [\\\"B\\\"], \\\"bigset.midpoint.2\\\" : [\\\"E\\\",\\\"F\\\"] } //display the question and answer buttons based on input values from jsPsych document.getElementById(scenario+\\\".\\\"+question).style.display = \\\"block\\\"; if (question == \\\"strategy\\\") {document.getElementById(\\\"strategyButton\\\").style.display = \\\"block\\\";} else {document.getElementById(\\\"testingButton\\\").style.display = \\\"block\\\";} //---------SET PROPERTIES OF THE GRAPH -------------// // set the dimensions and margins of the graph var margin = {top: 25, right: 30, bottom: 90, left: 100}, width = 800, height = 800; var intersects = false; //default value for intersects scaffold var xAxisTitle, yAxisTitle; var datafile =\\\"\\\"; // SET AXIS VALUES if (axis == 1){ axis = \\\"Orthogonal-XInside-YFull\\\"; } else if (axis == 2){ axis = \\\"Orthogonal-XInside-YPartial\\\"; } else if (axis ==3){ axis = \\\"Triangular-XInside-YInside\\\"; } else if (axis ==4){ axis = \\\"Orthogonal-XInside-YInside\\\"; } else if (axis ==5){ axis = \\\"Orthogonal-XFull-YFull\\\"; } // SET EXPLICIT SCAFFOLD FEATURES if (explicit ==2 && axis != \\\"diagonal\\\"){ scaffold = 2; intersects = false; } else if (explicit == 2 && axis == \\\"diagonal\\\"){ scaffold = 2; intersects = false; } //TODO: not sure if above two lines are still valid since leaders are now generated on the fly else if (explicit == 3){ $('#hint-interactive').css(\\\"display\\\",\\\"block\\\"); //display textimage scaffold intersects = true; } //SET DATA FILE FOR IMPLICIT SCAFFOLD if (impasse == 1){ datafile = \\\"../views/src/data/acme_nonimpasse.csv\\\"; } else if (impasse == 2){ datafile = \\\"../views/src/data/acme_impasse.csv\\\"; } //OVERRIDE DATA FILE FOR NON-SCAFFOLD QUESTIONS if (q > 5) { //override data file if q# is greater than 5 datafile = \\\"../views/src/data/bigset.csv\\\"; console.log(\\\"override data file\\\"); $('#orthogonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#diagonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#hint-interactive').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold intersects = false; } // //---------CREATE THE SVG ------------------------// var svg = d3.select(\\\".d3container\\\").append(\\\"svg\\\") .attr(\\\"width\\\", width + margin.left + margin.right) .attr(\\\"height\\\", height + margin.top + margin.bottom) .append(\\\"g\\\") .attr(\\\"transform\\\", \\\"translate(\\\" + margin.left + \\\",\\\" + margin.top + \\\")\\\"); //---------DRAW THE GRAPH ------------------------// xAxisTitle = \\\"START & END TIME (time of day)\\\"; yAxisTitle = \\\"DURATION (in hours)\\\"; drawTriangleModel(datafile,intersects,axis,scaffold,q); \"},{\"id\":2593},{\"id\":2594},{\"nodeType\":3,\"id\":2597,\"textContent\":\" //MOUSE LOGGING SCRIPT var mouseLog = [] var xwidth = $(document).width(); var xheight = $(document).width(); mouseLog.push(\\\"{x:\\\"+xwidth+\\\",y:\\\"+xheight+\\\",t:\\\"+\\\"0};\\\") document.onmousemove = function(e){ var pageCoords = \\\"{x:\\\" + e.pageX + \\\",y:\\\"+ e.pageY +\\\",t:\\\"+ Date.now()+ \\\"};\\\" ; mouseLog.push(pageCoords); // console.log(pageCoords); }; \"},{\"id\":2595}],[],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2598,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2599,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2598},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2600,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2599},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2601,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":2600},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2602,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2599}},{\"nodeType\":1,\"id\":2603,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2602},\"parentNode\":{\"id\":2599}},{\"nodeType\":3,\"id\":2604,\"textContent\":\"What is your age?\",\"parentNode\":{\"id\":2602}},{\"nodeType\":1,\"id\":2605,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2600}},{\"nodeType\":1,\"id\":2606,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2605},\"parentNode\":{\"id\":2600}},{\"nodeType\":3,\"id\":2607,\"textContent\":\"In what country were you born?\",\"parentNode\":{\"id\":2605}},{\"nodeType\":3,\"id\":2608,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":2601}}],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2598},{\"id\":2599},{\"id\":2602},{\"id\":2604},{\"id\":2603},{\"id\":2600},{\"id\":2605},{\"id\":2607},{\"id\":2606},{\"id\":2601},{\"id\":2608}],[],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2609,\"tagName\":\"FORM\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-form\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2610,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-preamble\",\"class\":\"jspsych-survey-multi-choice-preamble\"},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2611,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-0\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2610},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2612,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-1\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2611},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2613,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-2\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2612},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2614,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-3\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2613},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2615,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"submit\",\"id\":\"jspsych-survey-multi-choice-next\",\"class\":\"jspsych-survey-multi-choice jspsych-btn\",\"value\":\"Submit Answers\"},\"previousSibling\":{\"id\":2614},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2616,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2617,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2616},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2618,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2617},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2619,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2618},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2620,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2619},\"parentNode\":{\"id\":2611}},{\"nodeType\":3,\"id\":2621,\"textContent\":\"What is your first language?\",\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2622,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2621},\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2623,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2624,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2623}},{\"nodeType\":3,\"id\":2625,\"textContent\":\"English\",\"previousSibling\":{\"id\":2624},\"parentNode\":{\"id\":2623}},{\"nodeType\":1,\"id\":2626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2618}},{\"nodeType\":1,\"id\":2627,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2626}},{\"nodeType\":3,\"id\":2628,\"textContent\":\"Spanish\",\"previousSibling\":{\"id\":2627},\"parentNode\":{\"id\":2626}},{\"nodeType\":1,\"id\":2629,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2619}},{\"nodeType\":1,\"id\":2630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2629}},{\"nodeType\":3,\"id\":2631,\"textContent\":\"Mandarin or Cantonese\",\"previousSibling\":{\"id\":2630},\"parentNode\":{\"id\":2629}},{\"nodeType\":1,\"id\":2632,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2633,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2634,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2633},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2635,\"textContent\":\"*\",\"parentNode\":{\"id\":2622}},{\"nodeType\":1,\"id\":2636,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2637,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2636},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2638,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2637},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2639,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2638},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2640,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2639},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2641,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2640},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2642,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2641},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2643,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2642},\"parentNode\":{\"id\":2612}},{\"nodeType\":3,\"id\":2644,\"textContent\":\"What is your year in school?\",\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2645,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2644},\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2646,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2637}},{\"nodeType\":1,\"id\":2647,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2646}},{\"nodeType\":3,\"id\":2648,\"textContent\":\"First\",\"previousSibling\":{\"id\":2647},\"parentNode\":{\"id\":2646}},{\"nodeType\":1,\"id\":2649,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2638}},{\"nodeType\":1,\"id\":2650,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2649}},{\"nodeType\":3,\"id\":2651,\"textContent\":\"Second\",\"previousSibling\":{\"id\":2650},\"parentNode\":{\"id\":2649}},{\"nodeType\":1,\"id\":2652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2639}},{\"nodeType\":1,\"id\":2653,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2652}},{\"nodeType\":3,\"id\":2654,\"textContent\":\"Third\",\"previousSibling\":{\"id\":2653},\"parentNode\":{\"id\":2652}},{\"nodeType\":1,\"id\":2655,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2640}},{\"nodeType\":1,\"id\":2656,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2655}},{\"nodeType\":3,\"id\":2657,\"textContent\":\"Fourth\",\"previousSibling\":{\"id\":2656},\"parentNode\":{\"id\":2655}},{\"nodeType\":1,\"id\":2658,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2641}},{\"nodeType\":1,\"id\":2659,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2658}},{\"nodeType\":3,\"id\":2660,\"textContent\":\"Fifth\",\"previousSibling\":{\"id\":2659},\"parentNode\":{\"id\":2658}},{\"nodeType\":1,\"id\":2661,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2642}},{\"nodeType\":1,\"id\":2662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2661}},{\"nodeType\":3,\"id\":2663,\"textContent\":\"Graduate\",\"previousSibling\":{\"id\":2662},\"parentNode\":{\"id\":2661}},{\"nodeType\":1,\"id\":2664,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2643}},{\"nodeType\":1,\"id\":2665,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2666,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2665},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2667,\"textContent\":\"*\",\"parentNode\":{\"id\":2645}},{\"nodeType\":1,\"id\":2668,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2669,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2668},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2670,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2669},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2671,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2670},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2672,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2671},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2673,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2672},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2674,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2673},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2675,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2674},\"parentNode\":{\"id\":2613}},{\"nodeType\":3,\"id\":2676,\"textContent\":\"What is your major area of study?\",\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2677,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2676},\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2678,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2669}},{\"nodeType\":1,\"id\":2679,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2678}},{\"nodeType\":3,\"id\":2680,\"textContent\":\"Math or Computer Sciences\",\"previousSibling\":{\"id\":2679},\"parentNode\":{\"id\":2678}},{\"nodeType\":1,\"id\":2681,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2670}},{\"nodeType\":1,\"id\":2682,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2681}},{\"nodeType\":3,\"id\":2683,\"textContent\":\"Social Sciences (incl. CogSci)\",\"previousSibling\":{\"id\":2682},\"parentNode\":{\"id\":2681}},{\"nodeType\":1,\"id\":2684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2671}},{\"nodeType\":1,\"id\":2685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2684}},{\"nodeType\":3,\"id\":2686,\"textContent\":\"Biomedical & Health Sciences\",\"previousSibling\":{\"id\":2685},\"parentNode\":{\"id\":2684}},{\"nodeType\":1,\"id\":2687,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2672}},{\"nodeType\":1,\"id\":2688,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2687}},{\"nodeType\":3,\"id\":2689,\"textContent\":\"Natural Sciences\",\"previousSibling\":{\"id\":2688},\"parentNode\":{\"id\":2687}},{\"nodeType\":1,\"id\":2690,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2673}},{\"nodeType\":1,\"id\":2691,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2690}},{\"nodeType\":3,\"id\":2692,\"textContent\":\"Engineering\",\"previousSibling\":{\"id\":2691},\"parentNode\":{\"id\":2690}},{\"nodeType\":1,\"id\":2693,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2674}},{\"nodeType\":1,\"id\":2694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2693}},{\"nodeType\":3,\"id\":2695,\"textContent\":\"Humanities\",\"previousSibling\":{\"id\":2694},\"parentNode\":{\"id\":2693}},{\"nodeType\":1,\"id\":2696,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2675}},{\"nodeType\":1,\"id\":2697,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2698,\"textContent\":\"Fine Arts\",\"previousSibling\":{\"id\":2697},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2699,\"textContent\":\"*\",\"parentNode\":{\"id\":2677}},{\"nodeType\":1,\"id\":2700,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2701,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2700},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2702,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2701},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2703,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2702},\"parentNode\":{\"id\":2614}},{\"nodeType\":3,\"id\":2704,\"textContent\":\"What is your gender?\",\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2705,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2704},\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2706,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2701}},{\"nodeType\":1,\"id\":2707,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2706}},{\"nodeType\":3,\"id\":2708,\"textContent\":\"Male\",\"previousSibling\":{\"id\":2707},\"parentNode\":{\"id\":2706}},{\"nodeType\":1,\"id\":2709,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2702}},{\"nodeType\":1,\"id\":2710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2709}},{\"nodeType\":3,\"id\":2711,\"textContent\":\"Female\",\"previousSibling\":{\"id\":2710},\"parentNode\":{\"id\":2709}},{\"nodeType\":1,\"id\":2712,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2703}},{\"nodeType\":1,\"id\":2713,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2714,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2713},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2715,\"textContent\":\"*\",\"parentNode\":{\"id\":2705}}],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2609},{\"id\":2610},{\"id\":2611},{\"id\":2616},{\"id\":2621},{\"id\":2622},{\"id\":2635},{\"id\":2617},{\"id\":2623},{\"id\":2624},{\"id\":2625},{\"id\":2618},{\"id\":2626},{\"id\":2627},{\"id\":2628},{\"id\":2619},{\"id\":2629},{\"id\":2630},{\"id\":2631},{\"id\":2620},{\"id\":2632},{\"id\":2633},{\"id\":2634},{\"id\":2612},{\"id\":2636},{\"id\":2644},{\"id\":2645},{\"id\":2667},{\"id\":2637},{\"id\":2646},{\"id\":2647},{\"id\":2648},{\"id\":2638},{\"id\":2649},{\"id\":2650},{\"id\":2651},{\"id\":2639},{\"id\":2652},{\"id\":2653},{\"id\":2654},{\"id\":2640},{\"id\":2655},{\"id\":2656},{\"id\":2657},{\"id\":2641},{\"id\":2658},{\"id\":2659},{\"id\":2660},{\"id\":2642},{\"id\":2661},{\"id\":2662},{\"id\":2663},{\"id\":2643},{\"id\":2664},{\"id\":2665},{\"id\":2666},{\"id\":2613},{\"id\":2668},{\"id\":2676},{\"id\":2677},{\"id\":2699},{\"id\":2669},{\"id\":2678},{\"id\":2679},{\"id\":2680},{\"id\":2670},{\"id\":2681},{\"id\":2682},{\"id\":2683},{\"id\":2671},{\"id\":2684},{\"id\":2685},{\"id\":2686},{\"id\":2672},{\"id\":2687},{\"id\":2688},{\"id\":2689},{\"id\":2673},{\"id\":2690},{\"id\":2691},{\"id\":2692},{\"id\":2674},{\"id\":2693},{\"id\":2694},{\"id\":2695},{\"id\":2675},{\"id\":2696},{\"id\":2697},{\"id\":2698},{\"id\":2614},{\"id\":2700},{\"id\":2704},{\"id\":2705},{\"id\":2715},{\"id\":2701},{\"id\":2706},{\"id\":2707},{\"id\":2708},{\"id\":2702},{\"id\":2709},{\"id\":2710},{\"id\":2711},{\"id\":2703},{\"id\":2712},{\"id\":2713},{\"id\":2714},{\"id\":2615}],[],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2716,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2717,\"textContent\":\" \",\"previousSibling\":{\"id\":2716},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2718,\"textContent\":\" \",\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":2718},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2720,\"textContent\":\" \",\"previousSibling\":{\"id\":2719},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2721,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":2720},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2722,\"textContent\":\" \",\"previousSibling\":{\"id\":2721},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2723,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":2722},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2724,\"textContent\":\" \",\"previousSibling\":{\"id\":2723},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2725,\"textContent\":\" \",\"parentNode\":{\"id\":2719}},{\"nodeType\":1,\"id\":2726,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":2725},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2727,\"textContent\":\" \",\"previousSibling\":{\"id\":2726},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2728,\"textContent\":\" \",\"parentNode\":{\"id\":2726}},{\"nodeType\":1,\"id\":2729,\"tagName\":\"H3\",\"attributes\":{},\"previousSibling\":{\"id\":2728},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2730,\"textContent\":\" \",\"previousSibling\":{\"id\":2729},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2731,\"textContent\":\"DEBRIEFING\",\"parentNode\":{\"id\":2729}},{\"nodeType\":3,\"id\":2732,\"textContent\":\" \",\"parentNode\":{\"id\":2721}},{\"nodeType\":1,\"id\":2733,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":2732},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2734,\"textContent\":\" \",\"previousSibling\":{\"id\":2733},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2735,\"textContent\":\" \",\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2736,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic\"},\"previousSibling\":{\"id\":2735},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2737,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2736},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2738,\"textContent\":\" \",\"previousSibling\":{\"id\":2737},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2739,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2738},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2740,\"textContent\":\" \",\"previousSibling\":{\"id\":2739},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2741,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2740},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2742,\"textContent\":\" \",\"previousSibling\":{\"id\":2741},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2743,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:bold;\"},\"previousSibling\":{\"id\":2742},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2744,\"textContent\":\" \",\"previousSibling\":{\"id\":2743},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2745,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":2744},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2746,\"textContent\":\" \",\"previousSibling\":{\"id\":2745},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2747,\"textContent\":\"Thank you very much for your participation! This debriefing will tell you more about the study, what you did, and why. \",\"parentNode\":{\"id\":2736}},{\"nodeType\":3,\"id\":2748,\"textContent\":\" \",\"parentNode\":{\"id\":2737}},{\"nodeType\":1,\"id\":2749,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2748},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2750,\"textContent\":\" You have just used a series of pictures (charts, graphs and diagrams) accompanied by different types of instructions to answer a series of problem solving questions. While you were using the pictures, we measured where you clicked, scrolled and pointed with the computer mouse. We also measured the accuracy of your responses and the time it took to complete each question.\",\"previousSibling\":{\"id\":2749},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2751,\"textContent\":\"What did you just do?\",\"parentNode\":{\"id\":2749}},{\"nodeType\":3,\"id\":2752,\"textContent\":\" \",\"parentNode\":{\"id\":2739}},{\"nodeType\":1,\"id\":2753,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2752},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2754,\"textContent\":\" Researchers of learning and cognition have long been interested in how graphic displays of information can be used to communicate, solve problems, and generate insights. As powerful as graphics may be in their communicative efficiency, they're not always immediately intuitive to understand. In short, we know a great deal more about learning with representations than we do about the learning of representations. In this project we are building upon previous research on reading and graph comprehension to explore how readers make sense of unfamiliar representations. The instructions you saw for each type of graph are known as “scaffolding techniques”, and we will compare your performance with the scaffolding techniques you saw with the performance of other participants to determine which types of instructions are most effective in helping humans to make sense of unfamiliar graphs. \",\"previousSibling\":{\"id\":2753},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2755,\"textContent\":\"Why did we have you do it?\",\"parentNode\":{\"id\":2753}},{\"nodeType\":1,\"id\":2756,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2757,\"textContent\":\" We expect that you will have found some of the graphics more difficult to use than others. We also expect that with the assistance of the instructions, after solving several problems you will learn to use the difficult graphics so that you can answer the questions even more quickly than without. If you would like to receive a copy of the results of the study, or have any further questions, please contact the researchers Primary Researcher: Amy Fox : a2fox@ucsd.edu Faculty Advisor : Dr. Jim Hollan : hollan@ucsd.edu \",\"previousSibling\":{\"id\":2756},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2758,\"textContent\":\"What do we expect to find?\",\"parentNode\":{\"id\":2756}},{\"nodeType\":3,\"id\":2759,\"textContent\":\"It is important that you do not discuss this experiment with other students who might participate after you. They must participate in the same way as you did, without any knowledge of what the experiment entails, or the reasoning behind it.\",\"parentNode\":{\"id\":2743}},{\"nodeType\":3,\"id\":2760,\"textContent\":\"Thank you for your time! We hope you enjoyed participating in this study as much as we enjoyed designing it.\",\"parentNode\":{\"id\":2745}},{\"nodeType\":3,\"id\":2761,\"textContent\":\" \",\"parentNode\":{\"id\":2723}},{\"nodeType\":1,\"id\":2762,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":2761},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2763,\"textContent\":\" \",\"previousSibling\":{\"id\":2762},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2764,\"textContent\":\"FINISH\",\"parentNode\":{\"id\":2762}}],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2716},{\"id\":2718},{\"id\":2719},{\"id\":2725},{\"id\":2726},{\"id\":2728},{\"id\":2729},{\"id\":2731},{\"id\":2730},{\"id\":2727},{\"id\":2720},{\"id\":2721},{\"id\":2732},{\"id\":2733},{\"id\":2735},{\"id\":2736},{\"id\":2747},{\"id\":2737},{\"id\":2748},{\"id\":2749},{\"id\":2751},{\"id\":2750},{\"id\":2738},{\"id\":2739},{\"id\":2752},{\"id\":2753},{\"id\":2755},{\"id\":2754},{\"id\":2740},{\"id\":2741},{\"id\":2756},{\"id\":2758},{\"id\":2757},{\"id\":2742},{\"id\":2743},{\"id\":2759},{\"id\":2744},{\"id\":2745},{\"id\":2760},{\"id\":2746},{\"id\":2734},{\"id\":2722},{\"id\":2723},{\"id\":2761},{\"id\":2762},{\"id\":2764},{\"id\":2763},{\"id\":2724},{\"id\":2717}],[],[],[]]}"
    },
    {
      "sequence": 8,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2765,\"tagName\":\"PRE\",\"attributes\":{\"id\":\"jspsych-data-display\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2766,\"textContent\":\"[ { \\\"rt\\\": 131084, \\\"stimulus\\\": \\\"img/phone.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"phone\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 0, \\\"time_elapsed\\\": 131089, \\\"internal_node_id\\\": \\\"0.0-0.0\\\", \\\"subject\\\": \\\"38NFJ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"echo\\\", \\\"condition\\\": \\\"121\\\" }, { \\\"rt\\\": 8444, \\\"url\\\": \\\"../views/src/external/consent.html\\\", \\\"block\\\": \\\"consent\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 1, \\\"time_elapsed\\\": 140867, \\\"internal_node_id\\\": \\\"0.0-1.0\\\", \\\"subject\\\": \\\"38NFJ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"echo\\\", \\\"condition\\\": \\\"121\\\" }, { \\\"rt\\\": 8544, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"ECHO\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"121\\\\\\\"}\\\", \\\"block\\\": \\\"codes\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 2, \\\"time_elapsed\\\": 150417, \\\"internal_node_id\\\": \\\"0.0-2.0\\\", \\\"subject\\\": \\\"38NFJ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"echo\\\", \\\"condition\\\": \\\"121\\\" }, { \\\"rt\\\": 3636, \\\"url\\\": \\\"../views/src/external/instructions_lab.html\\\", \\\"block\\\": \\\"instructions_lab\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 3, \\\"time_elapsed\\\": 155145, \\\"internal_node_id\\\": \\\"0.0-3.0\\\", \\\"subject\\\": \\\"38NFJ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"echo\\\", \\\"condition\\\": \\\"121\\\" }, { \\\"rt\\\": 7297, \\\"stimulus\\\": \\\"img/acme.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"scenario\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 4, \\\"time_elapsed\\\": 163445, \\\"internal_node_id\\\": \\\"0.0-4.0\\\", \\\"subject\\\": \\\"38NFJ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"echo\\\", \\\"condition\\\": \\\"121\\\" }, { \\\"rt\\\": 20033, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 5, \\\"time_elapsed\\\": 184902, \\\"internal_node_id\\\": \\\"0.0-5.0-0.0\\\", \\\"subject\\\": \\\"38NFJ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"echo\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 1, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-11 AM-11 AM-C -02 PM-11 AM\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:1018,y:1023,t:1527008996209};\\\", \\\"{x:1074,y:1065,t:1527008996224};\\\", \\\"{x:1192,y:1166,t:1527008996240};\\\", \\\"{x:1334,y:1199,t:1527008996256};\\\", \\\"{x:1452,y:1199,t:1527008996273};\\\", \\\"{x:1516,y:1199,t:1527008996288};\\\", \\\"{x:1524,y:1199,t:1527008996306};\\\", \\\"{x:1508,y:1187,t:1527008996360};\\\", \\\"{x:1479,y:1135,t:1527008996373};\\\", \\\"{x:1439,y:970,t:1527008996389};\\\", \\\"{x:1407,y:795,t:1527008996406};\\\", \\\"{x:1403,y:681,t:1527008996423};\\\", \\\"{x:1428,y:552,t:1527008996440};\\\", \\\"{x:1444,y:504,t:1527008996458};\\\", \\\"{x:1457,y:471,t:1527008996473};\\\", \\\"{x:1471,y:455,t:1527008996490};\\\", \\\"{x:1495,y:449,t:1527008996507};\\\", \\\"{x:1517,y:449,t:1527008996523};\\\", \\\"{x:1529,y:449,t:1527008996540};\\\", \\\"{x:1531,y:450,t:1527008996557};\\\", \\\"{x:1520,y:450,t:1527008996573};\\\", \\\"{x:1476,y:450,t:1527008996590};\\\", \\\"{x:1346,y:450,t:1527008996608};\\\", \\\"{x:1261,y:446,t:1527008996623};\\\", \\\"{x:1138,y:423,t:1527008996640};\\\", \\\"{x:1008,y:404,t:1527008996657};\\\", \\\"{x:916,y:404,t:1527008996674};\\\", \\\"{x:872,y:413,t:1527008996690};\\\", \\\"{x:852,y:424,t:1527008996707};\\\", \\\"{x:846,y:433,t:1527008996724};\\\", \\\"{x:846,y:442,t:1527008996740};\\\", \\\"{x:848,y:458,t:1527008996757};\\\", \\\"{x:854,y:471,t:1527008996775};\\\", \\\"{x:858,y:484,t:1527008996790};\\\", \\\"{x:864,y:499,t:1527008996807};\\\", \\\"{x:864,y:500,t:1527008996824};\\\", \\\"{x:864,y:501,t:1527008996840};\\\", \\\"{x:863,y:501,t:1527008996904};\\\", \\\"{x:858,y:501,t:1527008996911};\\\", \\\"{x:854,y:503,t:1527008996924};\\\", \\\"{x:843,y:511,t:1527008996941};\\\", \\\"{x:834,y:519,t:1527008996956};\\\", \\\"{x:825,y:524,t:1527008996973};\\\", \\\"{x:824,y:524,t:1527008996990};\\\", \\\"{x:822,y:524,t:1527008997007};\\\", \\\"{x:821,y:526,t:1527008997023};\\\", \\\"{x:820,y:527,t:1527008997040};\\\", \\\"{x:818,y:529,t:1527008997056};\\\", \\\"{x:818,y:531,t:1527008997094};\\\", \\\"{x:819,y:532,t:1527008997143};\\\", \\\"{x:820,y:532,t:1527008997156};\\\", \\\"{x:821,y:532,t:1527008997174};\\\", \\\"{x:824,y:532,t:1527008997190};\\\", \\\"{x:826,y:532,t:1527008997207};\\\", \\\"{x:828,y:532,t:1527008997224};\\\", \\\"{x:829,y:531,t:1527008997241};\\\", \\\"{x:830,y:531,t:1527008997257};\\\", \\\"{x:831,y:530,t:1527008997279};\\\", \\\"{x:838,y:530,t:1527008997919};\\\", \\\"{x:859,y:530,t:1527008997928};\\\", \\\"{x:889,y:530,t:1527008997941};\\\", \\\"{x:962,y:530,t:1527008997958};\\\", \\\"{x:1059,y:530,t:1527008997974};\\\", \\\"{x:1206,y:557,t:1527008997990};\\\", \\\"{x:1283,y:579,t:1527008998007};\\\", \\\"{x:1330,y:598,t:1527008998025};\\\", \\\"{x:1367,y:610,t:1527008998042};\\\", \\\"{x:1383,y:616,t:1527008998058};\\\", \\\"{x:1392,y:623,t:1527008998074};\\\", \\\"{x:1398,y:630,t:1527008998090};\\\", \\\"{x:1405,y:641,t:1527008998108};\\\", \\\"{x:1411,y:652,t:1527008998124};\\\", \\\"{x:1415,y:665,t:1527008998141};\\\", \\\"{x:1415,y:680,t:1527008998157};\\\", \\\"{x:1402,y:728,t:1527008998174};\\\", \\\"{x:1386,y:769,t:1527008998190};\\\", \\\"{x:1371,y:805,t:1527008998208};\\\", \\\"{x:1352,y:842,t:1527008998225};\\\", \\\"{x:1329,y:885,t:1527008998241};\\\", \\\"{x:1309,y:929,t:1527008998257};\\\", \\\"{x:1289,y:962,t:1527008998275};\\\", \\\"{x:1275,y:979,t:1527008998292};\\\", \\\"{x:1267,y:990,t:1527008998309};\\\", \\\"{x:1259,y:1002,t:1527008998325};\\\", \\\"{x:1254,y:1011,t:1527008998341};\\\", \\\"{x:1253,y:1016,t:1527008998358};\\\", \\\"{x:1251,y:1019,t:1527008998375};\\\", \\\"{x:1251,y:1020,t:1527008998471};\\\", \\\"{x:1251,y:1019,t:1527008998536};\\\", \\\"{x:1251,y:1018,t:1527008998544};\\\", \\\"{x:1251,y:1016,t:1527008998558};\\\", \\\"{x:1251,y:1009,t:1527008998576};\\\", \\\"{x:1253,y:1006,t:1527008998592};\\\", \\\"{x:1259,y:997,t:1527008998608};\\\", \\\"{x:1267,y:990,t:1527008998626};\\\", \\\"{x:1273,y:980,t:1527008998642};\\\", \\\"{x:1275,y:977,t:1527008998658};\\\", \\\"{x:1277,y:975,t:1527008998675};\\\", \\\"{x:1277,y:974,t:1527008998692};\\\", \\\"{x:1278,y:972,t:1527008998708};\\\", \\\"{x:1278,y:971,t:1527008998725};\\\", \\\"{x:1281,y:967,t:1527008998743};\\\", \\\"{x:1283,y:966,t:1527008998758};\\\", \\\"{x:1284,y:964,t:1527008998776};\\\", \\\"{x:1284,y:963,t:1527008999023};\\\", \\\"{x:1284,y:962,t:1527008999070};\\\", \\\"{x:1284,y:961,t:1527008999504};\\\", \\\"{x:1283,y:959,t:1527008999520};\\\", \\\"{x:1283,y:958,t:1527008999591};\\\", \\\"{x:1282,y:958,t:1527008999623};\\\", \\\"{x:1282,y:956,t:1527008999671};\\\", \\\"{x:1281,y:956,t:1527008999703};\\\", \\\"{x:1281,y:955,t:1527008999719};\\\", \\\"{x:1281,y:954,t:1527008999816};\\\", \\\"{x:1281,y:953,t:1527008999863};\\\", \\\"{x:1281,y:952,t:1527008999880};\\\", \\\"{x:1281,y:951,t:1527008999903};\\\", \\\"{x:1281,y:950,t:1527008999919};\\\", \\\"{x:1281,y:949,t:1527008999935};\\\", \\\"{x:1281,y:948,t:1527008999960};\\\", \\\"{x:1281,y:946,t:1527008999976};\\\", \\\"{x:1281,y:945,t:1527009000007};\\\", \\\"{x:1281,y:944,t:1527009000015};\\\", \\\"{x:1281,y:943,t:1527009000054};\\\", \\\"{x:1282,y:944,t:1527009000670};\\\", \\\"{x:1282,y:945,t:1527009000679};\\\", \\\"{x:1282,y:946,t:1527009000692};\\\", \\\"{x:1283,y:948,t:1527009000710};\\\", \\\"{x:1283,y:949,t:1527009000726};\\\", \\\"{x:1283,y:951,t:1527009000743};\\\", \\\"{x:1283,y:953,t:1527009000759};\\\", \\\"{x:1283,y:954,t:1527009000775};\\\", \\\"{x:1283,y:955,t:1527009000793};\\\", \\\"{x:1283,y:952,t:1527009000911};\\\", \\\"{x:1283,y:949,t:1527009000927};\\\", \\\"{x:1284,y:946,t:1527009000943};\\\", \\\"{x:1284,y:943,t:1527009000959};\\\", \\\"{x:1284,y:941,t:1527009000977};\\\", \\\"{x:1284,y:939,t:1527009000992};\\\", \\\"{x:1284,y:938,t:1527009001015};\\\", \\\"{x:1284,y:937,t:1527009001031};\\\", \\\"{x:1284,y:935,t:1527009001047};\\\", \\\"{x:1284,y:933,t:1527009001063};\\\", \\\"{x:1284,y:932,t:1527009001077};\\\", \\\"{x:1284,y:931,t:1527009001093};\\\", \\\"{x:1284,y:929,t:1527009001110};\\\", \\\"{x:1284,y:928,t:1527009001127};\\\", \\\"{x:1284,y:926,t:1527009001143};\\\", \\\"{x:1284,y:925,t:1527009001161};\\\", \\\"{x:1284,y:923,t:1527009001178};\\\", \\\"{x:1284,y:922,t:1527009001200};\\\", \\\"{x:1284,y:921,t:1527009001216};\\\", \\\"{x:1284,y:920,t:1527009001231};\\\", \\\"{x:1284,y:919,t:1527009001248};\\\", \\\"{x:1284,y:918,t:1527009001263};\\\", \\\"{x:1284,y:917,t:1527009001281};\\\", \\\"{x:1284,y:915,t:1527009001303};\\\", \\\"{x:1284,y:914,t:1527009001319};\\\", \\\"{x:1284,y:913,t:1527009001334};\\\", \\\"{x:1284,y:911,t:1527009001344};\\\", \\\"{x:1284,y:907,t:1527009001359};\\\", \\\"{x:1284,y:902,t:1527009001377};\\\", \\\"{x:1284,y:896,t:1527009001394};\\\", \\\"{x:1284,y:889,t:1527009001410};\\\", \\\"{x:1284,y:884,t:1527009001426};\\\", \\\"{x:1284,y:880,t:1527009001444};\\\", \\\"{x:1284,y:876,t:1527009001460};\\\", \\\"{x:1284,y:871,t:1527009001476};\\\", \\\"{x:1284,y:865,t:1527009001494};\\\", \\\"{x:1284,y:862,t:1527009001510};\\\", \\\"{x:1284,y:856,t:1527009001527};\\\", \\\"{x:1284,y:854,t:1527009001543};\\\", \\\"{x:1284,y:852,t:1527009001561};\\\", \\\"{x:1284,y:851,t:1527009001577};\\\", \\\"{x:1284,y:850,t:1527009001594};\\\", \\\"{x:1284,y:848,t:1527009001610};\\\", \\\"{x:1284,y:843,t:1527009001627};\\\", \\\"{x:1284,y:838,t:1527009001645};\\\", \\\"{x:1284,y:834,t:1527009001660};\\\", \\\"{x:1284,y:830,t:1527009001677};\\\", \\\"{x:1284,y:827,t:1527009001695};\\\", \\\"{x:1284,y:824,t:1527009001711};\\\", \\\"{x:1284,y:819,t:1527009001728};\\\", \\\"{x:1284,y:813,t:1527009001743};\\\", \\\"{x:1284,y:807,t:1527009001760};\\\", \\\"{x:1284,y:801,t:1527009001777};\\\", \\\"{x:1283,y:793,t:1527009001794};\\\", \\\"{x:1283,y:786,t:1527009001811};\\\", \\\"{x:1280,y:780,t:1527009001827};\\\", \\\"{x:1279,y:772,t:1527009001844};\\\", \\\"{x:1278,y:765,t:1527009001861};\\\", \\\"{x:1275,y:755,t:1527009001878};\\\", \\\"{x:1274,y:746,t:1527009001894};\\\", \\\"{x:1271,y:733,t:1527009001911};\\\", \\\"{x:1270,y:725,t:1527009001928};\\\", \\\"{x:1268,y:718,t:1527009001945};\\\", \\\"{x:1267,y:711,t:1527009001961};\\\", \\\"{x:1266,y:706,t:1527009001978};\\\", \\\"{x:1265,y:701,t:1527009001995};\\\", \\\"{x:1264,y:696,t:1527009002011};\\\", \\\"{x:1264,y:693,t:1527009002028};\\\", \\\"{x:1264,y:689,t:1527009002044};\\\", \\\"{x:1264,y:686,t:1527009002061};\\\", \\\"{x:1264,y:680,t:1527009002077};\\\", \\\"{x:1264,y:676,t:1527009002094};\\\", \\\"{x:1264,y:669,t:1527009002112};\\\", \\\"{x:1264,y:664,t:1527009002127};\\\", \\\"{x:1264,y:659,t:1527009002145};\\\", \\\"{x:1264,y:653,t:1527009002162};\\\", \\\"{x:1264,y:648,t:1527009002178};\\\", \\\"{x:1264,y:642,t:1527009002194};\\\", \\\"{x:1264,y:639,t:1527009002211};\\\", \\\"{x:1264,y:634,t:1527009002228};\\\", \\\"{x:1264,y:631,t:1527009002245};\\\", \\\"{x:1264,y:628,t:1527009002261};\\\", \\\"{x:1264,y:626,t:1527009002278};\\\", \\\"{x:1264,y:622,t:1527009002294};\\\", \\\"{x:1264,y:613,t:1527009002312};\\\", \\\"{x:1264,y:606,t:1527009002327};\\\", \\\"{x:1264,y:599,t:1527009002344};\\\", \\\"{x:1264,y:593,t:1527009002361};\\\", \\\"{x:1264,y:589,t:1527009002378};\\\", \\\"{x:1266,y:585,t:1527009002394};\\\", \\\"{x:1266,y:582,t:1527009002411};\\\", \\\"{x:1267,y:580,t:1527009002428};\\\", \\\"{x:1268,y:576,t:1527009002444};\\\", \\\"{x:1269,y:573,t:1527009002462};\\\", \\\"{x:1270,y:569,t:1527009002479};\\\", \\\"{x:1271,y:564,t:1527009002495};\\\", \\\"{x:1274,y:560,t:1527009002511};\\\", \\\"{x:1274,y:557,t:1527009002528};\\\", \\\"{x:1275,y:556,t:1527009002544};\\\", \\\"{x:1275,y:554,t:1527009002562};\\\", \\\"{x:1276,y:554,t:1527009002579};\\\", \\\"{x:1277,y:553,t:1527009002595};\\\", \\\"{x:1277,y:552,t:1527009002615};\\\", \\\"{x:1278,y:552,t:1527009003000};\\\", \\\"{x:1279,y:554,t:1527009003015};\\\", \\\"{x:1280,y:555,t:1527009003028};\\\", \\\"{x:1281,y:556,t:1527009003049};\\\", \\\"{x:1281,y:559,t:1527009003166};\\\", \\\"{x:1276,y:563,t:1527009003178};\\\", \\\"{x:1250,y:576,t:1527009003195};\\\", \\\"{x:1195,y:598,t:1527009003212};\\\", \\\"{x:1103,y:613,t:1527009003228};\\\", \\\"{x:1005,y:633,t:1527009003245};\\\", \\\"{x:907,y:650,t:1527009003262};\\\", \\\"{x:827,y:667,t:1527009003278};\\\", \\\"{x:752,y:689,t:1527009003295};\\\", \\\"{x:729,y:695,t:1527009003312};\\\", \\\"{x:722,y:696,t:1527009003328};\\\", \\\"{x:720,y:696,t:1527009003345};\\\", \\\"{x:720,y:692,t:1527009003415};\\\", \\\"{x:720,y:683,t:1527009003429};\\\", \\\"{x:720,y:657,t:1527009003446};\\\", \\\"{x:726,y:632,t:1527009003462};\\\", \\\"{x:747,y:594,t:1527009003480};\\\", \\\"{x:798,y:533,t:1527009003495};\\\", \\\"{x:818,y:510,t:1527009003512};\\\", \\\"{x:832,y:500,t:1527009003529};\\\", \\\"{x:834,y:496,t:1527009003544};\\\", \\\"{x:835,y:495,t:1527009003562};\\\", \\\"{x:836,y:496,t:1527009003654};\\\", \\\"{x:837,y:497,t:1527009003661};\\\", \\\"{x:840,y:498,t:1527009003677};\\\", \\\"{x:844,y:500,t:1527009003695};\\\", \\\"{x:846,y:504,t:1527009003711};\\\", \\\"{x:847,y:507,t:1527009003729};\\\", \\\"{x:847,y:508,t:1527009003746};\\\", \\\"{x:847,y:511,t:1527009003761};\\\", \\\"{x:847,y:513,t:1527009003783};\\\", \\\"{x:847,y:514,t:1527009003795};\\\", \\\"{x:844,y:515,t:1527009003813};\\\", \\\"{x:840,y:515,t:1527009003829};\\\", \\\"{x:832,y:517,t:1527009003846};\\\", \\\"{x:829,y:517,t:1527009003862};\\\", \\\"{x:828,y:517,t:1527009003887};\\\", \\\"{x:827,y:518,t:1527009004199};\\\", \\\"{x:827,y:520,t:1527009004212};\\\", \\\"{x:829,y:526,t:1527009004229};\\\", \\\"{x:830,y:532,t:1527009004245};\\\", \\\"{x:830,y:537,t:1527009004263};\\\", \\\"{x:830,y:542,t:1527009004279};\\\", \\\"{x:830,y:547,t:1527009004295};\\\", \\\"{x:830,y:554,t:1527009004313};\\\", \\\"{x:830,y:566,t:1527009004329};\\\", \\\"{x:827,y:584,t:1527009004346};\\\", \\\"{x:821,y:608,t:1527009004363};\\\", \\\"{x:815,y:631,t:1527009004379};\\\", \\\"{x:808,y:654,t:1527009004396};\\\", \\\"{x:804,y:671,t:1527009004412};\\\", \\\"{x:801,y:687,t:1527009004429};\\\", \\\"{x:798,y:706,t:1527009004447};\\\", \\\"{x:796,y:717,t:1527009004463};\\\", \\\"{x:796,y:724,t:1527009004479};\\\", \\\"{x:796,y:729,t:1527009004496};\\\", \\\"{x:796,y:735,t:1527009004513};\\\", \\\"{x:799,y:748,t:1527009004529};\\\", \\\"{x:812,y:764,t:1527009004546};\\\", \\\"{x:838,y:778,t:1527009004563};\\\", \\\"{x:904,y:795,t:1527009004579};\\\", \\\"{x:993,y:809,t:1527009004596};\\\", \\\"{x:1101,y:823,t:1527009004613};\\\", \\\"{x:1210,y:824,t:1527009004630};\\\", \\\"{x:1366,y:826,t:1527009004649};\\\", \\\"{x:1452,y:826,t:1527009004663};\\\", \\\"{x:1508,y:828,t:1527009004689};\\\", \\\"{x:1533,y:830,t:1527009004705};\\\", \\\"{x:1543,y:832,t:1527009004722};\\\", \\\"{x:1543,y:833,t:1527009004776};\\\", \\\"{x:1543,y:834,t:1527009004789};\\\", \\\"{x:1542,y:840,t:1527009004805};\\\", \\\"{x:1539,y:849,t:1527009004822};\\\", \\\"{x:1533,y:863,t:1527009004839};\\\", \\\"{x:1524,y:884,t:1527009004856};\\\", \\\"{x:1518,y:896,t:1527009004872};\\\", \\\"{x:1513,y:902,t:1527009004890};\\\", \\\"{x:1508,y:910,t:1527009004905};\\\", \\\"{x:1505,y:917,t:1527009004923};\\\", \\\"{x:1501,y:925,t:1527009004940};\\\", \\\"{x:1494,y:936,t:1527009004956};\\\", \\\"{x:1486,y:949,t:1527009004972};\\\", \\\"{x:1475,y:961,t:1527009004989};\\\", \\\"{x:1462,y:972,t:1527009005005};\\\", \\\"{x:1447,y:982,t:1527009005022};\\\", \\\"{x:1434,y:988,t:1527009005039};\\\", \\\"{x:1406,y:998,t:1527009005057};\\\", \\\"{x:1394,y:1001,t:1527009005073};\\\", \\\"{x:1390,y:1001,t:1527009005090};\\\", \\\"{x:1386,y:1002,t:1527009005107};\\\", \\\"{x:1384,y:1003,t:1527009005123};\\\", \\\"{x:1382,y:1004,t:1527009005140};\\\", \\\"{x:1378,y:1004,t:1527009005157};\\\", \\\"{x:1375,y:1005,t:1527009005172};\\\", \\\"{x:1370,y:1007,t:1527009005189};\\\", \\\"{x:1366,y:1007,t:1527009005206};\\\", \\\"{x:1364,y:1009,t:1527009005223};\\\", \\\"{x:1361,y:1010,t:1527009005240};\\\", \\\"{x:1357,y:1010,t:1527009005257};\\\", \\\"{x:1355,y:1010,t:1527009005273};\\\", \\\"{x:1350,y:1010,t:1527009005290};\\\", \\\"{x:1343,y:1010,t:1527009005306};\\\", \\\"{x:1338,y:1010,t:1527009005323};\\\", \\\"{x:1327,y:1010,t:1527009005340};\\\", \\\"{x:1318,y:1009,t:1527009005356};\\\", \\\"{x:1311,y:1008,t:1527009005373};\\\", \\\"{x:1304,y:1005,t:1527009005389};\\\", \\\"{x:1299,y:1003,t:1527009005406};\\\", \\\"{x:1295,y:1000,t:1527009005423};\\\", \\\"{x:1293,y:1000,t:1527009005439};\\\", \\\"{x:1292,y:999,t:1527009005457};\\\", \\\"{x:1292,y:997,t:1527009005481};\\\", \\\"{x:1292,y:995,t:1527009005496};\\\", \\\"{x:1292,y:994,t:1527009005513};\\\", \\\"{x:1292,y:993,t:1527009005524};\\\", \\\"{x:1292,y:992,t:1527009005540};\\\", \\\"{x:1292,y:991,t:1527009005569};\\\", \\\"{x:1291,y:990,t:1527009005577};\\\", \\\"{x:1291,y:989,t:1527009005590};\\\", \\\"{x:1290,y:987,t:1527009005607};\\\", \\\"{x:1290,y:986,t:1527009005624};\\\", \\\"{x:1290,y:985,t:1527009005640};\\\", \\\"{x:1289,y:982,t:1527009005658};\\\", \\\"{x:1288,y:981,t:1527009005673};\\\", \\\"{x:1288,y:980,t:1527009005704};\\\", \\\"{x:1288,y:979,t:1527009005721};\\\", \\\"{x:1287,y:978,t:1527009005729};\\\", \\\"{x:1286,y:977,t:1527009005745};\\\", \\\"{x:1285,y:977,t:1527009005757};\\\", \\\"{x:1284,y:977,t:1527009005784};\\\", \\\"{x:1283,y:977,t:1527009005889};\\\", \\\"{x:1282,y:977,t:1527009005969};\\\", \\\"{x:1280,y:975,t:1527009005985};\\\", \\\"{x:1280,y:974,t:1527009006001};\\\", \\\"{x:1280,y:973,t:1527009006009};\\\", \\\"{x:1280,y:972,t:1527009006024};\\\", \\\"{x:1279,y:970,t:1527009006041};\\\", \\\"{x:1279,y:969,t:1527009006057};\\\", \\\"{x:1279,y:966,t:1527009006076};\\\", \\\"{x:1279,y:965,t:1527009006090};\\\", \\\"{x:1279,y:964,t:1527009006107};\\\", \\\"{x:1279,y:963,t:1527009006136};\\\", \\\"{x:1279,y:962,t:1527009006153};\\\", \\\"{x:1279,y:961,t:1527009006176};\\\", \\\"{x:1279,y:960,t:1527009006225};\\\", \\\"{x:1279,y:959,t:1527009006297};\\\", \\\"{x:1279,y:958,t:1527009006307};\\\", \\\"{x:1280,y:957,t:1527009006324};\\\", \\\"{x:1281,y:956,t:1527009006865};\\\", \\\"{x:1281,y:954,t:1527009006945};\\\", \\\"{x:1283,y:953,t:1527009006958};\\\", \\\"{x:1283,y:952,t:1527009006975};\\\", \\\"{x:1283,y:951,t:1527009007001};\\\", \\\"{x:1283,y:950,t:1527009007017};\\\", \\\"{x:1284,y:949,t:1527009007032};\\\", \\\"{x:1284,y:948,t:1527009007041};\\\", \\\"{x:1284,y:947,t:1527009007058};\\\", \\\"{x:1285,y:946,t:1527009007075};\\\", \\\"{x:1285,y:945,t:1527009007129};\\\", \\\"{x:1285,y:944,t:1527009007153};\\\", \\\"{x:1285,y:943,t:1527009007169};\\\", \\\"{x:1285,y:942,t:1527009007193};\\\", \\\"{x:1285,y:941,t:1527009007208};\\\", \\\"{x:1285,y:940,t:1527009007241};\\\", \\\"{x:1285,y:939,t:1527009007258};\\\", \\\"{x:1285,y:938,t:1527009007275};\\\", \\\"{x:1284,y:937,t:1527009007529};\\\", \\\"{x:1283,y:937,t:1527009007545};\\\", \\\"{x:1283,y:938,t:1527009007568};\\\", \\\"{x:1282,y:938,t:1527009007577};\\\", \\\"{x:1282,y:939,t:1527009007609};\\\", \\\"{x:1281,y:939,t:1527009007833};\\\", \\\"{x:1281,y:938,t:1527009007865};\\\", \\\"{x:1281,y:936,t:1527009007880};\\\", \\\"{x:1281,y:935,t:1527009007892};\\\", \\\"{x:1281,y:934,t:1527009007909};\\\", \\\"{x:1281,y:932,t:1527009007925};\\\", \\\"{x:1281,y:930,t:1527009007945};\\\", \\\"{x:1281,y:929,t:1527009007959};\\\", \\\"{x:1281,y:928,t:1527009007975};\\\", \\\"{x:1281,y:926,t:1527009007992};\\\", \\\"{x:1280,y:924,t:1527009008009};\\\", \\\"{x:1280,y:923,t:1527009008025};\\\", \\\"{x:1280,y:920,t:1527009008042};\\\", \\\"{x:1279,y:918,t:1527009008058};\\\", \\\"{x:1279,y:917,t:1527009008075};\\\", \\\"{x:1277,y:914,t:1527009008092};\\\", \\\"{x:1277,y:912,t:1527009008109};\\\", \\\"{x:1277,y:910,t:1527009008126};\\\", \\\"{x:1276,y:907,t:1527009008142};\\\", \\\"{x:1276,y:905,t:1527009008159};\\\", \\\"{x:1276,y:903,t:1527009008176};\\\", \\\"{x:1276,y:898,t:1527009008192};\\\", \\\"{x:1276,y:891,t:1527009008208};\\\", \\\"{x:1276,y:885,t:1527009008226};\\\", \\\"{x:1275,y:879,t:1527009008242};\\\", \\\"{x:1275,y:875,t:1527009008259};\\\", \\\"{x:1273,y:870,t:1527009008276};\\\", \\\"{x:1273,y:867,t:1527009008291};\\\", \\\"{x:1273,y:863,t:1527009008309};\\\", \\\"{x:1273,y:862,t:1527009008326};\\\", \\\"{x:1272,y:860,t:1527009008342};\\\", \\\"{x:1272,y:857,t:1527009008359};\\\", \\\"{x:1272,y:855,t:1527009008376};\\\", \\\"{x:1272,y:848,t:1527009008392};\\\", \\\"{x:1272,y:842,t:1527009008409};\\\", \\\"{x:1272,y:837,t:1527009008426};\\\", \\\"{x:1272,y:834,t:1527009008442};\\\", \\\"{x:1272,y:830,t:1527009008459};\\\", \\\"{x:1272,y:822,t:1527009008477};\\\", \\\"{x:1272,y:816,t:1527009008493};\\\", \\\"{x:1272,y:810,t:1527009008509};\\\", \\\"{x:1272,y:803,t:1527009008526};\\\", \\\"{x:1272,y:796,t:1527009008543};\\\", \\\"{x:1272,y:791,t:1527009008559};\\\", \\\"{x:1272,y:784,t:1527009008576};\\\", \\\"{x:1272,y:777,t:1527009008593};\\\", \\\"{x:1270,y:769,t:1527009008609};\\\", \\\"{x:1269,y:763,t:1527009008627};\\\", \\\"{x:1269,y:757,t:1527009008643};\\\", \\\"{x:1268,y:751,t:1527009008659};\\\", \\\"{x:1268,y:748,t:1527009008676};\\\", \\\"{x:1268,y:744,t:1527009008693};\\\", \\\"{x:1268,y:739,t:1527009008709};\\\", \\\"{x:1268,y:731,t:1527009008726};\\\", \\\"{x:1268,y:722,t:1527009008743};\\\", \\\"{x:1269,y:713,t:1527009008760};\\\", \\\"{x:1270,y:701,t:1527009008776};\\\", \\\"{x:1272,y:686,t:1527009008793};\\\", \\\"{x:1275,y:676,t:1527009008809};\\\", \\\"{x:1276,y:666,t:1527009008826};\\\", \\\"{x:1277,y:657,t:1527009008843};\\\", \\\"{x:1277,y:650,t:1527009008859};\\\", \\\"{x:1277,y:643,t:1527009008876};\\\", \\\"{x:1277,y:635,t:1527009008893};\\\", \\\"{x:1277,y:630,t:1527009008910};\\\", \\\"{x:1277,y:626,t:1527009008927};\\\", \\\"{x:1277,y:620,t:1527009008943};\\\", \\\"{x:1275,y:615,t:1527009008959};\\\", \\\"{x:1274,y:609,t:1527009008976};\\\", \\\"{x:1273,y:602,t:1527009008993};\\\", \\\"{x:1270,y:597,t:1527009009010};\\\", \\\"{x:1269,y:592,t:1527009009026};\\\", \\\"{x:1269,y:590,t:1527009009043};\\\", \\\"{x:1266,y:585,t:1527009009060};\\\", \\\"{x:1266,y:582,t:1527009009076};\\\", \\\"{x:1264,y:578,t:1527009009093};\\\", \\\"{x:1264,y:577,t:1527009009110};\\\", \\\"{x:1264,y:576,t:1527009009126};\\\", \\\"{x:1264,y:573,t:1527009009143};\\\", \\\"{x:1264,y:571,t:1527009009160};\\\", \\\"{x:1264,y:570,t:1527009009176};\\\", \\\"{x:1263,y:569,t:1527009009223};\\\", \\\"{x:1256,y:569,t:1527009009240};\\\", \\\"{x:1246,y:568,t:1527009009247};\\\", \\\"{x:1232,y:568,t:1527009009259};\\\", \\\"{x:1160,y:573,t:1527009009275};\\\", \\\"{x:1047,y:604,t:1527009009293};\\\", \\\"{x:930,y:637,t:1527009009309};\\\", \\\"{x:817,y:670,t:1527009009326};\\\", \\\"{x:725,y:697,t:1527009009343};\\\", \\\"{x:674,y:709,t:1527009009359};\\\", \\\"{x:649,y:717,t:1527009009376};\\\", \\\"{x:635,y:722,t:1527009009393};\\\", \\\"{x:628,y:728,t:1527009009410};\\\", \\\"{x:623,y:734,t:1527009009425};\\\", \\\"{x:617,y:740,t:1527009009443};\\\", \\\"{x:609,y:750,t:1527009009459};\\\", \\\"{x:596,y:761,t:1527009009477};\\\", \\\"{x:588,y:766,t:1527009009493};\\\", \\\"{x:582,y:769,t:1527009009510};\\\", \\\"{x:578,y:770,t:1527009009527};\\\", \\\"{x:576,y:770,t:1527009009543};\\\", \\\"{x:562,y:752,t:1527009009560};\\\", \\\"{x:547,y:729,t:1527009009578};\\\", \\\"{x:534,y:718,t:1527009009592};\\\", \\\"{x:522,y:711,t:1527009009609};\\\", \\\"{x:516,y:709,t:1527009009626};\\\", \\\"{x:514,y:707,t:1527009009643};\\\", \\\"{x:513,y:708,t:1527009009808};\\\", \\\"{x:513,y:709,t:1527009009815};\\\", \\\"{x:514,y:711,t:1527009009826};\\\", \\\"{x:515,y:717,t:1527009009843};\\\", \\\"{x:517,y:723,t:1527009009859};\\\", \\\"{x:517,y:727,t:1527009009877};\\\", \\\"{x:518,y:728,t:1527009009893};\\\", \\\"{x:518,y:729,t:1527009009969};\\\", \\\"{x:517,y:729,t:1527009010105};\\\", \\\"{x:516,y:729,t:1527009010113};\\\", \\\"{x:515,y:729,t:1527009010126};\\\", \\\"{x:514,y:729,t:1527009010201};\\\", \\\"{x:514,y:728,t:1527009010210};\\\", \\\"{x:514,y:726,t:1527009010227};\\\", \\\"{x:514,y:724,t:1527009010244};\\\", \\\"{x:514,y:722,t:1527009010260};\\\", \\\"{x:514,y:721,t:1527009010277};\\\", \\\"{x:513,y:719,t:1527009010294};\\\", \\\"{x:512,y:718,t:1527009010311};\\\", \\\"{x:511,y:718,t:1527009011009};\\\", \\\"{x:512,y:716,t:1527009011016};\\\", \\\"{x:515,y:716,t:1527009011027};\\\", \\\"{x:527,y:714,t:1527009011043};\\\", \\\"{x:539,y:710,t:1527009011060};\\\", \\\"{x:560,y:705,t:1527009011077};\\\", \\\"{x:583,y:699,t:1527009011094};\\\", \\\"{x:614,y:687,t:1527009011110};\\\", \\\"{x:657,y:664,t:1527009011128};\\\", \\\"{x:716,y:640,t:1527009011144};\\\", \\\"{x:743,y:628,t:1527009011161};\\\", \\\"{x:760,y:619,t:1527009011177};\\\", \\\"{x:766,y:617,t:1527009011194};\\\", \\\"{x:771,y:614,t:1527009011210};\\\", \\\"{x:774,y:613,t:1527009011227};\\\", \\\"{x:776,y:612,t:1527009011245};\\\", \\\"{x:778,y:611,t:1527009011261};\\\", \\\"{x:779,y:610,t:1527009011278};\\\" ] }, { \\\"rt\\\": 52954, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 6, \\\"time_elapsed\\\": 239172, \\\"internal_node_id\\\": \\\"0.0-5.0-1.0\\\", \\\"subject\\\": \\\"38NFJ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"echo\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 2, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"O\\\", \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-11 AM-10 AM-D -04 PM\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:780,y:610,t:1527009012617};\\\", \\\"{x:777,y:610,t:1527009012629};\\\", \\\"{x:754,y:610,t:1527009012645};\\\", \\\"{x:732,y:610,t:1527009012662};\\\", \\\"{x:709,y:610,t:1527009012681};\\\", \\\"{x:679,y:610,t:1527009012695};\\\", \\\"{x:671,y:610,t:1527009012711};\\\", \\\"{x:668,y:610,t:1527009012728};\\\", \\\"{x:668,y:611,t:1527009012767};\\\", \\\"{x:668,y:614,t:1527009012779};\\\", \\\"{x:670,y:618,t:1527009012795};\\\", \\\"{x:703,y:627,t:1527009012812};\\\", \\\"{x:814,y:645,t:1527009012828};\\\", \\\"{x:975,y:670,t:1527009012845};\\\", \\\"{x:1149,y:694,t:1527009012862};\\\", \\\"{x:1318,y:721,t:1527009012879};\\\", \\\"{x:1500,y:731,t:1527009012896};\\\", \\\"{x:1559,y:723,t:1527009012912};\\\", \\\"{x:1597,y:713,t:1527009012928};\\\", \\\"{x:1615,y:710,t:1527009012946};\\\", \\\"{x:1620,y:709,t:1527009012963};\\\", \\\"{x:1620,y:710,t:1527009013032};\\\", \\\"{x:1616,y:715,t:1527009013046};\\\", \\\"{x:1597,y:730,t:1527009013063};\\\", \\\"{x:1576,y:743,t:1527009013080};\\\", \\\"{x:1547,y:753,t:1527009013095};\\\", \\\"{x:1505,y:773,t:1527009013113};\\\", \\\"{x:1477,y:785,t:1527009013130};\\\", \\\"{x:1454,y:796,t:1527009013146};\\\", \\\"{x:1438,y:807,t:1527009013162};\\\", \\\"{x:1427,y:814,t:1527009013180};\\\", \\\"{x:1418,y:818,t:1527009013196};\\\", \\\"{x:1411,y:822,t:1527009013213};\\\", \\\"{x:1405,y:824,t:1527009013230};\\\", \\\"{x:1402,y:826,t:1527009013246};\\\", \\\"{x:1398,y:827,t:1527009013263};\\\", \\\"{x:1393,y:828,t:1527009013280};\\\", \\\"{x:1387,y:829,t:1527009013296};\\\", \\\"{x:1374,y:830,t:1527009013313};\\\", \\\"{x:1365,y:831,t:1527009013330};\\\", \\\"{x:1356,y:831,t:1527009013347};\\\", \\\"{x:1347,y:831,t:1527009013363};\\\", \\\"{x:1341,y:831,t:1527009013380};\\\", \\\"{x:1336,y:831,t:1527009013397};\\\", \\\"{x:1333,y:831,t:1527009013413};\\\", \\\"{x:1329,y:831,t:1527009013430};\\\", \\\"{x:1325,y:831,t:1527009013447};\\\", \\\"{x:1318,y:831,t:1527009013463};\\\", \\\"{x:1306,y:831,t:1527009013480};\\\", \\\"{x:1287,y:825,t:1527009013497};\\\", \\\"{x:1276,y:821,t:1527009013513};\\\", \\\"{x:1260,y:813,t:1527009013530};\\\", \\\"{x:1250,y:808,t:1527009013547};\\\", \\\"{x:1243,y:801,t:1527009013563};\\\", \\\"{x:1235,y:791,t:1527009013580};\\\", \\\"{x:1229,y:779,t:1527009013597};\\\", \\\"{x:1225,y:768,t:1527009013613};\\\", \\\"{x:1224,y:761,t:1527009013630};\\\", \\\"{x:1223,y:756,t:1527009013647};\\\", \\\"{x:1223,y:745,t:1527009013664};\\\", \\\"{x:1223,y:739,t:1527009013680};\\\", \\\"{x:1226,y:727,t:1527009013697};\\\", \\\"{x:1229,y:718,t:1527009013714};\\\", \\\"{x:1229,y:714,t:1527009013730};\\\", \\\"{x:1230,y:711,t:1527009013747};\\\", \\\"{x:1231,y:707,t:1527009013764};\\\", \\\"{x:1232,y:705,t:1527009013784};\\\", \\\"{x:1233,y:703,t:1527009013800};\\\", \\\"{x:1233,y:702,t:1527009013814};\\\", \\\"{x:1235,y:699,t:1527009013830};\\\", \\\"{x:1235,y:698,t:1527009013847};\\\", \\\"{x:1236,y:698,t:1527009013863};\\\", \\\"{x:1236,y:697,t:1527009013880};\\\", \\\"{x:1238,y:697,t:1527009013904};\\\", \\\"{x:1239,y:697,t:1527009013914};\\\", \\\"{x:1242,y:697,t:1527009013931};\\\", \\\"{x:1246,y:697,t:1527009013947};\\\", \\\"{x:1251,y:700,t:1527009013964};\\\", \\\"{x:1256,y:706,t:1527009013980};\\\", \\\"{x:1264,y:717,t:1527009013997};\\\", \\\"{x:1268,y:725,t:1527009014014};\\\", \\\"{x:1272,y:731,t:1527009014031};\\\", \\\"{x:1274,y:734,t:1527009014047};\\\", \\\"{x:1278,y:740,t:1527009014064};\\\", \\\"{x:1284,y:750,t:1527009014080};\\\", \\\"{x:1289,y:761,t:1527009014097};\\\", \\\"{x:1293,y:772,t:1527009014114};\\\", \\\"{x:1297,y:783,t:1527009014130};\\\", \\\"{x:1299,y:789,t:1527009014147};\\\", \\\"{x:1302,y:795,t:1527009014164};\\\", \\\"{x:1303,y:799,t:1527009014181};\\\", \\\"{x:1308,y:810,t:1527009014198};\\\", \\\"{x:1316,y:826,t:1527009014214};\\\", \\\"{x:1324,y:844,t:1527009014231};\\\", \\\"{x:1334,y:873,t:1527009014249};\\\", \\\"{x:1339,y:889,t:1527009014264};\\\", \\\"{x:1346,y:903,t:1527009014281};\\\", \\\"{x:1348,y:913,t:1527009014298};\\\", \\\"{x:1348,y:920,t:1527009014314};\\\", \\\"{x:1348,y:928,t:1527009014331};\\\", \\\"{x:1348,y:935,t:1527009014348};\\\", \\\"{x:1344,y:944,t:1527009014363};\\\", \\\"{x:1339,y:951,t:1527009014381};\\\", \\\"{x:1335,y:956,t:1527009014398};\\\", \\\"{x:1330,y:960,t:1527009014414};\\\", \\\"{x:1324,y:964,t:1527009014431};\\\", \\\"{x:1313,y:970,t:1527009014449};\\\", \\\"{x:1304,y:973,t:1527009014465};\\\", \\\"{x:1297,y:976,t:1527009014481};\\\", \\\"{x:1290,y:978,t:1527009014497};\\\", \\\"{x:1280,y:980,t:1527009014515};\\\", \\\"{x:1275,y:983,t:1527009014531};\\\", \\\"{x:1271,y:984,t:1527009014548};\\\", \\\"{x:1268,y:984,t:1527009014565};\\\", \\\"{x:1265,y:986,t:1527009014582};\\\", \\\"{x:1261,y:986,t:1527009014598};\\\", \\\"{x:1256,y:987,t:1527009014615};\\\", \\\"{x:1251,y:987,t:1527009014631};\\\", \\\"{x:1241,y:987,t:1527009014649};\\\", \\\"{x:1237,y:985,t:1527009014664};\\\", \\\"{x:1234,y:983,t:1527009014681};\\\", \\\"{x:1233,y:981,t:1527009014698};\\\", \\\"{x:1233,y:976,t:1527009014715};\\\", \\\"{x:1233,y:972,t:1527009014732};\\\", \\\"{x:1233,y:967,t:1527009014748};\\\", \\\"{x:1233,y:965,t:1527009014765};\\\", \\\"{x:1233,y:961,t:1527009014782};\\\", \\\"{x:1233,y:955,t:1527009014798};\\\", \\\"{x:1236,y:949,t:1527009014815};\\\", \\\"{x:1239,y:942,t:1527009014833};\\\", \\\"{x:1241,y:939,t:1527009014848};\\\", \\\"{x:1243,y:934,t:1527009014865};\\\", \\\"{x:1247,y:930,t:1527009014882};\\\", \\\"{x:1248,y:928,t:1527009014898};\\\", \\\"{x:1252,y:923,t:1527009014915};\\\", \\\"{x:1256,y:919,t:1527009014932};\\\", \\\"{x:1262,y:906,t:1527009014948};\\\", \\\"{x:1269,y:894,t:1527009014965};\\\", \\\"{x:1276,y:883,t:1527009014982};\\\", \\\"{x:1281,y:871,t:1527009014999};\\\", \\\"{x:1285,y:860,t:1527009015015};\\\", \\\"{x:1290,y:842,t:1527009015032};\\\", \\\"{x:1292,y:833,t:1527009015048};\\\", \\\"{x:1293,y:821,t:1527009015065};\\\", \\\"{x:1295,y:808,t:1527009015082};\\\", \\\"{x:1297,y:794,t:1527009015099};\\\", \\\"{x:1300,y:781,t:1527009015115};\\\", \\\"{x:1303,y:773,t:1527009015132};\\\", \\\"{x:1305,y:768,t:1527009015149};\\\", \\\"{x:1305,y:762,t:1527009015165};\\\", \\\"{x:1305,y:757,t:1527009015182};\\\", \\\"{x:1305,y:753,t:1527009015199};\\\", \\\"{x:1305,y:747,t:1527009015215};\\\", \\\"{x:1305,y:738,t:1527009015232};\\\", \\\"{x:1305,y:735,t:1527009015249};\\\", \\\"{x:1305,y:726,t:1527009015266};\\\", \\\"{x:1302,y:723,t:1527009015282};\\\", \\\"{x:1299,y:719,t:1527009015299};\\\", \\\"{x:1298,y:716,t:1527009015316};\\\", \\\"{x:1296,y:714,t:1527009015332};\\\", \\\"{x:1293,y:711,t:1527009015349};\\\", \\\"{x:1292,y:709,t:1527009015366};\\\", \\\"{x:1290,y:705,t:1527009015382};\\\", \\\"{x:1288,y:701,t:1527009015399};\\\", \\\"{x:1286,y:693,t:1527009015416};\\\", \\\"{x:1285,y:690,t:1527009015432};\\\", \\\"{x:1285,y:687,t:1527009015449};\\\", \\\"{x:1284,y:684,t:1527009015466};\\\", \\\"{x:1284,y:681,t:1527009015482};\\\", \\\"{x:1284,y:672,t:1527009015499};\\\", \\\"{x:1288,y:659,t:1527009015516};\\\", \\\"{x:1292,y:650,t:1527009015533};\\\", \\\"{x:1297,y:640,t:1527009015549};\\\", \\\"{x:1305,y:629,t:1527009015565};\\\", \\\"{x:1312,y:621,t:1527009015583};\\\", \\\"{x:1320,y:611,t:1527009015599};\\\", \\\"{x:1326,y:603,t:1527009015615};\\\", \\\"{x:1330,y:599,t:1527009015632};\\\", \\\"{x:1332,y:592,t:1527009015648};\\\", \\\"{x:1335,y:586,t:1527009015665};\\\", \\\"{x:1340,y:581,t:1527009015683};\\\", \\\"{x:1347,y:572,t:1527009015698};\\\", \\\"{x:1353,y:566,t:1527009015716};\\\", \\\"{x:1361,y:559,t:1527009015733};\\\", \\\"{x:1374,y:551,t:1527009015749};\\\", \\\"{x:1389,y:543,t:1527009015766};\\\", \\\"{x:1413,y:532,t:1527009015782};\\\", \\\"{x:1436,y:526,t:1527009015799};\\\", \\\"{x:1473,y:511,t:1527009015816};\\\", \\\"{x:1494,y:505,t:1527009015832};\\\", \\\"{x:1516,y:499,t:1527009015850};\\\", \\\"{x:1540,y:493,t:1527009015866};\\\", \\\"{x:1564,y:483,t:1527009015882};\\\", \\\"{x:1581,y:475,t:1527009015899};\\\", \\\"{x:1599,y:465,t:1527009015916};\\\", \\\"{x:1612,y:459,t:1527009015933};\\\", \\\"{x:1619,y:456,t:1527009015950};\\\", \\\"{x:1627,y:452,t:1527009015966};\\\", \\\"{x:1628,y:452,t:1527009015984};\\\", \\\"{x:1629,y:451,t:1527009016000};\\\", \\\"{x:1629,y:450,t:1527009016033};\\\", \\\"{x:1629,y:447,t:1527009016050};\\\", \\\"{x:1630,y:446,t:1527009016067};\\\", \\\"{x:1630,y:444,t:1527009016083};\\\", \\\"{x:1630,y:443,t:1527009016100};\\\", \\\"{x:1630,y:442,t:1527009016145};\\\", \\\"{x:1630,y:441,t:1527009016152};\\\", \\\"{x:1630,y:440,t:1527009016167};\\\", \\\"{x:1629,y:439,t:1527009016184};\\\", \\\"{x:1628,y:438,t:1527009016200};\\\", \\\"{x:1627,y:438,t:1527009016217};\\\", \\\"{x:1625,y:438,t:1527009016233};\\\", \\\"{x:1624,y:437,t:1527009016250};\\\", \\\"{x:1623,y:437,t:1527009016272};\\\", \\\"{x:1622,y:437,t:1527009016304};\\\", \\\"{x:1621,y:437,t:1527009016320};\\\", \\\"{x:1620,y:437,t:1527009016345};\\\", \\\"{x:1618,y:437,t:1527009016353};\\\", \\\"{x:1617,y:437,t:1527009016368};\\\", \\\"{x:1616,y:437,t:1527009018329};\\\", \\\"{x:1614,y:442,t:1527009023137};\\\", \\\"{x:1605,y:446,t:1527009023145};\\\", \\\"{x:1596,y:453,t:1527009023160};\\\", \\\"{x:1575,y:465,t:1527009023175};\\\", \\\"{x:1528,y:488,t:1527009023192};\\\", \\\"{x:1470,y:514,t:1527009023209};\\\", \\\"{x:1406,y:542,t:1527009023225};\\\", \\\"{x:1346,y:568,t:1527009023242};\\\", \\\"{x:1286,y:602,t:1527009023260};\\\", \\\"{x:1238,y:635,t:1527009023275};\\\", \\\"{x:1202,y:666,t:1527009023292};\\\", \\\"{x:1170,y:700,t:1527009023309};\\\", \\\"{x:1141,y:733,t:1527009023327};\\\", \\\"{x:1109,y:765,t:1527009023343};\\\", \\\"{x:1070,y:800,t:1527009023359};\\\", \\\"{x:995,y:859,t:1527009023376};\\\", \\\"{x:947,y:885,t:1527009023392};\\\", \\\"{x:907,y:897,t:1527009023409};\\\", \\\"{x:881,y:902,t:1527009023426};\\\", \\\"{x:856,y:905,t:1527009023442};\\\", \\\"{x:841,y:905,t:1527009023459};\\\", \\\"{x:835,y:905,t:1527009023476};\\\", \\\"{x:829,y:902,t:1527009023492};\\\", \\\"{x:814,y:901,t:1527009023509};\\\", \\\"{x:796,y:900,t:1527009023526};\\\", \\\"{x:774,y:896,t:1527009023543};\\\", \\\"{x:747,y:890,t:1527009023559};\\\", \\\"{x:714,y:875,t:1527009023576};\\\", \\\"{x:699,y:868,t:1527009023592};\\\", \\\"{x:689,y:863,t:1527009023610};\\\", \\\"{x:683,y:859,t:1527009023626};\\\", \\\"{x:680,y:858,t:1527009023644};\\\", \\\"{x:675,y:857,t:1527009023659};\\\", \\\"{x:674,y:857,t:1527009023680};\\\", \\\"{x:674,y:856,t:1527009023777};\\\", \\\"{x:684,y:855,t:1527009023793};\\\", \\\"{x:691,y:855,t:1527009023809};\\\", \\\"{x:695,y:855,t:1527009023826};\\\", \\\"{x:696,y:855,t:1527009023843};\\\", \\\"{x:697,y:854,t:1527009024041};\\\", \\\"{x:697,y:850,t:1527009024048};\\\", \\\"{x:697,y:841,t:1527009024060};\\\", \\\"{x:697,y:830,t:1527009024076};\\\", \\\"{x:697,y:826,t:1527009024093};\\\", \\\"{x:697,y:825,t:1527009024112};\\\", \\\"{x:697,y:824,t:1527009024127};\\\", \\\"{x:701,y:808,t:1527009024145};\\\", \\\"{x:707,y:799,t:1527009024160};\\\", \\\"{x:711,y:792,t:1527009024178};\\\", \\\"{x:718,y:785,t:1527009024193};\\\", \\\"{x:726,y:770,t:1527009024210};\\\", \\\"{x:730,y:748,t:1527009024227};\\\", \\\"{x:737,y:721,t:1527009024243};\\\", \\\"{x:744,y:698,t:1527009024260};\\\", \\\"{x:756,y:670,t:1527009024277};\\\", \\\"{x:768,y:649,t:1527009024293};\\\", \\\"{x:778,y:631,t:1527009024310};\\\", \\\"{x:790,y:615,t:1527009024327};\\\", \\\"{x:808,y:594,t:1527009024346};\\\", \\\"{x:819,y:582,t:1527009024360};\\\", \\\"{x:830,y:572,t:1527009024378};\\\", \\\"{x:850,y:558,t:1527009024401};\\\", \\\"{x:856,y:552,t:1527009024418};\\\", \\\"{x:865,y:544,t:1527009024435};\\\", \\\"{x:873,y:533,t:1527009024451};\\\", \\\"{x:881,y:518,t:1527009024471};\\\", \\\"{x:898,y:491,t:1527009024487};\\\", \\\"{x:909,y:474,t:1527009024505};\\\", \\\"{x:920,y:457,t:1527009024521};\\\", \\\"{x:925,y:449,t:1527009024538};\\\", \\\"{x:927,y:447,t:1527009024554};\\\", \\\"{x:930,y:447,t:1527009024897};\\\", \\\"{x:937,y:447,t:1527009024904};\\\", \\\"{x:966,y:448,t:1527009024920};\\\", \\\"{x:1000,y:467,t:1527009024938};\\\", \\\"{x:1047,y:508,t:1527009024953};\\\", \\\"{x:1118,y:565,t:1527009024970};\\\", \\\"{x:1216,y:618,t:1527009024987};\\\", \\\"{x:1307,y:658,t:1527009025003};\\\", \\\"{x:1395,y:679,t:1527009025020};\\\", \\\"{x:1463,y:695,t:1527009025037};\\\", \\\"{x:1529,y:708,t:1527009025053};\\\", \\\"{x:1617,y:733,t:1527009025070};\\\", \\\"{x:1691,y:761,t:1527009025087};\\\", \\\"{x:1730,y:780,t:1527009025103};\\\", \\\"{x:1752,y:796,t:1527009025120};\\\", \\\"{x:1756,y:806,t:1527009025136};\\\", \\\"{x:1758,y:819,t:1527009025153};\\\", \\\"{x:1758,y:825,t:1527009025170};\\\", \\\"{x:1756,y:829,t:1527009025186};\\\", \\\"{x:1752,y:832,t:1527009025203};\\\", \\\"{x:1747,y:835,t:1527009025220};\\\", \\\"{x:1743,y:835,t:1527009025237};\\\", \\\"{x:1737,y:835,t:1527009025254};\\\", \\\"{x:1734,y:835,t:1527009025269};\\\", \\\"{x:1727,y:829,t:1527009025287};\\\", \\\"{x:1717,y:807,t:1527009025304};\\\", \\\"{x:1701,y:768,t:1527009025319};\\\", \\\"{x:1670,y:697,t:1527009025336};\\\", \\\"{x:1642,y:648,t:1527009025352};\\\", \\\"{x:1611,y:591,t:1527009025369};\\\", \\\"{x:1583,y:547,t:1527009025386};\\\", \\\"{x:1573,y:527,t:1527009025403};\\\", \\\"{x:1570,y:520,t:1527009025419};\\\", \\\"{x:1568,y:514,t:1527009025436};\\\", \\\"{x:1567,y:506,t:1527009025452};\\\", \\\"{x:1566,y:500,t:1527009025469};\\\", \\\"{x:1566,y:499,t:1527009025485};\\\", \\\"{x:1566,y:497,t:1527009025503};\\\", \\\"{x:1566,y:496,t:1527009025520};\\\", \\\"{x:1566,y:494,t:1527009025535};\\\", \\\"{x:1568,y:487,t:1527009025552};\\\", \\\"{x:1571,y:485,t:1527009025569};\\\", \\\"{x:1575,y:481,t:1527009025585};\\\", \\\"{x:1580,y:474,t:1527009025602};\\\", \\\"{x:1584,y:470,t:1527009025618};\\\", \\\"{x:1587,y:466,t:1527009025636};\\\", \\\"{x:1593,y:461,t:1527009025652};\\\", \\\"{x:1601,y:456,t:1527009025669};\\\", \\\"{x:1606,y:451,t:1527009025686};\\\", \\\"{x:1611,y:447,t:1527009025702};\\\", \\\"{x:1614,y:445,t:1527009025719};\\\", \\\"{x:1615,y:443,t:1527009025736};\\\", \\\"{x:1615,y:442,t:1527009025751};\\\", \\\"{x:1616,y:442,t:1527009025808};\\\", \\\"{x:1616,y:441,t:1527009025819};\\\", \\\"{x:1617,y:440,t:1527009025835};\\\", \\\"{x:1617,y:439,t:1527009025873};\\\", \\\"{x:1617,y:438,t:1527009025945};\\\", \\\"{x:1617,y:437,t:1527009025952};\\\", \\\"{x:1617,y:435,t:1527009025979};\\\", \\\"{x:1617,y:434,t:1527009026088};\\\", \\\"{x:1617,y:432,t:1527009026200};\\\", \\\"{x:1617,y:431,t:1527009026240};\\\", \\\"{x:1617,y:430,t:1527009027496};\\\", \\\"{x:1616,y:429,t:1527009027817};\\\", \\\"{x:1615,y:429,t:1527009028377};\\\", \\\"{x:1614,y:429,t:1527009028472};\\\", \\\"{x:1613,y:429,t:1527009028504};\\\", \\\"{x:1613,y:430,t:1527009028568};\\\", \\\"{x:1613,y:431,t:1527009028577};\\\", \\\"{x:1613,y:432,t:1527009028594};\\\", \\\"{x:1614,y:435,t:1527009028612};\\\", \\\"{x:1614,y:436,t:1527009028641};\\\", \\\"{x:1614,y:438,t:1527009028664};\\\", \\\"{x:1616,y:441,t:1527009028678};\\\", \\\"{x:1617,y:445,t:1527009028695};\\\", \\\"{x:1618,y:451,t:1527009028710};\\\", \\\"{x:1620,y:455,t:1527009028728};\\\", \\\"{x:1621,y:457,t:1527009028745};\\\", \\\"{x:1621,y:459,t:1527009028760};\\\", \\\"{x:1621,y:460,t:1527009028777};\\\", \\\"{x:1621,y:466,t:1527009028793};\\\", \\\"{x:1622,y:473,t:1527009028810};\\\", \\\"{x:1625,y:483,t:1527009028827};\\\", \\\"{x:1626,y:492,t:1527009028843};\\\", \\\"{x:1626,y:502,t:1527009028861};\\\", \\\"{x:1628,y:509,t:1527009028877};\\\", \\\"{x:1629,y:515,t:1527009028893};\\\", \\\"{x:1629,y:523,t:1527009028910};\\\", \\\"{x:1629,y:532,t:1527009028926};\\\", \\\"{x:1629,y:550,t:1527009028945};\\\", \\\"{x:1629,y:557,t:1527009028960};\\\", \\\"{x:1629,y:564,t:1527009028976};\\\", \\\"{x:1629,y:568,t:1527009028994};\\\", \\\"{x:1629,y:571,t:1527009029011};\\\", \\\"{x:1629,y:575,t:1527009029027};\\\", \\\"{x:1629,y:579,t:1527009029044};\\\", \\\"{x:1629,y:582,t:1527009029059};\\\", \\\"{x:1629,y:584,t:1527009029077};\\\", \\\"{x:1629,y:586,t:1527009029094};\\\", \\\"{x:1629,y:588,t:1527009029110};\\\", \\\"{x:1629,y:589,t:1527009029127};\\\", \\\"{x:1629,y:592,t:1527009029145};\\\", \\\"{x:1629,y:594,t:1527009029160};\\\", \\\"{x:1628,y:596,t:1527009029177};\\\", \\\"{x:1627,y:600,t:1527009029193};\\\", \\\"{x:1624,y:605,t:1527009029210};\\\", \\\"{x:1624,y:608,t:1527009029226};\\\", \\\"{x:1622,y:610,t:1527009029243};\\\", \\\"{x:1621,y:613,t:1527009029259};\\\", \\\"{x:1620,y:616,t:1527009029276};\\\", \\\"{x:1619,y:618,t:1527009029293};\\\", \\\"{x:1618,y:620,t:1527009029310};\\\", \\\"{x:1617,y:626,t:1527009029326};\\\", \\\"{x:1614,y:630,t:1527009029343};\\\", \\\"{x:1614,y:633,t:1527009029360};\\\", \\\"{x:1613,y:634,t:1527009029376};\\\", \\\"{x:1613,y:636,t:1527009029392};\\\", \\\"{x:1612,y:637,t:1527009029409};\\\", \\\"{x:1611,y:640,t:1527009029425};\\\", \\\"{x:1611,y:641,t:1527009029442};\\\", \\\"{x:1611,y:644,t:1527009029459};\\\", \\\"{x:1611,y:647,t:1527009029475};\\\", \\\"{x:1611,y:651,t:1527009029492};\\\", \\\"{x:1611,y:655,t:1527009029509};\\\", \\\"{x:1611,y:658,t:1527009029525};\\\", \\\"{x:1611,y:662,t:1527009029541};\\\", \\\"{x:1611,y:664,t:1527009029559};\\\", \\\"{x:1611,y:668,t:1527009029576};\\\", \\\"{x:1611,y:671,t:1527009029593};\\\", \\\"{x:1611,y:672,t:1527009029608};\\\", \\\"{x:1612,y:674,t:1527009029626};\\\", \\\"{x:1612,y:675,t:1527009029642};\\\", \\\"{x:1612,y:676,t:1527009029658};\\\", \\\"{x:1612,y:677,t:1527009029680};\\\", \\\"{x:1612,y:678,t:1527009029696};\\\", \\\"{x:1612,y:679,t:1527009029728};\\\", \\\"{x:1612,y:680,t:1527009029741};\\\", \\\"{x:1612,y:681,t:1527009029760};\\\", \\\"{x:1612,y:680,t:1527009029896};\\\", \\\"{x:1612,y:672,t:1527009029907};\\\", \\\"{x:1617,y:651,t:1527009029925};\\\", \\\"{x:1623,y:618,t:1527009029940};\\\", \\\"{x:1626,y:569,t:1527009029958};\\\", \\\"{x:1626,y:527,t:1527009029974};\\\", \\\"{x:1629,y:502,t:1527009029991};\\\", \\\"{x:1630,y:484,t:1527009030008};\\\", \\\"{x:1630,y:468,t:1527009030024};\\\", \\\"{x:1630,y:462,t:1527009030041};\\\", \\\"{x:1630,y:459,t:1527009030058};\\\", \\\"{x:1629,y:455,t:1527009030074};\\\", \\\"{x:1629,y:452,t:1527009030090};\\\", \\\"{x:1629,y:448,t:1527009030107};\\\", \\\"{x:1629,y:445,t:1527009030124};\\\", \\\"{x:1628,y:443,t:1527009030141};\\\", \\\"{x:1628,y:442,t:1527009030158};\\\", \\\"{x:1628,y:441,t:1527009030216};\\\", \\\"{x:1627,y:441,t:1527009030224};\\\", \\\"{x:1626,y:441,t:1527009030240};\\\", \\\"{x:1624,y:441,t:1527009030256};\\\", \\\"{x:1621,y:441,t:1527009030274};\\\", \\\"{x:1616,y:441,t:1527009030291};\\\", \\\"{x:1614,y:441,t:1527009030307};\\\", \\\"{x:1612,y:441,t:1527009030324};\\\", \\\"{x:1611,y:442,t:1527009030383};\\\", \\\"{x:1611,y:443,t:1527009030407};\\\", \\\"{x:1611,y:444,t:1527009030423};\\\", \\\"{x:1611,y:446,t:1527009030439};\\\", \\\"{x:1610,y:450,t:1527009030456};\\\", \\\"{x:1610,y:454,t:1527009030472};\\\", \\\"{x:1610,y:457,t:1527009030489};\\\", \\\"{x:1610,y:461,t:1527009030506};\\\", \\\"{x:1610,y:465,t:1527009030522};\\\", \\\"{x:1610,y:469,t:1527009030539};\\\", \\\"{x:1610,y:472,t:1527009030556};\\\", \\\"{x:1610,y:478,t:1527009030573};\\\", \\\"{x:1610,y:483,t:1527009030589};\\\", \\\"{x:1610,y:487,t:1527009030606};\\\", \\\"{x:1610,y:491,t:1527009030623};\\\", \\\"{x:1610,y:499,t:1527009030640};\\\", \\\"{x:1610,y:501,t:1527009030655};\\\", \\\"{x:1610,y:508,t:1527009030672};\\\", \\\"{x:1610,y:512,t:1527009030690};\\\", \\\"{x:1610,y:517,t:1527009030705};\\\", \\\"{x:1610,y:521,t:1527009030722};\\\", \\\"{x:1610,y:524,t:1527009030739};\\\", \\\"{x:1610,y:527,t:1527009030756};\\\", \\\"{x:1611,y:531,t:1527009030773};\\\", \\\"{x:1611,y:537,t:1527009030788};\\\", \\\"{x:1613,y:542,t:1527009030806};\\\", \\\"{x:1614,y:548,t:1527009030822};\\\", \\\"{x:1614,y:554,t:1527009030839};\\\", \\\"{x:1617,y:559,t:1527009030856};\\\", \\\"{x:1617,y:564,t:1527009030872};\\\", \\\"{x:1618,y:568,t:1527009030888};\\\", \\\"{x:1618,y:573,t:1527009030906};\\\", \\\"{x:1619,y:576,t:1527009030922};\\\", \\\"{x:1619,y:582,t:1527009030938};\\\", \\\"{x:1620,y:586,t:1527009030955};\\\", \\\"{x:1621,y:591,t:1527009030971};\\\", \\\"{x:1622,y:597,t:1527009030989};\\\", \\\"{x:1622,y:601,t:1527009031004};\\\", \\\"{x:1623,y:606,t:1527009031022};\\\", \\\"{x:1624,y:609,t:1527009031039};\\\", \\\"{x:1624,y:613,t:1527009031054};\\\", \\\"{x:1625,y:617,t:1527009031072};\\\", \\\"{x:1626,y:625,t:1527009031088};\\\", \\\"{x:1626,y:629,t:1527009031104};\\\", \\\"{x:1626,y:632,t:1527009031122};\\\", \\\"{x:1628,y:637,t:1527009031138};\\\", \\\"{x:1628,y:641,t:1527009031155};\\\", \\\"{x:1629,y:645,t:1527009031171};\\\", \\\"{x:1629,y:650,t:1527009031187};\\\", \\\"{x:1629,y:656,t:1527009031205};\\\", \\\"{x:1630,y:661,t:1527009031220};\\\", \\\"{x:1630,y:669,t:1527009031237};\\\", \\\"{x:1630,y:673,t:1527009031254};\\\", \\\"{x:1630,y:677,t:1527009031270};\\\", \\\"{x:1630,y:682,t:1527009031288};\\\", \\\"{x:1630,y:684,t:1527009031304};\\\", \\\"{x:1632,y:689,t:1527009031321};\\\", \\\"{x:1632,y:694,t:1527009031338};\\\", \\\"{x:1632,y:699,t:1527009031354};\\\", \\\"{x:1632,y:706,t:1527009031371};\\\", \\\"{x:1632,y:714,t:1527009031387};\\\", \\\"{x:1632,y:719,t:1527009031404};\\\", \\\"{x:1632,y:725,t:1527009031421};\\\", \\\"{x:1632,y:729,t:1527009031437};\\\", \\\"{x:1632,y:733,t:1527009031454};\\\", \\\"{x:1632,y:736,t:1527009031470};\\\", \\\"{x:1632,y:741,t:1527009031486};\\\", \\\"{x:1632,y:746,t:1527009031504};\\\", \\\"{x:1632,y:751,t:1527009031520};\\\", \\\"{x:1631,y:755,t:1527009031536};\\\", \\\"{x:1631,y:761,t:1527009031553};\\\", \\\"{x:1631,y:765,t:1527009031570};\\\", \\\"{x:1629,y:770,t:1527009031586};\\\", \\\"{x:1629,y:776,t:1527009031603};\\\", \\\"{x:1628,y:780,t:1527009031620};\\\", \\\"{x:1628,y:785,t:1527009031636};\\\", \\\"{x:1628,y:788,t:1527009031653};\\\", \\\"{x:1627,y:793,t:1527009031669};\\\", \\\"{x:1625,y:796,t:1527009031686};\\\", \\\"{x:1625,y:801,t:1527009031703};\\\", \\\"{x:1625,y:804,t:1527009031719};\\\", \\\"{x:1625,y:806,t:1527009031736};\\\", \\\"{x:1624,y:808,t:1527009031753};\\\", \\\"{x:1624,y:809,t:1527009031769};\\\", \\\"{x:1624,y:811,t:1527009031787};\\\", \\\"{x:1624,y:813,t:1527009031802};\\\", \\\"{x:1623,y:816,t:1527009031819};\\\", \\\"{x:1622,y:820,t:1527009031835};\\\", \\\"{x:1622,y:825,t:1527009031853};\\\", \\\"{x:1621,y:828,t:1527009031869};\\\", \\\"{x:1621,y:832,t:1527009031886};\\\", \\\"{x:1621,y:836,t:1527009031903};\\\", \\\"{x:1621,y:844,t:1527009031920};\\\", \\\"{x:1620,y:851,t:1527009031936};\\\", \\\"{x:1620,y:856,t:1527009031953};\\\", \\\"{x:1620,y:863,t:1527009031969};\\\", \\\"{x:1620,y:869,t:1527009031986};\\\", \\\"{x:1620,y:875,t:1527009032003};\\\", \\\"{x:1620,y:880,t:1527009032019};\\\", \\\"{x:1619,y:885,t:1527009032036};\\\", \\\"{x:1619,y:887,t:1527009032052};\\\", \\\"{x:1619,y:892,t:1527009032068};\\\", \\\"{x:1618,y:894,t:1527009032086};\\\", \\\"{x:1617,y:898,t:1527009032103};\\\", \\\"{x:1617,y:903,t:1527009032118};\\\", \\\"{x:1616,y:908,t:1527009032135};\\\", \\\"{x:1616,y:910,t:1527009032152};\\\", \\\"{x:1616,y:912,t:1527009032168};\\\", \\\"{x:1616,y:914,t:1527009032185};\\\", \\\"{x:1616,y:915,t:1527009032202};\\\", \\\"{x:1616,y:917,t:1527009032218};\\\", \\\"{x:1614,y:919,t:1527009032235};\\\", \\\"{x:1614,y:920,t:1527009032252};\\\", \\\"{x:1614,y:921,t:1527009032268};\\\", \\\"{x:1614,y:923,t:1527009032284};\\\", \\\"{x:1614,y:926,t:1527009032301};\\\", \\\"{x:1613,y:927,t:1527009032318};\\\", \\\"{x:1613,y:928,t:1527009032334};\\\", \\\"{x:1613,y:930,t:1527009032351};\\\", \\\"{x:1613,y:933,t:1527009032368};\\\", \\\"{x:1612,y:935,t:1527009032384};\\\", \\\"{x:1612,y:937,t:1527009032402};\\\", \\\"{x:1612,y:939,t:1527009032417};\\\", \\\"{x:1612,y:942,t:1527009032434};\\\", \\\"{x:1612,y:943,t:1527009032452};\\\", \\\"{x:1612,y:946,t:1527009032468};\\\", \\\"{x:1612,y:949,t:1527009032484};\\\", \\\"{x:1612,y:950,t:1527009032500};\\\", \\\"{x:1612,y:952,t:1527009032517};\\\", \\\"{x:1612,y:954,t:1527009032534};\\\", \\\"{x:1612,y:955,t:1527009032551};\\\", \\\"{x:1612,y:957,t:1527009032568};\\\", \\\"{x:1612,y:958,t:1527009032585};\\\", \\\"{x:1612,y:960,t:1527009032601};\\\", \\\"{x:1612,y:961,t:1527009032617};\\\", \\\"{x:1613,y:963,t:1527009032640};\\\", \\\"{x:1613,y:964,t:1527009032680};\\\", \\\"{x:1613,y:965,t:1527009032713};\\\", \\\"{x:1613,y:966,t:1527009032720};\\\", \\\"{x:1613,y:967,t:1527009032734};\\\", \\\"{x:1613,y:968,t:1527009032751};\\\", \\\"{x:1613,y:969,t:1527009032767};\\\", \\\"{x:1614,y:970,t:1527009032912};\\\", \\\"{x:1611,y:970,t:1527009051399};\\\", \\\"{x:1609,y:969,t:1527009051407};\\\", \\\"{x:1606,y:968,t:1527009051419};\\\", \\\"{x:1605,y:968,t:1527009051807};\\\", \\\"{x:1606,y:968,t:1527009051991};\\\", \\\"{x:1608,y:968,t:1527009052006};\\\", \\\"{x:1609,y:968,t:1527009052023};\\\", \\\"{x:1610,y:968,t:1527009052054};\\\", \\\"{x:1611,y:967,t:1527009052103};\\\", \\\"{x:1612,y:967,t:1527009052463};\\\", \\\"{x:1612,y:966,t:1527009052471};\\\", \\\"{x:1613,y:966,t:1527009052503};\\\", \\\"{x:1614,y:966,t:1527009052516};\\\", \\\"{x:1615,y:966,t:1527009052532};\\\", \\\"{x:1616,y:964,t:1527009052549};\\\", \\\"{x:1615,y:964,t:1527009052784};\\\", \\\"{x:1612,y:964,t:1527009052798};\\\", \\\"{x:1604,y:964,t:1527009052815};\\\", \\\"{x:1599,y:964,t:1527009052832};\\\", \\\"{x:1596,y:964,t:1527009052848};\\\", \\\"{x:1592,y:964,t:1527009052865};\\\", \\\"{x:1589,y:964,t:1527009052882};\\\", \\\"{x:1588,y:964,t:1527009052898};\\\", \\\"{x:1586,y:964,t:1527009052915};\\\", \\\"{x:1584,y:964,t:1527009052931};\\\", \\\"{x:1580,y:964,t:1527009052948};\\\", \\\"{x:1576,y:964,t:1527009052965};\\\", \\\"{x:1572,y:964,t:1527009052980};\\\", \\\"{x:1567,y:965,t:1527009052999};\\\", \\\"{x:1562,y:965,t:1527009053015};\\\", \\\"{x:1559,y:965,t:1527009053030};\\\", \\\"{x:1557,y:965,t:1527009053048};\\\", \\\"{x:1555,y:966,t:1527009053065};\\\", \\\"{x:1554,y:966,t:1527009053081};\\\", \\\"{x:1553,y:967,t:1527009053098};\\\", \\\"{x:1552,y:967,t:1527009053783};\\\", \\\"{x:1551,y:967,t:1527009053799};\\\", \\\"{x:1549,y:967,t:1527009053830};\\\", \\\"{x:1549,y:966,t:1527009053846};\\\", \\\"{x:1548,y:964,t:1527009053862};\\\", \\\"{x:1547,y:960,t:1527009053879};\\\", \\\"{x:1546,y:958,t:1527009053902};\\\", \\\"{x:1546,y:957,t:1527009053943};\\\", \\\"{x:1546,y:955,t:1527009053951};\\\", \\\"{x:1546,y:954,t:1527009053962};\\\", \\\"{x:1546,y:943,t:1527009053979};\\\", \\\"{x:1546,y:930,t:1527009053995};\\\", \\\"{x:1546,y:915,t:1527009054011};\\\", \\\"{x:1546,y:909,t:1527009054029};\\\", \\\"{x:1546,y:906,t:1527009054045};\\\", \\\"{x:1546,y:904,t:1527009054062};\\\", \\\"{x:1546,y:901,t:1527009054079};\\\", \\\"{x:1546,y:898,t:1527009054094};\\\", \\\"{x:1546,y:895,t:1527009054112};\\\", \\\"{x:1546,y:892,t:1527009054128};\\\", \\\"{x:1547,y:891,t:1527009054145};\\\", \\\"{x:1547,y:890,t:1527009054162};\\\", \\\"{x:1547,y:891,t:1527009054351};\\\", \\\"{x:1547,y:892,t:1527009054361};\\\", \\\"{x:1547,y:895,t:1527009054378};\\\", \\\"{x:1547,y:899,t:1527009054394};\\\", \\\"{x:1547,y:900,t:1527009054735};\\\", \\\"{x:1546,y:900,t:1527009054750};\\\", \\\"{x:1545,y:900,t:1527009054783};\\\", \\\"{x:1544,y:900,t:1527009054815};\\\", \\\"{x:1543,y:900,t:1527009054879};\\\", \\\"{x:1543,y:899,t:1527009055007};\\\", \\\"{x:1544,y:899,t:1527009055031};\\\", \\\"{x:1545,y:899,t:1527009055043};\\\", \\\"{x:1546,y:899,t:1527009055059};\\\", \\\"{x:1547,y:898,t:1527009055078};\\\", \\\"{x:1548,y:898,t:1527009055103};\\\", \\\"{x:1549,y:898,t:1527009055111};\\\", \\\"{x:1549,y:897,t:1527009055231};\\\", \\\"{x:1548,y:896,t:1527009055242};\\\", \\\"{x:1547,y:896,t:1527009055270};\\\", \\\"{x:1545,y:896,t:1527009056167};\\\", \\\"{x:1544,y:896,t:1527009056535};\\\", \\\"{x:1543,y:895,t:1527009056544};\\\", \\\"{x:1542,y:894,t:1527009056555};\\\", \\\"{x:1541,y:894,t:1527009056572};\\\", \\\"{x:1539,y:892,t:1527009056589};\\\", \\\"{x:1537,y:891,t:1527009056605};\\\", \\\"{x:1535,y:889,t:1527009056622};\\\", \\\"{x:1532,y:888,t:1527009056639};\\\", \\\"{x:1530,y:886,t:1527009056655};\\\", \\\"{x:1525,y:882,t:1527009056672};\\\", \\\"{x:1525,y:881,t:1527009056688};\\\", \\\"{x:1523,y:879,t:1527009056705};\\\", \\\"{x:1522,y:878,t:1527009056722};\\\", \\\"{x:1520,y:875,t:1527009056738};\\\", \\\"{x:1519,y:874,t:1527009056755};\\\", \\\"{x:1516,y:870,t:1527009056772};\\\", \\\"{x:1515,y:867,t:1527009056788};\\\", \\\"{x:1512,y:865,t:1527009056805};\\\", \\\"{x:1510,y:862,t:1527009056821};\\\", \\\"{x:1507,y:859,t:1527009056838};\\\", \\\"{x:1505,y:858,t:1527009056854};\\\", \\\"{x:1505,y:856,t:1527009056871};\\\", \\\"{x:1503,y:855,t:1527009056888};\\\", \\\"{x:1503,y:854,t:1527009056911};\\\", \\\"{x:1502,y:854,t:1527009056927};\\\", \\\"{x:1502,y:853,t:1527009056945};\\\", \\\"{x:1501,y:853,t:1527009056959};\\\", \\\"{x:1500,y:852,t:1527009056972};\\\", \\\"{x:1500,y:851,t:1527009057024};\\\", \\\"{x:1498,y:850,t:1527009057047};\\\", \\\"{x:1497,y:849,t:1527009057079};\\\", \\\"{x:1496,y:848,t:1527009057094};\\\", \\\"{x:1494,y:848,t:1527009057119};\\\", \\\"{x:1493,y:847,t:1527009057127};\\\", \\\"{x:1492,y:846,t:1527009057143};\\\", \\\"{x:1491,y:846,t:1527009057154};\\\", \\\"{x:1489,y:845,t:1527009057171};\\\", \\\"{x:1488,y:844,t:1527009057187};\\\", \\\"{x:1485,y:842,t:1527009057204};\\\", \\\"{x:1484,y:842,t:1527009057220};\\\", \\\"{x:1483,y:841,t:1527009057237};\\\", \\\"{x:1482,y:840,t:1527009058184};\\\", \\\"{x:1481,y:839,t:1527009058455};\\\", \\\"{x:1480,y:839,t:1527009060655};\\\", \\\"{x:1478,y:839,t:1527009060663};\\\", \\\"{x:1474,y:838,t:1527009060679};\\\", \\\"{x:1463,y:835,t:1527009060695};\\\", \\\"{x:1458,y:833,t:1527009060711};\\\", \\\"{x:1456,y:832,t:1527009060729};\\\", \\\"{x:1453,y:832,t:1527009060745};\\\", \\\"{x:1451,y:832,t:1527009060761};\\\", \\\"{x:1450,y:831,t:1527009060778};\\\", \\\"{x:1448,y:831,t:1527009060795};\\\", \\\"{x:1445,y:830,t:1527009060812};\\\", \\\"{x:1440,y:828,t:1527009060829};\\\", \\\"{x:1436,y:826,t:1527009060845};\\\", \\\"{x:1432,y:825,t:1527009060861};\\\", \\\"{x:1428,y:824,t:1527009060878};\\\", \\\"{x:1425,y:822,t:1527009060895};\\\", \\\"{x:1422,y:821,t:1527009060911};\\\", \\\"{x:1422,y:820,t:1527009060928};\\\", \\\"{x:1421,y:819,t:1527009060945};\\\", \\\"{x:1420,y:817,t:1527009060983};\\\", \\\"{x:1419,y:816,t:1527009060995};\\\", \\\"{x:1419,y:812,t:1527009061012};\\\", \\\"{x:1415,y:804,t:1527009061027};\\\", \\\"{x:1412,y:794,t:1527009061044};\\\", \\\"{x:1410,y:785,t:1527009061060};\\\", \\\"{x:1408,y:782,t:1527009061078};\\\", \\\"{x:1407,y:780,t:1527009061095};\\\", \\\"{x:1406,y:779,t:1527009061111};\\\", \\\"{x:1405,y:778,t:1527009061327};\\\", \\\"{x:1404,y:778,t:1527009061359};\\\", \\\"{x:1403,y:778,t:1527009061479};\\\", \\\"{x:1400,y:778,t:1527009061495};\\\", \\\"{x:1397,y:778,t:1527009061509};\\\", \\\"{x:1381,y:778,t:1527009061527};\\\", \\\"{x:1325,y:771,t:1527009061544};\\\", \\\"{x:1247,y:760,t:1527009061559};\\\", \\\"{x:1161,y:749,t:1527009061576};\\\", \\\"{x:1053,y:733,t:1527009061592};\\\", \\\"{x:931,y:718,t:1527009061610};\\\", \\\"{x:814,y:698,t:1527009061626};\\\", \\\"{x:722,y:684,t:1527009061642};\\\", \\\"{x:685,y:678,t:1527009061660};\\\", \\\"{x:664,y:671,t:1527009061675};\\\", \\\"{x:650,y:667,t:1527009061693};\\\", \\\"{x:645,y:666,t:1527009061709};\\\", \\\"{x:638,y:662,t:1527009061725};\\\", \\\"{x:634,y:661,t:1527009061742};\\\", \\\"{x:630,y:660,t:1527009061759};\\\", \\\"{x:628,y:659,t:1527009061775};\\\", \\\"{x:618,y:657,t:1527009061793};\\\", \\\"{x:598,y:654,t:1527009061808};\\\", \\\"{x:582,y:654,t:1527009061825};\\\", \\\"{x:565,y:654,t:1527009061843};\\\", \\\"{x:549,y:654,t:1527009061858};\\\", \\\"{x:528,y:653,t:1527009061875};\\\", \\\"{x:506,y:649,t:1527009061893};\\\", \\\"{x:487,y:647,t:1527009061909};\\\", \\\"{x:470,y:644,t:1527009061925};\\\", \\\"{x:463,y:644,t:1527009061934};\\\", \\\"{x:445,y:642,t:1527009061950};\\\", \\\"{x:430,y:638,t:1527009061967};\\\", \\\"{x:416,y:635,t:1527009061985};\\\", \\\"{x:392,y:631,t:1527009062001};\\\", \\\"{x:363,y:628,t:1527009062017};\\\", \\\"{x:341,y:625,t:1527009062034};\\\", \\\"{x:325,y:621,t:1527009062051};\\\", \\\"{x:311,y:616,t:1527009062068};\\\", \\\"{x:305,y:612,t:1527009062085};\\\", \\\"{x:304,y:604,t:1527009062102};\\\", \\\"{x:306,y:594,t:1527009062118};\\\", \\\"{x:311,y:583,t:1527009062134};\\\", \\\"{x:315,y:576,t:1527009062152};\\\", \\\"{x:322,y:568,t:1527009062169};\\\", \\\"{x:328,y:560,t:1527009062185};\\\", \\\"{x:332,y:555,t:1527009062201};\\\", \\\"{x:336,y:551,t:1527009062218};\\\", \\\"{x:343,y:548,t:1527009062234};\\\", \\\"{x:349,y:546,t:1527009062252};\\\", \\\"{x:356,y:546,t:1527009062269};\\\", \\\"{x:360,y:545,t:1527009062284};\\\", \\\"{x:363,y:543,t:1527009062303};\\\", \\\"{x:368,y:543,t:1527009062319};\\\", \\\"{x:373,y:551,t:1527009062335};\\\", \\\"{x:380,y:561,t:1527009062352};\\\", \\\"{x:384,y:565,t:1527009062368};\\\", \\\"{x:386,y:567,t:1527009062385};\\\", \\\"{x:386,y:569,t:1527009062401};\\\", \\\"{x:385,y:569,t:1527009062552};\\\", \\\"{x:380,y:564,t:1527009062569};\\\", \\\"{x:377,y:559,t:1527009062586};\\\", \\\"{x:376,y:558,t:1527009062601};\\\", \\\"{x:376,y:557,t:1527009062618};\\\", \\\"{x:381,y:556,t:1527009062806};\\\", \\\"{x:392,y:552,t:1527009062818};\\\", \\\"{x:415,y:548,t:1527009062835};\\\", \\\"{x:445,y:544,t:1527009062852};\\\", \\\"{x:501,y:536,t:1527009062868};\\\", \\\"{x:588,y:523,t:1527009062885};\\\", \\\"{x:673,y:512,t:1527009062902};\\\", \\\"{x:762,y:501,t:1527009062918};\\\", \\\"{x:846,y:486,t:1527009062935};\\\", \\\"{x:876,y:484,t:1527009062952};\\\", \\\"{x:895,y:481,t:1527009062968};\\\", \\\"{x:905,y:479,t:1527009062986};\\\", \\\"{x:908,y:479,t:1527009063002};\\\", \\\"{x:909,y:478,t:1527009063063};\\\", \\\"{x:906,y:478,t:1527009063167};\\\", \\\"{x:901,y:479,t:1527009063175};\\\", \\\"{x:895,y:483,t:1527009063185};\\\", \\\"{x:878,y:492,t:1527009063203};\\\", \\\"{x:860,y:501,t:1527009063219};\\\", \\\"{x:845,y:506,t:1527009063236};\\\", \\\"{x:836,y:508,t:1527009063253};\\\", \\\"{x:825,y:508,t:1527009063269};\\\", \\\"{x:817,y:510,t:1527009063285};\\\", \\\"{x:811,y:512,t:1527009063302};\\\", \\\"{x:811,y:513,t:1527009063344};\\\", \\\"{x:813,y:513,t:1527009063424};\\\", \\\"{x:815,y:514,t:1527009063435};\\\", \\\"{x:824,y:517,t:1527009063453};\\\", \\\"{x:829,y:518,t:1527009063469};\\\", \\\"{x:834,y:520,t:1527009063486};\\\", \\\"{x:834,y:521,t:1527009063502};\\\", \\\"{x:836,y:521,t:1527009063518};\\\", \\\"{x:835,y:521,t:1527009063886};\\\", \\\"{x:833,y:521,t:1527009063903};\\\", \\\"{x:832,y:521,t:1527009063919};\\\", \\\"{x:831,y:522,t:1527009063943};\\\", \\\"{x:831,y:523,t:1527009063952};\\\", \\\"{x:828,y:526,t:1527009063969};\\\", \\\"{x:816,y:534,t:1527009063986};\\\", \\\"{x:798,y:546,t:1527009064003};\\\", \\\"{x:771,y:563,t:1527009064019};\\\", \\\"{x:730,y:586,t:1527009064037};\\\", \\\"{x:689,y:610,t:1527009064053};\\\", \\\"{x:651,y:632,t:1527009064070};\\\", \\\"{x:619,y:650,t:1527009064086};\\\", \\\"{x:566,y:679,t:1527009064103};\\\", \\\"{x:540,y:691,t:1527009064119};\\\", \\\"{x:511,y:706,t:1527009064137};\\\", \\\"{x:482,y:722,t:1527009064152};\\\", \\\"{x:463,y:733,t:1527009064169};\\\", \\\"{x:454,y:738,t:1527009064187};\\\", \\\"{x:449,y:742,t:1527009064203};\\\", \\\"{x:447,y:744,t:1527009064219};\\\", \\\"{x:446,y:744,t:1527009064263};\\\", \\\"{x:446,y:746,t:1527009064279};\\\", \\\"{x:444,y:748,t:1527009064287};\\\", \\\"{x:442,y:750,t:1527009064303};\\\", \\\"{x:437,y:754,t:1527009064320};\\\", \\\"{x:435,y:756,t:1527009064336};\\\", \\\"{x:434,y:756,t:1527009064354};\\\", \\\"{x:435,y:753,t:1527009064391};\\\", \\\"{x:438,y:748,t:1527009064404};\\\", \\\"{x:444,y:742,t:1527009064420};\\\", \\\"{x:448,y:737,t:1527009064436};\\\", \\\"{x:454,y:735,t:1527009064455};\\\", \\\"{x:460,y:732,t:1527009064470};\\\", \\\"{x:468,y:728,t:1527009064487};\\\", \\\"{x:477,y:722,t:1527009064503};\\\", \\\"{x:479,y:722,t:1527009064520};\\\", \\\"{x:480,y:721,t:1527009064537};\\\", \\\"{x:481,y:721,t:1527009064566};\\\", \\\"{x:482,y:721,t:1527009064575};\\\", \\\"{x:483,y:720,t:1527009064599};\\\", \\\"{x:484,y:720,t:1527009064623};\\\" ] }, { \\\"rt\\\": 25552, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 7, \\\"time_elapsed\\\": 265935, \\\"internal_node_id\\\": \\\"0.0-5.0-2.0\\\", \\\"subject\\\": \\\"38NFJ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"echo\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 3, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"A\\\", \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-C -09 AM-C -C -C -C -3\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:485,y:719,t:1527009066921};\\\", \\\"{x:492,y:716,t:1527009066933};\\\", \\\"{x:510,y:711,t:1527009066950};\\\", \\\"{x:523,y:706,t:1527009066966};\\\", \\\"{x:536,y:701,t:1527009066983};\\\", \\\"{x:546,y:699,t:1527009067000};\\\", \\\"{x:562,y:696,t:1527009067016};\\\", \\\"{x:575,y:691,t:1527009067033};\\\", \\\"{x:596,y:685,t:1527009067049};\\\", \\\"{x:612,y:680,t:1527009067066};\\\", \\\"{x:623,y:677,t:1527009067082};\\\", \\\"{x:634,y:673,t:1527009067099};\\\", \\\"{x:643,y:670,t:1527009067116};\\\", \\\"{x:653,y:667,t:1527009067132};\\\", \\\"{x:657,y:664,t:1527009067149};\\\", \\\"{x:661,y:661,t:1527009067166};\\\", \\\"{x:669,y:656,t:1527009067182};\\\", \\\"{x:676,y:649,t:1527009067199};\\\", \\\"{x:689,y:636,t:1527009067216};\\\", \\\"{x:712,y:617,t:1527009067234};\\\", \\\"{x:727,y:605,t:1527009067249};\\\", \\\"{x:742,y:595,t:1527009067266};\\\", \\\"{x:757,y:585,t:1527009067283};\\\", \\\"{x:776,y:573,t:1527009067299};\\\", \\\"{x:808,y:555,t:1527009067316};\\\", \\\"{x:848,y:530,t:1527009067333};\\\", \\\"{x:884,y:509,t:1527009067349};\\\", \\\"{x:925,y:491,t:1527009067366};\\\", \\\"{x:964,y:475,t:1527009067383};\\\", \\\"{x:1011,y:462,t:1527009067400};\\\", \\\"{x:1060,y:453,t:1527009067416};\\\", \\\"{x:1125,y:446,t:1527009067433};\\\", \\\"{x:1158,y:446,t:1527009067449};\\\", \\\"{x:1189,y:449,t:1527009067465};\\\", \\\"{x:1218,y:460,t:1527009067483};\\\", \\\"{x:1241,y:470,t:1527009067499};\\\", \\\"{x:1259,y:482,t:1527009067516};\\\", \\\"{x:1277,y:497,t:1527009067532};\\\", \\\"{x:1295,y:514,t:1527009067549};\\\", \\\"{x:1309,y:529,t:1527009067566};\\\", \\\"{x:1321,y:547,t:1527009067583};\\\", \\\"{x:1334,y:566,t:1527009067600};\\\", \\\"{x:1349,y:586,t:1527009067616};\\\", \\\"{x:1360,y:608,t:1527009067634};\\\", \\\"{x:1363,y:622,t:1527009067650};\\\", \\\"{x:1364,y:638,t:1527009067666};\\\", \\\"{x:1366,y:653,t:1527009067682};\\\", \\\"{x:1374,y:664,t:1527009067700};\\\", \\\"{x:1378,y:679,t:1527009067716};\\\", \\\"{x:1380,y:688,t:1527009067733};\\\", \\\"{x:1382,y:693,t:1527009067750};\\\", \\\"{x:1383,y:696,t:1527009067766};\\\", \\\"{x:1383,y:699,t:1527009067784};\\\", \\\"{x:1383,y:701,t:1527009067800};\\\", \\\"{x:1383,y:702,t:1527009067841};\\\", \\\"{x:1383,y:703,t:1527009067866};\\\", \\\"{x:1383,y:704,t:1527009067930};\\\", \\\"{x:1383,y:705,t:1527009067938};\\\", \\\"{x:1383,y:706,t:1527009067961};\\\", \\\"{x:1383,y:707,t:1527009067970};\\\", \\\"{x:1382,y:708,t:1527009067986};\\\", \\\"{x:1382,y:711,t:1527009068082};\\\", \\\"{x:1382,y:712,t:1527009068100};\\\", \\\"{x:1378,y:717,t:1527009068117};\\\", \\\"{x:1374,y:724,t:1527009068133};\\\", \\\"{x:1369,y:732,t:1527009068151};\\\", \\\"{x:1365,y:738,t:1527009068167};\\\", \\\"{x:1360,y:748,t:1527009068184};\\\", \\\"{x:1351,y:764,t:1527009068201};\\\", \\\"{x:1337,y:787,t:1527009068218};\\\", \\\"{x:1328,y:800,t:1527009068234};\\\", \\\"{x:1318,y:813,t:1527009068250};\\\", \\\"{x:1313,y:820,t:1527009068267};\\\", \\\"{x:1309,y:824,t:1527009068283};\\\", \\\"{x:1305,y:827,t:1527009068300};\\\", \\\"{x:1303,y:830,t:1527009068317};\\\", \\\"{x:1299,y:832,t:1527009068334};\\\", \\\"{x:1292,y:836,t:1527009068350};\\\", \\\"{x:1285,y:841,t:1527009068367};\\\", \\\"{x:1277,y:845,t:1527009068384};\\\", \\\"{x:1267,y:852,t:1527009068400};\\\", \\\"{x:1252,y:859,t:1527009068418};\\\", \\\"{x:1239,y:862,t:1527009068433};\\\", \\\"{x:1232,y:863,t:1527009068450};\\\", \\\"{x:1222,y:864,t:1527009068467};\\\", \\\"{x:1213,y:865,t:1527009068484};\\\", \\\"{x:1210,y:865,t:1527009068500};\\\", \\\"{x:1209,y:865,t:1527009068517};\\\", \\\"{x:1208,y:865,t:1527009068578};\\\", \\\"{x:1208,y:864,t:1527009068585};\\\", \\\"{x:1208,y:863,t:1527009068600};\\\", \\\"{x:1209,y:858,t:1527009068618};\\\", \\\"{x:1211,y:856,t:1527009068633};\\\", \\\"{x:1211,y:854,t:1527009068650};\\\", \\\"{x:1212,y:853,t:1527009068668};\\\", \\\"{x:1214,y:851,t:1527009068684};\\\", \\\"{x:1215,y:849,t:1527009068700};\\\", \\\"{x:1215,y:848,t:1527009068729};\\\", \\\"{x:1215,y:847,t:1527009068738};\\\", \\\"{x:1215,y:846,t:1527009068762};\\\", \\\"{x:1215,y:845,t:1527009068777};\\\", \\\"{x:1215,y:844,t:1527009068842};\\\", \\\"{x:1215,y:842,t:1527009068850};\\\", \\\"{x:1215,y:841,t:1527009068867};\\\", \\\"{x:1215,y:839,t:1527009068884};\\\", \\\"{x:1215,y:838,t:1527009068902};\\\", \\\"{x:1215,y:836,t:1527009068962};\\\", \\\"{x:1214,y:835,t:1527009068972};\\\", \\\"{x:1214,y:833,t:1527009069001};\\\", \\\"{x:1213,y:833,t:1527009069016};\\\", \\\"{x:1213,y:832,t:1527009069290};\\\", \\\"{x:1213,y:831,t:1527009069314};\\\", \\\"{x:1213,y:833,t:1527009075570};\\\", \\\"{x:1212,y:836,t:1527009075579};\\\", \\\"{x:1212,y:837,t:1527009075590};\\\", \\\"{x:1211,y:839,t:1527009075606};\\\", \\\"{x:1209,y:844,t:1527009075623};\\\", \\\"{x:1208,y:846,t:1527009075639};\\\", \\\"{x:1207,y:850,t:1527009075656};\\\", \\\"{x:1204,y:857,t:1527009075673};\\\", \\\"{x:1201,y:872,t:1527009075690};\\\", \\\"{x:1198,y:885,t:1527009075706};\\\", \\\"{x:1193,y:898,t:1527009075722};\\\", \\\"{x:1189,y:910,t:1527009075739};\\\", \\\"{x:1186,y:922,t:1527009075757};\\\", \\\"{x:1185,y:929,t:1527009075773};\\\", \\\"{x:1184,y:935,t:1527009075789};\\\", \\\"{x:1182,y:941,t:1527009075805};\\\", \\\"{x:1180,y:950,t:1527009075823};\\\", \\\"{x:1177,y:960,t:1527009075839};\\\", \\\"{x:1175,y:967,t:1527009075856};\\\", \\\"{x:1173,y:973,t:1527009075873};\\\", \\\"{x:1173,y:974,t:1527009075896};\\\", \\\"{x:1172,y:974,t:1527009075906};\\\", \\\"{x:1171,y:975,t:1527009075923};\\\", \\\"{x:1170,y:975,t:1527009075938};\\\", \\\"{x:1169,y:977,t:1527009075956};\\\", \\\"{x:1168,y:979,t:1527009075973};\\\", \\\"{x:1166,y:979,t:1527009075989};\\\", \\\"{x:1164,y:981,t:1527009076006};\\\", \\\"{x:1162,y:981,t:1527009076025};\\\", \\\"{x:1160,y:982,t:1527009076039};\\\", \\\"{x:1159,y:982,t:1527009076056};\\\", \\\"{x:1157,y:982,t:1527009076073};\\\", \\\"{x:1156,y:982,t:1527009076089};\\\", \\\"{x:1155,y:982,t:1527009076106};\\\", \\\"{x:1154,y:982,t:1527009076124};\\\", \\\"{x:1153,y:982,t:1527009076194};\\\", \\\"{x:1152,y:982,t:1527009076225};\\\", \\\"{x:1151,y:982,t:1527009076239};\\\", \\\"{x:1150,y:981,t:1527009076266};\\\", \\\"{x:1149,y:981,t:1527009076289};\\\", \\\"{x:1148,y:981,t:1527009076306};\\\", \\\"{x:1147,y:980,t:1527009076323};\\\", \\\"{x:1147,y:978,t:1527009076340};\\\", \\\"{x:1145,y:976,t:1527009076356};\\\", \\\"{x:1145,y:975,t:1527009076373};\\\", \\\"{x:1145,y:974,t:1527009076390};\\\", \\\"{x:1145,y:973,t:1527009076406};\\\", \\\"{x:1145,y:972,t:1527009076433};\\\", \\\"{x:1145,y:971,t:1527009076440};\\\", \\\"{x:1145,y:970,t:1527009076456};\\\", \\\"{x:1145,y:969,t:1527009076473};\\\", \\\"{x:1145,y:967,t:1527009076491};\\\", \\\"{x:1145,y:966,t:1527009076512};\\\", \\\"{x:1145,y:964,t:1527009076545};\\\", \\\"{x:1145,y:963,t:1527009076560};\\\", \\\"{x:1145,y:960,t:1527009076577};\\\", \\\"{x:1145,y:959,t:1527009076590};\\\", \\\"{x:1146,y:956,t:1527009076606};\\\", \\\"{x:1148,y:952,t:1527009076623};\\\", \\\"{x:1150,y:949,t:1527009076640};\\\", \\\"{x:1152,y:944,t:1527009076656};\\\", \\\"{x:1156,y:938,t:1527009076673};\\\", \\\"{x:1159,y:935,t:1527009076690};\\\", \\\"{x:1160,y:931,t:1527009076706};\\\", \\\"{x:1164,y:927,t:1527009076723};\\\", \\\"{x:1167,y:920,t:1527009076740};\\\", \\\"{x:1170,y:912,t:1527009076757};\\\", \\\"{x:1175,y:905,t:1527009076774};\\\", \\\"{x:1177,y:901,t:1527009076790};\\\", \\\"{x:1180,y:897,t:1527009076807};\\\", \\\"{x:1184,y:891,t:1527009076823};\\\", \\\"{x:1186,y:887,t:1527009076840};\\\", \\\"{x:1188,y:882,t:1527009076857};\\\", \\\"{x:1189,y:879,t:1527009076873};\\\", \\\"{x:1191,y:876,t:1527009076891};\\\", \\\"{x:1192,y:873,t:1527009076908};\\\", \\\"{x:1192,y:871,t:1527009076924};\\\", \\\"{x:1194,y:868,t:1527009076941};\\\", \\\"{x:1196,y:863,t:1527009076957};\\\", \\\"{x:1198,y:859,t:1527009076974};\\\", \\\"{x:1199,y:855,t:1527009076990};\\\", \\\"{x:1201,y:852,t:1527009077007};\\\", \\\"{x:1201,y:850,t:1527009077024};\\\", \\\"{x:1202,y:847,t:1527009077040};\\\", \\\"{x:1203,y:844,t:1527009077057};\\\", \\\"{x:1204,y:843,t:1527009077074};\\\", \\\"{x:1206,y:839,t:1527009077091};\\\", \\\"{x:1210,y:832,t:1527009077108};\\\", \\\"{x:1212,y:829,t:1527009077124};\\\", \\\"{x:1214,y:825,t:1527009077140};\\\", \\\"{x:1214,y:824,t:1527009077163};\\\", \\\"{x:1215,y:824,t:1527009077553};\\\", \\\"{x:1215,y:826,t:1527009077570};\\\", \\\"{x:1215,y:828,t:1527009077609};\\\", \\\"{x:1215,y:829,t:1527009077642};\\\", \\\"{x:1215,y:831,t:1527009077754};\\\", \\\"{x:1214,y:831,t:1527009077762};\\\", \\\"{x:1214,y:832,t:1527009078753};\\\", \\\"{x:1214,y:833,t:1527009078769};\\\", \\\"{x:1215,y:833,t:1527009078777};\\\", \\\"{x:1215,y:834,t:1527009078792};\\\", \\\"{x:1216,y:835,t:1527009078808};\\\", \\\"{x:1217,y:836,t:1527009078826};\\\", \\\"{x:1217,y:837,t:1527009078938};\\\", \\\"{x:1217,y:838,t:1527009079442};\\\", \\\"{x:1218,y:842,t:1527009079459};\\\", \\\"{x:1218,y:847,t:1527009079475};\\\", \\\"{x:1218,y:851,t:1527009079493};\\\", \\\"{x:1219,y:855,t:1527009079510};\\\", \\\"{x:1220,y:859,t:1527009079526};\\\", \\\"{x:1220,y:861,t:1527009079542};\\\", \\\"{x:1220,y:865,t:1527009079560};\\\", \\\"{x:1220,y:868,t:1527009079575};\\\", \\\"{x:1220,y:869,t:1527009079593};\\\", \\\"{x:1220,y:872,t:1527009079609};\\\", \\\"{x:1220,y:873,t:1527009079657};\\\", \\\"{x:1220,y:874,t:1527009079673};\\\", \\\"{x:1220,y:875,t:1527009079681};\\\", \\\"{x:1220,y:876,t:1527009079714};\\\", \\\"{x:1220,y:877,t:1527009079730};\\\", \\\"{x:1220,y:878,t:1527009079742};\\\", \\\"{x:1220,y:879,t:1527009079769};\\\", \\\"{x:1220,y:880,t:1527009079793};\\\", \\\"{x:1220,y:881,t:1527009079898};\\\", \\\"{x:1218,y:881,t:1527009079909};\\\", \\\"{x:1215,y:879,t:1527009079926};\\\", \\\"{x:1215,y:874,t:1527009079943};\\\", \\\"{x:1215,y:871,t:1527009079959};\\\", \\\"{x:1212,y:866,t:1527009079977};\\\", \\\"{x:1212,y:860,t:1527009079993};\\\", \\\"{x:1212,y:859,t:1527009080009};\\\", \\\"{x:1212,y:855,t:1527009080027};\\\", \\\"{x:1212,y:854,t:1527009080042};\\\", \\\"{x:1212,y:853,t:1527009080060};\\\", \\\"{x:1212,y:852,t:1527009080076};\\\", \\\"{x:1212,y:850,t:1527009080092};\\\", \\\"{x:1212,y:847,t:1527009080110};\\\", \\\"{x:1213,y:845,t:1527009080126};\\\", \\\"{x:1213,y:843,t:1527009080143};\\\", \\\"{x:1213,y:842,t:1527009080159};\\\", \\\"{x:1213,y:840,t:1527009080177};\\\", \\\"{x:1215,y:839,t:1527009080192};\\\", \\\"{x:1215,y:838,t:1527009080209};\\\", \\\"{x:1215,y:837,t:1527009080226};\\\", \\\"{x:1215,y:836,t:1527009080265};\\\", \\\"{x:1216,y:835,t:1527009080276};\\\", \\\"{x:1216,y:834,t:1527009080293};\\\", \\\"{x:1217,y:833,t:1527009080309};\\\", \\\"{x:1218,y:832,t:1527009080326};\\\", \\\"{x:1219,y:832,t:1527009080817};\\\", \\\"{x:1221,y:832,t:1527009080827};\\\", \\\"{x:1230,y:831,t:1527009080844};\\\", \\\"{x:1237,y:830,t:1527009080860};\\\", \\\"{x:1244,y:830,t:1527009080876};\\\", \\\"{x:1252,y:830,t:1527009080893};\\\", \\\"{x:1259,y:830,t:1527009080910};\\\", \\\"{x:1265,y:830,t:1527009080926};\\\", \\\"{x:1274,y:832,t:1527009080944};\\\", \\\"{x:1288,y:841,t:1527009080960};\\\", \\\"{x:1304,y:847,t:1527009080977};\\\", \\\"{x:1322,y:855,t:1527009080994};\\\", \\\"{x:1333,y:861,t:1527009081010};\\\", \\\"{x:1341,y:867,t:1527009081027};\\\", \\\"{x:1347,y:871,t:1527009081043};\\\", \\\"{x:1350,y:874,t:1527009081061};\\\", \\\"{x:1352,y:878,t:1527009081078};\\\", \\\"{x:1353,y:880,t:1527009081093};\\\", \\\"{x:1353,y:884,t:1527009081111};\\\", \\\"{x:1355,y:887,t:1527009081127};\\\", \\\"{x:1356,y:889,t:1527009081143};\\\", \\\"{x:1356,y:891,t:1527009081160};\\\", \\\"{x:1357,y:895,t:1527009081177};\\\", \\\"{x:1357,y:900,t:1527009081194};\\\", \\\"{x:1357,y:904,t:1527009081211};\\\", \\\"{x:1357,y:907,t:1527009081228};\\\", \\\"{x:1356,y:910,t:1527009081243};\\\", \\\"{x:1355,y:914,t:1527009081261};\\\", \\\"{x:1355,y:916,t:1527009081278};\\\", \\\"{x:1353,y:920,t:1527009081294};\\\", \\\"{x:1353,y:922,t:1527009081310};\\\", \\\"{x:1353,y:924,t:1527009081327};\\\", \\\"{x:1353,y:926,t:1527009081344};\\\", \\\"{x:1353,y:928,t:1527009081360};\\\", \\\"{x:1353,y:931,t:1527009081378};\\\", \\\"{x:1353,y:932,t:1527009081394};\\\", \\\"{x:1353,y:933,t:1527009081411};\\\", \\\"{x:1353,y:935,t:1527009081428};\\\", \\\"{x:1353,y:938,t:1527009081444};\\\", \\\"{x:1353,y:940,t:1527009081460};\\\", \\\"{x:1353,y:942,t:1527009081478};\\\", \\\"{x:1353,y:943,t:1527009081494};\\\", \\\"{x:1353,y:945,t:1527009081511};\\\", \\\"{x:1353,y:946,t:1527009081527};\\\", \\\"{x:1352,y:948,t:1527009081545};\\\", \\\"{x:1352,y:953,t:1527009081560};\\\", \\\"{x:1351,y:955,t:1527009081577};\\\", \\\"{x:1350,y:959,t:1527009081595};\\\", \\\"{x:1350,y:960,t:1527009081611};\\\", \\\"{x:1349,y:961,t:1527009081628};\\\", \\\"{x:1349,y:962,t:1527009081645};\\\", \\\"{x:1348,y:964,t:1527009081661};\\\", \\\"{x:1347,y:965,t:1527009081678};\\\", \\\"{x:1346,y:967,t:1527009081695};\\\", \\\"{x:1345,y:967,t:1527009081722};\\\", \\\"{x:1344,y:967,t:1527009081833};\\\", \\\"{x:1343,y:967,t:1527009081849};\\\", \\\"{x:1342,y:967,t:1527009081881};\\\", \\\"{x:1341,y:967,t:1527009081914};\\\", \\\"{x:1340,y:967,t:1527009081929};\\\", \\\"{x:1340,y:966,t:1527009081953};\\\", \\\"{x:1340,y:965,t:1527009081970};\\\", \\\"{x:1340,y:963,t:1527009081986};\\\", \\\"{x:1340,y:962,t:1527009081996};\\\", \\\"{x:1340,y:961,t:1527009082012};\\\", \\\"{x:1340,y:960,t:1527009082027};\\\", \\\"{x:1340,y:958,t:1527009082044};\\\", \\\"{x:1340,y:957,t:1527009082061};\\\", \\\"{x:1340,y:955,t:1527009082077};\\\", \\\"{x:1340,y:954,t:1527009082094};\\\", \\\"{x:1340,y:952,t:1527009082112};\\\", \\\"{x:1340,y:951,t:1527009082128};\\\", \\\"{x:1340,y:950,t:1527009082145};\\\", \\\"{x:1340,y:949,t:1527009082161};\\\", \\\"{x:1340,y:948,t:1527009082209};\\\", \\\"{x:1340,y:947,t:1527009082217};\\\", \\\"{x:1340,y:946,t:1527009082228};\\\", \\\"{x:1340,y:945,t:1527009082244};\\\", \\\"{x:1340,y:942,t:1527009082261};\\\", \\\"{x:1340,y:938,t:1527009082278};\\\", \\\"{x:1340,y:932,t:1527009082294};\\\", \\\"{x:1340,y:924,t:1527009082312};\\\", \\\"{x:1340,y:913,t:1527009082328};\\\", \\\"{x:1340,y:895,t:1527009082345};\\\", \\\"{x:1340,y:885,t:1527009082361};\\\", \\\"{x:1340,y:876,t:1527009082379};\\\", \\\"{x:1340,y:868,t:1527009082394};\\\", \\\"{x:1340,y:862,t:1527009082412};\\\", \\\"{x:1340,y:858,t:1527009082428};\\\", \\\"{x:1340,y:857,t:1527009082445};\\\", \\\"{x:1340,y:855,t:1527009082461};\\\", \\\"{x:1340,y:854,t:1527009082479};\\\", \\\"{x:1340,y:852,t:1527009082495};\\\", \\\"{x:1340,y:851,t:1527009082512};\\\", \\\"{x:1340,y:848,t:1527009082528};\\\", \\\"{x:1340,y:842,t:1527009082545};\\\", \\\"{x:1340,y:837,t:1527009082561};\\\", \\\"{x:1340,y:833,t:1527009082579};\\\", \\\"{x:1340,y:828,t:1527009082594};\\\", \\\"{x:1340,y:824,t:1527009082612};\\\", \\\"{x:1341,y:819,t:1527009082629};\\\", \\\"{x:1341,y:814,t:1527009082644};\\\", \\\"{x:1341,y:808,t:1527009082662};\\\", \\\"{x:1341,y:803,t:1527009082678};\\\", \\\"{x:1341,y:800,t:1527009082695};\\\", \\\"{x:1341,y:797,t:1527009082712};\\\", \\\"{x:1341,y:794,t:1527009082729};\\\", \\\"{x:1341,y:793,t:1527009082745};\\\", \\\"{x:1341,y:791,t:1527009082762};\\\", \\\"{x:1341,y:788,t:1527009082779};\\\", \\\"{x:1341,y:785,t:1527009082795};\\\", \\\"{x:1341,y:784,t:1527009082812};\\\", \\\"{x:1341,y:782,t:1527009082829};\\\", \\\"{x:1341,y:781,t:1527009082846};\\\", \\\"{x:1341,y:779,t:1527009082866};\\\", \\\"{x:1341,y:777,t:1527009082905};\\\", \\\"{x:1341,y:776,t:1527009082929};\\\", \\\"{x:1341,y:775,t:1527009082978};\\\", \\\"{x:1341,y:774,t:1527009083017};\\\", \\\"{x:1341,y:773,t:1527009083034};\\\", \\\"{x:1341,y:772,t:1527009083057};\\\", \\\"{x:1341,y:771,t:1527009083074};\\\", \\\"{x:1341,y:770,t:1527009083114};\\\", \\\"{x:1341,y:769,t:1527009083154};\\\", \\\"{x:1341,y:768,t:1527009083169};\\\", \\\"{x:1341,y:767,t:1527009083201};\\\", \\\"{x:1341,y:766,t:1527009083466};\\\", \\\"{x:1341,y:765,t:1527009083479};\\\", \\\"{x:1341,y:764,t:1527009083496};\\\", \\\"{x:1341,y:763,t:1527009083537};\\\", \\\"{x:1341,y:762,t:1527009083570};\\\", \\\"{x:1338,y:764,t:1527009088050};\\\", \\\"{x:1296,y:769,t:1527009088066};\\\", \\\"{x:1251,y:769,t:1527009088083};\\\", \\\"{x:1193,y:769,t:1527009088099};\\\", \\\"{x:1120,y:766,t:1527009088116};\\\", \\\"{x:1056,y:758,t:1527009088133};\\\", \\\"{x:986,y:747,t:1527009088151};\\\", \\\"{x:928,y:742,t:1527009088165};\\\", \\\"{x:888,y:742,t:1527009088182};\\\", \\\"{x:857,y:742,t:1527009088200};\\\", \\\"{x:830,y:741,t:1527009088216};\\\", \\\"{x:794,y:741,t:1527009088233};\\\", \\\"{x:763,y:744,t:1527009088249};\\\", \\\"{x:735,y:749,t:1527009088265};\\\", \\\"{x:714,y:750,t:1527009088282};\\\", \\\"{x:695,y:750,t:1527009088300};\\\", \\\"{x:681,y:749,t:1527009088316};\\\", \\\"{x:668,y:742,t:1527009088333};\\\", \\\"{x:650,y:733,t:1527009088349};\\\", \\\"{x:630,y:721,t:1527009088365};\\\", \\\"{x:614,y:714,t:1527009088383};\\\", \\\"{x:597,y:706,t:1527009088399};\\\", \\\"{x:574,y:697,t:1527009088416};\\\", \\\"{x:534,y:679,t:1527009088433};\\\", \\\"{x:510,y:669,t:1527009088449};\\\", \\\"{x:495,y:659,t:1527009088466};\\\", \\\"{x:481,y:649,t:1527009088484};\\\", \\\"{x:469,y:639,t:1527009088499};\\\", \\\"{x:462,y:635,t:1527009088516};\\\", \\\"{x:459,y:633,t:1527009088532};\\\", \\\"{x:457,y:631,t:1527009088549};\\\", \\\"{x:456,y:630,t:1527009088566};\\\", \\\"{x:452,y:627,t:1527009088582};\\\", \\\"{x:445,y:622,t:1527009088599};\\\", \\\"{x:433,y:610,t:1527009088617};\\\", \\\"{x:426,y:601,t:1527009088632};\\\", \\\"{x:420,y:594,t:1527009088650};\\\", \\\"{x:416,y:587,t:1527009088666};\\\", \\\"{x:411,y:579,t:1527009088682};\\\", \\\"{x:407,y:571,t:1527009088700};\\\", \\\"{x:403,y:564,t:1527009088717};\\\", \\\"{x:401,y:559,t:1527009088733};\\\", \\\"{x:400,y:553,t:1527009088749};\\\", \\\"{x:398,y:549,t:1527009088767};\\\", \\\"{x:398,y:548,t:1527009088783};\\\", \\\"{x:398,y:547,t:1527009088799};\\\", \\\"{x:398,y:546,t:1527009088817};\\\", \\\"{x:398,y:545,t:1527009088890};\\\", \\\"{x:397,y:543,t:1527009088922};\\\", \\\"{x:396,y:542,t:1527009088953};\\\", \\\"{x:396,y:541,t:1527009088984};\\\", \\\"{x:396,y:540,t:1527009088999};\\\", \\\"{x:395,y:537,t:1527009089016};\\\", \\\"{x:393,y:535,t:1527009089035};\\\", \\\"{x:393,y:534,t:1527009089056};\\\", \\\"{x:393,y:533,t:1527009089067};\\\", \\\"{x:393,y:532,t:1527009089112};\\\", \\\"{x:393,y:531,t:1527009089128};\\\", \\\"{x:393,y:530,t:1527009089136};\\\", \\\"{x:393,y:529,t:1527009089233};\\\", \\\"{x:393,y:529,t:1527009089340};\\\", \\\"{x:393,y:530,t:1527009089400};\\\", \\\"{x:392,y:535,t:1527009089416};\\\", \\\"{x:391,y:543,t:1527009089434};\\\", \\\"{x:389,y:551,t:1527009089450};\\\", \\\"{x:389,y:556,t:1527009089466};\\\", \\\"{x:389,y:559,t:1527009089484};\\\", \\\"{x:389,y:560,t:1527009089500};\\\", \\\"{x:389,y:561,t:1527009089848};\\\", \\\"{x:390,y:565,t:1527009089856};\\\", \\\"{x:392,y:571,t:1527009089867};\\\", \\\"{x:399,y:586,t:1527009089884};\\\", \\\"{x:409,y:603,t:1527009089900};\\\", \\\"{x:422,y:619,t:1527009089918};\\\", \\\"{x:437,y:638,t:1527009089934};\\\", \\\"{x:450,y:654,t:1527009089951};\\\", \\\"{x:459,y:664,t:1527009089968};\\\", \\\"{x:464,y:669,t:1527009089983};\\\", \\\"{x:467,y:671,t:1527009090001};\\\", \\\"{x:468,y:671,t:1527009090025};\\\", \\\"{x:468,y:672,t:1527009090041};\\\", \\\"{x:469,y:673,t:1527009090057};\\\", \\\"{x:470,y:674,t:1527009090073};\\\", \\\"{x:470,y:675,t:1527009090084};\\\", \\\"{x:473,y:678,t:1527009090100};\\\", \\\"{x:479,y:683,t:1527009090117};\\\", \\\"{x:486,y:688,t:1527009090134};\\\", \\\"{x:495,y:696,t:1527009090150};\\\", \\\"{x:506,y:706,t:1527009090168};\\\", \\\"{x:517,y:715,t:1527009090183};\\\", \\\"{x:529,y:721,t:1527009090200};\\\", \\\"{x:533,y:725,t:1527009090218};\\\", \\\"{x:534,y:726,t:1527009090235};\\\", \\\"{x:536,y:727,t:1527009090250};\\\", \\\"{x:536,y:728,t:1527009090569};\\\", \\\"{x:536,y:730,t:1527009090593};\\\", \\\"{x:537,y:731,t:1527009091353};\\\", \\\"{x:538,y:731,t:1527009091377};\\\", \\\"{x:539,y:731,t:1527009091419};\\\", \\\"{x:539,y:731,t:1527009091524};\\\", \\\"{x:539,y:730,t:1527009091568};\\\", \\\"{x:538,y:728,t:1527009091586};\\\", \\\"{x:538,y:727,t:1527009091601};\\\", \\\"{x:538,y:726,t:1527009091618};\\\", \\\"{x:537,y:725,t:1527009091680};\\\", \\\"{x:536,y:724,t:1527009091696};\\\", \\\"{x:535,y:723,t:1527009091712};\\\", \\\"{x:534,y:723,t:1527009091761};\\\", \\\"{x:533,y:722,t:1527009091769};\\\", \\\"{x:532,y:721,t:1527009091833};\\\", \\\"{x:531,y:720,t:1527009091865};\\\", \\\"{x:530,y:719,t:1527009091873};\\\", \\\"{x:530,y:718,t:1527009091886};\\\", \\\"{x:530,y:717,t:1527009091902};\\\", \\\"{x:529,y:716,t:1527009091918};\\\", \\\"{x:529,y:715,t:1527009091945};\\\", \\\"{x:529,y:714,t:1527009091961};\\\", \\\"{x:529,y:713,t:1527009091968};\\\", \\\"{x:529,y:712,t:1527009092009};\\\", \\\"{x:529,y:711,t:1527009092019};\\\", \\\"{x:527,y:709,t:1527009092036};\\\", \\\"{x:527,y:707,t:1527009092409};\\\", \\\"{x:527,y:704,t:1527009092419};\\\", \\\"{x:527,y:702,t:1527009092436};\\\", \\\"{x:528,y:700,t:1527009092453};\\\", \\\"{x:529,y:698,t:1527009092470};\\\", \\\"{x:530,y:697,t:1527009092486};\\\", \\\"{x:530,y:696,t:1527009092576};\\\", \\\"{x:531,y:695,t:1527009092592};\\\", \\\"{x:531,y:693,t:1527009092608};\\\" ] }, { \\\"rt\\\": 12758, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 8, \\\"time_elapsed\\\": 279927, \\\"internal_node_id\\\": \\\"0.0-5.0-3.0\\\", \\\"subject\\\": \\\"38NFJ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"echo\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 4, \\\"clicks\\\": 3, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"H\\\", \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-04 PM-04 PM-03 PM\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:534,y:680,t:1527009092743};\\\", \\\"{x:535,y:674,t:1527009092769};\\\", \\\"{x:535,y:673,t:1527009092786};\\\", \\\"{x:535,y:672,t:1527009092802};\\\", \\\"{x:535,y:670,t:1527009092834};\\\", \\\"{x:535,y:669,t:1527009092852};\\\", \\\"{x:535,y:668,t:1527009092870};\\\", \\\"{x:535,y:667,t:1527009092885};\\\", \\\"{x:537,y:666,t:1527009093057};\\\", \\\"{x:539,y:666,t:1527009093070};\\\", \\\"{x:544,y:665,t:1527009093087};\\\", \\\"{x:546,y:665,t:1527009093113};\\\", \\\"{x:572,y:659,t:1527009093207};\\\", \\\"{x:577,y:655,t:1527009093219};\\\", \\\"{x:587,y:647,t:1527009093237};\\\", \\\"{x:591,y:641,t:1527009093253};\\\", \\\"{x:599,y:635,t:1527009093270};\\\", \\\"{x:607,y:628,t:1527009093287};\\\", \\\"{x:615,y:622,t:1527009093303};\\\", \\\"{x:626,y:614,t:1527009093320};\\\", \\\"{x:634,y:606,t:1527009093336};\\\", \\\"{x:637,y:600,t:1527009093353};\\\", \\\"{x:642,y:589,t:1527009093369};\\\", \\\"{x:648,y:579,t:1527009093387};\\\", \\\"{x:653,y:570,t:1527009093403};\\\", \\\"{x:659,y:563,t:1527009093420};\\\", \\\"{x:664,y:556,t:1527009093436};\\\", \\\"{x:668,y:550,t:1527009093454};\\\", \\\"{x:670,y:546,t:1527009093469};\\\", \\\"{x:673,y:540,t:1527009093487};\\\", \\\"{x:676,y:532,t:1527009093504};\\\", \\\"{x:681,y:525,t:1527009093519};\\\", \\\"{x:690,y:512,t:1527009093536};\\\", \\\"{x:698,y:501,t:1527009093554};\\\", \\\"{x:711,y:487,t:1527009093570};\\\", \\\"{x:722,y:476,t:1527009093587};\\\", \\\"{x:729,y:467,t:1527009093603};\\\", \\\"{x:733,y:462,t:1527009093620};\\\", \\\"{x:737,y:459,t:1527009093637};\\\", \\\"{x:741,y:453,t:1527009093652};\\\", \\\"{x:744,y:447,t:1527009093670};\\\", \\\"{x:751,y:440,t:1527009093687};\\\", \\\"{x:760,y:432,t:1527009093703};\\\", \\\"{x:766,y:426,t:1527009093720};\\\", \\\"{x:770,y:422,t:1527009093736};\\\", \\\"{x:774,y:417,t:1527009093753};\\\", \\\"{x:776,y:416,t:1527009093770};\\\", \\\"{x:776,y:415,t:1527009093786};\\\", \\\"{x:777,y:415,t:1527009093803};\\\", \\\"{x:783,y:414,t:1527009094073};\\\", \\\"{x:797,y:414,t:1527009094086};\\\", \\\"{x:847,y:414,t:1527009094102};\\\", \\\"{x:925,y:435,t:1527009094119};\\\", \\\"{x:997,y:455,t:1527009094136};\\\", \\\"{x:1084,y:482,t:1527009094152};\\\", \\\"{x:1207,y:525,t:1527009094169};\\\", \\\"{x:1293,y:546,t:1527009094185};\\\", \\\"{x:1361,y:571,t:1527009094202};\\\", \\\"{x:1419,y:597,t:1527009094219};\\\", \\\"{x:1452,y:617,t:1527009094235};\\\", \\\"{x:1470,y:631,t:1527009094253};\\\", \\\"{x:1481,y:642,t:1527009094268};\\\", \\\"{x:1486,y:650,t:1527009094285};\\\", \\\"{x:1489,y:660,t:1527009094302};\\\", \\\"{x:1494,y:672,t:1527009094318};\\\", \\\"{x:1501,y:685,t:1527009094335};\\\", \\\"{x:1506,y:698,t:1527009094353};\\\", \\\"{x:1512,y:714,t:1527009094368};\\\", \\\"{x:1517,y:732,t:1527009094385};\\\", \\\"{x:1520,y:739,t:1527009094401};\\\", \\\"{x:1521,y:748,t:1527009094419};\\\", \\\"{x:1524,y:757,t:1527009094435};\\\", \\\"{x:1527,y:770,t:1527009094451};\\\", \\\"{x:1530,y:780,t:1527009094469};\\\", \\\"{x:1535,y:793,t:1527009094486};\\\", \\\"{x:1540,y:804,t:1527009094501};\\\", \\\"{x:1543,y:815,t:1527009094518};\\\", \\\"{x:1547,y:825,t:1527009094534};\\\", \\\"{x:1552,y:840,t:1527009094551};\\\", \\\"{x:1559,y:860,t:1527009094568};\\\", \\\"{x:1567,y:879,t:1527009094584};\\\", \\\"{x:1585,y:905,t:1527009094602};\\\", \\\"{x:1596,y:920,t:1527009094618};\\\", \\\"{x:1604,y:930,t:1527009094634};\\\", \\\"{x:1610,y:939,t:1527009094651};\\\", \\\"{x:1618,y:947,t:1527009094668};\\\", \\\"{x:1624,y:955,t:1527009094684};\\\", \\\"{x:1634,y:964,t:1527009094702};\\\", \\\"{x:1641,y:970,t:1527009094717};\\\", \\\"{x:1646,y:974,t:1527009094734};\\\", \\\"{x:1649,y:976,t:1527009094751};\\\", \\\"{x:1650,y:977,t:1527009094769};\\\", \\\"{x:1650,y:978,t:1527009094809};\\\", \\\"{x:1650,y:979,t:1527009094833};\\\", \\\"{x:1650,y:980,t:1527009094946};\\\", \\\"{x:1650,y:981,t:1527009094977};\\\", \\\"{x:1649,y:981,t:1527009094985};\\\", \\\"{x:1647,y:981,t:1527009095000};\\\", \\\"{x:1645,y:981,t:1527009095016};\\\", \\\"{x:1639,y:981,t:1527009095033};\\\", \\\"{x:1638,y:981,t:1527009095057};\\\", \\\"{x:1636,y:980,t:1527009095081};\\\", \\\"{x:1635,y:979,t:1527009095113};\\\", \\\"{x:1634,y:979,t:1527009095137};\\\", \\\"{x:1633,y:979,t:1527009095150};\\\", \\\"{x:1632,y:978,t:1527009095169};\\\", \\\"{x:1631,y:978,t:1527009095185};\\\", \\\"{x:1631,y:977,t:1527009095199};\\\", \\\"{x:1629,y:977,t:1527009095217};\\\", \\\"{x:1623,y:975,t:1527009095233};\\\", \\\"{x:1620,y:973,t:1527009095248};\\\", \\\"{x:1616,y:973,t:1527009095266};\\\", \\\"{x:1613,y:972,t:1527009095282};\\\", \\\"{x:1612,y:971,t:1527009095305};\\\", \\\"{x:1613,y:971,t:1527009095785};\\\", \\\"{x:1614,y:970,t:1527009095842};\\\", \\\"{x:1615,y:969,t:1527009095848};\\\", \\\"{x:1615,y:968,t:1527009095937};\\\", \\\"{x:1615,y:967,t:1527009095947};\\\", \\\"{x:1615,y:966,t:1527009095964};\\\", \\\"{x:1615,y:965,t:1527009095981};\\\", \\\"{x:1615,y:964,t:1527009095996};\\\", \\\"{x:1615,y:963,t:1527009096014};\\\", \\\"{x:1614,y:963,t:1527009097778};\\\", \\\"{x:1614,y:964,t:1527009099890};\\\", \\\"{x:1616,y:964,t:1527009099905};\\\", \\\"{x:1616,y:965,t:1527009099922};\\\", \\\"{x:1616,y:966,t:1527009100001};\\\", \\\"{x:1616,y:967,t:1527009100041};\\\", \\\"{x:1614,y:968,t:1527009100921};\\\", \\\"{x:1607,y:970,t:1527009100935};\\\", \\\"{x:1584,y:972,t:1527009100952};\\\", \\\"{x:1534,y:972,t:1527009100969};\\\", \\\"{x:1375,y:963,t:1527009100985};\\\", \\\"{x:1236,y:942,t:1527009101001};\\\", \\\"{x:1097,y:916,t:1527009101019};\\\", \\\"{x:971,y:893,t:1527009101035};\\\", \\\"{x:871,y:879,t:1527009101051};\\\", \\\"{x:807,y:860,t:1527009101067};\\\", \\\"{x:749,y:843,t:1527009101084};\\\", \\\"{x:707,y:832,t:1527009101102};\\\", \\\"{x:675,y:822,t:1527009101117};\\\", \\\"{x:655,y:819,t:1527009101135};\\\", \\\"{x:638,y:815,t:1527009101150};\\\", \\\"{x:608,y:807,t:1527009101167};\\\", \\\"{x:552,y:790,t:1527009101185};\\\", \\\"{x:488,y:775,t:1527009101200};\\\", \\\"{x:406,y:747,t:1527009101217};\\\", \\\"{x:375,y:727,t:1527009101234};\\\", \\\"{x:359,y:706,t:1527009101250};\\\", \\\"{x:355,y:687,t:1527009101267};\\\", \\\"{x:354,y:672,t:1527009101284};\\\", \\\"{x:354,y:662,t:1527009101300};\\\", \\\"{x:355,y:655,t:1527009101317};\\\", \\\"{x:355,y:651,t:1527009101333};\\\", \\\"{x:355,y:648,t:1527009101352};\\\", \\\"{x:355,y:647,t:1527009101367};\\\", \\\"{x:357,y:643,t:1527009101383};\\\", \\\"{x:358,y:641,t:1527009101402};\\\", \\\"{x:361,y:637,t:1527009101419};\\\", \\\"{x:363,y:632,t:1527009101435};\\\", \\\"{x:369,y:626,t:1527009101453};\\\", \\\"{x:372,y:621,t:1527009101469};\\\", \\\"{x:374,y:616,t:1527009101486};\\\", \\\"{x:375,y:611,t:1527009101504};\\\", \\\"{x:377,y:606,t:1527009101527};\\\", \\\"{x:378,y:601,t:1527009101543};\\\", \\\"{x:380,y:594,t:1527009101560};\\\", \\\"{x:382,y:588,t:1527009101576};\\\", \\\"{x:382,y:581,t:1527009101594};\\\", \\\"{x:382,y:576,t:1527009101610};\\\", \\\"{x:382,y:571,t:1527009101628};\\\", \\\"{x:383,y:565,t:1527009101643};\\\", \\\"{x:384,y:557,t:1527009101660};\\\", \\\"{x:385,y:553,t:1527009101676};\\\", \\\"{x:386,y:549,t:1527009101693};\\\", \\\"{x:387,y:548,t:1527009101710};\\\", \\\"{x:387,y:547,t:1527009101776};\\\", \\\"{x:388,y:547,t:1527009101792};\\\", \\\"{x:389,y:547,t:1527009101810};\\\", \\\"{x:392,y:549,t:1527009101827};\\\", \\\"{x:394,y:554,t:1527009101843};\\\", \\\"{x:394,y:560,t:1527009101860};\\\", \\\"{x:394,y:565,t:1527009101877};\\\", \\\"{x:394,y:572,t:1527009101893};\\\", \\\"{x:394,y:580,t:1527009101910};\\\", \\\"{x:396,y:588,t:1527009101926};\\\", \\\"{x:396,y:590,t:1527009101943};\\\", \\\"{x:400,y:592,t:1527009101960};\\\", \\\"{x:407,y:592,t:1527009101977};\\\", \\\"{x:428,y:592,t:1527009101993};\\\", \\\"{x:458,y:583,t:1527009102010};\\\", \\\"{x:502,y:571,t:1527009102028};\\\", \\\"{x:553,y:556,t:1527009102043};\\\", \\\"{x:607,y:546,t:1527009102060};\\\", \\\"{x:636,y:541,t:1527009102077};\\\", \\\"{x:653,y:539,t:1527009102094};\\\", \\\"{x:658,y:537,t:1527009102110};\\\", \\\"{x:659,y:537,t:1527009102127};\\\", \\\"{x:660,y:537,t:1527009102143};\\\", \\\"{x:659,y:538,t:1527009102225};\\\", \\\"{x:658,y:539,t:1527009102232};\\\", \\\"{x:654,y:542,t:1527009102244};\\\", \\\"{x:644,y:550,t:1527009102261};\\\", \\\"{x:635,y:557,t:1527009102277};\\\", \\\"{x:630,y:560,t:1527009102294};\\\", \\\"{x:625,y:563,t:1527009102309};\\\", \\\"{x:622,y:564,t:1527009102326};\\\", \\\"{x:618,y:565,t:1527009102344};\\\", \\\"{x:617,y:565,t:1527009102384};\\\", \\\"{x:616,y:565,t:1527009102569};\\\", \\\"{x:618,y:565,t:1527009102584};\\\", \\\"{x:619,y:565,t:1527009102600};\\\", \\\"{x:621,y:565,t:1527009102616};\\\", \\\"{x:621,y:565,t:1527009102664};\\\", \\\"{x:621,y:570,t:1527009102721};\\\", \\\"{x:621,y:574,t:1527009102728};\\\", \\\"{x:618,y:583,t:1527009102744};\\\", \\\"{x:617,y:592,t:1527009102761};\\\", \\\"{x:614,y:601,t:1527009102777};\\\", \\\"{x:613,y:607,t:1527009102794};\\\", \\\"{x:613,y:612,t:1527009102811};\\\", \\\"{x:613,y:616,t:1527009102827};\\\", \\\"{x:613,y:618,t:1527009102844};\\\", \\\"{x:612,y:623,t:1527009102861};\\\", \\\"{x:612,y:626,t:1527009102877};\\\", \\\"{x:611,y:631,t:1527009102893};\\\", \\\"{x:611,y:633,t:1527009102911};\\\", \\\"{x:610,y:635,t:1527009102928};\\\", \\\"{x:609,y:635,t:1527009102993};\\\", \\\"{x:607,y:635,t:1527009103025};\\\", \\\"{x:607,y:629,t:1527009103033};\\\", \\\"{x:606,y:620,t:1527009103045};\\\", \\\"{x:605,y:605,t:1527009103063};\\\", \\\"{x:605,y:594,t:1527009103078};\\\", \\\"{x:605,y:583,t:1527009103094};\\\", \\\"{x:605,y:577,t:1527009103111};\\\", \\\"{x:605,y:575,t:1527009103128};\\\", \\\"{x:606,y:576,t:1527009103168};\\\", \\\"{x:610,y:584,t:1527009103178};\\\", \\\"{x:614,y:599,t:1527009103194};\\\", \\\"{x:617,y:610,t:1527009103211};\\\", \\\"{x:617,y:619,t:1527009103229};\\\", \\\"{x:619,y:626,t:1527009103244};\\\", \\\"{x:619,y:628,t:1527009103361};\\\", \\\"{x:619,y:632,t:1527009103378};\\\", \\\"{x:618,y:637,t:1527009103395};\\\", \\\"{x:615,y:642,t:1527009103411};\\\", \\\"{x:615,y:647,t:1527009103429};\\\", \\\"{x:614,y:647,t:1527009103445};\\\", \\\"{x:614,y:648,t:1527009103461};\\\", \\\"{x:613,y:648,t:1527009103478};\\\", \\\"{x:612,y:648,t:1527009103561};\\\", \\\"{x:608,y:648,t:1527009103585};\\\", \\\"{x:608,y:647,t:1527009103593};\\\", \\\"{x:608,y:647,t:1527009103594};\\\", \\\"{x:607,y:647,t:1527009103611};\\\", \\\"{x:607,y:645,t:1527009103629};\\\", \\\"{x:607,y:644,t:1527009103645};\\\", \\\"{x:607,y:643,t:1527009103661};\\\", \\\"{x:607,y:642,t:1527009103678};\\\", \\\"{x:607,y:641,t:1527009103695};\\\", \\\"{x:607,y:638,t:1527009103711};\\\", \\\"{x:607,y:635,t:1527009103728};\\\", \\\"{x:607,y:628,t:1527009103745};\\\", \\\"{x:607,y:624,t:1527009103762};\\\", \\\"{x:607,y:623,t:1527009103873};\\\", \\\"{x:608,y:623,t:1527009104096};\\\", \\\"{x:609,y:622,t:1527009104112};\\\", \\\"{x:612,y:619,t:1527009104128};\\\", \\\"{x:613,y:615,t:1527009104145};\\\", \\\"{x:614,y:610,t:1527009104162};\\\", \\\"{x:615,y:604,t:1527009104179};\\\", \\\"{x:616,y:599,t:1527009104195};\\\", \\\"{x:617,y:593,t:1527009104211};\\\", \\\"{x:618,y:587,t:1527009104229};\\\", \\\"{x:619,y:585,t:1527009104245};\\\", \\\"{x:619,y:583,t:1527009104262};\\\", \\\"{x:619,y:580,t:1527009104280};\\\", \\\"{x:619,y:578,t:1527009104295};\\\", \\\"{x:619,y:573,t:1527009104313};\\\", \\\"{x:619,y:566,t:1527009104328};\\\", \\\"{x:619,y:563,t:1527009104345};\\\", \\\"{x:619,y:562,t:1527009104362};\\\", \\\"{x:619,y:560,t:1527009104408};\\\", \\\"{x:619,y:559,t:1527009104424};\\\", \\\"{x:619,y:556,t:1527009104440};\\\", \\\"{x:619,y:554,t:1527009104448};\\\", \\\"{x:619,y:552,t:1527009104462};\\\", \\\"{x:619,y:548,t:1527009104479};\\\", \\\"{x:619,y:549,t:1527009104760};\\\", \\\"{x:618,y:551,t:1527009104768};\\\", \\\"{x:618,y:553,t:1527009104779};\\\", \\\"{x:616,y:559,t:1527009104796};\\\", \\\"{x:616,y:561,t:1527009104812};\\\", \\\"{x:616,y:562,t:1527009104829};\\\", \\\"{x:616,y:564,t:1527009104846};\\\", \\\"{x:615,y:567,t:1527009104862};\\\", \\\"{x:610,y:579,t:1527009104880};\\\", \\\"{x:598,y:607,t:1527009104896};\\\", \\\"{x:588,y:628,t:1527009104913};\\\", \\\"{x:576,y:648,t:1527009104929};\\\", \\\"{x:562,y:667,t:1527009104946};\\\", \\\"{x:549,y:684,t:1527009104962};\\\", \\\"{x:533,y:703,t:1527009104979};\\\", \\\"{x:521,y:721,t:1527009104996};\\\", \\\"{x:512,y:733,t:1527009105012};\\\", \\\"{x:501,y:747,t:1527009105029};\\\", \\\"{x:494,y:757,t:1527009105046};\\\", \\\"{x:490,y:763,t:1527009105062};\\\", \\\"{x:489,y:764,t:1527009105079};\\\", \\\"{x:488,y:764,t:1527009105120};\\\", \\\"{x:486,y:764,t:1527009105136};\\\", \\\"{x:485,y:764,t:1527009105185};\\\", \\\"{x:485,y:762,t:1527009105201};\\\", \\\"{x:485,y:759,t:1527009105213};\\\", \\\"{x:487,y:750,t:1527009105229};\\\", \\\"{x:493,y:738,t:1527009105246};\\\", \\\"{x:496,y:731,t:1527009105264};\\\", \\\"{x:498,y:728,t:1527009105279};\\\", \\\"{x:499,y:725,t:1527009105296};\\\", \\\"{x:500,y:724,t:1527009105312};\\\", \\\"{x:500,y:723,t:1527009106233};\\\", \\\"{x:500,y:722,t:1527009106248};\\\", \\\"{x:500,y:714,t:1527009106264};\\\", \\\"{x:502,y:709,t:1527009106280};\\\", \\\"{x:502,y:705,t:1527009106297};\\\", \\\"{x:503,y:703,t:1527009106314};\\\", \\\"{x:503,y:702,t:1527009106330};\\\", \\\"{x:503,y:701,t:1527009106347};\\\", \\\"{x:503,y:700,t:1527009106364};\\\" ] }, { \\\"rt\\\": 21978, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 9, \\\"time_elapsed\\\": 303156, \\\"internal_node_id\\\": \\\"0.0-5.0-4.0\\\", \\\"subject\\\": \\\"38NFJ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"echo\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 5, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"A\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-A -A \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:526,y:696,t:1527009108745};\\\", \\\"{x:570,y:696,t:1527009108753};\\\", \\\"{x:617,y:696,t:1527009108765};\\\", \\\"{x:714,y:696,t:1527009108784};\\\", \\\"{x:774,y:699,t:1527009108800};\\\", \\\"{x:824,y:705,t:1527009108815};\\\", \\\"{x:924,y:705,t:1527009108832};\\\", \\\"{x:991,y:705,t:1527009108849};\\\", \\\"{x:1061,y:705,t:1527009108866};\\\", \\\"{x:1118,y:701,t:1527009108883};\\\", \\\"{x:1154,y:692,t:1527009108900};\\\", \\\"{x:1182,y:686,t:1527009108916};\\\", \\\"{x:1212,y:685,t:1527009108933};\\\", \\\"{x:1245,y:685,t:1527009108949};\\\", \\\"{x:1272,y:685,t:1527009108966};\\\", \\\"{x:1293,y:687,t:1527009108982};\\\", \\\"{x:1309,y:691,t:1527009109000};\\\", \\\"{x:1319,y:696,t:1527009109016};\\\", \\\"{x:1324,y:703,t:1527009109033};\\\", \\\"{x:1326,y:717,t:1527009109050};\\\", \\\"{x:1326,y:729,t:1527009109066};\\\", \\\"{x:1326,y:743,t:1527009109083};\\\", \\\"{x:1326,y:753,t:1527009109099};\\\", \\\"{x:1326,y:765,t:1527009109116};\\\", \\\"{x:1326,y:781,t:1527009109133};\\\", \\\"{x:1325,y:791,t:1527009109150};\\\", \\\"{x:1325,y:799,t:1527009109167};\\\", \\\"{x:1325,y:805,t:1527009109182};\\\", \\\"{x:1325,y:811,t:1527009109199};\\\", \\\"{x:1325,y:818,t:1527009109217};\\\", \\\"{x:1326,y:822,t:1527009109233};\\\", \\\"{x:1326,y:825,t:1527009109250};\\\", \\\"{x:1327,y:829,t:1527009109267};\\\", \\\"{x:1327,y:831,t:1527009109289};\\\", \\\"{x:1327,y:832,t:1527009109337};\\\", \\\"{x:1326,y:832,t:1527009109505};\\\", \\\"{x:1325,y:832,t:1527009109521};\\\", \\\"{x:1325,y:831,t:1527009109848};\\\", \\\"{x:1325,y:829,t:1527009109857};\\\", \\\"{x:1327,y:827,t:1527009109866};\\\", \\\"{x:1329,y:825,t:1527009109883};\\\", \\\"{x:1334,y:820,t:1527009109899};\\\", \\\"{x:1336,y:814,t:1527009109916};\\\", \\\"{x:1339,y:809,t:1527009109934};\\\", \\\"{x:1339,y:807,t:1527009109950};\\\", \\\"{x:1340,y:801,t:1527009109967};\\\", \\\"{x:1342,y:796,t:1527009109983};\\\", \\\"{x:1343,y:789,t:1527009110000};\\\", \\\"{x:1343,y:785,t:1527009110017};\\\", \\\"{x:1344,y:783,t:1527009110034};\\\", \\\"{x:1344,y:782,t:1527009110056};\\\", \\\"{x:1344,y:780,t:1527009110209};\\\", \\\"{x:1343,y:780,t:1527009110240};\\\", \\\"{x:1342,y:780,t:1527009110265};\\\", \\\"{x:1340,y:780,t:1527009110273};\\\", \\\"{x:1339,y:781,t:1527009110284};\\\", \\\"{x:1337,y:781,t:1527009110301};\\\", \\\"{x:1336,y:782,t:1527009110317};\\\", \\\"{x:1334,y:783,t:1527009110334};\\\", \\\"{x:1333,y:784,t:1527009110351};\\\", \\\"{x:1331,y:786,t:1527009110367};\\\", \\\"{x:1329,y:787,t:1527009110384};\\\", \\\"{x:1327,y:788,t:1527009110401};\\\", \\\"{x:1327,y:789,t:1527009110416};\\\", \\\"{x:1326,y:789,t:1527009110457};\\\", \\\"{x:1326,y:790,t:1527009110473};\\\", \\\"{x:1325,y:791,t:1527009110484};\\\", \\\"{x:1325,y:792,t:1527009110501};\\\", \\\"{x:1324,y:792,t:1527009110517};\\\", \\\"{x:1324,y:793,t:1527009110553};\\\", \\\"{x:1323,y:794,t:1527009110568};\\\", \\\"{x:1324,y:796,t:1527009114657};\\\", \\\"{x:1326,y:798,t:1527009114669};\\\", \\\"{x:1329,y:803,t:1527009114687};\\\", \\\"{x:1331,y:806,t:1527009114704};\\\", \\\"{x:1333,y:808,t:1527009114721};\\\", \\\"{x:1339,y:818,t:1527009114737};\\\", \\\"{x:1342,y:824,t:1527009114754};\\\", \\\"{x:1350,y:834,t:1527009114770};\\\", \\\"{x:1365,y:845,t:1527009114788};\\\", \\\"{x:1379,y:856,t:1527009114804};\\\", \\\"{x:1389,y:864,t:1527009114820};\\\", \\\"{x:1395,y:868,t:1527009114837};\\\", \\\"{x:1391,y:868,t:1527009114898};\\\", \\\"{x:1386,y:867,t:1527009114905};\\\", \\\"{x:1371,y:860,t:1527009114921};\\\", \\\"{x:1353,y:847,t:1527009114937};\\\", \\\"{x:1336,y:834,t:1527009114954};\\\", \\\"{x:1321,y:822,t:1527009114971};\\\", \\\"{x:1310,y:809,t:1527009114987};\\\", \\\"{x:1300,y:797,t:1527009115004};\\\", \\\"{x:1293,y:788,t:1527009115021};\\\", \\\"{x:1290,y:784,t:1527009115037};\\\", \\\"{x:1289,y:782,t:1527009115053};\\\", \\\"{x:1288,y:781,t:1527009115070};\\\", \\\"{x:1288,y:779,t:1527009115096};\\\", \\\"{x:1288,y:778,t:1527009115104};\\\", \\\"{x:1288,y:775,t:1527009115120};\\\", \\\"{x:1288,y:774,t:1527009115136};\\\", \\\"{x:1288,y:772,t:1527009115153};\\\", \\\"{x:1288,y:770,t:1527009115170};\\\", \\\"{x:1292,y:767,t:1527009115186};\\\", \\\"{x:1294,y:767,t:1527009115204};\\\", \\\"{x:1297,y:765,t:1527009115221};\\\", \\\"{x:1303,y:764,t:1527009115237};\\\", \\\"{x:1309,y:761,t:1527009115256};\\\", \\\"{x:1313,y:761,t:1527009115270};\\\", \\\"{x:1316,y:760,t:1527009115287};\\\", \\\"{x:1317,y:760,t:1527009115304};\\\", \\\"{x:1318,y:760,t:1527009115321};\\\", \\\"{x:1319,y:760,t:1527009115337};\\\", \\\"{x:1321,y:760,t:1527009115355};\\\", \\\"{x:1322,y:760,t:1527009115376};\\\", \\\"{x:1323,y:760,t:1527009115400};\\\", \\\"{x:1323,y:761,t:1527009115649};\\\", \\\"{x:1323,y:765,t:1527009116377};\\\", \\\"{x:1324,y:768,t:1527009116388};\\\", \\\"{x:1328,y:778,t:1527009116405};\\\", \\\"{x:1334,y:787,t:1527009116422};\\\", \\\"{x:1339,y:795,t:1527009116439};\\\", \\\"{x:1344,y:805,t:1527009116455};\\\", \\\"{x:1349,y:813,t:1527009116472};\\\", \\\"{x:1353,y:819,t:1527009116489};\\\", \\\"{x:1360,y:830,t:1527009116505};\\\", \\\"{x:1364,y:836,t:1527009116522};\\\", \\\"{x:1366,y:841,t:1527009116537};\\\", \\\"{x:1368,y:844,t:1527009116554};\\\", \\\"{x:1369,y:847,t:1527009116571};\\\", \\\"{x:1369,y:851,t:1527009116587};\\\", \\\"{x:1371,y:853,t:1527009116605};\\\", \\\"{x:1371,y:854,t:1527009116621};\\\", \\\"{x:1372,y:856,t:1527009116638};\\\", \\\"{x:1373,y:858,t:1527009116655};\\\", \\\"{x:1373,y:859,t:1527009116672};\\\", \\\"{x:1373,y:860,t:1527009116687};\\\", \\\"{x:1373,y:862,t:1527009116704};\\\", \\\"{x:1373,y:863,t:1527009116722};\\\", \\\"{x:1373,y:864,t:1527009116737};\\\", \\\"{x:1373,y:865,t:1527009116768};\\\", \\\"{x:1373,y:866,t:1527009116945};\\\", \\\"{x:1375,y:866,t:1527009116969};\\\", \\\"{x:1375,y:865,t:1527009117009};\\\", \\\"{x:1376,y:865,t:1527009117022};\\\", \\\"{x:1376,y:864,t:1527009117039};\\\", \\\"{x:1376,y:862,t:1527009117055};\\\", \\\"{x:1376,y:861,t:1527009117073};\\\", \\\"{x:1377,y:859,t:1527009117089};\\\", \\\"{x:1378,y:856,t:1527009117105};\\\", \\\"{x:1378,y:855,t:1527009117122};\\\", \\\"{x:1378,y:854,t:1527009117139};\\\", \\\"{x:1378,y:851,t:1527009117155};\\\", \\\"{x:1378,y:849,t:1527009117172};\\\", \\\"{x:1378,y:844,t:1527009117190};\\\", \\\"{x:1381,y:838,t:1527009117205};\\\", \\\"{x:1381,y:832,t:1527009117222};\\\", \\\"{x:1381,y:825,t:1527009117239};\\\", \\\"{x:1382,y:815,t:1527009117256};\\\", \\\"{x:1385,y:803,t:1527009117272};\\\", \\\"{x:1386,y:785,t:1527009117289};\\\", \\\"{x:1386,y:775,t:1527009117306};\\\", \\\"{x:1386,y:769,t:1527009117322};\\\", \\\"{x:1387,y:766,t:1527009117339};\\\", \\\"{x:1388,y:762,t:1527009117356};\\\", \\\"{x:1388,y:759,t:1527009117372};\\\", \\\"{x:1388,y:756,t:1527009117390};\\\", \\\"{x:1388,y:755,t:1527009117406};\\\", \\\"{x:1387,y:754,t:1527009117681};\\\", \\\"{x:1385,y:754,t:1527009117689};\\\", \\\"{x:1375,y:754,t:1527009117706};\\\", \\\"{x:1358,y:754,t:1527009117723};\\\", \\\"{x:1336,y:754,t:1527009117738};\\\", \\\"{x:1316,y:754,t:1527009117756};\\\", \\\"{x:1299,y:754,t:1527009117773};\\\", \\\"{x:1284,y:754,t:1527009117788};\\\", \\\"{x:1270,y:754,t:1527009117805};\\\", \\\"{x:1264,y:754,t:1527009117822};\\\", \\\"{x:1262,y:754,t:1527009117838};\\\", \\\"{x:1261,y:754,t:1527009117855};\\\", \\\"{x:1260,y:754,t:1527009117896};\\\", \\\"{x:1259,y:754,t:1527009117906};\\\", \\\"{x:1253,y:754,t:1527009117923};\\\", \\\"{x:1243,y:754,t:1527009117939};\\\", \\\"{x:1225,y:754,t:1527009117956};\\\", \\\"{x:1203,y:754,t:1527009117973};\\\", \\\"{x:1177,y:751,t:1527009117988};\\\", \\\"{x:1152,y:749,t:1527009118005};\\\", \\\"{x:1132,y:749,t:1527009118023};\\\", \\\"{x:1112,y:749,t:1527009118039};\\\", \\\"{x:1088,y:749,t:1527009118056};\\\", \\\"{x:1058,y:749,t:1527009118072};\\\", \\\"{x:1043,y:749,t:1527009118089};\\\", \\\"{x:1031,y:748,t:1527009118107};\\\", \\\"{x:1023,y:746,t:1527009118123};\\\", \\\"{x:1017,y:745,t:1527009118139};\\\", \\\"{x:1008,y:744,t:1527009118156};\\\", \\\"{x:999,y:743,t:1527009118173};\\\", \\\"{x:994,y:742,t:1527009118190};\\\", \\\"{x:990,y:741,t:1527009118206};\\\", \\\"{x:987,y:741,t:1527009118224};\\\", \\\"{x:985,y:740,t:1527009118240};\\\", \\\"{x:984,y:740,t:1527009118256};\\\", \\\"{x:982,y:740,t:1527009121153};\\\", \\\"{x:979,y:740,t:1527009121161};\\\", \\\"{x:976,y:740,t:1527009121175};\\\", \\\"{x:968,y:741,t:1527009121193};\\\", \\\"{x:966,y:741,t:1527009121208};\\\", \\\"{x:964,y:742,t:1527009121225};\\\", \\\"{x:963,y:742,t:1527009121242};\\\", \\\"{x:960,y:742,t:1527009121258};\\\", \\\"{x:950,y:742,t:1527009121275};\\\", \\\"{x:936,y:741,t:1527009121292};\\\", \\\"{x:918,y:736,t:1527009121308};\\\", \\\"{x:897,y:734,t:1527009121325};\\\", \\\"{x:867,y:729,t:1527009121343};\\\", \\\"{x:835,y:723,t:1527009121358};\\\", \\\"{x:800,y:715,t:1527009121375};\\\", \\\"{x:750,y:709,t:1527009121393};\\\", \\\"{x:707,y:701,t:1527009121408};\\\", \\\"{x:665,y:696,t:1527009121425};\\\", \\\"{x:640,y:691,t:1527009121442};\\\", \\\"{x:627,y:690,t:1527009121458};\\\", \\\"{x:617,y:687,t:1527009121475};\\\", \\\"{x:610,y:682,t:1527009121493};\\\", \\\"{x:607,y:680,t:1527009121508};\\\", \\\"{x:601,y:670,t:1527009121525};\\\", \\\"{x:587,y:657,t:1527009121542};\\\", \\\"{x:572,y:648,t:1527009121558};\\\", \\\"{x:556,y:640,t:1527009121574};\\\", \\\"{x:535,y:633,t:1527009121589};\\\", \\\"{x:508,y:625,t:1527009121606};\\\", \\\"{x:485,y:623,t:1527009121623};\\\", \\\"{x:455,y:619,t:1527009121643};\\\", \\\"{x:435,y:616,t:1527009121658};\\\", \\\"{x:412,y:612,t:1527009121676};\\\", \\\"{x:393,y:609,t:1527009121693};\\\", \\\"{x:381,y:606,t:1527009121710};\\\", \\\"{x:374,y:603,t:1527009121726};\\\", \\\"{x:370,y:601,t:1527009121743};\\\", \\\"{x:369,y:596,t:1527009121760};\\\", \\\"{x:369,y:590,t:1527009121776};\\\", \\\"{x:370,y:585,t:1527009121793};\\\", \\\"{x:371,y:577,t:1527009121809};\\\", \\\"{x:374,y:572,t:1527009121825};\\\", \\\"{x:377,y:565,t:1527009121843};\\\", \\\"{x:381,y:558,t:1527009121859};\\\", \\\"{x:384,y:552,t:1527009121877};\\\", \\\"{x:387,y:549,t:1527009121893};\\\", \\\"{x:391,y:544,t:1527009121910};\\\", \\\"{x:392,y:540,t:1527009121925};\\\", \\\"{x:393,y:537,t:1527009121943};\\\", \\\"{x:393,y:535,t:1527009121960};\\\", \\\"{x:393,y:534,t:1527009121975};\\\", \\\"{x:394,y:531,t:1527009121993};\\\", \\\"{x:394,y:528,t:1527009122009};\\\", \\\"{x:394,y:527,t:1527009122026};\\\", \\\"{x:393,y:527,t:1527009122600};\\\", \\\"{x:391,y:527,t:1527009122608};\\\", \\\"{x:391,y:527,t:1527009122613};\\\", \\\"{x:390,y:528,t:1527009122626};\\\", \\\"{x:388,y:528,t:1527009122648};\\\", \\\"{x:387,y:528,t:1527009122672};\\\", \\\"{x:387,y:529,t:1527009122687};\\\", \\\"{x:387,y:530,t:1527009122696};\\\", \\\"{x:387,y:531,t:1527009122710};\\\", \\\"{x:387,y:536,t:1527009122727};\\\", \\\"{x:389,y:554,t:1527009122744};\\\", \\\"{x:393,y:567,t:1527009122760};\\\", \\\"{x:396,y:578,t:1527009122777};\\\", \\\"{x:399,y:587,t:1527009122794};\\\", \\\"{x:402,y:599,t:1527009122811};\\\", \\\"{x:406,y:608,t:1527009122827};\\\", \\\"{x:408,y:615,t:1527009122844};\\\", \\\"{x:412,y:624,t:1527009122860};\\\", \\\"{x:412,y:629,t:1527009122877};\\\", \\\"{x:414,y:635,t:1527009122895};\\\", \\\"{x:416,y:638,t:1527009122911};\\\", \\\"{x:417,y:645,t:1527009122926};\\\", \\\"{x:420,y:652,t:1527009122944};\\\", \\\"{x:423,y:657,t:1527009122960};\\\", \\\"{x:425,y:663,t:1527009122976};\\\", \\\"{x:431,y:671,t:1527009122994};\\\", \\\"{x:436,y:681,t:1527009123010};\\\", \\\"{x:443,y:690,t:1527009123027};\\\", \\\"{x:456,y:706,t:1527009123044};\\\", \\\"{x:469,y:720,t:1527009123062};\\\", \\\"{x:482,y:732,t:1527009123077};\\\", \\\"{x:489,y:739,t:1527009123094};\\\", \\\"{x:496,y:744,t:1527009123111};\\\", \\\"{x:503,y:749,t:1527009123127};\\\", \\\"{x:513,y:758,t:1527009123144};\\\", \\\"{x:517,y:761,t:1527009123161};\\\", \\\"{x:519,y:763,t:1527009123177};\\\", \\\"{x:520,y:763,t:1527009123320};\\\", \\\"{x:521,y:762,t:1527009123328};\\\", \\\"{x:521,y:761,t:1527009123344};\\\", \\\"{x:523,y:757,t:1527009123361};\\\", \\\"{x:523,y:756,t:1527009123384};\\\", \\\"{x:523,y:754,t:1527009123409};\\\", \\\"{x:523,y:753,t:1527009123425};\\\", \\\"{x:523,y:752,t:1527009123441};\\\", \\\"{x:523,y:751,t:1527009123456};\\\", \\\"{x:523,y:750,t:1527009123481};\\\", \\\"{x:523,y:749,t:1527009123546};\\\", \\\"{x:523,y:747,t:1527009123561};\\\", \\\"{x:525,y:745,t:1527009123577};\\\", \\\"{x:525,y:744,t:1527009123594};\\\", \\\"{x:525,y:742,t:1527009123611};\\\", \\\"{x:525,y:741,t:1527009123627};\\\", \\\"{x:525,y:739,t:1527009123656};\\\", \\\"{x:525,y:738,t:1527009123680};\\\", \\\"{x:525,y:736,t:1527009123712};\\\", \\\"{x:525,y:735,t:1527009124152};\\\", \\\"{x:524,y:733,t:1527009128490};\\\", \\\"{x:523,y:732,t:1527009128505};\\\", \\\"{x:521,y:731,t:1527009128521};\\\", \\\"{x:520,y:731,t:1527009128529};\\\", \\\"{x:519,y:731,t:1527009128542};\\\" ] }, { \\\"rt\\\": 17117, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 10, \\\"time_elapsed\\\": 321480, \\\"internal_node_id\\\": \\\"0.0-6.0-0.0\\\", \\\"subject\\\": \\\"38NFJ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"echo\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration\\\", \\\"q\\\": 6, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\", \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-08 AM-10 AM-11 AM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:526,y:731,t:1527009136130};\\\", \\\"{x:568,y:731,t:1527009136147};\\\", \\\"{x:616,y:739,t:1527009136153};\\\", \\\"{x:679,y:747,t:1527009136166};\\\", \\\"{x:805,y:758,t:1527009136180};\\\", \\\"{x:944,y:779,t:1527009136196};\\\", \\\"{x:1082,y:798,t:1527009136213};\\\", \\\"{x:1218,y:820,t:1527009136231};\\\", \\\"{x:1334,y:834,t:1527009136246};\\\", \\\"{x:1424,y:851,t:1527009136263};\\\", \\\"{x:1489,y:867,t:1527009136280};\\\", \\\"{x:1497,y:872,t:1527009136296};\\\", \\\"{x:1497,y:874,t:1527009136328};\\\", \\\"{x:1495,y:875,t:1527009136336};\\\", \\\"{x:1491,y:875,t:1527009136346};\\\", \\\"{x:1479,y:881,t:1527009136363};\\\", \\\"{x:1461,y:890,t:1527009136381};\\\", \\\"{x:1442,y:898,t:1527009136396};\\\", \\\"{x:1422,y:907,t:1527009136414};\\\", \\\"{x:1402,y:913,t:1527009136430};\\\", \\\"{x:1377,y:919,t:1527009136447};\\\", \\\"{x:1354,y:926,t:1527009136464};\\\", \\\"{x:1331,y:933,t:1527009136481};\\\", \\\"{x:1306,y:940,t:1527009136497};\\\", \\\"{x:1290,y:945,t:1527009136513};\\\", \\\"{x:1272,y:946,t:1527009136531};\\\", \\\"{x:1252,y:952,t:1527009136547};\\\", \\\"{x:1234,y:955,t:1527009136564};\\\", \\\"{x:1218,y:956,t:1527009136581};\\\", \\\"{x:1200,y:957,t:1527009136598};\\\", \\\"{x:1179,y:957,t:1527009136613};\\\", \\\"{x:1157,y:960,t:1527009136631};\\\", \\\"{x:1135,y:967,t:1527009136647};\\\", \\\"{x:1123,y:971,t:1527009136664};\\\", \\\"{x:1116,y:972,t:1527009136681};\\\", \\\"{x:1115,y:972,t:1527009136713};\\\", \\\"{x:1114,y:973,t:1527009136762};\\\", \\\"{x:1112,y:974,t:1527009136769};\\\", \\\"{x:1110,y:975,t:1527009136781};\\\", \\\"{x:1105,y:976,t:1527009136798};\\\", \\\"{x:1102,y:977,t:1527009136814};\\\", \\\"{x:1101,y:977,t:1527009136831};\\\", \\\"{x:1100,y:978,t:1527009136890};\\\", \\\"{x:1100,y:976,t:1527009136953};\\\", \\\"{x:1101,y:974,t:1527009136969};\\\", \\\"{x:1102,y:974,t:1527009136982};\\\", \\\"{x:1106,y:972,t:1527009136998};\\\", \\\"{x:1114,y:970,t:1527009137015};\\\", \\\"{x:1126,y:967,t:1527009137030};\\\", \\\"{x:1138,y:967,t:1527009137048};\\\", \\\"{x:1142,y:967,t:1527009137065};\\\", \\\"{x:1148,y:968,t:1527009137082};\\\", \\\"{x:1149,y:968,t:1527009137105};\\\", \\\"{x:1150,y:968,t:1527009137115};\\\", \\\"{x:1151,y:968,t:1527009137457};\\\", \\\"{x:1153,y:968,t:1527009137465};\\\", \\\"{x:1160,y:965,t:1527009137481};\\\", \\\"{x:1166,y:964,t:1527009137498};\\\", \\\"{x:1172,y:962,t:1527009137515};\\\", \\\"{x:1180,y:962,t:1527009137532};\\\", \\\"{x:1185,y:961,t:1527009137548};\\\", \\\"{x:1187,y:961,t:1527009137565};\\\", \\\"{x:1190,y:961,t:1527009137582};\\\", \\\"{x:1193,y:961,t:1527009137598};\\\", \\\"{x:1195,y:961,t:1527009137615};\\\", \\\"{x:1199,y:961,t:1527009137632};\\\", \\\"{x:1201,y:962,t:1527009137648};\\\", \\\"{x:1204,y:963,t:1527009137665};\\\", \\\"{x:1206,y:964,t:1527009137681};\\\", \\\"{x:1208,y:965,t:1527009137706};\\\", \\\"{x:1209,y:965,t:1527009137729};\\\", \\\"{x:1211,y:966,t:1527009137744};\\\", \\\"{x:1212,y:966,t:1527009137769};\\\", \\\"{x:1214,y:967,t:1527009137781};\\\", \\\"{x:1216,y:967,t:1527009137797};\\\", \\\"{x:1217,y:969,t:1527009137814};\\\", \\\"{x:1218,y:969,t:1527009137831};\\\", \\\"{x:1219,y:969,t:1527009137848};\\\", \\\"{x:1220,y:969,t:1527009138018};\\\", \\\"{x:1221,y:969,t:1527009138033};\\\", \\\"{x:1222,y:969,t:1527009138049};\\\", \\\"{x:1230,y:969,t:1527009138065};\\\", \\\"{x:1233,y:970,t:1527009138081};\\\", \\\"{x:1237,y:970,t:1527009138100};\\\", \\\"{x:1242,y:970,t:1527009138115};\\\", \\\"{x:1248,y:970,t:1527009138132};\\\", \\\"{x:1257,y:970,t:1527009138149};\\\", \\\"{x:1265,y:970,t:1527009138164};\\\", \\\"{x:1269,y:970,t:1527009138181};\\\", \\\"{x:1273,y:970,t:1527009138199};\\\", \\\"{x:1275,y:970,t:1527009138214};\\\", \\\"{x:1276,y:970,t:1527009138265};\\\", \\\"{x:1277,y:969,t:1527009138281};\\\", \\\"{x:1278,y:969,t:1527009138298};\\\", \\\"{x:1280,y:968,t:1527009138314};\\\", \\\"{x:1283,y:968,t:1527009138331};\\\", \\\"{x:1284,y:966,t:1527009138353};\\\", \\\"{x:1285,y:966,t:1527009138376};\\\", \\\"{x:1286,y:966,t:1527009138392};\\\", \\\"{x:1287,y:966,t:1527009138600};\\\", \\\"{x:1288,y:966,t:1527009138615};\\\", \\\"{x:1290,y:966,t:1527009138631};\\\", \\\"{x:1297,y:965,t:1527009138648};\\\", \\\"{x:1306,y:965,t:1527009138665};\\\", \\\"{x:1318,y:965,t:1527009138682};\\\", \\\"{x:1329,y:965,t:1527009138698};\\\", \\\"{x:1335,y:965,t:1527009138715};\\\", \\\"{x:1339,y:965,t:1527009138732};\\\", \\\"{x:1340,y:965,t:1527009138748};\\\", \\\"{x:1341,y:965,t:1527009138766};\\\", \\\"{x:1343,y:964,t:1527009138783};\\\", \\\"{x:1347,y:962,t:1527009138798};\\\", \\\"{x:1350,y:960,t:1527009138815};\\\", \\\"{x:1351,y:959,t:1527009138832};\\\", \\\"{x:1352,y:959,t:1527009138849};\\\", \\\"{x:1356,y:959,t:1527009139257};\\\", \\\"{x:1359,y:959,t:1527009139265};\\\", \\\"{x:1367,y:959,t:1527009139282};\\\", \\\"{x:1378,y:959,t:1527009139299};\\\", \\\"{x:1392,y:959,t:1527009139315};\\\", \\\"{x:1403,y:961,t:1527009139332};\\\", \\\"{x:1411,y:961,t:1527009139349};\\\", \\\"{x:1415,y:961,t:1527009139365};\\\", \\\"{x:1417,y:961,t:1527009139383};\\\", \\\"{x:1417,y:963,t:1527009139513};\\\", \\\"{x:1416,y:963,t:1527009139554};\\\", \\\"{x:1415,y:963,t:1527009139566};\\\", \\\"{x:1414,y:963,t:1527009139601};\\\", \\\"{x:1416,y:963,t:1527009139738};\\\", \\\"{x:1418,y:963,t:1527009139750};\\\", \\\"{x:1421,y:963,t:1527009139766};\\\", \\\"{x:1426,y:963,t:1527009139782};\\\", \\\"{x:1432,y:962,t:1527009139799};\\\", \\\"{x:1443,y:960,t:1527009139816};\\\", \\\"{x:1446,y:959,t:1527009139833};\\\", \\\"{x:1452,y:959,t:1527009139850};\\\", \\\"{x:1456,y:958,t:1527009139866};\\\", \\\"{x:1457,y:958,t:1527009139883};\\\", \\\"{x:1459,y:958,t:1527009139899};\\\", \\\"{x:1461,y:958,t:1527009139917};\\\", \\\"{x:1464,y:958,t:1527009139934};\\\", \\\"{x:1467,y:958,t:1527009139950};\\\", \\\"{x:1469,y:958,t:1527009139966};\\\", \\\"{x:1472,y:956,t:1527009139983};\\\", \\\"{x:1476,y:956,t:1527009139999};\\\", \\\"{x:1478,y:956,t:1527009140017};\\\", \\\"{x:1480,y:956,t:1527009140033};\\\", \\\"{x:1482,y:956,t:1527009140057};\\\", \\\"{x:1482,y:958,t:1527009140482};\\\", \\\"{x:1482,y:959,t:1527009140497};\\\", \\\"{x:1481,y:960,t:1527009140561};\\\", \\\"{x:1480,y:960,t:1527009140880};\\\", \\\"{x:1473,y:960,t:1527009143458};\\\", \\\"{x:1461,y:960,t:1527009143469};\\\", \\\"{x:1422,y:960,t:1527009143486};\\\", \\\"{x:1371,y:960,t:1527009143503};\\\", \\\"{x:1302,y:960,t:1527009143519};\\\", \\\"{x:1242,y:956,t:1527009143536};\\\", \\\"{x:1132,y:952,t:1527009143553};\\\", \\\"{x:1057,y:952,t:1527009143570};\\\", \\\"{x:996,y:952,t:1527009143586};\\\", \\\"{x:945,y:945,t:1527009143604};\\\", \\\"{x:917,y:944,t:1527009143620};\\\", \\\"{x:892,y:940,t:1527009143636};\\\", \\\"{x:861,y:935,t:1527009143653};\\\", \\\"{x:812,y:932,t:1527009143670};\\\", \\\"{x:775,y:931,t:1527009143686};\\\", \\\"{x:746,y:927,t:1527009143703};\\\", \\\"{x:724,y:925,t:1527009143720};\\\", \\\"{x:707,y:920,t:1527009143736};\\\", \\\"{x:695,y:913,t:1527009143753};\\\", \\\"{x:692,y:909,t:1527009143769};\\\", \\\"{x:688,y:903,t:1527009143786};\\\", \\\"{x:685,y:897,t:1527009143803};\\\", \\\"{x:681,y:887,t:1527009143820};\\\", \\\"{x:673,y:878,t:1527009143836};\\\", \\\"{x:666,y:872,t:1527009143853};\\\", \\\"{x:657,y:866,t:1527009143869};\\\", \\\"{x:649,y:862,t:1527009143886};\\\", \\\"{x:640,y:857,t:1527009143903};\\\", \\\"{x:630,y:852,t:1527009143920};\\\", \\\"{x:616,y:846,t:1527009143936};\\\", \\\"{x:597,y:837,t:1527009143953};\\\", \\\"{x:588,y:834,t:1527009143970};\\\", \\\"{x:577,y:829,t:1527009143987};\\\", \\\"{x:569,y:826,t:1527009144003};\\\", \\\"{x:556,y:820,t:1527009144020};\\\", \\\"{x:542,y:814,t:1527009144036};\\\", \\\"{x:531,y:809,t:1527009144052};\\\", \\\"{x:523,y:806,t:1527009144070};\\\", \\\"{x:518,y:804,t:1527009144087};\\\", \\\"{x:511,y:800,t:1527009144103};\\\", \\\"{x:503,y:795,t:1527009144120};\\\", \\\"{x:485,y:791,t:1527009144137};\\\", \\\"{x:471,y:787,t:1527009144153};\\\", \\\"{x:462,y:786,t:1527009144170};\\\", \\\"{x:456,y:783,t:1527009144187};\\\", \\\"{x:448,y:781,t:1527009144203};\\\", \\\"{x:442,y:780,t:1527009144220};\\\", \\\"{x:437,y:777,t:1527009144237};\\\", \\\"{x:434,y:775,t:1527009144253};\\\", \\\"{x:431,y:772,t:1527009144270};\\\", \\\"{x:425,y:767,t:1527009144287};\\\", \\\"{x:420,y:762,t:1527009144304};\\\", \\\"{x:416,y:758,t:1527009144319};\\\", \\\"{x:408,y:748,t:1527009144337};\\\", \\\"{x:400,y:736,t:1527009144353};\\\", \\\"{x:396,y:730,t:1527009144370};\\\", \\\"{x:395,y:724,t:1527009144387};\\\", \\\"{x:395,y:716,t:1527009144403};\\\", \\\"{x:395,y:705,t:1527009144419};\\\", \\\"{x:395,y:694,t:1527009144437};\\\", \\\"{x:395,y:685,t:1527009144454};\\\", \\\"{x:395,y:676,t:1527009144470};\\\", \\\"{x:394,y:663,t:1527009144487};\\\", \\\"{x:394,y:649,t:1527009144502};\\\", \\\"{x:394,y:635,t:1527009144519};\\\", \\\"{x:394,y:617,t:1527009144536};\\\", \\\"{x:395,y:605,t:1527009144554};\\\", \\\"{x:396,y:593,t:1527009144571};\\\", \\\"{x:397,y:584,t:1527009144587};\\\", \\\"{x:398,y:577,t:1527009144604};\\\", \\\"{x:398,y:571,t:1527009144621};\\\", \\\"{x:398,y:565,t:1527009144636};\\\", \\\"{x:398,y:557,t:1527009144654};\\\", \\\"{x:398,y:554,t:1527009144671};\\\", \\\"{x:392,y:548,t:1527009144686};\\\", \\\"{x:379,y:541,t:1527009144704};\\\", \\\"{x:354,y:535,t:1527009144720};\\\", \\\"{x:306,y:530,t:1527009144736};\\\", \\\"{x:274,y:529,t:1527009144754};\\\", \\\"{x:252,y:527,t:1527009144770};\\\", \\\"{x:235,y:527,t:1527009144786};\\\", \\\"{x:224,y:527,t:1527009144803};\\\", \\\"{x:223,y:527,t:1527009144820};\\\", \\\"{x:223,y:529,t:1527009144865};\\\", \\\"{x:229,y:532,t:1527009144873};\\\", \\\"{x:240,y:532,t:1527009144886};\\\", \\\"{x:288,y:536,t:1527009144904};\\\", \\\"{x:396,y:536,t:1527009144920};\\\", \\\"{x:482,y:536,t:1527009144936};\\\", \\\"{x:563,y:536,t:1527009144954};\\\", \\\"{x:616,y:536,t:1527009144970};\\\", \\\"{x:638,y:536,t:1527009144986};\\\", \\\"{x:641,y:536,t:1527009145004};\\\", \\\"{x:642,y:536,t:1527009145021};\\\", \\\"{x:642,y:534,t:1527009145049};\\\", \\\"{x:641,y:533,t:1527009145056};\\\", \\\"{x:639,y:531,t:1527009145070};\\\", \\\"{x:636,y:528,t:1527009145087};\\\", \\\"{x:631,y:525,t:1527009145104};\\\", \\\"{x:626,y:523,t:1527009145121};\\\", \\\"{x:622,y:520,t:1527009145136};\\\", \\\"{x:613,y:518,t:1527009145154};\\\", \\\"{x:602,y:513,t:1527009145171};\\\", \\\"{x:595,y:510,t:1527009145186};\\\", \\\"{x:590,y:508,t:1527009145203};\\\", \\\"{x:590,y:507,t:1527009145220};\\\", \\\"{x:589,y:506,t:1527009145240};\\\", \\\"{x:589,y:505,t:1527009145297};\\\", \\\"{x:589,y:504,t:1527009145345};\\\", \\\"{x:591,y:503,t:1527009145355};\\\", \\\"{x:593,y:503,t:1527009145372};\\\", \\\"{x:597,y:503,t:1527009145388};\\\", \\\"{x:599,y:503,t:1527009145405};\\\", \\\"{x:600,y:503,t:1527009145425};\\\", \\\"{x:601,y:503,t:1527009145441};\\\", \\\"{x:602,y:503,t:1527009145454};\\\", \\\"{x:603,y:503,t:1527009145489};\\\", \\\"{x:604,y:503,t:1527009145521};\\\", \\\"{x:606,y:503,t:1527009145537};\\\", \\\"{x:607,y:503,t:1527009145553};\\\", \\\"{x:609,y:503,t:1527009145656};\\\", \\\"{x:613,y:503,t:1527009145670};\\\", \\\"{x:625,y:503,t:1527009145687};\\\", \\\"{x:652,y:508,t:1527009145704};\\\", \\\"{x:702,y:517,t:1527009145720};\\\", \\\"{x:734,y:523,t:1527009145738};\\\", \\\"{x:754,y:528,t:1527009145756};\\\", \\\"{x:767,y:533,t:1527009145770};\\\", \\\"{x:779,y:538,t:1527009145787};\\\", \\\"{x:789,y:542,t:1527009145804};\\\", \\\"{x:795,y:543,t:1527009145821};\\\", \\\"{x:798,y:544,t:1527009145838};\\\", \\\"{x:800,y:544,t:1527009145856};\\\", \\\"{x:801,y:544,t:1527009145872};\\\", \\\"{x:802,y:544,t:1527009145888};\\\", \\\"{x:806,y:544,t:1527009145905};\\\", \\\"{x:810,y:544,t:1527009145921};\\\", \\\"{x:811,y:544,t:1527009145944};\\\", \\\"{x:813,y:544,t:1527009145960};\\\", \\\"{x:815,y:544,t:1527009145976};\\\", \\\"{x:816,y:544,t:1527009145988};\\\", \\\"{x:818,y:544,t:1527009146005};\\\", \\\"{x:820,y:544,t:1527009146021};\\\", \\\"{x:821,y:544,t:1527009146037};\\\", \\\"{x:824,y:544,t:1527009146056};\\\", \\\"{x:827,y:544,t:1527009146070};\\\", \\\"{x:828,y:543,t:1527009146088};\\\", \\\"{x:829,y:543,t:1527009146105};\\\", \\\"{x:830,y:543,t:1527009146120};\\\", \\\"{x:831,y:542,t:1527009146177};\\\", \\\"{x:829,y:544,t:1527009146312};\\\", \\\"{x:823,y:549,t:1527009146322};\\\", \\\"{x:795,y:566,t:1527009146338};\\\", \\\"{x:751,y:590,t:1527009146354};\\\", \\\"{x:705,y:615,t:1527009146372};\\\", \\\"{x:649,y:633,t:1527009146388};\\\", \\\"{x:618,y:646,t:1527009146404};\\\", \\\"{x:594,y:658,t:1527009146421};\\\", \\\"{x:571,y:667,t:1527009146438};\\\", \\\"{x:551,y:674,t:1527009146455};\\\", \\\"{x:538,y:680,t:1527009146472};\\\", \\\"{x:531,y:684,t:1527009146488};\\\", \\\"{x:530,y:685,t:1527009146537};\\\", \\\"{x:529,y:686,t:1527009146545};\\\", \\\"{x:527,y:690,t:1527009146555};\\\", \\\"{x:526,y:693,t:1527009146572};\\\", \\\"{x:526,y:697,t:1527009146588};\\\", \\\"{x:526,y:700,t:1527009146605};\\\", \\\"{x:526,y:704,t:1527009146622};\\\", \\\"{x:526,y:706,t:1527009146712};\\\", \\\"{x:526,y:707,t:1527009146721};\\\", \\\"{x:526,y:714,t:1527009146738};\\\", \\\"{x:524,y:721,t:1527009146755};\\\", \\\"{x:523,y:728,t:1527009146772};\\\", \\\"{x:523,y:734,t:1527009146787};\\\", \\\"{x:523,y:737,t:1527009146805};\\\", \\\"{x:523,y:738,t:1527009146832};\\\", \\\"{x:523,y:739,t:1527009146840};\\\", \\\"{x:523,y:740,t:1527009146854};\\\", \\\"{x:523,y:741,t:1527009146872};\\\", \\\"{x:521,y:741,t:1527009147809};\\\", \\\"{x:519,y:740,t:1527009147823};\\\", \\\"{x:517,y:737,t:1527009147841};\\\", \\\"{x:513,y:733,t:1527009147856};\\\", \\\"{x:508,y:729,t:1527009147873};\\\", \\\"{x:502,y:726,t:1527009147889};\\\", \\\"{x:500,y:725,t:1527009147906};\\\", \\\"{x:499,y:725,t:1527009147928};\\\", \\\"{x:497,y:725,t:1527009147945};\\\", \\\"{x:495,y:724,t:1527009147957};\\\", \\\"{x:494,y:723,t:1527009147973};\\\" ] }, { \\\"rt\\\": 34020, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 11, \\\"time_elapsed\\\": 356748, \\\"internal_node_id\\\": \\\"0.0-6.0-1.0\\\", \\\"subject\\\": \\\"38NFJ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"echo\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+starts\\\", \\\"q\\\": 7, \\\"clicks\\\": 2.5, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:498,y:718,t:1527009148295};\\\", \\\"{x:513,y:710,t:1527009148307};\\\", \\\"{x:531,y:707,t:1527009148323};\\\", \\\"{x:557,y:702,t:1527009148339};\\\", \\\"{x:593,y:697,t:1527009148356};\\\", \\\"{x:696,y:691,t:1527009148388};\\\", \\\"{x:751,y:691,t:1527009148406};\\\", \\\"{x:813,y:691,t:1527009148423};\\\", \\\"{x:869,y:691,t:1527009148439};\\\", \\\"{x:933,y:691,t:1527009148456};\\\", \\\"{x:962,y:691,t:1527009148473};\\\", \\\"{x:979,y:691,t:1527009148490};\\\", \\\"{x:985,y:691,t:1527009148507};\\\", \\\"{x:986,y:691,t:1527009148536};\\\", \\\"{x:988,y:691,t:1527009150361};\\\", \\\"{x:991,y:689,t:1527009150375};\\\", \\\"{x:998,y:685,t:1527009150391};\\\", \\\"{x:1014,y:681,t:1527009150409};\\\", \\\"{x:1035,y:680,t:1527009150425};\\\", \\\"{x:1059,y:680,t:1527009150442};\\\", \\\"{x:1081,y:680,t:1527009150459};\\\", \\\"{x:1104,y:686,t:1527009150475};\\\", \\\"{x:1124,y:696,t:1527009150491};\\\", \\\"{x:1147,y:706,t:1527009150508};\\\", \\\"{x:1171,y:715,t:1527009150525};\\\", \\\"{x:1188,y:724,t:1527009150540};\\\", \\\"{x:1204,y:730,t:1527009150558};\\\", \\\"{x:1223,y:739,t:1527009150575};\\\", \\\"{x:1244,y:750,t:1527009150590};\\\", \\\"{x:1268,y:763,t:1527009150608};\\\", \\\"{x:1311,y:786,t:1527009150624};\\\", \\\"{x:1339,y:795,t:1527009150641};\\\", \\\"{x:1366,y:805,t:1527009150657};\\\", \\\"{x:1384,y:811,t:1527009150675};\\\", \\\"{x:1395,y:815,t:1527009150691};\\\", \\\"{x:1401,y:819,t:1527009150708};\\\", \\\"{x:1401,y:822,t:1527009150725};\\\", \\\"{x:1403,y:825,t:1527009150742};\\\", \\\"{x:1403,y:829,t:1527009150758};\\\", \\\"{x:1403,y:830,t:1527009150775};\\\", \\\"{x:1402,y:833,t:1527009150792};\\\", \\\"{x:1399,y:835,t:1527009150808};\\\", \\\"{x:1394,y:838,t:1527009150824};\\\", \\\"{x:1387,y:840,t:1527009150842};\\\", \\\"{x:1378,y:844,t:1527009150858};\\\", \\\"{x:1372,y:847,t:1527009150875};\\\", \\\"{x:1361,y:850,t:1527009150892};\\\", \\\"{x:1351,y:853,t:1527009150908};\\\", \\\"{x:1344,y:856,t:1527009150925};\\\", \\\"{x:1339,y:858,t:1527009150942};\\\", \\\"{x:1336,y:859,t:1527009150958};\\\", \\\"{x:1335,y:860,t:1527009151009};\\\", \\\"{x:1334,y:861,t:1527009151025};\\\", \\\"{x:1334,y:862,t:1527009151042};\\\", \\\"{x:1333,y:865,t:1527009151058};\\\", \\\"{x:1333,y:869,t:1527009151075};\\\", \\\"{x:1333,y:874,t:1527009151092};\\\", \\\"{x:1333,y:878,t:1527009151109};\\\", \\\"{x:1333,y:882,t:1527009151125};\\\", \\\"{x:1333,y:886,t:1527009151142};\\\", \\\"{x:1333,y:889,t:1527009151158};\\\", \\\"{x:1333,y:893,t:1527009151175};\\\", \\\"{x:1333,y:896,t:1527009151192};\\\", \\\"{x:1333,y:900,t:1527009151208};\\\", \\\"{x:1335,y:907,t:1527009151225};\\\", \\\"{x:1335,y:908,t:1527009151242};\\\", \\\"{x:1336,y:910,t:1527009151260};\\\", \\\"{x:1336,y:913,t:1527009151275};\\\", \\\"{x:1336,y:915,t:1527009151292};\\\", \\\"{x:1337,y:916,t:1527009151309};\\\", \\\"{x:1337,y:919,t:1527009151325};\\\", \\\"{x:1337,y:921,t:1527009151342};\\\", \\\"{x:1337,y:923,t:1527009151359};\\\", \\\"{x:1337,y:924,t:1527009151376};\\\", \\\"{x:1337,y:925,t:1527009151392};\\\", \\\"{x:1337,y:927,t:1527009151409};\\\", \\\"{x:1337,y:929,t:1527009151425};\\\", \\\"{x:1336,y:929,t:1527009151442};\\\", \\\"{x:1335,y:933,t:1527009151460};\\\", \\\"{x:1334,y:933,t:1527009151475};\\\", \\\"{x:1333,y:933,t:1527009151492};\\\", \\\"{x:1332,y:934,t:1527009151508};\\\", \\\"{x:1332,y:935,t:1527009151544};\\\", \\\"{x:1332,y:936,t:1527009151648};\\\", \\\"{x:1334,y:936,t:1527009151752};\\\", \\\"{x:1336,y:936,t:1527009152033};\\\", \\\"{x:1333,y:936,t:1527009152216};\\\", \\\"{x:1329,y:936,t:1527009152226};\\\", \\\"{x:1324,y:936,t:1527009152243};\\\", \\\"{x:1317,y:936,t:1527009152259};\\\", \\\"{x:1310,y:936,t:1527009152276};\\\", \\\"{x:1306,y:936,t:1527009152293};\\\", \\\"{x:1303,y:936,t:1527009152309};\\\", \\\"{x:1297,y:936,t:1527009152326};\\\", \\\"{x:1291,y:937,t:1527009152343};\\\", \\\"{x:1283,y:940,t:1527009152359};\\\", \\\"{x:1265,y:949,t:1527009152376};\\\", \\\"{x:1256,y:954,t:1527009152393};\\\", \\\"{x:1249,y:958,t:1527009152409};\\\", \\\"{x:1245,y:959,t:1527009152426};\\\", \\\"{x:1240,y:961,t:1527009152443};\\\", \\\"{x:1237,y:961,t:1527009152459};\\\", \\\"{x:1233,y:963,t:1527009152476};\\\", \\\"{x:1230,y:964,t:1527009152493};\\\", \\\"{x:1227,y:965,t:1527009152509};\\\", \\\"{x:1224,y:966,t:1527009152525};\\\", \\\"{x:1223,y:966,t:1527009152543};\\\", \\\"{x:1222,y:966,t:1527009152559};\\\", \\\"{x:1221,y:966,t:1527009152575};\\\", \\\"{x:1220,y:966,t:1527009152593};\\\", \\\"{x:1219,y:966,t:1527009152856};\\\", \\\"{x:1218,y:966,t:1527009152864};\\\", \\\"{x:1218,y:965,t:1527009152896};\\\", \\\"{x:1218,y:964,t:1527009152912};\\\", \\\"{x:1218,y:963,t:1527009152926};\\\", \\\"{x:1217,y:962,t:1527009152943};\\\", \\\"{x:1217,y:961,t:1527009152961};\\\", \\\"{x:1217,y:960,t:1527009152976};\\\", \\\"{x:1217,y:959,t:1527009152993};\\\", \\\"{x:1217,y:957,t:1527009153010};\\\", \\\"{x:1217,y:954,t:1527009153026};\\\", \\\"{x:1217,y:953,t:1527009153043};\\\", \\\"{x:1217,y:950,t:1527009153060};\\\", \\\"{x:1216,y:948,t:1527009153076};\\\", \\\"{x:1215,y:947,t:1527009153093};\\\", \\\"{x:1214,y:945,t:1527009153110};\\\", \\\"{x:1214,y:944,t:1527009153127};\\\", \\\"{x:1213,y:944,t:1527009153144};\\\", \\\"{x:1211,y:944,t:1527009153160};\\\", \\\"{x:1208,y:944,t:1527009153177};\\\", \\\"{x:1200,y:945,t:1527009153194};\\\", \\\"{x:1189,y:949,t:1527009153210};\\\", \\\"{x:1177,y:953,t:1527009153227};\\\", \\\"{x:1167,y:954,t:1527009153243};\\\", \\\"{x:1156,y:955,t:1527009153260};\\\", \\\"{x:1143,y:957,t:1527009153277};\\\", \\\"{x:1134,y:957,t:1527009153293};\\\", \\\"{x:1125,y:959,t:1527009153310};\\\", \\\"{x:1115,y:960,t:1527009153327};\\\", \\\"{x:1108,y:962,t:1527009153343};\\\", \\\"{x:1104,y:962,t:1527009153360};\\\", \\\"{x:1103,y:962,t:1527009153377};\\\", \\\"{x:1102,y:962,t:1527009153393};\\\", \\\"{x:1101,y:963,t:1527009153561};\\\", \\\"{x:1101,y:964,t:1527009153593};\\\", \\\"{x:1102,y:965,t:1527009153609};\\\", \\\"{x:1103,y:965,t:1527009153865};\\\", \\\"{x:1104,y:965,t:1527009153881};\\\", \\\"{x:1107,y:965,t:1527009153894};\\\", \\\"{x:1109,y:965,t:1527009153910};\\\", \\\"{x:1115,y:961,t:1527009153927};\\\", \\\"{x:1119,y:960,t:1527009153944};\\\", \\\"{x:1122,y:958,t:1527009153960};\\\", \\\"{x:1125,y:958,t:1527009153977};\\\", \\\"{x:1126,y:957,t:1527009153994};\\\", \\\"{x:1126,y:959,t:1527009154193};\\\", \\\"{x:1125,y:960,t:1527009154211};\\\", \\\"{x:1124,y:961,t:1527009154232};\\\", \\\"{x:1123,y:962,t:1527009154249};\\\", \\\"{x:1123,y:961,t:1527009155192};\\\", \\\"{x:1122,y:960,t:1527009155273};\\\", \\\"{x:1122,y:957,t:1527009155523};\\\", \\\"{x:1123,y:957,t:1527009155529};\\\", \\\"{x:1125,y:956,t:1527009155545};\\\", \\\"{x:1130,y:953,t:1527009155563};\\\", \\\"{x:1136,y:950,t:1527009155579};\\\", \\\"{x:1151,y:944,t:1527009155596};\\\", \\\"{x:1172,y:936,t:1527009155613};\\\", \\\"{x:1205,y:928,t:1527009155629};\\\", \\\"{x:1235,y:919,t:1527009155645};\\\", \\\"{x:1265,y:911,t:1527009155662};\\\", \\\"{x:1287,y:908,t:1527009155678};\\\", \\\"{x:1303,y:906,t:1527009155695};\\\", \\\"{x:1313,y:906,t:1527009155712};\\\", \\\"{x:1318,y:906,t:1527009155728};\\\", \\\"{x:1326,y:904,t:1527009155745};\\\", \\\"{x:1330,y:904,t:1527009155762};\\\", \\\"{x:1336,y:903,t:1527009155778};\\\", \\\"{x:1342,y:903,t:1527009155795};\\\", \\\"{x:1348,y:903,t:1527009155812};\\\", \\\"{x:1353,y:903,t:1527009155828};\\\", \\\"{x:1358,y:903,t:1527009155846};\\\", \\\"{x:1363,y:904,t:1527009155862};\\\", \\\"{x:1366,y:905,t:1527009155879};\\\", \\\"{x:1368,y:906,t:1527009155895};\\\", \\\"{x:1372,y:909,t:1527009155912};\\\", \\\"{x:1372,y:910,t:1527009155929};\\\", \\\"{x:1374,y:911,t:1527009155945};\\\", \\\"{x:1374,y:912,t:1527009155962};\\\", \\\"{x:1375,y:914,t:1527009155979};\\\", \\\"{x:1376,y:915,t:1527009156000};\\\", \\\"{x:1376,y:916,t:1527009156016};\\\", \\\"{x:1376,y:917,t:1527009156040};\\\", \\\"{x:1377,y:918,t:1527009156056};\\\", \\\"{x:1377,y:919,t:1527009156064};\\\", \\\"{x:1377,y:920,t:1527009156080};\\\", \\\"{x:1377,y:921,t:1527009156105};\\\", \\\"{x:1377,y:922,t:1527009156129};\\\", \\\"{x:1377,y:923,t:1527009156257};\\\", \\\"{x:1377,y:924,t:1527009156273};\\\", \\\"{x:1377,y:925,t:1527009156289};\\\", \\\"{x:1377,y:926,t:1527009156354};\\\", \\\"{x:1377,y:927,t:1527009156401};\\\", \\\"{x:1377,y:928,t:1527009156594};\\\", \\\"{x:1377,y:929,t:1527009156617};\\\", \\\"{x:1377,y:930,t:1527009156633};\\\", \\\"{x:1377,y:931,t:1527009156649};\\\", \\\"{x:1376,y:932,t:1527009156689};\\\", \\\"{x:1374,y:933,t:1527009156736};\\\", \\\"{x:1373,y:933,t:1527009156800};\\\", \\\"{x:1371,y:933,t:1527009156832};\\\", \\\"{x:1370,y:933,t:1527009156848};\\\", \\\"{x:1369,y:933,t:1527009156897};\\\", \\\"{x:1368,y:933,t:1527009156929};\\\", \\\"{x:1367,y:933,t:1527009156946};\\\", \\\"{x:1366,y:933,t:1527009157065};\\\", \\\"{x:1365,y:933,t:1527009157081};\\\", \\\"{x:1364,y:933,t:1527009157113};\\\", \\\"{x:1363,y:933,t:1527009157145};\\\", \\\"{x:1362,y:933,t:1527009157176};\\\", \\\"{x:1361,y:932,t:1527009157184};\\\", \\\"{x:1360,y:932,t:1527009158090};\\\", \\\"{x:1358,y:932,t:1527009159825};\\\", \\\"{x:1356,y:932,t:1527009159841};\\\", \\\"{x:1355,y:932,t:1527009159849};\\\", \\\"{x:1353,y:932,t:1527009159864};\\\", \\\"{x:1351,y:932,t:1527009159882};\\\", \\\"{x:1350,y:931,t:1527009159899};\\\", \\\"{x:1349,y:931,t:1527009160056};\\\", \\\"{x:1348,y:931,t:1527009160088};\\\", \\\"{x:1347,y:931,t:1527009160200};\\\", \\\"{x:1345,y:932,t:1527009160434};\\\", \\\"{x:1345,y:933,t:1527009160473};\\\", \\\"{x:1345,y:934,t:1527009160482};\\\", \\\"{x:1343,y:935,t:1527009160513};\\\", \\\"{x:1343,y:936,t:1527009160553};\\\", \\\"{x:1343,y:937,t:1527009160593};\\\", \\\"{x:1342,y:939,t:1527009160610};\\\", \\\"{x:1341,y:939,t:1527009160649};\\\", \\\"{x:1341,y:940,t:1527009160672};\\\", \\\"{x:1341,y:941,t:1527009160689};\\\", \\\"{x:1340,y:942,t:1527009160704};\\\", \\\"{x:1339,y:943,t:1527009160737};\\\", \\\"{x:1339,y:944,t:1527009160768};\\\", \\\"{x:1339,y:945,t:1527009160785};\\\", \\\"{x:1339,y:947,t:1527009160801};\\\", \\\"{x:1338,y:947,t:1527009160817};\\\", \\\"{x:1338,y:948,t:1527009160840};\\\", \\\"{x:1337,y:948,t:1527009160857};\\\", \\\"{x:1337,y:949,t:1527009160889};\\\", \\\"{x:1336,y:951,t:1527009160922};\\\", \\\"{x:1335,y:952,t:1527009160945};\\\", \\\"{x:1335,y:953,t:1527009160961};\\\", \\\"{x:1334,y:953,t:1527009162361};\\\", \\\"{x:1333,y:953,t:1527009162369};\\\", \\\"{x:1332,y:953,t:1527009162418};\\\", \\\"{x:1331,y:953,t:1527009162433};\\\", \\\"{x:1330,y:953,t:1527009162451};\\\", \\\"{x:1329,y:953,t:1527009162467};\\\", \\\"{x:1328,y:953,t:1527009162489};\\\", \\\"{x:1327,y:952,t:1527009162513};\\\", \\\"{x:1327,y:951,t:1527009162537};\\\", \\\"{x:1327,y:950,t:1527009162561};\\\", \\\"{x:1327,y:949,t:1527009162569};\\\", \\\"{x:1327,y:948,t:1527009162584};\\\", \\\"{x:1327,y:939,t:1527009162601};\\\", \\\"{x:1327,y:931,t:1527009162617};\\\", \\\"{x:1327,y:919,t:1527009162634};\\\", \\\"{x:1327,y:909,t:1527009162651};\\\", \\\"{x:1328,y:900,t:1527009162668};\\\", \\\"{x:1328,y:896,t:1527009162684};\\\", \\\"{x:1329,y:893,t:1527009162701};\\\", \\\"{x:1329,y:891,t:1527009162722};\\\", \\\"{x:1329,y:890,t:1527009162734};\\\", \\\"{x:1329,y:888,t:1527009162751};\\\", \\\"{x:1330,y:887,t:1527009162768};\\\", \\\"{x:1330,y:883,t:1527009162784};\\\", \\\"{x:1330,y:879,t:1527009162800};\\\", \\\"{x:1330,y:877,t:1527009162818};\\\", \\\"{x:1330,y:875,t:1527009162834};\\\", \\\"{x:1330,y:873,t:1527009162851};\\\", \\\"{x:1331,y:870,t:1527009162868};\\\", \\\"{x:1331,y:867,t:1527009162884};\\\", \\\"{x:1332,y:863,t:1527009162901};\\\", \\\"{x:1334,y:853,t:1527009162918};\\\", \\\"{x:1335,y:844,t:1527009162934};\\\", \\\"{x:1335,y:839,t:1527009162951};\\\", \\\"{x:1336,y:834,t:1527009162969};\\\", \\\"{x:1337,y:828,t:1527009162984};\\\", \\\"{x:1338,y:822,t:1527009163001};\\\", \\\"{x:1338,y:820,t:1527009163018};\\\", \\\"{x:1338,y:817,t:1527009163033};\\\", \\\"{x:1338,y:816,t:1527009163065};\\\", \\\"{x:1338,y:814,t:1527009163081};\\\", \\\"{x:1338,y:813,t:1527009163097};\\\", \\\"{x:1338,y:812,t:1527009163105};\\\", \\\"{x:1338,y:810,t:1527009163118};\\\", \\\"{x:1338,y:807,t:1527009163135};\\\", \\\"{x:1338,y:803,t:1527009163151};\\\", \\\"{x:1338,y:800,t:1527009163168};\\\", \\\"{x:1338,y:797,t:1527009163185};\\\", \\\"{x:1338,y:796,t:1527009163201};\\\", \\\"{x:1338,y:793,t:1527009163218};\\\", \\\"{x:1337,y:791,t:1527009163235};\\\", \\\"{x:1336,y:790,t:1527009163251};\\\", \\\"{x:1335,y:786,t:1527009164082};\\\", \\\"{x:1334,y:785,t:1527009164097};\\\", \\\"{x:1333,y:785,t:1527009164105};\\\", \\\"{x:1332,y:783,t:1527009164122};\\\", \\\"{x:1331,y:783,t:1527009164135};\\\", \\\"{x:1330,y:781,t:1527009164153};\\\", \\\"{x:1329,y:780,t:1527009164186};\\\", \\\"{x:1328,y:780,t:1527009164208};\\\", \\\"{x:1327,y:779,t:1527009164258};\\\", \\\"{x:1319,y:779,t:1527009173722};\\\", \\\"{x:1308,y:779,t:1527009173728};\\\", \\\"{x:1296,y:784,t:1527009173742};\\\", \\\"{x:1261,y:796,t:1527009173758};\\\", \\\"{x:1221,y:804,t:1527009173774};\\\", \\\"{x:1156,y:817,t:1527009173792};\\\", \\\"{x:1124,y:825,t:1527009173808};\\\", \\\"{x:1099,y:833,t:1527009173825};\\\", \\\"{x:1071,y:836,t:1527009173842};\\\", \\\"{x:1044,y:836,t:1527009173859};\\\", \\\"{x:1028,y:836,t:1527009173875};\\\", \\\"{x:1017,y:836,t:1527009173892};\\\", \\\"{x:1008,y:836,t:1527009173909};\\\", \\\"{x:997,y:834,t:1527009173925};\\\", \\\"{x:981,y:829,t:1527009173942};\\\", \\\"{x:962,y:823,t:1527009173959};\\\", \\\"{x:937,y:811,t:1527009173975};\\\", \\\"{x:903,y:793,t:1527009173992};\\\", \\\"{x:880,y:780,t:1527009174009};\\\", \\\"{x:855,y:763,t:1527009174025};\\\", \\\"{x:819,y:736,t:1527009174042};\\\", \\\"{x:794,y:718,t:1527009174059};\\\", \\\"{x:779,y:707,t:1527009174077};\\\", \\\"{x:767,y:701,t:1527009174092};\\\", \\\"{x:756,y:692,t:1527009174109};\\\", \\\"{x:753,y:691,t:1527009174126};\\\", \\\"{x:750,y:689,t:1527009174142};\\\", \\\"{x:747,y:688,t:1527009174159};\\\", \\\"{x:741,y:685,t:1527009174176};\\\", \\\"{x:731,y:681,t:1527009174192};\\\", \\\"{x:723,y:679,t:1527009174208};\\\", \\\"{x:711,y:675,t:1527009174226};\\\", \\\"{x:697,y:671,t:1527009174242};\\\", \\\"{x:676,y:666,t:1527009174259};\\\", \\\"{x:663,y:661,t:1527009174276};\\\", \\\"{x:654,y:659,t:1527009174293};\\\", \\\"{x:648,y:656,t:1527009174309};\\\", \\\"{x:642,y:655,t:1527009174326};\\\", \\\"{x:635,y:652,t:1527009174342};\\\", \\\"{x:629,y:651,t:1527009174359};\\\", \\\"{x:623,y:649,t:1527009174376};\\\", \\\"{x:622,y:649,t:1527009174392};\\\", \\\"{x:621,y:649,t:1527009174408};\\\", \\\"{x:620,y:649,t:1527009174425};\\\", \\\"{x:620,y:648,t:1527009174442};\\\", \\\"{x:618,y:648,t:1527009174458};\\\", \\\"{x:617,y:648,t:1527009174475};\\\", \\\"{x:616,y:648,t:1527009174880};\\\", \\\"{x:615,y:648,t:1527009174893};\\\", \\\"{x:614,y:648,t:1527009174912};\\\", \\\"{x:613,y:648,t:1527009174936};\\\", \\\"{x:609,y:649,t:1527009175920};\\\", \\\"{x:600,y:651,t:1527009175927};\\\", \\\"{x:581,y:655,t:1527009175944};\\\", \\\"{x:560,y:656,t:1527009175960};\\\", \\\"{x:537,y:656,t:1527009175976};\\\", \\\"{x:519,y:656,t:1527009175993};\\\", \\\"{x:505,y:656,t:1527009176010};\\\", \\\"{x:502,y:656,t:1527009176027};\\\", \\\"{x:499,y:656,t:1527009176044};\\\", \\\"{x:500,y:655,t:1527009176104};\\\", \\\"{x:507,y:650,t:1527009176111};\\\", \\\"{x:525,y:640,t:1527009176128};\\\", \\\"{x:541,y:628,t:1527009176145};\\\", \\\"{x:556,y:617,t:1527009176162};\\\", \\\"{x:574,y:605,t:1527009176179};\\\", \\\"{x:590,y:593,t:1527009176196};\\\", \\\"{x:602,y:586,t:1527009176212};\\\", \\\"{x:610,y:579,t:1527009176229};\\\", \\\"{x:625,y:573,t:1527009176245};\\\", \\\"{x:641,y:566,t:1527009176261};\\\", \\\"{x:648,y:562,t:1527009176279};\\\", \\\"{x:655,y:560,t:1527009176294};\\\", \\\"{x:660,y:557,t:1527009176311};\\\", \\\"{x:660,y:556,t:1527009176343};\\\", \\\"{x:660,y:555,t:1527009176359};\\\", \\\"{x:658,y:553,t:1527009176376};\\\", \\\"{x:655,y:552,t:1527009176383};\\\", \\\"{x:652,y:551,t:1527009176395};\\\", \\\"{x:640,y:548,t:1527009176411};\\\", \\\"{x:626,y:544,t:1527009176429};\\\", \\\"{x:607,y:539,t:1527009176445};\\\", \\\"{x:587,y:539,t:1527009176462};\\\", \\\"{x:568,y:538,t:1527009176478};\\\", \\\"{x:546,y:537,t:1527009176496};\\\", \\\"{x:534,y:537,t:1527009176511};\\\", \\\"{x:528,y:539,t:1527009176529};\\\", \\\"{x:523,y:540,t:1527009176545};\\\", \\\"{x:517,y:541,t:1527009176562};\\\", \\\"{x:509,y:542,t:1527009176579};\\\", \\\"{x:503,y:543,t:1527009176595};\\\", \\\"{x:496,y:544,t:1527009176612};\\\", \\\"{x:493,y:545,t:1527009176628};\\\", \\\"{x:492,y:546,t:1527009176655};\\\", \\\"{x:495,y:546,t:1527009176671};\\\", \\\"{x:501,y:546,t:1527009176680};\\\", \\\"{x:525,y:545,t:1527009176695};\\\", \\\"{x:566,y:539,t:1527009176712};\\\", \\\"{x:619,y:533,t:1527009176729};\\\", \\\"{x:675,y:532,t:1527009176746};\\\", \\\"{x:723,y:532,t:1527009176763};\\\", \\\"{x:748,y:532,t:1527009176779};\\\", \\\"{x:761,y:532,t:1527009176795};\\\", \\\"{x:769,y:531,t:1527009176813};\\\", \\\"{x:770,y:530,t:1527009176829};\\\", \\\"{x:772,y:529,t:1527009176846};\\\", \\\"{x:774,y:527,t:1527009176862};\\\", \\\"{x:775,y:525,t:1527009176879};\\\", \\\"{x:784,y:522,t:1527009176895};\\\", \\\"{x:787,y:521,t:1527009176912};\\\", \\\"{x:790,y:521,t:1527009176929};\\\", \\\"{x:793,y:520,t:1527009176946};\\\", \\\"{x:797,y:518,t:1527009176963};\\\", \\\"{x:798,y:518,t:1527009176979};\\\", \\\"{x:801,y:518,t:1527009176996};\\\", \\\"{x:805,y:517,t:1527009177013};\\\", \\\"{x:809,y:516,t:1527009177029};\\\", \\\"{x:814,y:516,t:1527009177045};\\\", \\\"{x:817,y:515,t:1527009177063};\\\", \\\"{x:819,y:514,t:1527009177078};\\\", \\\"{x:822,y:513,t:1527009177096};\\\", \\\"{x:824,y:511,t:1527009177120};\\\", \\\"{x:826,y:510,t:1527009177129};\\\", \\\"{x:829,y:509,t:1527009177145};\\\", \\\"{x:832,y:506,t:1527009177163};\\\", \\\"{x:837,y:504,t:1527009177178};\\\", \\\"{x:840,y:503,t:1527009177196};\\\", \\\"{x:841,y:503,t:1527009177213};\\\", \\\"{x:842,y:502,t:1527009177229};\\\", \\\"{x:841,y:502,t:1527009177591};\\\", \\\"{x:840,y:502,t:1527009177623};\\\", \\\"{x:839,y:502,t:1527009177631};\\\", \\\"{x:838,y:502,t:1527009177655};\\\", \\\"{x:837,y:503,t:1527009177663};\\\", \\\"{x:834,y:504,t:1527009177679};\\\", \\\"{x:831,y:505,t:1527009177697};\\\", \\\"{x:827,y:507,t:1527009177712};\\\", \\\"{x:823,y:510,t:1527009177730};\\\", \\\"{x:818,y:512,t:1527009177746};\\\", \\\"{x:814,y:515,t:1527009177763};\\\", \\\"{x:807,y:519,t:1527009177780};\\\", \\\"{x:798,y:523,t:1527009177796};\\\", \\\"{x:791,y:525,t:1527009177813};\\\", \\\"{x:781,y:530,t:1527009177829};\\\", \\\"{x:770,y:535,t:1527009177846};\\\", \\\"{x:755,y:539,t:1527009177862};\\\", \\\"{x:729,y:545,t:1527009177879};\\\", \\\"{x:701,y:549,t:1527009177897};\\\", \\\"{x:674,y:553,t:1527009177912};\\\", \\\"{x:641,y:555,t:1527009177930};\\\", \\\"{x:618,y:557,t:1527009177947};\\\", \\\"{x:599,y:557,t:1527009177963};\\\", \\\"{x:588,y:557,t:1527009177980};\\\", \\\"{x:581,y:558,t:1527009177997};\\\", \\\"{x:578,y:559,t:1527009178013};\\\", \\\"{x:574,y:560,t:1527009178030};\\\", \\\"{x:571,y:560,t:1527009178046};\\\", \\\"{x:562,y:562,t:1527009178064};\\\", \\\"{x:552,y:563,t:1527009178080};\\\", \\\"{x:543,y:565,t:1527009178097};\\\", \\\"{x:535,y:565,t:1527009178114};\\\", \\\"{x:522,y:565,t:1527009178129};\\\", \\\"{x:512,y:565,t:1527009178147};\\\", \\\"{x:504,y:565,t:1527009178164};\\\", \\\"{x:490,y:565,t:1527009178181};\\\", \\\"{x:476,y:565,t:1527009178196};\\\", \\\"{x:465,y:565,t:1527009178214};\\\", \\\"{x:454,y:565,t:1527009178230};\\\", \\\"{x:446,y:563,t:1527009178247};\\\", \\\"{x:438,y:560,t:1527009178264};\\\", \\\"{x:435,y:560,t:1527009178279};\\\", \\\"{x:434,y:559,t:1527009178297};\\\", \\\"{x:434,y:558,t:1527009178314};\\\", \\\"{x:432,y:558,t:1527009178360};\\\", \\\"{x:431,y:558,t:1527009178368};\\\", \\\"{x:430,y:558,t:1527009178380};\\\", \\\"{x:427,y:557,t:1527009178397};\\\", \\\"{x:420,y:553,t:1527009178415};\\\", \\\"{x:411,y:548,t:1527009178431};\\\", \\\"{x:404,y:546,t:1527009178447};\\\", \\\"{x:396,y:542,t:1527009178464};\\\", \\\"{x:394,y:540,t:1527009178480};\\\", \\\"{x:392,y:540,t:1527009178498};\\\", \\\"{x:391,y:538,t:1527009178514};\\\", \\\"{x:393,y:535,t:1527009178648};\\\", \\\"{x:406,y:530,t:1527009178664};\\\", \\\"{x:428,y:525,t:1527009178681};\\\", \\\"{x:455,y:523,t:1527009178699};\\\", \\\"{x:481,y:523,t:1527009178714};\\\", \\\"{x:512,y:523,t:1527009178731};\\\", \\\"{x:538,y:523,t:1527009178747};\\\", \\\"{x:565,y:523,t:1527009178764};\\\", \\\"{x:587,y:523,t:1527009178781};\\\", \\\"{x:606,y:523,t:1527009178797};\\\", \\\"{x:619,y:525,t:1527009178815};\\\", \\\"{x:626,y:526,t:1527009178831};\\\", \\\"{x:630,y:526,t:1527009178847};\\\", \\\"{x:631,y:527,t:1527009178953};\\\", \\\"{x:631,y:528,t:1527009178964};\\\", \\\"{x:631,y:529,t:1527009178981};\\\", \\\"{x:632,y:531,t:1527009178997};\\\", \\\"{x:634,y:532,t:1527009179014};\\\", \\\"{x:637,y:533,t:1527009179031};\\\", \\\"{x:652,y:537,t:1527009179049};\\\", \\\"{x:665,y:540,t:1527009179064};\\\", \\\"{x:681,y:542,t:1527009179081};\\\", \\\"{x:695,y:547,t:1527009179098};\\\", \\\"{x:704,y:550,t:1527009179114};\\\", \\\"{x:706,y:551,t:1527009179131};\\\", \\\"{x:706,y:553,t:1527009179192};\\\", \\\"{x:706,y:554,t:1527009179199};\\\", \\\"{x:704,y:555,t:1527009179213};\\\", \\\"{x:699,y:557,t:1527009179232};\\\", \\\"{x:689,y:558,t:1527009179247};\\\", \\\"{x:682,y:558,t:1527009179264};\\\", \\\"{x:676,y:558,t:1527009179280};\\\", \\\"{x:671,y:558,t:1527009179298};\\\", \\\"{x:668,y:558,t:1527009179315};\\\", \\\"{x:664,y:558,t:1527009179330};\\\", \\\"{x:659,y:557,t:1527009179348};\\\", \\\"{x:656,y:557,t:1527009179364};\\\", \\\"{x:649,y:557,t:1527009179381};\\\", \\\"{x:633,y:554,t:1527009179398};\\\", \\\"{x:615,y:553,t:1527009179415};\\\", \\\"{x:590,y:553,t:1527009179431};\\\", \\\"{x:528,y:553,t:1527009179447};\\\", \\\"{x:489,y:553,t:1527009179465};\\\", \\\"{x:447,y:553,t:1527009179481};\\\", \\\"{x:423,y:553,t:1527009179498};\\\", \\\"{x:412,y:553,t:1527009179515};\\\", \\\"{x:407,y:553,t:1527009179531};\\\", \\\"{x:406,y:553,t:1527009179548};\\\", \\\"{x:405,y:553,t:1527009179567};\\\", \\\"{x:403,y:553,t:1527009179584};\\\", \\\"{x:400,y:553,t:1527009179599};\\\", \\\"{x:399,y:553,t:1527009179614};\\\", \\\"{x:393,y:554,t:1527009179631};\\\", \\\"{x:381,y:556,t:1527009179648};\\\", \\\"{x:370,y:556,t:1527009179665};\\\", \\\"{x:361,y:556,t:1527009179680};\\\", \\\"{x:352,y:556,t:1527009179698};\\\", \\\"{x:339,y:556,t:1527009179714};\\\", \\\"{x:324,y:556,t:1527009179730};\\\", \\\"{x:309,y:556,t:1527009179748};\\\", \\\"{x:294,y:556,t:1527009179765};\\\", \\\"{x:278,y:556,t:1527009179781};\\\", \\\"{x:256,y:556,t:1527009179798};\\\", \\\"{x:236,y:556,t:1527009179815};\\\", \\\"{x:208,y:554,t:1527009179832};\\\", \\\"{x:190,y:554,t:1527009179848};\\\", \\\"{x:180,y:552,t:1527009179865};\\\", \\\"{x:176,y:552,t:1527009179882};\\\", \\\"{x:172,y:552,t:1527009179898};\\\", \\\"{x:169,y:552,t:1527009179915};\\\", \\\"{x:167,y:552,t:1527009179932};\\\", \\\"{x:166,y:552,t:1527009179948};\\\", \\\"{x:165,y:552,t:1527009179965};\\\", \\\"{x:162,y:552,t:1527009179982};\\\", \\\"{x:160,y:552,t:1527009179997};\\\", \\\"{x:157,y:552,t:1527009180015};\\\", \\\"{x:158,y:551,t:1527009180323};\\\", \\\"{x:161,y:551,t:1527009180332};\\\", \\\"{x:168,y:550,t:1527009180348};\\\", \\\"{x:183,y:555,t:1527009180365};\\\", \\\"{x:206,y:565,t:1527009180382};\\\", \\\"{x:230,y:577,t:1527009180399};\\\", \\\"{x:256,y:593,t:1527009180415};\\\", \\\"{x:303,y:619,t:1527009180432};\\\", \\\"{x:332,y:637,t:1527009180449};\\\", \\\"{x:354,y:651,t:1527009180466};\\\", \\\"{x:373,y:665,t:1527009180482};\\\", \\\"{x:385,y:675,t:1527009180499};\\\", \\\"{x:393,y:683,t:1527009180515};\\\", \\\"{x:406,y:694,t:1527009180532};\\\", \\\"{x:422,y:707,t:1527009180548};\\\", \\\"{x:434,y:716,t:1527009180566};\\\", \\\"{x:439,y:719,t:1527009180582};\\\", \\\"{x:443,y:722,t:1527009180599};\\\", \\\"{x:445,y:723,t:1527009180615};\\\", \\\"{x:452,y:729,t:1527009180632};\\\", \\\"{x:455,y:730,t:1527009180649};\\\", \\\"{x:460,y:735,t:1527009180666};\\\", \\\"{x:464,y:738,t:1527009180682};\\\", \\\"{x:467,y:738,t:1527009180699};\\\", \\\"{x:466,y:734,t:1527009180735};\\\", \\\"{x:460,y:719,t:1527009180750};\\\", \\\"{x:434,y:664,t:1527009180766};\\\", \\\"{x:367,y:577,t:1527009180783};\\\", \\\"{x:279,y:499,t:1527009180800};\\\", \\\"{x:139,y:414,t:1527009180816};\\\", \\\"{x:101,y:393,t:1527009180831};\\\", \\\"{x:92,y:390,t:1527009180848};\\\", \\\"{x:89,y:388,t:1527009180865};\\\", \\\"{x:89,y:393,t:1527009180895};\\\", \\\"{x:92,y:402,t:1527009180903};\\\", \\\"{x:97,y:413,t:1527009180915};\\\", \\\"{x:110,y:445,t:1527009180932};\\\", \\\"{x:119,y:478,t:1527009180949};\\\", \\\"{x:129,y:504,t:1527009180966};\\\", \\\"{x:136,y:523,t:1527009180983};\\\", \\\"{x:143,y:539,t:1527009181000};\\\", \\\"{x:149,y:558,t:1527009181016};\\\", \\\"{x:151,y:565,t:1527009181032};\\\", \\\"{x:151,y:570,t:1527009181049};\\\", \\\"{x:151,y:571,t:1527009181066};\\\", \\\"{x:151,y:566,t:1527009181194};\\\", \\\"{x:151,y:560,t:1527009181201};\\\", \\\"{x:151,y:551,t:1527009181216};\\\", \\\"{x:150,y:548,t:1527009181233};\\\", \\\"{x:149,y:546,t:1527009181249};\\\", \\\"{x:149,y:545,t:1527009181266};\\\", \\\"{x:149,y:543,t:1527009181336};\\\", \\\"{x:150,y:543,t:1527009181359};\\\", \\\"{x:151,y:543,t:1527009181375};\\\", \\\"{x:154,y:542,t:1527009181536};\\\", \\\"{x:158,y:542,t:1527009181550};\\\", \\\"{x:171,y:542,t:1527009181566};\\\", \\\"{x:200,y:548,t:1527009181583};\\\", \\\"{x:269,y:576,t:1527009181600};\\\", \\\"{x:318,y:604,t:1527009181616};\\\", \\\"{x:375,y:635,t:1527009181633};\\\", \\\"{x:418,y:660,t:1527009181651};\\\", \\\"{x:448,y:679,t:1527009181667};\\\", \\\"{x:463,y:697,t:1527009181683};\\\", \\\"{x:478,y:711,t:1527009181700};\\\", \\\"{x:490,y:717,t:1527009181716};\\\", \\\"{x:497,y:722,t:1527009181734};\\\", \\\"{x:502,y:725,t:1527009181750};\\\", \\\"{x:502,y:726,t:1527009181824};\\\", \\\"{x:503,y:730,t:1527009182017};\\\", \\\"{x:509,y:735,t:1527009182034};\\\", \\\"{x:515,y:741,t:1527009182050};\\\", \\\"{x:516,y:742,t:1527009182067};\\\", \\\"{x:518,y:744,t:1527009182084};\\\", \\\"{x:518,y:745,t:1527009182113};\\\", \\\"{x:518,y:744,t:1527009182816};\\\", \\\"{x:518,y:743,t:1527009182834};\\\", \\\"{x:517,y:741,t:1527009182850};\\\", \\\"{x:517,y:740,t:1527009183016};\\\", \\\"{x:517,y:739,t:1527009183024};\\\", \\\"{x:517,y:738,t:1527009183034};\\\", \\\"{x:517,y:736,t:1527009183051};\\\", \\\"{x:517,y:733,t:1527009183067};\\\", \\\"{x:517,y:732,t:1527009183084};\\\", \\\"{x:517,y:730,t:1527009183104};\\\", \\\"{x:517,y:729,t:1527009183128};\\\", \\\"{x:517,y:727,t:1527009183200};\\\", \\\"{x:517,y:726,t:1527009183257};\\\", \\\"{x:517,y:724,t:1527009183304};\\\", \\\"{x:517,y:723,t:1527009183328};\\\", \\\"{x:517,y:721,t:1527009183350};\\\", \\\"{x:517,y:720,t:1527009183367};\\\", \\\"{x:518,y:718,t:1527009183383};\\\", \\\"{x:520,y:714,t:1527009183401};\\\", \\\"{x:521,y:713,t:1527009183418};\\\" ] }, { \\\"rt\\\": 35163, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 12, \\\"time_elapsed\\\": 393103, \\\"internal_node_id\\\": \\\"0.0-6.0-2.0\\\", \\\"subject\\\": \\\"38NFJ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"echo\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+contained\\\", \\\"q\\\": 8, \\\"clicks\\\": 3.5, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-07 PM-08 PM-L -H -M \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:525,y:708,t:1527009183516};\\\", \\\"{x:525,y:707,t:1527009183816};\\\", \\\"{x:525,y:706,t:1527009183831};\\\", \\\"{x:525,y:705,t:1527009183856};\\\", \\\"{x:525,y:704,t:1527009183879};\\\", \\\"{x:525,y:703,t:1527009184184};\\\", \\\"{x:525,y:702,t:1527009184191};\\\", \\\"{x:525,y:699,t:1527009184207};\\\", \\\"{x:526,y:697,t:1527009184218};\\\", \\\"{x:527,y:689,t:1527009184235};\\\", \\\"{x:529,y:676,t:1527009184252};\\\", \\\"{x:529,y:661,t:1527009184268};\\\", \\\"{x:529,y:640,t:1527009184284};\\\", \\\"{x:529,y:617,t:1527009184302};\\\", \\\"{x:530,y:591,t:1527009184318};\\\", \\\"{x:534,y:565,t:1527009184335};\\\", \\\"{x:534,y:544,t:1527009184352};\\\", \\\"{x:534,y:523,t:1527009184369};\\\", \\\"{x:534,y:510,t:1527009184386};\\\", \\\"{x:533,y:503,t:1527009184402};\\\", \\\"{x:532,y:499,t:1527009184418};\\\", \\\"{x:531,y:498,t:1527009184439};\\\", \\\"{x:530,y:497,t:1527009184452};\\\", \\\"{x:529,y:497,t:1527009184503};\\\", \\\"{x:527,y:496,t:1527009184519};\\\", \\\"{x:522,y:494,t:1527009184535};\\\", \\\"{x:510,y:490,t:1527009184551};\\\", \\\"{x:498,y:487,t:1527009184569};\\\", \\\"{x:484,y:483,t:1527009184585};\\\", \\\"{x:470,y:479,t:1527009184601};\\\", \\\"{x:453,y:474,t:1527009184618};\\\", \\\"{x:435,y:468,t:1527009184634};\\\", \\\"{x:425,y:466,t:1527009184651};\\\", \\\"{x:421,y:465,t:1527009184669};\\\", \\\"{x:416,y:463,t:1527009184684};\\\", \\\"{x:412,y:462,t:1527009184701};\\\", \\\"{x:408,y:460,t:1527009184718};\\\", \\\"{x:401,y:460,t:1527009184734};\\\", \\\"{x:386,y:456,t:1527009184751};\\\", \\\"{x:375,y:456,t:1527009184767};\\\", \\\"{x:358,y:455,t:1527009184784};\\\", \\\"{x:348,y:453,t:1527009184801};\\\", \\\"{x:338,y:452,t:1527009184817};\\\", \\\"{x:325,y:451,t:1527009184834};\\\", \\\"{x:320,y:450,t:1527009184851};\\\", \\\"{x:316,y:450,t:1527009184867};\\\", \\\"{x:312,y:450,t:1527009184884};\\\", \\\"{x:311,y:450,t:1527009184900};\\\", \\\"{x:310,y:450,t:1527009184917};\\\", \\\"{x:309,y:450,t:1527009184934};\\\", \\\"{x:306,y:450,t:1527009184955};\\\", \\\"{x:299,y:452,t:1527009184972};\\\", \\\"{x:292,y:453,t:1527009184989};\\\", \\\"{x:289,y:455,t:1527009185005};\\\", \\\"{x:287,y:456,t:1527009185023};\\\", \\\"{x:286,y:457,t:1527009185053};\\\", \\\"{x:286,y:459,t:1527009185077};\\\", \\\"{x:285,y:459,t:1527009185117};\\\", \\\"{x:287,y:459,t:1527009185375};\\\", \\\"{x:292,y:459,t:1527009185388};\\\", \\\"{x:303,y:459,t:1527009185405};\\\", \\\"{x:326,y:459,t:1527009185422};\\\", \\\"{x:337,y:459,t:1527009185438};\\\", \\\"{x:349,y:459,t:1527009185455};\\\", \\\"{x:354,y:459,t:1527009185472};\\\", \\\"{x:357,y:460,t:1527009185488};\\\", \\\"{x:359,y:460,t:1527009185505};\\\", \\\"{x:360,y:460,t:1527009185522};\\\", \\\"{x:361,y:460,t:1527009185538};\\\", \\\"{x:362,y:460,t:1527009185555};\\\", \\\"{x:363,y:460,t:1527009185573};\\\", \\\"{x:364,y:460,t:1527009185589};\\\", \\\"{x:365,y:460,t:1527009185605};\\\", \\\"{x:366,y:460,t:1527009185621};\\\", \\\"{x:367,y:460,t:1527009185805};\\\", \\\"{x:369,y:460,t:1527009185925};\\\", \\\"{x:370,y:460,t:1527009185936};\\\", \\\"{x:375,y:459,t:1527009185954};\\\", \\\"{x:378,y:459,t:1527009185969};\\\", \\\"{x:382,y:459,t:1527009185987};\\\", \\\"{x:387,y:458,t:1527009186004};\\\", \\\"{x:391,y:457,t:1527009186020};\\\", \\\"{x:395,y:456,t:1527009186037};\\\", \\\"{x:402,y:456,t:1527009186053};\\\", \\\"{x:408,y:454,t:1527009186069};\\\", \\\"{x:410,y:454,t:1527009186086};\\\", \\\"{x:413,y:454,t:1527009186102};\\\", \\\"{x:416,y:453,t:1527009186119};\\\", \\\"{x:417,y:453,t:1527009186149};\\\", \\\"{x:418,y:453,t:1527009186165};\\\", \\\"{x:419,y:453,t:1527009186173};\\\", \\\"{x:420,y:453,t:1527009186197};\\\", \\\"{x:422,y:453,t:1527009186205};\\\", \\\"{x:423,y:453,t:1527009186220};\\\", \\\"{x:427,y:453,t:1527009186236};\\\", \\\"{x:434,y:453,t:1527009186253};\\\", \\\"{x:446,y:453,t:1527009186269};\\\", \\\"{x:455,y:455,t:1527009186286};\\\", \\\"{x:464,y:457,t:1527009186303};\\\", \\\"{x:472,y:459,t:1527009186319};\\\", \\\"{x:477,y:460,t:1527009186336};\\\", \\\"{x:482,y:461,t:1527009186353};\\\", \\\"{x:488,y:461,t:1527009186368};\\\", \\\"{x:492,y:461,t:1527009186386};\\\", \\\"{x:498,y:463,t:1527009186402};\\\", \\\"{x:504,y:464,t:1527009186419};\\\", \\\"{x:510,y:465,t:1527009186436};\\\", \\\"{x:519,y:466,t:1527009186452};\\\", \\\"{x:526,y:467,t:1527009186468};\\\", \\\"{x:537,y:469,t:1527009186484};\\\", \\\"{x:542,y:469,t:1527009186501};\\\", \\\"{x:544,y:470,t:1527009186519};\\\", \\\"{x:546,y:470,t:1527009186535};\\\", \\\"{x:547,y:470,t:1527009186565};\\\", \\\"{x:548,y:470,t:1527009186573};\\\", \\\"{x:549,y:470,t:1527009186585};\\\", \\\"{x:550,y:470,t:1527009186602};\\\", \\\"{x:552,y:470,t:1527009186618};\\\", \\\"{x:557,y:470,t:1527009186635};\\\", \\\"{x:560,y:470,t:1527009186651};\\\", \\\"{x:565,y:470,t:1527009186669};\\\", \\\"{x:570,y:470,t:1527009186685};\\\", \\\"{x:571,y:470,t:1527009186702};\\\", \\\"{x:573,y:470,t:1527009186718};\\\", \\\"{x:574,y:470,t:1527009186741};\\\", \\\"{x:575,y:469,t:1527009186766};\\\", \\\"{x:576,y:469,t:1527009186797};\\\", \\\"{x:577,y:469,t:1527009186806};\\\", \\\"{x:578,y:469,t:1527009186829};\\\", \\\"{x:579,y:468,t:1527009186837};\\\", \\\"{x:580,y:468,t:1527009186851};\\\", \\\"{x:581,y:468,t:1527009186868};\\\", \\\"{x:584,y:468,t:1527009186884};\\\", \\\"{x:588,y:467,t:1527009186901};\\\", \\\"{x:593,y:467,t:1527009186917};\\\", \\\"{x:598,y:467,t:1527009186935};\\\", \\\"{x:604,y:467,t:1527009186951};\\\", \\\"{x:609,y:467,t:1527009186967};\\\", \\\"{x:616,y:467,t:1527009186984};\\\", \\\"{x:623,y:467,t:1527009187001};\\\", \\\"{x:632,y:467,t:1527009187018};\\\", \\\"{x:638,y:467,t:1527009187034};\\\", \\\"{x:645,y:467,t:1527009187051};\\\", \\\"{x:651,y:467,t:1527009187068};\\\", \\\"{x:655,y:467,t:1527009187084};\\\", \\\"{x:658,y:467,t:1527009187101};\\\", \\\"{x:659,y:467,t:1527009187117};\\\", \\\"{x:660,y:467,t:1527009187134};\\\", \\\"{x:661,y:467,t:1527009187151};\\\", \\\"{x:662,y:467,t:1527009187167};\\\", \\\"{x:663,y:467,t:1527009187198};\\\", \\\"{x:664,y:467,t:1527009187222};\\\", \\\"{x:665,y:467,t:1527009187246};\\\", \\\"{x:663,y:467,t:1527009188054};\\\", \\\"{x:659,y:467,t:1527009188065};\\\", \\\"{x:648,y:467,t:1527009188082};\\\", \\\"{x:631,y:467,t:1527009188098};\\\", \\\"{x:613,y:469,t:1527009188115};\\\", \\\"{x:598,y:470,t:1527009188133};\\\", \\\"{x:588,y:470,t:1527009188148};\\\", \\\"{x:578,y:470,t:1527009188165};\\\", \\\"{x:564,y:470,t:1527009188182};\\\", \\\"{x:557,y:470,t:1527009188198};\\\", \\\"{x:547,y:469,t:1527009188216};\\\", \\\"{x:541,y:468,t:1527009188231};\\\", \\\"{x:536,y:467,t:1527009188248};\\\", \\\"{x:533,y:467,t:1527009188265};\\\", \\\"{x:532,y:467,t:1527009188282};\\\", \\\"{x:530,y:467,t:1527009188298};\\\", \\\"{x:528,y:467,t:1527009188314};\\\", \\\"{x:527,y:467,t:1527009188331};\\\", \\\"{x:525,y:467,t:1527009188348};\\\", \\\"{x:524,y:467,t:1527009188365};\\\", \\\"{x:527,y:466,t:1527009190326};\\\", \\\"{x:540,y:463,t:1527009190343};\\\", \\\"{x:550,y:459,t:1527009190359};\\\", \\\"{x:556,y:457,t:1527009190376};\\\", \\\"{x:558,y:456,t:1527009190392};\\\", \\\"{x:561,y:455,t:1527009190409};\\\", \\\"{x:562,y:455,t:1527009190426};\\\", \\\"{x:563,y:455,t:1527009190446};\\\", \\\"{x:564,y:454,t:1527009190459};\\\", \\\"{x:566,y:454,t:1527009190477};\\\", \\\"{x:567,y:454,t:1527009190494};\\\", \\\"{x:569,y:453,t:1527009190510};\\\", \\\"{x:570,y:453,t:1527009190525};\\\", \\\"{x:579,y:453,t:1527009190542};\\\", \\\"{x:587,y:453,t:1527009190560};\\\", \\\"{x:599,y:454,t:1527009190575};\\\", \\\"{x:617,y:459,t:1527009190592};\\\", \\\"{x:634,y:465,t:1527009190610};\\\", \\\"{x:656,y:471,t:1527009190626};\\\", \\\"{x:686,y:484,t:1527009190642};\\\", \\\"{x:722,y:499,t:1527009190659};\\\", \\\"{x:774,y:522,t:1527009190675};\\\", \\\"{x:824,y:541,t:1527009190692};\\\", \\\"{x:866,y:554,t:1527009190705};\\\", \\\"{x:911,y:569,t:1527009190723};\\\", \\\"{x:978,y:589,t:1527009190746};\\\", \\\"{x:1037,y:607,t:1527009190762};\\\", \\\"{x:1096,y:624,t:1527009190779};\\\", \\\"{x:1159,y:638,t:1527009190796};\\\", \\\"{x:1248,y:663,t:1527009190813};\\\", \\\"{x:1299,y:674,t:1527009190829};\\\", \\\"{x:1340,y:682,t:1527009190846};\\\", \\\"{x:1366,y:690,t:1527009190863};\\\", \\\"{x:1381,y:691,t:1527009190879};\\\", \\\"{x:1385,y:692,t:1527009190896};\\\", \\\"{x:1387,y:692,t:1527009190913};\\\", \\\"{x:1394,y:697,t:1527009191102};\\\", \\\"{x:1404,y:703,t:1527009191113};\\\", \\\"{x:1427,y:713,t:1527009191130};\\\", \\\"{x:1453,y:724,t:1527009191146};\\\", \\\"{x:1481,y:734,t:1527009191164};\\\", \\\"{x:1504,y:743,t:1527009191180};\\\", \\\"{x:1533,y:752,t:1527009191197};\\\", \\\"{x:1566,y:758,t:1527009191213};\\\", \\\"{x:1579,y:759,t:1527009191229};\\\", \\\"{x:1589,y:759,t:1527009191246};\\\", \\\"{x:1598,y:760,t:1527009191263};\\\", \\\"{x:1603,y:762,t:1527009191280};\\\", \\\"{x:1611,y:765,t:1527009191296};\\\", \\\"{x:1615,y:767,t:1527009191313};\\\", \\\"{x:1617,y:770,t:1527009191331};\\\", \\\"{x:1624,y:780,t:1527009191346};\\\", \\\"{x:1631,y:796,t:1527009191364};\\\", \\\"{x:1642,y:819,t:1527009191380};\\\", \\\"{x:1660,y:850,t:1527009191396};\\\", \\\"{x:1712,y:906,t:1527009191414};\\\", \\\"{x:1766,y:944,t:1527009191430};\\\", \\\"{x:1823,y:977,t:1527009191447};\\\", \\\"{x:1865,y:998,t:1527009191464};\\\", \\\"{x:1903,y:1012,t:1527009191481};\\\", \\\"{x:1919,y:1021,t:1527009191496};\\\", \\\"{x:1919,y:1025,t:1527009191513};\\\", \\\"{x:1919,y:1026,t:1527009191530};\\\", \\\"{x:1919,y:1025,t:1527009191565};\\\", \\\"{x:1919,y:1023,t:1527009191581};\\\", \\\"{x:1919,y:1021,t:1527009191597};\\\", \\\"{x:1918,y:1014,t:1527009191613};\\\", \\\"{x:1917,y:1012,t:1527009191630};\\\", \\\"{x:1915,y:1010,t:1527009191646};\\\", \\\"{x:1914,y:1006,t:1527009191662};\\\", \\\"{x:1911,y:1003,t:1527009191680};\\\", \\\"{x:1910,y:1001,t:1527009191697};\\\", \\\"{x:1908,y:999,t:1527009191713};\\\", \\\"{x:1904,y:997,t:1527009191730};\\\", \\\"{x:1903,y:997,t:1527009191747};\\\", \\\"{x:1902,y:996,t:1527009191764};\\\", \\\"{x:1899,y:995,t:1527009191780};\\\", \\\"{x:1897,y:994,t:1527009191797};\\\", \\\"{x:1896,y:994,t:1527009191813};\\\", \\\"{x:1895,y:994,t:1527009191830};\\\", \\\"{x:1892,y:994,t:1527009191903};\\\", \\\"{x:1890,y:992,t:1527009191913};\\\", \\\"{x:1885,y:990,t:1527009191930};\\\", \\\"{x:1882,y:988,t:1527009191949};\\\", \\\"{x:1880,y:986,t:1527009191963};\\\", \\\"{x:1878,y:986,t:1527009191980};\\\", \\\"{x:1874,y:982,t:1527009191997};\\\", \\\"{x:1873,y:982,t:1527009192029};\\\", \\\"{x:1872,y:981,t:1527009192037};\\\", \\\"{x:1871,y:981,t:1527009192047};\\\", \\\"{x:1871,y:980,t:1527009192069};\\\", \\\"{x:1870,y:979,t:1527009192080};\\\", \\\"{x:1868,y:978,t:1527009192097};\\\", \\\"{x:1866,y:976,t:1527009192114};\\\", \\\"{x:1861,y:972,t:1527009192130};\\\", \\\"{x:1854,y:967,t:1527009192147};\\\", \\\"{x:1851,y:965,t:1527009192165};\\\", \\\"{x:1849,y:964,t:1527009192180};\\\", \\\"{x:1847,y:963,t:1527009192198};\\\", \\\"{x:1846,y:962,t:1527009192238};\\\", \\\"{x:1845,y:962,t:1527009192262};\\\", \\\"{x:1844,y:962,t:1527009192269};\\\", \\\"{x:1843,y:962,t:1527009192280};\\\", \\\"{x:1841,y:962,t:1527009192297};\\\", \\\"{x:1840,y:962,t:1527009192314};\\\", \\\"{x:1837,y:962,t:1527009192330};\\\", \\\"{x:1833,y:962,t:1527009192347};\\\", \\\"{x:1831,y:962,t:1527009192364};\\\", \\\"{x:1830,y:961,t:1527009192380};\\\", \\\"{x:1828,y:961,t:1527009192405};\\\", \\\"{x:1824,y:958,t:1527009192631};\\\", \\\"{x:1819,y:952,t:1527009192638};\\\", \\\"{x:1812,y:943,t:1527009192648};\\\", \\\"{x:1798,y:920,t:1527009192664};\\\", \\\"{x:1775,y:888,t:1527009192681};\\\", \\\"{x:1750,y:845,t:1527009192698};\\\", \\\"{x:1722,y:796,t:1527009192714};\\\", \\\"{x:1698,y:759,t:1527009192732};\\\", \\\"{x:1683,y:739,t:1527009192748};\\\", \\\"{x:1673,y:723,t:1527009192764};\\\", \\\"{x:1664,y:711,t:1527009192782};\\\", \\\"{x:1660,y:705,t:1527009192798};\\\", \\\"{x:1656,y:699,t:1527009192815};\\\", \\\"{x:1650,y:692,t:1527009192831};\\\", \\\"{x:1636,y:682,t:1527009192847};\\\", \\\"{x:1621,y:672,t:1527009192865};\\\", \\\"{x:1596,y:665,t:1527009192881};\\\", \\\"{x:1567,y:651,t:1527009192898};\\\", \\\"{x:1532,y:635,t:1527009192914};\\\", \\\"{x:1497,y:614,t:1527009192931};\\\", \\\"{x:1448,y:586,t:1527009192948};\\\", \\\"{x:1396,y:556,t:1527009192964};\\\", \\\"{x:1345,y:535,t:1527009192981};\\\", \\\"{x:1330,y:527,t:1527009192998};\\\", \\\"{x:1329,y:526,t:1527009193014};\\\", \\\"{x:1329,y:524,t:1527009193062};\\\", \\\"{x:1331,y:518,t:1527009193070};\\\", \\\"{x:1335,y:511,t:1527009193082};\\\", \\\"{x:1349,y:499,t:1527009193099};\\\", \\\"{x:1361,y:494,t:1527009193114};\\\", \\\"{x:1373,y:492,t:1527009193132};\\\", \\\"{x:1387,y:492,t:1527009193148};\\\", \\\"{x:1406,y:492,t:1527009193165};\\\", \\\"{x:1425,y:492,t:1527009193182};\\\", \\\"{x:1438,y:492,t:1527009193198};\\\", \\\"{x:1463,y:492,t:1527009193214};\\\", \\\"{x:1490,y:492,t:1527009193231};\\\", \\\"{x:1514,y:494,t:1527009193248};\\\", \\\"{x:1532,y:499,t:1527009193264};\\\", \\\"{x:1550,y:501,t:1527009193281};\\\", \\\"{x:1562,y:503,t:1527009193299};\\\", \\\"{x:1569,y:503,t:1527009193314};\\\", \\\"{x:1574,y:503,t:1527009193331};\\\", \\\"{x:1580,y:503,t:1527009193349};\\\", \\\"{x:1584,y:503,t:1527009193365};\\\", \\\"{x:1588,y:500,t:1527009193382};\\\", \\\"{x:1596,y:496,t:1527009193398};\\\", \\\"{x:1600,y:495,t:1527009193415};\\\", \\\"{x:1601,y:494,t:1527009193431};\\\", \\\"{x:1600,y:494,t:1527009193590};\\\", \\\"{x:1599,y:494,t:1527009193599};\\\", \\\"{x:1597,y:494,t:1527009193615};\\\", \\\"{x:1595,y:494,t:1527009193632};\\\", \\\"{x:1593,y:494,t:1527009193649};\\\", \\\"{x:1588,y:495,t:1527009193666};\\\", \\\"{x:1583,y:497,t:1527009193684};\\\", \\\"{x:1580,y:497,t:1527009193698};\\\", \\\"{x:1579,y:498,t:1527009193716};\\\", \\\"{x:1578,y:498,t:1527009193733};\\\", \\\"{x:1577,y:498,t:1527009193758};\\\", \\\"{x:1578,y:498,t:1527009193934};\\\", \\\"{x:1578,y:499,t:1527009195982};\\\", \\\"{x:1579,y:500,t:1527009195997};\\\", \\\"{x:1579,y:501,t:1527009196013};\\\", \\\"{x:1580,y:502,t:1527009196021};\\\", \\\"{x:1580,y:503,t:1527009196037};\\\", \\\"{x:1580,y:505,t:1527009196050};\\\", \\\"{x:1580,y:506,t:1527009196077};\\\", \\\"{x:1581,y:507,t:1527009196085};\\\", \\\"{x:1582,y:508,t:1527009196100};\\\", \\\"{x:1582,y:510,t:1527009196117};\\\", \\\"{x:1582,y:513,t:1527009196133};\\\", \\\"{x:1582,y:515,t:1527009196149};\\\", \\\"{x:1583,y:517,t:1527009196167};\\\", \\\"{x:1583,y:518,t:1527009196183};\\\", \\\"{x:1583,y:520,t:1527009196200};\\\", \\\"{x:1584,y:523,t:1527009196217};\\\", \\\"{x:1584,y:527,t:1527009196233};\\\", \\\"{x:1584,y:532,t:1527009196250};\\\", \\\"{x:1584,y:536,t:1527009196267};\\\", \\\"{x:1584,y:540,t:1527009196284};\\\", \\\"{x:1584,y:544,t:1527009196301};\\\", \\\"{x:1584,y:550,t:1527009196317};\\\", \\\"{x:1584,y:555,t:1527009196334};\\\", \\\"{x:1585,y:561,t:1527009196349};\\\", \\\"{x:1586,y:566,t:1527009196367};\\\", \\\"{x:1586,y:569,t:1527009196384};\\\", \\\"{x:1587,y:574,t:1527009196400};\\\", \\\"{x:1590,y:578,t:1527009196417};\\\", \\\"{x:1590,y:583,t:1527009196434};\\\", \\\"{x:1591,y:585,t:1527009196450};\\\", \\\"{x:1593,y:590,t:1527009196467};\\\", \\\"{x:1594,y:592,t:1527009196484};\\\", \\\"{x:1594,y:595,t:1527009196500};\\\", \\\"{x:1595,y:599,t:1527009196516};\\\", \\\"{x:1595,y:602,t:1527009196534};\\\", \\\"{x:1595,y:605,t:1527009196550};\\\", \\\"{x:1596,y:607,t:1527009196567};\\\", \\\"{x:1596,y:609,t:1527009196584};\\\", \\\"{x:1596,y:612,t:1527009196600};\\\", \\\"{x:1596,y:615,t:1527009196617};\\\", \\\"{x:1596,y:617,t:1527009196634};\\\", \\\"{x:1596,y:618,t:1527009196650};\\\", \\\"{x:1596,y:620,t:1527009196669};\\\", \\\"{x:1596,y:621,t:1527009196684};\\\", \\\"{x:1596,y:623,t:1527009196700};\\\", \\\"{x:1596,y:624,t:1527009196717};\\\", \\\"{x:1596,y:626,t:1527009196734};\\\", \\\"{x:1596,y:627,t:1527009196751};\\\", \\\"{x:1595,y:628,t:1527009196767};\\\", \\\"{x:1593,y:630,t:1527009196784};\\\", \\\"{x:1592,y:631,t:1527009196813};\\\", \\\"{x:1591,y:631,t:1527009196837};\\\", \\\"{x:1590,y:632,t:1527009196877};\\\", \\\"{x:1589,y:633,t:1527009196909};\\\", \\\"{x:1588,y:633,t:1527009197005};\\\", \\\"{x:1587,y:634,t:1527009197133};\\\", \\\"{x:1585,y:634,t:1527009197189};\\\", \\\"{x:1584,y:635,t:1527009197218};\\\", \\\"{x:1583,y:636,t:1527009197234};\\\", \\\"{x:1582,y:636,t:1527009197389};\\\", \\\"{x:1581,y:636,t:1527009198309};\\\", \\\"{x:1580,y:636,t:1527009198373};\\\", \\\"{x:1579,y:636,t:1527009198564};\\\", \\\"{x:1577,y:636,t:1527009198645};\\\", \\\"{x:1574,y:636,t:1527009198653};\\\", \\\"{x:1569,y:639,t:1527009198669};\\\", \\\"{x:1558,y:653,t:1527009198685};\\\", \\\"{x:1536,y:682,t:1527009198703};\\\", \\\"{x:1515,y:707,t:1527009198719};\\\", \\\"{x:1495,y:735,t:1527009198735};\\\", \\\"{x:1478,y:758,t:1527009198752};\\\", \\\"{x:1458,y:783,t:1527009198770};\\\", \\\"{x:1445,y:801,t:1527009198785};\\\", \\\"{x:1437,y:814,t:1527009198802};\\\", \\\"{x:1432,y:824,t:1527009198819};\\\", \\\"{x:1422,y:836,t:1527009198835};\\\", \\\"{x:1413,y:848,t:1527009198852};\\\", \\\"{x:1400,y:865,t:1527009198868};\\\", \\\"{x:1391,y:873,t:1527009198885};\\\", \\\"{x:1387,y:876,t:1527009198902};\\\", \\\"{x:1385,y:878,t:1527009198919};\\\", \\\"{x:1383,y:878,t:1527009198936};\\\", \\\"{x:1382,y:879,t:1527009198957};\\\", \\\"{x:1379,y:878,t:1527009199061};\\\", \\\"{x:1374,y:873,t:1527009199069};\\\", \\\"{x:1366,y:862,t:1527009199086};\\\", \\\"{x:1353,y:844,t:1527009199103};\\\", \\\"{x:1343,y:829,t:1527009199119};\\\", \\\"{x:1335,y:815,t:1527009199136};\\\", \\\"{x:1332,y:811,t:1527009199152};\\\", \\\"{x:1330,y:807,t:1527009199169};\\\", \\\"{x:1329,y:806,t:1527009199186};\\\", \\\"{x:1329,y:805,t:1527009199213};\\\", \\\"{x:1329,y:804,t:1527009199229};\\\", \\\"{x:1329,y:802,t:1527009199253};\\\", \\\"{x:1330,y:797,t:1527009199269};\\\", \\\"{x:1336,y:794,t:1527009199286};\\\", \\\"{x:1341,y:791,t:1527009199302};\\\", \\\"{x:1344,y:789,t:1527009199319};\\\", \\\"{x:1346,y:788,t:1527009199337};\\\", \\\"{x:1347,y:788,t:1527009199354};\\\", \\\"{x:1348,y:788,t:1527009199369};\\\", \\\"{x:1349,y:788,t:1527009199386};\\\", \\\"{x:1350,y:787,t:1527009199403};\\\", \\\"{x:1350,y:786,t:1527009199419};\\\", \\\"{x:1350,y:787,t:1527009199653};\\\", \\\"{x:1343,y:806,t:1527009199669};\\\", \\\"{x:1333,y:829,t:1527009199686};\\\", \\\"{x:1322,y:851,t:1527009199703};\\\", \\\"{x:1308,y:874,t:1527009199720};\\\", \\\"{x:1293,y:896,t:1527009199736};\\\", \\\"{x:1282,y:916,t:1527009199754};\\\", \\\"{x:1271,y:932,t:1527009199770};\\\", \\\"{x:1262,y:942,t:1527009199786};\\\", \\\"{x:1258,y:947,t:1527009199803};\\\", \\\"{x:1257,y:949,t:1527009199820};\\\", \\\"{x:1256,y:950,t:1527009199836};\\\", \\\"{x:1255,y:950,t:1527009199853};\\\", \\\"{x:1254,y:951,t:1527009199870};\\\", \\\"{x:1253,y:951,t:1527009199965};\\\", \\\"{x:1252,y:951,t:1527009199981};\\\", \\\"{x:1251,y:951,t:1527009199989};\\\", \\\"{x:1250,y:951,t:1527009200005};\\\", \\\"{x:1248,y:951,t:1527009200020};\\\", \\\"{x:1247,y:951,t:1527009200052};\\\", \\\"{x:1246,y:951,t:1527009200077};\\\", \\\"{x:1245,y:951,t:1527009200117};\\\", \\\"{x:1244,y:951,t:1527009200485};\\\", \\\"{x:1243,y:951,t:1527009200492};\\\", \\\"{x:1242,y:951,t:1527009200565};\\\", \\\"{x:1240,y:951,t:1527009200637};\\\", \\\"{x:1239,y:951,t:1527009200717};\\\", \\\"{x:1237,y:951,t:1527009200797};\\\", \\\"{x:1236,y:951,t:1527009200820};\\\", \\\"{x:1235,y:951,t:1527009200877};\\\", \\\"{x:1235,y:952,t:1527009200933};\\\", \\\"{x:1230,y:952,t:1527009203013};\\\", \\\"{x:1219,y:952,t:1527009203022};\\\", \\\"{x:1189,y:952,t:1527009203039};\\\", \\\"{x:1131,y:938,t:1527009203055};\\\", \\\"{x:1057,y:908,t:1527009203072};\\\", \\\"{x:939,y:860,t:1527009203089};\\\", \\\"{x:799,y:780,t:1527009203105};\\\", \\\"{x:672,y:695,t:1527009203123};\\\", \\\"{x:571,y:615,t:1527009203139};\\\", \\\"{x:512,y:562,t:1527009203156};\\\", \\\"{x:482,y:531,t:1527009203173};\\\", \\\"{x:473,y:515,t:1527009203189};\\\", \\\"{x:469,y:508,t:1527009203205};\\\", \\\"{x:469,y:507,t:1527009203222};\\\", \\\"{x:469,y:506,t:1527009203239};\\\", \\\"{x:478,y:507,t:1527009203255};\\\", \\\"{x:490,y:512,t:1527009203272};\\\", \\\"{x:503,y:518,t:1527009203289};\\\", \\\"{x:512,y:527,t:1527009203306};\\\", \\\"{x:515,y:531,t:1527009203322};\\\", \\\"{x:518,y:537,t:1527009203340};\\\", \\\"{x:519,y:538,t:1527009203356};\\\", \\\"{x:519,y:541,t:1527009203372};\\\", \\\"{x:515,y:546,t:1527009203389};\\\", \\\"{x:509,y:550,t:1527009203406};\\\", \\\"{x:500,y:555,t:1527009203422};\\\", \\\"{x:491,y:557,t:1527009203440};\\\", \\\"{x:478,y:561,t:1527009203455};\\\", \\\"{x:464,y:564,t:1527009203473};\\\", \\\"{x:447,y:565,t:1527009203489};\\\", \\\"{x:433,y:566,t:1527009203506};\\\", \\\"{x:418,y:566,t:1527009203522};\\\", \\\"{x:404,y:566,t:1527009203540};\\\", \\\"{x:398,y:566,t:1527009203556};\\\", \\\"{x:396,y:566,t:1527009203572};\\\", \\\"{x:396,y:565,t:1527009203620};\\\", \\\"{x:413,y:559,t:1527009203639};\\\", \\\"{x:450,y:547,t:1527009203657};\\\", \\\"{x:511,y:530,t:1527009203673};\\\", \\\"{x:587,y:518,t:1527009203690};\\\", \\\"{x:670,y:507,t:1527009203707};\\\", \\\"{x:738,y:495,t:1527009203723};\\\", \\\"{x:784,y:490,t:1527009203739};\\\", \\\"{x:812,y:487,t:1527009203756};\\\", \\\"{x:827,y:487,t:1527009203772};\\\", \\\"{x:828,y:487,t:1527009203789};\\\", \\\"{x:829,y:487,t:1527009203806};\\\", \\\"{x:834,y:487,t:1527009203823};\\\", \\\"{x:844,y:487,t:1527009203839};\\\", \\\"{x:851,y:487,t:1527009203856};\\\", \\\"{x:856,y:488,t:1527009203873};\\\", \\\"{x:859,y:489,t:1527009203889};\\\", \\\"{x:861,y:489,t:1527009203906};\\\", \\\"{x:862,y:490,t:1527009203923};\\\", \\\"{x:864,y:491,t:1527009203939};\\\", \\\"{x:866,y:493,t:1527009203957};\\\", \\\"{x:869,y:496,t:1527009203973};\\\", \\\"{x:869,y:497,t:1527009203989};\\\", \\\"{x:870,y:500,t:1527009204007};\\\", \\\"{x:870,y:501,t:1527009204028};\\\", \\\"{x:867,y:503,t:1527009204039};\\\", \\\"{x:859,y:505,t:1527009204056};\\\", \\\"{x:846,y:506,t:1527009204073};\\\", \\\"{x:836,y:509,t:1527009204089};\\\", \\\"{x:828,y:509,t:1527009204106};\\\", \\\"{x:823,y:509,t:1527009204123};\\\", \\\"{x:820,y:510,t:1527009204139};\\\", \\\"{x:819,y:510,t:1527009204156};\\\", \\\"{x:819,y:511,t:1527009204229};\\\", \\\"{x:819,y:512,t:1527009204239};\\\", \\\"{x:820,y:513,t:1527009204256};\\\", \\\"{x:824,y:514,t:1527009204273};\\\", \\\"{x:825,y:515,t:1527009204290};\\\", \\\"{x:826,y:515,t:1527009204306};\\\", \\\"{x:826,y:514,t:1527009204892};\\\", \\\"{x:826,y:512,t:1527009204916};\\\", \\\"{x:825,y:512,t:1527009204981};\\\", \\\"{x:824,y:512,t:1527009204990};\\\", \\\"{x:823,y:512,t:1527009205008};\\\", \\\"{x:819,y:513,t:1527009205024};\\\", \\\"{x:815,y:516,t:1527009205040};\\\", \\\"{x:813,y:517,t:1527009205057};\\\", \\\"{x:811,y:518,t:1527009205074};\\\", \\\"{x:808,y:524,t:1527009205090};\\\", \\\"{x:802,y:530,t:1527009205108};\\\", \\\"{x:796,y:539,t:1527009205123};\\\", \\\"{x:791,y:546,t:1527009205140};\\\", \\\"{x:790,y:547,t:1527009205157};\\\", \\\"{x:789,y:548,t:1527009205174};\\\", \\\"{x:790,y:548,t:1527009205213};\\\", \\\"{x:796,y:546,t:1527009205224};\\\", \\\"{x:810,y:534,t:1527009205240};\\\", \\\"{x:823,y:524,t:1527009205257};\\\", \\\"{x:831,y:518,t:1527009205275};\\\", \\\"{x:836,y:516,t:1527009205291};\\\", \\\"{x:837,y:514,t:1527009205307};\\\", \\\"{x:838,y:514,t:1527009205324};\\\", \\\"{x:838,y:513,t:1527009205340};\\\", \\\"{x:838,y:509,t:1527009205357};\\\", \\\"{x:840,y:506,t:1527009205374};\\\", \\\"{x:840,y:503,t:1527009205390};\\\", \\\"{x:840,y:501,t:1527009205407};\\\", \\\"{x:840,y:500,t:1527009205525};\\\", \\\"{x:839,y:500,t:1527009205548};\\\", \\\"{x:838,y:500,t:1527009205572};\\\", \\\"{x:837,y:500,t:1527009205581};\\\", \\\"{x:836,y:500,t:1527009205591};\\\", \\\"{x:835,y:500,t:1527009205612};\\\", \\\"{x:834,y:500,t:1527009205624};\\\", \\\"{x:833,y:500,t:1527009205641};\\\", \\\"{x:832,y:501,t:1527009205717};\\\", \\\"{x:830,y:503,t:1527009209646};\\\", \\\"{x:824,y:508,t:1527009209661};\\\", \\\"{x:808,y:518,t:1527009209678};\\\", \\\"{x:802,y:520,t:1527009209693};\\\", \\\"{x:798,y:523,t:1527009209710};\\\", \\\"{x:794,y:524,t:1527009209728};\\\", \\\"{x:786,y:528,t:1527009209744};\\\", \\\"{x:778,y:532,t:1527009209760};\\\", \\\"{x:768,y:537,t:1527009209777};\\\", \\\"{x:760,y:541,t:1527009209794};\\\", \\\"{x:750,y:545,t:1527009209811};\\\", \\\"{x:741,y:549,t:1527009209827};\\\", \\\"{x:724,y:557,t:1527009209845};\\\", \\\"{x:707,y:564,t:1527009209861};\\\", \\\"{x:687,y:572,t:1527009209878};\\\", \\\"{x:667,y:580,t:1527009209895};\\\", \\\"{x:653,y:586,t:1527009209911};\\\", \\\"{x:645,y:589,t:1527009209928};\\\", \\\"{x:637,y:591,t:1527009209944};\\\", \\\"{x:621,y:591,t:1527009209962};\\\", \\\"{x:610,y:590,t:1527009209977};\\\", \\\"{x:602,y:586,t:1527009209994};\\\", \\\"{x:597,y:583,t:1527009210012};\\\", \\\"{x:597,y:579,t:1527009210027};\\\", \\\"{x:595,y:575,t:1527009210045};\\\", \\\"{x:593,y:572,t:1527009210061};\\\", \\\"{x:590,y:571,t:1527009210079};\\\", \\\"{x:584,y:570,t:1527009210094};\\\", \\\"{x:571,y:568,t:1527009210112};\\\", \\\"{x:553,y:566,t:1527009210128};\\\", \\\"{x:535,y:562,t:1527009210145};\\\", \\\"{x:520,y:561,t:1527009210161};\\\", \\\"{x:505,y:559,t:1527009210177};\\\", \\\"{x:489,y:556,t:1527009210195};\\\", \\\"{x:475,y:556,t:1527009210211};\\\", \\\"{x:452,y:556,t:1527009210228};\\\", \\\"{x:441,y:556,t:1527009210244};\\\", \\\"{x:432,y:556,t:1527009210261};\\\", \\\"{x:424,y:556,t:1527009210278};\\\", \\\"{x:411,y:556,t:1527009210296};\\\", \\\"{x:396,y:556,t:1527009210311};\\\", \\\"{x:376,y:556,t:1527009210328};\\\", \\\"{x:353,y:556,t:1527009210345};\\\", \\\"{x:327,y:556,t:1527009210363};\\\", \\\"{x:294,y:556,t:1527009210378};\\\", \\\"{x:266,y:556,t:1527009210396};\\\", \\\"{x:234,y:556,t:1527009210413};\\\", \\\"{x:218,y:558,t:1527009210428};\\\", \\\"{x:211,y:562,t:1527009210446};\\\", \\\"{x:207,y:565,t:1527009210463};\\\", \\\"{x:204,y:568,t:1527009210480};\\\", \\\"{x:202,y:570,t:1527009210494};\\\", \\\"{x:200,y:573,t:1527009210512};\\\", \\\"{x:193,y:579,t:1527009210527};\\\", \\\"{x:190,y:582,t:1527009210545};\\\", \\\"{x:179,y:586,t:1527009210562};\\\", \\\"{x:173,y:589,t:1527009210579};\\\", \\\"{x:169,y:591,t:1527009210595};\\\", \\\"{x:167,y:592,t:1527009210612};\\\", \\\"{x:165,y:594,t:1527009210628};\\\", \\\"{x:165,y:595,t:1527009210692};\\\", \\\"{x:168,y:595,t:1527009210780};\\\", \\\"{x:173,y:594,t:1527009210795};\\\", \\\"{x:189,y:592,t:1527009210812};\\\", \\\"{x:221,y:586,t:1527009210828};\\\", \\\"{x:248,y:583,t:1527009210845};\\\", \\\"{x:284,y:579,t:1527009210862};\\\", \\\"{x:327,y:576,t:1527009210878};\\\", \\\"{x:365,y:568,t:1527009210895};\\\", \\\"{x:403,y:560,t:1527009210912};\\\", \\\"{x:449,y:551,t:1527009210929};\\\", \\\"{x:495,y:542,t:1527009210946};\\\", \\\"{x:554,y:534,t:1527009210962};\\\", \\\"{x:596,y:528,t:1527009210978};\\\", \\\"{x:624,y:528,t:1527009210996};\\\", \\\"{x:655,y:528,t:1527009211013};\\\", \\\"{x:681,y:528,t:1527009211028};\\\", \\\"{x:706,y:528,t:1527009211045};\\\", \\\"{x:727,y:528,t:1527009211062};\\\", \\\"{x:741,y:528,t:1527009211079};\\\", \\\"{x:751,y:529,t:1527009211096};\\\", \\\"{x:767,y:535,t:1527009211112};\\\", \\\"{x:790,y:544,t:1527009211128};\\\", \\\"{x:811,y:556,t:1527009211146};\\\", \\\"{x:829,y:563,t:1527009211162};\\\", \\\"{x:844,y:568,t:1527009211178};\\\", \\\"{x:854,y:572,t:1527009211195};\\\", \\\"{x:857,y:573,t:1527009211212};\\\", \\\"{x:856,y:572,t:1527009211293};\\\", \\\"{x:855,y:571,t:1527009211301};\\\", \\\"{x:851,y:567,t:1527009211312};\\\", \\\"{x:843,y:556,t:1527009211329};\\\", \\\"{x:834,y:547,t:1527009211346};\\\", \\\"{x:828,y:544,t:1527009211362};\\\", \\\"{x:826,y:542,t:1527009211379};\\\", \\\"{x:823,y:540,t:1527009211396};\\\", \\\"{x:822,y:538,t:1527009211412};\\\", \\\"{x:822,y:537,t:1527009211429};\\\", \\\"{x:822,y:535,t:1527009211445};\\\", \\\"{x:823,y:535,t:1527009211485};\\\", \\\"{x:826,y:535,t:1527009211495};\\\", \\\"{x:828,y:535,t:1527009211513};\\\", \\\"{x:830,y:535,t:1527009211525};\\\", \\\"{x:832,y:536,t:1527009211546};\\\", \\\"{x:832,y:536,t:1527009211617};\\\", \\\"{x:832,y:538,t:1527009211661};\\\", \\\"{x:831,y:541,t:1527009211668};\\\", \\\"{x:830,y:543,t:1527009211678};\\\", \\\"{x:827,y:548,t:1527009211695};\\\", \\\"{x:825,y:553,t:1527009211712};\\\", \\\"{x:819,y:563,t:1527009211729};\\\", \\\"{x:815,y:570,t:1527009211745};\\\", \\\"{x:812,y:576,t:1527009211763};\\\", \\\"{x:812,y:578,t:1527009211780};\\\", \\\"{x:812,y:577,t:1527009211860};\\\", \\\"{x:814,y:567,t:1527009211868};\\\", \\\"{x:819,y:556,t:1527009211879};\\\", \\\"{x:825,y:538,t:1527009211896};\\\", \\\"{x:827,y:533,t:1527009211913};\\\", \\\"{x:829,y:527,t:1527009211930};\\\", \\\"{x:829,y:526,t:1527009211946};\\\", \\\"{x:829,y:524,t:1527009211963};\\\", \\\"{x:829,y:522,t:1527009212004};\\\", \\\"{x:829,y:521,t:1527009212013};\\\", \\\"{x:829,y:520,t:1527009212029};\\\", \\\"{x:832,y:516,t:1527009212046};\\\", \\\"{x:834,y:513,t:1527009212063};\\\", \\\"{x:836,y:510,t:1527009212080};\\\", \\\"{x:836,y:509,t:1527009212096};\\\", \\\"{x:838,y:507,t:1527009212112};\\\", \\\"{x:839,y:506,t:1527009212130};\\\", \\\"{x:839,y:505,t:1527009212146};\\\", \\\"{x:841,y:503,t:1527009212163};\\\", \\\"{x:841,y:502,t:1527009212180};\\\", \\\"{x:842,y:500,t:1527009212196};\\\", \\\"{x:841,y:500,t:1527009212628};\\\", \\\"{x:841,y:501,t:1527009212644};\\\", \\\"{x:840,y:501,t:1527009212660};\\\", \\\"{x:839,y:501,t:1527009212668};\\\", \\\"{x:838,y:502,t:1527009212679};\\\", \\\"{x:837,y:502,t:1527009212696};\\\", \\\"{x:836,y:504,t:1527009212714};\\\", \\\"{x:833,y:506,t:1527009212730};\\\", \\\"{x:831,y:507,t:1527009212748};\\\", \\\"{x:827,y:510,t:1527009212763};\\\", \\\"{x:820,y:516,t:1527009212780};\\\", \\\"{x:802,y:527,t:1527009212797};\\\", \\\"{x:788,y:537,t:1527009212814};\\\", \\\"{x:768,y:548,t:1527009212829};\\\", \\\"{x:751,y:558,t:1527009212847};\\\", \\\"{x:731,y:568,t:1527009212864};\\\", \\\"{x:709,y:577,t:1527009212879};\\\", \\\"{x:689,y:587,t:1527009212896};\\\", \\\"{x:673,y:596,t:1527009212914};\\\", \\\"{x:657,y:604,t:1527009212930};\\\", \\\"{x:642,y:612,t:1527009212947};\\\", \\\"{x:630,y:618,t:1527009212964};\\\", \\\"{x:617,y:624,t:1527009212980};\\\", \\\"{x:608,y:629,t:1527009212997};\\\", \\\"{x:601,y:633,t:1527009213015};\\\", \\\"{x:594,y:637,t:1527009213031};\\\", \\\"{x:591,y:639,t:1527009213046};\\\", \\\"{x:590,y:639,t:1527009213064};\\\", \\\"{x:596,y:633,t:1527009213164};\\\", \\\"{x:611,y:619,t:1527009213180};\\\", \\\"{x:644,y:599,t:1527009213197};\\\", \\\"{x:682,y:581,t:1527009213214};\\\", \\\"{x:712,y:569,t:1527009213230};\\\", \\\"{x:741,y:563,t:1527009213246};\\\", \\\"{x:764,y:558,t:1527009213264};\\\", \\\"{x:785,y:553,t:1527009213281};\\\", \\\"{x:802,y:549,t:1527009213296};\\\", \\\"{x:811,y:548,t:1527009213313};\\\", \\\"{x:818,y:545,t:1527009213331};\\\", \\\"{x:820,y:543,t:1527009213347};\\\", \\\"{x:821,y:543,t:1527009213363};\\\", \\\"{x:822,y:542,t:1527009213381};\\\", \\\"{x:823,y:540,t:1527009213397};\\\", \\\"{x:823,y:539,t:1527009213414};\\\", \\\"{x:823,y:538,t:1527009213431};\\\", \\\"{x:823,y:535,t:1527009213447};\\\", \\\"{x:823,y:533,t:1527009213464};\\\", \\\"{x:823,y:531,t:1527009213481};\\\", \\\"{x:823,y:529,t:1527009213497};\\\", \\\"{x:823,y:527,t:1527009213514};\\\", \\\"{x:823,y:525,t:1527009213530};\\\", \\\"{x:823,y:523,t:1527009213549};\\\", \\\"{x:823,y:522,t:1527009213564};\\\", \\\"{x:825,y:518,t:1527009213580};\\\", \\\"{x:826,y:517,t:1527009213598};\\\", \\\"{x:830,y:512,t:1527009213614};\\\", \\\"{x:832,y:510,t:1527009213631};\\\", \\\"{x:835,y:507,t:1527009213648};\\\", \\\"{x:836,y:505,t:1527009213665};\\\", \\\"{x:837,y:505,t:1527009213681};\\\", \\\"{x:836,y:505,t:1527009217517};\\\", \\\"{x:830,y:507,t:1527009217524};\\\", \\\"{x:820,y:513,t:1527009217538};\\\", \\\"{x:803,y:523,t:1527009217555};\\\", \\\"{x:788,y:532,t:1527009217571};\\\", \\\"{x:777,y:538,t:1527009217584};\\\", \\\"{x:763,y:548,t:1527009217601};\\\", \\\"{x:749,y:560,t:1527009217617};\\\", \\\"{x:734,y:576,t:1527009217635};\\\", \\\"{x:716,y:596,t:1527009217651};\\\", \\\"{x:704,y:610,t:1527009217667};\\\", \\\"{x:695,y:621,t:1527009217684};\\\", \\\"{x:683,y:635,t:1527009217701};\\\", \\\"{x:675,y:647,t:1527009217717};\\\", \\\"{x:665,y:660,t:1527009217734};\\\", \\\"{x:654,y:675,t:1527009217750};\\\", \\\"{x:643,y:689,t:1527009217767};\\\", \\\"{x:631,y:703,t:1527009217784};\\\", \\\"{x:608,y:726,t:1527009217800};\\\", \\\"{x:570,y:761,t:1527009217817};\\\", \\\"{x:526,y:799,t:1527009217833};\\\", \\\"{x:479,y:830,t:1527009217851};\\\", \\\"{x:438,y:846,t:1527009217868};\\\", \\\"{x:403,y:861,t:1527009217884};\\\", \\\"{x:363,y:879,t:1527009217901};\\\", \\\"{x:352,y:888,t:1527009217918};\\\", \\\"{x:347,y:891,t:1527009217934};\\\", \\\"{x:346,y:892,t:1527009217951};\\\", \\\"{x:346,y:893,t:1527009217968};\\\", \\\"{x:346,y:895,t:1527009217988};\\\", \\\"{x:347,y:896,t:1527009218005};\\\", \\\"{x:349,y:898,t:1527009218018};\\\", \\\"{x:353,y:898,t:1527009218034};\\\", \\\"{x:363,y:898,t:1527009218052};\\\", \\\"{x:381,y:882,t:1527009218068};\\\", \\\"{x:432,y:834,t:1527009218085};\\\", \\\"{x:467,y:804,t:1527009218101};\\\", \\\"{x:489,y:785,t:1527009218119};\\\", \\\"{x:505,y:770,t:1527009218135};\\\", \\\"{x:513,y:758,t:1527009218151};\\\", \\\"{x:518,y:751,t:1527009218168};\\\", \\\"{x:518,y:746,t:1527009218185};\\\", \\\"{x:518,y:744,t:1527009218201};\\\", \\\"{x:518,y:742,t:1527009218218};\\\", \\\"{x:518,y:741,t:1527009218245};\\\", \\\"{x:518,y:737,t:1527009219028};\\\", \\\"{x:522,y:730,t:1527009219036};\\\", \\\"{x:523,y:726,t:1527009219052};\\\", \\\"{x:527,y:719,t:1527009219067};\\\", \\\"{x:533,y:701,t:1527009219085};\\\", \\\"{x:537,y:692,t:1527009219102};\\\", \\\"{x:541,y:683,t:1527009219118};\\\", \\\"{x:545,y:676,t:1527009219135};\\\", \\\"{x:550,y:663,t:1527009219152};\\\", \\\"{x:561,y:645,t:1527009219168};\\\", \\\"{x:572,y:624,t:1527009219185};\\\", \\\"{x:585,y:591,t:1527009219202};\\\", \\\"{x:598,y:558,t:1527009219218};\\\", \\\"{x:608,y:537,t:1527009219235};\\\", \\\"{x:613,y:526,t:1527009219252};\\\", \\\"{x:615,y:520,t:1527009219268};\\\", \\\"{x:615,y:518,t:1527009219285};\\\", \\\"{x:615,y:517,t:1527009219308};\\\", \\\"{x:615,y:516,t:1527009219333};\\\", \\\"{x:615,y:515,t:1527009219652};\\\", \\\"{x:617,y:513,t:1527009219669};\\\", \\\"{x:617,y:511,t:1527009219765};\\\" ] }, { \\\"rt\\\": 13912, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 13, \\\"time_elapsed\\\": 408219, \\\"internal_node_id\\\": \\\"0.0-6.0-3.0\\\", \\\"subject\\\": \\\"38NFJ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"echo\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime+before+endtime+during\\\", \\\"q\\\": 9, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-G \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:615,y:511,t:1527009220533};\\\", \\\"{x:610,y:511,t:1527009220540};\\\", \\\"{x:604,y:511,t:1527009220553};\\\", \\\"{x:594,y:511,t:1527009220571};\\\", \\\"{x:577,y:513,t:1527009220586};\\\", \\\"{x:550,y:513,t:1527009220603};\\\", \\\"{x:510,y:506,t:1527009220619};\\\", \\\"{x:470,y:501,t:1527009220636};\\\", \\\"{x:429,y:501,t:1527009220652};\\\", \\\"{x:413,y:501,t:1527009220670};\\\", \\\"{x:407,y:501,t:1527009220686};\\\", \\\"{x:406,y:501,t:1527009220703};\\\", \\\"{x:406,y:500,t:1527009220933};\\\", \\\"{x:405,y:498,t:1527009220949};\\\", \\\"{x:405,y:497,t:1527009220964};\\\", \\\"{x:405,y:495,t:1527009220981};\\\", \\\"{x:405,y:494,t:1527009220988};\\\", \\\"{x:405,y:491,t:1527009221003};\\\", \\\"{x:405,y:484,t:1527009221020};\\\", \\\"{x:405,y:480,t:1527009221036};\\\", \\\"{x:406,y:475,t:1527009221053};\\\", \\\"{x:406,y:472,t:1527009221070};\\\", \\\"{x:407,y:470,t:1527009221087};\\\", \\\"{x:407,y:469,t:1527009221109};\\\", \\\"{x:409,y:467,t:1527009221124};\\\", \\\"{x:410,y:466,t:1527009221137};\\\", \\\"{x:411,y:465,t:1527009221154};\\\", \\\"{x:413,y:463,t:1527009221170};\\\", \\\"{x:415,y:460,t:1527009221187};\\\", \\\"{x:417,y:458,t:1527009221204};\\\", \\\"{x:420,y:455,t:1527009221220};\\\", \\\"{x:423,y:453,t:1527009221236};\\\", \\\"{x:424,y:453,t:1527009221284};\\\", \\\"{x:426,y:452,t:1527009221292};\\\", \\\"{x:426,y:451,t:1527009221304};\\\", \\\"{x:429,y:450,t:1527009221320};\\\", \\\"{x:430,y:449,t:1527009221337};\\\", \\\"{x:431,y:449,t:1527009221356};\\\", \\\"{x:431,y:448,t:1527009221371};\\\", \\\"{x:432,y:448,t:1527009221388};\\\", \\\"{x:432,y:447,t:1527009221652};\\\", \\\"{x:433,y:446,t:1527009221668};\\\", \\\"{x:434,y:446,t:1527009221684};\\\", \\\"{x:435,y:446,t:1527009221700};\\\", \\\"{x:436,y:446,t:1527009221716};\\\", \\\"{x:437,y:446,t:1527009221732};\\\", \\\"{x:438,y:446,t:1527009222005};\\\", \\\"{x:444,y:446,t:1527009222021};\\\", \\\"{x:460,y:446,t:1527009222039};\\\", \\\"{x:490,y:446,t:1527009222055};\\\", \\\"{x:539,y:435,t:1527009222071};\\\", \\\"{x:589,y:414,t:1527009222088};\\\", \\\"{x:624,y:400,t:1527009222105};\\\", \\\"{x:641,y:394,t:1527009222121};\\\", \\\"{x:652,y:388,t:1527009222138};\\\", \\\"{x:655,y:386,t:1527009222155};\\\", \\\"{x:657,y:386,t:1527009222172};\\\", \\\"{x:657,y:385,t:1527009222188};\\\", \\\"{x:658,y:385,t:1527009222205};\\\", \\\"{x:661,y:389,t:1527009222222};\\\", \\\"{x:662,y:394,t:1527009222238};\\\", \\\"{x:665,y:398,t:1527009222255};\\\", \\\"{x:665,y:402,t:1527009222272};\\\", \\\"{x:666,y:407,t:1527009222287};\\\", \\\"{x:665,y:414,t:1527009222305};\\\", \\\"{x:660,y:423,t:1527009222322};\\\", \\\"{x:655,y:433,t:1527009222338};\\\", \\\"{x:649,y:441,t:1527009222355};\\\", \\\"{x:646,y:446,t:1527009222373};\\\", \\\"{x:643,y:449,t:1527009222388};\\\", \\\"{x:640,y:453,t:1527009222405};\\\", \\\"{x:635,y:458,t:1527009222422};\\\", \\\"{x:626,y:463,t:1527009222439};\\\", \\\"{x:624,y:466,t:1527009222455};\\\", \\\"{x:621,y:468,t:1527009222472};\\\", \\\"{x:619,y:469,t:1527009222489};\\\", \\\"{x:616,y:469,t:1527009222506};\\\", \\\"{x:615,y:470,t:1527009222523};\\\", \\\"{x:614,y:470,t:1527009222539};\\\", \\\"{x:612,y:470,t:1527009222555};\\\", \\\"{x:607,y:470,t:1527009222572};\\\", \\\"{x:603,y:470,t:1527009222589};\\\", \\\"{x:600,y:470,t:1527009222605};\\\", \\\"{x:599,y:470,t:1527009222622};\\\", \\\"{x:597,y:470,t:1527009222639};\\\", \\\"{x:596,y:470,t:1527009222655};\\\", \\\"{x:595,y:470,t:1527009222684};\\\", \\\"{x:593,y:470,t:1527009222692};\\\", \\\"{x:592,y:470,t:1527009222708};\\\", \\\"{x:591,y:469,t:1527009222722};\\\", \\\"{x:590,y:468,t:1527009222739};\\\", \\\"{x:588,y:468,t:1527009222756};\\\", \\\"{x:586,y:467,t:1527009222772};\\\", \\\"{x:583,y:465,t:1527009222788};\\\", \\\"{x:582,y:464,t:1527009223005};\\\", \\\"{x:581,y:464,t:1527009223012};\\\", \\\"{x:581,y:462,t:1527009223023};\\\", \\\"{x:580,y:460,t:1527009223038};\\\", \\\"{x:580,y:459,t:1527009223056};\\\", \\\"{x:579,y:458,t:1527009223073};\\\", \\\"{x:579,y:457,t:1527009223089};\\\", \\\"{x:580,y:455,t:1527009223437};\\\", \\\"{x:582,y:455,t:1527009223445};\\\", \\\"{x:584,y:456,t:1527009223457};\\\", \\\"{x:592,y:457,t:1527009223473};\\\", \\\"{x:597,y:460,t:1527009223490};\\\", \\\"{x:601,y:461,t:1527009223507};\\\", \\\"{x:607,y:464,t:1527009223523};\\\", \\\"{x:614,y:465,t:1527009223541};\\\", \\\"{x:635,y:474,t:1527009223557};\\\", \\\"{x:648,y:477,t:1527009223574};\\\", \\\"{x:653,y:478,t:1527009223590};\\\", \\\"{x:654,y:479,t:1527009223607};\\\", \\\"{x:654,y:481,t:1527009223750};\\\", \\\"{x:656,y:485,t:1527009223757};\\\", \\\"{x:664,y:498,t:1527009223776};\\\", \\\"{x:674,y:513,t:1527009223791};\\\", \\\"{x:682,y:524,t:1527009223808};\\\", \\\"{x:693,y:537,t:1527009223822};\\\", \\\"{x:699,y:545,t:1527009223840};\\\", \\\"{x:704,y:549,t:1527009223856};\\\", \\\"{x:710,y:554,t:1527009223872};\\\", \\\"{x:716,y:560,t:1527009223889};\\\", \\\"{x:720,y:565,t:1527009223906};\\\", \\\"{x:721,y:567,t:1527009223922};\\\", \\\"{x:721,y:570,t:1527009223939};\\\", \\\"{x:722,y:575,t:1527009223956};\\\", \\\"{x:722,y:576,t:1527009223972};\\\", \\\"{x:722,y:578,t:1527009223989};\\\", \\\"{x:722,y:579,t:1527009224012};\\\", \\\"{x:722,y:580,t:1527009224036};\\\", \\\"{x:722,y:581,t:1527009224052};\\\", \\\"{x:725,y:577,t:1527009224717};\\\", \\\"{x:727,y:576,t:1527009224732};\\\", \\\"{x:728,y:575,t:1527009224740};\\\", \\\"{x:731,y:575,t:1527009224756};\\\", \\\"{x:735,y:575,t:1527009224773};\\\", \\\"{x:744,y:577,t:1527009224789};\\\", \\\"{x:763,y:585,t:1527009224806};\\\", \\\"{x:792,y:595,t:1527009224823};\\\", \\\"{x:843,y:606,t:1527009224841};\\\", \\\"{x:924,y:615,t:1527009224857};\\\", \\\"{x:1035,y:634,t:1527009224874};\\\", \\\"{x:1163,y:652,t:1527009224890};\\\", \\\"{x:1268,y:652,t:1527009224906};\\\", \\\"{x:1340,y:652,t:1527009224923};\\\", \\\"{x:1382,y:642,t:1527009224939};\\\", \\\"{x:1404,y:630,t:1527009224956};\\\", \\\"{x:1428,y:609,t:1527009224972};\\\", \\\"{x:1443,y:594,t:1527009224989};\\\", \\\"{x:1461,y:580,t:1527009225007};\\\", \\\"{x:1474,y:569,t:1527009225023};\\\", \\\"{x:1481,y:562,t:1527009225040};\\\", \\\"{x:1483,y:559,t:1527009225056};\\\", \\\"{x:1483,y:558,t:1527009225072};\\\", \\\"{x:1481,y:555,t:1527009225090};\\\", \\\"{x:1479,y:553,t:1527009225107};\\\", \\\"{x:1473,y:550,t:1527009225123};\\\", \\\"{x:1469,y:548,t:1527009225140};\\\", \\\"{x:1466,y:547,t:1527009225156};\\\", \\\"{x:1455,y:545,t:1527009225173};\\\", \\\"{x:1442,y:545,t:1527009225189};\\\", \\\"{x:1426,y:545,t:1527009225207};\\\", \\\"{x:1414,y:545,t:1527009225222};\\\", \\\"{x:1403,y:542,t:1527009225239};\\\", \\\"{x:1398,y:542,t:1527009225256};\\\", \\\"{x:1397,y:542,t:1527009225272};\\\", \\\"{x:1395,y:542,t:1527009225300};\\\", \\\"{x:1392,y:542,t:1527009225308};\\\", \\\"{x:1388,y:541,t:1527009225322};\\\", \\\"{x:1378,y:539,t:1527009225339};\\\", \\\"{x:1371,y:538,t:1527009225355};\\\", \\\"{x:1370,y:539,t:1527009225421};\\\", \\\"{x:1375,y:547,t:1527009225428};\\\", \\\"{x:1382,y:553,t:1527009225440};\\\", \\\"{x:1382,y:554,t:1527009225455};\\\", \\\"{x:1382,y:556,t:1527009225781};\\\", \\\"{x:1382,y:558,t:1527009225789};\\\", \\\"{x:1389,y:565,t:1527009225805};\\\", \\\"{x:1390,y:569,t:1527009225821};\\\", \\\"{x:1390,y:572,t:1527009225838};\\\", \\\"{x:1390,y:573,t:1527009225855};\\\", \\\"{x:1390,y:576,t:1527009225871};\\\", \\\"{x:1387,y:582,t:1527009225888};\\\", \\\"{x:1380,y:589,t:1527009225905};\\\", \\\"{x:1371,y:599,t:1527009225922};\\\", \\\"{x:1364,y:611,t:1527009225938};\\\", \\\"{x:1348,y:628,t:1527009225955};\\\", \\\"{x:1331,y:655,t:1527009225971};\\\", \\\"{x:1310,y:684,t:1527009225987};\\\", \\\"{x:1273,y:739,t:1527009226005};\\\", \\\"{x:1260,y:768,t:1527009226020};\\\", \\\"{x:1249,y:799,t:1527009226037};\\\", \\\"{x:1238,y:833,t:1527009226054};\\\", \\\"{x:1229,y:866,t:1527009226072};\\\", \\\"{x:1222,y:891,t:1527009226088};\\\", \\\"{x:1219,y:905,t:1527009226104};\\\", \\\"{x:1219,y:907,t:1527009226120};\\\", \\\"{x:1219,y:908,t:1527009226137};\\\", \\\"{x:1219,y:906,t:1527009227341};\\\", \\\"{x:1219,y:904,t:1527009227352};\\\", \\\"{x:1220,y:901,t:1527009227369};\\\", \\\"{x:1222,y:899,t:1527009227385};\\\", \\\"{x:1226,y:895,t:1527009227402};\\\", \\\"{x:1228,y:893,t:1527009227418};\\\", \\\"{x:1230,y:890,t:1527009227436};\\\", \\\"{x:1231,y:889,t:1527009227451};\\\", \\\"{x:1232,y:887,t:1527009227468};\\\", \\\"{x:1233,y:886,t:1527009227509};\\\", \\\"{x:1234,y:885,t:1527009227533};\\\", \\\"{x:1235,y:884,t:1527009227549};\\\", \\\"{x:1237,y:884,t:1527009227557};\\\", \\\"{x:1237,y:883,t:1527009227573};\\\", \\\"{x:1238,y:883,t:1527009227584};\\\", \\\"{x:1239,y:881,t:1527009227601};\\\", \\\"{x:1240,y:880,t:1527009227618};\\\", \\\"{x:1243,y:878,t:1527009227634};\\\", \\\"{x:1244,y:877,t:1527009227651};\\\", \\\"{x:1249,y:873,t:1527009227668};\\\", \\\"{x:1255,y:870,t:1527009227684};\\\", \\\"{x:1261,y:868,t:1527009227701};\\\", \\\"{x:1278,y:861,t:1527009227718};\\\", \\\"{x:1303,y:854,t:1527009227735};\\\", \\\"{x:1320,y:852,t:1527009227752};\\\", \\\"{x:1329,y:852,t:1527009227767};\\\", \\\"{x:1330,y:852,t:1527009227785};\\\", \\\"{x:1330,y:853,t:1527009227957};\\\", \\\"{x:1330,y:854,t:1527009227974};\\\", \\\"{x:1329,y:856,t:1527009227985};\\\", \\\"{x:1329,y:857,t:1527009228001};\\\", \\\"{x:1327,y:859,t:1527009228018};\\\", \\\"{x:1327,y:860,t:1527009228035};\\\", \\\"{x:1326,y:861,t:1527009228051};\\\", \\\"{x:1326,y:862,t:1527009228067};\\\", \\\"{x:1324,y:864,t:1527009228084};\\\", \\\"{x:1323,y:865,t:1527009228101};\\\", \\\"{x:1322,y:866,t:1527009228118};\\\", \\\"{x:1321,y:866,t:1527009228174};\\\", \\\"{x:1320,y:866,t:1527009228197};\\\", \\\"{x:1319,y:866,t:1527009228253};\\\", \\\"{x:1318,y:866,t:1527009228269};\\\", \\\"{x:1317,y:867,t:1527009228284};\\\", \\\"{x:1316,y:868,t:1527009228300};\\\", \\\"{x:1314,y:868,t:1527009228316};\\\", \\\"{x:1312,y:868,t:1527009228334};\\\", \\\"{x:1310,y:868,t:1527009228351};\\\", \\\"{x:1307,y:868,t:1527009228366};\\\", \\\"{x:1306,y:868,t:1527009228383};\\\", \\\"{x:1305,y:868,t:1527009228401};\\\", \\\"{x:1302,y:868,t:1527009228416};\\\", \\\"{x:1301,y:868,t:1527009228434};\\\", \\\"{x:1298,y:868,t:1527009228452};\\\", \\\"{x:1296,y:868,t:1527009228678};\\\", \\\"{x:1296,y:869,t:1527009228685};\\\", \\\"{x:1295,y:869,t:1527009228700};\\\", \\\"{x:1293,y:871,t:1527009228717};\\\", \\\"{x:1293,y:872,t:1527009228733};\\\", \\\"{x:1292,y:874,t:1527009228750};\\\", \\\"{x:1290,y:875,t:1527009228767};\\\", \\\"{x:1290,y:876,t:1527009228783};\\\", \\\"{x:1288,y:879,t:1527009228800};\\\", \\\"{x:1286,y:882,t:1527009228816};\\\", \\\"{x:1283,y:885,t:1527009228833};\\\", \\\"{x:1281,y:886,t:1527009228850};\\\", \\\"{x:1277,y:888,t:1527009228866};\\\", \\\"{x:1272,y:891,t:1527009228883};\\\", \\\"{x:1267,y:893,t:1527009228900};\\\", \\\"{x:1259,y:896,t:1527009228916};\\\", \\\"{x:1247,y:900,t:1527009228934};\\\", \\\"{x:1240,y:902,t:1527009228950};\\\", \\\"{x:1233,y:905,t:1527009228966};\\\", \\\"{x:1228,y:907,t:1527009228983};\\\", \\\"{x:1224,y:909,t:1527009228999};\\\", \\\"{x:1221,y:910,t:1527009229016};\\\", \\\"{x:1217,y:912,t:1527009229033};\\\", \\\"{x:1216,y:912,t:1527009229049};\\\", \\\"{x:1215,y:913,t:1527009229066};\\\", \\\"{x:1213,y:913,t:1527009229083};\\\", \\\"{x:1212,y:913,t:1527009229101};\\\", \\\"{x:1209,y:913,t:1527009230829};\\\", \\\"{x:1191,y:913,t:1527009230846};\\\", \\\"{x:1162,y:909,t:1527009230863};\\\", \\\"{x:1097,y:884,t:1527009230879};\\\", \\\"{x:1034,y:860,t:1527009230897};\\\", \\\"{x:979,y:835,t:1527009230912};\\\", \\\"{x:933,y:818,t:1527009230929};\\\", \\\"{x:894,y:808,t:1527009230945};\\\", \\\"{x:866,y:800,t:1527009230962};\\\", \\\"{x:844,y:799,t:1527009230979};\\\", \\\"{x:826,y:796,t:1527009230996};\\\", \\\"{x:814,y:794,t:1527009231012};\\\", \\\"{x:806,y:793,t:1527009231029};\\\", \\\"{x:798,y:789,t:1527009231045};\\\", \\\"{x:795,y:788,t:1527009231062};\\\", \\\"{x:787,y:784,t:1527009231079};\\\", \\\"{x:776,y:779,t:1527009231097};\\\", \\\"{x:764,y:774,t:1527009231112};\\\", \\\"{x:756,y:770,t:1527009231129};\\\", \\\"{x:744,y:767,t:1527009231144};\\\", \\\"{x:728,y:762,t:1527009231162};\\\", \\\"{x:709,y:754,t:1527009231179};\\\", \\\"{x:692,y:743,t:1527009231196};\\\", \\\"{x:657,y:724,t:1527009231212};\\\", \\\"{x:579,y:678,t:1527009231229};\\\", \\\"{x:524,y:646,t:1527009231246};\\\", \\\"{x:487,y:619,t:1527009231263};\\\", \\\"{x:455,y:597,t:1527009231279};\\\", \\\"{x:437,y:581,t:1527009231295};\\\", \\\"{x:431,y:575,t:1527009231312};\\\", \\\"{x:430,y:571,t:1527009231328};\\\", \\\"{x:430,y:570,t:1527009231345};\\\", \\\"{x:430,y:569,t:1527009231364};\\\", \\\"{x:430,y:567,t:1527009231378};\\\", \\\"{x:430,y:565,t:1527009231395};\\\", \\\"{x:430,y:564,t:1527009231412};\\\", \\\"{x:433,y:561,t:1527009231429};\\\", \\\"{x:438,y:558,t:1527009231445};\\\", \\\"{x:449,y:554,t:1527009231462};\\\", \\\"{x:467,y:549,t:1527009231478};\\\", \\\"{x:493,y:543,t:1527009231496};\\\", \\\"{x:521,y:535,t:1527009231512};\\\", \\\"{x:565,y:523,t:1527009231529};\\\", \\\"{x:597,y:520,t:1527009231545};\\\", \\\"{x:612,y:516,t:1527009231562};\\\", \\\"{x:619,y:514,t:1527009231578};\\\", \\\"{x:623,y:512,t:1527009231595};\\\", \\\"{x:625,y:510,t:1527009231613};\\\", \\\"{x:625,y:509,t:1527009231629};\\\", \\\"{x:624,y:508,t:1527009231725};\\\", \\\"{x:622,y:508,t:1527009231733};\\\", \\\"{x:621,y:507,t:1527009231746};\\\", \\\"{x:618,y:507,t:1527009231763};\\\", \\\"{x:611,y:506,t:1527009231779};\\\", \\\"{x:607,y:505,t:1527009231795};\\\", \\\"{x:605,y:505,t:1527009231812};\\\", \\\"{x:604,y:505,t:1527009231868};\\\", \\\"{x:603,y:505,t:1527009231884};\\\", \\\"{x:602,y:505,t:1527009231900};\\\", \\\"{x:602,y:508,t:1527009232124};\\\", \\\"{x:602,y:510,t:1527009232132};\\\", \\\"{x:601,y:513,t:1527009232146};\\\", \\\"{x:598,y:522,t:1527009232164};\\\", \\\"{x:594,y:538,t:1527009232179};\\\", \\\"{x:587,y:561,t:1527009232196};\\\", \\\"{x:577,y:596,t:1527009232212};\\\", \\\"{x:570,y:625,t:1527009232229};\\\", \\\"{x:562,y:651,t:1527009232246};\\\", \\\"{x:558,y:672,t:1527009232263};\\\", \\\"{x:554,y:690,t:1527009232279};\\\", \\\"{x:551,y:707,t:1527009232297};\\\", \\\"{x:550,y:721,t:1527009232313};\\\", \\\"{x:548,y:731,t:1527009232328};\\\", \\\"{x:545,y:741,t:1527009232346};\\\", \\\"{x:539,y:756,t:1527009232363};\\\", \\\"{x:534,y:767,t:1527009232379};\\\", \\\"{x:530,y:776,t:1527009232396};\\\", \\\"{x:529,y:782,t:1527009232412};\\\", \\\"{x:528,y:782,t:1527009232436};\\\", \\\"{x:528,y:783,t:1527009232469};\\\", \\\"{x:527,y:784,t:1527009232566};\\\", \\\"{x:526,y:783,t:1527009232597};\\\", \\\"{x:526,y:777,t:1527009232613};\\\", \\\"{x:526,y:771,t:1527009232630};\\\", \\\"{x:526,y:767,t:1527009232647};\\\", \\\"{x:526,y:764,t:1527009232663};\\\", \\\"{x:526,y:760,t:1527009232680};\\\", \\\"{x:526,y:758,t:1527009232697};\\\", \\\"{x:525,y:757,t:1527009232717};\\\", \\\"{x:525,y:756,t:1527009232733};\\\", \\\"{x:524,y:754,t:1527009232758};\\\", \\\"{x:523,y:753,t:1527009232765};\\\", \\\"{x:523,y:751,t:1527009232779};\\\", \\\"{x:521,y:744,t:1527009232797};\\\", \\\"{x:520,y:743,t:1527009232813};\\\", \\\"{x:520,y:741,t:1527009232926};\\\", \\\"{x:520,y:740,t:1527009233677};\\\", \\\"{x:520,y:739,t:1527009233684};\\\", \\\"{x:520,y:738,t:1527009233714};\\\", \\\"{x:520,y:738,t:1527009233812};\\\" ] }, { \\\"rt\\\": 5541, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 14, \\\"time_elapsed\\\": 414981, \\\"internal_node_id\\\": \\\"0.0-6.0-4.0\\\", \\\"subject\\\": \\\"38NFJ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"echo\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"ends\\\", \\\"q\\\": 10, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:521,y:735,t:1527009235373};\\\", \\\"{x:524,y:729,t:1527009235382};\\\", \\\"{x:543,y:682,t:1527009235455};\\\", \\\"{x:545,y:677,t:1527009235465};\\\", \\\"{x:548,y:669,t:1527009235482};\\\", \\\"{x:549,y:657,t:1527009235498};\\\", \\\"{x:554,y:637,t:1527009235515};\\\", \\\"{x:562,y:612,t:1527009235532};\\\", \\\"{x:568,y:594,t:1527009235548};\\\", \\\"{x:576,y:575,t:1527009235565};\\\", \\\"{x:580,y:564,t:1527009235581};\\\", \\\"{x:580,y:560,t:1527009235599};\\\", \\\"{x:581,y:558,t:1527009235614};\\\", \\\"{x:581,y:555,t:1527009235632};\\\", \\\"{x:581,y:553,t:1527009235649};\\\", \\\"{x:581,y:552,t:1527009235664};\\\", \\\"{x:581,y:551,t:1527009235682};\\\", \\\"{x:582,y:551,t:1527009235789};\\\", \\\"{x:585,y:550,t:1527009236644};\\\", \\\"{x:592,y:550,t:1527009236652};\\\", \\\"{x:606,y:549,t:1527009236666};\\\", \\\"{x:645,y:549,t:1527009236683};\\\", \\\"{x:703,y:549,t:1527009236700};\\\", \\\"{x:765,y:549,t:1527009236717};\\\", \\\"{x:881,y:559,t:1527009236733};\\\", \\\"{x:949,y:571,t:1527009236750};\\\", \\\"{x:1008,y:579,t:1527009236766};\\\", \\\"{x:1057,y:584,t:1527009236783};\\\", \\\"{x:1092,y:589,t:1527009236799};\\\", \\\"{x:1118,y:594,t:1527009236816};\\\", \\\"{x:1134,y:596,t:1527009236833};\\\", \\\"{x:1144,y:600,t:1527009236850};\\\", \\\"{x:1151,y:602,t:1527009236866};\\\", \\\"{x:1153,y:603,t:1527009236883};\\\", \\\"{x:1155,y:604,t:1527009236901};\\\", \\\"{x:1156,y:605,t:1527009236917};\\\", \\\"{x:1160,y:608,t:1527009236933};\\\", \\\"{x:1169,y:615,t:1527009236950};\\\", \\\"{x:1177,y:621,t:1527009236966};\\\", \\\"{x:1192,y:631,t:1527009236983};\\\", \\\"{x:1211,y:641,t:1527009237000};\\\", \\\"{x:1231,y:649,t:1527009237016};\\\", \\\"{x:1253,y:659,t:1527009237033};\\\", \\\"{x:1282,y:671,t:1527009237050};\\\", \\\"{x:1313,y:683,t:1527009237065};\\\", \\\"{x:1356,y:695,t:1527009237082};\\\", \\\"{x:1397,y:705,t:1527009237100};\\\", \\\"{x:1434,y:716,t:1527009237116};\\\", \\\"{x:1486,y:724,t:1527009237133};\\\", \\\"{x:1508,y:726,t:1527009237150};\\\", \\\"{x:1524,y:730,t:1527009237166};\\\", \\\"{x:1531,y:734,t:1527009237183};\\\", \\\"{x:1532,y:734,t:1527009237261};\\\", \\\"{x:1532,y:736,t:1527009237269};\\\", \\\"{x:1532,y:740,t:1527009237283};\\\", \\\"{x:1530,y:747,t:1527009237300};\\\", \\\"{x:1524,y:762,t:1527009237316};\\\", \\\"{x:1515,y:782,t:1527009237333};\\\", \\\"{x:1512,y:794,t:1527009237350};\\\", \\\"{x:1509,y:805,t:1527009237366};\\\", \\\"{x:1507,y:812,t:1527009237383};\\\", \\\"{x:1504,y:819,t:1527009237400};\\\", \\\"{x:1500,y:833,t:1527009237416};\\\", \\\"{x:1498,y:846,t:1527009237433};\\\", \\\"{x:1495,y:856,t:1527009237450};\\\", \\\"{x:1494,y:862,t:1527009237467};\\\", \\\"{x:1493,y:868,t:1527009237483};\\\", \\\"{x:1491,y:874,t:1527009237501};\\\", \\\"{x:1491,y:877,t:1527009237516};\\\", \\\"{x:1491,y:882,t:1527009237533};\\\", \\\"{x:1491,y:883,t:1527009237550};\\\", \\\"{x:1491,y:885,t:1527009237566};\\\", \\\"{x:1490,y:887,t:1527009237584};\\\", \\\"{x:1488,y:891,t:1527009237601};\\\", \\\"{x:1487,y:894,t:1527009237616};\\\", \\\"{x:1483,y:899,t:1527009237633};\\\", \\\"{x:1482,y:901,t:1527009237650};\\\", \\\"{x:1480,y:905,t:1527009237666};\\\", \\\"{x:1476,y:908,t:1527009237684};\\\", \\\"{x:1469,y:913,t:1527009237700};\\\", \\\"{x:1462,y:918,t:1527009237716};\\\", \\\"{x:1454,y:923,t:1527009237733};\\\", \\\"{x:1451,y:925,t:1527009237750};\\\", \\\"{x:1451,y:926,t:1527009237767};\\\", \\\"{x:1450,y:926,t:1527009237784};\\\", \\\"{x:1450,y:927,t:1527009237909};\\\", \\\"{x:1450,y:928,t:1527009237917};\\\", \\\"{x:1450,y:929,t:1527009237941};\\\", \\\"{x:1450,y:930,t:1527009237965};\\\", \\\"{x:1451,y:931,t:1527009237984};\\\", \\\"{x:1452,y:931,t:1527009238001};\\\", \\\"{x:1454,y:932,t:1527009238016};\\\", \\\"{x:1456,y:932,t:1527009238033};\\\", \\\"{x:1457,y:932,t:1527009238050};\\\", \\\"{x:1459,y:934,t:1527009238067};\\\", \\\"{x:1460,y:934,t:1527009238083};\\\", \\\"{x:1460,y:935,t:1527009238149};\\\", \\\"{x:1461,y:935,t:1527009238181};\\\", \\\"{x:1463,y:936,t:1527009238221};\\\", \\\"{x:1464,y:936,t:1527009238245};\\\", \\\"{x:1465,y:937,t:1527009238253};\\\", \\\"{x:1466,y:937,t:1527009238269};\\\", \\\"{x:1467,y:937,t:1527009238293};\\\", \\\"{x:1463,y:937,t:1527009238414};\\\", \\\"{x:1445,y:937,t:1527009238421};\\\", \\\"{x:1403,y:937,t:1527009238434};\\\", \\\"{x:1264,y:915,t:1527009238450};\\\", \\\"{x:1074,y:864,t:1527009238466};\\\", \\\"{x:867,y:806,t:1527009238483};\\\", \\\"{x:693,y:752,t:1527009238500};\\\", \\\"{x:578,y:710,t:1527009238516};\\\", \\\"{x:519,y:678,t:1527009238533};\\\", \\\"{x:516,y:675,t:1527009238550};\\\", \\\"{x:521,y:670,t:1527009238588};\\\", \\\"{x:529,y:665,t:1527009238600};\\\", \\\"{x:543,y:658,t:1527009238615};\\\", \\\"{x:549,y:649,t:1527009238633};\\\", \\\"{x:550,y:643,t:1527009238650};\\\", \\\"{x:550,y:639,t:1527009238666};\\\", \\\"{x:550,y:636,t:1527009238682};\\\", \\\"{x:550,y:634,t:1527009238700};\\\", \\\"{x:550,y:633,t:1527009238716};\\\", \\\"{x:546,y:622,t:1527009238733};\\\", \\\"{x:536,y:609,t:1527009238750};\\\", \\\"{x:518,y:594,t:1527009238766};\\\", \\\"{x:500,y:585,t:1527009238782};\\\", \\\"{x:487,y:578,t:1527009238799};\\\", \\\"{x:482,y:576,t:1527009238818};\\\", \\\"{x:482,y:574,t:1527009238834};\\\", \\\"{x:487,y:568,t:1527009238851};\\\", \\\"{x:501,y:556,t:1527009238868};\\\", \\\"{x:524,y:538,t:1527009238884};\\\", \\\"{x:544,y:527,t:1527009238901};\\\", \\\"{x:560,y:522,t:1527009238918};\\\", \\\"{x:565,y:521,t:1527009238934};\\\", \\\"{x:568,y:520,t:1527009238951};\\\", \\\"{x:573,y:517,t:1527009238969};\\\", \\\"{x:575,y:514,t:1527009238984};\\\", \\\"{x:577,y:512,t:1527009239001};\\\", \\\"{x:578,y:511,t:1527009239017};\\\", \\\"{x:579,y:511,t:1527009239034};\\\", \\\"{x:580,y:511,t:1527009239076};\\\", \\\"{x:582,y:510,t:1527009239149};\\\", \\\"{x:583,y:510,t:1527009239164};\\\", \\\"{x:585,y:510,t:1527009239172};\\\", \\\"{x:586,y:508,t:1527009239185};\\\", \\\"{x:589,y:508,t:1527009239201};\\\", \\\"{x:592,y:508,t:1527009239217};\\\", \\\"{x:595,y:506,t:1527009239235};\\\", \\\"{x:602,y:503,t:1527009239252};\\\", \\\"{x:611,y:500,t:1527009239268};\\\", \\\"{x:617,y:498,t:1527009239284};\\\", \\\"{x:619,y:497,t:1527009239301};\\\", \\\"{x:618,y:497,t:1527009239732};\\\", \\\"{x:616,y:497,t:1527009239740};\\\", \\\"{x:615,y:497,t:1527009239751};\\\", \\\"{x:612,y:499,t:1527009239769};\\\", \\\"{x:609,y:505,t:1527009239784};\\\", \\\"{x:601,y:519,t:1527009239802};\\\", \\\"{x:595,y:532,t:1527009239819};\\\", \\\"{x:588,y:550,t:1527009239834};\\\", \\\"{x:570,y:590,t:1527009239852};\\\", \\\"{x:556,y:623,t:1527009239868};\\\", \\\"{x:547,y:643,t:1527009239885};\\\", \\\"{x:545,y:654,t:1527009239902};\\\", \\\"{x:544,y:664,t:1527009239919};\\\", \\\"{x:538,y:677,t:1527009239934};\\\", \\\"{x:532,y:696,t:1527009239951};\\\", \\\"{x:520,y:721,t:1527009239969};\\\", \\\"{x:508,y:750,t:1527009239984};\\\", \\\"{x:498,y:767,t:1527009240002};\\\", \\\"{x:491,y:778,t:1527009240019};\\\", \\\"{x:487,y:786,t:1527009240035};\\\", \\\"{x:484,y:791,t:1527009240051};\\\", \\\"{x:482,y:793,t:1527009240068};\\\", \\\"{x:482,y:786,t:1527009240205};\\\", \\\"{x:485,y:780,t:1527009240219};\\\", \\\"{x:492,y:761,t:1527009240236};\\\", \\\"{x:496,y:756,t:1527009240252};\\\", \\\"{x:499,y:752,t:1527009240269};\\\", \\\"{x:500,y:752,t:1527009240285};\\\", \\\"{x:501,y:750,t:1527009240317};\\\", \\\"{x:502,y:749,t:1527009240332};\\\", \\\"{x:503,y:747,t:1527009240348};\\\", \\\"{x:503,y:746,t:1527009240356};\\\", \\\"{x:503,y:745,t:1527009240368};\\\", \\\"{x:503,y:744,t:1527009240386};\\\", \\\"{x:504,y:744,t:1527009240403};\\\", \\\"{x:504,y:743,t:1527009241396};\\\", \\\"{x:504,y:742,t:1527009241404};\\\", \\\"{x:504,y:740,t:1527009241420};\\\", \\\"{x:504,y:738,t:1527009241436};\\\", \\\"{x:509,y:728,t:1527009241453};\\\", \\\"{x:514,y:719,t:1527009241470};\\\", \\\"{x:525,y:698,t:1527009241486};\\\", \\\"{x:557,y:650,t:1527009241503};\\\", \\\"{x:602,y:588,t:1527009241520};\\\", \\\"{x:647,y:545,t:1527009241537};\\\", \\\"{x:686,y:521,t:1527009241553};\\\", \\\"{x:732,y:512,t:1527009241582};\\\", \\\"{x:737,y:509,t:1527009241588};\\\", \\\"{x:739,y:509,t:1527009241602};\\\", \\\"{x:740,y:509,t:1527009241620};\\\" ] }, { \\\"rt\\\": 6965, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 15, \\\"time_elapsed\\\": 423178, \\\"internal_node_id\\\": \\\"0.0-6.0-5.0\\\", \\\"subject\\\": \\\"38NFJ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"echo\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 11, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"M\\\", \\\"L\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-7-01 PM-12 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:746,y:509,t:1527009242653};\\\", \\\"{x:760,y:509,t:1527009242661};\\\", \\\"{x:771,y:509,t:1527009242671};\\\", \\\"{x:798,y:507,t:1527009242687};\\\", \\\"{x:828,y:507,t:1527009242705};\\\", \\\"{x:852,y:507,t:1527009242721};\\\", \\\"{x:888,y:507,t:1527009242737};\\\", \\\"{x:912,y:507,t:1527009242754};\\\", \\\"{x:931,y:507,t:1527009242770};\\\", \\\"{x:954,y:507,t:1527009242789};\\\", \\\"{x:971,y:505,t:1527009242804};\\\", \\\"{x:981,y:503,t:1527009242821};\\\", \\\"{x:990,y:502,t:1527009242838};\\\", \\\"{x:994,y:501,t:1527009242854};\\\", \\\"{x:1000,y:501,t:1527009242871};\\\", \\\"{x:1006,y:501,t:1527009242888};\\\", \\\"{x:1020,y:501,t:1527009242904};\\\", \\\"{x:1038,y:501,t:1527009242921};\\\", \\\"{x:1062,y:503,t:1527009242938};\\\", \\\"{x:1093,y:512,t:1527009242955};\\\", \\\"{x:1124,y:515,t:1527009242971};\\\", \\\"{x:1155,y:519,t:1527009242988};\\\", \\\"{x:1214,y:531,t:1527009243004};\\\", \\\"{x:1257,y:540,t:1527009243021};\\\", \\\"{x:1304,y:550,t:1527009243038};\\\", \\\"{x:1334,y:556,t:1527009243056};\\\", \\\"{x:1387,y:564,t:1527009243071};\\\", \\\"{x:1421,y:575,t:1527009243088};\\\", \\\"{x:1445,y:586,t:1527009243106};\\\", \\\"{x:1456,y:593,t:1527009243121};\\\", \\\"{x:1465,y:601,t:1527009243138};\\\", \\\"{x:1471,y:610,t:1527009243155};\\\", \\\"{x:1478,y:622,t:1527009243171};\\\", \\\"{x:1481,y:631,t:1527009243188};\\\", \\\"{x:1483,y:651,t:1527009243204};\\\", \\\"{x:1483,y:668,t:1527009243222};\\\", \\\"{x:1483,y:689,t:1527009243238};\\\", \\\"{x:1483,y:715,t:1527009243255};\\\", \\\"{x:1481,y:744,t:1527009243273};\\\", \\\"{x:1468,y:786,t:1527009243288};\\\", \\\"{x:1455,y:831,t:1527009243306};\\\", \\\"{x:1437,y:880,t:1527009243322};\\\", \\\"{x:1428,y:913,t:1527009243339};\\\", \\\"{x:1419,y:937,t:1527009243356};\\\", \\\"{x:1414,y:965,t:1527009243373};\\\", \\\"{x:1414,y:971,t:1527009243388};\\\", \\\"{x:1415,y:984,t:1527009243406};\\\", \\\"{x:1421,y:989,t:1527009243423};\\\", \\\"{x:1427,y:993,t:1527009243439};\\\", \\\"{x:1436,y:996,t:1527009243456};\\\", \\\"{x:1446,y:1001,t:1527009243472};\\\", \\\"{x:1455,y:1007,t:1527009243490};\\\", \\\"{x:1459,y:1008,t:1527009243505};\\\", \\\"{x:1458,y:1008,t:1527009243644};\\\", \\\"{x:1454,y:1008,t:1527009243656};\\\", \\\"{x:1442,y:1008,t:1527009243672};\\\", \\\"{x:1429,y:1008,t:1527009243689};\\\", \\\"{x:1415,y:1008,t:1527009243706};\\\", \\\"{x:1403,y:1008,t:1527009243722};\\\", \\\"{x:1388,y:1008,t:1527009243739};\\\", \\\"{x:1373,y:1004,t:1527009243756};\\\", \\\"{x:1370,y:1003,t:1527009243773};\\\", \\\"{x:1367,y:1002,t:1527009243789};\\\", \\\"{x:1366,y:1002,t:1527009243806};\\\", \\\"{x:1366,y:1001,t:1527009243822};\\\", \\\"{x:1363,y:1000,t:1527009243840};\\\", \\\"{x:1359,y:997,t:1527009243856};\\\", \\\"{x:1355,y:995,t:1527009243872};\\\", \\\"{x:1352,y:993,t:1527009243889};\\\", \\\"{x:1350,y:990,t:1527009243906};\\\", \\\"{x:1348,y:987,t:1527009243923};\\\", \\\"{x:1346,y:984,t:1527009243939};\\\", \\\"{x:1344,y:981,t:1527009243956};\\\", \\\"{x:1343,y:980,t:1527009243974};\\\", \\\"{x:1343,y:979,t:1527009244164};\\\", \\\"{x:1343,y:977,t:1527009244187};\\\", \\\"{x:1345,y:976,t:1527009244196};\\\", \\\"{x:1346,y:974,t:1527009244206};\\\", \\\"{x:1348,y:970,t:1527009244224};\\\", \\\"{x:1352,y:965,t:1527009244266};\\\", \\\"{x:1352,y:964,t:1527009244273};\\\", \\\"{x:1353,y:963,t:1527009244292};\\\", \\\"{x:1354,y:962,t:1527009244332};\\\", \\\"{x:1354,y:961,t:1527009244340};\\\", \\\"{x:1355,y:959,t:1527009244356};\\\", \\\"{x:1356,y:958,t:1527009244373};\\\", \\\"{x:1356,y:957,t:1527009244390};\\\", \\\"{x:1355,y:957,t:1527009245801};\\\", \\\"{x:1346,y:957,t:1527009245813};\\\", \\\"{x:1313,y:952,t:1527009245829};\\\", \\\"{x:1222,y:940,t:1527009245846};\\\", \\\"{x:1106,y:911,t:1527009245863};\\\", \\\"{x:985,y:878,t:1527009245879};\\\", \\\"{x:842,y:826,t:1527009245897};\\\", \\\"{x:770,y:783,t:1527009245912};\\\", \\\"{x:707,y:741,t:1527009245929};\\\", \\\"{x:678,y:714,t:1527009245946};\\\", \\\"{x:672,y:705,t:1527009245963};\\\", \\\"{x:671,y:699,t:1527009245978};\\\", \\\"{x:671,y:696,t:1527009245996};\\\", \\\"{x:671,y:695,t:1527009246013};\\\", \\\"{x:669,y:691,t:1527009246029};\\\", \\\"{x:665,y:685,t:1527009246046};\\\", \\\"{x:663,y:680,t:1527009246063};\\\", \\\"{x:659,y:674,t:1527009246080};\\\", \\\"{x:652,y:666,t:1527009246096};\\\", \\\"{x:639,y:656,t:1527009246113};\\\", \\\"{x:619,y:644,t:1527009246130};\\\", \\\"{x:579,y:627,t:1527009246148};\\\", \\\"{x:517,y:606,t:1527009246162};\\\", \\\"{x:453,y:589,t:1527009246180};\\\", \\\"{x:417,y:580,t:1527009246191};\\\", \\\"{x:398,y:574,t:1527009246208};\\\", \\\"{x:388,y:570,t:1527009246226};\\\", \\\"{x:388,y:569,t:1527009246279};\\\", \\\"{x:388,y:568,t:1527009246291};\\\", \\\"{x:388,y:565,t:1527009246308};\\\", \\\"{x:388,y:562,t:1527009246326};\\\", \\\"{x:390,y:559,t:1527009246343};\\\", \\\"{x:391,y:558,t:1527009246361};\\\", \\\"{x:392,y:557,t:1527009246377};\\\", \\\"{x:393,y:556,t:1527009246399};\\\", \\\"{x:393,y:555,t:1527009246411};\\\", \\\"{x:394,y:554,t:1527009246427};\\\", \\\"{x:395,y:553,t:1527009246445};\\\", \\\"{x:396,y:551,t:1527009246460};\\\", \\\"{x:396,y:549,t:1527009246553};\\\", \\\"{x:396,y:548,t:1527009246562};\\\", \\\"{x:394,y:548,t:1527009246577};\\\", \\\"{x:392,y:547,t:1527009246594};\\\", \\\"{x:387,y:545,t:1527009246610};\\\", \\\"{x:383,y:544,t:1527009246627};\\\", \\\"{x:381,y:543,t:1527009246647};\\\", \\\"{x:383,y:543,t:1527009246944};\\\", \\\"{x:403,y:540,t:1527009246960};\\\", \\\"{x:433,y:540,t:1527009246978};\\\", \\\"{x:474,y:540,t:1527009246995};\\\", \\\"{x:522,y:540,t:1527009247011};\\\", \\\"{x:558,y:540,t:1527009247027};\\\", \\\"{x:580,y:540,t:1527009247044};\\\", \\\"{x:595,y:540,t:1527009247062};\\\", \\\"{x:606,y:540,t:1527009247078};\\\", \\\"{x:619,y:540,t:1527009247095};\\\", \\\"{x:627,y:540,t:1527009247110};\\\", \\\"{x:634,y:539,t:1527009247127};\\\", \\\"{x:636,y:537,t:1527009247145};\\\", \\\"{x:638,y:537,t:1527009247162};\\\", \\\"{x:639,y:537,t:1527009247183};\\\", \\\"{x:640,y:537,t:1527009247194};\\\", \\\"{x:642,y:539,t:1527009247212};\\\", \\\"{x:642,y:544,t:1527009247228};\\\", \\\"{x:637,y:554,t:1527009247244};\\\", \\\"{x:620,y:567,t:1527009247263};\\\", \\\"{x:579,y:586,t:1527009247277};\\\", \\\"{x:512,y:603,t:1527009247295};\\\", \\\"{x:412,y:620,t:1527009247312};\\\", \\\"{x:383,y:627,t:1527009247328};\\\", \\\"{x:366,y:629,t:1527009247345};\\\", \\\"{x:363,y:629,t:1527009247362};\\\", \\\"{x:362,y:630,t:1527009247383};\\\", \\\"{x:362,y:631,t:1527009247407};\\\", \\\"{x:360,y:632,t:1527009247416};\\\", \\\"{x:358,y:633,t:1527009247428};\\\", \\\"{x:349,y:636,t:1527009247444};\\\", \\\"{x:340,y:641,t:1527009247462};\\\", \\\"{x:335,y:642,t:1527009247478};\\\", \\\"{x:335,y:643,t:1527009247494};\\\", \\\"{x:334,y:643,t:1527009247543};\\\", \\\"{x:336,y:643,t:1527009247576};\\\", \\\"{x:337,y:643,t:1527009247584};\\\", \\\"{x:341,y:642,t:1527009247595};\\\", \\\"{x:343,y:641,t:1527009247611};\\\", \\\"{x:347,y:639,t:1527009247628};\\\", \\\"{x:351,y:638,t:1527009247645};\\\", \\\"{x:353,y:637,t:1527009247661};\\\", \\\"{x:354,y:636,t:1527009247678};\\\", \\\"{x:358,y:634,t:1527009247695};\\\", \\\"{x:361,y:631,t:1527009247713};\\\", \\\"{x:367,y:626,t:1527009247729};\\\", \\\"{x:373,y:620,t:1527009247744};\\\", \\\"{x:377,y:618,t:1527009247761};\\\", \\\"{x:378,y:617,t:1527009247778};\\\", \\\"{x:379,y:617,t:1527009247816};\\\", \\\"{x:379,y:616,t:1527009247831};\\\", \\\"{x:380,y:612,t:1527009247848};\\\", \\\"{x:380,y:611,t:1527009247864};\\\", \\\"{x:381,y:611,t:1527009247878};\\\", \\\"{x:385,y:611,t:1527009248103};\\\", \\\"{x:386,y:616,t:1527009248111};\\\", \\\"{x:395,y:629,t:1527009248128};\\\", \\\"{x:407,y:647,t:1527009248146};\\\", \\\"{x:417,y:662,t:1527009248161};\\\", \\\"{x:423,y:674,t:1527009248179};\\\", \\\"{x:430,y:686,t:1527009248195};\\\", \\\"{x:432,y:692,t:1527009248211};\\\", \\\"{x:433,y:693,t:1527009248228};\\\", \\\"{x:435,y:695,t:1527009248246};\\\", \\\"{x:436,y:695,t:1527009248261};\\\", \\\"{x:437,y:696,t:1527009248278};\\\", \\\"{x:438,y:696,t:1527009248296};\\\", \\\"{x:441,y:697,t:1527009248312};\\\", \\\"{x:443,y:698,t:1527009248329};\\\", \\\"{x:447,y:702,t:1527009248345};\\\", \\\"{x:453,y:708,t:1527009248362};\\\", \\\"{x:460,y:717,t:1527009248379};\\\", \\\"{x:466,y:723,t:1527009248397};\\\", \\\"{x:472,y:728,t:1527009248411};\\\", \\\"{x:474,y:729,t:1527009248428};\\\", \\\"{x:475,y:729,t:1527009248463};\\\", \\\"{x:476,y:730,t:1527009248479};\\\", \\\"{x:477,y:731,t:1527009248495};\\\", \\\"{x:477,y:734,t:1527009248513};\\\", \\\"{x:478,y:736,t:1527009248528};\\\", \\\"{x:479,y:736,t:1527009248546};\\\", \\\"{x:479,y:738,t:1527009248855};\\\", \\\"{x:476,y:736,t:1527009249813};\\\" ] }, { \\\"rt\\\": 8350, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 16, \\\"time_elapsed\\\": 432766, \\\"internal_node_id\\\": \\\"0.0-6.0-6.0\\\", \\\"subject\\\": \\\"38NFJ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"echo\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 12, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-E \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:476,y:729,t:1527009249987};\\\", \\\"{x:476,y:727,t:1527009249996};\\\", \\\"{x:486,y:718,t:1527009250014};\\\", \\\"{x:504,y:704,t:1527009250029};\\\", \\\"{x:532,y:682,t:1527009250046};\\\", \\\"{x:607,y:643,t:1527009250063};\\\", \\\"{x:723,y:600,t:1527009250087};\\\", \\\"{x:764,y:591,t:1527009250096};\\\", \\\"{x:845,y:564,t:1527009250113};\\\", \\\"{x:923,y:540,t:1527009250131};\\\", \\\"{x:978,y:527,t:1527009250147};\\\", \\\"{x:1028,y:519,t:1527009250164};\\\", \\\"{x:1051,y:515,t:1527009250180};\\\", \\\"{x:1060,y:511,t:1527009250197};\\\", \\\"{x:1064,y:510,t:1527009250214};\\\", \\\"{x:1061,y:510,t:1527009250287};\\\", \\\"{x:1056,y:510,t:1527009250297};\\\", \\\"{x:1038,y:513,t:1527009250314};\\\", \\\"{x:1014,y:521,t:1527009250331};\\\", \\\"{x:993,y:529,t:1527009250348};\\\", \\\"{x:978,y:532,t:1527009250364};\\\", \\\"{x:963,y:537,t:1527009250380};\\\", \\\"{x:954,y:540,t:1527009250398};\\\", \\\"{x:941,y:542,t:1527009250416};\\\", \\\"{x:936,y:544,t:1527009250430};\\\", \\\"{x:933,y:545,t:1527009250447};\\\", \\\"{x:932,y:545,t:1527009250462};\\\", \\\"{x:925,y:545,t:1527009250615};\\\", \\\"{x:923,y:545,t:1527009250629};\\\", \\\"{x:921,y:545,t:1527009250646};\\\", \\\"{x:918,y:545,t:1527009250662};\\\", \\\"{x:917,y:545,t:1527009250743};\\\", \\\"{x:920,y:540,t:1527009250751};\\\", \\\"{x:928,y:537,t:1527009250763};\\\", \\\"{x:954,y:527,t:1527009250779};\\\", \\\"{x:989,y:516,t:1527009250796};\\\", \\\"{x:1040,y:506,t:1527009250814};\\\", \\\"{x:1076,y:504,t:1527009250830};\\\", \\\"{x:1118,y:500,t:1527009250847};\\\", \\\"{x:1142,y:500,t:1527009250864};\\\", \\\"{x:1167,y:500,t:1527009250880};\\\", \\\"{x:1184,y:500,t:1527009250898};\\\", \\\"{x:1200,y:500,t:1527009250913};\\\", \\\"{x:1216,y:500,t:1527009250930};\\\", \\\"{x:1234,y:500,t:1527009250948};\\\", \\\"{x:1246,y:500,t:1527009250963};\\\", \\\"{x:1254,y:502,t:1527009250981};\\\", \\\"{x:1257,y:503,t:1527009250998};\\\", \\\"{x:1259,y:505,t:1527009251015};\\\", \\\"{x:1262,y:509,t:1527009251031};\\\", \\\"{x:1264,y:518,t:1527009251048};\\\", \\\"{x:1266,y:523,t:1527009251065};\\\", \\\"{x:1267,y:530,t:1527009251081};\\\", \\\"{x:1271,y:537,t:1527009251097};\\\", \\\"{x:1274,y:548,t:1527009251115};\\\", \\\"{x:1277,y:558,t:1527009251131};\\\", \\\"{x:1280,y:568,t:1527009251149};\\\", \\\"{x:1284,y:579,t:1527009251166};\\\", \\\"{x:1290,y:590,t:1527009251180};\\\", \\\"{x:1297,y:599,t:1527009251198};\\\", \\\"{x:1308,y:613,t:1527009251216};\\\", \\\"{x:1311,y:615,t:1527009251231};\\\", \\\"{x:1323,y:625,t:1527009251248};\\\", \\\"{x:1330,y:631,t:1527009251265};\\\", \\\"{x:1338,y:635,t:1527009251281};\\\", \\\"{x:1345,y:641,t:1527009251298};\\\", \\\"{x:1352,y:643,t:1527009251315};\\\", \\\"{x:1355,y:645,t:1527009251332};\\\", \\\"{x:1357,y:646,t:1527009251348};\\\", \\\"{x:1359,y:647,t:1527009251365};\\\", \\\"{x:1361,y:648,t:1527009251382};\\\", \\\"{x:1364,y:647,t:1527009251944};\\\", \\\"{x:1365,y:646,t:1527009251952};\\\", \\\"{x:1368,y:642,t:1527009251965};\\\", \\\"{x:1372,y:637,t:1527009251982};\\\", \\\"{x:1377,y:631,t:1527009251999};\\\", \\\"{x:1381,y:626,t:1527009252016};\\\", \\\"{x:1386,y:620,t:1527009252033};\\\", \\\"{x:1389,y:617,t:1527009252050};\\\", \\\"{x:1392,y:615,t:1527009252066};\\\", \\\"{x:1394,y:613,t:1527009252082};\\\", \\\"{x:1396,y:613,t:1527009252137};\\\", \\\"{x:1397,y:613,t:1527009252149};\\\", \\\"{x:1399,y:613,t:1527009252167};\\\", \\\"{x:1404,y:613,t:1527009252183};\\\", \\\"{x:1405,y:613,t:1527009252199};\\\", \\\"{x:1408,y:613,t:1527009252216};\\\", \\\"{x:1411,y:615,t:1527009252232};\\\", \\\"{x:1412,y:617,t:1527009252249};\\\", \\\"{x:1412,y:622,t:1527009252266};\\\", \\\"{x:1412,y:629,t:1527009252282};\\\", \\\"{x:1412,y:634,t:1527009252299};\\\", \\\"{x:1411,y:642,t:1527009252316};\\\", \\\"{x:1406,y:651,t:1527009252332};\\\", \\\"{x:1400,y:661,t:1527009252349};\\\", \\\"{x:1396,y:668,t:1527009252367};\\\", \\\"{x:1391,y:674,t:1527009252382};\\\", \\\"{x:1387,y:679,t:1527009252400};\\\", \\\"{x:1380,y:685,t:1527009252416};\\\", \\\"{x:1376,y:690,t:1527009252433};\\\", \\\"{x:1373,y:695,t:1527009252449};\\\", \\\"{x:1371,y:697,t:1527009252466};\\\", \\\"{x:1368,y:700,t:1527009252483};\\\", \\\"{x:1365,y:703,t:1527009252499};\\\", \\\"{x:1364,y:708,t:1527009252516};\\\", \\\"{x:1362,y:710,t:1527009252533};\\\", \\\"{x:1361,y:711,t:1527009252549};\\\", \\\"{x:1359,y:712,t:1527009252566};\\\", \\\"{x:1358,y:712,t:1527009252617};\\\", \\\"{x:1357,y:712,t:1527009252632};\\\", \\\"{x:1356,y:712,t:1527009252649};\\\", \\\"{x:1355,y:712,t:1527009252680};\\\", \\\"{x:1354,y:712,t:1527009252689};\\\", \\\"{x:1353,y:712,t:1527009252704};\\\", \\\"{x:1352,y:712,t:1527009252736};\\\", \\\"{x:1352,y:710,t:1527009252847};\\\", \\\"{x:1352,y:709,t:1527009252872};\\\", \\\"{x:1352,y:708,t:1527009252887};\\\", \\\"{x:1352,y:707,t:1527009252936};\\\", \\\"{x:1352,y:706,t:1527009252992};\\\", \\\"{x:1351,y:705,t:1527009253193};\\\", \\\"{x:1351,y:704,t:1527009253200};\\\", \\\"{x:1349,y:704,t:1527009254129};\\\", \\\"{x:1347,y:712,t:1527009254136};\\\", \\\"{x:1344,y:725,t:1527009254151};\\\", \\\"{x:1338,y:754,t:1527009254167};\\\", \\\"{x:1335,y:794,t:1527009254184};\\\", \\\"{x:1333,y:818,t:1527009254200};\\\", \\\"{x:1328,y:839,t:1527009254218};\\\", \\\"{x:1324,y:856,t:1527009254234};\\\", \\\"{x:1319,y:871,t:1527009254251};\\\", \\\"{x:1313,y:883,t:1527009254267};\\\", \\\"{x:1307,y:893,t:1527009254284};\\\", \\\"{x:1302,y:901,t:1527009254301};\\\", \\\"{x:1298,y:906,t:1527009254318};\\\", \\\"{x:1293,y:912,t:1527009254334};\\\", \\\"{x:1290,y:915,t:1527009254352};\\\", \\\"{x:1282,y:920,t:1527009254367};\\\", \\\"{x:1274,y:927,t:1527009254385};\\\", \\\"{x:1267,y:929,t:1527009254401};\\\", \\\"{x:1264,y:931,t:1527009254418};\\\", \\\"{x:1260,y:932,t:1527009254435};\\\", \\\"{x:1255,y:935,t:1527009254451};\\\", \\\"{x:1250,y:937,t:1527009254468};\\\", \\\"{x:1245,y:940,t:1527009254484};\\\", \\\"{x:1239,y:944,t:1527009254501};\\\", \\\"{x:1231,y:950,t:1527009254518};\\\", \\\"{x:1222,y:956,t:1527009254535};\\\", \\\"{x:1217,y:960,t:1527009254551};\\\", \\\"{x:1212,y:965,t:1527009254568};\\\", \\\"{x:1211,y:965,t:1527009254585};\\\", \\\"{x:1211,y:966,t:1527009254616};\\\", \\\"{x:1210,y:966,t:1527009255488};\\\", \\\"{x:1210,y:965,t:1527009255512};\\\", \\\"{x:1210,y:964,t:1527009255536};\\\", \\\"{x:1210,y:963,t:1527009255632};\\\", \\\"{x:1207,y:963,t:1527009256129};\\\", \\\"{x:1197,y:962,t:1527009256136};\\\", \\\"{x:1154,y:943,t:1527009256153};\\\", \\\"{x:1039,y:881,t:1527009256169};\\\", \\\"{x:894,y:798,t:1527009256186};\\\", \\\"{x:754,y:714,t:1527009256202};\\\", \\\"{x:644,y:649,t:1527009256219};\\\", \\\"{x:553,y:592,t:1527009256238};\\\", \\\"{x:511,y:562,t:1527009256252};\\\", \\\"{x:494,y:539,t:1527009256285};\\\", \\\"{x:494,y:536,t:1527009256301};\\\", \\\"{x:494,y:535,t:1527009256318};\\\", \\\"{x:494,y:533,t:1527009256335};\\\", \\\"{x:494,y:532,t:1527009256367};\\\", \\\"{x:494,y:531,t:1527009256375};\\\", \\\"{x:494,y:530,t:1527009256385};\\\", \\\"{x:488,y:530,t:1527009256402};\\\", \\\"{x:480,y:530,t:1527009256419};\\\", \\\"{x:470,y:531,t:1527009256435};\\\", \\\"{x:454,y:540,t:1527009256452};\\\", \\\"{x:443,y:547,t:1527009256468};\\\", \\\"{x:434,y:553,t:1527009256485};\\\", \\\"{x:422,y:560,t:1527009256503};\\\", \\\"{x:418,y:565,t:1527009256519};\\\", \\\"{x:416,y:569,t:1527009256536};\\\", \\\"{x:419,y:572,t:1527009256552};\\\", \\\"{x:430,y:572,t:1527009256568};\\\", \\\"{x:455,y:572,t:1527009256584};\\\", \\\"{x:514,y:560,t:1527009256602};\\\", \\\"{x:617,y:544,t:1527009256619};\\\", \\\"{x:709,y:539,t:1527009256636};\\\", \\\"{x:768,y:539,t:1527009256652};\\\", \\\"{x:818,y:539,t:1527009256669};\\\", \\\"{x:843,y:539,t:1527009256685};\\\", \\\"{x:848,y:539,t:1527009256702};\\\", \\\"{x:850,y:539,t:1527009256719};\\\", \\\"{x:851,y:539,t:1527009256759};\\\", \\\"{x:853,y:539,t:1527009256775};\\\", \\\"{x:854,y:539,t:1527009256786};\\\", \\\"{x:856,y:539,t:1527009256802};\\\", \\\"{x:857,y:539,t:1527009256847};\\\", \\\"{x:857,y:540,t:1527009256855};\\\", \\\"{x:857,y:541,t:1527009256879};\\\", \\\"{x:856,y:541,t:1527009256904};\\\", \\\"{x:854,y:541,t:1527009256927};\\\", \\\"{x:853,y:541,t:1527009256943};\\\", \\\"{x:851,y:541,t:1527009256952};\\\", \\\"{x:850,y:541,t:1527009256969};\\\", \\\"{x:847,y:541,t:1527009256986};\\\", \\\"{x:844,y:541,t:1527009257003};\\\", \\\"{x:840,y:542,t:1527009257019};\\\", \\\"{x:834,y:542,t:1527009257036};\\\", \\\"{x:832,y:542,t:1527009257052};\\\", \\\"{x:830,y:542,t:1527009257069};\\\", \\\"{x:829,y:542,t:1527009257086};\\\", \\\"{x:828,y:542,t:1527009257263};\\\", \\\"{x:826,y:542,t:1527009257271};\\\", \\\"{x:820,y:546,t:1527009257286};\\\", \\\"{x:816,y:550,t:1527009257302};\\\", \\\"{x:810,y:555,t:1527009257319};\\\", \\\"{x:802,y:562,t:1527009257336};\\\", \\\"{x:793,y:570,t:1527009257354};\\\", \\\"{x:788,y:573,t:1527009257369};\\\", \\\"{x:786,y:575,t:1527009257386};\\\", \\\"{x:784,y:576,t:1527009257403};\\\", \\\"{x:781,y:579,t:1527009257420};\\\", \\\"{x:776,y:584,t:1527009257436};\\\", \\\"{x:764,y:593,t:1527009257453};\\\", \\\"{x:747,y:606,t:1527009257471};\\\", \\\"{x:726,y:621,t:1527009257486};\\\", \\\"{x:697,y:636,t:1527009257503};\\\", \\\"{x:644,y:662,t:1527009257518};\\\", \\\"{x:618,y:676,t:1527009257536};\\\", \\\"{x:597,y:684,t:1527009257552};\\\", \\\"{x:579,y:694,t:1527009257569};\\\", \\\"{x:563,y:705,t:1527009257586};\\\", \\\"{x:545,y:716,t:1527009257603};\\\", \\\"{x:529,y:727,t:1527009257619};\\\", \\\"{x:513,y:738,t:1527009257636};\\\", \\\"{x:501,y:744,t:1527009257653};\\\", \\\"{x:488,y:751,t:1527009257670};\\\", \\\"{x:480,y:756,t:1527009257687};\\\", \\\"{x:474,y:760,t:1527009257703};\\\", \\\"{x:474,y:759,t:1527009257824};\\\", \\\"{x:474,y:756,t:1527009257836};\\\", \\\"{x:482,y:745,t:1527009257854};\\\", \\\"{x:485,y:741,t:1527009257870};\\\", \\\"{x:487,y:738,t:1527009257886};\\\", \\\"{x:489,y:734,t:1527009257903};\\\", \\\"{x:489,y:733,t:1527009257919};\\\", \\\"{x:490,y:732,t:1527009257944};\\\", \\\"{x:491,y:731,t:1527009257960};\\\", \\\"{x:492,y:731,t:1527009258016};\\\", \\\"{x:492,y:730,t:1527009258888};\\\", \\\"{x:492,y:729,t:1527009258936};\\\", \\\"{x:492,y:727,t:1527009258943};\\\", \\\"{x:492,y:726,t:1527009258954};\\\", \\\"{x:492,y:723,t:1527009258970};\\\", \\\"{x:492,y:719,t:1527009258987};\\\", \\\"{x:492,y:717,t:1527009259004};\\\", \\\"{x:493,y:713,t:1527009259021};\\\", \\\"{x:496,y:707,t:1527009259037};\\\", \\\"{x:500,y:698,t:1527009259054};\\\", \\\"{x:512,y:678,t:1527009259071};\\\", \\\"{x:517,y:669,t:1527009259087};\\\", \\\"{x:539,y:643,t:1527009259104};\\\", \\\"{x:552,y:626,t:1527009259121};\\\", \\\"{x:567,y:612,t:1527009259137};\\\", \\\"{x:578,y:602,t:1527009259154};\\\", \\\"{x:588,y:587,t:1527009259171};\\\", \\\"{x:601,y:570,t:1527009259187};\\\", \\\"{x:617,y:552,t:1527009259204};\\\", \\\"{x:631,y:536,t:1527009259221};\\\", \\\"{x:643,y:522,t:1527009259237};\\\", \\\"{x:650,y:512,t:1527009259254};\\\", \\\"{x:655,y:505,t:1527009259271};\\\", \\\"{x:658,y:501,t:1527009259288};\\\", \\\"{x:660,y:496,t:1527009259304};\\\", \\\"{x:661,y:495,t:1527009259328};\\\" ] }, { \\\"rt\\\": 9064, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 17, \\\"time_elapsed\\\": 443027, \\\"internal_node_id\\\": \\\"0.0-6.0-7.0\\\", \\\"subject\\\": \\\"38NFJ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"echo\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 13, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"E\\\", \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-02 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:664,y:493,t:1527009261096};\\\", \\\"{x:675,y:490,t:1527009261106};\\\", \\\"{x:706,y:486,t:1527009261123};\\\", \\\"{x:746,y:481,t:1527009261139};\\\", \\\"{x:811,y:478,t:1527009261156};\\\", \\\"{x:869,y:478,t:1527009261172};\\\", \\\"{x:956,y:478,t:1527009261196};\\\", \\\"{x:984,y:478,t:1527009261206};\\\", \\\"{x:1052,y:487,t:1527009261223};\\\", \\\"{x:1085,y:498,t:1527009261239};\\\", \\\"{x:1118,y:511,t:1527009261256};\\\", \\\"{x:1139,y:520,t:1527009261273};\\\", \\\"{x:1161,y:536,t:1527009261289};\\\", \\\"{x:1184,y:554,t:1527009261306};\\\", \\\"{x:1205,y:569,t:1527009261323};\\\", \\\"{x:1221,y:582,t:1527009261339};\\\", \\\"{x:1236,y:601,t:1527009261356};\\\", \\\"{x:1254,y:618,t:1527009261373};\\\", \\\"{x:1273,y:633,t:1527009261389};\\\", \\\"{x:1288,y:646,t:1527009261406};\\\", \\\"{x:1309,y:669,t:1527009261424};\\\", \\\"{x:1323,y:686,t:1527009261439};\\\", \\\"{x:1338,y:705,t:1527009261456};\\\", \\\"{x:1352,y:725,t:1527009261473};\\\", \\\"{x:1359,y:742,t:1527009261489};\\\", \\\"{x:1366,y:763,t:1527009261506};\\\", \\\"{x:1371,y:784,t:1527009261524};\\\", \\\"{x:1380,y:806,t:1527009261540};\\\", \\\"{x:1390,y:824,t:1527009261556};\\\", \\\"{x:1399,y:835,t:1527009261573};\\\", \\\"{x:1407,y:844,t:1527009261590};\\\", \\\"{x:1416,y:854,t:1527009261607};\\\", \\\"{x:1427,y:867,t:1527009261624};\\\", \\\"{x:1433,y:877,t:1527009261640};\\\", \\\"{x:1438,y:883,t:1527009261657};\\\", \\\"{x:1442,y:887,t:1527009261673};\\\", \\\"{x:1445,y:887,t:1527009261690};\\\", \\\"{x:1447,y:887,t:1527009261707};\\\", \\\"{x:1448,y:887,t:1527009261724};\\\", \\\"{x:1448,y:886,t:1527009261793};\\\", \\\"{x:1449,y:885,t:1527009261807};\\\", \\\"{x:1455,y:869,t:1527009261824};\\\", \\\"{x:1460,y:850,t:1527009261841};\\\", \\\"{x:1465,y:833,t:1527009261857};\\\", \\\"{x:1466,y:821,t:1527009261874};\\\", \\\"{x:1466,y:810,t:1527009261890};\\\", \\\"{x:1466,y:802,t:1527009261908};\\\", \\\"{x:1464,y:796,t:1527009261924};\\\", \\\"{x:1457,y:788,t:1527009261941};\\\", \\\"{x:1448,y:779,t:1527009261958};\\\", \\\"{x:1436,y:771,t:1527009261973};\\\", \\\"{x:1430,y:766,t:1527009261991};\\\", \\\"{x:1423,y:761,t:1527009262007};\\\", \\\"{x:1416,y:756,t:1527009262024};\\\", \\\"{x:1412,y:754,t:1527009262040};\\\", \\\"{x:1407,y:752,t:1527009262058};\\\", \\\"{x:1400,y:749,t:1527009262073};\\\", \\\"{x:1391,y:746,t:1527009262090};\\\", \\\"{x:1381,y:744,t:1527009262108};\\\", \\\"{x:1370,y:743,t:1527009262123};\\\", \\\"{x:1354,y:743,t:1527009262140};\\\", \\\"{x:1341,y:743,t:1527009262158};\\\", \\\"{x:1328,y:745,t:1527009262173};\\\", \\\"{x:1318,y:747,t:1527009262191};\\\", \\\"{x:1311,y:749,t:1527009262208};\\\", \\\"{x:1298,y:756,t:1527009262224};\\\", \\\"{x:1292,y:760,t:1527009262240};\\\", \\\"{x:1289,y:763,t:1527009262258};\\\", \\\"{x:1286,y:770,t:1527009262275};\\\", \\\"{x:1283,y:779,t:1527009262290};\\\", \\\"{x:1282,y:789,t:1527009262308};\\\", \\\"{x:1282,y:799,t:1527009262325};\\\", \\\"{x:1282,y:805,t:1527009262341};\\\", \\\"{x:1284,y:810,t:1527009262358};\\\", \\\"{x:1286,y:814,t:1527009262375};\\\", \\\"{x:1288,y:815,t:1527009262391};\\\", \\\"{x:1290,y:816,t:1527009262408};\\\", \\\"{x:1290,y:817,t:1527009262424};\\\", \\\"{x:1291,y:817,t:1527009262448};\\\", \\\"{x:1292,y:817,t:1527009262457};\\\", \\\"{x:1293,y:817,t:1527009262505};\\\", \\\"{x:1295,y:817,t:1527009262512};\\\", \\\"{x:1297,y:817,t:1527009262524};\\\", \\\"{x:1308,y:815,t:1527009262540};\\\", \\\"{x:1322,y:808,t:1527009262558};\\\", \\\"{x:1337,y:798,t:1527009262575};\\\", \\\"{x:1357,y:781,t:1527009262591};\\\", \\\"{x:1370,y:768,t:1527009262607};\\\", \\\"{x:1385,y:745,t:1527009262625};\\\", \\\"{x:1396,y:718,t:1527009262642};\\\", \\\"{x:1404,y:699,t:1527009262658};\\\", \\\"{x:1410,y:684,t:1527009262675};\\\", \\\"{x:1414,y:675,t:1527009262691};\\\", \\\"{x:1418,y:668,t:1527009262708};\\\", \\\"{x:1420,y:661,t:1527009262724};\\\", \\\"{x:1423,y:653,t:1527009262741};\\\", \\\"{x:1429,y:640,t:1527009262758};\\\", \\\"{x:1438,y:620,t:1527009262774};\\\", \\\"{x:1443,y:607,t:1527009262792};\\\", \\\"{x:1443,y:603,t:1527009262808};\\\", \\\"{x:1445,y:601,t:1527009262824};\\\", \\\"{x:1446,y:598,t:1527009262842};\\\", \\\"{x:1447,y:595,t:1527009262857};\\\", \\\"{x:1447,y:593,t:1527009262874};\\\", \\\"{x:1450,y:587,t:1527009262892};\\\", \\\"{x:1454,y:576,t:1527009262909};\\\", \\\"{x:1459,y:565,t:1527009262925};\\\", \\\"{x:1460,y:557,t:1527009262942};\\\", \\\"{x:1460,y:552,t:1527009262959};\\\", \\\"{x:1461,y:551,t:1527009262974};\\\", \\\"{x:1463,y:551,t:1527009263120};\\\", \\\"{x:1466,y:551,t:1527009263128};\\\", \\\"{x:1469,y:553,t:1527009263141};\\\", \\\"{x:1474,y:557,t:1527009263158};\\\", \\\"{x:1480,y:560,t:1527009263175};\\\", \\\"{x:1487,y:567,t:1527009263193};\\\", \\\"{x:1491,y:570,t:1527009263208};\\\", \\\"{x:1496,y:573,t:1527009263226};\\\", \\\"{x:1507,y:578,t:1527009263242};\\\", \\\"{x:1520,y:584,t:1527009263259};\\\", \\\"{x:1539,y:589,t:1527009263275};\\\", \\\"{x:1554,y:592,t:1527009263292};\\\", \\\"{x:1565,y:593,t:1527009263309};\\\", \\\"{x:1581,y:595,t:1527009263326};\\\", \\\"{x:1590,y:597,t:1527009263342};\\\", \\\"{x:1603,y:599,t:1527009263359};\\\", \\\"{x:1612,y:599,t:1527009263376};\\\", \\\"{x:1616,y:600,t:1527009263392};\\\", \\\"{x:1617,y:600,t:1527009263416};\\\", \\\"{x:1618,y:600,t:1527009263432};\\\", \\\"{x:1619,y:600,t:1527009263441};\\\", \\\"{x:1619,y:599,t:1527009263459};\\\", \\\"{x:1619,y:595,t:1527009263476};\\\", \\\"{x:1619,y:589,t:1527009263492};\\\", \\\"{x:1619,y:582,t:1527009263509};\\\", \\\"{x:1619,y:579,t:1527009263526};\\\", \\\"{x:1619,y:574,t:1527009263541};\\\", \\\"{x:1618,y:573,t:1527009263558};\\\", \\\"{x:1617,y:572,t:1527009263576};\\\", \\\"{x:1616,y:574,t:1527009263688};\\\", \\\"{x:1615,y:580,t:1527009263696};\\\", \\\"{x:1615,y:586,t:1527009263708};\\\", \\\"{x:1615,y:594,t:1527009263725};\\\", \\\"{x:1615,y:604,t:1527009263743};\\\", \\\"{x:1616,y:615,t:1527009263758};\\\", \\\"{x:1620,y:634,t:1527009263776};\\\", \\\"{x:1622,y:648,t:1527009263792};\\\", \\\"{x:1622,y:660,t:1527009263808};\\\", \\\"{x:1624,y:671,t:1527009263826};\\\", \\\"{x:1624,y:680,t:1527009263842};\\\", \\\"{x:1624,y:689,t:1527009263859};\\\", \\\"{x:1624,y:697,t:1527009263876};\\\", \\\"{x:1624,y:705,t:1527009263892};\\\", \\\"{x:1624,y:712,t:1527009263910};\\\", \\\"{x:1623,y:718,t:1527009263926};\\\", \\\"{x:1621,y:726,t:1527009263943};\\\", \\\"{x:1615,y:739,t:1527009263960};\\\", \\\"{x:1609,y:751,t:1527009263976};\\\", \\\"{x:1602,y:768,t:1527009263992};\\\", \\\"{x:1595,y:792,t:1527009264010};\\\", \\\"{x:1588,y:817,t:1527009264026};\\\", \\\"{x:1583,y:839,t:1527009264042};\\\", \\\"{x:1578,y:860,t:1527009264059};\\\", \\\"{x:1576,y:878,t:1527009264075};\\\", \\\"{x:1572,y:900,t:1527009264092};\\\", \\\"{x:1565,y:925,t:1527009264110};\\\", \\\"{x:1556,y:948,t:1527009264125};\\\", \\\"{x:1542,y:968,t:1527009264143};\\\", \\\"{x:1529,y:993,t:1527009264160};\\\", \\\"{x:1524,y:999,t:1527009264176};\\\", \\\"{x:1522,y:1002,t:1527009264193};\\\", \\\"{x:1519,y:1004,t:1527009264210};\\\", \\\"{x:1516,y:1009,t:1527009264226};\\\", \\\"{x:1510,y:1013,t:1527009264243};\\\", \\\"{x:1507,y:1016,t:1527009264260};\\\", \\\"{x:1505,y:1018,t:1527009264276};\\\", \\\"{x:1504,y:1019,t:1527009264368};\\\", \\\"{x:1503,y:1019,t:1527009264376};\\\", \\\"{x:1502,y:1016,t:1527009264393};\\\", \\\"{x:1501,y:1006,t:1527009264410};\\\", \\\"{x:1500,y:997,t:1527009264427};\\\", \\\"{x:1498,y:989,t:1527009264443};\\\", \\\"{x:1498,y:985,t:1527009264459};\\\", \\\"{x:1498,y:982,t:1527009264477};\\\", \\\"{x:1498,y:979,t:1527009264492};\\\", \\\"{x:1498,y:977,t:1527009264510};\\\", \\\"{x:1498,y:975,t:1527009264526};\\\", \\\"{x:1497,y:974,t:1527009264543};\\\", \\\"{x:1494,y:971,t:1527009264560};\\\", \\\"{x:1493,y:970,t:1527009264600};\\\", \\\"{x:1492,y:970,t:1527009264632};\\\", \\\"{x:1490,y:970,t:1527009264648};\\\", \\\"{x:1489,y:970,t:1527009264660};\\\", \\\"{x:1488,y:969,t:1527009264676};\\\", \\\"{x:1485,y:968,t:1527009264695};\\\", \\\"{x:1484,y:968,t:1527009264712};\\\", \\\"{x:1484,y:967,t:1527009264929};\\\", \\\"{x:1483,y:966,t:1527009264943};\\\", \\\"{x:1482,y:965,t:1527009264961};\\\", \\\"{x:1478,y:965,t:1527009265705};\\\", \\\"{x:1467,y:965,t:1527009265712};\\\", \\\"{x:1421,y:951,t:1527009265728};\\\", \\\"{x:1324,y:926,t:1527009265745};\\\", \\\"{x:1194,y:887,t:1527009265761};\\\", \\\"{x:1050,y:843,t:1527009265778};\\\", \\\"{x:929,y:812,t:1527009265795};\\\", \\\"{x:784,y:762,t:1527009265810};\\\", \\\"{x:644,y:707,t:1527009265828};\\\", \\\"{x:523,y:661,t:1527009265845};\\\", \\\"{x:453,y:635,t:1527009265860};\\\", \\\"{x:417,y:620,t:1527009265879};\\\", \\\"{x:399,y:613,t:1527009265895};\\\", \\\"{x:386,y:606,t:1527009265911};\\\", \\\"{x:384,y:605,t:1527009265926};\\\", \\\"{x:381,y:603,t:1527009265942};\\\", \\\"{x:380,y:602,t:1527009265967};\\\", \\\"{x:380,y:601,t:1527009265976};\\\", \\\"{x:378,y:597,t:1527009265993};\\\", \\\"{x:375,y:593,t:1527009266010};\\\", \\\"{x:370,y:588,t:1527009266026};\\\", \\\"{x:370,y:587,t:1527009266055};\\\", \\\"{x:370,y:586,t:1527009266071};\\\", \\\"{x:370,y:585,t:1527009266087};\\\", \\\"{x:370,y:584,t:1527009266103};\\\", \\\"{x:371,y:584,t:1527009266128};\\\", \\\"{x:373,y:583,t:1527009266151};\\\", \\\"{x:373,y:582,t:1527009266168};\\\", \\\"{x:374,y:581,t:1527009266177};\\\", \\\"{x:377,y:578,t:1527009266193};\\\", \\\"{x:382,y:570,t:1527009266209};\\\", \\\"{x:387,y:561,t:1527009266228};\\\", \\\"{x:390,y:556,t:1527009266243};\\\", \\\"{x:391,y:553,t:1527009266260};\\\", \\\"{x:393,y:550,t:1527009266276};\\\", \\\"{x:395,y:546,t:1527009266293};\\\", \\\"{x:400,y:542,t:1527009266310};\\\", \\\"{x:407,y:537,t:1527009266326};\\\", \\\"{x:426,y:528,t:1527009266343};\\\", \\\"{x:433,y:526,t:1527009266360};\\\", \\\"{x:443,y:522,t:1527009266376};\\\", \\\"{x:459,y:517,t:1527009266394};\\\", \\\"{x:479,y:513,t:1527009266410};\\\", \\\"{x:497,y:509,t:1527009266426};\\\", \\\"{x:514,y:506,t:1527009266444};\\\", \\\"{x:521,y:506,t:1527009266459};\\\", \\\"{x:525,y:506,t:1527009266476};\\\", \\\"{x:527,y:505,t:1527009266493};\\\", \\\"{x:532,y:503,t:1527009266510};\\\", \\\"{x:537,y:500,t:1527009266527};\\\", \\\"{x:539,y:499,t:1527009266543};\\\", \\\"{x:542,y:499,t:1527009266560};\\\", \\\"{x:548,y:498,t:1527009266578};\\\", \\\"{x:554,y:496,t:1527009266593};\\\", \\\"{x:558,y:496,t:1527009266611};\\\", \\\"{x:561,y:496,t:1527009266628};\\\", \\\"{x:568,y:496,t:1527009266643};\\\", \\\"{x:572,y:496,t:1527009266660};\\\", \\\"{x:579,y:496,t:1527009266677};\\\", \\\"{x:586,y:496,t:1527009266694};\\\", \\\"{x:590,y:496,t:1527009266710};\\\", \\\"{x:595,y:496,t:1527009266728};\\\", \\\"{x:601,y:496,t:1527009266744};\\\", \\\"{x:604,y:496,t:1527009266760};\\\", \\\"{x:606,y:496,t:1527009266777};\\\", \\\"{x:607,y:496,t:1527009266794};\\\", \\\"{x:608,y:496,t:1527009266811};\\\", \\\"{x:609,y:496,t:1527009266848};\\\", \\\"{x:617,y:496,t:1527009267060};\\\", \\\"{x:644,y:496,t:1527009267077};\\\", \\\"{x:688,y:496,t:1527009267093};\\\", \\\"{x:748,y:499,t:1527009267110};\\\", \\\"{x:818,y:511,t:1527009267127};\\\", \\\"{x:849,y:518,t:1527009267144};\\\", \\\"{x:864,y:522,t:1527009267161};\\\", \\\"{x:872,y:523,t:1527009267177};\\\", \\\"{x:870,y:523,t:1527009267312};\\\", \\\"{x:868,y:522,t:1527009267328};\\\", \\\"{x:866,y:521,t:1527009267344};\\\", \\\"{x:864,y:521,t:1527009267361};\\\", \\\"{x:862,y:520,t:1527009267377};\\\", \\\"{x:860,y:519,t:1527009267393};\\\", \\\"{x:856,y:518,t:1527009267410};\\\", \\\"{x:852,y:515,t:1527009267428};\\\", \\\"{x:849,y:514,t:1527009267443};\\\", \\\"{x:844,y:512,t:1527009267461};\\\", \\\"{x:840,y:510,t:1527009267477};\\\", \\\"{x:837,y:509,t:1527009267494};\\\", \\\"{x:835,y:508,t:1527009267510};\\\", \\\"{x:833,y:507,t:1527009267558};\\\", \\\"{x:832,y:507,t:1527009267599};\\\", \\\"{x:830,y:507,t:1527009267775};\\\", \\\"{x:826,y:512,t:1527009267782};\\\", \\\"{x:822,y:518,t:1527009267795};\\\", \\\"{x:805,y:530,t:1527009267812};\\\", \\\"{x:783,y:546,t:1527009267827};\\\", \\\"{x:753,y:565,t:1527009267844};\\\", \\\"{x:721,y:582,t:1527009267862};\\\", \\\"{x:691,y:600,t:1527009267877};\\\", \\\"{x:666,y:618,t:1527009267895};\\\", \\\"{x:623,y:651,t:1527009267911};\\\", \\\"{x:583,y:680,t:1527009267927};\\\", \\\"{x:549,y:706,t:1527009267944};\\\", \\\"{x:530,y:723,t:1527009267962};\\\", \\\"{x:516,y:733,t:1527009267977};\\\", \\\"{x:508,y:741,t:1527009267994};\\\", \\\"{x:501,y:747,t:1527009268011};\\\", \\\"{x:494,y:755,t:1527009268028};\\\", \\\"{x:488,y:762,t:1527009268044};\\\", \\\"{x:482,y:770,t:1527009268062};\\\", \\\"{x:480,y:773,t:1527009268078};\\\", \\\"{x:478,y:777,t:1527009268095};\\\", \\\"{x:476,y:779,t:1527009268111};\\\", \\\"{x:478,y:775,t:1527009268280};\\\", \\\"{x:481,y:770,t:1527009268295};\\\", \\\"{x:488,y:751,t:1527009268313};\\\", \\\"{x:488,y:747,t:1527009268328};\\\", \\\"{x:489,y:746,t:1527009268345};\\\", \\\"{x:489,y:744,t:1527009268362};\\\", \\\"{x:489,y:743,t:1527009268391};\\\", \\\"{x:490,y:742,t:1527009268415};\\\", \\\"{x:491,y:741,t:1527009268428};\\\", \\\"{x:492,y:740,t:1527009269152};\\\", \\\"{x:496,y:726,t:1527009269162};\\\", \\\"{x:529,y:680,t:1527009269179};\\\", \\\"{x:553,y:646,t:1527009269195};\\\", \\\"{x:573,y:619,t:1527009269212};\\\", \\\"{x:590,y:601,t:1527009269228};\\\", \\\"{x:606,y:587,t:1527009269245};\\\", \\\"{x:619,y:576,t:1527009269262};\\\", \\\"{x:633,y:564,t:1527009269278};\\\", \\\"{x:651,y:550,t:1527009269296};\\\", \\\"{x:657,y:545,t:1527009269312};\\\", \\\"{x:659,y:544,t:1527009269329};\\\" ] }, { \\\"rt\\\": 6949, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 18, \\\"time_elapsed\\\": 451177, \\\"internal_node_id\\\": \\\"0.0-6.0-8.0\\\", \\\"subject\\\": \\\"38NFJ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"echo\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 14, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-03 PM-5\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:652,y:544,t:1527009270280};\\\", \\\"{x:641,y:544,t:1527009270297};\\\", \\\"{x:637,y:544,t:1527009270364};\\\", \\\"{x:641,y:544,t:1527009270527};\\\", \\\"{x:646,y:543,t:1527009270535};\\\", \\\"{x:650,y:542,t:1527009270546};\\\", \\\"{x:662,y:542,t:1527009270563};\\\", \\\"{x:686,y:539,t:1527009270579};\\\", \\\"{x:715,y:535,t:1527009270596};\\\", \\\"{x:750,y:533,t:1527009270615};\\\", \\\"{x:783,y:533,t:1527009270630};\\\", \\\"{x:820,y:533,t:1527009270647};\\\", \\\"{x:895,y:533,t:1527009270663};\\\", \\\"{x:940,y:533,t:1527009270680};\\\", \\\"{x:977,y:538,t:1527009270697};\\\", \\\"{x:1003,y:540,t:1527009270714};\\\", \\\"{x:1026,y:544,t:1527009270730};\\\", \\\"{x:1047,y:548,t:1527009270746};\\\", \\\"{x:1058,y:549,t:1527009270763};\\\", \\\"{x:1069,y:551,t:1527009270780};\\\", \\\"{x:1079,y:553,t:1527009270797};\\\", \\\"{x:1088,y:554,t:1527009270813};\\\", \\\"{x:1100,y:555,t:1527009270830};\\\", \\\"{x:1118,y:558,t:1527009270846};\\\", \\\"{x:1167,y:566,t:1527009270863};\\\", \\\"{x:1208,y:574,t:1527009270880};\\\", \\\"{x:1267,y:593,t:1527009270896};\\\", \\\"{x:1326,y:613,t:1527009270913};\\\", \\\"{x:1379,y:645,t:1527009270930};\\\", \\\"{x:1430,y:682,t:1527009270946};\\\", \\\"{x:1477,y:725,t:1527009270963};\\\", \\\"{x:1514,y:776,t:1527009270981};\\\", \\\"{x:1552,y:836,t:1527009270997};\\\", \\\"{x:1577,y:882,t:1527009271014};\\\", \\\"{x:1598,y:919,t:1527009271030};\\\", \\\"{x:1620,y:963,t:1527009271048};\\\", \\\"{x:1635,y:986,t:1527009271064};\\\", \\\"{x:1650,y:1005,t:1527009271081};\\\", \\\"{x:1660,y:1021,t:1527009271096};\\\", \\\"{x:1665,y:1033,t:1527009271113};\\\", \\\"{x:1666,y:1037,t:1527009271131};\\\", \\\"{x:1666,y:1041,t:1527009271146};\\\", \\\"{x:1664,y:1046,t:1527009271164};\\\", \\\"{x:1652,y:1050,t:1527009271181};\\\", \\\"{x:1635,y:1050,t:1527009271197};\\\", \\\"{x:1610,y:1050,t:1527009271214};\\\", \\\"{x:1583,y:1050,t:1527009271230};\\\", \\\"{x:1550,y:1046,t:1527009271247};\\\", \\\"{x:1535,y:1044,t:1527009271264};\\\", \\\"{x:1520,y:1039,t:1527009271280};\\\", \\\"{x:1512,y:1037,t:1527009271298};\\\", \\\"{x:1512,y:1035,t:1527009271336};\\\", \\\"{x:1513,y:1034,t:1527009271347};\\\", \\\"{x:1522,y:1024,t:1527009271363};\\\", \\\"{x:1532,y:1020,t:1527009271380};\\\", \\\"{x:1541,y:1016,t:1527009271398};\\\", \\\"{x:1550,y:1011,t:1527009271414};\\\", \\\"{x:1559,y:1006,t:1527009271431};\\\", \\\"{x:1567,y:1002,t:1527009271447};\\\", \\\"{x:1574,y:997,t:1527009271464};\\\", \\\"{x:1580,y:993,t:1527009271480};\\\", \\\"{x:1585,y:990,t:1527009271497};\\\", \\\"{x:1588,y:989,t:1527009271515};\\\", \\\"{x:1590,y:987,t:1527009271530};\\\", \\\"{x:1590,y:986,t:1527009271548};\\\", \\\"{x:1591,y:986,t:1527009271565};\\\", \\\"{x:1589,y:986,t:1527009271632};\\\", \\\"{x:1584,y:986,t:1527009271648};\\\", \\\"{x:1579,y:986,t:1527009271664};\\\", \\\"{x:1573,y:986,t:1527009271681};\\\", \\\"{x:1568,y:984,t:1527009271698};\\\", \\\"{x:1564,y:983,t:1527009271715};\\\", \\\"{x:1562,y:983,t:1527009271731};\\\", \\\"{x:1561,y:983,t:1527009271751};\\\", \\\"{x:1560,y:982,t:1527009271784};\\\", \\\"{x:1558,y:981,t:1527009271816};\\\", \\\"{x:1557,y:980,t:1527009271912};\\\", \\\"{x:1556,y:978,t:1527009271928};\\\", \\\"{x:1556,y:977,t:1527009271936};\\\", \\\"{x:1554,y:975,t:1527009271948};\\\", \\\"{x:1553,y:974,t:1527009271965};\\\", \\\"{x:1551,y:972,t:1527009271982};\\\", \\\"{x:1551,y:971,t:1527009271997};\\\", \\\"{x:1550,y:971,t:1527009272056};\\\", \\\"{x:1550,y:969,t:1527009272080};\\\", \\\"{x:1548,y:969,t:1527009272087};\\\", \\\"{x:1548,y:968,t:1527009272099};\\\", \\\"{x:1547,y:967,t:1527009272115};\\\", \\\"{x:1546,y:966,t:1527009272132};\\\", \\\"{x:1545,y:966,t:1527009272148};\\\", \\\"{x:1544,y:965,t:1527009272255};\\\", \\\"{x:1544,y:964,t:1527009272376};\\\", \\\"{x:1543,y:964,t:1527009272384};\\\", \\\"{x:1543,y:963,t:1527009272433};\\\", \\\"{x:1542,y:963,t:1527009272456};\\\", \\\"{x:1542,y:962,t:1527009272505};\\\", \\\"{x:1542,y:961,t:1527009272585};\\\", \\\"{x:1542,y:960,t:1527009272752};\\\", \\\"{x:1542,y:959,t:1527009272766};\\\", \\\"{x:1542,y:957,t:1527009272784};\\\", \\\"{x:1543,y:956,t:1527009272799};\\\", \\\"{x:1543,y:955,t:1527009272826};\\\", \\\"{x:1543,y:954,t:1527009272840};\\\", \\\"{x:1543,y:953,t:1527009272864};\\\", \\\"{x:1543,y:952,t:1527009273088};\\\", \\\"{x:1542,y:951,t:1527009273144};\\\", \\\"{x:1538,y:948,t:1527009273944};\\\", \\\"{x:1530,y:944,t:1527009273952};\\\", \\\"{x:1518,y:939,t:1527009273966};\\\", \\\"{x:1479,y:924,t:1527009273982};\\\", \\\"{x:1392,y:888,t:1527009273999};\\\", \\\"{x:1336,y:870,t:1527009274016};\\\", \\\"{x:1291,y:850,t:1527009274033};\\\", \\\"{x:1257,y:834,t:1527009274050};\\\", \\\"{x:1229,y:815,t:1527009274067};\\\", \\\"{x:1202,y:792,t:1527009274084};\\\", \\\"{x:1172,y:754,t:1527009274100};\\\", \\\"{x:1146,y:717,t:1527009274117};\\\", \\\"{x:1124,y:691,t:1527009274134};\\\", \\\"{x:1106,y:670,t:1527009274150};\\\", \\\"{x:1089,y:651,t:1527009274167};\\\", \\\"{x:1059,y:633,t:1527009274183};\\\", \\\"{x:1040,y:623,t:1527009274201};\\\", \\\"{x:1027,y:618,t:1527009274216};\\\", \\\"{x:1013,y:616,t:1527009274234};\\\", \\\"{x:1000,y:611,t:1527009274250};\\\", \\\"{x:981,y:605,t:1527009274267};\\\", \\\"{x:966,y:601,t:1527009274284};\\\", \\\"{x:955,y:598,t:1527009274300};\\\", \\\"{x:946,y:596,t:1527009274317};\\\", \\\"{x:935,y:595,t:1527009274334};\\\", \\\"{x:921,y:592,t:1527009274351};\\\", \\\"{x:904,y:591,t:1527009274366};\\\", \\\"{x:886,y:591,t:1527009274379};\\\", \\\"{x:867,y:591,t:1527009274396};\\\", \\\"{x:847,y:591,t:1527009274412};\\\", \\\"{x:827,y:591,t:1527009274429};\\\", \\\"{x:812,y:592,t:1527009274446};\\\", \\\"{x:806,y:593,t:1527009274463};\\\", \\\"{x:795,y:595,t:1527009274479};\\\", \\\"{x:784,y:598,t:1527009274497};\\\", \\\"{x:775,y:599,t:1527009274516};\\\", \\\"{x:763,y:599,t:1527009274532};\\\", \\\"{x:752,y:602,t:1527009274550};\\\", \\\"{x:739,y:603,t:1527009274566};\\\", \\\"{x:713,y:603,t:1527009274583};\\\", \\\"{x:688,y:604,t:1527009274600};\\\", \\\"{x:668,y:604,t:1527009274616};\\\", \\\"{x:651,y:604,t:1527009274633};\\\", \\\"{x:641,y:604,t:1527009274650};\\\", \\\"{x:635,y:604,t:1527009274666};\\\", \\\"{x:628,y:604,t:1527009274682};\\\", \\\"{x:623,y:604,t:1527009274699};\\\", \\\"{x:616,y:604,t:1527009274716};\\\", \\\"{x:607,y:604,t:1527009274732};\\\", \\\"{x:593,y:604,t:1527009274749};\\\", \\\"{x:578,y:604,t:1527009274767};\\\", \\\"{x:573,y:604,t:1527009274782};\\\", \\\"{x:566,y:602,t:1527009274800};\\\", \\\"{x:566,y:601,t:1527009274984};\\\", \\\"{x:566,y:600,t:1527009275009};\\\", \\\"{x:568,y:596,t:1527009275017};\\\", \\\"{x:573,y:587,t:1527009275034};\\\", \\\"{x:578,y:576,t:1527009275049};\\\", \\\"{x:585,y:565,t:1527009275066};\\\", \\\"{x:593,y:555,t:1527009275084};\\\", \\\"{x:599,y:547,t:1527009275100};\\\", \\\"{x:606,y:541,t:1527009275116};\\\", \\\"{x:613,y:535,t:1527009275134};\\\", \\\"{x:618,y:530,t:1527009275151};\\\", \\\"{x:619,y:530,t:1527009275167};\\\", \\\"{x:620,y:529,t:1527009275183};\\\", \\\"{x:618,y:529,t:1527009275280};\\\", \\\"{x:615,y:533,t:1527009275288};\\\", \\\"{x:610,y:537,t:1527009275301};\\\", \\\"{x:600,y:546,t:1527009275317};\\\", \\\"{x:589,y:552,t:1527009275334};\\\", \\\"{x:580,y:559,t:1527009275351};\\\", \\\"{x:568,y:563,t:1527009275367};\\\", \\\"{x:550,y:570,t:1527009275383};\\\", \\\"{x:543,y:574,t:1527009275400};\\\", \\\"{x:543,y:575,t:1527009275417};\\\", \\\"{x:545,y:574,t:1527009275495};\\\", \\\"{x:550,y:574,t:1527009275503};\\\", \\\"{x:556,y:572,t:1527009275517};\\\", \\\"{x:568,y:569,t:1527009275534};\\\", \\\"{x:581,y:567,t:1527009275550};\\\", \\\"{x:594,y:565,t:1527009275567};\\\", \\\"{x:598,y:564,t:1527009275584};\\\", \\\"{x:600,y:564,t:1527009275601};\\\", \\\"{x:602,y:564,t:1527009275618};\\\", \\\"{x:603,y:564,t:1527009275634};\\\", \\\"{x:605,y:564,t:1527009275650};\\\", \\\"{x:607,y:563,t:1527009275668};\\\", \\\"{x:609,y:563,t:1527009275683};\\\", \\\"{x:612,y:563,t:1527009275701};\\\", \\\"{x:616,y:564,t:1527009275717};\\\", \\\"{x:618,y:565,t:1527009275734};\\\", \\\"{x:618,y:566,t:1527009275752};\\\", \\\"{x:618,y:567,t:1527009275767};\\\", \\\"{x:618,y:570,t:1527009275785};\\\", \\\"{x:618,y:573,t:1527009275801};\\\", \\\"{x:618,y:577,t:1527009275818};\\\", \\\"{x:617,y:580,t:1527009275834};\\\", \\\"{x:616,y:581,t:1527009275850};\\\", \\\"{x:615,y:582,t:1527009275868};\\\", \\\"{x:614,y:582,t:1527009275885};\\\", \\\"{x:613,y:582,t:1527009275904};\\\", \\\"{x:612,y:582,t:1527009276055};\\\", \\\"{x:611,y:582,t:1527009276068};\\\", \\\"{x:609,y:582,t:1527009276083};\\\", \\\"{x:607,y:584,t:1527009276101};\\\", \\\"{x:602,y:589,t:1527009276118};\\\", \\\"{x:586,y:607,t:1527009276134};\\\", \\\"{x:569,y:630,t:1527009276150};\\\", \\\"{x:539,y:666,t:1527009276168};\\\", \\\"{x:528,y:681,t:1527009276184};\\\", \\\"{x:520,y:693,t:1527009276201};\\\", \\\"{x:514,y:705,t:1527009276217};\\\", \\\"{x:511,y:716,t:1527009276235};\\\", \\\"{x:510,y:726,t:1527009276251};\\\", \\\"{x:506,y:736,t:1527009276268};\\\", \\\"{x:504,y:743,t:1527009276284};\\\", \\\"{x:501,y:747,t:1527009276301};\\\", \\\"{x:498,y:752,t:1527009276317};\\\", \\\"{x:497,y:755,t:1527009276335};\\\", \\\"{x:496,y:756,t:1527009276351};\\\", \\\"{x:496,y:753,t:1527009276521};\\\", \\\"{x:496,y:750,t:1527009276534};\\\", \\\"{x:496,y:743,t:1527009276551};\\\", \\\"{x:497,y:740,t:1527009276567};\\\", \\\"{x:498,y:739,t:1527009276585};\\\", \\\"{x:500,y:739,t:1527009276631};\\\", \\\"{x:502,y:739,t:1527009276655};\\\", \\\"{x:502,y:739,t:1527009276766};\\\", \\\"{x:504,y:738,t:1527009277519};\\\", \\\"{x:508,y:734,t:1527009277536};\\\", \\\"{x:511,y:729,t:1527009277552};\\\", \\\"{x:519,y:723,t:1527009277569};\\\", \\\"{x:532,y:713,t:1527009277586};\\\", \\\"{x:543,y:706,t:1527009277603};\\\", \\\"{x:561,y:697,t:1527009277618};\\\", \\\"{x:587,y:684,t:1527009277636};\\\", \\\"{x:627,y:668,t:1527009277653};\\\", \\\"{x:686,y:640,t:1527009277669};\\\", \\\"{x:748,y:607,t:1527009277685};\\\", \\\"{x:787,y:581,t:1527009277703};\\\", \\\"{x:808,y:568,t:1527009277719};\\\", \\\"{x:824,y:556,t:1527009277735};\\\", \\\"{x:832,y:549,t:1527009277753};\\\", \\\"{x:843,y:540,t:1527009277769};\\\", \\\"{x:852,y:533,t:1527009277786};\\\", \\\"{x:853,y:531,t:1527009277802};\\\" ] }, { \\\"rt\\\": 11723, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 19, \\\"time_elapsed\\\": 464096, \\\"internal_node_id\\\": \\\"0.0-6.0-9.0\\\", \\\"subject\\\": \\\"38NFJ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"echo\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 15, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"K\\\", \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-01 PM-02 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:856,y:529,t:1527009278664};\\\", \\\"{x:862,y:526,t:1527009278694};\\\", \\\"{x:870,y:524,t:1527009278703};\\\", \\\"{x:878,y:523,t:1527009278719};\\\", \\\"{x:889,y:520,t:1527009278737};\\\", \\\"{x:893,y:520,t:1527009278752};\\\", \\\"{x:894,y:520,t:1527009278775};\\\", \\\"{x:895,y:520,t:1527009278806};\\\", \\\"{x:896,y:520,t:1527009278819};\\\", \\\"{x:897,y:520,t:1527009278847};\\\", \\\"{x:898,y:520,t:1527009278855};\\\", \\\"{x:899,y:520,t:1527009278869};\\\", \\\"{x:899,y:519,t:1527009278886};\\\", \\\"{x:905,y:520,t:1527009280536};\\\", \\\"{x:923,y:528,t:1527009280543};\\\", \\\"{x:944,y:536,t:1527009280556};\\\", \\\"{x:963,y:542,t:1527009280571};\\\", \\\"{x:968,y:544,t:1527009280587};\\\", \\\"{x:969,y:545,t:1527009280615};\\\", \\\"{x:965,y:545,t:1527009280662};\\\", \\\"{x:952,y:545,t:1527009280671};\\\", \\\"{x:926,y:542,t:1527009280688};\\\", \\\"{x:903,y:525,t:1527009280705};\\\", \\\"{x:857,y:473,t:1527009280721};\\\", \\\"{x:792,y:379,t:1527009280737};\\\", \\\"{x:730,y:262,t:1527009280755};\\\", \\\"{x:718,y:244,t:1527009280771};\\\", \\\"{x:718,y:245,t:1527009281528};\\\", \\\"{x:720,y:251,t:1527009281540};\\\", \\\"{x:724,y:261,t:1527009281556};\\\", \\\"{x:729,y:271,t:1527009281572};\\\", \\\"{x:732,y:278,t:1527009281589};\\\", \\\"{x:737,y:285,t:1527009281605};\\\", \\\"{x:740,y:291,t:1527009281622};\\\", \\\"{x:743,y:296,t:1527009281640};\\\", \\\"{x:745,y:298,t:1527009281656};\\\", \\\"{x:745,y:299,t:1527009281672};\\\", \\\"{x:745,y:300,t:1527009281689};\\\", \\\"{x:745,y:301,t:1527009281707};\\\", \\\"{x:745,y:302,t:1527009281722};\\\", \\\"{x:745,y:303,t:1527009282520};\\\", \\\"{x:742,y:308,t:1527009282528};\\\", \\\"{x:737,y:315,t:1527009282539};\\\", \\\"{x:723,y:326,t:1527009282556};\\\", \\\"{x:711,y:335,t:1527009282573};\\\", \\\"{x:698,y:343,t:1527009282589};\\\", \\\"{x:696,y:345,t:1527009282606};\\\", \\\"{x:694,y:347,t:1527009282623};\\\", \\\"{x:693,y:347,t:1527009282664};\\\", \\\"{x:692,y:350,t:1527009283624};\\\", \\\"{x:693,y:360,t:1527009283641};\\\", \\\"{x:695,y:369,t:1527009283657};\\\", \\\"{x:697,y:378,t:1527009283674};\\\", \\\"{x:700,y:385,t:1527009283691};\\\", \\\"{x:701,y:389,t:1527009283707};\\\", \\\"{x:703,y:395,t:1527009283724};\\\", \\\"{x:703,y:400,t:1527009283741};\\\", \\\"{x:704,y:405,t:1527009283757};\\\", \\\"{x:704,y:410,t:1527009283774};\\\", \\\"{x:704,y:416,t:1527009283790};\\\", \\\"{x:704,y:423,t:1527009283808};\\\", \\\"{x:704,y:426,t:1527009283824};\\\", \\\"{x:704,y:430,t:1527009283841};\\\", \\\"{x:704,y:433,t:1527009283857};\\\", \\\"{x:704,y:437,t:1527009283874};\\\", \\\"{x:704,y:440,t:1527009283891};\\\", \\\"{x:704,y:444,t:1527009283907};\\\", \\\"{x:702,y:453,t:1527009283924};\\\", \\\"{x:698,y:464,t:1527009283941};\\\", \\\"{x:695,y:470,t:1527009283957};\\\", \\\"{x:693,y:476,t:1527009283974};\\\", \\\"{x:691,y:480,t:1527009283990};\\\", \\\"{x:685,y:487,t:1527009284008};\\\", \\\"{x:680,y:491,t:1527009284023};\\\", \\\"{x:671,y:498,t:1527009284041};\\\", \\\"{x:663,y:505,t:1527009284058};\\\", \\\"{x:660,y:507,t:1527009284074};\\\", \\\"{x:656,y:510,t:1527009284091};\\\", \\\"{x:652,y:512,t:1527009284106};\\\", \\\"{x:650,y:513,t:1527009284124};\\\", \\\"{x:649,y:513,t:1527009284264};\\\", \\\"{x:648,y:513,t:1527009284279};\\\", \\\"{x:647,y:513,t:1527009284291};\\\", \\\"{x:644,y:511,t:1527009284308};\\\", \\\"{x:641,y:508,t:1527009284326};\\\", \\\"{x:638,y:504,t:1527009284342};\\\", \\\"{x:632,y:500,t:1527009284358};\\\", \\\"{x:625,y:495,t:1527009284374};\\\", \\\"{x:617,y:489,t:1527009284391};\\\", \\\"{x:614,y:487,t:1527009284407};\\\", \\\"{x:611,y:485,t:1527009284424};\\\", \\\"{x:610,y:485,t:1527009284441};\\\", \\\"{x:609,y:484,t:1527009284479};\\\", \\\"{x:610,y:484,t:1527009284583};\\\", \\\"{x:613,y:484,t:1527009284599};\\\", \\\"{x:616,y:484,t:1527009284608};\\\", \\\"{x:627,y:484,t:1527009284624};\\\", \\\"{x:643,y:484,t:1527009284641};\\\", \\\"{x:666,y:484,t:1527009284658};\\\", \\\"{x:697,y:486,t:1527009284674};\\\", \\\"{x:745,y:489,t:1527009284691};\\\", \\\"{x:821,y:499,t:1527009284708};\\\", \\\"{x:916,y:519,t:1527009284725};\\\", \\\"{x:1025,y:554,t:1527009284741};\\\", \\\"{x:1126,y:594,t:1527009284758};\\\", \\\"{x:1275,y:666,t:1527009284775};\\\", \\\"{x:1384,y:724,t:1527009284791};\\\", \\\"{x:1467,y:777,t:1527009284807};\\\", \\\"{x:1532,y:818,t:1527009284825};\\\", \\\"{x:1583,y:855,t:1527009284842};\\\", \\\"{x:1630,y:893,t:1527009284858};\\\", \\\"{x:1671,y:928,t:1527009284875};\\\", \\\"{x:1710,y:962,t:1527009284892};\\\", \\\"{x:1742,y:989,t:1527009284908};\\\", \\\"{x:1767,y:1010,t:1527009284925};\\\", \\\"{x:1781,y:1021,t:1527009284942};\\\", \\\"{x:1789,y:1028,t:1527009284959};\\\", \\\"{x:1789,y:1032,t:1527009284975};\\\", \\\"{x:1788,y:1036,t:1527009284992};\\\", \\\"{x:1773,y:1040,t:1527009285009};\\\", \\\"{x:1750,y:1041,t:1527009285025};\\\", \\\"{x:1721,y:1043,t:1527009285042};\\\", \\\"{x:1681,y:1043,t:1527009285059};\\\", \\\"{x:1628,y:1043,t:1527009285075};\\\", \\\"{x:1570,y:1038,t:1527009285092};\\\", \\\"{x:1515,y:1029,t:1527009285109};\\\", \\\"{x:1456,y:1013,t:1527009285127};\\\", \\\"{x:1428,y:1004,t:1527009285142};\\\", \\\"{x:1409,y:996,t:1527009285159};\\\", \\\"{x:1405,y:993,t:1527009285175};\\\", \\\"{x:1404,y:992,t:1527009285192};\\\", \\\"{x:1405,y:989,t:1527009285288};\\\", \\\"{x:1413,y:984,t:1527009285296};\\\", \\\"{x:1420,y:981,t:1527009285310};\\\", \\\"{x:1443,y:971,t:1527009285327};\\\", \\\"{x:1469,y:965,t:1527009285343};\\\", \\\"{x:1484,y:961,t:1527009285360};\\\", \\\"{x:1496,y:960,t:1527009285377};\\\", \\\"{x:1503,y:958,t:1527009285393};\\\", \\\"{x:1506,y:958,t:1527009285410};\\\", \\\"{x:1509,y:958,t:1527009285426};\\\", \\\"{x:1513,y:958,t:1527009285443};\\\", \\\"{x:1517,y:958,t:1527009285460};\\\", \\\"{x:1519,y:957,t:1527009285476};\\\", \\\"{x:1518,y:957,t:1527009285568};\\\", \\\"{x:1513,y:959,t:1527009285578};\\\", \\\"{x:1504,y:963,t:1527009285594};\\\", \\\"{x:1492,y:969,t:1527009285611};\\\", \\\"{x:1486,y:971,t:1527009285627};\\\", \\\"{x:1484,y:972,t:1527009285644};\\\", \\\"{x:1483,y:972,t:1527009285660};\\\", \\\"{x:1482,y:972,t:1527009285912};\\\", \\\"{x:1482,y:971,t:1527009285968};\\\", \\\"{x:1482,y:970,t:1527009286000};\\\", \\\"{x:1482,y:969,t:1527009286012};\\\", \\\"{x:1482,y:967,t:1527009286029};\\\", \\\"{x:1482,y:966,t:1527009286044};\\\", \\\"{x:1482,y:965,t:1527009286062};\\\", \\\"{x:1482,y:964,t:1527009286088};\\\", \\\"{x:1482,y:963,t:1527009286095};\\\", \\\"{x:1481,y:963,t:1527009286112};\\\", \\\"{x:1481,y:960,t:1527009286129};\\\", \\\"{x:1480,y:956,t:1527009286146};\\\", \\\"{x:1479,y:955,t:1527009286161};\\\", \\\"{x:1478,y:952,t:1527009286179};\\\", \\\"{x:1478,y:950,t:1527009286504};\\\", \\\"{x:1478,y:948,t:1527009286513};\\\", \\\"{x:1478,y:946,t:1527009286530};\\\", \\\"{x:1478,y:942,t:1527009286546};\\\", \\\"{x:1477,y:939,t:1527009286563};\\\", \\\"{x:1477,y:936,t:1527009286579};\\\", \\\"{x:1477,y:935,t:1527009286596};\\\", \\\"{x:1477,y:934,t:1527009286624};\\\", \\\"{x:1477,y:933,t:1527009286800};\\\", \\\"{x:1477,y:932,t:1527009286880};\\\", \\\"{x:1473,y:922,t:1527009286897};\\\", \\\"{x:1467,y:905,t:1527009286914};\\\", \\\"{x:1446,y:866,t:1527009286931};\\\", \\\"{x:1400,y:811,t:1527009286947};\\\", \\\"{x:1318,y:741,t:1527009286963};\\\", \\\"{x:1231,y:678,t:1527009286980};\\\", \\\"{x:1155,y:639,t:1527009286998};\\\", \\\"{x:1086,y:608,t:1527009287014};\\\", \\\"{x:1024,y:587,t:1527009287031};\\\", \\\"{x:946,y:564,t:1527009287048};\\\", \\\"{x:908,y:555,t:1527009287063};\\\", \\\"{x:891,y:551,t:1527009287073};\\\", \\\"{x:868,y:550,t:1527009287089};\\\", \\\"{x:857,y:550,t:1527009287106};\\\", \\\"{x:839,y:553,t:1527009287126};\\\", \\\"{x:810,y:558,t:1527009287143};\\\", \\\"{x:782,y:564,t:1527009287160};\\\", \\\"{x:754,y:569,t:1527009287176};\\\", \\\"{x:728,y:574,t:1527009287193};\\\", \\\"{x:699,y:576,t:1527009287210};\\\", \\\"{x:664,y:576,t:1527009287226};\\\", \\\"{x:627,y:576,t:1527009287242};\\\", \\\"{x:594,y:582,t:1527009287260};\\\", \\\"{x:581,y:584,t:1527009287276};\\\", \\\"{x:578,y:585,t:1527009287293};\\\", \\\"{x:577,y:585,t:1527009287310};\\\", \\\"{x:577,y:586,t:1527009287432};\\\", \\\"{x:577,y:587,t:1527009287444};\\\", \\\"{x:577,y:588,t:1527009287460};\\\", \\\"{x:579,y:589,t:1527009287504};\\\", \\\"{x:580,y:589,t:1527009287519};\\\", \\\"{x:581,y:590,t:1527009287535};\\\", \\\"{x:584,y:590,t:1527009287543};\\\", \\\"{x:586,y:592,t:1527009287561};\\\", \\\"{x:592,y:592,t:1527009287577};\\\", \\\"{x:597,y:592,t:1527009287593};\\\", \\\"{x:600,y:592,t:1527009287612};\\\", \\\"{x:601,y:592,t:1527009287626};\\\", \\\"{x:602,y:592,t:1527009287643};\\\", \\\"{x:605,y:592,t:1527009287660};\\\", \\\"{x:606,y:592,t:1527009287677};\\\", \\\"{x:608,y:592,t:1527009287693};\\\", \\\"{x:609,y:592,t:1527009287710};\\\", \\\"{x:611,y:592,t:1527009288015};\\\", \\\"{x:618,y:591,t:1527009288027};\\\", \\\"{x:635,y:590,t:1527009288044};\\\", \\\"{x:660,y:584,t:1527009288060};\\\", \\\"{x:686,y:581,t:1527009288077};\\\", \\\"{x:702,y:578,t:1527009288094};\\\", \\\"{x:710,y:575,t:1527009288110};\\\", \\\"{x:713,y:575,t:1527009288127};\\\", \\\"{x:708,y:575,t:1527009288168};\\\", \\\"{x:692,y:579,t:1527009288179};\\\", \\\"{x:647,y:590,t:1527009288194};\\\", \\\"{x:608,y:602,t:1527009288211};\\\", \\\"{x:567,y:612,t:1527009288227};\\\", \\\"{x:506,y:620,t:1527009288244};\\\", \\\"{x:458,y:627,t:1527009288261};\\\", \\\"{x:430,y:630,t:1527009288277};\\\", \\\"{x:409,y:633,t:1527009288295};\\\", \\\"{x:387,y:636,t:1527009288311};\\\", \\\"{x:384,y:636,t:1527009288327};\\\", \\\"{x:382,y:636,t:1527009288440};\\\", \\\"{x:382,y:634,t:1527009288447};\\\", \\\"{x:381,y:631,t:1527009288462};\\\", \\\"{x:380,y:624,t:1527009288478};\\\", \\\"{x:379,y:618,t:1527009288495};\\\", \\\"{x:378,y:611,t:1527009288512};\\\", \\\"{x:378,y:607,t:1527009288527};\\\", \\\"{x:378,y:603,t:1527009288544};\\\", \\\"{x:378,y:598,t:1527009288560};\\\", \\\"{x:378,y:596,t:1527009288576};\\\", \\\"{x:378,y:593,t:1527009288593};\\\", \\\"{x:378,y:591,t:1527009288611};\\\", \\\"{x:378,y:590,t:1527009288630};\\\", \\\"{x:379,y:589,t:1527009288811};\\\", \\\"{x:380,y:594,t:1527009288847};\\\", \\\"{x:388,y:609,t:1527009288861};\\\", \\\"{x:407,y:648,t:1527009288878};\\\", \\\"{x:434,y:694,t:1527009288894};\\\", \\\"{x:469,y:745,t:1527009288912};\\\", \\\"{x:482,y:766,t:1527009288928};\\\", \\\"{x:493,y:781,t:1527009288944};\\\", \\\"{x:498,y:788,t:1527009288961};\\\", \\\"{x:500,y:793,t:1527009288978};\\\", \\\"{x:500,y:794,t:1527009288994};\\\", \\\"{x:500,y:797,t:1527009289011};\\\", \\\"{x:500,y:795,t:1527009289127};\\\", \\\"{x:501,y:786,t:1527009289146};\\\", \\\"{x:501,y:783,t:1527009289162};\\\", \\\"{x:501,y:781,t:1527009289178};\\\", \\\"{x:502,y:778,t:1527009289196};\\\", \\\"{x:502,y:776,t:1527009289231};\\\", \\\"{x:502,y:775,t:1527009289245};\\\", \\\"{x:502,y:771,t:1527009289262};\\\", \\\"{x:503,y:769,t:1527009289278};\\\", \\\"{x:504,y:768,t:1527009289343};\\\", \\\"{x:504,y:768,t:1527009289391};\\\", \\\"{x:504,y:767,t:1527009289414};\\\", \\\"{x:505,y:764,t:1527009289428};\\\", \\\"{x:508,y:760,t:1527009289445};\\\", \\\"{x:510,y:758,t:1527009289461};\\\", \\\"{x:511,y:756,t:1527009289478};\\\", \\\"{x:512,y:754,t:1527009289495};\\\" ] }, { \\\"rt\\\": 87280, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 20, \\\"time_elapsed\\\": 552600, \\\"internal_node_id\\\": \\\"0.0-7.0-0.0\\\", \\\"subject\\\": \\\"38NFJ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"echo\\\", \\\"condition\\\": \\\"121\\\", \\\"q\\\": 16, \\\"answer\\\": \\\"took me a few questions to figure out, but the left corner of the equilateral triangle (positioning the letter at the top) is where the time starts and the right corner is where the time ends. So I figure out what triangles' lower corner is positioned at 12pm\\\", \\\"block\\\": \\\"triangular_testing\\\" }, { \\\"rt\\\": 14880, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"20\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"United States of America\\\\\\\"}\\\", \\\"block\\\": \\\"demo-1\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 21, \\\"time_elapsed\\\": 568486, \\\"internal_node_id\\\": \\\"0.0-8.0\\\", \\\"subject\\\": \\\"38NFJ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"echo\\\", \\\"condition\\\": \\\"121\\\" }, { \\\"rt\\\": 8022, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"English\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"Second\\\\\\\",\\\\\\\"Q2\\\\\\\":\\\\\\\"Biomedical & Health Sciences\\\\\\\",\\\\\\\"Q3\\\\\\\":\\\\\\\"Female\\\\\\\"}\\\", \\\"block\\\": \\\"demo-2\\\", \\\"trial_type\\\": \\\"survey-multi-choice\\\", \\\"trial_index\\\": 22, \\\"time_elapsed\\\": 577528, \\\"internal_node_id\\\": \\\"0.0-9.0\\\", \\\"subject\\\": \\\"38NFJ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"echo\\\", \\\"condition\\\": \\\"121\\\" }, { \\\"rt\\\": 6612, \\\"url\\\": \\\"../views/src/external/debrief.html\\\", \\\"block\\\": \\\"debrief\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 23, \\\"time_elapsed\\\": 585477, \\\"internal_node_id\\\": \\\"0.0-10.0\\\", \\\"subject\\\": \\\"38NFJ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"echo\\\", \\\"condition\\\": \\\"121\\\" } ]\",\"parentNode\":{\"id\":2765}}],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"META\",\"attributes\":{\"charset\":\"utf-8\"}},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":8,\"id\":59},{\"nodeType\":3,\"id\":60,\"textContent\":\" \"},{\"nodeType\":1,\"id\":61,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":62,\"textContent\":\" \"},{\"nodeType\":1,\"id\":63,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":64,\"textContent\":\" \"},{\"nodeType\":1,\"id\":65,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":66,\"textContent\":\" \"},{\"nodeType\":1,\"id\":67,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":68,\"textContent\":\" \"},{\"nodeType\":1,\"id\":69,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":70,\"textContent\":\" \"},{\"nodeType\":1,\"id\":71,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":72,\"textContent\":\" \"},{\"nodeType\":1,\"id\":73,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"stimulus\"},\"childNodes\":[{\"nodeType\":3,\"id\":74,\"textContent\":\" \"},{\"nodeType\":1,\"id\":75,\"tagName\":\"P\",\"attributes\":{\"class\":\"userid\",\"id\":\"userid\"},\"childNodes\":[{\"nodeType\":3,\"id\":76,\"textContent\":\"38NFJ\"}]},{\"nodeType\":3,\"id\":77,\"textContent\":\" \"},{\"nodeType\":1,\"id\":78,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"userinput\"},\"childNodes\":[{\"nodeType\":3,\"id\":79,\"textContent\":\" \"},{\"nodeType\":8,\"id\":80},{\"nodeType\":3,\"id\":81,\"textContent\":\" \"},{\"nodeType\":1,\"id\":82,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"legend\",\"id\":\"hint-interactive\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":83,\"textContent\":\" \"},{\"nodeType\":1,\"id\":84,\"tagName\":\"P\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":85,\"textContent\":\"Hint: Hover your mouse over the data points in the graph\"}]},{\"nodeType\":3,\"id\":86,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":87,\"textContent\":\" \"},{\"nodeType\":8,\"id\":88},{\"nodeType\":3,\"id\":89,\"textContent\":\" \"},{\"nodeType\":8,\"id\":90},{\"nodeType\":3,\"id\":91,\"textContent\":\" \"},{\"nodeType\":1,\"id\":92,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"test\"},\"childNodes\":[{\"nodeType\":3,\"id\":93,\"textContent\":\" \"},{\"nodeType\":1,\"id\":94,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":95,\"textContent\":\" \"},{\"nodeType\":1,\"id\":96,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":97,\"textContent\":\"Which shift(s) start at 11 am? \"}]},{\"nodeType\":3,\"id\":98,\"textContent\":\" \"},{\"nodeType\":1,\"id\":99,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":100,\"textContent\":\" \"},{\"nodeType\":1,\"id\":101,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":102,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":103,\"textContent\":\" \"},{\"nodeType\":1,\"id\":104,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":105,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":106,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":107,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":108,\"textContent\":\" \"},{\"nodeType\":1,\"id\":109,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":110,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":111,\"textContent\":\" \"},{\"nodeType\":1,\"id\":112,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":113,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":115,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":116,\"textContent\":\" \"},{\"nodeType\":1,\"id\":117,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":118,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":120,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":121,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":122,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":123,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":125,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":126,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":127,\"textContent\":\" \"},{\"nodeType\":1,\"id\":128,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":129,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":130,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":132,\"textContent\":\" \"},{\"nodeType\":1,\"id\":133,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":134,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":135,\"textContent\":\" \"},{\"nodeType\":1,\"id\":136,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":137,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":138,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":140,\"textContent\":\" \"},{\"nodeType\":1,\"id\":141,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":142,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":143,\"textContent\":\" \"},{\"nodeType\":1,\"id\":144,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":145,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":146,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":147,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":148,\"textContent\":\" \"},{\"nodeType\":1,\"id\":149,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":150,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":151,\"textContent\":\" \"},{\"nodeType\":1,\"id\":152,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":153,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":154,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":156,\"textContent\":\" \"},{\"nodeType\":1,\"id\":157,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":158,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":159,\"textContent\":\" \"},{\"nodeType\":1,\"id\":160,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":161,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":162,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":163,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":164,\"textContent\":\" \"},{\"nodeType\":1,\"id\":165,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":166,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":167,\"textContent\":\" \"},{\"nodeType\":1,\"id\":168,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":169,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":170,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":171,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":172,\"textContent\":\" \"},{\"nodeType\":1,\"id\":173,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":174,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":175,\"textContent\":\" \"},{\"nodeType\":1,\"id\":176,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":177,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":178,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":179,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":180,\"textContent\":\" \"},{\"nodeType\":1,\"id\":181,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":182,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":183,\"textContent\":\" \"},{\"nodeType\":1,\"id\":184,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":185,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":186,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":187,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":188,\"textContent\":\" \"},{\"nodeType\":1,\"id\":189,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":190,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":191,\"textContent\":\" \"},{\"nodeType\":1,\"id\":192,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":193,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":194,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":196,\"textContent\":\" \"},{\"nodeType\":1,\"id\":197,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":198,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":200,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":201,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":202,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":203,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":205,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":206,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":207,\"textContent\":\" \"},{\"nodeType\":1,\"id\":208,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":209,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":210,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":211,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":212,\"textContent\":\" \"},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":214,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":215,\"textContent\":\" \"},{\"nodeType\":1,\"id\":216,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":217,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":218,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":219,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":220,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":221,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":223,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":224,\"textContent\":\" \"},{\"nodeType\":1,\"id\":225,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":226,\"textContent\":\"Which shift(s) start at the same time as D?\"}]},{\"nodeType\":3,\"id\":227,\"textContent\":\" \"},{\"nodeType\":1,\"id\":228,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":229,\"textContent\":\" \"},{\"nodeType\":1,\"id\":230,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":231,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":232,\"textContent\":\" \"},{\"nodeType\":1,\"id\":233,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":234,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":235,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":236,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":237,\"textContent\":\" \"},{\"nodeType\":1,\"id\":238,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":239,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":240,\"textContent\":\" \"},{\"nodeType\":1,\"id\":241,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":242,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":243,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":244,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":245,\"textContent\":\" \"},{\"nodeType\":1,\"id\":246,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":247,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":248,\"textContent\":\" \"},{\"nodeType\":1,\"id\":249,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":250,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":251,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":252,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":253,\"textContent\":\" \"},{\"nodeType\":1,\"id\":254,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":255,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":256,\"textContent\":\" \"},{\"nodeType\":1,\"id\":257,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":258,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":259,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":260,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":261,\"textContent\":\" \"},{\"nodeType\":1,\"id\":262,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":263,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":264,\"textContent\":\" \"},{\"nodeType\":1,\"id\":265,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":266,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":267,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":268,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":269,\"textContent\":\" \"},{\"nodeType\":1,\"id\":270,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":271,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":273,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":274,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":275,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":276,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":278,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":279,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":280,\"textContent\":\" \"},{\"nodeType\":1,\"id\":281,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":282,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":283,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":284,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":286,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":287,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":288,\"textContent\":\" \"},{\"nodeType\":1,\"id\":289,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":290,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":291,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":292,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":293,\"textContent\":\" \"},{\"nodeType\":1,\"id\":294,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":295,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":296,\"textContent\":\" \"},{\"nodeType\":1,\"id\":297,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":298,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":299,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":300,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":301,\"textContent\":\" \"},{\"nodeType\":1,\"id\":302,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":303,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":304,\"textContent\":\" \"},{\"nodeType\":1,\"id\":305,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":306,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":307,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":308,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":309,\"textContent\":\" \"},{\"nodeType\":1,\"id\":310,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":311,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":312,\"textContent\":\" \"},{\"nodeType\":1,\"id\":313,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":314,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":315,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":316,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":317,\"textContent\":\" \"},{\"nodeType\":1,\"id\":318,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":319,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":320,\"textContent\":\" \"},{\"nodeType\":1,\"id\":321,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":322,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":323,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":324,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":325,\"textContent\":\" \"},{\"nodeType\":1,\"id\":326,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":327,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":328,\"textContent\":\" \"},{\"nodeType\":1,\"id\":329,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":330,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":331,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":332,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":333,\"textContent\":\" \"},{\"nodeType\":1,\"id\":334,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":335,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":336,\"textContent\":\" \"},{\"nodeType\":1,\"id\":337,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":338,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":339,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":340,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":341,\"textContent\":\" \"},{\"nodeType\":1,\"id\":342,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":343,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":344,\"textContent\":\" \"},{\"nodeType\":1,\"id\":345,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":346,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":347,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":348,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":349,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":351,\"textContent\":\" \"},{\"nodeType\":1,\"id\":352,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":353,\"textContent\":\" \"},{\"nodeType\":1,\"id\":354,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":355,\"textContent\":\"Which shift(s) begin when C ends?\"}]},{\"nodeType\":3,\"id\":356,\"textContent\":\" \"},{\"nodeType\":1,\"id\":357,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":358,\"textContent\":\" \"},{\"nodeType\":1,\"id\":359,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":360,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":361,\"textContent\":\" \"},{\"nodeType\":1,\"id\":362,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":363,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":364,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":365,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":366,\"textContent\":\" \"},{\"nodeType\":1,\"id\":367,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":368,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":369,\"textContent\":\" \"},{\"nodeType\":1,\"id\":370,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":371,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":372,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":373,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":374,\"textContent\":\" \"},{\"nodeType\":1,\"id\":375,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":376,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":377,\"textContent\":\" \"},{\"nodeType\":1,\"id\":378,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":379,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":380,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":381,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":382,\"textContent\":\" \"},{\"nodeType\":1,\"id\":383,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":384,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":385,\"textContent\":\" \"},{\"nodeType\":1,\"id\":386,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":387,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":388,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":389,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":390,\"textContent\":\" \"},{\"nodeType\":1,\"id\":391,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":392,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":393,\"textContent\":\" \"},{\"nodeType\":1,\"id\":394,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":395,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":396,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":397,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":398,\"textContent\":\" \"},{\"nodeType\":1,\"id\":399,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":400,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":401,\"textContent\":\" \"},{\"nodeType\":1,\"id\":402,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":403,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":404,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":405,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":406,\"textContent\":\" \"},{\"nodeType\":1,\"id\":407,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":408,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":409,\"textContent\":\" \"},{\"nodeType\":1,\"id\":410,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":411,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":412,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":413,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":414,\"textContent\":\" \"},{\"nodeType\":1,\"id\":415,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":416,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":417,\"textContent\":\" \"},{\"nodeType\":1,\"id\":418,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":419,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":420,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":421,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":422,\"textContent\":\" \"},{\"nodeType\":1,\"id\":423,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":424,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":425,\"textContent\":\" \"},{\"nodeType\":1,\"id\":426,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":427,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":428,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":429,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":430,\"textContent\":\" \"},{\"nodeType\":1,\"id\":431,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":432,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":433,\"textContent\":\" \"},{\"nodeType\":1,\"id\":434,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":435,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":436,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":437,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":438,\"textContent\":\" \"},{\"nodeType\":1,\"id\":439,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":440,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":441,\"textContent\":\" \"},{\"nodeType\":1,\"id\":442,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":443,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":444,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":445,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":446,\"textContent\":\" \"},{\"nodeType\":1,\"id\":447,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":448,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":449,\"textContent\":\" \"},{\"nodeType\":1,\"id\":450,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":451,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":452,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":453,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":454,\"textContent\":\" \"},{\"nodeType\":1,\"id\":455,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":456,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":457,\"textContent\":\" \"},{\"nodeType\":1,\"id\":458,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":459,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":460,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":461,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":462,\"textContent\":\" \"},{\"nodeType\":1,\"id\":463,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":464,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":465,\"textContent\":\" \"},{\"nodeType\":1,\"id\":466,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":467,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":468,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":469,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":470,\"textContent\":\" \"},{\"nodeType\":1,\"id\":471,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":472,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":473,\"textContent\":\" \"},{\"nodeType\":1,\"id\":474,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":475,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":476,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":477,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":478,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":479,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":480,\"textContent\":\" \"},{\"nodeType\":1,\"id\":481,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":483,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":484,\"textContent\":\" Which shift(s) end at 4 pm?\"}]},{\"nodeType\":3,\"id\":485,\"textContent\":\" \"},{\"nodeType\":1,\"id\":486,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":492,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":500,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":503,\"textContent\":\" \"},{\"nodeType\":1,\"id\":504,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":505,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":506,\"textContent\":\" \"},{\"nodeType\":1,\"id\":507,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":508,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":509,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":510,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":511,\"textContent\":\" \"},{\"nodeType\":1,\"id\":512,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":513,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":514,\"textContent\":\" \"},{\"nodeType\":1,\"id\":515,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":516,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":517,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":518,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":519,\"textContent\":\" \"},{\"nodeType\":1,\"id\":520,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":521,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":522,\"textContent\":\" \"},{\"nodeType\":1,\"id\":523,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":524,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":525,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":526,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":527,\"textContent\":\" \"},{\"nodeType\":1,\"id\":528,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":529,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":530,\"textContent\":\" \"},{\"nodeType\":1,\"id\":531,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":532,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":533,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":534,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":535,\"textContent\":\" \"},{\"nodeType\":1,\"id\":536,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":537,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":538,\"textContent\":\" \"},{\"nodeType\":1,\"id\":539,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":540,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":541,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":542,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":543,\"textContent\":\" \"},{\"nodeType\":1,\"id\":544,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":545,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":546,\"textContent\":\" \"},{\"nodeType\":1,\"id\":547,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":548,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":549,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":550,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":551,\"textContent\":\" \"},{\"nodeType\":1,\"id\":552,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":553,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":554,\"textContent\":\" \"},{\"nodeType\":1,\"id\":555,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":556,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":557,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":558,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":559,\"textContent\":\" \"},{\"nodeType\":1,\"id\":560,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":561,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":562,\"textContent\":\" \"},{\"nodeType\":1,\"id\":563,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":564,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":565,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":566,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":567,\"textContent\":\" \"},{\"nodeType\":1,\"id\":568,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":569,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":570,\"textContent\":\" \"},{\"nodeType\":1,\"id\":571,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":572,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":573,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":574,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":575,\"textContent\":\" \"},{\"nodeType\":1,\"id\":576,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":577,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":578,\"textContent\":\" \"},{\"nodeType\":1,\"id\":579,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":580,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":581,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":582,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":583,\"textContent\":\" \"},{\"nodeType\":1,\"id\":584,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":585,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":586,\"textContent\":\" \"},{\"nodeType\":1,\"id\":587,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":588,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":589,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":590,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":592,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":593,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":594,\"textContent\":\" \"},{\"nodeType\":1,\"id\":595,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":596,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":597,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":598,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":599,\"textContent\":\" \"},{\"nodeType\":1,\"id\":600,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":601,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":602,\"textContent\":\" \"},{\"nodeType\":1,\"id\":603,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":604,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":605,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":606,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":607,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":608,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":609,\"textContent\":\" \"},{\"nodeType\":1,\"id\":610,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":612,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":613,\"textContent\":\"Coffee breaks happen halfway through a shift.\"},{\"nodeType\":1,\"id\":614,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":615,\"textContent\":\" Which shift(s) share a break with I?\"}]},{\"nodeType\":3,\"id\":616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":617,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":618,\"textContent\":\" \"},{\"nodeType\":1,\"id\":619,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":620,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":621,\"textContent\":\" \"},{\"nodeType\":1,\"id\":622,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":623,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":624,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":625,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":626,\"textContent\":\" \"},{\"nodeType\":1,\"id\":627,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":628,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":629,\"textContent\":\" \"},{\"nodeType\":1,\"id\":630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":631,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":632,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":633,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":634,\"textContent\":\" \"},{\"nodeType\":1,\"id\":635,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":636,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":637,\"textContent\":\" \"},{\"nodeType\":1,\"id\":638,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":639,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":640,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":641,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":642,\"textContent\":\" \"},{\"nodeType\":1,\"id\":643,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":644,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":645,\"textContent\":\" \"},{\"nodeType\":1,\"id\":646,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":647,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":648,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":649,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":650,\"textContent\":\" \"},{\"nodeType\":1,\"id\":651,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":653,\"textContent\":\" \"},{\"nodeType\":1,\"id\":654,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":655,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":656,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":657,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":659,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":660,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":661,\"textContent\":\" \"},{\"nodeType\":1,\"id\":662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":663,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":664,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":665,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":666,\"textContent\":\" \"},{\"nodeType\":1,\"id\":667,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":668,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":669,\"textContent\":\" \"},{\"nodeType\":1,\"id\":670,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":671,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":672,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":673,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":674,\"textContent\":\" \"},{\"nodeType\":1,\"id\":675,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":676,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":677,\"textContent\":\" \"},{\"nodeType\":1,\"id\":678,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":679,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":680,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":681,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":682,\"textContent\":\" \"},{\"nodeType\":1,\"id\":683,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":685,\"textContent\":\" \"},{\"nodeType\":1,\"id\":686,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":687,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":688,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":689,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":690,\"textContent\":\" \"},{\"nodeType\":1,\"id\":691,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":692,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":693,\"textContent\":\" \"},{\"nodeType\":1,\"id\":694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":695,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":696,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":697,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":698,\"textContent\":\" \"},{\"nodeType\":1,\"id\":699,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":700,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":701,\"textContent\":\" \"},{\"nodeType\":1,\"id\":702,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":703,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":704,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":705,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":706,\"textContent\":\" \"},{\"nodeType\":1,\"id\":707,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":708,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":709,\"textContent\":\" \"},{\"nodeType\":1,\"id\":710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":711,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":712,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":713,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":714,\"textContent\":\" \"},{\"nodeType\":1,\"id\":715,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":716,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":717,\"textContent\":\" \"},{\"nodeType\":1,\"id\":718,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":719,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":720,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":721,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":722,\"textContent\":\" \"},{\"nodeType\":1,\"id\":723,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":724,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":725,\"textContent\":\" \"},{\"nodeType\":1,\"id\":726,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":727,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":728,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":729,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":730,\"textContent\":\" \"},{\"nodeType\":1,\"id\":731,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":732,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":733,\"textContent\":\" \"},{\"nodeType\":1,\"id\":734,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":735,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":736,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":737,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":738,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":739,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":741,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":742,\"textContent\":\" \"},{\"nodeType\":1,\"id\":743,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":744,\"textContent\":\"Which shift(s) are six hours long?\"}]},{\"nodeType\":3,\"id\":745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":746,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":747,\"textContent\":\" \"},{\"nodeType\":1,\"id\":748,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":749,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":750,\"textContent\":\" \"},{\"nodeType\":1,\"id\":751,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":752,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":753,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":754,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":755,\"textContent\":\" \"},{\"nodeType\":1,\"id\":756,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":757,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":758,\"textContent\":\" \"},{\"nodeType\":1,\"id\":759,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":760,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":761,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":762,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":763,\"textContent\":\" \"},{\"nodeType\":1,\"id\":764,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":765,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":766,\"textContent\":\" \"},{\"nodeType\":1,\"id\":767,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":768,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":769,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":770,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":771,\"textContent\":\" \"},{\"nodeType\":1,\"id\":772,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":773,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":774,\"textContent\":\" \"},{\"nodeType\":1,\"id\":775,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":776,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":777,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":778,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":779,\"textContent\":\" \"},{\"nodeType\":1,\"id\":780,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":781,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":782,\"textContent\":\" \"},{\"nodeType\":1,\"id\":783,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":784,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":785,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":786,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":787,\"textContent\":\" \"},{\"nodeType\":1,\"id\":788,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":789,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":790,\"textContent\":\" \"},{\"nodeType\":1,\"id\":791,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":792,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":793,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":794,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":795,\"textContent\":\" \"},{\"nodeType\":1,\"id\":796,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":797,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":798,\"textContent\":\" \"},{\"nodeType\":1,\"id\":799,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":800,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":801,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":802,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":803,\"textContent\":\" \"},{\"nodeType\":1,\"id\":804,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":805,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":806,\"textContent\":\" \"},{\"nodeType\":1,\"id\":807,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":808,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":809,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":810,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":812,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":813,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":814,\"textContent\":\" \"},{\"nodeType\":1,\"id\":815,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":816,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":817,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":818,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":819,\"textContent\":\" \"},{\"nodeType\":1,\"id\":820,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":821,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":822,\"textContent\":\" \"},{\"nodeType\":1,\"id\":823,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":824,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":825,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":826,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":827,\"textContent\":\" \"},{\"nodeType\":1,\"id\":828,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":829,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":830,\"textContent\":\" \"},{\"nodeType\":1,\"id\":831,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":832,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":833,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":834,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":835,\"textContent\":\" \"},{\"nodeType\":1,\"id\":836,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":837,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":838,\"textContent\":\" \"},{\"nodeType\":1,\"id\":839,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":840,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":841,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":842,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":843,\"textContent\":\" \"},{\"nodeType\":1,\"id\":844,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":845,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":846,\"textContent\":\" \"},{\"nodeType\":1,\"id\":847,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":848,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":849,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":850,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":851,\"textContent\":\" \"},{\"nodeType\":1,\"id\":852,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":853,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":854,\"textContent\":\" \"},{\"nodeType\":1,\"id\":855,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":856,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":857,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":858,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":859,\"textContent\":\" \"},{\"nodeType\":1,\"id\":860,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":861,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":862,\"textContent\":\" \"},{\"nodeType\":1,\"id\":863,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":864,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":865,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":866,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":867,\"textContent\":\" \"},{\"nodeType\":1,\"id\":868,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":869,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":870,\"textContent\":\" \"},{\"nodeType\":1,\"id\":871,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":872,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":873,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":874,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":875,\"textContent\":\" \"},{\"nodeType\":1,\"id\":876,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":877,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":878,\"textContent\":\" \"},{\"nodeType\":1,\"id\":879,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":880,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":881,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":882,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":883,\"textContent\":\" \"},{\"nodeType\":1,\"id\":884,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":885,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":886,\"textContent\":\" \"},{\"nodeType\":1,\"id\":887,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":888,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":889,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":890,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":891,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":892,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":894,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":895,\"textContent\":\" \"},{\"nodeType\":1,\"id\":896,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":897,\"textContent\":\"Which 2 shifts less than 5 hours long start at the same time?\"}]},{\"nodeType\":3,\"id\":898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":899,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":900,\"textContent\":\" \"},{\"nodeType\":1,\"id\":901,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":902,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":903,\"textContent\":\" \"},{\"nodeType\":1,\"id\":904,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":905,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":906,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":907,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":908,\"textContent\":\" \"},{\"nodeType\":1,\"id\":909,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":910,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":911,\"textContent\":\" \"},{\"nodeType\":1,\"id\":912,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":913,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":914,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":915,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":916,\"textContent\":\" \"},{\"nodeType\":1,\"id\":917,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":918,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":919,\"textContent\":\" \"},{\"nodeType\":1,\"id\":920,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":921,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":922,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":923,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":924,\"textContent\":\" \"},{\"nodeType\":1,\"id\":925,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":926,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":927,\"textContent\":\" \"},{\"nodeType\":1,\"id\":928,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":929,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":930,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":931,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":932,\"textContent\":\" \"},{\"nodeType\":1,\"id\":933,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":934,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":935,\"textContent\":\" \"},{\"nodeType\":1,\"id\":936,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":937,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":938,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":939,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":940,\"textContent\":\" \"},{\"nodeType\":1,\"id\":941,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":942,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":943,\"textContent\":\" \"},{\"nodeType\":1,\"id\":944,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":945,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":946,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":947,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":948,\"textContent\":\" \"},{\"nodeType\":1,\"id\":949,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":950,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":951,\"textContent\":\" \"},{\"nodeType\":1,\"id\":952,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":953,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":954,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":955,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":956,\"textContent\":\" \"},{\"nodeType\":1,\"id\":957,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":958,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":959,\"textContent\":\" \"},{\"nodeType\":1,\"id\":960,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":961,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":962,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":963,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":965,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":966,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":967,\"textContent\":\" \"},{\"nodeType\":1,\"id\":968,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":969,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":970,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":971,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":972,\"textContent\":\" \"},{\"nodeType\":1,\"id\":973,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":974,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":975,\"textContent\":\" \"},{\"nodeType\":1,\"id\":976,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":977,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":978,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":979,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":980,\"textContent\":\" \"},{\"nodeType\":1,\"id\":981,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":982,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":983,\"textContent\":\" \"},{\"nodeType\":1,\"id\":984,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":985,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":986,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":987,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":988,\"textContent\":\" \"},{\"nodeType\":1,\"id\":989,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":990,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":991,\"textContent\":\" \"},{\"nodeType\":1,\"id\":992,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":993,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":994,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":995,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":996,\"textContent\":\" \"},{\"nodeType\":1,\"id\":997,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":998,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":999,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1000,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1001,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1002,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1003,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1004,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1005,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1006,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1007,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1008,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1009,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1010,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1011,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1012,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1013,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1014,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1015,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1016,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1017,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1018,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1019,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1020,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1021,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1022,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1023,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1024,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1025,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1026,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1027,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1028,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1029,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1030,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1031,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1032,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1033,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1034,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1035,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1036,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1037,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1038,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1039,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1040,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1041,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1042,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1043,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1044,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1045,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1047,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+contained\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1048,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1049,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1050,\"textContent\":\"Which shift(s) under 7 hours long starts before B starts, and ends after X ends?\"}]},{\"nodeType\":3,\"id\":1051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1052,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1053,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1054,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1055,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1056,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1057,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1058,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1059,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1060,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1061,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1062,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1063,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1064,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1065,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1066,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1067,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1068,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1069,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1070,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1071,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1072,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1073,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1074,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1075,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1076,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1077,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1078,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1079,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1080,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1081,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1082,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1083,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1084,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1085,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1086,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1087,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1088,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1089,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1090,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1091,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1092,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1093,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1094,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1095,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1096,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1097,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1098,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1099,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1100,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1101,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1102,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1103,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1104,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1105,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1106,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1107,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1108,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1109,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1110,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1111,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1112,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1113,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1114,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1115,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1116,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1118,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1119,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1120,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1121,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1122,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1123,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1124,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1125,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1126,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1127,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1128,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1129,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1130,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1131,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1132,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1133,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1134,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1135,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1136,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1137,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1138,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1139,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1140,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1141,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1142,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1143,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1144,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1145,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1146,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1147,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1148,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1149,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1150,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1151,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1152,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1153,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1154,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1155,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1156,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1157,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1158,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1159,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1160,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1161,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1162,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1163,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1164,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1165,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1166,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1167,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1168,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1169,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1170,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1171,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1172,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1173,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1174,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1175,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1176,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1177,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1178,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1179,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1180,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1181,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1182,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1183,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1184,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1185,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1186,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1187,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1188,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1189,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1190,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1191,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1192,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1193,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1194,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1195,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1196,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1197,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1198,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1200,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime+before+endtime+during\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1202,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1203,\"textContent\":\"Which shift(s) begins before J begins and ends during B?\"}]},{\"nodeType\":3,\"id\":1204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1205,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1211,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1219,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1227,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1235,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1243,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1251,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1259,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1267,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1270,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1271,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1272,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1273,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1274,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1275,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1276,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1277,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1278,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1279,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1280,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1281,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1282,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1283,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1284,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1285,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1286,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1287,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1288,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1289,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1290,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1291,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1292,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1293,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1294,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1295,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1296,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1298,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1299,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1300,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1301,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1302,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1303,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1304,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1305,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1306,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1307,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1308,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1309,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1310,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1311,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1312,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1313,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1314,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1315,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1316,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1317,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1318,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1319,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1320,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1321,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1322,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1323,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1324,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1325,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1326,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1327,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1328,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1329,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1330,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1331,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1332,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1333,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1334,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1335,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1336,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1337,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1338,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1339,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1340,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1341,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1342,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1343,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1344,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1345,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1346,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1347,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1348,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1349,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1351,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1352,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1353,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.ends\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1354,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1355,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1356,\"textContent\":\"Which shift(s) end at the same time as F?\"}]},{\"nodeType\":3,\"id\":1357,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1358,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1359,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1360,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1361,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1362,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1363,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1364,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1365,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1366,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1367,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1368,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1369,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1370,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1371,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1372,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1373,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1374,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1375,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1376,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1377,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1378,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1379,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1380,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1381,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1382,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1383,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1384,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1385,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1386,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1387,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1388,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1389,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1390,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1391,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1392,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1393,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1394,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1395,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1396,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1397,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1398,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1399,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1400,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1401,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1402,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1403,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1404,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1405,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1406,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1407,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1408,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1409,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1410,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1411,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1412,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1413,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1414,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1415,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1416,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1417,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1418,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1419,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1420,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1421,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1422,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1423,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1424,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1425,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1426,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1427,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1428,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1429,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1430,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1431,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1432,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1433,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1434,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1435,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1436,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1437,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1438,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1439,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1440,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1441,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1442,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1443,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1444,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1445,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1446,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1447,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1448,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1449,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1450,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1451,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1452,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1453,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1454,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1455,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1456,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1457,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1458,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1459,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1460,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1461,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1462,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1463,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1464,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1465,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1466,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1467,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1468,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1469,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1470,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1471,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1472,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1473,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1474,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1475,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1476,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1477,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1478,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1479,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1480,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1481,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1483,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1484,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1485,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1486,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1492,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1500,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1503,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1504,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1505,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1506,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1507,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1508,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1509,\"textContent\":\"Which shift(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":1510,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1511,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1512,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1513,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1514,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1515,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1516,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1517,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1518,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1519,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1520,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1521,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1522,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1523,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1524,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1525,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1526,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1527,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1528,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1529,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1530,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1531,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1532,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1533,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1534,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1535,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1536,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1537,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1538,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1539,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1540,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1541,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1542,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1543,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1544,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1545,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1546,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1547,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1548,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1549,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1550,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1551,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1552,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1553,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1554,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1555,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1556,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1557,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1558,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1559,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1560,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1561,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1562,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1563,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1564,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1565,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1566,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1567,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1568,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1569,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1570,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1571,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1572,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1573,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1574,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1575,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1576,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1577,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1578,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1579,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1580,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1581,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1582,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1583,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1584,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1585,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1586,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1587,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1588,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1589,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1590,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1591,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1592,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1593,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1594,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1595,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1596,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1597,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1598,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1599,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1600,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1601,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1602,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1603,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1604,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1605,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1606,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1607,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1608,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1609,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1610,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1612,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1613,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1614,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1615,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1617,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1618,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1619,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1620,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1621,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1622,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1623,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1624,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1625,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1627,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1628,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1629,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1630,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1631,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1632,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1633,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1634,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1635,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1636,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1637,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1638,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1639,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1640,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1641,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1642,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1643,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1644,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1645,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1646,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1647,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1648,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1649,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1650,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1651,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1652,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1653,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1654,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1655,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1656,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1657,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1659,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1660,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1661,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1662,\"textContent\":\"Which shift(s) start at the same time as F?\"}]},{\"nodeType\":3,\"id\":1663,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1664,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1665,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1666,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1667,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1668,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1669,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1670,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1671,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1672,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1673,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1674,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1675,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1676,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1677,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1678,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1679,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1680,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1681,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1682,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1683,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1684,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1686,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1687,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1688,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1689,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1690,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1691,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1692,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1693,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1694,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1695,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1696,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1697,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1698,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1699,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1700,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1701,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1702,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1703,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1704,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1705,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1706,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1707,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1708,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1709,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1710,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1711,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1712,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1713,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1714,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1715,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1716,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1717,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1718,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1720,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1721,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1722,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1723,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1724,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1725,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1726,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1727,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1728,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1729,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1730,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1731,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1732,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1733,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1734,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1735,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1736,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1737,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1738,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1739,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1741,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1742,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1743,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1744,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1746,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1747,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1748,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1749,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1750,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1751,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1752,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1753,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1754,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1755,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1756,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1757,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1758,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1759,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1760,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1761,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1762,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1763,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1764,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1765,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1766,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1767,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1768,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1769,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1770,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1771,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1772,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1773,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1774,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1775,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1776,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1777,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1778,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1779,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1780,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1781,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1782,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1783,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1784,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1785,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1786,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1787,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1788,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1789,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1790,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1791,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1792,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1793,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1794,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1795,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1796,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1797,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1798,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1799,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1800,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1801,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1802,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1803,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1804,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1805,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1806,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1807,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1808,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1809,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1810,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1812,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1813,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1814,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1815,\"textContent\":\"Which 2 shifts end when Z begins?\"}]},{\"nodeType\":3,\"id\":1816,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1817,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1818,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1819,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1820,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1821,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1822,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1823,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1824,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1825,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1826,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1827,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1828,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1829,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1830,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1831,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1832,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1833,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1834,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1835,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1836,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1837,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1838,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1839,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1840,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1841,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1842,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1843,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1844,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1845,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1846,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1847,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1848,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1849,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1850,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1851,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1852,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1853,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1854,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1855,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1856,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1857,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1858,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1859,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1860,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1861,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1862,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1863,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1864,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1865,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1866,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1867,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1868,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1869,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1870,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1871,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1872,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1873,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1874,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1875,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1876,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1877,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1878,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1879,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1880,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1881,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1882,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1883,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1884,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1885,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1886,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1887,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1888,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1889,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1890,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1891,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1892,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1894,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1895,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1896,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1897,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1899,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1900,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1901,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1902,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1903,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1904,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1905,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1906,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1907,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1908,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1909,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1910,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1911,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1912,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1913,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1914,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1915,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1916,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1917,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1918,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1919,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1920,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1921,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1922,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1923,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1924,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1925,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1926,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1927,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1928,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1929,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1930,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1931,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1932,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1933,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1934,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1935,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1936,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1937,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1938,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1939,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1940,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1941,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1942,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1943,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1944,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1945,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1946,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1947,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1948,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1949,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1950,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1951,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1952,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1953,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1954,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1955,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1956,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1957,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1958,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1959,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1960,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1961,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1962,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1963,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1965,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1966,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1967,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1968,\"textContent\":\"Which shift(s) end at 3pm?\"}]},{\"nodeType\":3,\"id\":1969,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1970,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1971,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1972,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1973,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1974,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1975,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1976,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1977,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1978,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1979,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1980,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1981,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1982,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1983,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1984,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1985,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1986,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1987,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1988,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1989,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1990,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1991,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1992,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1993,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1994,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1995,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1996,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1997,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1998,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1999,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2000,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2001,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2002,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2003,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2004,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2005,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2006,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2007,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2008,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2009,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2010,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2011,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2012,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2013,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2014,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2015,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2016,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2017,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2018,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2019,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2020,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2021,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2022,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2023,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2024,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2025,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2026,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2027,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2028,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2029,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2030,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2031,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2032,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2033,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2034,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2035,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2036,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2037,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2038,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2039,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2040,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2041,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2042,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2043,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2044,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2045,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2047,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2048,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2049,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2050,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2052,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2053,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2054,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2055,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2056,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2057,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2058,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2059,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2060,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2061,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2062,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2063,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2064,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2065,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2066,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2067,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2068,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2069,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2070,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2071,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2072,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2073,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2074,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2075,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2076,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2077,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2078,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2079,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2080,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2081,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2082,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2083,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2084,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2085,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2086,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2087,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2088,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2089,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2090,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2091,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2092,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2093,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2094,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2095,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2096,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2097,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2098,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2099,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2100,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2101,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2102,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2103,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2104,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2105,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2106,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2107,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2108,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2109,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2110,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2111,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2112,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2113,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2114,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2115,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2116,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2118,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":2119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2120,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2121,\"textContent\":\"Coffee breaks happen halfway through a shift. \"},{\"nodeType\":1,\"id\":2122,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":2123,\"textContent\":\"Which shifts share a break at 2pm?\"}]},{\"nodeType\":3,\"id\":2124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2125,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":2126,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2127,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2128,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2129,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2130,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2131,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":2132,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2133,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2134,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2135,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2136,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2137,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2138,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2139,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":2140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2141,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2142,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2143,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2144,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2145,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2146,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2147,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":2148,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2149,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2150,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2151,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2152,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2153,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2154,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2155,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2156,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2157,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2158,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2159,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2160,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2161,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2162,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2163,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2164,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2165,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2166,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2167,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2168,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2169,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2170,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2171,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2172,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2173,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2174,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2175,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2176,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2177,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2178,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2179,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2180,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2181,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2182,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2183,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2184,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2185,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2186,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2187,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2188,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2189,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2190,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2191,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2192,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2193,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2194,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2195,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2196,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2197,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2198,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2199,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2200,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2202,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2203,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2204,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2205,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2211,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2219,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2227,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2235,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2243,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2251,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2259,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2267,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2270,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2271,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2273,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\".strategy\",\"style\":\"display: block;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2274,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2275,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2276,\"textContent\":\"Please describe how to determine what event(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":2277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2278,\"tagName\":\"TEXTAREA\",\"attributes\":{\"id\":\"strategyAnswer\",\"rows\":\"5\",\"cols\":\"80\"}},{\"nodeType\":3,\"id\":2279,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2280,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2281,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2282},{\"nodeType\":3,\"id\":2283,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2284},{\"nodeType\":3,\"id\":2285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2286,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"fixbottom\"},\"childNodes\":[{\"nodeType\":3,\"id\":2287,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2288,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"testingButton\",\"style\":\"display:none;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2289,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2290,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2291,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"strategyButton\",\"style\":\"display: block;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2292,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2293,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2294,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2295,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2296},{\"nodeType\":3,\"id\":2297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2298,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"d3container\"},\"childNodes\":[{\"nodeType\":1,\"id\":2299,\"tagName\":\"svg\",\"attributes\":{\"width\":\"930\",\"height\":\"915\"},\"childNodes\":[{\"nodeType\":1,\"id\":2300,\"tagName\":\"g\",\"attributes\":{\"transform\":\"translate(100,25)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2301,\"tagName\":\"g\",\"attributes\":{\"class\":\"leaders\"}},{\"nodeType\":1,\"id\":2302,\"tagName\":\"g\",\"attributes\":{\"class\":\"static-scaffold\"}},{\"nodeType\":1,\"id\":2303,\"tagName\":\"g\",\"attributes\":{\"class\":\"xaxis\",\"transform\":\"translate(0,800)\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"middle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2304,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M0.5,6V0.5H800.5V6\"}},{\"nodeType\":1,\"id\":2305,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2306,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2307,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2308,\"textContent\":\"08 AM\"}]}]},{\"nodeType\":1,\"id\":2309,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(33.83333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2310,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2311,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2312,\"textContent\":\"08:30\"}]}]},{\"nodeType\":1,\"id\":2313,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(67.16666666666666,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2314,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2315,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2316,\"textContent\":\"09 AM\"}]}]},{\"nodeType\":1,\"id\":2317,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(100.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2318,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2319,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2320,\"textContent\":\"09:30\"}]}]},{\"nodeType\":1,\"id\":2321,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(133.83333333333331,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2322,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2323,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2324,\"textContent\":\"10 AM\"}]}]},{\"nodeType\":1,\"id\":2325,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(167.16666666666669,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2326,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2327,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2328,\"textContent\":\"10:30\"}]}]},{\"nodeType\":1,\"id\":2329,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(200.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2330,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2331,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2332,\"textContent\":\"11 AM\"}]}]},{\"nodeType\":1,\"id\":2333,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(233.83333333333334,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2334,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2335,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2336,\"textContent\":\"11:30\"}]}]},{\"nodeType\":1,\"id\":2337,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(267.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2338,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2339,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2340,\"textContent\":\"12 PM\"}]}]},{\"nodeType\":1,\"id\":2341,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(300.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2342,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2343,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2344,\"textContent\":\"12:30\"}]}]},{\"nodeType\":1,\"id\":2345,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(333.83333333333337,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2346,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2347,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2348,\"textContent\":\"01 PM\"}]}]},{\"nodeType\":1,\"id\":2349,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(367.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2350,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2351,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2352,\"textContent\":\"01:30\"}]}]},{\"nodeType\":1,\"id\":2353,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(400.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2354,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2355,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2356,\"textContent\":\"02 PM\"}]}]},{\"nodeType\":1,\"id\":2357,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(433.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2358,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2359,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2360,\"textContent\":\"02:30\"}]}]},{\"nodeType\":1,\"id\":2361,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(467.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2362,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2363,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2364,\"textContent\":\"03 PM\"}]}]},{\"nodeType\":1,\"id\":2365,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(500.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2366,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2367,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2368,\"textContent\":\"03:30\"}]}]},{\"nodeType\":1,\"id\":2369,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(533.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2370,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2371,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2372,\"textContent\":\"04 PM\"}]}]},{\"nodeType\":1,\"id\":2373,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(567.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2374,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2375,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2376,\"textContent\":\"04:30\"}]}]},{\"nodeType\":1,\"id\":2377,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(600.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2378,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2379,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2380,\"textContent\":\"05 PM\"}]}]},{\"nodeType\":1,\"id\":2381,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(633.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2382,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2383,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2384,\"textContent\":\"05:30\"}]}]},{\"nodeType\":1,\"id\":2385,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(667.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2386,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2387,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2388,\"textContent\":\"06 PM\"}]}]},{\"nodeType\":1,\"id\":2389,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(700.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2390,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2391,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2392,\"textContent\":\"06:30\"}]}]},{\"nodeType\":1,\"id\":2393,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(733.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2394,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2395,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2396,\"textContent\":\"07 PM\"}]}]},{\"nodeType\":1,\"id\":2397,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(767.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2398,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2399,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2400,\"textContent\":\"07:30\"}]}]},{\"nodeType\":1,\"id\":2401,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(800.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2402,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2403,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2404,\"textContent\":\"08 PM\"}]}]},{\"nodeType\":1,\"id\":2405,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2406,\"tagName\":\"text\",\"attributes\":{\"x\":\"533.3333333333334\",\"y\":\"80\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2407,\"textContent\":\"START & END TIME (time of day)\"}]}]}]},{\"nodeType\":1,\"id\":2408,\"tagName\":\"g\",\"attributes\":{\"class\":\"yaxis\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"end\"},\"childNodes\":[{\"nodeType\":1,\"id\":2409,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M-15,800.5H0.5V0.5H-15\"}},{\"nodeType\":1,\"id\":2410,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,800.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2411,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2412,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2413,\"textContent\":\"0\"}]}]},{\"nodeType\":1,\"id\":2414,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,733.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2415,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2416,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2417,\"textContent\":\"1\"}]}]},{\"nodeType\":1,\"id\":2418,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,667.1666666666667)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2419,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2420,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2421,\"textContent\":\"2\"}]}]},{\"nodeType\":1,\"id\":2422,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,600.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2423,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2424,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2425,\"textContent\":\"3\"}]}]},{\"nodeType\":1,\"id\":2426,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,533.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2427,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2428,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2429,\"textContent\":\"4\"}]}]},{\"nodeType\":1,\"id\":2430,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,467.16666666666663)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2431,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2432,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2433,\"textContent\":\"5\"}]}]},{\"nodeType\":1,\"id\":2434,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,400.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2435,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2436,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2437,\"textContent\":\"6\"}]}]},{\"nodeType\":1,\"id\":2438,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,333.8333333333333)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2439,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2440,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2441,\"textContent\":\"7\"}]}]},{\"nodeType\":1,\"id\":2442,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,267.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2443,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2444,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2445,\"textContent\":\"8\"}]}]},{\"nodeType\":1,\"id\":2446,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,200.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2447,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2448,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2449,\"textContent\":\"9\"}]}]},{\"nodeType\":1,\"id\":2450,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,133.83333333333326)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2451,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2452,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2453,\"textContent\":\"10\"}]}]},{\"nodeType\":1,\"id\":2454,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,67.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2455,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2456,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2457,\"textContent\":\"11\"}]}]},{\"nodeType\":1,\"id\":2458,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,0.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2459,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2460,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2461,\"textContent\":\"12\"}]}]},{\"nodeType\":1,\"id\":2462,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2463,\"tagName\":\"text\",\"attributes\":{\"transform\":\"rotate(-90)\",\"x\":\"-350\",\"y\":\"-60\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2464,\"textContent\":\"DURATION (in hours)\"}]}]}]},{\"nodeType\":1,\"id\":2465,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2466,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2467,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"733.3333333333334\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2468,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2469,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"666.6666666666667\",\"y2\":\"666.6666666666667\"}}]},{\"nodeType\":1,\"id\":2470,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2471,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"600\",\"y2\":\"600\"}}]},{\"nodeType\":1,\"id\":2472,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2473,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"533.3333333333334\",\"y2\":\"533.3333333333334\"}}]},{\"nodeType\":1,\"id\":2474,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2475,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"466.66666666666663\",\"y2\":\"466.66666666666663\"}}]},{\"nodeType\":1,\"id\":2476,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2477,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"400\",\"y2\":\"400\"}}]},{\"nodeType\":1,\"id\":2478,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2479,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"333.3333333333333\",\"y2\":\"333.3333333333333\"}}]},{\"nodeType\":1,\"id\":2480,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2481,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"266.66666666666674\",\"y2\":\"266.66666666666674\"}}]},{\"nodeType\":1,\"id\":2482,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2483,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"200\",\"y2\":\"200\"}}]},{\"nodeType\":1,\"id\":2484,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2485,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"133.33333333333326\",\"y2\":\"133.33333333333326\"}}]},{\"nodeType\":1,\"id\":2486,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2487,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"66.66666666666674\",\"y2\":\"66.66666666666674\"}}]},{\"nodeType\":1,\"id\":2488,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2489,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"0\",\"y2\":\"0\"}}]}]},{\"nodeType\":1,\"id\":2490,\"tagName\":\"g\",\"attributes\":{\"class\":\"xgrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2491,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"0\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2492,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"800\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2493,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"433.3333333333333\",\"y2\":\"66.66666666666674\"}},{\"nodeType\":1,\"id\":2494,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"366.66666666666663\",\"y2\":\"66.66666666666674\"}},{\"nodeType\":1,\"id\":2495,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"466.6666666666667\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2496,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"333.33333333333337\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2497,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"500\",\"y2\":\"200\"}},{\"nodeType\":1,\"id\":2498,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"300\",\"y2\":\"200\"}},{\"nodeType\":1,\"id\":2499,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"533.3333333333333\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2500,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"266.66666666666663\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2501,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"566.6666666666667\",\"y2\":\"333.3333333333333\"}},{\"nodeType\":1,\"id\":2502,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"233.33333333333334\",\"y2\":\"333.3333333333333\"}},{\"nodeType\":1,\"id\":2503,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"600\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2504,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"200\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2505,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"633.3333333333333\",\"y2\":\"466.66666666666663\"}},{\"nodeType\":1,\"id\":2506,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"166.66666666666669\",\"y2\":\"466.66666666666663\"}},{\"nodeType\":1,\"id\":2507,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"666.6666666666667\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2508,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"133.33333333333331\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2509,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"700\",\"y2\":\"600\"}},{\"nodeType\":1,\"id\":2510,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"100\",\"y2\":\"600\"}},{\"nodeType\":1,\"id\":2511,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"733.3333333333333\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2512,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"66.66666666666666\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2513,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"766.6666666666667\",\"y2\":\"733.3333333333334\"}},{\"nodeType\":1,\"id\":2514,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"33.33333333333333\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2515,\"tagName\":\"g\",\"attributes\":{\"class\":\"data\"},\"childNodes\":[{\"nodeType\":1,\"id\":2516,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2517,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"266.66666666666674\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2518,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"258.66666666666674\"},\"childNodes\":[{\"nodeType\":3,\"id\":2519,\"textContent\":\"A \"}]}]},{\"nodeType\":1,\"id\":2520,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2521,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2522,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2523,\"textContent\":\"B \"}]}]},{\"nodeType\":1,\"id\":2524,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2525,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"366.66666666666663\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2526,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"361.66666666666663\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2527,\"textContent\":\"C \"}]}]},{\"nodeType\":1,\"id\":2528,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2529,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"666.6666666666667\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2530,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"661.6666666666667\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2531,\"textContent\":\"D \"}]}]},{\"nodeType\":1,\"id\":2532,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2533,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"200\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2534,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"195\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2535,\"textContent\":\"E \"}]}]},{\"nodeType\":1,\"id\":2536,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2537,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2538,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2539,\"textContent\":\"F \"}]}]},{\"nodeType\":1,\"id\":2540,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2541,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2542,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2543,\"textContent\":\"G \"}]}]},{\"nodeType\":1,\"id\":2544,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2545,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2546,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2547,\"textContent\":\"H \"}]}]},{\"nodeType\":1,\"id\":2548,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2549,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"100\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2550,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"95\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2551,\"textContent\":\"I \"}]}]},{\"nodeType\":1,\"id\":2552,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2553,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"133.33333333333331\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2554,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"128.33333333333331\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2555,\"textContent\":\"J \"}]}]},{\"nodeType\":1,\"id\":2556,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2557,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"133.33333333333326\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2558,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"125.33333333333326\"},\"childNodes\":[{\"nodeType\":3,\"id\":2559,\"textContent\":\"K \"}]}]},{\"nodeType\":1,\"id\":2560,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2561,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"333.3333333333333\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2562,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"325.3333333333333\"},\"childNodes\":[{\"nodeType\":3,\"id\":2563,\"textContent\":\"L \"}]}]},{\"nodeType\":1,\"id\":2564,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2565,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"300\",\"cy\":\"733.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2566,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"295\",\"y\":\"725.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2567,\"textContent\":\"M \"}]}]},{\"nodeType\":1,\"id\":2568,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2569,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"600\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2570,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"595\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2571,\"textContent\":\"N \"}]}]},{\"nodeType\":1,\"id\":2572,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2573,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"433.3333333333333\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2574,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"428.3333333333333\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2575,\"textContent\":\"O \"}]}]},{\"nodeType\":1,\"id\":2576,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2577,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"200\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2578,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"192\"},\"childNodes\":[{\"nodeType\":3,\"id\":2579,\"textContent\":\"P \"}]}]},{\"nodeType\":1,\"id\":2580,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2581,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"533.3333333333333\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2582,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"528.3333333333333\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2583,\"textContent\":\"Z \"}]}]},{\"nodeType\":1,\"id\":2584,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2585,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2586,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2587,\"textContent\":\"X \"}]}]}]}]}]}]},{\"nodeType\":3,\"id\":2588,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2589,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2590},{\"nodeType\":3,\"id\":2591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2592,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2593,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2594,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2595,\"textContent\":\" \"}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 199, dom: 712, initialDom: 781",
  "javascriptErrors": []
}