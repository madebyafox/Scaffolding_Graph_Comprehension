var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "127419c2f42157707a46fce24de3b959",
  "created": "2018-05-14T13:02:27.0670963-07:00",
  "lastActivity": "2018-05-14T13:05:15.8760485-07:00",
  "pageViews": [
    {
      "id": "051426284fde0c77531918cc018e3a9afc86fca6",
      "startTime": "2018-05-14T13:02:27.0670963-07:00",
      "endTime": "2018-05-14T13:05:15.8760485-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/",
      "visitTime": 169106,
      "engagementTime": 55735,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 169106,
  "engagementTime": 55735,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.39",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.170 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.170",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "f5c869410d8f60dcfafd27e6f2690b75",
  "gdpr": false
}