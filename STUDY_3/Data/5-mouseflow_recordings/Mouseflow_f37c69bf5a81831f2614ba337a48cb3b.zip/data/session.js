var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "f37c69bf5a81831f2614ba337a48cb3b",
  "created": "2018-05-25T11:06:20.1121823-07:00",
  "lastActivity": "2018-05-25T11:08:55.1509565-07:00",
  "pageViews": [
    {
      "id": "0525197746f5abc8ce3f40e74df2c6989447d04f",
      "startTime": "2018-05-25T11:06:20.2603251-07:00",
      "endTime": "2018-05-25T11:08:55.1509565-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/",
      "visitTime": 155396,
      "engagementTime": 98897,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 155396,
  "engagementTime": 98897,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.41",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "de679a07acd562b16a75a6ea061a8e97",
  "gdpr": false
}