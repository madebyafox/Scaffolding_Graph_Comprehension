var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "601b79a009d7ec67cffff7da8621d3fa",
  "created": "2018-06-04T13:22:39.2986025-07:00",
  "lastActivity": "2018-06-04T13:22:56.8090364-07:00",
  "pageViews": [
    {
      "id": "0604397615ff63f3d117f51429c0f50040cbfa18",
      "startTime": "2018-06-04T13:22:39.3120364-07:00",
      "endTime": "2018-06-04T13:22:56.8090364-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/11",
      "visitTime": 17497,
      "engagementTime": 17398,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 17497,
  "engagementTime": 17398,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.38",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=MUULG",
    "CONDITION=211",
    "TRI_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "c925f4c0fff2a2c0e71a4c51f242d707",
  "gdpr": false
}