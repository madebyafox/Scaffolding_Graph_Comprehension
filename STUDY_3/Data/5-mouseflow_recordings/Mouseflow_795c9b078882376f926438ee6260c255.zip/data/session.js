var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "795c9b078882376f926438ee6260c255",
  "created": "2018-05-14T14:10:25.407512-07:00",
  "lastActivity": "2018-05-14T14:11:04.881512-07:00",
  "pageViews": [
    {
      "id": "051425161776a2ec45f20e3276df4f3af444ab42",
      "startTime": "2018-05-14T14:10:25.407512-07:00",
      "endTime": "2018-05-14T14:11:04.881512-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/3",
      "visitTime": 39474,
      "engagementTime": 39474,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 39474,
  "engagementTime": 39474,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.31",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.170 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.170",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=7KANO",
    "CONDITION=111"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "bd5e899f8d181a871484d0b7efa79b75",
  "gdpr": false
}