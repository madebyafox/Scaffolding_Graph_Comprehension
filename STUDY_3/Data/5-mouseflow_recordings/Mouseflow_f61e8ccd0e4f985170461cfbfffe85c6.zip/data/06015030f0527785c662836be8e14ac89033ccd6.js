var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["06015030f0527785c662836be8e14ac89033ccd6"] = {
  "startTime": "2018-06-01T18:14:50.7603754Z",
  "websitePageUrl": "/16",
  "visitTime": 84832,
  "engagementTime": 83474,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1200,
  "tags": [
    "form-interact",
    "submit"
  ],
  "session": {
    "id": "f61e8ccd0e4f985170461cfbfffe85c6",
    "created": "2018-06-01T18:14:50.7603754+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.62 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "67.0.3396.62",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/16",
    "tags": [
      "form-interact",
      "submit"
    ],
    "variables": [
      "SID=7BW1K",
      "CONDITION=311"
    ],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "609ce382395fe6af6a8de2847602f952",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/f61e8ccd0e4f985170461cfbfffe85c6/play"
  },
  "events": [
    {
      "t": 1,
      "e": 1,
      "ty": 14,
      "x": 0,
      "y": 1199
    },
    {
      "t": 198,
      "e": 198,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 501,
      "e": 501,
      "ty": 2,
      "x": 776,
      "y": 494
    },
    {
      "t": 502,
      "e": 502,
      "ty": 41,
      "x": 5504,
      "y": 25276,
      "ta": "> div.stimulus > div:[2]"
    },
    {
      "t": 684,
      "e": 684,
      "ty": 6,
      "x": 410,
      "y": 526,
      "ta": "#strategyAnswer"
    },
    {
      "t": 701,
      "e": 701,
      "ty": 2,
      "x": 343,
      "y": 534
    },
    {
      "t": 751,
      "e": 751,
      "ty": 41,
      "x": 22471,
      "y": 9114,
      "ta": "#strategyAnswer"
    },
    {
      "t": 800,
      "e": 800,
      "ty": 2,
      "x": 296,
      "y": 534
    },
    {
      "t": 1001,
      "e": 1001,
      "ty": 41,
      "x": 22359,
      "y": 9114,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1601,
      "e": 1601,
      "ty": 2,
      "x": 295,
      "y": 534
    },
    {
      "t": 1751,
      "e": 1751,
      "ty": 41,
      "x": 22246,
      "y": 9114,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2601,
      "e": 2601,
      "ty": 2,
      "x": 294,
      "y": 534
    },
    {
      "t": 2751,
      "e": 2751,
      "ty": 41,
      "x": 22021,
      "y": 13160,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2800,
      "e": 2800,
      "ty": 2,
      "x": 293,
      "y": 542
    },
    {
      "t": 2901,
      "e": 2901,
      "ty": 2,
      "x": 291,
      "y": 551
    },
    {
      "t": 3001,
      "e": 3001,
      "ty": 2,
      "x": 291,
      "y": 555
    },
    {
      "t": 3001,
      "e": 3001,
      "ty": 41,
      "x": 21796,
      "y": 26105,
      "ta": "#strategyAnswer"
    },
    {
      "t": 3101,
      "e": 3101,
      "ty": 2,
      "x": 303,
      "y": 558
    },
    {
      "t": 3201,
      "e": 3201,
      "ty": 2,
      "x": 375,
      "y": 565
    },
    {
      "t": 3251,
      "e": 3251,
      "ty": 41,
      "x": 34948,
      "y": 28532,
      "ta": "#strategyAnswer"
    },
    {
      "t": 3301,
      "e": 3301,
      "ty": 2,
      "x": 443,
      "y": 549
    },
    {
      "t": 3401,
      "e": 3401,
      "ty": 2,
      "x": 470,
      "y": 540
    },
    {
      "t": 3501,
      "e": 3501,
      "ty": 2,
      "x": 479,
      "y": 535
    },
    {
      "t": 3502,
      "e": 3502,
      "ty": 41,
      "x": 42930,
      "y": 9923,
      "ta": "#strategyAnswer"
    },
    {
      "t": 3601,
      "e": 3601,
      "ty": 2,
      "x": 493,
      "y": 526
    },
    {
      "t": 3633,
      "e": 3633,
      "ty": 7,
      "x": 503,
      "y": 519,
      "ta": "#strategyAnswer"
    },
    {
      "t": 3701,
      "e": 3701,
      "ty": 2,
      "x": 517,
      "y": 509
    },
    {
      "t": 3751,
      "e": 3751,
      "ty": 41,
      "x": 47314,
      "y": 31048,
      "ta": "#.strategy > p"
    },
    {
      "t": 3801,
      "e": 3801,
      "ty": 2,
      "x": 518,
      "y": 508
    },
    {
      "t": 3901,
      "e": 3901,
      "ty": 2,
      "x": 519,
      "y": 507
    },
    {
      "t": 4001,
      "e": 4001,
      "ty": 41,
      "x": 47426,
      "y": 28708,
      "ta": "#.strategy > p"
    },
    {
      "t": 4201,
      "e": 4201,
      "ty": 2,
      "x": 530,
      "y": 505
    },
    {
      "t": 4251,
      "e": 4251,
      "ty": 41,
      "x": 64512,
      "y": 17005,
      "ta": "#.strategy > p"
    },
    {
      "t": 4301,
      "e": 4301,
      "ty": 2,
      "x": 859,
      "y": 502
    },
    {
      "t": 4401,
      "e": 4401,
      "ty": 2,
      "x": 946,
      "y": 507
    },
    {
      "t": 4501,
      "e": 4501,
      "ty": 2,
      "x": 960,
      "y": 516
    },
    {
      "t": 4501,
      "e": 4501,
      "ty": 41,
      "x": 12262,
      "y": 27073,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 4601,
      "e": 4601,
      "ty": 2,
      "x": 1005,
      "y": 549
    },
    {
      "t": 4700,
      "e": 4700,
      "ty": 2,
      "x": 1010,
      "y": 554
    },
    {
      "t": 4751,
      "e": 4751,
      "ty": 41,
      "x": 17054,
      "y": 32230,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 4801,
      "e": 4801,
      "ty": 2,
      "x": 1055,
      "y": 626
    },
    {
      "t": 4901,
      "e": 4901,
      "ty": 2,
      "x": 1089,
      "y": 710
    },
    {
      "t": 5002,
      "e": 5002,
      "ty": 2,
      "x": 1128,
      "y": 804
    },
    {
      "t": 5002,
      "e": 5002,
      "ty": 41,
      "x": 24101,
      "y": 47700,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 5101,
      "e": 5101,
      "ty": 2,
      "x": 1171,
      "y": 869
    },
    {
      "t": 5201,
      "e": 5201,
      "ty": 2,
      "x": 1234,
      "y": 920
    },
    {
      "t": 5251,
      "e": 5251,
      "ty": 41,
      "x": 32416,
      "y": 56510,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 5301,
      "e": 5301,
      "ty": 2,
      "x": 1259,
      "y": 935
    },
    {
      "t": 5401,
      "e": 5401,
      "ty": 2,
      "x": 1268,
      "y": 943
    },
    {
      "t": 5501,
      "e": 5501,
      "ty": 2,
      "x": 1288,
      "y": 959
    },
    {
      "t": 5502,
      "e": 5502,
      "ty": 41,
      "x": 660,
      "y": 64879,
      "ta": "> div.stimulus > div:[2] > svg > g > g:[6] > line:[13]"
    },
    {
      "t": 5601,
      "e": 5601,
      "ty": 2,
      "x": 1296,
      "y": 965
    },
    {
      "t": 5751,
      "e": 5751,
      "ty": 41,
      "x": 35939,
      "y": 59232,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 5801,
      "e": 5801,
      "ty": 2,
      "x": 1297,
      "y": 966
    },
    {
      "t": 5901,
      "e": 5901,
      "ty": 2,
      "x": 1299,
      "y": 965
    },
    {
      "t": 6002,
      "e": 6002,
      "ty": 2,
      "x": 1256,
      "y": 956
    },
    {
      "t": 6003,
      "e": 6003,
      "ty": 41,
      "x": 33120,
      "y": 58587,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 6102,
      "e": 6102,
      "ty": 2,
      "x": 1066,
      "y": 897
    },
    {
      "t": 6201,
      "e": 6201,
      "ty": 2,
      "x": 1065,
      "y": 897
    },
    {
      "t": 6252,
      "e": 6252,
      "ty": 41,
      "x": 20295,
      "y": 54791,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 6301,
      "e": 6301,
      "ty": 2,
      "x": 1122,
      "y": 950
    },
    {
      "t": 6401,
      "e": 6401,
      "ty": 2,
      "x": 1146,
      "y": 963
    },
    {
      "t": 6501,
      "e": 6501,
      "ty": 2,
      "x": 1149,
      "y": 960
    },
    {
      "t": 6501,
      "e": 6501,
      "ty": 41,
      "x": 25580,
      "y": 58874,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 6601,
      "e": 6601,
      "ty": 2,
      "x": 1153,
      "y": 958
    },
    {
      "t": 6751,
      "e": 6751,
      "ty": 41,
      "x": 25862,
      "y": 58730,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 10001,
      "e": 10001,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 12502,
      "e": 11751,
      "ty": 2,
      "x": 691,
      "y": 783
    },
    {
      "t": 12502,
      "e": 11751,
      "ty": 41,
      "x": 625,
      "y": 45796,
      "ta": "> div.stimulus > div:[2]"
    },
    {
      "t": 12601,
      "e": 11850,
      "ty": 2,
      "x": 303,
      "y": 669
    },
    {
      "t": 12701,
      "e": 11950,
      "ty": 2,
      "x": 304,
      "y": 652
    },
    {
      "t": 12723,
      "e": 11972,
      "ty": 6,
      "x": 329,
      "y": 591,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12752,
      "e": 12001,
      "ty": 41,
      "x": 26967,
      "y": 30150,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12802,
      "e": 12051,
      "ty": 2,
      "x": 351,
      "y": 523
    },
    {
      "t": 12901,
      "e": 12150,
      "ty": 2,
      "x": 338,
      "y": 542
    },
    {
      "t": 13002,
      "e": 12251,
      "ty": 2,
      "x": 323,
      "y": 561
    },
    {
      "t": 13002,
      "e": 12251,
      "ty": 41,
      "x": 25394,
      "y": 30959,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13008,
      "e": 12257,
      "ty": 3,
      "x": 323,
      "y": 561,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13010,
      "e": 12259,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13094,
      "e": 12343,
      "ty": 4,
      "x": 25394,
      "y": 30959,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13095,
      "e": 12344,
      "ty": 5,
      "x": 323,
      "y": 561,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13201,
      "e": 12450,
      "ty": 2,
      "x": 322,
      "y": 562
    },
    {
      "t": 13252,
      "e": 12501,
      "ty": 41,
      "x": 25281,
      "y": 31768,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13764,
      "e": 13013,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 13850,
      "e": 13099,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 13852,
      "e": 13101,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13970,
      "e": 13219,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "S"
    },
    {
      "t": 13986,
      "e": 13235,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "S"
    },
    {
      "t": 14538,
      "e": 13787,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 14538,
      "e": 13787,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14651,
      "e": 13900,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Sh"
    },
    {
      "t": 14674,
      "e": 13923,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 14674,
      "e": 13923,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14786,
      "e": 14035,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Shi"
    },
    {
      "t": 14811,
      "e": 14060,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 14812,
      "e": 14061,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14930,
      "e": 14179,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Shif"
    },
    {
      "t": 15051,
      "e": 14300,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 15051,
      "e": 14300,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15138,
      "e": 14387,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 15139,
      "e": 14388,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15170,
      "e": 14419,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ts"
    },
    {
      "t": 15251,
      "e": 14500,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 15251,
      "e": 14500,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15265,
      "e": 14514,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 15338,
      "e": 14587,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 15362,
      "e": 14611,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 15363,
      "e": 14612,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15482,
      "e": 14731,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 15490,
      "e": 14739,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 15491,
      "e": 14740,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15578,
      "e": 14827,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 15578,
      "e": 14827,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 15579,
      "e": 14828,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15634,
      "e": 14883,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 15636,
      "e": 14885,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15706,
      "e": 14955,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||at"
    },
    {
      "t": 15746,
      "e": 14995,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 15762,
      "e": 15011,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 15762,
      "e": 15011,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15858,
      "e": 15107,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 15907,
      "e": 15156,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 15908,
      "e": 15157,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16067,
      "e": 15316,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 16067,
      "e": 15316,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 16068,
      "e": 15317,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16154,
      "e": 15403,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 16155,
      "e": 15404,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16178,
      "e": 15427,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ta"
    },
    {
      "t": 16315,
      "e": 15564,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 16362,
      "e": 15611,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 16363,
      "e": 15612,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16441,
      "e": 15690,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 16442,
      "e": 15691,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16506,
      "e": 15755,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||rt"
    },
    {
      "t": 16570,
      "e": 15819,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 16635,
      "e": 15884,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 16636,
      "e": 15885,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16738,
      "e": 15987,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 16738,
      "e": 15987,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16754,
      "e": 16003,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| a"
    },
    {
      "t": 16882,
      "e": 16131,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 16883,
      "e": 16132,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16923,
      "e": 16172,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 17005,
      "e": 16254,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 17027,
      "e": 16276,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 17027,
      "e": 16276,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17146,
      "e": 16395,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 17323,
      "e": 16572,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 17324,
      "e": 16573,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17490,
      "e": 16739,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||1"
    },
    {
      "t": 17714,
      "e": 16963,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 17714,
      "e": 16963,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17810,
      "e": 17059,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||2"
    },
    {
      "t": 17914,
      "e": 17163,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 17915,
      "e": 17164,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18026,
      "e": 17275,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 18643,
      "e": 17892,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 18643,
      "e": 17892,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18746,
      "e": 17995,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 18882,
      "e": 18131,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 18884,
      "e": 18133,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18978,
      "e": 18227,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 19034,
      "e": 18283,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 19034,
      "e": 18283,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19090,
      "e": 18339,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 19091,
      "e": 18340,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19162,
      "e": 18411,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| a"
    },
    {
      "t": 19195,
      "e": 18444,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 19195,
      "e": 18444,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19243,
      "e": 18492,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 19283,
      "e": 18532,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 19283,
      "e": 18532,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19322,
      "e": 18571,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 19370,
      "e": 18619,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 19370,
      "e": 18619,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19394,
      "e": 18643,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 19498,
      "e": 18747,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 19635,
      "e": 18884,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 19635,
      "e": 18884,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19722,
      "e": 18971,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 19723,
      "e": 18972,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19762,
      "e": 19011,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||on"
    },
    {
      "t": 19843,
      "e": 19092,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 19899,
      "e": 19148,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 19901,
      "e": 19150,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19987,
      "e": 19236,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 19995,
      "e": 19244,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 19995,
      "e": 19244,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20001,
      "e": 19250,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 20098,
      "e": 19347,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 20106,
      "e": 19355,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 20106,
      "e": 19355,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20226,
      "e": 19475,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 20258,
      "e": 19507,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 20258,
      "e": 19507,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20362,
      "e": 19611,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 20363,
      "e": 19612,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20370,
      "e": 19619,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e "
    },
    {
      "t": 20475,
      "e": 19724,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 20539,
      "e": 19788,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 20540,
      "e": 19789,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20634,
      "e": 19883,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 20642,
      "e": 19891,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 20642,
      "e": 19891,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20730,
      "e": 19979,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 20762,
      "e": 20011,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 20763,
      "e": 20012,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20874,
      "e": 20123,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 20986,
      "e": 20235,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 20986,
      "e": 20235,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21090,
      "e": 20339,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 21362,
      "e": 20611,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 21365,
      "e": 20614,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21450,
      "e": 20699,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 21538,
      "e": 20787,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 21539,
      "e": 20788,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21610,
      "e": 20859,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 21738,
      "e": 20987,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 21739,
      "e": 20988,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21802,
      "e": 21051,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 21923,
      "e": 21172,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 21923,
      "e": 21172,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22042,
      "e": 21291,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 22146,
      "e": 21395,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 22148,
      "e": 21397,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22210,
      "e": 21459,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 22210,
      "e": 21459,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22258,
      "e": 21507,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||li"
    },
    {
      "t": 22322,
      "e": 21571,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 22459,
      "e": 21708,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 22459,
      "e": 21708,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22553,
      "e": 21802,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 22586,
      "e": 21835,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 22586,
      "e": 21835,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22666,
      "e": 21915,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 22739,
      "e": 21988,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 22740,
      "e": 21989,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22850,
      "e": 22099,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 23252,
      "e": 22501,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 23252,
      "e": 22501,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23346,
      "e": 22595,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 23538,
      "e": 22787,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 23540,
      "e": 22789,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23650,
      "e": 22899,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 23658,
      "e": 22907,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 23658,
      "e": 22907,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23770,
      "e": 23019,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 23771,
      "e": 23020,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23818,
      "e": 23067,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||at"
    },
    {
      "t": 23883,
      "e": 23132,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 24490,
      "e": 23739,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 24491,
      "e": 23740,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24602,
      "e": 23851,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Shifts that start at 12 pm are on the diagnol line that "
    },
    {
      "t": 24642,
      "e": 23891,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 25522,
      "e": 24771,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 25523,
      "e": 24772,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25611,
      "e": 24860,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 25651,
      "e": 24900,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 25651,
      "e": 24900,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25746,
      "e": 24995,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 25818,
      "e": 25067,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 25819,
      "e": 25068,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25923,
      "e": 25172,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 25923,
      "e": 25172,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26009,
      "e": 25258,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||es"
    },
    {
      "t": 26066,
      "e": 25315,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 26074,
      "e": 25323,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 26074,
      "e": 25323,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26179,
      "e": 25428,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 26266,
      "e": 25515,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 26267,
      "e": 25516,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26338,
      "e": 25587,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 26338,
      "e": 25587,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26385,
      "e": 25634,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||up"
    },
    {
      "t": 26450,
      "e": 25699,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 26474,
      "e": 25723,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 26475,
      "e": 25724,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26578,
      "e": 25827,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 26594,
      "e": 25843,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 26594,
      "e": 25843,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26691,
      "e": 25940,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 26691,
      "e": 25940,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26698,
      "e": 25947,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||an"
    },
    {
      "t": 26785,
      "e": 26034,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 26786,
      "e": 26035,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 26787,
      "e": 26036,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26873,
      "e": 26122,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 26881,
      "e": 26130,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 26882,
      "e": 26131,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26986,
      "e": 26235,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 27010,
      "e": 26259,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 27010,
      "e": 26259,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27074,
      "e": 26323,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 27074,
      "e": 26323,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27106,
      "e": 26355,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||to"
    },
    {
      "t": 27155,
      "e": 26404,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 27201,
      "e": 26450,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 27202,
      "e": 26451,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27274,
      "e": 26523,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 27274,
      "e": 26523,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27306,
      "e": 26555,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| t"
    },
    {
      "t": 27370,
      "e": 26619,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 27378,
      "e": 26627,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 27379,
      "e": 26628,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27467,
      "e": 26716,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 27474,
      "e": 26723,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 27475,
      "e": 26724,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27571,
      "e": 26820,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 27619,
      "e": 26868,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 27620,
      "e": 26869,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27754,
      "e": 27003,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 27874,
      "e": 27123,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 27876,
      "e": 27125,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27986,
      "e": 27235,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 27995,
      "e": 27236,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 27995,
      "e": 27236,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28074,
      "e": 27315,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 28137,
      "e": 27378,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 28138,
      "e": 27379,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28266,
      "e": 27507,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 28291,
      "e": 27532,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 28291,
      "e": 27532,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28403,
      "e": 27644,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Shifts that start at 12 pm are on the diagnol line that goes up and to the righ"
    },
    {
      "t": 28418,
      "e": 27659,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 28434,
      "e": 27675,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 28434,
      "e": 27675,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28538,
      "e": 27779,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 28611,
      "e": 27852,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 28612,
      "e": 27853,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28754,
      "e": 27995,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 29290,
      "e": 28531,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 29291,
      "e": 28532,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29386,
      "e": 28627,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 29409,
      "e": 28650,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 29410,
      "e": 28651,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29482,
      "e": 28723,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 29483,
      "e": 28724,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29506,
      "e": 28747,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||f "
    },
    {
      "t": 29586,
      "e": 28827,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 29627,
      "e": 28868,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 29628,
      "e": 28869,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29721,
      "e": 28962,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 29738,
      "e": 28979,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 29738,
      "e": 28979,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29826,
      "e": 29067,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 29842,
      "e": 29083,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 29842,
      "e": 29083,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29930,
      "e": 29171,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 29946,
      "e": 29187,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 29947,
      "e": 29188,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30073,
      "e": 29314,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 30138,
      "e": 29379,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 30138,
      "e": 29379,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30225,
      "e": 29466,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 30226,
      "e": 29467,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30289,
      "e": 29530,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||12"
    },
    {
      "t": 30354,
      "e": 29595,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 30666,
      "e": 29907,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 30667,
      "e": 29908,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30753,
      "e": 29994,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 30874,
      "e": 30115,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 30875,
      "e": 30116,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30961,
      "e": 30202,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 31026,
      "e": 30267,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 31026,
      "e": 30267,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31122,
      "e": 30363,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 31138,
      "e": 30379,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 31138,
      "e": 30379,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31218,
      "e": 30459,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 31218,
      "e": 30459,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31242,
      "e": 30483,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ma"
    },
    {
      "t": 31314,
      "e": 30555,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 31314,
      "e": 30555,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31363,
      "e": 30604,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 31409,
      "e": 30650,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 31418,
      "e": 30659,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "75"
    },
    {
      "t": 31418,
      "e": 30659,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31490,
      "e": 30731,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||k"
    },
    {
      "t": 31603,
      "e": 30844,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Shifts that start at 12 pm are on the diagnol line that goes up and to the right of the 12pm mark"
    },
    {
      "t": 31634,
      "e": 30875,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "190"
    },
    {
      "t": 31635,
      "e": 30876,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31745,
      "e": 30986,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||."
    },
    {
      "t": 31794,
      "e": 31035,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 31794,
      "e": 31035,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31889,
      "e": 31130,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 31890,
      "e": 31131,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 32043,
      "e": 31284,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 32043,
      "e": 31284,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32129,
      "e": 31370,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||T"
    },
    {
      "t": 32178,
      "e": 31419,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 32219,
      "e": 31460,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 32258,
      "e": 31499,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 32434,
      "e": 31675,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 32562,
      "e": 31803,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Shifts that start at 12 pm are on the diagnol line that goes up and to the right of the 12pm mark. "
    },
    {
      "t": 32986,
      "e": 32227,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 33154,
      "e": 32395,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 33154,
      "e": 32395,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33257,
      "e": 32498,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||I"
    },
    {
      "t": 33266,
      "e": 32507,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 33404,
      "e": 32645,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 33406,
      "e": 32647,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33489,
      "e": 32730,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 33538,
      "e": 32779,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 33538,
      "e": 32779,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33626,
      "e": 32867,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 33642,
      "e": 32883,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 33643,
      "e": 32884,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33714,
      "e": 32955,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 33715,
      "e": 32956,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33739,
      "e": 32957,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||th"
    },
    {
      "t": 33785,
      "e": 33003,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 33785,
      "e": 33003,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33834,
      "e": 33052,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 33882,
      "e": 33100,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 33882,
      "e": 33100,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33898,
      "e": 33116,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 33970,
      "e": 33188,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 34003,
      "e": 33221,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 34003,
      "e": 33221,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34074,
      "e": 33292,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 34074,
      "e": 33292,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34113,
      "e": 33331,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| c"
    },
    {
      "t": 34162,
      "e": 33380,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 34162,
      "e": 33380,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34186,
      "e": 33404,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 34242,
      "e": 33460,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 34242,
      "e": 33460,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34290,
      "e": 33508,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 34346,
      "e": 33564,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 34347,
      "e": 33565,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34394,
      "e": 33612,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 34442,
      "e": 33660,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 34505,
      "e": 33723,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 34506,
      "e": 33724,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34610,
      "e": 33828,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 34738,
      "e": 33956,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 34923,
      "e": 34141,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 34923,
      "e": 34141,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35042,
      "e": 34260,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||M"
    },
    {
      "t": 35122,
      "e": 34340,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 35259,
      "e": 34477,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 35259,
      "e": 34477,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35377,
      "e": 34595,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 35401,
      "e": 34619,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 35402,
      "e": 34620,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35538,
      "e": 34756,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 36323,
      "e": 35541,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 36323,
      "e": 35541,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36442,
      "e": 35660,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 36498,
      "e": 35716,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 36498,
      "e": 35716,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36593,
      "e": 35811,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 36682,
      "e": 35900,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 36683,
      "e": 35901,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36762,
      "e": 35980,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 36841,
      "e": 36059,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 37340,
      "e": 36558,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 37374,
      "e": 36592,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 37386,
      "e": 36604,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 37386,
      "e": 36604,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37466,
      "e": 36684,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||L"
    },
    {
      "t": 37498,
      "e": 36716,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 38004,
      "e": 37222,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "190"
    },
    {
      "t": 38004,
      "e": 37222,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38081,
      "e": 37299,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||."
    },
    {
      "t": 38203,
      "e": 37421,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Shifts that start at 12 pm are on the diagnol line that goes up and to the right of the 12pm mark. In this case M and L."
    },
    {
      "t": 39954,
      "e": 39172,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "13"
    },
    {
      "t": 39955,
      "e": 39173,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40001,
      "e": 39219,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 40033,
      "e": 39251,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||\n"
    },
    {
      "t": 40138,
      "e": 39356,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "13"
    },
    {
      "t": 40138,
      "e": 39356,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40209,
      "e": 39427,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||\n"
    },
    {
      "t": 40322,
      "e": 39540,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 40363,
      "e": 39581,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "66"
    },
    {
      "t": 40363,
      "e": 39581,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40457,
      "e": 39675,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||B"
    },
    {
      "t": 40493,
      "e": 39711,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 40646,
      "e": 39864,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 40647,
      "e": 39865,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40717,
      "e": 39935,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 40717,
      "e": 39935,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40750,
      "e": 39968,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||re"
    },
    {
      "t": 40789,
      "e": 40007,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 40790,
      "e": 40008,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40830,
      "e": 40048,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 40942,
      "e": 40160,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 41398,
      "e": 40616,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "75"
    },
    {
      "t": 41398,
      "e": 40616,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41454,
      "e": 40672,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 41454,
      "e": 40672,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41478,
      "e": 40696,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ks"
    },
    {
      "t": 41574,
      "e": 40792,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 41574,
      "e": 40792,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41590,
      "e": 40808,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 41678,
      "e": 40896,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 41686,
      "e": 40904,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 41686,
      "e": 40904,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41781,
      "e": 40999,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 41806,
      "e": 41024,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 41806,
      "e": 41024,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41870,
      "e": 41088,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 41870,
      "e": 41088,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41902,
      "e": 41120,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ha"
    },
    {
      "t": 41958,
      "e": 41176,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 41959,
      "e": 41177,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42005,
      "e": 41223,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 42077,
      "e": 41295,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 42094,
      "e": 41312,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 42094,
      "e": 41312,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42190,
      "e": 41408,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 42190,
      "e": 41408,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42206,
      "e": 41424,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| s"
    },
    {
      "t": 42350,
      "e": 41568,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 42630,
      "e": 41848,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 42631,
      "e": 41849,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42782,
      "e": 42000,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 42782,
      "e": 42000,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 42782,
      "e": 42000,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42920,
      "e": 42138,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 42921,
      "e": 42139,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42949,
      "e": 42167,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ar"
    },
    {
      "t": 42998,
      "e": 42216,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 42999,
      "e": 42217,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43069,
      "e": 42287,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 43141,
      "e": 42359,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 43399,
      "e": 42617,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 43399,
      "e": 42617,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43486,
      "e": 42704,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 43486,
      "e": 42704,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43502,
      "e": 42720,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| a"
    },
    {
      "t": 43582,
      "e": 42800,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 43582,
      "e": 42800,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43621,
      "e": 42839,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 43686,
      "e": 42904,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 43727,
      "e": 42945,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 43728,
      "e": 42946,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43846,
      "e": 43064,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 44119,
      "e": 43337,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 44119,
      "e": 43337,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44246,
      "e": 43464,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 44246,
      "e": 43464,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44294,
      "e": 43512,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||12"
    },
    {
      "t": 44374,
      "e": 43592,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 44886,
      "e": 44104,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 44886,
      "e": 44104,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44998,
      "e": 44216,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 44998,
      "e": 44216,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45022,
      "e": 44240,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||pm"
    },
    {
      "t": 45134,
      "e": 44352,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 45446,
      "e": 44664,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 45510,
      "e": 44728,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Shifts that start at 12 pm are on the diagnol line that goes up and to the right of the 12pm mark. In this case M and L.\n\nBreaks that start at 12p"
    },
    {
      "t": 45598,
      "e": 44816,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 45686,
      "e": 44904,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Shifts that start at 12 pm are on the diagnol line that goes up and to the right of the 12pm mark. In this case M and L.\n\nBreaks that start at 12"
    },
    {
      "t": 45742,
      "e": 44960,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 45742,
      "e": 44960,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45821,
      "e": 45039,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 45862,
      "e": 45080,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 45863,
      "e": 45081,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45982,
      "e": 45200,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 46078,
      "e": 45296,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 46080,
      "e": 45298,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46158,
      "e": 45376,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 46248,
      "e": 45378,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 46249,
      "e": 45379,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46325,
      "e": 45455,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 46325,
      "e": 45455,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46350,
      "e": 45480,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| a"
    },
    {
      "t": 46478,
      "e": 45608,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 46534,
      "e": 45664,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 46535,
      "e": 45665,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46605,
      "e": 45735,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 46606,
      "e": 45736,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46630,
      "e": 45760,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||re"
    },
    {
      "t": 46710,
      "e": 45840,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 46718,
      "e": 45848,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 46718,
      "e": 45848,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46806,
      "e": 45936,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 46838,
      "e": 45968,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 46839,
      "e": 45969,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46925,
      "e": 46055,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 46925,
      "e": 46055,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 46926,
      "e": 46056,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 47022,
      "e": 46152,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 47046,
      "e": 46176,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 47046,
      "e": 46176,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 47125,
      "e": 46255,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 47126,
      "e": 46256,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 47149,
      "e": 46279,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||re"
    },
    {
      "t": 47214,
      "e": 46344,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 47310,
      "e": 46440,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 47310,
      "e": 46440,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 47374,
      "e": 46504,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||c"
    },
    {
      "t": 47510,
      "e": 46640,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 47510,
      "e": 46640,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 47589,
      "e": 46719,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 47662,
      "e": 46792,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 47662,
      "e": 46792,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 47750,
      "e": 46880,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 47750,
      "e": 46880,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 47773,
      "e": 46903,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ly"
    },
    {
      "t": 47838,
      "e": 46968,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 47942,
      "e": 47072,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 47942,
      "e": 47072,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 47982,
      "e": 47112,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 47982,
      "e": 47112,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48062,
      "e": 47192,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| a"
    },
    {
      "t": 48093,
      "e": 47223,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "66"
    },
    {
      "t": 48093,
      "e": 47223,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48117,
      "e": 47247,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||b"
    },
    {
      "t": 48198,
      "e": 47328,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 48278,
      "e": 47408,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 48279,
      "e": 47409,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48398,
      "e": 47528,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 48494,
      "e": 47624,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "86"
    },
    {
      "t": 48495,
      "e": 47625,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48582,
      "e": 47712,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 48582,
      "e": 47712,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48614,
      "e": 47744,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ve"
    },
    {
      "t": 48694,
      "e": 47824,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 49950,
      "e": 49080,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 49951,
      "e": 49081,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50053,
      "e": 49183,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 51518,
      "e": 50648,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 51519,
      "e": 50649,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51629,
      "e": 50759,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 51629,
      "e": 50759,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51661,
      "e": 50791,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||th"
    },
    {
      "t": 51734,
      "e": 50864,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 51735,
      "e": 50865,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51741,
      "e": 50871,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 51862,
      "e": 50992,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 51926,
      "e": 51056,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 51927,
      "e": 51057,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52078,
      "e": 51208,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 52534,
      "e": 51664,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 52535,
      "e": 51665,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52702,
      "e": 51832,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||1"
    },
    {
      "t": 52710,
      "e": 51840,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 52710,
      "e": 51840,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52798,
      "e": 51928,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||2"
    },
    {
      "t": 52871,
      "e": 52001,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 52871,
      "e": 52001,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52997,
      "e": 52127,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 53029,
      "e": 52159,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 53030,
      "e": 52160,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53126,
      "e": 52256,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 53238,
      "e": 52368,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 53240,
      "e": 52370,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53317,
      "e": 52447,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 53373,
      "e": 52503,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 53374,
      "e": 52504,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53437,
      "e": 52567,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 53438,
      "e": 52568,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53453,
      "e": 52583,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| m"
    },
    {
      "t": 53573,
      "e": 52703,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 53590,
      "e": 52720,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 53590,
      "e": 52720,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53742,
      "e": 52872,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 53846,
      "e": 52976,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "75"
    },
    {
      "t": 53847,
      "e": 52977,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53909,
      "e": 53039,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||k"
    },
    {
      "t": 54086,
      "e": 53216,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 54181,
      "e": 53311,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Shifts that start at 12 pm are on the diagnol line that goes up and to the right of the 12pm mark. In this case M and L.\n\nBreaks that start at 12 pm are directly above the 12 pm ma"
    },
    {
      "t": 54230,
      "e": 53360,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 54230,
      "e": 53360,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54293,
      "e": 53423,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 54318,
      "e": 53448,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "75"
    },
    {
      "t": 54319,
      "e": 53449,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54398,
      "e": 53528,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||k"
    },
    {
      "t": 54550,
      "e": 53680,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "190"
    },
    {
      "t": 54551,
      "e": 53681,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54638,
      "e": 53681,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||."
    },
    {
      "t": 55406,
      "e": 54449,
      "ty": 2,
      "x": 338,
      "y": 551
    },
    {
      "t": 55505,
      "e": 54548,
      "ty": 2,
      "x": 354,
      "y": 549
    },
    {
      "t": 55505,
      "e": 54548,
      "ty": 41,
      "x": 28878,
      "y": 21250,
      "ta": "#strategyAnswer"
    },
    {
      "t": 55605,
      "e": 54648,
      "ty": 2,
      "x": 399,
      "y": 549
    },
    {
      "t": 55705,
      "e": 54748,
      "ty": 2,
      "x": 418,
      "y": 539
    },
    {
      "t": 55756,
      "e": 54799,
      "ty": 41,
      "x": 36185,
      "y": 10732,
      "ta": "#strategyAnswer"
    },
    {
      "t": 55805,
      "e": 54848,
      "ty": 2,
      "x": 419,
      "y": 533
    },
    {
      "t": 55866,
      "e": 54909,
      "ty": 3,
      "x": 417,
      "y": 529,
      "ta": "#strategyAnswer"
    },
    {
      "t": 55905,
      "e": 54948,
      "ty": 2,
      "x": 417,
      "y": 529
    },
    {
      "t": 55969,
      "e": 55012,
      "ty": 4,
      "x": 35960,
      "y": 5069,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56005,
      "e": 55048,
      "ty": 41,
      "x": 35960,
      "y": 5069,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56916,
      "e": 55959,
      "ty": 3,
      "x": 346,
      "y": 546,
      "ta": "#strategyAnswer"
    },
    {
      "t": 57005,
      "e": 56048,
      "ty": 2,
      "x": 346,
      "y": 546
    },
    {
      "t": 57005,
      "e": 56048,
      "ty": 41,
      "x": 27979,
      "y": 18823,
      "ta": "#strategyAnswer"
    },
    {
      "t": 57009,
      "e": 56052,
      "ty": 4,
      "x": 27979,
      "y": 18823,
      "ta": "#strategyAnswer"
    },
    {
      "t": 57009,
      "e": 56052,
      "ty": 5,
      "x": 346,
      "y": 546,
      "ta": "#strategyAnswer"
    },
    {
      "t": 57105,
      "e": 56148,
      "ty": 2,
      "x": 389,
      "y": 541
    },
    {
      "t": 57205,
      "e": 56248,
      "ty": 2,
      "x": 409,
      "y": 533
    },
    {
      "t": 57255,
      "e": 56298,
      "ty": 41,
      "x": 35061,
      "y": 8305,
      "ta": "#strategyAnswer"
    },
    {
      "t": 57306,
      "e": 56349,
      "ty": 2,
      "x": 411,
      "y": 533
    },
    {
      "t": 57405,
      "e": 56448,
      "ty": 2,
      "x": 414,
      "y": 533
    },
    {
      "t": 57442,
      "e": 56485,
      "ty": 3,
      "x": 414,
      "y": 533,
      "ta": "#strategyAnswer"
    },
    {
      "t": 57505,
      "e": 56548,
      "ty": 41,
      "x": 35623,
      "y": 8305,
      "ta": "#strategyAnswer"
    },
    {
      "t": 57537,
      "e": 56580,
      "ty": 4,
      "x": 35623,
      "y": 8305,
      "ta": "#strategyAnswer"
    },
    {
      "t": 57537,
      "e": 56580,
      "ty": 5,
      "x": 414,
      "y": 533,
      "ta": "#strategyAnswer"
    },
    {
      "t": 57605,
      "e": 56648,
      "ty": 2,
      "x": 419,
      "y": 533
    },
    {
      "t": 57705,
      "e": 56748,
      "ty": 2,
      "x": 455,
      "y": 537
    },
    {
      "t": 57755,
      "e": 56798,
      "ty": 41,
      "x": 43829,
      "y": 11541,
      "ta": "#strategyAnswer"
    },
    {
      "t": 57805,
      "e": 56848,
      "ty": 2,
      "x": 491,
      "y": 536
    },
    {
      "t": 57905,
      "e": 56948,
      "ty": 2,
      "x": 506,
      "y": 531
    },
    {
      "t": 58005,
      "e": 57048,
      "ty": 41,
      "x": 45965,
      "y": 6687,
      "ta": "#strategyAnswer"
    },
    {
      "t": 58382,
      "e": 57425,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "37"
    },
    {
      "t": 58477,
      "e": 57520,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 59246,
      "e": 58289,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 59247,
      "e": 58290,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 59333,
      "e": 58376,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Shifts that start at 12 pm are on the diaganol line that goes up and to the right of the 12pm mark. In this case M and L.\n\nBreaks that start at 12 pm are directly above the 12 pm mark."
    },
    {
      "t": 59605,
      "e": 58648,
      "ty": 2,
      "x": 404,
      "y": 527
    },
    {
      "t": 59666,
      "e": 58709,
      "ty": 7,
      "x": 429,
      "y": 521,
      "ta": "#strategyAnswer"
    },
    {
      "t": 59705,
      "e": 58748,
      "ty": 2,
      "x": 429,
      "y": 521
    },
    {
      "t": 59756,
      "e": 58799,
      "ty": 41,
      "x": 37309,
      "y": 61475,
      "ta": "#.strategy > p"
    },
    {
      "t": 59799,
      "e": 58842,
      "ty": 6,
      "x": 450,
      "y": 544,
      "ta": "#strategyAnswer"
    },
    {
      "t": 59805,
      "e": 58848,
      "ty": 2,
      "x": 450,
      "y": 544
    },
    {
      "t": 59905,
      "e": 58948,
      "ty": 2,
      "x": 466,
      "y": 556
    },
    {
      "t": 59913,
      "e": 58956,
      "ty": 3,
      "x": 466,
      "y": 556,
      "ta": "#strategyAnswer"
    },
    {
      "t": 60001,
      "e": 59044,
      "ty": 4,
      "x": 41468,
      "y": 26914,
      "ta": "#strategyAnswer"
    },
    {
      "t": 60001,
      "e": 59044,
      "ty": 5,
      "x": 466,
      "y": 556,
      "ta": "#strategyAnswer"
    },
    {
      "t": 60005,
      "e": 59048,
      "ty": 41,
      "x": 41468,
      "y": 26914,
      "ta": "#strategyAnswer"
    },
    {
      "t": 60005,
      "e": 59048,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 60406,
      "e": 59449,
      "ty": 2,
      "x": 413,
      "y": 556
    },
    {
      "t": 60505,
      "e": 59548,
      "ty": 2,
      "x": 329,
      "y": 561
    },
    {
      "t": 60506,
      "e": 59549,
      "ty": 41,
      "x": 26068,
      "y": 30959,
      "ta": "#strategyAnswer"
    },
    {
      "t": 60605,
      "e": 59648,
      "ty": 2,
      "x": 319,
      "y": 563
    },
    {
      "t": 60705,
      "e": 59748,
      "ty": 2,
      "x": 283,
      "y": 568
    },
    {
      "t": 60755,
      "e": 59798,
      "ty": 41,
      "x": 20897,
      "y": 36623,
      "ta": "#strategyAnswer"
    },
    {
      "t": 60905,
      "e": 59948,
      "ty": 2,
      "x": 394,
      "y": 570
    },
    {
      "t": 61006,
      "e": 60049,
      "ty": 2,
      "x": 412,
      "y": 590
    },
    {
      "t": 61006,
      "e": 60049,
      "ty": 41,
      "x": 35398,
      "y": 54422,
      "ta": "#strategyAnswer"
    },
    {
      "t": 61018,
      "e": 60061,
      "ty": 7,
      "x": 424,
      "y": 613,
      "ta": "#strategyAnswer"
    },
    {
      "t": 61050,
      "e": 60093,
      "ty": 6,
      "x": 447,
      "y": 656,
      "ta": "#strategyButton"
    },
    {
      "t": 61106,
      "e": 60149,
      "ty": 2,
      "x": 457,
      "y": 673
    },
    {
      "t": 61205,
      "e": 60248,
      "ty": 2,
      "x": 457,
      "y": 677
    },
    {
      "t": 61256,
      "e": 60299,
      "ty": 41,
      "x": 59749,
      "y": 52554,
      "ta": "#strategyButton"
    },
    {
      "t": 61305,
      "e": 60348,
      "ty": 2,
      "x": 448,
      "y": 682
    },
    {
      "t": 61507,
      "e": 60550,
      "ty": 2,
      "x": 447,
      "y": 682
    },
    {
      "t": 61507,
      "e": 60550,
      "ty": 41,
      "x": 59203,
      "y": 52554,
      "ta": "#strategyButton"
    },
    {
      "t": 61605,
      "e": 60648,
      "ty": 2,
      "x": 446,
      "y": 682
    },
    {
      "t": 61755,
      "e": 60798,
      "ty": 41,
      "x": 58657,
      "y": 52554,
      "ta": "#strategyButton"
    },
    {
      "t": 61883,
      "e": 60926,
      "ty": 3,
      "x": 446,
      "y": 682,
      "ta": "#strategyButton"
    },
    {
      "t": 61885,
      "e": 60928,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Shifts that start at 12 pm are on the diaganol line that goes up and to the right of the 12pm mark. In this case M and L.\n\nBreaks that start at 12 pm are directly above the 12 pm mark."
    },
    {
      "t": 61885,
      "e": 60928,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 61887,
      "e": 60930,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 61961,
      "e": 61004,
      "ty": 4,
      "x": 58657,
      "y": 52554,
      "ta": "#strategyButton"
    },
    {
      "t": 61972,
      "e": 61015,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 61973,
      "e": 61016,
      "ty": 5,
      "x": 446,
      "y": 682,
      "ta": "#strategyButton"
    },
    {
      "t": 61981,
      "e": 61024,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 62981,
      "e": 62024,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 63005,
      "e": 62048,
      "ty": 2,
      "x": 445,
      "y": 682
    },
    {
      "t": 63005,
      "e": 62048,
      "ty": 41,
      "x": 15049,
      "y": 37337,
      "ta": "html > body"
    },
    {
      "t": 63504,
      "e": 62547,
      "ty": 2,
      "x": 444,
      "y": 680
    },
    {
      "t": 63505,
      "e": 62548,
      "ty": 41,
      "x": 15014,
      "y": 37226,
      "ta": "html > body"
    },
    {
      "t": 63605,
      "e": 62648,
      "ty": 2,
      "x": 611,
      "y": 615
    },
    {
      "t": 63705,
      "e": 62748,
      "ty": 2,
      "x": 663,
      "y": 592
    },
    {
      "t": 63755,
      "e": 62798,
      "ty": 41,
      "x": 23211,
      "y": 31964,
      "ta": "html > body"
    },
    {
      "t": 63805,
      "e": 62848,
      "ty": 2,
      "x": 740,
      "y": 574
    },
    {
      "t": 63905,
      "e": 62948,
      "ty": 2,
      "x": 803,
      "y": 542
    },
    {
      "t": 64006,
      "e": 63049,
      "ty": 41,
      "x": 27377,
      "y": 29582,
      "ta": "html > body"
    },
    {
      "t": 64071,
      "e": 63114,
      "ty": 6,
      "x": 825,
      "y": 554,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 64106,
      "e": 63149,
      "ty": 2,
      "x": 829,
      "y": 559
    },
    {
      "t": 64250,
      "e": 63293,
      "ty": 3,
      "x": 829,
      "y": 559,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 64251,
      "e": 63294,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 64255,
      "e": 63298,
      "ty": 41,
      "x": 4542,
      "y": 15603,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 64346,
      "e": 63389,
      "ty": 4,
      "x": 4542,
      "y": 15603,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 64347,
      "e": 63390,
      "ty": 5,
      "x": 829,
      "y": 559,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 64806,
      "e": 63849,
      "ty": 2,
      "x": 829,
      "y": 560
    },
    {
      "t": 64905,
      "e": 63948,
      "ty": 2,
      "x": 829,
      "y": 563
    },
    {
      "t": 65006,
      "e": 64049,
      "ty": 41,
      "x": 4542,
      "y": 28086,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 65030,
      "e": 64073,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "50"
    },
    {
      "t": 65031,
      "e": 64074,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 65093,
      "e": 64136,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "2"
    },
    {
      "t": 65197,
      "e": 64240,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "50"
    },
    {
      "t": 65197,
      "e": 64240,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 65203,
      "e": 64246,
      "ty": 7,
      "x": 824,
      "y": 582,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 65205,
      "e": 64248,
      "ty": 2,
      "x": 824,
      "y": 582
    },
    {
      "t": 65256,
      "e": 64299,
      "ty": 41,
      "x": 3460,
      "y": 32415,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 65288,
      "e": 64331,
      "ty": 6,
      "x": 836,
      "y": 650,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 65293,
      "e": 64336,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "22"
    },
    {
      "t": 65305,
      "e": 64348,
      "ty": 2,
      "x": 839,
      "y": 654
    },
    {
      "t": 65506,
      "e": 64549,
      "ty": 2,
      "x": 841,
      "y": 654
    },
    {
      "t": 65506,
      "e": 64549,
      "ty": 41,
      "x": 7137,
      "y": 21845,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 65595,
      "e": 64638,
      "ty": 3,
      "x": 841,
      "y": 654,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 65596,
      "e": 64639,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "22"
    },
    {
      "t": 65596,
      "e": 64639,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 65598,
      "e": 64641,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 65689,
      "e": 64732,
      "ty": 4,
      "x": 7137,
      "y": 21845,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 65689,
      "e": 64732,
      "ty": 5,
      "x": 841,
      "y": 654,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 66230,
      "e": 65273,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 66445,
      "e": 65488,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "85"
    },
    {
      "t": 66447,
      "e": 65490,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 66526,
      "e": 65569,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "83"
    },
    {
      "t": 66527,
      "e": 65570,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 66557,
      "e": 65600,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "US"
    },
    {
      "t": 66581,
      "e": 65624,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "65"
    },
    {
      "t": 66581,
      "e": 65624,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 66645,
      "e": 65688,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "USA"
    },
    {
      "t": 66702,
      "e": 65745,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "USA"
    },
    {
      "t": 66709,
      "e": 65752,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "USA"
    },
    {
      "t": 67205,
      "e": 66248,
      "ty": 7,
      "x": 1005,
      "y": 681,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 67206,
      "e": 66249,
      "ty": 6,
      "x": 1005,
      "y": 681,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 67208,
      "e": 66251,
      "ty": 2,
      "x": 1005,
      "y": 681
    },
    {
      "t": 67222,
      "e": 66265,
      "ty": 7,
      "x": 1064,
      "y": 691,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 67254,
      "e": 66297,
      "ty": 41,
      "x": 37502,
      "y": 37947,
      "ta": "html > body"
    },
    {
      "t": 67306,
      "e": 66349,
      "ty": 2,
      "x": 1098,
      "y": 693
    },
    {
      "t": 67405,
      "e": 66448,
      "ty": 6,
      "x": 1022,
      "y": 693,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 67405,
      "e": 66448,
      "ty": 2,
      "x": 1022,
      "y": 693
    },
    {
      "t": 67506,
      "e": 66549,
      "ty": 2,
      "x": 1004,
      "y": 695
    },
    {
      "t": 67506,
      "e": 66549,
      "ty": 41,
      "x": 55702,
      "y": 37732,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 67570,
      "e": 66613,
      "ty": 3,
      "x": 1000,
      "y": 695,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 67571,
      "e": 66614,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "USA"
    },
    {
      "t": 67572,
      "e": 66615,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 67573,
      "e": 66616,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 67605,
      "e": 66648,
      "ty": 2,
      "x": 1000,
      "y": 695
    },
    {
      "t": 67641,
      "e": 66684,
      "ty": 4,
      "x": 53640,
      "y": 37732,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 67642,
      "e": 66685,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 67642,
      "e": 66685,
      "ty": 5,
      "x": 1000,
      "y": 695,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 67642,
      "e": 66685,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 67756,
      "e": 66799,
      "ty": 41,
      "x": 34162,
      "y": 38057,
      "ta": "html > body"
    },
    {
      "t": 67905,
      "e": 66948,
      "ty": 2,
      "x": 1018,
      "y": 673
    },
    {
      "t": 68006,
      "e": 67049,
      "ty": 2,
      "x": 1008,
      "y": 541
    },
    {
      "t": 68006,
      "e": 67049,
      "ty": 41,
      "x": 34437,
      "y": 29526,
      "ta": "html > body"
    },
    {
      "t": 68106,
      "e": 67149,
      "ty": 2,
      "x": 1001,
      "y": 532
    },
    {
      "t": 68256,
      "e": 67299,
      "ty": 41,
      "x": 34196,
      "y": 29028,
      "ta": "html > body"
    },
    {
      "t": 68606,
      "e": 67649,
      "ty": 2,
      "x": 1001,
      "y": 531
    },
    {
      "t": 68655,
      "e": 67698,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 68706,
      "e": 67749,
      "ty": 2,
      "x": 1023,
      "y": 518
    },
    {
      "t": 68756,
      "e": 67749,
      "ty": 41,
      "x": 52348,
      "y": 53832,
      "ta": "#jspsych-survey-multi-choice-option-1-3"
    },
    {
      "t": 68806,
      "e": 67799,
      "ty": 2,
      "x": 1051,
      "y": 502
    },
    {
      "t": 68905,
      "e": 67898,
      "ty": 2,
      "x": 1056,
      "y": 500
    },
    {
      "t": 69006,
      "e": 67999,
      "ty": 2,
      "x": 1057,
      "y": 499
    },
    {
      "t": 69006,
      "e": 67999,
      "ty": 41,
      "x": 55908,
      "y": 32767,
      "ta": "#jspsych-survey-multi-choice-option-1-3"
    },
    {
      "t": 69106,
      "e": 68099,
      "ty": 2,
      "x": 1039,
      "y": 424
    },
    {
      "t": 69205,
      "e": 68198,
      "ty": 2,
      "x": 964,
      "y": 350
    },
    {
      "t": 69255,
      "e": 68248,
      "ty": 41,
      "x": 29090,
      "y": 39789,
      "ta": "#jspsych-survey-multi-choice-option-0-3"
    },
    {
      "t": 69305,
      "e": 68298,
      "ty": 2,
      "x": 900,
      "y": 307
    },
    {
      "t": 69406,
      "e": 68399,
      "ty": 2,
      "x": 889,
      "y": 285
    },
    {
      "t": 69505,
      "e": 68498,
      "ty": 2,
      "x": 862,
      "y": 260
    },
    {
      "t": 69505,
      "e": 68498,
      "ty": 41,
      "x": 30905,
      "y": 9830,
      "ta": "#jspsych-survey-multi-choice-option-0-1 > label"
    },
    {
      "t": 69605,
      "e": 68598,
      "ty": 2,
      "x": 859,
      "y": 254
    },
    {
      "t": 69706,
      "e": 68699,
      "ty": 2,
      "x": 862,
      "y": 239
    },
    {
      "t": 69755,
      "e": 68748,
      "ty": 3,
      "x": 862,
      "y": 239,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 69757,
      "e": 68750,
      "ty": 41,
      "x": 33228,
      "y": 32767,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 69841,
      "e": 68834,
      "ty": 4,
      "x": 33228,
      "y": 32767,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 69841,
      "e": 68834,
      "ty": 5,
      "x": 862,
      "y": 239,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 69841,
      "e": 68834,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 69842,
      "e": 68835,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf",
      "v": "English"
    },
    {
      "t": 70006,
      "e": 68999,
      "ty": 2,
      "x": 857,
      "y": 263
    },
    {
      "t": 70006,
      "e": 68999,
      "ty": 41,
      "x": 27097,
      "y": 19660,
      "ta": "#jspsych-survey-multi-choice-option-0-1 > label"
    },
    {
      "t": 70105,
      "e": 69098,
      "ty": 2,
      "x": 864,
      "y": 355
    },
    {
      "t": 70205,
      "e": 69198,
      "ty": 2,
      "x": 868,
      "y": 386
    },
    {
      "t": 70255,
      "e": 69248,
      "ty": 41,
      "x": 11766,
      "y": 12186,
      "ta": "#jspsych-survey-multi-choice-1"
    },
    {
      "t": 70304,
      "e": 69297,
      "ty": 2,
      "x": 872,
      "y": 420
    },
    {
      "t": 70405,
      "e": 69398,
      "ty": 2,
      "x": 873,
      "y": 424
    },
    {
      "t": 70505,
      "e": 69498,
      "ty": 41,
      "x": 60377,
      "y": 62258,
      "ta": "#jspsych-survey-multi-choice-option-1-0 > label"
    },
    {
      "t": 70905,
      "e": 69898,
      "ty": 2,
      "x": 874,
      "y": 424
    },
    {
      "t": 71005,
      "e": 69998,
      "ty": 41,
      "x": 61547,
      "y": 62258,
      "ta": "#jspsych-survey-multi-choice-option-1-0 > label"
    },
    {
      "t": 71204,
      "e": 70197,
      "ty": 2,
      "x": 868,
      "y": 420
    },
    {
      "t": 71255,
      "e": 70248,
      "ty": 41,
      "x": 54524,
      "y": 49151,
      "ta": "#jspsych-survey-multi-choice-option-1-0 > label"
    },
    {
      "t": 71305,
      "e": 70298,
      "ty": 2,
      "x": 866,
      "y": 420
    },
    {
      "t": 71404,
      "e": 70397,
      "ty": 2,
      "x": 864,
      "y": 490
    },
    {
      "t": 71504,
      "e": 70497,
      "ty": 2,
      "x": 867,
      "y": 533
    },
    {
      "t": 71504,
      "e": 70497,
      "ty": 41,
      "x": 53338,
      "y": 52428,
      "ta": "#jspsych-survey-multi-choice-option-1-4 > label"
    },
    {
      "t": 71605,
      "e": 70598,
      "ty": 2,
      "x": 867,
      "y": 541
    },
    {
      "t": 71704,
      "e": 70697,
      "ty": 2,
      "x": 867,
      "y": 542
    },
    {
      "t": 71755,
      "e": 70748,
      "ty": 41,
      "x": 10816,
      "y": 2340,
      "ta": "#jspsych-survey-multi-choice-option-1-5"
    },
    {
      "t": 71904,
      "e": 70897,
      "ty": 2,
      "x": 865,
      "y": 532
    },
    {
      "t": 72005,
      "e": 70998,
      "ty": 2,
      "x": 865,
      "y": 522
    },
    {
      "t": 72005,
      "e": 70998,
      "ty": 41,
      "x": 50998,
      "y": 16383,
      "ta": "#jspsych-survey-multi-choice-option-1-4 > label"
    },
    {
      "t": 72104,
      "e": 71097,
      "ty": 2,
      "x": 864,
      "y": 503
    },
    {
      "t": 72204,
      "e": 71197,
      "ty": 2,
      "x": 866,
      "y": 499
    },
    {
      "t": 72255,
      "e": 71248,
      "ty": 41,
      "x": 40010,
      "y": 32767,
      "ta": "#jspsych-survey-multi-choice-option-1-3 > label"
    },
    {
      "t": 72266,
      "e": 71259,
      "ty": 3,
      "x": 866,
      "y": 499,
      "ta": "#jspsych-survey-multi-choice-option-1-3 > label"
    },
    {
      "t": 72267,
      "e": 71260,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 72330,
      "e": 71323,
      "ty": 4,
      "x": 40010,
      "y": 32767,
      "ta": "#jspsych-survey-multi-choice-option-1-3 > label"
    },
    {
      "t": 72330,
      "e": 71323,
      "ty": 5,
      "x": 866,
      "y": 499,
      "ta": "#jspsych-survey-multi-choice-option-1-3 > label"
    },
    {
      "t": 72332,
      "e": 71325,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 72335,
      "e": 71328,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf",
      "v": "Fourth"
    },
    {
      "t": 72605,
      "e": 71598,
      "ty": 2,
      "x": 907,
      "y": 552
    },
    {
      "t": 72705,
      "e": 71698,
      "ty": 2,
      "x": 967,
      "y": 613
    },
    {
      "t": 72755,
      "e": 71748,
      "ty": 41,
      "x": 34549,
      "y": 33776,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 72805,
      "e": 71798,
      "ty": 2,
      "x": 967,
      "y": 615
    },
    {
      "t": 72904,
      "e": 71897,
      "ty": 2,
      "x": 963,
      "y": 629
    },
    {
      "t": 73005,
      "e": 71998,
      "ty": 2,
      "x": 957,
      "y": 639
    },
    {
      "t": 73005,
      "e": 71998,
      "ty": 41,
      "x": 32176,
      "y": 56172,
      "ta": "#jspsych-survey-multi-choice-2 > p"
    },
    {
      "t": 73256,
      "e": 72249,
      "ty": 41,
      "x": 31701,
      "y": 56172,
      "ta": "#jspsych-survey-multi-choice-2 > p"
    },
    {
      "t": 73304,
      "e": 72297,
      "ty": 2,
      "x": 949,
      "y": 641
    },
    {
      "t": 73405,
      "e": 72398,
      "ty": 2,
      "x": 943,
      "y": 646
    },
    {
      "t": 73505,
      "e": 72498,
      "ty": 41,
      "x": 28853,
      "y": 8394,
      "ta": "#jspsych-survey-multi-choice-2"
    },
    {
      "t": 73705,
      "e": 72698,
      "ty": 2,
      "x": 965,
      "y": 635
    },
    {
      "t": 73755,
      "e": 72748,
      "ty": 41,
      "x": 34074,
      "y": 46810,
      "ta": "#jspsych-survey-multi-choice-2 > p"
    },
    {
      "t": 73905,
      "e": 72898,
      "ty": 2,
      "x": 963,
      "y": 637
    },
    {
      "t": 74005,
      "e": 72998,
      "ty": 2,
      "x": 956,
      "y": 667
    },
    {
      "t": 74005,
      "e": 72998,
      "ty": 41,
      "x": 36134,
      "y": 6553,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 74105,
      "e": 73098,
      "ty": 2,
      "x": 940,
      "y": 696
    },
    {
      "t": 74204,
      "e": 73197,
      "ty": 2,
      "x": 934,
      "y": 701
    },
    {
      "t": 74255,
      "e": 73248,
      "ty": 41,
      "x": 27863,
      "y": 29490,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 74305,
      "e": 73298,
      "ty": 2,
      "x": 929,
      "y": 709
    },
    {
      "t": 74405,
      "e": 73398,
      "ty": 2,
      "x": 924,
      "y": 738
    },
    {
      "t": 74505,
      "e": 73498,
      "ty": 2,
      "x": 923,
      "y": 752
    },
    {
      "t": 74505,
      "e": 73498,
      "ty": 41,
      "x": 42383,
      "y": 9830,
      "ta": "#jspsych-survey-multi-choice-option-2-3 > label"
    },
    {
      "t": 74605,
      "e": 73598,
      "ty": 2,
      "x": 927,
      "y": 773
    },
    {
      "t": 74705,
      "e": 73698,
      "ty": 2,
      "x": 965,
      "y": 724
    },
    {
      "t": 74754,
      "e": 73747,
      "ty": 41,
      "x": 38698,
      "y": 9830,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 74805,
      "e": 73798,
      "ty": 2,
      "x": 981,
      "y": 676
    },
    {
      "t": 74905,
      "e": 73898,
      "ty": 2,
      "x": 985,
      "y": 665
    },
    {
      "t": 75004,
      "e": 73997,
      "ty": 2,
      "x": 982,
      "y": 667
    },
    {
      "t": 75006,
      "e": 73999,
      "ty": 41,
      "x": 43115,
      "y": 6553,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 75075,
      "e": 74068,
      "ty": 3,
      "x": 978,
      "y": 671,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 75076,
      "e": 74069,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 75105,
      "e": 74098,
      "ty": 2,
      "x": 978,
      "y": 671
    },
    {
      "t": 75137,
      "e": 74130,
      "ty": 4,
      "x": 42041,
      "y": 19660,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 75137,
      "e": 74130,
      "ty": 5,
      "x": 978,
      "y": 671,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 75137,
      "e": 74130,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 75139,
      "e": 74132,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf",
      "v": "Math or Computer Sciences"
    },
    {
      "t": 75204,
      "e": 74197,
      "ty": 2,
      "x": 977,
      "y": 672
    },
    {
      "t": 75254,
      "e": 74247,
      "ty": 41,
      "x": 39893,
      "y": 49151,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 75305,
      "e": 74298,
      "ty": 2,
      "x": 954,
      "y": 714
    },
    {
      "t": 75405,
      "e": 74398,
      "ty": 2,
      "x": 949,
      "y": 784
    },
    {
      "t": 75505,
      "e": 74498,
      "ty": 2,
      "x": 945,
      "y": 806
    },
    {
      "t": 75505,
      "e": 74498,
      "ty": 41,
      "x": 29328,
      "y": 11702,
      "ta": "#jspsych-survey-multi-choice-option-2-5"
    },
    {
      "t": 75605,
      "e": 74598,
      "ty": 2,
      "x": 942,
      "y": 812
    },
    {
      "t": 75755,
      "e": 74748,
      "ty": 41,
      "x": 28616,
      "y": 25745,
      "ta": "#jspsych-survey-multi-choice-option-2-5"
    },
    {
      "t": 76205,
      "e": 75198,
      "ty": 2,
      "x": 924,
      "y": 826
    },
    {
      "t": 76255,
      "e": 75248,
      "ty": 41,
      "x": 22445,
      "y": 35108,
      "ta": "#jspsych-survey-multi-choice-option-2-6"
    },
    {
      "t": 76305,
      "e": 75298,
      "ty": 2,
      "x": 910,
      "y": 874
    },
    {
      "t": 76405,
      "e": 75398,
      "ty": 2,
      "x": 907,
      "y": 890
    },
    {
      "t": 76505,
      "e": 75498,
      "ty": 2,
      "x": 906,
      "y": 898
    },
    {
      "t": 76505,
      "e": 75498,
      "ty": 41,
      "x": 20072,
      "y": 53832,
      "ta": "#jspsych-survey-multi-choice-3 > p"
    },
    {
      "t": 76756,
      "e": 75498,
      "ty": 41,
      "x": 19835,
      "y": 53832,
      "ta": "#jspsych-survey-multi-choice-3 > p"
    },
    {
      "t": 76805,
      "e": 75547,
      "ty": 2,
      "x": 901,
      "y": 898
    },
    {
      "t": 76905,
      "e": 75647,
      "ty": 2,
      "x": 895,
      "y": 898
    },
    {
      "t": 77005,
      "e": 75747,
      "ty": 2,
      "x": 883,
      "y": 892
    },
    {
      "t": 77005,
      "e": 75747,
      "ty": 41,
      "x": 14614,
      "y": 39789,
      "ta": "#jspsych-survey-multi-choice-3 > p"
    },
    {
      "t": 77105,
      "e": 75847,
      "ty": 2,
      "x": 881,
      "y": 896
    },
    {
      "t": 77205,
      "e": 75947,
      "ty": 2,
      "x": 870,
      "y": 942
    },
    {
      "t": 77255,
      "e": 75997,
      "ty": 41,
      "x": 11054,
      "y": 2340,
      "ta": "#jspsych-survey-multi-choice-option-3-1"
    },
    {
      "t": 77305,
      "e": 76047,
      "ty": 2,
      "x": 866,
      "y": 954
    },
    {
      "t": 77405,
      "e": 76147,
      "ty": 2,
      "x": 865,
      "y": 956
    },
    {
      "t": 77505,
      "e": 76247,
      "ty": 41,
      "x": 35251,
      "y": 9830,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 77605,
      "e": 76347,
      "ty": 2,
      "x": 865,
      "y": 950
    },
    {
      "t": 77705,
      "e": 76447,
      "ty": 2,
      "x": 869,
      "y": 941
    },
    {
      "t": 77755,
      "e": 76497,
      "ty": 41,
      "x": 53059,
      "y": 42597,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 77805,
      "e": 76547,
      "ty": 2,
      "x": 870,
      "y": 938
    },
    {
      "t": 77818,
      "e": 76560,
      "ty": 3,
      "x": 870,
      "y": 938,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 77819,
      "e": 76561,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 77882,
      "e": 76624,
      "ty": 4,
      "x": 53059,
      "y": 42597,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 77882,
      "e": 76624,
      "ty": 5,
      "x": 870,
      "y": 938,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 77883,
      "e": 76625,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 77885,
      "e": 76627,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf",
      "v": "Male"
    },
    {
      "t": 78005,
      "e": 76747,
      "ty": 2,
      "x": 884,
      "y": 976
    },
    {
      "t": 78005,
      "e": 76747,
      "ty": 41,
      "x": 14851,
      "y": 63194,
      "ta": "#jspsych-survey-multi-choice-option-3-1"
    },
    {
      "t": 78080,
      "e": 76822,
      "ty": 6,
      "x": 898,
      "y": 1006,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 78105,
      "e": 76847,
      "ty": 2,
      "x": 903,
      "y": 1016
    },
    {
      "t": 78205,
      "e": 76947,
      "ty": 2,
      "x": 905,
      "y": 1018
    },
    {
      "t": 78256,
      "e": 76998,
      "ty": 41,
      "x": 38952,
      "y": 25816,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 78299,
      "e": 77041,
      "ty": 3,
      "x": 905,
      "y": 1018,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 78300,
      "e": 77042,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 78301,
      "e": 77043,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 78337,
      "e": 77079,
      "ty": 4,
      "x": 38952,
      "y": 25816,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 78337,
      "e": 77079,
      "ty": 5,
      "x": 905,
      "y": 1018,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 78339,
      "e": 77081,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 78339,
      "e": 77081,
      "ty": 13,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 78340,
      "e": 77082,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 78505,
      "e": 77247,
      "ty": 2,
      "x": 906,
      "y": 1018
    },
    {
      "t": 78505,
      "e": 77247,
      "ty": 41,
      "x": 30925,
      "y": 55951,
      "ta": "html > body"
    },
    {
      "t": 78605,
      "e": 77347,
      "ty": 2,
      "x": 689,
      "y": 923
    },
    {
      "t": 78705,
      "e": 77447,
      "ty": 2,
      "x": 580,
      "y": 719
    },
    {
      "t": 78755,
      "e": 77497,
      "ty": 41,
      "x": 19491,
      "y": 37725,
      "ta": "html > body"
    },
    {
      "t": 78805,
      "e": 77547,
      "ty": 2,
      "x": 574,
      "y": 670
    },
    {
      "t": 78904,
      "e": 77646,
      "ty": 2,
      "x": 627,
      "y": 567
    },
    {
      "t": 79005,
      "e": 77747,
      "ty": 2,
      "x": 661,
      "y": 519
    },
    {
      "t": 79005,
      "e": 77747,
      "ty": 41,
      "x": 22487,
      "y": 28308,
      "ta": "html > body"
    },
    {
      "t": 79405,
      "e": 78147,
      "ty": 2,
      "x": 662,
      "y": 517
    },
    {
      "t": 79505,
      "e": 78247,
      "ty": 41,
      "x": 22522,
      "y": 28197,
      "ta": "html > body"
    },
    {
      "t": 79605,
      "e": 78347,
      "ty": 2,
      "x": 655,
      "y": 522
    },
    {
      "t": 79688,
      "e": 78430,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 79755,
      "e": 78497,
      "ty": 41,
      "x": 17787,
      "y": 15414,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 80105,
      "e": 78847,
      "ty": 2,
      "x": 683,
      "y": 499
    },
    {
      "t": 80205,
      "e": 78947,
      "ty": 2,
      "x": 760,
      "y": 409
    },
    {
      "t": 80255,
      "e": 78997,
      "ty": 41,
      "x": 22608,
      "y": 13665,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 80305,
      "e": 79047,
      "ty": 2,
      "x": 617,
      "y": 368
    },
    {
      "t": 80406,
      "e": 79148,
      "ty": 2,
      "x": 400,
      "y": 343
    },
    {
      "t": 80505,
      "e": 79247,
      "ty": 2,
      "x": 392,
      "y": 353
    },
    {
      "t": 80506,
      "e": 79248,
      "ty": 41,
      "x": 4848,
      "y": 43336,
      "ta": "> div.masterdiv > div:[2] > div > p"
    },
    {
      "t": 80605,
      "e": 79347,
      "ty": 2,
      "x": 409,
      "y": 387
    },
    {
      "t": 80706,
      "e": 79448,
      "ty": 2,
      "x": 420,
      "y": 396
    },
    {
      "t": 80755,
      "e": 79497,
      "ty": 41,
      "x": 46909,
      "y": 57394,
      "ta": "> div.masterdiv > div:[2] > div > p:[2] > b"
    },
    {
      "t": 80805,
      "e": 79547,
      "ty": 2,
      "x": 449,
      "y": 420
    },
    {
      "t": 80905,
      "e": 79647,
      "ty": 2,
      "x": 460,
      "y": 427
    },
    {
      "t": 81005,
      "e": 79747,
      "ty": 2,
      "x": 462,
      "y": 425
    },
    {
      "t": 81006,
      "e": 79748,
      "ty": 41,
      "x": 8291,
      "y": 34730,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 81105,
      "e": 79847,
      "ty": 2,
      "x": 478,
      "y": 400
    },
    {
      "t": 81205,
      "e": 79947,
      "ty": 2,
      "x": 483,
      "y": 395
    },
    {
      "t": 81255,
      "e": 79997,
      "ty": 41,
      "x": 9423,
      "y": 8984,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 81298,
      "e": 80040,
      "ty": 3,
      "x": 485,
      "y": 392,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 81306,
      "e": 80048,
      "ty": 2,
      "x": 485,
      "y": 392
    },
    {
      "t": 81405,
      "e": 80147,
      "ty": 2,
      "x": 529,
      "y": 414
    },
    {
      "t": 81505,
      "e": 80247,
      "ty": 2,
      "x": 548,
      "y": 423
    },
    {
      "t": 81506,
      "e": 80248,
      "ty": 41,
      "x": 12522,
      "y": 33169,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 81602,
      "e": 80344,
      "ty": 4,
      "x": 12965,
      "y": 40191,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 81602,
      "e": 80344,
      "ty": 5,
      "x": 557,
      "y": 432,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 81605,
      "e": 80347,
      "ty": 2,
      "x": 557,
      "y": 432
    },
    {
      "t": 81705,
      "e": 80447,
      "ty": 2,
      "x": 625,
      "y": 505
    },
    {
      "t": 81755,
      "e": 80497,
      "ty": 41,
      "x": 17295,
      "y": 26337,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 81805,
      "e": 80547,
      "ty": 2,
      "x": 695,
      "y": 652
    },
    {
      "t": 81905,
      "e": 80647,
      "ty": 2,
      "x": 975,
      "y": 974
    },
    {
      "t": 82009,
      "e": 80651,
      "ty": 2,
      "x": 1049,
      "y": 1078
    },
    {
      "t": 82010,
      "e": 80652,
      "ty": 41,
      "x": 35849,
      "y": 59275,
      "ta": "> div.masterdiv"
    },
    {
      "t": 82105,
      "e": 80747,
      "ty": 2,
      "x": 1063,
      "y": 1124
    },
    {
      "t": 82206,
      "e": 80848,
      "ty": 2,
      "x": 1059,
      "y": 1124
    },
    {
      "t": 82234,
      "e": 80876,
      "ty": 6,
      "x": 1009,
      "y": 1102,
      "ta": "#start"
    },
    {
      "t": 82255,
      "e": 80897,
      "ty": 41,
      "x": 53247,
      "y": 54572,
      "ta": "#start"
    },
    {
      "t": 82304,
      "e": 80946,
      "ty": 2,
      "x": 1006,
      "y": 1101
    },
    {
      "t": 82405,
      "e": 81047,
      "ty": 2,
      "x": 992,
      "y": 1094
    },
    {
      "t": 82466,
      "e": 81108,
      "ty": 3,
      "x": 978,
      "y": 1091,
      "ta": "#start"
    },
    {
      "t": 82466,
      "e": 81108,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 82505,
      "e": 81147,
      "ty": 2,
      "x": 978,
      "y": 1091
    },
    {
      "t": 82505,
      "e": 81147,
      "ty": 41,
      "x": 37409,
      "y": 35297,
      "ta": "#start"
    },
    {
      "t": 82529,
      "e": 81171,
      "ty": 4,
      "x": 37409,
      "y": 35297,
      "ta": "#start"
    },
    {
      "t": 82531,
      "e": 81173,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 82531,
      "e": 81173,
      "ty": 5,
      "x": 978,
      "y": 1091,
      "ta": "#start"
    },
    {
      "t": 82532,
      "e": 81174,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 82704,
      "e": 81346,
      "ty": 2,
      "x": 856,
      "y": 937
    },
    {
      "t": 82755,
      "e": 81397,
      "ty": 41,
      "x": 22660,
      "y": 31798,
      "ta": "html > body"
    },
    {
      "t": 82805,
      "e": 81447,
      "ty": 2,
      "x": 527,
      "y": 112
    },
    {
      "t": 82906,
      "e": 81548,
      "ty": 2,
      "x": 591,
      "y": 0
    },
    {
      "t": 83005,
      "e": 81647,
      "ty": 2,
      "x": 593,
      "y": 0
    },
    {
      "t": 83005,
      "e": 81647,
      "ty": 41,
      "x": 20421,
      "y": 0,
      "ta": "html"
    },
    {
      "t": 83105,
      "e": 81747,
      "ty": 2,
      "x": 640,
      "y": 144
    },
    {
      "t": 83205,
      "e": 81847,
      "ty": 2,
      "x": 661,
      "y": 179
    },
    {
      "t": 83256,
      "e": 81898,
      "ty": 41,
      "x": 22487,
      "y": 9472,
      "ta": "html > body"
    },
    {
      "t": 83570,
      "e": 82212,
      "ty": 38,
      "x": 8,
      "y": 0
    },
    {
      "t": 84405,
      "e": 83047,
      "ty": 2,
      "x": 662,
      "y": 179
    },
    {
      "t": 84505,
      "e": 83147,
      "ty": 41,
      "x": 22965,
      "y": 32659,
      "ta": "#jspsych-data-display"
    },
    {
      "t": 84605,
      "e": 83247,
      "ty": 2,
      "x": 630,
      "y": 201
    },
    {
      "t": 84705,
      "e": 83347,
      "ty": 2,
      "x": 347,
      "y": 255
    },
    {
      "t": 84756,
      "e": 83398,
      "ty": 41,
      "x": 11006,
      "y": 32677,
      "ta": "#jspsych-data-display"
    },
    {
      "t": 84805,
      "e": 83447,
      "ty": 2,
      "x": 281,
      "y": 219
    },
    {
      "t": 84832,
      "e": 83474,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":56},{\"id\":57},{\"id\":58},{\"id\":59},{\"id\":60},{\"id\":61},{\"id\":62},{\"id\":63},{\"id\":64},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":72},{\"id\":73},{\"id\":74},{\"id\":75},{\"id\":76},{\"id\":77},{\"id\":78},{\"id\":79},{\"id\":80},{\"id\":81},{\"id\":82},{\"id\":83},{\"id\":84},{\"id\":85},{\"id\":86},{\"id\":87},{\"id\":88},{\"id\":89},{\"id\":90},{\"id\":91},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":96},{\"id\":97},{\"id\":98},{\"id\":99},{\"id\":100},{\"id\":101},{\"id\":102},{\"id\":103},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":109},{\"id\":110},{\"id\":111},{\"id\":112},{\"id\":113},{\"id\":114},{\"id\":115},{\"id\":116},{\"id\":117},{\"id\":118},{\"id\":119},{\"id\":120},{\"id\":121},{\"id\":122},{\"id\":123},{\"id\":124},{\"id\":125},{\"id\":126},{\"id\":127},{\"id\":128},{\"id\":129},{\"id\":130},{\"id\":131},{\"id\":132},{\"id\":133},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":141},{\"id\":142},{\"id\":143},{\"id\":144},{\"id\":145},{\"id\":146},{\"id\":147},{\"id\":148},{\"id\":149},{\"id\":150},{\"id\":151},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":155},{\"id\":156},{\"id\":157},{\"id\":158},{\"id\":159},{\"id\":160},{\"id\":161},{\"id\":162},{\"id\":163},{\"id\":164},{\"id\":165},{\"id\":166},{\"id\":167},{\"id\":168},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":172},{\"id\":173},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":178},{\"id\":179},{\"id\":180},{\"id\":181},{\"id\":182},{\"id\":183},{\"id\":184},{\"id\":185},{\"id\":186},{\"id\":187},{\"id\":188},{\"id\":189},{\"id\":190},{\"id\":191},{\"id\":192},{\"id\":193},{\"id\":194},{\"id\":195},{\"id\":196},{\"id\":197},{\"id\":198},{\"id\":199},{\"id\":200},{\"id\":201},{\"id\":202},{\"id\":203},{\"id\":204},{\"id\":205},{\"id\":206},{\"id\":207},{\"id\":208},{\"id\":209},{\"id\":210},{\"id\":211},{\"id\":212},{\"id\":213},{\"id\":214},{\"id\":215},{\"id\":216},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":220},{\"id\":221},{\"id\":222},{\"id\":223},{\"id\":224},{\"id\":225},{\"id\":226},{\"id\":227},{\"id\":228},{\"id\":229},{\"id\":230},{\"id\":231},{\"id\":232},{\"id\":233},{\"id\":234},{\"id\":235},{\"id\":236},{\"id\":237},{\"id\":238},{\"id\":239},{\"id\":240},{\"id\":241},{\"id\":242},{\"id\":243},{\"id\":244},{\"id\":245},{\"id\":246},{\"id\":247},{\"id\":248},{\"id\":249},{\"id\":250},{\"id\":251},{\"id\":252},{\"id\":253},{\"id\":254},{\"id\":255},{\"id\":256},{\"id\":257},{\"id\":258},{\"id\":259},{\"id\":260},{\"id\":261},{\"id\":262},{\"id\":263},{\"id\":264},{\"id\":265},{\"id\":266},{\"id\":267},{\"id\":268},{\"id\":269},{\"id\":270},{\"id\":271},{\"id\":272},{\"id\":273},{\"id\":274},{\"id\":275},{\"id\":276},{\"id\":277},{\"id\":278},{\"id\":279},{\"id\":280},{\"id\":281},{\"id\":282},{\"id\":283},{\"id\":284},{\"id\":285},{\"id\":286},{\"id\":287},{\"id\":288},{\"id\":289},{\"id\":290},{\"id\":291},{\"id\":292},{\"id\":293},{\"id\":294},{\"id\":295},{\"id\":296},{\"id\":297},{\"id\":298},{\"id\":299},{\"id\":300},{\"id\":301},{\"id\":302},{\"id\":303},{\"id\":304},{\"id\":305},{\"id\":306},{\"id\":307},{\"id\":308},{\"id\":309},{\"id\":310},{\"id\":311},{\"id\":312},{\"id\":313},{\"id\":314},{\"id\":315},{\"id\":316},{\"id\":317},{\"id\":318},{\"id\":319},{\"id\":320},{\"id\":321},{\"id\":322},{\"id\":323},{\"id\":324},{\"id\":325},{\"id\":326},{\"id\":327},{\"id\":328},{\"id\":329},{\"id\":330},{\"id\":331},{\"id\":332},{\"id\":333},{\"id\":334},{\"id\":335},{\"id\":336},{\"id\":337},{\"id\":338},{\"id\":339},{\"id\":340},{\"id\":341},{\"id\":342},{\"id\":343},{\"id\":344},{\"id\":345},{\"id\":346},{\"id\":347},{\"id\":348},{\"id\":349},{\"id\":350},{\"id\":351},{\"id\":352},{\"id\":353},{\"id\":354},{\"id\":355},{\"id\":356},{\"id\":357},{\"id\":358},{\"id\":359},{\"id\":360},{\"id\":361},{\"id\":362},{\"id\":363},{\"id\":364},{\"id\":365},{\"id\":366},{\"id\":367},{\"id\":368},{\"id\":369},{\"id\":370},{\"id\":371},{\"id\":372},{\"id\":373},{\"id\":374},{\"id\":375},{\"id\":376},{\"id\":377},{\"id\":378},{\"id\":379},{\"id\":380},{\"id\":381},{\"id\":382},{\"id\":383},{\"id\":384},{\"id\":385},{\"id\":386},{\"id\":387},{\"id\":388},{\"id\":389},{\"id\":390},{\"id\":391},{\"id\":392},{\"id\":393},{\"id\":394},{\"id\":395},{\"id\":396},{\"id\":397},{\"id\":398},{\"id\":399},{\"id\":400},{\"id\":401},{\"id\":402},{\"id\":403},{\"id\":404},{\"id\":405},{\"id\":406},{\"id\":407},{\"id\":408},{\"id\":409},{\"id\":410},{\"id\":411},{\"id\":412},{\"id\":413},{\"id\":414},{\"id\":415},{\"id\":416},{\"id\":417},{\"id\":418},{\"id\":419},{\"id\":420},{\"id\":421},{\"id\":422},{\"id\":423},{\"id\":424},{\"id\":425},{\"id\":426},{\"id\":427},{\"id\":428},{\"id\":429},{\"id\":430},{\"id\":431},{\"id\":432},{\"id\":433},{\"id\":434},{\"id\":435},{\"id\":436},{\"id\":437},{\"id\":438},{\"id\":439},{\"id\":440},{\"id\":441},{\"id\":442},{\"id\":443},{\"id\":444},{\"id\":445},{\"id\":446},{\"id\":447},{\"id\":448},{\"id\":449},{\"id\":450},{\"id\":451},{\"id\":452},{\"id\":453},{\"id\":454},{\"id\":455},{\"id\":456},{\"id\":457},{\"id\":458},{\"id\":459},{\"id\":460},{\"id\":461},{\"id\":462},{\"id\":463},{\"id\":464},{\"id\":465},{\"id\":466},{\"id\":467},{\"id\":468},{\"id\":469},{\"id\":470},{\"id\":471},{\"id\":472},{\"id\":473},{\"id\":474},{\"id\":475},{\"id\":476},{\"id\":477},{\"id\":478},{\"id\":479},{\"id\":480},{\"id\":481},{\"id\":482},{\"id\":483},{\"id\":484},{\"id\":485},{\"id\":486},{\"id\":487},{\"id\":488},{\"id\":489},{\"id\":490},{\"id\":491},{\"id\":492},{\"id\":493},{\"id\":494},{\"id\":495},{\"id\":496},{\"id\":497},{\"id\":498},{\"id\":499},{\"id\":500},{\"id\":501},{\"id\":502},{\"id\":503},{\"id\":504},{\"id\":505},{\"id\":506},{\"id\":507},{\"id\":508},{\"id\":509},{\"id\":510},{\"id\":511},{\"id\":512},{\"id\":513},{\"id\":514},{\"id\":515},{\"id\":516},{\"id\":517},{\"id\":518},{\"id\":519},{\"id\":520},{\"id\":521},{\"id\":522},{\"id\":523},{\"id\":524},{\"id\":525},{\"id\":526},{\"id\":527},{\"id\":528},{\"id\":529},{\"id\":530},{\"id\":531},{\"id\":532},{\"id\":533},{\"id\":534},{\"id\":535},{\"id\":536},{\"id\":537},{\"id\":538},{\"id\":539},{\"id\":540},{\"id\":541},{\"id\":542},{\"id\":543},{\"id\":544},{\"id\":545},{\"id\":546},{\"id\":547},{\"id\":548},{\"id\":549},{\"id\":550},{\"id\":551},{\"id\":552},{\"id\":553},{\"id\":554},{\"id\":555},{\"id\":556},{\"id\":557},{\"id\":558},{\"id\":559},{\"id\":560},{\"id\":561},{\"id\":562},{\"id\":563},{\"id\":564},{\"id\":565},{\"id\":566},{\"id\":567},{\"id\":568},{\"id\":569},{\"id\":570},{\"id\":571},{\"id\":572},{\"id\":573},{\"id\":574},{\"id\":575},{\"id\":576},{\"id\":577},{\"id\":578},{\"id\":579},{\"id\":580},{\"id\":581},{\"id\":582},{\"id\":583},{\"id\":584},{\"id\":585},{\"id\":586},{\"id\":587},{\"id\":588},{\"id\":589},{\"id\":590},{\"id\":591},{\"id\":592},{\"id\":593},{\"id\":594},{\"id\":595},{\"id\":596},{\"id\":597},{\"id\":598},{\"id\":599},{\"id\":600},{\"id\":601},{\"id\":602},{\"id\":603},{\"id\":604},{\"id\":605},{\"id\":606},{\"id\":607},{\"id\":608},{\"id\":609},{\"id\":610},{\"id\":611},{\"id\":612},{\"id\":613},{\"id\":614},{\"id\":615},{\"id\":616},{\"id\":617},{\"id\":618},{\"id\":619},{\"id\":620},{\"id\":621},{\"id\":622},{\"id\":623},{\"id\":624},{\"id\":625},{\"id\":626},{\"id\":627},{\"id\":628},{\"id\":629},{\"id\":630},{\"id\":631},{\"id\":632},{\"id\":633},{\"id\":634},{\"id\":635},{\"id\":636},{\"id\":637},{\"id\":638},{\"id\":639},{\"id\":640},{\"id\":641},{\"id\":642},{\"id\":643},{\"id\":644},{\"id\":645},{\"id\":646},{\"id\":647},{\"id\":648},{\"id\":649},{\"id\":650},{\"id\":651},{\"id\":652},{\"id\":653},{\"id\":654},{\"id\":655},{\"id\":656},{\"id\":657},{\"id\":658},{\"id\":659},{\"id\":660},{\"id\":661},{\"id\":662},{\"id\":663},{\"id\":664},{\"id\":665},{\"id\":666},{\"id\":667},{\"id\":668},{\"id\":669},{\"id\":670},{\"id\":671},{\"id\":672},{\"id\":673},{\"id\":674},{\"id\":675},{\"id\":676},{\"id\":677},{\"id\":678},{\"id\":679},{\"id\":680},{\"id\":681},{\"id\":682},{\"id\":683},{\"id\":684},{\"id\":685},{\"id\":686},{\"id\":687},{\"id\":688},{\"id\":689},{\"id\":690},{\"id\":691},{\"id\":692},{\"id\":693},{\"id\":694},{\"id\":695},{\"id\":696},{\"id\":697},{\"id\":698},{\"id\":699},{\"id\":700},{\"id\":701},{\"id\":702},{\"id\":703},{\"id\":704},{\"id\":705},{\"id\":706},{\"id\":707},{\"id\":708},{\"id\":709},{\"id\":710},{\"id\":711},{\"id\":712},{\"id\":713},{\"id\":714},{\"id\":715},{\"id\":716},{\"id\":717},{\"id\":718},{\"id\":719},{\"id\":720},{\"id\":721},{\"id\":722},{\"id\":723},{\"id\":724},{\"id\":725},{\"id\":726},{\"id\":727},{\"id\":728},{\"id\":729},{\"id\":730},{\"id\":731},{\"id\":732},{\"id\":733},{\"id\":734},{\"id\":735},{\"id\":736},{\"id\":737},{\"id\":738},{\"id\":739},{\"id\":740},{\"id\":741},{\"id\":742},{\"id\":743},{\"id\":744},{\"id\":745},{\"id\":746},{\"id\":747},{\"id\":748},{\"id\":749},{\"id\":750},{\"id\":751},{\"id\":752},{\"id\":753},{\"id\":754},{\"id\":755},{\"id\":756},{\"id\":757},{\"id\":758},{\"id\":759},{\"id\":760},{\"id\":761},{\"id\":762},{\"id\":763},{\"id\":764},{\"id\":765},{\"id\":766},{\"id\":767},{\"id\":768},{\"id\":769},{\"id\":770},{\"id\":771},{\"id\":772},{\"id\":773},{\"id\":774},{\"id\":775},{\"id\":776},{\"id\":777},{\"id\":778},{\"id\":779},{\"id\":780},{\"id\":781},{\"id\":782},{\"id\":783},{\"id\":784},{\"id\":785},{\"id\":786},{\"id\":787},{\"id\":788},{\"id\":789},{\"id\":790},{\"id\":791},{\"id\":792},{\"id\":793},{\"id\":794},{\"id\":795},{\"id\":796},{\"id\":797},{\"id\":798},{\"id\":799},{\"id\":800},{\"id\":801},{\"id\":802},{\"id\":803},{\"id\":804},{\"id\":805},{\"id\":806},{\"id\":807},{\"id\":808},{\"id\":809},{\"id\":810},{\"id\":811},{\"id\":812},{\"id\":813},{\"id\":814},{\"id\":815},{\"id\":816},{\"id\":817},{\"id\":818},{\"id\":819},{\"id\":820},{\"id\":821},{\"id\":822},{\"id\":823},{\"id\":824},{\"id\":825},{\"id\":826},{\"id\":827},{\"id\":828},{\"id\":829},{\"id\":830},{\"id\":831},{\"id\":832},{\"id\":833},{\"id\":834},{\"id\":835},{\"id\":836},{\"id\":837},{\"id\":838},{\"id\":839},{\"id\":840},{\"id\":841},{\"id\":842},{\"id\":843},{\"id\":844},{\"id\":845},{\"id\":846},{\"id\":847},{\"id\":848},{\"id\":849},{\"id\":850},{\"id\":851},{\"id\":852},{\"id\":853},{\"id\":854},{\"id\":855},{\"id\":856},{\"id\":857},{\"id\":858},{\"id\":859},{\"id\":860},{\"id\":861},{\"id\":862},{\"id\":863},{\"id\":864},{\"id\":865},{\"id\":866},{\"id\":867},{\"id\":868},{\"id\":869},{\"id\":870},{\"id\":871},{\"id\":872},{\"id\":873},{\"id\":874},{\"id\":875},{\"id\":876},{\"id\":877},{\"id\":878},{\"id\":879},{\"id\":880},{\"id\":881},{\"id\":882},{\"id\":883},{\"id\":884},{\"id\":885},{\"id\":886},{\"id\":887},{\"id\":888},{\"id\":889},{\"id\":890},{\"id\":891},{\"id\":892},{\"id\":893},{\"id\":894},{\"id\":895},{\"id\":896},{\"id\":897},{\"id\":898},{\"id\":899},{\"id\":900},{\"id\":901},{\"id\":902},{\"id\":903},{\"id\":904},{\"id\":905},{\"id\":906},{\"id\":907},{\"id\":908},{\"id\":909},{\"id\":910},{\"id\":911},{\"id\":912},{\"id\":913},{\"id\":914},{\"id\":915},{\"id\":916},{\"id\":917},{\"id\":918},{\"id\":919},{\"id\":920},{\"id\":921},{\"id\":922},{\"id\":923},{\"id\":924},{\"id\":925},{\"id\":926},{\"id\":927},{\"id\":928},{\"id\":929},{\"id\":930},{\"id\":931},{\"id\":932},{\"id\":933},{\"id\":934},{\"id\":935},{\"id\":936},{\"id\":937},{\"id\":938},{\"id\":939},{\"id\":940},{\"id\":941},{\"id\":942},{\"id\":943},{\"id\":944},{\"id\":945},{\"id\":946},{\"id\":947},{\"id\":948},{\"id\":949},{\"id\":950},{\"id\":951},{\"id\":952},{\"id\":953},{\"id\":954},{\"id\":955},{\"id\":956},{\"id\":957},{\"id\":958},{\"id\":959},{\"id\":960},{\"id\":961},{\"id\":962},{\"id\":963},{\"id\":964},{\"id\":965},{\"id\":966},{\"id\":967},{\"id\":968},{\"id\":969},{\"id\":970},{\"id\":971},{\"id\":972},{\"id\":973},{\"id\":974},{\"id\":975},{\"id\":976},{\"id\":977},{\"id\":978},{\"id\":979},{\"id\":980},{\"id\":981},{\"id\":982},{\"id\":983},{\"id\":984},{\"id\":985},{\"id\":986},{\"id\":987},{\"id\":988},{\"id\":989},{\"id\":990},{\"id\":991},{\"id\":992},{\"id\":993},{\"id\":994},{\"id\":995},{\"id\":996},{\"id\":997},{\"id\":998},{\"id\":999},{\"id\":1000},{\"id\":1001},{\"id\":1002},{\"id\":1003},{\"id\":1004},{\"id\":1005},{\"id\":1006},{\"id\":1007},{\"id\":1008},{\"id\":1009},{\"id\":1010},{\"id\":1011},{\"id\":1012},{\"id\":1013},{\"id\":1014},{\"id\":1015},{\"id\":1016},{\"id\":1017},{\"id\":1018},{\"id\":1019},{\"id\":1020},{\"id\":1021},{\"id\":1022},{\"id\":1023},{\"id\":1024},{\"id\":1025},{\"id\":1026},{\"id\":1027},{\"id\":1028},{\"id\":1029},{\"id\":1030},{\"id\":1031},{\"id\":1032},{\"id\":1033},{\"id\":1034},{\"id\":1035},{\"id\":1036},{\"id\":1037},{\"id\":1038},{\"id\":1039},{\"id\":1040},{\"id\":1041},{\"id\":1042},{\"id\":1043},{\"id\":1044},{\"id\":1045},{\"id\":1046},{\"id\":1047},{\"id\":1048},{\"id\":1049},{\"id\":1050},{\"id\":1051},{\"id\":1052},{\"id\":1053},{\"id\":1054},{\"id\":1055},{\"id\":1056},{\"id\":1057},{\"id\":1058},{\"id\":1059},{\"id\":1060},{\"id\":1061},{\"id\":1062},{\"id\":1063},{\"id\":1064},{\"id\":1065},{\"id\":1066},{\"id\":1067},{\"id\":1068},{\"id\":1069},{\"id\":1070},{\"id\":1071},{\"id\":1072},{\"id\":1073},{\"id\":1074},{\"id\":1075},{\"id\":1076},{\"id\":1077},{\"id\":1078},{\"id\":1079},{\"id\":1080},{\"id\":1081},{\"id\":1082},{\"id\":1083},{\"id\":1084},{\"id\":1085},{\"id\":1086},{\"id\":1087},{\"id\":1088},{\"id\":1089},{\"id\":1090},{\"id\":1091},{\"id\":1092},{\"id\":1093},{\"id\":1094},{\"id\":1095},{\"id\":1096},{\"id\":1097},{\"id\":1098},{\"id\":1099},{\"id\":1100},{\"id\":1101},{\"id\":1102},{\"id\":1103},{\"id\":1104},{\"id\":1105},{\"id\":1106},{\"id\":1107},{\"id\":1108},{\"id\":1109},{\"id\":1110},{\"id\":1111},{\"id\":1112},{\"id\":1113},{\"id\":1114},{\"id\":1115},{\"id\":1116},{\"id\":1117},{\"id\":1118},{\"id\":1119},{\"id\":1120},{\"id\":1121},{\"id\":1122},{\"id\":1123},{\"id\":1124},{\"id\":1125},{\"id\":1126},{\"id\":1127},{\"id\":1128},{\"id\":1129},{\"id\":1130},{\"id\":1131},{\"id\":1132},{\"id\":1133},{\"id\":1134},{\"id\":1135},{\"id\":1136},{\"id\":1137},{\"id\":1138},{\"id\":1139},{\"id\":1140},{\"id\":1141},{\"id\":1142},{\"id\":1143},{\"id\":1144},{\"id\":1145},{\"id\":1146},{\"id\":1147},{\"id\":1148},{\"id\":1149},{\"id\":1150},{\"id\":1151},{\"id\":1152},{\"id\":1153},{\"id\":1154},{\"id\":1155},{\"id\":1156},{\"id\":1157},{\"id\":1158},{\"id\":1159},{\"id\":1160},{\"id\":1161},{\"id\":1162},{\"id\":1163},{\"id\":1164},{\"id\":1165},{\"id\":1166},{\"id\":1167},{\"id\":1168},{\"id\":1169},{\"id\":1170},{\"id\":1171},{\"id\":1172},{\"id\":1173},{\"id\":1174},{\"id\":1175},{\"id\":1176},{\"id\":1177},{\"id\":1178},{\"id\":1179},{\"id\":1180},{\"id\":1181},{\"id\":1182},{\"id\":1183},{\"id\":1184},{\"id\":1185},{\"id\":1186},{\"id\":1187},{\"id\":1188},{\"id\":1189},{\"id\":1190},{\"id\":1191},{\"id\":1192},{\"id\":1193},{\"id\":1194},{\"id\":1195},{\"id\":1196},{\"id\":1197},{\"id\":1198},{\"id\":1199},{\"id\":1200},{\"id\":1201},{\"id\":1202},{\"id\":1203},{\"id\":1204},{\"id\":1205},{\"id\":1206},{\"id\":1207},{\"id\":1208},{\"id\":1209},{\"id\":1210},{\"id\":1211},{\"id\":1212},{\"id\":1213},{\"id\":1214},{\"id\":1215},{\"id\":1216},{\"id\":1217},{\"id\":1218},{\"id\":1219},{\"id\":1220},{\"id\":1221},{\"id\":1222},{\"id\":1223},{\"id\":1224},{\"id\":1225},{\"id\":1226},{\"id\":1227},{\"id\":1228},{\"id\":1229},{\"id\":1230},{\"id\":1231},{\"id\":1232},{\"id\":1233},{\"id\":1234},{\"id\":1235},{\"id\":1236},{\"id\":1237},{\"id\":1238},{\"id\":1239},{\"id\":1240},{\"id\":1241},{\"id\":1242},{\"id\":1243},{\"id\":1244},{\"id\":1245},{\"id\":1246},{\"id\":1247},{\"id\":1248},{\"id\":1249},{\"id\":1250},{\"id\":1251},{\"id\":1252},{\"id\":1253},{\"id\":1254},{\"id\":1255},{\"id\":1256},{\"id\":1257},{\"id\":1258},{\"id\":1259},{\"id\":1260},{\"id\":1261},{\"id\":1262},{\"id\":1263},{\"id\":1264},{\"id\":1265},{\"id\":1266},{\"id\":1267},{\"id\":1268},{\"id\":1269},{\"id\":1270},{\"id\":1271},{\"id\":1272},{\"id\":1273},{\"id\":1274},{\"id\":1275},{\"id\":1276},{\"id\":1277},{\"id\":1278},{\"id\":1279},{\"id\":1280},{\"id\":1281},{\"id\":1282},{\"id\":1283},{\"id\":1284},{\"id\":1285},{\"id\":1286},{\"id\":1287},{\"id\":1288},{\"id\":1289},{\"id\":1290},{\"id\":1291},{\"id\":1292},{\"id\":1293},{\"id\":1294},{\"id\":1295},{\"id\":1296},{\"id\":1297},{\"id\":1298},{\"id\":1299},{\"id\":1300},{\"id\":1301},{\"id\":1302},{\"id\":1303},{\"id\":1304},{\"id\":1305},{\"id\":1306},{\"id\":1307},{\"id\":1308},{\"id\":1309},{\"id\":1310},{\"id\":1311},{\"id\":1312},{\"id\":1313},{\"id\":1314},{\"id\":1315},{\"id\":1316},{\"id\":1317},{\"id\":1318},{\"id\":1319},{\"id\":1320},{\"id\":1321},{\"id\":1322},{\"id\":1323},{\"id\":1324},{\"id\":1325},{\"id\":1326},{\"id\":1327},{\"id\":1328},{\"id\":1329},{\"id\":1330},{\"id\":1331},{\"id\":1332},{\"id\":1333},{\"id\":1334},{\"id\":1335},{\"id\":1336},{\"id\":1337},{\"id\":1338},{\"id\":1339},{\"id\":1340},{\"id\":1341},{\"id\":1342},{\"id\":1343},{\"id\":1344},{\"id\":1345},{\"id\":1346},{\"id\":1347},{\"id\":1348},{\"id\":1349},{\"id\":1350},{\"id\":1351},{\"id\":1352},{\"id\":1353},{\"id\":1354},{\"id\":1355},{\"id\":1356},{\"id\":1357},{\"id\":1358},{\"id\":1359},{\"id\":1360},{\"id\":1361},{\"id\":1362},{\"id\":1363},{\"id\":1364},{\"id\":1365},{\"id\":1366},{\"id\":1367},{\"id\":1368},{\"id\":1369},{\"id\":1370},{\"id\":1371},{\"id\":1372},{\"id\":1373},{\"id\":1374},{\"id\":1375},{\"id\":1376},{\"id\":1377},{\"id\":1378},{\"id\":1379},{\"id\":1380},{\"id\":1381},{\"id\":1382},{\"id\":1383},{\"id\":1384},{\"id\":1385},{\"id\":1386},{\"id\":1387},{\"id\":1388},{\"id\":1389},{\"id\":1390},{\"id\":1391},{\"id\":1392},{\"id\":1393},{\"id\":1394},{\"id\":1395},{\"id\":1396},{\"id\":1397},{\"id\":1398},{\"id\":1399},{\"id\":1400},{\"id\":1401},{\"id\":1402},{\"id\":1403},{\"id\":1404},{\"id\":1405},{\"id\":1406},{\"id\":1407},{\"id\":1408},{\"id\":1409},{\"id\":1410},{\"id\":1411},{\"id\":1412},{\"id\":1413},{\"id\":1414},{\"id\":1415},{\"id\":1416},{\"id\":1417},{\"id\":1418},{\"id\":1419},{\"id\":1420},{\"id\":1421},{\"id\":1422},{\"id\":1423},{\"id\":1424},{\"id\":1425},{\"id\":1426},{\"id\":1427},{\"id\":1428},{\"id\":1429},{\"id\":1430},{\"id\":1431},{\"id\":1432},{\"id\":1433},{\"id\":1434},{\"id\":1435},{\"id\":1436},{\"id\":1437},{\"id\":1438},{\"id\":1439},{\"id\":1440},{\"id\":1441},{\"id\":1442},{\"id\":1443},{\"id\":1444},{\"id\":1445},{\"id\":1446},{\"id\":1447},{\"id\":1448},{\"id\":1449},{\"id\":1450},{\"id\":1451},{\"id\":1452},{\"id\":1453},{\"id\":1454},{\"id\":1455},{\"id\":1456},{\"id\":1457},{\"id\":1458},{\"id\":1459},{\"id\":1460},{\"id\":1461},{\"id\":1462},{\"id\":1463},{\"id\":1464},{\"id\":1465},{\"id\":1466},{\"id\":1467},{\"id\":1468},{\"id\":1469},{\"id\":1470},{\"id\":1471},{\"id\":1472},{\"id\":1473},{\"id\":1474},{\"id\":1475},{\"id\":1476},{\"id\":1477},{\"id\":1478},{\"id\":1479},{\"id\":1480},{\"id\":1481},{\"id\":1482},{\"id\":1483},{\"id\":1484},{\"id\":1485},{\"id\":1486},{\"id\":1487},{\"id\":1488},{\"id\":1489},{\"id\":1490},{\"id\":1491},{\"id\":1492},{\"id\":1493},{\"id\":1494},{\"id\":1495},{\"id\":1496},{\"id\":1497},{\"id\":1498},{\"id\":1499},{\"id\":1500},{\"id\":1501},{\"id\":1502},{\"id\":1503},{\"id\":1504},{\"id\":1505},{\"id\":1506},{\"id\":1507},{\"id\":1508},{\"id\":1509},{\"id\":1510},{\"id\":1511},{\"id\":1512},{\"id\":1513},{\"id\":1514},{\"id\":1515},{\"id\":1516},{\"id\":1517},{\"id\":1518},{\"id\":1519},{\"id\":1520},{\"id\":1521},{\"id\":1522},{\"id\":1523},{\"id\":1524},{\"id\":1525},{\"id\":1526},{\"id\":1527},{\"id\":1528},{\"id\":1529},{\"id\":1530},{\"id\":1531},{\"id\":1532},{\"id\":1533},{\"id\":1534},{\"id\":1535},{\"id\":1536},{\"id\":1537},{\"id\":1538},{\"id\":1539},{\"id\":1540},{\"id\":1541},{\"id\":1542},{\"id\":1543},{\"id\":1544},{\"id\":1545},{\"id\":1546},{\"id\":1547},{\"id\":1548},{\"id\":1549},{\"id\":1550},{\"id\":1551},{\"id\":1552},{\"id\":1553},{\"id\":1554},{\"id\":1555},{\"id\":1556},{\"id\":1557},{\"id\":1558},{\"id\":1559},{\"id\":1560},{\"id\":1561},{\"id\":1562},{\"id\":1563},{\"id\":1564},{\"id\":1565},{\"id\":1566},{\"id\":1567},{\"id\":1568},{\"id\":1569},{\"id\":1570},{\"id\":1571},{\"id\":1572},{\"id\":1573},{\"id\":1574},{\"id\":1575},{\"id\":1576},{\"id\":1577},{\"id\":1578},{\"id\":1579},{\"id\":1580},{\"id\":1581},{\"id\":1582},{\"id\":1583},{\"id\":1584},{\"id\":1585},{\"id\":1586},{\"id\":1587},{\"id\":1588},{\"id\":1589},{\"id\":1590},{\"id\":1591},{\"id\":1592},{\"id\":1593},{\"id\":1594},{\"id\":1595},{\"id\":1596},{\"id\":1597},{\"id\":1598},{\"id\":1599},{\"id\":1600},{\"id\":1601},{\"id\":1602},{\"id\":1603},{\"id\":1604},{\"id\":1605},{\"id\":1606},{\"id\":1607},{\"id\":1608},{\"id\":1609},{\"id\":1610},{\"id\":1611},{\"id\":1612},{\"id\":1613},{\"id\":1614},{\"id\":1615},{\"id\":1616},{\"id\":1617},{\"id\":1618},{\"id\":1619},{\"id\":1620},{\"id\":1621},{\"id\":1622},{\"id\":1623},{\"id\":1624},{\"id\":1625},{\"id\":1626},{\"id\":1627},{\"id\":1628},{\"id\":1629},{\"id\":1630},{\"id\":1631},{\"id\":1632},{\"id\":1633},{\"id\":1634},{\"id\":1635},{\"id\":1636},{\"id\":1637},{\"id\":1638},{\"id\":1639},{\"id\":1640},{\"id\":1641},{\"id\":1642},{\"id\":1643},{\"id\":1644},{\"id\":1645},{\"id\":1646},{\"id\":1647},{\"id\":1648},{\"id\":1649},{\"id\":1650},{\"id\":1651},{\"id\":1652},{\"id\":1653},{\"id\":1654},{\"id\":1655},{\"id\":1656},{\"id\":1657},{\"id\":1658},{\"id\":1659},{\"id\":1660},{\"id\":1661},{\"id\":1662},{\"id\":1663},{\"id\":1664},{\"id\":1665},{\"id\":1666},{\"id\":1667},{\"id\":1668},{\"id\":1669},{\"id\":1670},{\"id\":1671},{\"id\":1672},{\"id\":1673},{\"id\":1674},{\"id\":1675},{\"id\":1676},{\"id\":1677},{\"id\":1678},{\"id\":1679},{\"id\":1680},{\"id\":1681},{\"id\":1682},{\"id\":1683},{\"id\":1684},{\"id\":1685},{\"id\":1686},{\"id\":1687},{\"id\":1688},{\"id\":1689},{\"id\":1690},{\"id\":1691},{\"id\":1692},{\"id\":1693},{\"id\":1694},{\"id\":1695},{\"id\":1696},{\"id\":1697},{\"id\":1698},{\"id\":1699},{\"id\":1700},{\"id\":1701},{\"id\":1702},{\"id\":1703},{\"id\":1704},{\"id\":1705},{\"id\":1706},{\"id\":1707},{\"id\":1708},{\"id\":1709},{\"id\":1710},{\"id\":1711},{\"id\":1712},{\"id\":1713},{\"id\":1714},{\"id\":1715},{\"id\":1716},{\"id\":1717},{\"id\":1718},{\"id\":1719},{\"id\":1720},{\"id\":1721},{\"id\":1722},{\"id\":1723},{\"id\":1724},{\"id\":1725},{\"id\":1726},{\"id\":1727},{\"id\":1728},{\"id\":1729},{\"id\":1730},{\"id\":1731},{\"id\":1732},{\"id\":1733},{\"id\":1734},{\"id\":1735},{\"id\":1736},{\"id\":1737},{\"id\":1738},{\"id\":1739},{\"id\":1740},{\"id\":1741},{\"id\":1742},{\"id\":1743},{\"id\":1744},{\"id\":1745},{\"id\":1746},{\"id\":1747},{\"id\":1748},{\"id\":1749},{\"id\":1750},{\"id\":1751},{\"id\":1752},{\"id\":1753},{\"id\":1754},{\"id\":1755},{\"id\":1756},{\"id\":1757},{\"id\":1758},{\"id\":1759},{\"id\":1760},{\"id\":1761},{\"id\":1762},{\"id\":1763},{\"id\":1764},{\"id\":1765},{\"id\":1766},{\"id\":1767},{\"id\":1768},{\"id\":1769},{\"id\":1770},{\"id\":1771},{\"id\":1772},{\"id\":1773},{\"id\":1774},{\"id\":1775},{\"id\":1776},{\"id\":1777},{\"id\":1778},{\"id\":1779},{\"id\":1780},{\"id\":1781},{\"id\":1782},{\"id\":1783},{\"id\":1784},{\"id\":1785},{\"id\":1786},{\"id\":1787},{\"id\":1788},{\"id\":1789},{\"id\":1790},{\"id\":1791},{\"id\":1792},{\"id\":1793},{\"id\":1794},{\"id\":1795},{\"id\":1796},{\"id\":1797},{\"id\":1798},{\"id\":1799},{\"id\":1800},{\"id\":1801},{\"id\":1802},{\"id\":1803},{\"id\":1804},{\"id\":1805},{\"id\":1806},{\"id\":1807},{\"id\":1808},{\"id\":1809},{\"id\":1810},{\"id\":1811},{\"id\":1812},{\"id\":1813},{\"id\":1814},{\"id\":1815},{\"id\":1816},{\"id\":1817},{\"id\":1818},{\"id\":1819},{\"id\":1820},{\"id\":1821},{\"id\":1822},{\"id\":1823},{\"id\":1824},{\"id\":1825},{\"id\":1826},{\"id\":1827},{\"id\":1828},{\"id\":1829},{\"id\":1830},{\"id\":1831},{\"id\":1832},{\"id\":1833},{\"id\":1834},{\"id\":1835},{\"id\":1836},{\"id\":1837},{\"id\":1838},{\"id\":1839},{\"id\":1840},{\"id\":1841},{\"id\":1842},{\"id\":1843},{\"id\":1844},{\"id\":1845},{\"id\":1846},{\"id\":1847},{\"id\":1848},{\"id\":1849},{\"id\":1850},{\"id\":1851},{\"id\":1852},{\"id\":1853},{\"id\":1854},{\"id\":1855},{\"id\":1856},{\"id\":1857},{\"id\":1858},{\"id\":1859},{\"id\":1860},{\"id\":1861},{\"id\":1862},{\"id\":1863},{\"id\":1864},{\"id\":1865},{\"id\":1866},{\"id\":1867},{\"id\":1868},{\"id\":1869},{\"id\":1870},{\"id\":1871},{\"id\":1872},{\"id\":1873},{\"id\":1874},{\"id\":1875},{\"id\":1876},{\"id\":1877},{\"id\":1878},{\"id\":1879},{\"id\":1880},{\"id\":1881},{\"id\":1882},{\"id\":1883},{\"id\":1884},{\"id\":1885},{\"id\":1886},{\"id\":1887},{\"id\":1888},{\"id\":1889},{\"id\":1890},{\"id\":1891},{\"id\":1892},{\"id\":1893},{\"id\":1894},{\"id\":1895},{\"id\":1896},{\"id\":1897},{\"id\":1898},{\"id\":1899},{\"id\":1900},{\"id\":1901},{\"id\":1902},{\"id\":1903},{\"id\":1904},{\"id\":1905},{\"id\":1906},{\"id\":1907},{\"id\":1908},{\"id\":1909},{\"id\":1910},{\"id\":1911},{\"id\":1912},{\"id\":1913},{\"id\":1914},{\"id\":1915},{\"id\":1916},{\"id\":1917},{\"id\":1918},{\"id\":1919},{\"id\":1920},{\"id\":1921},{\"id\":1922},{\"id\":1923},{\"id\":1924},{\"id\":1925},{\"id\":1926},{\"id\":1927},{\"id\":1928},{\"id\":1929},{\"id\":1930},{\"id\":1931},{\"id\":1932},{\"id\":1933},{\"id\":1934},{\"id\":1935},{\"id\":1936},{\"id\":1937},{\"id\":1938},{\"id\":1939},{\"id\":1940},{\"id\":1941},{\"id\":1942},{\"id\":1943},{\"id\":1944},{\"id\":1945},{\"id\":1946},{\"id\":1947},{\"id\":1948},{\"id\":1949},{\"id\":1950},{\"id\":1951},{\"id\":1952},{\"id\":1953},{\"id\":1954},{\"id\":1955},{\"id\":1956},{\"id\":1957},{\"id\":1958},{\"id\":1959},{\"id\":1960},{\"id\":1961},{\"id\":1962},{\"id\":1963},{\"id\":1964},{\"id\":1965},{\"id\":1966},{\"id\":1967},{\"id\":1968},{\"id\":1969},{\"id\":1970},{\"id\":1971},{\"id\":1972},{\"id\":1973},{\"id\":1974},{\"id\":1975},{\"id\":1976},{\"id\":1977},{\"id\":1978},{\"id\":1979},{\"id\":1980},{\"id\":1981},{\"id\":1982},{\"id\":1983},{\"id\":1984},{\"id\":1985},{\"id\":1986},{\"id\":1987},{\"id\":1988},{\"id\":1989},{\"id\":1990},{\"id\":1991},{\"id\":1992},{\"id\":1993},{\"id\":1994},{\"id\":1995},{\"id\":1996},{\"id\":1997},{\"id\":1998},{\"id\":1999},{\"id\":2000},{\"id\":2001},{\"id\":2002},{\"id\":2003},{\"id\":2004},{\"id\":2005},{\"id\":2006},{\"id\":2007},{\"id\":2008},{\"id\":2009},{\"id\":2010},{\"id\":2011},{\"id\":2012},{\"id\":2013},{\"id\":2014},{\"id\":2015},{\"id\":2016},{\"id\":2017},{\"id\":2018},{\"id\":2019},{\"id\":2020},{\"id\":2021},{\"id\":2022},{\"id\":2023},{\"id\":2024},{\"id\":2025},{\"id\":2026},{\"id\":2027},{\"id\":2028},{\"id\":2029},{\"id\":2030},{\"id\":2031},{\"id\":2032},{\"id\":2033},{\"id\":2034},{\"id\":2035},{\"id\":2036},{\"id\":2037},{\"id\":2038},{\"id\":2039},{\"id\":2040},{\"id\":2041},{\"id\":2042},{\"id\":2043},{\"id\":2044},{\"id\":2045},{\"id\":2046},{\"id\":2047},{\"id\":2048},{\"id\":2049},{\"id\":2050},{\"id\":2051},{\"id\":2052},{\"id\":2053},{\"id\":2054},{\"id\":2055},{\"id\":2056},{\"id\":2057},{\"id\":2058},{\"id\":2059},{\"id\":2060},{\"id\":2061},{\"id\":2062},{\"id\":2063},{\"id\":2064},{\"id\":2065},{\"id\":2066},{\"id\":2067},{\"id\":2068},{\"id\":2069},{\"id\":2070},{\"id\":2071},{\"id\":2072},{\"id\":2073},{\"id\":2074},{\"id\":2075},{\"id\":2076},{\"id\":2077},{\"id\":2078},{\"id\":2079},{\"id\":2080},{\"id\":2081},{\"id\":2082},{\"id\":2083},{\"id\":2084},{\"id\":2085},{\"id\":2086},{\"id\":2087},{\"id\":2088},{\"id\":2089},{\"id\":2090},{\"id\":2091},{\"id\":2092},{\"id\":2093},{\"id\":2094},{\"id\":2095},{\"id\":2096},{\"id\":2097},{\"id\":2098},{\"id\":2099},{\"id\":2100},{\"id\":2101},{\"id\":2102},{\"id\":2103},{\"id\":2104},{\"id\":2105},{\"id\":2106},{\"id\":2107},{\"id\":2108},{\"id\":2109},{\"id\":2110},{\"id\":2111},{\"id\":2112},{\"id\":2113},{\"id\":2114},{\"id\":2115},{\"id\":2116},{\"id\":2117},{\"id\":2118},{\"id\":2119},{\"id\":2120},{\"id\":2121},{\"id\":2122},{\"id\":2123},{\"id\":2124},{\"id\":2125},{\"id\":2126},{\"id\":2127},{\"id\":2128},{\"id\":2129},{\"id\":2130},{\"id\":2131},{\"id\":2132},{\"id\":2133},{\"id\":2134},{\"id\":2135},{\"id\":2136},{\"id\":2137},{\"id\":2138},{\"id\":2139},{\"id\":2140},{\"id\":2141},{\"id\":2142},{\"id\":2143},{\"id\":2144},{\"id\":2145},{\"id\":2146},{\"id\":2147},{\"id\":2148},{\"id\":2149},{\"id\":2150},{\"id\":2151},{\"id\":2152},{\"id\":2153},{\"id\":2154},{\"id\":2155},{\"id\":2156},{\"id\":2157},{\"id\":2158},{\"id\":2159},{\"id\":2160},{\"id\":2161},{\"id\":2162},{\"id\":2163},{\"id\":2164},{\"id\":2165},{\"id\":2166},{\"id\":2167},{\"id\":2168},{\"id\":2169},{\"id\":2170},{\"id\":2171},{\"id\":2172},{\"id\":2173},{\"id\":2174},{\"id\":2175},{\"id\":2176},{\"id\":2177},{\"id\":2178},{\"id\":2179},{\"id\":2180},{\"id\":2181},{\"id\":2182},{\"id\":2183},{\"id\":2184},{\"id\":2185},{\"id\":2186},{\"id\":2187},{\"id\":2188},{\"id\":2189},{\"id\":2190},{\"id\":2191},{\"id\":2192},{\"id\":2193},{\"id\":2194},{\"id\":2195},{\"id\":2196},{\"id\":2197},{\"id\":2198},{\"id\":2199},{\"id\":2200},{\"id\":2201},{\"id\":2202},{\"id\":2203},{\"id\":2204},{\"id\":2205},{\"id\":2206},{\"id\":2207},{\"id\":2208},{\"id\":2209},{\"id\":2210},{\"id\":2211},{\"id\":2212},{\"id\":2213},{\"id\":2214},{\"id\":2215},{\"id\":2216},{\"id\":2217},{\"id\":2218},{\"id\":2219},{\"id\":2220},{\"id\":2221},{\"id\":2222},{\"id\":2223},{\"id\":2224},{\"id\":2225},{\"id\":2226},{\"id\":2227},{\"id\":2228},{\"id\":2229},{\"id\":2230},{\"id\":2231},{\"id\":2232},{\"id\":2233},{\"id\":2234},{\"id\":2235},{\"id\":2236},{\"id\":2237},{\"id\":2238},{\"id\":2239},{\"id\":2240},{\"id\":2241},{\"id\":2242},{\"id\":2243},{\"id\":2244},{\"id\":2245},{\"id\":2246},{\"id\":2247},{\"id\":2248},{\"id\":2249},{\"id\":2250},{\"id\":2251},{\"id\":2252},{\"id\":2253},{\"id\":2254},{\"id\":2255},{\"id\":2256},{\"id\":2257},{\"id\":2258},{\"id\":2259},{\"id\":2260},{\"id\":2261},{\"id\":2262},{\"id\":2263},{\"id\":2264},{\"id\":2265},{\"id\":2266},{\"id\":2267},{\"id\":2268},{\"id\":2269},{\"id\":2270},{\"id\":2271},{\"id\":2272},{\"id\":2273},{\"id\":2274},{\"id\":2275},{\"id\":2276},{\"id\":2277},{\"id\":2278},{\"id\":2279},{\"id\":2280},{\"id\":2281},{\"id\":2282},{\"id\":2283},{\"id\":2284},{\"id\":2285},{\"id\":2286},{\"id\":2287},{\"id\":2288},{\"id\":2289},{\"id\":2290},{\"id\":2291},{\"id\":2292},{\"id\":2293},{\"id\":2294},{\"id\":2295},{\"id\":2296},{\"id\":2297},{\"id\":2298},{\"id\":2299},{\"id\":2300},{\"id\":2301},{\"id\":2302},{\"id\":2303},{\"id\":2304},{\"id\":2305},{\"id\":2306},{\"id\":2307},{\"id\":2308},{\"id\":2309},{\"id\":2310},{\"id\":2311},{\"id\":2312},{\"id\":2313},{\"id\":2314},{\"id\":2315},{\"id\":2316},{\"id\":2317},{\"id\":2318},{\"id\":2319},{\"id\":2320},{\"id\":2321},{\"id\":2322},{\"id\":2323},{\"id\":2324},{\"id\":2325},{\"id\":2326},{\"id\":2327},{\"id\":2328},{\"id\":2329},{\"id\":2330},{\"id\":2331},{\"id\":2332},{\"id\":2333},{\"id\":2334},{\"id\":2335},{\"id\":2336},{\"id\":2337},{\"id\":2338},{\"id\":2339},{\"id\":2340},{\"id\":2341},{\"id\":2342},{\"id\":2343},{\"id\":2344},{\"id\":2345},{\"id\":2346},{\"id\":2347},{\"id\":2348},{\"id\":2349},{\"id\":2350},{\"id\":2351},{\"id\":2352},{\"id\":2353},{\"id\":2354},{\"id\":2355},{\"id\":2356},{\"id\":2357},{\"id\":2358},{\"id\":2359},{\"id\":2360},{\"id\":2361},{\"id\":2362},{\"id\":2363},{\"id\":2364},{\"id\":2365},{\"id\":2366},{\"id\":2367},{\"id\":2368},{\"id\":2369},{\"id\":2370},{\"id\":2371},{\"id\":2372},{\"id\":2373},{\"id\":2374},{\"id\":2375},{\"id\":2376},{\"id\":2377},{\"id\":2378},{\"id\":2379},{\"id\":2380},{\"id\":2381},{\"id\":2382},{\"id\":2383},{\"id\":2384},{\"id\":2385},{\"id\":2386},{\"id\":2387},{\"id\":2388},{\"id\":2389},{\"id\":2390},{\"id\":2391},{\"id\":2392},{\"id\":2393},{\"id\":2394},{\"id\":2395},{\"id\":2396},{\"id\":2397},{\"id\":2398},{\"id\":2399},{\"id\":2400},{\"id\":2401},{\"id\":2402},{\"id\":2403},{\"id\":2404},{\"id\":2405},{\"id\":2406},{\"id\":2407},{\"id\":2408},{\"id\":2409},{\"id\":2410},{\"id\":2411},{\"id\":2412},{\"id\":2413},{\"id\":2414},{\"id\":2415},{\"id\":2416},{\"id\":2417},{\"id\":2418},{\"id\":2419},{\"id\":2420},{\"id\":2421},{\"id\":2422},{\"id\":2423},{\"id\":2424},{\"id\":2425},{\"id\":2426},{\"id\":2427},{\"id\":2428},{\"id\":2429},{\"id\":2430},{\"id\":2431},{\"id\":2432},{\"id\":2433},{\"id\":2434},{\"id\":2435},{\"id\":2436},{\"id\":2437},{\"id\":2438},{\"id\":2439},{\"id\":2440},{\"id\":2441},{\"id\":2442},{\"id\":2443},{\"id\":2444},{\"id\":2445},{\"id\":2446},{\"id\":2447},{\"id\":2448},{\"id\":2449},{\"id\":2450},{\"id\":2451},{\"id\":2452},{\"id\":2453},{\"id\":2454},{\"id\":2455},{\"id\":2456},{\"id\":2457},{\"id\":2458},{\"id\":2459},{\"id\":2460},{\"id\":2461},{\"id\":2462},{\"id\":2463},{\"id\":2464},{\"id\":2465},{\"id\":2466},{\"id\":2467},{\"id\":2468},{\"id\":2469},{\"id\":2470},{\"id\":2471},{\"id\":2472},{\"id\":2473},{\"id\":2474},{\"id\":2475},{\"id\":2476},{\"id\":2477},{\"id\":2478},{\"id\":2479},{\"id\":2480},{\"id\":2481},{\"id\":2482},{\"id\":2483},{\"id\":2484},{\"id\":2485},{\"id\":2486},{\"id\":2487},{\"id\":2488},{\"id\":2489},{\"id\":2490},{\"id\":2491},{\"id\":2492},{\"id\":2493},{\"id\":2494},{\"id\":2495},{\"id\":2496},{\"id\":2497},{\"id\":2498},{\"id\":2499},{\"id\":2500},{\"id\":2501},{\"id\":2502},{\"id\":2503},{\"id\":2504},{\"id\":2505},{\"id\":2506},{\"id\":2507},{\"id\":2508},{\"id\":2509},{\"id\":2510},{\"id\":2511},{\"id\":2512},{\"id\":2513},{\"id\":2514},{\"id\":2515},{\"id\":2516},{\"id\":2517},{\"id\":2518},{\"id\":2519},{\"id\":2520},{\"id\":2521},{\"id\":2522},{\"id\":2523},{\"id\":2524},{\"id\":2525},{\"id\":2526},{\"id\":2527},{\"id\":2528},{\"id\":2529},{\"id\":2530},{\"id\":2531},{\"id\":2532},{\"id\":2533},{\"id\":2534},{\"id\":2535},{\"id\":2536},{\"id\":2537},{\"id\":2538},{\"id\":2539},{\"id\":2540},{\"id\":2541},{\"id\":2542},{\"id\":2543},{\"id\":2544},{\"id\":2545},{\"id\":2546},{\"id\":2547},{\"id\":2548},{\"id\":2549},{\"id\":2550},{\"id\":2551},{\"id\":2552},{\"id\":2553},{\"id\":2554},{\"id\":2555},{\"id\":2556},{\"id\":2557},{\"id\":2558},{\"id\":2559},{\"id\":2560},{\"id\":2561},{\"id\":2562},{\"id\":2563},{\"id\":2564},{\"id\":2565},{\"id\":2566},{\"id\":2567},{\"id\":2568},{\"id\":2569},{\"id\":2570},{\"id\":2571},{\"id\":2572},{\"id\":2573},{\"id\":2574},{\"id\":2575},{\"id\":2576},{\"id\":2577},{\"id\":2578},{\"id\":2579},{\"id\":2580},{\"id\":2581},{\"id\":2582},{\"id\":2583},{\"id\":2584},{\"id\":2585},{\"id\":2586},{\"id\":2587},{\"id\":2588},{\"id\":2589},{\"id\":2590},{\"id\":2591},{\"id\":2592},{\"nodeType\":3,\"id\":2596,\"textContent\":\" // Track clicks on page $(document).ready(function() { $(\\\".control\\\").click(function(e) { e.stopImmediatePropagation(); clicks = clicks + 1; console.log(clicks); }); }); $('.userid').html(sid); // console.log(\\\"start of clicked array: \\\"+clicked); // console.log(\\\"start of hovered string: \\\"+hovered); //set correct answers for each question var triangular_answers = { \\\"acme.starttime.1\\\" : [\\\"F\\\"], \\\"acme.starts.1\\\" : [\\\"K\\\"], \\\"acme.meets.1\\\" : [\\\"F\\\"], \\\"acme.endtime.1\\\" : [\\\"H\\\"], \\\"acme.midpoint.1\\\" : [\\\"O\\\"], \\\"acme.starttime.2\\\" : [\\\"F\\\"], \\\"acme.starts.2\\\" : [\\\"K\\\"], \\\"acme.meets.2\\\" : [\\\"F\\\"], \\\"acme.endtime.2\\\" : [\\\"H\\\"], \\\"acme.midpoint.2\\\" : [\\\"A\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"E\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"E\\\"], \\\"bigset.starttime.1\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.1\\\" : [\\\"G\\\"], \\\"bigset.meets.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.1\\\" : [\\\"X\\\"], \\\"bigset.midpoint.1\\\" : [\\\"K\\\",\\\"X\\\"], \\\"bigset.starttime.2\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.2\\\" : [\\\"G\\\"], \\\"bigset.meets.2\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.2\\\" : [\\\"X\\\"], \\\"bigset.midpoint.2\\\" : [\\\"K\\\",\\\"X\\\"] } var orthogonal_answers = { \\\"acme.starttime.1\\\" : [\\\"A\\\"], \\\"acme.starts.1\\\" : [\\\"E\\\"], \\\"acme.meets.1\\\" : [\\\"Z\\\"], \\\"acme.endtime.1\\\" : [\\\"U\\\"], \\\"acme.midpoint.1\\\" : [\\\"U\\\"], \\\"acme.starttime.2\\\" : [\\\"0\\\"], \\\"acme.starts.2\\\" : [\\\"0\\\"], \\\"acme.meets.2\\\" : [\\\"0\\\"], \\\"acme.endtime.2\\\" : [\\\"0\\\"], \\\"acme.midpoint.2\\\" : [\\\"0\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"X\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"X\\\"], \\\"bigset.starttime.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.1\\\" : [\\\"B\\\"], \\\"bigset.meets.1\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.1\\\" : [\\\"B\\\"], \\\"bigset.midpoint.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.starttime.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.2\\\" : [\\\"B\\\"], \\\"bigset.meets.2\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.2\\\" : [\\\"B\\\"], \\\"bigset.midpoint.2\\\" : [\\\"E\\\",\\\"F\\\"] } //display the question and answer buttons based on input values from jsPsych document.getElementById(scenario+\\\".\\\"+question).style.display = \\\"block\\\"; if (question == \\\"strategy\\\") {document.getElementById(\\\"strategyButton\\\").style.display = \\\"block\\\";} else {document.getElementById(\\\"testingButton\\\").style.display = \\\"block\\\";} //---------SET PROPERTIES OF THE GRAPH -------------// // set the dimensions and margins of the graph var margin = {top: 25, right: 30, bottom: 90, left: 100}, width = 800, height = 800; var intersects = false; //default value for intersects scaffold var xAxisTitle, yAxisTitle; var datafile =\\\"\\\"; // SET AXIS VALUES if (axis == 1){ axis = \\\"Orthogonal-XInside-YFull\\\"; } else if (axis == 2){ axis = \\\"Orthogonal-XInside-YPartial\\\"; } else if (axis ==3){ axis = \\\"Triangular-XInside-YInside\\\"; } else if (axis ==4){ axis = \\\"Orthogonal-XInside-YInside\\\"; } else if (axis ==5){ axis = \\\"Orthogonal-XFull-YFull\\\"; } // SET EXPLICIT SCAFFOLD FEATURES if (explicit ==2 && axis != \\\"diagonal\\\"){ scaffold = 2; intersects = false; } else if (explicit == 2 && axis == \\\"diagonal\\\"){ scaffold = 2; intersects = false; } //TODO: not sure if above two lines are still valid since leaders are now generated on the fly else if (explicit == 3){ $('#hint-interactive').css(\\\"display\\\",\\\"block\\\"); //display textimage scaffold intersects = true; } //SET DATA FILE FOR IMPLICIT SCAFFOLD if (impasse == 1){ datafile = \\\"../views/src/data/acme_nonimpasse.csv\\\"; } else if (impasse == 2){ datafile = \\\"../views/src/data/acme_impasse.csv\\\"; } //OVERRIDE DATA FILE FOR NON-SCAFFOLD QUESTIONS if (q > 5) { //override data file if q# is greater than 5 datafile = \\\"../views/src/data/bigset.csv\\\"; console.log(\\\"override data file\\\"); $('#orthogonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#diagonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#hint-interactive').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold intersects = false; } // //---------CREATE THE SVG ------------------------// var svg = d3.select(\\\".d3container\\\").append(\\\"svg\\\") .attr(\\\"width\\\", width + margin.left + margin.right) .attr(\\\"height\\\", height + margin.top + margin.bottom) .append(\\\"g\\\") .attr(\\\"transform\\\", \\\"translate(\\\" + margin.left + \\\",\\\" + margin.top + \\\")\\\"); //---------DRAW THE GRAPH ------------------------// xAxisTitle = \\\"START & END TIME (time of day)\\\"; yAxisTitle = \\\"DURATION (in hours)\\\"; drawTriangleModel(datafile,intersects,axis,scaffold,q); \"},{\"id\":2593},{\"id\":2594},{\"nodeType\":3,\"id\":2597,\"textContent\":\" //MOUSE LOGGING SCRIPT var mouseLog = [] var xwidth = $(document).width(); var xheight = $(document).width(); mouseLog.push(\\\"{x:\\\"+xwidth+\\\",y:\\\"+xheight+\\\",t:\\\"+\\\"0};\\\") document.onmousemove = function(e){ var pageCoords = \\\"{x:\\\" + e.pageX + \\\",y:\\\"+ e.pageY +\\\",t:\\\"+ Date.now()+ \\\"};\\\" ; mouseLog.push(pageCoords); // console.log(pageCoords); }; \"},{\"id\":2595}],[],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2598,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2599,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2598},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2600,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2599},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2601,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":2600},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2602,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2599}},{\"nodeType\":1,\"id\":2603,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2602},\"parentNode\":{\"id\":2599}},{\"nodeType\":3,\"id\":2604,\"textContent\":\"What is your age?\",\"parentNode\":{\"id\":2602}},{\"nodeType\":1,\"id\":2605,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2600}},{\"nodeType\":1,\"id\":2606,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2605},\"parentNode\":{\"id\":2600}},{\"nodeType\":3,\"id\":2607,\"textContent\":\"In what country were you born?\",\"parentNode\":{\"id\":2605}},{\"nodeType\":3,\"id\":2608,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":2601}}],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2598},{\"id\":2599},{\"id\":2602},{\"id\":2604},{\"id\":2603},{\"id\":2600},{\"id\":2605},{\"id\":2607},{\"id\":2606},{\"id\":2601},{\"id\":2608}],[],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2609,\"tagName\":\"FORM\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-form\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2610,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-preamble\",\"class\":\"jspsych-survey-multi-choice-preamble\"},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2611,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-0\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2610},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2612,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-1\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2611},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2613,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-2\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2612},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2614,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-3\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2613},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2615,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"submit\",\"id\":\"jspsych-survey-multi-choice-next\",\"class\":\"jspsych-survey-multi-choice jspsych-btn\",\"value\":\"Submit Answers\"},\"previousSibling\":{\"id\":2614},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2616,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2617,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2616},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2618,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2617},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2619,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2618},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2620,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2619},\"parentNode\":{\"id\":2611}},{\"nodeType\":3,\"id\":2621,\"textContent\":\"What is your first language?\",\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2622,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2621},\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2623,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2624,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2623}},{\"nodeType\":3,\"id\":2625,\"textContent\":\"English\",\"previousSibling\":{\"id\":2624},\"parentNode\":{\"id\":2623}},{\"nodeType\":1,\"id\":2626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2618}},{\"nodeType\":1,\"id\":2627,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2626}},{\"nodeType\":3,\"id\":2628,\"textContent\":\"Spanish\",\"previousSibling\":{\"id\":2627},\"parentNode\":{\"id\":2626}},{\"nodeType\":1,\"id\":2629,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2619}},{\"nodeType\":1,\"id\":2630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2629}},{\"nodeType\":3,\"id\":2631,\"textContent\":\"Mandarin or Cantonese\",\"previousSibling\":{\"id\":2630},\"parentNode\":{\"id\":2629}},{\"nodeType\":1,\"id\":2632,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2633,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2634,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2633},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2635,\"textContent\":\"*\",\"parentNode\":{\"id\":2622}},{\"nodeType\":1,\"id\":2636,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2637,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2636},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2638,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2637},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2639,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2638},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2640,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2639},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2641,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2640},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2642,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2641},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2643,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2642},\"parentNode\":{\"id\":2612}},{\"nodeType\":3,\"id\":2644,\"textContent\":\"What is your year in school?\",\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2645,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2644},\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2646,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2637}},{\"nodeType\":1,\"id\":2647,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2646}},{\"nodeType\":3,\"id\":2648,\"textContent\":\"First\",\"previousSibling\":{\"id\":2647},\"parentNode\":{\"id\":2646}},{\"nodeType\":1,\"id\":2649,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2638}},{\"nodeType\":1,\"id\":2650,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2649}},{\"nodeType\":3,\"id\":2651,\"textContent\":\"Second\",\"previousSibling\":{\"id\":2650},\"parentNode\":{\"id\":2649}},{\"nodeType\":1,\"id\":2652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2639}},{\"nodeType\":1,\"id\":2653,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2652}},{\"nodeType\":3,\"id\":2654,\"textContent\":\"Third\",\"previousSibling\":{\"id\":2653},\"parentNode\":{\"id\":2652}},{\"nodeType\":1,\"id\":2655,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2640}},{\"nodeType\":1,\"id\":2656,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2655}},{\"nodeType\":3,\"id\":2657,\"textContent\":\"Fourth\",\"previousSibling\":{\"id\":2656},\"parentNode\":{\"id\":2655}},{\"nodeType\":1,\"id\":2658,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2641}},{\"nodeType\":1,\"id\":2659,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2658}},{\"nodeType\":3,\"id\":2660,\"textContent\":\"Fifth\",\"previousSibling\":{\"id\":2659},\"parentNode\":{\"id\":2658}},{\"nodeType\":1,\"id\":2661,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2642}},{\"nodeType\":1,\"id\":2662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2661}},{\"nodeType\":3,\"id\":2663,\"textContent\":\"Graduate\",\"previousSibling\":{\"id\":2662},\"parentNode\":{\"id\":2661}},{\"nodeType\":1,\"id\":2664,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2643}},{\"nodeType\":1,\"id\":2665,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2666,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2665},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2667,\"textContent\":\"*\",\"parentNode\":{\"id\":2645}},{\"nodeType\":1,\"id\":2668,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2669,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2668},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2670,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2669},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2671,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2670},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2672,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2671},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2673,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2672},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2674,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2673},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2675,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2674},\"parentNode\":{\"id\":2613}},{\"nodeType\":3,\"id\":2676,\"textContent\":\"What is your major area of study?\",\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2677,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2676},\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2678,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2669}},{\"nodeType\":1,\"id\":2679,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2678}},{\"nodeType\":3,\"id\":2680,\"textContent\":\"Math or Computer Sciences\",\"previousSibling\":{\"id\":2679},\"parentNode\":{\"id\":2678}},{\"nodeType\":1,\"id\":2681,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2670}},{\"nodeType\":1,\"id\":2682,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2681}},{\"nodeType\":3,\"id\":2683,\"textContent\":\"Social Sciences (incl. CogSci)\",\"previousSibling\":{\"id\":2682},\"parentNode\":{\"id\":2681}},{\"nodeType\":1,\"id\":2684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2671}},{\"nodeType\":1,\"id\":2685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2684}},{\"nodeType\":3,\"id\":2686,\"textContent\":\"Biomedical & Health Sciences\",\"previousSibling\":{\"id\":2685},\"parentNode\":{\"id\":2684}},{\"nodeType\":1,\"id\":2687,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2672}},{\"nodeType\":1,\"id\":2688,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2687}},{\"nodeType\":3,\"id\":2689,\"textContent\":\"Natural Sciences\",\"previousSibling\":{\"id\":2688},\"parentNode\":{\"id\":2687}},{\"nodeType\":1,\"id\":2690,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2673}},{\"nodeType\":1,\"id\":2691,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2690}},{\"nodeType\":3,\"id\":2692,\"textContent\":\"Engineering\",\"previousSibling\":{\"id\":2691},\"parentNode\":{\"id\":2690}},{\"nodeType\":1,\"id\":2693,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2674}},{\"nodeType\":1,\"id\":2694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2693}},{\"nodeType\":3,\"id\":2695,\"textContent\":\"Humanities\",\"previousSibling\":{\"id\":2694},\"parentNode\":{\"id\":2693}},{\"nodeType\":1,\"id\":2696,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2675}},{\"nodeType\":1,\"id\":2697,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2698,\"textContent\":\"Fine Arts\",\"previousSibling\":{\"id\":2697},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2699,\"textContent\":\"*\",\"parentNode\":{\"id\":2677}},{\"nodeType\":1,\"id\":2700,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2701,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2700},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2702,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2701},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2703,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2702},\"parentNode\":{\"id\":2614}},{\"nodeType\":3,\"id\":2704,\"textContent\":\"What is your gender?\",\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2705,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2704},\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2706,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2701}},{\"nodeType\":1,\"id\":2707,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2706}},{\"nodeType\":3,\"id\":2708,\"textContent\":\"Male\",\"previousSibling\":{\"id\":2707},\"parentNode\":{\"id\":2706}},{\"nodeType\":1,\"id\":2709,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2702}},{\"nodeType\":1,\"id\":2710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2709}},{\"nodeType\":3,\"id\":2711,\"textContent\":\"Female\",\"previousSibling\":{\"id\":2710},\"parentNode\":{\"id\":2709}},{\"nodeType\":1,\"id\":2712,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2703}},{\"nodeType\":1,\"id\":2713,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2714,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2713},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2715,\"textContent\":\"*\",\"parentNode\":{\"id\":2705}}],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2609},{\"id\":2610},{\"id\":2611},{\"id\":2616},{\"id\":2621},{\"id\":2622},{\"id\":2635},{\"id\":2617},{\"id\":2623},{\"id\":2624},{\"id\":2625},{\"id\":2618},{\"id\":2626},{\"id\":2627},{\"id\":2628},{\"id\":2619},{\"id\":2629},{\"id\":2630},{\"id\":2631},{\"id\":2620},{\"id\":2632},{\"id\":2633},{\"id\":2634},{\"id\":2612},{\"id\":2636},{\"id\":2644},{\"id\":2645},{\"id\":2667},{\"id\":2637},{\"id\":2646},{\"id\":2647},{\"id\":2648},{\"id\":2638},{\"id\":2649},{\"id\":2650},{\"id\":2651},{\"id\":2639},{\"id\":2652},{\"id\":2653},{\"id\":2654},{\"id\":2640},{\"id\":2655},{\"id\":2656},{\"id\":2657},{\"id\":2641},{\"id\":2658},{\"id\":2659},{\"id\":2660},{\"id\":2642},{\"id\":2661},{\"id\":2662},{\"id\":2663},{\"id\":2643},{\"id\":2664},{\"id\":2665},{\"id\":2666},{\"id\":2613},{\"id\":2668},{\"id\":2676},{\"id\":2677},{\"id\":2699},{\"id\":2669},{\"id\":2678},{\"id\":2679},{\"id\":2680},{\"id\":2670},{\"id\":2681},{\"id\":2682},{\"id\":2683},{\"id\":2671},{\"id\":2684},{\"id\":2685},{\"id\":2686},{\"id\":2672},{\"id\":2687},{\"id\":2688},{\"id\":2689},{\"id\":2673},{\"id\":2690},{\"id\":2691},{\"id\":2692},{\"id\":2674},{\"id\":2693},{\"id\":2694},{\"id\":2695},{\"id\":2675},{\"id\":2696},{\"id\":2697},{\"id\":2698},{\"id\":2614},{\"id\":2700},{\"id\":2704},{\"id\":2705},{\"id\":2715},{\"id\":2701},{\"id\":2706},{\"id\":2707},{\"id\":2708},{\"id\":2702},{\"id\":2709},{\"id\":2710},{\"id\":2711},{\"id\":2703},{\"id\":2712},{\"id\":2713},{\"id\":2714},{\"id\":2615}],[],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2716,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2717,\"textContent\":\" \",\"previousSibling\":{\"id\":2716},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2718,\"textContent\":\" \",\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":2718},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2720,\"textContent\":\" \",\"previousSibling\":{\"id\":2719},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2721,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":2720},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2722,\"textContent\":\" \",\"previousSibling\":{\"id\":2721},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2723,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":2722},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2724,\"textContent\":\" \",\"previousSibling\":{\"id\":2723},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2725,\"textContent\":\" \",\"parentNode\":{\"id\":2719}},{\"nodeType\":1,\"id\":2726,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":2725},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2727,\"textContent\":\" \",\"previousSibling\":{\"id\":2726},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2728,\"textContent\":\" \",\"parentNode\":{\"id\":2726}},{\"nodeType\":1,\"id\":2729,\"tagName\":\"H3\",\"attributes\":{},\"previousSibling\":{\"id\":2728},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2730,\"textContent\":\" \",\"previousSibling\":{\"id\":2729},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2731,\"textContent\":\"DEBRIEFING\",\"parentNode\":{\"id\":2729}},{\"nodeType\":3,\"id\":2732,\"textContent\":\" \",\"parentNode\":{\"id\":2721}},{\"nodeType\":1,\"id\":2733,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":2732},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2734,\"textContent\":\" \",\"previousSibling\":{\"id\":2733},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2735,\"textContent\":\" \",\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2736,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic\"},\"previousSibling\":{\"id\":2735},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2737,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2736},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2738,\"textContent\":\" \",\"previousSibling\":{\"id\":2737},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2739,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2738},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2740,\"textContent\":\" \",\"previousSibling\":{\"id\":2739},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2741,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2740},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2742,\"textContent\":\" \",\"previousSibling\":{\"id\":2741},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2743,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:bold;\"},\"previousSibling\":{\"id\":2742},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2744,\"textContent\":\" \",\"previousSibling\":{\"id\":2743},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2745,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":2744},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2746,\"textContent\":\" \",\"previousSibling\":{\"id\":2745},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2747,\"textContent\":\"Thank you very much for your participation! This debriefing will tell you more about the study, what you did, and why. \",\"parentNode\":{\"id\":2736}},{\"nodeType\":3,\"id\":2748,\"textContent\":\" \",\"parentNode\":{\"id\":2737}},{\"nodeType\":1,\"id\":2749,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2748},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2750,\"textContent\":\" You have just used a series of pictures (charts, graphs and diagrams) accompanied by different types of instructions to answer a series of problem solving questions. While you were using the pictures, we measured where you clicked, scrolled and pointed with the computer mouse. We also measured the accuracy of your responses and the time it took to complete each question.\",\"previousSibling\":{\"id\":2749},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2751,\"textContent\":\"What did you just do?\",\"parentNode\":{\"id\":2749}},{\"nodeType\":3,\"id\":2752,\"textContent\":\" \",\"parentNode\":{\"id\":2739}},{\"nodeType\":1,\"id\":2753,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2752},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2754,\"textContent\":\" Researchers of learning and cognition have long been interested in how graphic displays of information can be used to communicate, solve problems, and generate insights. As powerful as graphics may be in their communicative efficiency, they're not always immediately intuitive to understand. In short, we know a great deal more about learning with representations than we do about the learning of representations. In this project we are building upon previous research on reading and graph comprehension to explore how readers make sense of unfamiliar representations. The instructions you saw for each type of graph are known as “scaffolding techniques”, and we will compare your performance with the scaffolding techniques you saw with the performance of other participants to determine which types of instructions are most effective in helping humans to make sense of unfamiliar graphs. \",\"previousSibling\":{\"id\":2753},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2755,\"textContent\":\"Why did we have you do it?\",\"parentNode\":{\"id\":2753}},{\"nodeType\":1,\"id\":2756,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2757,\"textContent\":\" We expect that you will have found some of the graphics more difficult to use than others. We also expect that with the assistance of the instructions, after solving several problems you will learn to use the difficult graphics so that you can answer the questions even more quickly than without. If you would like to receive a copy of the results of the study, or have any further questions, please contact the researchers Primary Researcher: Amy Fox : a2fox@ucsd.edu Faculty Advisor : Dr. Jim Hollan : hollan@ucsd.edu \",\"previousSibling\":{\"id\":2756},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2758,\"textContent\":\"What do we expect to find?\",\"parentNode\":{\"id\":2756}},{\"nodeType\":3,\"id\":2759,\"textContent\":\"It is important that you do not discuss this experiment with other students who might participate after you. They must participate in the same way as you did, without any knowledge of what the experiment entails, or the reasoning behind it.\",\"parentNode\":{\"id\":2743}},{\"nodeType\":3,\"id\":2760,\"textContent\":\"Thank you for your time! We hope you enjoyed participating in this study as much as we enjoyed designing it.\",\"parentNode\":{\"id\":2745}},{\"nodeType\":3,\"id\":2761,\"textContent\":\" \",\"parentNode\":{\"id\":2723}},{\"nodeType\":1,\"id\":2762,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":2761},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2763,\"textContent\":\" \",\"previousSibling\":{\"id\":2762},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2764,\"textContent\":\"FINISH\",\"parentNode\":{\"id\":2762}}],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2716},{\"id\":2718},{\"id\":2719},{\"id\":2725},{\"id\":2726},{\"id\":2728},{\"id\":2729},{\"id\":2731},{\"id\":2730},{\"id\":2727},{\"id\":2720},{\"id\":2721},{\"id\":2732},{\"id\":2733},{\"id\":2735},{\"id\":2736},{\"id\":2747},{\"id\":2737},{\"id\":2748},{\"id\":2749},{\"id\":2751},{\"id\":2750},{\"id\":2738},{\"id\":2739},{\"id\":2752},{\"id\":2753},{\"id\":2755},{\"id\":2754},{\"id\":2740},{\"id\":2741},{\"id\":2756},{\"id\":2758},{\"id\":2757},{\"id\":2742},{\"id\":2743},{\"id\":2759},{\"id\":2744},{\"id\":2745},{\"id\":2760},{\"id\":2746},{\"id\":2734},{\"id\":2722},{\"id\":2723},{\"id\":2761},{\"id\":2762},{\"id\":2764},{\"id\":2763},{\"id\":2724},{\"id\":2717}],[],[],[]]}"
    },
    {
      "sequence": 8,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2765,\"tagName\":\"PRE\",\"attributes\":{\"id\":\"jspsych-data-display\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2766,\"textContent\":\"[ { \\\"rt\\\": 120737, \\\"stimulus\\\": \\\"img/phone.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"phone\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 0, \\\"time_elapsed\\\": 120744, \\\"internal_node_id\\\": \\\"0.0-0.0\\\", \\\"subject\\\": \\\"7BW1K\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\" }, { \\\"rt\\\": 4834, \\\"url\\\": \\\"../views/src/external/consent.html\\\", \\\"block\\\": \\\"consent\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 1, \\\"time_elapsed\\\": 126903, \\\"internal_node_id\\\": \\\"0.0-1.0\\\", \\\"subject\\\": \\\"7BW1K\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\" }, { \\\"rt\\\": 6656, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"xray\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"311\\\\\\\"}\\\", \\\"block\\\": \\\"codes\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 2, \\\"time_elapsed\\\": 134567, \\\"internal_node_id\\\": \\\"0.0-2.0\\\", \\\"subject\\\": \\\"7BW1K\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\" }, { \\\"rt\\\": 22681, \\\"url\\\": \\\"../views/src/external/instructions_lab.html\\\", \\\"block\\\": \\\"instructions_lab\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 3, \\\"time_elapsed\\\": 158344, \\\"internal_node_id\\\": \\\"0.0-3.0\\\", \\\"subject\\\": \\\"7BW1K\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\" }, { \\\"rt\\\": 19279, \\\"stimulus\\\": \\\"img/acme.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"scenario\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 4, \\\"time_elapsed\\\": 178626, \\\"internal_node_id\\\": \\\"0.0-4.0\\\", \\\"subject\\\": \\\"7BW1K\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\" }, { \\\"rt\\\": 45883, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 5, \\\"time_elapsed\\\": 225933, \\\"internal_node_id\\\": \\\"0.0-5.0-0.0\\\", \\\"subject\\\": \\\"7BW1K\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 1, \\\"clicks\\\": 3.5, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-C -12 PM-A -11 AM-11 AM-2-11 AM-11 AM-11 AM-11 AM-A -A -A -F -F -F -F -K \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:972,y:511,t:1527876572120};\\\", \\\"{x:918,y:441,t:1527876572367};\\\", \\\"{x:912,y:438,t:1527876572487};\\\", \\\"{x:904,y:438,t:1527876572500};\\\", \\\"{x:893,y:438,t:1527876572517};\\\", \\\"{x:873,y:440,t:1527876572533};\\\", \\\"{x:847,y:446,t:1527876572549};\\\", \\\"{x:830,y:450,t:1527876572567};\\\", \\\"{x:810,y:455,t:1527876572583};\\\", \\\"{x:787,y:460,t:1527876572599};\\\", \\\"{x:783,y:461,t:1527876572616};\\\", \\\"{x:770,y:464,t:1527876572633};\\\", \\\"{x:761,y:465,t:1527876572650};\\\", \\\"{x:748,y:467,t:1527876572667};\\\", \\\"{x:739,y:470,t:1527876572682};\\\", \\\"{x:726,y:473,t:1527876572700};\\\", \\\"{x:701,y:478,t:1527876572717};\\\", \\\"{x:682,y:480,t:1527876572733};\\\", \\\"{x:678,y:481,t:1527876572750};\\\", \\\"{x:665,y:482,t:1527876572767};\\\", \\\"{x:656,y:485,t:1527876572783};\\\", \\\"{x:648,y:486,t:1527876572801};\\\", \\\"{x:645,y:486,t:1527876572817};\\\", \\\"{x:644,y:486,t:1527876572834};\\\", \\\"{x:641,y:488,t:1527876572851};\\\", \\\"{x:637,y:488,t:1527876572873};\\\", \\\"{x:634,y:489,t:1527876572884};\\\", \\\"{x:624,y:489,t:1527876572901};\\\", \\\"{x:616,y:490,t:1527876572917};\\\", \\\"{x:612,y:490,t:1527876572935};\\\", \\\"{x:611,y:490,t:1527876572950};\\\", \\\"{x:611,y:492,t:1527876573458};\\\", \\\"{x:610,y:492,t:1527876573468};\\\", \\\"{x:609,y:492,t:1527876573545};\\\", \\\"{x:608,y:493,t:1527876573553};\\\", \\\"{x:605,y:495,t:1527876573568};\\\", \\\"{x:593,y:500,t:1527876573585};\\\", \\\"{x:583,y:506,t:1527876573601};\\\", \\\"{x:583,y:507,t:1527876573633};\\\", \\\"{x:583,y:508,t:1527876573641};\\\", \\\"{x:580,y:509,t:1527876573651};\\\", \\\"{x:565,y:514,t:1527876573668};\\\", \\\"{x:558,y:518,t:1527876573685};\\\", \\\"{x:552,y:520,t:1527876573702};\\\", \\\"{x:550,y:522,t:1527876573717};\\\", \\\"{x:548,y:522,t:1527876573734};\\\", \\\"{x:546,y:523,t:1527876573840};\\\", \\\"{x:545,y:523,t:1527876573851};\\\", \\\"{x:543,y:524,t:1527876573868};\\\", \\\"{x:542,y:524,t:1527876573929};\\\", \\\"{x:539,y:524,t:1527876573944};\\\", \\\"{x:533,y:524,t:1527876573952};\\\", \\\"{x:529,y:524,t:1527876573968};\\\", \\\"{x:526,y:524,t:1527876573983};\\\", \\\"{x:524,y:524,t:1527876574001};\\\", \\\"{x:522,y:524,t:1527876574048};\\\", \\\"{x:520,y:523,t:1527876574056};\\\", \\\"{x:518,y:522,t:1527876574068};\\\", \\\"{x:512,y:520,t:1527876574085};\\\", \\\"{x:511,y:519,t:1527876574101};\\\", \\\"{x:508,y:517,t:1527876574118};\\\", \\\"{x:507,y:517,t:1527876574144};\\\", \\\"{x:506,y:517,t:1527876574218};\\\", \\\"{x:504,y:516,t:1527876574234};\\\", \\\"{x:503,y:516,t:1527876574258};\\\", \\\"{x:502,y:516,t:1527876574273};\\\", \\\"{x:501,y:516,t:1527876574513};\\\", \\\"{x:501,y:515,t:1527876574522};\\\", \\\"{x:500,y:514,t:1527876574552};\\\", \\\"{x:498,y:514,t:1527876574608};\\\", \\\"{x:495,y:514,t:1527876574618};\\\", \\\"{x:491,y:514,t:1527876574635};\\\", \\\"{x:489,y:514,t:1527876574652};\\\", \\\"{x:488,y:514,t:1527876574668};\\\", \\\"{x:487,y:515,t:1527876574752};\\\", \\\"{x:485,y:515,t:1527876574768};\\\", \\\"{x:482,y:515,t:1527876574785};\\\", \\\"{x:481,y:515,t:1527876574802};\\\", \\\"{x:480,y:515,t:1527876574818};\\\", \\\"{x:479,y:515,t:1527876574835};\\\", \\\"{x:478,y:516,t:1527876574852};\\\", \\\"{x:475,y:517,t:1527876574873};\\\", \\\"{x:474,y:517,t:1527876574889};\\\", \\\"{x:472,y:517,t:1527876574902};\\\", \\\"{x:469,y:517,t:1527876574918};\\\", \\\"{x:468,y:517,t:1527876574935};\\\", \\\"{x:466,y:517,t:1527876574961};\\\", \\\"{x:466,y:518,t:1527876575081};\\\", \\\"{x:465,y:518,t:1527876575097};\\\", \\\"{x:464,y:519,t:1527876575105};\\\", \\\"{x:464,y:520,t:1527876575521};\\\", \\\"{x:470,y:520,t:1527876576794};\\\", \\\"{x:476,y:517,t:1527876576804};\\\", \\\"{x:484,y:513,t:1527876576820};\\\", \\\"{x:490,y:511,t:1527876576837};\\\", \\\"{x:510,y:509,t:1527876576853};\\\", \\\"{x:527,y:509,t:1527876576871};\\\", \\\"{x:532,y:509,t:1527876576887};\\\", \\\"{x:551,y:509,t:1527876576903};\\\", \\\"{x:582,y:511,t:1527876576922};\\\", \\\"{x:606,y:519,t:1527876576937};\\\", \\\"{x:622,y:522,t:1527876576953};\\\", \\\"{x:640,y:529,t:1527876576970};\\\", \\\"{x:653,y:533,t:1527876576986};\\\", \\\"{x:672,y:538,t:1527876577003};\\\", \\\"{x:695,y:546,t:1527876577020};\\\", \\\"{x:732,y:560,t:1527876577037};\\\", \\\"{x:767,y:571,t:1527876577053};\\\", \\\"{x:806,y:582,t:1527876577071};\\\", \\\"{x:837,y:591,t:1527876577087};\\\", \\\"{x:864,y:598,t:1527876577104};\\\", \\\"{x:872,y:599,t:1527876577120};\\\", \\\"{x:873,y:599,t:1527876577144};\\\", \\\"{x:874,y:599,t:1527876577154};\\\", \\\"{x:876,y:600,t:1527876577170};\\\", \\\"{x:879,y:601,t:1527876577187};\\\", \\\"{x:886,y:604,t:1527876577204};\\\", \\\"{x:891,y:607,t:1527876577220};\\\", \\\"{x:908,y:620,t:1527876577238};\\\", \\\"{x:928,y:632,t:1527876577254};\\\", \\\"{x:939,y:639,t:1527876577270};\\\", \\\"{x:950,y:648,t:1527876577287};\\\", \\\"{x:958,y:655,t:1527876577304};\\\", \\\"{x:963,y:659,t:1527876577320};\\\", \\\"{x:963,y:660,t:1527876577337};\\\", \\\"{x:964,y:662,t:1527876577354};\\\", \\\"{x:965,y:662,t:1527876577393};\\\", \\\"{x:967,y:664,t:1527876577405};\\\", \\\"{x:970,y:667,t:1527876577420};\\\", \\\"{x:977,y:671,t:1527876577437};\\\", \\\"{x:981,y:672,t:1527876577454};\\\", \\\"{x:982,y:674,t:1527876577472};\\\", \\\"{x:982,y:675,t:1527876577488};\\\", \\\"{x:983,y:677,t:1527876577521};\\\", \\\"{x:985,y:678,t:1527876577537};\\\", \\\"{x:988,y:680,t:1527876577554};\\\", \\\"{x:991,y:682,t:1527876577571};\\\", \\\"{x:992,y:682,t:1527876577588};\\\", \\\"{x:995,y:684,t:1527876577605};\\\", \\\"{x:995,y:685,t:1527876577642};\\\", \\\"{x:997,y:684,t:1527876577778};\\\", \\\"{x:998,y:681,t:1527876577788};\\\", \\\"{x:999,y:676,t:1527876577805};\\\", \\\"{x:1000,y:667,t:1527876577822};\\\", \\\"{x:1002,y:658,t:1527876577839};\\\", \\\"{x:1004,y:645,t:1527876577855};\\\", \\\"{x:1004,y:636,t:1527876577872};\\\", \\\"{x:1007,y:620,t:1527876577890};\\\", \\\"{x:1006,y:607,t:1527876577905};\\\", \\\"{x:1004,y:593,t:1527876577921};\\\", \\\"{x:997,y:579,t:1527876577939};\\\", \\\"{x:990,y:563,t:1527876577955};\\\", \\\"{x:984,y:549,t:1527876577973};\\\", \\\"{x:982,y:540,t:1527876577989};\\\", \\\"{x:981,y:535,t:1527876578005};\\\", \\\"{x:980,y:532,t:1527876578022};\\\", \\\"{x:979,y:529,t:1527876578038};\\\", \\\"{x:979,y:527,t:1527876578055};\\\", \\\"{x:978,y:526,t:1527876578072};\\\", \\\"{x:979,y:531,t:1527876578209};\\\", \\\"{x:984,y:542,t:1527876578223};\\\", \\\"{x:1000,y:557,t:1527876578239};\\\", \\\"{x:1016,y:576,t:1527876578256};\\\", \\\"{x:1033,y:596,t:1527876578272};\\\", \\\"{x:1052,y:623,t:1527876578289};\\\", \\\"{x:1071,y:649,t:1527876578306};\\\", \\\"{x:1094,y:674,t:1527876578322};\\\", \\\"{x:1112,y:702,t:1527876578339};\\\", \\\"{x:1132,y:728,t:1527876578356};\\\", \\\"{x:1142,y:742,t:1527876578372};\\\", \\\"{x:1152,y:761,t:1527876578389};\\\", \\\"{x:1168,y:776,t:1527876578406};\\\", \\\"{x:1179,y:787,t:1527876578422};\\\", \\\"{x:1192,y:797,t:1527876578439};\\\", \\\"{x:1192,y:801,t:1527876578457};\\\", \\\"{x:1201,y:811,t:1527876578472};\\\", \\\"{x:1208,y:816,t:1527876578490};\\\", \\\"{x:1211,y:818,t:1527876578568};\\\", \\\"{x:1212,y:819,t:1527876578576};\\\", \\\"{x:1214,y:820,t:1527876578588};\\\", \\\"{x:1216,y:822,t:1527876578605};\\\", \\\"{x:1222,y:827,t:1527876578698};\\\", \\\"{x:1230,y:834,t:1527876578706};\\\", \\\"{x:1252,y:853,t:1527876578723};\\\", \\\"{x:1274,y:873,t:1527876578738};\\\", \\\"{x:1292,y:890,t:1527876578756};\\\", \\\"{x:1302,y:900,t:1527876578773};\\\", \\\"{x:1308,y:912,t:1527876578788};\\\", \\\"{x:1317,y:924,t:1527876578806};\\\", \\\"{x:1332,y:940,t:1527876578822};\\\", \\\"{x:1344,y:954,t:1527876578839};\\\", \\\"{x:1356,y:962,t:1527876578856};\\\", \\\"{x:1362,y:970,t:1527876578873};\\\", \\\"{x:1363,y:971,t:1527876578889};\\\", \\\"{x:1363,y:972,t:1527876578913};\\\", \\\"{x:1364,y:973,t:1527876578925};\\\", \\\"{x:1365,y:974,t:1527876578939};\\\", \\\"{x:1366,y:975,t:1527876579009};\\\", \\\"{x:1367,y:977,t:1527876579023};\\\", \\\"{x:1369,y:978,t:1527876579040};\\\", \\\"{x:1372,y:981,t:1527876579056};\\\", \\\"{x:1373,y:984,t:1527876579072};\\\", \\\"{x:1374,y:985,t:1527876579096};\\\", \\\"{x:1375,y:987,t:1527876579105};\\\", \\\"{x:1382,y:994,t:1527876579123};\\\", \\\"{x:1390,y:1003,t:1527876579140};\\\", \\\"{x:1393,y:1009,t:1527876579155};\\\", \\\"{x:1398,y:1013,t:1527876579172};\\\", \\\"{x:1399,y:1015,t:1527876579189};\\\", \\\"{x:1399,y:1016,t:1527876579205};\\\", \\\"{x:1400,y:1018,t:1527876579222};\\\", \\\"{x:1401,y:1018,t:1527876579239};\\\", \\\"{x:1401,y:1019,t:1527876579586};\\\", \\\"{x:1401,y:1017,t:1527876579633};\\\", \\\"{x:1401,y:1016,t:1527876579641};\\\", \\\"{x:1397,y:1008,t:1527876579657};\\\", \\\"{x:1391,y:998,t:1527876579673};\\\", \\\"{x:1382,y:990,t:1527876579690};\\\", \\\"{x:1377,y:981,t:1527876579707};\\\", \\\"{x:1373,y:972,t:1527876579724};\\\", \\\"{x:1368,y:959,t:1527876579740};\\\", \\\"{x:1365,y:947,t:1527876579757};\\\", \\\"{x:1361,y:935,t:1527876579774};\\\", \\\"{x:1355,y:925,t:1527876579790};\\\", \\\"{x:1349,y:914,t:1527876579807};\\\", \\\"{x:1346,y:906,t:1527876579824};\\\", \\\"{x:1341,y:899,t:1527876579840};\\\", \\\"{x:1338,y:890,t:1527876579857};\\\", \\\"{x:1336,y:885,t:1527876579875};\\\", \\\"{x:1335,y:880,t:1527876579890};\\\", \\\"{x:1334,y:879,t:1527876579907};\\\", \\\"{x:1333,y:875,t:1527876579924};\\\", \\\"{x:1332,y:873,t:1527876579940};\\\", \\\"{x:1331,y:870,t:1527876579957};\\\", \\\"{x:1330,y:868,t:1527876579974};\\\", \\\"{x:1326,y:860,t:1527876579992};\\\", \\\"{x:1323,y:857,t:1527876580007};\\\", \\\"{x:1323,y:856,t:1527876580024};\\\", \\\"{x:1321,y:852,t:1527876580041};\\\", \\\"{x:1321,y:851,t:1527876580066};\\\", \\\"{x:1320,y:850,t:1527876580074};\\\", \\\"{x:1319,y:849,t:1527876580091};\\\", \\\"{x:1318,y:848,t:1527876580107};\\\", \\\"{x:1317,y:847,t:1527876580125};\\\", \\\"{x:1316,y:846,t:1527876580141};\\\", \\\"{x:1315,y:846,t:1527876580217};\\\", \\\"{x:1314,y:845,t:1527876580234};\\\", \\\"{x:1313,y:845,t:1527876580241};\\\", \\\"{x:1311,y:845,t:1527876580258};\\\", \\\"{x:1310,y:845,t:1527876580298};\\\", \\\"{x:1310,y:844,t:1527876580313};\\\", \\\"{x:1309,y:844,t:1527876580325};\\\", \\\"{x:1308,y:844,t:1527876580341};\\\", \\\"{x:1307,y:844,t:1527876580358};\\\", \\\"{x:1304,y:843,t:1527876580374};\\\", \\\"{x:1301,y:842,t:1527876580393};\\\", \\\"{x:1300,y:842,t:1527876580442};\\\", \\\"{x:1297,y:840,t:1527876580458};\\\", \\\"{x:1296,y:839,t:1527876580481};\\\", \\\"{x:1294,y:839,t:1527876580491};\\\", \\\"{x:1293,y:836,t:1527876580562};\\\", \\\"{x:1291,y:833,t:1527876580602};\\\", \\\"{x:1290,y:832,t:1527876580612};\\\", \\\"{x:1287,y:828,t:1527876580624};\\\", \\\"{x:1283,y:824,t:1527876580641};\\\", \\\"{x:1283,y:823,t:1527876580658};\\\", \\\"{x:1281,y:822,t:1527876580675};\\\", \\\"{x:1280,y:820,t:1527876580690};\\\", \\\"{x:1279,y:820,t:1527876580707};\\\", \\\"{x:1277,y:818,t:1527876580725};\\\", \\\"{x:1277,y:817,t:1527876580741};\\\", \\\"{x:1276,y:817,t:1527876581202};\\\", \\\"{x:1275,y:817,t:1527876581218};\\\", \\\"{x:1275,y:818,t:1527876581226};\\\", \\\"{x:1275,y:822,t:1527876581242};\\\", \\\"{x:1275,y:823,t:1527876581258};\\\", \\\"{x:1275,y:826,t:1527876581275};\\\", \\\"{x:1275,y:829,t:1527876581304};\\\", \\\"{x:1275,y:833,t:1527876581312};\\\", \\\"{x:1275,y:835,t:1527876581325};\\\", \\\"{x:1275,y:842,t:1527876581341};\\\", \\\"{x:1275,y:846,t:1527876581358};\\\", \\\"{x:1275,y:852,t:1527876581374};\\\", \\\"{x:1275,y:857,t:1527876581392};\\\", \\\"{x:1274,y:861,t:1527876581408};\\\", \\\"{x:1274,y:867,t:1527876581424};\\\", \\\"{x:1274,y:871,t:1527876581442};\\\", \\\"{x:1274,y:874,t:1527876581459};\\\", \\\"{x:1274,y:877,t:1527876581475};\\\", \\\"{x:1274,y:881,t:1527876581492};\\\", \\\"{x:1274,y:882,t:1527876581509};\\\", \\\"{x:1274,y:885,t:1527876581525};\\\", \\\"{x:1274,y:888,t:1527876581542};\\\", \\\"{x:1273,y:891,t:1527876581559};\\\", \\\"{x:1273,y:893,t:1527876581575};\\\", \\\"{x:1273,y:895,t:1527876581592};\\\", \\\"{x:1273,y:899,t:1527876581608};\\\", \\\"{x:1271,y:902,t:1527876581625};\\\", \\\"{x:1270,y:905,t:1527876581642};\\\", \\\"{x:1270,y:909,t:1527876581659};\\\", \\\"{x:1270,y:914,t:1527876581675};\\\", \\\"{x:1270,y:919,t:1527876581692};\\\", \\\"{x:1270,y:923,t:1527876581709};\\\", \\\"{x:1270,y:924,t:1527876581725};\\\", \\\"{x:1270,y:926,t:1527876581741};\\\", \\\"{x:1270,y:929,t:1527876581759};\\\", \\\"{x:1270,y:931,t:1527876581777};\\\", \\\"{x:1270,y:934,t:1527876581792};\\\", \\\"{x:1270,y:939,t:1527876581809};\\\", \\\"{x:1270,y:945,t:1527876581825};\\\", \\\"{x:1271,y:949,t:1527876581842};\\\", \\\"{x:1271,y:954,t:1527876581859};\\\", \\\"{x:1272,y:956,t:1527876581876};\\\", \\\"{x:1273,y:959,t:1527876581893};\\\", \\\"{x:1274,y:964,t:1527876581910};\\\", \\\"{x:1274,y:966,t:1527876581926};\\\", \\\"{x:1275,y:972,t:1527876581943};\\\", \\\"{x:1276,y:977,t:1527876581959};\\\", \\\"{x:1276,y:978,t:1527876581976};\\\", \\\"{x:1277,y:983,t:1527876581992};\\\", \\\"{x:1277,y:985,t:1527876582010};\\\", \\\"{x:1277,y:986,t:1527876582026};\\\", \\\"{x:1278,y:987,t:1527876582042};\\\", \\\"{x:1278,y:988,t:1527876582059};\\\", \\\"{x:1278,y:991,t:1527876582076};\\\", \\\"{x:1277,y:990,t:1527876582321};\\\", \\\"{x:1272,y:986,t:1527876582329};\\\", \\\"{x:1267,y:983,t:1527876582343};\\\", \\\"{x:1256,y:974,t:1527876582359};\\\", \\\"{x:1236,y:964,t:1527876582377};\\\", \\\"{x:1218,y:957,t:1527876582393};\\\", \\\"{x:1214,y:955,t:1527876582410};\\\", \\\"{x:1209,y:953,t:1527876582427};\\\", \\\"{x:1208,y:951,t:1527876582443};\\\", \\\"{x:1205,y:950,t:1527876582460};\\\", \\\"{x:1202,y:948,t:1527876582476};\\\", \\\"{x:1197,y:943,t:1527876582493};\\\", \\\"{x:1190,y:937,t:1527876582510};\\\", \\\"{x:1184,y:932,t:1527876582526};\\\", \\\"{x:1172,y:923,t:1527876582543};\\\", \\\"{x:1158,y:914,t:1527876582560};\\\", \\\"{x:1148,y:906,t:1527876582576};\\\", \\\"{x:1129,y:894,t:1527876582593};\\\", \\\"{x:1113,y:885,t:1527876582610};\\\", \\\"{x:1096,y:874,t:1527876582626};\\\", \\\"{x:1075,y:859,t:1527876582643};\\\", \\\"{x:1055,y:846,t:1527876582660};\\\", \\\"{x:1036,y:831,t:1527876582676};\\\", \\\"{x:1017,y:816,t:1527876582693};\\\", \\\"{x:999,y:800,t:1527876582710};\\\", \\\"{x:982,y:781,t:1527876582726};\\\", \\\"{x:970,y:768,t:1527876582743};\\\", \\\"{x:957,y:755,t:1527876582760};\\\", \\\"{x:946,y:744,t:1527876582775};\\\", \\\"{x:924,y:722,t:1527876582793};\\\", \\\"{x:913,y:711,t:1527876582810};\\\", \\\"{x:898,y:702,t:1527876582827};\\\", \\\"{x:887,y:694,t:1527876582842};\\\", \\\"{x:877,y:686,t:1527876582860};\\\", \\\"{x:866,y:677,t:1527876582876};\\\", \\\"{x:859,y:668,t:1527876582893};\\\", \\\"{x:852,y:663,t:1527876582910};\\\", \\\"{x:843,y:658,t:1527876582927};\\\", \\\"{x:837,y:656,t:1527876582943};\\\", \\\"{x:826,y:651,t:1527876582960};\\\", \\\"{x:794,y:639,t:1527876582977};\\\", \\\"{x:776,y:631,t:1527876582993};\\\", \\\"{x:759,y:620,t:1527876583009};\\\", \\\"{x:730,y:604,t:1527876583025};\\\", \\\"{x:690,y:591,t:1527876583042};\\\", \\\"{x:641,y:574,t:1527876583059};\\\", \\\"{x:585,y:558,t:1527876583076};\\\", \\\"{x:534,y:548,t:1527876583091};\\\", \\\"{x:479,y:533,t:1527876583108};\\\", \\\"{x:450,y:529,t:1527876583125};\\\", \\\"{x:429,y:525,t:1527876583142};\\\", \\\"{x:415,y:524,t:1527876583159};\\\", \\\"{x:406,y:524,t:1527876583176};\\\", \\\"{x:389,y:524,t:1527876583191};\\\", \\\"{x:377,y:524,t:1527876583208};\\\", \\\"{x:369,y:524,t:1527876583226};\\\", \\\"{x:365,y:525,t:1527876583243};\\\", \\\"{x:365,y:526,t:1527876583258};\\\", \\\"{x:364,y:529,t:1527876583280};\\\", \\\"{x:364,y:531,t:1527876583293};\\\", \\\"{x:364,y:540,t:1527876583309};\\\", \\\"{x:367,y:548,t:1527876583327};\\\", \\\"{x:371,y:552,t:1527876583342};\\\", \\\"{x:373,y:555,t:1527876583358};\\\", \\\"{x:374,y:556,t:1527876583375};\\\", \\\"{x:375,y:558,t:1527876583391};\\\", \\\"{x:381,y:565,t:1527876583408};\\\", \\\"{x:384,y:567,t:1527876583425};\\\", \\\"{x:386,y:569,t:1527876583442};\\\", \\\"{x:387,y:569,t:1527876587129};\\\", \\\"{x:395,y:565,t:1527876587142};\\\", \\\"{x:401,y:563,t:1527876587159};\\\", \\\"{x:408,y:560,t:1527876587176};\\\", \\\"{x:416,y:555,t:1527876587192};\\\", \\\"{x:427,y:550,t:1527876587209};\\\", \\\"{x:439,y:544,t:1527876587226};\\\", \\\"{x:452,y:542,t:1527876587242};\\\", \\\"{x:475,y:541,t:1527876587260};\\\", \\\"{x:493,y:541,t:1527876587275};\\\", \\\"{x:509,y:541,t:1527876587296};\\\", \\\"{x:519,y:544,t:1527876587312};\\\", \\\"{x:519,y:546,t:1527876587408};\\\", \\\"{x:517,y:547,t:1527876587424};\\\", \\\"{x:515,y:549,t:1527876587432};\\\", \\\"{x:509,y:552,t:1527876587445};\\\", \\\"{x:502,y:552,t:1527876587462};\\\", \\\"{x:499,y:554,t:1527876587478};\\\", \\\"{x:498,y:555,t:1527876587496};\\\", \\\"{x:491,y:558,t:1527876587512};\\\", \\\"{x:482,y:561,t:1527876587529};\\\", \\\"{x:469,y:562,t:1527876587546};\\\", \\\"{x:458,y:562,t:1527876587563};\\\", \\\"{x:445,y:562,t:1527876587578};\\\", \\\"{x:435,y:562,t:1527876587596};\\\", \\\"{x:424,y:562,t:1527876587613};\\\", \\\"{x:412,y:560,t:1527876587629};\\\", \\\"{x:402,y:556,t:1527876587646};\\\", \\\"{x:386,y:552,t:1527876587663};\\\", \\\"{x:379,y:551,t:1527876587679};\\\", \\\"{x:371,y:549,t:1527876587697};\\\", \\\"{x:364,y:548,t:1527876587713};\\\", \\\"{x:363,y:548,t:1527876587729};\\\", \\\"{x:363,y:547,t:1527876587961};\\\", \\\"{x:365,y:546,t:1527876587969};\\\", \\\"{x:367,y:546,t:1527876587980};\\\", \\\"{x:373,y:546,t:1527876587996};\\\", \\\"{x:380,y:547,t:1527876588014};\\\", \\\"{x:384,y:549,t:1527876588030};\\\", \\\"{x:386,y:550,t:1527876588046};\\\", \\\"{x:387,y:550,t:1527876588063};\\\", \\\"{x:389,y:552,t:1527876588079};\\\", \\\"{x:392,y:554,t:1527876588095};\\\", \\\"{x:396,y:556,t:1527876588113};\\\", \\\"{x:398,y:556,t:1527876588135};\\\", \\\"{x:399,y:557,t:1527876588184};\\\", \\\"{x:399,y:558,t:1527876588377};\\\", \\\"{x:399,y:560,t:1527876588409};\\\", \\\"{x:398,y:561,t:1527876588425};\\\", \\\"{x:397,y:561,t:1527876588433};\\\", \\\"{x:396,y:561,t:1527876588448};\\\", \\\"{x:398,y:561,t:1527876588680};\\\", \\\"{x:403,y:559,t:1527876588696};\\\", \\\"{x:406,y:557,t:1527876588713};\\\", \\\"{x:416,y:556,t:1527876588730};\\\", \\\"{x:432,y:560,t:1527876588747};\\\", \\\"{x:443,y:565,t:1527876588763};\\\", \\\"{x:448,y:573,t:1527876588780};\\\", \\\"{x:457,y:578,t:1527876588796};\\\", \\\"{x:462,y:581,t:1527876588815};\\\", \\\"{x:465,y:583,t:1527876588829};\\\", \\\"{x:468,y:585,t:1527876588847};\\\", \\\"{x:487,y:592,t:1527876588863};\\\", \\\"{x:497,y:596,t:1527876588880};\\\", \\\"{x:510,y:600,t:1527876588897};\\\", \\\"{x:528,y:610,t:1527876588913};\\\", \\\"{x:543,y:616,t:1527876588930};\\\", \\\"{x:549,y:620,t:1527876588947};\\\", \\\"{x:553,y:624,t:1527876588964};\\\", \\\"{x:556,y:628,t:1527876588979};\\\", \\\"{x:560,y:632,t:1527876588996};\\\", \\\"{x:565,y:640,t:1527876589014};\\\", \\\"{x:571,y:650,t:1527876589030};\\\", \\\"{x:578,y:657,t:1527876589047};\\\", \\\"{x:598,y:676,t:1527876589064};\\\", \\\"{x:616,y:691,t:1527876589081};\\\", \\\"{x:642,y:711,t:1527876589096};\\\", \\\"{x:664,y:724,t:1527876589113};\\\", \\\"{x:704,y:746,t:1527876589129};\\\", \\\"{x:741,y:764,t:1527876589147};\\\", \\\"{x:785,y:783,t:1527876589163};\\\", \\\"{x:840,y:806,t:1527876589179};\\\", \\\"{x:871,y:822,t:1527876589197};\\\", \\\"{x:872,y:822,t:1527876589213};\\\", \\\"{x:876,y:822,t:1527876589230};\\\", \\\"{x:877,y:822,t:1527876589561};\\\", \\\"{x:878,y:822,t:1527876589569};\\\", \\\"{x:881,y:822,t:1527876589634};\\\", \\\"{x:890,y:822,t:1527876589646};\\\", \\\"{x:939,y:822,t:1527876589662};\\\", \\\"{x:977,y:822,t:1527876589679};\\\", \\\"{x:1001,y:822,t:1527876589696};\\\", \\\"{x:1027,y:822,t:1527876589712};\\\", \\\"{x:1034,y:822,t:1527876589728};\\\", \\\"{x:1036,y:821,t:1527876589744};\\\", \\\"{x:1047,y:821,t:1527876589761};\\\", \\\"{x:1063,y:822,t:1527876589778};\\\", \\\"{x:1080,y:826,t:1527876589794};\\\", \\\"{x:1108,y:828,t:1527876589811};\\\", \\\"{x:1130,y:831,t:1527876589829};\\\", \\\"{x:1148,y:833,t:1527876589845};\\\", \\\"{x:1160,y:833,t:1527876589861};\\\", \\\"{x:1170,y:833,t:1527876589877};\\\", \\\"{x:1177,y:833,t:1527876589894};\\\", \\\"{x:1185,y:834,t:1527876589912};\\\", \\\"{x:1199,y:839,t:1527876589927};\\\", \\\"{x:1214,y:842,t:1527876589945};\\\", \\\"{x:1229,y:844,t:1527876589961};\\\", \\\"{x:1246,y:847,t:1527876589977};\\\", \\\"{x:1258,y:848,t:1527876589995};\\\", \\\"{x:1271,y:849,t:1527876590011};\\\", \\\"{x:1276,y:851,t:1527876590028};\\\", \\\"{x:1279,y:853,t:1527876590045};\\\", \\\"{x:1280,y:853,t:1527876590064};\\\", \\\"{x:1281,y:853,t:1527876590185};\\\", \\\"{x:1282,y:853,t:1527876590201};\\\", \\\"{x:1283,y:852,t:1527876590322};\\\", \\\"{x:1283,y:849,t:1527876590345};\\\", \\\"{x:1283,y:848,t:1527876590359};\\\", \\\"{x:1283,y:846,t:1527876590392};\\\", \\\"{x:1283,y:845,t:1527876590408};\\\", \\\"{x:1283,y:843,t:1527876590424};\\\", \\\"{x:1283,y:842,t:1527876590440};\\\", \\\"{x:1283,y:840,t:1527876590448};\\\", \\\"{x:1283,y:839,t:1527876590504};\\\", \\\"{x:1282,y:839,t:1527876590729};\\\", \\\"{x:1282,y:842,t:1527876590743};\\\", \\\"{x:1284,y:854,t:1527876590760};\\\", \\\"{x:1289,y:871,t:1527876590777};\\\", \\\"{x:1289,y:877,t:1527876590793};\\\", \\\"{x:1291,y:879,t:1527876590809};\\\", \\\"{x:1291,y:884,t:1527876590826};\\\", \\\"{x:1291,y:887,t:1527876590842};\\\", \\\"{x:1291,y:891,t:1527876590859};\\\", \\\"{x:1291,y:897,t:1527876590877};\\\", \\\"{x:1291,y:899,t:1527876590893};\\\", \\\"{x:1292,y:902,t:1527876590909};\\\", \\\"{x:1292,y:906,t:1527876590926};\\\", \\\"{x:1292,y:911,t:1527876590942};\\\", \\\"{x:1292,y:915,t:1527876590959};\\\", \\\"{x:1292,y:923,t:1527876590975};\\\", \\\"{x:1294,y:938,t:1527876590992};\\\", \\\"{x:1294,y:946,t:1527876591008};\\\", \\\"{x:1295,y:955,t:1527876591026};\\\", \\\"{x:1295,y:962,t:1527876591043};\\\", \\\"{x:1295,y:967,t:1527876591060};\\\", \\\"{x:1295,y:974,t:1527876591076};\\\", \\\"{x:1296,y:982,t:1527876591092};\\\", \\\"{x:1299,y:992,t:1527876591108};\\\", \\\"{x:1299,y:999,t:1527876591126};\\\", \\\"{x:1298,y:1001,t:1527876591142};\\\", \\\"{x:1297,y:1004,t:1527876591158};\\\", \\\"{x:1297,y:1005,t:1527876591176};\\\", \\\"{x:1297,y:1002,t:1527876591218};\\\", \\\"{x:1297,y:997,t:1527876591225};\\\", \\\"{x:1293,y:984,t:1527876591241};\\\", \\\"{x:1294,y:972,t:1527876591258};\\\", \\\"{x:1293,y:947,t:1527876591276};\\\", \\\"{x:1293,y:930,t:1527876591291};\\\", \\\"{x:1292,y:919,t:1527876591308};\\\", \\\"{x:1292,y:907,t:1527876591326};\\\", \\\"{x:1290,y:898,t:1527876591341};\\\", \\\"{x:1289,y:888,t:1527876591358};\\\", \\\"{x:1288,y:882,t:1527876591374};\\\", \\\"{x:1288,y:877,t:1527876591391};\\\", \\\"{x:1286,y:871,t:1527876591408};\\\", \\\"{x:1286,y:869,t:1527876591424};\\\", \\\"{x:1286,y:867,t:1527876591456};\\\", \\\"{x:1286,y:866,t:1527876591674};\\\", \\\"{x:1286,y:864,t:1527876592873};\\\", \\\"{x:1286,y:863,t:1527876593449};\\\", \\\"{x:1286,y:861,t:1527876593457};\\\", \\\"{x:1286,y:859,t:1527876593470};\\\", \\\"{x:1286,y:856,t:1527876593487};\\\", \\\"{x:1286,y:854,t:1527876593502};\\\", \\\"{x:1286,y:850,t:1527876593520};\\\", \\\"{x:1286,y:848,t:1527876593535};\\\", \\\"{x:1286,y:846,t:1527876593552};\\\", \\\"{x:1285,y:844,t:1527876593570};\\\", \\\"{x:1285,y:843,t:1527876593633};\\\", \\\"{x:1285,y:842,t:1527876595201};\\\", \\\"{x:1284,y:842,t:1527876595562};\\\", \\\"{x:1284,y:840,t:1527876595593};\\\", \\\"{x:1285,y:840,t:1527876595601};\\\", \\\"{x:1286,y:838,t:1527876595614};\\\", \\\"{x:1288,y:835,t:1527876595631};\\\", \\\"{x:1292,y:832,t:1527876595648};\\\", \\\"{x:1294,y:830,t:1527876595664};\\\", \\\"{x:1294,y:829,t:1527876595681};\\\", \\\"{x:1295,y:822,t:1527876595977};\\\", \\\"{x:1295,y:814,t:1527876595985};\\\", \\\"{x:1295,y:804,t:1527876595996};\\\", \\\"{x:1295,y:788,t:1527876596013};\\\", \\\"{x:1292,y:773,t:1527876596030};\\\", \\\"{x:1290,y:761,t:1527876596047};\\\", \\\"{x:1290,y:755,t:1527876596063};\\\", \\\"{x:1288,y:750,t:1527876596080};\\\", \\\"{x:1288,y:749,t:1527876596095};\\\", \\\"{x:1287,y:749,t:1527876596481};\\\", \\\"{x:1284,y:751,t:1527876596497};\\\", \\\"{x:1281,y:753,t:1527876596512};\\\", \\\"{x:1277,y:762,t:1527876596528};\\\", \\\"{x:1275,y:766,t:1527876596545};\\\", \\\"{x:1275,y:772,t:1527876596561};\\\", \\\"{x:1273,y:777,t:1527876596579};\\\", \\\"{x:1273,y:782,t:1527876596595};\\\", \\\"{x:1273,y:786,t:1527876596612};\\\", \\\"{x:1273,y:791,t:1527876596628};\\\", \\\"{x:1272,y:794,t:1527876596645};\\\", \\\"{x:1272,y:799,t:1527876596662};\\\", \\\"{x:1271,y:804,t:1527876596678};\\\", \\\"{x:1271,y:807,t:1527876596695};\\\", \\\"{x:1271,y:809,t:1527876596711};\\\", \\\"{x:1271,y:813,t:1527876596728};\\\", \\\"{x:1271,y:819,t:1527876596745};\\\", \\\"{x:1271,y:826,t:1527876596761};\\\", \\\"{x:1272,y:831,t:1527876596777};\\\", \\\"{x:1273,y:837,t:1527876596795};\\\", \\\"{x:1273,y:843,t:1527876596810};\\\", \\\"{x:1274,y:849,t:1527876596828};\\\", \\\"{x:1275,y:854,t:1527876596844};\\\", \\\"{x:1277,y:859,t:1527876596861};\\\", \\\"{x:1277,y:862,t:1527876596878};\\\", \\\"{x:1277,y:869,t:1527876596893};\\\", \\\"{x:1277,y:873,t:1527876596910};\\\", \\\"{x:1277,y:879,t:1527876596928};\\\", \\\"{x:1277,y:883,t:1527876596944};\\\", \\\"{x:1277,y:895,t:1527876596961};\\\", \\\"{x:1277,y:900,t:1527876596977};\\\", \\\"{x:1277,y:907,t:1527876596994};\\\", \\\"{x:1277,y:914,t:1527876597010};\\\", \\\"{x:1277,y:920,t:1527876597027};\\\", \\\"{x:1280,y:925,t:1527876597044};\\\", \\\"{x:1281,y:931,t:1527876597061};\\\", \\\"{x:1282,y:936,t:1527876597076};\\\", \\\"{x:1282,y:945,t:1527876597094};\\\", \\\"{x:1281,y:952,t:1527876597110};\\\", \\\"{x:1281,y:958,t:1527876597127};\\\", \\\"{x:1280,y:968,t:1527876597144};\\\", \\\"{x:1279,y:976,t:1527876597160};\\\", \\\"{x:1277,y:984,t:1527876597177};\\\", \\\"{x:1277,y:988,t:1527876597194};\\\", \\\"{x:1278,y:989,t:1527876597210};\\\", \\\"{x:1278,y:992,t:1527876597227};\\\", \\\"{x:1278,y:989,t:1527876597361};\\\", \\\"{x:1278,y:981,t:1527876597376};\\\", \\\"{x:1278,y:955,t:1527876597393};\\\", \\\"{x:1279,y:937,t:1527876597409};\\\", \\\"{x:1282,y:919,t:1527876597426};\\\", \\\"{x:1283,y:912,t:1527876597443};\\\", \\\"{x:1283,y:903,t:1527876597460};\\\", \\\"{x:1283,y:899,t:1527876597475};\\\", \\\"{x:1283,y:896,t:1527876597493};\\\", \\\"{x:1282,y:892,t:1527876597509};\\\", \\\"{x:1282,y:886,t:1527876597526};\\\", \\\"{x:1282,y:881,t:1527876597543};\\\", \\\"{x:1282,y:875,t:1527876597559};\\\", \\\"{x:1282,y:871,t:1527876597576};\\\", \\\"{x:1282,y:864,t:1527876597592};\\\", \\\"{x:1282,y:859,t:1527876597609};\\\", \\\"{x:1283,y:857,t:1527876597626};\\\", \\\"{x:1283,y:852,t:1527876597642};\\\", \\\"{x:1283,y:849,t:1527876597658};\\\", \\\"{x:1283,y:844,t:1527876597676};\\\", \\\"{x:1283,y:839,t:1527876597692};\\\", \\\"{x:1283,y:835,t:1527876597716};\\\", \\\"{x:1285,y:825,t:1527876597742};\\\", \\\"{x:1285,y:820,t:1527876597758};\\\", \\\"{x:1285,y:817,t:1527876597782};\\\", \\\"{x:1286,y:815,t:1527876597799};\\\", \\\"{x:1286,y:813,t:1527876597815};\\\", \\\"{x:1286,y:810,t:1527876597832};\\\", \\\"{x:1286,y:808,t:1527876597856};\\\", \\\"{x:1286,y:806,t:1527876597865};\\\", \\\"{x:1287,y:804,t:1527876597882};\\\", \\\"{x:1287,y:802,t:1527876597900};\\\", \\\"{x:1287,y:801,t:1527876597916};\\\", \\\"{x:1288,y:799,t:1527876597933};\\\", \\\"{x:1289,y:798,t:1527876597950};\\\", \\\"{x:1289,y:796,t:1527876597967};\\\", \\\"{x:1289,y:792,t:1527876597984};\\\", \\\"{x:1289,y:790,t:1527876598009};\\\", \\\"{x:1289,y:789,t:1527876598033};\\\", \\\"{x:1289,y:787,t:1527876598050};\\\", \\\"{x:1289,y:786,t:1527876598067};\\\", \\\"{x:1289,y:784,t:1527876598083};\\\", \\\"{x:1289,y:781,t:1527876598099};\\\", \\\"{x:1289,y:779,t:1527876598116};\\\", \\\"{x:1289,y:777,t:1527876598134};\\\", \\\"{x:1289,y:774,t:1527876598149};\\\", \\\"{x:1289,y:773,t:1527876598168};\\\", \\\"{x:1288,y:773,t:1527876598183};\\\", \\\"{x:1288,y:771,t:1527876598199};\\\", \\\"{x:1287,y:767,t:1527876598216};\\\", \\\"{x:1287,y:764,t:1527876598233};\\\", \\\"{x:1286,y:760,t:1527876598250};\\\", \\\"{x:1285,y:754,t:1527876598266};\\\", \\\"{x:1285,y:752,t:1527876598284};\\\", \\\"{x:1284,y:749,t:1527876598301};\\\", \\\"{x:1284,y:748,t:1527876598316};\\\", \\\"{x:1284,y:747,t:1527876598336};\\\", \\\"{x:1282,y:746,t:1527876598401};\\\", \\\"{x:1277,y:750,t:1527876598417};\\\", \\\"{x:1273,y:765,t:1527876598434};\\\", \\\"{x:1272,y:775,t:1527876598450};\\\", \\\"{x:1272,y:787,t:1527876598467};\\\", \\\"{x:1272,y:798,t:1527876598483};\\\", \\\"{x:1273,y:807,t:1527876598500};\\\", \\\"{x:1274,y:813,t:1527876598517};\\\", \\\"{x:1274,y:818,t:1527876598534};\\\", \\\"{x:1274,y:820,t:1527876598550};\\\", \\\"{x:1276,y:824,t:1527876598567};\\\", \\\"{x:1277,y:827,t:1527876598585};\\\", \\\"{x:1277,y:828,t:1527876598600};\\\", \\\"{x:1278,y:830,t:1527876598631};\\\", \\\"{x:1279,y:830,t:1527876598712};\\\", \\\"{x:1280,y:830,t:1527876598722};\\\", \\\"{x:1281,y:830,t:1527876598738};\\\", \\\"{x:1282,y:830,t:1527876598760};\\\", \\\"{x:1283,y:830,t:1527876598771};\\\", \\\"{x:1284,y:830,t:1527876598788};\\\", \\\"{x:1284,y:831,t:1527876598824};\\\", \\\"{x:1287,y:829,t:1527876602483};\\\", \\\"{x:1297,y:826,t:1527876602508};\\\", \\\"{x:1304,y:827,t:1527876602524};\\\", \\\"{x:1307,y:829,t:1527876602541};\\\", \\\"{x:1310,y:831,t:1527876602557};\\\", \\\"{x:1312,y:831,t:1527876602574};\\\", \\\"{x:1312,y:832,t:1527876602591};\\\", \\\"{x:1314,y:834,t:1527876602608};\\\", \\\"{x:1315,y:837,t:1527876602624};\\\", \\\"{x:1317,y:841,t:1527876602641};\\\", \\\"{x:1320,y:844,t:1527876602658};\\\", \\\"{x:1320,y:845,t:1527876602675};\\\", \\\"{x:1322,y:848,t:1527876602691};\\\", \\\"{x:1323,y:848,t:1527876602709};\\\", \\\"{x:1324,y:848,t:1527876602725};\\\", \\\"{x:1330,y:848,t:1527876602741};\\\", \\\"{x:1335,y:843,t:1527876602758};\\\", \\\"{x:1340,y:840,t:1527876602774};\\\", \\\"{x:1345,y:836,t:1527876602791};\\\", \\\"{x:1353,y:832,t:1527876602808};\\\", \\\"{x:1355,y:831,t:1527876602825};\\\", \\\"{x:1363,y:824,t:1527876602841};\\\", \\\"{x:1366,y:818,t:1527876602858};\\\", \\\"{x:1369,y:811,t:1527876602874};\\\", \\\"{x:1373,y:804,t:1527876602891};\\\", \\\"{x:1378,y:795,t:1527876602909};\\\", \\\"{x:1382,y:789,t:1527876602924};\\\", \\\"{x:1385,y:781,t:1527876602941};\\\", \\\"{x:1389,y:770,t:1527876602958};\\\", \\\"{x:1392,y:761,t:1527876602975};\\\", \\\"{x:1395,y:755,t:1527876602992};\\\", \\\"{x:1397,y:753,t:1527876603009};\\\", \\\"{x:1394,y:753,t:1527876603169};\\\", \\\"{x:1392,y:754,t:1527876603177};\\\", \\\"{x:1391,y:754,t:1527876603192};\\\", \\\"{x:1387,y:756,t:1527876603208};\\\", \\\"{x:1386,y:757,t:1527876603226};\\\", \\\"{x:1384,y:758,t:1527876603246};\\\", \\\"{x:1382,y:759,t:1527876603258};\\\", \\\"{x:1381,y:760,t:1527876604545};\\\", \\\"{x:1379,y:760,t:1527876604560};\\\", \\\"{x:1360,y:767,t:1527876604579};\\\", \\\"{x:1318,y:775,t:1527876604592};\\\", \\\"{x:1270,y:783,t:1527876604609};\\\", \\\"{x:1197,y:795,t:1527876604627};\\\", \\\"{x:1116,y:794,t:1527876604643};\\\", \\\"{x:1013,y:790,t:1527876604660};\\\", \\\"{x:896,y:772,t:1527876604676};\\\", \\\"{x:796,y:742,t:1527876604692};\\\", \\\"{x:737,y:723,t:1527876604710};\\\", \\\"{x:704,y:710,t:1527876604727};\\\", \\\"{x:688,y:701,t:1527876604742};\\\", \\\"{x:683,y:698,t:1527876604759};\\\", \\\"{x:681,y:696,t:1527876604777};\\\", \\\"{x:680,y:689,t:1527876604793};\\\", \\\"{x:675,y:675,t:1527876604811};\\\", \\\"{x:657,y:655,t:1527876604827};\\\", \\\"{x:626,y:631,t:1527876604843};\\\", \\\"{x:587,y:597,t:1527876604860};\\\", \\\"{x:570,y:578,t:1527876604876};\\\", \\\"{x:557,y:570,t:1527876604894};\\\", \\\"{x:556,y:570,t:1527876604909};\\\", \\\"{x:552,y:570,t:1527876604952};\\\", \\\"{x:547,y:571,t:1527876604960};\\\", \\\"{x:533,y:582,t:1527876604976};\\\", \\\"{x:517,y:594,t:1527876604993};\\\", \\\"{x:501,y:604,t:1527876605009};\\\", \\\"{x:482,y:610,t:1527876605027};\\\", \\\"{x:465,y:616,t:1527876605043};\\\", \\\"{x:460,y:616,t:1527876605060};\\\", \\\"{x:444,y:619,t:1527876605076};\\\", \\\"{x:420,y:613,t:1527876605094};\\\", \\\"{x:407,y:607,t:1527876605111};\\\", \\\"{x:397,y:602,t:1527876605126};\\\", \\\"{x:392,y:594,t:1527876605145};\\\", \\\"{x:378,y:578,t:1527876605160};\\\", \\\"{x:373,y:573,t:1527876605177};\\\", \\\"{x:373,y:572,t:1527876605257};\\\", \\\"{x:374,y:570,t:1527876605272};\\\", \\\"{x:377,y:568,t:1527876605281};\\\", \\\"{x:378,y:567,t:1527876605294};\\\", \\\"{x:379,y:567,t:1527876605310};\\\", \\\"{x:381,y:565,t:1527876605327};\\\", \\\"{x:383,y:563,t:1527876605344};\\\", \\\"{x:384,y:561,t:1527876605361};\\\", \\\"{x:386,y:560,t:1527876605377};\\\", \\\"{x:391,y:558,t:1527876605394};\\\", \\\"{x:393,y:557,t:1527876605410};\\\", \\\"{x:394,y:558,t:1527876605648};\\\", \\\"{x:394,y:561,t:1527876605660};\\\", \\\"{x:394,y:564,t:1527876605677};\\\", \\\"{x:393,y:567,t:1527876605694};\\\", \\\"{x:392,y:568,t:1527876605710};\\\", \\\"{x:392,y:571,t:1527876605728};\\\", \\\"{x:391,y:574,t:1527876605744};\\\", \\\"{x:390,y:581,t:1527876605761};\\\", \\\"{x:390,y:583,t:1527876605778};\\\", \\\"{x:390,y:585,t:1527876605824};\\\", \\\"{x:390,y:586,t:1527876605840};\\\", \\\"{x:388,y:588,t:1527876605856};\\\", \\\"{x:388,y:589,t:1527876605888};\\\", \\\"{x:388,y:590,t:1527876605920};\\\", \\\"{x:387,y:591,t:1527876605928};\\\", \\\"{x:385,y:593,t:1527876605943};\\\", \\\"{x:384,y:594,t:1527876605961};\\\", \\\"{x:383,y:595,t:1527876605978};\\\", \\\"{x:387,y:596,t:1527876606239};\\\", \\\"{x:394,y:599,t:1527876606248};\\\", \\\"{x:396,y:601,t:1527876606261};\\\", \\\"{x:414,y:605,t:1527876606277};\\\", \\\"{x:431,y:612,t:1527876606295};\\\", \\\"{x:443,y:622,t:1527876606311};\\\", \\\"{x:469,y:635,t:1527876606327};\\\", \\\"{x:494,y:648,t:1527876606344};\\\", \\\"{x:525,y:663,t:1527876606362};\\\", \\\"{x:563,y:685,t:1527876606377};\\\", \\\"{x:596,y:704,t:1527876606395};\\\", \\\"{x:637,y:712,t:1527876606411};\\\", \\\"{x:708,y:728,t:1527876606427};\\\", \\\"{x:735,y:735,t:1527876606445};\\\", \\\"{x:755,y:736,t:1527876606461};\\\", \\\"{x:781,y:738,t:1527876606477};\\\", \\\"{x:805,y:738,t:1527876606494};\\\", \\\"{x:843,y:732,t:1527876606512};\\\", \\\"{x:857,y:731,t:1527876606527};\\\", \\\"{x:919,y:723,t:1527876606544};\\\", \\\"{x:961,y:718,t:1527876606562};\\\", \\\"{x:1023,y:708,t:1527876606577};\\\", \\\"{x:1068,y:702,t:1527876606594};\\\", \\\"{x:1091,y:697,t:1527876606612};\\\", \\\"{x:1105,y:693,t:1527876606628};\\\", \\\"{x:1118,y:691,t:1527876606645};\\\", \\\"{x:1122,y:688,t:1527876606662};\\\", \\\"{x:1126,y:685,t:1527876606679};\\\", \\\"{x:1133,y:683,t:1527876606695};\\\", \\\"{x:1144,y:676,t:1527876606712};\\\", \\\"{x:1162,y:668,t:1527876606728};\\\", \\\"{x:1192,y:658,t:1527876606745};\\\", \\\"{x:1219,y:654,t:1527876606762};\\\", \\\"{x:1260,y:654,t:1527876606779};\\\", \\\"{x:1290,y:659,t:1527876606795};\\\", \\\"{x:1339,y:676,t:1527876606812};\\\", \\\"{x:1365,y:693,t:1527876606829};\\\", \\\"{x:1380,y:711,t:1527876606845};\\\", \\\"{x:1390,y:729,t:1527876606862};\\\", \\\"{x:1398,y:743,t:1527876606879};\\\", \\\"{x:1402,y:750,t:1527876606895};\\\", \\\"{x:1404,y:753,t:1527876606912};\\\", \\\"{x:1405,y:754,t:1527876606993};\\\", \\\"{x:1405,y:755,t:1527876607009};\\\", \\\"{x:1405,y:756,t:1527876607017};\\\", \\\"{x:1401,y:758,t:1527876607029};\\\", \\\"{x:1389,y:758,t:1527876607046};\\\", \\\"{x:1381,y:758,t:1527876607065};\\\", \\\"{x:1376,y:758,t:1527876607079};\\\", \\\"{x:1375,y:758,t:1527876607095};\\\", \\\"{x:1375,y:759,t:1527876607432};\\\", \\\"{x:1378,y:763,t:1527876607449};\\\", \\\"{x:1385,y:768,t:1527876607463};\\\", \\\"{x:1387,y:770,t:1527876607478};\\\", \\\"{x:1388,y:770,t:1527876607496};\\\", \\\"{x:1388,y:771,t:1527876607777};\\\", \\\"{x:1387,y:773,t:1527876607792};\\\", \\\"{x:1386,y:773,t:1527876607817};\\\", \\\"{x:1384,y:774,t:1527876607833};\\\", \\\"{x:1383,y:774,t:1527876607873};\\\", \\\"{x:1382,y:774,t:1527876607880};\\\", \\\"{x:1381,y:774,t:1527876607937};\\\", \\\"{x:1380,y:774,t:1527876607952};\\\", \\\"{x:1379,y:774,t:1527876607977};\\\", \\\"{x:1378,y:773,t:1527876608001};\\\", \\\"{x:1378,y:771,t:1527876608121};\\\", \\\"{x:1378,y:769,t:1527876608129};\\\", \\\"{x:1378,y:768,t:1527876608150};\\\", \\\"{x:1378,y:766,t:1527876608207};\\\", \\\"{x:1379,y:766,t:1527876608231};\\\", \\\"{x:1379,y:765,t:1527876608245};\\\", \\\"{x:1380,y:764,t:1527876608271};\\\", \\\"{x:1381,y:764,t:1527876614785};\\\", \\\"{x:1384,y:761,t:1527876614802};\\\", \\\"{x:1391,y:750,t:1527876614821};\\\", \\\"{x:1397,y:741,t:1527876614834};\\\", \\\"{x:1399,y:736,t:1527876614850};\\\", \\\"{x:1403,y:727,t:1527876614867};\\\", \\\"{x:1404,y:724,t:1527876614884};\\\", \\\"{x:1406,y:719,t:1527876614900};\\\", \\\"{x:1407,y:716,t:1527876614918};\\\", \\\"{x:1408,y:715,t:1527876614934};\\\", \\\"{x:1410,y:710,t:1527876614951};\\\", \\\"{x:1412,y:705,t:1527876614968};\\\", \\\"{x:1413,y:703,t:1527876614983};\\\", \\\"{x:1413,y:702,t:1527876615001};\\\", \\\"{x:1413,y:700,t:1527876615018};\\\", \\\"{x:1414,y:699,t:1527876615034};\\\", \\\"{x:1414,y:698,t:1527876615057};\\\", \\\"{x:1415,y:696,t:1527876615068};\\\", \\\"{x:1416,y:693,t:1527876615084};\\\", \\\"{x:1419,y:688,t:1527876615101};\\\", \\\"{x:1421,y:684,t:1527876615119};\\\", \\\"{x:1423,y:679,t:1527876615135};\\\", \\\"{x:1425,y:674,t:1527876615152};\\\", \\\"{x:1429,y:666,t:1527876615168};\\\", \\\"{x:1431,y:660,t:1527876615185};\\\", \\\"{x:1434,y:654,t:1527876615201};\\\", \\\"{x:1440,y:643,t:1527876615218};\\\", \\\"{x:1445,y:634,t:1527876615235};\\\", \\\"{x:1453,y:621,t:1527876615251};\\\", \\\"{x:1461,y:608,t:1527876615268};\\\", \\\"{x:1472,y:589,t:1527876615284};\\\", \\\"{x:1486,y:565,t:1527876615301};\\\", \\\"{x:1500,y:540,t:1527876615319};\\\", \\\"{x:1510,y:524,t:1527876615335};\\\", \\\"{x:1520,y:508,t:1527876615352};\\\", \\\"{x:1526,y:499,t:1527876615368};\\\", \\\"{x:1528,y:497,t:1527876615385};\\\", \\\"{x:1528,y:498,t:1527876615441};\\\", \\\"{x:1530,y:506,t:1527876615452};\\\", \\\"{x:1535,y:532,t:1527876615469};\\\", \\\"{x:1539,y:558,t:1527876615485};\\\", \\\"{x:1540,y:584,t:1527876615501};\\\", \\\"{x:1540,y:608,t:1527876615518};\\\", \\\"{x:1541,y:621,t:1527876615535};\\\", \\\"{x:1540,y:634,t:1527876615551};\\\", \\\"{x:1538,y:641,t:1527876615569};\\\", \\\"{x:1538,y:642,t:1527876615585};\\\", \\\"{x:1537,y:642,t:1527876615657};\\\", \\\"{x:1535,y:642,t:1527876615673};\\\", \\\"{x:1534,y:642,t:1527876615685};\\\", \\\"{x:1532,y:642,t:1527876615702};\\\", \\\"{x:1530,y:642,t:1527876615719};\\\", \\\"{x:1528,y:642,t:1527876615734};\\\", \\\"{x:1524,y:645,t:1527876615752};\\\", \\\"{x:1522,y:645,t:1527876615768};\\\", \\\"{x:1519,y:645,t:1527876615785};\\\", \\\"{x:1516,y:645,t:1527876615802};\\\", \\\"{x:1514,y:645,t:1527876615818};\\\", \\\"{x:1512,y:645,t:1527876615835};\\\", \\\"{x:1509,y:644,t:1527876615851};\\\", \\\"{x:1508,y:643,t:1527876615868};\\\", \\\"{x:1507,y:642,t:1527876615885};\\\", \\\"{x:1504,y:641,t:1527876615936};\\\", \\\"{x:1496,y:640,t:1527876615952};\\\", \\\"{x:1490,y:640,t:1527876615969};\\\", \\\"{x:1482,y:640,t:1527876615985};\\\", \\\"{x:1476,y:639,t:1527876616002};\\\", \\\"{x:1469,y:636,t:1527876616018};\\\", \\\"{x:1466,y:634,t:1527876616035};\\\", \\\"{x:1463,y:634,t:1527876616057};\\\", \\\"{x:1461,y:634,t:1527876616067};\\\", \\\"{x:1464,y:633,t:1527876616184};\\\", \\\"{x:1470,y:633,t:1527876616191};\\\", \\\"{x:1479,y:630,t:1527876616202};\\\", \\\"{x:1487,y:629,t:1527876616219};\\\", \\\"{x:1497,y:628,t:1527876616235};\\\", \\\"{x:1503,y:627,t:1527876616252};\\\", \\\"{x:1505,y:627,t:1527876616269};\\\", \\\"{x:1508,y:627,t:1527876616285};\\\", \\\"{x:1511,y:626,t:1527876616305};\\\", \\\"{x:1514,y:626,t:1527876616319};\\\", \\\"{x:1516,y:626,t:1527876616335};\\\", \\\"{x:1517,y:625,t:1527876616351};\\\", \\\"{x:1516,y:625,t:1527876616881};\\\", \\\"{x:1512,y:627,t:1527876616889};\\\", \\\"{x:1499,y:633,t:1527876616906};\\\", \\\"{x:1455,y:646,t:1527876616919};\\\", \\\"{x:1410,y:662,t:1527876616936};\\\", \\\"{x:1332,y:684,t:1527876616953};\\\", \\\"{x:1225,y:708,t:1527876616970};\\\", \\\"{x:1120,y:737,t:1527876616986};\\\", \\\"{x:1011,y:755,t:1527876617003};\\\", \\\"{x:931,y:766,t:1527876617020};\\\", \\\"{x:882,y:774,t:1527876617036};\\\", \\\"{x:856,y:774,t:1527876617053};\\\", \\\"{x:838,y:774,t:1527876617070};\\\", \\\"{x:816,y:773,t:1527876617085};\\\", \\\"{x:801,y:771,t:1527876617103};\\\", \\\"{x:777,y:766,t:1527876617120};\\\", \\\"{x:754,y:767,t:1527876617136};\\\", \\\"{x:728,y:771,t:1527876617153};\\\", \\\"{x:700,y:771,t:1527876617170};\\\", \\\"{x:666,y:771,t:1527876617186};\\\", \\\"{x:634,y:766,t:1527876617203};\\\", \\\"{x:605,y:756,t:1527876617220};\\\", \\\"{x:581,y:748,t:1527876617237};\\\", \\\"{x:560,y:743,t:1527876617254};\\\", \\\"{x:540,y:739,t:1527876617269};\\\", \\\"{x:524,y:737,t:1527876617286};\\\", \\\"{x:514,y:736,t:1527876617303};\\\", \\\"{x:507,y:734,t:1527876617319};\\\", \\\"{x:507,y:733,t:1527876617337};\\\", \\\"{x:504,y:733,t:1527876617464};\\\", \\\"{x:503,y:734,t:1527876617473};\\\", \\\"{x:502,y:735,t:1527876617487};\\\", \\\"{x:502,y:740,t:1527876617504};\\\", \\\"{x:501,y:741,t:1527876617520};\\\", \\\"{x:501,y:743,t:1527876617537};\\\", \\\"{x:501,y:744,t:1527876617553};\\\", \\\"{x:501,y:745,t:1527876617576};\\\", \\\"{x:501,y:746,t:1527876617608};\\\", \\\"{x:500,y:748,t:1527876617624};\\\", \\\"{x:500,y:749,t:1527876617648};\\\", \\\"{x:500,y:750,t:1527876617656};\\\", \\\"{x:499,y:750,t:1527876617673};\\\", \\\"{x:502,y:751,t:1527876618359};\\\", \\\"{x:505,y:751,t:1527876618371};\\\", \\\"{x:511,y:749,t:1527876618386};\\\", \\\"{x:515,y:748,t:1527876618404};\\\", \\\"{x:520,y:746,t:1527876618430};\\\", \\\"{x:524,y:744,t:1527876618436};\\\", \\\"{x:531,y:741,t:1527876618454};\\\", \\\"{x:546,y:741,t:1527876618470};\\\", \\\"{x:561,y:741,t:1527876618487};\\\", \\\"{x:590,y:740,t:1527876618504};\\\", \\\"{x:610,y:740,t:1527876618520};\\\", \\\"{x:625,y:741,t:1527876618537};\\\", \\\"{x:632,y:741,t:1527876618554};\\\", \\\"{x:641,y:741,t:1527876618570};\\\", \\\"{x:652,y:741,t:1527876618587};\\\", \\\"{x:656,y:742,t:1527876618604};\\\" ] }, { \\\"rt\\\": 14566, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 6, \\\"time_elapsed\\\": 241779, \\\"internal_node_id\\\": \\\"0.0-5.0-1.0\\\", \\\"subject\\\": \\\"7BW1K\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 2, \\\"clicks\\\": 1, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"K\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-D -K -4\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:656,y:743,t:1527876619279};\\\", \\\"{x:649,y:717,t:1527876619709};\\\", \\\"{x:642,y:709,t:1527876619721};\\\", \\\"{x:637,y:703,t:1527876619737};\\\", \\\"{x:628,y:695,t:1527876619755};\\\", \\\"{x:624,y:692,t:1527876619772};\\\", \\\"{x:619,y:690,t:1527876619788};\\\", \\\"{x:614,y:685,t:1527876619806};\\\", \\\"{x:609,y:681,t:1527876619822};\\\", \\\"{x:600,y:671,t:1527876619838};\\\", \\\"{x:590,y:659,t:1527876619855};\\\", \\\"{x:574,y:644,t:1527876619872};\\\", \\\"{x:555,y:634,t:1527876619889};\\\", \\\"{x:532,y:621,t:1527876619905};\\\", \\\"{x:520,y:612,t:1527876619922};\\\", \\\"{x:515,y:606,t:1527876619940};\\\", \\\"{x:513,y:604,t:1527876619955};\\\", \\\"{x:511,y:602,t:1527876619975};\\\", \\\"{x:510,y:600,t:1527876619989};\\\", \\\"{x:504,y:591,t:1527876620005};\\\", \\\"{x:502,y:588,t:1527876620022};\\\", \\\"{x:498,y:583,t:1527876620040};\\\", \\\"{x:493,y:576,t:1527876620056};\\\", \\\"{x:491,y:575,t:1527876620087};\\\", \\\"{x:491,y:574,t:1527876620095};\\\", \\\"{x:490,y:571,t:1527876620106};\\\", \\\"{x:490,y:568,t:1527876620122};\\\", \\\"{x:489,y:561,t:1527876620138};\\\", \\\"{x:489,y:554,t:1527876620154};\\\", \\\"{x:489,y:541,t:1527876620173};\\\", \\\"{x:489,y:524,t:1527876620189};\\\", \\\"{x:485,y:509,t:1527876620205};\\\", \\\"{x:481,y:490,t:1527876620222};\\\", \\\"{x:476,y:471,t:1527876620239};\\\", \\\"{x:467,y:442,t:1527876620255};\\\", \\\"{x:453,y:412,t:1527876620272};\\\", \\\"{x:447,y:399,t:1527876620289};\\\", \\\"{x:442,y:393,t:1527876620305};\\\", \\\"{x:440,y:388,t:1527876620322};\\\", \\\"{x:439,y:388,t:1527876620338};\\\", \\\"{x:438,y:388,t:1527876620355};\\\", \\\"{x:433,y:388,t:1527876620372};\\\", \\\"{x:424,y:389,t:1527876620389};\\\", \\\"{x:411,y:392,t:1527876620405};\\\", \\\"{x:399,y:395,t:1527876620422};\\\", \\\"{x:385,y:400,t:1527876620439};\\\", \\\"{x:369,y:405,t:1527876620455};\\\", \\\"{x:363,y:409,t:1527876620472};\\\", \\\"{x:356,y:413,t:1527876620489};\\\", \\\"{x:352,y:416,t:1527876620506};\\\", \\\"{x:349,y:418,t:1527876620522};\\\", \\\"{x:346,y:420,t:1527876620539};\\\", \\\"{x:345,y:420,t:1527876620556};\\\", \\\"{x:345,y:421,t:1527876620572};\\\", \\\"{x:344,y:421,t:1527876620589};\\\", \\\"{x:342,y:423,t:1527876620606};\\\", \\\"{x:339,y:425,t:1527876620622};\\\", \\\"{x:335,y:427,t:1527876620639};\\\", \\\"{x:329,y:429,t:1527876620656};\\\", \\\"{x:329,y:430,t:1527876620672};\\\", \\\"{x:328,y:430,t:1527876620689};\\\", \\\"{x:330,y:430,t:1527876621128};\\\", \\\"{x:332,y:430,t:1527876621152};\\\", \\\"{x:333,y:430,t:1527876621168};\\\", \\\"{x:335,y:430,t:1527876621176};\\\", \\\"{x:336,y:429,t:1527876621217};\\\", \\\"{x:339,y:429,t:1527876621240};\\\", \\\"{x:342,y:427,t:1527876621256};\\\", \\\"{x:352,y:426,t:1527876621272};\\\", \\\"{x:372,y:426,t:1527876621290};\\\", \\\"{x:394,y:430,t:1527876621306};\\\", \\\"{x:401,y:432,t:1527876621322};\\\", \\\"{x:414,y:432,t:1527876621339};\\\", \\\"{x:424,y:432,t:1527876621356};\\\", \\\"{x:435,y:431,t:1527876621372};\\\", \\\"{x:436,y:430,t:1527876621391};\\\", \\\"{x:438,y:429,t:1527876621407};\\\", \\\"{x:439,y:429,t:1527876621423};\\\", \\\"{x:439,y:428,t:1527876621439};\\\", \\\"{x:446,y:427,t:1527876621456};\\\", \\\"{x:449,y:427,t:1527876621472};\\\", \\\"{x:454,y:427,t:1527876621489};\\\", \\\"{x:458,y:427,t:1527876621506};\\\", \\\"{x:463,y:427,t:1527876621522};\\\", \\\"{x:470,y:427,t:1527876621539};\\\", \\\"{x:478,y:427,t:1527876621556};\\\", \\\"{x:486,y:427,t:1527876621572};\\\", \\\"{x:491,y:430,t:1527876621590};\\\", \\\"{x:499,y:433,t:1527876621607};\\\", \\\"{x:500,y:434,t:1527876621624};\\\", \\\"{x:501,y:435,t:1527876621664};\\\", \\\"{x:502,y:435,t:1527876621673};\\\", \\\"{x:502,y:439,t:1527876621689};\\\", \\\"{x:503,y:441,t:1527876621707};\\\", \\\"{x:505,y:447,t:1527876621723};\\\", \\\"{x:505,y:453,t:1527876621739};\\\", \\\"{x:502,y:460,t:1527876621756};\\\", \\\"{x:498,y:465,t:1527876621773};\\\", \\\"{x:496,y:468,t:1527876621789};\\\", \\\"{x:489,y:477,t:1527876621807};\\\", \\\"{x:482,y:486,t:1527876621823};\\\", \\\"{x:474,y:492,t:1527876621838};\\\", \\\"{x:461,y:501,t:1527876621856};\\\", \\\"{x:451,y:506,t:1527876621873};\\\", \\\"{x:446,y:511,t:1527876621889};\\\", \\\"{x:442,y:513,t:1527876621906};\\\", \\\"{x:441,y:513,t:1527876621927};\\\", \\\"{x:440,y:513,t:1527876621976};\\\", \\\"{x:439,y:514,t:1527876621999};\\\", \\\"{x:439,y:515,t:1527876622007};\\\", \\\"{x:438,y:515,t:1527876622024};\\\", \\\"{x:437,y:515,t:1527876622993};\\\", \\\"{x:437,y:513,t:1527876623016};\\\", \\\"{x:441,y:513,t:1527876623023};\\\", \\\"{x:455,y:513,t:1527876623040};\\\", \\\"{x:471,y:513,t:1527876623057};\\\", \\\"{x:495,y:513,t:1527876623074};\\\", \\\"{x:521,y:513,t:1527876623091};\\\", \\\"{x:544,y:513,t:1527876623106};\\\", \\\"{x:577,y:514,t:1527876623124};\\\", \\\"{x:593,y:517,t:1527876623140};\\\", \\\"{x:613,y:518,t:1527876623156};\\\", \\\"{x:631,y:519,t:1527876623173};\\\", \\\"{x:649,y:520,t:1527876623190};\\\", \\\"{x:666,y:525,t:1527876623207};\\\", \\\"{x:688,y:526,t:1527876623223};\\\", \\\"{x:712,y:529,t:1527876623240};\\\", \\\"{x:732,y:530,t:1527876623256};\\\", \\\"{x:748,y:530,t:1527876623273};\\\", \\\"{x:754,y:532,t:1527876623290};\\\", \\\"{x:761,y:533,t:1527876623307};\\\", \\\"{x:765,y:533,t:1527876623323};\\\", \\\"{x:769,y:533,t:1527876623340};\\\", \\\"{x:774,y:533,t:1527876623356};\\\", \\\"{x:784,y:533,t:1527876623373};\\\", \\\"{x:791,y:533,t:1527876623390};\\\", \\\"{x:807,y:535,t:1527876623407};\\\", \\\"{x:822,y:537,t:1527876623423};\\\", \\\"{x:842,y:539,t:1527876623440};\\\", \\\"{x:858,y:539,t:1527876623457};\\\", \\\"{x:878,y:542,t:1527876623475};\\\", \\\"{x:889,y:543,t:1527876623489};\\\", \\\"{x:903,y:544,t:1527876623506};\\\", \\\"{x:912,y:545,t:1527876623525};\\\", \\\"{x:927,y:548,t:1527876623541};\\\", \\\"{x:938,y:549,t:1527876623557};\\\", \\\"{x:949,y:552,t:1527876623575};\\\", \\\"{x:953,y:552,t:1527876623592};\\\", \\\"{x:954,y:552,t:1527876623687};\\\", \\\"{x:955,y:552,t:1527876623695};\\\", \\\"{x:956,y:552,t:1527876623708};\\\", \\\"{x:958,y:552,t:1527876623725};\\\", \\\"{x:963,y:552,t:1527876623743};\\\", \\\"{x:973,y:551,t:1527876623758};\\\", \\\"{x:1003,y:546,t:1527876623776};\\\", \\\"{x:1028,y:540,t:1527876623792};\\\", \\\"{x:1065,y:536,t:1527876623808};\\\", \\\"{x:1126,y:526,t:1527876623825};\\\", \\\"{x:1165,y:516,t:1527876623842};\\\", \\\"{x:1203,y:507,t:1527876623858};\\\", \\\"{x:1258,y:496,t:1527876623875};\\\", \\\"{x:1290,y:495,t:1527876623892};\\\", \\\"{x:1315,y:489,t:1527876623909};\\\", \\\"{x:1329,y:485,t:1527876623926};\\\", \\\"{x:1335,y:483,t:1527876623942};\\\", \\\"{x:1340,y:482,t:1527876623958};\\\", \\\"{x:1346,y:479,t:1527876623976};\\\", \\\"{x:1368,y:473,t:1527876623992};\\\", \\\"{x:1382,y:467,t:1527876624009};\\\", \\\"{x:1399,y:462,t:1527876624025};\\\", \\\"{x:1430,y:455,t:1527876624042};\\\", \\\"{x:1450,y:448,t:1527876624058};\\\", \\\"{x:1460,y:446,t:1527876624075};\\\", \\\"{x:1466,y:445,t:1527876624093};\\\", \\\"{x:1469,y:444,t:1527876624108};\\\", \\\"{x:1471,y:444,t:1527876624126};\\\", \\\"{x:1476,y:442,t:1527876624143};\\\", \\\"{x:1489,y:441,t:1527876624159};\\\", \\\"{x:1520,y:439,t:1527876624176};\\\", \\\"{x:1533,y:437,t:1527876624192};\\\", \\\"{x:1545,y:435,t:1527876624210};\\\", \\\"{x:1549,y:435,t:1527876624226};\\\", \\\"{x:1553,y:435,t:1527876624242};\\\", \\\"{x:1555,y:435,t:1527876624259};\\\", \\\"{x:1556,y:435,t:1527876624275};\\\", \\\"{x:1557,y:435,t:1527876624293};\\\", \\\"{x:1563,y:435,t:1527876624309};\\\", \\\"{x:1569,y:435,t:1527876624325};\\\", \\\"{x:1576,y:435,t:1527876624342};\\\", \\\"{x:1582,y:434,t:1527876624360};\\\", \\\"{x:1587,y:432,t:1527876624408};\\\", \\\"{x:1588,y:432,t:1527876624426};\\\", \\\"{x:1590,y:432,t:1527876624442};\\\", \\\"{x:1594,y:432,t:1527876624460};\\\", \\\"{x:1601,y:432,t:1527876624476};\\\", \\\"{x:1602,y:431,t:1527876624492};\\\", \\\"{x:1603,y:431,t:1527876624509};\\\", \\\"{x:1605,y:430,t:1527876624553};\\\", \\\"{x:1606,y:430,t:1527876624568};\\\", \\\"{x:1609,y:430,t:1527876624581};\\\", \\\"{x:1612,y:429,t:1527876624591};\\\", \\\"{x:1613,y:429,t:1527876624608};\\\", \\\"{x:1615,y:428,t:1527876624626};\\\", \\\"{x:1613,y:428,t:1527876625608};\\\", \\\"{x:1611,y:430,t:1527876625616};\\\", \\\"{x:1608,y:430,t:1527876625630};\\\", \\\"{x:1607,y:437,t:1527876625644};\\\", \\\"{x:1599,y:451,t:1527876625660};\\\", \\\"{x:1588,y:470,t:1527876625676};\\\", \\\"{x:1575,y:485,t:1527876625693};\\\", \\\"{x:1564,y:503,t:1527876625710};\\\", \\\"{x:1550,y:524,t:1527876625726};\\\", \\\"{x:1535,y:555,t:1527876625743};\\\", \\\"{x:1522,y:579,t:1527876625760};\\\", \\\"{x:1508,y:598,t:1527876625776};\\\", \\\"{x:1502,y:611,t:1527876625794};\\\", \\\"{x:1501,y:616,t:1527876625811};\\\", \\\"{x:1501,y:618,t:1527876625826};\\\", \\\"{x:1501,y:619,t:1527876625843};\\\", \\\"{x:1501,y:622,t:1527876625861};\\\", \\\"{x:1501,y:625,t:1527876625876};\\\", \\\"{x:1499,y:633,t:1527876625893};\\\", \\\"{x:1497,y:641,t:1527876625910};\\\", \\\"{x:1495,y:645,t:1527876625928};\\\", \\\"{x:1495,y:646,t:1527876625952};\\\", \\\"{x:1498,y:646,t:1527876626080};\\\", \\\"{x:1502,y:646,t:1527876626094};\\\", \\\"{x:1507,y:642,t:1527876626110};\\\", \\\"{x:1511,y:636,t:1527876626127};\\\", \\\"{x:1512,y:634,t:1527876626144};\\\", \\\"{x:1512,y:633,t:1527876626160};\\\", \\\"{x:1514,y:632,t:1527876626177};\\\", \\\"{x:1513,y:631,t:1527876626817};\\\", \\\"{x:1466,y:631,t:1527876626845};\\\", \\\"{x:1408,y:631,t:1527876626861};\\\", \\\"{x:1326,y:627,t:1527876626877};\\\", \\\"{x:1242,y:626,t:1527876626895};\\\", \\\"{x:1120,y:613,t:1527876626911};\\\", \\\"{x:1057,y:608,t:1527876626927};\\\", \\\"{x:1001,y:600,t:1527876626944};\\\", \\\"{x:948,y:585,t:1527876626962};\\\", \\\"{x:889,y:569,t:1527876626978};\\\", \\\"{x:810,y:552,t:1527876626994};\\\", \\\"{x:756,y:541,t:1527876627011};\\\", \\\"{x:706,y:529,t:1527876627027};\\\", \\\"{x:638,y:525,t:1527876627044};\\\", \\\"{x:578,y:519,t:1527876627062};\\\", \\\"{x:548,y:521,t:1527876627078};\\\", \\\"{x:529,y:522,t:1527876627094};\\\", \\\"{x:513,y:523,t:1527876627111};\\\", \\\"{x:508,y:524,t:1527876627127};\\\", \\\"{x:506,y:527,t:1527876627145};\\\", \\\"{x:499,y:530,t:1527876627162};\\\", \\\"{x:494,y:533,t:1527876627178};\\\", \\\"{x:492,y:533,t:1527876627195};\\\", \\\"{x:491,y:533,t:1527876627211};\\\", \\\"{x:490,y:534,t:1527876627229};\\\", \\\"{x:486,y:536,t:1527876627244};\\\", \\\"{x:479,y:540,t:1527876627261};\\\", \\\"{x:465,y:545,t:1527876627280};\\\", \\\"{x:457,y:551,t:1527876627293};\\\", \\\"{x:454,y:553,t:1527876627311};\\\", \\\"{x:452,y:554,t:1527876627328};\\\", \\\"{x:451,y:554,t:1527876627351};\\\", \\\"{x:450,y:556,t:1527876627361};\\\", \\\"{x:447,y:558,t:1527876627378};\\\", \\\"{x:445,y:561,t:1527876627394};\\\", \\\"{x:445,y:565,t:1527876627411};\\\", \\\"{x:445,y:569,t:1527876627428};\\\", \\\"{x:445,y:571,t:1527876627444};\\\", \\\"{x:448,y:573,t:1527876627461};\\\", \\\"{x:454,y:574,t:1527876627478};\\\", \\\"{x:470,y:579,t:1527876627494};\\\", \\\"{x:512,y:587,t:1527876627512};\\\", \\\"{x:535,y:591,t:1527876627528};\\\", \\\"{x:566,y:594,t:1527876627545};\\\", \\\"{x:591,y:597,t:1527876627561};\\\", \\\"{x:601,y:597,t:1527876627578};\\\", \\\"{x:603,y:597,t:1527876627607};\\\", \\\"{x:603,y:598,t:1527876627704};\\\", \\\"{x:601,y:599,t:1527876627712};\\\", \\\"{x:597,y:602,t:1527876627729};\\\", \\\"{x:588,y:604,t:1527876627745};\\\", \\\"{x:571,y:608,t:1527876627762};\\\", \\\"{x:550,y:614,t:1527876627779};\\\", \\\"{x:509,y:618,t:1527876627796};\\\", \\\"{x:477,y:618,t:1527876627811};\\\", \\\"{x:435,y:618,t:1527876627828};\\\", \\\"{x:402,y:618,t:1527876627845};\\\", \\\"{x:384,y:618,t:1527876627861};\\\", \\\"{x:370,y:618,t:1527876627877};\\\", \\\"{x:363,y:618,t:1527876627894};\\\", \\\"{x:362,y:618,t:1527876627943};\\\", \\\"{x:360,y:617,t:1527876627960};\\\", \\\"{x:349,y:614,t:1527876627978};\\\", \\\"{x:342,y:613,t:1527876627995};\\\", \\\"{x:335,y:613,t:1527876628012};\\\", \\\"{x:334,y:613,t:1527876628028};\\\", \\\"{x:335,y:614,t:1527876628160};\\\", \\\"{x:337,y:617,t:1527876628168};\\\", \\\"{x:340,y:619,t:1527876628179};\\\", \\\"{x:345,y:622,t:1527876628194};\\\", \\\"{x:346,y:622,t:1527876628212};\\\", \\\"{x:349,y:622,t:1527876628228};\\\", \\\"{x:351,y:623,t:1527876628255};\\\", \\\"{x:353,y:623,t:1527876628263};\\\", \\\"{x:358,y:623,t:1527876628279};\\\", \\\"{x:359,y:623,t:1527876628295};\\\", \\\"{x:361,y:625,t:1527876628312};\\\", \\\"{x:362,y:626,t:1527876628329};\\\", \\\"{x:363,y:627,t:1527876628359};\\\", \\\"{x:364,y:628,t:1527876628367};\\\", \\\"{x:365,y:630,t:1527876628449};\\\", \\\"{x:366,y:631,t:1527876628462};\\\", \\\"{x:370,y:636,t:1527876628479};\\\", \\\"{x:373,y:637,t:1527876628496};\\\", \\\"{x:376,y:637,t:1527876628513};\\\", \\\"{x:379,y:638,t:1527876628530};\\\", \\\"{x:380,y:639,t:1527876628546};\\\", \\\"{x:382,y:639,t:1527876628562};\\\", \\\"{x:383,y:639,t:1527876628580};\\\", \\\"{x:387,y:639,t:1527876628595};\\\", \\\"{x:389,y:639,t:1527876628612};\\\", \\\"{x:390,y:639,t:1527876628631};\\\", \\\"{x:391,y:640,t:1527876630552};\\\", \\\"{x:392,y:641,t:1527876630563};\\\", \\\"{x:404,y:655,t:1527876630582};\\\", \\\"{x:413,y:664,t:1527876630599};\\\", \\\"{x:435,y:682,t:1527876630613};\\\", \\\"{x:463,y:706,t:1527876630630};\\\", \\\"{x:484,y:727,t:1527876630647};\\\", \\\"{x:498,y:738,t:1527876630664};\\\", \\\"{x:501,y:745,t:1527876630680};\\\", \\\"{x:506,y:751,t:1527876630697};\\\", \\\"{x:507,y:752,t:1527876630719};\\\", \\\"{x:508,y:753,t:1527876630872};\\\", \\\"{x:515,y:753,t:1527876631193};\\\", \\\"{x:536,y:753,t:1527876631200};\\\", \\\"{x:569,y:753,t:1527876631215};\\\", \\\"{x:652,y:753,t:1527876631231};\\\", \\\"{x:824,y:739,t:1527876631250};\\\", \\\"{x:946,y:719,t:1527876631268};\\\", \\\"{x:1061,y:696,t:1527876631284};\\\", \\\"{x:1119,y:683,t:1527876631302};\\\", \\\"{x:1163,y:665,t:1527876631317};\\\", \\\"{x:1183,y:654,t:1527876631334};\\\", \\\"{x:1199,y:645,t:1527876631352};\\\", \\\"{x:1214,y:636,t:1527876631368};\\\", \\\"{x:1226,y:627,t:1527876631384};\\\", \\\"{x:1246,y:616,t:1527876631402};\\\", \\\"{x:1278,y:606,t:1527876631418};\\\", \\\"{x:1285,y:603,t:1527876631435};\\\", \\\"{x:1293,y:599,t:1527876631451};\\\", \\\"{x:1303,y:597,t:1527876631469};\\\", \\\"{x:1315,y:594,t:1527876631485};\\\", \\\"{x:1330,y:594,t:1527876631502};\\\", \\\"{x:1367,y:594,t:1527876631519};\\\", \\\"{x:1402,y:595,t:1527876631535};\\\", \\\"{x:1428,y:594,t:1527876631552};\\\", \\\"{x:1457,y:597,t:1527876631570};\\\", \\\"{x:1484,y:600,t:1527876631585};\\\", \\\"{x:1501,y:601,t:1527876631602};\\\", \\\"{x:1503,y:602,t:1527876631619};\\\", \\\"{x:1506,y:603,t:1527876631676};\\\", \\\"{x:1508,y:603,t:1527876631687};\\\", \\\"{x:1523,y:604,t:1527876631702};\\\", \\\"{x:1530,y:605,t:1527876631720};\\\", \\\"{x:1539,y:606,t:1527876631736};\\\", \\\"{x:1540,y:607,t:1527876631752};\\\", \\\"{x:1536,y:609,t:1527876631787};\\\", \\\"{x:1534,y:611,t:1527876631803};\\\", \\\"{x:1525,y:621,t:1527876631819};\\\", \\\"{x:1524,y:626,t:1527876631837};\\\", \\\"{x:1522,y:631,t:1527876631854};\\\", \\\"{x:1521,y:634,t:1527876631869};\\\", \\\"{x:1519,y:636,t:1527876631886};\\\", \\\"{x:1518,y:638,t:1527876631904};\\\", \\\"{x:1517,y:639,t:1527876631919};\\\", \\\"{x:1517,y:642,t:1527876631936};\\\", \\\"{x:1516,y:643,t:1527876631979};\\\", \\\"{x:1515,y:643,t:1527876632364};\\\", \\\"{x:1510,y:643,t:1527876632371};\\\", \\\"{x:1491,y:651,t:1527876632387};\\\", \\\"{x:1463,y:666,t:1527876632403};\\\", \\\"{x:1414,y:685,t:1527876632420};\\\", \\\"{x:1344,y:706,t:1527876632438};\\\", \\\"{x:1275,y:724,t:1527876632454};\\\", \\\"{x:1210,y:751,t:1527876632470};\\\", \\\"{x:1128,y:770,t:1527876632487};\\\", \\\"{x:1059,y:789,t:1527876632504};\\\", \\\"{x:1039,y:801,t:1527876632520};\\\", \\\"{x:1030,y:805,t:1527876632537};\\\", \\\"{x:1026,y:806,t:1527876632554};\\\", \\\"{x:1026,y:810,t:1527876632570};\\\", \\\"{x:987,y:808,t:1527876632732};\\\", \\\"{x:929,y:795,t:1527876632740};\\\", \\\"{x:872,y:785,t:1527876632754};\\\", \\\"{x:780,y:766,t:1527876632771};\\\", \\\"{x:752,y:760,t:1527876632787};\\\", \\\"{x:741,y:756,t:1527876632805};\\\", \\\"{x:736,y:755,t:1527876632821};\\\", \\\"{x:735,y:754,t:1527876632837};\\\", \\\"{x:733,y:754,t:1527876632854};\\\", \\\"{x:728,y:754,t:1527876632871};\\\", \\\"{x:720,y:754,t:1527876632887};\\\", \\\"{x:714,y:752,t:1527876632903};\\\", \\\"{x:710,y:752,t:1527876632920};\\\", \\\"{x:698,y:752,t:1527876632937};\\\", \\\"{x:673,y:752,t:1527876632954};\\\", \\\"{x:628,y:750,t:1527876632971};\\\", \\\"{x:598,y:745,t:1527876632988};\\\", \\\"{x:588,y:744,t:1527876633005};\\\", \\\"{x:585,y:742,t:1527876633021};\\\", \\\"{x:584,y:742,t:1527876633038};\\\", \\\"{x:582,y:742,t:1527876633116};\\\", \\\"{x:581,y:742,t:1527876633131};\\\", \\\"{x:581,y:741,t:1527876633147};\\\", \\\"{x:579,y:741,t:1527876633155};\\\", \\\"{x:574,y:740,t:1527876633171};\\\", \\\"{x:570,y:738,t:1527876633188};\\\", \\\"{x:566,y:736,t:1527876633205};\\\", \\\"{x:564,y:735,t:1527876633222};\\\", \\\"{x:562,y:734,t:1527876633238};\\\", \\\"{x:558,y:733,t:1527876633255};\\\", \\\"{x:557,y:733,t:1527876633272};\\\", \\\"{x:555,y:733,t:1527876633287};\\\", \\\"{x:552,y:733,t:1527876633304};\\\", \\\"{x:551,y:733,t:1527876633387};\\\", \\\"{x:550,y:733,t:1527876633394};\\\", \\\"{x:548,y:734,t:1527876633404};\\\", \\\"{x:546,y:734,t:1527876633422};\\\", \\\"{x:545,y:735,t:1527876633459};\\\", \\\"{x:545,y:736,t:1527876633475};\\\", \\\"{x:542,y:739,t:1527876633490};\\\", \\\"{x:541,y:742,t:1527876633505};\\\", \\\"{x:534,y:749,t:1527876633521};\\\", \\\"{x:530,y:753,t:1527876633536};\\\", \\\"{x:529,y:754,t:1527876633552};\\\", \\\"{x:529,y:750,t:1527876634196};\\\", \\\"{x:529,y:747,t:1527876634204};\\\", \\\"{x:531,y:742,t:1527876634220};\\\", \\\"{x:534,y:734,t:1527876634237};\\\", \\\"{x:539,y:727,t:1527876634254};\\\", \\\"{x:547,y:715,t:1527876634270};\\\", \\\"{x:549,y:713,t:1527876634287};\\\", \\\"{x:550,y:712,t:1527876634304};\\\", \\\"{x:550,y:709,t:1527876634320};\\\", \\\"{x:550,y:705,t:1527876634337};\\\", \\\"{x:553,y:704,t:1527876634354};\\\" ] }, { \\\"rt\\\": 17131, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 7, \\\"time_elapsed\\\": 260133, \\\"internal_node_id\\\": \\\"0.0-5.0-2.0\\\", \\\"subject\\\": \\\"7BW1K\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 3, \\\"clicks\\\": 1, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-C -C -C -C -C -F -F \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:553,y:703,t:1527876635203};\\\", \\\"{x:554,y:701,t:1527876635218};\\\", \\\"{x:555,y:700,t:1527876635226};\\\", \\\"{x:557,y:700,t:1527876635238};\\\", \\\"{x:562,y:696,t:1527876635254};\\\", \\\"{x:569,y:692,t:1527876635271};\\\", \\\"{x:574,y:689,t:1527876635288};\\\", \\\"{x:575,y:688,t:1527876635305};\\\", \\\"{x:576,y:688,t:1527876635321};\\\", \\\"{x:578,y:687,t:1527876635338};\\\", \\\"{x:580,y:685,t:1527876635355};\\\", \\\"{x:581,y:684,t:1527876635371};\\\", \\\"{x:581,y:683,t:1527876635867};\\\", \\\"{x:583,y:683,t:1527876636244};\\\", \\\"{x:585,y:681,t:1527876636256};\\\", \\\"{x:586,y:676,t:1527876636272};\\\", \\\"{x:589,y:668,t:1527876636289};\\\", \\\"{x:593,y:661,t:1527876636305};\\\", \\\"{x:599,y:652,t:1527876636322};\\\", \\\"{x:602,y:645,t:1527876636340};\\\", \\\"{x:602,y:641,t:1527876636355};\\\", \\\"{x:602,y:633,t:1527876636371};\\\", \\\"{x:597,y:622,t:1527876636389};\\\", \\\"{x:585,y:611,t:1527876636405};\\\", \\\"{x:565,y:597,t:1527876636422};\\\", \\\"{x:546,y:585,t:1527876636439};\\\", \\\"{x:520,y:574,t:1527876636455};\\\", \\\"{x:500,y:566,t:1527876636472};\\\", \\\"{x:477,y:556,t:1527876636489};\\\", \\\"{x:444,y:549,t:1527876636506};\\\", \\\"{x:425,y:543,t:1527876636522};\\\", \\\"{x:396,y:540,t:1527876636539};\\\", \\\"{x:384,y:539,t:1527876636555};\\\", \\\"{x:383,y:539,t:1527876636572};\\\", \\\"{x:381,y:539,t:1527876636594};\\\", \\\"{x:379,y:539,t:1527876636611};\\\", \\\"{x:378,y:539,t:1527876636622};\\\", \\\"{x:370,y:541,t:1527876636639};\\\", \\\"{x:359,y:541,t:1527876636655};\\\", \\\"{x:343,y:545,t:1527876636672};\\\", \\\"{x:336,y:545,t:1527876636688};\\\", \\\"{x:330,y:546,t:1527876636706};\\\", \\\"{x:315,y:553,t:1527876636722};\\\", \\\"{x:285,y:555,t:1527876636739};\\\", \\\"{x:260,y:555,t:1527876636757};\\\", \\\"{x:236,y:556,t:1527876636772};\\\", \\\"{x:217,y:556,t:1527876636788};\\\", \\\"{x:199,y:559,t:1527876636806};\\\", \\\"{x:195,y:559,t:1527876636822};\\\", \\\"{x:194,y:560,t:1527876636839};\\\", \\\"{x:192,y:560,t:1527876636856};\\\", \\\"{x:183,y:563,t:1527876636872};\\\", \\\"{x:172,y:564,t:1527876636889};\\\", \\\"{x:166,y:564,t:1527876636906};\\\", \\\"{x:161,y:564,t:1527876636921};\\\", \\\"{x:159,y:564,t:1527876636995};\\\", \\\"{x:158,y:564,t:1527876637006};\\\", \\\"{x:156,y:564,t:1527876637023};\\\", \\\"{x:154,y:563,t:1527876637040};\\\", \\\"{x:152,y:562,t:1527876637057};\\\", \\\"{x:149,y:560,t:1527876637074};\\\", \\\"{x:147,y:558,t:1527876637090};\\\", \\\"{x:146,y:558,t:1527876637138};\\\", \\\"{x:146,y:557,t:1527876637348};\\\", \\\"{x:147,y:556,t:1527876637356};\\\", \\\"{x:147,y:555,t:1527876637373};\\\", \\\"{x:149,y:554,t:1527876637390};\\\", \\\"{x:151,y:554,t:1527876637407};\\\", \\\"{x:153,y:553,t:1527876637424};\\\", \\\"{x:154,y:552,t:1527876637451};\\\", \\\"{x:155,y:551,t:1527876637459};\\\", \\\"{x:156,y:550,t:1527876637474};\\\", \\\"{x:157,y:550,t:1527876637499};\\\", \\\"{x:159,y:549,t:1527876638747};\\\", \\\"{x:165,y:547,t:1527876638757};\\\", \\\"{x:176,y:541,t:1527876638775};\\\", \\\"{x:188,y:536,t:1527876638790};\\\", \\\"{x:195,y:532,t:1527876638806};\\\", \\\"{x:204,y:529,t:1527876638824};\\\", \\\"{x:217,y:529,t:1527876638840};\\\", \\\"{x:249,y:529,t:1527876638857};\\\", \\\"{x:296,y:529,t:1527876638873};\\\", \\\"{x:440,y:529,t:1527876638890};\\\", \\\"{x:532,y:529,t:1527876638907};\\\", \\\"{x:623,y:529,t:1527876638923};\\\", \\\"{x:720,y:529,t:1527876638941};\\\", \\\"{x:809,y:529,t:1527876638957};\\\", \\\"{x:869,y:530,t:1527876638974};\\\", \\\"{x:947,y:530,t:1527876638991};\\\", \\\"{x:989,y:530,t:1527876639007};\\\", \\\"{x:1024,y:532,t:1527876639024};\\\", \\\"{x:1072,y:531,t:1527876639041};\\\", \\\"{x:1131,y:531,t:1527876639059};\\\", \\\"{x:1181,y:531,t:1527876639075};\\\", \\\"{x:1213,y:531,t:1527876639091};\\\", \\\"{x:1227,y:530,t:1527876639109};\\\", \\\"{x:1234,y:530,t:1527876639125};\\\", \\\"{x:1237,y:530,t:1527876639142};\\\", \\\"{x:1239,y:530,t:1527876639158};\\\", \\\"{x:1242,y:533,t:1527876639174};\\\", \\\"{x:1248,y:537,t:1527876639191};\\\", \\\"{x:1253,y:541,t:1527876639208};\\\", \\\"{x:1256,y:543,t:1527876639225};\\\", \\\"{x:1260,y:545,t:1527876639241};\\\", \\\"{x:1262,y:546,t:1527876639259};\\\", \\\"{x:1263,y:547,t:1527876639275};\\\", \\\"{x:1266,y:547,t:1527876639299};\\\", \\\"{x:1267,y:547,t:1527876639364};\\\", \\\"{x:1269,y:547,t:1527876639374};\\\", \\\"{x:1270,y:547,t:1527876639391};\\\", \\\"{x:1272,y:547,t:1527876639409};\\\", \\\"{x:1274,y:547,t:1527876639425};\\\", \\\"{x:1276,y:547,t:1527876639442};\\\", \\\"{x:1277,y:547,t:1527876639459};\\\", \\\"{x:1278,y:547,t:1527876639474};\\\", \\\"{x:1279,y:547,t:1527876639491};\\\", \\\"{x:1282,y:547,t:1527876639509};\\\", \\\"{x:1286,y:546,t:1527876639525};\\\", \\\"{x:1290,y:546,t:1527876639541};\\\", \\\"{x:1294,y:546,t:1527876639559};\\\", \\\"{x:1296,y:546,t:1527876639574};\\\", \\\"{x:1297,y:546,t:1527876639592};\\\", \\\"{x:1299,y:546,t:1527876639619};\\\", \\\"{x:1301,y:545,t:1527876639627};\\\", \\\"{x:1302,y:544,t:1527876639641};\\\", \\\"{x:1306,y:543,t:1527876639658};\\\", \\\"{x:1313,y:539,t:1527876639676};\\\", \\\"{x:1316,y:537,t:1527876639691};\\\", \\\"{x:1319,y:540,t:1527876639987};\\\", \\\"{x:1319,y:542,t:1527876640003};\\\", \\\"{x:1320,y:545,t:1527876640011};\\\", \\\"{x:1323,y:551,t:1527876640026};\\\", \\\"{x:1325,y:561,t:1527876640042};\\\", \\\"{x:1327,y:568,t:1527876640058};\\\", \\\"{x:1328,y:571,t:1527876640075};\\\", \\\"{x:1328,y:573,t:1527876640093};\\\", \\\"{x:1328,y:576,t:1527876640109};\\\", \\\"{x:1328,y:577,t:1527876640125};\\\", \\\"{x:1328,y:579,t:1527876640143};\\\", \\\"{x:1328,y:583,t:1527876640158};\\\", \\\"{x:1328,y:588,t:1527876640175};\\\", \\\"{x:1328,y:595,t:1527876640192};\\\", \\\"{x:1328,y:602,t:1527876640209};\\\", \\\"{x:1329,y:607,t:1527876640226};\\\", \\\"{x:1330,y:614,t:1527876640243};\\\", \\\"{x:1332,y:621,t:1527876640258};\\\", \\\"{x:1334,y:631,t:1527876640275};\\\", \\\"{x:1336,y:636,t:1527876640292};\\\", \\\"{x:1336,y:638,t:1527876640309};\\\", \\\"{x:1337,y:644,t:1527876640326};\\\", \\\"{x:1337,y:645,t:1527876640343};\\\", \\\"{x:1337,y:647,t:1527876640359};\\\", \\\"{x:1337,y:651,t:1527876640376};\\\", \\\"{x:1337,y:654,t:1527876640392};\\\", \\\"{x:1337,y:660,t:1527876640409};\\\", \\\"{x:1337,y:664,t:1527876640426};\\\", \\\"{x:1337,y:667,t:1527876640443};\\\", \\\"{x:1337,y:674,t:1527876640459};\\\", \\\"{x:1337,y:680,t:1527876640476};\\\", \\\"{x:1335,y:688,t:1527876640492};\\\", \\\"{x:1335,y:694,t:1527876640510};\\\", \\\"{x:1332,y:704,t:1527876640526};\\\", \\\"{x:1328,y:717,t:1527876640542};\\\", \\\"{x:1319,y:729,t:1527876640560};\\\", \\\"{x:1312,y:739,t:1527876640575};\\\", \\\"{x:1310,y:742,t:1527876640592};\\\", \\\"{x:1309,y:744,t:1527876640609};\\\", \\\"{x:1309,y:747,t:1527876640626};\\\", \\\"{x:1307,y:750,t:1527876640642};\\\", \\\"{x:1304,y:755,t:1527876640660};\\\", \\\"{x:1302,y:758,t:1527876640675};\\\", \\\"{x:1301,y:760,t:1527876640693};\\\", \\\"{x:1299,y:764,t:1527876640709};\\\", \\\"{x:1297,y:767,t:1527876640725};\\\", \\\"{x:1296,y:769,t:1527876640743};\\\", \\\"{x:1295,y:772,t:1527876640760};\\\", \\\"{x:1291,y:775,t:1527876640775};\\\", \\\"{x:1287,y:779,t:1527876640793};\\\", \\\"{x:1279,y:783,t:1527876640810};\\\", \\\"{x:1274,y:788,t:1527876640826};\\\", \\\"{x:1270,y:793,t:1527876640843};\\\", \\\"{x:1264,y:796,t:1527876640860};\\\", \\\"{x:1256,y:800,t:1527876640877};\\\", \\\"{x:1247,y:803,t:1527876640893};\\\", \\\"{x:1234,y:806,t:1527876640909};\\\", \\\"{x:1221,y:811,t:1527876640927};\\\", \\\"{x:1214,y:812,t:1527876640942};\\\", \\\"{x:1209,y:815,t:1527876640960};\\\", \\\"{x:1207,y:816,t:1527876640976};\\\", \\\"{x:1204,y:816,t:1527876640993};\\\", \\\"{x:1203,y:817,t:1527876641010};\\\", \\\"{x:1201,y:818,t:1527876641026};\\\", \\\"{x:1200,y:819,t:1527876641043};\\\", \\\"{x:1200,y:820,t:1527876641059};\\\", \\\"{x:1200,y:821,t:1527876641076};\\\", \\\"{x:1200,y:822,t:1527876641099};\\\", \\\"{x:1200,y:824,t:1527876641110};\\\", \\\"{x:1201,y:827,t:1527876641126};\\\", \\\"{x:1204,y:829,t:1527876641143};\\\", \\\"{x:1207,y:831,t:1527876641160};\\\", \\\"{x:1211,y:832,t:1527876641187};\\\", \\\"{x:1213,y:832,t:1527876641192};\\\", \\\"{x:1214,y:832,t:1527876641209};\\\", \\\"{x:1220,y:832,t:1527876644550};\\\", \\\"{x:1229,y:825,t:1527876644561};\\\", \\\"{x:1311,y:779,t:1527876644578};\\\", \\\"{x:1344,y:758,t:1527876644595};\\\", \\\"{x:1393,y:742,t:1527876644612};\\\", \\\"{x:1418,y:730,t:1527876644628};\\\", \\\"{x:1426,y:725,t:1527876644645};\\\", \\\"{x:1428,y:724,t:1527876644663};\\\", \\\"{x:1429,y:724,t:1527876644678};\\\", \\\"{x:1430,y:724,t:1527876644747};\\\", \\\"{x:1432,y:724,t:1527876644762};\\\", \\\"{x:1435,y:724,t:1527876644778};\\\", \\\"{x:1439,y:725,t:1527876644796};\\\", \\\"{x:1442,y:727,t:1527876644812};\\\", \\\"{x:1443,y:730,t:1527876644829};\\\", \\\"{x:1443,y:735,t:1527876644845};\\\", \\\"{x:1440,y:741,t:1527876644862};\\\", \\\"{x:1431,y:748,t:1527876644879};\\\", \\\"{x:1423,y:752,t:1527876644895};\\\", \\\"{x:1411,y:756,t:1527876644913};\\\", \\\"{x:1401,y:760,t:1527876644930};\\\", \\\"{x:1399,y:762,t:1527876644946};\\\", \\\"{x:1397,y:763,t:1527876644963};\\\", \\\"{x:1397,y:764,t:1527876645020};\\\", \\\"{x:1396,y:764,t:1527876645029};\\\", \\\"{x:1394,y:765,t:1527876645046};\\\", \\\"{x:1392,y:766,t:1527876645063};\\\", \\\"{x:1390,y:767,t:1527876645080};\\\", \\\"{x:1388,y:768,t:1527876645095};\\\", \\\"{x:1387,y:769,t:1527876645115};\\\", \\\"{x:1385,y:770,t:1527876645180};\\\", \\\"{x:1384,y:771,t:1527876645196};\\\", \\\"{x:1383,y:771,t:1527876645219};\\\", \\\"{x:1382,y:772,t:1527876645230};\\\", \\\"{x:1380,y:772,t:1527876645283};\\\", \\\"{x:1379,y:772,t:1527876645296};\\\", \\\"{x:1377,y:774,t:1527876645312};\\\", \\\"{x:1376,y:774,t:1527876645329};\\\", \\\"{x:1374,y:774,t:1527876645346};\\\", \\\"{x:1372,y:775,t:1527876645652};\\\", \\\"{x:1370,y:775,t:1527876645667};\\\", \\\"{x:1368,y:775,t:1527876645683};\\\", \\\"{x:1368,y:774,t:1527876645697};\\\", \\\"{x:1365,y:773,t:1527876645713};\\\", \\\"{x:1364,y:772,t:1527876645730};\\\", \\\"{x:1362,y:772,t:1527876645747};\\\", \\\"{x:1359,y:772,t:1527876645763};\\\", \\\"{x:1353,y:772,t:1527876645780};\\\", \\\"{x:1335,y:772,t:1527876645797};\\\", \\\"{x:1323,y:774,t:1527876645813};\\\", \\\"{x:1310,y:777,t:1527876645829};\\\", \\\"{x:1300,y:779,t:1527876645846};\\\", \\\"{x:1292,y:780,t:1527876645863};\\\", \\\"{x:1289,y:783,t:1527876645880};\\\", \\\"{x:1277,y:789,t:1527876645897};\\\", \\\"{x:1269,y:792,t:1527876645914};\\\", \\\"{x:1264,y:796,t:1527876645930};\\\", \\\"{x:1260,y:799,t:1527876645947};\\\", \\\"{x:1259,y:799,t:1527876645963};\\\", \\\"{x:1257,y:800,t:1527876645980};\\\", \\\"{x:1254,y:802,t:1527876645997};\\\", \\\"{x:1249,y:804,t:1527876646013};\\\", \\\"{x:1240,y:810,t:1527876646030};\\\", \\\"{x:1236,y:813,t:1527876646047};\\\", \\\"{x:1232,y:815,t:1527876646064};\\\", \\\"{x:1230,y:816,t:1527876646080};\\\", \\\"{x:1229,y:817,t:1527876646097};\\\", \\\"{x:1228,y:817,t:1527876646114};\\\", \\\"{x:1226,y:819,t:1527876646130};\\\", \\\"{x:1222,y:820,t:1527876646147};\\\", \\\"{x:1220,y:822,t:1527876646163};\\\", \\\"{x:1219,y:823,t:1527876646187};\\\", \\\"{x:1217,y:824,t:1527876646211};\\\", \\\"{x:1215,y:825,t:1527876646231};\\\", \\\"{x:1212,y:828,t:1527876646246};\\\", \\\"{x:1209,y:831,t:1527876646263};\\\", \\\"{x:1206,y:833,t:1527876646281};\\\", \\\"{x:1205,y:834,t:1527876646296};\\\", \\\"{x:1206,y:834,t:1527876646612};\\\", \\\"{x:1209,y:834,t:1527876646619};\\\", \\\"{x:1210,y:834,t:1527876646630};\\\", \\\"{x:1216,y:832,t:1527876646651};\\\", \\\"{x:1218,y:831,t:1527876646663};\\\", \\\"{x:1225,y:829,t:1527876647285};\\\", \\\"{x:1233,y:823,t:1527876647297};\\\", \\\"{x:1252,y:814,t:1527876647314};\\\", \\\"{x:1278,y:800,t:1527876647331};\\\", \\\"{x:1302,y:788,t:1527876647347};\\\", \\\"{x:1314,y:781,t:1527876647364};\\\", \\\"{x:1320,y:777,t:1527876647382};\\\", \\\"{x:1323,y:776,t:1527876647397};\\\", \\\"{x:1324,y:775,t:1527876647414};\\\", \\\"{x:1325,y:775,t:1527876647450};\\\", \\\"{x:1326,y:775,t:1527876647465};\\\", \\\"{x:1330,y:775,t:1527876647482};\\\", \\\"{x:1338,y:770,t:1527876647498};\\\", \\\"{x:1345,y:765,t:1527876647515};\\\", \\\"{x:1348,y:762,t:1527876647531};\\\", \\\"{x:1349,y:761,t:1527876647555};\\\", \\\"{x:1350,y:761,t:1527876647587};\\\", \\\"{x:1350,y:760,t:1527876647598};\\\", \\\"{x:1352,y:760,t:1527876647615};\\\", \\\"{x:1353,y:759,t:1527876647631};\\\", \\\"{x:1355,y:758,t:1527876647648};\\\", \\\"{x:1356,y:758,t:1527876647675};\\\", \\\"{x:1356,y:757,t:1527876647683};\\\", \\\"{x:1360,y:756,t:1527876647697};\\\", \\\"{x:1372,y:756,t:1527876647715};\\\", \\\"{x:1381,y:758,t:1527876647735};\\\", \\\"{x:1389,y:760,t:1527876647749};\\\", \\\"{x:1390,y:761,t:1527876647764};\\\", \\\"{x:1390,y:763,t:1527876647781};\\\", \\\"{x:1390,y:765,t:1527876647797};\\\", \\\"{x:1392,y:767,t:1527876647814};\\\", \\\"{x:1394,y:769,t:1527876647831};\\\", \\\"{x:1395,y:771,t:1527876647848};\\\", \\\"{x:1396,y:771,t:1527876647865};\\\", \\\"{x:1395,y:771,t:1527876647955};\\\", \\\"{x:1392,y:770,t:1527876647965};\\\", \\\"{x:1388,y:769,t:1527876647982};\\\", \\\"{x:1383,y:768,t:1527876648002};\\\", \\\"{x:1382,y:767,t:1527876648014};\\\", \\\"{x:1381,y:767,t:1527876648154};\\\", \\\"{x:1379,y:767,t:1527876649004};\\\", \\\"{x:1376,y:767,t:1527876649020};\\\", \\\"{x:1350,y:766,t:1527876649034};\\\", \\\"{x:1336,y:766,t:1527876649049};\\\", \\\"{x:1295,y:766,t:1527876649066};\\\", \\\"{x:1192,y:764,t:1527876649082};\\\", \\\"{x:1101,y:756,t:1527876649099};\\\", \\\"{x:1041,y:751,t:1527876649116};\\\", \\\"{x:987,y:742,t:1527876649132};\\\", \\\"{x:952,y:728,t:1527876649149};\\\", \\\"{x:930,y:720,t:1527876649166};\\\", \\\"{x:901,y:710,t:1527876649182};\\\", \\\"{x:884,y:701,t:1527876649199};\\\", \\\"{x:863,y:694,t:1527876649215};\\\", \\\"{x:840,y:689,t:1527876649232};\\\", \\\"{x:803,y:682,t:1527876649251};\\\", \\\"{x:795,y:681,t:1527876649265};\\\", \\\"{x:779,y:677,t:1527876649282};\\\", \\\"{x:767,y:676,t:1527876649299};\\\", \\\"{x:749,y:671,t:1527876649315};\\\", \\\"{x:709,y:663,t:1527876649334};\\\", \\\"{x:680,y:654,t:1527876649349};\\\", \\\"{x:645,y:642,t:1527876649365};\\\", \\\"{x:606,y:629,t:1527876649382};\\\", \\\"{x:584,y:620,t:1527876649399};\\\", \\\"{x:568,y:609,t:1527876649416};\\\", \\\"{x:545,y:599,t:1527876649432};\\\", \\\"{x:511,y:591,t:1527876649449};\\\", \\\"{x:487,y:581,t:1527876649466};\\\", \\\"{x:464,y:575,t:1527876649482};\\\", \\\"{x:461,y:574,t:1527876649499};\\\", \\\"{x:456,y:575,t:1527876649594};\\\", \\\"{x:453,y:576,t:1527876649602};\\\", \\\"{x:446,y:581,t:1527876649617};\\\", \\\"{x:428,y:591,t:1527876649632};\\\", \\\"{x:412,y:598,t:1527876649649};\\\", \\\"{x:400,y:602,t:1527876649666};\\\", \\\"{x:400,y:603,t:1527876649682};\\\", \\\"{x:399,y:603,t:1527876649722};\\\", \\\"{x:398,y:603,t:1527876649733};\\\", \\\"{x:397,y:603,t:1527876649749};\\\", \\\"{x:394,y:603,t:1527876649767};\\\", \\\"{x:393,y:603,t:1527876649867};\\\", \\\"{x:393,y:608,t:1527876650388};\\\", \\\"{x:399,y:617,t:1527876650401};\\\", \\\"{x:418,y:644,t:1527876650418};\\\", \\\"{x:443,y:684,t:1527876650434};\\\", \\\"{x:476,y:723,t:1527876650450};\\\", \\\"{x:496,y:742,t:1527876650467};\\\", \\\"{x:497,y:746,t:1527876650484};\\\", \\\"{x:498,y:746,t:1527876650555};\\\", \\\"{x:500,y:746,t:1527876650570};\\\", \\\"{x:502,y:746,t:1527876650583};\\\", \\\"{x:504,y:745,t:1527876650600};\\\", \\\"{x:505,y:743,t:1527876650616};\\\", \\\"{x:505,y:742,t:1527876650634};\\\", \\\"{x:506,y:742,t:1527876650675};\\\", \\\"{x:504,y:742,t:1527876650915};\\\", \\\"{x:504,y:743,t:1527876651331};\\\", \\\"{x:505,y:743,t:1527876652675};\\\", \\\"{x:507,y:743,t:1527876652684};\\\", \\\"{x:513,y:743,t:1527876652702};\\\", \\\"{x:521,y:739,t:1527876652718};\\\", \\\"{x:525,y:737,t:1527876652736};\\\", \\\"{x:533,y:731,t:1527876652751};\\\", \\\"{x:535,y:729,t:1527876652768};\\\", \\\"{x:548,y:720,t:1527876652785};\\\", \\\"{x:558,y:713,t:1527876652802};\\\", \\\"{x:561,y:710,t:1527876652819};\\\", \\\"{x:561,y:708,t:1527876652835};\\\", \\\"{x:564,y:704,t:1527876652851};\\\", \\\"{x:571,y:699,t:1527876652869};\\\", \\\"{x:571,y:698,t:1527876652890};\\\", \\\"{x:571,y:696,t:1527876652902};\\\" ] }, { \\\"rt\\\": 10016, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 8, \\\"time_elapsed\\\": 271394, \\\"internal_node_id\\\": \\\"0.0-5.0-3.0\\\", \\\"subject\\\": \\\"7BW1K\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 4, \\\"clicks\\\": 1, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"H\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F -H -H \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:574,y:691,t:1527876653444};\\\", \\\"{x:577,y:688,t:1527876653922};\\\", \\\"{x:579,y:686,t:1527876653937};\\\", \\\"{x:579,y:685,t:1527876653952};\\\", \\\"{x:580,y:680,t:1527876653969};\\\", \\\"{x:581,y:677,t:1527876653986};\\\", \\\"{x:582,y:676,t:1527876654379};\\\", \\\"{x:583,y:676,t:1527876654418};\\\", \\\"{x:584,y:675,t:1527876654491};\\\", \\\"{x:584,y:674,t:1527876654531};\\\", \\\"{x:585,y:674,t:1527876654539};\\\", \\\"{x:588,y:671,t:1527876654554};\\\", \\\"{x:593,y:666,t:1527876654570};\\\", \\\"{x:601,y:656,t:1527876654587};\\\", \\\"{x:604,y:652,t:1527876654605};\\\", \\\"{x:611,y:645,t:1527876654620};\\\", \\\"{x:614,y:643,t:1527876654636};\\\", \\\"{x:616,y:640,t:1527876654653};\\\", \\\"{x:618,y:639,t:1527876654669};\\\", \\\"{x:620,y:637,t:1527876654690};\\\", \\\"{x:623,y:636,t:1527876654703};\\\", \\\"{x:626,y:633,t:1527876654719};\\\", \\\"{x:635,y:626,t:1527876654736};\\\", \\\"{x:641,y:620,t:1527876654754};\\\", \\\"{x:645,y:617,t:1527876654770};\\\", \\\"{x:647,y:615,t:1527876654794};\\\", \\\"{x:647,y:612,t:1527876654850};\\\", \\\"{x:652,y:606,t:1527876654859};\\\", \\\"{x:660,y:600,t:1527876654871};\\\", \\\"{x:687,y:588,t:1527876654887};\\\", \\\"{x:716,y:582,t:1527876654903};\\\", \\\"{x:740,y:577,t:1527876654921};\\\", \\\"{x:767,y:572,t:1527876654938};\\\", \\\"{x:777,y:571,t:1527876654954};\\\", \\\"{x:804,y:567,t:1527876654970};\\\", \\\"{x:818,y:565,t:1527876654988};\\\", \\\"{x:833,y:566,t:1527876655004};\\\", \\\"{x:844,y:566,t:1527876655021};\\\", \\\"{x:857,y:566,t:1527876655038};\\\", \\\"{x:864,y:565,t:1527876655054};\\\", \\\"{x:875,y:568,t:1527876655072};\\\", \\\"{x:883,y:568,t:1527876655087};\\\", \\\"{x:891,y:568,t:1527876655104};\\\", \\\"{x:898,y:569,t:1527876655121};\\\", \\\"{x:903,y:569,t:1527876655138};\\\", \\\"{x:908,y:571,t:1527876655154};\\\", \\\"{x:910,y:571,t:1527876655170};\\\", \\\"{x:913,y:571,t:1527876655188};\\\", \\\"{x:916,y:571,t:1527876655204};\\\", \\\"{x:921,y:571,t:1527876655220};\\\", \\\"{x:928,y:571,t:1527876655237};\\\", \\\"{x:938,y:571,t:1527876655254};\\\", \\\"{x:947,y:572,t:1527876655271};\\\", \\\"{x:957,y:572,t:1527876655289};\\\", \\\"{x:976,y:574,t:1527876655304};\\\", \\\"{x:999,y:577,t:1527876655319};\\\", \\\"{x:1024,y:579,t:1527876655335};\\\", \\\"{x:1053,y:583,t:1527876655352};\\\", \\\"{x:1077,y:585,t:1527876655369};\\\", \\\"{x:1096,y:589,t:1527876655385};\\\", \\\"{x:1121,y:592,t:1527876655402};\\\", \\\"{x:1140,y:596,t:1527876655420};\\\", \\\"{x:1155,y:600,t:1527876655436};\\\", \\\"{x:1185,y:608,t:1527876655452};\\\", \\\"{x:1209,y:613,t:1527876655469};\\\", \\\"{x:1234,y:618,t:1527876655486};\\\", \\\"{x:1254,y:627,t:1527876655503};\\\", \\\"{x:1261,y:631,t:1527876655519};\\\", \\\"{x:1270,y:637,t:1527876655536};\\\", \\\"{x:1282,y:646,t:1527876655553};\\\", \\\"{x:1295,y:658,t:1527876655569};\\\", \\\"{x:1307,y:668,t:1527876655586};\\\", \\\"{x:1320,y:678,t:1527876655602};\\\", \\\"{x:1341,y:696,t:1527876655620};\\\", \\\"{x:1354,y:705,t:1527876655636};\\\", \\\"{x:1358,y:709,t:1527876655653};\\\", \\\"{x:1363,y:717,t:1527876655670};\\\", \\\"{x:1366,y:721,t:1527876655687};\\\", \\\"{x:1370,y:730,t:1527876655702};\\\", \\\"{x:1375,y:739,t:1527876655719};\\\", \\\"{x:1376,y:742,t:1527876655736};\\\", \\\"{x:1378,y:747,t:1527876655752};\\\", \\\"{x:1380,y:750,t:1527876655769};\\\", \\\"{x:1381,y:754,t:1527876655785};\\\", \\\"{x:1383,y:757,t:1527876655802};\\\", \\\"{x:1387,y:762,t:1527876655819};\\\", \\\"{x:1390,y:765,t:1527876655835};\\\", \\\"{x:1391,y:765,t:1527876655852};\\\", \\\"{x:1391,y:766,t:1527876655870};\\\", \\\"{x:1391,y:767,t:1527876655885};\\\", \\\"{x:1391,y:768,t:1527876655903};\\\", \\\"{x:1393,y:771,t:1527876655918};\\\", \\\"{x:1396,y:774,t:1527876655935};\\\", \\\"{x:1398,y:777,t:1527876655953};\\\", \\\"{x:1402,y:782,t:1527876655968};\\\", \\\"{x:1402,y:785,t:1527876655986};\\\", \\\"{x:1405,y:787,t:1527876656002};\\\", \\\"{x:1407,y:789,t:1527876656019};\\\", \\\"{x:1411,y:794,t:1527876656035};\\\", \\\"{x:1415,y:798,t:1527876656051};\\\", \\\"{x:1419,y:803,t:1527876656068};\\\", \\\"{x:1425,y:807,t:1527876656085};\\\", \\\"{x:1436,y:815,t:1527876656101};\\\", \\\"{x:1446,y:823,t:1527876656118};\\\", \\\"{x:1454,y:829,t:1527876656135};\\\", \\\"{x:1465,y:835,t:1527876656151};\\\", \\\"{x:1474,y:841,t:1527876656168};\\\", \\\"{x:1487,y:849,t:1527876656184};\\\", \\\"{x:1501,y:855,t:1527876656201};\\\", \\\"{x:1511,y:860,t:1527876656219};\\\", \\\"{x:1521,y:864,t:1527876656234};\\\", \\\"{x:1535,y:871,t:1527876656250};\\\", \\\"{x:1542,y:880,t:1527876656269};\\\", \\\"{x:1548,y:886,t:1527876656284};\\\", \\\"{x:1553,y:891,t:1527876656302};\\\", \\\"{x:1560,y:899,t:1527876656318};\\\", \\\"{x:1564,y:904,t:1527876656334};\\\", \\\"{x:1569,y:908,t:1527876656351};\\\", \\\"{x:1575,y:915,t:1527876656367};\\\", \\\"{x:1579,y:919,t:1527876656384};\\\", \\\"{x:1585,y:925,t:1527876656402};\\\", \\\"{x:1592,y:931,t:1527876656418};\\\", \\\"{x:1598,y:940,t:1527876656434};\\\", \\\"{x:1608,y:950,t:1527876656451};\\\", \\\"{x:1614,y:956,t:1527876656468};\\\", \\\"{x:1614,y:957,t:1527876656484};\\\", \\\"{x:1615,y:957,t:1527876656603};\\\", \\\"{x:1615,y:955,t:1527876656731};\\\", \\\"{x:1611,y:950,t:1527876656739};\\\", \\\"{x:1604,y:944,t:1527876656750};\\\", \\\"{x:1588,y:930,t:1527876656766};\\\", \\\"{x:1572,y:917,t:1527876656783};\\\", \\\"{x:1567,y:912,t:1527876656800};\\\", \\\"{x:1567,y:911,t:1527876656816};\\\", \\\"{x:1567,y:909,t:1527876656835};\\\", \\\"{x:1567,y:907,t:1527876656851};\\\", \\\"{x:1567,y:901,t:1527876656866};\\\", \\\"{x:1563,y:890,t:1527876656883};\\\", \\\"{x:1562,y:881,t:1527876656899};\\\", \\\"{x:1559,y:873,t:1527876656917};\\\", \\\"{x:1558,y:868,t:1527876656933};\\\", \\\"{x:1557,y:862,t:1527876656949};\\\", \\\"{x:1557,y:857,t:1527876656966};\\\", \\\"{x:1555,y:848,t:1527876656983};\\\", \\\"{x:1554,y:842,t:1527876657000};\\\", \\\"{x:1551,y:833,t:1527876657017};\\\", \\\"{x:1549,y:825,t:1527876657032};\\\", \\\"{x:1545,y:816,t:1527876657049};\\\", \\\"{x:1542,y:809,t:1527876657066};\\\", \\\"{x:1541,y:801,t:1527876657082};\\\", \\\"{x:1536,y:790,t:1527876657099};\\\", \\\"{x:1528,y:778,t:1527876657117};\\\", \\\"{x:1517,y:765,t:1527876657132};\\\", \\\"{x:1507,y:752,t:1527876657149};\\\", \\\"{x:1502,y:744,t:1527876657165};\\\", \\\"{x:1501,y:736,t:1527876657183};\\\", \\\"{x:1499,y:726,t:1527876657200};\\\", \\\"{x:1497,y:721,t:1527876657215};\\\", \\\"{x:1494,y:712,t:1527876657233};\\\", \\\"{x:1491,y:699,t:1527876657250};\\\", \\\"{x:1487,y:690,t:1527876657266};\\\", \\\"{x:1486,y:681,t:1527876657282};\\\", \\\"{x:1483,y:672,t:1527876657299};\\\", \\\"{x:1480,y:664,t:1527876657316};\\\", \\\"{x:1478,y:658,t:1527876657333};\\\", \\\"{x:1475,y:649,t:1527876657348};\\\", \\\"{x:1471,y:642,t:1527876657366};\\\", \\\"{x:1465,y:633,t:1527876657382};\\\", \\\"{x:1459,y:625,t:1527876657398};\\\", \\\"{x:1454,y:615,t:1527876657415};\\\", \\\"{x:1451,y:608,t:1527876657432};\\\", \\\"{x:1445,y:597,t:1527876657448};\\\", \\\"{x:1440,y:585,t:1527876657465};\\\", \\\"{x:1433,y:574,t:1527876657482};\\\", \\\"{x:1427,y:564,t:1527876657499};\\\", \\\"{x:1421,y:554,t:1527876657515};\\\", \\\"{x:1420,y:551,t:1527876657532};\\\", \\\"{x:1418,y:549,t:1527876657549};\\\", \\\"{x:1418,y:546,t:1527876657565};\\\", \\\"{x:1418,y:545,t:1527876657581};\\\", \\\"{x:1418,y:544,t:1527876657644};\\\", \\\"{x:1417,y:544,t:1527876657651};\\\", \\\"{x:1416,y:544,t:1527876657664};\\\", \\\"{x:1413,y:544,t:1527876657681};\\\", \\\"{x:1412,y:544,t:1527876657713};\\\", \\\"{x:1411,y:546,t:1527876657753};\\\", \\\"{x:1410,y:547,t:1527876657769};\\\", \\\"{x:1410,y:549,t:1527876657781};\\\", \\\"{x:1410,y:552,t:1527876657797};\\\", \\\"{x:1409,y:554,t:1527876657814};\\\", \\\"{x:1409,y:556,t:1527876657831};\\\", \\\"{x:1409,y:557,t:1527876657947};\\\", \\\"{x:1409,y:558,t:1527876658011};\\\", \\\"{x:1409,y:560,t:1527876658187};\\\", \\\"{x:1410,y:561,t:1527876658241};\\\", \\\"{x:1411,y:561,t:1527876658330};\\\", \\\"{x:1412,y:561,t:1527876658427};\\\", \\\"{x:1413,y:561,t:1527876658443};\\\", \\\"{x:1400,y:563,t:1527876660806};\\\", \\\"{x:1340,y:589,t:1527876660825};\\\", \\\"{x:1163,y:637,t:1527876660842};\\\", \\\"{x:1010,y:663,t:1527876660858};\\\", \\\"{x:855,y:682,t:1527876660875};\\\", \\\"{x:711,y:682,t:1527876660892};\\\", \\\"{x:597,y:684,t:1527876660909};\\\", \\\"{x:505,y:684,t:1527876660924};\\\", \\\"{x:463,y:684,t:1527876660942};\\\", \\\"{x:443,y:681,t:1527876660958};\\\", \\\"{x:422,y:679,t:1527876660975};\\\", \\\"{x:405,y:675,t:1527876660992};\\\", \\\"{x:388,y:668,t:1527876661009};\\\", \\\"{x:374,y:660,t:1527876661026};\\\", \\\"{x:371,y:657,t:1527876661042};\\\", \\\"{x:368,y:652,t:1527876661059};\\\", \\\"{x:367,y:649,t:1527876661076};\\\", \\\"{x:366,y:646,t:1527876661099};\\\", \\\"{x:366,y:643,t:1527876661114};\\\", \\\"{x:366,y:642,t:1527876661125};\\\", \\\"{x:366,y:636,t:1527876661142};\\\", \\\"{x:367,y:632,t:1527876661159};\\\", \\\"{x:368,y:626,t:1527876661175};\\\", \\\"{x:368,y:623,t:1527876661192};\\\", \\\"{x:368,y:621,t:1527876661209};\\\", \\\"{x:368,y:618,t:1527876661225};\\\", \\\"{x:375,y:615,t:1527876661243};\\\", \\\"{x:382,y:611,t:1527876661259};\\\", \\\"{x:386,y:609,t:1527876661276};\\\", \\\"{x:389,y:608,t:1527876661292};\\\", \\\"{x:391,y:605,t:1527876661309};\\\", \\\"{x:396,y:605,t:1527876661326};\\\", \\\"{x:400,y:603,t:1527876661342};\\\", \\\"{x:409,y:600,t:1527876661358};\\\", \\\"{x:419,y:597,t:1527876661376};\\\", \\\"{x:428,y:594,t:1527876661392};\\\", \\\"{x:438,y:590,t:1527876661409};\\\", \\\"{x:467,y:585,t:1527876661426};\\\", \\\"{x:515,y:579,t:1527876661443};\\\", \\\"{x:552,y:574,t:1527876661458};\\\", \\\"{x:574,y:571,t:1527876661478};\\\", \\\"{x:585,y:567,t:1527876661492};\\\", \\\"{x:588,y:566,t:1527876661509};\\\", \\\"{x:586,y:566,t:1527876661643};\\\", \\\"{x:581,y:566,t:1527876661658};\\\", \\\"{x:575,y:568,t:1527876661676};\\\", \\\"{x:575,y:571,t:1527876661693};\\\", \\\"{x:575,y:576,t:1527876661710};\\\", \\\"{x:575,y:582,t:1527876661726};\\\", \\\"{x:578,y:587,t:1527876661743};\\\", \\\"{x:581,y:592,t:1527876661759};\\\", \\\"{x:585,y:596,t:1527876661776};\\\", \\\"{x:589,y:597,t:1527876661792};\\\", \\\"{x:597,y:599,t:1527876661809};\\\", \\\"{x:604,y:600,t:1527876661826};\\\", \\\"{x:607,y:600,t:1527876661842};\\\", \\\"{x:608,y:600,t:1527876661882};\\\", \\\"{x:609,y:600,t:1527876661914};\\\", \\\"{x:610,y:600,t:1527876661938};\\\", \\\"{x:609,y:600,t:1527876662882};\\\", \\\"{x:606,y:604,t:1527876662895};\\\", \\\"{x:594,y:620,t:1527876662913};\\\", \\\"{x:584,y:635,t:1527876662929};\\\", \\\"{x:577,y:653,t:1527876662943};\\\", \\\"{x:569,y:670,t:1527876662960};\\\", \\\"{x:564,y:685,t:1527876662977};\\\", \\\"{x:558,y:698,t:1527876662994};\\\", \\\"{x:553,y:707,t:1527876663010};\\\", \\\"{x:548,y:717,t:1527876663026};\\\", \\\"{x:543,y:726,t:1527876663044};\\\", \\\"{x:539,y:733,t:1527876663060};\\\", \\\"{x:538,y:734,t:1527876663077};\\\", \\\"{x:533,y:743,t:1527876663095};\\\", \\\"{x:526,y:750,t:1527876663110};\\\", \\\"{x:523,y:755,t:1527876663127};\\\", \\\"{x:521,y:759,t:1527876663144};\\\", \\\"{x:516,y:763,t:1527876663161};\\\", \\\"{x:515,y:764,t:1527876663177};\\\", \\\"{x:513,y:766,t:1527876663195};\\\", \\\"{x:512,y:767,t:1527876663211};\\\", \\\"{x:514,y:767,t:1527876663795};\\\", \\\"{x:525,y:764,t:1527876663810};\\\", \\\"{x:538,y:763,t:1527876663828};\\\", \\\"{x:563,y:759,t:1527876663844};\\\", \\\"{x:587,y:755,t:1527876663861};\\\", \\\"{x:617,y:755,t:1527876663878};\\\", \\\"{x:673,y:755,t:1527876663894};\\\", \\\"{x:762,y:757,t:1527876663911};\\\", \\\"{x:865,y:771,t:1527876663929};\\\", \\\"{x:958,y:777,t:1527876663944};\\\", \\\"{x:1042,y:779,t:1527876663961};\\\", \\\"{x:1065,y:780,t:1527876663979};\\\", \\\"{x:1070,y:778,t:1527876663994};\\\" ] }, { \\\"rt\\\": 20729, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 9, \\\"time_elapsed\\\": 293421, \\\"internal_node_id\\\": \\\"0.0-5.0-4.0\\\", \\\"subject\\\": \\\"7BW1K\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 5, \\\"clicks\\\": 1, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"O\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-6-I -I -O -O -I -I -O -O -I \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:1024,y:756,t:1527876665188};\\\", \\\"{x:1014,y:755,t:1527876665195};\\\", \\\"{x:989,y:744,t:1527876665212};\\\", \\\"{x:967,y:732,t:1527876665229};\\\", \\\"{x:947,y:720,t:1527876665245};\\\", \\\"{x:928,y:709,t:1527876665262};\\\", \\\"{x:903,y:693,t:1527876665279};\\\", \\\"{x:882,y:682,t:1527876665295};\\\", \\\"{x:862,y:672,t:1527876665312};\\\", \\\"{x:851,y:666,t:1527876665329};\\\", \\\"{x:837,y:659,t:1527876665345};\\\", \\\"{x:823,y:654,t:1527876665362};\\\", \\\"{x:807,y:647,t:1527876665379};\\\", \\\"{x:791,y:640,t:1527876665396};\\\", \\\"{x:770,y:631,t:1527876665412};\\\", \\\"{x:743,y:619,t:1527876665430};\\\", \\\"{x:715,y:609,t:1527876665446};\\\", \\\"{x:682,y:591,t:1527876665463};\\\", \\\"{x:658,y:581,t:1527876665479};\\\", \\\"{x:637,y:569,t:1527876665496};\\\", \\\"{x:623,y:562,t:1527876665512};\\\", \\\"{x:611,y:552,t:1527876665530};\\\", \\\"{x:582,y:539,t:1527876665545};\\\", \\\"{x:568,y:530,t:1527876665562};\\\", \\\"{x:549,y:524,t:1527876665579};\\\", \\\"{x:537,y:517,t:1527876665596};\\\", \\\"{x:528,y:514,t:1527876665613};\\\", \\\"{x:519,y:510,t:1527876665629};\\\", \\\"{x:516,y:510,t:1527876665646};\\\", \\\"{x:512,y:510,t:1527876665663};\\\", \\\"{x:508,y:508,t:1527876665679};\\\", \\\"{x:503,y:507,t:1527876665696};\\\", \\\"{x:495,y:504,t:1527876665713};\\\", \\\"{x:487,y:502,t:1527876665730};\\\", \\\"{x:472,y:497,t:1527876665746};\\\", \\\"{x:458,y:493,t:1527876665764};\\\", \\\"{x:446,y:490,t:1527876665781};\\\", \\\"{x:432,y:489,t:1527876665797};\\\", \\\"{x:419,y:485,t:1527876665813};\\\", \\\"{x:402,y:484,t:1527876665831};\\\", \\\"{x:395,y:484,t:1527876665847};\\\", \\\"{x:393,y:483,t:1527876665863};\\\", \\\"{x:392,y:482,t:1527876665880};\\\", \\\"{x:391,y:482,t:1527876665897};\\\", \\\"{x:391,y:481,t:1527876665931};\\\", \\\"{x:389,y:480,t:1527876665947};\\\", \\\"{x:385,y:480,t:1527876665963};\\\", \\\"{x:384,y:479,t:1527876665981};\\\", \\\"{x:383,y:479,t:1527876665998};\\\", \\\"{x:382,y:478,t:1527876666107};\\\", \\\"{x:381,y:478,t:1527876666123};\\\", \\\"{x:379,y:478,t:1527876666147};\\\", \\\"{x:375,y:479,t:1527876666164};\\\", \\\"{x:373,y:481,t:1527876666181};\\\", \\\"{x:368,y:482,t:1527876666198};\\\", \\\"{x:368,y:483,t:1527876666214};\\\", \\\"{x:364,y:484,t:1527876666231};\\\", \\\"{x:363,y:485,t:1527876666248};\\\", \\\"{x:362,y:485,t:1527876666264};\\\", \\\"{x:360,y:486,t:1527876666282};\\\", \\\"{x:358,y:487,t:1527876666298};\\\", \\\"{x:357,y:488,t:1527876666363};\\\", \\\"{x:356,y:488,t:1527876666371};\\\", \\\"{x:355,y:488,t:1527876666459};\\\", \\\"{x:355,y:489,t:1527876666467};\\\", \\\"{x:354,y:490,t:1527876666482};\\\", \\\"{x:352,y:491,t:1527876666499};\\\", \\\"{x:351,y:491,t:1527876666515};\\\", \\\"{x:350,y:492,t:1527876666533};\\\", \\\"{x:349,y:492,t:1527876666549};\\\", \\\"{x:348,y:493,t:1527876666587};\\\", \\\"{x:347,y:494,t:1527876666600};\\\", \\\"{x:346,y:497,t:1527876666616};\\\", \\\"{x:344,y:501,t:1527876666632};\\\", \\\"{x:341,y:502,t:1527876666649};\\\", \\\"{x:341,y:505,t:1527876666665};\\\", \\\"{x:339,y:506,t:1527876666682};\\\", \\\"{x:338,y:506,t:1527876666700};\\\", \\\"{x:336,y:506,t:1527876666716};\\\", \\\"{x:334,y:508,t:1527876666733};\\\", \\\"{x:333,y:508,t:1527876666779};\\\", \\\"{x:336,y:508,t:1527876666979};\\\", \\\"{x:340,y:507,t:1527876666986};\\\", \\\"{x:342,y:507,t:1527876667000};\\\", \\\"{x:351,y:502,t:1527876667016};\\\", \\\"{x:357,y:500,t:1527876667034};\\\", \\\"{x:360,y:499,t:1527876667051};\\\", \\\"{x:361,y:498,t:1527876667068};\\\", \\\"{x:364,y:496,t:1527876667083};\\\", \\\"{x:370,y:494,t:1527876667101};\\\", \\\"{x:377,y:492,t:1527876667117};\\\", \\\"{x:380,y:491,t:1527876667133};\\\", \\\"{x:384,y:490,t:1527876667151};\\\", \\\"{x:386,y:490,t:1527876667167};\\\", \\\"{x:388,y:490,t:1527876667195};\\\", \\\"{x:389,y:490,t:1527876667202};\\\", \\\"{x:394,y:490,t:1527876667218};\\\", \\\"{x:404,y:490,t:1527876667235};\\\", \\\"{x:416,y:490,t:1527876667250};\\\", \\\"{x:430,y:491,t:1527876667267};\\\", \\\"{x:435,y:491,t:1527876667285};\\\", \\\"{x:439,y:491,t:1527876667302};\\\", \\\"{x:442,y:491,t:1527876667317};\\\", \\\"{x:445,y:491,t:1527876667335};\\\", \\\"{x:449,y:491,t:1527876667351};\\\", \\\"{x:450,y:491,t:1527876667368};\\\", \\\"{x:453,y:491,t:1527876667384};\\\", \\\"{x:458,y:491,t:1527876667401};\\\", \\\"{x:464,y:491,t:1527876667418};\\\", \\\"{x:469,y:491,t:1527876667434};\\\", \\\"{x:474,y:491,t:1527876667451};\\\", \\\"{x:479,y:491,t:1527876667469};\\\", \\\"{x:484,y:491,t:1527876667485};\\\", \\\"{x:486,y:489,t:1527876667502};\\\", \\\"{x:487,y:489,t:1527876667518};\\\", \\\"{x:488,y:489,t:1527876667595};\\\", \\\"{x:488,y:490,t:1527876667643};\\\", \\\"{x:486,y:491,t:1527876667658};\\\", \\\"{x:485,y:492,t:1527876667669};\\\", \\\"{x:481,y:493,t:1527876667685};\\\", \\\"{x:475,y:496,t:1527876667702};\\\", \\\"{x:469,y:500,t:1527876667718};\\\", \\\"{x:464,y:502,t:1527876667735};\\\", \\\"{x:457,y:505,t:1527876667752};\\\", \\\"{x:450,y:508,t:1527876667769};\\\", \\\"{x:445,y:509,t:1527876667785};\\\", \\\"{x:440,y:513,t:1527876667802};\\\", \\\"{x:432,y:516,t:1527876667818};\\\", \\\"{x:428,y:516,t:1527876667836};\\\", \\\"{x:420,y:517,t:1527876667852};\\\", \\\"{x:416,y:517,t:1527876667870};\\\", \\\"{x:413,y:517,t:1527876667886};\\\", \\\"{x:409,y:517,t:1527876667903};\\\", \\\"{x:406,y:517,t:1527876667919};\\\", \\\"{x:397,y:517,t:1527876667937};\\\", \\\"{x:382,y:517,t:1527876667952};\\\", \\\"{x:370,y:517,t:1527876667969};\\\", \\\"{x:352,y:517,t:1527876667986};\\\", \\\"{x:348,y:517,t:1527876668003};\\\", \\\"{x:347,y:517,t:1527876668020};\\\", \\\"{x:349,y:518,t:1527876668179};\\\", \\\"{x:354,y:518,t:1527876668186};\\\", \\\"{x:362,y:518,t:1527876668204};\\\", \\\"{x:373,y:520,t:1527876668221};\\\", \\\"{x:379,y:521,t:1527876668237};\\\", \\\"{x:398,y:521,t:1527876668254};\\\", \\\"{x:416,y:521,t:1527876668270};\\\", \\\"{x:439,y:521,t:1527876668288};\\\", \\\"{x:458,y:522,t:1527876668303};\\\", \\\"{x:469,y:525,t:1527876668320};\\\", \\\"{x:479,y:526,t:1527876668337};\\\", \\\"{x:487,y:526,t:1527876668353};\\\", \\\"{x:492,y:527,t:1527876668370};\\\", \\\"{x:496,y:527,t:1527876668387};\\\", \\\"{x:502,y:527,t:1527876668404};\\\", \\\"{x:510,y:527,t:1527876668420};\\\", \\\"{x:517,y:527,t:1527876668437};\\\", \\\"{x:522,y:527,t:1527876668454};\\\", \\\"{x:524,y:527,t:1527876668471};\\\", \\\"{x:526,y:527,t:1527876668487};\\\", \\\"{x:527,y:527,t:1527876668504};\\\", \\\"{x:527,y:526,t:1527876668538};\\\", \\\"{x:528,y:526,t:1527876668563};\\\", \\\"{x:529,y:526,t:1527876668579};\\\", \\\"{x:530,y:526,t:1527876668587};\\\", \\\"{x:533,y:526,t:1527876668610};\\\", \\\"{x:534,y:526,t:1527876668622};\\\", \\\"{x:536,y:526,t:1527876668667};\\\", \\\"{x:537,y:526,t:1527876668707};\\\", \\\"{x:538,y:526,t:1527876668723};\\\", \\\"{x:539,y:526,t:1527876668746};\\\", \\\"{x:540,y:526,t:1527876668763};\\\", \\\"{x:542,y:527,t:1527876668778};\\\", \\\"{x:543,y:527,t:1527876668789};\\\", \\\"{x:546,y:527,t:1527876668806};\\\", \\\"{x:551,y:527,t:1527876668822};\\\", \\\"{x:558,y:527,t:1527876668838};\\\", \\\"{x:566,y:527,t:1527876668855};\\\", \\\"{x:570,y:528,t:1527876668873};\\\", \\\"{x:573,y:529,t:1527876668888};\\\", \\\"{x:578,y:530,t:1527876668906};\\\", \\\"{x:583,y:530,t:1527876668922};\\\", \\\"{x:589,y:532,t:1527876668939};\\\", \\\"{x:593,y:533,t:1527876668956};\\\", \\\"{x:594,y:534,t:1527876668979};\\\", \\\"{x:596,y:535,t:1527876668990};\\\", \\\"{x:597,y:535,t:1527876669006};\\\", \\\"{x:599,y:535,t:1527876669023};\\\", \\\"{x:601,y:535,t:1527876669039};\\\", \\\"{x:604,y:535,t:1527876669055};\\\", \\\"{x:609,y:535,t:1527876669073};\\\", \\\"{x:610,y:536,t:1527876669089};\\\", \\\"{x:612,y:536,t:1527876669106};\\\", \\\"{x:614,y:536,t:1527876669138};\\\", \\\"{x:615,y:536,t:1527876669171};\\\", \\\"{x:617,y:536,t:1527876669179};\\\", \\\"{x:618,y:536,t:1527876669195};\\\", \\\"{x:619,y:536,t:1527876669234};\\\", \\\"{x:620,y:536,t:1527876669259};\\\", \\\"{x:621,y:536,t:1527876669274};\\\", \\\"{x:622,y:535,t:1527876669306};\\\", \\\"{x:622,y:534,t:1527876669339};\\\", \\\"{x:625,y:533,t:1527876669371};\\\", \\\"{x:627,y:533,t:1527876669387};\\\", \\\"{x:628,y:532,t:1527876669394};\\\", \\\"{x:632,y:532,t:1527876669406};\\\", \\\"{x:634,y:532,t:1527876669427};\\\", \\\"{x:634,y:533,t:1527876669491};\\\", \\\"{x:634,y:534,t:1527876669508};\\\", \\\"{x:631,y:532,t:1527876670539};\\\", \\\"{x:626,y:532,t:1527876670547};\\\", \\\"{x:623,y:532,t:1527876670561};\\\", \\\"{x:607,y:527,t:1527876670577};\\\", \\\"{x:592,y:524,t:1527876670594};\\\", \\\"{x:572,y:517,t:1527876670611};\\\", \\\"{x:555,y:513,t:1527876670628};\\\", \\\"{x:535,y:510,t:1527876670643};\\\", \\\"{x:523,y:507,t:1527876670660};\\\", \\\"{x:511,y:505,t:1527876670678};\\\", \\\"{x:500,y:503,t:1527876670693};\\\", \\\"{x:493,y:502,t:1527876670710};\\\", \\\"{x:487,y:501,t:1527876670727};\\\", \\\"{x:478,y:500,t:1527876670743};\\\", \\\"{x:465,y:496,t:1527876670760};\\\", \\\"{x:453,y:494,t:1527876670777};\\\", \\\"{x:446,y:493,t:1527876670794};\\\", \\\"{x:435,y:491,t:1527876670810};\\\", \\\"{x:421,y:491,t:1527876670827};\\\", \\\"{x:405,y:487,t:1527876670844};\\\", \\\"{x:393,y:486,t:1527876670860};\\\", \\\"{x:391,y:486,t:1527876670878};\\\", \\\"{x:386,y:486,t:1527876670895};\\\", \\\"{x:380,y:486,t:1527876670911};\\\", \\\"{x:377,y:486,t:1527876670927};\\\", \\\"{x:374,y:486,t:1527876670944};\\\", \\\"{x:371,y:486,t:1527876670961};\\\", \\\"{x:370,y:486,t:1527876670977};\\\", \\\"{x:369,y:486,t:1527876671043};\\\", \\\"{x:369,y:484,t:1527876671146};\\\", \\\"{x:371,y:484,t:1527876671161};\\\", \\\"{x:386,y:482,t:1527876671177};\\\", \\\"{x:405,y:482,t:1527876671195};\\\", \\\"{x:427,y:482,t:1527876671212};\\\", \\\"{x:442,y:482,t:1527876671228};\\\", \\\"{x:466,y:485,t:1527876671245};\\\", \\\"{x:481,y:491,t:1527876671262};\\\", \\\"{x:504,y:497,t:1527876671278};\\\", \\\"{x:514,y:498,t:1527876671296};\\\", \\\"{x:519,y:501,t:1527876671312};\\\", \\\"{x:521,y:501,t:1527876671329};\\\", \\\"{x:522,y:501,t:1527876671345};\\\", \\\"{x:524,y:501,t:1527876671362};\\\", \\\"{x:526,y:501,t:1527876671379};\\\", \\\"{x:531,y:501,t:1527876671395};\\\", \\\"{x:541,y:504,t:1527876671412};\\\", \\\"{x:554,y:506,t:1527876671429};\\\", \\\"{x:560,y:507,t:1527876671445};\\\", \\\"{x:568,y:510,t:1527876671462};\\\", \\\"{x:575,y:511,t:1527876671480};\\\", \\\"{x:576,y:512,t:1527876671764};\\\", \\\"{x:576,y:513,t:1527876671780};\\\", \\\"{x:572,y:514,t:1527876671797};\\\", \\\"{x:570,y:517,t:1527876671814};\\\", \\\"{x:564,y:523,t:1527876671831};\\\", \\\"{x:559,y:528,t:1527876671847};\\\", \\\"{x:557,y:532,t:1527876671864};\\\", \\\"{x:556,y:533,t:1527876671880};\\\", \\\"{x:555,y:534,t:1527876671898};\\\", \\\"{x:553,y:535,t:1527876671914};\\\", \\\"{x:552,y:536,t:1527876671930};\\\", \\\"{x:551,y:537,t:1527876671970};\\\", \\\"{x:549,y:538,t:1527876671995};\\\", \\\"{x:549,y:539,t:1527876672010};\\\", \\\"{x:548,y:539,t:1527876672018};\\\", \\\"{x:547,y:540,t:1527876672030};\\\", \\\"{x:546,y:541,t:1527876672050};\\\", \\\"{x:545,y:542,t:1527876672064};\\\", \\\"{x:544,y:542,t:1527876672187};\\\", \\\"{x:542,y:542,t:1527876672199};\\\", \\\"{x:539,y:543,t:1527876672215};\\\", \\\"{x:535,y:545,t:1527876672232};\\\", \\\"{x:530,y:546,t:1527876672248};\\\", \\\"{x:529,y:546,t:1527876672264};\\\", \\\"{x:528,y:546,t:1527876672282};\\\", \\\"{x:525,y:546,t:1527876672299};\\\", \\\"{x:523,y:546,t:1527876672315};\\\", \\\"{x:520,y:546,t:1527876672338};\\\", \\\"{x:519,y:545,t:1527876672348};\\\", \\\"{x:511,y:542,t:1527876672366};\\\", \\\"{x:507,y:540,t:1527876672382};\\\", \\\"{x:504,y:539,t:1527876672399};\\\", \\\"{x:502,y:537,t:1527876672416};\\\", \\\"{x:500,y:537,t:1527876672432};\\\", \\\"{x:498,y:536,t:1527876672448};\\\", \\\"{x:496,y:535,t:1527876672466};\\\", \\\"{x:495,y:533,t:1527876672483};\\\", \\\"{x:493,y:531,t:1527876672499};\\\", \\\"{x:491,y:531,t:1527876672516};\\\", \\\"{x:490,y:530,t:1527876672533};\\\", \\\"{x:489,y:529,t:1527876672549};\\\", \\\"{x:489,y:528,t:1527876672566};\\\", \\\"{x:490,y:527,t:1527876672867};\\\", \\\"{x:491,y:527,t:1527876672891};\\\", \\\"{x:492,y:527,t:1527876672900};\\\", \\\"{x:496,y:525,t:1527876672917};\\\", \\\"{x:501,y:524,t:1527876672934};\\\", \\\"{x:518,y:524,t:1527876672951};\\\", \\\"{x:546,y:524,t:1527876672966};\\\", \\\"{x:586,y:524,t:1527876672983};\\\", \\\"{x:654,y:525,t:1527876673001};\\\", \\\"{x:733,y:530,t:1527876673017};\\\", \\\"{x:799,y:539,t:1527876673034};\\\", \\\"{x:846,y:542,t:1527876673050};\\\", \\\"{x:873,y:545,t:1527876673068};\\\", \\\"{x:900,y:551,t:1527876673084};\\\", \\\"{x:918,y:554,t:1527876673101};\\\", \\\"{x:930,y:555,t:1527876673118};\\\", \\\"{x:939,y:555,t:1527876673134};\\\", \\\"{x:948,y:555,t:1527876673151};\\\", \\\"{x:959,y:555,t:1527876673167};\\\", \\\"{x:974,y:555,t:1527876673185};\\\", \\\"{x:994,y:555,t:1527876673201};\\\", \\\"{x:1021,y:562,t:1527876673217};\\\", \\\"{x:1062,y:567,t:1527876673235};\\\", \\\"{x:1087,y:571,t:1527876673253};\\\", \\\"{x:1126,y:580,t:1527876673267};\\\", \\\"{x:1161,y:585,t:1527876673285};\\\", \\\"{x:1183,y:591,t:1527876673304};\\\", \\\"{x:1211,y:595,t:1527876673333};\\\", \\\"{x:1214,y:595,t:1527876673337};\\\", \\\"{x:1216,y:595,t:1527876673351};\\\", \\\"{x:1217,y:595,t:1527876673367};\\\", \\\"{x:1218,y:595,t:1527876673385};\\\", \\\"{x:1221,y:595,t:1527876673401};\\\", \\\"{x:1226,y:595,t:1527876673417};\\\", \\\"{x:1231,y:595,t:1527876673434};\\\", \\\"{x:1234,y:595,t:1527876673451};\\\", \\\"{x:1239,y:592,t:1527876673468};\\\", \\\"{x:1243,y:586,t:1527876673484};\\\", \\\"{x:1246,y:581,t:1527876673502};\\\", \\\"{x:1249,y:574,t:1527876673519};\\\", \\\"{x:1259,y:563,t:1527876673536};\\\", \\\"{x:1266,y:551,t:1527876673552};\\\", \\\"{x:1270,y:543,t:1527876673569};\\\", \\\"{x:1272,y:537,t:1527876673586};\\\", \\\"{x:1274,y:534,t:1527876673602};\\\", \\\"{x:1274,y:533,t:1527876673618};\\\", \\\"{x:1274,y:531,t:1527876673642};\\\", \\\"{x:1274,y:527,t:1527876673659};\\\", \\\"{x:1279,y:522,t:1527876673669};\\\", \\\"{x:1287,y:515,t:1527876673685};\\\", \\\"{x:1298,y:505,t:1527876673703};\\\", \\\"{x:1309,y:497,t:1527876673722};\\\", \\\"{x:1311,y:496,t:1527876673735};\\\", \\\"{x:1315,y:493,t:1527876673753};\\\", \\\"{x:1319,y:492,t:1527876673770};\\\", \\\"{x:1323,y:490,t:1527876673785};\\\", \\\"{x:1328,y:489,t:1527876673802};\\\", \\\"{x:1331,y:488,t:1527876673819};\\\", \\\"{x:1334,y:486,t:1527876673836};\\\", \\\"{x:1337,y:485,t:1527876673852};\\\", \\\"{x:1333,y:485,t:1527876673953};\\\", \\\"{x:1331,y:486,t:1527876673969};\\\", \\\"{x:1327,y:486,t:1527876673985};\\\", \\\"{x:1322,y:487,t:1527876674002};\\\", \\\"{x:1320,y:488,t:1527876674018};\\\", \\\"{x:1318,y:489,t:1527876674035};\\\", \\\"{x:1317,y:490,t:1527876674074};\\\", \\\"{x:1315,y:490,t:1527876674122};\\\", \\\"{x:1313,y:491,t:1527876674240};\\\", \\\"{x:1312,y:492,t:1527876674252};\\\", \\\"{x:1311,y:492,t:1527876674269};\\\", \\\"{x:1311,y:493,t:1527876674286};\\\", \\\"{x:1311,y:494,t:1527876674834};\\\", \\\"{x:1311,y:496,t:1527876674843};\\\", \\\"{x:1311,y:500,t:1527876674856};\\\", \\\"{x:1314,y:509,t:1527876674875};\\\", \\\"{x:1315,y:520,t:1527876674890};\\\", \\\"{x:1316,y:532,t:1527876674904};\\\", \\\"{x:1317,y:541,t:1527876674919};\\\", \\\"{x:1319,y:547,t:1527876674937};\\\", \\\"{x:1319,y:553,t:1527876674954};\\\", \\\"{x:1319,y:561,t:1527876674970};\\\", \\\"{x:1319,y:573,t:1527876674987};\\\", \\\"{x:1320,y:579,t:1527876675004};\\\", \\\"{x:1320,y:582,t:1527876675020};\\\", \\\"{x:1320,y:584,t:1527876675037};\\\", \\\"{x:1320,y:585,t:1527876675054};\\\", \\\"{x:1320,y:588,t:1527876675071};\\\", \\\"{x:1320,y:594,t:1527876675087};\\\", \\\"{x:1320,y:598,t:1527876675104};\\\", \\\"{x:1319,y:603,t:1527876675121};\\\", \\\"{x:1317,y:609,t:1527876675137};\\\", \\\"{x:1316,y:614,t:1527876675154};\\\", \\\"{x:1315,y:618,t:1527876675171};\\\", \\\"{x:1314,y:621,t:1527876675187};\\\", \\\"{x:1314,y:622,t:1527876675204};\\\", \\\"{x:1314,y:625,t:1527876675225};\\\", \\\"{x:1314,y:627,t:1527876675273};\\\", \\\"{x:1314,y:628,t:1527876675286};\\\", \\\"{x:1314,y:629,t:1527876675304};\\\", \\\"{x:1307,y:633,t:1527876677045};\\\", \\\"{x:1288,y:633,t:1527876677055};\\\", \\\"{x:1250,y:634,t:1527876677071};\\\", \\\"{x:1169,y:634,t:1527876677088};\\\", \\\"{x:1050,y:634,t:1527876677106};\\\", \\\"{x:983,y:627,t:1527876677121};\\\", \\\"{x:946,y:622,t:1527876677139};\\\", \\\"{x:921,y:616,t:1527876677155};\\\", \\\"{x:904,y:612,t:1527876677171};\\\", \\\"{x:870,y:608,t:1527876677188};\\\", \\\"{x:839,y:605,t:1527876677206};\\\", \\\"{x:811,y:603,t:1527876677221};\\\", \\\"{x:792,y:603,t:1527876677239};\\\", \\\"{x:778,y:600,t:1527876677256};\\\", \\\"{x:773,y:599,t:1527876677272};\\\", \\\"{x:770,y:598,t:1527876677288};\\\", \\\"{x:761,y:598,t:1527876677306};\\\", \\\"{x:756,y:598,t:1527876677322};\\\", \\\"{x:714,y:598,t:1527876677339};\\\", \\\"{x:672,y:598,t:1527876677355};\\\", \\\"{x:635,y:598,t:1527876677372};\\\", \\\"{x:613,y:598,t:1527876677388};\\\", \\\"{x:587,y:600,t:1527876677406};\\\", \\\"{x:554,y:600,t:1527876677422};\\\", \\\"{x:531,y:599,t:1527876677438};\\\", \\\"{x:511,y:598,t:1527876677455};\\\", \\\"{x:492,y:595,t:1527876677474};\\\", \\\"{x:477,y:594,t:1527876677489};\\\", \\\"{x:461,y:591,t:1527876677506};\\\", \\\"{x:449,y:590,t:1527876677522};\\\", \\\"{x:439,y:589,t:1527876677539};\\\", \\\"{x:422,y:589,t:1527876677555};\\\", \\\"{x:412,y:589,t:1527876677572};\\\", \\\"{x:384,y:589,t:1527876677588};\\\", \\\"{x:364,y:588,t:1527876677605};\\\", \\\"{x:346,y:588,t:1527876677622};\\\", \\\"{x:334,y:588,t:1527876677639};\\\", \\\"{x:328,y:588,t:1527876677656};\\\", \\\"{x:324,y:588,t:1527876677673};\\\", \\\"{x:333,y:585,t:1527876677741};\\\", \\\"{x:355,y:581,t:1527876677755};\\\", \\\"{x:377,y:581,t:1527876677773};\\\", \\\"{x:419,y:584,t:1527876677790};\\\", \\\"{x:503,y:589,t:1527876677807};\\\", \\\"{x:583,y:597,t:1527876677823};\\\", \\\"{x:639,y:606,t:1527876677838};\\\", \\\"{x:690,y:608,t:1527876677856};\\\", \\\"{x:716,y:608,t:1527876677872};\\\", \\\"{x:730,y:608,t:1527876677890};\\\", \\\"{x:732,y:608,t:1527876677905};\\\", \\\"{x:734,y:607,t:1527876677922};\\\", \\\"{x:735,y:607,t:1527876677954};\\\", \\\"{x:736,y:607,t:1527876677961};\\\", \\\"{x:739,y:605,t:1527876677972};\\\", \\\"{x:746,y:603,t:1527876677989};\\\", \\\"{x:761,y:602,t:1527876678005};\\\", \\\"{x:773,y:601,t:1527876678022};\\\", \\\"{x:782,y:599,t:1527876678040};\\\", \\\"{x:784,y:597,t:1527876678055};\\\", \\\"{x:785,y:597,t:1527876678072};\\\", \\\"{x:789,y:594,t:1527876678089};\\\", \\\"{x:792,y:593,t:1527876678107};\\\", \\\"{x:792,y:591,t:1527876678123};\\\", \\\"{x:794,y:589,t:1527876678139};\\\", \\\"{x:797,y:584,t:1527876678155};\\\", \\\"{x:799,y:581,t:1527876678173};\\\", \\\"{x:802,y:577,t:1527876678189};\\\", \\\"{x:805,y:573,t:1527876678205};\\\", \\\"{x:809,y:568,t:1527876678222};\\\", \\\"{x:812,y:566,t:1527876678239};\\\", \\\"{x:815,y:565,t:1527876678255};\\\", \\\"{x:816,y:565,t:1527876678272};\\\", \\\"{x:818,y:565,t:1527876678322};\\\", \\\"{x:823,y:565,t:1527876678340};\\\", \\\"{x:826,y:567,t:1527876678356};\\\", \\\"{x:828,y:568,t:1527876678373};\\\", \\\"{x:835,y:570,t:1527876678835};\\\", \\\"{x:843,y:571,t:1527876678842};\\\", \\\"{x:857,y:574,t:1527876678857};\\\", \\\"{x:913,y:577,t:1527876678875};\\\", \\\"{x:1038,y:588,t:1527876678892};\\\", \\\"{x:1124,y:588,t:1527876678907};\\\", \\\"{x:1242,y:581,t:1527876678925};\\\", \\\"{x:1359,y:556,t:1527876678940};\\\", \\\"{x:1397,y:542,t:1527876678957};\\\", \\\"{x:1429,y:531,t:1527876678975};\\\", \\\"{x:1445,y:525,t:1527876678990};\\\", \\\"{x:1449,y:521,t:1527876679008};\\\", \\\"{x:1451,y:520,t:1527876679024};\\\", \\\"{x:1453,y:518,t:1527876679040};\\\", \\\"{x:1457,y:517,t:1527876679057};\\\", \\\"{x:1467,y:512,t:1527876679075};\\\", \\\"{x:1469,y:511,t:1527876679090};\\\", \\\"{x:1470,y:510,t:1527876679107};\\\", \\\"{x:1469,y:510,t:1527876679139};\\\", \\\"{x:1466,y:510,t:1527876679146};\\\", \\\"{x:1457,y:508,t:1527876679157};\\\", \\\"{x:1444,y:505,t:1527876679174};\\\", \\\"{x:1439,y:505,t:1527876679191};\\\", \\\"{x:1437,y:505,t:1527876679207};\\\", \\\"{x:1435,y:505,t:1527876679224};\\\", \\\"{x:1427,y:504,t:1527876679242};\\\", \\\"{x:1404,y:496,t:1527876679258};\\\", \\\"{x:1360,y:486,t:1527876679274};\\\", \\\"{x:1333,y:480,t:1527876679290};\\\", \\\"{x:1311,y:477,t:1527876679307};\\\", \\\"{x:1297,y:475,t:1527876679324};\\\", \\\"{x:1290,y:473,t:1527876679341};\\\", \\\"{x:1289,y:473,t:1527876679357};\\\", \\\"{x:1288,y:473,t:1527876679374};\\\", \\\"{x:1287,y:473,t:1527876679391};\\\", \\\"{x:1287,y:474,t:1527876679407};\\\", \\\"{x:1289,y:475,t:1527876679459};\\\", \\\"{x:1304,y:481,t:1527876679474};\\\", \\\"{x:1311,y:487,t:1527876679491};\\\", \\\"{x:1322,y:492,t:1527876679509};\\\", \\\"{x:1328,y:496,t:1527876679524};\\\", \\\"{x:1331,y:497,t:1527876679541};\\\", \\\"{x:1331,y:499,t:1527876679577};\\\", \\\"{x:1330,y:499,t:1527876679690};\\\", \\\"{x:1328,y:499,t:1527876679709};\\\", \\\"{x:1326,y:499,t:1527876679724};\\\", \\\"{x:1323,y:499,t:1527876679741};\\\", \\\"{x:1322,y:499,t:1527876679758};\\\", \\\"{x:1320,y:499,t:1527876679774};\\\", \\\"{x:1318,y:498,t:1527876679794};\\\", \\\"{x:1317,y:498,t:1527876679807};\\\", \\\"{x:1316,y:498,t:1527876680170};\\\", \\\"{x:1316,y:501,t:1527876680202};\\\", \\\"{x:1314,y:507,t:1527876680213};\\\", \\\"{x:1314,y:513,t:1527876680225};\\\", \\\"{x:1315,y:528,t:1527876680240};\\\", \\\"{x:1318,y:547,t:1527876680257};\\\", \\\"{x:1319,y:557,t:1527876680274};\\\", \\\"{x:1320,y:562,t:1527876680290};\\\", \\\"{x:1321,y:568,t:1527876680308};\\\", \\\"{x:1322,y:574,t:1527876680324};\\\", \\\"{x:1323,y:576,t:1527876680341};\\\", \\\"{x:1324,y:579,t:1527876680357};\\\", \\\"{x:1326,y:582,t:1527876680374};\\\", \\\"{x:1326,y:584,t:1527876680391};\\\", \\\"{x:1326,y:586,t:1527876680408};\\\", \\\"{x:1326,y:589,t:1527876680424};\\\", \\\"{x:1326,y:593,t:1527876680441};\\\", \\\"{x:1326,y:603,t:1527876680458};\\\", \\\"{x:1325,y:608,t:1527876680475};\\\", \\\"{x:1325,y:610,t:1527876680491};\\\", \\\"{x:1325,y:614,t:1527876680508};\\\", \\\"{x:1324,y:616,t:1527876680525};\\\", \\\"{x:1324,y:617,t:1527876680541};\\\", \\\"{x:1324,y:618,t:1527876680557};\\\", \\\"{x:1324,y:620,t:1527876680575};\\\", \\\"{x:1323,y:621,t:1527876680591};\\\", \\\"{x:1322,y:624,t:1527876680608};\\\", \\\"{x:1322,y:625,t:1527876680625};\\\", \\\"{x:1322,y:629,t:1527876680642};\\\", \\\"{x:1321,y:632,t:1527876680659};\\\", \\\"{x:1320,y:632,t:1527876680915};\\\", \\\"{x:1318,y:632,t:1527876680943};\\\", \\\"{x:1316,y:632,t:1527876680958};\\\", \\\"{x:1315,y:632,t:1527876680974};\\\", \\\"{x:1313,y:632,t:1527876680992};\\\", \\\"{x:1312,y:632,t:1527876681082};\\\", \\\"{x:1311,y:633,t:1527876681091};\\\", \\\"{x:1310,y:633,t:1527876683026};\\\", \\\"{x:1310,y:630,t:1527876683050};\\\", \\\"{x:1310,y:621,t:1527876683062};\\\", \\\"{x:1309,y:610,t:1527876683077};\\\", \\\"{x:1308,y:595,t:1527876683093};\\\", \\\"{x:1307,y:583,t:1527876683110};\\\", \\\"{x:1305,y:576,t:1527876683127};\\\", \\\"{x:1305,y:573,t:1527876683142};\\\", \\\"{x:1305,y:570,t:1527876683159};\\\", \\\"{x:1305,y:566,t:1527876683176};\\\", \\\"{x:1305,y:562,t:1527876683193};\\\", \\\"{x:1305,y:557,t:1527876683210};\\\", \\\"{x:1305,y:553,t:1527876683227};\\\", \\\"{x:1306,y:548,t:1527876683243};\\\", \\\"{x:1307,y:544,t:1527876683260};\\\", \\\"{x:1308,y:538,t:1527876683276};\\\", \\\"{x:1315,y:521,t:1527876683293};\\\", \\\"{x:1316,y:509,t:1527876683310};\\\", \\\"{x:1316,y:498,t:1527876683328};\\\", \\\"{x:1316,y:493,t:1527876683343};\\\", \\\"{x:1316,y:492,t:1527876684306};\\\", \\\"{x:1311,y:499,t:1527876684322};\\\", \\\"{x:1303,y:515,t:1527876684343};\\\", \\\"{x:1269,y:538,t:1527876684360};\\\", \\\"{x:1185,y:573,t:1527876684377};\\\", \\\"{x:1106,y:601,t:1527876684395};\\\", \\\"{x:1017,y:616,t:1527876684410};\\\", \\\"{x:905,y:637,t:1527876684428};\\\", \\\"{x:801,y:644,t:1527876684444};\\\", \\\"{x:628,y:658,t:1527876684461};\\\", \\\"{x:461,y:672,t:1527876684478};\\\", \\\"{x:414,y:679,t:1527876684495};\\\", \\\"{x:410,y:680,t:1527876684510};\\\", \\\"{x:411,y:681,t:1527876684618};\\\", \\\"{x:415,y:684,t:1527876684628};\\\", \\\"{x:421,y:692,t:1527876684645};\\\", \\\"{x:429,y:700,t:1527876684661};\\\", \\\"{x:433,y:704,t:1527876684679};\\\", \\\"{x:435,y:708,t:1527876684695};\\\", \\\"{x:435,y:709,t:1527876684712};\\\", \\\"{x:437,y:710,t:1527876684728};\\\", \\\"{x:438,y:711,t:1527876684745};\\\", \\\"{x:441,y:714,t:1527876684762};\\\", \\\"{x:446,y:715,t:1527876684778};\\\", \\\"{x:449,y:718,t:1527876684796};\\\", \\\"{x:451,y:720,t:1527876684812};\\\", \\\"{x:455,y:722,t:1527876684829};\\\", \\\"{x:459,y:726,t:1527876684845};\\\", \\\"{x:459,y:728,t:1527876684862};\\\", \\\"{x:461,y:730,t:1527876684879};\\\", \\\"{x:463,y:733,t:1527876684896};\\\", \\\"{x:466,y:734,t:1527876684912};\\\", \\\"{x:468,y:735,t:1527876684930};\\\", \\\"{x:469,y:737,t:1527876684946};\\\", \\\"{x:470,y:741,t:1527876684962};\\\", \\\"{x:470,y:743,t:1527876684979};\\\", \\\"{x:471,y:745,t:1527876684996};\\\", \\\"{x:472,y:746,t:1527876685018};\\\", \\\"{x:472,y:747,t:1527876685030};\\\", \\\"{x:473,y:747,t:1527876685046};\\\", \\\"{x:473,y:749,t:1527876685063};\\\", \\\"{x:474,y:750,t:1527876685082};\\\", \\\"{x:475,y:751,t:1527876685098};\\\", \\\"{x:475,y:753,t:1527876685113};\\\", \\\"{x:476,y:753,t:1527876685128};\\\", \\\"{x:476,y:755,t:1527876685145};\\\", \\\"{x:478,y:757,t:1527876685162};\\\", \\\"{x:479,y:758,t:1527876685178};\\\", \\\"{x:481,y:760,t:1527876685194};\\\", \\\"{x:482,y:761,t:1527876685211};\\\", \\\"{x:484,y:763,t:1527876685228};\\\", \\\"{x:486,y:765,t:1527876685245};\\\", \\\"{x:487,y:767,t:1527876685261};\\\", \\\"{x:490,y:770,t:1527876685278};\\\", \\\"{x:490,y:771,t:1527876685295};\\\", \\\"{x:493,y:774,t:1527876685311};\\\", \\\"{x:494,y:775,t:1527876685328};\\\", \\\"{x:495,y:775,t:1527876685842};\\\", \\\"{x:499,y:772,t:1527876685850};\\\", \\\"{x:500,y:768,t:1527876685862};\\\", \\\"{x:506,y:764,t:1527876685879};\\\", \\\"{x:508,y:758,t:1527876685896};\\\", \\\"{x:513,y:754,t:1527876685911};\\\", \\\"{x:513,y:752,t:1527876685929};\\\", \\\"{x:515,y:746,t:1527876685946};\\\", \\\"{x:515,y:744,t:1527876685962};\\\", \\\"{x:515,y:742,t:1527876685979};\\\" ] }, { \\\"rt\\\": 10138, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 10, \\\"time_elapsed\\\": 304856, \\\"internal_node_id\\\": \\\"0.0-6.0-0.0\\\", \\\"subject\\\": \\\"7BW1K\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration\\\", \\\"q\\\": 6, \\\"clicks\\\": 2, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\", \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-P -P -P -E -E -6\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:516,y:742,t:1527876687074};\\\", \\\"{x:520,y:742,t:1527876687082};\\\", \\\"{x:521,y:742,t:1527876687097};\\\", \\\"{x:527,y:737,t:1527876687206};\\\", \\\"{x:528,y:737,t:1527876687214};\\\", \\\"{x:528,y:736,t:1527876687229};\\\", \\\"{x:531,y:724,t:1527876687246};\\\", \\\"{x:533,y:714,t:1527876687264};\\\", \\\"{x:533,y:710,t:1527876687281};\\\", \\\"{x:533,y:704,t:1527876687297};\\\", \\\"{x:528,y:696,t:1527876687312};\\\", \\\"{x:523,y:688,t:1527876687330};\\\", \\\"{x:520,y:684,t:1527876687346};\\\", \\\"{x:519,y:682,t:1527876687364};\\\", \\\"{x:518,y:682,t:1527876687379};\\\", \\\"{x:515,y:676,t:1527876687397};\\\", \\\"{x:503,y:657,t:1527876687413};\\\", \\\"{x:474,y:628,t:1527876687430};\\\", \\\"{x:447,y:608,t:1527876687446};\\\", \\\"{x:428,y:597,t:1527876687464};\\\", \\\"{x:410,y:582,t:1527876687481};\\\", \\\"{x:403,y:579,t:1527876687497};\\\", \\\"{x:395,y:574,t:1527876687513};\\\", \\\"{x:387,y:564,t:1527876687530};\\\", \\\"{x:380,y:557,t:1527876687548};\\\", \\\"{x:376,y:550,t:1527876687565};\\\", \\\"{x:373,y:546,t:1527876687579};\\\", \\\"{x:371,y:543,t:1527876687597};\\\", \\\"{x:369,y:542,t:1527876687613};\\\", \\\"{x:369,y:540,t:1527876687630};\\\", \\\"{x:367,y:540,t:1527876687647};\\\", \\\"{x:364,y:540,t:1527876687663};\\\", \\\"{x:356,y:539,t:1527876687680};\\\", \\\"{x:350,y:538,t:1527876687697};\\\", \\\"{x:341,y:536,t:1527876687713};\\\", \\\"{x:328,y:532,t:1527876687730};\\\", \\\"{x:316,y:529,t:1527876687747};\\\", \\\"{x:304,y:524,t:1527876687765};\\\", \\\"{x:294,y:520,t:1527876687780};\\\", \\\"{x:274,y:515,t:1527876687798};\\\", \\\"{x:253,y:506,t:1527876687815};\\\", \\\"{x:233,y:497,t:1527876687829};\\\", \\\"{x:220,y:492,t:1527876687847};\\\", \\\"{x:214,y:489,t:1527876687864};\\\", \\\"{x:210,y:486,t:1527876687881};\\\", \\\"{x:208,y:486,t:1527876687906};\\\", \\\"{x:209,y:485,t:1527876688035};\\\", \\\"{x:211,y:484,t:1527876688050};\\\", \\\"{x:214,y:484,t:1527876688065};\\\", \\\"{x:216,y:482,t:1527876688081};\\\", \\\"{x:218,y:481,t:1527876688097};\\\", \\\"{x:219,y:481,t:1527876688114};\\\", \\\"{x:221,y:481,t:1527876688131};\\\", \\\"{x:223,y:480,t:1527876688154};\\\", \\\"{x:224,y:479,t:1527876688178};\\\", \\\"{x:225,y:479,t:1527876688186};\\\", \\\"{x:227,y:479,t:1527876688210};\\\", \\\"{x:227,y:478,t:1527876688226};\\\", \\\"{x:228,y:478,t:1527876688234};\\\", \\\"{x:230,y:478,t:1527876688247};\\\", \\\"{x:241,y:479,t:1527876688265};\\\", \\\"{x:255,y:482,t:1527876688281};\\\", \\\"{x:266,y:487,t:1527876688298};\\\", \\\"{x:299,y:495,t:1527876688316};\\\", \\\"{x:319,y:500,t:1527876688331};\\\", \\\"{x:331,y:501,t:1527876688347};\\\", \\\"{x:340,y:502,t:1527876688364};\\\", \\\"{x:350,y:502,t:1527876688381};\\\", \\\"{x:355,y:502,t:1527876688398};\\\", \\\"{x:360,y:502,t:1527876688414};\\\", \\\"{x:363,y:502,t:1527876688430};\\\", \\\"{x:365,y:501,t:1527876688448};\\\", \\\"{x:367,y:501,t:1527876688464};\\\", \\\"{x:368,y:500,t:1527876688482};\\\", \\\"{x:370,y:500,t:1527876688498};\\\", \\\"{x:371,y:500,t:1527876688530};\\\", \\\"{x:374,y:499,t:1527876688538};\\\", \\\"{x:376,y:498,t:1527876688549};\\\", \\\"{x:383,y:498,t:1527876688564};\\\", \\\"{x:385,y:497,t:1527876688581};\\\", \\\"{x:388,y:497,t:1527876688598};\\\", \\\"{x:390,y:497,t:1527876688615};\\\", \\\"{x:391,y:497,t:1527876688631};\\\", \\\"{x:392,y:497,t:1527876688648};\\\", \\\"{x:393,y:497,t:1527876688778};\\\", \\\"{x:394,y:497,t:1527876688963};\\\", \\\"{x:399,y:497,t:1527876688970};\\\", \\\"{x:404,y:497,t:1527876688982};\\\", \\\"{x:440,y:495,t:1527876689000};\\\", \\\"{x:500,y:488,t:1527876689017};\\\", \\\"{x:614,y:486,t:1527876689033};\\\", \\\"{x:754,y:476,t:1527876689046};\\\", \\\"{x:893,y:471,t:1527876689062};\\\", \\\"{x:1033,y:459,t:1527876689080};\\\", \\\"{x:1183,y:437,t:1527876689097};\\\", \\\"{x:1305,y:414,t:1527876689112};\\\", \\\"{x:1462,y:406,t:1527876689130};\\\", \\\"{x:1549,y:404,t:1527876689147};\\\", \\\"{x:1624,y:402,t:1527876689163};\\\", \\\"{x:1666,y:398,t:1527876689180};\\\", \\\"{x:1690,y:396,t:1527876689197};\\\", \\\"{x:1716,y:392,t:1527876689213};\\\", \\\"{x:1730,y:391,t:1527876689230};\\\", \\\"{x:1735,y:389,t:1527876689247};\\\", \\\"{x:1738,y:388,t:1527876689263};\\\", \\\"{x:1739,y:386,t:1527876689339};\\\", \\\"{x:1738,y:385,t:1527876689347};\\\", \\\"{x:1719,y:381,t:1527876689363};\\\", \\\"{x:1703,y:381,t:1527876689380};\\\", \\\"{x:1688,y:380,t:1527876689396};\\\", \\\"{x:1672,y:378,t:1527876689413};\\\", \\\"{x:1658,y:375,t:1527876689430};\\\", \\\"{x:1640,y:372,t:1527876689446};\\\", \\\"{x:1619,y:369,t:1527876689463};\\\", \\\"{x:1592,y:362,t:1527876689480};\\\", \\\"{x:1557,y:351,t:1527876689496};\\\", \\\"{x:1538,y:345,t:1527876689513};\\\", \\\"{x:1522,y:343,t:1527876689529};\\\", \\\"{x:1519,y:341,t:1527876689546};\\\", \\\"{x:1516,y:341,t:1527876689610};\\\", \\\"{x:1514,y:341,t:1527876689618};\\\", \\\"{x:1512,y:342,t:1527876689642};\\\", \\\"{x:1512,y:343,t:1527876689707};\\\", \\\"{x:1515,y:344,t:1527876689714};\\\", \\\"{x:1515,y:345,t:1527876689730};\\\", \\\"{x:1527,y:345,t:1527876689746};\\\", \\\"{x:1532,y:344,t:1527876689764};\\\", \\\"{x:1538,y:342,t:1527876689779};\\\", \\\"{x:1542,y:340,t:1527876689796};\\\", \\\"{x:1547,y:340,t:1527876689813};\\\", \\\"{x:1549,y:340,t:1527876689829};\\\", \\\"{x:1553,y:340,t:1527876689845};\\\", \\\"{x:1554,y:340,t:1527876689863};\\\", \\\"{x:1555,y:340,t:1527876689881};\\\", \\\"{x:1556,y:340,t:1527876689921};\\\", \\\"{x:1557,y:341,t:1527876689930};\\\", \\\"{x:1562,y:346,t:1527876689946};\\\", \\\"{x:1567,y:352,t:1527876689963};\\\", \\\"{x:1569,y:354,t:1527876689979};\\\", \\\"{x:1571,y:357,t:1527876689996};\\\", \\\"{x:1573,y:358,t:1527876690014};\\\", \\\"{x:1575,y:360,t:1527876690029};\\\", \\\"{x:1576,y:360,t:1527876690048};\\\", \\\"{x:1577,y:360,t:1527876690154};\\\", \\\"{x:1578,y:360,t:1527876690177};\\\", \\\"{x:1579,y:360,t:1527876690185};\\\", \\\"{x:1580,y:360,t:1527876690242};\\\", \\\"{x:1581,y:360,t:1527876690250};\\\", \\\"{x:1582,y:360,t:1527876690262};\\\", \\\"{x:1584,y:360,t:1527876690279};\\\", \\\"{x:1585,y:360,t:1527876690314};\\\", \\\"{x:1587,y:360,t:1527876690347};\\\", \\\"{x:1588,y:360,t:1527876690371};\\\", \\\"{x:1590,y:360,t:1527876690386};\\\", \\\"{x:1591,y:358,t:1527876690402};\\\", \\\"{x:1592,y:358,t:1527876690426};\\\", \\\"{x:1593,y:357,t:1527876690523};\\\", \\\"{x:1594,y:357,t:1527876690563};\\\", \\\"{x:1595,y:357,t:1527876690602};\\\", \\\"{x:1594,y:357,t:1527876690971};\\\", \\\"{x:1594,y:358,t:1527876690979};\\\", \\\"{x:1592,y:359,t:1527876690995};\\\", \\\"{x:1591,y:359,t:1527876691012};\\\", \\\"{x:1590,y:360,t:1527876691051};\\\", \\\"{x:1589,y:361,t:1527876691082};\\\", \\\"{x:1588,y:362,t:1527876691106};\\\", \\\"{x:1588,y:363,t:1527876691122};\\\", \\\"{x:1587,y:363,t:1527876691131};\\\", \\\"{x:1587,y:364,t:1527876691145};\\\", \\\"{x:1586,y:364,t:1527876691161};\\\", \\\"{x:1585,y:366,t:1527876691178};\\\", \\\"{x:1584,y:368,t:1527876691195};\\\", \\\"{x:1583,y:373,t:1527876691211};\\\", \\\"{x:1582,y:376,t:1527876691228};\\\", \\\"{x:1579,y:383,t:1527876691245};\\\", \\\"{x:1578,y:386,t:1527876691264};\\\", \\\"{x:1577,y:390,t:1527876691281};\\\", \\\"{x:1575,y:395,t:1527876691299};\\\", \\\"{x:1573,y:403,t:1527876691315};\\\", \\\"{x:1569,y:408,t:1527876691331};\\\", \\\"{x:1567,y:414,t:1527876691349};\\\", \\\"{x:1564,y:422,t:1527876691364};\\\", \\\"{x:1563,y:430,t:1527876691381};\\\", \\\"{x:1560,y:434,t:1527876691399};\\\", \\\"{x:1558,y:439,t:1527876691414};\\\", \\\"{x:1557,y:441,t:1527876691432};\\\", \\\"{x:1556,y:443,t:1527876691448};\\\", \\\"{x:1553,y:448,t:1527876691465};\\\", \\\"{x:1550,y:452,t:1527876691482};\\\", \\\"{x:1549,y:457,t:1527876691498};\\\", \\\"{x:1545,y:462,t:1527876691515};\\\", \\\"{x:1542,y:467,t:1527876691532};\\\", \\\"{x:1538,y:471,t:1527876691548};\\\", \\\"{x:1530,y:479,t:1527876691565};\\\", \\\"{x:1518,y:490,t:1527876691581};\\\", \\\"{x:1505,y:499,t:1527876691599};\\\", \\\"{x:1496,y:506,t:1527876691615};\\\", \\\"{x:1482,y:515,t:1527876691632};\\\", \\\"{x:1469,y:521,t:1527876691648};\\\", \\\"{x:1454,y:525,t:1527876691665};\\\", \\\"{x:1439,y:530,t:1527876691682};\\\", \\\"{x:1426,y:532,t:1527876691698};\\\", \\\"{x:1418,y:534,t:1527876691715};\\\", \\\"{x:1403,y:538,t:1527876691732};\\\", \\\"{x:1393,y:540,t:1527876691748};\\\", \\\"{x:1379,y:544,t:1527876691766};\\\", \\\"{x:1375,y:545,t:1527876691781};\\\", \\\"{x:1367,y:548,t:1527876691798};\\\", \\\"{x:1360,y:550,t:1527876691815};\\\", \\\"{x:1353,y:552,t:1527876691831};\\\", \\\"{x:1333,y:558,t:1527876691848};\\\", \\\"{x:1318,y:558,t:1527876691866};\\\", \\\"{x:1308,y:558,t:1527876691881};\\\", \\\"{x:1305,y:558,t:1527876691898};\\\", \\\"{x:1303,y:558,t:1527876691918};\\\", \\\"{x:1302,y:559,t:1527876691932};\\\", \\\"{x:1300,y:560,t:1527876691948};\\\", \\\"{x:1293,y:560,t:1527876691965};\\\", \\\"{x:1284,y:561,t:1527876691982};\\\", \\\"{x:1260,y:561,t:1527876691999};\\\", \\\"{x:1254,y:561,t:1527876692015};\\\", \\\"{x:1248,y:561,t:1527876692031};\\\", \\\"{x:1247,y:563,t:1527876692222};\\\", \\\"{x:1248,y:563,t:1527876692231};\\\", \\\"{x:1260,y:565,t:1527876692248};\\\", \\\"{x:1274,y:567,t:1527876692265};\\\", \\\"{x:1280,y:568,t:1527876692282};\\\", \\\"{x:1281,y:568,t:1527876692314};\\\", \\\"{x:1277,y:568,t:1527876692527};\\\", \\\"{x:1265,y:568,t:1527876692534};\\\", \\\"{x:1239,y:565,t:1527876692548};\\\", \\\"{x:1207,y:563,t:1527876692563};\\\", \\\"{x:1156,y:560,t:1527876692581};\\\", \\\"{x:1120,y:551,t:1527876692596};\\\", \\\"{x:1093,y:547,t:1527876692613};\\\", \\\"{x:1089,y:547,t:1527876692630};\\\", \\\"{x:1082,y:550,t:1527876692646};\\\", \\\"{x:1077,y:553,t:1527876692663};\\\", \\\"{x:1071,y:559,t:1527876692680};\\\", \\\"{x:1059,y:565,t:1527876692697};\\\", \\\"{x:1037,y:568,t:1527876692714};\\\", \\\"{x:1017,y:568,t:1527876692731};\\\", \\\"{x:1009,y:568,t:1527876692747};\\\", \\\"{x:996,y:568,t:1527876692764};\\\", \\\"{x:972,y:566,t:1527876692780};\\\", \\\"{x:947,y:560,t:1527876692797};\\\", \\\"{x:849,y:551,t:1527876692814};\\\", \\\"{x:783,y:535,t:1527876692831};\\\", \\\"{x:725,y:529,t:1527876692846};\\\", \\\"{x:698,y:519,t:1527876692865};\\\", \\\"{x:689,y:517,t:1527876692881};\\\", \\\"{x:686,y:516,t:1527876692898};\\\", \\\"{x:685,y:516,t:1527876692957};\\\", \\\"{x:684,y:516,t:1527876692971};\\\", \\\"{x:679,y:516,t:1527876692987};\\\", \\\"{x:676,y:515,t:1527876693005};\\\", \\\"{x:674,y:515,t:1527876693021};\\\", \\\"{x:673,y:515,t:1527876693038};\\\", \\\"{x:671,y:515,t:1527876693054};\\\", \\\"{x:666,y:515,t:1527876693072};\\\", \\\"{x:659,y:514,t:1527876693087};\\\", \\\"{x:652,y:512,t:1527876693105};\\\", \\\"{x:647,y:510,t:1527876693122};\\\", \\\"{x:644,y:510,t:1527876693174};\\\", \\\"{x:641,y:508,t:1527876693190};\\\", \\\"{x:632,y:507,t:1527876693205};\\\", \\\"{x:624,y:506,t:1527876693221};\\\", \\\"{x:622,y:506,t:1527876693239};\\\", \\\"{x:618,y:506,t:1527876693573};\\\", \\\"{x:609,y:506,t:1527876693588};\\\", \\\"{x:585,y:510,t:1527876693606};\\\", \\\"{x:554,y:516,t:1527876693622};\\\", \\\"{x:510,y:522,t:1527876693639};\\\", \\\"{x:474,y:527,t:1527876693655};\\\", \\\"{x:455,y:529,t:1527876693672};\\\", \\\"{x:432,y:532,t:1527876693688};\\\", \\\"{x:413,y:538,t:1527876693706};\\\", \\\"{x:389,y:541,t:1527876693722};\\\", \\\"{x:368,y:541,t:1527876693738};\\\", \\\"{x:348,y:543,t:1527876693756};\\\", \\\"{x:337,y:543,t:1527876693772};\\\", \\\"{x:321,y:545,t:1527876693789};\\\", \\\"{x:313,y:545,t:1527876693805};\\\", \\\"{x:301,y:550,t:1527876693821};\\\", \\\"{x:284,y:554,t:1527876693839};\\\", \\\"{x:270,y:556,t:1527876693857};\\\", \\\"{x:254,y:558,t:1527876693872};\\\", \\\"{x:241,y:558,t:1527876693888};\\\", \\\"{x:232,y:558,t:1527876693906};\\\", \\\"{x:229,y:558,t:1527876693922};\\\", \\\"{x:228,y:558,t:1527876693938};\\\", \\\"{x:227,y:558,t:1527876693956};\\\", \\\"{x:226,y:558,t:1527876694005};\\\", \\\"{x:230,y:561,t:1527876694126};\\\", \\\"{x:239,y:564,t:1527876694140};\\\", \\\"{x:262,y:576,t:1527876694155};\\\", \\\"{x:308,y:591,t:1527876694172};\\\", \\\"{x:360,y:606,t:1527876694189};\\\", \\\"{x:377,y:612,t:1527876694205};\\\", \\\"{x:385,y:616,t:1527876694223};\\\", \\\"{x:390,y:616,t:1527876694239};\\\", \\\"{x:398,y:614,t:1527876694255};\\\", \\\"{x:414,y:610,t:1527876694273};\\\", \\\"{x:444,y:604,t:1527876694289};\\\", \\\"{x:471,y:601,t:1527876694306};\\\", \\\"{x:504,y:596,t:1527876694324};\\\", \\\"{x:529,y:593,t:1527876694340};\\\", \\\"{x:554,y:587,t:1527876694355};\\\", \\\"{x:575,y:585,t:1527876694373};\\\", \\\"{x:593,y:581,t:1527876694389};\\\", \\\"{x:609,y:580,t:1527876694406};\\\", \\\"{x:623,y:577,t:1527876694423};\\\", \\\"{x:630,y:577,t:1527876694440};\\\", \\\"{x:635,y:575,t:1527876694456};\\\", \\\"{x:639,y:574,t:1527876694473};\\\", \\\"{x:644,y:573,t:1527876694490};\\\", \\\"{x:647,y:571,t:1527876694505};\\\", \\\"{x:656,y:567,t:1527876694523};\\\", \\\"{x:666,y:564,t:1527876694540};\\\", \\\"{x:674,y:561,t:1527876694556};\\\", \\\"{x:683,y:558,t:1527876694573};\\\", \\\"{x:698,y:555,t:1527876694590};\\\", \\\"{x:710,y:552,t:1527876694606};\\\", \\\"{x:725,y:548,t:1527876694625};\\\", \\\"{x:740,y:545,t:1527876694639};\\\", \\\"{x:749,y:544,t:1527876694656};\\\", \\\"{x:756,y:542,t:1527876694673};\\\", \\\"{x:769,y:539,t:1527876694690};\\\", \\\"{x:783,y:535,t:1527876694706};\\\", \\\"{x:798,y:532,t:1527876694723};\\\", \\\"{x:812,y:531,t:1527876694739};\\\", \\\"{x:826,y:531,t:1527876694757};\\\", \\\"{x:836,y:531,t:1527876694772};\\\", \\\"{x:846,y:531,t:1527876694790};\\\", \\\"{x:851,y:531,t:1527876694806};\\\", \\\"{x:853,y:532,t:1527876694824};\\\", \\\"{x:854,y:533,t:1527876694853};\\\", \\\"{x:855,y:534,t:1527876694870};\\\", \\\"{x:856,y:534,t:1527876694877};\\\", \\\"{x:857,y:536,t:1527876694890};\\\", \\\"{x:858,y:538,t:1527876694907};\\\", \\\"{x:858,y:542,t:1527876694991};\\\", \\\"{x:850,y:544,t:1527876695007};\\\", \\\"{x:850,y:545,t:1527876695024};\\\", \\\"{x:849,y:546,t:1527876695041};\\\", \\\"{x:849,y:547,t:1527876695694};\\\", \\\"{x:849,y:548,t:1527876695706};\\\", \\\"{x:849,y:549,t:1527876695723};\\\", \\\"{x:849,y:551,t:1527876695740};\\\", \\\"{x:849,y:552,t:1527876695756};\\\", \\\"{x:849,y:554,t:1527876695773};\\\", \\\"{x:849,y:558,t:1527876695789};\\\", \\\"{x:846,y:561,t:1527876695806};\\\", \\\"{x:842,y:565,t:1527876695823};\\\", \\\"{x:839,y:568,t:1527876695839};\\\", \\\"{x:836,y:572,t:1527876695856};\\\", \\\"{x:830,y:580,t:1527876695873};\\\", \\\"{x:826,y:586,t:1527876695890};\\\", \\\"{x:818,y:594,t:1527876695907};\\\", \\\"{x:808,y:602,t:1527876695924};\\\", \\\"{x:791,y:616,t:1527876695940};\\\", \\\"{x:782,y:626,t:1527876695957};\\\", \\\"{x:771,y:634,t:1527876695974};\\\", \\\"{x:761,y:641,t:1527876695991};\\\", \\\"{x:745,y:648,t:1527876696007};\\\", \\\"{x:729,y:658,t:1527876696024};\\\", \\\"{x:697,y:677,t:1527876696040};\\\", \\\"{x:664,y:697,t:1527876696057};\\\", \\\"{x:637,y:706,t:1527876696074};\\\", \\\"{x:626,y:709,t:1527876696090};\\\", \\\"{x:621,y:712,t:1527876696107};\\\", \\\"{x:618,y:714,t:1527876696124};\\\", \\\"{x:617,y:715,t:1527876696140};\\\", \\\"{x:606,y:719,t:1527876696157};\\\", \\\"{x:597,y:720,t:1527876696173};\\\", \\\"{x:575,y:721,t:1527876696190};\\\", \\\"{x:543,y:726,t:1527876696209};\\\", \\\"{x:527,y:728,t:1527876696223};\\\", \\\"{x:523,y:729,t:1527876696241};\\\", \\\"{x:522,y:730,t:1527876696357};\\\", \\\"{x:522,y:731,t:1527876696406};\\\", \\\"{x:521,y:732,t:1527876696413};\\\", \\\"{x:520,y:732,t:1527876696542};\\\", \\\"{x:521,y:732,t:1527876697238};\\\", \\\"{x:525,y:732,t:1527876697245};\\\", \\\"{x:530,y:728,t:1527876697258};\\\", \\\"{x:535,y:725,t:1527876697275};\\\", \\\"{x:538,y:721,t:1527876697292};\\\", \\\"{x:541,y:719,t:1527876697309};\\\", \\\"{x:546,y:715,t:1527876697325};\\\", \\\"{x:559,y:706,t:1527876697341};\\\", \\\"{x:575,y:696,t:1527876697359};\\\", \\\"{x:587,y:689,t:1527876697375};\\\", \\\"{x:601,y:682,t:1527876697392};\\\", \\\"{x:601,y:675,t:1527876697409};\\\", \\\"{x:616,y:666,t:1527876697424};\\\", \\\"{x:624,y:657,t:1527876697441};\\\", \\\"{x:649,y:649,t:1527876697458};\\\", \\\"{x:662,y:645,t:1527876697474};\\\", \\\"{x:681,y:638,t:1527876697491};\\\", \\\"{x:695,y:633,t:1527876697509};\\\", \\\"{x:704,y:625,t:1527876697525};\\\", \\\"{x:710,y:621,t:1527876697541};\\\", \\\"{x:711,y:621,t:1527876697909};\\\" ] }, { \\\"rt\\\": 28604, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 11, \\\"time_elapsed\\\": 334763, \\\"internal_node_id\\\": \\\"0.0-6.0-1.0\\\", \\\"subject\\\": \\\"7BW1K\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+starts\\\", \\\"q\\\": 7, \\\"clicks\\\": 2, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"X\\\", \\\"O\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F -X -X -O -O -O -O -X -X -F -F -B -O -O -X -X \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:711,y:614,t:1527876698765};\\\", \\\"{x:684,y:591,t:1527876698784};\\\", \\\"{x:667,y:586,t:1527876698794};\\\", \\\"{x:640,y:572,t:1527876698810};\\\", \\\"{x:617,y:558,t:1527876698826};\\\", \\\"{x:602,y:551,t:1527876698843};\\\", \\\"{x:592,y:544,t:1527876698860};\\\", \\\"{x:591,y:542,t:1527876698875};\\\", \\\"{x:590,y:541,t:1527876698933};\\\", \\\"{x:588,y:541,t:1527876699045};\\\", \\\"{x:586,y:539,t:1527876699060};\\\", \\\"{x:578,y:537,t:1527876699076};\\\", \\\"{x:563,y:531,t:1527876699094};\\\", \\\"{x:548,y:524,t:1527876699110};\\\", \\\"{x:539,y:521,t:1527876699125};\\\", \\\"{x:527,y:515,t:1527876699143};\\\", \\\"{x:519,y:509,t:1527876699159};\\\", \\\"{x:517,y:507,t:1527876699177};\\\", \\\"{x:516,y:506,t:1527876699196};\\\", \\\"{x:514,y:503,t:1527876699213};\\\", \\\"{x:509,y:503,t:1527876699226};\\\", \\\"{x:499,y:500,t:1527876699243};\\\", \\\"{x:491,y:498,t:1527876699261};\\\", \\\"{x:476,y:491,t:1527876699277};\\\", \\\"{x:464,y:485,t:1527876699293};\\\", \\\"{x:455,y:482,t:1527876699310};\\\", \\\"{x:439,y:480,t:1527876699327};\\\", \\\"{x:411,y:478,t:1527876699342};\\\", \\\"{x:359,y:473,t:1527876699360};\\\", \\\"{x:286,y:470,t:1527876699377};\\\", \\\"{x:229,y:457,t:1527876699393};\\\", \\\"{x:202,y:448,t:1527876699410};\\\", \\\"{x:196,y:445,t:1527876699427};\\\", \\\"{x:196,y:444,t:1527876699443};\\\", \\\"{x:195,y:444,t:1527876699460};\\\", \\\"{x:197,y:442,t:1527876699542};\\\", \\\"{x:202,y:441,t:1527876699549};\\\", \\\"{x:205,y:440,t:1527876699561};\\\", \\\"{x:211,y:437,t:1527876699577};\\\", \\\"{x:216,y:436,t:1527876699595};\\\", \\\"{x:227,y:436,t:1527876699610};\\\", \\\"{x:243,y:436,t:1527876699627};\\\", \\\"{x:270,y:440,t:1527876699644};\\\", \\\"{x:303,y:453,t:1527876699660};\\\", \\\"{x:341,y:467,t:1527876699677};\\\", \\\"{x:350,y:471,t:1527876699694};\\\", \\\"{x:351,y:472,t:1527876699710};\\\", \\\"{x:352,y:472,t:1527876699870};\\\", \\\"{x:353,y:471,t:1527876699878};\\\", \\\"{x:354,y:470,t:1527876699894};\\\", \\\"{x:357,y:467,t:1527876699911};\\\", \\\"{x:358,y:465,t:1527876699927};\\\", \\\"{x:360,y:463,t:1527876699944};\\\", \\\"{x:362,y:462,t:1527876699960};\\\", \\\"{x:364,y:460,t:1527876699978};\\\", \\\"{x:366,y:459,t:1527876699994};\\\", \\\"{x:368,y:458,t:1527876700021};\\\", \\\"{x:369,y:457,t:1527876700029};\\\", \\\"{x:370,y:456,t:1527876700053};\\\", \\\"{x:371,y:456,t:1527876700062};\\\", \\\"{x:372,y:456,t:1527876700077};\\\", \\\"{x:374,y:456,t:1527876700302};\\\", \\\"{x:375,y:455,t:1527876700311};\\\", \\\"{x:376,y:454,t:1527876700328};\\\", \\\"{x:378,y:453,t:1527876700344};\\\", \\\"{x:380,y:453,t:1527876700361};\\\", \\\"{x:381,y:453,t:1527876700379};\\\", \\\"{x:379,y:453,t:1527876701238};\\\", \\\"{x:378,y:453,t:1527876701245};\\\", \\\"{x:374,y:454,t:1527876701261};\\\", \\\"{x:370,y:455,t:1527876701279};\\\", \\\"{x:364,y:457,t:1527876701296};\\\", \\\"{x:363,y:457,t:1527876701312};\\\", \\\"{x:360,y:459,t:1527876701329};\\\", \\\"{x:356,y:459,t:1527876701344};\\\", \\\"{x:352,y:460,t:1527876701361};\\\", \\\"{x:346,y:462,t:1527876701378};\\\", \\\"{x:338,y:462,t:1527876701395};\\\", \\\"{x:331,y:464,t:1527876701412};\\\", \\\"{x:321,y:464,t:1527876701427};\\\", \\\"{x:300,y:464,t:1527876701445};\\\", \\\"{x:293,y:464,t:1527876701462};\\\", \\\"{x:289,y:464,t:1527876701478};\\\", \\\"{x:287,y:464,t:1527876701495};\\\", \\\"{x:285,y:464,t:1527876701512};\\\", \\\"{x:282,y:464,t:1527876701529};\\\", \\\"{x:280,y:464,t:1527876701545};\\\", \\\"{x:278,y:463,t:1527876701563};\\\", \\\"{x:278,y:462,t:1527876701662};\\\", \\\"{x:283,y:460,t:1527876701679};\\\", \\\"{x:292,y:457,t:1527876701695};\\\", \\\"{x:297,y:453,t:1527876701713};\\\", \\\"{x:298,y:453,t:1527876701729};\\\", \\\"{x:299,y:452,t:1527876701830};\\\", \\\"{x:300,y:452,t:1527876701846};\\\", \\\"{x:303,y:452,t:1527876701862};\\\", \\\"{x:309,y:450,t:1527876701879};\\\", \\\"{x:314,y:450,t:1527876701895};\\\", \\\"{x:320,y:449,t:1527876701912};\\\", \\\"{x:329,y:447,t:1527876701929};\\\", \\\"{x:335,y:447,t:1527876701946};\\\", \\\"{x:340,y:447,t:1527876701962};\\\", \\\"{x:343,y:446,t:1527876701980};\\\", \\\"{x:344,y:446,t:1527876701996};\\\", \\\"{x:346,y:446,t:1527876702013};\\\", \\\"{x:353,y:445,t:1527876702029};\\\", \\\"{x:357,y:444,t:1527876702045};\\\", \\\"{x:362,y:442,t:1527876702062};\\\", \\\"{x:366,y:442,t:1527876702080};\\\", \\\"{x:376,y:441,t:1527876702096};\\\", \\\"{x:386,y:438,t:1527876702113};\\\", \\\"{x:401,y:438,t:1527876702129};\\\", \\\"{x:422,y:438,t:1527876702147};\\\", \\\"{x:432,y:438,t:1527876702162};\\\", \\\"{x:435,y:438,t:1527876702180};\\\", \\\"{x:438,y:438,t:1527876702222};\\\", \\\"{x:439,y:438,t:1527876702230};\\\", \\\"{x:445,y:438,t:1527876702246};\\\", \\\"{x:455,y:439,t:1527876702263};\\\", \\\"{x:460,y:441,t:1527876702280};\\\", \\\"{x:462,y:441,t:1527876702296};\\\", \\\"{x:463,y:441,t:1527876702398};\\\", \\\"{x:464,y:441,t:1527876702446};\\\", \\\"{x:466,y:442,t:1527876702582};\\\", \\\"{x:468,y:442,t:1527876702597};\\\", \\\"{x:477,y:446,t:1527876702613};\\\", \\\"{x:484,y:449,t:1527876702630};\\\", \\\"{x:491,y:451,t:1527876702646};\\\", \\\"{x:494,y:451,t:1527876702663};\\\", \\\"{x:495,y:451,t:1527876702679};\\\", \\\"{x:496,y:451,t:1527876702734};\\\", \\\"{x:497,y:452,t:1527876702790};\\\", \\\"{x:498,y:452,t:1527876702870};\\\", \\\"{x:499,y:452,t:1527876702926};\\\", \\\"{x:500,y:452,t:1527876702934};\\\", \\\"{x:501,y:452,t:1527876702966};\\\", \\\"{x:502,y:452,t:1527876702981};\\\", \\\"{x:503,y:452,t:1527876702996};\\\", \\\"{x:504,y:452,t:1527876703070};\\\", \\\"{x:505,y:452,t:1527876703080};\\\", \\\"{x:511,y:452,t:1527876703096};\\\", \\\"{x:517,y:452,t:1527876703114};\\\", \\\"{x:519,y:452,t:1527876703131};\\\", \\\"{x:520,y:452,t:1527876703148};\\\", \\\"{x:521,y:452,t:1527876703164};\\\", \\\"{x:522,y:452,t:1527876703197};\\\", \\\"{x:528,y:452,t:1527876703213};\\\", \\\"{x:534,y:452,t:1527876703230};\\\", \\\"{x:539,y:452,t:1527876703248};\\\", \\\"{x:541,y:452,t:1527876703264};\\\", \\\"{x:545,y:452,t:1527876703280};\\\", \\\"{x:547,y:452,t:1527876703297};\\\", \\\"{x:554,y:452,t:1527876703313};\\\", \\\"{x:563,y:450,t:1527876703330};\\\", \\\"{x:570,y:450,t:1527876703347};\\\", \\\"{x:579,y:450,t:1527876703363};\\\", \\\"{x:584,y:450,t:1527876703380};\\\", \\\"{x:587,y:450,t:1527876703396};\\\", \\\"{x:588,y:450,t:1527876703444};\\\", \\\"{x:589,y:450,t:1527876703510};\\\", \\\"{x:590,y:450,t:1527876703534};\\\", \\\"{x:591,y:450,t:1527876703557};\\\", \\\"{x:592,y:450,t:1527876703590};\\\", \\\"{x:594,y:450,t:1527876703701};\\\", \\\"{x:595,y:450,t:1527876703715};\\\", \\\"{x:596,y:451,t:1527876703731};\\\", \\\"{x:597,y:451,t:1527876704502};\\\", \\\"{x:599,y:451,t:1527876704558};\\\", \\\"{x:600,y:451,t:1527876704565};\\\", \\\"{x:609,y:449,t:1527876704581};\\\", \\\"{x:620,y:449,t:1527876704598};\\\", \\\"{x:632,y:449,t:1527876704614};\\\", \\\"{x:645,y:449,t:1527876704632};\\\", \\\"{x:657,y:449,t:1527876704649};\\\", \\\"{x:674,y:449,t:1527876704665};\\\", \\\"{x:684,y:448,t:1527876704682};\\\", \\\"{x:695,y:447,t:1527876704699};\\\", \\\"{x:702,y:447,t:1527876704714};\\\", \\\"{x:706,y:447,t:1527876704732};\\\", \\\"{x:708,y:447,t:1527876704748};\\\", \\\"{x:709,y:447,t:1527876704766};\\\", \\\"{x:712,y:446,t:1527876704789};\\\", \\\"{x:713,y:446,t:1527876704798};\\\", \\\"{x:715,y:446,t:1527876704816};\\\", \\\"{x:716,y:446,t:1527876704832};\\\", \\\"{x:719,y:446,t:1527876704861};\\\", \\\"{x:723,y:448,t:1527876704869};\\\", \\\"{x:726,y:449,t:1527876704882};\\\", \\\"{x:728,y:449,t:1527876704899};\\\", \\\"{x:732,y:449,t:1527876704916};\\\", \\\"{x:735,y:449,t:1527876704931};\\\", \\\"{x:738,y:449,t:1527876704948};\\\", \\\"{x:745,y:449,t:1527876704965};\\\", \\\"{x:749,y:449,t:1527876704981};\\\", \\\"{x:752,y:449,t:1527876704999};\\\", \\\"{x:755,y:449,t:1527876705326};\\\", \\\"{x:758,y:449,t:1527876705333};\\\", \\\"{x:762,y:449,t:1527876705348};\\\", \\\"{x:783,y:449,t:1527876705366};\\\", \\\"{x:806,y:451,t:1527876705382};\\\", \\\"{x:837,y:454,t:1527876705399};\\\", \\\"{x:867,y:454,t:1527876705415};\\\", \\\"{x:912,y:454,t:1527876705432};\\\", \\\"{x:939,y:454,t:1527876705448};\\\", \\\"{x:959,y:455,t:1527876705465};\\\", \\\"{x:972,y:455,t:1527876705483};\\\", \\\"{x:988,y:455,t:1527876705499};\\\", \\\"{x:1001,y:455,t:1527876705515};\\\", \\\"{x:1012,y:456,t:1527876705533};\\\", \\\"{x:1020,y:461,t:1527876705549};\\\", \\\"{x:1037,y:464,t:1527876705566};\\\", \\\"{x:1046,y:465,t:1527876705582};\\\", \\\"{x:1056,y:466,t:1527876705599};\\\", \\\"{x:1073,y:472,t:1527876705616};\\\", \\\"{x:1088,y:474,t:1527876705633};\\\", \\\"{x:1109,y:477,t:1527876705649};\\\", \\\"{x:1118,y:480,t:1527876705666};\\\", \\\"{x:1123,y:481,t:1527876705682};\\\", \\\"{x:1125,y:481,t:1527876705700};\\\", \\\"{x:1125,y:482,t:1527876705717};\\\", \\\"{x:1126,y:483,t:1527876705733};\\\", \\\"{x:1127,y:484,t:1527876705750};\\\", \\\"{x:1129,y:485,t:1527876705766};\\\", \\\"{x:1130,y:486,t:1527876705783};\\\", \\\"{x:1131,y:486,t:1527876705800};\\\", \\\"{x:1134,y:488,t:1527876705815};\\\", \\\"{x:1136,y:489,t:1527876705833};\\\", \\\"{x:1139,y:490,t:1527876705850};\\\", \\\"{x:1143,y:491,t:1527876705866};\\\", \\\"{x:1145,y:493,t:1527876705883};\\\", \\\"{x:1147,y:494,t:1527876705900};\\\", \\\"{x:1148,y:496,t:1527876705916};\\\", \\\"{x:1149,y:497,t:1527876705934};\\\", \\\"{x:1150,y:499,t:1527876705950};\\\", \\\"{x:1154,y:503,t:1527876705966};\\\", \\\"{x:1160,y:509,t:1527876705982};\\\", \\\"{x:1164,y:514,t:1527876706000};\\\", \\\"{x:1165,y:517,t:1527876706016};\\\", \\\"{x:1166,y:519,t:1527876706033};\\\", \\\"{x:1166,y:522,t:1527876706050};\\\", \\\"{x:1167,y:527,t:1527876706067};\\\", \\\"{x:1170,y:535,t:1527876706082};\\\", \\\"{x:1171,y:545,t:1527876706099};\\\", \\\"{x:1171,y:556,t:1527876706117};\\\", \\\"{x:1174,y:563,t:1527876706133};\\\", \\\"{x:1175,y:571,t:1527876706150};\\\", \\\"{x:1177,y:579,t:1527876706167};\\\", \\\"{x:1180,y:592,t:1527876706183};\\\", \\\"{x:1184,y:609,t:1527876706200};\\\", \\\"{x:1186,y:628,t:1527876706216};\\\", \\\"{x:1187,y:638,t:1527876706232};\\\", \\\"{x:1190,y:644,t:1527876706249};\\\", \\\"{x:1191,y:647,t:1527876706267};\\\", \\\"{x:1192,y:647,t:1527876706350};\\\", \\\"{x:1196,y:647,t:1527876706367};\\\", \\\"{x:1200,y:646,t:1527876706383};\\\", \\\"{x:1209,y:642,t:1527876706400};\\\", \\\"{x:1220,y:637,t:1527876706417};\\\", \\\"{x:1226,y:635,t:1527876706434};\\\", \\\"{x:1229,y:633,t:1527876706449};\\\", \\\"{x:1230,y:632,t:1527876706467};\\\", \\\"{x:1231,y:632,t:1527876706493};\\\", \\\"{x:1233,y:633,t:1527876706501};\\\", \\\"{x:1234,y:634,t:1527876706516};\\\", \\\"{x:1248,y:643,t:1527876706533};\\\", \\\"{x:1256,y:646,t:1527876706550};\\\", \\\"{x:1262,y:649,t:1527876706567};\\\", \\\"{x:1271,y:655,t:1527876706584};\\\", \\\"{x:1276,y:659,t:1527876706600};\\\", \\\"{x:1288,y:663,t:1527876706617};\\\", \\\"{x:1303,y:667,t:1527876706634};\\\", \\\"{x:1323,y:671,t:1527876706650};\\\", \\\"{x:1336,y:674,t:1527876706667};\\\", \\\"{x:1339,y:674,t:1527876706684};\\\", \\\"{x:1341,y:674,t:1527876706700};\\\", \\\"{x:1342,y:674,t:1527876706750};\\\", \\\"{x:1344,y:674,t:1527876706781};\\\", \\\"{x:1345,y:674,t:1527876706870};\\\", \\\"{x:1345,y:675,t:1527876706885};\\\", \\\"{x:1345,y:677,t:1527876707982};\\\", \\\"{x:1345,y:678,t:1527876707993};\\\", \\\"{x:1345,y:679,t:1527876708001};\\\", \\\"{x:1345,y:681,t:1527876708017};\\\", \\\"{x:1346,y:684,t:1527876708034};\\\", \\\"{x:1346,y:685,t:1527876708051};\\\", \\\"{x:1346,y:687,t:1527876708067};\\\", \\\"{x:1346,y:688,t:1527876708084};\\\", \\\"{x:1346,y:689,t:1527876708189};\\\", \\\"{x:1347,y:690,t:1527876708334};\\\", \\\"{x:1348,y:690,t:1527876708351};\\\", \\\"{x:1350,y:690,t:1527876708405};\\\", \\\"{x:1351,y:690,t:1527876708417};\\\", \\\"{x:1352,y:691,t:1527876708434};\\\", \\\"{x:1354,y:691,t:1527876708451};\\\", \\\"{x:1355,y:691,t:1527876708469};\\\", \\\"{x:1356,y:691,t:1527876708485};\\\", \\\"{x:1361,y:694,t:1527876708501};\\\", \\\"{x:1371,y:698,t:1527876708519};\\\", \\\"{x:1385,y:703,t:1527876708534};\\\", \\\"{x:1402,y:710,t:1527876708551};\\\", \\\"{x:1409,y:714,t:1527876708568};\\\", \\\"{x:1415,y:716,t:1527876708584};\\\", \\\"{x:1419,y:717,t:1527876708601};\\\", \\\"{x:1425,y:719,t:1527876708619};\\\", \\\"{x:1431,y:722,t:1527876708635};\\\", \\\"{x:1442,y:723,t:1527876708652};\\\", \\\"{x:1447,y:726,t:1527876708668};\\\", \\\"{x:1453,y:727,t:1527876708684};\\\", \\\"{x:1455,y:728,t:1527876708701};\\\", \\\"{x:1456,y:730,t:1527876708718};\\\", \\\"{x:1459,y:734,t:1527876708734};\\\", \\\"{x:1463,y:738,t:1527876708751};\\\", \\\"{x:1467,y:741,t:1527876708768};\\\", \\\"{x:1470,y:744,t:1527876708784};\\\", \\\"{x:1474,y:745,t:1527876708801};\\\", \\\"{x:1477,y:746,t:1527876708818};\\\", \\\"{x:1481,y:749,t:1527876708835};\\\", \\\"{x:1485,y:752,t:1527876708852};\\\", \\\"{x:1495,y:760,t:1527876708869};\\\", \\\"{x:1495,y:761,t:1527876708894};\\\", \\\"{x:1497,y:761,t:1527876708910};\\\", \\\"{x:1498,y:761,t:1527876708982};\\\", \\\"{x:1500,y:761,t:1527876708990};\\\", \\\"{x:1502,y:762,t:1527876709006};\\\", \\\"{x:1503,y:764,t:1527876709019};\\\", \\\"{x:1505,y:765,t:1527876709035};\\\", \\\"{x:1505,y:766,t:1527876709052};\\\", \\\"{x:1507,y:767,t:1527876709069};\\\", \\\"{x:1508,y:768,t:1527876709478};\\\", \\\"{x:1509,y:774,t:1527876709486};\\\", \\\"{x:1506,y:785,t:1527876709504};\\\", \\\"{x:1506,y:787,t:1527876709526};\\\", \\\"{x:1506,y:790,t:1527876709536};\\\", \\\"{x:1506,y:792,t:1527876709553};\\\", \\\"{x:1506,y:793,t:1527876709569};\\\", \\\"{x:1505,y:793,t:1527876709605};\\\", \\\"{x:1504,y:793,t:1527876709686};\\\", \\\"{x:1502,y:793,t:1527876709758};\\\", \\\"{x:1500,y:794,t:1527876709774};\\\", \\\"{x:1500,y:795,t:1527876709786};\\\", \\\"{x:1498,y:796,t:1527876709803};\\\", \\\"{x:1495,y:797,t:1527876709819};\\\", \\\"{x:1493,y:799,t:1527876709835};\\\", \\\"{x:1492,y:800,t:1527876709853};\\\", \\\"{x:1490,y:802,t:1527876709869};\\\", \\\"{x:1487,y:804,t:1527876709885};\\\", \\\"{x:1482,y:807,t:1527876709902};\\\", \\\"{x:1478,y:813,t:1527876709919};\\\", \\\"{x:1476,y:818,t:1527876709936};\\\", \\\"{x:1476,y:823,t:1527876709953};\\\", \\\"{x:1475,y:825,t:1527876709973};\\\", \\\"{x:1474,y:826,t:1527876710301};\\\", \\\"{x:1475,y:825,t:1527876710677};\\\", \\\"{x:1476,y:825,t:1527876710687};\\\", \\\"{x:1480,y:822,t:1527876710704};\\\", \\\"{x:1482,y:821,t:1527876710720};\\\", \\\"{x:1483,y:821,t:1527876710749};\\\", \\\"{x:1485,y:820,t:1527876710759};\\\", \\\"{x:1485,y:819,t:1527876710770};\\\", \\\"{x:1489,y:817,t:1527876710787};\\\", \\\"{x:1493,y:816,t:1527876710804};\\\", \\\"{x:1495,y:814,t:1527876710820};\\\", \\\"{x:1497,y:813,t:1527876710836};\\\", \\\"{x:1500,y:813,t:1527876710853};\\\", \\\"{x:1500,y:812,t:1527876710870};\\\", \\\"{x:1502,y:808,t:1527876710887};\\\", \\\"{x:1505,y:804,t:1527876710904};\\\", \\\"{x:1510,y:797,t:1527876710921};\\\", \\\"{x:1512,y:788,t:1527876710937};\\\", \\\"{x:1515,y:783,t:1527876710954};\\\", \\\"{x:1515,y:780,t:1527876710971};\\\", \\\"{x:1516,y:776,t:1527876710987};\\\", \\\"{x:1521,y:771,t:1527876711003};\\\", \\\"{x:1525,y:766,t:1527876711021};\\\", \\\"{x:1527,y:760,t:1527876711037};\\\", \\\"{x:1531,y:752,t:1527876711054};\\\", \\\"{x:1531,y:750,t:1527876711071};\\\", \\\"{x:1532,y:749,t:1527876711087};\\\", \\\"{x:1531,y:749,t:1527876711238};\\\", \\\"{x:1528,y:749,t:1527876711253};\\\", \\\"{x:1527,y:750,t:1527876711271};\\\", \\\"{x:1526,y:752,t:1527876711287};\\\", \\\"{x:1525,y:753,t:1527876711304};\\\", \\\"{x:1525,y:754,t:1527876711321};\\\", \\\"{x:1523,y:755,t:1527876711339};\\\", \\\"{x:1521,y:757,t:1527876711354};\\\", \\\"{x:1517,y:759,t:1527876711373};\\\", \\\"{x:1504,y:764,t:1527876711389};\\\", \\\"{x:1486,y:768,t:1527876711404};\\\", \\\"{x:1460,y:774,t:1527876711421};\\\", \\\"{x:1386,y:777,t:1527876711438};\\\", \\\"{x:1315,y:773,t:1527876711454};\\\", \\\"{x:1234,y:762,t:1527876711471};\\\", \\\"{x:1185,y:751,t:1527876711488};\\\", \\\"{x:1092,y:732,t:1527876711504};\\\", \\\"{x:1017,y:707,t:1527876711521};\\\", \\\"{x:946,y:682,t:1527876711538};\\\", \\\"{x:913,y:667,t:1527876711554};\\\", \\\"{x:880,y:654,t:1527876711570};\\\", \\\"{x:852,y:644,t:1527876711588};\\\", \\\"{x:829,y:636,t:1527876711604};\\\", \\\"{x:815,y:628,t:1527876711623};\\\", \\\"{x:810,y:626,t:1527876711637};\\\", \\\"{x:810,y:625,t:1527876711653};\\\", \\\"{x:807,y:623,t:1527876711709};\\\", \\\"{x:806,y:623,t:1527876711716};\\\", \\\"{x:805,y:621,t:1527876711732};\\\", \\\"{x:805,y:619,t:1527876711773};\\\", \\\"{x:805,y:617,t:1527876711781};\\\", \\\"{x:808,y:614,t:1527876711798};\\\", \\\"{x:810,y:612,t:1527876711814};\\\", \\\"{x:816,y:608,t:1527876711832};\\\", \\\"{x:819,y:604,t:1527876711849};\\\", \\\"{x:827,y:599,t:1527876711865};\\\", \\\"{x:834,y:595,t:1527876711882};\\\", \\\"{x:841,y:589,t:1527876711904};\\\", \\\"{x:842,y:587,t:1527876711920};\\\", \\\"{x:843,y:586,t:1527876711936};\\\", \\\"{x:843,y:585,t:1527876711953};\\\", \\\"{x:844,y:583,t:1527876711972};\\\", \\\"{x:844,y:581,t:1527876711996};\\\", \\\"{x:844,y:580,t:1527876712005};\\\", \\\"{x:844,y:578,t:1527876712020};\\\", \\\"{x:844,y:574,t:1527876712037};\\\", \\\"{x:844,y:570,t:1527876712053};\\\", \\\"{x:844,y:569,t:1527876712070};\\\", \\\"{x:844,y:568,t:1527876712088};\\\", \\\"{x:844,y:567,t:1527876712103};\\\", \\\"{x:841,y:567,t:1527876712205};\\\", \\\"{x:838,y:567,t:1527876712221};\\\", \\\"{x:833,y:567,t:1527876712237};\\\", \\\"{x:829,y:568,t:1527876712254};\\\", \\\"{x:828,y:568,t:1527876712293};\\\", \\\"{x:828,y:569,t:1527876712494};\\\", \\\"{x:828,y:570,t:1527876712510};\\\", \\\"{x:826,y:571,t:1527876712837};\\\", \\\"{x:804,y:574,t:1527876712854};\\\", \\\"{x:775,y:579,t:1527876712870};\\\", \\\"{x:717,y:587,t:1527876712889};\\\", \\\"{x:674,y:594,t:1527876712905};\\\", \\\"{x:615,y:596,t:1527876712921};\\\", \\\"{x:546,y:603,t:1527876712938};\\\", \\\"{x:488,y:605,t:1527876712955};\\\", \\\"{x:443,y:605,t:1527876712972};\\\", \\\"{x:409,y:605,t:1527876712987};\\\", \\\"{x:394,y:605,t:1527876713004};\\\", \\\"{x:393,y:605,t:1527876713021};\\\", \\\"{x:390,y:605,t:1527876713094};\\\", \\\"{x:387,y:604,t:1527876713105};\\\", \\\"{x:385,y:603,t:1527876713122};\\\", \\\"{x:380,y:600,t:1527876713140};\\\", \\\"{x:376,y:597,t:1527876713155};\\\", \\\"{x:374,y:595,t:1527876713171};\\\", \\\"{x:372,y:591,t:1527876713189};\\\", \\\"{x:372,y:590,t:1527876713309};\\\", \\\"{x:372,y:588,t:1527876713325};\\\", \\\"{x:372,y:587,t:1527876713338};\\\", \\\"{x:375,y:586,t:1527876713354};\\\", \\\"{x:376,y:584,t:1527876713372};\\\", \\\"{x:377,y:584,t:1527876713388};\\\", \\\"{x:377,y:583,t:1527876713404};\\\", \\\"{x:377,y:582,t:1527876714205};\\\", \\\"{x:379,y:581,t:1527876714222};\\\", \\\"{x:380,y:581,t:1527876714239};\\\", \\\"{x:382,y:580,t:1527876714256};\\\", \\\"{x:383,y:580,t:1527876714272};\\\", \\\"{x:384,y:580,t:1527876714293};\\\", \\\"{x:386,y:579,t:1527876714306};\\\", \\\"{x:388,y:578,t:1527876714321};\\\", \\\"{x:389,y:578,t:1527876714339};\\\", \\\"{x:390,y:577,t:1527876714356};\\\", \\\"{x:391,y:577,t:1527876714372};\\\", \\\"{x:392,y:577,t:1527876715165};\\\", \\\"{x:392,y:576,t:1527876715293};\\\", \\\"{x:394,y:575,t:1527876715306};\\\", \\\"{x:396,y:574,t:1527876715324};\\\", \\\"{x:404,y:572,t:1527876715340};\\\", \\\"{x:412,y:572,t:1527876715356};\\\", \\\"{x:424,y:571,t:1527876715374};\\\", \\\"{x:429,y:568,t:1527876715389};\\\", \\\"{x:430,y:568,t:1527876715407};\\\", \\\"{x:431,y:568,t:1527876715423};\\\", \\\"{x:430,y:568,t:1527876715502};\\\", \\\"{x:427,y:568,t:1527876715510};\\\", \\\"{x:424,y:568,t:1527876715523};\\\", \\\"{x:422,y:569,t:1527876715540};\\\", \\\"{x:427,y:569,t:1527876715574};\\\", \\\"{x:440,y:565,t:1527876715590};\\\", \\\"{x:497,y:567,t:1527876715607};\\\", \\\"{x:574,y:567,t:1527876715625};\\\", \\\"{x:609,y:568,t:1527876715639};\\\", \\\"{x:628,y:571,t:1527876715656};\\\", \\\"{x:634,y:571,t:1527876715673};\\\", \\\"{x:635,y:572,t:1527876715772};\\\", \\\"{x:633,y:573,t:1527876715796};\\\", \\\"{x:632,y:574,t:1527876715807};\\\", \\\"{x:629,y:574,t:1527876715823};\\\", \\\"{x:627,y:575,t:1527876715840};\\\", \\\"{x:625,y:576,t:1527876715856};\\\", \\\"{x:624,y:576,t:1527876715873};\\\", \\\"{x:623,y:578,t:1527876715890};\\\", \\\"{x:622,y:578,t:1527876715965};\\\", \\\"{x:623,y:578,t:1527876716204};\\\", \\\"{x:627,y:577,t:1527876716213};\\\", \\\"{x:631,y:577,t:1527876716223};\\\", \\\"{x:640,y:576,t:1527876716240};\\\", \\\"{x:712,y:581,t:1527876716257};\\\", \\\"{x:811,y:589,t:1527876716274};\\\", \\\"{x:949,y:606,t:1527876716291};\\\", \\\"{x:1101,y:628,t:1527876716307};\\\", \\\"{x:1252,y:661,t:1527876716323};\\\", \\\"{x:1477,y:709,t:1527876716340};\\\", \\\"{x:1615,y:745,t:1527876716356};\\\", \\\"{x:1742,y:779,t:1527876716374};\\\", \\\"{x:1836,y:805,t:1527876716392};\\\", \\\"{x:1883,y:819,t:1527876716407};\\\", \\\"{x:1906,y:828,t:1527876716423};\\\", \\\"{x:1908,y:830,t:1527876716441};\\\", \\\"{x:1908,y:831,t:1527876716517};\\\", \\\"{x:1908,y:834,t:1527876716525};\\\", \\\"{x:1893,y:836,t:1527876716541};\\\", \\\"{x:1834,y:835,t:1527876716557};\\\", \\\"{x:1753,y:822,t:1527876716574};\\\", \\\"{x:1708,y:815,t:1527876716592};\\\", \\\"{x:1661,y:804,t:1527876716608};\\\", \\\"{x:1627,y:798,t:1527876716624};\\\", \\\"{x:1599,y:793,t:1527876716641};\\\", \\\"{x:1581,y:789,t:1527876716658};\\\", \\\"{x:1569,y:784,t:1527876716674};\\\", \\\"{x:1556,y:783,t:1527876716692};\\\", \\\"{x:1547,y:779,t:1527876716708};\\\", \\\"{x:1544,y:778,t:1527876716724};\\\", \\\"{x:1544,y:777,t:1527876716750};\\\", \\\"{x:1543,y:777,t:1527876716822};\\\", \\\"{x:1543,y:776,t:1527876716829};\\\", \\\"{x:1543,y:775,t:1527876716878};\\\", \\\"{x:1543,y:774,t:1527876716901};\\\", \\\"{x:1543,y:772,t:1527876716910};\\\", \\\"{x:1544,y:771,t:1527876716925};\\\", \\\"{x:1544,y:770,t:1527876716974};\\\", \\\"{x:1543,y:769,t:1527876717046};\\\", \\\"{x:1542,y:769,t:1527876717070};\\\", \\\"{x:1539,y:769,t:1527876717078};\\\", \\\"{x:1537,y:769,t:1527876717091};\\\", \\\"{x:1534,y:768,t:1527876717109};\\\", \\\"{x:1530,y:768,t:1527876717125};\\\", \\\"{x:1529,y:768,t:1527876717165};\\\", \\\"{x:1527,y:768,t:1527876717181};\\\", \\\"{x:1525,y:768,t:1527876717198};\\\", \\\"{x:1523,y:768,t:1527876717209};\\\", \\\"{x:1519,y:768,t:1527876717225};\\\", \\\"{x:1516,y:768,t:1527876717242};\\\", \\\"{x:1513,y:766,t:1527876717258};\\\", \\\"{x:1513,y:765,t:1527876717437};\\\", \\\"{x:1513,y:763,t:1527876717454};\\\", \\\"{x:1514,y:762,t:1527876717462};\\\", \\\"{x:1515,y:762,t:1527876717475};\\\", \\\"{x:1517,y:760,t:1527876717492};\\\", \\\"{x:1518,y:759,t:1527876717508};\\\", \\\"{x:1519,y:759,t:1527876717583};\\\", \\\"{x:1517,y:759,t:1527876718197};\\\", \\\"{x:1516,y:759,t:1527876718209};\\\", \\\"{x:1515,y:759,t:1527876718349};\\\", \\\"{x:1513,y:759,t:1527876718365};\\\", \\\"{x:1513,y:760,t:1527876718388};\\\", \\\"{x:1512,y:761,t:1527876718396};\\\", \\\"{x:1512,y:762,t:1527876718428};\\\", \\\"{x:1511,y:764,t:1527876718468};\\\", \\\"{x:1509,y:766,t:1527876718477};\\\", \\\"{x:1508,y:767,t:1527876718492};\\\", \\\"{x:1508,y:768,t:1527876718509};\\\", \\\"{x:1508,y:769,t:1527876718533};\\\", \\\"{x:1507,y:770,t:1527876718542};\\\", \\\"{x:1508,y:769,t:1527876718973};\\\", \\\"{x:1509,y:768,t:1527876718981};\\\", \\\"{x:1510,y:768,t:1527876718997};\\\", \\\"{x:1510,y:767,t:1527876719010};\\\", \\\"{x:1510,y:766,t:1527876719025};\\\", \\\"{x:1511,y:765,t:1527876719043};\\\", \\\"{x:1511,y:764,t:1527876719059};\\\", \\\"{x:1512,y:763,t:1527876719077};\\\", \\\"{x:1512,y:762,t:1527876719134};\\\", \\\"{x:1513,y:762,t:1527876719189};\\\", \\\"{x:1514,y:762,t:1527876719205};\\\", \\\"{x:1515,y:761,t:1527876719334};\\\", \\\"{x:1515,y:760,t:1527876719382};\\\", \\\"{x:1515,y:759,t:1527876719573};\\\", \\\"{x:1513,y:759,t:1527876719581};\\\", \\\"{x:1510,y:761,t:1527876719593};\\\", \\\"{x:1506,y:766,t:1527876719610};\\\", \\\"{x:1498,y:775,t:1527876719626};\\\", \\\"{x:1493,y:783,t:1527876719642};\\\", \\\"{x:1485,y:792,t:1527876719660};\\\", \\\"{x:1481,y:800,t:1527876719676};\\\", \\\"{x:1480,y:801,t:1527876719709};\\\", \\\"{x:1480,y:802,t:1527876719717};\\\", \\\"{x:1479,y:803,t:1527876719727};\\\", \\\"{x:1478,y:805,t:1527876719743};\\\", \\\"{x:1477,y:807,t:1527876719760};\\\", \\\"{x:1477,y:808,t:1527876719926};\\\", \\\"{x:1477,y:812,t:1527876719943};\\\", \\\"{x:1477,y:817,t:1527876719961};\\\", \\\"{x:1477,y:825,t:1527876719978};\\\", \\\"{x:1474,y:833,t:1527876719993};\\\", \\\"{x:1474,y:839,t:1527876720010};\\\", \\\"{x:1474,y:842,t:1527876720027};\\\", \\\"{x:1475,y:840,t:1527876720205};\\\", \\\"{x:1478,y:837,t:1527876720214};\\\", \\\"{x:1478,y:835,t:1527876720228};\\\", \\\"{x:1481,y:830,t:1527876720245};\\\", \\\"{x:1481,y:828,t:1527876720260};\\\", \\\"{x:1481,y:827,t:1527876722285};\\\", \\\"{x:1485,y:825,t:1527876722295};\\\", \\\"{x:1491,y:823,t:1527876722313};\\\", \\\"{x:1494,y:822,t:1527876722329};\\\", \\\"{x:1495,y:822,t:1527876722345};\\\", \\\"{x:1497,y:822,t:1527876722366};\\\", \\\"{x:1499,y:821,t:1527876722381};\\\", \\\"{x:1501,y:820,t:1527876722398};\\\", \\\"{x:1502,y:819,t:1527876722413};\\\", \\\"{x:1504,y:819,t:1527876722429};\\\", \\\"{x:1507,y:817,t:1527876722445};\\\", \\\"{x:1508,y:817,t:1527876722463};\\\", \\\"{x:1508,y:816,t:1527876722494};\\\", \\\"{x:1508,y:814,t:1527876722854};\\\", \\\"{x:1508,y:808,t:1527876722862};\\\", \\\"{x:1502,y:796,t:1527876722880};\\\", \\\"{x:1498,y:783,t:1527876722896};\\\", \\\"{x:1496,y:769,t:1527876722913};\\\", \\\"{x:1492,y:756,t:1527876722930};\\\", \\\"{x:1485,y:747,t:1527876722945};\\\", \\\"{x:1472,y:735,t:1527876722962};\\\", \\\"{x:1462,y:725,t:1527876722979};\\\", \\\"{x:1449,y:713,t:1527876722996};\\\", \\\"{x:1442,y:703,t:1527876723013};\\\", \\\"{x:1434,y:687,t:1527876723029};\\\", \\\"{x:1430,y:679,t:1527876723046};\\\", \\\"{x:1420,y:671,t:1527876723062};\\\", \\\"{x:1409,y:662,t:1527876723080};\\\", \\\"{x:1396,y:653,t:1527876723096};\\\", \\\"{x:1393,y:650,t:1527876723112};\\\", \\\"{x:1392,y:648,t:1527876723129};\\\", \\\"{x:1391,y:646,t:1527876723147};\\\", \\\"{x:1390,y:644,t:1527876723162};\\\", \\\"{x:1383,y:641,t:1527876723179};\\\", \\\"{x:1371,y:639,t:1527876723197};\\\", \\\"{x:1352,y:634,t:1527876723213};\\\", \\\"{x:1337,y:632,t:1527876723229};\\\", \\\"{x:1333,y:632,t:1527876723246};\\\", \\\"{x:1332,y:632,t:1527876723262};\\\", \\\"{x:1330,y:632,t:1527876723280};\\\", \\\"{x:1327,y:646,t:1527876723296};\\\", \\\"{x:1327,y:663,t:1527876723313};\\\", \\\"{x:1327,y:673,t:1527876723330};\\\", \\\"{x:1328,y:683,t:1527876723347};\\\", \\\"{x:1331,y:686,t:1527876723362};\\\", \\\"{x:1334,y:688,t:1527876723379};\\\", \\\"{x:1338,y:689,t:1527876723396};\\\", \\\"{x:1340,y:689,t:1527876723413};\\\", \\\"{x:1343,y:688,t:1527876723429};\\\", \\\"{x:1346,y:686,t:1527876723446};\\\", \\\"{x:1348,y:686,t:1527876723630};\\\", \\\"{x:1350,y:695,t:1527876723646};\\\", \\\"{x:1352,y:702,t:1527876723664};\\\", \\\"{x:1353,y:706,t:1527876723680};\\\", \\\"{x:1354,y:707,t:1527876723697};\\\", \\\"{x:1355,y:708,t:1527876723713};\\\", \\\"{x:1355,y:709,t:1527876723902};\\\", \\\"{x:1355,y:711,t:1527876723914};\\\", \\\"{x:1350,y:720,t:1527876723930};\\\", \\\"{x:1344,y:736,t:1527876723947};\\\", \\\"{x:1334,y:758,t:1527876723964};\\\", \\\"{x:1326,y:781,t:1527876723980};\\\", \\\"{x:1325,y:791,t:1527876723996};\\\", \\\"{x:1325,y:798,t:1527876724013};\\\", \\\"{x:1325,y:800,t:1527876724030};\\\", \\\"{x:1330,y:798,t:1527876724110};\\\", \\\"{x:1333,y:795,t:1527876724118};\\\", \\\"{x:1336,y:791,t:1527876724130};\\\", \\\"{x:1339,y:785,t:1527876724147};\\\", \\\"{x:1348,y:777,t:1527876724163};\\\", \\\"{x:1350,y:769,t:1527876724181};\\\", \\\"{x:1351,y:764,t:1527876724197};\\\", \\\"{x:1351,y:758,t:1527876724214};\\\", \\\"{x:1354,y:757,t:1527876724445};\\\", \\\"{x:1356,y:757,t:1527876724454};\\\", \\\"{x:1359,y:756,t:1527876724464};\\\", \\\"{x:1367,y:753,t:1527876724480};\\\", \\\"{x:1374,y:749,t:1527876724498};\\\", \\\"{x:1390,y:744,t:1527876724512};\\\", \\\"{x:1404,y:740,t:1527876724529};\\\", \\\"{x:1410,y:738,t:1527876724546};\\\", \\\"{x:1414,y:736,t:1527876724563};\\\", \\\"{x:1417,y:735,t:1527876724580};\\\", \\\"{x:1425,y:735,t:1527876724597};\\\", \\\"{x:1433,y:737,t:1527876724613};\\\", \\\"{x:1446,y:743,t:1527876724630};\\\", \\\"{x:1462,y:747,t:1527876724647};\\\", \\\"{x:1479,y:751,t:1527876724663};\\\", \\\"{x:1494,y:753,t:1527876724680};\\\", \\\"{x:1497,y:754,t:1527876724697};\\\", \\\"{x:1501,y:755,t:1527876724713};\\\", \\\"{x:1502,y:756,t:1527876724731};\\\", \\\"{x:1505,y:756,t:1527876724765};\\\", \\\"{x:1508,y:756,t:1527876724780};\\\", \\\"{x:1516,y:759,t:1527876724797};\\\", \\\"{x:1523,y:759,t:1527876724815};\\\", \\\"{x:1526,y:759,t:1527876724831};\\\", \\\"{x:1528,y:759,t:1527876724848};\\\", \\\"{x:1525,y:759,t:1527876724950};\\\", \\\"{x:1523,y:760,t:1527876724964};\\\", \\\"{x:1514,y:767,t:1527876724981};\\\", \\\"{x:1499,y:780,t:1527876724998};\\\", \\\"{x:1491,y:787,t:1527876725015};\\\", \\\"{x:1487,y:792,t:1527876725031};\\\", \\\"{x:1483,y:797,t:1527876725047};\\\", \\\"{x:1482,y:798,t:1527876725064};\\\", \\\"{x:1481,y:799,t:1527876725085};\\\", \\\"{x:1481,y:800,t:1527876725134};\\\", \\\"{x:1481,y:801,t:1527876725148};\\\", \\\"{x:1481,y:803,t:1527876725165};\\\", \\\"{x:1481,y:805,t:1527876725181};\\\", \\\"{x:1479,y:809,t:1527876725198};\\\", \\\"{x:1479,y:811,t:1527876725215};\\\", \\\"{x:1479,y:815,t:1527876725230};\\\", \\\"{x:1479,y:818,t:1527876725247};\\\", \\\"{x:1478,y:821,t:1527876725264};\\\", \\\"{x:1478,y:823,t:1527876725281};\\\", \\\"{x:1478,y:826,t:1527876725298};\\\", \\\"{x:1478,y:828,t:1527876725315};\\\", \\\"{x:1475,y:828,t:1527876725590};\\\", \\\"{x:1464,y:828,t:1527876725597};\\\", \\\"{x:1435,y:828,t:1527876725614};\\\", \\\"{x:1411,y:826,t:1527876725631};\\\", \\\"{x:1346,y:826,t:1527876725647};\\\", \\\"{x:1253,y:823,t:1527876725664};\\\", \\\"{x:1139,y:803,t:1527876725681};\\\", \\\"{x:1035,y:781,t:1527876725697};\\\", \\\"{x:939,y:757,t:1527876725714};\\\", \\\"{x:865,y:739,t:1527876725731};\\\", \\\"{x:833,y:733,t:1527876725747};\\\", \\\"{x:812,y:729,t:1527876725764};\\\", \\\"{x:795,y:729,t:1527876725781};\\\", \\\"{x:781,y:730,t:1527876725797};\\\", \\\"{x:758,y:736,t:1527876725814};\\\", \\\"{x:735,y:737,t:1527876725832};\\\", \\\"{x:696,y:737,t:1527876725847};\\\", \\\"{x:632,y:737,t:1527876725864};\\\", \\\"{x:574,y:737,t:1527876725882};\\\", \\\"{x:552,y:736,t:1527876725900};\\\", \\\"{x:544,y:734,t:1527876725914};\\\", \\\"{x:542,y:734,t:1527876725931};\\\", \\\"{x:541,y:734,t:1527876725948};\\\", \\\"{x:538,y:734,t:1527876725964};\\\", \\\"{x:531,y:736,t:1527876725980};\\\", \\\"{x:525,y:737,t:1527876725998};\\\", \\\"{x:517,y:737,t:1527876726013};\\\", \\\"{x:510,y:737,t:1527876726031};\\\", \\\"{x:509,y:737,t:1527876726048};\\\", \\\"{x:513,y:737,t:1527876727253};\\\", \\\"{x:516,y:735,t:1527876727266};\\\", \\\"{x:523,y:731,t:1527876727283};\\\", \\\"{x:526,y:729,t:1527876727316};\\\", \\\"{x:536,y:721,t:1527876727332};\\\", \\\"{x:558,y:719,t:1527876727349};\\\", \\\"{x:583,y:717,t:1527876727365};\\\", \\\"{x:596,y:716,t:1527876727382};\\\", \\\"{x:596,y:715,t:1527876727693};\\\", \\\"{x:598,y:712,t:1527876727700};\\\", \\\"{x:599,y:711,t:1527876727716};\\\", \\\"{x:604,y:709,t:1527876727732};\\\", \\\"{x:605,y:709,t:1527876727749};\\\", \\\"{x:606,y:704,t:1527876727766};\\\", \\\"{x:608,y:703,t:1527876727783};\\\", \\\"{x:609,y:702,t:1527876727800};\\\", \\\"{x:611,y:700,t:1527876727821};\\\", \\\"{x:613,y:699,t:1527876727833};\\\", \\\"{x:629,y:693,t:1527876727863};\\\", \\\"{x:634,y:689,t:1527876727868};\\\", \\\"{x:635,y:689,t:1527876727882};\\\", \\\"{x:643,y:683,t:1527876727900};\\\", \\\"{x:650,y:681,t:1527876727916};\\\", \\\"{x:658,y:680,t:1527876727933};\\\" ] }, { \\\"rt\\\": 30793, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 12, \\\"time_elapsed\\\": 366779, \\\"internal_node_id\\\": \\\"0.0-6.0-2.0\\\", \\\"subject\\\": \\\"7BW1K\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+contained\\\", \\\"q\\\": 8, \\\"clicks\\\": 1, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-E -B \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:700,y:669,t:1527876728055};\\\", \\\"{x:706,y:669,t:1527876728083};\\\", \\\"{x:707,y:667,t:1527876728100};\\\", \\\"{x:708,y:667,t:1527876728515};\\\", \\\"{x:703,y:659,t:1527876728518};\\\", \\\"{x:674,y:637,t:1527876728534};\\\", \\\"{x:655,y:625,t:1527876728550};\\\", \\\"{x:626,y:610,t:1527876728567};\\\", \\\"{x:609,y:597,t:1527876728584};\\\", \\\"{x:596,y:589,t:1527876728601};\\\", \\\"{x:592,y:586,t:1527876728617};\\\", \\\"{x:590,y:584,t:1527876728634};\\\", \\\"{x:589,y:582,t:1527876728650};\\\", \\\"{x:585,y:579,t:1527876728667};\\\", \\\"{x:577,y:574,t:1527876728684};\\\", \\\"{x:573,y:570,t:1527876728700};\\\", \\\"{x:561,y:562,t:1527876728718};\\\", \\\"{x:546,y:555,t:1527876728735};\\\", \\\"{x:516,y:546,t:1527876728749};\\\", \\\"{x:490,y:535,t:1527876728768};\\\", \\\"{x:457,y:521,t:1527876728785};\\\", \\\"{x:428,y:504,t:1527876728802};\\\", \\\"{x:399,y:489,t:1527876728816};\\\", \\\"{x:381,y:477,t:1527876728835};\\\", \\\"{x:373,y:474,t:1527876728851};\\\", \\\"{x:371,y:473,t:1527876728867};\\\", \\\"{x:369,y:472,t:1527876728908};\\\", \\\"{x:365,y:472,t:1527876728917};\\\", \\\"{x:355,y:470,t:1527876728934};\\\", \\\"{x:341,y:465,t:1527876728951};\\\", \\\"{x:334,y:464,t:1527876728967};\\\", \\\"{x:328,y:461,t:1527876728984};\\\", \\\"{x:319,y:460,t:1527876729001};\\\", \\\"{x:314,y:458,t:1527876729017};\\\", \\\"{x:311,y:457,t:1527876729034};\\\", \\\"{x:308,y:456,t:1527876729052};\\\", \\\"{x:307,y:456,t:1527876729077};\\\", \\\"{x:306,y:456,t:1527876729085};\\\", \\\"{x:306,y:455,t:1527876729229};\\\", \\\"{x:306,y:453,t:1527876729253};\\\", \\\"{x:308,y:453,t:1527876729269};\\\", \\\"{x:309,y:453,t:1527876729292};\\\", \\\"{x:309,y:452,t:1527876729301};\\\", \\\"{x:310,y:452,t:1527876729325};\\\", \\\"{x:312,y:451,t:1527876729334};\\\", \\\"{x:313,y:451,t:1527876729357};\\\", \\\"{x:314,y:450,t:1527876729368};\\\", \\\"{x:315,y:450,t:1527876729413};\\\", \\\"{x:316,y:450,t:1527876729517};\\\", \\\"{x:317,y:450,t:1527876729534};\\\", \\\"{x:319,y:449,t:1527876729605};\\\", \\\"{x:320,y:449,t:1527876729838};\\\", \\\"{x:321,y:448,t:1527876729851};\\\", \\\"{x:322,y:447,t:1527876729877};\\\", \\\"{x:323,y:447,t:1527876729909};\\\", \\\"{x:324,y:447,t:1527876729919};\\\", \\\"{x:327,y:446,t:1527876729941};\\\", \\\"{x:327,y:445,t:1527876729951};\\\", \\\"{x:329,y:444,t:1527876729968};\\\", \\\"{x:332,y:443,t:1527876729986};\\\", \\\"{x:333,y:443,t:1527876730001};\\\", \\\"{x:334,y:443,t:1527876730018};\\\", \\\"{x:337,y:442,t:1527876730036};\\\", \\\"{x:338,y:442,t:1527876730052};\\\", \\\"{x:349,y:442,t:1527876730068};\\\", \\\"{x:365,y:443,t:1527876730084};\\\", \\\"{x:385,y:447,t:1527876730101};\\\", \\\"{x:403,y:451,t:1527876730118};\\\", \\\"{x:412,y:453,t:1527876730135};\\\", \\\"{x:415,y:455,t:1527876730151};\\\", \\\"{x:418,y:456,t:1527876730168};\\\", \\\"{x:420,y:457,t:1527876730185};\\\", \\\"{x:421,y:457,t:1527876730228};\\\", \\\"{x:423,y:457,t:1527876730244};\\\", \\\"{x:424,y:457,t:1527876730269};\\\", \\\"{x:425,y:457,t:1527876730285};\\\", \\\"{x:429,y:457,t:1527876730301};\\\", \\\"{x:432,y:457,t:1527876730318};\\\", \\\"{x:435,y:457,t:1527876730336};\\\", \\\"{x:437,y:457,t:1527876730353};\\\", \\\"{x:439,y:457,t:1527876730368};\\\", \\\"{x:443,y:457,t:1527876730386};\\\", \\\"{x:445,y:457,t:1527876730403};\\\", \\\"{x:446,y:457,t:1527876730419};\\\", \\\"{x:448,y:457,t:1527876730436};\\\", \\\"{x:452,y:456,t:1527876730452};\\\", \\\"{x:454,y:455,t:1527876730469};\\\", \\\"{x:460,y:454,t:1527876730485};\\\", \\\"{x:463,y:454,t:1527876730503};\\\", \\\"{x:466,y:454,t:1527876730519};\\\", \\\"{x:469,y:451,t:1527876730536};\\\", \\\"{x:472,y:451,t:1527876730552};\\\", \\\"{x:476,y:451,t:1527876730568};\\\", \\\"{x:484,y:451,t:1527876730585};\\\", \\\"{x:492,y:451,t:1527876730602};\\\", \\\"{x:500,y:451,t:1527876730618};\\\", \\\"{x:507,y:451,t:1527876730636};\\\", \\\"{x:515,y:448,t:1527876730652};\\\", \\\"{x:520,y:448,t:1527876730668};\\\", \\\"{x:526,y:448,t:1527876730685};\\\", \\\"{x:530,y:448,t:1527876730703};\\\", \\\"{x:532,y:448,t:1527876730718};\\\", \\\"{x:537,y:448,t:1527876730736};\\\", \\\"{x:541,y:448,t:1527876730753};\\\", \\\"{x:548,y:448,t:1527876730769};\\\", \\\"{x:556,y:447,t:1527876730785};\\\", \\\"{x:564,y:446,t:1527876730802};\\\", \\\"{x:569,y:446,t:1527876730820};\\\", \\\"{x:575,y:446,t:1527876730835};\\\", \\\"{x:578,y:446,t:1527876730853};\\\", \\\"{x:579,y:446,t:1527876730869};\\\", \\\"{x:580,y:446,t:1527876730901};\\\", \\\"{x:581,y:446,t:1527876730998};\\\", \\\"{x:584,y:446,t:1527876733822};\\\", \\\"{x:589,y:444,t:1527876733838};\\\", \\\"{x:592,y:443,t:1527876733855};\\\", \\\"{x:595,y:442,t:1527876733872};\\\", \\\"{x:595,y:441,t:1527876733887};\\\", \\\"{x:597,y:440,t:1527876733905};\\\", \\\"{x:602,y:441,t:1527876733965};\\\", \\\"{x:604,y:442,t:1527876733973};\\\", \\\"{x:611,y:444,t:1527876733988};\\\", \\\"{x:629,y:450,t:1527876734005};\\\", \\\"{x:643,y:452,t:1527876734021};\\\", \\\"{x:652,y:455,t:1527876734038};\\\", \\\"{x:660,y:455,t:1527876734055};\\\", \\\"{x:664,y:455,t:1527876734071};\\\", \\\"{x:667,y:455,t:1527876734088};\\\", \\\"{x:669,y:455,t:1527876734105};\\\", \\\"{x:670,y:455,t:1527876734122};\\\", \\\"{x:671,y:455,t:1527876734262};\\\", \\\"{x:672,y:455,t:1527876734277};\\\", \\\"{x:673,y:455,t:1527876734293};\\\", \\\"{x:674,y:455,t:1527876734317};\\\", \\\"{x:675,y:455,t:1527876734341};\\\", \\\"{x:676,y:455,t:1527876734357};\\\", \\\"{x:675,y:455,t:1527876735022};\\\", \\\"{x:674,y:455,t:1527876735053};\\\", \\\"{x:672,y:456,t:1527876735077};\\\", \\\"{x:672,y:457,t:1527876735088};\\\", \\\"{x:670,y:457,t:1527876735106};\\\", \\\"{x:667,y:459,t:1527876735122};\\\", \\\"{x:662,y:460,t:1527876735139};\\\", \\\"{x:660,y:461,t:1527876735156};\\\", \\\"{x:653,y:461,t:1527876735173};\\\", \\\"{x:644,y:461,t:1527876735189};\\\", \\\"{x:642,y:461,t:1527876735206};\\\", \\\"{x:627,y:460,t:1527876735222};\\\", \\\"{x:607,y:454,t:1527876735239};\\\", \\\"{x:584,y:448,t:1527876735256};\\\", \\\"{x:566,y:447,t:1527876735272};\\\", \\\"{x:544,y:443,t:1527876735289};\\\", \\\"{x:523,y:440,t:1527876735306};\\\", \\\"{x:510,y:438,t:1527876735323};\\\", \\\"{x:496,y:436,t:1527876735339};\\\", \\\"{x:490,y:436,t:1527876735356};\\\", \\\"{x:484,y:436,t:1527876735373};\\\", \\\"{x:482,y:436,t:1527876735389};\\\", \\\"{x:479,y:436,t:1527876735406};\\\", \\\"{x:472,y:436,t:1527876735423};\\\", \\\"{x:463,y:435,t:1527876735439};\\\", \\\"{x:451,y:435,t:1527876735456};\\\", \\\"{x:440,y:435,t:1527876735473};\\\", \\\"{x:427,y:435,t:1527876735489};\\\", \\\"{x:412,y:435,t:1527876735506};\\\", \\\"{x:399,y:435,t:1527876735523};\\\", \\\"{x:389,y:435,t:1527876735539};\\\", \\\"{x:377,y:438,t:1527876735556};\\\", \\\"{x:361,y:440,t:1527876735572};\\\", \\\"{x:354,y:441,t:1527876735590};\\\", \\\"{x:352,y:443,t:1527876735606};\\\", \\\"{x:350,y:443,t:1527876735622};\\\", \\\"{x:352,y:443,t:1527876735805};\\\", \\\"{x:353,y:443,t:1527876735823};\\\", \\\"{x:363,y:446,t:1527876735840};\\\", \\\"{x:383,y:449,t:1527876735856};\\\", \\\"{x:411,y:453,t:1527876735873};\\\", \\\"{x:449,y:458,t:1527876735889};\\\", \\\"{x:512,y:472,t:1527876735906};\\\", \\\"{x:568,y:480,t:1527876735923};\\\", \\\"{x:609,y:482,t:1527876735940};\\\", \\\"{x:651,y:485,t:1527876735955};\\\", \\\"{x:704,y:491,t:1527876735974};\\\", \\\"{x:736,y:495,t:1527876735990};\\\", \\\"{x:759,y:496,t:1527876736006};\\\", \\\"{x:776,y:497,t:1527876736023};\\\", \\\"{x:794,y:498,t:1527876736040};\\\", \\\"{x:812,y:500,t:1527876736056};\\\", \\\"{x:834,y:502,t:1527876736074};\\\", \\\"{x:867,y:506,t:1527876736091};\\\", \\\"{x:922,y:514,t:1527876736106};\\\", \\\"{x:967,y:518,t:1527876736123};\\\", \\\"{x:1010,y:529,t:1527876736140};\\\", \\\"{x:1028,y:532,t:1527876736156};\\\", \\\"{x:1035,y:533,t:1527876736173};\\\", \\\"{x:1038,y:533,t:1527876736191};\\\", \\\"{x:1040,y:533,t:1527876736206};\\\", \\\"{x:1043,y:533,t:1527876736223};\\\", \\\"{x:1048,y:532,t:1527876736240};\\\", \\\"{x:1053,y:532,t:1527876736256};\\\", \\\"{x:1057,y:531,t:1527876736273};\\\", \\\"{x:1062,y:527,t:1527876736291};\\\", \\\"{x:1063,y:526,t:1527876736307};\\\", \\\"{x:1065,y:524,t:1527876736323};\\\", \\\"{x:1066,y:523,t:1527876736340};\\\", \\\"{x:1068,y:521,t:1527876736357};\\\", \\\"{x:1072,y:518,t:1527876736374};\\\", \\\"{x:1080,y:514,t:1527876736391};\\\", \\\"{x:1085,y:511,t:1527876736407};\\\", \\\"{x:1086,y:509,t:1527876736424};\\\", \\\"{x:1087,y:508,t:1527876736440};\\\", \\\"{x:1089,y:506,t:1527876736477};\\\", \\\"{x:1091,y:506,t:1527876736501};\\\", \\\"{x:1092,y:506,t:1527876736525};\\\", \\\"{x:1092,y:505,t:1527876736540};\\\", \\\"{x:1092,y:504,t:1527876736629};\\\", \\\"{x:1093,y:502,t:1527876736641};\\\", \\\"{x:1094,y:502,t:1527876736661};\\\", \\\"{x:1094,y:501,t:1527876736677};\\\", \\\"{x:1094,y:503,t:1527876737045};\\\", \\\"{x:1094,y:505,t:1527876737058};\\\", \\\"{x:1094,y:509,t:1527876737075};\\\", \\\"{x:1094,y:514,t:1527876737091};\\\", \\\"{x:1094,y:522,t:1527876737107};\\\", \\\"{x:1096,y:537,t:1527876737125};\\\", \\\"{x:1097,y:544,t:1527876737141};\\\", \\\"{x:1098,y:551,t:1527876737158};\\\", \\\"{x:1098,y:555,t:1527876737175};\\\", \\\"{x:1099,y:559,t:1527876737191};\\\", \\\"{x:1099,y:560,t:1527876737208};\\\", \\\"{x:1100,y:560,t:1527876737225};\\\", \\\"{x:1100,y:561,t:1527876737241};\\\", \\\"{x:1100,y:562,t:1527876738557};\\\", \\\"{x:1102,y:562,t:1527876738573};\\\", \\\"{x:1104,y:562,t:1527876738589};\\\", \\\"{x:1104,y:561,t:1527876738613};\\\", \\\"{x:1105,y:561,t:1527876738626};\\\", \\\"{x:1106,y:561,t:1527876738678};\\\", \\\"{x:1107,y:561,t:1527876738725};\\\", \\\"{x:1107,y:560,t:1527876739206};\\\", \\\"{x:1107,y:559,t:1527876739501};\\\", \\\"{x:1108,y:557,t:1527876742437};\\\", \\\"{x:1110,y:555,t:1527876742445};\\\", \\\"{x:1113,y:555,t:1527876742469};\\\", \\\"{x:1123,y:555,t:1527876742480};\\\", \\\"{x:1138,y:554,t:1527876742495};\\\", \\\"{x:1153,y:554,t:1527876742512};\\\", \\\"{x:1184,y:554,t:1527876742529};\\\", \\\"{x:1220,y:554,t:1527876742545};\\\", \\\"{x:1244,y:551,t:1527876742562};\\\", \\\"{x:1261,y:549,t:1527876742579};\\\", \\\"{x:1268,y:548,t:1527876742595};\\\", \\\"{x:1269,y:548,t:1527876742637};\\\", \\\"{x:1271,y:548,t:1527876742653};\\\", \\\"{x:1272,y:548,t:1527876742677};\\\", \\\"{x:1273,y:547,t:1527876742685};\\\", \\\"{x:1274,y:547,t:1527876742701};\\\", \\\"{x:1276,y:547,t:1527876742725};\\\", \\\"{x:1278,y:547,t:1527876742741};\\\", \\\"{x:1280,y:546,t:1527876742749};\\\", \\\"{x:1281,y:546,t:1527876742762};\\\", \\\"{x:1285,y:546,t:1527876742780};\\\", \\\"{x:1291,y:546,t:1527876742796};\\\", \\\"{x:1295,y:546,t:1527876742812};\\\", \\\"{x:1298,y:546,t:1527876742830};\\\", \\\"{x:1302,y:547,t:1527876742847};\\\", \\\"{x:1308,y:548,t:1527876742862};\\\", \\\"{x:1314,y:550,t:1527876742879};\\\", \\\"{x:1318,y:551,t:1527876742896};\\\", \\\"{x:1322,y:552,t:1527876742912};\\\", \\\"{x:1325,y:554,t:1527876742929};\\\", \\\"{x:1327,y:556,t:1527876742949};\\\", \\\"{x:1327,y:558,t:1527876742962};\\\", \\\"{x:1330,y:565,t:1527876742979};\\\", \\\"{x:1332,y:570,t:1527876742996};\\\", \\\"{x:1333,y:573,t:1527876743012};\\\", \\\"{x:1333,y:584,t:1527876743029};\\\", \\\"{x:1333,y:592,t:1527876743047};\\\", \\\"{x:1332,y:604,t:1527876743063};\\\", \\\"{x:1332,y:613,t:1527876743079};\\\", \\\"{x:1330,y:626,t:1527876743096};\\\", \\\"{x:1330,y:636,t:1527876743113};\\\", \\\"{x:1330,y:644,t:1527876743129};\\\", \\\"{x:1330,y:649,t:1527876743146};\\\", \\\"{x:1330,y:652,t:1527876743162};\\\", \\\"{x:1329,y:657,t:1527876743179};\\\", \\\"{x:1329,y:667,t:1527876743196};\\\", \\\"{x:1329,y:671,t:1527876743213};\\\", \\\"{x:1330,y:686,t:1527876743229};\\\", \\\"{x:1331,y:699,t:1527876743246};\\\", \\\"{x:1334,y:715,t:1527876743264};\\\", \\\"{x:1336,y:732,t:1527876743279};\\\", \\\"{x:1339,y:752,t:1527876743297};\\\", \\\"{x:1341,y:767,t:1527876743313};\\\", \\\"{x:1343,y:777,t:1527876743329};\\\", \\\"{x:1347,y:788,t:1527876743346};\\\", \\\"{x:1349,y:792,t:1527876743364};\\\", \\\"{x:1352,y:795,t:1527876743378};\\\", \\\"{x:1354,y:795,t:1527876743396};\\\", \\\"{x:1358,y:795,t:1527876743412};\\\", \\\"{x:1361,y:795,t:1527876743429};\\\", \\\"{x:1363,y:794,t:1527876743445};\\\", \\\"{x:1363,y:792,t:1527876743463};\\\", \\\"{x:1367,y:787,t:1527876743479};\\\", \\\"{x:1367,y:780,t:1527876743495};\\\", \\\"{x:1367,y:772,t:1527876743513};\\\", \\\"{x:1366,y:762,t:1527876743529};\\\", \\\"{x:1364,y:756,t:1527876743545};\\\", \\\"{x:1362,y:752,t:1527876743563};\\\", \\\"{x:1361,y:752,t:1527876743710};\\\", \\\"{x:1358,y:752,t:1527876743717};\\\", \\\"{x:1357,y:754,t:1527876743731};\\\", \\\"{x:1355,y:754,t:1527876743746};\\\", \\\"{x:1352,y:756,t:1527876743763};\\\", \\\"{x:1352,y:757,t:1527876743780};\\\", \\\"{x:1351,y:757,t:1527876744045};\\\", \\\"{x:1351,y:758,t:1527876744053};\\\", \\\"{x:1349,y:759,t:1527876744071};\\\", \\\"{x:1348,y:760,t:1527876744213};\\\", \\\"{x:1348,y:762,t:1527876744277};\\\", \\\"{x:1347,y:762,t:1527876750573};\\\", \\\"{x:1344,y:762,t:1527876755905};\\\", \\\"{x:1323,y:762,t:1527876755913};\\\", \\\"{x:1300,y:760,t:1527876755927};\\\", \\\"{x:1204,y:743,t:1527876755944};\\\", \\\"{x:1055,y:719,t:1527876755960};\\\", \\\"{x:983,y:698,t:1527876755976};\\\", \\\"{x:936,y:686,t:1527876755994};\\\", \\\"{x:907,y:676,t:1527876756010};\\\", \\\"{x:880,y:670,t:1527876756026};\\\", \\\"{x:864,y:662,t:1527876756043};\\\", \\\"{x:857,y:659,t:1527876756061};\\\", \\\"{x:853,y:659,t:1527876756077};\\\", \\\"{x:848,y:659,t:1527876756092};\\\", \\\"{x:847,y:659,t:1527876756110};\\\", \\\"{x:834,y:659,t:1527876756126};\\\", \\\"{x:811,y:659,t:1527876756143};\\\", \\\"{x:787,y:659,t:1527876756160};\\\", \\\"{x:764,y:653,t:1527876756175};\\\", \\\"{x:744,y:648,t:1527876756192};\\\", \\\"{x:726,y:642,t:1527876756210};\\\", \\\"{x:710,y:634,t:1527876756226};\\\", \\\"{x:699,y:628,t:1527876756244};\\\", \\\"{x:692,y:623,t:1527876756260};\\\", \\\"{x:687,y:618,t:1527876756275};\\\", \\\"{x:686,y:615,t:1527876756292};\\\", \\\"{x:684,y:611,t:1527876756310};\\\", \\\"{x:683,y:608,t:1527876756327};\\\", \\\"{x:683,y:603,t:1527876756344};\\\", \\\"{x:683,y:597,t:1527876756359};\\\", \\\"{x:683,y:593,t:1527876756377};\\\", \\\"{x:681,y:587,t:1527876756393};\\\", \\\"{x:679,y:583,t:1527876756410};\\\", \\\"{x:676,y:574,t:1527876756426};\\\", \\\"{x:673,y:568,t:1527876756442};\\\", \\\"{x:665,y:561,t:1527876756460};\\\", \\\"{x:646,y:545,t:1527876756477};\\\", \\\"{x:618,y:535,t:1527876756494};\\\", \\\"{x:568,y:521,t:1527876756510};\\\", \\\"{x:531,y:508,t:1527876756527};\\\", \\\"{x:494,y:497,t:1527876756544};\\\", \\\"{x:483,y:494,t:1527876756560};\\\", \\\"{x:478,y:492,t:1527876756577};\\\", \\\"{x:474,y:492,t:1527876756594};\\\", \\\"{x:469,y:492,t:1527876756610};\\\", \\\"{x:459,y:492,t:1527876756627};\\\", \\\"{x:449,y:493,t:1527876756644};\\\", \\\"{x:434,y:495,t:1527876756660};\\\", \\\"{x:424,y:499,t:1527876756677};\\\", \\\"{x:416,y:499,t:1527876756694};\\\", \\\"{x:413,y:501,t:1527876756709};\\\", \\\"{x:420,y:501,t:1527876756744};\\\", \\\"{x:450,y:501,t:1527876756759};\\\", \\\"{x:521,y:498,t:1527876756779};\\\", \\\"{x:609,y:489,t:1527876756793};\\\", \\\"{x:704,y:489,t:1527876756810};\\\", \\\"{x:784,y:489,t:1527876756827};\\\", \\\"{x:819,y:493,t:1527876756843};\\\", \\\"{x:832,y:495,t:1527876756861};\\\", \\\"{x:833,y:495,t:1527876756876};\\\", \\\"{x:834,y:495,t:1527876756911};\\\", \\\"{x:840,y:496,t:1527876756926};\\\", \\\"{x:871,y:503,t:1527876756944};\\\", \\\"{x:894,y:506,t:1527876756961};\\\", \\\"{x:897,y:508,t:1527876756976};\\\", \\\"{x:900,y:508,t:1527876756994};\\\", \\\"{x:901,y:510,t:1527876757040};\\\", \\\"{x:900,y:515,t:1527876757048};\\\", \\\"{x:897,y:519,t:1527876757062};\\\", \\\"{x:882,y:530,t:1527876757077};\\\", \\\"{x:860,y:542,t:1527876757094};\\\", \\\"{x:850,y:548,t:1527876757110};\\\", \\\"{x:838,y:554,t:1527876757127};\\\", \\\"{x:830,y:560,t:1527876757144};\\\", \\\"{x:828,y:561,t:1527876757160};\\\", \\\"{x:828,y:560,t:1527876757352};\\\", \\\"{x:828,y:557,t:1527876757361};\\\", \\\"{x:832,y:551,t:1527876757378};\\\", \\\"{x:833,y:548,t:1527876757394};\\\", \\\"{x:835,y:546,t:1527876757411};\\\", \\\"{x:829,y:546,t:1527876758111};\\\", \\\"{x:787,y:554,t:1527876758127};\\\", \\\"{x:751,y:565,t:1527876758146};\\\", \\\"{x:700,y:573,t:1527876758162};\\\", \\\"{x:668,y:579,t:1527876758177};\\\", \\\"{x:652,y:584,t:1527876758194};\\\", \\\"{x:641,y:590,t:1527876758211};\\\", \\\"{x:636,y:594,t:1527876758228};\\\", \\\"{x:622,y:605,t:1527876758246};\\\", \\\"{x:597,y:627,t:1527876758262};\\\", \\\"{x:572,y:644,t:1527876758278};\\\", \\\"{x:537,y:662,t:1527876758295};\\\", \\\"{x:537,y:667,t:1527876758311};\\\", \\\"{x:534,y:672,t:1527876758328};\\\", \\\"{x:534,y:673,t:1527876758345};\\\", \\\"{x:535,y:683,t:1527876758362};\\\", \\\"{x:537,y:684,t:1527876758379};\\\", \\\"{x:538,y:685,t:1527876758395};\\\", \\\"{x:541,y:688,t:1527876758412};\\\", \\\"{x:543,y:689,t:1527876758428};\\\", \\\"{x:543,y:690,t:1527876758445};\\\", \\\"{x:546,y:692,t:1527876758462};\\\", \\\"{x:548,y:696,t:1527876758479};\\\", \\\"{x:549,y:700,t:1527876758495};\\\", \\\"{x:549,y:708,t:1527876758511};\\\", \\\"{x:549,y:713,t:1527876758529};\\\", \\\"{x:547,y:720,t:1527876758546};\\\", \\\"{x:543,y:725,t:1527876758562};\\\", \\\"{x:542,y:729,t:1527876758578};\\\", \\\"{x:539,y:732,t:1527876758595};\\\", \\\"{x:538,y:735,t:1527876758612};\\\", \\\"{x:536,y:739,t:1527876758628};\\\", \\\"{x:535,y:740,t:1527876758645};\\\", \\\"{x:534,y:740,t:1527876758663};\\\", \\\"{x:534,y:741,t:1527876758688};\\\", \\\"{x:533,y:742,t:1527876758712};\\\", \\\"{x:533,y:743,t:1527876758729};\\\", \\\"{x:536,y:740,t:1527876759176};\\\", \\\"{x:541,y:739,t:1527876759184};\\\", \\\"{x:545,y:735,t:1527876759196};\\\", \\\"{x:551,y:731,t:1527876759212};\\\", \\\"{x:562,y:723,t:1527876759228};\\\", \\\"{x:576,y:714,t:1527876759245};\\\", \\\"{x:594,y:703,t:1527876759262};\\\", \\\"{x:609,y:688,t:1527876759279};\\\", \\\"{x:673,y:647,t:1527876759295};\\\", \\\"{x:715,y:619,t:1527876759312};\\\", \\\"{x:743,y:599,t:1527876759329};\\\", \\\"{x:780,y:574,t:1527876759346};\\\", \\\"{x:790,y:565,t:1527876759361};\\\", \\\"{x:790,y:564,t:1527876759904};\\\", \\\"{x:789,y:563,t:1527876759913};\\\", \\\"{x:788,y:562,t:1527876759929};\\\", \\\"{x:787,y:561,t:1527876759945};\\\" ] }, { \\\"rt\\\": 37732, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 13, \\\"time_elapsed\\\": 405739, \\\"internal_node_id\\\": \\\"0.0-6.0-3.0\\\", \\\"subject\\\": \\\"7BW1K\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime+before+endtime+during\\\", \\\"q\\\": 9, \\\"clicks\\\": 1, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"I\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F -J -I -I -B -B -F -F -J -I -B -B -B -I -I \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:783,y:561,t:1527876760496};\\\", \\\"{x:759,y:556,t:1527876760513};\\\", \\\"{x:721,y:542,t:1527876760530};\\\", \\\"{x:674,y:521,t:1527876760548};\\\", \\\"{x:598,y:492,t:1527876760564};\\\", \\\"{x:540,y:468,t:1527876760580};\\\", \\\"{x:503,y:446,t:1527876760597};\\\", \\\"{x:485,y:434,t:1527876760613};\\\", \\\"{x:460,y:427,t:1527876760695};\\\", \\\"{x:458,y:427,t:1527876760735};\\\", \\\"{x:457,y:427,t:1527876760751};\\\", \\\"{x:455,y:427,t:1527876760767};\\\", \\\"{x:454,y:427,t:1527876760780};\\\", \\\"{x:450,y:429,t:1527876760796};\\\", \\\"{x:447,y:433,t:1527876760812};\\\", \\\"{x:441,y:440,t:1527876760829};\\\", \\\"{x:437,y:447,t:1527876760846};\\\", \\\"{x:435,y:452,t:1527876760863};\\\", \\\"{x:433,y:453,t:1527876760880};\\\", \\\"{x:433,y:454,t:1527876760936};\\\", \\\"{x:433,y:455,t:1527876760984};\\\", \\\"{x:433,y:457,t:1527876760997};\\\", \\\"{x:433,y:463,t:1527876761013};\\\", \\\"{x:433,y:465,t:1527876761029};\\\", \\\"{x:434,y:465,t:1527876761601};\\\", \\\"{x:435,y:465,t:1527876761616};\\\", \\\"{x:436,y:465,t:1527876761629};\\\", \\\"{x:437,y:464,t:1527876761646};\\\", \\\"{x:440,y:463,t:1527876761662};\\\", \\\"{x:443,y:463,t:1527876761679};\\\", \\\"{x:446,y:461,t:1527876761695};\\\", \\\"{x:452,y:460,t:1527876761713};\\\", \\\"{x:458,y:459,t:1527876761729};\\\", \\\"{x:459,y:459,t:1527876761746};\\\", \\\"{x:463,y:459,t:1527876761762};\\\", \\\"{x:465,y:457,t:1527876761779};\\\", \\\"{x:467,y:457,t:1527876761795};\\\", \\\"{x:469,y:456,t:1527876761813};\\\", \\\"{x:471,y:456,t:1527876761828};\\\", \\\"{x:472,y:456,t:1527876761848};\\\", \\\"{x:474,y:456,t:1527876761889};\\\", \\\"{x:475,y:455,t:1527876762049};\\\", \\\"{x:476,y:455,t:1527876762062};\\\", \\\"{x:477,y:455,t:1527876762088};\\\", \\\"{x:479,y:455,t:1527876762096};\\\", \\\"{x:481,y:455,t:1527876762112};\\\", \\\"{x:482,y:455,t:1527876762136};\\\", \\\"{x:483,y:455,t:1527876762152};\\\", \\\"{x:484,y:455,t:1527876762162};\\\", \\\"{x:485,y:455,t:1527876762179};\\\", \\\"{x:488,y:455,t:1527876762196};\\\", \\\"{x:492,y:455,t:1527876762212};\\\", \\\"{x:494,y:455,t:1527876762228};\\\", \\\"{x:496,y:455,t:1527876762246};\\\", \\\"{x:500,y:455,t:1527876762262};\\\", \\\"{x:504,y:455,t:1527876762279};\\\", \\\"{x:518,y:455,t:1527876762295};\\\", \\\"{x:532,y:455,t:1527876762312};\\\", \\\"{x:556,y:455,t:1527876762328};\\\", \\\"{x:562,y:455,t:1527876762345};\\\", \\\"{x:564,y:455,t:1527876762361};\\\", \\\"{x:565,y:455,t:1527876762416};\\\", \\\"{x:566,y:455,t:1527876762428};\\\", \\\"{x:567,y:455,t:1527876762473};\\\", \\\"{x:568,y:455,t:1527876762496};\\\", \\\"{x:569,y:455,t:1527876762528};\\\", \\\"{x:570,y:455,t:1527876762560};\\\", \\\"{x:571,y:455,t:1527876762578};\\\", \\\"{x:572,y:455,t:1527876762594};\\\", \\\"{x:575,y:455,t:1527876762612};\\\", \\\"{x:577,y:455,t:1527876762632};\\\", \\\"{x:579,y:455,t:1527876762645};\\\", \\\"{x:585,y:456,t:1527876762661};\\\", \\\"{x:589,y:457,t:1527876762679};\\\", \\\"{x:601,y:459,t:1527876762695};\\\", \\\"{x:614,y:459,t:1527876762711};\\\", \\\"{x:631,y:459,t:1527876762728};\\\", \\\"{x:640,y:461,t:1527876762744};\\\", \\\"{x:642,y:462,t:1527876762762};\\\", \\\"{x:643,y:462,t:1527876762913};\\\", \\\"{x:643,y:463,t:1527876763065};\\\", \\\"{x:647,y:463,t:1527876763455};\\\", \\\"{x:655,y:463,t:1527876763463};\\\", \\\"{x:667,y:463,t:1527876763476};\\\", \\\"{x:686,y:463,t:1527876763493};\\\", \\\"{x:711,y:464,t:1527876763510};\\\", \\\"{x:761,y:460,t:1527876763526};\\\", \\\"{x:811,y:460,t:1527876763543};\\\", \\\"{x:870,y:460,t:1527876763559};\\\", \\\"{x:913,y:460,t:1527876763576};\\\", \\\"{x:939,y:461,t:1527876763593};\\\", \\\"{x:977,y:462,t:1527876763609};\\\", \\\"{x:1000,y:464,t:1527876763627};\\\", \\\"{x:1037,y:469,t:1527876763644};\\\", \\\"{x:1065,y:469,t:1527876763659};\\\", \\\"{x:1094,y:473,t:1527876763677};\\\", \\\"{x:1117,y:476,t:1527876763694};\\\", \\\"{x:1137,y:483,t:1527876763709};\\\", \\\"{x:1152,y:486,t:1527876763726};\\\", \\\"{x:1163,y:490,t:1527876763744};\\\", \\\"{x:1178,y:496,t:1527876763759};\\\", \\\"{x:1209,y:505,t:1527876763776};\\\", \\\"{x:1222,y:513,t:1527876763793};\\\", \\\"{x:1246,y:525,t:1527876763810};\\\", \\\"{x:1265,y:540,t:1527876763826};\\\", \\\"{x:1284,y:552,t:1527876763844};\\\", \\\"{x:1301,y:561,t:1527876763860};\\\", \\\"{x:1308,y:566,t:1527876763877};\\\", \\\"{x:1311,y:570,t:1527876763892};\\\", \\\"{x:1313,y:571,t:1527876763910};\\\", \\\"{x:1314,y:572,t:1527876763927};\\\", \\\"{x:1315,y:575,t:1527876764065};\\\", \\\"{x:1316,y:578,t:1527876764076};\\\", \\\"{x:1318,y:583,t:1527876764092};\\\", \\\"{x:1320,y:586,t:1527876764110};\\\", \\\"{x:1320,y:591,t:1527876764126};\\\", \\\"{x:1323,y:594,t:1527876764143};\\\", \\\"{x:1326,y:601,t:1527876764160};\\\", \\\"{x:1328,y:603,t:1527876764185};\\\", \\\"{x:1329,y:606,t:1527876764193};\\\", \\\"{x:1333,y:609,t:1527876764210};\\\", \\\"{x:1338,y:612,t:1527876764225};\\\", \\\"{x:1340,y:614,t:1527876764243};\\\", \\\"{x:1342,y:616,t:1527876764260};\\\", \\\"{x:1343,y:618,t:1527876764275};\\\", \\\"{x:1344,y:619,t:1527876764293};\\\", \\\"{x:1347,y:622,t:1527876764309};\\\", \\\"{x:1349,y:624,t:1527876764326};\\\", \\\"{x:1351,y:629,t:1527876764343};\\\", \\\"{x:1351,y:633,t:1527876764360};\\\", \\\"{x:1352,y:638,t:1527876764376};\\\", \\\"{x:1352,y:648,t:1527876764392};\\\", \\\"{x:1352,y:653,t:1527876764408};\\\", \\\"{x:1352,y:660,t:1527876764426};\\\", \\\"{x:1350,y:666,t:1527876764443};\\\", \\\"{x:1348,y:670,t:1527876764458};\\\", \\\"{x:1343,y:678,t:1527876764476};\\\", \\\"{x:1338,y:684,t:1527876764493};\\\", \\\"{x:1334,y:689,t:1527876764509};\\\", \\\"{x:1325,y:697,t:1527876764526};\\\", \\\"{x:1316,y:703,t:1527876764542};\\\", \\\"{x:1307,y:710,t:1527876764558};\\\", \\\"{x:1295,y:722,t:1527876764576};\\\", \\\"{x:1287,y:728,t:1527876764592};\\\", \\\"{x:1281,y:733,t:1527876764609};\\\", \\\"{x:1275,y:738,t:1527876764625};\\\", \\\"{x:1270,y:742,t:1527876764642};\\\", \\\"{x:1265,y:749,t:1527876764658};\\\", \\\"{x:1257,y:758,t:1527876764676};\\\", \\\"{x:1250,y:764,t:1527876764691};\\\", \\\"{x:1244,y:768,t:1527876764708};\\\", \\\"{x:1241,y:770,t:1527876764725};\\\", \\\"{x:1239,y:771,t:1527876764742};\\\", \\\"{x:1239,y:772,t:1527876764759};\\\", \\\"{x:1238,y:772,t:1527876764776};\\\", \\\"{x:1238,y:773,t:1527876764792};\\\", \\\"{x:1237,y:773,t:1527876764808};\\\", \\\"{x:1236,y:774,t:1527876764826};\\\", \\\"{x:1235,y:775,t:1527876764897};\\\", \\\"{x:1234,y:775,t:1527876764993};\\\", \\\"{x:1233,y:775,t:1527876765032};\\\", \\\"{x:1232,y:775,t:1527876765137};\\\", \\\"{x:1231,y:777,t:1527876765577};\\\", \\\"{x:1230,y:777,t:1527876765592};\\\", \\\"{x:1228,y:778,t:1527876765608};\\\", \\\"{x:1228,y:785,t:1527876765624};\\\", \\\"{x:1228,y:792,t:1527876765640};\\\", \\\"{x:1228,y:795,t:1527876765664};\\\", \\\"{x:1228,y:798,t:1527876765675};\\\", \\\"{x:1228,y:802,t:1527876765691};\\\", \\\"{x:1228,y:807,t:1527876765707};\\\", \\\"{x:1228,y:810,t:1527876765723};\\\", \\\"{x:1228,y:815,t:1527876765740};\\\", \\\"{x:1228,y:816,t:1527876765758};\\\", \\\"{x:1227,y:818,t:1527876765774};\\\", \\\"{x:1227,y:819,t:1527876765790};\\\", \\\"{x:1226,y:821,t:1527876765807};\\\", \\\"{x:1226,y:823,t:1527876765824};\\\", \\\"{x:1225,y:824,t:1527876765841};\\\", \\\"{x:1224,y:826,t:1527876765872};\\\", \\\"{x:1224,y:827,t:1527876765896};\\\", \\\"{x:1224,y:829,t:1527876765929};\\\", \\\"{x:1223,y:829,t:1527876765941};\\\", \\\"{x:1221,y:829,t:1527876766033};\\\", \\\"{x:1218,y:829,t:1527876766042};\\\", \\\"{x:1217,y:829,t:1527876766056};\\\", \\\"{x:1213,y:829,t:1527876766073};\\\", \\\"{x:1212,y:828,t:1527876766090};\\\", \\\"{x:1209,y:824,t:1527876766107};\\\", \\\"{x:1206,y:821,t:1527876766123};\\\", \\\"{x:1205,y:814,t:1527876766140};\\\", \\\"{x:1205,y:806,t:1527876766156};\\\", \\\"{x:1205,y:797,t:1527876766173};\\\", \\\"{x:1204,y:793,t:1527876766190};\\\", \\\"{x:1203,y:791,t:1527876766206};\\\", \\\"{x:1202,y:789,t:1527876766223};\\\", \\\"{x:1200,y:787,t:1527876766240};\\\", \\\"{x:1200,y:786,t:1527876766264};\\\", \\\"{x:1199,y:784,t:1527876766274};\\\", \\\"{x:1198,y:783,t:1527876766289};\\\", \\\"{x:1197,y:782,t:1527876766307};\\\", \\\"{x:1197,y:781,t:1527876766324};\\\", \\\"{x:1193,y:781,t:1527876766340};\\\", \\\"{x:1191,y:781,t:1527876766357};\\\", \\\"{x:1189,y:781,t:1527876766374};\\\", \\\"{x:1188,y:781,t:1527876766392};\\\", \\\"{x:1188,y:780,t:1527876766569};\\\", \\\"{x:1187,y:778,t:1527876766576};\\\", \\\"{x:1186,y:778,t:1527876766590};\\\", \\\"{x:1186,y:775,t:1527876766607};\\\", \\\"{x:1184,y:773,t:1527876766623};\\\", \\\"{x:1183,y:771,t:1527876766640};\\\", \\\"{x:1179,y:768,t:1527876766657};\\\", \\\"{x:1178,y:767,t:1527876766689};\\\", \\\"{x:1177,y:767,t:1527876766737};\\\", \\\"{x:1176,y:767,t:1527876766777};\\\", \\\"{x:1177,y:767,t:1527876770697};\\\", \\\"{x:1182,y:766,t:1527876770718};\\\", \\\"{x:1183,y:766,t:1527876770734};\\\", \\\"{x:1185,y:766,t:1527876770751};\\\", \\\"{x:1187,y:766,t:1527876770769};\\\", \\\"{x:1188,y:766,t:1527876770800};\\\", \\\"{x:1188,y:765,t:1527876770818};\\\", \\\"{x:1190,y:764,t:1527876770835};\\\", \\\"{x:1191,y:764,t:1527876770851};\\\", \\\"{x:1194,y:762,t:1527876770868};\\\", \\\"{x:1195,y:761,t:1527876770883};\\\", \\\"{x:1195,y:760,t:1527876770912};\\\", \\\"{x:1196,y:760,t:1527876771121};\\\", \\\"{x:1197,y:760,t:1527876771169};\\\", \\\"{x:1200,y:760,t:1527876771249};\\\", \\\"{x:1204,y:760,t:1527876771256};\\\", \\\"{x:1210,y:759,t:1527876771267};\\\", \\\"{x:1215,y:757,t:1527876771284};\\\", \\\"{x:1227,y:756,t:1527876771301};\\\", \\\"{x:1239,y:756,t:1527876771317};\\\", \\\"{x:1245,y:756,t:1527876771334};\\\", \\\"{x:1255,y:756,t:1527876771351};\\\", \\\"{x:1269,y:758,t:1527876771366};\\\", \\\"{x:1284,y:759,t:1527876771383};\\\", \\\"{x:1291,y:760,t:1527876771401};\\\", \\\"{x:1297,y:763,t:1527876771416};\\\", \\\"{x:1302,y:764,t:1527876771433};\\\", \\\"{x:1306,y:765,t:1527876771449};\\\", \\\"{x:1310,y:765,t:1527876771467};\\\", \\\"{x:1315,y:766,t:1527876771483};\\\", \\\"{x:1321,y:768,t:1527876771500};\\\", \\\"{x:1325,y:770,t:1527876771516};\\\", \\\"{x:1328,y:770,t:1527876771533};\\\", \\\"{x:1332,y:770,t:1527876771549};\\\", \\\"{x:1332,y:771,t:1527876771567};\\\", \\\"{x:1333,y:771,t:1527876771583};\\\", \\\"{x:1334,y:771,t:1527876771600};\\\", \\\"{x:1335,y:771,t:1527876771648};\\\", \\\"{x:1336,y:771,t:1527876771776};\\\", \\\"{x:1337,y:770,t:1527876771784};\\\", \\\"{x:1339,y:770,t:1527876771800};\\\", \\\"{x:1343,y:769,t:1527876771816};\\\", \\\"{x:1344,y:768,t:1527876771833};\\\", \\\"{x:1345,y:768,t:1527876771850};\\\", \\\"{x:1346,y:767,t:1527876771867};\\\", \\\"{x:1347,y:766,t:1527876771888};\\\", \\\"{x:1348,y:766,t:1527876771900};\\\", \\\"{x:1349,y:766,t:1527876771916};\\\", \\\"{x:1351,y:766,t:1527876771936};\\\", \\\"{x:1351,y:764,t:1527876773321};\\\", \\\"{x:1350,y:763,t:1527876773385};\\\", \\\"{x:1349,y:763,t:1527876778136};\\\", \\\"{x:1346,y:763,t:1527876779312};\\\", \\\"{x:1345,y:763,t:1527876779324};\\\", \\\"{x:1342,y:764,t:1527876779340};\\\", \\\"{x:1338,y:766,t:1527876779358};\\\", \\\"{x:1337,y:766,t:1527876779377};\\\", \\\"{x:1335,y:767,t:1527876779391};\\\", \\\"{x:1333,y:772,t:1527876779408};\\\", \\\"{x:1331,y:779,t:1527876779424};\\\", \\\"{x:1327,y:786,t:1527876779440};\\\", \\\"{x:1324,y:799,t:1527876779456};\\\", \\\"{x:1319,y:809,t:1527876779474};\\\", \\\"{x:1317,y:825,t:1527876779490};\\\", \\\"{x:1315,y:840,t:1527876779506};\\\", \\\"{x:1312,y:852,t:1527876779523};\\\", \\\"{x:1306,y:861,t:1527876779540};\\\", \\\"{x:1305,y:866,t:1527876779556};\\\", \\\"{x:1303,y:871,t:1527876779572};\\\", \\\"{x:1300,y:879,t:1527876779590};\\\", \\\"{x:1299,y:885,t:1527876779607};\\\", \\\"{x:1295,y:893,t:1527876779622};\\\", \\\"{x:1289,y:903,t:1527876779639};\\\", \\\"{x:1285,y:912,t:1527876779657};\\\", \\\"{x:1281,y:923,t:1527876779673};\\\", \\\"{x:1275,y:935,t:1527876779690};\\\", \\\"{x:1268,y:949,t:1527876779707};\\\", \\\"{x:1264,y:958,t:1527876779723};\\\", \\\"{x:1255,y:969,t:1527876779740};\\\", \\\"{x:1253,y:976,t:1527876779755};\\\", \\\"{x:1250,y:980,t:1527876779772};\\\", \\\"{x:1248,y:983,t:1527876779790};\\\", \\\"{x:1247,y:985,t:1527876779806};\\\", \\\"{x:1246,y:986,t:1527876779823};\\\", \\\"{x:1245,y:988,t:1527876779839};\\\", \\\"{x:1245,y:989,t:1527876779855};\\\", \\\"{x:1244,y:989,t:1527876779960};\\\", \\\"{x:1243,y:988,t:1527876779976};\\\", \\\"{x:1243,y:987,t:1527876779990};\\\", \\\"{x:1243,y:986,t:1527876780006};\\\", \\\"{x:1243,y:984,t:1527876780022};\\\", \\\"{x:1243,y:983,t:1527876780079};\\\", \\\"{x:1243,y:982,t:1527876780175};\\\", \\\"{x:1243,y:981,t:1527876780208};\\\", \\\"{x:1243,y:980,t:1527876780240};\\\", \\\"{x:1243,y:977,t:1527876780256};\\\", \\\"{x:1243,y:974,t:1527876780273};\\\", \\\"{x:1243,y:967,t:1527876780289};\\\", \\\"{x:1243,y:962,t:1527876780306};\\\", \\\"{x:1243,y:953,t:1527876780322};\\\", \\\"{x:1243,y:951,t:1527876780339};\\\", \\\"{x:1245,y:940,t:1527876780356};\\\", \\\"{x:1251,y:925,t:1527876780372};\\\", \\\"{x:1256,y:911,t:1527876780389};\\\", \\\"{x:1256,y:906,t:1527876780406};\\\", \\\"{x:1261,y:896,t:1527876780422};\\\", \\\"{x:1265,y:883,t:1527876780439};\\\", \\\"{x:1270,y:874,t:1527876780455};\\\", \\\"{x:1276,y:862,t:1527876780472};\\\", \\\"{x:1282,y:853,t:1527876780489};\\\", \\\"{x:1287,y:844,t:1527876780505};\\\", \\\"{x:1294,y:836,t:1527876780522};\\\", \\\"{x:1296,y:831,t:1527876780539};\\\", \\\"{x:1302,y:823,t:1527876780556};\\\", \\\"{x:1307,y:816,t:1527876780572};\\\", \\\"{x:1312,y:811,t:1527876780589};\\\", \\\"{x:1317,y:805,t:1527876780606};\\\", \\\"{x:1320,y:802,t:1527876780622};\\\", \\\"{x:1321,y:801,t:1527876780639};\\\", \\\"{x:1322,y:799,t:1527876780656};\\\", \\\"{x:1323,y:799,t:1527876780680};\\\", \\\"{x:1323,y:798,t:1527876780689};\\\", \\\"{x:1325,y:796,t:1527876780705};\\\", \\\"{x:1326,y:794,t:1527876780723};\\\", \\\"{x:1327,y:792,t:1527876780739};\\\", \\\"{x:1328,y:792,t:1527876780755};\\\", \\\"{x:1329,y:790,t:1527876780772};\\\", \\\"{x:1329,y:787,t:1527876780788};\\\", \\\"{x:1331,y:785,t:1527876780806};\\\", \\\"{x:1331,y:784,t:1527876780822};\\\", \\\"{x:1333,y:780,t:1527876780838};\\\", \\\"{x:1335,y:777,t:1527876780856};\\\", \\\"{x:1336,y:773,t:1527876780873};\\\", \\\"{x:1336,y:771,t:1527876780888};\\\", \\\"{x:1336,y:770,t:1527876780905};\\\", \\\"{x:1337,y:769,t:1527876780923};\\\", \\\"{x:1337,y:768,t:1527876780939};\\\", \\\"{x:1337,y:767,t:1527876781016};\\\", \\\"{x:1338,y:767,t:1527876781024};\\\", \\\"{x:1339,y:766,t:1527876781088};\\\", \\\"{x:1341,y:756,t:1527876781840};\\\", \\\"{x:1341,y:754,t:1527876781854};\\\", \\\"{x:1344,y:745,t:1527876781871};\\\", \\\"{x:1344,y:744,t:1527876782329};\\\", \\\"{x:1345,y:743,t:1527876782361};\\\", \\\"{x:1345,y:742,t:1527876782370};\\\", \\\"{x:1346,y:736,t:1527876782386};\\\", \\\"{x:1346,y:729,t:1527876782403};\\\", \\\"{x:1346,y:724,t:1527876782420};\\\", \\\"{x:1347,y:722,t:1527876782436};\\\", \\\"{x:1347,y:718,t:1527876782453};\\\", \\\"{x:1347,y:712,t:1527876782471};\\\", \\\"{x:1347,y:706,t:1527876782486};\\\", \\\"{x:1347,y:694,t:1527876782503};\\\", \\\"{x:1344,y:682,t:1527876782521};\\\", \\\"{x:1343,y:666,t:1527876782537};\\\", \\\"{x:1340,y:657,t:1527876782553};\\\", \\\"{x:1339,y:648,t:1527876782571};\\\", \\\"{x:1334,y:633,t:1527876782586};\\\", \\\"{x:1325,y:616,t:1527876782603};\\\", \\\"{x:1319,y:603,t:1527876782619};\\\", \\\"{x:1312,y:592,t:1527876782636};\\\", \\\"{x:1307,y:582,t:1527876782653};\\\", \\\"{x:1304,y:577,t:1527876782669};\\\", \\\"{x:1301,y:574,t:1527876782687};\\\", \\\"{x:1299,y:570,t:1527876782703};\\\", \\\"{x:1298,y:569,t:1527876782719};\\\", \\\"{x:1297,y:568,t:1527876782744};\\\", \\\"{x:1296,y:568,t:1527876782888};\\\", \\\"{x:1296,y:576,t:1527876782902};\\\", \\\"{x:1287,y:595,t:1527876782919};\\\", \\\"{x:1276,y:626,t:1527876782936};\\\", \\\"{x:1265,y:649,t:1527876782953};\\\", \\\"{x:1264,y:661,t:1527876782970};\\\", \\\"{x:1264,y:666,t:1527876782986};\\\", \\\"{x:1264,y:667,t:1527876783002};\\\", \\\"{x:1264,y:668,t:1527876783019};\\\", \\\"{x:1264,y:669,t:1527876783037};\\\", \\\"{x:1263,y:670,t:1527876783052};\\\", \\\"{x:1261,y:674,t:1527876783069};\\\", \\\"{x:1260,y:680,t:1527876783087};\\\", \\\"{x:1256,y:692,t:1527876783103};\\\", \\\"{x:1255,y:702,t:1527876783119};\\\", \\\"{x:1248,y:730,t:1527876783136};\\\", \\\"{x:1244,y:755,t:1527876783153};\\\", \\\"{x:1241,y:775,t:1527876783170};\\\", \\\"{x:1238,y:799,t:1527876783186};\\\", \\\"{x:1238,y:820,t:1527876783203};\\\", \\\"{x:1238,y:823,t:1527876783219};\\\", \\\"{x:1238,y:824,t:1527876783248};\\\", \\\"{x:1238,y:825,t:1527876783288};\\\", \\\"{x:1237,y:826,t:1527876783303};\\\", \\\"{x:1236,y:826,t:1527876783392};\\\", \\\"{x:1234,y:827,t:1527876783402};\\\", \\\"{x:1231,y:829,t:1527876783419};\\\", \\\"{x:1229,y:829,t:1527876783435};\\\", \\\"{x:1226,y:830,t:1527876783451};\\\", \\\"{x:1224,y:831,t:1527876783468};\\\", \\\"{x:1221,y:829,t:1527876783648};\\\", \\\"{x:1218,y:829,t:1527876783656};\\\", \\\"{x:1217,y:828,t:1527876786264};\\\", \\\"{x:1217,y:827,t:1527876786680};\\\", \\\"{x:1217,y:824,t:1527876788449};\\\", \\\"{x:1219,y:818,t:1527876788464};\\\", \\\"{x:1227,y:804,t:1527876788480};\\\", \\\"{x:1235,y:791,t:1527876788496};\\\", \\\"{x:1241,y:776,t:1527876788513};\\\", \\\"{x:1253,y:760,t:1527876788530};\\\", \\\"{x:1257,y:745,t:1527876788546};\\\", \\\"{x:1263,y:731,t:1527876788563};\\\", \\\"{x:1273,y:713,t:1527876788579};\\\", \\\"{x:1275,y:709,t:1527876788595};\\\", \\\"{x:1276,y:708,t:1527876788617};\\\", \\\"{x:1272,y:708,t:1527876788784};\\\", \\\"{x:1269,y:711,t:1527876788796};\\\", \\\"{x:1263,y:715,t:1527876788813};\\\", \\\"{x:1255,y:719,t:1527876788829};\\\", \\\"{x:1247,y:722,t:1527876788846};\\\", \\\"{x:1240,y:726,t:1527876788863};\\\", \\\"{x:1235,y:728,t:1527876788879};\\\", \\\"{x:1230,y:730,t:1527876788894};\\\", \\\"{x:1227,y:732,t:1527876788912};\\\", \\\"{x:1224,y:733,t:1527876788928};\\\", \\\"{x:1220,y:736,t:1527876788944};\\\", \\\"{x:1216,y:739,t:1527876788961};\\\", \\\"{x:1215,y:740,t:1527876788978};\\\", \\\"{x:1213,y:740,t:1527876788995};\\\", \\\"{x:1212,y:741,t:1527876789011};\\\", \\\"{x:1209,y:743,t:1527876789028};\\\", \\\"{x:1208,y:743,t:1527876789045};\\\", \\\"{x:1205,y:744,t:1527876789062};\\\", \\\"{x:1202,y:746,t:1527876789079};\\\", \\\"{x:1199,y:748,t:1527876789096};\\\", \\\"{x:1197,y:750,t:1527876789112};\\\", \\\"{x:1196,y:750,t:1527876789128};\\\", \\\"{x:1195,y:751,t:1527876789145};\\\", \\\"{x:1193,y:753,t:1527876789161};\\\", \\\"{x:1192,y:753,t:1527876789178};\\\", \\\"{x:1191,y:754,t:1527876789194};\\\", \\\"{x:1188,y:756,t:1527876789211};\\\", \\\"{x:1187,y:757,t:1527876789232};\\\", \\\"{x:1186,y:757,t:1527876789255};\\\", \\\"{x:1185,y:758,t:1527876789272};\\\", \\\"{x:1184,y:759,t:1527876789280};\\\", \\\"{x:1182,y:761,t:1527876789311};\\\", \\\"{x:1181,y:761,t:1527876789328};\\\", \\\"{x:1181,y:762,t:1527876789383};\\\", \\\"{x:1181,y:763,t:1527876789407};\\\", \\\"{x:1187,y:763,t:1527876789415};\\\", \\\"{x:1191,y:761,t:1527876789427};\\\", \\\"{x:1206,y:755,t:1527876789444};\\\", \\\"{x:1226,y:751,t:1527876789461};\\\", \\\"{x:1253,y:751,t:1527876789478};\\\", \\\"{x:1279,y:751,t:1527876789495};\\\", \\\"{x:1308,y:752,t:1527876789511};\\\", \\\"{x:1317,y:754,t:1527876789527};\\\", \\\"{x:1319,y:756,t:1527876789545};\\\", \\\"{x:1320,y:756,t:1527876789561};\\\", \\\"{x:1321,y:756,t:1527876789577};\\\", \\\"{x:1323,y:757,t:1527876789640};\\\", \\\"{x:1324,y:759,t:1527876789648};\\\", \\\"{x:1331,y:761,t:1527876789661};\\\", \\\"{x:1337,y:765,t:1527876789679};\\\", \\\"{x:1344,y:768,t:1527876789695};\\\", \\\"{x:1347,y:769,t:1527876789710};\\\", \\\"{x:1348,y:769,t:1527876789728};\\\", \\\"{x:1349,y:769,t:1527876789760};\\\", \\\"{x:1350,y:768,t:1527876789792};\\\", \\\"{x:1351,y:768,t:1527876789817};\\\", \\\"{x:1351,y:767,t:1527876789833};\\\", \\\"{x:1352,y:767,t:1527876789864};\\\", \\\"{x:1352,y:766,t:1527876789895};\\\", \\\"{x:1353,y:765,t:1527876789959};\\\", \\\"{x:1354,y:764,t:1527876789967};\\\", \\\"{x:1354,y:763,t:1527876790055};\\\", \\\"{x:1351,y:763,t:1527876790064};\\\", \\\"{x:1347,y:764,t:1527876790078};\\\", \\\"{x:1337,y:768,t:1527876790094};\\\", \\\"{x:1326,y:772,t:1527876790111};\\\", \\\"{x:1303,y:777,t:1527876790127};\\\", \\\"{x:1290,y:778,t:1527876790143};\\\", \\\"{x:1279,y:779,t:1527876790160};\\\", \\\"{x:1273,y:779,t:1527876790177};\\\", \\\"{x:1266,y:779,t:1527876790194};\\\", \\\"{x:1263,y:779,t:1527876790211};\\\", \\\"{x:1259,y:779,t:1527876790227};\\\", \\\"{x:1255,y:779,t:1527876790244};\\\", \\\"{x:1253,y:779,t:1527876790260};\\\", \\\"{x:1252,y:779,t:1527876790276};\\\", \\\"{x:1250,y:779,t:1527876790360};\\\", \\\"{x:1246,y:779,t:1527876790378};\\\", \\\"{x:1238,y:778,t:1527876790394};\\\", \\\"{x:1226,y:777,t:1527876790411};\\\", \\\"{x:1211,y:774,t:1527876790426};\\\", \\\"{x:1198,y:772,t:1527876790443};\\\", \\\"{x:1185,y:768,t:1527876790459};\\\", \\\"{x:1175,y:766,t:1527876790476};\\\", \\\"{x:1169,y:763,t:1527876790493};\\\", \\\"{x:1162,y:762,t:1527876790509};\\\", \\\"{x:1156,y:759,t:1527876790526};\\\", \\\"{x:1148,y:755,t:1527876790543};\\\", \\\"{x:1146,y:755,t:1527876790559};\\\", \\\"{x:1145,y:755,t:1527876790632};\\\", \\\"{x:1145,y:754,t:1527876790744};\\\", \\\"{x:1148,y:752,t:1527876790760};\\\", \\\"{x:1152,y:751,t:1527876790776};\\\", \\\"{x:1156,y:749,t:1527876790792};\\\", \\\"{x:1164,y:749,t:1527876790810};\\\", \\\"{x:1170,y:749,t:1527876790826};\\\", \\\"{x:1174,y:749,t:1527876790842};\\\", \\\"{x:1177,y:750,t:1527876790860};\\\", \\\"{x:1179,y:752,t:1527876790877};\\\", \\\"{x:1180,y:753,t:1527876790893};\\\", \\\"{x:1181,y:753,t:1527876790910};\\\", \\\"{x:1182,y:753,t:1527876790926};\\\", \\\"{x:1182,y:754,t:1527876790943};\\\", \\\"{x:1183,y:754,t:1527876790976};\\\", \\\"{x:1185,y:756,t:1527876791129};\\\", \\\"{x:1185,y:757,t:1527876791144};\\\", \\\"{x:1186,y:759,t:1527876791168};\\\", \\\"{x:1186,y:760,t:1527876791185};\\\", \\\"{x:1187,y:761,t:1527876791210};\\\", \\\"{x:1187,y:762,t:1527876791776};\\\", \\\"{x:1188,y:763,t:1527876791889};\\\", \\\"{x:1188,y:765,t:1527876791928};\\\", \\\"{x:1188,y:766,t:1527876791968};\\\", \\\"{x:1188,y:768,t:1527876792096};\\\", \\\"{x:1192,y:766,t:1527876793544};\\\", \\\"{x:1204,y:762,t:1527876793556};\\\", \\\"{x:1241,y:760,t:1527876793573};\\\", \\\"{x:1269,y:757,t:1527876793590};\\\", \\\"{x:1289,y:757,t:1527876793606};\\\", \\\"{x:1297,y:756,t:1527876793623};\\\", \\\"{x:1293,y:758,t:1527876793816};\\\", \\\"{x:1289,y:761,t:1527876793824};\\\", \\\"{x:1284,y:762,t:1527876793839};\\\", \\\"{x:1276,y:766,t:1527876793856};\\\", \\\"{x:1269,y:770,t:1527876793873};\\\", \\\"{x:1264,y:773,t:1527876793888};\\\", \\\"{x:1262,y:774,t:1527876793906};\\\", \\\"{x:1258,y:777,t:1527876793923};\\\", \\\"{x:1254,y:778,t:1527876793939};\\\", \\\"{x:1250,y:779,t:1527876793956};\\\", \\\"{x:1238,y:780,t:1527876793973};\\\", \\\"{x:1228,y:780,t:1527876793989};\\\", \\\"{x:1220,y:780,t:1527876794006};\\\", \\\"{x:1212,y:780,t:1527876794023};\\\", \\\"{x:1208,y:779,t:1527876794039};\\\", \\\"{x:1202,y:777,t:1527876794056};\\\", \\\"{x:1199,y:777,t:1527876794072};\\\", \\\"{x:1184,y:775,t:1527876794088};\\\", \\\"{x:1166,y:772,t:1527876794105};\\\", \\\"{x:1134,y:766,t:1527876794121};\\\", \\\"{x:1106,y:759,t:1527876794138};\\\", \\\"{x:1076,y:754,t:1527876794155};\\\", \\\"{x:1054,y:752,t:1527876794171};\\\", \\\"{x:1035,y:747,t:1527876794188};\\\", \\\"{x:1008,y:741,t:1527876794206};\\\", \\\"{x:969,y:730,t:1527876794221};\\\", \\\"{x:919,y:717,t:1527876794238};\\\", \\\"{x:816,y:683,t:1527876794255};\\\", \\\"{x:751,y:664,t:1527876794271};\\\", \\\"{x:711,y:652,t:1527876794288};\\\", \\\"{x:692,y:646,t:1527876794305};\\\", \\\"{x:689,y:642,t:1527876794321};\\\", \\\"{x:686,y:640,t:1527876794338};\\\", \\\"{x:682,y:640,t:1527876794354};\\\", \\\"{x:675,y:639,t:1527876794371};\\\", \\\"{x:662,y:637,t:1527876794388};\\\", \\\"{x:648,y:633,t:1527876794404};\\\", \\\"{x:631,y:630,t:1527876794422};\\\", \\\"{x:618,y:629,t:1527876794438};\\\", \\\"{x:608,y:628,t:1527876794454};\\\", \\\"{x:601,y:628,t:1527876794474};\\\", \\\"{x:590,y:628,t:1527876794491};\\\", \\\"{x:583,y:630,t:1527876794507};\\\", \\\"{x:580,y:630,t:1527876794524};\\\", \\\"{x:578,y:630,t:1527876794541};\\\", \\\"{x:579,y:630,t:1527876794591};\\\", \\\"{x:585,y:626,t:1527876794607};\\\", \\\"{x:595,y:620,t:1527876794624};\\\", \\\"{x:606,y:614,t:1527876794642};\\\", \\\"{x:617,y:605,t:1527876794658};\\\", \\\"{x:625,y:598,t:1527876794676};\\\", \\\"{x:628,y:594,t:1527876794691};\\\", \\\"{x:628,y:591,t:1527876794707};\\\", \\\"{x:628,y:588,t:1527876794724};\\\", \\\"{x:628,y:584,t:1527876794741};\\\", \\\"{x:622,y:569,t:1527876794757};\\\", \\\"{x:603,y:556,t:1527876794774};\\\", \\\"{x:565,y:540,t:1527876794791};\\\", \\\"{x:533,y:532,t:1527876794807};\\\", \\\"{x:504,y:522,t:1527876794824};\\\", \\\"{x:471,y:517,t:1527876794842};\\\", \\\"{x:428,y:510,t:1527876794858};\\\", \\\"{x:416,y:510,t:1527876794874};\\\", \\\"{x:404,y:508,t:1527876794891};\\\", \\\"{x:389,y:507,t:1527876794908};\\\", \\\"{x:380,y:505,t:1527876794924};\\\", \\\"{x:361,y:503,t:1527876794942};\\\", \\\"{x:337,y:503,t:1527876794958};\\\", \\\"{x:317,y:503,t:1527876794974};\\\", \\\"{x:313,y:503,t:1527876794991};\\\", \\\"{x:313,y:502,t:1527876795136};\\\", \\\"{x:314,y:500,t:1527876795143};\\\", \\\"{x:315,y:500,t:1527876795158};\\\", \\\"{x:317,y:500,t:1527876795175};\\\", \\\"{x:315,y:500,t:1527876795192};\\\", \\\"{x:303,y:501,t:1527876795208};\\\", \\\"{x:279,y:506,t:1527876795226};\\\", \\\"{x:264,y:509,t:1527876795244};\\\", \\\"{x:256,y:511,t:1527876795258};\\\", \\\"{x:253,y:512,t:1527876795275};\\\", \\\"{x:252,y:512,t:1527876795292};\\\", \\\"{x:249,y:514,t:1527876795308};\\\", \\\"{x:242,y:516,t:1527876795325};\\\", \\\"{x:239,y:519,t:1527876795342};\\\", \\\"{x:233,y:521,t:1527876795359};\\\", \\\"{x:228,y:523,t:1527876795374};\\\", \\\"{x:220,y:527,t:1527876795391};\\\", \\\"{x:211,y:529,t:1527876795407};\\\", \\\"{x:204,y:535,t:1527876795425};\\\", \\\"{x:202,y:536,t:1527876795441};\\\", \\\"{x:201,y:536,t:1527876795471};\\\", \\\"{x:198,y:535,t:1527876795479};\\\", \\\"{x:195,y:530,t:1527876795491};\\\", \\\"{x:186,y:519,t:1527876795509};\\\", \\\"{x:175,y:510,t:1527876795526};\\\", \\\"{x:165,y:500,t:1527876795541};\\\", \\\"{x:158,y:495,t:1527876795558};\\\", \\\"{x:157,y:494,t:1527876795598};\\\", \\\"{x:157,y:493,t:1527876795608};\\\", \\\"{x:158,y:484,t:1527876795626};\\\", \\\"{x:156,y:476,t:1527876795641};\\\", \\\"{x:152,y:471,t:1527876795658};\\\", \\\"{x:152,y:474,t:1527876795839};\\\", \\\"{x:152,y:478,t:1527876795846};\\\", \\\"{x:153,y:484,t:1527876795858};\\\", \\\"{x:154,y:488,t:1527876795875};\\\", \\\"{x:156,y:492,t:1527876795892};\\\", \\\"{x:156,y:493,t:1527876795908};\\\", \\\"{x:157,y:493,t:1527876796047};\\\", \\\"{x:159,y:495,t:1527876796058};\\\", \\\"{x:166,y:502,t:1527876796075};\\\", \\\"{x:168,y:503,t:1527876796091};\\\", \\\"{x:169,y:503,t:1527876796127};\\\", \\\"{x:170,y:503,t:1527876796159};\\\", \\\"{x:170,y:503,t:1527876796256};\\\", \\\"{x:177,y:503,t:1527876796456};\\\", \\\"{x:185,y:503,t:1527876796463};\\\", \\\"{x:190,y:504,t:1527876796476};\\\", \\\"{x:211,y:517,t:1527876796492};\\\", \\\"{x:244,y:537,t:1527876796511};\\\", \\\"{x:261,y:552,t:1527876796525};\\\", \\\"{x:327,y:594,t:1527876796543};\\\", \\\"{x:431,y:660,t:1527876796559};\\\", \\\"{x:476,y:688,t:1527876796576};\\\", \\\"{x:492,y:706,t:1527876796592};\\\", \\\"{x:499,y:710,t:1527876796610};\\\", \\\"{x:501,y:713,t:1527876796625};\\\", \\\"{x:501,y:714,t:1527876796760};\\\", \\\"{x:501,y:715,t:1527876796776};\\\", \\\"{x:501,y:716,t:1527876796807};\\\", \\\"{x:501,y:718,t:1527876796816};\\\", \\\"{x:500,y:720,t:1527876796825};\\\", \\\"{x:497,y:725,t:1527876796842};\\\", \\\"{x:497,y:729,t:1527876796859};\\\", \\\"{x:497,y:730,t:1527876796887};\\\", \\\"{x:497,y:731,t:1527876796895};\\\", \\\"{x:497,y:732,t:1527876796935};\\\", \\\"{x:497,y:735,t:1527876796943};\\\", \\\"{x:497,y:741,t:1527876796959};\\\", \\\"{x:498,y:744,t:1527876796977};\\\", \\\"{x:499,y:746,t:1527876796993};\\\", \\\"{x:499,y:748,t:1527876797010};\\\", \\\"{x:500,y:748,t:1527876797536};\\\", \\\"{x:501,y:748,t:1527876797543};\\\", \\\"{x:502,y:748,t:1527876797575};\\\", \\\"{x:503,y:748,t:1527876797594};\\\", \\\"{x:504,y:748,t:1527876797611};\\\", \\\"{x:505,y:747,t:1527876797627};\\\", \\\"{x:505,y:746,t:1527876798296};\\\", \\\"{x:504,y:746,t:1527876798311};\\\", \\\"{x:503,y:749,t:1527876798328};\\\", \\\"{x:526,y:732,t:1527876798880};\\\", \\\"{x:532,y:728,t:1527876798894};\\\", \\\"{x:552,y:717,t:1527876798910};\\\", \\\"{x:563,y:710,t:1527876798927};\\\", \\\"{x:576,y:701,t:1527876798944};\\\", \\\"{x:589,y:694,t:1527876798961};\\\" ] }, { \\\"rt\\\": 11817, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 14, \\\"time_elapsed\\\": 418856, \\\"internal_node_id\\\": \\\"0.0-6.0-4.0\\\", \\\"subject\\\": \\\"7BW1K\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"ends\\\", \\\"q\\\": 10, \\\"clicks\\\": 1, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-7-F -F -F -E \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:633,y:644,t:1527876799112};\\\", \\\"{x:633,y:643,t:1527876799127};\\\", \\\"{x:637,y:639,t:1527876799144};\\\", \\\"{x:643,y:632,t:1527876799161};\\\", \\\"{x:652,y:625,t:1527876799179};\\\", \\\"{x:662,y:617,t:1527876799194};\\\", \\\"{x:672,y:608,t:1527876799211};\\\", \\\"{x:695,y:593,t:1527876799242};\\\", \\\"{x:711,y:581,t:1527876799261};\\\", \\\"{x:726,y:570,t:1527876799279};\\\", \\\"{x:752,y:553,t:1527876799295};\\\", \\\"{x:765,y:542,t:1527876799311};\\\", \\\"{x:774,y:534,t:1527876799328};\\\", \\\"{x:776,y:533,t:1527876799345};\\\", \\\"{x:777,y:532,t:1527876799361};\\\", \\\"{x:778,y:532,t:1527876799378};\\\", \\\"{x:778,y:531,t:1527876799399};\\\", \\\"{x:766,y:531,t:1527876799544};\\\", \\\"{x:717,y:535,t:1527876799563};\\\", \\\"{x:671,y:551,t:1527876799579};\\\", \\\"{x:641,y:556,t:1527876799595};\\\", \\\"{x:514,y:543,t:1527876799695};\\\", \\\"{x:479,y:534,t:1527876799712};\\\", \\\"{x:456,y:525,t:1527876799728};\\\", \\\"{x:448,y:522,t:1527876799745};\\\", \\\"{x:446,y:519,t:1527876799761};\\\", \\\"{x:444,y:517,t:1527876799779};\\\", \\\"{x:444,y:515,t:1527876799795};\\\", \\\"{x:442,y:512,t:1527876799811};\\\", \\\"{x:439,y:510,t:1527876799828};\\\", \\\"{x:433,y:506,t:1527876799845};\\\", \\\"{x:428,y:505,t:1527876799863};\\\", \\\"{x:424,y:503,t:1527876799878};\\\", \\\"{x:424,y:502,t:1527876799903};\\\", \\\"{x:423,y:501,t:1527876799919};\\\", \\\"{x:421,y:500,t:1527876799928};\\\", \\\"{x:416,y:497,t:1527876799945};\\\", \\\"{x:409,y:494,t:1527876799963};\\\", \\\"{x:397,y:487,t:1527876799980};\\\", \\\"{x:392,y:483,t:1527876799996};\\\", \\\"{x:391,y:481,t:1527876800013};\\\", \\\"{x:390,y:479,t:1527876800028};\\\", \\\"{x:390,y:478,t:1527876800046};\\\", \\\"{x:390,y:476,t:1527876800062};\\\", \\\"{x:387,y:474,t:1527876800078};\\\", \\\"{x:386,y:473,t:1527876800096};\\\", \\\"{x:386,y:472,t:1527876800113};\\\", \\\"{x:385,y:472,t:1527876800303};\\\", \\\"{x:387,y:470,t:1527876800432};\\\", \\\"{x:391,y:468,t:1527876800446};\\\", \\\"{x:399,y:464,t:1527876800463};\\\", \\\"{x:423,y:459,t:1527876800480};\\\", \\\"{x:443,y:458,t:1527876800496};\\\", \\\"{x:457,y:457,t:1527876800513};\\\", \\\"{x:475,y:456,t:1527876800530};\\\", \\\"{x:483,y:456,t:1527876800546};\\\", \\\"{x:489,y:456,t:1527876800562};\\\", \\\"{x:498,y:456,t:1527876800580};\\\", \\\"{x:503,y:456,t:1527876800596};\\\", \\\"{x:507,y:454,t:1527876800613};\\\", \\\"{x:511,y:454,t:1527876800630};\\\", \\\"{x:517,y:452,t:1527876800646};\\\", \\\"{x:522,y:451,t:1527876800663};\\\", \\\"{x:527,y:450,t:1527876800679};\\\", \\\"{x:529,y:450,t:1527876800696};\\\", \\\"{x:530,y:450,t:1527876800713};\\\", \\\"{x:531,y:450,t:1527876800730};\\\", \\\"{x:532,y:450,t:1527876800746};\\\", \\\"{x:533,y:450,t:1527876801216};\\\", \\\"{x:540,y:451,t:1527876801230};\\\", \\\"{x:568,y:452,t:1527876801247};\\\", \\\"{x:617,y:457,t:1527876801263};\\\", \\\"{x:674,y:467,t:1527876801280};\\\", \\\"{x:770,y:477,t:1527876801297};\\\", \\\"{x:876,y:493,t:1527876801315};\\\", \\\"{x:979,y:498,t:1527876801330};\\\", \\\"{x:1061,y:504,t:1527876801346};\\\", \\\"{x:1153,y:506,t:1527876801364};\\\", \\\"{x:1249,y:511,t:1527876801380};\\\", \\\"{x:1292,y:513,t:1527876801396};\\\", \\\"{x:1312,y:513,t:1527876801413};\\\", \\\"{x:1323,y:518,t:1527876801430};\\\", \\\"{x:1332,y:523,t:1527876801447};\\\", \\\"{x:1337,y:530,t:1527876801463};\\\", \\\"{x:1342,y:539,t:1527876801480};\\\", \\\"{x:1356,y:556,t:1527876801497};\\\", \\\"{x:1368,y:569,t:1527876801514};\\\", \\\"{x:1376,y:578,t:1527876801529};\\\", \\\"{x:1385,y:586,t:1527876801547};\\\", \\\"{x:1393,y:591,t:1527876801563};\\\", \\\"{x:1402,y:596,t:1527876801581};\\\", \\\"{x:1406,y:600,t:1527876801596};\\\", \\\"{x:1410,y:604,t:1527876801614};\\\", \\\"{x:1413,y:606,t:1527876801630};\\\", \\\"{x:1417,y:610,t:1527876801647};\\\", \\\"{x:1421,y:615,t:1527876801663};\\\", \\\"{x:1422,y:618,t:1527876801682};\\\", \\\"{x:1424,y:619,t:1527876801697};\\\", \\\"{x:1426,y:622,t:1527876801714};\\\", \\\"{x:1428,y:624,t:1527876801730};\\\", \\\"{x:1429,y:626,t:1527876801746};\\\", \\\"{x:1429,y:627,t:1527876801776};\\\", \\\"{x:1431,y:629,t:1527876801784};\\\", \\\"{x:1431,y:632,t:1527876801797};\\\", \\\"{x:1432,y:635,t:1527876801814};\\\", \\\"{x:1433,y:639,t:1527876801831};\\\", \\\"{x:1434,y:642,t:1527876801846};\\\", \\\"{x:1436,y:645,t:1527876801864};\\\", \\\"{x:1436,y:646,t:1527876801882};\\\", \\\"{x:1437,y:647,t:1527876802072};\\\", \\\"{x:1436,y:647,t:1527876802192};\\\", \\\"{x:1434,y:649,t:1527876802200};\\\", \\\"{x:1431,y:650,t:1527876802215};\\\", \\\"{x:1418,y:655,t:1527876802231};\\\", \\\"{x:1416,y:656,t:1527876802248};\\\", \\\"{x:1412,y:658,t:1527876802264};\\\", \\\"{x:1408,y:662,t:1527876802283};\\\", \\\"{x:1403,y:665,t:1527876802298};\\\", \\\"{x:1397,y:669,t:1527876802314};\\\", \\\"{x:1390,y:674,t:1527876802331};\\\", \\\"{x:1381,y:676,t:1527876802348};\\\", \\\"{x:1376,y:680,t:1527876802364};\\\", \\\"{x:1372,y:682,t:1527876802381};\\\", \\\"{x:1371,y:683,t:1527876802398};\\\", \\\"{x:1370,y:683,t:1527876802414};\\\", \\\"{x:1365,y:686,t:1527876802431};\\\", \\\"{x:1358,y:690,t:1527876802448};\\\", \\\"{x:1348,y:695,t:1527876802467};\\\", \\\"{x:1344,y:697,t:1527876802481};\\\", \\\"{x:1342,y:697,t:1527876802497};\\\", \\\"{x:1342,y:698,t:1527876802514};\\\", \\\"{x:1341,y:698,t:1527876802583};\\\", \\\"{x:1340,y:699,t:1527876802597};\\\", \\\"{x:1339,y:699,t:1527876802615};\\\", \\\"{x:1338,y:699,t:1527876802630};\\\", \\\"{x:1340,y:699,t:1527876802776};\\\", \\\"{x:1342,y:699,t:1527876802791};\\\", \\\"{x:1343,y:699,t:1527876802808};\\\", \\\"{x:1344,y:699,t:1527876802815};\\\", \\\"{x:1345,y:699,t:1527876802944};\\\", \\\"{x:1346,y:699,t:1527876802968};\\\", \\\"{x:1347,y:698,t:1527876805072};\\\", \\\"{x:1347,y:694,t:1527876805112};\\\", \\\"{x:1347,y:686,t:1527876805120};\\\", \\\"{x:1346,y:678,t:1527876805133};\\\", \\\"{x:1336,y:654,t:1527876805151};\\\", \\\"{x:1322,y:624,t:1527876805167};\\\", \\\"{x:1313,y:605,t:1527876805183};\\\", \\\"{x:1305,y:590,t:1527876805200};\\\", \\\"{x:1301,y:581,t:1527876805217};\\\", \\\"{x:1298,y:574,t:1527876805234};\\\", \\\"{x:1297,y:568,t:1527876805251};\\\", \\\"{x:1294,y:560,t:1527876805266};\\\", \\\"{x:1290,y:553,t:1527876805283};\\\", \\\"{x:1289,y:551,t:1527876805301};\\\", \\\"{x:1289,y:550,t:1527876805317};\\\", \\\"{x:1289,y:549,t:1527876805333};\\\", \\\"{x:1288,y:548,t:1527876805352};\\\", \\\"{x:1286,y:548,t:1527876805456};\\\", \\\"{x:1284,y:549,t:1527876805472};\\\", \\\"{x:1280,y:549,t:1527876805483};\\\", \\\"{x:1271,y:552,t:1527876805500};\\\", \\\"{x:1261,y:553,t:1527876805517};\\\", \\\"{x:1236,y:558,t:1527876805533};\\\", \\\"{x:1208,y:558,t:1527876805550};\\\", \\\"{x:1161,y:559,t:1527876805568};\\\", \\\"{x:1126,y:559,t:1527876805583};\\\", \\\"{x:1088,y:561,t:1527876805601};\\\", \\\"{x:1051,y:561,t:1527876805617};\\\", \\\"{x:1017,y:556,t:1527876805634};\\\", \\\"{x:981,y:556,t:1527876805651};\\\", \\\"{x:936,y:556,t:1527876805667};\\\", \\\"{x:879,y:554,t:1527876805685};\\\", \\\"{x:853,y:557,t:1527876805699};\\\", \\\"{x:793,y:560,t:1527876805716};\\\", \\\"{x:725,y:558,t:1527876805733};\\\", \\\"{x:663,y:548,t:1527876805750};\\\", \\\"{x:605,y:540,t:1527876805766};\\\", \\\"{x:568,y:528,t:1527876805783};\\\", \\\"{x:556,y:524,t:1527876805800};\\\", \\\"{x:556,y:523,t:1527876805830};\\\", \\\"{x:556,y:522,t:1527876805894};\\\", \\\"{x:556,y:521,t:1527876805903};\\\", \\\"{x:560,y:515,t:1527876805917};\\\", \\\"{x:572,y:504,t:1527876805934};\\\", \\\"{x:583,y:491,t:1527876805950};\\\", \\\"{x:596,y:483,t:1527876805967};\\\", \\\"{x:601,y:481,t:1527876805984};\\\", \\\"{x:603,y:481,t:1527876806000};\\\", \\\"{x:607,y:481,t:1527876806017};\\\", \\\"{x:609,y:481,t:1527876806033};\\\", \\\"{x:610,y:481,t:1527876806051};\\\", \\\"{x:610,y:482,t:1527876806067};\\\", \\\"{x:609,y:483,t:1527876806087};\\\", \\\"{x:609,y:484,t:1527876806232};\\\", \\\"{x:608,y:485,t:1527876806256};\\\", \\\"{x:607,y:486,t:1527876806271};\\\", \\\"{x:605,y:487,t:1527876806285};\\\", \\\"{x:605,y:488,t:1527876806300};\\\", \\\"{x:604,y:488,t:1527876806316};\\\", \\\"{x:603,y:489,t:1527876806335};\\\", \\\"{x:602,y:490,t:1527876806390};\\\", \\\"{x:601,y:491,t:1527876806400};\\\", \\\"{x:600,y:497,t:1527876807543};\\\", \\\"{x:599,y:498,t:1527876807552};\\\", \\\"{x:598,y:503,t:1527876807568};\\\", \\\"{x:595,y:509,t:1527876807585};\\\", \\\"{x:592,y:517,t:1527876807602};\\\", \\\"{x:590,y:524,t:1527876807618};\\\", \\\"{x:584,y:534,t:1527876807636};\\\", \\\"{x:584,y:540,t:1527876807652};\\\", \\\"{x:582,y:545,t:1527876807667};\\\", \\\"{x:580,y:553,t:1527876807684};\\\", \\\"{x:579,y:558,t:1527876807702};\\\", \\\"{x:579,y:563,t:1527876807718};\\\", \\\"{x:578,y:570,t:1527876807734};\\\", \\\"{x:575,y:578,t:1527876807751};\\\", \\\"{x:573,y:589,t:1527876807768};\\\", \\\"{x:571,y:601,t:1527876807786};\\\", \\\"{x:570,y:610,t:1527876807802};\\\", \\\"{x:566,y:625,t:1527876807818};\\\", \\\"{x:565,y:639,t:1527876807836};\\\", \\\"{x:564,y:649,t:1527876807852};\\\", \\\"{x:561,y:664,t:1527876807868};\\\", \\\"{x:561,y:676,t:1527876807885};\\\", \\\"{x:560,y:687,t:1527876807902};\\\", \\\"{x:556,y:700,t:1527876807918};\\\", \\\"{x:555,y:702,t:1527876807934};\\\", \\\"{x:549,y:710,t:1527876807952};\\\", \\\"{x:543,y:718,t:1527876807969};\\\", \\\"{x:539,y:725,t:1527876807986};\\\", \\\"{x:530,y:733,t:1527876808001};\\\", \\\"{x:526,y:736,t:1527876808018};\\\", \\\"{x:525,y:737,t:1527876808034};\\\", \\\"{x:521,y:739,t:1527876808052};\\\", \\\"{x:517,y:742,t:1527876808069};\\\", \\\"{x:515,y:744,t:1527876808084};\\\", \\\"{x:514,y:745,t:1527876808102};\\\", \\\"{x:512,y:747,t:1527876808119};\\\" ] }, { \\\"rt\\\": 11649, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 15, \\\"time_elapsed\\\": 431773, \\\"internal_node_id\\\": \\\"0.0-6.0-5.0\\\", \\\"subject\\\": \\\"7BW1K\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 11, \\\"clicks\\\": 2, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"M\\\", \\\"L\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:520,y:746,t:1527876813276};\\\", \\\"{x:529,y:743,t:1527876813295};\\\", \\\"{x:533,y:743,t:1527876813310};\\\", \\\"{x:546,y:750,t:1527876813327};\\\", \\\"{x:549,y:753,t:1527876813344};\\\", \\\"{x:558,y:754,t:1527876813362};\\\", \\\"{x:563,y:750,t:1527876813901};\\\", \\\"{x:569,y:746,t:1527876813912};\\\", \\\"{x:576,y:742,t:1527876813926};\\\", \\\"{x:586,y:737,t:1527876813944};\\\", \\\"{x:591,y:733,t:1527876813960};\\\", \\\"{x:598,y:729,t:1527876813977};\\\", \\\"{x:604,y:727,t:1527876813994};\\\", \\\"{x:622,y:723,t:1527876814010};\\\", \\\"{x:634,y:720,t:1527876814027};\\\", \\\"{x:654,y:719,t:1527876814043};\\\", \\\"{x:679,y:719,t:1527876814061};\\\", \\\"{x:694,y:719,t:1527876814077};\\\", \\\"{x:723,y:719,t:1527876814094};\\\", \\\"{x:759,y:720,t:1527876814111};\\\", \\\"{x:792,y:725,t:1527876814127};\\\", \\\"{x:827,y:726,t:1527876814144};\\\", \\\"{x:855,y:726,t:1527876814161};\\\", \\\"{x:884,y:726,t:1527876814177};\\\", \\\"{x:959,y:707,t:1527876814194};\\\", \\\"{x:1055,y:676,t:1527876814211};\\\", \\\"{x:1109,y:663,t:1527876814228};\\\", \\\"{x:1168,y:647,t:1527876814245};\\\", \\\"{x:1210,y:641,t:1527876814261};\\\", \\\"{x:1226,y:635,t:1527876814278};\\\", \\\"{x:1242,y:631,t:1527876814295};\\\", \\\"{x:1251,y:628,t:1527876814312};\\\", \\\"{x:1255,y:626,t:1527876814329};\\\", \\\"{x:1256,y:626,t:1527876814344};\\\", \\\"{x:1257,y:626,t:1527876814361};\\\", \\\"{x:1258,y:626,t:1527876814379};\\\", \\\"{x:1258,y:625,t:1527876814395};\\\", \\\"{x:1259,y:626,t:1527876814723};\\\", \\\"{x:1262,y:630,t:1527876814732};\\\", \\\"{x:1265,y:635,t:1527876814745};\\\", \\\"{x:1272,y:651,t:1527876814762};\\\", \\\"{x:1279,y:671,t:1527876814778};\\\", \\\"{x:1284,y:687,t:1527876814795};\\\", \\\"{x:1290,y:707,t:1527876814811};\\\", \\\"{x:1297,y:719,t:1527876814828};\\\", \\\"{x:1303,y:734,t:1527876814846};\\\", \\\"{x:1310,y:745,t:1527876814861};\\\", \\\"{x:1318,y:757,t:1527876814878};\\\", \\\"{x:1323,y:765,t:1527876814895};\\\", \\\"{x:1326,y:773,t:1527876814912};\\\", \\\"{x:1330,y:779,t:1527876814929};\\\", \\\"{x:1332,y:783,t:1527876814946};\\\", \\\"{x:1335,y:787,t:1527876814961};\\\", \\\"{x:1337,y:792,t:1527876814978};\\\", \\\"{x:1344,y:801,t:1527876814995};\\\", \\\"{x:1348,y:805,t:1527876815011};\\\", \\\"{x:1350,y:808,t:1527876815029};\\\", \\\"{x:1353,y:811,t:1527876815046};\\\", \\\"{x:1360,y:820,t:1527876815061};\\\", \\\"{x:1364,y:829,t:1527876815078};\\\", \\\"{x:1369,y:838,t:1527876815096};\\\", \\\"{x:1377,y:850,t:1527876815112};\\\", \\\"{x:1384,y:858,t:1527876815129};\\\", \\\"{x:1389,y:862,t:1527876815145};\\\", \\\"{x:1392,y:865,t:1527876815162};\\\", \\\"{x:1397,y:868,t:1527876815179};\\\", \\\"{x:1410,y:876,t:1527876815195};\\\", \\\"{x:1418,y:882,t:1527876815213};\\\", \\\"{x:1425,y:886,t:1527876815228};\\\", \\\"{x:1432,y:893,t:1527876815245};\\\", \\\"{x:1438,y:897,t:1527876815261};\\\", \\\"{x:1444,y:903,t:1527876815279};\\\", \\\"{x:1451,y:909,t:1527876815295};\\\", \\\"{x:1460,y:917,t:1527876815312};\\\", \\\"{x:1468,y:922,t:1527876815329};\\\", \\\"{x:1472,y:926,t:1527876815346};\\\", \\\"{x:1478,y:929,t:1527876815362};\\\", \\\"{x:1481,y:930,t:1527876815378};\\\", \\\"{x:1482,y:930,t:1527876815396};\\\", \\\"{x:1483,y:931,t:1527876815419};\\\", \\\"{x:1484,y:932,t:1527876815428};\\\", \\\"{x:1486,y:933,t:1527876815446};\\\", \\\"{x:1489,y:937,t:1527876815462};\\\", \\\"{x:1492,y:939,t:1527876815478};\\\", \\\"{x:1496,y:941,t:1527876815496};\\\", \\\"{x:1497,y:941,t:1527876815513};\\\", \\\"{x:1500,y:943,t:1527876815529};\\\", \\\"{x:1501,y:943,t:1527876815707};\\\", \\\"{x:1502,y:943,t:1527876815716};\\\", \\\"{x:1503,y:944,t:1527876815731};\\\", \\\"{x:1504,y:944,t:1527876815819};\\\", \\\"{x:1507,y:944,t:1527876815829};\\\", \\\"{x:1511,y:944,t:1527876815846};\\\", \\\"{x:1515,y:944,t:1527876815863};\\\", \\\"{x:1522,y:944,t:1527876815880};\\\", \\\"{x:1524,y:944,t:1527876815895};\\\", \\\"{x:1526,y:944,t:1527876815912};\\\", \\\"{x:1527,y:944,t:1527876815930};\\\", \\\"{x:1528,y:944,t:1527876815946};\\\", \\\"{x:1529,y:944,t:1527876815963};\\\", \\\"{x:1530,y:944,t:1527876815980};\\\", \\\"{x:1531,y:945,t:1527876816084};\\\", \\\"{x:1531,y:946,t:1527876816096};\\\", \\\"{x:1530,y:947,t:1527876816112};\\\", \\\"{x:1519,y:948,t:1527876816130};\\\", \\\"{x:1502,y:948,t:1527876816146};\\\", \\\"{x:1482,y:948,t:1527876816163};\\\", \\\"{x:1447,y:948,t:1527876816180};\\\", \\\"{x:1418,y:945,t:1527876816197};\\\", \\\"{x:1389,y:937,t:1527876816212};\\\", \\\"{x:1366,y:934,t:1527876816230};\\\", \\\"{x:1360,y:933,t:1527876816246};\\\", \\\"{x:1358,y:933,t:1527876816262};\\\", \\\"{x:1356,y:933,t:1527876816283};\\\", \\\"{x:1355,y:933,t:1527876816420};\\\", \\\"{x:1354,y:933,t:1527876816435};\\\", \\\"{x:1354,y:934,t:1527876816447};\\\", \\\"{x:1353,y:937,t:1527876816463};\\\", \\\"{x:1352,y:938,t:1527876816480};\\\", \\\"{x:1352,y:939,t:1527876816496};\\\", \\\"{x:1352,y:942,t:1527876816513};\\\", \\\"{x:1352,y:943,t:1527876816530};\\\", \\\"{x:1352,y:945,t:1527876816546};\\\", \\\"{x:1351,y:948,t:1527876816562};\\\", \\\"{x:1350,y:950,t:1527876816580};\\\", \\\"{x:1349,y:952,t:1527876816597};\\\", \\\"{x:1349,y:953,t:1527876816613};\\\", \\\"{x:1349,y:955,t:1527876816629};\\\", \\\"{x:1349,y:956,t:1527876816647};\\\", \\\"{x:1348,y:958,t:1527876816663};\\\", \\\"{x:1347,y:962,t:1527876816680};\\\", \\\"{x:1347,y:964,t:1527876816699};\\\", \\\"{x:1346,y:965,t:1527876816716};\\\", \\\"{x:1344,y:965,t:1527876820812};\\\", \\\"{x:1340,y:965,t:1527876820819};\\\", \\\"{x:1329,y:964,t:1527876820833};\\\", \\\"{x:1314,y:958,t:1527876820850};\\\", \\\"{x:1259,y:938,t:1527876820866};\\\", \\\"{x:1150,y:907,t:1527876820883};\\\", \\\"{x:1129,y:899,t:1527876820899};\\\", \\\"{x:1123,y:893,t:1527876820916};\\\", \\\"{x:1120,y:890,t:1527876820933};\\\", \\\"{x:1113,y:885,t:1527876820950};\\\", \\\"{x:1106,y:881,t:1527876820966};\\\", \\\"{x:1094,y:868,t:1527876820983};\\\", \\\"{x:1076,y:849,t:1527876820999};\\\", \\\"{x:1017,y:806,t:1527876821016};\\\", \\\"{x:947,y:757,t:1527876821034};\\\", \\\"{x:850,y:713,t:1527876821050};\\\", \\\"{x:763,y:665,t:1527876821067};\\\", \\\"{x:641,y:601,t:1527876821084};\\\", \\\"{x:571,y:562,t:1527876821099};\\\", \\\"{x:496,y:513,t:1527876821117};\\\", \\\"{x:438,y:476,t:1527876821133};\\\", \\\"{x:400,y:447,t:1527876821151};\\\", \\\"{x:392,y:440,t:1527876821166};\\\", \\\"{x:391,y:438,t:1527876821183};\\\", \\\"{x:392,y:435,t:1527876821200};\\\", \\\"{x:397,y:432,t:1527876821216};\\\", \\\"{x:401,y:430,t:1527876821233};\\\", \\\"{x:405,y:428,t:1527876821251};\\\", \\\"{x:408,y:428,t:1527876821266};\\\", \\\"{x:421,y:431,t:1527876821283};\\\", \\\"{x:440,y:451,t:1527876821300};\\\", \\\"{x:464,y:466,t:1527876821317};\\\", \\\"{x:499,y:480,t:1527876821333};\\\", \\\"{x:553,y:500,t:1527876821351};\\\", \\\"{x:577,y:507,t:1527876821366};\\\", \\\"{x:584,y:508,t:1527876821383};\\\", \\\"{x:584,y:510,t:1527876821459};\\\", \\\"{x:581,y:513,t:1527876821475};\\\", \\\"{x:575,y:516,t:1527876821483};\\\", \\\"{x:565,y:519,t:1527876821501};\\\", \\\"{x:544,y:524,t:1527876821516};\\\", \\\"{x:523,y:529,t:1527876821534};\\\", \\\"{x:502,y:533,t:1527876821550};\\\", \\\"{x:487,y:538,t:1527876821568};\\\", \\\"{x:471,y:545,t:1527876821583};\\\", \\\"{x:457,y:549,t:1527876821600};\\\", \\\"{x:443,y:556,t:1527876821617};\\\", \\\"{x:426,y:559,t:1527876821634};\\\", \\\"{x:401,y:563,t:1527876821651};\\\", \\\"{x:384,y:567,t:1527876821667};\\\", \\\"{x:376,y:568,t:1527876821683};\\\", \\\"{x:373,y:568,t:1527876821700};\\\", \\\"{x:371,y:569,t:1527876821717};\\\", \\\"{x:370,y:569,t:1527876821811};\\\", \\\"{x:369,y:566,t:1527876821819};\\\", \\\"{x:370,y:564,t:1527876821834};\\\", \\\"{x:373,y:562,t:1527876821852};\\\", \\\"{x:376,y:561,t:1527876821867};\\\", \\\"{x:377,y:561,t:1527876821891};\\\", \\\"{x:378,y:561,t:1527876821923};\\\", \\\"{x:380,y:560,t:1527876821934};\\\", \\\"{x:380,y:559,t:1527876821950};\\\", \\\"{x:384,y:558,t:1527876821968};\\\", \\\"{x:385,y:557,t:1527876821984};\\\", \\\"{x:386,y:556,t:1527876822000};\\\", \\\"{x:387,y:555,t:1527876822018};\\\", \\\"{x:390,y:554,t:1527876822074};\\\", \\\"{x:391,y:553,t:1527876822090};\\\", \\\"{x:392,y:552,t:1527876822170};\\\", \\\"{x:393,y:551,t:1527876822204};\\\", \\\"{x:388,y:551,t:1527876822417};\\\", \\\"{x:387,y:574,t:1527876822434};\\\", \\\"{x:385,y:581,t:1527876822451};\\\", \\\"{x:383,y:588,t:1527876822467};\\\", \\\"{x:383,y:592,t:1527876822484};\\\", \\\"{x:381,y:597,t:1527876822502};\\\", \\\"{x:381,y:598,t:1527876822517};\\\", \\\"{x:382,y:599,t:1527876822534};\\\", \\\"{x:382,y:600,t:1527876822551};\\\", \\\"{x:383,y:600,t:1527876822594};\\\", \\\"{x:384,y:600,t:1527876822627};\\\", \\\"{x:385,y:601,t:1527876822669};\\\", \\\"{x:387,y:603,t:1527876822684};\\\", \\\"{x:387,y:605,t:1527876822706};\\\", \\\"{x:387,y:607,t:1527876822723};\\\", \\\"{x:388,y:609,t:1527876822734};\\\", \\\"{x:388,y:610,t:1527876822751};\\\", \\\"{x:390,y:614,t:1527876822767};\\\", \\\"{x:391,y:616,t:1527876822784};\\\", \\\"{x:391,y:617,t:1527876822801};\\\", \\\"{x:391,y:618,t:1527876822818};\\\", \\\"{x:391,y:619,t:1527876822834};\\\", \\\"{x:391,y:620,t:1527876823043};\\\", \\\"{x:391,y:622,t:1527876823066};\\\", \\\"{x:391,y:625,t:1527876823074};\\\", \\\"{x:391,y:630,t:1527876823084};\\\", \\\"{x:391,y:636,t:1527876823102};\\\", \\\"{x:392,y:642,t:1527876823119};\\\", \\\"{x:394,y:645,t:1527876823135};\\\", \\\"{x:394,y:646,t:1527876823152};\\\", \\\"{x:399,y:654,t:1527876823168};\\\", \\\"{x:408,y:666,t:1527876823185};\\\", \\\"{x:416,y:682,t:1527876823202};\\\", \\\"{x:436,y:703,t:1527876823218};\\\", \\\"{x:443,y:717,t:1527876823234};\\\", \\\"{x:452,y:727,t:1527876823252};\\\", \\\"{x:462,y:735,t:1527876823269};\\\", \\\"{x:470,y:739,t:1527876823284};\\\", \\\"{x:474,y:741,t:1527876823301};\\\", \\\"{x:475,y:741,t:1527876823318};\\\", \\\"{x:478,y:740,t:1527876823335};\\\", \\\"{x:479,y:740,t:1527876823387};\\\", \\\"{x:481,y:737,t:1527876823401};\\\", \\\"{x:482,y:737,t:1527876823419};\\\", \\\"{x:483,y:737,t:1527876824212};\\\" ] }, { \\\"rt\\\": 10972, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 16, \\\"time_elapsed\\\": 444060, \\\"internal_node_id\\\": \\\"0.0-6.0-6.0\\\", \\\"subject\\\": \\\"7BW1K\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 12, \\\"clicks\\\": 1.5, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:484,y:735,t:1527876825394};\\\", \\\"{x:484,y:734,t:1527876825404};\\\", \\\"{x:489,y:709,t:1527876825544};\\\", \\\"{x:489,y:704,t:1527876825557};\\\", \\\"{x:489,y:701,t:1527876825570};\\\", \\\"{x:489,y:697,t:1527876825587};\\\", \\\"{x:486,y:694,t:1527876825603};\\\", \\\"{x:485,y:693,t:1527876825620};\\\", \\\"{x:484,y:692,t:1527876825636};\\\", \\\"{x:474,y:673,t:1527876825698};\\\", \\\"{x:467,y:662,t:1527876825704};\\\", \\\"{x:456,y:642,t:1527876825720};\\\", \\\"{x:440,y:624,t:1527876825737};\\\", \\\"{x:433,y:615,t:1527876825753};\\\", \\\"{x:405,y:622,t:1527876825770};\\\", \\\"{x:389,y:626,t:1527876825786};\\\", \\\"{x:381,y:626,t:1527876825803};\\\", \\\"{x:374,y:626,t:1527876825820};\\\", \\\"{x:373,y:626,t:1527876825837};\\\", \\\"{x:367,y:622,t:1527876825854};\\\", \\\"{x:363,y:614,t:1527876825871};\\\", \\\"{x:363,y:597,t:1527876825888};\\\", \\\"{x:366,y:581,t:1527876825904};\\\", \\\"{x:367,y:565,t:1527876825920};\\\", \\\"{x:367,y:550,t:1527876825938};\\\", \\\"{x:366,y:537,t:1527876825953};\\\", \\\"{x:369,y:529,t:1527876825970};\\\", \\\"{x:372,y:526,t:1527876825988};\\\", \\\"{x:374,y:524,t:1527876826004};\\\", \\\"{x:375,y:524,t:1527876826020};\\\", \\\"{x:376,y:524,t:1527876826037};\\\", \\\"{x:379,y:522,t:1527876826054};\\\", \\\"{x:380,y:521,t:1527876826071};\\\", \\\"{x:387,y:516,t:1527876826089};\\\", \\\"{x:396,y:509,t:1527876826103};\\\", \\\"{x:404,y:504,t:1527876826120};\\\", \\\"{x:421,y:498,t:1527876826137};\\\", \\\"{x:445,y:486,t:1527876826155};\\\", \\\"{x:462,y:477,t:1527876826170};\\\", \\\"{x:471,y:471,t:1527876826187};\\\", \\\"{x:475,y:468,t:1527876826204};\\\", \\\"{x:479,y:466,t:1527876826220};\\\", \\\"{x:482,y:464,t:1527876826238};\\\", \\\"{x:483,y:463,t:1527876826580};\\\", \\\"{x:486,y:461,t:1527876826588};\\\", \\\"{x:500,y:456,t:1527876826604};\\\", \\\"{x:516,y:455,t:1527876826621};\\\", \\\"{x:541,y:455,t:1527876826638};\\\", \\\"{x:577,y:458,t:1527876826655};\\\", \\\"{x:635,y:461,t:1527876826671};\\\", \\\"{x:699,y:471,t:1527876826689};\\\", \\\"{x:780,y:484,t:1527876826705};\\\", \\\"{x:825,y:492,t:1527876826722};\\\", \\\"{x:875,y:504,t:1527876826737};\\\", \\\"{x:918,y:512,t:1527876826754};\\\", \\\"{x:940,y:517,t:1527876826771};\\\", \\\"{x:956,y:521,t:1527876826788};\\\", \\\"{x:969,y:526,t:1527876826804};\\\", \\\"{x:986,y:529,t:1527876826822};\\\", \\\"{x:1003,y:534,t:1527876826837};\\\", \\\"{x:1019,y:539,t:1527876826855};\\\", \\\"{x:1038,y:548,t:1527876826872};\\\", \\\"{x:1057,y:550,t:1527876826888};\\\", \\\"{x:1075,y:554,t:1527876826905};\\\", \\\"{x:1089,y:555,t:1527876826921};\\\", \\\"{x:1098,y:559,t:1527876826938};\\\", \\\"{x:1133,y:569,t:1527876826955};\\\", \\\"{x:1158,y:579,t:1527876826972};\\\", \\\"{x:1178,y:586,t:1527876826988};\\\", \\\"{x:1196,y:596,t:1527876827005};\\\", \\\"{x:1213,y:604,t:1527876827022};\\\", \\\"{x:1219,y:607,t:1527876827038};\\\", \\\"{x:1223,y:611,t:1527876827055};\\\", \\\"{x:1230,y:617,t:1527876827072};\\\", \\\"{x:1241,y:623,t:1527876827087};\\\", \\\"{x:1244,y:626,t:1527876827105};\\\", \\\"{x:1246,y:630,t:1527876827123};\\\", \\\"{x:1249,y:634,t:1527876827138};\\\", \\\"{x:1257,y:646,t:1527876827155};\\\", \\\"{x:1263,y:654,t:1527876827172};\\\", \\\"{x:1269,y:663,t:1527876827187};\\\", \\\"{x:1278,y:672,t:1527876827204};\\\", \\\"{x:1282,y:678,t:1527876827222};\\\", \\\"{x:1282,y:679,t:1527876827239};\\\", \\\"{x:1284,y:681,t:1527876827255};\\\", \\\"{x:1284,y:683,t:1527876827291};\\\", \\\"{x:1288,y:683,t:1527876827305};\\\", \\\"{x:1297,y:689,t:1527876827322};\\\", \\\"{x:1309,y:694,t:1527876827339};\\\", \\\"{x:1323,y:698,t:1527876827355};\\\", \\\"{x:1334,y:700,t:1527876827372};\\\", \\\"{x:1339,y:700,t:1527876827389};\\\", \\\"{x:1344,y:700,t:1527876827407};\\\", \\\"{x:1348,y:700,t:1527876827422};\\\", \\\"{x:1351,y:699,t:1527876827438};\\\", \\\"{x:1352,y:698,t:1527876827458};\\\", \\\"{x:1353,y:698,t:1527876827514};\\\", \\\"{x:1353,y:697,t:1527876827651};\\\", \\\"{x:1352,y:697,t:1527876828420};\\\", \\\"{x:1351,y:697,t:1527876828435};\\\", \\\"{x:1350,y:698,t:1527876828459};\\\", \\\"{x:1348,y:698,t:1527876828547};\\\", \\\"{x:1347,y:698,t:1527876828595};\\\", \\\"{x:1347,y:699,t:1527876828606};\\\", \\\"{x:1345,y:700,t:1527876828900};\\\", \\\"{x:1344,y:701,t:1527876828931};\\\", \\\"{x:1343,y:702,t:1527876828981};\\\", \\\"{x:1338,y:704,t:1527876830474};\\\", \\\"{x:1314,y:717,t:1527876830490};\\\", \\\"{x:1290,y:727,t:1527876830507};\\\", \\\"{x:1266,y:736,t:1527876830524};\\\", \\\"{x:1229,y:740,t:1527876830541};\\\", \\\"{x:1206,y:742,t:1527876830558};\\\", \\\"{x:1175,y:740,t:1527876830574};\\\", \\\"{x:1144,y:738,t:1527876830591};\\\", \\\"{x:1096,y:736,t:1527876830608};\\\", \\\"{x:1033,y:723,t:1527876830623};\\\", \\\"{x:978,y:709,t:1527876830641};\\\", \\\"{x:949,y:698,t:1527876830658};\\\", \\\"{x:920,y:684,t:1527876830675};\\\", \\\"{x:904,y:678,t:1527876830690};\\\", \\\"{x:885,y:669,t:1527876830707};\\\", \\\"{x:864,y:663,t:1527876830724};\\\", \\\"{x:839,y:654,t:1527876830740};\\\", \\\"{x:828,y:647,t:1527876830758};\\\", \\\"{x:800,y:641,t:1527876830774};\\\", \\\"{x:756,y:630,t:1527876830792};\\\", \\\"{x:709,y:617,t:1527876830809};\\\", \\\"{x:667,y:605,t:1527876830821};\\\", \\\"{x:634,y:596,t:1527876830839};\\\", \\\"{x:609,y:589,t:1527876830855};\\\", \\\"{x:588,y:580,t:1527876830874};\\\", \\\"{x:576,y:576,t:1527876830891};\\\", \\\"{x:565,y:575,t:1527876830908};\\\", \\\"{x:556,y:575,t:1527876830924};\\\", \\\"{x:546,y:575,t:1527876830940};\\\", \\\"{x:508,y:575,t:1527876830957};\\\", \\\"{x:468,y:573,t:1527876830976};\\\", \\\"{x:436,y:573,t:1527876830990};\\\", \\\"{x:401,y:573,t:1527876831008};\\\", \\\"{x:379,y:569,t:1527876831025};\\\", \\\"{x:365,y:568,t:1527876831042};\\\", \\\"{x:352,y:566,t:1527876831057};\\\", \\\"{x:334,y:566,t:1527876831074};\\\", \\\"{x:322,y:566,t:1527876831092};\\\", \\\"{x:316,y:566,t:1527876831108};\\\", \\\"{x:312,y:566,t:1527876831125};\\\", \\\"{x:305,y:566,t:1527876831142};\\\", \\\"{x:291,y:566,t:1527876831158};\\\", \\\"{x:275,y:566,t:1527876831175};\\\", \\\"{x:261,y:566,t:1527876831195};\\\", \\\"{x:244,y:565,t:1527876831207};\\\", \\\"{x:229,y:565,t:1527876831224};\\\", \\\"{x:220,y:565,t:1527876831241};\\\", \\\"{x:212,y:566,t:1527876831257};\\\", \\\"{x:199,y:567,t:1527876831275};\\\", \\\"{x:192,y:569,t:1527876831292};\\\", \\\"{x:189,y:570,t:1527876831307};\\\", \\\"{x:187,y:570,t:1527876831324};\\\", \\\"{x:186,y:571,t:1527876831450};\\\", \\\"{x:186,y:572,t:1527876831458};\\\", \\\"{x:186,y:573,t:1527876831475};\\\", \\\"{x:189,y:576,t:1527876831491};\\\", \\\"{x:192,y:578,t:1527876831508};\\\", \\\"{x:196,y:579,t:1527876831526};\\\", \\\"{x:200,y:581,t:1527876831542};\\\", \\\"{x:203,y:582,t:1527876831559};\\\", \\\"{x:212,y:584,t:1527876831574};\\\", \\\"{x:228,y:586,t:1527876831592};\\\", \\\"{x:241,y:589,t:1527876831609};\\\", \\\"{x:257,y:590,t:1527876831625};\\\", \\\"{x:269,y:590,t:1527876831642};\\\", \\\"{x:301,y:588,t:1527876831661};\\\", \\\"{x:331,y:581,t:1527876831675};\\\", \\\"{x:362,y:564,t:1527876831691};\\\", \\\"{x:411,y:553,t:1527876831709};\\\", \\\"{x:470,y:543,t:1527876831725};\\\", \\\"{x:536,y:528,t:1527876831742};\\\", \\\"{x:600,y:517,t:1527876831759};\\\", \\\"{x:634,y:513,t:1527876831775};\\\", \\\"{x:650,y:511,t:1527876831791};\\\", \\\"{x:658,y:509,t:1527876831808};\\\", \\\"{x:671,y:507,t:1527876831825};\\\", \\\"{x:681,y:507,t:1527876831842};\\\", \\\"{x:700,y:507,t:1527876831858};\\\", \\\"{x:711,y:507,t:1527876831874};\\\", \\\"{x:714,y:507,t:1527876831891};\\\", \\\"{x:715,y:507,t:1527876831909};\\\", \\\"{x:718,y:507,t:1527876831938};\\\", \\\"{x:726,y:507,t:1527876831947};\\\", \\\"{x:735,y:511,t:1527876831958};\\\", \\\"{x:761,y:521,t:1527876831976};\\\", \\\"{x:780,y:529,t:1527876831992};\\\", \\\"{x:795,y:533,t:1527876832009};\\\", \\\"{x:800,y:533,t:1527876832026};\\\", \\\"{x:801,y:533,t:1527876832307};\\\", \\\"{x:802,y:533,t:1527876832323};\\\", \\\"{x:803,y:533,t:1527876832331};\\\", \\\"{x:804,y:533,t:1527876832341};\\\", \\\"{x:807,y:533,t:1527876832358};\\\", \\\"{x:808,y:533,t:1527876832376};\\\", \\\"{x:810,y:533,t:1527876832392};\\\", \\\"{x:812,y:532,t:1527876832409};\\\", \\\"{x:813,y:532,t:1527876832425};\\\", \\\"{x:816,y:532,t:1527876832442};\\\", \\\"{x:817,y:532,t:1527876832458};\\\", \\\"{x:819,y:532,t:1527876832475};\\\", \\\"{x:820,y:532,t:1527876832493};\\\", \\\"{x:821,y:532,t:1527876832747};\\\", \\\"{x:821,y:533,t:1527876832770};\\\", \\\"{x:819,y:534,t:1527876832779};\\\", \\\"{x:818,y:534,t:1527876832793};\\\", \\\"{x:812,y:537,t:1527876832809};\\\", \\\"{x:810,y:538,t:1527876832826};\\\", \\\"{x:795,y:544,t:1527876832843};\\\", \\\"{x:773,y:557,t:1527876832861};\\\", \\\"{x:753,y:566,t:1527876832876};\\\", \\\"{x:736,y:573,t:1527876832891};\\\", \\\"{x:727,y:580,t:1527876832908};\\\", \\\"{x:719,y:584,t:1527876832925};\\\", \\\"{x:714,y:587,t:1527876832942};\\\", \\\"{x:711,y:590,t:1527876832959};\\\", \\\"{x:709,y:591,t:1527876832976};\\\", \\\"{x:708,y:591,t:1527876832993};\\\", \\\"{x:712,y:590,t:1527876833051};\\\", \\\"{x:718,y:587,t:1527876833060};\\\", \\\"{x:728,y:578,t:1527876833077};\\\", \\\"{x:739,y:573,t:1527876833093};\\\", \\\"{x:749,y:569,t:1527876833109};\\\", \\\"{x:753,y:567,t:1527876833125};\\\", \\\"{x:755,y:566,t:1527876833143};\\\", \\\"{x:761,y:564,t:1527876833160};\\\", \\\"{x:768,y:561,t:1527876833177};\\\", \\\"{x:779,y:557,t:1527876833192};\\\", \\\"{x:788,y:555,t:1527876833210};\\\", \\\"{x:805,y:550,t:1527876833226};\\\", \\\"{x:817,y:548,t:1527876833243};\\\", \\\"{x:823,y:547,t:1527876833260};\\\", \\\"{x:830,y:546,t:1527876833277};\\\", \\\"{x:834,y:546,t:1527876833293};\\\", \\\"{x:835,y:546,t:1527876833309};\\\", \\\"{x:837,y:546,t:1527876833346};\\\", \\\"{x:838,y:546,t:1527876833360};\\\", \\\"{x:840,y:545,t:1527876833377};\\\", \\\"{x:840,y:544,t:1527876833393};\\\", \\\"{x:839,y:544,t:1527876833843};\\\", \\\"{x:837,y:544,t:1527876833882};\\\", \\\"{x:835,y:544,t:1527876833893};\\\", \\\"{x:828,y:550,t:1527876833910};\\\", \\\"{x:817,y:558,t:1527876833928};\\\", \\\"{x:800,y:568,t:1527876833943};\\\", \\\"{x:784,y:577,t:1527876833959};\\\", \\\"{x:759,y:590,t:1527876833976};\\\", \\\"{x:742,y:598,t:1527876833995};\\\", \\\"{x:733,y:603,t:1527876834010};\\\", \\\"{x:730,y:605,t:1527876834027};\\\", \\\"{x:725,y:609,t:1527876834044};\\\", \\\"{x:719,y:616,t:1527876834061};\\\", \\\"{x:705,y:626,t:1527876834076};\\\", \\\"{x:693,y:635,t:1527876834094};\\\", \\\"{x:678,y:646,t:1527876834110};\\\", \\\"{x:660,y:656,t:1527876834126};\\\", \\\"{x:644,y:666,t:1527876834143};\\\", \\\"{x:633,y:673,t:1527876834161};\\\", \\\"{x:623,y:680,t:1527876834177};\\\", \\\"{x:615,y:685,t:1527876834194};\\\", \\\"{x:602,y:692,t:1527876834211};\\\", \\\"{x:594,y:697,t:1527876834226};\\\", \\\"{x:587,y:700,t:1527876834244};\\\", \\\"{x:581,y:702,t:1527876834261};\\\", \\\"{x:576,y:704,t:1527876834277};\\\", \\\"{x:570,y:708,t:1527876834294};\\\", \\\"{x:563,y:709,t:1527876834311};\\\", \\\"{x:552,y:714,t:1527876834326};\\\", \\\"{x:544,y:719,t:1527876834344};\\\", \\\"{x:535,y:722,t:1527876834361};\\\", \\\"{x:527,y:726,t:1527876834377};\\\", \\\"{x:522,y:727,t:1527876834394};\\\", \\\"{x:509,y:730,t:1527876834410};\\\", \\\"{x:505,y:732,t:1527876834428};\\\", \\\"{x:504,y:733,t:1527876834444};\\\", \\\"{x:503,y:734,t:1527876834499};\\\", \\\"{x:502,y:734,t:1527876834511};\\\", \\\"{x:499,y:735,t:1527876834527};\\\", \\\"{x:498,y:735,t:1527876834544};\\\", \\\"{x:496,y:736,t:1527876834561};\\\", \\\"{x:495,y:737,t:1527876834667};\\\" ] }, { \\\"rt\\\": 11295, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 17, \\\"time_elapsed\\\": 456583, \\\"internal_node_id\\\": \\\"0.0-6.0-7.0\\\", \\\"subject\\\": \\\"7BW1K\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 13, \\\"clicks\\\": 2, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"E\\\", \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-X -Z \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:496,y:713,t:1527876838077};\\\", \\\"{x:504,y:664,t:1527876838097};\\\", \\\"{x:504,y:657,t:1527876838114};\\\", \\\"{x:498,y:636,t:1527876838130};\\\", \\\"{x:490,y:619,t:1527876838148};\\\", \\\"{x:486,y:609,t:1527876838164};\\\", \\\"{x:484,y:603,t:1527876838180};\\\", \\\"{x:482,y:593,t:1527876838198};\\\", \\\"{x:480,y:585,t:1527876838213};\\\", \\\"{x:478,y:580,t:1527876838230};\\\", \\\"{x:476,y:576,t:1527876838246};\\\", \\\"{x:474,y:574,t:1527876838263};\\\", \\\"{x:474,y:573,t:1527876838280};\\\", \\\"{x:473,y:573,t:1527876838298};\\\", \\\"{x:472,y:571,t:1527876838365};\\\", \\\"{x:466,y:565,t:1527876838381};\\\", \\\"{x:449,y:550,t:1527876838397};\\\", \\\"{x:423,y:535,t:1527876838414};\\\", \\\"{x:391,y:522,t:1527876838431};\\\", \\\"{x:373,y:514,t:1527876838447};\\\", \\\"{x:365,y:511,t:1527876838464};\\\", \\\"{x:362,y:509,t:1527876838481};\\\", \\\"{x:361,y:507,t:1527876838497};\\\", \\\"{x:359,y:497,t:1527876838513};\\\", \\\"{x:359,y:490,t:1527876838530};\\\", \\\"{x:359,y:482,t:1527876838547};\\\", \\\"{x:359,y:477,t:1527876838564};\\\", \\\"{x:363,y:469,t:1527876838581};\\\", \\\"{x:372,y:462,t:1527876838596};\\\", \\\"{x:384,y:454,t:1527876838614};\\\", \\\"{x:397,y:449,t:1527876838630};\\\", \\\"{x:408,y:444,t:1527876838647};\\\", \\\"{x:412,y:441,t:1527876838664};\\\", \\\"{x:417,y:440,t:1527876838680};\\\", \\\"{x:425,y:439,t:1527876838697};\\\", \\\"{x:433,y:439,t:1527876838714};\\\", \\\"{x:441,y:437,t:1527876838730};\\\", \\\"{x:447,y:437,t:1527876838747};\\\", \\\"{x:450,y:437,t:1527876838764};\\\", \\\"{x:451,y:437,t:1527876838780};\\\", \\\"{x:452,y:437,t:1527876838797};\\\", \\\"{x:453,y:437,t:1527876838835};\\\", \\\"{x:455,y:437,t:1527876838847};\\\", \\\"{x:457,y:437,t:1527876838865};\\\", \\\"{x:459,y:436,t:1527876838880};\\\", \\\"{x:460,y:436,t:1527876838907};\\\", \\\"{x:461,y:436,t:1527876838915};\\\", \\\"{x:462,y:436,t:1527876838930};\\\", \\\"{x:464,y:436,t:1527876838947};\\\", \\\"{x:466,y:436,t:1527876838964};\\\", \\\"{x:468,y:436,t:1527876838979};\\\", \\\"{x:469,y:436,t:1527876838997};\\\", \\\"{x:472,y:436,t:1527876839014};\\\", \\\"{x:478,y:438,t:1527876839030};\\\", \\\"{x:482,y:440,t:1527876839047};\\\", \\\"{x:486,y:442,t:1527876839064};\\\", \\\"{x:489,y:445,t:1527876839080};\\\", \\\"{x:491,y:445,t:1527876839097};\\\", \\\"{x:491,y:446,t:1527876839123};\\\", \\\"{x:492,y:446,t:1527876839147};\\\", \\\"{x:493,y:447,t:1527876839164};\\\", \\\"{x:495,y:447,t:1527876839563};\\\", \\\"{x:497,y:447,t:1527876839580};\\\", \\\"{x:500,y:447,t:1527876839597};\\\", \\\"{x:502,y:447,t:1527876839614};\\\", \\\"{x:506,y:447,t:1527876839631};\\\", \\\"{x:508,y:447,t:1527876839648};\\\", \\\"{x:513,y:447,t:1527876839663};\\\", \\\"{x:517,y:446,t:1527876839681};\\\", \\\"{x:525,y:446,t:1527876839697};\\\", \\\"{x:535,y:446,t:1527876839714};\\\", \\\"{x:548,y:446,t:1527876839731};\\\", \\\"{x:552,y:446,t:1527876839747};\\\", \\\"{x:559,y:445,t:1527876839764};\\\", \\\"{x:562,y:445,t:1527876839781};\\\", \\\"{x:564,y:444,t:1527876839797};\\\", \\\"{x:566,y:444,t:1527876839814};\\\", \\\"{x:569,y:443,t:1527876839830};\\\", \\\"{x:572,y:443,t:1527876839848};\\\", \\\"{x:577,y:442,t:1527876839863};\\\", \\\"{x:580,y:442,t:1527876839880};\\\", \\\"{x:583,y:442,t:1527876839898};\\\", \\\"{x:584,y:442,t:1527876839915};\\\", \\\"{x:584,y:443,t:1527876840011};\\\", \\\"{x:583,y:444,t:1527876840019};\\\", \\\"{x:582,y:445,t:1527876840031};\\\", \\\"{x:578,y:448,t:1527876840046};\\\", \\\"{x:572,y:452,t:1527876840063};\\\", \\\"{x:563,y:463,t:1527876840081};\\\", \\\"{x:555,y:472,t:1527876840097};\\\", \\\"{x:536,y:486,t:1527876840114};\\\", \\\"{x:503,y:507,t:1527876840132};\\\", \\\"{x:483,y:517,t:1527876840146};\\\", \\\"{x:471,y:522,t:1527876840165};\\\", \\\"{x:464,y:526,t:1527876840182};\\\", \\\"{x:463,y:527,t:1527876840199};\\\", \\\"{x:462,y:529,t:1527876840215};\\\", \\\"{x:457,y:533,t:1527876840232};\\\", \\\"{x:448,y:537,t:1527876840249};\\\", \\\"{x:443,y:539,t:1527876840265};\\\", \\\"{x:434,y:545,t:1527876840281};\\\", \\\"{x:427,y:550,t:1527876840299};\\\", \\\"{x:426,y:550,t:1527876840315};\\\", \\\"{x:425,y:551,t:1527876840331};\\\", \\\"{x:424,y:553,t:1527876840349};\\\", \\\"{x:423,y:554,t:1527876840364};\\\", \\\"{x:421,y:554,t:1527876840382};\\\", \\\"{x:421,y:555,t:1527876840399};\\\", \\\"{x:419,y:556,t:1527876840416};\\\", \\\"{x:418,y:557,t:1527876840432};\\\", \\\"{x:417,y:558,t:1527876840449};\\\", \\\"{x:415,y:561,t:1527876840466};\\\", \\\"{x:414,y:562,t:1527876840482};\\\", \\\"{x:412,y:564,t:1527876840500};\\\", \\\"{x:412,y:565,t:1527876840516};\\\", \\\"{x:411,y:566,t:1527876840533};\\\", \\\"{x:411,y:567,t:1527876840549};\\\", \\\"{x:412,y:567,t:1527876840635};\\\", \\\"{x:415,y:567,t:1527876840649};\\\", \\\"{x:428,y:564,t:1527876840667};\\\", \\\"{x:437,y:563,t:1527876840683};\\\", \\\"{x:480,y:562,t:1527876840701};\\\", \\\"{x:536,y:562,t:1527876840715};\\\", \\\"{x:600,y:562,t:1527876840732};\\\", \\\"{x:676,y:560,t:1527876840749};\\\", \\\"{x:740,y:560,t:1527876840766};\\\", \\\"{x:782,y:561,t:1527876840781};\\\", \\\"{x:833,y:561,t:1527876840799};\\\", \\\"{x:875,y:554,t:1527876840816};\\\", \\\"{x:914,y:551,t:1527876840831};\\\", \\\"{x:939,y:547,t:1527876840849};\\\", \\\"{x:987,y:538,t:1527876840867};\\\", \\\"{x:1012,y:535,t:1527876840882};\\\", \\\"{x:1029,y:532,t:1527876840900};\\\", \\\"{x:1040,y:532,t:1527876840916};\\\", \\\"{x:1054,y:530,t:1527876840932};\\\", \\\"{x:1064,y:527,t:1527876840949};\\\", \\\"{x:1067,y:526,t:1527876840966};\\\", \\\"{x:1077,y:523,t:1527876840983};\\\", \\\"{x:1085,y:522,t:1527876840999};\\\", \\\"{x:1109,y:521,t:1527876841017};\\\", \\\"{x:1130,y:521,t:1527876841033};\\\", \\\"{x:1149,y:521,t:1527876841050};\\\", \\\"{x:1175,y:519,t:1527876841067};\\\", \\\"{x:1204,y:518,t:1527876841083};\\\", \\\"{x:1235,y:518,t:1527876841099};\\\", \\\"{x:1252,y:511,t:1527876841116};\\\", \\\"{x:1261,y:511,t:1527876841133};\\\", \\\"{x:1269,y:507,t:1527876841149};\\\", \\\"{x:1271,y:504,t:1527876841166};\\\", \\\"{x:1274,y:499,t:1527876841184};\\\", \\\"{x:1281,y:489,t:1527876841199};\\\", \\\"{x:1295,y:465,t:1527876841216};\\\", \\\"{x:1318,y:439,t:1527876841233};\\\", \\\"{x:1329,y:431,t:1527876841250};\\\", \\\"{x:1368,y:397,t:1527876841266};\\\", \\\"{x:1394,y:378,t:1527876841283};\\\", \\\"{x:1402,y:364,t:1527876841300};\\\", \\\"{x:1408,y:358,t:1527876841317};\\\", \\\"{x:1408,y:357,t:1527876841333};\\\", \\\"{x:1409,y:356,t:1527876841371};\\\", \\\"{x:1409,y:360,t:1527876841444};\\\", \\\"{x:1406,y:367,t:1527876841451};\\\", \\\"{x:1399,y:386,t:1527876841467};\\\", \\\"{x:1393,y:403,t:1527876841484};\\\", \\\"{x:1383,y:421,t:1527876841500};\\\", \\\"{x:1377,y:435,t:1527876841517};\\\", \\\"{x:1365,y:461,t:1527876841534};\\\", \\\"{x:1354,y:482,t:1527876841551};\\\", \\\"{x:1348,y:504,t:1527876841566};\\\", \\\"{x:1342,y:520,t:1527876841584};\\\", \\\"{x:1337,y:535,t:1527876841601};\\\", \\\"{x:1334,y:543,t:1527876841617};\\\", \\\"{x:1330,y:555,t:1527876841633};\\\", \\\"{x:1325,y:568,t:1527876841651};\\\", \\\"{x:1323,y:576,t:1527876841667};\\\", \\\"{x:1321,y:581,t:1527876841683};\\\", \\\"{x:1319,y:588,t:1527876841701};\\\", \\\"{x:1317,y:593,t:1527876841717};\\\", \\\"{x:1315,y:600,t:1527876841733};\\\", \\\"{x:1313,y:604,t:1527876841750};\\\", \\\"{x:1311,y:612,t:1527876841767};\\\", \\\"{x:1309,y:621,t:1527876841784};\\\", \\\"{x:1305,y:633,t:1527876841800};\\\", \\\"{x:1303,y:642,t:1527876841817};\\\", \\\"{x:1298,y:653,t:1527876841834};\\\", \\\"{x:1290,y:675,t:1527876841851};\\\", \\\"{x:1283,y:689,t:1527876841867};\\\", \\\"{x:1277,y:706,t:1527876841884};\\\", \\\"{x:1267,y:726,t:1527876841901};\\\", \\\"{x:1256,y:746,t:1527876841918};\\\", \\\"{x:1248,y:762,t:1527876841933};\\\", \\\"{x:1240,y:773,t:1527876841951};\\\", \\\"{x:1239,y:779,t:1527876841968};\\\", \\\"{x:1237,y:785,t:1527876841984};\\\", \\\"{x:1237,y:787,t:1527876842001};\\\", \\\"{x:1237,y:792,t:1527876842017};\\\", \\\"{x:1237,y:796,t:1527876842033};\\\", \\\"{x:1239,y:803,t:1527876842051};\\\", \\\"{x:1244,y:807,t:1527876842067};\\\", \\\"{x:1249,y:811,t:1527876842084};\\\", \\\"{x:1251,y:812,t:1527876842100};\\\", \\\"{x:1255,y:814,t:1527876842118};\\\", \\\"{x:1259,y:814,t:1527876842134};\\\", \\\"{x:1267,y:814,t:1527876842151};\\\", \\\"{x:1275,y:814,t:1527876842168};\\\", \\\"{x:1285,y:815,t:1527876842183};\\\", \\\"{x:1305,y:818,t:1527876842200};\\\", \\\"{x:1320,y:821,t:1527876842217};\\\", \\\"{x:1338,y:826,t:1527876842235};\\\", \\\"{x:1341,y:827,t:1527876842251};\\\", \\\"{x:1345,y:828,t:1527876842268};\\\", \\\"{x:1351,y:828,t:1527876842284};\\\", \\\"{x:1366,y:830,t:1527876842300};\\\", \\\"{x:1371,y:833,t:1527876842318};\\\", \\\"{x:1377,y:834,t:1527876842335};\\\", \\\"{x:1382,y:834,t:1527876842350};\\\", \\\"{x:1386,y:834,t:1527876842368};\\\", \\\"{x:1391,y:834,t:1527876842385};\\\", \\\"{x:1398,y:834,t:1527876842400};\\\", \\\"{x:1403,y:833,t:1527876842418};\\\", \\\"{x:1421,y:831,t:1527876842435};\\\", \\\"{x:1427,y:830,t:1527876842450};\\\", \\\"{x:1439,y:828,t:1527876842468};\\\", \\\"{x:1445,y:827,t:1527876842485};\\\", \\\"{x:1457,y:824,t:1527876842500};\\\", \\\"{x:1471,y:820,t:1527876842517};\\\", \\\"{x:1478,y:818,t:1527876842534};\\\", \\\"{x:1482,y:816,t:1527876842552};\\\", \\\"{x:1489,y:813,t:1527876842568};\\\", \\\"{x:1497,y:809,t:1527876842585};\\\", \\\"{x:1504,y:808,t:1527876842602};\\\", \\\"{x:1513,y:804,t:1527876842618};\\\", \\\"{x:1526,y:799,t:1527876842635};\\\", \\\"{x:1534,y:796,t:1527876842651};\\\", \\\"{x:1541,y:795,t:1527876842668};\\\", \\\"{x:1548,y:795,t:1527876842685};\\\", \\\"{x:1553,y:794,t:1527876842702};\\\", \\\"{x:1558,y:792,t:1527876842717};\\\", \\\"{x:1560,y:792,t:1527876842735};\\\", \\\"{x:1562,y:792,t:1527876842751};\\\", \\\"{x:1563,y:792,t:1527876842770};\\\", \\\"{x:1566,y:792,t:1527876842784};\\\", \\\"{x:1569,y:793,t:1527876842801};\\\", \\\"{x:1578,y:797,t:1527876842817};\\\", \\\"{x:1585,y:799,t:1527876842833};\\\", \\\"{x:1591,y:800,t:1527876842851};\\\", \\\"{x:1596,y:801,t:1527876842868};\\\", \\\"{x:1598,y:801,t:1527876842884};\\\", \\\"{x:1600,y:801,t:1527876842901};\\\", \\\"{x:1602,y:801,t:1527876843051};\\\", \\\"{x:1602,y:800,t:1527876843068};\\\", \\\"{x:1604,y:796,t:1527876843085};\\\", \\\"{x:1604,y:793,t:1527876843102};\\\", \\\"{x:1607,y:788,t:1527876843119};\\\", \\\"{x:1607,y:785,t:1527876843135};\\\", \\\"{x:1608,y:777,t:1527876843152};\\\", \\\"{x:1609,y:769,t:1527876843169};\\\", \\\"{x:1609,y:760,t:1527876843184};\\\", \\\"{x:1609,y:752,t:1527876843202};\\\", \\\"{x:1609,y:738,t:1527876843219};\\\", \\\"{x:1607,y:730,t:1527876843235};\\\", \\\"{x:1607,y:726,t:1527876843252};\\\", \\\"{x:1606,y:723,t:1527876843269};\\\", \\\"{x:1606,y:720,t:1527876843285};\\\", \\\"{x:1606,y:716,t:1527876843302};\\\", \\\"{x:1606,y:715,t:1527876843318};\\\", \\\"{x:1608,y:712,t:1527876843335};\\\", \\\"{x:1610,y:708,t:1527876843352};\\\", \\\"{x:1612,y:702,t:1527876843369};\\\", \\\"{x:1613,y:698,t:1527876843388};\\\", \\\"{x:1615,y:696,t:1527876843401};\\\", \\\"{x:1615,y:694,t:1527876843418};\\\", \\\"{x:1614,y:696,t:1527876843739};\\\", \\\"{x:1613,y:699,t:1527876843751};\\\", \\\"{x:1611,y:702,t:1527876843769};\\\", \\\"{x:1609,y:705,t:1527876843785};\\\", \\\"{x:1607,y:708,t:1527876843803};\\\", \\\"{x:1606,y:709,t:1527876843818};\\\", \\\"{x:1605,y:711,t:1527876843835};\\\", \\\"{x:1604,y:715,t:1527876843853};\\\", \\\"{x:1603,y:717,t:1527876843868};\\\", \\\"{x:1601,y:722,t:1527876843886};\\\", \\\"{x:1599,y:727,t:1527876843902};\\\", \\\"{x:1597,y:733,t:1527876843919};\\\", \\\"{x:1596,y:739,t:1527876843936};\\\", \\\"{x:1592,y:746,t:1527876843953};\\\", \\\"{x:1588,y:754,t:1527876843969};\\\", \\\"{x:1584,y:761,t:1527876843986};\\\", \\\"{x:1581,y:765,t:1527876844003};\\\", \\\"{x:1579,y:771,t:1527876844019};\\\", \\\"{x:1577,y:777,t:1527876844036};\\\", \\\"{x:1575,y:781,t:1527876844053};\\\", \\\"{x:1573,y:788,t:1527876844068};\\\", \\\"{x:1571,y:794,t:1527876844086};\\\", \\\"{x:1569,y:797,t:1527876844102};\\\", \\\"{x:1566,y:804,t:1527876844119};\\\", \\\"{x:1562,y:812,t:1527876844136};\\\", \\\"{x:1559,y:820,t:1527876844152};\\\", \\\"{x:1553,y:829,t:1527876844168};\\\", \\\"{x:1551,y:832,t:1527876844185};\\\", \\\"{x:1544,y:849,t:1527876844202};\\\", \\\"{x:1538,y:859,t:1527876844219};\\\", \\\"{x:1532,y:869,t:1527876844235};\\\", \\\"{x:1529,y:877,t:1527876844253};\\\", \\\"{x:1524,y:886,t:1527876844269};\\\", \\\"{x:1519,y:893,t:1527876844285};\\\", \\\"{x:1517,y:896,t:1527876844303};\\\", \\\"{x:1516,y:899,t:1527876844319};\\\", \\\"{x:1514,y:901,t:1527876844335};\\\", \\\"{x:1514,y:902,t:1527876844352};\\\", \\\"{x:1512,y:905,t:1527876844370};\\\", \\\"{x:1510,y:907,t:1527876844386};\\\", \\\"{x:1508,y:912,t:1527876844403};\\\", \\\"{x:1505,y:914,t:1527876844419};\\\", \\\"{x:1503,y:917,t:1527876844436};\\\", \\\"{x:1502,y:921,t:1527876844453};\\\", \\\"{x:1500,y:925,t:1527876844470};\\\", \\\"{x:1499,y:931,t:1527876844486};\\\", \\\"{x:1498,y:935,t:1527876844502};\\\", \\\"{x:1496,y:938,t:1527876844520};\\\", \\\"{x:1496,y:940,t:1527876844536};\\\", \\\"{x:1495,y:942,t:1527876844553};\\\", \\\"{x:1492,y:945,t:1527876844570};\\\", \\\"{x:1491,y:947,t:1527876844587};\\\", \\\"{x:1488,y:949,t:1527876844603};\\\", \\\"{x:1488,y:950,t:1527876844627};\\\", \\\"{x:1487,y:950,t:1527876844923};\\\", \\\"{x:1486,y:948,t:1527876844937};\\\", \\\"{x:1482,y:941,t:1527876844953};\\\", \\\"{x:1477,y:935,t:1527876844970};\\\", \\\"{x:1469,y:920,t:1527876844987};\\\", \\\"{x:1465,y:911,t:1527876845003};\\\", \\\"{x:1460,y:900,t:1527876845020};\\\", \\\"{x:1446,y:881,t:1527876845037};\\\", \\\"{x:1429,y:860,t:1527876845054};\\\", \\\"{x:1417,y:846,t:1527876845070};\\\", \\\"{x:1402,y:833,t:1527876845087};\\\", \\\"{x:1399,y:826,t:1527876845104};\\\", \\\"{x:1398,y:824,t:1527876845120};\\\", \\\"{x:1398,y:822,t:1527876845137};\\\", \\\"{x:1398,y:821,t:1527876845154};\\\", \\\"{x:1398,y:820,t:1527876845170};\\\", \\\"{x:1393,y:809,t:1527876845186};\\\", \\\"{x:1386,y:796,t:1527876845203};\\\", \\\"{x:1377,y:780,t:1527876845220};\\\", \\\"{x:1366,y:758,t:1527876845237};\\\", \\\"{x:1359,y:745,t:1527876845254};\\\", \\\"{x:1345,y:725,t:1527876845270};\\\", \\\"{x:1334,y:703,t:1527876845287};\\\", \\\"{x:1320,y:682,t:1527876845304};\\\", \\\"{x:1307,y:660,t:1527876845320};\\\", \\\"{x:1289,y:638,t:1527876845337};\\\", \\\"{x:1271,y:620,t:1527876845354};\\\", \\\"{x:1253,y:605,t:1527876845370};\\\", \\\"{x:1199,y:572,t:1527876845387};\\\", \\\"{x:1166,y:552,t:1527876845403};\\\", \\\"{x:1124,y:533,t:1527876845421};\\\", \\\"{x:1075,y:512,t:1527876845437};\\\", \\\"{x:1018,y:492,t:1527876845454};\\\", \\\"{x:961,y:480,t:1527876845471};\\\", \\\"{x:931,y:476,t:1527876845486};\\\", \\\"{x:905,y:476,t:1527876845504};\\\", \\\"{x:878,y:479,t:1527876845521};\\\", \\\"{x:850,y:483,t:1527876845536};\\\", \\\"{x:830,y:489,t:1527876845555};\\\", \\\"{x:791,y:496,t:1527876845570};\\\", \\\"{x:776,y:498,t:1527876845586};\\\", \\\"{x:760,y:501,t:1527876845603};\\\", \\\"{x:751,y:501,t:1527876845620};\\\", \\\"{x:747,y:501,t:1527876845636};\\\", \\\"{x:740,y:501,t:1527876845653};\\\", \\\"{x:734,y:502,t:1527876845670};\\\", \\\"{x:726,y:502,t:1527876845686};\\\", \\\"{x:717,y:503,t:1527876845704};\\\", \\\"{x:707,y:504,t:1527876845721};\\\", \\\"{x:681,y:505,t:1527876845736};\\\", \\\"{x:656,y:505,t:1527876845753};\\\", \\\"{x:621,y:506,t:1527876845770};\\\", \\\"{x:606,y:508,t:1527876845786};\\\", \\\"{x:604,y:508,t:1527876845803};\\\", \\\"{x:603,y:508,t:1527876845890};\\\", \\\"{x:602,y:509,t:1527876845903};\\\", \\\"{x:600,y:510,t:1527876845920};\\\", \\\"{x:598,y:513,t:1527876845937};\\\", \\\"{x:597,y:517,t:1527876845953};\\\", \\\"{x:594,y:523,t:1527876845971};\\\", \\\"{x:593,y:528,t:1527876845987};\\\", \\\"{x:594,y:527,t:1527876846178};\\\", \\\"{x:596,y:527,t:1527876846187};\\\", \\\"{x:598,y:525,t:1527876846203};\\\", \\\"{x:601,y:524,t:1527876846222};\\\", \\\"{x:602,y:523,t:1527876846237};\\\", \\\"{x:603,y:522,t:1527876846253};\\\", \\\"{x:605,y:521,t:1527876846270};\\\", \\\"{x:605,y:520,t:1527876846290};\\\", \\\"{x:606,y:519,t:1527876846303};\\\", \\\"{x:606,y:518,t:1527876846322};\\\", \\\"{x:608,y:518,t:1527876846337};\\\", \\\"{x:611,y:515,t:1527876846354};\\\", \\\"{x:612,y:513,t:1527876846370};\\\", \\\"{x:615,y:508,t:1527876846387};\\\", \\\"{x:615,y:507,t:1527876846403};\\\", \\\"{x:616,y:505,t:1527876846420};\\\", \\\"{x:616,y:504,t:1527876846625};\\\", \\\"{x:618,y:500,t:1527876846637};\\\", \\\"{x:621,y:500,t:1527876846654};\\\", \\\"{x:622,y:499,t:1527876846698};\\\", \\\"{x:624,y:497,t:1527876846706};\\\", \\\"{x:629,y:497,t:1527876846720};\\\", \\\"{x:638,y:492,t:1527876846737};\\\", \\\"{x:653,y:488,t:1527876846755};\\\", \\\"{x:661,y:485,t:1527876846771};\\\", \\\"{x:673,y:481,t:1527876846787};\\\", \\\"{x:694,y:477,t:1527876846804};\\\", \\\"{x:718,y:473,t:1527876846820};\\\", \\\"{x:763,y:473,t:1527876846837};\\\", \\\"{x:783,y:474,t:1527876846855};\\\", \\\"{x:788,y:475,t:1527876846870};\\\", \\\"{x:796,y:479,t:1527876846887};\\\", \\\"{x:796,y:480,t:1527876846923};\\\", \\\"{x:795,y:480,t:1527876846946};\\\", \\\"{x:793,y:482,t:1527876846971};\\\", \\\"{x:793,y:484,t:1527876846987};\\\", \\\"{x:793,y:485,t:1527876847005};\\\", \\\"{x:791,y:486,t:1527876847035};\\\", \\\"{x:791,y:488,t:1527876847044};\\\", \\\"{x:791,y:490,t:1527876847054};\\\", \\\"{x:791,y:494,t:1527876847071};\\\", \\\"{x:792,y:499,t:1527876847087};\\\", \\\"{x:792,y:502,t:1527876847104};\\\", \\\"{x:795,y:506,t:1527876847121};\\\", \\\"{x:801,y:514,t:1527876847137};\\\", \\\"{x:811,y:519,t:1527876847154};\\\", \\\"{x:812,y:520,t:1527876847171};\\\", \\\"{x:814,y:520,t:1527876847187};\\\", \\\"{x:815,y:520,t:1527876847204};\\\", \\\"{x:817,y:520,t:1527876847221};\\\", \\\"{x:818,y:520,t:1527876847237};\\\", \\\"{x:820,y:520,t:1527876847266};\\\", \\\"{x:821,y:520,t:1527876847290};\\\", \\\"{x:822,y:520,t:1527876847304};\\\", \\\"{x:823,y:520,t:1527876847321};\\\", \\\"{x:824,y:520,t:1527876847378};\\\", \\\"{x:826,y:520,t:1527876847418};\\\", \\\"{x:827,y:519,t:1527876847434};\\\", \\\"{x:829,y:516,t:1527876847442};\\\", \\\"{x:831,y:514,t:1527876847455};\\\", \\\"{x:832,y:513,t:1527876847491};\\\", \\\"{x:834,y:511,t:1527876847515};\\\", \\\"{x:834,y:509,t:1527876847539};\\\", \\\"{x:835,y:504,t:1527876847554};\\\", \\\"{x:836,y:503,t:1527876847571};\\\", \\\"{x:833,y:503,t:1527876847762};\\\", \\\"{x:828,y:508,t:1527876847771};\\\", \\\"{x:817,y:519,t:1527876847789};\\\", \\\"{x:807,y:533,t:1527876847806};\\\", \\\"{x:803,y:542,t:1527876847821};\\\", \\\"{x:791,y:558,t:1527876847839};\\\", \\\"{x:779,y:573,t:1527876847855};\\\", \\\"{x:766,y:586,t:1527876847871};\\\", \\\"{x:746,y:603,t:1527876847889};\\\", \\\"{x:723,y:614,t:1527876847907};\\\", \\\"{x:702,y:623,t:1527876847921};\\\", \\\"{x:665,y:639,t:1527876847938};\\\", \\\"{x:651,y:648,t:1527876847955};\\\", \\\"{x:636,y:652,t:1527876847971};\\\", \\\"{x:624,y:658,t:1527876847988};\\\", \\\"{x:617,y:662,t:1527876848006};\\\", \\\"{x:596,y:673,t:1527876848021};\\\", \\\"{x:575,y:679,t:1527876848038};\\\", \\\"{x:560,y:686,t:1527876848055};\\\", \\\"{x:545,y:694,t:1527876848072};\\\", \\\"{x:536,y:697,t:1527876848089};\\\", \\\"{x:532,y:700,t:1527876848105};\\\", \\\"{x:529,y:702,t:1527876848122};\\\", \\\"{x:521,y:708,t:1527876848138};\\\", \\\"{x:517,y:712,t:1527876848155};\\\", \\\"{x:514,y:717,t:1527876848172};\\\", \\\"{x:511,y:722,t:1527876848189};\\\", \\\"{x:509,y:725,t:1527876848204};\\\", \\\"{x:509,y:727,t:1527876848221};\\\", \\\"{x:507,y:729,t:1527876848238};\\\", \\\"{x:506,y:731,t:1527876848255};\\\", \\\"{x:505,y:733,t:1527876848272};\\\", \\\"{x:505,y:734,t:1527876848289};\\\", \\\"{x:504,y:736,t:1527876848306};\\\" ] }, { \\\"rt\\\": 26116, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 18, \\\"time_elapsed\\\": 483918, \\\"internal_node_id\\\": \\\"0.0-6.0-8.0\\\", \\\"subject\\\": \\\"7BW1K\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 14, \\\"clicks\\\": 1, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-G -G -04 PM-X -04 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:503,y:737,t:1527876851979};\\\", \\\"{x:504,y:737,t:1527876854459};\\\", \\\"{x:505,y:737,t:1527876854474};\\\", \\\"{x:506,y:737,t:1527876854483};\\\", \\\"{x:506,y:736,t:1527876854494};\\\", \\\"{x:507,y:735,t:1527876854563};\\\", \\\"{x:507,y:734,t:1527876854835};\\\", \\\"{x:506,y:733,t:1527876854850};\\\", \\\"{x:506,y:732,t:1527876854861};\\\", \\\"{x:505,y:732,t:1527876854878};\\\", \\\"{x:503,y:732,t:1527876854895};\\\", \\\"{x:502,y:732,t:1527876854938};\\\", \\\"{x:501,y:731,t:1527876854947};\\\", \\\"{x:501,y:730,t:1527876855387};\\\", \\\"{x:500,y:729,t:1527876855715};\\\", \\\"{x:499,y:726,t:1527876857467};\\\", \\\"{x:494,y:726,t:1527876857480};\\\", \\\"{x:471,y:733,t:1527876857497};\\\", \\\"{x:429,y:756,t:1527876857514};\\\", \\\"{x:328,y:799,t:1527876857529};\\\", \\\"{x:251,y:829,t:1527876857546};\\\", \\\"{x:183,y:856,t:1527876857562};\\\", \\\"{x:157,y:873,t:1527876857580};\\\", \\\"{x:134,y:882,t:1527876857595};\\\", \\\"{x:124,y:887,t:1527876857612};\\\", \\\"{x:120,y:889,t:1527876857629};\\\", \\\"{x:118,y:890,t:1527876857770};\\\", \\\"{x:112,y:891,t:1527876857780};\\\", \\\"{x:91,y:900,t:1527876857796};\\\", \\\"{x:61,y:915,t:1527876857813};\\\", \\\"{x:40,y:928,t:1527876857830};\\\", \\\"{x:13,y:943,t:1527876857846};\\\", \\\"{x:0,y:952,t:1527876857864};\\\", \\\"{x:0,y:957,t:1527876857880};\\\", \\\"{x:0,y:962,t:1527876857896};\\\", \\\"{x:0,y:964,t:1527876857913};\\\", \\\"{x:0,y:965,t:1527876857930};\\\", \\\"{x:0,y:966,t:1527876857946};\\\", \\\"{x:0,y:965,t:1527876858947};\\\", \\\"{x:0,y:963,t:1527876858964};\\\", \\\"{x:0,y:961,t:1527876858981};\\\", \\\"{x:0,y:960,t:1527876859018};\\\", \\\"{x:0,y:959,t:1527876859031};\\\", \\\"{x:0,y:960,t:1527876859178};\\\", \\\"{x:0,y:961,t:1527876859203};\\\", \\\"{x:0,y:962,t:1527876859218};\\\", \\\"{x:0,y:957,t:1527876860411};\\\", \\\"{x:0,y:956,t:1527876860426};\\\", \\\"{x:0,y:954,t:1527876862187};\\\", \\\"{x:0,y:950,t:1527876862199};\\\", \\\"{x:0,y:947,t:1527876862216};\\\", \\\"{x:5,y:947,t:1527876862651};\\\", \\\"{x:11,y:952,t:1527876862667};\\\", \\\"{x:13,y:958,t:1527876862684};\\\", \\\"{x:13,y:960,t:1527876862700};\\\", \\\"{x:13,y:961,t:1527876863299};\\\", \\\"{x:11,y:963,t:1527876863306};\\\", \\\"{x:9,y:963,t:1527876863330};\\\", \\\"{x:9,y:964,t:1527876863442};\\\", \\\"{x:13,y:964,t:1527876863450};\\\", \\\"{x:22,y:960,t:1527876863467};\\\", \\\"{x:31,y:956,t:1527876863485};\\\", \\\"{x:43,y:951,t:1527876863499};\\\", \\\"{x:45,y:951,t:1527876863517};\\\", \\\"{x:51,y:947,t:1527876863533};\\\", \\\"{x:57,y:947,t:1527876863550};\\\", \\\"{x:62,y:947,t:1527876863566};\\\", \\\"{x:71,y:947,t:1527876863583};\\\", \\\"{x:78,y:947,t:1527876863600};\\\", \\\"{x:88,y:948,t:1527876863617};\\\", \\\"{x:104,y:955,t:1527876863634};\\\", \\\"{x:113,y:958,t:1527876863651};\\\", \\\"{x:127,y:963,t:1527876863667};\\\", \\\"{x:142,y:971,t:1527876863684};\\\", \\\"{x:148,y:975,t:1527876863701};\\\", \\\"{x:150,y:975,t:1527876863717};\\\", \\\"{x:152,y:975,t:1527876863939};\\\", \\\"{x:153,y:975,t:1527876863951};\\\", \\\"{x:154,y:975,t:1527876863994};\\\", \\\"{x:156,y:975,t:1527876864002};\\\", \\\"{x:158,y:974,t:1527876864026};\\\", \\\"{x:159,y:973,t:1527876864035};\\\", \\\"{x:166,y:967,t:1527876864051};\\\", \\\"{x:181,y:953,t:1527876864068};\\\", \\\"{x:201,y:930,t:1527876864086};\\\", \\\"{x:235,y:882,t:1527876864101};\\\", \\\"{x:266,y:828,t:1527876864118};\\\", \\\"{x:278,y:803,t:1527876864135};\\\", \\\"{x:288,y:777,t:1527876864151};\\\", \\\"{x:296,y:744,t:1527876864168};\\\", \\\"{x:300,y:729,t:1527876864184};\\\", \\\"{x:308,y:707,t:1527876864202};\\\", \\\"{x:318,y:681,t:1527876864219};\\\", \\\"{x:324,y:667,t:1527876864236};\\\", \\\"{x:328,y:653,t:1527876864250};\\\", \\\"{x:330,y:641,t:1527876864267};\\\", \\\"{x:332,y:632,t:1527876864285};\\\", \\\"{x:333,y:627,t:1527876864301};\\\", \\\"{x:337,y:623,t:1527876864317};\\\", \\\"{x:337,y:622,t:1527876864334};\\\", \\\"{x:337,y:621,t:1527876865859};\\\", \\\"{x:342,y:617,t:1527876865869};\\\", \\\"{x:349,y:615,t:1527876865886};\\\", \\\"{x:350,y:615,t:1527876865904};\\\", \\\"{x:351,y:615,t:1527876865919};\\\", \\\"{x:353,y:613,t:1527876865979};\\\", \\\"{x:354,y:613,t:1527876865986};\\\", \\\"{x:367,y:607,t:1527876866004};\\\", \\\"{x:384,y:598,t:1527876866021};\\\", \\\"{x:401,y:593,t:1527876866036};\\\", \\\"{x:420,y:588,t:1527876866053};\\\", \\\"{x:440,y:582,t:1527876866069};\\\", \\\"{x:466,y:573,t:1527876866086};\\\", \\\"{x:486,y:557,t:1527876866103};\\\", \\\"{x:503,y:540,t:1527876866120};\\\", \\\"{x:514,y:520,t:1527876866137};\\\", \\\"{x:523,y:501,t:1527876866154};\\\", \\\"{x:535,y:485,t:1527876866170};\\\", \\\"{x:538,y:480,t:1527876866186};\\\", \\\"{x:543,y:474,t:1527876866203};\\\", \\\"{x:549,y:467,t:1527876866220};\\\", \\\"{x:568,y:446,t:1527876866236};\\\", \\\"{x:584,y:429,t:1527876866253};\\\", \\\"{x:593,y:418,t:1527876866270};\\\", \\\"{x:598,y:408,t:1527876866286};\\\", \\\"{x:598,y:405,t:1527876866303};\\\", \\\"{x:599,y:403,t:1527876866320};\\\", \\\"{x:598,y:403,t:1527876866410};\\\", \\\"{x:588,y:405,t:1527876866420};\\\", \\\"{x:551,y:429,t:1527876866437};\\\", \\\"{x:530,y:442,t:1527876866454};\\\", \\\"{x:520,y:448,t:1527876866470};\\\", \\\"{x:516,y:451,t:1527876866487};\\\", \\\"{x:515,y:453,t:1527876866504};\\\", \\\"{x:513,y:453,t:1527876866521};\\\", \\\"{x:508,y:453,t:1527876866538};\\\", \\\"{x:499,y:456,t:1527876866553};\\\", \\\"{x:483,y:460,t:1527876866570};\\\", \\\"{x:480,y:461,t:1527876866588};\\\", \\\"{x:479,y:461,t:1527876866604};\\\", \\\"{x:477,y:462,t:1527876866621};\\\", \\\"{x:476,y:462,t:1527876866642};\\\", \\\"{x:475,y:463,t:1527876866654};\\\", \\\"{x:474,y:463,t:1527876866670};\\\", \\\"{x:473,y:463,t:1527876866687};\\\", \\\"{x:472,y:463,t:1527876866747};\\\", \\\"{x:470,y:463,t:1527876866754};\\\", \\\"{x:466,y:463,t:1527876866770};\\\", \\\"{x:462,y:463,t:1527876866787};\\\", \\\"{x:461,y:463,t:1527876867619};\\\", \\\"{x:462,y:463,t:1527876867755};\\\", \\\"{x:469,y:462,t:1527876867772};\\\", \\\"{x:474,y:461,t:1527876867788};\\\", \\\"{x:479,y:458,t:1527876867805};\\\", \\\"{x:482,y:456,t:1527876867821};\\\", \\\"{x:485,y:454,t:1527876867838};\\\", \\\"{x:490,y:452,t:1527876867855};\\\", \\\"{x:502,y:447,t:1527876867871};\\\", \\\"{x:514,y:441,t:1527876867889};\\\", \\\"{x:518,y:437,t:1527876867905};\\\", \\\"{x:533,y:436,t:1527876867922};\\\", \\\"{x:554,y:436,t:1527876867938};\\\", \\\"{x:567,y:438,t:1527876867954};\\\", \\\"{x:620,y:446,t:1527876867972};\\\", \\\"{x:704,y:461,t:1527876867989};\\\", \\\"{x:738,y:470,t:1527876868005};\\\", \\\"{x:797,y:482,t:1527876868022};\\\", \\\"{x:848,y:491,t:1527876868040};\\\", \\\"{x:858,y:495,t:1527876868055};\\\", \\\"{x:859,y:495,t:1527876868442};\\\", \\\"{x:876,y:495,t:1527876868456};\\\", \\\"{x:916,y:493,t:1527876868471};\\\", \\\"{x:926,y:490,t:1527876868489};\\\", \\\"{x:940,y:488,t:1527876868505};\\\", \\\"{x:969,y:484,t:1527876868523};\\\", \\\"{x:1012,y:478,t:1527876868538};\\\", \\\"{x:1039,y:476,t:1527876868555};\\\", \\\"{x:1068,y:471,t:1527876868572};\\\", \\\"{x:1097,y:470,t:1527876868588};\\\", \\\"{x:1114,y:465,t:1527876868605};\\\", \\\"{x:1132,y:461,t:1527876868622};\\\", \\\"{x:1159,y:456,t:1527876868638};\\\", \\\"{x:1182,y:454,t:1527876868655};\\\", \\\"{x:1200,y:454,t:1527876868672};\\\", \\\"{x:1213,y:451,t:1527876868688};\\\", \\\"{x:1224,y:451,t:1527876868705};\\\", \\\"{x:1231,y:450,t:1527876868721};\\\", \\\"{x:1234,y:448,t:1527876868739};\\\", \\\"{x:1241,y:446,t:1527876868755};\\\", \\\"{x:1262,y:443,t:1527876868772};\\\", \\\"{x:1279,y:440,t:1527876868789};\\\", \\\"{x:1297,y:436,t:1527876868805};\\\", \\\"{x:1325,y:426,t:1527876868822};\\\", \\\"{x:1340,y:421,t:1527876868839};\\\", \\\"{x:1347,y:420,t:1527876868856};\\\", \\\"{x:1348,y:420,t:1527876868873};\\\", \\\"{x:1349,y:420,t:1527876868890};\\\", \\\"{x:1350,y:420,t:1527876868905};\\\", \\\"{x:1351,y:420,t:1527876868931};\\\", \\\"{x:1352,y:423,t:1527876868979};\\\", \\\"{x:1352,y:424,t:1527876868989};\\\", \\\"{x:1354,y:426,t:1527876869005};\\\", \\\"{x:1355,y:431,t:1527876869023};\\\", \\\"{x:1358,y:443,t:1527876869040};\\\", \\\"{x:1364,y:463,t:1527876869056};\\\", \\\"{x:1376,y:483,t:1527876869073};\\\", \\\"{x:1385,y:503,t:1527876869089};\\\", \\\"{x:1395,y:523,t:1527876869106};\\\", \\\"{x:1410,y:549,t:1527876869122};\\\", \\\"{x:1420,y:562,t:1527876869142};\\\", \\\"{x:1429,y:574,t:1527876869155};\\\", \\\"{x:1440,y:598,t:1527876869172};\\\", \\\"{x:1454,y:619,t:1527876869189};\\\", \\\"{x:1464,y:635,t:1527876869205};\\\", \\\"{x:1475,y:650,t:1527876869222};\\\", \\\"{x:1481,y:663,t:1527876869239};\\\", \\\"{x:1486,y:673,t:1527876869256};\\\", \\\"{x:1491,y:684,t:1527876869272};\\\", \\\"{x:1494,y:705,t:1527876869290};\\\", \\\"{x:1499,y:727,t:1527876869306};\\\", \\\"{x:1501,y:744,t:1527876869322};\\\", \\\"{x:1504,y:756,t:1527876869340};\\\", \\\"{x:1510,y:768,t:1527876869356};\\\", \\\"{x:1515,y:781,t:1527876869372};\\\", \\\"{x:1520,y:791,t:1527876869390};\\\", \\\"{x:1532,y:803,t:1527876869406};\\\", \\\"{x:1546,y:821,t:1527876869422};\\\", \\\"{x:1557,y:837,t:1527876869440};\\\", \\\"{x:1566,y:852,t:1527876869455};\\\", \\\"{x:1569,y:865,t:1527876869473};\\\", \\\"{x:1575,y:876,t:1527876869490};\\\", \\\"{x:1575,y:880,t:1527876869505};\\\", \\\"{x:1577,y:892,t:1527876869522};\\\", \\\"{x:1580,y:900,t:1527876869540};\\\", \\\"{x:1582,y:904,t:1527876869557};\\\", \\\"{x:1582,y:908,t:1527876869573};\\\", \\\"{x:1584,y:911,t:1527876869590};\\\", \\\"{x:1584,y:913,t:1527876869607};\\\", \\\"{x:1583,y:918,t:1527876869623};\\\", \\\"{x:1580,y:922,t:1527876869640};\\\", \\\"{x:1579,y:923,t:1527876869657};\\\", \\\"{x:1578,y:925,t:1527876869672};\\\", \\\"{x:1577,y:926,t:1527876869689};\\\", \\\"{x:1568,y:937,t:1527876869706};\\\", \\\"{x:1564,y:943,t:1527876869722};\\\", \\\"{x:1560,y:950,t:1527876869740};\\\", \\\"{x:1557,y:953,t:1527876869756};\\\", \\\"{x:1555,y:956,t:1527876869772};\\\", \\\"{x:1555,y:957,t:1527876869789};\\\", \\\"{x:1554,y:958,t:1527876869874};\\\", \\\"{x:1553,y:958,t:1527876869890};\\\", \\\"{x:1553,y:960,t:1527876869906};\\\", \\\"{x:1552,y:961,t:1527876869937};\\\", \\\"{x:1552,y:962,t:1527876869986};\\\", \\\"{x:1550,y:962,t:1527876870011};\\\", \\\"{x:1550,y:963,t:1527876870027};\\\", \\\"{x:1549,y:963,t:1527876870075};\\\", \\\"{x:1548,y:963,t:1527876870099};\\\", \\\"{x:1547,y:963,t:1527876870107};\\\", \\\"{x:1546,y:963,t:1527876870138};\\\", \\\"{x:1545,y:964,t:1527876870163};\\\", \\\"{x:1544,y:962,t:1527876870291};\\\", \\\"{x:1544,y:956,t:1527876870307};\\\", \\\"{x:1544,y:945,t:1527876870324};\\\", \\\"{x:1543,y:936,t:1527876870340};\\\", \\\"{x:1541,y:924,t:1527876870356};\\\", \\\"{x:1539,y:915,t:1527876870374};\\\", \\\"{x:1536,y:903,t:1527876870390};\\\", \\\"{x:1534,y:887,t:1527876870407};\\\", \\\"{x:1527,y:863,t:1527876870424};\\\", \\\"{x:1518,y:839,t:1527876870440};\\\", \\\"{x:1500,y:804,t:1527876870457};\\\", \\\"{x:1490,y:782,t:1527876870474};\\\", \\\"{x:1475,y:761,t:1527876870490};\\\", \\\"{x:1471,y:753,t:1527876870507};\\\", \\\"{x:1470,y:748,t:1527876870524};\\\", \\\"{x:1468,y:743,t:1527876870541};\\\", \\\"{x:1463,y:730,t:1527876870557};\\\", \\\"{x:1458,y:711,t:1527876870574};\\\", \\\"{x:1446,y:685,t:1527876870591};\\\", \\\"{x:1435,y:666,t:1527876870607};\\\", \\\"{x:1426,y:649,t:1527876870623};\\\", \\\"{x:1420,y:634,t:1527876870641};\\\", \\\"{x:1412,y:618,t:1527876870657};\\\", \\\"{x:1402,y:601,t:1527876870674};\\\", \\\"{x:1380,y:567,t:1527876870690};\\\", \\\"{x:1359,y:537,t:1527876870707};\\\", \\\"{x:1336,y:502,t:1527876870723};\\\", \\\"{x:1319,y:483,t:1527876870741};\\\", \\\"{x:1309,y:473,t:1527876870757};\\\", \\\"{x:1304,y:468,t:1527876870774};\\\", \\\"{x:1296,y:465,t:1527876870791};\\\", \\\"{x:1287,y:459,t:1527876870807};\\\", \\\"{x:1283,y:457,t:1527876870824};\\\", \\\"{x:1257,y:452,t:1527876870841};\\\", \\\"{x:1228,y:442,t:1527876870857};\\\", \\\"{x:1169,y:423,t:1527876870874};\\\", \\\"{x:1067,y:399,t:1527876870891};\\\", \\\"{x:1023,y:391,t:1527876870907};\\\", \\\"{x:975,y:382,t:1527876870924};\\\", \\\"{x:913,y:380,t:1527876870941};\\\", \\\"{x:848,y:377,t:1527876870957};\\\", \\\"{x:809,y:377,t:1527876870974};\\\", \\\"{x:781,y:376,t:1527876870991};\\\", \\\"{x:752,y:376,t:1527876871008};\\\", \\\"{x:694,y:381,t:1527876871023};\\\", \\\"{x:658,y:390,t:1527876871041};\\\", \\\"{x:647,y:398,t:1527876871058};\\\", \\\"{x:644,y:401,t:1527876871074};\\\", \\\"{x:644,y:413,t:1527876871090};\\\", \\\"{x:644,y:423,t:1527876871108};\\\", \\\"{x:641,y:432,t:1527876871124};\\\", \\\"{x:641,y:442,t:1527876871141};\\\", \\\"{x:641,y:459,t:1527876871157};\\\", \\\"{x:642,y:477,t:1527876871174};\\\", \\\"{x:648,y:505,t:1527876871192};\\\", \\\"{x:652,y:526,t:1527876871207};\\\", \\\"{x:652,y:543,t:1527876871222};\\\", \\\"{x:652,y:555,t:1527876871240};\\\", \\\"{x:647,y:577,t:1527876871258};\\\", \\\"{x:644,y:588,t:1527876871273};\\\", \\\"{x:634,y:608,t:1527876871294};\\\", \\\"{x:622,y:627,t:1527876871311};\\\", \\\"{x:608,y:645,t:1527876871328};\\\", \\\"{x:591,y:666,t:1527876871344};\\\", \\\"{x:577,y:685,t:1527876871360};\\\", \\\"{x:556,y:699,t:1527876871377};\\\", \\\"{x:537,y:708,t:1527876871393};\\\", \\\"{x:513,y:716,t:1527876871410};\\\", \\\"{x:495,y:718,t:1527876871427};\\\", \\\"{x:470,y:720,t:1527876871445};\\\", \\\"{x:455,y:720,t:1527876871460};\\\", \\\"{x:437,y:715,t:1527876871478};\\\", \\\"{x:421,y:711,t:1527876871494};\\\", \\\"{x:419,y:710,t:1527876871510};\\\", \\\"{x:417,y:708,t:1527876871574};\\\", \\\"{x:413,y:700,t:1527876871581};\\\", \\\"{x:409,y:696,t:1527876871594};\\\", \\\"{x:397,y:683,t:1527876871611};\\\", \\\"{x:382,y:672,t:1527876871628};\\\", \\\"{x:357,y:660,t:1527876871645};\\\", \\\"{x:290,y:642,t:1527876871661};\\\", \\\"{x:261,y:634,t:1527876871678};\\\", \\\"{x:238,y:629,t:1527876871695};\\\", \\\"{x:218,y:627,t:1527876871711};\\\", \\\"{x:213,y:627,t:1527876871727};\\\", \\\"{x:203,y:627,t:1527876871744};\\\", \\\"{x:200,y:629,t:1527876871760};\\\", \\\"{x:197,y:630,t:1527876871778};\\\", \\\"{x:195,y:632,t:1527876871798};\\\", \\\"{x:194,y:632,t:1527876871813};\\\", \\\"{x:193,y:633,t:1527876871837};\\\", \\\"{x:193,y:634,t:1527876871845};\\\", \\\"{x:192,y:634,t:1527876871910};\\\", \\\"{x:201,y:632,t:1527876871918};\\\", \\\"{x:212,y:630,t:1527876871929};\\\", \\\"{x:230,y:621,t:1527876871944};\\\", \\\"{x:260,y:614,t:1527876871960};\\\", \\\"{x:312,y:607,t:1527876871978};\\\", \\\"{x:389,y:602,t:1527876871994};\\\", \\\"{x:494,y:602,t:1527876872012};\\\", \\\"{x:590,y:608,t:1527876872028};\\\", \\\"{x:709,y:615,t:1527876872045};\\\", \\\"{x:743,y:619,t:1527876872061};\\\", \\\"{x:781,y:624,t:1527876872078};\\\", \\\"{x:820,y:629,t:1527876872094};\\\", \\\"{x:860,y:630,t:1527876872111};\\\", \\\"{x:900,y:633,t:1527876872128};\\\", \\\"{x:927,y:635,t:1527876872145};\\\", \\\"{x:952,y:637,t:1527876872162};\\\", \\\"{x:967,y:637,t:1527876872178};\\\", \\\"{x:974,y:637,t:1527876872195};\\\", \\\"{x:977,y:637,t:1527876872212};\\\", \\\"{x:978,y:637,t:1527876872262};\\\", \\\"{x:978,y:632,t:1527876872280};\\\", \\\"{x:963,y:619,t:1527876872295};\\\", \\\"{x:927,y:604,t:1527876872313};\\\", \\\"{x:906,y:592,t:1527876872329};\\\", \\\"{x:879,y:581,t:1527876872344};\\\", \\\"{x:857,y:568,t:1527876872362};\\\", \\\"{x:850,y:561,t:1527876872378};\\\", \\\"{x:846,y:558,t:1527876872394};\\\", \\\"{x:842,y:556,t:1527876872411};\\\", \\\"{x:826,y:551,t:1527876872428};\\\", \\\"{x:803,y:549,t:1527876872445};\\\", \\\"{x:796,y:549,t:1527876872461};\\\", \\\"{x:782,y:553,t:1527876872479};\\\", \\\"{x:766,y:561,t:1527876872495};\\\", \\\"{x:748,y:570,t:1527876872512};\\\", \\\"{x:733,y:578,t:1527876872529};\\\", \\\"{x:695,y:594,t:1527876872544};\\\", \\\"{x:665,y:612,t:1527876872562};\\\", \\\"{x:622,y:627,t:1527876872579};\\\", \\\"{x:593,y:629,t:1527876872594};\\\", \\\"{x:567,y:631,t:1527876872611};\\\", \\\"{x:551,y:633,t:1527876872629};\\\", \\\"{x:549,y:634,t:1527876872645};\\\", \\\"{x:551,y:634,t:1527876872733};\\\", \\\"{x:554,y:634,t:1527876872746};\\\", \\\"{x:560,y:630,t:1527876872762};\\\", \\\"{x:567,y:619,t:1527876872778};\\\", \\\"{x:570,y:613,t:1527876872795};\\\", \\\"{x:573,y:608,t:1527876872812};\\\", \\\"{x:576,y:602,t:1527876872829};\\\", \\\"{x:582,y:596,t:1527876872845};\\\", \\\"{x:597,y:591,t:1527876872862};\\\", \\\"{x:604,y:587,t:1527876872879};\\\", \\\"{x:610,y:584,t:1527876872895};\\\", \\\"{x:613,y:583,t:1527876872912};\\\", \\\"{x:616,y:582,t:1527876872997};\\\", \\\"{x:625,y:580,t:1527876873405};\\\", \\\"{x:668,y:580,t:1527876873413};\\\", \\\"{x:735,y:587,t:1527876873430};\\\", \\\"{x:980,y:643,t:1527876873447};\\\", \\\"{x:1176,y:700,t:1527876873462};\\\", \\\"{x:1355,y:753,t:1527876873478};\\\", \\\"{x:1511,y:808,t:1527876873496};\\\", \\\"{x:1626,y:850,t:1527876873512};\\\", \\\"{x:1705,y:897,t:1527876873529};\\\", \\\"{x:1721,y:913,t:1527876873546};\\\", \\\"{x:1725,y:917,t:1527876873562};\\\", \\\"{x:1724,y:921,t:1527876873579};\\\", \\\"{x:1720,y:925,t:1527876873596};\\\", \\\"{x:1715,y:927,t:1527876873613};\\\", \\\"{x:1714,y:928,t:1527876873628};\\\", \\\"{x:1713,y:929,t:1527876873645};\\\", \\\"{x:1712,y:930,t:1527876873663};\\\", \\\"{x:1708,y:936,t:1527876873679};\\\", \\\"{x:1697,y:944,t:1527876873696};\\\", \\\"{x:1682,y:956,t:1527876873713};\\\", \\\"{x:1661,y:966,t:1527876873729};\\\", \\\"{x:1630,y:975,t:1527876873746};\\\", \\\"{x:1608,y:976,t:1527876873763};\\\", \\\"{x:1589,y:976,t:1527876873780};\\\", \\\"{x:1574,y:973,t:1527876873796};\\\", \\\"{x:1547,y:959,t:1527876873813};\\\", \\\"{x:1542,y:954,t:1527876873829};\\\", \\\"{x:1538,y:946,t:1527876873845};\\\", \\\"{x:1537,y:943,t:1527876873863};\\\", \\\"{x:1537,y:939,t:1527876873880};\\\", \\\"{x:1537,y:938,t:1527876873896};\\\", \\\"{x:1534,y:937,t:1527876873982};\\\", \\\"{x:1530,y:933,t:1527876873997};\\\", \\\"{x:1515,y:920,t:1527876874013};\\\", \\\"{x:1511,y:917,t:1527876874029};\\\", \\\"{x:1510,y:916,t:1527876874046};\\\", \\\"{x:1510,y:915,t:1527876874063};\\\", \\\"{x:1509,y:913,t:1527876874093};\\\", \\\"{x:1508,y:910,t:1527876874110};\\\", \\\"{x:1505,y:904,t:1527876874118};\\\", \\\"{x:1503,y:900,t:1527876874130};\\\", \\\"{x:1498,y:884,t:1527876874146};\\\", \\\"{x:1484,y:859,t:1527876874163};\\\", \\\"{x:1471,y:834,t:1527876874180};\\\", \\\"{x:1464,y:818,t:1527876874196};\\\", \\\"{x:1460,y:811,t:1527876874213};\\\", \\\"{x:1460,y:810,t:1527876874254};\\\", \\\"{x:1465,y:819,t:1527876874270};\\\", \\\"{x:1470,y:827,t:1527876874280};\\\", \\\"{x:1478,y:853,t:1527876874296};\\\", \\\"{x:1486,y:871,t:1527876874313};\\\", \\\"{x:1495,y:895,t:1527876874330};\\\", \\\"{x:1499,y:908,t:1527876874346};\\\", \\\"{x:1503,y:917,t:1527876874362};\\\", \\\"{x:1507,y:921,t:1527876874379};\\\", \\\"{x:1512,y:927,t:1527876874396};\\\", \\\"{x:1516,y:936,t:1527876874413};\\\", \\\"{x:1516,y:942,t:1527876874429};\\\", \\\"{x:1516,y:947,t:1527876874447};\\\", \\\"{x:1516,y:949,t:1527876874463};\\\", \\\"{x:1515,y:949,t:1527876874550};\\\", \\\"{x:1512,y:942,t:1527876874563};\\\", \\\"{x:1507,y:925,t:1527876874580};\\\", \\\"{x:1498,y:889,t:1527876874597};\\\", \\\"{x:1493,y:864,t:1527876874613};\\\", \\\"{x:1486,y:839,t:1527876874630};\\\", \\\"{x:1480,y:815,t:1527876874648};\\\", \\\"{x:1470,y:788,t:1527876874664};\\\", \\\"{x:1465,y:776,t:1527876874680};\\\", \\\"{x:1460,y:766,t:1527876874697};\\\", \\\"{x:1460,y:764,t:1527876874714};\\\", \\\"{x:1463,y:768,t:1527876874846};\\\", \\\"{x:1484,y:795,t:1527876874864};\\\", \\\"{x:1521,y:846,t:1527876874880};\\\", \\\"{x:1560,y:890,t:1527876874897};\\\", \\\"{x:1589,y:919,t:1527876874915};\\\", \\\"{x:1609,y:943,t:1527876874930};\\\", \\\"{x:1622,y:959,t:1527876874947};\\\", \\\"{x:1625,y:969,t:1527876874964};\\\", \\\"{x:1626,y:973,t:1527876874981};\\\", \\\"{x:1624,y:973,t:1527876875013};\\\", \\\"{x:1610,y:970,t:1527876875030};\\\", \\\"{x:1591,y:949,t:1527876875048};\\\", \\\"{x:1554,y:917,t:1527876875065};\\\", \\\"{x:1509,y:855,t:1527876875080};\\\", \\\"{x:1462,y:776,t:1527876875098};\\\", \\\"{x:1422,y:692,t:1527876875114};\\\", \\\"{x:1390,y:630,t:1527876875130};\\\", \\\"{x:1379,y:594,t:1527876875148};\\\", \\\"{x:1366,y:559,t:1527876875165};\\\", \\\"{x:1358,y:533,t:1527876875180};\\\", \\\"{x:1351,y:517,t:1527876875197};\\\", \\\"{x:1346,y:510,t:1527876875214};\\\", \\\"{x:1337,y:510,t:1527876875231};\\\", \\\"{x:1310,y:523,t:1527876875247};\\\", \\\"{x:1223,y:556,t:1527876875264};\\\", \\\"{x:1103,y:593,t:1527876875281};\\\", \\\"{x:996,y:622,t:1527876875298};\\\", \\\"{x:897,y:643,t:1527876875314};\\\", \\\"{x:803,y:671,t:1527876875331};\\\", \\\"{x:737,y:697,t:1527876875347};\\\", \\\"{x:703,y:713,t:1527876875364};\\\", \\\"{x:696,y:720,t:1527876875381};\\\", \\\"{x:695,y:720,t:1527876875397};\\\", \\\"{x:694,y:722,t:1527876875422};\\\", \\\"{x:693,y:722,t:1527876875431};\\\", \\\"{x:689,y:725,t:1527876875447};\\\", \\\"{x:676,y:731,t:1527876875464};\\\", \\\"{x:653,y:737,t:1527876875481};\\\", \\\"{x:635,y:742,t:1527876875497};\\\", \\\"{x:623,y:750,t:1527876875514};\\\", \\\"{x:615,y:753,t:1527876875531};\\\", \\\"{x:610,y:756,t:1527876875548};\\\", \\\"{x:600,y:758,t:1527876875564};\\\", \\\"{x:587,y:758,t:1527876875581};\\\", \\\"{x:577,y:758,t:1527876875597};\\\", \\\"{x:570,y:758,t:1527876875614};\\\", \\\"{x:567,y:758,t:1527876875631};\\\", \\\"{x:566,y:758,t:1527876875647};\\\", \\\"{x:564,y:757,t:1527876875710};\\\", \\\"{x:560,y:756,t:1527876875718};\\\", \\\"{x:557,y:756,t:1527876875731};\\\", \\\"{x:551,y:754,t:1527876875749};\\\", \\\"{x:545,y:752,t:1527876875764};\\\", \\\"{x:532,y:746,t:1527876875781};\\\", \\\"{x:530,y:745,t:1527876875795};\\\", \\\"{x:528,y:745,t:1527876875811};\\\", \\\"{x:525,y:743,t:1527876875828};\\\", \\\"{x:524,y:743,t:1527876875845};\\\", \\\"{x:524,y:742,t:1527876876165};\\\", \\\"{x:539,y:734,t:1527876876181};\\\", \\\"{x:568,y:726,t:1527876876198};\\\", \\\"{x:608,y:718,t:1527876876215};\\\", \\\"{x:646,y:710,t:1527876876232};\\\", \\\"{x:679,y:710,t:1527876876247};\\\", \\\"{x:714,y:697,t:1527876876265};\\\", \\\"{x:730,y:695,t:1527876876281};\\\", \\\"{x:748,y:694,t:1527876876298};\\\", \\\"{x:759,y:691,t:1527876876315};\\\", \\\"{x:761,y:689,t:1527876876332};\\\", \\\"{x:761,y:685,t:1527876876373};\\\", \\\"{x:748,y:662,t:1527876876382};\\\", \\\"{x:703,y:602,t:1527876876398};\\\", \\\"{x:676,y:559,t:1527876876415};\\\", \\\"{x:622,y:505,t:1527876876432};\\\", \\\"{x:585,y:469,t:1527876876448};\\\", \\\"{x:551,y:437,t:1527876876464};\\\", \\\"{x:530,y:410,t:1527876876482};\\\", \\\"{x:512,y:390,t:1527876876497};\\\", \\\"{x:498,y:375,t:1527876876515};\\\", \\\"{x:497,y:373,t:1527876876532};\\\", \\\"{x:494,y:373,t:1527876876694};\\\", \\\"{x:493,y:373,t:1527876876854};\\\", \\\"{x:494,y:374,t:1527876876865};\\\", \\\"{x:497,y:378,t:1527876876882};\\\", \\\"{x:501,y:382,t:1527876876899};\\\", \\\"{x:505,y:386,t:1527876876915};\\\", \\\"{x:510,y:388,t:1527876876932};\\\", \\\"{x:517,y:390,t:1527876876949};\\\", \\\"{x:525,y:392,t:1527876876965};\\\", \\\"{x:532,y:394,t:1527876876982};\\\", \\\"{x:545,y:395,t:1527876876999};\\\", \\\"{x:554,y:395,t:1527876877017};\\\" ] }, { \\\"rt\\\": 12547, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 19, \\\"time_elapsed\\\": 497732, \\\"internal_node_id\\\": \\\"0.0-6.0-9.0\\\", \\\"subject\\\": \\\"7BW1K\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 15, \\\"clicks\\\": 2, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"K\\\", \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-02 PM-02 PM-G \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:542,y:400,t:1527876877697};\\\", \\\"{x:538,y:402,t:1527876877701};\\\", \\\"{x:535,y:402,t:1527876877716};\\\", \\\"{x:521,y:410,t:1527876877733};\\\", \\\"{x:508,y:412,t:1527876877748};\\\", \\\"{x:488,y:412,t:1527876877765};\\\", \\\"{x:467,y:412,t:1527876877783};\\\", \\\"{x:450,y:412,t:1527876877799};\\\", \\\"{x:441,y:412,t:1527876877815};\\\", \\\"{x:419,y:412,t:1527876877833};\\\", \\\"{x:392,y:412,t:1527876877849};\\\", \\\"{x:367,y:412,t:1527876877866};\\\", \\\"{x:355,y:412,t:1527876877882};\\\", \\\"{x:350,y:412,t:1527876877899};\\\", \\\"{x:348,y:413,t:1527876877916};\\\", \\\"{x:347,y:416,t:1527876877981};\\\", \\\"{x:347,y:419,t:1527876877989};\\\", \\\"{x:345,y:422,t:1527876877998};\\\", \\\"{x:344,y:430,t:1527876878016};\\\", \\\"{x:343,y:437,t:1527876878032};\\\", \\\"{x:343,y:444,t:1527876878049};\\\", \\\"{x:343,y:449,t:1527876878065};\\\", \\\"{x:345,y:452,t:1527876878083};\\\", \\\"{x:347,y:454,t:1527876878100};\\\", \\\"{x:349,y:454,t:1527876878286};\\\", \\\"{x:352,y:453,t:1527876878300};\\\", \\\"{x:354,y:449,t:1527876878316};\\\", \\\"{x:359,y:444,t:1527876878334};\\\", \\\"{x:360,y:441,t:1527876878350};\\\", \\\"{x:360,y:439,t:1527876878366};\\\", \\\"{x:361,y:438,t:1527876878383};\\\", \\\"{x:364,y:435,t:1527876878997};\\\", \\\"{x:375,y:432,t:1527876879004};\\\", \\\"{x:393,y:428,t:1527876879016};\\\", \\\"{x:476,y:441,t:1527876879034};\\\", \\\"{x:539,y:453,t:1527876879049};\\\", \\\"{x:579,y:461,t:1527876879067};\\\", \\\"{x:594,y:465,t:1527876879083};\\\", \\\"{x:601,y:465,t:1527876879100};\\\", \\\"{x:602,y:465,t:1527876879117};\\\", \\\"{x:604,y:465,t:1527876879141};\\\", \\\"{x:606,y:465,t:1527876879310};\\\", \\\"{x:609,y:463,t:1527876879317};\\\", \\\"{x:612,y:462,t:1527876879334};\\\", \\\"{x:613,y:462,t:1527876879350};\\\", \\\"{x:613,y:461,t:1527876879373};\\\", \\\"{x:614,y:461,t:1527876879383};\\\", \\\"{x:615,y:460,t:1527876879525};\\\", \\\"{x:616,y:459,t:1527876879533};\\\", \\\"{x:618,y:459,t:1527876879549};\\\", \\\"{x:619,y:457,t:1527876879566};\\\", \\\"{x:621,y:456,t:1527876879582};\\\", \\\"{x:622,y:456,t:1527876879600};\\\", \\\"{x:624,y:455,t:1527876879630};\\\", \\\"{x:625,y:454,t:1527876879661};\\\", \\\"{x:626,y:454,t:1527876880070};\\\", \\\"{x:629,y:458,t:1527876880086};\\\", \\\"{x:635,y:468,t:1527876880102};\\\", \\\"{x:638,y:473,t:1527876880118};\\\", \\\"{x:640,y:477,t:1527876880135};\\\", \\\"{x:642,y:478,t:1527876880151};\\\", \\\"{x:642,y:479,t:1527876880189};\\\", \\\"{x:642,y:479,t:1527876881095};\\\", \\\"{x:643,y:480,t:1527876881269};\\\", \\\"{x:655,y:482,t:1527876881286};\\\", \\\"{x:663,y:481,t:1527876881302};\\\", \\\"{x:686,y:482,t:1527876881319};\\\", \\\"{x:687,y:482,t:1527876881336};\\\", \\\"{x:689,y:481,t:1527876881590};\\\", \\\"{x:692,y:479,t:1527876881604};\\\", \\\"{x:700,y:475,t:1527876881619};\\\", \\\"{x:707,y:473,t:1527876881637};\\\", \\\"{x:713,y:475,t:1527876881654};\\\", \\\"{x:721,y:476,t:1527876881670};\\\", \\\"{x:727,y:478,t:1527876881686};\\\", \\\"{x:728,y:478,t:1527876881703};\\\", \\\"{x:729,y:478,t:1527876881720};\\\", \\\"{x:730,y:480,t:1527876881757};\\\", \\\"{x:730,y:483,t:1527876881770};\\\", \\\"{x:730,y:487,t:1527876881787};\\\", \\\"{x:731,y:487,t:1527876882245};\\\", \\\"{x:733,y:487,t:1527876882253};\\\", \\\"{x:738,y:485,t:1527876882270};\\\", \\\"{x:738,y:484,t:1527876882287};\\\", \\\"{x:739,y:484,t:1527876882304};\\\", \\\"{x:740,y:483,t:1527876882606};\\\", \\\"{x:742,y:482,t:1527876882620};\\\", \\\"{x:744,y:481,t:1527876882637};\\\", \\\"{x:747,y:478,t:1527876882655};\\\", \\\"{x:749,y:477,t:1527876882672};\\\", \\\"{x:750,y:477,t:1527876882688};\\\", \\\"{x:751,y:475,t:1527876882870};\\\", \\\"{x:751,y:475,t:1527876882918};\\\", \\\"{x:753,y:474,t:1527876883094};\\\", \\\"{x:759,y:474,t:1527876883104};\\\", \\\"{x:767,y:474,t:1527876883121};\\\", \\\"{x:812,y:474,t:1527876883139};\\\", \\\"{x:861,y:478,t:1527876883155};\\\", \\\"{x:938,y:496,t:1527876883171};\\\", \\\"{x:1032,y:512,t:1527876883189};\\\", \\\"{x:1126,y:537,t:1527876883205};\\\", \\\"{x:1264,y:570,t:1527876883222};\\\", \\\"{x:1327,y:585,t:1527876883239};\\\", \\\"{x:1358,y:599,t:1527876883254};\\\", \\\"{x:1384,y:609,t:1527876883272};\\\", \\\"{x:1404,y:617,t:1527876883289};\\\", \\\"{x:1418,y:626,t:1527876883305};\\\", \\\"{x:1440,y:639,t:1527876883322};\\\", \\\"{x:1462,y:659,t:1527876883339};\\\", \\\"{x:1481,y:673,t:1527876883356};\\\", \\\"{x:1499,y:689,t:1527876883371};\\\", \\\"{x:1509,y:699,t:1527876883389};\\\", \\\"{x:1514,y:708,t:1527876883406};\\\", \\\"{x:1515,y:711,t:1527876883421};\\\", \\\"{x:1516,y:711,t:1527876883439};\\\", \\\"{x:1516,y:712,t:1527876883456};\\\", \\\"{x:1516,y:713,t:1527876883472};\\\", \\\"{x:1517,y:714,t:1527876883488};\\\", \\\"{x:1517,y:721,t:1527876883505};\\\", \\\"{x:1518,y:729,t:1527876883522};\\\", \\\"{x:1520,y:742,t:1527876883539};\\\", \\\"{x:1520,y:757,t:1527876883556};\\\", \\\"{x:1520,y:775,t:1527876883572};\\\", \\\"{x:1516,y:791,t:1527876883589};\\\", \\\"{x:1511,y:806,t:1527876883605};\\\", \\\"{x:1508,y:815,t:1527876883620};\\\", \\\"{x:1506,y:822,t:1527876883638};\\\", \\\"{x:1505,y:827,t:1527876883655};\\\", \\\"{x:1503,y:834,t:1527876883672};\\\", \\\"{x:1503,y:842,t:1527876883688};\\\", \\\"{x:1498,y:852,t:1527876883705};\\\", \\\"{x:1493,y:869,t:1527876883723};\\\", \\\"{x:1485,y:882,t:1527876883738};\\\", \\\"{x:1474,y:898,t:1527876883755};\\\", \\\"{x:1469,y:913,t:1527876883773};\\\", \\\"{x:1469,y:918,t:1527876883789};\\\", \\\"{x:1472,y:933,t:1527876883805};\\\", \\\"{x:1476,y:938,t:1527876883823};\\\", \\\"{x:1478,y:941,t:1527876883839};\\\", \\\"{x:1479,y:942,t:1527876883855};\\\", \\\"{x:1479,y:944,t:1527876883872};\\\", \\\"{x:1480,y:951,t:1527876883889};\\\", \\\"{x:1480,y:956,t:1527876883906};\\\", \\\"{x:1483,y:962,t:1527876883923};\\\", \\\"{x:1483,y:965,t:1527876883938};\\\", \\\"{x:1484,y:965,t:1527876883955};\\\", \\\"{x:1485,y:967,t:1527876883972};\\\", \\\"{x:1490,y:967,t:1527876883989};\\\", \\\"{x:1492,y:969,t:1527876884005};\\\", \\\"{x:1497,y:970,t:1527876884022};\\\", \\\"{x:1501,y:970,t:1527876884039};\\\", \\\"{x:1503,y:970,t:1527876884056};\\\", \\\"{x:1505,y:970,t:1527876884072};\\\", \\\"{x:1506,y:970,t:1527876884089};\\\", \\\"{x:1508,y:970,t:1527876884105};\\\", \\\"{x:1510,y:969,t:1527876884122};\\\", \\\"{x:1512,y:969,t:1527876884139};\\\", \\\"{x:1509,y:969,t:1527876884366};\\\", \\\"{x:1506,y:969,t:1527876884373};\\\", \\\"{x:1502,y:970,t:1527876884389};\\\", \\\"{x:1501,y:971,t:1527876884407};\\\", \\\"{x:1500,y:970,t:1527876884718};\\\", \\\"{x:1500,y:967,t:1527876884726};\\\", \\\"{x:1500,y:965,t:1527876884740};\\\", \\\"{x:1500,y:961,t:1527876884756};\\\", \\\"{x:1500,y:957,t:1527876884773};\\\", \\\"{x:1500,y:955,t:1527876884789};\\\", \\\"{x:1500,y:953,t:1527876884820};\\\", \\\"{x:1500,y:952,t:1527876884828};\\\", \\\"{x:1499,y:951,t:1527876884844};\\\", \\\"{x:1499,y:949,t:1527876884856};\\\", \\\"{x:1498,y:946,t:1527876884874};\\\", \\\"{x:1497,y:940,t:1527876884889};\\\", \\\"{x:1496,y:936,t:1527876884906};\\\", \\\"{x:1495,y:930,t:1527876884923};\\\", \\\"{x:1495,y:925,t:1527876884939};\\\", \\\"{x:1494,y:919,t:1527876884956};\\\", \\\"{x:1492,y:910,t:1527876884973};\\\", \\\"{x:1492,y:902,t:1527876884990};\\\", \\\"{x:1492,y:892,t:1527876885006};\\\", \\\"{x:1492,y:888,t:1527876885023};\\\", \\\"{x:1492,y:881,t:1527876885040};\\\", \\\"{x:1491,y:875,t:1527876885057};\\\", \\\"{x:1491,y:868,t:1527876885074};\\\", \\\"{x:1491,y:865,t:1527876885090};\\\", \\\"{x:1492,y:863,t:1527876885107};\\\", \\\"{x:1492,y:862,t:1527876885124};\\\", \\\"{x:1492,y:861,t:1527876885255};\\\", \\\"{x:1492,y:858,t:1527876885262};\\\", \\\"{x:1492,y:856,t:1527876885273};\\\", \\\"{x:1492,y:851,t:1527876885291};\\\", \\\"{x:1493,y:847,t:1527876885307};\\\", \\\"{x:1493,y:843,t:1527876885324};\\\", \\\"{x:1493,y:839,t:1527876885341};\\\", \\\"{x:1491,y:834,t:1527876885357};\\\", \\\"{x:1491,y:833,t:1527876885374};\\\", \\\"{x:1491,y:830,t:1527876885391};\\\", \\\"{x:1488,y:826,t:1527876885408};\\\", \\\"{x:1486,y:818,t:1527876885424};\\\", \\\"{x:1486,y:814,t:1527876885441};\\\", \\\"{x:1485,y:805,t:1527876885458};\\\", \\\"{x:1483,y:793,t:1527876885474};\\\", \\\"{x:1481,y:780,t:1527876885490};\\\", \\\"{x:1476,y:759,t:1527876885507};\\\", \\\"{x:1466,y:723,t:1527876885523};\\\", \\\"{x:1456,y:672,t:1527876885540};\\\", \\\"{x:1441,y:616,t:1527876885557};\\\", \\\"{x:1430,y:586,t:1527876885573};\\\", \\\"{x:1427,y:576,t:1527876885590};\\\", \\\"{x:1426,y:566,t:1527876885607};\\\", \\\"{x:1412,y:553,t:1527876885624};\\\", \\\"{x:1379,y:543,t:1527876885641};\\\", \\\"{x:1316,y:529,t:1527876885657};\\\", \\\"{x:1262,y:526,t:1527876885674};\\\", \\\"{x:1231,y:526,t:1527876885690};\\\", \\\"{x:1186,y:527,t:1527876885707};\\\", \\\"{x:1150,y:538,t:1527876885725};\\\", \\\"{x:1094,y:552,t:1527876885741};\\\", \\\"{x:947,y:596,t:1527876885758};\\\", \\\"{x:829,y:645,t:1527876885774};\\\", \\\"{x:759,y:668,t:1527876885790};\\\", \\\"{x:594,y:719,t:1527876885822};\\\", \\\"{x:534,y:732,t:1527876885839};\\\", \\\"{x:490,y:744,t:1527876885855};\\\", \\\"{x:459,y:755,t:1527876885871};\\\", \\\"{x:449,y:760,t:1527876885889};\\\", \\\"{x:439,y:763,t:1527876885906};\\\", \\\"{x:426,y:765,t:1527876885922};\\\", \\\"{x:415,y:765,t:1527876885939};\\\", \\\"{x:410,y:764,t:1527876885956};\\\", \\\"{x:406,y:760,t:1527876885972};\\\", \\\"{x:403,y:757,t:1527876885989};\\\", \\\"{x:401,y:741,t:1527876886006};\\\", \\\"{x:397,y:721,t:1527876886023};\\\", \\\"{x:388,y:695,t:1527876886040};\\\", \\\"{x:374,y:675,t:1527876886057};\\\", \\\"{x:358,y:656,t:1527876886073};\\\", \\\"{x:344,y:642,t:1527876886090};\\\", \\\"{x:335,y:626,t:1527876886106};\\\", \\\"{x:321,y:616,t:1527876886122};\\\", \\\"{x:310,y:610,t:1527876886140};\\\", \\\"{x:290,y:603,t:1527876886156};\\\", \\\"{x:287,y:603,t:1527876886173};\\\", \\\"{x:285,y:603,t:1527876886189};\\\", \\\"{x:282,y:605,t:1527876886205};\\\", \\\"{x:276,y:608,t:1527876886223};\\\", \\\"{x:269,y:612,t:1527876886239};\\\", \\\"{x:259,y:616,t:1527876886258};\\\", \\\"{x:246,y:620,t:1527876886272};\\\", \\\"{x:239,y:623,t:1527876886289};\\\", \\\"{x:233,y:624,t:1527876886306};\\\", \\\"{x:231,y:626,t:1527876886323};\\\", \\\"{x:230,y:626,t:1527876886339};\\\", \\\"{x:230,y:625,t:1527876886397};\\\", \\\"{x:234,y:622,t:1527876886406};\\\", \\\"{x:242,y:618,t:1527876886423};\\\", \\\"{x:260,y:610,t:1527876886439};\\\", \\\"{x:276,y:604,t:1527876886456};\\\", \\\"{x:294,y:596,t:1527876886473};\\\", \\\"{x:302,y:594,t:1527876886489};\\\", \\\"{x:312,y:591,t:1527876886506};\\\", \\\"{x:319,y:589,t:1527876886523};\\\", \\\"{x:323,y:589,t:1527876886540};\\\", \\\"{x:325,y:589,t:1527876886556};\\\", \\\"{x:327,y:589,t:1527876886573};\\\", \\\"{x:337,y:589,t:1527876886589};\\\", \\\"{x:339,y:589,t:1527876886606};\\\", \\\"{x:339,y:588,t:1527876886750};\\\", \\\"{x:339,y:587,t:1527876886765};\\\", \\\"{x:342,y:585,t:1527876886781};\\\", \\\"{x:343,y:584,t:1527876886790};\\\", \\\"{x:352,y:584,t:1527876886806};\\\", \\\"{x:359,y:580,t:1527876886824};\\\", \\\"{x:360,y:580,t:1527876886839};\\\", \\\"{x:361,y:580,t:1527876886857};\\\", \\\"{x:362,y:580,t:1527876886885};\\\", \\\"{x:363,y:580,t:1527876886910};\\\", \\\"{x:364,y:580,t:1527876886924};\\\", \\\"{x:367,y:580,t:1527876886940};\\\", \\\"{x:373,y:582,t:1527876886957};\\\", \\\"{x:379,y:584,t:1527876886974};\\\", \\\"{x:382,y:585,t:1527876886991};\\\", \\\"{x:383,y:585,t:1527876887030};\\\", \\\"{x:384,y:585,t:1527876887677};\\\", \\\"{x:387,y:585,t:1527876887690};\\\", \\\"{x:389,y:585,t:1527876887707};\\\", \\\"{x:393,y:585,t:1527876887724};\\\", \\\"{x:397,y:585,t:1527876887741};\\\", \\\"{x:408,y:585,t:1527876887757};\\\", \\\"{x:419,y:588,t:1527876887775};\\\", \\\"{x:428,y:592,t:1527876887790};\\\", \\\"{x:440,y:596,t:1527876887807};\\\", \\\"{x:460,y:604,t:1527876887824};\\\", \\\"{x:476,y:608,t:1527876887842};\\\", \\\"{x:481,y:610,t:1527876887857};\\\", \\\"{x:481,y:611,t:1527876887918};\\\", \\\"{x:481,y:613,t:1527876887933};\\\", \\\"{x:480,y:613,t:1527876887941};\\\", \\\"{x:472,y:617,t:1527876887958};\\\", \\\"{x:466,y:620,t:1527876887974};\\\", \\\"{x:465,y:621,t:1527876887990};\\\", \\\"{x:463,y:621,t:1527876888007};\\\", \\\"{x:461,y:621,t:1527876888092};\\\", \\\"{x:461,y:622,t:1527876888116};\\\", \\\"{x:465,y:623,t:1527876888149};\\\", \\\"{x:469,y:625,t:1527876888157};\\\", \\\"{x:484,y:625,t:1527876888174};\\\", \\\"{x:501,y:625,t:1527876888192};\\\", \\\"{x:525,y:623,t:1527876888207};\\\", \\\"{x:546,y:620,t:1527876888224};\\\", \\\"{x:562,y:618,t:1527876888241};\\\", \\\"{x:576,y:614,t:1527876888257};\\\", \\\"{x:587,y:612,t:1527876888274};\\\", \\\"{x:602,y:611,t:1527876888291};\\\", \\\"{x:621,y:611,t:1527876888307};\\\", \\\"{x:643,y:611,t:1527876888324};\\\", \\\"{x:677,y:611,t:1527876888340};\\\", \\\"{x:704,y:606,t:1527876888357};\\\", \\\"{x:717,y:605,t:1527876888374};\\\", \\\"{x:724,y:601,t:1527876888392};\\\", \\\"{x:728,y:598,t:1527876888408};\\\", \\\"{x:729,y:598,t:1527876888424};\\\", \\\"{x:729,y:597,t:1527876888557};\\\", \\\"{x:720,y:596,t:1527876888577};\\\", \\\"{x:704,y:591,t:1527876888591};\\\", \\\"{x:687,y:587,t:1527876888608};\\\", \\\"{x:682,y:584,t:1527876888624};\\\", \\\"{x:668,y:582,t:1527876888641};\\\", \\\"{x:657,y:579,t:1527876888658};\\\", \\\"{x:638,y:578,t:1527876888674};\\\", \\\"{x:622,y:577,t:1527876888691};\\\", \\\"{x:603,y:577,t:1527876888708};\\\", \\\"{x:590,y:577,t:1527876888724};\\\", \\\"{x:589,y:577,t:1527876888742};\\\", \\\"{x:591,y:577,t:1527876888821};\\\", \\\"{x:594,y:579,t:1527876888829};\\\", \\\"{x:597,y:580,t:1527876888841};\\\", \\\"{x:605,y:581,t:1527876888859};\\\", \\\"{x:609,y:582,t:1527876888875};\\\", \\\"{x:610,y:583,t:1527876888918};\\\", \\\"{x:610,y:586,t:1527876888925};\\\", \\\"{x:610,y:591,t:1527876888941};\\\", \\\"{x:613,y:597,t:1527876888958};\\\", \\\"{x:616,y:600,t:1527876888975};\\\", \\\"{x:617,y:602,t:1527876888991};\\\", \\\"{x:617,y:603,t:1527876889189};\\\", \\\"{x:617,y:604,t:1527876889205};\\\", \\\"{x:617,y:605,t:1527876889220};\\\", \\\"{x:617,y:607,t:1527876889228};\\\", \\\"{x:617,y:612,t:1527876889241};\\\", \\\"{x:614,y:613,t:1527876889258};\\\", \\\"{x:614,y:619,t:1527876889276};\\\", \\\"{x:611,y:624,t:1527876889293};\\\", \\\"{x:605,y:638,t:1527876889308};\\\", \\\"{x:596,y:649,t:1527876889326};\\\", \\\"{x:585,y:664,t:1527876889342};\\\", \\\"{x:579,y:680,t:1527876889358};\\\", \\\"{x:573,y:691,t:1527876889375};\\\", \\\"{x:569,y:700,t:1527876889393};\\\", \\\"{x:564,y:714,t:1527876889408};\\\", \\\"{x:557,y:727,t:1527876889426};\\\", \\\"{x:552,y:734,t:1527876889443};\\\", \\\"{x:544,y:742,t:1527876889458};\\\", \\\"{x:541,y:746,t:1527876889475};\\\", \\\"{x:538,y:749,t:1527876889492};\\\", \\\"{x:537,y:750,t:1527876889508};\\\", \\\"{x:535,y:752,t:1527876889525};\\\", \\\"{x:534,y:752,t:1527876889543};\\\", \\\"{x:533,y:753,t:1527876889558};\\\", \\\"{x:530,y:753,t:1527876889613};\\\", \\\"{x:529,y:754,t:1527876889626};\\\", \\\"{x:527,y:755,t:1527876889644};\\\", \\\"{x:526,y:756,t:1527876889659};\\\", \\\"{x:528,y:755,t:1527876890013};\\\", \\\"{x:534,y:754,t:1527876890025};\\\", \\\"{x:548,y:746,t:1527876890043};\\\", \\\"{x:566,y:739,t:1527876890059};\\\", \\\"{x:593,y:728,t:1527876890075};\\\", \\\"{x:611,y:717,t:1527876890092};\\\", \\\"{x:637,y:701,t:1527876890109};\\\", \\\"{x:657,y:688,t:1527876890127};\\\", \\\"{x:674,y:667,t:1527876890142};\\\", \\\"{x:691,y:647,t:1527876890159};\\\", \\\"{x:754,y:555,t:1527876890176};\\\", \\\"{x:776,y:507,t:1527876890193};\\\", \\\"{x:778,y:496,t:1527876890209};\\\", \\\"{x:778,y:494,t:1527876890226};\\\", \\\"{x:778,y:493,t:1527876890414};\\\" ] }, { \\\"rt\\\": 61767, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 20, \\\"time_elapsed\\\": 560723, \\\"internal_node_id\\\": \\\"0.0-7.0-0.0\\\", \\\"subject\\\": \\\"7BW1K\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\", \\\"q\\\": 16, \\\"answer\\\": \\\"Shifts that start at 12 pm are on the diaganol line that goes up and to the right of the 12pm mark. In this case M and L.\\\\n\\\\nBreaks that start at 12 pm are directly above the 12 pm mark.\\\", \\\"block\\\": \\\"triangular_testing\\\" }, { \\\"rt\\\": 4662, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"22\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"USA\\\\\\\"}\\\", \\\"block\\\": \\\"demo-1\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 21, \\\"time_elapsed\\\": 566392, \\\"internal_node_id\\\": \\\"0.0-8.0\\\", \\\"subject\\\": \\\"7BW1K\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\" }, { \\\"rt\\\": 9688, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"English\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"Fourth\\\\\\\",\\\\\\\"Q2\\\\\\\":\\\\\\\"Math or Computer Sciences\\\\\\\",\\\\\\\"Q3\\\\\\\":\\\\\\\"Male\\\\\\\"}\\\", \\\"block\\\": \\\"demo-2\\\", \\\"trial_type\\\": \\\"survey-multi-choice\\\", \\\"trial_index\\\": 22, \\\"time_elapsed\\\": 577089, \\\"internal_node_id\\\": \\\"0.0-9.0\\\", \\\"subject\\\": \\\"7BW1K\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\" }, { \\\"rt\\\": 2851, \\\"url\\\": \\\"../views/src/external/debrief.html\\\", \\\"block\\\": \\\"debrief\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 23, \\\"time_elapsed\\\": 581281, \\\"internal_node_id\\\": \\\"0.0-10.0\\\", \\\"subject\\\": \\\"7BW1K\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\" } ]\",\"parentNode\":{\"id\":2765}}],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"META\",\"attributes\":{\"charset\":\"utf-8\"}},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":8,\"id\":59},{\"nodeType\":3,\"id\":60,\"textContent\":\" \"},{\"nodeType\":1,\"id\":61,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":62,\"textContent\":\" \"},{\"nodeType\":1,\"id\":63,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":64,\"textContent\":\" \"},{\"nodeType\":1,\"id\":65,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":66,\"textContent\":\" \"},{\"nodeType\":1,\"id\":67,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":68,\"textContent\":\" \"},{\"nodeType\":1,\"id\":69,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":70,\"textContent\":\" \"},{\"nodeType\":1,\"id\":71,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":72,\"textContent\":\" \"},{\"nodeType\":1,\"id\":73,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"stimulus\"},\"childNodes\":[{\"nodeType\":3,\"id\":74,\"textContent\":\" \"},{\"nodeType\":1,\"id\":75,\"tagName\":\"P\",\"attributes\":{\"class\":\"userid\",\"id\":\"userid\"},\"childNodes\":[{\"nodeType\":3,\"id\":76,\"textContent\":\"7BW1K\"}]},{\"nodeType\":3,\"id\":77,\"textContent\":\" \"},{\"nodeType\":1,\"id\":78,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"userinput\"},\"childNodes\":[{\"nodeType\":3,\"id\":79,\"textContent\":\" \"},{\"nodeType\":8,\"id\":80},{\"nodeType\":3,\"id\":81,\"textContent\":\" \"},{\"nodeType\":1,\"id\":82,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"legend\",\"id\":\"hint-interactive\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":83,\"textContent\":\" \"},{\"nodeType\":1,\"id\":84,\"tagName\":\"P\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":85,\"textContent\":\"Hint: Hover your mouse over the data points in the graph\"}]},{\"nodeType\":3,\"id\":86,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":87,\"textContent\":\" \"},{\"nodeType\":8,\"id\":88},{\"nodeType\":3,\"id\":89,\"textContent\":\" \"},{\"nodeType\":8,\"id\":90},{\"nodeType\":3,\"id\":91,\"textContent\":\" \"},{\"nodeType\":1,\"id\":92,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"test\"},\"childNodes\":[{\"nodeType\":3,\"id\":93,\"textContent\":\" \"},{\"nodeType\":1,\"id\":94,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":95,\"textContent\":\" \"},{\"nodeType\":1,\"id\":96,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":97,\"textContent\":\"Which shift(s) start at 11 am? \"}]},{\"nodeType\":3,\"id\":98,\"textContent\":\" \"},{\"nodeType\":1,\"id\":99,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":100,\"textContent\":\" \"},{\"nodeType\":1,\"id\":101,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":102,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":103,\"textContent\":\" \"},{\"nodeType\":1,\"id\":104,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":105,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":106,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":107,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":108,\"textContent\":\" \"},{\"nodeType\":1,\"id\":109,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":110,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":111,\"textContent\":\" \"},{\"nodeType\":1,\"id\":112,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":113,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":115,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":116,\"textContent\":\" \"},{\"nodeType\":1,\"id\":117,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":118,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":120,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":121,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":122,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":123,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":125,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":126,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":127,\"textContent\":\" \"},{\"nodeType\":1,\"id\":128,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":129,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":130,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":132,\"textContent\":\" \"},{\"nodeType\":1,\"id\":133,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":134,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":135,\"textContent\":\" \"},{\"nodeType\":1,\"id\":136,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":137,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":138,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":140,\"textContent\":\" \"},{\"nodeType\":1,\"id\":141,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":142,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":143,\"textContent\":\" \"},{\"nodeType\":1,\"id\":144,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":145,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":146,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":147,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":148,\"textContent\":\" \"},{\"nodeType\":1,\"id\":149,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":150,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":151,\"textContent\":\" \"},{\"nodeType\":1,\"id\":152,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":153,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":154,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":156,\"textContent\":\" \"},{\"nodeType\":1,\"id\":157,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":158,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":159,\"textContent\":\" \"},{\"nodeType\":1,\"id\":160,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":161,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":162,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":163,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":164,\"textContent\":\" \"},{\"nodeType\":1,\"id\":165,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":166,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":167,\"textContent\":\" \"},{\"nodeType\":1,\"id\":168,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":169,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":170,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":171,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":172,\"textContent\":\" \"},{\"nodeType\":1,\"id\":173,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":174,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":175,\"textContent\":\" \"},{\"nodeType\":1,\"id\":176,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":177,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":178,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":179,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":180,\"textContent\":\" \"},{\"nodeType\":1,\"id\":181,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":182,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":183,\"textContent\":\" \"},{\"nodeType\":1,\"id\":184,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":185,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":186,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":187,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":188,\"textContent\":\" \"},{\"nodeType\":1,\"id\":189,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":190,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":191,\"textContent\":\" \"},{\"nodeType\":1,\"id\":192,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":193,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":194,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":196,\"textContent\":\" \"},{\"nodeType\":1,\"id\":197,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":198,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":200,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":201,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":202,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":203,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":205,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":206,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":207,\"textContent\":\" \"},{\"nodeType\":1,\"id\":208,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":209,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":210,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":211,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":212,\"textContent\":\" \"},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":214,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":215,\"textContent\":\" \"},{\"nodeType\":1,\"id\":216,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":217,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":218,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":219,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":220,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":221,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":223,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":224,\"textContent\":\" \"},{\"nodeType\":1,\"id\":225,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":226,\"textContent\":\"Which shift(s) start at the same time as D?\"}]},{\"nodeType\":3,\"id\":227,\"textContent\":\" \"},{\"nodeType\":1,\"id\":228,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":229,\"textContent\":\" \"},{\"nodeType\":1,\"id\":230,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":231,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":232,\"textContent\":\" \"},{\"nodeType\":1,\"id\":233,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":234,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":235,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":236,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":237,\"textContent\":\" \"},{\"nodeType\":1,\"id\":238,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":239,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":240,\"textContent\":\" \"},{\"nodeType\":1,\"id\":241,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":242,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":243,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":244,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":245,\"textContent\":\" \"},{\"nodeType\":1,\"id\":246,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":247,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":248,\"textContent\":\" \"},{\"nodeType\":1,\"id\":249,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":250,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":251,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":252,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":253,\"textContent\":\" \"},{\"nodeType\":1,\"id\":254,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":255,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":256,\"textContent\":\" \"},{\"nodeType\":1,\"id\":257,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":258,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":259,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":260,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":261,\"textContent\":\" \"},{\"nodeType\":1,\"id\":262,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":263,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":264,\"textContent\":\" \"},{\"nodeType\":1,\"id\":265,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":266,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":267,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":268,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":269,\"textContent\":\" \"},{\"nodeType\":1,\"id\":270,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":271,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":273,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":274,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":275,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":276,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":278,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":279,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":280,\"textContent\":\" \"},{\"nodeType\":1,\"id\":281,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":282,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":283,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":284,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":286,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":287,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":288,\"textContent\":\" \"},{\"nodeType\":1,\"id\":289,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":290,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":291,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":292,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":293,\"textContent\":\" \"},{\"nodeType\":1,\"id\":294,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":295,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":296,\"textContent\":\" \"},{\"nodeType\":1,\"id\":297,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":298,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":299,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":300,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":301,\"textContent\":\" \"},{\"nodeType\":1,\"id\":302,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":303,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":304,\"textContent\":\" \"},{\"nodeType\":1,\"id\":305,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":306,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":307,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":308,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":309,\"textContent\":\" \"},{\"nodeType\":1,\"id\":310,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":311,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":312,\"textContent\":\" \"},{\"nodeType\":1,\"id\":313,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":314,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":315,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":316,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":317,\"textContent\":\" \"},{\"nodeType\":1,\"id\":318,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":319,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":320,\"textContent\":\" \"},{\"nodeType\":1,\"id\":321,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":322,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":323,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":324,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":325,\"textContent\":\" \"},{\"nodeType\":1,\"id\":326,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":327,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":328,\"textContent\":\" \"},{\"nodeType\":1,\"id\":329,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":330,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":331,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":332,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":333,\"textContent\":\" \"},{\"nodeType\":1,\"id\":334,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":335,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":336,\"textContent\":\" \"},{\"nodeType\":1,\"id\":337,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":338,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":339,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":340,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":341,\"textContent\":\" \"},{\"nodeType\":1,\"id\":342,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":343,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":344,\"textContent\":\" \"},{\"nodeType\":1,\"id\":345,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":346,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":347,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":348,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":349,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":351,\"textContent\":\" \"},{\"nodeType\":1,\"id\":352,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":353,\"textContent\":\" \"},{\"nodeType\":1,\"id\":354,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":355,\"textContent\":\"Which shift(s) begin when C ends?\"}]},{\"nodeType\":3,\"id\":356,\"textContent\":\" \"},{\"nodeType\":1,\"id\":357,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":358,\"textContent\":\" \"},{\"nodeType\":1,\"id\":359,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":360,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":361,\"textContent\":\" \"},{\"nodeType\":1,\"id\":362,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":363,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":364,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":365,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":366,\"textContent\":\" \"},{\"nodeType\":1,\"id\":367,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":368,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":369,\"textContent\":\" \"},{\"nodeType\":1,\"id\":370,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":371,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":372,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":373,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":374,\"textContent\":\" \"},{\"nodeType\":1,\"id\":375,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":376,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":377,\"textContent\":\" \"},{\"nodeType\":1,\"id\":378,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":379,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":380,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":381,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":382,\"textContent\":\" \"},{\"nodeType\":1,\"id\":383,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":384,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":385,\"textContent\":\" \"},{\"nodeType\":1,\"id\":386,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":387,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":388,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":389,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":390,\"textContent\":\" \"},{\"nodeType\":1,\"id\":391,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":392,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":393,\"textContent\":\" \"},{\"nodeType\":1,\"id\":394,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":395,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":396,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":397,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":398,\"textContent\":\" \"},{\"nodeType\":1,\"id\":399,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":400,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":401,\"textContent\":\" \"},{\"nodeType\":1,\"id\":402,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":403,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":404,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":405,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":406,\"textContent\":\" \"},{\"nodeType\":1,\"id\":407,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":408,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":409,\"textContent\":\" \"},{\"nodeType\":1,\"id\":410,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":411,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":412,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":413,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":414,\"textContent\":\" \"},{\"nodeType\":1,\"id\":415,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":416,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":417,\"textContent\":\" \"},{\"nodeType\":1,\"id\":418,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":419,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":420,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":421,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":422,\"textContent\":\" \"},{\"nodeType\":1,\"id\":423,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":424,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":425,\"textContent\":\" \"},{\"nodeType\":1,\"id\":426,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":427,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":428,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":429,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":430,\"textContent\":\" \"},{\"nodeType\":1,\"id\":431,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":432,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":433,\"textContent\":\" \"},{\"nodeType\":1,\"id\":434,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":435,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":436,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":437,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":438,\"textContent\":\" \"},{\"nodeType\":1,\"id\":439,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":440,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":441,\"textContent\":\" \"},{\"nodeType\":1,\"id\":442,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":443,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":444,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":445,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":446,\"textContent\":\" \"},{\"nodeType\":1,\"id\":447,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":448,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":449,\"textContent\":\" \"},{\"nodeType\":1,\"id\":450,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":451,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":452,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":453,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":454,\"textContent\":\" \"},{\"nodeType\":1,\"id\":455,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":456,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":457,\"textContent\":\" \"},{\"nodeType\":1,\"id\":458,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":459,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":460,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":461,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":462,\"textContent\":\" \"},{\"nodeType\":1,\"id\":463,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":464,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":465,\"textContent\":\" \"},{\"nodeType\":1,\"id\":466,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":467,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":468,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":469,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":470,\"textContent\":\" \"},{\"nodeType\":1,\"id\":471,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":472,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":473,\"textContent\":\" \"},{\"nodeType\":1,\"id\":474,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":475,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":476,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":477,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":478,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":479,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":480,\"textContent\":\" \"},{\"nodeType\":1,\"id\":481,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":483,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":484,\"textContent\":\" Which shift(s) end at 4 pm?\"}]},{\"nodeType\":3,\"id\":485,\"textContent\":\" \"},{\"nodeType\":1,\"id\":486,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":492,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":500,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":503,\"textContent\":\" \"},{\"nodeType\":1,\"id\":504,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":505,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":506,\"textContent\":\" \"},{\"nodeType\":1,\"id\":507,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":508,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":509,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":510,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":511,\"textContent\":\" \"},{\"nodeType\":1,\"id\":512,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":513,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":514,\"textContent\":\" \"},{\"nodeType\":1,\"id\":515,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":516,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":517,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":518,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":519,\"textContent\":\" \"},{\"nodeType\":1,\"id\":520,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":521,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":522,\"textContent\":\" \"},{\"nodeType\":1,\"id\":523,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":524,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":525,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":526,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":527,\"textContent\":\" \"},{\"nodeType\":1,\"id\":528,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":529,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":530,\"textContent\":\" \"},{\"nodeType\":1,\"id\":531,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":532,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":533,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":534,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":535,\"textContent\":\" \"},{\"nodeType\":1,\"id\":536,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":537,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":538,\"textContent\":\" \"},{\"nodeType\":1,\"id\":539,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":540,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":541,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":542,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":543,\"textContent\":\" \"},{\"nodeType\":1,\"id\":544,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":545,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":546,\"textContent\":\" \"},{\"nodeType\":1,\"id\":547,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":548,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":549,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":550,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":551,\"textContent\":\" \"},{\"nodeType\":1,\"id\":552,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":553,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":554,\"textContent\":\" \"},{\"nodeType\":1,\"id\":555,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":556,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":557,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":558,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":559,\"textContent\":\" \"},{\"nodeType\":1,\"id\":560,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":561,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":562,\"textContent\":\" \"},{\"nodeType\":1,\"id\":563,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":564,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":565,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":566,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":567,\"textContent\":\" \"},{\"nodeType\":1,\"id\":568,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":569,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":570,\"textContent\":\" \"},{\"nodeType\":1,\"id\":571,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":572,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":573,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":574,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":575,\"textContent\":\" \"},{\"nodeType\":1,\"id\":576,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":577,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":578,\"textContent\":\" \"},{\"nodeType\":1,\"id\":579,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":580,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":581,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":582,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":583,\"textContent\":\" \"},{\"nodeType\":1,\"id\":584,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":585,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":586,\"textContent\":\" \"},{\"nodeType\":1,\"id\":587,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":588,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":589,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":590,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":592,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":593,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":594,\"textContent\":\" \"},{\"nodeType\":1,\"id\":595,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":596,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":597,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":598,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":599,\"textContent\":\" \"},{\"nodeType\":1,\"id\":600,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":601,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":602,\"textContent\":\" \"},{\"nodeType\":1,\"id\":603,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":604,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":605,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":606,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":607,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":608,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":609,\"textContent\":\" \"},{\"nodeType\":1,\"id\":610,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":612,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":613,\"textContent\":\"Coffee breaks happen halfway through a shift.\"},{\"nodeType\":1,\"id\":614,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":615,\"textContent\":\" Which shift(s) share a break with I?\"}]},{\"nodeType\":3,\"id\":616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":617,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":618,\"textContent\":\" \"},{\"nodeType\":1,\"id\":619,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":620,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":621,\"textContent\":\" \"},{\"nodeType\":1,\"id\":622,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":623,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":624,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":625,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":626,\"textContent\":\" \"},{\"nodeType\":1,\"id\":627,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":628,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":629,\"textContent\":\" \"},{\"nodeType\":1,\"id\":630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":631,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":632,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":633,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":634,\"textContent\":\" \"},{\"nodeType\":1,\"id\":635,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":636,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":637,\"textContent\":\" \"},{\"nodeType\":1,\"id\":638,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":639,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":640,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":641,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":642,\"textContent\":\" \"},{\"nodeType\":1,\"id\":643,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":644,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":645,\"textContent\":\" \"},{\"nodeType\":1,\"id\":646,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":647,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":648,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":649,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":650,\"textContent\":\" \"},{\"nodeType\":1,\"id\":651,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":653,\"textContent\":\" \"},{\"nodeType\":1,\"id\":654,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":655,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":656,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":657,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":659,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":660,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":661,\"textContent\":\" \"},{\"nodeType\":1,\"id\":662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":663,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":664,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":665,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":666,\"textContent\":\" \"},{\"nodeType\":1,\"id\":667,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":668,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":669,\"textContent\":\" \"},{\"nodeType\":1,\"id\":670,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":671,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":672,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":673,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":674,\"textContent\":\" \"},{\"nodeType\":1,\"id\":675,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":676,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":677,\"textContent\":\" \"},{\"nodeType\":1,\"id\":678,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":679,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":680,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":681,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":682,\"textContent\":\" \"},{\"nodeType\":1,\"id\":683,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":685,\"textContent\":\" \"},{\"nodeType\":1,\"id\":686,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":687,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":688,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":689,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":690,\"textContent\":\" \"},{\"nodeType\":1,\"id\":691,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":692,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":693,\"textContent\":\" \"},{\"nodeType\":1,\"id\":694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":695,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":696,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":697,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":698,\"textContent\":\" \"},{\"nodeType\":1,\"id\":699,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":700,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":701,\"textContent\":\" \"},{\"nodeType\":1,\"id\":702,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":703,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":704,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":705,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":706,\"textContent\":\" \"},{\"nodeType\":1,\"id\":707,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":708,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":709,\"textContent\":\" \"},{\"nodeType\":1,\"id\":710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":711,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":712,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":713,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":714,\"textContent\":\" \"},{\"nodeType\":1,\"id\":715,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":716,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":717,\"textContent\":\" \"},{\"nodeType\":1,\"id\":718,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":719,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":720,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":721,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":722,\"textContent\":\" \"},{\"nodeType\":1,\"id\":723,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":724,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":725,\"textContent\":\" \"},{\"nodeType\":1,\"id\":726,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":727,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":728,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":729,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":730,\"textContent\":\" \"},{\"nodeType\":1,\"id\":731,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":732,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":733,\"textContent\":\" \"},{\"nodeType\":1,\"id\":734,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":735,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":736,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":737,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":738,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":739,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":741,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":742,\"textContent\":\" \"},{\"nodeType\":1,\"id\":743,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":744,\"textContent\":\"Which shift(s) are six hours long?\"}]},{\"nodeType\":3,\"id\":745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":746,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":747,\"textContent\":\" \"},{\"nodeType\":1,\"id\":748,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":749,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":750,\"textContent\":\" \"},{\"nodeType\":1,\"id\":751,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":752,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":753,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":754,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":755,\"textContent\":\" \"},{\"nodeType\":1,\"id\":756,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":757,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":758,\"textContent\":\" \"},{\"nodeType\":1,\"id\":759,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":760,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":761,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":762,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":763,\"textContent\":\" \"},{\"nodeType\":1,\"id\":764,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":765,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":766,\"textContent\":\" \"},{\"nodeType\":1,\"id\":767,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":768,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":769,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":770,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":771,\"textContent\":\" \"},{\"nodeType\":1,\"id\":772,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":773,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":774,\"textContent\":\" \"},{\"nodeType\":1,\"id\":775,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":776,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":777,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":778,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":779,\"textContent\":\" \"},{\"nodeType\":1,\"id\":780,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":781,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":782,\"textContent\":\" \"},{\"nodeType\":1,\"id\":783,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":784,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":785,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":786,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":787,\"textContent\":\" \"},{\"nodeType\":1,\"id\":788,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":789,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":790,\"textContent\":\" \"},{\"nodeType\":1,\"id\":791,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":792,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":793,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":794,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":795,\"textContent\":\" \"},{\"nodeType\":1,\"id\":796,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":797,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":798,\"textContent\":\" \"},{\"nodeType\":1,\"id\":799,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":800,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":801,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":802,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":803,\"textContent\":\" \"},{\"nodeType\":1,\"id\":804,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":805,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":806,\"textContent\":\" \"},{\"nodeType\":1,\"id\":807,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":808,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":809,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":810,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":812,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":813,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":814,\"textContent\":\" \"},{\"nodeType\":1,\"id\":815,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":816,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":817,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":818,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":819,\"textContent\":\" \"},{\"nodeType\":1,\"id\":820,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":821,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":822,\"textContent\":\" \"},{\"nodeType\":1,\"id\":823,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":824,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":825,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":826,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":827,\"textContent\":\" \"},{\"nodeType\":1,\"id\":828,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":829,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":830,\"textContent\":\" \"},{\"nodeType\":1,\"id\":831,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":832,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":833,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":834,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":835,\"textContent\":\" \"},{\"nodeType\":1,\"id\":836,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":837,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":838,\"textContent\":\" \"},{\"nodeType\":1,\"id\":839,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":840,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":841,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":842,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":843,\"textContent\":\" \"},{\"nodeType\":1,\"id\":844,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":845,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":846,\"textContent\":\" \"},{\"nodeType\":1,\"id\":847,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":848,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":849,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":850,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":851,\"textContent\":\" \"},{\"nodeType\":1,\"id\":852,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":853,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":854,\"textContent\":\" \"},{\"nodeType\":1,\"id\":855,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":856,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":857,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":858,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":859,\"textContent\":\" \"},{\"nodeType\":1,\"id\":860,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":861,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":862,\"textContent\":\" \"},{\"nodeType\":1,\"id\":863,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":864,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":865,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":866,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":867,\"textContent\":\" \"},{\"nodeType\":1,\"id\":868,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":869,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":870,\"textContent\":\" \"},{\"nodeType\":1,\"id\":871,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":872,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":873,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":874,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":875,\"textContent\":\" \"},{\"nodeType\":1,\"id\":876,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":877,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":878,\"textContent\":\" \"},{\"nodeType\":1,\"id\":879,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":880,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":881,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":882,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":883,\"textContent\":\" \"},{\"nodeType\":1,\"id\":884,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":885,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":886,\"textContent\":\" \"},{\"nodeType\":1,\"id\":887,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":888,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":889,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":890,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":891,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":892,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":894,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":895,\"textContent\":\" \"},{\"nodeType\":1,\"id\":896,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":897,\"textContent\":\"Which 2 shifts less than 5 hours long start at the same time?\"}]},{\"nodeType\":3,\"id\":898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":899,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":900,\"textContent\":\" \"},{\"nodeType\":1,\"id\":901,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":902,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":903,\"textContent\":\" \"},{\"nodeType\":1,\"id\":904,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":905,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":906,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":907,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":908,\"textContent\":\" \"},{\"nodeType\":1,\"id\":909,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":910,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":911,\"textContent\":\" \"},{\"nodeType\":1,\"id\":912,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":913,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":914,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":915,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":916,\"textContent\":\" \"},{\"nodeType\":1,\"id\":917,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":918,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":919,\"textContent\":\" \"},{\"nodeType\":1,\"id\":920,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":921,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":922,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":923,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":924,\"textContent\":\" \"},{\"nodeType\":1,\"id\":925,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":926,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":927,\"textContent\":\" \"},{\"nodeType\":1,\"id\":928,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":929,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":930,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":931,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":932,\"textContent\":\" \"},{\"nodeType\":1,\"id\":933,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":934,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":935,\"textContent\":\" \"},{\"nodeType\":1,\"id\":936,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":937,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":938,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":939,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":940,\"textContent\":\" \"},{\"nodeType\":1,\"id\":941,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":942,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":943,\"textContent\":\" \"},{\"nodeType\":1,\"id\":944,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":945,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":946,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":947,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":948,\"textContent\":\" \"},{\"nodeType\":1,\"id\":949,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":950,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":951,\"textContent\":\" \"},{\"nodeType\":1,\"id\":952,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":953,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":954,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":955,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":956,\"textContent\":\" \"},{\"nodeType\":1,\"id\":957,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":958,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":959,\"textContent\":\" \"},{\"nodeType\":1,\"id\":960,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":961,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":962,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":963,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":965,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":966,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":967,\"textContent\":\" \"},{\"nodeType\":1,\"id\":968,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":969,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":970,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":971,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":972,\"textContent\":\" \"},{\"nodeType\":1,\"id\":973,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":974,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":975,\"textContent\":\" \"},{\"nodeType\":1,\"id\":976,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":977,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":978,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":979,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":980,\"textContent\":\" \"},{\"nodeType\":1,\"id\":981,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":982,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":983,\"textContent\":\" \"},{\"nodeType\":1,\"id\":984,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":985,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":986,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":987,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":988,\"textContent\":\" \"},{\"nodeType\":1,\"id\":989,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":990,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":991,\"textContent\":\" \"},{\"nodeType\":1,\"id\":992,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":993,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":994,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":995,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":996,\"textContent\":\" \"},{\"nodeType\":1,\"id\":997,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":998,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":999,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1000,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1001,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1002,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1003,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1004,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1005,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1006,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1007,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1008,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1009,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1010,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1011,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1012,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1013,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1014,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1015,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1016,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1017,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1018,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1019,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1020,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1021,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1022,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1023,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1024,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1025,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1026,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1027,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1028,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1029,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1030,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1031,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1032,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1033,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1034,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1035,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1036,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1037,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1038,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1039,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1040,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1041,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1042,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1043,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1044,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1045,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1047,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+contained\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1048,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1049,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1050,\"textContent\":\"Which shift(s) under 7 hours long starts before B starts, and ends after X ends?\"}]},{\"nodeType\":3,\"id\":1051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1052,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1053,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1054,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1055,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1056,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1057,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1058,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1059,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1060,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1061,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1062,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1063,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1064,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1065,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1066,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1067,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1068,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1069,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1070,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1071,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1072,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1073,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1074,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1075,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1076,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1077,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1078,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1079,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1080,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1081,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1082,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1083,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1084,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1085,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1086,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1087,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1088,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1089,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1090,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1091,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1092,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1093,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1094,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1095,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1096,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1097,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1098,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1099,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1100,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1101,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1102,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1103,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1104,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1105,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1106,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1107,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1108,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1109,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1110,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1111,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1112,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1113,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1114,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1115,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1116,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1118,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1119,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1120,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1121,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1122,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1123,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1124,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1125,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1126,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1127,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1128,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1129,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1130,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1131,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1132,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1133,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1134,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1135,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1136,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1137,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1138,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1139,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1140,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1141,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1142,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1143,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1144,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1145,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1146,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1147,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1148,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1149,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1150,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1151,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1152,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1153,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1154,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1155,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1156,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1157,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1158,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1159,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1160,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1161,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1162,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1163,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1164,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1165,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1166,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1167,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1168,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1169,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1170,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1171,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1172,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1173,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1174,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1175,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1176,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1177,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1178,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1179,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1180,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1181,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1182,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1183,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1184,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1185,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1186,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1187,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1188,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1189,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1190,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1191,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1192,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1193,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1194,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1195,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1196,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1197,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1198,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1200,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime+before+endtime+during\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1202,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1203,\"textContent\":\"Which shift(s) begins before J begins and ends during B?\"}]},{\"nodeType\":3,\"id\":1204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1205,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1211,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1219,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1227,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1235,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1243,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1251,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1259,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1267,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1270,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1271,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1272,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1273,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1274,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1275,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1276,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1277,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1278,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1279,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1280,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1281,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1282,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1283,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1284,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1285,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1286,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1287,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1288,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1289,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1290,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1291,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1292,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1293,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1294,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1295,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1296,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1298,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1299,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1300,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1301,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1302,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1303,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1304,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1305,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1306,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1307,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1308,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1309,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1310,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1311,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1312,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1313,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1314,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1315,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1316,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1317,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1318,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1319,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1320,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1321,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1322,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1323,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1324,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1325,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1326,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1327,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1328,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1329,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1330,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1331,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1332,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1333,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1334,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1335,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1336,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1337,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1338,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1339,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1340,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1341,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1342,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1343,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1344,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1345,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1346,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1347,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1348,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1349,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1351,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1352,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1353,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.ends\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1354,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1355,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1356,\"textContent\":\"Which shift(s) end at the same time as F?\"}]},{\"nodeType\":3,\"id\":1357,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1358,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1359,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1360,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1361,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1362,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1363,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1364,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1365,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1366,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1367,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1368,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1369,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1370,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1371,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1372,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1373,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1374,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1375,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1376,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1377,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1378,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1379,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1380,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1381,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1382,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1383,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1384,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1385,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1386,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1387,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1388,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1389,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1390,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1391,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1392,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1393,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1394,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1395,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1396,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1397,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1398,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1399,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1400,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1401,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1402,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1403,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1404,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1405,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1406,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1407,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1408,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1409,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1410,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1411,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1412,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1413,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1414,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1415,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1416,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1417,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1418,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1419,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1420,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1421,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1422,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1423,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1424,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1425,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1426,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1427,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1428,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1429,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1430,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1431,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1432,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1433,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1434,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1435,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1436,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1437,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1438,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1439,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1440,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1441,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1442,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1443,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1444,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1445,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1446,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1447,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1448,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1449,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1450,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1451,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1452,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1453,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1454,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1455,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1456,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1457,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1458,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1459,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1460,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1461,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1462,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1463,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1464,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1465,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1466,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1467,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1468,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1469,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1470,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1471,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1472,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1473,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1474,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1475,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1476,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1477,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1478,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1479,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1480,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1481,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1483,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1484,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1485,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1486,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1492,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1500,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1503,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1504,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1505,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1506,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1507,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1508,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1509,\"textContent\":\"Which shift(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":1510,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1511,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1512,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1513,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1514,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1515,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1516,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1517,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1518,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1519,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1520,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1521,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1522,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1523,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1524,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1525,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1526,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1527,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1528,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1529,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1530,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1531,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1532,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1533,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1534,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1535,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1536,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1537,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1538,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1539,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1540,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1541,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1542,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1543,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1544,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1545,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1546,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1547,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1548,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1549,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1550,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1551,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1552,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1553,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1554,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1555,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1556,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1557,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1558,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1559,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1560,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1561,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1562,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1563,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1564,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1565,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1566,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1567,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1568,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1569,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1570,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1571,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1572,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1573,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1574,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1575,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1576,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1577,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1578,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1579,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1580,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1581,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1582,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1583,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1584,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1585,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1586,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1587,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1588,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1589,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1590,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1591,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1592,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1593,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1594,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1595,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1596,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1597,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1598,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1599,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1600,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1601,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1602,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1603,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1604,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1605,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1606,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1607,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1608,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1609,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1610,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1612,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1613,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1614,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1615,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1617,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1618,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1619,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1620,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1621,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1622,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1623,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1624,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1625,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1627,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1628,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1629,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1630,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1631,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1632,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1633,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1634,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1635,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1636,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1637,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1638,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1639,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1640,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1641,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1642,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1643,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1644,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1645,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1646,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1647,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1648,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1649,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1650,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1651,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1652,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1653,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1654,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1655,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1656,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1657,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1659,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1660,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1661,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1662,\"textContent\":\"Which shift(s) start at the same time as F?\"}]},{\"nodeType\":3,\"id\":1663,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1664,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1665,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1666,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1667,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1668,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1669,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1670,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1671,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1672,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1673,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1674,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1675,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1676,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1677,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1678,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1679,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1680,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1681,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1682,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1683,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1684,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1686,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1687,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1688,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1689,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1690,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1691,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1692,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1693,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1694,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1695,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1696,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1697,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1698,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1699,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1700,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1701,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1702,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1703,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1704,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1705,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1706,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1707,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1708,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1709,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1710,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1711,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1712,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1713,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1714,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1715,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1716,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1717,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1718,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1720,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1721,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1722,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1723,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1724,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1725,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1726,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1727,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1728,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1729,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1730,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1731,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1732,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1733,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1734,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1735,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1736,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1737,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1738,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1739,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1741,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1742,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1743,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1744,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1746,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1747,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1748,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1749,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1750,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1751,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1752,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1753,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1754,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1755,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1756,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1757,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1758,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1759,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1760,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1761,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1762,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1763,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1764,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1765,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1766,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1767,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1768,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1769,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1770,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1771,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1772,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1773,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1774,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1775,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1776,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1777,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1778,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1779,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1780,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1781,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1782,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1783,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1784,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1785,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1786,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1787,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1788,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1789,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1790,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1791,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1792,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1793,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1794,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1795,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1796,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1797,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1798,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1799,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1800,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1801,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1802,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1803,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1804,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1805,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1806,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1807,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1808,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1809,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1810,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1812,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1813,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1814,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1815,\"textContent\":\"Which 2 shifts end when Z begins?\"}]},{\"nodeType\":3,\"id\":1816,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1817,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1818,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1819,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1820,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1821,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1822,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1823,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1824,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1825,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1826,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1827,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1828,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1829,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1830,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1831,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1832,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1833,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1834,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1835,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1836,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1837,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1838,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1839,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1840,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1841,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1842,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1843,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1844,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1845,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1846,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1847,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1848,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1849,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1850,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1851,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1852,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1853,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1854,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1855,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1856,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1857,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1858,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1859,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1860,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1861,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1862,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1863,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1864,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1865,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1866,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1867,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1868,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1869,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1870,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1871,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1872,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1873,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1874,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1875,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1876,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1877,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1878,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1879,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1880,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1881,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1882,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1883,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1884,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1885,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1886,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1887,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1888,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1889,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1890,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1891,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1892,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1894,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1895,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1896,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1897,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1899,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1900,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1901,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1902,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1903,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1904,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1905,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1906,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1907,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1908,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1909,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1910,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1911,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1912,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1913,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1914,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1915,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1916,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1917,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1918,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1919,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1920,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1921,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1922,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1923,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1924,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1925,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1926,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1927,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1928,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1929,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1930,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1931,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1932,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1933,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1934,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1935,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1936,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1937,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1938,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1939,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1940,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1941,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1942,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1943,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1944,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1945,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1946,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1947,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1948,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1949,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1950,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1951,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1952,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1953,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1954,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1955,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1956,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1957,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1958,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1959,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1960,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1961,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1962,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1963,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1965,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1966,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1967,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1968,\"textContent\":\"Which shift(s) end at 3pm?\"}]},{\"nodeType\":3,\"id\":1969,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1970,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1971,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1972,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1973,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1974,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1975,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1976,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1977,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1978,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1979,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1980,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1981,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1982,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1983,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1984,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1985,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1986,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1987,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1988,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1989,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1990,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1991,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1992,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1993,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1994,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1995,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1996,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1997,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1998,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1999,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2000,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2001,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2002,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2003,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2004,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2005,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2006,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2007,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2008,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2009,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2010,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2011,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2012,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2013,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2014,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2015,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2016,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2017,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2018,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2019,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2020,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2021,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2022,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2023,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2024,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2025,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2026,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2027,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2028,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2029,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2030,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2031,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2032,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2033,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2034,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2035,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2036,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2037,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2038,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2039,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2040,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2041,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2042,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2043,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2044,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2045,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2047,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2048,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2049,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2050,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2052,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2053,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2054,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2055,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2056,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2057,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2058,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2059,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2060,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2061,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2062,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2063,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2064,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2065,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2066,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2067,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2068,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2069,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2070,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2071,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2072,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2073,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2074,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2075,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2076,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2077,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2078,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2079,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2080,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2081,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2082,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2083,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2084,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2085,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2086,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2087,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2088,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2089,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2090,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2091,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2092,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2093,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2094,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2095,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2096,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2097,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2098,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2099,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2100,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2101,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2102,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2103,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2104,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2105,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2106,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2107,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2108,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2109,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2110,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2111,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2112,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2113,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2114,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2115,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2116,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2118,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":2119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2120,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2121,\"textContent\":\"Coffee breaks happen halfway through a shift. \"},{\"nodeType\":1,\"id\":2122,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":2123,\"textContent\":\"Which shifts share a break at 2pm?\"}]},{\"nodeType\":3,\"id\":2124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2125,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":2126,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2127,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2128,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2129,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2130,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2131,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":2132,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2133,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2134,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2135,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2136,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2137,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2138,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2139,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":2140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2141,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2142,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2143,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2144,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2145,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2146,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2147,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":2148,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2149,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2150,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2151,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2152,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2153,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2154,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2155,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2156,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2157,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2158,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2159,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2160,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2161,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2162,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2163,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2164,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2165,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2166,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2167,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2168,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2169,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2170,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2171,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2172,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2173,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2174,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2175,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2176,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2177,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2178,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2179,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2180,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2181,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2182,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2183,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2184,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2185,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2186,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2187,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2188,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2189,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2190,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2191,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2192,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2193,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2194,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2195,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2196,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2197,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2198,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2199,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2200,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2202,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2203,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2204,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2205,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2211,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2219,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2227,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2235,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2243,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2251,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2259,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2267,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2270,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2271,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2273,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\".strategy\",\"style\":\"display: block;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2274,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2275,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2276,\"textContent\":\"Please describe how to determine what event(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":2277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2278,\"tagName\":\"TEXTAREA\",\"attributes\":{\"id\":\"strategyAnswer\",\"rows\":\"5\",\"cols\":\"80\"}},{\"nodeType\":3,\"id\":2279,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2280,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2281,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2282},{\"nodeType\":3,\"id\":2283,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2284},{\"nodeType\":3,\"id\":2285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2286,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"fixbottom\"},\"childNodes\":[{\"nodeType\":3,\"id\":2287,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2288,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"testingButton\",\"style\":\"display:none;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2289,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2290,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2291,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"strategyButton\",\"style\":\"display: block;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2292,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2293,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2294,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2295,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2296},{\"nodeType\":3,\"id\":2297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2298,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"d3container\"},\"childNodes\":[{\"nodeType\":1,\"id\":2299,\"tagName\":\"svg\",\"attributes\":{\"width\":\"930\",\"height\":\"915\"},\"childNodes\":[{\"nodeType\":1,\"id\":2300,\"tagName\":\"g\",\"attributes\":{\"transform\":\"translate(100,25)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2301,\"tagName\":\"g\",\"attributes\":{\"class\":\"leaders\"}},{\"nodeType\":1,\"id\":2302,\"tagName\":\"g\",\"attributes\":{\"class\":\"static-scaffold\"}},{\"nodeType\":1,\"id\":2303,\"tagName\":\"g\",\"attributes\":{\"class\":\"xaxis\",\"transform\":\"translate(0,800)\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"middle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2304,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M0.5,6V0.5H800.5V6\"}},{\"nodeType\":1,\"id\":2305,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2306,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2307,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2308,\"textContent\":\"08 AM\"}]}]},{\"nodeType\":1,\"id\":2309,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(33.83333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2310,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2311,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2312,\"textContent\":\"08:30\"}]}]},{\"nodeType\":1,\"id\":2313,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(67.16666666666666,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2314,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2315,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2316,\"textContent\":\"09 AM\"}]}]},{\"nodeType\":1,\"id\":2317,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(100.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2318,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2319,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2320,\"textContent\":\"09:30\"}]}]},{\"nodeType\":1,\"id\":2321,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(133.83333333333331,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2322,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2323,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2324,\"textContent\":\"10 AM\"}]}]},{\"nodeType\":1,\"id\":2325,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(167.16666666666669,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2326,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2327,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2328,\"textContent\":\"10:30\"}]}]},{\"nodeType\":1,\"id\":2329,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(200.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2330,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2331,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2332,\"textContent\":\"11 AM\"}]}]},{\"nodeType\":1,\"id\":2333,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(233.83333333333334,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2334,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2335,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2336,\"textContent\":\"11:30\"}]}]},{\"nodeType\":1,\"id\":2337,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(267.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2338,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2339,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2340,\"textContent\":\"12 PM\"}]}]},{\"nodeType\":1,\"id\":2341,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(300.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2342,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2343,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2344,\"textContent\":\"12:30\"}]}]},{\"nodeType\":1,\"id\":2345,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(333.83333333333337,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2346,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2347,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2348,\"textContent\":\"01 PM\"}]}]},{\"nodeType\":1,\"id\":2349,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(367.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2350,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2351,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2352,\"textContent\":\"01:30\"}]}]},{\"nodeType\":1,\"id\":2353,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(400.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2354,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2355,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2356,\"textContent\":\"02 PM\"}]}]},{\"nodeType\":1,\"id\":2357,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(433.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2358,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2359,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2360,\"textContent\":\"02:30\"}]}]},{\"nodeType\":1,\"id\":2361,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(467.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2362,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2363,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2364,\"textContent\":\"03 PM\"}]}]},{\"nodeType\":1,\"id\":2365,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(500.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2366,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2367,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2368,\"textContent\":\"03:30\"}]}]},{\"nodeType\":1,\"id\":2369,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(533.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2370,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2371,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2372,\"textContent\":\"04 PM\"}]}]},{\"nodeType\":1,\"id\":2373,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(567.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2374,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2375,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2376,\"textContent\":\"04:30\"}]}]},{\"nodeType\":1,\"id\":2377,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(600.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2378,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2379,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2380,\"textContent\":\"05 PM\"}]}]},{\"nodeType\":1,\"id\":2381,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(633.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2382,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2383,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2384,\"textContent\":\"05:30\"}]}]},{\"nodeType\":1,\"id\":2385,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(667.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2386,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2387,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2388,\"textContent\":\"06 PM\"}]}]},{\"nodeType\":1,\"id\":2389,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(700.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2390,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2391,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2392,\"textContent\":\"06:30\"}]}]},{\"nodeType\":1,\"id\":2393,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(733.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2394,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2395,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2396,\"textContent\":\"07 PM\"}]}]},{\"nodeType\":1,\"id\":2397,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(767.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2398,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2399,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2400,\"textContent\":\"07:30\"}]}]},{\"nodeType\":1,\"id\":2401,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(800.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2402,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2403,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2404,\"textContent\":\"08 PM\"}]}]},{\"nodeType\":1,\"id\":2405,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2406,\"tagName\":\"text\",\"attributes\":{\"x\":\"533.3333333333334\",\"y\":\"80\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2407,\"textContent\":\"START & END TIME (time of day)\"}]}]}]},{\"nodeType\":1,\"id\":2408,\"tagName\":\"g\",\"attributes\":{\"class\":\"yaxis\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"end\"},\"childNodes\":[{\"nodeType\":1,\"id\":2409,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M-15,800.5H0.5V0.5H-15\"}},{\"nodeType\":1,\"id\":2410,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,800.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2411,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2412,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2413,\"textContent\":\"0\"}]}]},{\"nodeType\":1,\"id\":2414,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,733.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2415,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2416,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2417,\"textContent\":\"1\"}]}]},{\"nodeType\":1,\"id\":2418,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,667.1666666666667)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2419,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2420,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2421,\"textContent\":\"2\"}]}]},{\"nodeType\":1,\"id\":2422,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,600.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2423,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2424,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2425,\"textContent\":\"3\"}]}]},{\"nodeType\":1,\"id\":2426,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,533.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2427,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2428,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2429,\"textContent\":\"4\"}]}]},{\"nodeType\":1,\"id\":2430,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,467.16666666666663)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2431,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2432,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2433,\"textContent\":\"5\"}]}]},{\"nodeType\":1,\"id\":2434,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,400.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2435,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2436,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2437,\"textContent\":\"6\"}]}]},{\"nodeType\":1,\"id\":2438,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,333.8333333333333)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2439,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2440,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2441,\"textContent\":\"7\"}]}]},{\"nodeType\":1,\"id\":2442,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,267.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2443,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2444,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2445,\"textContent\":\"8\"}]}]},{\"nodeType\":1,\"id\":2446,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,200.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2447,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2448,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2449,\"textContent\":\"9\"}]}]},{\"nodeType\":1,\"id\":2450,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,133.83333333333326)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2451,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2452,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2453,\"textContent\":\"10\"}]}]},{\"nodeType\":1,\"id\":2454,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,67.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2455,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2456,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2457,\"textContent\":\"11\"}]}]},{\"nodeType\":1,\"id\":2458,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,0.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2459,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2460,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2461,\"textContent\":\"12\"}]}]},{\"nodeType\":1,\"id\":2462,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2463,\"tagName\":\"text\",\"attributes\":{\"transform\":\"rotate(-90)\",\"x\":\"-350\",\"y\":\"-60\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2464,\"textContent\":\"DURATION (in hours)\"}]}]}]},{\"nodeType\":1,\"id\":2465,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2466,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2467,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"733.3333333333334\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2468,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2469,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"666.6666666666667\",\"y2\":\"666.6666666666667\"}}]},{\"nodeType\":1,\"id\":2470,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2471,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"600\",\"y2\":\"600\"}}]},{\"nodeType\":1,\"id\":2472,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2473,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"533.3333333333334\",\"y2\":\"533.3333333333334\"}}]},{\"nodeType\":1,\"id\":2474,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2475,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"466.66666666666663\",\"y2\":\"466.66666666666663\"}}]},{\"nodeType\":1,\"id\":2476,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2477,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"400\",\"y2\":\"400\"}}]},{\"nodeType\":1,\"id\":2478,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2479,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"333.3333333333333\",\"y2\":\"333.3333333333333\"}}]},{\"nodeType\":1,\"id\":2480,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2481,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"266.66666666666674\",\"y2\":\"266.66666666666674\"}}]},{\"nodeType\":1,\"id\":2482,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2483,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"200\",\"y2\":\"200\"}}]},{\"nodeType\":1,\"id\":2484,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2485,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"133.33333333333326\",\"y2\":\"133.33333333333326\"}}]},{\"nodeType\":1,\"id\":2486,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2487,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"66.66666666666674\",\"y2\":\"66.66666666666674\"}}]},{\"nodeType\":1,\"id\":2488,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2489,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"0\",\"y2\":\"0\"}}]}]},{\"nodeType\":1,\"id\":2490,\"tagName\":\"g\",\"attributes\":{\"class\":\"xgrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2491,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"0\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2492,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"800\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2493,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"433.3333333333333\",\"y2\":\"66.66666666666674\"}},{\"nodeType\":1,\"id\":2494,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"366.66666666666663\",\"y2\":\"66.66666666666674\"}},{\"nodeType\":1,\"id\":2495,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"466.6666666666667\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2496,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"333.33333333333337\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2497,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"500\",\"y2\":\"200\"}},{\"nodeType\":1,\"id\":2498,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"300\",\"y2\":\"200\"}},{\"nodeType\":1,\"id\":2499,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"533.3333333333333\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2500,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"266.66666666666663\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2501,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"566.6666666666667\",\"y2\":\"333.3333333333333\"}},{\"nodeType\":1,\"id\":2502,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"233.33333333333334\",\"y2\":\"333.3333333333333\"}},{\"nodeType\":1,\"id\":2503,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"600\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2504,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"200\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2505,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"633.3333333333333\",\"y2\":\"466.66666666666663\"}},{\"nodeType\":1,\"id\":2506,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"166.66666666666669\",\"y2\":\"466.66666666666663\"}},{\"nodeType\":1,\"id\":2507,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"666.6666666666667\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2508,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"133.33333333333331\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2509,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"700\",\"y2\":\"600\"}},{\"nodeType\":1,\"id\":2510,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"100\",\"y2\":\"600\"}},{\"nodeType\":1,\"id\":2511,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"733.3333333333333\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2512,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"66.66666666666666\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2513,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"766.6666666666667\",\"y2\":\"733.3333333333334\"}},{\"nodeType\":1,\"id\":2514,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"33.33333333333333\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2515,\"tagName\":\"g\",\"attributes\":{\"class\":\"data\"},\"childNodes\":[{\"nodeType\":1,\"id\":2516,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2517,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"266.66666666666674\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2518,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"258.66666666666674\"},\"childNodes\":[{\"nodeType\":3,\"id\":2519,\"textContent\":\"A \"}]}]},{\"nodeType\":1,\"id\":2520,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2521,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2522,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2523,\"textContent\":\"B \"}]}]},{\"nodeType\":1,\"id\":2524,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2525,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"366.66666666666663\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2526,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"361.66666666666663\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2527,\"textContent\":\"C \"}]}]},{\"nodeType\":1,\"id\":2528,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2529,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"666.6666666666667\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2530,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"661.6666666666667\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2531,\"textContent\":\"D \"}]}]},{\"nodeType\":1,\"id\":2532,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2533,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"200\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2534,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"195\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2535,\"textContent\":\"E \"}]}]},{\"nodeType\":1,\"id\":2536,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2537,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2538,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2539,\"textContent\":\"F \"}]}]},{\"nodeType\":1,\"id\":2540,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2541,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2542,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2543,\"textContent\":\"G \"}]}]},{\"nodeType\":1,\"id\":2544,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2545,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2546,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2547,\"textContent\":\"H \"}]}]},{\"nodeType\":1,\"id\":2548,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2549,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"100\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2550,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"95\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2551,\"textContent\":\"I \"}]}]},{\"nodeType\":1,\"id\":2552,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2553,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"133.33333333333331\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2554,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"128.33333333333331\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2555,\"textContent\":\"J \"}]}]},{\"nodeType\":1,\"id\":2556,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2557,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"133.33333333333326\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2558,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"125.33333333333326\"},\"childNodes\":[{\"nodeType\":3,\"id\":2559,\"textContent\":\"K \"}]}]},{\"nodeType\":1,\"id\":2560,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2561,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"333.3333333333333\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2562,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"325.3333333333333\"},\"childNodes\":[{\"nodeType\":3,\"id\":2563,\"textContent\":\"L \"}]}]},{\"nodeType\":1,\"id\":2564,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2565,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"300\",\"cy\":\"733.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2566,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"295\",\"y\":\"725.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2567,\"textContent\":\"M \"}]}]},{\"nodeType\":1,\"id\":2568,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2569,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"600\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2570,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"595\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2571,\"textContent\":\"N \"}]}]},{\"nodeType\":1,\"id\":2572,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2573,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"433.3333333333333\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2574,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"428.3333333333333\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2575,\"textContent\":\"O \"}]}]},{\"nodeType\":1,\"id\":2576,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2577,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"200\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2578,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"192\"},\"childNodes\":[{\"nodeType\":3,\"id\":2579,\"textContent\":\"P \"}]}]},{\"nodeType\":1,\"id\":2580,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2581,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"533.3333333333333\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2582,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"528.3333333333333\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2583,\"textContent\":\"Z \"}]}]},{\"nodeType\":1,\"id\":2584,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2585,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2586,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2587,\"textContent\":\"X \"}]}]}]}]}]}]},{\"nodeType\":3,\"id\":2588,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2589,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2590},{\"nodeType\":3,\"id\":2591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2592,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2593,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2594,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2595,\"textContent\":\" \"}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 261, dom: 1025, initialDom: 1113",
  "javascriptErrors": []
}