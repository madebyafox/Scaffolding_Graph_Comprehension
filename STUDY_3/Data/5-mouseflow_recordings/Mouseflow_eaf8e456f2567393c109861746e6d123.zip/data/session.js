var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "eaf8e456f2567393c109861746e6d123",
  "created": "2018-05-25T11:09:18.7263166-07:00",
  "lastActivity": "2018-05-25T11:09:44.3729022-07:00",
  "pageViews": [
    {
      "id": "05251833957e44123f8a3c5b9176457affffb9f9",
      "startTime": "2018-05-25T11:09:18.7899022-07:00",
      "endTime": "2018-05-25T11:09:44.3729022-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/1",
      "visitTime": 25583,
      "engagementTime": 25583,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 25583,
  "engagementTime": 25583,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.36",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=PLKGC",
    "CONDITION=114",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "10fb01ef4d8d9e5a38eea39fef658a31",
  "gdpr": false
}