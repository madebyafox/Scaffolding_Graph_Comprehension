var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["06012785edc1c725ae93048cba19f355df552aaf"] = {
  "startTime": "2018-06-01T18:06:27.3046008Z",
  "websitePageUrl": "/",
  "visitTime": 187462,
  "engagementTime": 61614,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 929,
  "viewportHeight": 1047,
  "tags": [
    "form-interact"
  ],
  "session": {
    "id": "746ee15cd9ae2b99cf2af3feee187239",
    "created": "2018-06-01T18:06:27.3046008+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.181",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/",
    "tags": [
      "form-interact"
    ],
    "variables": [],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "d3134af6e161d9c67a23530346aaa145",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/746ee15cd9ae2b99cf2af3feee187239/play"
  },
  "events": [
    {
      "t": 101,
      "e": 101,
      "ty": 0,
      "x": 929,
      "y": 1047
    },
    {
      "t": 340,
      "e": 340,
      "ty": 14,
      "x": 0,
      "y": 1046
    },
    {
      "t": 8100,
      "e": 5101,
      "ty": 2,
      "x": 300,
      "y": 96
    },
    {
      "t": 8201,
      "e": 5202,
      "ty": 2,
      "x": 294,
      "y": 106
    },
    {
      "t": 8253,
      "e": 5254,
      "ty": 41,
      "x": 20551,
      "y": 6235,
      "ta": "html > body"
    },
    {
      "t": 8700,
      "e": 5701,
      "ty": 2,
      "x": 348,
      "y": 100
    },
    {
      "t": 8750,
      "e": 5751,
      "ty": 41,
      "x": 31977,
      "y": 5662,
      "ta": "html > body"
    },
    {
      "t": 8800,
      "e": 5801,
      "ty": 2,
      "x": 612,
      "y": 107
    },
    {
      "t": 8901,
      "e": 5902,
      "ty": 2,
      "x": 769,
      "y": 92
    },
    {
      "t": 9000,
      "e": 6001,
      "ty": 2,
      "x": 857,
      "y": 31
    },
    {
      "t": 9000,
      "e": 6001,
      "ty": 41,
      "x": 61007,
      "y": 1463,
      "ta": "html > body"
    },
    {
      "t": 9025,
      "e": 6026,
      "ty": 40,
      "x": 0,
      "y": 0
    },
    {
      "t": 9100,
      "e": 6101,
      "ty": 2,
      "x": 852,
      "y": 4
    },
    {
      "t": 9251,
      "e": 6252,
      "ty": 41,
      "x": 61223,
      "y": 254,
      "ta": "html"
    },
    {
      "t": 9900,
      "e": 6901,
      "ty": 0,
      "x": 1920,
      "y": 1094
    },
    {
      "t": 10000,
      "e": 7001,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 10100,
      "e": 7750,
      "ty": 2,
      "x": 814,
      "y": 251
    },
    {
      "t": 10201,
      "e": 7851,
      "ty": 2,
      "x": 783,
      "y": 281
    },
    {
      "t": 10251,
      "e": 7901,
      "ty": 41,
      "x": 22964,
      "y": 11018,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 10300,
      "e": 7950,
      "ty": 2,
      "x": 777,
      "y": 278
    },
    {
      "t": 10400,
      "e": 8050,
      "ty": 2,
      "x": 974,
      "y": 347
    },
    {
      "t": 10500,
      "e": 8150,
      "ty": 2,
      "x": 1348,
      "y": 423
    },
    {
      "t": 10500,
      "e": 8150,
      "ty": 41,
      "x": 53984,
      "y": 22650,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 18901,
      "e": 13150,
      "ty": 2,
      "x": 1358,
      "y": 501
    },
    {
      "t": 19000,
      "e": 13249,
      "ty": 2,
      "x": 1354,
      "y": 597
    },
    {
      "t": 19000,
      "e": 13249,
      "ty": 41,
      "x": 54312,
      "y": 36904,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 19901,
      "e": 14150,
      "ty": 2,
      "x": 1382,
      "y": 598
    },
    {
      "t": 20001,
      "e": 14250,
      "ty": 2,
      "x": 1408,
      "y": 593
    },
    {
      "t": 20001,
      "e": 14250,
      "ty": 41,
      "x": 57261,
      "y": 36576,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 20001,
      "e": 14250,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 20100,
      "e": 14349,
      "ty": 2,
      "x": 1481,
      "y": 587
    },
    {
      "t": 20201,
      "e": 14450,
      "ty": 2,
      "x": 1547,
      "y": 593
    },
    {
      "t": 20251,
      "e": 14500,
      "ty": 41,
      "x": 64852,
      "y": 36576,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 20301,
      "e": 14550,
      "ty": 2,
      "x": 1548,
      "y": 593
    },
    {
      "t": 20501,
      "e": 14750,
      "ty": 41,
      "x": 64906,
      "y": 36576,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 22201,
      "e": 16450,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 22201,
      "e": 16450,
      "ty": 2,
      "x": 1548,
      "y": 659
    },
    {
      "t": 22251,
      "e": 16500,
      "ty": 41,
      "x": 64906,
      "y": 37641,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 30002,
      "e": 21500,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 128108,
      "e": 21500,
      "ty": 2,
      "x": 1910,
      "y": 173
    },
    {
      "t": 128259,
      "e": 21651,
      "ty": 41,
      "x": 64191,
      "y": 9140,
      "ta": "> div.masterdiv"
    },
    {
      "t": 128309,
      "e": 21701,
      "ty": 2,
      "x": 1562,
      "y": 287
    },
    {
      "t": 128409,
      "e": 21801,
      "ty": 2,
      "x": 1320,
      "y": 614
    },
    {
      "t": 128510,
      "e": 21902,
      "ty": 41,
      "x": 50503,
      "y": 54876,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 128709,
      "e": 22101,
      "ty": 2,
      "x": 1292,
      "y": 616
    },
    {
      "t": 128759,
      "e": 22151,
      "ty": 41,
      "x": 34661,
      "y": 59817,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 128809,
      "e": 22201,
      "ty": 2,
      "x": 775,
      "y": 699
    },
    {
      "t": 128909,
      "e": 22301,
      "ty": 2,
      "x": 759,
      "y": 681
    },
    {
      "t": 129009,
      "e": 22401,
      "ty": 2,
      "x": 997,
      "y": 809
    },
    {
      "t": 129010,
      "e": 22402,
      "ty": 41,
      "x": 34612,
      "y": 63669,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 129109,
      "e": 22501,
      "ty": 2,
      "x": 871,
      "y": 849
    },
    {
      "t": 129209,
      "e": 22601,
      "ty": 2,
      "x": 809,
      "y": 879
    },
    {
      "t": 129260,
      "e": 22652,
      "ty": 41,
      "x": 25117,
      "y": 61395,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 129309,
      "e": 22701,
      "ty": 2,
      "x": 797,
      "y": 906
    },
    {
      "t": 129409,
      "e": 22801,
      "ty": 2,
      "x": 800,
      "y": 920
    },
    {
      "t": 129508,
      "e": 22900,
      "ty": 2,
      "x": 810,
      "y": 935
    },
    {
      "t": 129509,
      "e": 22901,
      "ty": 41,
      "x": 25412,
      "y": 56000,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 129609,
      "e": 23001,
      "ty": 2,
      "x": 811,
      "y": 935
    },
    {
      "t": 129616,
      "e": 23008,
      "ty": 3,
      "x": 811,
      "y": 935,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 129689,
      "e": 23081,
      "ty": 4,
      "x": 25461,
      "y": 56000,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 129689,
      "e": 23081,
      "ty": 5,
      "x": 811,
      "y": 935,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 129760,
      "e": 23152,
      "ty": 41,
      "x": 25461,
      "y": 56000,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 129810,
      "e": 23202,
      "ty": 2,
      "x": 812,
      "y": 927
    },
    {
      "t": 129909,
      "e": 23301,
      "ty": 2,
      "x": 815,
      "y": 914
    },
    {
      "t": 129913,
      "e": 23305,
      "ty": 3,
      "x": 815,
      "y": 914,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 129991,
      "e": 23383,
      "ty": 4,
      "x": 37887,
      "y": 9881,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 129991,
      "e": 23383,
      "ty": 5,
      "x": 815,
      "y": 914,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 129992,
      "e": 23384,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox"
    },
    {
      "t": 129996,
      "e": 23388,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox",
      "v": "on"
    },
    {
      "t": 130009,
      "e": 23401,
      "ty": 41,
      "x": 37887,
      "y": 9881,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 130109,
      "e": 23501,
      "ty": 2,
      "x": 897,
      "y": 1008
    },
    {
      "t": 130209,
      "e": 23601,
      "ty": 2,
      "x": 993,
      "y": 1121
    },
    {
      "t": 130259,
      "e": 23651,
      "ty": 41,
      "x": 41427,
      "y": 19008,
      "ta": "> div.masterdiv > div:[3]"
    },
    {
      "t": 130309,
      "e": 23701,
      "ty": 2,
      "x": 954,
      "y": 1086
    },
    {
      "t": 130409,
      "e": 23801,
      "ty": 2,
      "x": 953,
      "y": 1084
    },
    {
      "t": 130457,
      "e": 23849,
      "ty": 3,
      "x": 953,
      "y": 1084,
      "ta": "#start"
    },
    {
      "t": 130458,
      "e": 23850,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox"
    },
    {
      "t": 130459,
      "e": 23851,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 130509,
      "e": 23901,
      "ty": 41,
      "x": 23756,
      "y": 21804,
      "ta": "#start"
    },
    {
      "t": 130511,
      "e": 23903,
      "ty": 4,
      "x": 23756,
      "y": 21804,
      "ta": "#start"
    },
    {
      "t": 130515,
      "e": 23907,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 130518,
      "e": 23910,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 130518,
      "e": 23910,
      "ty": 5,
      "x": 953,
      "y": 1084,
      "ta": "#start"
    },
    {
      "t": 130609,
      "e": 24001,
      "ty": 2,
      "x": 953,
      "y": 1083
    },
    {
      "t": 130760,
      "e": 24152,
      "ty": 41,
      "x": 32543,
      "y": 59552,
      "ta": "html > body"
    },
    {
      "t": 131009,
      "e": 24401,
      "ty": 2,
      "x": 953,
      "y": 1082
    },
    {
      "t": 131010,
      "e": 24402,
      "ty": 41,
      "x": 32543,
      "y": 59496,
      "ta": "html > body"
    },
    {
      "t": 131109,
      "e": 24501,
      "ty": 2,
      "x": 953,
      "y": 1029
    },
    {
      "t": 131209,
      "e": 24601,
      "ty": 2,
      "x": 924,
      "y": 954
    },
    {
      "t": 131259,
      "e": 24651,
      "ty": 41,
      "x": 31441,
      "y": 52405,
      "ta": "html > body"
    },
    {
      "t": 131309,
      "e": 24701,
      "ty": 2,
      "x": 921,
      "y": 954
    },
    {
      "t": 131523,
      "e": 24915,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 131709,
      "e": 25101,
      "ty": 2,
      "x": 920,
      "y": 932
    },
    {
      "t": 131761,
      "e": 25153,
      "ty": 41,
      "x": 31407,
      "y": 51187,
      "ta": "html > body"
    },
    {
      "t": 132009,
      "e": 25401,
      "ty": 2,
      "x": 921,
      "y": 927
    },
    {
      "t": 132009,
      "e": 25401,
      "ty": 41,
      "x": 31441,
      "y": 50910,
      "ta": "html > body"
    },
    {
      "t": 132109,
      "e": 25501,
      "ty": 2,
      "x": 930,
      "y": 784
    },
    {
      "t": 132109,
      "e": 25501,
      "ty": 6,
      "x": 930,
      "y": 731,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 132125,
      "e": 25517,
      "ty": 7,
      "x": 930,
      "y": 684,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 132126,
      "e": 25518,
      "ty": 6,
      "x": 930,
      "y": 684,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 132142,
      "e": 25534,
      "ty": 7,
      "x": 930,
      "y": 646,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 132209,
      "e": 25601,
      "ty": 2,
      "x": 929,
      "y": 608
    },
    {
      "t": 132215,
      "e": 25607,
      "ty": 6,
      "x": 929,
      "y": 606,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 132259,
      "e": 25651,
      "ty": 41,
      "x": 26170,
      "y": 62414,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 132309,
      "e": 25701,
      "ty": 2,
      "x": 928,
      "y": 605
    },
    {
      "t": 132409,
      "e": 25801,
      "ty": 2,
      "x": 921,
      "y": 605
    },
    {
      "t": 132504,
      "e": 25896,
      "ty": 3,
      "x": 921,
      "y": 605,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 132505,
      "e": 25897,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 132509,
      "e": 25901,
      "ty": 41,
      "x": 24440,
      "y": 59293,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 132599,
      "e": 25991,
      "ty": 4,
      "x": 24440,
      "y": 59293,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 132599,
      "e": 25991,
      "ty": 5,
      "x": 921,
      "y": 605,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 135237,
      "e": 28629,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "16"
    },
    {
      "t": 135355,
      "e": 28747,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "88"
    },
    {
      "t": 135357,
      "e": 28749,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 135451,
      "e": 28843,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "X"
    },
    {
      "t": 135684,
      "e": 29076,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "89"
    },
    {
      "t": 135685,
      "e": 29077,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 135771,
      "e": 29163,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "XY"
    },
    {
      "t": 135787,
      "e": 29179,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "82"
    },
    {
      "t": 135788,
      "e": 29180,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 135891,
      "e": 29283,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "XYR"
    },
    {
      "t": 135932,
      "e": 29324,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "65"
    },
    {
      "t": 135932,
      "e": 29324,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 136084,
      "e": 29476,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "XYRA"
    },
    {
      "t": 136332,
      "e": 29724,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "8"
    },
    {
      "t": 136395,
      "e": 29787,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "XYR"
    },
    {
      "t": 136476,
      "e": 29868,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "8"
    },
    {
      "t": 136547,
      "e": 29939,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "XY"
    },
    {
      "t": 136635,
      "e": 30027,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "65"
    },
    {
      "t": 136636,
      "e": 30028,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 136772,
      "e": 30164,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "XYA"
    },
    {
      "t": 136780,
      "e": 30172,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "89"
    },
    {
      "t": 136780,
      "e": 30172,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 136891,
      "e": 30283,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "XYAY"
    },
    {
      "t": 137043,
      "e": 30435,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "+||"
    },
    {
      "t": 137547,
      "e": 30939,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "8"
    },
    {
      "t": 137605,
      "e": 30941,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "XYA"
    },
    {
      "t": 137683,
      "e": 31019,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "8"
    },
    {
      "t": 137731,
      "e": 31067,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "XY"
    },
    {
      "t": 137803,
      "e": 31139,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "8"
    },
    {
      "t": 137851,
      "e": 31187,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "X"
    },
    {
      "t": 138300,
      "e": 31636,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "16"
    },
    {
      "t": 138508,
      "e": 31844,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "82"
    },
    {
      "t": 138508,
      "e": 31844,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 138614,
      "e": 31950,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "XR"
    },
    {
      "t": 138643,
      "e": 31979,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "XR"
    },
    {
      "t": 138700,
      "e": 32036,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "65"
    },
    {
      "t": 138700,
      "e": 32036,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 138814,
      "e": 32150,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "XRA"
    },
    {
      "t": 138827,
      "e": 32163,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "XRA"
    },
    {
      "t": 138876,
      "e": 32212,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "89"
    },
    {
      "t": 138876,
      "e": 32212,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 138972,
      "e": 32308,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "XRAY"
    },
    {
      "t": 139036,
      "e": 32372,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "+||"
    },
    {
      "t": 139300,
      "e": 32636,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "9"
    },
    {
      "t": 139301,
      "e": 32637,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "XRAY"
    },
    {
      "t": 139302,
      "e": 32638,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 139302,
      "e": 32638,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 139483,
      "e": 32819,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": ""
    },
    {
      "t": 140075,
      "e": 33411,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "51"
    },
    {
      "t": 140075,
      "e": 33411,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 140163,
      "e": 33499,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "3"
    },
    {
      "t": 140291,
      "e": 33627,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "49"
    },
    {
      "t": 140292,
      "e": 33628,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 140355,
      "e": 33691,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "31"
    },
    {
      "t": 140427,
      "e": 33763,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "49"
    },
    {
      "t": 140428,
      "e": 33764,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 140524,
      "e": 33860,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "31*"
    },
    {
      "t": 141344,
      "e": 34680,
      "ty": 7,
      "x": 924,
      "y": 607,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 141409,
      "e": 34745,
      "ty": 2,
      "x": 936,
      "y": 611
    },
    {
      "t": 141509,
      "e": 34845,
      "ty": 41,
      "x": 27684,
      "y": 62716,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 141909,
      "e": 35245,
      "ty": 2,
      "x": 938,
      "y": 619
    },
    {
      "t": 141967,
      "e": 35303,
      "ty": 6,
      "x": 996,
      "y": 689,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 141983,
      "e": 35319,
      "ty": 7,
      "x": 1017,
      "y": 712,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 141983,
      "e": 35319,
      "ty": 6,
      "x": 1017,
      "y": 712,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 142000,
      "e": 35336,
      "ty": 7,
      "x": 1026,
      "y": 719,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 142009,
      "e": 35345,
      "ty": 2,
      "x": 1026,
      "y": 719
    },
    {
      "t": 142009,
      "e": 35345,
      "ty": 41,
      "x": 35057,
      "y": 39387,
      "ta": "html > body"
    },
    {
      "t": 142110,
      "e": 35446,
      "ty": 2,
      "x": 1075,
      "y": 758
    },
    {
      "t": 142209,
      "e": 35545,
      "ty": 2,
      "x": 1000,
      "y": 756
    },
    {
      "t": 142259,
      "e": 35595,
      "ty": 41,
      "x": 33611,
      "y": 41326,
      "ta": "html > body"
    },
    {
      "t": 142310,
      "e": 35646,
      "ty": 2,
      "x": 984,
      "y": 754
    },
    {
      "t": 142384,
      "e": 35720,
      "ty": 6,
      "x": 983,
      "y": 740,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 142409,
      "e": 35745,
      "ty": 2,
      "x": 979,
      "y": 733
    },
    {
      "t": 142510,
      "e": 35846,
      "ty": 2,
      "x": 972,
      "y": 709
    },
    {
      "t": 142510,
      "e": 35846,
      "ty": 41,
      "x": 39209,
      "y": 1985,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 142625,
      "e": 35961,
      "ty": 3,
      "x": 972,
      "y": 709,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 142625,
      "e": 35961,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "31*"
    },
    {
      "t": 142626,
      "e": 35962,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 142627,
      "e": 35963,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 142703,
      "e": 36039,
      "ty": 4,
      "x": 39209,
      "y": 1985,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 142704,
      "e": 36040,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 142704,
      "e": 36040,
      "ty": 5,
      "x": 972,
      "y": 709,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 142705,
      "e": 36041,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 143009,
      "e": 36345,
      "ty": 2,
      "x": 972,
      "y": 708
    },
    {
      "t": 143010,
      "e": 36346,
      "ty": 41,
      "x": 33197,
      "y": 38778,
      "ta": "html > body"
    },
    {
      "t": 143801,
      "e": 37137,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 143832,
      "e": 37168,
      "ty": 6,
      "x": 972,
      "y": 708,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 144792,
      "e": 38128,
      "ty": 7,
      "x": 960,
      "y": 698,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 144793,
      "e": 38129,
      "ty": 6,
      "x": 960,
      "y": 698,
      "ta": "> div.masterdiv > div:[2] > div > ul > li"
    },
    {
      "t": 144809,
      "e": 38145,
      "ty": 2,
      "x": 951,
      "y": 692
    },
    {
      "t": 144853,
      "e": 38189,
      "ty": 7,
      "x": 899,
      "y": 667,
      "ta": "> div.masterdiv > div:[2] > div > ul > li"
    },
    {
      "t": 144910,
      "e": 38246,
      "ty": 2,
      "x": 853,
      "y": 649
    },
    {
      "t": 145010,
      "e": 38346,
      "ty": 2,
      "x": 717,
      "y": 609
    },
    {
      "t": 145010,
      "e": 38346,
      "ty": 41,
      "x": 20837,
      "y": 31453,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 145109,
      "e": 38445,
      "ty": 2,
      "x": 699,
      "y": 605
    },
    {
      "t": 145260,
      "e": 38596,
      "ty": 41,
      "x": 39860,
      "y": 60890,
      "ta": "> div.masterdiv > div:[2] > div > table > tbody > tr:[5] > td"
    },
    {
      "t": 145510,
      "e": 38846,
      "ty": 2,
      "x": 718,
      "y": 638
    },
    {
      "t": 145510,
      "e": 38846,
      "ty": 41,
      "x": 20886,
      "y": 30463,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 145609,
      "e": 38945,
      "ty": 2,
      "x": 739,
      "y": 665
    },
    {
      "t": 145760,
      "e": 39096,
      "ty": 41,
      "x": 21919,
      "y": 40129,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 146710,
      "e": 40046,
      "ty": 2,
      "x": 743,
      "y": 665
    },
    {
      "t": 146755,
      "e": 40091,
      "ty": 6,
      "x": 809,
      "y": 680,
      "ta": "> div.masterdiv > div:[2] > div > ul > li"
    },
    {
      "t": 146760,
      "e": 40096,
      "ty": 41,
      "x": 24165,
      "y": 21101,
      "ta": "> div.masterdiv > div:[2] > div > ul > li"
    },
    {
      "t": 146789,
      "e": 40125,
      "ty": 7,
      "x": 875,
      "y": 703,
      "ta": "> div.masterdiv > div:[2] > div > ul > li"
    },
    {
      "t": 146789,
      "e": 40125,
      "ty": 6,
      "x": 875,
      "y": 703,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 146810,
      "e": 40146,
      "ty": 2,
      "x": 913,
      "y": 725
    },
    {
      "t": 146821,
      "e": 40157,
      "ty": 7,
      "x": 940,
      "y": 741,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 146823,
      "e": 40159,
      "ty": 6,
      "x": 940,
      "y": 741,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 146855,
      "e": 40191,
      "ty": 7,
      "x": 967,
      "y": 761,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 146855,
      "e": 40191,
      "ty": 6,
      "x": 967,
      "y": 761,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[4]"
    },
    {
      "t": 146872,
      "e": 40208,
      "ty": 7,
      "x": 978,
      "y": 784,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[4]"
    },
    {
      "t": 146910,
      "e": 40246,
      "ty": 2,
      "x": 987,
      "y": 816
    },
    {
      "t": 147009,
      "e": 40345,
      "ty": 2,
      "x": 988,
      "y": 916
    },
    {
      "t": 147009,
      "e": 40345,
      "ty": 41,
      "x": 34169,
      "y": 54684,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 147110,
      "e": 40446,
      "ty": 2,
      "x": 988,
      "y": 931
    },
    {
      "t": 147260,
      "e": 40596,
      "ty": 41,
      "x": 34169,
      "y": 55723,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 147410,
      "e": 40746,
      "ty": 2,
      "x": 987,
      "y": 931
    },
    {
      "t": 147510,
      "e": 40846,
      "ty": 2,
      "x": 1001,
      "y": 935
    },
    {
      "t": 147511,
      "e": 40847,
      "ty": 41,
      "x": 34809,
      "y": 56000,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 147609,
      "e": 40945,
      "ty": 2,
      "x": 1001,
      "y": 994
    },
    {
      "t": 147706,
      "e": 41042,
      "ty": 6,
      "x": 972,
      "y": 1076,
      "ta": "#start"
    },
    {
      "t": 147709,
      "e": 41045,
      "ty": 2,
      "x": 972,
      "y": 1076
    },
    {
      "t": 147754,
      "e": 41090,
      "ty": 7,
      "x": 969,
      "y": 1110,
      "ta": "#start"
    },
    {
      "t": 147760,
      "e": 41096,
      "ty": 41,
      "x": 37214,
      "y": 20670,
      "ta": "> div.masterdiv > div:[3]"
    },
    {
      "t": 147809,
      "e": 41145,
      "ty": 2,
      "x": 982,
      "y": 1133
    },
    {
      "t": 147909,
      "e": 41245,
      "ty": 2,
      "x": 1001,
      "y": 1134
    },
    {
      "t": 148009,
      "e": 41345,
      "ty": 2,
      "x": 983,
      "y": 1108
    },
    {
      "t": 148010,
      "e": 41346,
      "ty": 41,
      "x": 43768,
      "y": 19562,
      "ta": "> div.masterdiv > div:[3]"
    },
    {
      "t": 148022,
      "e": 41358,
      "ty": 6,
      "x": 981,
      "y": 1105,
      "ta": "#start"
    },
    {
      "t": 148110,
      "e": 41446,
      "ty": 2,
      "x": 978,
      "y": 1099
    },
    {
      "t": 148209,
      "e": 41545,
      "ty": 2,
      "x": 974,
      "y": 1089
    },
    {
      "t": 148260,
      "e": 41596,
      "ty": 41,
      "x": 35225,
      "y": 31442,
      "ta": "#start"
    },
    {
      "t": 148281,
      "e": 41617,
      "ty": 3,
      "x": 974,
      "y": 1089,
      "ta": "#start"
    },
    {
      "t": 148282,
      "e": 41618,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 148374,
      "e": 41710,
      "ty": 4,
      "x": 35225,
      "y": 31442,
      "ta": "#start"
    },
    {
      "t": 148375,
      "e": 41711,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 148376,
      "e": 41712,
      "ty": 5,
      "x": 974,
      "y": 1089,
      "ta": "#start"
    },
    {
      "t": 148378,
      "e": 41714,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 148711,
      "e": 41714,
      "ty": 2,
      "x": 973,
      "y": 1089
    },
    {
      "t": 148760,
      "e": 41763,
      "ty": 41,
      "x": 33232,
      "y": 59884,
      "ta": "html > body"
    },
    {
      "t": 149010,
      "e": 42013,
      "ty": 2,
      "x": 994,
      "y": 1073
    },
    {
      "t": 149010,
      "e": 42013,
      "ty": 41,
      "x": 33955,
      "y": 58998,
      "ta": "html > body"
    },
    {
      "t": 149110,
      "e": 42113,
      "ty": 2,
      "x": 1014,
      "y": 1012
    },
    {
      "t": 149209,
      "e": 42212,
      "ty": 2,
      "x": 1019,
      "y": 991
    },
    {
      "t": 149259,
      "e": 42262,
      "ty": 41,
      "x": 34816,
      "y": 54455,
      "ta": "html > body"
    },
    {
      "t": 149379,
      "e": 42382,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 160009,
      "e": 47262,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 173110,
      "e": 47262,
      "ty": 2,
      "x": 926,
      "y": 116
    },
    {
      "t": 173209,
      "e": 47361,
      "ty": 2,
      "x": 644,
      "y": 0
    },
    {
      "t": 173260,
      "e": 47412,
      "ty": 41,
      "x": 22177,
      "y": 0,
      "ta": "html"
    },
    {
      "t": 174809,
      "e": 48961,
      "ty": 2,
      "x": 677,
      "y": 28
    },
    {
      "t": 174909,
      "e": 49061,
      "ty": 2,
      "x": 906,
      "y": 239
    },
    {
      "t": 175009,
      "e": 49161,
      "ty": 2,
      "x": 1045,
      "y": 369
    },
    {
      "t": 175009,
      "e": 49161,
      "ty": 41,
      "x": 36918,
      "y": 17354,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 177610,
      "e": 51762,
      "ty": 2,
      "x": 989,
      "y": 322
    },
    {
      "t": 177710,
      "e": 51862,
      "ty": 2,
      "x": 996,
      "y": 328
    },
    {
      "t": 177759,
      "e": 51911,
      "ty": 41,
      "x": 34539,
      "y": 14170,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 179259,
      "e": 53411,
      "ty": 41,
      "x": 34345,
      "y": 15257,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 179310,
      "e": 53462,
      "ty": 2,
      "x": 989,
      "y": 451
    },
    {
      "t": 179410,
      "e": 53562,
      "ty": 2,
      "x": 992,
      "y": 794
    },
    {
      "t": 179509,
      "e": 53661,
      "ty": 41,
      "x": 34345,
      "y": 50354,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 180013,
      "e": 54165,
      "ty": 2,
      "x": 976,
      "y": 787
    },
    {
      "t": 180013,
      "e": 54165,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 180015,
      "e": 54167,
      "ty": 41,
      "x": 33568,
      "y": 49811,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 180114,
      "e": 54266,
      "ty": 2,
      "x": 896,
      "y": 753
    },
    {
      "t": 180214,
      "e": 54366,
      "ty": 2,
      "x": 763,
      "y": 727
    },
    {
      "t": 180263,
      "e": 54415,
      "ty": 41,
      "x": 20995,
      "y": 44919,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 180313,
      "e": 54465,
      "ty": 2,
      "x": 708,
      "y": 751
    },
    {
      "t": 180413,
      "e": 54565,
      "ty": 2,
      "x": 719,
      "y": 829
    },
    {
      "t": 180513,
      "e": 54665,
      "ty": 2,
      "x": 725,
      "y": 811
    },
    {
      "t": 180514,
      "e": 54666,
      "ty": 41,
      "x": 21383,
      "y": 51674,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 180614,
      "e": 54766,
      "ty": 2,
      "x": 683,
      "y": 717
    },
    {
      "t": 180713,
      "e": 54865,
      "ty": 2,
      "x": 669,
      "y": 703
    },
    {
      "t": 180764,
      "e": 54916,
      "ty": 41,
      "x": 18616,
      "y": 43444,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 180814,
      "e": 54966,
      "ty": 2,
      "x": 668,
      "y": 708
    },
    {
      "t": 181014,
      "e": 55166,
      "ty": 41,
      "x": 18616,
      "y": 43677,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 181614,
      "e": 55766,
      "ty": 2,
      "x": 670,
      "y": 697
    },
    {
      "t": 181714,
      "e": 55866,
      "ty": 2,
      "x": 675,
      "y": 676
    },
    {
      "t": 181764,
      "e": 55916,
      "ty": 41,
      "x": 20995,
      "y": 40415,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 181814,
      "e": 55966,
      "ty": 2,
      "x": 798,
      "y": 661
    },
    {
      "t": 181913,
      "e": 56065,
      "ty": 2,
      "x": 919,
      "y": 669
    },
    {
      "t": 182013,
      "e": 56165,
      "ty": 2,
      "x": 948,
      "y": 680
    },
    {
      "t": 182013,
      "e": 56165,
      "ty": 41,
      "x": 32209,
      "y": 41502,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 182114,
      "e": 56266,
      "ty": 2,
      "x": 982,
      "y": 696
    },
    {
      "t": 182213,
      "e": 56365,
      "ty": 2,
      "x": 996,
      "y": 705
    },
    {
      "t": 182264,
      "e": 56416,
      "ty": 41,
      "x": 34879,
      "y": 43677,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 182313,
      "e": 56465,
      "ty": 2,
      "x": 1007,
      "y": 711
    },
    {
      "t": 182414,
      "e": 56566,
      "ty": 2,
      "x": 1026,
      "y": 720
    },
    {
      "t": 182513,
      "e": 56665,
      "ty": 2,
      "x": 1030,
      "y": 721
    },
    {
      "t": 182514,
      "e": 56666,
      "ty": 41,
      "x": 36189,
      "y": 44686,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 182613,
      "e": 56765,
      "ty": 2,
      "x": 1036,
      "y": 723
    },
    {
      "t": 182714,
      "e": 56866,
      "ty": 2,
      "x": 1037,
      "y": 723
    },
    {
      "t": 182764,
      "e": 56916,
      "ty": 41,
      "x": 36529,
      "y": 44841,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 183013,
      "e": 57165,
      "ty": 2,
      "x": 1027,
      "y": 723
    },
    {
      "t": 183014,
      "e": 57166,
      "ty": 41,
      "x": 36044,
      "y": 44841,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 183114,
      "e": 57266,
      "ty": 2,
      "x": 991,
      "y": 714
    },
    {
      "t": 183214,
      "e": 57366,
      "ty": 2,
      "x": 980,
      "y": 710
    },
    {
      "t": 183264,
      "e": 57416,
      "ty": 41,
      "x": 32791,
      "y": 43366,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 183314,
      "e": 57466,
      "ty": 2,
      "x": 943,
      "y": 699
    },
    {
      "t": 183414,
      "e": 57566,
      "ty": 2,
      "x": 923,
      "y": 688
    },
    {
      "t": 183513,
      "e": 57665,
      "ty": 2,
      "x": 898,
      "y": 674
    },
    {
      "t": 183515,
      "e": 57667,
      "ty": 41,
      "x": 29782,
      "y": 41037,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 183614,
      "e": 57766,
      "ty": 2,
      "x": 886,
      "y": 665
    },
    {
      "t": 183714,
      "e": 57866,
      "ty": 2,
      "x": 867,
      "y": 648
    },
    {
      "t": 183763,
      "e": 57915,
      "ty": 41,
      "x": 27840,
      "y": 38396,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 183814,
      "e": 57966,
      "ty": 2,
      "x": 855,
      "y": 633
    },
    {
      "t": 183914,
      "e": 58066,
      "ty": 2,
      "x": 855,
      "y": 631
    },
    {
      "t": 184013,
      "e": 58165,
      "ty": 2,
      "x": 850,
      "y": 626
    },
    {
      "t": 184014,
      "e": 58166,
      "ty": 41,
      "x": 27451,
      "y": 37309,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 184114,
      "e": 58266,
      "ty": 2,
      "x": 805,
      "y": 611
    },
    {
      "t": 184214,
      "e": 58366,
      "ty": 2,
      "x": 790,
      "y": 608
    },
    {
      "t": 184264,
      "e": 58416,
      "ty": 41,
      "x": 24393,
      "y": 35834,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 184314,
      "e": 58466,
      "ty": 2,
      "x": 779,
      "y": 607
    },
    {
      "t": 184413,
      "e": 58565,
      "ty": 2,
      "x": 765,
      "y": 606
    },
    {
      "t": 184514,
      "e": 58666,
      "ty": 2,
      "x": 750,
      "y": 604
    },
    {
      "t": 184514,
      "e": 58666,
      "ty": 41,
      "x": 22597,
      "y": 35601,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 184613,
      "e": 58765,
      "ty": 2,
      "x": 733,
      "y": 604
    },
    {
      "t": 184713,
      "e": 58865,
      "ty": 2,
      "x": 732,
      "y": 604
    },
    {
      "t": 184764,
      "e": 58916,
      "ty": 41,
      "x": 21723,
      "y": 35601,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 185113,
      "e": 59265,
      "ty": 2,
      "x": 746,
      "y": 604
    },
    {
      "t": 185213,
      "e": 59365,
      "ty": 2,
      "x": 785,
      "y": 610
    },
    {
      "t": 185264,
      "e": 59416,
      "ty": 41,
      "x": 24539,
      "y": 36067,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 185313,
      "e": 59465,
      "ty": 2,
      "x": 797,
      "y": 610
    },
    {
      "t": 185413,
      "e": 59565,
      "ty": 2,
      "x": 805,
      "y": 610
    },
    {
      "t": 185513,
      "e": 59665,
      "ty": 2,
      "x": 826,
      "y": 610
    },
    {
      "t": 185513,
      "e": 59665,
      "ty": 41,
      "x": 26286,
      "y": 36067,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 185612,
      "e": 59764,
      "ty": 2,
      "x": 905,
      "y": 612
    },
    {
      "t": 185713,
      "e": 59865,
      "ty": 2,
      "x": 906,
      "y": 612
    },
    {
      "t": 185763,
      "e": 59915,
      "ty": 41,
      "x": 30170,
      "y": 36222,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 186457,
      "e": 60609,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 187462,
      "e": 61614,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":60},{\"id\":63},{\"id\":64},{\"id\":74},{\"id\":75},{\"id\":77},{\"id\":78},{\"id\":80},{\"id\":79},{\"id\":76},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":81},{\"id\":82},{\"id\":84},{\"id\":85},{\"id\":97},{\"id\":86},{\"id\":87},{\"id\":98},{\"id\":88},{\"id\":89},{\"id\":99},{\"id\":90},{\"id\":91},{\"id\":100},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":101},{\"id\":102},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":103},{\"id\":96},{\"id\":83},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":109},{\"id\":110},{\"id\":112},{\"id\":111},{\"id\":72},{\"id\":73},{\"id\":61},{\"id\":62}],[],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":113,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":113},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":115,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":114},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":116,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":115},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":117,\"tagName\":\"P\",\"attributes\":{},\"parentNode\":{\"id\":113}},{\"nodeType\":3,\"id\":118,\"textContent\":\"Please enter the following information from your participant card\",\"parentNode\":{\"id\":117}},{\"nodeType\":1,\"id\":119,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":114}},{\"nodeType\":1,\"id\":120,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":119},\"parentNode\":{\"id\":114}},{\"nodeType\":3,\"id\":121,\"textContent\":\"Session code: \",\"parentNode\":{\"id\":119}},{\"nodeType\":1,\"id\":122,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":115}},{\"nodeType\":1,\"id\":123,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":122},\"parentNode\":{\"id\":115}},{\"nodeType\":3,\"id\":124,\"textContent\":\"Condition code: \",\"parentNode\":{\"id\":122}},{\"nodeType\":3,\"id\":125,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":116}}],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":113},{\"id\":117},{\"id\":118},{\"id\":114},{\"id\":119},{\"id\":121},{\"id\":120},{\"id\":115},{\"id\":122},{\"id\":124},{\"id\":123},{\"id\":116},{\"id\":125}],[],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":126,\"tagName\":\"SCRIPT\",\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":127,\"textContent\":\" \",\"previousSibling\":{\"id\":126},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":128,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"previousSibling\":{\"id\":127},\"parentNode\":{\"id\":55}},{\"nodeType\":8,\"id\":129,\"previousSibling\":{\"id\":128},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":130,\"textContent\":\" \",\"previousSibling\":{\"id\":129},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \\t//set text of scenario descriptions based on scenario randomization order in main switch(scenarios[0]) { case \\\"acme\\\": $('#da1').text(\\\"Answer 15 questions to help a manager coordinate a factory shift schedule.\\\"); break; } \",\"parentNode\":{\"id\":126}},{\"nodeType\":3,\"id\":132,\"textContent\":\" \",\"parentNode\":{\"id\":128}},{\"nodeType\":1,\"id\":133,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":132},\"parentNode\":{\"id\":128}},{\"nodeType\":8,\"id\":134,\"previousSibling\":{\"id\":133},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":135,\"textContent\":\" \",\"previousSibling\":{\"id\":134},\"parentNode\":{\"id\":128}},{\"nodeType\":1,\"id\":136,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":135},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":137,\"textContent\":\" \",\"previousSibling\":{\"id\":136},\"parentNode\":{\"id\":128}},{\"nodeType\":8,\"id\":138,\"previousSibling\":{\"id\":137},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \",\"previousSibling\":{\"id\":138},\"parentNode\":{\"id\":128}},{\"nodeType\":1,\"id\":140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":139},\"parentNode\":{\"id\":128}},{\"nodeType\":8,\"id\":141,\"previousSibling\":{\"id\":140},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":142,\"textContent\":\" \",\"previousSibling\":{\"id\":141},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":143,\"textContent\":\" \",\"parentNode\":{\"id\":133}},{\"nodeType\":1,\"id\":144,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":143},\"parentNode\":{\"id\":133}},{\"nodeType\":3,\"id\":145,\"textContent\":\" \",\"previousSibling\":{\"id\":144},\"parentNode\":{\"id\":133}},{\"nodeType\":3,\"id\":146,\"textContent\":\" \",\"parentNode\":{\"id\":144}},{\"nodeType\":1,\"id\":147,\"tagName\":\"H1\",\"attributes\":{},\"previousSibling\":{\"id\":146},\"parentNode\":{\"id\":144}},{\"nodeType\":3,\"id\":148,\"textContent\":\" \",\"previousSibling\":{\"id\":147},\"parentNode\":{\"id\":144}},{\"nodeType\":3,\"id\":149,\"textContent\":\"Instructions\",\"parentNode\":{\"id\":147}},{\"nodeType\":3,\"id\":150,\"textContent\":\" \",\"parentNode\":{\"id\":136}},{\"nodeType\":1,\"id\":151,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":150},\"parentNode\":{\"id\":136}},{\"nodeType\":3,\"id\":152,\"textContent\":\" \",\"previousSibling\":{\"id\":151},\"parentNode\":{\"id\":136}},{\"nodeType\":8,\"id\":153,\"previousSibling\":{\"id\":152},\"parentNode\":{\"id\":136}},{\"nodeType\":3,\"id\":154,\"textContent\":\" \",\"previousSibling\":{\"id\":153},\"parentNode\":{\"id\":136}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \",\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":156,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":155},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":157,\"tagName\":\"TABLE\",\"attributes\":{\"cellspacing\":\"0\",\"cellpadding\":\"0\",\"border\":\"0\",\"style\":\"display:block;\"},\"previousSibling\":{\"id\":156},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":158,\"textContent\":\" \",\"previousSibling\":{\"id\":157},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":159,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":158},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":160,\"textContent\":\" \",\"previousSibling\":{\"id\":159},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":161,\"tagName\":\"UL\",\"attributes\":{\"class\":\"fa-ul\"},\"previousSibling\":{\"id\":160},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":162,\"textContent\":\" \",\"previousSibling\":{\"id\":161},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":163,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":162},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":164,\"textContent\":\" \",\"previousSibling\":{\"id\":163},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":165,\"textContent\":\"We are interested in learning about how people make decisions about time. In this study, you are going to solve a series of problems about scheduling events. To help you solve the problems, we are going to give you a variety of graphs and diagrams. You are going to complete \",\"parentNode\":{\"id\":156}},{\"nodeType\":1,\"id\":166,\"tagName\":\"I\",\"attributes\":{},\"previousSibling\":{\"id\":165},\"parentNode\":{\"id\":156}},{\"nodeType\":3,\"id\":167,\"textContent\":\" of the activities on this computer. \",\"previousSibling\":{\"id\":166},\"parentNode\":{\"id\":156}},{\"nodeType\":3,\"id\":168,\"textContent\":\"all\",\"parentNode\":{\"id\":166}},{\"nodeType\":3,\"id\":169,\"textContent\":\" \",\"parentNode\":{\"id\":157}},{\"nodeType\":1,\"id\":170,\"tagName\":\"TBODY\",\"attributes\":{},\"previousSibling\":{\"id\":169},\"parentNode\":{\"id\":157}},{\"nodeType\":1,\"id\":171,\"tagName\":\"TR\",\"attributes\":{},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":172,\"textContent\":\" \",\"previousSibling\":{\"id\":171},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":173,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":172},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":174,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":173},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":175,\"tagName\":\"TR\",\"attributes\":{\"height\":\"15\"},\"previousSibling\":{\"id\":174},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":176,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":175},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":177,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":176},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":178,\"textContent\":\" \",\"previousSibling\":{\"id\":177},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":179,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":178},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":180,\"textContent\":\" \",\"previousSibling\":{\"id\":179},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":181,\"textContent\":\" \",\"parentNode\":{\"id\":171}},{\"nodeType\":1,\"id\":182,\"tagName\":\"TD\",\"attributes\":{\"width\":\"40\",\"rowspan\":\"2\"},\"previousSibling\":{\"id\":181},\"parentNode\":{\"id\":171}},{\"nodeType\":3,\"id\":183,\"textContent\":\" \",\"previousSibling\":{\"id\":182},\"parentNode\":{\"id\":171}},{\"nodeType\":1,\"id\":184,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":183},\"parentNode\":{\"id\":171}},{\"nodeType\":3,\"id\":185,\"textContent\":\" \",\"previousSibling\":{\"id\":184},\"parentNode\":{\"id\":171}},{\"nodeType\":1,\"id\":186,\"tagName\":\"A\",\"attributes\":{\"class\":\"fa fa-desktop fa-lg\"},\"parentNode\":{\"id\":182}},{\"nodeType\":3,\"id\":187,\"textContent\":\"Acme Factory [20 minutes]\",\"parentNode\":{\"id\":184}},{\"nodeType\":3,\"id\":188,\"textContent\":\" \",\"parentNode\":{\"id\":173}},{\"nodeType\":1,\"id\":189,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":188},\"parentNode\":{\"id\":173}},{\"nodeType\":3,\"id\":190,\"textContent\":\" \",\"previousSibling\":{\"id\":189},\"parentNode\":{\"id\":173}},{\"nodeType\":1,\"id\":191,\"tagName\":\"A\",\"attributes\":{\"id\":\"da1\",\"class\":\"subheading\"},\"parentNode\":{\"id\":189}},{\"nodeType\":3,\"id\":192,\"textContent\":\"Answer 15 questions to help a manager coordinate a factory shift schedule.\",\"parentNode\":{\"id\":191}},{\"nodeType\":3,\"id\":193,\"textContent\":\" \",\"parentNode\":{\"id\":177}},{\"nodeType\":1,\"id\":194,\"tagName\":\"TD\",\"attributes\":{\"rowspan\":\"2\"},\"previousSibling\":{\"id\":193},\"parentNode\":{\"id\":177}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \",\"previousSibling\":{\"id\":194},\"parentNode\":{\"id\":177}},{\"nodeType\":1,\"id\":196,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":195},\"parentNode\":{\"id\":177}},{\"nodeType\":3,\"id\":197,\"textContent\":\" \",\"previousSibling\":{\"id\":196},\"parentNode\":{\"id\":177}},{\"nodeType\":1,\"id\":198,\"tagName\":\"A\",\"attributes\":{\"class\":\"fa fa-desktop fa-lg\"},\"parentNode\":{\"id\":194}},{\"nodeType\":3,\"id\":199,\"textContent\":\"Final Survey [5 minutes]\",\"parentNode\":{\"id\":196}},{\"nodeType\":3,\"id\":200,\"textContent\":\" \",\"parentNode\":{\"id\":179}},{\"nodeType\":1,\"id\":201,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":200},\"parentNode\":{\"id\":179}},{\"nodeType\":3,\"id\":202,\"textContent\":\" \",\"previousSibling\":{\"id\":201},\"parentNode\":{\"id\":179}},{\"nodeType\":1,\"id\":203,\"tagName\":\"I\",\"attributes\":{},\"parentNode\":{\"id\":201}},{\"nodeType\":3,\"id\":204,\"textContent\":\"Complete a demographic survey and feedback on your experience.\",\"parentNode\":{\"id\":203}},{\"nodeType\":1,\"id\":205,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":159}},{\"nodeType\":3,\"id\":206,\"textContent\":\" \",\"previousSibling\":{\"id\":205},\"parentNode\":{\"id\":159}},{\"nodeType\":3,\"id\":207,\"textContent\":\"To ensure accurate results, please:\",\"parentNode\":{\"id\":205}},{\"nodeType\":3,\"id\":208,\"textContent\":\" \\t\",\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":209,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":208},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":210,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":209},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":211,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":210},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":212,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":211},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":212},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":214,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":213},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":215,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":214},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":216,\"textContent\":\" \",\"previousSibling\":{\"id\":215},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":217,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-check\",\"style\":\"color:green\"},\"parentNode\":{\"id\":209}},{\"nodeType\":3,\"id\":218,\"textContent\":\"DO read all instructions \",\"previousSibling\":{\"id\":217},\"parentNode\":{\"id\":209}},{\"nodeType\":1,\"id\":219,\"tagName\":\"I\",\"attributes\":{},\"previousSibling\":{\"id\":218},\"parentNode\":{\"id\":209}},{\"nodeType\":3,\"id\":220,\"textContent\":\" \",\"previousSibling\":{\"id\":219},\"parentNode\":{\"id\":209}},{\"nodeType\":3,\"id\":221,\"textContent\":\"carefully\",\"parentNode\":{\"id\":219}},{\"nodeType\":1,\"id\":222,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":211}},{\"nodeType\":3,\"id\":223,\"textContent\":\"DO NOT close this browser window\",\"previousSibling\":{\"id\":222},\"parentNode\":{\"id\":211}},{\"nodeType\":1,\"id\":224,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":213}},{\"nodeType\":3,\"id\":225,\"textContent\":\"DO NOT try to return to a previous page \",\"previousSibling\":{\"id\":224},\"parentNode\":{\"id\":213}},{\"nodeType\":1,\"id\":226,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":215}},{\"nodeType\":3,\"id\":227,\"textContent\":\"DO NOT use the back button on the mouse or web browser\",\"previousSibling\":{\"id\":226},\"parentNode\":{\"id\":215}},{\"nodeType\":3,\"id\":228,\"textContent\":\"If you have questions at any time, please raise your hand and the experimenter will assist you. \",\"parentNode\":{\"id\":163}},{\"nodeType\":3,\"id\":229,\"textContent\":\" \\t\",\"parentNode\":{\"id\":140}},{\"nodeType\":1,\"id\":230,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":229},\"parentNode\":{\"id\":140}},{\"nodeType\":3,\"id\":231,\"textContent\":\" \",\"previousSibling\":{\"id\":230},\"parentNode\":{\"id\":140}},{\"nodeType\":3,\"id\":232,\"textContent\":\"BEGIN\",\"parentNode\":{\"id\":230}}],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":126},{\"id\":131},{\"id\":127},{\"id\":128},{\"id\":132},{\"id\":133},{\"id\":143},{\"id\":144},{\"id\":146},{\"id\":147},{\"id\":149},{\"id\":148},{\"id\":145},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":150},{\"id\":151},{\"id\":155},{\"id\":156},{\"id\":165},{\"id\":166},{\"id\":168},{\"id\":167},{\"id\":157},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":181},{\"id\":182},{\"id\":186},{\"id\":183},{\"id\":184},{\"id\":187},{\"id\":185},{\"id\":172},{\"id\":173},{\"id\":188},{\"id\":189},{\"id\":191},{\"id\":192},{\"id\":190},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":193},{\"id\":194},{\"id\":198},{\"id\":195},{\"id\":196},{\"id\":199},{\"id\":197},{\"id\":178},{\"id\":179},{\"id\":200},{\"id\":201},{\"id\":203},{\"id\":204},{\"id\":202},{\"id\":180},{\"id\":158},{\"id\":159},{\"id\":205},{\"id\":207},{\"id\":206},{\"id\":160},{\"id\":161},{\"id\":208},{\"id\":209},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":221},{\"id\":220},{\"id\":210},{\"id\":211},{\"id\":222},{\"id\":223},{\"id\":212},{\"id\":213},{\"id\":224},{\"id\":225},{\"id\":214},{\"id\":215},{\"id\":226},{\"id\":227},{\"id\":216},{\"id\":162},{\"id\":163},{\"id\":228},{\"id\":164},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":229},{\"id\":230},{\"id\":232},{\"id\":231},{\"id\":141},{\"id\":142},{\"id\":129},{\"id\":130}],[],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":233,\"tagName\":\"IMG\",\"attributes\":{\"src\":\"img/acme.png\",\"id\":\"jspsych-single-stim-stimulus\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":234,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":233},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":235,\"textContent\":\"Press enter to continue\",\"parentNode\":{\"id\":234}}],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":233},{\"id\":234},{\"id\":235}],[],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":1,\"id\":59,\"tagName\":\"IMG\",\"attributes\":{\"src\":\"img/phone.png\",\"id\":\"jspsych-single-stim-stimulus\"}}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 172, dom: 495, initialDom: 498",
  "javascriptErrors": []
}