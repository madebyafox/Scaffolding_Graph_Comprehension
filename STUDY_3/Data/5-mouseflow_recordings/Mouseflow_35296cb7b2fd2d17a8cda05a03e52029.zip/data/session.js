var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "35296cb7b2fd2d17a8cda05a03e52029",
  "created": "2018-05-15T10:13:05.6629432-07:00",
  "lastActivity": "2018-05-15T10:15:04.0754818-07:00",
  "pageViews": [
    {
      "id": "051505235662dc955bd475db0d382ec087b7ce35",
      "startTime": "2018-05-15T10:13:05.839295-07:00",
      "endTime": "2018-05-15T10:15:04.0754818-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/5",
      "visitTime": 118409,
      "engagementTime": 76859,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 118409,
  "engagementTime": 76859,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.26",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.170 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.170",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=ZJPX1",
    "CONDITION=121"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "b95bc6af62c6c0c07db7fe58c7e0efda",
  "gdpr": false
}