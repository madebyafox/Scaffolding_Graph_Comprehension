var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "0d209c12ec7c5d09df191149219be6b0",
  "created": "2018-05-25T11:22:09.1720015-07:00",
  "lastActivity": "2018-05-25T11:23:12.1411265-07:00",
  "pageViews": [
    {
      "id": "052509572d3c1f7249befd5587663e8e67115fb4",
      "startTime": "2018-05-25T11:22:09.2734114-07:00",
      "endTime": "2018-05-25T11:23:12.1411265-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/13",
      "visitTime": 63016,
      "engagementTime": 62316,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 63016,
  "engagementTime": 62316,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.44",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=UV5LD",
    "CONDITION=114"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "29b55c1efcb5f86e5b5e34f5d394a045",
  "gdpr": false
}