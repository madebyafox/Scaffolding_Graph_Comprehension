var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "2b5a90dc2717927f4e052b438a87a16b",
  "created": "2018-05-18T11:17:41.9306021-07:00",
  "lastActivity": "2018-05-18T11:18:16.293136-07:00",
  "pageViews": [
    {
      "id": "051841265d2d52e622f78f9055fe47990c934ce6",
      "startTime": "2018-05-18T11:17:41.932136-07:00",
      "endTime": "2018-05-18T11:18:16.293136-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/10",
      "visitTime": 34361,
      "engagementTime": 30361,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 34361,
  "engagementTime": 30361,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.26",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=E3YN6",
    "CONDITION=113"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "5665da2462815aedb9a8e2e14fee305d",
  "gdpr": false
}