var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["060457199d1d6e7ad0ff6d8a92eb8443cb77fc4b"] = {
  "startTime": "2018-06-04T20:22:57.2906026Z",
  "websitePageUrl": "/16",
  "visitTime": 113520,
  "engagementTime": 111931,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1200,
  "tags": [
    "form-interact",
    "submit"
  ],
  "session": {
    "id": "34dd11c6c54ff3d8b7e507dedc559000",
    "created": "2018-06-04T20:22:57.2906026+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.181",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/16",
    "tags": [
      "form-interact",
      "submit"
    ],
    "variables": [
      "SID=K0CNH",
      "CONDITION=211"
    ],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "08cfee5a97a3605ce325cabb8fa422fa",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/34dd11c6c54ff3d8b7e507dedc559000/play"
  },
  "events": [
    {
      "t": 1,
      "e": 1,
      "ty": 14,
      "x": 0,
      "y": 1199
    },
    {
      "t": 248,
      "e": 248,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 248,
      "e": 248,
      "ty": 1,
      "x": 0,
      "y": 16
    },
    {
      "t": 900,
      "e": 900,
      "ty": 2,
      "x": 504,
      "y": 748
    },
    {
      "t": 1001,
      "e": 1001,
      "ty": 2,
      "x": 507,
      "y": 746
    },
    {
      "t": 1001,
      "e": 1001,
      "ty": 41,
      "x": 46077,
      "y": 40883,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 1101,
      "e": 1101,
      "ty": 2,
      "x": 514,
      "y": 746
    },
    {
      "t": 1200,
      "e": 1200,
      "ty": 2,
      "x": 534,
      "y": 747
    },
    {
      "t": 1250,
      "e": 1250,
      "ty": 41,
      "x": 49787,
      "y": 40993,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 1301,
      "e": 1301,
      "ty": 2,
      "x": 559,
      "y": 749
    },
    {
      "t": 1400,
      "e": 1400,
      "ty": 2,
      "x": 578,
      "y": 753
    },
    {
      "t": 1500,
      "e": 1500,
      "ty": 2,
      "x": 585,
      "y": 754
    },
    {
      "t": 1500,
      "e": 1500,
      "ty": 41,
      "x": 54845,
      "y": 41326,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 1600,
      "e": 1600,
      "ty": 2,
      "x": 601,
      "y": 755
    },
    {
      "t": 1700,
      "e": 1700,
      "ty": 2,
      "x": 614,
      "y": 756
    },
    {
      "t": 1750,
      "e": 1750,
      "ty": 41,
      "x": 59229,
      "y": 41437,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 1800,
      "e": 1800,
      "ty": 2,
      "x": 629,
      "y": 757
    },
    {
      "t": 1901,
      "e": 1901,
      "ty": 2,
      "x": 637,
      "y": 757
    },
    {
      "t": 2001,
      "e": 2001,
      "ty": 2,
      "x": 641,
      "y": 757
    },
    {
      "t": 2001,
      "e": 2001,
      "ty": 41,
      "x": 61140,
      "y": 41492,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 2101,
      "e": 2101,
      "ty": 2,
      "x": 649,
      "y": 756
    },
    {
      "t": 2200,
      "e": 2200,
      "ty": 2,
      "x": 654,
      "y": 753
    },
    {
      "t": 2250,
      "e": 2250,
      "ty": 41,
      "x": 63613,
      "y": 41104,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 2300,
      "e": 2300,
      "ty": 2,
      "x": 670,
      "y": 748
    },
    {
      "t": 2400,
      "e": 2400,
      "ty": 2,
      "x": 694,
      "y": 733
    },
    {
      "t": 2500,
      "e": 2500,
      "ty": 2,
      "x": 723,
      "y": 715
    },
    {
      "t": 2501,
      "e": 2501,
      "ty": 41,
      "x": 2462,
      "y": 40968,
      "ta": "> div.stimulus > div:[2]"
    },
    {
      "t": 2600,
      "e": 2600,
      "ty": 2,
      "x": 735,
      "y": 692
    },
    {
      "t": 2700,
      "e": 2700,
      "ty": 2,
      "x": 724,
      "y": 616
    },
    {
      "t": 2750,
      "e": 2750,
      "ty": 41,
      "x": 2060,
      "y": 32945,
      "ta": "> div.stimulus > div:[2]"
    },
    {
      "t": 2800,
      "e": 2800,
      "ty": 2,
      "x": 695,
      "y": 589
    },
    {
      "t": 2829,
      "e": 2829,
      "ty": 6,
      "x": 675,
      "y": 583,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2900,
      "e": 2900,
      "ty": 2,
      "x": 590,
      "y": 566
    },
    {
      "t": 3000,
      "e": 3000,
      "ty": 2,
      "x": 559,
      "y": 558
    },
    {
      "t": 3000,
      "e": 3000,
      "ty": 41,
      "x": 51922,
      "y": 28532,
      "ta": "#strategyAnswer"
    },
    {
      "t": 3222,
      "e": 3222,
      "ty": 3,
      "x": 559,
      "y": 558,
      "ta": "#strategyAnswer"
    },
    {
      "t": 3222,
      "e": 3222,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 3350,
      "e": 3350,
      "ty": 4,
      "x": 51922,
      "y": 28532,
      "ta": "#strategyAnswer"
    },
    {
      "t": 3350,
      "e": 3350,
      "ty": 5,
      "x": 559,
      "y": 558,
      "ta": "#strategyAnswer"
    },
    {
      "t": 3750,
      "e": 3750,
      "ty": 41,
      "x": 54957,
      "y": 28532,
      "ta": "#strategyAnswer"
    },
    {
      "t": 3779,
      "e": 3779,
      "ty": 7,
      "x": 704,
      "y": 573,
      "ta": "#strategyAnswer"
    },
    {
      "t": 3800,
      "e": 3800,
      "ty": 2,
      "x": 772,
      "y": 587
    },
    {
      "t": 3900,
      "e": 3900,
      "ty": 2,
      "x": 995,
      "y": 651
    },
    {
      "t": 4001,
      "e": 4001,
      "ty": 2,
      "x": 1042,
      "y": 676
    },
    {
      "t": 4001,
      "e": 4001,
      "ty": 41,
      "x": 18040,
      "y": 38533,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 4100,
      "e": 4100,
      "ty": 2,
      "x": 1103,
      "y": 712
    },
    {
      "t": 4200,
      "e": 4200,
      "ty": 2,
      "x": 1127,
      "y": 762
    },
    {
      "t": 4250,
      "e": 4250,
      "ty": 41,
      "x": 23960,
      "y": 46268,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 4300,
      "e": 4300,
      "ty": 2,
      "x": 1125,
      "y": 806
    },
    {
      "t": 4401,
      "e": 4401,
      "ty": 2,
      "x": 1124,
      "y": 808
    },
    {
      "t": 4500,
      "e": 4500,
      "ty": 2,
      "x": 1124,
      "y": 810
    },
    {
      "t": 4501,
      "e": 4501,
      "ty": 41,
      "x": 23819,
      "y": 48130,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 4600,
      "e": 4600,
      "ty": 2,
      "x": 1126,
      "y": 812
    },
    {
      "t": 4701,
      "e": 4701,
      "ty": 2,
      "x": 1132,
      "y": 814
    },
    {
      "t": 4750,
      "e": 4750,
      "ty": 41,
      "x": 24664,
      "y": 48417,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 4801,
      "e": 4801,
      "ty": 2,
      "x": 1140,
      "y": 816
    },
    {
      "t": 4900,
      "e": 4900,
      "ty": 2,
      "x": 1157,
      "y": 832
    },
    {
      "t": 5001,
      "e": 5001,
      "ty": 2,
      "x": 1174,
      "y": 857
    },
    {
      "t": 5001,
      "e": 5001,
      "ty": 41,
      "x": 27342,
      "y": 51496,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 5101,
      "e": 5101,
      "ty": 2,
      "x": 1195,
      "y": 905
    },
    {
      "t": 5200,
      "e": 5200,
      "ty": 2,
      "x": 1199,
      "y": 914
    },
    {
      "t": 5251,
      "e": 5251,
      "ty": 41,
      "x": 29104,
      "y": 55794,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 5301,
      "e": 5301,
      "ty": 2,
      "x": 1199,
      "y": 922
    },
    {
      "t": 5401,
      "e": 5401,
      "ty": 2,
      "x": 1184,
      "y": 932
    },
    {
      "t": 5500,
      "e": 5500,
      "ty": 2,
      "x": 1160,
      "y": 945
    },
    {
      "t": 5501,
      "e": 5501,
      "ty": 41,
      "x": 26356,
      "y": 57799,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 5600,
      "e": 5600,
      "ty": 2,
      "x": 1156,
      "y": 948
    },
    {
      "t": 5701,
      "e": 5701,
      "ty": 2,
      "x": 1150,
      "y": 951
    },
    {
      "t": 5751,
      "e": 5751,
      "ty": 41,
      "x": 25651,
      "y": 58372,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 5801,
      "e": 5801,
      "ty": 2,
      "x": 1148,
      "y": 954
    },
    {
      "t": 5900,
      "e": 5900,
      "ty": 2,
      "x": 1147,
      "y": 959
    },
    {
      "t": 6001,
      "e": 6001,
      "ty": 2,
      "x": 1147,
      "y": 964
    },
    {
      "t": 6002,
      "e": 6002,
      "ty": 41,
      "x": 21341,
      "y": 5957,
      "ta": "> div.stimulus > div:[2] > svg > g > g:[3] > path"
    },
    {
      "t": 6400,
      "e": 6400,
      "ty": 2,
      "x": 1147,
      "y": 965
    },
    {
      "t": 6500,
      "e": 6500,
      "ty": 41,
      "x": 25439,
      "y": 59232,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 6601,
      "e": 6601,
      "ty": 2,
      "x": 1159,
      "y": 963
    },
    {
      "t": 6751,
      "e": 6751,
      "ty": 41,
      "x": 22324,
      "y": 0,
      "ta": "> div.stimulus > div:[2] > svg > g > g:[3] > path"
    },
    {
      "t": 7101,
      "e": 7101,
      "ty": 2,
      "x": 1159,
      "y": 961
    },
    {
      "t": 7201,
      "e": 7201,
      "ty": 2,
      "x": 1157,
      "y": 960
    },
    {
      "t": 7251,
      "e": 7251,
      "ty": 41,
      "x": 26144,
      "y": 58874,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 7600,
      "e": 7600,
      "ty": 2,
      "x": 1157,
      "y": 959
    },
    {
      "t": 7701,
      "e": 7701,
      "ty": 2,
      "x": 1165,
      "y": 937
    },
    {
      "t": 7751,
      "e": 7751,
      "ty": 41,
      "x": 27342,
      "y": 55436,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 7800,
      "e": 7800,
      "ty": 2,
      "x": 1178,
      "y": 899
    },
    {
      "t": 7900,
      "e": 7900,
      "ty": 2,
      "x": 1269,
      "y": 802
    },
    {
      "t": 8000,
      "e": 8000,
      "ty": 2,
      "x": 1320,
      "y": 766
    },
    {
      "t": 8000,
      "e": 8000,
      "ty": 41,
      "x": 36493,
      "y": 49151,
      "ta": "> div.stimulus > div:[2] > svg > g > g:[7] > g:[15] > circle"
    },
    {
      "t": 8101,
      "e": 8101,
      "ty": 2,
      "x": 1325,
      "y": 762
    },
    {
      "t": 8251,
      "e": 8251,
      "ty": 41,
      "x": 63799,
      "y": 27306,
      "ta": "> div.stimulus > div:[2] > svg > g > g:[7] > g:[15] > circle"
    },
    {
      "t": 9148,
      "e": 9148,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 9154,
      "e": 9154,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "20"
    },
    {
      "t": 9186,
      "e": 9186,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": ""
    },
    {
      "t": 9339,
      "e": 9339,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 9339,
      "e": 9339,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9433,
      "e": 9433,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "y"
    },
    {
      "t": 9466,
      "e": 9466,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "y"
    },
    {
      "t": 9498,
      "e": 9498,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 9498,
      "e": 9498,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9603,
      "e": 9603,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "yO"
    },
    {
      "t": 9618,
      "e": 9618,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "yO"
    },
    {
      "t": 9811,
      "e": 9811,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 9811,
      "e": 9811,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9898,
      "e": 9898,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "yOU"
    },
    {
      "t": 10000,
      "e": 10000,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 10004,
      "e": 10004,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "yOU"
    },
    {
      "t": 10218,
      "e": 10218,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 10258,
      "e": 10258,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "yO"
    },
    {
      "t": 10322,
      "e": 10322,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 10369,
      "e": 10369,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "y"
    },
    {
      "t": 10425,
      "e": 10425,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 10473,
      "e": 10473,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": ""
    },
    {
      "t": 10603,
      "e": 10603,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": ""
    },
    {
      "t": 10818,
      "e": 10818,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "20"
    },
    {
      "t": 10899,
      "e": 10899,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": ""
    },
    {
      "t": 11043,
      "e": 11043,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 11138,
      "e": 11138,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 11139,
      "e": 11139,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11210,
      "e": 11210,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Y"
    },
    {
      "t": 11250,
      "e": 11250,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Y"
    },
    {
      "t": 11258,
      "e": 11258,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 11258,
      "e": 11258,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11338,
      "e": 11338,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Yo"
    },
    {
      "t": 11370,
      "e": 11370,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 11371,
      "e": 11371,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11450,
      "e": 11450,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You"
    },
    {
      "t": 11491,
      "e": 11491,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 11492,
      "e": 11492,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11553,
      "e": 11553,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You "
    },
    {
      "t": 11554,
      "e": 11554,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 11554,
      "e": 11554,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11641,
      "e": 11641,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 11642,
      "e": 11642,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11649,
      "e": 11649,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ca"
    },
    {
      "t": 11705,
      "e": 11705,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 11706,
      "e": 11706,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11738,
      "e": 11738,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 11770,
      "e": 11770,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 11778,
      "e": 11778,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 11778,
      "e": 11778,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11842,
      "e": 11842,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 11858,
      "e": 11858,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 11858,
      "e": 11858,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11970,
      "e": 11970,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 11994,
      "e": 11994,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 11995,
      "e": 11995,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12114,
      "e": 12114,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 12145,
      "e": 12145,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 12146,
      "e": 12146,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12226,
      "e": 12226,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 12250,
      "e": 12250,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 12251,
      "e": 12251,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12338,
      "e": 12338,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 12339,
      "e": 12339,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12370,
      "e": 12370,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||er"
    },
    {
      "t": 12457,
      "e": 12457,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 12482,
      "e": 12482,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 12482,
      "e": 12482,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12570,
      "e": 12570,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 12634,
      "e": 12634,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 12635,
      "e": 12635,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12698,
      "e": 12698,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 12746,
      "e": 12746,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 12747,
      "e": 12747,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12817,
      "e": 12817,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 12818,
      "e": 12818,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12825,
      "e": 12825,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ne"
    },
    {
      "t": 12898,
      "e": 12898,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 12898,
      "e": 12898,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12922,
      "e": 12922,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 12970,
      "e": 12970,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 13075,
      "e": 13075,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 13075,
      "e": 13075,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13146,
      "e": 13146,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 13146,
      "e": 13146,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13169,
      "e": 13169,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||wh"
    },
    {
      "t": 13226,
      "e": 13226,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 13274,
      "e": 13274,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 13274,
      "e": 13274,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13355,
      "e": 13355,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 13394,
      "e": 13394,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 13395,
      "e": 13395,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13449,
      "e": 13449,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 13450,
      "e": 13450,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13482,
      "e": 13482,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ch"
    },
    {
      "t": 13522,
      "e": 13522,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 13562,
      "e": 13562,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 13562,
      "e": 13562,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13658,
      "e": 13658,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 13706,
      "e": 13706,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 13707,
      "e": 13707,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13802,
      "e": 13802,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 13802,
      "e": 13802,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13809,
      "e": 13809,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||sh"
    },
    {
      "t": 13882,
      "e": 13882,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 13922,
      "e": 13922,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 13922,
      "e": 13922,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14002,
      "e": 14002,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 14033,
      "e": 14033,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 14034,
      "e": 14034,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14130,
      "e": 14130,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||f"
    },
    {
      "t": 14242,
      "e": 14242,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 14242,
      "e": 14242,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14315,
      "e": 14315,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 14419,
      "e": 14419,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 14419,
      "e": 14419,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14506,
      "e": 14506,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 16034,
      "e": 16034,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 16035,
      "e": 16035,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16105,
      "e": 16105,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 16338,
      "e": 16338,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 16418,
      "e": 16418,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You can determine which shifts"
    },
    {
      "t": 16443,
      "e": 16443,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 16443,
      "e": 16443,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16545,
      "e": 16545,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 16715,
      "e": 16715,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 16715,
      "e": 16715,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16794,
      "e": 16794,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 16826,
      "e": 16826,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 16827,
      "e": 16827,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16914,
      "e": 16914,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 16914,
      "e": 16914,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16929,
      "e": 16929,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ar"
    },
    {
      "t": 16978,
      "e": 16978,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 17075,
      "e": 17075,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 17075,
      "e": 17075,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17139,
      "e": 17139,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 17371,
      "e": 17371,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 17426,
      "e": 17426,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You can determine which shiftsstar"
    },
    {
      "t": 17482,
      "e": 17482,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 17531,
      "e": 17483,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You can determine which shiftssta"
    },
    {
      "t": 17594,
      "e": 17546,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 17626,
      "e": 17578,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You can determine which shiftsst"
    },
    {
      "t": 17697,
      "e": 17649,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 17721,
      "e": 17673,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You can determine which shiftss"
    },
    {
      "t": 17818,
      "e": 17770,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 17866,
      "e": 17818,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You can determine which shifts"
    },
    {
      "t": 18003,
      "e": 17955,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You can determine which shifts"
    },
    {
      "t": 20370,
      "e": 20322,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 20370,
      "e": 20322,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20418,
      "e": 20370,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 20586,
      "e": 20538,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 20587,
      "e": 20539,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20706,
      "e": 20658,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 20826,
      "e": 20778,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 20827,
      "e": 20779,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20857,
      "e": 20809,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 20939,
      "e": 20891,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 20939,
      "e": 20891,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21033,
      "e": 20985,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 21105,
      "e": 21057,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 21106,
      "e": 21058,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21218,
      "e": 21170,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 21219,
      "e": 21171,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21242,
      "e": 21194,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ar"
    },
    {
      "t": 21305,
      "e": 21257,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 21394,
      "e": 21346,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 21395,
      "e": 21347,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21458,
      "e": 21410,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 21883,
      "e": 21835,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 21930,
      "e": 21882,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You can determine which shifts satar"
    },
    {
      "t": 22123,
      "e": 22075,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 22162,
      "e": 22114,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You can determine which shifts sata"
    },
    {
      "t": 22257,
      "e": 22209,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 22354,
      "e": 22306,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You can determine which shifts sat"
    },
    {
      "t": 24106,
      "e": 24058,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 24203,
      "e": 24155,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You can determine which shifts sa"
    },
    {
      "t": 24291,
      "e": 24243,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 24370,
      "e": 24322,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You can determine which shifts s"
    },
    {
      "t": 24459,
      "e": 24411,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 24530,
      "e": 24482,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You can determine which shifts "
    },
    {
      "t": 24618,
      "e": 24570,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 24673,
      "e": 24625,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You can determine which shifts"
    },
    {
      "t": 24805,
      "e": 24757,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You can determine which shifts"
    },
    {
      "t": 25762,
      "e": 25714,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 25809,
      "e": 25761,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You can determine which shift"
    },
    {
      "t": 25906,
      "e": 25858,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 25946,
      "e": 25898,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You can determine which shif"
    },
    {
      "t": 26026,
      "e": 25978,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 26082,
      "e": 26034,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You can determine which shi"
    },
    {
      "t": 26203,
      "e": 26155,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You can determine which shi"
    },
    {
      "t": 26713,
      "e": 26665,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 26713,
      "e": 26665,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26793,
      "e": 26745,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||f"
    },
    {
      "t": 26881,
      "e": 26833,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 26883,
      "e": 26835,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26930,
      "e": 26882,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 27009,
      "e": 26961,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 27010,
      "e": 26962,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27090,
      "e": 27042,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 27097,
      "e": 27049,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 27097,
      "e": 27049,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27178,
      "e": 27130,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 27226,
      "e": 27178,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 27227,
      "e": 27179,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27298,
      "e": 27179,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 27314,
      "e": 27195,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 27314,
      "e": 27195,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27369,
      "e": 27250,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||c"
    },
    {
      "t": 27442,
      "e": 27323,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 27443,
      "e": 27324,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27514,
      "e": 27395,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||c"
    },
    {
      "t": 27578,
      "e": 27459,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 27578,
      "e": 27459,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27667,
      "e": 27548,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 27667,
      "e": 27548,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27691,
      "e": 27572,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ur"
    },
    {
      "t": 27722,
      "e": 27603,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 27778,
      "e": 27659,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 27779,
      "e": 27660,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27826,
      "e": 27707,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 27866,
      "e": 27747,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 27866,
      "e": 27747,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27977,
      "e": 27858,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 28194,
      "e": 28075,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 28195,
      "e": 28076,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28274,
      "e": 28155,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 28329,
      "e": 28210,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 28330,
      "e": 28211,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28426,
      "e": 28307,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 28754,
      "e": 28635,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 28755,
      "e": 28636,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28850,
      "e": 28731,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||1"
    },
    {
      "t": 28906,
      "e": 28787,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 28906,
      "e": 28787,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28986,
      "e": 28867,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 28987,
      "e": 28868,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29050,
      "e": 28931,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||12"
    },
    {
      "t": 29065,
      "e": 28946,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 29682,
      "e": 29563,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 29738,
      "e": 29619,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You can determine which shifts occur at 11"
    },
    {
      "t": 29818,
      "e": 29699,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 29882,
      "e": 29763,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 29882,
      "e": 29763,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29889,
      "e": 29770,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You can determine which shifts occur at 12"
    },
    {
      "t": 30003,
      "e": 29884,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You can determine which shifts occur at 12"
    },
    {
      "t": 30004,
      "e": 29885,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 30005,
      "e": 29886,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 30006,
      "e": 29887,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30065,
      "e": 29946,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 30170,
      "e": 30051,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "66"
    },
    {
      "t": 30170,
      "e": 30051,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30235,
      "e": 30116,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||b"
    },
    {
      "t": 30313,
      "e": 30194,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 30314,
      "e": 30195,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30369,
      "e": 30250,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||y"
    },
    {
      "t": 30491,
      "e": 30372,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 30492,
      "e": 30373,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30569,
      "e": 30450,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 30585,
      "e": 30466,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 30586,
      "e": 30467,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30650,
      "e": 30531,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 30882,
      "e": 30763,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 30883,
      "e": 30764,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30954,
      "e": 30835,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 31058,
      "e": 30939,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 31059,
      "e": 30940,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31131,
      "e": 31012,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 31362,
      "e": 31243,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 31417,
      "e": 31298,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You can determine which shifts occur at 12 by se"
    },
    {
      "t": 31506,
      "e": 31387,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 31506,
      "e": 31387,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31594,
      "e": 31475,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 31610,
      "e": 31491,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 31611,
      "e": 31492,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31666,
      "e": 31547,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 31738,
      "e": 31619,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 31739,
      "e": 31620,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31817,
      "e": 31698,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 31817,
      "e": 31698,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31826,
      "e": 31707,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ng"
    },
    {
      "t": 31898,
      "e": 31779,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 31898,
      "e": 31779,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31905,
      "e": 31786,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 31937,
      "e": 31818,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 32466,
      "e": 32347,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 32467,
      "e": 32348,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32572,
      "e": 32453,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||w"
    },
    {
      "t": 32586,
      "e": 32467,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 32587,
      "e": 32468,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32658,
      "e": 32539,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 32659,
      "e": 32540,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32674,
      "e": 32555,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ha"
    },
    {
      "t": 32739,
      "e": 32620,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 33321,
      "e": 33202,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 33385,
      "e": 33266,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You can determine which shifts occur at 12 by seeing wh"
    },
    {
      "t": 33506,
      "e": 33387,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 33553,
      "e": 33434,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You can determine which shifts occur at 12 by seeing w"
    },
    {
      "t": 35497,
      "e": 35378,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 35538,
      "e": 35378,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You can determine which shifts occur at 12 by seeing "
    },
    {
      "t": 36455,
      "e": 36295,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 36456,
      "e": 36296,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36462,
      "e": 36302,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||w"
    },
    {
      "t": 36600,
      "e": 36440,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You can determine which shifts occur at 12 by seeing w"
    },
    {
      "t": 37063,
      "e": 36903,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 37143,
      "e": 36983,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You can determine which shifts occur at 12 by seeing "
    },
    {
      "t": 37919,
      "e": 37759,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 37919,
      "e": 37759,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37998,
      "e": 37838,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||w"
    },
    {
      "t": 38143,
      "e": 37983,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 38143,
      "e": 37983,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38247,
      "e": 38087,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 38327,
      "e": 38167,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 38327,
      "e": 38167,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38407,
      "e": 38247,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 38415,
      "e": 38255,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 38416,
      "e": 38256,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38486,
      "e": 38326,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 38487,
      "e": 38327,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38502,
      "e": 38342,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ch"
    },
    {
      "t": 38598,
      "e": 38438,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 38623,
      "e": 38463,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 38623,
      "e": 38463,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38727,
      "e": 38567,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 39759,
      "e": 39599,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 39760,
      "e": 39600,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39822,
      "e": 39662,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 39894,
      "e": 39734,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 39894,
      "e": 39734,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39983,
      "e": 39823,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 40079,
      "e": 39919,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 40080,
      "e": 39920,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40127,
      "e": 39967,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 40247,
      "e": 40087,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 40248,
      "e": 40088,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40311,
      "e": 40151,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 40319,
      "e": 40159,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 40321,
      "e": 40161,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40366,
      "e": 40206,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 40438,
      "e": 40278,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 40439,
      "e": 40279,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40511,
      "e": 40351,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 40511,
      "e": 40351,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40526,
      "e": 40366,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s "
    },
    {
      "t": 40615,
      "e": 40455,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 40646,
      "e": 40486,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 40648,
      "e": 40488,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40694,
      "e": 40534,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 40766,
      "e": 40606,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 40767,
      "e": 40607,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40862,
      "e": 40702,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 40887,
      "e": 40727,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 40888,
      "e": 40728,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40942,
      "e": 40782,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 41022,
      "e": 40862,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 41022,
      "e": 40862,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41095,
      "e": 40935,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 41200,
      "e": 41040,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You can determine which shifts occur at 12 by seeing which points on t"
    },
    {
      "t": 41215,
      "e": 41055,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 41216,
      "e": 41056,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41286,
      "e": 41126,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 41399,
      "e": 41239,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You can determine which shifts occur at 12 by seeing which points on th"
    },
    {
      "t": 41527,
      "e": 41367,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 41535,
      "e": 41375,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You can determine which shifts occur at 12 by seeing which points on t"
    },
    {
      "t": 41622,
      "e": 41462,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 41686,
      "e": 41526,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You can determine which shifts occur at 12 by seeing which points on "
    },
    {
      "t": 41801,
      "e": 41527,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You can determine which shifts occur at 12 by seeing which points on "
    },
    {
      "t": 42687,
      "e": 42413,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 42688,
      "e": 42414,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42758,
      "e": 42484,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 42782,
      "e": 42508,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 42782,
      "e": 42508,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42854,
      "e": 42580,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 42854,
      "e": 42580,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42870,
      "e": 42596,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||he"
    },
    {
      "t": 42943,
      "e": 42669,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 42943,
      "e": 42669,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42957,
      "e": 42683,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 43014,
      "e": 42740,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 43199,
      "e": 42925,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 43199,
      "e": 42925,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43254,
      "e": 42980,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 43455,
      "e": 43181,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 43456,
      "e": 43182,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43527,
      "e": 43253,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 43615,
      "e": 43341,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 43616,
      "e": 43342,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43702,
      "e": 43428,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 43702,
      "e": 43428,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43750,
      "e": 43476,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ne"
    },
    {
      "t": 43807,
      "e": 43533,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 43807,
      "e": 43533,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 43807,
      "e": 43533,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43894,
      "e": 43620,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 44001,
      "e": 43727,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You can determine which shifts occur at 12 by seeing which points on the line "
    },
    {
      "t": 46207,
      "e": 45933,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 46208,
      "e": 45934,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46262,
      "e": 45988,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 46262,
      "e": 45988,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46302,
      "e": 46028,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||co"
    },
    {
      "t": 46358,
      "e": 46084,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 46479,
      "e": 46205,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 46479,
      "e": 46205,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46574,
      "e": 46300,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 46646,
      "e": 46372,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 46646,
      "e": 46372,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46703,
      "e": 46429,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 46734,
      "e": 46460,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 46735,
      "e": 46461,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46822,
      "e": 46548,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 46822,
      "e": 46548,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 46822,
      "e": 46548,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46894,
      "e": 46620,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 46902,
      "e": 46628,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 46902,
      "e": 46628,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 47007,
      "e": 46733,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 47055,
      "e": 46781,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 47055,
      "e": 46781,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 47119,
      "e": 46845,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 47215,
      "e": 46941,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 47216,
      "e": 46942,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 47278,
      "e": 47004,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 47279,
      "e": 47005,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 47310,
      "e": 47036,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ut"
    },
    {
      "t": 47366,
      "e": 47092,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 47366,
      "e": 47092,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 47367,
      "e": 47093,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 47463,
      "e": 47189,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 47471,
      "e": 47197,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 47471,
      "e": 47197,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 47534,
      "e": 47260,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 47534,
      "e": 47260,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 47557,
      "e": 47283,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||of"
    },
    {
      "t": 47646,
      "e": 47372,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 47654,
      "e": 47380,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 47655,
      "e": 47381,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 47743,
      "e": 47469,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 48319,
      "e": 48045,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 48320,
      "e": 48046,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48326,
      "e": 48052,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 48327,
      "e": 48053,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48486,
      "e": 48212,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||21"
    },
    {
      "t": 48551,
      "e": 48277,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 49015,
      "e": 48741,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 49062,
      "e": 48788,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You can determine which shifts occur at 12 by seeing which points on the line coming out of 2"
    },
    {
      "t": 49110,
      "e": 48836,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 49111,
      "e": 48837,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49166,
      "e": 48892,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 49167,
      "e": 48893,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49192,
      "e": 48918,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||12"
    },
    {
      "t": 49262,
      "e": 48988,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 49310,
      "e": 49036,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 49310,
      "e": 49036,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49383,
      "e": 49109,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 49542,
      "e": 49268,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 49598,
      "e": 49268,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You can determine which shifts occur at 12 by seeing which points on the line coming out of 212"
    },
    {
      "t": 49662,
      "e": 49332,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 49702,
      "e": 49372,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You can determine which shifts occur at 12 by seeing which points on the line coming out of 21"
    },
    {
      "t": 49767,
      "e": 49437,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 49814,
      "e": 49484,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You can determine which shifts occur at 12 by seeing which points on the line coming out of 2"
    },
    {
      "t": 49886,
      "e": 49556,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 49942,
      "e": 49612,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 49942,
      "e": 49612,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49951,
      "e": 49621,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You can determine which shifts occur at 12 by seeing which points on the line coming out of 1"
    },
    {
      "t": 50022,
      "e": 49692,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 50023,
      "e": 49693,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50095,
      "e": 49765,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||2"
    },
    {
      "t": 50143,
      "e": 49813,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 50182,
      "e": 49852,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 50184,
      "e": 49854,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50286,
      "e": 49956,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 50382,
      "e": 50052,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 50383,
      "e": 50053,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50487,
      "e": 50157,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 50488,
      "e": 50158,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50494,
      "e": 50164,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||to"
    },
    {
      "t": 50550,
      "e": 50220,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 50582,
      "e": 50252,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 50583,
      "e": 50253,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50686,
      "e": 50356,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 50687,
      "e": 50357,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50694,
      "e": 50364,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||wa"
    },
    {
      "t": 50798,
      "e": 50468,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 50903,
      "e": 50573,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 50904,
      "e": 50574,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50990,
      "e": 50660,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 51054,
      "e": 50724,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 51054,
      "e": 50724,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51159,
      "e": 50829,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 51159,
      "e": 50829,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51198,
      "e": 50868,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ds"
    },
    {
      "t": 51278,
      "e": 50948,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 51302,
      "e": 50972,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 51302,
      "e": 50972,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51359,
      "e": 51029,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 51359,
      "e": 51029,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 51359,
      "e": 51029,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51453,
      "e": 51123,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 51486,
      "e": 51156,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 51487,
      "e": 51157,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51494,
      "e": 51164,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 51494,
      "e": 51164,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51566,
      "e": 51236,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||he"
    },
    {
      "t": 51582,
      "e": 51252,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 51583,
      "e": 51253,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51590,
      "e": 51260,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 51639,
      "e": 51309,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 51639,
      "e": 51309,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51654,
      "e": 51324,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 51719,
      "e": 51389,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 51727,
      "e": 51397,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 51728,
      "e": 51398,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51798,
      "e": 51468,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 51798,
      "e": 51468,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51806,
      "e": 51476,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ig"
    },
    {
      "t": 51854,
      "e": 51524,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 51870,
      "e": 51540,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 51870,
      "e": 51540,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51926,
      "e": 51596,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 51927,
      "e": 51597,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51934,
      "e": 51604,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ht"
    },
    {
      "t": 52015,
      "e": 51685,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 52135,
      "e": 51805,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "190"
    },
    {
      "t": 52136,
      "e": 51806,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52198,
      "e": 51868,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||."
    },
    {
      "t": 52671,
      "e": 52341,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 52671,
      "e": 52341,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52741,
      "e": 52411,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 52790,
      "e": 52460,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 52918,
      "e": 52588,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "66"
    },
    {
      "t": 52919,
      "e": 52589,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52990,
      "e": 52660,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||B"
    },
    {
      "t": 52997,
      "e": 52667,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 53005,
      "e": 52675,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 53006,
      "e": 52676,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53110,
      "e": 52780,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 53110,
      "e": 52780,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53134,
      "e": 52804,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||re"
    },
    {
      "t": 53182,
      "e": 52852,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 53207,
      "e": 52852,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 53209,
      "e": 52854,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53293,
      "e": 52938,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 53302,
      "e": 52947,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "75"
    },
    {
      "t": 53302,
      "e": 52947,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53390,
      "e": 53035,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||k"
    },
    {
      "t": 53414,
      "e": 53059,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 53414,
      "e": 53059,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53478,
      "e": 53123,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 53600,
      "e": 53245,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You can determine which shifts occur at 12 by seeing which points on the line coming out of 12 towards the right. Breaks"
    },
    {
      "t": 53903,
      "e": 53548,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 53904,
      "e": 53549,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54006,
      "e": 53651,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 54350,
      "e": 53995,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 54351,
      "e": 53996,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54414,
      "e": 54059,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 54446,
      "e": 54091,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 54446,
      "e": 54091,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54502,
      "e": 54147,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 54502,
      "e": 54147,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54550,
      "e": 54195,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ha"
    },
    {
      "t": 54567,
      "e": 54212,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 54567,
      "e": 54212,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54590,
      "e": 54235,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 54654,
      "e": 54299,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 54670,
      "e": 54315,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 54670,
      "e": 54315,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54750,
      "e": 54395,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 55198,
      "e": 54843,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 55200,
      "e": 54845,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 55262,
      "e": 54907,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 55326,
      "e": 54971,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 55326,
      "e": 54971,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 55390,
      "e": 55035,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||c"
    },
    {
      "t": 55463,
      "e": 55108,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 55463,
      "e": 55108,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 55542,
      "e": 55187,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||c"
    },
    {
      "t": 55614,
      "e": 55259,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 55614,
      "e": 55259,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 55735,
      "e": 55380,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||u"
    },
    {
      "t": 55735,
      "e": 55380,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 55736,
      "e": 55381,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 55806,
      "e": 55451,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 55806,
      "e": 55451,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 55838,
      "e": 55483,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r "
    },
    {
      "t": 55878,
      "e": 55523,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 55959,
      "e": 55604,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 55959,
      "e": 55604,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56038,
      "e": 55683,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 56102,
      "e": 55747,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 56102,
      "e": 55747,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56182,
      "e": 55827,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 56214,
      "e": 55859,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 56215,
      "e": 55860,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56286,
      "e": 55931,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 56302,
      "e": 55947,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 56302,
      "e": 55947,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56391,
      "e": 56036,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 56414,
      "e": 56059,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 56415,
      "e": 56060,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56494,
      "e": 56139,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 56495,
      "e": 56140,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56525,
      "e": 56170,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||he"
    },
    {
      "t": 56566,
      "e": 56211,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 56605,
      "e": 56250,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 56606,
      "e": 56251,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56695,
      "e": 56340,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 56800,
      "e": 56445,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You can determine which shifts occur at 12 by seeing which points on the line coming out of 12 towards the right. Breaks that occur on the "
    },
    {
      "t": 57278,
      "e": 56923,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 57334,
      "e": 56979,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You can determine which shifts occur at 12 by seeing which points on the line coming out of 12 towards the right. Breaks that occur on the"
    },
    {
      "t": 57390,
      "e": 57035,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 57439,
      "e": 57036,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You can determine which shifts occur at 12 by seeing which points on the line coming out of 12 towards the right. Breaks that occur on th"
    },
    {
      "t": 57494,
      "e": 57091,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 57541,
      "e": 57138,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You can determine which shifts occur at 12 by seeing which points on the line coming out of 12 towards the right. Breaks that occur on t"
    },
    {
      "t": 57622,
      "e": 57219,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 57654,
      "e": 57251,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You can determine which shifts occur at 12 by seeing which points on the line coming out of 12 towards the right. Breaks that occur on "
    },
    {
      "t": 57800,
      "e": 57397,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You can determine which shifts occur at 12 by seeing which points on the line coming out of 12 towards the right. Breaks that occur on "
    },
    {
      "t": 58054,
      "e": 57651,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 58056,
      "e": 57653,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 58101,
      "e": 57698,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 58102,
      "e": 57699,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 58166,
      "e": 57763,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||12"
    },
    {
      "t": 58222,
      "e": 57819,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 58520,
      "e": 58117,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 58558,
      "e": 58155,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You can determine which shifts occur at 12 by seeing which points on the line coming out of 12 towards the right. Breaks that occur on 1"
    },
    {
      "t": 58638,
      "e": 58235,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 58677,
      "e": 58274,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You can determine which shifts occur at 12 by seeing which points on the line coming out of 12 towards the right. Breaks that occur on "
    },
    {
      "t": 58710,
      "e": 58307,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 58710,
      "e": 58307,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 58790,
      "e": 58387,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 58814,
      "e": 58411,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 58863,
      "e": 58412,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You can determine which shifts occur at 12 by seeing which points on the line coming out of 12 towards the right. Breaks that occur on "
    },
    {
      "t": 58934,
      "e": 58483,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 58990,
      "e": 58539,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You can determine which shifts occur at 12 by seeing which points on the line coming out of 12 towards the right. Breaks that occur on"
    },
    {
      "t": 59063,
      "e": 58612,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 59102,
      "e": 58651,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You can determine which shifts occur at 12 by seeing which points on the line coming out of 12 towards the right. Breaks that occur o"
    },
    {
      "t": 59174,
      "e": 58723,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 59214,
      "e": 58763,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You can determine which shifts occur at 12 by seeing which points on the line coming out of 12 towards the right. Breaks that occur "
    },
    {
      "t": 59301,
      "e": 58850,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 59302,
      "e": 58851,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 59438,
      "e": 58987,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 59711,
      "e": 59260,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 59712,
      "e": 59261,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 59781,
      "e": 59330,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 59822,
      "e": 59371,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 59822,
      "e": 59371,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 59886,
      "e": 59435,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 59934,
      "e": 59483,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 59935,
      "e": 59484,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 60070,
      "e": 59619,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||1"
    },
    {
      "t": 60351,
      "e": 59900,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 60351,
      "e": 59900,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 60470,
      "e": 60019,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||2"
    },
    {
      "t": 60470,
      "e": 60019,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "189"
    },
    {
      "t": 60471,
      "e": 60020,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 60575,
      "e": 60124,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||-"
    },
    {
      "t": 60784,
      "e": 60333,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 60785,
      "e": 60334,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 60919,
      "e": 60468,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 61047,
      "e": 60596,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 61047,
      "e": 60596,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 61125,
      "e": 60674,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 61134,
      "e": 60683,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 61134,
      "e": 60683,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 61198,
      "e": 60747,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 61342,
      "e": 60891,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 61382,
      "e": 60931,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You can determine which shifts occur at 12 by seeing which points on the line coming out of 12 towards the right. Breaks that occur at 12-om"
    },
    {
      "t": 61438,
      "e": 60987,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 61478,
      "e": 60987,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You can determine which shifts occur at 12 by seeing which points on the line coming out of 12 towards the right. Breaks that occur at 12-o"
    },
    {
      "t": 61543,
      "e": 61052,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 61606,
      "e": 61115,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You can determine which shifts occur at 12 by seeing which points on the line coming out of 12 towards the right. Breaks that occur at 12-"
    },
    {
      "t": 61918,
      "e": 61427,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 61974,
      "e": 61483,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You can determine which shifts occur at 12 by seeing which points on the line coming out of 12 towards the right. Breaks that occur at 12"
    },
    {
      "t": 62183,
      "e": 61692,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 62183,
      "e": 61692,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 62230,
      "e": 61739,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 62366,
      "e": 61875,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 62366,
      "e": 61875,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 62446,
      "e": 61955,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 62566,
      "e": 62075,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 62567,
      "e": 62076,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 62646,
      "e": 62155,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 62838,
      "e": 62347,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 62839,
      "e": 62348,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 62990,
      "e": 62499,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 62990,
      "e": 62499,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 62990,
      "e": 62499,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 63101,
      "e": 62610,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 63102,
      "e": 62611,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 63166,
      "e": 62675,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||re"
    },
    {
      "t": 63238,
      "e": 62747,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 63247,
      "e": 62756,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 63247,
      "e": 62756,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 63358,
      "e": 62867,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 64751,
      "e": 64260,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 64751,
      "e": 64260,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 64838,
      "e": 64347,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 64902,
      "e": 64411,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 64902,
      "e": 64411,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 64998,
      "e": 64507,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 65086,
      "e": 64595,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 65088,
      "e": 64597,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 65151,
      "e": 64660,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 65247,
      "e": 64756,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 65247,
      "e": 64756,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 65293,
      "e": 64802,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 65294,
      "e": 64803,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 65334,
      "e": 64843,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||nt"
    },
    {
      "t": 65381,
      "e": 64890,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 65470,
      "e": 64979,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 65471,
      "e": 64980,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 65550,
      "e": 65059,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 65550,
      "e": 65059,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 65598,
      "e": 65107,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s "
    },
    {
      "t": 65646,
      "e": 65155,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 65670,
      "e": 65179,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 65670,
      "e": 65179,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 65735,
      "e": 65244,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 66079,
      "e": 65588,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 66080,
      "e": 65589,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 66174,
      "e": 65683,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 66197,
      "e": 65706,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 66198,
      "e": 65707,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 66270,
      "e": 65779,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 66302,
      "e": 65811,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 66302,
      "e": 65811,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 66382,
      "e": 65891,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 66415,
      "e": 65924,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 66415,
      "e": 65924,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 66517,
      "e": 66026,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 66525,
      "e": 66034,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 66526,
      "e": 66035,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 66654,
      "e": 66163,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 67702,
      "e": 67211,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 67703,
      "e": 67212,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 67750,
      "e": 67259,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 67846,
      "e": 67355,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "86"
    },
    {
      "t": 67846,
      "e": 67355,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 67918,
      "e": 67427,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||v"
    },
    {
      "t": 67990,
      "e": 67499,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 67991,
      "e": 67500,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 68094,
      "e": 67603,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 68094,
      "e": 67603,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 68126,
      "e": 67635,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||er"
    },
    {
      "t": 68182,
      "e": 67691,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 68319,
      "e": 67691,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 68321,
      "e": 67693,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 68366,
      "e": 67738,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 68414,
      "e": 67786,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 68414,
      "e": 67786,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 68478,
      "e": 67850,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 68501,
      "e": 67873,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 68502,
      "e": 67874,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 68606,
      "e": 67978,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||c"
    },
    {
      "t": 68607,
      "e": 67979,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 68607,
      "e": 67979,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 68686,
      "e": 68058,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 68686,
      "e": 68058,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 68702,
      "e": 68074,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||al"
    },
    {
      "t": 68782,
      "e": 68154,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 68814,
      "e": 68186,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 68815,
      "e": 68187,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 68879,
      "e": 68251,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 68959,
      "e": 68331,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 68959,
      "e": 68331,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 69030,
      "e": 68402,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 69263,
      "e": 68635,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 69263,
      "e": 68635,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 69341,
      "e": 68713,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||x"
    },
    {
      "t": 69358,
      "e": 68730,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 69358,
      "e": 68730,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 69447,
      "e": 68819,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 69806,
      "e": 69178,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 69807,
      "e": 69179,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 69878,
      "e": 69250,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||c"
    },
    {
      "t": 70000,
      "e": 69372,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You can determine which shifts occur at 12 by seeing which points on the line coming out of 12 towards the right. Breaks that occur at 12pm are points on the vertical axic"
    },
    {
      "t": 70183,
      "e": 69555,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 70682,
      "e": 70054,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 70715,
      "e": 70087,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 70747,
      "e": 70119,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 70781,
      "e": 70153,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 70813,
      "e": 70185,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 70846,
      "e": 70218,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 70879,
      "e": 70251,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 70912,
      "e": 70284,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 70946,
      "e": 70318,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 70979,
      "e": 70351,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 71011,
      "e": 70383,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 71044,
      "e": 70416,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 71061,
      "e": 70433,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You can determine which shifts occur at 12 by seeing which points on the line coming out of 12 towards the right. Breaks that occur at 12pm are points on the "
    },
    {
      "t": 71200,
      "e": 70572,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You can determine which shifts occur at 12 by seeing which points on the line coming out of 12 towards the right. Breaks that occur at 12pm are points on the "
    },
    {
      "t": 71671,
      "e": 71043,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 71672,
      "e": 71044,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 71743,
      "e": 71115,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 71831,
      "e": 71203,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 71832,
      "e": 71204,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 71833,
      "e": 71205,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 71834,
      "e": 71206,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 71861,
      "e": 71233,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||op"
    },
    {
      "t": 71861,
      "e": 71233,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 71886,
      "e": 71258,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 71886,
      "e": 71258,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 71949,
      "e": 71321,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 72687,
      "e": 72059,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 72702,
      "e": 72059,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You can determine which shifts occur at 12 by seeing which points on the line coming out of 12 towards the right. Breaks that occur at 12pm are points on the hop"
    },
    {
      "t": 72806,
      "e": 72163,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 72821,
      "e": 72178,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You can determine which shifts occur at 12 by seeing which points on the line coming out of 12 towards the right. Breaks that occur at 12pm are points on the ho"
    },
    {
      "t": 73000,
      "e": 72357,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You can determine which shifts occur at 12 by seeing which points on the line coming out of 12 towards the right. Breaks that occur at 12pm are points on the ho"
    },
    {
      "t": 73094,
      "e": 72451,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 73096,
      "e": 72453,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 73150,
      "e": 72507,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 73190,
      "e": 72547,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 73191,
      "e": 72548,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 73286,
      "e": 72643,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 73333,
      "e": 72690,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "90"
    },
    {
      "t": 73334,
      "e": 72691,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 73414,
      "e": 72771,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||z"
    },
    {
      "t": 73510,
      "e": 72867,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 73511,
      "e": 72868,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 73590,
      "e": 72947,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 73629,
      "e": 72986,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 73630,
      "e": 72987,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 73685,
      "e": 73042,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 73774,
      "e": 73131,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 73775,
      "e": 73132,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 73837,
      "e": 73194,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 73839,
      "e": 73196,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 73846,
      "e": 73203,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||nt"
    },
    {
      "t": 73928,
      "e": 73285,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 74086,
      "e": 73443,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 74125,
      "e": 73482,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You can determine which shifts occur at 12 by seeing which points on the line coming out of 12 towards the right. Breaks that occur at 12pm are points on the horizaon"
    },
    {
      "t": 74190,
      "e": 73547,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 74230,
      "e": 73547,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You can determine which shifts occur at 12 by seeing which points on the line coming out of 12 towards the right. Breaks that occur at 12pm are points on the horizao"
    },
    {
      "t": 74294,
      "e": 73611,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 74341,
      "e": 73658,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You can determine which shifts occur at 12 by seeing which points on the line coming out of 12 towards the right. Breaks that occur at 12pm are points on the horiza"
    },
    {
      "t": 74405,
      "e": 73722,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 74469,
      "e": 73786,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You can determine which shifts occur at 12 by seeing which points on the line coming out of 12 towards the right. Breaks that occur at 12pm are points on the horiz"
    },
    {
      "t": 74599,
      "e": 73916,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You can determine which shifts occur at 12 by seeing which points on the line coming out of 12 towards the right. Breaks that occur at 12pm are points on the horiz"
    },
    {
      "t": 74901,
      "e": 74218,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 74901,
      "e": 74218,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 74973,
      "e": 74290,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 75061,
      "e": 74378,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 75062,
      "e": 74379,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 75125,
      "e": 74442,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 75126,
      "e": 74443,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 75141,
      "e": 74458,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||nt"
    },
    {
      "t": 75198,
      "e": 74515,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 75335,
      "e": 74652,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 75335,
      "e": 74652,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 75421,
      "e": 74738,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 75421,
      "e": 74738,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 75430,
      "e": 74747,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||al"
    },
    {
      "t": 75550,
      "e": 74867,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 75566,
      "e": 74883,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 75567,
      "e": 74884,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 75661,
      "e": 74978,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 75734,
      "e": 75051,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 75734,
      "e": 75051,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 75814,
      "e": 75131,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 75917,
      "e": 75234,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 75919,
      "e": 75236,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 75966,
      "e": 75283,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 76078,
      "e": 75395,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 76079,
      "e": 75396,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 76149,
      "e": 75466,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 76150,
      "e": 75467,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 76198,
      "e": 75515,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ne"
    },
    {
      "t": 76238,
      "e": 75555,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 76735,
      "e": 76052,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 76735,
      "e": 76052,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 76814,
      "e": 76131,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 77423,
      "e": 76740,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 77424,
      "e": 76741,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 77502,
      "e": 76819,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 77526,
      "e": 76843,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "66"
    },
    {
      "t": 77526,
      "e": 76843,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 77606,
      "e": 76923,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||b"
    },
    {
      "t": 77686,
      "e": 77003,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 77687,
      "e": 77004,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 77783,
      "e": 77005,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 78158,
      "e": 77380,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "86"
    },
    {
      "t": 78159,
      "e": 77381,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 78238,
      "e": 77460,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||v"
    },
    {
      "t": 78485,
      "e": 77707,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 78533,
      "e": 77755,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You can determine which shifts occur at 12 by seeing which points on the line coming out of 12 towards the right. Breaks that occur at 12pm are points on the horizontal line abo"
    },
    {
      "t": 78926,
      "e": 78148,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "86"
    },
    {
      "t": 78927,
      "e": 78149,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 78933,
      "e": 78155,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 78934,
      "e": 78156,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 78973,
      "e": 78195,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||vc"
    },
    {
      "t": 79006,
      "e": 78228,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 79206,
      "e": 78428,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 79207,
      "e": 78429,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 79326,
      "e": 78548,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 79446,
      "e": 78668,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 79501,
      "e": 78723,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You can determine which shifts occur at 12 by seeing which points on the line coming out of 12 towards the right. Breaks that occur at 12pm are points on the horizontal line abovc"
    },
    {
      "t": 79629,
      "e": 78851,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 79630,
      "e": 78852,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 79758,
      "e": 78980,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 79797,
      "e": 79019,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 79845,
      "e": 79067,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You can determine which shifts occur at 12 by seeing which points on the line coming out of 12 towards the right. Breaks that occur at 12pm are points on the horizontal line abovc"
    },
    {
      "t": 79926,
      "e": 79148,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 79973,
      "e": 79195,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 79973,
      "e": 79195,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 79981,
      "e": 79203,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You can determine which shifts occur at 12 by seeing which points on the line coming out of 12 towards the right. Breaks that occur at 12pm are points on the horizontal line above"
    },
    {
      "t": 80046,
      "e": 79268,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 80230,
      "e": 79452,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 80231,
      "e": 79453,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 80294,
      "e": 79516,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 80342,
      "e": 79564,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 80342,
      "e": 79564,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 80422,
      "e": 79644,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||1"
    },
    {
      "t": 80486,
      "e": 79708,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 80486,
      "e": 79708,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 80590,
      "e": 79812,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||2"
    },
    {
      "t": 80678,
      "e": 79900,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 80679,
      "e": 79901,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 80743,
      "e": 79901,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 80870,
      "e": 80028,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 80871,
      "e": 80029,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 80909,
      "e": 80067,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 81897,
      "e": 81055,
      "ty": 2,
      "x": 1305,
      "y": 775
    },
    {
      "t": 81997,
      "e": 81155,
      "ty": 2,
      "x": 1293,
      "y": 802
    },
    {
      "t": 81998,
      "e": 81156,
      "ty": 41,
      "x": 35728,
      "y": 47557,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 82046,
      "e": 81204,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "190"
    },
    {
      "t": 82047,
      "e": 81205,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 82085,
      "e": 81243,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||."
    },
    {
      "t": 82097,
      "e": 81255,
      "ty": 2,
      "x": 1280,
      "y": 820
    },
    {
      "t": 82197,
      "e": 81355,
      "ty": 2,
      "x": 1197,
      "y": 877
    },
    {
      "t": 82199,
      "e": 81357,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You can determine which shifts occur at 12 by seeing which points on the line coming out of 12 towards the right. Breaks that occur at 12pm are points on the horizontal line above 12pm."
    },
    {
      "t": 82248,
      "e": 81406,
      "ty": 41,
      "x": 27342,
      "y": 53359,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 82298,
      "e": 81456,
      "ty": 2,
      "x": 1159,
      "y": 877
    },
    {
      "t": 82397,
      "e": 81555,
      "ty": 2,
      "x": 767,
      "y": 772
    },
    {
      "t": 82497,
      "e": 81655,
      "ty": 2,
      "x": 414,
      "y": 726
    },
    {
      "t": 82498,
      "e": 81656,
      "ty": 41,
      "x": 35623,
      "y": 39775,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 82598,
      "e": 81756,
      "ty": 2,
      "x": 407,
      "y": 723
    },
    {
      "t": 82697,
      "e": 81855,
      "ty": 2,
      "x": 392,
      "y": 689
    },
    {
      "t": 82705,
      "e": 81863,
      "ty": 6,
      "x": 381,
      "y": 675,
      "ta": "#strategyButton"
    },
    {
      "t": 82747,
      "e": 81905,
      "ty": 41,
      "x": 19882,
      "y": 19786,
      "ta": "#strategyButton"
    },
    {
      "t": 82798,
      "e": 81956,
      "ty": 2,
      "x": 375,
      "y": 665
    },
    {
      "t": 82811,
      "e": 81969,
      "ty": 3,
      "x": 375,
      "y": 665,
      "ta": "#strategyButton"
    },
    {
      "t": 82812,
      "e": 81970,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You can determine which shifts occur at 12 by seeing which points on the line coming out of 12 towards the right. Breaks that occur at 12pm are points on the horizontal line above 12pm."
    },
    {
      "t": 82813,
      "e": 81971,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 82813,
      "e": 81971,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 82890,
      "e": 82048,
      "ty": 4,
      "x": 19882,
      "y": 19786,
      "ta": "#strategyButton"
    },
    {
      "t": 82898,
      "e": 82056,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 82900,
      "e": 82058,
      "ty": 5,
      "x": 375,
      "y": 665,
      "ta": "#strategyButton"
    },
    {
      "t": 82905,
      "e": 82063,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 83903,
      "e": 83061,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 84597,
      "e": 83755,
      "ty": 2,
      "x": 376,
      "y": 665
    },
    {
      "t": 84697,
      "e": 83855,
      "ty": 2,
      "x": 405,
      "y": 635
    },
    {
      "t": 84747,
      "e": 83905,
      "ty": 41,
      "x": 15462,
      "y": 33515,
      "ta": "html > body"
    },
    {
      "t": 84798,
      "e": 83956,
      "ty": 2,
      "x": 533,
      "y": 586
    },
    {
      "t": 84893,
      "e": 84051,
      "ty": 6,
      "x": 852,
      "y": 568,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 84897,
      "e": 84055,
      "ty": 2,
      "x": 852,
      "y": 568
    },
    {
      "t": 84997,
      "e": 84155,
      "ty": 2,
      "x": 952,
      "y": 564
    },
    {
      "t": 84998,
      "e": 84156,
      "ty": 41,
      "x": 31145,
      "y": 31207,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 85162,
      "e": 84320,
      "ty": 3,
      "x": 952,
      "y": 564,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 85163,
      "e": 84321,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 85258,
      "e": 84416,
      "ty": 4,
      "x": 31145,
      "y": 31207,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 85258,
      "e": 84416,
      "ty": 5,
      "x": 952,
      "y": 564,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 85814,
      "e": 84972,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "97"
    },
    {
      "t": 85814,
      "e": 84972,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 85894,
      "e": 85052,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "1"
    },
    {
      "t": 85943,
      "e": 85101,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "105"
    },
    {
      "t": 85943,
      "e": 85101,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 85997,
      "e": 85155,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "19"
    },
    {
      "t": 86476,
      "e": 85634,
      "ty": 7,
      "x": 880,
      "y": 575,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 86498,
      "e": 85656,
      "ty": 2,
      "x": 873,
      "y": 585
    },
    {
      "t": 86498,
      "e": 85656,
      "ty": 41,
      "x": 14058,
      "y": 1409,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 86598,
      "e": 85756,
      "ty": 2,
      "x": 869,
      "y": 603
    },
    {
      "t": 86698,
      "e": 85856,
      "ty": 2,
      "x": 871,
      "y": 613
    },
    {
      "t": 86744,
      "e": 85902,
      "ty": 6,
      "x": 872,
      "y": 656,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 86748,
      "e": 85906,
      "ty": 41,
      "x": 13842,
      "y": 28086,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 86798,
      "e": 85956,
      "ty": 2,
      "x": 874,
      "y": 662
    },
    {
      "t": 86890,
      "e": 86048,
      "ty": 3,
      "x": 874,
      "y": 662,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 86891,
      "e": 86049,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "19"
    },
    {
      "t": 86892,
      "e": 86050,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 86893,
      "e": 86051,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 86994,
      "e": 86152,
      "ty": 4,
      "x": 14274,
      "y": 46810,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 86994,
      "e": 86152,
      "ty": 5,
      "x": 874,
      "y": 662,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 86998,
      "e": 86156,
      "ty": 41,
      "x": 14274,
      "y": 46810,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 87574,
      "e": 86732,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 87719,
      "e": 86877,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "85"
    },
    {
      "t": 87719,
      "e": 86877,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 87806,
      "e": 86964,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "83"
    },
    {
      "t": 87806,
      "e": 86964,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 87814,
      "e": 86972,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "US"
    },
    {
      "t": 87894,
      "e": 87052,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "65"
    },
    {
      "t": 87894,
      "e": 87052,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 87934,
      "e": 87092,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "USA"
    },
    {
      "t": 88014,
      "e": 87172,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "USA"
    },
    {
      "t": 88015,
      "e": 87173,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "USA"
    },
    {
      "t": 88562,
      "e": 87720,
      "ty": 7,
      "x": 888,
      "y": 672,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 88578,
      "e": 87720,
      "ty": 6,
      "x": 904,
      "y": 693,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 88598,
      "e": 87740,
      "ty": 2,
      "x": 907,
      "y": 700
    },
    {
      "t": 88698,
      "e": 87840,
      "ty": 2,
      "x": 912,
      "y": 705
    },
    {
      "t": 88746,
      "e": 87888,
      "ty": 7,
      "x": 919,
      "y": 709,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 88747,
      "e": 87889,
      "ty": 41,
      "x": 31372,
      "y": 38833,
      "ta": "html > body"
    },
    {
      "t": 88797,
      "e": 87939,
      "ty": 2,
      "x": 921,
      "y": 710
    },
    {
      "t": 88818,
      "e": 87960,
      "ty": 3,
      "x": 921,
      "y": 710,
      "ta": "html > body"
    },
    {
      "t": 88818,
      "e": 87960,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "USA"
    },
    {
      "t": 88818,
      "e": 87960,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 88913,
      "e": 88055,
      "ty": 4,
      "x": 31441,
      "y": 38888,
      "ta": "html > body"
    },
    {
      "t": 88913,
      "e": 88055,
      "ty": 5,
      "x": 921,
      "y": 710,
      "ta": "html > body"
    },
    {
      "t": 88998,
      "e": 88140,
      "ty": 41,
      "x": 31441,
      "y": 38888,
      "ta": "html > body"
    },
    {
      "t": 89096,
      "e": 88238,
      "ty": 6,
      "x": 922,
      "y": 706,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 89097,
      "e": 88239,
      "ty": 2,
      "x": 922,
      "y": 706
    },
    {
      "t": 89198,
      "e": 88340,
      "ty": 2,
      "x": 928,
      "y": 687
    },
    {
      "t": 89248,
      "e": 88390,
      "ty": 41,
      "x": 16532,
      "y": 21845,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 89428,
      "e": 88570,
      "ty": 7,
      "x": 955,
      "y": 669,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 89446,
      "e": 88588,
      "ty": 6,
      "x": 971,
      "y": 657,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 89496,
      "e": 88638,
      "ty": 7,
      "x": 988,
      "y": 646,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 89498,
      "e": 88640,
      "ty": 2,
      "x": 988,
      "y": 646
    },
    {
      "t": 89498,
      "e": 88640,
      "ty": 41,
      "x": 38931,
      "y": 44394,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 89598,
      "e": 88740,
      "ty": 2,
      "x": 1256,
      "y": 646
    },
    {
      "t": 89698,
      "e": 88840,
      "ty": 2,
      "x": 1239,
      "y": 653
    },
    {
      "t": 89748,
      "e": 88890,
      "ty": 41,
      "x": 41463,
      "y": 36119,
      "ta": "html > body"
    },
    {
      "t": 89797,
      "e": 88939,
      "ty": 2,
      "x": 1201,
      "y": 658
    },
    {
      "t": 89898,
      "e": 89040,
      "ty": 2,
      "x": 1170,
      "y": 648
    },
    {
      "t": 89997,
      "e": 89139,
      "ty": 2,
      "x": 1140,
      "y": 640
    },
    {
      "t": 89997,
      "e": 89139,
      "ty": 41,
      "x": 38983,
      "y": 35011,
      "ta": "html > body"
    },
    {
      "t": 90097,
      "e": 89239,
      "ty": 2,
      "x": 1129,
      "y": 640
    },
    {
      "t": 90197,
      "e": 89339,
      "ty": 2,
      "x": 1126,
      "y": 652
    },
    {
      "t": 90248,
      "e": 89390,
      "ty": 41,
      "x": 38019,
      "y": 36008,
      "ta": "html > body"
    },
    {
      "t": 90262,
      "e": 89404,
      "ty": 6,
      "x": 1109,
      "y": 659,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 90298,
      "e": 89440,
      "ty": 2,
      "x": 1106,
      "y": 659
    },
    {
      "t": 90398,
      "e": 89540,
      "ty": 2,
      "x": 1102,
      "y": 659
    },
    {
      "t": 90419,
      "e": 89561,
      "ty": 3,
      "x": 1102,
      "y": 659,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 90498,
      "e": 89640,
      "ty": 41,
      "x": 63588,
      "y": 37448,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 90506,
      "e": 89648,
      "ty": 4,
      "x": 63588,
      "y": 37448,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 90507,
      "e": 89649,
      "ty": 5,
      "x": 1102,
      "y": 659,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 90698,
      "e": 89840,
      "ty": 2,
      "x": 1102,
      "y": 662
    },
    {
      "t": 90730,
      "e": 89872,
      "ty": 7,
      "x": 1096,
      "y": 668,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 90748,
      "e": 89890,
      "ty": 41,
      "x": 60776,
      "y": 63420,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 90797,
      "e": 89939,
      "ty": 6,
      "x": 1016,
      "y": 683,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 90798,
      "e": 89940,
      "ty": 2,
      "x": 1016,
      "y": 683
    },
    {
      "t": 90897,
      "e": 90039,
      "ty": 2,
      "x": 957,
      "y": 684
    },
    {
      "t": 90998,
      "e": 90140,
      "ty": 41,
      "x": 31479,
      "y": 15887,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 91050,
      "e": 90192,
      "ty": 3,
      "x": 957,
      "y": 684,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 91051,
      "e": 90193,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 91123,
      "e": 90265,
      "ty": 4,
      "x": 31479,
      "y": 15887,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 91124,
      "e": 90266,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 91126,
      "e": 90268,
      "ty": 5,
      "x": 957,
      "y": 684,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 91126,
      "e": 90268,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 91497,
      "e": 90639,
      "ty": 2,
      "x": 958,
      "y": 683
    },
    {
      "t": 91497,
      "e": 90639,
      "ty": 41,
      "x": 32715,
      "y": 37393,
      "ta": "html > body"
    },
    {
      "t": 91597,
      "e": 90739,
      "ty": 2,
      "x": 1020,
      "y": 668
    },
    {
      "t": 91698,
      "e": 90840,
      "ty": 2,
      "x": 1045,
      "y": 654
    },
    {
      "t": 91747,
      "e": 90889,
      "ty": 41,
      "x": 34506,
      "y": 36562,
      "ta": "html > body"
    },
    {
      "t": 91796,
      "e": 90938,
      "ty": 2,
      "x": 1009,
      "y": 668
    },
    {
      "t": 91998,
      "e": 91140,
      "ty": 41,
      "x": 34472,
      "y": 36562,
      "ta": "html > body"
    },
    {
      "t": 92142,
      "e": 91284,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 92597,
      "e": 91739,
      "ty": 2,
      "x": 1009,
      "y": 667
    },
    {
      "t": 92697,
      "e": 91839,
      "ty": 2,
      "x": 1017,
      "y": 597
    },
    {
      "t": 92747,
      "e": 91889,
      "ty": 41,
      "x": 52111,
      "y": 2340,
      "ta": "#jspsych-survey-multi-choice-option-1-0"
    },
    {
      "t": 92797,
      "e": 91939,
      "ty": 2,
      "x": 1045,
      "y": 264
    },
    {
      "t": 92897,
      "e": 92039,
      "ty": 2,
      "x": 984,
      "y": 119
    },
    {
      "t": 92997,
      "e": 92139,
      "ty": 2,
      "x": 959,
      "y": 151
    },
    {
      "t": 92998,
      "e": 92140,
      "ty": 41,
      "x": 32750,
      "y": 7921,
      "ta": "html > body"
    },
    {
      "t": 93097,
      "e": 92239,
      "ty": 2,
      "x": 932,
      "y": 207
    },
    {
      "t": 93197,
      "e": 92339,
      "ty": 2,
      "x": 928,
      "y": 217
    },
    {
      "t": 93247,
      "e": 92389,
      "ty": 41,
      "x": 24818,
      "y": 17005,
      "ta": "#jspsych-survey-multi-choice-0"
    },
    {
      "t": 93297,
      "e": 92439,
      "ty": 2,
      "x": 916,
      "y": 229
    },
    {
      "t": 93393,
      "e": 92535,
      "ty": 3,
      "x": 896,
      "y": 237,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 93397,
      "e": 92539,
      "ty": 2,
      "x": 896,
      "y": 237
    },
    {
      "t": 93489,
      "e": 92631,
      "ty": 4,
      "x": 60250,
      "y": 26214,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 93490,
      "e": 92632,
      "ty": 5,
      "x": 895,
      "y": 237,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 93490,
      "e": 92632,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 93490,
      "e": 92632,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf",
      "v": "English"
    },
    {
      "t": 93497,
      "e": 92639,
      "ty": 2,
      "x": 895,
      "y": 237
    },
    {
      "t": 93497,
      "e": 92639,
      "ty": 41,
      "x": 60250,
      "y": 26214,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 93697,
      "e": 92839,
      "ty": 2,
      "x": 892,
      "y": 237
    },
    {
      "t": 93747,
      "e": 92889,
      "ty": 41,
      "x": 54518,
      "y": 42597,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 93797,
      "e": 92939,
      "ty": 2,
      "x": 887,
      "y": 257
    },
    {
      "t": 93897,
      "e": 93039,
      "ty": 2,
      "x": 921,
      "y": 368
    },
    {
      "t": 93997,
      "e": 93139,
      "ty": 2,
      "x": 907,
      "y": 425
    },
    {
      "t": 93998,
      "e": 93140,
      "ty": 41,
      "x": 20309,
      "y": 56172,
      "ta": "#jspsych-survey-multi-choice-option-1-0"
    },
    {
      "t": 94097,
      "e": 93239,
      "ty": 2,
      "x": 890,
      "y": 446
    },
    {
      "t": 94247,
      "e": 93389,
      "ty": 41,
      "x": 53179,
      "y": 42597,
      "ta": "#jspsych-survey-multi-choice-option-1-1 > label"
    },
    {
      "t": 94296,
      "e": 93438,
      "ty": 2,
      "x": 880,
      "y": 445
    },
    {
      "t": 94333,
      "e": 93475,
      "ty": 6,
      "x": 831,
      "y": 415,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 94349,
      "e": 93491,
      "ty": 7,
      "x": 817,
      "y": 408,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 94397,
      "e": 93539,
      "ty": 2,
      "x": 813,
      "y": 408
    },
    {
      "t": 94497,
      "e": 93639,
      "ty": 2,
      "x": 798,
      "y": 448
    },
    {
      "t": 94498,
      "e": 93639,
      "ty": 41,
      "x": 27205,
      "y": 24374,
      "ta": "html > body"
    },
    {
      "t": 94597,
      "e": 93738,
      "ty": 2,
      "x": 796,
      "y": 507
    },
    {
      "t": 94697,
      "e": 93838,
      "ty": 2,
      "x": 831,
      "y": 566
    },
    {
      "t": 94748,
      "e": 93889,
      "ty": 41,
      "x": 7731,
      "y": 4681,
      "ta": "#jspsych-survey-multi-choice-option-1-6"
    },
    {
      "t": 94797,
      "e": 93938,
      "ty": 2,
      "x": 868,
      "y": 558
    },
    {
      "t": 94897,
      "e": 94038,
      "ty": 2,
      "x": 891,
      "y": 506
    },
    {
      "t": 94997,
      "e": 94138,
      "ty": 2,
      "x": 891,
      "y": 495
    },
    {
      "t": 94997,
      "e": 94138,
      "ty": 41,
      "x": 62449,
      "y": 19660,
      "ta": "#jspsych-survey-multi-choice-option-1-3 > label"
    },
    {
      "t": 95097,
      "e": 94238,
      "ty": 2,
      "x": 885,
      "y": 480
    },
    {
      "t": 95197,
      "e": 94338,
      "ty": 2,
      "x": 875,
      "y": 469
    },
    {
      "t": 95247,
      "e": 94388,
      "ty": 41,
      "x": 52404,
      "y": 9830,
      "ta": "#jspsych-survey-multi-choice-option-1-2 > label"
    },
    {
      "t": 95297,
      "e": 94438,
      "ty": 2,
      "x": 869,
      "y": 456
    },
    {
      "t": 95397,
      "e": 94538,
      "ty": 2,
      "x": 867,
      "y": 449
    },
    {
      "t": 95483,
      "e": 94624,
      "ty": 3,
      "x": 867,
      "y": 449,
      "ta": "#jspsych-survey-multi-choice-option-1-1 > label"
    },
    {
      "t": 95484,
      "e": 94625,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 95497,
      "e": 94638,
      "ty": 41,
      "x": 36405,
      "y": 52428,
      "ta": "#jspsych-survey-multi-choice-option-1-1 > label"
    },
    {
      "t": 95569,
      "e": 94710,
      "ty": 4,
      "x": 36405,
      "y": 52428,
      "ta": "#jspsych-survey-multi-choice-option-1-1 > label"
    },
    {
      "t": 95569,
      "e": 94710,
      "ty": 5,
      "x": 867,
      "y": 449,
      "ta": "#jspsych-survey-multi-choice-option-1-1 > label"
    },
    {
      "t": 95570,
      "e": 94711,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 95570,
      "e": 94711,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf",
      "v": "Second"
    },
    {
      "t": 95745,
      "e": 94886,
      "ty": 41,
      "x": 11528,
      "y": 4681,
      "ta": "#jspsych-survey-multi-choice-option-1-2"
    },
    {
      "t": 95796,
      "e": 94937,
      "ty": 2,
      "x": 874,
      "y": 463
    },
    {
      "t": 95895,
      "e": 95036,
      "ty": 2,
      "x": 907,
      "y": 521
    },
    {
      "t": 95995,
      "e": 95136,
      "ty": 2,
      "x": 925,
      "y": 641
    },
    {
      "t": 95995,
      "e": 95136,
      "ty": 41,
      "x": 24581,
      "y": 60853,
      "ta": "#jspsych-survey-multi-choice-2 > p"
    },
    {
      "t": 96095,
      "e": 95236,
      "ty": 2,
      "x": 938,
      "y": 692
    },
    {
      "t": 96195,
      "e": 95336,
      "ty": 2,
      "x": 938,
      "y": 693
    },
    {
      "t": 96245,
      "e": 95386,
      "ty": 41,
      "x": 29375,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 96595,
      "e": 95736,
      "ty": 2,
      "x": 929,
      "y": 696
    },
    {
      "t": 96695,
      "e": 95836,
      "ty": 2,
      "x": 907,
      "y": 699
    },
    {
      "t": 96746,
      "e": 95887,
      "ty": 41,
      "x": 20808,
      "y": 19660,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 96795,
      "e": 95936,
      "ty": 2,
      "x": 900,
      "y": 701
    },
    {
      "t": 96895,
      "e": 96036,
      "ty": 2,
      "x": 886,
      "y": 702
    },
    {
      "t": 96995,
      "e": 96136,
      "ty": 2,
      "x": 877,
      "y": 702
    },
    {
      "t": 96995,
      "e": 96136,
      "ty": 41,
      "x": 14004,
      "y": 29490,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 97095,
      "e": 96236,
      "ty": 2,
      "x": 869,
      "y": 704
    },
    {
      "t": 97196,
      "e": 96337,
      "ty": 2,
      "x": 868,
      "y": 705
    },
    {
      "t": 97246,
      "e": 96387,
      "ty": 41,
      "x": 11736,
      "y": 39321,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 97295,
      "e": 96436,
      "ty": 2,
      "x": 868,
      "y": 696
    },
    {
      "t": 97395,
      "e": 96536,
      "ty": 2,
      "x": 867,
      "y": 690
    },
    {
      "t": 97495,
      "e": 96636,
      "ty": 2,
      "x": 866,
      "y": 689
    },
    {
      "t": 97495,
      "e": 96636,
      "ty": 41,
      "x": 10579,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-2-1"
    },
    {
      "t": 97695,
      "e": 96836,
      "ty": 2,
      "x": 867,
      "y": 685
    },
    {
      "t": 97745,
      "e": 96886,
      "ty": 41,
      "x": 12774,
      "y": 58981,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 97796,
      "e": 96937,
      "ty": 2,
      "x": 873,
      "y": 680
    },
    {
      "t": 97895,
      "e": 97036,
      "ty": 2,
      "x": 876,
      "y": 677
    },
    {
      "t": 97995,
      "e": 97136,
      "ty": 2,
      "x": 881,
      "y": 676
    },
    {
      "t": 97996,
      "e": 97137,
      "ty": 41,
      "x": 15996,
      "y": 36044,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 98095,
      "e": 97236,
      "ty": 2,
      "x": 892,
      "y": 687
    },
    {
      "t": 98195,
      "e": 97336,
      "ty": 2,
      "x": 903,
      "y": 708
    },
    {
      "t": 98246,
      "e": 97387,
      "ty": 41,
      "x": 20309,
      "y": 4681,
      "ta": "#jspsych-survey-multi-choice-option-2-2"
    },
    {
      "t": 98295,
      "e": 97436,
      "ty": 2,
      "x": 911,
      "y": 734
    },
    {
      "t": 98395,
      "e": 97536,
      "ty": 2,
      "x": 915,
      "y": 750
    },
    {
      "t": 98496,
      "e": 97637,
      "ty": 2,
      "x": 918,
      "y": 754
    },
    {
      "t": 98496,
      "e": 97637,
      "ty": 41,
      "x": 40297,
      "y": 16383,
      "ta": "#jspsych-survey-multi-choice-option-2-3 > label"
    },
    {
      "t": 98595,
      "e": 97736,
      "ty": 2,
      "x": 920,
      "y": 756
    },
    {
      "t": 98696,
      "e": 97837,
      "ty": 2,
      "x": 923,
      "y": 758
    },
    {
      "t": 98746,
      "e": 97887,
      "ty": 41,
      "x": 42383,
      "y": 29490,
      "ta": "#jspsych-survey-multi-choice-option-2-3 > label"
    },
    {
      "t": 98896,
      "e": 98037,
      "ty": 2,
      "x": 928,
      "y": 755
    },
    {
      "t": 98995,
      "e": 98136,
      "ty": 2,
      "x": 938,
      "y": 732
    },
    {
      "t": 98996,
      "e": 98137,
      "ty": 41,
      "x": 29259,
      "y": 36044,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 99095,
      "e": 98236,
      "ty": 2,
      "x": 939,
      "y": 725
    },
    {
      "t": 99196,
      "e": 98337,
      "ty": 2,
      "x": 943,
      "y": 698
    },
    {
      "t": 99246,
      "e": 98387,
      "ty": 41,
      "x": 30635,
      "y": 13107,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 99296,
      "e": 98437,
      "ty": 2,
      "x": 943,
      "y": 697
    },
    {
      "t": 99344,
      "e": 98485,
      "ty": 3,
      "x": 943,
      "y": 697,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 99345,
      "e": 98486,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 99456,
      "e": 98597,
      "ty": 4,
      "x": 30635,
      "y": 13107,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 99456,
      "e": 98597,
      "ty": 5,
      "x": 943,
      "y": 697,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 99458,
      "e": 98599,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 99459,
      "e": 98600,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf",
      "v": "Social Sciences (incl. CogSci)"
    },
    {
      "t": 99595,
      "e": 98736,
      "ty": 2,
      "x": 961,
      "y": 718
    },
    {
      "t": 99695,
      "e": 98836,
      "ty": 2,
      "x": 1009,
      "y": 790
    },
    {
      "t": 99745,
      "e": 98886,
      "ty": 41,
      "x": 46178,
      "y": 60853,
      "ta": "#jspsych-survey-multi-choice-option-2-4"
    },
    {
      "t": 99795,
      "e": 98936,
      "ty": 2,
      "x": 1018,
      "y": 819
    },
    {
      "t": 99896,
      "e": 99037,
      "ty": 2,
      "x": 1021,
      "y": 869
    },
    {
      "t": 99995,
      "e": 99136,
      "ty": 2,
      "x": 1015,
      "y": 897
    },
    {
      "t": 99996,
      "e": 99137,
      "ty": 41,
      "x": 45940,
      "y": 51491,
      "ta": "#jspsych-survey-multi-choice-3 > p"
    },
    {
      "t": 100095,
      "e": 99236,
      "ty": 2,
      "x": 995,
      "y": 906
    },
    {
      "t": 100195,
      "e": 99336,
      "ty": 2,
      "x": 910,
      "y": 926
    },
    {
      "t": 100246,
      "e": 99387,
      "ty": 41,
      "x": 58520,
      "y": 29490,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 100296,
      "e": 99437,
      "ty": 2,
      "x": 872,
      "y": 934
    },
    {
      "t": 100369,
      "e": 99510,
      "ty": 3,
      "x": 872,
      "y": 934,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 100370,
      "e": 99511,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 100463,
      "e": 99604,
      "ty": 4,
      "x": 55243,
      "y": 29490,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 100464,
      "e": 99605,
      "ty": 5,
      "x": 872,
      "y": 934,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 100464,
      "e": 99605,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 100464,
      "e": 99605,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf",
      "v": "Male"
    },
    {
      "t": 100495,
      "e": 99636,
      "ty": 41,
      "x": 55243,
      "y": 29490,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 100595,
      "e": 99736,
      "ty": 2,
      "x": 901,
      "y": 978
    },
    {
      "t": 100696,
      "e": 99837,
      "ty": 2,
      "x": 903,
      "y": 981
    },
    {
      "t": 100746,
      "e": 99887,
      "ty": 41,
      "x": 19360,
      "y": 9362,
      "ta": "#jspsych-survey-multi-choice-option-3-2"
    },
    {
      "t": 100795,
      "e": 99936,
      "ty": 2,
      "x": 904,
      "y": 982
    },
    {
      "t": 100896,
      "e": 100037,
      "ty": 2,
      "x": 906,
      "y": 985
    },
    {
      "t": 100996,
      "e": 100137,
      "ty": 2,
      "x": 910,
      "y": 985
    },
    {
      "t": 100996,
      "e": 100137,
      "ty": 41,
      "x": 21021,
      "y": 18724,
      "ta": "#jspsych-survey-multi-choice-option-3-2"
    },
    {
      "t": 101096,
      "e": 100237,
      "ty": 2,
      "x": 912,
      "y": 985
    },
    {
      "t": 101246,
      "e": 100387,
      "ty": 41,
      "x": 21971,
      "y": 42129,
      "ta": "#jspsych-survey-multi-choice-option-3-2"
    },
    {
      "t": 101287,
      "e": 100428,
      "ty": 6,
      "x": 914,
      "y": 1005,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 101295,
      "e": 100436,
      "ty": 2,
      "x": 914,
      "y": 1005
    },
    {
      "t": 101395,
      "e": 100536,
      "ty": 2,
      "x": 915,
      "y": 1012
    },
    {
      "t": 101465,
      "e": 100606,
      "ty": 3,
      "x": 915,
      "y": 1012,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 101465,
      "e": 100606,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 101466,
      "e": 100607,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 101495,
      "e": 100636,
      "ty": 41,
      "x": 44106,
      "y": 13901,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 101559,
      "e": 100700,
      "ty": 4,
      "x": 44106,
      "y": 13901,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 101559,
      "e": 100700,
      "ty": 5,
      "x": 915,
      "y": 1012,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 101562,
      "e": 100703,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 101563,
      "e": 100707,
      "ty": 13,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 101564,
      "e": 100708,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 102891,
      "e": 102035,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 107296,
      "e": 105707,
      "ty": 2,
      "x": 915,
      "y": 1013
    },
    {
      "t": 107496,
      "e": 105907,
      "ty": 41,
      "x": 30578,
      "y": 61401,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 108195,
      "e": 106606,
      "ty": 2,
      "x": 914,
      "y": 1013
    },
    {
      "t": 108246,
      "e": 106657,
      "ty": 41,
      "x": 30479,
      "y": 61332,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 108296,
      "e": 106707,
      "ty": 2,
      "x": 926,
      "y": 1027
    },
    {
      "t": 108396,
      "e": 106807,
      "ty": 2,
      "x": 980,
      "y": 1054
    },
    {
      "t": 108495,
      "e": 106906,
      "ty": 2,
      "x": 1014,
      "y": 1061
    },
    {
      "t": 108496,
      "e": 106907,
      "ty": 41,
      "x": 35448,
      "y": 64725,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 108596,
      "e": 107007,
      "ty": 2,
      "x": 1076,
      "y": 1065
    },
    {
      "t": 108696,
      "e": 107107,
      "ty": 2,
      "x": 1082,
      "y": 1067
    },
    {
      "t": 108746,
      "e": 107157,
      "ty": 41,
      "x": 38794,
      "y": 65210,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 108795,
      "e": 107206,
      "ty": 2,
      "x": 1076,
      "y": 1070
    },
    {
      "t": 108895,
      "e": 107306,
      "ty": 2,
      "x": 1067,
      "y": 1075
    },
    {
      "t": 108996,
      "e": 107407,
      "ty": 2,
      "x": 1059,
      "y": 1078
    },
    {
      "t": 108996,
      "e": 107407,
      "ty": 41,
      "x": 36194,
      "y": 59275,
      "ta": "> div.masterdiv"
    },
    {
      "t": 109096,
      "e": 107507,
      "ty": 2,
      "x": 1033,
      "y": 1082
    },
    {
      "t": 109110,
      "e": 107521,
      "ty": 6,
      "x": 1022,
      "y": 1082,
      "ta": "#start"
    },
    {
      "t": 109196,
      "e": 107607,
      "ty": 2,
      "x": 1002,
      "y": 1082
    },
    {
      "t": 109246,
      "e": 107657,
      "ty": 41,
      "x": 48878,
      "y": 17949,
      "ta": "#start"
    },
    {
      "t": 109296,
      "e": 107707,
      "ty": 2,
      "x": 998,
      "y": 1082
    },
    {
      "t": 109496,
      "e": 107907,
      "ty": 41,
      "x": 48332,
      "y": 17949,
      "ta": "#start"
    },
    {
      "t": 109996,
      "e": 108407,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 110873,
      "e": 109284,
      "ty": 3,
      "x": 998,
      "y": 1082,
      "ta": "#start"
    },
    {
      "t": 110874,
      "e": 109285,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 111104,
      "e": 109515,
      "ty": 4,
      "x": 48332,
      "y": 17949,
      "ta": "#start"
    },
    {
      "t": 111106,
      "e": 109517,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 111106,
      "e": 109517,
      "ty": 5,
      "x": 998,
      "y": 1082,
      "ta": "#start"
    },
    {
      "t": 111106,
      "e": 109517,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 112154,
      "e": 110565,
      "ty": 38,
      "x": 8,
      "y": 0
    },
    {
      "t": 112907,
      "e": 111318,
      "ty": 2,
      "x": 995,
      "y": 1082
    },
    {
      "t": 112907,
      "e": 111318,
      "ty": 41,
      "x": 33936,
      "y": 32880,
      "ta": "#jspsych-data-display"
    },
    {
      "t": 113295,
      "e": 111706,
      "ty": 2,
      "x": 995,
      "y": 1080
    },
    {
      "t": 113395,
      "e": 111806,
      "ty": 2,
      "x": 1000,
      "y": 1073
    },
    {
      "t": 113496,
      "e": 111907,
      "ty": 2,
      "x": 1003,
      "y": 1068
    },
    {
      "t": 113496,
      "e": 111907,
      "ty": 41,
      "x": 34200,
      "y": 32877,
      "ta": "#jspsych-data-display"
    },
    {
      "t": 113520,
      "e": 111931,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":56},{\"id\":57},{\"id\":58},{\"id\":59},{\"id\":60},{\"id\":61},{\"id\":62},{\"id\":63},{\"id\":64},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":72},{\"id\":73},{\"id\":74},{\"id\":75},{\"id\":76},{\"id\":77},{\"id\":78},{\"id\":79},{\"id\":80},{\"id\":81},{\"id\":82},{\"id\":83},{\"id\":84},{\"id\":85},{\"id\":86},{\"id\":87},{\"id\":88},{\"id\":89},{\"id\":90},{\"id\":91},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":96},{\"id\":97},{\"id\":98},{\"id\":99},{\"id\":100},{\"id\":101},{\"id\":102},{\"id\":103},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":109},{\"id\":110},{\"id\":111},{\"id\":112},{\"id\":113},{\"id\":114},{\"id\":115},{\"id\":116},{\"id\":117},{\"id\":118},{\"id\":119},{\"id\":120},{\"id\":121},{\"id\":122},{\"id\":123},{\"id\":124},{\"id\":125},{\"id\":126},{\"id\":127},{\"id\":128},{\"id\":129},{\"id\":130},{\"id\":131},{\"id\":132},{\"id\":133},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":141},{\"id\":142},{\"id\":143},{\"id\":144},{\"id\":145},{\"id\":146},{\"id\":147},{\"id\":148},{\"id\":149},{\"id\":150},{\"id\":151},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":155},{\"id\":156},{\"id\":157},{\"id\":158},{\"id\":159},{\"id\":160},{\"id\":161},{\"id\":162},{\"id\":163},{\"id\":164},{\"id\":165},{\"id\":166},{\"id\":167},{\"id\":168},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":172},{\"id\":173},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":178},{\"id\":179},{\"id\":180},{\"id\":181},{\"id\":182},{\"id\":183},{\"id\":184},{\"id\":185},{\"id\":186},{\"id\":187},{\"id\":188},{\"id\":189},{\"id\":190},{\"id\":191},{\"id\":192},{\"id\":193},{\"id\":194},{\"id\":195},{\"id\":196},{\"id\":197},{\"id\":198},{\"id\":199},{\"id\":200},{\"id\":201},{\"id\":202},{\"id\":203},{\"id\":204},{\"id\":205},{\"id\":206},{\"id\":207},{\"id\":208},{\"id\":209},{\"id\":210},{\"id\":211},{\"id\":212},{\"id\":213},{\"id\":214},{\"id\":215},{\"id\":216},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":220},{\"id\":221},{\"id\":222},{\"id\":223},{\"id\":224},{\"id\":225},{\"id\":226},{\"id\":227},{\"id\":228},{\"id\":229},{\"id\":230},{\"id\":231},{\"id\":232},{\"id\":233},{\"id\":234},{\"id\":235},{\"id\":236},{\"id\":237},{\"id\":238},{\"id\":239},{\"id\":240},{\"id\":241},{\"id\":242},{\"id\":243},{\"id\":244},{\"id\":245},{\"id\":246},{\"id\":247},{\"id\":248},{\"id\":249},{\"id\":250},{\"id\":251},{\"id\":252},{\"id\":253},{\"id\":254},{\"id\":255},{\"id\":256},{\"id\":257},{\"id\":258},{\"id\":259},{\"id\":260},{\"id\":261},{\"id\":262},{\"id\":263},{\"id\":264},{\"id\":265},{\"id\":266},{\"id\":267},{\"id\":268},{\"id\":269},{\"id\":270},{\"id\":271},{\"id\":272},{\"id\":273},{\"id\":274},{\"id\":275},{\"id\":276},{\"id\":277},{\"id\":278},{\"id\":279},{\"id\":280},{\"id\":281},{\"id\":282},{\"id\":283},{\"id\":284},{\"id\":285},{\"id\":286},{\"id\":287},{\"id\":288},{\"id\":289},{\"id\":290},{\"id\":291},{\"id\":292},{\"id\":293},{\"id\":294},{\"id\":295},{\"id\":296},{\"id\":297},{\"id\":298},{\"id\":299},{\"id\":300},{\"id\":301},{\"id\":302},{\"id\":303},{\"id\":304},{\"id\":305},{\"id\":306},{\"id\":307},{\"id\":308},{\"id\":309},{\"id\":310},{\"id\":311},{\"id\":312},{\"id\":313},{\"id\":314},{\"id\":315},{\"id\":316},{\"id\":317},{\"id\":318},{\"id\":319},{\"id\":320},{\"id\":321},{\"id\":322},{\"id\":323},{\"id\":324},{\"id\":325},{\"id\":326},{\"id\":327},{\"id\":328},{\"id\":329},{\"id\":330},{\"id\":331},{\"id\":332},{\"id\":333},{\"id\":334},{\"id\":335},{\"id\":336},{\"id\":337},{\"id\":338},{\"id\":339},{\"id\":340},{\"id\":341},{\"id\":342},{\"id\":343},{\"id\":344},{\"id\":345},{\"id\":346},{\"id\":347},{\"id\":348},{\"id\":349},{\"id\":350},{\"id\":351},{\"id\":352},{\"id\":353},{\"id\":354},{\"id\":355},{\"id\":356},{\"id\":357},{\"id\":358},{\"id\":359},{\"id\":360},{\"id\":361},{\"id\":362},{\"id\":363},{\"id\":364},{\"id\":365},{\"id\":366},{\"id\":367},{\"id\":368},{\"id\":369},{\"id\":370},{\"id\":371},{\"id\":372},{\"id\":373},{\"id\":374},{\"id\":375},{\"id\":376},{\"id\":377},{\"id\":378},{\"id\":379},{\"id\":380},{\"id\":381},{\"id\":382},{\"id\":383},{\"id\":384},{\"id\":385},{\"id\":386},{\"id\":387},{\"id\":388},{\"id\":389},{\"id\":390},{\"id\":391},{\"id\":392},{\"id\":393},{\"id\":394},{\"id\":395},{\"id\":396},{\"id\":397},{\"id\":398},{\"id\":399},{\"id\":400},{\"id\":401},{\"id\":402},{\"id\":403},{\"id\":404},{\"id\":405},{\"id\":406},{\"id\":407},{\"id\":408},{\"id\":409},{\"id\":410},{\"id\":411},{\"id\":412},{\"id\":413},{\"id\":414},{\"id\":415},{\"id\":416},{\"id\":417},{\"id\":418},{\"id\":419},{\"id\":420},{\"id\":421},{\"id\":422},{\"id\":423},{\"id\":424},{\"id\":425},{\"id\":426},{\"id\":427},{\"id\":428},{\"id\":429},{\"id\":430},{\"id\":431},{\"id\":432},{\"id\":433},{\"id\":434},{\"id\":435},{\"id\":436},{\"id\":437},{\"id\":438},{\"id\":439},{\"id\":440},{\"id\":441},{\"id\":442},{\"id\":443},{\"id\":444},{\"id\":445},{\"id\":446},{\"id\":447},{\"id\":448},{\"id\":449},{\"id\":450},{\"id\":451},{\"id\":452},{\"id\":453},{\"id\":454},{\"id\":455},{\"id\":456},{\"id\":457},{\"id\":458},{\"id\":459},{\"id\":460},{\"id\":461},{\"id\":462},{\"id\":463},{\"id\":464},{\"id\":465},{\"id\":466},{\"id\":467},{\"id\":468},{\"id\":469},{\"id\":470},{\"id\":471},{\"id\":472},{\"id\":473},{\"id\":474},{\"id\":475},{\"id\":476},{\"id\":477},{\"id\":478},{\"id\":479},{\"id\":480},{\"id\":481},{\"id\":482},{\"id\":483},{\"id\":484},{\"id\":485},{\"id\":486},{\"id\":487},{\"id\":488},{\"id\":489},{\"id\":490},{\"id\":491},{\"id\":492},{\"id\":493},{\"id\":494},{\"id\":495},{\"id\":496},{\"id\":497},{\"id\":498},{\"id\":499},{\"id\":500},{\"id\":501},{\"id\":502},{\"id\":503},{\"id\":504},{\"id\":505},{\"id\":506},{\"id\":507},{\"id\":508},{\"id\":509},{\"id\":510},{\"id\":511},{\"id\":512},{\"id\":513},{\"id\":514},{\"id\":515},{\"id\":516},{\"id\":517},{\"id\":518},{\"id\":519},{\"id\":520},{\"id\":521},{\"id\":522},{\"id\":523},{\"id\":524},{\"id\":525},{\"id\":526},{\"id\":527},{\"id\":528},{\"id\":529},{\"id\":530},{\"id\":531},{\"id\":532},{\"id\":533},{\"id\":534},{\"id\":535},{\"id\":536},{\"id\":537},{\"id\":538},{\"id\":539},{\"id\":540},{\"id\":541},{\"id\":542},{\"id\":543},{\"id\":544},{\"id\":545},{\"id\":546},{\"id\":547},{\"id\":548},{\"id\":549},{\"id\":550},{\"id\":551},{\"id\":552},{\"id\":553},{\"id\":554},{\"id\":555},{\"id\":556},{\"id\":557},{\"id\":558},{\"id\":559},{\"id\":560},{\"id\":561},{\"id\":562},{\"id\":563},{\"id\":564},{\"id\":565},{\"id\":566},{\"id\":567},{\"id\":568},{\"id\":569},{\"id\":570},{\"id\":571},{\"id\":572},{\"id\":573},{\"id\":574},{\"id\":575},{\"id\":576},{\"id\":577},{\"id\":578},{\"id\":579},{\"id\":580},{\"id\":581},{\"id\":582},{\"id\":583},{\"id\":584},{\"id\":585},{\"id\":586},{\"id\":587},{\"id\":588},{\"id\":589},{\"id\":590},{\"id\":591},{\"id\":592},{\"id\":593},{\"id\":594},{\"id\":595},{\"id\":596},{\"id\":597},{\"id\":598},{\"id\":599},{\"id\":600},{\"id\":601},{\"id\":602},{\"id\":603},{\"id\":604},{\"id\":605},{\"id\":606},{\"id\":607},{\"id\":608},{\"id\":609},{\"id\":610},{\"id\":611},{\"id\":612},{\"id\":613},{\"id\":614},{\"id\":615},{\"id\":616},{\"id\":617},{\"id\":618},{\"id\":619},{\"id\":620},{\"id\":621},{\"id\":622},{\"id\":623},{\"id\":624},{\"id\":625},{\"id\":626},{\"id\":627},{\"id\":628},{\"id\":629},{\"id\":630},{\"id\":631},{\"id\":632},{\"id\":633},{\"id\":634},{\"id\":635},{\"id\":636},{\"id\":637},{\"id\":638},{\"id\":639},{\"id\":640},{\"id\":641},{\"id\":642},{\"id\":643},{\"id\":644},{\"id\":645},{\"id\":646},{\"id\":647},{\"id\":648},{\"id\":649},{\"id\":650},{\"id\":651},{\"id\":652},{\"id\":653},{\"id\":654},{\"id\":655},{\"id\":656},{\"id\":657},{\"id\":658},{\"id\":659},{\"id\":660},{\"id\":661},{\"id\":662},{\"id\":663},{\"id\":664},{\"id\":665},{\"id\":666},{\"id\":667},{\"id\":668},{\"id\":669},{\"id\":670},{\"id\":671},{\"id\":672},{\"id\":673},{\"id\":674},{\"id\":675},{\"id\":676},{\"id\":677},{\"id\":678},{\"id\":679},{\"id\":680},{\"id\":681},{\"id\":682},{\"id\":683},{\"id\":684},{\"id\":685},{\"id\":686},{\"id\":687},{\"id\":688},{\"id\":689},{\"id\":690},{\"id\":691},{\"id\":692},{\"id\":693},{\"id\":694},{\"id\":695},{\"id\":696},{\"id\":697},{\"id\":698},{\"id\":699},{\"id\":700},{\"id\":701},{\"id\":702},{\"id\":703},{\"id\":704},{\"id\":705},{\"id\":706},{\"id\":707},{\"id\":708},{\"id\":709},{\"id\":710},{\"id\":711},{\"id\":712},{\"id\":713},{\"id\":714},{\"id\":715},{\"id\":716},{\"id\":717},{\"id\":718},{\"id\":719},{\"id\":720},{\"id\":721},{\"id\":722},{\"id\":723},{\"id\":724},{\"id\":725},{\"id\":726},{\"id\":727},{\"id\":728},{\"id\":729},{\"id\":730},{\"id\":731},{\"id\":732},{\"id\":733},{\"id\":734},{\"id\":735},{\"id\":736},{\"id\":737},{\"id\":738},{\"id\":739},{\"id\":740},{\"id\":741},{\"id\":742},{\"id\":743},{\"id\":744},{\"id\":745},{\"id\":746},{\"id\":747},{\"id\":748},{\"id\":749},{\"id\":750},{\"id\":751},{\"id\":752},{\"id\":753},{\"id\":754},{\"id\":755},{\"id\":756},{\"id\":757},{\"id\":758},{\"id\":759},{\"id\":760},{\"id\":761},{\"id\":762},{\"id\":763},{\"id\":764},{\"id\":765},{\"id\":766},{\"id\":767},{\"id\":768},{\"id\":769},{\"id\":770},{\"id\":771},{\"id\":772},{\"id\":773},{\"id\":774},{\"id\":775},{\"id\":776},{\"id\":777},{\"id\":778},{\"id\":779},{\"id\":780},{\"id\":781},{\"id\":782},{\"id\":783},{\"id\":784},{\"id\":785},{\"id\":786},{\"id\":787},{\"id\":788},{\"id\":789},{\"id\":790},{\"id\":791},{\"id\":792},{\"id\":793},{\"id\":794},{\"id\":795},{\"id\":796},{\"id\":797},{\"id\":798},{\"id\":799},{\"id\":800},{\"id\":801},{\"id\":802},{\"id\":803},{\"id\":804},{\"id\":805},{\"id\":806},{\"id\":807},{\"id\":808},{\"id\":809},{\"id\":810},{\"id\":811},{\"id\":812},{\"id\":813},{\"id\":814},{\"id\":815},{\"id\":816},{\"id\":817},{\"id\":818},{\"id\":819},{\"id\":820},{\"id\":821},{\"id\":822},{\"id\":823},{\"id\":824},{\"id\":825},{\"id\":826},{\"id\":827},{\"id\":828},{\"id\":829},{\"id\":830},{\"id\":831},{\"id\":832},{\"id\":833},{\"id\":834},{\"id\":835},{\"id\":836},{\"id\":837},{\"id\":838},{\"id\":839},{\"id\":840},{\"id\":841},{\"id\":842},{\"id\":843},{\"id\":844},{\"id\":845},{\"id\":846},{\"id\":847},{\"id\":848},{\"id\":849},{\"id\":850},{\"id\":851},{\"id\":852},{\"id\":853},{\"id\":854},{\"id\":855},{\"id\":856},{\"id\":857},{\"id\":858},{\"id\":859},{\"id\":860},{\"id\":861},{\"id\":862},{\"id\":863},{\"id\":864},{\"id\":865},{\"id\":866},{\"id\":867},{\"id\":868},{\"id\":869},{\"id\":870},{\"id\":871},{\"id\":872},{\"id\":873},{\"id\":874},{\"id\":875},{\"id\":876},{\"id\":877},{\"id\":878},{\"id\":879},{\"id\":880},{\"id\":881},{\"id\":882},{\"id\":883},{\"id\":884},{\"id\":885},{\"id\":886},{\"id\":887},{\"id\":888},{\"id\":889},{\"id\":890},{\"id\":891},{\"id\":892},{\"id\":893},{\"id\":894},{\"id\":895},{\"id\":896},{\"id\":897},{\"id\":898},{\"id\":899},{\"id\":900},{\"id\":901},{\"id\":902},{\"id\":903},{\"id\":904},{\"id\":905},{\"id\":906},{\"id\":907},{\"id\":908},{\"id\":909},{\"id\":910},{\"id\":911},{\"id\":912},{\"id\":913},{\"id\":914},{\"id\":915},{\"id\":916},{\"id\":917},{\"id\":918},{\"id\":919},{\"id\":920},{\"id\":921},{\"id\":922},{\"id\":923},{\"id\":924},{\"id\":925},{\"id\":926},{\"id\":927},{\"id\":928},{\"id\":929},{\"id\":930},{\"id\":931},{\"id\":932},{\"id\":933},{\"id\":934},{\"id\":935},{\"id\":936},{\"id\":937},{\"id\":938},{\"id\":939},{\"id\":940},{\"id\":941},{\"id\":942},{\"id\":943},{\"id\":944},{\"id\":945},{\"id\":946},{\"id\":947},{\"id\":948},{\"id\":949},{\"id\":950},{\"id\":951},{\"id\":952},{\"id\":953},{\"id\":954},{\"id\":955},{\"id\":956},{\"id\":957},{\"id\":958},{\"id\":959},{\"id\":960},{\"id\":961},{\"id\":962},{\"id\":963},{\"id\":964},{\"id\":965},{\"id\":966},{\"id\":967},{\"id\":968},{\"id\":969},{\"id\":970},{\"id\":971},{\"id\":972},{\"id\":973},{\"id\":974},{\"id\":975},{\"id\":976},{\"id\":977},{\"id\":978},{\"id\":979},{\"id\":980},{\"id\":981},{\"id\":982},{\"id\":983},{\"id\":984},{\"id\":985},{\"id\":986},{\"id\":987},{\"id\":988},{\"id\":989},{\"id\":990},{\"id\":991},{\"id\":992},{\"id\":993},{\"id\":994},{\"id\":995},{\"id\":996},{\"id\":997},{\"id\":998},{\"id\":999},{\"id\":1000},{\"id\":1001},{\"id\":1002},{\"id\":1003},{\"id\":1004},{\"id\":1005},{\"id\":1006},{\"id\":1007},{\"id\":1008},{\"id\":1009},{\"id\":1010},{\"id\":1011},{\"id\":1012},{\"id\":1013},{\"id\":1014},{\"id\":1015},{\"id\":1016},{\"id\":1017},{\"id\":1018},{\"id\":1019},{\"id\":1020},{\"id\":1021},{\"id\":1022},{\"id\":1023},{\"id\":1024},{\"id\":1025},{\"id\":1026},{\"id\":1027},{\"id\":1028},{\"id\":1029},{\"id\":1030},{\"id\":1031},{\"id\":1032},{\"id\":1033},{\"id\":1034},{\"id\":1035},{\"id\":1036},{\"id\":1037},{\"id\":1038},{\"id\":1039},{\"id\":1040},{\"id\":1041},{\"id\":1042},{\"id\":1043},{\"id\":1044},{\"id\":1045},{\"id\":1046},{\"id\":1047},{\"id\":1048},{\"id\":1049},{\"id\":1050},{\"id\":1051},{\"id\":1052},{\"id\":1053},{\"id\":1054},{\"id\":1055},{\"id\":1056},{\"id\":1057},{\"id\":1058},{\"id\":1059},{\"id\":1060},{\"id\":1061},{\"id\":1062},{\"id\":1063},{\"id\":1064},{\"id\":1065},{\"id\":1066},{\"id\":1067},{\"id\":1068},{\"id\":1069},{\"id\":1070},{\"id\":1071},{\"id\":1072},{\"id\":1073},{\"id\":1074},{\"id\":1075},{\"id\":1076},{\"id\":1077},{\"id\":1078},{\"id\":1079},{\"id\":1080},{\"id\":1081},{\"id\":1082},{\"id\":1083},{\"id\":1084},{\"id\":1085},{\"id\":1086},{\"id\":1087},{\"id\":1088},{\"id\":1089},{\"id\":1090},{\"id\":1091},{\"id\":1092},{\"id\":1093},{\"id\":1094},{\"id\":1095},{\"id\":1096},{\"id\":1097},{\"id\":1098},{\"id\":1099},{\"id\":1100},{\"id\":1101},{\"id\":1102},{\"id\":1103},{\"id\":1104},{\"id\":1105},{\"id\":1106},{\"id\":1107},{\"id\":1108},{\"id\":1109},{\"id\":1110},{\"id\":1111},{\"id\":1112},{\"id\":1113},{\"id\":1114},{\"id\":1115},{\"id\":1116},{\"id\":1117},{\"id\":1118},{\"id\":1119},{\"id\":1120},{\"id\":1121},{\"id\":1122},{\"id\":1123},{\"id\":1124},{\"id\":1125},{\"id\":1126},{\"id\":1127},{\"id\":1128},{\"id\":1129},{\"id\":1130},{\"id\":1131},{\"id\":1132},{\"id\":1133},{\"id\":1134},{\"id\":1135},{\"id\":1136},{\"id\":1137},{\"id\":1138},{\"id\":1139},{\"id\":1140},{\"id\":1141},{\"id\":1142},{\"id\":1143},{\"id\":1144},{\"id\":1145},{\"id\":1146},{\"id\":1147},{\"id\":1148},{\"id\":1149},{\"id\":1150},{\"id\":1151},{\"id\":1152},{\"id\":1153},{\"id\":1154},{\"id\":1155},{\"id\":1156},{\"id\":1157},{\"id\":1158},{\"id\":1159},{\"id\":1160},{\"id\":1161},{\"id\":1162},{\"id\":1163},{\"id\":1164},{\"id\":1165},{\"id\":1166},{\"id\":1167},{\"id\":1168},{\"id\":1169},{\"id\":1170},{\"id\":1171},{\"id\":1172},{\"id\":1173},{\"id\":1174},{\"id\":1175},{\"id\":1176},{\"id\":1177},{\"id\":1178},{\"id\":1179},{\"id\":1180},{\"id\":1181},{\"id\":1182},{\"id\":1183},{\"id\":1184},{\"id\":1185},{\"id\":1186},{\"id\":1187},{\"id\":1188},{\"id\":1189},{\"id\":1190},{\"id\":1191},{\"id\":1192},{\"id\":1193},{\"id\":1194},{\"id\":1195},{\"id\":1196},{\"id\":1197},{\"id\":1198},{\"id\":1199},{\"id\":1200},{\"id\":1201},{\"id\":1202},{\"id\":1203},{\"id\":1204},{\"id\":1205},{\"id\":1206},{\"id\":1207},{\"id\":1208},{\"id\":1209},{\"id\":1210},{\"id\":1211},{\"id\":1212},{\"id\":1213},{\"id\":1214},{\"id\":1215},{\"id\":1216},{\"id\":1217},{\"id\":1218},{\"id\":1219},{\"id\":1220},{\"id\":1221},{\"id\":1222},{\"id\":1223},{\"id\":1224},{\"id\":1225},{\"id\":1226},{\"id\":1227},{\"id\":1228},{\"id\":1229},{\"id\":1230},{\"id\":1231},{\"id\":1232},{\"id\":1233},{\"id\":1234},{\"id\":1235},{\"id\":1236},{\"id\":1237},{\"id\":1238},{\"id\":1239},{\"id\":1240},{\"id\":1241},{\"id\":1242},{\"id\":1243},{\"id\":1244},{\"id\":1245},{\"id\":1246},{\"id\":1247},{\"id\":1248},{\"id\":1249},{\"id\":1250},{\"id\":1251},{\"id\":1252},{\"id\":1253},{\"id\":1254},{\"id\":1255},{\"id\":1256},{\"id\":1257},{\"id\":1258},{\"id\":1259},{\"id\":1260},{\"id\":1261},{\"id\":1262},{\"id\":1263},{\"id\":1264},{\"id\":1265},{\"id\":1266},{\"id\":1267},{\"id\":1268},{\"id\":1269},{\"id\":1270},{\"id\":1271},{\"id\":1272},{\"id\":1273},{\"id\":1274},{\"id\":1275},{\"id\":1276},{\"id\":1277},{\"id\":1278},{\"id\":1279},{\"id\":1280},{\"id\":1281},{\"id\":1282},{\"id\":1283},{\"id\":1284},{\"id\":1285},{\"id\":1286},{\"id\":1287},{\"id\":1288},{\"id\":1289},{\"id\":1290},{\"id\":1291},{\"id\":1292},{\"id\":1293},{\"id\":1294},{\"id\":1295},{\"id\":1296},{\"id\":1297},{\"id\":1298},{\"id\":1299},{\"id\":1300},{\"id\":1301},{\"id\":1302},{\"id\":1303},{\"id\":1304},{\"id\":1305},{\"id\":1306},{\"id\":1307},{\"id\":1308},{\"id\":1309},{\"id\":1310},{\"id\":1311},{\"id\":1312},{\"id\":1313},{\"id\":1314},{\"id\":1315},{\"id\":1316},{\"id\":1317},{\"id\":1318},{\"id\":1319},{\"id\":1320},{\"id\":1321},{\"id\":1322},{\"id\":1323},{\"id\":1324},{\"id\":1325},{\"id\":1326},{\"id\":1327},{\"id\":1328},{\"id\":1329},{\"id\":1330},{\"id\":1331},{\"id\":1332},{\"id\":1333},{\"id\":1334},{\"id\":1335},{\"id\":1336},{\"id\":1337},{\"id\":1338},{\"id\":1339},{\"id\":1340},{\"id\":1341},{\"id\":1342},{\"id\":1343},{\"id\":1344},{\"id\":1345},{\"id\":1346},{\"id\":1347},{\"id\":1348},{\"id\":1349},{\"id\":1350},{\"id\":1351},{\"id\":1352},{\"id\":1353},{\"id\":1354},{\"id\":1355},{\"id\":1356},{\"id\":1357},{\"id\":1358},{\"id\":1359},{\"id\":1360},{\"id\":1361},{\"id\":1362},{\"id\":1363},{\"id\":1364},{\"id\":1365},{\"id\":1366},{\"id\":1367},{\"id\":1368},{\"id\":1369},{\"id\":1370},{\"id\":1371},{\"id\":1372},{\"id\":1373},{\"id\":1374},{\"id\":1375},{\"id\":1376},{\"id\":1377},{\"id\":1378},{\"id\":1379},{\"id\":1380},{\"id\":1381},{\"id\":1382},{\"id\":1383},{\"id\":1384},{\"id\":1385},{\"id\":1386},{\"id\":1387},{\"id\":1388},{\"id\":1389},{\"id\":1390},{\"id\":1391},{\"id\":1392},{\"id\":1393},{\"id\":1394},{\"id\":1395},{\"id\":1396},{\"id\":1397},{\"id\":1398},{\"id\":1399},{\"id\":1400},{\"id\":1401},{\"id\":1402},{\"id\":1403},{\"id\":1404},{\"id\":1405},{\"id\":1406},{\"id\":1407},{\"id\":1408},{\"id\":1409},{\"id\":1410},{\"id\":1411},{\"id\":1412},{\"id\":1413},{\"id\":1414},{\"id\":1415},{\"id\":1416},{\"id\":1417},{\"id\":1418},{\"id\":1419},{\"id\":1420},{\"id\":1421},{\"id\":1422},{\"id\":1423},{\"id\":1424},{\"id\":1425},{\"id\":1426},{\"id\":1427},{\"id\":1428},{\"id\":1429},{\"id\":1430},{\"id\":1431},{\"id\":1432},{\"id\":1433},{\"id\":1434},{\"id\":1435},{\"id\":1436},{\"id\":1437},{\"id\":1438},{\"id\":1439},{\"id\":1440},{\"id\":1441},{\"id\":1442},{\"id\":1443},{\"id\":1444},{\"id\":1445},{\"id\":1446},{\"id\":1447},{\"id\":1448},{\"id\":1449},{\"id\":1450},{\"id\":1451},{\"id\":1452},{\"id\":1453},{\"id\":1454},{\"id\":1455},{\"id\":1456},{\"id\":1457},{\"id\":1458},{\"id\":1459},{\"id\":1460},{\"id\":1461},{\"id\":1462},{\"id\":1463},{\"id\":1464},{\"id\":1465},{\"id\":1466},{\"id\":1467},{\"id\":1468},{\"id\":1469},{\"id\":1470},{\"id\":1471},{\"id\":1472},{\"id\":1473},{\"id\":1474},{\"id\":1475},{\"id\":1476},{\"id\":1477},{\"id\":1478},{\"id\":1479},{\"id\":1480},{\"id\":1481},{\"id\":1482},{\"id\":1483},{\"id\":1484},{\"id\":1485},{\"id\":1486},{\"id\":1487},{\"id\":1488},{\"id\":1489},{\"id\":1490},{\"id\":1491},{\"id\":1492},{\"id\":1493},{\"id\":1494},{\"id\":1495},{\"id\":1496},{\"id\":1497},{\"id\":1498},{\"id\":1499},{\"id\":1500},{\"id\":1501},{\"id\":1502},{\"id\":1503},{\"id\":1504},{\"id\":1505},{\"id\":1506},{\"id\":1507},{\"id\":1508},{\"id\":1509},{\"id\":1510},{\"id\":1511},{\"id\":1512},{\"id\":1513},{\"id\":1514},{\"id\":1515},{\"id\":1516},{\"id\":1517},{\"id\":1518},{\"id\":1519},{\"id\":1520},{\"id\":1521},{\"id\":1522},{\"id\":1523},{\"id\":1524},{\"id\":1525},{\"id\":1526},{\"id\":1527},{\"id\":1528},{\"id\":1529},{\"id\":1530},{\"id\":1531},{\"id\":1532},{\"id\":1533},{\"id\":1534},{\"id\":1535},{\"id\":1536},{\"id\":1537},{\"id\":1538},{\"id\":1539},{\"id\":1540},{\"id\":1541},{\"id\":1542},{\"id\":1543},{\"id\":1544},{\"id\":1545},{\"id\":1546},{\"id\":1547},{\"id\":1548},{\"id\":1549},{\"id\":1550},{\"id\":1551},{\"id\":1552},{\"id\":1553},{\"id\":1554},{\"id\":1555},{\"id\":1556},{\"id\":1557},{\"id\":1558},{\"id\":1559},{\"id\":1560},{\"id\":1561},{\"id\":1562},{\"id\":1563},{\"id\":1564},{\"id\":1565},{\"id\":1566},{\"id\":1567},{\"id\":1568},{\"id\":1569},{\"id\":1570},{\"id\":1571},{\"id\":1572},{\"id\":1573},{\"id\":1574},{\"id\":1575},{\"id\":1576},{\"id\":1577},{\"id\":1578},{\"id\":1579},{\"id\":1580},{\"id\":1581},{\"id\":1582},{\"id\":1583},{\"id\":1584},{\"id\":1585},{\"id\":1586},{\"id\":1587},{\"id\":1588},{\"id\":1589},{\"id\":1590},{\"id\":1591},{\"id\":1592},{\"id\":1593},{\"id\":1594},{\"id\":1595},{\"id\":1596},{\"id\":1597},{\"id\":1598},{\"id\":1599},{\"id\":1600},{\"id\":1601},{\"id\":1602},{\"id\":1603},{\"id\":1604},{\"id\":1605},{\"id\":1606},{\"id\":1607},{\"id\":1608},{\"id\":1609},{\"id\":1610},{\"id\":1611},{\"id\":1612},{\"id\":1613},{\"id\":1614},{\"id\":1615},{\"id\":1616},{\"id\":1617},{\"id\":1618},{\"id\":1619},{\"id\":1620},{\"id\":1621},{\"id\":1622},{\"id\":1623},{\"id\":1624},{\"id\":1625},{\"id\":1626},{\"id\":1627},{\"id\":1628},{\"id\":1629},{\"id\":1630},{\"id\":1631},{\"id\":1632},{\"id\":1633},{\"id\":1634},{\"id\":1635},{\"id\":1636},{\"id\":1637},{\"id\":1638},{\"id\":1639},{\"id\":1640},{\"id\":1641},{\"id\":1642},{\"id\":1643},{\"id\":1644},{\"id\":1645},{\"id\":1646},{\"id\":1647},{\"id\":1648},{\"id\":1649},{\"id\":1650},{\"id\":1651},{\"id\":1652},{\"id\":1653},{\"id\":1654},{\"id\":1655},{\"id\":1656},{\"id\":1657},{\"id\":1658},{\"id\":1659},{\"id\":1660},{\"id\":1661},{\"id\":1662},{\"id\":1663},{\"id\":1664},{\"id\":1665},{\"id\":1666},{\"id\":1667},{\"id\":1668},{\"id\":1669},{\"id\":1670},{\"id\":1671},{\"id\":1672},{\"id\":1673},{\"id\":1674},{\"id\":1675},{\"id\":1676},{\"id\":1677},{\"id\":1678},{\"id\":1679},{\"id\":1680},{\"id\":1681},{\"id\":1682},{\"id\":1683},{\"id\":1684},{\"id\":1685},{\"id\":1686},{\"id\":1687},{\"id\":1688},{\"id\":1689},{\"id\":1690},{\"id\":1691},{\"id\":1692},{\"id\":1693},{\"id\":1694},{\"id\":1695},{\"id\":1696},{\"id\":1697},{\"id\":1698},{\"id\":1699},{\"id\":1700},{\"id\":1701},{\"id\":1702},{\"id\":1703},{\"id\":1704},{\"id\":1705},{\"id\":1706},{\"id\":1707},{\"id\":1708},{\"id\":1709},{\"id\":1710},{\"id\":1711},{\"id\":1712},{\"id\":1713},{\"id\":1714},{\"id\":1715},{\"id\":1716},{\"id\":1717},{\"id\":1718},{\"id\":1719},{\"id\":1720},{\"id\":1721},{\"id\":1722},{\"id\":1723},{\"id\":1724},{\"id\":1725},{\"id\":1726},{\"id\":1727},{\"id\":1728},{\"id\":1729},{\"id\":1730},{\"id\":1731},{\"id\":1732},{\"id\":1733},{\"id\":1734},{\"id\":1735},{\"id\":1736},{\"id\":1737},{\"id\":1738},{\"id\":1739},{\"id\":1740},{\"id\":1741},{\"id\":1742},{\"id\":1743},{\"id\":1744},{\"id\":1745},{\"id\":1746},{\"id\":1747},{\"id\":1748},{\"id\":1749},{\"id\":1750},{\"id\":1751},{\"id\":1752},{\"id\":1753},{\"id\":1754},{\"id\":1755},{\"id\":1756},{\"id\":1757},{\"id\":1758},{\"id\":1759},{\"id\":1760},{\"id\":1761},{\"id\":1762},{\"id\":1763},{\"id\":1764},{\"id\":1765},{\"id\":1766},{\"id\":1767},{\"id\":1768},{\"id\":1769},{\"id\":1770},{\"id\":1771},{\"id\":1772},{\"id\":1773},{\"id\":1774},{\"id\":1775},{\"id\":1776},{\"id\":1777},{\"id\":1778},{\"id\":1779},{\"id\":1780},{\"id\":1781},{\"id\":1782},{\"id\":1783},{\"id\":1784},{\"id\":1785},{\"id\":1786},{\"id\":1787},{\"id\":1788},{\"id\":1789},{\"id\":1790},{\"id\":1791},{\"id\":1792},{\"id\":1793},{\"id\":1794},{\"id\":1795},{\"id\":1796},{\"id\":1797},{\"id\":1798},{\"id\":1799},{\"id\":1800},{\"id\":1801},{\"id\":1802},{\"id\":1803},{\"id\":1804},{\"id\":1805},{\"id\":1806},{\"id\":1807},{\"id\":1808},{\"id\":1809},{\"id\":1810},{\"id\":1811},{\"id\":1812},{\"id\":1813},{\"id\":1814},{\"id\":1815},{\"id\":1816},{\"id\":1817},{\"id\":1818},{\"id\":1819},{\"id\":1820},{\"id\":1821},{\"id\":1822},{\"id\":1823},{\"id\":1824},{\"id\":1825},{\"id\":1826},{\"id\":1827},{\"id\":1828},{\"id\":1829},{\"id\":1830},{\"id\":1831},{\"id\":1832},{\"id\":1833},{\"id\":1834},{\"id\":1835},{\"id\":1836},{\"id\":1837},{\"id\":1838},{\"id\":1839},{\"id\":1840},{\"id\":1841},{\"id\":1842},{\"id\":1843},{\"id\":1844},{\"id\":1845},{\"id\":1846},{\"id\":1847},{\"id\":1848},{\"id\":1849},{\"id\":1850},{\"id\":1851},{\"id\":1852},{\"id\":1853},{\"id\":1854},{\"id\":1855},{\"id\":1856},{\"id\":1857},{\"id\":1858},{\"id\":1859},{\"id\":1860},{\"id\":1861},{\"id\":1862},{\"id\":1863},{\"id\":1864},{\"id\":1865},{\"id\":1866},{\"id\":1867},{\"id\":1868},{\"id\":1869},{\"id\":1870},{\"id\":1871},{\"id\":1872},{\"id\":1873},{\"id\":1874},{\"id\":1875},{\"id\":1876},{\"id\":1877},{\"id\":1878},{\"id\":1879},{\"id\":1880},{\"id\":1881},{\"id\":1882},{\"id\":1883},{\"id\":1884},{\"id\":1885},{\"id\":1886},{\"id\":1887},{\"id\":1888},{\"id\":1889},{\"id\":1890},{\"id\":1891},{\"id\":1892},{\"id\":1893},{\"id\":1894},{\"id\":1895},{\"id\":1896},{\"id\":1897},{\"id\":1898},{\"id\":1899},{\"id\":1900},{\"id\":1901},{\"id\":1902},{\"id\":1903},{\"id\":1904},{\"id\":1905},{\"id\":1906},{\"id\":1907},{\"id\":1908},{\"id\":1909},{\"id\":1910},{\"id\":1911},{\"id\":1912},{\"id\":1913},{\"id\":1914},{\"id\":1915},{\"id\":1916},{\"id\":1917},{\"id\":1918},{\"id\":1919},{\"id\":1920},{\"id\":1921},{\"id\":1922},{\"id\":1923},{\"id\":1924},{\"id\":1925},{\"id\":1926},{\"id\":1927},{\"id\":1928},{\"id\":1929},{\"id\":1930},{\"id\":1931},{\"id\":1932},{\"id\":1933},{\"id\":1934},{\"id\":1935},{\"id\":1936},{\"id\":1937},{\"id\":1938},{\"id\":1939},{\"id\":1940},{\"id\":1941},{\"id\":1942},{\"id\":1943},{\"id\":1944},{\"id\":1945},{\"id\":1946},{\"id\":1947},{\"id\":1948},{\"id\":1949},{\"id\":1950},{\"id\":1951},{\"id\":1952},{\"id\":1953},{\"id\":1954},{\"id\":1955},{\"id\":1956},{\"id\":1957},{\"id\":1958},{\"id\":1959},{\"id\":1960},{\"id\":1961},{\"id\":1962},{\"id\":1963},{\"id\":1964},{\"id\":1965},{\"id\":1966},{\"id\":1967},{\"id\":1968},{\"id\":1969},{\"id\":1970},{\"id\":1971},{\"id\":1972},{\"id\":1973},{\"id\":1974},{\"id\":1975},{\"id\":1976},{\"id\":1977},{\"id\":1978},{\"id\":1979},{\"id\":1980},{\"id\":1981},{\"id\":1982},{\"id\":1983},{\"id\":1984},{\"id\":1985},{\"id\":1986},{\"id\":1987},{\"id\":1988},{\"id\":1989},{\"id\":1990},{\"id\":1991},{\"id\":1992},{\"id\":1993},{\"id\":1994},{\"id\":1995},{\"id\":1996},{\"id\":1997},{\"id\":1998},{\"id\":1999},{\"id\":2000},{\"id\":2001},{\"id\":2002},{\"id\":2003},{\"id\":2004},{\"id\":2005},{\"id\":2006},{\"id\":2007},{\"id\":2008},{\"id\":2009},{\"id\":2010},{\"id\":2011},{\"id\":2012},{\"id\":2013},{\"id\":2014},{\"id\":2015},{\"id\":2016},{\"id\":2017},{\"id\":2018},{\"id\":2019},{\"id\":2020},{\"id\":2021},{\"id\":2022},{\"id\":2023},{\"id\":2024},{\"id\":2025},{\"id\":2026},{\"id\":2027},{\"id\":2028},{\"id\":2029},{\"id\":2030},{\"id\":2031},{\"id\":2032},{\"id\":2033},{\"id\":2034},{\"id\":2035},{\"id\":2036},{\"id\":2037},{\"id\":2038},{\"id\":2039},{\"id\":2040},{\"id\":2041},{\"id\":2042},{\"id\":2043},{\"id\":2044},{\"id\":2045},{\"id\":2046},{\"id\":2047},{\"id\":2048},{\"id\":2049},{\"id\":2050},{\"id\":2051},{\"id\":2052},{\"id\":2053},{\"id\":2054},{\"id\":2055},{\"id\":2056},{\"id\":2057},{\"id\":2058},{\"id\":2059},{\"id\":2060},{\"id\":2061},{\"id\":2062},{\"id\":2063},{\"id\":2064},{\"id\":2065},{\"id\":2066},{\"id\":2067},{\"id\":2068},{\"id\":2069},{\"id\":2070},{\"id\":2071},{\"id\":2072},{\"id\":2073},{\"id\":2074},{\"id\":2075},{\"id\":2076},{\"id\":2077},{\"id\":2078},{\"id\":2079},{\"id\":2080},{\"id\":2081},{\"id\":2082},{\"id\":2083},{\"id\":2084},{\"id\":2085},{\"id\":2086},{\"id\":2087},{\"id\":2088},{\"id\":2089},{\"id\":2090},{\"id\":2091},{\"id\":2092},{\"id\":2093},{\"id\":2094},{\"id\":2095},{\"id\":2096},{\"id\":2097},{\"id\":2098},{\"id\":2099},{\"id\":2100},{\"id\":2101},{\"id\":2102},{\"id\":2103},{\"id\":2104},{\"id\":2105},{\"id\":2106},{\"id\":2107},{\"id\":2108},{\"id\":2109},{\"id\":2110},{\"id\":2111},{\"id\":2112},{\"id\":2113},{\"id\":2114},{\"id\":2115},{\"id\":2116},{\"id\":2117},{\"id\":2118},{\"id\":2119},{\"id\":2120},{\"id\":2121},{\"id\":2122},{\"id\":2123},{\"id\":2124},{\"id\":2125},{\"id\":2126},{\"id\":2127},{\"id\":2128},{\"id\":2129},{\"id\":2130},{\"id\":2131},{\"id\":2132},{\"id\":2133},{\"id\":2134},{\"id\":2135},{\"id\":2136},{\"id\":2137},{\"id\":2138},{\"id\":2139},{\"id\":2140},{\"id\":2141},{\"id\":2142},{\"id\":2143},{\"id\":2144},{\"id\":2145},{\"id\":2146},{\"id\":2147},{\"id\":2148},{\"id\":2149},{\"id\":2150},{\"id\":2151},{\"id\":2152},{\"id\":2153},{\"id\":2154},{\"id\":2155},{\"id\":2156},{\"id\":2157},{\"id\":2158},{\"id\":2159},{\"id\":2160},{\"id\":2161},{\"id\":2162},{\"id\":2163},{\"id\":2164},{\"id\":2165},{\"id\":2166},{\"id\":2167},{\"id\":2168},{\"id\":2169},{\"id\":2170},{\"id\":2171},{\"id\":2172},{\"id\":2173},{\"id\":2174},{\"id\":2175},{\"id\":2176},{\"id\":2177},{\"id\":2178},{\"id\":2179},{\"id\":2180},{\"id\":2181},{\"id\":2182},{\"id\":2183},{\"id\":2184},{\"id\":2185},{\"id\":2186},{\"id\":2187},{\"id\":2188},{\"id\":2189},{\"id\":2190},{\"id\":2191},{\"id\":2192},{\"id\":2193},{\"id\":2194},{\"id\":2195},{\"id\":2196},{\"id\":2197},{\"id\":2198},{\"id\":2199},{\"id\":2200},{\"id\":2201},{\"id\":2202},{\"id\":2203},{\"id\":2204},{\"id\":2205},{\"id\":2206},{\"id\":2207},{\"id\":2208},{\"id\":2209},{\"id\":2210},{\"id\":2211},{\"id\":2212},{\"id\":2213},{\"id\":2214},{\"id\":2215},{\"id\":2216},{\"id\":2217},{\"id\":2218},{\"id\":2219},{\"id\":2220},{\"id\":2221},{\"id\":2222},{\"id\":2223},{\"id\":2224},{\"id\":2225},{\"id\":2226},{\"id\":2227},{\"id\":2228},{\"id\":2229},{\"id\":2230},{\"id\":2231},{\"id\":2232},{\"id\":2233},{\"id\":2234},{\"id\":2235},{\"id\":2236},{\"id\":2237},{\"id\":2238},{\"id\":2239},{\"id\":2240},{\"id\":2241},{\"id\":2242},{\"id\":2243},{\"id\":2244},{\"id\":2245},{\"id\":2246},{\"id\":2247},{\"id\":2248},{\"id\":2249},{\"id\":2250},{\"id\":2251},{\"id\":2252},{\"id\":2253},{\"id\":2254},{\"id\":2255},{\"id\":2256},{\"id\":2257},{\"id\":2258},{\"id\":2259},{\"id\":2260},{\"id\":2261},{\"id\":2262},{\"id\":2263},{\"id\":2264},{\"id\":2265},{\"id\":2266},{\"id\":2267},{\"id\":2268},{\"id\":2269},{\"id\":2270},{\"id\":2271},{\"id\":2272},{\"id\":2273},{\"id\":2274},{\"id\":2275},{\"id\":2276},{\"id\":2277},{\"id\":2278},{\"id\":2279},{\"id\":2280},{\"id\":2281},{\"id\":2282},{\"id\":2283},{\"id\":2284},{\"id\":2285},{\"id\":2286},{\"id\":2287},{\"id\":2288},{\"id\":2289},{\"id\":2290},{\"id\":2291},{\"id\":2292},{\"id\":2293},{\"id\":2294},{\"id\":2295},{\"id\":2296},{\"id\":2297},{\"id\":2298},{\"id\":2299},{\"id\":2300},{\"id\":2301},{\"id\":2302},{\"id\":2303},{\"id\":2304},{\"id\":2305},{\"id\":2306},{\"id\":2307},{\"id\":2308},{\"id\":2309},{\"id\":2310},{\"id\":2311},{\"id\":2312},{\"id\":2313},{\"id\":2314},{\"id\":2315},{\"id\":2316},{\"id\":2317},{\"id\":2318},{\"id\":2319},{\"id\":2320},{\"id\":2321},{\"id\":2322},{\"id\":2323},{\"id\":2324},{\"id\":2325},{\"id\":2326},{\"id\":2327},{\"id\":2328},{\"id\":2329},{\"id\":2330},{\"id\":2331},{\"id\":2332},{\"id\":2333},{\"id\":2334},{\"id\":2335},{\"id\":2336},{\"id\":2337},{\"id\":2338},{\"id\":2339},{\"id\":2340},{\"id\":2341},{\"id\":2342},{\"id\":2343},{\"id\":2344},{\"id\":2345},{\"id\":2346},{\"id\":2347},{\"id\":2348},{\"id\":2349},{\"id\":2350},{\"id\":2351},{\"id\":2352},{\"id\":2353},{\"id\":2354},{\"id\":2355},{\"id\":2356},{\"id\":2357},{\"id\":2358},{\"id\":2359},{\"id\":2360},{\"id\":2361},{\"id\":2362},{\"id\":2363},{\"id\":2364},{\"id\":2365},{\"id\":2366},{\"id\":2367},{\"id\":2368},{\"id\":2369},{\"id\":2370},{\"id\":2371},{\"id\":2372},{\"id\":2373},{\"id\":2374},{\"id\":2375},{\"id\":2376},{\"id\":2377},{\"id\":2378},{\"id\":2379},{\"id\":2380},{\"id\":2381},{\"id\":2382},{\"id\":2383},{\"id\":2384},{\"id\":2385},{\"id\":2386},{\"id\":2387},{\"id\":2388},{\"id\":2389},{\"id\":2390},{\"id\":2391},{\"id\":2392},{\"id\":2393},{\"id\":2394},{\"id\":2395},{\"id\":2396},{\"id\":2397},{\"id\":2398},{\"id\":2399},{\"id\":2400},{\"id\":2401},{\"id\":2402},{\"id\":2403},{\"id\":2404},{\"id\":2405},{\"id\":2406},{\"id\":2407},{\"id\":2408},{\"id\":2409},{\"id\":2410},{\"id\":2411},{\"id\":2412},{\"id\":2413},{\"id\":2414},{\"id\":2415},{\"id\":2416},{\"id\":2417},{\"id\":2418},{\"id\":2419},{\"id\":2420},{\"id\":2421},{\"id\":2422},{\"id\":2423},{\"id\":2424},{\"id\":2425},{\"id\":2426},{\"id\":2427},{\"id\":2428},{\"id\":2429},{\"id\":2430},{\"id\":2431},{\"id\":2432},{\"id\":2433},{\"id\":2434},{\"id\":2435},{\"id\":2436},{\"id\":2437},{\"id\":2438},{\"id\":2439},{\"id\":2440},{\"id\":2441},{\"id\":2442},{\"id\":2443},{\"id\":2444},{\"id\":2445},{\"id\":2446},{\"id\":2447},{\"id\":2448},{\"id\":2449},{\"id\":2450},{\"id\":2451},{\"id\":2452},{\"id\":2453},{\"id\":2454},{\"id\":2455},{\"id\":2456},{\"id\":2457},{\"id\":2458},{\"id\":2459},{\"id\":2460},{\"id\":2461},{\"id\":2462},{\"id\":2463},{\"id\":2464},{\"id\":2465},{\"id\":2466},{\"id\":2467},{\"id\":2468},{\"id\":2469},{\"id\":2470},{\"id\":2471},{\"id\":2472},{\"id\":2473},{\"id\":2474},{\"id\":2475},{\"id\":2476},{\"id\":2477},{\"id\":2478},{\"id\":2479},{\"id\":2480},{\"id\":2481},{\"id\":2482},{\"id\":2483},{\"id\":2484},{\"id\":2485},{\"id\":2486},{\"id\":2487},{\"id\":2488},{\"id\":2489},{\"id\":2490},{\"id\":2491},{\"id\":2492},{\"id\":2493},{\"id\":2494},{\"id\":2495},{\"id\":2496},{\"id\":2497},{\"id\":2498},{\"id\":2499},{\"id\":2500},{\"id\":2501},{\"id\":2502},{\"id\":2503},{\"id\":2504},{\"id\":2505},{\"id\":2506},{\"id\":2507},{\"id\":2508},{\"id\":2509},{\"id\":2510},{\"id\":2511},{\"id\":2512},{\"id\":2513},{\"id\":2514},{\"id\":2515},{\"id\":2516},{\"id\":2517},{\"id\":2518},{\"id\":2519},{\"id\":2520},{\"id\":2521},{\"id\":2522},{\"id\":2523},{\"id\":2524},{\"id\":2525},{\"id\":2526},{\"id\":2527},{\"id\":2528},{\"id\":2529},{\"id\":2530},{\"id\":2531},{\"id\":2532},{\"id\":2533},{\"id\":2534},{\"id\":2535},{\"id\":2536},{\"id\":2537},{\"id\":2538},{\"id\":2539},{\"id\":2540},{\"id\":2541},{\"id\":2542},{\"id\":2543},{\"id\":2544},{\"id\":2545},{\"id\":2546},{\"id\":2547},{\"id\":2548},{\"id\":2549},{\"id\":2550},{\"id\":2551},{\"id\":2552},{\"id\":2553},{\"id\":2554},{\"id\":2555},{\"id\":2556},{\"id\":2557},{\"id\":2558},{\"id\":2559},{\"id\":2560},{\"id\":2561},{\"id\":2562},{\"id\":2563},{\"id\":2564},{\"id\":2565},{\"id\":2566},{\"id\":2567},{\"id\":2568},{\"id\":2569},{\"id\":2570},{\"id\":2571},{\"id\":2572},{\"id\":2573},{\"id\":2574},{\"id\":2575},{\"id\":2576},{\"id\":2577},{\"id\":2578},{\"id\":2579},{\"id\":2580},{\"id\":2581},{\"id\":2582},{\"id\":2583},{\"id\":2584},{\"id\":2585},{\"id\":2586},{\"id\":2587},{\"id\":2588},{\"id\":2589},{\"id\":2590},{\"id\":2591},{\"id\":2592},{\"nodeType\":3,\"id\":2596,\"textContent\":\" // Track clicks on page $(document).ready(function() { $(\\\".control\\\").click(function(e) { e.stopImmediatePropagation(); clicks = clicks + 1; console.log(clicks); }); }); $('.userid').html(sid); // console.log(\\\"start of clicked array: \\\"+clicked); // console.log(\\\"start of hovered string: \\\"+hovered); //set correct answers for each question var triangular_answers = { \\\"acme.starttime.1\\\" : [\\\"F\\\"], \\\"acme.starts.1\\\" : [\\\"K\\\"], \\\"acme.meets.1\\\" : [\\\"F\\\"], \\\"acme.endtime.1\\\" : [\\\"H\\\"], \\\"acme.midpoint.1\\\" : [\\\"O\\\"], \\\"acme.starttime.2\\\" : [\\\"F\\\"], \\\"acme.starts.2\\\" : [\\\"K\\\"], \\\"acme.meets.2\\\" : [\\\"F\\\"], \\\"acme.endtime.2\\\" : [\\\"H\\\"], \\\"acme.midpoint.2\\\" : [\\\"A\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"E\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"E\\\"], \\\"bigset.starttime.1\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.1\\\" : [\\\"G\\\"], \\\"bigset.meets.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.1\\\" : [\\\"X\\\"], \\\"bigset.midpoint.1\\\" : [\\\"K\\\",\\\"X\\\"], \\\"bigset.starttime.2\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.2\\\" : [\\\"G\\\"], \\\"bigset.meets.2\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.2\\\" : [\\\"X\\\"], \\\"bigset.midpoint.2\\\" : [\\\"K\\\",\\\"X\\\"] } var orthogonal_answers = { \\\"acme.starttime.1\\\" : [\\\"A\\\"], \\\"acme.starts.1\\\" : [\\\"E\\\"], \\\"acme.meets.1\\\" : [\\\"Z\\\"], \\\"acme.endtime.1\\\" : [\\\"U\\\"], \\\"acme.midpoint.1\\\" : [\\\"U\\\"], \\\"acme.starttime.2\\\" : [\\\"0\\\"], \\\"acme.starts.2\\\" : [\\\"0\\\"], \\\"acme.meets.2\\\" : [\\\"0\\\"], \\\"acme.endtime.2\\\" : [\\\"0\\\"], \\\"acme.midpoint.2\\\" : [\\\"0\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"X\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"X\\\"], \\\"bigset.starttime.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.1\\\" : [\\\"B\\\"], \\\"bigset.meets.1\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.1\\\" : [\\\"B\\\"], \\\"bigset.midpoint.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.starttime.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.2\\\" : [\\\"B\\\"], \\\"bigset.meets.2\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.2\\\" : [\\\"B\\\"], \\\"bigset.midpoint.2\\\" : [\\\"E\\\",\\\"F\\\"] } //display the question and answer buttons based on input values from jsPsych document.getElementById(scenario+\\\".\\\"+question).style.display = \\\"block\\\"; if (question == \\\"strategy\\\") {document.getElementById(\\\"strategyButton\\\").style.display = \\\"block\\\";} else {document.getElementById(\\\"testingButton\\\").style.display = \\\"block\\\";} //---------SET PROPERTIES OF THE GRAPH -------------// // set the dimensions and margins of the graph var margin = {top: 25, right: 30, bottom: 90, left: 100}, width = 800, height = 800; var intersects = false; //default value for intersects scaffold var xAxisTitle, yAxisTitle; var datafile =\\\"\\\"; // SET AXIS VALUES if (axis == 1){ axis = \\\"Orthogonal-XInside-YFull\\\"; } else if (axis == 2){ axis = \\\"Orthogonal-XInside-YPartial\\\"; } else if (axis ==3){ axis = \\\"Triangular-XInside-YInside\\\"; } else if (axis ==4){ axis = \\\"Orthogonal-XInside-YInside\\\"; } else if (axis ==5){ axis = \\\"Orthogonal-XFull-YFull\\\"; } // SET EXPLICIT SCAFFOLD FEATURES if (explicit ==2 && axis != \\\"diagonal\\\"){ scaffold = 2; intersects = false; } else if (explicit == 2 && axis == \\\"diagonal\\\"){ scaffold = 2; intersects = false; } //TODO: not sure if above two lines are still valid since leaders are now generated on the fly else if (explicit == 3){ $('#hint-interactive').css(\\\"display\\\",\\\"block\\\"); //display textimage scaffold intersects = true; } //SET DATA FILE FOR IMPLICIT SCAFFOLD if (impasse == 1){ datafile = \\\"../views/src/data/acme_nonimpasse.csv\\\"; } else if (impasse == 2){ datafile = \\\"../views/src/data/acme_impasse.csv\\\"; } //OVERRIDE DATA FILE FOR NON-SCAFFOLD QUESTIONS if (q > 5) { //override data file if q# is greater than 5 datafile = \\\"../views/src/data/bigset.csv\\\"; console.log(\\\"override data file\\\"); $('#orthogonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#diagonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#hint-interactive').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold intersects = false; } // //---------CREATE THE SVG ------------------------// var svg = d3.select(\\\".d3container\\\").append(\\\"svg\\\") .attr(\\\"width\\\", width + margin.left + margin.right) .attr(\\\"height\\\", height + margin.top + margin.bottom) .append(\\\"g\\\") .attr(\\\"transform\\\", \\\"translate(\\\" + margin.left + \\\",\\\" + margin.top + \\\")\\\"); //---------DRAW THE GRAPH ------------------------// xAxisTitle = \\\"START & END TIME (time of day)\\\"; yAxisTitle = \\\"DURATION (in hours)\\\"; drawTriangleModel(datafile,intersects,axis,scaffold,q); \"},{\"id\":2593},{\"id\":2594},{\"nodeType\":3,\"id\":2597,\"textContent\":\" //MOUSE LOGGING SCRIPT var mouseLog = [] var xwidth = $(document).width(); var xheight = $(document).width(); mouseLog.push(\\\"{x:\\\"+xwidth+\\\",y:\\\"+xheight+\\\",t:\\\"+\\\"0};\\\") document.onmousemove = function(e){ var pageCoords = \\\"{x:\\\" + e.pageX + \\\",y:\\\"+ e.pageY +\\\",t:\\\"+ Date.now()+ \\\"};\\\" ; mouseLog.push(pageCoords); // console.log(pageCoords); }; \"},{\"id\":2595}],[],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2598,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2599,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2598},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2600,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2599},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2601,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":2600},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2602,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2599}},{\"nodeType\":1,\"id\":2603,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2602},\"parentNode\":{\"id\":2599}},{\"nodeType\":3,\"id\":2604,\"textContent\":\"What is your age?\",\"parentNode\":{\"id\":2602}},{\"nodeType\":1,\"id\":2605,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2600}},{\"nodeType\":1,\"id\":2606,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2605},\"parentNode\":{\"id\":2600}},{\"nodeType\":3,\"id\":2607,\"textContent\":\"In what country were you born?\",\"parentNode\":{\"id\":2605}},{\"nodeType\":3,\"id\":2608,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":2601}}],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2598},{\"id\":2599},{\"id\":2602},{\"id\":2604},{\"id\":2603},{\"id\":2600},{\"id\":2605},{\"id\":2607},{\"id\":2606},{\"id\":2601},{\"id\":2608}],[],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2609,\"tagName\":\"FORM\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-form\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2610,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-preamble\",\"class\":\"jspsych-survey-multi-choice-preamble\"},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2611,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-0\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2610},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2612,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-1\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2611},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2613,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-2\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2612},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2614,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-3\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2613},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2615,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"submit\",\"id\":\"jspsych-survey-multi-choice-next\",\"class\":\"jspsych-survey-multi-choice jspsych-btn\",\"value\":\"Submit Answers\"},\"previousSibling\":{\"id\":2614},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2616,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2617,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2616},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2618,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2617},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2619,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2618},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2620,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2619},\"parentNode\":{\"id\":2611}},{\"nodeType\":3,\"id\":2621,\"textContent\":\"What is your first language?\",\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2622,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2621},\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2623,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2624,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2623}},{\"nodeType\":3,\"id\":2625,\"textContent\":\"English\",\"previousSibling\":{\"id\":2624},\"parentNode\":{\"id\":2623}},{\"nodeType\":1,\"id\":2626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2618}},{\"nodeType\":1,\"id\":2627,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2626}},{\"nodeType\":3,\"id\":2628,\"textContent\":\"Spanish\",\"previousSibling\":{\"id\":2627},\"parentNode\":{\"id\":2626}},{\"nodeType\":1,\"id\":2629,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2619}},{\"nodeType\":1,\"id\":2630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2629}},{\"nodeType\":3,\"id\":2631,\"textContent\":\"Mandarin or Cantonese\",\"previousSibling\":{\"id\":2630},\"parentNode\":{\"id\":2629}},{\"nodeType\":1,\"id\":2632,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2633,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2634,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2633},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2635,\"textContent\":\"*\",\"parentNode\":{\"id\":2622}},{\"nodeType\":1,\"id\":2636,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2637,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2636},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2638,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2637},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2639,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2638},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2640,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2639},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2641,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2640},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2642,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2641},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2643,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2642},\"parentNode\":{\"id\":2612}},{\"nodeType\":3,\"id\":2644,\"textContent\":\"What is your year in school?\",\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2645,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2644},\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2646,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2637}},{\"nodeType\":1,\"id\":2647,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2646}},{\"nodeType\":3,\"id\":2648,\"textContent\":\"First\",\"previousSibling\":{\"id\":2647},\"parentNode\":{\"id\":2646}},{\"nodeType\":1,\"id\":2649,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2638}},{\"nodeType\":1,\"id\":2650,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2649}},{\"nodeType\":3,\"id\":2651,\"textContent\":\"Second\",\"previousSibling\":{\"id\":2650},\"parentNode\":{\"id\":2649}},{\"nodeType\":1,\"id\":2652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2639}},{\"nodeType\":1,\"id\":2653,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2652}},{\"nodeType\":3,\"id\":2654,\"textContent\":\"Third\",\"previousSibling\":{\"id\":2653},\"parentNode\":{\"id\":2652}},{\"nodeType\":1,\"id\":2655,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2640}},{\"nodeType\":1,\"id\":2656,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2655}},{\"nodeType\":3,\"id\":2657,\"textContent\":\"Fourth\",\"previousSibling\":{\"id\":2656},\"parentNode\":{\"id\":2655}},{\"nodeType\":1,\"id\":2658,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2641}},{\"nodeType\":1,\"id\":2659,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2658}},{\"nodeType\":3,\"id\":2660,\"textContent\":\"Fifth\",\"previousSibling\":{\"id\":2659},\"parentNode\":{\"id\":2658}},{\"nodeType\":1,\"id\":2661,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2642}},{\"nodeType\":1,\"id\":2662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2661}},{\"nodeType\":3,\"id\":2663,\"textContent\":\"Graduate\",\"previousSibling\":{\"id\":2662},\"parentNode\":{\"id\":2661}},{\"nodeType\":1,\"id\":2664,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2643}},{\"nodeType\":1,\"id\":2665,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2666,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2665},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2667,\"textContent\":\"*\",\"parentNode\":{\"id\":2645}},{\"nodeType\":1,\"id\":2668,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2669,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2668},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2670,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2669},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2671,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2670},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2672,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2671},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2673,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2672},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2674,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2673},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2675,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2674},\"parentNode\":{\"id\":2613}},{\"nodeType\":3,\"id\":2676,\"textContent\":\"What is your major area of study?\",\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2677,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2676},\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2678,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2669}},{\"nodeType\":1,\"id\":2679,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2678}},{\"nodeType\":3,\"id\":2680,\"textContent\":\"Math or Computer Sciences\",\"previousSibling\":{\"id\":2679},\"parentNode\":{\"id\":2678}},{\"nodeType\":1,\"id\":2681,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2670}},{\"nodeType\":1,\"id\":2682,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2681}},{\"nodeType\":3,\"id\":2683,\"textContent\":\"Social Sciences (incl. CogSci)\",\"previousSibling\":{\"id\":2682},\"parentNode\":{\"id\":2681}},{\"nodeType\":1,\"id\":2684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2671}},{\"nodeType\":1,\"id\":2685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2684}},{\"nodeType\":3,\"id\":2686,\"textContent\":\"Biomedical & Health Sciences\",\"previousSibling\":{\"id\":2685},\"parentNode\":{\"id\":2684}},{\"nodeType\":1,\"id\":2687,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2672}},{\"nodeType\":1,\"id\":2688,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2687}},{\"nodeType\":3,\"id\":2689,\"textContent\":\"Natural Sciences\",\"previousSibling\":{\"id\":2688},\"parentNode\":{\"id\":2687}},{\"nodeType\":1,\"id\":2690,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2673}},{\"nodeType\":1,\"id\":2691,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2690}},{\"nodeType\":3,\"id\":2692,\"textContent\":\"Engineering\",\"previousSibling\":{\"id\":2691},\"parentNode\":{\"id\":2690}},{\"nodeType\":1,\"id\":2693,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2674}},{\"nodeType\":1,\"id\":2694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2693}},{\"nodeType\":3,\"id\":2695,\"textContent\":\"Humanities\",\"previousSibling\":{\"id\":2694},\"parentNode\":{\"id\":2693}},{\"nodeType\":1,\"id\":2696,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2675}},{\"nodeType\":1,\"id\":2697,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2698,\"textContent\":\"Fine Arts\",\"previousSibling\":{\"id\":2697},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2699,\"textContent\":\"*\",\"parentNode\":{\"id\":2677}},{\"nodeType\":1,\"id\":2700,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2701,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2700},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2702,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2701},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2703,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2702},\"parentNode\":{\"id\":2614}},{\"nodeType\":3,\"id\":2704,\"textContent\":\"What is your gender?\",\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2705,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2704},\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2706,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2701}},{\"nodeType\":1,\"id\":2707,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2706}},{\"nodeType\":3,\"id\":2708,\"textContent\":\"Male\",\"previousSibling\":{\"id\":2707},\"parentNode\":{\"id\":2706}},{\"nodeType\":1,\"id\":2709,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2702}},{\"nodeType\":1,\"id\":2710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2709}},{\"nodeType\":3,\"id\":2711,\"textContent\":\"Female\",\"previousSibling\":{\"id\":2710},\"parentNode\":{\"id\":2709}},{\"nodeType\":1,\"id\":2712,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2703}},{\"nodeType\":1,\"id\":2713,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2714,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2713},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2715,\"textContent\":\"*\",\"parentNode\":{\"id\":2705}}],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2609},{\"id\":2610},{\"id\":2611},{\"id\":2616},{\"id\":2621},{\"id\":2622},{\"id\":2635},{\"id\":2617},{\"id\":2623},{\"id\":2624},{\"id\":2625},{\"id\":2618},{\"id\":2626},{\"id\":2627},{\"id\":2628},{\"id\":2619},{\"id\":2629},{\"id\":2630},{\"id\":2631},{\"id\":2620},{\"id\":2632},{\"id\":2633},{\"id\":2634},{\"id\":2612},{\"id\":2636},{\"id\":2644},{\"id\":2645},{\"id\":2667},{\"id\":2637},{\"id\":2646},{\"id\":2647},{\"id\":2648},{\"id\":2638},{\"id\":2649},{\"id\":2650},{\"id\":2651},{\"id\":2639},{\"id\":2652},{\"id\":2653},{\"id\":2654},{\"id\":2640},{\"id\":2655},{\"id\":2656},{\"id\":2657},{\"id\":2641},{\"id\":2658},{\"id\":2659},{\"id\":2660},{\"id\":2642},{\"id\":2661},{\"id\":2662},{\"id\":2663},{\"id\":2643},{\"id\":2664},{\"id\":2665},{\"id\":2666},{\"id\":2613},{\"id\":2668},{\"id\":2676},{\"id\":2677},{\"id\":2699},{\"id\":2669},{\"id\":2678},{\"id\":2679},{\"id\":2680},{\"id\":2670},{\"id\":2681},{\"id\":2682},{\"id\":2683},{\"id\":2671},{\"id\":2684},{\"id\":2685},{\"id\":2686},{\"id\":2672},{\"id\":2687},{\"id\":2688},{\"id\":2689},{\"id\":2673},{\"id\":2690},{\"id\":2691},{\"id\":2692},{\"id\":2674},{\"id\":2693},{\"id\":2694},{\"id\":2695},{\"id\":2675},{\"id\":2696},{\"id\":2697},{\"id\":2698},{\"id\":2614},{\"id\":2700},{\"id\":2704},{\"id\":2705},{\"id\":2715},{\"id\":2701},{\"id\":2706},{\"id\":2707},{\"id\":2708},{\"id\":2702},{\"id\":2709},{\"id\":2710},{\"id\":2711},{\"id\":2703},{\"id\":2712},{\"id\":2713},{\"id\":2714},{\"id\":2615}],[],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2716,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2717,\"textContent\":\" \",\"previousSibling\":{\"id\":2716},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2718,\"textContent\":\" \",\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":2718},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2720,\"textContent\":\" \",\"previousSibling\":{\"id\":2719},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2721,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":2720},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2722,\"textContent\":\" \",\"previousSibling\":{\"id\":2721},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2723,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":2722},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2724,\"textContent\":\" \",\"previousSibling\":{\"id\":2723},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2725,\"textContent\":\" \",\"parentNode\":{\"id\":2719}},{\"nodeType\":1,\"id\":2726,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":2725},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2727,\"textContent\":\" \",\"previousSibling\":{\"id\":2726},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2728,\"textContent\":\" \",\"parentNode\":{\"id\":2726}},{\"nodeType\":1,\"id\":2729,\"tagName\":\"H3\",\"attributes\":{},\"previousSibling\":{\"id\":2728},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2730,\"textContent\":\" \",\"previousSibling\":{\"id\":2729},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2731,\"textContent\":\"DEBRIEFING\",\"parentNode\":{\"id\":2729}},{\"nodeType\":3,\"id\":2732,\"textContent\":\" \",\"parentNode\":{\"id\":2721}},{\"nodeType\":1,\"id\":2733,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":2732},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2734,\"textContent\":\" \",\"previousSibling\":{\"id\":2733},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2735,\"textContent\":\" \",\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2736,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic\"},\"previousSibling\":{\"id\":2735},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2737,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2736},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2738,\"textContent\":\" \",\"previousSibling\":{\"id\":2737},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2739,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2738},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2740,\"textContent\":\" \",\"previousSibling\":{\"id\":2739},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2741,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2740},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2742,\"textContent\":\" \",\"previousSibling\":{\"id\":2741},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2743,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:bold;\"},\"previousSibling\":{\"id\":2742},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2744,\"textContent\":\" \",\"previousSibling\":{\"id\":2743},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2745,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":2744},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2746,\"textContent\":\" \",\"previousSibling\":{\"id\":2745},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2747,\"textContent\":\"Thank you very much for your participation! This debriefing will tell you more about the study, what you did, and why. \",\"parentNode\":{\"id\":2736}},{\"nodeType\":3,\"id\":2748,\"textContent\":\" \",\"parentNode\":{\"id\":2737}},{\"nodeType\":1,\"id\":2749,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2748},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2750,\"textContent\":\" You have just used a series of pictures (charts, graphs and diagrams) accompanied by different types of instructions to answer a series of problem solving questions. While you were using the pictures, we measured where you clicked, scrolled and pointed with the computer mouse. We also measured the accuracy of your responses and the time it took to complete each question.\",\"previousSibling\":{\"id\":2749},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2751,\"textContent\":\"What did you just do?\",\"parentNode\":{\"id\":2749}},{\"nodeType\":3,\"id\":2752,\"textContent\":\" \",\"parentNode\":{\"id\":2739}},{\"nodeType\":1,\"id\":2753,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2752},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2754,\"textContent\":\" Researchers of learning and cognition have long been interested in how graphic displays of information can be used to communicate, solve problems, and generate insights. As powerful as graphics may be in their communicative efficiency, they're not always immediately intuitive to understand. In short, we know a great deal more about learning with representations than we do about the learning of representations. In this project we are building upon previous research on reading and graph comprehension to explore how readers make sense of unfamiliar representations. The instructions you saw for each type of graph are known as “scaffolding techniques”, and we will compare your performance with the scaffolding techniques you saw with the performance of other participants to determine which types of instructions are most effective in helping humans to make sense of unfamiliar graphs. \",\"previousSibling\":{\"id\":2753},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2755,\"textContent\":\"Why did we have you do it?\",\"parentNode\":{\"id\":2753}},{\"nodeType\":1,\"id\":2756,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2757,\"textContent\":\" We expect that you will have found some of the graphics more difficult to use than others. We also expect that with the assistance of the instructions, after solving several problems you will learn to use the difficult graphics so that you can answer the questions even more quickly than without. If you would like to receive a copy of the results of the study, or have any further questions, please contact the researchers Primary Researcher: Amy Fox : a2fox@ucsd.edu Faculty Advisor : Dr. Jim Hollan : hollan@ucsd.edu \",\"previousSibling\":{\"id\":2756},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2758,\"textContent\":\"What do we expect to find?\",\"parentNode\":{\"id\":2756}},{\"nodeType\":3,\"id\":2759,\"textContent\":\"It is important that you do not discuss this experiment with other students who might participate after you. They must participate in the same way as you did, without any knowledge of what the experiment entails, or the reasoning behind it.\",\"parentNode\":{\"id\":2743}},{\"nodeType\":3,\"id\":2760,\"textContent\":\"Thank you for your time! We hope you enjoyed participating in this study as much as we enjoyed designing it.\",\"parentNode\":{\"id\":2745}},{\"nodeType\":3,\"id\":2761,\"textContent\":\" \",\"parentNode\":{\"id\":2723}},{\"nodeType\":1,\"id\":2762,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":2761},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2763,\"textContent\":\" \",\"previousSibling\":{\"id\":2762},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2764,\"textContent\":\"FINISH\",\"parentNode\":{\"id\":2762}}],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2716},{\"id\":2718},{\"id\":2719},{\"id\":2725},{\"id\":2726},{\"id\":2728},{\"id\":2729},{\"id\":2731},{\"id\":2730},{\"id\":2727},{\"id\":2720},{\"id\":2721},{\"id\":2732},{\"id\":2733},{\"id\":2735},{\"id\":2736},{\"id\":2747},{\"id\":2737},{\"id\":2748},{\"id\":2749},{\"id\":2751},{\"id\":2750},{\"id\":2738},{\"id\":2739},{\"id\":2752},{\"id\":2753},{\"id\":2755},{\"id\":2754},{\"id\":2740},{\"id\":2741},{\"id\":2756},{\"id\":2758},{\"id\":2757},{\"id\":2742},{\"id\":2743},{\"id\":2759},{\"id\":2744},{\"id\":2745},{\"id\":2760},{\"id\":2746},{\"id\":2734},{\"id\":2722},{\"id\":2723},{\"id\":2761},{\"id\":2762},{\"id\":2764},{\"id\":2763},{\"id\":2724},{\"id\":2717}],[],[],[]]}"
    },
    {
      "sequence": 8,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2765,\"tagName\":\"PRE\",\"attributes\":{\"id\":\"jspsych-data-display\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2766,\"textContent\":\"[ { \\\"rt\\\": 452932, \\\"stimulus\\\": \\\"img/phone.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"phone\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 0, \\\"time_elapsed\\\": 452937, \\\"internal_node_id\\\": \\\"0.0-0.0\\\", \\\"subject\\\": \\\"K0CNH\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\" }, { \\\"rt\\\": 3543, \\\"url\\\": \\\"../views/src/external/consent.html\\\", \\\"block\\\": \\\"consent\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 1, \\\"time_elapsed\\\": 457818, \\\"internal_node_id\\\": \\\"0.0-1.0\\\", \\\"subject\\\": \\\"K0CNH\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\" }, { \\\"rt\\\": 6433, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"ZULU\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"211\\\\\\\"}\\\", \\\"block\\\": \\\"codes\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 2, \\\"time_elapsed\\\": 465257, \\\"internal_node_id\\\": \\\"0.0-2.0\\\", \\\"subject\\\": \\\"K0CNH\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\" }, { \\\"rt\\\": 11007, \\\"url\\\": \\\"../views/src/external/instructions_lab.html\\\", \\\"block\\\": \\\"instructions_lab\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 3, \\\"time_elapsed\\\": 477353, \\\"internal_node_id\\\": \\\"0.0-3.0\\\", \\\"subject\\\": \\\"K0CNH\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\" }, { \\\"rt\\\": 9317, \\\"stimulus\\\": \\\"img/acme.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"scenario\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 4, \\\"time_elapsed\\\": 487673, \\\"internal_node_id\\\": \\\"0.0-4.0\\\", \\\"subject\\\": \\\"K0CNH\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\" }, { \\\"rt\\\": 30981, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 5, \\\"time_elapsed\\\": 520034, \\\"internal_node_id\\\": \\\"0.0-5.0-0.0\\\", \\\"subject\\\": \\\"K0CNH\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 1, \\\"clicks\\\": 1, \\\"explicit\\\": 2, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"A\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:1163,y:841,t:1528143406963};\\\", \\\"{x:1173,y:833,t:1528143406978};\\\", \\\"{x:1175,y:831,t:1528143406994};\\\", \\\"{x:1177,y:830,t:1528143407011};\\\", \\\"{x:1177,y:829,t:1528143407028};\\\", \\\"{x:1178,y:829,t:1528143407554};\\\", \\\"{x:1179,y:829,t:1528143407979};\\\", \\\"{x:1180,y:829,t:1528143407995};\\\", \\\"{x:1181,y:829,t:1528143408012};\\\", \\\"{x:1182,y:829,t:1528143408042};\\\", \\\"{x:1183,y:829,t:1528143408049};\\\", \\\"{x:1185,y:830,t:1528143408066};\\\", \\\"{x:1185,y:831,t:1528143408082};\\\", \\\"{x:1186,y:832,t:1528143408098};\\\", \\\"{x:1187,y:834,t:1528143408111};\\\", \\\"{x:1187,y:835,t:1528143408128};\\\", \\\"{x:1192,y:842,t:1528143408145};\\\", \\\"{x:1203,y:858,t:1528143408162};\\\", \\\"{x:1214,y:873,t:1528143408178};\\\", \\\"{x:1222,y:887,t:1528143408195};\\\", \\\"{x:1229,y:901,t:1528143408212};\\\", \\\"{x:1234,y:913,t:1528143408228};\\\", \\\"{x:1238,y:921,t:1528143408245};\\\", \\\"{x:1240,y:928,t:1528143408262};\\\", \\\"{x:1241,y:931,t:1528143408278};\\\", \\\"{x:1242,y:934,t:1528143408295};\\\", \\\"{x:1243,y:936,t:1528143408312};\\\", \\\"{x:1243,y:939,t:1528143408329};\\\", \\\"{x:1243,y:940,t:1528143408344};\\\", \\\"{x:1245,y:944,t:1528143408362};\\\", \\\"{x:1245,y:945,t:1528143408410};\\\", \\\"{x:1246,y:945,t:1528143408594};\\\", \\\"{x:1247,y:945,t:1528143408625};\\\", \\\"{x:1246,y:945,t:1528143410523};\\\", \\\"{x:1238,y:946,t:1528143410530};\\\", \\\"{x:1218,y:946,t:1528143410547};\\\", \\\"{x:1203,y:946,t:1528143410563};\\\", \\\"{x:1189,y:946,t:1528143410581};\\\", \\\"{x:1181,y:946,t:1528143410597};\\\", \\\"{x:1179,y:946,t:1528143410613};\\\", \\\"{x:1176,y:946,t:1528143410630};\\\", \\\"{x:1174,y:946,t:1528143410685};\\\", \\\"{x:1174,y:947,t:1528143410704};\\\", \\\"{x:1173,y:947,t:1528143410721};\\\", \\\"{x:1171,y:947,t:1528143410737};\\\", \\\"{x:1170,y:949,t:1528143410784};\\\", \\\"{x:1169,y:949,t:1528143410801};\\\", \\\"{x:1168,y:949,t:1528143410813};\\\", \\\"{x:1166,y:950,t:1528143410829};\\\", \\\"{x:1162,y:952,t:1528143410846};\\\", \\\"{x:1160,y:953,t:1528143410863};\\\", \\\"{x:1156,y:954,t:1528143410879};\\\", \\\"{x:1149,y:956,t:1528143410896};\\\", \\\"{x:1147,y:957,t:1528143410913};\\\", \\\"{x:1144,y:959,t:1528143410929};\\\", \\\"{x:1142,y:961,t:1528143410946};\\\", \\\"{x:1140,y:961,t:1528143410969};\\\", \\\"{x:1139,y:961,t:1528143411001};\\\", \\\"{x:1137,y:961,t:1528143411041};\\\", \\\"{x:1136,y:961,t:1528143411057};\\\", \\\"{x:1135,y:961,t:1528143411122};\\\", \\\"{x:1135,y:960,t:1528143411138};\\\", \\\"{x:1135,y:959,t:1528143411147};\\\", \\\"{x:1135,y:957,t:1528143411164};\\\", \\\"{x:1135,y:956,t:1528143411210};\\\", \\\"{x:1135,y:954,t:1528143411217};\\\", \\\"{x:1136,y:953,t:1528143411241};\\\", \\\"{x:1136,y:952,t:1528143411249};\\\", \\\"{x:1138,y:952,t:1528143411264};\\\", \\\"{x:1140,y:950,t:1528143411280};\\\", \\\"{x:1144,y:947,t:1528143411297};\\\", \\\"{x:1147,y:945,t:1528143411313};\\\", \\\"{x:1149,y:942,t:1528143411330};\\\", \\\"{x:1153,y:940,t:1528143411347};\\\", \\\"{x:1156,y:938,t:1528143411364};\\\", \\\"{x:1159,y:937,t:1528143411381};\\\", \\\"{x:1163,y:935,t:1528143411397};\\\", \\\"{x:1165,y:933,t:1528143411414};\\\", \\\"{x:1168,y:931,t:1528143411430};\\\", \\\"{x:1171,y:928,t:1528143411447};\\\", \\\"{x:1174,y:926,t:1528143411464};\\\", \\\"{x:1178,y:924,t:1528143411481};\\\", \\\"{x:1186,y:922,t:1528143411497};\\\", \\\"{x:1195,y:919,t:1528143411514};\\\", \\\"{x:1198,y:917,t:1528143411531};\\\", \\\"{x:1201,y:915,t:1528143411547};\\\", \\\"{x:1203,y:914,t:1528143411564};\\\", \\\"{x:1205,y:913,t:1528143411581};\\\", \\\"{x:1206,y:913,t:1528143411602};\\\", \\\"{x:1205,y:913,t:1528143411810};\\\", \\\"{x:1204,y:913,t:1528143411825};\\\", \\\"{x:1203,y:914,t:1528143411833};\\\", \\\"{x:1202,y:914,t:1528143412370};\\\", \\\"{x:1201,y:914,t:1528143412381};\\\", \\\"{x:1198,y:915,t:1528143412398};\\\", \\\"{x:1195,y:915,t:1528143412414};\\\", \\\"{x:1192,y:915,t:1528143412431};\\\", \\\"{x:1188,y:915,t:1528143412448};\\\", \\\"{x:1186,y:916,t:1528143412464};\\\", \\\"{x:1184,y:916,t:1528143412480};\\\", \\\"{x:1184,y:917,t:1528143412633};\\\", \\\"{x:1183,y:917,t:1528143412648};\\\", \\\"{x:1182,y:917,t:1528143412738};\\\", \\\"{x:1181,y:917,t:1528143412770};\\\", \\\"{x:1181,y:918,t:1528143412794};\\\", \\\"{x:1180,y:918,t:1528143412818};\\\", \\\"{x:1179,y:919,t:1528143412834};\\\", \\\"{x:1178,y:919,t:1528143412858};\\\", \\\"{x:1177,y:919,t:1528143412881};\\\", \\\"{x:1177,y:920,t:1528143414522};\\\", \\\"{x:1179,y:920,t:1528143414618};\\\", \\\"{x:1195,y:922,t:1528143414634};\\\", \\\"{x:1204,y:923,t:1528143414650};\\\", \\\"{x:1209,y:925,t:1528143414666};\\\", \\\"{x:1225,y:928,t:1528143414684};\\\", \\\"{x:1241,y:930,t:1528143414700};\\\", \\\"{x:1251,y:931,t:1528143414716};\\\", \\\"{x:1255,y:932,t:1528143414733};\\\", \\\"{x:1257,y:932,t:1528143414751};\\\", \\\"{x:1258,y:932,t:1528143414890};\\\", \\\"{x:1259,y:932,t:1528143414901};\\\", \\\"{x:1260,y:932,t:1528143414917};\\\", \\\"{x:1262,y:932,t:1528143414934};\\\", \\\"{x:1264,y:932,t:1528143414950};\\\", \\\"{x:1267,y:932,t:1528143414966};\\\", \\\"{x:1269,y:932,t:1528143414983};\\\", \\\"{x:1271,y:932,t:1528143415001};\\\", \\\"{x:1272,y:932,t:1528143415026};\\\", \\\"{x:1273,y:932,t:1528143415041};\\\", \\\"{x:1274,y:932,t:1528143415057};\\\", \\\"{x:1277,y:932,t:1528143415067};\\\", \\\"{x:1279,y:932,t:1528143415083};\\\", \\\"{x:1283,y:932,t:1528143415100};\\\", \\\"{x:1284,y:932,t:1528143415146};\\\", \\\"{x:1285,y:932,t:1528143415210};\\\", \\\"{x:1285,y:931,t:1528143415282};\\\", \\\"{x:1285,y:930,t:1528143415300};\\\", \\\"{x:1283,y:928,t:1528143415318};\\\", \\\"{x:1280,y:927,t:1528143415333};\\\", \\\"{x:1273,y:926,t:1528143415350};\\\", \\\"{x:1264,y:924,t:1528143415367};\\\", \\\"{x:1254,y:924,t:1528143415384};\\\", \\\"{x:1245,y:924,t:1528143415401};\\\", \\\"{x:1234,y:924,t:1528143415418};\\\", \\\"{x:1230,y:924,t:1528143415434};\\\", \\\"{x:1225,y:924,t:1528143415450};\\\", \\\"{x:1222,y:924,t:1528143415468};\\\", \\\"{x:1218,y:925,t:1528143415484};\\\", \\\"{x:1215,y:926,t:1528143415501};\\\", \\\"{x:1213,y:927,t:1528143415518};\\\", \\\"{x:1214,y:927,t:1528143415602};\\\", \\\"{x:1215,y:926,t:1528143415618};\\\", \\\"{x:1218,y:923,t:1528143415634};\\\", \\\"{x:1220,y:921,t:1528143415650};\\\", \\\"{x:1223,y:918,t:1528143415668};\\\", \\\"{x:1226,y:914,t:1528143415684};\\\", \\\"{x:1230,y:908,t:1528143415701};\\\", \\\"{x:1234,y:900,t:1528143415718};\\\", \\\"{x:1239,y:892,t:1528143415734};\\\", \\\"{x:1241,y:883,t:1528143415751};\\\", \\\"{x:1243,y:872,t:1528143415768};\\\", \\\"{x:1243,y:866,t:1528143415785};\\\", \\\"{x:1243,y:862,t:1528143415801};\\\", \\\"{x:1243,y:861,t:1528143415817};\\\", \\\"{x:1243,y:859,t:1528143415833};\\\", \\\"{x:1242,y:855,t:1528143415850};\\\", \\\"{x:1239,y:850,t:1528143415867};\\\", \\\"{x:1238,y:847,t:1528143415885};\\\", \\\"{x:1236,y:844,t:1528143415900};\\\", \\\"{x:1235,y:843,t:1528143415918};\\\", \\\"{x:1234,y:843,t:1528143415934};\\\", \\\"{x:1230,y:843,t:1528143416098};\\\", \\\"{x:1223,y:840,t:1528143416106};\\\", \\\"{x:1212,y:839,t:1528143416117};\\\", \\\"{x:1174,y:832,t:1528143416135};\\\", \\\"{x:1105,y:821,t:1528143416151};\\\", \\\"{x:1019,y:810,t:1528143416167};\\\", \\\"{x:938,y:797,t:1528143416184};\\\", \\\"{x:826,y:774,t:1528143416200};\\\", \\\"{x:763,y:758,t:1528143416216};\\\", \\\"{x:704,y:740,t:1528143416233};\\\", \\\"{x:664,y:729,t:1528143416250};\\\", \\\"{x:639,y:718,t:1528143416266};\\\", \\\"{x:614,y:707,t:1528143416283};\\\", \\\"{x:598,y:699,t:1528143416300};\\\", \\\"{x:586,y:693,t:1528143416317};\\\", \\\"{x:580,y:689,t:1528143416333};\\\", \\\"{x:575,y:683,t:1528143416351};\\\", \\\"{x:566,y:676,t:1528143416367};\\\", \\\"{x:557,y:668,t:1528143416384};\\\", \\\"{x:553,y:664,t:1528143416401};\\\", \\\"{x:552,y:663,t:1528143416418};\\\", \\\"{x:550,y:661,t:1528143416434};\\\", \\\"{x:548,y:657,t:1528143416451};\\\", \\\"{x:544,y:652,t:1528143416468};\\\", \\\"{x:540,y:647,t:1528143416485};\\\", \\\"{x:536,y:642,t:1528143416500};\\\", \\\"{x:532,y:639,t:1528143416518};\\\", \\\"{x:531,y:637,t:1528143416535};\\\", \\\"{x:529,y:636,t:1528143416551};\\\", \\\"{x:528,y:634,t:1528143416569};\\\", \\\"{x:527,y:633,t:1528143416593};\\\", \\\"{x:526,y:633,t:1528143427506};\\\", \\\"{x:525,y:636,t:1528143427513};\\\", \\\"{x:525,y:638,t:1528143427537};\\\", \\\"{x:524,y:632,t:1528143427641};\\\", \\\"{x:523,y:627,t:1528143427649};\\\", \\\"{x:523,y:622,t:1528143427661};\\\", \\\"{x:523,y:611,t:1528143427681};\\\", \\\"{x:523,y:599,t:1528143427693};\\\", \\\"{x:523,y:594,t:1528143427711};\\\", \\\"{x:523,y:590,t:1528143427727};\\\", \\\"{x:523,y:588,t:1528143427744};\\\", \\\"{x:523,y:576,t:1528143427761};\\\", \\\"{x:522,y:567,t:1528143427777};\\\", \\\"{x:517,y:556,t:1528143427794};\\\", \\\"{x:512,y:547,t:1528143427811};\\\", \\\"{x:508,y:543,t:1528143427828};\\\", \\\"{x:506,y:541,t:1528143427844};\\\", \\\"{x:506,y:540,t:1528143427861};\\\", \\\"{x:504,y:540,t:1528143431177};\\\", \\\"{x:500,y:540,t:1528143431191};\\\", \\\"{x:483,y:540,t:1528143431208};\\\", \\\"{x:451,y:540,t:1528143431225};\\\", \\\"{x:438,y:540,t:1528143431241};\\\", \\\"{x:430,y:540,t:1528143431257};\\\", \\\"{x:423,y:539,t:1528143431275};\\\", \\\"{x:418,y:539,t:1528143431292};\\\", \\\"{x:417,y:539,t:1528143431308};\\\", \\\"{x:415,y:539,t:1528143431325};\\\", \\\"{x:409,y:540,t:1528143431342};\\\", \\\"{x:402,y:542,t:1528143431357};\\\", \\\"{x:390,y:546,t:1528143431377};\\\", \\\"{x:377,y:549,t:1528143431392};\\\", \\\"{x:364,y:551,t:1528143431407};\\\", \\\"{x:338,y:555,t:1528143431430};\\\", \\\"{x:321,y:555,t:1528143431447};\\\", \\\"{x:301,y:555,t:1528143431463};\\\", \\\"{x:282,y:555,t:1528143431480};\\\", \\\"{x:281,y:555,t:1528143431497};\\\", \\\"{x:284,y:555,t:1528143431536};\\\", \\\"{x:294,y:554,t:1528143431547};\\\", \\\"{x:316,y:547,t:1528143431564};\\\", \\\"{x:338,y:541,t:1528143431581};\\\", \\\"{x:357,y:536,t:1528143431598};\\\", \\\"{x:369,y:532,t:1528143431614};\\\", \\\"{x:371,y:531,t:1528143431630};\\\", \\\"{x:373,y:530,t:1528143431648};\\\", \\\"{x:375,y:530,t:1528143431705};\\\", \\\"{x:376,y:530,t:1528143431715};\\\", \\\"{x:379,y:528,t:1528143431730};\\\", \\\"{x:381,y:525,t:1528143431747};\\\", \\\"{x:384,y:524,t:1528143431764};\\\", \\\"{x:386,y:522,t:1528143431781};\\\", \\\"{x:387,y:521,t:1528143431797};\\\", \\\"{x:386,y:526,t:1528143432048};\\\", \\\"{x:390,y:539,t:1528143432064};\\\", \\\"{x:407,y:554,t:1528143432082};\\\", \\\"{x:426,y:568,t:1528143432097};\\\", \\\"{x:449,y:583,t:1528143432114};\\\", \\\"{x:480,y:607,t:1528143432131};\\\", \\\"{x:494,y:622,t:1528143432148};\\\", \\\"{x:500,y:633,t:1528143432165};\\\", \\\"{x:503,y:640,t:1528143432181};\\\", \\\"{x:512,y:654,t:1528143432199};\\\", \\\"{x:522,y:665,t:1528143432215};\\\", \\\"{x:525,y:670,t:1528143432231};\\\", \\\"{x:526,y:670,t:1528143432247};\\\", \\\"{x:531,y:676,t:1528143432265};\\\", \\\"{x:535,y:680,t:1528143432281};\\\", \\\"{x:538,y:683,t:1528143432297};\\\", \\\"{x:540,y:683,t:1528143432314};\\\", \\\"{x:542,y:685,t:1528143432331};\\\", \\\"{x:542,y:688,t:1528143432348};\\\", \\\"{x:545,y:691,t:1528143432364};\\\", \\\"{x:545,y:695,t:1528143432381};\\\", \\\"{x:545,y:697,t:1528143432397};\\\", \\\"{x:545,y:702,t:1528143432415};\\\", \\\"{x:545,y:707,t:1528143432431};\\\", \\\"{x:545,y:720,t:1528143432448};\\\", \\\"{x:545,y:726,t:1528143432465};\\\", \\\"{x:545,y:727,t:1528143432482};\\\", \\\"{x:546,y:727,t:1528143432498};\\\", \\\"{x:545,y:728,t:1528143432801};\\\", \\\"{x:545,y:727,t:1528143432994};\\\", \\\"{x:545,y:726,t:1528143433001};\\\", \\\"{x:545,y:725,t:1528143433015};\\\", \\\"{x:545,y:723,t:1528143433031};\\\", \\\"{x:549,y:717,t:1528143433048};\\\", \\\"{x:550,y:713,t:1528143433064};\\\", \\\"{x:553,y:710,t:1528143433081};\\\", \\\"{x:554,y:708,t:1528143433098};\\\", \\\"{x:556,y:706,t:1528143433115};\\\", \\\"{x:557,y:705,t:1528143433132};\\\", \\\"{x:559,y:704,t:1528143433149};\\\", \\\"{x:560,y:703,t:1528143433166};\\\", \\\"{x:561,y:703,t:1528143433181};\\\", \\\"{x:561,y:702,t:1528143433199};\\\", \\\"{x:562,y:701,t:1528143433217};\\\", \\\"{x:563,y:700,t:1528143433233};\\\", \\\"{x:564,y:700,t:1528143433249};\\\", \\\"{x:565,y:699,t:1528143433266};\\\", \\\"{x:567,y:699,t:1528143433297};\\\", \\\"{x:567,y:698,t:1528143433313};\\\", \\\"{x:568,y:698,t:1528143433329};\\\" ] }, { \\\"rt\\\": 8944, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 6, \\\"time_elapsed\\\": 530291, \\\"internal_node_id\\\": \\\"0.0-5.0-1.0\\\", \\\"subject\\\": \\\"K0CNH\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 2, \\\"clicks\\\": 1, \\\"explicit\\\": 2, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:568,y:696,t:1528143434594};\\\", \\\"{x:567,y:696,t:1528143434696};\\\", \\\"{x:566,y:696,t:1528143435081};\\\", \\\"{x:565,y:696,t:1528143435089};\\\", \\\"{x:565,y:697,t:1528143435146};\\\", \\\"{x:564,y:697,t:1528143435177};\\\", \\\"{x:563,y:697,t:1528143435208};\\\", \\\"{x:562,y:698,t:1528143435225};\\\", \\\"{x:561,y:699,t:1528143435249};\\\", \\\"{x:561,y:700,t:1528143435289};\\\", \\\"{x:560,y:700,t:1528143438521};\\\", \\\"{x:560,y:699,t:1528143441194};\\\", \\\"{x:560,y:691,t:1528143441204};\\\", \\\"{x:560,y:676,t:1528143441221};\\\", \\\"{x:563,y:666,t:1528143441238};\\\", \\\"{x:566,y:655,t:1528143441255};\\\", \\\"{x:567,y:652,t:1528143441271};\\\", \\\"{x:567,y:650,t:1528143441307};\\\", \\\"{x:567,y:647,t:1528143441321};\\\", \\\"{x:567,y:636,t:1528143441338};\\\", \\\"{x:566,y:623,t:1528143441354};\\\", \\\"{x:566,y:612,t:1528143441372};\\\", \\\"{x:566,y:604,t:1528143441388};\\\", \\\"{x:564,y:599,t:1528143441404};\\\", \\\"{x:561,y:595,t:1528143441421};\\\", \\\"{x:555,y:593,t:1528143441438};\\\", \\\"{x:545,y:590,t:1528143441454};\\\", \\\"{x:533,y:588,t:1528143441472};\\\", \\\"{x:507,y:588,t:1528143441488};\\\", \\\"{x:484,y:588,t:1528143441505};\\\", \\\"{x:460,y:588,t:1528143441521};\\\", \\\"{x:431,y:586,t:1528143441539};\\\", \\\"{x:403,y:581,t:1528143441556};\\\", \\\"{x:376,y:580,t:1528143441572};\\\", \\\"{x:359,y:577,t:1528143441588};\\\", \\\"{x:349,y:576,t:1528143441606};\\\", \\\"{x:343,y:575,t:1528143441621};\\\", \\\"{x:342,y:575,t:1528143441639};\\\", \\\"{x:340,y:575,t:1528143441746};\\\", \\\"{x:339,y:575,t:1528143441756};\\\", \\\"{x:333,y:575,t:1528143441772};\\\", \\\"{x:318,y:578,t:1528143441789};\\\", \\\"{x:295,y:585,t:1528143441806};\\\", \\\"{x:270,y:588,t:1528143441822};\\\", \\\"{x:242,y:589,t:1528143441838};\\\", \\\"{x:220,y:590,t:1528143441856};\\\", \\\"{x:200,y:594,t:1528143441871};\\\", \\\"{x:185,y:596,t:1528143441889};\\\", \\\"{x:182,y:596,t:1528143441905};\\\", \\\"{x:181,y:596,t:1528143441921};\\\", \\\"{x:180,y:598,t:1528143441961};\\\", \\\"{x:180,y:599,t:1528143441972};\\\", \\\"{x:176,y:604,t:1528143441988};\\\", \\\"{x:173,y:609,t:1528143442007};\\\", \\\"{x:172,y:613,t:1528143442024};\\\", \\\"{x:171,y:615,t:1528143442039};\\\", \\\"{x:170,y:617,t:1528143442056};\\\", \\\"{x:170,y:624,t:1528143442074};\\\", \\\"{x:170,y:628,t:1528143442088};\\\", \\\"{x:170,y:630,t:1528143442105};\\\", \\\"{x:172,y:630,t:1528143442359};\\\", \\\"{x:179,y:630,t:1528143442372};\\\", \\\"{x:200,y:630,t:1528143442389};\\\", \\\"{x:230,y:632,t:1528143442405};\\\", \\\"{x:261,y:637,t:1528143442422};\\\", \\\"{x:302,y:645,t:1528143442439};\\\", \\\"{x:340,y:653,t:1528143442456};\\\", \\\"{x:376,y:660,t:1528143442472};\\\", \\\"{x:393,y:663,t:1528143442490};\\\", \\\"{x:405,y:668,t:1528143442506};\\\", \\\"{x:409,y:670,t:1528143442523};\\\", \\\"{x:414,y:673,t:1528143442540};\\\", \\\"{x:416,y:674,t:1528143442560};\\\", \\\"{x:417,y:675,t:1528143442573};\\\", \\\"{x:420,y:678,t:1528143442590};\\\", \\\"{x:425,y:682,t:1528143442606};\\\", \\\"{x:432,y:687,t:1528143442623};\\\", \\\"{x:443,y:693,t:1528143442640};\\\", \\\"{x:456,y:698,t:1528143442656};\\\", \\\"{x:473,y:702,t:1528143442676};\\\", \\\"{x:477,y:704,t:1528143442690};\\\", \\\"{x:479,y:704,t:1528143442705};\\\", \\\"{x:480,y:704,t:1528143442728};\\\", \\\"{x:482,y:704,t:1528143442752};\\\", \\\"{x:483,y:705,t:1528143442760};\\\", \\\"{x:482,y:705,t:1528143443488};\\\", \\\"{x:481,y:705,t:1528143443504};\\\" ] }, { \\\"rt\\\": 26802, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 7, \\\"time_elapsed\\\": 558311, \\\"internal_node_id\\\": \\\"0.0-5.0-2.0\\\", \\\"subject\\\": \\\"K0CNH\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 3, \\\"clicks\\\": 1, \\\"explicit\\\": 2, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"A\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:480,y:704,t:1528143445833};\\\", \\\"{x:480,y:703,t:1528143446169};\\\", \\\"{x:479,y:703,t:1528143466804};\\\", \\\"{x:474,y:703,t:1528143466811};\\\", \\\"{x:456,y:701,t:1528143466828};\\\", \\\"{x:423,y:697,t:1528143466846};\\\", \\\"{x:360,y:685,t:1528143466862};\\\", \\\"{x:304,y:677,t:1528143466878};\\\", \\\"{x:263,y:671,t:1528143466890};\\\", \\\"{x:221,y:665,t:1528143466908};\\\", \\\"{x:164,y:654,t:1528143466924};\\\", \\\"{x:116,y:648,t:1528143466941};\\\", \\\"{x:32,y:633,t:1528143466958};\\\", \\\"{x:0,y:611,t:1528143466979};\\\", \\\"{x:0,y:605,t:1528143466996};\\\", \\\"{x:0,y:600,t:1528143467011};\\\", \\\"{x:0,y:598,t:1528143467028};\\\", \\\"{x:0,y:597,t:1528143467045};\\\", \\\"{x:0,y:596,t:1528143467066};\\\", \\\"{x:0,y:594,t:1528143467079};\\\", \\\"{x:3,y:591,t:1528143467095};\\\", \\\"{x:6,y:588,t:1528143467111};\\\", \\\"{x:11,y:585,t:1528143467129};\\\", \\\"{x:23,y:581,t:1528143467145};\\\", \\\"{x:38,y:575,t:1528143467162};\\\", \\\"{x:73,y:568,t:1528143467180};\\\", \\\"{x:101,y:564,t:1528143467195};\\\", \\\"{x:123,y:561,t:1528143467211};\\\", \\\"{x:144,y:561,t:1528143467227};\\\", \\\"{x:165,y:561,t:1528143467245};\\\", \\\"{x:184,y:561,t:1528143467262};\\\", \\\"{x:208,y:561,t:1528143467279};\\\", \\\"{x:234,y:561,t:1528143467295};\\\", \\\"{x:261,y:561,t:1528143467311};\\\", \\\"{x:280,y:561,t:1528143467330};\\\", \\\"{x:291,y:558,t:1528143467345};\\\", \\\"{x:292,y:558,t:1528143467362};\\\", \\\"{x:293,y:558,t:1528143467411};\\\", \\\"{x:295,y:556,t:1528143467419};\\\", \\\"{x:297,y:553,t:1528143467428};\\\", \\\"{x:302,y:547,t:1528143467446};\\\", \\\"{x:303,y:544,t:1528143467463};\\\", \\\"{x:307,y:540,t:1528143467479};\\\", \\\"{x:310,y:534,t:1528143467496};\\\", \\\"{x:317,y:527,t:1528143467512};\\\", \\\"{x:328,y:519,t:1528143467529};\\\", \\\"{x:337,y:512,t:1528143467546};\\\", \\\"{x:345,y:507,t:1528143467563};\\\", \\\"{x:350,y:503,t:1528143467579};\\\", \\\"{x:352,y:501,t:1528143467596};\\\", \\\"{x:353,y:500,t:1528143467626};\\\", \\\"{x:354,y:500,t:1528143467667};\\\", \\\"{x:355,y:500,t:1528143467771};\\\", \\\"{x:356,y:500,t:1528143467851};\\\", \\\"{x:356,y:501,t:1528143467867};\\\", \\\"{x:357,y:503,t:1528143467879};\\\", \\\"{x:358,y:504,t:1528143467895};\\\", \\\"{x:360,y:508,t:1528143467913};\\\", \\\"{x:361,y:509,t:1528143467929};\\\", \\\"{x:363,y:511,t:1528143467945};\\\", \\\"{x:367,y:514,t:1528143467962};\\\", \\\"{x:369,y:515,t:1528143467980};\\\", \\\"{x:370,y:516,t:1528143467995};\\\", \\\"{x:373,y:517,t:1528143468012};\\\", \\\"{x:374,y:517,t:1528143468035};\\\", \\\"{x:375,y:522,t:1528143469931};\\\", \\\"{x:399,y:561,t:1528143469948};\\\", \\\"{x:436,y:612,t:1528143469966};\\\", \\\"{x:480,y:658,t:1528143469981};\\\", \\\"{x:524,y:685,t:1528143469998};\\\", \\\"{x:552,y:703,t:1528143470014};\\\", \\\"{x:573,y:719,t:1528143470031};\\\", \\\"{x:586,y:734,t:1528143470047};\\\", \\\"{x:595,y:746,t:1528143470064};\\\", \\\"{x:600,y:753,t:1528143470080};\\\", \\\"{x:601,y:756,t:1528143470097};\\\", \\\"{x:602,y:756,t:1528143470236};\\\", \\\"{x:601,y:753,t:1528143470248};\\\", \\\"{x:595,y:746,t:1528143470263};\\\", \\\"{x:588,y:739,t:1528143470281};\\\", \\\"{x:582,y:734,t:1528143470297};\\\", \\\"{x:573,y:726,t:1528143470314};\\\", \\\"{x:564,y:723,t:1528143470332};\\\", \\\"{x:563,y:723,t:1528143470347};\\\", \\\"{x:563,y:722,t:1528143470444};\\\", \\\"{x:561,y:722,t:1528143470451};\\\", \\\"{x:560,y:722,t:1528143470465};\\\", \\\"{x:557,y:721,t:1528143470482};\\\", \\\"{x:554,y:721,t:1528143470499};\\\", \\\"{x:553,y:721,t:1528143470523};\\\", \\\"{x:552,y:719,t:1528143470572};\\\", \\\"{x:551,y:719,t:1528143470643};\\\" ] }, { \\\"rt\\\": 11566, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 8, \\\"time_elapsed\\\": 571119, \\\"internal_node_id\\\": \\\"0.0-5.0-3.0\\\", \\\"subject\\\": \\\"K0CNH\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 4, \\\"clicks\\\": 1, \\\"explicit\\\": 2, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"H\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-04 PM-Z -K -07 PM-04 PM\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:559,y:719,t:1528143473460};\\\", \\\"{x:570,y:719,t:1528143473469};\\\", \\\"{x:595,y:719,t:1528143473484};\\\", \\\"{x:623,y:722,t:1528143473501};\\\", \\\"{x:651,y:727,t:1528143473517};\\\", \\\"{x:684,y:732,t:1528143473534};\\\", \\\"{x:716,y:737,t:1528143473551};\\\", \\\"{x:750,y:742,t:1528143473567};\\\", \\\"{x:791,y:747,t:1528143473584};\\\", \\\"{x:839,y:754,t:1528143473601};\\\", \\\"{x:894,y:760,t:1528143473618};\\\", \\\"{x:947,y:767,t:1528143473634};\\\", \\\"{x:1013,y:770,t:1528143473650};\\\", \\\"{x:1046,y:770,t:1528143473667};\\\", \\\"{x:1083,y:770,t:1528143473684};\\\", \\\"{x:1119,y:770,t:1528143473701};\\\", \\\"{x:1148,y:770,t:1528143473718};\\\", \\\"{x:1175,y:770,t:1528143473733};\\\", \\\"{x:1197,y:770,t:1528143473750};\\\", \\\"{x:1216,y:770,t:1528143473767};\\\", \\\"{x:1236,y:770,t:1528143473784};\\\", \\\"{x:1257,y:770,t:1528143473801};\\\", \\\"{x:1273,y:770,t:1528143473818};\\\", \\\"{x:1288,y:770,t:1528143473834};\\\", \\\"{x:1305,y:770,t:1528143473851};\\\", \\\"{x:1312,y:770,t:1528143473868};\\\", \\\"{x:1318,y:770,t:1528143473885};\\\", \\\"{x:1324,y:770,t:1528143473901};\\\", \\\"{x:1332,y:770,t:1528143473918};\\\", \\\"{x:1343,y:772,t:1528143473935};\\\", \\\"{x:1356,y:772,t:1528143473951};\\\", \\\"{x:1371,y:772,t:1528143473968};\\\", \\\"{x:1387,y:772,t:1528143473985};\\\", \\\"{x:1403,y:772,t:1528143474001};\\\", \\\"{x:1425,y:773,t:1528143474018};\\\", \\\"{x:1462,y:774,t:1528143474035};\\\", \\\"{x:1480,y:775,t:1528143474051};\\\", \\\"{x:1497,y:777,t:1528143474069};\\\", \\\"{x:1511,y:779,t:1528143474086};\\\", \\\"{x:1526,y:780,t:1528143474101};\\\", \\\"{x:1540,y:783,t:1528143474118};\\\", \\\"{x:1556,y:785,t:1528143474136};\\\", \\\"{x:1570,y:787,t:1528143474152};\\\", \\\"{x:1583,y:789,t:1528143474168};\\\", \\\"{x:1597,y:794,t:1528143474186};\\\", \\\"{x:1606,y:795,t:1528143474203};\\\", \\\"{x:1615,y:799,t:1528143474219};\\\", \\\"{x:1624,y:804,t:1528143474235};\\\", \\\"{x:1627,y:807,t:1528143474252};\\\", \\\"{x:1628,y:809,t:1528143474268};\\\", \\\"{x:1631,y:814,t:1528143474285};\\\", \\\"{x:1632,y:818,t:1528143474302};\\\", \\\"{x:1635,y:823,t:1528143474319};\\\", \\\"{x:1639,y:828,t:1528143474335};\\\", \\\"{x:1644,y:834,t:1528143474352};\\\", \\\"{x:1647,y:840,t:1528143474369};\\\", \\\"{x:1648,y:845,t:1528143474386};\\\", \\\"{x:1651,y:851,t:1528143474402};\\\", \\\"{x:1652,y:856,t:1528143474418};\\\", \\\"{x:1654,y:868,t:1528143474435};\\\", \\\"{x:1656,y:873,t:1528143474452};\\\", \\\"{x:1660,y:879,t:1528143474469};\\\", \\\"{x:1664,y:892,t:1528143474486};\\\", \\\"{x:1668,y:903,t:1528143474502};\\\", \\\"{x:1672,y:916,t:1528143474520};\\\", \\\"{x:1681,y:931,t:1528143474536};\\\", \\\"{x:1695,y:947,t:1528143474552};\\\", \\\"{x:1702,y:960,t:1528143474569};\\\", \\\"{x:1705,y:970,t:1528143474586};\\\", \\\"{x:1705,y:978,t:1528143474602};\\\", \\\"{x:1705,y:984,t:1528143474619};\\\", \\\"{x:1705,y:985,t:1528143474635};\\\", \\\"{x:1703,y:987,t:1528143474653};\\\", \\\"{x:1699,y:988,t:1528143474670};\\\", \\\"{x:1695,y:989,t:1528143474685};\\\", \\\"{x:1688,y:991,t:1528143474703};\\\", \\\"{x:1679,y:992,t:1528143474719};\\\", \\\"{x:1670,y:992,t:1528143474736};\\\", \\\"{x:1658,y:992,t:1528143474752};\\\", \\\"{x:1651,y:992,t:1528143474769};\\\", \\\"{x:1637,y:990,t:1528143474787};\\\", \\\"{x:1619,y:984,t:1528143474803};\\\", \\\"{x:1575,y:971,t:1528143474820};\\\", \\\"{x:1520,y:950,t:1528143474836};\\\", \\\"{x:1473,y:929,t:1528143474852};\\\", \\\"{x:1427,y:911,t:1528143474869};\\\", \\\"{x:1392,y:899,t:1528143474887};\\\", \\\"{x:1366,y:892,t:1528143474903};\\\", \\\"{x:1351,y:886,t:1528143474920};\\\", \\\"{x:1344,y:883,t:1528143474936};\\\", \\\"{x:1345,y:881,t:1528143474996};\\\", \\\"{x:1346,y:879,t:1528143475003};\\\", \\\"{x:1355,y:873,t:1528143475019};\\\", \\\"{x:1364,y:866,t:1528143475037};\\\", \\\"{x:1370,y:858,t:1528143475052};\\\", \\\"{x:1378,y:839,t:1528143475070};\\\", \\\"{x:1386,y:815,t:1528143475087};\\\", \\\"{x:1394,y:793,t:1528143475103};\\\", \\\"{x:1403,y:777,t:1528143475119};\\\", \\\"{x:1409,y:766,t:1528143475136};\\\", \\\"{x:1414,y:752,t:1528143475153};\\\", \\\"{x:1419,y:734,t:1528143475169};\\\", \\\"{x:1424,y:720,t:1528143475186};\\\", \\\"{x:1430,y:710,t:1528143475203};\\\", \\\"{x:1435,y:703,t:1528143475219};\\\", \\\"{x:1439,y:699,t:1528143475236};\\\", \\\"{x:1441,y:696,t:1528143475254};\\\", \\\"{x:1444,y:693,t:1528143475270};\\\", \\\"{x:1449,y:689,t:1528143475286};\\\", \\\"{x:1461,y:685,t:1528143475303};\\\", \\\"{x:1476,y:678,t:1528143475320};\\\", \\\"{x:1492,y:671,t:1528143475337};\\\", \\\"{x:1501,y:667,t:1528143475354};\\\", \\\"{x:1505,y:666,t:1528143475369};\\\", \\\"{x:1506,y:665,t:1528143475387};\\\", \\\"{x:1508,y:664,t:1528143475612};\\\", \\\"{x:1510,y:662,t:1528143475644};\\\", \\\"{x:1510,y:656,t:1528143475654};\\\", \\\"{x:1514,y:637,t:1528143475671};\\\", \\\"{x:1518,y:626,t:1528143475690};\\\", \\\"{x:1519,y:621,t:1528143475704};\\\", \\\"{x:1523,y:616,t:1528143475720};\\\", \\\"{x:1523,y:614,t:1528143475737};\\\", \\\"{x:1525,y:612,t:1528143475753};\\\", \\\"{x:1526,y:612,t:1528143475835};\\\", \\\"{x:1529,y:613,t:1528143475843};\\\", \\\"{x:1536,y:619,t:1528143475853};\\\", \\\"{x:1552,y:639,t:1528143475870};\\\", \\\"{x:1572,y:661,t:1528143475888};\\\", \\\"{x:1594,y:680,t:1528143475903};\\\", \\\"{x:1611,y:694,t:1528143475920};\\\", \\\"{x:1626,y:707,t:1528143475937};\\\", \\\"{x:1639,y:720,t:1528143475953};\\\", \\\"{x:1649,y:733,t:1528143475970};\\\", \\\"{x:1672,y:761,t:1528143475987};\\\", \\\"{x:1683,y:781,t:1528143476004};\\\", \\\"{x:1694,y:800,t:1528143476020};\\\", \\\"{x:1712,y:825,t:1528143476037};\\\", \\\"{x:1746,y:870,t:1528143476055};\\\", \\\"{x:1776,y:908,t:1528143476070};\\\", \\\"{x:1794,y:928,t:1528143476087};\\\", \\\"{x:1806,y:938,t:1528143476105};\\\", \\\"{x:1813,y:950,t:1528143476121};\\\", \\\"{x:1816,y:957,t:1528143476137};\\\", \\\"{x:1821,y:969,t:1528143476154};\\\", \\\"{x:1825,y:981,t:1528143476169};\\\", \\\"{x:1830,y:996,t:1528143476186};\\\", \\\"{x:1831,y:1001,t:1528143476204};\\\", \\\"{x:1833,y:1006,t:1528143476220};\\\", \\\"{x:1833,y:1009,t:1528143476236};\\\", \\\"{x:1833,y:1011,t:1528143476254};\\\", \\\"{x:1833,y:1012,t:1528143476271};\\\", \\\"{x:1828,y:1016,t:1528143476287};\\\", \\\"{x:1818,y:1020,t:1528143476304};\\\", \\\"{x:1805,y:1021,t:1528143476321};\\\", \\\"{x:1792,y:1022,t:1528143476337};\\\", \\\"{x:1775,y:1022,t:1528143476355};\\\", \\\"{x:1738,y:1022,t:1528143476370};\\\", \\\"{x:1713,y:1019,t:1528143476387};\\\", \\\"{x:1687,y:1014,t:1528143476404};\\\", \\\"{x:1665,y:1008,t:1528143476422};\\\", \\\"{x:1646,y:1002,t:1528143476437};\\\", \\\"{x:1634,y:998,t:1528143476454};\\\", \\\"{x:1626,y:994,t:1528143476471};\\\", \\\"{x:1623,y:992,t:1528143476487};\\\", \\\"{x:1623,y:991,t:1528143476515};\\\", \\\"{x:1623,y:990,t:1528143476523};\\\", \\\"{x:1623,y:988,t:1528143476537};\\\", \\\"{x:1623,y:987,t:1528143476554};\\\", \\\"{x:1623,y:984,t:1528143476571};\\\", \\\"{x:1624,y:981,t:1528143476588};\\\", \\\"{x:1624,y:979,t:1528143476604};\\\", \\\"{x:1624,y:976,t:1528143476621};\\\", \\\"{x:1625,y:973,t:1528143476639};\\\", \\\"{x:1625,y:972,t:1528143476654};\\\", \\\"{x:1625,y:969,t:1528143476671};\\\", \\\"{x:1625,y:968,t:1528143476689};\\\", \\\"{x:1625,y:967,t:1528143476704};\\\", \\\"{x:1625,y:966,t:1528143476721};\\\", \\\"{x:1625,y:965,t:1528143476738};\\\", \\\"{x:1624,y:965,t:1528143476812};\\\", \\\"{x:1622,y:965,t:1528143476827};\\\", \\\"{x:1621,y:965,t:1528143476843};\\\", \\\"{x:1620,y:965,t:1528143476855};\\\", \\\"{x:1617,y:965,t:1528143476872};\\\", \\\"{x:1616,y:964,t:1528143476940};\\\", \\\"{x:1614,y:962,t:1528143476956};\\\", \\\"{x:1613,y:960,t:1528143476979};\\\", \\\"{x:1613,y:959,t:1528143476997};\\\", \\\"{x:1613,y:958,t:1528143477005};\\\", \\\"{x:1613,y:957,t:1528143477021};\\\", \\\"{x:1613,y:955,t:1528143477038};\\\", \\\"{x:1613,y:954,t:1528143477067};\\\", \\\"{x:1613,y:953,t:1528143477090};\\\", \\\"{x:1613,y:951,t:1528143477428};\\\", \\\"{x:1613,y:949,t:1528143477439};\\\", \\\"{x:1613,y:946,t:1528143477455};\\\", \\\"{x:1613,y:943,t:1528143477473};\\\", \\\"{x:1613,y:941,t:1528143477490};\\\", \\\"{x:1611,y:938,t:1528143477506};\\\", \\\"{x:1611,y:936,t:1528143477523};\\\", \\\"{x:1609,y:930,t:1528143477540};\\\", \\\"{x:1607,y:925,t:1528143477556};\\\", \\\"{x:1605,y:921,t:1528143477573};\\\", \\\"{x:1604,y:918,t:1528143477589};\\\", \\\"{x:1603,y:916,t:1528143477606};\\\", \\\"{x:1602,y:914,t:1528143477623};\\\", \\\"{x:1600,y:911,t:1528143477640};\\\", \\\"{x:1600,y:908,t:1528143477656};\\\", \\\"{x:1598,y:899,t:1528143477672};\\\", \\\"{x:1591,y:888,t:1528143477690};\\\", \\\"{x:1586,y:880,t:1528143477706};\\\", \\\"{x:1583,y:876,t:1528143477723};\\\", \\\"{x:1582,y:875,t:1528143477740};\\\", \\\"{x:1582,y:874,t:1528143477756};\\\", \\\"{x:1580,y:872,t:1528143477773};\\\", \\\"{x:1578,y:869,t:1528143477790};\\\", \\\"{x:1574,y:865,t:1528143477806};\\\", \\\"{x:1571,y:861,t:1528143477822};\\\", \\\"{x:1568,y:858,t:1528143477839};\\\", \\\"{x:1567,y:856,t:1528143477856};\\\", \\\"{x:1565,y:855,t:1528143477872};\\\", \\\"{x:1564,y:852,t:1528143477889};\\\", \\\"{x:1561,y:848,t:1528143477906};\\\", \\\"{x:1556,y:842,t:1528143477922};\\\", \\\"{x:1552,y:835,t:1528143477939};\\\", \\\"{x:1549,y:831,t:1528143477956};\\\", \\\"{x:1548,y:829,t:1528143477972};\\\", \\\"{x:1547,y:827,t:1528143478036};\\\", \\\"{x:1547,y:826,t:1528143478051};\\\", \\\"{x:1546,y:825,t:1528143478059};\\\", \\\"{x:1545,y:824,t:1528143478092};\\\", \\\"{x:1545,y:823,t:1528143478107};\\\", \\\"{x:1544,y:820,t:1528143478123};\\\", \\\"{x:1542,y:817,t:1528143478139};\\\", \\\"{x:1540,y:815,t:1528143478156};\\\", \\\"{x:1539,y:813,t:1528143478173};\\\", \\\"{x:1538,y:812,t:1528143478189};\\\", \\\"{x:1537,y:811,t:1528143478206};\\\", \\\"{x:1536,y:810,t:1528143478223};\\\", \\\"{x:1536,y:808,t:1528143478240};\\\", \\\"{x:1536,y:807,t:1528143478256};\\\", \\\"{x:1535,y:807,t:1528143478274};\\\", \\\"{x:1535,y:806,t:1528143478372};\\\", \\\"{x:1535,y:804,t:1528143478390};\\\", \\\"{x:1534,y:801,t:1528143478407};\\\", \\\"{x:1532,y:799,t:1528143478424};\\\", \\\"{x:1531,y:796,t:1528143478441};\\\", \\\"{x:1530,y:795,t:1528143478457};\\\", \\\"{x:1530,y:793,t:1528143478491};\\\", \\\"{x:1528,y:791,t:1528143478508};\\\", \\\"{x:1528,y:790,t:1528143478523};\\\", \\\"{x:1526,y:789,t:1528143478541};\\\", \\\"{x:1526,y:787,t:1528143478557};\\\", \\\"{x:1526,y:786,t:1528143478574};\\\", \\\"{x:1526,y:785,t:1528143478592};\\\", \\\"{x:1526,y:784,t:1528143478607};\\\", \\\"{x:1526,y:783,t:1528143478624};\\\", \\\"{x:1526,y:781,t:1528143478644};\\\", \\\"{x:1525,y:779,t:1528143478676};\\\", \\\"{x:1525,y:777,t:1528143478700};\\\", \\\"{x:1523,y:776,t:1528143478707};\\\", \\\"{x:1522,y:773,t:1528143478724};\\\", \\\"{x:1521,y:768,t:1528143478741};\\\", \\\"{x:1519,y:766,t:1528143478758};\\\", \\\"{x:1518,y:762,t:1528143478774};\\\", \\\"{x:1516,y:759,t:1528143478791};\\\", \\\"{x:1515,y:759,t:1528143478808};\\\", \\\"{x:1515,y:758,t:1528143478824};\\\", \\\"{x:1514,y:755,t:1528143478841};\\\", \\\"{x:1512,y:752,t:1528143478858};\\\", \\\"{x:1511,y:749,t:1528143478874};\\\", \\\"{x:1508,y:743,t:1528143478891};\\\", \\\"{x:1504,y:737,t:1528143478908};\\\", \\\"{x:1502,y:734,t:1528143478925};\\\", \\\"{x:1499,y:730,t:1528143478940};\\\", \\\"{x:1493,y:723,t:1528143478958};\\\", \\\"{x:1488,y:717,t:1528143478974};\\\", \\\"{x:1485,y:713,t:1528143478991};\\\", \\\"{x:1483,y:709,t:1528143479007};\\\", \\\"{x:1482,y:707,t:1528143479025};\\\", \\\"{x:1480,y:702,t:1528143479041};\\\", \\\"{x:1476,y:698,t:1528143479057};\\\", \\\"{x:1472,y:691,t:1528143479075};\\\", \\\"{x:1467,y:684,t:1528143479090};\\\", \\\"{x:1462,y:677,t:1528143479107};\\\", \\\"{x:1459,y:674,t:1528143479125};\\\", \\\"{x:1454,y:674,t:1528143479141};\\\", \\\"{x:1440,y:674,t:1528143479158};\\\", \\\"{x:1412,y:676,t:1528143479175};\\\", \\\"{x:1347,y:690,t:1528143479191};\\\", \\\"{x:1236,y:704,t:1528143479208};\\\", \\\"{x:1111,y:710,t:1528143479224};\\\", \\\"{x:983,y:710,t:1528143479241};\\\", \\\"{x:859,y:710,t:1528143479258};\\\", \\\"{x:762,y:710,t:1528143479274};\\\", \\\"{x:689,y:710,t:1528143479291};\\\", \\\"{x:671,y:710,t:1528143479307};\\\", \\\"{x:666,y:709,t:1528143479324};\\\", \\\"{x:665,y:707,t:1528143479388};\\\", \\\"{x:663,y:707,t:1528143479395};\\\", \\\"{x:662,y:706,t:1528143479407};\\\", \\\"{x:661,y:705,t:1528143479425};\\\", \\\"{x:659,y:703,t:1528143479441};\\\", \\\"{x:654,y:696,t:1528143479457};\\\", \\\"{x:641,y:685,t:1528143479474};\\\", \\\"{x:628,y:676,t:1528143479491};\\\", \\\"{x:626,y:674,t:1528143479508};\\\", \\\"{x:625,y:671,t:1528143479524};\\\", \\\"{x:624,y:664,t:1528143479542};\\\", \\\"{x:624,y:660,t:1528143479557};\\\", \\\"{x:624,y:652,t:1528143479575};\\\", \\\"{x:624,y:646,t:1528143479594};\\\", \\\"{x:624,y:641,t:1528143479608};\\\", \\\"{x:638,y:616,t:1528143479642};\\\", \\\"{x:642,y:609,t:1528143479656};\\\", \\\"{x:643,y:607,t:1528143479673};\\\", \\\"{x:643,y:606,t:1528143479689};\\\", \\\"{x:643,y:604,t:1528143479778};\\\", \\\"{x:643,y:601,t:1528143479789};\\\", \\\"{x:642,y:596,t:1528143479805};\\\", \\\"{x:638,y:589,t:1528143479822};\\\", \\\"{x:636,y:586,t:1528143479839};\\\", \\\"{x:635,y:584,t:1528143479857};\\\", \\\"{x:634,y:583,t:1528143479872};\\\", \\\"{x:634,y:582,t:1528143479889};\\\", \\\"{x:634,y:579,t:1528143479907};\\\", \\\"{x:633,y:578,t:1528143479922};\\\", \\\"{x:633,y:577,t:1528143479939};\\\", \\\"{x:632,y:576,t:1528143479963};\\\", \\\"{x:631,y:576,t:1528143479980};\\\", \\\"{x:631,y:574,t:1528143480021};\\\", \\\"{x:630,y:573,t:1528143480043};\\\", \\\"{x:630,y:572,t:1528143480100};\\\", \\\"{x:630,y:571,t:1528143480115};\\\", \\\"{x:630,y:570,t:1528143480123};\\\", \\\"{x:629,y:570,t:1528143480139};\\\", \\\"{x:628,y:569,t:1528143480158};\\\", \\\"{x:628,y:568,t:1528143480258};\\\", \\\"{x:628,y:567,t:1528143480291};\\\", \\\"{x:628,y:566,t:1528143481572};\\\", \\\"{x:627,y:565,t:1528143482051};\\\", \\\"{x:627,y:564,t:1528143482059};\\\", \\\"{x:625,y:563,t:1528143482073};\\\", \\\"{x:625,y:560,t:1528143482090};\\\", \\\"{x:624,y:558,t:1528143482107};\\\", \\\"{x:624,y:557,t:1528143482124};\\\", \\\"{x:623,y:556,t:1528143482147};\\\", \\\"{x:622,y:556,t:1528143482562};\\\", \\\"{x:622,y:556,t:1528143482567};\\\", \\\"{x:619,y:556,t:1528143482594};\\\", \\\"{x:613,y:563,t:1528143482608};\\\", \\\"{x:599,y:586,t:1528143482624};\\\", \\\"{x:566,y:629,t:1528143482641};\\\", \\\"{x:533,y:656,t:1528143482659};\\\", \\\"{x:517,y:672,t:1528143482675};\\\", \\\"{x:517,y:673,t:1528143482698};\\\", \\\"{x:517,y:674,t:1528143482938};\\\", \\\"{x:518,y:677,t:1528143482963};\\\", \\\"{x:518,y:679,t:1528143482975};\\\", \\\"{x:518,y:683,t:1528143482991};\\\", \\\"{x:519,y:687,t:1528143483008};\\\", \\\"{x:520,y:688,t:1528143483025};\\\", \\\"{x:520,y:689,t:1528143483067};\\\", \\\"{x:520,y:690,t:1528143483074};\\\", \\\"{x:520,y:699,t:1528143483092};\\\", \\\"{x:520,y:712,t:1528143483110};\\\", \\\"{x:518,y:726,t:1528143483126};\\\", \\\"{x:516,y:737,t:1528143483143};\\\", \\\"{x:514,y:740,t:1528143483158};\\\", \\\"{x:514,y:741,t:1528143483176};\\\", \\\"{x:514,y:742,t:1528143483191};\\\", \\\"{x:514,y:743,t:1528143483209};\\\", \\\"{x:514,y:742,t:1528143483459};\\\", \\\"{x:514,y:738,t:1528143483476};\\\", \\\"{x:514,y:736,t:1528143483493};\\\", \\\"{x:514,y:734,t:1528143483510};\\\", \\\"{x:514,y:733,t:1528143483525};\\\", \\\"{x:514,y:731,t:1528143483541};\\\", \\\"{x:514,y:730,t:1528143483562};\\\", \\\"{x:514,y:729,t:1528143483576};\\\", \\\"{x:515,y:728,t:1528143483591};\\\", \\\"{x:515,y:727,t:1528143483608};\\\", \\\"{x:515,y:726,t:1528143483625};\\\" ] }, { \\\"rt\\\": 24612, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 9, \\\"time_elapsed\\\": 596967, \\\"internal_node_id\\\": \\\"0.0-5.0-4.0\\\", \\\"subject\\\": \\\"K0CNH\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 5, \\\"clicks\\\": 1, \\\"explicit\\\": 2, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"O\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-02 PM-02 PM-03 PM-I -O \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:513,y:726,t:1528143486028};\\\", \\\"{x:497,y:726,t:1528143486046};\\\", \\\"{x:472,y:726,t:1528143486061};\\\", \\\"{x:440,y:726,t:1528143486079};\\\", \\\"{x:396,y:721,t:1528143486095};\\\", \\\"{x:356,y:709,t:1528143486110};\\\", \\\"{x:327,y:701,t:1528143486127};\\\", \\\"{x:309,y:696,t:1528143486144};\\\", \\\"{x:289,y:689,t:1528143486160};\\\", \\\"{x:261,y:679,t:1528143486178};\\\", \\\"{x:200,y:658,t:1528143486195};\\\", \\\"{x:142,y:632,t:1528143486211};\\\", \\\"{x:66,y:606,t:1528143486228};\\\", \\\"{x:0,y:587,t:1528143486245};\\\", \\\"{x:0,y:573,t:1528143486260};\\\", \\\"{x:0,y:567,t:1528143486277};\\\", \\\"{x:0,y:561,t:1528143486295};\\\", \\\"{x:0,y:555,t:1528143486310};\\\", \\\"{x:0,y:544,t:1528143486327};\\\", \\\"{x:0,y:527,t:1528143486344};\\\", \\\"{x:0,y:512,t:1528143486361};\\\", \\\"{x:0,y:498,t:1528143486378};\\\", \\\"{x:0,y:472,t:1528143486395};\\\", \\\"{x:4,y:458,t:1528143486411};\\\", \\\"{x:12,y:445,t:1528143486428};\\\", \\\"{x:25,y:435,t:1528143486445};\\\", \\\"{x:46,y:425,t:1528143486462};\\\", \\\"{x:91,y:412,t:1528143486478};\\\", \\\"{x:144,y:404,t:1528143486495};\\\", \\\"{x:204,y:394,t:1528143486512};\\\", \\\"{x:246,y:389,t:1528143486527};\\\", \\\"{x:266,y:389,t:1528143486545};\\\", \\\"{x:278,y:389,t:1528143486562};\\\", \\\"{x:287,y:389,t:1528143486577};\\\", \\\"{x:296,y:389,t:1528143486595};\\\", \\\"{x:305,y:387,t:1528143486611};\\\", \\\"{x:321,y:387,t:1528143486628};\\\", \\\"{x:342,y:387,t:1528143486644};\\\", \\\"{x:358,y:387,t:1528143486661};\\\", \\\"{x:369,y:387,t:1528143486678};\\\", \\\"{x:373,y:387,t:1528143486694};\\\", \\\"{x:375,y:387,t:1528143486731};\\\", \\\"{x:376,y:388,t:1528143486745};\\\", \\\"{x:381,y:394,t:1528143486762};\\\", \\\"{x:389,y:400,t:1528143486778};\\\", \\\"{x:397,y:405,t:1528143486795};\\\", \\\"{x:405,y:410,t:1528143486811};\\\", \\\"{x:410,y:413,t:1528143486827};\\\", \\\"{x:418,y:418,t:1528143486845};\\\", \\\"{x:427,y:424,t:1528143486862};\\\", \\\"{x:437,y:429,t:1528143486879};\\\", \\\"{x:446,y:433,t:1528143486894};\\\", \\\"{x:459,y:438,t:1528143486912};\\\", \\\"{x:468,y:442,t:1528143486929};\\\", \\\"{x:479,y:444,t:1528143486945};\\\", \\\"{x:486,y:447,t:1528143486962};\\\", \\\"{x:492,y:448,t:1528143486979};\\\", \\\"{x:497,y:450,t:1528143486995};\\\", \\\"{x:500,y:451,t:1528143487012};\\\", \\\"{x:506,y:452,t:1528143487029};\\\", \\\"{x:515,y:455,t:1528143487044};\\\", \\\"{x:523,y:455,t:1528143487062};\\\", \\\"{x:531,y:455,t:1528143487079};\\\", \\\"{x:539,y:455,t:1528143487095};\\\", \\\"{x:546,y:455,t:1528143487112};\\\", \\\"{x:555,y:456,t:1528143487129};\\\", \\\"{x:565,y:456,t:1528143487145};\\\", \\\"{x:576,y:456,t:1528143487162};\\\", \\\"{x:594,y:456,t:1528143487179};\\\", \\\"{x:602,y:456,t:1528143487195};\\\", \\\"{x:611,y:456,t:1528143487211};\\\", \\\"{x:621,y:457,t:1528143487228};\\\", \\\"{x:633,y:458,t:1528143487245};\\\", \\\"{x:644,y:458,t:1528143487261};\\\", \\\"{x:656,y:458,t:1528143487279};\\\", \\\"{x:662,y:458,t:1528143487295};\\\", \\\"{x:668,y:458,t:1528143487312};\\\", \\\"{x:674,y:458,t:1528143487329};\\\", \\\"{x:676,y:458,t:1528143487346};\\\", \\\"{x:677,y:458,t:1528143487361};\\\", \\\"{x:678,y:459,t:1528143487403};\\\", \\\"{x:678,y:460,t:1528143487419};\\\", \\\"{x:677,y:462,t:1528143487429};\\\", \\\"{x:674,y:463,t:1528143487446};\\\", \\\"{x:668,y:466,t:1528143487462};\\\", \\\"{x:652,y:468,t:1528143487479};\\\", \\\"{x:636,y:471,t:1528143487496};\\\", \\\"{x:620,y:473,t:1528143487512};\\\", \\\"{x:601,y:476,t:1528143487529};\\\", \\\"{x:585,y:478,t:1528143487546};\\\", \\\"{x:574,y:479,t:1528143487562};\\\", \\\"{x:557,y:483,t:1528143487579};\\\", \\\"{x:544,y:486,t:1528143487595};\\\", \\\"{x:537,y:487,t:1528143487612};\\\", \\\"{x:530,y:488,t:1528143487628};\\\", \\\"{x:524,y:490,t:1528143487645};\\\", \\\"{x:521,y:490,t:1528143487662};\\\", \\\"{x:516,y:491,t:1528143487679};\\\", \\\"{x:510,y:492,t:1528143487696};\\\", \\\"{x:502,y:492,t:1528143487713};\\\", \\\"{x:489,y:495,t:1528143487728};\\\", \\\"{x:473,y:496,t:1528143487746};\\\", \\\"{x:453,y:497,t:1528143487763};\\\", \\\"{x:442,y:497,t:1528143487779};\\\", \\\"{x:434,y:497,t:1528143487795};\\\", \\\"{x:425,y:497,t:1528143487813};\\\", \\\"{x:415,y:497,t:1528143487829};\\\", \\\"{x:407,y:499,t:1528143487846};\\\", \\\"{x:401,y:500,t:1528143487863};\\\", \\\"{x:396,y:501,t:1528143487878};\\\", \\\"{x:393,y:501,t:1528143487896};\\\", \\\"{x:391,y:501,t:1528143487913};\\\", \\\"{x:390,y:501,t:1528143487931};\\\", \\\"{x:387,y:501,t:1528143487946};\\\", \\\"{x:383,y:503,t:1528143487964};\\\", \\\"{x:380,y:503,t:1528143487979};\\\", \\\"{x:379,y:503,t:1528143487995};\\\", \\\"{x:378,y:503,t:1528143488027};\\\", \\\"{x:377,y:503,t:1528143488051};\\\", \\\"{x:377,y:501,t:1528143488067};\\\", \\\"{x:377,y:500,t:1528143488079};\\\", \\\"{x:378,y:497,t:1528143488096};\\\", \\\"{x:379,y:493,t:1528143488113};\\\", \\\"{x:380,y:492,t:1528143488128};\\\", \\\"{x:381,y:490,t:1528143488146};\\\", \\\"{x:384,y:487,t:1528143488163};\\\", \\\"{x:385,y:486,t:1528143488179};\\\", \\\"{x:386,y:485,t:1528143488195};\\\", \\\"{x:388,y:485,t:1528143488219};\\\", \\\"{x:388,y:484,t:1528143488230};\\\", \\\"{x:390,y:483,t:1528143488245};\\\", \\\"{x:398,y:480,t:1528143488263};\\\", \\\"{x:404,y:479,t:1528143488280};\\\", \\\"{x:410,y:478,t:1528143488296};\\\", \\\"{x:421,y:476,t:1528143488313};\\\", \\\"{x:428,y:475,t:1528143488330};\\\", \\\"{x:436,y:475,t:1528143488346};\\\", \\\"{x:446,y:474,t:1528143488363};\\\", \\\"{x:451,y:474,t:1528143488380};\\\", \\\"{x:455,y:474,t:1528143488396};\\\", \\\"{x:457,y:474,t:1528143488413};\\\", \\\"{x:460,y:474,t:1528143488430};\\\", \\\"{x:464,y:474,t:1528143488446};\\\", \\\"{x:472,y:474,t:1528143488463};\\\", \\\"{x:484,y:474,t:1528143488480};\\\", \\\"{x:497,y:474,t:1528143488495};\\\", \\\"{x:506,y:474,t:1528143488513};\\\", \\\"{x:512,y:474,t:1528143488530};\\\", \\\"{x:518,y:474,t:1528143488545};\\\", \\\"{x:531,y:474,t:1528143488562};\\\", \\\"{x:536,y:474,t:1528143488579};\\\", \\\"{x:533,y:476,t:1528143488635};\\\", \\\"{x:528,y:477,t:1528143488647};\\\", \\\"{x:513,y:481,t:1528143488663};\\\", \\\"{x:490,y:487,t:1528143488680};\\\", \\\"{x:470,y:490,t:1528143488697};\\\", \\\"{x:450,y:492,t:1528143488712};\\\", \\\"{x:429,y:492,t:1528143488730};\\\", \\\"{x:397,y:497,t:1528143488746};\\\", \\\"{x:379,y:499,t:1528143488763};\\\", \\\"{x:367,y:502,t:1528143488780};\\\", \\\"{x:363,y:503,t:1528143488797};\\\", \\\"{x:361,y:503,t:1528143488813};\\\", \\\"{x:363,y:503,t:1528143488938};\\\", \\\"{x:369,y:502,t:1528143488946};\\\", \\\"{x:384,y:501,t:1528143488964};\\\", \\\"{x:399,y:500,t:1528143488979};\\\", \\\"{x:420,y:500,t:1528143488996};\\\", \\\"{x:443,y:500,t:1528143489013};\\\", \\\"{x:462,y:500,t:1528143489029};\\\", \\\"{x:474,y:500,t:1528143489046};\\\", \\\"{x:481,y:500,t:1528143489063};\\\", \\\"{x:483,y:500,t:1528143489080};\\\", \\\"{x:485,y:500,t:1528143489096};\\\", \\\"{x:485,y:499,t:1528143489113};\\\", \\\"{x:487,y:499,t:1528143489130};\\\", \\\"{x:492,y:499,t:1528143489147};\\\", \\\"{x:497,y:499,t:1528143489163};\\\", \\\"{x:503,y:499,t:1528143489180};\\\", \\\"{x:511,y:499,t:1528143489196};\\\", \\\"{x:519,y:499,t:1528143489214};\\\", \\\"{x:526,y:499,t:1528143489230};\\\", \\\"{x:531,y:499,t:1528143489246};\\\", \\\"{x:535,y:499,t:1528143489264};\\\", \\\"{x:538,y:499,t:1528143489280};\\\", \\\"{x:542,y:499,t:1528143489297};\\\", \\\"{x:547,y:499,t:1528143489314};\\\", \\\"{x:551,y:499,t:1528143489330};\\\", \\\"{x:556,y:499,t:1528143489346};\\\", \\\"{x:561,y:499,t:1528143489364};\\\", \\\"{x:565,y:499,t:1528143489379};\\\", \\\"{x:566,y:499,t:1528143489396};\\\", \\\"{x:564,y:499,t:1528143489508};\\\", \\\"{x:561,y:499,t:1528143489515};\\\", \\\"{x:556,y:499,t:1528143489531};\\\", \\\"{x:551,y:500,t:1528143489547};\\\", \\\"{x:546,y:500,t:1528143489564};\\\", \\\"{x:541,y:500,t:1528143489581};\\\", \\\"{x:540,y:501,t:1528143489597};\\\", \\\"{x:541,y:501,t:1528143489875};\\\", \\\"{x:542,y:501,t:1528143489883};\\\", \\\"{x:543,y:501,t:1528143489899};\\\", \\\"{x:544,y:501,t:1528143489913};\\\", \\\"{x:545,y:501,t:1528143489931};\\\", \\\"{x:546,y:501,t:1528143490091};\\\", \\\"{x:547,y:501,t:1528143490099};\\\", \\\"{x:549,y:501,t:1528143490114};\\\", \\\"{x:552,y:501,t:1528143490131};\\\", \\\"{x:557,y:501,t:1528143490147};\\\", \\\"{x:564,y:501,t:1528143490164};\\\", \\\"{x:571,y:500,t:1528143490181};\\\", \\\"{x:583,y:498,t:1528143490198};\\\", \\\"{x:602,y:494,t:1528143490214};\\\", \\\"{x:622,y:490,t:1528143490231};\\\", \\\"{x:649,y:485,t:1528143490248};\\\", \\\"{x:678,y:483,t:1528143490264};\\\", \\\"{x:705,y:483,t:1528143490281};\\\", \\\"{x:731,y:482,t:1528143490298};\\\", \\\"{x:762,y:482,t:1528143490314};\\\", \\\"{x:820,y:482,t:1528143490331};\\\", \\\"{x:879,y:482,t:1528143490348};\\\", \\\"{x:945,y:482,t:1528143490365};\\\", \\\"{x:1026,y:482,t:1528143490382};\\\", \\\"{x:1107,y:482,t:1528143490398};\\\", \\\"{x:1195,y:482,t:1528143490415};\\\", \\\"{x:1276,y:482,t:1528143490431};\\\", \\\"{x:1362,y:482,t:1528143490449};\\\", \\\"{x:1429,y:482,t:1528143490465};\\\", \\\"{x:1472,y:482,t:1528143490481};\\\", \\\"{x:1498,y:484,t:1528143490498};\\\", \\\"{x:1516,y:486,t:1528143490515};\\\", \\\"{x:1521,y:487,t:1528143490531};\\\", \\\"{x:1521,y:488,t:1528143490548};\\\", \\\"{x:1522,y:489,t:1528143490595};\\\", \\\"{x:1523,y:490,t:1528143490611};\\\", \\\"{x:1524,y:491,t:1528143490619};\\\", \\\"{x:1524,y:492,t:1528143490631};\\\", \\\"{x:1524,y:495,t:1528143490648};\\\", \\\"{x:1525,y:496,t:1528143490665};\\\", \\\"{x:1525,y:500,t:1528143490682};\\\", \\\"{x:1527,y:505,t:1528143490698};\\\", \\\"{x:1527,y:511,t:1528143490715};\\\", \\\"{x:1527,y:513,t:1528143490731};\\\", \\\"{x:1527,y:515,t:1528143490779};\\\", \\\"{x:1527,y:516,t:1528143490787};\\\", \\\"{x:1524,y:517,t:1528143490797};\\\", \\\"{x:1517,y:518,t:1528143490814};\\\", \\\"{x:1502,y:522,t:1528143490832};\\\", \\\"{x:1479,y:523,t:1528143490847};\\\", \\\"{x:1454,y:523,t:1528143490864};\\\", \\\"{x:1427,y:523,t:1528143490882};\\\", \\\"{x:1407,y:523,t:1528143490898};\\\", \\\"{x:1377,y:523,t:1528143490914};\\\", \\\"{x:1363,y:523,t:1528143490932};\\\", \\\"{x:1350,y:523,t:1528143490948};\\\", \\\"{x:1341,y:523,t:1528143490965};\\\", \\\"{x:1333,y:523,t:1528143490982};\\\", \\\"{x:1330,y:523,t:1528143490998};\\\", \\\"{x:1325,y:523,t:1528143491015};\\\", \\\"{x:1319,y:523,t:1528143491032};\\\", \\\"{x:1317,y:523,t:1528143491048};\\\", \\\"{x:1316,y:523,t:1528143491065};\\\", \\\"{x:1313,y:523,t:1528143491082};\\\", \\\"{x:1312,y:523,t:1528143491098};\\\", \\\"{x:1311,y:523,t:1528143491147};\\\", \\\"{x:1311,y:520,t:1528143491165};\\\", \\\"{x:1310,y:517,t:1528143491183};\\\", \\\"{x:1310,y:516,t:1528143491198};\\\", \\\"{x:1309,y:515,t:1528143491275};\\\", \\\"{x:1308,y:515,t:1528143491283};\\\", \\\"{x:1305,y:518,t:1528143491299};\\\", \\\"{x:1300,y:523,t:1528143491315};\\\", \\\"{x:1293,y:527,t:1528143491333};\\\", \\\"{x:1285,y:531,t:1528143491349};\\\", \\\"{x:1282,y:532,t:1528143491365};\\\", \\\"{x:1280,y:534,t:1528143491383};\\\", \\\"{x:1278,y:536,t:1528143491399};\\\", \\\"{x:1277,y:537,t:1528143491415};\\\", \\\"{x:1275,y:540,t:1528143491432};\\\", \\\"{x:1273,y:544,t:1528143491449};\\\", \\\"{x:1269,y:548,t:1528143491465};\\\", \\\"{x:1265,y:553,t:1528143491482};\\\", \\\"{x:1261,y:560,t:1528143491499};\\\", \\\"{x:1257,y:565,t:1528143491515};\\\", \\\"{x:1253,y:570,t:1528143491532};\\\", \\\"{x:1250,y:580,t:1528143491549};\\\", \\\"{x:1248,y:597,t:1528143491566};\\\", \\\"{x:1244,y:616,t:1528143491582};\\\", \\\"{x:1239,y:635,t:1528143491599};\\\", \\\"{x:1234,y:656,t:1528143491615};\\\", \\\"{x:1228,y:673,t:1528143491632};\\\", \\\"{x:1224,y:690,t:1528143491649};\\\", \\\"{x:1222,y:709,t:1528143491665};\\\", \\\"{x:1222,y:727,t:1528143491682};\\\", \\\"{x:1218,y:753,t:1528143491699};\\\", \\\"{x:1215,y:765,t:1528143491715};\\\", \\\"{x:1212,y:773,t:1528143491732};\\\", \\\"{x:1210,y:780,t:1528143491749};\\\", \\\"{x:1209,y:785,t:1528143491766};\\\", \\\"{x:1208,y:795,t:1528143491782};\\\", \\\"{x:1206,y:809,t:1528143491799};\\\", \\\"{x:1203,y:821,t:1528143491816};\\\", \\\"{x:1199,y:832,t:1528143491832};\\\", \\\"{x:1194,y:842,t:1528143491849};\\\", \\\"{x:1189,y:850,t:1528143491866};\\\", \\\"{x:1181,y:861,t:1528143491882};\\\", \\\"{x:1171,y:874,t:1528143491899};\\\", \\\"{x:1164,y:884,t:1528143491916};\\\", \\\"{x:1157,y:892,t:1528143491932};\\\", \\\"{x:1150,y:898,t:1528143491949};\\\", \\\"{x:1141,y:907,t:1528143491966};\\\", \\\"{x:1135,y:915,t:1528143491982};\\\", \\\"{x:1127,y:924,t:1528143491999};\\\", \\\"{x:1122,y:929,t:1528143492016};\\\", \\\"{x:1117,y:933,t:1528143492032};\\\", \\\"{x:1115,y:936,t:1528143492049};\\\", \\\"{x:1113,y:939,t:1528143492066};\\\", \\\"{x:1111,y:944,t:1528143492082};\\\", \\\"{x:1109,y:948,t:1528143492099};\\\", \\\"{x:1109,y:949,t:1528143492116};\\\", \\\"{x:1108,y:949,t:1528143492132};\\\", \\\"{x:1105,y:954,t:1528143492149};\\\", \\\"{x:1102,y:956,t:1528143492166};\\\", \\\"{x:1099,y:958,t:1528143492182};\\\", \\\"{x:1097,y:959,t:1528143492199};\\\", \\\"{x:1096,y:959,t:1528143492216};\\\", \\\"{x:1095,y:959,t:1528143492233};\\\", \\\"{x:1094,y:959,t:1528143492267};\\\", \\\"{x:1095,y:955,t:1528143492283};\\\", \\\"{x:1096,y:949,t:1528143492299};\\\", \\\"{x:1107,y:931,t:1528143492316};\\\", \\\"{x:1127,y:903,t:1528143492333};\\\", \\\"{x:1150,y:881,t:1528143492349};\\\", \\\"{x:1175,y:856,t:1528143492366};\\\", \\\"{x:1193,y:833,t:1528143492383};\\\", \\\"{x:1214,y:806,t:1528143492399};\\\", \\\"{x:1233,y:781,t:1528143492416};\\\", \\\"{x:1254,y:750,t:1528143492434};\\\", \\\"{x:1276,y:715,t:1528143492450};\\\", \\\"{x:1292,y:674,t:1528143492467};\\\", \\\"{x:1297,y:653,t:1528143492483};\\\", \\\"{x:1300,y:642,t:1528143492498};\\\", \\\"{x:1302,y:623,t:1528143492515};\\\", \\\"{x:1307,y:599,t:1528143492532};\\\", \\\"{x:1312,y:574,t:1528143492549};\\\", \\\"{x:1318,y:556,t:1528143492565};\\\", \\\"{x:1323,y:536,t:1528143492582};\\\", \\\"{x:1329,y:516,t:1528143492599};\\\", \\\"{x:1332,y:505,t:1528143492615};\\\", \\\"{x:1336,y:492,t:1528143492632};\\\", \\\"{x:1336,y:483,t:1528143492650};\\\", \\\"{x:1336,y:471,t:1528143492665};\\\", \\\"{x:1336,y:465,t:1528143492683};\\\", \\\"{x:1336,y:464,t:1528143492700};\\\", \\\"{x:1336,y:462,t:1528143492716};\\\", \\\"{x:1336,y:458,t:1528143492733};\\\", \\\"{x:1338,y:462,t:1528143492787};\\\", \\\"{x:1342,y:475,t:1528143492800};\\\", \\\"{x:1354,y:516,t:1528143492816};\\\", \\\"{x:1365,y:555,t:1528143492833};\\\", \\\"{x:1376,y:583,t:1528143492850};\\\", \\\"{x:1390,y:614,t:1528143492866};\\\", \\\"{x:1403,y:657,t:1528143492882};\\\", \\\"{x:1412,y:685,t:1528143492899};\\\", \\\"{x:1416,y:706,t:1528143492915};\\\", \\\"{x:1417,y:723,t:1528143492932};\\\", \\\"{x:1418,y:741,t:1528143492950};\\\", \\\"{x:1420,y:765,t:1528143492966};\\\", \\\"{x:1420,y:787,t:1528143492983};\\\", \\\"{x:1420,y:807,t:1528143493000};\\\", \\\"{x:1421,y:831,t:1528143493017};\\\", \\\"{x:1421,y:856,t:1528143493033};\\\", \\\"{x:1426,y:889,t:1528143493050};\\\", \\\"{x:1437,y:931,t:1528143493067};\\\", \\\"{x:1447,y:956,t:1528143493083};\\\", \\\"{x:1457,y:972,t:1528143493100};\\\", \\\"{x:1465,y:982,t:1528143493118};\\\", \\\"{x:1473,y:987,t:1528143493134};\\\", \\\"{x:1483,y:993,t:1528143493149};\\\", \\\"{x:1486,y:995,t:1528143493167};\\\", \\\"{x:1489,y:997,t:1528143493183};\\\", \\\"{x:1489,y:998,t:1528143493199};\\\", \\\"{x:1490,y:999,t:1528143493219};\\\", \\\"{x:1491,y:1001,t:1528143493259};\\\", \\\"{x:1493,y:1001,t:1528143493274};\\\", \\\"{x:1494,y:1001,t:1528143493292};\\\", \\\"{x:1495,y:1001,t:1528143493300};\\\", \\\"{x:1497,y:1000,t:1528143493318};\\\", \\\"{x:1497,y:999,t:1528143493347};\\\", \\\"{x:1497,y:998,t:1528143493363};\\\", \\\"{x:1497,y:997,t:1528143493379};\\\", \\\"{x:1497,y:996,t:1528143493387};\\\", \\\"{x:1497,y:995,t:1528143493399};\\\", \\\"{x:1497,y:992,t:1528143493417};\\\", \\\"{x:1497,y:991,t:1528143493434};\\\", \\\"{x:1497,y:989,t:1528143493484};\\\", \\\"{x:1497,y:986,t:1528143493564};\\\", \\\"{x:1498,y:985,t:1528143493571};\\\", \\\"{x:1500,y:983,t:1528143493584};\\\", \\\"{x:1503,y:979,t:1528143493601};\\\", \\\"{x:1503,y:978,t:1528143493617};\\\", \\\"{x:1504,y:977,t:1528143493634};\\\", \\\"{x:1505,y:977,t:1528143493683};\\\", \\\"{x:1507,y:976,t:1528143493700};\\\", \\\"{x:1510,y:976,t:1528143493717};\\\", \\\"{x:1513,y:975,t:1528143493734};\\\", \\\"{x:1520,y:973,t:1528143493750};\\\", \\\"{x:1534,y:970,t:1528143493767};\\\", \\\"{x:1549,y:969,t:1528143493784};\\\", \\\"{x:1563,y:968,t:1528143493801};\\\", \\\"{x:1569,y:968,t:1528143493817};\\\", \\\"{x:1574,y:968,t:1528143493833};\\\", \\\"{x:1575,y:968,t:1528143493849};\\\", \\\"{x:1575,y:967,t:1528143494052};\\\", \\\"{x:1575,y:966,t:1528143494067};\\\", \\\"{x:1575,y:963,t:1528143494085};\\\", \\\"{x:1574,y:962,t:1528143494102};\\\", \\\"{x:1572,y:960,t:1528143494117};\\\", \\\"{x:1570,y:957,t:1528143494134};\\\", \\\"{x:1567,y:954,t:1528143494151};\\\", \\\"{x:1564,y:951,t:1528143494167};\\\", \\\"{x:1559,y:947,t:1528143494184};\\\", \\\"{x:1555,y:944,t:1528143494201};\\\", \\\"{x:1549,y:938,t:1528143494217};\\\", \\\"{x:1542,y:932,t:1528143494234};\\\", \\\"{x:1530,y:921,t:1528143494251};\\\", \\\"{x:1523,y:915,t:1528143494269};\\\", \\\"{x:1510,y:904,t:1528143494284};\\\", \\\"{x:1497,y:888,t:1528143494302};\\\", \\\"{x:1484,y:863,t:1528143494317};\\\", \\\"{x:1467,y:836,t:1528143494334};\\\", \\\"{x:1456,y:819,t:1528143494350};\\\", \\\"{x:1451,y:810,t:1528143494367};\\\", \\\"{x:1443,y:799,t:1528143494383};\\\", \\\"{x:1436,y:784,t:1528143494400};\\\", \\\"{x:1428,y:762,t:1528143494417};\\\", \\\"{x:1420,y:741,t:1528143494433};\\\", \\\"{x:1401,y:704,t:1528143494451};\\\", \\\"{x:1393,y:693,t:1528143494468};\\\", \\\"{x:1388,y:687,t:1528143494483};\\\", \\\"{x:1385,y:685,t:1528143494501};\\\", \\\"{x:1383,y:683,t:1528143494517};\\\", \\\"{x:1381,y:681,t:1528143494533};\\\", \\\"{x:1376,y:681,t:1528143494550};\\\", \\\"{x:1367,y:685,t:1528143494567};\\\", \\\"{x:1355,y:700,t:1528143494584};\\\", \\\"{x:1342,y:714,t:1528143494600};\\\", \\\"{x:1331,y:727,t:1528143494617};\\\", \\\"{x:1324,y:736,t:1528143494634};\\\", \\\"{x:1320,y:739,t:1528143494651};\\\", \\\"{x:1319,y:739,t:1528143494714};\\\", \\\"{x:1319,y:732,t:1528143494730};\\\", \\\"{x:1319,y:728,t:1528143494738};\\\", \\\"{x:1319,y:722,t:1528143494750};\\\", \\\"{x:1319,y:706,t:1528143494767};\\\", \\\"{x:1319,y:686,t:1528143494784};\\\", \\\"{x:1321,y:662,t:1528143494800};\\\", \\\"{x:1327,y:632,t:1528143494818};\\\", \\\"{x:1334,y:592,t:1528143494834};\\\", \\\"{x:1338,y:569,t:1528143494850};\\\", \\\"{x:1340,y:543,t:1528143494868};\\\", \\\"{x:1340,y:527,t:1528143494885};\\\", \\\"{x:1340,y:522,t:1528143494900};\\\", \\\"{x:1340,y:520,t:1528143494917};\\\", \\\"{x:1340,y:519,t:1528143494934};\\\", \\\"{x:1340,y:513,t:1528143494950};\\\", \\\"{x:1337,y:507,t:1528143494967};\\\", \\\"{x:1333,y:498,t:1528143494984};\\\", \\\"{x:1331,y:495,t:1528143495001};\\\", \\\"{x:1330,y:494,t:1528143495017};\\\", \\\"{x:1328,y:494,t:1528143495034};\\\", \\\"{x:1327,y:494,t:1528143495051};\\\", \\\"{x:1323,y:494,t:1528143495068};\\\", \\\"{x:1319,y:496,t:1528143495085};\\\", \\\"{x:1315,y:504,t:1528143495101};\\\", \\\"{x:1309,y:514,t:1528143495118};\\\", \\\"{x:1304,y:525,t:1528143495134};\\\", \\\"{x:1302,y:531,t:1528143495151};\\\", \\\"{x:1302,y:535,t:1528143495167};\\\", \\\"{x:1301,y:538,t:1528143495185};\\\", \\\"{x:1301,y:539,t:1528143495202};\\\", \\\"{x:1301,y:541,t:1528143495218};\\\", \\\"{x:1301,y:545,t:1528143495234};\\\", \\\"{x:1301,y:548,t:1528143495252};\\\", \\\"{x:1301,y:551,t:1528143495268};\\\", \\\"{x:1301,y:556,t:1528143495285};\\\", \\\"{x:1301,y:559,t:1528143495302};\\\", \\\"{x:1301,y:564,t:1528143495318};\\\", \\\"{x:1301,y:567,t:1528143495335};\\\", \\\"{x:1301,y:569,t:1528143495353};\\\", \\\"{x:1301,y:570,t:1528143495368};\\\", \\\"{x:1301,y:572,t:1528143495385};\\\", \\\"{x:1300,y:573,t:1528143495627};\\\", \\\"{x:1300,y:575,t:1528143495635};\\\", \\\"{x:1300,y:577,t:1528143495659};\\\", \\\"{x:1299,y:577,t:1528143495669};\\\", \\\"{x:1299,y:578,t:1528143495690};\\\", \\\"{x:1299,y:579,t:1528143495707};\\\", \\\"{x:1299,y:580,t:1528143495719};\\\", \\\"{x:1299,y:581,t:1528143495735};\\\", \\\"{x:1299,y:582,t:1528143495755};\\\", \\\"{x:1299,y:583,t:1528143495779};\\\", \\\"{x:1299,y:581,t:1528143495940};\\\", \\\"{x:1299,y:575,t:1528143495952};\\\", \\\"{x:1300,y:562,t:1528143495969};\\\", \\\"{x:1300,y:549,t:1528143495985};\\\", \\\"{x:1300,y:538,t:1528143496002};\\\", \\\"{x:1300,y:522,t:1528143496018};\\\", \\\"{x:1300,y:513,t:1528143496035};\\\", \\\"{x:1299,y:507,t:1528143496052};\\\", \\\"{x:1299,y:503,t:1528143496069};\\\", \\\"{x:1299,y:501,t:1528143496086};\\\", \\\"{x:1296,y:503,t:1528143496164};\\\", \\\"{x:1294,y:506,t:1528143496171};\\\", \\\"{x:1291,y:509,t:1528143496187};\\\", \\\"{x:1287,y:520,t:1528143496202};\\\", \\\"{x:1287,y:527,t:1528143496219};\\\", \\\"{x:1287,y:532,t:1528143496236};\\\", \\\"{x:1287,y:537,t:1528143496252};\\\", \\\"{x:1287,y:541,t:1528143496269};\\\", \\\"{x:1287,y:542,t:1528143496286};\\\", \\\"{x:1287,y:546,t:1528143496302};\\\", \\\"{x:1288,y:549,t:1528143496319};\\\", \\\"{x:1290,y:552,t:1528143496337};\\\", \\\"{x:1291,y:558,t:1528143496352};\\\", \\\"{x:1294,y:563,t:1528143496370};\\\", \\\"{x:1295,y:569,t:1528143496387};\\\", \\\"{x:1299,y:577,t:1528143496402};\\\", \\\"{x:1304,y:591,t:1528143496419};\\\", \\\"{x:1307,y:598,t:1528143496436};\\\", \\\"{x:1310,y:604,t:1528143496452};\\\", \\\"{x:1312,y:608,t:1528143496469};\\\", \\\"{x:1315,y:611,t:1528143496486};\\\", \\\"{x:1315,y:613,t:1528143496503};\\\", \\\"{x:1318,y:617,t:1528143496519};\\\", \\\"{x:1319,y:619,t:1528143496537};\\\", \\\"{x:1321,y:621,t:1528143496553};\\\", \\\"{x:1322,y:625,t:1528143496569};\\\", \\\"{x:1323,y:628,t:1528143496586};\\\", \\\"{x:1323,y:630,t:1528143496611};\\\", \\\"{x:1323,y:631,t:1528143496651};\\\", \\\"{x:1323,y:630,t:1528143496892};\\\", \\\"{x:1323,y:628,t:1528143496903};\\\", \\\"{x:1323,y:625,t:1528143496920};\\\", \\\"{x:1323,y:621,t:1528143496937};\\\", \\\"{x:1323,y:616,t:1528143496953};\\\", \\\"{x:1323,y:605,t:1528143496970};\\\", \\\"{x:1326,y:586,t:1528143496987};\\\", \\\"{x:1328,y:554,t:1528143497003};\\\", \\\"{x:1330,y:540,t:1528143497021};\\\", \\\"{x:1330,y:531,t:1528143497036};\\\", \\\"{x:1330,y:519,t:1528143497054};\\\", \\\"{x:1330,y:512,t:1528143497070};\\\", \\\"{x:1330,y:508,t:1528143497087};\\\", \\\"{x:1330,y:506,t:1528143497107};\\\", \\\"{x:1330,y:516,t:1528143497219};\\\", \\\"{x:1325,y:545,t:1528143497237};\\\", \\\"{x:1319,y:571,t:1528143497254};\\\", \\\"{x:1312,y:594,t:1528143497270};\\\", \\\"{x:1306,y:610,t:1528143497287};\\\", \\\"{x:1295,y:630,t:1528143497304};\\\", \\\"{x:1282,y:650,t:1528143497320};\\\", \\\"{x:1268,y:665,t:1528143497336};\\\", \\\"{x:1258,y:674,t:1528143497353};\\\", \\\"{x:1242,y:684,t:1528143497371};\\\", \\\"{x:1222,y:689,t:1528143497387};\\\", \\\"{x:1186,y:695,t:1528143497404};\\\", \\\"{x:1153,y:695,t:1528143497420};\\\", \\\"{x:1080,y:695,t:1528143497437};\\\", \\\"{x:1022,y:695,t:1528143497454};\\\", \\\"{x:999,y:695,t:1528143497470};\\\", \\\"{x:984,y:691,t:1528143497488};\\\", \\\"{x:969,y:684,t:1528143497503};\\\", \\\"{x:951,y:677,t:1528143497520};\\\", \\\"{x:931,y:670,t:1528143497537};\\\", \\\"{x:896,y:661,t:1528143497553};\\\", \\\"{x:843,y:645,t:1528143497570};\\\", \\\"{x:748,y:628,t:1528143497587};\\\", \\\"{x:689,y:616,t:1528143497605};\\\", \\\"{x:635,y:607,t:1528143497620};\\\", \\\"{x:592,y:602,t:1528143497653};\\\", \\\"{x:589,y:602,t:1528143497669};\\\", \\\"{x:585,y:602,t:1528143497686};\\\", \\\"{x:581,y:604,t:1528143497703};\\\", \\\"{x:575,y:608,t:1528143497719};\\\", \\\"{x:570,y:613,t:1528143497735};\\\", \\\"{x:566,y:618,t:1528143497752};\\\", \\\"{x:558,y:627,t:1528143497770};\\\", \\\"{x:550,y:640,t:1528143497787};\\\", \\\"{x:549,y:641,t:1528143497803};\\\", \\\"{x:549,y:642,t:1528143497820};\\\", \\\"{x:549,y:643,t:1528143497837};\\\", \\\"{x:549,y:644,t:1528143497858};\\\", \\\"{x:550,y:643,t:1528143497939};\\\", \\\"{x:553,y:642,t:1528143497954};\\\", \\\"{x:564,y:635,t:1528143497970};\\\", \\\"{x:575,y:630,t:1528143497987};\\\", \\\"{x:590,y:623,t:1528143498005};\\\", \\\"{x:603,y:618,t:1528143498022};\\\", \\\"{x:612,y:614,t:1528143498037};\\\", \\\"{x:614,y:614,t:1528143498054};\\\", \\\"{x:615,y:613,t:1528143498070};\\\", \\\"{x:617,y:612,t:1528143498099};\\\", \\\"{x:622,y:612,t:1528143498107};\\\", \\\"{x:628,y:612,t:1528143498120};\\\", \\\"{x:650,y:610,t:1528143498138};\\\", \\\"{x:678,y:605,t:1528143498154};\\\", \\\"{x:738,y:597,t:1528143498171};\\\", \\\"{x:795,y:586,t:1528143498187};\\\", \\\"{x:865,y:572,t:1528143498204};\\\", \\\"{x:925,y:549,t:1528143498222};\\\", \\\"{x:952,y:535,t:1528143498237};\\\", \\\"{x:956,y:532,t:1528143498254};\\\", \\\"{x:958,y:532,t:1528143498271};\\\", \\\"{x:956,y:528,t:1528143498298};\\\", \\\"{x:950,y:526,t:1528143498306};\\\", \\\"{x:943,y:523,t:1528143498320};\\\", \\\"{x:928,y:517,t:1528143498337};\\\", \\\"{x:896,y:512,t:1528143498354};\\\", \\\"{x:881,y:511,t:1528143498370};\\\", \\\"{x:876,y:511,t:1528143498386};\\\", \\\"{x:875,y:511,t:1528143498404};\\\", \\\"{x:872,y:511,t:1528143498420};\\\", \\\"{x:868,y:513,t:1528143498437};\\\", \\\"{x:865,y:517,t:1528143498454};\\\", \\\"{x:862,y:520,t:1528143498471};\\\", \\\"{x:860,y:521,t:1528143498488};\\\", \\\"{x:859,y:521,t:1528143498651};\\\", \\\"{x:857,y:522,t:1528143498683};\\\", \\\"{x:855,y:523,t:1528143498716};\\\", \\\"{x:854,y:523,t:1528143498838};\\\", \\\"{x:852,y:523,t:1528143498866};\\\", \\\"{x:844,y:530,t:1528143498874};\\\", \\\"{x:833,y:539,t:1528143498888};\\\", \\\"{x:812,y:556,t:1528143498905};\\\", \\\"{x:798,y:569,t:1528143498921};\\\", \\\"{x:795,y:573,t:1528143498938};\\\", \\\"{x:793,y:573,t:1528143498985};\\\", \\\"{x:790,y:573,t:1528143499002};\\\", \\\"{x:788,y:573,t:1528143499011};\\\", \\\"{x:787,y:573,t:1528143499021};\\\", \\\"{x:783,y:573,t:1528143499038};\\\", \\\"{x:779,y:576,t:1528143499055};\\\", \\\"{x:776,y:579,t:1528143499070};\\\", \\\"{x:771,y:584,t:1528143499088};\\\", \\\"{x:766,y:590,t:1528143499105};\\\", \\\"{x:762,y:596,t:1528143499122};\\\", \\\"{x:758,y:602,t:1528143499138};\\\", \\\"{x:742,y:611,t:1528143499155};\\\", \\\"{x:730,y:617,t:1528143499171};\\\", \\\"{x:721,y:621,t:1528143499190};\\\", \\\"{x:717,y:624,t:1528143499205};\\\", \\\"{x:715,y:626,t:1528143499221};\\\", \\\"{x:713,y:630,t:1528143499239};\\\", \\\"{x:711,y:636,t:1528143499255};\\\", \\\"{x:708,y:644,t:1528143499271};\\\", \\\"{x:705,y:649,t:1528143499288};\\\", \\\"{x:704,y:651,t:1528143499305};\\\", \\\"{x:703,y:654,t:1528143499321};\\\", \\\"{x:702,y:655,t:1528143499339};\\\", \\\"{x:701,y:659,t:1528143499355};\\\", \\\"{x:701,y:661,t:1528143499371};\\\", \\\"{x:700,y:662,t:1528143499388};\\\", \\\"{x:699,y:665,t:1528143499406};\\\", \\\"{x:697,y:668,t:1528143499421};\\\", \\\"{x:696,y:673,t:1528143499438};\\\", \\\"{x:693,y:679,t:1528143499455};\\\", \\\"{x:689,y:687,t:1528143499473};\\\", \\\"{x:686,y:696,t:1528143499489};\\\", \\\"{x:680,y:705,t:1528143499505};\\\", \\\"{x:673,y:712,t:1528143499522};\\\", \\\"{x:662,y:720,t:1528143499539};\\\", \\\"{x:649,y:727,t:1528143499555};\\\", \\\"{x:645,y:729,t:1528143499572};\\\", \\\"{x:643,y:729,t:1528143499588};\\\", \\\"{x:642,y:730,t:1528143499605};\\\", \\\"{x:640,y:730,t:1528143499635};\\\", \\\"{x:639,y:730,t:1528143499650};\\\", \\\"{x:639,y:731,t:1528143499659};\\\", \\\"{x:638,y:731,t:1528143499672};\\\", \\\"{x:636,y:732,t:1528143499688};\\\", \\\"{x:632,y:733,t:1528143499706};\\\", \\\"{x:629,y:734,t:1528143499722};\\\", \\\"{x:621,y:736,t:1528143499738};\\\", \\\"{x:609,y:739,t:1528143499756};\\\", \\\"{x:601,y:742,t:1528143499772};\\\", \\\"{x:596,y:743,t:1528143499789};\\\", \\\"{x:588,y:748,t:1528143499805};\\\", \\\"{x:583,y:748,t:1528143499822};\\\", \\\"{x:580,y:750,t:1528143499838};\\\", \\\"{x:579,y:751,t:1528143499856};\\\", \\\"{x:577,y:752,t:1528143499873};\\\", \\\"{x:576,y:753,t:1528143499888};\\\", \\\"{x:574,y:754,t:1528143499906};\\\", \\\"{x:569,y:755,t:1528143499922};\\\", \\\"{x:562,y:758,t:1528143499940};\\\", \\\"{x:552,y:761,t:1528143499955};\\\", \\\"{x:541,y:763,t:1528143499972};\\\", \\\"{x:535,y:763,t:1528143499990};\\\", \\\"{x:527,y:764,t:1528143500006};\\\", \\\"{x:521,y:764,t:1528143500023};\\\", \\\"{x:518,y:764,t:1528143500040};\\\", \\\"{x:517,y:764,t:1528143500074};\\\", \\\"{x:516,y:764,t:1528143500218};\\\", \\\"{x:513,y:762,t:1528143500226};\\\", \\\"{x:511,y:761,t:1528143500238};\\\", \\\"{x:506,y:757,t:1528143500255};\\\", \\\"{x:504,y:754,t:1528143500272};\\\", \\\"{x:503,y:752,t:1528143500289};\\\", \\\"{x:502,y:751,t:1528143500305};\\\", \\\"{x:502,y:750,t:1528143500322};\\\", \\\"{x:502,y:748,t:1528143500812};\\\", \\\"{x:502,y:747,t:1528143500823};\\\", \\\"{x:502,y:744,t:1528143500839};\\\", \\\"{x:501,y:742,t:1528143500856};\\\", \\\"{x:501,y:740,t:1528143500874};\\\", \\\"{x:499,y:738,t:1528143500889};\\\", \\\"{x:499,y:737,t:1528143500906};\\\", \\\"{x:498,y:735,t:1528143500923};\\\", \\\"{x:497,y:734,t:1528143500940};\\\", \\\"{x:497,y:732,t:1528143505587};\\\", \\\"{x:497,y:731,t:1528143510226};\\\", \\\"{x:497,y:730,t:1528143510233};\\\", \\\"{x:497,y:728,t:1528143510246};\\\", \\\"{x:498,y:725,t:1528143510263};\\\", \\\"{x:498,y:724,t:1528143510280};\\\" ] }, { \\\"rt\\\": 56474, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 10, \\\"time_elapsed\\\": 654722, \\\"internal_node_id\\\": \\\"0.0-6.0-0.0\\\", \\\"subject\\\": \\\"K0CNH\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration\\\", \\\"q\\\": 6, \\\"clicks\\\": 2.5, \\\"explicit\\\": 2, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\", \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-09 AM-I -02 PM-01 PM-09 AM-10 AM-11 AM-12 PM-01 PM-02 PM-02 PM-02 PM-J -J -J -11 AM-12 PM-11 AM-10 AM-09 AM-0-09 AM-10 AM-11 AM-11 AM-12 PM-12 PM-01 PM-H -G -G -02 PM-01 PM-02 PM-03 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:498,y:722,t:1528143511323};\\\", \\\"{x:499,y:722,t:1528143511340};\\\", \\\"{x:500,y:721,t:1528143511354};\\\", \\\"{x:501,y:721,t:1528143511364};\\\", \\\"{x:503,y:719,t:1528143511382};\\\", \\\"{x:505,y:718,t:1528143511397};\\\", \\\"{x:510,y:716,t:1528143511414};\\\", \\\"{x:516,y:713,t:1528143511431};\\\", \\\"{x:522,y:709,t:1528143511447};\\\", \\\"{x:529,y:706,t:1528143511464};\\\", \\\"{x:540,y:702,t:1528143511481};\\\", \\\"{x:548,y:696,t:1528143511497};\\\", \\\"{x:562,y:692,t:1528143511514};\\\", \\\"{x:575,y:687,t:1528143511532};\\\", \\\"{x:593,y:681,t:1528143511547};\\\", \\\"{x:616,y:676,t:1528143511564};\\\", \\\"{x:639,y:671,t:1528143511582};\\\", \\\"{x:665,y:668,t:1528143511597};\\\", \\\"{x:693,y:662,t:1528143511615};\\\", \\\"{x:719,y:656,t:1528143511631};\\\", \\\"{x:741,y:652,t:1528143511649};\\\", \\\"{x:764,y:647,t:1528143511664};\\\", \\\"{x:783,y:641,t:1528143511682};\\\", \\\"{x:806,y:634,t:1528143511699};\\\", \\\"{x:818,y:628,t:1528143511716};\\\", \\\"{x:832,y:621,t:1528143511731};\\\", \\\"{x:848,y:615,t:1528143511748};\\\", \\\"{x:861,y:609,t:1528143511765};\\\", \\\"{x:870,y:605,t:1528143511782};\\\", \\\"{x:876,y:601,t:1528143511798};\\\", \\\"{x:883,y:596,t:1528143511815};\\\", \\\"{x:890,y:591,t:1528143511832};\\\", \\\"{x:894,y:585,t:1528143511849};\\\", \\\"{x:897,y:579,t:1528143511864};\\\", \\\"{x:899,y:568,t:1528143511881};\\\", \\\"{x:903,y:539,t:1528143511898};\\\", \\\"{x:898,y:532,t:1528143511914};\\\", \\\"{x:887,y:524,t:1528143511932};\\\", \\\"{x:865,y:517,t:1528143511949};\\\", \\\"{x:823,y:510,t:1528143511966};\\\", \\\"{x:767,y:502,t:1528143511982};\\\", \\\"{x:701,y:499,t:1528143511999};\\\", \\\"{x:649,y:494,t:1528143512015};\\\", \\\"{x:596,y:494,t:1528143512032};\\\", \\\"{x:549,y:494,t:1528143512048};\\\", \\\"{x:522,y:494,t:1528143512065};\\\", \\\"{x:506,y:494,t:1528143512082};\\\", \\\"{x:490,y:494,t:1528143512099};\\\", \\\"{x:485,y:494,t:1528143512115};\\\", \\\"{x:484,y:494,t:1528143512139};\\\", \\\"{x:483,y:495,t:1528143512148};\\\", \\\"{x:482,y:495,t:1528143512171};\\\", \\\"{x:484,y:495,t:1528143512371};\\\", \\\"{x:489,y:494,t:1528143512381};\\\", \\\"{x:502,y:490,t:1528143512401};\\\", \\\"{x:516,y:487,t:1528143512415};\\\", \\\"{x:533,y:485,t:1528143512433};\\\", \\\"{x:548,y:482,t:1528143512449};\\\", \\\"{x:562,y:481,t:1528143512465};\\\", \\\"{x:586,y:476,t:1528143512482};\\\", \\\"{x:597,y:476,t:1528143512498};\\\", \\\"{x:605,y:476,t:1528143512515};\\\", \\\"{x:609,y:476,t:1528143512532};\\\", \\\"{x:612,y:476,t:1528143512549};\\\", \\\"{x:613,y:476,t:1528143512626};\\\", \\\"{x:614,y:476,t:1528143512634};\\\", \\\"{x:615,y:476,t:1528143512649};\\\", \\\"{x:617,y:476,t:1528143512665};\\\", \\\"{x:621,y:476,t:1528143512683};\\\", \\\"{x:624,y:476,t:1528143512698};\\\", \\\"{x:625,y:476,t:1528143512716};\\\", \\\"{x:628,y:476,t:1528143512732};\\\", \\\"{x:629,y:476,t:1528143512762};\\\", \\\"{x:630,y:476,t:1528143512807};\\\", \\\"{x:631,y:476,t:1528143512822};\\\", \\\"{x:632,y:476,t:1528143512836};\\\", \\\"{x:635,y:476,t:1528143512853};\\\", \\\"{x:643,y:476,t:1528143512869};\\\", \\\"{x:655,y:476,t:1528143512886};\\\", \\\"{x:664,y:476,t:1528143512903};\\\", \\\"{x:672,y:476,t:1528143512919};\\\", \\\"{x:679,y:476,t:1528143512937};\\\", \\\"{x:687,y:476,t:1528143512954};\\\", \\\"{x:701,y:476,t:1528143512970};\\\", \\\"{x:714,y:476,t:1528143512987};\\\", \\\"{x:727,y:476,t:1528143513004};\\\", \\\"{x:734,y:476,t:1528143513019};\\\", \\\"{x:740,y:476,t:1528143513037};\\\", \\\"{x:746,y:477,t:1528143513053};\\\", \\\"{x:757,y:480,t:1528143513069};\\\", \\\"{x:778,y:481,t:1528143513086};\\\", \\\"{x:793,y:481,t:1528143513104};\\\", \\\"{x:807,y:481,t:1528143513120};\\\", \\\"{x:821,y:481,t:1528143513137};\\\", \\\"{x:836,y:481,t:1528143513154};\\\", \\\"{x:849,y:481,t:1528143513170};\\\", \\\"{x:867,y:481,t:1528143513187};\\\", \\\"{x:885,y:481,t:1528143513204};\\\", \\\"{x:905,y:481,t:1528143513219};\\\", \\\"{x:927,y:481,t:1528143513237};\\\", \\\"{x:952,y:481,t:1528143513254};\\\", \\\"{x:973,y:481,t:1528143513270};\\\", \\\"{x:1005,y:481,t:1528143513287};\\\", \\\"{x:1028,y:482,t:1528143513304};\\\", \\\"{x:1047,y:482,t:1528143513320};\\\", \\\"{x:1072,y:483,t:1528143513337};\\\", \\\"{x:1096,y:488,t:1528143513354};\\\", \\\"{x:1128,y:494,t:1528143513370};\\\", \\\"{x:1154,y:497,t:1528143513388};\\\", \\\"{x:1180,y:501,t:1528143513404};\\\", \\\"{x:1206,y:505,t:1528143513420};\\\", \\\"{x:1230,y:512,t:1528143513437};\\\", \\\"{x:1249,y:517,t:1528143513454};\\\", \\\"{x:1266,y:523,t:1528143513470};\\\", \\\"{x:1285,y:527,t:1528143513487};\\\", \\\"{x:1299,y:530,t:1528143513504};\\\", \\\"{x:1308,y:531,t:1528143513521};\\\", \\\"{x:1319,y:535,t:1528143513538};\\\", \\\"{x:1326,y:539,t:1528143513554};\\\", \\\"{x:1333,y:546,t:1528143513571};\\\", \\\"{x:1344,y:554,t:1528143513588};\\\", \\\"{x:1353,y:559,t:1528143513604};\\\", \\\"{x:1368,y:568,t:1528143513622};\\\", \\\"{x:1382,y:574,t:1528143513638};\\\", \\\"{x:1393,y:581,t:1528143513654};\\\", \\\"{x:1411,y:594,t:1528143513671};\\\", \\\"{x:1425,y:610,t:1528143513687};\\\", \\\"{x:1435,y:630,t:1528143513704};\\\", \\\"{x:1442,y:648,t:1528143513721};\\\", \\\"{x:1444,y:666,t:1528143513737};\\\", \\\"{x:1446,y:682,t:1528143513754};\\\", \\\"{x:1447,y:700,t:1528143513771};\\\", \\\"{x:1448,y:716,t:1528143513787};\\\", \\\"{x:1448,y:731,t:1528143513804};\\\", \\\"{x:1448,y:745,t:1528143513821};\\\", \\\"{x:1448,y:758,t:1528143513837};\\\", \\\"{x:1446,y:772,t:1528143513855};\\\", \\\"{x:1435,y:796,t:1528143513871};\\\", \\\"{x:1430,y:805,t:1528143513887};\\\", \\\"{x:1427,y:806,t:1528143513905};\\\", \\\"{x:1426,y:807,t:1528143514552};\\\", \\\"{x:1424,y:807,t:1528143514655};\\\", \\\"{x:1424,y:808,t:1528143514702};\\\", \\\"{x:1423,y:808,t:1528143514710};\\\", \\\"{x:1421,y:809,t:1528143514721};\\\", \\\"{x:1419,y:811,t:1528143514738};\\\", \\\"{x:1414,y:814,t:1528143514755};\\\", \\\"{x:1409,y:818,t:1528143514771};\\\", \\\"{x:1403,y:822,t:1528143514788};\\\", \\\"{x:1398,y:827,t:1528143514804};\\\", \\\"{x:1395,y:830,t:1528143514821};\\\", \\\"{x:1391,y:831,t:1528143514838};\\\", \\\"{x:1388,y:834,t:1528143514855};\\\", \\\"{x:1386,y:836,t:1528143514872};\\\", \\\"{x:1385,y:837,t:1528143514888};\\\", \\\"{x:1383,y:839,t:1528143514905};\\\", \\\"{x:1378,y:842,t:1528143514922};\\\", \\\"{x:1371,y:846,t:1528143514938};\\\", \\\"{x:1362,y:853,t:1528143514955};\\\", \\\"{x:1351,y:859,t:1528143514972};\\\", \\\"{x:1339,y:867,t:1528143514988};\\\", \\\"{x:1328,y:873,t:1528143515005};\\\", \\\"{x:1316,y:880,t:1528143515023};\\\", \\\"{x:1301,y:889,t:1528143515038};\\\", \\\"{x:1278,y:901,t:1528143515055};\\\", \\\"{x:1268,y:906,t:1528143515073};\\\", \\\"{x:1256,y:911,t:1528143515088};\\\", \\\"{x:1245,y:915,t:1528143515105};\\\", \\\"{x:1237,y:916,t:1528143515122};\\\", \\\"{x:1228,y:918,t:1528143515138};\\\", \\\"{x:1217,y:920,t:1528143515154};\\\", \\\"{x:1204,y:923,t:1528143515173};\\\", \\\"{x:1194,y:924,t:1528143515188};\\\", \\\"{x:1183,y:928,t:1528143515205};\\\", \\\"{x:1176,y:930,t:1528143515222};\\\", \\\"{x:1161,y:934,t:1528143515238};\\\", \\\"{x:1145,y:945,t:1528143515255};\\\", \\\"{x:1144,y:955,t:1528143515273};\\\", \\\"{x:1142,y:967,t:1528143515289};\\\", \\\"{x:1142,y:988,t:1528143515305};\\\", \\\"{x:1144,y:1009,t:1528143515322};\\\", \\\"{x:1136,y:1017,t:1528143515338};\\\", \\\"{x:1125,y:1022,t:1528143515355};\\\", \\\"{x:1123,y:1022,t:1528143515373};\\\", \\\"{x:1122,y:1022,t:1528143515831};\\\", \\\"{x:1121,y:1022,t:1528143515911};\\\", \\\"{x:1121,y:1020,t:1528143515935};\\\", \\\"{x:1122,y:1018,t:1528143515951};\\\", \\\"{x:1123,y:1017,t:1528143515959};\\\", \\\"{x:1124,y:1013,t:1528143515973};\\\", \\\"{x:1126,y:1007,t:1528143515989};\\\", \\\"{x:1128,y:1002,t:1528143516006};\\\", \\\"{x:1128,y:1001,t:1528143516023};\\\", \\\"{x:1132,y:991,t:1528143516039};\\\", \\\"{x:1135,y:985,t:1528143516057};\\\", \\\"{x:1138,y:976,t:1528143516073};\\\", \\\"{x:1143,y:970,t:1528143516089};\\\", \\\"{x:1146,y:962,t:1528143516107};\\\", \\\"{x:1153,y:954,t:1528143516123};\\\", \\\"{x:1156,y:948,t:1528143516140};\\\", \\\"{x:1157,y:944,t:1528143516157};\\\", \\\"{x:1160,y:938,t:1528143516172};\\\", \\\"{x:1165,y:927,t:1528143516189};\\\", \\\"{x:1168,y:915,t:1528143516207};\\\", \\\"{x:1175,y:898,t:1528143516222};\\\", \\\"{x:1182,y:879,t:1528143516239};\\\", \\\"{x:1186,y:872,t:1528143516256};\\\", \\\"{x:1186,y:867,t:1528143516272};\\\", \\\"{x:1187,y:863,t:1528143516289};\\\", \\\"{x:1189,y:853,t:1528143516306};\\\", \\\"{x:1189,y:839,t:1528143516324};\\\", \\\"{x:1189,y:835,t:1528143516340};\\\", \\\"{x:1189,y:832,t:1528143516356};\\\", \\\"{x:1189,y:829,t:1528143516374};\\\", \\\"{x:1189,y:826,t:1528143516389};\\\", \\\"{x:1189,y:824,t:1528143516406};\\\", \\\"{x:1189,y:822,t:1528143516422};\\\", \\\"{x:1188,y:822,t:1528143516439};\\\", \\\"{x:1188,y:821,t:1528143516550};\\\", \\\"{x:1188,y:820,t:1528143516559};\\\", \\\"{x:1188,y:819,t:1528143516574};\\\", \\\"{x:1188,y:817,t:1528143516589};\\\", \\\"{x:1188,y:813,t:1528143516606};\\\", \\\"{x:1188,y:809,t:1528143516623};\\\", \\\"{x:1188,y:807,t:1528143516640};\\\", \\\"{x:1188,y:804,t:1528143516656};\\\", \\\"{x:1188,y:803,t:1528143516674};\\\", \\\"{x:1188,y:801,t:1528143516688};\\\", \\\"{x:1188,y:797,t:1528143516706};\\\", \\\"{x:1187,y:793,t:1528143516723};\\\", \\\"{x:1187,y:789,t:1528143516739};\\\", \\\"{x:1185,y:780,t:1528143516756};\\\", \\\"{x:1185,y:776,t:1528143516773};\\\", \\\"{x:1184,y:772,t:1528143516790};\\\", \\\"{x:1184,y:771,t:1528143516807};\\\", \\\"{x:1183,y:766,t:1528143516825};\\\", \\\"{x:1183,y:763,t:1528143516840};\\\", \\\"{x:1182,y:762,t:1528143516855};\\\", \\\"{x:1182,y:761,t:1528143518544};\\\", \\\"{x:1182,y:760,t:1528143518558};\\\", \\\"{x:1185,y:760,t:1528143518574};\\\", \\\"{x:1189,y:760,t:1528143518592};\\\", \\\"{x:1194,y:762,t:1528143518607};\\\", \\\"{x:1203,y:764,t:1528143518624};\\\", \\\"{x:1216,y:766,t:1528143518641};\\\", \\\"{x:1230,y:768,t:1528143518658};\\\", \\\"{x:1243,y:769,t:1528143518674};\\\", \\\"{x:1258,y:770,t:1528143518691};\\\", \\\"{x:1272,y:771,t:1528143518708};\\\", \\\"{x:1282,y:771,t:1528143518724};\\\", \\\"{x:1289,y:773,t:1528143518741};\\\", \\\"{x:1297,y:774,t:1528143518758};\\\", \\\"{x:1299,y:774,t:1528143518774};\\\", \\\"{x:1302,y:774,t:1528143518791};\\\", \\\"{x:1305,y:774,t:1528143518808};\\\", \\\"{x:1309,y:775,t:1528143518824};\\\", \\\"{x:1311,y:776,t:1528143518841};\\\", \\\"{x:1313,y:776,t:1528143518858};\\\", \\\"{x:1316,y:778,t:1528143518873};\\\", \\\"{x:1320,y:779,t:1528143518890};\\\", \\\"{x:1324,y:781,t:1528143518908};\\\", \\\"{x:1326,y:781,t:1528143518924};\\\", \\\"{x:1330,y:782,t:1528143518941};\\\", \\\"{x:1331,y:783,t:1528143518958};\\\", \\\"{x:1332,y:783,t:1528143518974};\\\", \\\"{x:1332,y:784,t:1528143519278};\\\", \\\"{x:1332,y:785,t:1528143519302};\\\", \\\"{x:1332,y:786,t:1528143519310};\\\", \\\"{x:1332,y:788,t:1528143519472};\\\", \\\"{x:1331,y:788,t:1528143519494};\\\", \\\"{x:1330,y:789,t:1528143519510};\\\", \\\"{x:1330,y:790,t:1528143519525};\\\", \\\"{x:1329,y:790,t:1528143519540};\\\", \\\"{x:1327,y:791,t:1528143519558};\\\", \\\"{x:1325,y:792,t:1528143519575};\\\", \\\"{x:1324,y:793,t:1528143519591};\\\", \\\"{x:1323,y:794,t:1528143519608};\\\", \\\"{x:1321,y:796,t:1528143519625};\\\", \\\"{x:1320,y:797,t:1528143519641};\\\", \\\"{x:1319,y:799,t:1528143519658};\\\", \\\"{x:1318,y:802,t:1528143519675};\\\", \\\"{x:1317,y:804,t:1528143519692};\\\", \\\"{x:1316,y:807,t:1528143519708};\\\", \\\"{x:1314,y:812,t:1528143519725};\\\", \\\"{x:1311,y:822,t:1528143519743};\\\", \\\"{x:1306,y:830,t:1528143519759};\\\", \\\"{x:1303,y:837,t:1528143519775};\\\", \\\"{x:1297,y:847,t:1528143519792};\\\", \\\"{x:1293,y:854,t:1528143519808};\\\", \\\"{x:1288,y:860,t:1528143519826};\\\", \\\"{x:1285,y:865,t:1528143519842};\\\", \\\"{x:1283,y:868,t:1528143519858};\\\", \\\"{x:1280,y:870,t:1528143519875};\\\", \\\"{x:1278,y:875,t:1528143519892};\\\", \\\"{x:1276,y:880,t:1528143519909};\\\", \\\"{x:1274,y:883,t:1528143519925};\\\", \\\"{x:1274,y:884,t:1528143519943};\\\", \\\"{x:1273,y:887,t:1528143519959};\\\", \\\"{x:1271,y:889,t:1528143519975};\\\", \\\"{x:1271,y:893,t:1528143519993};\\\", \\\"{x:1271,y:897,t:1528143520009};\\\", \\\"{x:1270,y:901,t:1528143520026};\\\", \\\"{x:1270,y:904,t:1528143520042};\\\", \\\"{x:1270,y:906,t:1528143520059};\\\", \\\"{x:1270,y:907,t:1528143520079};\\\", \\\"{x:1270,y:908,t:1528143520095};\\\", \\\"{x:1270,y:909,t:1528143520108};\\\", \\\"{x:1270,y:911,t:1528143520127};\\\", \\\"{x:1274,y:914,t:1528143520143};\\\", \\\"{x:1282,y:918,t:1528143520159};\\\", \\\"{x:1291,y:921,t:1528143520175};\\\", \\\"{x:1306,y:925,t:1528143520192};\\\", \\\"{x:1320,y:928,t:1528143520209};\\\", \\\"{x:1337,y:930,t:1528143520225};\\\", \\\"{x:1351,y:933,t:1528143520243};\\\", \\\"{x:1358,y:934,t:1528143520259};\\\", \\\"{x:1359,y:934,t:1528143520279};\\\", \\\"{x:1359,y:935,t:1528143520376};\\\", \\\"{x:1359,y:938,t:1528143520392};\\\", \\\"{x:1359,y:939,t:1528143520409};\\\", \\\"{x:1359,y:941,t:1528143520425};\\\", \\\"{x:1359,y:942,t:1528143520443};\\\", \\\"{x:1358,y:943,t:1528143520459};\\\", \\\"{x:1360,y:943,t:1528143520647};\\\", \\\"{x:1361,y:943,t:1528143520660};\\\", \\\"{x:1364,y:943,t:1528143520676};\\\", \\\"{x:1366,y:943,t:1528143520692};\\\", \\\"{x:1367,y:943,t:1528143520709};\\\", \\\"{x:1368,y:943,t:1528143520734};\\\", \\\"{x:1369,y:943,t:1528143520814};\\\", \\\"{x:1370,y:943,t:1528143520920};\\\", \\\"{x:1373,y:945,t:1528143520935};\\\", \\\"{x:1374,y:946,t:1528143520943};\\\", \\\"{x:1377,y:947,t:1528143520960};\\\", \\\"{x:1382,y:949,t:1528143520976};\\\", \\\"{x:1391,y:951,t:1528143520992};\\\", \\\"{x:1403,y:953,t:1528143521010};\\\", \\\"{x:1423,y:956,t:1528143521026};\\\", \\\"{x:1442,y:960,t:1528143521042};\\\", \\\"{x:1464,y:962,t:1528143521060};\\\", \\\"{x:1484,y:965,t:1528143521076};\\\", \\\"{x:1497,y:970,t:1528143521093};\\\", \\\"{x:1499,y:971,t:1528143521109};\\\", \\\"{x:1500,y:973,t:1528143521126};\\\", \\\"{x:1500,y:976,t:1528143521143};\\\", \\\"{x:1499,y:978,t:1528143521159};\\\", \\\"{x:1490,y:982,t:1528143521177};\\\", \\\"{x:1473,y:983,t:1528143521194};\\\", \\\"{x:1456,y:983,t:1528143521210};\\\", \\\"{x:1433,y:983,t:1528143521227};\\\", \\\"{x:1409,y:983,t:1528143521244};\\\", \\\"{x:1389,y:983,t:1528143521260};\\\", \\\"{x:1366,y:986,t:1528143521276};\\\", \\\"{x:1341,y:986,t:1528143521294};\\\", \\\"{x:1317,y:986,t:1528143521309};\\\", \\\"{x:1280,y:986,t:1528143521327};\\\", \\\"{x:1252,y:987,t:1528143521343};\\\", \\\"{x:1244,y:992,t:1528143521359};\\\", \\\"{x:1239,y:994,t:1528143521377};\\\", \\\"{x:1239,y:995,t:1528143521393};\\\", \\\"{x:1237,y:995,t:1528143521415};\\\", \\\"{x:1238,y:995,t:1528143521426};\\\", \\\"{x:1238,y:996,t:1528143521574};\\\", \\\"{x:1236,y:996,t:1528143521582};\\\", \\\"{x:1235,y:996,t:1528143521593};\\\", \\\"{x:1234,y:996,t:1528143521610};\\\", \\\"{x:1233,y:996,t:1528143521656};\\\", \\\"{x:1232,y:994,t:1528143521663};\\\", \\\"{x:1230,y:993,t:1528143521676};\\\", \\\"{x:1227,y:993,t:1528143521693};\\\", \\\"{x:1212,y:989,t:1528143521710};\\\", \\\"{x:1209,y:989,t:1528143521726};\\\", \\\"{x:1208,y:989,t:1528143521749};\\\", \\\"{x:1207,y:989,t:1528143521760};\\\", \\\"{x:1201,y:987,t:1528143521776};\\\", \\\"{x:1193,y:986,t:1528143521793};\\\", \\\"{x:1181,y:984,t:1528143521810};\\\", \\\"{x:1175,y:983,t:1528143521826};\\\", \\\"{x:1174,y:982,t:1528143521843};\\\", \\\"{x:1173,y:982,t:1528143521862};\\\", \\\"{x:1172,y:982,t:1528143521879};\\\", \\\"{x:1171,y:981,t:1528143521895};\\\", \\\"{x:1170,y:981,t:1528143521927};\\\", \\\"{x:1168,y:980,t:1528143521957};\\\", \\\"{x:1166,y:979,t:1528143522174};\\\", \\\"{x:1165,y:979,t:1528143522199};\\\", \\\"{x:1165,y:978,t:1528143522210};\\\", \\\"{x:1162,y:978,t:1528143522230};\\\", \\\"{x:1159,y:976,t:1528143522255};\\\", \\\"{x:1158,y:976,t:1528143522270};\\\", \\\"{x:1157,y:976,t:1528143522279};\\\", \\\"{x:1156,y:975,t:1528143522293};\\\", \\\"{x:1155,y:975,t:1528143522310};\\\", \\\"{x:1154,y:975,t:1528143522327};\\\", \\\"{x:1152,y:975,t:1528143522343};\\\", \\\"{x:1152,y:974,t:1528143522361};\\\", \\\"{x:1151,y:974,t:1528143522407};\\\", \\\"{x:1151,y:973,t:1528143522639};\\\", \\\"{x:1152,y:973,t:1528143522647};\\\", \\\"{x:1156,y:972,t:1528143522660};\\\", \\\"{x:1167,y:972,t:1528143522677};\\\", \\\"{x:1182,y:972,t:1528143522694};\\\", \\\"{x:1205,y:972,t:1528143522711};\\\", \\\"{x:1213,y:972,t:1528143522728};\\\", \\\"{x:1217,y:973,t:1528143522744};\\\", \\\"{x:1222,y:973,t:1528143522761};\\\", \\\"{x:1224,y:973,t:1528143522777};\\\", \\\"{x:1226,y:973,t:1528143522794};\\\", \\\"{x:1227,y:973,t:1528143522871};\\\", \\\"{x:1229,y:973,t:1528143523199};\\\", \\\"{x:1236,y:973,t:1528143523212};\\\", \\\"{x:1246,y:973,t:1528143523228};\\\", \\\"{x:1251,y:973,t:1528143523244};\\\", \\\"{x:1259,y:973,t:1528143523261};\\\", \\\"{x:1264,y:973,t:1528143523278};\\\", \\\"{x:1266,y:973,t:1528143523295};\\\", \\\"{x:1267,y:973,t:1528143523311};\\\", \\\"{x:1268,y:973,t:1528143523327};\\\", \\\"{x:1269,y:973,t:1528143523415};\\\", \\\"{x:1270,y:973,t:1528143523639};\\\", \\\"{x:1271,y:973,t:1528143523647};\\\", \\\"{x:1274,y:973,t:1528143523661};\\\", \\\"{x:1283,y:973,t:1528143523678};\\\", \\\"{x:1290,y:973,t:1528143523693};\\\", \\\"{x:1298,y:973,t:1528143523711};\\\", \\\"{x:1307,y:973,t:1528143523728};\\\", \\\"{x:1315,y:973,t:1528143523744};\\\", \\\"{x:1325,y:973,t:1528143523761};\\\", \\\"{x:1331,y:973,t:1528143523778};\\\", \\\"{x:1333,y:973,t:1528143523794};\\\", \\\"{x:1334,y:973,t:1528143523911};\\\", \\\"{x:1335,y:973,t:1528143524047};\\\", \\\"{x:1336,y:973,t:1528143524062};\\\", \\\"{x:1342,y:973,t:1528143524078};\\\", \\\"{x:1343,y:973,t:1528143524134};\\\", \\\"{x:1345,y:973,t:1528143524262};\\\", \\\"{x:1348,y:972,t:1528143524279};\\\", \\\"{x:1355,y:971,t:1528143524295};\\\", \\\"{x:1361,y:971,t:1528143524311};\\\", \\\"{x:1365,y:971,t:1528143524329};\\\", \\\"{x:1372,y:969,t:1528143524346};\\\", \\\"{x:1378,y:969,t:1528143524362};\\\", \\\"{x:1385,y:969,t:1528143524379};\\\", \\\"{x:1387,y:969,t:1528143524396};\\\", \\\"{x:1389,y:969,t:1528143524412};\\\", \\\"{x:1392,y:969,t:1528143524429};\\\", \\\"{x:1395,y:969,t:1528143524446};\\\", \\\"{x:1399,y:969,t:1528143524462};\\\", \\\"{x:1405,y:969,t:1528143524478};\\\", \\\"{x:1407,y:969,t:1528143524496};\\\", \\\"{x:1408,y:969,t:1528143524512};\\\", \\\"{x:1410,y:970,t:1528143524703};\\\", \\\"{x:1411,y:970,t:1528143524713};\\\", \\\"{x:1416,y:970,t:1528143524728};\\\", \\\"{x:1426,y:972,t:1528143524745};\\\", \\\"{x:1440,y:972,t:1528143524764};\\\", \\\"{x:1452,y:973,t:1528143524779};\\\", \\\"{x:1465,y:973,t:1528143524796};\\\", \\\"{x:1477,y:974,t:1528143524813};\\\", \\\"{x:1486,y:976,t:1528143524829};\\\", \\\"{x:1492,y:976,t:1528143524846};\\\", \\\"{x:1499,y:978,t:1528143524863};\\\", \\\"{x:1503,y:979,t:1528143524880};\\\", \\\"{x:1505,y:979,t:1528143524896};\\\", \\\"{x:1506,y:980,t:1528143524913};\\\", \\\"{x:1505,y:980,t:1528143525239};\\\", \\\"{x:1503,y:980,t:1528143525287};\\\", \\\"{x:1502,y:980,t:1528143525296};\\\", \\\"{x:1500,y:979,t:1528143525319};\\\", \\\"{x:1499,y:979,t:1528143525330};\\\", \\\"{x:1497,y:979,t:1528143525346};\\\", \\\"{x:1495,y:978,t:1528143525363};\\\", \\\"{x:1494,y:978,t:1528143525380};\\\", \\\"{x:1493,y:978,t:1528143525399};\\\", \\\"{x:1492,y:978,t:1528143525422};\\\", \\\"{x:1492,y:977,t:1528143525431};\\\", \\\"{x:1491,y:977,t:1528143525447};\\\", \\\"{x:1490,y:977,t:1528143525463};\\\", \\\"{x:1488,y:974,t:1528143526367};\\\", \\\"{x:1488,y:973,t:1528143526383};\\\", \\\"{x:1486,y:971,t:1528143526399};\\\", \\\"{x:1485,y:970,t:1528143526415};\\\", \\\"{x:1485,y:969,t:1528143526431};\\\", \\\"{x:1485,y:968,t:1528143526448};\\\", \\\"{x:1484,y:968,t:1528143526471};\\\", \\\"{x:1484,y:967,t:1528143526487};\\\", \\\"{x:1483,y:966,t:1528143526527};\\\", \\\"{x:1482,y:966,t:1528143526551};\\\", \\\"{x:1482,y:965,t:1528143526564};\\\", \\\"{x:1481,y:964,t:1528143526632};\\\", \\\"{x:1480,y:963,t:1528143526663};\\\", \\\"{x:1480,y:962,t:1528143526687};\\\", \\\"{x:1479,y:961,t:1528143526744};\\\", \\\"{x:1478,y:960,t:1528143527222};\\\", \\\"{x:1476,y:959,t:1528143527238};\\\", \\\"{x:1476,y:958,t:1528143527254};\\\", \\\"{x:1475,y:957,t:1528143527271};\\\", \\\"{x:1474,y:956,t:1528143527286};\\\", \\\"{x:1474,y:955,t:1528143527311};\\\", \\\"{x:1474,y:954,t:1528143527319};\\\", \\\"{x:1474,y:955,t:1528143527743};\\\", \\\"{x:1475,y:955,t:1528143527751};\\\", \\\"{x:1475,y:956,t:1528143527765};\\\", \\\"{x:1478,y:959,t:1528143527782};\\\", \\\"{x:1479,y:960,t:1528143527798};\\\", \\\"{x:1481,y:962,t:1528143527815};\\\", \\\"{x:1481,y:964,t:1528143527832};\\\", \\\"{x:1482,y:966,t:1528143527847};\\\", \\\"{x:1484,y:968,t:1528143527865};\\\", \\\"{x:1485,y:968,t:1528143527881};\\\", \\\"{x:1485,y:970,t:1528143527898};\\\", \\\"{x:1486,y:971,t:1528143527915};\\\", \\\"{x:1487,y:972,t:1528143527932};\\\", \\\"{x:1487,y:973,t:1528143527958};\\\", \\\"{x:1488,y:973,t:1528143528703};\\\", \\\"{x:1486,y:966,t:1528143528719};\\\", \\\"{x:1474,y:952,t:1528143528732};\\\", \\\"{x:1431,y:911,t:1528143528749};\\\", \\\"{x:1375,y:873,t:1528143528766};\\\", \\\"{x:1312,y:846,t:1528143528782};\\\", \\\"{x:1232,y:808,t:1528143528799};\\\", \\\"{x:1181,y:778,t:1528143528815};\\\", \\\"{x:1116,y:730,t:1528143528832};\\\", \\\"{x:1043,y:661,t:1528143528849};\\\", \\\"{x:970,y:603,t:1528143528866};\\\", \\\"{x:904,y:561,t:1528143528881};\\\", \\\"{x:853,y:537,t:1528143528898};\\\", \\\"{x:831,y:528,t:1528143528915};\\\", \\\"{x:813,y:521,t:1528143528932};\\\", \\\"{x:798,y:517,t:1528143528946};\\\", \\\"{x:782,y:515,t:1528143528964};\\\", \\\"{x:767,y:515,t:1528143528979};\\\", \\\"{x:763,y:515,t:1528143528996};\\\", \\\"{x:760,y:515,t:1528143529014};\\\", \\\"{x:758,y:516,t:1528143529029};\\\", \\\"{x:748,y:517,t:1528143529045};\\\", \\\"{x:734,y:517,t:1528143529064};\\\", \\\"{x:724,y:517,t:1528143529079};\\\", \\\"{x:712,y:517,t:1528143529097};\\\", \\\"{x:702,y:517,t:1528143529112};\\\", \\\"{x:692,y:517,t:1528143529134};\\\", \\\"{x:682,y:514,t:1528143529150};\\\", \\\"{x:677,y:513,t:1528143529166};\\\", \\\"{x:667,y:512,t:1528143529183};\\\", \\\"{x:653,y:510,t:1528143529200};\\\", \\\"{x:645,y:508,t:1528143529216};\\\", \\\"{x:640,y:507,t:1528143529233};\\\", \\\"{x:636,y:507,t:1528143529250};\\\", \\\"{x:635,y:507,t:1528143529270};\\\", \\\"{x:634,y:507,t:1528143529334};\\\", \\\"{x:633,y:506,t:1528143529358};\\\", \\\"{x:632,y:506,t:1528143529374};\\\", \\\"{x:631,y:506,t:1528143529384};\\\", \\\"{x:631,y:505,t:1528143529399};\\\", \\\"{x:631,y:504,t:1528143529590};\\\", \\\"{x:634,y:503,t:1528143529600};\\\", \\\"{x:648,y:503,t:1528143529616};\\\", \\\"{x:669,y:505,t:1528143529633};\\\", \\\"{x:695,y:512,t:1528143529651};\\\", \\\"{x:725,y:519,t:1528143529667};\\\", \\\"{x:749,y:524,t:1528143529683};\\\", \\\"{x:776,y:531,t:1528143529701};\\\", \\\"{x:804,y:539,t:1528143529717};\\\", \\\"{x:833,y:547,t:1528143529734};\\\", \\\"{x:894,y:564,t:1528143529750};\\\", \\\"{x:928,y:573,t:1528143529766};\\\", \\\"{x:956,y:581,t:1528143529784};\\\", \\\"{x:986,y:588,t:1528143529800};\\\", \\\"{x:1016,y:595,t:1528143529818};\\\", \\\"{x:1042,y:605,t:1528143529833};\\\", \\\"{x:1067,y:612,t:1528143529851};\\\", \\\"{x:1095,y:621,t:1528143529867};\\\", \\\"{x:1130,y:630,t:1528143529883};\\\", \\\"{x:1170,y:642,t:1528143529900};\\\", \\\"{x:1203,y:651,t:1528143529918};\\\", \\\"{x:1233,y:660,t:1528143529934};\\\", \\\"{x:1273,y:678,t:1528143529950};\\\", \\\"{x:1292,y:686,t:1528143529967};\\\", \\\"{x:1308,y:695,t:1528143529984};\\\", \\\"{x:1317,y:700,t:1528143530000};\\\", \\\"{x:1322,y:703,t:1528143530018};\\\", \\\"{x:1327,y:707,t:1528143530034};\\\", \\\"{x:1331,y:711,t:1528143530051};\\\", \\\"{x:1333,y:715,t:1528143530068};\\\", \\\"{x:1336,y:720,t:1528143530084};\\\", \\\"{x:1337,y:724,t:1528143530101};\\\", \\\"{x:1340,y:730,t:1528143530118};\\\", \\\"{x:1341,y:734,t:1528143530133};\\\", \\\"{x:1342,y:742,t:1528143530151};\\\", \\\"{x:1342,y:748,t:1528143530167};\\\", \\\"{x:1342,y:757,t:1528143530184};\\\", \\\"{x:1342,y:767,t:1528143530201};\\\", \\\"{x:1342,y:778,t:1528143530218};\\\", \\\"{x:1338,y:792,t:1528143530234};\\\", \\\"{x:1336,y:799,t:1528143530251};\\\", \\\"{x:1334,y:805,t:1528143530268};\\\", \\\"{x:1330,y:813,t:1528143530284};\\\", \\\"{x:1326,y:822,t:1528143530300};\\\", \\\"{x:1322,y:829,t:1528143530318};\\\", \\\"{x:1317,y:836,t:1528143530334};\\\", \\\"{x:1314,y:841,t:1528143530350};\\\", \\\"{x:1311,y:844,t:1528143530368};\\\", \\\"{x:1307,y:846,t:1528143530385};\\\", \\\"{x:1304,y:848,t:1528143530401};\\\", \\\"{x:1299,y:850,t:1528143530417};\\\", \\\"{x:1293,y:851,t:1528143530434};\\\", \\\"{x:1288,y:853,t:1528143530451};\\\", \\\"{x:1283,y:854,t:1528143530468};\\\", \\\"{x:1278,y:855,t:1528143530485};\\\", \\\"{x:1276,y:855,t:1528143530501};\\\", \\\"{x:1275,y:855,t:1528143530526};\\\", \\\"{x:1273,y:855,t:1528143530551};\\\", \\\"{x:1273,y:854,t:1528143530568};\\\", \\\"{x:1273,y:853,t:1528143530585};\\\", \\\"{x:1272,y:851,t:1528143530600};\\\", \\\"{x:1270,y:849,t:1528143530618};\\\", \\\"{x:1270,y:847,t:1528143530635};\\\", \\\"{x:1270,y:846,t:1528143530751};\\\", \\\"{x:1269,y:846,t:1528143530975};\\\", \\\"{x:1268,y:846,t:1528143530985};\\\", \\\"{x:1267,y:846,t:1528143531002};\\\", \\\"{x:1269,y:846,t:1528143531151};\\\", \\\"{x:1272,y:846,t:1528143531168};\\\", \\\"{x:1276,y:846,t:1528143531185};\\\", \\\"{x:1278,y:846,t:1528143531202};\\\", \\\"{x:1281,y:847,t:1528143531218};\\\", \\\"{x:1283,y:848,t:1528143531235};\\\", \\\"{x:1284,y:849,t:1528143531255};\\\", \\\"{x:1285,y:850,t:1528143531269};\\\", \\\"{x:1285,y:851,t:1528143531285};\\\", \\\"{x:1286,y:853,t:1528143531303};\\\", \\\"{x:1286,y:857,t:1528143531319};\\\", \\\"{x:1286,y:858,t:1528143531335};\\\", \\\"{x:1286,y:861,t:1528143531352};\\\", \\\"{x:1286,y:863,t:1528143531369};\\\", \\\"{x:1286,y:864,t:1528143531385};\\\", \\\"{x:1286,y:866,t:1528143531402};\\\", \\\"{x:1286,y:867,t:1528143531419};\\\", \\\"{x:1285,y:871,t:1528143531435};\\\", \\\"{x:1284,y:874,t:1528143531454};\\\", \\\"{x:1281,y:878,t:1528143531469};\\\", \\\"{x:1279,y:882,t:1528143531485};\\\", \\\"{x:1277,y:886,t:1528143531502};\\\", \\\"{x:1271,y:895,t:1528143531519};\\\", \\\"{x:1268,y:901,t:1528143531535};\\\", \\\"{x:1262,y:907,t:1528143531552};\\\", \\\"{x:1257,y:910,t:1528143531569};\\\", \\\"{x:1253,y:912,t:1528143531585};\\\", \\\"{x:1248,y:913,t:1528143531602};\\\", \\\"{x:1245,y:915,t:1528143531619};\\\", \\\"{x:1242,y:917,t:1528143531635};\\\", \\\"{x:1239,y:919,t:1528143531653};\\\", \\\"{x:1236,y:921,t:1528143531669};\\\", \\\"{x:1233,y:922,t:1528143531686};\\\", \\\"{x:1229,y:924,t:1528143531702};\\\", \\\"{x:1220,y:924,t:1528143531718};\\\", \\\"{x:1215,y:925,t:1528143531736};\\\", \\\"{x:1210,y:927,t:1528143531753};\\\", \\\"{x:1204,y:927,t:1528143531769};\\\", \\\"{x:1201,y:927,t:1528143531786};\\\", \\\"{x:1199,y:927,t:1528143531802};\\\", \\\"{x:1196,y:927,t:1528143531819};\\\", \\\"{x:1193,y:927,t:1528143531836};\\\", \\\"{x:1191,y:927,t:1528143531854};\\\", \\\"{x:1189,y:927,t:1528143531869};\\\", \\\"{x:1187,y:926,t:1528143531886};\\\", \\\"{x:1185,y:924,t:1528143531902};\\\", \\\"{x:1185,y:923,t:1528143531927};\\\", \\\"{x:1185,y:922,t:1528143531936};\\\", \\\"{x:1185,y:921,t:1528143531952};\\\", \\\"{x:1185,y:920,t:1528143531969};\\\", \\\"{x:1185,y:919,t:1528143531986};\\\", \\\"{x:1184,y:918,t:1528143532063};\\\", \\\"{x:1183,y:918,t:1528143532071};\\\", \\\"{x:1181,y:918,t:1528143532086};\\\", \\\"{x:1179,y:918,t:1528143532102};\\\", \\\"{x:1178,y:918,t:1528143532119};\\\", \\\"{x:1177,y:918,t:1528143532183};\\\", \\\"{x:1178,y:915,t:1528143532190};\\\", \\\"{x:1182,y:912,t:1528143532203};\\\", \\\"{x:1196,y:903,t:1528143532219};\\\", \\\"{x:1210,y:891,t:1528143532236};\\\", \\\"{x:1220,y:872,t:1528143532255};\\\", \\\"{x:1224,y:866,t:1528143532269};\\\", \\\"{x:1227,y:855,t:1528143532286};\\\", \\\"{x:1229,y:840,t:1528143532303};\\\", \\\"{x:1229,y:835,t:1528143532318};\\\", \\\"{x:1231,y:831,t:1528143532336};\\\", \\\"{x:1231,y:830,t:1528143532375};\\\", \\\"{x:1231,y:829,t:1528143532391};\\\", \\\"{x:1231,y:828,t:1528143532439};\\\", \\\"{x:1232,y:828,t:1528143532454};\\\", \\\"{x:1232,y:826,t:1528143532469};\\\", \\\"{x:1234,y:824,t:1528143532485};\\\", \\\"{x:1235,y:822,t:1528143532501};\\\", \\\"{x:1236,y:820,t:1528143532519};\\\", \\\"{x:1236,y:819,t:1528143532535};\\\", \\\"{x:1238,y:818,t:1528143532552};\\\", \\\"{x:1240,y:815,t:1528143532570};\\\", \\\"{x:1243,y:812,t:1528143532585};\\\", \\\"{x:1246,y:805,t:1528143532602};\\\", \\\"{x:1249,y:796,t:1528143532620};\\\", \\\"{x:1251,y:789,t:1528143532636};\\\", \\\"{x:1252,y:787,t:1528143532653};\\\", \\\"{x:1254,y:785,t:1528143532670};\\\", \\\"{x:1256,y:783,t:1528143532686};\\\", \\\"{x:1257,y:781,t:1528143532703};\\\", \\\"{x:1257,y:780,t:1528143532720};\\\", \\\"{x:1258,y:779,t:1528143532751};\\\", \\\"{x:1259,y:779,t:1528143532759};\\\", \\\"{x:1259,y:778,t:1528143532771};\\\", \\\"{x:1259,y:777,t:1528143532786};\\\", \\\"{x:1260,y:775,t:1528143532804};\\\", \\\"{x:1260,y:774,t:1528143532821};\\\", \\\"{x:1259,y:781,t:1528143532919};\\\", \\\"{x:1252,y:799,t:1528143532936};\\\", \\\"{x:1246,y:808,t:1528143532953};\\\", \\\"{x:1241,y:816,t:1528143532970};\\\", \\\"{x:1238,y:821,t:1528143532988};\\\", \\\"{x:1238,y:820,t:1528143533055};\\\", \\\"{x:1240,y:817,t:1528143533070};\\\", \\\"{x:1241,y:814,t:1528143533086};\\\", \\\"{x:1240,y:814,t:1528143533167};\\\", \\\"{x:1239,y:814,t:1528143533175};\\\", \\\"{x:1237,y:814,t:1528143533187};\\\", \\\"{x:1234,y:815,t:1528143533203};\\\", \\\"{x:1227,y:817,t:1528143533220};\\\", \\\"{x:1225,y:819,t:1528143533237};\\\", \\\"{x:1223,y:822,t:1528143533254};\\\", \\\"{x:1223,y:823,t:1528143533271};\\\", \\\"{x:1220,y:826,t:1528143533287};\\\", \\\"{x:1220,y:828,t:1528143533304};\\\", \\\"{x:1217,y:831,t:1528143533320};\\\", \\\"{x:1214,y:834,t:1528143533337};\\\", \\\"{x:1213,y:836,t:1528143533354};\\\", \\\"{x:1210,y:840,t:1528143533370};\\\", \\\"{x:1209,y:843,t:1528143533387};\\\", \\\"{x:1208,y:846,t:1528143533404};\\\", \\\"{x:1206,y:849,t:1528143533420};\\\", \\\"{x:1205,y:851,t:1528143533437};\\\", \\\"{x:1204,y:852,t:1528143533454};\\\", \\\"{x:1203,y:854,t:1528143533470};\\\", \\\"{x:1203,y:855,t:1528143533503};\\\", \\\"{x:1203,y:853,t:1528143533623};\\\", \\\"{x:1204,y:852,t:1528143533637};\\\", \\\"{x:1210,y:849,t:1528143533654};\\\", \\\"{x:1216,y:848,t:1528143533671};\\\", \\\"{x:1221,y:846,t:1528143533687};\\\", \\\"{x:1223,y:845,t:1528143533704};\\\", \\\"{x:1223,y:840,t:1528143533720};\\\", \\\"{x:1223,y:839,t:1528143534183};\\\", \\\"{x:1223,y:838,t:1528143534190};\\\", \\\"{x:1223,y:837,t:1528143534203};\\\", \\\"{x:1223,y:834,t:1528143534221};\\\", \\\"{x:1219,y:828,t:1528143534237};\\\", \\\"{x:1218,y:827,t:1528143534254};\\\", \\\"{x:1217,y:825,t:1528143534270};\\\", \\\"{x:1215,y:824,t:1528143534288};\\\", \\\"{x:1209,y:824,t:1528143534304};\\\", \\\"{x:1204,y:824,t:1528143534320};\\\", \\\"{x:1191,y:830,t:1528143534338};\\\", \\\"{x:1172,y:843,t:1528143534354};\\\", \\\"{x:1139,y:866,t:1528143534370};\\\", \\\"{x:1116,y:882,t:1528143534388};\\\", \\\"{x:1101,y:895,t:1528143534403};\\\", \\\"{x:1091,y:908,t:1528143534421};\\\", \\\"{x:1086,y:920,t:1528143534438};\\\", \\\"{x:1084,y:929,t:1528143534454};\\\", \\\"{x:1084,y:933,t:1528143534471};\\\", \\\"{x:1084,y:937,t:1528143534488};\\\", \\\"{x:1084,y:940,t:1528143534503};\\\", \\\"{x:1084,y:943,t:1528143534521};\\\", \\\"{x:1083,y:946,t:1528143534537};\\\", \\\"{x:1083,y:947,t:1528143534554};\\\", \\\"{x:1083,y:949,t:1528143534571};\\\", \\\"{x:1082,y:952,t:1528143534588};\\\", \\\"{x:1082,y:953,t:1528143534604};\\\", \\\"{x:1082,y:954,t:1528143534703};\\\", \\\"{x:1084,y:954,t:1528143534722};\\\", \\\"{x:1087,y:954,t:1528143534738};\\\", \\\"{x:1090,y:953,t:1528143534754};\\\", \\\"{x:1094,y:952,t:1528143534771};\\\", \\\"{x:1098,y:951,t:1528143534788};\\\", \\\"{x:1101,y:951,t:1528143534806};\\\", \\\"{x:1103,y:949,t:1528143534821};\\\", \\\"{x:1106,y:949,t:1528143534838};\\\", \\\"{x:1112,y:949,t:1528143534854};\\\", \\\"{x:1116,y:949,t:1528143534871};\\\", \\\"{x:1119,y:949,t:1528143534889};\\\", \\\"{x:1120,y:949,t:1528143534906};\\\", \\\"{x:1123,y:949,t:1528143534921};\\\", \\\"{x:1130,y:950,t:1528143534939};\\\", \\\"{x:1137,y:952,t:1528143534955};\\\", \\\"{x:1141,y:953,t:1528143534972};\\\", \\\"{x:1141,y:954,t:1528143534989};\\\", \\\"{x:1142,y:954,t:1528143535005};\\\", \\\"{x:1143,y:955,t:1528143535030};\\\", \\\"{x:1144,y:956,t:1528143535087};\\\", \\\"{x:1144,y:957,t:1528143535239};\\\", \\\"{x:1144,y:958,t:1528143535270};\\\", \\\"{x:1145,y:959,t:1528143535288};\\\", \\\"{x:1145,y:960,t:1528143535334};\\\", \\\"{x:1145,y:961,t:1528143535343};\\\", \\\"{x:1145,y:962,t:1528143535543};\\\", \\\"{x:1146,y:963,t:1528143535639};\\\", \\\"{x:1147,y:963,t:1528143535711};\\\", \\\"{x:1150,y:963,t:1528143535911};\\\", \\\"{x:1152,y:963,t:1528143535922};\\\", \\\"{x:1158,y:963,t:1528143535939};\\\", \\\"{x:1167,y:962,t:1528143535956};\\\", \\\"{x:1177,y:962,t:1528143535972};\\\", \\\"{x:1187,y:962,t:1528143535989};\\\", \\\"{x:1194,y:962,t:1528143536006};\\\", \\\"{x:1204,y:962,t:1528143536022};\\\", \\\"{x:1210,y:962,t:1528143536039};\\\", \\\"{x:1216,y:962,t:1528143536056};\\\", \\\"{x:1219,y:962,t:1528143536072};\\\", \\\"{x:1223,y:962,t:1528143536088};\\\", \\\"{x:1226,y:962,t:1528143536106};\\\", \\\"{x:1233,y:962,t:1528143536122};\\\", \\\"{x:1238,y:962,t:1528143536139};\\\", \\\"{x:1241,y:962,t:1528143536155};\\\", \\\"{x:1243,y:962,t:1528143536171};\\\", \\\"{x:1245,y:962,t:1528143536188};\\\", \\\"{x:1246,y:962,t:1528143536205};\\\", \\\"{x:1246,y:961,t:1528143536335};\\\", \\\"{x:1245,y:958,t:1528143536350};\\\", \\\"{x:1242,y:957,t:1528143536358};\\\", \\\"{x:1242,y:956,t:1528143536372};\\\", \\\"{x:1237,y:952,t:1528143536388};\\\", \\\"{x:1228,y:940,t:1528143536406};\\\", \\\"{x:1220,y:931,t:1528143536422};\\\", \\\"{x:1212,y:927,t:1528143536439};\\\", \\\"{x:1208,y:926,t:1528143536456};\\\", \\\"{x:1205,y:926,t:1528143536472};\\\", \\\"{x:1204,y:926,t:1528143536489};\\\", \\\"{x:1201,y:926,t:1528143536506};\\\", \\\"{x:1199,y:926,t:1528143536522};\\\", \\\"{x:1195,y:926,t:1528143536539};\\\", \\\"{x:1190,y:926,t:1528143536556};\\\", \\\"{x:1187,y:926,t:1528143536573};\\\", \\\"{x:1186,y:926,t:1528143536589};\\\", \\\"{x:1184,y:926,t:1528143536607};\\\", \\\"{x:1183,y:927,t:1528143536622};\\\", \\\"{x:1183,y:928,t:1528143536639};\\\", \\\"{x:1182,y:931,t:1528143536656};\\\", \\\"{x:1180,y:937,t:1528143536673};\\\", \\\"{x:1178,y:946,t:1528143536689};\\\", \\\"{x:1176,y:951,t:1528143536706};\\\", \\\"{x:1176,y:954,t:1528143536723};\\\", \\\"{x:1176,y:957,t:1528143536739};\\\", \\\"{x:1176,y:958,t:1528143536756};\\\", \\\"{x:1174,y:961,t:1528143536773};\\\", \\\"{x:1172,y:965,t:1528143536790};\\\", \\\"{x:1171,y:966,t:1528143536823};\\\", \\\"{x:1170,y:966,t:1528143536855};\\\", \\\"{x:1170,y:964,t:1528143536887};\\\", \\\"{x:1179,y:960,t:1528143536894};\\\", \\\"{x:1189,y:958,t:1528143536906};\\\", \\\"{x:1209,y:955,t:1528143536923};\\\", \\\"{x:1227,y:953,t:1528143536938};\\\", \\\"{x:1244,y:949,t:1528143536956};\\\", \\\"{x:1257,y:948,t:1528143536973};\\\", \\\"{x:1264,y:948,t:1528143536990};\\\", \\\"{x:1265,y:948,t:1528143537006};\\\", \\\"{x:1266,y:948,t:1528143537080};\\\", \\\"{x:1266,y:949,t:1528143537103};\\\", \\\"{x:1268,y:949,t:1528143537231};\\\", \\\"{x:1269,y:948,t:1528143537240};\\\", \\\"{x:1271,y:940,t:1528143537256};\\\", \\\"{x:1274,y:930,t:1528143537273};\\\", \\\"{x:1278,y:918,t:1528143537290};\\\", \\\"{x:1280,y:912,t:1528143537306};\\\", \\\"{x:1282,y:903,t:1528143537323};\\\", \\\"{x:1284,y:892,t:1528143537340};\\\", \\\"{x:1286,y:878,t:1528143537357};\\\", \\\"{x:1288,y:859,t:1528143537373};\\\", \\\"{x:1296,y:817,t:1528143537391};\\\", \\\"{x:1300,y:776,t:1528143537406};\\\", \\\"{x:1301,y:764,t:1528143537423};\\\", \\\"{x:1301,y:763,t:1528143537440};\\\", \\\"{x:1301,y:762,t:1528143537511};\\\", \\\"{x:1297,y:763,t:1528143537523};\\\", \\\"{x:1276,y:781,t:1528143537541};\\\", \\\"{x:1255,y:799,t:1528143537558};\\\", \\\"{x:1235,y:818,t:1528143537573};\\\", \\\"{x:1207,y:835,t:1528143537590};\\\", \\\"{x:1195,y:839,t:1528143537606};\\\", \\\"{x:1188,y:844,t:1528143537624};\\\", \\\"{x:1187,y:844,t:1528143537640};\\\", \\\"{x:1186,y:845,t:1528143537657};\\\", \\\"{x:1186,y:846,t:1528143537742};\\\", \\\"{x:1186,y:847,t:1528143537756};\\\", \\\"{x:1191,y:849,t:1528143537773};\\\", \\\"{x:1209,y:851,t:1528143537790};\\\", \\\"{x:1224,y:851,t:1528143537807};\\\", \\\"{x:1241,y:851,t:1528143537823};\\\", \\\"{x:1257,y:844,t:1528143537839};\\\", \\\"{x:1272,y:831,t:1528143537857};\\\", \\\"{x:1284,y:812,t:1528143537874};\\\", \\\"{x:1291,y:789,t:1528143537890};\\\", \\\"{x:1303,y:752,t:1528143537907};\\\", \\\"{x:1314,y:718,t:1528143537924};\\\", \\\"{x:1319,y:700,t:1528143537940};\\\", \\\"{x:1319,y:694,t:1528143537957};\\\", \\\"{x:1321,y:687,t:1528143537975};\\\", \\\"{x:1321,y:694,t:1528143538071};\\\", \\\"{x:1321,y:703,t:1528143538078};\\\", \\\"{x:1321,y:715,t:1528143538090};\\\", \\\"{x:1321,y:737,t:1528143538107};\\\", \\\"{x:1323,y:754,t:1528143538124};\\\", \\\"{x:1329,y:770,t:1528143538140};\\\", \\\"{x:1336,y:786,t:1528143538157};\\\", \\\"{x:1343,y:801,t:1528143538174};\\\", \\\"{x:1344,y:808,t:1528143538191};\\\", \\\"{x:1344,y:811,t:1528143538207};\\\", \\\"{x:1344,y:812,t:1528143538224};\\\", \\\"{x:1344,y:813,t:1528143538271};\\\", \\\"{x:1344,y:814,t:1528143538279};\\\", \\\"{x:1344,y:815,t:1528143538291};\\\", \\\"{x:1346,y:820,t:1528143538307};\\\", \\\"{x:1346,y:823,t:1528143538324};\\\", \\\"{x:1346,y:829,t:1528143538341};\\\", \\\"{x:1346,y:832,t:1528143538358};\\\", \\\"{x:1346,y:834,t:1528143538374};\\\", \\\"{x:1346,y:833,t:1528143539046};\\\", \\\"{x:1347,y:833,t:1528143539183};\\\", \\\"{x:1348,y:833,t:1528143539255};\\\", \\\"{x:1349,y:831,t:1528143539263};\\\", \\\"{x:1349,y:829,t:1528143539275};\\\", \\\"{x:1349,y:826,t:1528143539292};\\\", \\\"{x:1349,y:824,t:1528143539308};\\\", \\\"{x:1349,y:823,t:1528143539324};\\\", \\\"{x:1349,y:822,t:1528143539342};\\\", \\\"{x:1347,y:822,t:1528143539389};\\\", \\\"{x:1345,y:823,t:1528143539398};\\\", \\\"{x:1342,y:825,t:1528143539408};\\\", \\\"{x:1338,y:828,t:1528143539425};\\\", \\\"{x:1334,y:831,t:1528143539440};\\\", \\\"{x:1332,y:832,t:1528143539457};\\\", \\\"{x:1331,y:833,t:1528143539475};\\\", \\\"{x:1330,y:832,t:1528143539575};\\\", \\\"{x:1330,y:828,t:1528143539592};\\\", \\\"{x:1332,y:822,t:1528143539608};\\\", \\\"{x:1333,y:815,t:1528143539625};\\\", \\\"{x:1333,y:809,t:1528143539642};\\\", \\\"{x:1335,y:797,t:1528143539658};\\\", \\\"{x:1338,y:781,t:1528143539676};\\\", \\\"{x:1340,y:770,t:1528143539693};\\\", \\\"{x:1340,y:769,t:1528143539708};\\\", \\\"{x:1341,y:769,t:1528143539759};\\\", \\\"{x:1345,y:772,t:1528143539775};\\\", \\\"{x:1354,y:784,t:1528143539792};\\\", \\\"{x:1360,y:794,t:1528143539809};\\\", \\\"{x:1364,y:797,t:1528143539825};\\\", \\\"{x:1371,y:806,t:1528143539843};\\\", \\\"{x:1374,y:815,t:1528143539858};\\\", \\\"{x:1376,y:819,t:1528143539876};\\\", \\\"{x:1377,y:823,t:1528143539892};\\\", \\\"{x:1375,y:829,t:1528143539908};\\\", \\\"{x:1355,y:840,t:1528143539926};\\\", \\\"{x:1308,y:857,t:1528143539942};\\\", \\\"{x:1268,y:870,t:1528143539958};\\\", \\\"{x:1246,y:879,t:1528143539975};\\\", \\\"{x:1237,y:885,t:1528143539992};\\\", \\\"{x:1236,y:886,t:1528143540009};\\\", \\\"{x:1236,y:888,t:1528143540030};\\\", \\\"{x:1236,y:889,t:1528143540063};\\\", \\\"{x:1238,y:889,t:1528143540095};\\\", \\\"{x:1240,y:889,t:1528143540110};\\\", \\\"{x:1247,y:889,t:1528143540126};\\\", \\\"{x:1262,y:892,t:1528143540142};\\\", \\\"{x:1270,y:894,t:1528143540159};\\\", \\\"{x:1282,y:898,t:1528143540176};\\\", \\\"{x:1298,y:902,t:1528143540193};\\\", \\\"{x:1309,y:905,t:1528143540209};\\\", \\\"{x:1327,y:911,t:1528143540226};\\\", \\\"{x:1343,y:918,t:1528143540243};\\\", \\\"{x:1351,y:922,t:1528143540259};\\\", \\\"{x:1358,y:927,t:1528143540275};\\\", \\\"{x:1369,y:930,t:1528143540292};\\\", \\\"{x:1370,y:933,t:1528143540309};\\\", \\\"{x:1376,y:936,t:1528143540325};\\\", \\\"{x:1377,y:937,t:1528143540342};\\\", \\\"{x:1376,y:941,t:1528143540359};\\\", \\\"{x:1372,y:943,t:1528143540415};\\\", \\\"{x:1371,y:943,t:1528143540426};\\\", \\\"{x:1369,y:943,t:1528143540443};\\\", \\\"{x:1366,y:943,t:1528143540459};\\\", \\\"{x:1365,y:943,t:1528143540486};\\\", \\\"{x:1365,y:941,t:1528143540495};\\\", \\\"{x:1364,y:941,t:1528143540510};\\\", \\\"{x:1363,y:941,t:1528143540599};\\\", \\\"{x:1362,y:941,t:1528143540614};\\\", \\\"{x:1361,y:941,t:1528143540626};\\\", \\\"{x:1360,y:941,t:1528143540643};\\\", \\\"{x:1356,y:941,t:1528143540660};\\\", \\\"{x:1353,y:941,t:1528143540677};\\\", \\\"{x:1353,y:940,t:1528143540694};\\\", \\\"{x:1352,y:940,t:1528143540735};\\\", \\\"{x:1351,y:940,t:1528143540743};\\\", \\\"{x:1350,y:939,t:1528143540823};\\\", \\\"{x:1350,y:938,t:1528143540847};\\\", \\\"{x:1349,y:938,t:1528143540859};\\\", \\\"{x:1346,y:939,t:1528143541215};\\\", \\\"{x:1344,y:942,t:1528143541227};\\\", \\\"{x:1340,y:950,t:1528143541244};\\\", \\\"{x:1338,y:954,t:1528143541259};\\\", \\\"{x:1336,y:956,t:1528143541276};\\\", \\\"{x:1335,y:958,t:1528143541293};\\\", \\\"{x:1330,y:962,t:1528143541309};\\\", \\\"{x:1322,y:967,t:1528143541326};\\\", \\\"{x:1321,y:969,t:1528143541344};\\\", \\\"{x:1318,y:970,t:1528143541360};\\\", \\\"{x:1312,y:973,t:1528143541376};\\\", \\\"{x:1304,y:977,t:1528143541393};\\\", \\\"{x:1302,y:977,t:1528143541410};\\\", \\\"{x:1300,y:977,t:1528143541426};\\\", \\\"{x:1299,y:977,t:1528143541454};\\\", \\\"{x:1297,y:977,t:1528143541503};\\\", \\\"{x:1296,y:977,t:1528143541510};\\\", \\\"{x:1293,y:977,t:1528143541527};\\\", \\\"{x:1292,y:977,t:1528143541567};\\\", \\\"{x:1291,y:977,t:1528143541583};\\\", \\\"{x:1290,y:977,t:1528143541593};\\\", \\\"{x:1287,y:975,t:1528143541610};\\\", \\\"{x:1285,y:970,t:1528143541626};\\\", \\\"{x:1283,y:969,t:1528143541644};\\\", \\\"{x:1283,y:968,t:1528143541661};\\\", \\\"{x:1281,y:966,t:1528143541677};\\\", \\\"{x:1280,y:966,t:1528143541693};\\\", \\\"{x:1279,y:965,t:1528143541711};\\\", \\\"{x:1278,y:964,t:1528143541743};\\\", \\\"{x:1278,y:963,t:1528143541760};\\\", \\\"{x:1277,y:963,t:1528143541777};\\\", \\\"{x:1276,y:962,t:1528143541847};\\\", \\\"{x:1275,y:962,t:1528143541863};\\\", \\\"{x:1272,y:961,t:1528143541878};\\\", \\\"{x:1267,y:961,t:1528143541893};\\\", \\\"{x:1262,y:961,t:1528143541911};\\\", \\\"{x:1261,y:961,t:1528143541991};\\\", \\\"{x:1260,y:961,t:1528143541998};\\\", \\\"{x:1259,y:961,t:1528143542010};\\\", \\\"{x:1256,y:961,t:1528143542027};\\\", \\\"{x:1254,y:961,t:1528143542043};\\\", \\\"{x:1253,y:961,t:1528143542063};\\\", \\\"{x:1256,y:961,t:1528143542286};\\\", \\\"{x:1258,y:961,t:1528143542294};\\\", \\\"{x:1261,y:961,t:1528143542310};\\\", \\\"{x:1263,y:961,t:1528143542327};\\\", \\\"{x:1264,y:961,t:1528143542344};\\\", \\\"{x:1265,y:961,t:1528143542375};\\\", \\\"{x:1266,y:961,t:1528143542382};\\\", \\\"{x:1267,y:961,t:1528143542394};\\\", \\\"{x:1269,y:961,t:1528143542410};\\\", \\\"{x:1270,y:961,t:1528143542447};\\\", \\\"{x:1273,y:961,t:1528143542461};\\\", \\\"{x:1276,y:961,t:1528143542477};\\\", \\\"{x:1279,y:961,t:1528143542494};\\\", \\\"{x:1280,y:961,t:1528143542527};\\\", \\\"{x:1282,y:962,t:1528143542575};\\\", \\\"{x:1282,y:963,t:1528143542591};\\\", \\\"{x:1283,y:963,t:1528143542599};\\\", \\\"{x:1285,y:963,t:1528143542630};\\\", \\\"{x:1285,y:964,t:1528143542646};\\\", \\\"{x:1286,y:965,t:1528143542679};\\\", \\\"{x:1286,y:966,t:1528143542703};\\\", \\\"{x:1287,y:966,t:1528143542911};\\\", \\\"{x:1290,y:966,t:1528143542928};\\\", \\\"{x:1293,y:966,t:1528143542944};\\\", \\\"{x:1300,y:965,t:1528143542961};\\\", \\\"{x:1307,y:965,t:1528143542978};\\\", \\\"{x:1312,y:965,t:1528143542994};\\\", \\\"{x:1318,y:965,t:1528143543011};\\\", \\\"{x:1323,y:965,t:1528143543028};\\\", \\\"{x:1328,y:965,t:1528143543044};\\\", \\\"{x:1334,y:965,t:1528143543062};\\\", \\\"{x:1341,y:965,t:1528143543078};\\\", \\\"{x:1342,y:965,t:1528143543094};\\\", \\\"{x:1344,y:965,t:1528143543126};\\\", \\\"{x:1346,y:965,t:1528143543159};\\\", \\\"{x:1347,y:966,t:1528143543166};\\\", \\\"{x:1351,y:969,t:1528143543179};\\\", \\\"{x:1358,y:970,t:1528143543195};\\\", \\\"{x:1361,y:970,t:1528143543211};\\\", \\\"{x:1363,y:971,t:1528143543228};\\\", \\\"{x:1363,y:972,t:1528143543244};\\\", \\\"{x:1363,y:973,t:1528143543261};\\\", \\\"{x:1359,y:978,t:1528143543278};\\\", \\\"{x:1349,y:979,t:1528143543294};\\\", \\\"{x:1324,y:980,t:1528143543312};\\\", \\\"{x:1263,y:980,t:1528143543328};\\\", \\\"{x:1204,y:980,t:1528143543344};\\\", \\\"{x:1175,y:980,t:1528143543362};\\\", \\\"{x:1156,y:980,t:1528143543378};\\\", \\\"{x:1141,y:980,t:1528143543394};\\\", \\\"{x:1135,y:980,t:1528143543411};\\\", \\\"{x:1129,y:980,t:1528143543428};\\\", \\\"{x:1125,y:980,t:1528143543445};\\\", \\\"{x:1121,y:982,t:1528143543461};\\\", \\\"{x:1118,y:984,t:1528143543479};\\\", \\\"{x:1114,y:985,t:1528143543494};\\\", \\\"{x:1111,y:985,t:1528143543511};\\\", \\\"{x:1110,y:985,t:1528143543535};\\\", \\\"{x:1108,y:985,t:1528143543559};\\\", \\\"{x:1106,y:985,t:1528143543575};\\\", \\\"{x:1106,y:984,t:1528143543582};\\\", \\\"{x:1105,y:983,t:1528143543596};\\\", \\\"{x:1105,y:982,t:1528143543615};\\\", \\\"{x:1105,y:981,t:1528143543631};\\\", \\\"{x:1105,y:979,t:1528143543646};\\\", \\\"{x:1104,y:977,t:1528143543662};\\\", \\\"{x:1103,y:974,t:1528143543679};\\\", \\\"{x:1103,y:971,t:1528143543695};\\\", \\\"{x:1103,y:968,t:1528143543712};\\\", \\\"{x:1104,y:964,t:1528143543729};\\\", \\\"{x:1105,y:961,t:1528143543746};\\\", \\\"{x:1105,y:960,t:1528143543762};\\\", \\\"{x:1105,y:959,t:1528143543790};\\\", \\\"{x:1104,y:959,t:1528143543807};\\\", \\\"{x:1101,y:959,t:1528143543814};\\\", \\\"{x:1098,y:959,t:1528143543831};\\\", \\\"{x:1096,y:959,t:1528143543846};\\\", \\\"{x:1092,y:959,t:1528143543861};\\\", \\\"{x:1076,y:961,t:1528143543879};\\\", \\\"{x:1061,y:964,t:1528143543896};\\\", \\\"{x:1058,y:964,t:1528143543912};\\\", \\\"{x:1057,y:964,t:1528143543929};\\\", \\\"{x:1058,y:963,t:1528143544087};\\\", \\\"{x:1059,y:963,t:1528143544095};\\\", \\\"{x:1065,y:961,t:1528143544113};\\\", \\\"{x:1077,y:960,t:1528143544128};\\\", \\\"{x:1094,y:960,t:1528143544146};\\\", \\\"{x:1113,y:960,t:1528143544162};\\\", \\\"{x:1133,y:960,t:1528143544179};\\\", \\\"{x:1154,y:960,t:1528143544196};\\\", \\\"{x:1164,y:960,t:1528143544212};\\\", \\\"{x:1166,y:960,t:1528143544229};\\\", \\\"{x:1168,y:960,t:1528143544246};\\\", \\\"{x:1168,y:961,t:1528143544262};\\\", \\\"{x:1168,y:962,t:1528143544327};\\\", \\\"{x:1168,y:963,t:1528143544343};\\\", \\\"{x:1168,y:964,t:1528143544351};\\\", \\\"{x:1168,y:965,t:1528143544362};\\\", \\\"{x:1165,y:968,t:1528143544379};\\\", \\\"{x:1151,y:972,t:1528143544395};\\\", \\\"{x:1141,y:973,t:1528143544412};\\\", \\\"{x:1132,y:974,t:1528143544429};\\\", \\\"{x:1125,y:974,t:1528143544446};\\\", \\\"{x:1124,y:974,t:1528143544471};\\\", \\\"{x:1124,y:973,t:1528143544535};\\\", \\\"{x:1125,y:971,t:1528143544551};\\\", \\\"{x:1126,y:970,t:1528143544566};\\\", \\\"{x:1127,y:969,t:1528143544583};\\\", \\\"{x:1129,y:968,t:1528143544596};\\\", \\\"{x:1140,y:967,t:1528143544613};\\\", \\\"{x:1151,y:964,t:1528143544629};\\\", \\\"{x:1155,y:962,t:1528143544646};\\\", \\\"{x:1158,y:962,t:1528143544662};\\\", \\\"{x:1166,y:962,t:1528143544679};\\\", \\\"{x:1176,y:962,t:1528143544695};\\\", \\\"{x:1185,y:963,t:1528143544712};\\\", \\\"{x:1188,y:964,t:1528143544729};\\\", \\\"{x:1189,y:965,t:1528143544746};\\\", \\\"{x:1192,y:967,t:1528143544762};\\\", \\\"{x:1196,y:970,t:1528143544780};\\\", \\\"{x:1203,y:971,t:1528143544796};\\\", \\\"{x:1208,y:972,t:1528143544812};\\\", \\\"{x:1210,y:972,t:1528143544830};\\\", \\\"{x:1212,y:973,t:1528143544846};\\\", \\\"{x:1213,y:974,t:1528143544879};\\\", \\\"{x:1214,y:974,t:1528143544896};\\\", \\\"{x:1215,y:974,t:1528143544999};\\\", \\\"{x:1217,y:974,t:1528143545071};\\\", \\\"{x:1218,y:974,t:1528143545080};\\\", \\\"{x:1222,y:974,t:1528143545096};\\\", \\\"{x:1226,y:974,t:1528143545112};\\\", \\\"{x:1229,y:974,t:1528143545129};\\\", \\\"{x:1232,y:973,t:1528143545146};\\\", \\\"{x:1234,y:973,t:1528143545162};\\\", \\\"{x:1236,y:973,t:1528143545180};\\\", \\\"{x:1238,y:973,t:1528143545196};\\\", \\\"{x:1242,y:973,t:1528143545213};\\\", \\\"{x:1247,y:973,t:1528143545230};\\\", \\\"{x:1269,y:974,t:1528143545246};\\\", \\\"{x:1290,y:976,t:1528143545263};\\\", \\\"{x:1309,y:979,t:1528143545280};\\\", \\\"{x:1318,y:979,t:1528143545297};\\\", \\\"{x:1319,y:979,t:1528143545327};\\\", \\\"{x:1318,y:979,t:1528143545527};\\\", \\\"{x:1317,y:978,t:1528143545542};\\\", \\\"{x:1316,y:978,t:1528143545558};\\\", \\\"{x:1315,y:976,t:1528143545583};\\\", \\\"{x:1314,y:975,t:1528143545596};\\\", \\\"{x:1312,y:974,t:1528143545614};\\\", \\\"{x:1310,y:973,t:1528143545638};\\\", \\\"{x:1308,y:973,t:1528143545662};\\\", \\\"{x:1306,y:973,t:1528143545680};\\\", \\\"{x:1306,y:972,t:1528143545718};\\\", \\\"{x:1305,y:972,t:1528143545742};\\\", \\\"{x:1303,y:972,t:1528143545775};\\\", \\\"{x:1302,y:972,t:1528143545791};\\\", \\\"{x:1300,y:972,t:1528143545807};\\\", \\\"{x:1299,y:972,t:1528143545823};\\\", \\\"{x:1297,y:972,t:1528143545831};\\\", \\\"{x:1304,y:971,t:1528143545911};\\\", \\\"{x:1315,y:971,t:1528143545919};\\\", \\\"{x:1323,y:971,t:1528143545931};\\\", \\\"{x:1339,y:971,t:1528143545947};\\\", \\\"{x:1357,y:971,t:1528143545963};\\\", \\\"{x:1372,y:971,t:1528143545982};\\\", \\\"{x:1376,y:971,t:1528143545997};\\\", \\\"{x:1377,y:972,t:1528143546014};\\\", \\\"{x:1377,y:973,t:1528143546030};\\\", \\\"{x:1376,y:975,t:1528143546046};\\\", \\\"{x:1374,y:977,t:1528143546063};\\\", \\\"{x:1373,y:978,t:1528143546081};\\\", \\\"{x:1371,y:978,t:1528143546097};\\\", \\\"{x:1366,y:980,t:1528143546114};\\\", \\\"{x:1365,y:981,t:1528143546134};\\\", \\\"{x:1364,y:981,t:1528143546174};\\\", \\\"{x:1363,y:981,t:1528143546191};\\\", \\\"{x:1362,y:981,t:1528143546343};\\\", \\\"{x:1362,y:980,t:1528143546350};\\\", \\\"{x:1362,y:978,t:1528143546364};\\\", \\\"{x:1368,y:976,t:1528143546381};\\\", \\\"{x:1376,y:972,t:1528143546398};\\\", \\\"{x:1391,y:969,t:1528143546414};\\\", \\\"{x:1416,y:966,t:1528143546430};\\\", \\\"{x:1424,y:965,t:1528143546447};\\\", \\\"{x:1426,y:965,t:1528143546463};\\\", \\\"{x:1428,y:965,t:1528143546486};\\\", \\\"{x:1429,y:965,t:1528143546607};\\\", \\\"{x:1429,y:966,t:1528143546630};\\\", \\\"{x:1427,y:968,t:1528143546711};\\\", \\\"{x:1426,y:968,t:1528143546791};\\\", \\\"{x:1425,y:968,t:1528143546807};\\\", \\\"{x:1424,y:969,t:1528143546815};\\\", \\\"{x:1423,y:970,t:1528143546830};\\\", \\\"{x:1420,y:970,t:1528143549150};\\\", \\\"{x:1418,y:968,t:1528143549166};\\\", \\\"{x:1407,y:957,t:1528143549182};\\\", \\\"{x:1394,y:949,t:1528143549200};\\\", \\\"{x:1384,y:944,t:1528143549216};\\\", \\\"{x:1380,y:943,t:1528143549233};\\\", \\\"{x:1379,y:943,t:1528143549710};\\\", \\\"{x:1373,y:943,t:1528143549718};\\\", \\\"{x:1364,y:943,t:1528143549734};\\\", \\\"{x:1329,y:931,t:1528143549750};\\\", \\\"{x:1255,y:895,t:1528143549766};\\\", \\\"{x:1196,y:848,t:1528143549784};\\\", \\\"{x:1153,y:791,t:1528143549800};\\\", \\\"{x:1131,y:734,t:1528143549817};\\\", \\\"{x:1112,y:665,t:1528143549834};\\\", \\\"{x:1080,y:603,t:1528143549850};\\\", \\\"{x:1044,y:557,t:1528143549867};\\\", \\\"{x:997,y:528,t:1528143549884};\\\", \\\"{x:958,y:516,t:1528143549900};\\\", \\\"{x:907,y:508,t:1528143549918};\\\", \\\"{x:874,y:508,t:1528143549933};\\\", \\\"{x:834,y:508,t:1528143549949};\\\", \\\"{x:795,y:508,t:1528143549966};\\\", \\\"{x:766,y:508,t:1528143549983};\\\", \\\"{x:732,y:508,t:1528143550000};\\\", \\\"{x:699,y:508,t:1528143550016};\\\", \\\"{x:662,y:508,t:1528143550033};\\\", \\\"{x:629,y:508,t:1528143550049};\\\", \\\"{x:590,y:517,t:1528143550066};\\\", \\\"{x:558,y:529,t:1528143550084};\\\", \\\"{x:530,y:541,t:1528143550100};\\\", \\\"{x:506,y:551,t:1528143550116};\\\", \\\"{x:491,y:557,t:1528143550134};\\\", \\\"{x:483,y:565,t:1528143550150};\\\", \\\"{x:482,y:566,t:1528143550165};\\\", \\\"{x:482,y:567,t:1528143550197};\\\", \\\"{x:485,y:567,t:1528143550245};\\\", \\\"{x:490,y:567,t:1528143550253};\\\", \\\"{x:499,y:570,t:1528143550268};\\\", \\\"{x:540,y:589,t:1528143550283};\\\", \\\"{x:602,y:601,t:1528143550301};\\\", \\\"{x:674,y:609,t:1528143550316};\\\", \\\"{x:730,y:609,t:1528143550335};\\\", \\\"{x:757,y:609,t:1528143550350};\\\", \\\"{x:758,y:610,t:1528143550366};\\\", \\\"{x:749,y:615,t:1528143550383};\\\", \\\"{x:706,y:627,t:1528143550400};\\\", \\\"{x:625,y:649,t:1528143550417};\\\", \\\"{x:572,y:659,t:1528143550433};\\\", \\\"{x:510,y:668,t:1528143550450};\\\", \\\"{x:457,y:668,t:1528143550467};\\\", \\\"{x:406,y:665,t:1528143550483};\\\", \\\"{x:366,y:653,t:1528143550500};\\\", \\\"{x:345,y:641,t:1528143550517};\\\", \\\"{x:341,y:632,t:1528143550534};\\\", \\\"{x:349,y:608,t:1528143550550};\\\", \\\"{x:375,y:592,t:1528143550568};\\\", \\\"{x:426,y:575,t:1528143550583};\\\", \\\"{x:501,y:557,t:1528143550600};\\\", \\\"{x:579,y:542,t:1528143550618};\\\", \\\"{x:678,y:532,t:1528143550633};\\\", \\\"{x:790,y:526,t:1528143550651};\\\", \\\"{x:893,y:526,t:1528143550667};\\\", \\\"{x:962,y:526,t:1528143550684};\\\", \\\"{x:995,y:530,t:1528143550700};\\\", \\\"{x:1006,y:534,t:1528143550717};\\\", \\\"{x:1007,y:542,t:1528143550733};\\\", \\\"{x:992,y:555,t:1528143550751};\\\", \\\"{x:973,y:563,t:1528143550768};\\\", \\\"{x:959,y:566,t:1528143550784};\\\", \\\"{x:951,y:569,t:1528143550800};\\\", \\\"{x:948,y:570,t:1528143550818};\\\", \\\"{x:944,y:570,t:1528143550834};\\\", \\\"{x:937,y:570,t:1528143550850};\\\", \\\"{x:918,y:568,t:1528143550867};\\\", \\\"{x:897,y:561,t:1528143550884};\\\", \\\"{x:882,y:556,t:1528143550900};\\\", \\\"{x:871,y:554,t:1528143550917};\\\", \\\"{x:868,y:552,t:1528143550935};\\\", \\\"{x:867,y:552,t:1528143550974};\\\", \\\"{x:871,y:551,t:1528143551221};\\\", \\\"{x:877,y:551,t:1528143551234};\\\", \\\"{x:899,y:555,t:1528143551251};\\\", \\\"{x:948,y:567,t:1528143551267};\\\", \\\"{x:1031,y:578,t:1528143551285};\\\", \\\"{x:1139,y:594,t:1528143551300};\\\", \\\"{x:1312,y:615,t:1528143551318};\\\", \\\"{x:1412,y:630,t:1528143551334};\\\", \\\"{x:1491,y:643,t:1528143551351};\\\", \\\"{x:1530,y:654,t:1528143551367};\\\", \\\"{x:1554,y:662,t:1528143551384};\\\", \\\"{x:1563,y:665,t:1528143551402};\\\", \\\"{x:1566,y:668,t:1528143551418};\\\", \\\"{x:1566,y:669,t:1528143551435};\\\", \\\"{x:1566,y:671,t:1528143551452};\\\", \\\"{x:1566,y:672,t:1528143551467};\\\", \\\"{x:1564,y:672,t:1528143551559};\\\", \\\"{x:1555,y:672,t:1528143551568};\\\", \\\"{x:1516,y:672,t:1528143551585};\\\", \\\"{x:1438,y:672,t:1528143551601};\\\", \\\"{x:1333,y:672,t:1528143551618};\\\", \\\"{x:1222,y:672,t:1528143551635};\\\", \\\"{x:1109,y:661,t:1528143551652};\\\", \\\"{x:1009,y:645,t:1528143551668};\\\", \\\"{x:965,y:637,t:1528143551685};\\\", \\\"{x:943,y:628,t:1528143551702};\\\", \\\"{x:934,y:622,t:1528143551719};\\\", \\\"{x:934,y:620,t:1528143551734};\\\", \\\"{x:932,y:618,t:1528143551752};\\\", \\\"{x:932,y:617,t:1528143551767};\\\", \\\"{x:929,y:614,t:1528143551784};\\\", \\\"{x:919,y:610,t:1528143551801};\\\", \\\"{x:904,y:606,t:1528143551818};\\\", \\\"{x:885,y:597,t:1528143551836};\\\", \\\"{x:863,y:588,t:1528143551852};\\\", \\\"{x:844,y:577,t:1528143551869};\\\", \\\"{x:839,y:572,t:1528143551884};\\\", \\\"{x:838,y:569,t:1528143551901};\\\", \\\"{x:838,y:564,t:1528143551918};\\\", \\\"{x:837,y:560,t:1528143551935};\\\", \\\"{x:837,y:558,t:1528143551951};\\\", \\\"{x:837,y:557,t:1528143551973};\\\", \\\"{x:837,y:556,t:1528143551985};\\\", \\\"{x:840,y:553,t:1528143552001};\\\", \\\"{x:842,y:550,t:1528143552018};\\\", \\\"{x:842,y:548,t:1528143552035};\\\", \\\"{x:843,y:547,t:1528143552051};\\\", \\\"{x:844,y:545,t:1528143552068};\\\", \\\"{x:844,y:544,t:1528143552366};\\\", \\\"{x:854,y:543,t:1528143552374};\\\", \\\"{x:870,y:547,t:1528143552386};\\\", \\\"{x:926,y:563,t:1528143552402};\\\", \\\"{x:1013,y:578,t:1528143552419};\\\", \\\"{x:1110,y:592,t:1528143552435};\\\", \\\"{x:1221,y:608,t:1528143552451};\\\", \\\"{x:1332,y:622,t:1528143552468};\\\", \\\"{x:1475,y:644,t:1528143552485};\\\", \\\"{x:1549,y:651,t:1528143552501};\\\", \\\"{x:1599,y:656,t:1528143552518};\\\", \\\"{x:1628,y:656,t:1528143552536};\\\", \\\"{x:1638,y:656,t:1528143552552};\\\", \\\"{x:1639,y:656,t:1528143552568};\\\", \\\"{x:1640,y:656,t:1528143552590};\\\", \\\"{x:1640,y:655,t:1528143552615};\\\", \\\"{x:1639,y:653,t:1528143552622};\\\", \\\"{x:1637,y:652,t:1528143552636};\\\", \\\"{x:1632,y:649,t:1528143552654};\\\", \\\"{x:1625,y:645,t:1528143552668};\\\", \\\"{x:1608,y:636,t:1528143552686};\\\", \\\"{x:1582,y:623,t:1528143552702};\\\", \\\"{x:1570,y:616,t:1528143552719};\\\", \\\"{x:1560,y:608,t:1528143552736};\\\", \\\"{x:1555,y:597,t:1528143552753};\\\", \\\"{x:1552,y:579,t:1528143552769};\\\", \\\"{x:1547,y:570,t:1528143552786};\\\", \\\"{x:1544,y:565,t:1528143552803};\\\", \\\"{x:1539,y:561,t:1528143552818};\\\", \\\"{x:1529,y:556,t:1528143552836};\\\", \\\"{x:1513,y:554,t:1528143552853};\\\", \\\"{x:1491,y:550,t:1528143552869};\\\", \\\"{x:1461,y:550,t:1528143552886};\\\", \\\"{x:1428,y:550,t:1528143552902};\\\", \\\"{x:1422,y:551,t:1528143552920};\\\", \\\"{x:1418,y:554,t:1528143552936};\\\", \\\"{x:1414,y:560,t:1528143552953};\\\", \\\"{x:1414,y:568,t:1528143552970};\\\", \\\"{x:1413,y:581,t:1528143552987};\\\", \\\"{x:1413,y:593,t:1528143553002};\\\", \\\"{x:1413,y:607,t:1528143553020};\\\", \\\"{x:1416,y:619,t:1528143553036};\\\", \\\"{x:1418,y:628,t:1528143553053};\\\", \\\"{x:1420,y:633,t:1528143553070};\\\", \\\"{x:1422,y:640,t:1528143553086};\\\", \\\"{x:1424,y:643,t:1528143553102};\\\", \\\"{x:1424,y:644,t:1528143553120};\\\", \\\"{x:1424,y:646,t:1528143553136};\\\", \\\"{x:1424,y:652,t:1528143553153};\\\", \\\"{x:1423,y:660,t:1528143553170};\\\", \\\"{x:1421,y:673,t:1528143553186};\\\", \\\"{x:1420,y:686,t:1528143553203};\\\", \\\"{x:1414,y:708,t:1528143553221};\\\", \\\"{x:1410,y:730,t:1528143553236};\\\", \\\"{x:1406,y:750,t:1528143553253};\\\", \\\"{x:1401,y:768,t:1528143553270};\\\", \\\"{x:1396,y:783,t:1528143553286};\\\", \\\"{x:1394,y:795,t:1528143553303};\\\", \\\"{x:1392,y:810,t:1528143553320};\\\", \\\"{x:1392,y:828,t:1528143553336};\\\", \\\"{x:1391,y:840,t:1528143553353};\\\", \\\"{x:1391,y:846,t:1528143553370};\\\", \\\"{x:1391,y:849,t:1528143553386};\\\", \\\"{x:1390,y:853,t:1528143553403};\\\", \\\"{x:1389,y:857,t:1528143553420};\\\", \\\"{x:1386,y:864,t:1528143553437};\\\", \\\"{x:1381,y:873,t:1528143553454};\\\", \\\"{x:1374,y:883,t:1528143553471};\\\", \\\"{x:1371,y:888,t:1528143553486};\\\", \\\"{x:1366,y:895,t:1528143553503};\\\", \\\"{x:1360,y:902,t:1528143553519};\\\", \\\"{x:1355,y:909,t:1528143553537};\\\", \\\"{x:1352,y:916,t:1528143553553};\\\", \\\"{x:1350,y:920,t:1528143553570};\\\", \\\"{x:1349,y:921,t:1528143553587};\\\", \\\"{x:1348,y:924,t:1528143553603};\\\", \\\"{x:1347,y:925,t:1528143553620};\\\", \\\"{x:1347,y:926,t:1528143553637};\\\", \\\"{x:1347,y:928,t:1528143553654};\\\", \\\"{x:1345,y:931,t:1528143553670};\\\", \\\"{x:1345,y:933,t:1528143553687};\\\", \\\"{x:1345,y:936,t:1528143553702};\\\", \\\"{x:1344,y:939,t:1528143553720};\\\", \\\"{x:1343,y:940,t:1528143553737};\\\", \\\"{x:1344,y:941,t:1528143553766};\\\", \\\"{x:1350,y:941,t:1528143553775};\\\", \\\"{x:1355,y:942,t:1528143553787};\\\", \\\"{x:1369,y:942,t:1528143553803};\\\", \\\"{x:1384,y:942,t:1528143553819};\\\", \\\"{x:1397,y:942,t:1528143553837};\\\", \\\"{x:1402,y:942,t:1528143553853};\\\", \\\"{x:1404,y:942,t:1528143553871};\\\", \\\"{x:1404,y:941,t:1528143555320};\\\", \\\"{x:1405,y:941,t:1528143555391};\\\", \\\"{x:1406,y:941,t:1528143555407};\\\", \\\"{x:1407,y:941,t:1528143555422};\\\", \\\"{x:1417,y:942,t:1528143555439};\\\", \\\"{x:1421,y:943,t:1528143555455};\\\", \\\"{x:1428,y:944,t:1528143555471};\\\", \\\"{x:1434,y:944,t:1528143555488};\\\", \\\"{x:1448,y:945,t:1528143555505};\\\", \\\"{x:1463,y:945,t:1528143555521};\\\", \\\"{x:1477,y:946,t:1528143555538};\\\", \\\"{x:1486,y:947,t:1528143555555};\\\", \\\"{x:1491,y:950,t:1528143555571};\\\", \\\"{x:1499,y:952,t:1528143555588};\\\", \\\"{x:1503,y:954,t:1528143555605};\\\", \\\"{x:1505,y:955,t:1528143555621};\\\", \\\"{x:1509,y:957,t:1528143555638};\\\", \\\"{x:1510,y:957,t:1528143555655};\\\", \\\"{x:1510,y:958,t:1528143555719};\\\", \\\"{x:1510,y:959,t:1528143555791};\\\", \\\"{x:1510,y:961,t:1528143555805};\\\", \\\"{x:1493,y:967,t:1528143555822};\\\", \\\"{x:1478,y:971,t:1528143555839};\\\", \\\"{x:1458,y:975,t:1528143555855};\\\", \\\"{x:1440,y:976,t:1528143555872};\\\", \\\"{x:1428,y:977,t:1528143555888};\\\", \\\"{x:1423,y:978,t:1528143555905};\\\", \\\"{x:1422,y:978,t:1528143555921};\\\", \\\"{x:1421,y:979,t:1528143555938};\\\", \\\"{x:1420,y:979,t:1528143556103};\\\", \\\"{x:1420,y:977,t:1528143556175};\\\", \\\"{x:1420,y:976,t:1528143556190};\\\", \\\"{x:1420,y:975,t:1528143556206};\\\", \\\"{x:1420,y:974,t:1528143556222};\\\", \\\"{x:1420,y:973,t:1528143556238};\\\", \\\"{x:1420,y:972,t:1528143556311};\\\", \\\"{x:1420,y:971,t:1528143556326};\\\", \\\"{x:1419,y:970,t:1528143556399};\\\", \\\"{x:1418,y:969,t:1528143556478};\\\", \\\"{x:1417,y:968,t:1528143556511};\\\", \\\"{x:1416,y:967,t:1528143556534};\\\", \\\"{x:1415,y:966,t:1528143557173};\\\", \\\"{x:1413,y:966,t:1528143557188};\\\", \\\"{x:1408,y:965,t:1528143557205};\\\", \\\"{x:1402,y:965,t:1528143557222};\\\", \\\"{x:1397,y:964,t:1528143557238};\\\", \\\"{x:1395,y:963,t:1528143557255};\\\", \\\"{x:1393,y:963,t:1528143557273};\\\", \\\"{x:1392,y:963,t:1528143557288};\\\", \\\"{x:1391,y:963,t:1528143557334};\\\", \\\"{x:1390,y:963,t:1528143557374};\\\", \\\"{x:1389,y:963,t:1528143557398};\\\", \\\"{x:1388,y:963,t:1528143557423};\\\", \\\"{x:1386,y:962,t:1528143557440};\\\", \\\"{x:1383,y:962,t:1528143557456};\\\", \\\"{x:1382,y:962,t:1528143557478};\\\", \\\"{x:1381,y:962,t:1528143557502};\\\", \\\"{x:1380,y:962,t:1528143557527};\\\", \\\"{x:1379,y:962,t:1528143557540};\\\", \\\"{x:1378,y:962,t:1528143557558};\\\", \\\"{x:1377,y:962,t:1528143557591};\\\", \\\"{x:1376,y:962,t:1528143557638};\\\", \\\"{x:1375,y:962,t:1528143557647};\\\", \\\"{x:1374,y:962,t:1528143557662};\\\", \\\"{x:1373,y:962,t:1528143557702};\\\", \\\"{x:1372,y:962,t:1528143557727};\\\", \\\"{x:1371,y:962,t:1528143557839};\\\", \\\"{x:1370,y:962,t:1528143557858};\\\", \\\"{x:1369,y:962,t:1528143557873};\\\", \\\"{x:1368,y:962,t:1528143557890};\\\", \\\"{x:1366,y:962,t:1528143557906};\\\", \\\"{x:1365,y:962,t:1528143557957};\\\", \\\"{x:1364,y:962,t:1528143557972};\\\", \\\"{x:1362,y:963,t:1528143557990};\\\", \\\"{x:1360,y:963,t:1528143558007};\\\", \\\"{x:1358,y:964,t:1528143558030};\\\", \\\"{x:1357,y:964,t:1528143558110};\\\", \\\"{x:1356,y:964,t:1528143558151};\\\", \\\"{x:1355,y:964,t:1528143558174};\\\", \\\"{x:1354,y:964,t:1528143558190};\\\", \\\"{x:1353,y:964,t:1528143558302};\\\", \\\"{x:1354,y:962,t:1528143558327};\\\", \\\"{x:1355,y:962,t:1528143558340};\\\", \\\"{x:1356,y:962,t:1528143558358};\\\", \\\"{x:1359,y:962,t:1528143558374};\\\", \\\"{x:1369,y:962,t:1528143558390};\\\", \\\"{x:1381,y:962,t:1528143558408};\\\", \\\"{x:1396,y:962,t:1528143558424};\\\", \\\"{x:1403,y:962,t:1528143558441};\\\", \\\"{x:1406,y:962,t:1528143558457};\\\", \\\"{x:1407,y:962,t:1528143558475};\\\", \\\"{x:1408,y:962,t:1528143558490};\\\", \\\"{x:1409,y:962,t:1528143558507};\\\", \\\"{x:1409,y:963,t:1528143558663};\\\", \\\"{x:1409,y:964,t:1528143558674};\\\", \\\"{x:1409,y:965,t:1528143558703};\\\", \\\"{x:1410,y:965,t:1528143558799};\\\", \\\"{x:1411,y:965,t:1528143558807};\\\", \\\"{x:1412,y:965,t:1528143558824};\\\", \\\"{x:1413,y:965,t:1528143558842};\\\", \\\"{x:1414,y:965,t:1528143558857};\\\", \\\"{x:1415,y:965,t:1528143558874};\\\", \\\"{x:1415,y:966,t:1528143558894};\\\", \\\"{x:1416,y:966,t:1528143558935};\\\", \\\"{x:1418,y:966,t:1528143558942};\\\", \\\"{x:1420,y:966,t:1528143558957};\\\", \\\"{x:1427,y:966,t:1528143558974};\\\", \\\"{x:1433,y:966,t:1528143558991};\\\", \\\"{x:1439,y:966,t:1528143559007};\\\", \\\"{x:1445,y:966,t:1528143559024};\\\", \\\"{x:1452,y:966,t:1528143559041};\\\", \\\"{x:1459,y:966,t:1528143559057};\\\", \\\"{x:1468,y:966,t:1528143559074};\\\", \\\"{x:1472,y:966,t:1528143559091};\\\", \\\"{x:1477,y:966,t:1528143559107};\\\", \\\"{x:1480,y:966,t:1528143559124};\\\", \\\"{x:1484,y:966,t:1528143559142};\\\", \\\"{x:1484,y:967,t:1528143559174};\\\", \\\"{x:1485,y:967,t:1528143559191};\\\", \\\"{x:1486,y:968,t:1528143559231};\\\", \\\"{x:1487,y:968,t:1528143559242};\\\", \\\"{x:1487,y:969,t:1528143559343};\\\", \\\"{x:1487,y:970,t:1528143559358};\\\", \\\"{x:1486,y:972,t:1528143559374};\\\", \\\"{x:1481,y:973,t:1528143559391};\\\", \\\"{x:1475,y:974,t:1528143559408};\\\", \\\"{x:1474,y:974,t:1528143559424};\\\", \\\"{x:1477,y:974,t:1528143559526};\\\", \\\"{x:1479,y:974,t:1528143559541};\\\", \\\"{x:1486,y:973,t:1528143559558};\\\", \\\"{x:1488,y:973,t:1528143559575};\\\", \\\"{x:1489,y:973,t:1528143559591};\\\", \\\"{x:1493,y:972,t:1528143559608};\\\", \\\"{x:1499,y:971,t:1528143559625};\\\", \\\"{x:1503,y:971,t:1528143559641};\\\", \\\"{x:1508,y:971,t:1528143559658};\\\", \\\"{x:1516,y:971,t:1528143559675};\\\", \\\"{x:1523,y:971,t:1528143559691};\\\", \\\"{x:1529,y:971,t:1528143559708};\\\", \\\"{x:1535,y:971,t:1528143559725};\\\", \\\"{x:1537,y:971,t:1528143559741};\\\", \\\"{x:1538,y:971,t:1528143559758};\\\", \\\"{x:1540,y:971,t:1528143559775};\\\", \\\"{x:1541,y:971,t:1528143559791};\\\", \\\"{x:1544,y:971,t:1528143559808};\\\", \\\"{x:1547,y:971,t:1528143559825};\\\", \\\"{x:1548,y:971,t:1528143559841};\\\", \\\"{x:1550,y:971,t:1528143559858};\\\", \\\"{x:1551,y:971,t:1528143560054};\\\", \\\"{x:1553,y:971,t:1528143560070};\\\", \\\"{x:1555,y:971,t:1528143560078};\\\", \\\"{x:1558,y:971,t:1528143560092};\\\", \\\"{x:1565,y:971,t:1528143560108};\\\", \\\"{x:1574,y:970,t:1528143560126};\\\", \\\"{x:1584,y:968,t:1528143560143};\\\", \\\"{x:1589,y:968,t:1528143560158};\\\", \\\"{x:1592,y:967,t:1528143560175};\\\", \\\"{x:1596,y:967,t:1528143560192};\\\", \\\"{x:1597,y:967,t:1528143560215};\\\", \\\"{x:1598,y:967,t:1528143560225};\\\", \\\"{x:1599,y:967,t:1528143560242};\\\", \\\"{x:1600,y:967,t:1528143560271};\\\", \\\"{x:1602,y:967,t:1528143560287};\\\", \\\"{x:1603,y:966,t:1528143560295};\\\", \\\"{x:1605,y:966,t:1528143560309};\\\", \\\"{x:1607,y:966,t:1528143560325};\\\", \\\"{x:1608,y:966,t:1528143560342};\\\", \\\"{x:1610,y:966,t:1528143560414};\\\", \\\"{x:1612,y:966,t:1528143560702};\\\", \\\"{x:1613,y:966,t:1528143560727};\\\", \\\"{x:1617,y:966,t:1528143560742};\\\", \\\"{x:1624,y:966,t:1528143560759};\\\", \\\"{x:1636,y:966,t:1528143560775};\\\", \\\"{x:1646,y:966,t:1528143560792};\\\", \\\"{x:1652,y:966,t:1528143560809};\\\", \\\"{x:1657,y:966,t:1528143560825};\\\", \\\"{x:1662,y:966,t:1528143560842};\\\", \\\"{x:1664,y:965,t:1528143560859};\\\", \\\"{x:1665,y:965,t:1528143560875};\\\", \\\"{x:1667,y:965,t:1528143560942};\\\", \\\"{x:1669,y:964,t:1528143560959};\\\", \\\"{x:1671,y:964,t:1528143561302};\\\", \\\"{x:1672,y:964,t:1528143561318};\\\", \\\"{x:1674,y:964,t:1528143562358};\\\", \\\"{x:1676,y:964,t:1528143562399};\\\", \\\"{x:1677,y:964,t:1528143562414};\\\", \\\"{x:1678,y:964,t:1528143562463};\\\", \\\"{x:1679,y:964,t:1528143562477};\\\", \\\"{x:1680,y:964,t:1528143562493};\\\", \\\"{x:1682,y:964,t:1528143562510};\\\", \\\"{x:1683,y:964,t:1528143562527};\\\", \\\"{x:1685,y:964,t:1528143562550};\\\", \\\"{x:1686,y:964,t:1528143562566};\\\", \\\"{x:1687,y:964,t:1528143562577};\\\", \\\"{x:1689,y:964,t:1528143562594};\\\", \\\"{x:1691,y:963,t:1528143562610};\\\", \\\"{x:1694,y:963,t:1528143562627};\\\", \\\"{x:1699,y:962,t:1528143562645};\\\", \\\"{x:1701,y:962,t:1528143562660};\\\", \\\"{x:1704,y:961,t:1528143562677};\\\", \\\"{x:1707,y:961,t:1528143562693};\\\", \\\"{x:1708,y:961,t:1528143562710};\\\", \\\"{x:1710,y:961,t:1528143562728};\\\", \\\"{x:1711,y:961,t:1528143562750};\\\", \\\"{x:1712,y:961,t:1528143562760};\\\", \\\"{x:1714,y:961,t:1528143562778};\\\", \\\"{x:1716,y:961,t:1528143562795};\\\", \\\"{x:1717,y:961,t:1528143562823};\\\", \\\"{x:1718,y:961,t:1528143562831};\\\", \\\"{x:1720,y:961,t:1528143562844};\\\", \\\"{x:1723,y:961,t:1528143562859};\\\", \\\"{x:1726,y:961,t:1528143562876};\\\", \\\"{x:1731,y:961,t:1528143562893};\\\", \\\"{x:1734,y:961,t:1528143562909};\\\", \\\"{x:1737,y:961,t:1528143562927};\\\", \\\"{x:1739,y:961,t:1528143562943};\\\", \\\"{x:1741,y:962,t:1528143562959};\\\", \\\"{x:1744,y:962,t:1528143562977};\\\", \\\"{x:1746,y:962,t:1528143562998};\\\", \\\"{x:1747,y:962,t:1528143563607};\\\", \\\"{x:1749,y:962,t:1528143563623};\\\", \\\"{x:1751,y:962,t:1528143563630};\\\", \\\"{x:1755,y:962,t:1528143563645};\\\", \\\"{x:1766,y:961,t:1528143563662};\\\", \\\"{x:1788,y:961,t:1528143563678};\\\", \\\"{x:1802,y:961,t:1528143563694};\\\", \\\"{x:1810,y:961,t:1528143563711};\\\", \\\"{x:1812,y:961,t:1528143563729};\\\", \\\"{x:1813,y:961,t:1528143563744};\\\", \\\"{x:1814,y:961,t:1528143563783};\\\", \\\"{x:1814,y:960,t:1528143565751};\\\", \\\"{x:1814,y:959,t:1528143565763};\\\", \\\"{x:1814,y:958,t:1528143565779};\\\", \\\"{x:1814,y:957,t:1528143566095};\\\", \\\"{x:1814,y:956,t:1528143566110};\\\", \\\"{x:1813,y:956,t:1528143566118};\\\", \\\"{x:1810,y:956,t:1528143566719};\\\", \\\"{x:1804,y:956,t:1528143566731};\\\", \\\"{x:1785,y:956,t:1528143566748};\\\", \\\"{x:1747,y:956,t:1528143566764};\\\", \\\"{x:1672,y:956,t:1528143566780};\\\", \\\"{x:1561,y:938,t:1528143566797};\\\", \\\"{x:1425,y:919,t:1528143566813};\\\", \\\"{x:1208,y:887,t:1528143566830};\\\", \\\"{x:1077,y:868,t:1528143566847};\\\", \\\"{x:952,y:845,t:1528143566863};\\\", \\\"{x:823,y:813,t:1528143566879};\\\", \\\"{x:718,y:789,t:1528143566896};\\\", \\\"{x:650,y:771,t:1528143566912};\\\", \\\"{x:604,y:764,t:1528143566930};\\\", \\\"{x:578,y:759,t:1528143566947};\\\", \\\"{x:558,y:755,t:1528143566962};\\\", \\\"{x:549,y:754,t:1528143566980};\\\", \\\"{x:539,y:753,t:1528143566996};\\\", \\\"{x:533,y:753,t:1528143567013};\\\", \\\"{x:529,y:751,t:1528143567029};\\\", \\\"{x:528,y:751,t:1528143567046};\\\", \\\"{x:527,y:751,t:1528143567064};\\\", \\\"{x:522,y:751,t:1528143567080};\\\", \\\"{x:520,y:751,t:1528143567097};\\\", \\\"{x:519,y:750,t:1528143567141};\\\", \\\"{x:520,y:750,t:1528143567477};\\\" ] }, { \\\"rt\\\": 26328, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 11, \\\"time_elapsed\\\": 682286, \\\"internal_node_id\\\": \\\"0.0-6.0-1.0\\\", \\\"subject\\\": \\\"K0CNH\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+starts\\\", \\\"q\\\": 7, \\\"clicks\\\": 2.5, \\\"explicit\\\": 2, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"X\\\", \\\"O\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-O -X -X -X -X \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:515,y:747,t:1528143569662};\\\", \\\"{x:504,y:743,t:1528143569670};\\\", \\\"{x:496,y:740,t:1528143569685};\\\", \\\"{x:474,y:729,t:1528143569701};\\\", \\\"{x:458,y:719,t:1528143569718};\\\", \\\"{x:439,y:708,t:1528143569734};\\\", \\\"{x:431,y:702,t:1528143569749};\\\", \\\"{x:428,y:695,t:1528143569765};\\\", \\\"{x:425,y:686,t:1528143569782};\\\", \\\"{x:421,y:670,t:1528143569798};\\\", \\\"{x:417,y:655,t:1528143569816};\\\", \\\"{x:409,y:631,t:1528143569833};\\\", \\\"{x:398,y:605,t:1528143569849};\\\", \\\"{x:386,y:584,t:1528143569866};\\\", \\\"{x:373,y:567,t:1528143569882};\\\", \\\"{x:364,y:555,t:1528143569899};\\\", \\\"{x:354,y:544,t:1528143569916};\\\", \\\"{x:348,y:540,t:1528143569933};\\\", \\\"{x:344,y:537,t:1528143569949};\\\", \\\"{x:343,y:536,t:1528143569965};\\\", \\\"{x:342,y:536,t:1528143570006};\\\", \\\"{x:342,y:535,t:1528143570016};\\\", \\\"{x:340,y:533,t:1528143570034};\\\", \\\"{x:337,y:533,t:1528143570050};\\\", \\\"{x:330,y:529,t:1528143570066};\\\", \\\"{x:326,y:528,t:1528143570083};\\\", \\\"{x:319,y:525,t:1528143570099};\\\", \\\"{x:315,y:523,t:1528143570117};\\\", \\\"{x:308,y:517,t:1528143570134};\\\", \\\"{x:305,y:513,t:1528143570149};\\\", \\\"{x:295,y:503,t:1528143570166};\\\", \\\"{x:287,y:493,t:1528143570182};\\\", \\\"{x:278,y:482,t:1528143570199};\\\", \\\"{x:273,y:475,t:1528143570215};\\\", \\\"{x:272,y:471,t:1528143570232};\\\", \\\"{x:272,y:468,t:1528143570248};\\\", \\\"{x:278,y:460,t:1528143570265};\\\", \\\"{x:289,y:453,t:1528143570281};\\\", \\\"{x:303,y:449,t:1528143570299};\\\", \\\"{x:316,y:444,t:1528143570315};\\\", \\\"{x:317,y:444,t:1528143570332};\\\", \\\"{x:321,y:443,t:1528143570382};\\\", \\\"{x:324,y:442,t:1528143570398};\\\", \\\"{x:326,y:442,t:1528143570415};\\\", \\\"{x:328,y:441,t:1528143570432};\\\", \\\"{x:329,y:440,t:1528143570448};\\\", \\\"{x:333,y:440,t:1528143570465};\\\", \\\"{x:342,y:440,t:1528143570481};\\\", \\\"{x:365,y:440,t:1528143570498};\\\", \\\"{x:393,y:440,t:1528143570515};\\\", \\\"{x:425,y:443,t:1528143570531};\\\", \\\"{x:451,y:444,t:1528143570548};\\\", \\\"{x:469,y:446,t:1528143570565};\\\", \\\"{x:483,y:448,t:1528143570582};\\\", \\\"{x:485,y:448,t:1528143570599};\\\", \\\"{x:486,y:448,t:1528143570686};\\\", \\\"{x:488,y:448,t:1528143570697};\\\", \\\"{x:492,y:449,t:1528143570715};\\\", \\\"{x:496,y:450,t:1528143570730};\\\", \\\"{x:499,y:450,t:1528143570748};\\\", \\\"{x:509,y:452,t:1528143570764};\\\", \\\"{x:523,y:453,t:1528143570781};\\\", \\\"{x:537,y:456,t:1528143570797};\\\", \\\"{x:554,y:457,t:1528143570814};\\\", \\\"{x:563,y:458,t:1528143570830};\\\", \\\"{x:571,y:460,t:1528143570848};\\\", \\\"{x:577,y:460,t:1528143570864};\\\", \\\"{x:583,y:460,t:1528143570880};\\\", \\\"{x:589,y:460,t:1528143570896};\\\", \\\"{x:595,y:461,t:1528143570914};\\\", \\\"{x:600,y:461,t:1528143570931};\\\", \\\"{x:605,y:461,t:1528143570947};\\\", \\\"{x:608,y:461,t:1528143570963};\\\", \\\"{x:609,y:461,t:1528143570980};\\\", \\\"{x:611,y:461,t:1528143570996};\\\", \\\"{x:614,y:461,t:1528143571013};\\\", \\\"{x:625,y:461,t:1528143571029};\\\", \\\"{x:632,y:461,t:1528143571046};\\\", \\\"{x:640,y:461,t:1528143571063};\\\", \\\"{x:650,y:462,t:1528143571079};\\\", \\\"{x:660,y:462,t:1528143571096};\\\", \\\"{x:671,y:462,t:1528143571113};\\\", \\\"{x:686,y:466,t:1528143571129};\\\", \\\"{x:704,y:468,t:1528143571146};\\\", \\\"{x:726,y:471,t:1528143571163};\\\", \\\"{x:744,y:472,t:1528143571180};\\\", \\\"{x:755,y:472,t:1528143571195};\\\", \\\"{x:765,y:473,t:1528143571213};\\\", \\\"{x:779,y:476,t:1528143571229};\\\", \\\"{x:797,y:478,t:1528143571246};\\\", \\\"{x:829,y:482,t:1528143571262};\\\", \\\"{x:851,y:485,t:1528143571278};\\\", \\\"{x:866,y:488,t:1528143571297};\\\", \\\"{x:879,y:489,t:1528143571312};\\\", \\\"{x:898,y:494,t:1528143571333};\\\", \\\"{x:915,y:499,t:1528143571349};\\\", \\\"{x:933,y:505,t:1528143571367};\\\", \\\"{x:948,y:509,t:1528143571384};\\\", \\\"{x:961,y:513,t:1528143571401};\\\", \\\"{x:978,y:517,t:1528143571416};\\\", \\\"{x:992,y:520,t:1528143571434};\\\", \\\"{x:1000,y:523,t:1528143571450};\\\", \\\"{x:1009,y:525,t:1528143571468};\\\", \\\"{x:1018,y:528,t:1528143571484};\\\", \\\"{x:1030,y:532,t:1528143571500};\\\", \\\"{x:1050,y:540,t:1528143571517};\\\", \\\"{x:1067,y:545,t:1528143571533};\\\", \\\"{x:1084,y:550,t:1528143571550};\\\", \\\"{x:1104,y:556,t:1528143571568};\\\", \\\"{x:1124,y:561,t:1528143571585};\\\", \\\"{x:1143,y:567,t:1528143571601};\\\", \\\"{x:1162,y:574,t:1528143571617};\\\", \\\"{x:1178,y:580,t:1528143571634};\\\", \\\"{x:1191,y:585,t:1528143571650};\\\", \\\"{x:1207,y:592,t:1528143571667};\\\", \\\"{x:1223,y:598,t:1528143571684};\\\", \\\"{x:1243,y:606,t:1528143571700};\\\", \\\"{x:1274,y:616,t:1528143571718};\\\", \\\"{x:1294,y:625,t:1528143571734};\\\", \\\"{x:1314,y:634,t:1528143571751};\\\", \\\"{x:1330,y:640,t:1528143571768};\\\", \\\"{x:1346,y:648,t:1528143571785};\\\", \\\"{x:1360,y:655,t:1528143571802};\\\", \\\"{x:1369,y:661,t:1528143571818};\\\", \\\"{x:1383,y:671,t:1528143571835};\\\", \\\"{x:1399,y:682,t:1528143571852};\\\", \\\"{x:1414,y:696,t:1528143571867};\\\", \\\"{x:1432,y:714,t:1528143571885};\\\", \\\"{x:1459,y:733,t:1528143571902};\\\", \\\"{x:1469,y:740,t:1528143571918};\\\", \\\"{x:1498,y:754,t:1528143571935};\\\", \\\"{x:1512,y:761,t:1528143571954};\\\", \\\"{x:1513,y:761,t:1528143571966};\\\", \\\"{x:1513,y:759,t:1528143575761};\\\", \\\"{x:1511,y:759,t:1528143575777};\\\", \\\"{x:1506,y:759,t:1528143575794};\\\", \\\"{x:1505,y:759,t:1528143575808};\\\", \\\"{x:1503,y:759,t:1528143575824};\\\", \\\"{x:1501,y:759,t:1528143576001};\\\", \\\"{x:1500,y:759,t:1528143576016};\\\", \\\"{x:1498,y:759,t:1528143576025};\\\", \\\"{x:1496,y:759,t:1528143576049};\\\", \\\"{x:1495,y:759,t:1528143576057};\\\", \\\"{x:1492,y:759,t:1528143576074};\\\", \\\"{x:1489,y:759,t:1528143576091};\\\", \\\"{x:1486,y:761,t:1528143576108};\\\", \\\"{x:1482,y:764,t:1528143576123};\\\", \\\"{x:1476,y:768,t:1528143576141};\\\", \\\"{x:1472,y:772,t:1528143576157};\\\", \\\"{x:1468,y:775,t:1528143576174};\\\", \\\"{x:1465,y:778,t:1528143576191};\\\", \\\"{x:1463,y:781,t:1528143576207};\\\", \\\"{x:1456,y:791,t:1528143576224};\\\", \\\"{x:1450,y:798,t:1528143576241};\\\", \\\"{x:1444,y:806,t:1528143576257};\\\", \\\"{x:1441,y:814,t:1528143576274};\\\", \\\"{x:1439,y:821,t:1528143576290};\\\", \\\"{x:1437,y:825,t:1528143576308};\\\", \\\"{x:1437,y:829,t:1528143576324};\\\", \\\"{x:1436,y:829,t:1528143576409};\\\", \\\"{x:1435,y:830,t:1528143576456};\\\", \\\"{x:1434,y:832,t:1528143576472};\\\", \\\"{x:1433,y:833,t:1528143576488};\\\", \\\"{x:1432,y:834,t:1528143576496};\\\", \\\"{x:1431,y:835,t:1528143576520};\\\", \\\"{x:1431,y:836,t:1528143576544};\\\", \\\"{x:1430,y:836,t:1528143576560};\\\", \\\"{x:1429,y:837,t:1528143576584};\\\", \\\"{x:1429,y:838,t:1528143576592};\\\", \\\"{x:1429,y:839,t:1528143576608};\\\", \\\"{x:1429,y:840,t:1528143576624};\\\", \\\"{x:1429,y:841,t:1528143576641};\\\", \\\"{x:1429,y:843,t:1528143576673};\\\", \\\"{x:1429,y:844,t:1528143576817};\\\", \\\"{x:1429,y:846,t:1528143576824};\\\", \\\"{x:1434,y:848,t:1528143576842};\\\", \\\"{x:1445,y:851,t:1528143576857};\\\", \\\"{x:1458,y:854,t:1528143576874};\\\", \\\"{x:1472,y:857,t:1528143576892};\\\", \\\"{x:1483,y:860,t:1528143576907};\\\", \\\"{x:1494,y:864,t:1528143576925};\\\", \\\"{x:1509,y:868,t:1528143576941};\\\", \\\"{x:1525,y:873,t:1528143576957};\\\", \\\"{x:1538,y:878,t:1528143576974};\\\", \\\"{x:1550,y:884,t:1528143576991};\\\", \\\"{x:1576,y:896,t:1528143577007};\\\", \\\"{x:1612,y:908,t:1528143577024};\\\", \\\"{x:1632,y:916,t:1528143577041};\\\", \\\"{x:1642,y:921,t:1528143577058};\\\", \\\"{x:1643,y:921,t:1528143577074};\\\", \\\"{x:1644,y:922,t:1528143577091};\\\", \\\"{x:1643,y:922,t:1528143577112};\\\", \\\"{x:1642,y:922,t:1528143577124};\\\", \\\"{x:1637,y:922,t:1528143577141};\\\", \\\"{x:1635,y:922,t:1528143577158};\\\", \\\"{x:1633,y:922,t:1528143577174};\\\", \\\"{x:1631,y:922,t:1528143577192};\\\", \\\"{x:1630,y:922,t:1528143577209};\\\", \\\"{x:1629,y:922,t:1528143577241};\\\", \\\"{x:1628,y:922,t:1528143577281};\\\", \\\"{x:1627,y:922,t:1528143577297};\\\", \\\"{x:1627,y:921,t:1528143577633};\\\", \\\"{x:1626,y:920,t:1528143577689};\\\", \\\"{x:1625,y:919,t:1528143578041};\\\", \\\"{x:1623,y:917,t:1528143579273};\\\", \\\"{x:1622,y:917,t:1528143579289};\\\", \\\"{x:1619,y:917,t:1528143579297};\\\", \\\"{x:1614,y:915,t:1528143579309};\\\", \\\"{x:1609,y:915,t:1528143579327};\\\", \\\"{x:1600,y:913,t:1528143579344};\\\", \\\"{x:1590,y:912,t:1528143579359};\\\", \\\"{x:1577,y:910,t:1528143579377};\\\", \\\"{x:1571,y:909,t:1528143579393};\\\", \\\"{x:1567,y:909,t:1528143579410};\\\", \\\"{x:1565,y:908,t:1528143579426};\\\", \\\"{x:1563,y:908,t:1528143579443};\\\", \\\"{x:1562,y:908,t:1528143579465};\\\", \\\"{x:1561,y:908,t:1528143579488};\\\", \\\"{x:1560,y:908,t:1528143579497};\\\", \\\"{x:1559,y:908,t:1528143579520};\\\", \\\"{x:1559,y:907,t:1528143579529};\\\", \\\"{x:1558,y:907,t:1528143581154};\\\", \\\"{x:1557,y:907,t:1528143583145};\\\", \\\"{x:1547,y:907,t:1528143583163};\\\", \\\"{x:1539,y:907,t:1528143583179};\\\", \\\"{x:1530,y:907,t:1528143583197};\\\", \\\"{x:1519,y:908,t:1528143583213};\\\", \\\"{x:1509,y:909,t:1528143583230};\\\", \\\"{x:1505,y:910,t:1528143583247};\\\", \\\"{x:1502,y:910,t:1528143583263};\\\", \\\"{x:1499,y:911,t:1528143583280};\\\", \\\"{x:1495,y:912,t:1528143583297};\\\", \\\"{x:1492,y:912,t:1528143583312};\\\", \\\"{x:1487,y:915,t:1528143583330};\\\", \\\"{x:1480,y:916,t:1528143583346};\\\", \\\"{x:1470,y:919,t:1528143583363};\\\", \\\"{x:1461,y:920,t:1528143583379};\\\", \\\"{x:1453,y:921,t:1528143583397};\\\", \\\"{x:1444,y:923,t:1528143583413};\\\", \\\"{x:1435,y:924,t:1528143583430};\\\", \\\"{x:1425,y:926,t:1528143583446};\\\", \\\"{x:1416,y:928,t:1528143583463};\\\", \\\"{x:1403,y:929,t:1528143583480};\\\", \\\"{x:1394,y:930,t:1528143583497};\\\", \\\"{x:1390,y:932,t:1528143583513};\\\", \\\"{x:1388,y:933,t:1528143583530};\\\", \\\"{x:1386,y:934,t:1528143583547};\\\", \\\"{x:1385,y:935,t:1528143583563};\\\", \\\"{x:1384,y:937,t:1528143583580};\\\", \\\"{x:1381,y:939,t:1528143583597};\\\", \\\"{x:1381,y:942,t:1528143583614};\\\", \\\"{x:1380,y:943,t:1528143583630};\\\", \\\"{x:1380,y:945,t:1528143583646};\\\", \\\"{x:1380,y:947,t:1528143583664};\\\", \\\"{x:1380,y:949,t:1528143583680};\\\", \\\"{x:1380,y:952,t:1528143583697};\\\", \\\"{x:1380,y:954,t:1528143583714};\\\", \\\"{x:1380,y:955,t:1528143583730};\\\", \\\"{x:1380,y:957,t:1528143583747};\\\", \\\"{x:1380,y:958,t:1528143583764};\\\", \\\"{x:1380,y:960,t:1528143583780};\\\", \\\"{x:1380,y:961,t:1528143583801};\\\", \\\"{x:1381,y:961,t:1528143583841};\\\", \\\"{x:1383,y:961,t:1528143583864};\\\", \\\"{x:1385,y:961,t:1528143583881};\\\", \\\"{x:1388,y:958,t:1528143583897};\\\", \\\"{x:1393,y:955,t:1528143583914};\\\", \\\"{x:1397,y:949,t:1528143583930};\\\", \\\"{x:1399,y:945,t:1528143583946};\\\", \\\"{x:1401,y:940,t:1528143583964};\\\", \\\"{x:1403,y:934,t:1528143583980};\\\", \\\"{x:1404,y:931,t:1528143583997};\\\", \\\"{x:1408,y:927,t:1528143584014};\\\", \\\"{x:1414,y:921,t:1528143584030};\\\", \\\"{x:1418,y:913,t:1528143584047};\\\", \\\"{x:1427,y:901,t:1528143584064};\\\", \\\"{x:1440,y:884,t:1528143584081};\\\", \\\"{x:1444,y:876,t:1528143584096};\\\", \\\"{x:1448,y:871,t:1528143584114};\\\", \\\"{x:1451,y:867,t:1528143584131};\\\", \\\"{x:1453,y:864,t:1528143584147};\\\", \\\"{x:1456,y:860,t:1528143584164};\\\", \\\"{x:1458,y:857,t:1528143584181};\\\", \\\"{x:1460,y:851,t:1528143584197};\\\", \\\"{x:1462,y:844,t:1528143584214};\\\", \\\"{x:1464,y:836,t:1528143584230};\\\", \\\"{x:1467,y:831,t:1528143584246};\\\", \\\"{x:1470,y:827,t:1528143584264};\\\", \\\"{x:1474,y:822,t:1528143584280};\\\", \\\"{x:1477,y:818,t:1528143584296};\\\", \\\"{x:1478,y:815,t:1528143584313};\\\", \\\"{x:1479,y:813,t:1528143584330};\\\", \\\"{x:1481,y:810,t:1528143584346};\\\", \\\"{x:1483,y:808,t:1528143584364};\\\", \\\"{x:1483,y:807,t:1528143584381};\\\", \\\"{x:1484,y:807,t:1528143584396};\\\", \\\"{x:1484,y:809,t:1528143584440};\\\", \\\"{x:1484,y:819,t:1528143584449};\\\", \\\"{x:1484,y:826,t:1528143584465};\\\", \\\"{x:1484,y:835,t:1528143584481};\\\", \\\"{x:1484,y:836,t:1528143584498};\\\", \\\"{x:1484,y:837,t:1528143584514};\\\", \\\"{x:1483,y:838,t:1528143584531};\\\", \\\"{x:1482,y:839,t:1528143584548};\\\", \\\"{x:1482,y:838,t:1528143584689};\\\", \\\"{x:1482,y:837,t:1528143584698};\\\", \\\"{x:1482,y:836,t:1528143584713};\\\", \\\"{x:1482,y:835,t:1528143584761};\\\", \\\"{x:1484,y:835,t:1528143584782};\\\", \\\"{x:1487,y:835,t:1528143584798};\\\", \\\"{x:1490,y:836,t:1528143584814};\\\", \\\"{x:1495,y:840,t:1528143584831};\\\", \\\"{x:1499,y:845,t:1528143584848};\\\", \\\"{x:1502,y:851,t:1528143584864};\\\", \\\"{x:1506,y:857,t:1528143584881};\\\", \\\"{x:1509,y:861,t:1528143584898};\\\", \\\"{x:1510,y:864,t:1528143584914};\\\", \\\"{x:1512,y:867,t:1528143584931};\\\", \\\"{x:1514,y:870,t:1528143584948};\\\", \\\"{x:1516,y:872,t:1528143584965};\\\", \\\"{x:1517,y:874,t:1528143584980};\\\", \\\"{x:1519,y:878,t:1528143584998};\\\", \\\"{x:1522,y:882,t:1528143585015};\\\", \\\"{x:1524,y:889,t:1528143585031};\\\", \\\"{x:1526,y:894,t:1528143585048};\\\", \\\"{x:1529,y:904,t:1528143585065};\\\", \\\"{x:1531,y:909,t:1528143585081};\\\", \\\"{x:1534,y:916,t:1528143585098};\\\", \\\"{x:1537,y:923,t:1528143585115};\\\", \\\"{x:1539,y:928,t:1528143585131};\\\", \\\"{x:1541,y:932,t:1528143585148};\\\", \\\"{x:1545,y:937,t:1528143585165};\\\", \\\"{x:1550,y:938,t:1528143585181};\\\", \\\"{x:1552,y:939,t:1528143585197};\\\", \\\"{x:1553,y:939,t:1528143585215};\\\", \\\"{x:1555,y:939,t:1528143585231};\\\", \\\"{x:1559,y:941,t:1528143585248};\\\", \\\"{x:1570,y:944,t:1528143585264};\\\", \\\"{x:1573,y:945,t:1528143585281};\\\", \\\"{x:1576,y:946,t:1528143585298};\\\", \\\"{x:1582,y:946,t:1528143585315};\\\", \\\"{x:1588,y:946,t:1528143585331};\\\", \\\"{x:1592,y:946,t:1528143585348};\\\", \\\"{x:1593,y:946,t:1528143585365};\\\", \\\"{x:1594,y:946,t:1528143585382};\\\", \\\"{x:1593,y:946,t:1528143585512};\\\", \\\"{x:1590,y:946,t:1528143585520};\\\", \\\"{x:1587,y:946,t:1528143585532};\\\", \\\"{x:1582,y:946,t:1528143585548};\\\", \\\"{x:1578,y:946,t:1528143585564};\\\", \\\"{x:1573,y:946,t:1528143585582};\\\", \\\"{x:1567,y:946,t:1528143585598};\\\", \\\"{x:1563,y:946,t:1528143585614};\\\", \\\"{x:1560,y:946,t:1528143585631};\\\", \\\"{x:1559,y:946,t:1528143585647};\\\", \\\"{x:1556,y:944,t:1528143585665};\\\", \\\"{x:1553,y:940,t:1528143585681};\\\", \\\"{x:1548,y:931,t:1528143585698};\\\", \\\"{x:1543,y:919,t:1528143585714};\\\", \\\"{x:1537,y:903,t:1528143585731};\\\", \\\"{x:1527,y:889,t:1528143585748};\\\", \\\"{x:1516,y:873,t:1528143585764};\\\", \\\"{x:1508,y:863,t:1528143585782};\\\", \\\"{x:1504,y:855,t:1528143585798};\\\", \\\"{x:1502,y:850,t:1528143585815};\\\", \\\"{x:1501,y:845,t:1528143585832};\\\", \\\"{x:1500,y:834,t:1528143585848};\\\", \\\"{x:1500,y:821,t:1528143585865};\\\", \\\"{x:1500,y:814,t:1528143585882};\\\", \\\"{x:1500,y:809,t:1528143585898};\\\", \\\"{x:1500,y:806,t:1528143585915};\\\", \\\"{x:1500,y:803,t:1528143585932};\\\", \\\"{x:1501,y:794,t:1528143585949};\\\", \\\"{x:1501,y:789,t:1528143585969};\\\", \\\"{x:1502,y:783,t:1528143585981};\\\", \\\"{x:1503,y:780,t:1528143585998};\\\", \\\"{x:1504,y:777,t:1528143586014};\\\", \\\"{x:1505,y:776,t:1528143586032};\\\", \\\"{x:1506,y:772,t:1528143586047};\\\", \\\"{x:1506,y:770,t:1528143586064};\\\", \\\"{x:1506,y:768,t:1528143586081};\\\", \\\"{x:1507,y:767,t:1528143586098};\\\", \\\"{x:1507,y:766,t:1528143586161};\\\", \\\"{x:1507,y:765,t:1528143586192};\\\", \\\"{x:1505,y:764,t:1528143586201};\\\", \\\"{x:1504,y:764,t:1528143586216};\\\", \\\"{x:1503,y:763,t:1528143586232};\\\", \\\"{x:1499,y:763,t:1528143586249};\\\", \\\"{x:1490,y:769,t:1528143586266};\\\", \\\"{x:1474,y:781,t:1528143586282};\\\", \\\"{x:1463,y:786,t:1528143586298};\\\", \\\"{x:1446,y:789,t:1528143586315};\\\", \\\"{x:1423,y:789,t:1528143586331};\\\", \\\"{x:1393,y:789,t:1528143586348};\\\", \\\"{x:1340,y:789,t:1528143586366};\\\", \\\"{x:1255,y:783,t:1528143586381};\\\", \\\"{x:1179,y:770,t:1528143586399};\\\", \\\"{x:1117,y:758,t:1528143586415};\\\", \\\"{x:1056,y:741,t:1528143586431};\\\", \\\"{x:997,y:718,t:1528143586449};\\\", \\\"{x:973,y:701,t:1528143586465};\\\", \\\"{x:945,y:676,t:1528143586481};\\\", \\\"{x:904,y:641,t:1528143586499};\\\", \\\"{x:860,y:604,t:1528143586516};\\\", \\\"{x:820,y:571,t:1528143586531};\\\", \\\"{x:787,y:553,t:1528143586549};\\\", \\\"{x:748,y:541,t:1528143586582};\\\", \\\"{x:738,y:540,t:1528143586598};\\\", \\\"{x:725,y:540,t:1528143586615};\\\", \\\"{x:708,y:540,t:1528143586633};\\\", \\\"{x:693,y:540,t:1528143586649};\\\", \\\"{x:675,y:540,t:1528143586665};\\\", \\\"{x:660,y:540,t:1528143586683};\\\", \\\"{x:633,y:542,t:1528143586698};\\\", \\\"{x:603,y:548,t:1528143586715};\\\", \\\"{x:576,y:549,t:1528143586733};\\\", \\\"{x:546,y:553,t:1528143586748};\\\", \\\"{x:524,y:554,t:1528143586766};\\\", \\\"{x:508,y:555,t:1528143586782};\\\", \\\"{x:497,y:558,t:1528143586799};\\\", \\\"{x:490,y:559,t:1528143586815};\\\", \\\"{x:488,y:559,t:1528143586832};\\\", \\\"{x:486,y:561,t:1528143586849};\\\", \\\"{x:480,y:564,t:1528143586867};\\\", \\\"{x:468,y:571,t:1528143586882};\\\", \\\"{x:457,y:576,t:1528143586899};\\\", \\\"{x:448,y:578,t:1528143586916};\\\", \\\"{x:439,y:583,t:1528143586933};\\\", \\\"{x:434,y:586,t:1528143586949};\\\", \\\"{x:429,y:588,t:1528143586965};\\\", \\\"{x:425,y:593,t:1528143586983};\\\", \\\"{x:419,y:597,t:1528143587000};\\\", \\\"{x:414,y:601,t:1528143587017};\\\", \\\"{x:406,y:610,t:1528143587032};\\\", \\\"{x:405,y:614,t:1528143587049};\\\", \\\"{x:404,y:617,t:1528143587066};\\\", \\\"{x:404,y:619,t:1528143587083};\\\", \\\"{x:404,y:620,t:1528143587099};\\\", \\\"{x:404,y:623,t:1528143587115};\\\", \\\"{x:404,y:626,t:1528143587132};\\\", \\\"{x:404,y:628,t:1528143587150};\\\", \\\"{x:407,y:630,t:1528143587165};\\\", \\\"{x:410,y:631,t:1528143587182};\\\", \\\"{x:415,y:633,t:1528143587200};\\\", \\\"{x:418,y:633,t:1528143587217};\\\", \\\"{x:422,y:633,t:1528143587232};\\\", \\\"{x:426,y:633,t:1528143587250};\\\", \\\"{x:431,y:633,t:1528143587265};\\\", \\\"{x:432,y:633,t:1528143587282};\\\", \\\"{x:433,y:633,t:1528143587300};\\\", \\\"{x:434,y:633,t:1528143587320};\\\", \\\"{x:435,y:634,t:1528143587441};\\\", \\\"{x:435,y:636,t:1528143587450};\\\", \\\"{x:432,y:638,t:1528143587467};\\\", \\\"{x:428,y:640,t:1528143587483};\\\", \\\"{x:424,y:641,t:1528143587499};\\\", \\\"{x:417,y:642,t:1528143587516};\\\", \\\"{x:409,y:643,t:1528143587532};\\\", \\\"{x:404,y:644,t:1528143587549};\\\", \\\"{x:397,y:644,t:1528143587567};\\\", \\\"{x:389,y:644,t:1528143587583};\\\", \\\"{x:375,y:644,t:1528143587599};\\\", \\\"{x:362,y:643,t:1528143587615};\\\", \\\"{x:350,y:642,t:1528143587632};\\\", \\\"{x:335,y:642,t:1528143587650};\\\", \\\"{x:322,y:642,t:1528143587666};\\\", \\\"{x:306,y:642,t:1528143587683};\\\", \\\"{x:288,y:642,t:1528143587700};\\\", \\\"{x:262,y:642,t:1528143587717};\\\", \\\"{x:242,y:642,t:1528143587733};\\\", \\\"{x:233,y:642,t:1528143587750};\\\", \\\"{x:230,y:642,t:1528143587767};\\\", \\\"{x:229,y:642,t:1528143587783};\\\", \\\"{x:228,y:642,t:1528143587808};\\\", \\\"{x:228,y:641,t:1528143587816};\\\", \\\"{x:231,y:639,t:1528143587833};\\\", \\\"{x:246,y:638,t:1528143587850};\\\", \\\"{x:273,y:634,t:1528143587867};\\\", \\\"{x:327,y:626,t:1528143587884};\\\", \\\"{x:411,y:620,t:1528143587899};\\\", \\\"{x:500,y:618,t:1528143587917};\\\", \\\"{x:588,y:611,t:1528143587933};\\\", \\\"{x:683,y:597,t:1528143587949};\\\", \\\"{x:763,y:586,t:1528143587967};\\\", \\\"{x:801,y:582,t:1528143587984};\\\", \\\"{x:814,y:581,t:1528143587999};\\\", \\\"{x:824,y:581,t:1528143588017};\\\", \\\"{x:827,y:581,t:1528143588033};\\\", \\\"{x:830,y:581,t:1528143588050};\\\", \\\"{x:835,y:581,t:1528143588067};\\\", \\\"{x:845,y:581,t:1528143588084};\\\", \\\"{x:859,y:581,t:1528143588101};\\\", \\\"{x:874,y:581,t:1528143588117};\\\", \\\"{x:881,y:581,t:1528143588134};\\\", \\\"{x:884,y:581,t:1528143588149};\\\", \\\"{x:882,y:581,t:1528143588225};\\\", \\\"{x:880,y:581,t:1528143588234};\\\", \\\"{x:869,y:581,t:1528143588251};\\\", \\\"{x:853,y:581,t:1528143588267};\\\", \\\"{x:836,y:581,t:1528143588284};\\\", \\\"{x:828,y:581,t:1528143588301};\\\", \\\"{x:824,y:581,t:1528143588316};\\\", \\\"{x:823,y:581,t:1528143588334};\\\", \\\"{x:823,y:580,t:1528143588367};\\\", \\\"{x:822,y:580,t:1528143588648};\\\", \\\"{x:810,y:582,t:1528143588655};\\\", \\\"{x:793,y:583,t:1528143588667};\\\", \\\"{x:766,y:584,t:1528143588684};\\\", \\\"{x:742,y:586,t:1528143588700};\\\", \\\"{x:718,y:586,t:1528143588719};\\\", \\\"{x:699,y:586,t:1528143588733};\\\", \\\"{x:685,y:586,t:1528143588750};\\\", \\\"{x:675,y:586,t:1528143588767};\\\", \\\"{x:668,y:586,t:1528143588784};\\\", \\\"{x:661,y:586,t:1528143588800};\\\", \\\"{x:660,y:586,t:1528143588824};\\\", \\\"{x:657,y:586,t:1528143588841};\\\", \\\"{x:654,y:586,t:1528143588851};\\\", \\\"{x:647,y:586,t:1528143588868};\\\", \\\"{x:640,y:586,t:1528143588884};\\\", \\\"{x:633,y:586,t:1528143588901};\\\", \\\"{x:632,y:586,t:1528143588917};\\\", \\\"{x:630,y:586,t:1528143588933};\\\", \\\"{x:633,y:584,t:1528143589167};\\\", \\\"{x:657,y:582,t:1528143589184};\\\", \\\"{x:682,y:579,t:1528143589200};\\\", \\\"{x:712,y:579,t:1528143589217};\\\", \\\"{x:739,y:579,t:1528143589235};\\\", \\\"{x:758,y:579,t:1528143589250};\\\", \\\"{x:768,y:579,t:1528143589267};\\\", \\\"{x:774,y:579,t:1528143589284};\\\", \\\"{x:776,y:579,t:1528143589300};\\\", \\\"{x:777,y:579,t:1528143589344};\\\", \\\"{x:778,y:578,t:1528143589424};\\\", \\\"{x:781,y:577,t:1528143589440};\\\", \\\"{x:788,y:577,t:1528143589451};\\\", \\\"{x:805,y:573,t:1528143589468};\\\", \\\"{x:836,y:569,t:1528143589485};\\\", \\\"{x:873,y:567,t:1528143589502};\\\", \\\"{x:895,y:567,t:1528143589517};\\\", \\\"{x:898,y:567,t:1528143589534};\\\", \\\"{x:899,y:567,t:1528143589552};\\\", \\\"{x:900,y:567,t:1528143589584};\\\", \\\"{x:898,y:569,t:1528143589601};\\\", \\\"{x:893,y:571,t:1528143589618};\\\", \\\"{x:884,y:571,t:1528143589635};\\\", \\\"{x:876,y:573,t:1528143589652};\\\", \\\"{x:875,y:573,t:1528143589667};\\\", \\\"{x:874,y:573,t:1528143589685};\\\", \\\"{x:873,y:573,t:1528143589704};\\\", \\\"{x:872,y:573,t:1528143589760};\\\", \\\"{x:871,y:573,t:1528143589776};\\\", \\\"{x:870,y:573,t:1528143589873};\\\", \\\"{x:869,y:573,t:1528143589897};\\\", \\\"{x:866,y:573,t:1528143589919};\\\", \\\"{x:864,y:573,t:1528143589959};\\\", \\\"{x:862,y:572,t:1528143589983};\\\", \\\"{x:861,y:571,t:1528143590000};\\\", \\\"{x:860,y:571,t:1528143590007};\\\", \\\"{x:859,y:570,t:1528143590056};\\\", \\\"{x:857,y:570,t:1528143590825};\\\", \\\"{x:856,y:572,t:1528143590836};\\\", \\\"{x:856,y:576,t:1528143590852};\\\", \\\"{x:856,y:579,t:1528143590869};\\\", \\\"{x:856,y:583,t:1528143590886};\\\", \\\"{x:856,y:586,t:1528143590902};\\\", \\\"{x:856,y:587,t:1528143590919};\\\", \\\"{x:856,y:589,t:1528143590937};\\\", \\\"{x:856,y:591,t:1528143590952};\\\", \\\"{x:856,y:592,t:1528143590969};\\\", \\\"{x:856,y:593,t:1528143590986};\\\", \\\"{x:856,y:594,t:1528143591026};\\\", \\\"{x:856,y:595,t:1528143591036};\\\", \\\"{x:855,y:596,t:1528143591064};\\\", \\\"{x:854,y:598,t:1528143591073};\\\", \\\"{x:853,y:599,t:1528143591088};\\\", \\\"{x:853,y:600,t:1528143591103};\\\", \\\"{x:851,y:600,t:1528143591177};\\\", \\\"{x:852,y:598,t:1528143591240};\\\", \\\"{x:853,y:596,t:1528143591253};\\\", \\\"{x:856,y:591,t:1528143591270};\\\", \\\"{x:857,y:588,t:1528143591287};\\\", \\\"{x:858,y:587,t:1528143591302};\\\", \\\"{x:858,y:585,t:1528143591319};\\\", \\\"{x:859,y:575,t:1528143591335};\\\", \\\"{x:859,y:571,t:1528143591352};\\\", \\\"{x:859,y:566,t:1528143591370};\\\", \\\"{x:859,y:565,t:1528143591386};\\\", \\\"{x:858,y:565,t:1528143591403};\\\", \\\"{x:855,y:565,t:1528143591420};\\\", \\\"{x:846,y:570,t:1528143591435};\\\", \\\"{x:840,y:575,t:1528143591452};\\\", \\\"{x:832,y:581,t:1528143591469};\\\", \\\"{x:826,y:588,t:1528143591486};\\\", \\\"{x:816,y:601,t:1528143591504};\\\", \\\"{x:797,y:624,t:1528143591519};\\\", \\\"{x:791,y:631,t:1528143591535};\\\", \\\"{x:786,y:635,t:1528143591554};\\\", \\\"{x:785,y:639,t:1528143591570};\\\", \\\"{x:781,y:642,t:1528143591672};\\\", \\\"{x:781,y:647,t:1528143591686};\\\", \\\"{x:781,y:662,t:1528143591703};\\\", \\\"{x:775,y:676,t:1528143591721};\\\", \\\"{x:769,y:682,t:1528143591736};\\\", \\\"{x:763,y:687,t:1528143591753};\\\", \\\"{x:759,y:691,t:1528143591770};\\\", \\\"{x:753,y:698,t:1528143591786};\\\", \\\"{x:747,y:705,t:1528143591803};\\\", \\\"{x:739,y:713,t:1528143591820};\\\", \\\"{x:731,y:722,t:1528143591836};\\\", \\\"{x:720,y:735,t:1528143591853};\\\", \\\"{x:701,y:749,t:1528143591870};\\\", \\\"{x:694,y:756,t:1528143591887};\\\", \\\"{x:694,y:757,t:1528143592665};\\\", \\\"{x:693,y:760,t:1528143593833};\\\", \\\"{x:692,y:760,t:1528143593840};\\\", \\\"{x:692,y:761,t:1528143593993};\\\", \\\"{x:687,y:765,t:1528143594004};\\\", \\\"{x:666,y:783,t:1528143594021};\\\", \\\"{x:646,y:798,t:1528143594038};\\\", \\\"{x:631,y:805,t:1528143594054};\\\", \\\"{x:603,y:813,t:1528143594072};\\\", \\\"{x:558,y:823,t:1528143594088};\\\", \\\"{x:514,y:830,t:1528143594104};\\\", \\\"{x:469,y:836,t:1528143594120};\\\", \\\"{x:438,y:836,t:1528143594138};\\\", \\\"{x:410,y:836,t:1528143594154};\\\", \\\"{x:395,y:836,t:1528143594172};\\\", \\\"{x:391,y:835,t:1528143594188};\\\", \\\"{x:390,y:835,t:1528143594204};\\\", \\\"{x:390,y:831,t:1528143594221};\\\", \\\"{x:390,y:823,t:1528143594238};\\\", \\\"{x:398,y:806,t:1528143594254};\\\", \\\"{x:408,y:789,t:1528143594271};\\\", \\\"{x:426,y:767,t:1528143594289};\\\", \\\"{x:432,y:758,t:1528143594305};\\\", \\\"{x:434,y:755,t:1528143594322};\\\", \\\"{x:435,y:754,t:1528143594345};\\\", \\\"{x:435,y:753,t:1528143594368};\\\", \\\"{x:437,y:752,t:1528143594376};\\\", \\\"{x:438,y:751,t:1528143594393};\\\", \\\"{x:440,y:750,t:1528143594416};\\\", \\\"{x:442,y:749,t:1528143594440};\\\", \\\"{x:443,y:749,t:1528143594456};\\\", \\\"{x:443,y:748,t:1528143594471};\\\", \\\"{x:447,y:748,t:1528143594489};\\\", \\\"{x:450,y:746,t:1528143594505};\\\", \\\"{x:454,y:744,t:1528143594520};\\\", \\\"{x:457,y:743,t:1528143594537};\\\", \\\"{x:458,y:743,t:1528143594555};\\\", \\\"{x:458,y:742,t:1528143594572};\\\", \\\"{x:459,y:742,t:1528143595496};\\\" ] }, { \\\"rt\\\": 40197, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 12, \\\"time_elapsed\\\": 723803, \\\"internal_node_id\\\": \\\"0.0-6.0-2.0\\\", \\\"subject\\\": \\\"K0CNH\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+contained\\\", \\\"q\\\": 8, \\\"clicks\\\": 2.5, \\\"explicit\\\": 2, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"F\\\", \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-M -O -G -01 PM-02 PM-03 PM-04 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:460,y:740,t:1528143598465};\\\", \\\"{x:462,y:720,t:1528143598472};\\\", \\\"{x:460,y:692,t:1528143598492};\\\", \\\"{x:456,y:671,t:1528143598504};\\\", \\\"{x:456,y:649,t:1528143598522};\\\", \\\"{x:456,y:621,t:1528143598542};\\\", \\\"{x:459,y:599,t:1528143598559};\\\", \\\"{x:462,y:582,t:1528143598575};\\\", \\\"{x:463,y:561,t:1528143598591};\\\", \\\"{x:465,y:546,t:1528143598608};\\\", \\\"{x:467,y:537,t:1528143598625};\\\", \\\"{x:467,y:532,t:1528143598641};\\\", \\\"{x:467,y:530,t:1528143598659};\\\", \\\"{x:466,y:528,t:1528143598680};\\\", \\\"{x:462,y:527,t:1528143598692};\\\", \\\"{x:449,y:521,t:1528143598709};\\\", \\\"{x:431,y:516,t:1528143598726};\\\", \\\"{x:397,y:506,t:1528143598742};\\\", \\\"{x:356,y:494,t:1528143598759};\\\", \\\"{x:307,y:483,t:1528143598775};\\\", \\\"{x:258,y:468,t:1528143598792};\\\", \\\"{x:232,y:460,t:1528143598809};\\\", \\\"{x:209,y:451,t:1528143598826};\\\", \\\"{x:187,y:442,t:1528143598842};\\\", \\\"{x:169,y:434,t:1528143598859};\\\", \\\"{x:155,y:428,t:1528143598876};\\\", \\\"{x:147,y:425,t:1528143598892};\\\", \\\"{x:140,y:423,t:1528143598909};\\\", \\\"{x:138,y:422,t:1528143598926};\\\", \\\"{x:136,y:421,t:1528143598943};\\\", \\\"{x:136,y:420,t:1528143599096};\\\", \\\"{x:136,y:418,t:1528143599110};\\\", \\\"{x:139,y:414,t:1528143599127};\\\", \\\"{x:146,y:409,t:1528143599143};\\\", \\\"{x:160,y:402,t:1528143599160};\\\", \\\"{x:170,y:395,t:1528143599177};\\\", \\\"{x:174,y:393,t:1528143599194};\\\", \\\"{x:178,y:390,t:1528143599210};\\\", \\\"{x:183,y:387,t:1528143599227};\\\", \\\"{x:188,y:384,t:1528143599244};\\\", \\\"{x:194,y:382,t:1528143599261};\\\", \\\"{x:201,y:375,t:1528143599277};\\\", \\\"{x:206,y:374,t:1528143599295};\\\", \\\"{x:215,y:370,t:1528143599312};\\\", \\\"{x:228,y:368,t:1528143599328};\\\", \\\"{x:242,y:366,t:1528143599344};\\\", \\\"{x:254,y:365,t:1528143599361};\\\", \\\"{x:267,y:365,t:1528143599378};\\\", \\\"{x:277,y:365,t:1528143599394};\\\", \\\"{x:286,y:365,t:1528143599411};\\\", \\\"{x:293,y:365,t:1528143599428};\\\", \\\"{x:297,y:365,t:1528143599446};\\\", \\\"{x:304,y:367,t:1528143599461};\\\", \\\"{x:307,y:367,t:1528143599478};\\\", \\\"{x:311,y:369,t:1528143599496};\\\", \\\"{x:315,y:371,t:1528143599512};\\\", \\\"{x:319,y:374,t:1528143599528};\\\", \\\"{x:322,y:375,t:1528143599545};\\\", \\\"{x:324,y:377,t:1528143599562};\\\", \\\"{x:325,y:378,t:1528143599579};\\\", \\\"{x:327,y:380,t:1528143599595};\\\", \\\"{x:329,y:382,t:1528143599613};\\\", \\\"{x:330,y:383,t:1528143599630};\\\", \\\"{x:330,y:386,t:1528143599646};\\\", \\\"{x:332,y:387,t:1528143599662};\\\", \\\"{x:334,y:387,t:1528143599864};\\\", \\\"{x:335,y:389,t:1528143599880};\\\", \\\"{x:337,y:389,t:1528143599896};\\\", \\\"{x:338,y:390,t:1528143599913};\\\", \\\"{x:339,y:390,t:1528143599931};\\\", \\\"{x:340,y:390,t:1528143599961};\\\", \\\"{x:340,y:391,t:1528143600041};\\\", \\\"{x:341,y:392,t:1528143600048};\\\", \\\"{x:342,y:392,t:1528143600081};\\\", \\\"{x:342,y:393,t:1528143600098};\\\", \\\"{x:342,y:394,t:1528143600114};\\\", \\\"{x:342,y:395,t:1528143600131};\\\", \\\"{x:342,y:397,t:1528143600148};\\\", \\\"{x:344,y:399,t:1528143600164};\\\", \\\"{x:344,y:401,t:1528143600181};\\\", \\\"{x:344,y:402,t:1528143600200};\\\", \\\"{x:344,y:404,t:1528143600232};\\\", \\\"{x:345,y:404,t:1528143600248};\\\", \\\"{x:345,y:405,t:1528143600312};\\\", \\\"{x:345,y:408,t:1528143600464};\\\", \\\"{x:345,y:409,t:1528143600472};\\\", \\\"{x:345,y:411,t:1528143600482};\\\", \\\"{x:347,y:415,t:1528143600500};\\\", \\\"{x:349,y:420,t:1528143600516};\\\", \\\"{x:350,y:424,t:1528143600532};\\\", \\\"{x:352,y:427,t:1528143600549};\\\", \\\"{x:352,y:429,t:1528143600566};\\\", \\\"{x:353,y:430,t:1528143600592};\\\", \\\"{x:355,y:430,t:1528143600721};\\\", \\\"{x:356,y:430,t:1528143600733};\\\", \\\"{x:357,y:430,t:1528143600750};\\\", \\\"{x:358,y:430,t:1528143600768};\\\", \\\"{x:359,y:430,t:1528143600784};\\\", \\\"{x:361,y:430,t:1528143600800};\\\", \\\"{x:363,y:430,t:1528143600817};\\\", \\\"{x:369,y:430,t:1528143600835};\\\", \\\"{x:377,y:430,t:1528143600851};\\\", \\\"{x:384,y:430,t:1528143600867};\\\", \\\"{x:391,y:430,t:1528143600884};\\\", \\\"{x:399,y:430,t:1528143600900};\\\", \\\"{x:402,y:430,t:1528143600917};\\\", \\\"{x:406,y:430,t:1528143600933};\\\", \\\"{x:408,y:430,t:1528143600951};\\\", \\\"{x:413,y:430,t:1528143600967};\\\", \\\"{x:416,y:430,t:1528143600984};\\\", \\\"{x:417,y:430,t:1528143601001};\\\", \\\"{x:419,y:430,t:1528143601018};\\\", \\\"{x:420,y:430,t:1528143601035};\\\", \\\"{x:423,y:430,t:1528143601051};\\\", \\\"{x:427,y:431,t:1528143601068};\\\", \\\"{x:428,y:432,t:1528143601217};\\\", \\\"{x:428,y:435,t:1528143601224};\\\", \\\"{x:428,y:436,t:1528143601235};\\\", \\\"{x:430,y:441,t:1528143601252};\\\", \\\"{x:431,y:446,t:1528143601270};\\\", \\\"{x:432,y:450,t:1528143601286};\\\", \\\"{x:434,y:452,t:1528143601303};\\\", \\\"{x:434,y:455,t:1528143601320};\\\", \\\"{x:435,y:456,t:1528143601336};\\\", \\\"{x:435,y:457,t:1528143601352};\\\", \\\"{x:435,y:458,t:1528143601384};\\\", \\\"{x:435,y:459,t:1528143601457};\\\", \\\"{x:435,y:460,t:1528143601470};\\\", \\\"{x:435,y:461,t:1528143601487};\\\", \\\"{x:433,y:462,t:1528143601503};\\\", \\\"{x:433,y:464,t:1528143601520};\\\", \\\"{x:433,y:466,t:1528143601537};\\\", \\\"{x:432,y:467,t:1528143601560};\\\", \\\"{x:433,y:467,t:1528143601769};\\\", \\\"{x:434,y:467,t:1528143601784};\\\", \\\"{x:435,y:467,t:1528143601808};\\\", \\\"{x:436,y:467,t:1528143601821};\\\", \\\"{x:437,y:467,t:1528143601856};\\\", \\\"{x:439,y:466,t:1528143601953};\\\", \\\"{x:441,y:466,t:1528143601967};\\\", \\\"{x:442,y:466,t:1528143601976};\\\", \\\"{x:443,y:466,t:1528143601988};\\\", \\\"{x:446,y:467,t:1528143602005};\\\", \\\"{x:449,y:467,t:1528143602022};\\\", \\\"{x:450,y:468,t:1528143602039};\\\", \\\"{x:452,y:468,t:1528143602104};\\\", \\\"{x:452,y:469,t:1528143602673};\\\", \\\"{x:452,y:470,t:1528143602696};\\\", \\\"{x:452,y:472,t:1528143602720};\\\", \\\"{x:452,y:473,t:1528143602744};\\\", \\\"{x:453,y:473,t:1528143602888};\\\", \\\"{x:455,y:473,t:1528143602904};\\\", \\\"{x:457,y:473,t:1528143602920};\\\", \\\"{x:459,y:473,t:1528143602928};\\\", \\\"{x:460,y:473,t:1528143602943};\\\", \\\"{x:468,y:473,t:1528143602960};\\\", \\\"{x:500,y:473,t:1528143602976};\\\", \\\"{x:531,y:473,t:1528143602994};\\\", \\\"{x:578,y:478,t:1528143603009};\\\", \\\"{x:636,y:486,t:1528143603026};\\\", \\\"{x:704,y:500,t:1528143603045};\\\", \\\"{x:772,y:521,t:1528143603061};\\\", \\\"{x:883,y:559,t:1528143603076};\\\", \\\"{x:999,y:609,t:1528143603096};\\\", \\\"{x:1186,y:680,t:1528143603112};\\\", \\\"{x:1305,y:713,t:1528143603129};\\\", \\\"{x:1421,y:746,t:1528143603145};\\\", \\\"{x:1525,y:766,t:1528143603162};\\\", \\\"{x:1606,y:793,t:1528143603179};\\\", \\\"{x:1670,y:812,t:1528143603196};\\\", \\\"{x:1711,y:826,t:1528143603212};\\\", \\\"{x:1735,y:837,t:1528143603229};\\\", \\\"{x:1750,y:847,t:1528143603246};\\\", \\\"{x:1755,y:851,t:1528143603262};\\\", \\\"{x:1757,y:852,t:1528143603280};\\\", \\\"{x:1756,y:855,t:1528143603296};\\\", \\\"{x:1748,y:862,t:1528143603313};\\\", \\\"{x:1729,y:869,t:1528143603330};\\\", \\\"{x:1697,y:875,t:1528143603347};\\\", \\\"{x:1652,y:881,t:1528143603364};\\\", \\\"{x:1614,y:885,t:1528143603380};\\\", \\\"{x:1577,y:890,t:1528143603396};\\\", \\\"{x:1545,y:892,t:1528143603413};\\\", \\\"{x:1516,y:892,t:1528143603430};\\\", \\\"{x:1487,y:892,t:1528143603447};\\\", \\\"{x:1464,y:892,t:1528143603463};\\\", \\\"{x:1441,y:892,t:1528143603480};\\\", \\\"{x:1431,y:890,t:1528143603497};\\\", \\\"{x:1427,y:889,t:1528143603514};\\\", \\\"{x:1425,y:889,t:1528143603531};\\\", \\\"{x:1422,y:889,t:1528143603547};\\\", \\\"{x:1418,y:889,t:1528143603563};\\\", \\\"{x:1411,y:889,t:1528143603581};\\\", \\\"{x:1403,y:889,t:1528143603597};\\\", \\\"{x:1393,y:889,t:1528143603613};\\\", \\\"{x:1383,y:889,t:1528143603630};\\\", \\\"{x:1372,y:889,t:1528143603648};\\\", \\\"{x:1364,y:889,t:1528143603664};\\\", \\\"{x:1350,y:889,t:1528143603680};\\\", \\\"{x:1338,y:888,t:1528143603698};\\\", \\\"{x:1332,y:886,t:1528143603714};\\\", \\\"{x:1330,y:885,t:1528143603730};\\\", \\\"{x:1328,y:885,t:1528143603748};\\\", \\\"{x:1326,y:885,t:1528143603764};\\\", \\\"{x:1324,y:884,t:1528143603780};\\\", \\\"{x:1322,y:884,t:1528143603799};\\\", \\\"{x:1321,y:884,t:1528143603823};\\\", \\\"{x:1319,y:884,t:1528143603840};\\\", \\\"{x:1317,y:885,t:1528143603855};\\\", \\\"{x:1317,y:886,t:1528143603872};\\\", \\\"{x:1316,y:887,t:1528143603881};\\\", \\\"{x:1315,y:887,t:1528143603927};\\\", \\\"{x:1314,y:888,t:1528143603935};\\\", \\\"{x:1313,y:889,t:1528143603952};\\\", \\\"{x:1312,y:889,t:1528143603964};\\\", \\\"{x:1308,y:891,t:1528143603981};\\\", \\\"{x:1306,y:892,t:1528143603997};\\\", \\\"{x:1302,y:893,t:1528143604014};\\\", \\\"{x:1299,y:896,t:1528143604031};\\\", \\\"{x:1294,y:898,t:1528143604048};\\\", \\\"{x:1291,y:900,t:1528143604064};\\\", \\\"{x:1288,y:902,t:1528143604082};\\\", \\\"{x:1285,y:904,t:1528143604099};\\\", \\\"{x:1283,y:906,t:1528143604115};\\\", \\\"{x:1282,y:907,t:1528143604132};\\\", \\\"{x:1281,y:907,t:1528143604149};\\\", \\\"{x:1279,y:909,t:1528143604164};\\\", \\\"{x:1277,y:911,t:1528143604182};\\\", \\\"{x:1276,y:913,t:1528143604199};\\\", \\\"{x:1274,y:916,t:1528143604216};\\\", \\\"{x:1273,y:917,t:1528143604232};\\\", \\\"{x:1270,y:920,t:1528143604248};\\\", \\\"{x:1269,y:922,t:1528143604266};\\\", \\\"{x:1266,y:923,t:1528143604282};\\\", \\\"{x:1263,y:926,t:1528143604299};\\\", \\\"{x:1262,y:927,t:1528143604315};\\\", \\\"{x:1260,y:928,t:1528143604333};\\\", \\\"{x:1259,y:929,t:1528143604349};\\\", \\\"{x:1258,y:929,t:1528143604368};\\\", \\\"{x:1255,y:930,t:1528143604409};\\\", \\\"{x:1254,y:931,t:1528143604424};\\\", \\\"{x:1254,y:932,t:1528143604440};\\\", \\\"{x:1253,y:932,t:1528143604457};\\\", \\\"{x:1251,y:932,t:1528143604807};\\\", \\\"{x:1251,y:933,t:1528143605055};\\\", \\\"{x:1249,y:934,t:1528143605143};\\\", \\\"{x:1248,y:934,t:1528143605841};\\\", \\\"{x:1248,y:933,t:1528143605896};\\\", \\\"{x:1248,y:932,t:1528143605904};\\\", \\\"{x:1248,y:930,t:1528143605919};\\\", \\\"{x:1251,y:929,t:1528143605935};\\\", \\\"{x:1263,y:927,t:1528143605953};\\\", \\\"{x:1271,y:925,t:1528143605969};\\\", \\\"{x:1277,y:924,t:1528143605985};\\\", \\\"{x:1287,y:923,t:1528143606002};\\\", \\\"{x:1292,y:921,t:1528143606019};\\\", \\\"{x:1294,y:919,t:1528143606036};\\\", \\\"{x:1297,y:917,t:1528143606052};\\\", \\\"{x:1298,y:916,t:1528143606069};\\\", \\\"{x:1300,y:915,t:1528143606086};\\\", \\\"{x:1300,y:914,t:1528143606102};\\\", \\\"{x:1302,y:910,t:1528143606119};\\\", \\\"{x:1302,y:908,t:1528143606135};\\\", \\\"{x:1302,y:903,t:1528143606153};\\\", \\\"{x:1304,y:899,t:1528143606169};\\\", \\\"{x:1308,y:891,t:1528143606186};\\\", \\\"{x:1310,y:887,t:1528143606203};\\\", \\\"{x:1313,y:882,t:1528143606219};\\\", \\\"{x:1319,y:875,t:1528143606236};\\\", \\\"{x:1322,y:870,t:1528143606253};\\\", \\\"{x:1324,y:866,t:1528143606270};\\\", \\\"{x:1328,y:863,t:1528143606286};\\\", \\\"{x:1332,y:859,t:1528143606303};\\\", \\\"{x:1341,y:854,t:1528143606320};\\\", \\\"{x:1349,y:849,t:1528143606337};\\\", \\\"{x:1357,y:843,t:1528143606354};\\\", \\\"{x:1365,y:838,t:1528143606371};\\\", \\\"{x:1370,y:837,t:1528143606387};\\\", \\\"{x:1375,y:837,t:1528143606404};\\\", \\\"{x:1381,y:834,t:1528143606421};\\\", \\\"{x:1387,y:832,t:1528143606437};\\\", \\\"{x:1395,y:828,t:1528143606454};\\\", \\\"{x:1401,y:828,t:1528143606470};\\\", \\\"{x:1412,y:828,t:1528143606488};\\\", \\\"{x:1421,y:828,t:1528143606504};\\\", \\\"{x:1426,y:828,t:1528143606521};\\\", \\\"{x:1432,y:829,t:1528143606538};\\\", \\\"{x:1441,y:831,t:1528143606554};\\\", \\\"{x:1451,y:834,t:1528143606570};\\\", \\\"{x:1459,y:836,t:1528143606588};\\\", \\\"{x:1465,y:836,t:1528143606605};\\\", \\\"{x:1468,y:837,t:1528143606621};\\\", \\\"{x:1469,y:837,t:1528143606638};\\\", \\\"{x:1470,y:838,t:1528143606656};\\\", \\\"{x:1471,y:838,t:1528143606672};\\\", \\\"{x:1477,y:840,t:1528143606688};\\\", \\\"{x:1483,y:842,t:1528143606704};\\\", \\\"{x:1488,y:842,t:1528143606722};\\\", \\\"{x:1493,y:843,t:1528143606738};\\\", \\\"{x:1498,y:843,t:1528143606755};\\\", \\\"{x:1506,y:846,t:1528143606771};\\\", \\\"{x:1512,y:846,t:1528143606788};\\\", \\\"{x:1522,y:847,t:1528143606805};\\\", \\\"{x:1528,y:848,t:1528143606822};\\\", \\\"{x:1531,y:848,t:1528143606839};\\\", \\\"{x:1531,y:849,t:1528143606855};\\\", \\\"{x:1532,y:849,t:1528143606872};\\\", \\\"{x:1533,y:849,t:1528143606937};\\\", \\\"{x:1533,y:850,t:1528143606945};\\\", \\\"{x:1534,y:850,t:1528143606955};\\\", \\\"{x:1537,y:851,t:1528143606972};\\\", \\\"{x:1539,y:851,t:1528143606989};\\\", \\\"{x:1541,y:851,t:1528143607006};\\\", \\\"{x:1542,y:851,t:1528143607022};\\\", \\\"{x:1543,y:852,t:1528143607040};\\\", \\\"{x:1547,y:854,t:1528143607056};\\\", \\\"{x:1550,y:857,t:1528143607072};\\\", \\\"{x:1551,y:857,t:1528143607089};\\\", \\\"{x:1554,y:857,t:1528143607106};\\\", \\\"{x:1556,y:858,t:1528143607123};\\\", \\\"{x:1558,y:860,t:1528143607139};\\\", \\\"{x:1559,y:860,t:1528143607156};\\\", \\\"{x:1560,y:860,t:1528143607172};\\\", \\\"{x:1561,y:860,t:1528143607188};\\\", \\\"{x:1563,y:860,t:1528143607205};\\\", \\\"{x:1564,y:860,t:1528143607222};\\\", \\\"{x:1565,y:860,t:1528143607240};\\\", \\\"{x:1566,y:860,t:1528143607255};\\\", \\\"{x:1567,y:860,t:1528143607272};\\\", \\\"{x:1568,y:860,t:1528143607296};\\\", \\\"{x:1568,y:859,t:1528143607344};\\\", \\\"{x:1568,y:857,t:1528143607355};\\\", \\\"{x:1568,y:856,t:1528143607372};\\\", \\\"{x:1567,y:853,t:1528143607390};\\\", \\\"{x:1566,y:850,t:1528143607407};\\\", \\\"{x:1564,y:846,t:1528143607423};\\\", \\\"{x:1563,y:843,t:1528143607440};\\\", \\\"{x:1560,y:839,t:1528143607457};\\\", \\\"{x:1559,y:836,t:1528143607473};\\\", \\\"{x:1556,y:833,t:1528143607490};\\\", \\\"{x:1552,y:828,t:1528143607507};\\\", \\\"{x:1549,y:824,t:1528143607523};\\\", \\\"{x:1547,y:821,t:1528143607540};\\\", \\\"{x:1545,y:818,t:1528143607557};\\\", \\\"{x:1544,y:815,t:1528143607574};\\\", \\\"{x:1542,y:812,t:1528143607590};\\\", \\\"{x:1539,y:807,t:1528143607607};\\\", \\\"{x:1533,y:797,t:1528143607625};\\\", \\\"{x:1529,y:790,t:1528143607640};\\\", \\\"{x:1522,y:780,t:1528143607657};\\\", \\\"{x:1517,y:774,t:1528143607674};\\\", \\\"{x:1514,y:771,t:1528143607691};\\\", \\\"{x:1513,y:769,t:1528143607707};\\\", \\\"{x:1511,y:767,t:1528143607726};\\\", \\\"{x:1510,y:765,t:1528143607757};\\\", \\\"{x:1509,y:764,t:1528143607773};\\\", \\\"{x:1506,y:761,t:1528143607791};\\\", \\\"{x:1506,y:760,t:1528143607977};\\\", \\\"{x:1505,y:759,t:1528143607991};\\\", \\\"{x:1505,y:756,t:1528143608008};\\\", \\\"{x:1503,y:752,t:1528143608024};\\\", \\\"{x:1503,y:749,t:1528143608041};\\\", \\\"{x:1502,y:748,t:1528143608057};\\\", \\\"{x:1502,y:746,t:1528143608074};\\\", \\\"{x:1501,y:745,t:1528143608112};\\\", \\\"{x:1501,y:743,t:1528143608529};\\\", \\\"{x:1501,y:742,t:1528143608543};\\\", \\\"{x:1501,y:739,t:1528143608559};\\\", \\\"{x:1501,y:735,t:1528143608576};\\\", \\\"{x:1501,y:733,t:1528143608593};\\\", \\\"{x:1501,y:732,t:1528143609233};\\\", \\\"{x:1501,y:730,t:1528143609249};\\\", \\\"{x:1501,y:729,t:1528143609288};\\\", \\\"{x:1501,y:727,t:1528143609376};\\\", \\\"{x:1500,y:725,t:1528143609395};\\\", \\\"{x:1500,y:724,t:1528143609465};\\\", \\\"{x:1499,y:723,t:1528143609478};\\\", \\\"{x:1499,y:720,t:1528143609495};\\\", \\\"{x:1498,y:719,t:1528143609511};\\\", \\\"{x:1498,y:717,t:1528143609528};\\\", \\\"{x:1498,y:716,t:1528143609544};\\\", \\\"{x:1496,y:713,t:1528143609562};\\\", \\\"{x:1495,y:712,t:1528143609592};\\\", \\\"{x:1494,y:711,t:1528143609601};\\\", \\\"{x:1494,y:709,t:1528143609616};\\\", \\\"{x:1493,y:708,t:1528143609628};\\\", \\\"{x:1492,y:706,t:1528143609645};\\\", \\\"{x:1489,y:702,t:1528143609662};\\\", \\\"{x:1489,y:700,t:1528143609679};\\\", \\\"{x:1488,y:697,t:1528143609695};\\\", \\\"{x:1486,y:695,t:1528143609712};\\\", \\\"{x:1485,y:693,t:1528143609728};\\\", \\\"{x:1484,y:691,t:1528143609753};\\\", \\\"{x:1483,y:691,t:1528143609768};\\\", \\\"{x:1482,y:690,t:1528143609779};\\\", \\\"{x:1481,y:689,t:1528143609796};\\\", \\\"{x:1480,y:688,t:1528143609812};\\\", \\\"{x:1479,y:687,t:1528143609829};\\\", \\\"{x:1477,y:684,t:1528143609846};\\\", \\\"{x:1475,y:682,t:1528143609862};\\\", \\\"{x:1474,y:681,t:1528143609879};\\\", \\\"{x:1473,y:679,t:1528143609895};\\\", \\\"{x:1472,y:678,t:1528143609912};\\\", \\\"{x:1471,y:676,t:1528143609935};\\\", \\\"{x:1470,y:676,t:1528143609951};\\\", \\\"{x:1469,y:675,t:1528143609962};\\\", \\\"{x:1468,y:675,t:1528143609991};\\\", \\\"{x:1467,y:674,t:1528143609999};\\\", \\\"{x:1466,y:673,t:1528143610016};\\\", \\\"{x:1465,y:671,t:1528143610032};\\\", \\\"{x:1464,y:670,t:1528143610045};\\\", \\\"{x:1461,y:667,t:1528143610062};\\\", \\\"{x:1458,y:664,t:1528143610079};\\\", \\\"{x:1455,y:661,t:1528143610095};\\\", \\\"{x:1453,y:659,t:1528143610113};\\\", \\\"{x:1452,y:658,t:1528143610129};\\\", \\\"{x:1450,y:657,t:1528143610145};\\\", \\\"{x:1450,y:656,t:1528143610163};\\\", \\\"{x:1447,y:654,t:1528143610179};\\\", \\\"{x:1443,y:650,t:1528143610197};\\\", \\\"{x:1442,y:648,t:1528143610213};\\\", \\\"{x:1440,y:646,t:1528143610230};\\\", \\\"{x:1440,y:645,t:1528143610246};\\\", \\\"{x:1438,y:644,t:1528143610263};\\\", \\\"{x:1436,y:643,t:1528143610280};\\\", \\\"{x:1436,y:640,t:1528143610296};\\\", \\\"{x:1434,y:637,t:1528143610312};\\\", \\\"{x:1430,y:633,t:1528143610329};\\\", \\\"{x:1429,y:631,t:1528143610346};\\\", \\\"{x:1429,y:630,t:1528143610364};\\\", \\\"{x:1428,y:630,t:1528143610400};\\\", \\\"{x:1427,y:630,t:1528143610600};\\\", \\\"{x:1423,y:632,t:1528143610614};\\\", \\\"{x:1418,y:637,t:1528143610631};\\\", \\\"{x:1406,y:644,t:1528143610648};\\\", \\\"{x:1402,y:645,t:1528143610664};\\\", \\\"{x:1398,y:647,t:1528143610681};\\\", \\\"{x:1396,y:649,t:1528143610698};\\\", \\\"{x:1393,y:651,t:1528143610714};\\\", \\\"{x:1388,y:655,t:1528143610731};\\\", \\\"{x:1386,y:657,t:1528143610748};\\\", \\\"{x:1384,y:659,t:1528143610764};\\\", \\\"{x:1380,y:661,t:1528143610781};\\\", \\\"{x:1379,y:662,t:1528143610808};\\\", \\\"{x:1377,y:664,t:1528143610849};\\\", \\\"{x:1376,y:665,t:1528143610865};\\\", \\\"{x:1374,y:668,t:1528143610881};\\\", \\\"{x:1372,y:669,t:1528143610898};\\\", \\\"{x:1369,y:671,t:1528143610915};\\\", \\\"{x:1368,y:672,t:1528143610932};\\\", \\\"{x:1367,y:672,t:1528143610948};\\\", \\\"{x:1366,y:674,t:1528143610965};\\\", \\\"{x:1365,y:674,t:1528143610984};\\\", \\\"{x:1365,y:673,t:1528143611153};\\\", \\\"{x:1365,y:671,t:1528143611165};\\\", \\\"{x:1365,y:667,t:1528143611182};\\\", \\\"{x:1366,y:665,t:1528143611199};\\\", \\\"{x:1366,y:663,t:1528143611216};\\\", \\\"{x:1366,y:662,t:1528143611232};\\\", \\\"{x:1368,y:658,t:1528143611249};\\\", \\\"{x:1370,y:653,t:1528143611266};\\\", \\\"{x:1370,y:650,t:1528143611282};\\\", \\\"{x:1371,y:647,t:1528143611299};\\\", \\\"{x:1372,y:644,t:1528143611316};\\\", \\\"{x:1373,y:639,t:1528143611333};\\\", \\\"{x:1374,y:635,t:1528143611349};\\\", \\\"{x:1374,y:633,t:1528143611366};\\\", \\\"{x:1375,y:632,t:1528143611383};\\\", \\\"{x:1376,y:628,t:1528143611399};\\\", \\\"{x:1379,y:616,t:1528143611417};\\\", \\\"{x:1384,y:606,t:1528143611433};\\\", \\\"{x:1388,y:596,t:1528143611449};\\\", \\\"{x:1389,y:594,t:1528143611466};\\\", \\\"{x:1392,y:590,t:1528143611483};\\\", \\\"{x:1394,y:587,t:1528143611500};\\\", \\\"{x:1396,y:582,t:1528143611516};\\\", \\\"{x:1397,y:580,t:1528143611533};\\\", \\\"{x:1398,y:578,t:1528143611550};\\\", \\\"{x:1398,y:577,t:1528143611566};\\\", \\\"{x:1398,y:576,t:1528143611584};\\\", \\\"{x:1399,y:575,t:1528143611657};\\\", \\\"{x:1399,y:573,t:1528143611688};\\\", \\\"{x:1400,y:573,t:1528143611700};\\\", \\\"{x:1400,y:572,t:1528143611736};\\\", \\\"{x:1401,y:572,t:1528143611750};\\\", \\\"{x:1403,y:570,t:1528143611767};\\\", \\\"{x:1403,y:569,t:1528143611785};\\\", \\\"{x:1404,y:569,t:1528143611801};\\\", \\\"{x:1405,y:568,t:1528143611816};\\\", \\\"{x:1406,y:568,t:1528143611848};\\\", \\\"{x:1408,y:568,t:1528143611919};\\\", \\\"{x:1409,y:568,t:1528143612129};\\\", \\\"{x:1410,y:567,t:1528143612369};\\\", \\\"{x:1411,y:567,t:1528143612576};\\\", \\\"{x:1412,y:566,t:1528143612608};\\\", \\\"{x:1406,y:566,t:1528143613938};\\\", \\\"{x:1333,y:566,t:1528143613955};\\\", \\\"{x:1235,y:566,t:1528143613972};\\\", \\\"{x:1138,y:566,t:1528143613989};\\\", \\\"{x:1037,y:558,t:1528143614006};\\\", \\\"{x:954,y:547,t:1528143614022};\\\", \\\"{x:895,y:539,t:1528143614040};\\\", \\\"{x:831,y:538,t:1528143614055};\\\", \\\"{x:810,y:538,t:1528143614072};\\\", \\\"{x:803,y:538,t:1528143614087};\\\", \\\"{x:798,y:538,t:1528143614104};\\\", \\\"{x:794,y:538,t:1528143614121};\\\", \\\"{x:786,y:538,t:1528143614137};\\\", \\\"{x:764,y:540,t:1528143614155};\\\", \\\"{x:735,y:542,t:1528143614170};\\\", \\\"{x:707,y:547,t:1528143614188};\\\", \\\"{x:684,y:548,t:1528143614204};\\\", \\\"{x:662,y:551,t:1528143614220};\\\", \\\"{x:647,y:552,t:1528143614238};\\\", \\\"{x:643,y:552,t:1528143614255};\\\", \\\"{x:641,y:552,t:1528143614272};\\\", \\\"{x:644,y:551,t:1528143614376};\\\", \\\"{x:657,y:548,t:1528143614388};\\\", \\\"{x:700,y:544,t:1528143614404};\\\", \\\"{x:735,y:541,t:1528143614424};\\\", \\\"{x:765,y:539,t:1528143614437};\\\", \\\"{x:782,y:539,t:1528143614454};\\\", \\\"{x:788,y:539,t:1528143614471};\\\", \\\"{x:789,y:539,t:1528143614616};\\\", \\\"{x:792,y:539,t:1528143614624};\\\", \\\"{x:793,y:538,t:1528143614640};\\\", \\\"{x:794,y:538,t:1528143614655};\\\", \\\"{x:797,y:534,t:1528143614672};\\\", \\\"{x:799,y:531,t:1528143614689};\\\", \\\"{x:800,y:528,t:1528143614705};\\\", \\\"{x:802,y:526,t:1528143614722};\\\", \\\"{x:802,y:525,t:1528143614760};\\\", \\\"{x:803,y:524,t:1528143614777};\\\", \\\"{x:803,y:523,t:1528143614788};\\\", \\\"{x:805,y:521,t:1528143614804};\\\", \\\"{x:808,y:517,t:1528143614822};\\\", \\\"{x:809,y:516,t:1528143614838};\\\", \\\"{x:809,y:515,t:1528143614854};\\\", \\\"{x:811,y:513,t:1528143614871};\\\", \\\"{x:813,y:511,t:1528143614889};\\\", \\\"{x:813,y:509,t:1528143614904};\\\", \\\"{x:815,y:507,t:1528143614921};\\\", \\\"{x:817,y:509,t:1528143615488};\\\", \\\"{x:820,y:512,t:1528143615506};\\\", \\\"{x:824,y:517,t:1528143615522};\\\", \\\"{x:828,y:521,t:1528143615540};\\\", \\\"{x:831,y:524,t:1528143615555};\\\", \\\"{x:831,y:525,t:1528143615572};\\\", \\\"{x:832,y:525,t:1528143615591};\\\", \\\"{x:833,y:525,t:1528143615607};\\\", \\\"{x:834,y:525,t:1528143615622};\\\", \\\"{x:836,y:525,t:1528143615639};\\\", \\\"{x:839,y:524,t:1528143615656};\\\", \\\"{x:841,y:522,t:1528143615672};\\\", \\\"{x:842,y:520,t:1528143615689};\\\", \\\"{x:843,y:516,t:1528143615707};\\\", \\\"{x:843,y:514,t:1528143615721};\\\", \\\"{x:843,y:513,t:1528143615739};\\\", \\\"{x:843,y:512,t:1528143615848};\\\", \\\"{x:842,y:513,t:1528143616072};\\\", \\\"{x:841,y:516,t:1528143616080};\\\", \\\"{x:841,y:517,t:1528143616090};\\\", \\\"{x:839,y:520,t:1528143616106};\\\", \\\"{x:837,y:525,t:1528143616123};\\\", \\\"{x:836,y:531,t:1528143616140};\\\", \\\"{x:835,y:533,t:1528143616156};\\\", \\\"{x:835,y:534,t:1528143616173};\\\", \\\"{x:835,y:535,t:1528143616559};\\\", \\\"{x:841,y:540,t:1528143616572};\\\", \\\"{x:869,y:563,t:1528143616591};\\\", \\\"{x:911,y:582,t:1528143616607};\\\", \\\"{x:966,y:608,t:1528143616623};\\\", \\\"{x:1054,y:647,t:1528143616639};\\\", \\\"{x:1114,y:682,t:1528143616656};\\\", \\\"{x:1166,y:702,t:1528143616673};\\\", \\\"{x:1212,y:722,t:1528143616690};\\\", \\\"{x:1245,y:736,t:1528143616707};\\\", \\\"{x:1261,y:740,t:1528143616722};\\\", \\\"{x:1266,y:742,t:1528143616740};\\\", \\\"{x:1266,y:743,t:1528143616808};\\\", \\\"{x:1266,y:744,t:1528143616824};\\\", \\\"{x:1266,y:746,t:1528143616839};\\\", \\\"{x:1262,y:749,t:1528143616858};\\\", \\\"{x:1257,y:752,t:1528143616874};\\\", \\\"{x:1251,y:754,t:1528143616889};\\\", \\\"{x:1246,y:757,t:1528143616907};\\\", \\\"{x:1244,y:762,t:1528143616924};\\\", \\\"{x:1242,y:768,t:1528143616939};\\\", \\\"{x:1242,y:774,t:1528143616957};\\\", \\\"{x:1242,y:775,t:1528143616974};\\\", \\\"{x:1242,y:777,t:1528143616999};\\\", \\\"{x:1242,y:778,t:1528143617023};\\\", \\\"{x:1242,y:782,t:1528143617039};\\\", \\\"{x:1243,y:786,t:1528143617057};\\\", \\\"{x:1243,y:787,t:1528143617074};\\\", \\\"{x:1243,y:788,t:1528143617090};\\\", \\\"{x:1243,y:792,t:1528143617107};\\\", \\\"{x:1240,y:800,t:1528143617124};\\\", \\\"{x:1236,y:803,t:1528143617139};\\\", \\\"{x:1236,y:804,t:1528143617157};\\\", \\\"{x:1236,y:801,t:1528143617273};\\\", \\\"{x:1246,y:790,t:1528143617290};\\\", \\\"{x:1254,y:781,t:1528143617307};\\\", \\\"{x:1258,y:775,t:1528143617324};\\\", \\\"{x:1261,y:767,t:1528143617340};\\\", \\\"{x:1264,y:762,t:1528143617356};\\\", \\\"{x:1264,y:759,t:1528143617373};\\\", \\\"{x:1265,y:754,t:1528143617390};\\\", \\\"{x:1268,y:749,t:1528143617407};\\\", \\\"{x:1273,y:739,t:1528143617423};\\\", \\\"{x:1276,y:728,t:1528143617441};\\\", \\\"{x:1279,y:717,t:1528143617458};\\\", \\\"{x:1283,y:709,t:1528143617474};\\\", \\\"{x:1286,y:702,t:1528143617491};\\\", \\\"{x:1290,y:694,t:1528143617507};\\\", \\\"{x:1293,y:686,t:1528143617524};\\\", \\\"{x:1296,y:678,t:1528143617541};\\\", \\\"{x:1298,y:676,t:1528143617557};\\\", \\\"{x:1300,y:671,t:1528143617574};\\\", \\\"{x:1303,y:665,t:1528143617591};\\\", \\\"{x:1307,y:656,t:1528143617607};\\\", \\\"{x:1309,y:650,t:1528143617624};\\\", \\\"{x:1312,y:647,t:1528143617641};\\\", \\\"{x:1314,y:644,t:1528143617657};\\\", \\\"{x:1319,y:639,t:1528143617674};\\\", \\\"{x:1322,y:634,t:1528143617692};\\\", \\\"{x:1323,y:631,t:1528143617708};\\\", \\\"{x:1326,y:625,t:1528143617724};\\\", \\\"{x:1328,y:621,t:1528143617741};\\\", \\\"{x:1329,y:619,t:1528143617758};\\\", \\\"{x:1331,y:616,t:1528143617774};\\\", \\\"{x:1335,y:608,t:1528143617791};\\\", \\\"{x:1341,y:591,t:1528143617807};\\\", \\\"{x:1348,y:579,t:1528143617824};\\\", \\\"{x:1349,y:577,t:1528143617841};\\\", \\\"{x:1351,y:572,t:1528143617857};\\\", \\\"{x:1354,y:567,t:1528143617874};\\\", \\\"{x:1356,y:561,t:1528143617891};\\\", \\\"{x:1361,y:552,t:1528143617908};\\\", \\\"{x:1362,y:549,t:1528143617924};\\\", \\\"{x:1364,y:545,t:1528143617941};\\\", \\\"{x:1365,y:542,t:1528143617959};\\\", \\\"{x:1369,y:538,t:1528143617974};\\\", \\\"{x:1369,y:536,t:1528143617991};\\\", \\\"{x:1369,y:535,t:1528143618008};\\\", \\\"{x:1371,y:532,t:1528143618073};\\\", \\\"{x:1372,y:531,t:1528143618080};\\\", \\\"{x:1372,y:530,t:1528143618096};\\\", \\\"{x:1374,y:528,t:1528143618176};\\\", \\\"{x:1375,y:527,t:1528143618191};\\\", \\\"{x:1376,y:525,t:1528143618208};\\\", \\\"{x:1378,y:524,t:1528143618224};\\\", \\\"{x:1378,y:523,t:1528143618241};\\\", \\\"{x:1378,y:522,t:1528143618272};\\\", \\\"{x:1379,y:522,t:1528143618288};\\\", \\\"{x:1380,y:524,t:1528143618792};\\\", \\\"{x:1382,y:531,t:1528143618809};\\\", \\\"{x:1386,y:540,t:1528143618825};\\\", \\\"{x:1386,y:544,t:1528143618843};\\\", \\\"{x:1389,y:550,t:1528143618859};\\\", \\\"{x:1389,y:552,t:1528143618876};\\\", \\\"{x:1390,y:554,t:1528143618893};\\\", \\\"{x:1390,y:555,t:1528143618908};\\\", \\\"{x:1392,y:558,t:1528143618925};\\\", \\\"{x:1393,y:560,t:1528143618942};\\\", \\\"{x:1396,y:566,t:1528143618960};\\\", \\\"{x:1397,y:567,t:1528143618975};\\\", \\\"{x:1401,y:576,t:1528143618992};\\\", \\\"{x:1403,y:580,t:1528143619008};\\\", \\\"{x:1407,y:587,t:1528143619025};\\\", \\\"{x:1410,y:592,t:1528143619043};\\\", \\\"{x:1413,y:597,t:1528143619058};\\\", \\\"{x:1417,y:605,t:1528143619076};\\\", \\\"{x:1422,y:612,t:1528143619092};\\\", \\\"{x:1426,y:619,t:1528143619108};\\\", \\\"{x:1430,y:627,t:1528143619125};\\\", \\\"{x:1435,y:636,t:1528143619143};\\\", \\\"{x:1444,y:649,t:1528143619159};\\\", \\\"{x:1452,y:662,t:1528143619175};\\\", \\\"{x:1471,y:688,t:1528143619192};\\\", \\\"{x:1480,y:701,t:1528143619209};\\\", \\\"{x:1492,y:714,t:1528143619225};\\\", \\\"{x:1501,y:725,t:1528143619242};\\\", \\\"{x:1508,y:732,t:1528143619260};\\\", \\\"{x:1517,y:741,t:1528143619276};\\\", \\\"{x:1524,y:750,t:1528143619292};\\\", \\\"{x:1530,y:757,t:1528143619309};\\\", \\\"{x:1532,y:762,t:1528143619325};\\\", \\\"{x:1536,y:765,t:1528143619342};\\\", \\\"{x:1538,y:769,t:1528143619359};\\\", \\\"{x:1540,y:774,t:1528143619375};\\\", \\\"{x:1542,y:778,t:1528143619393};\\\", \\\"{x:1543,y:781,t:1528143619409};\\\", \\\"{x:1544,y:784,t:1528143619426};\\\", \\\"{x:1545,y:790,t:1528143619442};\\\", \\\"{x:1547,y:802,t:1528143619459};\\\", \\\"{x:1550,y:816,t:1528143619475};\\\", \\\"{x:1551,y:825,t:1528143619493};\\\", \\\"{x:1551,y:828,t:1528143619510};\\\", \\\"{x:1551,y:829,t:1528143619525};\\\", \\\"{x:1551,y:831,t:1528143619543};\\\", \\\"{x:1551,y:832,t:1528143619568};\\\", \\\"{x:1549,y:832,t:1528143619585};\\\", \\\"{x:1543,y:832,t:1528143619593};\\\", \\\"{x:1519,y:832,t:1528143619609};\\\", \\\"{x:1473,y:832,t:1528143619626};\\\", \\\"{x:1425,y:832,t:1528143619642};\\\", \\\"{x:1383,y:838,t:1528143619660};\\\", \\\"{x:1344,y:844,t:1528143619676};\\\", \\\"{x:1317,y:852,t:1528143619692};\\\", \\\"{x:1297,y:858,t:1528143619710};\\\", \\\"{x:1282,y:863,t:1528143619727};\\\", \\\"{x:1274,y:866,t:1528143619743};\\\", \\\"{x:1263,y:868,t:1528143619759};\\\", \\\"{x:1249,y:872,t:1528143619776};\\\", \\\"{x:1243,y:874,t:1528143619793};\\\", \\\"{x:1236,y:875,t:1528143619809};\\\", \\\"{x:1230,y:876,t:1528143619826};\\\", \\\"{x:1222,y:876,t:1528143619842};\\\", \\\"{x:1211,y:876,t:1528143619859};\\\", \\\"{x:1203,y:876,t:1528143619876};\\\", \\\"{x:1201,y:876,t:1528143619892};\\\", \\\"{x:1200,y:877,t:1528143619961};\\\", \\\"{x:1198,y:886,t:1528143619976};\\\", \\\"{x:1196,y:900,t:1528143619993};\\\", \\\"{x:1192,y:912,t:1528143620009};\\\", \\\"{x:1192,y:922,t:1528143620026};\\\", \\\"{x:1191,y:929,t:1528143620043};\\\", \\\"{x:1189,y:935,t:1528143620059};\\\", \\\"{x:1188,y:941,t:1528143620076};\\\", \\\"{x:1188,y:945,t:1528143620094};\\\", \\\"{x:1188,y:946,t:1528143620161};\\\", \\\"{x:1188,y:947,t:1528143620176};\\\", \\\"{x:1188,y:948,t:1528143620193};\\\", \\\"{x:1190,y:948,t:1528143620289};\\\", \\\"{x:1197,y:950,t:1528143620296};\\\", \\\"{x:1202,y:952,t:1528143620309};\\\", \\\"{x:1220,y:957,t:1528143620326};\\\", \\\"{x:1233,y:960,t:1528143620344};\\\", \\\"{x:1243,y:963,t:1528143620359};\\\", \\\"{x:1246,y:964,t:1528143620376};\\\", \\\"{x:1246,y:965,t:1528143620409};\\\", \\\"{x:1245,y:966,t:1528143620416};\\\", \\\"{x:1241,y:966,t:1528143620426};\\\", \\\"{x:1225,y:966,t:1528143620443};\\\", \\\"{x:1212,y:967,t:1528143620460};\\\", \\\"{x:1205,y:967,t:1528143620476};\\\", \\\"{x:1204,y:967,t:1528143620493};\\\", \\\"{x:1202,y:967,t:1528143620520};\\\", \\\"{x:1203,y:967,t:1528143620624};\\\", \\\"{x:1204,y:967,t:1528143620632};\\\", \\\"{x:1207,y:967,t:1528143620644};\\\", \\\"{x:1210,y:967,t:1528143620660};\\\", \\\"{x:1214,y:966,t:1528143620677};\\\", \\\"{x:1215,y:966,t:1528143620728};\\\", \\\"{x:1217,y:966,t:1528143620881};\\\", \\\"{x:1218,y:966,t:1528143621048};\\\", \\\"{x:1219,y:966,t:1528143621061};\\\", \\\"{x:1222,y:966,t:1528143621077};\\\", \\\"{x:1230,y:965,t:1528143621093};\\\", \\\"{x:1243,y:962,t:1528143621110};\\\", \\\"{x:1253,y:961,t:1528143621128};\\\", \\\"{x:1261,y:960,t:1528143621144};\\\", \\\"{x:1266,y:959,t:1528143621160};\\\", \\\"{x:1269,y:959,t:1528143621178};\\\", \\\"{x:1271,y:959,t:1528143621194};\\\", \\\"{x:1273,y:959,t:1528143621211};\\\", \\\"{x:1275,y:960,t:1528143621228};\\\", \\\"{x:1276,y:961,t:1528143621243};\\\", \\\"{x:1278,y:962,t:1528143621297};\\\", \\\"{x:1281,y:963,t:1528143621310};\\\", \\\"{x:1283,y:963,t:1528143621327};\\\", \\\"{x:1285,y:964,t:1528143621344};\\\", \\\"{x:1286,y:965,t:1528143621361};\\\", \\\"{x:1287,y:965,t:1528143621377};\\\", \\\"{x:1286,y:965,t:1528143621416};\\\", \\\"{x:1284,y:965,t:1528143621427};\\\", \\\"{x:1281,y:965,t:1528143621445};\\\", \\\"{x:1279,y:965,t:1528143621460};\\\", \\\"{x:1279,y:966,t:1528143621592};\\\", \\\"{x:1280,y:966,t:1528143621600};\\\", \\\"{x:1282,y:966,t:1528143621611};\\\", \\\"{x:1284,y:966,t:1528143621628};\\\", \\\"{x:1285,y:966,t:1528143621648};\\\", \\\"{x:1286,y:966,t:1528143621660};\\\", \\\"{x:1292,y:966,t:1528143621678};\\\", \\\"{x:1301,y:968,t:1528143621694};\\\", \\\"{x:1304,y:968,t:1528143621710};\\\", \\\"{x:1307,y:968,t:1528143621727};\\\", \\\"{x:1313,y:968,t:1528143621744};\\\", \\\"{x:1315,y:968,t:1528143621761};\\\", \\\"{x:1317,y:968,t:1528143621825};\\\", \\\"{x:1319,y:968,t:1528143621832};\\\", \\\"{x:1323,y:968,t:1528143621844};\\\", \\\"{x:1330,y:968,t:1528143621861};\\\", \\\"{x:1334,y:968,t:1528143621877};\\\", \\\"{x:1337,y:968,t:1528143621895};\\\", \\\"{x:1338,y:968,t:1528143621911};\\\", \\\"{x:1339,y:968,t:1528143621936};\\\", \\\"{x:1340,y:968,t:1528143621944};\\\", \\\"{x:1356,y:968,t:1528143621961};\\\", \\\"{x:1379,y:968,t:1528143621977};\\\", \\\"{x:1397,y:968,t:1528143621993};\\\", \\\"{x:1410,y:968,t:1528143622011};\\\", \\\"{x:1413,y:968,t:1528143622027};\\\", \\\"{x:1414,y:968,t:1528143622044};\\\", \\\"{x:1414,y:967,t:1528143622071};\\\", \\\"{x:1412,y:967,t:1528143622088};\\\", \\\"{x:1411,y:967,t:1528143622095};\\\", \\\"{x:1409,y:967,t:1528143622111};\\\", \\\"{x:1404,y:966,t:1528143622127};\\\", \\\"{x:1391,y:964,t:1528143622144};\\\", \\\"{x:1382,y:963,t:1528143622161};\\\", \\\"{x:1379,y:962,t:1528143622179};\\\", \\\"{x:1378,y:961,t:1528143622194};\\\", \\\"{x:1377,y:961,t:1528143622211};\\\", \\\"{x:1376,y:961,t:1528143622265};\\\", \\\"{x:1375,y:961,t:1528143622304};\\\", \\\"{x:1374,y:961,t:1528143622328};\\\", \\\"{x:1373,y:960,t:1528143622345};\\\", \\\"{x:1372,y:960,t:1528143622361};\\\", \\\"{x:1371,y:960,t:1528143622379};\\\", \\\"{x:1367,y:957,t:1528143622395};\\\", \\\"{x:1365,y:957,t:1528143622411};\\\", \\\"{x:1362,y:956,t:1528143622428};\\\", \\\"{x:1358,y:955,t:1528143622444};\\\", \\\"{x:1358,y:954,t:1528143622461};\\\", \\\"{x:1357,y:954,t:1528143622479};\\\", \\\"{x:1356,y:952,t:1528143622681};\\\", \\\"{x:1356,y:951,t:1528143622704};\\\", \\\"{x:1357,y:951,t:1528143626825};\\\", \\\"{x:1358,y:951,t:1528143626856};\\\", \\\"{x:1359,y:951,t:1528143626896};\\\", \\\"{x:1359,y:952,t:1528143626937};\\\", \\\"{x:1359,y:953,t:1528143626948};\\\", \\\"{x:1359,y:954,t:1528143626965};\\\", \\\"{x:1359,y:955,t:1528143626982};\\\", \\\"{x:1359,y:956,t:1528143626999};\\\", \\\"{x:1359,y:957,t:1528143627065};\\\", \\\"{x:1359,y:958,t:1528143627280};\\\", \\\"{x:1359,y:959,t:1528143627641};\\\", \\\"{x:1358,y:959,t:1528143627649};\\\", \\\"{x:1356,y:961,t:1528143627666};\\\", \\\"{x:1352,y:961,t:1528143627682};\\\", \\\"{x:1351,y:962,t:1528143627698};\\\", \\\"{x:1346,y:962,t:1528143627716};\\\", \\\"{x:1339,y:962,t:1528143627733};\\\", \\\"{x:1336,y:962,t:1528143627749};\\\", \\\"{x:1331,y:962,t:1528143627766};\\\", \\\"{x:1324,y:962,t:1528143627783};\\\", \\\"{x:1317,y:961,t:1528143627798};\\\", \\\"{x:1310,y:960,t:1528143627816};\\\", \\\"{x:1302,y:959,t:1528143627832};\\\", \\\"{x:1286,y:957,t:1528143627849};\\\", \\\"{x:1270,y:955,t:1528143627866};\\\", \\\"{x:1254,y:953,t:1528143627883};\\\", \\\"{x:1247,y:951,t:1528143627898};\\\", \\\"{x:1242,y:951,t:1528143627915};\\\", \\\"{x:1237,y:950,t:1528143627932};\\\", \\\"{x:1234,y:950,t:1528143627950};\\\", \\\"{x:1231,y:949,t:1528143627965};\\\", \\\"{x:1229,y:949,t:1528143627983};\\\", \\\"{x:1228,y:948,t:1528143627999};\\\", \\\"{x:1226,y:948,t:1528143628032};\\\", \\\"{x:1226,y:947,t:1528143628049};\\\", \\\"{x:1225,y:947,t:1528143628112};\\\", \\\"{x:1225,y:948,t:1528143628143};\\\", \\\"{x:1225,y:949,t:1528143628167};\\\", \\\"{x:1225,y:950,t:1528143628183};\\\", \\\"{x:1225,y:951,t:1528143628199};\\\", \\\"{x:1224,y:953,t:1528143628215};\\\", \\\"{x:1223,y:954,t:1528143628232};\\\", \\\"{x:1220,y:955,t:1528143628250};\\\", \\\"{x:1216,y:957,t:1528143628266};\\\", \\\"{x:1211,y:957,t:1528143628283};\\\", \\\"{x:1204,y:957,t:1528143628300};\\\", \\\"{x:1197,y:957,t:1528143628316};\\\", \\\"{x:1191,y:957,t:1528143628332};\\\", \\\"{x:1189,y:957,t:1528143628350};\\\", \\\"{x:1187,y:957,t:1528143628366};\\\", \\\"{x:1186,y:957,t:1528143628384};\\\", \\\"{x:1185,y:957,t:1528143628481};\\\", \\\"{x:1184,y:958,t:1528143628496};\\\", \\\"{x:1184,y:959,t:1528143628520};\\\", \\\"{x:1183,y:960,t:1528143628552};\\\", \\\"{x:1182,y:960,t:1528143628633};\\\", \\\"{x:1180,y:961,t:1528143628650};\\\", \\\"{x:1178,y:961,t:1528143628721};\\\", \\\"{x:1177,y:961,t:1528143628732};\\\", \\\"{x:1174,y:961,t:1528143628750};\\\", \\\"{x:1173,y:961,t:1528143628767};\\\", \\\"{x:1172,y:961,t:1528143628783};\\\", \\\"{x:1172,y:962,t:1528143628800};\\\", \\\"{x:1171,y:963,t:1528143629033};\\\", \\\"{x:1170,y:963,t:1528143629088};\\\", \\\"{x:1169,y:963,t:1528143629160};\\\", \\\"{x:1168,y:964,t:1528143629201};\\\", \\\"{x:1170,y:963,t:1528143629401};\\\", \\\"{x:1180,y:963,t:1528143629416};\\\", \\\"{x:1193,y:963,t:1528143629434};\\\", \\\"{x:1205,y:963,t:1528143629451};\\\", \\\"{x:1215,y:963,t:1528143629467};\\\", \\\"{x:1219,y:963,t:1528143629484};\\\", \\\"{x:1220,y:963,t:1528143629501};\\\", \\\"{x:1222,y:963,t:1528143629560};\\\", \\\"{x:1223,y:963,t:1528143629592};\\\", \\\"{x:1224,y:964,t:1528143629608};\\\", \\\"{x:1223,y:964,t:1528143629872};\\\", \\\"{x:1224,y:963,t:1528143629883};\\\", \\\"{x:1232,y:963,t:1528143629901};\\\", \\\"{x:1243,y:962,t:1528143629919};\\\", \\\"{x:1255,y:962,t:1528143629934};\\\", \\\"{x:1264,y:962,t:1528143629951};\\\", \\\"{x:1270,y:962,t:1528143629968};\\\", \\\"{x:1272,y:962,t:1528143630200};\\\", \\\"{x:1273,y:962,t:1528143630272};\\\", \\\"{x:1274,y:962,t:1528143630366};\\\", \\\"{x:1277,y:962,t:1528143630384};\\\", \\\"{x:1281,y:962,t:1528143630399};\\\", \\\"{x:1286,y:962,t:1528143630416};\\\", \\\"{x:1296,y:962,t:1528143630434};\\\", \\\"{x:1304,y:962,t:1528143630450};\\\", \\\"{x:1311,y:962,t:1528143630467};\\\", \\\"{x:1316,y:962,t:1528143630484};\\\", \\\"{x:1320,y:962,t:1528143630500};\\\", \\\"{x:1322,y:962,t:1528143630518};\\\", \\\"{x:1323,y:962,t:1528143630535};\\\", \\\"{x:1324,y:962,t:1528143630592};\\\", \\\"{x:1325,y:962,t:1528143630624};\\\", \\\"{x:1326,y:962,t:1528143630656};\\\", \\\"{x:1326,y:963,t:1528143630668};\\\", \\\"{x:1330,y:964,t:1528143630684};\\\", \\\"{x:1335,y:965,t:1528143630702};\\\", \\\"{x:1337,y:965,t:1528143630718};\\\", \\\"{x:1340,y:966,t:1528143630735};\\\", \\\"{x:1338,y:966,t:1528143630840};\\\", \\\"{x:1336,y:966,t:1528143630852};\\\", \\\"{x:1331,y:966,t:1528143630867};\\\", \\\"{x:1329,y:966,t:1528143630885};\\\", \\\"{x:1323,y:966,t:1528143630902};\\\", \\\"{x:1317,y:966,t:1528143630918};\\\", \\\"{x:1312,y:966,t:1528143630935};\\\", \\\"{x:1307,y:966,t:1528143630951};\\\", \\\"{x:1300,y:966,t:1528143630967};\\\", \\\"{x:1295,y:965,t:1528143630985};\\\", \\\"{x:1286,y:965,t:1528143631002};\\\", \\\"{x:1276,y:963,t:1528143631018};\\\", \\\"{x:1267,y:963,t:1528143631034};\\\", \\\"{x:1257,y:961,t:1528143631053};\\\", \\\"{x:1243,y:961,t:1528143631069};\\\", \\\"{x:1233,y:960,t:1528143631085};\\\", \\\"{x:1230,y:960,t:1528143631102};\\\", \\\"{x:1229,y:960,t:1528143631120};\\\", \\\"{x:1227,y:960,t:1528143631136};\\\", \\\"{x:1224,y:960,t:1528143631152};\\\", \\\"{x:1223,y:960,t:1528143631169};\\\", \\\"{x:1222,y:960,t:1528143631216};\\\", \\\"{x:1221,y:960,t:1528143631224};\\\", \\\"{x:1228,y:960,t:1528143631352};\\\", \\\"{x:1253,y:960,t:1528143631368};\\\", \\\"{x:1272,y:963,t:1528143631386};\\\", \\\"{x:1295,y:963,t:1528143631402};\\\", \\\"{x:1310,y:964,t:1528143631419};\\\", \\\"{x:1314,y:964,t:1528143631436};\\\", \\\"{x:1313,y:964,t:1528143631504};\\\", \\\"{x:1311,y:964,t:1528143631519};\\\", \\\"{x:1309,y:964,t:1528143631536};\\\", \\\"{x:1306,y:964,t:1528143631552};\\\", \\\"{x:1302,y:965,t:1528143631569};\\\", \\\"{x:1297,y:965,t:1528143631586};\\\", \\\"{x:1290,y:965,t:1528143631602};\\\", \\\"{x:1285,y:967,t:1528143631619};\\\", \\\"{x:1283,y:967,t:1528143631664};\\\", \\\"{x:1282,y:966,t:1528143631681};\\\", \\\"{x:1281,y:966,t:1528143631688};\\\", \\\"{x:1282,y:966,t:1528143631816};\\\", \\\"{x:1286,y:966,t:1528143631824};\\\", \\\"{x:1292,y:966,t:1528143631836};\\\", \\\"{x:1297,y:966,t:1528143631852};\\\", \\\"{x:1310,y:966,t:1528143631868};\\\", \\\"{x:1321,y:966,t:1528143631886};\\\", \\\"{x:1327,y:966,t:1528143631903};\\\", \\\"{x:1330,y:966,t:1528143631919};\\\", \\\"{x:1331,y:966,t:1528143631944};\\\", \\\"{x:1333,y:966,t:1528143632272};\\\", \\\"{x:1335,y:966,t:1528143632288};\\\", \\\"{x:1336,y:966,t:1528143632303};\\\", \\\"{x:1337,y:966,t:1528143632320};\\\", \\\"{x:1338,y:966,t:1528143632336};\\\", \\\"{x:1339,y:966,t:1528143632352};\\\", \\\"{x:1341,y:966,t:1528143632370};\\\", \\\"{x:1343,y:966,t:1528143632386};\\\", \\\"{x:1349,y:967,t:1528143632403};\\\", \\\"{x:1354,y:967,t:1528143632420};\\\", \\\"{x:1363,y:968,t:1528143632436};\\\", \\\"{x:1368,y:968,t:1528143632453};\\\", \\\"{x:1376,y:968,t:1528143632469};\\\", \\\"{x:1388,y:970,t:1528143632486};\\\", \\\"{x:1399,y:970,t:1528143632503};\\\", \\\"{x:1405,y:970,t:1528143632520};\\\", \\\"{x:1406,y:970,t:1528143632535};\\\", \\\"{x:1407,y:970,t:1528143632553};\\\", \\\"{x:1407,y:971,t:1528143632648};\\\", \\\"{x:1408,y:971,t:1528143632816};\\\", \\\"{x:1409,y:971,t:1528143632823};\\\", \\\"{x:1411,y:971,t:1528143632836};\\\", \\\"{x:1415,y:971,t:1528143632853};\\\", \\\"{x:1425,y:971,t:1528143632870};\\\", \\\"{x:1437,y:971,t:1528143632887};\\\", \\\"{x:1448,y:971,t:1528143632902};\\\", \\\"{x:1461,y:971,t:1528143632919};\\\", \\\"{x:1464,y:971,t:1528143632936};\\\", \\\"{x:1465,y:971,t:1528143632975};\\\", \\\"{x:1466,y:971,t:1528143632999};\\\", \\\"{x:1467,y:971,t:1528143633005};\\\", \\\"{x:1468,y:971,t:1528143633021};\\\", \\\"{x:1469,y:971,t:1528143633037};\\\", \\\"{x:1470,y:971,t:1528143633053};\\\", \\\"{x:1471,y:971,t:1528143633262};\\\", \\\"{x:1477,y:971,t:1528143633270};\\\", \\\"{x:1484,y:971,t:1528143633285};\\\", \\\"{x:1508,y:971,t:1528143633303};\\\", \\\"{x:1523,y:971,t:1528143633318};\\\", \\\"{x:1531,y:971,t:1528143633335};\\\", \\\"{x:1532,y:971,t:1528143633366};\\\", \\\"{x:1533,y:971,t:1528143633406};\\\", \\\"{x:1534,y:970,t:1528143633418};\\\", \\\"{x:1535,y:970,t:1528143633462};\\\", \\\"{x:1536,y:970,t:1528143633494};\\\", \\\"{x:1537,y:970,t:1528143633510};\\\", \\\"{x:1538,y:970,t:1528143633559};\\\", \\\"{x:1542,y:970,t:1528143633742};\\\", \\\"{x:1545,y:970,t:1528143633752};\\\", \\\"{x:1553,y:970,t:1528143633769};\\\", \\\"{x:1562,y:970,t:1528143633785};\\\", \\\"{x:1567,y:970,t:1528143633801};\\\", \\\"{x:1570,y:970,t:1528143633820};\\\", \\\"{x:1572,y:970,t:1528143633835};\\\", \\\"{x:1573,y:970,t:1528143633852};\\\", \\\"{x:1576,y:970,t:1528143633869};\\\", \\\"{x:1580,y:970,t:1528143633885};\\\", \\\"{x:1592,y:971,t:1528143633902};\\\", \\\"{x:1597,y:972,t:1528143633919};\\\", \\\"{x:1601,y:972,t:1528143633935};\\\", \\\"{x:1603,y:972,t:1528143633952};\\\", \\\"{x:1604,y:972,t:1528143633974};\\\", \\\"{x:1605,y:972,t:1528143633985};\\\", \\\"{x:1606,y:972,t:1528143634006};\\\", \\\"{x:1607,y:972,t:1528143634038};\\\", \\\"{x:1608,y:972,t:1528143634052};\\\", \\\"{x:1609,y:972,t:1528143634069};\\\", \\\"{x:1606,y:972,t:1528143635534};\\\", \\\"{x:1602,y:972,t:1528143635542};\\\", \\\"{x:1592,y:972,t:1528143635554};\\\", \\\"{x:1558,y:963,t:1528143635571};\\\", \\\"{x:1502,y:947,t:1528143635588};\\\", \\\"{x:1431,y:917,t:1528143635603};\\\", \\\"{x:1364,y:887,t:1528143635620};\\\", \\\"{x:1296,y:846,t:1528143635637};\\\", \\\"{x:1223,y:806,t:1528143635653};\\\", \\\"{x:1098,y:738,t:1528143635670};\\\", \\\"{x:1006,y:699,t:1528143635687};\\\", \\\"{x:920,y:669,t:1528143635703};\\\", \\\"{x:855,y:648,t:1528143635720};\\\", \\\"{x:794,y:631,t:1528143635738};\\\", \\\"{x:745,y:620,t:1528143635754};\\\", \\\"{x:694,y:611,t:1528143635770};\\\", \\\"{x:659,y:605,t:1528143635786};\\\", \\\"{x:633,y:604,t:1528143635802};\\\", \\\"{x:613,y:604,t:1528143635819};\\\", \\\"{x:596,y:604,t:1528143635837};\\\", \\\"{x:582,y:604,t:1528143635853};\\\", \\\"{x:578,y:605,t:1528143635869};\\\", \\\"{x:575,y:608,t:1528143635886};\\\", \\\"{x:569,y:618,t:1528143635903};\\\", \\\"{x:558,y:636,t:1528143635920};\\\", \\\"{x:548,y:652,t:1528143635937};\\\", \\\"{x:538,y:666,t:1528143635954};\\\", \\\"{x:533,y:677,t:1528143635970};\\\", \\\"{x:527,y:688,t:1528143635987};\\\", \\\"{x:521,y:698,t:1528143636003};\\\", \\\"{x:516,y:704,t:1528143636020};\\\", \\\"{x:515,y:707,t:1528143636036};\\\", \\\"{x:514,y:713,t:1528143636053};\\\", \\\"{x:512,y:717,t:1528143636071};\\\", \\\"{x:511,y:721,t:1528143636087};\\\", \\\"{x:509,y:724,t:1528143636103};\\\", \\\"{x:509,y:726,t:1528143636121};\\\", \\\"{x:509,y:727,t:1528143636137};\\\", \\\"{x:508,y:727,t:1528143636678};\\\", \\\"{x:507,y:727,t:1528143636717};\\\", \\\"{x:506,y:727,t:1528143636725};\\\", \\\"{x:505,y:727,t:1528143636749};\\\", \\\"{x:504,y:727,t:1528143636765};\\\", \\\"{x:503,y:727,t:1528143636773};\\\", \\\"{x:502,y:727,t:1528143636805};\\\", \\\"{x:499,y:726,t:1528143636989};\\\", \\\"{x:498,y:725,t:1528143637003};\\\", \\\"{x:495,y:724,t:1528143637021};\\\", \\\"{x:491,y:722,t:1528143637037};\\\", \\\"{x:491,y:721,t:1528143637054};\\\", \\\"{x:490,y:721,t:1528143637071};\\\" ] }, { \\\"rt\\\": 75067, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 13, \\\"time_elapsed\\\": 800170, \\\"internal_node_id\\\": \\\"0.0-6.0-3.0\\\", \\\"subject\\\": \\\"K0CNH\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime+before+endtime+during\\\", \\\"q\\\": 9, \\\"clicks\\\": 1, \\\"explicit\\\": 2, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-05 PM-04 PM-05 PM-3-I -I -I -I -04 PM-B -B -M -J -J -B -B \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:489,y:720,t:1528143638205};\\\", \\\"{x:489,y:718,t:1528143638220};\\\", \\\"{x:489,y:716,t:1528143638223};\\\", \\\"{x:489,y:713,t:1528143638239};\\\", \\\"{x:488,y:706,t:1528143638254};\\\", \\\"{x:487,y:700,t:1528143638271};\\\", \\\"{x:486,y:693,t:1528143638289};\\\", \\\"{x:486,y:680,t:1528143638304};\\\", \\\"{x:486,y:665,t:1528143638321};\\\", \\\"{x:486,y:644,t:1528143638338};\\\", \\\"{x:486,y:622,t:1528143638355};\\\", \\\"{x:486,y:599,t:1528143638372};\\\", \\\"{x:486,y:571,t:1528143638389};\\\", \\\"{x:486,y:523,t:1528143638405};\\\", \\\"{x:482,y:502,t:1528143638422};\\\", \\\"{x:474,y:491,t:1528143638439};\\\", \\\"{x:468,y:487,t:1528143638455};\\\", \\\"{x:465,y:486,t:1528143638472};\\\", \\\"{x:461,y:483,t:1528143638489};\\\", \\\"{x:449,y:482,t:1528143638506};\\\", \\\"{x:431,y:477,t:1528143638522};\\\", \\\"{x:404,y:473,t:1528143638539};\\\", \\\"{x:374,y:471,t:1528143638555};\\\", \\\"{x:348,y:470,t:1528143638571};\\\", \\\"{x:324,y:470,t:1528143638589};\\\", \\\"{x:296,y:470,t:1528143638606};\\\", \\\"{x:281,y:470,t:1528143638623};\\\", \\\"{x:271,y:470,t:1528143638639};\\\", \\\"{x:266,y:470,t:1528143638656};\\\", \\\"{x:265,y:470,t:1528143638774};\\\", \\\"{x:265,y:468,t:1528143638789};\\\", \\\"{x:270,y:464,t:1528143638806};\\\", \\\"{x:274,y:463,t:1528143638823};\\\", \\\"{x:276,y:462,t:1528143638839};\\\", \\\"{x:285,y:461,t:1528143638855};\\\", \\\"{x:293,y:460,t:1528143638872};\\\", \\\"{x:303,y:459,t:1528143638888};\\\", \\\"{x:317,y:459,t:1528143638906};\\\", \\\"{x:328,y:459,t:1528143638922};\\\", \\\"{x:341,y:459,t:1528143638939};\\\", \\\"{x:355,y:459,t:1528143638956};\\\", \\\"{x:370,y:459,t:1528143638973};\\\", \\\"{x:397,y:459,t:1528143638989};\\\", \\\"{x:416,y:459,t:1528143639006};\\\", \\\"{x:435,y:459,t:1528143639023};\\\", \\\"{x:448,y:459,t:1528143639039};\\\", \\\"{x:459,y:459,t:1528143639055};\\\", \\\"{x:467,y:459,t:1528143639073};\\\", \\\"{x:473,y:459,t:1528143639090};\\\", \\\"{x:476,y:458,t:1528143639106};\\\", \\\"{x:480,y:457,t:1528143639123};\\\", \\\"{x:484,y:457,t:1528143639140};\\\", \\\"{x:488,y:457,t:1528143639156};\\\", \\\"{x:495,y:457,t:1528143639173};\\\", \\\"{x:516,y:457,t:1528143639190};\\\", \\\"{x:537,y:457,t:1528143639206};\\\", \\\"{x:554,y:457,t:1528143639223};\\\", \\\"{x:572,y:457,t:1528143639240};\\\", \\\"{x:585,y:457,t:1528143639257};\\\", \\\"{x:592,y:457,t:1528143639273};\\\", \\\"{x:595,y:457,t:1528143639290};\\\", \\\"{x:600,y:457,t:1528143639309};\\\", \\\"{x:602,y:457,t:1528143639323};\\\", \\\"{x:606,y:457,t:1528143639340};\\\", \\\"{x:609,y:457,t:1528143639357};\\\", \\\"{x:614,y:457,t:1528143639373};\\\", \\\"{x:621,y:457,t:1528143639390};\\\", \\\"{x:628,y:457,t:1528143639407};\\\", \\\"{x:635,y:457,t:1528143639422};\\\", \\\"{x:644,y:457,t:1528143639440};\\\", \\\"{x:651,y:457,t:1528143639457};\\\", \\\"{x:655,y:457,t:1528143639473};\\\", \\\"{x:660,y:457,t:1528143639490};\\\", \\\"{x:666,y:457,t:1528143639507};\\\", \\\"{x:669,y:457,t:1528143639523};\\\", \\\"{x:673,y:457,t:1528143639540};\\\", \\\"{x:674,y:457,t:1528143639557};\\\", \\\"{x:682,y:457,t:1528143639574};\\\", \\\"{x:687,y:457,t:1528143639590};\\\", \\\"{x:694,y:457,t:1528143639607};\\\", \\\"{x:704,y:457,t:1528143639624};\\\", \\\"{x:719,y:457,t:1528143639640};\\\", \\\"{x:737,y:459,t:1528143639657};\\\", \\\"{x:752,y:459,t:1528143639674};\\\", \\\"{x:768,y:459,t:1528143639690};\\\", \\\"{x:782,y:459,t:1528143639709};\\\", \\\"{x:796,y:459,t:1528143639724};\\\", \\\"{x:813,y:458,t:1528143639740};\\\", \\\"{x:833,y:454,t:1528143639756};\\\", \\\"{x:877,y:449,t:1528143639773};\\\", \\\"{x:903,y:445,t:1528143639790};\\\", \\\"{x:926,y:444,t:1528143639807};\\\", \\\"{x:948,y:444,t:1528143639824};\\\", \\\"{x:967,y:444,t:1528143639840};\\\", \\\"{x:979,y:444,t:1528143639857};\\\", \\\"{x:985,y:444,t:1528143639874};\\\", \\\"{x:990,y:444,t:1528143639890};\\\", \\\"{x:999,y:444,t:1528143639909};\\\", \\\"{x:1007,y:444,t:1528143639925};\\\", \\\"{x:1012,y:444,t:1528143639941};\\\", \\\"{x:1019,y:444,t:1528143639957};\\\", \\\"{x:1043,y:444,t:1528143639974};\\\", \\\"{x:1066,y:444,t:1528143639991};\\\", \\\"{x:1091,y:444,t:1528143640007};\\\", \\\"{x:1117,y:444,t:1528143640024};\\\", \\\"{x:1144,y:444,t:1528143640041};\\\", \\\"{x:1174,y:445,t:1528143640057};\\\", \\\"{x:1217,y:453,t:1528143640075};\\\", \\\"{x:1247,y:456,t:1528143640092};\\\", \\\"{x:1289,y:462,t:1528143640109};\\\", \\\"{x:1334,y:469,t:1528143640124};\\\", \\\"{x:1391,y:482,t:1528143640141};\\\", \\\"{x:1405,y:485,t:1528143640156};\\\", \\\"{x:1444,y:498,t:1528143640174};\\\", \\\"{x:1460,y:503,t:1528143640190};\\\", \\\"{x:1478,y:510,t:1528143640208};\\\", \\\"{x:1495,y:516,t:1528143640224};\\\", \\\"{x:1517,y:527,t:1528143640240};\\\", \\\"{x:1544,y:539,t:1528143640257};\\\", \\\"{x:1584,y:553,t:1528143640274};\\\", \\\"{x:1630,y:570,t:1528143640290};\\\", \\\"{x:1687,y:590,t:1528143640308};\\\", \\\"{x:1740,y:605,t:1528143640323};\\\", \\\"{x:1797,y:625,t:1528143640340};\\\", \\\"{x:1863,y:657,t:1528143640357};\\\", \\\"{x:1906,y:682,t:1528143640374};\\\", \\\"{x:1919,y:713,t:1528143640390};\\\", \\\"{x:1919,y:745,t:1528143640407};\\\", \\\"{x:1919,y:763,t:1528143640424};\\\", \\\"{x:1919,y:767,t:1528143640441};\\\", \\\"{x:1919,y:765,t:1528143640934};\\\", \\\"{x:1919,y:763,t:1528143640950};\\\", \\\"{x:1919,y:760,t:1528143640958};\\\", \\\"{x:1919,y:757,t:1528143640974};\\\", \\\"{x:1919,y:751,t:1528143640990};\\\", \\\"{x:1919,y:744,t:1528143641008};\\\", \\\"{x:1919,y:737,t:1528143641025};\\\", \\\"{x:1919,y:731,t:1528143641041};\\\", \\\"{x:1918,y:727,t:1528143641058};\\\", \\\"{x:1916,y:722,t:1528143641075};\\\", \\\"{x:1914,y:716,t:1528143641091};\\\", \\\"{x:1912,y:710,t:1528143641108};\\\", \\\"{x:1909,y:704,t:1528143641125};\\\", \\\"{x:1908,y:703,t:1528143641141};\\\", \\\"{x:1906,y:699,t:1528143641157};\\\", \\\"{x:1905,y:697,t:1528143641176};\\\", \\\"{x:1903,y:692,t:1528143641191};\\\", \\\"{x:1903,y:689,t:1528143641208};\\\", \\\"{x:1900,y:682,t:1528143641226};\\\", \\\"{x:1889,y:664,t:1528143641241};\\\", \\\"{x:1871,y:641,t:1528143641258};\\\", \\\"{x:1849,y:609,t:1528143641274};\\\", \\\"{x:1832,y:577,t:1528143641291};\\\", \\\"{x:1816,y:546,t:1528143641309};\\\", \\\"{x:1800,y:510,t:1528143641325};\\\", \\\"{x:1786,y:476,t:1528143641341};\\\", \\\"{x:1767,y:432,t:1528143641357};\\\", \\\"{x:1756,y:411,t:1528143641375};\\\", \\\"{x:1749,y:397,t:1528143641392};\\\", \\\"{x:1743,y:385,t:1528143641408};\\\", \\\"{x:1740,y:376,t:1528143641426};\\\", \\\"{x:1740,y:372,t:1528143641441};\\\", \\\"{x:1739,y:369,t:1528143641458};\\\", \\\"{x:1738,y:367,t:1528143641475};\\\", \\\"{x:1737,y:365,t:1528143641491};\\\", \\\"{x:1735,y:365,t:1528143641799};\\\", \\\"{x:1731,y:365,t:1528143641808};\\\", \\\"{x:1715,y:372,t:1528143641825};\\\", \\\"{x:1698,y:379,t:1528143641842};\\\", \\\"{x:1689,y:383,t:1528143641858};\\\", \\\"{x:1687,y:383,t:1528143641876};\\\", \\\"{x:1687,y:384,t:1528143642054};\\\", \\\"{x:1687,y:387,t:1528143642062};\\\", \\\"{x:1687,y:390,t:1528143642075};\\\", \\\"{x:1687,y:397,t:1528143642092};\\\", \\\"{x:1687,y:405,t:1528143642108};\\\", \\\"{x:1687,y:417,t:1528143642125};\\\", \\\"{x:1690,y:455,t:1528143642142};\\\", \\\"{x:1703,y:498,t:1528143642158};\\\", \\\"{x:1720,y:542,t:1528143642175};\\\", \\\"{x:1741,y:591,t:1528143642192};\\\", \\\"{x:1761,y:629,t:1528143642209};\\\", \\\"{x:1775,y:652,t:1528143642226};\\\", \\\"{x:1781,y:667,t:1528143642243};\\\", \\\"{x:1783,y:674,t:1528143642258};\\\", \\\"{x:1783,y:675,t:1528143642430};\\\", \\\"{x:1782,y:677,t:1528143642445};\\\", \\\"{x:1781,y:679,t:1528143642459};\\\", \\\"{x:1780,y:692,t:1528143642475};\\\", \\\"{x:1780,y:714,t:1528143642493};\\\", \\\"{x:1796,y:774,t:1528143642509};\\\", \\\"{x:1839,y:840,t:1528143642526};\\\", \\\"{x:1906,y:906,t:1528143642543};\\\", \\\"{x:1919,y:971,t:1528143642559};\\\", \\\"{x:1919,y:1015,t:1528143642575};\\\", \\\"{x:1919,y:1056,t:1528143642592};\\\", \\\"{x:1919,y:1072,t:1528143642609};\\\", \\\"{x:1919,y:1077,t:1528143642626};\\\", \\\"{x:1919,y:1078,t:1528143642642};\\\", \\\"{x:1919,y:1079,t:1528143642660};\\\", \\\"{x:1917,y:1079,t:1528143642676};\\\", \\\"{x:1907,y:1079,t:1528143642692};\\\", \\\"{x:1887,y:1074,t:1528143642710};\\\", \\\"{x:1870,y:1068,t:1528143642726};\\\", \\\"{x:1858,y:1062,t:1528143642742};\\\", \\\"{x:1850,y:1057,t:1528143642759};\\\", \\\"{x:1843,y:1055,t:1528143642776};\\\", \\\"{x:1835,y:1051,t:1528143642792};\\\", \\\"{x:1821,y:1046,t:1528143642809};\\\", \\\"{x:1803,y:1036,t:1528143642826};\\\", \\\"{x:1784,y:1027,t:1528143642842};\\\", \\\"{x:1769,y:1018,t:1528143642859};\\\", \\\"{x:1753,y:1009,t:1528143642875};\\\", \\\"{x:1737,y:1003,t:1528143642891};\\\", \\\"{x:1717,y:992,t:1528143642909};\\\", \\\"{x:1709,y:989,t:1528143642925};\\\", \\\"{x:1705,y:987,t:1528143642942};\\\", \\\"{x:1699,y:984,t:1528143642959};\\\", \\\"{x:1694,y:981,t:1528143642976};\\\", \\\"{x:1690,y:980,t:1528143642992};\\\", \\\"{x:1687,y:977,t:1528143643009};\\\", \\\"{x:1683,y:977,t:1528143643026};\\\", \\\"{x:1677,y:974,t:1528143643042};\\\", \\\"{x:1669,y:973,t:1528143643059};\\\", \\\"{x:1656,y:972,t:1528143643077};\\\", \\\"{x:1642,y:969,t:1528143643092};\\\", \\\"{x:1624,y:966,t:1528143643109};\\\", \\\"{x:1586,y:960,t:1528143643126};\\\", \\\"{x:1538,y:948,t:1528143643142};\\\", \\\"{x:1499,y:943,t:1528143643159};\\\", \\\"{x:1463,y:940,t:1528143643176};\\\", \\\"{x:1438,y:935,t:1528143643193};\\\", \\\"{x:1423,y:934,t:1528143643209};\\\", \\\"{x:1412,y:931,t:1528143643226};\\\", \\\"{x:1409,y:930,t:1528143643244};\\\", \\\"{x:1404,y:927,t:1528143643260};\\\", \\\"{x:1400,y:923,t:1528143643277};\\\", \\\"{x:1395,y:918,t:1528143643293};\\\", \\\"{x:1391,y:907,t:1528143643310};\\\", \\\"{x:1387,y:884,t:1528143643327};\\\", \\\"{x:1384,y:863,t:1528143643344};\\\", \\\"{x:1381,y:852,t:1528143643359};\\\", \\\"{x:1381,y:853,t:1528143644334};\\\", \\\"{x:1381,y:854,t:1528143644358};\\\", \\\"{x:1381,y:855,t:1528143644382};\\\", \\\"{x:1383,y:857,t:1528143644397};\\\", \\\"{x:1384,y:859,t:1528143644410};\\\", \\\"{x:1388,y:863,t:1528143644427};\\\", \\\"{x:1391,y:866,t:1528143644443};\\\", \\\"{x:1394,y:870,t:1528143644461};\\\", \\\"{x:1395,y:873,t:1528143644478};\\\", \\\"{x:1396,y:874,t:1528143644495};\\\", \\\"{x:1398,y:876,t:1528143644517};\\\", \\\"{x:1401,y:878,t:1528143644527};\\\", \\\"{x:1409,y:883,t:1528143644544};\\\", \\\"{x:1421,y:886,t:1528143644561};\\\", \\\"{x:1435,y:893,t:1528143644578};\\\", \\\"{x:1452,y:902,t:1528143644593};\\\", \\\"{x:1471,y:913,t:1528143644611};\\\", \\\"{x:1489,y:921,t:1528143644627};\\\", \\\"{x:1510,y:930,t:1528143644644};\\\", \\\"{x:1538,y:942,t:1528143644661};\\\", \\\"{x:1579,y:960,t:1528143644677};\\\", \\\"{x:1609,y:973,t:1528143644694};\\\", \\\"{x:1634,y:983,t:1528143644710};\\\", \\\"{x:1650,y:989,t:1528143644727};\\\", \\\"{x:1663,y:992,t:1528143644744};\\\", \\\"{x:1667,y:994,t:1528143644761};\\\", \\\"{x:1669,y:994,t:1528143644777};\\\", \\\"{x:1670,y:994,t:1528143644798};\\\", \\\"{x:1670,y:992,t:1528143644910};\\\", \\\"{x:1670,y:990,t:1528143644928};\\\", \\\"{x:1670,y:987,t:1528143644945};\\\", \\\"{x:1670,y:984,t:1528143644961};\\\", \\\"{x:1670,y:981,t:1528143644977};\\\", \\\"{x:1670,y:978,t:1528143644994};\\\", \\\"{x:1670,y:975,t:1528143645012};\\\", \\\"{x:1670,y:974,t:1528143645027};\\\", \\\"{x:1670,y:972,t:1528143645044};\\\", \\\"{x:1670,y:970,t:1528143645061};\\\", \\\"{x:1668,y:968,t:1528143645078};\\\", \\\"{x:1664,y:965,t:1528143645094};\\\", \\\"{x:1659,y:963,t:1528143645112};\\\", \\\"{x:1655,y:960,t:1528143645127};\\\", \\\"{x:1653,y:960,t:1528143645145};\\\", \\\"{x:1652,y:959,t:1528143645161};\\\", \\\"{x:1650,y:959,t:1528143645230};\\\", \\\"{x:1648,y:959,t:1528143645244};\\\", \\\"{x:1629,y:959,t:1528143645262};\\\", \\\"{x:1601,y:959,t:1528143645277};\\\", \\\"{x:1540,y:959,t:1528143645294};\\\", \\\"{x:1462,y:959,t:1528143645311};\\\", \\\"{x:1376,y:959,t:1528143645328};\\\", \\\"{x:1298,y:950,t:1528143645345};\\\", \\\"{x:1237,y:940,t:1528143645361};\\\", \\\"{x:1172,y:928,t:1528143645377};\\\", \\\"{x:1105,y:911,t:1528143645394};\\\", \\\"{x:1067,y:895,t:1528143645412};\\\", \\\"{x:1039,y:878,t:1528143645428};\\\", \\\"{x:1030,y:867,t:1528143645445};\\\", \\\"{x:1021,y:847,t:1528143645461};\\\", \\\"{x:1019,y:833,t:1528143645478};\\\", \\\"{x:1019,y:823,t:1528143645495};\\\", \\\"{x:1021,y:813,t:1528143645511};\\\", \\\"{x:1030,y:799,t:1528143645528};\\\", \\\"{x:1039,y:787,t:1528143645544};\\\", \\\"{x:1048,y:777,t:1528143645561};\\\", \\\"{x:1059,y:766,t:1528143645577};\\\", \\\"{x:1071,y:758,t:1528143645594};\\\", \\\"{x:1083,y:751,t:1528143645611};\\\", \\\"{x:1096,y:745,t:1528143645628};\\\", \\\"{x:1104,y:740,t:1528143645644};\\\", \\\"{x:1105,y:738,t:1528143645661};\\\", \\\"{x:1105,y:736,t:1528143646446};\\\", \\\"{x:1105,y:735,t:1528143646462};\\\", \\\"{x:1105,y:734,t:1528143646758};\\\", \\\"{x:1103,y:734,t:1528143647014};\\\", \\\"{x:1105,y:734,t:1528143647158};\\\", \\\"{x:1107,y:734,t:1528143647166};\\\", \\\"{x:1109,y:734,t:1528143647180};\\\", \\\"{x:1117,y:736,t:1528143647196};\\\", \\\"{x:1128,y:740,t:1528143647212};\\\", \\\"{x:1163,y:751,t:1528143647229};\\\", \\\"{x:1192,y:762,t:1528143647246};\\\", \\\"{x:1228,y:777,t:1528143647262};\\\", \\\"{x:1255,y:788,t:1528143647279};\\\", \\\"{x:1279,y:797,t:1528143647296};\\\", \\\"{x:1295,y:806,t:1528143647313};\\\", \\\"{x:1311,y:811,t:1528143647329};\\\", \\\"{x:1320,y:815,t:1528143647346};\\\", \\\"{x:1328,y:820,t:1528143647363};\\\", \\\"{x:1333,y:822,t:1528143647379};\\\", \\\"{x:1340,y:825,t:1528143647397};\\\", \\\"{x:1345,y:828,t:1528143647412};\\\", \\\"{x:1347,y:828,t:1528143647430};\\\", \\\"{x:1348,y:828,t:1528143647446};\\\", \\\"{x:1345,y:829,t:1528143647654};\\\", \\\"{x:1340,y:829,t:1528143647663};\\\", \\\"{x:1327,y:829,t:1528143647680};\\\", \\\"{x:1310,y:832,t:1528143647697};\\\", \\\"{x:1293,y:833,t:1528143647713};\\\", \\\"{x:1286,y:835,t:1528143647729};\\\", \\\"{x:1282,y:837,t:1528143647746};\\\", \\\"{x:1281,y:837,t:1528143647762};\\\", \\\"{x:1281,y:838,t:1528143647926};\\\", \\\"{x:1281,y:839,t:1528143647941};\\\", \\\"{x:1281,y:840,t:1528143647958};\\\", \\\"{x:1281,y:841,t:1528143647990};\\\", \\\"{x:1281,y:842,t:1528143648014};\\\", \\\"{x:1281,y:843,t:1528143648158};\\\", \\\"{x:1280,y:844,t:1528143648238};\\\", \\\"{x:1279,y:844,t:1528143648262};\\\", \\\"{x:1277,y:844,t:1528143648294};\\\", \\\"{x:1276,y:844,t:1528143648310};\\\", \\\"{x:1275,y:845,t:1528143648318};\\\", \\\"{x:1274,y:845,t:1528143648331};\\\", \\\"{x:1273,y:845,t:1528143648347};\\\", \\\"{x:1270,y:845,t:1528143648364};\\\", \\\"{x:1267,y:845,t:1528143648380};\\\", \\\"{x:1266,y:845,t:1528143648397};\\\", \\\"{x:1265,y:845,t:1528143648414};\\\", \\\"{x:1264,y:845,t:1528143648431};\\\", \\\"{x:1263,y:845,t:1528143648687};\\\", \\\"{x:1261,y:845,t:1528143648718};\\\", \\\"{x:1260,y:844,t:1528143648742};\\\", \\\"{x:1259,y:843,t:1528143648749};\\\", \\\"{x:1258,y:843,t:1528143648773};\\\", \\\"{x:1258,y:842,t:1528143648822};\\\", \\\"{x:1257,y:841,t:1528143648838};\\\", \\\"{x:1257,y:840,t:1528143648902};\\\", \\\"{x:1256,y:840,t:1528143648998};\\\", \\\"{x:1255,y:840,t:1528143649038};\\\", \\\"{x:1254,y:840,t:1528143649190};\\\", \\\"{x:1253,y:840,t:1528143649222};\\\", \\\"{x:1251,y:840,t:1528143649237};\\\", \\\"{x:1249,y:840,t:1528143649248};\\\", \\\"{x:1247,y:840,t:1528143649264};\\\", \\\"{x:1244,y:840,t:1528143649281};\\\", \\\"{x:1241,y:840,t:1528143649297};\\\", \\\"{x:1240,y:839,t:1528143649390};\\\", \\\"{x:1238,y:839,t:1528143651390};\\\", \\\"{x:1234,y:839,t:1528143651399};\\\", \\\"{x:1221,y:836,t:1528143651416};\\\", \\\"{x:1203,y:833,t:1528143651432};\\\", \\\"{x:1186,y:828,t:1528143651449};\\\", \\\"{x:1172,y:823,t:1528143651465};\\\", \\\"{x:1165,y:821,t:1528143651483};\\\", \\\"{x:1161,y:819,t:1528143651499};\\\", \\\"{x:1160,y:819,t:1528143651515};\\\", \\\"{x:1159,y:819,t:1528143651533};\\\", \\\"{x:1158,y:819,t:1528143651645};\\\", \\\"{x:1157,y:819,t:1528143651710};\\\", \\\"{x:1156,y:819,t:1528143651717};\\\", \\\"{x:1155,y:819,t:1528143651732};\\\", \\\"{x:1153,y:820,t:1528143651750};\\\", \\\"{x:1151,y:821,t:1528143651765};\\\", \\\"{x:1151,y:823,t:1528143651782};\\\", \\\"{x:1149,y:824,t:1528143651800};\\\", \\\"{x:1149,y:826,t:1528143651926};\\\", \\\"{x:1148,y:827,t:1528143651934};\\\", \\\"{x:1147,y:827,t:1528143652054};\\\", \\\"{x:1147,y:826,t:1528143652085};\\\", \\\"{x:1147,y:824,t:1528143652100};\\\", \\\"{x:1148,y:823,t:1528143652117};\\\", \\\"{x:1149,y:820,t:1528143652133};\\\", \\\"{x:1152,y:817,t:1528143652150};\\\", \\\"{x:1155,y:815,t:1528143652167};\\\", \\\"{x:1156,y:813,t:1528143652183};\\\", \\\"{x:1157,y:813,t:1528143652200};\\\", \\\"{x:1158,y:812,t:1528143652217};\\\", \\\"{x:1160,y:810,t:1528143652233};\\\", \\\"{x:1161,y:810,t:1528143652249};\\\", \\\"{x:1164,y:809,t:1528143652267};\\\", \\\"{x:1167,y:807,t:1528143652283};\\\", \\\"{x:1169,y:806,t:1528143652300};\\\", \\\"{x:1173,y:806,t:1528143652316};\\\", \\\"{x:1176,y:803,t:1528143652333};\\\", \\\"{x:1181,y:798,t:1528143652350};\\\", \\\"{x:1181,y:796,t:1528143652366};\\\", \\\"{x:1182,y:794,t:1528143652383};\\\", \\\"{x:1183,y:793,t:1528143652400};\\\", \\\"{x:1184,y:791,t:1528143652416};\\\", \\\"{x:1184,y:790,t:1528143652433};\\\", \\\"{x:1185,y:788,t:1528143652450};\\\", \\\"{x:1185,y:787,t:1528143652467};\\\", \\\"{x:1185,y:786,t:1528143652483};\\\", \\\"{x:1185,y:784,t:1528143652500};\\\", \\\"{x:1185,y:783,t:1528143652550};\\\", \\\"{x:1185,y:782,t:1528143652670};\\\", \\\"{x:1184,y:781,t:1528143652693};\\\", \\\"{x:1183,y:780,t:1528143652782};\\\", \\\"{x:1182,y:780,t:1528143652998};\\\", \\\"{x:1181,y:780,t:1528143653982};\\\", \\\"{x:1181,y:779,t:1528143653990};\\\", \\\"{x:1181,y:778,t:1528143654001};\\\", \\\"{x:1182,y:777,t:1528143654017};\\\", \\\"{x:1182,y:776,t:1528143654037};\\\", \\\"{x:1183,y:775,t:1528143654051};\\\", \\\"{x:1185,y:774,t:1528143654190};\\\", \\\"{x:1185,y:772,t:1528143654214};\\\", \\\"{x:1186,y:771,t:1528143654246};\\\", \\\"{x:1187,y:770,t:1528143654294};\\\", \\\"{x:1188,y:769,t:1528143654301};\\\", \\\"{x:1189,y:766,t:1528143654317};\\\", \\\"{x:1190,y:764,t:1528143654335};\\\", \\\"{x:1191,y:764,t:1528143654351};\\\", \\\"{x:1192,y:762,t:1528143654368};\\\", \\\"{x:1194,y:760,t:1528143654385};\\\", \\\"{x:1194,y:758,t:1528143654401};\\\", \\\"{x:1195,y:757,t:1528143654418};\\\", \\\"{x:1195,y:756,t:1528143654435};\\\", \\\"{x:1195,y:755,t:1528143654450};\\\", \\\"{x:1196,y:755,t:1528143654469};\\\", \\\"{x:1197,y:754,t:1528143654485};\\\", \\\"{x:1197,y:753,t:1528143654518};\\\", \\\"{x:1198,y:752,t:1528143654549};\\\", \\\"{x:1198,y:751,t:1528143654558};\\\", \\\"{x:1199,y:750,t:1528143654573};\\\", \\\"{x:1200,y:749,t:1528143654585};\\\", \\\"{x:1200,y:748,t:1528143654601};\\\", \\\"{x:1201,y:747,t:1528143654618};\\\", \\\"{x:1202,y:746,t:1528143654670};\\\", \\\"{x:1203,y:745,t:1528143654685};\\\", \\\"{x:1203,y:744,t:1528143654709};\\\", \\\"{x:1202,y:744,t:1528143654846};\\\", \\\"{x:1199,y:746,t:1528143654854};\\\", \\\"{x:1196,y:748,t:1528143654868};\\\", \\\"{x:1192,y:751,t:1528143654885};\\\", \\\"{x:1187,y:754,t:1528143654901};\\\", \\\"{x:1184,y:757,t:1528143654918};\\\", \\\"{x:1181,y:759,t:1528143654938};\\\", \\\"{x:1180,y:762,t:1528143654951};\\\", \\\"{x:1178,y:764,t:1528143654968};\\\", \\\"{x:1176,y:767,t:1528143654985};\\\", \\\"{x:1174,y:771,t:1528143655001};\\\", \\\"{x:1171,y:775,t:1528143655018};\\\", \\\"{x:1169,y:779,t:1528143655034};\\\", \\\"{x:1167,y:781,t:1528143655051};\\\", \\\"{x:1167,y:783,t:1528143655069};\\\", \\\"{x:1167,y:784,t:1528143655293};\\\", \\\"{x:1167,y:783,t:1528143655309};\\\", \\\"{x:1168,y:780,t:1528143655318};\\\", \\\"{x:1170,y:776,t:1528143655334};\\\", \\\"{x:1173,y:773,t:1528143655351};\\\", \\\"{x:1175,y:770,t:1528143655368};\\\", \\\"{x:1176,y:768,t:1528143655384};\\\", \\\"{x:1177,y:766,t:1528143655402};\\\", \\\"{x:1178,y:766,t:1528143655418};\\\", \\\"{x:1179,y:764,t:1528143655434};\\\", \\\"{x:1179,y:763,t:1528143655451};\\\", \\\"{x:1180,y:761,t:1528143655468};\\\", \\\"{x:1180,y:760,t:1528143655485};\\\", \\\"{x:1181,y:759,t:1528143655501};\\\", \\\"{x:1182,y:759,t:1528143655518};\\\", \\\"{x:1182,y:757,t:1528143655535};\\\", \\\"{x:1183,y:756,t:1528143655551};\\\", \\\"{x:1184,y:754,t:1528143655573};\\\", \\\"{x:1185,y:754,t:1528143655598};\\\", \\\"{x:1185,y:753,t:1528143655613};\\\", \\\"{x:1186,y:753,t:1528143655621};\\\", \\\"{x:1186,y:751,t:1528143655669};\\\", \\\"{x:1186,y:750,t:1528143655766};\\\", \\\"{x:1186,y:749,t:1528143655918};\\\", \\\"{x:1186,y:748,t:1528143655936};\\\", \\\"{x:1185,y:748,t:1528143656206};\\\", \\\"{x:1184,y:748,t:1528143656278};\\\", \\\"{x:1184,y:749,t:1528143656286};\\\", \\\"{x:1183,y:750,t:1528143656382};\\\", \\\"{x:1183,y:751,t:1528143656502};\\\", \\\"{x:1182,y:753,t:1528143656519};\\\", \\\"{x:1181,y:753,t:1528143656536};\\\", \\\"{x:1181,y:754,t:1528143656553};\\\", \\\"{x:1180,y:755,t:1528143656570};\\\", \\\"{x:1180,y:757,t:1528143656586};\\\", \\\"{x:1179,y:757,t:1528143656603};\\\", \\\"{x:1177,y:760,t:1528143656620};\\\", \\\"{x:1177,y:762,t:1528143656653};\\\", \\\"{x:1176,y:764,t:1528143656670};\\\", \\\"{x:1176,y:765,t:1528143656685};\\\", \\\"{x:1174,y:767,t:1528143656704};\\\", \\\"{x:1173,y:769,t:1528143656720};\\\", \\\"{x:1173,y:770,t:1528143656736};\\\", \\\"{x:1172,y:770,t:1528143656753};\\\", \\\"{x:1171,y:772,t:1528143656781};\\\", \\\"{x:1172,y:772,t:1528143657214};\\\", \\\"{x:1173,y:772,t:1528143657229};\\\", \\\"{x:1174,y:771,t:1528143657253};\\\", \\\"{x:1176,y:771,t:1528143657292};\\\", \\\"{x:1177,y:771,t:1528143657325};\\\", \\\"{x:1179,y:771,t:1528143657357};\\\", \\\"{x:1180,y:771,t:1528143657421};\\\", \\\"{x:1181,y:771,t:1528143657446};\\\", \\\"{x:1182,y:772,t:1528143657454};\\\", \\\"{x:1183,y:774,t:1528143657470};\\\", \\\"{x:1186,y:777,t:1528143657487};\\\", \\\"{x:1193,y:780,t:1528143657504};\\\", \\\"{x:1198,y:783,t:1528143657519};\\\", \\\"{x:1203,y:787,t:1528143657536};\\\", \\\"{x:1211,y:789,t:1528143657553};\\\", \\\"{x:1214,y:791,t:1528143657569};\\\", \\\"{x:1217,y:792,t:1528143657586};\\\", \\\"{x:1220,y:794,t:1528143657603};\\\", \\\"{x:1222,y:796,t:1528143657619};\\\", \\\"{x:1225,y:799,t:1528143657636};\\\", \\\"{x:1234,y:804,t:1528143657653};\\\", \\\"{x:1238,y:807,t:1528143657669};\\\", \\\"{x:1244,y:810,t:1528143657687};\\\", \\\"{x:1248,y:812,t:1528143657704};\\\", \\\"{x:1252,y:815,t:1528143657719};\\\", \\\"{x:1255,y:817,t:1528143657737};\\\", \\\"{x:1261,y:821,t:1528143657753};\\\", \\\"{x:1265,y:825,t:1528143657770};\\\", \\\"{x:1269,y:829,t:1528143657787};\\\", \\\"{x:1273,y:834,t:1528143657804};\\\", \\\"{x:1276,y:839,t:1528143657820};\\\", \\\"{x:1280,y:844,t:1528143657837};\\\", \\\"{x:1284,y:853,t:1528143657853};\\\", \\\"{x:1288,y:859,t:1528143657870};\\\", \\\"{x:1292,y:866,t:1528143657886};\\\", \\\"{x:1294,y:872,t:1528143657903};\\\", \\\"{x:1297,y:876,t:1528143657921};\\\", \\\"{x:1300,y:881,t:1528143657936};\\\", \\\"{x:1301,y:882,t:1528143657954};\\\", \\\"{x:1303,y:885,t:1528143657971};\\\", \\\"{x:1305,y:887,t:1528143657986};\\\", \\\"{x:1305,y:888,t:1528143658003};\\\", \\\"{x:1307,y:891,t:1528143658020};\\\", \\\"{x:1308,y:891,t:1528143658053};\\\", \\\"{x:1309,y:892,t:1528143658262};\\\", \\\"{x:1310,y:892,t:1528143658271};\\\", \\\"{x:1311,y:892,t:1528143658287};\\\", \\\"{x:1312,y:892,t:1528143658304};\\\", \\\"{x:1313,y:892,t:1528143658334};\\\", \\\"{x:1314,y:892,t:1528143658342};\\\", \\\"{x:1316,y:891,t:1528143658354};\\\", \\\"{x:1318,y:890,t:1528143658374};\\\", \\\"{x:1320,y:889,t:1528143658389};\\\", \\\"{x:1321,y:889,t:1528143658413};\\\", \\\"{x:1322,y:889,t:1528143658421};\\\", \\\"{x:1323,y:888,t:1528143658470};\\\", \\\"{x:1324,y:887,t:1528143658488};\\\", \\\"{x:1325,y:887,t:1528143658504};\\\", \\\"{x:1326,y:887,t:1528143658521};\\\", \\\"{x:1327,y:886,t:1528143658538};\\\", \\\"{x:1328,y:886,t:1528143658554};\\\", \\\"{x:1329,y:885,t:1528143658597};\\\", \\\"{x:1329,y:884,t:1528143658670};\\\", \\\"{x:1329,y:883,t:1528143658688};\\\", \\\"{x:1329,y:881,t:1528143658704};\\\", \\\"{x:1329,y:879,t:1528143658721};\\\", \\\"{x:1329,y:878,t:1528143658738};\\\", \\\"{x:1329,y:877,t:1528143658754};\\\", \\\"{x:1330,y:876,t:1528143659069};\\\", \\\"{x:1331,y:876,t:1528143659566};\\\", \\\"{x:1329,y:876,t:1528143660509};\\\", \\\"{x:1326,y:876,t:1528143660522};\\\", \\\"{x:1313,y:880,t:1528143660539};\\\", \\\"{x:1302,y:881,t:1528143660556};\\\", \\\"{x:1291,y:883,t:1528143660572};\\\", \\\"{x:1280,y:885,t:1528143660590};\\\", \\\"{x:1274,y:885,t:1528143660606};\\\", \\\"{x:1271,y:885,t:1528143660623};\\\", \\\"{x:1267,y:888,t:1528143660639};\\\", \\\"{x:1266,y:888,t:1528143660656};\\\", \\\"{x:1265,y:889,t:1528143660672};\\\", \\\"{x:1264,y:889,t:1528143660689};\\\", \\\"{x:1262,y:891,t:1528143660706};\\\", \\\"{x:1256,y:892,t:1528143660722};\\\", \\\"{x:1252,y:894,t:1528143660738};\\\", \\\"{x:1248,y:896,t:1528143660755};\\\", \\\"{x:1243,y:899,t:1528143660772};\\\", \\\"{x:1239,y:901,t:1528143660789};\\\", \\\"{x:1237,y:903,t:1528143660805};\\\", \\\"{x:1236,y:905,t:1528143660822};\\\", \\\"{x:1234,y:907,t:1528143660838};\\\", \\\"{x:1233,y:908,t:1528143660855};\\\", \\\"{x:1232,y:910,t:1528143660872};\\\", \\\"{x:1232,y:912,t:1528143660888};\\\", \\\"{x:1231,y:913,t:1528143660905};\\\", \\\"{x:1231,y:915,t:1528143660923};\\\", \\\"{x:1228,y:919,t:1528143660939};\\\", \\\"{x:1225,y:924,t:1528143660956};\\\", \\\"{x:1220,y:932,t:1528143660973};\\\", \\\"{x:1216,y:937,t:1528143660989};\\\", \\\"{x:1213,y:942,t:1528143661006};\\\", \\\"{x:1210,y:945,t:1528143661023};\\\", \\\"{x:1207,y:949,t:1528143661039};\\\", \\\"{x:1206,y:951,t:1528143661056};\\\", \\\"{x:1206,y:953,t:1528143661073};\\\", \\\"{x:1205,y:953,t:1528143661126};\\\", \\\"{x:1204,y:953,t:1528143661165};\\\", \\\"{x:1204,y:952,t:1528143661174};\\\", \\\"{x:1208,y:946,t:1528143661189};\\\", \\\"{x:1214,y:939,t:1528143661206};\\\", \\\"{x:1219,y:934,t:1528143661223};\\\", \\\"{x:1225,y:929,t:1528143661240};\\\", \\\"{x:1229,y:923,t:1528143661256};\\\", \\\"{x:1235,y:915,t:1528143661273};\\\", \\\"{x:1240,y:909,t:1528143661290};\\\", \\\"{x:1244,y:904,t:1528143661307};\\\", \\\"{x:1247,y:903,t:1528143661323};\\\", \\\"{x:1248,y:902,t:1528143661340};\\\", \\\"{x:1250,y:900,t:1528143661357};\\\", \\\"{x:1252,y:896,t:1528143661373};\\\", \\\"{x:1253,y:895,t:1528143661390};\\\", \\\"{x:1256,y:892,t:1528143661406};\\\", \\\"{x:1262,y:888,t:1528143661423};\\\", \\\"{x:1268,y:884,t:1528143661440};\\\", \\\"{x:1275,y:877,t:1528143661455};\\\", \\\"{x:1289,y:867,t:1528143661474};\\\", \\\"{x:1298,y:859,t:1528143661490};\\\", \\\"{x:1310,y:850,t:1528143661506};\\\", \\\"{x:1321,y:841,t:1528143661523};\\\", \\\"{x:1330,y:829,t:1528143661541};\\\", \\\"{x:1338,y:817,t:1528143661557};\\\", \\\"{x:1345,y:804,t:1528143661573};\\\", \\\"{x:1351,y:793,t:1528143661590};\\\", \\\"{x:1355,y:786,t:1528143661607};\\\", \\\"{x:1357,y:781,t:1528143661623};\\\", \\\"{x:1358,y:777,t:1528143661640};\\\", \\\"{x:1359,y:771,t:1528143661656};\\\", \\\"{x:1361,y:763,t:1528143661673};\\\", \\\"{x:1361,y:762,t:1528143661690};\\\", \\\"{x:1361,y:760,t:1528143661759};\\\", \\\"{x:1362,y:760,t:1528143661790};\\\", \\\"{x:1362,y:762,t:1528143661934};\\\", \\\"{x:1362,y:765,t:1528143661941};\\\", \\\"{x:1365,y:774,t:1528143661957};\\\", \\\"{x:1368,y:785,t:1528143661974};\\\", \\\"{x:1370,y:794,t:1528143661990};\\\", \\\"{x:1376,y:803,t:1528143662008};\\\", \\\"{x:1382,y:814,t:1528143662023};\\\", \\\"{x:1386,y:819,t:1528143662040};\\\", \\\"{x:1391,y:825,t:1528143662058};\\\", \\\"{x:1396,y:831,t:1528143662073};\\\", \\\"{x:1401,y:836,t:1528143662090};\\\", \\\"{x:1403,y:840,t:1528143662109};\\\", \\\"{x:1408,y:844,t:1528143662123};\\\", \\\"{x:1413,y:848,t:1528143662140};\\\", \\\"{x:1423,y:857,t:1528143662157};\\\", \\\"{x:1439,y:868,t:1528143662174};\\\", \\\"{x:1453,y:877,t:1528143662190};\\\", \\\"{x:1472,y:888,t:1528143662207};\\\", \\\"{x:1492,y:897,t:1528143662225};\\\", \\\"{x:1514,y:906,t:1528143662240};\\\", \\\"{x:1535,y:916,t:1528143662257};\\\", \\\"{x:1557,y:925,t:1528143662274};\\\", \\\"{x:1577,y:933,t:1528143662291};\\\", \\\"{x:1594,y:941,t:1528143662309};\\\", \\\"{x:1607,y:947,t:1528143662324};\\\", \\\"{x:1615,y:949,t:1528143662341};\\\", \\\"{x:1621,y:953,t:1528143662357};\\\", \\\"{x:1622,y:953,t:1528143662375};\\\", \\\"{x:1623,y:954,t:1528143662582};\\\", \\\"{x:1623,y:955,t:1528143662614};\\\", \\\"{x:1622,y:955,t:1528143662630};\\\", \\\"{x:1620,y:956,t:1528143662641};\\\", \\\"{x:1617,y:960,t:1528143662657};\\\", \\\"{x:1613,y:962,t:1528143662674};\\\", \\\"{x:1609,y:966,t:1528143662691};\\\", \\\"{x:1606,y:967,t:1528143662709};\\\", \\\"{x:1604,y:970,t:1528143662725};\\\", \\\"{x:1601,y:972,t:1528143662741};\\\", \\\"{x:1599,y:974,t:1528143662757};\\\", \\\"{x:1597,y:975,t:1528143662774};\\\", \\\"{x:1595,y:977,t:1528143662791};\\\", \\\"{x:1591,y:979,t:1528143662808};\\\", \\\"{x:1590,y:979,t:1528143662838};\\\", \\\"{x:1590,y:980,t:1528143662862};\\\", \\\"{x:1589,y:980,t:1528143662878};\\\", \\\"{x:1588,y:980,t:1528143662891};\\\", \\\"{x:1587,y:980,t:1528143662909};\\\", \\\"{x:1582,y:979,t:1528143662925};\\\", \\\"{x:1572,y:971,t:1528143662941};\\\", \\\"{x:1560,y:964,t:1528143662958};\\\", \\\"{x:1547,y:955,t:1528143662975};\\\", \\\"{x:1534,y:948,t:1528143662991};\\\", \\\"{x:1515,y:938,t:1528143663007};\\\", \\\"{x:1502,y:933,t:1528143663024};\\\", \\\"{x:1491,y:928,t:1528143663041};\\\", \\\"{x:1483,y:925,t:1528143663057};\\\", \\\"{x:1480,y:923,t:1528143663074};\\\", \\\"{x:1477,y:921,t:1528143663091};\\\", \\\"{x:1475,y:920,t:1528143663108};\\\", \\\"{x:1472,y:918,t:1528143663125};\\\", \\\"{x:1465,y:909,t:1528143663142};\\\", \\\"{x:1458,y:902,t:1528143663158};\\\", \\\"{x:1451,y:893,t:1528143663174};\\\", \\\"{x:1447,y:887,t:1528143663191};\\\", \\\"{x:1443,y:880,t:1528143663209};\\\", \\\"{x:1439,y:873,t:1528143663224};\\\", \\\"{x:1435,y:865,t:1528143663241};\\\", \\\"{x:1431,y:859,t:1528143663258};\\\", \\\"{x:1430,y:853,t:1528143663274};\\\", \\\"{x:1428,y:850,t:1528143663291};\\\", \\\"{x:1426,y:845,t:1528143663308};\\\", \\\"{x:1423,y:840,t:1528143663324};\\\", \\\"{x:1417,y:830,t:1528143663342};\\\", \\\"{x:1409,y:822,t:1528143663358};\\\", \\\"{x:1402,y:813,t:1528143663374};\\\", \\\"{x:1397,y:807,t:1528143663391};\\\", \\\"{x:1392,y:801,t:1528143663408};\\\", \\\"{x:1388,y:797,t:1528143663424};\\\", \\\"{x:1384,y:792,t:1528143663442};\\\", \\\"{x:1380,y:785,t:1528143663458};\\\", \\\"{x:1377,y:781,t:1528143663474};\\\", \\\"{x:1376,y:776,t:1528143663492};\\\", \\\"{x:1374,y:772,t:1528143663508};\\\", \\\"{x:1372,y:768,t:1528143663524};\\\", \\\"{x:1368,y:763,t:1528143663542};\\\", \\\"{x:1364,y:759,t:1528143663558};\\\", \\\"{x:1361,y:756,t:1528143663576};\\\", \\\"{x:1357,y:753,t:1528143663591};\\\", \\\"{x:1355,y:751,t:1528143663609};\\\", \\\"{x:1354,y:750,t:1528143663626};\\\", \\\"{x:1353,y:750,t:1528143663661};\\\", \\\"{x:1352,y:749,t:1528143663675};\\\", \\\"{x:1351,y:749,t:1528143663774};\\\", \\\"{x:1348,y:750,t:1528143663791};\\\", \\\"{x:1347,y:752,t:1528143663808};\\\", \\\"{x:1347,y:754,t:1528143663854};\\\", \\\"{x:1347,y:755,t:1528143663869};\\\", \\\"{x:1347,y:757,t:1528143663885};\\\", \\\"{x:1347,y:758,t:1528143664078};\\\", \\\"{x:1347,y:760,t:1528143664118};\\\", \\\"{x:1347,y:761,t:1528143664142};\\\", \\\"{x:1348,y:763,t:1528143664158};\\\", \\\"{x:1348,y:765,t:1528143664175};\\\", \\\"{x:1348,y:766,t:1528143664192};\\\", \\\"{x:1349,y:767,t:1528143664208};\\\", \\\"{x:1349,y:768,t:1528143664229};\\\", \\\"{x:1349,y:769,t:1528143664243};\\\", \\\"{x:1349,y:771,t:1528143664258};\\\", \\\"{x:1349,y:773,t:1528143664276};\\\", \\\"{x:1349,y:777,t:1528143664292};\\\", \\\"{x:1348,y:786,t:1528143664310};\\\", \\\"{x:1343,y:794,t:1528143664324};\\\", \\\"{x:1339,y:802,t:1528143664342};\\\", \\\"{x:1334,y:808,t:1528143664358};\\\", \\\"{x:1329,y:816,t:1528143664375};\\\", \\\"{x:1324,y:822,t:1528143664391};\\\", \\\"{x:1320,y:828,t:1528143664408};\\\", \\\"{x:1317,y:831,t:1528143664424};\\\", \\\"{x:1314,y:835,t:1528143664442};\\\", \\\"{x:1308,y:843,t:1528143664458};\\\", \\\"{x:1304,y:849,t:1528143664474};\\\", \\\"{x:1296,y:859,t:1528143664492};\\\", \\\"{x:1290,y:865,t:1528143664508};\\\", \\\"{x:1281,y:873,t:1528143664524};\\\", \\\"{x:1275,y:878,t:1528143664541};\\\", \\\"{x:1270,y:882,t:1528143664559};\\\", \\\"{x:1266,y:886,t:1528143664575};\\\", \\\"{x:1262,y:889,t:1528143664592};\\\", \\\"{x:1259,y:892,t:1528143664608};\\\", \\\"{x:1257,y:895,t:1528143664625};\\\", \\\"{x:1255,y:897,t:1528143664642};\\\", \\\"{x:1252,y:900,t:1528143664659};\\\", \\\"{x:1250,y:903,t:1528143664675};\\\", \\\"{x:1248,y:906,t:1528143664692};\\\", \\\"{x:1244,y:913,t:1528143664709};\\\", \\\"{x:1239,y:917,t:1528143664725};\\\", \\\"{x:1237,y:921,t:1528143664742};\\\", \\\"{x:1236,y:922,t:1528143664759};\\\", \\\"{x:1235,y:923,t:1528143664798};\\\", \\\"{x:1233,y:924,t:1528143664810};\\\", \\\"{x:1230,y:926,t:1528143664824};\\\", \\\"{x:1229,y:926,t:1528143664845};\\\", \\\"{x:1229,y:927,t:1528143664877};\\\", \\\"{x:1227,y:928,t:1528143664892};\\\", \\\"{x:1220,y:932,t:1528143664909};\\\", \\\"{x:1216,y:935,t:1528143664925};\\\", \\\"{x:1216,y:936,t:1528143664942};\\\", \\\"{x:1216,y:937,t:1528143664990};\\\", \\\"{x:1216,y:938,t:1528143665006};\\\", \\\"{x:1215,y:939,t:1528143665158};\\\", \\\"{x:1214,y:939,t:1528143665430};\\\", \\\"{x:1213,y:939,t:1528143665442};\\\", \\\"{x:1202,y:944,t:1528143665459};\\\", \\\"{x:1193,y:954,t:1528143665476};\\\", \\\"{x:1192,y:955,t:1528143665774};\\\", \\\"{x:1192,y:956,t:1528143665973};\\\", \\\"{x:1191,y:956,t:1528143665981};\\\", \\\"{x:1183,y:957,t:1528143665993};\\\", \\\"{x:1164,y:957,t:1528143666010};\\\", \\\"{x:1147,y:957,t:1528143666026};\\\", \\\"{x:1138,y:957,t:1528143666043};\\\", \\\"{x:1135,y:957,t:1528143666060};\\\", \\\"{x:1134,y:957,t:1528143666076};\\\", \\\"{x:1134,y:956,t:1528143666111};\\\", \\\"{x:1136,y:948,t:1528143666125};\\\", \\\"{x:1147,y:933,t:1528143666143};\\\", \\\"{x:1155,y:922,t:1528143666160};\\\", \\\"{x:1163,y:914,t:1528143666176};\\\", \\\"{x:1172,y:904,t:1528143666192};\\\", \\\"{x:1182,y:891,t:1528143666209};\\\", \\\"{x:1192,y:882,t:1528143666226};\\\", \\\"{x:1203,y:873,t:1528143666242};\\\", \\\"{x:1214,y:865,t:1528143666260};\\\", \\\"{x:1226,y:856,t:1528143666275};\\\", \\\"{x:1240,y:840,t:1528143666293};\\\", \\\"{x:1246,y:832,t:1528143666310};\\\", \\\"{x:1249,y:828,t:1528143666326};\\\", \\\"{x:1250,y:826,t:1528143666343};\\\", \\\"{x:1251,y:824,t:1528143666361};\\\", \\\"{x:1252,y:822,t:1528143666376};\\\", \\\"{x:1254,y:819,t:1528143666393};\\\", \\\"{x:1255,y:815,t:1528143666410};\\\", \\\"{x:1258,y:812,t:1528143666427};\\\", \\\"{x:1259,y:808,t:1528143666443};\\\", \\\"{x:1261,y:806,t:1528143666460};\\\", \\\"{x:1262,y:803,t:1528143666476};\\\", \\\"{x:1265,y:798,t:1528143666493};\\\", \\\"{x:1266,y:790,t:1528143666511};\\\", \\\"{x:1271,y:779,t:1528143666527};\\\", \\\"{x:1275,y:770,t:1528143666543};\\\", \\\"{x:1278,y:765,t:1528143666560};\\\", \\\"{x:1282,y:757,t:1528143666577};\\\", \\\"{x:1284,y:754,t:1528143666594};\\\", \\\"{x:1288,y:746,t:1528143666611};\\\", \\\"{x:1295,y:730,t:1528143666627};\\\", \\\"{x:1303,y:714,t:1528143666643};\\\", \\\"{x:1308,y:703,t:1528143666660};\\\", \\\"{x:1309,y:702,t:1528143666678};\\\", \\\"{x:1309,y:705,t:1528143666757};\\\", \\\"{x:1312,y:714,t:1528143666766};\\\", \\\"{x:1313,y:722,t:1528143666777};\\\", \\\"{x:1317,y:739,t:1528143666793};\\\", \\\"{x:1324,y:755,t:1528143666810};\\\", \\\"{x:1334,y:771,t:1528143666827};\\\", \\\"{x:1345,y:789,t:1528143666843};\\\", \\\"{x:1356,y:805,t:1528143666860};\\\", \\\"{x:1373,y:826,t:1528143666877};\\\", \\\"{x:1385,y:838,t:1528143666893};\\\", \\\"{x:1394,y:846,t:1528143666910};\\\", \\\"{x:1401,y:853,t:1528143666927};\\\", \\\"{x:1407,y:860,t:1528143666943};\\\", \\\"{x:1412,y:868,t:1528143666960};\\\", \\\"{x:1417,y:874,t:1528143666978};\\\", \\\"{x:1420,y:880,t:1528143666994};\\\", \\\"{x:1422,y:882,t:1528143667010};\\\", \\\"{x:1423,y:883,t:1528143667027};\\\", \\\"{x:1423,y:884,t:1528143667045};\\\", \\\"{x:1423,y:885,t:1528143667060};\\\", \\\"{x:1423,y:888,t:1528143667077};\\\", \\\"{x:1423,y:890,t:1528143667094};\\\", \\\"{x:1423,y:891,t:1528143667110};\\\", \\\"{x:1422,y:892,t:1528143667127};\\\", \\\"{x:1421,y:892,t:1528143667144};\\\", \\\"{x:1418,y:893,t:1528143667160};\\\", \\\"{x:1410,y:894,t:1528143667178};\\\", \\\"{x:1399,y:894,t:1528143667194};\\\", \\\"{x:1382,y:894,t:1528143667210};\\\", \\\"{x:1371,y:894,t:1528143667228};\\\", \\\"{x:1361,y:894,t:1528143667244};\\\", \\\"{x:1351,y:894,t:1528143667260};\\\", \\\"{x:1337,y:894,t:1528143667276};\\\", \\\"{x:1329,y:894,t:1528143667293};\\\", \\\"{x:1323,y:894,t:1528143667310};\\\", \\\"{x:1316,y:895,t:1528143667326};\\\", \\\"{x:1307,y:899,t:1528143667344};\\\", \\\"{x:1296,y:903,t:1528143667360};\\\", \\\"{x:1282,y:911,t:1528143667377};\\\", \\\"{x:1260,y:918,t:1528143667394};\\\", \\\"{x:1244,y:922,t:1528143667410};\\\", \\\"{x:1231,y:926,t:1528143667427};\\\", \\\"{x:1225,y:928,t:1528143667444};\\\", \\\"{x:1205,y:930,t:1528143667461};\\\", \\\"{x:1197,y:934,t:1528143667476};\\\", \\\"{x:1190,y:938,t:1528143667494};\\\", \\\"{x:1190,y:937,t:1528143667644};\\\", \\\"{x:1193,y:932,t:1528143667660};\\\", \\\"{x:1199,y:926,t:1528143667676};\\\", \\\"{x:1206,y:918,t:1528143667694};\\\", \\\"{x:1210,y:912,t:1528143667711};\\\", \\\"{x:1213,y:907,t:1528143667727};\\\", \\\"{x:1215,y:904,t:1528143667744};\\\", \\\"{x:1217,y:900,t:1528143667760};\\\", \\\"{x:1219,y:895,t:1528143667777};\\\", \\\"{x:1223,y:890,t:1528143667794};\\\", \\\"{x:1228,y:883,t:1528143667811};\\\", \\\"{x:1233,y:877,t:1528143667827};\\\", \\\"{x:1237,y:871,t:1528143667844};\\\", \\\"{x:1246,y:858,t:1528143667861};\\\", \\\"{x:1252,y:852,t:1528143667878};\\\", \\\"{x:1258,y:846,t:1528143667894};\\\", \\\"{x:1266,y:839,t:1528143667911};\\\", \\\"{x:1274,y:832,t:1528143667928};\\\", \\\"{x:1280,y:826,t:1528143667944};\\\", \\\"{x:1291,y:814,t:1528143667961};\\\", \\\"{x:1301,y:802,t:1528143667978};\\\", \\\"{x:1310,y:788,t:1528143667994};\\\", \\\"{x:1323,y:770,t:1528143668011};\\\", \\\"{x:1333,y:754,t:1528143668029};\\\", \\\"{x:1339,y:743,t:1528143668044};\\\", \\\"{x:1347,y:727,t:1528143668061};\\\", \\\"{x:1349,y:722,t:1528143668078};\\\", \\\"{x:1350,y:719,t:1528143668094};\\\", \\\"{x:1350,y:717,t:1528143668111};\\\", \\\"{x:1351,y:716,t:1528143668128};\\\", \\\"{x:1351,y:714,t:1528143668144};\\\", \\\"{x:1351,y:713,t:1528143668173};\\\", \\\"{x:1352,y:712,t:1528143668902};\\\", \\\"{x:1354,y:714,t:1528143668917};\\\", \\\"{x:1355,y:715,t:1528143668928};\\\", \\\"{x:1360,y:720,t:1528143668945};\\\", \\\"{x:1365,y:724,t:1528143668963};\\\", \\\"{x:1367,y:727,t:1528143668979};\\\", \\\"{x:1371,y:730,t:1528143668995};\\\", \\\"{x:1375,y:734,t:1528143669012};\\\", \\\"{x:1380,y:740,t:1528143669028};\\\", \\\"{x:1386,y:749,t:1528143669045};\\\", \\\"{x:1391,y:755,t:1528143669061};\\\", \\\"{x:1394,y:759,t:1528143669078};\\\", \\\"{x:1398,y:764,t:1528143669095};\\\", \\\"{x:1403,y:770,t:1528143669112};\\\", \\\"{x:1410,y:781,t:1528143669129};\\\", \\\"{x:1418,y:794,t:1528143669146};\\\", \\\"{x:1426,y:809,t:1528143669162};\\\", \\\"{x:1435,y:824,t:1528143669179};\\\", \\\"{x:1443,y:840,t:1528143669196};\\\", \\\"{x:1452,y:856,t:1528143669213};\\\", \\\"{x:1457,y:866,t:1528143669229};\\\", \\\"{x:1460,y:872,t:1528143669245};\\\", \\\"{x:1461,y:876,t:1528143669262};\\\", \\\"{x:1463,y:881,t:1528143669279};\\\", \\\"{x:1463,y:886,t:1528143669296};\\\", \\\"{x:1466,y:891,t:1528143669312};\\\", \\\"{x:1466,y:892,t:1528143669330};\\\", \\\"{x:1466,y:893,t:1528143669349};\\\", \\\"{x:1466,y:894,t:1528143669534};\\\", \\\"{x:1466,y:895,t:1528143669546};\\\", \\\"{x:1466,y:896,t:1528143669566};\\\", \\\"{x:1466,y:897,t:1528143669622};\\\", \\\"{x:1466,y:898,t:1528143670054};\\\", \\\"{x:1466,y:897,t:1528143670109};\\\", \\\"{x:1466,y:896,t:1528143670126};\\\", \\\"{x:1466,y:895,t:1528143670133};\\\", \\\"{x:1465,y:895,t:1528143670147};\\\", \\\"{x:1465,y:894,t:1528143670162};\\\", \\\"{x:1464,y:892,t:1528143670182};\\\", \\\"{x:1463,y:891,t:1528143670196};\\\", \\\"{x:1463,y:889,t:1528143670213};\\\", \\\"{x:1461,y:886,t:1528143670229};\\\", \\\"{x:1458,y:881,t:1528143670246};\\\", \\\"{x:1456,y:879,t:1528143670263};\\\", \\\"{x:1455,y:876,t:1528143670278};\\\", \\\"{x:1453,y:874,t:1528143670296};\\\", \\\"{x:1452,y:873,t:1528143670313};\\\", \\\"{x:1451,y:872,t:1528143670329};\\\", \\\"{x:1450,y:870,t:1528143670346};\\\", \\\"{x:1449,y:869,t:1528143670363};\\\", \\\"{x:1448,y:868,t:1528143670379};\\\", \\\"{x:1447,y:867,t:1528143670396};\\\", \\\"{x:1446,y:867,t:1528143670492};\\\", \\\"{x:1446,y:866,t:1528143670508};\\\", \\\"{x:1446,y:865,t:1528143670524};\\\", \\\"{x:1445,y:864,t:1528143670565};\\\", \\\"{x:1444,y:863,t:1528143670604};\\\", \\\"{x:1444,y:862,t:1528143670830};\\\", \\\"{x:1443,y:861,t:1528143670846};\\\", \\\"{x:1442,y:860,t:1528143670864};\\\", \\\"{x:1441,y:860,t:1528143670880};\\\", \\\"{x:1437,y:859,t:1528143670896};\\\", \\\"{x:1435,y:858,t:1528143670916};\\\", \\\"{x:1434,y:858,t:1528143670981};\\\", \\\"{x:1433,y:858,t:1528143671012};\\\", \\\"{x:1432,y:858,t:1528143671030};\\\", \\\"{x:1431,y:857,t:1528143671046};\\\", \\\"{x:1430,y:856,t:1528143671064};\\\", \\\"{x:1428,y:856,t:1528143671080};\\\", \\\"{x:1426,y:855,t:1528143671097};\\\", \\\"{x:1422,y:853,t:1528143671113};\\\", \\\"{x:1416,y:851,t:1528143671130};\\\", \\\"{x:1406,y:848,t:1528143671147};\\\", \\\"{x:1394,y:845,t:1528143671163};\\\", \\\"{x:1380,y:838,t:1528143671180};\\\", \\\"{x:1365,y:832,t:1528143671196};\\\", \\\"{x:1346,y:824,t:1528143671214};\\\", \\\"{x:1336,y:820,t:1528143671230};\\\", \\\"{x:1326,y:815,t:1528143671247};\\\", \\\"{x:1314,y:810,t:1528143671263};\\\", \\\"{x:1304,y:805,t:1528143671280};\\\", \\\"{x:1293,y:800,t:1528143671297};\\\", \\\"{x:1283,y:796,t:1528143671314};\\\", \\\"{x:1272,y:792,t:1528143671330};\\\", \\\"{x:1263,y:791,t:1528143671348};\\\", \\\"{x:1255,y:788,t:1528143671363};\\\", \\\"{x:1246,y:786,t:1528143671381};\\\", \\\"{x:1235,y:783,t:1528143671397};\\\", \\\"{x:1228,y:782,t:1528143671413};\\\", \\\"{x:1221,y:780,t:1528143671431};\\\", \\\"{x:1215,y:779,t:1528143671447};\\\", \\\"{x:1211,y:779,t:1528143671463};\\\", \\\"{x:1209,y:779,t:1528143671481};\\\", \\\"{x:1205,y:778,t:1528143671497};\\\", \\\"{x:1201,y:778,t:1528143671514};\\\", \\\"{x:1195,y:776,t:1528143671531};\\\", \\\"{x:1190,y:776,t:1528143671548};\\\", \\\"{x:1186,y:776,t:1528143671564};\\\", \\\"{x:1184,y:775,t:1528143671581};\\\", \\\"{x:1183,y:775,t:1528143671597};\\\", \\\"{x:1186,y:775,t:1528143671694};\\\", \\\"{x:1189,y:775,t:1528143671701};\\\", \\\"{x:1193,y:775,t:1528143671713};\\\", \\\"{x:1204,y:775,t:1528143671730};\\\", \\\"{x:1216,y:775,t:1528143671747};\\\", \\\"{x:1227,y:775,t:1528143671764};\\\", \\\"{x:1236,y:775,t:1528143671780};\\\", \\\"{x:1247,y:775,t:1528143671797};\\\", \\\"{x:1255,y:775,t:1528143671814};\\\", \\\"{x:1262,y:775,t:1528143671830};\\\", \\\"{x:1270,y:775,t:1528143671847};\\\", \\\"{x:1277,y:775,t:1528143671864};\\\", \\\"{x:1284,y:775,t:1528143671881};\\\", \\\"{x:1289,y:775,t:1528143671898};\\\", \\\"{x:1293,y:775,t:1528143671914};\\\", \\\"{x:1295,y:774,t:1528143671930};\\\", \\\"{x:1298,y:774,t:1528143671947};\\\", \\\"{x:1304,y:773,t:1528143671965};\\\", \\\"{x:1310,y:772,t:1528143671981};\\\", \\\"{x:1329,y:772,t:1528143671998};\\\", \\\"{x:1340,y:772,t:1528143672015};\\\", \\\"{x:1353,y:772,t:1528143672031};\\\", \\\"{x:1363,y:772,t:1528143672048};\\\", \\\"{x:1370,y:772,t:1528143672065};\\\", \\\"{x:1375,y:772,t:1528143672080};\\\", \\\"{x:1378,y:772,t:1528143672097};\\\", \\\"{x:1380,y:771,t:1528143672114};\\\", \\\"{x:1382,y:771,t:1528143672574};\\\", \\\"{x:1383,y:771,t:1528143672589};\\\", \\\"{x:1385,y:771,t:1528143672734};\\\", \\\"{x:1387,y:771,t:1528143672749};\\\", \\\"{x:1394,y:771,t:1528143672764};\\\", \\\"{x:1406,y:771,t:1528143672781};\\\", \\\"{x:1413,y:771,t:1528143672799};\\\", \\\"{x:1414,y:771,t:1528143672814};\\\", \\\"{x:1416,y:770,t:1528143675854};\\\", \\\"{x:1417,y:768,t:1528143675870};\\\", \\\"{x:1417,y:767,t:1528143675884};\\\", \\\"{x:1417,y:765,t:1528143675900};\\\", \\\"{x:1418,y:760,t:1528143675918};\\\", \\\"{x:1420,y:758,t:1528143675934};\\\", \\\"{x:1420,y:756,t:1528143675951};\\\", \\\"{x:1421,y:755,t:1528143675967};\\\", \\\"{x:1421,y:753,t:1528143675984};\\\", \\\"{x:1422,y:751,t:1528143676001};\\\", \\\"{x:1422,y:750,t:1528143676018};\\\", \\\"{x:1422,y:749,t:1528143676034};\\\", \\\"{x:1422,y:748,t:1528143676051};\\\", \\\"{x:1423,y:747,t:1528143676068};\\\", \\\"{x:1418,y:756,t:1528143687846};\\\", \\\"{x:1411,y:765,t:1528143687859};\\\", \\\"{x:1390,y:782,t:1528143687876};\\\", \\\"{x:1363,y:799,t:1528143687893};\\\", \\\"{x:1337,y:813,t:1528143687909};\\\", \\\"{x:1325,y:820,t:1528143687926};\\\", \\\"{x:1315,y:828,t:1528143687943};\\\", \\\"{x:1309,y:835,t:1528143687959};\\\", \\\"{x:1306,y:838,t:1528143687976};\\\", \\\"{x:1304,y:844,t:1528143687992};\\\", \\\"{x:1301,y:847,t:1528143688009};\\\", \\\"{x:1299,y:851,t:1528143688026};\\\", \\\"{x:1295,y:856,t:1528143688043};\\\", \\\"{x:1293,y:857,t:1528143688060};\\\", \\\"{x:1288,y:861,t:1528143688077};\\\", \\\"{x:1279,y:867,t:1528143688093};\\\", \\\"{x:1273,y:872,t:1528143688109};\\\", \\\"{x:1268,y:874,t:1528143688127};\\\", \\\"{x:1259,y:875,t:1528143688144};\\\", \\\"{x:1257,y:876,t:1528143688159};\\\", \\\"{x:1256,y:876,t:1528143688176};\\\", \\\"{x:1255,y:877,t:1528143688197};\\\", \\\"{x:1253,y:877,t:1528143688246};\\\", \\\"{x:1250,y:875,t:1528143688259};\\\", \\\"{x:1245,y:870,t:1528143688276};\\\", \\\"{x:1239,y:858,t:1528143688294};\\\", \\\"{x:1232,y:846,t:1528143688309};\\\", \\\"{x:1227,y:836,t:1528143688327};\\\", \\\"{x:1221,y:830,t:1528143688344};\\\", \\\"{x:1218,y:827,t:1528143688360};\\\", \\\"{x:1214,y:823,t:1528143688377};\\\", \\\"{x:1207,y:819,t:1528143688394};\\\", \\\"{x:1196,y:815,t:1528143688409};\\\", \\\"{x:1177,y:807,t:1528143688426};\\\", \\\"{x:1150,y:796,t:1528143688443};\\\", \\\"{x:1118,y:788,t:1528143688460};\\\", \\\"{x:1087,y:779,t:1528143688476};\\\", \\\"{x:1043,y:765,t:1528143688493};\\\", \\\"{x:1020,y:759,t:1528143688511};\\\", \\\"{x:998,y:749,t:1528143688527};\\\", \\\"{x:984,y:740,t:1528143688543};\\\", \\\"{x:972,y:733,t:1528143688560};\\\", \\\"{x:960,y:726,t:1528143688576};\\\", \\\"{x:950,y:720,t:1528143688593};\\\", \\\"{x:939,y:713,t:1528143688610};\\\", \\\"{x:933,y:710,t:1528143688626};\\\", \\\"{x:928,y:708,t:1528143688643};\\\", \\\"{x:926,y:707,t:1528143688660};\\\", \\\"{x:926,y:706,t:1528143688709};\\\", \\\"{x:933,y:706,t:1528143688726};\\\", \\\"{x:947,y:705,t:1528143688743};\\\", \\\"{x:962,y:705,t:1528143688760};\\\", \\\"{x:979,y:705,t:1528143688776};\\\", \\\"{x:1000,y:705,t:1528143688794};\\\", \\\"{x:1025,y:705,t:1528143688810};\\\", \\\"{x:1047,y:705,t:1528143688827};\\\", \\\"{x:1067,y:705,t:1528143688844};\\\", \\\"{x:1083,y:705,t:1528143688860};\\\", \\\"{x:1100,y:705,t:1528143688877};\\\", \\\"{x:1107,y:705,t:1528143688893};\\\", \\\"{x:1115,y:705,t:1528143688910};\\\", \\\"{x:1123,y:705,t:1528143688928};\\\", \\\"{x:1139,y:705,t:1528143688944};\\\", \\\"{x:1162,y:705,t:1528143688960};\\\", \\\"{x:1190,y:705,t:1528143688977};\\\", \\\"{x:1218,y:705,t:1528143688993};\\\", \\\"{x:1248,y:705,t:1528143689010};\\\", \\\"{x:1285,y:708,t:1528143689027};\\\", \\\"{x:1331,y:717,t:1528143689043};\\\", \\\"{x:1376,y:724,t:1528143689061};\\\", \\\"{x:1422,y:738,t:1528143689077};\\\", \\\"{x:1435,y:745,t:1528143689093};\\\", \\\"{x:1440,y:748,t:1528143689111};\\\", \\\"{x:1442,y:751,t:1528143689127};\\\", \\\"{x:1442,y:754,t:1528143689144};\\\", \\\"{x:1442,y:757,t:1528143689160};\\\", \\\"{x:1442,y:761,t:1528143689177};\\\", \\\"{x:1442,y:763,t:1528143689193};\\\", \\\"{x:1442,y:767,t:1528143689211};\\\", \\\"{x:1442,y:775,t:1528143689227};\\\", \\\"{x:1442,y:778,t:1528143689243};\\\", \\\"{x:1442,y:783,t:1528143689261};\\\", \\\"{x:1441,y:787,t:1528143689277};\\\", \\\"{x:1440,y:789,t:1528143689293};\\\", \\\"{x:1437,y:792,t:1528143689311};\\\", \\\"{x:1432,y:794,t:1528143689328};\\\", \\\"{x:1420,y:797,t:1528143689343};\\\", \\\"{x:1400,y:802,t:1528143689361};\\\", \\\"{x:1376,y:802,t:1528143689377};\\\", \\\"{x:1350,y:802,t:1528143689394};\\\", \\\"{x:1332,y:802,t:1528143689411};\\\", \\\"{x:1318,y:802,t:1528143689427};\\\", \\\"{x:1311,y:802,t:1528143689445};\\\", \\\"{x:1307,y:801,t:1528143689461};\\\", \\\"{x:1306,y:800,t:1528143689485};\\\", \\\"{x:1306,y:799,t:1528143689493};\\\", \\\"{x:1306,y:798,t:1528143689510};\\\", \\\"{x:1305,y:796,t:1528143689527};\\\", \\\"{x:1305,y:794,t:1528143689544};\\\", \\\"{x:1301,y:791,t:1528143689559};\\\", \\\"{x:1295,y:788,t:1528143689576};\\\", \\\"{x:1286,y:786,t:1528143689594};\\\", \\\"{x:1271,y:783,t:1528143689610};\\\", \\\"{x:1253,y:782,t:1528143689626};\\\", \\\"{x:1228,y:777,t:1528143689644};\\\", \\\"{x:1199,y:775,t:1528143689660};\\\", \\\"{x:1175,y:775,t:1528143689676};\\\", \\\"{x:1173,y:775,t:1528143689694};\\\", \\\"{x:1172,y:775,t:1528143689709};\\\", \\\"{x:1173,y:775,t:1528143689781};\\\", \\\"{x:1176,y:775,t:1528143689797};\\\", \\\"{x:1178,y:775,t:1528143689810};\\\", \\\"{x:1185,y:775,t:1528143689827};\\\", \\\"{x:1189,y:775,t:1528143689844};\\\", \\\"{x:1191,y:775,t:1528143689861};\\\", \\\"{x:1193,y:775,t:1528143689877};\\\", \\\"{x:1194,y:775,t:1528143689894};\\\", \\\"{x:1196,y:775,t:1528143689910};\\\", \\\"{x:1199,y:775,t:1528143689927};\\\", \\\"{x:1202,y:775,t:1528143689944};\\\", \\\"{x:1204,y:774,t:1528143689961};\\\", \\\"{x:1207,y:773,t:1528143689977};\\\", \\\"{x:1209,y:772,t:1528143689994};\\\", \\\"{x:1214,y:770,t:1528143690011};\\\", \\\"{x:1220,y:769,t:1528143690027};\\\", \\\"{x:1228,y:766,t:1528143690044};\\\", \\\"{x:1242,y:764,t:1528143690061};\\\", \\\"{x:1249,y:764,t:1528143690077};\\\", \\\"{x:1258,y:762,t:1528143690094};\\\", \\\"{x:1264,y:761,t:1528143690112};\\\", \\\"{x:1271,y:761,t:1528143690127};\\\", \\\"{x:1283,y:761,t:1528143690144};\\\", \\\"{x:1298,y:761,t:1528143690161};\\\", \\\"{x:1315,y:761,t:1528143690177};\\\", \\\"{x:1330,y:761,t:1528143690194};\\\", \\\"{x:1340,y:761,t:1528143690211};\\\", \\\"{x:1347,y:761,t:1528143690227};\\\", \\\"{x:1350,y:761,t:1528143690244};\\\", \\\"{x:1354,y:761,t:1528143690262};\\\", \\\"{x:1355,y:761,t:1528143690277};\\\", \\\"{x:1356,y:761,t:1528143690294};\\\", \\\"{x:1358,y:761,t:1528143690311};\\\", \\\"{x:1362,y:761,t:1528143690327};\\\", \\\"{x:1368,y:761,t:1528143690344};\\\", \\\"{x:1373,y:761,t:1528143690361};\\\", \\\"{x:1378,y:761,t:1528143690378};\\\", \\\"{x:1382,y:761,t:1528143690395};\\\", \\\"{x:1386,y:761,t:1528143690412};\\\", \\\"{x:1390,y:761,t:1528143690428};\\\", \\\"{x:1397,y:761,t:1528143690444};\\\", \\\"{x:1404,y:761,t:1528143690460};\\\", \\\"{x:1406,y:761,t:1528143690477};\\\", \\\"{x:1404,y:761,t:1528143691005};\\\", \\\"{x:1401,y:761,t:1528143691013};\\\", \\\"{x:1393,y:761,t:1528143691029};\\\", \\\"{x:1386,y:761,t:1528143691044};\\\", \\\"{x:1379,y:761,t:1528143691061};\\\", \\\"{x:1370,y:761,t:1528143691078};\\\", \\\"{x:1365,y:761,t:1528143691095};\\\", \\\"{x:1361,y:761,t:1528143691112};\\\", \\\"{x:1358,y:761,t:1528143691128};\\\", \\\"{x:1357,y:761,t:1528143691145};\\\", \\\"{x:1356,y:761,t:1528143691161};\\\", \\\"{x:1355,y:761,t:1528143691805};\\\", \\\"{x:1354,y:761,t:1528143691829};\\\", \\\"{x:1353,y:761,t:1528143691845};\\\", \\\"{x:1351,y:761,t:1528143691862};\\\", \\\"{x:1349,y:761,t:1528143691879};\\\", \\\"{x:1348,y:761,t:1528143691895};\\\", \\\"{x:1347,y:761,t:1528143691912};\\\", \\\"{x:1346,y:761,t:1528143691933};\\\", \\\"{x:1345,y:761,t:1528143691949};\\\", \\\"{x:1344,y:761,t:1528143691989};\\\", \\\"{x:1334,y:760,t:1528143709747};\\\", \\\"{x:1296,y:750,t:1528143709756};\\\", \\\"{x:1193,y:732,t:1528143709772};\\\", \\\"{x:1112,y:721,t:1528143709789};\\\", \\\"{x:1046,y:706,t:1528143709805};\\\", \\\"{x:1011,y:695,t:1528143709822};\\\", \\\"{x:997,y:690,t:1528143709839};\\\", \\\"{x:995,y:689,t:1528143709855};\\\", \\\"{x:994,y:689,t:1528143709913};\\\", \\\"{x:993,y:689,t:1528143709923};\\\", \\\"{x:990,y:689,t:1528143709938};\\\", \\\"{x:986,y:689,t:1528143709956};\\\", \\\"{x:982,y:689,t:1528143709973};\\\", \\\"{x:975,y:689,t:1528143709989};\\\", \\\"{x:970,y:689,t:1528143710006};\\\", \\\"{x:963,y:689,t:1528143710022};\\\", \\\"{x:959,y:689,t:1528143710039};\\\", \\\"{x:955,y:689,t:1528143710056};\\\", \\\"{x:952,y:689,t:1528143710073};\\\", \\\"{x:951,y:689,t:1528143710089};\\\", \\\"{x:949,y:689,t:1528143710105};\\\", \\\"{x:948,y:689,t:1528143710250};\\\", \\\"{x:947,y:689,t:1528143710258};\\\", \\\"{x:946,y:689,t:1528143710273};\\\", \\\"{x:945,y:689,t:1528143710314};\\\", \\\"{x:943,y:689,t:1528143710323};\\\", \\\"{x:942,y:689,t:1528143710345};\\\", \\\"{x:941,y:689,t:1528143710361};\\\", \\\"{x:940,y:689,t:1528143710373};\\\", \\\"{x:939,y:689,t:1528143710466};\\\", \\\"{x:937,y:689,t:1528143710682};\\\", \\\"{x:936,y:689,t:1528143710697};\\\", \\\"{x:934,y:689,t:1528143710714};\\\", \\\"{x:933,y:689,t:1528143710746};\\\", \\\"{x:932,y:689,t:1528143710778};\\\", \\\"{x:931,y:689,t:1528143710790};\\\", \\\"{x:930,y:689,t:1528143710806};\\\", \\\"{x:928,y:689,t:1528143710823};\\\", \\\"{x:923,y:689,t:1528143710840};\\\", \\\"{x:916,y:689,t:1528143710857};\\\", \\\"{x:908,y:688,t:1528143710873};\\\", \\\"{x:900,y:686,t:1528143710890};\\\", \\\"{x:891,y:685,t:1528143710907};\\\", \\\"{x:882,y:682,t:1528143710923};\\\", \\\"{x:873,y:681,t:1528143710940};\\\", \\\"{x:866,y:680,t:1528143710957};\\\", \\\"{x:862,y:679,t:1528143710973};\\\", \\\"{x:856,y:678,t:1528143710990};\\\", \\\"{x:851,y:676,t:1528143711007};\\\", \\\"{x:843,y:673,t:1528143711023};\\\", \\\"{x:838,y:672,t:1528143711040};\\\", \\\"{x:833,y:670,t:1528143711057};\\\", \\\"{x:828,y:669,t:1528143711073};\\\", \\\"{x:819,y:666,t:1528143711089};\\\", \\\"{x:807,y:663,t:1528143711107};\\\", \\\"{x:795,y:660,t:1528143711123};\\\", \\\"{x:782,y:656,t:1528143711140};\\\", \\\"{x:772,y:653,t:1528143711157};\\\", \\\"{x:759,y:647,t:1528143711173};\\\", \\\"{x:746,y:641,t:1528143711190};\\\", \\\"{x:732,y:632,t:1528143711207};\\\", \\\"{x:720,y:623,t:1528143711225};\\\", \\\"{x:705,y:611,t:1528143711240};\\\", \\\"{x:689,y:594,t:1528143711257};\\\", \\\"{x:682,y:588,t:1528143711273};\\\", \\\"{x:662,y:567,t:1528143711289};\\\", \\\"{x:648,y:554,t:1528143711306};\\\", \\\"{x:636,y:543,t:1528143711323};\\\", \\\"{x:621,y:530,t:1528143711345};\\\", \\\"{x:607,y:518,t:1528143711361};\\\", \\\"{x:604,y:515,t:1528143711378};\\\", \\\"{x:603,y:513,t:1528143711395};\\\", \\\"{x:602,y:513,t:1528143711417};\\\", \\\"{x:602,y:512,t:1528143711441};\\\", \\\"{x:602,y:511,t:1528143711529};\\\", \\\"{x:602,y:510,t:1528143711553};\\\", \\\"{x:602,y:509,t:1528143711585};\\\", \\\"{x:599,y:511,t:1528143711825};\\\", \\\"{x:589,y:520,t:1528143711833};\\\", \\\"{x:577,y:531,t:1528143711845};\\\", \\\"{x:541,y:568,t:1528143711862};\\\", \\\"{x:506,y:605,t:1528143711882};\\\", \\\"{x:484,y:629,t:1528143711895};\\\", \\\"{x:463,y:651,t:1528143711912};\\\", \\\"{x:443,y:670,t:1528143711928};\\\", \\\"{x:425,y:689,t:1528143711944};\\\", \\\"{x:418,y:696,t:1528143711961};\\\", \\\"{x:415,y:703,t:1528143711978};\\\", \\\"{x:414,y:710,t:1528143711995};\\\", \\\"{x:413,y:714,t:1528143712012};\\\", \\\"{x:413,y:716,t:1528143712065};\\\", \\\"{x:413,y:717,t:1528143712105};\\\", \\\"{x:416,y:717,t:1528143712113};\\\", \\\"{x:420,y:717,t:1528143712128};\\\", \\\"{x:429,y:718,t:1528143712145};\\\", \\\"{x:435,y:718,t:1528143712161};\\\", \\\"{x:440,y:721,t:1528143712179};\\\", \\\"{x:447,y:723,t:1528143712197};\\\", \\\"{x:454,y:725,t:1528143712212};\\\", \\\"{x:460,y:726,t:1528143712229};\\\", \\\"{x:466,y:727,t:1528143712245};\\\", \\\"{x:467,y:727,t:1528143712261};\\\", \\\"{x:468,y:727,t:1528143712402};\\\", \\\"{x:471,y:728,t:1528143712412};\\\", \\\"{x:480,y:733,t:1528143712429};\\\", \\\"{x:490,y:735,t:1528143712446};\\\", \\\"{x:495,y:735,t:1528143712461};\\\", \\\"{x:497,y:735,t:1528143712479};\\\" ] }, { \\\"rt\\\": 8957, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 14, \\\"time_elapsed\\\": 810716, \\\"internal_node_id\\\": \\\"0.0-6.0-4.0\\\", \\\"subject\\\": \\\"K0CNH\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"ends\\\", \\\"q\\\": 10, \\\"clicks\\\": 1, \\\"explicit\\\": 2, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-5\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:500,y:734,t:1528143716219};\\\", \\\"{x:509,y:732,t:1528143716239};\\\", \\\"{x:517,y:729,t:1528143716251};\\\", \\\"{x:527,y:727,t:1528143716268};\\\", \\\"{x:537,y:725,t:1528143716283};\\\", \\\"{x:545,y:725,t:1528143716300};\\\", \\\"{x:557,y:725,t:1528143716318};\\\", \\\"{x:568,y:725,t:1528143716334};\\\", \\\"{x:579,y:725,t:1528143716351};\\\", \\\"{x:590,y:725,t:1528143716363};\\\", \\\"{x:605,y:725,t:1528143716380};\\\", \\\"{x:620,y:725,t:1528143716396};\\\", \\\"{x:637,y:725,t:1528143716413};\\\", \\\"{x:650,y:725,t:1528143716430};\\\", \\\"{x:660,y:725,t:1528143716447};\\\", \\\"{x:667,y:725,t:1528143716464};\\\", \\\"{x:676,y:725,t:1528143716482};\\\", \\\"{x:682,y:725,t:1528143716497};\\\", \\\"{x:688,y:725,t:1528143716514};\\\", \\\"{x:694,y:726,t:1528143716530};\\\", \\\"{x:703,y:726,t:1528143716547};\\\", \\\"{x:708,y:726,t:1528143716564};\\\", \\\"{x:716,y:728,t:1528143716580};\\\", \\\"{x:724,y:729,t:1528143716597};\\\", \\\"{x:732,y:729,t:1528143716615};\\\", \\\"{x:739,y:729,t:1528143716630};\\\", \\\"{x:746,y:729,t:1528143716647};\\\", \\\"{x:753,y:729,t:1528143716664};\\\", \\\"{x:764,y:729,t:1528143716681};\\\", \\\"{x:771,y:730,t:1528143716697};\\\", \\\"{x:779,y:730,t:1528143716713};\\\", \\\"{x:783,y:730,t:1528143716730};\\\", \\\"{x:786,y:732,t:1528143716747};\\\", \\\"{x:787,y:732,t:1528143716764};\\\", \\\"{x:788,y:732,t:1528143716890};\\\", \\\"{x:788,y:729,t:1528143716897};\\\", \\\"{x:788,y:722,t:1528143716914};\\\", \\\"{x:784,y:716,t:1528143716930};\\\", \\\"{x:776,y:702,t:1528143716948};\\\", \\\"{x:766,y:683,t:1528143716965};\\\", \\\"{x:758,y:670,t:1528143716980};\\\", \\\"{x:748,y:654,t:1528143716998};\\\", \\\"{x:739,y:637,t:1528143717014};\\\", \\\"{x:732,y:619,t:1528143717031};\\\", \\\"{x:725,y:603,t:1528143717047};\\\", \\\"{x:716,y:585,t:1528143717067};\\\", \\\"{x:713,y:576,t:1528143717083};\\\", \\\"{x:708,y:566,t:1528143717098};\\\", \\\"{x:705,y:559,t:1528143717116};\\\", \\\"{x:702,y:555,t:1528143717133};\\\", \\\"{x:698,y:550,t:1528143717148};\\\", \\\"{x:692,y:542,t:1528143717165};\\\", \\\"{x:687,y:533,t:1528143717183};\\\", \\\"{x:682,y:528,t:1528143717198};\\\", \\\"{x:682,y:527,t:1528143717216};\\\", \\\"{x:682,y:526,t:1528143717249};\\\", \\\"{x:685,y:526,t:1528143717266};\\\", \\\"{x:694,y:528,t:1528143717282};\\\", \\\"{x:710,y:536,t:1528143717299};\\\", \\\"{x:732,y:545,t:1528143717318};\\\", \\\"{x:761,y:557,t:1528143717333};\\\", \\\"{x:799,y:572,t:1528143717350};\\\", \\\"{x:849,y:587,t:1528143717366};\\\", \\\"{x:903,y:603,t:1528143717384};\\\", \\\"{x:948,y:610,t:1528143717398};\\\", \\\"{x:980,y:616,t:1528143717416};\\\", \\\"{x:1020,y:622,t:1528143717433};\\\", \\\"{x:1042,y:624,t:1528143717450};\\\", \\\"{x:1063,y:628,t:1528143717466};\\\", \\\"{x:1079,y:629,t:1528143717484};\\\", \\\"{x:1097,y:633,t:1528143717499};\\\", \\\"{x:1115,y:635,t:1528143717516};\\\", \\\"{x:1136,y:638,t:1528143717533};\\\", \\\"{x:1153,y:640,t:1528143717550};\\\", \\\"{x:1170,y:643,t:1528143717567};\\\", \\\"{x:1184,y:644,t:1528143717583};\\\", \\\"{x:1200,y:644,t:1528143717600};\\\", \\\"{x:1231,y:644,t:1528143717617};\\\", \\\"{x:1259,y:649,t:1528143717633};\\\", \\\"{x:1300,y:656,t:1528143717651};\\\", \\\"{x:1350,y:663,t:1528143717667};\\\", \\\"{x:1398,y:669,t:1528143717683};\\\", \\\"{x:1426,y:676,t:1528143717700};\\\", \\\"{x:1445,y:682,t:1528143717717};\\\", \\\"{x:1460,y:687,t:1528143717734};\\\", \\\"{x:1468,y:690,t:1528143717750};\\\", \\\"{x:1469,y:690,t:1528143717767};\\\", \\\"{x:1469,y:691,t:1528143717802};\\\", \\\"{x:1469,y:692,t:1528143717825};\\\", \\\"{x:1467,y:692,t:1528143717834};\\\", \\\"{x:1457,y:696,t:1528143717850};\\\", \\\"{x:1443,y:700,t:1528143717868};\\\", \\\"{x:1425,y:706,t:1528143717884};\\\", \\\"{x:1407,y:707,t:1528143717900};\\\", \\\"{x:1393,y:708,t:1528143717917};\\\", \\\"{x:1385,y:708,t:1528143717934};\\\", \\\"{x:1384,y:708,t:1528143717951};\\\", \\\"{x:1382,y:708,t:1528143717968};\\\", \\\"{x:1381,y:708,t:1528143717993};\\\", \\\"{x:1380,y:707,t:1528143718000};\\\", \\\"{x:1377,y:706,t:1528143718017};\\\", \\\"{x:1375,y:705,t:1528143718034};\\\", \\\"{x:1374,y:705,t:1528143718066};\\\", \\\"{x:1373,y:705,t:1528143718073};\\\", \\\"{x:1372,y:705,t:1528143718089};\\\", \\\"{x:1371,y:705,t:1528143718105};\\\", \\\"{x:1370,y:704,t:1528143718119};\\\", \\\"{x:1367,y:703,t:1528143718134};\\\", \\\"{x:1365,y:703,t:1528143718151};\\\", \\\"{x:1364,y:703,t:1528143718202};\\\", \\\"{x:1363,y:703,t:1528143718234};\\\", \\\"{x:1362,y:703,t:1528143718252};\\\", \\\"{x:1361,y:703,t:1528143718298};\\\", \\\"{x:1360,y:703,t:1528143718322};\\\", \\\"{x:1359,y:703,t:1528143718370};\\\", \\\"{x:1359,y:706,t:1528143718442};\\\", \\\"{x:1359,y:707,t:1528143718452};\\\", \\\"{x:1360,y:711,t:1528143718469};\\\", \\\"{x:1365,y:717,t:1528143718486};\\\", \\\"{x:1367,y:722,t:1528143718503};\\\", \\\"{x:1370,y:728,t:1528143718518};\\\", \\\"{x:1372,y:733,t:1528143718535};\\\", \\\"{x:1376,y:738,t:1528143718552};\\\", \\\"{x:1378,y:742,t:1528143718569};\\\", \\\"{x:1382,y:751,t:1528143718586};\\\", \\\"{x:1383,y:756,t:1528143718603};\\\", \\\"{x:1388,y:763,t:1528143718618};\\\", \\\"{x:1392,y:770,t:1528143718636};\\\", \\\"{x:1397,y:778,t:1528143718652};\\\", \\\"{x:1400,y:786,t:1528143718669};\\\", \\\"{x:1405,y:795,t:1528143718686};\\\", \\\"{x:1406,y:800,t:1528143718703};\\\", \\\"{x:1409,y:805,t:1528143718719};\\\", \\\"{x:1409,y:808,t:1528143718736};\\\", \\\"{x:1410,y:812,t:1528143718753};\\\", \\\"{x:1412,y:818,t:1528143718769};\\\", \\\"{x:1416,y:824,t:1528143718785};\\\", \\\"{x:1416,y:827,t:1528143718803};\\\", \\\"{x:1418,y:831,t:1528143718820};\\\", \\\"{x:1419,y:834,t:1528143718837};\\\", \\\"{x:1421,y:836,t:1528143718852};\\\", \\\"{x:1421,y:837,t:1528143718870};\\\", \\\"{x:1421,y:839,t:1528143718887};\\\", \\\"{x:1423,y:841,t:1528143718902};\\\", \\\"{x:1423,y:843,t:1528143718919};\\\", \\\"{x:1424,y:844,t:1528143718936};\\\", \\\"{x:1424,y:847,t:1528143718953};\\\", \\\"{x:1427,y:850,t:1528143718970};\\\", \\\"{x:1427,y:853,t:1528143718986};\\\", \\\"{x:1428,y:855,t:1528143719003};\\\", \\\"{x:1429,y:857,t:1528143719020};\\\", \\\"{x:1430,y:859,t:1528143719037};\\\", \\\"{x:1431,y:860,t:1528143719054};\\\", \\\"{x:1431,y:862,t:1528143719069};\\\", \\\"{x:1433,y:864,t:1528143719087};\\\", \\\"{x:1433,y:865,t:1528143719103};\\\", \\\"{x:1433,y:866,t:1528143719120};\\\", \\\"{x:1434,y:867,t:1528143719136};\\\", \\\"{x:1435,y:870,t:1528143719153};\\\", \\\"{x:1436,y:870,t:1528143719170};\\\", \\\"{x:1436,y:871,t:1528143719186};\\\", \\\"{x:1437,y:872,t:1528143719203};\\\", \\\"{x:1439,y:874,t:1528143719233};\\\", \\\"{x:1439,y:875,t:1528143719249};\\\", \\\"{x:1440,y:877,t:1528143719273};\\\", \\\"{x:1441,y:878,t:1528143719290};\\\", \\\"{x:1441,y:879,t:1528143719305};\\\", \\\"{x:1441,y:880,t:1528143719321};\\\", \\\"{x:1443,y:882,t:1528143719337};\\\", \\\"{x:1444,y:884,t:1528143719354};\\\", \\\"{x:1444,y:886,t:1528143719370};\\\", \\\"{x:1446,y:888,t:1528143719387};\\\", \\\"{x:1447,y:890,t:1528143719403};\\\", \\\"{x:1448,y:892,t:1528143719420};\\\", \\\"{x:1450,y:894,t:1528143719438};\\\", \\\"{x:1452,y:896,t:1528143719453};\\\", \\\"{x:1453,y:898,t:1528143719471};\\\", \\\"{x:1454,y:899,t:1528143719487};\\\", \\\"{x:1454,y:900,t:1528143719504};\\\", \\\"{x:1455,y:900,t:1528143719520};\\\", \\\"{x:1456,y:901,t:1528143719538};\\\", \\\"{x:1456,y:903,t:1528143719554};\\\", \\\"{x:1457,y:904,t:1528143719586};\\\", \\\"{x:1457,y:905,t:1528143719593};\\\", \\\"{x:1457,y:906,t:1528143719625};\\\", \\\"{x:1458,y:906,t:1528143719642};\\\", \\\"{x:1459,y:908,t:1528143719657};\\\", \\\"{x:1459,y:909,t:1528143719689};\\\", \\\"{x:1459,y:910,t:1528143719713};\\\", \\\"{x:1460,y:911,t:1528143719722};\\\", \\\"{x:1460,y:912,t:1528143719737};\\\", \\\"{x:1461,y:913,t:1528143719755};\\\", \\\"{x:1462,y:916,t:1528143719771};\\\", \\\"{x:1464,y:920,t:1528143719788};\\\", \\\"{x:1465,y:922,t:1528143719805};\\\", \\\"{x:1466,y:926,t:1528143719822};\\\", \\\"{x:1467,y:928,t:1528143719839};\\\", \\\"{x:1469,y:931,t:1528143719854};\\\", \\\"{x:1469,y:934,t:1528143719871};\\\", \\\"{x:1469,y:936,t:1528143719888};\\\", \\\"{x:1469,y:940,t:1528143719904};\\\", \\\"{x:1471,y:943,t:1528143719922};\\\", \\\"{x:1471,y:944,t:1528143719938};\\\", \\\"{x:1471,y:946,t:1528143719955};\\\", \\\"{x:1471,y:947,t:1528143719971};\\\", \\\"{x:1472,y:949,t:1528143719994};\\\", \\\"{x:1472,y:950,t:1528143720033};\\\", \\\"{x:1467,y:951,t:1528143721595};\\\", \\\"{x:1439,y:949,t:1528143721609};\\\", \\\"{x:1355,y:934,t:1528143721625};\\\", \\\"{x:1181,y:905,t:1528143721642};\\\", \\\"{x:1060,y:874,t:1528143721659};\\\", \\\"{x:952,y:843,t:1528143721675};\\\", \\\"{x:866,y:804,t:1528143721691};\\\", \\\"{x:797,y:761,t:1528143721708};\\\", \\\"{x:731,y:721,t:1528143721726};\\\", \\\"{x:682,y:692,t:1528143721741};\\\", \\\"{x:659,y:678,t:1528143721759};\\\", \\\"{x:651,y:673,t:1528143721775};\\\", \\\"{x:648,y:671,t:1528143721792};\\\", \\\"{x:648,y:669,t:1528143721809};\\\", \\\"{x:648,y:664,t:1528143721825};\\\", \\\"{x:647,y:660,t:1528143721842};\\\", \\\"{x:645,y:653,t:1528143721859};\\\", \\\"{x:644,y:649,t:1528143721875};\\\", \\\"{x:644,y:643,t:1528143721892};\\\", \\\"{x:640,y:635,t:1528143721908};\\\", \\\"{x:635,y:623,t:1528143721927};\\\", \\\"{x:631,y:610,t:1528143721941};\\\", \\\"{x:631,y:597,t:1528143721958};\\\", \\\"{x:631,y:588,t:1528143721976};\\\", \\\"{x:630,y:567,t:1528143721997};\\\", \\\"{x:628,y:559,t:1528143722014};\\\", \\\"{x:627,y:554,t:1528143722030};\\\", \\\"{x:625,y:552,t:1528143722052};\\\", \\\"{x:625,y:551,t:1528143722070};\\\", \\\"{x:624,y:549,t:1528143722086};\\\", \\\"{x:623,y:547,t:1528143722103};\\\", \\\"{x:623,y:545,t:1528143722120};\\\", \\\"{x:618,y:526,t:1528143722137};\\\", \\\"{x:616,y:517,t:1528143722154};\\\", \\\"{x:616,y:515,t:1528143722234};\\\", \\\"{x:616,y:514,t:1528143722242};\\\", \\\"{x:616,y:513,t:1528143722275};\\\", \\\"{x:616,y:512,t:1528143722592};\\\", \\\"{x:614,y:519,t:1528143722604};\\\", \\\"{x:612,y:538,t:1528143722620};\\\", \\\"{x:609,y:557,t:1528143722637};\\\", \\\"{x:606,y:576,t:1528143722655};\\\", \\\"{x:604,y:596,t:1528143722670};\\\", \\\"{x:601,y:614,t:1528143722688};\\\", \\\"{x:600,y:628,t:1528143722704};\\\", \\\"{x:600,y:638,t:1528143722720};\\\", \\\"{x:599,y:654,t:1528143722737};\\\", \\\"{x:596,y:663,t:1528143722754};\\\", \\\"{x:592,y:672,t:1528143722770};\\\", \\\"{x:588,y:684,t:1528143722787};\\\", \\\"{x:586,y:692,t:1528143722804};\\\", \\\"{x:583,y:702,t:1528143722820};\\\", \\\"{x:582,y:707,t:1528143722837};\\\", \\\"{x:580,y:709,t:1528143722854};\\\", \\\"{x:579,y:709,t:1528143722870};\\\", \\\"{x:579,y:710,t:1528143722906};\\\", \\\"{x:578,y:711,t:1528143722954};\\\", \\\"{x:577,y:711,t:1528143722971};\\\", \\\"{x:575,y:711,t:1528143722988};\\\", \\\"{x:573,y:711,t:1528143723005};\\\", \\\"{x:570,y:713,t:1528143723022};\\\", \\\"{x:566,y:718,t:1528143723038};\\\", \\\"{x:565,y:720,t:1528143723054};\\\", \\\"{x:563,y:721,t:1528143723071};\\\", \\\"{x:563,y:722,t:1528143723090};\\\", \\\"{x:562,y:723,t:1528143723139};\\\", \\\"{x:561,y:724,t:1528143723155};\\\", \\\"{x:561,y:725,t:1528143723265};\\\", \\\"{x:561,y:725,t:1528143723377};\\\", \\\"{x:561,y:726,t:1528143723432};\\\", \\\"{x:562,y:726,t:1528143723601};\\\", \\\"{x:572,y:726,t:1528143723610};\\\", \\\"{x:575,y:724,t:1528143723622};\\\", \\\"{x:591,y:712,t:1528143723638};\\\", \\\"{x:618,y:694,t:1528143723654};\\\", \\\"{x:658,y:674,t:1528143723671};\\\", \\\"{x:688,y:661,t:1528143723688};\\\", \\\"{x:717,y:654,t:1528143723704};\\\", \\\"{x:769,y:646,t:1528143723721};\\\", \\\"{x:798,y:643,t:1528143723738};\\\", \\\"{x:823,y:638,t:1528143723756};\\\", \\\"{x:842,y:636,t:1528143723772};\\\", \\\"{x:855,y:633,t:1528143723788};\\\", \\\"{x:860,y:631,t:1528143723806};\\\", \\\"{x:861,y:631,t:1528143724370};\\\" ] }, { \\\"rt\\\": 11901, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 15, \\\"time_elapsed\\\": 823836, \\\"internal_node_id\\\": \\\"0.0-6.0-5.0\\\", \\\"subject\\\": \\\"K0CNH\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 11, \\\"clicks\\\": 2.5, \\\"explicit\\\": 2, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"M\\\", \\\"L\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-11 AM-M -M -I \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:862,y:631,t:1528143724680};\\\", \\\"{x:863,y:631,t:1528143724697};\\\", \\\"{x:864,y:630,t:1528143725594};\\\", \\\"{x:864,y:629,t:1528143725609};\\\", \\\"{x:864,y:627,t:1528143725633};\\\", \\\"{x:864,y:626,t:1528143725666};\\\", \\\"{x:864,y:624,t:1528143725697};\\\", \\\"{x:864,y:623,t:1528143725713};\\\", \\\"{x:864,y:621,t:1528143725728};\\\", \\\"{x:864,y:620,t:1528143725739};\\\", \\\"{x:864,y:618,t:1528143725756};\\\", \\\"{x:864,y:616,t:1528143725773};\\\", \\\"{x:864,y:614,t:1528143725789};\\\", \\\"{x:865,y:610,t:1528143725806};\\\", \\\"{x:865,y:606,t:1528143725823};\\\", \\\"{x:867,y:602,t:1528143725839};\\\", \\\"{x:868,y:600,t:1528143725857};\\\", \\\"{x:870,y:595,t:1528143725872};\\\", \\\"{x:874,y:591,t:1528143725890};\\\", \\\"{x:882,y:584,t:1528143725906};\\\", \\\"{x:896,y:578,t:1528143725923};\\\", \\\"{x:915,y:570,t:1528143725941};\\\", \\\"{x:938,y:561,t:1528143725957};\\\", \\\"{x:968,y:554,t:1528143725974};\\\", \\\"{x:1003,y:543,t:1528143725992};\\\", \\\"{x:1039,y:532,t:1528143726006};\\\", \\\"{x:1081,y:521,t:1528143726024};\\\", \\\"{x:1131,y:507,t:1528143726041};\\\", \\\"{x:1177,y:498,t:1528143726057};\\\", \\\"{x:1222,y:491,t:1528143726073};\\\", \\\"{x:1249,y:487,t:1528143726091};\\\", \\\"{x:1277,y:484,t:1528143726107};\\\", \\\"{x:1298,y:480,t:1528143726123};\\\", \\\"{x:1323,y:476,t:1528143726140};\\\", \\\"{x:1350,y:476,t:1528143726156};\\\", \\\"{x:1378,y:476,t:1528143726174};\\\", \\\"{x:1405,y:476,t:1528143726191};\\\", \\\"{x:1426,y:476,t:1528143726208};\\\", \\\"{x:1445,y:478,t:1528143726224};\\\", \\\"{x:1463,y:482,t:1528143726240};\\\", \\\"{x:1485,y:487,t:1528143726257};\\\", \\\"{x:1494,y:489,t:1528143726274};\\\", \\\"{x:1498,y:491,t:1528143726290};\\\", \\\"{x:1503,y:492,t:1528143726308};\\\", \\\"{x:1506,y:495,t:1528143726324};\\\", \\\"{x:1511,y:499,t:1528143726341};\\\", \\\"{x:1519,y:508,t:1528143726358};\\\", \\\"{x:1528,y:521,t:1528143726373};\\\", \\\"{x:1537,y:540,t:1528143726391};\\\", \\\"{x:1544,y:557,t:1528143726408};\\\", \\\"{x:1551,y:575,t:1528143726425};\\\", \\\"{x:1556,y:589,t:1528143726441};\\\", \\\"{x:1561,y:609,t:1528143726457};\\\", \\\"{x:1563,y:623,t:1528143726475};\\\", \\\"{x:1563,y:638,t:1528143726491};\\\", \\\"{x:1565,y:661,t:1528143726508};\\\", \\\"{x:1569,y:691,t:1528143726525};\\\", \\\"{x:1571,y:722,t:1528143726541};\\\", \\\"{x:1571,y:756,t:1528143726558};\\\", \\\"{x:1571,y:792,t:1528143726574};\\\", \\\"{x:1571,y:837,t:1528143726592};\\\", \\\"{x:1571,y:884,t:1528143726608};\\\", \\\"{x:1571,y:949,t:1528143726625};\\\", \\\"{x:1561,y:1031,t:1528143726641};\\\", \\\"{x:1555,y:1064,t:1528143726657};\\\", \\\"{x:1550,y:1086,t:1528143726675};\\\", \\\"{x:1549,y:1093,t:1528143726691};\\\", \\\"{x:1546,y:1093,t:1528143726802};\\\", \\\"{x:1543,y:1092,t:1528143726810};\\\", \\\"{x:1535,y:1088,t:1528143726825};\\\", \\\"{x:1498,y:1077,t:1528143726841};\\\", \\\"{x:1439,y:1060,t:1528143726859};\\\", \\\"{x:1376,y:1042,t:1528143726876};\\\", \\\"{x:1331,y:1031,t:1528143726891};\\\", \\\"{x:1307,y:1023,t:1528143726908};\\\", \\\"{x:1290,y:1017,t:1528143726925};\\\", \\\"{x:1283,y:1016,t:1528143726942};\\\", \\\"{x:1278,y:1013,t:1528143726959};\\\", \\\"{x:1277,y:1013,t:1528143727026};\\\", \\\"{x:1273,y:1011,t:1528143727042};\\\", \\\"{x:1267,y:1009,t:1528143727059};\\\", \\\"{x:1261,y:1008,t:1528143727076};\\\", \\\"{x:1256,y:1006,t:1528143727092};\\\", \\\"{x:1255,y:1005,t:1528143727109};\\\", \\\"{x:1253,y:1003,t:1528143727126};\\\", \\\"{x:1253,y:1002,t:1528143727141};\\\", \\\"{x:1253,y:996,t:1528143727159};\\\", \\\"{x:1257,y:987,t:1528143727176};\\\", \\\"{x:1270,y:974,t:1528143727193};\\\", \\\"{x:1283,y:965,t:1528143727210};\\\", \\\"{x:1300,y:954,t:1528143727226};\\\", \\\"{x:1310,y:947,t:1528143727243};\\\", \\\"{x:1320,y:942,t:1528143727259};\\\", \\\"{x:1326,y:938,t:1528143727276};\\\", \\\"{x:1333,y:935,t:1528143727293};\\\", \\\"{x:1336,y:935,t:1528143727308};\\\", \\\"{x:1339,y:935,t:1528143727325};\\\", \\\"{x:1340,y:935,t:1528143727345};\\\", \\\"{x:1342,y:935,t:1528143727361};\\\", \\\"{x:1344,y:937,t:1528143727376};\\\", \\\"{x:1346,y:940,t:1528143727393};\\\", \\\"{x:1348,y:941,t:1528143727409};\\\", \\\"{x:1348,y:943,t:1528143727426};\\\", \\\"{x:1348,y:945,t:1528143727443};\\\", \\\"{x:1348,y:948,t:1528143727460};\\\", \\\"{x:1348,y:950,t:1528143727476};\\\", \\\"{x:1348,y:952,t:1528143727492};\\\", \\\"{x:1347,y:952,t:1528143727510};\\\", \\\"{x:1346,y:953,t:1528143727526};\\\", \\\"{x:1343,y:954,t:1528143727543};\\\", \\\"{x:1342,y:954,t:1528143727560};\\\", \\\"{x:1342,y:956,t:1528143727576};\\\", \\\"{x:1340,y:958,t:1528143727593};\\\", \\\"{x:1340,y:959,t:1528143727610};\\\", \\\"{x:1341,y:959,t:1528143727818};\\\", \\\"{x:1344,y:959,t:1528143727827};\\\", \\\"{x:1346,y:957,t:1528143727842};\\\", \\\"{x:1350,y:954,t:1528143727860};\\\", \\\"{x:1354,y:950,t:1528143727877};\\\", \\\"{x:1357,y:948,t:1528143727894};\\\", \\\"{x:1360,y:944,t:1528143727910};\\\", \\\"{x:1363,y:941,t:1528143727927};\\\", \\\"{x:1366,y:937,t:1528143727944};\\\", \\\"{x:1369,y:932,t:1528143727961};\\\", \\\"{x:1370,y:931,t:1528143727977};\\\", \\\"{x:1373,y:926,t:1528143727994};\\\", \\\"{x:1374,y:925,t:1528143728010};\\\", \\\"{x:1374,y:923,t:1528143728027};\\\", \\\"{x:1374,y:922,t:1528143728170};\\\", \\\"{x:1374,y:921,t:1528143728177};\\\", \\\"{x:1374,y:919,t:1528143728194};\\\", \\\"{x:1377,y:915,t:1528143728211};\\\", \\\"{x:1378,y:912,t:1528143728227};\\\", \\\"{x:1378,y:909,t:1528143728244};\\\", \\\"{x:1379,y:907,t:1528143728260};\\\", \\\"{x:1380,y:903,t:1528143728276};\\\", \\\"{x:1381,y:899,t:1528143728296};\\\", \\\"{x:1381,y:897,t:1528143728310};\\\", \\\"{x:1381,y:896,t:1528143728327};\\\", \\\"{x:1383,y:894,t:1528143728343};\\\", \\\"{x:1383,y:893,t:1528143728361};\\\", \\\"{x:1384,y:891,t:1528143728377};\\\", \\\"{x:1384,y:890,t:1528143728393};\\\", \\\"{x:1385,y:888,t:1528143728410};\\\", \\\"{x:1386,y:887,t:1528143728433};\\\", \\\"{x:1387,y:886,t:1528143728449};\\\", \\\"{x:1388,y:884,t:1528143728473};\\\", \\\"{x:1389,y:884,t:1528143728505};\\\", \\\"{x:1390,y:883,t:1528143728554};\\\", \\\"{x:1390,y:882,t:1528143728578};\\\", \\\"{x:1391,y:881,t:1528143728594};\\\", \\\"{x:1392,y:880,t:1528143728610};\\\", \\\"{x:1394,y:878,t:1528143728627};\\\", \\\"{x:1394,y:877,t:1528143728649};\\\", \\\"{x:1395,y:876,t:1528143728661};\\\", \\\"{x:1396,y:875,t:1528143728678};\\\", \\\"{x:1396,y:874,t:1528143728730};\\\", \\\"{x:1397,y:874,t:1528143728753};\\\", \\\"{x:1397,y:873,t:1528143728818};\\\", \\\"{x:1398,y:872,t:1528143728841};\\\", \\\"{x:1398,y:871,t:1528143728874};\\\", \\\"{x:1398,y:869,t:1528143729818};\\\", \\\"{x:1396,y:867,t:1528143729830};\\\", \\\"{x:1390,y:863,t:1528143729847};\\\", \\\"{x:1378,y:852,t:1528143729863};\\\", \\\"{x:1362,y:842,t:1528143729880};\\\", \\\"{x:1341,y:826,t:1528143729897};\\\", \\\"{x:1329,y:812,t:1528143729913};\\\", \\\"{x:1316,y:798,t:1528143729930};\\\", \\\"{x:1311,y:794,t:1528143729947};\\\", \\\"{x:1308,y:792,t:1528143729963};\\\", \\\"{x:1307,y:791,t:1528143730034};\\\", \\\"{x:1306,y:791,t:1528143730047};\\\", \\\"{x:1305,y:791,t:1528143730065};\\\", \\\"{x:1303,y:791,t:1528143730080};\\\", \\\"{x:1302,y:790,t:1528143730097};\\\", \\\"{x:1300,y:790,t:1528143730113};\\\", \\\"{x:1299,y:790,t:1528143730153};\\\", \\\"{x:1298,y:790,t:1528143730164};\\\", \\\"{x:1297,y:790,t:1528143730181};\\\", \\\"{x:1296,y:790,t:1528143730197};\\\", \\\"{x:1294,y:791,t:1528143730214};\\\", \\\"{x:1292,y:791,t:1528143730231};\\\", \\\"{x:1291,y:791,t:1528143730247};\\\", \\\"{x:1290,y:791,t:1528143730370};\\\", \\\"{x:1289,y:791,t:1528143730381};\\\", \\\"{x:1286,y:791,t:1528143730398};\\\", \\\"{x:1279,y:791,t:1528143730415};\\\", \\\"{x:1269,y:791,t:1528143730431};\\\", \\\"{x:1256,y:789,t:1528143730448};\\\", \\\"{x:1241,y:783,t:1528143730464};\\\", \\\"{x:1222,y:778,t:1528143730481};\\\", \\\"{x:1196,y:767,t:1528143730497};\\\", \\\"{x:1177,y:756,t:1528143730514};\\\", \\\"{x:1157,y:745,t:1528143730532};\\\", \\\"{x:1135,y:735,t:1528143730548};\\\", \\\"{x:1111,y:724,t:1528143730564};\\\", \\\"{x:1077,y:717,t:1528143730581};\\\", \\\"{x:1037,y:704,t:1528143730598};\\\", \\\"{x:992,y:692,t:1528143730615};\\\", \\\"{x:945,y:680,t:1528143730631};\\\", \\\"{x:898,y:666,t:1528143730648};\\\", \\\"{x:865,y:657,t:1528143730664};\\\", \\\"{x:826,y:647,t:1528143730681};\\\", \\\"{x:809,y:641,t:1528143730697};\\\", \\\"{x:805,y:641,t:1528143730715};\\\", \\\"{x:803,y:640,t:1528143730778};\\\", \\\"{x:800,y:638,t:1528143730793};\\\", \\\"{x:797,y:637,t:1528143730809};\\\", \\\"{x:792,y:635,t:1528143730817};\\\", \\\"{x:790,y:634,t:1528143730832};\\\", \\\"{x:782,y:630,t:1528143730849};\\\", \\\"{x:773,y:625,t:1528143730865};\\\", \\\"{x:772,y:623,t:1528143730877};\\\", \\\"{x:769,y:620,t:1528143730893};\\\", \\\"{x:762,y:614,t:1528143730910};\\\", \\\"{x:750,y:607,t:1528143730927};\\\", \\\"{x:734,y:598,t:1528143730944};\\\", \\\"{x:706,y:585,t:1528143730961};\\\", \\\"{x:689,y:579,t:1528143730977};\\\", \\\"{x:675,y:574,t:1528143730993};\\\", \\\"{x:664,y:569,t:1528143731010};\\\", \\\"{x:654,y:562,t:1528143731028};\\\", \\\"{x:638,y:555,t:1528143731044};\\\", \\\"{x:628,y:551,t:1528143731060};\\\", \\\"{x:617,y:548,t:1528143731077};\\\", \\\"{x:612,y:546,t:1528143731093};\\\", \\\"{x:601,y:543,t:1528143731110};\\\", \\\"{x:591,y:541,t:1528143731127};\\\", \\\"{x:575,y:534,t:1528143731144};\\\", \\\"{x:549,y:530,t:1528143731160};\\\", \\\"{x:531,y:527,t:1528143731177};\\\", \\\"{x:519,y:525,t:1528143731193};\\\", \\\"{x:509,y:524,t:1528143731211};\\\", \\\"{x:502,y:522,t:1528143731227};\\\", \\\"{x:492,y:521,t:1528143731244};\\\", \\\"{x:477,y:521,t:1528143731260};\\\", \\\"{x:461,y:522,t:1528143731278};\\\", \\\"{x:441,y:522,t:1528143731293};\\\", \\\"{x:422,y:522,t:1528143731311};\\\", \\\"{x:400,y:522,t:1528143731328};\\\", \\\"{x:387,y:522,t:1528143731344};\\\", \\\"{x:382,y:522,t:1528143731361};\\\", \\\"{x:381,y:522,t:1528143731377};\\\", \\\"{x:380,y:522,t:1528143731425};\\\", \\\"{x:378,y:522,t:1528143731450};\\\", \\\"{x:375,y:522,t:1528143731460};\\\", \\\"{x:371,y:523,t:1528143731478};\\\", \\\"{x:363,y:526,t:1528143731496};\\\", \\\"{x:357,y:528,t:1528143731510};\\\", \\\"{x:351,y:530,t:1528143731527};\\\", \\\"{x:349,y:531,t:1528143731544};\\\", \\\"{x:349,y:532,t:1528143731786};\\\", \\\"{x:350,y:532,t:1528143731794};\\\", \\\"{x:354,y:532,t:1528143731811};\\\", \\\"{x:361,y:533,t:1528143731827};\\\", \\\"{x:363,y:534,t:1528143731845};\\\", \\\"{x:364,y:534,t:1528143731890};\\\", \\\"{x:364,y:536,t:1528143732505};\\\", \\\"{x:365,y:543,t:1528143732512};\\\", \\\"{x:368,y:551,t:1528143732528};\\\", \\\"{x:372,y:556,t:1528143732546};\\\", \\\"{x:374,y:557,t:1528143732561};\\\", \\\"{x:376,y:559,t:1528143732578};\\\", \\\"{x:378,y:559,t:1528143732594};\\\", \\\"{x:379,y:559,t:1528143732616};\\\", \\\"{x:380,y:558,t:1528143732657};\\\", \\\"{x:383,y:555,t:1528143732665};\\\", \\\"{x:383,y:552,t:1528143732679};\\\", \\\"{x:387,y:548,t:1528143732695};\\\", \\\"{x:389,y:545,t:1528143732712};\\\", \\\"{x:389,y:544,t:1528143732728};\\\", \\\"{x:390,y:544,t:1528143732745};\\\", \\\"{x:391,y:549,t:1528143733048};\\\", \\\"{x:392,y:556,t:1528143733063};\\\", \\\"{x:394,y:562,t:1528143733079};\\\", \\\"{x:395,y:567,t:1528143733095};\\\", \\\"{x:395,y:573,t:1528143733112};\\\", \\\"{x:395,y:576,t:1528143733128};\\\", \\\"{x:396,y:578,t:1528143733146};\\\", \\\"{x:397,y:583,t:1528143733162};\\\", \\\"{x:397,y:584,t:1528143733178};\\\", \\\"{x:397,y:586,t:1528143733195};\\\", \\\"{x:397,y:589,t:1528143733213};\\\", \\\"{x:397,y:590,t:1528143733233};\\\", \\\"{x:397,y:591,t:1528143733306};\\\", \\\"{x:397,y:593,t:1528143733321};\\\", \\\"{x:397,y:595,t:1528143733338};\\\", \\\"{x:396,y:596,t:1528143733370};\\\", \\\"{x:395,y:596,t:1528143733408};\\\", \\\"{x:393,y:596,t:1528143733441};\\\", \\\"{x:392,y:597,t:1528143733490};\\\", \\\"{x:392,y:598,t:1528143733497};\\\", \\\"{x:392,y:599,t:1528143733513};\\\", \\\"{x:391,y:601,t:1528143733531};\\\", \\\"{x:390,y:602,t:1528143733553};\\\", \\\"{x:390,y:604,t:1528143733578};\\\", \\\"{x:390,y:605,t:1528143733596};\\\", \\\"{x:390,y:607,t:1528143733613};\\\", \\\"{x:390,y:608,t:1528143733648};\\\", \\\"{x:390,y:610,t:1528143733688};\\\", \\\"{x:390,y:611,t:1528143733713};\\\", \\\"{x:389,y:611,t:1528143733737};\\\", \\\"{x:387,y:611,t:1528143733833};\\\", \\\"{x:386,y:611,t:1528143734272};\\\", \\\"{x:386,y:613,t:1528143734345};\\\", \\\"{x:386,y:614,t:1528143734353};\\\", \\\"{x:386,y:618,t:1528143734363};\\\", \\\"{x:390,y:624,t:1528143734380};\\\", \\\"{x:395,y:632,t:1528143734398};\\\", \\\"{x:401,y:641,t:1528143734414};\\\", \\\"{x:407,y:646,t:1528143734429};\\\", \\\"{x:412,y:651,t:1528143734446};\\\", \\\"{x:420,y:658,t:1528143734464};\\\", \\\"{x:427,y:663,t:1528143734480};\\\", \\\"{x:435,y:672,t:1528143734496};\\\", \\\"{x:438,y:677,t:1528143734512};\\\", \\\"{x:440,y:682,t:1528143734529};\\\", \\\"{x:442,y:690,t:1528143734547};\\\", \\\"{x:444,y:696,t:1528143734564};\\\", \\\"{x:445,y:701,t:1528143734580};\\\", \\\"{x:447,y:708,t:1528143734597};\\\", \\\"{x:451,y:717,t:1528143734613};\\\", \\\"{x:454,y:725,t:1528143734631};\\\", \\\"{x:458,y:732,t:1528143734646};\\\", \\\"{x:462,y:737,t:1528143734664};\\\", \\\"{x:465,y:742,t:1528143734679};\\\", \\\"{x:469,y:748,t:1528143734697};\\\", \\\"{x:470,y:748,t:1528143734714};\\\", \\\"{x:470,y:750,t:1528143734730};\\\", \\\"{x:472,y:753,t:1528143734747};\\\", \\\"{x:473,y:755,t:1528143734766};\\\", \\\"{x:475,y:757,t:1528143734780};\\\", \\\"{x:475,y:758,t:1528143735050};\\\", \\\"{x:474,y:758,t:1528143736057};\\\", \\\"{x:473,y:758,t:1528143736170};\\\", \\\"{x:472,y:757,t:1528143736193};\\\", \\\"{x:471,y:757,t:1528143736202};\\\", \\\"{x:470,y:756,t:1528143736215};\\\", \\\"{x:470,y:748,t:1528143736233};\\\", \\\"{x:470,y:745,t:1528143736248};\\\", \\\"{x:470,y:742,t:1528143736265};\\\", \\\"{x:470,y:741,t:1528143736289};\\\", \\\"{x:470,y:740,t:1528143736897};\\\", \\\"{x:470,y:737,t:1528143736905};\\\", \\\"{x:470,y:735,t:1528143736916};\\\", \\\"{x:471,y:733,t:1528143736932};\\\", \\\"{x:472,y:729,t:1528143736949};\\\", \\\"{x:473,y:726,t:1528143736965};\\\", \\\"{x:474,y:723,t:1528143736983};\\\", \\\"{x:475,y:721,t:1528143736999};\\\", \\\"{x:475,y:720,t:1528143737016};\\\", \\\"{x:475,y:719,t:1528143737082};\\\", \\\"{x:476,y:719,t:1528143737099};\\\", \\\"{x:477,y:716,t:1528143737115};\\\", \\\"{x:478,y:715,t:1528143737133};\\\", \\\"{x:479,y:713,t:1528143737149};\\\", \\\"{x:481,y:710,t:1528143737166};\\\", \\\"{x:482,y:709,t:1528143737183};\\\", \\\"{x:484,y:708,t:1528143737199};\\\", \\\"{x:484,y:707,t:1528143737216};\\\", \\\"{x:485,y:707,t:1528143737241};\\\" ] }, { \\\"rt\\\": 6232, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 16, \\\"time_elapsed\\\": 831280, \\\"internal_node_id\\\": \\\"0.0-6.0-6.0\\\", \\\"subject\\\": \\\"K0CNH\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 12, \\\"clicks\\\": 1, \\\"explicit\\\": 2, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F -F -F \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:485,y:705,t:1528143737776};\\\", \\\"{x:485,y:704,t:1528143737784};\\\", \\\"{x:486,y:703,t:1528143737800};\\\", \\\"{x:486,y:701,t:1528143737833};\\\", \\\"{x:487,y:699,t:1528143737856};\\\", \\\"{x:487,y:698,t:1528143737872};\\\", \\\"{x:488,y:697,t:1528143737883};\\\", \\\"{x:489,y:697,t:1528143737899};\\\", \\\"{x:489,y:695,t:1528143737916};\\\", \\\"{x:491,y:694,t:1528143737932};\\\", \\\"{x:491,y:693,t:1528143737950};\\\", \\\"{x:492,y:692,t:1528143737969};\\\", \\\"{x:492,y:691,t:1528143738001};\\\", \\\"{x:492,y:690,t:1528143738016};\\\", \\\"{x:494,y:689,t:1528143738032};\\\", \\\"{x:494,y:688,t:1528143738050};\\\", \\\"{x:495,y:688,t:1528143738066};\\\", \\\"{x:496,y:686,t:1528143738084};\\\", \\\"{x:499,y:684,t:1528143738153};\\\", \\\"{x:501,y:682,t:1528143738166};\\\", \\\"{x:503,y:682,t:1528143738187};\\\", \\\"{x:503,y:681,t:1528143738207};\\\", \\\"{x:504,y:681,t:1528143738224};\\\", \\\"{x:506,y:680,t:1528143738240};\\\", \\\"{x:509,y:680,t:1528143738256};\\\", \\\"{x:510,y:679,t:1528143738265};\\\", \\\"{x:519,y:678,t:1528143738282};\\\", \\\"{x:526,y:678,t:1528143738300};\\\", \\\"{x:534,y:678,t:1528143738315};\\\", \\\"{x:544,y:678,t:1528143738333};\\\", \\\"{x:554,y:678,t:1528143738350};\\\", \\\"{x:562,y:678,t:1528143738366};\\\", \\\"{x:571,y:677,t:1528143738383};\\\", \\\"{x:580,y:677,t:1528143738400};\\\", \\\"{x:591,y:677,t:1528143738416};\\\", \\\"{x:607,y:677,t:1528143738433};\\\", \\\"{x:621,y:677,t:1528143738450};\\\", \\\"{x:638,y:677,t:1528143738467};\\\", \\\"{x:653,y:677,t:1528143738483};\\\", \\\"{x:667,y:677,t:1528143738500};\\\", \\\"{x:678,y:677,t:1528143738517};\\\", \\\"{x:684,y:676,t:1528143738533};\\\", \\\"{x:690,y:675,t:1528143738550};\\\", \\\"{x:695,y:674,t:1528143738567};\\\", \\\"{x:699,y:673,t:1528143738583};\\\", \\\"{x:702,y:672,t:1528143738600};\\\", \\\"{x:710,y:670,t:1528143738617};\\\", \\\"{x:717,y:669,t:1528143738633};\\\", \\\"{x:730,y:669,t:1528143738651};\\\", \\\"{x:748,y:669,t:1528143738667};\\\", \\\"{x:764,y:669,t:1528143738683};\\\", \\\"{x:785,y:669,t:1528143738700};\\\", \\\"{x:802,y:669,t:1528143738717};\\\", \\\"{x:823,y:669,t:1528143738733};\\\", \\\"{x:841,y:669,t:1528143738750};\\\", \\\"{x:856,y:669,t:1528143738767};\\\", \\\"{x:871,y:669,t:1528143738783};\\\", \\\"{x:886,y:669,t:1528143738801};\\\", \\\"{x:905,y:669,t:1528143738817};\\\", \\\"{x:922,y:674,t:1528143738833};\\\", \\\"{x:943,y:678,t:1528143738850};\\\", \\\"{x:965,y:681,t:1528143738867};\\\", \\\"{x:986,y:684,t:1528143738885};\\\", \\\"{x:1009,y:688,t:1528143738901};\\\", \\\"{x:1038,y:692,t:1528143738917};\\\", \\\"{x:1072,y:696,t:1528143738935};\\\", \\\"{x:1096,y:700,t:1528143738950};\\\", \\\"{x:1120,y:703,t:1528143738967};\\\", \\\"{x:1144,y:708,t:1528143738984};\\\", \\\"{x:1169,y:712,t:1528143739000};\\\", \\\"{x:1201,y:719,t:1528143739018};\\\", \\\"{x:1219,y:722,t:1528143739033};\\\", \\\"{x:1235,y:724,t:1528143739051};\\\", \\\"{x:1251,y:728,t:1528143739067};\\\", \\\"{x:1266,y:732,t:1528143739085};\\\", \\\"{x:1279,y:735,t:1528143739100};\\\", \\\"{x:1288,y:737,t:1528143739118};\\\", \\\"{x:1298,y:738,t:1528143739134};\\\", \\\"{x:1305,y:739,t:1528143739151};\\\", \\\"{x:1309,y:740,t:1528143739167};\\\", \\\"{x:1312,y:740,t:1528143739184};\\\", \\\"{x:1315,y:740,t:1528143739201};\\\", \\\"{x:1320,y:740,t:1528143739217};\\\", \\\"{x:1323,y:740,t:1528143739235};\\\", \\\"{x:1326,y:740,t:1528143739251};\\\", \\\"{x:1330,y:739,t:1528143739268};\\\", \\\"{x:1333,y:736,t:1528143739284};\\\", \\\"{x:1337,y:733,t:1528143739301};\\\", \\\"{x:1343,y:729,t:1528143739318};\\\", \\\"{x:1347,y:725,t:1528143739334};\\\", \\\"{x:1354,y:720,t:1528143739351};\\\", \\\"{x:1360,y:714,t:1528143739367};\\\", \\\"{x:1365,y:708,t:1528143739384};\\\", \\\"{x:1365,y:705,t:1528143739401};\\\", \\\"{x:1366,y:705,t:1528143739425};\\\", \\\"{x:1366,y:703,t:1528143739666};\\\", \\\"{x:1366,y:702,t:1528143739674};\\\", \\\"{x:1366,y:700,t:1528143739685};\\\", \\\"{x:1366,y:699,t:1528143739702};\\\", \\\"{x:1366,y:697,t:1528143739718};\\\", \\\"{x:1366,y:696,t:1528143739735};\\\", \\\"{x:1366,y:695,t:1528143739762};\\\", \\\"{x:1366,y:694,t:1528143739809};\\\", \\\"{x:1366,y:693,t:1528143739834};\\\", \\\"{x:1366,y:691,t:1528143739852};\\\", \\\"{x:1366,y:688,t:1528143739869};\\\", \\\"{x:1366,y:681,t:1528143739884};\\\", \\\"{x:1367,y:674,t:1528143739902};\\\", \\\"{x:1367,y:670,t:1528143739918};\\\", \\\"{x:1367,y:669,t:1528143739935};\\\", \\\"{x:1367,y:668,t:1528143739952};\\\", \\\"{x:1368,y:667,t:1528143739986};\\\", \\\"{x:1368,y:666,t:1528143740170};\\\", \\\"{x:1367,y:666,t:1528143740184};\\\", \\\"{x:1363,y:666,t:1528143740201};\\\", \\\"{x:1359,y:666,t:1528143740219};\\\", \\\"{x:1358,y:666,t:1528143740235};\\\", \\\"{x:1357,y:666,t:1528143740251};\\\", \\\"{x:1356,y:666,t:1528143740281};\\\", \\\"{x:1354,y:667,t:1528143740297};\\\", \\\"{x:1353,y:668,t:1528143740314};\\\", \\\"{x:1352,y:668,t:1528143740322};\\\", \\\"{x:1350,y:669,t:1528143740335};\\\", \\\"{x:1347,y:671,t:1528143740351};\\\", \\\"{x:1341,y:675,t:1528143740368};\\\", \\\"{x:1335,y:678,t:1528143740385};\\\", \\\"{x:1332,y:680,t:1528143740402};\\\", \\\"{x:1328,y:684,t:1528143740418};\\\", \\\"{x:1326,y:688,t:1528143740436};\\\", \\\"{x:1324,y:691,t:1528143740452};\\\", \\\"{x:1321,y:694,t:1528143740469};\\\", \\\"{x:1321,y:696,t:1528143740486};\\\", \\\"{x:1319,y:700,t:1528143740502};\\\", \\\"{x:1319,y:702,t:1528143740519};\\\", \\\"{x:1318,y:704,t:1528143740536};\\\", \\\"{x:1317,y:707,t:1528143740552};\\\", \\\"{x:1317,y:709,t:1528143740569};\\\", \\\"{x:1316,y:714,t:1528143740586};\\\", \\\"{x:1314,y:716,t:1528143740601};\\\", \\\"{x:1314,y:719,t:1528143740618};\\\", \\\"{x:1314,y:721,t:1528143740635};\\\", \\\"{x:1312,y:724,t:1528143740652};\\\", \\\"{x:1312,y:726,t:1528143740668};\\\", \\\"{x:1311,y:729,t:1528143740685};\\\", \\\"{x:1310,y:731,t:1528143740702};\\\", \\\"{x:1309,y:734,t:1528143740718};\\\", \\\"{x:1309,y:736,t:1528143740735};\\\", \\\"{x:1309,y:738,t:1528143740752};\\\", \\\"{x:1307,y:740,t:1528143740768};\\\", \\\"{x:1307,y:741,t:1528143740785};\\\", \\\"{x:1309,y:740,t:1528143741042};\\\", \\\"{x:1313,y:734,t:1528143741052};\\\", \\\"{x:1322,y:722,t:1528143741068};\\\", \\\"{x:1330,y:709,t:1528143741086};\\\", \\\"{x:1336,y:703,t:1528143741102};\\\", \\\"{x:1340,y:698,t:1528143741119};\\\", \\\"{x:1342,y:696,t:1528143741138};\\\", \\\"{x:1344,y:692,t:1528143741152};\\\", \\\"{x:1348,y:682,t:1528143741168};\\\", \\\"{x:1354,y:665,t:1528143741185};\\\", \\\"{x:1359,y:659,t:1528143741202};\\\", \\\"{x:1361,y:656,t:1528143741218};\\\", \\\"{x:1362,y:654,t:1528143741235};\\\", \\\"{x:1363,y:653,t:1528143741256};\\\", \\\"{x:1364,y:650,t:1528143741296};\\\", \\\"{x:1365,y:650,t:1528143741321};\\\", \\\"{x:1366,y:649,t:1528143741335};\\\", \\\"{x:1366,y:648,t:1528143741352};\\\", \\\"{x:1368,y:646,t:1528143741369};\\\", \\\"{x:1369,y:645,t:1528143741386};\\\", \\\"{x:1371,y:643,t:1528143741402};\\\", \\\"{x:1371,y:642,t:1528143741426};\\\", \\\"{x:1370,y:648,t:1528143741642};\\\", \\\"{x:1367,y:655,t:1528143741652};\\\", \\\"{x:1355,y:677,t:1528143741669};\\\", \\\"{x:1343,y:694,t:1528143741686};\\\", \\\"{x:1330,y:712,t:1528143741703};\\\", \\\"{x:1321,y:725,t:1528143741719};\\\", \\\"{x:1309,y:739,t:1528143741736};\\\", \\\"{x:1293,y:753,t:1528143741753};\\\", \\\"{x:1270,y:769,t:1528143741769};\\\", \\\"{x:1254,y:773,t:1528143741786};\\\", \\\"{x:1244,y:775,t:1528143741802};\\\", \\\"{x:1230,y:776,t:1528143741820};\\\", \\\"{x:1211,y:776,t:1528143741836};\\\", \\\"{x:1181,y:770,t:1528143741853};\\\", \\\"{x:1127,y:752,t:1528143741870};\\\", \\\"{x:1063,y:722,t:1528143741886};\\\", \\\"{x:978,y:685,t:1528143741903};\\\", \\\"{x:888,y:652,t:1528143741919};\\\", \\\"{x:813,y:618,t:1528143741938};\\\", \\\"{x:744,y:591,t:1528143741953};\\\", \\\"{x:642,y:563,t:1528143741969};\\\", \\\"{x:589,y:547,t:1528143741986};\\\", \\\"{x:544,y:533,t:1528143742003};\\\", \\\"{x:515,y:526,t:1528143742019};\\\", \\\"{x:491,y:521,t:1528143742036};\\\", \\\"{x:469,y:519,t:1528143742053};\\\", \\\"{x:453,y:518,t:1528143742069};\\\", \\\"{x:439,y:517,t:1528143742087};\\\", \\\"{x:432,y:516,t:1528143742103};\\\", \\\"{x:431,y:516,t:1528143742119};\\\", \\\"{x:437,y:518,t:1528143742218};\\\", \\\"{x:446,y:522,t:1528143742236};\\\", \\\"{x:457,y:525,t:1528143742253};\\\", \\\"{x:467,y:526,t:1528143742270};\\\", \\\"{x:481,y:526,t:1528143742286};\\\", \\\"{x:490,y:526,t:1528143742303};\\\", \\\"{x:496,y:526,t:1528143742320};\\\", \\\"{x:501,y:526,t:1528143742336};\\\", \\\"{x:503,y:526,t:1528143742353};\\\", \\\"{x:505,y:526,t:1528143742370};\\\", \\\"{x:509,y:527,t:1528143742385};\\\", \\\"{x:519,y:529,t:1528143742403};\\\", \\\"{x:529,y:530,t:1528143742419};\\\", \\\"{x:547,y:532,t:1528143742436};\\\", \\\"{x:568,y:535,t:1528143742453};\\\", \\\"{x:590,y:536,t:1528143742470};\\\", \\\"{x:614,y:536,t:1528143742486};\\\", \\\"{x:643,y:536,t:1528143742503};\\\", \\\"{x:671,y:536,t:1528143742520};\\\", \\\"{x:694,y:536,t:1528143742536};\\\", \\\"{x:720,y:536,t:1528143742553};\\\", \\\"{x:729,y:536,t:1528143742570};\\\", \\\"{x:732,y:536,t:1528143742586};\\\", \\\"{x:734,y:536,t:1528143742602};\\\", \\\"{x:737,y:536,t:1528143742620};\\\", \\\"{x:741,y:536,t:1528143742636};\\\", \\\"{x:746,y:536,t:1528143742653};\\\", \\\"{x:752,y:536,t:1528143742670};\\\", \\\"{x:754,y:536,t:1528143742687};\\\", \\\"{x:755,y:536,t:1528143742703};\\\", \\\"{x:757,y:536,t:1528143742719};\\\", \\\"{x:782,y:536,t:1528143742736};\\\", \\\"{x:811,y:541,t:1528143742753};\\\", \\\"{x:841,y:547,t:1528143742770};\\\", \\\"{x:863,y:549,t:1528143742787};\\\", \\\"{x:878,y:552,t:1528143742803};\\\", \\\"{x:885,y:552,t:1528143742820};\\\", \\\"{x:884,y:552,t:1528143742921};\\\", \\\"{x:881,y:552,t:1528143742937};\\\", \\\"{x:877,y:551,t:1528143742953};\\\", \\\"{x:871,y:548,t:1528143742970};\\\", \\\"{x:867,y:547,t:1528143742988};\\\", \\\"{x:865,y:544,t:1528143743003};\\\", \\\"{x:864,y:544,t:1528143743216};\\\", \\\"{x:862,y:544,t:1528143743224};\\\", \\\"{x:860,y:544,t:1528143743237};\\\", \\\"{x:851,y:545,t:1528143743254};\\\", \\\"{x:837,y:550,t:1528143743270};\\\", \\\"{x:818,y:558,t:1528143743287};\\\", \\\"{x:789,y:570,t:1528143743304};\\\", \\\"{x:747,y:589,t:1528143743320};\\\", \\\"{x:686,y:613,t:1528143743337};\\\", \\\"{x:653,y:628,t:1528143743354};\\\", \\\"{x:626,y:640,t:1528143743370};\\\", \\\"{x:602,y:651,t:1528143743387};\\\", \\\"{x:582,y:660,t:1528143743404};\\\", \\\"{x:566,y:670,t:1528143743421};\\\", \\\"{x:550,y:677,t:1528143743437};\\\", \\\"{x:542,y:683,t:1528143743454};\\\", \\\"{x:536,y:688,t:1528143743472};\\\", \\\"{x:526,y:697,t:1528143743487};\\\", \\\"{x:523,y:706,t:1528143743504};\\\", \\\"{x:517,y:712,t:1528143743520};\\\", \\\"{x:516,y:713,t:1528143743561};\\\", \\\"{x:515,y:714,t:1528143743571};\\\", \\\"{x:512,y:718,t:1528143743587};\\\", \\\"{x:511,y:720,t:1528143743605};\\\", \\\"{x:511,y:721,t:1528143743960};\\\", \\\"{x:510,y:722,t:1528143744225};\\\", \\\"{x:511,y:719,t:1528143744238};\\\", \\\"{x:522,y:706,t:1528143744254};\\\", \\\"{x:538,y:691,t:1528143744271};\\\", \\\"{x:552,y:679,t:1528143744288};\\\", \\\"{x:569,y:668,t:1528143744304};\\\", \\\"{x:611,y:644,t:1528143744321};\\\", \\\"{x:652,y:626,t:1528143744338};\\\", \\\"{x:694,y:607,t:1528143744354};\\\", \\\"{x:724,y:595,t:1528143744371};\\\", \\\"{x:750,y:588,t:1528143744388};\\\", \\\"{x:777,y:578,t:1528143744404};\\\", \\\"{x:797,y:571,t:1528143744421};\\\", \\\"{x:815,y:565,t:1528143744438};\\\", \\\"{x:831,y:561,t:1528143744455};\\\", \\\"{x:838,y:559,t:1528143744471};\\\", \\\"{x:840,y:557,t:1528143744489};\\\" ] }, { \\\"rt\\\": 10801, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 17, \\\"time_elapsed\\\": 843295, \\\"internal_node_id\\\": \\\"0.0-6.0-7.0\\\", \\\"subject\\\": \\\"K0CNH\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 13, \\\"clicks\\\": 2.5, \\\"explicit\\\": 2, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"J\\\", \\\"A\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F -H -H -H -A \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:841,y:557,t:1528143746649};\\\", \\\"{x:844,y:557,t:1528143746677};\\\", \\\"{x:845,y:558,t:1528143746690};\\\", \\\"{x:849,y:559,t:1528143746706};\\\", \\\"{x:858,y:563,t:1528143746724};\\\", \\\"{x:874,y:568,t:1528143746739};\\\", \\\"{x:894,y:574,t:1528143746756};\\\", \\\"{x:915,y:581,t:1528143746773};\\\", \\\"{x:935,y:587,t:1528143746789};\\\", \\\"{x:956,y:590,t:1528143746807};\\\", \\\"{x:976,y:593,t:1528143746822};\\\", \\\"{x:994,y:596,t:1528143746840};\\\", \\\"{x:1012,y:598,t:1528143746856};\\\", \\\"{x:1031,y:601,t:1528143746874};\\\", \\\"{x:1044,y:603,t:1528143746890};\\\", \\\"{x:1058,y:605,t:1528143746906};\\\", \\\"{x:1074,y:610,t:1528143746923};\\\", \\\"{x:1089,y:614,t:1528143746940};\\\", \\\"{x:1105,y:618,t:1528143746957};\\\", \\\"{x:1121,y:624,t:1528143746973};\\\", \\\"{x:1139,y:627,t:1528143746990};\\\", \\\"{x:1156,y:632,t:1528143747008};\\\", \\\"{x:1177,y:638,t:1528143747023};\\\", \\\"{x:1199,y:644,t:1528143747040};\\\", \\\"{x:1229,y:653,t:1528143747057};\\\", \\\"{x:1251,y:659,t:1528143747073};\\\", \\\"{x:1271,y:665,t:1528143747090};\\\", \\\"{x:1289,y:670,t:1528143747108};\\\", \\\"{x:1308,y:675,t:1528143747123};\\\", \\\"{x:1325,y:680,t:1528143747140};\\\", \\\"{x:1346,y:687,t:1528143747157};\\\", \\\"{x:1367,y:693,t:1528143747174};\\\", \\\"{x:1384,y:697,t:1528143747190};\\\", \\\"{x:1401,y:702,t:1528143747208};\\\", \\\"{x:1418,y:707,t:1528143747224};\\\", \\\"{x:1437,y:709,t:1528143747240};\\\", \\\"{x:1468,y:714,t:1528143747257};\\\", \\\"{x:1486,y:718,t:1528143747273};\\\", \\\"{x:1504,y:721,t:1528143747291};\\\", \\\"{x:1517,y:723,t:1528143747307};\\\", \\\"{x:1527,y:723,t:1528143747323};\\\", \\\"{x:1535,y:723,t:1528143747341};\\\", \\\"{x:1543,y:723,t:1528143747357};\\\", \\\"{x:1550,y:723,t:1528143747374};\\\", \\\"{x:1553,y:723,t:1528143747390};\\\", \\\"{x:1557,y:723,t:1528143747407};\\\", \\\"{x:1558,y:723,t:1528143747425};\\\", \\\"{x:1559,y:723,t:1528143747440};\\\", \\\"{x:1561,y:723,t:1528143747458};\\\", \\\"{x:1563,y:722,t:1528143747475};\\\", \\\"{x:1565,y:721,t:1528143747491};\\\", \\\"{x:1566,y:720,t:1528143747507};\\\", \\\"{x:1568,y:718,t:1528143747525};\\\", \\\"{x:1569,y:718,t:1528143747541};\\\", \\\"{x:1571,y:716,t:1528143747558};\\\", \\\"{x:1573,y:714,t:1528143747574};\\\", \\\"{x:1577,y:712,t:1528143747591};\\\", \\\"{x:1578,y:711,t:1528143747608};\\\", \\\"{x:1580,y:709,t:1528143747624};\\\", \\\"{x:1582,y:708,t:1528143747640};\\\", \\\"{x:1583,y:706,t:1528143747657};\\\", \\\"{x:1584,y:704,t:1528143747674};\\\", \\\"{x:1584,y:703,t:1528143747690};\\\", \\\"{x:1584,y:701,t:1528143747707};\\\", \\\"{x:1584,y:699,t:1528143747724};\\\", \\\"{x:1584,y:696,t:1528143747740};\\\", \\\"{x:1584,y:690,t:1528143747758};\\\", \\\"{x:1584,y:673,t:1528143747774};\\\", \\\"{x:1584,y:659,t:1528143747790};\\\", \\\"{x:1584,y:652,t:1528143747808};\\\", \\\"{x:1584,y:650,t:1528143747824};\\\", \\\"{x:1584,y:648,t:1528143747840};\\\", \\\"{x:1584,y:646,t:1528143748154};\\\", \\\"{x:1584,y:644,t:1528143748162};\\\", \\\"{x:1584,y:642,t:1528143748177};\\\", \\\"{x:1584,y:641,t:1528143748192};\\\", \\\"{x:1584,y:639,t:1528143748207};\\\", \\\"{x:1584,y:636,t:1528143748225};\\\", \\\"{x:1584,y:633,t:1528143748244};\\\", \\\"{x:1583,y:630,t:1528143748257};\\\", \\\"{x:1582,y:628,t:1528143748274};\\\", \\\"{x:1582,y:626,t:1528143748291};\\\", \\\"{x:1582,y:625,t:1528143748308};\\\", \\\"{x:1581,y:624,t:1528143748325};\\\", \\\"{x:1581,y:623,t:1528143748393};\\\", \\\"{x:1580,y:622,t:1528143748407};\\\", \\\"{x:1579,y:619,t:1528143748424};\\\", \\\"{x:1577,y:615,t:1528143748441};\\\", \\\"{x:1576,y:613,t:1528143748458};\\\", \\\"{x:1575,y:611,t:1528143748475};\\\", \\\"{x:1574,y:606,t:1528143748492};\\\", \\\"{x:1572,y:600,t:1528143748509};\\\", \\\"{x:1569,y:592,t:1528143748525};\\\", \\\"{x:1567,y:584,t:1528143748542};\\\", \\\"{x:1567,y:583,t:1528143748559};\\\", \\\"{x:1566,y:583,t:1528143748575};\\\", \\\"{x:1566,y:584,t:1528143748826};\\\", \\\"{x:1566,y:589,t:1528143748841};\\\", \\\"{x:1567,y:591,t:1528143748859};\\\", \\\"{x:1568,y:595,t:1528143748876};\\\", \\\"{x:1569,y:597,t:1528143748921};\\\", \\\"{x:1569,y:598,t:1528143748962};\\\", \\\"{x:1570,y:599,t:1528143748977};\\\", \\\"{x:1570,y:600,t:1528143748993};\\\", \\\"{x:1570,y:601,t:1528143749050};\\\", \\\"{x:1571,y:602,t:1528143749059};\\\", \\\"{x:1572,y:604,t:1528143749076};\\\", \\\"{x:1573,y:606,t:1528143749091};\\\", \\\"{x:1573,y:608,t:1528143749109};\\\", \\\"{x:1573,y:609,t:1528143749126};\\\", \\\"{x:1574,y:610,t:1528143749142};\\\", \\\"{x:1575,y:611,t:1528143749161};\\\", \\\"{x:1575,y:612,t:1528143749202};\\\", \\\"{x:1575,y:613,t:1528143749217};\\\", \\\"{x:1576,y:613,t:1528143749282};\\\", \\\"{x:1576,y:610,t:1528143749330};\\\", \\\"{x:1579,y:599,t:1528143749343};\\\", \\\"{x:1579,y:584,t:1528143749358};\\\", \\\"{x:1579,y:579,t:1528143749376};\\\", \\\"{x:1579,y:577,t:1528143749393};\\\", \\\"{x:1579,y:575,t:1528143749409};\\\", \\\"{x:1579,y:573,t:1528143749426};\\\", \\\"{x:1578,y:572,t:1528143749443};\\\", \\\"{x:1578,y:571,t:1528143749459};\\\", \\\"{x:1577,y:570,t:1528143749505};\\\", \\\"{x:1576,y:568,t:1528143749521};\\\", \\\"{x:1575,y:567,t:1528143749529};\\\", \\\"{x:1575,y:566,t:1528143749543};\\\", \\\"{x:1572,y:563,t:1528143749559};\\\", \\\"{x:1567,y:560,t:1528143749576};\\\", \\\"{x:1555,y:551,t:1528143749593};\\\", \\\"{x:1554,y:550,t:1528143749610};\\\", \\\"{x:1549,y:547,t:1528143749626};\\\", \\\"{x:1547,y:545,t:1528143749643};\\\", \\\"{x:1545,y:544,t:1528143749660};\\\", \\\"{x:1544,y:543,t:1528143749676};\\\", \\\"{x:1543,y:541,t:1528143749693};\\\", \\\"{x:1541,y:538,t:1528143749710};\\\", \\\"{x:1538,y:534,t:1528143749726};\\\", \\\"{x:1537,y:530,t:1528143749743};\\\", \\\"{x:1534,y:526,t:1528143749760};\\\", \\\"{x:1532,y:522,t:1528143749776};\\\", \\\"{x:1529,y:516,t:1528143749793};\\\", \\\"{x:1527,y:513,t:1528143749809};\\\", \\\"{x:1526,y:509,t:1528143749825};\\\", \\\"{x:1523,y:502,t:1528143749843};\\\", \\\"{x:1520,y:497,t:1528143749859};\\\", \\\"{x:1518,y:493,t:1528143749875};\\\", \\\"{x:1518,y:492,t:1528143749893};\\\", \\\"{x:1517,y:490,t:1528143749909};\\\", \\\"{x:1515,y:488,t:1528143749926};\\\", \\\"{x:1515,y:485,t:1528143749942};\\\", \\\"{x:1512,y:481,t:1528143749959};\\\", \\\"{x:1511,y:478,t:1528143749975};\\\", \\\"{x:1507,y:472,t:1528143749993};\\\", \\\"{x:1505,y:470,t:1528143750009};\\\", \\\"{x:1504,y:469,t:1528143750026};\\\", \\\"{x:1503,y:467,t:1528143750043};\\\", \\\"{x:1501,y:464,t:1528143750060};\\\", \\\"{x:1499,y:461,t:1528143750076};\\\", \\\"{x:1497,y:456,t:1528143750093};\\\", \\\"{x:1494,y:453,t:1528143750110};\\\", \\\"{x:1492,y:449,t:1528143750127};\\\", \\\"{x:1488,y:443,t:1528143750143};\\\", \\\"{x:1483,y:436,t:1528143750160};\\\", \\\"{x:1481,y:432,t:1528143750177};\\\", \\\"{x:1481,y:431,t:1528143750193};\\\", \\\"{x:1478,y:427,t:1528143750209};\\\", \\\"{x:1475,y:423,t:1528143750227};\\\", \\\"{x:1471,y:417,t:1528143750243};\\\", \\\"{x:1468,y:411,t:1528143750260};\\\", \\\"{x:1463,y:404,t:1528143750277};\\\", \\\"{x:1458,y:396,t:1528143750292};\\\", \\\"{x:1455,y:392,t:1528143750309};\\\", \\\"{x:1454,y:390,t:1528143750326};\\\", \\\"{x:1451,y:387,t:1528143750342};\\\", \\\"{x:1450,y:382,t:1528143750360};\\\", \\\"{x:1447,y:374,t:1528143750378};\\\", \\\"{x:1446,y:372,t:1528143750393};\\\", \\\"{x:1444,y:372,t:1528143751314};\\\", \\\"{x:1442,y:373,t:1528143751327};\\\", \\\"{x:1436,y:381,t:1528143751344};\\\", \\\"{x:1427,y:392,t:1528143751362};\\\", \\\"{x:1424,y:396,t:1528143751377};\\\", \\\"{x:1422,y:398,t:1528143751394};\\\", \\\"{x:1420,y:399,t:1528143751411};\\\", \\\"{x:1419,y:400,t:1528143751428};\\\", \\\"{x:1418,y:400,t:1528143751444};\\\", \\\"{x:1417,y:401,t:1528143751461};\\\", \\\"{x:1416,y:403,t:1528143751478};\\\", \\\"{x:1415,y:404,t:1528143751513};\\\", \\\"{x:1414,y:405,t:1528143751528};\\\", \\\"{x:1413,y:406,t:1528143751543};\\\", \\\"{x:1413,y:407,t:1528143751585};\\\", \\\"{x:1412,y:409,t:1528143751594};\\\", \\\"{x:1411,y:411,t:1528143751611};\\\", \\\"{x:1409,y:416,t:1528143751629};\\\", \\\"{x:1407,y:419,t:1528143751644};\\\", \\\"{x:1406,y:421,t:1528143751661};\\\", \\\"{x:1406,y:423,t:1528143751697};\\\", \\\"{x:1406,y:424,t:1528143751713};\\\", \\\"{x:1406,y:426,t:1528143751727};\\\", \\\"{x:1405,y:428,t:1528143751744};\\\", \\\"{x:1405,y:429,t:1528143751761};\\\", \\\"{x:1404,y:430,t:1528143751779};\\\", \\\"{x:1400,y:435,t:1528143752352};\\\", \\\"{x:1377,y:443,t:1528143752361};\\\", \\\"{x:1285,y:474,t:1528143752377};\\\", \\\"{x:1149,y:513,t:1528143752395};\\\", \\\"{x:995,y:550,t:1528143752411};\\\", \\\"{x:855,y:581,t:1528143752428};\\\", \\\"{x:751,y:607,t:1528143752445};\\\", \\\"{x:683,y:619,t:1528143752462};\\\", \\\"{x:632,y:626,t:1528143752478};\\\", \\\"{x:610,y:630,t:1528143752495};\\\", \\\"{x:602,y:632,t:1528143752512};\\\", \\\"{x:601,y:632,t:1528143752527};\\\", \\\"{x:600,y:629,t:1528143752649};\\\", \\\"{x:600,y:625,t:1528143752661};\\\", \\\"{x:600,y:622,t:1528143752678};\\\", \\\"{x:600,y:618,t:1528143752695};\\\", \\\"{x:600,y:610,t:1528143752712};\\\", \\\"{x:600,y:596,t:1528143752730};\\\", \\\"{x:600,y:591,t:1528143752744};\\\", \\\"{x:600,y:590,t:1528143752761};\\\", \\\"{x:599,y:588,t:1528143752778};\\\", \\\"{x:592,y:587,t:1528143752794};\\\", \\\"{x:577,y:586,t:1528143752812};\\\", \\\"{x:558,y:586,t:1528143752829};\\\", \\\"{x:536,y:586,t:1528143752846};\\\", \\\"{x:513,y:586,t:1528143752861};\\\", \\\"{x:490,y:586,t:1528143752879};\\\", \\\"{x:468,y:586,t:1528143752895};\\\", \\\"{x:453,y:583,t:1528143752911};\\\", \\\"{x:450,y:582,t:1528143752927};\\\", \\\"{x:449,y:581,t:1528143752961};\\\", \\\"{x:453,y:577,t:1528143752978};\\\", \\\"{x:464,y:573,t:1528143752994};\\\", \\\"{x:476,y:567,t:1528143753012};\\\", \\\"{x:492,y:563,t:1528143753028};\\\", \\\"{x:505,y:559,t:1528143753046};\\\", \\\"{x:510,y:558,t:1528143753061};\\\", \\\"{x:513,y:558,t:1528143753078};\\\", \\\"{x:516,y:557,t:1528143753096};\\\", \\\"{x:518,y:556,t:1528143753110};\\\", \\\"{x:525,y:554,t:1528143753128};\\\", \\\"{x:533,y:552,t:1528143753143};\\\", \\\"{x:536,y:551,t:1528143753159};\\\", \\\"{x:543,y:549,t:1528143753176};\\\", \\\"{x:551,y:549,t:1528143753193};\\\", \\\"{x:568,y:549,t:1528143753209};\\\", \\\"{x:588,y:549,t:1528143753226};\\\", \\\"{x:604,y:545,t:1528143753243};\\\", \\\"{x:612,y:545,t:1528143753259};\\\", \\\"{x:613,y:545,t:1528143753277};\\\", \\\"{x:615,y:545,t:1528143753359};\\\", \\\"{x:615,y:544,t:1528143753377};\\\", \\\"{x:616,y:543,t:1528143753415};\\\", \\\"{x:616,y:542,t:1528143753439};\\\", \\\"{x:617,y:542,t:1528143753463};\\\", \\\"{x:614,y:542,t:1528143753638};\\\", \\\"{x:598,y:547,t:1528143753647};\\\", \\\"{x:578,y:554,t:1528143753661};\\\", \\\"{x:541,y:565,t:1528143753677};\\\", \\\"{x:483,y:582,t:1528143753693};\\\", \\\"{x:403,y:603,t:1528143753711};\\\", \\\"{x:379,y:611,t:1528143753730};\\\", \\\"{x:362,y:616,t:1528143753791};\\\", \\\"{x:362,y:617,t:1528143753798};\\\", \\\"{x:361,y:617,t:1528143753829};\\\", \\\"{x:360,y:617,t:1528143753862};\\\", \\\"{x:359,y:617,t:1528143753878};\\\", \\\"{x:357,y:617,t:1528143753895};\\\", \\\"{x:356,y:617,t:1528143753910};\\\", \\\"{x:356,y:614,t:1528143753959};\\\", \\\"{x:356,y:611,t:1528143753967};\\\", \\\"{x:357,y:606,t:1528143753978};\\\", \\\"{x:359,y:591,t:1528143753994};\\\", \\\"{x:361,y:577,t:1528143754010};\\\", \\\"{x:362,y:570,t:1528143754027};\\\", \\\"{x:363,y:564,t:1528143754044};\\\", \\\"{x:363,y:554,t:1528143754061};\\\", \\\"{x:367,y:542,t:1528143754077};\\\", \\\"{x:370,y:533,t:1528143754093};\\\", \\\"{x:371,y:527,t:1528143754110};\\\", \\\"{x:371,y:526,t:1528143754127};\\\", \\\"{x:371,y:524,t:1528143754144};\\\", \\\"{x:372,y:522,t:1528143754161};\\\", \\\"{x:373,y:521,t:1528143754178};\\\", \\\"{x:374,y:518,t:1528143754193};\\\", \\\"{x:375,y:516,t:1528143754211};\\\", \\\"{x:375,y:515,t:1528143754228};\\\", \\\"{x:378,y:522,t:1528143754478};\\\", \\\"{x:380,y:538,t:1528143754495};\\\", \\\"{x:386,y:558,t:1528143754510};\\\", \\\"{x:396,y:581,t:1528143754528};\\\", \\\"{x:407,y:602,t:1528143754545};\\\", \\\"{x:420,y:622,t:1528143754560};\\\", \\\"{x:430,y:641,t:1528143754578};\\\", \\\"{x:439,y:657,t:1528143754594};\\\", \\\"{x:445,y:671,t:1528143754610};\\\", \\\"{x:450,y:684,t:1528143754627};\\\", \\\"{x:453,y:694,t:1528143754644};\\\", \\\"{x:455,y:701,t:1528143754660};\\\", \\\"{x:455,y:704,t:1528143754678};\\\", \\\"{x:455,y:705,t:1528143754694};\\\", \\\"{x:456,y:706,t:1528143754711};\\\", \\\"{x:456,y:701,t:1528143754759};\\\", \\\"{x:453,y:695,t:1528143754767};\\\", \\\"{x:453,y:689,t:1528143754778};\\\", \\\"{x:453,y:674,t:1528143754796};\\\", \\\"{x:450,y:646,t:1528143754813};\\\", \\\"{x:444,y:610,t:1528143754828};\\\", \\\"{x:439,y:581,t:1528143754844};\\\", \\\"{x:433,y:561,t:1528143754861};\\\", \\\"{x:427,y:545,t:1528143754878};\\\", \\\"{x:420,y:532,t:1528143754895};\\\", \\\"{x:417,y:527,t:1528143754912};\\\", \\\"{x:416,y:524,t:1528143754928};\\\", \\\"{x:416,y:523,t:1528143754966};\\\", \\\"{x:416,y:522,t:1528143754978};\\\", \\\"{x:414,y:518,t:1528143754994};\\\", \\\"{x:412,y:515,t:1528143755011};\\\", \\\"{x:412,y:512,t:1528143755028};\\\", \\\"{x:410,y:510,t:1528143755045};\\\", \\\"{x:409,y:508,t:1528143755062};\\\", \\\"{x:408,y:507,t:1528143755079};\\\", \\\"{x:406,y:503,t:1528143755094};\\\", \\\"{x:405,y:501,t:1528143755111};\\\", \\\"{x:404,y:499,t:1528143755127};\\\", \\\"{x:404,y:500,t:1528143755351};\\\", \\\"{x:404,y:504,t:1528143755361};\\\", \\\"{x:404,y:516,t:1528143755379};\\\", \\\"{x:405,y:544,t:1528143755395};\\\", \\\"{x:412,y:575,t:1528143755412};\\\", \\\"{x:420,y:602,t:1528143755429};\\\", \\\"{x:428,y:617,t:1528143755445};\\\", \\\"{x:431,y:622,t:1528143755462};\\\", \\\"{x:435,y:630,t:1528143755478};\\\", \\\"{x:439,y:638,t:1528143755495};\\\", \\\"{x:443,y:649,t:1528143755512};\\\", \\\"{x:448,y:658,t:1528143755529};\\\", \\\"{x:452,y:665,t:1528143755545};\\\", \\\"{x:456,y:670,t:1528143755562};\\\", \\\"{x:463,y:677,t:1528143755578};\\\", \\\"{x:474,y:690,t:1528143755596};\\\", \\\"{x:488,y:702,t:1528143755612};\\\", \\\"{x:495,y:709,t:1528143755628};\\\", \\\"{x:501,y:715,t:1528143755646};\\\", \\\"{x:505,y:718,t:1528143755662};\\\", \\\"{x:508,y:723,t:1528143755680};\\\", \\\"{x:510,y:726,t:1528143755695};\\\", \\\"{x:510,y:730,t:1528143755711};\\\", \\\"{x:510,y:736,t:1528143755729};\\\", \\\"{x:510,y:738,t:1528143755746};\\\", \\\"{x:510,y:739,t:1528143755761};\\\", \\\"{x:510,y:740,t:1528143755799};\\\", \\\"{x:510,y:741,t:1528143755961};\\\" ] }, { \\\"rt\\\": 8276, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 18, \\\"time_elapsed\\\": 852849, \\\"internal_node_id\\\": \\\"0.0-6.0-8.0\\\", \\\"subject\\\": \\\"K0CNH\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 14, \\\"clicks\\\": 1, \\\"explicit\\\": 2, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-04 PM-04 PM-03 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:511,y:741,t:1528143757999};\\\", \\\"{x:525,y:738,t:1528143758015};\\\", \\\"{x:552,y:734,t:1528143758043};\\\", \\\"{x:562,y:733,t:1528143758047};\\\", \\\"{x:578,y:733,t:1528143758065};\\\", \\\"{x:594,y:733,t:1528143758082};\\\", \\\"{x:610,y:733,t:1528143758097};\\\", \\\"{x:630,y:733,t:1528143758114};\\\", \\\"{x:648,y:733,t:1528143758130};\\\", \\\"{x:667,y:733,t:1528143758147};\\\", \\\"{x:682,y:733,t:1528143758164};\\\", \\\"{x:695,y:733,t:1528143758181};\\\", \\\"{x:707,y:733,t:1528143758196};\\\", \\\"{x:720,y:733,t:1528143758214};\\\", \\\"{x:748,y:733,t:1528143758230};\\\", \\\"{x:770,y:733,t:1528143758247};\\\", \\\"{x:796,y:733,t:1528143758264};\\\", \\\"{x:819,y:733,t:1528143758281};\\\", \\\"{x:842,y:733,t:1528143758298};\\\", \\\"{x:865,y:733,t:1528143758314};\\\", \\\"{x:894,y:737,t:1528143758330};\\\", \\\"{x:920,y:742,t:1528143758347};\\\", \\\"{x:943,y:744,t:1528143758364};\\\", \\\"{x:965,y:747,t:1528143758381};\\\", \\\"{x:982,y:749,t:1528143758399};\\\", \\\"{x:1002,y:753,t:1528143758414};\\\", \\\"{x:1030,y:760,t:1528143758431};\\\", \\\"{x:1048,y:766,t:1528143758448};\\\", \\\"{x:1064,y:770,t:1528143758464};\\\", \\\"{x:1078,y:776,t:1528143758480};\\\", \\\"{x:1094,y:782,t:1528143758498};\\\", \\\"{x:1117,y:789,t:1528143758513};\\\", \\\"{x:1145,y:797,t:1528143758531};\\\", \\\"{x:1178,y:806,t:1528143758548};\\\", \\\"{x:1207,y:816,t:1528143758564};\\\", \\\"{x:1243,y:830,t:1528143758581};\\\", \\\"{x:1275,y:842,t:1528143758598};\\\", \\\"{x:1311,y:851,t:1528143758614};\\\", \\\"{x:1373,y:870,t:1528143758631};\\\", \\\"{x:1420,y:882,t:1528143758648};\\\", \\\"{x:1453,y:891,t:1528143758664};\\\", \\\"{x:1491,y:905,t:1528143758682};\\\", \\\"{x:1528,y:922,t:1528143758698};\\\", \\\"{x:1562,y:940,t:1528143758715};\\\", \\\"{x:1593,y:954,t:1528143758731};\\\", \\\"{x:1610,y:963,t:1528143758749};\\\", \\\"{x:1622,y:968,t:1528143758764};\\\", \\\"{x:1628,y:970,t:1528143758782};\\\", \\\"{x:1631,y:972,t:1528143758798};\\\", \\\"{x:1634,y:974,t:1528143758814};\\\", \\\"{x:1636,y:975,t:1528143758832};\\\", \\\"{x:1636,y:976,t:1528143758895};\\\", \\\"{x:1636,y:978,t:1528143758904};\\\", \\\"{x:1636,y:979,t:1528143758916};\\\", \\\"{x:1636,y:981,t:1528143758931};\\\", \\\"{x:1630,y:983,t:1528143758949};\\\", \\\"{x:1620,y:984,t:1528143758965};\\\", \\\"{x:1602,y:984,t:1528143758981};\\\", \\\"{x:1583,y:984,t:1528143758999};\\\", \\\"{x:1551,y:980,t:1528143759015};\\\", \\\"{x:1532,y:976,t:1528143759031};\\\", \\\"{x:1521,y:973,t:1528143759049};\\\", \\\"{x:1519,y:972,t:1528143759066};\\\", \\\"{x:1518,y:971,t:1528143759081};\\\", \\\"{x:1518,y:970,t:1528143759119};\\\", \\\"{x:1518,y:969,t:1528143759131};\\\", \\\"{x:1518,y:968,t:1528143759148};\\\", \\\"{x:1520,y:967,t:1528143759165};\\\", \\\"{x:1524,y:964,t:1528143759182};\\\", \\\"{x:1526,y:962,t:1528143759199};\\\", \\\"{x:1528,y:961,t:1528143759215};\\\", \\\"{x:1530,y:960,t:1528143759232};\\\", \\\"{x:1533,y:959,t:1528143759249};\\\", \\\"{x:1538,y:959,t:1528143759266};\\\", \\\"{x:1545,y:957,t:1528143759282};\\\", \\\"{x:1550,y:956,t:1528143759299};\\\", \\\"{x:1552,y:955,t:1528143759335};\\\", \\\"{x:1552,y:957,t:1528143759544};\\\", \\\"{x:1552,y:958,t:1528143759584};\\\", \\\"{x:1551,y:960,t:1528143759640};\\\", \\\"{x:1550,y:961,t:1528143759687};\\\", \\\"{x:1549,y:961,t:1528143760344};\\\", \\\"{x:1547,y:961,t:1528143760359};\\\", \\\"{x:1543,y:961,t:1528143760367};\\\", \\\"{x:1539,y:961,t:1528143760383};\\\", \\\"{x:1512,y:961,t:1528143760399};\\\", \\\"{x:1483,y:960,t:1528143760417};\\\", \\\"{x:1451,y:952,t:1528143760433};\\\", \\\"{x:1398,y:938,t:1528143760449};\\\", \\\"{x:1332,y:920,t:1528143760467};\\\", \\\"{x:1258,y:892,t:1528143760483};\\\", \\\"{x:1175,y:854,t:1528143760499};\\\", \\\"{x:1124,y:826,t:1528143760516};\\\", \\\"{x:1077,y:798,t:1528143760534};\\\", \\\"{x:1031,y:771,t:1528143760550};\\\", \\\"{x:993,y:749,t:1528143760566};\\\", \\\"{x:963,y:731,t:1528143760584};\\\", \\\"{x:945,y:723,t:1528143760599};\\\", \\\"{x:928,y:717,t:1528143760616};\\\", \\\"{x:923,y:716,t:1528143760634};\\\", \\\"{x:919,y:716,t:1528143760649};\\\", \\\"{x:917,y:714,t:1528143760666};\\\", \\\"{x:916,y:714,t:1528143760687};\\\", \\\"{x:915,y:714,t:1528143760710};\\\", \\\"{x:913,y:714,t:1528143760719};\\\", \\\"{x:912,y:714,t:1528143760735};\\\", \\\"{x:909,y:714,t:1528143760749};\\\", \\\"{x:906,y:714,t:1528143760766};\\\", \\\"{x:898,y:714,t:1528143760783};\\\", \\\"{x:892,y:714,t:1528143760799};\\\", \\\"{x:886,y:714,t:1528143760816};\\\", \\\"{x:884,y:714,t:1528143760833};\\\", \\\"{x:884,y:713,t:1528143760849};\\\", \\\"{x:883,y:713,t:1528143760866};\\\", \\\"{x:882,y:712,t:1528143760883};\\\", \\\"{x:880,y:711,t:1528143760899};\\\", \\\"{x:876,y:710,t:1528143760916};\\\", \\\"{x:872,y:709,t:1528143760934};\\\", \\\"{x:867,y:706,t:1528143760949};\\\", \\\"{x:863,y:705,t:1528143760966};\\\", \\\"{x:860,y:703,t:1528143760984};\\\", \\\"{x:856,y:702,t:1528143761000};\\\", \\\"{x:854,y:701,t:1528143761016};\\\", \\\"{x:852,y:700,t:1528143761033};\\\", \\\"{x:850,y:699,t:1528143761050};\\\", \\\"{x:849,y:699,t:1528143761066};\\\", \\\"{x:848,y:699,t:1528143761083};\\\", \\\"{x:847,y:699,t:1528143761111};\\\", \\\"{x:846,y:699,t:1528143761119};\\\", \\\"{x:845,y:699,t:1528143761134};\\\", \\\"{x:843,y:698,t:1528143761150};\\\", \\\"{x:842,y:698,t:1528143761166};\\\", \\\"{x:840,y:698,t:1528143761182};\\\", \\\"{x:832,y:696,t:1528143763495};\\\", \\\"{x:818,y:691,t:1528143763503};\\\", \\\"{x:808,y:689,t:1528143763518};\\\", \\\"{x:758,y:674,t:1528143763535};\\\", \\\"{x:728,y:665,t:1528143763552};\\\", \\\"{x:710,y:660,t:1528143763568};\\\", \\\"{x:696,y:655,t:1528143763585};\\\", \\\"{x:682,y:651,t:1528143763602};\\\", \\\"{x:676,y:649,t:1528143763618};\\\", \\\"{x:670,y:646,t:1528143763636};\\\", \\\"{x:666,y:645,t:1528143763653};\\\", \\\"{x:660,y:642,t:1528143763668};\\\", \\\"{x:656,y:642,t:1528143763685};\\\", \\\"{x:650,y:641,t:1528143763702};\\\", \\\"{x:645,y:640,t:1528143763718};\\\", \\\"{x:632,y:637,t:1528143763735};\\\", \\\"{x:625,y:636,t:1528143763752};\\\", \\\"{x:616,y:633,t:1528143763767};\\\", \\\"{x:609,y:631,t:1528143763785};\\\", \\\"{x:602,y:629,t:1528143763802};\\\", \\\"{x:596,y:627,t:1528143763818};\\\", \\\"{x:593,y:625,t:1528143763835};\\\", \\\"{x:590,y:622,t:1528143763852};\\\", \\\"{x:587,y:619,t:1528143763867};\\\", \\\"{x:581,y:614,t:1528143763885};\\\", \\\"{x:573,y:608,t:1528143763902};\\\", \\\"{x:560,y:603,t:1528143763918};\\\", \\\"{x:540,y:598,t:1528143763935};\\\", \\\"{x:529,y:595,t:1528143763952};\\\", \\\"{x:522,y:595,t:1528143763968};\\\", \\\"{x:509,y:595,t:1528143763985};\\\", \\\"{x:497,y:595,t:1528143764002};\\\", \\\"{x:482,y:593,t:1528143764019};\\\", \\\"{x:468,y:592,t:1528143764034};\\\", \\\"{x:458,y:590,t:1528143764051};\\\", \\\"{x:451,y:590,t:1528143764069};\\\", \\\"{x:444,y:590,t:1528143764084};\\\", \\\"{x:437,y:590,t:1528143764102};\\\", \\\"{x:429,y:590,t:1528143764119};\\\", \\\"{x:423,y:590,t:1528143764135};\\\", \\\"{x:414,y:589,t:1528143764152};\\\", \\\"{x:408,y:588,t:1528143764170};\\\", \\\"{x:407,y:588,t:1528143764185};\\\", \\\"{x:406,y:587,t:1528143764202};\\\", \\\"{x:404,y:586,t:1528143764219};\\\", \\\"{x:404,y:585,t:1528143764246};\\\", \\\"{x:404,y:584,t:1528143764254};\\\", \\\"{x:407,y:583,t:1528143764311};\\\", \\\"{x:417,y:583,t:1528143764319};\\\", \\\"{x:450,y:583,t:1528143764336};\\\", \\\"{x:495,y:583,t:1528143764352};\\\", \\\"{x:545,y:583,t:1528143764371};\\\", \\\"{x:584,y:583,t:1528143764385};\\\", \\\"{x:611,y:583,t:1528143764402};\\\", \\\"{x:619,y:583,t:1528143764419};\\\", \\\"{x:620,y:584,t:1528143764520};\\\", \\\"{x:620,y:585,t:1528143764750};\\\", \\\"{x:611,y:593,t:1528143764758};\\\", \\\"{x:602,y:602,t:1528143764769};\\\", \\\"{x:572,y:623,t:1528143764786};\\\", \\\"{x:533,y:649,t:1528143764802};\\\", \\\"{x:506,y:670,t:1528143764819};\\\", \\\"{x:497,y:684,t:1528143764836};\\\", \\\"{x:490,y:698,t:1528143764852};\\\", \\\"{x:486,y:703,t:1528143764868};\\\", \\\"{x:484,y:708,t:1528143764886};\\\", \\\"{x:481,y:718,t:1528143764902};\\\", \\\"{x:481,y:720,t:1528143765248};\\\", \\\"{x:481,y:724,t:1528143765254};\\\", \\\"{x:482,y:727,t:1528143765269};\\\", \\\"{x:485,y:736,t:1528143765286};\\\", \\\"{x:485,y:737,t:1528143765310};\\\", \\\"{x:487,y:738,t:1528143765320};\\\", \\\"{x:487,y:739,t:1528143765342};\\\", \\\"{x:487,y:740,t:1528143765407};\\\", \\\"{x:488,y:740,t:1528143765767};\\\", \\\"{x:488,y:741,t:1528143765775};\\\", \\\"{x:494,y:738,t:1528143765787};\\\", \\\"{x:503,y:728,t:1528143765803};\\\", \\\"{x:521,y:717,t:1528143765820};\\\", \\\"{x:537,y:707,t:1528143765837};\\\", \\\"{x:554,y:697,t:1528143765853};\\\", \\\"{x:575,y:690,t:1528143765871};\\\", \\\"{x:584,y:688,t:1528143765887};\\\", \\\"{x:588,y:686,t:1528143765903};\\\", \\\"{x:590,y:686,t:1528143765920};\\\", \\\"{x:592,y:685,t:1528143765937};\\\", \\\"{x:594,y:684,t:1528143765953};\\\", \\\"{x:598,y:683,t:1528143765970};\\\", \\\"{x:601,y:682,t:1528143765987};\\\", \\\"{x:605,y:680,t:1528143766004};\\\", \\\"{x:608,y:680,t:1528143766020};\\\", \\\"{x:609,y:679,t:1528143766038};\\\" ] }, { \\\"rt\\\": 9736, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 19, \\\"time_elapsed\\\": 863853, \\\"internal_node_id\\\": \\\"0.0-6.0-9.0\\\", \\\"subject\\\": \\\"K0CNH\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 15, \\\"clicks\\\": 2, \\\"explicit\\\": 2, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"K\\\", \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-M -4\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:611,y:679,t:1528143767495};\\\", \\\"{x:612,y:677,t:1528143769248};\\\", \\\"{x:621,y:677,t:1528143769257};\\\", \\\"{x:645,y:678,t:1528143769273};\\\", \\\"{x:687,y:685,t:1528143769289};\\\", \\\"{x:738,y:694,t:1528143769307};\\\", \\\"{x:790,y:701,t:1528143769322};\\\", \\\"{x:846,y:709,t:1528143769340};\\\", \\\"{x:912,y:722,t:1528143769357};\\\", \\\"{x:995,y:733,t:1528143769373};\\\", \\\"{x:1073,y:744,t:1528143769390};\\\", \\\"{x:1161,y:757,t:1528143769407};\\\", \\\"{x:1212,y:765,t:1528143769422};\\\", \\\"{x:1260,y:774,t:1528143769439};\\\", \\\"{x:1308,y:788,t:1528143769456};\\\", \\\"{x:1351,y:796,t:1528143769473};\\\", \\\"{x:1379,y:805,t:1528143769490};\\\", \\\"{x:1401,y:812,t:1528143769507};\\\", \\\"{x:1411,y:815,t:1528143769525};\\\", \\\"{x:1417,y:819,t:1528143769540};\\\", \\\"{x:1422,y:824,t:1528143769557};\\\", \\\"{x:1424,y:827,t:1528143769574};\\\", \\\"{x:1424,y:828,t:1528143769589};\\\", \\\"{x:1424,y:830,t:1528143769607};\\\", \\\"{x:1424,y:833,t:1528143769623};\\\", \\\"{x:1424,y:836,t:1528143769640};\\\", \\\"{x:1423,y:840,t:1528143769657};\\\", \\\"{x:1420,y:844,t:1528143769674};\\\", \\\"{x:1417,y:848,t:1528143769690};\\\", \\\"{x:1414,y:850,t:1528143769706};\\\", \\\"{x:1409,y:854,t:1528143769725};\\\", \\\"{x:1406,y:856,t:1528143769740};\\\", \\\"{x:1403,y:859,t:1528143769756};\\\", \\\"{x:1400,y:862,t:1528143769773};\\\", \\\"{x:1396,y:865,t:1528143769790};\\\", \\\"{x:1391,y:871,t:1528143769807};\\\", \\\"{x:1390,y:873,t:1528143769823};\\\", \\\"{x:1390,y:875,t:1528143769840};\\\", \\\"{x:1388,y:876,t:1528143769857};\\\", \\\"{x:1388,y:878,t:1528143769879};\\\", \\\"{x:1388,y:879,t:1528143769896};\\\", \\\"{x:1387,y:880,t:1528143769907};\\\", \\\"{x:1386,y:882,t:1528143769925};\\\", \\\"{x:1384,y:884,t:1528143769941};\\\", \\\"{x:1383,y:885,t:1528143769957};\\\", \\\"{x:1382,y:886,t:1528143769975};\\\", \\\"{x:1377,y:889,t:1528143769991};\\\", \\\"{x:1367,y:891,t:1528143770008};\\\", \\\"{x:1359,y:896,t:1528143770024};\\\", \\\"{x:1353,y:900,t:1528143770041};\\\", \\\"{x:1350,y:903,t:1528143770057};\\\", \\\"{x:1348,y:904,t:1528143770073};\\\", \\\"{x:1347,y:905,t:1528143770091};\\\", \\\"{x:1347,y:906,t:1528143770107};\\\", \\\"{x:1347,y:908,t:1528143770125};\\\", \\\"{x:1346,y:909,t:1528143770140};\\\", \\\"{x:1344,y:910,t:1528143770157};\\\", \\\"{x:1341,y:912,t:1528143770174};\\\", \\\"{x:1334,y:914,t:1528143770191};\\\", \\\"{x:1328,y:915,t:1528143770207};\\\", \\\"{x:1322,y:915,t:1528143770224};\\\", \\\"{x:1318,y:916,t:1528143770241};\\\", \\\"{x:1313,y:916,t:1528143770257};\\\", \\\"{x:1311,y:916,t:1528143770274};\\\", \\\"{x:1307,y:917,t:1528143770290};\\\", \\\"{x:1303,y:917,t:1528143770307};\\\", \\\"{x:1298,y:917,t:1528143770326};\\\", \\\"{x:1294,y:918,t:1528143770340};\\\", \\\"{x:1291,y:918,t:1528143770357};\\\", \\\"{x:1287,y:919,t:1528143770374};\\\", \\\"{x:1285,y:920,t:1528143770391};\\\", \\\"{x:1283,y:920,t:1528143770407};\\\", \\\"{x:1282,y:921,t:1528143770424};\\\", \\\"{x:1281,y:921,t:1528143770440};\\\", \\\"{x:1280,y:921,t:1528143770457};\\\", \\\"{x:1279,y:921,t:1528143770474};\\\", \\\"{x:1277,y:921,t:1528143770491};\\\", \\\"{x:1273,y:921,t:1528143770508};\\\", \\\"{x:1270,y:921,t:1528143770525};\\\", \\\"{x:1266,y:923,t:1528143770541};\\\", \\\"{x:1265,y:923,t:1528143770558};\\\", \\\"{x:1265,y:924,t:1528143770574};\\\", \\\"{x:1265,y:925,t:1528143770591};\\\", \\\"{x:1265,y:926,t:1528143770608};\\\", \\\"{x:1265,y:927,t:1528143770639};\\\", \\\"{x:1265,y:928,t:1528143770696};\\\", \\\"{x:1266,y:928,t:1528143770708};\\\", \\\"{x:1272,y:929,t:1528143770725};\\\", \\\"{x:1278,y:930,t:1528143770741};\\\", \\\"{x:1287,y:931,t:1528143770758};\\\", \\\"{x:1295,y:932,t:1528143770774};\\\", \\\"{x:1307,y:934,t:1528143770791};\\\", \\\"{x:1314,y:934,t:1528143770807};\\\", \\\"{x:1319,y:934,t:1528143770824};\\\", \\\"{x:1324,y:934,t:1528143770841};\\\", \\\"{x:1331,y:934,t:1528143770858};\\\", \\\"{x:1337,y:934,t:1528143770875};\\\", \\\"{x:1342,y:934,t:1528143770890};\\\", \\\"{x:1347,y:934,t:1528143770908};\\\", \\\"{x:1354,y:934,t:1528143770926};\\\", \\\"{x:1363,y:935,t:1528143770941};\\\", \\\"{x:1372,y:938,t:1528143770957};\\\", \\\"{x:1390,y:940,t:1528143770975};\\\", \\\"{x:1401,y:941,t:1528143770991};\\\", \\\"{x:1409,y:942,t:1528143771008};\\\", \\\"{x:1419,y:944,t:1528143771025};\\\", \\\"{x:1428,y:945,t:1528143771041};\\\", \\\"{x:1434,y:945,t:1528143771058};\\\", \\\"{x:1437,y:947,t:1528143771075};\\\", \\\"{x:1438,y:947,t:1528143771091};\\\", \\\"{x:1439,y:947,t:1528143771108};\\\", \\\"{x:1441,y:947,t:1528143771125};\\\", \\\"{x:1443,y:947,t:1528143771142};\\\", \\\"{x:1447,y:948,t:1528143771158};\\\", \\\"{x:1454,y:948,t:1528143771176};\\\", \\\"{x:1459,y:948,t:1528143771191};\\\", \\\"{x:1461,y:948,t:1528143771208};\\\", \\\"{x:1465,y:950,t:1528143771225};\\\", \\\"{x:1468,y:950,t:1528143771241};\\\", \\\"{x:1473,y:951,t:1528143771258};\\\", \\\"{x:1474,y:951,t:1528143771275};\\\", \\\"{x:1475,y:951,t:1528143771291};\\\", \\\"{x:1476,y:951,t:1528143771320};\\\", \\\"{x:1476,y:950,t:1528143771408};\\\", \\\"{x:1476,y:949,t:1528143771431};\\\", \\\"{x:1476,y:948,t:1528143771442};\\\", \\\"{x:1476,y:947,t:1528143771463};\\\", \\\"{x:1476,y:946,t:1528143771479};\\\", \\\"{x:1476,y:945,t:1528143771552};\\\", \\\"{x:1477,y:945,t:1528143771559};\\\", \\\"{x:1480,y:945,t:1528143771575};\\\", \\\"{x:1484,y:945,t:1528143771592};\\\", \\\"{x:1487,y:945,t:1528143771608};\\\", \\\"{x:1489,y:945,t:1528143771625};\\\", \\\"{x:1492,y:945,t:1528143771642};\\\", \\\"{x:1495,y:945,t:1528143771658};\\\", \\\"{x:1496,y:945,t:1528143771675};\\\", \\\"{x:1497,y:945,t:1528143771692};\\\", \\\"{x:1499,y:945,t:1528143771743};\\\", \\\"{x:1502,y:947,t:1528143771759};\\\", \\\"{x:1504,y:948,t:1528143771775};\\\", \\\"{x:1505,y:948,t:1528143771792};\\\", \\\"{x:1506,y:948,t:1528143771808};\\\", \\\"{x:1507,y:949,t:1528143771824};\\\", \\\"{x:1508,y:949,t:1528143771842};\\\", \\\"{x:1508,y:950,t:1528143771859};\\\", \\\"{x:1508,y:951,t:1528143771895};\\\", \\\"{x:1508,y:952,t:1528143771927};\\\", \\\"{x:1506,y:952,t:1528143771944};\\\", \\\"{x:1504,y:952,t:1528143771959};\\\", \\\"{x:1503,y:952,t:1528143771975};\\\", \\\"{x:1502,y:952,t:1528143771992};\\\", \\\"{x:1500,y:952,t:1528143772009};\\\", \\\"{x:1497,y:952,t:1528143772025};\\\", \\\"{x:1495,y:954,t:1528143772042};\\\", \\\"{x:1491,y:954,t:1528143772059};\\\", \\\"{x:1489,y:955,t:1528143772075};\\\", \\\"{x:1487,y:955,t:1528143772092};\\\", \\\"{x:1486,y:955,t:1528143772111};\\\", \\\"{x:1486,y:956,t:1528143772344};\\\", \\\"{x:1486,y:957,t:1528143772391};\\\", \\\"{x:1485,y:958,t:1528143772431};\\\", \\\"{x:1484,y:958,t:1528143772442};\\\", \\\"{x:1483,y:958,t:1528143772459};\\\", \\\"{x:1482,y:958,t:1528143772478};\\\", \\\"{x:1481,y:958,t:1528143772542};\\\", \\\"{x:1480,y:958,t:1528143772582};\\\", \\\"{x:1480,y:957,t:1528143773112};\\\", \\\"{x:1480,y:956,t:1528143773759};\\\", \\\"{x:1479,y:956,t:1528143773856};\\\", \\\"{x:1479,y:955,t:1528143773896};\\\", \\\"{x:1479,y:954,t:1528143773919};\\\", \\\"{x:1478,y:953,t:1528143773927};\\\", \\\"{x:1477,y:953,t:1528143773950};\\\", \\\"{x:1475,y:952,t:1528143773959};\\\", \\\"{x:1473,y:951,t:1528143773976};\\\", \\\"{x:1470,y:950,t:1528143773992};\\\", \\\"{x:1465,y:947,t:1528143774010};\\\", \\\"{x:1460,y:944,t:1528143774026};\\\", \\\"{x:1456,y:942,t:1528143774043};\\\", \\\"{x:1448,y:936,t:1528143774060};\\\", \\\"{x:1437,y:929,t:1528143774076};\\\", \\\"{x:1422,y:906,t:1528143774093};\\\", \\\"{x:1406,y:881,t:1528143774110};\\\", \\\"{x:1378,y:849,t:1528143774126};\\\", \\\"{x:1349,y:830,t:1528143774143};\\\", \\\"{x:1323,y:814,t:1528143774160};\\\", \\\"{x:1289,y:798,t:1528143774177};\\\", \\\"{x:1242,y:778,t:1528143774193};\\\", \\\"{x:1200,y:760,t:1528143774210};\\\", \\\"{x:1180,y:752,t:1528143774226};\\\", \\\"{x:1175,y:749,t:1528143774244};\\\", \\\"{x:1171,y:747,t:1528143774260};\\\", \\\"{x:1168,y:745,t:1528143774277};\\\", \\\"{x:1163,y:743,t:1528143774294};\\\", \\\"{x:1154,y:737,t:1528143774310};\\\", \\\"{x:1134,y:730,t:1528143774326};\\\", \\\"{x:1119,y:725,t:1528143774343};\\\", \\\"{x:1105,y:720,t:1528143774360};\\\", \\\"{x:1084,y:714,t:1528143774376};\\\", \\\"{x:1058,y:702,t:1528143774393};\\\", \\\"{x:1026,y:689,t:1528143774410};\\\", \\\"{x:979,y:668,t:1528143774427};\\\", \\\"{x:952,y:659,t:1528143774444};\\\", \\\"{x:932,y:651,t:1528143774460};\\\", \\\"{x:916,y:646,t:1528143774477};\\\", \\\"{x:909,y:642,t:1528143774495};\\\", \\\"{x:904,y:640,t:1528143774509};\\\", \\\"{x:885,y:635,t:1528143774526};\\\", \\\"{x:870,y:634,t:1528143774543};\\\", \\\"{x:854,y:631,t:1528143774560};\\\", \\\"{x:836,y:629,t:1528143774577};\\\", \\\"{x:814,y:626,t:1528143774594};\\\", \\\"{x:789,y:621,t:1528143774610};\\\", \\\"{x:771,y:619,t:1528143774627};\\\", \\\"{x:762,y:618,t:1528143774643};\\\", \\\"{x:753,y:616,t:1528143774660};\\\", \\\"{x:744,y:616,t:1528143774677};\\\", \\\"{x:731,y:616,t:1528143774693};\\\", \\\"{x:705,y:616,t:1528143774711};\\\", \\\"{x:694,y:616,t:1528143774727};\\\", \\\"{x:681,y:615,t:1528143774743};\\\", \\\"{x:673,y:614,t:1528143774761};\\\", \\\"{x:664,y:611,t:1528143774778};\\\", \\\"{x:656,y:610,t:1528143774793};\\\", \\\"{x:647,y:606,t:1528143774811};\\\", \\\"{x:641,y:605,t:1528143774827};\\\", \\\"{x:640,y:604,t:1528143774844};\\\", \\\"{x:638,y:602,t:1528143774861};\\\", \\\"{x:636,y:601,t:1528143774877};\\\", \\\"{x:635,y:598,t:1528143774893};\\\", \\\"{x:632,y:595,t:1528143774910};\\\", \\\"{x:631,y:594,t:1528143774927};\\\", \\\"{x:631,y:592,t:1528143774944};\\\", \\\"{x:630,y:591,t:1528143774960};\\\", \\\"{x:630,y:590,t:1528143775182};\\\", \\\"{x:626,y:586,t:1528143775194};\\\", \\\"{x:611,y:580,t:1528143775210};\\\", \\\"{x:591,y:575,t:1528143775228};\\\", \\\"{x:563,y:568,t:1528143775245};\\\", \\\"{x:537,y:560,t:1528143775262};\\\", \\\"{x:518,y:556,t:1528143775278};\\\", \\\"{x:504,y:554,t:1528143775294};\\\", \\\"{x:498,y:554,t:1528143775312};\\\", \\\"{x:491,y:554,t:1528143775328};\\\", \\\"{x:486,y:554,t:1528143775344};\\\", \\\"{x:482,y:555,t:1528143775362};\\\", \\\"{x:478,y:557,t:1528143775377};\\\", \\\"{x:474,y:558,t:1528143775395};\\\", \\\"{x:466,y:559,t:1528143775412};\\\", \\\"{x:457,y:564,t:1528143775428};\\\", \\\"{x:447,y:569,t:1528143775445};\\\", \\\"{x:434,y:574,t:1528143775462};\\\", \\\"{x:423,y:577,t:1528143775479};\\\", \\\"{x:420,y:578,t:1528143775494};\\\", \\\"{x:416,y:580,t:1528143775511};\\\", \\\"{x:415,y:581,t:1528143775550};\\\", \\\"{x:415,y:583,t:1528143775862};\\\", \\\"{x:416,y:588,t:1528143775878};\\\", \\\"{x:418,y:596,t:1528143775895};\\\", \\\"{x:424,y:611,t:1528143775912};\\\", \\\"{x:430,y:625,t:1528143775929};\\\", \\\"{x:438,y:639,t:1528143775945};\\\", \\\"{x:445,y:651,t:1528143775962};\\\", \\\"{x:450,y:662,t:1528143775979};\\\", \\\"{x:453,y:672,t:1528143775994};\\\", \\\"{x:454,y:682,t:1528143776011};\\\", \\\"{x:457,y:695,t:1528143776029};\\\", \\\"{x:459,y:705,t:1528143776045};\\\", \\\"{x:462,y:714,t:1528143776062};\\\", \\\"{x:467,y:722,t:1528143776078};\\\", \\\"{x:469,y:730,t:1528143776095};\\\", \\\"{x:471,y:735,t:1528143776113};\\\", \\\"{x:474,y:739,t:1528143776128};\\\", \\\"{x:478,y:741,t:1528143776145};\\\", \\\"{x:479,y:742,t:1528143776161};\\\", \\\"{x:481,y:743,t:1528143776178};\\\", \\\"{x:483,y:745,t:1528143776195};\\\", \\\"{x:484,y:745,t:1528143776211};\\\", \\\"{x:487,y:745,t:1528143776310};\\\", \\\"{x:488,y:745,t:1528143776318};\\\", \\\"{x:493,y:745,t:1528143776328};\\\", \\\"{x:498,y:746,t:1528143776345};\\\", \\\"{x:502,y:747,t:1528143776361};\\\", \\\"{x:506,y:749,t:1528143776378};\\\", \\\"{x:505,y:749,t:1528143776759};\\\", \\\"{x:504,y:749,t:1528143776767};\\\" ] }, { \\\"rt\\\": 82645, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 20, \\\"time_elapsed\\\": 947765, \\\"internal_node_id\\\": \\\"0.0-7.0-0.0\\\", \\\"subject\\\": \\\"K0CNH\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\", \\\"q\\\": 16, \\\"answer\\\": \\\"You can determine which shifts occur at 12 by seeing which points on the line coming out of 12 towards the right. Breaks that occur at 12pm are points on the horizontal line above 12pm.\\\", \\\"block\\\": \\\"triangular_testing\\\" }, { \\\"rt\\\": 7222, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"19\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"USA\\\\\\\"}\\\", \\\"block\\\": \\\"demo-1\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 21, \\\"time_elapsed\\\": 955991, \\\"internal_node_id\\\": \\\"0.0-8.0\\\", \\\"subject\\\": \\\"K0CNH\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\" }, { \\\"rt\\\": 9421, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"English\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"Second\\\\\\\",\\\\\\\"Q2\\\\\\\":\\\\\\\"Social Sciences (incl. CogSci)\\\\\\\",\\\\\\\"Q3\\\\\\\":\\\\\\\"Male\\\\\\\"}\\\", \\\"block\\\": \\\"demo-2\\\", \\\"trial_type\\\": \\\"survey-multi-choice\\\", \\\"trial_index\\\": 22, \\\"time_elapsed\\\": 966429, \\\"internal_node_id\\\": \\\"0.0-9.0\\\", \\\"subject\\\": \\\"K0CNH\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\" }, { \\\"rt\\\": 8218, \\\"url\\\": \\\"../views/src/external/debrief.html\\\", \\\"block\\\": \\\"debrief\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 23, \\\"time_elapsed\\\": 975972, \\\"internal_node_id\\\": \\\"0.0-10.0\\\", \\\"subject\\\": \\\"K0CNH\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\" } ]\",\"parentNode\":{\"id\":2765}}],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"META\",\"attributes\":{\"charset\":\"utf-8\"}},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":8,\"id\":59},{\"nodeType\":3,\"id\":60,\"textContent\":\" \"},{\"nodeType\":1,\"id\":61,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":62,\"textContent\":\" \"},{\"nodeType\":1,\"id\":63,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":64,\"textContent\":\" \"},{\"nodeType\":1,\"id\":65,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":66,\"textContent\":\" \"},{\"nodeType\":1,\"id\":67,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":68,\"textContent\":\" \"},{\"nodeType\":1,\"id\":69,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":70,\"textContent\":\" \"},{\"nodeType\":1,\"id\":71,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":72,\"textContent\":\" \"},{\"nodeType\":1,\"id\":73,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"stimulus\"},\"childNodes\":[{\"nodeType\":3,\"id\":74,\"textContent\":\" \"},{\"nodeType\":1,\"id\":75,\"tagName\":\"P\",\"attributes\":{\"class\":\"userid\",\"id\":\"userid\"},\"childNodes\":[{\"nodeType\":3,\"id\":76,\"textContent\":\"K0CNH\"}]},{\"nodeType\":3,\"id\":77,\"textContent\":\" \"},{\"nodeType\":1,\"id\":78,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"userinput\"},\"childNodes\":[{\"nodeType\":3,\"id\":79,\"textContent\":\" \"},{\"nodeType\":8,\"id\":80},{\"nodeType\":3,\"id\":81,\"textContent\":\" \"},{\"nodeType\":1,\"id\":82,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"legend\",\"id\":\"hint-interactive\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":83,\"textContent\":\" \"},{\"nodeType\":1,\"id\":84,\"tagName\":\"P\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":85,\"textContent\":\"Hint: Hover your mouse over the data points in the graph\"}]},{\"nodeType\":3,\"id\":86,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":87,\"textContent\":\" \"},{\"nodeType\":8,\"id\":88},{\"nodeType\":3,\"id\":89,\"textContent\":\" \"},{\"nodeType\":8,\"id\":90},{\"nodeType\":3,\"id\":91,\"textContent\":\" \"},{\"nodeType\":1,\"id\":92,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"test\"},\"childNodes\":[{\"nodeType\":3,\"id\":93,\"textContent\":\" \"},{\"nodeType\":1,\"id\":94,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":95,\"textContent\":\" \"},{\"nodeType\":1,\"id\":96,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":97,\"textContent\":\"Which shift(s) start at 11 am? \"}]},{\"nodeType\":3,\"id\":98,\"textContent\":\" \"},{\"nodeType\":1,\"id\":99,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":100,\"textContent\":\" \"},{\"nodeType\":1,\"id\":101,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":102,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":103,\"textContent\":\" \"},{\"nodeType\":1,\"id\":104,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":105,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":106,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":107,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":108,\"textContent\":\" \"},{\"nodeType\":1,\"id\":109,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":110,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":111,\"textContent\":\" \"},{\"nodeType\":1,\"id\":112,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":113,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":115,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":116,\"textContent\":\" \"},{\"nodeType\":1,\"id\":117,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":118,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":120,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":121,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":122,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":123,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":125,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":126,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":127,\"textContent\":\" \"},{\"nodeType\":1,\"id\":128,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":129,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":130,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":132,\"textContent\":\" \"},{\"nodeType\":1,\"id\":133,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":134,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":135,\"textContent\":\" \"},{\"nodeType\":1,\"id\":136,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":137,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":138,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":140,\"textContent\":\" \"},{\"nodeType\":1,\"id\":141,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":142,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":143,\"textContent\":\" \"},{\"nodeType\":1,\"id\":144,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":145,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":146,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":147,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":148,\"textContent\":\" \"},{\"nodeType\":1,\"id\":149,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":150,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":151,\"textContent\":\" \"},{\"nodeType\":1,\"id\":152,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":153,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":154,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":156,\"textContent\":\" \"},{\"nodeType\":1,\"id\":157,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":158,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":159,\"textContent\":\" \"},{\"nodeType\":1,\"id\":160,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":161,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":162,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":163,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":164,\"textContent\":\" \"},{\"nodeType\":1,\"id\":165,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":166,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":167,\"textContent\":\" \"},{\"nodeType\":1,\"id\":168,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":169,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":170,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":171,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":172,\"textContent\":\" \"},{\"nodeType\":1,\"id\":173,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":174,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":175,\"textContent\":\" \"},{\"nodeType\":1,\"id\":176,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":177,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":178,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":179,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":180,\"textContent\":\" \"},{\"nodeType\":1,\"id\":181,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":182,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":183,\"textContent\":\" \"},{\"nodeType\":1,\"id\":184,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":185,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":186,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":187,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":188,\"textContent\":\" \"},{\"nodeType\":1,\"id\":189,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":190,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":191,\"textContent\":\" \"},{\"nodeType\":1,\"id\":192,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":193,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":194,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":196,\"textContent\":\" \"},{\"nodeType\":1,\"id\":197,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":198,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":200,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":201,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":202,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":203,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":205,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":206,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":207,\"textContent\":\" \"},{\"nodeType\":1,\"id\":208,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":209,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":210,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":211,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":212,\"textContent\":\" \"},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":214,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":215,\"textContent\":\" \"},{\"nodeType\":1,\"id\":216,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":217,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":218,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":219,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":220,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":221,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":223,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":224,\"textContent\":\" \"},{\"nodeType\":1,\"id\":225,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":226,\"textContent\":\"Which shift(s) start at the same time as D?\"}]},{\"nodeType\":3,\"id\":227,\"textContent\":\" \"},{\"nodeType\":1,\"id\":228,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":229,\"textContent\":\" \"},{\"nodeType\":1,\"id\":230,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":231,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":232,\"textContent\":\" \"},{\"nodeType\":1,\"id\":233,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":234,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":235,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":236,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":237,\"textContent\":\" \"},{\"nodeType\":1,\"id\":238,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":239,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":240,\"textContent\":\" \"},{\"nodeType\":1,\"id\":241,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":242,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":243,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":244,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":245,\"textContent\":\" \"},{\"nodeType\":1,\"id\":246,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":247,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":248,\"textContent\":\" \"},{\"nodeType\":1,\"id\":249,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":250,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":251,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":252,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":253,\"textContent\":\" \"},{\"nodeType\":1,\"id\":254,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":255,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":256,\"textContent\":\" \"},{\"nodeType\":1,\"id\":257,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":258,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":259,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":260,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":261,\"textContent\":\" \"},{\"nodeType\":1,\"id\":262,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":263,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":264,\"textContent\":\" \"},{\"nodeType\":1,\"id\":265,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":266,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":267,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":268,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":269,\"textContent\":\" \"},{\"nodeType\":1,\"id\":270,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":271,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":273,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":274,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":275,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":276,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":278,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":279,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":280,\"textContent\":\" \"},{\"nodeType\":1,\"id\":281,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":282,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":283,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":284,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":286,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":287,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":288,\"textContent\":\" \"},{\"nodeType\":1,\"id\":289,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":290,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":291,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":292,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":293,\"textContent\":\" \"},{\"nodeType\":1,\"id\":294,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":295,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":296,\"textContent\":\" \"},{\"nodeType\":1,\"id\":297,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":298,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":299,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":300,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":301,\"textContent\":\" \"},{\"nodeType\":1,\"id\":302,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":303,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":304,\"textContent\":\" \"},{\"nodeType\":1,\"id\":305,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":306,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":307,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":308,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":309,\"textContent\":\" \"},{\"nodeType\":1,\"id\":310,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":311,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":312,\"textContent\":\" \"},{\"nodeType\":1,\"id\":313,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":314,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":315,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":316,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":317,\"textContent\":\" \"},{\"nodeType\":1,\"id\":318,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":319,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":320,\"textContent\":\" \"},{\"nodeType\":1,\"id\":321,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":322,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":323,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":324,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":325,\"textContent\":\" \"},{\"nodeType\":1,\"id\":326,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":327,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":328,\"textContent\":\" \"},{\"nodeType\":1,\"id\":329,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":330,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":331,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":332,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":333,\"textContent\":\" \"},{\"nodeType\":1,\"id\":334,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":335,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":336,\"textContent\":\" \"},{\"nodeType\":1,\"id\":337,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":338,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":339,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":340,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":341,\"textContent\":\" \"},{\"nodeType\":1,\"id\":342,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":343,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":344,\"textContent\":\" \"},{\"nodeType\":1,\"id\":345,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":346,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":347,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":348,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":349,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":351,\"textContent\":\" \"},{\"nodeType\":1,\"id\":352,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":353,\"textContent\":\" \"},{\"nodeType\":1,\"id\":354,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":355,\"textContent\":\"Which shift(s) begin when C ends?\"}]},{\"nodeType\":3,\"id\":356,\"textContent\":\" \"},{\"nodeType\":1,\"id\":357,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":358,\"textContent\":\" \"},{\"nodeType\":1,\"id\":359,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":360,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":361,\"textContent\":\" \"},{\"nodeType\":1,\"id\":362,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":363,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":364,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":365,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":366,\"textContent\":\" \"},{\"nodeType\":1,\"id\":367,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":368,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":369,\"textContent\":\" \"},{\"nodeType\":1,\"id\":370,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":371,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":372,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":373,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":374,\"textContent\":\" \"},{\"nodeType\":1,\"id\":375,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":376,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":377,\"textContent\":\" \"},{\"nodeType\":1,\"id\":378,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":379,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":380,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":381,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":382,\"textContent\":\" \"},{\"nodeType\":1,\"id\":383,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":384,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":385,\"textContent\":\" \"},{\"nodeType\":1,\"id\":386,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":387,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":388,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":389,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":390,\"textContent\":\" \"},{\"nodeType\":1,\"id\":391,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":392,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":393,\"textContent\":\" \"},{\"nodeType\":1,\"id\":394,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":395,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":396,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":397,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":398,\"textContent\":\" \"},{\"nodeType\":1,\"id\":399,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":400,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":401,\"textContent\":\" \"},{\"nodeType\":1,\"id\":402,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":403,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":404,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":405,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":406,\"textContent\":\" \"},{\"nodeType\":1,\"id\":407,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":408,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":409,\"textContent\":\" \"},{\"nodeType\":1,\"id\":410,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":411,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":412,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":413,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":414,\"textContent\":\" \"},{\"nodeType\":1,\"id\":415,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":416,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":417,\"textContent\":\" \"},{\"nodeType\":1,\"id\":418,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":419,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":420,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":421,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":422,\"textContent\":\" \"},{\"nodeType\":1,\"id\":423,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":424,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":425,\"textContent\":\" \"},{\"nodeType\":1,\"id\":426,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":427,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":428,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":429,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":430,\"textContent\":\" \"},{\"nodeType\":1,\"id\":431,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":432,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":433,\"textContent\":\" \"},{\"nodeType\":1,\"id\":434,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":435,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":436,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":437,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":438,\"textContent\":\" \"},{\"nodeType\":1,\"id\":439,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":440,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":441,\"textContent\":\" \"},{\"nodeType\":1,\"id\":442,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":443,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":444,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":445,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":446,\"textContent\":\" \"},{\"nodeType\":1,\"id\":447,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":448,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":449,\"textContent\":\" \"},{\"nodeType\":1,\"id\":450,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":451,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":452,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":453,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":454,\"textContent\":\" \"},{\"nodeType\":1,\"id\":455,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":456,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":457,\"textContent\":\" \"},{\"nodeType\":1,\"id\":458,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":459,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":460,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":461,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":462,\"textContent\":\" \"},{\"nodeType\":1,\"id\":463,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":464,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":465,\"textContent\":\" \"},{\"nodeType\":1,\"id\":466,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":467,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":468,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":469,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":470,\"textContent\":\" \"},{\"nodeType\":1,\"id\":471,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":472,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":473,\"textContent\":\" \"},{\"nodeType\":1,\"id\":474,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":475,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":476,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":477,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":478,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":479,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":480,\"textContent\":\" \"},{\"nodeType\":1,\"id\":481,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":483,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":484,\"textContent\":\" Which shift(s) end at 4 pm?\"}]},{\"nodeType\":3,\"id\":485,\"textContent\":\" \"},{\"nodeType\":1,\"id\":486,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":492,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":500,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":503,\"textContent\":\" \"},{\"nodeType\":1,\"id\":504,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":505,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":506,\"textContent\":\" \"},{\"nodeType\":1,\"id\":507,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":508,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":509,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":510,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":511,\"textContent\":\" \"},{\"nodeType\":1,\"id\":512,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":513,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":514,\"textContent\":\" \"},{\"nodeType\":1,\"id\":515,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":516,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":517,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":518,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":519,\"textContent\":\" \"},{\"nodeType\":1,\"id\":520,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":521,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":522,\"textContent\":\" \"},{\"nodeType\":1,\"id\":523,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":524,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":525,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":526,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":527,\"textContent\":\" \"},{\"nodeType\":1,\"id\":528,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":529,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":530,\"textContent\":\" \"},{\"nodeType\":1,\"id\":531,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":532,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":533,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":534,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":535,\"textContent\":\" \"},{\"nodeType\":1,\"id\":536,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":537,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":538,\"textContent\":\" \"},{\"nodeType\":1,\"id\":539,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":540,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":541,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":542,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":543,\"textContent\":\" \"},{\"nodeType\":1,\"id\":544,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":545,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":546,\"textContent\":\" \"},{\"nodeType\":1,\"id\":547,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":548,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":549,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":550,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":551,\"textContent\":\" \"},{\"nodeType\":1,\"id\":552,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":553,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":554,\"textContent\":\" \"},{\"nodeType\":1,\"id\":555,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":556,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":557,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":558,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":559,\"textContent\":\" \"},{\"nodeType\":1,\"id\":560,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":561,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":562,\"textContent\":\" \"},{\"nodeType\":1,\"id\":563,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":564,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":565,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":566,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":567,\"textContent\":\" \"},{\"nodeType\":1,\"id\":568,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":569,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":570,\"textContent\":\" \"},{\"nodeType\":1,\"id\":571,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":572,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":573,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":574,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":575,\"textContent\":\" \"},{\"nodeType\":1,\"id\":576,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":577,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":578,\"textContent\":\" \"},{\"nodeType\":1,\"id\":579,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":580,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":581,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":582,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":583,\"textContent\":\" \"},{\"nodeType\":1,\"id\":584,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":585,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":586,\"textContent\":\" \"},{\"nodeType\":1,\"id\":587,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":588,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":589,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":590,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":592,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":593,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":594,\"textContent\":\" \"},{\"nodeType\":1,\"id\":595,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":596,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":597,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":598,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":599,\"textContent\":\" \"},{\"nodeType\":1,\"id\":600,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":601,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":602,\"textContent\":\" \"},{\"nodeType\":1,\"id\":603,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":604,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":605,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":606,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":607,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":608,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":609,\"textContent\":\" \"},{\"nodeType\":1,\"id\":610,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":612,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":613,\"textContent\":\"Coffee breaks happen halfway through a shift.\"},{\"nodeType\":1,\"id\":614,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":615,\"textContent\":\" Which shift(s) share a break with I?\"}]},{\"nodeType\":3,\"id\":616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":617,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":618,\"textContent\":\" \"},{\"nodeType\":1,\"id\":619,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":620,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":621,\"textContent\":\" \"},{\"nodeType\":1,\"id\":622,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":623,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":624,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":625,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":626,\"textContent\":\" \"},{\"nodeType\":1,\"id\":627,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":628,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":629,\"textContent\":\" \"},{\"nodeType\":1,\"id\":630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":631,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":632,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":633,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":634,\"textContent\":\" \"},{\"nodeType\":1,\"id\":635,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":636,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":637,\"textContent\":\" \"},{\"nodeType\":1,\"id\":638,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":639,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":640,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":641,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":642,\"textContent\":\" \"},{\"nodeType\":1,\"id\":643,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":644,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":645,\"textContent\":\" \"},{\"nodeType\":1,\"id\":646,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":647,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":648,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":649,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":650,\"textContent\":\" \"},{\"nodeType\":1,\"id\":651,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":653,\"textContent\":\" \"},{\"nodeType\":1,\"id\":654,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":655,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":656,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":657,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":659,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":660,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":661,\"textContent\":\" \"},{\"nodeType\":1,\"id\":662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":663,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":664,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":665,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":666,\"textContent\":\" \"},{\"nodeType\":1,\"id\":667,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":668,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":669,\"textContent\":\" \"},{\"nodeType\":1,\"id\":670,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":671,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":672,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":673,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":674,\"textContent\":\" \"},{\"nodeType\":1,\"id\":675,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":676,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":677,\"textContent\":\" \"},{\"nodeType\":1,\"id\":678,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":679,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":680,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":681,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":682,\"textContent\":\" \"},{\"nodeType\":1,\"id\":683,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":685,\"textContent\":\" \"},{\"nodeType\":1,\"id\":686,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":687,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":688,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":689,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":690,\"textContent\":\" \"},{\"nodeType\":1,\"id\":691,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":692,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":693,\"textContent\":\" \"},{\"nodeType\":1,\"id\":694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":695,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":696,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":697,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":698,\"textContent\":\" \"},{\"nodeType\":1,\"id\":699,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":700,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":701,\"textContent\":\" \"},{\"nodeType\":1,\"id\":702,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":703,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":704,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":705,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":706,\"textContent\":\" \"},{\"nodeType\":1,\"id\":707,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":708,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":709,\"textContent\":\" \"},{\"nodeType\":1,\"id\":710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":711,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":712,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":713,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":714,\"textContent\":\" \"},{\"nodeType\":1,\"id\":715,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":716,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":717,\"textContent\":\" \"},{\"nodeType\":1,\"id\":718,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":719,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":720,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":721,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":722,\"textContent\":\" \"},{\"nodeType\":1,\"id\":723,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":724,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":725,\"textContent\":\" \"},{\"nodeType\":1,\"id\":726,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":727,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":728,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":729,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":730,\"textContent\":\" \"},{\"nodeType\":1,\"id\":731,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":732,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":733,\"textContent\":\" \"},{\"nodeType\":1,\"id\":734,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":735,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":736,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":737,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":738,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":739,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":741,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":742,\"textContent\":\" \"},{\"nodeType\":1,\"id\":743,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":744,\"textContent\":\"Which shift(s) are six hours long?\"}]},{\"nodeType\":3,\"id\":745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":746,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":747,\"textContent\":\" \"},{\"nodeType\":1,\"id\":748,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":749,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":750,\"textContent\":\" \"},{\"nodeType\":1,\"id\":751,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":752,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":753,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":754,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":755,\"textContent\":\" \"},{\"nodeType\":1,\"id\":756,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":757,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":758,\"textContent\":\" \"},{\"nodeType\":1,\"id\":759,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":760,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":761,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":762,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":763,\"textContent\":\" \"},{\"nodeType\":1,\"id\":764,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":765,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":766,\"textContent\":\" \"},{\"nodeType\":1,\"id\":767,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":768,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":769,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":770,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":771,\"textContent\":\" \"},{\"nodeType\":1,\"id\":772,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":773,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":774,\"textContent\":\" \"},{\"nodeType\":1,\"id\":775,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":776,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":777,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":778,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":779,\"textContent\":\" \"},{\"nodeType\":1,\"id\":780,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":781,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":782,\"textContent\":\" \"},{\"nodeType\":1,\"id\":783,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":784,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":785,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":786,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":787,\"textContent\":\" \"},{\"nodeType\":1,\"id\":788,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":789,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":790,\"textContent\":\" \"},{\"nodeType\":1,\"id\":791,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":792,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":793,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":794,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":795,\"textContent\":\" \"},{\"nodeType\":1,\"id\":796,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":797,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":798,\"textContent\":\" \"},{\"nodeType\":1,\"id\":799,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":800,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":801,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":802,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":803,\"textContent\":\" \"},{\"nodeType\":1,\"id\":804,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":805,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":806,\"textContent\":\" \"},{\"nodeType\":1,\"id\":807,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":808,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":809,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":810,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":812,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":813,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":814,\"textContent\":\" \"},{\"nodeType\":1,\"id\":815,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":816,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":817,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":818,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":819,\"textContent\":\" \"},{\"nodeType\":1,\"id\":820,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":821,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":822,\"textContent\":\" \"},{\"nodeType\":1,\"id\":823,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":824,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":825,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":826,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":827,\"textContent\":\" \"},{\"nodeType\":1,\"id\":828,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":829,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":830,\"textContent\":\" \"},{\"nodeType\":1,\"id\":831,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":832,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":833,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":834,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":835,\"textContent\":\" \"},{\"nodeType\":1,\"id\":836,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":837,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":838,\"textContent\":\" \"},{\"nodeType\":1,\"id\":839,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":840,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":841,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":842,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":843,\"textContent\":\" \"},{\"nodeType\":1,\"id\":844,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":845,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":846,\"textContent\":\" \"},{\"nodeType\":1,\"id\":847,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":848,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":849,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":850,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":851,\"textContent\":\" \"},{\"nodeType\":1,\"id\":852,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":853,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":854,\"textContent\":\" \"},{\"nodeType\":1,\"id\":855,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":856,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":857,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":858,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":859,\"textContent\":\" \"},{\"nodeType\":1,\"id\":860,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":861,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":862,\"textContent\":\" \"},{\"nodeType\":1,\"id\":863,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":864,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":865,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":866,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":867,\"textContent\":\" \"},{\"nodeType\":1,\"id\":868,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":869,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":870,\"textContent\":\" \"},{\"nodeType\":1,\"id\":871,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":872,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":873,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":874,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":875,\"textContent\":\" \"},{\"nodeType\":1,\"id\":876,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":877,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":878,\"textContent\":\" \"},{\"nodeType\":1,\"id\":879,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":880,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":881,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":882,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":883,\"textContent\":\" \"},{\"nodeType\":1,\"id\":884,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":885,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":886,\"textContent\":\" \"},{\"nodeType\":1,\"id\":887,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":888,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":889,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":890,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":891,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":892,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":894,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":895,\"textContent\":\" \"},{\"nodeType\":1,\"id\":896,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":897,\"textContent\":\"Which 2 shifts less than 5 hours long start at the same time?\"}]},{\"nodeType\":3,\"id\":898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":899,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":900,\"textContent\":\" \"},{\"nodeType\":1,\"id\":901,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":902,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":903,\"textContent\":\" \"},{\"nodeType\":1,\"id\":904,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":905,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":906,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":907,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":908,\"textContent\":\" \"},{\"nodeType\":1,\"id\":909,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":910,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":911,\"textContent\":\" \"},{\"nodeType\":1,\"id\":912,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":913,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":914,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":915,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":916,\"textContent\":\" \"},{\"nodeType\":1,\"id\":917,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":918,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":919,\"textContent\":\" \"},{\"nodeType\":1,\"id\":920,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":921,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":922,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":923,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":924,\"textContent\":\" \"},{\"nodeType\":1,\"id\":925,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":926,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":927,\"textContent\":\" \"},{\"nodeType\":1,\"id\":928,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":929,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":930,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":931,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":932,\"textContent\":\" \"},{\"nodeType\":1,\"id\":933,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":934,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":935,\"textContent\":\" \"},{\"nodeType\":1,\"id\":936,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":937,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":938,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":939,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":940,\"textContent\":\" \"},{\"nodeType\":1,\"id\":941,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":942,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":943,\"textContent\":\" \"},{\"nodeType\":1,\"id\":944,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":945,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":946,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":947,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":948,\"textContent\":\" \"},{\"nodeType\":1,\"id\":949,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":950,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":951,\"textContent\":\" \"},{\"nodeType\":1,\"id\":952,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":953,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":954,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":955,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":956,\"textContent\":\" \"},{\"nodeType\":1,\"id\":957,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":958,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":959,\"textContent\":\" \"},{\"nodeType\":1,\"id\":960,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":961,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":962,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":963,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":965,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":966,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":967,\"textContent\":\" \"},{\"nodeType\":1,\"id\":968,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":969,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":970,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":971,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":972,\"textContent\":\" \"},{\"nodeType\":1,\"id\":973,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":974,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":975,\"textContent\":\" \"},{\"nodeType\":1,\"id\":976,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":977,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":978,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":979,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":980,\"textContent\":\" \"},{\"nodeType\":1,\"id\":981,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":982,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":983,\"textContent\":\" \"},{\"nodeType\":1,\"id\":984,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":985,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":986,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":987,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":988,\"textContent\":\" \"},{\"nodeType\":1,\"id\":989,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":990,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":991,\"textContent\":\" \"},{\"nodeType\":1,\"id\":992,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":993,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":994,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":995,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":996,\"textContent\":\" \"},{\"nodeType\":1,\"id\":997,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":998,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":999,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1000,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1001,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1002,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1003,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1004,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1005,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1006,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1007,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1008,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1009,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1010,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1011,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1012,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1013,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1014,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1015,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1016,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1017,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1018,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1019,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1020,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1021,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1022,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1023,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1024,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1025,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1026,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1027,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1028,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1029,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1030,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1031,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1032,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1033,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1034,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1035,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1036,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1037,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1038,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1039,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1040,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1041,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1042,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1043,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1044,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1045,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1047,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+contained\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1048,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1049,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1050,\"textContent\":\"Which shift(s) under 7 hours long starts before B starts, and ends after X ends?\"}]},{\"nodeType\":3,\"id\":1051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1052,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1053,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1054,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1055,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1056,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1057,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1058,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1059,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1060,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1061,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1062,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1063,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1064,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1065,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1066,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1067,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1068,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1069,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1070,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1071,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1072,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1073,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1074,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1075,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1076,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1077,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1078,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1079,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1080,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1081,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1082,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1083,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1084,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1085,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1086,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1087,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1088,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1089,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1090,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1091,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1092,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1093,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1094,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1095,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1096,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1097,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1098,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1099,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1100,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1101,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1102,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1103,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1104,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1105,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1106,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1107,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1108,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1109,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1110,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1111,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1112,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1113,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1114,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1115,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1116,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1118,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1119,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1120,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1121,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1122,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1123,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1124,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1125,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1126,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1127,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1128,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1129,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1130,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1131,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1132,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1133,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1134,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1135,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1136,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1137,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1138,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1139,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1140,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1141,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1142,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1143,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1144,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1145,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1146,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1147,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1148,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1149,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1150,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1151,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1152,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1153,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1154,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1155,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1156,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1157,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1158,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1159,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1160,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1161,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1162,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1163,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1164,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1165,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1166,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1167,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1168,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1169,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1170,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1171,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1172,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1173,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1174,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1175,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1176,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1177,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1178,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1179,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1180,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1181,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1182,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1183,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1184,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1185,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1186,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1187,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1188,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1189,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1190,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1191,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1192,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1193,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1194,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1195,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1196,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1197,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1198,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1200,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime+before+endtime+during\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1202,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1203,\"textContent\":\"Which shift(s) begins before J begins and ends during B?\"}]},{\"nodeType\":3,\"id\":1204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1205,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1211,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1219,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1227,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1235,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1243,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1251,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1259,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1267,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1270,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1271,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1272,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1273,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1274,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1275,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1276,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1277,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1278,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1279,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1280,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1281,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1282,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1283,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1284,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1285,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1286,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1287,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1288,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1289,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1290,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1291,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1292,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1293,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1294,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1295,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1296,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1298,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1299,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1300,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1301,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1302,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1303,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1304,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1305,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1306,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1307,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1308,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1309,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1310,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1311,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1312,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1313,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1314,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1315,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1316,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1317,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1318,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1319,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1320,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1321,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1322,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1323,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1324,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1325,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1326,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1327,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1328,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1329,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1330,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1331,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1332,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1333,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1334,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1335,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1336,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1337,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1338,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1339,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1340,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1341,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1342,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1343,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1344,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1345,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1346,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1347,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1348,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1349,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1351,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1352,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1353,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.ends\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1354,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1355,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1356,\"textContent\":\"Which shift(s) end at the same time as F?\"}]},{\"nodeType\":3,\"id\":1357,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1358,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1359,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1360,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1361,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1362,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1363,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1364,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1365,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1366,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1367,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1368,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1369,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1370,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1371,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1372,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1373,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1374,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1375,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1376,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1377,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1378,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1379,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1380,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1381,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1382,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1383,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1384,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1385,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1386,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1387,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1388,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1389,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1390,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1391,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1392,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1393,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1394,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1395,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1396,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1397,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1398,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1399,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1400,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1401,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1402,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1403,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1404,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1405,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1406,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1407,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1408,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1409,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1410,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1411,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1412,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1413,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1414,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1415,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1416,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1417,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1418,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1419,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1420,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1421,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1422,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1423,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1424,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1425,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1426,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1427,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1428,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1429,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1430,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1431,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1432,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1433,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1434,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1435,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1436,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1437,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1438,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1439,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1440,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1441,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1442,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1443,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1444,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1445,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1446,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1447,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1448,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1449,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1450,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1451,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1452,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1453,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1454,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1455,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1456,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1457,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1458,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1459,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1460,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1461,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1462,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1463,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1464,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1465,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1466,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1467,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1468,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1469,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1470,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1471,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1472,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1473,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1474,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1475,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1476,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1477,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1478,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1479,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1480,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1481,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1483,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1484,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1485,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1486,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1492,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1500,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1503,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1504,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1505,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1506,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1507,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1508,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1509,\"textContent\":\"Which shift(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":1510,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1511,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1512,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1513,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1514,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1515,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1516,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1517,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1518,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1519,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1520,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1521,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1522,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1523,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1524,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1525,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1526,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1527,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1528,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1529,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1530,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1531,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1532,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1533,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1534,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1535,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1536,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1537,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1538,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1539,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1540,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1541,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1542,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1543,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1544,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1545,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1546,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1547,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1548,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1549,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1550,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1551,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1552,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1553,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1554,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1555,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1556,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1557,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1558,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1559,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1560,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1561,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1562,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1563,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1564,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1565,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1566,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1567,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1568,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1569,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1570,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1571,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1572,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1573,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1574,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1575,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1576,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1577,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1578,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1579,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1580,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1581,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1582,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1583,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1584,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1585,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1586,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1587,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1588,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1589,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1590,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1591,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1592,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1593,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1594,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1595,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1596,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1597,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1598,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1599,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1600,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1601,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1602,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1603,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1604,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1605,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1606,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1607,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1608,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1609,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1610,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1612,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1613,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1614,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1615,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1617,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1618,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1619,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1620,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1621,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1622,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1623,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1624,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1625,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1627,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1628,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1629,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1630,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1631,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1632,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1633,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1634,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1635,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1636,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1637,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1638,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1639,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1640,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1641,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1642,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1643,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1644,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1645,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1646,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1647,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1648,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1649,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1650,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1651,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1652,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1653,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1654,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1655,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1656,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1657,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1659,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1660,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1661,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1662,\"textContent\":\"Which shift(s) start at the same time as F?\"}]},{\"nodeType\":3,\"id\":1663,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1664,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1665,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1666,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1667,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1668,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1669,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1670,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1671,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1672,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1673,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1674,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1675,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1676,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1677,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1678,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1679,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1680,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1681,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1682,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1683,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1684,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1686,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1687,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1688,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1689,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1690,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1691,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1692,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1693,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1694,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1695,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1696,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1697,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1698,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1699,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1700,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1701,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1702,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1703,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1704,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1705,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1706,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1707,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1708,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1709,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1710,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1711,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1712,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1713,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1714,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1715,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1716,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1717,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1718,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1720,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1721,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1722,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1723,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1724,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1725,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1726,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1727,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1728,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1729,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1730,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1731,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1732,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1733,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1734,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1735,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1736,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1737,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1738,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1739,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1741,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1742,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1743,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1744,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1746,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1747,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1748,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1749,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1750,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1751,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1752,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1753,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1754,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1755,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1756,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1757,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1758,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1759,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1760,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1761,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1762,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1763,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1764,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1765,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1766,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1767,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1768,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1769,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1770,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1771,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1772,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1773,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1774,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1775,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1776,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1777,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1778,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1779,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1780,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1781,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1782,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1783,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1784,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1785,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1786,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1787,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1788,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1789,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1790,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1791,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1792,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1793,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1794,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1795,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1796,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1797,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1798,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1799,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1800,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1801,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1802,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1803,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1804,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1805,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1806,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1807,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1808,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1809,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1810,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1812,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1813,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1814,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1815,\"textContent\":\"Which 2 shifts end when Z begins?\"}]},{\"nodeType\":3,\"id\":1816,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1817,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1818,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1819,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1820,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1821,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1822,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1823,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1824,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1825,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1826,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1827,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1828,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1829,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1830,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1831,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1832,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1833,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1834,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1835,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1836,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1837,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1838,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1839,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1840,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1841,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1842,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1843,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1844,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1845,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1846,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1847,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1848,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1849,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1850,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1851,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1852,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1853,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1854,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1855,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1856,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1857,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1858,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1859,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1860,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1861,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1862,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1863,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1864,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1865,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1866,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1867,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1868,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1869,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1870,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1871,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1872,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1873,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1874,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1875,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1876,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1877,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1878,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1879,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1880,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1881,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1882,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1883,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1884,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1885,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1886,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1887,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1888,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1889,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1890,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1891,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1892,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1894,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1895,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1896,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1897,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1899,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1900,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1901,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1902,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1903,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1904,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1905,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1906,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1907,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1908,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1909,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1910,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1911,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1912,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1913,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1914,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1915,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1916,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1917,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1918,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1919,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1920,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1921,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1922,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1923,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1924,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1925,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1926,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1927,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1928,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1929,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1930,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1931,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1932,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1933,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1934,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1935,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1936,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1937,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1938,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1939,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1940,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1941,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1942,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1943,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1944,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1945,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1946,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1947,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1948,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1949,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1950,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1951,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1952,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1953,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1954,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1955,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1956,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1957,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1958,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1959,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1960,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1961,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1962,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1963,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1965,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1966,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1967,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1968,\"textContent\":\"Which shift(s) end at 3pm?\"}]},{\"nodeType\":3,\"id\":1969,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1970,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1971,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1972,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1973,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1974,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1975,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1976,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1977,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1978,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1979,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1980,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1981,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1982,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1983,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1984,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1985,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1986,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1987,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1988,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1989,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1990,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1991,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1992,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1993,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1994,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1995,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1996,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1997,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1998,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1999,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2000,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2001,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2002,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2003,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2004,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2005,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2006,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2007,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2008,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2009,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2010,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2011,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2012,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2013,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2014,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2015,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2016,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2017,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2018,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2019,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2020,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2021,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2022,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2023,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2024,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2025,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2026,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2027,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2028,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2029,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2030,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2031,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2032,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2033,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2034,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2035,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2036,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2037,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2038,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2039,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2040,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2041,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2042,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2043,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2044,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2045,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2047,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2048,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2049,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2050,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2052,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2053,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2054,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2055,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2056,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2057,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2058,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2059,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2060,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2061,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2062,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2063,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2064,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2065,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2066,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2067,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2068,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2069,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2070,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2071,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2072,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2073,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2074,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2075,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2076,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2077,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2078,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2079,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2080,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2081,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2082,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2083,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2084,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2085,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2086,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2087,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2088,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2089,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2090,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2091,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2092,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2093,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2094,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2095,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2096,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2097,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2098,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2099,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2100,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2101,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2102,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2103,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2104,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2105,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2106,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2107,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2108,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2109,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2110,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2111,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2112,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2113,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2114,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2115,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2116,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2118,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":2119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2120,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2121,\"textContent\":\"Coffee breaks happen halfway through a shift. \"},{\"nodeType\":1,\"id\":2122,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":2123,\"textContent\":\"Which shifts share a break at 2pm?\"}]},{\"nodeType\":3,\"id\":2124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2125,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":2126,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2127,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2128,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2129,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2130,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2131,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":2132,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2133,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2134,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2135,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2136,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2137,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2138,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2139,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":2140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2141,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2142,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2143,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2144,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2145,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2146,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2147,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":2148,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2149,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2150,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2151,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2152,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2153,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2154,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2155,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2156,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2157,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2158,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2159,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2160,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2161,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2162,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2163,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2164,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2165,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2166,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2167,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2168,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2169,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2170,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2171,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2172,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2173,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2174,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2175,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2176,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2177,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2178,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2179,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2180,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2181,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2182,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2183,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2184,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2185,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2186,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2187,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2188,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2189,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2190,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2191,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2192,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2193,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2194,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2195,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2196,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2197,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2198,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2199,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2200,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2202,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2203,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2204,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2205,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2211,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2219,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2227,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2235,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2243,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2251,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2259,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2267,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2270,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2271,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2273,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\".strategy\",\"style\":\"display: block;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2274,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2275,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2276,\"textContent\":\"Please describe how to determine what event(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":2277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2278,\"tagName\":\"TEXTAREA\",\"attributes\":{\"id\":\"strategyAnswer\",\"rows\":\"5\",\"cols\":\"80\"}},{\"nodeType\":3,\"id\":2279,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2280,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2281,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2282},{\"nodeType\":3,\"id\":2283,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2284},{\"nodeType\":3,\"id\":2285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2286,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"fixbottom\"},\"childNodes\":[{\"nodeType\":3,\"id\":2287,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2288,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"testingButton\",\"style\":\"display:none;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2289,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2290,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2291,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"strategyButton\",\"style\":\"display: block;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2292,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2293,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2294,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2295,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2296},{\"nodeType\":3,\"id\":2297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2298,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"d3container\"},\"childNodes\":[{\"nodeType\":1,\"id\":2299,\"tagName\":\"svg\",\"attributes\":{\"width\":\"930\",\"height\":\"915\"},\"childNodes\":[{\"nodeType\":1,\"id\":2300,\"tagName\":\"g\",\"attributes\":{\"transform\":\"translate(100,25)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2301,\"tagName\":\"g\",\"attributes\":{\"class\":\"leaders\"}},{\"nodeType\":1,\"id\":2302,\"tagName\":\"g\",\"attributes\":{\"class\":\"static-scaffold\"}},{\"nodeType\":1,\"id\":2303,\"tagName\":\"g\",\"attributes\":{\"class\":\"xaxis\",\"transform\":\"translate(0,800)\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"middle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2304,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M0.5,6V0.5H800.5V6\"}},{\"nodeType\":1,\"id\":2305,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2306,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2307,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2308,\"textContent\":\"08 AM\"}]}]},{\"nodeType\":1,\"id\":2309,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(33.83333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2310,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2311,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2312,\"textContent\":\"08:30\"}]}]},{\"nodeType\":1,\"id\":2313,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(67.16666666666666,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2314,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2315,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2316,\"textContent\":\"09 AM\"}]}]},{\"nodeType\":1,\"id\":2317,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(100.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2318,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2319,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2320,\"textContent\":\"09:30\"}]}]},{\"nodeType\":1,\"id\":2321,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(133.83333333333331,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2322,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2323,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2324,\"textContent\":\"10 AM\"}]}]},{\"nodeType\":1,\"id\":2325,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(167.16666666666669,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2326,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2327,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2328,\"textContent\":\"10:30\"}]}]},{\"nodeType\":1,\"id\":2329,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(200.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2330,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2331,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2332,\"textContent\":\"11 AM\"}]}]},{\"nodeType\":1,\"id\":2333,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(233.83333333333334,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2334,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2335,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2336,\"textContent\":\"11:30\"}]}]},{\"nodeType\":1,\"id\":2337,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(267.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2338,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2339,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2340,\"textContent\":\"12 PM\"}]}]},{\"nodeType\":1,\"id\":2341,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(300.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2342,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2343,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2344,\"textContent\":\"12:30\"}]}]},{\"nodeType\":1,\"id\":2345,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(333.83333333333337,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2346,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2347,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2348,\"textContent\":\"01 PM\"}]}]},{\"nodeType\":1,\"id\":2349,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(367.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2350,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2351,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2352,\"textContent\":\"01:30\"}]}]},{\"nodeType\":1,\"id\":2353,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(400.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2354,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2355,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2356,\"textContent\":\"02 PM\"}]}]},{\"nodeType\":1,\"id\":2357,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(433.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2358,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2359,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2360,\"textContent\":\"02:30\"}]}]},{\"nodeType\":1,\"id\":2361,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(467.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2362,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2363,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2364,\"textContent\":\"03 PM\"}]}]},{\"nodeType\":1,\"id\":2365,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(500.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2366,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2367,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2368,\"textContent\":\"03:30\"}]}]},{\"nodeType\":1,\"id\":2369,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(533.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2370,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2371,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2372,\"textContent\":\"04 PM\"}]}]},{\"nodeType\":1,\"id\":2373,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(567.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2374,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2375,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2376,\"textContent\":\"04:30\"}]}]},{\"nodeType\":1,\"id\":2377,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(600.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2378,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2379,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2380,\"textContent\":\"05 PM\"}]}]},{\"nodeType\":1,\"id\":2381,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(633.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2382,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2383,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2384,\"textContent\":\"05:30\"}]}]},{\"nodeType\":1,\"id\":2385,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(667.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2386,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2387,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2388,\"textContent\":\"06 PM\"}]}]},{\"nodeType\":1,\"id\":2389,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(700.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2390,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2391,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2392,\"textContent\":\"06:30\"}]}]},{\"nodeType\":1,\"id\":2393,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(733.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2394,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2395,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2396,\"textContent\":\"07 PM\"}]}]},{\"nodeType\":1,\"id\":2397,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(767.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2398,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2399,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2400,\"textContent\":\"07:30\"}]}]},{\"nodeType\":1,\"id\":2401,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(800.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2402,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2403,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2404,\"textContent\":\"08 PM\"}]}]},{\"nodeType\":1,\"id\":2405,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2406,\"tagName\":\"text\",\"attributes\":{\"x\":\"533.3333333333334\",\"y\":\"80\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2407,\"textContent\":\"START & END TIME (time of day)\"}]}]}]},{\"nodeType\":1,\"id\":2408,\"tagName\":\"g\",\"attributes\":{\"class\":\"yaxis\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"end\"},\"childNodes\":[{\"nodeType\":1,\"id\":2409,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M-15,800.5H0.5V0.5H-15\"}},{\"nodeType\":1,\"id\":2410,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,800.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2411,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2412,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2413,\"textContent\":\"0\"}]}]},{\"nodeType\":1,\"id\":2414,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,733.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2415,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2416,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2417,\"textContent\":\"1\"}]}]},{\"nodeType\":1,\"id\":2418,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,667.1666666666667)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2419,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2420,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2421,\"textContent\":\"2\"}]}]},{\"nodeType\":1,\"id\":2422,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,600.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2423,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2424,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2425,\"textContent\":\"3\"}]}]},{\"nodeType\":1,\"id\":2426,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,533.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2427,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2428,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2429,\"textContent\":\"4\"}]}]},{\"nodeType\":1,\"id\":2430,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,467.16666666666663)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2431,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2432,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2433,\"textContent\":\"5\"}]}]},{\"nodeType\":1,\"id\":2434,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,400.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2435,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2436,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2437,\"textContent\":\"6\"}]}]},{\"nodeType\":1,\"id\":2438,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,333.8333333333333)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2439,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2440,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2441,\"textContent\":\"7\"}]}]},{\"nodeType\":1,\"id\":2442,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,267.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2443,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2444,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2445,\"textContent\":\"8\"}]}]},{\"nodeType\":1,\"id\":2446,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,200.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2447,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2448,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2449,\"textContent\":\"9\"}]}]},{\"nodeType\":1,\"id\":2450,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,133.83333333333326)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2451,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2452,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2453,\"textContent\":\"10\"}]}]},{\"nodeType\":1,\"id\":2454,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,67.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2455,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2456,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2457,\"textContent\":\"11\"}]}]},{\"nodeType\":1,\"id\":2458,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,0.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2459,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2460,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2461,\"textContent\":\"12\"}]}]},{\"nodeType\":1,\"id\":2462,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2463,\"tagName\":\"text\",\"attributes\":{\"transform\":\"rotate(-90)\",\"x\":\"-350\",\"y\":\"-60\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2464,\"textContent\":\"DURATION (in hours)\"}]}]}]},{\"nodeType\":1,\"id\":2465,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2466,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2467,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"733.3333333333334\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2468,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2469,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"666.6666666666667\",\"y2\":\"666.6666666666667\"}}]},{\"nodeType\":1,\"id\":2470,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2471,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"600\",\"y2\":\"600\"}}]},{\"nodeType\":1,\"id\":2472,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2473,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"533.3333333333334\",\"y2\":\"533.3333333333334\"}}]},{\"nodeType\":1,\"id\":2474,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2475,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"466.66666666666663\",\"y2\":\"466.66666666666663\"}}]},{\"nodeType\":1,\"id\":2476,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2477,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"400\",\"y2\":\"400\"}}]},{\"nodeType\":1,\"id\":2478,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2479,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"333.3333333333333\",\"y2\":\"333.3333333333333\"}}]},{\"nodeType\":1,\"id\":2480,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2481,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"266.66666666666674\",\"y2\":\"266.66666666666674\"}}]},{\"nodeType\":1,\"id\":2482,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2483,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"200\",\"y2\":\"200\"}}]},{\"nodeType\":1,\"id\":2484,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2485,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"133.33333333333326\",\"y2\":\"133.33333333333326\"}}]},{\"nodeType\":1,\"id\":2486,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2487,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"66.66666666666674\",\"y2\":\"66.66666666666674\"}}]},{\"nodeType\":1,\"id\":2488,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2489,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"0\",\"y2\":\"0\"}}]}]},{\"nodeType\":1,\"id\":2490,\"tagName\":\"g\",\"attributes\":{\"class\":\"xgrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2491,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"0\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2492,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"800\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2493,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"433.3333333333333\",\"y2\":\"66.66666666666674\"}},{\"nodeType\":1,\"id\":2494,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"366.66666666666663\",\"y2\":\"66.66666666666674\"}},{\"nodeType\":1,\"id\":2495,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"466.6666666666667\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2496,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"333.33333333333337\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2497,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"500\",\"y2\":\"200\"}},{\"nodeType\":1,\"id\":2498,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"300\",\"y2\":\"200\"}},{\"nodeType\":1,\"id\":2499,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"533.3333333333333\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2500,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"266.66666666666663\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2501,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"566.6666666666667\",\"y2\":\"333.3333333333333\"}},{\"nodeType\":1,\"id\":2502,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"233.33333333333334\",\"y2\":\"333.3333333333333\"}},{\"nodeType\":1,\"id\":2503,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"600\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2504,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"200\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2505,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"633.3333333333333\",\"y2\":\"466.66666666666663\"}},{\"nodeType\":1,\"id\":2506,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"166.66666666666669\",\"y2\":\"466.66666666666663\"}},{\"nodeType\":1,\"id\":2507,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"666.6666666666667\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2508,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"133.33333333333331\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2509,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"700\",\"y2\":\"600\"}},{\"nodeType\":1,\"id\":2510,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"100\",\"y2\":\"600\"}},{\"nodeType\":1,\"id\":2511,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"733.3333333333333\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2512,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"66.66666666666666\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2513,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"766.6666666666667\",\"y2\":\"733.3333333333334\"}},{\"nodeType\":1,\"id\":2514,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"33.33333333333333\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2515,\"tagName\":\"g\",\"attributes\":{\"class\":\"data\"},\"childNodes\":[{\"nodeType\":1,\"id\":2516,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2517,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"266.66666666666674\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2518,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"258.66666666666674\"},\"childNodes\":[{\"nodeType\":3,\"id\":2519,\"textContent\":\"A \"}]}]},{\"nodeType\":1,\"id\":2520,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2521,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2522,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2523,\"textContent\":\"B \"}]}]},{\"nodeType\":1,\"id\":2524,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2525,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"366.66666666666663\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2526,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"361.66666666666663\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2527,\"textContent\":\"C \"}]}]},{\"nodeType\":1,\"id\":2528,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2529,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"666.6666666666667\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2530,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"661.6666666666667\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2531,\"textContent\":\"D \"}]}]},{\"nodeType\":1,\"id\":2532,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2533,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"200\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2534,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"195\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2535,\"textContent\":\"E \"}]}]},{\"nodeType\":1,\"id\":2536,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2537,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2538,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2539,\"textContent\":\"F \"}]}]},{\"nodeType\":1,\"id\":2540,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2541,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2542,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2543,\"textContent\":\"G \"}]}]},{\"nodeType\":1,\"id\":2544,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2545,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2546,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2547,\"textContent\":\"H \"}]}]},{\"nodeType\":1,\"id\":2548,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2549,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"100\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2550,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"95\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2551,\"textContent\":\"I \"}]}]},{\"nodeType\":1,\"id\":2552,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2553,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"133.33333333333331\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2554,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"128.33333333333331\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2555,\"textContent\":\"J \"}]}]},{\"nodeType\":1,\"id\":2556,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2557,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"133.33333333333326\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2558,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"125.33333333333326\"},\"childNodes\":[{\"nodeType\":3,\"id\":2559,\"textContent\":\"K \"}]}]},{\"nodeType\":1,\"id\":2560,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2561,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"333.3333333333333\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2562,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"325.3333333333333\"},\"childNodes\":[{\"nodeType\":3,\"id\":2563,\"textContent\":\"L \"}]}]},{\"nodeType\":1,\"id\":2564,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2565,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"300\",\"cy\":\"733.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2566,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"295\",\"y\":\"725.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2567,\"textContent\":\"M \"}]}]},{\"nodeType\":1,\"id\":2568,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2569,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"600\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2570,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"595\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2571,\"textContent\":\"N \"}]}]},{\"nodeType\":1,\"id\":2572,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2573,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"433.3333333333333\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2574,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"428.3333333333333\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2575,\"textContent\":\"O \"}]}]},{\"nodeType\":1,\"id\":2576,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2577,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"200\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2578,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"192\"},\"childNodes\":[{\"nodeType\":3,\"id\":2579,\"textContent\":\"P \"}]}]},{\"nodeType\":1,\"id\":2580,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2581,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"533.3333333333333\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2582,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"528.3333333333333\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2583,\"textContent\":\"Z \"}]}]},{\"nodeType\":1,\"id\":2584,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2585,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2586,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2587,\"textContent\":\"X \"}]}]}]}]}]}]},{\"nodeType\":3,\"id\":2588,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2589,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2590},{\"nodeType\":3,\"id\":2591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2592,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2593,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2594,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2595,\"textContent\":\" \"}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 227, dom: 828, initialDom: 990",
  "javascriptErrors": []
}