var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "56db894214f73d8d23c27c2c2ce243d5",
  "created": "2018-05-29T11:01:46.8230266-07:00",
  "lastActivity": "2018-05-29T11:01:54.3400266-07:00",
  "pageViews": [
    {
      "id": "05294637a1f969afb9665daf6ad19e4366538819",
      "startTime": "2018-05-29T11:01:46.8230266-07:00",
      "endTime": "2018-05-29T11:01:54.3400266-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/12",
      "visitTime": 7517,
      "engagementTime": 7514,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 7517,
  "engagementTime": 7514,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.26",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=1N858",
    "CONDITION=114",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "1d3e9f81cd084265d9b799103f767650",
  "gdpr": false
}