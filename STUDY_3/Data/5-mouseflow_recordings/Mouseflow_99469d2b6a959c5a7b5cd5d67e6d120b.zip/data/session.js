var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "99469d2b6a959c5a7b5cd5d67e6d120b",
  "created": "2018-05-29T10:06:33.5927083-07:00",
  "lastActivity": "2018-05-29T10:07:56.3277556-07:00",
  "pageViews": [
    {
      "id": "05293372bbb5ed6b6d084b4cc8fdd6d0ef28e1f2",
      "startTime": "2018-05-29T10:06:33.5927083-07:00",
      "endTime": "2018-05-29T10:07:56.3277556-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/4",
      "visitTime": 82774,
      "engagementTime": 41471,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 82774,
  "engagementTime": 41471,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.36",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=RRF03",
    "CONDITION=114",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "ff871ff5278351d4702572c835daec66",
  "gdpr": false
}