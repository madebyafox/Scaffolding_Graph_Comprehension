var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "c0f9be36c7f9cd40b3143f378b1cb25e",
  "created": "2018-05-18T10:20:06.8516693-07:00",
  "lastActivity": "2018-05-18T10:20:13.6920355-07:00",
  "pageViews": [
    {
      "id": "05180763cd3235790ecc140b0b57047efbeeb123",
      "startTime": "2018-05-18T10:20:06.8516693-07:00",
      "endTime": "2018-05-18T10:20:13.6920355-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/12",
      "visitTime": 7256,
      "engagementTime": 7256,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 7256,
  "engagementTime": 7256,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.39",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=PQN6T",
    "CONDITION=111",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "f5f5e9b570bba721f879e76924cd7dbb",
  "gdpr": false
}