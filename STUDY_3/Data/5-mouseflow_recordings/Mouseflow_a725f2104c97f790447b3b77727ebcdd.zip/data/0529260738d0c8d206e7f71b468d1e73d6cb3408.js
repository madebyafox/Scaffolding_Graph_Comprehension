var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["0529260738d0c8d206e7f71b468d1e73d6cb3408"] = {
  "startTime": "2018-05-29T17:12:26.0453775Z",
  "websitePageUrl": "/16",
  "visitTime": 52088,
  "engagementTime": 51924,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1200,
  "tags": [
    "form-interact",
    "submit"
  ],
  "session": {
    "id": "a725f2104c97f790447b3b77727ebcdd",
    "created": "2018-05-29T17:12:26.0453775+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.181",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/16",
    "tags": [
      "form-interact",
      "submit"
    ],
    "variables": [
      "SID=AZKMW",
      "CONDITION=114"
    ],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "3a1aa10305c54d570d9f2f064c6ab3ff",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/a725f2104c97f790447b3b77727ebcdd/play"
  },
  "events": [
    {
      "t": 2,
      "e": 2,
      "ty": 14,
      "x": 0,
      "y": 1199
    },
    {
      "t": 100,
      "e": 100,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 100,
      "e": 100,
      "ty": 1,
      "x": 0,
      "y": 16
    },
    {
      "t": 654,
      "e": 654,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 1494,
      "e": 1494,
      "ty": 6,
      "x": 419,
      "y": 591,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1500,
      "e": 1500,
      "ty": 2,
      "x": 419,
      "y": 591
    },
    {
      "t": 1500,
      "e": 1500,
      "ty": 41,
      "x": 36185,
      "y": 55231,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1601,
      "e": 1601,
      "ty": 2,
      "x": 385,
      "y": 530
    },
    {
      "t": 1627,
      "e": 1627,
      "ty": 7,
      "x": 385,
      "y": 515,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1700,
      "e": 1700,
      "ty": 2,
      "x": 380,
      "y": 486
    },
    {
      "t": 1751,
      "e": 1751,
      "ty": 41,
      "x": 31576,
      "y": 3515,
      "ta": "> div.stimulus > div > div:[2]"
    },
    {
      "t": 1798,
      "e": 1798,
      "ty": 6,
      "x": 388,
      "y": 542,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1800,
      "e": 1800,
      "ty": 2,
      "x": 388,
      "y": 542
    },
    {
      "t": 1877,
      "e": 1877,
      "ty": 7,
      "x": 407,
      "y": 606,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1900,
      "e": 1900,
      "ty": 2,
      "x": 407,
      "y": 606
    },
    {
      "t": 2000,
      "e": 2000,
      "ty": 41,
      "x": 34836,
      "y": 62323,
      "ta": "#.strategy"
    },
    {
      "t": 2251,
      "e": 2251,
      "ty": 41,
      "x": 34836,
      "y": 61762,
      "ta": "#.strategy"
    },
    {
      "t": 2261,
      "e": 2261,
      "ty": 6,
      "x": 406,
      "y": 603,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2300,
      "e": 2300,
      "ty": 2,
      "x": 404,
      "y": 600
    },
    {
      "t": 2401,
      "e": 2401,
      "ty": 2,
      "x": 403,
      "y": 596
    },
    {
      "t": 2501,
      "e": 2501,
      "ty": 41,
      "x": 34386,
      "y": 59277,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2622,
      "e": 2622,
      "ty": 3,
      "x": 403,
      "y": 596,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2624,
      "e": 2624,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2701,
      "e": 2701,
      "ty": 4,
      "x": 34386,
      "y": 59277,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2701,
      "e": 2701,
      "ty": 5,
      "x": 403,
      "y": 596,
      "ta": "#strategyAnswer"
    },
    {
      "t": 6114,
      "e": 6114,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 6115,
      "e": 6115,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 6233,
      "e": 6233,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "l"
    },
    {
      "t": 6530,
      "e": 6530,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 6593,
      "e": 6593,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": ""
    },
    {
      "t": 6681,
      "e": 6681,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 6761,
      "e": 6761,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": ""
    },
    {
      "t": 7074,
      "e": 7074,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 7137,
      "e": 7137,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 7138,
      "e": 7138,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 7224,
      "e": 7224,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "L"
    },
    {
      "t": 7265,
      "e": 7265,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "L"
    },
    {
      "t": 7353,
      "e": 7353,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 7353,
      "e": 7353,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 7416,
      "e": 7416,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Lo"
    },
    {
      "t": 7497,
      "e": 7497,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 7497,
      "e": 7497,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 7561,
      "e": 7561,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "75"
    },
    {
      "t": 7562,
      "e": 7562,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 7593,
      "e": 7593,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look"
    },
    {
      "t": 7674,
      "e": 7674,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 7714,
      "e": 7714,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 7715,
      "e": 7715,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 7801,
      "e": 7801,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 7801,
      "e": 7801,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 7824,
      "e": 7824,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||in"
    },
    {
      "t": 7880,
      "e": 7880,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 7881,
      "e": 7881,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 7921,
      "e": 7921,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 7953,
      "e": 7953,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 7953,
      "e": 7953,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 7969,
      "e": 7969,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 8032,
      "e": 8032,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 8032,
      "e": 8032,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8059,
      "e": 8059,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 8088,
      "e": 8088,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 8089,
      "e": 8089,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8152,
      "e": 8152,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 8168,
      "e": 8168,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 8168,
      "e": 8168,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8178,
      "e": 8178,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 8273,
      "e": 8273,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 8273,
      "e": 8273,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 8273,
      "e": 8273,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8344,
      "e": 8344,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 8345,
      "e": 8345,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8401,
      "e": 8401,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||th"
    },
    {
      "t": 8433,
      "e": 8433,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 8433,
      "e": 8433,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8473,
      "e": 8473,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 8489,
      "e": 8489,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 8489,
      "e": 8489,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8553,
      "e": 8553,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 8625,
      "e": 8625,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 8625,
      "e": 8625,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 8625,
      "e": 8625,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8713,
      "e": 8713,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 8853,
      "e": 8853,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 8853,
      "e": 8853,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8888,
      "e": 8888,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 8888,
      "e": 8888,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8945,
      "e": 8945,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ra"
    },
    {
      "t": 8993,
      "e": 8993,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 8993,
      "e": 8993,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9049,
      "e": 9049,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 9106,
      "e": 9106,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 9378,
      "e": 9378,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 9433,
      "e": 9433,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Looking at the gra"
    },
    {
      "t": 9537,
      "e": 9537,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 9593,
      "e": 9593,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Looking at the gr"
    },
    {
      "t": 9698,
      "e": 9698,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 9744,
      "e": 9744,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Looking at the g"
    },
    {
      "t": 9857,
      "e": 9857,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 9929,
      "e": 9929,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Looking at the "
    },
    {
      "t": 10000,
      "e": 10000,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 10041,
      "e": 10041,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 10097,
      "e": 10097,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Looking at the"
    },
    {
      "t": 10203,
      "e": 10203,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Looking at the"
    },
    {
      "t": 10384,
      "e": 10384,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 10385,
      "e": 10385,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10498,
      "e": 10498,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 10585,
      "e": 10585,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 10587,
      "e": 10587,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10680,
      "e": 10680,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||x"
    },
    {
      "t": 10752,
      "e": 10752,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 10753,
      "e": 10753,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10810,
      "e": 10810,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 10993,
      "e": 10993,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 11049,
      "e": 11049,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Looking at the x"
    },
    {
      "t": 11410,
      "e": 11410,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 11410,
      "e": 11410,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11497,
      "e": 11497,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 11497,
      "e": 11497,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11537,
      "e": 11537,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| a"
    },
    {
      "t": 11593,
      "e": 11593,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 11713,
      "e": 11713,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 11715,
      "e": 11715,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11809,
      "e": 11809,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 11809,
      "e": 11809,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11817,
      "e": 11817,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||xi"
    },
    {
      "t": 11921,
      "e": 11921,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 11937,
      "e": 11937,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 11937,
      "e": 11937,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11938,
      "e": 11938,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 11938,
      "e": 11938,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11993,
      "e": 11993,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||sd"
    },
    {
      "t": 11993,
      "e": 11993,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 12016,
      "e": 12016,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 12017,
      "e": 12017,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12112,
      "e": 12112,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 12298,
      "e": 12298,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 12352,
      "e": 12352,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Looking at the x axisd"
    },
    {
      "t": 12449,
      "e": 12449,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 12521,
      "e": 12521,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Looking at the x axis"
    },
    {
      "t": 12585,
      "e": 12585,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 12586,
      "e": 12586,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12666,
      "e": 12666,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 12666,
      "e": 12666,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12681,
      "e": 12681,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| a"
    },
    {
      "t": 12752,
      "e": 12752,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 12753,
      "e": 12753,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12793,
      "e": 12793,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 12849,
      "e": 12849,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 12851,
      "e": 12851,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12929,
      "e": 12929,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 12929,
      "e": 12929,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12937,
      "e": 12937,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d "
    },
    {
      "t": 12953,
      "e": 12953,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 13041,
      "e": 13041,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 13041,
      "e": 13041,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13049,
      "e": 13049,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 13104,
      "e": 13104,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 13105,
      "e": 13105,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13120,
      "e": 13120,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 13193,
      "e": 13193,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 13193,
      "e": 13193,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13249,
      "e": 13249,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 13249,
      "e": 13249,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13258,
      "e": 13258,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e "
    },
    {
      "t": 13320,
      "e": 13320,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 13353,
      "e": 13353,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 13368,
      "e": 13368,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 13369,
      "e": 13369,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13449,
      "e": 13449,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 13449,
      "e": 13449,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13496,
      "e": 13496,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ya"
    },
    {
      "t": 13552,
      "e": 13552,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 13641,
      "e": 13641,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 13642,
      "e": 13642,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13657,
      "e": 13657,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 13793,
      "e": 13793,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 13849,
      "e": 13849,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Looking at the x axis and the ya"
    },
    {
      "t": 13994,
      "e": 13994,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 14048,
      "e": 14048,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Looking at the x axis and the y"
    },
    {
      "t": 14145,
      "e": 14145,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 14145,
      "e": 14145,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14232,
      "e": 14232,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 14233,
      "e": 14233,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14249,
      "e": 14249,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| a"
    },
    {
      "t": 14306,
      "e": 14306,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 14441,
      "e": 14441,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 14442,
      "e": 14442,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14505,
      "e": 14505,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||x"
    },
    {
      "t": 14513,
      "e": 14513,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 14513,
      "e": 14513,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14593,
      "e": 14593,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 14632,
      "e": 14632,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 14633,
      "e": 14633,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14713,
      "e": 14713,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 14754,
      "e": 14754,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "190"
    },
    {
      "t": 14754,
      "e": 14754,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14865,
      "e": 14865,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 14865,
      "e": 14865,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14897,
      "e": 14897,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||. "
    },
    {
      "t": 14969,
      "e": 14969,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 16023,
      "e": 16023,
      "ty": 7,
      "x": 401,
      "y": 607,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16074,
      "e": 16074,
      "ty": 6,
      "x": 386,
      "y": 654,
      "ta": "#strategyButton"
    },
    {
      "t": 16100,
      "e": 16100,
      "ty": 2,
      "x": 385,
      "y": 657
    },
    {
      "t": 16200,
      "e": 16200,
      "ty": 2,
      "x": 384,
      "y": 671
    },
    {
      "t": 16250,
      "e": 16250,
      "ty": 41,
      "x": 24797,
      "y": 50626,
      "ta": "#strategyButton"
    },
    {
      "t": 16300,
      "e": 16300,
      "ty": 2,
      "x": 384,
      "y": 681
    },
    {
      "t": 16302,
      "e": 16302,
      "ty": 3,
      "x": 384,
      "y": 681,
      "ta": "#strategyButton"
    },
    {
      "t": 16303,
      "e": 16303,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Looking at the x axis and the y axis. "
    },
    {
      "t": 16304,
      "e": 16304,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16307,
      "e": 16308,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 16372,
      "e": 16373,
      "ty": 4,
      "x": 24797,
      "y": 50626,
      "ta": "#strategyButton"
    },
    {
      "t": 16382,
      "e": 16383,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 16384,
      "e": 16385,
      "ty": 5,
      "x": 384,
      "y": 681,
      "ta": "#strategyButton"
    },
    {
      "t": 16392,
      "e": 16393,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 17390,
      "e": 17391,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 17949,
      "e": 17950,
      "ty": 2,
      "x": 549,
      "y": 637
    },
    {
      "t": 18000,
      "e": 18001,
      "ty": 2,
      "x": 1358,
      "y": 491
    },
    {
      "t": 18000,
      "e": 18001,
      "ty": 41,
      "x": 46490,
      "y": 26756,
      "ta": "html > body"
    },
    {
      "t": 18100,
      "e": 18101,
      "ty": 2,
      "x": 1363,
      "y": 490
    },
    {
      "t": 18200,
      "e": 18201,
      "ty": 2,
      "x": 1154,
      "y": 519
    },
    {
      "t": 18250,
      "e": 18251,
      "ty": 41,
      "x": 26819,
      "y": 33824,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 18300,
      "e": 18301,
      "ty": 2,
      "x": 916,
      "y": 540
    },
    {
      "t": 18500,
      "e": 18501,
      "ty": 2,
      "x": 919,
      "y": 553
    },
    {
      "t": 18500,
      "e": 18501,
      "ty": 41,
      "x": 24007,
      "y": 44394,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 18662,
      "e": 18663,
      "ty": 3,
      "x": 919,
      "y": 553,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 18765,
      "e": 18766,
      "ty": 4,
      "x": 24007,
      "y": 44394,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 18765,
      "e": 18766,
      "ty": 5,
      "x": 919,
      "y": 553,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 18957,
      "e": 18958,
      "ty": 6,
      "x": 919,
      "y": 554,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 19000,
      "e": 19001,
      "ty": 2,
      "x": 919,
      "y": 554
    },
    {
      "t": 19000,
      "e": 19001,
      "ty": 41,
      "x": 24007,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 19100,
      "e": 19101,
      "ty": 2,
      "x": 920,
      "y": 554
    },
    {
      "t": 19251,
      "e": 19252,
      "ty": 41,
      "x": 24224,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 19270,
      "e": 19271,
      "ty": 3,
      "x": 920,
      "y": 554,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 19271,
      "e": 19272,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 19342,
      "e": 19343,
      "ty": 4,
      "x": 24224,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 19342,
      "e": 19343,
      "ty": 5,
      "x": 920,
      "y": 554,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 19501,
      "e": 19502,
      "ty": 2,
      "x": 922,
      "y": 554
    },
    {
      "t": 19501,
      "e": 19502,
      "ty": 41,
      "x": 24656,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 21014,
      "e": 21015,
      "ty": 7,
      "x": 936,
      "y": 550,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 21101,
      "e": 21102,
      "ty": 2,
      "x": 956,
      "y": 539
    },
    {
      "t": 21250,
      "e": 21251,
      "ty": 41,
      "x": 32010,
      "y": 34529,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 21385,
      "e": 21386,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "50"
    },
    {
      "t": 21386,
      "e": 21387,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 21448,
      "e": 21449,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "54"
    },
    {
      "t": 21449,
      "e": 21450,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 21505,
      "e": 21506,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "26"
    },
    {
      "t": 21576,
      "e": 21577,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "26"
    },
    {
      "t": 21713,
      "e": 21714,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "9"
    },
    {
      "t": 21714,
      "e": 21715,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "26"
    },
    {
      "t": 21714,
      "e": 21715,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 21715,
      "e": 21716,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 21825,
      "e": 21826,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": ""
    },
    {
      "t": 22473,
      "e": 22474,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "80"
    },
    {
      "t": 22474,
      "e": 22475,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 22481,
      "e": 22482,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "79"
    },
    {
      "t": 22481,
      "e": 22482,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 22513,
      "e": 22514,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "po"
    },
    {
      "t": 22545,
      "e": 22546,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "po"
    },
    {
      "t": 22874,
      "e": 22875,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "8"
    },
    {
      "t": 22913,
      "e": 22914,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "p"
    },
    {
      "t": 23009,
      "e": 23010,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "8"
    },
    {
      "t": 23081,
      "e": 23082,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": ""
    },
    {
      "t": 23203,
      "e": 23204,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": ""
    },
    {
      "t": 23448,
      "e": 23449,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "80"
    },
    {
      "t": 23448,
      "e": 23449,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 23552,
      "e": 23553,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "72"
    },
    {
      "t": 23553,
      "e": 23554,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 23576,
      "e": 23577,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "ph"
    },
    {
      "t": 23656,
      "e": 23657,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "73"
    },
    {
      "t": 23656,
      "e": 23657,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 23705,
      "e": 23706,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "phi"
    },
    {
      "t": 23761,
      "e": 23762,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "phi"
    },
    {
      "t": 23849,
      "e": 23850,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "76"
    },
    {
      "t": 23850,
      "e": 23851,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 24003,
      "e": 24004,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "phil"
    },
    {
      "t": 24017,
      "e": 24018,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "73"
    },
    {
      "t": 24018,
      "e": 24019,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 24041,
      "e": 24042,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "phili"
    },
    {
      "t": 24169,
      "e": 24170,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 24202,
      "e": 24203,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "80"
    },
    {
      "t": 24202,
      "e": 24203,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 24249,
      "e": 24250,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||p"
    },
    {
      "t": 25105,
      "e": 25106,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "8"
    },
    {
      "t": 25176,
      "e": 25177,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "phili"
    },
    {
      "t": 25272,
      "e": 25273,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "8"
    },
    {
      "t": 25403,
      "e": 25404,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "phil"
    },
    {
      "t": 25773,
      "e": 25774,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "8"
    },
    {
      "t": 25804,
      "e": 25805,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "8"
    },
    {
      "t": 25838,
      "e": 25839,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "8"
    },
    {
      "t": 25871,
      "e": 25872,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "8"
    },
    {
      "t": 25904,
      "e": 25905,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "8"
    },
    {
      "t": 25937,
      "e": 25938,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "8"
    },
    {
      "t": 25970,
      "e": 25971,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "8"
    },
    {
      "t": 26004,
      "e": 26005,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "8"
    },
    {
      "t": 26017,
      "e": 26018,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": ""
    },
    {
      "t": 26233,
      "e": 26234,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 26665,
      "e": 26666,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "80"
    },
    {
      "t": 26666,
      "e": 26667,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 26793,
      "e": 26794,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "P"
    },
    {
      "t": 26832,
      "e": 26833,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "P"
    },
    {
      "t": 27041,
      "e": 27042,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "72"
    },
    {
      "t": 27041,
      "e": 27042,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 27137,
      "e": 27138,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "73"
    },
    {
      "t": 27137,
      "e": 27138,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 27161,
      "e": 27162,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Phi"
    },
    {
      "t": 27225,
      "e": 27226,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Phi"
    },
    {
      "t": 27297,
      "e": 27298,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "76"
    },
    {
      "t": 27298,
      "e": 27299,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 27400,
      "e": 27401,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "73"
    },
    {
      "t": 27400,
      "e": 27401,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 27424,
      "e": 27425,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Phili"
    },
    {
      "t": 27562,
      "e": 27563,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 27777,
      "e": 27778,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "80"
    },
    {
      "t": 27778,
      "e": 27779,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 27832,
      "e": 27833,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||p"
    },
    {
      "t": 27912,
      "e": 27913,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "80"
    },
    {
      "t": 27913,
      "e": 27914,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 27993,
      "e": 27994,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||p"
    },
    {
      "t": 28049,
      "e": 28050,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "73"
    },
    {
      "t": 28050,
      "e": 28051,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 28153,
      "e": 28154,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||i"
    },
    {
      "t": 28273,
      "e": 28274,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "78"
    },
    {
      "t": 28274,
      "e": 28275,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 28352,
      "e": 28353,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "69"
    },
    {
      "t": 28352,
      "e": 28353,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 28376,
      "e": 28377,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||ne"
    },
    {
      "t": 28408,
      "e": 28409,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "83"
    },
    {
      "t": 28408,
      "e": 28409,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 28472,
      "e": 28473,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||s"
    },
    {
      "t": 28536,
      "e": 28537,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 29189,
      "e": 29190,
      "ty": 6,
      "x": 961,
      "y": 562,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 29198,
      "e": 29199,
      "ty": 7,
      "x": 962,
      "y": 583,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 29200,
      "e": 29201,
      "ty": 2,
      "x": 962,
      "y": 583
    },
    {
      "t": 29250,
      "e": 29251,
      "ty": 6,
      "x": 965,
      "y": 654,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 29250,
      "e": 29251,
      "ty": 41,
      "x": 33957,
      "y": 21845,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 29267,
      "e": 29268,
      "ty": 7,
      "x": 967,
      "y": 673,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 29284,
      "e": 29269,
      "ty": 6,
      "x": 967,
      "y": 689,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 29300,
      "e": 29285,
      "ty": 2,
      "x": 968,
      "y": 691
    },
    {
      "t": 29401,
      "e": 29386,
      "ty": 2,
      "x": 968,
      "y": 692
    },
    {
      "t": 29501,
      "e": 29486,
      "ty": 41,
      "x": 37148,
      "y": 31774,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 29534,
      "e": 29519,
      "ty": 3,
      "x": 968,
      "y": 692,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 29534,
      "e": 29519,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Philippines"
    },
    {
      "t": 29535,
      "e": 29520,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 29536,
      "e": 29521,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 29605,
      "e": 29590,
      "ty": 4,
      "x": 37148,
      "y": 31774,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 29605,
      "e": 29590,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 29606,
      "e": 29591,
      "ty": 5,
      "x": 968,
      "y": 692,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 29606,
      "e": 29591,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 30626,
      "e": 30611,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 31200,
      "e": 31185,
      "ty": 2,
      "x": 852,
      "y": 522
    },
    {
      "t": 31250,
      "e": 31235,
      "ty": 41,
      "x": 26551,
      "y": 18835,
      "ta": "html > body"
    },
    {
      "t": 31300,
      "e": 31285,
      "ty": 2,
      "x": 771,
      "y": 252
    },
    {
      "t": 31401,
      "e": 31386,
      "ty": 2,
      "x": 798,
      "y": 191
    },
    {
      "t": 31501,
      "e": 31486,
      "ty": 2,
      "x": 841,
      "y": 187
    },
    {
      "t": 31501,
      "e": 31486,
      "ty": 41,
      "x": 4646,
      "y": 18724,
      "ta": "#jspsych-survey-multi-choice-0 > p"
    },
    {
      "t": 31600,
      "e": 31585,
      "ty": 2,
      "x": 847,
      "y": 189
    },
    {
      "t": 31701,
      "e": 31686,
      "ty": 2,
      "x": 852,
      "y": 202
    },
    {
      "t": 31750,
      "e": 31735,
      "ty": 41,
      "x": 7256,
      "y": 17420,
      "ta": "#jspsych-survey-multi-choice-0"
    },
    {
      "t": 31801,
      "e": 31786,
      "ty": 2,
      "x": 851,
      "y": 227
    },
    {
      "t": 31900,
      "e": 31885,
      "ty": 2,
      "x": 850,
      "y": 228
    },
    {
      "t": 32001,
      "e": 31986,
      "ty": 2,
      "x": 849,
      "y": 229
    },
    {
      "t": 32001,
      "e": 31986,
      "ty": 41,
      "x": 22582,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 32101,
      "e": 32086,
      "ty": 2,
      "x": 849,
      "y": 230
    },
    {
      "t": 32201,
      "e": 32186,
      "ty": 2,
      "x": 846,
      "y": 234
    },
    {
      "t": 32251,
      "e": 32236,
      "ty": 41,
      "x": 4646,
      "y": 60853,
      "ta": "#jspsych-survey-multi-choice-option-0-0"
    },
    {
      "t": 32301,
      "e": 32286,
      "ty": 2,
      "x": 840,
      "y": 257
    },
    {
      "t": 32325,
      "e": 32310,
      "ty": 6,
      "x": 839,
      "y": 260,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 32400,
      "e": 32385,
      "ty": 2,
      "x": 838,
      "y": 267
    },
    {
      "t": 32420,
      "e": 32405,
      "ty": 7,
      "x": 837,
      "y": 275,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 32470,
      "e": 32455,
      "ty": 6,
      "x": 837,
      "y": 291,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 32501,
      "e": 32486,
      "ty": 2,
      "x": 837,
      "y": 296
    },
    {
      "t": 32501,
      "e": 32486,
      "ty": 41,
      "x": 53325,
      "y": 40329,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 32502,
      "e": 32487,
      "ty": 7,
      "x": 837,
      "y": 302,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 32536,
      "e": 32521,
      "ty": 6,
      "x": 838,
      "y": 317,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 32601,
      "e": 32586,
      "ty": 2,
      "x": 839,
      "y": 322
    },
    {
      "t": 32701,
      "e": 32686,
      "ty": 2,
      "x": 839,
      "y": 324
    },
    {
      "t": 32717,
      "e": 32702,
      "ty": 3,
      "x": 839,
      "y": 324,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 32718,
      "e": 32703,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 32751,
      "e": 32736,
      "ty": 41,
      "x": 63408,
      "y": 40329,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 32797,
      "e": 32782,
      "ty": 4,
      "x": 63408,
      "y": 40329,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 32798,
      "e": 32783,
      "ty": 5,
      "x": 839,
      "y": 324,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 32799,
      "e": 32784,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf",
      "v": "Other"
    },
    {
      "t": 33188,
      "e": 33173,
      "ty": 7,
      "x": 839,
      "y": 334,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 33201,
      "e": 33186,
      "ty": 2,
      "x": 839,
      "y": 334
    },
    {
      "t": 33251,
      "e": 33236,
      "ty": 41,
      "x": 4171,
      "y": 35108,
      "ta": "#jspsych-survey-multi-choice-1 > p"
    },
    {
      "t": 33301,
      "e": 33286,
      "ty": 2,
      "x": 839,
      "y": 387
    },
    {
      "t": 33387,
      "e": 33372,
      "ty": 6,
      "x": 839,
      "y": 409,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 33401,
      "e": 33386,
      "ty": 2,
      "x": 839,
      "y": 409
    },
    {
      "t": 33501,
      "e": 33486,
      "ty": 2,
      "x": 839,
      "y": 413
    },
    {
      "t": 33501,
      "e": 33486,
      "ty": 41,
      "x": 63408,
      "y": 25205,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 33521,
      "e": 33506,
      "ty": 7,
      "x": 839,
      "y": 422,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 33600,
      "e": 33585,
      "ty": 2,
      "x": 843,
      "y": 466
    },
    {
      "t": 33701,
      "e": 33686,
      "ty": 2,
      "x": 842,
      "y": 528
    },
    {
      "t": 33752,
      "e": 33687,
      "ty": 41,
      "x": 24081,
      "y": 36044,
      "ta": "#jspsych-survey-multi-choice-option-1-4 > label"
    },
    {
      "t": 34000,
      "e": 33935,
      "ty": 2,
      "x": 842,
      "y": 510
    },
    {
      "t": 34001,
      "e": 33936,
      "ty": 41,
      "x": 4883,
      "y": 58513,
      "ta": "#jspsych-survey-multi-choice-option-1-3"
    },
    {
      "t": 34101,
      "e": 34036,
      "ty": 2,
      "x": 842,
      "y": 458
    },
    {
      "t": 34154,
      "e": 34089,
      "ty": 6,
      "x": 837,
      "y": 415,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 34170,
      "e": 34105,
      "ty": 7,
      "x": 836,
      "y": 406,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 34200,
      "e": 34135,
      "ty": 2,
      "x": 834,
      "y": 397
    },
    {
      "t": 34250,
      "e": 34185,
      "ty": 41,
      "x": 1323,
      "y": 18724,
      "ta": "#jspsych-survey-multi-choice-1 > p"
    },
    {
      "t": 34301,
      "e": 34236,
      "ty": 2,
      "x": 826,
      "y": 356
    },
    {
      "t": 34401,
      "e": 34336,
      "ty": 2,
      "x": 838,
      "y": 381
    },
    {
      "t": 34501,
      "e": 34436,
      "ty": 2,
      "x": 845,
      "y": 397
    },
    {
      "t": 34501,
      "e": 34436,
      "ty": 41,
      "x": 5595,
      "y": 11373,
      "ta": "#jspsych-survey-multi-choice-1"
    },
    {
      "t": 35201,
      "e": 35136,
      "ty": 2,
      "x": 845,
      "y": 398
    },
    {
      "t": 35251,
      "e": 35186,
      "ty": 41,
      "x": 5595,
      "y": 11644,
      "ta": "#jspsych-survey-multi-choice-1"
    },
    {
      "t": 35701,
      "e": 35636,
      "ty": 2,
      "x": 843,
      "y": 400
    },
    {
      "t": 35751,
      "e": 35686,
      "ty": 41,
      "x": 16436,
      "y": 22937,
      "ta": "#jspsych-survey-multi-choice-option-1-1 > label"
    },
    {
      "t": 35756,
      "e": 35691,
      "ty": 6,
      "x": 837,
      "y": 447,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 35773,
      "e": 35708,
      "ty": 7,
      "x": 836,
      "y": 454,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 35800,
      "e": 35735,
      "ty": 2,
      "x": 836,
      "y": 457
    },
    {
      "t": 35805,
      "e": 35740,
      "ty": 6,
      "x": 836,
      "y": 465,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 35854,
      "e": 35789,
      "ty": 7,
      "x": 838,
      "y": 480,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 35900,
      "e": 35835,
      "ty": 2,
      "x": 839,
      "y": 483
    },
    {
      "t": 35989,
      "e": 35924,
      "ty": 6,
      "x": 838,
      "y": 494,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 36001,
      "e": 35936,
      "ty": 2,
      "x": 838,
      "y": 494
    },
    {
      "t": 36001,
      "e": 35936,
      "ty": 41,
      "x": 58367,
      "y": 10082,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 36101,
      "e": 36036,
      "ty": 2,
      "x": 836,
      "y": 501
    },
    {
      "t": 36201,
      "e": 36136,
      "ty": 2,
      "x": 834,
      "y": 504
    },
    {
      "t": 36251,
      "e": 36186,
      "ty": 41,
      "x": 38202,
      "y": 60493,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 36638,
      "e": 36573,
      "ty": 3,
      "x": 834,
      "y": 504,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 36640,
      "e": 36575,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 36641,
      "e": 36576,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 36700,
      "e": 36635,
      "ty": 4,
      "x": 38202,
      "y": 60493,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 36701,
      "e": 36636,
      "ty": 5,
      "x": 834,
      "y": 504,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 36701,
      "e": 36636,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf",
      "v": "Fourth"
    },
    {
      "t": 37102,
      "e": 37037,
      "ty": 7,
      "x": 832,
      "y": 513,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 37109,
      "e": 37044,
      "ty": 6,
      "x": 832,
      "y": 528,
      "ta": "jspsych-survey-multi-choice-response-1[4]_mf"
    },
    {
      "t": 37123,
      "e": 37058,
      "ty": 7,
      "x": 832,
      "y": 536,
      "ta": "jspsych-survey-multi-choice-response-1[4]_mf"
    },
    {
      "t": 37190,
      "e": 37125,
      "ty": 6,
      "x": 832,
      "y": 577,
      "ta": "jspsych-survey-multi-choice-response-1[6]_mf"
    },
    {
      "t": 37200,
      "e": 37135,
      "ty": 2,
      "x": 832,
      "y": 577
    },
    {
      "t": 37251,
      "e": 37186,
      "ty": 41,
      "x": 28120,
      "y": 30246,
      "ta": "jspsych-survey-multi-choice-response-1[6]_mf"
    },
    {
      "t": 37301,
      "e": 37236,
      "ty": 2,
      "x": 832,
      "y": 582
    },
    {
      "t": 38061,
      "e": 37996,
      "ty": 7,
      "x": 832,
      "y": 600,
      "ta": "jspsych-survey-multi-choice-response-1[6]_mf"
    },
    {
      "t": 38101,
      "e": 38036,
      "ty": 2,
      "x": 832,
      "y": 612
    },
    {
      "t": 38201,
      "e": 38136,
      "ty": 2,
      "x": 840,
      "y": 655
    },
    {
      "t": 38251,
      "e": 38186,
      "ty": 41,
      "x": 4409,
      "y": 10832,
      "ta": "#jspsych-survey-multi-choice-2"
    },
    {
      "t": 38401,
      "e": 38336,
      "ty": 2,
      "x": 845,
      "y": 663
    },
    {
      "t": 38501,
      "e": 38436,
      "ty": 2,
      "x": 848,
      "y": 676
    },
    {
      "t": 38501,
      "e": 38436,
      "ty": 41,
      "x": 7136,
      "y": 36044,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 38601,
      "e": 38536,
      "ty": 2,
      "x": 848,
      "y": 679
    },
    {
      "t": 38701,
      "e": 38636,
      "ty": 2,
      "x": 849,
      "y": 684
    },
    {
      "t": 38751,
      "e": 38686,
      "ty": 41,
      "x": 6782,
      "y": 60853,
      "ta": "#jspsych-survey-multi-choice-option-2-0"
    },
    {
      "t": 38801,
      "e": 38736,
      "ty": 2,
      "x": 850,
      "y": 691
    },
    {
      "t": 38901,
      "e": 38836,
      "ty": 2,
      "x": 848,
      "y": 699
    },
    {
      "t": 39000,
      "e": 38935,
      "ty": 2,
      "x": 844,
      "y": 710
    },
    {
      "t": 39001,
      "e": 38936,
      "ty": 41,
      "x": 5689,
      "y": 55704,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 39101,
      "e": 39036,
      "ty": 2,
      "x": 839,
      "y": 722
    },
    {
      "t": 39201,
      "e": 39136,
      "ty": 2,
      "x": 838,
      "y": 722
    },
    {
      "t": 39251,
      "e": 39186,
      "ty": 41,
      "x": 3658,
      "y": 3276,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 39305,
      "e": 39240,
      "ty": 2,
      "x": 830,
      "y": 714
    },
    {
      "t": 39313,
      "e": 39248,
      "ty": 6,
      "x": 827,
      "y": 704,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 39362,
      "e": 39297,
      "ty": 7,
      "x": 826,
      "y": 695,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 39405,
      "e": 39340,
      "ty": 2,
      "x": 825,
      "y": 689
    },
    {
      "t": 39505,
      "e": 39440,
      "ty": 2,
      "x": 823,
      "y": 681
    },
    {
      "t": 39505,
      "e": 39440,
      "ty": 41,
      "x": 423,
      "y": 52428,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 39605,
      "e": 39540,
      "ty": 2,
      "x": 824,
      "y": 670
    },
    {
      "t": 39754,
      "e": 39689,
      "ty": 6,
      "x": 826,
      "y": 672,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 39755,
      "e": 39690,
      "ty": 41,
      "x": 0,
      "y": 20164,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 39797,
      "e": 39732,
      "ty": 7,
      "x": 826,
      "y": 681,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 39804,
      "e": 39739,
      "ty": 2,
      "x": 826,
      "y": 681
    },
    {
      "t": 39829,
      "e": 39764,
      "ty": 6,
      "x": 830,
      "y": 700,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 39845,
      "e": 39780,
      "ty": 7,
      "x": 834,
      "y": 709,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 39905,
      "e": 39840,
      "ty": 2,
      "x": 844,
      "y": 736
    },
    {
      "t": 40004,
      "e": 39939,
      "ty": 2,
      "x": 851,
      "y": 756
    },
    {
      "t": 40004,
      "e": 39939,
      "ty": 41,
      "x": 12341,
      "y": 22937,
      "ta": "#jspsych-survey-multi-choice-option-2-3 > label"
    },
    {
      "t": 40105,
      "e": 40040,
      "ty": 2,
      "x": 843,
      "y": 793
    },
    {
      "t": 40147,
      "e": 40082,
      "ty": 6,
      "x": 836,
      "y": 808,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 40204,
      "e": 40139,
      "ty": 2,
      "x": 835,
      "y": 813
    },
    {
      "t": 40254,
      "e": 40189,
      "ty": 41,
      "x": 33161,
      "y": 35288,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 40304,
      "e": 40239,
      "ty": 2,
      "x": 833,
      "y": 815
    },
    {
      "t": 40604,
      "e": 40539,
      "ty": 2,
      "x": 833,
      "y": 816
    },
    {
      "t": 40664,
      "e": 40599,
      "ty": 7,
      "x": 834,
      "y": 802,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 40697,
      "e": 40632,
      "ty": 6,
      "x": 835,
      "y": 789,
      "ta": "jspsych-survey-multi-choice-response-2[4]_mf"
    },
    {
      "t": 40705,
      "e": 40640,
      "ty": 2,
      "x": 835,
      "y": 789
    },
    {
      "t": 40747,
      "e": 40682,
      "ty": 7,
      "x": 837,
      "y": 776,
      "ta": "jspsych-survey-multi-choice-response-2[4]_mf"
    },
    {
      "t": 40757,
      "e": 40684,
      "ty": 41,
      "x": 3697,
      "y": 7021,
      "ta": "#jspsych-survey-multi-choice-option-2-4"
    },
    {
      "t": 40804,
      "e": 40731,
      "ty": 2,
      "x": 841,
      "y": 765
    },
    {
      "t": 40904,
      "e": 40831,
      "ty": 2,
      "x": 843,
      "y": 756
    },
    {
      "t": 41004,
      "e": 40931,
      "ty": 2,
      "x": 845,
      "y": 740
    },
    {
      "t": 41004,
      "e": 40931,
      "ty": 41,
      "x": 5917,
      "y": 62258,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 41104,
      "e": 41031,
      "ty": 2,
      "x": 843,
      "y": 717
    },
    {
      "t": 41204,
      "e": 41131,
      "ty": 2,
      "x": 837,
      "y": 690
    },
    {
      "t": 41231,
      "e": 41158,
      "ty": 6,
      "x": 835,
      "y": 680,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 41254,
      "e": 41181,
      "ty": 41,
      "x": 38202,
      "y": 30246,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 41281,
      "e": 41208,
      "ty": 7,
      "x": 832,
      "y": 664,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 41305,
      "e": 41232,
      "ty": 2,
      "x": 832,
      "y": 661
    },
    {
      "t": 41406,
      "e": 41333,
      "ty": 2,
      "x": 832,
      "y": 656
    },
    {
      "t": 41505,
      "e": 41432,
      "ty": 41,
      "x": 2510,
      "y": 11103,
      "ta": "#jspsych-survey-multi-choice-2"
    },
    {
      "t": 41704,
      "e": 41631,
      "ty": 2,
      "x": 832,
      "y": 659
    },
    {
      "t": 41755,
      "e": 41682,
      "ty": 41,
      "x": 2840,
      "y": 6553,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 41765,
      "e": 41692,
      "ty": 6,
      "x": 832,
      "y": 671,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 41804,
      "e": 41731,
      "ty": 2,
      "x": 832,
      "y": 674
    },
    {
      "t": 41849,
      "e": 41776,
      "ty": 7,
      "x": 833,
      "y": 681,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 41904,
      "e": 41831,
      "ty": 2,
      "x": 833,
      "y": 684
    },
    {
      "t": 42005,
      "e": 41932,
      "ty": 2,
      "x": 836,
      "y": 692
    },
    {
      "t": 42005,
      "e": 41932,
      "ty": 41,
      "x": 3459,
      "y": 7021,
      "ta": "#jspsych-survey-multi-choice-option-2-1"
    },
    {
      "t": 42254,
      "e": 42181,
      "ty": 41,
      "x": 3673,
      "y": 6553,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 42265,
      "e": 42192,
      "ty": 6,
      "x": 836,
      "y": 697,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 42304,
      "e": 42231,
      "ty": 2,
      "x": 836,
      "y": 698
    },
    {
      "t": 42404,
      "e": 42331,
      "ty": 2,
      "x": 837,
      "y": 702
    },
    {
      "t": 42504,
      "e": 42431,
      "ty": 2,
      "x": 838,
      "y": 704
    },
    {
      "t": 42504,
      "e": 42431,
      "ty": 41,
      "x": 58367,
      "y": 40329,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 43204,
      "e": 43131,
      "ty": 2,
      "x": 838,
      "y": 705
    },
    {
      "t": 43254,
      "e": 43181,
      "ty": 41,
      "x": 58367,
      "y": 45370,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 43354,
      "e": 43281,
      "ty": 3,
      "x": 838,
      "y": 705,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 43355,
      "e": 43282,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 43355,
      "e": 43282,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 43440,
      "e": 43367,
      "ty": 4,
      "x": 58367,
      "y": 45370,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 43440,
      "e": 43367,
      "ty": 5,
      "x": 838,
      "y": 705,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 43441,
      "e": 43368,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf",
      "v": "Social Sciences (incl. CogSci)"
    },
    {
      "t": 43754,
      "e": 43681,
      "ty": 7,
      "x": 842,
      "y": 715,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 43755,
      "e": 43682,
      "ty": 41,
      "x": 4883,
      "y": 60853,
      "ta": "#jspsych-survey-multi-choice-option-2-1"
    },
    {
      "t": 43804,
      "e": 43731,
      "ty": 2,
      "x": 854,
      "y": 748
    },
    {
      "t": 43904,
      "e": 43831,
      "ty": 2,
      "x": 875,
      "y": 844
    },
    {
      "t": 44004,
      "e": 43931,
      "ty": 2,
      "x": 880,
      "y": 863
    },
    {
      "t": 44004,
      "e": 43931,
      "ty": 41,
      "x": 13902,
      "y": 52457,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 44104,
      "e": 44031,
      "ty": 2,
      "x": 875,
      "y": 871
    },
    {
      "t": 44204,
      "e": 44131,
      "ty": 2,
      "x": 863,
      "y": 899
    },
    {
      "t": 44254,
      "e": 44181,
      "ty": 41,
      "x": 7731,
      "y": 20668,
      "ta": "#jspsych-survey-multi-choice-3"
    },
    {
      "t": 44304,
      "e": 44231,
      "ty": 2,
      "x": 851,
      "y": 924
    },
    {
      "t": 44404,
      "e": 44331,
      "ty": 2,
      "x": 850,
      "y": 925
    },
    {
      "t": 44504,
      "e": 44431,
      "ty": 41,
      "x": 31214,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 44604,
      "e": 44531,
      "ty": 2,
      "x": 848,
      "y": 930
    },
    {
      "t": 44705,
      "e": 44632,
      "ty": 2,
      "x": 846,
      "y": 937
    },
    {
      "t": 44754,
      "e": 44681,
      "ty": 41,
      "x": 26845,
      "y": 39321,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 44904,
      "e": 44831,
      "ty": 2,
      "x": 843,
      "y": 937
    },
    {
      "t": 44960,
      "e": 44887,
      "ty": 3,
      "x": 843,
      "y": 938,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 44961,
      "e": 44888,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 45004,
      "e": 44931,
      "ty": 2,
      "x": 843,
      "y": 938
    },
    {
      "t": 45004,
      "e": 44931,
      "ty": 41,
      "x": 23568,
      "y": 42597,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 45097,
      "e": 45024,
      "ty": 4,
      "x": 23568,
      "y": 52428,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 45098,
      "e": 45025,
      "ty": 5,
      "x": 843,
      "y": 941,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 45099,
      "e": 45026,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 45101,
      "e": 45028,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf",
      "v": "Male"
    },
    {
      "t": 45105,
      "e": 45032,
      "ty": 2,
      "x": 843,
      "y": 941
    },
    {
      "t": 45204,
      "e": 45131,
      "ty": 2,
      "x": 842,
      "y": 945
    },
    {
      "t": 45255,
      "e": 45182,
      "ty": 41,
      "x": 16646,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 45305,
      "e": 45232,
      "ty": 2,
      "x": 848,
      "y": 974
    },
    {
      "t": 45405,
      "e": 45332,
      "ty": 2,
      "x": 850,
      "y": 974
    },
    {
      "t": 45504,
      "e": 45431,
      "ty": 41,
      "x": 6782,
      "y": 58513,
      "ta": "#jspsych-survey-multi-choice-option-3-1"
    },
    {
      "t": 45604,
      "e": 45531,
      "ty": 2,
      "x": 850,
      "y": 977
    },
    {
      "t": 45704,
      "e": 45631,
      "ty": 2,
      "x": 855,
      "y": 998
    },
    {
      "t": 45719,
      "e": 45646,
      "ty": 6,
      "x": 863,
      "y": 1009,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 45754,
      "e": 45681,
      "ty": 41,
      "x": 19367,
      "y": 19859,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 45804,
      "e": 45731,
      "ty": 2,
      "x": 871,
      "y": 1020
    },
    {
      "t": 45904,
      "e": 45831,
      "ty": 2,
      "x": 875,
      "y": 1025
    },
    {
      "t": 45994,
      "e": 45921,
      "ty": 3,
      "x": 875,
      "y": 1025,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 45996,
      "e": 45923,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 45997,
      "e": 45924,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 46005,
      "e": 45932,
      "ty": 41,
      "x": 23490,
      "y": 39718,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 46096,
      "e": 45932,
      "ty": 4,
      "x": 23490,
      "y": 39718,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 46097,
      "e": 45933,
      "ty": 5,
      "x": 875,
      "y": 1025,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 46099,
      "e": 45935,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 46100,
      "e": 45936,
      "ty": 13,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 46102,
      "e": 45938,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 47196,
      "e": 47032,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 47205,
      "e": 47041,
      "ty": 2,
      "x": 879,
      "y": 1018
    },
    {
      "t": 47255,
      "e": 47091,
      "ty": 41,
      "x": 28856,
      "y": 61609,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 47304,
      "e": 47140,
      "ty": 2,
      "x": 882,
      "y": 1013
    },
    {
      "t": 47405,
      "e": 47241,
      "ty": 2,
      "x": 883,
      "y": 1004
    },
    {
      "t": 47505,
      "e": 47341,
      "ty": 2,
      "x": 886,
      "y": 996
    },
    {
      "t": 47505,
      "e": 47341,
      "ty": 41,
      "x": 29151,
      "y": 60224,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 47610,
      "e": 47446,
      "ty": 2,
      "x": 888,
      "y": 988
    },
    {
      "t": 47705,
      "e": 47541,
      "ty": 2,
      "x": 889,
      "y": 988
    },
    {
      "t": 47754,
      "e": 47590,
      "ty": 41,
      "x": 29446,
      "y": 59670,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 47804,
      "e": 47640,
      "ty": 2,
      "x": 896,
      "y": 988
    },
    {
      "t": 47904,
      "e": 47740,
      "ty": 2,
      "x": 940,
      "y": 1001
    },
    {
      "t": 48004,
      "e": 47840,
      "ty": 2,
      "x": 732,
      "y": 957
    },
    {
      "t": 48005,
      "e": 47841,
      "ty": 41,
      "x": 21575,
      "y": 57523,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 48104,
      "e": 47940,
      "ty": 2,
      "x": 56,
      "y": 831
    },
    {
      "t": 48205,
      "e": 48041,
      "ty": 2,
      "x": 0,
      "y": 803
    },
    {
      "t": 48255,
      "e": 48091,
      "ty": 41,
      "x": 34,
      "y": 44317,
      "ta": "html"
    },
    {
      "t": 48304,
      "e": 48140,
      "ty": 2,
      "x": 47,
      "y": 794
    },
    {
      "t": 48404,
      "e": 48240,
      "ty": 2,
      "x": 528,
      "y": 897
    },
    {
      "t": 48504,
      "e": 48340,
      "ty": 2,
      "x": 1255,
      "y": 1158
    },
    {
      "t": 48505,
      "e": 48341,
      "ty": 41,
      "x": 42943,
      "y": 63706,
      "ta": "> div.masterdiv"
    },
    {
      "t": 48605,
      "e": 48441,
      "ty": 2,
      "x": 1269,
      "y": 1169
    },
    {
      "t": 48704,
      "e": 48540,
      "ty": 2,
      "x": 1217,
      "y": 1170
    },
    {
      "t": 48755,
      "e": 48591,
      "ty": 41,
      "x": 38776,
      "y": 63596,
      "ta": "> div.masterdiv"
    },
    {
      "t": 48804,
      "e": 48640,
      "ty": 2,
      "x": 1086,
      "y": 1145
    },
    {
      "t": 48904,
      "e": 48740,
      "ty": 2,
      "x": 1060,
      "y": 1133
    },
    {
      "t": 49005,
      "e": 48841,
      "ty": 6,
      "x": 1024,
      "y": 1105,
      "ta": "#start"
    },
    {
      "t": 49007,
      "e": 48843,
      "ty": 2,
      "x": 1024,
      "y": 1105
    },
    {
      "t": 49007,
      "e": 48843,
      "ty": 41,
      "x": 62531,
      "y": 62282,
      "ta": "#start"
    },
    {
      "t": 49104,
      "e": 48940,
      "ty": 2,
      "x": 953,
      "y": 1072
    },
    {
      "t": 49137,
      "e": 48973,
      "ty": 7,
      "x": 950,
      "y": 1071,
      "ta": "#start"
    },
    {
      "t": 49201,
      "e": 49037,
      "ty": 3,
      "x": 950,
      "y": 1071,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 49205,
      "e": 49041,
      "ty": 2,
      "x": 950,
      "y": 1071
    },
    {
      "t": 49254,
      "e": 49090,
      "ty": 41,
      "x": 32300,
      "y": 65418,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 49281,
      "e": 49117,
      "ty": 4,
      "x": 32300,
      "y": 65418,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 49281,
      "e": 49117,
      "ty": 5,
      "x": 950,
      "y": 1071,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 49425,
      "e": 49261,
      "ty": 6,
      "x": 951,
      "y": 1073,
      "ta": "#start"
    },
    {
      "t": 49504,
      "e": 49340,
      "ty": 2,
      "x": 954,
      "y": 1076
    },
    {
      "t": 49504,
      "e": 49340,
      "ty": 41,
      "x": 24302,
      "y": 6384,
      "ta": "#start"
    },
    {
      "t": 49657,
      "e": 49493,
      "ty": 3,
      "x": 954,
      "y": 1076,
      "ta": "#start"
    },
    {
      "t": 49658,
      "e": 49494,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 49704,
      "e": 49540,
      "ty": 2,
      "x": 955,
      "y": 1078
    },
    {
      "t": 49753,
      "e": 49589,
      "ty": 4,
      "x": 24848,
      "y": 10239,
      "ta": "#start"
    },
    {
      "t": 49753,
      "e": 49589,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 49753,
      "e": 49589,
      "ty": 5,
      "x": 955,
      "y": 1078,
      "ta": "#start"
    },
    {
      "t": 49754,
      "e": 49590,
      "ty": 38,
      "x": 8,
      "y": 0
    },
    {
      "t": 49755,
      "e": 49591,
      "ty": 41,
      "x": 32612,
      "y": 59275,
      "ta": "html > body"
    },
    {
      "t": 50255,
      "e": 50091,
      "ty": 41,
      "x": 31441,
      "y": 52073,
      "ta": "html > body"
    },
    {
      "t": 50305,
      "e": 50141,
      "ty": 2,
      "x": 817,
      "y": 669
    },
    {
      "t": 50404,
      "e": 50240,
      "ty": 2,
      "x": 510,
      "y": 16
    },
    {
      "t": 50504,
      "e": 50340,
      "ty": 2,
      "x": 488,
      "y": 16
    },
    {
      "t": 50505,
      "e": 50341,
      "ty": 41,
      "x": 16530,
      "y": 443,
      "ta": "html > body"
    },
    {
      "t": 50790,
      "e": 50626,
      "ty": 38,
      "x": 9,
      "y": 0
    },
    {
      "t": 52088,
      "e": 51924,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2311,\"tagName\":\"g\",\"attributes\":{\"class\":\"xaxis\",\"transform\":\"translate(0,800)\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"middle\"},\"previousSibling\":{\"id\":2302},\"parentNode\":{\"id\":2300}},{\"nodeType\":1,\"id\":2312,\"tagName\":\"g\",\"attributes\":{\"class\":\"yaxis\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"end\"},\"previousSibling\":{\"id\":2311},\"parentNode\":{\"id\":2300}},{\"nodeType\":1,\"id\":2313,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2312},\"parentNode\":{\"id\":2300}},{\"nodeType\":1,\"id\":2314,\"tagName\":\"g\",\"attributes\":{\"class\":\"xgrid\"},\"previousSibling\":{\"id\":2313},\"parentNode\":{\"id\":2300}},{\"nodeType\":1,\"id\":2315,\"tagName\":\"g\",\"attributes\":{\"class\":\"data\"},\"previousSibling\":{\"id\":2314},\"parentNode\":{\"id\":2300}},{\"nodeType\":1,\"id\":2316,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M0.5,6V0.5H800.5V6\"},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2317,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0.5,0)\"},\"previousSibling\":{\"id\":2316},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2318,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(33.83333333333333,0)\"},\"previousSibling\":{\"id\":2317},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2319,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(67.16666666666666,0)\"},\"previousSibling\":{\"id\":2318},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2320,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(100.5,0)\"},\"previousSibling\":{\"id\":2319},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2321,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(133.83333333333331,0)\"},\"previousSibling\":{\"id\":2320},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2322,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(167.16666666666669,0)\"},\"previousSibling\":{\"id\":2321},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2323,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(200.5,0)\"},\"previousSibling\":{\"id\":2322},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2324,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(233.83333333333334,0)\"},\"previousSibling\":{\"id\":2323},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2325,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(267.16666666666663,0)\"},\"previousSibling\":{\"id\":2324},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2326,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(300.5,0)\"},\"previousSibling\":{\"id\":2325},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2327,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(333.83333333333337,0)\"},\"previousSibling\":{\"id\":2326},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2328,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(367.16666666666663,0)\"},\"previousSibling\":{\"id\":2327},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2329,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(400.5,0)\"},\"previousSibling\":{\"id\":2328},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2330,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(433.8333333333333,0)\"},\"previousSibling\":{\"id\":2329},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2331,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(467.1666666666667,0)\"},\"previousSibling\":{\"id\":2330},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2332,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(500.5,0)\"},\"previousSibling\":{\"id\":2331},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2333,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(533.8333333333333,0)\"},\"previousSibling\":{\"id\":2332},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2334,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(567.1666666666667,0)\"},\"previousSibling\":{\"id\":2333},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2335,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(600.5,0)\"},\"previousSibling\":{\"id\":2334},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2336,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(633.8333333333333,0)\"},\"previousSibling\":{\"id\":2335},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2337,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(667.1666666666667,0)\"},\"previousSibling\":{\"id\":2336},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2338,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(700.5,0)\"},\"previousSibling\":{\"id\":2337},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2339,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(733.8333333333333,0)\"},\"previousSibling\":{\"id\":2338},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2340,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(767.1666666666667,0)\"},\"previousSibling\":{\"id\":2339},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2341,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(800.5,0)\"},\"previousSibling\":{\"id\":2340},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2342,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"previousSibling\":{\"id\":2341},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2343,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2317}},{\"nodeType\":1,\"id\":2344,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2343},\"parentNode\":{\"id\":2317}},{\"nodeType\":1,\"id\":2345,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2318}},{\"nodeType\":1,\"id\":2346,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2345},\"parentNode\":{\"id\":2318}},{\"nodeType\":1,\"id\":2347,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2319}},{\"nodeType\":1,\"id\":2348,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2347},\"parentNode\":{\"id\":2319}},{\"nodeType\":1,\"id\":2349,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2320}},{\"nodeType\":1,\"id\":2350,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2349},\"parentNode\":{\"id\":2320}},{\"nodeType\":1,\"id\":2351,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2321}},{\"nodeType\":1,\"id\":2352,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2351},\"parentNode\":{\"id\":2321}},{\"nodeType\":1,\"id\":2353,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2322}},{\"nodeType\":1,\"id\":2354,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2353},\"parentNode\":{\"id\":2322}},{\"nodeType\":1,\"id\":2355,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2323}},{\"nodeType\":1,\"id\":2356,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2355},\"parentNode\":{\"id\":2323}},{\"nodeType\":1,\"id\":2357,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2324}},{\"nodeType\":1,\"id\":2358,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2357},\"parentNode\":{\"id\":2324}},{\"nodeType\":1,\"id\":2359,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2325}},{\"nodeType\":1,\"id\":2360,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2359},\"parentNode\":{\"id\":2325}},{\"nodeType\":1,\"id\":2361,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2326}},{\"nodeType\":1,\"id\":2362,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2361},\"parentNode\":{\"id\":2326}},{\"nodeType\":1,\"id\":2363,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2327}},{\"nodeType\":1,\"id\":2364,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2363},\"parentNode\":{\"id\":2327}},{\"nodeType\":1,\"id\":2365,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2328}},{\"nodeType\":1,\"id\":2366,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2365},\"parentNode\":{\"id\":2328}},{\"nodeType\":1,\"id\":2367,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2329}},{\"nodeType\":1,\"id\":2368,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2367},\"parentNode\":{\"id\":2329}},{\"nodeType\":1,\"id\":2369,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2330}},{\"nodeType\":1,\"id\":2370,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2369},\"parentNode\":{\"id\":2330}},{\"nodeType\":1,\"id\":2371,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2331}},{\"nodeType\":1,\"id\":2372,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2371},\"parentNode\":{\"id\":2331}},{\"nodeType\":1,\"id\":2373,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2332}},{\"nodeType\":1,\"id\":2374,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2373},\"parentNode\":{\"id\":2332}},{\"nodeType\":1,\"id\":2375,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2333}},{\"nodeType\":1,\"id\":2376,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2375},\"parentNode\":{\"id\":2333}},{\"nodeType\":1,\"id\":2377,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2334}},{\"nodeType\":1,\"id\":2378,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2377},\"parentNode\":{\"id\":2334}},{\"nodeType\":1,\"id\":2379,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2335}},{\"nodeType\":1,\"id\":2380,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2379},\"parentNode\":{\"id\":2335}},{\"nodeType\":1,\"id\":2381,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2336}},{\"nodeType\":1,\"id\":2382,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2381},\"parentNode\":{\"id\":2336}},{\"nodeType\":1,\"id\":2383,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2337}},{\"nodeType\":1,\"id\":2384,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2383},\"parentNode\":{\"id\":2337}},{\"nodeType\":1,\"id\":2385,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2338}},{\"nodeType\":1,\"id\":2386,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2385},\"parentNode\":{\"id\":2338}},{\"nodeType\":1,\"id\":2387,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2339}},{\"nodeType\":1,\"id\":2388,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2387},\"parentNode\":{\"id\":2339}},{\"nodeType\":1,\"id\":2389,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2340}},{\"nodeType\":1,\"id\":2390,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2389},\"parentNode\":{\"id\":2340}},{\"nodeType\":1,\"id\":2391,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2341}},{\"nodeType\":1,\"id\":2392,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2391},\"parentNode\":{\"id\":2341}},{\"nodeType\":3,\"id\":2393,\"textContent\":\"08 AM\",\"parentNode\":{\"id\":2344}},{\"nodeType\":3,\"id\":2394,\"textContent\":\"08:30\",\"parentNode\":{\"id\":2346}},{\"nodeType\":3,\"id\":2395,\"textContent\":\"09 AM\",\"parentNode\":{\"id\":2348}},{\"nodeType\":3,\"id\":2396,\"textContent\":\"09:30\",\"parentNode\":{\"id\":2350}},{\"nodeType\":3,\"id\":2397,\"textContent\":\"10 AM\",\"parentNode\":{\"id\":2352}},{\"nodeType\":3,\"id\":2398,\"textContent\":\"10:30\",\"parentNode\":{\"id\":2354}},{\"nodeType\":3,\"id\":2399,\"textContent\":\"11 AM\",\"parentNode\":{\"id\":2356}},{\"nodeType\":3,\"id\":2400,\"textContent\":\"11:30\",\"parentNode\":{\"id\":2358}},{\"nodeType\":3,\"id\":2401,\"textContent\":\"12 PM\",\"parentNode\":{\"id\":2360}},{\"nodeType\":3,\"id\":2402,\"textContent\":\"12:30\",\"parentNode\":{\"id\":2362}},{\"nodeType\":3,\"id\":2403,\"textContent\":\"01 PM\",\"parentNode\":{\"id\":2364}},{\"nodeType\":3,\"id\":2404,\"textContent\":\"01:30\",\"parentNode\":{\"id\":2366}},{\"nodeType\":3,\"id\":2405,\"textContent\":\"02 PM\",\"parentNode\":{\"id\":2368}},{\"nodeType\":3,\"id\":2406,\"textContent\":\"02:30\",\"parentNode\":{\"id\":2370}},{\"nodeType\":3,\"id\":2407,\"textContent\":\"03 PM\",\"parentNode\":{\"id\":2372}},{\"nodeType\":3,\"id\":2408,\"textContent\":\"03:30\",\"parentNode\":{\"id\":2374}},{\"nodeType\":3,\"id\":2409,\"textContent\":\"04 PM\",\"parentNode\":{\"id\":2376}},{\"nodeType\":3,\"id\":2410,\"textContent\":\"04:30\",\"parentNode\":{\"id\":2378}},{\"nodeType\":3,\"id\":2411,\"textContent\":\"05 PM\",\"parentNode\":{\"id\":2380}},{\"nodeType\":3,\"id\":2412,\"textContent\":\"05:30\",\"parentNode\":{\"id\":2382}},{\"nodeType\":3,\"id\":2413,\"textContent\":\"06 PM\",\"parentNode\":{\"id\":2384}},{\"nodeType\":3,\"id\":2414,\"textContent\":\"06:30\",\"parentNode\":{\"id\":2386}},{\"nodeType\":3,\"id\":2415,\"textContent\":\"07 PM\",\"parentNode\":{\"id\":2388}},{\"nodeType\":3,\"id\":2416,\"textContent\":\"07:30\",\"parentNode\":{\"id\":2390}},{\"nodeType\":3,\"id\":2417,\"textContent\":\"08 PM\",\"parentNode\":{\"id\":2392}},{\"nodeType\":1,\"id\":2418,\"tagName\":\"text\",\"attributes\":{\"x\":\"533.3333333333334\",\"y\":\"80\",\"style\":\"text-anchor: end;\"},\"parentNode\":{\"id\":2342}},{\"nodeType\":3,\"id\":2419,\"textContent\":\"START & END TIME (time of day)\",\"parentNode\":{\"id\":2418}},{\"nodeType\":1,\"id\":2420,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M-15,800.5H0.5V0.5H-15\"},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2421,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,800.5)\"},\"previousSibling\":{\"id\":2420},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2422,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,733.8333333333334)\"},\"previousSibling\":{\"id\":2421},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2423,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,667.1666666666667)\"},\"previousSibling\":{\"id\":2422},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2424,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,600.5)\"},\"previousSibling\":{\"id\":2423},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2425,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,533.8333333333334)\"},\"previousSibling\":{\"id\":2424},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2426,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,467.16666666666663)\"},\"previousSibling\":{\"id\":2425},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2427,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,400.5)\"},\"previousSibling\":{\"id\":2426},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2428,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,333.8333333333333)\"},\"previousSibling\":{\"id\":2427},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2429,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,267.16666666666674)\"},\"previousSibling\":{\"id\":2428},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2430,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,200.5)\"},\"previousSibling\":{\"id\":2429},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2431,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,133.83333333333326)\"},\"previousSibling\":{\"id\":2430},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2432,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,67.16666666666674)\"},\"previousSibling\":{\"id\":2431},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2433,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,0.5)\"},\"previousSibling\":{\"id\":2432},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2434,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"previousSibling\":{\"id\":2433},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2435,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2421}},{\"nodeType\":1,\"id\":2436,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2435},\"parentNode\":{\"id\":2421}},{\"nodeType\":1,\"id\":2437,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2422}},{\"nodeType\":1,\"id\":2438,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2437},\"parentNode\":{\"id\":2422}},{\"nodeType\":1,\"id\":2439,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2423}},{\"nodeType\":1,\"id\":2440,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2439},\"parentNode\":{\"id\":2423}},{\"nodeType\":1,\"id\":2441,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2424}},{\"nodeType\":1,\"id\":2442,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2441},\"parentNode\":{\"id\":2424}},{\"nodeType\":1,\"id\":2443,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2425}},{\"nodeType\":1,\"id\":2444,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2443},\"parentNode\":{\"id\":2425}},{\"nodeType\":1,\"id\":2445,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2426}},{\"nodeType\":1,\"id\":2446,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2445},\"parentNode\":{\"id\":2426}},{\"nodeType\":1,\"id\":2447,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2427}},{\"nodeType\":1,\"id\":2448,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2447},\"parentNode\":{\"id\":2427}},{\"nodeType\":1,\"id\":2449,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2428}},{\"nodeType\":1,\"id\":2450,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2449},\"parentNode\":{\"id\":2428}},{\"nodeType\":1,\"id\":2451,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2429}},{\"nodeType\":1,\"id\":2452,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2451},\"parentNode\":{\"id\":2429}},{\"nodeType\":1,\"id\":2453,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2430}},{\"nodeType\":1,\"id\":2454,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2453},\"parentNode\":{\"id\":2430}},{\"nodeType\":1,\"id\":2455,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2431}},{\"nodeType\":1,\"id\":2456,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2455},\"parentNode\":{\"id\":2431}},{\"nodeType\":1,\"id\":2457,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2432}},{\"nodeType\":1,\"id\":2458,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2457},\"parentNode\":{\"id\":2432}},{\"nodeType\":1,\"id\":2459,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2433}},{\"nodeType\":1,\"id\":2460,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2459},\"parentNode\":{\"id\":2433}},{\"nodeType\":3,\"id\":2461,\"textContent\":\"0\",\"parentNode\":{\"id\":2436}},{\"nodeType\":3,\"id\":2462,\"textContent\":\"1\",\"parentNode\":{\"id\":2438}},{\"nodeType\":3,\"id\":2463,\"textContent\":\"2\",\"parentNode\":{\"id\":2440}},{\"nodeType\":3,\"id\":2464,\"textContent\":\"3\",\"parentNode\":{\"id\":2442}},{\"nodeType\":3,\"id\":2465,\"textContent\":\"4\",\"parentNode\":{\"id\":2444}},{\"nodeType\":3,\"id\":2466,\"textContent\":\"5\",\"parentNode\":{\"id\":2446}},{\"nodeType\":3,\"id\":2467,\"textContent\":\"6\",\"parentNode\":{\"id\":2448}},{\"nodeType\":3,\"id\":2468,\"textContent\":\"7\",\"parentNode\":{\"id\":2450}},{\"nodeType\":3,\"id\":2469,\"textContent\":\"8\",\"parentNode\":{\"id\":2452}},{\"nodeType\":3,\"id\":2470,\"textContent\":\"9\",\"parentNode\":{\"id\":2454}},{\"nodeType\":3,\"id\":2471,\"textContent\":\"10\",\"parentNode\":{\"id\":2456}},{\"nodeType\":3,\"id\":2472,\"textContent\":\"11\",\"parentNode\":{\"id\":2458}},{\"nodeType\":3,\"id\":2473,\"textContent\":\"12\",\"parentNode\":{\"id\":2460}},{\"nodeType\":1,\"id\":2474,\"tagName\":\"text\",\"attributes\":{\"transform\":\"rotate(-90)\",\"x\":\"-350\",\"y\":\"-60\",\"style\":\"text-anchor: end;\"},\"parentNode\":{\"id\":2434}},{\"nodeType\":3,\"id\":2475,\"textContent\":\"DURATION (in hours)\",\"parentNode\":{\"id\":2474}},{\"nodeType\":1,\"id\":2476,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2477,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"previousSibling\":{\"id\":2476},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2478,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"previousSibling\":{\"id\":2477},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2479,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"previousSibling\":{\"id\":2478},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2480,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"previousSibling\":{\"id\":2479},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2481,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"previousSibling\":{\"id\":2480},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2482,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"previousSibling\":{\"id\":2481},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2483,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"previousSibling\":{\"id\":2482},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2484,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"previousSibling\":{\"id\":2483},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2485,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"previousSibling\":{\"id\":2484},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2486,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"previousSibling\":{\"id\":2485},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2487,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"previousSibling\":{\"id\":2486},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2488,\"tagName\":\"line\",\"attributes\":{\"x1\":\"13.333333333333329\",\"x2\":\"766.6666666666667\",\"y1\":\"733.3333333333334\",\"y2\":\"733.3333333333334\"},\"parentNode\":{\"id\":2476}},{\"nodeType\":1,\"id\":2489,\"tagName\":\"line\",\"attributes\":{\"x1\":\"46.66666666666666\",\"x2\":\"733.3333333333333\",\"y1\":\"666.6666666666667\",\"y2\":\"666.6666666666667\"},\"parentNode\":{\"id\":2477}},{\"nodeType\":1,\"id\":2490,\"tagName\":\"line\",\"attributes\":{\"x1\":\"80\",\"x2\":\"700\",\"y1\":\"600\",\"y2\":\"600\"},\"parentNode\":{\"id\":2478}},{\"nodeType\":1,\"id\":2491,\"tagName\":\"line\",\"attributes\":{\"x1\":\"113.33333333333331\",\"x2\":\"666.6666666666667\",\"y1\":\"533.3333333333334\",\"y2\":\"533.3333333333334\"},\"parentNode\":{\"id\":2479}},{\"nodeType\":1,\"id\":2492,\"tagName\":\"line\",\"attributes\":{\"x1\":\"146.66666666666669\",\"x2\":\"633.3333333333333\",\"y1\":\"466.66666666666663\",\"y2\":\"466.66666666666663\"},\"parentNode\":{\"id\":2480}},{\"nodeType\":1,\"id\":2493,\"tagName\":\"line\",\"attributes\":{\"x1\":\"180\",\"x2\":\"600\",\"y1\":\"400\",\"y2\":\"400\"},\"parentNode\":{\"id\":2481}},{\"nodeType\":1,\"id\":2494,\"tagName\":\"line\",\"attributes\":{\"x1\":\"213.33333333333334\",\"x2\":\"566.6666666666667\",\"y1\":\"333.3333333333333\",\"y2\":\"333.3333333333333\"},\"parentNode\":{\"id\":2482}},{\"nodeType\":1,\"id\":2495,\"tagName\":\"line\",\"attributes\":{\"x1\":\"246.66666666666663\",\"x2\":\"533.3333333333333\",\"y1\":\"266.66666666666674\",\"y2\":\"266.66666666666674\"},\"parentNode\":{\"id\":2483}},{\"nodeType\":1,\"id\":2496,\"tagName\":\"line\",\"attributes\":{\"x1\":\"280\",\"x2\":\"500\",\"y1\":\"200\",\"y2\":\"200\"},\"parentNode\":{\"id\":2484}},{\"nodeType\":1,\"id\":2497,\"tagName\":\"line\",\"attributes\":{\"x1\":\"313.33333333333337\",\"x2\":\"466.6666666666667\",\"y1\":\"133.33333333333326\",\"y2\":\"133.33333333333326\"},\"parentNode\":{\"id\":2485}},{\"nodeType\":1,\"id\":2498,\"tagName\":\"line\",\"attributes\":{\"x1\":\"346.66666666666663\",\"x2\":\"433.3333333333333\",\"y1\":\"66.66666666666674\",\"y2\":\"66.66666666666674\"},\"parentNode\":{\"id\":2486}},{\"nodeType\":1,\"id\":2499,\"tagName\":\"line\",\"attributes\":{\"x1\":\"380\",\"x2\":\"400\",\"y1\":\"0\",\"y2\":\"0\"},\"parentNode\":{\"id\":2487}},{\"nodeType\":1,\"id\":2500,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"0\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2501,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"800\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"},\"previousSibling\":{\"id\":2500},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2502,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"433.3333333333333\",\"y2\":\"66.66666666666674\"},\"previousSibling\":{\"id\":2501},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2503,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"366.66666666666663\",\"y2\":\"66.66666666666674\"},\"previousSibling\":{\"id\":2502},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2504,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"466.6666666666667\",\"y2\":\"133.33333333333326\"},\"previousSibling\":{\"id\":2503},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2505,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"333.33333333333337\",\"y2\":\"133.33333333333326\"},\"previousSibling\":{\"id\":2504},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2506,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"500\",\"y2\":\"200\"},\"previousSibling\":{\"id\":2505},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2507,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"300\",\"y2\":\"200\"},\"previousSibling\":{\"id\":2506},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2508,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"533.3333333333333\",\"y2\":\"266.66666666666674\"},\"previousSibling\":{\"id\":2507},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2509,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"266.66666666666663\",\"y2\":\"266.66666666666674\"},\"previousSibling\":{\"id\":2508},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2510,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"566.6666666666667\",\"y2\":\"333.3333333333333\"},\"previousSibling\":{\"id\":2509},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2511,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"233.33333333333334\",\"y2\":\"333.3333333333333\"},\"previousSibling\":{\"id\":2510},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2512,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"600\",\"y2\":\"400\"},\"previousSibling\":{\"id\":2511},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2513,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"200\",\"y2\":\"400\"},\"previousSibling\":{\"id\":2512},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2514,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"633.3333333333333\",\"y2\":\"466.66666666666663\"},\"previousSibling\":{\"id\":2513},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2515,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"166.66666666666669\",\"y2\":\"466.66666666666663\"},\"previousSibling\":{\"id\":2514},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2516,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"666.6666666666667\",\"y2\":\"533.3333333333334\"},\"previousSibling\":{\"id\":2515},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2517,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"133.33333333333331\",\"y2\":\"533.3333333333334\"},\"previousSibling\":{\"id\":2516},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2518,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"700\",\"y2\":\"600\"},\"previousSibling\":{\"id\":2517},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2519,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"100\",\"y2\":\"600\"},\"previousSibling\":{\"id\":2518},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2520,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"733.3333333333333\",\"y2\":\"666.6666666666667\"},\"previousSibling\":{\"id\":2519},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2521,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"66.66666666666666\",\"y2\":\"666.6666666666667\"},\"previousSibling\":{\"id\":2520},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2522,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"766.6666666666667\",\"y2\":\"733.3333333333334\"},\"previousSibling\":{\"id\":2521},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2523,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"33.33333333333333\",\"y2\":\"733.3333333333334\"},\"previousSibling\":{\"id\":2522},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2524,\"tagName\":\"g\",\"attributes\":{},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2525,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2524},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2526,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2525},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2527,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2526},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2528,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2527},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2529,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2528},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2530,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2529},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2531,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2530},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2532,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2531},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2533,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2532},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2534,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2533},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2535,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2534},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2536,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2535},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2537,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2536},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2538,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2537},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2539,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2538},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2540,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2539},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2541,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2540},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2542,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"266.66666666666674\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2524}},{\"nodeType\":1,\"id\":2543,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"258.66666666666674\"},\"previousSibling\":{\"id\":2542},\"parentNode\":{\"id\":2524}},{\"nodeType\":1,\"id\":2544,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2525}},{\"nodeType\":1,\"id\":2545,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"592\"},\"previousSibling\":{\"id\":2544},\"parentNode\":{\"id\":2525}},{\"nodeType\":1,\"id\":2546,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"366.66666666666663\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2526}},{\"nodeType\":1,\"id\":2547,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"361.66666666666663\",\"y\":\"458.66666666666663\"},\"previousSibling\":{\"id\":2546},\"parentNode\":{\"id\":2526}},{\"nodeType\":1,\"id\":2548,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"666.6666666666667\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2527}},{\"nodeType\":1,\"id\":2549,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"661.6666666666667\",\"y\":\"658.6666666666667\"},\"previousSibling\":{\"id\":2548},\"parentNode\":{\"id\":2527}},{\"nodeType\":1,\"id\":2550,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"200\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2528}},{\"nodeType\":1,\"id\":2551,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"195\",\"y\":\"392\"},\"previousSibling\":{\"id\":2550},\"parentNode\":{\"id\":2528}},{\"nodeType\":1,\"id\":2552,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2529}},{\"nodeType\":1,\"id\":2553,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"525.3333333333334\"},\"previousSibling\":{\"id\":2552},\"parentNode\":{\"id\":2529}},{\"nodeType\":1,\"id\":2554,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2530}},{\"nodeType\":1,\"id\":2555,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"392\"},\"previousSibling\":{\"id\":2554},\"parentNode\":{\"id\":2530}},{\"nodeType\":1,\"id\":2556,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2531}},{\"nodeType\":1,\"id\":2557,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"458.66666666666663\"},\"previousSibling\":{\"id\":2556},\"parentNode\":{\"id\":2531}},{\"nodeType\":1,\"id\":2558,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"100\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2532}},{\"nodeType\":1,\"id\":2559,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"95\",\"y\":\"592\"},\"previousSibling\":{\"id\":2558},\"parentNode\":{\"id\":2532}},{\"nodeType\":1,\"id\":2560,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"133.33333333333331\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2533}},{\"nodeType\":1,\"id\":2561,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"128.33333333333331\",\"y\":\"658.6666666666667\"},\"previousSibling\":{\"id\":2560},\"parentNode\":{\"id\":2533}},{\"nodeType\":1,\"id\":2562,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"133.33333333333326\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2534}},{\"nodeType\":1,\"id\":2563,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"125.33333333333326\"},\"previousSibling\":{\"id\":2562},\"parentNode\":{\"id\":2534}},{\"nodeType\":1,\"id\":2564,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"333.3333333333333\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2535}},{\"nodeType\":1,\"id\":2565,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"325.3333333333333\"},\"previousSibling\":{\"id\":2564},\"parentNode\":{\"id\":2535}},{\"nodeType\":1,\"id\":2566,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"300\",\"cy\":\"733.3333333333334\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2536}},{\"nodeType\":1,\"id\":2567,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"295\",\"y\":\"725.3333333333334\"},\"previousSibling\":{\"id\":2566},\"parentNode\":{\"id\":2536}},{\"nodeType\":1,\"id\":2568,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"600\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2537}},{\"nodeType\":1,\"id\":2569,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"595\",\"y\":\"658.6666666666667\"},\"previousSibling\":{\"id\":2568},\"parentNode\":{\"id\":2537}},{\"nodeType\":1,\"id\":2570,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"433.3333333333333\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2538}},{\"nodeType\":1,\"id\":2571,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"428.3333333333333\",\"y\":\"592\"},\"previousSibling\":{\"id\":2570},\"parentNode\":{\"id\":2538}},{\"nodeType\":1,\"id\":2572,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"200\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2539}},{\"nodeType\":1,\"id\":2573,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"192\"},\"previousSibling\":{\"id\":2572},\"parentNode\":{\"id\":2539}},{\"nodeType\":1,\"id\":2574,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"533.3333333333333\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2540}},{\"nodeType\":1,\"id\":2575,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"528.3333333333333\",\"y\":\"525.3333333333334\"},\"previousSibling\":{\"id\":2574},\"parentNode\":{\"id\":2540}},{\"nodeType\":1,\"id\":2576,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2541}},{\"nodeType\":1,\"id\":2577,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"658.6666666666667\"},\"previousSibling\":{\"id\":2576},\"parentNode\":{\"id\":2541}},{\"nodeType\":3,\"id\":2578,\"textContent\":\"A \",\"parentNode\":{\"id\":2543}},{\"nodeType\":3,\"id\":2579,\"textContent\":\"B \",\"parentNode\":{\"id\":2545}},{\"nodeType\":3,\"id\":2580,\"textContent\":\"C \",\"parentNode\":{\"id\":2547}},{\"nodeType\":3,\"id\":2581,\"textContent\":\"D \",\"parentNode\":{\"id\":2549}},{\"nodeType\":3,\"id\":2582,\"textContent\":\"E \",\"parentNode\":{\"id\":2551}},{\"nodeType\":3,\"id\":2583,\"textContent\":\"F \",\"parentNode\":{\"id\":2553}},{\"nodeType\":3,\"id\":2584,\"textContent\":\"G \",\"parentNode\":{\"id\":2555}},{\"nodeType\":3,\"id\":2585,\"textContent\":\"H \",\"parentNode\":{\"id\":2557}},{\"nodeType\":3,\"id\":2586,\"textContent\":\"I \",\"parentNode\":{\"id\":2559}},{\"nodeType\":3,\"id\":2587,\"textContent\":\"J \",\"parentNode\":{\"id\":2561}},{\"nodeType\":3,\"id\":2588,\"textContent\":\"K \",\"parentNode\":{\"id\":2563}},{\"nodeType\":3,\"id\":2589,\"textContent\":\"L \",\"parentNode\":{\"id\":2565}},{\"nodeType\":3,\"id\":2590,\"textContent\":\"M \",\"parentNode\":{\"id\":2567}},{\"nodeType\":3,\"id\":2591,\"textContent\":\"N \",\"parentNode\":{\"id\":2569}},{\"nodeType\":3,\"id\":2592,\"textContent\":\"O \",\"parentNode\":{\"id\":2571}},{\"nodeType\":3,\"id\":2593,\"textContent\":\"P \",\"parentNode\":{\"id\":2573}},{\"nodeType\":3,\"id\":2594,\"textContent\":\"Z \",\"parentNode\":{\"id\":2575}},{\"nodeType\":3,\"id\":2595,\"textContent\":\"X \",\"parentNode\":{\"id\":2577}}],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":56},{\"id\":57},{\"id\":58},{\"id\":59},{\"id\":60},{\"id\":61},{\"id\":62},{\"id\":63},{\"id\":64},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":72},{\"id\":73},{\"id\":74},{\"id\":75},{\"id\":76},{\"id\":77},{\"id\":78},{\"id\":79},{\"id\":80},{\"id\":81},{\"id\":82},{\"id\":83},{\"id\":84},{\"id\":85},{\"id\":86},{\"id\":87},{\"id\":88},{\"id\":89},{\"id\":90},{\"id\":91},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":96},{\"id\":97},{\"id\":98},{\"id\":99},{\"id\":100},{\"id\":101},{\"id\":102},{\"id\":103},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":109},{\"id\":110},{\"id\":111},{\"id\":112},{\"id\":113},{\"id\":114},{\"id\":115},{\"id\":116},{\"id\":117},{\"id\":118},{\"id\":119},{\"id\":120},{\"id\":121},{\"id\":122},{\"id\":123},{\"id\":124},{\"id\":125},{\"id\":126},{\"id\":127},{\"id\":128},{\"id\":129},{\"id\":130},{\"id\":131},{\"id\":132},{\"id\":133},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":141},{\"id\":142},{\"id\":143},{\"id\":144},{\"id\":145},{\"id\":146},{\"id\":147},{\"id\":148},{\"id\":149},{\"id\":150},{\"id\":151},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":155},{\"id\":156},{\"id\":157},{\"id\":158},{\"id\":159},{\"id\":160},{\"id\":161},{\"id\":162},{\"id\":163},{\"id\":164},{\"id\":165},{\"id\":166},{\"id\":167},{\"id\":168},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":172},{\"id\":173},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":178},{\"id\":179},{\"id\":180},{\"id\":181},{\"id\":182},{\"id\":183},{\"id\":184},{\"id\":185},{\"id\":186},{\"id\":187},{\"id\":188},{\"id\":189},{\"id\":190},{\"id\":191},{\"id\":192},{\"id\":193},{\"id\":194},{\"id\":195},{\"id\":196},{\"id\":197},{\"id\":198},{\"id\":199},{\"id\":200},{\"id\":201},{\"id\":202},{\"id\":203},{\"id\":204},{\"id\":205},{\"id\":206},{\"id\":207},{\"id\":208},{\"id\":209},{\"id\":210},{\"id\":211},{\"id\":212},{\"id\":213},{\"id\":214},{\"id\":215},{\"id\":216},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":220},{\"id\":221},{\"id\":222},{\"id\":223},{\"id\":224},{\"id\":225},{\"id\":226},{\"id\":227},{\"id\":228},{\"id\":229},{\"id\":230},{\"id\":231},{\"id\":232},{\"id\":233},{\"id\":234},{\"id\":235},{\"id\":236},{\"id\":237},{\"id\":238},{\"id\":239},{\"id\":240},{\"id\":241},{\"id\":242},{\"id\":243},{\"id\":244},{\"id\":245},{\"id\":246},{\"id\":247},{\"id\":248},{\"id\":249},{\"id\":250},{\"id\":251},{\"id\":252},{\"id\":253},{\"id\":254},{\"id\":255},{\"id\":256},{\"id\":257},{\"id\":258},{\"id\":259},{\"id\":260},{\"id\":261},{\"id\":262},{\"id\":263},{\"id\":264},{\"id\":265},{\"id\":266},{\"id\":267},{\"id\":268},{\"id\":269},{\"id\":270},{\"id\":271},{\"id\":272},{\"id\":273},{\"id\":274},{\"id\":275},{\"id\":276},{\"id\":277},{\"id\":278},{\"id\":279},{\"id\":280},{\"id\":281},{\"id\":282},{\"id\":283},{\"id\":284},{\"id\":285},{\"id\":286},{\"id\":287},{\"id\":288},{\"id\":289},{\"id\":290},{\"id\":291},{\"id\":292},{\"id\":293},{\"id\":294},{\"id\":295},{\"id\":296},{\"id\":297},{\"id\":298},{\"id\":299},{\"id\":300},{\"id\":301},{\"id\":302},{\"id\":303},{\"id\":304},{\"id\":305},{\"id\":306},{\"id\":307},{\"id\":308},{\"id\":309},{\"id\":310},{\"id\":311},{\"id\":312},{\"id\":313},{\"id\":314},{\"id\":315},{\"id\":316},{\"id\":317},{\"id\":318},{\"id\":319},{\"id\":320},{\"id\":321},{\"id\":322},{\"id\":323},{\"id\":324},{\"id\":325},{\"id\":326},{\"id\":327},{\"id\":328},{\"id\":329},{\"id\":330},{\"id\":331},{\"id\":332},{\"id\":333},{\"id\":334},{\"id\":335},{\"id\":336},{\"id\":337},{\"id\":338},{\"id\":339},{\"id\":340},{\"id\":341},{\"id\":342},{\"id\":343},{\"id\":344},{\"id\":345},{\"id\":346},{\"id\":347},{\"id\":348},{\"id\":349},{\"id\":350},{\"id\":351},{\"id\":352},{\"id\":353},{\"id\":354},{\"id\":355},{\"id\":356},{\"id\":357},{\"id\":358},{\"id\":359},{\"id\":360},{\"id\":361},{\"id\":362},{\"id\":363},{\"id\":364},{\"id\":365},{\"id\":366},{\"id\":367},{\"id\":368},{\"id\":369},{\"id\":370},{\"id\":371},{\"id\":372},{\"id\":373},{\"id\":374},{\"id\":375},{\"id\":376},{\"id\":377},{\"id\":378},{\"id\":379},{\"id\":380},{\"id\":381},{\"id\":382},{\"id\":383},{\"id\":384},{\"id\":385},{\"id\":386},{\"id\":387},{\"id\":388},{\"id\":389},{\"id\":390},{\"id\":391},{\"id\":392},{\"id\":393},{\"id\":394},{\"id\":395},{\"id\":396},{\"id\":397},{\"id\":398},{\"id\":399},{\"id\":400},{\"id\":401},{\"id\":402},{\"id\":403},{\"id\":404},{\"id\":405},{\"id\":406},{\"id\":407},{\"id\":408},{\"id\":409},{\"id\":410},{\"id\":411},{\"id\":412},{\"id\":413},{\"id\":414},{\"id\":415},{\"id\":416},{\"id\":417},{\"id\":418},{\"id\":419},{\"id\":420},{\"id\":421},{\"id\":422},{\"id\":423},{\"id\":424},{\"id\":425},{\"id\":426},{\"id\":427},{\"id\":428},{\"id\":429},{\"id\":430},{\"id\":431},{\"id\":432},{\"id\":433},{\"id\":434},{\"id\":435},{\"id\":436},{\"id\":437},{\"id\":438},{\"id\":439},{\"id\":440},{\"id\":441},{\"id\":442},{\"id\":443},{\"id\":444},{\"id\":445},{\"id\":446},{\"id\":447},{\"id\":448},{\"id\":449},{\"id\":450},{\"id\":451},{\"id\":452},{\"id\":453},{\"id\":454},{\"id\":455},{\"id\":456},{\"id\":457},{\"id\":458},{\"id\":459},{\"id\":460},{\"id\":461},{\"id\":462},{\"id\":463},{\"id\":464},{\"id\":465},{\"id\":466},{\"id\":467},{\"id\":468},{\"id\":469},{\"id\":470},{\"id\":471},{\"id\":472},{\"id\":473},{\"id\":474},{\"id\":475},{\"id\":476},{\"id\":477},{\"id\":478},{\"id\":479},{\"id\":480},{\"id\":481},{\"id\":482},{\"id\":483},{\"id\":484},{\"id\":485},{\"id\":486},{\"id\":487},{\"id\":488},{\"id\":489},{\"id\":490},{\"id\":491},{\"id\":492},{\"id\":493},{\"id\":494},{\"id\":495},{\"id\":496},{\"id\":497},{\"id\":498},{\"id\":499},{\"id\":500},{\"id\":501},{\"id\":502},{\"id\":503},{\"id\":504},{\"id\":505},{\"id\":506},{\"id\":507},{\"id\":508},{\"id\":509},{\"id\":510},{\"id\":511},{\"id\":512},{\"id\":513},{\"id\":514},{\"id\":515},{\"id\":516},{\"id\":517},{\"id\":518},{\"id\":519},{\"id\":520},{\"id\":521},{\"id\":522},{\"id\":523},{\"id\":524},{\"id\":525},{\"id\":526},{\"id\":527},{\"id\":528},{\"id\":529},{\"id\":530},{\"id\":531},{\"id\":532},{\"id\":533},{\"id\":534},{\"id\":535},{\"id\":536},{\"id\":537},{\"id\":538},{\"id\":539},{\"id\":540},{\"id\":541},{\"id\":542},{\"id\":543},{\"id\":544},{\"id\":545},{\"id\":546},{\"id\":547},{\"id\":548},{\"id\":549},{\"id\":550},{\"id\":551},{\"id\":552},{\"id\":553},{\"id\":554},{\"id\":555},{\"id\":556},{\"id\":557},{\"id\":558},{\"id\":559},{\"id\":560},{\"id\":561},{\"id\":562},{\"id\":563},{\"id\":564},{\"id\":565},{\"id\":566},{\"id\":567},{\"id\":568},{\"id\":569},{\"id\":570},{\"id\":571},{\"id\":572},{\"id\":573},{\"id\":574},{\"id\":575},{\"id\":576},{\"id\":577},{\"id\":578},{\"id\":579},{\"id\":580},{\"id\":581},{\"id\":582},{\"id\":583},{\"id\":584},{\"id\":585},{\"id\":586},{\"id\":587},{\"id\":588},{\"id\":589},{\"id\":590},{\"id\":591},{\"id\":592},{\"id\":593},{\"id\":594},{\"id\":595},{\"id\":596},{\"id\":597},{\"id\":598},{\"id\":599},{\"id\":600},{\"id\":601},{\"id\":602},{\"id\":603},{\"id\":604},{\"id\":605},{\"id\":606},{\"id\":607},{\"id\":608},{\"id\":609},{\"id\":610},{\"id\":611},{\"id\":612},{\"id\":613},{\"id\":614},{\"id\":615},{\"id\":616},{\"id\":617},{\"id\":618},{\"id\":619},{\"id\":620},{\"id\":621},{\"id\":622},{\"id\":623},{\"id\":624},{\"id\":625},{\"id\":626},{\"id\":627},{\"id\":628},{\"id\":629},{\"id\":630},{\"id\":631},{\"id\":632},{\"id\":633},{\"id\":634},{\"id\":635},{\"id\":636},{\"id\":637},{\"id\":638},{\"id\":639},{\"id\":640},{\"id\":641},{\"id\":642},{\"id\":643},{\"id\":644},{\"id\":645},{\"id\":646},{\"id\":647},{\"id\":648},{\"id\":649},{\"id\":650},{\"id\":651},{\"id\":652},{\"id\":653},{\"id\":654},{\"id\":655},{\"id\":656},{\"id\":657},{\"id\":658},{\"id\":659},{\"id\":660},{\"id\":661},{\"id\":662},{\"id\":663},{\"id\":664},{\"id\":665},{\"id\":666},{\"id\":667},{\"id\":668},{\"id\":669},{\"id\":670},{\"id\":671},{\"id\":672},{\"id\":673},{\"id\":674},{\"id\":675},{\"id\":676},{\"id\":677},{\"id\":678},{\"id\":679},{\"id\":680},{\"id\":681},{\"id\":682},{\"id\":683},{\"id\":684},{\"id\":685},{\"id\":686},{\"id\":687},{\"id\":688},{\"id\":689},{\"id\":690},{\"id\":691},{\"id\":692},{\"id\":693},{\"id\":694},{\"id\":695},{\"id\":696},{\"id\":697},{\"id\":698},{\"id\":699},{\"id\":700},{\"id\":701},{\"id\":702},{\"id\":703},{\"id\":704},{\"id\":705},{\"id\":706},{\"id\":707},{\"id\":708},{\"id\":709},{\"id\":710},{\"id\":711},{\"id\":712},{\"id\":713},{\"id\":714},{\"id\":715},{\"id\":716},{\"id\":717},{\"id\":718},{\"id\":719},{\"id\":720},{\"id\":721},{\"id\":722},{\"id\":723},{\"id\":724},{\"id\":725},{\"id\":726},{\"id\":727},{\"id\":728},{\"id\":729},{\"id\":730},{\"id\":731},{\"id\":732},{\"id\":733},{\"id\":734},{\"id\":735},{\"id\":736},{\"id\":737},{\"id\":738},{\"id\":739},{\"id\":740},{\"id\":741},{\"id\":742},{\"id\":743},{\"id\":744},{\"id\":745},{\"id\":746},{\"id\":747},{\"id\":748},{\"id\":749},{\"id\":750},{\"id\":751},{\"id\":752},{\"id\":753},{\"id\":754},{\"id\":755},{\"id\":756},{\"id\":757},{\"id\":758},{\"id\":759},{\"id\":760},{\"id\":761},{\"id\":762},{\"id\":763},{\"id\":764},{\"id\":765},{\"id\":766},{\"id\":767},{\"id\":768},{\"id\":769},{\"id\":770},{\"id\":771},{\"id\":772},{\"id\":773},{\"id\":774},{\"id\":775},{\"id\":776},{\"id\":777},{\"id\":778},{\"id\":779},{\"id\":780},{\"id\":781},{\"id\":782},{\"id\":783},{\"id\":784},{\"id\":785},{\"id\":786},{\"id\":787},{\"id\":788},{\"id\":789},{\"id\":790},{\"id\":791},{\"id\":792},{\"id\":793},{\"id\":794},{\"id\":795},{\"id\":796},{\"id\":797},{\"id\":798},{\"id\":799},{\"id\":800},{\"id\":801},{\"id\":802},{\"id\":803},{\"id\":804},{\"id\":805},{\"id\":806},{\"id\":807},{\"id\":808},{\"id\":809},{\"id\":810},{\"id\":811},{\"id\":812},{\"id\":813},{\"id\":814},{\"id\":815},{\"id\":816},{\"id\":817},{\"id\":818},{\"id\":819},{\"id\":820},{\"id\":821},{\"id\":822},{\"id\":823},{\"id\":824},{\"id\":825},{\"id\":826},{\"id\":827},{\"id\":828},{\"id\":829},{\"id\":830},{\"id\":831},{\"id\":832},{\"id\":833},{\"id\":834},{\"id\":835},{\"id\":836},{\"id\":837},{\"id\":838},{\"id\":839},{\"id\":840},{\"id\":841},{\"id\":842},{\"id\":843},{\"id\":844},{\"id\":845},{\"id\":846},{\"id\":847},{\"id\":848},{\"id\":849},{\"id\":850},{\"id\":851},{\"id\":852},{\"id\":853},{\"id\":854},{\"id\":855},{\"id\":856},{\"id\":857},{\"id\":858},{\"id\":859},{\"id\":860},{\"id\":861},{\"id\":862},{\"id\":863},{\"id\":864},{\"id\":865},{\"id\":866},{\"id\":867},{\"id\":868},{\"id\":869},{\"id\":870},{\"id\":871},{\"id\":872},{\"id\":873},{\"id\":874},{\"id\":875},{\"id\":876},{\"id\":877},{\"id\":878},{\"id\":879},{\"id\":880},{\"id\":881},{\"id\":882},{\"id\":883},{\"id\":884},{\"id\":885},{\"id\":886},{\"id\":887},{\"id\":888},{\"id\":889},{\"id\":890},{\"id\":891},{\"id\":892},{\"id\":893},{\"id\":894},{\"id\":895},{\"id\":896},{\"id\":897},{\"id\":898},{\"id\":899},{\"id\":900},{\"id\":901},{\"id\":902},{\"id\":903},{\"id\":904},{\"id\":905},{\"id\":906},{\"id\":907},{\"id\":908},{\"id\":909},{\"id\":910},{\"id\":911},{\"id\":912},{\"id\":913},{\"id\":914},{\"id\":915},{\"id\":916},{\"id\":917},{\"id\":918},{\"id\":919},{\"id\":920},{\"id\":921},{\"id\":922},{\"id\":923},{\"id\":924},{\"id\":925},{\"id\":926},{\"id\":927},{\"id\":928},{\"id\":929},{\"id\":930},{\"id\":931},{\"id\":932},{\"id\":933},{\"id\":934},{\"id\":935},{\"id\":936},{\"id\":937},{\"id\":938},{\"id\":939},{\"id\":940},{\"id\":941},{\"id\":942},{\"id\":943},{\"id\":944},{\"id\":945},{\"id\":946},{\"id\":947},{\"id\":948},{\"id\":949},{\"id\":950},{\"id\":951},{\"id\":952},{\"id\":953},{\"id\":954},{\"id\":955},{\"id\":956},{\"id\":957},{\"id\":958},{\"id\":959},{\"id\":960},{\"id\":961},{\"id\":962},{\"id\":963},{\"id\":964},{\"id\":965},{\"id\":966},{\"id\":967},{\"id\":968},{\"id\":969},{\"id\":970},{\"id\":971},{\"id\":972},{\"id\":973},{\"id\":974},{\"id\":975},{\"id\":976},{\"id\":977},{\"id\":978},{\"id\":979},{\"id\":980},{\"id\":981},{\"id\":982},{\"id\":983},{\"id\":984},{\"id\":985},{\"id\":986},{\"id\":987},{\"id\":988},{\"id\":989},{\"id\":990},{\"id\":991},{\"id\":992},{\"id\":993},{\"id\":994},{\"id\":995},{\"id\":996},{\"id\":997},{\"id\":998},{\"id\":999},{\"id\":1000},{\"id\":1001},{\"id\":1002},{\"id\":1003},{\"id\":1004},{\"id\":1005},{\"id\":1006},{\"id\":1007},{\"id\":1008},{\"id\":1009},{\"id\":1010},{\"id\":1011},{\"id\":1012},{\"id\":1013},{\"id\":1014},{\"id\":1015},{\"id\":1016},{\"id\":1017},{\"id\":1018},{\"id\":1019},{\"id\":1020},{\"id\":1021},{\"id\":1022},{\"id\":1023},{\"id\":1024},{\"id\":1025},{\"id\":1026},{\"id\":1027},{\"id\":1028},{\"id\":1029},{\"id\":1030},{\"id\":1031},{\"id\":1032},{\"id\":1033},{\"id\":1034},{\"id\":1035},{\"id\":1036},{\"id\":1037},{\"id\":1038},{\"id\":1039},{\"id\":1040},{\"id\":1041},{\"id\":1042},{\"id\":1043},{\"id\":1044},{\"id\":1045},{\"id\":1046},{\"id\":1047},{\"id\":1048},{\"id\":1049},{\"id\":1050},{\"id\":1051},{\"id\":1052},{\"id\":1053},{\"id\":1054},{\"id\":1055},{\"id\":1056},{\"id\":1057},{\"id\":1058},{\"id\":1059},{\"id\":1060},{\"id\":1061},{\"id\":1062},{\"id\":1063},{\"id\":1064},{\"id\":1065},{\"id\":1066},{\"id\":1067},{\"id\":1068},{\"id\":1069},{\"id\":1070},{\"id\":1071},{\"id\":1072},{\"id\":1073},{\"id\":1074},{\"id\":1075},{\"id\":1076},{\"id\":1077},{\"id\":1078},{\"id\":1079},{\"id\":1080},{\"id\":1081},{\"id\":1082},{\"id\":1083},{\"id\":1084},{\"id\":1085},{\"id\":1086},{\"id\":1087},{\"id\":1088},{\"id\":1089},{\"id\":1090},{\"id\":1091},{\"id\":1092},{\"id\":1093},{\"id\":1094},{\"id\":1095},{\"id\":1096},{\"id\":1097},{\"id\":1098},{\"id\":1099},{\"id\":1100},{\"id\":1101},{\"id\":1102},{\"id\":1103},{\"id\":1104},{\"id\":1105},{\"id\":1106},{\"id\":1107},{\"id\":1108},{\"id\":1109},{\"id\":1110},{\"id\":1111},{\"id\":1112},{\"id\":1113},{\"id\":1114},{\"id\":1115},{\"id\":1116},{\"id\":1117},{\"id\":1118},{\"id\":1119},{\"id\":1120},{\"id\":1121},{\"id\":1122},{\"id\":1123},{\"id\":1124},{\"id\":1125},{\"id\":1126},{\"id\":1127},{\"id\":1128},{\"id\":1129},{\"id\":1130},{\"id\":1131},{\"id\":1132},{\"id\":1133},{\"id\":1134},{\"id\":1135},{\"id\":1136},{\"id\":1137},{\"id\":1138},{\"id\":1139},{\"id\":1140},{\"id\":1141},{\"id\":1142},{\"id\":1143},{\"id\":1144},{\"id\":1145},{\"id\":1146},{\"id\":1147},{\"id\":1148},{\"id\":1149},{\"id\":1150},{\"id\":1151},{\"id\":1152},{\"id\":1153},{\"id\":1154},{\"id\":1155},{\"id\":1156},{\"id\":1157},{\"id\":1158},{\"id\":1159},{\"id\":1160},{\"id\":1161},{\"id\":1162},{\"id\":1163},{\"id\":1164},{\"id\":1165},{\"id\":1166},{\"id\":1167},{\"id\":1168},{\"id\":1169},{\"id\":1170},{\"id\":1171},{\"id\":1172},{\"id\":1173},{\"id\":1174},{\"id\":1175},{\"id\":1176},{\"id\":1177},{\"id\":1178},{\"id\":1179},{\"id\":1180},{\"id\":1181},{\"id\":1182},{\"id\":1183},{\"id\":1184},{\"id\":1185},{\"id\":1186},{\"id\":1187},{\"id\":1188},{\"id\":1189},{\"id\":1190},{\"id\":1191},{\"id\":1192},{\"id\":1193},{\"id\":1194},{\"id\":1195},{\"id\":1196},{\"id\":1197},{\"id\":1198},{\"id\":1199},{\"id\":1200},{\"id\":1201},{\"id\":1202},{\"id\":1203},{\"id\":1204},{\"id\":1205},{\"id\":1206},{\"id\":1207},{\"id\":1208},{\"id\":1209},{\"id\":1210},{\"id\":1211},{\"id\":1212},{\"id\":1213},{\"id\":1214},{\"id\":1215},{\"id\":1216},{\"id\":1217},{\"id\":1218},{\"id\":1219},{\"id\":1220},{\"id\":1221},{\"id\":1222},{\"id\":1223},{\"id\":1224},{\"id\":1225},{\"id\":1226},{\"id\":1227},{\"id\":1228},{\"id\":1229},{\"id\":1230},{\"id\":1231},{\"id\":1232},{\"id\":1233},{\"id\":1234},{\"id\":1235},{\"id\":1236},{\"id\":1237},{\"id\":1238},{\"id\":1239},{\"id\":1240},{\"id\":1241},{\"id\":1242},{\"id\":1243},{\"id\":1244},{\"id\":1245},{\"id\":1246},{\"id\":1247},{\"id\":1248},{\"id\":1249},{\"id\":1250},{\"id\":1251},{\"id\":1252},{\"id\":1253},{\"id\":1254},{\"id\":1255},{\"id\":1256},{\"id\":1257},{\"id\":1258},{\"id\":1259},{\"id\":1260},{\"id\":1261},{\"id\":1262},{\"id\":1263},{\"id\":1264},{\"id\":1265},{\"id\":1266},{\"id\":1267},{\"id\":1268},{\"id\":1269},{\"id\":1270},{\"id\":1271},{\"id\":1272},{\"id\":1273},{\"id\":1274},{\"id\":1275},{\"id\":1276},{\"id\":1277},{\"id\":1278},{\"id\":1279},{\"id\":1280},{\"id\":1281},{\"id\":1282},{\"id\":1283},{\"id\":1284},{\"id\":1285},{\"id\":1286},{\"id\":1287},{\"id\":1288},{\"id\":1289},{\"id\":1290},{\"id\":1291},{\"id\":1292},{\"id\":1293},{\"id\":1294},{\"id\":1295},{\"id\":1296},{\"id\":1297},{\"id\":1298},{\"id\":1299},{\"id\":1300},{\"id\":1301},{\"id\":1302},{\"id\":1303},{\"id\":1304},{\"id\":1305},{\"id\":1306},{\"id\":1307},{\"id\":1308},{\"id\":1309},{\"id\":1310},{\"id\":1311},{\"id\":1312},{\"id\":1313},{\"id\":1314},{\"id\":1315},{\"id\":1316},{\"id\":1317},{\"id\":1318},{\"id\":1319},{\"id\":1320},{\"id\":1321},{\"id\":1322},{\"id\":1323},{\"id\":1324},{\"id\":1325},{\"id\":1326},{\"id\":1327},{\"id\":1328},{\"id\":1329},{\"id\":1330},{\"id\":1331},{\"id\":1332},{\"id\":1333},{\"id\":1334},{\"id\":1335},{\"id\":1336},{\"id\":1337},{\"id\":1338},{\"id\":1339},{\"id\":1340},{\"id\":1341},{\"id\":1342},{\"id\":1343},{\"id\":1344},{\"id\":1345},{\"id\":1346},{\"id\":1347},{\"id\":1348},{\"id\":1349},{\"id\":1350},{\"id\":1351},{\"id\":1352},{\"id\":1353},{\"id\":1354},{\"id\":1355},{\"id\":1356},{\"id\":1357},{\"id\":1358},{\"id\":1359},{\"id\":1360},{\"id\":1361},{\"id\":1362},{\"id\":1363},{\"id\":1364},{\"id\":1365},{\"id\":1366},{\"id\":1367},{\"id\":1368},{\"id\":1369},{\"id\":1370},{\"id\":1371},{\"id\":1372},{\"id\":1373},{\"id\":1374},{\"id\":1375},{\"id\":1376},{\"id\":1377},{\"id\":1378},{\"id\":1379},{\"id\":1380},{\"id\":1381},{\"id\":1382},{\"id\":1383},{\"id\":1384},{\"id\":1385},{\"id\":1386},{\"id\":1387},{\"id\":1388},{\"id\":1389},{\"id\":1390},{\"id\":1391},{\"id\":1392},{\"id\":1393},{\"id\":1394},{\"id\":1395},{\"id\":1396},{\"id\":1397},{\"id\":1398},{\"id\":1399},{\"id\":1400},{\"id\":1401},{\"id\":1402},{\"id\":1403},{\"id\":1404},{\"id\":1405},{\"id\":1406},{\"id\":1407},{\"id\":1408},{\"id\":1409},{\"id\":1410},{\"id\":1411},{\"id\":1412},{\"id\":1413},{\"id\":1414},{\"id\":1415},{\"id\":1416},{\"id\":1417},{\"id\":1418},{\"id\":1419},{\"id\":1420},{\"id\":1421},{\"id\":1422},{\"id\":1423},{\"id\":1424},{\"id\":1425},{\"id\":1426},{\"id\":1427},{\"id\":1428},{\"id\":1429},{\"id\":1430},{\"id\":1431},{\"id\":1432},{\"id\":1433},{\"id\":1434},{\"id\":1435},{\"id\":1436},{\"id\":1437},{\"id\":1438},{\"id\":1439},{\"id\":1440},{\"id\":1441},{\"id\":1442},{\"id\":1443},{\"id\":1444},{\"id\":1445},{\"id\":1446},{\"id\":1447},{\"id\":1448},{\"id\":1449},{\"id\":1450},{\"id\":1451},{\"id\":1452},{\"id\":1453},{\"id\":1454},{\"id\":1455},{\"id\":1456},{\"id\":1457},{\"id\":1458},{\"id\":1459},{\"id\":1460},{\"id\":1461},{\"id\":1462},{\"id\":1463},{\"id\":1464},{\"id\":1465},{\"id\":1466},{\"id\":1467},{\"id\":1468},{\"id\":1469},{\"id\":1470},{\"id\":1471},{\"id\":1472},{\"id\":1473},{\"id\":1474},{\"id\":1475},{\"id\":1476},{\"id\":1477},{\"id\":1478},{\"id\":1479},{\"id\":1480},{\"id\":1481},{\"id\":1482},{\"id\":1483},{\"id\":1484},{\"id\":1485},{\"id\":1486},{\"id\":1487},{\"id\":1488},{\"id\":1489},{\"id\":1490},{\"id\":1491},{\"id\":1492},{\"id\":1493},{\"id\":1494},{\"id\":1495},{\"id\":1496},{\"id\":1497},{\"id\":1498},{\"id\":1499},{\"id\":1500},{\"id\":1501},{\"id\":1502},{\"id\":1503},{\"id\":1504},{\"id\":1505},{\"id\":1506},{\"id\":1507},{\"id\":1508},{\"id\":1509},{\"id\":1510},{\"id\":1511},{\"id\":1512},{\"id\":1513},{\"id\":1514},{\"id\":1515},{\"id\":1516},{\"id\":1517},{\"id\":1518},{\"id\":1519},{\"id\":1520},{\"id\":1521},{\"id\":1522},{\"id\":1523},{\"id\":1524},{\"id\":1525},{\"id\":1526},{\"id\":1527},{\"id\":1528},{\"id\":1529},{\"id\":1530},{\"id\":1531},{\"id\":1532},{\"id\":1533},{\"id\":1534},{\"id\":1535},{\"id\":1536},{\"id\":1537},{\"id\":1538},{\"id\":1539},{\"id\":1540},{\"id\":1541},{\"id\":1542},{\"id\":1543},{\"id\":1544},{\"id\":1545},{\"id\":1546},{\"id\":1547},{\"id\":1548},{\"id\":1549},{\"id\":1550},{\"id\":1551},{\"id\":1552},{\"id\":1553},{\"id\":1554},{\"id\":1555},{\"id\":1556},{\"id\":1557},{\"id\":1558},{\"id\":1559},{\"id\":1560},{\"id\":1561},{\"id\":1562},{\"id\":1563},{\"id\":1564},{\"id\":1565},{\"id\":1566},{\"id\":1567},{\"id\":1568},{\"id\":1569},{\"id\":1570},{\"id\":1571},{\"id\":1572},{\"id\":1573},{\"id\":1574},{\"id\":1575},{\"id\":1576},{\"id\":1577},{\"id\":1578},{\"id\":1579},{\"id\":1580},{\"id\":1581},{\"id\":1582},{\"id\":1583},{\"id\":1584},{\"id\":1585},{\"id\":1586},{\"id\":1587},{\"id\":1588},{\"id\":1589},{\"id\":1590},{\"id\":1591},{\"id\":1592},{\"id\":1593},{\"id\":1594},{\"id\":1595},{\"id\":1596},{\"id\":1597},{\"id\":1598},{\"id\":1599},{\"id\":1600},{\"id\":1601},{\"id\":1602},{\"id\":1603},{\"id\":1604},{\"id\":1605},{\"id\":1606},{\"id\":1607},{\"id\":1608},{\"id\":1609},{\"id\":1610},{\"id\":1611},{\"id\":1612},{\"id\":1613},{\"id\":1614},{\"id\":1615},{\"id\":1616},{\"id\":1617},{\"id\":1618},{\"id\":1619},{\"id\":1620},{\"id\":1621},{\"id\":1622},{\"id\":1623},{\"id\":1624},{\"id\":1625},{\"id\":1626},{\"id\":1627},{\"id\":1628},{\"id\":1629},{\"id\":1630},{\"id\":1631},{\"id\":1632},{\"id\":1633},{\"id\":1634},{\"id\":1635},{\"id\":1636},{\"id\":1637},{\"id\":1638},{\"id\":1639},{\"id\":1640},{\"id\":1641},{\"id\":1642},{\"id\":1643},{\"id\":1644},{\"id\":1645},{\"id\":1646},{\"id\":1647},{\"id\":1648},{\"id\":1649},{\"id\":1650},{\"id\":1651},{\"id\":1652},{\"id\":1653},{\"id\":1654},{\"id\":1655},{\"id\":1656},{\"id\":1657},{\"id\":1658},{\"id\":1659},{\"id\":1660},{\"id\":1661},{\"id\":1662},{\"id\":1663},{\"id\":1664},{\"id\":1665},{\"id\":1666},{\"id\":1667},{\"id\":1668},{\"id\":1669},{\"id\":1670},{\"id\":1671},{\"id\":1672},{\"id\":1673},{\"id\":1674},{\"id\":1675},{\"id\":1676},{\"id\":1677},{\"id\":1678},{\"id\":1679},{\"id\":1680},{\"id\":1681},{\"id\":1682},{\"id\":1683},{\"id\":1684},{\"id\":1685},{\"id\":1686},{\"id\":1687},{\"id\":1688},{\"id\":1689},{\"id\":1690},{\"id\":1691},{\"id\":1692},{\"id\":1693},{\"id\":1694},{\"id\":1695},{\"id\":1696},{\"id\":1697},{\"id\":1698},{\"id\":1699},{\"id\":1700},{\"id\":1701},{\"id\":1702},{\"id\":1703},{\"id\":1704},{\"id\":1705},{\"id\":1706},{\"id\":1707},{\"id\":1708},{\"id\":1709},{\"id\":1710},{\"id\":1711},{\"id\":1712},{\"id\":1713},{\"id\":1714},{\"id\":1715},{\"id\":1716},{\"id\":1717},{\"id\":1718},{\"id\":1719},{\"id\":1720},{\"id\":1721},{\"id\":1722},{\"id\":1723},{\"id\":1724},{\"id\":1725},{\"id\":1726},{\"id\":1727},{\"id\":1728},{\"id\":1729},{\"id\":1730},{\"id\":1731},{\"id\":1732},{\"id\":1733},{\"id\":1734},{\"id\":1735},{\"id\":1736},{\"id\":1737},{\"id\":1738},{\"id\":1739},{\"id\":1740},{\"id\":1741},{\"id\":1742},{\"id\":1743},{\"id\":1744},{\"id\":1745},{\"id\":1746},{\"id\":1747},{\"id\":1748},{\"id\":1749},{\"id\":1750},{\"id\":1751},{\"id\":1752},{\"id\":1753},{\"id\":1754},{\"id\":1755},{\"id\":1756},{\"id\":1757},{\"id\":1758},{\"id\":1759},{\"id\":1760},{\"id\":1761},{\"id\":1762},{\"id\":1763},{\"id\":1764},{\"id\":1765},{\"id\":1766},{\"id\":1767},{\"id\":1768},{\"id\":1769},{\"id\":1770},{\"id\":1771},{\"id\":1772},{\"id\":1773},{\"id\":1774},{\"id\":1775},{\"id\":1776},{\"id\":1777},{\"id\":1778},{\"id\":1779},{\"id\":1780},{\"id\":1781},{\"id\":1782},{\"id\":1783},{\"id\":1784},{\"id\":1785},{\"id\":1786},{\"id\":1787},{\"id\":1788},{\"id\":1789},{\"id\":1790},{\"id\":1791},{\"id\":1792},{\"id\":1793},{\"id\":1794},{\"id\":1795},{\"id\":1796},{\"id\":1797},{\"id\":1798},{\"id\":1799},{\"id\":1800},{\"id\":1801},{\"id\":1802},{\"id\":1803},{\"id\":1804},{\"id\":1805},{\"id\":1806},{\"id\":1807},{\"id\":1808},{\"id\":1809},{\"id\":1810},{\"id\":1811},{\"id\":1812},{\"id\":1813},{\"id\":1814},{\"id\":1815},{\"id\":1816},{\"id\":1817},{\"id\":1818},{\"id\":1819},{\"id\":1820},{\"id\":1821},{\"id\":1822},{\"id\":1823},{\"id\":1824},{\"id\":1825},{\"id\":1826},{\"id\":1827},{\"id\":1828},{\"id\":1829},{\"id\":1830},{\"id\":1831},{\"id\":1832},{\"id\":1833},{\"id\":1834},{\"id\":1835},{\"id\":1836},{\"id\":1837},{\"id\":1838},{\"id\":1839},{\"id\":1840},{\"id\":1841},{\"id\":1842},{\"id\":1843},{\"id\":1844},{\"id\":1845},{\"id\":1846},{\"id\":1847},{\"id\":1848},{\"id\":1849},{\"id\":1850},{\"id\":1851},{\"id\":1852},{\"id\":1853},{\"id\":1854},{\"id\":1855},{\"id\":1856},{\"id\":1857},{\"id\":1858},{\"id\":1859},{\"id\":1860},{\"id\":1861},{\"id\":1862},{\"id\":1863},{\"id\":1864},{\"id\":1865},{\"id\":1866},{\"id\":1867},{\"id\":1868},{\"id\":1869},{\"id\":1870},{\"id\":1871},{\"id\":1872},{\"id\":1873},{\"id\":1874},{\"id\":1875},{\"id\":1876},{\"id\":1877},{\"id\":1878},{\"id\":1879},{\"id\":1880},{\"id\":1881},{\"id\":1882},{\"id\":1883},{\"id\":1884},{\"id\":1885},{\"id\":1886},{\"id\":1887},{\"id\":1888},{\"id\":1889},{\"id\":1890},{\"id\":1891},{\"id\":1892},{\"id\":1893},{\"id\":1894},{\"id\":1895},{\"id\":1896},{\"id\":1897},{\"id\":1898},{\"id\":1899},{\"id\":1900},{\"id\":1901},{\"id\":1902},{\"id\":1903},{\"id\":1904},{\"id\":1905},{\"id\":1906},{\"id\":1907},{\"id\":1908},{\"id\":1909},{\"id\":1910},{\"id\":1911},{\"id\":1912},{\"id\":1913},{\"id\":1914},{\"id\":1915},{\"id\":1916},{\"id\":1917},{\"id\":1918},{\"id\":1919},{\"id\":1920},{\"id\":1921},{\"id\":1922},{\"id\":1923},{\"id\":1924},{\"id\":1925},{\"id\":1926},{\"id\":1927},{\"id\":1928},{\"id\":1929},{\"id\":1930},{\"id\":1931},{\"id\":1932},{\"id\":1933},{\"id\":1934},{\"id\":1935},{\"id\":1936},{\"id\":1937},{\"id\":1938},{\"id\":1939},{\"id\":1940},{\"id\":1941},{\"id\":1942},{\"id\":1943},{\"id\":1944},{\"id\":1945},{\"id\":1946},{\"id\":1947},{\"id\":1948},{\"id\":1949},{\"id\":1950},{\"id\":1951},{\"id\":1952},{\"id\":1953},{\"id\":1954},{\"id\":1955},{\"id\":1956},{\"id\":1957},{\"id\":1958},{\"id\":1959},{\"id\":1960},{\"id\":1961},{\"id\":1962},{\"id\":1963},{\"id\":1964},{\"id\":1965},{\"id\":1966},{\"id\":1967},{\"id\":1968},{\"id\":1969},{\"id\":1970},{\"id\":1971},{\"id\":1972},{\"id\":1973},{\"id\":1974},{\"id\":1975},{\"id\":1976},{\"id\":1977},{\"id\":1978},{\"id\":1979},{\"id\":1980},{\"id\":1981},{\"id\":1982},{\"id\":1983},{\"id\":1984},{\"id\":1985},{\"id\":1986},{\"id\":1987},{\"id\":1988},{\"id\":1989},{\"id\":1990},{\"id\":1991},{\"id\":1992},{\"id\":1993},{\"id\":1994},{\"id\":1995},{\"id\":1996},{\"id\":1997},{\"id\":1998},{\"id\":1999},{\"id\":2000},{\"id\":2001},{\"id\":2002},{\"id\":2003},{\"id\":2004},{\"id\":2005},{\"id\":2006},{\"id\":2007},{\"id\":2008},{\"id\":2009},{\"id\":2010},{\"id\":2011},{\"id\":2012},{\"id\":2013},{\"id\":2014},{\"id\":2015},{\"id\":2016},{\"id\":2017},{\"id\":2018},{\"id\":2019},{\"id\":2020},{\"id\":2021},{\"id\":2022},{\"id\":2023},{\"id\":2024},{\"id\":2025},{\"id\":2026},{\"id\":2027},{\"id\":2028},{\"id\":2029},{\"id\":2030},{\"id\":2031},{\"id\":2032},{\"id\":2033},{\"id\":2034},{\"id\":2035},{\"id\":2036},{\"id\":2037},{\"id\":2038},{\"id\":2039},{\"id\":2040},{\"id\":2041},{\"id\":2042},{\"id\":2043},{\"id\":2044},{\"id\":2045},{\"id\":2046},{\"id\":2047},{\"id\":2048},{\"id\":2049},{\"id\":2050},{\"id\":2051},{\"id\":2052},{\"id\":2053},{\"id\":2054},{\"id\":2055},{\"id\":2056},{\"id\":2057},{\"id\":2058},{\"id\":2059},{\"id\":2060},{\"id\":2061},{\"id\":2062},{\"id\":2063},{\"id\":2064},{\"id\":2065},{\"id\":2066},{\"id\":2067},{\"id\":2068},{\"id\":2069},{\"id\":2070},{\"id\":2071},{\"id\":2072},{\"id\":2073},{\"id\":2074},{\"id\":2075},{\"id\":2076},{\"id\":2077},{\"id\":2078},{\"id\":2079},{\"id\":2080},{\"id\":2081},{\"id\":2082},{\"id\":2083},{\"id\":2084},{\"id\":2085},{\"id\":2086},{\"id\":2087},{\"id\":2088},{\"id\":2089},{\"id\":2090},{\"id\":2091},{\"id\":2092},{\"id\":2093},{\"id\":2094},{\"id\":2095},{\"id\":2096},{\"id\":2097},{\"id\":2098},{\"id\":2099},{\"id\":2100},{\"id\":2101},{\"id\":2102},{\"id\":2103},{\"id\":2104},{\"id\":2105},{\"id\":2106},{\"id\":2107},{\"id\":2108},{\"id\":2109},{\"id\":2110},{\"id\":2111},{\"id\":2112},{\"id\":2113},{\"id\":2114},{\"id\":2115},{\"id\":2116},{\"id\":2117},{\"id\":2118},{\"id\":2119},{\"id\":2120},{\"id\":2121},{\"id\":2122},{\"id\":2123},{\"id\":2124},{\"id\":2125},{\"id\":2126},{\"id\":2127},{\"id\":2128},{\"id\":2129},{\"id\":2130},{\"id\":2131},{\"id\":2132},{\"id\":2133},{\"id\":2134},{\"id\":2135},{\"id\":2136},{\"id\":2137},{\"id\":2138},{\"id\":2139},{\"id\":2140},{\"id\":2141},{\"id\":2142},{\"id\":2143},{\"id\":2144},{\"id\":2145},{\"id\":2146},{\"id\":2147},{\"id\":2148},{\"id\":2149},{\"id\":2150},{\"id\":2151},{\"id\":2152},{\"id\":2153},{\"id\":2154},{\"id\":2155},{\"id\":2156},{\"id\":2157},{\"id\":2158},{\"id\":2159},{\"id\":2160},{\"id\":2161},{\"id\":2162},{\"id\":2163},{\"id\":2164},{\"id\":2165},{\"id\":2166},{\"id\":2167},{\"id\":2168},{\"id\":2169},{\"id\":2170},{\"id\":2171},{\"id\":2172},{\"id\":2173},{\"id\":2174},{\"id\":2175},{\"id\":2176},{\"id\":2177},{\"id\":2178},{\"id\":2179},{\"id\":2180},{\"id\":2181},{\"id\":2182},{\"id\":2183},{\"id\":2184},{\"id\":2185},{\"id\":2186},{\"id\":2187},{\"id\":2188},{\"id\":2189},{\"id\":2190},{\"id\":2191},{\"id\":2192},{\"id\":2193},{\"id\":2194},{\"id\":2195},{\"id\":2196},{\"id\":2197},{\"id\":2198},{\"id\":2199},{\"id\":2200},{\"id\":2201},{\"id\":2202},{\"id\":2203},{\"id\":2204},{\"id\":2205},{\"id\":2206},{\"id\":2207},{\"id\":2208},{\"id\":2209},{\"id\":2210},{\"id\":2211},{\"id\":2212},{\"id\":2213},{\"id\":2214},{\"id\":2215},{\"id\":2216},{\"id\":2217},{\"id\":2218},{\"id\":2219},{\"id\":2220},{\"id\":2221},{\"id\":2222},{\"id\":2223},{\"id\":2224},{\"id\":2225},{\"id\":2226},{\"id\":2227},{\"id\":2228},{\"id\":2229},{\"id\":2230},{\"id\":2231},{\"id\":2232},{\"id\":2233},{\"id\":2234},{\"id\":2235},{\"id\":2236},{\"id\":2237},{\"id\":2238},{\"id\":2239},{\"id\":2240},{\"id\":2241},{\"id\":2242},{\"id\":2243},{\"id\":2244},{\"id\":2245},{\"id\":2246},{\"id\":2247},{\"id\":2248},{\"id\":2249},{\"id\":2250},{\"id\":2251},{\"id\":2252},{\"id\":2253},{\"id\":2254},{\"id\":2255},{\"id\":2256},{\"id\":2257},{\"id\":2258},{\"id\":2259},{\"id\":2260},{\"id\":2261},{\"id\":2262},{\"id\":2263},{\"id\":2264},{\"id\":2265},{\"id\":2266},{\"id\":2267},{\"id\":2268},{\"id\":2269},{\"id\":2270},{\"id\":2271},{\"id\":2272},{\"id\":2273},{\"id\":2274},{\"id\":2275},{\"id\":2276},{\"id\":2277},{\"id\":2278},{\"id\":2279},{\"id\":2280},{\"id\":2281},{\"id\":2282},{\"id\":2283},{\"id\":2284},{\"id\":2285},{\"id\":2286},{\"id\":2287},{\"id\":2288},{\"id\":2289},{\"id\":2290},{\"id\":2291},{\"id\":2292},{\"id\":2293},{\"id\":2294},{\"id\":2295},{\"id\":2296},{\"id\":2297},{\"id\":2298},{\"id\":2299},{\"id\":2300},{\"id\":2301},{\"id\":2302},{\"id\":2311},{\"id\":2316},{\"id\":2317},{\"id\":2343},{\"id\":2344},{\"id\":2393},{\"id\":2318},{\"id\":2345},{\"id\":2346},{\"id\":2394},{\"id\":2319},{\"id\":2347},{\"id\":2348},{\"id\":2395},{\"id\":2320},{\"id\":2349},{\"id\":2350},{\"id\":2396},{\"id\":2321},{\"id\":2351},{\"id\":2352},{\"id\":2397},{\"id\":2322},{\"id\":2353},{\"id\":2354},{\"id\":2398},{\"id\":2323},{\"id\":2355},{\"id\":2356},{\"id\":2399},{\"id\":2324},{\"id\":2357},{\"id\":2358},{\"id\":2400},{\"id\":2325},{\"id\":2359},{\"id\":2360},{\"id\":2401},{\"id\":2326},{\"id\":2361},{\"id\":2362},{\"id\":2402},{\"id\":2327},{\"id\":2363},{\"id\":2364},{\"id\":2403},{\"id\":2328},{\"id\":2365},{\"id\":2366},{\"id\":2404},{\"id\":2329},{\"id\":2367},{\"id\":2368},{\"id\":2405},{\"id\":2330},{\"id\":2369},{\"id\":2370},{\"id\":2406},{\"id\":2331},{\"id\":2371},{\"id\":2372},{\"id\":2407},{\"id\":2332},{\"id\":2373},{\"id\":2374},{\"id\":2408},{\"id\":2333},{\"id\":2375},{\"id\":2376},{\"id\":2409},{\"id\":2334},{\"id\":2377},{\"id\":2378},{\"id\":2410},{\"id\":2335},{\"id\":2379},{\"id\":2380},{\"id\":2411},{\"id\":2336},{\"id\":2381},{\"id\":2382},{\"id\":2412},{\"id\":2337},{\"id\":2383},{\"id\":2384},{\"id\":2413},{\"id\":2338},{\"id\":2385},{\"id\":2386},{\"id\":2414},{\"id\":2339},{\"id\":2387},{\"id\":2388},{\"id\":2415},{\"id\":2340},{\"id\":2389},{\"id\":2390},{\"id\":2416},{\"id\":2341},{\"id\":2391},{\"id\":2392},{\"id\":2417},{\"id\":2342},{\"id\":2418},{\"id\":2419},{\"id\":2312},{\"id\":2420},{\"id\":2421},{\"id\":2435},{\"id\":2436},{\"id\":2461},{\"id\":2422},{\"id\":2437},{\"id\":2438},{\"id\":2462},{\"id\":2423},{\"id\":2439},{\"id\":2440},{\"id\":2463},{\"id\":2424},{\"id\":2441},{\"id\":2442},{\"id\":2464},{\"id\":2425},{\"id\":2443},{\"id\":2444},{\"id\":2465},{\"id\":2426},{\"id\":2445},{\"id\":2446},{\"id\":2466},{\"id\":2427},{\"id\":2447},{\"id\":2448},{\"id\":2467},{\"id\":2428},{\"id\":2449},{\"id\":2450},{\"id\":2468},{\"id\":2429},{\"id\":2451},{\"id\":2452},{\"id\":2469},{\"id\":2430},{\"id\":2453},{\"id\":2454},{\"id\":2470},{\"id\":2431},{\"id\":2455},{\"id\":2456},{\"id\":2471},{\"id\":2432},{\"id\":2457},{\"id\":2458},{\"id\":2472},{\"id\":2433},{\"id\":2459},{\"id\":2460},{\"id\":2473},{\"id\":2434},{\"id\":2474},{\"id\":2475},{\"id\":2313},{\"id\":2476},{\"id\":2488},{\"id\":2477},{\"id\":2489},{\"id\":2478},{\"id\":2490},{\"id\":2479},{\"id\":2491},{\"id\":2480},{\"id\":2492},{\"id\":2481},{\"id\":2493},{\"id\":2482},{\"id\":2494},{\"id\":2483},{\"id\":2495},{\"id\":2484},{\"id\":2496},{\"id\":2485},{\"id\":2497},{\"id\":2486},{\"id\":2498},{\"id\":2487},{\"id\":2499},{\"id\":2314},{\"id\":2500},{\"id\":2501},{\"id\":2502},{\"id\":2503},{\"id\":2504},{\"id\":2505},{\"id\":2506},{\"id\":2507},{\"id\":2508},{\"id\":2509},{\"id\":2510},{\"id\":2511},{\"id\":2512},{\"id\":2513},{\"id\":2514},{\"id\":2515},{\"id\":2516},{\"id\":2517},{\"id\":2518},{\"id\":2519},{\"id\":2520},{\"id\":2521},{\"id\":2522},{\"id\":2523},{\"id\":2315},{\"id\":2524},{\"id\":2542},{\"id\":2543},{\"id\":2578},{\"id\":2525},{\"id\":2544},{\"id\":2545},{\"id\":2579},{\"id\":2526},{\"id\":2546},{\"id\":2547},{\"id\":2580},{\"id\":2527},{\"id\":2548},{\"id\":2549},{\"id\":2581},{\"id\":2528},{\"id\":2550},{\"id\":2551},{\"id\":2582},{\"id\":2529},{\"id\":2552},{\"id\":2553},{\"id\":2583},{\"id\":2530},{\"id\":2554},{\"id\":2555},{\"id\":2584},{\"id\":2531},{\"id\":2556},{\"id\":2557},{\"id\":2585},{\"id\":2532},{\"id\":2558},{\"id\":2559},{\"id\":2586},{\"id\":2533},{\"id\":2560},{\"id\":2561},{\"id\":2587},{\"id\":2534},{\"id\":2562},{\"id\":2563},{\"id\":2588},{\"id\":2535},{\"id\":2564},{\"id\":2565},{\"id\":2589},{\"id\":2536},{\"id\":2566},{\"id\":2567},{\"id\":2590},{\"id\":2537},{\"id\":2568},{\"id\":2569},{\"id\":2591},{\"id\":2538},{\"id\":2570},{\"id\":2571},{\"id\":2592},{\"id\":2539},{\"id\":2572},{\"id\":2573},{\"id\":2593},{\"id\":2540},{\"id\":2574},{\"id\":2575},{\"id\":2594},{\"id\":2541},{\"id\":2576},{\"id\":2577},{\"id\":2595},{\"id\":2303},{\"id\":2304},{\"id\":2305},{\"id\":2306},{\"id\":2307},{\"nodeType\":3,\"id\":2596,\"textContent\":\" // Track clicks on page $(document).ready(function() { $(\\\".control\\\").click(function(e) { e.stopImmediatePropagation(); clicks = clicks + 1; console.log(clicks); }); }); $('.userid').html(sid); // console.log(\\\"start of clicked array: \\\"+clicked); // console.log(\\\"start of hovered string: \\\"+hovered); //set correct answers for each question var triangular_answers = { \\\"acme.starttime.1\\\" : [\\\"F\\\"], \\\"acme.starts.1\\\" : [\\\"K\\\"], \\\"acme.meets.1\\\" : [\\\"F\\\"], \\\"acme.endtime.1\\\" : [\\\"H\\\"], \\\"acme.midpoint.1\\\" : [\\\"O\\\"], \\\"acme.starttime.2\\\" : [\\\"F\\\"], \\\"acme.starts.2\\\" : [\\\"K\\\"], \\\"acme.meets.2\\\" : [\\\"F\\\"], \\\"acme.endtime.2\\\" : [\\\"H\\\"], \\\"acme.midpoint.2\\\" : [\\\"A\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"E\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"E\\\"], \\\"bigset.starttime.1\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.1\\\" : [\\\"G\\\"], \\\"bigset.meets.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.1\\\" : [\\\"X\\\"], \\\"bigset.midpoint.1\\\" : [\\\"K\\\",\\\"X\\\"], \\\"bigset.starttime.2\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.2\\\" : [\\\"G\\\"], \\\"bigset.meets.2\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.2\\\" : [\\\"X\\\"], \\\"bigset.midpoint.2\\\" : [\\\"K\\\",\\\"X\\\"] } var orthogonal_answers = { \\\"acme.starttime.1\\\" : [\\\"A\\\"], \\\"acme.starts.1\\\" : [\\\"E\\\"], \\\"acme.meets.1\\\" : [\\\"Z\\\"], \\\"acme.endtime.1\\\" : [\\\"U\\\"], \\\"acme.midpoint.1\\\" : [\\\"U\\\"], \\\"acme.starttime.2\\\" : [\\\"0\\\"], \\\"acme.starts.2\\\" : [\\\"0\\\"], \\\"acme.meets.2\\\" : [\\\"0\\\"], \\\"acme.endtime.2\\\" : [\\\"0\\\"], \\\"acme.midpoint.2\\\" : [\\\"0\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"X\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"X\\\"], \\\"bigset.starttime.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.1\\\" : [\\\"B\\\"], \\\"bigset.meets.1\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.1\\\" : [\\\"B\\\"], \\\"bigset.midpoint.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.starttime.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.2\\\" : [\\\"B\\\"], \\\"bigset.meets.2\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.2\\\" : [\\\"B\\\"], \\\"bigset.midpoint.2\\\" : [\\\"E\\\",\\\"F\\\"] } //display the question and answer buttons based on input values from jsPsych document.getElementById(scenario+\\\".\\\"+question).style.display = \\\"block\\\"; if (question == \\\"strategy\\\") {document.getElementById(\\\"strategyButton\\\").style.display = \\\"block\\\";} else {document.getElementById(\\\"testingButton\\\").style.display = \\\"block\\\";} //---------SET PROPERTIES OF THE GRAPH -------------// // set the dimensions and margins of the graph var margin = {top: 25, right: 30, bottom: 90, left: 100}, width = 800, height = 800; var intersects = false; //default value for intersects scaffold var xAxisTitle, yAxisTitle; var datafile =\\\"\\\"; // SET AXIS VALUES if (axis == 1){ axis = \\\"Orthogonal-XInside-YFull\\\"; } else if (axis == 2){ axis = \\\"Orthogonal-XInside-YPartial\\\"; } else if (axis ==3){ axis = \\\"Triangular-XInside-YInside\\\"; } else if (axis ==4){ axis = \\\"Orthogonal-XInside-YInside\\\"; } else if (axis ==5){ axis = \\\"Orthogonal-XFull-YFull\\\"; } // SET EXPLICIT SCAFFOLD FEATURES if (explicit ==2 && axis != \\\"diagonal\\\"){ scaffold = 2; intersects = false; } else if (explicit == 2 && axis == \\\"diagonal\\\"){ scaffold = 2; intersects = false; } //TODO: not sure if above two lines are still valid since leaders are now generated on the fly else if (explicit == 3){ $('#hint-interactive').css(\\\"display\\\",\\\"block\\\"); //display textimage scaffold intersects = true; } //SET DATA FILE FOR IMPLICIT SCAFFOLD if (impasse == 1){ datafile = \\\"../views/src/data/acme_nonimpasse.csv\\\"; } else if (impasse == 2){ datafile = \\\"../views/src/data/acme_impasse.csv\\\"; } //OVERRIDE DATA FILE FOR NON-SCAFFOLD QUESTIONS if (q > 5) { //override data file if q# is greater than 5 datafile = \\\"../views/src/data/bigset.csv\\\"; console.log(\\\"override data file\\\"); $('#orthogonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#diagonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#hint-interactive').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold intersects = false; } // //---------CREATE THE SVG ------------------------// var svg = d3.select(\\\".d3container\\\").append(\\\"svg\\\") .attr(\\\"width\\\", width + margin.left + margin.right) .attr(\\\"height\\\", height + margin.top + margin.bottom) .append(\\\"g\\\") .attr(\\\"transform\\\", \\\"translate(\\\" + margin.left + \\\",\\\" + margin.top + \\\")\\\"); //---------DRAW THE GRAPH ------------------------// xAxisTitle = \\\"START & END TIME (time of day)\\\"; yAxisTitle = \\\"DURATION (in hours)\\\"; drawTriangleModel(datafile,intersects,axis,scaffold,q); \"},{\"id\":2308},{\"id\":2309},{\"nodeType\":3,\"id\":2597,\"textContent\":\" //MOUSE LOGGING SCRIPT var mouseLog = [] var xwidth = $(document).width(); var xheight = $(document).width(); mouseLog.push(\\\"{x:\\\"+xwidth+\\\",y:\\\"+xheight+\\\",t:\\\"+\\\"0};\\\") document.onmousemove = function(e){ var pageCoords = \\\"{x:\\\" + e.pageX + \\\",y:\\\"+ e.pageY +\\\",t:\\\"+ Date.now()+ \\\"};\\\" ; mouseLog.push(pageCoords); // console.log(pageCoords); }; \"},{\"id\":2310}],[],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2598,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2599,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2598},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2600,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2599},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2601,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":2600},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2602,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2599}},{\"nodeType\":1,\"id\":2603,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2602},\"parentNode\":{\"id\":2599}},{\"nodeType\":3,\"id\":2604,\"textContent\":\"What is your age?\",\"parentNode\":{\"id\":2602}},{\"nodeType\":1,\"id\":2605,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2600}},{\"nodeType\":1,\"id\":2606,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2605},\"parentNode\":{\"id\":2600}},{\"nodeType\":3,\"id\":2607,\"textContent\":\"In what country were you born?\",\"parentNode\":{\"id\":2605}},{\"nodeType\":3,\"id\":2608,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":2601}}],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2598},{\"id\":2599},{\"id\":2602},{\"id\":2604},{\"id\":2603},{\"id\":2600},{\"id\":2605},{\"id\":2607},{\"id\":2606},{\"id\":2601},{\"id\":2608}],[],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2609,\"tagName\":\"FORM\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-form\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2610,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-preamble\",\"class\":\"jspsych-survey-multi-choice-preamble\"},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2611,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-0\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2610},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2612,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-1\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2611},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2613,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-2\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2612},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2614,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-3\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2613},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2615,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"submit\",\"id\":\"jspsych-survey-multi-choice-next\",\"class\":\"jspsych-survey-multi-choice jspsych-btn\",\"value\":\"Submit Answers\"},\"previousSibling\":{\"id\":2614},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2616,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2617,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2616},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2618,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2617},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2619,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2618},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2620,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2619},\"parentNode\":{\"id\":2611}},{\"nodeType\":3,\"id\":2621,\"textContent\":\"What is your first language?\",\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2622,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2621},\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2623,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2624,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2623}},{\"nodeType\":3,\"id\":2625,\"textContent\":\"English\",\"previousSibling\":{\"id\":2624},\"parentNode\":{\"id\":2623}},{\"nodeType\":1,\"id\":2626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2618}},{\"nodeType\":1,\"id\":2627,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2626}},{\"nodeType\":3,\"id\":2628,\"textContent\":\"Spanish\",\"previousSibling\":{\"id\":2627},\"parentNode\":{\"id\":2626}},{\"nodeType\":1,\"id\":2629,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2619}},{\"nodeType\":1,\"id\":2630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2629}},{\"nodeType\":3,\"id\":2631,\"textContent\":\"Mandarin or Cantonese\",\"previousSibling\":{\"id\":2630},\"parentNode\":{\"id\":2629}},{\"nodeType\":1,\"id\":2632,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2633,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2634,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2633},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2635,\"textContent\":\"*\",\"parentNode\":{\"id\":2622}},{\"nodeType\":1,\"id\":2636,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2637,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2636},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2638,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2637},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2639,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2638},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2640,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2639},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2641,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2640},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2642,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2641},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2643,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2642},\"parentNode\":{\"id\":2612}},{\"nodeType\":3,\"id\":2644,\"textContent\":\"What is your year in school?\",\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2645,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2644},\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2646,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2637}},{\"nodeType\":1,\"id\":2647,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2646}},{\"nodeType\":3,\"id\":2648,\"textContent\":\"First\",\"previousSibling\":{\"id\":2647},\"parentNode\":{\"id\":2646}},{\"nodeType\":1,\"id\":2649,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2638}},{\"nodeType\":1,\"id\":2650,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2649}},{\"nodeType\":3,\"id\":2651,\"textContent\":\"Second\",\"previousSibling\":{\"id\":2650},\"parentNode\":{\"id\":2649}},{\"nodeType\":1,\"id\":2652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2639}},{\"nodeType\":1,\"id\":2653,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2652}},{\"nodeType\":3,\"id\":2654,\"textContent\":\"Third\",\"previousSibling\":{\"id\":2653},\"parentNode\":{\"id\":2652}},{\"nodeType\":1,\"id\":2655,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2640}},{\"nodeType\":1,\"id\":2656,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2655}},{\"nodeType\":3,\"id\":2657,\"textContent\":\"Fourth\",\"previousSibling\":{\"id\":2656},\"parentNode\":{\"id\":2655}},{\"nodeType\":1,\"id\":2658,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2641}},{\"nodeType\":1,\"id\":2659,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2658}},{\"nodeType\":3,\"id\":2660,\"textContent\":\"Fifth\",\"previousSibling\":{\"id\":2659},\"parentNode\":{\"id\":2658}},{\"nodeType\":1,\"id\":2661,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2642}},{\"nodeType\":1,\"id\":2662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2661}},{\"nodeType\":3,\"id\":2663,\"textContent\":\"Graduate\",\"previousSibling\":{\"id\":2662},\"parentNode\":{\"id\":2661}},{\"nodeType\":1,\"id\":2664,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2643}},{\"nodeType\":1,\"id\":2665,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2666,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2665},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2667,\"textContent\":\"*\",\"parentNode\":{\"id\":2645}},{\"nodeType\":1,\"id\":2668,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2669,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2668},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2670,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2669},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2671,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2670},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2672,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2671},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2673,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2672},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2674,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2673},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2675,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2674},\"parentNode\":{\"id\":2613}},{\"nodeType\":3,\"id\":2676,\"textContent\":\"What is your major area of study?\",\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2677,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2676},\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2678,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2669}},{\"nodeType\":1,\"id\":2679,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2678}},{\"nodeType\":3,\"id\":2680,\"textContent\":\"Math or Computer Sciences\",\"previousSibling\":{\"id\":2679},\"parentNode\":{\"id\":2678}},{\"nodeType\":1,\"id\":2681,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2670}},{\"nodeType\":1,\"id\":2682,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2681}},{\"nodeType\":3,\"id\":2683,\"textContent\":\"Social Sciences (incl. CogSci)\",\"previousSibling\":{\"id\":2682},\"parentNode\":{\"id\":2681}},{\"nodeType\":1,\"id\":2684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2671}},{\"nodeType\":1,\"id\":2685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2684}},{\"nodeType\":3,\"id\":2686,\"textContent\":\"Biomedical & Health Sciences\",\"previousSibling\":{\"id\":2685},\"parentNode\":{\"id\":2684}},{\"nodeType\":1,\"id\":2687,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2672}},{\"nodeType\":1,\"id\":2688,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2687}},{\"nodeType\":3,\"id\":2689,\"textContent\":\"Natural Sciences\",\"previousSibling\":{\"id\":2688},\"parentNode\":{\"id\":2687}},{\"nodeType\":1,\"id\":2690,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2673}},{\"nodeType\":1,\"id\":2691,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2690}},{\"nodeType\":3,\"id\":2692,\"textContent\":\"Engineering\",\"previousSibling\":{\"id\":2691},\"parentNode\":{\"id\":2690}},{\"nodeType\":1,\"id\":2693,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2674}},{\"nodeType\":1,\"id\":2694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2693}},{\"nodeType\":3,\"id\":2695,\"textContent\":\"Humanities\",\"previousSibling\":{\"id\":2694},\"parentNode\":{\"id\":2693}},{\"nodeType\":1,\"id\":2696,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2675}},{\"nodeType\":1,\"id\":2697,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2698,\"textContent\":\"Fine Arts\",\"previousSibling\":{\"id\":2697},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2699,\"textContent\":\"*\",\"parentNode\":{\"id\":2677}},{\"nodeType\":1,\"id\":2700,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2701,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2700},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2702,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2701},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2703,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2702},\"parentNode\":{\"id\":2614}},{\"nodeType\":3,\"id\":2704,\"textContent\":\"What is your gender?\",\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2705,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2704},\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2706,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2701}},{\"nodeType\":1,\"id\":2707,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2706}},{\"nodeType\":3,\"id\":2708,\"textContent\":\"Male\",\"previousSibling\":{\"id\":2707},\"parentNode\":{\"id\":2706}},{\"nodeType\":1,\"id\":2709,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2702}},{\"nodeType\":1,\"id\":2710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2709}},{\"nodeType\":3,\"id\":2711,\"textContent\":\"Female\",\"previousSibling\":{\"id\":2710},\"parentNode\":{\"id\":2709}},{\"nodeType\":1,\"id\":2712,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2703}},{\"nodeType\":1,\"id\":2713,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2714,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2713},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2715,\"textContent\":\"*\",\"parentNode\":{\"id\":2705}}],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2609},{\"id\":2610},{\"id\":2611},{\"id\":2616},{\"id\":2621},{\"id\":2622},{\"id\":2635},{\"id\":2617},{\"id\":2623},{\"id\":2624},{\"id\":2625},{\"id\":2618},{\"id\":2626},{\"id\":2627},{\"id\":2628},{\"id\":2619},{\"id\":2629},{\"id\":2630},{\"id\":2631},{\"id\":2620},{\"id\":2632},{\"id\":2633},{\"id\":2634},{\"id\":2612},{\"id\":2636},{\"id\":2644},{\"id\":2645},{\"id\":2667},{\"id\":2637},{\"id\":2646},{\"id\":2647},{\"id\":2648},{\"id\":2638},{\"id\":2649},{\"id\":2650},{\"id\":2651},{\"id\":2639},{\"id\":2652},{\"id\":2653},{\"id\":2654},{\"id\":2640},{\"id\":2655},{\"id\":2656},{\"id\":2657},{\"id\":2641},{\"id\":2658},{\"id\":2659},{\"id\":2660},{\"id\":2642},{\"id\":2661},{\"id\":2662},{\"id\":2663},{\"id\":2643},{\"id\":2664},{\"id\":2665},{\"id\":2666},{\"id\":2613},{\"id\":2668},{\"id\":2676},{\"id\":2677},{\"id\":2699},{\"id\":2669},{\"id\":2678},{\"id\":2679},{\"id\":2680},{\"id\":2670},{\"id\":2681},{\"id\":2682},{\"id\":2683},{\"id\":2671},{\"id\":2684},{\"id\":2685},{\"id\":2686},{\"id\":2672},{\"id\":2687},{\"id\":2688},{\"id\":2689},{\"id\":2673},{\"id\":2690},{\"id\":2691},{\"id\":2692},{\"id\":2674},{\"id\":2693},{\"id\":2694},{\"id\":2695},{\"id\":2675},{\"id\":2696},{\"id\":2697},{\"id\":2698},{\"id\":2614},{\"id\":2700},{\"id\":2704},{\"id\":2705},{\"id\":2715},{\"id\":2701},{\"id\":2706},{\"id\":2707},{\"id\":2708},{\"id\":2702},{\"id\":2709},{\"id\":2710},{\"id\":2711},{\"id\":2703},{\"id\":2712},{\"id\":2713},{\"id\":2714},{\"id\":2615}],[],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2716,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2717,\"textContent\":\" \",\"previousSibling\":{\"id\":2716},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2718,\"textContent\":\" \",\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":2718},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2720,\"textContent\":\" \",\"previousSibling\":{\"id\":2719},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2721,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":2720},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2722,\"textContent\":\" \",\"previousSibling\":{\"id\":2721},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2723,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":2722},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2724,\"textContent\":\" \",\"previousSibling\":{\"id\":2723},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2725,\"textContent\":\" \",\"parentNode\":{\"id\":2719}},{\"nodeType\":1,\"id\":2726,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":2725},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2727,\"textContent\":\" \",\"previousSibling\":{\"id\":2726},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2728,\"textContent\":\" \",\"parentNode\":{\"id\":2726}},{\"nodeType\":1,\"id\":2729,\"tagName\":\"H3\",\"attributes\":{},\"previousSibling\":{\"id\":2728},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2730,\"textContent\":\" \",\"previousSibling\":{\"id\":2729},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2731,\"textContent\":\"DEBRIEFING\",\"parentNode\":{\"id\":2729}},{\"nodeType\":3,\"id\":2732,\"textContent\":\" \",\"parentNode\":{\"id\":2721}},{\"nodeType\":1,\"id\":2733,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":2732},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2734,\"textContent\":\" \",\"previousSibling\":{\"id\":2733},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2735,\"textContent\":\" \",\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2736,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic\"},\"previousSibling\":{\"id\":2735},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2737,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2736},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2738,\"textContent\":\" \",\"previousSibling\":{\"id\":2737},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2739,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2738},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2740,\"textContent\":\" \",\"previousSibling\":{\"id\":2739},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2741,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2740},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2742,\"textContent\":\" \",\"previousSibling\":{\"id\":2741},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2743,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:bold;\"},\"previousSibling\":{\"id\":2742},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2744,\"textContent\":\" \",\"previousSibling\":{\"id\":2743},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2745,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":2744},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2746,\"textContent\":\" \",\"previousSibling\":{\"id\":2745},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2747,\"textContent\":\"Thank you very much for your participation! This debriefing will tell you more about the study, what you did, and why. \",\"parentNode\":{\"id\":2736}},{\"nodeType\":3,\"id\":2748,\"textContent\":\" \",\"parentNode\":{\"id\":2737}},{\"nodeType\":1,\"id\":2749,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2748},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2750,\"textContent\":\" You have just used a series of pictures (charts, graphs and diagrams) accompanied by different types of instructions to answer a series of problem solving questions. While you were using the pictures, we measured where you clicked, scrolled and pointed with the computer mouse. We also measured the accuracy of your responses and the time it took to complete each question.\",\"previousSibling\":{\"id\":2749},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2751,\"textContent\":\"What did you just do?\",\"parentNode\":{\"id\":2749}},{\"nodeType\":3,\"id\":2752,\"textContent\":\" \",\"parentNode\":{\"id\":2739}},{\"nodeType\":1,\"id\":2753,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2752},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2754,\"textContent\":\" Researchers of learning and cognition have long been interested in how graphic displays of information can be used to communicate, solve problems, and generate insights. As powerful as graphics may be in their communicative efficiency, they're not always immediately intuitive to understand. In short, we know a great deal more about learning with representations than we do about the learning of representations. In this project we are building upon previous research on reading and graph comprehension to explore how readers make sense of unfamiliar representations. The instructions you saw for each type of graph are known as “scaffolding techniques”, and we will compare your performance with the scaffolding techniques you saw with the performance of other participants to determine which types of instructions are most effective in helping humans to make sense of unfamiliar graphs. \",\"previousSibling\":{\"id\":2753},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2755,\"textContent\":\"Why did we have you do it?\",\"parentNode\":{\"id\":2753}},{\"nodeType\":1,\"id\":2756,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2757,\"textContent\":\" We expect that you will have found some of the graphics more difficult to use than others. We also expect that with the assistance of the instructions, after solving several problems you will learn to use the difficult graphics so that you can answer the questions even more quickly than without. If you would like to receive a copy of the results of the study, or have any further questions, please contact the researchers Primary Researcher: Amy Fox : a2fox@ucsd.edu Faculty Advisor : Dr. Jim Hollan : hollan@ucsd.edu \",\"previousSibling\":{\"id\":2756},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2758,\"textContent\":\"What do we expect to find?\",\"parentNode\":{\"id\":2756}},{\"nodeType\":3,\"id\":2759,\"textContent\":\"It is important that you do not discuss this experiment with other students who might participate after you. They must participate in the same way as you did, without any knowledge of what the experiment entails, or the reasoning behind it.\",\"parentNode\":{\"id\":2743}},{\"nodeType\":3,\"id\":2760,\"textContent\":\"Thank you for your time! We hope you enjoyed participating in this study as much as we enjoyed designing it.\",\"parentNode\":{\"id\":2745}},{\"nodeType\":3,\"id\":2761,\"textContent\":\" \",\"parentNode\":{\"id\":2723}},{\"nodeType\":1,\"id\":2762,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":2761},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2763,\"textContent\":\" \",\"previousSibling\":{\"id\":2762},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2764,\"textContent\":\"FINISH\",\"parentNode\":{\"id\":2762}}],[],[]]}"
    },
    {
      "sequence": 8,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2716},{\"id\":2718},{\"id\":2719},{\"id\":2725},{\"id\":2726},{\"id\":2728},{\"id\":2729},{\"id\":2731},{\"id\":2730},{\"id\":2727},{\"id\":2720},{\"id\":2721},{\"id\":2732},{\"id\":2733},{\"id\":2735},{\"id\":2736},{\"id\":2747},{\"id\":2737},{\"id\":2748},{\"id\":2749},{\"id\":2751},{\"id\":2750},{\"id\":2738},{\"id\":2739},{\"id\":2752},{\"id\":2753},{\"id\":2755},{\"id\":2754},{\"id\":2740},{\"id\":2741},{\"id\":2756},{\"id\":2758},{\"id\":2757},{\"id\":2742},{\"id\":2743},{\"id\":2759},{\"id\":2744},{\"id\":2745},{\"id\":2760},{\"id\":2746},{\"id\":2734},{\"id\":2722},{\"id\":2723},{\"id\":2761},{\"id\":2762},{\"id\":2764},{\"id\":2763},{\"id\":2724},{\"id\":2717}],[],[],[]]}"
    },
    {
      "sequence": 9,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2765,\"tagName\":\"PRE\",\"attributes\":{\"id\":\"jspsych-data-display\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2766,\"textContent\":\"[ { \\\"rt\\\": 43077, \\\"stimulus\\\": \\\"img/phone.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"phone\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 0, \\\"time_elapsed\\\": 43079, \\\"internal_node_id\\\": \\\"0.0-0.0\\\", \\\"subject\\\": \\\"AZKMW\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"oscar\\\", \\\"condition\\\": \\\"114\\\" }, { \\\"rt\\\": 42512, \\\"url\\\": \\\"../views/src/external/consent.html\\\", \\\"block\\\": \\\"consent\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 1, \\\"time_elapsed\\\": 86697, \\\"internal_node_id\\\": \\\"0.0-1.0\\\", \\\"subject\\\": \\\"AZKMW\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"oscar\\\", \\\"condition\\\": \\\"114\\\" }, { \\\"rt\\\": 19335, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"OSCAR\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"114\\\\\\\"}\\\", \\\"block\\\": \\\"codes\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 2, \\\"time_elapsed\\\": 107041, \\\"internal_node_id\\\": \\\"0.0-2.0\\\", \\\"subject\\\": \\\"AZKMW\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"oscar\\\", \\\"condition\\\": \\\"114\\\" }, { \\\"rt\\\": 45781, \\\"url\\\": \\\"../views/src/external/instructions_lab.html\\\", \\\"block\\\": \\\"instructions_lab\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 3, \\\"time_elapsed\\\": 154166, \\\"internal_node_id\\\": \\\"0.0-3.0\\\", \\\"subject\\\": \\\"AZKMW\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"oscar\\\", \\\"condition\\\": \\\"114\\\" }, { \\\"rt\\\": 9403, \\\"stimulus\\\": \\\"img/acme.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"scenario\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 4, \\\"time_elapsed\\\": 164570, \\\"internal_node_id\\\": \\\"0.0-4.0\\\", \\\"subject\\\": \\\"AZKMW\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"oscar\\\", \\\"condition\\\": \\\"114\\\" }, { \\\"rt\\\": 15786, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 5, \\\"time_elapsed\\\": 181798, \\\"internal_node_id\\\": \\\"0.0-5.0-0.0\\\", \\\"subject\\\": \\\"AZKMW\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"oscar\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 1, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"A\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-11 AM-12 PM-A \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:584,y:416,t:1527613503062};\\\", \\\"{x:589,y:436,t:1527613503069};\\\", \\\"{x:591,y:472,t:1527613503081};\\\", \\\"{x:598,y:524,t:1527613503100};\\\", \\\"{x:600,y:589,t:1527613503115};\\\", \\\"{x:611,y:641,t:1527613503132};\\\", \\\"{x:629,y:691,t:1527613503148};\\\", \\\"{x:635,y:709,t:1527613503165};\\\", \\\"{x:638,y:714,t:1527613503182};\\\", \\\"{x:638,y:715,t:1527613503199};\\\", \\\"{x:639,y:715,t:1527613503437};\\\", \\\"{x:627,y:701,t:1527613503449};\\\", \\\"{x:522,y:630,t:1527613503467};\\\", \\\"{x:400,y:579,t:1527613503484};\\\", \\\"{x:332,y:552,t:1527613503499};\\\", \\\"{x:240,y:525,t:1527613503516};\\\", \\\"{x:211,y:515,t:1527613503532};\\\", \\\"{x:202,y:513,t:1527613503548};\\\", \\\"{x:198,y:510,t:1527613503565};\\\", \\\"{x:196,y:508,t:1527613503582};\\\", \\\"{x:194,y:505,t:1527613503599};\\\", \\\"{x:194,y:501,t:1527613503616};\\\", \\\"{x:194,y:499,t:1527613503631};\\\", \\\"{x:194,y:496,t:1527613503649};\\\", \\\"{x:194,y:492,t:1527613503666};\\\", \\\"{x:209,y:487,t:1527613503682};\\\", \\\"{x:223,y:487,t:1527613503699};\\\", \\\"{x:240,y:484,t:1527613503716};\\\", \\\"{x:246,y:482,t:1527613503732};\\\", \\\"{x:263,y:481,t:1527613503749};\\\", \\\"{x:289,y:485,t:1527613503767};\\\", \\\"{x:312,y:489,t:1527613503783};\\\", \\\"{x:327,y:491,t:1527613503800};\\\", \\\"{x:334,y:493,t:1527613503816};\\\", \\\"{x:336,y:493,t:1527613503833};\\\", \\\"{x:337,y:496,t:1527613503924};\\\", \\\"{x:340,y:502,t:1527613503932};\\\", \\\"{x:347,y:516,t:1527613503950};\\\", \\\"{x:350,y:522,t:1527613503966};\\\", \\\"{x:353,y:525,t:1527613503982};\\\", \\\"{x:355,y:525,t:1527613503998};\\\", \\\"{x:360,y:528,t:1527613504016};\\\", \\\"{x:362,y:529,t:1527613504033};\\\", \\\"{x:364,y:529,t:1527613504049};\\\", \\\"{x:366,y:530,t:1527613504067};\\\", \\\"{x:368,y:531,t:1527613504084};\\\", \\\"{x:369,y:531,t:1527613504099};\\\", \\\"{x:370,y:532,t:1527613504140};\\\", \\\"{x:373,y:532,t:1527613504204};\\\", \\\"{x:375,y:531,t:1527613504216};\\\", \\\"{x:376,y:531,t:1527613504243};\\\", \\\"{x:378,y:530,t:1527613504767};\\\", \\\"{x:386,y:533,t:1527613505204};\\\", \\\"{x:405,y:544,t:1527613505214};\\\", \\\"{x:464,y:574,t:1527613505231};\\\", \\\"{x:567,y:627,t:1527613505247};\\\", \\\"{x:715,y:712,t:1527613505265};\\\", \\\"{x:970,y:855,t:1527613505281};\\\", \\\"{x:1152,y:940,t:1527613505297};\\\", \\\"{x:1323,y:1015,t:1527613505314};\\\", \\\"{x:1494,y:1088,t:1527613505331};\\\", \\\"{x:1640,y:1157,t:1527613505348};\\\", \\\"{x:1766,y:1204,t:1527613505364};\\\", \\\"{x:1851,y:1215,t:1527613505381};\\\", \\\"{x:1891,y:1215,t:1527613505397};\\\", \\\"{x:1913,y:1215,t:1527613505414};\\\", \\\"{x:1919,y:1215,t:1527613505431};\\\", \\\"{x:1915,y:1209,t:1527613505498};\\\", \\\"{x:1892,y:1187,t:1527613505515};\\\", \\\"{x:1867,y:1168,t:1527613505532};\\\", \\\"{x:1825,y:1138,t:1527613505549};\\\", \\\"{x:1764,y:1108,t:1527613505565};\\\", \\\"{x:1710,y:1081,t:1527613505581};\\\", \\\"{x:1679,y:1065,t:1527613505599};\\\", \\\"{x:1656,y:1053,t:1527613505614};\\\", \\\"{x:1638,y:1042,t:1527613505632};\\\", \\\"{x:1627,y:1035,t:1527613505648};\\\", \\\"{x:1619,y:1029,t:1527613505665};\\\", \\\"{x:1618,y:1028,t:1527613505714};\\\", \\\"{x:1610,y:1025,t:1527613505732};\\\", \\\"{x:1586,y:1019,t:1527613505749};\\\", \\\"{x:1555,y:1010,t:1527613505766};\\\", \\\"{x:1508,y:997,t:1527613505782};\\\", \\\"{x:1459,y:988,t:1527613505799};\\\", \\\"{x:1364,y:968,t:1527613505816};\\\", \\\"{x:1261,y:952,t:1527613505831};\\\", \\\"{x:1155,y:934,t:1527613505848};\\\", \\\"{x:1054,y:904,t:1527613505865};\\\", \\\"{x:1031,y:894,t:1527613505881};\\\", \\\"{x:1016,y:890,t:1527613505898};\\\", \\\"{x:1008,y:888,t:1527613505915};\\\", \\\"{x:1010,y:891,t:1527613506002};\\\", \\\"{x:1014,y:893,t:1527613506016};\\\", \\\"{x:1018,y:894,t:1527613506033};\\\", \\\"{x:1025,y:898,t:1527613506048};\\\", \\\"{x:1048,y:905,t:1527613506066};\\\", \\\"{x:1072,y:913,t:1527613506081};\\\", \\\"{x:1102,y:921,t:1527613506099};\\\", \\\"{x:1129,y:932,t:1527613506117};\\\", \\\"{x:1158,y:937,t:1527613506133};\\\", \\\"{x:1176,y:947,t:1527613506149};\\\", \\\"{x:1214,y:958,t:1527613506166};\\\", \\\"{x:1276,y:971,t:1527613506182};\\\", \\\"{x:1334,y:986,t:1527613506200};\\\", \\\"{x:1379,y:999,t:1527613506215};\\\", \\\"{x:1394,y:1002,t:1527613506232};\\\", \\\"{x:1397,y:1002,t:1527613506250};\\\", \\\"{x:1396,y:1001,t:1527613506298};\\\", \\\"{x:1393,y:997,t:1527613506306};\\\", \\\"{x:1387,y:991,t:1527613506316};\\\", \\\"{x:1377,y:986,t:1527613506333};\\\", \\\"{x:1365,y:982,t:1527613506350};\\\", \\\"{x:1360,y:978,t:1527613506366};\\\", \\\"{x:1352,y:976,t:1527613506383};\\\", \\\"{x:1344,y:971,t:1527613506400};\\\", \\\"{x:1332,y:968,t:1527613506416};\\\", \\\"{x:1324,y:965,t:1527613506433};\\\", \\\"{x:1321,y:963,t:1527613506450};\\\", \\\"{x:1320,y:962,t:1527613506466};\\\", \\\"{x:1318,y:960,t:1527613506483};\\\", \\\"{x:1317,y:956,t:1527613506500};\\\", \\\"{x:1317,y:954,t:1527613506517};\\\", \\\"{x:1317,y:950,t:1527613506533};\\\", \\\"{x:1316,y:942,t:1527613506550};\\\", \\\"{x:1315,y:932,t:1527613506567};\\\", \\\"{x:1312,y:917,t:1527613506583};\\\", \\\"{x:1308,y:895,t:1527613506600};\\\", \\\"{x:1304,y:871,t:1527613506617};\\\", \\\"{x:1296,y:850,t:1527613506633};\\\", \\\"{x:1279,y:816,t:1527613506650};\\\", \\\"{x:1261,y:798,t:1527613506667};\\\", \\\"{x:1226,y:780,t:1527613506683};\\\", \\\"{x:1166,y:767,t:1527613506700};\\\", \\\"{x:1047,y:749,t:1527613506716};\\\", \\\"{x:889,y:727,t:1527613506733};\\\", \\\"{x:709,y:702,t:1527613506750};\\\", \\\"{x:519,y:679,t:1527613506767};\\\", \\\"{x:315,y:659,t:1527613506784};\\\", \\\"{x:133,y:634,t:1527613506802};\\\", \\\"{x:0,y:605,t:1527613506817};\\\", \\\"{x:0,y:592,t:1527613506832};\\\", \\\"{x:0,y:582,t:1527613506849};\\\", \\\"{x:0,y:581,t:1527613506865};\\\", \\\"{x:0,y:580,t:1527613506897};\\\", \\\"{x:11,y:579,t:1527613506961};\\\", \\\"{x:24,y:577,t:1527613506969};\\\", \\\"{x:39,y:576,t:1527613506982};\\\", \\\"{x:74,y:571,t:1527613507000};\\\", \\\"{x:133,y:571,t:1527613507016};\\\", \\\"{x:179,y:573,t:1527613507033};\\\", \\\"{x:229,y:587,t:1527613507050};\\\", \\\"{x:300,y:611,t:1527613507067};\\\", \\\"{x:348,y:631,t:1527613507083};\\\", \\\"{x:370,y:644,t:1527613507099};\\\", \\\"{x:392,y:654,t:1527613507116};\\\", \\\"{x:417,y:667,t:1527613507132};\\\", \\\"{x:444,y:674,t:1527613507149};\\\", \\\"{x:470,y:683,t:1527613507166};\\\", \\\"{x:481,y:686,t:1527613507182};\\\", \\\"{x:494,y:693,t:1527613507200};\\\", \\\"{x:499,y:696,t:1527613507216};\\\", \\\"{x:505,y:698,t:1527613507232};\\\", \\\"{x:506,y:699,t:1527613507249};\\\", \\\"{x:507,y:700,t:1527613507314};\\\", \\\"{x:511,y:705,t:1527613507322};\\\", \\\"{x:519,y:715,t:1527613507334};\\\", \\\"{x:531,y:728,t:1527613507349};\\\", \\\"{x:540,y:740,t:1527613507367};\\\", \\\"{x:545,y:745,t:1527613507382};\\\", \\\"{x:546,y:746,t:1527613507399};\\\", \\\"{x:546,y:744,t:1527613507626};\\\", \\\"{x:546,y:742,t:1527613507634};\\\", \\\"{x:545,y:739,t:1527613507650};\\\", \\\"{x:545,y:736,t:1527613507666};\\\", \\\"{x:544,y:732,t:1527613507684};\\\", \\\"{x:542,y:729,t:1527613507700};\\\", \\\"{x:541,y:728,t:1527613507722};\\\" ] }, { \\\"rt\\\": 24785, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 6, \\\"time_elapsed\\\": 207836, \\\"internal_node_id\\\": \\\"0.0-5.0-1.0\\\", \\\"subject\\\": \\\"AZKMW\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"oscar\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 2, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-C -D -D -04 PM\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:540,y:728,t:1527613509393};\\\", \\\"{x:537,y:717,t:1527613511627};\\\", \\\"{x:526,y:681,t:1527613511635};\\\", \\\"{x:513,y:656,t:1527613511645};\\\", \\\"{x:493,y:609,t:1527613511663};\\\", \\\"{x:472,y:534,t:1527613511687};\\\", \\\"{x:449,y:484,t:1527613511703};\\\", \\\"{x:429,y:439,t:1527613511720};\\\", \\\"{x:415,y:420,t:1527613511736};\\\", \\\"{x:408,y:406,t:1527613511752};\\\", \\\"{x:407,y:388,t:1527613511769};\\\", \\\"{x:407,y:382,t:1527613511786};\\\", \\\"{x:410,y:377,t:1527613511803};\\\", \\\"{x:411,y:376,t:1527613511820};\\\", \\\"{x:414,y:374,t:1527613511836};\\\", \\\"{x:417,y:368,t:1527613511853};\\\", \\\"{x:421,y:360,t:1527613511869};\\\", \\\"{x:426,y:352,t:1527613511887};\\\", \\\"{x:431,y:343,t:1527613511904};\\\", \\\"{x:441,y:329,t:1527613511919};\\\", \\\"{x:448,y:326,t:1527613511936};\\\", \\\"{x:449,y:325,t:1527613511953};\\\", \\\"{x:453,y:326,t:1527613511994};\\\", \\\"{x:453,y:331,t:1527613512003};\\\", \\\"{x:461,y:348,t:1527613512020};\\\", \\\"{x:471,y:367,t:1527613512036};\\\", \\\"{x:484,y:386,t:1527613512053};\\\", \\\"{x:492,y:402,t:1527613512069};\\\", \\\"{x:494,y:419,t:1527613512087};\\\", \\\"{x:499,y:432,t:1527613512104};\\\", \\\"{x:506,y:444,t:1527613512119};\\\", \\\"{x:514,y:461,t:1527613512137};\\\", \\\"{x:519,y:473,t:1527613512153};\\\", \\\"{x:522,y:479,t:1527613512169};\\\", \\\"{x:526,y:486,t:1527613512186};\\\", \\\"{x:530,y:493,t:1527613512204};\\\", \\\"{x:534,y:496,t:1527613512220};\\\", \\\"{x:535,y:497,t:1527613512236};\\\", \\\"{x:535,y:498,t:1527613512253};\\\", \\\"{x:536,y:498,t:1527613512270};\\\", \\\"{x:537,y:498,t:1527613512287};\\\", \\\"{x:538,y:499,t:1527613512304};\\\", \\\"{x:539,y:499,t:1527613512321};\\\", \\\"{x:540,y:499,t:1527613512474};\\\", \\\"{x:543,y:498,t:1527613512498};\\\", \\\"{x:544,y:497,t:1527613512514};\\\", \\\"{x:545,y:497,t:1527613512538};\\\", \\\"{x:545,y:496,t:1527613512561};\\\", \\\"{x:545,y:495,t:1527613512570};\\\", \\\"{x:547,y:494,t:1527613512593};\\\", \\\"{x:550,y:494,t:1527613512603};\\\", \\\"{x:555,y:492,t:1527613512620};\\\", \\\"{x:559,y:491,t:1527613512637};\\\", \\\"{x:562,y:490,t:1527613512653};\\\", \\\"{x:564,y:488,t:1527613512670};\\\", \\\"{x:567,y:487,t:1527613512687};\\\", \\\"{x:568,y:487,t:1527613512703};\\\", \\\"{x:569,y:486,t:1527613512720};\\\", \\\"{x:571,y:486,t:1527613512754};\\\", \\\"{x:572,y:486,t:1527613512770};\\\", \\\"{x:579,y:486,t:1527613512787};\\\", \\\"{x:587,y:486,t:1527613512804};\\\", \\\"{x:601,y:486,t:1527613512820};\\\", \\\"{x:609,y:486,t:1527613512837};\\\", \\\"{x:627,y:486,t:1527613512854};\\\", \\\"{x:648,y:486,t:1527613512871};\\\", \\\"{x:655,y:486,t:1527613512887};\\\", \\\"{x:659,y:486,t:1527613512904};\\\", \\\"{x:660,y:486,t:1527613512920};\\\", \\\"{x:662,y:486,t:1527613512954};\\\", \\\"{x:673,y:486,t:1527613513170};\\\", \\\"{x:720,y:494,t:1527613513188};\\\", \\\"{x:792,y:518,t:1527613513206};\\\", \\\"{x:858,y:543,t:1527613513220};\\\", \\\"{x:948,y:578,t:1527613513237};\\\", \\\"{x:1049,y:612,t:1527613513254};\\\", \\\"{x:1156,y:653,t:1527613513270};\\\", \\\"{x:1281,y:698,t:1527613513287};\\\", \\\"{x:1411,y:761,t:1527613513304};\\\", \\\"{x:1531,y:818,t:1527613513320};\\\", \\\"{x:1696,y:901,t:1527613513337};\\\", \\\"{x:1719,y:912,t:1527613513355};\\\", \\\"{x:1714,y:912,t:1527613514586};\\\", \\\"{x:1708,y:909,t:1527613514594};\\\", \\\"{x:1700,y:908,t:1527613514607};\\\", \\\"{x:1687,y:905,t:1527613514623};\\\", \\\"{x:1674,y:900,t:1527613514639};\\\", \\\"{x:1662,y:897,t:1527613514656};\\\", \\\"{x:1654,y:892,t:1527613514673};\\\", \\\"{x:1646,y:888,t:1527613514689};\\\", \\\"{x:1625,y:879,t:1527613514706};\\\", \\\"{x:1612,y:873,t:1527613514723};\\\", \\\"{x:1600,y:867,t:1527613514739};\\\", \\\"{x:1589,y:860,t:1527613514756};\\\", \\\"{x:1580,y:856,t:1527613514773};\\\", \\\"{x:1572,y:851,t:1527613514789};\\\", \\\"{x:1563,y:846,t:1527613514806};\\\", \\\"{x:1554,y:841,t:1527613514823};\\\", \\\"{x:1543,y:836,t:1527613514839};\\\", \\\"{x:1528,y:831,t:1527613514856};\\\", \\\"{x:1510,y:827,t:1527613514873};\\\", \\\"{x:1489,y:821,t:1527613514889};\\\", \\\"{x:1464,y:818,t:1527613514906};\\\", \\\"{x:1445,y:809,t:1527613514923};\\\", \\\"{x:1430,y:807,t:1527613514939};\\\", \\\"{x:1424,y:807,t:1527613514956};\\\", \\\"{x:1421,y:807,t:1527613514973};\\\", \\\"{x:1419,y:807,t:1527613514989};\\\", \\\"{x:1410,y:810,t:1527613515006};\\\", \\\"{x:1392,y:817,t:1527613515023};\\\", \\\"{x:1371,y:828,t:1527613515039};\\\", \\\"{x:1350,y:844,t:1527613515056};\\\", \\\"{x:1320,y:863,t:1527613515073};\\\", \\\"{x:1295,y:876,t:1527613515090};\\\", \\\"{x:1291,y:879,t:1527613515106};\\\", \\\"{x:1284,y:883,t:1527613515123};\\\", \\\"{x:1282,y:884,t:1527613515140};\\\", \\\"{x:1278,y:886,t:1527613515156};\\\", \\\"{x:1275,y:890,t:1527613515173};\\\", \\\"{x:1272,y:891,t:1527613515190};\\\", \\\"{x:1265,y:891,t:1527613515206};\\\", \\\"{x:1250,y:888,t:1527613515223};\\\", \\\"{x:1236,y:884,t:1527613515241};\\\", \\\"{x:1224,y:877,t:1527613515256};\\\", \\\"{x:1213,y:870,t:1527613515273};\\\", \\\"{x:1210,y:866,t:1527613515290};\\\", \\\"{x:1209,y:864,t:1527613515306};\\\", \\\"{x:1207,y:859,t:1527613515323};\\\", \\\"{x:1206,y:854,t:1527613515340};\\\", \\\"{x:1206,y:848,t:1527613515356};\\\", \\\"{x:1206,y:844,t:1527613515373};\\\", \\\"{x:1206,y:840,t:1527613515390};\\\", \\\"{x:1206,y:837,t:1527613515406};\\\", \\\"{x:1207,y:835,t:1527613515423};\\\", \\\"{x:1207,y:832,t:1527613515440};\\\", \\\"{x:1207,y:830,t:1527613515466};\\\", \\\"{x:1207,y:829,t:1527613515482};\\\", \\\"{x:1207,y:828,t:1527613515506};\\\", \\\"{x:1208,y:827,t:1527613515546};\\\", \\\"{x:1211,y:826,t:1527613515560};\\\", \\\"{x:1224,y:825,t:1527613515572};\\\", \\\"{x:1238,y:823,t:1527613515590};\\\", \\\"{x:1251,y:821,t:1527613515607};\\\", \\\"{x:1270,y:814,t:1527613515622};\\\", \\\"{x:1285,y:810,t:1527613515640};\\\", \\\"{x:1294,y:808,t:1527613515656};\\\", \\\"{x:1301,y:805,t:1527613515673};\\\", \\\"{x:1311,y:802,t:1527613515689};\\\", \\\"{x:1316,y:801,t:1527613515707};\\\", \\\"{x:1320,y:800,t:1527613515723};\\\", \\\"{x:1322,y:799,t:1527613515739};\\\", \\\"{x:1323,y:798,t:1527613515762};\\\", \\\"{x:1320,y:803,t:1527613515954};\\\", \\\"{x:1318,y:805,t:1527613515962};\\\", \\\"{x:1317,y:806,t:1527613515974};\\\", \\\"{x:1317,y:807,t:1527613515989};\\\", \\\"{x:1317,y:808,t:1527613516006};\\\", \\\"{x:1317,y:809,t:1527613516024};\\\", \\\"{x:1314,y:817,t:1527613516554};\\\", \\\"{x:1314,y:824,t:1527613516562};\\\", \\\"{x:1313,y:832,t:1527613516574};\\\", \\\"{x:1310,y:845,t:1527613516591};\\\", \\\"{x:1310,y:851,t:1527613516607};\\\", \\\"{x:1311,y:857,t:1527613516624};\\\", \\\"{x:1313,y:859,t:1527613516640};\\\", \\\"{x:1318,y:861,t:1527613516657};\\\", \\\"{x:1322,y:863,t:1527613516673};\\\", \\\"{x:1327,y:865,t:1527613516691};\\\", \\\"{x:1333,y:866,t:1527613516708};\\\", \\\"{x:1336,y:866,t:1527613516724};\\\", \\\"{x:1342,y:867,t:1527613516741};\\\", \\\"{x:1346,y:869,t:1527613516758};\\\", \\\"{x:1351,y:869,t:1527613516774};\\\", \\\"{x:1354,y:870,t:1527613516791};\\\", \\\"{x:1355,y:870,t:1527613516808};\\\", \\\"{x:1356,y:870,t:1527613516824};\\\", \\\"{x:1357,y:870,t:1527613516841};\\\", \\\"{x:1361,y:871,t:1527613516858};\\\", \\\"{x:1362,y:873,t:1527613516874};\\\", \\\"{x:1369,y:876,t:1527613516890};\\\", \\\"{x:1376,y:878,t:1527613516908};\\\", \\\"{x:1384,y:882,t:1527613516924};\\\", \\\"{x:1388,y:884,t:1527613516941};\\\", \\\"{x:1392,y:886,t:1527613516958};\\\", \\\"{x:1396,y:890,t:1527613516974};\\\", \\\"{x:1398,y:891,t:1527613516991};\\\", \\\"{x:1399,y:892,t:1527613517009};\\\", \\\"{x:1400,y:893,t:1527613517024};\\\", \\\"{x:1401,y:894,t:1527613517066};\\\", \\\"{x:1402,y:895,t:1527613517090};\\\", \\\"{x:1402,y:888,t:1527613517570};\\\", \\\"{x:1402,y:874,t:1527613517578};\\\", \\\"{x:1404,y:856,t:1527613517592};\\\", \\\"{x:1409,y:828,t:1527613517609};\\\", \\\"{x:1414,y:795,t:1527613517625};\\\", \\\"{x:1422,y:746,t:1527613517642};\\\", \\\"{x:1425,y:722,t:1527613517658};\\\", \\\"{x:1431,y:698,t:1527613517676};\\\", \\\"{x:1442,y:659,t:1527613517693};\\\", \\\"{x:1454,y:634,t:1527613517708};\\\", \\\"{x:1464,y:595,t:1527613517725};\\\", \\\"{x:1482,y:553,t:1527613517742};\\\", \\\"{x:1494,y:521,t:1527613517758};\\\", \\\"{x:1502,y:489,t:1527613517775};\\\", \\\"{x:1512,y:464,t:1527613517792};\\\", \\\"{x:1524,y:438,t:1527613517808};\\\", \\\"{x:1535,y:417,t:1527613517825};\\\", \\\"{x:1546,y:398,t:1527613517842};\\\", \\\"{x:1552,y:389,t:1527613517858};\\\", \\\"{x:1556,y:378,t:1527613517875};\\\", \\\"{x:1563,y:367,t:1527613517892};\\\", \\\"{x:1568,y:362,t:1527613517909};\\\", \\\"{x:1573,y:358,t:1527613517924};\\\", \\\"{x:1577,y:355,t:1527613517942};\\\", \\\"{x:1579,y:354,t:1527613517960};\\\", \\\"{x:1580,y:359,t:1527613518066};\\\", \\\"{x:1582,y:364,t:1527613518076};\\\", \\\"{x:1586,y:373,t:1527613518092};\\\", \\\"{x:1591,y:381,t:1527613518109};\\\", \\\"{x:1593,y:386,t:1527613518125};\\\", \\\"{x:1596,y:394,t:1527613518142};\\\", \\\"{x:1602,y:402,t:1527613518160};\\\", \\\"{x:1605,y:406,t:1527613518175};\\\", \\\"{x:1606,y:408,t:1527613518192};\\\", \\\"{x:1608,y:412,t:1527613518209};\\\", \\\"{x:1609,y:416,t:1527613518226};\\\", \\\"{x:1613,y:422,t:1527613518242};\\\", \\\"{x:1613,y:423,t:1527613518259};\\\", \\\"{x:1613,y:427,t:1527613521011};\\\", \\\"{x:1613,y:434,t:1527613521027};\\\", \\\"{x:1613,y:443,t:1527613521044};\\\", \\\"{x:1613,y:449,t:1527613521061};\\\", \\\"{x:1612,y:454,t:1527613521078};\\\", \\\"{x:1612,y:461,t:1527613521094};\\\", \\\"{x:1611,y:466,t:1527613521110};\\\", \\\"{x:1612,y:469,t:1527613521127};\\\", \\\"{x:1612,y:472,t:1527613521144};\\\", \\\"{x:1612,y:476,t:1527613521161};\\\", \\\"{x:1612,y:483,t:1527613521177};\\\", \\\"{x:1612,y:487,t:1527613521195};\\\", \\\"{x:1612,y:490,t:1527613521211};\\\", \\\"{x:1612,y:493,t:1527613521228};\\\", \\\"{x:1612,y:498,t:1527613521245};\\\", \\\"{x:1612,y:503,t:1527613521262};\\\", \\\"{x:1610,y:508,t:1527613521278};\\\", \\\"{x:1610,y:513,t:1527613521295};\\\", \\\"{x:1610,y:516,t:1527613521312};\\\", \\\"{x:1610,y:519,t:1527613521329};\\\", \\\"{x:1610,y:523,t:1527613521345};\\\", \\\"{x:1610,y:527,t:1527613521361};\\\", \\\"{x:1609,y:536,t:1527613521379};\\\", \\\"{x:1608,y:541,t:1527613521395};\\\", \\\"{x:1606,y:547,t:1527613521412};\\\", \\\"{x:1606,y:552,t:1527613521429};\\\", \\\"{x:1605,y:556,t:1527613521445};\\\", \\\"{x:1604,y:560,t:1527613521461};\\\", \\\"{x:1604,y:565,t:1527613521478};\\\", \\\"{x:1604,y:570,t:1527613521495};\\\", \\\"{x:1604,y:572,t:1527613521511};\\\", \\\"{x:1604,y:575,t:1527613521529};\\\", \\\"{x:1604,y:576,t:1527613521546};\\\", \\\"{x:1603,y:577,t:1527613521562};\\\", \\\"{x:1603,y:578,t:1527613521633};\\\", \\\"{x:1604,y:578,t:1527613522209};\\\", \\\"{x:1605,y:577,t:1527613522217};\\\", \\\"{x:1606,y:578,t:1527613522394};\\\", \\\"{x:1606,y:580,t:1527613522402};\\\", \\\"{x:1607,y:584,t:1527613522413};\\\", \\\"{x:1609,y:590,t:1527613522430};\\\", \\\"{x:1610,y:593,t:1527613522446};\\\", \\\"{x:1611,y:597,t:1527613522462};\\\", \\\"{x:1612,y:601,t:1527613522479};\\\", \\\"{x:1612,y:603,t:1527613522496};\\\", \\\"{x:1613,y:604,t:1527613522512};\\\", \\\"{x:1614,y:607,t:1527613522530};\\\", \\\"{x:1616,y:610,t:1527613522546};\\\", \\\"{x:1616,y:611,t:1527613522562};\\\", \\\"{x:1617,y:613,t:1527613522579};\\\", \\\"{x:1617,y:614,t:1527613522601};\\\", \\\"{x:1617,y:616,t:1527613522641};\\\", \\\"{x:1617,y:618,t:1527613522657};\\\", \\\"{x:1617,y:619,t:1527613522665};\\\", \\\"{x:1617,y:621,t:1527613522689};\\\", \\\"{x:1617,y:623,t:1527613522697};\\\", \\\"{x:1617,y:624,t:1527613522713};\\\", \\\"{x:1617,y:626,t:1527613522729};\\\", \\\"{x:1617,y:628,t:1527613522746};\\\", \\\"{x:1616,y:632,t:1527613522762};\\\", \\\"{x:1615,y:636,t:1527613522779};\\\", \\\"{x:1613,y:641,t:1527613522796};\\\", \\\"{x:1613,y:645,t:1527613522813};\\\", \\\"{x:1612,y:649,t:1527613522829};\\\", \\\"{x:1612,y:653,t:1527613522846};\\\", \\\"{x:1612,y:655,t:1527613522863};\\\", \\\"{x:1612,y:656,t:1527613522882};\\\", \\\"{x:1612,y:657,t:1527613522896};\\\", \\\"{x:1612,y:658,t:1527613522913};\\\", \\\"{x:1612,y:659,t:1527613522929};\\\", \\\"{x:1612,y:657,t:1527613523210};\\\", \\\"{x:1612,y:655,t:1527613523218};\\\", \\\"{x:1613,y:653,t:1527613523234};\\\", \\\"{x:1613,y:651,t:1527613523246};\\\", \\\"{x:1614,y:648,t:1527613523263};\\\", \\\"{x:1614,y:647,t:1527613523280};\\\", \\\"{x:1614,y:651,t:1527613523714};\\\", \\\"{x:1617,y:662,t:1527613523730};\\\", \\\"{x:1621,y:679,t:1527613523747};\\\", \\\"{x:1624,y:699,t:1527613523763};\\\", \\\"{x:1627,y:712,t:1527613523780};\\\", \\\"{x:1627,y:723,t:1527613523797};\\\", \\\"{x:1628,y:733,t:1527613523814};\\\", \\\"{x:1631,y:741,t:1527613523830};\\\", \\\"{x:1633,y:748,t:1527613523847};\\\", \\\"{x:1635,y:753,t:1527613523863};\\\", \\\"{x:1635,y:759,t:1527613523881};\\\", \\\"{x:1637,y:768,t:1527613523897};\\\", \\\"{x:1637,y:771,t:1527613523914};\\\", \\\"{x:1640,y:777,t:1527613523931};\\\", \\\"{x:1640,y:780,t:1527613523947};\\\", \\\"{x:1640,y:788,t:1527613523964};\\\", \\\"{x:1640,y:797,t:1527613523980};\\\", \\\"{x:1639,y:806,t:1527613523998};\\\", \\\"{x:1637,y:812,t:1527613524015};\\\", \\\"{x:1637,y:819,t:1527613524030};\\\", \\\"{x:1637,y:820,t:1527613524138};\\\", \\\"{x:1637,y:823,t:1527613524154};\\\", \\\"{x:1637,y:824,t:1527613524164};\\\", \\\"{x:1637,y:829,t:1527613524180};\\\", \\\"{x:1634,y:837,t:1527613524198};\\\", \\\"{x:1631,y:846,t:1527613524215};\\\", \\\"{x:1630,y:853,t:1527613524230};\\\", \\\"{x:1629,y:858,t:1527613524248};\\\", \\\"{x:1628,y:867,t:1527613524264};\\\", \\\"{x:1628,y:873,t:1527613524280};\\\", \\\"{x:1628,y:882,t:1527613524298};\\\", \\\"{x:1628,y:888,t:1527613524314};\\\", \\\"{x:1627,y:893,t:1527613524331};\\\", \\\"{x:1626,y:902,t:1527613524347};\\\", \\\"{x:1625,y:916,t:1527613524364};\\\", \\\"{x:1625,y:924,t:1527613524382};\\\", \\\"{x:1625,y:935,t:1527613524397};\\\", \\\"{x:1624,y:947,t:1527613524414};\\\", \\\"{x:1624,y:953,t:1527613524431};\\\", \\\"{x:1624,y:959,t:1527613524447};\\\", \\\"{x:1624,y:963,t:1527613524464};\\\", \\\"{x:1624,y:966,t:1527613524481};\\\", \\\"{x:1623,y:967,t:1527613524498};\\\", \\\"{x:1623,y:968,t:1527613524562};\\\", \\\"{x:1622,y:969,t:1527613524730};\\\", \\\"{x:1622,y:956,t:1527613524748};\\\", \\\"{x:1619,y:944,t:1527613524764};\\\", \\\"{x:1617,y:927,t:1527613524782};\\\", \\\"{x:1614,y:913,t:1527613524799};\\\", \\\"{x:1614,y:904,t:1527613524814};\\\", \\\"{x:1614,y:891,t:1527613524831};\\\", \\\"{x:1614,y:878,t:1527613524849};\\\", \\\"{x:1614,y:867,t:1527613524864};\\\", \\\"{x:1614,y:856,t:1527613524882};\\\", \\\"{x:1614,y:851,t:1527613524898};\\\", \\\"{x:1615,y:844,t:1527613524914};\\\", \\\"{x:1615,y:835,t:1527613524931};\\\", \\\"{x:1615,y:824,t:1527613524948};\\\", \\\"{x:1615,y:808,t:1527613524965};\\\", \\\"{x:1615,y:795,t:1527613524982};\\\", \\\"{x:1616,y:779,t:1527613524999};\\\", \\\"{x:1619,y:766,t:1527613525015};\\\", \\\"{x:1620,y:749,t:1527613525031};\\\", \\\"{x:1622,y:734,t:1527613525048};\\\", \\\"{x:1624,y:721,t:1527613525064};\\\", \\\"{x:1629,y:698,t:1527613525081};\\\", \\\"{x:1630,y:686,t:1527613525097};\\\", \\\"{x:1633,y:669,t:1527613525114};\\\", \\\"{x:1634,y:659,t:1527613525131};\\\", \\\"{x:1635,y:652,t:1527613525148};\\\", \\\"{x:1638,y:637,t:1527613525165};\\\", \\\"{x:1639,y:626,t:1527613525181};\\\", \\\"{x:1640,y:617,t:1527613525198};\\\", \\\"{x:1640,y:609,t:1527613525215};\\\", \\\"{x:1640,y:602,t:1527613525230};\\\", \\\"{x:1640,y:597,t:1527613525248};\\\", \\\"{x:1640,y:584,t:1527613525265};\\\", \\\"{x:1640,y:577,t:1527613525281};\\\", \\\"{x:1640,y:566,t:1527613525298};\\\", \\\"{x:1635,y:548,t:1527613525315};\\\", \\\"{x:1630,y:533,t:1527613525331};\\\", \\\"{x:1625,y:522,t:1527613525348};\\\", \\\"{x:1608,y:504,t:1527613525365};\\\", \\\"{x:1579,y:484,t:1527613525381};\\\", \\\"{x:1500,y:446,t:1527613525398};\\\", \\\"{x:1398,y:418,t:1527613525416};\\\", \\\"{x:1281,y:395,t:1527613525431};\\\", \\\"{x:1171,y:385,t:1527613525449};\\\", \\\"{x:958,y:402,t:1527613525466};\\\", \\\"{x:806,y:421,t:1527613525481};\\\", \\\"{x:664,y:445,t:1527613525498};\\\", \\\"{x:497,y:481,t:1527613525516};\\\", \\\"{x:382,y:522,t:1527613525532};\\\", \\\"{x:330,y:553,t:1527613525549};\\\", \\\"{x:316,y:563,t:1527613525564};\\\", \\\"{x:305,y:570,t:1527613525578};\\\", \\\"{x:297,y:578,t:1527613525596};\\\", \\\"{x:293,y:580,t:1527613525612};\\\", \\\"{x:288,y:583,t:1527613525631};\\\", \\\"{x:286,y:587,t:1527613525647};\\\", \\\"{x:285,y:595,t:1527613525664};\\\", \\\"{x:284,y:608,t:1527613525680};\\\", \\\"{x:284,y:614,t:1527613525698};\\\", \\\"{x:284,y:622,t:1527613525715};\\\", \\\"{x:287,y:634,t:1527613525730};\\\", \\\"{x:297,y:650,t:1527613525748};\\\", \\\"{x:311,y:657,t:1527613525764};\\\", \\\"{x:327,y:659,t:1527613525781};\\\", \\\"{x:339,y:654,t:1527613525798};\\\", \\\"{x:356,y:644,t:1527613525814};\\\", \\\"{x:371,y:630,t:1527613525831};\\\", \\\"{x:377,y:613,t:1527613525848};\\\", \\\"{x:381,y:593,t:1527613525866};\\\", \\\"{x:381,y:578,t:1527613525881};\\\", \\\"{x:380,y:567,t:1527613525898};\\\", \\\"{x:374,y:557,t:1527613525915};\\\", \\\"{x:370,y:551,t:1527613525930};\\\", \\\"{x:366,y:551,t:1527613526066};\\\", \\\"{x:364,y:551,t:1527613526081};\\\", \\\"{x:362,y:551,t:1527613526114};\\\", \\\"{x:354,y:554,t:1527613526121};\\\", \\\"{x:347,y:555,t:1527613526131};\\\", \\\"{x:317,y:558,t:1527613526148};\\\", \\\"{x:292,y:559,t:1527613526166};\\\", \\\"{x:265,y:561,t:1527613526183};\\\", \\\"{x:243,y:564,t:1527613526198};\\\", \\\"{x:229,y:565,t:1527613526215};\\\", \\\"{x:223,y:565,t:1527613526231};\\\", \\\"{x:221,y:565,t:1527613526247};\\\", \\\"{x:219,y:565,t:1527613526265};\\\", \\\"{x:218,y:565,t:1527613526281};\\\", \\\"{x:216,y:567,t:1527613526345};\\\", \\\"{x:213,y:573,t:1527613526353};\\\", \\\"{x:212,y:574,t:1527613526364};\\\", \\\"{x:211,y:580,t:1527613526383};\\\", \\\"{x:210,y:584,t:1527613526399};\\\", \\\"{x:210,y:589,t:1527613526415};\\\", \\\"{x:211,y:598,t:1527613526432};\\\", \\\"{x:211,y:601,t:1527613526448};\\\", \\\"{x:215,y:607,t:1527613526465};\\\", \\\"{x:215,y:613,t:1527613526482};\\\", \\\"{x:215,y:618,t:1527613526498};\\\", \\\"{x:215,y:626,t:1527613526515};\\\", \\\"{x:215,y:632,t:1527613526531};\\\", \\\"{x:215,y:633,t:1527613526569};\\\", \\\"{x:215,y:634,t:1527613526584};\\\", \\\"{x:226,y:641,t:1527613526906};\\\", \\\"{x:258,y:657,t:1527613526916};\\\", \\\"{x:277,y:668,t:1527613526932};\\\", \\\"{x:362,y:687,t:1527613526949};\\\", \\\"{x:462,y:717,t:1527613526965};\\\", \\\"{x:523,y:733,t:1527613526982};\\\", \\\"{x:545,y:740,t:1527613526999};\\\", \\\"{x:568,y:745,t:1527613527015};\\\", \\\"{x:575,y:745,t:1527613527032};\\\", \\\"{x:577,y:745,t:1527613527049};\\\", \\\"{x:579,y:743,t:1527613527105};\\\", \\\"{x:582,y:741,t:1527613527115};\\\", \\\"{x:588,y:738,t:1527613527132};\\\", \\\"{x:591,y:736,t:1527613527149};\\\", \\\"{x:594,y:733,t:1527613527165};\\\", \\\"{x:595,y:729,t:1527613527182};\\\", \\\"{x:602,y:721,t:1527613527199};\\\", \\\"{x:600,y:713,t:1527613527215};\\\", \\\"{x:572,y:704,t:1527613527233};\\\", \\\"{x:521,y:701,t:1527613527250};\\\", \\\"{x:473,y:699,t:1527613527266};\\\", \\\"{x:384,y:699,t:1527613527282};\\\", \\\"{x:256,y:691,t:1527613527299};\\\", \\\"{x:139,y:674,t:1527613527317};\\\", \\\"{x:47,y:659,t:1527613527332};\\\", \\\"{x:8,y:650,t:1527613527350};\\\", \\\"{x:0,y:646,t:1527613527366};\\\", \\\"{x:0,y:645,t:1527613527382};\\\", \\\"{x:0,y:646,t:1527613527465};\\\", \\\"{x:0,y:647,t:1527613527489};\\\", \\\"{x:1,y:647,t:1527613527499};\\\", \\\"{x:13,y:647,t:1527613527516};\\\", \\\"{x:25,y:648,t:1527613527533};\\\", \\\"{x:39,y:649,t:1527613527549};\\\", \\\"{x:53,y:649,t:1527613527567};\\\", \\\"{x:74,y:649,t:1527613527583};\\\", \\\"{x:89,y:649,t:1527613527599};\\\", \\\"{x:103,y:649,t:1527613527616};\\\", \\\"{x:118,y:641,t:1527613527633};\\\", \\\"{x:125,y:639,t:1527613527650};\\\", \\\"{x:130,y:637,t:1527613527666};\\\", \\\"{x:131,y:636,t:1527613527683};\\\", \\\"{x:132,y:636,t:1527613527699};\\\", \\\"{x:133,y:636,t:1527613527778};\\\", \\\"{x:134,y:636,t:1527613527786};\\\", \\\"{x:135,y:635,t:1527613527809};\\\", \\\"{x:136,y:635,t:1527613527833};\\\", \\\"{x:137,y:635,t:1527613527849};\\\", \\\"{x:139,y:635,t:1527613527865};\\\", \\\"{x:140,y:634,t:1527613527913};\\\", \\\"{x:140,y:634,t:1527613527947};\\\", \\\"{x:145,y:634,t:1527613528066};\\\", \\\"{x:166,y:638,t:1527613528084};\\\", \\\"{x:189,y:646,t:1527613528100};\\\", \\\"{x:210,y:661,t:1527613528116};\\\", \\\"{x:248,y:675,t:1527613528133};\\\", \\\"{x:308,y:688,t:1527613528150};\\\", \\\"{x:367,y:697,t:1527613528166};\\\", \\\"{x:395,y:699,t:1527613528183};\\\", \\\"{x:403,y:699,t:1527613528200};\\\", \\\"{x:404,y:697,t:1527613528216};\\\", \\\"{x:405,y:696,t:1527613528241};\\\", \\\"{x:405,y:695,t:1527613528249};\\\", \\\"{x:393,y:681,t:1527613528266};\\\", \\\"{x:351,y:670,t:1527613528283};\\\", \\\"{x:314,y:658,t:1527613528300};\\\", \\\"{x:250,y:649,t:1527613528316};\\\", \\\"{x:204,y:640,t:1527613528333};\\\", \\\"{x:175,y:636,t:1527613528351};\\\", \\\"{x:151,y:633,t:1527613528366};\\\", \\\"{x:143,y:632,t:1527613528383};\\\", \\\"{x:138,y:632,t:1527613528400};\\\", \\\"{x:137,y:632,t:1527613528416};\\\", \\\"{x:140,y:632,t:1527613528705};\\\", \\\"{x:142,y:632,t:1527613528717};\\\", \\\"{x:144,y:632,t:1527613528733};\\\", \\\"{x:146,y:632,t:1527613528750};\\\", \\\"{x:147,y:633,t:1527613528769};\\\", \\\"{x:148,y:633,t:1527613528785};\\\", \\\"{x:149,y:633,t:1527613528810};\\\", \\\"{x:151,y:633,t:1527613529250};\\\", \\\"{x:195,y:645,t:1527613529268};\\\", \\\"{x:257,y:664,t:1527613529285};\\\", \\\"{x:333,y:692,t:1527613529300};\\\", \\\"{x:428,y:719,t:1527613529317};\\\", \\\"{x:517,y:736,t:1527613529333};\\\", \\\"{x:602,y:755,t:1527613529350};\\\", \\\"{x:667,y:765,t:1527613529367};\\\", \\\"{x:710,y:775,t:1527613529384};\\\", \\\"{x:725,y:779,t:1527613529401};\\\", \\\"{x:732,y:780,t:1527613529417};\\\", \\\"{x:733,y:779,t:1527613529522};\\\", \\\"{x:733,y:777,t:1527613529537};\\\", \\\"{x:732,y:776,t:1527613529551};\\\", \\\"{x:727,y:772,t:1527613529568};\\\", \\\"{x:712,y:764,t:1527613529584};\\\", \\\"{x:674,y:753,t:1527613529601};\\\", \\\"{x:648,y:743,t:1527613529617};\\\", \\\"{x:632,y:736,t:1527613529634};\\\", \\\"{x:623,y:732,t:1527613529651};\\\", \\\"{x:615,y:731,t:1527613529667};\\\", \\\"{x:609,y:729,t:1527613529684};\\\", \\\"{x:607,y:729,t:1527613529701};\\\", \\\"{x:607,y:728,t:1527613529717};\\\", \\\"{x:606,y:728,t:1527613529778};\\\", \\\"{x:605,y:728,t:1527613529786};\\\", \\\"{x:600,y:728,t:1527613529802};\\\", \\\"{x:596,y:728,t:1527613529818};\\\", \\\"{x:595,y:728,t:1527613529834};\\\", \\\"{x:594,y:728,t:1527613529852};\\\", \\\"{x:593,y:728,t:1527613529922};\\\", \\\"{x:592,y:728,t:1527613529934};\\\", \\\"{x:591,y:728,t:1527613529951};\\\", \\\"{x:590,y:727,t:1527613529967};\\\", \\\"{x:589,y:726,t:1527613529984};\\\", \\\"{x:588,y:724,t:1527613530002};\\\", \\\"{x:587,y:723,t:1527613530017};\\\", \\\"{x:586,y:722,t:1527613530034};\\\", \\\"{x:584,y:722,t:1527613530137};\\\", \\\"{x:583,y:721,t:1527613532050};\\\", \\\"{x:583,y:720,t:1527613532130};\\\", \\\"{x:583,y:719,t:1527613532337};\\\", \\\"{x:583,y:717,t:1527613532425};\\\", \\\"{x:583,y:716,t:1527613532489};\\\", \\\"{x:582,y:716,t:1527613533018};\\\", \\\"{x:581,y:716,t:1527613533025};\\\", \\\"{x:580,y:716,t:1527613533057};\\\", \\\"{x:579,y:716,t:1527613533069};\\\", \\\"{x:577,y:718,t:1527613533505};\\\", \\\"{x:575,y:719,t:1527613533520};\\\", \\\"{x:573,y:721,t:1527613533537};\\\", \\\"{x:564,y:723,t:1527613533555};\\\", \\\"{x:556,y:725,t:1527613533570};\\\", \\\"{x:548,y:725,t:1527613533585};\\\", \\\"{x:533,y:728,t:1527613533604};\\\", \\\"{x:516,y:729,t:1527613533621};\\\", \\\"{x:510,y:729,t:1527613533637};\\\", \\\"{x:509,y:729,t:1527613533654};\\\" ] }, { \\\"rt\\\": 26568, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 7, \\\"time_elapsed\\\": 235643, \\\"internal_node_id\\\": \\\"0.0-5.0-2.0\\\", \\\"subject\\\": \\\"AZKMW\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"oscar\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 3, \\\"clicks\\\": 5.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"A\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-O -A -A \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:506,y:725,t:1527613539297};\\\", \\\"{x:504,y:710,t:1527613539309};\\\", \\\"{x:477,y:671,t:1527613539326};\\\", \\\"{x:451,y:639,t:1527613539343};\\\", \\\"{x:399,y:595,t:1527613539360};\\\", \\\"{x:335,y:549,t:1527613539376};\\\", \\\"{x:264,y:488,t:1527613539392};\\\", \\\"{x:229,y:461,t:1527613539408};\\\", \\\"{x:210,y:445,t:1527613539426};\\\", \\\"{x:203,y:435,t:1527613539442};\\\", \\\"{x:202,y:434,t:1527613539458};\\\", \\\"{x:202,y:431,t:1527613539475};\\\", \\\"{x:202,y:428,t:1527613539492};\\\", \\\"{x:208,y:421,t:1527613539508};\\\", \\\"{x:215,y:418,t:1527613539525};\\\", \\\"{x:221,y:416,t:1527613539543};\\\", \\\"{x:231,y:415,t:1527613539559};\\\", \\\"{x:238,y:415,t:1527613539576};\\\", \\\"{x:247,y:415,t:1527613539593};\\\", \\\"{x:261,y:415,t:1527613539609};\\\", \\\"{x:281,y:418,t:1527613539626};\\\", \\\"{x:304,y:425,t:1527613539642};\\\", \\\"{x:329,y:437,t:1527613539660};\\\", \\\"{x:348,y:450,t:1527613539675};\\\", \\\"{x:357,y:457,t:1527613539693};\\\", \\\"{x:362,y:462,t:1527613539710};\\\", \\\"{x:364,y:467,t:1527613539725};\\\", \\\"{x:364,y:474,t:1527613539743};\\\", \\\"{x:364,y:485,t:1527613539760};\\\", \\\"{x:364,y:494,t:1527613539776};\\\", \\\"{x:364,y:499,t:1527613539793};\\\", \\\"{x:364,y:501,t:1527613539809};\\\", \\\"{x:364,y:504,t:1527613539833};\\\", \\\"{x:364,y:506,t:1527613539844};\\\", \\\"{x:364,y:511,t:1527613539859};\\\", \\\"{x:364,y:515,t:1527613539876};\\\", \\\"{x:364,y:519,t:1527613539892};\\\", \\\"{x:364,y:521,t:1527613539909};\\\", \\\"{x:364,y:525,t:1527613539926};\\\", \\\"{x:364,y:526,t:1527613539945};\\\", \\\"{x:365,y:526,t:1527613539968};\\\", \\\"{x:366,y:526,t:1527613539976};\\\", \\\"{x:371,y:525,t:1527613539993};\\\", \\\"{x:373,y:525,t:1527613540009};\\\", \\\"{x:375,y:524,t:1527613540027};\\\", \\\"{x:376,y:524,t:1527613540043};\\\", \\\"{x:377,y:522,t:1527613540097};\\\", \\\"{x:378,y:522,t:1527613540110};\\\", \\\"{x:378,y:519,t:1527613540126};\\\", \\\"{x:379,y:518,t:1527613540142};\\\", \\\"{x:380,y:518,t:1527613541601};\\\", \\\"{x:389,y:520,t:1527613541611};\\\", \\\"{x:425,y:534,t:1527613541628};\\\", \\\"{x:492,y:554,t:1527613541643};\\\", \\\"{x:557,y:580,t:1527613541660};\\\", \\\"{x:617,y:603,t:1527613541678};\\\", \\\"{x:699,y:631,t:1527613541695};\\\", \\\"{x:762,y:655,t:1527613541710};\\\", \\\"{x:813,y:668,t:1527613541727};\\\", \\\"{x:867,y:680,t:1527613541744};\\\", \\\"{x:882,y:684,t:1527613541760};\\\", \\\"{x:888,y:685,t:1527613541777};\\\", \\\"{x:890,y:685,t:1527613541794};\\\", \\\"{x:888,y:685,t:1527613542025};\\\", \\\"{x:879,y:682,t:1527613542033};\\\", \\\"{x:870,y:675,t:1527613542046};\\\", \\\"{x:848,y:664,t:1527613542062};\\\", \\\"{x:825,y:655,t:1527613542079};\\\", \\\"{x:813,y:647,t:1527613542096};\\\", \\\"{x:793,y:639,t:1527613542112};\\\", \\\"{x:775,y:633,t:1527613542129};\\\", \\\"{x:765,y:631,t:1527613542145};\\\", \\\"{x:758,y:628,t:1527613542162};\\\", \\\"{x:756,y:628,t:1527613542178};\\\", \\\"{x:754,y:628,t:1527613542196};\\\", \\\"{x:752,y:627,t:1527613542212};\\\", \\\"{x:749,y:627,t:1527613542229};\\\", \\\"{x:742,y:627,t:1527613542246};\\\", \\\"{x:731,y:624,t:1527613542263};\\\", \\\"{x:717,y:622,t:1527613542281};\\\", \\\"{x:709,y:619,t:1527613542296};\\\", \\\"{x:704,y:619,t:1527613542310};\\\", \\\"{x:702,y:619,t:1527613542353};\\\", \\\"{x:699,y:620,t:1527613542369};\\\", \\\"{x:698,y:620,t:1527613542393};\\\", \\\"{x:698,y:621,t:1527613542400};\\\", \\\"{x:697,y:621,t:1527613542411};\\\", \\\"{x:692,y:623,t:1527613542429};\\\", \\\"{x:687,y:625,t:1527613542444};\\\", \\\"{x:681,y:626,t:1527613542461};\\\", \\\"{x:676,y:627,t:1527613542479};\\\", \\\"{x:671,y:628,t:1527613542496};\\\", \\\"{x:670,y:628,t:1527613542512};\\\", \\\"{x:676,y:628,t:1527613542618};\\\", \\\"{x:688,y:628,t:1527613542629};\\\", \\\"{x:715,y:626,t:1527613542645};\\\", \\\"{x:754,y:619,t:1527613542664};\\\", \\\"{x:797,y:611,t:1527613542680};\\\", \\\"{x:825,y:605,t:1527613542695};\\\", \\\"{x:844,y:598,t:1527613542711};\\\", \\\"{x:853,y:594,t:1527613542728};\\\", \\\"{x:855,y:593,t:1527613542744};\\\", \\\"{x:856,y:592,t:1527613542761};\\\", \\\"{x:858,y:589,t:1527613542778};\\\", \\\"{x:859,y:588,t:1527613542794};\\\", \\\"{x:860,y:584,t:1527613542811};\\\", \\\"{x:863,y:579,t:1527613542829};\\\", \\\"{x:863,y:575,t:1527613542845};\\\", \\\"{x:864,y:570,t:1527613542863};\\\", \\\"{x:866,y:564,t:1527613542879};\\\", \\\"{x:866,y:558,t:1527613542894};\\\", \\\"{x:866,y:550,t:1527613542911};\\\", \\\"{x:864,y:536,t:1527613542929};\\\", \\\"{x:857,y:524,t:1527613542946};\\\", \\\"{x:849,y:513,t:1527613542961};\\\", \\\"{x:843,y:507,t:1527613542979};\\\", \\\"{x:841,y:499,t:1527613542996};\\\", \\\"{x:839,y:496,t:1527613543012};\\\", \\\"{x:838,y:493,t:1527613543028};\\\", \\\"{x:835,y:491,t:1527613543046};\\\", \\\"{x:834,y:491,t:1527613543061};\\\", \\\"{x:832,y:494,t:1527613543210};\\\", \\\"{x:831,y:497,t:1527613543217};\\\", \\\"{x:831,y:501,t:1527613543229};\\\", \\\"{x:831,y:508,t:1527613543247};\\\", \\\"{x:831,y:513,t:1527613543263};\\\", \\\"{x:831,y:520,t:1527613543278};\\\", \\\"{x:831,y:525,t:1527613543295};\\\", \\\"{x:831,y:527,t:1527613543312};\\\", \\\"{x:831,y:529,t:1527613543946};\\\", \\\"{x:830,y:532,t:1527613543963};\\\", \\\"{x:830,y:534,t:1527613543980};\\\", \\\"{x:830,y:537,t:1527613543995};\\\", \\\"{x:830,y:538,t:1527613544032};\\\", \\\"{x:830,y:540,t:1527613544057};\\\", \\\"{x:829,y:540,t:1527613544065};\\\", \\\"{x:828,y:541,t:1527613544082};\\\", \\\"{x:828,y:543,t:1527613544449};\\\", \\\"{x:827,y:549,t:1527613544464};\\\", \\\"{x:826,y:553,t:1527613544480};\\\", \\\"{x:826,y:555,t:1527613544496};\\\", \\\"{x:825,y:557,t:1527613544513};\\\", \\\"{x:825,y:558,t:1527613544530};\\\", \\\"{x:825,y:559,t:1527613544547};\\\", \\\"{x:824,y:563,t:1527613544563};\\\", \\\"{x:822,y:565,t:1527613544585};\\\", \\\"{x:822,y:566,t:1527613544597};\\\", \\\"{x:822,y:569,t:1527613544613};\\\", \\\"{x:822,y:572,t:1527613544629};\\\", \\\"{x:821,y:573,t:1527613544745};\\\", \\\"{x:816,y:574,t:1527613544761};\\\", \\\"{x:798,y:574,t:1527613544769};\\\", \\\"{x:752,y:569,t:1527613544780};\\\", \\\"{x:635,y:548,t:1527613544799};\\\", \\\"{x:496,y:527,t:1527613544813};\\\", \\\"{x:374,y:506,t:1527613544830};\\\", \\\"{x:287,y:491,t:1527613544847};\\\", \\\"{x:222,y:479,t:1527613544863};\\\", \\\"{x:204,y:477,t:1527613544879};\\\", \\\"{x:203,y:477,t:1527613544992};\\\", \\\"{x:203,y:478,t:1527613545000};\\\", \\\"{x:209,y:479,t:1527613545013};\\\", \\\"{x:226,y:482,t:1527613545030};\\\", \\\"{x:247,y:483,t:1527613545046};\\\", \\\"{x:270,y:486,t:1527613545063};\\\", \\\"{x:311,y:486,t:1527613545082};\\\", \\\"{x:338,y:486,t:1527613545097};\\\", \\\"{x:361,y:486,t:1527613545114};\\\", \\\"{x:388,y:486,t:1527613545130};\\\", \\\"{x:415,y:486,t:1527613545147};\\\", \\\"{x:433,y:486,t:1527613545163};\\\", \\\"{x:443,y:486,t:1527613545180};\\\", \\\"{x:449,y:486,t:1527613545197};\\\", \\\"{x:452,y:486,t:1527613545214};\\\", \\\"{x:457,y:486,t:1527613545230};\\\", \\\"{x:464,y:486,t:1527613545246};\\\", \\\"{x:472,y:486,t:1527613545263};\\\", \\\"{x:486,y:486,t:1527613545280};\\\", \\\"{x:499,y:486,t:1527613545297};\\\", \\\"{x:510,y:486,t:1527613545314};\\\", \\\"{x:518,y:488,t:1527613545331};\\\", \\\"{x:534,y:490,t:1527613545348};\\\", \\\"{x:545,y:494,t:1527613545364};\\\", \\\"{x:553,y:494,t:1527613545381};\\\", \\\"{x:564,y:495,t:1527613545398};\\\", \\\"{x:573,y:495,t:1527613545414};\\\", \\\"{x:582,y:495,t:1527613545431};\\\", \\\"{x:591,y:497,t:1527613545448};\\\", \\\"{x:601,y:497,t:1527613545464};\\\", \\\"{x:612,y:497,t:1527613545482};\\\", \\\"{x:614,y:497,t:1527613545497};\\\", \\\"{x:615,y:497,t:1527613545514};\\\", \\\"{x:616,y:497,t:1527613545626};\\\", \\\"{x:616,y:498,t:1527613545705};\\\", \\\"{x:617,y:500,t:1527613545714};\\\", \\\"{x:621,y:504,t:1527613545731};\\\", \\\"{x:621,y:510,t:1527613545750};\\\", \\\"{x:625,y:517,t:1527613545764};\\\", \\\"{x:628,y:521,t:1527613545781};\\\", \\\"{x:630,y:522,t:1527613545801};\\\", \\\"{x:631,y:524,t:1527613545814};\\\", \\\"{x:632,y:524,t:1527613546129};\\\", \\\"{x:632,y:521,t:1527613546145};\\\", \\\"{x:634,y:521,t:1527613546153};\\\", \\\"{x:634,y:520,t:1527613546164};\\\", \\\"{x:635,y:519,t:1527613546181};\\\", \\\"{x:635,y:518,t:1527613546198};\\\", \\\"{x:635,y:517,t:1527613546225};\\\", \\\"{x:635,y:518,t:1527613546705};\\\", \\\"{x:636,y:518,t:1527613546715};\\\", \\\"{x:636,y:520,t:1527613546731};\\\", \\\"{x:637,y:521,t:1527613546753};\\\", \\\"{x:636,y:521,t:1527613547001};\\\", \\\"{x:630,y:521,t:1527613547015};\\\", \\\"{x:627,y:521,t:1527613547032};\\\", \\\"{x:626,y:521,t:1527613547049};\\\", \\\"{x:623,y:525,t:1527613547683};\\\", \\\"{x:622,y:527,t:1527613547699};\\\", \\\"{x:625,y:528,t:1527613547762};\\\", \\\"{x:632,y:526,t:1527613547769};\\\", \\\"{x:645,y:523,t:1527613547784};\\\", \\\"{x:732,y:518,t:1527613547799};\\\", \\\"{x:841,y:498,t:1527613547816};\\\", \\\"{x:1062,y:461,t:1527613547832};\\\", \\\"{x:1236,y:439,t:1527613547849};\\\", \\\"{x:1405,y:439,t:1527613547866};\\\", \\\"{x:1570,y:439,t:1527613547882};\\\", \\\"{x:1705,y:448,t:1527613547900};\\\", \\\"{x:1797,y:464,t:1527613547916};\\\", \\\"{x:1835,y:476,t:1527613547932};\\\", \\\"{x:1855,y:492,t:1527613547949};\\\", \\\"{x:1858,y:502,t:1527613547965};\\\", \\\"{x:1860,y:510,t:1527613547982};\\\", \\\"{x:1860,y:515,t:1527613548000};\\\", \\\"{x:1860,y:518,t:1527613548016};\\\", \\\"{x:1859,y:519,t:1527613548041};\\\", \\\"{x:1858,y:520,t:1527613548057};\\\", \\\"{x:1857,y:520,t:1527613548090};\\\", \\\"{x:1849,y:520,t:1527613548101};\\\", \\\"{x:1835,y:517,t:1527613548116};\\\", \\\"{x:1815,y:515,t:1527613548134};\\\", \\\"{x:1802,y:516,t:1527613548150};\\\", \\\"{x:1778,y:525,t:1527613548167};\\\", \\\"{x:1715,y:549,t:1527613548183};\\\", \\\"{x:1641,y:577,t:1527613548200};\\\", \\\"{x:1551,y:617,t:1527613548217};\\\", \\\"{x:1499,y:636,t:1527613548233};\\\", \\\"{x:1457,y:651,t:1527613548250};\\\", \\\"{x:1434,y:660,t:1527613548268};\\\", \\\"{x:1420,y:667,t:1527613548283};\\\", \\\"{x:1408,y:675,t:1527613548300};\\\", \\\"{x:1401,y:682,t:1527613548317};\\\", \\\"{x:1396,y:689,t:1527613548333};\\\", \\\"{x:1393,y:694,t:1527613548350};\\\", \\\"{x:1393,y:695,t:1527613548367};\\\", \\\"{x:1393,y:698,t:1527613548383};\\\", \\\"{x:1390,y:701,t:1527613548401};\\\", \\\"{x:1386,y:704,t:1527613548418};\\\", \\\"{x:1378,y:713,t:1527613548433};\\\", \\\"{x:1368,y:723,t:1527613548450};\\\", \\\"{x:1355,y:733,t:1527613548467};\\\", \\\"{x:1341,y:741,t:1527613548484};\\\", \\\"{x:1334,y:747,t:1527613548500};\\\", \\\"{x:1329,y:748,t:1527613548517};\\\", \\\"{x:1324,y:751,t:1527613548534};\\\", \\\"{x:1314,y:755,t:1527613548550};\\\", \\\"{x:1309,y:757,t:1527613548568};\\\", \\\"{x:1305,y:757,t:1527613548584};\\\", \\\"{x:1304,y:756,t:1527613548626};\\\", \\\"{x:1304,y:748,t:1527613548634};\\\", \\\"{x:1303,y:729,t:1527613548650};\\\", \\\"{x:1303,y:701,t:1527613548667};\\\", \\\"{x:1303,y:673,t:1527613548684};\\\", \\\"{x:1305,y:655,t:1527613548700};\\\", \\\"{x:1311,y:630,t:1527613548720};\\\", \\\"{x:1319,y:611,t:1527613548736};\\\", \\\"{x:1326,y:591,t:1527613548750};\\\", \\\"{x:1334,y:574,t:1527613548767};\\\", \\\"{x:1339,y:562,t:1527613548785};\\\", \\\"{x:1341,y:552,t:1527613548801};\\\", \\\"{x:1342,y:552,t:1527613548818};\\\", \\\"{x:1342,y:551,t:1527613548834};\\\", \\\"{x:1341,y:553,t:1527613549066};\\\", \\\"{x:1340,y:560,t:1527613549073};\\\", \\\"{x:1339,y:566,t:1527613549084};\\\", \\\"{x:1337,y:580,t:1527613549102};\\\", \\\"{x:1337,y:591,t:1527613549118};\\\", \\\"{x:1337,y:605,t:1527613549135};\\\", \\\"{x:1337,y:615,t:1527613549151};\\\", \\\"{x:1337,y:623,t:1527613549168};\\\", \\\"{x:1335,y:634,t:1527613549184};\\\", \\\"{x:1335,y:641,t:1527613549201};\\\", \\\"{x:1335,y:644,t:1527613549219};\\\", \\\"{x:1335,y:645,t:1527613549235};\\\", \\\"{x:1335,y:646,t:1527613549251};\\\", \\\"{x:1335,y:647,t:1527613549322};\\\", \\\"{x:1335,y:644,t:1527613549553};\\\", \\\"{x:1333,y:642,t:1527613549569};\\\", \\\"{x:1329,y:634,t:1527613549586};\\\", \\\"{x:1328,y:632,t:1527613549601};\\\", \\\"{x:1327,y:631,t:1527613549618};\\\", \\\"{x:1325,y:631,t:1527613549689};\\\", \\\"{x:1323,y:638,t:1527613549701};\\\", \\\"{x:1314,y:648,t:1527613549719};\\\", \\\"{x:1305,y:660,t:1527613549735};\\\", \\\"{x:1300,y:674,t:1527613549752};\\\", \\\"{x:1298,y:689,t:1527613549768};\\\", \\\"{x:1298,y:700,t:1527613549786};\\\", \\\"{x:1301,y:712,t:1527613549801};\\\", \\\"{x:1305,y:722,t:1527613549819};\\\", \\\"{x:1310,y:732,t:1527613549835};\\\", \\\"{x:1316,y:744,t:1527613549853};\\\", \\\"{x:1320,y:754,t:1527613549868};\\\", \\\"{x:1321,y:758,t:1527613549885};\\\", \\\"{x:1322,y:762,t:1527613549902};\\\", \\\"{x:1324,y:767,t:1527613549918};\\\", \\\"{x:1324,y:770,t:1527613549935};\\\", \\\"{x:1328,y:773,t:1527613549953};\\\", \\\"{x:1327,y:775,t:1527613549977};\\\", \\\"{x:1327,y:776,t:1527613549985};\\\", \\\"{x:1326,y:777,t:1527613550003};\\\", \\\"{x:1324,y:780,t:1527613550019};\\\", \\\"{x:1323,y:782,t:1527613550036};\\\", \\\"{x:1319,y:788,t:1527613550052};\\\", \\\"{x:1318,y:789,t:1527613550069};\\\", \\\"{x:1317,y:790,t:1527613550176};\\\", \\\"{x:1316,y:791,t:1527613550185};\\\", \\\"{x:1316,y:792,t:1527613550202};\\\", \\\"{x:1316,y:793,t:1527613550289};\\\", \\\"{x:1315,y:793,t:1527613550418};\\\", \\\"{x:1314,y:794,t:1527613550433};\\\", \\\"{x:1314,y:795,t:1527613550538};\\\", \\\"{x:1312,y:799,t:1527613550553};\\\", \\\"{x:1310,y:803,t:1527613550570};\\\", \\\"{x:1310,y:804,t:1527613550586};\\\", \\\"{x:1309,y:805,t:1527613550603};\\\", \\\"{x:1307,y:807,t:1527613550649};\\\", \\\"{x:1307,y:809,t:1527613550657};\\\", \\\"{x:1307,y:811,t:1527613550669};\\\", \\\"{x:1304,y:822,t:1527613550686};\\\", \\\"{x:1304,y:825,t:1527613550703};\\\", \\\"{x:1303,y:829,t:1527613550720};\\\", \\\"{x:1303,y:830,t:1527613550737};\\\", \\\"{x:1303,y:835,t:1527613550754};\\\", \\\"{x:1303,y:836,t:1527613550769};\\\", \\\"{x:1303,y:840,t:1527613550786};\\\", \\\"{x:1303,y:846,t:1527613550804};\\\", \\\"{x:1303,y:849,t:1527613550819};\\\", \\\"{x:1303,y:851,t:1527613550836};\\\", \\\"{x:1303,y:852,t:1527613550853};\\\", \\\"{x:1303,y:854,t:1527613550883};\\\", \\\"{x:1302,y:854,t:1527613550937};\\\", \\\"{x:1300,y:854,t:1527613551025};\\\", \\\"{x:1297,y:852,t:1527613551036};\\\", \\\"{x:1291,y:847,t:1527613551053};\\\", \\\"{x:1277,y:838,t:1527613551070};\\\", \\\"{x:1263,y:826,t:1527613551087};\\\", \\\"{x:1238,y:808,t:1527613551102};\\\", \\\"{x:1168,y:775,t:1527613551120};\\\", \\\"{x:1052,y:722,t:1527613551135};\\\", \\\"{x:854,y:654,t:1527613551152};\\\", \\\"{x:693,y:595,t:1527613551169};\\\", \\\"{x:517,y:532,t:1527613551186};\\\", \\\"{x:389,y:489,t:1527613551203};\\\", \\\"{x:300,y:462,t:1527613551219};\\\", \\\"{x:256,y:450,t:1527613551234};\\\", \\\"{x:245,y:445,t:1527613551252};\\\", \\\"{x:243,y:443,t:1527613551268};\\\", \\\"{x:244,y:443,t:1527613551328};\\\", \\\"{x:252,y:443,t:1527613551336};\\\", \\\"{x:263,y:445,t:1527613551351};\\\", \\\"{x:297,y:446,t:1527613551368};\\\", \\\"{x:318,y:448,t:1527613551384};\\\", \\\"{x:356,y:448,t:1527613551401};\\\", \\\"{x:392,y:449,t:1527613551419};\\\", \\\"{x:429,y:452,t:1527613551435};\\\", \\\"{x:449,y:455,t:1527613551452};\\\", \\\"{x:457,y:456,t:1527613551468};\\\", \\\"{x:458,y:456,t:1527613551486};\\\", \\\"{x:460,y:456,t:1527613551502};\\\", \\\"{x:465,y:456,t:1527613551519};\\\", \\\"{x:467,y:456,t:1527613551537};\\\", \\\"{x:468,y:456,t:1527613551552};\\\", \\\"{x:471,y:456,t:1527613551609};\\\", \\\"{x:476,y:457,t:1527613551619};\\\", \\\"{x:490,y:465,t:1527613551637};\\\", \\\"{x:503,y:471,t:1527613551653};\\\", \\\"{x:518,y:477,t:1527613551669};\\\", \\\"{x:528,y:480,t:1527613551686};\\\", \\\"{x:543,y:488,t:1527613551701};\\\", \\\"{x:554,y:498,t:1527613551719};\\\", \\\"{x:572,y:509,t:1527613551736};\\\", \\\"{x:590,y:518,t:1527613551751};\\\", \\\"{x:611,y:523,t:1527613551769};\\\", \\\"{x:624,y:525,t:1527613551786};\\\", \\\"{x:630,y:525,t:1527613551802};\\\", \\\"{x:633,y:525,t:1527613551819};\\\", \\\"{x:632,y:525,t:1527613552129};\\\", \\\"{x:628,y:525,t:1527613552136};\\\", \\\"{x:621,y:525,t:1527613552152};\\\", \\\"{x:621,y:524,t:1527613552169};\\\", \\\"{x:620,y:524,t:1527613552185};\\\", \\\"{x:620,y:523,t:1527613554560};\\\", \\\"{x:623,y:522,t:1527613554570};\\\", \\\"{x:634,y:516,t:1527613554588};\\\", \\\"{x:658,y:512,t:1527613554605};\\\", \\\"{x:689,y:507,t:1527613554621};\\\", \\\"{x:709,y:506,t:1527613554638};\\\", \\\"{x:728,y:504,t:1527613554656};\\\", \\\"{x:734,y:503,t:1527613554671};\\\", \\\"{x:735,y:503,t:1527613554688};\\\", \\\"{x:736,y:503,t:1527613554809};\\\", \\\"{x:740,y:503,t:1527613554825};\\\", \\\"{x:744,y:503,t:1527613554839};\\\", \\\"{x:759,y:507,t:1527613554856};\\\", \\\"{x:775,y:515,t:1527613554872};\\\", \\\"{x:796,y:520,t:1527613554888};\\\", \\\"{x:817,y:526,t:1527613554905};\\\", \\\"{x:826,y:527,t:1527613554924};\\\", \\\"{x:836,y:530,t:1527613554937};\\\", \\\"{x:843,y:530,t:1527613554954};\\\", \\\"{x:846,y:531,t:1527613554973};\\\", \\\"{x:847,y:531,t:1527613554988};\\\", \\\"{x:848,y:534,t:1527613556137};\\\", \\\"{x:869,y:556,t:1527613556146};\\\", \\\"{x:906,y:585,t:1527613556158};\\\", \\\"{x:1006,y:636,t:1527613556173};\\\", \\\"{x:1100,y:680,t:1527613556189};\\\", \\\"{x:1197,y:725,t:1527613556206};\\\", \\\"{x:1285,y:758,t:1527613556223};\\\", \\\"{x:1323,y:781,t:1527613556239};\\\", \\\"{x:1352,y:797,t:1527613556256};\\\", \\\"{x:1353,y:798,t:1527613556273};\\\", \\\"{x:1353,y:799,t:1527613556520};\\\", \\\"{x:1353,y:800,t:1527613556536};\\\", \\\"{x:1348,y:805,t:1527613556544};\\\", \\\"{x:1341,y:810,t:1527613556556};\\\", \\\"{x:1324,y:818,t:1527613556573};\\\", \\\"{x:1305,y:823,t:1527613556589};\\\", \\\"{x:1294,y:828,t:1527613556606};\\\", \\\"{x:1290,y:829,t:1527613556623};\\\", \\\"{x:1289,y:829,t:1527613556640};\\\", \\\"{x:1288,y:829,t:1527613556721};\\\", \\\"{x:1286,y:829,t:1527613556737};\\\", \\\"{x:1285,y:829,t:1527613556816};\\\", \\\"{x:1284,y:829,t:1527613556849};\\\", \\\"{x:1284,y:826,t:1527613556883};\\\", \\\"{x:1284,y:823,t:1527613556891};\\\", \\\"{x:1284,y:817,t:1527613556906};\\\", \\\"{x:1283,y:813,t:1527613556923};\\\", \\\"{x:1282,y:805,t:1527613556941};\\\", \\\"{x:1280,y:799,t:1527613556956};\\\", \\\"{x:1279,y:794,t:1527613556973};\\\", \\\"{x:1279,y:789,t:1527613556990};\\\", \\\"{x:1279,y:785,t:1527613557005};\\\", \\\"{x:1279,y:782,t:1527613557023};\\\", \\\"{x:1278,y:777,t:1527613557040};\\\", \\\"{x:1276,y:776,t:1527613557056};\\\", \\\"{x:1276,y:772,t:1527613557073};\\\", \\\"{x:1276,y:769,t:1527613557090};\\\", \\\"{x:1275,y:766,t:1527613557107};\\\", \\\"{x:1275,y:761,t:1527613557123};\\\", \\\"{x:1274,y:757,t:1527613557139};\\\", \\\"{x:1274,y:755,t:1527613557157};\\\", \\\"{x:1274,y:753,t:1527613557173};\\\", \\\"{x:1274,y:749,t:1527613557189};\\\", \\\"{x:1273,y:746,t:1527613557207};\\\", \\\"{x:1273,y:744,t:1527613557223};\\\", \\\"{x:1273,y:737,t:1527613557240};\\\", \\\"{x:1273,y:734,t:1527613557257};\\\", \\\"{x:1273,y:730,t:1527613557273};\\\", \\\"{x:1273,y:726,t:1527613557290};\\\", \\\"{x:1272,y:720,t:1527613557307};\\\", \\\"{x:1271,y:712,t:1527613557323};\\\", \\\"{x:1271,y:709,t:1527613557340};\\\", \\\"{x:1270,y:703,t:1527613557356};\\\", \\\"{x:1270,y:693,t:1527613557373};\\\", \\\"{x:1267,y:679,t:1527613557390};\\\", \\\"{x:1267,y:670,t:1527613557407};\\\", \\\"{x:1267,y:659,t:1527613557423};\\\", \\\"{x:1268,y:637,t:1527613557440};\\\", \\\"{x:1268,y:618,t:1527613557456};\\\", \\\"{x:1268,y:596,t:1527613557473};\\\", \\\"{x:1267,y:570,t:1527613557490};\\\", \\\"{x:1259,y:545,t:1527613557507};\\\", \\\"{x:1251,y:533,t:1527613557523};\\\", \\\"{x:1242,y:522,t:1527613557540};\\\", \\\"{x:1226,y:517,t:1527613557557};\\\", \\\"{x:1210,y:516,t:1527613557574};\\\", \\\"{x:1179,y:515,t:1527613557590};\\\", \\\"{x:1098,y:542,t:1527613557607};\\\", \\\"{x:971,y:593,t:1527613557624};\\\", \\\"{x:880,y:628,t:1527613557640};\\\", \\\"{x:797,y:665,t:1527613557657};\\\", \\\"{x:761,y:683,t:1527613557674};\\\", \\\"{x:722,y:701,t:1527613557690};\\\", \\\"{x:693,y:715,t:1527613557707};\\\", \\\"{x:677,y:728,t:1527613557724};\\\", \\\"{x:665,y:738,t:1527613557739};\\\", \\\"{x:662,y:740,t:1527613557757};\\\", \\\"{x:660,y:742,t:1527613557773};\\\", \\\"{x:657,y:744,t:1527613557789};\\\", \\\"{x:649,y:749,t:1527613557807};\\\", \\\"{x:638,y:754,t:1527613557824};\\\", \\\"{x:632,y:758,t:1527613557839};\\\", \\\"{x:631,y:759,t:1527613557856};\\\", \\\"{x:631,y:749,t:1527613557937};\\\", \\\"{x:633,y:739,t:1527613557944};\\\", \\\"{x:636,y:727,t:1527613557957};\\\", \\\"{x:655,y:697,t:1527613557974};\\\", \\\"{x:689,y:650,t:1527613557991};\\\", \\\"{x:720,y:614,t:1527613558008};\\\", \\\"{x:774,y:560,t:1527613558024};\\\", \\\"{x:799,y:540,t:1527613558041};\\\", \\\"{x:824,y:521,t:1527613558057};\\\", \\\"{x:843,y:505,t:1527613558074};\\\", \\\"{x:853,y:495,t:1527613558091};\\\", \\\"{x:859,y:489,t:1527613558107};\\\", \\\"{x:862,y:487,t:1527613558124};\\\", \\\"{x:860,y:487,t:1527613558297};\\\", \\\"{x:859,y:488,t:1527613558308};\\\", \\\"{x:853,y:491,t:1527613558324};\\\", \\\"{x:845,y:497,t:1527613558341};\\\", \\\"{x:840,y:502,t:1527613558358};\\\", \\\"{x:839,y:502,t:1527613558377};\\\", \\\"{x:839,y:507,t:1527613558474};\\\", \\\"{x:839,y:515,t:1527613558491};\\\", \\\"{x:841,y:520,t:1527613558508};\\\", \\\"{x:844,y:525,t:1527613558524};\\\", \\\"{x:847,y:528,t:1527613558541};\\\", \\\"{x:847,y:533,t:1527613558558};\\\", \\\"{x:849,y:538,t:1527613558575};\\\", \\\"{x:850,y:541,t:1527613558591};\\\", \\\"{x:850,y:545,t:1527613558608};\\\", \\\"{x:850,y:546,t:1527613558680};\\\", \\\"{x:852,y:546,t:1527613558729};\\\", \\\"{x:852,y:544,t:1527613558741};\\\", \\\"{x:853,y:538,t:1527613558759};\\\", \\\"{x:853,y:537,t:1527613558775};\\\", \\\"{x:853,y:535,t:1527613558792};\\\", \\\"{x:853,y:531,t:1527613558809};\\\", \\\"{x:853,y:530,t:1527613558824};\\\", \\\"{x:854,y:529,t:1527613558841};\\\", \\\"{x:854,y:528,t:1527613558859};\\\", \\\"{x:854,y:526,t:1527613558875};\\\", \\\"{x:854,y:525,t:1527613558892};\\\", \\\"{x:854,y:522,t:1527613558908};\\\", \\\"{x:854,y:520,t:1527613558925};\\\", \\\"{x:854,y:519,t:1527613558942};\\\", \\\"{x:853,y:518,t:1527613559225};\\\", \\\"{x:852,y:518,t:1527613559257};\\\", \\\"{x:850,y:518,t:1527613559337};\\\", \\\"{x:849,y:518,t:1527613559401};\\\", \\\"{x:848,y:518,t:1527613559409};\\\", \\\"{x:847,y:518,t:1527613559425};\\\", \\\"{x:840,y:524,t:1527613560578};\\\", \\\"{x:823,y:543,t:1527613560594};\\\", \\\"{x:757,y:599,t:1527613560609};\\\", \\\"{x:640,y:660,t:1527613560627};\\\", \\\"{x:547,y:694,t:1527613560643};\\\", \\\"{x:450,y:741,t:1527613560659};\\\", \\\"{x:368,y:773,t:1527613560676};\\\", \\\"{x:323,y:791,t:1527613560693};\\\", \\\"{x:304,y:799,t:1527613560709};\\\", \\\"{x:299,y:802,t:1527613560725};\\\", \\\"{x:298,y:802,t:1527613560824};\\\", \\\"{x:300,y:798,t:1527613560906};\\\", \\\"{x:301,y:797,t:1527613560913};\\\", \\\"{x:305,y:794,t:1527613560927};\\\", \\\"{x:316,y:786,t:1527613560943};\\\", \\\"{x:329,y:775,t:1527613560960};\\\", \\\"{x:346,y:761,t:1527613560976};\\\", \\\"{x:360,y:747,t:1527613560993};\\\", \\\"{x:371,y:735,t:1527613561010};\\\", \\\"{x:377,y:727,t:1527613561026};\\\", \\\"{x:379,y:726,t:1527613561043};\\\", \\\"{x:380,y:725,t:1527613561060};\\\", \\\"{x:381,y:723,t:1527613561128};\\\", \\\"{x:385,y:722,t:1527613561143};\\\", \\\"{x:391,y:719,t:1527613561160};\\\", \\\"{x:394,y:718,t:1527613561176};\\\", \\\"{x:395,y:718,t:1527613561200};\\\", \\\"{x:398,y:717,t:1527613561264};\\\", \\\"{x:399,y:716,t:1527613561280};\\\", \\\"{x:403,y:714,t:1527613561293};\\\", \\\"{x:433,y:709,t:1527613561310};\\\", \\\"{x:456,y:708,t:1527613561327};\\\", \\\"{x:487,y:708,t:1527613561343};\\\", \\\"{x:525,y:708,t:1527613561360};\\\", \\\"{x:545,y:710,t:1527613561376};\\\", \\\"{x:557,y:711,t:1527613561393};\\\", \\\"{x:556,y:712,t:1527613561632};\\\", \\\"{x:555,y:713,t:1527613561928};\\\" ] }, { \\\"rt\\\": 44245, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 8, \\\"time_elapsed\\\": 281190, \\\"internal_node_id\\\": \\\"0.0-5.0-3.0\\\", \\\"subject\\\": \\\"AZKMW\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"oscar\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 4, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"F\\\", \\\"U\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-4-U -U -F -F -O -O -K -I \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:554,y:713,t:1527613565089};\\\", \\\"{x:554,y:714,t:1527613565096};\\\", \\\"{x:552,y:709,t:1527613565924};\\\", \\\"{x:545,y:703,t:1527613565934};\\\", \\\"{x:537,y:692,t:1527613565954};\\\", \\\"{x:526,y:670,t:1527613565966};\\\", \\\"{x:518,y:654,t:1527613565983};\\\", \\\"{x:517,y:653,t:1527613567076};\\\", \\\"{x:515,y:649,t:1527613567087};\\\", \\\"{x:514,y:646,t:1527613567101};\\\", \\\"{x:514,y:645,t:1527613567154};\\\", \\\"{x:514,y:643,t:1527613567492};\\\", \\\"{x:514,y:641,t:1527613567502};\\\", \\\"{x:525,y:636,t:1527613567519};\\\", \\\"{x:538,y:631,t:1527613567534};\\\", \\\"{x:550,y:625,t:1527613567552};\\\", \\\"{x:555,y:624,t:1527613567568};\\\", \\\"{x:559,y:622,t:1527613567584};\\\", \\\"{x:568,y:617,t:1527613567603};\\\", \\\"{x:580,y:615,t:1527613567618};\\\", \\\"{x:589,y:611,t:1527613567635};\\\", \\\"{x:601,y:607,t:1527613567651};\\\", \\\"{x:606,y:606,t:1527613567668};\\\", \\\"{x:613,y:600,t:1527613567685};\\\", \\\"{x:620,y:594,t:1527613567701};\\\", \\\"{x:621,y:588,t:1527613567718};\\\", \\\"{x:631,y:578,t:1527613567736};\\\", \\\"{x:638,y:565,t:1527613567752};\\\", \\\"{x:644,y:550,t:1527613567768};\\\", \\\"{x:647,y:539,t:1527613567785};\\\", \\\"{x:649,y:531,t:1527613567802};\\\", \\\"{x:650,y:527,t:1527613567818};\\\", \\\"{x:650,y:524,t:1527613567835};\\\", \\\"{x:650,y:523,t:1527613567867};\\\", \\\"{x:651,y:522,t:1527613567875};\\\", \\\"{x:651,y:521,t:1527613567891};\\\", \\\"{x:653,y:520,t:1527613567902};\\\", \\\"{x:654,y:517,t:1527613567918};\\\", \\\"{x:655,y:514,t:1527613567935};\\\", \\\"{x:655,y:505,t:1527613567952};\\\", \\\"{x:657,y:485,t:1527613567969};\\\", \\\"{x:657,y:458,t:1527613567986};\\\", \\\"{x:668,y:434,t:1527613568002};\\\", \\\"{x:679,y:403,t:1527613568018};\\\", \\\"{x:697,y:375,t:1527613568035};\\\", \\\"{x:701,y:372,t:1527613568053};\\\", \\\"{x:701,y:370,t:1527613569500};\\\", \\\"{x:701,y:344,t:1527613569508};\\\", \\\"{x:705,y:283,t:1527613569521};\\\", \\\"{x:731,y:133,t:1527613569537};\\\", \\\"{x:755,y:16,t:1527613569554};\\\", \\\"{x:785,y:16,t:1527613569571};\\\", \\\"{x:831,y:16,t:1527613569588};\\\", \\\"{x:882,y:16,t:1527613569604};\\\", \\\"{x:936,y:16,t:1527613569621};\\\", \\\"{x:976,y:16,t:1527613569637};\\\", \\\"{x:1018,y:16,t:1527613569654};\\\", \\\"{x:1044,y:16,t:1527613569671};\\\", \\\"{x:1110,y:16,t:1527613569688};\\\", \\\"{x:1145,y:16,t:1527613569703};\\\", \\\"{x:1171,y:16,t:1527613569721};\\\", \\\"{x:1171,y:16,t:1527613569738};\\\", \\\"{x:1160,y:16,t:1527613569772};\\\", \\\"{x:1130,y:16,t:1527613569787};\\\", \\\"{x:1102,y:16,t:1527613569805};\\\", \\\"{x:1067,y:16,t:1527613569821};\\\", \\\"{x:1020,y:16,t:1527613569838};\\\", \\\"{x:949,y:16,t:1527613569855};\\\", \\\"{x:906,y:16,t:1527613569871};\\\", \\\"{x:864,y:16,t:1527613569888};\\\", \\\"{x:826,y:16,t:1527613569905};\\\", \\\"{x:808,y:16,t:1527613569921};\\\", \\\"{x:805,y:16,t:1527613569938};\\\", \\\"{x:805,y:21,t:1527613570012};\\\", \\\"{x:807,y:31,t:1527613570021};\\\", \\\"{x:819,y:56,t:1527613570038};\\\", \\\"{x:821,y:71,t:1527613570055};\\\", \\\"{x:819,y:72,t:1527613570204};\\\", \\\"{x:818,y:72,t:1527613570222};\\\", \\\"{x:817,y:72,t:1527613570238};\\\", \\\"{x:817,y:74,t:1527613570268};\\\", \\\"{x:816,y:81,t:1527613570276};\\\", \\\"{x:814,y:94,t:1527613570288};\\\", \\\"{x:803,y:140,t:1527613570305};\\\", \\\"{x:776,y:203,t:1527613570322};\\\", \\\"{x:750,y:231,t:1527613570338};\\\", \\\"{x:740,y:236,t:1527613570355};\\\", \\\"{x:740,y:237,t:1527613571036};\\\", \\\"{x:740,y:238,t:1527613571332};\\\", \\\"{x:740,y:240,t:1527613571356};\\\", \\\"{x:740,y:242,t:1527613571373};\\\", \\\"{x:740,y:245,t:1527613571390};\\\", \\\"{x:741,y:252,t:1527613571406};\\\", \\\"{x:747,y:267,t:1527613571423};\\\", \\\"{x:752,y:279,t:1527613571440};\\\", \\\"{x:762,y:290,t:1527613571456};\\\", \\\"{x:776,y:301,t:1527613571473};\\\", \\\"{x:789,y:310,t:1527613571490};\\\", \\\"{x:802,y:316,t:1527613571507};\\\", \\\"{x:807,y:321,t:1527613571523};\\\", \\\"{x:810,y:323,t:1527613571540};\\\", \\\"{x:811,y:323,t:1527613571571};\\\", \\\"{x:814,y:325,t:1527613571588};\\\", \\\"{x:819,y:328,t:1527613571596};\\\", \\\"{x:824,y:329,t:1527613571607};\\\", \\\"{x:840,y:345,t:1527613571623};\\\", \\\"{x:864,y:361,t:1527613571640};\\\", \\\"{x:866,y:361,t:1527613571715};\\\", \\\"{x:869,y:361,t:1527613571724};\\\", \\\"{x:870,y:361,t:1527613571755};\\\", \\\"{x:874,y:361,t:1527613571763};\\\", \\\"{x:875,y:361,t:1527613571773};\\\", \\\"{x:881,y:360,t:1527613571790};\\\", \\\"{x:885,y:358,t:1527613571807};\\\", \\\"{x:896,y:358,t:1527613571824};\\\", \\\"{x:908,y:356,t:1527613571840};\\\", \\\"{x:920,y:356,t:1527613571857};\\\", \\\"{x:939,y:356,t:1527613571873};\\\", \\\"{x:969,y:356,t:1527613571890};\\\", \\\"{x:1001,y:359,t:1527613571908};\\\", \\\"{x:1096,y:375,t:1527613571924};\\\", \\\"{x:1155,y:392,t:1527613571940};\\\", \\\"{x:1243,y:417,t:1527613571957};\\\", \\\"{x:1329,y:440,t:1527613571974};\\\", \\\"{x:1410,y:468,t:1527613571990};\\\", \\\"{x:1461,y:493,t:1527613572007};\\\", \\\"{x:1487,y:506,t:1527613572024};\\\", \\\"{x:1503,y:514,t:1527613572040};\\\", \\\"{x:1521,y:521,t:1527613572057};\\\", \\\"{x:1540,y:528,t:1527613572074};\\\", \\\"{x:1554,y:538,t:1527613572090};\\\", \\\"{x:1565,y:545,t:1527613572108};\\\", \\\"{x:1570,y:547,t:1527613572124};\\\", \\\"{x:1571,y:547,t:1527613572212};\\\", \\\"{x:1573,y:550,t:1527613572236};\\\", \\\"{x:1573,y:553,t:1527613572244};\\\", \\\"{x:1574,y:553,t:1527613572257};\\\", \\\"{x:1577,y:558,t:1527613572274};\\\", \\\"{x:1580,y:572,t:1527613572292};\\\", \\\"{x:1583,y:587,t:1527613572307};\\\", \\\"{x:1593,y:655,t:1527613572324};\\\", \\\"{x:1594,y:692,t:1527613572341};\\\", \\\"{x:1597,y:730,t:1527613572358};\\\", \\\"{x:1599,y:761,t:1527613572375};\\\", \\\"{x:1599,y:788,t:1527613572391};\\\", \\\"{x:1599,y:807,t:1527613572408};\\\", \\\"{x:1602,y:825,t:1527613572424};\\\", \\\"{x:1602,y:833,t:1527613572441};\\\", \\\"{x:1601,y:834,t:1527613572458};\\\", \\\"{x:1601,y:835,t:1527613572476};\\\", \\\"{x:1601,y:838,t:1527613572491};\\\", \\\"{x:1600,y:851,t:1527613572507};\\\", \\\"{x:1594,y:862,t:1527613572524};\\\", \\\"{x:1591,y:866,t:1527613572541};\\\", \\\"{x:1588,y:868,t:1527613572558};\\\", \\\"{x:1581,y:873,t:1527613572574};\\\", \\\"{x:1577,y:873,t:1527613572591};\\\", \\\"{x:1574,y:874,t:1527613572608};\\\", \\\"{x:1570,y:880,t:1527613572624};\\\", \\\"{x:1561,y:893,t:1527613572642};\\\", \\\"{x:1554,y:908,t:1527613572658};\\\", \\\"{x:1549,y:924,t:1527613572674};\\\", \\\"{x:1546,y:937,t:1527613572691};\\\", \\\"{x:1545,y:953,t:1527613572708};\\\", \\\"{x:1544,y:959,t:1527613572725};\\\", \\\"{x:1544,y:960,t:1527613572939};\\\", \\\"{x:1545,y:960,t:1527613572947};\\\", \\\"{x:1546,y:960,t:1527613572971};\\\", \\\"{x:1548,y:959,t:1527613572979};\\\", \\\"{x:1549,y:959,t:1527613572995};\\\", \\\"{x:1550,y:959,t:1527613573010};\\\", \\\"{x:1552,y:958,t:1527613573024};\\\", \\\"{x:1555,y:957,t:1527613573041};\\\", \\\"{x:1556,y:957,t:1527613573059};\\\", \\\"{x:1558,y:957,t:1527613573075};\\\", \\\"{x:1562,y:956,t:1527613573090};\\\", \\\"{x:1565,y:956,t:1527613573107};\\\", \\\"{x:1568,y:956,t:1527613573125};\\\", \\\"{x:1572,y:956,t:1527613573142};\\\", \\\"{x:1576,y:955,t:1527613573158};\\\", \\\"{x:1577,y:955,t:1527613573180};\\\", \\\"{x:1578,y:955,t:1527613573284};\\\", \\\"{x:1579,y:954,t:1527613573299};\\\", \\\"{x:1579,y:953,t:1527613574028};\\\", \\\"{x:1582,y:953,t:1527613574044};\\\", \\\"{x:1585,y:954,t:1527613574059};\\\", \\\"{x:1585,y:956,t:1527613574076};\\\", \\\"{x:1587,y:957,t:1527613574095};\\\", \\\"{x:1587,y:958,t:1527613574132};\\\", \\\"{x:1587,y:959,t:1527613574180};\\\", \\\"{x:1588,y:959,t:1527613574404};\\\", \\\"{x:1590,y:959,t:1527613574420};\\\", \\\"{x:1592,y:959,t:1527613574428};\\\", \\\"{x:1593,y:959,t:1527613574443};\\\", \\\"{x:1594,y:959,t:1527613574460};\\\", \\\"{x:1594,y:957,t:1527613574748};\\\", \\\"{x:1594,y:951,t:1527613574760};\\\", \\\"{x:1596,y:937,t:1527613574777};\\\", \\\"{x:1599,y:924,t:1527613574794};\\\", \\\"{x:1603,y:903,t:1527613574811};\\\", \\\"{x:1610,y:854,t:1527613574827};\\\", \\\"{x:1617,y:807,t:1527613574844};\\\", \\\"{x:1618,y:793,t:1527613574861};\\\", \\\"{x:1618,y:780,t:1527613574877};\\\", \\\"{x:1618,y:765,t:1527613574895};\\\", \\\"{x:1615,y:753,t:1527613574910};\\\", \\\"{x:1614,y:743,t:1527613574928};\\\", \\\"{x:1613,y:736,t:1527613574944};\\\", \\\"{x:1612,y:732,t:1527613574960};\\\", \\\"{x:1612,y:729,t:1527613574977};\\\", \\\"{x:1612,y:725,t:1527613574994};\\\", \\\"{x:1612,y:722,t:1527613575011};\\\", \\\"{x:1612,y:720,t:1527613575028};\\\", \\\"{x:1611,y:716,t:1527613575044};\\\", \\\"{x:1611,y:714,t:1527613575061};\\\", \\\"{x:1608,y:714,t:1527613575668};\\\", \\\"{x:1602,y:714,t:1527613575678};\\\", \\\"{x:1583,y:714,t:1527613575696};\\\", \\\"{x:1545,y:714,t:1527613575711};\\\", \\\"{x:1488,y:717,t:1527613575728};\\\", \\\"{x:1403,y:721,t:1527613575745};\\\", \\\"{x:1326,y:721,t:1527613575761};\\\", \\\"{x:1239,y:718,t:1527613575778};\\\", \\\"{x:1126,y:703,t:1527613575795};\\\", \\\"{x:1088,y:696,t:1527613575811};\\\", \\\"{x:1058,y:691,t:1527613575828};\\\", \\\"{x:1043,y:683,t:1527613575846};\\\", \\\"{x:1038,y:677,t:1527613575861};\\\", \\\"{x:1027,y:665,t:1527613575878};\\\", \\\"{x:1012,y:655,t:1527613575897};\\\", \\\"{x:1003,y:639,t:1527613575912};\\\", \\\"{x:999,y:628,t:1527613575929};\\\", \\\"{x:998,y:622,t:1527613575945};\\\", \\\"{x:998,y:617,t:1527613575962};\\\", \\\"{x:1004,y:608,t:1527613575978};\\\", \\\"{x:1021,y:589,t:1527613575996};\\\", \\\"{x:1027,y:577,t:1527613576012};\\\", \\\"{x:1034,y:570,t:1527613576028};\\\", \\\"{x:1039,y:562,t:1527613576046};\\\", \\\"{x:1044,y:544,t:1527613576062};\\\", \\\"{x:1049,y:527,t:1527613576078};\\\", \\\"{x:1050,y:522,t:1527613576095};\\\", \\\"{x:1050,y:534,t:1527613576148};\\\", \\\"{x:1050,y:555,t:1527613576162};\\\", \\\"{x:1054,y:591,t:1527613576179};\\\", \\\"{x:1054,y:618,t:1527613576195};\\\", \\\"{x:1052,y:634,t:1527613576211};\\\", \\\"{x:1051,y:646,t:1527613576228};\\\", \\\"{x:1051,y:663,t:1527613576246};\\\", \\\"{x:1063,y:682,t:1527613576262};\\\", \\\"{x:1073,y:698,t:1527613576279};\\\", \\\"{x:1088,y:718,t:1527613576295};\\\", \\\"{x:1103,y:733,t:1527613576312};\\\", \\\"{x:1111,y:741,t:1527613576329};\\\", \\\"{x:1112,y:745,t:1527613576345};\\\", \\\"{x:1118,y:748,t:1527613576362};\\\", \\\"{x:1119,y:749,t:1527613576379};\\\", \\\"{x:1122,y:749,t:1527613576395};\\\", \\\"{x:1124,y:749,t:1527613576412};\\\", \\\"{x:1128,y:749,t:1527613576429};\\\", \\\"{x:1129,y:749,t:1527613576445};\\\", \\\"{x:1138,y:746,t:1527613576462};\\\", \\\"{x:1155,y:741,t:1527613576479};\\\", \\\"{x:1180,y:740,t:1527613576495};\\\", \\\"{x:1227,y:736,t:1527613576512};\\\", \\\"{x:1286,y:736,t:1527613576529};\\\", \\\"{x:1367,y:736,t:1527613576545};\\\", \\\"{x:1455,y:736,t:1527613576562};\\\", \\\"{x:1573,y:736,t:1527613576578};\\\", \\\"{x:1659,y:750,t:1527613576596};\\\", \\\"{x:1745,y:761,t:1527613576611};\\\", \\\"{x:1833,y:770,t:1527613576628};\\\", \\\"{x:1905,y:779,t:1527613576646};\\\", \\\"{x:1919,y:786,t:1527613576661};\\\", \\\"{x:1919,y:790,t:1527613576675};\\\", \\\"{x:1919,y:793,t:1527613576693};\\\", \\\"{x:1919,y:794,t:1527613576708};\\\", \\\"{x:1919,y:796,t:1527613576725};\\\", \\\"{x:1919,y:800,t:1527613576743};\\\", \\\"{x:1913,y:805,t:1527613576758};\\\", \\\"{x:1904,y:811,t:1527613576775};\\\", \\\"{x:1898,y:813,t:1527613576793};\\\", \\\"{x:1884,y:820,t:1527613576808};\\\", \\\"{x:1854,y:832,t:1527613576825};\\\", \\\"{x:1826,y:841,t:1527613576843};\\\", \\\"{x:1801,y:846,t:1527613576859};\\\", \\\"{x:1709,y:864,t:1527613576876};\\\", \\\"{x:1621,y:869,t:1527613576894};\\\", \\\"{x:1595,y:871,t:1527613576909};\\\", \\\"{x:1584,y:868,t:1527613576926};\\\", \\\"{x:1566,y:868,t:1527613576943};\\\", \\\"{x:1554,y:863,t:1527613576959};\\\", \\\"{x:1541,y:862,t:1527613576975};\\\", \\\"{x:1538,y:861,t:1527613576993};\\\", \\\"{x:1535,y:860,t:1527613577010};\\\", \\\"{x:1535,y:859,t:1527613577108};\\\", \\\"{x:1535,y:857,t:1527613577123};\\\", \\\"{x:1536,y:855,t:1527613577140};\\\", \\\"{x:1538,y:852,t:1527613577148};\\\", \\\"{x:1541,y:850,t:1527613577160};\\\", \\\"{x:1541,y:848,t:1527613577176};\\\", \\\"{x:1542,y:847,t:1527613577193};\\\", \\\"{x:1542,y:846,t:1527613577211};\\\", \\\"{x:1543,y:842,t:1527613577227};\\\", \\\"{x:1546,y:834,t:1527613577243};\\\", \\\"{x:1547,y:832,t:1527613577260};\\\", \\\"{x:1547,y:829,t:1527613577277};\\\", \\\"{x:1548,y:827,t:1527613577295};\\\", \\\"{x:1548,y:826,t:1527613577340};\\\", \\\"{x:1548,y:825,t:1527613577356};\\\", \\\"{x:1548,y:824,t:1527613577364};\\\", \\\"{x:1548,y:823,t:1527613577377};\\\", \\\"{x:1543,y:819,t:1527613577393};\\\", \\\"{x:1538,y:815,t:1527613577410};\\\", \\\"{x:1534,y:814,t:1527613577428};\\\", \\\"{x:1533,y:813,t:1527613577444};\\\", \\\"{x:1531,y:812,t:1527613577460};\\\", \\\"{x:1528,y:812,t:1527613577477};\\\", \\\"{x:1525,y:810,t:1527613577495};\\\", \\\"{x:1524,y:808,t:1527613577510};\\\", \\\"{x:1521,y:806,t:1527613577527};\\\", \\\"{x:1520,y:805,t:1527613577543};\\\", \\\"{x:1519,y:805,t:1527613577876};\\\", \\\"{x:1521,y:802,t:1527613578604};\\\", \\\"{x:1526,y:797,t:1527613578611};\\\", \\\"{x:1536,y:790,t:1527613578628};\\\", \\\"{x:1545,y:785,t:1527613578644};\\\", \\\"{x:1557,y:778,t:1527613578661};\\\", \\\"{x:1564,y:773,t:1527613578678};\\\", \\\"{x:1576,y:771,t:1527613578694};\\\", \\\"{x:1582,y:769,t:1527613578711};\\\", \\\"{x:1583,y:769,t:1527613578727};\\\", \\\"{x:1584,y:768,t:1527613578744};\\\", \\\"{x:1589,y:767,t:1527613578761};\\\", \\\"{x:1592,y:765,t:1527613578778};\\\", \\\"{x:1591,y:765,t:1527613579620};\\\", \\\"{x:1589,y:766,t:1527613579629};\\\", \\\"{x:1578,y:770,t:1527613579646};\\\", \\\"{x:1571,y:772,t:1527613579662};\\\", \\\"{x:1568,y:774,t:1527613579678};\\\", \\\"{x:1567,y:774,t:1527613579695};\\\", \\\"{x:1565,y:775,t:1527613579713};\\\", \\\"{x:1562,y:777,t:1527613579729};\\\", \\\"{x:1561,y:777,t:1527613579748};\\\", \\\"{x:1561,y:778,t:1527613579820};\\\", \\\"{x:1561,y:781,t:1527613579829};\\\", \\\"{x:1561,y:784,t:1527613579846};\\\", \\\"{x:1558,y:789,t:1527613579862};\\\", \\\"{x:1558,y:792,t:1527613579879};\\\", \\\"{x:1553,y:800,t:1527613579895};\\\", \\\"{x:1553,y:806,t:1527613579912};\\\", \\\"{x:1552,y:812,t:1527613579929};\\\", \\\"{x:1552,y:815,t:1527613579946};\\\", \\\"{x:1552,y:819,t:1527613579963};\\\", \\\"{x:1553,y:820,t:1527613579980};\\\", \\\"{x:1553,y:821,t:1527613580028};\\\", \\\"{x:1555,y:823,t:1527613580076};\\\", \\\"{x:1556,y:825,t:1527613580091};\\\", \\\"{x:1557,y:826,t:1527613580100};\\\", \\\"{x:1558,y:828,t:1527613580113};\\\", \\\"{x:1561,y:831,t:1527613580129};\\\", \\\"{x:1564,y:833,t:1527613580145};\\\", \\\"{x:1565,y:834,t:1527613580163};\\\", \\\"{x:1565,y:835,t:1527613580291};\\\", \\\"{x:1565,y:836,t:1527613580324};\\\", \\\"{x:1563,y:838,t:1527613580340};\\\", \\\"{x:1558,y:838,t:1527613580348};\\\", \\\"{x:1549,y:838,t:1527613580362};\\\", \\\"{x:1539,y:838,t:1527613580380};\\\", \\\"{x:1531,y:838,t:1527613580396};\\\", \\\"{x:1519,y:838,t:1527613580412};\\\", \\\"{x:1512,y:838,t:1527613580429};\\\", \\\"{x:1510,y:838,t:1527613580445};\\\", \\\"{x:1508,y:838,t:1527613580462};\\\", \\\"{x:1508,y:839,t:1527613580492};\\\", \\\"{x:1507,y:840,t:1527613580515};\\\", \\\"{x:1506,y:841,t:1527613580548};\\\", \\\"{x:1505,y:841,t:1527613580596};\\\", \\\"{x:1502,y:841,t:1527613580612};\\\", \\\"{x:1499,y:837,t:1527613580630};\\\", \\\"{x:1496,y:835,t:1527613580647};\\\", \\\"{x:1494,y:834,t:1527613580662};\\\", \\\"{x:1492,y:834,t:1527613580700};\\\", \\\"{x:1489,y:834,t:1527613580723};\\\", \\\"{x:1487,y:833,t:1527613580739};\\\", \\\"{x:1485,y:832,t:1527613580798};\\\", \\\"{x:1484,y:831,t:1527613580947};\\\", \\\"{x:1484,y:829,t:1527613580963};\\\", \\\"{x:1484,y:826,t:1527613580979};\\\", \\\"{x:1484,y:825,t:1527613580996};\\\", \\\"{x:1484,y:824,t:1527613582798};\\\", \\\"{x:1485,y:824,t:1527613582815};\\\", \\\"{x:1486,y:824,t:1527613583380};\\\", \\\"{x:1488,y:826,t:1527613583732};\\\", \\\"{x:1490,y:831,t:1527613583748};\\\", \\\"{x:1492,y:834,t:1527613583765};\\\", \\\"{x:1492,y:838,t:1527613583782};\\\", \\\"{x:1494,y:839,t:1527613583804};\\\", \\\"{x:1498,y:839,t:1527613584076};\\\", \\\"{x:1501,y:839,t:1527613584083};\\\", \\\"{x:1504,y:839,t:1527613584099};\\\", \\\"{x:1518,y:836,t:1527613584115};\\\", \\\"{x:1528,y:835,t:1527613584133};\\\", \\\"{x:1544,y:832,t:1527613584149};\\\", \\\"{x:1559,y:832,t:1527613584166};\\\", \\\"{x:1565,y:832,t:1527613584182};\\\", \\\"{x:1567,y:832,t:1527613584198};\\\", \\\"{x:1568,y:832,t:1527613584444};\\\", \\\"{x:1570,y:832,t:1527613584451};\\\", \\\"{x:1572,y:832,t:1527613584465};\\\", \\\"{x:1580,y:831,t:1527613584482};\\\", \\\"{x:1592,y:828,t:1527613584500};\\\", \\\"{x:1602,y:827,t:1527613584515};\\\", \\\"{x:1608,y:827,t:1527613584532};\\\", \\\"{x:1609,y:827,t:1527613584555};\\\", \\\"{x:1611,y:827,t:1527613584566};\\\", \\\"{x:1612,y:824,t:1527613586867};\\\", \\\"{x:1538,y:806,t:1527613586885};\\\", \\\"{x:1407,y:768,t:1527613586900};\\\", \\\"{x:1218,y:722,t:1527613586918};\\\", \\\"{x:990,y:675,t:1527613586934};\\\", \\\"{x:746,y:623,t:1527613586950};\\\", \\\"{x:507,y:576,t:1527613586968};\\\", \\\"{x:318,y:539,t:1527613586984};\\\", \\\"{x:157,y:513,t:1527613587002};\\\", \\\"{x:25,y:481,t:1527613587017};\\\", \\\"{x:0,y:466,t:1527613587034};\\\", \\\"{x:0,y:446,t:1527613587051};\\\", \\\"{x:0,y:445,t:1527613587068};\\\", \\\"{x:0,y:443,t:1527613587131};\\\", \\\"{x:0,y:442,t:1527613587139};\\\", \\\"{x:2,y:442,t:1527613587151};\\\", \\\"{x:8,y:442,t:1527613587168};\\\", \\\"{x:23,y:446,t:1527613587184};\\\", \\\"{x:44,y:457,t:1527613587201};\\\", \\\"{x:70,y:468,t:1527613587219};\\\", \\\"{x:132,y:488,t:1527613587234};\\\", \\\"{x:232,y:505,t:1527613587251};\\\", \\\"{x:272,y:514,t:1527613587269};\\\", \\\"{x:313,y:515,t:1527613587285};\\\", \\\"{x:337,y:515,t:1527613587301};\\\", \\\"{x:366,y:515,t:1527613587318};\\\", \\\"{x:385,y:515,t:1527613587335};\\\", \\\"{x:404,y:518,t:1527613587352};\\\", \\\"{x:420,y:522,t:1527613587368};\\\", \\\"{x:423,y:523,t:1527613587384};\\\", \\\"{x:430,y:524,t:1527613587401};\\\", \\\"{x:443,y:528,t:1527613587418};\\\", \\\"{x:472,y:534,t:1527613587434};\\\", \\\"{x:558,y:557,t:1527613587452};\\\", \\\"{x:605,y:563,t:1527613587469};\\\", \\\"{x:624,y:574,t:1527613587484};\\\", \\\"{x:641,y:576,t:1527613587501};\\\", \\\"{x:644,y:578,t:1527613587518};\\\", \\\"{x:645,y:578,t:1527613587534};\\\", \\\"{x:649,y:582,t:1527613587551};\\\", \\\"{x:650,y:587,t:1527613587568};\\\", \\\"{x:650,y:589,t:1527613587584};\\\", \\\"{x:650,y:590,t:1527613587601};\\\", \\\"{x:650,y:591,t:1527613587618};\\\", \\\"{x:650,y:592,t:1527613587635};\\\", \\\"{x:650,y:593,t:1527613587771};\\\", \\\"{x:650,y:594,t:1527613587787};\\\", \\\"{x:647,y:594,t:1527613587803};\\\", \\\"{x:640,y:594,t:1527613587819};\\\", \\\"{x:628,y:593,t:1527613587835};\\\", \\\"{x:626,y:593,t:1527613587850};\\\", \\\"{x:625,y:593,t:1527613587867};\\\", \\\"{x:626,y:593,t:1527613588443};\\\", \\\"{x:631,y:593,t:1527613588452};\\\", \\\"{x:659,y:593,t:1527613588470};\\\", \\\"{x:707,y:593,t:1527613588484};\\\", \\\"{x:794,y:599,t:1527613588503};\\\", \\\"{x:885,y:608,t:1527613588519};\\\", \\\"{x:994,y:612,t:1527613588535};\\\", \\\"{x:1112,y:623,t:1527613588552};\\\", \\\"{x:1255,y:635,t:1527613588569};\\\", \\\"{x:1374,y:652,t:1527613588585};\\\", \\\"{x:1491,y:656,t:1527613588602};\\\", \\\"{x:1643,y:656,t:1527613588619};\\\", \\\"{x:1716,y:656,t:1527613588635};\\\", \\\"{x:1783,y:659,t:1527613588652};\\\", \\\"{x:1802,y:661,t:1527613588670};\\\", \\\"{x:1819,y:662,t:1527613588686};\\\", \\\"{x:1823,y:664,t:1527613588703};\\\", \\\"{x:1824,y:665,t:1527613588720};\\\", \\\"{x:1821,y:664,t:1527613588812};\\\", \\\"{x:1818,y:664,t:1527613588819};\\\", \\\"{x:1806,y:664,t:1527613588836};\\\", \\\"{x:1791,y:667,t:1527613588852};\\\", \\\"{x:1771,y:676,t:1527613588869};\\\", \\\"{x:1751,y:686,t:1527613588886};\\\", \\\"{x:1727,y:692,t:1527613588903};\\\", \\\"{x:1712,y:694,t:1527613588920};\\\", \\\"{x:1692,y:695,t:1527613588937};\\\", \\\"{x:1679,y:695,t:1527613588952};\\\", \\\"{x:1664,y:695,t:1527613588970};\\\", \\\"{x:1655,y:695,t:1527613588986};\\\", \\\"{x:1647,y:698,t:1527613589002};\\\", \\\"{x:1637,y:703,t:1527613589020};\\\", \\\"{x:1626,y:707,t:1527613589037};\\\", \\\"{x:1622,y:709,t:1527613589052};\\\", \\\"{x:1616,y:713,t:1527613589070};\\\", \\\"{x:1609,y:717,t:1527613589087};\\\", \\\"{x:1604,y:719,t:1527613589115};\\\", \\\"{x:1596,y:722,t:1527613589123};\\\", \\\"{x:1594,y:722,t:1527613589136};\\\", \\\"{x:1583,y:722,t:1527613589153};\\\", \\\"{x:1573,y:722,t:1527613589169};\\\", \\\"{x:1555,y:722,t:1527613589187};\\\", \\\"{x:1549,y:722,t:1527613589202};\\\", \\\"{x:1531,y:721,t:1527613589219};\\\", \\\"{x:1522,y:719,t:1527613589237};\\\", \\\"{x:1514,y:714,t:1527613589253};\\\", \\\"{x:1508,y:709,t:1527613589269};\\\", \\\"{x:1503,y:703,t:1527613589287};\\\", \\\"{x:1501,y:699,t:1527613589303};\\\", \\\"{x:1499,y:691,t:1527613589320};\\\", \\\"{x:1495,y:683,t:1527613589336};\\\", \\\"{x:1492,y:678,t:1527613589353};\\\", \\\"{x:1491,y:673,t:1527613589370};\\\", \\\"{x:1491,y:670,t:1527613589387};\\\", \\\"{x:1488,y:666,t:1527613589404};\\\", \\\"{x:1487,y:664,t:1527613589420};\\\", \\\"{x:1486,y:663,t:1527613589443};\\\", \\\"{x:1486,y:662,t:1527613589460};\\\", \\\"{x:1486,y:661,t:1527613589516};\\\", \\\"{x:1484,y:660,t:1527613589524};\\\", \\\"{x:1484,y:658,t:1527613589537};\\\", \\\"{x:1483,y:657,t:1527613589554};\\\", \\\"{x:1483,y:654,t:1527613589569};\\\", \\\"{x:1482,y:653,t:1527613589692};\\\", \\\"{x:1480,y:655,t:1527613590148};\\\", \\\"{x:1480,y:658,t:1527613590156};\\\", \\\"{x:1479,y:661,t:1527613590171};\\\", \\\"{x:1476,y:668,t:1527613590187};\\\", \\\"{x:1473,y:680,t:1527613590204};\\\", \\\"{x:1473,y:683,t:1527613590221};\\\", \\\"{x:1473,y:686,t:1527613590237};\\\", \\\"{x:1473,y:688,t:1527613590259};\\\", \\\"{x:1473,y:689,t:1527613590371};\\\", \\\"{x:1475,y:691,t:1527613590387};\\\", \\\"{x:1475,y:694,t:1527613590404};\\\", \\\"{x:1475,y:698,t:1527613590421};\\\", \\\"{x:1476,y:704,t:1527613590438};\\\", \\\"{x:1476,y:712,t:1527613590454};\\\", \\\"{x:1476,y:720,t:1527613590471};\\\", \\\"{x:1476,y:732,t:1527613590488};\\\", \\\"{x:1470,y:742,t:1527613590504};\\\", \\\"{x:1465,y:751,t:1527613590520};\\\", \\\"{x:1455,y:763,t:1527613590537};\\\", \\\"{x:1448,y:770,t:1527613590553};\\\", \\\"{x:1443,y:777,t:1527613590570};\\\", \\\"{x:1440,y:779,t:1527613590588};\\\", \\\"{x:1440,y:780,t:1527613590708};\\\", \\\"{x:1438,y:780,t:1527613590723};\\\", \\\"{x:1434,y:779,t:1527613590739};\\\", \\\"{x:1432,y:779,t:1527613590754};\\\", \\\"{x:1423,y:775,t:1527613590770};\\\", \\\"{x:1410,y:770,t:1527613590787};\\\", \\\"{x:1402,y:770,t:1527613590804};\\\", \\\"{x:1392,y:770,t:1527613590821};\\\", \\\"{x:1385,y:769,t:1527613590838};\\\", \\\"{x:1381,y:769,t:1527613590855};\\\", \\\"{x:1378,y:767,t:1527613590871};\\\", \\\"{x:1377,y:767,t:1527613590888};\\\", \\\"{x:1377,y:766,t:1527613590904};\\\", \\\"{x:1376,y:765,t:1527613590996};\\\", \\\"{x:1376,y:764,t:1527613591092};\\\", \\\"{x:1376,y:761,t:1527613591115};\\\", \\\"{x:1376,y:760,t:1527613591123};\\\", \\\"{x:1376,y:758,t:1527613591139};\\\", \\\"{x:1378,y:756,t:1527613591155};\\\", \\\"{x:1379,y:756,t:1527613591492};\\\", \\\"{x:1380,y:756,t:1527613591667};\\\", \\\"{x:1381,y:756,t:1527613591826};\\\", \\\"{x:1383,y:756,t:1527613591858};\\\", \\\"{x:1384,y:756,t:1527613591964};\\\", \\\"{x:1384,y:757,t:1527613591995};\\\", \\\"{x:1385,y:757,t:1527613592028};\\\", \\\"{x:1387,y:757,t:1527613592236};\\\", \\\"{x:1388,y:757,t:1527613592251};\\\", \\\"{x:1390,y:758,t:1527613592259};\\\", \\\"{x:1392,y:758,t:1527613592272};\\\", \\\"{x:1394,y:759,t:1527613592288};\\\", \\\"{x:1395,y:760,t:1527613592305};\\\", \\\"{x:1396,y:760,t:1527613592323};\\\", \\\"{x:1397,y:760,t:1527613592476};\\\", \\\"{x:1399,y:760,t:1527613592556};\\\", \\\"{x:1400,y:760,t:1527613592588};\\\", \\\"{x:1403,y:760,t:1527613592605};\\\", \\\"{x:1412,y:761,t:1527613592622};\\\", \\\"{x:1426,y:764,t:1527613592639};\\\", \\\"{x:1435,y:770,t:1527613592656};\\\", \\\"{x:1453,y:772,t:1527613592672};\\\", \\\"{x:1475,y:777,t:1527613592689};\\\", \\\"{x:1493,y:778,t:1527613592706};\\\", \\\"{x:1518,y:781,t:1527613592724};\\\", \\\"{x:1526,y:781,t:1527613592739};\\\", \\\"{x:1540,y:781,t:1527613592755};\\\", \\\"{x:1545,y:781,t:1527613592773};\\\", \\\"{x:1548,y:780,t:1527613592789};\\\", \\\"{x:1546,y:780,t:1527613592860};\\\", \\\"{x:1537,y:780,t:1527613592873};\\\", \\\"{x:1523,y:780,t:1527613592889};\\\", \\\"{x:1503,y:780,t:1527613592905};\\\", \\\"{x:1462,y:780,t:1527613592922};\\\", \\\"{x:1445,y:777,t:1527613592939};\\\", \\\"{x:1402,y:773,t:1527613592955};\\\", \\\"{x:1357,y:762,t:1527613592972};\\\", \\\"{x:1316,y:751,t:1527613592988};\\\", \\\"{x:1261,y:745,t:1527613593005};\\\", \\\"{x:1207,y:737,t:1527613593022};\\\", \\\"{x:1168,y:730,t:1527613593038};\\\", \\\"{x:1125,y:724,t:1527613593055};\\\", \\\"{x:1091,y:719,t:1527613593072};\\\", \\\"{x:1040,y:713,t:1527613593088};\\\", \\\"{x:970,y:701,t:1527613593105};\\\", \\\"{x:881,y:676,t:1527613593122};\\\", \\\"{x:818,y:650,t:1527613593138};\\\", \\\"{x:753,y:627,t:1527613593155};\\\", \\\"{x:667,y:604,t:1527613593173};\\\", \\\"{x:583,y:577,t:1527613593190};\\\", \\\"{x:500,y:566,t:1527613593206};\\\", \\\"{x:469,y:560,t:1527613593222};\\\", \\\"{x:451,y:557,t:1527613593239};\\\", \\\"{x:450,y:557,t:1527613593248};\\\", \\\"{x:441,y:557,t:1527613593265};\\\", \\\"{x:440,y:557,t:1527613593283};\\\", \\\"{x:435,y:557,t:1527613593298};\\\", \\\"{x:431,y:557,t:1527613593315};\\\", \\\"{x:428,y:558,t:1527613593483};\\\", \\\"{x:427,y:562,t:1527613593499};\\\", \\\"{x:427,y:568,t:1527613593515};\\\", \\\"{x:428,y:575,t:1527613593534};\\\", \\\"{x:428,y:580,t:1527613593549};\\\", \\\"{x:428,y:586,t:1527613593573};\\\", \\\"{x:428,y:587,t:1527613593610};\\\", \\\"{x:428,y:588,t:1527613593623};\\\", \\\"{x:428,y:590,t:1527613593639};\\\", \\\"{x:427,y:591,t:1527613593656};\\\", \\\"{x:424,y:593,t:1527613593672};\\\", \\\"{x:423,y:595,t:1527613593689};\\\", \\\"{x:422,y:596,t:1527613593707};\\\", \\\"{x:417,y:597,t:1527613593723};\\\", \\\"{x:417,y:598,t:1527613593763};\\\", \\\"{x:412,y:598,t:1527613593773};\\\", \\\"{x:397,y:596,t:1527613593791};\\\", \\\"{x:389,y:594,t:1527613593807};\\\", \\\"{x:387,y:593,t:1527613593823};\\\", \\\"{x:384,y:591,t:1527613593840};\\\", \\\"{x:382,y:590,t:1527613593856};\\\", \\\"{x:381,y:590,t:1527613593873};\\\", \\\"{x:380,y:588,t:1527613593891};\\\", \\\"{x:380,y:586,t:1527613593971};\\\", \\\"{x:380,y:585,t:1527613593978};\\\", \\\"{x:382,y:582,t:1527613593991};\\\", \\\"{x:388,y:576,t:1527613594007};\\\", \\\"{x:390,y:571,t:1527613594024};\\\", \\\"{x:393,y:563,t:1527613594040};\\\", \\\"{x:396,y:560,t:1527613594056};\\\", \\\"{x:397,y:557,t:1527613594073};\\\", \\\"{x:398,y:557,t:1527613594299};\\\", \\\"{x:399,y:557,t:1527613594306};\\\", \\\"{x:399,y:557,t:1527613594367};\\\", \\\"{x:409,y:557,t:1527613594611};\\\", \\\"{x:420,y:553,t:1527613594623};\\\", \\\"{x:446,y:553,t:1527613594641};\\\", \\\"{x:491,y:553,t:1527613594657};\\\", \\\"{x:520,y:553,t:1527613594674};\\\", \\\"{x:563,y:556,t:1527613594691};\\\", \\\"{x:579,y:557,t:1527613594707};\\\", \\\"{x:595,y:559,t:1527613594724};\\\", \\\"{x:605,y:562,t:1527613594741};\\\", \\\"{x:615,y:564,t:1527613594757};\\\", \\\"{x:631,y:566,t:1527613594774};\\\", \\\"{x:650,y:566,t:1527613594791};\\\", \\\"{x:672,y:566,t:1527613594807};\\\", \\\"{x:700,y:566,t:1527613594824};\\\", \\\"{x:773,y:565,t:1527613594841};\\\", \\\"{x:879,y:565,t:1527613594857};\\\", \\\"{x:979,y:566,t:1527613594874};\\\", \\\"{x:1138,y:588,t:1527613594890};\\\", \\\"{x:1254,y:602,t:1527613594908};\\\", \\\"{x:1357,y:618,t:1527613594924};\\\", \\\"{x:1451,y:628,t:1527613594941};\\\", \\\"{x:1509,y:634,t:1527613594957};\\\", \\\"{x:1544,y:640,t:1527613594975};\\\", \\\"{x:1563,y:642,t:1527613594991};\\\", \\\"{x:1575,y:643,t:1527613595007};\\\", \\\"{x:1577,y:643,t:1527613595025};\\\", \\\"{x:1579,y:643,t:1527613595041};\\\", \\\"{x:1580,y:643,t:1527613595204};\\\", \\\"{x:1580,y:644,t:1527613595211};\\\", \\\"{x:1579,y:645,t:1527613595225};\\\", \\\"{x:1579,y:646,t:1527613595242};\\\", \\\"{x:1577,y:646,t:1527613595291};\\\", \\\"{x:1576,y:646,t:1527613595315};\\\", \\\"{x:1576,y:647,t:1527613595331};\\\", \\\"{x:1575,y:647,t:1527613595347};\\\", \\\"{x:1575,y:648,t:1527613595467};\\\", \\\"{x:1575,y:649,t:1527613595476};\\\", \\\"{x:1568,y:649,t:1527613595492};\\\", \\\"{x:1552,y:647,t:1527613595509};\\\", \\\"{x:1532,y:645,t:1527613595525};\\\", \\\"{x:1514,y:641,t:1527613595542};\\\", \\\"{x:1495,y:639,t:1527613595559};\\\", \\\"{x:1481,y:634,t:1527613595575};\\\", \\\"{x:1472,y:631,t:1527613595592};\\\", \\\"{x:1466,y:629,t:1527613595609};\\\", \\\"{x:1462,y:628,t:1527613595625};\\\", \\\"{x:1460,y:628,t:1527613595642};\\\", \\\"{x:1459,y:628,t:1527613596020};\\\", \\\"{x:1458,y:628,t:1527613596028};\\\", \\\"{x:1457,y:628,t:1527613596043};\\\", \\\"{x:1453,y:629,t:1527613596059};\\\", \\\"{x:1449,y:631,t:1527613596076};\\\", \\\"{x:1436,y:632,t:1527613596093};\\\", \\\"{x:1422,y:632,t:1527613596109};\\\", \\\"{x:1405,y:632,t:1527613596126};\\\", \\\"{x:1384,y:632,t:1527613596144};\\\", \\\"{x:1362,y:632,t:1527613596159};\\\", \\\"{x:1354,y:631,t:1527613596176};\\\", \\\"{x:1339,y:631,t:1527613596193};\\\", \\\"{x:1321,y:631,t:1527613596209};\\\", \\\"{x:1315,y:631,t:1527613596227};\\\", \\\"{x:1296,y:631,t:1527613596244};\\\", \\\"{x:1287,y:632,t:1527613596259};\\\", \\\"{x:1286,y:632,t:1527613596276};\\\", \\\"{x:1283,y:633,t:1527613596293};\\\", \\\"{x:1283,y:634,t:1527613596309};\\\", \\\"{x:1282,y:636,t:1527613596326};\\\", \\\"{x:1281,y:638,t:1527613596343};\\\", \\\"{x:1281,y:641,t:1527613596359};\\\", \\\"{x:1281,y:642,t:1527613596747};\\\", \\\"{x:1284,y:640,t:1527613596760};\\\", \\\"{x:1291,y:639,t:1527613596777};\\\", \\\"{x:1298,y:637,t:1527613596793};\\\", \\\"{x:1300,y:636,t:1527613596810};\\\", \\\"{x:1303,y:635,t:1527613596827};\\\", \\\"{x:1309,y:632,t:1527613596844};\\\", \\\"{x:1310,y:632,t:1527613596860};\\\", \\\"{x:1313,y:632,t:1527613596877};\\\", \\\"{x:1314,y:632,t:1527613596893};\\\", \\\"{x:1321,y:631,t:1527613596911};\\\", \\\"{x:1327,y:631,t:1527613596927};\\\", \\\"{x:1333,y:631,t:1527613596943};\\\", \\\"{x:1337,y:631,t:1527613596960};\\\", \\\"{x:1340,y:631,t:1527613596977};\\\", \\\"{x:1341,y:630,t:1527613596993};\\\", \\\"{x:1342,y:630,t:1527613597010};\\\", \\\"{x:1347,y:629,t:1527613597027};\\\", \\\"{x:1349,y:629,t:1527613597043};\\\", \\\"{x:1351,y:628,t:1527613597060};\\\", \\\"{x:1352,y:627,t:1527613597077};\\\", \\\"{x:1353,y:627,t:1527613597148};\\\", \\\"{x:1355,y:627,t:1527613597171};\\\", \\\"{x:1358,y:626,t:1527613597179};\\\", \\\"{x:1360,y:626,t:1527613597195};\\\", \\\"{x:1361,y:625,t:1527613597210};\\\", \\\"{x:1362,y:625,t:1527613597276};\\\", \\\"{x:1368,y:625,t:1527613597295};\\\", \\\"{x:1372,y:625,t:1527613597310};\\\", \\\"{x:1374,y:625,t:1527613597327};\\\", \\\"{x:1375,y:625,t:1527613597468};\\\", \\\"{x:1376,y:625,t:1527613597515};\\\", \\\"{x:1377,y:625,t:1527613597571};\\\", \\\"{x:1379,y:625,t:1527613597708};\\\", \\\"{x:1385,y:625,t:1527613597715};\\\", \\\"{x:1394,y:625,t:1527613597728};\\\", \\\"{x:1416,y:627,t:1527613597744};\\\", \\\"{x:1434,y:627,t:1527613597761};\\\", \\\"{x:1449,y:628,t:1527613597778};\\\", \\\"{x:1453,y:629,t:1527613597794};\\\", \\\"{x:1454,y:629,t:1527613597811};\\\", \\\"{x:1456,y:629,t:1527613597836};\\\", \\\"{x:1457,y:629,t:1527613597844};\\\", \\\"{x:1461,y:628,t:1527613597861};\\\", \\\"{x:1464,y:627,t:1527613597878};\\\", \\\"{x:1465,y:627,t:1527613597895};\\\", \\\"{x:1464,y:627,t:1527613598082};\\\", \\\"{x:1463,y:627,t:1527613598094};\\\", \\\"{x:1460,y:628,t:1527613598110};\\\", \\\"{x:1460,y:629,t:1527613598127};\\\", \\\"{x:1459,y:629,t:1527613598145};\\\", \\\"{x:1458,y:629,t:1527613598161};\\\", \\\"{x:1458,y:630,t:1527613598268};\\\", \\\"{x:1457,y:630,t:1527613598291};\\\", \\\"{x:1457,y:631,t:1527613598332};\\\", \\\"{x:1458,y:632,t:1527613598547};\\\", \\\"{x:1465,y:632,t:1527613598562};\\\", \\\"{x:1482,y:632,t:1527613598578};\\\", \\\"{x:1497,y:632,t:1527613598595};\\\", \\\"{x:1500,y:632,t:1527613598613};\\\", \\\"{x:1503,y:632,t:1527613598844};\\\", \\\"{x:1504,y:632,t:1527613598851};\\\", \\\"{x:1506,y:632,t:1527613598867};\\\", \\\"{x:1507,y:632,t:1527613598891};\\\", \\\"{x:1507,y:631,t:1527613599003};\\\", \\\"{x:1509,y:629,t:1527613599620};\\\", \\\"{x:1511,y:627,t:1527613599630};\\\", \\\"{x:1516,y:627,t:1527613599645};\\\", \\\"{x:1520,y:626,t:1527613599664};\\\", \\\"{x:1521,y:626,t:1527613599680};\\\", \\\"{x:1523,y:624,t:1527613599696};\\\", \\\"{x:1524,y:624,t:1527613599713};\\\", \\\"{x:1525,y:624,t:1527613599730};\\\", \\\"{x:1526,y:624,t:1527613599747};\\\", \\\"{x:1530,y:623,t:1527613599763};\\\", \\\"{x:1535,y:623,t:1527613599779};\\\", \\\"{x:1542,y:620,t:1527613599797};\\\", \\\"{x:1546,y:620,t:1527613599813};\\\", \\\"{x:1549,y:619,t:1527613599830};\\\", \\\"{x:1550,y:619,t:1527613599847};\\\", \\\"{x:1551,y:619,t:1527613599863};\\\", \\\"{x:1553,y:618,t:1527613599880};\\\", \\\"{x:1556,y:617,t:1527613599899};\\\", \\\"{x:1560,y:617,t:1527613599913};\\\", \\\"{x:1578,y:618,t:1527613599930};\\\", \\\"{x:1638,y:636,t:1527613599947};\\\", \\\"{x:1664,y:643,t:1527613599963};\\\", \\\"{x:1689,y:649,t:1527613599980};\\\", \\\"{x:1700,y:650,t:1527613599997};\\\", \\\"{x:1701,y:650,t:1527613600014};\\\", \\\"{x:1701,y:651,t:1527613600587};\\\", \\\"{x:1701,y:653,t:1527613600716};\\\", \\\"{x:1701,y:655,t:1527613600731};\\\", \\\"{x:1698,y:655,t:1527613600747};\\\", \\\"{x:1692,y:655,t:1527613600764};\\\", \\\"{x:1680,y:655,t:1527613600781};\\\", \\\"{x:1673,y:655,t:1527613600798};\\\", \\\"{x:1666,y:653,t:1527613600814};\\\", \\\"{x:1660,y:650,t:1527613600831};\\\", \\\"{x:1658,y:650,t:1527613600848};\\\", \\\"{x:1657,y:650,t:1527613600891};\\\", \\\"{x:1655,y:649,t:1527613600899};\\\", \\\"{x:1653,y:649,t:1527613600914};\\\", \\\"{x:1652,y:649,t:1527613600938};\\\", \\\"{x:1651,y:649,t:1527613600970};\\\", \\\"{x:1648,y:648,t:1527613601019};\\\", \\\"{x:1647,y:648,t:1527613601132};\\\", \\\"{x:1646,y:648,t:1527613601148};\\\", \\\"{x:1645,y:648,t:1527613601179};\\\", \\\"{x:1644,y:648,t:1527613601195};\\\", \\\"{x:1643,y:648,t:1527613601227};\\\", \\\"{x:1642,y:648,t:1527613601235};\\\", \\\"{x:1641,y:648,t:1527613601372};\\\", \\\"{x:1641,y:649,t:1527613601381};\\\", \\\"{x:1638,y:651,t:1527613601398};\\\", \\\"{x:1635,y:654,t:1527613601415};\\\", \\\"{x:1632,y:655,t:1527613601432};\\\", \\\"{x:1630,y:657,t:1527613601448};\\\", \\\"{x:1626,y:658,t:1527613601465};\\\", \\\"{x:1623,y:661,t:1527613601482};\\\", \\\"{x:1619,y:665,t:1527613601499};\\\", \\\"{x:1612,y:673,t:1527613601516};\\\", \\\"{x:1602,y:685,t:1527613601532};\\\", \\\"{x:1593,y:695,t:1527613601549};\\\", \\\"{x:1586,y:703,t:1527613601565};\\\", \\\"{x:1582,y:708,t:1527613601582};\\\", \\\"{x:1581,y:709,t:1527613601599};\\\", \\\"{x:1581,y:707,t:1527613602084};\\\", \\\"{x:1575,y:689,t:1527613602099};\\\", \\\"{x:1567,y:672,t:1527613602115};\\\", \\\"{x:1555,y:654,t:1527613602132};\\\", \\\"{x:1546,y:638,t:1527613602149};\\\", \\\"{x:1538,y:622,t:1527613602166};\\\", \\\"{x:1532,y:608,t:1527613602183};\\\", \\\"{x:1528,y:598,t:1527613602200};\\\", \\\"{x:1525,y:590,t:1527613602216};\\\", \\\"{x:1520,y:578,t:1527613602233};\\\", \\\"{x:1515,y:565,t:1527613602249};\\\", \\\"{x:1504,y:545,t:1527613602267};\\\", \\\"{x:1489,y:517,t:1527613602282};\\\", \\\"{x:1465,y:493,t:1527613602300};\\\", \\\"{x:1452,y:483,t:1527613602316};\\\", \\\"{x:1441,y:477,t:1527613602333};\\\", \\\"{x:1434,y:472,t:1527613602349};\\\", \\\"{x:1427,y:469,t:1527613602366};\\\", \\\"{x:1419,y:467,t:1527613602384};\\\", \\\"{x:1413,y:465,t:1527613602399};\\\", \\\"{x:1411,y:464,t:1527613602416};\\\", \\\"{x:1409,y:464,t:1527613602433};\\\", \\\"{x:1408,y:464,t:1527613602451};\\\", \\\"{x:1403,y:464,t:1527613602467};\\\", \\\"{x:1397,y:466,t:1527613602483};\\\", \\\"{x:1387,y:470,t:1527613602499};\\\", \\\"{x:1374,y:471,t:1527613602516};\\\", \\\"{x:1362,y:475,t:1527613602533};\\\", \\\"{x:1351,y:476,t:1527613602549};\\\", \\\"{x:1339,y:481,t:1527613602566};\\\", \\\"{x:1331,y:485,t:1527613602583};\\\", \\\"{x:1327,y:489,t:1527613602599};\\\", \\\"{x:1323,y:493,t:1527613602616};\\\", \\\"{x:1321,y:495,t:1527613602633};\\\", \\\"{x:1319,y:496,t:1527613602724};\\\", \\\"{x:1321,y:496,t:1527613604780};\\\", \\\"{x:1333,y:499,t:1527613604788};\\\", \\\"{x:1339,y:502,t:1527613604802};\\\", \\\"{x:1362,y:510,t:1527613604818};\\\", \\\"{x:1387,y:516,t:1527613604836};\\\", \\\"{x:1394,y:517,t:1527613604852};\\\", \\\"{x:1395,y:517,t:1527613604870};\\\", \\\"{x:1396,y:517,t:1527613605091};\\\", \\\"{x:1398,y:517,t:1527613605102};\\\", \\\"{x:1400,y:516,t:1527613605119};\\\", \\\"{x:1402,y:514,t:1527613605135};\\\", \\\"{x:1403,y:511,t:1527613605152};\\\", \\\"{x:1404,y:509,t:1527613605170};\\\", \\\"{x:1405,y:507,t:1527613605187};\\\", \\\"{x:1405,y:506,t:1527613605202};\\\", \\\"{x:1406,y:505,t:1527613605219};\\\", \\\"{x:1407,y:504,t:1527613605237};\\\", \\\"{x:1408,y:503,t:1527613605252};\\\", \\\"{x:1409,y:502,t:1527613605275};\\\", \\\"{x:1410,y:501,t:1527613605299};\\\", \\\"{x:1410,y:500,t:1527613605315};\\\", \\\"{x:1411,y:499,t:1527613605323};\\\", \\\"{x:1411,y:498,t:1527613605339};\\\", \\\"{x:1413,y:498,t:1527613605353};\\\", \\\"{x:1414,y:497,t:1527613605369};\\\", \\\"{x:1414,y:496,t:1527613605387};\\\", \\\"{x:1417,y:495,t:1527613605402};\\\", \\\"{x:1421,y:495,t:1527613605419};\\\", \\\"{x:1428,y:495,t:1527613605437};\\\", \\\"{x:1438,y:494,t:1527613605452};\\\", \\\"{x:1447,y:493,t:1527613605469};\\\", \\\"{x:1454,y:492,t:1527613605486};\\\", \\\"{x:1456,y:491,t:1527613605502};\\\", \\\"{x:1457,y:490,t:1527613605519};\\\", \\\"{x:1458,y:490,t:1527613605563};\\\", \\\"{x:1460,y:490,t:1527613605755};\\\", \\\"{x:1466,y:492,t:1527613605769};\\\", \\\"{x:1471,y:493,t:1527613605786};\\\", \\\"{x:1492,y:500,t:1527613605803};\\\", \\\"{x:1506,y:503,t:1527613605820};\\\", \\\"{x:1515,y:506,t:1527613605836};\\\", \\\"{x:1520,y:508,t:1527613605853};\\\", \\\"{x:1522,y:509,t:1527613605870};\\\", \\\"{x:1524,y:509,t:1527613606083};\\\", \\\"{x:1528,y:506,t:1527613606091};\\\", \\\"{x:1530,y:506,t:1527613606104};\\\", \\\"{x:1534,y:504,t:1527613606120};\\\", \\\"{x:1539,y:502,t:1527613606137};\\\", \\\"{x:1541,y:501,t:1527613606153};\\\", \\\"{x:1542,y:500,t:1527613606171};\\\", \\\"{x:1548,y:498,t:1527613606187};\\\", \\\"{x:1541,y:498,t:1527613606267};\\\", \\\"{x:1519,y:498,t:1527613606275};\\\", \\\"{x:1468,y:492,t:1527613606288};\\\", \\\"{x:1303,y:479,t:1527613606303};\\\", \\\"{x:1112,y:475,t:1527613606321};\\\", \\\"{x:943,y:498,t:1527613606338};\\\", \\\"{x:762,y:536,t:1527613606355};\\\", \\\"{x:585,y:561,t:1527613606370};\\\", \\\"{x:395,y:595,t:1527613606387};\\\", \\\"{x:350,y:617,t:1527613606411};\\\", \\\"{x:352,y:616,t:1527613606618};\\\", \\\"{x:358,y:612,t:1527613606635};\\\", \\\"{x:366,y:612,t:1527613606649};\\\", \\\"{x:390,y:612,t:1527613606667};\\\", \\\"{x:415,y:620,t:1527613606684};\\\", \\\"{x:438,y:627,t:1527613606701};\\\", \\\"{x:455,y:635,t:1527613606717};\\\", \\\"{x:470,y:645,t:1527613606733};\\\", \\\"{x:484,y:656,t:1527613606751};\\\", \\\"{x:491,y:665,t:1527613606767};\\\", \\\"{x:501,y:682,t:1527613606784};\\\", \\\"{x:504,y:698,t:1527613606800};\\\", \\\"{x:506,y:716,t:1527613606817};\\\", \\\"{x:506,y:731,t:1527613606833};\\\", \\\"{x:506,y:741,t:1527613606850};\\\", \\\"{x:506,y:743,t:1527613606867};\\\", \\\"{x:507,y:739,t:1527613607075};\\\", \\\"{x:507,y:737,t:1527613607084};\\\", \\\"{x:510,y:731,t:1527613607102};\\\", \\\"{x:514,y:722,t:1527613607118};\\\", \\\"{x:516,y:713,t:1527613607133};\\\", \\\"{x:517,y:712,t:1527613607151};\\\", \\\"{x:518,y:709,t:1527613607167};\\\", \\\"{x:518,y:706,t:1527613607185};\\\", \\\"{x:521,y:703,t:1527613607843};\\\", \\\"{x:521,y:700,t:1527613607852};\\\", \\\"{x:526,y:694,t:1527613607868};\\\", \\\"{x:527,y:691,t:1527613607885};\\\", \\\"{x:528,y:690,t:1527613607902};\\\", \\\"{x:530,y:688,t:1527613607918};\\\", \\\"{x:530,y:687,t:1527613607935};\\\", \\\"{x:532,y:686,t:1527613607952};\\\", \\\"{x:532,y:685,t:1527613607968};\\\", \\\"{x:532,y:684,t:1527613607987};\\\", \\\"{x:532,y:683,t:1527613608139};\\\", \\\"{x:533,y:682,t:1527613608154};\\\" ] }, { \\\"rt\\\": 58831, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 9, \\\"time_elapsed\\\": 341265, \\\"internal_node_id\\\": \\\"0.0-5.0-4.0\\\", \\\"subject\\\": \\\"AZKMW\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"oscar\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 5, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"U\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-I -O -I \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:537,y:675,t:1527613612756};\\\", \\\"{x:559,y:655,t:1527613612774};\\\", \\\"{x:583,y:636,t:1527613612788};\\\", \\\"{x:599,y:623,t:1527613612805};\\\", \\\"{x:617,y:609,t:1527613612822};\\\", \\\"{x:629,y:601,t:1527613612839};\\\", \\\"{x:645,y:593,t:1527613612855};\\\", \\\"{x:666,y:586,t:1527613612873};\\\", \\\"{x:689,y:579,t:1527613612888};\\\", \\\"{x:711,y:570,t:1527613612905};\\\", \\\"{x:736,y:564,t:1527613612923};\\\", \\\"{x:745,y:559,t:1527613612938};\\\", \\\"{x:759,y:556,t:1527613612955};\\\", \\\"{x:774,y:553,t:1527613612972};\\\", \\\"{x:792,y:548,t:1527613612989};\\\", \\\"{x:818,y:536,t:1527613613004};\\\", \\\"{x:858,y:523,t:1527613613022};\\\", \\\"{x:885,y:513,t:1527613613039};\\\", \\\"{x:911,y:506,t:1527613613056};\\\", \\\"{x:940,y:495,t:1527613613072};\\\", \\\"{x:952,y:491,t:1527613613089};\\\", \\\"{x:954,y:489,t:1527613613106};\\\", \\\"{x:957,y:484,t:1527613613826};\\\", \\\"{x:977,y:478,t:1527613613839};\\\", \\\"{x:1046,y:476,t:1527613613856};\\\", \\\"{x:1164,y:489,t:1527613613872};\\\", \\\"{x:1304,y:499,t:1527613613889};\\\", \\\"{x:1585,y:519,t:1527613613905};\\\", \\\"{x:1773,y:518,t:1527613613923};\\\", \\\"{x:1919,y:518,t:1527613613940};\\\", \\\"{x:1918,y:518,t:1527613614050};\\\", \\\"{x:1917,y:518,t:1527613614065};\\\", \\\"{x:1915,y:519,t:1527613614073};\\\", \\\"{x:1908,y:519,t:1527613614089};\\\", \\\"{x:1890,y:519,t:1527613614105};\\\", \\\"{x:1859,y:519,t:1527613614122};\\\", \\\"{x:1840,y:517,t:1527613614139};\\\", \\\"{x:1817,y:515,t:1527613614156};\\\", \\\"{x:1784,y:510,t:1527613614172};\\\", \\\"{x:1748,y:507,t:1527613614190};\\\", \\\"{x:1676,y:507,t:1527613614206};\\\", \\\"{x:1620,y:507,t:1527613614223};\\\", \\\"{x:1573,y:512,t:1527613614239};\\\", \\\"{x:1550,y:515,t:1527613614256};\\\", \\\"{x:1535,y:518,t:1527613614273};\\\", \\\"{x:1518,y:521,t:1527613614289};\\\", \\\"{x:1509,y:523,t:1527613614306};\\\", \\\"{x:1499,y:528,t:1527613614322};\\\", \\\"{x:1491,y:529,t:1527613614340};\\\", \\\"{x:1489,y:530,t:1527613614356};\\\", \\\"{x:1488,y:530,t:1527613614442};\\\", \\\"{x:1485,y:530,t:1527613614456};\\\", \\\"{x:1467,y:530,t:1527613614473};\\\", \\\"{x:1435,y:524,t:1527613614489};\\\", \\\"{x:1420,y:523,t:1527613614507};\\\", \\\"{x:1402,y:523,t:1527613614523};\\\", \\\"{x:1375,y:520,t:1527613614540};\\\", \\\"{x:1352,y:519,t:1527613614557};\\\", \\\"{x:1340,y:515,t:1527613614573};\\\", \\\"{x:1328,y:513,t:1527613614590};\\\", \\\"{x:1324,y:510,t:1527613614607};\\\", \\\"{x:1322,y:509,t:1527613614623};\\\", \\\"{x:1321,y:508,t:1527613614657};\\\", \\\"{x:1321,y:507,t:1527613615106};\\\", \\\"{x:1321,y:505,t:1527613615178};\\\", \\\"{x:1321,y:504,t:1527613615190};\\\", \\\"{x:1325,y:500,t:1527613615207};\\\", \\\"{x:1330,y:499,t:1527613615224};\\\", \\\"{x:1332,y:497,t:1527613615240};\\\", \\\"{x:1333,y:495,t:1527613615266};\\\", \\\"{x:1334,y:495,t:1527613615467};\\\", \\\"{x:1336,y:495,t:1527613615572};\\\", \\\"{x:1337,y:495,t:1527613615579};\\\", \\\"{x:1341,y:495,t:1527613615591};\\\", \\\"{x:1349,y:495,t:1527613615608};\\\", \\\"{x:1352,y:495,t:1527613615625};\\\", \\\"{x:1359,y:495,t:1527613615641};\\\", \\\"{x:1363,y:495,t:1527613615658};\\\", \\\"{x:1365,y:496,t:1527613615987};\\\", \\\"{x:1366,y:496,t:1527613615995};\\\", \\\"{x:1368,y:497,t:1527613616011};\\\", \\\"{x:1370,y:498,t:1527613616025};\\\", \\\"{x:1375,y:502,t:1527613616042};\\\", \\\"{x:1397,y:516,t:1527613616059};\\\", \\\"{x:1401,y:517,t:1527613616074};\\\", \\\"{x:1402,y:519,t:1527613616091};\\\", \\\"{x:1403,y:519,t:1527613616108};\\\", \\\"{x:1404,y:519,t:1527613616130};\\\", \\\"{x:1404,y:517,t:1527613616355};\\\", \\\"{x:1404,y:516,t:1527613616363};\\\", \\\"{x:1404,y:515,t:1527613616375};\\\", \\\"{x:1404,y:513,t:1527613616392};\\\", \\\"{x:1404,y:512,t:1527613616409};\\\", \\\"{x:1405,y:511,t:1527613616425};\\\", \\\"{x:1405,y:508,t:1527613616442};\\\", \\\"{x:1405,y:504,t:1527613616459};\\\", \\\"{x:1405,y:502,t:1527613616474};\\\", \\\"{x:1405,y:501,t:1527613616491};\\\", \\\"{x:1405,y:500,t:1527613616643};\\\", \\\"{x:1405,y:499,t:1527613616659};\\\", \\\"{x:1404,y:499,t:1527613616940};\\\", \\\"{x:1399,y:500,t:1527613616947};\\\", \\\"{x:1395,y:502,t:1527613616959};\\\", \\\"{x:1386,y:506,t:1527613616975};\\\", \\\"{x:1377,y:511,t:1527613616993};\\\", \\\"{x:1366,y:511,t:1527613617009};\\\", \\\"{x:1358,y:511,t:1527613617025};\\\", \\\"{x:1352,y:511,t:1527613617042};\\\", \\\"{x:1349,y:509,t:1527613617059};\\\", \\\"{x:1348,y:509,t:1527613617083};\\\", \\\"{x:1347,y:508,t:1527613617180};\\\", \\\"{x:1346,y:508,t:1527613617192};\\\", \\\"{x:1345,y:507,t:1527613617208};\\\", \\\"{x:1344,y:506,t:1527613617225};\\\", \\\"{x:1344,y:504,t:1527613617243};\\\", \\\"{x:1343,y:503,t:1527613617291};\\\", \\\"{x:1341,y:503,t:1527613617298};\\\", \\\"{x:1340,y:503,t:1527613617363};\\\", \\\"{x:1339,y:503,t:1527613617376};\\\", \\\"{x:1337,y:503,t:1527613617393};\\\", \\\"{x:1328,y:501,t:1527613617410};\\\", \\\"{x:1323,y:501,t:1527613617426};\\\", \\\"{x:1318,y:500,t:1527613617445};\\\", \\\"{x:1315,y:500,t:1527613617459};\\\", \\\"{x:1316,y:500,t:1527613617955};\\\", \\\"{x:1323,y:500,t:1527613617964};\\\", \\\"{x:1324,y:500,t:1527613617976};\\\", \\\"{x:1336,y:499,t:1527613617993};\\\", \\\"{x:1360,y:499,t:1527613618010};\\\", \\\"{x:1393,y:497,t:1527613618026};\\\", \\\"{x:1407,y:497,t:1527613618043};\\\", \\\"{x:1435,y:495,t:1527613618060};\\\", \\\"{x:1462,y:495,t:1527613618077};\\\", \\\"{x:1483,y:496,t:1527613618092};\\\", \\\"{x:1496,y:498,t:1527613618109};\\\", \\\"{x:1510,y:498,t:1527613618126};\\\", \\\"{x:1520,y:498,t:1527613618142};\\\", \\\"{x:1527,y:498,t:1527613618159};\\\", \\\"{x:1530,y:498,t:1527613618177};\\\", \\\"{x:1533,y:498,t:1527613618192};\\\", \\\"{x:1536,y:498,t:1527613618210};\\\", \\\"{x:1541,y:497,t:1527613618226};\\\", \\\"{x:1553,y:495,t:1527613618242};\\\", \\\"{x:1568,y:494,t:1527613618260};\\\", \\\"{x:1587,y:491,t:1527613618277};\\\", \\\"{x:1599,y:489,t:1527613618293};\\\", \\\"{x:1611,y:486,t:1527613618309};\\\", \\\"{x:1618,y:483,t:1527613618327};\\\", \\\"{x:1619,y:483,t:1527613618344};\\\", \\\"{x:1621,y:482,t:1527613618360};\\\", \\\"{x:1623,y:482,t:1527613618437};\\\", \\\"{x:1624,y:482,t:1527613618466};\\\", \\\"{x:1625,y:482,t:1527613618482};\\\", \\\"{x:1628,y:483,t:1527613618827};\\\", \\\"{x:1633,y:487,t:1527613618843};\\\", \\\"{x:1634,y:488,t:1527613618860};\\\", \\\"{x:1636,y:492,t:1527613618877};\\\", \\\"{x:1637,y:494,t:1527613618894};\\\", \\\"{x:1638,y:495,t:1527613618910};\\\", \\\"{x:1639,y:497,t:1527613618927};\\\", \\\"{x:1640,y:499,t:1527613618947};\\\", \\\"{x:1642,y:500,t:1527613618963};\\\", \\\"{x:1643,y:500,t:1527613618977};\\\", \\\"{x:1646,y:500,t:1527613618994};\\\", \\\"{x:1647,y:501,t:1527613619011};\\\", \\\"{x:1649,y:502,t:1527613619035};\\\", \\\"{x:1649,y:503,t:1527613619059};\\\", \\\"{x:1650,y:503,t:1527613619107};\\\", \\\"{x:1650,y:504,t:1527613619147};\\\", \\\"{x:1650,y:506,t:1527613619163};\\\", \\\"{x:1650,y:507,t:1527613619179};\\\", \\\"{x:1650,y:508,t:1527613619193};\\\", \\\"{x:1653,y:509,t:1527613619210};\\\", \\\"{x:1653,y:510,t:1527613619242};\\\", \\\"{x:1653,y:509,t:1527613623226};\\\", \\\"{x:1653,y:508,t:1527613623251};\\\", \\\"{x:1652,y:506,t:1527613623267};\\\", \\\"{x:1652,y:504,t:1527613623291};\\\", \\\"{x:1652,y:503,t:1527613623315};\\\", \\\"{x:1652,y:502,t:1527613623330};\\\", \\\"{x:1652,y:501,t:1527613623347};\\\", \\\"{x:1652,y:500,t:1527613623364};\\\", \\\"{x:1651,y:500,t:1527613623403};\\\", \\\"{x:1650,y:498,t:1527613623413};\\\", \\\"{x:1650,y:497,t:1527613623499};\\\", \\\"{x:1650,y:496,t:1527613623514};\\\", \\\"{x:1649,y:495,t:1527613623531};\\\", \\\"{x:1649,y:494,t:1527613625178};\\\", \\\"{x:1646,y:494,t:1527613625186};\\\", \\\"{x:1641,y:496,t:1527613625197};\\\", \\\"{x:1634,y:499,t:1527613625214};\\\", \\\"{x:1623,y:504,t:1527613625231};\\\", \\\"{x:1608,y:513,t:1527613625247};\\\", \\\"{x:1592,y:522,t:1527613625264};\\\", \\\"{x:1580,y:526,t:1527613625281};\\\", \\\"{x:1579,y:526,t:1527613625302};\\\", \\\"{x:1575,y:525,t:1527613625318};\\\", \\\"{x:1574,y:525,t:1527613625336};\\\", \\\"{x:1573,y:524,t:1527613625366};\\\", \\\"{x:1566,y:523,t:1527613625374};\\\", \\\"{x:1562,y:523,t:1527613625386};\\\", \\\"{x:1556,y:522,t:1527613625402};\\\", \\\"{x:1551,y:522,t:1527613625418};\\\", \\\"{x:1541,y:522,t:1527613625436};\\\", \\\"{x:1535,y:522,t:1527613625453};\\\", \\\"{x:1521,y:519,t:1527613625469};\\\", \\\"{x:1500,y:509,t:1527613625486};\\\", \\\"{x:1451,y:488,t:1527613625503};\\\", \\\"{x:1432,y:479,t:1527613625519};\\\", \\\"{x:1418,y:474,t:1527613625536};\\\", \\\"{x:1410,y:471,t:1527613625553};\\\", \\\"{x:1409,y:470,t:1527613625569};\\\", \\\"{x:1407,y:470,t:1527613625631};\\\", \\\"{x:1406,y:471,t:1527613625646};\\\", \\\"{x:1405,y:471,t:1527613625671};\\\", \\\"{x:1405,y:472,t:1527613625686};\\\", \\\"{x:1405,y:473,t:1527613625743};\\\", \\\"{x:1405,y:474,t:1527613625767};\\\", \\\"{x:1405,y:475,t:1527613625782};\\\", \\\"{x:1402,y:478,t:1527613625790};\\\", \\\"{x:1402,y:479,t:1527613625803};\\\", \\\"{x:1400,y:485,t:1527613625819};\\\", \\\"{x:1399,y:489,t:1527613625836};\\\", \\\"{x:1399,y:492,t:1527613625853};\\\", \\\"{x:1398,y:495,t:1527613625870};\\\", \\\"{x:1395,y:496,t:1527613625886};\\\", \\\"{x:1392,y:499,t:1527613625903};\\\", \\\"{x:1391,y:500,t:1527613625927};\\\", \\\"{x:1391,y:501,t:1527613625936};\\\", \\\"{x:1389,y:502,t:1527613625953};\\\", \\\"{x:1388,y:503,t:1527613625974};\\\", \\\"{x:1385,y:503,t:1527613625998};\\\", \\\"{x:1384,y:503,t:1527613626007};\\\", \\\"{x:1382,y:505,t:1527613626023};\\\", \\\"{x:1381,y:505,t:1527613626036};\\\", \\\"{x:1381,y:506,t:1527613626053};\\\", \\\"{x:1379,y:506,t:1527613626069};\\\", \\\"{x:1378,y:506,t:1527613626086};\\\", \\\"{x:1374,y:506,t:1527613626103};\\\", \\\"{x:1373,y:506,t:1527613626120};\\\", \\\"{x:1372,y:507,t:1527613626423};\\\", \\\"{x:1362,y:514,t:1527613626438};\\\", \\\"{x:1342,y:525,t:1527613626453};\\\", \\\"{x:1318,y:532,t:1527613626470};\\\", \\\"{x:1288,y:532,t:1527613626486};\\\", \\\"{x:1270,y:532,t:1527613626502};\\\", \\\"{x:1255,y:532,t:1527613626520};\\\", \\\"{x:1240,y:532,t:1527613626537};\\\", \\\"{x:1231,y:532,t:1527613626553};\\\", \\\"{x:1230,y:532,t:1527613626569};\\\", \\\"{x:1232,y:532,t:1527613626679};\\\", \\\"{x:1233,y:532,t:1527613626687};\\\", \\\"{x:1242,y:530,t:1527613626703};\\\", \\\"{x:1257,y:530,t:1527613626720};\\\", \\\"{x:1268,y:528,t:1527613626737};\\\", \\\"{x:1277,y:528,t:1527613626753};\\\", \\\"{x:1281,y:528,t:1527613626770};\\\", \\\"{x:1285,y:528,t:1527613626787};\\\", \\\"{x:1286,y:529,t:1527613626803};\\\", \\\"{x:1287,y:529,t:1527613626895};\\\", \\\"{x:1288,y:531,t:1527613626904};\\\", \\\"{x:1290,y:536,t:1527613626920};\\\", \\\"{x:1293,y:543,t:1527613626938};\\\", \\\"{x:1297,y:552,t:1527613626954};\\\", \\\"{x:1301,y:561,t:1527613626970};\\\", \\\"{x:1302,y:567,t:1527613626987};\\\", \\\"{x:1302,y:572,t:1527613627004};\\\", \\\"{x:1302,y:576,t:1527613627020};\\\", \\\"{x:1304,y:587,t:1527613627037};\\\", \\\"{x:1307,y:607,t:1527613627054};\\\", \\\"{x:1311,y:627,t:1527613627071};\\\", \\\"{x:1318,y:655,t:1527613627087};\\\", \\\"{x:1318,y:664,t:1527613627104};\\\", \\\"{x:1318,y:680,t:1527613627120};\\\", \\\"{x:1318,y:698,t:1527613627137};\\\", \\\"{x:1318,y:717,t:1527613627154};\\\", \\\"{x:1318,y:731,t:1527613627170};\\\", \\\"{x:1318,y:732,t:1527613627187};\\\", \\\"{x:1317,y:732,t:1527613627204};\\\", \\\"{x:1317,y:728,t:1527613627327};\\\", \\\"{x:1318,y:722,t:1527613627337};\\\", \\\"{x:1321,y:697,t:1527613627354};\\\", \\\"{x:1323,y:672,t:1527613627371};\\\", \\\"{x:1328,y:640,t:1527613627387};\\\", \\\"{x:1329,y:615,t:1527613627404};\\\", \\\"{x:1329,y:604,t:1527613627421};\\\", \\\"{x:1338,y:585,t:1527613627437};\\\", \\\"{x:1345,y:573,t:1527613627454};\\\", \\\"{x:1354,y:557,t:1527613627470};\\\", \\\"{x:1356,y:551,t:1527613627487};\\\", \\\"{x:1360,y:542,t:1527613627504};\\\", \\\"{x:1363,y:539,t:1527613627521};\\\", \\\"{x:1364,y:537,t:1527613627537};\\\", \\\"{x:1365,y:534,t:1527613627554};\\\", \\\"{x:1366,y:531,t:1527613627571};\\\", \\\"{x:1368,y:528,t:1527613627587};\\\", \\\"{x:1370,y:525,t:1527613627604};\\\", \\\"{x:1373,y:523,t:1527613627621};\\\", \\\"{x:1374,y:522,t:1527613627637};\\\", \\\"{x:1375,y:521,t:1527613627654};\\\", \\\"{x:1376,y:520,t:1527613627688};\\\", \\\"{x:1377,y:519,t:1527613627743};\\\", \\\"{x:1379,y:516,t:1527613627754};\\\", \\\"{x:1381,y:513,t:1527613627771};\\\", \\\"{x:1383,y:511,t:1527613627788};\\\", \\\"{x:1383,y:509,t:1527613627804};\\\", \\\"{x:1384,y:507,t:1527613627821};\\\", \\\"{x:1384,y:504,t:1527613627841};\\\", \\\"{x:1384,y:502,t:1527613627854};\\\", \\\"{x:1384,y:501,t:1527613627887};\\\", \\\"{x:1384,y:500,t:1527613627918};\\\", \\\"{x:1384,y:499,t:1527613627943};\\\", \\\"{x:1384,y:497,t:1527613627954};\\\", \\\"{x:1384,y:495,t:1527613627971};\\\", \\\"{x:1391,y:494,t:1527613628207};\\\", \\\"{x:1395,y:494,t:1527613628222};\\\", \\\"{x:1401,y:492,t:1527613628240};\\\", \\\"{x:1403,y:492,t:1527613628255};\\\", \\\"{x:1404,y:492,t:1527613628302};\\\", \\\"{x:1407,y:491,t:1527613628311};\\\", \\\"{x:1408,y:489,t:1527613628321};\\\", \\\"{x:1411,y:489,t:1527613628338};\\\", \\\"{x:1426,y:488,t:1527613628355};\\\", \\\"{x:1440,y:487,t:1527613628371};\\\", \\\"{x:1443,y:485,t:1527613628388};\\\", \\\"{x:1452,y:485,t:1527613628405};\\\", \\\"{x:1456,y:485,t:1527613628421};\\\", \\\"{x:1460,y:485,t:1527613628441};\\\", \\\"{x:1459,y:485,t:1527613628589};\\\", \\\"{x:1457,y:486,t:1527613628604};\\\", \\\"{x:1454,y:487,t:1527613628620};\\\", \\\"{x:1451,y:490,t:1527613628639};\\\", \\\"{x:1450,y:491,t:1527613628661};\\\", \\\"{x:1454,y:491,t:1527613628919};\\\", \\\"{x:1467,y:495,t:1527613628926};\\\", \\\"{x:1478,y:496,t:1527613628938};\\\", \\\"{x:1496,y:501,t:1527613628955};\\\", \\\"{x:1520,y:505,t:1527613628972};\\\", \\\"{x:1533,y:508,t:1527613628988};\\\", \\\"{x:1541,y:510,t:1527613629005};\\\", \\\"{x:1544,y:510,t:1527613629022};\\\", \\\"{x:1547,y:509,t:1527613629223};\\\", \\\"{x:1548,y:508,t:1527613629247};\\\", \\\"{x:1548,y:507,t:1527613629255};\\\", \\\"{x:1548,y:504,t:1527613629272};\\\", \\\"{x:1548,y:503,t:1527613629295};\\\", \\\"{x:1548,y:501,t:1527613629327};\\\", \\\"{x:1549,y:500,t:1527613629391};\\\", \\\"{x:1549,y:498,t:1527613629406};\\\", \\\"{x:1549,y:496,t:1527613629422};\\\", \\\"{x:1549,y:494,t:1527613629440};\\\", \\\"{x:1548,y:493,t:1527613629455};\\\", \\\"{x:1547,y:491,t:1527613629472};\\\", \\\"{x:1546,y:491,t:1527613629489};\\\", \\\"{x:1545,y:491,t:1527613629647};\\\", \\\"{x:1544,y:491,t:1527613629655};\\\", \\\"{x:1539,y:491,t:1527613629672};\\\", \\\"{x:1533,y:495,t:1527613629689};\\\", \\\"{x:1523,y:497,t:1527613629706};\\\", \\\"{x:1517,y:499,t:1527613629722};\\\", \\\"{x:1515,y:499,t:1527613629739};\\\", \\\"{x:1515,y:500,t:1527613629756};\\\", \\\"{x:1515,y:501,t:1527613629772};\\\", \\\"{x:1515,y:503,t:1527613629814};\\\", \\\"{x:1517,y:503,t:1527613630015};\\\", \\\"{x:1522,y:503,t:1527613630022};\\\", \\\"{x:1531,y:500,t:1527613630039};\\\", \\\"{x:1542,y:496,t:1527613630057};\\\", \\\"{x:1546,y:493,t:1527613630072};\\\", \\\"{x:1548,y:493,t:1527613630089};\\\", \\\"{x:1549,y:493,t:1527613630106};\\\", \\\"{x:1550,y:493,t:1527613630123};\\\", \\\"{x:1550,y:492,t:1527613630140};\\\", \\\"{x:1551,y:492,t:1527613630205};\\\", \\\"{x:1552,y:492,t:1527613630294};\\\", \\\"{x:1553,y:492,t:1527613630367};\\\", \\\"{x:1554,y:492,t:1527613630398};\\\", \\\"{x:1556,y:492,t:1527613630406};\\\", \\\"{x:1559,y:493,t:1527613630422};\\\", \\\"{x:1568,y:494,t:1527613630439};\\\", \\\"{x:1575,y:495,t:1527613630456};\\\", \\\"{x:1588,y:495,t:1527613630473};\\\", \\\"{x:1596,y:496,t:1527613630489};\\\", \\\"{x:1599,y:497,t:1527613630507};\\\", \\\"{x:1602,y:497,t:1527613630631};\\\", \\\"{x:1603,y:497,t:1527613630871};\\\", \\\"{x:1605,y:497,t:1527613630902};\\\", \\\"{x:1613,y:494,t:1527613630918};\\\", \\\"{x:1616,y:493,t:1527613630926};\\\", \\\"{x:1619,y:492,t:1527613630940};\\\", \\\"{x:1623,y:492,t:1527613630957};\\\", \\\"{x:1627,y:490,t:1527613630974};\\\", \\\"{x:1630,y:490,t:1527613630990};\\\", \\\"{x:1633,y:489,t:1527613631007};\\\", \\\"{x:1635,y:488,t:1527613631023};\\\", \\\"{x:1636,y:488,t:1527613631054};\\\", \\\"{x:1637,y:488,t:1527613631343};\\\", \\\"{x:1636,y:488,t:1527613638023};\\\", \\\"{x:1633,y:489,t:1527613638039};\\\", \\\"{x:1630,y:490,t:1527613638046};\\\", \\\"{x:1626,y:491,t:1527613638062};\\\", \\\"{x:1610,y:496,t:1527613638078};\\\", \\\"{x:1602,y:496,t:1527613638095};\\\", \\\"{x:1588,y:496,t:1527613638112};\\\", \\\"{x:1566,y:496,t:1527613638129};\\\", \\\"{x:1544,y:496,t:1527613638146};\\\", \\\"{x:1519,y:491,t:1527613638162};\\\", \\\"{x:1493,y:487,t:1527613638178};\\\", \\\"{x:1474,y:486,t:1527613638195};\\\", \\\"{x:1449,y:486,t:1527613638213};\\\", \\\"{x:1437,y:481,t:1527613638228};\\\", \\\"{x:1427,y:480,t:1527613638245};\\\", \\\"{x:1427,y:479,t:1527613638262};\\\", \\\"{x:1427,y:478,t:1527613638294};\\\", \\\"{x:1427,y:477,t:1527613638312};\\\", \\\"{x:1427,y:478,t:1527613640471};\\\", \\\"{x:1428,y:479,t:1527613640510};\\\", \\\"{x:1429,y:481,t:1527613640711};\\\", \\\"{x:1430,y:482,t:1527613640719};\\\", \\\"{x:1430,y:484,t:1527613640730};\\\", \\\"{x:1432,y:488,t:1527613640747};\\\", \\\"{x:1432,y:490,t:1527613640763};\\\", \\\"{x:1435,y:494,t:1527613640781};\\\", \\\"{x:1437,y:496,t:1527613640798};\\\", \\\"{x:1438,y:497,t:1527613640814};\\\", \\\"{x:1439,y:498,t:1527613640895};\\\", \\\"{x:1440,y:498,t:1527613640910};\\\", \\\"{x:1440,y:499,t:1527613640918};\\\", \\\"{x:1441,y:500,t:1527613640931};\\\", \\\"{x:1445,y:500,t:1527613640947};\\\", \\\"{x:1448,y:502,t:1527613640964};\\\", \\\"{x:1452,y:502,t:1527613640980};\\\", \\\"{x:1453,y:502,t:1527613640998};\\\", \\\"{x:1455,y:502,t:1527613641015};\\\", \\\"{x:1455,y:501,t:1527613641294};\\\", \\\"{x:1455,y:500,t:1527613641375};\\\", \\\"{x:1455,y:499,t:1527613641406};\\\", \\\"{x:1455,y:498,t:1527613641430};\\\", \\\"{x:1451,y:498,t:1527613641454};\\\", \\\"{x:1450,y:497,t:1527613641470};\\\", \\\"{x:1449,y:497,t:1527613641480};\\\", \\\"{x:1448,y:497,t:1527613641498};\\\", \\\"{x:1447,y:496,t:1527613641514};\\\", \\\"{x:1446,y:496,t:1527613641534};\\\", \\\"{x:1445,y:496,t:1527613641548};\\\", \\\"{x:1442,y:496,t:1527613641564};\\\", \\\"{x:1441,y:496,t:1527613641582};\\\", \\\"{x:1440,y:496,t:1527613641597};\\\", \\\"{x:1440,y:495,t:1527613641615};\\\", \\\"{x:1441,y:495,t:1527613642358};\\\", \\\"{x:1442,y:495,t:1527613642374};\\\", \\\"{x:1444,y:495,t:1527613642390};\\\", \\\"{x:1445,y:495,t:1527613642406};\\\", \\\"{x:1446,y:495,t:1527613642416};\\\", \\\"{x:1447,y:496,t:1527613642431};\\\", \\\"{x:1448,y:497,t:1527613642448};\\\", \\\"{x:1449,y:497,t:1527613642466};\\\", \\\"{x:1450,y:497,t:1527613642481};\\\", \\\"{x:1451,y:497,t:1527613647183};\\\", \\\"{x:1454,y:498,t:1527613647222};\\\", \\\"{x:1455,y:498,t:1527613647422};\\\", \\\"{x:1456,y:500,t:1527613647446};\\\", \\\"{x:1457,y:500,t:1527613647470};\\\", \\\"{x:1458,y:500,t:1527613647534};\\\", \\\"{x:1460,y:500,t:1527613647591};\\\", \\\"{x:1461,y:500,t:1527613647639};\\\", \\\"{x:1461,y:501,t:1527613650261};\\\", \\\"{x:1460,y:502,t:1527613650270};\\\", \\\"{x:1453,y:502,t:1527613650287};\\\", \\\"{x:1449,y:502,t:1527613650303};\\\", \\\"{x:1445,y:503,t:1527613650320};\\\", \\\"{x:1437,y:503,t:1527613650337};\\\", \\\"{x:1429,y:502,t:1527613650353};\\\", \\\"{x:1426,y:502,t:1527613650370};\\\", \\\"{x:1420,y:501,t:1527613650387};\\\", \\\"{x:1413,y:499,t:1527613650403};\\\", \\\"{x:1407,y:499,t:1527613650421};\\\", \\\"{x:1399,y:498,t:1527613650439};\\\", \\\"{x:1395,y:498,t:1527613650454};\\\", \\\"{x:1389,y:498,t:1527613650471};\\\", \\\"{x:1387,y:498,t:1527613650487};\\\", \\\"{x:1384,y:497,t:1527613650504};\\\", \\\"{x:1375,y:496,t:1527613650521};\\\", \\\"{x:1370,y:494,t:1527613650538};\\\", \\\"{x:1366,y:494,t:1527613650555};\\\", \\\"{x:1362,y:490,t:1527613650790};\\\", \\\"{x:1363,y:490,t:1527613650910};\\\", \\\"{x:1365,y:490,t:1527613650921};\\\", \\\"{x:1366,y:490,t:1527613650938};\\\", \\\"{x:1369,y:490,t:1527613650955};\\\", \\\"{x:1370,y:490,t:1527613650972};\\\", \\\"{x:1371,y:491,t:1527613650988};\\\", \\\"{x:1372,y:491,t:1527613651014};\\\", \\\"{x:1373,y:491,t:1527613651111};\\\", \\\"{x:1374,y:491,t:1527613651198};\\\", \\\"{x:1375,y:491,t:1527613651206};\\\", \\\"{x:1376,y:491,t:1527613651335};\\\", \\\"{x:1377,y:491,t:1527613651342};\\\", \\\"{x:1378,y:491,t:1527613651355};\\\", \\\"{x:1379,y:491,t:1527613651375};\\\", \\\"{x:1380,y:491,t:1527613651405};\\\", \\\"{x:1381,y:490,t:1527613651422};\\\", \\\"{x:1383,y:490,t:1527613651439};\\\", \\\"{x:1386,y:489,t:1527613651455};\\\", \\\"{x:1386,y:488,t:1527613651486};\\\", \\\"{x:1387,y:488,t:1527613651494};\\\", \\\"{x:1388,y:487,t:1527613651505};\\\", \\\"{x:1397,y:484,t:1527613651522};\\\", \\\"{x:1417,y:483,t:1527613651539};\\\", \\\"{x:1425,y:483,t:1527613651555};\\\", \\\"{x:1438,y:484,t:1527613651572};\\\", \\\"{x:1450,y:486,t:1527613651589};\\\", \\\"{x:1453,y:487,t:1527613651605};\\\", \\\"{x:1454,y:488,t:1527613651621};\\\", \\\"{x:1455,y:489,t:1527613651702};\\\", \\\"{x:1455,y:491,t:1527613651718};\\\", \\\"{x:1453,y:492,t:1527613651726};\\\", \\\"{x:1447,y:495,t:1527613651739};\\\", \\\"{x:1440,y:496,t:1527613651755};\\\", \\\"{x:1412,y:496,t:1527613651772};\\\", \\\"{x:1372,y:496,t:1527613651789};\\\", \\\"{x:1343,y:496,t:1527613651804};\\\", \\\"{x:1314,y:493,t:1527613651823};\\\", \\\"{x:1301,y:490,t:1527613651840};\\\", \\\"{x:1298,y:490,t:1527613651855};\\\", \\\"{x:1294,y:489,t:1527613651871};\\\", \\\"{x:1299,y:489,t:1527613652054};\\\", \\\"{x:1302,y:488,t:1527613652062};\\\", \\\"{x:1309,y:488,t:1527613652072};\\\", \\\"{x:1317,y:488,t:1527613652088};\\\", \\\"{x:1321,y:488,t:1527613652106};\\\", \\\"{x:1324,y:488,t:1527613652122};\\\", \\\"{x:1326,y:488,t:1527613652138};\\\", \\\"{x:1327,y:487,t:1527613652156};\\\", \\\"{x:1329,y:487,t:1527613652173};\\\", \\\"{x:1333,y:486,t:1527613652189};\\\", \\\"{x:1344,y:485,t:1527613652205};\\\", \\\"{x:1354,y:485,t:1527613652221};\\\", \\\"{x:1368,y:485,t:1527613652238};\\\", \\\"{x:1381,y:488,t:1527613652255};\\\", \\\"{x:1386,y:491,t:1527613652271};\\\", \\\"{x:1389,y:491,t:1527613652288};\\\", \\\"{x:1389,y:492,t:1527613652306};\\\", \\\"{x:1391,y:492,t:1527613652333};\\\", \\\"{x:1392,y:492,t:1527613652439};\\\", \\\"{x:1393,y:493,t:1527613652456};\\\", \\\"{x:1394,y:494,t:1527613652478};\\\", \\\"{x:1394,y:495,t:1527613652489};\\\", \\\"{x:1394,y:497,t:1527613652509};\\\", \\\"{x:1394,y:499,t:1527613652542};\\\", \\\"{x:1394,y:500,t:1527613652556};\\\", \\\"{x:1394,y:501,t:1527613652573};\\\", \\\"{x:1394,y:504,t:1527613652588};\\\", \\\"{x:1402,y:509,t:1527613652606};\\\", \\\"{x:1414,y:514,t:1527613652622};\\\", \\\"{x:1421,y:517,t:1527613652639};\\\", \\\"{x:1426,y:517,t:1527613652655};\\\", \\\"{x:1428,y:517,t:1527613652673};\\\", \\\"{x:1429,y:517,t:1527613652727};\\\", \\\"{x:1429,y:516,t:1527613652749};\\\", \\\"{x:1429,y:515,t:1527613652758};\\\", \\\"{x:1430,y:515,t:1527613652773};\\\", \\\"{x:1431,y:513,t:1527613652788};\\\", \\\"{x:1433,y:512,t:1527613652806};\\\", \\\"{x:1434,y:510,t:1527613652823};\\\", \\\"{x:1436,y:509,t:1527613652846};\\\", \\\"{x:1438,y:508,t:1527613652886};\\\", \\\"{x:1439,y:507,t:1527613652902};\\\", \\\"{x:1439,y:506,t:1527613652926};\\\", \\\"{x:1440,y:505,t:1527613652939};\\\", \\\"{x:1441,y:505,t:1527613652955};\\\", \\\"{x:1443,y:504,t:1527613652973};\\\", \\\"{x:1447,y:502,t:1527613652990};\\\", \\\"{x:1451,y:500,t:1527613653006};\\\", \\\"{x:1453,y:497,t:1527613653022};\\\", \\\"{x:1453,y:496,t:1527613653071};\\\", \\\"{x:1453,y:495,t:1527613653165};\\\", \\\"{x:1454,y:494,t:1527613653181};\\\", \\\"{x:1455,y:493,t:1527613653189};\\\", \\\"{x:1456,y:493,t:1527613653213};\\\", \\\"{x:1458,y:491,t:1527613653222};\\\", \\\"{x:1459,y:491,t:1527613653239};\\\", \\\"{x:1461,y:490,t:1527613653255};\\\", \\\"{x:1462,y:489,t:1527613653272};\\\", \\\"{x:1464,y:489,t:1527613653289};\\\", \\\"{x:1465,y:489,t:1527613653309};\\\", \\\"{x:1468,y:489,t:1527613653322};\\\", \\\"{x:1474,y:489,t:1527613653339};\\\", \\\"{x:1483,y:489,t:1527613653356};\\\", \\\"{x:1489,y:489,t:1527613653372};\\\", \\\"{x:1490,y:489,t:1527613653389};\\\", \\\"{x:1491,y:489,t:1527613653622};\\\", \\\"{x:1493,y:489,t:1527613653640};\\\", \\\"{x:1495,y:488,t:1527613653656};\\\", \\\"{x:1496,y:487,t:1527613653686};\\\", \\\"{x:1498,y:487,t:1527613653710};\\\", \\\"{x:1503,y:487,t:1527613653723};\\\", \\\"{x:1514,y:491,t:1527613653740};\\\", \\\"{x:1521,y:492,t:1527613653757};\\\", \\\"{x:1524,y:493,t:1527613653773};\\\", \\\"{x:1525,y:493,t:1527613653790};\\\", \\\"{x:1527,y:494,t:1527613653870};\\\", \\\"{x:1528,y:497,t:1527613653877};\\\", \\\"{x:1530,y:500,t:1527613653889};\\\", \\\"{x:1532,y:504,t:1527613653906};\\\", \\\"{x:1533,y:508,t:1527613653923};\\\", \\\"{x:1534,y:508,t:1527613653939};\\\", \\\"{x:1535,y:508,t:1527613654206};\\\", \\\"{x:1537,y:508,t:1527613654213};\\\", \\\"{x:1539,y:507,t:1527613654223};\\\", \\\"{x:1543,y:504,t:1527613654239};\\\", \\\"{x:1547,y:503,t:1527613654256};\\\", \\\"{x:1553,y:501,t:1527613654274};\\\", \\\"{x:1556,y:501,t:1527613654291};\\\", \\\"{x:1559,y:501,t:1527613654306};\\\", \\\"{x:1560,y:501,t:1527613654340};\\\", \\\"{x:1561,y:501,t:1527613654453};\\\", \\\"{x:1562,y:501,t:1527613654469};\\\", \\\"{x:1563,y:502,t:1527613654485};\\\", \\\"{x:1564,y:502,t:1527613654542};\\\", \\\"{x:1565,y:502,t:1527613654556};\\\", \\\"{x:1568,y:502,t:1527613654573};\\\", \\\"{x:1569,y:502,t:1527613654591};\\\", \\\"{x:1572,y:501,t:1527613654607};\\\", \\\"{x:1576,y:500,t:1527613654624};\\\", \\\"{x:1578,y:499,t:1527613654640};\\\", \\\"{x:1579,y:499,t:1527613654656};\\\", \\\"{x:1583,y:499,t:1527613654674};\\\", \\\"{x:1590,y:499,t:1527613654690};\\\", \\\"{x:1599,y:499,t:1527613654707};\\\", \\\"{x:1603,y:499,t:1527613654724};\\\", \\\"{x:1607,y:499,t:1527613654740};\\\", \\\"{x:1609,y:499,t:1527613654757};\\\", \\\"{x:1610,y:499,t:1527613654774};\\\", \\\"{x:1612,y:497,t:1527613654791};\\\", \\\"{x:1614,y:496,t:1527613654808};\\\", \\\"{x:1620,y:494,t:1527613654825};\\\", \\\"{x:1627,y:494,t:1527613654841};\\\", \\\"{x:1631,y:492,t:1527613654858};\\\", \\\"{x:1636,y:491,t:1527613654874};\\\", \\\"{x:1641,y:490,t:1527613654891};\\\", \\\"{x:1642,y:489,t:1527613654908};\\\", \\\"{x:1644,y:488,t:1527613654923};\\\", \\\"{x:1645,y:488,t:1527613654949};\\\", \\\"{x:1646,y:488,t:1527613654957};\\\", \\\"{x:1647,y:487,t:1527613654981};\\\", \\\"{x:1648,y:486,t:1527613654997};\\\", \\\"{x:1649,y:486,t:1527613655021};\\\", \\\"{x:1648,y:486,t:1527613655221};\\\", \\\"{x:1643,y:483,t:1527613655229};\\\", \\\"{x:1628,y:479,t:1527613655240};\\\", \\\"{x:1592,y:470,t:1527613655257};\\\", \\\"{x:1566,y:463,t:1527613655274};\\\", \\\"{x:1541,y:461,t:1527613655290};\\\", \\\"{x:1524,y:458,t:1527613655307};\\\", \\\"{x:1518,y:458,t:1527613655324};\\\", \\\"{x:1516,y:458,t:1527613655341};\\\", \\\"{x:1515,y:458,t:1527613655414};\\\", \\\"{x:1516,y:459,t:1527613655425};\\\", \\\"{x:1516,y:464,t:1527613655441};\\\", \\\"{x:1519,y:468,t:1527613655458};\\\", \\\"{x:1519,y:469,t:1527613655475};\\\", \\\"{x:1519,y:471,t:1527613655518};\\\", \\\"{x:1519,y:473,t:1527613655550};\\\", \\\"{x:1519,y:475,t:1527613655558};\\\", \\\"{x:1519,y:479,t:1527613655575};\\\", \\\"{x:1518,y:484,t:1527613655591};\\\", \\\"{x:1517,y:486,t:1527613655608};\\\", \\\"{x:1517,y:489,t:1527613655625};\\\", \\\"{x:1516,y:491,t:1527613655641};\\\", \\\"{x:1512,y:494,t:1527613655658};\\\", \\\"{x:1501,y:498,t:1527613655675};\\\", \\\"{x:1492,y:501,t:1527613655691};\\\", \\\"{x:1488,y:503,t:1527613655708};\\\", \\\"{x:1482,y:506,t:1527613655725};\\\", \\\"{x:1475,y:507,t:1527613655742};\\\", \\\"{x:1471,y:509,t:1527613655758};\\\", \\\"{x:1467,y:511,t:1527613655775};\\\", \\\"{x:1463,y:512,t:1527613655792};\\\", \\\"{x:1463,y:513,t:1527613655807};\\\", \\\"{x:1462,y:513,t:1527613655824};\\\", \\\"{x:1459,y:512,t:1527613655893};\\\", \\\"{x:1458,y:510,t:1527613655925};\\\", \\\"{x:1458,y:509,t:1527613655941};\\\", \\\"{x:1458,y:508,t:1527613655965};\\\", \\\"{x:1460,y:508,t:1527613655981};\\\", \\\"{x:1463,y:505,t:1527613655992};\\\", \\\"{x:1467,y:504,t:1527613656008};\\\", \\\"{x:1470,y:503,t:1527613656024};\\\", \\\"{x:1473,y:501,t:1527613656042};\\\", \\\"{x:1474,y:500,t:1527613656086};\\\", \\\"{x:1474,y:499,t:1527613656870};\\\", \\\"{x:1475,y:498,t:1527613656886};\\\", \\\"{x:1475,y:497,t:1527613656901};\\\", \\\"{x:1476,y:495,t:1527613656909};\\\", \\\"{x:1476,y:494,t:1527613656965};\\\", \\\"{x:1476,y:493,t:1527613657061};\\\", \\\"{x:1477,y:492,t:1527613658653};\\\", \\\"{x:1479,y:492,t:1527613658677};\\\", \\\"{x:1480,y:492,t:1527613658693};\\\", \\\"{x:1481,y:492,t:1527613658709};\\\", \\\"{x:1482,y:493,t:1527613658758};\\\", \\\"{x:1483,y:494,t:1527613658798};\\\", \\\"{x:1484,y:494,t:1527613658894};\\\", \\\"{x:1484,y:495,t:1527613659359};\\\", \\\"{x:1483,y:495,t:1527613659390};\\\", \\\"{x:1482,y:496,t:1527613659406};\\\", \\\"{x:1481,y:496,t:1527613659421};\\\", \\\"{x:1480,y:496,t:1527613659430};\\\", \\\"{x:1479,y:496,t:1527613659461};\\\", \\\"{x:1478,y:497,t:1527613663277};\\\", \\\"{x:1478,y:498,t:1527613663525};\\\", \\\"{x:1475,y:500,t:1527613664134};\\\", \\\"{x:1464,y:505,t:1527613664148};\\\", \\\"{x:1443,y:511,t:1527613664164};\\\", \\\"{x:1403,y:525,t:1527613664181};\\\", \\\"{x:1307,y:549,t:1527613664197};\\\", \\\"{x:1262,y:561,t:1527613664214};\\\", \\\"{x:1235,y:565,t:1527613664231};\\\", \\\"{x:1176,y:575,t:1527613664247};\\\", \\\"{x:1174,y:576,t:1527613664264};\\\", \\\"{x:1173,y:576,t:1527613665040};\\\", \\\"{x:1172,y:577,t:1527613665070};\\\", \\\"{x:1170,y:580,t:1527613665081};\\\", \\\"{x:1163,y:590,t:1527613665098};\\\", \\\"{x:1150,y:606,t:1527613665115};\\\", \\\"{x:1135,y:619,t:1527613665131};\\\", \\\"{x:1125,y:630,t:1527613665148};\\\", \\\"{x:1103,y:644,t:1527613665165};\\\", \\\"{x:1092,y:652,t:1527613665182};\\\", \\\"{x:1079,y:661,t:1527613665198};\\\", \\\"{x:1068,y:667,t:1527613665215};\\\", \\\"{x:1060,y:671,t:1527613665231};\\\", \\\"{x:1052,y:674,t:1527613665247};\\\", \\\"{x:1039,y:679,t:1527613665265};\\\", \\\"{x:1024,y:685,t:1527613665281};\\\", \\\"{x:1007,y:691,t:1527613665298};\\\", \\\"{x:985,y:695,t:1527613665315};\\\", \\\"{x:964,y:697,t:1527613665332};\\\", \\\"{x:943,y:697,t:1527613665348};\\\", \\\"{x:910,y:696,t:1527613665365};\\\", \\\"{x:900,y:692,t:1527613665381};\\\", \\\"{x:872,y:687,t:1527613665398};\\\", \\\"{x:840,y:683,t:1527613665415};\\\", \\\"{x:821,y:679,t:1527613665432};\\\", \\\"{x:804,y:679,t:1527613665448};\\\", \\\"{x:802,y:679,t:1527613665465};\\\", \\\"{x:797,y:678,t:1527613665482};\\\", \\\"{x:790,y:678,t:1527613665498};\\\", \\\"{x:786,y:678,t:1527613665516};\\\", \\\"{x:783,y:678,t:1527613665532};\\\", \\\"{x:782,y:678,t:1527613665548};\\\", \\\"{x:781,y:677,t:1527613665686};\\\", \\\"{x:779,y:675,t:1527613665699};\\\", \\\"{x:770,y:667,t:1527613665715};\\\", \\\"{x:752,y:653,t:1527613665732};\\\", \\\"{x:708,y:628,t:1527613665750};\\\", \\\"{x:662,y:611,t:1527613665767};\\\", \\\"{x:640,y:602,t:1527613665782};\\\", \\\"{x:624,y:594,t:1527613665799};\\\", \\\"{x:617,y:592,t:1527613665819};\\\", \\\"{x:610,y:592,t:1527613665836};\\\", \\\"{x:602,y:592,t:1527613665852};\\\", \\\"{x:590,y:593,t:1527613665868};\\\", \\\"{x:586,y:594,t:1527613665886};\\\", \\\"{x:583,y:594,t:1527613665902};\\\", \\\"{x:582,y:595,t:1527613665919};\\\", \\\"{x:581,y:595,t:1527613665936};\\\", \\\"{x:580,y:596,t:1527613666046};\\\", \\\"{x:582,y:601,t:1527613666061};\\\", \\\"{x:586,y:609,t:1527613666069};\\\", \\\"{x:599,y:623,t:1527613666086};\\\", \\\"{x:613,y:636,t:1527613666102};\\\", \\\"{x:617,y:640,t:1527613666119};\\\", \\\"{x:621,y:642,t:1527613666136};\\\", \\\"{x:623,y:642,t:1527613666152};\\\", \\\"{x:623,y:639,t:1527613666342};\\\", \\\"{x:622,y:638,t:1527613666353};\\\", \\\"{x:618,y:628,t:1527613666371};\\\", \\\"{x:615,y:619,t:1527613666387};\\\", \\\"{x:613,y:612,t:1527613666403};\\\", \\\"{x:610,y:608,t:1527613666419};\\\", \\\"{x:610,y:607,t:1527613666437};\\\", \\\"{x:609,y:606,t:1527613666461};\\\", \\\"{x:609,y:605,t:1527613666549};\\\", \\\"{x:608,y:605,t:1527613666556};\\\", \\\"{x:608,y:608,t:1527613666845};\\\", \\\"{x:608,y:609,t:1527613666853};\\\", \\\"{x:608,y:624,t:1527613666871};\\\", \\\"{x:608,y:643,t:1527613666888};\\\", \\\"{x:608,y:661,t:1527613666904};\\\", \\\"{x:610,y:679,t:1527613666921};\\\", \\\"{x:613,y:689,t:1527613666937};\\\", \\\"{x:614,y:698,t:1527613666954};\\\", \\\"{x:614,y:705,t:1527613666970};\\\", \\\"{x:614,y:708,t:1527613666987};\\\", \\\"{x:614,y:709,t:1527613667004};\\\", \\\"{x:614,y:714,t:1527613667021};\\\", \\\"{x:614,y:722,t:1527613667038};\\\", \\\"{x:611,y:725,t:1527613667054};\\\", \\\"{x:609,y:727,t:1527613667070};\\\", \\\"{x:608,y:728,t:1527613667087};\\\", \\\"{x:606,y:728,t:1527613667118};\\\", \\\"{x:605,y:728,t:1527613667125};\\\", \\\"{x:601,y:728,t:1527613667137};\\\", \\\"{x:594,y:728,t:1527613667154};\\\", \\\"{x:581,y:728,t:1527613667171};\\\", \\\"{x:573,y:727,t:1527613667187};\\\", \\\"{x:573,y:724,t:1527613667205};\\\", \\\"{x:562,y:722,t:1527613667223};\\\", \\\"{x:558,y:721,t:1527613667239};\\\", \\\"{x:555,y:721,t:1527613667254};\\\", \\\"{x:555,y:720,t:1527613667548};\\\", \\\"{x:555,y:719,t:1527613667589};\\\", \\\"{x:555,y:718,t:1527613667603};\\\", \\\"{x:556,y:716,t:1527613667620};\\\", \\\"{x:556,y:715,t:1527613668277};\\\" ] }, { \\\"rt\\\": 17788, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 10, \\\"time_elapsed\\\": 360307, \\\"internal_node_id\\\": \\\"0.0-6.0-0.0\\\", \\\"subject\\\": \\\"AZKMW\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"oscar\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration\\\", \\\"q\\\": 6, \\\"clicks\\\": 3, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\", \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-E -E \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:558,y:713,t:1527613673725};\\\", \\\"{x:558,y:708,t:1527613673743};\\\", \\\"{x:559,y:707,t:1527613673759};\\\", \\\"{x:560,y:706,t:1527613673853};\\\", \\\"{x:561,y:704,t:1527613673861};\\\", \\\"{x:563,y:702,t:1527613673876};\\\", \\\"{x:563,y:701,t:1527613673893};\\\", \\\"{x:563,y:700,t:1527613673942};\\\", \\\"{x:563,y:699,t:1527613674086};\\\", \\\"{x:564,y:697,t:1527613674118};\\\", \\\"{x:565,y:696,t:1527613674190};\\\", \\\"{x:566,y:696,t:1527613674358};\\\", \\\"{x:566,y:694,t:1527613674846};\\\", \\\"{x:568,y:692,t:1527613674861};\\\", \\\"{x:569,y:688,t:1527613674876};\\\", \\\"{x:573,y:684,t:1527613674894};\\\", \\\"{x:577,y:678,t:1527613674910};\\\", \\\"{x:585,y:669,t:1527613674927};\\\", \\\"{x:602,y:655,t:1527613674944};\\\", \\\"{x:623,y:646,t:1527613674961};\\\", \\\"{x:643,y:640,t:1527613674977};\\\", \\\"{x:664,y:631,t:1527613674995};\\\", \\\"{x:687,y:628,t:1527613675010};\\\", \\\"{x:710,y:624,t:1527613675027};\\\", \\\"{x:737,y:623,t:1527613675043};\\\", \\\"{x:766,y:619,t:1527613675059};\\\", \\\"{x:790,y:614,t:1527613675075};\\\", \\\"{x:821,y:611,t:1527613675092};\\\", \\\"{x:871,y:602,t:1527613675108};\\\", \\\"{x:898,y:596,t:1527613675125};\\\", \\\"{x:929,y:588,t:1527613675142};\\\", \\\"{x:965,y:580,t:1527613675160};\\\", \\\"{x:1050,y:561,t:1527613675177};\\\", \\\"{x:1151,y:525,t:1527613675193};\\\", \\\"{x:1260,y:498,t:1527613675210};\\\", \\\"{x:1307,y:488,t:1527613675227};\\\", \\\"{x:1327,y:481,t:1527613675244};\\\", \\\"{x:1341,y:475,t:1527613675260};\\\", \\\"{x:1373,y:468,t:1527613675277};\\\", \\\"{x:1390,y:465,t:1527613675294};\\\", \\\"{x:1402,y:461,t:1527613675311};\\\", \\\"{x:1404,y:461,t:1527613675328};\\\", \\\"{x:1405,y:460,t:1527613675344};\\\", \\\"{x:1404,y:467,t:1527613675462};\\\", \\\"{x:1393,y:491,t:1527613675477};\\\", \\\"{x:1383,y:508,t:1527613675494};\\\", \\\"{x:1370,y:526,t:1527613675512};\\\", \\\"{x:1361,y:534,t:1527613675528};\\\", \\\"{x:1355,y:542,t:1527613675545};\\\", \\\"{x:1352,y:545,t:1527613675562};\\\", \\\"{x:1349,y:549,t:1527613675578};\\\", \\\"{x:1348,y:551,t:1527613675605};\\\", \\\"{x:1348,y:552,t:1527613675630};\\\", \\\"{x:1348,y:553,t:1527613675669};\\\", \\\"{x:1346,y:554,t:1527613675684};\\\", \\\"{x:1345,y:555,t:1527613675709};\\\", \\\"{x:1344,y:555,t:1527613675733};\\\", \\\"{x:1343,y:555,t:1527613675745};\\\", \\\"{x:1342,y:556,t:1527613675761};\\\", \\\"{x:1337,y:558,t:1527613675778};\\\", \\\"{x:1332,y:560,t:1527613675794};\\\", \\\"{x:1329,y:561,t:1527613675811};\\\", \\\"{x:1326,y:562,t:1527613675828};\\\", \\\"{x:1324,y:562,t:1527613675845};\\\", \\\"{x:1322,y:563,t:1527613675862};\\\", \\\"{x:1321,y:563,t:1527613675901};\\\", \\\"{x:1320,y:563,t:1527613675950};\\\", \\\"{x:1319,y:563,t:1527613675961};\\\", \\\"{x:1317,y:562,t:1527613675980};\\\", \\\"{x:1316,y:562,t:1527613675996};\\\", \\\"{x:1310,y:562,t:1527613676011};\\\", \\\"{x:1295,y:564,t:1527613676029};\\\", \\\"{x:1283,y:568,t:1527613676048};\\\", \\\"{x:1282,y:569,t:1527613676093};\\\", \\\"{x:1281,y:569,t:1527613676622};\\\", \\\"{x:1281,y:568,t:1527613676629};\\\", \\\"{x:1281,y:567,t:1527613676661};\\\", \\\"{x:1281,y:566,t:1527613676717};\\\", \\\"{x:1280,y:565,t:1527613676729};\\\", \\\"{x:1282,y:565,t:1527613677422};\\\", \\\"{x:1283,y:565,t:1527613677430};\\\", \\\"{x:1288,y:565,t:1527613677448};\\\", \\\"{x:1293,y:565,t:1527613677464};\\\", \\\"{x:1298,y:565,t:1527613677480};\\\", \\\"{x:1313,y:565,t:1527613677499};\\\", \\\"{x:1335,y:565,t:1527613677514};\\\", \\\"{x:1357,y:567,t:1527613677531};\\\", \\\"{x:1379,y:571,t:1527613677548};\\\", \\\"{x:1397,y:575,t:1527613677564};\\\", \\\"{x:1420,y:578,t:1527613677581};\\\", \\\"{x:1448,y:582,t:1527613677598};\\\", \\\"{x:1458,y:582,t:1527613677615};\\\", \\\"{x:1460,y:582,t:1527613677631};\\\", \\\"{x:1457,y:582,t:1527613679246};\\\", \\\"{x:1450,y:582,t:1527613679254};\\\", \\\"{x:1442,y:582,t:1527613679266};\\\", \\\"{x:1432,y:581,t:1527613679282};\\\", \\\"{x:1422,y:580,t:1527613679299};\\\", \\\"{x:1413,y:578,t:1527613679316};\\\", \\\"{x:1410,y:577,t:1527613679333};\\\", \\\"{x:1408,y:577,t:1527613679454};\\\", \\\"{x:1406,y:577,t:1527613679469};\\\", \\\"{x:1400,y:577,t:1527613679484};\\\", \\\"{x:1390,y:577,t:1527613679500};\\\", \\\"{x:1368,y:577,t:1527613679516};\\\", \\\"{x:1252,y:574,t:1527613679533};\\\", \\\"{x:1107,y:565,t:1527613679549};\\\", \\\"{x:977,y:544,t:1527613679566};\\\", \\\"{x:822,y:529,t:1527613679584};\\\", \\\"{x:749,y:507,t:1527613679600};\\\", \\\"{x:727,y:502,t:1527613679609};\\\", \\\"{x:720,y:500,t:1527613679626};\\\", \\\"{x:718,y:500,t:1527613679642};\\\", \\\"{x:716,y:499,t:1527613680062};\\\", \\\"{x:707,y:499,t:1527613680069};\\\", \\\"{x:703,y:499,t:1527613680081};\\\", \\\"{x:678,y:493,t:1527613680098};\\\", \\\"{x:637,y:489,t:1527613680114};\\\", \\\"{x:609,y:484,t:1527613680131};\\\", \\\"{x:595,y:483,t:1527613680148};\\\", \\\"{x:585,y:483,t:1527613680164};\\\", \\\"{x:580,y:483,t:1527613680181};\\\", \\\"{x:579,y:483,t:1527613680349};\\\", \\\"{x:584,y:488,t:1527613680365};\\\", \\\"{x:593,y:496,t:1527613680381};\\\", \\\"{x:595,y:497,t:1527613680399};\\\", \\\"{x:596,y:498,t:1527613680414};\\\", \\\"{x:596,y:500,t:1527613680533};\\\", \\\"{x:596,y:501,t:1527613680550};\\\", \\\"{x:605,y:502,t:1527613680871};\\\", \\\"{x:614,y:502,t:1527613680881};\\\", \\\"{x:644,y:504,t:1527613680899};\\\", \\\"{x:699,y:510,t:1527613680914};\\\", \\\"{x:772,y:525,t:1527613680931};\\\", \\\"{x:888,y:552,t:1527613680948};\\\", \\\"{x:946,y:569,t:1527613680964};\\\", \\\"{x:984,y:579,t:1527613680981};\\\", \\\"{x:1009,y:584,t:1527613680998};\\\", \\\"{x:1025,y:588,t:1527613681015};\\\", \\\"{x:1030,y:589,t:1527613681033};\\\", \\\"{x:1030,y:590,t:1527613681133};\\\", \\\"{x:1010,y:594,t:1527613681149};\\\", \\\"{x:986,y:595,t:1527613681165};\\\", \\\"{x:954,y:595,t:1527613681183};\\\", \\\"{x:904,y:589,t:1527613681200};\\\", \\\"{x:857,y:578,t:1527613681215};\\\", \\\"{x:823,y:567,t:1527613681233};\\\", \\\"{x:801,y:557,t:1527613681249};\\\", \\\"{x:778,y:548,t:1527613681265};\\\", \\\"{x:759,y:541,t:1527613681282};\\\", \\\"{x:749,y:539,t:1527613681299};\\\", \\\"{x:743,y:539,t:1527613681315};\\\", \\\"{x:739,y:539,t:1527613681332};\\\", \\\"{x:737,y:539,t:1527613681349};\\\", \\\"{x:735,y:539,t:1527613681438};\\\", \\\"{x:733,y:539,t:1527613681448};\\\", \\\"{x:727,y:537,t:1527613681465};\\\", \\\"{x:721,y:534,t:1527613681483};\\\", \\\"{x:710,y:532,t:1527613681499};\\\", \\\"{x:693,y:526,t:1527613681515};\\\", \\\"{x:666,y:520,t:1527613681532};\\\", \\\"{x:647,y:515,t:1527613681550};\\\", \\\"{x:618,y:503,t:1527613681565};\\\", \\\"{x:594,y:492,t:1527613681583};\\\", \\\"{x:572,y:483,t:1527613681598};\\\", \\\"{x:564,y:478,t:1527613681615};\\\", \\\"{x:560,y:478,t:1527613681632};\\\", \\\"{x:560,y:477,t:1527613681649};\\\", \\\"{x:563,y:477,t:1527613681861};\\\", \\\"{x:563,y:478,t:1527613681869};\\\", \\\"{x:566,y:479,t:1527613681882};\\\", \\\"{x:570,y:479,t:1527613681900};\\\", \\\"{x:574,y:483,t:1527613681917};\\\", \\\"{x:579,y:485,t:1527613681933};\\\", \\\"{x:582,y:488,t:1527613681950};\\\", \\\"{x:584,y:489,t:1527613681966};\\\", \\\"{x:588,y:493,t:1527613681982};\\\", \\\"{x:589,y:493,t:1527613682000};\\\", \\\"{x:592,y:494,t:1527613682016};\\\", \\\"{x:592,y:495,t:1527613682037};\\\", \\\"{x:593,y:495,t:1527613682061};\\\", \\\"{x:594,y:495,t:1527613682069};\\\", \\\"{x:596,y:496,t:1527613682093};\\\", \\\"{x:598,y:497,t:1527613682118};\\\", \\\"{x:599,y:497,t:1527613682917};\\\", \\\"{x:601,y:497,t:1527613682934};\\\", \\\"{x:603,y:496,t:1527613682956};\\\", \\\"{x:604,y:496,t:1527613682966};\\\", \\\"{x:605,y:496,t:1527613682983};\\\", \\\"{x:607,y:495,t:1527613683000};\\\", \\\"{x:611,y:494,t:1527613683016};\\\", \\\"{x:612,y:493,t:1527613683034};\\\", \\\"{x:619,y:493,t:1527613683050};\\\", \\\"{x:632,y:493,t:1527613683066};\\\", \\\"{x:649,y:493,t:1527613683083};\\\", \\\"{x:669,y:495,t:1527613683100};\\\", \\\"{x:693,y:499,t:1527613683116};\\\", \\\"{x:710,y:505,t:1527613683133};\\\", \\\"{x:730,y:510,t:1527613683150};\\\", \\\"{x:746,y:515,t:1527613683166};\\\", \\\"{x:761,y:522,t:1527613683184};\\\", \\\"{x:769,y:524,t:1527613683200};\\\", \\\"{x:773,y:526,t:1527613683216};\\\", \\\"{x:774,y:526,t:1527613683341};\\\", \\\"{x:777,y:530,t:1527613683350};\\\", \\\"{x:779,y:534,t:1527613683367};\\\", \\\"{x:782,y:539,t:1527613683383};\\\", \\\"{x:786,y:545,t:1527613683400};\\\", \\\"{x:789,y:552,t:1527613683417};\\\", \\\"{x:790,y:553,t:1527613683433};\\\", \\\"{x:790,y:555,t:1527613683451};\\\", \\\"{x:792,y:556,t:1527613683468};\\\", \\\"{x:793,y:556,t:1527613683484};\\\", \\\"{x:794,y:557,t:1527613683501};\\\", \\\"{x:796,y:558,t:1527613683565};\\\", \\\"{x:802,y:558,t:1527613683573};\\\", \\\"{x:807,y:555,t:1527613683584};\\\", \\\"{x:818,y:550,t:1527613683601};\\\", \\\"{x:828,y:545,t:1527613683617};\\\", \\\"{x:840,y:542,t:1527613683634};\\\", \\\"{x:845,y:539,t:1527613683650};\\\", \\\"{x:847,y:539,t:1527613683692};\\\", \\\"{x:845,y:539,t:1527613684205};\\\", \\\"{x:840,y:539,t:1527613684217};\\\", \\\"{x:825,y:539,t:1527613684235};\\\", \\\"{x:803,y:539,t:1527613684252};\\\", \\\"{x:780,y:534,t:1527613684267};\\\", \\\"{x:747,y:524,t:1527613684285};\\\", \\\"{x:728,y:517,t:1527613684302};\\\", \\\"{x:713,y:511,t:1527613684318};\\\", \\\"{x:699,y:507,t:1527613684334};\\\", \\\"{x:695,y:506,t:1527613684351};\\\", \\\"{x:694,y:506,t:1527613684368};\\\", \\\"{x:692,y:505,t:1527613684566};\\\", \\\"{x:688,y:505,t:1527613684573};\\\", \\\"{x:685,y:504,t:1527613684585};\\\", \\\"{x:676,y:503,t:1527613684601};\\\", \\\"{x:663,y:502,t:1527613684619};\\\", \\\"{x:650,y:502,t:1527613684635};\\\", \\\"{x:646,y:502,t:1527613684652};\\\", \\\"{x:643,y:502,t:1527613684669};\\\", \\\"{x:642,y:502,t:1527613684752};\\\", \\\"{x:642,y:502,t:1527613684863};\\\", \\\"{x:640,y:502,t:1527613685037};\\\", \\\"{x:638,y:503,t:1527613685052};\\\", \\\"{x:629,y:519,t:1527613685069};\\\", \\\"{x:619,y:540,t:1527613685087};\\\", \\\"{x:614,y:557,t:1527613685103};\\\", \\\"{x:609,y:571,t:1527613685120};\\\", \\\"{x:604,y:579,t:1527613685136};\\\", \\\"{x:602,y:580,t:1527613685151};\\\", \\\"{x:601,y:580,t:1527613685205};\\\", \\\"{x:600,y:579,t:1527613685219};\\\", \\\"{x:599,y:571,t:1527613685235};\\\", \\\"{x:599,y:560,t:1527613685252};\\\", \\\"{x:599,y:547,t:1527613685268};\\\", \\\"{x:600,y:541,t:1527613685286};\\\", \\\"{x:601,y:537,t:1527613685302};\\\", \\\"{x:603,y:531,t:1527613685322};\\\", \\\"{x:604,y:526,t:1527613685339};\\\", \\\"{x:605,y:522,t:1527613685357};\\\", \\\"{x:606,y:516,t:1527613685373};\\\", \\\"{x:606,y:510,t:1527613685390};\\\", \\\"{x:607,y:507,t:1527613685406};\\\", \\\"{x:608,y:507,t:1527613685422};\\\", \\\"{x:609,y:512,t:1527613685768};\\\", \\\"{x:609,y:522,t:1527613685777};\\\", \\\"{x:609,y:527,t:1527613685790};\\\", \\\"{x:607,y:543,t:1527613685807};\\\", \\\"{x:606,y:561,t:1527613685824};\\\", \\\"{x:603,y:579,t:1527613685839};\\\", \\\"{x:602,y:596,t:1527613685856};\\\", \\\"{x:600,y:609,t:1527613685874};\\\", \\\"{x:597,y:623,t:1527613685890};\\\", \\\"{x:596,y:640,t:1527613685906};\\\", \\\"{x:596,y:644,t:1527613685924};\\\", \\\"{x:596,y:647,t:1527613685940};\\\", \\\"{x:593,y:653,t:1527613685956};\\\", \\\"{x:591,y:656,t:1527613685974};\\\", \\\"{x:590,y:660,t:1527613685989};\\\", \\\"{x:589,y:660,t:1527613686006};\\\", \\\"{x:588,y:662,t:1527613686105};\\\", \\\"{x:587,y:665,t:1527613686113};\\\", \\\"{x:586,y:667,t:1527613686124};\\\", \\\"{x:581,y:672,t:1527613686140};\\\", \\\"{x:575,y:683,t:1527613686157};\\\", \\\"{x:567,y:692,t:1527613686175};\\\", \\\"{x:558,y:704,t:1527613686190};\\\", \\\"{x:555,y:710,t:1527613686207};\\\", \\\"{x:551,y:721,t:1527613686225};\\\", \\\"{x:547,y:727,t:1527613686241};\\\", \\\"{x:544,y:733,t:1527613686256};\\\", \\\"{x:544,y:738,t:1527613686274};\\\", \\\"{x:544,y:741,t:1527613686290};\\\", \\\"{x:542,y:745,t:1527613686308};\\\", \\\"{x:541,y:745,t:1527613686328};\\\" ] }, { \\\"rt\\\": 38871, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 11, \\\"time_elapsed\\\": 400403, \\\"internal_node_id\\\": \\\"0.0-6.0-1.0\\\", \\\"subject\\\": \\\"AZKMW\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"oscar\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+starts\\\", \\\"q\\\": 7, \\\"clicks\\\": 6.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-3-I -J -J -5-F -F -F -F \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:557,y:749,t:1527613692570};\\\", \\\"{x:622,y:759,t:1527613692581};\\\", \\\"{x:860,y:783,t:1527613692606};\\\", \\\"{x:913,y:783,t:1527613692611};\\\", \\\"{x:933,y:784,t:1527613692629};\\\", \\\"{x:937,y:783,t:1527613693089};\\\", \\\"{x:941,y:783,t:1527613693096};\\\", \\\"{x:954,y:779,t:1527613693113};\\\", \\\"{x:966,y:776,t:1527613693129};\\\", \\\"{x:974,y:772,t:1527613693146};\\\", \\\"{x:987,y:768,t:1527613693164};\\\", \\\"{x:1000,y:764,t:1527613693179};\\\", \\\"{x:1010,y:762,t:1527613693196};\\\", \\\"{x:1016,y:762,t:1527613693213};\\\", \\\"{x:1021,y:762,t:1527613693229};\\\", \\\"{x:1024,y:762,t:1527613693246};\\\", \\\"{x:1025,y:762,t:1527613693263};\\\", \\\"{x:1033,y:762,t:1527613693280};\\\", \\\"{x:1038,y:762,t:1527613693296};\\\", \\\"{x:1057,y:761,t:1527613693314};\\\", \\\"{x:1073,y:759,t:1527613693330};\\\", \\\"{x:1092,y:759,t:1527613693347};\\\", \\\"{x:1110,y:760,t:1527613693364};\\\", \\\"{x:1123,y:763,t:1527613693379};\\\", \\\"{x:1135,y:765,t:1527613693397};\\\", \\\"{x:1155,y:767,t:1527613693413};\\\", \\\"{x:1177,y:771,t:1527613693428};\\\", \\\"{x:1198,y:778,t:1527613693446};\\\", \\\"{x:1209,y:780,t:1527613693463};\\\", \\\"{x:1215,y:782,t:1527613693479};\\\", \\\"{x:1220,y:784,t:1527613693496};\\\", \\\"{x:1221,y:784,t:1527613693713};\\\", \\\"{x:1221,y:782,t:1527613693729};\\\", \\\"{x:1210,y:779,t:1527613693746};\\\", \\\"{x:1203,y:777,t:1527613693762};\\\", \\\"{x:1190,y:776,t:1527613693780};\\\", \\\"{x:1183,y:776,t:1527613693795};\\\", \\\"{x:1181,y:776,t:1527613693813};\\\", \\\"{x:1180,y:776,t:1527613693830};\\\", \\\"{x:1179,y:774,t:1527613694402};\\\", \\\"{x:1179,y:772,t:1527613694414};\\\", \\\"{x:1179,y:770,t:1527613694433};\\\", \\\"{x:1179,y:769,t:1527613694448};\\\", \\\"{x:1179,y:767,t:1527613694467};\\\", \\\"{x:1179,y:766,t:1527613695505};\\\", \\\"{x:1181,y:766,t:1527613695514};\\\", \\\"{x:1182,y:766,t:1527613695553};\\\", \\\"{x:1183,y:769,t:1527613696363};\\\", \\\"{x:1184,y:775,t:1527613696367};\\\", \\\"{x:1188,y:781,t:1527613696381};\\\", \\\"{x:1192,y:791,t:1527613696398};\\\", \\\"{x:1197,y:802,t:1527613696415};\\\", \\\"{x:1199,y:808,t:1527613696432};\\\", \\\"{x:1201,y:811,t:1527613696447};\\\", \\\"{x:1201,y:812,t:1527613696465};\\\", \\\"{x:1202,y:813,t:1527613696625};\\\", \\\"{x:1206,y:815,t:1527613696633};\\\", \\\"{x:1214,y:822,t:1527613696649};\\\", \\\"{x:1218,y:832,t:1527613696666};\\\", \\\"{x:1221,y:839,t:1527613696683};\\\", \\\"{x:1224,y:845,t:1527613696700};\\\", \\\"{x:1225,y:846,t:1527613696715};\\\", \\\"{x:1228,y:843,t:1527613698681};\\\", \\\"{x:1229,y:836,t:1527613698690};\\\", \\\"{x:1229,y:834,t:1527613698700};\\\", \\\"{x:1231,y:828,t:1527613698717};\\\", \\\"{x:1236,y:817,t:1527613698734};\\\", \\\"{x:1239,y:811,t:1527613698751};\\\", \\\"{x:1242,y:804,t:1527613698767};\\\", \\\"{x:1244,y:800,t:1527613698784};\\\", \\\"{x:1245,y:798,t:1527613698801};\\\", \\\"{x:1246,y:793,t:1527613698817};\\\", \\\"{x:1247,y:792,t:1527613698835};\\\", \\\"{x:1247,y:791,t:1527613698857};\\\", \\\"{x:1247,y:789,t:1527613698868};\\\", \\\"{x:1248,y:786,t:1527613698885};\\\", \\\"{x:1251,y:782,t:1527613698906};\\\", \\\"{x:1252,y:782,t:1527613698918};\\\", \\\"{x:1255,y:778,t:1527613698935};\\\", \\\"{x:1260,y:776,t:1527613698951};\\\", \\\"{x:1269,y:771,t:1527613698968};\\\", \\\"{x:1276,y:768,t:1527613698984};\\\", \\\"{x:1281,y:766,t:1527613699001};\\\", \\\"{x:1288,y:763,t:1527613699018};\\\", \\\"{x:1292,y:761,t:1527613699035};\\\", \\\"{x:1298,y:759,t:1527613699051};\\\", \\\"{x:1300,y:758,t:1527613699068};\\\", \\\"{x:1301,y:758,t:1527613699084};\\\", \\\"{x:1302,y:757,t:1527613699101};\\\", \\\"{x:1301,y:757,t:1527613702057};\\\", \\\"{x:1270,y:753,t:1527613702070};\\\", \\\"{x:1154,y:740,t:1527613702087};\\\", \\\"{x:1019,y:727,t:1527613702103};\\\", \\\"{x:860,y:690,t:1527613702119};\\\", \\\"{x:592,y:640,t:1527613702137};\\\", \\\"{x:424,y:600,t:1527613702153};\\\", \\\"{x:310,y:580,t:1527613702170};\\\", \\\"{x:229,y:557,t:1527613702186};\\\", \\\"{x:195,y:545,t:1527613702203};\\\", \\\"{x:183,y:540,t:1527613702219};\\\", \\\"{x:177,y:538,t:1527613702236};\\\", \\\"{x:176,y:537,t:1527613702253};\\\", \\\"{x:175,y:537,t:1527613702304};\\\", \\\"{x:171,y:537,t:1527613702320};\\\", \\\"{x:155,y:535,t:1527613702336};\\\", \\\"{x:134,y:531,t:1527613702353};\\\", \\\"{x:113,y:525,t:1527613702370};\\\", \\\"{x:109,y:525,t:1527613702387};\\\", \\\"{x:109,y:523,t:1527613702498};\\\", \\\"{x:112,y:522,t:1527613702504};\\\", \\\"{x:128,y:520,t:1527613702520};\\\", \\\"{x:149,y:516,t:1527613702538};\\\", \\\"{x:163,y:512,t:1527613702553};\\\", \\\"{x:168,y:511,t:1527613702570};\\\", \\\"{x:169,y:511,t:1527613702587};\\\", \\\"{x:169,y:510,t:1527613702603};\\\", \\\"{x:172,y:515,t:1527613702985};\\\", \\\"{x:172,y:523,t:1527613702993};\\\", \\\"{x:172,y:530,t:1527613703005};\\\", \\\"{x:171,y:536,t:1527613703020};\\\", \\\"{x:171,y:542,t:1527613703037};\\\", \\\"{x:171,y:543,t:1527613703054};\\\", \\\"{x:171,y:544,t:1527613703088};\\\", \\\"{x:173,y:546,t:1527613703777};\\\", \\\"{x:183,y:555,t:1527613703788};\\\", \\\"{x:215,y:574,t:1527613703804};\\\", \\\"{x:240,y:591,t:1527613703821};\\\", \\\"{x:286,y:616,t:1527613703839};\\\", \\\"{x:340,y:645,t:1527613703854};\\\", \\\"{x:399,y:676,t:1527613703871};\\\", \\\"{x:480,y:716,t:1527613703888};\\\", \\\"{x:503,y:727,t:1527613703904};\\\", \\\"{x:520,y:731,t:1527613703921};\\\", \\\"{x:523,y:732,t:1527613703938};\\\", \\\"{x:524,y:733,t:1527613703954};\\\", \\\"{x:524,y:731,t:1527613713777};\\\", \\\"{x:520,y:713,t:1527613713788};\\\", \\\"{x:498,y:668,t:1527613713803};\\\", \\\"{x:484,y:641,t:1527613713820};\\\", \\\"{x:450,y:593,t:1527613713843};\\\", \\\"{x:436,y:576,t:1527613713860};\\\", \\\"{x:427,y:564,t:1527613713879};\\\", \\\"{x:423,y:562,t:1527613713896};\\\", \\\"{x:413,y:552,t:1527613713912};\\\", \\\"{x:413,y:551,t:1527613713929};\\\", \\\"{x:412,y:551,t:1527613713946};\\\", \\\"{x:410,y:549,t:1527613713963};\\\", \\\"{x:410,y:546,t:1527613713979};\\\", \\\"{x:409,y:545,t:1527613713995};\\\", \\\"{x:409,y:541,t:1527613714012};\\\", \\\"{x:409,y:539,t:1527613714029};\\\", \\\"{x:412,y:536,t:1527613714045};\\\", \\\"{x:414,y:532,t:1527613714062};\\\", \\\"{x:417,y:529,t:1527613714080};\\\", \\\"{x:420,y:528,t:1527613714096};\\\", \\\"{x:441,y:525,t:1527613714112};\\\", \\\"{x:463,y:524,t:1527613714130};\\\", \\\"{x:488,y:524,t:1527613714147};\\\", \\\"{x:509,y:524,t:1527613714162};\\\", \\\"{x:524,y:527,t:1527613714180};\\\", \\\"{x:531,y:532,t:1527613714197};\\\", \\\"{x:533,y:534,t:1527613714213};\\\", \\\"{x:534,y:537,t:1527613714230};\\\", \\\"{x:534,y:539,t:1527613714247};\\\", \\\"{x:534,y:542,t:1527613714263};\\\", \\\"{x:531,y:547,t:1527613714279};\\\", \\\"{x:527,y:553,t:1527613714297};\\\", \\\"{x:527,y:555,t:1527613714314};\\\", \\\"{x:526,y:556,t:1527613714331};\\\", \\\"{x:525,y:556,t:1527613714346};\\\", \\\"{x:524,y:557,t:1527613714364};\\\", \\\"{x:521,y:558,t:1527613714380};\\\", \\\"{x:514,y:559,t:1527613714396};\\\", \\\"{x:501,y:559,t:1527613714414};\\\", \\\"{x:479,y:559,t:1527613714429};\\\", \\\"{x:433,y:558,t:1527613714447};\\\", \\\"{x:351,y:552,t:1527613714465};\\\", \\\"{x:305,y:547,t:1527613714479};\\\", \\\"{x:247,y:542,t:1527613714497};\\\", \\\"{x:202,y:538,t:1527613714513};\\\", \\\"{x:167,y:538,t:1527613714530};\\\", \\\"{x:150,y:532,t:1527613714546};\\\", \\\"{x:150,y:531,t:1527613714576};\\\", \\\"{x:150,y:526,t:1527613714866};\\\", \\\"{x:152,y:521,t:1527613714881};\\\", \\\"{x:153,y:515,t:1527613714897};\\\", \\\"{x:153,y:512,t:1527613714914};\\\", \\\"{x:155,y:507,t:1527613714930};\\\", \\\"{x:155,y:505,t:1527613714947};\\\", \\\"{x:155,y:504,t:1527613714964};\\\", \\\"{x:156,y:502,t:1527613714984};\\\", \\\"{x:156,y:501,t:1527613715033};\\\", \\\"{x:157,y:500,t:1527613715047};\\\", \\\"{x:158,y:499,t:1527613715121};\\\", \\\"{x:159,y:501,t:1527613715336};\\\", \\\"{x:159,y:504,t:1527613715348};\\\", \\\"{x:160,y:510,t:1527613715364};\\\", \\\"{x:163,y:515,t:1527613715381};\\\", \\\"{x:163,y:517,t:1527613715398};\\\", \\\"{x:164,y:518,t:1527613715414};\\\", \\\"{x:165,y:520,t:1527613715430};\\\", \\\"{x:166,y:521,t:1527613715448};\\\", \\\"{x:166,y:522,t:1527613715561};\\\", \\\"{x:166,y:525,t:1527613716874};\\\", \\\"{x:166,y:528,t:1527613716889};\\\", \\\"{x:166,y:529,t:1527613716899};\\\", \\\"{x:166,y:534,t:1527613716916};\\\", \\\"{x:166,y:536,t:1527613716931};\\\", \\\"{x:166,y:537,t:1527613716949};\\\", \\\"{x:175,y:539,t:1527613717977};\\\", \\\"{x:187,y:541,t:1527613717985};\\\", \\\"{x:252,y:541,t:1527613718001};\\\", \\\"{x:366,y:543,t:1527613718017};\\\", \\\"{x:507,y:558,t:1527613718034};\\\", \\\"{x:672,y:574,t:1527613718050};\\\", \\\"{x:834,y:576,t:1527613718067};\\\", \\\"{x:937,y:595,t:1527613718084};\\\", \\\"{x:946,y:603,t:1527613718100};\\\", \\\"{x:973,y:614,t:1527613718117};\\\", \\\"{x:1008,y:627,t:1527613718133};\\\", \\\"{x:1027,y:634,t:1527613718150};\\\", \\\"{x:1029,y:634,t:1527613718168};\\\", \\\"{x:1030,y:634,t:1527613718199};\\\", \\\"{x:1032,y:635,t:1527613718216};\\\", \\\"{x:1033,y:636,t:1527613718232};\\\", \\\"{x:1035,y:636,t:1527613718296};\\\", \\\"{x:1038,y:636,t:1527613718304};\\\", \\\"{x:1044,y:636,t:1527613718316};\\\", \\\"{x:1059,y:637,t:1527613718333};\\\", \\\"{x:1077,y:642,t:1527613718349};\\\", \\\"{x:1094,y:646,t:1527613718366};\\\", \\\"{x:1115,y:649,t:1527613718383};\\\", \\\"{x:1142,y:651,t:1527613718399};\\\", \\\"{x:1183,y:657,t:1527613718416};\\\", \\\"{x:1232,y:665,t:1527613718433};\\\", \\\"{x:1300,y:679,t:1527613718449};\\\", \\\"{x:1343,y:685,t:1527613718466};\\\", \\\"{x:1365,y:690,t:1527613718483};\\\", \\\"{x:1381,y:693,t:1527613718499};\\\", \\\"{x:1393,y:697,t:1527613718516};\\\", \\\"{x:1400,y:700,t:1527613718532};\\\", \\\"{x:1401,y:701,t:1527613718549};\\\", \\\"{x:1404,y:705,t:1527613718624};\\\", \\\"{x:1405,y:713,t:1527613718632};\\\", \\\"{x:1409,y:728,t:1527613718648};\\\", \\\"{x:1411,y:734,t:1527613718666};\\\", \\\"{x:1407,y:732,t:1527613718873};\\\", \\\"{x:1405,y:732,t:1527613718883};\\\", \\\"{x:1402,y:733,t:1527613718921};\\\", \\\"{x:1401,y:733,t:1527613718932};\\\", \\\"{x:1400,y:730,t:1527613718948};\\\", \\\"{x:1399,y:730,t:1527613718964};\\\", \\\"{x:1398,y:729,t:1527613718992};\\\", \\\"{x:1397,y:727,t:1527613719056};\\\", \\\"{x:1396,y:727,t:1527613719065};\\\", \\\"{x:1395,y:726,t:1527613719082};\\\", \\\"{x:1390,y:726,t:1527613719098};\\\", \\\"{x:1386,y:726,t:1527613719115};\\\", \\\"{x:1384,y:725,t:1527613719132};\\\", \\\"{x:1383,y:725,t:1527613719148};\\\", \\\"{x:1382,y:724,t:1527613719165};\\\", \\\"{x:1380,y:723,t:1527613719182};\\\", \\\"{x:1378,y:723,t:1527613719198};\\\", \\\"{x:1377,y:723,t:1527613719215};\\\", \\\"{x:1376,y:723,t:1527613719231};\\\", \\\"{x:1373,y:723,t:1527613719247};\\\", \\\"{x:1372,y:723,t:1527613719279};\\\", \\\"{x:1371,y:723,t:1527613719287};\\\", \\\"{x:1369,y:723,t:1527613719303};\\\", \\\"{x:1367,y:723,t:1527613719328};\\\", \\\"{x:1365,y:723,t:1527613719344};\\\", \\\"{x:1364,y:723,t:1527613719352};\\\", \\\"{x:1363,y:723,t:1527613719368};\\\", \\\"{x:1362,y:723,t:1527613719391};\\\", \\\"{x:1360,y:721,t:1527613719472};\\\", \\\"{x:1360,y:720,t:1527613719481};\\\", \\\"{x:1358,y:714,t:1527613719498};\\\", \\\"{x:1356,y:710,t:1527613719514};\\\", \\\"{x:1354,y:707,t:1527613719531};\\\", \\\"{x:1352,y:703,t:1527613719548};\\\", \\\"{x:1351,y:699,t:1527613719565};\\\", \\\"{x:1349,y:695,t:1527613719581};\\\", \\\"{x:1348,y:693,t:1527613719598};\\\", \\\"{x:1348,y:690,t:1527613719615};\\\", \\\"{x:1348,y:688,t:1527613719631};\\\", \\\"{x:1347,y:686,t:1527613719648};\\\", \\\"{x:1347,y:685,t:1527613719672};\\\", \\\"{x:1349,y:692,t:1527613719817};\\\", \\\"{x:1351,y:706,t:1527613719832};\\\", \\\"{x:1358,y:734,t:1527613719847};\\\", \\\"{x:1369,y:779,t:1527613719864};\\\", \\\"{x:1373,y:805,t:1527613719879};\\\", \\\"{x:1374,y:822,t:1527613719897};\\\", \\\"{x:1375,y:832,t:1527613719914};\\\", \\\"{x:1375,y:834,t:1527613719930};\\\", \\\"{x:1375,y:835,t:1527613720058};\\\", \\\"{x:1374,y:835,t:1527613720065};\\\", \\\"{x:1371,y:826,t:1527613720081};\\\", \\\"{x:1365,y:821,t:1527613720097};\\\", \\\"{x:1365,y:820,t:1527613720114};\\\", \\\"{x:1364,y:820,t:1527613720145};\\\", \\\"{x:1360,y:819,t:1527613720153};\\\", \\\"{x:1351,y:815,t:1527613720169};\\\", \\\"{x:1330,y:815,t:1527613720185};\\\", \\\"{x:1265,y:818,t:1527613720197};\\\", \\\"{x:1161,y:809,t:1527613720214};\\\", \\\"{x:1125,y:800,t:1527613720231};\\\", \\\"{x:1102,y:793,t:1527613720246};\\\", \\\"{x:1081,y:784,t:1527613720263};\\\", \\\"{x:1069,y:779,t:1527613720280};\\\", \\\"{x:1069,y:778,t:1527613720297};\\\", \\\"{x:1069,y:777,t:1527613720384};\\\", \\\"{x:1069,y:776,t:1527613720416};\\\", \\\"{x:1069,y:774,t:1527613720440};\\\", \\\"{x:1068,y:772,t:1527613720449};\\\", \\\"{x:1068,y:768,t:1527613720463};\\\", \\\"{x:1067,y:758,t:1527613720480};\\\", \\\"{x:1066,y:753,t:1527613720496};\\\", \\\"{x:1066,y:751,t:1527613720513};\\\", \\\"{x:1066,y:750,t:1527613720530};\\\", \\\"{x:1063,y:748,t:1527613720553};\\\", \\\"{x:1060,y:745,t:1527613720563};\\\", \\\"{x:1046,y:720,t:1527613720580};\\\", \\\"{x:1034,y:704,t:1527613720597};\\\", \\\"{x:1025,y:694,t:1527613720613};\\\", \\\"{x:1010,y:675,t:1527613720630};\\\", \\\"{x:990,y:650,t:1527613720646};\\\", \\\"{x:943,y:612,t:1527613720666};\\\", \\\"{x:878,y:575,t:1527613720679};\\\", \\\"{x:781,y:523,t:1527613720702};\\\", \\\"{x:688,y:488,t:1527613720720};\\\", \\\"{x:566,y:430,t:1527613720735};\\\", \\\"{x:331,y:343,t:1527613720752};\\\", \\\"{x:190,y:300,t:1527613720769};\\\", \\\"{x:50,y:265,t:1527613720785};\\\", \\\"{x:0,y:243,t:1527613720801};\\\", \\\"{x:0,y:227,t:1527613720818};\\\", \\\"{x:0,y:211,t:1527613720834};\\\", \\\"{x:0,y:196,t:1527613720852};\\\", \\\"{x:0,y:189,t:1527613720868};\\\", \\\"{x:0,y:186,t:1527613720884};\\\", \\\"{x:0,y:185,t:1527613720902};\\\", \\\"{x:10,y:186,t:1527613721000};\\\", \\\"{x:30,y:193,t:1527613721008};\\\", \\\"{x:47,y:204,t:1527613721018};\\\", \\\"{x:132,y:239,t:1527613721036};\\\", \\\"{x:204,y:284,t:1527613721052};\\\", \\\"{x:274,y:335,t:1527613721068};\\\", \\\"{x:348,y:393,t:1527613721085};\\\", \\\"{x:398,y:435,t:1527613721103};\\\", \\\"{x:440,y:465,t:1527613721118};\\\", \\\"{x:493,y:501,t:1527613721136};\\\", \\\"{x:560,y:537,t:1527613721154};\\\", \\\"{x:588,y:551,t:1527613721169};\\\", \\\"{x:643,y:568,t:1527613721186};\\\", \\\"{x:691,y:592,t:1527613721202};\\\", \\\"{x:728,y:610,t:1527613721219};\\\", \\\"{x:747,y:617,t:1527613721235};\\\", \\\"{x:762,y:617,t:1527613721251};\\\", \\\"{x:766,y:616,t:1527613721269};\\\", \\\"{x:769,y:615,t:1527613721311};\\\", \\\"{x:771,y:613,t:1527613721319};\\\", \\\"{x:773,y:611,t:1527613721336};\\\", \\\"{x:775,y:604,t:1527613721352};\\\", \\\"{x:778,y:595,t:1527613721369};\\\", \\\"{x:779,y:582,t:1527613721387};\\\", \\\"{x:785,y:571,t:1527613721401};\\\", \\\"{x:788,y:567,t:1527613721419};\\\", \\\"{x:789,y:564,t:1527613721436};\\\", \\\"{x:792,y:558,t:1527613721452};\\\", \\\"{x:793,y:552,t:1527613721469};\\\", \\\"{x:796,y:548,t:1527613721485};\\\", \\\"{x:796,y:544,t:1527613721501};\\\", \\\"{x:797,y:541,t:1527613721518};\\\", \\\"{x:797,y:530,t:1527613721535};\\\", \\\"{x:797,y:526,t:1527613721552};\\\", \\\"{x:797,y:523,t:1527613721570};\\\", \\\"{x:797,y:518,t:1527613721586};\\\", \\\"{x:797,y:516,t:1527613721603};\\\", \\\"{x:798,y:514,t:1527613721619};\\\", \\\"{x:799,y:513,t:1527613721636};\\\", \\\"{x:802,y:509,t:1527613721653};\\\", \\\"{x:805,y:507,t:1527613721669};\\\", \\\"{x:811,y:501,t:1527613721686};\\\", \\\"{x:815,y:495,t:1527613721703};\\\", \\\"{x:818,y:493,t:1527613721719};\\\", \\\"{x:819,y:492,t:1527613721736};\\\", \\\"{x:820,y:492,t:1527613722152};\\\", \\\"{x:815,y:493,t:1527613722233};\\\", \\\"{x:808,y:498,t:1527613722240};\\\", \\\"{x:800,y:506,t:1527613722254};\\\", \\\"{x:770,y:539,t:1527613722271};\\\", \\\"{x:682,y:597,t:1527613722287};\\\", \\\"{x:594,y:634,t:1527613722302};\\\", \\\"{x:459,y:695,t:1527613722319};\\\", \\\"{x:370,y:739,t:1527613722336};\\\", \\\"{x:315,y:762,t:1527613722352};\\\", \\\"{x:257,y:786,t:1527613722370};\\\", \\\"{x:223,y:798,t:1527613722386};\\\", \\\"{x:204,y:804,t:1527613722403};\\\", \\\"{x:196,y:808,t:1527613722420};\\\", \\\"{x:194,y:808,t:1527613722436};\\\", \\\"{x:194,y:807,t:1527613722576};\\\", \\\"{x:195,y:801,t:1527613722586};\\\", \\\"{x:204,y:783,t:1527613722603};\\\", \\\"{x:211,y:766,t:1527613722620};\\\", \\\"{x:219,y:739,t:1527613722637};\\\", \\\"{x:230,y:719,t:1527613722652};\\\", \\\"{x:238,y:703,t:1527613722670};\\\", \\\"{x:254,y:681,t:1527613722687};\\\", \\\"{x:270,y:663,t:1527613722703};\\\", \\\"{x:291,y:635,t:1527613722720};\\\", \\\"{x:299,y:617,t:1527613722737};\\\", \\\"{x:301,y:611,t:1527613722754};\\\", \\\"{x:302,y:610,t:1527613722770};\\\", \\\"{x:302,y:609,t:1527613722786};\\\", \\\"{x:302,y:608,t:1527613722920};\\\", \\\"{x:304,y:608,t:1527613722936};\\\", \\\"{x:309,y:604,t:1527613722953};\\\", \\\"{x:324,y:603,t:1527613722970};\\\", \\\"{x:347,y:602,t:1527613722987};\\\", \\\"{x:413,y:599,t:1527613723004};\\\", \\\"{x:469,y:589,t:1527613723020};\\\", \\\"{x:565,y:581,t:1527613723037};\\\", \\\"{x:653,y:560,t:1527613723053};\\\", \\\"{x:703,y:534,t:1527613723070};\\\", \\\"{x:800,y:504,t:1527613723087};\\\", \\\"{x:896,y:484,t:1527613723104};\\\", \\\"{x:949,y:474,t:1527613723120};\\\", \\\"{x:979,y:470,t:1527613723137};\\\", \\\"{x:997,y:468,t:1527613723154};\\\", \\\"{x:1009,y:464,t:1527613723170};\\\", \\\"{x:1011,y:463,t:1527613723186};\\\", \\\"{x:1012,y:463,t:1527613723204};\\\", \\\"{x:1011,y:464,t:1527613723338};\\\", \\\"{x:1002,y:466,t:1527613723355};\\\", \\\"{x:986,y:474,t:1527613723371};\\\", \\\"{x:972,y:481,t:1527613723386};\\\", \\\"{x:943,y:493,t:1527613723405};\\\", \\\"{x:922,y:500,t:1527613723421};\\\", \\\"{x:904,y:508,t:1527613723437};\\\", \\\"{x:890,y:514,t:1527613723454};\\\", \\\"{x:884,y:515,t:1527613723471};\\\", \\\"{x:877,y:515,t:1527613723489};\\\", \\\"{x:876,y:517,t:1527613723504};\\\", \\\"{x:875,y:517,t:1527613723585};\\\", \\\"{x:873,y:517,t:1527613723608};\\\", \\\"{x:871,y:517,t:1527613723621};\\\", \\\"{x:871,y:518,t:1527613723639};\\\", \\\"{x:863,y:516,t:1527613723689};\\\", \\\"{x:862,y:514,t:1527613723703};\\\", \\\"{x:860,y:512,t:1527613723721};\\\", \\\"{x:859,y:511,t:1527613723738};\\\", \\\"{x:859,y:510,t:1527613723753};\\\", \\\"{x:859,y:509,t:1527613724072};\\\", \\\"{x:854,y:509,t:1527613724088};\\\", \\\"{x:848,y:509,t:1527613724104};\\\", \\\"{x:831,y:509,t:1527613724122};\\\", \\\"{x:813,y:511,t:1527613724138};\\\", \\\"{x:775,y:515,t:1527613724155};\\\", \\\"{x:704,y:527,t:1527613724171};\\\", \\\"{x:615,y:526,t:1527613724188};\\\", \\\"{x:515,y:526,t:1527613724204};\\\", \\\"{x:432,y:536,t:1527613724221};\\\", \\\"{x:340,y:552,t:1527613724237};\\\", \\\"{x:242,y:569,t:1527613724256};\\\", \\\"{x:173,y:587,t:1527613724271};\\\", \\\"{x:131,y:600,t:1527613724288};\\\", \\\"{x:115,y:611,t:1527613724306};\\\", \\\"{x:111,y:614,t:1527613724321};\\\", \\\"{x:111,y:615,t:1527613724352};\\\", \\\"{x:112,y:617,t:1527613724384};\\\", \\\"{x:115,y:620,t:1527613724392};\\\", \\\"{x:119,y:624,t:1527613724405};\\\", \\\"{x:123,y:631,t:1527613724422};\\\", \\\"{x:125,y:636,t:1527613724440};\\\", \\\"{x:126,y:639,t:1527613724456};\\\", \\\"{x:128,y:643,t:1527613724472};\\\", \\\"{x:131,y:646,t:1527613724488};\\\", \\\"{x:133,y:646,t:1527613724505};\\\", \\\"{x:136,y:646,t:1527613724522};\\\", \\\"{x:137,y:646,t:1527613724538};\\\", \\\"{x:140,y:646,t:1527613724555};\\\", \\\"{x:142,y:644,t:1527613724573};\\\", \\\"{x:143,y:644,t:1527613724592};\\\", \\\"{x:144,y:642,t:1527613724605};\\\", \\\"{x:146,y:640,t:1527613724622};\\\", \\\"{x:149,y:636,t:1527613724639};\\\", \\\"{x:151,y:635,t:1527613724655};\\\", \\\"{x:152,y:634,t:1527613724672};\\\", \\\"{x:154,y:630,t:1527613724688};\\\", \\\"{x:155,y:630,t:1527613724704};\\\", \\\"{x:157,y:630,t:1527613724722};\\\", \\\"{x:158,y:629,t:1527613724738};\\\", \\\"{x:159,y:628,t:1527613724755};\\\", \\\"{x:163,y:626,t:1527613724801};\\\", \\\"{x:168,y:625,t:1527613724821};\\\", \\\"{x:170,y:622,t:1527613724838};\\\", \\\"{x:172,y:621,t:1527613724855};\\\", \\\"{x:174,y:618,t:1527613724871};\\\", \\\"{x:176,y:615,t:1527613724889};\\\", \\\"{x:177,y:615,t:1527613724905};\\\", \\\"{x:178,y:612,t:1527613724922};\\\", \\\"{x:178,y:610,t:1527613724938};\\\", \\\"{x:178,y:609,t:1527613724955};\\\", \\\"{x:179,y:606,t:1527613724972};\\\", \\\"{x:179,y:600,t:1527613724990};\\\", \\\"{x:179,y:594,t:1527613725005};\\\", \\\"{x:178,y:588,t:1527613725023};\\\", \\\"{x:176,y:582,t:1527613725039};\\\", \\\"{x:174,y:579,t:1527613725054};\\\", \\\"{x:172,y:574,t:1527613725072};\\\", \\\"{x:170,y:572,t:1527613725089};\\\", \\\"{x:169,y:571,t:1527613725104};\\\", \\\"{x:169,y:568,t:1527613725122};\\\", \\\"{x:169,y:566,t:1527613725248};\\\", \\\"{x:169,y:565,t:1527613725256};\\\", \\\"{x:169,y:561,t:1527613725272};\\\", \\\"{x:169,y:558,t:1527613725289};\\\", \\\"{x:169,y:557,t:1527613725305};\\\", \\\"{x:169,y:554,t:1527613725323};\\\", \\\"{x:169,y:552,t:1527613725339};\\\", \\\"{x:169,y:548,t:1527613725356};\\\", \\\"{x:168,y:547,t:1527613725372};\\\", \\\"{x:167,y:545,t:1527613725389};\\\", \\\"{x:167,y:542,t:1527613725406};\\\", \\\"{x:167,y:540,t:1527613725422};\\\", \\\"{x:167,y:539,t:1527613725439};\\\", \\\"{x:167,y:538,t:1527613725455};\\\", \\\"{x:167,y:537,t:1527613725512};\\\", \\\"{x:167,y:538,t:1527613725848};\\\", \\\"{x:173,y:544,t:1527613725857};\\\", \\\"{x:192,y:555,t:1527613725872};\\\", \\\"{x:225,y:575,t:1527613725889};\\\", \\\"{x:267,y:606,t:1527613725906};\\\", \\\"{x:315,y:630,t:1527613725924};\\\", \\\"{x:353,y:655,t:1527613725940};\\\", \\\"{x:370,y:669,t:1527613725956};\\\", \\\"{x:397,y:686,t:1527613725973};\\\", \\\"{x:417,y:694,t:1527613725990};\\\", \\\"{x:428,y:701,t:1527613726006};\\\", \\\"{x:429,y:701,t:1527613726023};\\\", \\\"{x:429,y:702,t:1527613726192};\\\", \\\"{x:429,y:705,t:1527613726206};\\\", \\\"{x:432,y:715,t:1527613726223};\\\", \\\"{x:435,y:717,t:1527613726240};\\\", \\\"{x:438,y:718,t:1527613726280};\\\", \\\"{x:440,y:721,t:1527613726290};\\\", \\\"{x:442,y:722,t:1527613726307};\\\", \\\"{x:445,y:725,t:1527613726324};\\\", \\\"{x:447,y:726,t:1527613726340};\\\" ] }, { \\\"rt\\\": 28366, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 12, \\\"time_elapsed\\\": 430029, \\\"internal_node_id\\\": \\\"0.0-6.0-2.0\\\", \\\"subject\\\": \\\"AZKMW\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"oscar\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+contained\\\", \\\"q\\\": 8, \\\"clicks\\\": 4, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"I\\\", \\\"J\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-B -J \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:439,y:730,t:1527613730810};\\\", \\\"{x:423,y:735,t:1527613730834};\\\", \\\"{x:422,y:736,t:1527613730845};\\\", \\\"{x:416,y:738,t:1527613730860};\\\", \\\"{x:411,y:742,t:1527613730877};\\\", \\\"{x:409,y:751,t:1527613730892};\\\", \\\"{x:406,y:756,t:1527613730910};\\\", \\\"{x:403,y:759,t:1527613730927};\\\", \\\"{x:401,y:759,t:1527613730943};\\\", \\\"{x:415,y:744,t:1527613731489};\\\", \\\"{x:433,y:721,t:1527613731496};\\\", \\\"{x:458,y:705,t:1527613731512};\\\", \\\"{x:481,y:677,t:1527613731528};\\\", \\\"{x:490,y:653,t:1527613731547};\\\", \\\"{x:493,y:602,t:1527613731562};\\\", \\\"{x:486,y:543,t:1527613731578};\\\", \\\"{x:483,y:535,t:1527613731594};\\\", \\\"{x:482,y:534,t:1527613736689};\\\", \\\"{x:484,y:533,t:1527613736720};\\\", \\\"{x:488,y:533,t:1527613736731};\\\", \\\"{x:509,y:533,t:1527613736751};\\\", \\\"{x:519,y:533,t:1527613736764};\\\", \\\"{x:520,y:533,t:1527613736781};\\\", \\\"{x:522,y:532,t:1527613736799};\\\", \\\"{x:528,y:531,t:1527613736816};\\\", \\\"{x:541,y:529,t:1527613736831};\\\", \\\"{x:550,y:527,t:1527613736848};\\\", \\\"{x:554,y:525,t:1527613736865};\\\", \\\"{x:557,y:525,t:1527613736881};\\\", \\\"{x:559,y:525,t:1527613736898};\\\", \\\"{x:562,y:525,t:1527613736915};\\\", \\\"{x:564,y:525,t:1527613736932};\\\", \\\"{x:561,y:525,t:1527613737473};\\\", \\\"{x:555,y:527,t:1527613737483};\\\", \\\"{x:546,y:529,t:1527613737500};\\\", \\\"{x:534,y:532,t:1527613737517};\\\", \\\"{x:517,y:538,t:1527613737533};\\\", \\\"{x:513,y:539,t:1527613737550};\\\", \\\"{x:512,y:540,t:1527613737567};\\\", \\\"{x:510,y:541,t:1527613737583};\\\", \\\"{x:510,y:535,t:1527613737801};\\\", \\\"{x:510,y:526,t:1527613737816};\\\", \\\"{x:511,y:522,t:1527613737835};\\\", \\\"{x:511,y:516,t:1527613737851};\\\", \\\"{x:513,y:511,t:1527613737867};\\\", \\\"{x:516,y:504,t:1527613737883};\\\", \\\"{x:519,y:499,t:1527613737899};\\\", \\\"{x:529,y:489,t:1527613737915};\\\", \\\"{x:539,y:479,t:1527613737933};\\\", \\\"{x:558,y:466,t:1527613737950};\\\", \\\"{x:594,y:452,t:1527613737965};\\\", \\\"{x:635,y:435,t:1527613737982};\\\", \\\"{x:734,y:413,t:1527613737999};\\\", \\\"{x:811,y:397,t:1527613738015};\\\", \\\"{x:903,y:379,t:1527613738033};\\\", \\\"{x:1023,y:358,t:1527613738049};\\\", \\\"{x:1161,y:339,t:1527613738065};\\\", \\\"{x:1313,y:322,t:1527613738082};\\\", \\\"{x:1458,y:311,t:1527613738099};\\\", \\\"{x:1627,y:285,t:1527613738116};\\\", \\\"{x:1746,y:270,t:1527613738132};\\\", \\\"{x:1821,y:261,t:1527613738150};\\\", \\\"{x:1835,y:256,t:1527613738167};\\\", \\\"{x:1840,y:255,t:1527613738182};\\\", \\\"{x:1841,y:255,t:1527613738200};\\\", \\\"{x:1838,y:256,t:1527613738249};\\\", \\\"{x:1831,y:262,t:1527613738256};\\\", \\\"{x:1825,y:267,t:1527613738267};\\\", \\\"{x:1807,y:285,t:1527613738283};\\\", \\\"{x:1787,y:305,t:1527613738300};\\\", \\\"{x:1762,y:322,t:1527613738317};\\\", \\\"{x:1720,y:348,t:1527613738333};\\\", \\\"{x:1692,y:367,t:1527613738350};\\\", \\\"{x:1680,y:373,t:1527613738367};\\\", \\\"{x:1678,y:375,t:1527613738383};\\\", \\\"{x:1677,y:376,t:1527613738400};\\\", \\\"{x:1675,y:376,t:1527613738497};\\\", \\\"{x:1664,y:386,t:1527613738504};\\\", \\\"{x:1653,y:400,t:1527613738517};\\\", \\\"{x:1626,y:432,t:1527613738533};\\\", \\\"{x:1598,y:454,t:1527613738550};\\\", \\\"{x:1560,y:475,t:1527613738567};\\\", \\\"{x:1521,y:497,t:1527613738584};\\\", \\\"{x:1504,y:503,t:1527613738601};\\\", \\\"{x:1481,y:517,t:1527613738617};\\\", \\\"{x:1465,y:529,t:1527613738634};\\\", \\\"{x:1453,y:536,t:1527613738650};\\\", \\\"{x:1445,y:538,t:1527613738667};\\\", \\\"{x:1444,y:538,t:1527613738684};\\\", \\\"{x:1445,y:532,t:1527613738936};\\\", \\\"{x:1445,y:531,t:1527613738950};\\\", \\\"{x:1447,y:524,t:1527613738967};\\\", \\\"{x:1450,y:516,t:1527613738984};\\\", \\\"{x:1450,y:515,t:1527613739000};\\\", \\\"{x:1450,y:513,t:1527613739018};\\\", \\\"{x:1450,y:512,t:1527613739177};\\\", \\\"{x:1450,y:510,t:1527613739185};\\\", \\\"{x:1450,y:509,t:1527613739201};\\\", \\\"{x:1446,y:509,t:1527613739473};\\\", \\\"{x:1437,y:508,t:1527613739484};\\\", \\\"{x:1424,y:508,t:1527613739501};\\\", \\\"{x:1416,y:505,t:1527613739518};\\\", \\\"{x:1397,y:504,t:1527613739533};\\\", \\\"{x:1377,y:503,t:1527613739551};\\\", \\\"{x:1350,y:503,t:1527613739568};\\\", \\\"{x:1340,y:503,t:1527613739585};\\\", \\\"{x:1334,y:503,t:1527613739601};\\\", \\\"{x:1335,y:503,t:1527613739992};\\\", \\\"{x:1338,y:501,t:1527613740001};\\\", \\\"{x:1342,y:501,t:1527613740019};\\\", \\\"{x:1348,y:500,t:1527613740035};\\\", \\\"{x:1364,y:499,t:1527613740051};\\\", \\\"{x:1371,y:499,t:1527613740068};\\\", \\\"{x:1386,y:498,t:1527613740085};\\\", \\\"{x:1403,y:496,t:1527613740101};\\\", \\\"{x:1416,y:495,t:1527613740119};\\\", \\\"{x:1427,y:495,t:1527613740135};\\\", \\\"{x:1438,y:495,t:1527613740151};\\\", \\\"{x:1446,y:495,t:1527613740169};\\\", \\\"{x:1447,y:495,t:1527613740185};\\\", \\\"{x:1450,y:495,t:1527613740201};\\\", \\\"{x:1451,y:495,t:1527613740218};\\\", \\\"{x:1452,y:495,t:1527613740235};\\\", \\\"{x:1453,y:495,t:1527613740251};\\\", \\\"{x:1455,y:495,t:1527613740267};\\\", \\\"{x:1456,y:496,t:1527613740285};\\\", \\\"{x:1459,y:497,t:1527613740301};\\\", \\\"{x:1465,y:499,t:1527613740318};\\\", \\\"{x:1469,y:501,t:1527613740335};\\\", \\\"{x:1476,y:503,t:1527613740351};\\\", \\\"{x:1482,y:504,t:1527613740367};\\\", \\\"{x:1488,y:505,t:1527613740384};\\\", \\\"{x:1494,y:506,t:1527613740401};\\\", \\\"{x:1499,y:508,t:1527613740417};\\\", \\\"{x:1500,y:508,t:1527613740435};\\\", \\\"{x:1501,y:508,t:1527613740456};\\\", \\\"{x:1501,y:510,t:1527613743897};\\\", \\\"{x:1501,y:511,t:1527613743945};\\\", \\\"{x:1498,y:514,t:1527613743953};\\\", \\\"{x:1497,y:514,t:1527613743971};\\\", \\\"{x:1497,y:515,t:1527613743988};\\\", \\\"{x:1495,y:516,t:1527613744004};\\\", \\\"{x:1494,y:517,t:1527613744023};\\\", \\\"{x:1493,y:518,t:1527613744038};\\\", \\\"{x:1489,y:522,t:1527613744053};\\\", \\\"{x:1481,y:528,t:1527613744070};\\\", \\\"{x:1475,y:536,t:1527613744088};\\\", \\\"{x:1469,y:542,t:1527613744104};\\\", \\\"{x:1458,y:550,t:1527613744121};\\\", \\\"{x:1444,y:562,t:1527613744137};\\\", \\\"{x:1440,y:567,t:1527613744154};\\\", \\\"{x:1434,y:572,t:1527613744172};\\\", \\\"{x:1426,y:578,t:1527613744187};\\\", \\\"{x:1422,y:581,t:1527613744204};\\\", \\\"{x:1418,y:584,t:1527613744221};\\\", \\\"{x:1412,y:589,t:1527613744237};\\\", \\\"{x:1409,y:591,t:1527613744255};\\\", \\\"{x:1408,y:591,t:1527613744545};\\\", \\\"{x:1408,y:589,t:1527613744556};\\\", \\\"{x:1408,y:587,t:1527613744571};\\\", \\\"{x:1408,y:585,t:1527613744588};\\\", \\\"{x:1408,y:584,t:1527613744616};\\\", \\\"{x:1408,y:583,t:1527613744624};\\\", \\\"{x:1408,y:582,t:1527613744673};\\\", \\\"{x:1407,y:581,t:1527613744849};\\\", \\\"{x:1406,y:582,t:1527613744856};\\\", \\\"{x:1404,y:585,t:1527613744873};\\\", \\\"{x:1403,y:588,t:1527613744888};\\\", \\\"{x:1400,y:592,t:1527613744905};\\\", \\\"{x:1400,y:594,t:1527613744923};\\\", \\\"{x:1400,y:596,t:1527613744939};\\\", \\\"{x:1399,y:597,t:1527613744954};\\\", \\\"{x:1399,y:598,t:1527613744971};\\\", \\\"{x:1398,y:600,t:1527613744988};\\\", \\\"{x:1398,y:603,t:1527613745004};\\\", \\\"{x:1398,y:605,t:1527613745021};\\\", \\\"{x:1398,y:607,t:1527613745037};\\\", \\\"{x:1397,y:609,t:1527613745055};\\\", \\\"{x:1397,y:616,t:1527613745071};\\\", \\\"{x:1399,y:634,t:1527613745089};\\\", \\\"{x:1403,y:650,t:1527613745105};\\\", \\\"{x:1403,y:665,t:1527613745121};\\\", \\\"{x:1403,y:672,t:1527613745138};\\\", \\\"{x:1401,y:680,t:1527613745155};\\\", \\\"{x:1401,y:690,t:1527613745172};\\\", \\\"{x:1401,y:699,t:1527613745188};\\\", \\\"{x:1399,y:700,t:1527613745205};\\\", \\\"{x:1399,y:702,t:1527613745222};\\\", \\\"{x:1398,y:705,t:1527613745240};\\\", \\\"{x:1394,y:710,t:1527613745256};\\\", \\\"{x:1389,y:715,t:1527613745273};\\\", \\\"{x:1389,y:716,t:1527613745296};\\\", \\\"{x:1388,y:716,t:1527613745320};\\\", \\\"{x:1387,y:718,t:1527613745389};\\\", \\\"{x:1385,y:718,t:1527613745404};\\\", \\\"{x:1384,y:718,t:1527613745492};\\\", \\\"{x:1384,y:719,t:1527613745524};\\\", \\\"{x:1382,y:720,t:1527613745540};\\\", \\\"{x:1380,y:720,t:1527613745548};\\\", \\\"{x:1379,y:722,t:1527613745559};\\\", \\\"{x:1376,y:725,t:1527613745577};\\\", \\\"{x:1373,y:727,t:1527613745594};\\\", \\\"{x:1368,y:730,t:1527613745611};\\\", \\\"{x:1360,y:736,t:1527613745626};\\\", \\\"{x:1354,y:741,t:1527613745643};\\\", \\\"{x:1346,y:750,t:1527613745661};\\\", \\\"{x:1343,y:754,t:1527613745676};\\\", \\\"{x:1342,y:758,t:1527613745693};\\\", \\\"{x:1342,y:759,t:1527613745932};\\\", \\\"{x:1342,y:756,t:1527613746085};\\\", \\\"{x:1342,y:752,t:1527613746093};\\\", \\\"{x:1342,y:747,t:1527613746110};\\\", \\\"{x:1344,y:742,t:1527613746127};\\\", \\\"{x:1344,y:739,t:1527613746143};\\\", \\\"{x:1344,y:736,t:1527613746161};\\\", \\\"{x:1344,y:735,t:1527613746177};\\\", \\\"{x:1344,y:731,t:1527613746194};\\\", \\\"{x:1344,y:729,t:1527613746210};\\\", \\\"{x:1345,y:725,t:1527613746227};\\\", \\\"{x:1345,y:722,t:1527613746260};\\\", \\\"{x:1346,y:720,t:1527613746277};\\\", \\\"{x:1347,y:718,t:1527613746294};\\\", \\\"{x:1348,y:716,t:1527613746310};\\\", \\\"{x:1348,y:713,t:1527613746327};\\\", \\\"{x:1348,y:712,t:1527613746343};\\\", \\\"{x:1350,y:708,t:1527613746361};\\\", \\\"{x:1351,y:707,t:1527613746378};\\\", \\\"{x:1351,y:704,t:1527613746393};\\\", \\\"{x:1353,y:701,t:1527613746411};\\\", \\\"{x:1355,y:698,t:1527613746427};\\\", \\\"{x:1355,y:696,t:1527613746444};\\\", \\\"{x:1355,y:695,t:1527613746460};\\\", \\\"{x:1355,y:694,t:1527613746483};\\\", \\\"{x:1356,y:693,t:1527613746507};\\\", \\\"{x:1357,y:692,t:1527613748108};\\\", \\\"{x:1357,y:690,t:1527613748133};\\\", \\\"{x:1357,y:688,t:1527613748146};\\\", \\\"{x:1357,y:692,t:1527613749541};\\\", \\\"{x:1357,y:696,t:1527613749548};\\\", \\\"{x:1357,y:702,t:1527613749563};\\\", \\\"{x:1358,y:708,t:1527613749579};\\\", \\\"{x:1358,y:723,t:1527613749596};\\\", \\\"{x:1358,y:739,t:1527613749614};\\\", \\\"{x:1358,y:753,t:1527613749630};\\\", \\\"{x:1358,y:762,t:1527613749646};\\\", \\\"{x:1357,y:769,t:1527613749663};\\\", \\\"{x:1357,y:773,t:1527613749680};\\\", \\\"{x:1357,y:777,t:1527613749696};\\\", \\\"{x:1356,y:780,t:1527613749713};\\\", \\\"{x:1356,y:784,t:1527613749729};\\\", \\\"{x:1355,y:786,t:1527613749747};\\\", \\\"{x:1354,y:789,t:1527613749764};\\\", \\\"{x:1352,y:793,t:1527613749780};\\\", \\\"{x:1350,y:798,t:1527613749796};\\\", \\\"{x:1347,y:802,t:1527613749814};\\\", \\\"{x:1344,y:805,t:1527613749829};\\\", \\\"{x:1342,y:807,t:1527613749846};\\\", \\\"{x:1334,y:812,t:1527613749863};\\\", \\\"{x:1330,y:813,t:1527613749880};\\\", \\\"{x:1325,y:816,t:1527613749896};\\\", \\\"{x:1320,y:818,t:1527613749913};\\\", \\\"{x:1314,y:821,t:1527613749930};\\\", \\\"{x:1305,y:824,t:1527613749946};\\\", \\\"{x:1297,y:827,t:1527613749964};\\\", \\\"{x:1279,y:834,t:1527613749981};\\\", \\\"{x:1267,y:838,t:1527613749996};\\\", \\\"{x:1257,y:841,t:1527613750013};\\\", \\\"{x:1245,y:845,t:1527613750031};\\\", \\\"{x:1237,y:848,t:1527613750046};\\\", \\\"{x:1233,y:850,t:1527613750064};\\\", \\\"{x:1231,y:850,t:1527613750080};\\\", \\\"{x:1230,y:850,t:1527613750097};\\\", \\\"{x:1230,y:851,t:1527613750113};\\\", \\\"{x:1228,y:851,t:1527613750228};\\\", \\\"{x:1228,y:850,t:1527613750236};\\\", \\\"{x:1227,y:849,t:1527613750247};\\\", \\\"{x:1226,y:845,t:1527613750264};\\\", \\\"{x:1224,y:843,t:1527613750281};\\\", \\\"{x:1224,y:842,t:1527613750339};\\\", \\\"{x:1224,y:841,t:1527613750347};\\\", \\\"{x:1223,y:839,t:1527613750363};\\\", \\\"{x:1219,y:834,t:1527613750379};\\\", \\\"{x:1215,y:829,t:1527613750398};\\\", \\\"{x:1208,y:823,t:1527613750413};\\\", \\\"{x:1205,y:821,t:1527613750430};\\\", \\\"{x:1204,y:820,t:1527613750447};\\\", \\\"{x:1203,y:819,t:1527613750463};\\\", \\\"{x:1202,y:819,t:1527613750480};\\\", \\\"{x:1201,y:817,t:1527613750497};\\\", \\\"{x:1200,y:816,t:1527613750513};\\\", \\\"{x:1198,y:812,t:1527613750530};\\\", \\\"{x:1196,y:807,t:1527613750547};\\\", \\\"{x:1196,y:805,t:1527613750563};\\\", \\\"{x:1188,y:794,t:1527613750580};\\\", \\\"{x:1183,y:787,t:1527613750598};\\\", \\\"{x:1175,y:780,t:1527613750613};\\\", \\\"{x:1169,y:771,t:1527613750630};\\\", \\\"{x:1165,y:765,t:1527613750648};\\\", \\\"{x:1160,y:760,t:1527613750664};\\\", \\\"{x:1154,y:747,t:1527613750680};\\\", \\\"{x:1146,y:733,t:1527613750698};\\\", \\\"{x:1140,y:723,t:1527613750713};\\\", \\\"{x:1137,y:718,t:1527613750731};\\\", \\\"{x:1136,y:718,t:1527613750965};\\\", \\\"{x:1115,y:719,t:1527613750980};\\\", \\\"{x:1093,y:719,t:1527613750998};\\\", \\\"{x:1036,y:716,t:1527613751014};\\\", \\\"{x:957,y:709,t:1527613751031};\\\", \\\"{x:833,y:694,t:1527613751047};\\\", \\\"{x:746,y:679,t:1527613751065};\\\", \\\"{x:626,y:657,t:1527613751080};\\\", \\\"{x:512,y:624,t:1527613751099};\\\", \\\"{x:421,y:600,t:1527613751114};\\\", \\\"{x:399,y:588,t:1527613751130};\\\", \\\"{x:388,y:584,t:1527613751147};\\\", \\\"{x:383,y:582,t:1527613751163};\\\", \\\"{x:382,y:582,t:1527613751275};\\\", \\\"{x:382,y:581,t:1527613751283};\\\", \\\"{x:382,y:580,t:1527613751307};\\\", \\\"{x:384,y:579,t:1527613751315};\\\", \\\"{x:384,y:576,t:1527613751331};\\\", \\\"{x:390,y:568,t:1527613751348};\\\", \\\"{x:392,y:568,t:1527613751363};\\\", \\\"{x:396,y:561,t:1527613751382};\\\", \\\"{x:398,y:558,t:1527613751398};\\\", \\\"{x:400,y:556,t:1527613751414};\\\", \\\"{x:401,y:554,t:1527613751445};\\\", \\\"{x:401,y:553,t:1527613751479};\\\", \\\"{x:402,y:552,t:1527613751556};\\\", \\\"{x:404,y:549,t:1527613751605};\\\", \\\"{x:405,y:548,t:1527613751614};\\\", \\\"{x:406,y:544,t:1527613751631};\\\", \\\"{x:406,y:538,t:1527613751648};\\\", \\\"{x:406,y:531,t:1527613751665};\\\", \\\"{x:407,y:526,t:1527613751681};\\\", \\\"{x:408,y:520,t:1527613751698};\\\", \\\"{x:409,y:513,t:1527613751714};\\\", \\\"{x:412,y:503,t:1527613751731};\\\", \\\"{x:415,y:498,t:1527613751748};\\\", \\\"{x:415,y:496,t:1527613751765};\\\", \\\"{x:416,y:493,t:1527613751782};\\\", \\\"{x:414,y:492,t:1527613752213};\\\", \\\"{x:401,y:501,t:1527613752232};\\\", \\\"{x:388,y:507,t:1527613752248};\\\", \\\"{x:360,y:516,t:1527613752265};\\\", \\\"{x:331,y:521,t:1527613752282};\\\", \\\"{x:304,y:522,t:1527613752298};\\\", \\\"{x:277,y:523,t:1527613752315};\\\", \\\"{x:267,y:525,t:1527613752332};\\\", \\\"{x:265,y:526,t:1527613752347};\\\", \\\"{x:268,y:525,t:1527613752613};\\\", \\\"{x:274,y:521,t:1527613752621};\\\", \\\"{x:284,y:518,t:1527613752632};\\\", \\\"{x:302,y:514,t:1527613752649};\\\", \\\"{x:319,y:512,t:1527613752664};\\\", \\\"{x:324,y:511,t:1527613752682};\\\", \\\"{x:324,y:510,t:1527613752699};\\\", \\\"{x:325,y:509,t:1527613752860};\\\", \\\"{x:329,y:507,t:1527613752868};\\\", \\\"{x:330,y:507,t:1527613752883};\\\", \\\"{x:332,y:503,t:1527613752900};\\\", \\\"{x:334,y:502,t:1527613752915};\\\", \\\"{x:341,y:499,t:1527613752932};\\\", \\\"{x:342,y:499,t:1527613752963};\\\", \\\"{x:343,y:499,t:1527613752972};\\\", \\\"{x:344,y:499,t:1527613752983};\\\", \\\"{x:345,y:497,t:1527613753000};\\\", \\\"{x:346,y:497,t:1527613753016};\\\", \\\"{x:338,y:495,t:1527613753196};\\\", \\\"{x:331,y:492,t:1527613753204};\\\", \\\"{x:321,y:491,t:1527613753215};\\\", \\\"{x:301,y:490,t:1527613753233};\\\", \\\"{x:283,y:492,t:1527613753249};\\\", \\\"{x:267,y:496,t:1527613753268};\\\", \\\"{x:249,y:500,t:1527613753282};\\\", \\\"{x:230,y:502,t:1527613753299};\\\", \\\"{x:225,y:502,t:1527613753316};\\\", \\\"{x:224,y:502,t:1527613753333};\\\", \\\"{x:223,y:503,t:1527613753443};\\\", \\\"{x:221,y:505,t:1527613753451};\\\", \\\"{x:218,y:507,t:1527613753466};\\\", \\\"{x:210,y:513,t:1527613753483};\\\", \\\"{x:207,y:514,t:1527613753500};\\\", \\\"{x:206,y:514,t:1527613753516};\\\", \\\"{x:205,y:514,t:1527613753708};\\\", \\\"{x:204,y:514,t:1527613753724};\\\", \\\"{x:204,y:514,t:1527613753748};\\\", \\\"{x:197,y:513,t:1527613753924};\\\", \\\"{x:188,y:510,t:1527613753935};\\\", \\\"{x:157,y:505,t:1527613753952};\\\", \\\"{x:133,y:502,t:1527613753967};\\\", \\\"{x:106,y:495,t:1527613753982};\\\", \\\"{x:89,y:489,t:1527613754000};\\\", \\\"{x:83,y:488,t:1527613754015};\\\", \\\"{x:81,y:488,t:1527613754059};\\\", \\\"{x:81,y:487,t:1527613754075};\\\", \\\"{x:83,y:485,t:1527613754269};\\\", \\\"{x:97,y:485,t:1527613754283};\\\", \\\"{x:102,y:485,t:1527613754299};\\\", \\\"{x:110,y:485,t:1527613754316};\\\", \\\"{x:124,y:485,t:1527613754333};\\\", \\\"{x:137,y:487,t:1527613754349};\\\", \\\"{x:149,y:489,t:1527613754366};\\\", \\\"{x:158,y:491,t:1527613754383};\\\", \\\"{x:164,y:492,t:1527613754400};\\\", \\\"{x:167,y:493,t:1527613754417};\\\", \\\"{x:167,y:494,t:1527613754433};\\\", \\\"{x:168,y:494,t:1527613754771};\\\", \\\"{x:175,y:494,t:1527613754784};\\\", \\\"{x:202,y:496,t:1527613754801};\\\", \\\"{x:224,y:495,t:1527613754817};\\\", \\\"{x:245,y:493,t:1527613754834};\\\", \\\"{x:274,y:493,t:1527613754851};\\\", \\\"{x:293,y:493,t:1527613754867};\\\", \\\"{x:294,y:492,t:1527613754884};\\\", \\\"{x:295,y:492,t:1527613754900};\\\", \\\"{x:296,y:491,t:1527613755028};\\\", \\\"{x:297,y:491,t:1527613755036};\\\", \\\"{x:299,y:491,t:1527613755188};\\\", \\\"{x:303,y:491,t:1527613755212};\\\", \\\"{x:305,y:491,t:1527613755227};\\\", \\\"{x:312,y:492,t:1527613755236};\\\", \\\"{x:330,y:496,t:1527613755251};\\\", \\\"{x:354,y:501,t:1527613755268};\\\", \\\"{x:367,y:506,t:1527613755284};\\\", \\\"{x:377,y:506,t:1527613755303};\\\", \\\"{x:380,y:506,t:1527613755317};\\\", \\\"{x:382,y:506,t:1527613755373};\\\", \\\"{x:383,y:506,t:1527613755384};\\\", \\\"{x:385,y:506,t:1527613755400};\\\", \\\"{x:386,y:506,t:1527613755418};\\\", \\\"{x:387,y:506,t:1527613755434};\\\", \\\"{x:388,y:506,t:1527613755450};\\\", \\\"{x:390,y:506,t:1527613755811};\\\", \\\"{x:396,y:512,t:1527613755819};\\\", \\\"{x:399,y:522,t:1527613755835};\\\", \\\"{x:413,y:556,t:1527613755851};\\\", \\\"{x:422,y:581,t:1527613755868};\\\", \\\"{x:434,y:609,t:1527613755885};\\\", \\\"{x:448,y:635,t:1527613755902};\\\", \\\"{x:462,y:664,t:1527613755918};\\\", \\\"{x:480,y:697,t:1527613755936};\\\", \\\"{x:496,y:716,t:1527613755951};\\\", \\\"{x:507,y:727,t:1527613755968};\\\", \\\"{x:516,y:737,t:1527613755985};\\\", \\\"{x:521,y:740,t:1527613756001};\\\", \\\"{x:522,y:740,t:1527613756684};\\\", \\\"{x:523,y:739,t:1527613756699};\\\", \\\"{x:523,y:738,t:1527613756707};\\\", \\\"{x:523,y:737,t:1527613756719};\\\", \\\"{x:523,y:736,t:1527613756764};\\\", \\\"{x:523,y:735,t:1527613756771};\\\", \\\"{x:523,y:734,t:1527613756785};\\\", \\\"{x:523,y:733,t:1527613756818};\\\", \\\"{x:523,y:732,t:1527613756843};\\\" ] }, { \\\"rt\\\": 14814, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 13, \\\"time_elapsed\\\": 446151, \\\"internal_node_id\\\": \\\"0.0-6.0-3.0\\\", \\\"subject\\\": \\\"AZKMW\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"oscar\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime+before+endtime+during\\\", \\\"q\\\": 9, \\\"clicks\\\": 1.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"I\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-4-O -09 AM-09 AM-J \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:530,y:730,t:1527613759941};\\\", \\\"{x:542,y:729,t:1527613759955};\\\", \\\"{x:599,y:717,t:1527613759974};\\\", \\\"{x:680,y:708,t:1527613759988};\\\", \\\"{x:765,y:698,t:1527613760004};\\\", \\\"{x:869,y:690,t:1527613760021};\\\", \\\"{x:956,y:691,t:1527613760038};\\\", \\\"{x:1059,y:693,t:1527613760054};\\\", \\\"{x:1159,y:692,t:1527613760071};\\\", \\\"{x:1237,y:681,t:1527613760088};\\\", \\\"{x:1320,y:681,t:1527613760104};\\\", \\\"{x:1373,y:681,t:1527613760122};\\\", \\\"{x:1403,y:681,t:1527613760138};\\\", \\\"{x:1475,y:670,t:1527613760155};\\\", \\\"{x:1512,y:659,t:1527613760171};\\\", \\\"{x:1533,y:654,t:1527613760189};\\\", \\\"{x:1549,y:651,t:1527613760206};\\\", \\\"{x:1570,y:649,t:1527613760222};\\\", \\\"{x:1594,y:646,t:1527613760239};\\\", \\\"{x:1632,y:634,t:1527613760255};\\\", \\\"{x:1655,y:629,t:1527613760272};\\\", \\\"{x:1664,y:628,t:1527613760288};\\\", \\\"{x:1672,y:627,t:1527613760306};\\\", \\\"{x:1673,y:626,t:1527613760331};\\\", \\\"{x:1673,y:634,t:1527613760419};\\\", \\\"{x:1669,y:641,t:1527613760427};\\\", \\\"{x:1664,y:650,t:1527613760438};\\\", \\\"{x:1654,y:665,t:1527613760455};\\\", \\\"{x:1644,y:677,t:1527613760471};\\\", \\\"{x:1636,y:685,t:1527613760489};\\\", \\\"{x:1626,y:696,t:1527613760506};\\\", \\\"{x:1612,y:707,t:1527613760522};\\\", \\\"{x:1596,y:717,t:1527613760539};\\\", \\\"{x:1578,y:731,t:1527613760555};\\\", \\\"{x:1566,y:734,t:1527613760572};\\\", \\\"{x:1556,y:736,t:1527613760588};\\\", \\\"{x:1546,y:740,t:1527613760606};\\\", \\\"{x:1538,y:742,t:1527613760622};\\\", \\\"{x:1528,y:743,t:1527613760638};\\\", \\\"{x:1514,y:744,t:1527613760655};\\\", \\\"{x:1498,y:744,t:1527613760673};\\\", \\\"{x:1481,y:744,t:1527613760689};\\\", \\\"{x:1473,y:744,t:1527613760706};\\\", \\\"{x:1469,y:744,t:1527613760723};\\\", \\\"{x:1463,y:744,t:1527613760739};\\\", \\\"{x:1460,y:744,t:1527613760756};\\\", \\\"{x:1459,y:744,t:1527613760869};\\\", \\\"{x:1459,y:740,t:1527613760876};\\\", \\\"{x:1460,y:734,t:1527613760889};\\\", \\\"{x:1461,y:720,t:1527613760906};\\\", \\\"{x:1461,y:713,t:1527613760923};\\\", \\\"{x:1461,y:704,t:1527613760938};\\\", \\\"{x:1461,y:694,t:1527613760956};\\\", \\\"{x:1461,y:683,t:1527613760973};\\\", \\\"{x:1451,y:667,t:1527613760989};\\\", \\\"{x:1442,y:658,t:1527613761006};\\\", \\\"{x:1439,y:655,t:1527613761023};\\\", \\\"{x:1437,y:655,t:1527613761040};\\\", \\\"{x:1436,y:655,t:1527613761056};\\\", \\\"{x:1436,y:654,t:1527613761189};\\\", \\\"{x:1436,y:653,t:1527613761203};\\\", \\\"{x:1438,y:652,t:1527613761212};\\\", \\\"{x:1439,y:651,t:1527613761223};\\\", \\\"{x:1444,y:647,t:1527613761240};\\\", \\\"{x:1449,y:643,t:1527613761256};\\\", \\\"{x:1450,y:643,t:1527613761273};\\\", \\\"{x:1452,y:642,t:1527613761290};\\\", \\\"{x:1452,y:640,t:1527613761306};\\\", \\\"{x:1453,y:640,t:1527613761323};\\\", \\\"{x:1454,y:639,t:1527613761340};\\\", \\\"{x:1452,y:640,t:1527613761508};\\\", \\\"{x:1437,y:665,t:1527613761523};\\\", \\\"{x:1349,y:791,t:1527613761540};\\\", \\\"{x:1300,y:863,t:1527613761556};\\\", \\\"{x:1259,y:912,t:1527613761573};\\\", \\\"{x:1218,y:945,t:1527613761590};\\\", \\\"{x:1176,y:971,t:1527613761607};\\\", \\\"{x:1142,y:983,t:1527613761624};\\\", \\\"{x:1123,y:992,t:1527613761640};\\\", \\\"{x:1112,y:993,t:1527613761657};\\\", \\\"{x:1110,y:994,t:1527613761673};\\\", \\\"{x:1109,y:994,t:1527613761690};\\\", \\\"{x:1110,y:994,t:1527613761748};\\\", \\\"{x:1113,y:994,t:1527613761756};\\\", \\\"{x:1119,y:989,t:1527613761773};\\\", \\\"{x:1129,y:978,t:1527613761791};\\\", \\\"{x:1139,y:966,t:1527613761807};\\\", \\\"{x:1152,y:952,t:1527613761823};\\\", \\\"{x:1164,y:936,t:1527613761840};\\\", \\\"{x:1179,y:919,t:1527613761857};\\\", \\\"{x:1192,y:903,t:1527613761872};\\\", \\\"{x:1202,y:890,t:1527613761890};\\\", \\\"{x:1208,y:881,t:1527613761907};\\\", \\\"{x:1210,y:878,t:1527613761923};\\\", \\\"{x:1212,y:874,t:1527613761940};\\\", \\\"{x:1213,y:872,t:1527613761980};\\\", \\\"{x:1214,y:871,t:1527613761990};\\\", \\\"{x:1215,y:867,t:1527613762069};\\\", \\\"{x:1216,y:865,t:1527613762084};\\\", \\\"{x:1216,y:862,t:1527613762092};\\\", \\\"{x:1217,y:859,t:1527613762106};\\\", \\\"{x:1219,y:850,t:1527613762124};\\\", \\\"{x:1220,y:841,t:1527613762140};\\\", \\\"{x:1221,y:831,t:1527613762158};\\\", \\\"{x:1222,y:827,t:1527613762174};\\\", \\\"{x:1222,y:822,t:1527613762190};\\\", \\\"{x:1224,y:819,t:1527613762207};\\\", \\\"{x:1224,y:816,t:1527613762224};\\\", \\\"{x:1224,y:817,t:1527613762444};\\\", \\\"{x:1222,y:824,t:1527613762456};\\\", \\\"{x:1216,y:832,t:1527613762477};\\\", \\\"{x:1214,y:836,t:1527613762491};\\\", \\\"{x:1214,y:837,t:1527613762507};\\\", \\\"{x:1213,y:838,t:1527613762523};\\\", \\\"{x:1212,y:838,t:1527613764333};\\\", \\\"{x:1206,y:832,t:1527613764342};\\\", \\\"{x:1193,y:816,t:1527613764359};\\\", \\\"{x:1178,y:801,t:1527613764375};\\\", \\\"{x:1170,y:790,t:1527613764392};\\\", \\\"{x:1168,y:781,t:1527613764409};\\\", \\\"{x:1166,y:779,t:1527613764425};\\\", \\\"{x:1165,y:777,t:1527613764442};\\\", \\\"{x:1165,y:775,t:1527613764459};\\\", \\\"{x:1165,y:773,t:1527613764475};\\\", \\\"{x:1165,y:771,t:1527613764492};\\\", \\\"{x:1164,y:771,t:1527613764508};\\\", \\\"{x:1164,y:770,t:1527613764899};\\\", \\\"{x:1167,y:770,t:1527613765884};\\\", \\\"{x:1174,y:766,t:1527613765893};\\\", \\\"{x:1190,y:765,t:1527613765910};\\\", \\\"{x:1216,y:765,t:1527613765926};\\\", \\\"{x:1241,y:765,t:1527613765943};\\\", \\\"{x:1248,y:768,t:1527613765960};\\\", \\\"{x:1256,y:769,t:1527613765977};\\\", \\\"{x:1266,y:770,t:1527613765993};\\\", \\\"{x:1273,y:771,t:1527613766010};\\\", \\\"{x:1275,y:771,t:1527613766026};\\\", \\\"{x:1276,y:771,t:1527613766083};\\\", \\\"{x:1278,y:771,t:1527613766099};\\\", \\\"{x:1279,y:771,t:1527613766115};\\\", \\\"{x:1282,y:770,t:1527613766127};\\\", \\\"{x:1283,y:770,t:1527613766143};\\\", \\\"{x:1285,y:769,t:1527613766160};\\\", \\\"{x:1286,y:769,t:1527613766176};\\\", \\\"{x:1286,y:768,t:1527613766192};\\\", \\\"{x:1285,y:769,t:1527613766269};\\\", \\\"{x:1282,y:772,t:1527613766277};\\\", \\\"{x:1275,y:776,t:1527613766293};\\\", \\\"{x:1267,y:781,t:1527613766310};\\\", \\\"{x:1254,y:790,t:1527613766327};\\\", \\\"{x:1231,y:802,t:1527613766344};\\\", \\\"{x:1212,y:809,t:1527613766359};\\\", \\\"{x:1194,y:814,t:1527613766377};\\\", \\\"{x:1184,y:817,t:1527613766394};\\\", \\\"{x:1175,y:819,t:1527613766410};\\\", \\\"{x:1169,y:819,t:1527613766427};\\\", \\\"{x:1161,y:818,t:1527613766443};\\\", \\\"{x:1153,y:817,t:1527613766460};\\\", \\\"{x:1142,y:812,t:1527613766477};\\\", \\\"{x:1128,y:808,t:1527613766494};\\\", \\\"{x:1113,y:805,t:1527613766510};\\\", \\\"{x:1088,y:796,t:1527613766527};\\\", \\\"{x:1040,y:781,t:1527613766543};\\\", \\\"{x:973,y:759,t:1527613766560};\\\", \\\"{x:872,y:723,t:1527613766577};\\\", \\\"{x:756,y:688,t:1527613766594};\\\", \\\"{x:625,y:645,t:1527613766610};\\\", \\\"{x:476,y:601,t:1527613766628};\\\", \\\"{x:310,y:554,t:1527613766643};\\\", \\\"{x:226,y:527,t:1527613766660};\\\", \\\"{x:179,y:515,t:1527613766677};\\\", \\\"{x:160,y:503,t:1527613766693};\\\", \\\"{x:149,y:495,t:1527613766711};\\\", \\\"{x:144,y:492,t:1527613766726};\\\", \\\"{x:144,y:491,t:1527613766956};\\\", \\\"{x:145,y:490,t:1527613766963};\\\", \\\"{x:146,y:490,t:1527613766978};\\\", \\\"{x:150,y:488,t:1527613766994};\\\", \\\"{x:155,y:485,t:1527613767012};\\\", \\\"{x:163,y:483,t:1527613767027};\\\", \\\"{x:169,y:480,t:1527613767042};\\\", \\\"{x:174,y:479,t:1527613767059};\\\", \\\"{x:182,y:476,t:1527613767077};\\\", \\\"{x:194,y:475,t:1527613767094};\\\", \\\"{x:200,y:475,t:1527613767109};\\\", \\\"{x:209,y:473,t:1527613767126};\\\", \\\"{x:221,y:473,t:1527613767144};\\\", \\\"{x:230,y:473,t:1527613767160};\\\", \\\"{x:236,y:473,t:1527613767177};\\\", \\\"{x:244,y:473,t:1527613767194};\\\", \\\"{x:250,y:473,t:1527613767209};\\\", \\\"{x:254,y:473,t:1527613767227};\\\", \\\"{x:263,y:473,t:1527613767244};\\\", \\\"{x:265,y:473,t:1527613767270};\\\", \\\"{x:266,y:473,t:1527613767276};\\\", \\\"{x:271,y:473,t:1527613767293};\\\", \\\"{x:278,y:473,t:1527613767309};\\\", \\\"{x:284,y:473,t:1527613767327};\\\", \\\"{x:290,y:473,t:1527613767343};\\\", \\\"{x:297,y:474,t:1527613767359};\\\", \\\"{x:310,y:477,t:1527613767376};\\\", \\\"{x:319,y:478,t:1527613767392};\\\", \\\"{x:332,y:482,t:1527613767410};\\\", \\\"{x:349,y:486,t:1527613767427};\\\", \\\"{x:375,y:492,t:1527613767443};\\\", \\\"{x:393,y:498,t:1527613767460};\\\", \\\"{x:410,y:502,t:1527613767478};\\\", \\\"{x:425,y:505,t:1527613767494};\\\", \\\"{x:439,y:508,t:1527613767510};\\\", \\\"{x:449,y:510,t:1527613767527};\\\", \\\"{x:463,y:514,t:1527613767543};\\\", \\\"{x:469,y:515,t:1527613767560};\\\", \\\"{x:477,y:518,t:1527613767578};\\\", \\\"{x:487,y:521,t:1527613767593};\\\", \\\"{x:491,y:522,t:1527613767610};\\\", \\\"{x:502,y:524,t:1527613767627};\\\", \\\"{x:507,y:525,t:1527613767645};\\\", \\\"{x:508,y:525,t:1527613767675};\\\", \\\"{x:509,y:525,t:1527613768316};\\\", \\\"{x:506,y:525,t:1527613768328};\\\", \\\"{x:501,y:525,t:1527613768344};\\\", \\\"{x:500,y:525,t:1527613768362};\\\", \\\"{x:498,y:525,t:1527613768380};\\\", \\\"{x:497,y:525,t:1527613768395};\\\", \\\"{x:496,y:525,t:1527613768411};\\\", \\\"{x:495,y:525,t:1527613768435};\\\", \\\"{x:492,y:525,t:1527613768490};\\\", \\\"{x:491,y:525,t:1527613768499};\\\", \\\"{x:488,y:525,t:1527613768511};\\\", \\\"{x:476,y:525,t:1527613768529};\\\", \\\"{x:459,y:525,t:1527613768546};\\\", \\\"{x:443,y:524,t:1527613768562};\\\", \\\"{x:421,y:524,t:1527613768579};\\\", \\\"{x:393,y:524,t:1527613768595};\\\", \\\"{x:326,y:524,t:1527613768611};\\\", \\\"{x:283,y:521,t:1527613768628};\\\", \\\"{x:256,y:520,t:1527613768645};\\\", \\\"{x:235,y:518,t:1527613768662};\\\", \\\"{x:221,y:518,t:1527613768679};\\\", \\\"{x:219,y:518,t:1527613768695};\\\", \\\"{x:222,y:518,t:1527613768956};\\\", \\\"{x:225,y:516,t:1527613768972};\\\", \\\"{x:227,y:515,t:1527613768979};\\\", \\\"{x:232,y:511,t:1527613768995};\\\", \\\"{x:233,y:511,t:1527613769011};\\\", \\\"{x:229,y:510,t:1527613769564};\\\", \\\"{x:212,y:507,t:1527613769579};\\\", \\\"{x:201,y:505,t:1527613769596};\\\", \\\"{x:199,y:505,t:1527613769613};\\\", \\\"{x:196,y:505,t:1527613769948};\\\", \\\"{x:194,y:505,t:1527613769988};\\\", \\\"{x:193,y:504,t:1527613770003};\\\", \\\"{x:192,y:504,t:1527613770019};\\\", \\\"{x:190,y:503,t:1527613770035};\\\", \\\"{x:189,y:503,t:1527613770083};\\\", \\\"{x:187,y:502,t:1527613770181};\\\", \\\"{x:185,y:502,t:1527613770230};\\\", \\\"{x:184,y:502,t:1527613770403};\\\", \\\"{x:183,y:502,t:1527613770867};\\\", \\\"{x:182,y:502,t:1527613771028};\\\", \\\"{x:180,y:502,t:1527613771484};\\\", \\\"{x:178,y:502,t:1527613771498};\\\", \\\"{x:176,y:502,t:1527613771514};\\\", \\\"{x:175,y:502,t:1527613771531};\\\", \\\"{x:174,y:502,t:1527613771547};\\\", \\\"{x:173,y:502,t:1527613771653};\\\", \\\"{x:176,y:507,t:1527613771665};\\\", \\\"{x:202,y:533,t:1527613771683};\\\", \\\"{x:261,y:574,t:1527613771698};\\\", \\\"{x:318,y:609,t:1527613771714};\\\", \\\"{x:388,y:656,t:1527613771731};\\\", \\\"{x:428,y:673,t:1527613771748};\\\", \\\"{x:435,y:680,t:1527613771764};\\\", \\\"{x:439,y:685,t:1527613771780};\\\", \\\"{x:460,y:692,t:1527613771798};\\\", \\\"{x:469,y:694,t:1527613771814};\\\", \\\"{x:470,y:694,t:1527613771831};\\\", \\\"{x:471,y:696,t:1527613772020};\\\", \\\"{x:473,y:701,t:1527613772030};\\\", \\\"{x:474,y:707,t:1527613772048};\\\", \\\"{x:478,y:716,t:1527613772064};\\\", \\\"{x:481,y:719,t:1527613772081};\\\", \\\"{x:486,y:722,t:1527613772100};\\\", \\\"{x:490,y:730,t:1527613772114};\\\", \\\"{x:498,y:743,t:1527613772131};\\\", \\\"{x:499,y:744,t:1527613772148};\\\", \\\"{x:500,y:745,t:1527613772170};\\\" ] }, { \\\"rt\\\": 25985, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 14, \\\"time_elapsed\\\": 473420, \\\"internal_node_id\\\": \\\"0.0-6.0-4.0\\\", \\\"subject\\\": \\\"AZKMW\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"oscar\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"ends\\\", \\\"q\\\": 10, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F -F -G -H -X -X \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:505,y:746,t:1527613776540};\\\", \\\"{x:523,y:746,t:1527613776547};\\\", \\\"{x:540,y:746,t:1527613776558};\\\", \\\"{x:618,y:746,t:1527613776577};\\\", \\\"{x:727,y:743,t:1527613776592};\\\", \\\"{x:866,y:738,t:1527613776608};\\\", \\\"{x:950,y:734,t:1527613776618};\\\", \\\"{x:1206,y:726,t:1527613776635};\\\", \\\"{x:1383,y:726,t:1527613776652};\\\", \\\"{x:1555,y:723,t:1527613776668};\\\", \\\"{x:1664,y:723,t:1527613776684};\\\", \\\"{x:1681,y:731,t:1527613776702};\\\", \\\"{x:1690,y:736,t:1527613776718};\\\", \\\"{x:1681,y:737,t:1527613776900};\\\", \\\"{x:1676,y:739,t:1527613776908};\\\", \\\"{x:1671,y:740,t:1527613776919};\\\", \\\"{x:1651,y:740,t:1527613776935};\\\", \\\"{x:1631,y:740,t:1527613776952};\\\", \\\"{x:1613,y:734,t:1527613776970};\\\", \\\"{x:1591,y:734,t:1527613776985};\\\", \\\"{x:1581,y:734,t:1527613777002};\\\", \\\"{x:1564,y:733,t:1527613777020};\\\", \\\"{x:1556,y:733,t:1527613777035};\\\", \\\"{x:1553,y:733,t:1527613777052};\\\", \\\"{x:1542,y:733,t:1527613777069};\\\", \\\"{x:1527,y:733,t:1527613777086};\\\", \\\"{x:1515,y:733,t:1527613777103};\\\", \\\"{x:1507,y:732,t:1527613777119};\\\", \\\"{x:1500,y:730,t:1527613777135};\\\", \\\"{x:1479,y:725,t:1527613777152};\\\", \\\"{x:1462,y:723,t:1527613777169};\\\", \\\"{x:1441,y:718,t:1527613777184};\\\", \\\"{x:1422,y:713,t:1527613777202};\\\", \\\"{x:1398,y:710,t:1527613777219};\\\", \\\"{x:1385,y:709,t:1527613777235};\\\", \\\"{x:1374,y:709,t:1527613777252};\\\", \\\"{x:1356,y:709,t:1527613777269};\\\", \\\"{x:1352,y:709,t:1527613777287};\\\", \\\"{x:1351,y:709,t:1527613777302};\\\", \\\"{x:1350,y:709,t:1527613777868};\\\", \\\"{x:1349,y:709,t:1527613778484};\\\", \\\"{x:1348,y:709,t:1527613778540};\\\", \\\"{x:1347,y:708,t:1527613778675};\\\", \\\"{x:1345,y:707,t:1527613778687};\\\", \\\"{x:1345,y:706,t:1527613778704};\\\", \\\"{x:1345,y:705,t:1527613778720};\\\", \\\"{x:1345,y:703,t:1527613778738};\\\", \\\"{x:1345,y:702,t:1527613778788};\\\", \\\"{x:1345,y:701,t:1527613778814};\\\", \\\"{x:1345,y:700,t:1527613778819};\\\", \\\"{x:1345,y:699,t:1527613778843};\\\", \\\"{x:1345,y:698,t:1527613778891};\\\", \\\"{x:1345,y:697,t:1527613778938};\\\", \\\"{x:1345,y:696,t:1527613779660};\\\", \\\"{x:1345,y:690,t:1527613783547};\\\", \\\"{x:1343,y:676,t:1527613783557};\\\", \\\"{x:1340,y:668,t:1527613783574};\\\", \\\"{x:1340,y:662,t:1527613783590};\\\", \\\"{x:1340,y:653,t:1527613783607};\\\", \\\"{x:1340,y:648,t:1527613783624};\\\", \\\"{x:1340,y:647,t:1527613783641};\\\", \\\"{x:1341,y:647,t:1527613783859};\\\", \\\"{x:1341,y:648,t:1527613783874};\\\", \\\"{x:1346,y:656,t:1527613783891};\\\", \\\"{x:1355,y:663,t:1527613783907};\\\", \\\"{x:1366,y:679,t:1527613783925};\\\", \\\"{x:1376,y:690,t:1527613783942};\\\", \\\"{x:1385,y:700,t:1527613783957};\\\", \\\"{x:1387,y:703,t:1527613783975};\\\", \\\"{x:1389,y:705,t:1527613783992};\\\", \\\"{x:1391,y:705,t:1527613784196};\\\", \\\"{x:1396,y:705,t:1527613784208};\\\", \\\"{x:1412,y:700,t:1527613784225};\\\", \\\"{x:1417,y:697,t:1527613784242};\\\", \\\"{x:1423,y:694,t:1527613784258};\\\", \\\"{x:1428,y:692,t:1527613784274};\\\", \\\"{x:1431,y:692,t:1527613784292};\\\", \\\"{x:1429,y:692,t:1527613784660};\\\", \\\"{x:1428,y:693,t:1527613784674};\\\", \\\"{x:1429,y:693,t:1527613784764};\\\", \\\"{x:1430,y:693,t:1527613784776};\\\", \\\"{x:1432,y:693,t:1527613784792};\\\", \\\"{x:1438,y:695,t:1527613784808};\\\", \\\"{x:1442,y:696,t:1527613784826};\\\", \\\"{x:1446,y:697,t:1527613784842};\\\", \\\"{x:1449,y:699,t:1527613784858};\\\", \\\"{x:1452,y:699,t:1527613784875};\\\", \\\"{x:1453,y:699,t:1527613784891};\\\", \\\"{x:1455,y:699,t:1527613784909};\\\", \\\"{x:1459,y:699,t:1527613784926};\\\", \\\"{x:1463,y:699,t:1527613784942};\\\", \\\"{x:1466,y:699,t:1527613784959};\\\", \\\"{x:1469,y:699,t:1527613784976};\\\", \\\"{x:1471,y:699,t:1527613784992};\\\", \\\"{x:1473,y:699,t:1527613785008};\\\", \\\"{x:1474,y:699,t:1527613785060};\\\", \\\"{x:1476,y:699,t:1527613785075};\\\", \\\"{x:1478,y:699,t:1527613785100};\\\", \\\"{x:1479,y:699,t:1527613785109};\\\", \\\"{x:1480,y:698,t:1527613785126};\\\", \\\"{x:1482,y:698,t:1527613785147};\\\", \\\"{x:1484,y:697,t:1527613785159};\\\", \\\"{x:1485,y:697,t:1527613785176};\\\", \\\"{x:1487,y:696,t:1527613785193};\\\", \\\"{x:1490,y:696,t:1527613785208};\\\", \\\"{x:1491,y:696,t:1527613785228};\\\", \\\"{x:1494,y:695,t:1527613785244};\\\", \\\"{x:1494,y:694,t:1527613785258};\\\", \\\"{x:1497,y:693,t:1527613785275};\\\", \\\"{x:1498,y:692,t:1527613785299};\\\", \\\"{x:1499,y:692,t:1527613785309};\\\", \\\"{x:1501,y:692,t:1527613785325};\\\", \\\"{x:1503,y:692,t:1527613785342};\\\", \\\"{x:1506,y:691,t:1527613785358};\\\", \\\"{x:1513,y:691,t:1527613785375};\\\", \\\"{x:1516,y:691,t:1527613785392};\\\", \\\"{x:1520,y:691,t:1527613785408};\\\", \\\"{x:1522,y:691,t:1527613785434};\\\", \\\"{x:1523,y:691,t:1527613785442};\\\", \\\"{x:1525,y:691,t:1527613785458};\\\", \\\"{x:1528,y:691,t:1527613785475};\\\", \\\"{x:1530,y:691,t:1527613785492};\\\", \\\"{x:1532,y:691,t:1527613785508};\\\", \\\"{x:1536,y:691,t:1527613785525};\\\", \\\"{x:1542,y:691,t:1527613785543};\\\", \\\"{x:1546,y:692,t:1527613785560};\\\", \\\"{x:1547,y:692,t:1527613785575};\\\", \\\"{x:1549,y:693,t:1527613785592};\\\", \\\"{x:1549,y:694,t:1527613785691};\\\", \\\"{x:1550,y:694,t:1527613785715};\\\", \\\"{x:1554,y:694,t:1527613785726};\\\", \\\"{x:1560,y:694,t:1527613785742};\\\", \\\"{x:1571,y:694,t:1527613785760};\\\", \\\"{x:1585,y:695,t:1527613785776};\\\", \\\"{x:1596,y:695,t:1527613785792};\\\", \\\"{x:1601,y:695,t:1527613785809};\\\", \\\"{x:1603,y:695,t:1527613785825};\\\", \\\"{x:1604,y:695,t:1527613785842};\\\", \\\"{x:1604,y:696,t:1527613788212};\\\", \\\"{x:1598,y:696,t:1527613788227};\\\", \\\"{x:1563,y:686,t:1527613788246};\\\", \\\"{x:1524,y:676,t:1527613788262};\\\", \\\"{x:1481,y:668,t:1527613788277};\\\", \\\"{x:1441,y:655,t:1527613788295};\\\", \\\"{x:1415,y:648,t:1527613788311};\\\", \\\"{x:1400,y:643,t:1527613788327};\\\", \\\"{x:1396,y:641,t:1527613788344};\\\", \\\"{x:1394,y:640,t:1527613788361};\\\", \\\"{x:1393,y:640,t:1527613788386};\\\", \\\"{x:1393,y:639,t:1527613788474};\\\", \\\"{x:1393,y:635,t:1527613788482};\\\", \\\"{x:1393,y:633,t:1527613788494};\\\", \\\"{x:1392,y:627,t:1527613788511};\\\", \\\"{x:1387,y:615,t:1527613788528};\\\", \\\"{x:1382,y:610,t:1527613788544};\\\", \\\"{x:1378,y:605,t:1527613788561};\\\", \\\"{x:1375,y:594,t:1527613788577};\\\", \\\"{x:1366,y:585,t:1527613788594};\\\", \\\"{x:1360,y:579,t:1527613788611};\\\", \\\"{x:1356,y:576,t:1527613788629};\\\", \\\"{x:1356,y:575,t:1527613788644};\\\", \\\"{x:1354,y:574,t:1527613788661};\\\", \\\"{x:1354,y:573,t:1527613788867};\\\", \\\"{x:1354,y:572,t:1527613788899};\\\", \\\"{x:1355,y:570,t:1527613788923};\\\", \\\"{x:1356,y:570,t:1527613788931};\\\", \\\"{x:1358,y:570,t:1527613788945};\\\", \\\"{x:1361,y:569,t:1527613788961};\\\", \\\"{x:1363,y:567,t:1527613788979};\\\", \\\"{x:1364,y:566,t:1527613789155};\\\", \\\"{x:1365,y:566,t:1527613789163};\\\", \\\"{x:1369,y:566,t:1527613789181};\\\", \\\"{x:1374,y:566,t:1527613789196};\\\", \\\"{x:1379,y:565,t:1527613789212};\\\", \\\"{x:1382,y:565,t:1527613789228};\\\", \\\"{x:1387,y:565,t:1527613789245};\\\", \\\"{x:1396,y:565,t:1527613789262};\\\", \\\"{x:1405,y:566,t:1527613789279};\\\", \\\"{x:1407,y:567,t:1527613789295};\\\", \\\"{x:1410,y:568,t:1527613789312};\\\", \\\"{x:1411,y:568,t:1527613789451};\\\", \\\"{x:1413,y:567,t:1527613789476};\\\", \\\"{x:1416,y:565,t:1527613789496};\\\", \\\"{x:1418,y:564,t:1527613789511};\\\", \\\"{x:1419,y:563,t:1527613789564};\\\", \\\"{x:1420,y:563,t:1527613789578};\\\", \\\"{x:1422,y:563,t:1527613789596};\\\", \\\"{x:1423,y:562,t:1527613789644};\\\", \\\"{x:1424,y:560,t:1527613789659};\\\", \\\"{x:1427,y:560,t:1527613789683};\\\", \\\"{x:1429,y:560,t:1527613789696};\\\", \\\"{x:1431,y:560,t:1527613789713};\\\", \\\"{x:1434,y:560,t:1527613789729};\\\", \\\"{x:1437,y:560,t:1527613789745};\\\", \\\"{x:1440,y:560,t:1527613789763};\\\", \\\"{x:1442,y:560,t:1527613789795};\\\", \\\"{x:1445,y:560,t:1527613789813};\\\", \\\"{x:1448,y:560,t:1527613789829};\\\", \\\"{x:1452,y:560,t:1527613789846};\\\", \\\"{x:1453,y:560,t:1527613789863};\\\", \\\"{x:1454,y:560,t:1527613789924};\\\", \\\"{x:1456,y:560,t:1527613789947};\\\", \\\"{x:1457,y:560,t:1527613789963};\\\", \\\"{x:1458,y:560,t:1527613789995};\\\", \\\"{x:1459,y:560,t:1527613790019};\\\", \\\"{x:1460,y:560,t:1527613790030};\\\", \\\"{x:1461,y:560,t:1527613790045};\\\", \\\"{x:1462,y:560,t:1527613790063};\\\", \\\"{x:1464,y:560,t:1527613790080};\\\", \\\"{x:1468,y:560,t:1527613790096};\\\", \\\"{x:1470,y:560,t:1527613790116};\\\", \\\"{x:1471,y:560,t:1527613790130};\\\", \\\"{x:1473,y:560,t:1527613790146};\\\", \\\"{x:1475,y:560,t:1527613790163};\\\", \\\"{x:1477,y:560,t:1527613790180};\\\", \\\"{x:1478,y:560,t:1527613790196};\\\", \\\"{x:1480,y:560,t:1527613790235};\\\", \\\"{x:1484,y:560,t:1527613790508};\\\", \\\"{x:1486,y:560,t:1527613790515};\\\", \\\"{x:1490,y:560,t:1527613790529};\\\", \\\"{x:1511,y:560,t:1527613790546};\\\", \\\"{x:1521,y:560,t:1527613790563};\\\", \\\"{x:1525,y:560,t:1527613790581};\\\", \\\"{x:1532,y:560,t:1527613790597};\\\", \\\"{x:1542,y:560,t:1527613790613};\\\", \\\"{x:1545,y:560,t:1527613790630};\\\", \\\"{x:1548,y:559,t:1527613790646};\\\", \\\"{x:1549,y:559,t:1527613790663};\\\", \\\"{x:1550,y:559,t:1527613790680};\\\", \\\"{x:1552,y:559,t:1527613791028};\\\", \\\"{x:1554,y:559,t:1527613791035};\\\", \\\"{x:1555,y:559,t:1527613791047};\\\", \\\"{x:1559,y:560,t:1527613791064};\\\", \\\"{x:1566,y:562,t:1527613791080};\\\", \\\"{x:1569,y:564,t:1527613791097};\\\", \\\"{x:1573,y:565,t:1527613791114};\\\", \\\"{x:1580,y:568,t:1527613791130};\\\", \\\"{x:1591,y:569,t:1527613791147};\\\", \\\"{x:1600,y:569,t:1527613791163};\\\", \\\"{x:1608,y:569,t:1527613791180};\\\", \\\"{x:1612,y:569,t:1527613791196};\\\", \\\"{x:1617,y:569,t:1527613791213};\\\", \\\"{x:1615,y:569,t:1527613791460};\\\", \\\"{x:1611,y:573,t:1527613791467};\\\", \\\"{x:1606,y:578,t:1527613791481};\\\", \\\"{x:1602,y:584,t:1527613791497};\\\", \\\"{x:1597,y:592,t:1527613791514};\\\", \\\"{x:1589,y:600,t:1527613791532};\\\", \\\"{x:1586,y:605,t:1527613791547};\\\", \\\"{x:1584,y:610,t:1527613791564};\\\", \\\"{x:1580,y:614,t:1527613791581};\\\", \\\"{x:1575,y:620,t:1527613791597};\\\", \\\"{x:1572,y:625,t:1527613791614};\\\", \\\"{x:1568,y:629,t:1527613791631};\\\", \\\"{x:1566,y:633,t:1527613791647};\\\", \\\"{x:1564,y:637,t:1527613791664};\\\", \\\"{x:1561,y:640,t:1527613791681};\\\", \\\"{x:1559,y:643,t:1527613791698};\\\", \\\"{x:1554,y:650,t:1527613791714};\\\", \\\"{x:1548,y:657,t:1527613791731};\\\", \\\"{x:1542,y:663,t:1527613791747};\\\", \\\"{x:1537,y:669,t:1527613791764};\\\", \\\"{x:1532,y:675,t:1527613791781};\\\", \\\"{x:1525,y:680,t:1527613791798};\\\", \\\"{x:1516,y:685,t:1527613791814};\\\", \\\"{x:1509,y:693,t:1527613791831};\\\", \\\"{x:1506,y:696,t:1527613791848};\\\", \\\"{x:1502,y:699,t:1527613791864};\\\", \\\"{x:1495,y:703,t:1527613791881};\\\", \\\"{x:1486,y:709,t:1527613791898};\\\", \\\"{x:1480,y:713,t:1527613791914};\\\", \\\"{x:1466,y:720,t:1527613791931};\\\", \\\"{x:1454,y:725,t:1527613791948};\\\", \\\"{x:1443,y:729,t:1527613791964};\\\", \\\"{x:1436,y:732,t:1527613791980};\\\", \\\"{x:1430,y:738,t:1527613791998};\\\", \\\"{x:1419,y:742,t:1527613792014};\\\", \\\"{x:1412,y:744,t:1527613792031};\\\", \\\"{x:1410,y:747,t:1527613792047};\\\", \\\"{x:1402,y:750,t:1527613792064};\\\", \\\"{x:1396,y:751,t:1527613792080};\\\", \\\"{x:1389,y:751,t:1527613792098};\\\", \\\"{x:1374,y:752,t:1527613792115};\\\", \\\"{x:1365,y:750,t:1527613792131};\\\", \\\"{x:1357,y:750,t:1527613792148};\\\", \\\"{x:1352,y:748,t:1527613792165};\\\", \\\"{x:1351,y:747,t:1527613792181};\\\", \\\"{x:1351,y:743,t:1527613792198};\\\", \\\"{x:1351,y:736,t:1527613792215};\\\", \\\"{x:1351,y:727,t:1527613792231};\\\", \\\"{x:1351,y:721,t:1527613792248};\\\", \\\"{x:1351,y:712,t:1527613792265};\\\", \\\"{x:1352,y:702,t:1527613792281};\\\", \\\"{x:1353,y:701,t:1527613792298};\\\", \\\"{x:1353,y:700,t:1527613792323};\\\", \\\"{x:1354,y:699,t:1527613792692};\\\", \\\"{x:1355,y:699,t:1527613792700};\\\", \\\"{x:1359,y:699,t:1527613792715};\\\", \\\"{x:1362,y:699,t:1527613792732};\\\", \\\"{x:1365,y:699,t:1527613792748};\\\", \\\"{x:1366,y:698,t:1527613792765};\\\", \\\"{x:1368,y:698,t:1527613792782};\\\", \\\"{x:1370,y:698,t:1527613792798};\\\", \\\"{x:1373,y:698,t:1527613792815};\\\", \\\"{x:1374,y:698,t:1527613792832};\\\", \\\"{x:1376,y:698,t:1527613792848};\\\", \\\"{x:1379,y:699,t:1527613792940};\\\", \\\"{x:1381,y:702,t:1527613792955};\\\", \\\"{x:1383,y:707,t:1527613792965};\\\", \\\"{x:1396,y:716,t:1527613792982};\\\", \\\"{x:1400,y:722,t:1527613792999};\\\", \\\"{x:1400,y:727,t:1527613793015};\\\", \\\"{x:1402,y:733,t:1527613793032};\\\", \\\"{x:1403,y:734,t:1527613793049};\\\", \\\"{x:1403,y:737,t:1527613793075};\\\", \\\"{x:1403,y:742,t:1527613793083};\\\", \\\"{x:1403,y:747,t:1527613793100};\\\", \\\"{x:1402,y:750,t:1527613793115};\\\", \\\"{x:1401,y:751,t:1527613793131};\\\", \\\"{x:1401,y:752,t:1527613793163};\\\", \\\"{x:1401,y:754,t:1527613793458};\\\", \\\"{x:1401,y:755,t:1527613793467};\\\", \\\"{x:1402,y:757,t:1527613793481};\\\", \\\"{x:1404,y:762,t:1527613793498};\\\", \\\"{x:1409,y:766,t:1527613793516};\\\", \\\"{x:1412,y:769,t:1527613793532};\\\", \\\"{x:1414,y:771,t:1527613793548};\\\", \\\"{x:1417,y:772,t:1527613793565};\\\", \\\"{x:1420,y:772,t:1527613793581};\\\", \\\"{x:1421,y:772,t:1527613793598};\\\", \\\"{x:1422,y:772,t:1527613793615};\\\", \\\"{x:1423,y:773,t:1527613793781};\\\", \\\"{x:1423,y:775,t:1527613793787};\\\", \\\"{x:1423,y:778,t:1527613793799};\\\", \\\"{x:1422,y:786,t:1527613793816};\\\", \\\"{x:1422,y:796,t:1527613793832};\\\", \\\"{x:1419,y:804,t:1527613793849};\\\", \\\"{x:1418,y:811,t:1527613793866};\\\", \\\"{x:1417,y:828,t:1527613793883};\\\", \\\"{x:1416,y:836,t:1527613793899};\\\", \\\"{x:1416,y:837,t:1527613793923};\\\", \\\"{x:1415,y:837,t:1527613793948};\\\", \\\"{x:1414,y:838,t:1527613793955};\\\", \\\"{x:1414,y:839,t:1527613794236};\\\", \\\"{x:1414,y:840,t:1527613794249};\\\", \\\"{x:1413,y:841,t:1527613794266};\\\", \\\"{x:1411,y:846,t:1527613794283};\\\", \\\"{x:1409,y:850,t:1527613794300};\\\", \\\"{x:1407,y:855,t:1527613794316};\\\", \\\"{x:1404,y:861,t:1527613794333};\\\", \\\"{x:1401,y:867,t:1527613794350};\\\", \\\"{x:1398,y:875,t:1527613794365};\\\", \\\"{x:1397,y:879,t:1527613794383};\\\", \\\"{x:1395,y:883,t:1527613794400};\\\", \\\"{x:1393,y:887,t:1527613794417};\\\", \\\"{x:1391,y:892,t:1527613794433};\\\", \\\"{x:1389,y:897,t:1527613794451};\\\", \\\"{x:1389,y:900,t:1527613794466};\\\", \\\"{x:1388,y:903,t:1527613794483};\\\", \\\"{x:1392,y:904,t:1527613794715};\\\", \\\"{x:1394,y:904,t:1527613794723};\\\", \\\"{x:1397,y:904,t:1527613794733};\\\", \\\"{x:1407,y:897,t:1527613794750};\\\", \\\"{x:1415,y:890,t:1527613794767};\\\", \\\"{x:1423,y:885,t:1527613794783};\\\", \\\"{x:1426,y:881,t:1527613794800};\\\", \\\"{x:1435,y:871,t:1527613794818};\\\", \\\"{x:1441,y:865,t:1527613794834};\\\", \\\"{x:1449,y:856,t:1527613794850};\\\", \\\"{x:1464,y:839,t:1527613794868};\\\", \\\"{x:1467,y:833,t:1527613794883};\\\", \\\"{x:1469,y:829,t:1527613794900};\\\", \\\"{x:1472,y:826,t:1527613794917};\\\", \\\"{x:1473,y:824,t:1527613794933};\\\", \\\"{x:1474,y:822,t:1527613794950};\\\", \\\"{x:1475,y:821,t:1527613794968};\\\", \\\"{x:1475,y:819,t:1527613794983};\\\", \\\"{x:1477,y:817,t:1527613795000};\\\", \\\"{x:1479,y:814,t:1527613795017};\\\", \\\"{x:1479,y:813,t:1527613795033};\\\", \\\"{x:1480,y:812,t:1527613795049};\\\", \\\"{x:1481,y:812,t:1527613795067};\\\", \\\"{x:1482,y:812,t:1527613795204};\\\", \\\"{x:1487,y:813,t:1527613795218};\\\", \\\"{x:1493,y:819,t:1527613795234};\\\", \\\"{x:1497,y:824,t:1527613795250};\\\", \\\"{x:1507,y:832,t:1527613795267};\\\", \\\"{x:1508,y:833,t:1527613795283};\\\", \\\"{x:1509,y:833,t:1527613795300};\\\", \\\"{x:1510,y:833,t:1527613795317};\\\", \\\"{x:1510,y:832,t:1527613795652};\\\", \\\"{x:1510,y:831,t:1527613795667};\\\", \\\"{x:1510,y:830,t:1527613795692};\\\", \\\"{x:1511,y:828,t:1527613795707};\\\", \\\"{x:1511,y:827,t:1527613795987};\\\", \\\"{x:1514,y:824,t:1527613796001};\\\", \\\"{x:1528,y:819,t:1527613796018};\\\", \\\"{x:1537,y:816,t:1527613796034};\\\", \\\"{x:1554,y:810,t:1527613796051};\\\", \\\"{x:1557,y:810,t:1527613796067};\\\", \\\"{x:1559,y:809,t:1527613796084};\\\", \\\"{x:1560,y:809,t:1527613796181};\\\", \\\"{x:1561,y:809,t:1527613796228};\\\", \\\"{x:1562,y:809,t:1527613796235};\\\", \\\"{x:1563,y:809,t:1527613796251};\\\", \\\"{x:1565,y:810,t:1527613796269};\\\", \\\"{x:1567,y:811,t:1527613796284};\\\", \\\"{x:1569,y:811,t:1527613796301};\\\", \\\"{x:1572,y:813,t:1527613796318};\\\", \\\"{x:1573,y:813,t:1527613796334};\\\", \\\"{x:1576,y:813,t:1527613796351};\\\", \\\"{x:1580,y:814,t:1527613796369};\\\", \\\"{x:1584,y:815,t:1527613796384};\\\", \\\"{x:1590,y:815,t:1527613796401};\\\", \\\"{x:1592,y:816,t:1527613796418};\\\", \\\"{x:1599,y:817,t:1527613796434};\\\", \\\"{x:1610,y:818,t:1527613796451};\\\", \\\"{x:1617,y:818,t:1527613796468};\\\", \\\"{x:1623,y:818,t:1527613796486};\\\", \\\"{x:1627,y:818,t:1527613796501};\\\", \\\"{x:1630,y:818,t:1527613796518};\\\", \\\"{x:1613,y:818,t:1527613796620};\\\", \\\"{x:1535,y:818,t:1527613796636};\\\", \\\"{x:1476,y:818,t:1527613796651};\\\", \\\"{x:1375,y:826,t:1527613796668};\\\", \\\"{x:1325,y:835,t:1527613796685};\\\", \\\"{x:1295,y:832,t:1527613796702};\\\", \\\"{x:1289,y:827,t:1527613796718};\\\", \\\"{x:1279,y:817,t:1527613796735};\\\", \\\"{x:1270,y:806,t:1527613796751};\\\", \\\"{x:1258,y:789,t:1527613796769};\\\", \\\"{x:1242,y:774,t:1527613796786};\\\", \\\"{x:1232,y:760,t:1527613796801};\\\", \\\"{x:1227,y:749,t:1527613796819};\\\", \\\"{x:1223,y:742,t:1527613796835};\\\", \\\"{x:1219,y:737,t:1527613796851};\\\", \\\"{x:1213,y:728,t:1527613796868};\\\", \\\"{x:1201,y:720,t:1527613796885};\\\", \\\"{x:1183,y:715,t:1527613796902};\\\", \\\"{x:1173,y:711,t:1527613796918};\\\", \\\"{x:1139,y:710,t:1527613796935};\\\", \\\"{x:1081,y:710,t:1527613796952};\\\", \\\"{x:1017,y:710,t:1527613796968};\\\", \\\"{x:939,y:710,t:1527613796985};\\\", \\\"{x:890,y:710,t:1527613797002};\\\", \\\"{x:834,y:710,t:1527613797018};\\\", \\\"{x:788,y:710,t:1527613797034};\\\", \\\"{x:765,y:708,t:1527613797051};\\\", \\\"{x:755,y:705,t:1527613797067};\\\", \\\"{x:739,y:700,t:1527613797085};\\\", \\\"{x:718,y:693,t:1527613797102};\\\", \\\"{x:707,y:689,t:1527613797118};\\\", \\\"{x:705,y:688,t:1527613797195};\\\", \\\"{x:705,y:683,t:1527613797203};\\\", \\\"{x:701,y:677,t:1527613797218};\\\", \\\"{x:699,y:672,t:1527613797235};\\\", \\\"{x:697,y:667,t:1527613797252};\\\", \\\"{x:695,y:650,t:1527613797268};\\\", \\\"{x:688,y:630,t:1527613797286};\\\", \\\"{x:672,y:603,t:1527613797302};\\\", \\\"{x:651,y:572,t:1527613797318};\\\", \\\"{x:642,y:560,t:1527613797335};\\\", \\\"{x:631,y:544,t:1527613797352};\\\", \\\"{x:622,y:535,t:1527613797368};\\\", \\\"{x:621,y:535,t:1527613797386};\\\", \\\"{x:620,y:535,t:1527613797402};\\\", \\\"{x:618,y:534,t:1527613797418};\\\", \\\"{x:616,y:534,t:1527613797458};\\\", \\\"{x:610,y:540,t:1527613797468};\\\", \\\"{x:600,y:556,t:1527613797486};\\\", \\\"{x:595,y:576,t:1527613797503};\\\", \\\"{x:595,y:589,t:1527613797518};\\\", \\\"{x:595,y:593,t:1527613797536};\\\", \\\"{x:595,y:596,t:1527613797552};\\\", \\\"{x:597,y:597,t:1527613797569};\\\", \\\"{x:599,y:597,t:1527613797586};\\\", \\\"{x:602,y:597,t:1527613797602};\\\", \\\"{x:603,y:597,t:1527613797627};\\\", \\\"{x:604,y:597,t:1527613797642};\\\", \\\"{x:605,y:597,t:1527613797763};\\\", \\\"{x:606,y:597,t:1527613797771};\\\", \\\"{x:609,y:596,t:1527613797786};\\\", \\\"{x:610,y:592,t:1527613797804};\\\", \\\"{x:612,y:589,t:1527613797819};\\\", \\\"{x:614,y:584,t:1527613797835};\\\", \\\"{x:614,y:583,t:1527613797853};\\\", \\\"{x:615,y:582,t:1527613797868};\\\", \\\"{x:616,y:582,t:1527613797886};\\\", \\\"{x:616,y:581,t:1527613797955};\\\", \\\"{x:616,y:580,t:1527613798234};\\\", \\\"{x:614,y:587,t:1527613798243};\\\", \\\"{x:612,y:598,t:1527613798253};\\\", \\\"{x:603,y:618,t:1527613798270};\\\", \\\"{x:599,y:629,t:1527613798285};\\\", \\\"{x:597,y:637,t:1527613798303};\\\", \\\"{x:595,y:643,t:1527613798320};\\\", \\\"{x:594,y:645,t:1527613798336};\\\", \\\"{x:594,y:646,t:1527613798355};\\\", \\\"{x:594,y:647,t:1527613798369};\\\", \\\"{x:594,y:649,t:1527613798386};\\\", \\\"{x:591,y:656,t:1527613798403};\\\", \\\"{x:588,y:662,t:1527613798420};\\\", \\\"{x:587,y:668,t:1527613798436};\\\", \\\"{x:587,y:669,t:1527613798453};\\\", \\\"{x:585,y:673,t:1527613798470};\\\", \\\"{x:582,y:680,t:1527613798486};\\\", \\\"{x:578,y:686,t:1527613798503};\\\", \\\"{x:576,y:692,t:1527613798521};\\\", \\\"{x:573,y:698,t:1527613798537};\\\", \\\"{x:568,y:710,t:1527613798552};\\\", \\\"{x:563,y:718,t:1527613798570};\\\", \\\"{x:550,y:734,t:1527613798587};\\\", \\\"{x:544,y:743,t:1527613798602};\\\", \\\"{x:536,y:750,t:1527613798620};\\\", \\\"{x:532,y:757,t:1527613798637};\\\", \\\"{x:529,y:759,t:1527613798653};\\\", \\\"{x:527,y:762,t:1527613798669};\\\", \\\"{x:525,y:763,t:1527613798687};\\\", \\\"{x:524,y:765,t:1527613798702};\\\", \\\"{x:523,y:765,t:1527613799347};\\\", \\\"{x:523,y:762,t:1527613799354};\\\", \\\"{x:525,y:757,t:1527613799371};\\\", \\\"{x:526,y:751,t:1527613799388};\\\", \\\"{x:526,y:748,t:1527613799403};\\\", \\\"{x:526,y:745,t:1527613799419};\\\", \\\"{x:527,y:743,t:1527613799436};\\\", \\\"{x:528,y:742,t:1527613800394};\\\", \\\"{x:528,y:741,t:1527613800405};\\\", \\\"{x:529,y:741,t:1527613800442};\\\" ] }, { \\\"rt\\\": 16646, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 15, \\\"time_elapsed\\\": 491338, \\\"internal_node_id\\\": \\\"0.0-6.0-5.0\\\", \\\"subject\\\": \\\"AZKMW\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"oscar\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 11, \\\"clicks\\\": 3.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-M -M -B -B -F \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:529,y:740,t:1527613804699};\\\", \\\"{x:534,y:734,t:1527613804709};\\\", \\\"{x:554,y:720,t:1527613804733};\\\", \\\"{x:566,y:710,t:1527613804742};\\\", \\\"{x:591,y:694,t:1527613804757};\\\", \\\"{x:602,y:684,t:1527613804774};\\\", \\\"{x:614,y:668,t:1527613804791};\\\", \\\"{x:626,y:658,t:1527613804808};\\\", \\\"{x:633,y:653,t:1527613804825};\\\", \\\"{x:636,y:647,t:1527613804841};\\\", \\\"{x:639,y:640,t:1527613804858};\\\", \\\"{x:641,y:636,t:1527613804874};\\\", \\\"{x:643,y:630,t:1527613804892};\\\", \\\"{x:645,y:618,t:1527613804908};\\\", \\\"{x:646,y:608,t:1527613804925};\\\", \\\"{x:649,y:597,t:1527613804942};\\\", \\\"{x:650,y:590,t:1527613804958};\\\", \\\"{x:651,y:584,t:1527613804975};\\\", \\\"{x:652,y:580,t:1527613804992};\\\", \\\"{x:652,y:579,t:1527613805008};\\\", \\\"{x:652,y:576,t:1527613805025};\\\", \\\"{x:652,y:571,t:1527613805042};\\\", \\\"{x:652,y:561,t:1527613805059};\\\", \\\"{x:648,y:549,t:1527613805076};\\\", \\\"{x:646,y:543,t:1527613805092};\\\", \\\"{x:644,y:536,t:1527613805107};\\\", \\\"{x:643,y:532,t:1527613805125};\\\", \\\"{x:641,y:528,t:1527613805142};\\\", \\\"{x:640,y:525,t:1527613805159};\\\", \\\"{x:639,y:524,t:1527613805180};\\\", \\\"{x:639,y:523,t:1527613805219};\\\", \\\"{x:639,y:522,t:1527613805331};\\\", \\\"{x:639,y:521,t:1527613805406};\\\", \\\"{x:639,y:520,t:1527613805413};\\\", \\\"{x:639,y:519,t:1527613805428};\\\", \\\"{x:639,y:517,t:1527613805446};\\\", \\\"{x:639,y:516,t:1527613805462};\\\", \\\"{x:640,y:514,t:1527613805478};\\\", \\\"{x:641,y:513,t:1527613805495};\\\", \\\"{x:642,y:512,t:1527613805512};\\\", \\\"{x:642,y:511,t:1527613805529};\\\", \\\"{x:643,y:511,t:1527613805546};\\\", \\\"{x:644,y:511,t:1527613805799};\\\", \\\"{x:654,y:511,t:1527613805813};\\\", \\\"{x:702,y:524,t:1527613805831};\\\", \\\"{x:786,y:553,t:1527613805847};\\\", \\\"{x:977,y:608,t:1527613805863};\\\", \\\"{x:1100,y:648,t:1527613805879};\\\", \\\"{x:1189,y:679,t:1527613805895};\\\", \\\"{x:1302,y:723,t:1527613805912};\\\", \\\"{x:1394,y:773,t:1527613805929};\\\", \\\"{x:1458,y:815,t:1527613805946};\\\", \\\"{x:1495,y:844,t:1527613805962};\\\", \\\"{x:1516,y:857,t:1527613805979};\\\", \\\"{x:1528,y:874,t:1527613805995};\\\", \\\"{x:1534,y:884,t:1527613806013};\\\", \\\"{x:1537,y:890,t:1527613806029};\\\", \\\"{x:1537,y:891,t:1527613806045};\\\", \\\"{x:1537,y:892,t:1527613806119};\\\", \\\"{x:1537,y:894,t:1527613806130};\\\", \\\"{x:1532,y:902,t:1527613806146};\\\", \\\"{x:1527,y:906,t:1527613806163};\\\", \\\"{x:1523,y:907,t:1527613806180};\\\", \\\"{x:1515,y:908,t:1527613806196};\\\", \\\"{x:1506,y:910,t:1527613806213};\\\", \\\"{x:1498,y:910,t:1527613806230};\\\", \\\"{x:1489,y:910,t:1527613806246};\\\", \\\"{x:1480,y:907,t:1527613806264};\\\", \\\"{x:1472,y:905,t:1527613806280};\\\", \\\"{x:1468,y:903,t:1527613806296};\\\", \\\"{x:1465,y:902,t:1527613806313};\\\", \\\"{x:1462,y:901,t:1527613806330};\\\", \\\"{x:1453,y:898,t:1527613806347};\\\", \\\"{x:1444,y:892,t:1527613806363};\\\", \\\"{x:1434,y:888,t:1527613806380};\\\", \\\"{x:1419,y:884,t:1527613806397};\\\", \\\"{x:1409,y:883,t:1527613806413};\\\", \\\"{x:1402,y:881,t:1527613806430};\\\", \\\"{x:1399,y:881,t:1527613806446};\\\", \\\"{x:1398,y:881,t:1527613806599};\\\", \\\"{x:1397,y:880,t:1527613806622};\\\", \\\"{x:1397,y:879,t:1527613806630};\\\", \\\"{x:1396,y:877,t:1527613806647};\\\", \\\"{x:1395,y:875,t:1527613806664};\\\", \\\"{x:1394,y:872,t:1527613806679};\\\", \\\"{x:1393,y:865,t:1527613806697};\\\", \\\"{x:1390,y:854,t:1527613806713};\\\", \\\"{x:1387,y:839,t:1527613806729};\\\", \\\"{x:1383,y:828,t:1527613806747};\\\", \\\"{x:1383,y:815,t:1527613806763};\\\", \\\"{x:1381,y:805,t:1527613806779};\\\", \\\"{x:1380,y:800,t:1527613806797};\\\", \\\"{x:1380,y:793,t:1527613806813};\\\", \\\"{x:1380,y:785,t:1527613806830};\\\", \\\"{x:1381,y:769,t:1527613806846};\\\", \\\"{x:1382,y:762,t:1527613806864};\\\", \\\"{x:1382,y:759,t:1527613806879};\\\", \\\"{x:1380,y:748,t:1527613806896};\\\", \\\"{x:1380,y:743,t:1527613806914};\\\", \\\"{x:1380,y:736,t:1527613806929};\\\", \\\"{x:1380,y:731,t:1527613806946};\\\", \\\"{x:1380,y:724,t:1527613806963};\\\", \\\"{x:1380,y:718,t:1527613806979};\\\", \\\"{x:1380,y:710,t:1527613806996};\\\", \\\"{x:1382,y:699,t:1527613807014};\\\", \\\"{x:1382,y:693,t:1527613807029};\\\", \\\"{x:1383,y:690,t:1527613807047};\\\", \\\"{x:1385,y:686,t:1527613807063};\\\", \\\"{x:1385,y:682,t:1527613807079};\\\", \\\"{x:1386,y:677,t:1527613807096};\\\", \\\"{x:1387,y:674,t:1527613807114};\\\", \\\"{x:1387,y:670,t:1527613807130};\\\", \\\"{x:1388,y:667,t:1527613807147};\\\", \\\"{x:1389,y:664,t:1527613807164};\\\", \\\"{x:1390,y:660,t:1527613807180};\\\", \\\"{x:1391,y:657,t:1527613807197};\\\", \\\"{x:1392,y:653,t:1527613807214};\\\", \\\"{x:1392,y:650,t:1527613807230};\\\", \\\"{x:1392,y:648,t:1527613807247};\\\", \\\"{x:1393,y:645,t:1527613807264};\\\", \\\"{x:1394,y:643,t:1527613807280};\\\", \\\"{x:1395,y:640,t:1527613807297};\\\", \\\"{x:1395,y:638,t:1527613807314};\\\", \\\"{x:1395,y:637,t:1527613807330};\\\", \\\"{x:1396,y:635,t:1527613807347};\\\", \\\"{x:1396,y:636,t:1527613807846};\\\", \\\"{x:1396,y:637,t:1527613807862};\\\", \\\"{x:1396,y:639,t:1527613807918};\\\", \\\"{x:1395,y:642,t:1527613807930};\\\", \\\"{x:1394,y:645,t:1527613807946};\\\", \\\"{x:1394,y:649,t:1527613807963};\\\", \\\"{x:1392,y:654,t:1527613807980};\\\", \\\"{x:1391,y:661,t:1527613807997};\\\", \\\"{x:1391,y:670,t:1527613808013};\\\", \\\"{x:1390,y:676,t:1527613808031};\\\", \\\"{x:1388,y:682,t:1527613808047};\\\", \\\"{x:1387,y:688,t:1527613808064};\\\", \\\"{x:1386,y:694,t:1527613808080};\\\", \\\"{x:1383,y:704,t:1527613808098};\\\", \\\"{x:1382,y:717,t:1527613808114};\\\", \\\"{x:1380,y:723,t:1527613808131};\\\", \\\"{x:1377,y:732,t:1527613808148};\\\", \\\"{x:1374,y:741,t:1527613808164};\\\", \\\"{x:1373,y:748,t:1527613808181};\\\", \\\"{x:1373,y:757,t:1527613808199};\\\", \\\"{x:1370,y:766,t:1527613808214};\\\", \\\"{x:1370,y:775,t:1527613808231};\\\", \\\"{x:1368,y:785,t:1527613808248};\\\", \\\"{x:1366,y:796,t:1527613808265};\\\", \\\"{x:1365,y:802,t:1527613808281};\\\", \\\"{x:1364,y:808,t:1527613808298};\\\", \\\"{x:1364,y:811,t:1527613808314};\\\", \\\"{x:1362,y:817,t:1527613808331};\\\", \\\"{x:1362,y:821,t:1527613808348};\\\", \\\"{x:1363,y:827,t:1527613808364};\\\", \\\"{x:1363,y:833,t:1527613808381};\\\", \\\"{x:1365,y:840,t:1527613808398};\\\", \\\"{x:1367,y:848,t:1527613808414};\\\", \\\"{x:1369,y:853,t:1527613808431};\\\", \\\"{x:1371,y:858,t:1527613808448};\\\", \\\"{x:1371,y:862,t:1527613808464};\\\", \\\"{x:1373,y:863,t:1527613808481};\\\", \\\"{x:1376,y:868,t:1527613808498};\\\", \\\"{x:1378,y:873,t:1527613808514};\\\", \\\"{x:1379,y:878,t:1527613808531};\\\", \\\"{x:1382,y:882,t:1527613808547};\\\", \\\"{x:1383,y:888,t:1527613808564};\\\", \\\"{x:1384,y:893,t:1527613808584};\\\", \\\"{x:1385,y:902,t:1527613808597};\\\", \\\"{x:1385,y:909,t:1527613808613};\\\", \\\"{x:1384,y:914,t:1527613808630};\\\", \\\"{x:1384,y:915,t:1527613808647};\\\", \\\"{x:1384,y:917,t:1527613808665};\\\", \\\"{x:1381,y:922,t:1527613808681};\\\", \\\"{x:1380,y:923,t:1527613808697};\\\", \\\"{x:1377,y:928,t:1527613808714};\\\", \\\"{x:1374,y:936,t:1527613808730};\\\", \\\"{x:1372,y:938,t:1527613808747};\\\", \\\"{x:1370,y:940,t:1527613808765};\\\", \\\"{x:1368,y:943,t:1527613808781};\\\", \\\"{x:1368,y:945,t:1527613808806};\\\", \\\"{x:1366,y:945,t:1527613808822};\\\", \\\"{x:1365,y:946,t:1527613808895};\\\", \\\"{x:1364,y:947,t:1527613808902};\\\", \\\"{x:1363,y:947,t:1527613808919};\\\", \\\"{x:1362,y:948,t:1527613808934};\\\", \\\"{x:1361,y:949,t:1527613808948};\\\", \\\"{x:1359,y:950,t:1527613808965};\\\", \\\"{x:1358,y:950,t:1527613808990};\\\", \\\"{x:1357,y:952,t:1527613809182};\\\", \\\"{x:1356,y:952,t:1527613809198};\\\", \\\"{x:1355,y:953,t:1527613809215};\\\", \\\"{x:1353,y:954,t:1527613809232};\\\", \\\"{x:1351,y:955,t:1527613809248};\\\", \\\"{x:1350,y:956,t:1527613809265};\\\", \\\"{x:1349,y:958,t:1527613809282};\\\", \\\"{x:1348,y:958,t:1527613809310};\\\", \\\"{x:1347,y:958,t:1527613809318};\\\", \\\"{x:1345,y:959,t:1527613809350};\\\", \\\"{x:1345,y:960,t:1527613809364};\\\", \\\"{x:1343,y:962,t:1527613809382};\\\", \\\"{x:1342,y:962,t:1527613809397};\\\", \\\"{x:1341,y:962,t:1527613809415};\\\", \\\"{x:1339,y:962,t:1527613809693};\\\", \\\"{x:1339,y:961,t:1527613809701};\\\", \\\"{x:1337,y:957,t:1527613809714};\\\", \\\"{x:1335,y:950,t:1527613809731};\\\", \\\"{x:1333,y:944,t:1527613809748};\\\", \\\"{x:1332,y:939,t:1527613809764};\\\", \\\"{x:1331,y:931,t:1527613809781};\\\", \\\"{x:1331,y:927,t:1527613809798};\\\", \\\"{x:1329,y:921,t:1527613809814};\\\", \\\"{x:1329,y:915,t:1527613809832};\\\", \\\"{x:1329,y:912,t:1527613809848};\\\", \\\"{x:1329,y:907,t:1527613809864};\\\", \\\"{x:1329,y:904,t:1527613809882};\\\", \\\"{x:1328,y:903,t:1527613809899};\\\", \\\"{x:1328,y:901,t:1527613809914};\\\", \\\"{x:1328,y:898,t:1527613809932};\\\", \\\"{x:1328,y:894,t:1527613809949};\\\", \\\"{x:1328,y:891,t:1527613809965};\\\", \\\"{x:1326,y:888,t:1527613809982};\\\", \\\"{x:1326,y:885,t:1527613809998};\\\", \\\"{x:1326,y:880,t:1527613810015};\\\", \\\"{x:1327,y:875,t:1527613810032};\\\", \\\"{x:1327,y:872,t:1527613810050};\\\", \\\"{x:1329,y:869,t:1527613810065};\\\", \\\"{x:1330,y:866,t:1527613810082};\\\", \\\"{x:1330,y:862,t:1527613810099};\\\", \\\"{x:1332,y:857,t:1527613810116};\\\", \\\"{x:1335,y:854,t:1527613810132};\\\", \\\"{x:1337,y:848,t:1527613810149};\\\", \\\"{x:1340,y:843,t:1527613810164};\\\", \\\"{x:1344,y:834,t:1527613810182};\\\", \\\"{x:1345,y:830,t:1527613810199};\\\", \\\"{x:1348,y:824,t:1527613810215};\\\", \\\"{x:1349,y:821,t:1527613810239};\\\", \\\"{x:1350,y:814,t:1527613810258};\\\", \\\"{x:1352,y:813,t:1527613810265};\\\", \\\"{x:1356,y:803,t:1527613810299};\\\", \\\"{x:1358,y:799,t:1527613810315};\\\", \\\"{x:1359,y:796,t:1527613810331};\\\", \\\"{x:1361,y:795,t:1527613810590};\\\", \\\"{x:1361,y:794,t:1527613810606};\\\", \\\"{x:1361,y:793,t:1527613810616};\\\", \\\"{x:1361,y:791,t:1527613810632};\\\", \\\"{x:1361,y:790,t:1527613810648};\\\", \\\"{x:1361,y:788,t:1527613810665};\\\", \\\"{x:1361,y:787,t:1527613810686};\\\", \\\"{x:1361,y:785,t:1527613810847};\\\", \\\"{x:1361,y:782,t:1527613810878};\\\", \\\"{x:1360,y:780,t:1527613810886};\\\", \\\"{x:1360,y:779,t:1527613810899};\\\", \\\"{x:1358,y:775,t:1527613810917};\\\", \\\"{x:1354,y:769,t:1527613810932};\\\", \\\"{x:1352,y:766,t:1527613810949};\\\", \\\"{x:1351,y:763,t:1527613810966};\\\", \\\"{x:1350,y:761,t:1527613810982};\\\", \\\"{x:1350,y:760,t:1527613811006};\\\", \\\"{x:1350,y:758,t:1527613811022};\\\", \\\"{x:1349,y:757,t:1527613811034};\\\", \\\"{x:1349,y:755,t:1527613811049};\\\", \\\"{x:1348,y:752,t:1527613811066};\\\", \\\"{x:1348,y:751,t:1527613811082};\\\", \\\"{x:1348,y:749,t:1527613811099};\\\", \\\"{x:1348,y:745,t:1527613811116};\\\", \\\"{x:1348,y:742,t:1527613811133};\\\", \\\"{x:1348,y:737,t:1527613811149};\\\", \\\"{x:1349,y:729,t:1527613811166};\\\", \\\"{x:1348,y:716,t:1527613811182};\\\", \\\"{x:1343,y:695,t:1527613811199};\\\", \\\"{x:1323,y:664,t:1527613811217};\\\", \\\"{x:1263,y:609,t:1527613811233};\\\", \\\"{x:1158,y:540,t:1527613811249};\\\", \\\"{x:1047,y:481,t:1527613811266};\\\", \\\"{x:918,y:436,t:1527613811283};\\\", \\\"{x:792,y:404,t:1527613811299};\\\", \\\"{x:668,y:373,t:1527613811316};\\\", \\\"{x:570,y:355,t:1527613811333};\\\", \\\"{x:485,y:349,t:1527613811348};\\\", \\\"{x:379,y:349,t:1527613811366};\\\", \\\"{x:298,y:350,t:1527613811382};\\\", \\\"{x:214,y:367,t:1527613811399};\\\", \\\"{x:147,y:384,t:1527613811416};\\\", \\\"{x:131,y:396,t:1527613811433};\\\", \\\"{x:108,y:409,t:1527613811449};\\\", \\\"{x:97,y:418,t:1527613811466};\\\", \\\"{x:93,y:426,t:1527613811482};\\\", \\\"{x:88,y:440,t:1527613811500};\\\", \\\"{x:86,y:452,t:1527613811516};\\\", \\\"{x:86,y:463,t:1527613811533};\\\", \\\"{x:88,y:483,t:1527613811550};\\\", \\\"{x:94,y:498,t:1527613811568};\\\", \\\"{x:104,y:509,t:1527613811582};\\\", \\\"{x:115,y:519,t:1527613811600};\\\", \\\"{x:119,y:522,t:1527613811608};\\\", \\\"{x:139,y:531,t:1527613811626};\\\", \\\"{x:165,y:538,t:1527613811643};\\\", \\\"{x:193,y:543,t:1527613811667};\\\", \\\"{x:207,y:544,t:1527613811683};\\\", \\\"{x:215,y:544,t:1527613811701};\\\", \\\"{x:219,y:544,t:1527613811717};\\\", \\\"{x:218,y:544,t:1527613811903};\\\", \\\"{x:214,y:544,t:1527613811917};\\\", \\\"{x:207,y:544,t:1527613811934};\\\", \\\"{x:200,y:546,t:1527613811951};\\\", \\\"{x:200,y:547,t:1527613812606};\\\", \\\"{x:197,y:550,t:1527613812622};\\\", \\\"{x:190,y:549,t:1527613812635};\\\", \\\"{x:164,y:544,t:1527613812653};\\\", \\\"{x:144,y:542,t:1527613812669};\\\", \\\"{x:133,y:539,t:1527613812684};\\\", \\\"{x:126,y:537,t:1527613812702};\\\", \\\"{x:124,y:537,t:1527613812717};\\\", \\\"{x:123,y:535,t:1527613812735};\\\", \\\"{x:123,y:531,t:1527613812752};\\\", \\\"{x:124,y:531,t:1527613812768};\\\", \\\"{x:125,y:531,t:1527613812863};\\\", \\\"{x:126,y:531,t:1527613812990};\\\", \\\"{x:127,y:531,t:1527613813005};\\\", \\\"{x:129,y:531,t:1527613813046};\\\", \\\"{x:130,y:531,t:1527613813078};\\\", \\\"{x:131,y:531,t:1527613813102};\\\", \\\"{x:134,y:531,t:1527613813134};\\\", \\\"{x:136,y:532,t:1527613813158};\\\", \\\"{x:137,y:532,t:1527613813238};\\\", \\\"{x:144,y:533,t:1527613813718};\\\", \\\"{x:170,y:533,t:1527613813736};\\\", \\\"{x:196,y:533,t:1527613813754};\\\", \\\"{x:222,y:535,t:1527613813767};\\\", \\\"{x:244,y:537,t:1527613813784};\\\", \\\"{x:263,y:543,t:1527613813800};\\\", \\\"{x:270,y:543,t:1527613813817};\\\", \\\"{x:270,y:544,t:1527613813877};\\\", \\\"{x:269,y:545,t:1527613813885};\\\", \\\"{x:266,y:546,t:1527613813900};\\\", \\\"{x:260,y:549,t:1527613813916};\\\", \\\"{x:242,y:553,t:1527613813933};\\\", \\\"{x:232,y:555,t:1527613813950};\\\", \\\"{x:218,y:558,t:1527613813969};\\\", \\\"{x:210,y:558,t:1527613813983};\\\", \\\"{x:209,y:558,t:1527613814013};\\\", \\\"{x:207,y:558,t:1527613814157};\\\", \\\"{x:202,y:558,t:1527613814169};\\\", \\\"{x:191,y:558,t:1527613814185};\\\", \\\"{x:169,y:556,t:1527613814203};\\\", \\\"{x:153,y:550,t:1527613814221};\\\", \\\"{x:136,y:548,t:1527613814235};\\\", \\\"{x:129,y:546,t:1527613814252};\\\", \\\"{x:121,y:545,t:1527613814268};\\\", \\\"{x:121,y:544,t:1527613814438};\\\", \\\"{x:121,y:542,t:1527613814454};\\\", \\\"{x:122,y:540,t:1527613814469};\\\", \\\"{x:123,y:539,t:1527613814486};\\\", \\\"{x:125,y:538,t:1527613814503};\\\", \\\"{x:128,y:538,t:1527613814534};\\\", \\\"{x:129,y:538,t:1527613814550};\\\", \\\"{x:131,y:538,t:1527613814558};\\\", \\\"{x:133,y:538,t:1527613814570};\\\", \\\"{x:135,y:538,t:1527613814586};\\\", \\\"{x:139,y:538,t:1527613814602};\\\", \\\"{x:142,y:538,t:1527613814620};\\\", \\\"{x:144,y:538,t:1527613814636};\\\", \\\"{x:146,y:538,t:1527613814653};\\\", \\\"{x:149,y:538,t:1527613814671};\\\", \\\"{x:151,y:538,t:1527613814687};\\\", \\\"{x:152,y:538,t:1527613814703};\\\", \\\"{x:155,y:539,t:1527613814718};\\\", \\\"{x:156,y:539,t:1527613814736};\\\", \\\"{x:157,y:539,t:1527613814758};\\\", \\\"{x:158,y:539,t:1527613814769};\\\", \\\"{x:159,y:539,t:1527613815101};\\\", \\\"{x:161,y:539,t:1527613815109};\\\", \\\"{x:163,y:539,t:1527613815120};\\\", \\\"{x:175,y:534,t:1527613815137};\\\", \\\"{x:191,y:528,t:1527613815153};\\\", \\\"{x:210,y:523,t:1527613815170};\\\", \\\"{x:259,y:514,t:1527613815187};\\\", \\\"{x:333,y:506,t:1527613815204};\\\", \\\"{x:384,y:505,t:1527613815220};\\\", \\\"{x:480,y:499,t:1527613815237};\\\", \\\"{x:624,y:499,t:1527613815254};\\\", \\\"{x:713,y:499,t:1527613815269};\\\", \\\"{x:769,y:499,t:1527613815287};\\\", \\\"{x:793,y:499,t:1527613815303};\\\", \\\"{x:801,y:499,t:1527613815319};\\\", \\\"{x:803,y:499,t:1527613815337};\\\", \\\"{x:804,y:499,t:1527613815366};\\\", \\\"{x:806,y:499,t:1527613815397};\\\", \\\"{x:808,y:498,t:1527613815406};\\\", \\\"{x:810,y:498,t:1527613815422};\\\", \\\"{x:811,y:497,t:1527613815437};\\\", \\\"{x:813,y:497,t:1527613815454};\\\", \\\"{x:814,y:497,t:1527613815638};\\\", \\\"{x:815,y:496,t:1527613815655};\\\", \\\"{x:816,y:496,t:1527613815721};\\\", \\\"{x:816,y:496,t:1527613815737};\\\", \\\"{x:817,y:496,t:1527613816078};\\\", \\\"{x:818,y:498,t:1527613816093};\\\", \\\"{x:820,y:500,t:1527613816105};\\\", \\\"{x:824,y:503,t:1527613816121};\\\", \\\"{x:828,y:504,t:1527613816139};\\\", \\\"{x:830,y:507,t:1527613816154};\\\", \\\"{x:832,y:508,t:1527613816170};\\\", \\\"{x:833,y:509,t:1527613816213};\\\", \\\"{x:834,y:509,t:1527613816221};\\\", \\\"{x:835,y:509,t:1527613816237};\\\", \\\"{x:835,y:510,t:1527613816253};\\\", \\\"{x:830,y:518,t:1527613816574};\\\", \\\"{x:820,y:527,t:1527613816588};\\\", \\\"{x:796,y:547,t:1527613816605};\\\", \\\"{x:774,y:564,t:1527613816623};\\\", \\\"{x:718,y:606,t:1527613816638};\\\", \\\"{x:668,y:640,t:1527613816655};\\\", \\\"{x:638,y:664,t:1527613816671};\\\", \\\"{x:612,y:679,t:1527613816687};\\\", \\\"{x:589,y:692,t:1527613816705};\\\", \\\"{x:571,y:704,t:1527613816721};\\\", \\\"{x:562,y:709,t:1527613816738};\\\", \\\"{x:555,y:714,t:1527613816755};\\\", \\\"{x:553,y:715,t:1527613816771};\\\", \\\"{x:550,y:717,t:1527613816788};\\\", \\\"{x:549,y:720,t:1527613816807};\\\", \\\"{x:542,y:726,t:1527613816821};\\\", \\\"{x:534,y:737,t:1527613816837};\\\", \\\"{x:528,y:744,t:1527613816854};\\\", \\\"{x:523,y:749,t:1527613816872};\\\", \\\"{x:519,y:752,t:1527613816887};\\\", \\\"{x:516,y:755,t:1527613816905};\\\", \\\"{x:515,y:755,t:1527613816925};\\\", \\\"{x:515,y:756,t:1527613816938};\\\", \\\"{x:515,y:757,t:1527613816957};\\\", \\\"{x:515,y:759,t:1527613816971};\\\", \\\"{x:514,y:759,t:1527613816997};\\\", \\\"{x:513,y:758,t:1527613817318};\\\", \\\"{x:513,y:754,t:1527613817327};\\\", \\\"{x:513,y:752,t:1527613817338};\\\", \\\"{x:514,y:748,t:1527613817355};\\\", \\\"{x:516,y:741,t:1527613817372};\\\", \\\"{x:516,y:739,t:1527613817389};\\\", \\\"{x:516,y:737,t:1527613817404};\\\", \\\"{x:516,y:736,t:1527613817989};\\\" ] }, { \\\"rt\\\": 11004, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 16, \\\"time_elapsed\\\": 503657, \\\"internal_node_id\\\": \\\"0.0-6.0-6.0\\\", \\\"subject\\\": \\\"AZKMW\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"oscar\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 12, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F -B -B \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:522,y:734,t:1527613823199};\\\", \\\"{x:543,y:728,t:1527613823217};\\\", \\\"{x:569,y:720,t:1527613823234};\\\", \\\"{x:586,y:717,t:1527613823249};\\\", \\\"{x:620,y:717,t:1527613823265};\\\", \\\"{x:673,y:717,t:1527613823277};\\\", \\\"{x:734,y:717,t:1527613823292};\\\", \\\"{x:793,y:718,t:1527613823309};\\\", \\\"{x:860,y:725,t:1527613823327};\\\", \\\"{x:895,y:725,t:1527613823343};\\\", \\\"{x:919,y:725,t:1527613823360};\\\", \\\"{x:952,y:725,t:1527613823377};\\\", \\\"{x:983,y:725,t:1527613823393};\\\", \\\"{x:1039,y:725,t:1527613823409};\\\", \\\"{x:1101,y:726,t:1527613823427};\\\", \\\"{x:1163,y:732,t:1527613823442};\\\", \\\"{x:1205,y:732,t:1527613823459};\\\", \\\"{x:1293,y:733,t:1527613823476};\\\", \\\"{x:1350,y:729,t:1527613823493};\\\", \\\"{x:1400,y:729,t:1527613823510};\\\", \\\"{x:1425,y:729,t:1527613823527};\\\", \\\"{x:1444,y:729,t:1527613823543};\\\", \\\"{x:1453,y:728,t:1527613823559};\\\", \\\"{x:1457,y:727,t:1527613823577};\\\", \\\"{x:1459,y:727,t:1527613823594};\\\", \\\"{x:1459,y:726,t:1527613823609};\\\", \\\"{x:1458,y:726,t:1527613823789};\\\", \\\"{x:1456,y:727,t:1527613823797};\\\", \\\"{x:1453,y:727,t:1527613823810};\\\", \\\"{x:1446,y:730,t:1527613823826};\\\", \\\"{x:1445,y:730,t:1527613823844};\\\", \\\"{x:1444,y:731,t:1527613823868};\\\", \\\"{x:1442,y:731,t:1527613824164};\\\", \\\"{x:1442,y:729,t:1527613824176};\\\", \\\"{x:1443,y:722,t:1527613824193};\\\", \\\"{x:1447,y:714,t:1527613824210};\\\", \\\"{x:1448,y:712,t:1527613824227};\\\", \\\"{x:1449,y:706,t:1527613824244};\\\", \\\"{x:1452,y:697,t:1527613824261};\\\", \\\"{x:1455,y:687,t:1527613824277};\\\", \\\"{x:1456,y:683,t:1527613824294};\\\", \\\"{x:1461,y:675,t:1527613824311};\\\", \\\"{x:1463,y:671,t:1527613824326};\\\", \\\"{x:1466,y:667,t:1527613824344};\\\", \\\"{x:1468,y:662,t:1527613824361};\\\", \\\"{x:1471,y:657,t:1527613824377};\\\", \\\"{x:1477,y:643,t:1527613824394};\\\", \\\"{x:1479,y:641,t:1527613824411};\\\", \\\"{x:1480,y:637,t:1527613824427};\\\", \\\"{x:1484,y:632,t:1527613824444};\\\", \\\"{x:1486,y:630,t:1527613824462};\\\", \\\"{x:1487,y:628,t:1527613824478};\\\", \\\"{x:1490,y:624,t:1527613824494};\\\", \\\"{x:1491,y:624,t:1527613824511};\\\", \\\"{x:1493,y:623,t:1527613824528};\\\", \\\"{x:1493,y:622,t:1527613824545};\\\", \\\"{x:1495,y:622,t:1527613824573};\\\", \\\"{x:1495,y:621,t:1527613824582};\\\", \\\"{x:1496,y:621,t:1527613824594};\\\", \\\"{x:1498,y:621,t:1527613824622};\\\", \\\"{x:1500,y:621,t:1527613824630};\\\", \\\"{x:1502,y:621,t:1527613824646};\\\", \\\"{x:1506,y:621,t:1527613824661};\\\", \\\"{x:1514,y:624,t:1527613824678};\\\", \\\"{x:1527,y:629,t:1527613824695};\\\", \\\"{x:1535,y:634,t:1527613824712};\\\", \\\"{x:1542,y:635,t:1527613824729};\\\", \\\"{x:1546,y:638,t:1527613824744};\\\", \\\"{x:1551,y:639,t:1527613824762};\\\", \\\"{x:1554,y:641,t:1527613824778};\\\", \\\"{x:1556,y:643,t:1527613824798};\\\", \\\"{x:1557,y:644,t:1527613824811};\\\", \\\"{x:1561,y:648,t:1527613824829};\\\", \\\"{x:1561,y:652,t:1527613824845};\\\", \\\"{x:1561,y:662,t:1527613824862};\\\", \\\"{x:1559,y:671,t:1527613824878};\\\", \\\"{x:1555,y:678,t:1527613824895};\\\", \\\"{x:1548,y:689,t:1527613824912};\\\", \\\"{x:1537,y:704,t:1527613824928};\\\", \\\"{x:1523,y:716,t:1527613824945};\\\", \\\"{x:1509,y:725,t:1527613824961};\\\", \\\"{x:1497,y:736,t:1527613824978};\\\", \\\"{x:1490,y:740,t:1527613824996};\\\", \\\"{x:1481,y:745,t:1527613825012};\\\", \\\"{x:1471,y:750,t:1527613825029};\\\", \\\"{x:1445,y:763,t:1527613825046};\\\", \\\"{x:1428,y:769,t:1527613825062};\\\", \\\"{x:1400,y:779,t:1527613825079};\\\", \\\"{x:1394,y:780,t:1527613825096};\\\", \\\"{x:1390,y:781,t:1527613825112};\\\", \\\"{x:1387,y:781,t:1527613825182};\\\", \\\"{x:1385,y:776,t:1527613825195};\\\", \\\"{x:1375,y:752,t:1527613825211};\\\", \\\"{x:1366,y:736,t:1527613825229};\\\", \\\"{x:1359,y:723,t:1527613825246};\\\", \\\"{x:1352,y:713,t:1527613825262};\\\", \\\"{x:1345,y:699,t:1527613825281};\\\", \\\"{x:1340,y:690,t:1527613825295};\\\", \\\"{x:1338,y:685,t:1527613825311};\\\", \\\"{x:1337,y:681,t:1527613825328};\\\", \\\"{x:1334,y:678,t:1527613825345};\\\", \\\"{x:1333,y:675,t:1527613825361};\\\", \\\"{x:1332,y:675,t:1527613825378};\\\", \\\"{x:1332,y:674,t:1527613825395};\\\", \\\"{x:1333,y:674,t:1527613825630};\\\", \\\"{x:1354,y:680,t:1527613825646};\\\", \\\"{x:1357,y:682,t:1527613825662};\\\", \\\"{x:1363,y:683,t:1527613825679};\\\", \\\"{x:1367,y:685,t:1527613825696};\\\", \\\"{x:1368,y:685,t:1527613825902};\\\", \\\"{x:1368,y:689,t:1527613825918};\\\", \\\"{x:1368,y:693,t:1527613825929};\\\", \\\"{x:1361,y:706,t:1527613825946};\\\", \\\"{x:1356,y:718,t:1527613825962};\\\", \\\"{x:1352,y:731,t:1527613825980};\\\", \\\"{x:1350,y:742,t:1527613825995};\\\", \\\"{x:1349,y:747,t:1527613826013};\\\", \\\"{x:1349,y:749,t:1527613826029};\\\", \\\"{x:1349,y:751,t:1527613826134};\\\", \\\"{x:1349,y:755,t:1527613826145};\\\", \\\"{x:1352,y:763,t:1527613826164};\\\", \\\"{x:1354,y:769,t:1527613826181};\\\", \\\"{x:1355,y:772,t:1527613826195};\\\", \\\"{x:1356,y:774,t:1527613826213};\\\", \\\"{x:1356,y:778,t:1527613826230};\\\", \\\"{x:1358,y:783,t:1527613826246};\\\", \\\"{x:1359,y:786,t:1527613826262};\\\", \\\"{x:1359,y:789,t:1527613826280};\\\", \\\"{x:1359,y:791,t:1527613826297};\\\", \\\"{x:1359,y:793,t:1527613826313};\\\", \\\"{x:1359,y:794,t:1527613826329};\\\", \\\"{x:1356,y:795,t:1527613826382};\\\", \\\"{x:1353,y:795,t:1527613826396};\\\", \\\"{x:1333,y:795,t:1527613826412};\\\", \\\"{x:1293,y:782,t:1527613826430};\\\", \\\"{x:1250,y:759,t:1527613826446};\\\", \\\"{x:1194,y:730,t:1527613826462};\\\", \\\"{x:1132,y:700,t:1527613826480};\\\", \\\"{x:1084,y:675,t:1527613826497};\\\", \\\"{x:1034,y:652,t:1527613826513};\\\", \\\"{x:996,y:630,t:1527613826530};\\\", \\\"{x:974,y:615,t:1527613826546};\\\", \\\"{x:949,y:601,t:1527613826564};\\\", \\\"{x:936,y:593,t:1527613826580};\\\", \\\"{x:931,y:590,t:1527613826595};\\\", \\\"{x:929,y:589,t:1527613826611};\\\", \\\"{x:928,y:589,t:1527613826717};\\\", \\\"{x:926,y:589,t:1527613826729};\\\", \\\"{x:924,y:589,t:1527613826766};\\\", \\\"{x:923,y:588,t:1527613826869};\\\", \\\"{x:918,y:577,t:1527613826879};\\\", \\\"{x:907,y:561,t:1527613826897};\\\", \\\"{x:892,y:549,t:1527613826914};\\\", \\\"{x:876,y:539,t:1527613826929};\\\", \\\"{x:850,y:527,t:1527613826946};\\\", \\\"{x:832,y:521,t:1527613826963};\\\", \\\"{x:813,y:516,t:1527613826980};\\\", \\\"{x:790,y:516,t:1527613826996};\\\", \\\"{x:749,y:516,t:1527613827013};\\\", \\\"{x:735,y:514,t:1527613827028};\\\", \\\"{x:677,y:532,t:1527613827046};\\\", \\\"{x:616,y:559,t:1527613827063};\\\", \\\"{x:533,y:596,t:1527613827080};\\\", \\\"{x:500,y:603,t:1527613827097};\\\", \\\"{x:459,y:617,t:1527613827113};\\\", \\\"{x:439,y:624,t:1527613827129};\\\", \\\"{x:434,y:625,t:1527613827146};\\\", \\\"{x:426,y:624,t:1527613827163};\\\", \\\"{x:423,y:625,t:1527613827180};\\\", \\\"{x:423,y:626,t:1527613827196};\\\", \\\"{x:423,y:627,t:1527613827221};\\\", \\\"{x:422,y:629,t:1527613827237};\\\", \\\"{x:418,y:629,t:1527613827342};\\\", \\\"{x:411,y:623,t:1527613827351};\\\", \\\"{x:402,y:621,t:1527613827363};\\\", \\\"{x:393,y:617,t:1527613827380};\\\", \\\"{x:385,y:616,t:1527613827396};\\\", \\\"{x:372,y:614,t:1527613827413};\\\", \\\"{x:358,y:613,t:1527613827430};\\\", \\\"{x:342,y:611,t:1527613827447};\\\", \\\"{x:324,y:611,t:1527613827463};\\\", \\\"{x:305,y:611,t:1527613827480};\\\", \\\"{x:301,y:611,t:1527613827496};\\\", \\\"{x:298,y:611,t:1527613827513};\\\", \\\"{x:295,y:611,t:1527613827530};\\\", \\\"{x:293,y:609,t:1527613827547};\\\", \\\"{x:291,y:605,t:1527613827563};\\\", \\\"{x:288,y:599,t:1527613827580};\\\", \\\"{x:272,y:582,t:1527613827598};\\\", \\\"{x:254,y:570,t:1527613827613};\\\", \\\"{x:244,y:567,t:1527613827630};\\\", \\\"{x:225,y:563,t:1527613827647};\\\", \\\"{x:204,y:555,t:1527613827664};\\\", \\\"{x:188,y:548,t:1527613827680};\\\", \\\"{x:167,y:538,t:1527613827698};\\\", \\\"{x:153,y:529,t:1527613827713};\\\", \\\"{x:141,y:524,t:1527613827732};\\\", \\\"{x:133,y:523,t:1527613827747};\\\", \\\"{x:129,y:522,t:1527613827763};\\\", \\\"{x:128,y:522,t:1527613827780};\\\", \\\"{x:127,y:523,t:1527613828054};\\\", \\\"{x:128,y:526,t:1527613828066};\\\", \\\"{x:132,y:529,t:1527613828081};\\\", \\\"{x:135,y:532,t:1527613828097};\\\", \\\"{x:140,y:537,t:1527613828114};\\\", \\\"{x:143,y:539,t:1527613828130};\\\", \\\"{x:143,y:540,t:1527613828172};\\\", \\\"{x:144,y:541,t:1527613828181};\\\", \\\"{x:145,y:542,t:1527613828197};\\\", \\\"{x:146,y:543,t:1527613828214};\\\", \\\"{x:147,y:543,t:1527613828334};\\\", \\\"{x:148,y:543,t:1527613828357};\\\", \\\"{x:149,y:543,t:1527613828383};\\\", \\\"{x:150,y:543,t:1527613828397};\\\", \\\"{x:151,y:543,t:1527613828493};\\\", \\\"{x:152,y:543,t:1527613828910};\\\", \\\"{x:154,y:543,t:1527613828918};\\\", \\\"{x:157,y:543,t:1527613828931};\\\", \\\"{x:164,y:542,t:1527613828947};\\\", \\\"{x:181,y:542,t:1527613828965};\\\", \\\"{x:217,y:556,t:1527613828982};\\\", \\\"{x:252,y:569,t:1527613828999};\\\", \\\"{x:315,y:593,t:1527613829016};\\\", \\\"{x:368,y:616,t:1527613829032};\\\", \\\"{x:403,y:632,t:1527613829049};\\\", \\\"{x:430,y:650,t:1527613829065};\\\", \\\"{x:445,y:657,t:1527613829081};\\\", \\\"{x:457,y:666,t:1527613829098};\\\", \\\"{x:462,y:669,t:1527613829115};\\\", \\\"{x:467,y:673,t:1527613829132};\\\", \\\"{x:471,y:676,t:1527613829148};\\\", \\\"{x:473,y:678,t:1527613829165};\\\", \\\"{x:475,y:681,t:1527613829181};\\\", \\\"{x:476,y:682,t:1527613829199};\\\", \\\"{x:478,y:683,t:1527613829215};\\\", \\\"{x:479,y:685,t:1527613829232};\\\", \\\"{x:480,y:687,t:1527613829248};\\\", \\\"{x:481,y:688,t:1527613829265};\\\", \\\"{x:486,y:696,t:1527613829281};\\\", \\\"{x:489,y:705,t:1527613829298};\\\", \\\"{x:492,y:711,t:1527613829315};\\\", \\\"{x:495,y:714,t:1527613829332};\\\", \\\"{x:495,y:716,t:1527613829350};\\\", \\\"{x:495,y:717,t:1527613829478};\\\", \\\"{x:497,y:718,t:1527613829486};\\\", \\\"{x:497,y:719,t:1527613829498};\\\", \\\"{x:497,y:721,t:1527613829517};\\\", \\\"{x:498,y:723,t:1527613829532};\\\", \\\"{x:499,y:729,t:1527613829548};\\\", \\\"{x:501,y:733,t:1527613829565};\\\", \\\"{x:504,y:737,t:1527613829581};\\\", \\\"{x:504,y:739,t:1527613829606};\\\" ] }, { \\\"rt\\\": 26968, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 17, \\\"time_elapsed\\\": 531848, \\\"internal_node_id\\\": \\\"0.0-6.0-7.0\\\", \\\"subject\\\": \\\"AZKMW\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"oscar\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 13, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-X \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:505,y:739,t:1527613833797};\\\", \\\"{x:505,y:738,t:1527613834285};\\\", \\\"{x:506,y:737,t:1527613834293};\\\", \\\"{x:509,y:735,t:1527613834310};\\\", \\\"{x:512,y:733,t:1527613834326};\\\", \\\"{x:517,y:730,t:1527613834343};\\\", \\\"{x:521,y:729,t:1527613834361};\\\", \\\"{x:523,y:728,t:1527613834378};\\\", \\\"{x:526,y:726,t:1527613834394};\\\", \\\"{x:535,y:724,t:1527613834410};\\\", \\\"{x:554,y:721,t:1527613834427};\\\", \\\"{x:571,y:719,t:1527613834444};\\\", \\\"{x:589,y:716,t:1527613834460};\\\", \\\"{x:633,y:716,t:1527613834476};\\\", \\\"{x:650,y:716,t:1527613834485};\\\", \\\"{x:690,y:718,t:1527613834502};\\\", \\\"{x:746,y:725,t:1527613834519};\\\", \\\"{x:794,y:732,t:1527613834535};\\\", \\\"{x:861,y:744,t:1527613834552};\\\", \\\"{x:922,y:759,t:1527613834569};\\\", \\\"{x:933,y:764,t:1527613834585};\\\", \\\"{x:934,y:765,t:1527613834957};\\\", \\\"{x:937,y:767,t:1527613834970};\\\", \\\"{x:949,y:768,t:1527613834986};\\\", \\\"{x:969,y:768,t:1527613835003};\\\", \\\"{x:976,y:768,t:1527613835020};\\\", \\\"{x:979,y:765,t:1527613835037};\\\", \\\"{x:994,y:763,t:1527613835053};\\\", \\\"{x:1024,y:761,t:1527613835069};\\\", \\\"{x:1043,y:757,t:1527613835087};\\\", \\\"{x:1066,y:757,t:1527613835103};\\\", \\\"{x:1103,y:758,t:1527613835119};\\\", \\\"{x:1131,y:763,t:1527613835137};\\\", \\\"{x:1170,y:767,t:1527613835154};\\\", \\\"{x:1206,y:772,t:1527613835169};\\\", \\\"{x:1238,y:776,t:1527613835187};\\\", \\\"{x:1295,y:776,t:1527613835204};\\\", \\\"{x:1362,y:776,t:1527613835220};\\\", \\\"{x:1422,y:782,t:1527613835237};\\\", \\\"{x:1495,y:790,t:1527613835254};\\\", \\\"{x:1539,y:793,t:1527613835270};\\\", \\\"{x:1568,y:793,t:1527613835287};\\\", \\\"{x:1590,y:794,t:1527613835304};\\\", \\\"{x:1599,y:794,t:1527613835320};\\\", \\\"{x:1613,y:794,t:1527613835337};\\\", \\\"{x:1622,y:795,t:1527613835353};\\\", \\\"{x:1626,y:795,t:1527613835370};\\\", \\\"{x:1627,y:795,t:1527613835387};\\\", \\\"{x:1629,y:794,t:1527613835486};\\\", \\\"{x:1630,y:793,t:1527613835504};\\\", \\\"{x:1633,y:791,t:1527613835520};\\\", \\\"{x:1636,y:787,t:1527613835537};\\\", \\\"{x:1639,y:784,t:1527613835554};\\\", \\\"{x:1641,y:781,t:1527613835570};\\\", \\\"{x:1643,y:776,t:1527613835587};\\\", \\\"{x:1644,y:773,t:1527613835604};\\\", \\\"{x:1645,y:766,t:1527613835621};\\\", \\\"{x:1646,y:763,t:1527613835637};\\\", \\\"{x:1647,y:759,t:1527613835654};\\\", \\\"{x:1647,y:754,t:1527613835671};\\\", \\\"{x:1649,y:746,t:1527613835687};\\\", \\\"{x:1650,y:742,t:1527613835704};\\\", \\\"{x:1652,y:728,t:1527613835721};\\\", \\\"{x:1654,y:718,t:1527613835737};\\\", \\\"{x:1654,y:715,t:1527613835754};\\\", \\\"{x:1655,y:710,t:1527613835771};\\\", \\\"{x:1655,y:708,t:1527613835787};\\\", \\\"{x:1655,y:707,t:1527613835804};\\\", \\\"{x:1655,y:704,t:1527613835821};\\\", \\\"{x:1655,y:701,t:1527613835837};\\\", \\\"{x:1655,y:699,t:1527613835854};\\\", \\\"{x:1655,y:698,t:1527613835871};\\\", \\\"{x:1655,y:696,t:1527613835893};\\\", \\\"{x:1655,y:694,t:1527613835904};\\\", \\\"{x:1655,y:692,t:1527613835921};\\\", \\\"{x:1654,y:691,t:1527613835937};\\\", \\\"{x:1642,y:690,t:1527613835954};\\\", \\\"{x:1631,y:690,t:1527613835971};\\\", \\\"{x:1626,y:690,t:1527613835987};\\\", \\\"{x:1625,y:690,t:1527613836004};\\\", \\\"{x:1624,y:690,t:1527613836054};\\\", \\\"{x:1622,y:690,t:1527613836294};\\\", \\\"{x:1621,y:691,t:1527613836304};\\\", \\\"{x:1621,y:694,t:1527613836321};\\\", \\\"{x:1621,y:699,t:1527613836338};\\\", \\\"{x:1620,y:701,t:1527613836354};\\\", \\\"{x:1620,y:704,t:1527613836370};\\\", \\\"{x:1619,y:707,t:1527613836389};\\\", \\\"{x:1619,y:708,t:1527613836477};\\\", \\\"{x:1619,y:709,t:1527613836493};\\\", \\\"{x:1619,y:710,t:1527613836505};\\\", \\\"{x:1619,y:711,t:1527613836525};\\\", \\\"{x:1621,y:715,t:1527613836878};\\\", \\\"{x:1629,y:722,t:1527613836889};\\\", \\\"{x:1640,y:732,t:1527613836904};\\\", \\\"{x:1647,y:736,t:1527613836922};\\\", \\\"{x:1661,y:749,t:1527613836937};\\\", \\\"{x:1678,y:761,t:1527613836954};\\\", \\\"{x:1688,y:766,t:1527613836972};\\\", \\\"{x:1693,y:769,t:1527613836987};\\\", \\\"{x:1696,y:770,t:1527613837005};\\\", \\\"{x:1698,y:774,t:1527613837142};\\\", \\\"{x:1698,y:777,t:1527613837158};\\\", \\\"{x:1700,y:779,t:1527613837172};\\\", \\\"{x:1700,y:782,t:1527613837188};\\\", \\\"{x:1700,y:789,t:1527613837205};\\\", \\\"{x:1701,y:799,t:1527613837221};\\\", \\\"{x:1701,y:805,t:1527613837237};\\\", \\\"{x:1703,y:810,t:1527613837254};\\\", \\\"{x:1703,y:812,t:1527613837271};\\\", \\\"{x:1704,y:813,t:1527613837287};\\\", \\\"{x:1704,y:815,t:1527613837304};\\\", \\\"{x:1705,y:815,t:1527613837321};\\\", \\\"{x:1706,y:816,t:1527613837338};\\\", \\\"{x:1706,y:817,t:1527613837355};\\\", \\\"{x:1706,y:818,t:1527613837371};\\\", \\\"{x:1706,y:819,t:1527613837388};\\\", \\\"{x:1706,y:820,t:1527613837404};\\\", \\\"{x:1704,y:824,t:1527613837421};\\\", \\\"{x:1704,y:826,t:1527613837439};\\\", \\\"{x:1704,y:828,t:1527613837454};\\\", \\\"{x:1704,y:830,t:1527613837472};\\\", \\\"{x:1704,y:833,t:1527613837490};\\\", \\\"{x:1704,y:835,t:1527613837505};\\\", \\\"{x:1704,y:838,t:1527613837521};\\\", \\\"{x:1704,y:839,t:1527613837538};\\\", \\\"{x:1704,y:842,t:1527613837554};\\\", \\\"{x:1705,y:844,t:1527613837572};\\\", \\\"{x:1709,y:846,t:1527613837589};\\\", \\\"{x:1712,y:847,t:1527613837605};\\\", \\\"{x:1725,y:851,t:1527613837621};\\\", \\\"{x:1730,y:854,t:1527613837639};\\\", \\\"{x:1736,y:856,t:1527613837654};\\\", \\\"{x:1742,y:857,t:1527613837672};\\\", \\\"{x:1749,y:860,t:1527613837690};\\\", \\\"{x:1753,y:860,t:1527613837705};\\\", \\\"{x:1755,y:860,t:1527613837721};\\\", \\\"{x:1759,y:860,t:1527613837738};\\\", \\\"{x:1760,y:860,t:1527613837755};\\\", \\\"{x:1761,y:859,t:1527613837782};\\\", \\\"{x:1762,y:859,t:1527613837790};\\\", \\\"{x:1765,y:857,t:1527613837805};\\\", \\\"{x:1768,y:856,t:1527613837822};\\\", \\\"{x:1772,y:854,t:1527613837839};\\\", \\\"{x:1777,y:850,t:1527613837856};\\\", \\\"{x:1779,y:850,t:1527613837871};\\\", \\\"{x:1784,y:847,t:1527613837889};\\\", \\\"{x:1785,y:847,t:1527613837906};\\\", \\\"{x:1786,y:846,t:1527613837921};\\\", \\\"{x:1784,y:846,t:1527613837997};\\\", \\\"{x:1782,y:846,t:1527613838004};\\\", \\\"{x:1776,y:846,t:1527613838021};\\\", \\\"{x:1754,y:846,t:1527613838039};\\\", \\\"{x:1718,y:845,t:1527613838055};\\\", \\\"{x:1618,y:832,t:1527613838072};\\\", \\\"{x:1483,y:815,t:1527613838089};\\\", \\\"{x:1346,y:789,t:1527613838106};\\\", \\\"{x:1190,y:756,t:1527613838121};\\\", \\\"{x:1030,y:719,t:1527613838139};\\\", \\\"{x:902,y:676,t:1527613838156};\\\", \\\"{x:773,y:625,t:1527613838172};\\\", \\\"{x:677,y:585,t:1527613838189};\\\", \\\"{x:614,y:555,t:1527613838206};\\\", \\\"{x:598,y:547,t:1527613838222};\\\", \\\"{x:584,y:540,t:1527613838238};\\\", \\\"{x:567,y:538,t:1527613838255};\\\", \\\"{x:549,y:534,t:1527613838272};\\\", \\\"{x:531,y:532,t:1527613838289};\\\", \\\"{x:524,y:532,t:1527613838305};\\\", \\\"{x:523,y:530,t:1527613838323};\\\", \\\"{x:522,y:530,t:1527613838542};\\\", \\\"{x:514,y:535,t:1527613838556};\\\", \\\"{x:495,y:545,t:1527613838574};\\\", \\\"{x:463,y:556,t:1527613838588};\\\", \\\"{x:442,y:558,t:1527613838606};\\\", \\\"{x:421,y:560,t:1527613838622};\\\", \\\"{x:415,y:562,t:1527613838639};\\\", \\\"{x:409,y:563,t:1527613838656};\\\", \\\"{x:388,y:563,t:1527613838672};\\\", \\\"{x:382,y:563,t:1527613838689};\\\", \\\"{x:374,y:563,t:1527613838705};\\\", \\\"{x:367,y:563,t:1527613838723};\\\", \\\"{x:363,y:564,t:1527613838739};\\\", \\\"{x:359,y:566,t:1527613838755};\\\", \\\"{x:356,y:568,t:1527613838773};\\\", \\\"{x:353,y:572,t:1527613838789};\\\", \\\"{x:349,y:574,t:1527613838806};\\\", \\\"{x:341,y:581,t:1527613838822};\\\", \\\"{x:332,y:587,t:1527613838839};\\\", \\\"{x:321,y:593,t:1527613838856};\\\", \\\"{x:306,y:598,t:1527613838874};\\\", \\\"{x:293,y:600,t:1527613838890};\\\", \\\"{x:289,y:600,t:1527613838905};\\\", \\\"{x:284,y:599,t:1527613838923};\\\", \\\"{x:280,y:594,t:1527613838939};\\\", \\\"{x:276,y:588,t:1527613838955};\\\", \\\"{x:272,y:580,t:1527613838973};\\\", \\\"{x:272,y:578,t:1527613838989};\\\", \\\"{x:269,y:575,t:1527613839006};\\\", \\\"{x:264,y:571,t:1527613839023};\\\", \\\"{x:261,y:569,t:1527613839039};\\\", \\\"{x:256,y:567,t:1527613839056};\\\", \\\"{x:252,y:566,t:1527613839072};\\\", \\\"{x:247,y:565,t:1527613839089};\\\", \\\"{x:245,y:564,t:1527613839106};\\\", \\\"{x:240,y:564,t:1527613839123};\\\", \\\"{x:239,y:564,t:1527613839139};\\\", \\\"{x:238,y:564,t:1527613839510};\\\", \\\"{x:236,y:564,t:1527613839523};\\\", \\\"{x:228,y:564,t:1527613839541};\\\", \\\"{x:222,y:566,t:1527613839557};\\\", \\\"{x:212,y:580,t:1527613839573};\\\", \\\"{x:203,y:590,t:1527613839591};\\\", \\\"{x:196,y:603,t:1527613839608};\\\", \\\"{x:188,y:613,t:1527613839624};\\\", \\\"{x:182,y:622,t:1527613839640};\\\", \\\"{x:177,y:629,t:1527613839657};\\\", \\\"{x:176,y:631,t:1527613839673};\\\", \\\"{x:175,y:631,t:1527613839689};\\\", \\\"{x:175,y:632,t:1527613839709};\\\", \\\"{x:174,y:636,t:1527613839723};\\\", \\\"{x:172,y:638,t:1527613839740};\\\", \\\"{x:172,y:641,t:1527613839757};\\\", \\\"{x:172,y:642,t:1527613839773};\\\", \\\"{x:171,y:643,t:1527613839790};\\\", \\\"{x:171,y:644,t:1527613839806};\\\", \\\"{x:171,y:645,t:1527613839823};\\\", \\\"{x:171,y:646,t:1527613839981};\\\", \\\"{x:171,y:647,t:1527613844013};\\\", \\\"{x:172,y:648,t:1527613844027};\\\", \\\"{x:179,y:646,t:1527613844044};\\\", \\\"{x:194,y:638,t:1527613844062};\\\", \\\"{x:201,y:636,t:1527613844076};\\\", \\\"{x:210,y:631,t:1527613844094};\\\", \\\"{x:215,y:630,t:1527613844110};\\\", \\\"{x:221,y:626,t:1527613844126};\\\", \\\"{x:239,y:614,t:1527613844144};\\\", \\\"{x:258,y:602,t:1527613844161};\\\", \\\"{x:284,y:589,t:1527613844178};\\\", \\\"{x:306,y:574,t:1527613844193};\\\", \\\"{x:326,y:561,t:1527613844211};\\\", \\\"{x:354,y:544,t:1527613844227};\\\", \\\"{x:405,y:508,t:1527613844244};\\\", \\\"{x:453,y:476,t:1527613844261};\\\", \\\"{x:487,y:459,t:1527613844276};\\\", \\\"{x:507,y:448,t:1527613844293};\\\", \\\"{x:526,y:437,t:1527613844310};\\\", \\\"{x:535,y:432,t:1527613844326};\\\", \\\"{x:541,y:429,t:1527613844343};\\\", \\\"{x:544,y:425,t:1527613844361};\\\", \\\"{x:548,y:422,t:1527613844376};\\\", \\\"{x:551,y:420,t:1527613844394};\\\", \\\"{x:553,y:418,t:1527613844410};\\\", \\\"{x:554,y:417,t:1527613844429};\\\", \\\"{x:555,y:417,t:1527613844502};\\\", \\\"{x:556,y:417,t:1527613844511};\\\", \\\"{x:561,y:422,t:1527613844528};\\\", \\\"{x:563,y:434,t:1527613844544};\\\", \\\"{x:566,y:449,t:1527613844561};\\\", \\\"{x:566,y:463,t:1527613844578};\\\", \\\"{x:568,y:473,t:1527613844594};\\\", \\\"{x:569,y:479,t:1527613844610};\\\", \\\"{x:570,y:480,t:1527613844628};\\\", \\\"{x:570,y:481,t:1527613844678};\\\", \\\"{x:570,y:480,t:1527613844997};\\\", \\\"{x:570,y:477,t:1527613845011};\\\", \\\"{x:569,y:470,t:1527613845028};\\\", \\\"{x:569,y:460,t:1527613845045};\\\", \\\"{x:569,y:455,t:1527613845061};\\\", \\\"{x:569,y:451,t:1527613845078};\\\", \\\"{x:569,y:449,t:1527613845950};\\\", \\\"{x:571,y:448,t:1527613845962};\\\", \\\"{x:628,y:461,t:1527613845978};\\\", \\\"{x:734,y:481,t:1527613845996};\\\", \\\"{x:839,y:512,t:1527613846014};\\\", \\\"{x:977,y:544,t:1527613846029};\\\", \\\"{x:977,y:545,t:1527613846046};\\\", \\\"{x:979,y:545,t:1527613846558};\\\", \\\"{x:990,y:546,t:1527613846566};\\\", \\\"{x:1003,y:546,t:1527613846581};\\\", \\\"{x:1018,y:550,t:1527613846598};\\\", \\\"{x:1047,y:569,t:1527613846614};\\\", \\\"{x:1063,y:583,t:1527613846630};\\\", \\\"{x:1083,y:590,t:1527613846647};\\\", \\\"{x:1090,y:593,t:1527613846664};\\\", \\\"{x:1095,y:595,t:1527613846680};\\\", \\\"{x:1108,y:602,t:1527613846697};\\\", \\\"{x:1116,y:607,t:1527613846715};\\\", \\\"{x:1120,y:607,t:1527613846731};\\\", \\\"{x:1125,y:610,t:1527613846747};\\\", \\\"{x:1132,y:614,t:1527613846764};\\\", \\\"{x:1145,y:622,t:1527613846781};\\\", \\\"{x:1164,y:630,t:1527613846797};\\\", \\\"{x:1188,y:642,t:1527613846815};\\\", \\\"{x:1233,y:660,t:1527613846831};\\\", \\\"{x:1293,y:684,t:1527613846849};\\\", \\\"{x:1382,y:709,t:1527613846864};\\\", \\\"{x:1491,y:731,t:1527613846881};\\\", \\\"{x:1598,y:741,t:1527613846899};\\\", \\\"{x:1726,y:762,t:1527613846915};\\\", \\\"{x:1831,y:774,t:1527613846932};\\\", \\\"{x:1904,y:776,t:1527613846948};\\\", \\\"{x:1919,y:779,t:1527613846964};\\\", \\\"{x:1919,y:777,t:1527613846988};\\\", \\\"{x:1919,y:776,t:1527613847004};\\\", \\\"{x:1919,y:775,t:1527613847309};\\\", \\\"{x:1903,y:769,t:1527613847325};\\\", \\\"{x:1862,y:762,t:1527613847334};\\\", \\\"{x:1844,y:755,t:1527613847345};\\\", \\\"{x:1791,y:739,t:1527613847363};\\\", \\\"{x:1713,y:726,t:1527613847380};\\\", \\\"{x:1675,y:715,t:1527613847396};\\\", \\\"{x:1641,y:703,t:1527613847413};\\\", \\\"{x:1622,y:697,t:1527613847430};\\\", \\\"{x:1607,y:691,t:1527613847446};\\\", \\\"{x:1593,y:684,t:1527613847464};\\\", \\\"{x:1580,y:681,t:1527613847480};\\\", \\\"{x:1572,y:681,t:1527613847498};\\\", \\\"{x:1544,y:681,t:1527613847513};\\\", \\\"{x:1519,y:678,t:1527613847531};\\\", \\\"{x:1458,y:678,t:1527613847547};\\\", \\\"{x:1397,y:678,t:1527613847563};\\\", \\\"{x:1377,y:678,t:1527613847580};\\\", \\\"{x:1363,y:678,t:1527613847597};\\\", \\\"{x:1359,y:678,t:1527613847614};\\\", \\\"{x:1358,y:678,t:1527613847630};\\\", \\\"{x:1358,y:680,t:1527613847734};\\\", \\\"{x:1359,y:682,t:1527613847747};\\\", \\\"{x:1361,y:684,t:1527613847763};\\\", \\\"{x:1362,y:686,t:1527613847781};\\\", \\\"{x:1363,y:688,t:1527613847797};\\\", \\\"{x:1365,y:688,t:1527613847814};\\\", \\\"{x:1366,y:689,t:1527613847830};\\\", \\\"{x:1368,y:690,t:1527613847848};\\\", \\\"{x:1369,y:691,t:1527613847864};\\\", \\\"{x:1370,y:691,t:1527613847892};\\\", \\\"{x:1370,y:693,t:1527613847973};\\\", \\\"{x:1370,y:695,t:1527613847981};\\\", \\\"{x:1366,y:699,t:1527613847997};\\\", \\\"{x:1360,y:704,t:1527613848014};\\\", \\\"{x:1355,y:707,t:1527613848029};\\\", \\\"{x:1354,y:707,t:1527613848047};\\\", \\\"{x:1355,y:707,t:1527613848365};\\\", \\\"{x:1358,y:707,t:1527613848380};\\\", \\\"{x:1372,y:707,t:1527613848398};\\\", \\\"{x:1377,y:707,t:1527613848415};\\\", \\\"{x:1381,y:707,t:1527613848431};\\\", \\\"{x:1387,y:707,t:1527613848447};\\\", \\\"{x:1392,y:707,t:1527613848464};\\\", \\\"{x:1394,y:707,t:1527613848481};\\\", \\\"{x:1395,y:707,t:1527613848509};\\\", \\\"{x:1396,y:707,t:1527613848549};\\\", \\\"{x:1397,y:706,t:1527613848564};\\\", \\\"{x:1402,y:705,t:1527613848581};\\\", \\\"{x:1405,y:705,t:1527613848597};\\\", \\\"{x:1409,y:705,t:1527613848615};\\\", \\\"{x:1412,y:704,t:1527613848631};\\\", \\\"{x:1415,y:703,t:1527613848648};\\\", \\\"{x:1418,y:702,t:1527613848664};\\\", \\\"{x:1419,y:702,t:1527613848685};\\\", \\\"{x:1422,y:700,t:1527613848837};\\\", \\\"{x:1424,y:698,t:1527613848868};\\\", \\\"{x:1424,y:697,t:1527613848884};\\\", \\\"{x:1426,y:696,t:1527613848897};\\\", \\\"{x:1427,y:695,t:1527613848913};\\\", \\\"{x:1431,y:692,t:1527613848930};\\\", \\\"{x:1432,y:691,t:1527613848948};\\\", \\\"{x:1433,y:690,t:1527613848964};\\\", \\\"{x:1434,y:690,t:1527613848997};\\\", \\\"{x:1434,y:689,t:1527613849004};\\\", \\\"{x:1435,y:689,t:1527613849013};\\\", \\\"{x:1435,y:688,t:1527613849031};\\\", \\\"{x:1436,y:688,t:1527613849048};\\\", \\\"{x:1439,y:688,t:1527613849063};\\\", \\\"{x:1440,y:688,t:1527613849081};\\\", \\\"{x:1445,y:688,t:1527613849098};\\\", \\\"{x:1449,y:688,t:1527613849114};\\\", \\\"{x:1457,y:689,t:1527613849131};\\\", \\\"{x:1460,y:691,t:1527613849148};\\\", \\\"{x:1468,y:694,t:1527613849164};\\\", \\\"{x:1477,y:697,t:1527613849181};\\\", \\\"{x:1482,y:700,t:1527613849199};\\\", \\\"{x:1484,y:701,t:1527613849215};\\\", \\\"{x:1485,y:702,t:1527613849262};\\\", \\\"{x:1486,y:702,t:1527613849445};\\\", \\\"{x:1487,y:702,t:1527613849461};\\\", \\\"{x:1489,y:702,t:1527613849470};\\\", \\\"{x:1491,y:701,t:1527613849485};\\\", \\\"{x:1493,y:699,t:1527613849509};\\\", \\\"{x:1494,y:698,t:1527613849525};\\\", \\\"{x:1495,y:697,t:1527613849541};\\\", \\\"{x:1496,y:696,t:1527613849558};\\\", \\\"{x:1498,y:694,t:1527613849582};\\\", \\\"{x:1501,y:692,t:1527613849598};\\\", \\\"{x:1505,y:691,t:1527613849615};\\\", \\\"{x:1510,y:691,t:1527613849631};\\\", \\\"{x:1517,y:690,t:1527613849648};\\\", \\\"{x:1523,y:689,t:1527613849665};\\\", \\\"{x:1529,y:689,t:1527613849681};\\\", \\\"{x:1533,y:687,t:1527613849699};\\\", \\\"{x:1537,y:687,t:1527613849715};\\\", \\\"{x:1540,y:687,t:1527613849732};\\\", \\\"{x:1543,y:687,t:1527613849749};\\\", \\\"{x:1544,y:687,t:1527613849766};\\\", \\\"{x:1545,y:687,t:1527613849798};\\\", \\\"{x:1547,y:688,t:1527613849815};\\\", \\\"{x:1550,y:693,t:1527613849833};\\\", \\\"{x:1550,y:697,t:1527613849849};\\\", \\\"{x:1552,y:699,t:1527613849866};\\\", \\\"{x:1554,y:701,t:1527613849883};\\\", \\\"{x:1554,y:702,t:1527613849898};\\\", \\\"{x:1555,y:704,t:1527613849916};\\\", \\\"{x:1556,y:705,t:1527613849998};\\\", \\\"{x:1562,y:704,t:1527613850015};\\\", \\\"{x:1565,y:703,t:1527613850033};\\\", \\\"{x:1568,y:699,t:1527613850048};\\\", \\\"{x:1578,y:696,t:1527613850065};\\\", \\\"{x:1587,y:695,t:1527613850082};\\\", \\\"{x:1594,y:695,t:1527613850099};\\\", \\\"{x:1598,y:695,t:1527613850115};\\\", \\\"{x:1601,y:695,t:1527613850132};\\\", \\\"{x:1602,y:695,t:1527613850148};\\\", \\\"{x:1605,y:699,t:1527613850164};\\\", \\\"{x:1606,y:703,t:1527613850182};\\\", \\\"{x:1609,y:709,t:1527613850198};\\\", \\\"{x:1609,y:713,t:1527613850214};\\\", \\\"{x:1610,y:715,t:1527613850232};\\\", \\\"{x:1611,y:716,t:1527613850247};\\\", \\\"{x:1611,y:717,t:1527613853725};\\\", \\\"{x:1611,y:720,t:1527613853749};\\\", \\\"{x:1611,y:722,t:1527613853757};\\\", \\\"{x:1611,y:724,t:1527613853773};\\\", \\\"{x:1611,y:727,t:1527613853785};\\\", \\\"{x:1609,y:733,t:1527613853801};\\\", \\\"{x:1608,y:736,t:1527613853818};\\\", \\\"{x:1607,y:737,t:1527613853834};\\\", \\\"{x:1604,y:743,t:1527613853851};\\\", \\\"{x:1602,y:745,t:1527613853868};\\\", \\\"{x:1600,y:749,t:1527613853884};\\\", \\\"{x:1596,y:754,t:1527613853900};\\\", \\\"{x:1592,y:759,t:1527613853918};\\\", \\\"{x:1592,y:760,t:1527613853941};\\\", \\\"{x:1592,y:761,t:1527613853981};\\\", \\\"{x:1592,y:762,t:1527613853989};\\\", \\\"{x:1592,y:763,t:1527613854001};\\\", \\\"{x:1589,y:763,t:1527613854046};\\\", \\\"{x:1588,y:763,t:1527613854061};\\\", \\\"{x:1584,y:763,t:1527613854077};\\\", \\\"{x:1582,y:763,t:1527613854085};\\\", \\\"{x:1576,y:763,t:1527613854101};\\\", \\\"{x:1573,y:764,t:1527613854119};\\\", \\\"{x:1567,y:767,t:1527613854135};\\\", \\\"{x:1561,y:768,t:1527613854151};\\\", \\\"{x:1550,y:770,t:1527613854168};\\\", \\\"{x:1540,y:771,t:1527613854186};\\\", \\\"{x:1529,y:773,t:1527613854201};\\\", \\\"{x:1507,y:775,t:1527613854219};\\\", \\\"{x:1490,y:775,t:1527613854235};\\\", \\\"{x:1467,y:775,t:1527613854251};\\\", \\\"{x:1431,y:774,t:1527613854268};\\\", \\\"{x:1371,y:760,t:1527613854285};\\\", \\\"{x:1330,y:759,t:1527613854301};\\\", \\\"{x:1294,y:755,t:1527613854318};\\\", \\\"{x:1257,y:749,t:1527613854336};\\\", \\\"{x:1203,y:739,t:1527613854351};\\\", \\\"{x:1130,y:728,t:1527613854369};\\\", \\\"{x:1041,y:713,t:1527613854385};\\\", \\\"{x:969,y:706,t:1527613854402};\\\", \\\"{x:947,y:708,t:1527613854418};\\\", \\\"{x:945,y:707,t:1527613855037};\\\", \\\"{x:938,y:698,t:1527613855052};\\\", \\\"{x:911,y:668,t:1527613855069};\\\", \\\"{x:900,y:660,t:1527613855085};\\\", \\\"{x:892,y:652,t:1527613855103};\\\", \\\"{x:887,y:640,t:1527613855119};\\\", \\\"{x:881,y:619,t:1527613855137};\\\", \\\"{x:863,y:592,t:1527613855153};\\\", \\\"{x:840,y:551,t:1527613855169};\\\", \\\"{x:813,y:508,t:1527613855186};\\\", \\\"{x:795,y:483,t:1527613855203};\\\", \\\"{x:788,y:474,t:1527613855219};\\\", \\\"{x:789,y:477,t:1527613855524};\\\", \\\"{x:795,y:485,t:1527613855536};\\\", \\\"{x:802,y:496,t:1527613855553};\\\", \\\"{x:807,y:505,t:1527613855569};\\\", \\\"{x:811,y:510,t:1527613855586};\\\", \\\"{x:813,y:514,t:1527613855602};\\\", \\\"{x:815,y:514,t:1527613855677};\\\", \\\"{x:818,y:513,t:1527613855687};\\\", \\\"{x:826,y:509,t:1527613855703};\\\", \\\"{x:831,y:506,t:1527613855718};\\\", \\\"{x:833,y:505,t:1527613855736};\\\", \\\"{x:837,y:504,t:1527613855753};\\\", \\\"{x:842,y:501,t:1527613855770};\\\", \\\"{x:846,y:499,t:1527613855786};\\\", \\\"{x:847,y:498,t:1527613855804};\\\", \\\"{x:842,y:500,t:1527613856212};\\\", \\\"{x:829,y:513,t:1527613856220};\\\", \\\"{x:801,y:532,t:1527613856237};\\\", \\\"{x:775,y:551,t:1527613856253};\\\", \\\"{x:759,y:566,t:1527613856271};\\\", \\\"{x:756,y:586,t:1527613856287};\\\", \\\"{x:756,y:589,t:1527613856304};\\\", \\\"{x:754,y:591,t:1527613856413};\\\", \\\"{x:754,y:592,t:1527613856421};\\\", \\\"{x:754,y:589,t:1527613856493};\\\", \\\"{x:754,y:584,t:1527613856504};\\\", \\\"{x:754,y:576,t:1527613856520};\\\", \\\"{x:753,y:567,t:1527613856538};\\\", \\\"{x:749,y:555,t:1527613856556};\\\", \\\"{x:742,y:543,t:1527613856570};\\\", \\\"{x:730,y:534,t:1527613856587};\\\", \\\"{x:714,y:524,t:1527613856605};\\\", \\\"{x:677,y:516,t:1527613856621};\\\", \\\"{x:629,y:517,t:1527613856637};\\\", \\\"{x:590,y:520,t:1527613856654};\\\", \\\"{x:579,y:524,t:1527613856670};\\\", \\\"{x:575,y:527,t:1527613856687};\\\", \\\"{x:575,y:528,t:1527613856708};\\\", \\\"{x:574,y:529,t:1527613856721};\\\", \\\"{x:572,y:533,t:1527613856737};\\\", \\\"{x:570,y:538,t:1527613856754};\\\", \\\"{x:570,y:542,t:1527613856770};\\\", \\\"{x:570,y:554,t:1527613856787};\\\", \\\"{x:570,y:565,t:1527613856805};\\\", \\\"{x:570,y:587,t:1527613856821};\\\", \\\"{x:574,y:598,t:1527613856838};\\\", \\\"{x:579,y:605,t:1527613856856};\\\", \\\"{x:582,y:608,t:1527613856871};\\\", \\\"{x:585,y:608,t:1527613856887};\\\", \\\"{x:587,y:608,t:1527613856904};\\\", \\\"{x:588,y:608,t:1527613856921};\\\", \\\"{x:591,y:607,t:1527613856937};\\\", \\\"{x:597,y:602,t:1527613856954};\\\", \\\"{x:602,y:598,t:1527613856972};\\\", \\\"{x:605,y:595,t:1527613856987};\\\", \\\"{x:605,y:594,t:1527613857004};\\\", \\\"{x:605,y:589,t:1527613857021};\\\", \\\"{x:605,y:586,t:1527613857038};\\\", \\\"{x:605,y:584,t:1527613857054};\\\", \\\"{x:605,y:583,t:1527613857071};\\\", \\\"{x:604,y:581,t:1527613857087};\\\", \\\"{x:604,y:579,t:1527613857104};\\\", \\\"{x:603,y:577,t:1527613857121};\\\", \\\"{x:602,y:575,t:1527613857137};\\\", \\\"{x:598,y:575,t:1527613857365};\\\", \\\"{x:591,y:581,t:1527613857372};\\\", \\\"{x:578,y:602,t:1527613857389};\\\", \\\"{x:571,y:609,t:1527613857404};\\\", \\\"{x:560,y:636,t:1527613857422};\\\", \\\"{x:558,y:654,t:1527613857438};\\\", \\\"{x:557,y:675,t:1527613857454};\\\", \\\"{x:556,y:692,t:1527613857471};\\\", \\\"{x:556,y:711,t:1527613857488};\\\", \\\"{x:555,y:726,t:1527613857504};\\\", \\\"{x:555,y:732,t:1527613857521};\\\", \\\"{x:552,y:738,t:1527613857538};\\\", \\\"{x:551,y:746,t:1527613857555};\\\", \\\"{x:550,y:760,t:1527613857572};\\\", \\\"{x:549,y:768,t:1527613857588};\\\", \\\"{x:548,y:770,t:1527613857605};\\\", \\\"{x:548,y:772,t:1527613857621};\\\", \\\"{x:547,y:772,t:1527613857788};\\\", \\\"{x:546,y:767,t:1527613857804};\\\", \\\"{x:544,y:761,t:1527613857821};\\\", \\\"{x:541,y:754,t:1527613857838};\\\", \\\"{x:541,y:747,t:1527613857855};\\\", \\\"{x:539,y:743,t:1527613857871};\\\", \\\"{x:539,y:740,t:1527613857888};\\\", \\\"{x:539,y:738,t:1527613858044};\\\", \\\"{x:539,y:738,t:1527613858070};\\\", \\\"{x:539,y:736,t:1527613858100};\\\", \\\"{x:539,y:735,t:1527613858108};\\\", \\\"{x:539,y:734,t:1527613858122};\\\", \\\"{x:539,y:733,t:1527613858140};\\\", \\\"{x:540,y:731,t:1527613858156};\\\", \\\"{x:541,y:731,t:1527613858261};\\\", \\\"{x:543,y:729,t:1527613858272};\\\", \\\"{x:543,y:728,t:1527613858389};\\\", \\\"{x:544,y:728,t:1527613858406};\\\", \\\"{x:544,y:727,t:1527613858422};\\\", \\\"{x:544,y:726,t:1527613858477};\\\", \\\"{x:544,y:725,t:1527613858489};\\\", \\\"{x:544,y:722,t:1527613858509};\\\", \\\"{x:548,y:718,t:1527613858522};\\\", \\\"{x:550,y:711,t:1527613858539};\\\", \\\"{x:551,y:710,t:1527613858555};\\\", \\\"{x:551,y:709,t:1527613858572};\\\", \\\"{x:552,y:707,t:1527613858588};\\\", \\\"{x:554,y:705,t:1527613858621};\\\", \\\"{x:554,y:703,t:1527613858629};\\\", \\\"{x:554,y:701,t:1527613858641};\\\", \\\"{x:554,y:698,t:1527613858655};\\\", \\\"{x:554,y:697,t:1527613858677};\\\" ] }, { \\\"rt\\\": 24598, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 18, \\\"time_elapsed\\\": 557751, \\\"internal_node_id\\\": \\\"0.0-6.0-8.0\\\", \\\"subject\\\": \\\"AZKMW\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"oscar\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 14, \\\"clicks\\\": 1.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-05 PM-01 PM-03 PM-X -X -O \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:555,y:688,t:1527613861900};\\\", \\\"{x:559,y:678,t:1527613861908};\\\", \\\"{x:564,y:658,t:1527613861924};\\\", \\\"{x:572,y:633,t:1527613861941};\\\", \\\"{x:582,y:613,t:1527613861958};\\\", \\\"{x:594,y:590,t:1527613861974};\\\", \\\"{x:601,y:576,t:1527613861992};\\\", \\\"{x:613,y:551,t:1527613862008};\\\", \\\"{x:619,y:538,t:1527613862025};\\\", \\\"{x:629,y:519,t:1527613862041};\\\", \\\"{x:631,y:516,t:1527613862059};\\\", \\\"{x:632,y:514,t:1527613862075};\\\", \\\"{x:633,y:512,t:1527613862092};\\\", \\\"{x:634,y:511,t:1527613862108};\\\", \\\"{x:634,y:509,t:1527613862925};\\\", \\\"{x:635,y:509,t:1527613862932};\\\", \\\"{x:637,y:509,t:1527613862944};\\\", \\\"{x:638,y:506,t:1527613863533};\\\", \\\"{x:644,y:506,t:1527613863547};\\\", \\\"{x:665,y:510,t:1527613863561};\\\", \\\"{x:688,y:518,t:1527613863577};\\\", \\\"{x:752,y:537,t:1527613863593};\\\", \\\"{x:879,y:572,t:1527613863610};\\\", \\\"{x:1033,y:608,t:1527613863627};\\\", \\\"{x:1190,y:652,t:1527613863643};\\\", \\\"{x:1320,y:688,t:1527613863659};\\\", \\\"{x:1509,y:748,t:1527613863676};\\\", \\\"{x:1625,y:781,t:1527613863693};\\\", \\\"{x:1734,y:818,t:1527613863709};\\\", \\\"{x:1799,y:840,t:1527613863726};\\\", \\\"{x:1836,y:861,t:1527613863743};\\\", \\\"{x:1853,y:871,t:1527613863759};\\\", \\\"{x:1861,y:877,t:1527613863776};\\\", \\\"{x:1867,y:881,t:1527613863794};\\\", \\\"{x:1869,y:882,t:1527613863810};\\\", \\\"{x:1869,y:883,t:1527613863924};\\\", \\\"{x:1869,y:885,t:1527613863940};\\\", \\\"{x:1866,y:889,t:1527613863948};\\\", \\\"{x:1859,y:894,t:1527613863960};\\\", \\\"{x:1841,y:908,t:1527613863976};\\\", \\\"{x:1820,y:921,t:1527613863993};\\\", \\\"{x:1801,y:934,t:1527613864010};\\\", \\\"{x:1766,y:944,t:1527613864026};\\\", \\\"{x:1740,y:954,t:1527613864043};\\\", \\\"{x:1723,y:957,t:1527613864061};\\\", \\\"{x:1713,y:958,t:1527613864076};\\\", \\\"{x:1711,y:960,t:1527613864093};\\\", \\\"{x:1710,y:961,t:1527613864111};\\\", \\\"{x:1709,y:961,t:1527613864132};\\\", \\\"{x:1705,y:964,t:1527613864149};\\\", \\\"{x:1702,y:965,t:1527613864161};\\\", \\\"{x:1697,y:969,t:1527613864176};\\\", \\\"{x:1687,y:973,t:1527613864193};\\\", \\\"{x:1682,y:976,t:1527613864211};\\\", \\\"{x:1679,y:977,t:1527613864227};\\\", \\\"{x:1678,y:978,t:1527613864244};\\\", \\\"{x:1672,y:980,t:1527613864261};\\\", \\\"{x:1664,y:982,t:1527613864277};\\\", \\\"{x:1653,y:987,t:1527613864294};\\\", \\\"{x:1652,y:987,t:1527613864310};\\\", \\\"{x:1645,y:990,t:1527613864326};\\\", \\\"{x:1631,y:991,t:1527613864344};\\\", \\\"{x:1612,y:994,t:1527613864361};\\\", \\\"{x:1581,y:997,t:1527613864377};\\\", \\\"{x:1549,y:997,t:1527613864393};\\\", \\\"{x:1488,y:997,t:1527613864411};\\\", \\\"{x:1447,y:997,t:1527613864427};\\\", \\\"{x:1427,y:997,t:1527613864443};\\\", \\\"{x:1404,y:994,t:1527613864461};\\\", \\\"{x:1393,y:994,t:1527613864477};\\\", \\\"{x:1383,y:993,t:1527613864493};\\\", \\\"{x:1381,y:993,t:1527613864510};\\\", \\\"{x:1380,y:992,t:1527613864527};\\\", \\\"{x:1382,y:989,t:1527613864621};\\\", \\\"{x:1385,y:987,t:1527613864637};\\\", \\\"{x:1388,y:983,t:1527613864653};\\\", \\\"{x:1390,y:980,t:1527613864661};\\\", \\\"{x:1399,y:971,t:1527613864677};\\\", \\\"{x:1411,y:966,t:1527613864694};\\\", \\\"{x:1422,y:960,t:1527613864711};\\\", \\\"{x:1430,y:956,t:1527613864728};\\\", \\\"{x:1433,y:954,t:1527613864743};\\\", \\\"{x:1434,y:954,t:1527613864761};\\\", \\\"{x:1439,y:950,t:1527613864778};\\\", \\\"{x:1443,y:949,t:1527613864794};\\\", \\\"{x:1444,y:948,t:1527613864811};\\\", \\\"{x:1445,y:948,t:1527613864828};\\\", \\\"{x:1447,y:948,t:1527613864844};\\\", \\\"{x:1448,y:947,t:1527613864861};\\\", \\\"{x:1449,y:947,t:1527613864893};\\\", \\\"{x:1450,y:947,t:1527613864911};\\\", \\\"{x:1452,y:947,t:1527613864928};\\\", \\\"{x:1467,y:950,t:1527613864944};\\\", \\\"{x:1510,y:957,t:1527613864960};\\\", \\\"{x:1532,y:966,t:1527613864978};\\\", \\\"{x:1554,y:974,t:1527613864994};\\\", \\\"{x:1571,y:981,t:1527613865011};\\\", \\\"{x:1584,y:984,t:1527613865027};\\\", \\\"{x:1594,y:990,t:1527613865045};\\\", \\\"{x:1597,y:990,t:1527613865060};\\\", \\\"{x:1602,y:992,t:1527613865078};\\\", \\\"{x:1605,y:992,t:1527613865095};\\\", \\\"{x:1607,y:992,t:1527613865141};\\\", \\\"{x:1607,y:991,t:1527613865294};\\\", \\\"{x:1606,y:991,t:1527613865301};\\\", \\\"{x:1605,y:990,t:1527613865311};\\\", \\\"{x:1604,y:989,t:1527613865328};\\\", \\\"{x:1599,y:986,t:1527613865345};\\\", \\\"{x:1588,y:977,t:1527613865361};\\\", \\\"{x:1578,y:967,t:1527613865378};\\\", \\\"{x:1565,y:958,t:1527613865395};\\\", \\\"{x:1555,y:953,t:1527613865415};\\\", \\\"{x:1547,y:949,t:1527613865432};\\\", \\\"{x:1544,y:946,t:1527613865449};\\\", \\\"{x:1543,y:945,t:1527613865465};\\\", \\\"{x:1544,y:944,t:1527613865689};\\\", \\\"{x:1548,y:944,t:1527613865700};\\\", \\\"{x:1550,y:945,t:1527613865716};\\\", \\\"{x:1555,y:945,t:1527613865732};\\\", \\\"{x:1562,y:946,t:1527613865749};\\\", \\\"{x:1563,y:947,t:1527613865767};\\\", \\\"{x:1563,y:948,t:1527613865922};\\\", \\\"{x:1563,y:949,t:1527613865933};\\\", \\\"{x:1558,y:950,t:1527613865953};\\\", \\\"{x:1552,y:950,t:1527613865966};\\\", \\\"{x:1546,y:950,t:1527613865983};\\\", \\\"{x:1541,y:952,t:1527613865999};\\\", \\\"{x:1535,y:953,t:1527613866016};\\\", \\\"{x:1534,y:953,t:1527613866042};\\\", \\\"{x:1530,y:953,t:1527613866266};\\\", \\\"{x:1514,y:946,t:1527613866283};\\\", \\\"{x:1489,y:940,t:1527613866300};\\\", \\\"{x:1463,y:938,t:1527613866316};\\\", \\\"{x:1432,y:933,t:1527613866334};\\\", \\\"{x:1411,y:929,t:1527613866349};\\\", \\\"{x:1403,y:927,t:1527613866366};\\\", \\\"{x:1399,y:924,t:1527613866383};\\\", \\\"{x:1394,y:920,t:1527613866399};\\\", \\\"{x:1392,y:918,t:1527613866417};\\\", \\\"{x:1393,y:918,t:1527613866498};\\\", \\\"{x:1395,y:919,t:1527613866505};\\\", \\\"{x:1399,y:920,t:1527613866517};\\\", \\\"{x:1402,y:920,t:1527613866533};\\\", \\\"{x:1407,y:921,t:1527613866551};\\\", \\\"{x:1411,y:922,t:1527613866567};\\\", \\\"{x:1416,y:922,t:1527613866584};\\\", \\\"{x:1418,y:922,t:1527613866600};\\\", \\\"{x:1421,y:922,t:1527613866616};\\\", \\\"{x:1426,y:921,t:1527613866634};\\\", \\\"{x:1429,y:919,t:1527613866649};\\\", \\\"{x:1435,y:917,t:1527613866666};\\\", \\\"{x:1439,y:917,t:1527613866683};\\\", \\\"{x:1444,y:915,t:1527613866700};\\\", \\\"{x:1447,y:913,t:1527613866716};\\\", \\\"{x:1447,y:912,t:1527613866734};\\\", \\\"{x:1448,y:910,t:1527613866751};\\\", \\\"{x:1450,y:909,t:1527613866766};\\\", \\\"{x:1451,y:909,t:1527613866809};\\\", \\\"{x:1451,y:908,t:1527613866818};\\\", \\\"{x:1452,y:908,t:1527613866833};\\\", \\\"{x:1453,y:907,t:1527613866850};\\\", \\\"{x:1453,y:905,t:1527613867066};\\\", \\\"{x:1452,y:904,t:1527613867098};\\\", \\\"{x:1451,y:902,t:1527613867146};\\\", \\\"{x:1451,y:901,t:1527613867153};\\\", \\\"{x:1450,y:900,t:1527613867170};\\\", \\\"{x:1449,y:900,t:1527613867183};\\\", \\\"{x:1449,y:899,t:1527613867200};\\\", \\\"{x:1449,y:898,t:1527613867218};\\\", \\\"{x:1449,y:897,t:1527613867242};\\\", \\\"{x:1449,y:895,t:1527613868114};\\\", \\\"{x:1449,y:894,t:1527613868145};\\\", \\\"{x:1449,y:893,t:1527613868153};\\\", \\\"{x:1449,y:892,t:1527613868177};\\\", \\\"{x:1449,y:890,t:1527613868209};\\\", \\\"{x:1449,y:886,t:1527613868441};\\\", \\\"{x:1449,y:885,t:1527613868451};\\\", \\\"{x:1451,y:881,t:1527613868468};\\\", \\\"{x:1452,y:878,t:1527613868484};\\\", \\\"{x:1452,y:874,t:1527613868501};\\\", \\\"{x:1452,y:870,t:1527613868519};\\\", \\\"{x:1451,y:864,t:1527613868535};\\\", \\\"{x:1450,y:862,t:1527613868551};\\\", \\\"{x:1449,y:859,t:1527613868568};\\\", \\\"{x:1447,y:855,t:1527613868585};\\\", \\\"{x:1447,y:853,t:1527613868610};\\\", \\\"{x:1447,y:852,t:1527613868618};\\\", \\\"{x:1447,y:851,t:1527613868665};\\\", \\\"{x:1447,y:850,t:1527613868681};\\\", \\\"{x:1447,y:849,t:1527613868730};\\\", \\\"{x:1447,y:848,t:1527613868753};\\\", \\\"{x:1447,y:847,t:1527613868769};\\\", \\\"{x:1447,y:846,t:1527613868817};\\\", \\\"{x:1447,y:845,t:1527613868835};\\\", \\\"{x:1448,y:842,t:1527613868851};\\\", \\\"{x:1451,y:839,t:1527613868869};\\\", \\\"{x:1454,y:838,t:1527613868885};\\\", \\\"{x:1457,y:837,t:1527613868901};\\\", \\\"{x:1462,y:836,t:1527613868918};\\\", \\\"{x:1468,y:835,t:1527613868935};\\\", \\\"{x:1471,y:834,t:1527613868950};\\\", \\\"{x:1475,y:832,t:1527613868968};\\\", \\\"{x:1480,y:829,t:1527613868985};\\\", \\\"{x:1481,y:829,t:1527613869001};\\\", \\\"{x:1481,y:828,t:1527613869017};\\\", \\\"{x:1482,y:828,t:1527613869035};\\\", \\\"{x:1484,y:826,t:1527613869121};\\\", \\\"{x:1484,y:823,t:1527613869137};\\\", \\\"{x:1483,y:818,t:1527613869151};\\\", \\\"{x:1473,y:811,t:1527613869168};\\\", \\\"{x:1454,y:803,t:1527613869184};\\\", \\\"{x:1441,y:795,t:1527613869200};\\\", \\\"{x:1432,y:792,t:1527613869218};\\\", \\\"{x:1428,y:789,t:1527613869235};\\\", \\\"{x:1426,y:789,t:1527613869252};\\\", \\\"{x:1425,y:788,t:1527613869268};\\\", \\\"{x:1422,y:786,t:1527613869285};\\\", \\\"{x:1421,y:785,t:1527613869302};\\\", \\\"{x:1420,y:784,t:1527613869317};\\\", \\\"{x:1419,y:783,t:1527613869334};\\\", \\\"{x:1417,y:783,t:1527613869417};\\\", \\\"{x:1415,y:782,t:1527613869424};\\\", \\\"{x:1411,y:781,t:1527613869434};\\\", \\\"{x:1402,y:778,t:1527613869452};\\\", \\\"{x:1397,y:777,t:1527613869468};\\\", \\\"{x:1395,y:777,t:1527613869485};\\\", \\\"{x:1393,y:775,t:1527613869502};\\\", \\\"{x:1392,y:774,t:1527613869889};\\\", \\\"{x:1392,y:773,t:1527613869902};\\\", \\\"{x:1392,y:770,t:1527613869919};\\\", \\\"{x:1392,y:768,t:1527613869936};\\\", \\\"{x:1392,y:767,t:1527613869953};\\\", \\\"{x:1391,y:766,t:1527613869969};\\\", \\\"{x:1391,y:765,t:1527613869985};\\\", \\\"{x:1390,y:765,t:1527613870002};\\\", \\\"{x:1388,y:765,t:1527613870250};\\\", \\\"{x:1386,y:765,t:1527613870257};\\\", \\\"{x:1385,y:765,t:1527613870274};\\\", \\\"{x:1384,y:765,t:1527613870289};\\\", \\\"{x:1383,y:765,t:1527613870303};\\\", \\\"{x:1382,y:765,t:1527613870330};\\\", \\\"{x:1380,y:764,t:1527613870354};\\\", \\\"{x:1380,y:763,t:1527613870609};\\\", \\\"{x:1380,y:762,t:1527613870619};\\\", \\\"{x:1380,y:760,t:1527613870641};\\\", \\\"{x:1380,y:759,t:1527613870673};\\\", \\\"{x:1381,y:759,t:1527613870697};\\\", \\\"{x:1383,y:759,t:1527613871081};\\\", \\\"{x:1385,y:759,t:1527613871089};\\\", \\\"{x:1386,y:758,t:1527613871104};\\\", \\\"{x:1389,y:758,t:1527613871121};\\\", \\\"{x:1391,y:758,t:1527613871137};\\\", \\\"{x:1393,y:759,t:1527613871153};\\\", \\\"{x:1396,y:760,t:1527613871171};\\\", \\\"{x:1401,y:763,t:1527613871187};\\\", \\\"{x:1405,y:765,t:1527613871204};\\\", \\\"{x:1407,y:767,t:1527613871220};\\\", \\\"{x:1411,y:769,t:1527613871236};\\\", \\\"{x:1413,y:771,t:1527613871254};\\\", \\\"{x:1414,y:772,t:1527613871270};\\\", \\\"{x:1415,y:773,t:1527613871286};\\\", \\\"{x:1418,y:773,t:1527613871810};\\\", \\\"{x:1421,y:774,t:1527613871821};\\\", \\\"{x:1431,y:776,t:1527613871837};\\\", \\\"{x:1438,y:778,t:1527613871854};\\\", \\\"{x:1446,y:778,t:1527613871870};\\\", \\\"{x:1452,y:779,t:1527613871887};\\\", \\\"{x:1457,y:779,t:1527613871904};\\\", \\\"{x:1458,y:779,t:1527613871920};\\\", \\\"{x:1460,y:779,t:1527613871938};\\\", \\\"{x:1461,y:779,t:1527613871954};\\\", \\\"{x:1463,y:779,t:1527613871970};\\\", \\\"{x:1465,y:778,t:1527613871987};\\\", \\\"{x:1468,y:776,t:1527613872009};\\\", \\\"{x:1469,y:776,t:1527613872021};\\\", \\\"{x:1469,y:775,t:1527613872037};\\\", \\\"{x:1472,y:774,t:1527613872054};\\\", \\\"{x:1473,y:773,t:1527613872071};\\\", \\\"{x:1474,y:771,t:1527613872087};\\\", \\\"{x:1476,y:771,t:1527613872561};\\\", \\\"{x:1478,y:771,t:1527613872570};\\\", \\\"{x:1480,y:771,t:1527613872588};\\\", \\\"{x:1482,y:771,t:1527613872604};\\\", \\\"{x:1487,y:771,t:1527613872622};\\\", \\\"{x:1492,y:771,t:1527613872637};\\\", \\\"{x:1493,y:771,t:1527613872655};\\\", \\\"{x:1495,y:772,t:1527613872672};\\\", \\\"{x:1496,y:772,t:1527613872687};\\\", \\\"{x:1496,y:773,t:1527613872745};\\\", \\\"{x:1498,y:773,t:1527613872770};\\\", \\\"{x:1500,y:773,t:1527613872785};\\\", \\\"{x:1501,y:773,t:1527613872801};\\\", \\\"{x:1502,y:773,t:1527613872809};\\\", \\\"{x:1507,y:773,t:1527613872821};\\\", \\\"{x:1511,y:773,t:1527613872838};\\\", \\\"{x:1515,y:771,t:1527613872854};\\\", \\\"{x:1518,y:770,t:1527613872871};\\\", \\\"{x:1524,y:768,t:1527613872888};\\\", \\\"{x:1528,y:766,t:1527613872905};\\\", \\\"{x:1538,y:762,t:1527613872922};\\\", \\\"{x:1543,y:761,t:1527613872937};\\\", \\\"{x:1550,y:759,t:1527613872954};\\\", \\\"{x:1552,y:759,t:1527613872971};\\\", \\\"{x:1553,y:759,t:1527613872988};\\\", \\\"{x:1552,y:759,t:1527613873265};\\\", \\\"{x:1549,y:759,t:1527613873273};\\\", \\\"{x:1544,y:759,t:1527613873289};\\\", \\\"{x:1543,y:760,t:1527613873305};\\\", \\\"{x:1540,y:761,t:1527613873321};\\\", \\\"{x:1539,y:761,t:1527613873353};\\\", \\\"{x:1535,y:762,t:1527613873697};\\\", \\\"{x:1533,y:764,t:1527613873705};\\\", \\\"{x:1532,y:764,t:1527613873722};\\\", \\\"{x:1528,y:764,t:1527613873738};\\\", \\\"{x:1525,y:765,t:1527613873755};\\\", \\\"{x:1523,y:766,t:1527613873772};\\\", \\\"{x:1522,y:766,t:1527613873788};\\\", \\\"{x:1521,y:767,t:1527613873833};\\\", \\\"{x:1520,y:767,t:1527613873849};\\\", \\\"{x:1518,y:767,t:1527613873873};\\\", \\\"{x:1517,y:767,t:1527613874473};\\\", \\\"{x:1487,y:766,t:1527613874538};\\\", \\\"{x:1396,y:754,t:1527613874555};\\\", \\\"{x:1291,y:740,t:1527613874572};\\\", \\\"{x:1141,y:719,t:1527613874590};\\\", \\\"{x:966,y:685,t:1527613874606};\\\", \\\"{x:761,y:648,t:1527613874622};\\\", \\\"{x:530,y:599,t:1527613874639};\\\", \\\"{x:344,y:555,t:1527613874656};\\\", \\\"{x:192,y:520,t:1527613874672};\\\", \\\"{x:15,y:483,t:1527613874688};\\\", \\\"{x:0,y:474,t:1527613874705};\\\", \\\"{x:0,y:473,t:1527613874722};\\\", \\\"{x:0,y:474,t:1527613874793};\\\", \\\"{x:1,y:476,t:1527613874938};\\\", \\\"{x:10,y:483,t:1527613874946};\\\", \\\"{x:18,y:491,t:1527613874957};\\\", \\\"{x:33,y:501,t:1527613874973};\\\", \\\"{x:47,y:514,t:1527613874990};\\\", \\\"{x:61,y:525,t:1527613875008};\\\", \\\"{x:85,y:547,t:1527613875022};\\\", \\\"{x:102,y:559,t:1527613875040};\\\", \\\"{x:104,y:561,t:1527613875056};\\\", \\\"{x:105,y:558,t:1527613875249};\\\", \\\"{x:105,y:557,t:1527613875256};\\\", \\\"{x:107,y:546,t:1527613875274};\\\", \\\"{x:116,y:538,t:1527613875291};\\\", \\\"{x:119,y:535,t:1527613875307};\\\", \\\"{x:120,y:535,t:1527613875400};\\\", \\\"{x:121,y:535,t:1527613875408};\\\", \\\"{x:122,y:535,t:1527613875424};\\\", \\\"{x:128,y:536,t:1527613875440};\\\", \\\"{x:135,y:537,t:1527613875457};\\\", \\\"{x:139,y:537,t:1527613875474};\\\", \\\"{x:142,y:539,t:1527613875491};\\\", \\\"{x:143,y:539,t:1527613875507};\\\", \\\"{x:144,y:539,t:1527613875545};\\\", \\\"{x:155,y:550,t:1527613876138};\\\", \\\"{x:181,y:576,t:1527613876162};\\\", \\\"{x:219,y:616,t:1527613876174};\\\", \\\"{x:252,y:643,t:1527613876192};\\\", \\\"{x:291,y:668,t:1527613876207};\\\", \\\"{x:375,y:714,t:1527613876224};\\\", \\\"{x:423,y:738,t:1527613876241};\\\", \\\"{x:443,y:749,t:1527613876256};\\\", \\\"{x:454,y:756,t:1527613876274};\\\", \\\"{x:462,y:761,t:1527613876291};\\\", \\\"{x:464,y:762,t:1527613876308};\\\", \\\"{x:466,y:765,t:1527613876324};\\\", \\\"{x:469,y:772,t:1527613876341};\\\", \\\"{x:471,y:774,t:1527613876358};\\\", \\\"{x:472,y:777,t:1527613876374};\\\", \\\"{x:473,y:778,t:1527613876391};\\\", \\\"{x:474,y:778,t:1527613876432};\\\", \\\"{x:475,y:776,t:1527613876441};\\\", \\\"{x:479,y:766,t:1527613876458};\\\", \\\"{x:482,y:762,t:1527613876474};\\\", \\\"{x:487,y:756,t:1527613876491};\\\", \\\"{x:490,y:753,t:1527613876510};\\\", \\\"{x:493,y:750,t:1527613876524};\\\", \\\"{x:494,y:750,t:1527613876541};\\\", \\\"{x:494,y:748,t:1527613876576};\\\", \\\"{x:494,y:742,t:1527613876591};\\\", \\\"{x:494,y:727,t:1527613876608};\\\", \\\"{x:491,y:711,t:1527613876625};\\\", \\\"{x:474,y:689,t:1527613876641};\\\", \\\"{x:430,y:651,t:1527613876659};\\\", \\\"{x:328,y:602,t:1527613876675};\\\", \\\"{x:208,y:560,t:1527613876692};\\\", \\\"{x:121,y:535,t:1527613876708};\\\", \\\"{x:88,y:521,t:1527613876724};\\\", \\\"{x:61,y:510,t:1527613876741};\\\", \\\"{x:36,y:503,t:1527613876758};\\\", \\\"{x:29,y:500,t:1527613876775};\\\", \\\"{x:28,y:504,t:1527613876945};\\\", \\\"{x:31,y:506,t:1527613876958};\\\", \\\"{x:40,y:513,t:1527613876976};\\\", \\\"{x:55,y:524,t:1527613876991};\\\", \\\"{x:79,y:537,t:1527613877010};\\\", \\\"{x:88,y:543,t:1527613877025};\\\", \\\"{x:92,y:546,t:1527613877041};\\\", \\\"{x:94,y:548,t:1527613877058};\\\", \\\"{x:95,y:549,t:1527613877076};\\\", \\\"{x:96,y:550,t:1527613877161};\\\", \\\"{x:97,y:550,t:1527613877175};\\\", \\\"{x:98,y:550,t:1527613877217};\\\", \\\"{x:99,y:550,t:1527613877417};\\\", \\\"{x:101,y:551,t:1527613877425};\\\", \\\"{x:104,y:552,t:1527613877443};\\\", \\\"{x:110,y:554,t:1527613877458};\\\", \\\"{x:115,y:556,t:1527613877477};\\\", \\\"{x:124,y:557,t:1527613877492};\\\", \\\"{x:132,y:560,t:1527613877508};\\\", \\\"{x:137,y:560,t:1527613877525};\\\", \\\"{x:137,y:561,t:1527613877560};\\\", \\\"{x:142,y:561,t:1527613877592};\\\", \\\"{x:143,y:561,t:1527613877608};\\\", \\\"{x:146,y:559,t:1527613877640};\\\", \\\"{x:147,y:559,t:1527613877649};\\\", \\\"{x:149,y:557,t:1527613877659};\\\", \\\"{x:150,y:556,t:1527613877675};\\\", \\\"{x:151,y:555,t:1527613877692};\\\", \\\"{x:152,y:554,t:1527613877768};\\\", \\\"{x:153,y:553,t:1527613877777};\\\", \\\"{x:156,y:552,t:1527613877872};\\\", \\\"{x:159,y:551,t:1527613877881};\\\", \\\"{x:160,y:550,t:1527613877892};\\\", \\\"{x:161,y:549,t:1527613877909};\\\", \\\"{x:162,y:549,t:1527613877937};\\\", \\\"{x:166,y:549,t:1527613880849};\\\", \\\"{x:172,y:552,t:1527613880862};\\\", \\\"{x:186,y:570,t:1527613880880};\\\", \\\"{x:199,y:585,t:1527613880894};\\\", \\\"{x:240,y:620,t:1527613880927};\\\", \\\"{x:259,y:633,t:1527613880943};\\\", \\\"{x:272,y:648,t:1527613880962};\\\", \\\"{x:279,y:653,t:1527613880979};\\\", \\\"{x:281,y:656,t:1527613880995};\\\", \\\"{x:283,y:656,t:1527613881011};\\\", \\\"{x:286,y:656,t:1527613881072};\\\", \\\"{x:287,y:656,t:1527613881080};\\\", \\\"{x:290,y:658,t:1527613881095};\\\", \\\"{x:294,y:661,t:1527613881111};\\\", \\\"{x:316,y:677,t:1527613881129};\\\", \\\"{x:339,y:692,t:1527613881146};\\\", \\\"{x:364,y:713,t:1527613881161};\\\", \\\"{x:406,y:738,t:1527613881178};\\\", \\\"{x:446,y:766,t:1527613881196};\\\", \\\"{x:473,y:783,t:1527613881211};\\\", \\\"{x:513,y:796,t:1527613881229};\\\", \\\"{x:549,y:807,t:1527613881246};\\\", \\\"{x:574,y:816,t:1527613881262};\\\", \\\"{x:586,y:819,t:1527613881278};\\\", \\\"{x:599,y:823,t:1527613881295};\\\", \\\"{x:602,y:823,t:1527613881311};\\\", \\\"{x:603,y:823,t:1527613881329};\\\", \\\"{x:605,y:823,t:1527613881361};\\\", \\\"{x:605,y:822,t:1527613881368};\\\", \\\"{x:606,y:819,t:1527613881385};\\\", \\\"{x:607,y:817,t:1527613881395};\\\", \\\"{x:608,y:816,t:1527613881412};\\\", \\\"{x:608,y:810,t:1527613881428};\\\", \\\"{x:608,y:798,t:1527613881445};\\\", \\\"{x:603,y:785,t:1527613881463};\\\", \\\"{x:598,y:775,t:1527613881478};\\\", \\\"{x:593,y:769,t:1527613881495};\\\", \\\"{x:582,y:756,t:1527613881513};\\\", \\\"{x:572,y:747,t:1527613881528};\\\", \\\"{x:566,y:742,t:1527613881545};\\\", \\\"{x:561,y:739,t:1527613881564};\\\", \\\"{x:554,y:735,t:1527613881578};\\\", \\\"{x:550,y:731,t:1527613881595};\\\", \\\"{x:548,y:730,t:1527613881612};\\\", \\\"{x:546,y:729,t:1527613881628};\\\", \\\"{x:545,y:728,t:1527613881645};\\\", \\\"{x:544,y:728,t:1527613881662};\\\", \\\"{x:543,y:728,t:1527613881678};\\\", \\\"{x:542,y:728,t:1527613881695};\\\", \\\"{x:538,y:726,t:1527613881712};\\\", \\\"{x:535,y:726,t:1527613881728};\\\", \\\"{x:534,y:725,t:1527613881745};\\\" ] }, { \\\"rt\\\": 60042, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 19, \\\"time_elapsed\\\": 619078, \\\"internal_node_id\\\": \\\"0.0-6.0-9.0\\\", \\\"subject\\\": \\\"AZKMW\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"oscar\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 15, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"F\\\", \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-04 PM-03 PM-06 PM-B -B -D -02 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:546,y:725,t:1527613887305};\\\", \\\"{x:588,y:725,t:1527613887317};\\\", \\\"{x:609,y:720,t:1527613887333};\\\", \\\"{x:610,y:720,t:1527613887350};\\\", \\\"{x:610,y:717,t:1527613888472};\\\", \\\"{x:610,y:709,t:1527613888484};\\\", \\\"{x:609,y:697,t:1527613888500};\\\", \\\"{x:605,y:675,t:1527613888517};\\\", \\\"{x:599,y:652,t:1527613888535};\\\", \\\"{x:590,y:623,t:1527613888551};\\\", \\\"{x:581,y:595,t:1527613888568};\\\", \\\"{x:564,y:524,t:1527613888584};\\\", \\\"{x:548,y:483,t:1527613888601};\\\", \\\"{x:543,y:449,t:1527613888617};\\\", \\\"{x:533,y:398,t:1527613888634};\\\", \\\"{x:525,y:367,t:1527613888650};\\\", \\\"{x:510,y:331,t:1527613888667};\\\", \\\"{x:495,y:298,t:1527613888684};\\\", \\\"{x:484,y:279,t:1527613888700};\\\", \\\"{x:477,y:265,t:1527613888717};\\\", \\\"{x:474,y:261,t:1527613888734};\\\", \\\"{x:485,y:266,t:1527613888832};\\\", \\\"{x:506,y:284,t:1527613888840};\\\", \\\"{x:529,y:306,t:1527613888851};\\\", \\\"{x:553,y:346,t:1527613888868};\\\", \\\"{x:561,y:365,t:1527613888884};\\\", \\\"{x:563,y:374,t:1527613888901};\\\", \\\"{x:564,y:377,t:1527613888917};\\\", \\\"{x:565,y:379,t:1527613888934};\\\", \\\"{x:565,y:380,t:1527613888952};\\\", \\\"{x:565,y:381,t:1527613888975};\\\", \\\"{x:567,y:382,t:1527613889104};\\\", \\\"{x:570,y:390,t:1527613889117};\\\", \\\"{x:584,y:410,t:1527613889135};\\\", \\\"{x:601,y:432,t:1527613889151};\\\", \\\"{x:617,y:465,t:1527613889167};\\\", \\\"{x:660,y:527,t:1527613889185};\\\", \\\"{x:713,y:573,t:1527613889201};\\\", \\\"{x:765,y:617,t:1527613889219};\\\", \\\"{x:834,y:662,t:1527613889235};\\\", \\\"{x:884,y:693,t:1527613889251};\\\", \\\"{x:901,y:706,t:1527613889268};\\\", \\\"{x:907,y:710,t:1527613889284};\\\", \\\"{x:909,y:710,t:1527613889301};\\\", \\\"{x:910,y:711,t:1527613889318};\\\", \\\"{x:914,y:709,t:1527613889384};\\\", \\\"{x:914,y:708,t:1527613889392};\\\", \\\"{x:914,y:706,t:1527613890975};\\\", \\\"{x:929,y:706,t:1527613890987};\\\", \\\"{x:1034,y:720,t:1527613891004};\\\", \\\"{x:1208,y:776,t:1527613891020};\\\", \\\"{x:1366,y:819,t:1527613891036};\\\", \\\"{x:1467,y:859,t:1527613891053};\\\", \\\"{x:1553,y:882,t:1527613891070};\\\", \\\"{x:1652,y:906,t:1527613891087};\\\", \\\"{x:1747,y:940,t:1527613891103};\\\", \\\"{x:1773,y:946,t:1527613891120};\\\", \\\"{x:1765,y:946,t:1527613891281};\\\", \\\"{x:1740,y:946,t:1527613891289};\\\", \\\"{x:1695,y:952,t:1527613891304};\\\", \\\"{x:1621,y:976,t:1527613891321};\\\", \\\"{x:1601,y:992,t:1527613891339};\\\", \\\"{x:1585,y:1002,t:1527613891354};\\\", \\\"{x:1571,y:1008,t:1527613891371};\\\", \\\"{x:1569,y:1010,t:1527613891389};\\\", \\\"{x:1568,y:1010,t:1527613891404};\\\", \\\"{x:1566,y:1010,t:1527613891601};\\\", \\\"{x:1561,y:1010,t:1527613891608};\\\", \\\"{x:1557,y:1007,t:1527613891621};\\\", \\\"{x:1552,y:1004,t:1527613891638};\\\", \\\"{x:1548,y:1000,t:1527613891655};\\\", \\\"{x:1543,y:995,t:1527613891671};\\\", \\\"{x:1536,y:991,t:1527613891688};\\\", \\\"{x:1535,y:990,t:1527613891705};\\\", \\\"{x:1532,y:987,t:1527613891785};\\\", \\\"{x:1528,y:984,t:1527613891793};\\\", \\\"{x:1526,y:982,t:1527613891806};\\\", \\\"{x:1524,y:979,t:1527613891821};\\\", \\\"{x:1520,y:975,t:1527613891838};\\\", \\\"{x:1517,y:972,t:1527613891855};\\\", \\\"{x:1513,y:967,t:1527613891872};\\\", \\\"{x:1503,y:960,t:1527613891888};\\\", \\\"{x:1490,y:948,t:1527613891905};\\\", \\\"{x:1485,y:945,t:1527613891922};\\\", \\\"{x:1483,y:943,t:1527613891939};\\\", \\\"{x:1481,y:942,t:1527613891955};\\\", \\\"{x:1481,y:943,t:1527613892217};\\\", \\\"{x:1481,y:945,t:1527613892225};\\\", \\\"{x:1481,y:948,t:1527613892239};\\\", \\\"{x:1481,y:953,t:1527613892256};\\\", \\\"{x:1478,y:957,t:1527613892272};\\\", \\\"{x:1478,y:960,t:1527613892290};\\\", \\\"{x:1478,y:962,t:1527613892329};\\\", \\\"{x:1476,y:963,t:1527613892529};\\\", \\\"{x:1463,y:962,t:1527613892540};\\\", \\\"{x:1351,y:923,t:1527613892556};\\\", \\\"{x:1176,y:866,t:1527613892572};\\\", \\\"{x:950,y:800,t:1527613892590};\\\", \\\"{x:725,y:710,t:1527613892606};\\\", \\\"{x:625,y:648,t:1527613892622};\\\", \\\"{x:453,y:592,t:1527613892640};\\\", \\\"{x:285,y:547,t:1527613892657};\\\", \\\"{x:122,y:502,t:1527613892672};\\\", \\\"{x:52,y:480,t:1527613892698};\\\", \\\"{x:42,y:475,t:1527613892713};\\\", \\\"{x:42,y:474,t:1527613892921};\\\", \\\"{x:47,y:471,t:1527613892938};\\\", \\\"{x:51,y:470,t:1527613892969};\\\", \\\"{x:54,y:467,t:1527613892976};\\\", \\\"{x:71,y:467,t:1527613892988};\\\", \\\"{x:187,y:498,t:1527613893005};\\\", \\\"{x:358,y:549,t:1527613893022};\\\", \\\"{x:565,y:605,t:1527613893038};\\\", \\\"{x:795,y:681,t:1527613893055};\\\", \\\"{x:1125,y:796,t:1527613893072};\\\", \\\"{x:1299,y:846,t:1527613893088};\\\", \\\"{x:1481,y:901,t:1527613893105};\\\", \\\"{x:1626,y:947,t:1527613893121};\\\", \\\"{x:1736,y:978,t:1527613893138};\\\", \\\"{x:1826,y:1011,t:1527613893154};\\\", \\\"{x:1881,y:1024,t:1527613893172};\\\", \\\"{x:1898,y:1029,t:1527613893188};\\\", \\\"{x:1899,y:1029,t:1527613893205};\\\", \\\"{x:1897,y:1029,t:1527613893362};\\\", \\\"{x:1882,y:1031,t:1527613893372};\\\", \\\"{x:1831,y:1033,t:1527613893389};\\\", \\\"{x:1781,y:1032,t:1527613893405};\\\", \\\"{x:1717,y:1032,t:1527613893422};\\\", \\\"{x:1650,y:1032,t:1527613893439};\\\", \\\"{x:1603,y:1032,t:1527613893455};\\\", \\\"{x:1557,y:1031,t:1527613893472};\\\", \\\"{x:1528,y:1030,t:1527613893489};\\\", \\\"{x:1517,y:1027,t:1527613893505};\\\", \\\"{x:1515,y:1025,t:1527613893523};\\\", \\\"{x:1514,y:1025,t:1527613893539};\\\", \\\"{x:1513,y:1025,t:1527613893649};\\\", \\\"{x:1510,y:1022,t:1527613893665};\\\", \\\"{x:1503,y:1014,t:1527613893672};\\\", \\\"{x:1480,y:999,t:1527613893689};\\\", \\\"{x:1452,y:983,t:1527613893706};\\\", \\\"{x:1425,y:964,t:1527613893723};\\\", \\\"{x:1411,y:956,t:1527613893739};\\\", \\\"{x:1399,y:950,t:1527613893756};\\\", \\\"{x:1394,y:948,t:1527613893773};\\\", \\\"{x:1394,y:947,t:1527613893789};\\\", \\\"{x:1393,y:947,t:1527613893809};\\\", \\\"{x:1392,y:947,t:1527613893823};\\\", \\\"{x:1393,y:946,t:1527613893992};\\\", \\\"{x:1396,y:945,t:1527613894006};\\\", \\\"{x:1399,y:945,t:1527613894022};\\\", \\\"{x:1401,y:945,t:1527613894038};\\\", \\\"{x:1403,y:945,t:1527613894055};\\\", \\\"{x:1404,y:945,t:1527613894072};\\\", \\\"{x:1404,y:944,t:1527613894152};\\\", \\\"{x:1405,y:944,t:1527613894160};\\\", \\\"{x:1406,y:942,t:1527613894175};\\\", \\\"{x:1406,y:941,t:1527613894199};\\\", \\\"{x:1408,y:939,t:1527613894207};\\\", \\\"{x:1408,y:938,t:1527613894222};\\\", \\\"{x:1408,y:934,t:1527613894239};\\\", \\\"{x:1408,y:931,t:1527613894256};\\\", \\\"{x:1410,y:928,t:1527613894271};\\\", \\\"{x:1410,y:925,t:1527613894289};\\\", \\\"{x:1411,y:921,t:1527613894305};\\\", \\\"{x:1411,y:918,t:1527613894321};\\\", \\\"{x:1411,y:917,t:1527613894339};\\\", \\\"{x:1412,y:915,t:1527613894356};\\\", \\\"{x:1412,y:914,t:1527613894373};\\\", \\\"{x:1412,y:913,t:1527613894392};\\\", \\\"{x:1412,y:911,t:1527613894406};\\\", \\\"{x:1412,y:909,t:1527613894423};\\\", \\\"{x:1412,y:905,t:1527613894439};\\\", \\\"{x:1412,y:904,t:1527613894455};\\\", \\\"{x:1413,y:901,t:1527613894472};\\\", \\\"{x:1413,y:900,t:1527613894528};\\\", \\\"{x:1413,y:899,t:1527613894539};\\\", \\\"{x:1414,y:898,t:1527613894556};\\\", \\\"{x:1414,y:896,t:1527613894625};\\\", \\\"{x:1415,y:896,t:1527613895080};\\\", \\\"{x:1421,y:899,t:1527613895089};\\\", \\\"{x:1430,y:906,t:1527613895106};\\\", \\\"{x:1443,y:915,t:1527613895122};\\\", \\\"{x:1455,y:922,t:1527613895140};\\\", \\\"{x:1470,y:931,t:1527613895155};\\\", \\\"{x:1480,y:937,t:1527613895173};\\\", \\\"{x:1482,y:939,t:1527613895189};\\\", \\\"{x:1482,y:940,t:1527613895206};\\\", \\\"{x:1483,y:941,t:1527613895233};\\\", \\\"{x:1484,y:942,t:1527613895248};\\\", \\\"{x:1484,y:943,t:1527613895256};\\\", \\\"{x:1484,y:946,t:1527613895273};\\\", \\\"{x:1487,y:953,t:1527613895291};\\\", \\\"{x:1490,y:958,t:1527613895307};\\\", \\\"{x:1491,y:961,t:1527613895323};\\\", \\\"{x:1492,y:962,t:1527613895340};\\\", \\\"{x:1493,y:963,t:1527613895357};\\\", \\\"{x:1494,y:963,t:1527613895817};\\\", \\\"{x:1494,y:964,t:1527613895841};\\\", \\\"{x:1493,y:964,t:1527613895889};\\\", \\\"{x:1490,y:964,t:1527613896281};\\\", \\\"{x:1488,y:963,t:1527613896291};\\\", \\\"{x:1486,y:963,t:1527613896307};\\\", \\\"{x:1484,y:963,t:1527613896324};\\\", \\\"{x:1481,y:961,t:1527613896342};\\\", \\\"{x:1479,y:961,t:1527613897993};\\\", \\\"{x:1469,y:961,t:1527613898009};\\\", \\\"{x:1451,y:960,t:1527613898025};\\\", \\\"{x:1426,y:954,t:1527613898043};\\\", \\\"{x:1373,y:948,t:1527613898058};\\\", \\\"{x:1343,y:942,t:1527613898075};\\\", \\\"{x:1335,y:940,t:1527613898092};\\\", \\\"{x:1325,y:935,t:1527613898108};\\\", \\\"{x:1319,y:931,t:1527613898125};\\\", \\\"{x:1318,y:931,t:1527613898142};\\\", \\\"{x:1318,y:930,t:1527613898169};\\\", \\\"{x:1317,y:930,t:1527613898177};\\\", \\\"{x:1317,y:927,t:1527613898216};\\\", \\\"{x:1317,y:925,t:1527613898225};\\\", \\\"{x:1317,y:911,t:1527613898242};\\\", \\\"{x:1317,y:891,t:1527613898260};\\\", \\\"{x:1316,y:872,t:1527613898276};\\\", \\\"{x:1314,y:848,t:1527613898293};\\\", \\\"{x:1311,y:830,t:1527613898310};\\\", \\\"{x:1303,y:809,t:1527613898325};\\\", \\\"{x:1298,y:800,t:1527613898342};\\\", \\\"{x:1297,y:797,t:1527613898359};\\\", \\\"{x:1297,y:796,t:1527613898474};\\\", \\\"{x:1296,y:796,t:1527613898489};\\\", \\\"{x:1294,y:797,t:1527613898496};\\\", \\\"{x:1292,y:798,t:1527613898513};\\\", \\\"{x:1292,y:799,t:1527613898525};\\\", \\\"{x:1289,y:803,t:1527613898543};\\\", \\\"{x:1289,y:804,t:1527613898559};\\\", \\\"{x:1288,y:805,t:1527613898576};\\\", \\\"{x:1289,y:805,t:1527613898785};\\\", \\\"{x:1293,y:806,t:1527613898792};\\\", \\\"{x:1305,y:811,t:1527613898810};\\\", \\\"{x:1315,y:813,t:1527613898826};\\\", \\\"{x:1324,y:817,t:1527613898843};\\\", \\\"{x:1329,y:820,t:1527613898860};\\\", \\\"{x:1332,y:821,t:1527613898877};\\\", \\\"{x:1335,y:824,t:1527613898893};\\\", \\\"{x:1338,y:831,t:1527613898909};\\\", \\\"{x:1342,y:835,t:1527613898926};\\\", \\\"{x:1345,y:840,t:1527613898943};\\\", \\\"{x:1348,y:842,t:1527613898960};\\\", \\\"{x:1350,y:846,t:1527613898976};\\\", \\\"{x:1353,y:846,t:1527613899081};\\\", \\\"{x:1355,y:845,t:1527613899093};\\\", \\\"{x:1359,y:840,t:1527613899110};\\\", \\\"{x:1364,y:836,t:1527613899127};\\\", \\\"{x:1365,y:834,t:1527613899143};\\\", \\\"{x:1367,y:832,t:1527613899160};\\\", \\\"{x:1369,y:830,t:1527613899177};\\\", \\\"{x:1370,y:829,t:1527613899194};\\\", \\\"{x:1370,y:828,t:1527613899210};\\\", \\\"{x:1371,y:828,t:1527613899226};\\\", \\\"{x:1372,y:828,t:1527613899281};\\\", \\\"{x:1372,y:826,t:1527613899297};\\\", \\\"{x:1372,y:825,t:1527613899313};\\\", \\\"{x:1372,y:823,t:1527613899329};\\\", \\\"{x:1372,y:821,t:1527613899344};\\\", \\\"{x:1372,y:819,t:1527613899360};\\\", \\\"{x:1372,y:817,t:1527613899376};\\\", \\\"{x:1372,y:816,t:1527613899393};\\\", \\\"{x:1372,y:813,t:1527613899409};\\\", \\\"{x:1371,y:808,t:1527613899426};\\\", \\\"{x:1370,y:801,t:1527613899442};\\\", \\\"{x:1370,y:792,t:1527613899459};\\\", \\\"{x:1370,y:788,t:1527613899476};\\\", \\\"{x:1370,y:782,t:1527613899492};\\\", \\\"{x:1370,y:776,t:1527613899509};\\\", \\\"{x:1374,y:770,t:1527613899526};\\\", \\\"{x:1377,y:765,t:1527613899543};\\\", \\\"{x:1381,y:758,t:1527613899560};\\\", \\\"{x:1388,y:750,t:1527613899577};\\\", \\\"{x:1391,y:746,t:1527613899593};\\\", \\\"{x:1394,y:742,t:1527613899610};\\\", \\\"{x:1397,y:739,t:1527613899626};\\\", \\\"{x:1398,y:737,t:1527613899643};\\\", \\\"{x:1396,y:737,t:1527613899841};\\\", \\\"{x:1394,y:738,t:1527613899848};\\\", \\\"{x:1392,y:739,t:1527613899864};\\\", \\\"{x:1391,y:740,t:1527613899912};\\\", \\\"{x:1390,y:741,t:1527613899961};\\\", \\\"{x:1390,y:744,t:1527613899977};\\\", \\\"{x:1389,y:748,t:1527613899993};\\\", \\\"{x:1389,y:750,t:1527613900011};\\\", \\\"{x:1389,y:754,t:1527613900026};\\\", \\\"{x:1390,y:758,t:1527613900044};\\\", \\\"{x:1390,y:759,t:1527613900060};\\\", \\\"{x:1390,y:760,t:1527613900105};\\\", \\\"{x:1390,y:761,t:1527613900304};\\\", \\\"{x:1390,y:762,t:1527613900311};\\\", \\\"{x:1388,y:762,t:1527613900351};\\\", \\\"{x:1387,y:762,t:1527613900360};\\\", \\\"{x:1383,y:762,t:1527613900376};\\\", \\\"{x:1376,y:762,t:1527613900392};\\\", \\\"{x:1371,y:762,t:1527613900410};\\\", \\\"{x:1365,y:763,t:1527613900426};\\\", \\\"{x:1355,y:763,t:1527613900443};\\\", \\\"{x:1342,y:763,t:1527613900461};\\\", \\\"{x:1333,y:763,t:1527613900477};\\\", \\\"{x:1323,y:763,t:1527613900493};\\\", \\\"{x:1319,y:763,t:1527613900510};\\\", \\\"{x:1318,y:764,t:1527613900528};\\\", \\\"{x:1319,y:764,t:1527613900777};\\\", \\\"{x:1320,y:765,t:1527613900794};\\\", \\\"{x:1322,y:765,t:1527613900811};\\\", \\\"{x:1323,y:765,t:1527613900828};\\\", \\\"{x:1326,y:767,t:1527613900844};\\\", \\\"{x:1327,y:767,t:1527613900861};\\\", \\\"{x:1328,y:767,t:1527613900881};\\\", \\\"{x:1329,y:767,t:1527613900929};\\\", \\\"{x:1331,y:767,t:1527613900961};\\\", \\\"{x:1340,y:767,t:1527613900977};\\\", \\\"{x:1345,y:767,t:1527613900996};\\\", \\\"{x:1350,y:767,t:1527613901012};\\\", \\\"{x:1358,y:765,t:1527613901029};\\\", \\\"{x:1369,y:761,t:1527613901045};\\\", \\\"{x:1371,y:761,t:1527613901061};\\\", \\\"{x:1372,y:759,t:1527613901078};\\\", \\\"{x:1374,y:759,t:1527613901095};\\\", \\\"{x:1375,y:758,t:1527613901170};\\\", \\\"{x:1376,y:758,t:1527613901178};\\\", \\\"{x:1377,y:757,t:1527613901194};\\\", \\\"{x:1379,y:756,t:1527613901212};\\\", \\\"{x:1381,y:755,t:1527613901228};\\\", \\\"{x:1383,y:755,t:1527613901248};\\\", \\\"{x:1383,y:754,t:1527613901262};\\\", \\\"{x:1386,y:754,t:1527613901321};\\\", \\\"{x:1388,y:754,t:1527613901378};\\\", \\\"{x:1388,y:755,t:1527613901497};\\\", \\\"{x:1388,y:758,t:1527613901512};\\\", \\\"{x:1386,y:762,t:1527613901529};\\\", \\\"{x:1386,y:765,t:1527613901544};\\\", \\\"{x:1385,y:765,t:1527613901561};\\\", \\\"{x:1385,y:766,t:1527613901578};\\\", \\\"{x:1385,y:767,t:1527613902737};\\\", \\\"{x:1386,y:767,t:1527613902785};\\\", \\\"{x:1387,y:767,t:1527613902816};\\\", \\\"{x:1389,y:767,t:1527613902881};\\\", \\\"{x:1392,y:767,t:1527613902897};\\\", \\\"{x:1394,y:767,t:1527613902929};\\\", \\\"{x:1398,y:767,t:1527613902946};\\\", \\\"{x:1400,y:767,t:1527613902963};\\\", \\\"{x:1403,y:766,t:1527613902979};\\\", \\\"{x:1404,y:766,t:1527613902996};\\\", \\\"{x:1408,y:765,t:1527613903013};\\\", \\\"{x:1410,y:765,t:1527613903030};\\\", \\\"{x:1413,y:764,t:1527613903045};\\\", \\\"{x:1414,y:764,t:1527613903065};\\\", \\\"{x:1415,y:763,t:1527613903089};\\\", \\\"{x:1415,y:762,t:1527613903129};\\\", \\\"{x:1416,y:762,t:1527613903146};\\\", \\\"{x:1416,y:761,t:1527613903665};\\\", \\\"{x:1417,y:760,t:1527613903721};\\\", \\\"{x:1418,y:760,t:1527613903730};\\\", \\\"{x:1418,y:759,t:1527613903768};\\\", \\\"{x:1420,y:759,t:1527613903785};\\\", \\\"{x:1425,y:759,t:1527613903796};\\\", \\\"{x:1431,y:758,t:1527613903813};\\\", \\\"{x:1436,y:758,t:1527613903830};\\\", \\\"{x:1440,y:758,t:1527613903846};\\\", \\\"{x:1447,y:758,t:1527613903864};\\\", \\\"{x:1450,y:755,t:1527613903879};\\\", \\\"{x:1453,y:755,t:1527613903896};\\\", \\\"{x:1454,y:755,t:1527613903953};\\\", \\\"{x:1455,y:755,t:1527613904121};\\\", \\\"{x:1456,y:755,t:1527613904145};\\\", \\\"{x:1458,y:756,t:1527613904153};\\\", \\\"{x:1460,y:756,t:1527613904169};\\\", \\\"{x:1462,y:756,t:1527613904192};\\\", \\\"{x:1463,y:756,t:1527613904224};\\\", \\\"{x:1464,y:757,t:1527613904273};\\\", \\\"{x:1465,y:757,t:1527613904297};\\\", \\\"{x:1467,y:758,t:1527613904328};\\\", \\\"{x:1469,y:759,t:1527613904417};\\\", \\\"{x:1470,y:759,t:1527613904432};\\\", \\\"{x:1471,y:759,t:1527613904448};\\\", \\\"{x:1472,y:759,t:1527613904465};\\\", \\\"{x:1473,y:759,t:1527613904489};\\\", \\\"{x:1474,y:759,t:1527613905152};\\\", \\\"{x:1482,y:759,t:1527613905163};\\\", \\\"{x:1495,y:757,t:1527613905180};\\\", \\\"{x:1497,y:757,t:1527613905198};\\\", \\\"{x:1498,y:757,t:1527613905213};\\\", \\\"{x:1500,y:757,t:1527613905230};\\\", \\\"{x:1501,y:757,t:1527613905247};\\\", \\\"{x:1501,y:756,t:1527613905265};\\\", \\\"{x:1500,y:756,t:1527613905849};\\\", \\\"{x:1499,y:756,t:1527613905864};\\\", \\\"{x:1498,y:756,t:1527613905882};\\\", \\\"{x:1495,y:756,t:1527613905937};\\\", \\\"{x:1494,y:756,t:1527613905948};\\\", \\\"{x:1493,y:756,t:1527613905965};\\\", \\\"{x:1492,y:756,t:1527613905982};\\\", \\\"{x:1489,y:758,t:1527613905998};\\\", \\\"{x:1486,y:758,t:1527613906024};\\\", \\\"{x:1485,y:758,t:1527613906033};\\\", \\\"{x:1484,y:758,t:1527613907241};\\\", \\\"{x:1483,y:756,t:1527613914761};\\\", \\\"{x:1483,y:746,t:1527613914771};\\\", \\\"{x:1483,y:740,t:1527613914788};\\\", \\\"{x:1481,y:733,t:1527613914805};\\\", \\\"{x:1479,y:728,t:1527613914821};\\\", \\\"{x:1478,y:725,t:1527613914838};\\\", \\\"{x:1478,y:724,t:1527613914855};\\\", \\\"{x:1478,y:723,t:1527613914871};\\\", \\\"{x:1478,y:721,t:1527613914888};\\\", \\\"{x:1478,y:719,t:1527613914905};\\\", \\\"{x:1478,y:718,t:1527613914921};\\\", \\\"{x:1478,y:717,t:1527613914938};\\\", \\\"{x:1477,y:716,t:1527613914955};\\\", \\\"{x:1476,y:714,t:1527613914971};\\\", \\\"{x:1476,y:712,t:1527613915007};\\\", \\\"{x:1476,y:710,t:1527613915024};\\\", \\\"{x:1476,y:708,t:1527613915040};\\\", \\\"{x:1476,y:706,t:1527613915056};\\\", \\\"{x:1476,y:705,t:1527613915070};\\\", \\\"{x:1476,y:703,t:1527613915088};\\\", \\\"{x:1476,y:702,t:1527613915104};\\\", \\\"{x:1476,y:700,t:1527613915128};\\\", \\\"{x:1476,y:698,t:1527613915144};\\\", \\\"{x:1476,y:696,t:1527613915160};\\\", \\\"{x:1476,y:695,t:1527613915192};\\\", \\\"{x:1477,y:694,t:1527613915207};\\\", \\\"{x:1477,y:693,t:1527613915224};\\\", \\\"{x:1478,y:692,t:1527613915280};\\\", \\\"{x:1474,y:688,t:1527613915431};\\\", \\\"{x:1444,y:687,t:1527613915440};\\\", \\\"{x:1381,y:687,t:1527613915455};\\\", \\\"{x:1110,y:664,t:1527613915471};\\\", \\\"{x:885,y:653,t:1527613915487};\\\", \\\"{x:687,y:635,t:1527613915505};\\\", \\\"{x:500,y:610,t:1527613915522};\\\", \\\"{x:358,y:605,t:1527613915538};\\\", \\\"{x:233,y:605,t:1527613915557};\\\", \\\"{x:170,y:609,t:1527613915574};\\\", \\\"{x:149,y:613,t:1527613915589};\\\", \\\"{x:143,y:616,t:1527613915607};\\\", \\\"{x:141,y:618,t:1527613915623};\\\", \\\"{x:151,y:616,t:1527613915704};\\\", \\\"{x:168,y:613,t:1527613915712};\\\", \\\"{x:194,y:611,t:1527613915724};\\\", \\\"{x:259,y:601,t:1527613915740};\\\", \\\"{x:326,y:590,t:1527613915757};\\\", \\\"{x:385,y:579,t:1527613915773};\\\", \\\"{x:469,y:568,t:1527613915790};\\\", \\\"{x:498,y:561,t:1527613915807};\\\", \\\"{x:518,y:550,t:1527613915825};\\\", \\\"{x:527,y:547,t:1527613915839};\\\", \\\"{x:536,y:545,t:1527613915857};\\\", \\\"{x:554,y:537,t:1527613915874};\\\", \\\"{x:589,y:538,t:1527613915890};\\\", \\\"{x:645,y:538,t:1527613915907};\\\", \\\"{x:712,y:538,t:1527613915923};\\\", \\\"{x:758,y:540,t:1527613915941};\\\", \\\"{x:815,y:544,t:1527613915956};\\\", \\\"{x:840,y:544,t:1527613915975};\\\", \\\"{x:849,y:544,t:1527613915991};\\\", \\\"{x:850,y:542,t:1527613916201};\\\", \\\"{x:850,y:540,t:1527613916225};\\\", \\\"{x:852,y:538,t:1527613916241};\\\", \\\"{x:852,y:537,t:1527613916271};\\\", \\\"{x:852,y:535,t:1527613916279};\\\", \\\"{x:852,y:534,t:1527613916295};\\\", \\\"{x:852,y:533,t:1527613916306};\\\", \\\"{x:852,y:532,t:1527613916323};\\\", \\\"{x:852,y:531,t:1527613916341};\\\", \\\"{x:852,y:530,t:1527613916358};\\\", \\\"{x:852,y:529,t:1527613916373};\\\", \\\"{x:849,y:526,t:1527613916390};\\\", \\\"{x:844,y:525,t:1527613916406};\\\", \\\"{x:841,y:524,t:1527613916423};\\\", \\\"{x:841,y:525,t:1527613916801};\\\", \\\"{x:830,y:535,t:1527613925861};\\\", \\\"{x:656,y:766,t:1527613925884};\\\", \\\"{x:583,y:866,t:1527613925901};\\\", \\\"{x:543,y:910,t:1527613925918};\\\", \\\"{x:526,y:932,t:1527613925935};\\\", \\\"{x:502,y:959,t:1527613925951};\\\", \\\"{x:480,y:982,t:1527613925968};\\\", \\\"{x:465,y:999,t:1527613925985};\\\", \\\"{x:456,y:1009,t:1527613926001};\\\", \\\"{x:455,y:1010,t:1527613926018};\\\", \\\"{x:454,y:1011,t:1527613926035};\\\", \\\"{x:454,y:1012,t:1527613926051};\\\", \\\"{x:451,y:1009,t:1527613926082};\\\", \\\"{x:450,y:971,t:1527613926090};\\\", \\\"{x:446,y:913,t:1527613926101};\\\", \\\"{x:446,y:826,t:1527613926118};\\\", \\\"{x:437,y:762,t:1527613926135};\\\", \\\"{x:437,y:728,t:1527613926151};\\\", \\\"{x:438,y:715,t:1527613926168};\\\", \\\"{x:440,y:714,t:1527613926347};\\\", \\\"{x:445,y:713,t:1527613926355};\\\", \\\"{x:446,y:713,t:1527613926368};\\\", \\\"{x:476,y:723,t:1527613926387};\\\", \\\"{x:480,y:728,t:1527613926403};\\\", \\\"{x:491,y:738,t:1527613926420};\\\", \\\"{x:497,y:743,t:1527613926435};\\\", \\\"{x:499,y:744,t:1527613926452};\\\", \\\"{x:501,y:746,t:1527613926468};\\\", \\\"{x:503,y:747,t:1527613927084};\\\", \\\"{x:534,y:742,t:1527613927091};\\\", \\\"{x:595,y:742,t:1527613927103};\\\", \\\"{x:736,y:742,t:1527613927119};\\\", \\\"{x:804,y:740,t:1527613927136};\\\", \\\"{x:821,y:731,t:1527613927152};\\\", \\\"{x:826,y:727,t:1527613927169};\\\", \\\"{x:826,y:720,t:1527613927243};\\\", \\\"{x:826,y:711,t:1527613927252};\\\", \\\"{x:823,y:697,t:1527613927269};\\\", \\\"{x:822,y:689,t:1527613927287};\\\", \\\"{x:813,y:669,t:1527613927302};\\\", \\\"{x:802,y:647,t:1527613927320};\\\", \\\"{x:785,y:620,t:1527613927337};\\\", \\\"{x:768,y:600,t:1527613927354};\\\", \\\"{x:754,y:584,t:1527613927369};\\\", \\\"{x:746,y:577,t:1527613927386};\\\", \\\"{x:744,y:576,t:1527613927804};\\\", \\\"{x:741,y:577,t:1527613927819};\\\", \\\"{x:740,y:577,t:1527613927835};\\\", \\\"{x:739,y:577,t:1527613927963};\\\", \\\"{x:737,y:577,t:1527613927971};\\\", \\\"{x:734,y:577,t:1527613927986};\\\", \\\"{x:729,y:580,t:1527613928002};\\\", \\\"{x:725,y:584,t:1527613928018};\\\", \\\"{x:705,y:616,t:1527613928036};\\\", \\\"{x:674,y:656,t:1527613928053};\\\", \\\"{x:637,y:700,t:1527613928070};\\\", \\\"{x:589,y:755,t:1527613928087};\\\", \\\"{x:567,y:779,t:1527613928103};\\\", \\\"{x:552,y:797,t:1527613928121};\\\", \\\"{x:535,y:815,t:1527613928137};\\\", \\\"{x:525,y:827,t:1527613928153};\\\", \\\"{x:522,y:832,t:1527613928170};\\\", \\\"{x:522,y:833,t:1527613928428};\\\", \\\"{x:522,y:829,t:1527613928451};\\\", \\\"{x:524,y:822,t:1527613928459};\\\", \\\"{x:526,y:815,t:1527613928471};\\\", \\\"{x:530,y:787,t:1527613928488};\\\", \\\"{x:536,y:766,t:1527613928506};\\\", \\\"{x:541,y:754,t:1527613928521};\\\", \\\"{x:544,y:748,t:1527613928537};\\\", \\\"{x:544,y:747,t:1527613928553};\\\", \\\"{x:544,y:745,t:1527613928972};\\\", \\\"{x:555,y:737,t:1527613928987};\\\", \\\"{x:614,y:737,t:1527613929005};\\\", \\\"{x:637,y:737,t:1527613929020};\\\", \\\"{x:654,y:737,t:1527613929038};\\\", \\\"{x:677,y:742,t:1527613929055};\\\", \\\"{x:697,y:746,t:1527613929070};\\\", \\\"{x:708,y:747,t:1527613929088};\\\", \\\"{x:714,y:750,t:1527613930708};\\\", \\\"{x:731,y:759,t:1527613930723};\\\", \\\"{x:749,y:769,t:1527613930739};\\\", \\\"{x:780,y:779,t:1527613930755};\\\", \\\"{x:816,y:786,t:1527613930772};\\\", \\\"{x:865,y:792,t:1527613930789};\\\", \\\"{x:940,y:801,t:1527613930806};\\\", \\\"{x:1038,y:807,t:1527613930824};\\\", \\\"{x:1147,y:804,t:1527613930839};\\\", \\\"{x:1284,y:809,t:1527613930856};\\\", \\\"{x:1397,y:819,t:1527613930873};\\\", \\\"{x:1515,y:831,t:1527613930889};\\\", \\\"{x:1612,y:847,t:1527613930906};\\\", \\\"{x:1687,y:857,t:1527613930923};\\\", \\\"{x:1716,y:858,t:1527613930938};\\\", \\\"{x:1744,y:856,t:1527613930955};\\\", \\\"{x:1768,y:855,t:1527613930972};\\\", \\\"{x:1784,y:853,t:1527613930988};\\\", \\\"{x:1791,y:850,t:1527613931005};\\\", \\\"{x:1792,y:849,t:1527613931022};\\\", \\\"{x:1794,y:846,t:1527613931039};\\\", \\\"{x:1794,y:841,t:1527613931055};\\\", \\\"{x:1794,y:836,t:1527613931072};\\\", \\\"{x:1788,y:831,t:1527613931089};\\\", \\\"{x:1775,y:830,t:1527613931106};\\\", \\\"{x:1747,y:829,t:1527613931123};\\\", \\\"{x:1724,y:834,t:1527613931139};\\\", \\\"{x:1695,y:843,t:1527613931155};\\\", \\\"{x:1671,y:849,t:1527613931173};\\\", \\\"{x:1631,y:859,t:1527613931190};\\\", \\\"{x:1574,y:883,t:1527613931206};\\\", \\\"{x:1551,y:887,t:1527613931222};\\\", \\\"{x:1534,y:890,t:1527613931240};\\\", \\\"{x:1528,y:892,t:1527613931256};\\\", \\\"{x:1523,y:894,t:1527613931273};\\\", \\\"{x:1522,y:894,t:1527613931290};\\\", \\\"{x:1521,y:899,t:1527613931306};\\\", \\\"{x:1519,y:905,t:1527613931323};\\\", \\\"{x:1519,y:918,t:1527613931340};\\\", \\\"{x:1519,y:926,t:1527613931356};\\\", \\\"{x:1519,y:932,t:1527613931373};\\\", \\\"{x:1518,y:934,t:1527613931390};\\\", \\\"{x:1518,y:936,t:1527613931405};\\\", \\\"{x:1517,y:938,t:1527613931436};\\\", \\\"{x:1517,y:939,t:1527613931459};\\\", \\\"{x:1517,y:941,t:1527613931476};\\\", \\\"{x:1517,y:942,t:1527613931490};\\\", \\\"{x:1517,y:946,t:1527613931506};\\\", \\\"{x:1513,y:959,t:1527613931524};\\\", \\\"{x:1508,y:969,t:1527613931539};\\\", \\\"{x:1503,y:982,t:1527613931557};\\\", \\\"{x:1498,y:993,t:1527613931573};\\\", \\\"{x:1494,y:999,t:1527613931590};\\\", \\\"{x:1492,y:1002,t:1527613931607};\\\", \\\"{x:1492,y:997,t:1527613931851};\\\", \\\"{x:1492,y:995,t:1527613931859};\\\", \\\"{x:1492,y:989,t:1527613931873};\\\", \\\"{x:1492,y:985,t:1527613931890};\\\", \\\"{x:1492,y:982,t:1527613931907};\\\", \\\"{x:1492,y:980,t:1527613931923};\\\", \\\"{x:1492,y:977,t:1527613931940};\\\", \\\"{x:1492,y:975,t:1527613931957};\\\", \\\"{x:1492,y:973,t:1527613931973};\\\", \\\"{x:1491,y:972,t:1527613931990};\\\", \\\"{x:1491,y:970,t:1527613932007};\\\", \\\"{x:1490,y:967,t:1527613932025};\\\", \\\"{x:1490,y:966,t:1527613932040};\\\", \\\"{x:1490,y:965,t:1527613932057};\\\", \\\"{x:1489,y:963,t:1527613932074};\\\", \\\"{x:1489,y:959,t:1527613932091};\\\", \\\"{x:1487,y:954,t:1527613932107};\\\", \\\"{x:1487,y:949,t:1527613932124};\\\", \\\"{x:1487,y:945,t:1527613932140};\\\", \\\"{x:1485,y:940,t:1527613932157};\\\", \\\"{x:1482,y:927,t:1527613932174};\\\", \\\"{x:1482,y:924,t:1527613932190};\\\", \\\"{x:1480,y:917,t:1527613932207};\\\", \\\"{x:1480,y:905,t:1527613932224};\\\", \\\"{x:1481,y:900,t:1527613932240};\\\", \\\"{x:1481,y:896,t:1527613932257};\\\", \\\"{x:1481,y:892,t:1527613932274};\\\", \\\"{x:1481,y:888,t:1527613932290};\\\", \\\"{x:1481,y:880,t:1527613932307};\\\", \\\"{x:1481,y:879,t:1527613932324};\\\", \\\"{x:1479,y:876,t:1527613932340};\\\", \\\"{x:1477,y:873,t:1527613932357};\\\", \\\"{x:1476,y:868,t:1527613932374};\\\", \\\"{x:1475,y:862,t:1527613932390};\\\", \\\"{x:1474,y:859,t:1527613932407};\\\", \\\"{x:1474,y:858,t:1527613932424};\\\", \\\"{x:1473,y:857,t:1527613932440};\\\", \\\"{x:1473,y:856,t:1527613932457};\\\", \\\"{x:1473,y:860,t:1527613933140};\\\", \\\"{x:1476,y:874,t:1527613933158};\\\", \\\"{x:1479,y:885,t:1527613933174};\\\", \\\"{x:1480,y:893,t:1527613933191};\\\", \\\"{x:1482,y:902,t:1527613933208};\\\", \\\"{x:1483,y:907,t:1527613933224};\\\", \\\"{x:1485,y:912,t:1527613933241};\\\", \\\"{x:1486,y:914,t:1527613933258};\\\", \\\"{x:1487,y:914,t:1527613933274};\\\", \\\"{x:1490,y:916,t:1527613933291};\\\", \\\"{x:1491,y:916,t:1527613933307};\\\", \\\"{x:1492,y:917,t:1527613933324};\\\", \\\"{x:1494,y:920,t:1527613933341};\\\", \\\"{x:1496,y:928,t:1527613933358};\\\", \\\"{x:1496,y:930,t:1527613933374};\\\", \\\"{x:1496,y:934,t:1527613933391};\\\", \\\"{x:1497,y:935,t:1527613933408};\\\", \\\"{x:1497,y:937,t:1527613933451};\\\", \\\"{x:1496,y:937,t:1527613933508};\\\", \\\"{x:1492,y:925,t:1527613933525};\\\", \\\"{x:1488,y:918,t:1527613933541};\\\", \\\"{x:1486,y:907,t:1527613933558};\\\", \\\"{x:1482,y:898,t:1527613933575};\\\", \\\"{x:1476,y:887,t:1527613933591};\\\", \\\"{x:1473,y:878,t:1527613933608};\\\", \\\"{x:1473,y:870,t:1527613933625};\\\", \\\"{x:1473,y:866,t:1527613933641};\\\", \\\"{x:1473,y:858,t:1527613933658};\\\", \\\"{x:1473,y:847,t:1527613933675};\\\", \\\"{x:1473,y:841,t:1527613933691};\\\", \\\"{x:1473,y:836,t:1527613933708};\\\", \\\"{x:1473,y:830,t:1527613933726};\\\", \\\"{x:1473,y:825,t:1527613933742};\\\", \\\"{x:1474,y:823,t:1527613933758};\\\", \\\"{x:1474,y:821,t:1527613933775};\\\", \\\"{x:1474,y:820,t:1527613933791};\\\", \\\"{x:1474,y:819,t:1527613933812};\\\", \\\"{x:1474,y:818,t:1527613933827};\\\", \\\"{x:1474,y:816,t:1527613933841};\\\", \\\"{x:1475,y:813,t:1527613933859};\\\", \\\"{x:1475,y:809,t:1527613933876};\\\", \\\"{x:1475,y:804,t:1527613933891};\\\", \\\"{x:1475,y:799,t:1527613933908};\\\", \\\"{x:1474,y:791,t:1527613933925};\\\", \\\"{x:1474,y:786,t:1527613933942};\\\", \\\"{x:1473,y:779,t:1527613933958};\\\", \\\"{x:1472,y:775,t:1527613933975};\\\", \\\"{x:1471,y:772,t:1527613933992};\\\", \\\"{x:1471,y:769,t:1527613934009};\\\", \\\"{x:1471,y:768,t:1527613934025};\\\", \\\"{x:1471,y:766,t:1527613934042};\\\", \\\"{x:1471,y:765,t:1527613934058};\\\", \\\"{x:1470,y:763,t:1527613934076};\\\", \\\"{x:1470,y:761,t:1527613934092};\\\", \\\"{x:1470,y:756,t:1527613934108};\\\", \\\"{x:1470,y:753,t:1527613934125};\\\", \\\"{x:1470,y:751,t:1527613934142};\\\", \\\"{x:1469,y:749,t:1527613934157};\\\", \\\"{x:1468,y:748,t:1527613934627};\\\", \\\"{x:1466,y:748,t:1527613934667};\\\", \\\"{x:1465,y:749,t:1527613934779};\\\", \\\"{x:1464,y:750,t:1527613934795};\\\", \\\"{x:1462,y:751,t:1527613934931};\\\", \\\"{x:1462,y:752,t:1527613934942};\\\", \\\"{x:1463,y:757,t:1527613934959};\\\", \\\"{x:1463,y:758,t:1527613934979};\\\", \\\"{x:1463,y:759,t:1527613934992};\\\", \\\"{x:1459,y:766,t:1527613937332};\\\", \\\"{x:1414,y:776,t:1527613937345};\\\", \\\"{x:1203,y:787,t:1527613937362};\\\", \\\"{x:1012,y:784,t:1527613937378};\\\", \\\"{x:859,y:773,t:1527613937395};\\\", \\\"{x:647,y:743,t:1527613937411};\\\", \\\"{x:467,y:719,t:1527613937427};\\\", \\\"{x:257,y:691,t:1527613937444};\\\", \\\"{x:90,y:653,t:1527613937462};\\\", \\\"{x:0,y:609,t:1527613937478};\\\", \\\"{x:0,y:572,t:1527613937494};\\\", \\\"{x:0,y:545,t:1527613937511};\\\", \\\"{x:0,y:537,t:1527613937528};\\\", \\\"{x:0,y:535,t:1527613937544};\\\", \\\"{x:0,y:531,t:1527613937561};\\\", \\\"{x:0,y:528,t:1527613937577};\\\", \\\"{x:24,y:522,t:1527613937594};\\\", \\\"{x:32,y:522,t:1527613937612};\\\", \\\"{x:63,y:520,t:1527613937628};\\\", \\\"{x:76,y:522,t:1527613937645};\\\", \\\"{x:87,y:522,t:1527613937662};\\\", \\\"{x:92,y:525,t:1527613937678};\\\", \\\"{x:93,y:525,t:1527613937695};\\\", \\\"{x:96,y:525,t:1527613937712};\\\", \\\"{x:100,y:525,t:1527613937728};\\\", \\\"{x:105,y:525,t:1527613937745};\\\", \\\"{x:108,y:523,t:1527613937762};\\\", \\\"{x:113,y:519,t:1527613937778};\\\", \\\"{x:123,y:515,t:1527613937795};\\\", \\\"{x:124,y:515,t:1527613937819};\\\", \\\"{x:126,y:515,t:1527613937828};\\\", \\\"{x:129,y:515,t:1527613937845};\\\", \\\"{x:135,y:520,t:1527613937862};\\\", \\\"{x:145,y:528,t:1527613937878};\\\", \\\"{x:151,y:538,t:1527613937895};\\\", \\\"{x:156,y:544,t:1527613937912};\\\", \\\"{x:158,y:548,t:1527613937927};\\\", \\\"{x:161,y:552,t:1527613937945};\\\", \\\"{x:162,y:554,t:1527613937962};\\\", \\\"{x:165,y:555,t:1527613937977};\\\", \\\"{x:170,y:564,t:1527613937995};\\\", \\\"{x:174,y:574,t:1527613938013};\\\", \\\"{x:177,y:581,t:1527613938028};\\\", \\\"{x:178,y:584,t:1527613938044};\\\", \\\"{x:181,y:588,t:1527613938062};\\\", \\\"{x:181,y:583,t:1527613938171};\\\", \\\"{x:181,y:577,t:1527613938180};\\\", \\\"{x:180,y:564,t:1527613938195};\\\", \\\"{x:175,y:551,t:1527613938211};\\\", \\\"{x:173,y:543,t:1527613938229};\\\", \\\"{x:172,y:540,t:1527613938245};\\\", \\\"{x:171,y:540,t:1527613938262};\\\", \\\"{x:171,y:539,t:1527613938402};\\\", \\\"{x:170,y:538,t:1527613938412};\\\", \\\"{x:169,y:536,t:1527613938429};\\\", \\\"{x:168,y:537,t:1527613939283};\\\", \\\"{x:167,y:538,t:1527613939295};\\\", \\\"{x:167,y:539,t:1527613939314};\\\", \\\"{x:166,y:539,t:1527613939329};\\\", \\\"{x:165,y:539,t:1527613939435};\\\", \\\"{x:163,y:546,t:1527613939446};\\\", \\\"{x:161,y:550,t:1527613939463};\\\", \\\"{x:161,y:554,t:1527613939479};\\\", \\\"{x:171,y:560,t:1527613939915};\\\", \\\"{x:185,y:569,t:1527613939930};\\\", \\\"{x:226,y:602,t:1527613939947};\\\", \\\"{x:256,y:626,t:1527613939963};\\\", \\\"{x:285,y:651,t:1527613939980};\\\", \\\"{x:325,y:680,t:1527613939997};\\\", \\\"{x:367,y:708,t:1527613940014};\\\", \\\"{x:398,y:733,t:1527613940030};\\\", \\\"{x:421,y:752,t:1527613940046};\\\", \\\"{x:443,y:768,t:1527613940063};\\\", \\\"{x:470,y:788,t:1527613940080};\\\", \\\"{x:493,y:803,t:1527613940097};\\\", \\\"{x:501,y:808,t:1527613940113};\\\", \\\"{x:505,y:809,t:1527613940129};\\\", \\\"{x:513,y:812,t:1527613940146};\\\", \\\"{x:517,y:812,t:1527613940162};\\\", \\\"{x:518,y:811,t:1527613940180};\\\", \\\"{x:519,y:811,t:1527613940197};\\\", \\\"{x:521,y:810,t:1527613940219};\\\", \\\"{x:523,y:809,t:1527613940229};\\\", \\\"{x:533,y:805,t:1527613940246};\\\", \\\"{x:536,y:804,t:1527613940264};\\\", \\\"{x:536,y:803,t:1527613940280};\\\", \\\"{x:538,y:802,t:1527613941187};\\\", \\\"{x:539,y:801,t:1527613941198};\\\", \\\"{x:542,y:800,t:1527613941214};\\\", \\\"{x:543,y:798,t:1527613941259};\\\", \\\"{x:545,y:797,t:1527613941274};\\\", \\\"{x:546,y:795,t:1527613941291};\\\", \\\"{x:547,y:794,t:1527613941307};\\\", \\\"{x:547,y:793,t:1527613941459};\\\", \\\"{x:549,y:793,t:1527613941467};\\\", \\\"{x:553,y:791,t:1527613941481};\\\", \\\"{x:557,y:788,t:1527613941498};\\\", \\\"{x:565,y:781,t:1527613941515};\\\", \\\"{x:570,y:777,t:1527613941531};\\\", \\\"{x:572,y:775,t:1527613941548};\\\", \\\"{x:574,y:774,t:1527613941565};\\\", \\\"{x:574,y:772,t:1527613941587};\\\", \\\"{x:575,y:771,t:1527613941602};\\\", \\\"{x:578,y:767,t:1527613941615};\\\", \\\"{x:579,y:765,t:1527613941631};\\\", \\\"{x:580,y:764,t:1527613941648};\\\", \\\"{x:581,y:763,t:1527613941665};\\\", \\\"{x:582,y:761,t:1527613941681};\\\", \\\"{x:583,y:760,t:1527613941698};\\\", \\\"{x:584,y:760,t:1527613942276};\\\", \\\"{x:575,y:761,t:1527613943283};\\\", \\\"{x:565,y:760,t:1527613943299};\\\", \\\"{x:546,y:762,t:1527613943317};\\\", \\\"{x:536,y:764,t:1527613943333};\\\", \\\"{x:532,y:765,t:1527613943348};\\\", \\\"{x:531,y:766,t:1527613943365};\\\", \\\"{x:530,y:762,t:1527613943427};\\\", \\\"{x:530,y:758,t:1527613943434};\\\", \\\"{x:529,y:756,t:1527613943448};\\\", \\\"{x:529,y:755,t:1527613943466};\\\", \\\"{x:528,y:753,t:1527613943482};\\\", \\\"{x:528,y:752,t:1527613943659};\\\", \\\"{x:527,y:752,t:1527613943699};\\\", \\\"{x:526,y:752,t:1527613943716};\\\", \\\"{x:525,y:752,t:1527613943747};\\\", \\\"{x:525,y:753,t:1527613943827};\\\", \\\"{x:525,y:754,t:1527613945410};\\\", \\\"{x:525,y:755,t:1527613946011};\\\" ] }, { \\\"rt\\\": 15863, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 20, \\\"time_elapsed\\\": 636477, \\\"internal_node_id\\\": \\\"0.0-7.0-0.0\\\", \\\"subject\\\": \\\"AZKMW\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"oscar\\\", \\\"condition\\\": \\\"114\\\", \\\"q\\\": 16, \\\"answer\\\": \\\"Looking at the x axis and the y axis. \\\", \\\"block\\\": \\\"triangular_testing\\\" }, { \\\"rt\\\": 12217, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"26\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"Philippines\\\\\\\"}\\\", \\\"block\\\": \\\"demo-1\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 21, \\\"time_elapsed\\\": 649699, \\\"internal_node_id\\\": \\\"0.0-8.0\\\", \\\"subject\\\": \\\"AZKMW\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"oscar\\\", \\\"condition\\\": \\\"114\\\" }, { \\\"rt\\\": 15476, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"Other\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"Fourth\\\\\\\",\\\\\\\"Q2\\\\\\\":\\\\\\\"Social Sciences (incl. CogSci)\\\\\\\",\\\\\\\"Q3\\\\\\\":\\\\\\\"Male\\\\\\\"}\\\", \\\"block\\\": \\\"demo-2\\\", \\\"trial_type\\\": \\\"survey-multi-choice\\\", \\\"trial_index\\\": 22, \\\"time_elapsed\\\": 666193, \\\"internal_node_id\\\": \\\"0.0-9.0\\\", \\\"subject\\\": \\\"AZKMW\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"oscar\\\", \\\"condition\\\": \\\"114\\\" }, { \\\"rt\\\": 2563, \\\"url\\\": \\\"../views/src/external/debrief.html\\\", \\\"block\\\": \\\"debrief\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 23, \\\"time_elapsed\\\": 669846, \\\"internal_node_id\\\": \\\"0.0-10.0\\\", \\\"subject\\\": \\\"AZKMW\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"oscar\\\", \\\"condition\\\": \\\"114\\\" } ]\",\"parentNode\":{\"id\":2765}}],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"META\",\"attributes\":{\"charset\":\"utf-8\"}},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":8,\"id\":59},{\"nodeType\":3,\"id\":60,\"textContent\":\" \"},{\"nodeType\":1,\"id\":61,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":62,\"textContent\":\" \"},{\"nodeType\":1,\"id\":63,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":64,\"textContent\":\" \"},{\"nodeType\":1,\"id\":65,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":66,\"textContent\":\" \"},{\"nodeType\":1,\"id\":67,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":68,\"textContent\":\" \"},{\"nodeType\":1,\"id\":69,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":70,\"textContent\":\" \"},{\"nodeType\":1,\"id\":71,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":72,\"textContent\":\" \"},{\"nodeType\":1,\"id\":73,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"stimulus\"},\"childNodes\":[{\"nodeType\":3,\"id\":74,\"textContent\":\" \"},{\"nodeType\":1,\"id\":75,\"tagName\":\"P\",\"attributes\":{\"class\":\"userid\",\"id\":\"userid\"},\"childNodes\":[{\"nodeType\":3,\"id\":76,\"textContent\":\"AZKMW\"}]},{\"nodeType\":3,\"id\":77,\"textContent\":\" \"},{\"nodeType\":1,\"id\":78,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"userinput\"},\"childNodes\":[{\"nodeType\":3,\"id\":79,\"textContent\":\" \"},{\"nodeType\":8,\"id\":80},{\"nodeType\":3,\"id\":81,\"textContent\":\" \"},{\"nodeType\":1,\"id\":82,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"legend\",\"id\":\"hint-interactive\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":83,\"textContent\":\" \"},{\"nodeType\":1,\"id\":84,\"tagName\":\"P\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":85,\"textContent\":\"Hint: Hover your mouse over the data points in the graph\"}]},{\"nodeType\":3,\"id\":86,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":87,\"textContent\":\" \"},{\"nodeType\":8,\"id\":88},{\"nodeType\":3,\"id\":89,\"textContent\":\" \"},{\"nodeType\":8,\"id\":90},{\"nodeType\":3,\"id\":91,\"textContent\":\" \"},{\"nodeType\":1,\"id\":92,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"test\"},\"childNodes\":[{\"nodeType\":3,\"id\":93,\"textContent\":\" \"},{\"nodeType\":1,\"id\":94,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":95,\"textContent\":\" \"},{\"nodeType\":1,\"id\":96,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":97,\"textContent\":\"Which shift(s) start at 11 am? \"}]},{\"nodeType\":3,\"id\":98,\"textContent\":\" \"},{\"nodeType\":1,\"id\":99,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":100,\"textContent\":\" \"},{\"nodeType\":1,\"id\":101,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":102,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":103,\"textContent\":\" \"},{\"nodeType\":1,\"id\":104,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":105,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":106,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":107,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":108,\"textContent\":\" \"},{\"nodeType\":1,\"id\":109,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":110,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":111,\"textContent\":\" \"},{\"nodeType\":1,\"id\":112,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":113,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":115,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":116,\"textContent\":\" \"},{\"nodeType\":1,\"id\":117,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":118,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":120,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":121,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":122,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":123,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":125,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":126,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":127,\"textContent\":\" \"},{\"nodeType\":1,\"id\":128,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":129,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":130,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":132,\"textContent\":\" \"},{\"nodeType\":1,\"id\":133,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":134,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":135,\"textContent\":\" \"},{\"nodeType\":1,\"id\":136,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":137,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":138,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":140,\"textContent\":\" \"},{\"nodeType\":1,\"id\":141,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":142,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":143,\"textContent\":\" \"},{\"nodeType\":1,\"id\":144,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":145,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":146,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":147,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":148,\"textContent\":\" \"},{\"nodeType\":1,\"id\":149,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":150,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":151,\"textContent\":\" \"},{\"nodeType\":1,\"id\":152,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":153,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":154,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":156,\"textContent\":\" \"},{\"nodeType\":1,\"id\":157,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":158,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":159,\"textContent\":\" \"},{\"nodeType\":1,\"id\":160,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":161,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":162,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":163,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":164,\"textContent\":\" \"},{\"nodeType\":1,\"id\":165,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":166,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":167,\"textContent\":\" \"},{\"nodeType\":1,\"id\":168,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":169,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":170,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":171,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":172,\"textContent\":\" \"},{\"nodeType\":1,\"id\":173,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":174,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":175,\"textContent\":\" \"},{\"nodeType\":1,\"id\":176,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":177,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":178,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":179,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":180,\"textContent\":\" \"},{\"nodeType\":1,\"id\":181,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":182,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":183,\"textContent\":\" \"},{\"nodeType\":1,\"id\":184,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":185,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":186,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":187,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":188,\"textContent\":\" \"},{\"nodeType\":1,\"id\":189,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":190,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":191,\"textContent\":\" \"},{\"nodeType\":1,\"id\":192,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":193,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":194,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":196,\"textContent\":\" \"},{\"nodeType\":1,\"id\":197,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":198,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":200,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":201,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":202,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":203,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":205,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":206,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":207,\"textContent\":\" \"},{\"nodeType\":1,\"id\":208,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":209,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":210,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":211,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":212,\"textContent\":\" \"},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":214,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":215,\"textContent\":\" \"},{\"nodeType\":1,\"id\":216,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":217,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":218,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":219,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":220,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":221,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":223,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":224,\"textContent\":\" \"},{\"nodeType\":1,\"id\":225,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":226,\"textContent\":\"Which shift(s) start at the same time as D?\"}]},{\"nodeType\":3,\"id\":227,\"textContent\":\" \"},{\"nodeType\":1,\"id\":228,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":229,\"textContent\":\" \"},{\"nodeType\":1,\"id\":230,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":231,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":232,\"textContent\":\" \"},{\"nodeType\":1,\"id\":233,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":234,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":235,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":236,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":237,\"textContent\":\" \"},{\"nodeType\":1,\"id\":238,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":239,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":240,\"textContent\":\" \"},{\"nodeType\":1,\"id\":241,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":242,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":243,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":244,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":245,\"textContent\":\" \"},{\"nodeType\":1,\"id\":246,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":247,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":248,\"textContent\":\" \"},{\"nodeType\":1,\"id\":249,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":250,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":251,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":252,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":253,\"textContent\":\" \"},{\"nodeType\":1,\"id\":254,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":255,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":256,\"textContent\":\" \"},{\"nodeType\":1,\"id\":257,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":258,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":259,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":260,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":261,\"textContent\":\" \"},{\"nodeType\":1,\"id\":262,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":263,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":264,\"textContent\":\" \"},{\"nodeType\":1,\"id\":265,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":266,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":267,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":268,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":269,\"textContent\":\" \"},{\"nodeType\":1,\"id\":270,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":271,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":273,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":274,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":275,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":276,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":278,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":279,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":280,\"textContent\":\" \"},{\"nodeType\":1,\"id\":281,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":282,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":283,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":284,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":286,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":287,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":288,\"textContent\":\" \"},{\"nodeType\":1,\"id\":289,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":290,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":291,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":292,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":293,\"textContent\":\" \"},{\"nodeType\":1,\"id\":294,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":295,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":296,\"textContent\":\" \"},{\"nodeType\":1,\"id\":297,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":298,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":299,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":300,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":301,\"textContent\":\" \"},{\"nodeType\":1,\"id\":302,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":303,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":304,\"textContent\":\" \"},{\"nodeType\":1,\"id\":305,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":306,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":307,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":308,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":309,\"textContent\":\" \"},{\"nodeType\":1,\"id\":310,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":311,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":312,\"textContent\":\" \"},{\"nodeType\":1,\"id\":313,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":314,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":315,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":316,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":317,\"textContent\":\" \"},{\"nodeType\":1,\"id\":318,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":319,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":320,\"textContent\":\" \"},{\"nodeType\":1,\"id\":321,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":322,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":323,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":324,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":325,\"textContent\":\" \"},{\"nodeType\":1,\"id\":326,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":327,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":328,\"textContent\":\" \"},{\"nodeType\":1,\"id\":329,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":330,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":331,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":332,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":333,\"textContent\":\" \"},{\"nodeType\":1,\"id\":334,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":335,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":336,\"textContent\":\" \"},{\"nodeType\":1,\"id\":337,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":338,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":339,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":340,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":341,\"textContent\":\" \"},{\"nodeType\":1,\"id\":342,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":343,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":344,\"textContent\":\" \"},{\"nodeType\":1,\"id\":345,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":346,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":347,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":348,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":349,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":351,\"textContent\":\" \"},{\"nodeType\":1,\"id\":352,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":353,\"textContent\":\" \"},{\"nodeType\":1,\"id\":354,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":355,\"textContent\":\"Which shift(s) begin when C ends?\"}]},{\"nodeType\":3,\"id\":356,\"textContent\":\" \"},{\"nodeType\":1,\"id\":357,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":358,\"textContent\":\" \"},{\"nodeType\":1,\"id\":359,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":360,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":361,\"textContent\":\" \"},{\"nodeType\":1,\"id\":362,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":363,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":364,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":365,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":366,\"textContent\":\" \"},{\"nodeType\":1,\"id\":367,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":368,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":369,\"textContent\":\" \"},{\"nodeType\":1,\"id\":370,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":371,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":372,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":373,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":374,\"textContent\":\" \"},{\"nodeType\":1,\"id\":375,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":376,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":377,\"textContent\":\" \"},{\"nodeType\":1,\"id\":378,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":379,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":380,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":381,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":382,\"textContent\":\" \"},{\"nodeType\":1,\"id\":383,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":384,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":385,\"textContent\":\" \"},{\"nodeType\":1,\"id\":386,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":387,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":388,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":389,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":390,\"textContent\":\" \"},{\"nodeType\":1,\"id\":391,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":392,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":393,\"textContent\":\" \"},{\"nodeType\":1,\"id\":394,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":395,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":396,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":397,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":398,\"textContent\":\" \"},{\"nodeType\":1,\"id\":399,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":400,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":401,\"textContent\":\" \"},{\"nodeType\":1,\"id\":402,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":403,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":404,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":405,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":406,\"textContent\":\" \"},{\"nodeType\":1,\"id\":407,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":408,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":409,\"textContent\":\" \"},{\"nodeType\":1,\"id\":410,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":411,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":412,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":413,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":414,\"textContent\":\" \"},{\"nodeType\":1,\"id\":415,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":416,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":417,\"textContent\":\" \"},{\"nodeType\":1,\"id\":418,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":419,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":420,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":421,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":422,\"textContent\":\" \"},{\"nodeType\":1,\"id\":423,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":424,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":425,\"textContent\":\" \"},{\"nodeType\":1,\"id\":426,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":427,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":428,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":429,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":430,\"textContent\":\" \"},{\"nodeType\":1,\"id\":431,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":432,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":433,\"textContent\":\" \"},{\"nodeType\":1,\"id\":434,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":435,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":436,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":437,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":438,\"textContent\":\" \"},{\"nodeType\":1,\"id\":439,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":440,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":441,\"textContent\":\" \"},{\"nodeType\":1,\"id\":442,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":443,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":444,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":445,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":446,\"textContent\":\" \"},{\"nodeType\":1,\"id\":447,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":448,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":449,\"textContent\":\" \"},{\"nodeType\":1,\"id\":450,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":451,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":452,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":453,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":454,\"textContent\":\" \"},{\"nodeType\":1,\"id\":455,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":456,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":457,\"textContent\":\" \"},{\"nodeType\":1,\"id\":458,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":459,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":460,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":461,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":462,\"textContent\":\" \"},{\"nodeType\":1,\"id\":463,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":464,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":465,\"textContent\":\" \"},{\"nodeType\":1,\"id\":466,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":467,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":468,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":469,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":470,\"textContent\":\" \"},{\"nodeType\":1,\"id\":471,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":472,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":473,\"textContent\":\" \"},{\"nodeType\":1,\"id\":474,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":475,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":476,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":477,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":478,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":479,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":480,\"textContent\":\" \"},{\"nodeType\":1,\"id\":481,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":483,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":484,\"textContent\":\" Which shift(s) end at 4 pm?\"}]},{\"nodeType\":3,\"id\":485,\"textContent\":\" \"},{\"nodeType\":1,\"id\":486,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":492,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":500,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":503,\"textContent\":\" \"},{\"nodeType\":1,\"id\":504,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":505,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":506,\"textContent\":\" \"},{\"nodeType\":1,\"id\":507,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":508,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":509,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":510,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":511,\"textContent\":\" \"},{\"nodeType\":1,\"id\":512,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":513,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":514,\"textContent\":\" \"},{\"nodeType\":1,\"id\":515,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":516,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":517,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":518,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":519,\"textContent\":\" \"},{\"nodeType\":1,\"id\":520,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":521,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":522,\"textContent\":\" \"},{\"nodeType\":1,\"id\":523,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":524,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":525,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":526,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":527,\"textContent\":\" \"},{\"nodeType\":1,\"id\":528,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":529,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":530,\"textContent\":\" \"},{\"nodeType\":1,\"id\":531,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":532,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":533,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":534,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":535,\"textContent\":\" \"},{\"nodeType\":1,\"id\":536,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":537,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":538,\"textContent\":\" \"},{\"nodeType\":1,\"id\":539,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":540,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":541,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":542,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":543,\"textContent\":\" \"},{\"nodeType\":1,\"id\":544,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":545,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":546,\"textContent\":\" \"},{\"nodeType\":1,\"id\":547,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":548,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":549,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":550,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":551,\"textContent\":\" \"},{\"nodeType\":1,\"id\":552,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":553,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":554,\"textContent\":\" \"},{\"nodeType\":1,\"id\":555,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":556,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":557,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":558,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":559,\"textContent\":\" \"},{\"nodeType\":1,\"id\":560,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":561,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":562,\"textContent\":\" \"},{\"nodeType\":1,\"id\":563,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":564,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":565,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":566,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":567,\"textContent\":\" \"},{\"nodeType\":1,\"id\":568,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":569,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":570,\"textContent\":\" \"},{\"nodeType\":1,\"id\":571,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":572,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":573,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":574,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":575,\"textContent\":\" \"},{\"nodeType\":1,\"id\":576,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":577,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":578,\"textContent\":\" \"},{\"nodeType\":1,\"id\":579,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":580,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":581,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":582,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":583,\"textContent\":\" \"},{\"nodeType\":1,\"id\":584,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":585,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":586,\"textContent\":\" \"},{\"nodeType\":1,\"id\":587,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":588,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":589,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":590,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":592,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":593,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":594,\"textContent\":\" \"},{\"nodeType\":1,\"id\":595,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":596,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":597,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":598,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":599,\"textContent\":\" \"},{\"nodeType\":1,\"id\":600,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":601,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":602,\"textContent\":\" \"},{\"nodeType\":1,\"id\":603,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":604,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":605,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":606,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":607,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":608,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":609,\"textContent\":\" \"},{\"nodeType\":1,\"id\":610,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":612,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":613,\"textContent\":\"Coffee breaks happen halfway through a shift.\"},{\"nodeType\":1,\"id\":614,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":615,\"textContent\":\" Which shift(s) share a break with I?\"}]},{\"nodeType\":3,\"id\":616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":617,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":618,\"textContent\":\" \"},{\"nodeType\":1,\"id\":619,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":620,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":621,\"textContent\":\" \"},{\"nodeType\":1,\"id\":622,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":623,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":624,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":625,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":626,\"textContent\":\" \"},{\"nodeType\":1,\"id\":627,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":628,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":629,\"textContent\":\" \"},{\"nodeType\":1,\"id\":630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":631,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":632,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":633,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":634,\"textContent\":\" \"},{\"nodeType\":1,\"id\":635,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":636,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":637,\"textContent\":\" \"},{\"nodeType\":1,\"id\":638,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":639,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":640,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":641,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":642,\"textContent\":\" \"},{\"nodeType\":1,\"id\":643,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":644,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":645,\"textContent\":\" \"},{\"nodeType\":1,\"id\":646,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":647,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":648,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":649,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":650,\"textContent\":\" \"},{\"nodeType\":1,\"id\":651,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":653,\"textContent\":\" \"},{\"nodeType\":1,\"id\":654,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":655,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":656,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":657,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":659,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":660,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":661,\"textContent\":\" \"},{\"nodeType\":1,\"id\":662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":663,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":664,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":665,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":666,\"textContent\":\" \"},{\"nodeType\":1,\"id\":667,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":668,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":669,\"textContent\":\" \"},{\"nodeType\":1,\"id\":670,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":671,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":672,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":673,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":674,\"textContent\":\" \"},{\"nodeType\":1,\"id\":675,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":676,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":677,\"textContent\":\" \"},{\"nodeType\":1,\"id\":678,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":679,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":680,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":681,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":682,\"textContent\":\" \"},{\"nodeType\":1,\"id\":683,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":685,\"textContent\":\" \"},{\"nodeType\":1,\"id\":686,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":687,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":688,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":689,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":690,\"textContent\":\" \"},{\"nodeType\":1,\"id\":691,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":692,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":693,\"textContent\":\" \"},{\"nodeType\":1,\"id\":694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":695,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":696,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":697,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":698,\"textContent\":\" \"},{\"nodeType\":1,\"id\":699,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":700,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":701,\"textContent\":\" \"},{\"nodeType\":1,\"id\":702,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":703,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":704,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":705,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":706,\"textContent\":\" \"},{\"nodeType\":1,\"id\":707,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":708,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":709,\"textContent\":\" \"},{\"nodeType\":1,\"id\":710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":711,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":712,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":713,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":714,\"textContent\":\" \"},{\"nodeType\":1,\"id\":715,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":716,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":717,\"textContent\":\" \"},{\"nodeType\":1,\"id\":718,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":719,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":720,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":721,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":722,\"textContent\":\" \"},{\"nodeType\":1,\"id\":723,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":724,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":725,\"textContent\":\" \"},{\"nodeType\":1,\"id\":726,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":727,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":728,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":729,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":730,\"textContent\":\" \"},{\"nodeType\":1,\"id\":731,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":732,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":733,\"textContent\":\" \"},{\"nodeType\":1,\"id\":734,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":735,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":736,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":737,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":738,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":739,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":741,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":742,\"textContent\":\" \"},{\"nodeType\":1,\"id\":743,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":744,\"textContent\":\"Which shift(s) are six hours long?\"}]},{\"nodeType\":3,\"id\":745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":746,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":747,\"textContent\":\" \"},{\"nodeType\":1,\"id\":748,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":749,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":750,\"textContent\":\" \"},{\"nodeType\":1,\"id\":751,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":752,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":753,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":754,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":755,\"textContent\":\" \"},{\"nodeType\":1,\"id\":756,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":757,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":758,\"textContent\":\" \"},{\"nodeType\":1,\"id\":759,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":760,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":761,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":762,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":763,\"textContent\":\" \"},{\"nodeType\":1,\"id\":764,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":765,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":766,\"textContent\":\" \"},{\"nodeType\":1,\"id\":767,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":768,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":769,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":770,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":771,\"textContent\":\" \"},{\"nodeType\":1,\"id\":772,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":773,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":774,\"textContent\":\" \"},{\"nodeType\":1,\"id\":775,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":776,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":777,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":778,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":779,\"textContent\":\" \"},{\"nodeType\":1,\"id\":780,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":781,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":782,\"textContent\":\" \"},{\"nodeType\":1,\"id\":783,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":784,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":785,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":786,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":787,\"textContent\":\" \"},{\"nodeType\":1,\"id\":788,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":789,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":790,\"textContent\":\" \"},{\"nodeType\":1,\"id\":791,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":792,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":793,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":794,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":795,\"textContent\":\" \"},{\"nodeType\":1,\"id\":796,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":797,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":798,\"textContent\":\" \"},{\"nodeType\":1,\"id\":799,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":800,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":801,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":802,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":803,\"textContent\":\" \"},{\"nodeType\":1,\"id\":804,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":805,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":806,\"textContent\":\" \"},{\"nodeType\":1,\"id\":807,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":808,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":809,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":810,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":812,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":813,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":814,\"textContent\":\" \"},{\"nodeType\":1,\"id\":815,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":816,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":817,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":818,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":819,\"textContent\":\" \"},{\"nodeType\":1,\"id\":820,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":821,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":822,\"textContent\":\" \"},{\"nodeType\":1,\"id\":823,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":824,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":825,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":826,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":827,\"textContent\":\" \"},{\"nodeType\":1,\"id\":828,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":829,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":830,\"textContent\":\" \"},{\"nodeType\":1,\"id\":831,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":832,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":833,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":834,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":835,\"textContent\":\" \"},{\"nodeType\":1,\"id\":836,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":837,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":838,\"textContent\":\" \"},{\"nodeType\":1,\"id\":839,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":840,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":841,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":842,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":843,\"textContent\":\" \"},{\"nodeType\":1,\"id\":844,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":845,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":846,\"textContent\":\" \"},{\"nodeType\":1,\"id\":847,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":848,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":849,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":850,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":851,\"textContent\":\" \"},{\"nodeType\":1,\"id\":852,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":853,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":854,\"textContent\":\" \"},{\"nodeType\":1,\"id\":855,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":856,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":857,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":858,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":859,\"textContent\":\" \"},{\"nodeType\":1,\"id\":860,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":861,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":862,\"textContent\":\" \"},{\"nodeType\":1,\"id\":863,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":864,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":865,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":866,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":867,\"textContent\":\" \"},{\"nodeType\":1,\"id\":868,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":869,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":870,\"textContent\":\" \"},{\"nodeType\":1,\"id\":871,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":872,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":873,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":874,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":875,\"textContent\":\" \"},{\"nodeType\":1,\"id\":876,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":877,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":878,\"textContent\":\" \"},{\"nodeType\":1,\"id\":879,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":880,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":881,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":882,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":883,\"textContent\":\" \"},{\"nodeType\":1,\"id\":884,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":885,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":886,\"textContent\":\" \"},{\"nodeType\":1,\"id\":887,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":888,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":889,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":890,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":891,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":892,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":894,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":895,\"textContent\":\" \"},{\"nodeType\":1,\"id\":896,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":897,\"textContent\":\"Which 2 shifts less than 5 hours long start at the same time?\"}]},{\"nodeType\":3,\"id\":898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":899,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":900,\"textContent\":\" \"},{\"nodeType\":1,\"id\":901,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":902,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":903,\"textContent\":\" \"},{\"nodeType\":1,\"id\":904,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":905,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":906,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":907,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":908,\"textContent\":\" \"},{\"nodeType\":1,\"id\":909,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":910,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":911,\"textContent\":\" \"},{\"nodeType\":1,\"id\":912,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":913,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":914,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":915,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":916,\"textContent\":\" \"},{\"nodeType\":1,\"id\":917,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":918,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":919,\"textContent\":\" \"},{\"nodeType\":1,\"id\":920,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":921,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":922,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":923,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":924,\"textContent\":\" \"},{\"nodeType\":1,\"id\":925,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":926,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":927,\"textContent\":\" \"},{\"nodeType\":1,\"id\":928,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":929,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":930,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":931,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":932,\"textContent\":\" \"},{\"nodeType\":1,\"id\":933,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":934,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":935,\"textContent\":\" \"},{\"nodeType\":1,\"id\":936,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":937,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":938,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":939,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":940,\"textContent\":\" \"},{\"nodeType\":1,\"id\":941,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":942,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":943,\"textContent\":\" \"},{\"nodeType\":1,\"id\":944,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":945,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":946,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":947,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":948,\"textContent\":\" \"},{\"nodeType\":1,\"id\":949,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":950,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":951,\"textContent\":\" \"},{\"nodeType\":1,\"id\":952,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":953,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":954,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":955,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":956,\"textContent\":\" \"},{\"nodeType\":1,\"id\":957,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":958,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":959,\"textContent\":\" \"},{\"nodeType\":1,\"id\":960,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":961,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":962,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":963,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":965,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":966,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":967,\"textContent\":\" \"},{\"nodeType\":1,\"id\":968,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":969,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":970,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":971,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":972,\"textContent\":\" \"},{\"nodeType\":1,\"id\":973,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":974,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":975,\"textContent\":\" \"},{\"nodeType\":1,\"id\":976,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":977,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":978,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":979,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":980,\"textContent\":\" \"},{\"nodeType\":1,\"id\":981,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":982,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":983,\"textContent\":\" \"},{\"nodeType\":1,\"id\":984,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":985,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":986,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":987,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":988,\"textContent\":\" \"},{\"nodeType\":1,\"id\":989,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":990,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":991,\"textContent\":\" \"},{\"nodeType\":1,\"id\":992,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":993,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":994,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":995,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":996,\"textContent\":\" \"},{\"nodeType\":1,\"id\":997,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":998,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":999,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1000,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1001,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1002,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1003,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1004,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1005,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1006,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1007,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1008,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1009,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1010,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1011,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1012,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1013,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1014,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1015,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1016,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1017,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1018,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1019,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1020,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1021,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1022,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1023,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1024,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1025,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1026,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1027,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1028,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1029,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1030,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1031,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1032,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1033,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1034,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1035,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1036,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1037,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1038,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1039,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1040,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1041,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1042,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1043,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1044,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1045,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1047,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+contained\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1048,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1049,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1050,\"textContent\":\"Which shift(s) under 7 hours long starts before B starts, and ends after X ends?\"}]},{\"nodeType\":3,\"id\":1051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1052,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1053,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1054,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1055,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1056,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1057,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1058,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1059,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1060,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1061,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1062,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1063,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1064,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1065,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1066,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1067,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1068,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1069,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1070,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1071,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1072,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1073,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1074,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1075,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1076,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1077,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1078,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1079,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1080,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1081,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1082,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1083,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1084,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1085,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1086,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1087,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1088,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1089,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1090,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1091,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1092,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1093,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1094,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1095,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1096,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1097,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1098,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1099,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1100,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1101,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1102,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1103,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1104,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1105,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1106,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1107,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1108,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1109,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1110,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1111,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1112,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1113,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1114,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1115,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1116,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1118,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1119,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1120,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1121,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1122,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1123,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1124,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1125,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1126,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1127,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1128,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1129,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1130,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1131,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1132,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1133,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1134,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1135,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1136,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1137,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1138,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1139,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1140,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1141,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1142,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1143,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1144,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1145,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1146,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1147,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1148,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1149,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1150,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1151,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1152,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1153,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1154,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1155,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1156,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1157,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1158,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1159,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1160,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1161,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1162,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1163,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1164,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1165,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1166,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1167,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1168,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1169,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1170,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1171,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1172,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1173,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1174,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1175,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1176,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1177,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1178,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1179,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1180,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1181,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1182,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1183,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1184,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1185,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1186,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1187,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1188,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1189,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1190,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1191,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1192,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1193,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1194,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1195,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1196,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1197,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1198,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1200,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime+before+endtime+during\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1202,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1203,\"textContent\":\"Which shift(s) begins before J begins and ends during B?\"}]},{\"nodeType\":3,\"id\":1204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1205,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1211,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1219,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1227,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1235,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1243,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1251,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1259,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1267,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1270,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1271,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1272,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1273,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1274,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1275,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1276,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1277,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1278,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1279,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1280,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1281,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1282,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1283,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1284,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1285,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1286,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1287,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1288,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1289,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1290,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1291,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1292,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1293,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1294,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1295,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1296,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1298,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1299,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1300,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1301,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1302,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1303,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1304,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1305,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1306,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1307,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1308,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1309,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1310,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1311,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1312,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1313,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1314,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1315,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1316,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1317,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1318,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1319,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1320,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1321,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1322,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1323,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1324,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1325,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1326,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1327,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1328,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1329,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1330,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1331,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1332,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1333,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1334,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1335,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1336,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1337,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1338,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1339,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1340,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1341,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1342,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1343,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1344,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1345,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1346,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1347,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1348,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1349,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1351,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1352,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1353,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.ends\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1354,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1355,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1356,\"textContent\":\"Which shift(s) end at the same time as F?\"}]},{\"nodeType\":3,\"id\":1357,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1358,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1359,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1360,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1361,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1362,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1363,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1364,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1365,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1366,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1367,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1368,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1369,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1370,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1371,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1372,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1373,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1374,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1375,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1376,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1377,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1378,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1379,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1380,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1381,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1382,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1383,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1384,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1385,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1386,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1387,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1388,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1389,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1390,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1391,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1392,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1393,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1394,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1395,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1396,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1397,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1398,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1399,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1400,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1401,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1402,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1403,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1404,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1405,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1406,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1407,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1408,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1409,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1410,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1411,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1412,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1413,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1414,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1415,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1416,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1417,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1418,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1419,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1420,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1421,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1422,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1423,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1424,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1425,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1426,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1427,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1428,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1429,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1430,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1431,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1432,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1433,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1434,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1435,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1436,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1437,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1438,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1439,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1440,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1441,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1442,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1443,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1444,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1445,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1446,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1447,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1448,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1449,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1450,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1451,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1452,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1453,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1454,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1455,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1456,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1457,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1458,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1459,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1460,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1461,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1462,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1463,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1464,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1465,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1466,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1467,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1468,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1469,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1470,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1471,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1472,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1473,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1474,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1475,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1476,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1477,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1478,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1479,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1480,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1481,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1483,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1484,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1485,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1486,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1492,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1500,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1503,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1504,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1505,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1506,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1507,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1508,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1509,\"textContent\":\"Which shift(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":1510,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1511,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1512,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1513,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1514,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1515,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1516,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1517,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1518,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1519,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1520,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1521,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1522,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1523,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1524,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1525,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1526,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1527,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1528,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1529,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1530,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1531,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1532,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1533,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1534,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1535,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1536,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1537,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1538,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1539,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1540,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1541,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1542,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1543,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1544,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1545,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1546,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1547,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1548,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1549,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1550,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1551,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1552,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1553,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1554,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1555,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1556,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1557,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1558,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1559,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1560,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1561,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1562,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1563,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1564,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1565,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1566,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1567,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1568,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1569,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1570,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1571,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1572,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1573,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1574,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1575,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1576,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1577,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1578,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1579,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1580,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1581,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1582,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1583,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1584,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1585,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1586,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1587,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1588,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1589,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1590,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1591,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1592,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1593,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1594,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1595,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1596,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1597,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1598,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1599,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1600,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1601,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1602,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1603,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1604,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1605,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1606,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1607,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1608,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1609,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1610,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1612,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1613,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1614,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1615,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1617,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1618,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1619,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1620,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1621,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1622,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1623,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1624,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1625,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1627,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1628,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1629,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1630,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1631,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1632,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1633,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1634,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1635,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1636,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1637,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1638,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1639,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1640,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1641,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1642,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1643,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1644,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1645,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1646,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1647,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1648,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1649,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1650,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1651,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1652,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1653,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1654,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1655,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1656,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1657,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1659,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1660,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1661,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1662,\"textContent\":\"Which shift(s) start at the same time as F?\"}]},{\"nodeType\":3,\"id\":1663,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1664,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1665,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1666,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1667,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1668,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1669,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1670,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1671,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1672,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1673,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1674,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1675,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1676,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1677,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1678,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1679,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1680,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1681,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1682,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1683,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1684,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1686,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1687,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1688,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1689,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1690,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1691,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1692,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1693,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1694,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1695,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1696,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1697,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1698,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1699,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1700,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1701,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1702,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1703,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1704,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1705,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1706,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1707,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1708,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1709,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1710,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1711,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1712,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1713,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1714,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1715,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1716,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1717,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1718,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1720,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1721,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1722,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1723,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1724,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1725,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1726,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1727,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1728,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1729,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1730,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1731,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1732,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1733,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1734,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1735,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1736,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1737,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1738,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1739,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1741,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1742,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1743,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1744,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1746,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1747,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1748,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1749,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1750,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1751,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1752,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1753,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1754,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1755,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1756,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1757,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1758,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1759,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1760,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1761,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1762,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1763,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1764,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1765,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1766,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1767,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1768,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1769,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1770,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1771,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1772,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1773,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1774,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1775,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1776,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1777,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1778,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1779,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1780,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1781,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1782,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1783,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1784,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1785,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1786,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1787,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1788,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1789,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1790,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1791,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1792,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1793,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1794,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1795,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1796,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1797,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1798,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1799,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1800,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1801,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1802,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1803,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1804,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1805,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1806,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1807,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1808,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1809,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1810,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1812,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1813,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1814,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1815,\"textContent\":\"Which 2 shifts end when Z begins?\"}]},{\"nodeType\":3,\"id\":1816,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1817,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1818,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1819,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1820,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1821,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1822,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1823,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1824,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1825,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1826,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1827,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1828,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1829,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1830,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1831,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1832,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1833,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1834,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1835,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1836,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1837,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1838,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1839,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1840,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1841,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1842,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1843,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1844,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1845,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1846,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1847,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1848,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1849,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1850,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1851,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1852,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1853,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1854,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1855,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1856,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1857,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1858,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1859,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1860,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1861,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1862,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1863,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1864,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1865,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1866,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1867,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1868,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1869,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1870,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1871,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1872,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1873,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1874,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1875,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1876,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1877,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1878,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1879,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1880,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1881,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1882,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1883,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1884,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1885,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1886,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1887,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1888,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1889,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1890,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1891,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1892,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1894,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1895,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1896,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1897,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1899,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1900,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1901,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1902,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1903,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1904,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1905,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1906,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1907,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1908,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1909,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1910,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1911,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1912,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1913,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1914,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1915,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1916,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1917,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1918,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1919,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1920,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1921,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1922,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1923,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1924,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1925,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1926,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1927,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1928,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1929,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1930,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1931,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1932,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1933,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1934,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1935,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1936,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1937,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1938,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1939,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1940,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1941,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1942,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1943,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1944,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1945,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1946,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1947,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1948,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1949,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1950,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1951,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1952,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1953,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1954,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1955,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1956,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1957,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1958,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1959,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1960,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1961,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1962,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1963,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1965,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1966,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1967,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1968,\"textContent\":\"Which shift(s) end at 3pm?\"}]},{\"nodeType\":3,\"id\":1969,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1970,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1971,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1972,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1973,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1974,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1975,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1976,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1977,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1978,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1979,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1980,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1981,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1982,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1983,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1984,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1985,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1986,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1987,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1988,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1989,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1990,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1991,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1992,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1993,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1994,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1995,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1996,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1997,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1998,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1999,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2000,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2001,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2002,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2003,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2004,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2005,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2006,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2007,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2008,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2009,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2010,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2011,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2012,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2013,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2014,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2015,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2016,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2017,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2018,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2019,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2020,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2021,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2022,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2023,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2024,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2025,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2026,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2027,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2028,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2029,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2030,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2031,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2032,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2033,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2034,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2035,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2036,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2037,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2038,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2039,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2040,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2041,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2042,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2043,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2044,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2045,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2047,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2048,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2049,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2050,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2052,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2053,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2054,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2055,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2056,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2057,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2058,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2059,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2060,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2061,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2062,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2063,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2064,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2065,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2066,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2067,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2068,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2069,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2070,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2071,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2072,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2073,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2074,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2075,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2076,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2077,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2078,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2079,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2080,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2081,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2082,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2083,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2084,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2085,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2086,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2087,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2088,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2089,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2090,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2091,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2092,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2093,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2094,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2095,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2096,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2097,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2098,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2099,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2100,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2101,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2102,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2103,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2104,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2105,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2106,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2107,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2108,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2109,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2110,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2111,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2112,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2113,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2114,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2115,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2116,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2118,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":2119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2120,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2121,\"textContent\":\"Coffee breaks happen halfway through a shift. \"},{\"nodeType\":1,\"id\":2122,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":2123,\"textContent\":\"Which shifts share a break at 2pm?\"}]},{\"nodeType\":3,\"id\":2124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2125,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":2126,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2127,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2128,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2129,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2130,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2131,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":2132,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2133,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2134,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2135,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2136,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2137,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2138,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2139,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":2140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2141,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2142,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2143,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2144,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2145,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2146,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2147,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":2148,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2149,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2150,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2151,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2152,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2153,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2154,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2155,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2156,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2157,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2158,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2159,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2160,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2161,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2162,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2163,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2164,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2165,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2166,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2167,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2168,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2169,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2170,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2171,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2172,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2173,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2174,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2175,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2176,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2177,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2178,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2179,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2180,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2181,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2182,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2183,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2184,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2185,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2186,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2187,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2188,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2189,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2190,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2191,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2192,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2193,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2194,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2195,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2196,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2197,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2198,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2199,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2200,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2202,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2203,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2204,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2205,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2211,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2219,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2227,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2235,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2243,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2251,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2259,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2267,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2270,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2271,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2273,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\".strategy\",\"style\":\"display: block;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2274,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2275,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2276,\"textContent\":\"Please describe how to determine what event(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":2277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2278,\"tagName\":\"TEXTAREA\",\"attributes\":{\"id\":\"strategyAnswer\",\"rows\":\"5\",\"cols\":\"80\"}},{\"nodeType\":3,\"id\":2279,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2280,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2281,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2282},{\"nodeType\":3,\"id\":2283,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2284},{\"nodeType\":3,\"id\":2285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2286,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"fixbottom\"},\"childNodes\":[{\"nodeType\":3,\"id\":2287,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2288,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"testingButton\",\"style\":\"display:none;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2289,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2290,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2291,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"strategyButton\",\"style\":\"display: block;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2292,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2293,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2294,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2295,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2296},{\"nodeType\":3,\"id\":2297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2298,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"d3container\"},\"childNodes\":[{\"nodeType\":1,\"id\":2299,\"tagName\":\"svg\",\"attributes\":{\"width\":\"930\",\"height\":\"915\"},\"childNodes\":[{\"nodeType\":1,\"id\":2300,\"tagName\":\"g\",\"attributes\":{\"transform\":\"translate(100,25)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2301,\"tagName\":\"g\",\"attributes\":{\"class\":\"leaders\"}},{\"nodeType\":1,\"id\":2302,\"tagName\":\"g\",\"attributes\":{\"class\":\"static-scaffold\"}}]}]}]},{\"nodeType\":3,\"id\":2303,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2304,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2305},{\"nodeType\":3,\"id\":2306,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2307,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2308,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2309,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2310,\"textContent\":\" \"}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 190, dom: 855, initialDom: 931",
  "javascriptErrors": []
}