var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["052215190497b720a5ea6c2e6eafc673f72f8d1a"] = {
  "startTime": "2018-05-22T21:15:14.753982Z",
  "websitePageUrl": "/16",
  "visitTime": 213043,
  "engagementTime": 194200,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1094,
  "tags": [
    "form-interact",
    "submit"
  ],
  "session": {
    "id": "59e56292bace18bee31333644816686b",
    "created": "2018-05-22T21:15:14.753982+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.181",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/16",
    "tags": [
      "form-interact",
      "submit"
    ],
    "variables": [
      "SID=QOJ6L",
      "CONDITION=121"
    ],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "2edd71aae33e92764f232b676963a9de",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/59e56292bace18bee31333644816686b/play"
  },
  "events": [
    {
      "t": 1,
      "e": 1,
      "ty": 14,
      "x": 0,
      "y": 1093
    },
    {
      "t": 183,
      "e": 183,
      "ty": 0,
      "x": 1920,
      "y": 1094
    },
    {
      "t": 1102,
      "e": 1102,
      "ty": 2,
      "x": 423,
      "y": 647
    },
    {
      "t": 1132,
      "e": 1132,
      "ty": 6,
      "x": 394,
      "y": 632,
      "ta": "#strategyButton"
    },
    {
      "t": 1202,
      "e": 1202,
      "ty": 2,
      "x": 376,
      "y": 614
    },
    {
      "t": 1231,
      "e": 1231,
      "ty": 7,
      "x": 371,
      "y": 591,
      "ta": "#strategyButton"
    },
    {
      "t": 1252,
      "e": 1252,
      "ty": 41,
      "x": 23595,
      "y": 4761,
      "ta": "> div.stimulus > div > div:[3]"
    },
    {
      "t": 1282,
      "e": 1282,
      "ty": 6,
      "x": 369,
      "y": 547,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1301,
      "e": 1301,
      "ty": 2,
      "x": 369,
      "y": 537
    },
    {
      "t": 1402,
      "e": 1402,
      "ty": 2,
      "x": 372,
      "y": 519
    },
    {
      "t": 1501,
      "e": 1501,
      "ty": 2,
      "x": 373,
      "y": 517
    },
    {
      "t": 1502,
      "e": 1502,
      "ty": 41,
      "x": 31014,
      "y": 38241,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1531,
      "e": 1531,
      "ty": 3,
      "x": 373,
      "y": 517,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1531,
      "e": 1531,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1658,
      "e": 1658,
      "ty": 4,
      "x": 31014,
      "y": 38241,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1658,
      "e": 1658,
      "ty": 5,
      "x": 373,
      "y": 517,
      "ta": "#strategyAnswer"
    },
    {
      "t": 3002,
      "e": 3002,
      "ty": 2,
      "x": 391,
      "y": 517
    },
    {
      "t": 3002,
      "e": 3002,
      "ty": 41,
      "x": 33037,
      "y": 38241,
      "ta": "#strategyAnswer"
    },
    {
      "t": 3102,
      "e": 3102,
      "ty": 2,
      "x": 456,
      "y": 526
    },
    {
      "t": 3253,
      "e": 3253,
      "ty": 41,
      "x": 40344,
      "y": 45523,
      "ta": "#strategyAnswer"
    },
    {
      "t": 4202,
      "e": 4202,
      "ty": 2,
      "x": 605,
      "y": 529
    },
    {
      "t": 4234,
      "e": 4234,
      "ty": 7,
      "x": 691,
      "y": 532,
      "ta": "#strategyAnswer"
    },
    {
      "t": 4252,
      "e": 4252,
      "ty": 41,
      "x": 1027,
      "y": 31737,
      "ta": "> div.stimulus > div:[2]"
    },
    {
      "t": 4302,
      "e": 4302,
      "ty": 2,
      "x": 698,
      "y": 532
    },
    {
      "t": 5003,
      "e": 5003,
      "ty": 2,
      "x": 706,
      "y": 533
    },
    {
      "t": 5003,
      "e": 5003,
      "ty": 41,
      "x": 1486,
      "y": 31808,
      "ta": "> div.stimulus > div:[2]"
    },
    {
      "t": 5101,
      "e": 5101,
      "ty": 2,
      "x": 699,
      "y": 536
    },
    {
      "t": 5119,
      "e": 5119,
      "ty": 6,
      "x": 671,
      "y": 537,
      "ta": "#strategyAnswer"
    },
    {
      "t": 5201,
      "e": 5201,
      "ty": 2,
      "x": 605,
      "y": 518
    },
    {
      "t": 5252,
      "e": 5252,
      "ty": 41,
      "x": 56082,
      "y": 23678,
      "ta": "#strategyAnswer"
    },
    {
      "t": 5301,
      "e": 5301,
      "ty": 2,
      "x": 596,
      "y": 489
    },
    {
      "t": 5402,
      "e": 5402,
      "ty": 2,
      "x": 599,
      "y": 480
    },
    {
      "t": 5502,
      "e": 5502,
      "ty": 41,
      "x": 56419,
      "y": 8305,
      "ta": "#strategyAnswer"
    },
    {
      "t": 5702,
      "e": 5702,
      "ty": 2,
      "x": 612,
      "y": 491
    },
    {
      "t": 5752,
      "e": 5752,
      "ty": 41,
      "x": 64063,
      "y": 34196,
      "ta": "#strategyAnswer"
    },
    {
      "t": 5752,
      "e": 5752,
      "ty": 7,
      "x": 724,
      "y": 531,
      "ta": "#strategyAnswer"
    },
    {
      "t": 5801,
      "e": 5801,
      "ty": 2,
      "x": 893,
      "y": 555
    },
    {
      "t": 5901,
      "e": 5901,
      "ty": 2,
      "x": 1223,
      "y": 613
    },
    {
      "t": 6002,
      "e": 6002,
      "ty": 41,
      "x": 30795,
      "y": 37816,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 6301,
      "e": 6301,
      "ty": 2,
      "x": 1223,
      "y": 614
    },
    {
      "t": 6401,
      "e": 6401,
      "ty": 2,
      "x": 1223,
      "y": 615
    },
    {
      "t": 6501,
      "e": 6501,
      "ty": 41,
      "x": 30795,
      "y": 37960,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 6601,
      "e": 6601,
      "ty": 2,
      "x": 1231,
      "y": 615
    },
    {
      "t": 6701,
      "e": 6701,
      "ty": 2,
      "x": 1304,
      "y": 633
    },
    {
      "t": 6752,
      "e": 6752,
      "ty": 41,
      "x": 37771,
      "y": 40395,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 6801,
      "e": 6801,
      "ty": 2,
      "x": 1326,
      "y": 673
    },
    {
      "t": 6901,
      "e": 6901,
      "ty": 2,
      "x": 1320,
      "y": 734
    },
    {
      "t": 7001,
      "e": 7001,
      "ty": 2,
      "x": 1274,
      "y": 815
    },
    {
      "t": 7002,
      "e": 7002,
      "ty": 41,
      "x": 34389,
      "y": 52284,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 7101,
      "e": 7101,
      "ty": 2,
      "x": 1237,
      "y": 863
    },
    {
      "t": 7201,
      "e": 7201,
      "ty": 2,
      "x": 1199,
      "y": 885
    },
    {
      "t": 7252,
      "e": 7252,
      "ty": 41,
      "x": 29033,
      "y": 57584,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 7301,
      "e": 7301,
      "ty": 2,
      "x": 1193,
      "y": 892
    },
    {
      "t": 7401,
      "e": 7401,
      "ty": 2,
      "x": 1175,
      "y": 900
    },
    {
      "t": 7501,
      "e": 7501,
      "ty": 2,
      "x": 1167,
      "y": 905
    },
    {
      "t": 7502,
      "e": 7502,
      "ty": 41,
      "x": 26849,
      "y": 58730,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 7601,
      "e": 7601,
      "ty": 2,
      "x": 1164,
      "y": 909
    },
    {
      "t": 7701,
      "e": 7701,
      "ty": 2,
      "x": 1160,
      "y": 914
    },
    {
      "t": 7751,
      "e": 7751,
      "ty": 41,
      "x": 26144,
      "y": 59447,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 7801,
      "e": 7801,
      "ty": 2,
      "x": 1156,
      "y": 916
    },
    {
      "t": 7901,
      "e": 7901,
      "ty": 2,
      "x": 1152,
      "y": 914
    },
    {
      "t": 8001,
      "e": 8001,
      "ty": 2,
      "x": 1150,
      "y": 910
    },
    {
      "t": 8002,
      "e": 8002,
      "ty": 41,
      "x": 21586,
      "y": 0,
      "ta": "> div.stimulus > div:[2] > svg > g > g:[3] > path"
    },
    {
      "t": 10002,
      "e": 10002,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 11501,
      "e": 11501,
      "ty": 2,
      "x": 1155,
      "y": 911
    },
    {
      "t": 11502,
      "e": 11502,
      "ty": 41,
      "x": 21996,
      "y": 5957,
      "ta": "> div.stimulus > div:[2] > svg > g > g:[3] > path"
    },
    {
      "t": 12601,
      "e": 12601,
      "ty": 2,
      "x": 1154,
      "y": 907
    },
    {
      "t": 12701,
      "e": 12701,
      "ty": 2,
      "x": 1152,
      "y": 896
    },
    {
      "t": 12751,
      "e": 12751,
      "ty": 41,
      "x": 25651,
      "y": 57584,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 12801,
      "e": 12801,
      "ty": 2,
      "x": 1146,
      "y": 879
    },
    {
      "t": 13002,
      "e": 13002,
      "ty": 41,
      "x": 25369,
      "y": 56868,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 13251,
      "e": 13251,
      "ty": 41,
      "x": 24312,
      "y": 56653,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 13302,
      "e": 13302,
      "ty": 2,
      "x": 972,
      "y": 817
    },
    {
      "t": 13401,
      "e": 13401,
      "ty": 2,
      "x": 418,
      "y": 559
    },
    {
      "t": 13408,
      "e": 13408,
      "ty": 6,
      "x": 385,
      "y": 530,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13502,
      "e": 13502,
      "ty": 2,
      "x": 362,
      "y": 491
    },
    {
      "t": 13502,
      "e": 13502,
      "ty": 41,
      "x": 29778,
      "y": 17205,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13602,
      "e": 13602,
      "ty": 2,
      "x": 362,
      "y": 484
    },
    {
      "t": 13751,
      "e": 13751,
      "ty": 41,
      "x": 29778,
      "y": 11541,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14001,
      "e": 14001,
      "ty": 2,
      "x": 362,
      "y": 488
    },
    {
      "t": 14002,
      "e": 14002,
      "ty": 41,
      "x": 29778,
      "y": 14778,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14101,
      "e": 14101,
      "ty": 2,
      "x": 369,
      "y": 504
    },
    {
      "t": 14252,
      "e": 14252,
      "ty": 41,
      "x": 30564,
      "y": 27723,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14501,
      "e": 14501,
      "ty": 2,
      "x": 371,
      "y": 504
    },
    {
      "t": 14501,
      "e": 14501,
      "ty": 41,
      "x": 30789,
      "y": 27723,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20002,
      "e": 19501,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 20046,
      "e": 19501,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 20150,
      "e": 19605,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 20150,
      "e": 19605,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20238,
      "e": 19693,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "F"
    },
    {
      "t": 20246,
      "e": 19701,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "F"
    },
    {
      "t": 20278,
      "e": 19733,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 20278,
      "e": 19733,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20382,
      "e": 19837,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Fi"
    },
    {
      "t": 20606,
      "e": 20061,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 20607,
      "e": 20062,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20718,
      "e": 20173,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Fir"
    },
    {
      "t": 20719,
      "e": 20174,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 20720,
      "e": 20175,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20870,
      "e": 20325,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Firs"
    },
    {
      "t": 20894,
      "e": 20349,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 20894,
      "e": 20349,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21004,
      "e": 20459,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "First"
    },
    {
      "t": 21014,
      "e": 20469,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 21016,
      "e": 20471,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21049,
      "e": 20504,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t "
    },
    {
      "t": 21133,
      "e": 20588,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 22390,
      "e": 21845,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 22391,
      "e": 21846,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22470,
      "e": 21925,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||f"
    },
    {
      "t": 22526,
      "e": 21981,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 22527,
      "e": 21982,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22607,
      "e": 22062,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 22607,
      "e": 22062,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22637,
      "e": 22092,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||in"
    },
    {
      "t": 22694,
      "e": 22149,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 22694,
      "e": 22149,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22701,
      "e": 22156,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 22790,
      "e": 22245,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 22830,
      "e": 22285,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 22831,
      "e": 22286,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22886,
      "e": 22341,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 23002,
      "e": 22457,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "First find "
    },
    {
      "t": 24717,
      "e": 24172,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 24718,
      "e": 24173,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24789,
      "e": 24244,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||1"
    },
    {
      "t": 26007,
      "e": 25462,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 26117,
      "e": 25572,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "First find "
    },
    {
      "t": 26494,
      "e": 25949,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 26495,
      "e": 25950,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26581,
      "e": 26036,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 26581,
      "e": 26036,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26613,
      "e": 26068,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||th"
    },
    {
      "t": 26678,
      "e": 26133,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 26710,
      "e": 26165,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 26710,
      "e": 26165,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26830,
      "e": 26285,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 26831,
      "e": 26286,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26862,
      "e": 26317,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e "
    },
    {
      "t": 26966,
      "e": 26421,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 27679,
      "e": 27134,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 27679,
      "e": 27134,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27774,
      "e": 27229,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 27919,
      "e": 27374,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 27919,
      "e": 27374,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27997,
      "e": 27452,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 28142,
      "e": 27597,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 28144,
      "e": 27599,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28302,
      "e": 27757,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 28342,
      "e": 27797,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 28343,
      "e": 27798,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28453,
      "e": 27908,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 28518,
      "e": 27973,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 28518,
      "e": 27973,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28622,
      "e": 28077,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 28623,
      "e": 28078,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28630,
      "e": 28085,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t "
    },
    {
      "t": 28757,
      "e": 28212,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 30002,
      "e": 29457,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 31639,
      "e": 31094,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 31639,
      "e": 31094,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31774,
      "e": 31229,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 32125,
      "e": 31580,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 32126,
      "e": 31581,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32206,
      "e": 31661,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 32206,
      "e": 31661,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32245,
      "e": 31700,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||f "
    },
    {
      "t": 32310,
      "e": 31765,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 32486,
      "e": 31941,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 32487,
      "e": 31942,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32604,
      "e": 32059,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "First find the point of 1"
    },
    {
      "t": 32623,
      "e": 32078,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||1"
    },
    {
      "t": 32703,
      "e": 32158,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 32703,
      "e": 32158,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32797,
      "e": 32252,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||2"
    },
    {
      "t": 33134,
      "e": 32589,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 33135,
      "e": 32590,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33198,
      "e": 32653,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 33326,
      "e": 32781,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 33326,
      "e": 32781,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33390,
      "e": 32845,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 33462,
      "e": 32917,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 33463,
      "e": 32918,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33557,
      "e": 33012,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 34862,
      "e": 34317,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 34933,
      "e": 34388,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "First find the point of 12pm"
    },
    {
      "t": 35022,
      "e": 34477,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 35101,
      "e": 34556,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "First find the point of 12p"
    },
    {
      "t": 35182,
      "e": 34637,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 35278,
      "e": 34733,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "First find the point of 12"
    },
    {
      "t": 35390,
      "e": 34845,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 35759,
      "e": 35214,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 35760,
      "e": 35215,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35837,
      "e": 35292,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||P"
    },
    {
      "t": 36014,
      "e": 35469,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 36015,
      "e": 35470,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36101,
      "e": 35556,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||M"
    },
    {
      "t": 36174,
      "e": 35629,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 36270,
      "e": 35725,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 36270,
      "e": 35725,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36365,
      "e": 35820,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 36437,
      "e": 35892,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 36438,
      "e": 35893,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36559,
      "e": 36014,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 36559,
      "e": 36014,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36566,
      "e": 36021,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||of"
    },
    {
      "t": 36669,
      "e": 36124,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 36670,
      "e": 36125,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 36670,
      "e": 36125,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36774,
      "e": 36229,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 37102,
      "e": 36557,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 37166,
      "e": 36621,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "First find the point of 12PM of"
    },
    {
      "t": 37182,
      "e": 36637,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 37293,
      "e": 36748,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "First find the point of 12PM o"
    },
    {
      "t": 37799,
      "e": 37254,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 37799,
      "e": 37254,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37902,
      "e": 37357,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 37926,
      "e": 37381,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 37926,
      "e": 37381,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38046,
      "e": 37501,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 39103,
      "e": 38558,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 39103,
      "e": 38558,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39261,
      "e": 38716,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||x"
    },
    {
      "t": 39993,
      "e": 39448,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "189"
    },
    {
      "t": 39995,
      "e": 39450,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40005,
      "e": 39460,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 40081,
      "e": 39536,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||-"
    },
    {
      "t": 40176,
      "e": 39631,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 40178,
      "e": 39633,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40345,
      "e": 39800,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 40425,
      "e": 39880,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 40425,
      "e": 39880,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40553,
      "e": 40008,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 40553,
      "e": 40008,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40561,
      "e": 40016,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||xi"
    },
    {
      "t": 40625,
      "e": 40080,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 40657,
      "e": 40112,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 40657,
      "e": 40112,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40753,
      "e": 40208,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 40793,
      "e": 40248,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 40793,
      "e": 40248,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40913,
      "e": 40368,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 41138,
      "e": 40593,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 41265,
      "e": 40720,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "First find the point of 12PM on x-axis"
    },
    {
      "t": 41337,
      "e": 40792,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "188"
    },
    {
      "t": 41337,
      "e": 40792,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41457,
      "e": 40912,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||,"
    },
    {
      "t": 41497,
      "e": 40952,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 41497,
      "e": 40952,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41577,
      "e": 41032,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 41714,
      "e": 41169,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 41715,
      "e": 41170,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41793,
      "e": 41248,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 41794,
      "e": 41249,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41809,
      "e": 41264,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||th"
    },
    {
      "t": 41897,
      "e": 41352,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 41920,
      "e": 41375,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 41922,
      "e": 41377,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41985,
      "e": 41440,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 41985,
      "e": 41440,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42057,
      "e": 41512,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||en"
    },
    {
      "t": 42081,
      "e": 41536,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 42138,
      "e": 41593,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 42138,
      "e": 41593,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42225,
      "e": 41680,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 50005,
      "e": 46680,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 60747,
      "e": 46680,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 60747,
      "e": 46680,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 60809,
      "e": 46742,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 60937,
      "e": 46870,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 60938,
      "e": 46871,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 61025,
      "e": 46958,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 61049,
      "e": 46982,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 61050,
      "e": 46983,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 61161,
      "e": 47094,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 61345,
      "e": 47278,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 61346,
      "e": 47279,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 61505,
      "e": 47438,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||c"
    },
    {
      "t": 61545,
      "e": 47478,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 61545,
      "e": 47478,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 61666,
      "e": 47599,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 61666,
      "e": 47599,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 61667,
      "e": 47600,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 61760,
      "e": 47693,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 61865,
      "e": 47798,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 61865,
      "e": 47798,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 61945,
      "e": 47878,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 62281,
      "e": 48214,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 62407,
      "e": 48340,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "First find the point of 12PM on x-axis, then trace "
    },
    {
      "t": 62416,
      "e": 48349,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "First find the point of 12PM on x-axis, then trace "
    },
    {
      "t": 62465,
      "e": 48398,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 62465,
      "e": 48398,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 62561,
      "e": 48494,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 62569,
      "e": 48502,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 62570,
      "e": 48503,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 62625,
      "e": 48558,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 62641,
      "e": 48574,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 62641,
      "e": 48574,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 62736,
      "e": 48669,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 62744,
      "e": 48677,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 62745,
      "e": 48678,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 62832,
      "e": 48765,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 63617,
      "e": 49550,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 63618,
      "e": 49551,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 63721,
      "e": 49654,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 63873,
      "e": 49806,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 63874,
      "e": 49807,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 63944,
      "e": 49877,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 63945,
      "e": 49878,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 63992,
      "e": 49925,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||in"
    },
    {
      "t": 64064,
      "e": 49997,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 64065,
      "e": 49998,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 64073,
      "e": 50006,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 64121,
      "e": 50054,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 64123,
      "e": 50056,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 64178,
      "e": 50111,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 64264,
      "e": 50197,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 65938,
      "e": 51871,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 65939,
      "e": 51872,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 66009,
      "e": 51942,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 66010,
      "e": 51943,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 66032,
      "e": 51965,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||to"
    },
    {
      "t": 66097,
      "e": 52030,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 66208,
      "e": 52141,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "First find the point of 12PM on x-axis, then trace the line to"
    },
    {
      "t": 66217,
      "e": 52150,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 66218,
      "e": 52151,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 66312,
      "e": 52245,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||w"
    },
    {
      "t": 66401,
      "e": 52334,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 66402,
      "e": 52335,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 66545,
      "e": 52478,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 66658,
      "e": 52591,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 66658,
      "e": 52591,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 66737,
      "e": 52670,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 66881,
      "e": 52814,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 66882,
      "e": 52815,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 67007,
      "e": 52940,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "First find the point of 12PM on x-axis, then trace the line toward"
    },
    {
      "t": 67016,
      "e": 52949,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 67041,
      "e": 52974,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 67042,
      "e": 52975,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 67152,
      "e": 53085,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 67169,
      "e": 53102,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 67169,
      "e": 53102,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 67265,
      "e": 53198,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 67337,
      "e": 53270,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 67339,
      "e": 53272,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 67448,
      "e": 53381,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 67537,
      "e": 53470,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 67538,
      "e": 53471,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 67568,
      "e": 53501,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 68154,
      "e": 54087,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 68154,
      "e": 54087,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 68265,
      "e": 54198,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 68265,
      "e": 54198,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 68272,
      "e": 54205,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e "
    },
    {
      "t": 68361,
      "e": 54294,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 68864,
      "e": 54797,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 68864,
      "e": 54797,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 68928,
      "e": 54861,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||u"
    },
    {
      "t": 69049,
      "e": 54982,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 69050,
      "e": 54983,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 69153,
      "e": 55086,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 69457,
      "e": 55390,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "189"
    },
    {
      "t": 69458,
      "e": 55391,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 69544,
      "e": 55477,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||-"
    },
    {
      "t": 69729,
      "e": 55662,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 69729,
      "e": 55662,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 69824,
      "e": 55757,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 69874,
      "e": 55759,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 69876,
      "e": 55761,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 69968,
      "e": 55853,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 70040,
      "e": 55925,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 70040,
      "e": 55925,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 70113,
      "e": 55998,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 70153,
      "e": 56038,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 70154,
      "e": 56039,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 70225,
      "e": 56110,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 70233,
      "e": 56118,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 70234,
      "e": 56119,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 70344,
      "e": 56229,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 70344,
      "e": 56229,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 70369,
      "e": 56254,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t "
    },
    {
      "t": 70473,
      "e": 56358,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 71297,
      "e": 57182,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 71297,
      "e": 57182,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 71353,
      "e": 57238,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 71353,
      "e": 57238,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 71384,
      "e": 57269,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||di"
    },
    {
      "t": 71432,
      "e": 57317,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 71529,
      "e": 57414,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 71530,
      "e": 57415,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 71616,
      "e": 57501,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 71616,
      "e": 57501,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 71649,
      "e": 57534,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||re"
    },
    {
      "t": 71721,
      "e": 57606,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 71865,
      "e": 57750,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 71866,
      "e": 57751,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 71953,
      "e": 57838,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||c"
    },
    {
      "t": 72090,
      "e": 57975,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 72090,
      "e": 57975,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 72177,
      "e": 58062,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 72193,
      "e": 58078,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 72194,
      "e": 58079,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 72274,
      "e": 58159,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 72274,
      "e": 58159,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 72288,
      "e": 58173,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||io"
    },
    {
      "t": 72406,
      "e": 58291,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "First find the point of 12PM on x-axis, then trace the line towards the up-right directio"
    },
    {
      "t": 72409,
      "e": 58294,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 72457,
      "e": 58342,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 72457,
      "e": 58342,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 72513,
      "e": 58398,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 72562,
      "e": 58447,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 72562,
      "e": 58447,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 72664,
      "e": 58549,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 72720,
      "e": 58605,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 72721,
      "e": 58606,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 72825,
      "e": 58710,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 72826,
      "e": 58711,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 72841,
      "e": 58726,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||of"
    },
    {
      "t": 72905,
      "e": 58790,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 72905,
      "e": 58790,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 72928,
      "e": 58813,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 73024,
      "e": 58909,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 73857,
      "e": 59742,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 73858,
      "e": 59743,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 73945,
      "e": 59830,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 73946,
      "e": 59831,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 73946,
      "e": 59831,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 74016,
      "e": 59901,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 74032,
      "e": 59917,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 74032,
      "e": 59917,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 74113,
      "e": 59998,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 74113,
      "e": 59998,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 74145,
      "e": 60030,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e "
    },
    {
      "t": 74233,
      "e": 60118,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 74401,
      "e": 60286,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 74402,
      "e": 60287,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 74536,
      "e": 60421,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||1"
    },
    {
      "t": 74617,
      "e": 60502,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 74617,
      "e": 60502,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 74729,
      "e": 60614,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||2"
    },
    {
      "t": 75041,
      "e": 60926,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 75217,
      "e": 61102,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 75218,
      "e": 61103,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 75305,
      "e": 61190,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||O"
    },
    {
      "t": 75406,
      "e": 61291,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "First find the point of 12PM on x-axis, then trace the line towards the up-right direction of the 12O"
    },
    {
      "t": 75537,
      "e": 61422,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 75657,
      "e": 61542,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 75769,
      "e": 61654,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "First find the point of 12PM on x-axis, then trace the line towards the up-right direction of the 12"
    },
    {
      "t": 75833,
      "e": 61718,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 75921,
      "e": 61806,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 75922,
      "e": 61807,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 76001,
      "e": 61886,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||P"
    },
    {
      "t": 76186,
      "e": 62071,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 76186,
      "e": 62071,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 76248,
      "e": 62133,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||M"
    },
    {
      "t": 76336,
      "e": 62221,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 76545,
      "e": 62430,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 76546,
      "e": 62431,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 76681,
      "e": 62566,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 76994,
      "e": 62879,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 76994,
      "e": 62879,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 77084,
      "e": 62882,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 77241,
      "e": 63039,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 77241,
      "e": 63039,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 77313,
      "e": 63111,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 77417,
      "e": 63215,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 77418,
      "e": 63216,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 77528,
      "e": 63326,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 77529,
      "e": 63327,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 77560,
      "e": 63358,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||in"
    },
    {
      "t": 77617,
      "e": 63415,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 77617,
      "e": 63415,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 77649,
      "e": 63447,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 77721,
      "e": 63519,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 77721,
      "e": 63519,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 77760,
      "e": 63558,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 77840,
      "e": 63638,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 79345,
      "e": 65143,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 79480,
      "e": 65278,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "First find the point of 12PM on x-axis, then trace the line towards the up-right direction of the 12PM point"
    },
    {
      "t": 79561,
      "e": 65359,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "188"
    },
    {
      "t": 79562,
      "e": 65360,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 79664,
      "e": 65462,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||,"
    },
    {
      "t": 79672,
      "e": 65470,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 79673,
      "e": 65471,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 79801,
      "e": 65599,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 82738,
      "e": 68536,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 82738,
      "e": 68536,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 82848,
      "e": 68646,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 82881,
      "e": 68679,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 82881,
      "e": 68679,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 82929,
      "e": 68727,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 83345,
      "e": 69143,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 83346,
      "e": 69144,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 83465,
      "e": 69263,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 83585,
      "e": 69383,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 83664,
      "e": 69462,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "First find the point of 12PM on x-axis, then trace the line towards the up-right direction of the 12PM point, th"
    },
    {
      "t": 83737,
      "e": 69535,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 83833,
      "e": 69631,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "First find the point of 12PM on x-axis, then trace the line towards the up-right direction of the 12PM point, t"
    },
    {
      "t": 83937,
      "e": 69735,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 84049,
      "e": 69847,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "First find the point of 12PM on x-axis, then trace the line towards the up-right direction of the 12PM point, "
    },
    {
      "t": 84138,
      "e": 69936,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 84192,
      "e": 69990,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "First find the point of 12PM on x-axis, then trace the line towards the up-right direction of the 12PM point,"
    },
    {
      "t": 84313,
      "e": 70111,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 84360,
      "e": 70158,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "First find the point of 12PM on x-axis, then trace the line towards the up-right direction of the 12PM point"
    },
    {
      "t": 85048,
      "e": 70846,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "186"
    },
    {
      "t": 85048,
      "e": 70846,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 85105,
      "e": 70846,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||;"
    },
    {
      "t": 85207,
      "e": 70948,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "First find the point of 12PM on x-axis, then trace the line towards the up-right direction of the 12PM point;"
    },
    {
      "t": 85281,
      "e": 71022,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 85282,
      "e": 71023,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 85368,
      "e": 71109,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 85376,
      "e": 71117,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 85377,
      "e": 71118,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 85448,
      "e": 71189,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 85449,
      "e": 71190,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 85449,
      "e": 71190,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 85545,
      "e": 71286,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 85562,
      "e": 71303,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 85563,
      "e": 71304,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 85648,
      "e": 71389,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 85744,
      "e": 71485,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 85745,
      "e": 71486,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 85873,
      "e": 71614,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 86153,
      "e": 71894,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 86154,
      "e": 71895,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 86216,
      "e": 71957,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 86353,
      "e": 72094,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 86353,
      "e": 72094,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 86441,
      "e": 72182,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 86442,
      "e": 72183,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 86464,
      "e": 72205,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||in"
    },
    {
      "t": 86536,
      "e": 72277,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 86552,
      "e": 72293,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 86552,
      "e": 72293,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 86657,
      "e": 72398,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 86801,
      "e": 72542,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 86802,
      "e": 72543,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 86929,
      "e": 72670,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 86937,
      "e": 72678,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 86939,
      "e": 72680,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 87097,
      "e": 72838,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 87240,
      "e": 72981,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 87241,
      "e": 72982,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 87361,
      "e": 73102,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 87569,
      "e": 73310,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 87569,
      "e": 73310,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 87665,
      "e": 73406,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 88497,
      "e": 74238,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 88600,
      "e": 74341,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "First find the point of 12PM on x-axis, then trace the line towards the up-right direction of the 12PM point;the points l"
    },
    {
      "t": 88929,
      "e": 74670,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 88930,
      "e": 74671,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 88976,
      "e": 74717,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 88976,
      "e": 74717,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 89000,
      "e": 74741,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ie"
    },
    {
      "t": 89089,
      "e": 74830,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 89090,
      "e": 74831,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 89112,
      "e": 74853,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 89216,
      "e": 74957,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 89280,
      "e": 75021,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 89281,
      "e": 75022,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 89385,
      "e": 75126,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 89489,
      "e": 75230,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 89492,
      "e": 75233,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 89584,
      "e": 75325,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 89592,
      "e": 75333,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 89592,
      "e": 75333,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 89688,
      "e": 75429,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 89835,
      "e": 75576,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 89835,
      "e": 75576,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 89936,
      "e": 75677,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 89936,
      "e": 75677,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 89960,
      "e": 75701,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||th"
    },
    {
      "t": 90025,
      "e": 75766,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 90025,
      "e": 75766,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 90032,
      "e": 75773,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 90129,
      "e": 75870,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 90130,
      "e": 75871,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 90168,
      "e": 75909,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 90273,
      "e": 76014,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 91025,
      "e": 76766,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 91026,
      "e": 76767,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 91088,
      "e": 76829,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 91208,
      "e": 76949,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "First find the point of 12PM on x-axis, then trace the line towards the up-right direction of the 12PM point;the points lie on the l"
    },
    {
      "t": 91345,
      "e": 77086,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 91346,
      "e": 77087,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 91432,
      "e": 77173,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 91433,
      "e": 77174,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 91480,
      "e": 77221,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||in"
    },
    {
      "t": 91545,
      "e": 77286,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 91545,
      "e": 77286,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 91602,
      "e": 77287,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 91640,
      "e": 77325,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 91641,
      "e": 77326,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 91681,
      "e": 77366,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 91760,
      "e": 77445,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 91825,
      "e": 77510,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 91825,
      "e": 77510,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 91921,
      "e": 77606,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 92889,
      "e": 78574,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 92992,
      "e": 78677,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 92992,
      "e": 78677,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 93024,
      "e": 78709,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "First find the point of 12PM on x-axis, then trace the line towards the up-right direction of the 12PM point;the points lie on the line a"
    },
    {
      "t": 93129,
      "e": 78814,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 93129,
      "e": 78814,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 93136,
      "e": 78821,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 93225,
      "e": 78910,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 93225,
      "e": 78910,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 93313,
      "e": 78998,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 93328,
      "e": 79013,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 93328,
      "e": 79013,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 93337,
      "e": 79022,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 93416,
      "e": 79101,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 93577,
      "e": 79262,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 93578,
      "e": 79263,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 93696,
      "e": 79381,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 93801,
      "e": 79486,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 93802,
      "e": 79487,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 93921,
      "e": 79606,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 93977,
      "e": 79662,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 93977,
      "e": 79662,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 94057,
      "e": 79742,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 94064,
      "e": 79749,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 94065,
      "e": 79750,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 94152,
      "e": 79837,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 95681,
      "e": 81366,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 95682,
      "e": 81367,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 95777,
      "e": 81462,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 95913,
      "e": 81598,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "86"
    },
    {
      "t": 95913,
      "e": 81598,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 96033,
      "e": 81718,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 96033,
      "e": 81718,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 96040,
      "e": 81725,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ve"
    },
    {
      "t": 96137,
      "e": 81822,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 96144,
      "e": 81829,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 96146,
      "e": 81831,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 96232,
      "e": 81917,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 96273,
      "e": 81958,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 96273,
      "e": 81958,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 96328,
      "e": 82013,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 96465,
      "e": 82150,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 96467,
      "e": 82152,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 96568,
      "e": 82253,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 96569,
      "e": 82254,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 96576,
      "e": 82261,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s "
    },
    {
      "t": 96713,
      "e": 82398,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 97721,
      "e": 83406,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 97722,
      "e": 83407,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 97800,
      "e": 83485,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||w"
    },
    {
      "t": 97953,
      "e": 83638,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 97953,
      "e": 83638,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 98064,
      "e": 83749,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 98457,
      "e": 84142,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 98536,
      "e": 84221,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "First find the point of 12PM on x-axis, then trace the line towards the up-right direction of the 12PM point;the points lie on the line are the events w"
    },
    {
      "t": 98873,
      "e": 84558,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 98874,
      "e": 84559,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 98968,
      "e": 84653,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 98992,
      "e": 84677,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 98993,
      "e": 84678,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 99096,
      "e": 84781,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 99233,
      "e": 84918,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 99234,
      "e": 84919,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 99352,
      "e": 85037,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 99352,
      "e": 85037,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 99360,
      "e": 85045,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ar"
    },
    {
      "t": 99432,
      "e": 85117,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 99433,
      "e": 85118,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 99489,
      "e": 85174,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 99545,
      "e": 85230,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 99568,
      "e": 85253,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 99569,
      "e": 85254,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 99624,
      "e": 85309,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 99760,
      "e": 85445,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 99761,
      "e": 85446,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 99859,
      "e": 85544,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 99988,
      "e": 85673,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 99988,
      "e": 85673,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 100007,
      "e": 85692,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 100035,
      "e": 85720,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 100115,
      "e": 85800,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 100116,
      "e": 85801,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 100186,
      "e": 85871,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 100291,
      "e": 85976,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "75"
    },
    {
      "t": 100291,
      "e": 85976,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 100346,
      "e": 86031,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||k"
    },
    {
      "t": 100451,
      "e": 86136,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 100452,
      "e": 86137,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 100523,
      "e": 86208,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 100523,
      "e": 86208,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 100523,
      "e": 86208,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 100586,
      "e": 86271,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 100586,
      "e": 86271,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 100619,
      "e": 86304,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ng"
    },
    {
      "t": 100675,
      "e": 86360,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 100675,
      "e": 86360,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 100683,
      "e": 86368,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 100739,
      "e": 86424,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 100891,
      "e": 86576,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 100892,
      "e": 86577,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 100995,
      "e": 86680,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 100996,
      "e": 86681,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 101003,
      "e": 86688,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||fo"
    },
    {
      "t": 101108,
      "e": 86793,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 101148,
      "e": 86833,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 101148,
      "e": 86833,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 101259,
      "e": 86944,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 101739,
      "e": 87424,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "190"
    },
    {
      "t": 101740,
      "e": 87425,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 101795,
      "e": 87480,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||."
    },
    {
      "t": 102308,
      "e": 87993,
      "ty": 2,
      "x": 376,
      "y": 505
    },
    {
      "t": 102407,
      "e": 88092,
      "ty": 2,
      "x": 419,
      "y": 511
    },
    {
      "t": 102508,
      "e": 88193,
      "ty": 2,
      "x": 421,
      "y": 511
    },
    {
      "t": 102508,
      "e": 88193,
      "ty": 41,
      "x": 36410,
      "y": 33386,
      "ta": "#strategyAnswer"
    },
    {
      "t": 102605,
      "e": 88290,
      "ty": 7,
      "x": 585,
      "y": 463,
      "ta": "#strategyAnswer"
    },
    {
      "t": 102607,
      "e": 88292,
      "ty": 2,
      "x": 585,
      "y": 463
    },
    {
      "t": 102663,
      "e": 88348,
      "ty": 6,
      "x": 621,
      "y": 469,
      "ta": "#strategyAnswer"
    },
    {
      "t": 102707,
      "e": 88392,
      "ty": 2,
      "x": 559,
      "y": 525
    },
    {
      "t": 102755,
      "e": 88440,
      "ty": 7,
      "x": 548,
      "y": 551,
      "ta": "#strategyAnswer"
    },
    {
      "t": 102757,
      "e": 88442,
      "ty": 41,
      "x": 50686,
      "y": 61202,
      "ta": "#.strategy"
    },
    {
      "t": 102808,
      "e": 88493,
      "ty": 2,
      "x": 548,
      "y": 560
    },
    {
      "t": 102907,
      "e": 88592,
      "ty": 2,
      "x": 478,
      "y": 617
    },
    {
      "t": 103006,
      "e": 88691,
      "ty": 6,
      "x": 455,
      "y": 625,
      "ta": "#strategyButton"
    },
    {
      "t": 103007,
      "e": 88692,
      "ty": 2,
      "x": 455,
      "y": 625
    },
    {
      "t": 103007,
      "e": 88692,
      "ty": 41,
      "x": 63572,
      "y": 44844,
      "ta": "#strategyButton"
    },
    {
      "t": 103108,
      "e": 88793,
      "ty": 2,
      "x": 446,
      "y": 627
    },
    {
      "t": 103257,
      "e": 88942,
      "ty": 41,
      "x": 58657,
      "y": 48699,
      "ta": "#strategyButton"
    },
    {
      "t": 103758,
      "e": 89443,
      "ty": 41,
      "x": 59749,
      "y": 52554,
      "ta": "#strategyButton"
    },
    {
      "t": 103807,
      "e": 89492,
      "ty": 2,
      "x": 447,
      "y": 633
    },
    {
      "t": 104007,
      "e": 89692,
      "ty": 2,
      "x": 446,
      "y": 632
    },
    {
      "t": 104008,
      "e": 89693,
      "ty": 41,
      "x": 58657,
      "y": 58336,
      "ta": "#strategyButton"
    },
    {
      "t": 104307,
      "e": 89992,
      "ty": 2,
      "x": 444,
      "y": 627
    },
    {
      "t": 104408,
      "e": 90093,
      "ty": 2,
      "x": 444,
      "y": 622
    },
    {
      "t": 104508,
      "e": 90193,
      "ty": 41,
      "x": 57564,
      "y": 39061,
      "ta": "#strategyButton"
    },
    {
      "t": 104907,
      "e": 90592,
      "ty": 2,
      "x": 443,
      "y": 621
    },
    {
      "t": 105008,
      "e": 90693,
      "ty": 41,
      "x": 57018,
      "y": 37134,
      "ta": "#strategyButton"
    },
    {
      "t": 106208,
      "e": 91893,
      "ty": 2,
      "x": 439,
      "y": 621
    },
    {
      "t": 106257,
      "e": 91942,
      "ty": 41,
      "x": 46096,
      "y": 39061,
      "ta": "#strategyButton"
    },
    {
      "t": 106308,
      "e": 91993,
      "ty": 2,
      "x": 418,
      "y": 622
    },
    {
      "t": 106508,
      "e": 92193,
      "ty": 2,
      "x": 416,
      "y": 620
    },
    {
      "t": 106508,
      "e": 92193,
      "ty": 41,
      "x": 42273,
      "y": 35206,
      "ta": "#strategyButton"
    },
    {
      "t": 106808,
      "e": 92493,
      "ty": 2,
      "x": 415,
      "y": 620
    },
    {
      "t": 107008,
      "e": 92693,
      "ty": 41,
      "x": 41727,
      "y": 35206,
      "ta": "#strategyButton"
    },
    {
      "t": 108208,
      "e": 93893,
      "ty": 2,
      "x": 419,
      "y": 604
    },
    {
      "t": 108211,
      "e": 93896,
      "ty": 7,
      "x": 432,
      "y": 591,
      "ta": "#strategyButton"
    },
    {
      "t": 108258,
      "e": 93943,
      "ty": 41,
      "x": 41356,
      "y": 62323,
      "ta": "#.strategy"
    },
    {
      "t": 108259,
      "e": 93944,
      "ty": 6,
      "x": 488,
      "y": 526,
      "ta": "#strategyAnswer"
    },
    {
      "t": 108293,
      "e": 93978,
      "ty": 7,
      "x": 531,
      "y": 464,
      "ta": "#strategyAnswer"
    },
    {
      "t": 108308,
      "e": 93993,
      "ty": 2,
      "x": 531,
      "y": 464
    },
    {
      "t": 108408,
      "e": 94093,
      "ty": 2,
      "x": 564,
      "y": 428
    },
    {
      "t": 108493,
      "e": 94178,
      "ty": 6,
      "x": 538,
      "y": 488,
      "ta": "#strategyAnswer"
    },
    {
      "t": 108507,
      "e": 94192,
      "ty": 2,
      "x": 538,
      "y": 488
    },
    {
      "t": 108508,
      "e": 94193,
      "ty": 41,
      "x": 49562,
      "y": 14778,
      "ta": "#strategyAnswer"
    },
    {
      "t": 108542,
      "e": 94227,
      "ty": 7,
      "x": 492,
      "y": 562,
      "ta": "#strategyAnswer"
    },
    {
      "t": 108608,
      "e": 94293,
      "ty": 2,
      "x": 475,
      "y": 586
    },
    {
      "t": 108707,
      "e": 94392,
      "ty": 2,
      "x": 463,
      "y": 600
    },
    {
      "t": 108727,
      "e": 94412,
      "ty": 6,
      "x": 454,
      "y": 607,
      "ta": "#strategyButton"
    },
    {
      "t": 108758,
      "e": 94443,
      "ty": 41,
      "x": 59749,
      "y": 15931,
      "ta": "#strategyButton"
    },
    {
      "t": 108808,
      "e": 94493,
      "ty": 2,
      "x": 440,
      "y": 614
    },
    {
      "t": 109008,
      "e": 94693,
      "ty": 41,
      "x": 55380,
      "y": 23641,
      "ta": "#strategyButton"
    },
    {
      "t": 109183,
      "e": 94868,
      "ty": 3,
      "x": 440,
      "y": 614,
      "ta": "#strategyButton"
    },
    {
      "t": 109183,
      "e": 94868,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "First find the point of 12PM on x-axis, then trace the line towards the up-right direction of the 12PM point;the points lie on the line are the events we are looking for."
    },
    {
      "t": 109183,
      "e": 94868,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 109184,
      "e": 94869,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 109944,
      "e": 95629,
      "ty": 7,
      "x": 447,
      "y": 588,
      "ta": "#strategyButton"
    },
    {
      "t": 109993,
      "e": 95678,
      "ty": 6,
      "x": 460,
      "y": 540,
      "ta": "#strategyAnswer"
    },
    {
      "t": 110007,
      "e": 95692,
      "ty": 2,
      "x": 460,
      "y": 540
    },
    {
      "t": 110008,
      "e": 95693,
      "ty": 41,
      "x": 40794,
      "y": 56850,
      "ta": "#strategyAnswer"
    },
    {
      "t": 110008,
      "e": 95693,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 110107,
      "e": 95792,
      "ty": 2,
      "x": 470,
      "y": 503
    },
    {
      "t": 110135,
      "e": 95820,
      "ty": 4,
      "x": 41918,
      "y": 26105,
      "ta": "#strategyAnswer"
    },
    {
      "t": 110207,
      "e": 95892,
      "ty": 2,
      "x": 470,
      "y": 502
    },
    {
      "t": 110258,
      "e": 95943,
      "ty": 41,
      "x": 41918,
      "y": 36623,
      "ta": "#strategyAnswer"
    },
    {
      "t": 110295,
      "e": 95980,
      "ty": 7,
      "x": 468,
      "y": 567,
      "ta": "#strategyAnswer"
    },
    {
      "t": 110308,
      "e": 95993,
      "ty": 2,
      "x": 468,
      "y": 567
    },
    {
      "t": 110344,
      "e": 96029,
      "ty": 6,
      "x": 456,
      "y": 614,
      "ta": "#strategyButton"
    },
    {
      "t": 110408,
      "e": 96093,
      "ty": 2,
      "x": 452,
      "y": 626
    },
    {
      "t": 110508,
      "e": 96193,
      "ty": 2,
      "x": 452,
      "y": 627
    },
    {
      "t": 110508,
      "e": 96193,
      "ty": 41,
      "x": 61933,
      "y": 48699,
      "ta": "#strategyButton"
    },
    {
      "t": 110608,
      "e": 96293,
      "ty": 2,
      "x": 450,
      "y": 631
    },
    {
      "t": 110758,
      "e": 96443,
      "ty": 41,
      "x": 60841,
      "y": 56409,
      "ta": "#strategyButton"
    },
    {
      "t": 111608,
      "e": 97293,
      "ty": 2,
      "x": 450,
      "y": 626
    },
    {
      "t": 111708,
      "e": 97393,
      "ty": 2,
      "x": 450,
      "y": 611
    },
    {
      "t": 111758,
      "e": 97443,
      "ty": 41,
      "x": 60841,
      "y": 15931,
      "ta": "#strategyButton"
    },
    {
      "t": 111808,
      "e": 97493,
      "ty": 2,
      "x": 450,
      "y": 609
    },
    {
      "t": 112008,
      "e": 97693,
      "ty": 2,
      "x": 447,
      "y": 615
    },
    {
      "t": 112008,
      "e": 97693,
      "ty": 41,
      "x": 59203,
      "y": 25569,
      "ta": "#strategyButton"
    },
    {
      "t": 112108,
      "e": 97793,
      "ty": 2,
      "x": 444,
      "y": 618
    },
    {
      "t": 112208,
      "e": 97893,
      "ty": 2,
      "x": 443,
      "y": 620
    },
    {
      "t": 112258,
      "e": 97943,
      "ty": 41,
      "x": 55926,
      "y": 40989,
      "ta": "#strategyButton"
    },
    {
      "t": 112307,
      "e": 97992,
      "ty": 2,
      "x": 438,
      "y": 628
    },
    {
      "t": 112407,
      "e": 98092,
      "ty": 2,
      "x": 437,
      "y": 630
    },
    {
      "t": 112508,
      "e": 98193,
      "ty": 2,
      "x": 436,
      "y": 632
    },
    {
      "t": 112508,
      "e": 98193,
      "ty": 41,
      "x": 53195,
      "y": 58336,
      "ta": "#strategyButton"
    },
    {
      "t": 112608,
      "e": 98293,
      "ty": 2,
      "x": 435,
      "y": 635
    },
    {
      "t": 112648,
      "e": 98333,
      "ty": 7,
      "x": 435,
      "y": 636,
      "ta": "#strategyButton"
    },
    {
      "t": 112708,
      "e": 98393,
      "ty": 2,
      "x": 435,
      "y": 636
    },
    {
      "t": 112758,
      "e": 98443,
      "ty": 41,
      "x": 54490,
      "y": 44082,
      "ta": "> div.stimulus > div > div:[3]"
    },
    {
      "t": 114345,
      "e": 100030,
      "ty": 6,
      "x": 435,
      "y": 635,
      "ta": "#strategyButton"
    },
    {
      "t": 114407,
      "e": 100092,
      "ty": 2,
      "x": 435,
      "y": 630
    },
    {
      "t": 114508,
      "e": 100193,
      "ty": 41,
      "x": 52649,
      "y": 54481,
      "ta": "#strategyButton"
    },
    {
      "t": 114683,
      "e": 100368,
      "ty": 7,
      "x": 413,
      "y": 593,
      "ta": "#strategyButton"
    },
    {
      "t": 114708,
      "e": 100393,
      "ty": 2,
      "x": 396,
      "y": 574
    },
    {
      "t": 114731,
      "e": 100416,
      "ty": 6,
      "x": 361,
      "y": 543,
      "ta": "#strategyAnswer"
    },
    {
      "t": 114758,
      "e": 100443,
      "ty": 41,
      "x": 28878,
      "y": 53613,
      "ta": "#strategyAnswer"
    },
    {
      "t": 114808,
      "e": 100493,
      "ty": 2,
      "x": 332,
      "y": 517
    },
    {
      "t": 114908,
      "e": 100593,
      "ty": 2,
      "x": 330,
      "y": 514
    },
    {
      "t": 114952,
      "e": 100637,
      "ty": 3,
      "x": 330,
      "y": 514,
      "ta": "#strategyAnswer"
    },
    {
      "t": 114953,
      "e": 100638,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 114954,
      "e": 100639,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 115008,
      "e": 100693,
      "ty": 41,
      "x": 26180,
      "y": 35814,
      "ta": "#strategyAnswer"
    },
    {
      "t": 115062,
      "e": 100747,
      "ty": 4,
      "x": 26180,
      "y": 35814,
      "ta": "#strategyAnswer"
    },
    {
      "t": 115063,
      "e": 100748,
      "ty": 5,
      "x": 330,
      "y": 514,
      "ta": "#strategyAnswer"
    },
    {
      "t": 115258,
      "e": 100943,
      "ty": 41,
      "x": 26405,
      "y": 35814,
      "ta": "#strategyAnswer"
    },
    {
      "t": 115308,
      "e": 100993,
      "ty": 2,
      "x": 332,
      "y": 514
    },
    {
      "t": 115723,
      "e": 101408,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 115802,
      "e": 101487,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "First find the point of 12PM on x-axis, then trace the line towards the up-right direction of the 12PM point;the points lie on the line are the events we are looking for"
    },
    {
      "t": 115955,
      "e": 101640,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "188"
    },
    {
      "t": 115956,
      "e": 101641,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 116034,
      "e": 101719,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||,"
    },
    {
      "t": 116050,
      "e": 101735,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 116050,
      "e": 101735,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 116155,
      "e": 101840,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 116227,
      "e": 101912,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 116227,
      "e": 101912,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 116307,
      "e": 101992,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||w"
    },
    {
      "t": 116410,
      "e": 102095,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "First find the point of 12PM on x-axis, then trace the line towards the up-right direction of the 12PM point;the points lie on the line are the events we are looking for, w"
    },
    {
      "t": 116507,
      "e": 102192,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 116509,
      "e": 102194,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 116626,
      "e": 102311,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 116634,
      "e": 102319,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 116634,
      "e": 102319,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 116747,
      "e": 102432,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 116804,
      "e": 102489,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 116804,
      "e": 102489,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 116858,
      "e": 102543,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||c"
    },
    {
      "t": 116930,
      "e": 102615,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 116930,
      "e": 102615,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 117035,
      "e": 102720,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 117083,
      "e": 102768,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 117084,
      "e": 102769,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 117208,
      "e": 102893,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "First find the point of 12PM on x-axis, then trace the line towards the up-right direction of the 12PM point;the points lie on the line are the events we are looking for, which "
    },
    {
      "t": 117210,
      "e": 102893,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 117347,
      "e": 103030,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 117347,
      "e": 103030,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 117466,
      "e": 103149,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 117515,
      "e": 103198,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 117516,
      "e": 103199,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 117595,
      "e": 103278,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 117595,
      "e": 103278,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 117602,
      "e": 103285,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s "
    },
    {
      "t": 117715,
      "e": 103398,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 118371,
      "e": 104054,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 118635,
      "e": 104318,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 118636,
      "e": 104319,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 118723,
      "e": 104406,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||M"
    },
    {
      "t": 118748,
      "e": 104431,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 118900,
      "e": 104583,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 118900,
      "e": 104583,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 119009,
      "e": 104692,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "First find the point of 12PM on x-axis, then trace the line towards the up-right direction of the 12PM point;the points lie on the line are the events we are looking for, which is M "
    },
    {
      "t": 119011,
      "e": 104694,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 119059,
      "e": 104742,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 119059,
      "e": 104742,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 119188,
      "e": 104871,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 119236,
      "e": 104919,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 119237,
      "e": 104920,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 119339,
      "e": 105022,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 119340,
      "e": 105023,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 119354,
      "e": 105037,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||nd"
    },
    {
      "t": 119419,
      "e": 105102,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 119420,
      "e": 105103,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 119458,
      "e": 105141,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 119530,
      "e": 105213,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 119659,
      "e": 105342,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 119906,
      "e": 105589,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "75"
    },
    {
      "t": 119907,
      "e": 105590,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 119979,
      "e": 105662,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||K"
    },
    {
      "t": 120163,
      "e": 105846,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 120236,
      "e": 105919,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 120362,
      "e": 106045,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "First find the point of 12PM on x-axis, then trace the line towards the up-right direction of the 12PM point;the points lie on the line are the events we are looking for, which is M and "
    },
    {
      "t": 120395,
      "e": 106078,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 120458,
      "e": 106141,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 120459,
      "e": 106142,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 120555,
      "e": 106238,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||L"
    },
    {
      "t": 120644,
      "e": 106327,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 121010,
      "e": 106693,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "190"
    },
    {
      "t": 121010,
      "e": 106693,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 121074,
      "e": 106757,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||."
    },
    {
      "t": 121209,
      "e": 106892,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "First find the point of 12PM on x-axis, then trace the line towards the up-right direction of the 12PM point;the points lie on the line are the events we are looking for, which is M and L."
    },
    {
      "t": 121475,
      "e": 107158,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "107"
    },
    {
      "t": 121476,
      "e": 107159,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 121507,
      "e": 107190,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||+"
    },
    {
      "t": 121610,
      "e": 107191,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "First find the point of 12PM on x-axis, then trace the line towards the up-right direction of the 12PM point;the points lie on the line are the events we are looking for, which is M and L.+"
    },
    {
      "t": 122307,
      "e": 107888,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 122363,
      "e": 107944,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "First find the point of 12PM on x-axis, then trace the line towards the up-right direction of the 12PM point;the points lie on the line are the events we are looking for, which is M and L."
    },
    {
      "t": 122908,
      "e": 108489,
      "ty": 2,
      "x": 497,
      "y": 538
    },
    {
      "t": 123007,
      "e": 108588,
      "ty": 2,
      "x": 491,
      "y": 541
    },
    {
      "t": 123017,
      "e": 108598,
      "ty": 41,
      "x": 44278,
      "y": 57659,
      "ta": "#strategyAnswer"
    },
    {
      "t": 123373,
      "e": 108954,
      "ty": 7,
      "x": 490,
      "y": 564,
      "ta": "#strategyAnswer"
    },
    {
      "t": 123407,
      "e": 108988,
      "ty": 2,
      "x": 456,
      "y": 589
    },
    {
      "t": 123507,
      "e": 109088,
      "ty": 2,
      "x": 437,
      "y": 596
    },
    {
      "t": 123507,
      "e": 109088,
      "ty": 41,
      "x": 55426,
      "y": 17868,
      "ta": "> div.stimulus > div > div:[3]"
    },
    {
      "t": 123556,
      "e": 109137,
      "ty": 6,
      "x": 383,
      "y": 603,
      "ta": "#strategyButton"
    },
    {
      "t": 123588,
      "e": 109169,
      "ty": 7,
      "x": 320,
      "y": 616,
      "ta": "#strategyButton"
    },
    {
      "t": 123607,
      "e": 109188,
      "ty": 2,
      "x": 303,
      "y": 621
    },
    {
      "t": 123707,
      "e": 109288,
      "ty": 2,
      "x": 315,
      "y": 624
    },
    {
      "t": 123739,
      "e": 109320,
      "ty": 6,
      "x": 339,
      "y": 625,
      "ta": "#strategyButton"
    },
    {
      "t": 123757,
      "e": 109338,
      "ty": 41,
      "x": 7321,
      "y": 50626,
      "ta": "#strategyButton"
    },
    {
      "t": 123807,
      "e": 109388,
      "ty": 2,
      "x": 375,
      "y": 630
    },
    {
      "t": 123839,
      "e": 109420,
      "ty": 3,
      "x": 376,
      "y": 630,
      "ta": "#strategyButton"
    },
    {
      "t": 123840,
      "e": 109421,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "First find the point of 12PM on x-axis, then trace the line towards the up-right direction of the 12PM point;the points lie on the line are the events we are looking for, which is M and L."
    },
    {
      "t": 123841,
      "e": 109422,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 123841,
      "e": 109422,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 123907,
      "e": 109488,
      "ty": 2,
      "x": 376,
      "y": 630
    },
    {
      "t": 123991,
      "e": 109572,
      "ty": 4,
      "x": 20428,
      "y": 54481,
      "ta": "#strategyButton"
    },
    {
      "t": 124011,
      "e": 109592,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 124011,
      "e": 109592,
      "ty": 5,
      "x": 376,
      "y": 630,
      "ta": "#strategyButton"
    },
    {
      "t": 124017,
      "e": 109598,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 124019,
      "e": 109600,
      "ty": 41,
      "x": 12673,
      "y": 37848,
      "ta": "html > body"
    },
    {
      "t": 124307,
      "e": 109888,
      "ty": 2,
      "x": 378,
      "y": 630
    },
    {
      "t": 124407,
      "e": 109988,
      "ty": 2,
      "x": 451,
      "y": 617
    },
    {
      "t": 124508,
      "e": 110089,
      "ty": 41,
      "x": 15255,
      "y": 37057,
      "ta": "html > body"
    },
    {
      "t": 125016,
      "e": 110597,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 125207,
      "e": 110788,
      "ty": 2,
      "x": 452,
      "y": 613
    },
    {
      "t": 125257,
      "e": 110838,
      "ty": 41,
      "x": 15290,
      "y": 36509,
      "ta": "html > body"
    },
    {
      "t": 125308,
      "e": 110889,
      "ty": 2,
      "x": 461,
      "y": 601
    },
    {
      "t": 125408,
      "e": 110989,
      "ty": 2,
      "x": 504,
      "y": 582
    },
    {
      "t": 125507,
      "e": 111088,
      "ty": 2,
      "x": 800,
      "y": 587
    },
    {
      "t": 125508,
      "e": 111089,
      "ty": 41,
      "x": 27274,
      "y": 35231,
      "ta": "html > body"
    },
    {
      "t": 125608,
      "e": 111189,
      "ty": 2,
      "x": 944,
      "y": 552
    },
    {
      "t": 125707,
      "e": 111288,
      "ty": 2,
      "x": 955,
      "y": 532
    },
    {
      "t": 125758,
      "e": 111339,
      "ty": 41,
      "x": 32443,
      "y": 60602,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 125807,
      "e": 111388,
      "ty": 2,
      "x": 958,
      "y": 523
    },
    {
      "t": 125888,
      "e": 111469,
      "ty": 3,
      "x": 958,
      "y": 523,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 125976,
      "e": 111557,
      "ty": 4,
      "x": 32443,
      "y": 60602,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 125976,
      "e": 111557,
      "ty": 5,
      "x": 958,
      "y": 523,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 126040,
      "e": 111621,
      "ty": 6,
      "x": 958,
      "y": 520,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 126107,
      "e": 111688,
      "ty": 2,
      "x": 958,
      "y": 515
    },
    {
      "t": 126134,
      "e": 111715,
      "ty": 3,
      "x": 958,
      "y": 514,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 126134,
      "e": 111715,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 126207,
      "e": 111788,
      "ty": 2,
      "x": 958,
      "y": 514
    },
    {
      "t": 126255,
      "e": 111836,
      "ty": 4,
      "x": 32443,
      "y": 40569,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 126256,
      "e": 111837,
      "ty": 5,
      "x": 958,
      "y": 514,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 126257,
      "e": 111838,
      "ty": 41,
      "x": 32443,
      "y": 40569,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 126407,
      "e": 111988,
      "ty": 2,
      "x": 989,
      "y": 512
    },
    {
      "t": 126458,
      "e": 112039,
      "ty": 7,
      "x": 1115,
      "y": 505,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 126507,
      "e": 112088,
      "ty": 2,
      "x": 1128,
      "y": 504
    },
    {
      "t": 126508,
      "e": 112089,
      "ty": 41,
      "x": 38570,
      "y": 30181,
      "ta": "html > body"
    },
    {
      "t": 126707,
      "e": 112288,
      "ty": 2,
      "x": 1124,
      "y": 508
    },
    {
      "t": 126757,
      "e": 112338,
      "ty": 41,
      "x": 38157,
      "y": 30729,
      "ta": "html > body"
    },
    {
      "t": 126807,
      "e": 112388,
      "ty": 2,
      "x": 1116,
      "y": 513
    },
    {
      "t": 126907,
      "e": 112488,
      "ty": 2,
      "x": 1111,
      "y": 515
    },
    {
      "t": 126920,
      "e": 112501,
      "ty": 6,
      "x": 1108,
      "y": 515,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 126985,
      "e": 112502,
      "ty": 3,
      "x": 1108,
      "y": 515,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 127007,
      "e": 112524,
      "ty": 2,
      "x": 1108,
      "y": 515
    },
    {
      "t": 127008,
      "e": 112525,
      "ty": 41,
      "x": 64886,
      "y": 43690,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 127102,
      "e": 112619,
      "ty": 4,
      "x": 64886,
      "y": 43690,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 127102,
      "e": 112619,
      "ty": 5,
      "x": 1108,
      "y": 515,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 127508,
      "e": 113025,
      "ty": 2,
      "x": 1081,
      "y": 518
    },
    {
      "t": 127508,
      "e": 113025,
      "ty": 41,
      "x": 59046,
      "y": 53052,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 127607,
      "e": 113124,
      "ty": 2,
      "x": 1068,
      "y": 514
    },
    {
      "t": 127680,
      "e": 113197,
      "ty": 3,
      "x": 1066,
      "y": 511,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 127708,
      "e": 113225,
      "ty": 2,
      "x": 1066,
      "y": 511
    },
    {
      "t": 127758,
      "e": 113275,
      "ty": 41,
      "x": 55802,
      "y": 31207,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 127775,
      "e": 113292,
      "ty": 4,
      "x": 55802,
      "y": 31207,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 127775,
      "e": 113292,
      "ty": 5,
      "x": 1066,
      "y": 511,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 128395,
      "e": 113912,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "98"
    },
    {
      "t": 128396,
      "e": 113913,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 128475,
      "e": 113992,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "2"
    },
    {
      "t": 128587,
      "e": 114104,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "98"
    },
    {
      "t": 128587,
      "e": 114104,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 128666,
      "e": 114183,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "22"
    },
    {
      "t": 129144,
      "e": 114661,
      "ty": 7,
      "x": 1072,
      "y": 490,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 129207,
      "e": 114724,
      "ty": 2,
      "x": 1072,
      "y": 483
    },
    {
      "t": 129258,
      "e": 114775,
      "ty": 41,
      "x": 57099,
      "y": 32415,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 129407,
      "e": 114924,
      "ty": 2,
      "x": 1072,
      "y": 487
    },
    {
      "t": 129415,
      "e": 114932,
      "ty": 6,
      "x": 1077,
      "y": 508,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 129427,
      "e": 114944,
      "ty": 7,
      "x": 1078,
      "y": 529,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 129462,
      "e": 114979,
      "ty": 6,
      "x": 1008,
      "y": 629,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 129477,
      "e": 114994,
      "ty": 7,
      "x": 958,
      "y": 665,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 129507,
      "e": 115024,
      "ty": 2,
      "x": 928,
      "y": 691
    },
    {
      "t": 129508,
      "e": 115025,
      "ty": 41,
      "x": 31682,
      "y": 41560,
      "ta": "html > body"
    },
    {
      "t": 129607,
      "e": 115124,
      "ty": 2,
      "x": 901,
      "y": 711
    },
    {
      "t": 129707,
      "e": 115224,
      "ty": 2,
      "x": 932,
      "y": 688
    },
    {
      "t": 129727,
      "e": 115244,
      "ty": 6,
      "x": 975,
      "y": 653,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 129758,
      "e": 115275,
      "ty": 41,
      "x": 47971,
      "y": 35746,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 129808,
      "e": 115325,
      "ty": 2,
      "x": 1005,
      "y": 624
    },
    {
      "t": 129811,
      "e": 115328,
      "ty": 7,
      "x": 1007,
      "y": 621,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 129907,
      "e": 115424,
      "ty": 2,
      "x": 1009,
      "y": 616
    },
    {
      "t": 129959,
      "e": 115476,
      "ty": 6,
      "x": 1009,
      "y": 614,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 130008,
      "e": 115525,
      "ty": 2,
      "x": 1009,
      "y": 612
    },
    {
      "t": 130008,
      "e": 115525,
      "ty": 41,
      "x": 43473,
      "y": 56172,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 130108,
      "e": 115625,
      "ty": 2,
      "x": 1009,
      "y": 608
    },
    {
      "t": 130129,
      "e": 115646,
      "ty": 3,
      "x": 1009,
      "y": 608,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 130129,
      "e": 115646,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "22"
    },
    {
      "t": 130129,
      "e": 115646,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 130130,
      "e": 115647,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 130231,
      "e": 115748,
      "ty": 4,
      "x": 43473,
      "y": 43690,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 130232,
      "e": 115749,
      "ty": 5,
      "x": 1009,
      "y": 608,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 130258,
      "e": 115775,
      "ty": 41,
      "x": 43473,
      "y": 43690,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 130819,
      "e": 116336,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 130955,
      "e": 116472,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "67"
    },
    {
      "t": 130956,
      "e": 116473,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 131058,
      "e": 116575,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "C"
    },
    {
      "t": 131074,
      "e": 116591,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "C"
    },
    {
      "t": 131147,
      "e": 116664,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "72"
    },
    {
      "t": 131147,
      "e": 116664,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 131219,
      "e": 116736,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "73"
    },
    {
      "t": 131220,
      "e": 116737,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 131235,
      "e": 116752,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Chi"
    },
    {
      "t": 131338,
      "e": 116855,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Chi"
    },
    {
      "t": 131347,
      "e": 116864,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "78"
    },
    {
      "t": 131348,
      "e": 116865,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 131450,
      "e": 116967,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Chin"
    },
    {
      "t": 131466,
      "e": 116983,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "65"
    },
    {
      "t": 131467,
      "e": 116984,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 131579,
      "e": 117096,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||a"
    },
    {
      "t": 132108,
      "e": 117625,
      "ty": 2,
      "x": 1003,
      "y": 609
    },
    {
      "t": 132146,
      "e": 117663,
      "ty": 7,
      "x": 986,
      "y": 619,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 132164,
      "e": 117681,
      "ty": 6,
      "x": 985,
      "y": 624,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 132208,
      "e": 117725,
      "ty": 2,
      "x": 990,
      "y": 637
    },
    {
      "t": 132258,
      "e": 117775,
      "ty": 41,
      "x": 47456,
      "y": 47661,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 132308,
      "e": 117825,
      "ty": 2,
      "x": 982,
      "y": 652
    },
    {
      "t": 132408,
      "e": 117925,
      "ty": 2,
      "x": 981,
      "y": 652
    },
    {
      "t": 132487,
      "e": 118004,
      "ty": 3,
      "x": 980,
      "y": 650,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 132492,
      "e": 118009,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "China"
    },
    {
      "t": 132493,
      "e": 118010,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 132493,
      "e": 118010,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 132508,
      "e": 118025,
      "ty": 2,
      "x": 980,
      "y": 650
    },
    {
      "t": 132508,
      "e": 118025,
      "ty": 41,
      "x": 43332,
      "y": 53619,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 132662,
      "e": 118179,
      "ty": 4,
      "x": 43332,
      "y": 53619,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 132664,
      "e": 118181,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 132664,
      "e": 118181,
      "ty": 5,
      "x": 980,
      "y": 650,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 132664,
      "e": 118181,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 133007,
      "e": 118524,
      "ty": 2,
      "x": 983,
      "y": 646
    },
    {
      "t": 133008,
      "e": 118525,
      "ty": 41,
      "x": 33576,
      "y": 38822,
      "ta": "html > body"
    },
    {
      "t": 133108,
      "e": 118625,
      "ty": 2,
      "x": 999,
      "y": 602
    },
    {
      "t": 133208,
      "e": 118725,
      "ty": 2,
      "x": 895,
      "y": 451
    },
    {
      "t": 133258,
      "e": 118775,
      "ty": 41,
      "x": 30546,
      "y": 26956,
      "ta": "html > body"
    },
    {
      "t": 133691,
      "e": 119208,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 134207,
      "e": 119724,
      "ty": 2,
      "x": 898,
      "y": 446
    },
    {
      "t": 134258,
      "e": 119775,
      "ty": 41,
      "x": 19597,
      "y": 53832,
      "ta": "#jspsych-survey-multi-choice-option-1-2"
    },
    {
      "t": 134307,
      "e": 119824,
      "ty": 2,
      "x": 912,
      "y": 383
    },
    {
      "t": 134407,
      "e": 119924,
      "ty": 2,
      "x": 924,
      "y": 269
    },
    {
      "t": 134507,
      "e": 120024,
      "ty": 2,
      "x": 924,
      "y": 251
    },
    {
      "t": 134508,
      "e": 120025,
      "ty": 41,
      "x": 32148,
      "y": 62258,
      "ta": "#jspsych-survey-multi-choice-option-0-2 > label"
    },
    {
      "t": 134608,
      "e": 120125,
      "ty": 2,
      "x": 916,
      "y": 234
    },
    {
      "t": 134708,
      "e": 120225,
      "ty": 2,
      "x": 861,
      "y": 200
    },
    {
      "t": 134758,
      "e": 120275,
      "ty": 41,
      "x": 7256,
      "y": 58513,
      "ta": "#jspsych-survey-multi-choice-option-0-0"
    },
    {
      "t": 134807,
      "e": 120324,
      "ty": 2,
      "x": 849,
      "y": 196
    },
    {
      "t": 134907,
      "e": 120424,
      "ty": 2,
      "x": 840,
      "y": 195
    },
    {
      "t": 135007,
      "e": 120524,
      "ty": 2,
      "x": 832,
      "y": 201
    },
    {
      "t": 135008,
      "e": 120525,
      "ty": 41,
      "x": 2510,
      "y": 2340,
      "ta": "#jspsych-survey-multi-choice-option-0-1"
    },
    {
      "t": 135099,
      "e": 120616,
      "ty": 6,
      "x": 837,
      "y": 190,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 135108,
      "e": 120616,
      "ty": 2,
      "x": 837,
      "y": 190
    },
    {
      "t": 135208,
      "e": 120716,
      "ty": 2,
      "x": 837,
      "y": 187
    },
    {
      "t": 135257,
      "e": 120765,
      "ty": 41,
      "x": 53325,
      "y": 40329,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 135262,
      "e": 120770,
      "ty": 3,
      "x": 837,
      "y": 187,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 135263,
      "e": 120771,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 135399,
      "e": 120907,
      "ty": 4,
      "x": 53325,
      "y": 40329,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 135400,
      "e": 120908,
      "ty": 5,
      "x": 837,
      "y": 187,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 135401,
      "e": 120909,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf",
      "v": "English"
    },
    {
      "t": 135708,
      "e": 121216,
      "ty": 2,
      "x": 835,
      "y": 185
    },
    {
      "t": 135711,
      "e": 121219,
      "ty": 3,
      "x": 835,
      "y": 185,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 135758,
      "e": 121266,
      "ty": 41,
      "x": 43243,
      "y": 30246,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 135799,
      "e": 121307,
      "ty": 4,
      "x": 43243,
      "y": 30246,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 135799,
      "e": 121307,
      "ty": 5,
      "x": 835,
      "y": 185,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 135865,
      "e": 121373,
      "ty": 7,
      "x": 833,
      "y": 194,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 135899,
      "e": 121407,
      "ty": 6,
      "x": 832,
      "y": 213,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 135908,
      "e": 121416,
      "ty": 2,
      "x": 832,
      "y": 213
    },
    {
      "t": 135917,
      "e": 121425,
      "ty": 7,
      "x": 832,
      "y": 222,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 135966,
      "e": 121474,
      "ty": 6,
      "x": 832,
      "y": 235,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 136008,
      "e": 121516,
      "ty": 2,
      "x": 832,
      "y": 235
    },
    {
      "t": 136008,
      "e": 121516,
      "ty": 41,
      "x": 28120,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 136232,
      "e": 121740,
      "ty": 3,
      "x": 832,
      "y": 235,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 136233,
      "e": 121741,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 136233,
      "e": 121741,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 136319,
      "e": 121827,
      "ty": 4,
      "x": 28120,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 136319,
      "e": 121827,
      "ty": 5,
      "x": 832,
      "y": 235,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 136321,
      "e": 121829,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf",
      "v": "Mandarin or Cantonese"
    },
    {
      "t": 136408,
      "e": 121916,
      "ty": 2,
      "x": 832,
      "y": 239
    },
    {
      "t": 136450,
      "e": 121958,
      "ty": 7,
      "x": 837,
      "y": 248,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 136508,
      "e": 122016,
      "ty": 2,
      "x": 841,
      "y": 251
    },
    {
      "t": 136508,
      "e": 122016,
      "ty": 41,
      "x": 6135,
      "y": 62258,
      "ta": "#jspsych-survey-multi-choice-option-0-2 > label"
    },
    {
      "t": 136608,
      "e": 122116,
      "ty": 2,
      "x": 887,
      "y": 272
    },
    {
      "t": 136708,
      "e": 122216,
      "ty": 2,
      "x": 954,
      "y": 292
    },
    {
      "t": 136758,
      "e": 122266,
      "ty": 41,
      "x": 31464,
      "y": 14123,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 136808,
      "e": 122316,
      "ty": 2,
      "x": 949,
      "y": 310
    },
    {
      "t": 136908,
      "e": 122416,
      "ty": 2,
      "x": 951,
      "y": 366
    },
    {
      "t": 137007,
      "e": 122515,
      "ty": 2,
      "x": 945,
      "y": 369
    },
    {
      "t": 137008,
      "e": 122516,
      "ty": 41,
      "x": 29328,
      "y": 49151,
      "ta": "#jspsych-survey-multi-choice-option-1-0"
    },
    {
      "t": 137408,
      "e": 122916,
      "ty": 2,
      "x": 945,
      "y": 371
    },
    {
      "t": 137508,
      "e": 123016,
      "ty": 41,
      "x": 29328,
      "y": 53832,
      "ta": "#jspsych-survey-multi-choice-option-1-0"
    },
    {
      "t": 137608,
      "e": 123116,
      "ty": 2,
      "x": 957,
      "y": 374
    },
    {
      "t": 137708,
      "e": 123216,
      "ty": 2,
      "x": 957,
      "y": 375
    },
    {
      "t": 137758,
      "e": 123266,
      "ty": 41,
      "x": 30989,
      "y": 63194,
      "ta": "#jspsych-survey-multi-choice-option-1-0"
    },
    {
      "t": 137808,
      "e": 123316,
      "ty": 2,
      "x": 952,
      "y": 375
    },
    {
      "t": 138108,
      "e": 123616,
      "ty": 2,
      "x": 949,
      "y": 375
    },
    {
      "t": 138208,
      "e": 123716,
      "ty": 2,
      "x": 874,
      "y": 374
    },
    {
      "t": 138259,
      "e": 123767,
      "ty": 41,
      "x": 9867,
      "y": 60853,
      "ta": "#jspsych-survey-multi-choice-option-1-0"
    },
    {
      "t": 138308,
      "e": 123816,
      "ty": 2,
      "x": 856,
      "y": 376
    },
    {
      "t": 138408,
      "e": 123916,
      "ty": 2,
      "x": 852,
      "y": 388
    },
    {
      "t": 138508,
      "e": 124016,
      "ty": 41,
      "x": 24424,
      "y": 26214,
      "ta": "#jspsych-survey-multi-choice-option-1-1 > label"
    },
    {
      "t": 139608,
      "e": 125116,
      "ty": 2,
      "x": 854,
      "y": 407
    },
    {
      "t": 139708,
      "e": 125216,
      "ty": 2,
      "x": 865,
      "y": 468
    },
    {
      "t": 139758,
      "e": 125266,
      "ty": 41,
      "x": 48657,
      "y": 29490,
      "ta": "#jspsych-survey-multi-choice-option-1-4 > label"
    },
    {
      "t": 139807,
      "e": 125315,
      "ty": 2,
      "x": 858,
      "y": 477
    },
    {
      "t": 139908,
      "e": 125416,
      "ty": 2,
      "x": 849,
      "y": 481
    },
    {
      "t": 140008,
      "e": 125516,
      "ty": 2,
      "x": 848,
      "y": 481
    },
    {
      "t": 140009,
      "e": 125517,
      "ty": 41,
      "x": 31103,
      "y": 55704,
      "ta": "#jspsych-survey-multi-choice-option-1-4 > label"
    },
    {
      "t": 140108,
      "e": 125616,
      "ty": 2,
      "x": 842,
      "y": 484
    },
    {
      "t": 140170,
      "e": 125678,
      "ty": 6,
      "x": 835,
      "y": 497,
      "ta": "jspsych-survey-multi-choice-response-1[5]_mf"
    },
    {
      "t": 140208,
      "e": 125716,
      "ty": 2,
      "x": 831,
      "y": 506
    },
    {
      "t": 140236,
      "e": 125744,
      "ty": 7,
      "x": 830,
      "y": 508,
      "ta": "jspsych-survey-multi-choice-response-1[5]_mf"
    },
    {
      "t": 140258,
      "e": 125766,
      "ty": 41,
      "x": 5853,
      "y": 52428,
      "ta": "#jspsych-survey-multi-choice-option-1-5 > label"
    },
    {
      "t": 140308,
      "e": 125816,
      "ty": 2,
      "x": 830,
      "y": 508
    },
    {
      "t": 140376,
      "e": 125884,
      "ty": 6,
      "x": 828,
      "y": 507,
      "ta": "jspsych-survey-multi-choice-response-1[5]_mf"
    },
    {
      "t": 140408,
      "e": 125916,
      "ty": 2,
      "x": 828,
      "y": 504
    },
    {
      "t": 140511,
      "e": 125918,
      "ty": 2,
      "x": 828,
      "y": 496
    },
    {
      "t": 140515,
      "e": 125922,
      "ty": 41,
      "x": 7955,
      "y": 5041,
      "ta": "jspsych-survey-multi-choice-response-1[5]_mf"
    },
    {
      "t": 140854,
      "e": 126261,
      "ty": 7,
      "x": 828,
      "y": 493,
      "ta": "jspsych-survey-multi-choice-response-1[5]_mf"
    },
    {
      "t": 140908,
      "e": 126315,
      "ty": 2,
      "x": 834,
      "y": 480
    },
    {
      "t": 140919,
      "e": 126326,
      "ty": 6,
      "x": 835,
      "y": 477,
      "ta": "jspsych-survey-multi-choice-response-1[4]_mf"
    },
    {
      "t": 141003,
      "e": 126410,
      "ty": 7,
      "x": 839,
      "y": 464,
      "ta": "jspsych-survey-multi-choice-response-1[4]_mf"
    },
    {
      "t": 141008,
      "e": 126415,
      "ty": 2,
      "x": 839,
      "y": 464
    },
    {
      "t": 141008,
      "e": 126415,
      "ty": 41,
      "x": 20571,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-1-4 > label"
    },
    {
      "t": 141107,
      "e": 126514,
      "ty": 2,
      "x": 842,
      "y": 452
    },
    {
      "t": 141258,
      "e": 126665,
      "ty": 41,
      "x": 18469,
      "y": 52428,
      "ta": "#jspsych-survey-multi-choice-option-1-3 > label"
    },
    {
      "t": 141307,
      "e": 126714,
      "ty": 2,
      "x": 842,
      "y": 455
    },
    {
      "t": 141407,
      "e": 126814,
      "ty": 2,
      "x": 839,
      "y": 463
    },
    {
      "t": 141456,
      "e": 126863,
      "ty": 3,
      "x": 839,
      "y": 463,
      "ta": "#jspsych-survey-multi-choice-option-1-4"
    },
    {
      "t": 141456,
      "e": 126863,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 141508,
      "e": 126915,
      "ty": 41,
      "x": 4171,
      "y": 7021,
      "ta": "#jspsych-survey-multi-choice-option-1-4"
    },
    {
      "t": 141550,
      "e": 126957,
      "ty": 4,
      "x": 4171,
      "y": 7021,
      "ta": "#jspsych-survey-multi-choice-option-1-4"
    },
    {
      "t": 141551,
      "e": 126958,
      "ty": 5,
      "x": 839,
      "y": 463,
      "ta": "#jspsych-survey-multi-choice-option-1-4"
    },
    {
      "t": 141807,
      "e": 127214,
      "ty": 2,
      "x": 842,
      "y": 465
    },
    {
      "t": 141907,
      "e": 127314,
      "ty": 2,
      "x": 821,
      "y": 484
    },
    {
      "t": 142000,
      "e": 127407,
      "ty": 3,
      "x": 820,
      "y": 485,
      "ta": "html > body"
    },
    {
      "t": 142007,
      "e": 127414,
      "ty": 2,
      "x": 820,
      "y": 485
    },
    {
      "t": 142008,
      "e": 127415,
      "ty": 41,
      "x": 27963,
      "y": 29025,
      "ta": "html > body"
    },
    {
      "t": 142094,
      "e": 127501,
      "ty": 4,
      "x": 27963,
      "y": 29025,
      "ta": "html > body"
    },
    {
      "t": 142095,
      "e": 127502,
      "ty": 5,
      "x": 820,
      "y": 485,
      "ta": "html > body"
    },
    {
      "t": 142207,
      "e": 127614,
      "ty": 2,
      "x": 825,
      "y": 478
    },
    {
      "t": 142221,
      "e": 127628,
      "ty": 6,
      "x": 827,
      "y": 475,
      "ta": "jspsych-survey-multi-choice-response-1[4]_mf"
    },
    {
      "t": 142257,
      "e": 127664,
      "ty": 41,
      "x": 28120,
      "y": 10082,
      "ta": "jspsych-survey-multi-choice-response-1[4]_mf"
    },
    {
      "t": 142302,
      "e": 127709,
      "ty": 3,
      "x": 832,
      "y": 469,
      "ta": "jspsych-survey-multi-choice-response-1[4]_mf"
    },
    {
      "t": 142303,
      "e": 127710,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[4]_mf"
    },
    {
      "t": 142307,
      "e": 127714,
      "ty": 2,
      "x": 832,
      "y": 469
    },
    {
      "t": 142398,
      "e": 127805,
      "ty": 4,
      "x": 28120,
      "y": 10082,
      "ta": "jspsych-survey-multi-choice-response-1[4]_mf"
    },
    {
      "t": 142399,
      "e": 127806,
      "ty": 5,
      "x": 832,
      "y": 469,
      "ta": "jspsych-survey-multi-choice-response-1[4]_mf"
    },
    {
      "t": 142400,
      "e": 127807,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[4]_mf",
      "v": "Fifth"
    },
    {
      "t": 142664,
      "e": 128071,
      "ty": 7,
      "x": 837,
      "y": 465,
      "ta": "jspsych-survey-multi-choice-response-1[4]_mf"
    },
    {
      "t": 142707,
      "e": 128114,
      "ty": 2,
      "x": 1049,
      "y": 325
    },
    {
      "t": 142757,
      "e": 128164,
      "ty": 41,
      "x": 42323,
      "y": 11378,
      "ta": "html > body"
    },
    {
      "t": 142807,
      "e": 128214,
      "ty": 2,
      "x": 1272,
      "y": 168
    },
    {
      "t": 142908,
      "e": 128315,
      "ty": 2,
      "x": 1257,
      "y": 181
    },
    {
      "t": 143007,
      "e": 128414,
      "ty": 2,
      "x": 1116,
      "y": 286
    },
    {
      "t": 143007,
      "e": 128414,
      "ty": 41,
      "x": 38157,
      "y": 16916,
      "ta": "html > body"
    },
    {
      "t": 143107,
      "e": 128514,
      "ty": 2,
      "x": 1077,
      "y": 299
    },
    {
      "t": 143207,
      "e": 128614,
      "ty": 2,
      "x": 1047,
      "y": 303
    },
    {
      "t": 143257,
      "e": 128664,
      "ty": 41,
      "x": 52111,
      "y": 4681,
      "ta": "#jspsych-survey-multi-choice-1 > p"
    },
    {
      "t": 143308,
      "e": 128715,
      "ty": 2,
      "x": 1040,
      "y": 304
    },
    {
      "t": 143407,
      "e": 128814,
      "ty": 2,
      "x": 1047,
      "y": 308
    },
    {
      "t": 143507,
      "e": 128914,
      "ty": 41,
      "x": 0,
      "y": 6553,
      "ta": "#jspsych-survey-multi-choice-1 > p > span"
    },
    {
      "t": 143807,
      "e": 129214,
      "ty": 2,
      "x": 1050,
      "y": 318
    },
    {
      "t": 143908,
      "e": 129315,
      "ty": 2,
      "x": 1027,
      "y": 522
    },
    {
      "t": 144008,
      "e": 129415,
      "ty": 2,
      "x": 1001,
      "y": 537
    },
    {
      "t": 144008,
      "e": 129415,
      "ty": 41,
      "x": 42618,
      "y": 49151,
      "ta": "#jspsych-survey-multi-choice-option-1-6"
    },
    {
      "t": 144207,
      "e": 129614,
      "ty": 1,
      "x": 0,
      "y": 8
    },
    {
      "t": 144307,
      "e": 129714,
      "ty": 1,
      "x": 0,
      "y": 16
    },
    {
      "t": 144607,
      "e": 130014,
      "ty": 2,
      "x": 961,
      "y": 603
    },
    {
      "t": 144707,
      "e": 130114,
      "ty": 2,
      "x": 878,
      "y": 652
    },
    {
      "t": 144757,
      "e": 130164,
      "ty": 41,
      "x": 8461,
      "y": 55704,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 144807,
      "e": 130214,
      "ty": 2,
      "x": 846,
      "y": 660
    },
    {
      "t": 145008,
      "e": 130415,
      "ty": 2,
      "x": 853,
      "y": 674
    },
    {
      "t": 145008,
      "e": 130415,
      "ty": 41,
      "x": 7925,
      "y": 19660,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 145106,
      "e": 130513,
      "ty": 6,
      "x": 839,
      "y": 700,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 145107,
      "e": 130514,
      "ty": 2,
      "x": 839,
      "y": 700
    },
    {
      "t": 145139,
      "e": 130546,
      "ty": 7,
      "x": 821,
      "y": 708,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 145207,
      "e": 130614,
      "ty": 2,
      "x": 810,
      "y": 711
    },
    {
      "t": 145257,
      "e": 130664,
      "ty": 41,
      "x": 27619,
      "y": 42777,
      "ta": "html > body"
    },
    {
      "t": 145607,
      "e": 130665,
      "ty": 6,
      "x": 836,
      "y": 727,
      "ta": "jspsych-survey-multi-choice-response-2[4]_mf"
    },
    {
      "t": 145608,
      "e": 130666,
      "ty": 2,
      "x": 836,
      "y": 727
    },
    {
      "t": 145641,
      "e": 130699,
      "ty": 7,
      "x": 841,
      "y": 730,
      "ta": "jspsych-survey-multi-choice-response-2[4]_mf"
    },
    {
      "t": 145707,
      "e": 130765,
      "ty": 2,
      "x": 851,
      "y": 747
    },
    {
      "t": 145757,
      "e": 130815,
      "ty": 41,
      "x": 7494,
      "y": 2340,
      "ta": "#jspsych-survey-multi-choice-option-2-5"
    },
    {
      "t": 145807,
      "e": 130865,
      "ty": 2,
      "x": 853,
      "y": 752
    },
    {
      "t": 145891,
      "e": 130949,
      "ty": 6,
      "x": 839,
      "y": 756,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 145907,
      "e": 130965,
      "ty": 2,
      "x": 839,
      "y": 756
    },
    {
      "t": 145924,
      "e": 130982,
      "ty": 7,
      "x": 825,
      "y": 758,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 146007,
      "e": 131065,
      "ty": 2,
      "x": 820,
      "y": 759
    },
    {
      "t": 146007,
      "e": 131065,
      "ty": 41,
      "x": 27963,
      "y": 45698,
      "ta": "html > body"
    },
    {
      "t": 146207,
      "e": 131265,
      "ty": 2,
      "x": 825,
      "y": 758
    },
    {
      "t": 146208,
      "e": 131266,
      "ty": 6,
      "x": 826,
      "y": 757,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 146257,
      "e": 131315,
      "ty": 41,
      "x": 0,
      "y": 10082,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 146308,
      "e": 131366,
      "ty": 2,
      "x": 826,
      "y": 757
    },
    {
      "t": 146507,
      "e": 131565,
      "ty": 2,
      "x": 830,
      "y": 761
    },
    {
      "t": 146508,
      "e": 131566,
      "ty": 41,
      "x": 18037,
      "y": 30246,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 146607,
      "e": 131665,
      "ty": 2,
      "x": 832,
      "y": 766
    },
    {
      "t": 146655,
      "e": 131713,
      "ty": 7,
      "x": 832,
      "y": 769,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 146707,
      "e": 131765,
      "ty": 2,
      "x": 832,
      "y": 772
    },
    {
      "t": 146758,
      "e": 131816,
      "ty": 41,
      "x": 2510,
      "y": 63194,
      "ta": "#jspsych-survey-multi-choice-option-2-5"
    },
    {
      "t": 146807,
      "e": 131865,
      "ty": 2,
      "x": 832,
      "y": 775
    },
    {
      "t": 146858,
      "e": 131916,
      "ty": 6,
      "x": 839,
      "y": 761,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 146874,
      "e": 131932,
      "ty": 7,
      "x": 842,
      "y": 749,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 146907,
      "e": 131965,
      "ty": 2,
      "x": 845,
      "y": 739
    },
    {
      "t": 147007,
      "e": 132065,
      "ty": 2,
      "x": 861,
      "y": 662
    },
    {
      "t": 147008,
      "e": 132066,
      "ty": 41,
      "x": 9392,
      "y": 60853,
      "ta": "#jspsych-survey-multi-choice-option-2-1"
    },
    {
      "t": 147107,
      "e": 132165,
      "ty": 2,
      "x": 859,
      "y": 645
    },
    {
      "t": 147208,
      "e": 132266,
      "ty": 2,
      "x": 853,
      "y": 639
    },
    {
      "t": 147257,
      "e": 132315,
      "ty": 41,
      "x": 7256,
      "y": 4681,
      "ta": "#jspsych-survey-multi-choice-option-2-1"
    },
    {
      "t": 147308,
      "e": 132366,
      "ty": 2,
      "x": 848,
      "y": 640
    },
    {
      "t": 147407,
      "e": 132465,
      "ty": 2,
      "x": 844,
      "y": 648
    },
    {
      "t": 147507,
      "e": 132565,
      "ty": 2,
      "x": 838,
      "y": 663
    },
    {
      "t": 147508,
      "e": 132566,
      "ty": 41,
      "x": 3934,
      "y": 63194,
      "ta": "#jspsych-survey-multi-choice-option-2-1"
    },
    {
      "t": 147607,
      "e": 132665,
      "ty": 2,
      "x": 834,
      "y": 666
    },
    {
      "t": 147707,
      "e": 132765,
      "ty": 2,
      "x": 833,
      "y": 665
    },
    {
      "t": 147758,
      "e": 132816,
      "ty": 41,
      "x": 2273,
      "y": 60853,
      "ta": "#jspsych-survey-multi-choice-option-2-1"
    },
    {
      "t": 147807,
      "e": 132865,
      "ty": 2,
      "x": 829,
      "y": 660
    },
    {
      "t": 147907,
      "e": 132965,
      "ty": 2,
      "x": 828,
      "y": 659
    },
    {
      "t": 148007,
      "e": 133065,
      "ty": 2,
      "x": 827,
      "y": 658
    },
    {
      "t": 148008,
      "e": 133066,
      "ty": 41,
      "x": 1405,
      "y": 58981,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 148027,
      "e": 133085,
      "ty": 6,
      "x": 828,
      "y": 655,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 148107,
      "e": 133165,
      "ty": 2,
      "x": 829,
      "y": 654
    },
    {
      "t": 148258,
      "e": 133316,
      "ty": 41,
      "x": 12996,
      "y": 55452,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 148608,
      "e": 133666,
      "ty": 2,
      "x": 830,
      "y": 654
    },
    {
      "t": 148757,
      "e": 133815,
      "ty": 41,
      "x": 18037,
      "y": 55452,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 149007,
      "e": 134065,
      "ty": 2,
      "x": 832,
      "y": 655
    },
    {
      "t": 149008,
      "e": 134066,
      "ty": 41,
      "x": 28120,
      "y": 60493,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 149093,
      "e": 134151,
      "ty": 7,
      "x": 818,
      "y": 647,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 149108,
      "e": 134166,
      "ty": 2,
      "x": 818,
      "y": 647
    },
    {
      "t": 149207,
      "e": 134265,
      "ty": 2,
      "x": 765,
      "y": 628
    },
    {
      "t": 149258,
      "e": 134316,
      "ty": 41,
      "x": 26069,
      "y": 37726,
      "ta": "html > body"
    },
    {
      "t": 149407,
      "e": 134465,
      "ty": 2,
      "x": 770,
      "y": 628
    },
    {
      "t": 149508,
      "e": 134566,
      "ty": 2,
      "x": 772,
      "y": 632
    },
    {
      "t": 149508,
      "e": 134566,
      "ty": 41,
      "x": 26310,
      "y": 37970,
      "ta": "html > body"
    },
    {
      "t": 149758,
      "e": 134816,
      "ty": 41,
      "x": 26344,
      "y": 38091,
      "ta": "html > body"
    },
    {
      "t": 149807,
      "e": 134865,
      "ty": 2,
      "x": 773,
      "y": 635
    },
    {
      "t": 149908,
      "e": 134966,
      "ty": 2,
      "x": 773,
      "y": 637
    },
    {
      "t": 150008,
      "e": 135066,
      "ty": 41,
      "x": 26344,
      "y": 38274,
      "ta": "html > body"
    },
    {
      "t": 150108,
      "e": 135166,
      "ty": 2,
      "x": 773,
      "y": 638
    },
    {
      "t": 150258,
      "e": 135316,
      "ty": 41,
      "x": 26344,
      "y": 38335,
      "ta": "html > body"
    },
    {
      "t": 150407,
      "e": 135465,
      "ty": 2,
      "x": 773,
      "y": 639
    },
    {
      "t": 150507,
      "e": 135565,
      "ty": 2,
      "x": 771,
      "y": 641
    },
    {
      "t": 150508,
      "e": 135566,
      "ty": 41,
      "x": 26275,
      "y": 38517,
      "ta": "html > body"
    },
    {
      "t": 150608,
      "e": 135666,
      "ty": 2,
      "x": 769,
      "y": 642
    },
    {
      "t": 150708,
      "e": 135766,
      "ty": 2,
      "x": 768,
      "y": 642
    },
    {
      "t": 150758,
      "e": 135816,
      "ty": 41,
      "x": 26172,
      "y": 38578,
      "ta": "html > body"
    },
    {
      "t": 151208,
      "e": 136266,
      "ty": 2,
      "x": 773,
      "y": 644
    },
    {
      "t": 151258,
      "e": 136316,
      "ty": 41,
      "x": 27033,
      "y": 38943,
      "ta": "html > body"
    },
    {
      "t": 151308,
      "e": 136366,
      "ty": 2,
      "x": 802,
      "y": 649
    },
    {
      "t": 151407,
      "e": 136465,
      "ty": 2,
      "x": 811,
      "y": 649
    },
    {
      "t": 151507,
      "e": 136565,
      "ty": 2,
      "x": 813,
      "y": 649
    },
    {
      "t": 151508,
      "e": 136566,
      "ty": 41,
      "x": 27722,
      "y": 39004,
      "ta": "html > body"
    },
    {
      "t": 151607,
      "e": 136665,
      "ty": 2,
      "x": 819,
      "y": 647
    },
    {
      "t": 151707,
      "e": 136765,
      "ty": 2,
      "x": 825,
      "y": 647
    },
    {
      "t": 151751,
      "e": 136809,
      "ty": 6,
      "x": 826,
      "y": 647,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 151758,
      "e": 136816,
      "ty": 41,
      "x": 0,
      "y": 20164,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 151807,
      "e": 136865,
      "ty": 2,
      "x": 826,
      "y": 647
    },
    {
      "t": 151952,
      "e": 137010,
      "ty": 3,
      "x": 826,
      "y": 647,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 151953,
      "e": 137011,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[4]_mf"
    },
    {
      "t": 151954,
      "e": 137012,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 152086,
      "e": 137144,
      "ty": 4,
      "x": 0,
      "y": 20164,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 152086,
      "e": 137144,
      "ty": 5,
      "x": 826,
      "y": 647,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 152086,
      "e": 137144,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf",
      "v": "Social Sciences (incl. CogSci)"
    },
    {
      "t": 152408,
      "e": 137466,
      "ty": 2,
      "x": 832,
      "y": 648
    },
    {
      "t": 152447,
      "e": 137505,
      "ty": 7,
      "x": 844,
      "y": 648,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 152507,
      "e": 137565,
      "ty": 2,
      "x": 916,
      "y": 623
    },
    {
      "t": 152508,
      "e": 137566,
      "ty": 41,
      "x": 25394,
      "y": 36044,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 152607,
      "e": 137665,
      "ty": 2,
      "x": 1129,
      "y": 535
    },
    {
      "t": 152708,
      "e": 137766,
      "ty": 2,
      "x": 1133,
      "y": 534
    },
    {
      "t": 152758,
      "e": 137816,
      "ty": 41,
      "x": 38742,
      "y": 32006,
      "ta": "html > body"
    },
    {
      "t": 153208,
      "e": 138266,
      "ty": 2,
      "x": 1132,
      "y": 542
    },
    {
      "t": 153258,
      "e": 138266,
      "ty": 41,
      "x": 38604,
      "y": 32737,
      "ta": "html > body"
    },
    {
      "t": 153308,
      "e": 138316,
      "ty": 2,
      "x": 1129,
      "y": 546
    },
    {
      "t": 154307,
      "e": 139315,
      "ty": 2,
      "x": 1128,
      "y": 548
    },
    {
      "t": 154408,
      "e": 139416,
      "ty": 2,
      "x": 1109,
      "y": 588
    },
    {
      "t": 154507,
      "e": 139515,
      "ty": 41,
      "x": 37915,
      "y": 35292,
      "ta": "html > body"
    },
    {
      "t": 155007,
      "e": 140015,
      "ty": 2,
      "x": 1120,
      "y": 617
    },
    {
      "t": 155008,
      "e": 140016,
      "ty": 41,
      "x": 38294,
      "y": 37057,
      "ta": "html > body"
    },
    {
      "t": 155107,
      "e": 140115,
      "ty": 2,
      "x": 1113,
      "y": 660
    },
    {
      "t": 155208,
      "e": 140216,
      "ty": 2,
      "x": 1067,
      "y": 684
    },
    {
      "t": 155257,
      "e": 140265,
      "ty": 41,
      "x": 52823,
      "y": 11702,
      "ta": "#jspsych-survey-multi-choice-option-2-3"
    },
    {
      "t": 155308,
      "e": 140316,
      "ty": 2,
      "x": 1042,
      "y": 697
    },
    {
      "t": 155408,
      "e": 140416,
      "ty": 2,
      "x": 1036,
      "y": 696
    },
    {
      "t": 155508,
      "e": 140516,
      "ty": 41,
      "x": 50924,
      "y": 9362,
      "ta": "#jspsych-survey-multi-choice-option-2-3"
    },
    {
      "t": 156707,
      "e": 141715,
      "ty": 2,
      "x": 1033,
      "y": 697
    },
    {
      "t": 156757,
      "e": 141765,
      "ty": 41,
      "x": 49026,
      "y": 21064,
      "ta": "#jspsych-survey-multi-choice-option-2-3"
    },
    {
      "t": 156808,
      "e": 141816,
      "ty": 2,
      "x": 1020,
      "y": 710
    },
    {
      "t": 156907,
      "e": 141915,
      "ty": 2,
      "x": 1014,
      "y": 716
    },
    {
      "t": 157008,
      "e": 142016,
      "ty": 2,
      "x": 1010,
      "y": 719
    },
    {
      "t": 157008,
      "e": 142016,
      "ty": 41,
      "x": 44754,
      "y": 63194,
      "ta": "#jspsych-survey-multi-choice-option-2-3"
    },
    {
      "t": 157108,
      "e": 142116,
      "ty": 2,
      "x": 1000,
      "y": 723
    },
    {
      "t": 157208,
      "e": 142216,
      "ty": 2,
      "x": 951,
      "y": 723
    },
    {
      "t": 157258,
      "e": 142266,
      "ty": 41,
      "x": 25293,
      "y": 7021,
      "ta": "#jspsych-survey-multi-choice-option-2-4"
    },
    {
      "t": 157308,
      "e": 142316,
      "ty": 2,
      "x": 917,
      "y": 723
    },
    {
      "t": 157408,
      "e": 142416,
      "ty": 2,
      "x": 902,
      "y": 727
    },
    {
      "t": 157508,
      "e": 142516,
      "ty": 2,
      "x": 866,
      "y": 737
    },
    {
      "t": 157508,
      "e": 142516,
      "ty": 41,
      "x": 24956,
      "y": 42597,
      "ta": "#jspsych-survey-multi-choice-option-2-4 > label"
    },
    {
      "t": 157607,
      "e": 142615,
      "ty": 2,
      "x": 861,
      "y": 738
    },
    {
      "t": 157707,
      "e": 142715,
      "ty": 2,
      "x": 853,
      "y": 738
    },
    {
      "t": 157758,
      "e": 142766,
      "ty": 41,
      "x": 13759,
      "y": 26214,
      "ta": "#jspsych-survey-multi-choice-option-2-4 > label"
    },
    {
      "t": 157800,
      "e": 142808,
      "ty": 6,
      "x": 833,
      "y": 710,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 157808,
      "e": 142816,
      "ty": 2,
      "x": 833,
      "y": 710
    },
    {
      "t": 157850,
      "e": 142858,
      "ty": 7,
      "x": 829,
      "y": 697,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 157908,
      "e": 142916,
      "ty": 2,
      "x": 829,
      "y": 692
    },
    {
      "t": 158007,
      "e": 143015,
      "ty": 2,
      "x": 829,
      "y": 690
    },
    {
      "t": 158007,
      "e": 143015,
      "ty": 41,
      "x": 1798,
      "y": 60853,
      "ta": "#jspsych-survey-multi-choice-option-2-2"
    },
    {
      "t": 158208,
      "e": 143216,
      "ty": 2,
      "x": 829,
      "y": 686
    },
    {
      "t": 158235,
      "e": 143243,
      "ty": 6,
      "x": 831,
      "y": 683,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 158258,
      "e": 143266,
      "ty": 41,
      "x": 28120,
      "y": 40329,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 158308,
      "e": 143316,
      "ty": 2,
      "x": 834,
      "y": 677
    },
    {
      "t": 158508,
      "e": 143516,
      "ty": 41,
      "x": 38202,
      "y": 30246,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 159308,
      "e": 144316,
      "ty": 2,
      "x": 834,
      "y": 679
    },
    {
      "t": 159508,
      "e": 144516,
      "ty": 41,
      "x": 38202,
      "y": 40329,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 159607,
      "e": 144615,
      "ty": 2,
      "x": 836,
      "y": 682
    },
    {
      "t": 159638,
      "e": 144646,
      "ty": 7,
      "x": 840,
      "y": 685,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 159707,
      "e": 144715,
      "ty": 2,
      "x": 878,
      "y": 752
    },
    {
      "t": 159758,
      "e": 144766,
      "ty": 41,
      "x": 21733,
      "y": 14043,
      "ta": "#jspsych-survey-multi-choice-3 > p"
    },
    {
      "t": 159808,
      "e": 144816,
      "ty": 2,
      "x": 908,
      "y": 864
    },
    {
      "t": 159912,
      "e": 144920,
      "ty": 2,
      "x": 904,
      "y": 875
    },
    {
      "t": 160013,
      "e": 145021,
      "ty": 41,
      "x": 19597,
      "y": 16383,
      "ta": "#jspsych-survey-multi-choice-option-3-0"
    },
    {
      "t": 160013,
      "e": 145021,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 160211,
      "e": 145219,
      "ty": 2,
      "x": 902,
      "y": 875
    },
    {
      "t": 160262,
      "e": 145270,
      "ty": 41,
      "x": 16275,
      "y": 16383,
      "ta": "#jspsych-survey-multi-choice-option-3-0"
    },
    {
      "t": 160312,
      "e": 145320,
      "ty": 2,
      "x": 890,
      "y": 875
    },
    {
      "t": 160411,
      "e": 145419,
      "ty": 2,
      "x": 872,
      "y": 877
    },
    {
      "t": 160512,
      "e": 145520,
      "ty": 2,
      "x": 854,
      "y": 882
    },
    {
      "t": 160512,
      "e": 145520,
      "ty": 41,
      "x": 35583,
      "y": 32767,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 160612,
      "e": 145620,
      "ty": 2,
      "x": 840,
      "y": 884
    },
    {
      "t": 160622,
      "e": 145630,
      "ty": 6,
      "x": 838,
      "y": 884,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 160699,
      "e": 145707,
      "ty": 3,
      "x": 835,
      "y": 884,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 160699,
      "e": 145707,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 160700,
      "e": 145708,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 160712,
      "e": 145720,
      "ty": 2,
      "x": 835,
      "y": 884
    },
    {
      "t": 160762,
      "e": 145770,
      "ty": 41,
      "x": 43243,
      "y": 45370,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 160812,
      "e": 145820,
      "ty": 2,
      "x": 834,
      "y": 884
    },
    {
      "t": 160834,
      "e": 145842,
      "ty": 4,
      "x": 38202,
      "y": 45370,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 160835,
      "e": 145843,
      "ty": 5,
      "x": 834,
      "y": 884,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 160835,
      "e": 145843,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf",
      "v": "Male"
    },
    {
      "t": 161012,
      "e": 146020,
      "ty": 41,
      "x": 38202,
      "y": 45370,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 161108,
      "e": 146116,
      "ty": 7,
      "x": 834,
      "y": 891,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 161111,
      "e": 146119,
      "ty": 2,
      "x": 834,
      "y": 891
    },
    {
      "t": 161207,
      "e": 146215,
      "ty": 6,
      "x": 902,
      "y": 952,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 161212,
      "e": 146220,
      "ty": 2,
      "x": 902,
      "y": 952
    },
    {
      "t": 161262,
      "e": 146270,
      "ty": 41,
      "x": 42044,
      "y": 11915,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 161312,
      "e": 146320,
      "ty": 2,
      "x": 911,
      "y": 959
    },
    {
      "t": 161411,
      "e": 146419,
      "ty": 2,
      "x": 913,
      "y": 962
    },
    {
      "t": 161512,
      "e": 146520,
      "ty": 2,
      "x": 914,
      "y": 963
    },
    {
      "t": 161512,
      "e": 146520,
      "ty": 41,
      "x": 43590,
      "y": 21845,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 163700,
      "e": 148708,
      "ty": 3,
      "x": 914,
      "y": 963,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 163701,
      "e": 148709,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 163701,
      "e": 148709,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 164667,
      "e": 149675,
      "ty": 4,
      "x": 43590,
      "y": 21845,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 164668,
      "e": 149676,
      "ty": 5,
      "x": 914,
      "y": 963,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 164674,
      "e": 149682,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 164676,
      "e": 149684,
      "ty": 13,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 164678,
      "e": 149686,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 165011,
      "e": 150019,
      "ty": 2,
      "x": 921,
      "y": 947
    },
    {
      "t": 165011,
      "e": 150019,
      "ty": 41,
      "x": 31441,
      "y": 57137,
      "ta": "html > body"
    },
    {
      "t": 165111,
      "e": 150119,
      "ty": 2,
      "x": 1032,
      "y": 508
    },
    {
      "t": 165211,
      "e": 150219,
      "ty": 2,
      "x": 1026,
      "y": 468
    },
    {
      "t": 165261,
      "e": 150269,
      "ty": 41,
      "x": 35057,
      "y": 27990,
      "ta": "html > body"
    },
    {
      "t": 165511,
      "e": 150519,
      "ty": 2,
      "x": 977,
      "y": 475
    },
    {
      "t": 165511,
      "e": 150519,
      "ty": 41,
      "x": 33370,
      "y": 28416,
      "ta": "html > body"
    },
    {
      "t": 165611,
      "e": 150619,
      "ty": 2,
      "x": 920,
      "y": 472
    },
    {
      "t": 165761,
      "e": 150769,
      "ty": 41,
      "x": 31407,
      "y": 28234,
      "ta": "html > body"
    },
    {
      "t": 166025,
      "e": 151033,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 167011,
      "e": 152019,
      "ty": 41,
      "x": 30725,
      "y": 30231,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 167011,
      "e": 152019,
      "ty": 2,
      "x": 918,
      "y": 507
    },
    {
      "t": 167111,
      "e": 152119,
      "ty": 2,
      "x": 920,
      "y": 610
    },
    {
      "t": 167261,
      "e": 152269,
      "ty": 41,
      "x": 30824,
      "y": 38035,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 167711,
      "e": 152719,
      "ty": 2,
      "x": 920,
      "y": 612
    },
    {
      "t": 167761,
      "e": 152769,
      "ty": 41,
      "x": 30627,
      "y": 38267,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 167811,
      "e": 152819,
      "ty": 2,
      "x": 907,
      "y": 614
    },
    {
      "t": 167911,
      "e": 152919,
      "ty": 2,
      "x": 772,
      "y": 580
    },
    {
      "t": 168011,
      "e": 153019,
      "ty": 2,
      "x": 479,
      "y": 439
    },
    {
      "t": 168011,
      "e": 153019,
      "ty": 41,
      "x": 51524,
      "y": 18022,
      "ta": "> div.masterdiv > div:[2] > div > p:[3] > b"
    },
    {
      "t": 168111,
      "e": 153119,
      "ty": 2,
      "x": 466,
      "y": 410
    },
    {
      "t": 168211,
      "e": 153219,
      "ty": 2,
      "x": 467,
      "y": 376
    },
    {
      "t": 168262,
      "e": 153270,
      "ty": 41,
      "x": 8587,
      "y": 37058,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 168311,
      "e": 153319,
      "ty": 2,
      "x": 468,
      "y": 375
    },
    {
      "t": 168811,
      "e": 153819,
      "ty": 2,
      "x": 469,
      "y": 374
    },
    {
      "t": 169012,
      "e": 154020,
      "ty": 41,
      "x": 8636,
      "y": 36278,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 170012,
      "e": 155020,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 171311,
      "e": 156319,
      "ty": 2,
      "x": 472,
      "y": 380
    },
    {
      "t": 171411,
      "e": 156419,
      "ty": 2,
      "x": 485,
      "y": 398
    },
    {
      "t": 171511,
      "e": 156519,
      "ty": 2,
      "x": 509,
      "y": 413
    },
    {
      "t": 171511,
      "e": 156519,
      "ty": 41,
      "x": 10604,
      "y": 15225,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 171612,
      "e": 156620,
      "ty": 2,
      "x": 519,
      "y": 417
    },
    {
      "t": 171711,
      "e": 156719,
      "ty": 2,
      "x": 524,
      "y": 420
    },
    {
      "t": 171762,
      "e": 156770,
      "ty": 41,
      "x": 11391,
      "y": 16152,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 171811,
      "e": 156819,
      "ty": 2,
      "x": 525,
      "y": 421
    },
    {
      "t": 176012,
      "e": 161020,
      "ty": 2,
      "x": 647,
      "y": 490
    },
    {
      "t": 176012,
      "e": 161020,
      "ty": 41,
      "x": 17393,
      "y": 23600,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 176111,
      "e": 161119,
      "ty": 2,
      "x": 776,
      "y": 525
    },
    {
      "t": 176211,
      "e": 161219,
      "ty": 2,
      "x": 772,
      "y": 516
    },
    {
      "t": 176262,
      "e": 161270,
      "ty": 41,
      "x": 23198,
      "y": 32182,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 176312,
      "e": 161320,
      "ty": 2,
      "x": 762,
      "y": 511
    },
    {
      "t": 176411,
      "e": 161419,
      "ty": 2,
      "x": 754,
      "y": 507
    },
    {
      "t": 176511,
      "e": 161519,
      "ty": 2,
      "x": 750,
      "y": 505
    },
    {
      "t": 176512,
      "e": 161520,
      "ty": 41,
      "x": 22460,
      "y": 29451,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 176611,
      "e": 161619,
      "ty": 2,
      "x": 748,
      "y": 503
    },
    {
      "t": 176761,
      "e": 161769,
      "ty": 41,
      "x": 22362,
      "y": 28671,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 177411,
      "e": 162419,
      "ty": 2,
      "x": 748,
      "y": 502
    },
    {
      "t": 177512,
      "e": 162520,
      "ty": 41,
      "x": 22362,
      "y": 28281,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 178911,
      "e": 163919,
      "ty": 2,
      "x": 728,
      "y": 475
    },
    {
      "t": 179012,
      "e": 164020,
      "ty": 2,
      "x": 721,
      "y": 469
    },
    {
      "t": 179012,
      "e": 164020,
      "ty": 41,
      "x": 21034,
      "y": 15408,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 179112,
      "e": 164120,
      "ty": 2,
      "x": 712,
      "y": 466
    },
    {
      "t": 179211,
      "e": 164219,
      "ty": 2,
      "x": 709,
      "y": 466
    },
    {
      "t": 179262,
      "e": 164270,
      "ty": 41,
      "x": 20443,
      "y": 14238,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 180012,
      "e": 165020,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 184912,
      "e": 169270,
      "ty": 2,
      "x": 742,
      "y": 467
    },
    {
      "t": 185012,
      "e": 169370,
      "ty": 2,
      "x": 1183,
      "y": 467
    },
    {
      "t": 185012,
      "e": 169370,
      "ty": 41,
      "x": 43763,
      "y": 14628,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 185112,
      "e": 169470,
      "ty": 2,
      "x": 1374,
      "y": 467
    },
    {
      "t": 185212,
      "e": 169570,
      "ty": 2,
      "x": 1453,
      "y": 464
    },
    {
      "t": 185262,
      "e": 169620,
      "ty": 41,
      "x": 57833,
      "y": 10727,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 185312,
      "e": 169670,
      "ty": 2,
      "x": 1510,
      "y": 427
    },
    {
      "t": 185412,
      "e": 169770,
      "ty": 2,
      "x": 1568,
      "y": 371
    },
    {
      "t": 185512,
      "e": 169870,
      "ty": 2,
      "x": 1562,
      "y": 364
    },
    {
      "t": 185513,
      "e": 169871,
      "ty": 41,
      "x": 62408,
      "y": 28476,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 185612,
      "e": 169970,
      "ty": 2,
      "x": 1532,
      "y": 360
    },
    {
      "t": 185712,
      "e": 170070,
      "ty": 2,
      "x": 1530,
      "y": 360
    },
    {
      "t": 185763,
      "e": 170121,
      "ty": 41,
      "x": 60785,
      "y": 25355,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 185812,
      "e": 170170,
      "ty": 2,
      "x": 1528,
      "y": 361
    },
    {
      "t": 185911,
      "e": 170269,
      "ty": 2,
      "x": 1415,
      "y": 362
    },
    {
      "t": 186010,
      "e": 170368,
      "ty": 2,
      "x": 976,
      "y": 379
    },
    {
      "t": 186011,
      "e": 170369,
      "ty": 41,
      "x": 33579,
      "y": 40179,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 186112,
      "e": 170470,
      "ty": 2,
      "x": 720,
      "y": 414
    },
    {
      "t": 186212,
      "e": 170570,
      "ty": 2,
      "x": 614,
      "y": 439
    },
    {
      "t": 186262,
      "e": 170620,
      "ty": 41,
      "x": 12178,
      "y": 7216,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 186311,
      "e": 170669,
      "ty": 2,
      "x": 477,
      "y": 448
    },
    {
      "t": 186412,
      "e": 170770,
      "ty": 2,
      "x": 403,
      "y": 429
    },
    {
      "t": 186512,
      "e": 170870,
      "ty": 41,
      "x": 5389,
      "y": 17078,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 186712,
      "e": 171070,
      "ty": 2,
      "x": 408,
      "y": 428
    },
    {
      "t": 186765,
      "e": 171123,
      "ty": 41,
      "x": 6865,
      "y": 16731,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 186812,
      "e": 171170,
      "ty": 2,
      "x": 452,
      "y": 425
    },
    {
      "t": 186911,
      "e": 171269,
      "ty": 2,
      "x": 459,
      "y": 425
    },
    {
      "t": 187011,
      "e": 171369,
      "ty": 2,
      "x": 480,
      "y": 426
    },
    {
      "t": 187011,
      "e": 171369,
      "ty": 41,
      "x": 9177,
      "y": 16731,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 187111,
      "e": 171469,
      "ty": 2,
      "x": 491,
      "y": 429
    },
    {
      "t": 187210,
      "e": 171568,
      "ty": 2,
      "x": 517,
      "y": 441
    },
    {
      "t": 187261,
      "e": 171619,
      "ty": 41,
      "x": 64020,
      "y": 37682,
      "ta": "> div.masterdiv > div:[2] > div > p:[3] > b"
    },
    {
      "t": 187311,
      "e": 171669,
      "ty": 2,
      "x": 531,
      "y": 448
    },
    {
      "t": 187411,
      "e": 171769,
      "ty": 2,
      "x": 540,
      "y": 454
    },
    {
      "t": 187511,
      "e": 171869,
      "ty": 2,
      "x": 543,
      "y": 459
    },
    {
      "t": 187511,
      "e": 171869,
      "ty": 41,
      "x": 12276,
      "y": 11507,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 187611,
      "e": 171969,
      "ty": 2,
      "x": 543,
      "y": 460
    },
    {
      "t": 187761,
      "e": 172119,
      "ty": 41,
      "x": 12276,
      "y": 11897,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 187911,
      "e": 172269,
      "ty": 2,
      "x": 567,
      "y": 473
    },
    {
      "t": 188011,
      "e": 172369,
      "ty": 2,
      "x": 621,
      "y": 490
    },
    {
      "t": 188012,
      "e": 172370,
      "ty": 41,
      "x": 16114,
      "y": 23600,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 188111,
      "e": 172469,
      "ty": 2,
      "x": 641,
      "y": 490
    },
    {
      "t": 188211,
      "e": 172569,
      "ty": 2,
      "x": 649,
      "y": 492
    },
    {
      "t": 188262,
      "e": 172620,
      "ty": 41,
      "x": 17491,
      "y": 24380,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 189111,
      "e": 173469,
      "ty": 2,
      "x": 648,
      "y": 483
    },
    {
      "t": 189211,
      "e": 173569,
      "ty": 2,
      "x": 641,
      "y": 473
    },
    {
      "t": 189262,
      "e": 173620,
      "ty": 41,
      "x": 17098,
      "y": 13848,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 189311,
      "e": 173669,
      "ty": 2,
      "x": 645,
      "y": 460
    },
    {
      "t": 189411,
      "e": 173769,
      "ty": 2,
      "x": 667,
      "y": 454
    },
    {
      "t": 189511,
      "e": 173869,
      "ty": 2,
      "x": 695,
      "y": 455
    },
    {
      "t": 189512,
      "e": 173870,
      "ty": 41,
      "x": 19754,
      "y": 9947,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 189611,
      "e": 173969,
      "ty": 2,
      "x": 696,
      "y": 455
    },
    {
      "t": 189761,
      "e": 174119,
      "ty": 41,
      "x": 19951,
      "y": 10727,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 189811,
      "e": 174169,
      "ty": 2,
      "x": 700,
      "y": 457
    },
    {
      "t": 190011,
      "e": 174369,
      "ty": 41,
      "x": 20000,
      "y": 10727,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 190012,
      "e": 174370,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 192911,
      "e": 177269,
      "ty": 2,
      "x": 740,
      "y": 476
    },
    {
      "t": 193011,
      "e": 177369,
      "ty": 2,
      "x": 859,
      "y": 515
    },
    {
      "t": 193011,
      "e": 177369,
      "ty": 41,
      "x": 27823,
      "y": 33352,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 193112,
      "e": 177470,
      "ty": 2,
      "x": 876,
      "y": 523
    },
    {
      "t": 193211,
      "e": 177569,
      "ty": 2,
      "x": 883,
      "y": 528
    },
    {
      "t": 193261,
      "e": 177619,
      "ty": 41,
      "x": 29102,
      "y": 39203,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 193311,
      "e": 177669,
      "ty": 2,
      "x": 886,
      "y": 531
    },
    {
      "t": 193511,
      "e": 177869,
      "ty": 41,
      "x": 29151,
      "y": 39594,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 198612,
      "e": 182869,
      "ty": 2,
      "x": 884,
      "y": 533
    },
    {
      "t": 198761,
      "e": 183018,
      "ty": 41,
      "x": 29003,
      "y": 40764,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 198811,
      "e": 183068,
      "ty": 2,
      "x": 882,
      "y": 534
    },
    {
      "t": 198912,
      "e": 183169,
      "ty": 2,
      "x": 880,
      "y": 535
    },
    {
      "t": 199011,
      "e": 183268,
      "ty": 2,
      "x": 879,
      "y": 536
    },
    {
      "t": 199012,
      "e": 183269,
      "ty": 41,
      "x": 28807,
      "y": 41544,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 200012,
      "e": 184269,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 207112,
      "e": 188269,
      "ty": 2,
      "x": 877,
      "y": 537
    },
    {
      "t": 207212,
      "e": 188369,
      "ty": 2,
      "x": 870,
      "y": 544
    },
    {
      "t": 207262,
      "e": 188419,
      "ty": 41,
      "x": 27774,
      "y": 48566,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 207312,
      "e": 188469,
      "ty": 2,
      "x": 850,
      "y": 565
    },
    {
      "t": 207411,
      "e": 188568,
      "ty": 2,
      "x": 819,
      "y": 606
    },
    {
      "t": 207511,
      "e": 188668,
      "ty": 2,
      "x": 808,
      "y": 622
    },
    {
      "t": 207512,
      "e": 188669,
      "ty": 41,
      "x": 25314,
      "y": 3803,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 207612,
      "e": 188769,
      "ty": 2,
      "x": 806,
      "y": 630
    },
    {
      "t": 207712,
      "e": 188869,
      "ty": 2,
      "x": 807,
      "y": 632
    },
    {
      "t": 207762,
      "e": 188919,
      "ty": 41,
      "x": 25264,
      "y": 9654,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 208712,
      "e": 189869,
      "ty": 2,
      "x": 831,
      "y": 738
    },
    {
      "t": 208762,
      "e": 189919,
      "ty": 41,
      "x": 27134,
      "y": 60266,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 208812,
      "e": 189969,
      "ty": 2,
      "x": 845,
      "y": 812
    },
    {
      "t": 208912,
      "e": 190069,
      "ty": 2,
      "x": 846,
      "y": 812
    },
    {
      "t": 209011,
      "e": 190168,
      "ty": 41,
      "x": 27183,
      "y": 61424,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 209112,
      "e": 190269,
      "ty": 2,
      "x": 847,
      "y": 811
    },
    {
      "t": 209211,
      "e": 190368,
      "ty": 2,
      "x": 851,
      "y": 811
    },
    {
      "t": 209261,
      "e": 190418,
      "ty": 41,
      "x": 29495,
      "y": 36278,
      "ta": "> div.masterdiv > div:[2] > div > p:[6]"
    },
    {
      "t": 209311,
      "e": 190468,
      "ty": 2,
      "x": 957,
      "y": 891
    },
    {
      "t": 209411,
      "e": 190568,
      "ty": 2,
      "x": 996,
      "y": 976
    },
    {
      "t": 209416,
      "e": 190573,
      "ty": 6,
      "x": 998,
      "y": 990,
      "ta": "#start"
    },
    {
      "t": 209496,
      "e": 190653,
      "ty": 7,
      "x": 1000,
      "y": 1012,
      "ta": "#start"
    },
    {
      "t": 209511,
      "e": 190668,
      "ty": 2,
      "x": 1000,
      "y": 1012
    },
    {
      "t": 209511,
      "e": 190668,
      "ty": 41,
      "x": 51725,
      "y": 21119,
      "ta": "> div.masterdiv > div:[3]"
    },
    {
      "t": 209658,
      "e": 190815,
      "ty": 6,
      "x": 999,
      "y": 1010,
      "ta": "#start"
    },
    {
      "t": 209711,
      "e": 190868,
      "ty": 2,
      "x": 994,
      "y": 1003
    },
    {
      "t": 209761,
      "e": 190918,
      "ty": 41,
      "x": 44509,
      "y": 41832,
      "ta": "#start"
    },
    {
      "t": 209811,
      "e": 190968,
      "ty": 2,
      "x": 991,
      "y": 999
    },
    {
      "t": 209930,
      "e": 191087,
      "ty": 3,
      "x": 991,
      "y": 999,
      "ta": "#start"
    },
    {
      "t": 209931,
      "e": 191088,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 210138,
      "e": 191295,
      "ty": 4,
      "x": 44509,
      "y": 41832,
      "ta": "#start"
    },
    {
      "t": 210139,
      "e": 191296,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 210140,
      "e": 191297,
      "ty": 5,
      "x": 991,
      "y": 999,
      "ta": "#start"
    },
    {
      "t": 210142,
      "e": 191299,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 210611,
      "e": 191768,
      "ty": 2,
      "x": 988,
      "y": 992
    },
    {
      "t": 210711,
      "e": 191868,
      "ty": 2,
      "x": 987,
      "y": 985
    },
    {
      "t": 210761,
      "e": 191918,
      "ty": 41,
      "x": 33680,
      "y": 59328,
      "ta": "html > body"
    },
    {
      "t": 210811,
      "e": 191968,
      "ty": 2,
      "x": 985,
      "y": 981
    },
    {
      "t": 211011,
      "e": 192168,
      "ty": 41,
      "x": 33645,
      "y": 59206,
      "ta": "html > body"
    },
    {
      "t": 211191,
      "e": 192348,
      "ty": 38,
      "x": 8,
      "y": 0
    },
    {
      "t": 213043,
      "e": 194200,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":56},{\"id\":57},{\"id\":58},{\"id\":59},{\"id\":60},{\"id\":61},{\"id\":62},{\"id\":63},{\"id\":64},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":72},{\"id\":73},{\"id\":74},{\"id\":75},{\"id\":76},{\"id\":77},{\"id\":78},{\"id\":79},{\"id\":80},{\"id\":81},{\"id\":82},{\"id\":83},{\"id\":84},{\"id\":85},{\"id\":86},{\"id\":87},{\"id\":88},{\"id\":89},{\"id\":90},{\"id\":91},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":96},{\"id\":97},{\"id\":98},{\"id\":99},{\"id\":100},{\"id\":101},{\"id\":102},{\"id\":103},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":109},{\"id\":110},{\"id\":111},{\"id\":112},{\"id\":113},{\"id\":114},{\"id\":115},{\"id\":116},{\"id\":117},{\"id\":118},{\"id\":119},{\"id\":120},{\"id\":121},{\"id\":122},{\"id\":123},{\"id\":124},{\"id\":125},{\"id\":126},{\"id\":127},{\"id\":128},{\"id\":129},{\"id\":130},{\"id\":131},{\"id\":132},{\"id\":133},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":141},{\"id\":142},{\"id\":143},{\"id\":144},{\"id\":145},{\"id\":146},{\"id\":147},{\"id\":148},{\"id\":149},{\"id\":150},{\"id\":151},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":155},{\"id\":156},{\"id\":157},{\"id\":158},{\"id\":159},{\"id\":160},{\"id\":161},{\"id\":162},{\"id\":163},{\"id\":164},{\"id\":165},{\"id\":166},{\"id\":167},{\"id\":168},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":172},{\"id\":173},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":178},{\"id\":179},{\"id\":180},{\"id\":181},{\"id\":182},{\"id\":183},{\"id\":184},{\"id\":185},{\"id\":186},{\"id\":187},{\"id\":188},{\"id\":189},{\"id\":190},{\"id\":191},{\"id\":192},{\"id\":193},{\"id\":194},{\"id\":195},{\"id\":196},{\"id\":197},{\"id\":198},{\"id\":199},{\"id\":200},{\"id\":201},{\"id\":202},{\"id\":203},{\"id\":204},{\"id\":205},{\"id\":206},{\"id\":207},{\"id\":208},{\"id\":209},{\"id\":210},{\"id\":211},{\"id\":212},{\"id\":213},{\"id\":214},{\"id\":215},{\"id\":216},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":220},{\"id\":221},{\"id\":222},{\"id\":223},{\"id\":224},{\"id\":225},{\"id\":226},{\"id\":227},{\"id\":228},{\"id\":229},{\"id\":230},{\"id\":231},{\"id\":232},{\"id\":233},{\"id\":234},{\"id\":235},{\"id\":236},{\"id\":237},{\"id\":238},{\"id\":239},{\"id\":240},{\"id\":241},{\"id\":242},{\"id\":243},{\"id\":244},{\"id\":245},{\"id\":246},{\"id\":247},{\"id\":248},{\"id\":249},{\"id\":250},{\"id\":251},{\"id\":252},{\"id\":253},{\"id\":254},{\"id\":255},{\"id\":256},{\"id\":257},{\"id\":258},{\"id\":259},{\"id\":260},{\"id\":261},{\"id\":262},{\"id\":263},{\"id\":264},{\"id\":265},{\"id\":266},{\"id\":267},{\"id\":268},{\"id\":269},{\"id\":270},{\"id\":271},{\"id\":272},{\"id\":273},{\"id\":274},{\"id\":275},{\"id\":276},{\"id\":277},{\"id\":278},{\"id\":279},{\"id\":280},{\"id\":281},{\"id\":282},{\"id\":283},{\"id\":284},{\"id\":285},{\"id\":286},{\"id\":287},{\"id\":288},{\"id\":289},{\"id\":290},{\"id\":291},{\"id\":292},{\"id\":293},{\"id\":294},{\"id\":295},{\"id\":296},{\"id\":297},{\"id\":298},{\"id\":299},{\"id\":300},{\"id\":301},{\"id\":302},{\"id\":303},{\"id\":304},{\"id\":305},{\"id\":306},{\"id\":307},{\"id\":308},{\"id\":309},{\"id\":310},{\"id\":311},{\"id\":312},{\"id\":313},{\"id\":314},{\"id\":315},{\"id\":316},{\"id\":317},{\"id\":318},{\"id\":319},{\"id\":320},{\"id\":321},{\"id\":322},{\"id\":323},{\"id\":324},{\"id\":325},{\"id\":326},{\"id\":327},{\"id\":328},{\"id\":329},{\"id\":330},{\"id\":331},{\"id\":332},{\"id\":333},{\"id\":334},{\"id\":335},{\"id\":336},{\"id\":337},{\"id\":338},{\"id\":339},{\"id\":340},{\"id\":341},{\"id\":342},{\"id\":343},{\"id\":344},{\"id\":345},{\"id\":346},{\"id\":347},{\"id\":348},{\"id\":349},{\"id\":350},{\"id\":351},{\"id\":352},{\"id\":353},{\"id\":354},{\"id\":355},{\"id\":356},{\"id\":357},{\"id\":358},{\"id\":359},{\"id\":360},{\"id\":361},{\"id\":362},{\"id\":363},{\"id\":364},{\"id\":365},{\"id\":366},{\"id\":367},{\"id\":368},{\"id\":369},{\"id\":370},{\"id\":371},{\"id\":372},{\"id\":373},{\"id\":374},{\"id\":375},{\"id\":376},{\"id\":377},{\"id\":378},{\"id\":379},{\"id\":380},{\"id\":381},{\"id\":382},{\"id\":383},{\"id\":384},{\"id\":385},{\"id\":386},{\"id\":387},{\"id\":388},{\"id\":389},{\"id\":390},{\"id\":391},{\"id\":392},{\"id\":393},{\"id\":394},{\"id\":395},{\"id\":396},{\"id\":397},{\"id\":398},{\"id\":399},{\"id\":400},{\"id\":401},{\"id\":402},{\"id\":403},{\"id\":404},{\"id\":405},{\"id\":406},{\"id\":407},{\"id\":408},{\"id\":409},{\"id\":410},{\"id\":411},{\"id\":412},{\"id\":413},{\"id\":414},{\"id\":415},{\"id\":416},{\"id\":417},{\"id\":418},{\"id\":419},{\"id\":420},{\"id\":421},{\"id\":422},{\"id\":423},{\"id\":424},{\"id\":425},{\"id\":426},{\"id\":427},{\"id\":428},{\"id\":429},{\"id\":430},{\"id\":431},{\"id\":432},{\"id\":433},{\"id\":434},{\"id\":435},{\"id\":436},{\"id\":437},{\"id\":438},{\"id\":439},{\"id\":440},{\"id\":441},{\"id\":442},{\"id\":443},{\"id\":444},{\"id\":445},{\"id\":446},{\"id\":447},{\"id\":448},{\"id\":449},{\"id\":450},{\"id\":451},{\"id\":452},{\"id\":453},{\"id\":454},{\"id\":455},{\"id\":456},{\"id\":457},{\"id\":458},{\"id\":459},{\"id\":460},{\"id\":461},{\"id\":462},{\"id\":463},{\"id\":464},{\"id\":465},{\"id\":466},{\"id\":467},{\"id\":468},{\"id\":469},{\"id\":470},{\"id\":471},{\"id\":472},{\"id\":473},{\"id\":474},{\"id\":475},{\"id\":476},{\"id\":477},{\"id\":478},{\"id\":479},{\"id\":480},{\"id\":481},{\"id\":482},{\"id\":483},{\"id\":484},{\"id\":485},{\"id\":486},{\"id\":487},{\"id\":488},{\"id\":489},{\"id\":490},{\"id\":491},{\"id\":492},{\"id\":493},{\"id\":494},{\"id\":495},{\"id\":496},{\"id\":497},{\"id\":498},{\"id\":499},{\"id\":500},{\"id\":501},{\"id\":502},{\"id\":503},{\"id\":504},{\"id\":505},{\"id\":506},{\"id\":507},{\"id\":508},{\"id\":509},{\"id\":510},{\"id\":511},{\"id\":512},{\"id\":513},{\"id\":514},{\"id\":515},{\"id\":516},{\"id\":517},{\"id\":518},{\"id\":519},{\"id\":520},{\"id\":521},{\"id\":522},{\"id\":523},{\"id\":524},{\"id\":525},{\"id\":526},{\"id\":527},{\"id\":528},{\"id\":529},{\"id\":530},{\"id\":531},{\"id\":532},{\"id\":533},{\"id\":534},{\"id\":535},{\"id\":536},{\"id\":537},{\"id\":538},{\"id\":539},{\"id\":540},{\"id\":541},{\"id\":542},{\"id\":543},{\"id\":544},{\"id\":545},{\"id\":546},{\"id\":547},{\"id\":548},{\"id\":549},{\"id\":550},{\"id\":551},{\"id\":552},{\"id\":553},{\"id\":554},{\"id\":555},{\"id\":556},{\"id\":557},{\"id\":558},{\"id\":559},{\"id\":560},{\"id\":561},{\"id\":562},{\"id\":563},{\"id\":564},{\"id\":565},{\"id\":566},{\"id\":567},{\"id\":568},{\"id\":569},{\"id\":570},{\"id\":571},{\"id\":572},{\"id\":573},{\"id\":574},{\"id\":575},{\"id\":576},{\"id\":577},{\"id\":578},{\"id\":579},{\"id\":580},{\"id\":581},{\"id\":582},{\"id\":583},{\"id\":584},{\"id\":585},{\"id\":586},{\"id\":587},{\"id\":588},{\"id\":589},{\"id\":590},{\"id\":591},{\"id\":592},{\"id\":593},{\"id\":594},{\"id\":595},{\"id\":596},{\"id\":597},{\"id\":598},{\"id\":599},{\"id\":600},{\"id\":601},{\"id\":602},{\"id\":603},{\"id\":604},{\"id\":605},{\"id\":606},{\"id\":607},{\"id\":608},{\"id\":609},{\"id\":610},{\"id\":611},{\"id\":612},{\"id\":613},{\"id\":614},{\"id\":615},{\"id\":616},{\"id\":617},{\"id\":618},{\"id\":619},{\"id\":620},{\"id\":621},{\"id\":622},{\"id\":623},{\"id\":624},{\"id\":625},{\"id\":626},{\"id\":627},{\"id\":628},{\"id\":629},{\"id\":630},{\"id\":631},{\"id\":632},{\"id\":633},{\"id\":634},{\"id\":635},{\"id\":636},{\"id\":637},{\"id\":638},{\"id\":639},{\"id\":640},{\"id\":641},{\"id\":642},{\"id\":643},{\"id\":644},{\"id\":645},{\"id\":646},{\"id\":647},{\"id\":648},{\"id\":649},{\"id\":650},{\"id\":651},{\"id\":652},{\"id\":653},{\"id\":654},{\"id\":655},{\"id\":656},{\"id\":657},{\"id\":658},{\"id\":659},{\"id\":660},{\"id\":661},{\"id\":662},{\"id\":663},{\"id\":664},{\"id\":665},{\"id\":666},{\"id\":667},{\"id\":668},{\"id\":669},{\"id\":670},{\"id\":671},{\"id\":672},{\"id\":673},{\"id\":674},{\"id\":675},{\"id\":676},{\"id\":677},{\"id\":678},{\"id\":679},{\"id\":680},{\"id\":681},{\"id\":682},{\"id\":683},{\"id\":684},{\"id\":685},{\"id\":686},{\"id\":687},{\"id\":688},{\"id\":689},{\"id\":690},{\"id\":691},{\"id\":692},{\"id\":693},{\"id\":694},{\"id\":695},{\"id\":696},{\"id\":697},{\"id\":698},{\"id\":699},{\"id\":700},{\"id\":701},{\"id\":702},{\"id\":703},{\"id\":704},{\"id\":705},{\"id\":706},{\"id\":707},{\"id\":708},{\"id\":709},{\"id\":710},{\"id\":711},{\"id\":712},{\"id\":713},{\"id\":714},{\"id\":715},{\"id\":716},{\"id\":717},{\"id\":718},{\"id\":719},{\"id\":720},{\"id\":721},{\"id\":722},{\"id\":723},{\"id\":724},{\"id\":725},{\"id\":726},{\"id\":727},{\"id\":728},{\"id\":729},{\"id\":730},{\"id\":731},{\"id\":732},{\"id\":733},{\"id\":734},{\"id\":735},{\"id\":736},{\"id\":737},{\"id\":738},{\"id\":739},{\"id\":740},{\"id\":741},{\"id\":742},{\"id\":743},{\"id\":744},{\"id\":745},{\"id\":746},{\"id\":747},{\"id\":748},{\"id\":749},{\"id\":750},{\"id\":751},{\"id\":752},{\"id\":753},{\"id\":754},{\"id\":755},{\"id\":756},{\"id\":757},{\"id\":758},{\"id\":759},{\"id\":760},{\"id\":761},{\"id\":762},{\"id\":763},{\"id\":764},{\"id\":765},{\"id\":766},{\"id\":767},{\"id\":768},{\"id\":769},{\"id\":770},{\"id\":771},{\"id\":772},{\"id\":773},{\"id\":774},{\"id\":775},{\"id\":776},{\"id\":777},{\"id\":778},{\"id\":779},{\"id\":780},{\"id\":781},{\"id\":782},{\"id\":783},{\"id\":784},{\"id\":785},{\"id\":786},{\"id\":787},{\"id\":788},{\"id\":789},{\"id\":790},{\"id\":791},{\"id\":792},{\"id\":793},{\"id\":794},{\"id\":795},{\"id\":796},{\"id\":797},{\"id\":798},{\"id\":799},{\"id\":800},{\"id\":801},{\"id\":802},{\"id\":803},{\"id\":804},{\"id\":805},{\"id\":806},{\"id\":807},{\"id\":808},{\"id\":809},{\"id\":810},{\"id\":811},{\"id\":812},{\"id\":813},{\"id\":814},{\"id\":815},{\"id\":816},{\"id\":817},{\"id\":818},{\"id\":819},{\"id\":820},{\"id\":821},{\"id\":822},{\"id\":823},{\"id\":824},{\"id\":825},{\"id\":826},{\"id\":827},{\"id\":828},{\"id\":829},{\"id\":830},{\"id\":831},{\"id\":832},{\"id\":833},{\"id\":834},{\"id\":835},{\"id\":836},{\"id\":837},{\"id\":838},{\"id\":839},{\"id\":840},{\"id\":841},{\"id\":842},{\"id\":843},{\"id\":844},{\"id\":845},{\"id\":846},{\"id\":847},{\"id\":848},{\"id\":849},{\"id\":850},{\"id\":851},{\"id\":852},{\"id\":853},{\"id\":854},{\"id\":855},{\"id\":856},{\"id\":857},{\"id\":858},{\"id\":859},{\"id\":860},{\"id\":861},{\"id\":862},{\"id\":863},{\"id\":864},{\"id\":865},{\"id\":866},{\"id\":867},{\"id\":868},{\"id\":869},{\"id\":870},{\"id\":871},{\"id\":872},{\"id\":873},{\"id\":874},{\"id\":875},{\"id\":876},{\"id\":877},{\"id\":878},{\"id\":879},{\"id\":880},{\"id\":881},{\"id\":882},{\"id\":883},{\"id\":884},{\"id\":885},{\"id\":886},{\"id\":887},{\"id\":888},{\"id\":889},{\"id\":890},{\"id\":891},{\"id\":892},{\"id\":893},{\"id\":894},{\"id\":895},{\"id\":896},{\"id\":897},{\"id\":898},{\"id\":899},{\"id\":900},{\"id\":901},{\"id\":902},{\"id\":903},{\"id\":904},{\"id\":905},{\"id\":906},{\"id\":907},{\"id\":908},{\"id\":909},{\"id\":910},{\"id\":911},{\"id\":912},{\"id\":913},{\"id\":914},{\"id\":915},{\"id\":916},{\"id\":917},{\"id\":918},{\"id\":919},{\"id\":920},{\"id\":921},{\"id\":922},{\"id\":923},{\"id\":924},{\"id\":925},{\"id\":926},{\"id\":927},{\"id\":928},{\"id\":929},{\"id\":930},{\"id\":931},{\"id\":932},{\"id\":933},{\"id\":934},{\"id\":935},{\"id\":936},{\"id\":937},{\"id\":938},{\"id\":939},{\"id\":940},{\"id\":941},{\"id\":942},{\"id\":943},{\"id\":944},{\"id\":945},{\"id\":946},{\"id\":947},{\"id\":948},{\"id\":949},{\"id\":950},{\"id\":951},{\"id\":952},{\"id\":953},{\"id\":954},{\"id\":955},{\"id\":956},{\"id\":957},{\"id\":958},{\"id\":959},{\"id\":960},{\"id\":961},{\"id\":962},{\"id\":963},{\"id\":964},{\"id\":965},{\"id\":966},{\"id\":967},{\"id\":968},{\"id\":969},{\"id\":970},{\"id\":971},{\"id\":972},{\"id\":973},{\"id\":974},{\"id\":975},{\"id\":976},{\"id\":977},{\"id\":978},{\"id\":979},{\"id\":980},{\"id\":981},{\"id\":982},{\"id\":983},{\"id\":984},{\"id\":985},{\"id\":986},{\"id\":987},{\"id\":988},{\"id\":989},{\"id\":990},{\"id\":991},{\"id\":992},{\"id\":993},{\"id\":994},{\"id\":995},{\"id\":996},{\"id\":997},{\"id\":998},{\"id\":999},{\"id\":1000},{\"id\":1001},{\"id\":1002},{\"id\":1003},{\"id\":1004},{\"id\":1005},{\"id\":1006},{\"id\":1007},{\"id\":1008},{\"id\":1009},{\"id\":1010},{\"id\":1011},{\"id\":1012},{\"id\":1013},{\"id\":1014},{\"id\":1015},{\"id\":1016},{\"id\":1017},{\"id\":1018},{\"id\":1019},{\"id\":1020},{\"id\":1021},{\"id\":1022},{\"id\":1023},{\"id\":1024},{\"id\":1025},{\"id\":1026},{\"id\":1027},{\"id\":1028},{\"id\":1029},{\"id\":1030},{\"id\":1031},{\"id\":1032},{\"id\":1033},{\"id\":1034},{\"id\":1035},{\"id\":1036},{\"id\":1037},{\"id\":1038},{\"id\":1039},{\"id\":1040},{\"id\":1041},{\"id\":1042},{\"id\":1043},{\"id\":1044},{\"id\":1045},{\"id\":1046},{\"id\":1047},{\"id\":1048},{\"id\":1049},{\"id\":1050},{\"id\":1051},{\"id\":1052},{\"id\":1053},{\"id\":1054},{\"id\":1055},{\"id\":1056},{\"id\":1057},{\"id\":1058},{\"id\":1059},{\"id\":1060},{\"id\":1061},{\"id\":1062},{\"id\":1063},{\"id\":1064},{\"id\":1065},{\"id\":1066},{\"id\":1067},{\"id\":1068},{\"id\":1069},{\"id\":1070},{\"id\":1071},{\"id\":1072},{\"id\":1073},{\"id\":1074},{\"id\":1075},{\"id\":1076},{\"id\":1077},{\"id\":1078},{\"id\":1079},{\"id\":1080},{\"id\":1081},{\"id\":1082},{\"id\":1083},{\"id\":1084},{\"id\":1085},{\"id\":1086},{\"id\":1087},{\"id\":1088},{\"id\":1089},{\"id\":1090},{\"id\":1091},{\"id\":1092},{\"id\":1093},{\"id\":1094},{\"id\":1095},{\"id\":1096},{\"id\":1097},{\"id\":1098},{\"id\":1099},{\"id\":1100},{\"id\":1101},{\"id\":1102},{\"id\":1103},{\"id\":1104},{\"id\":1105},{\"id\":1106},{\"id\":1107},{\"id\":1108},{\"id\":1109},{\"id\":1110},{\"id\":1111},{\"id\":1112},{\"id\":1113},{\"id\":1114},{\"id\":1115},{\"id\":1116},{\"id\":1117},{\"id\":1118},{\"id\":1119},{\"id\":1120},{\"id\":1121},{\"id\":1122},{\"id\":1123},{\"id\":1124},{\"id\":1125},{\"id\":1126},{\"id\":1127},{\"id\":1128},{\"id\":1129},{\"id\":1130},{\"id\":1131},{\"id\":1132},{\"id\":1133},{\"id\":1134},{\"id\":1135},{\"id\":1136},{\"id\":1137},{\"id\":1138},{\"id\":1139},{\"id\":1140},{\"id\":1141},{\"id\":1142},{\"id\":1143},{\"id\":1144},{\"id\":1145},{\"id\":1146},{\"id\":1147},{\"id\":1148},{\"id\":1149},{\"id\":1150},{\"id\":1151},{\"id\":1152},{\"id\":1153},{\"id\":1154},{\"id\":1155},{\"id\":1156},{\"id\":1157},{\"id\":1158},{\"id\":1159},{\"id\":1160},{\"id\":1161},{\"id\":1162},{\"id\":1163},{\"id\":1164},{\"id\":1165},{\"id\":1166},{\"id\":1167},{\"id\":1168},{\"id\":1169},{\"id\":1170},{\"id\":1171},{\"id\":1172},{\"id\":1173},{\"id\":1174},{\"id\":1175},{\"id\":1176},{\"id\":1177},{\"id\":1178},{\"id\":1179},{\"id\":1180},{\"id\":1181},{\"id\":1182},{\"id\":1183},{\"id\":1184},{\"id\":1185},{\"id\":1186},{\"id\":1187},{\"id\":1188},{\"id\":1189},{\"id\":1190},{\"id\":1191},{\"id\":1192},{\"id\":1193},{\"id\":1194},{\"id\":1195},{\"id\":1196},{\"id\":1197},{\"id\":1198},{\"id\":1199},{\"id\":1200},{\"id\":1201},{\"id\":1202},{\"id\":1203},{\"id\":1204},{\"id\":1205},{\"id\":1206},{\"id\":1207},{\"id\":1208},{\"id\":1209},{\"id\":1210},{\"id\":1211},{\"id\":1212},{\"id\":1213},{\"id\":1214},{\"id\":1215},{\"id\":1216},{\"id\":1217},{\"id\":1218},{\"id\":1219},{\"id\":1220},{\"id\":1221},{\"id\":1222},{\"id\":1223},{\"id\":1224},{\"id\":1225},{\"id\":1226},{\"id\":1227},{\"id\":1228},{\"id\":1229},{\"id\":1230},{\"id\":1231},{\"id\":1232},{\"id\":1233},{\"id\":1234},{\"id\":1235},{\"id\":1236},{\"id\":1237},{\"id\":1238},{\"id\":1239},{\"id\":1240},{\"id\":1241},{\"id\":1242},{\"id\":1243},{\"id\":1244},{\"id\":1245},{\"id\":1246},{\"id\":1247},{\"id\":1248},{\"id\":1249},{\"id\":1250},{\"id\":1251},{\"id\":1252},{\"id\":1253},{\"id\":1254},{\"id\":1255},{\"id\":1256},{\"id\":1257},{\"id\":1258},{\"id\":1259},{\"id\":1260},{\"id\":1261},{\"id\":1262},{\"id\":1263},{\"id\":1264},{\"id\":1265},{\"id\":1266},{\"id\":1267},{\"id\":1268},{\"id\":1269},{\"id\":1270},{\"id\":1271},{\"id\":1272},{\"id\":1273},{\"id\":1274},{\"id\":1275},{\"id\":1276},{\"id\":1277},{\"id\":1278},{\"id\":1279},{\"id\":1280},{\"id\":1281},{\"id\":1282},{\"id\":1283},{\"id\":1284},{\"id\":1285},{\"id\":1286},{\"id\":1287},{\"id\":1288},{\"id\":1289},{\"id\":1290},{\"id\":1291},{\"id\":1292},{\"id\":1293},{\"id\":1294},{\"id\":1295},{\"id\":1296},{\"id\":1297},{\"id\":1298},{\"id\":1299},{\"id\":1300},{\"id\":1301},{\"id\":1302},{\"id\":1303},{\"id\":1304},{\"id\":1305},{\"id\":1306},{\"id\":1307},{\"id\":1308},{\"id\":1309},{\"id\":1310},{\"id\":1311},{\"id\":1312},{\"id\":1313},{\"id\":1314},{\"id\":1315},{\"id\":1316},{\"id\":1317},{\"id\":1318},{\"id\":1319},{\"id\":1320},{\"id\":1321},{\"id\":1322},{\"id\":1323},{\"id\":1324},{\"id\":1325},{\"id\":1326},{\"id\":1327},{\"id\":1328},{\"id\":1329},{\"id\":1330},{\"id\":1331},{\"id\":1332},{\"id\":1333},{\"id\":1334},{\"id\":1335},{\"id\":1336},{\"id\":1337},{\"id\":1338},{\"id\":1339},{\"id\":1340},{\"id\":1341},{\"id\":1342},{\"id\":1343},{\"id\":1344},{\"id\":1345},{\"id\":1346},{\"id\":1347},{\"id\":1348},{\"id\":1349},{\"id\":1350},{\"id\":1351},{\"id\":1352},{\"id\":1353},{\"id\":1354},{\"id\":1355},{\"id\":1356},{\"id\":1357},{\"id\":1358},{\"id\":1359},{\"id\":1360},{\"id\":1361},{\"id\":1362},{\"id\":1363},{\"id\":1364},{\"id\":1365},{\"id\":1366},{\"id\":1367},{\"id\":1368},{\"id\":1369},{\"id\":1370},{\"id\":1371},{\"id\":1372},{\"id\":1373},{\"id\":1374},{\"id\":1375},{\"id\":1376},{\"id\":1377},{\"id\":1378},{\"id\":1379},{\"id\":1380},{\"id\":1381},{\"id\":1382},{\"id\":1383},{\"id\":1384},{\"id\":1385},{\"id\":1386},{\"id\":1387},{\"id\":1388},{\"id\":1389},{\"id\":1390},{\"id\":1391},{\"id\":1392},{\"id\":1393},{\"id\":1394},{\"id\":1395},{\"id\":1396},{\"id\":1397},{\"id\":1398},{\"id\":1399},{\"id\":1400},{\"id\":1401},{\"id\":1402},{\"id\":1403},{\"id\":1404},{\"id\":1405},{\"id\":1406},{\"id\":1407},{\"id\":1408},{\"id\":1409},{\"id\":1410},{\"id\":1411},{\"id\":1412},{\"id\":1413},{\"id\":1414},{\"id\":1415},{\"id\":1416},{\"id\":1417},{\"id\":1418},{\"id\":1419},{\"id\":1420},{\"id\":1421},{\"id\":1422},{\"id\":1423},{\"id\":1424},{\"id\":1425},{\"id\":1426},{\"id\":1427},{\"id\":1428},{\"id\":1429},{\"id\":1430},{\"id\":1431},{\"id\":1432},{\"id\":1433},{\"id\":1434},{\"id\":1435},{\"id\":1436},{\"id\":1437},{\"id\":1438},{\"id\":1439},{\"id\":1440},{\"id\":1441},{\"id\":1442},{\"id\":1443},{\"id\":1444},{\"id\":1445},{\"id\":1446},{\"id\":1447},{\"id\":1448},{\"id\":1449},{\"id\":1450},{\"id\":1451},{\"id\":1452},{\"id\":1453},{\"id\":1454},{\"id\":1455},{\"id\":1456},{\"id\":1457},{\"id\":1458},{\"id\":1459},{\"id\":1460},{\"id\":1461},{\"id\":1462},{\"id\":1463},{\"id\":1464},{\"id\":1465},{\"id\":1466},{\"id\":1467},{\"id\":1468},{\"id\":1469},{\"id\":1470},{\"id\":1471},{\"id\":1472},{\"id\":1473},{\"id\":1474},{\"id\":1475},{\"id\":1476},{\"id\":1477},{\"id\":1478},{\"id\":1479},{\"id\":1480},{\"id\":1481},{\"id\":1482},{\"id\":1483},{\"id\":1484},{\"id\":1485},{\"id\":1486},{\"id\":1487},{\"id\":1488},{\"id\":1489},{\"id\":1490},{\"id\":1491},{\"id\":1492},{\"id\":1493},{\"id\":1494},{\"id\":1495},{\"id\":1496},{\"id\":1497},{\"id\":1498},{\"id\":1499},{\"id\":1500},{\"id\":1501},{\"id\":1502},{\"id\":1503},{\"id\":1504},{\"id\":1505},{\"id\":1506},{\"id\":1507},{\"id\":1508},{\"id\":1509},{\"id\":1510},{\"id\":1511},{\"id\":1512},{\"id\":1513},{\"id\":1514},{\"id\":1515},{\"id\":1516},{\"id\":1517},{\"id\":1518},{\"id\":1519},{\"id\":1520},{\"id\":1521},{\"id\":1522},{\"id\":1523},{\"id\":1524},{\"id\":1525},{\"id\":1526},{\"id\":1527},{\"id\":1528},{\"id\":1529},{\"id\":1530},{\"id\":1531},{\"id\":1532},{\"id\":1533},{\"id\":1534},{\"id\":1535},{\"id\":1536},{\"id\":1537},{\"id\":1538},{\"id\":1539},{\"id\":1540},{\"id\":1541},{\"id\":1542},{\"id\":1543},{\"id\":1544},{\"id\":1545},{\"id\":1546},{\"id\":1547},{\"id\":1548},{\"id\":1549},{\"id\":1550},{\"id\":1551},{\"id\":1552},{\"id\":1553},{\"id\":1554},{\"id\":1555},{\"id\":1556},{\"id\":1557},{\"id\":1558},{\"id\":1559},{\"id\":1560},{\"id\":1561},{\"id\":1562},{\"id\":1563},{\"id\":1564},{\"id\":1565},{\"id\":1566},{\"id\":1567},{\"id\":1568},{\"id\":1569},{\"id\":1570},{\"id\":1571},{\"id\":1572},{\"id\":1573},{\"id\":1574},{\"id\":1575},{\"id\":1576},{\"id\":1577},{\"id\":1578},{\"id\":1579},{\"id\":1580},{\"id\":1581},{\"id\":1582},{\"id\":1583},{\"id\":1584},{\"id\":1585},{\"id\":1586},{\"id\":1587},{\"id\":1588},{\"id\":1589},{\"id\":1590},{\"id\":1591},{\"id\":1592},{\"id\":1593},{\"id\":1594},{\"id\":1595},{\"id\":1596},{\"id\":1597},{\"id\":1598},{\"id\":1599},{\"id\":1600},{\"id\":1601},{\"id\":1602},{\"id\":1603},{\"id\":1604},{\"id\":1605},{\"id\":1606},{\"id\":1607},{\"id\":1608},{\"id\":1609},{\"id\":1610},{\"id\":1611},{\"id\":1612},{\"id\":1613},{\"id\":1614},{\"id\":1615},{\"id\":1616},{\"id\":1617},{\"id\":1618},{\"id\":1619},{\"id\":1620},{\"id\":1621},{\"id\":1622},{\"id\":1623},{\"id\":1624},{\"id\":1625},{\"id\":1626},{\"id\":1627},{\"id\":1628},{\"id\":1629},{\"id\":1630},{\"id\":1631},{\"id\":1632},{\"id\":1633},{\"id\":1634},{\"id\":1635},{\"id\":1636},{\"id\":1637},{\"id\":1638},{\"id\":1639},{\"id\":1640},{\"id\":1641},{\"id\":1642},{\"id\":1643},{\"id\":1644},{\"id\":1645},{\"id\":1646},{\"id\":1647},{\"id\":1648},{\"id\":1649},{\"id\":1650},{\"id\":1651},{\"id\":1652},{\"id\":1653},{\"id\":1654},{\"id\":1655},{\"id\":1656},{\"id\":1657},{\"id\":1658},{\"id\":1659},{\"id\":1660},{\"id\":1661},{\"id\":1662},{\"id\":1663},{\"id\":1664},{\"id\":1665},{\"id\":1666},{\"id\":1667},{\"id\":1668},{\"id\":1669},{\"id\":1670},{\"id\":1671},{\"id\":1672},{\"id\":1673},{\"id\":1674},{\"id\":1675},{\"id\":1676},{\"id\":1677},{\"id\":1678},{\"id\":1679},{\"id\":1680},{\"id\":1681},{\"id\":1682},{\"id\":1683},{\"id\":1684},{\"id\":1685},{\"id\":1686},{\"id\":1687},{\"id\":1688},{\"id\":1689},{\"id\":1690},{\"id\":1691},{\"id\":1692},{\"id\":1693},{\"id\":1694},{\"id\":1695},{\"id\":1696},{\"id\":1697},{\"id\":1698},{\"id\":1699},{\"id\":1700},{\"id\":1701},{\"id\":1702},{\"id\":1703},{\"id\":1704},{\"id\":1705},{\"id\":1706},{\"id\":1707},{\"id\":1708},{\"id\":1709},{\"id\":1710},{\"id\":1711},{\"id\":1712},{\"id\":1713},{\"id\":1714},{\"id\":1715},{\"id\":1716},{\"id\":1717},{\"id\":1718},{\"id\":1719},{\"id\":1720},{\"id\":1721},{\"id\":1722},{\"id\":1723},{\"id\":1724},{\"id\":1725},{\"id\":1726},{\"id\":1727},{\"id\":1728},{\"id\":1729},{\"id\":1730},{\"id\":1731},{\"id\":1732},{\"id\":1733},{\"id\":1734},{\"id\":1735},{\"id\":1736},{\"id\":1737},{\"id\":1738},{\"id\":1739},{\"id\":1740},{\"id\":1741},{\"id\":1742},{\"id\":1743},{\"id\":1744},{\"id\":1745},{\"id\":1746},{\"id\":1747},{\"id\":1748},{\"id\":1749},{\"id\":1750},{\"id\":1751},{\"id\":1752},{\"id\":1753},{\"id\":1754},{\"id\":1755},{\"id\":1756},{\"id\":1757},{\"id\":1758},{\"id\":1759},{\"id\":1760},{\"id\":1761},{\"id\":1762},{\"id\":1763},{\"id\":1764},{\"id\":1765},{\"id\":1766},{\"id\":1767},{\"id\":1768},{\"id\":1769},{\"id\":1770},{\"id\":1771},{\"id\":1772},{\"id\":1773},{\"id\":1774},{\"id\":1775},{\"id\":1776},{\"id\":1777},{\"id\":1778},{\"id\":1779},{\"id\":1780},{\"id\":1781},{\"id\":1782},{\"id\":1783},{\"id\":1784},{\"id\":1785},{\"id\":1786},{\"id\":1787},{\"id\":1788},{\"id\":1789},{\"id\":1790},{\"id\":1791},{\"id\":1792},{\"id\":1793},{\"id\":1794},{\"id\":1795},{\"id\":1796},{\"id\":1797},{\"id\":1798},{\"id\":1799},{\"id\":1800},{\"id\":1801},{\"id\":1802},{\"id\":1803},{\"id\":1804},{\"id\":1805},{\"id\":1806},{\"id\":1807},{\"id\":1808},{\"id\":1809},{\"id\":1810},{\"id\":1811},{\"id\":1812},{\"id\":1813},{\"id\":1814},{\"id\":1815},{\"id\":1816},{\"id\":1817},{\"id\":1818},{\"id\":1819},{\"id\":1820},{\"id\":1821},{\"id\":1822},{\"id\":1823},{\"id\":1824},{\"id\":1825},{\"id\":1826},{\"id\":1827},{\"id\":1828},{\"id\":1829},{\"id\":1830},{\"id\":1831},{\"id\":1832},{\"id\":1833},{\"id\":1834},{\"id\":1835},{\"id\":1836},{\"id\":1837},{\"id\":1838},{\"id\":1839},{\"id\":1840},{\"id\":1841},{\"id\":1842},{\"id\":1843},{\"id\":1844},{\"id\":1845},{\"id\":1846},{\"id\":1847},{\"id\":1848},{\"id\":1849},{\"id\":1850},{\"id\":1851},{\"id\":1852},{\"id\":1853},{\"id\":1854},{\"id\":1855},{\"id\":1856},{\"id\":1857},{\"id\":1858},{\"id\":1859},{\"id\":1860},{\"id\":1861},{\"id\":1862},{\"id\":1863},{\"id\":1864},{\"id\":1865},{\"id\":1866},{\"id\":1867},{\"id\":1868},{\"id\":1869},{\"id\":1870},{\"id\":1871},{\"id\":1872},{\"id\":1873},{\"id\":1874},{\"id\":1875},{\"id\":1876},{\"id\":1877},{\"id\":1878},{\"id\":1879},{\"id\":1880},{\"id\":1881},{\"id\":1882},{\"id\":1883},{\"id\":1884},{\"id\":1885},{\"id\":1886},{\"id\":1887},{\"id\":1888},{\"id\":1889},{\"id\":1890},{\"id\":1891},{\"id\":1892},{\"id\":1893},{\"id\":1894},{\"id\":1895},{\"id\":1896},{\"id\":1897},{\"id\":1898},{\"id\":1899},{\"id\":1900},{\"id\":1901},{\"id\":1902},{\"id\":1903},{\"id\":1904},{\"id\":1905},{\"id\":1906},{\"id\":1907},{\"id\":1908},{\"id\":1909},{\"id\":1910},{\"id\":1911},{\"id\":1912},{\"id\":1913},{\"id\":1914},{\"id\":1915},{\"id\":1916},{\"id\":1917},{\"id\":1918},{\"id\":1919},{\"id\":1920},{\"id\":1921},{\"id\":1922},{\"id\":1923},{\"id\":1924},{\"id\":1925},{\"id\":1926},{\"id\":1927},{\"id\":1928},{\"id\":1929},{\"id\":1930},{\"id\":1931},{\"id\":1932},{\"id\":1933},{\"id\":1934},{\"id\":1935},{\"id\":1936},{\"id\":1937},{\"id\":1938},{\"id\":1939},{\"id\":1940},{\"id\":1941},{\"id\":1942},{\"id\":1943},{\"id\":1944},{\"id\":1945},{\"id\":1946},{\"id\":1947},{\"id\":1948},{\"id\":1949},{\"id\":1950},{\"id\":1951},{\"id\":1952},{\"id\":1953},{\"id\":1954},{\"id\":1955},{\"id\":1956},{\"id\":1957},{\"id\":1958},{\"id\":1959},{\"id\":1960},{\"id\":1961},{\"id\":1962},{\"id\":1963},{\"id\":1964},{\"id\":1965},{\"id\":1966},{\"id\":1967},{\"id\":1968},{\"id\":1969},{\"id\":1970},{\"id\":1971},{\"id\":1972},{\"id\":1973},{\"id\":1974},{\"id\":1975},{\"id\":1976},{\"id\":1977},{\"id\":1978},{\"id\":1979},{\"id\":1980},{\"id\":1981},{\"id\":1982},{\"id\":1983},{\"id\":1984},{\"id\":1985},{\"id\":1986},{\"id\":1987},{\"id\":1988},{\"id\":1989},{\"id\":1990},{\"id\":1991},{\"id\":1992},{\"id\":1993},{\"id\":1994},{\"id\":1995},{\"id\":1996},{\"id\":1997},{\"id\":1998},{\"id\":1999},{\"id\":2000},{\"id\":2001},{\"id\":2002},{\"id\":2003},{\"id\":2004},{\"id\":2005},{\"id\":2006},{\"id\":2007},{\"id\":2008},{\"id\":2009},{\"id\":2010},{\"id\":2011},{\"id\":2012},{\"id\":2013},{\"id\":2014},{\"id\":2015},{\"id\":2016},{\"id\":2017},{\"id\":2018},{\"id\":2019},{\"id\":2020},{\"id\":2021},{\"id\":2022},{\"id\":2023},{\"id\":2024},{\"id\":2025},{\"id\":2026},{\"id\":2027},{\"id\":2028},{\"id\":2029},{\"id\":2030},{\"id\":2031},{\"id\":2032},{\"id\":2033},{\"id\":2034},{\"id\":2035},{\"id\":2036},{\"id\":2037},{\"id\":2038},{\"id\":2039},{\"id\":2040},{\"id\":2041},{\"id\":2042},{\"id\":2043},{\"id\":2044},{\"id\":2045},{\"id\":2046},{\"id\":2047},{\"id\":2048},{\"id\":2049},{\"id\":2050},{\"id\":2051},{\"id\":2052},{\"id\":2053},{\"id\":2054},{\"id\":2055},{\"id\":2056},{\"id\":2057},{\"id\":2058},{\"id\":2059},{\"id\":2060},{\"id\":2061},{\"id\":2062},{\"id\":2063},{\"id\":2064},{\"id\":2065},{\"id\":2066},{\"id\":2067},{\"id\":2068},{\"id\":2069},{\"id\":2070},{\"id\":2071},{\"id\":2072},{\"id\":2073},{\"id\":2074},{\"id\":2075},{\"id\":2076},{\"id\":2077},{\"id\":2078},{\"id\":2079},{\"id\":2080},{\"id\":2081},{\"id\":2082},{\"id\":2083},{\"id\":2084},{\"id\":2085},{\"id\":2086},{\"id\":2087},{\"id\":2088},{\"id\":2089},{\"id\":2090},{\"id\":2091},{\"id\":2092},{\"id\":2093},{\"id\":2094},{\"id\":2095},{\"id\":2096},{\"id\":2097},{\"id\":2098},{\"id\":2099},{\"id\":2100},{\"id\":2101},{\"id\":2102},{\"id\":2103},{\"id\":2104},{\"id\":2105},{\"id\":2106},{\"id\":2107},{\"id\":2108},{\"id\":2109},{\"id\":2110},{\"id\":2111},{\"id\":2112},{\"id\":2113},{\"id\":2114},{\"id\":2115},{\"id\":2116},{\"id\":2117},{\"id\":2118},{\"id\":2119},{\"id\":2120},{\"id\":2121},{\"id\":2122},{\"id\":2123},{\"id\":2124},{\"id\":2125},{\"id\":2126},{\"id\":2127},{\"id\":2128},{\"id\":2129},{\"id\":2130},{\"id\":2131},{\"id\":2132},{\"id\":2133},{\"id\":2134},{\"id\":2135},{\"id\":2136},{\"id\":2137},{\"id\":2138},{\"id\":2139},{\"id\":2140},{\"id\":2141},{\"id\":2142},{\"id\":2143},{\"id\":2144},{\"id\":2145},{\"id\":2146},{\"id\":2147},{\"id\":2148},{\"id\":2149},{\"id\":2150},{\"id\":2151},{\"id\":2152},{\"id\":2153},{\"id\":2154},{\"id\":2155},{\"id\":2156},{\"id\":2157},{\"id\":2158},{\"id\":2159},{\"id\":2160},{\"id\":2161},{\"id\":2162},{\"id\":2163},{\"id\":2164},{\"id\":2165},{\"id\":2166},{\"id\":2167},{\"id\":2168},{\"id\":2169},{\"id\":2170},{\"id\":2171},{\"id\":2172},{\"id\":2173},{\"id\":2174},{\"id\":2175},{\"id\":2176},{\"id\":2177},{\"id\":2178},{\"id\":2179},{\"id\":2180},{\"id\":2181},{\"id\":2182},{\"id\":2183},{\"id\":2184},{\"id\":2185},{\"id\":2186},{\"id\":2187},{\"id\":2188},{\"id\":2189},{\"id\":2190},{\"id\":2191},{\"id\":2192},{\"id\":2193},{\"id\":2194},{\"id\":2195},{\"id\":2196},{\"id\":2197},{\"id\":2198},{\"id\":2199},{\"id\":2200},{\"id\":2201},{\"id\":2202},{\"id\":2203},{\"id\":2204},{\"id\":2205},{\"id\":2206},{\"id\":2207},{\"id\":2208},{\"id\":2209},{\"id\":2210},{\"id\":2211},{\"id\":2212},{\"id\":2213},{\"id\":2214},{\"id\":2215},{\"id\":2216},{\"id\":2217},{\"id\":2218},{\"id\":2219},{\"id\":2220},{\"id\":2221},{\"id\":2222},{\"id\":2223},{\"id\":2224},{\"id\":2225},{\"id\":2226},{\"id\":2227},{\"id\":2228},{\"id\":2229},{\"id\":2230},{\"id\":2231},{\"id\":2232},{\"id\":2233},{\"id\":2234},{\"id\":2235},{\"id\":2236},{\"id\":2237},{\"id\":2238},{\"id\":2239},{\"id\":2240},{\"id\":2241},{\"id\":2242},{\"id\":2243},{\"id\":2244},{\"id\":2245},{\"id\":2246},{\"id\":2247},{\"id\":2248},{\"id\":2249},{\"id\":2250},{\"id\":2251},{\"id\":2252},{\"id\":2253},{\"id\":2254},{\"id\":2255},{\"id\":2256},{\"id\":2257},{\"id\":2258},{\"id\":2259},{\"id\":2260},{\"id\":2261},{\"id\":2262},{\"id\":2263},{\"id\":2264},{\"id\":2265},{\"id\":2266},{\"id\":2267},{\"id\":2268},{\"id\":2269},{\"id\":2270},{\"id\":2271},{\"id\":2272},{\"id\":2273},{\"id\":2274},{\"id\":2275},{\"id\":2276},{\"id\":2277},{\"id\":2278},{\"id\":2279},{\"id\":2280},{\"id\":2281},{\"id\":2282},{\"id\":2283},{\"id\":2284},{\"id\":2285},{\"id\":2286},{\"id\":2287},{\"id\":2288},{\"id\":2289},{\"id\":2290},{\"id\":2291},{\"id\":2292},{\"id\":2293},{\"id\":2294},{\"id\":2295},{\"id\":2296},{\"id\":2297},{\"id\":2298},{\"id\":2299},{\"id\":2300},{\"id\":2301},{\"id\":2302},{\"id\":2303},{\"id\":2304},{\"id\":2305},{\"id\":2306},{\"id\":2307},{\"id\":2308},{\"id\":2309},{\"id\":2310},{\"id\":2311},{\"id\":2312},{\"id\":2313},{\"id\":2314},{\"id\":2315},{\"id\":2316},{\"id\":2317},{\"id\":2318},{\"id\":2319},{\"id\":2320},{\"id\":2321},{\"id\":2322},{\"id\":2323},{\"id\":2324},{\"id\":2325},{\"id\":2326},{\"id\":2327},{\"id\":2328},{\"id\":2329},{\"id\":2330},{\"id\":2331},{\"id\":2332},{\"id\":2333},{\"id\":2334},{\"id\":2335},{\"id\":2336},{\"id\":2337},{\"id\":2338},{\"id\":2339},{\"id\":2340},{\"id\":2341},{\"id\":2342},{\"id\":2343},{\"id\":2344},{\"id\":2345},{\"id\":2346},{\"id\":2347},{\"id\":2348},{\"id\":2349},{\"id\":2350},{\"id\":2351},{\"id\":2352},{\"id\":2353},{\"id\":2354},{\"id\":2355},{\"id\":2356},{\"id\":2357},{\"id\":2358},{\"id\":2359},{\"id\":2360},{\"id\":2361},{\"id\":2362},{\"id\":2363},{\"id\":2364},{\"id\":2365},{\"id\":2366},{\"id\":2367},{\"id\":2368},{\"id\":2369},{\"id\":2370},{\"id\":2371},{\"id\":2372},{\"id\":2373},{\"id\":2374},{\"id\":2375},{\"id\":2376},{\"id\":2377},{\"id\":2378},{\"id\":2379},{\"id\":2380},{\"id\":2381},{\"id\":2382},{\"id\":2383},{\"id\":2384},{\"id\":2385},{\"id\":2386},{\"id\":2387},{\"id\":2388},{\"id\":2389},{\"id\":2390},{\"id\":2391},{\"id\":2392},{\"id\":2393},{\"id\":2394},{\"id\":2395},{\"id\":2396},{\"id\":2397},{\"id\":2398},{\"id\":2399},{\"id\":2400},{\"id\":2401},{\"id\":2402},{\"id\":2403},{\"id\":2404},{\"id\":2405},{\"id\":2406},{\"id\":2407},{\"id\":2408},{\"id\":2409},{\"id\":2410},{\"id\":2411},{\"id\":2412},{\"id\":2413},{\"id\":2414},{\"id\":2415},{\"id\":2416},{\"id\":2417},{\"id\":2418},{\"id\":2419},{\"id\":2420},{\"id\":2421},{\"id\":2422},{\"id\":2423},{\"id\":2424},{\"id\":2425},{\"id\":2426},{\"id\":2427},{\"id\":2428},{\"id\":2429},{\"id\":2430},{\"id\":2431},{\"id\":2432},{\"id\":2433},{\"id\":2434},{\"id\":2435},{\"id\":2436},{\"id\":2437},{\"id\":2438},{\"id\":2439},{\"id\":2440},{\"id\":2441},{\"id\":2442},{\"id\":2443},{\"id\":2444},{\"id\":2445},{\"id\":2446},{\"id\":2447},{\"id\":2448},{\"id\":2449},{\"id\":2450},{\"id\":2451},{\"id\":2452},{\"id\":2453},{\"id\":2454},{\"id\":2455},{\"id\":2456},{\"id\":2457},{\"id\":2458},{\"id\":2459},{\"id\":2460},{\"id\":2461},{\"id\":2462},{\"id\":2463},{\"id\":2464},{\"id\":2465},{\"id\":2466},{\"id\":2467},{\"id\":2468},{\"id\":2469},{\"id\":2470},{\"id\":2471},{\"id\":2472},{\"id\":2473},{\"id\":2474},{\"id\":2475},{\"id\":2476},{\"id\":2477},{\"id\":2478},{\"id\":2479},{\"id\":2480},{\"id\":2481},{\"id\":2482},{\"id\":2483},{\"id\":2484},{\"id\":2485},{\"id\":2486},{\"id\":2487},{\"id\":2488},{\"id\":2489},{\"id\":2490},{\"id\":2491},{\"id\":2492},{\"id\":2493},{\"id\":2494},{\"id\":2495},{\"id\":2496},{\"id\":2497},{\"id\":2498},{\"id\":2499},{\"id\":2500},{\"id\":2501},{\"id\":2502},{\"id\":2503},{\"id\":2504},{\"id\":2505},{\"id\":2506},{\"id\":2507},{\"id\":2508},{\"id\":2509},{\"id\":2510},{\"id\":2511},{\"id\":2512},{\"id\":2513},{\"id\":2514},{\"id\":2515},{\"id\":2516},{\"id\":2517},{\"id\":2518},{\"id\":2519},{\"id\":2520},{\"id\":2521},{\"id\":2522},{\"id\":2523},{\"id\":2524},{\"id\":2525},{\"id\":2526},{\"id\":2527},{\"id\":2528},{\"id\":2529},{\"id\":2530},{\"id\":2531},{\"id\":2532},{\"id\":2533},{\"id\":2534},{\"id\":2535},{\"id\":2536},{\"id\":2537},{\"id\":2538},{\"id\":2539},{\"id\":2540},{\"id\":2541},{\"id\":2542},{\"id\":2543},{\"id\":2544},{\"id\":2545},{\"id\":2546},{\"id\":2547},{\"id\":2548},{\"id\":2549},{\"id\":2550},{\"id\":2551},{\"id\":2552},{\"id\":2553},{\"id\":2554},{\"id\":2555},{\"id\":2556},{\"id\":2557},{\"id\":2558},{\"id\":2559},{\"id\":2560},{\"id\":2561},{\"id\":2562},{\"id\":2563},{\"id\":2564},{\"id\":2565},{\"id\":2566},{\"id\":2567},{\"id\":2568},{\"id\":2569},{\"id\":2570},{\"id\":2571},{\"id\":2572},{\"id\":2573},{\"id\":2574},{\"id\":2575},{\"id\":2576},{\"id\":2577},{\"id\":2578},{\"id\":2579},{\"id\":2580},{\"id\":2581},{\"id\":2582},{\"id\":2583},{\"id\":2584},{\"id\":2585},{\"id\":2586},{\"id\":2587},{\"id\":2588},{\"id\":2589},{\"id\":2590},{\"id\":2591},{\"id\":2592},{\"nodeType\":3,\"id\":2596,\"textContent\":\" // Track clicks on page $(document).ready(function() { $(\\\".control\\\").click(function(e) { e.stopImmediatePropagation(); clicks = clicks + 1; console.log(clicks); }); }); $('.userid').html(sid); // console.log(\\\"start of clicked array: \\\"+clicked); // console.log(\\\"start of hovered string: \\\"+hovered); //set correct answers for each question var triangular_answers = { \\\"acme.starttime.1\\\" : [\\\"F\\\"], \\\"acme.starts.1\\\" : [\\\"K\\\"], \\\"acme.meets.1\\\" : [\\\"F\\\"], \\\"acme.endtime.1\\\" : [\\\"H\\\"], \\\"acme.midpoint.1\\\" : [\\\"O\\\"], \\\"acme.starttime.2\\\" : [\\\"F\\\"], \\\"acme.starts.2\\\" : [\\\"K\\\"], \\\"acme.meets.2\\\" : [\\\"F\\\"], \\\"acme.endtime.2\\\" : [\\\"H\\\"], \\\"acme.midpoint.2\\\" : [\\\"A\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"E\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"E\\\"], \\\"bigset.starttime.1\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.1\\\" : [\\\"G\\\"], \\\"bigset.meets.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.1\\\" : [\\\"X\\\"], \\\"bigset.midpoint.1\\\" : [\\\"K\\\",\\\"X\\\"], \\\"bigset.starttime.2\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.2\\\" : [\\\"G\\\"], \\\"bigset.meets.2\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.2\\\" : [\\\"X\\\"], \\\"bigset.midpoint.2\\\" : [\\\"K\\\",\\\"X\\\"] } var orthogonal_answers = { \\\"acme.starttime.1\\\" : [\\\"A\\\"], \\\"acme.starts.1\\\" : [\\\"E\\\"], \\\"acme.meets.1\\\" : [\\\"Z\\\"], \\\"acme.endtime.1\\\" : [\\\"U\\\"], \\\"acme.midpoint.1\\\" : [\\\"U\\\"], \\\"acme.starttime.2\\\" : [\\\"0\\\"], \\\"acme.starts.2\\\" : [\\\"0\\\"], \\\"acme.meets.2\\\" : [\\\"0\\\"], \\\"acme.endtime.2\\\" : [\\\"0\\\"], \\\"acme.midpoint.2\\\" : [\\\"0\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"X\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"X\\\"], \\\"bigset.starttime.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.1\\\" : [\\\"B\\\"], \\\"bigset.meets.1\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.1\\\" : [\\\"B\\\"], \\\"bigset.midpoint.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.starttime.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.2\\\" : [\\\"B\\\"], \\\"bigset.meets.2\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.2\\\" : [\\\"B\\\"], \\\"bigset.midpoint.2\\\" : [\\\"E\\\",\\\"F\\\"] } //display the question and answer buttons based on input values from jsPsych document.getElementById(scenario+\\\".\\\"+question).style.display = \\\"block\\\"; if (question == \\\"strategy\\\") {document.getElementById(\\\"strategyButton\\\").style.display = \\\"block\\\";} else {document.getElementById(\\\"testingButton\\\").style.display = \\\"block\\\";} //---------SET PROPERTIES OF THE GRAPH -------------// // set the dimensions and margins of the graph var margin = {top: 25, right: 30, bottom: 90, left: 100}, width = 800, height = 800; var intersects = false; //default value for intersects scaffold var xAxisTitle, yAxisTitle; var datafile =\\\"\\\"; // SET AXIS VALUES if (axis == 1){ axis = \\\"Orthogonal-XInside-YFull\\\"; } else if (axis == 2){ axis = \\\"Orthogonal-XInside-YPartial\\\"; } else if (axis ==3){ axis = \\\"Triangular-XInside-YInside\\\"; } else if (axis ==4){ axis = \\\"Orthogonal-XInside-YInside\\\"; } else if (axis ==5){ axis = \\\"Orthogonal-XFull-YFull\\\"; } // SET EXPLICIT SCAFFOLD FEATURES if (explicit ==2 && axis != \\\"diagonal\\\"){ scaffold = 2; intersects = false; } else if (explicit == 2 && axis == \\\"diagonal\\\"){ scaffold = 2; intersects = false; } //TODO: not sure if above two lines are still valid since leaders are now generated on the fly else if (explicit == 3){ $('#hint-interactive').css(\\\"display\\\",\\\"block\\\"); //display textimage scaffold intersects = true; } //SET DATA FILE FOR IMPLICIT SCAFFOLD if (impasse == 1){ datafile = \\\"../views/src/data/acme_nonimpasse.csv\\\"; } else if (impasse == 2){ datafile = \\\"../views/src/data/acme_impasse.csv\\\"; } //OVERRIDE DATA FILE FOR NON-SCAFFOLD QUESTIONS if (q > 5) { //override data file if q# is greater than 5 datafile = \\\"../views/src/data/bigset.csv\\\"; console.log(\\\"override data file\\\"); $('#orthogonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#diagonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#hint-interactive').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold intersects = false; } // //---------CREATE THE SVG ------------------------// var svg = d3.select(\\\".d3container\\\").append(\\\"svg\\\") .attr(\\\"width\\\", width + margin.left + margin.right) .attr(\\\"height\\\", height + margin.top + margin.bottom) .append(\\\"g\\\") .attr(\\\"transform\\\", \\\"translate(\\\" + margin.left + \\\",\\\" + margin.top + \\\")\\\"); //---------DRAW THE GRAPH ------------------------// xAxisTitle = \\\"START & END TIME (time of day)\\\"; yAxisTitle = \\\"DURATION (in hours)\\\"; drawTriangleModel(datafile,intersects,axis,scaffold,q); \"},{\"id\":2593},{\"id\":2594},{\"nodeType\":3,\"id\":2597,\"textContent\":\" //MOUSE LOGGING SCRIPT var mouseLog = [] var xwidth = $(document).width(); var xheight = $(document).width(); mouseLog.push(\\\"{x:\\\"+xwidth+\\\",y:\\\"+xheight+\\\",t:\\\"+\\\"0};\\\") document.onmousemove = function(e){ var pageCoords = \\\"{x:\\\" + e.pageX + \\\",y:\\\"+ e.pageY +\\\",t:\\\"+ Date.now()+ \\\"};\\\" ; mouseLog.push(pageCoords); // console.log(pageCoords); }; \"},{\"id\":2595}],[],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2598,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2599,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2598},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2600,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2599},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2601,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":2600},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2602,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2599}},{\"nodeType\":1,\"id\":2603,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2602},\"parentNode\":{\"id\":2599}},{\"nodeType\":3,\"id\":2604,\"textContent\":\"What is your age?\",\"parentNode\":{\"id\":2602}},{\"nodeType\":1,\"id\":2605,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2600}},{\"nodeType\":1,\"id\":2606,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2605},\"parentNode\":{\"id\":2600}},{\"nodeType\":3,\"id\":2607,\"textContent\":\"In what country were you born?\",\"parentNode\":{\"id\":2605}},{\"nodeType\":3,\"id\":2608,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":2601}}],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2598},{\"id\":2599},{\"id\":2602},{\"id\":2604},{\"id\":2603},{\"id\":2600},{\"id\":2605},{\"id\":2607},{\"id\":2606},{\"id\":2601},{\"id\":2608}],[],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2609,\"tagName\":\"FORM\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-form\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2610,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-preamble\",\"class\":\"jspsych-survey-multi-choice-preamble\"},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2611,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-0\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2610},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2612,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-1\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2611},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2613,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-2\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2612},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2614,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-3\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2613},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2615,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"submit\",\"id\":\"jspsych-survey-multi-choice-next\",\"class\":\"jspsych-survey-multi-choice jspsych-btn\",\"value\":\"Submit Answers\"},\"previousSibling\":{\"id\":2614},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2616,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2617,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2616},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2618,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2617},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2619,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2618},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2620,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2619},\"parentNode\":{\"id\":2611}},{\"nodeType\":3,\"id\":2621,\"textContent\":\"What is your first language?\",\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2622,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2621},\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2623,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2624,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2623}},{\"nodeType\":3,\"id\":2625,\"textContent\":\"English\",\"previousSibling\":{\"id\":2624},\"parentNode\":{\"id\":2623}},{\"nodeType\":1,\"id\":2626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2618}},{\"nodeType\":1,\"id\":2627,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2626}},{\"nodeType\":3,\"id\":2628,\"textContent\":\"Spanish\",\"previousSibling\":{\"id\":2627},\"parentNode\":{\"id\":2626}},{\"nodeType\":1,\"id\":2629,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2619}},{\"nodeType\":1,\"id\":2630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2629}},{\"nodeType\":3,\"id\":2631,\"textContent\":\"Mandarin or Cantonese\",\"previousSibling\":{\"id\":2630},\"parentNode\":{\"id\":2629}},{\"nodeType\":1,\"id\":2632,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2633,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2634,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2633},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2635,\"textContent\":\"*\",\"parentNode\":{\"id\":2622}},{\"nodeType\":1,\"id\":2636,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2637,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2636},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2638,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2637},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2639,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2638},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2640,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2639},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2641,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2640},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2642,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2641},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2643,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2642},\"parentNode\":{\"id\":2612}},{\"nodeType\":3,\"id\":2644,\"textContent\":\"What is your year in school?\",\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2645,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2644},\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2646,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2637}},{\"nodeType\":1,\"id\":2647,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2646}},{\"nodeType\":3,\"id\":2648,\"textContent\":\"First\",\"previousSibling\":{\"id\":2647},\"parentNode\":{\"id\":2646}},{\"nodeType\":1,\"id\":2649,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2638}},{\"nodeType\":1,\"id\":2650,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2649}},{\"nodeType\":3,\"id\":2651,\"textContent\":\"Second\",\"previousSibling\":{\"id\":2650},\"parentNode\":{\"id\":2649}},{\"nodeType\":1,\"id\":2652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2639}},{\"nodeType\":1,\"id\":2653,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2652}},{\"nodeType\":3,\"id\":2654,\"textContent\":\"Third\",\"previousSibling\":{\"id\":2653},\"parentNode\":{\"id\":2652}},{\"nodeType\":1,\"id\":2655,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2640}},{\"nodeType\":1,\"id\":2656,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2655}},{\"nodeType\":3,\"id\":2657,\"textContent\":\"Fourth\",\"previousSibling\":{\"id\":2656},\"parentNode\":{\"id\":2655}},{\"nodeType\":1,\"id\":2658,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2641}},{\"nodeType\":1,\"id\":2659,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2658}},{\"nodeType\":3,\"id\":2660,\"textContent\":\"Fifth\",\"previousSibling\":{\"id\":2659},\"parentNode\":{\"id\":2658}},{\"nodeType\":1,\"id\":2661,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2642}},{\"nodeType\":1,\"id\":2662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2661}},{\"nodeType\":3,\"id\":2663,\"textContent\":\"Graduate\",\"previousSibling\":{\"id\":2662},\"parentNode\":{\"id\":2661}},{\"nodeType\":1,\"id\":2664,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2643}},{\"nodeType\":1,\"id\":2665,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2666,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2665},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2667,\"textContent\":\"*\",\"parentNode\":{\"id\":2645}},{\"nodeType\":1,\"id\":2668,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2669,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2668},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2670,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2669},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2671,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2670},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2672,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2671},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2673,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2672},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2674,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2673},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2675,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2674},\"parentNode\":{\"id\":2613}},{\"nodeType\":3,\"id\":2676,\"textContent\":\"What is your major area of study?\",\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2677,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2676},\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2678,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2669}},{\"nodeType\":1,\"id\":2679,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2678}},{\"nodeType\":3,\"id\":2680,\"textContent\":\"Math or Computer Sciences\",\"previousSibling\":{\"id\":2679},\"parentNode\":{\"id\":2678}},{\"nodeType\":1,\"id\":2681,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2670}},{\"nodeType\":1,\"id\":2682,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2681}},{\"nodeType\":3,\"id\":2683,\"textContent\":\"Social Sciences (incl. CogSci)\",\"previousSibling\":{\"id\":2682},\"parentNode\":{\"id\":2681}},{\"nodeType\":1,\"id\":2684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2671}},{\"nodeType\":1,\"id\":2685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2684}},{\"nodeType\":3,\"id\":2686,\"textContent\":\"Biomedical & Health Sciences\",\"previousSibling\":{\"id\":2685},\"parentNode\":{\"id\":2684}},{\"nodeType\":1,\"id\":2687,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2672}},{\"nodeType\":1,\"id\":2688,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2687}},{\"nodeType\":3,\"id\":2689,\"textContent\":\"Natural Sciences\",\"previousSibling\":{\"id\":2688},\"parentNode\":{\"id\":2687}},{\"nodeType\":1,\"id\":2690,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2673}},{\"nodeType\":1,\"id\":2691,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2690}},{\"nodeType\":3,\"id\":2692,\"textContent\":\"Engineering\",\"previousSibling\":{\"id\":2691},\"parentNode\":{\"id\":2690}},{\"nodeType\":1,\"id\":2693,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2674}},{\"nodeType\":1,\"id\":2694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2693}},{\"nodeType\":3,\"id\":2695,\"textContent\":\"Humanities\",\"previousSibling\":{\"id\":2694},\"parentNode\":{\"id\":2693}},{\"nodeType\":1,\"id\":2696,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2675}},{\"nodeType\":1,\"id\":2697,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2698,\"textContent\":\"Fine Arts\",\"previousSibling\":{\"id\":2697},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2699,\"textContent\":\"*\",\"parentNode\":{\"id\":2677}},{\"nodeType\":1,\"id\":2700,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2701,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2700},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2702,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2701},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2703,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2702},\"parentNode\":{\"id\":2614}},{\"nodeType\":3,\"id\":2704,\"textContent\":\"What is your gender?\",\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2705,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2704},\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2706,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2701}},{\"nodeType\":1,\"id\":2707,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2706}},{\"nodeType\":3,\"id\":2708,\"textContent\":\"Male\",\"previousSibling\":{\"id\":2707},\"parentNode\":{\"id\":2706}},{\"nodeType\":1,\"id\":2709,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2702}},{\"nodeType\":1,\"id\":2710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2709}},{\"nodeType\":3,\"id\":2711,\"textContent\":\"Female\",\"previousSibling\":{\"id\":2710},\"parentNode\":{\"id\":2709}},{\"nodeType\":1,\"id\":2712,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2703}},{\"nodeType\":1,\"id\":2713,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2714,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2713},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2715,\"textContent\":\"*\",\"parentNode\":{\"id\":2705}}],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2609},{\"id\":2610},{\"id\":2611},{\"id\":2616},{\"id\":2621},{\"id\":2622},{\"id\":2635},{\"id\":2617},{\"id\":2623},{\"id\":2624},{\"id\":2625},{\"id\":2618},{\"id\":2626},{\"id\":2627},{\"id\":2628},{\"id\":2619},{\"id\":2629},{\"id\":2630},{\"id\":2631},{\"id\":2620},{\"id\":2632},{\"id\":2633},{\"id\":2634},{\"id\":2612},{\"id\":2636},{\"id\":2644},{\"id\":2645},{\"id\":2667},{\"id\":2637},{\"id\":2646},{\"id\":2647},{\"id\":2648},{\"id\":2638},{\"id\":2649},{\"id\":2650},{\"id\":2651},{\"id\":2639},{\"id\":2652},{\"id\":2653},{\"id\":2654},{\"id\":2640},{\"id\":2655},{\"id\":2656},{\"id\":2657},{\"id\":2641},{\"id\":2658},{\"id\":2659},{\"id\":2660},{\"id\":2642},{\"id\":2661},{\"id\":2662},{\"id\":2663},{\"id\":2643},{\"id\":2664},{\"id\":2665},{\"id\":2666},{\"id\":2613},{\"id\":2668},{\"id\":2676},{\"id\":2677},{\"id\":2699},{\"id\":2669},{\"id\":2678},{\"id\":2679},{\"id\":2680},{\"id\":2670},{\"id\":2681},{\"id\":2682},{\"id\":2683},{\"id\":2671},{\"id\":2684},{\"id\":2685},{\"id\":2686},{\"id\":2672},{\"id\":2687},{\"id\":2688},{\"id\":2689},{\"id\":2673},{\"id\":2690},{\"id\":2691},{\"id\":2692},{\"id\":2674},{\"id\":2693},{\"id\":2694},{\"id\":2695},{\"id\":2675},{\"id\":2696},{\"id\":2697},{\"id\":2698},{\"id\":2614},{\"id\":2700},{\"id\":2704},{\"id\":2705},{\"id\":2715},{\"id\":2701},{\"id\":2706},{\"id\":2707},{\"id\":2708},{\"id\":2702},{\"id\":2709},{\"id\":2710},{\"id\":2711},{\"id\":2703},{\"id\":2712},{\"id\":2713},{\"id\":2714},{\"id\":2615}],[],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2716,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2717,\"textContent\":\" \",\"previousSibling\":{\"id\":2716},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2718,\"textContent\":\" \",\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":2718},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2720,\"textContent\":\" \",\"previousSibling\":{\"id\":2719},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2721,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":2720},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2722,\"textContent\":\" \",\"previousSibling\":{\"id\":2721},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2723,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":2722},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2724,\"textContent\":\" \",\"previousSibling\":{\"id\":2723},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2725,\"textContent\":\" \",\"parentNode\":{\"id\":2719}},{\"nodeType\":1,\"id\":2726,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":2725},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2727,\"textContent\":\" \",\"previousSibling\":{\"id\":2726},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2728,\"textContent\":\" \",\"parentNode\":{\"id\":2726}},{\"nodeType\":1,\"id\":2729,\"tagName\":\"H3\",\"attributes\":{},\"previousSibling\":{\"id\":2728},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2730,\"textContent\":\" \",\"previousSibling\":{\"id\":2729},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2731,\"textContent\":\"DEBRIEFING\",\"parentNode\":{\"id\":2729}},{\"nodeType\":3,\"id\":2732,\"textContent\":\" \",\"parentNode\":{\"id\":2721}},{\"nodeType\":1,\"id\":2733,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":2732},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2734,\"textContent\":\" \",\"previousSibling\":{\"id\":2733},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2735,\"textContent\":\" \",\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2736,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic\"},\"previousSibling\":{\"id\":2735},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2737,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2736},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2738,\"textContent\":\" \",\"previousSibling\":{\"id\":2737},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2739,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2738},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2740,\"textContent\":\" \",\"previousSibling\":{\"id\":2739},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2741,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2740},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2742,\"textContent\":\" \",\"previousSibling\":{\"id\":2741},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2743,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:bold;\"},\"previousSibling\":{\"id\":2742},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2744,\"textContent\":\" \",\"previousSibling\":{\"id\":2743},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2745,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":2744},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2746,\"textContent\":\" \",\"previousSibling\":{\"id\":2745},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2747,\"textContent\":\"Thank you very much for your participation! This debriefing will tell you more about the study, what you did, and why. \",\"parentNode\":{\"id\":2736}},{\"nodeType\":3,\"id\":2748,\"textContent\":\" \",\"parentNode\":{\"id\":2737}},{\"nodeType\":1,\"id\":2749,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2748},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2750,\"textContent\":\" You have just used a series of pictures (charts, graphs and diagrams) accompanied by different types of instructions to answer a series of problem solving questions. While you were using the pictures, we measured where you clicked, scrolled and pointed with the computer mouse. We also measured the accuracy of your responses and the time it took to complete each question.\",\"previousSibling\":{\"id\":2749},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2751,\"textContent\":\"What did you just do?\",\"parentNode\":{\"id\":2749}},{\"nodeType\":3,\"id\":2752,\"textContent\":\" \",\"parentNode\":{\"id\":2739}},{\"nodeType\":1,\"id\":2753,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2752},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2754,\"textContent\":\" Researchers of learning and cognition have long been interested in how graphic displays of information can be used to communicate, solve problems, and generate insights. As powerful as graphics may be in their communicative efficiency, they're not always immediately intuitive to understand. In short, we know a great deal more about learning with representations than we do about the learning of representations. In this project we are building upon previous research on reading and graph comprehension to explore how readers make sense of unfamiliar representations. The instructions you saw for each type of graph are known as “scaffolding techniques”, and we will compare your performance with the scaffolding techniques you saw with the performance of other participants to determine which types of instructions are most effective in helping humans to make sense of unfamiliar graphs. \",\"previousSibling\":{\"id\":2753},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2755,\"textContent\":\"Why did we have you do it?\",\"parentNode\":{\"id\":2753}},{\"nodeType\":1,\"id\":2756,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2757,\"textContent\":\" We expect that you will have found some of the graphics more difficult to use than others. We also expect that with the assistance of the instructions, after solving several problems you will learn to use the difficult graphics so that you can answer the questions even more quickly than without. If you would like to receive a copy of the results of the study, or have any further questions, please contact the researchers Primary Researcher: Amy Fox : a2fox@ucsd.edu Faculty Advisor : Dr. Jim Hollan : hollan@ucsd.edu \",\"previousSibling\":{\"id\":2756},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2758,\"textContent\":\"What do we expect to find?\",\"parentNode\":{\"id\":2756}},{\"nodeType\":3,\"id\":2759,\"textContent\":\"It is important that you do not discuss this experiment with other students who might participate after you. They must participate in the same way as you did, without any knowledge of what the experiment entails, or the reasoning behind it.\",\"parentNode\":{\"id\":2743}},{\"nodeType\":3,\"id\":2760,\"textContent\":\"Thank you for your time! We hope you enjoyed participating in this study as much as we enjoyed designing it.\",\"parentNode\":{\"id\":2745}},{\"nodeType\":3,\"id\":2761,\"textContent\":\" \",\"parentNode\":{\"id\":2723}},{\"nodeType\":1,\"id\":2762,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":2761},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2763,\"textContent\":\" \",\"previousSibling\":{\"id\":2762},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2764,\"textContent\":\"FINISH\",\"parentNode\":{\"id\":2762}}],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2716},{\"id\":2718},{\"id\":2719},{\"id\":2725},{\"id\":2726},{\"id\":2728},{\"id\":2729},{\"id\":2731},{\"id\":2730},{\"id\":2727},{\"id\":2720},{\"id\":2721},{\"id\":2732},{\"id\":2733},{\"id\":2735},{\"id\":2736},{\"id\":2747},{\"id\":2737},{\"id\":2748},{\"id\":2749},{\"id\":2751},{\"id\":2750},{\"id\":2738},{\"id\":2739},{\"id\":2752},{\"id\":2753},{\"id\":2755},{\"id\":2754},{\"id\":2740},{\"id\":2741},{\"id\":2756},{\"id\":2758},{\"id\":2757},{\"id\":2742},{\"id\":2743},{\"id\":2759},{\"id\":2744},{\"id\":2745},{\"id\":2760},{\"id\":2746},{\"id\":2734},{\"id\":2722},{\"id\":2723},{\"id\":2761},{\"id\":2762},{\"id\":2764},{\"id\":2763},{\"id\":2724},{\"id\":2717}],[],[],[]]}"
    },
    {
      "sequence": 8,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2765,\"tagName\":\"PRE\",\"attributes\":{\"id\":\"jspsych-data-display\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2766,\"textContent\":\"[ { \\\"rt\\\": 279431, \\\"stimulus\\\": \\\"img/phone.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"phone\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 0, \\\"time_elapsed\\\": 279433, \\\"internal_node_id\\\": \\\"0.0-0.0\\\", \\\"subject\\\": \\\"QOJ6L\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"hotel\\\", \\\"condition\\\": \\\"121\\\" }, { \\\"rt\\\": 20007, \\\"url\\\": \\\"../views/src/external/consent.html\\\", \\\"block\\\": \\\"consent\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 1, \\\"time_elapsed\\\": 300778, \\\"internal_node_id\\\": \\\"0.0-1.0\\\", \\\"subject\\\": \\\"QOJ6L\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"hotel\\\", \\\"condition\\\": \\\"121\\\" }, { \\\"rt\\\": 9414, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"hotel\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"121\\\\\\\"}\\\", \\\"block\\\": \\\"codes\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 2, \\\"time_elapsed\\\": 311201, \\\"internal_node_id\\\": \\\"0.0-2.0\\\", \\\"subject\\\": \\\"QOJ6L\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"hotel\\\", \\\"condition\\\": \\\"121\\\" }, { \\\"rt\\\": 21589, \\\"url\\\": \\\"../views/src/external/instructions_lab.html\\\", \\\"block\\\": \\\"instructions_lab\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 3, \\\"time_elapsed\\\": 333880, \\\"internal_node_id\\\": \\\"0.0-3.0\\\", \\\"subject\\\": \\\"QOJ6L\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"hotel\\\", \\\"condition\\\": \\\"121\\\" }, { \\\"rt\\\": 18575, \\\"stimulus\\\": \\\"img/acme.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"scenario\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 4, \\\"time_elapsed\\\": 353457, \\\"internal_node_id\\\": \\\"0.0-4.0\\\", \\\"subject\\\": \\\"QOJ6L\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"hotel\\\", \\\"condition\\\": \\\"121\\\" }, { \\\"rt\\\": 96850, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 5, \\\"time_elapsed\\\": 451692, \\\"internal_node_id\\\": \\\"0.0-5.0-0.0\\\", \\\"subject\\\": \\\"QOJ6L\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"hotel\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 1, \\\"clicks\\\": 4, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-H -H -11 AM-11 AM-A -F -F -F -C -C -X -X -J -J -H -H -H -H -C -C -08 AM-08 AM-08 AM-C -10 AM-11 AM-F -F -F -F -F -F -10 AM\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:737,y:571,t:1527023274628};\\\", \\\"{x:749,y:573,t:1527023274644};\\\", \\\"{x:754,y:582,t:1527023274661};\\\", \\\"{x:754,y:603,t:1527023274677};\\\", \\\"{x:754,y:618,t:1527023274693};\\\", \\\"{x:754,y:620,t:1527023274710};\\\", \\\"{x:752,y:623,t:1527023274875};\\\", \\\"{x:741,y:635,t:1527023274883};\\\", \\\"{x:741,y:649,t:1527023274893};\\\", \\\"{x:873,y:680,t:1527023274911};\\\", \\\"{x:1080,y:680,t:1527023274927};\\\", \\\"{x:1258,y:642,t:1527023274944};\\\", \\\"{x:1383,y:575,t:1527023274961};\\\", \\\"{x:1478,y:480,t:1527023274977};\\\", \\\"{x:1556,y:364,t:1527023274993};\\\", \\\"{x:1651,y:171,t:1527023275011};\\\", \\\"{x:1727,y:47,t:1527023275027};\\\", \\\"{x:1715,y:0,t:1527023275725};\\\", \\\"{x:1709,y:3,t:1527023275732};\\\", \\\"{x:1706,y:9,t:1527023275746};\\\", \\\"{x:1698,y:22,t:1527023275761};\\\", \\\"{x:1682,y:44,t:1527023275778};\\\", \\\"{x:1635,y:86,t:1527023275795};\\\", \\\"{x:1597,y:126,t:1527023275811};\\\", \\\"{x:1542,y:209,t:1527023275828};\\\", \\\"{x:1477,y:319,t:1527023275845};\\\", \\\"{x:1404,y:432,t:1527023275862};\\\", \\\"{x:1328,y:556,t:1527023275878};\\\", \\\"{x:1248,y:654,t:1527023275896};\\\", \\\"{x:1162,y:714,t:1527023275911};\\\", \\\"{x:1092,y:764,t:1527023275928};\\\", \\\"{x:1036,y:804,t:1527023275946};\\\", \\\"{x:1010,y:819,t:1527023275961};\\\", \\\"{x:1003,y:822,t:1527023275978};\\\", \\\"{x:1002,y:822,t:1527023276003};\\\", \\\"{x:1001,y:822,t:1527023276011};\\\", \\\"{x:1001,y:820,t:1527023276029};\\\", \\\"{x:1001,y:818,t:1527023276046};\\\", \\\"{x:1001,y:817,t:1527023276062};\\\", \\\"{x:1001,y:816,t:1527023276083};\\\", \\\"{x:1005,y:812,t:1527023276095};\\\", \\\"{x:1030,y:802,t:1527023276112};\\\", \\\"{x:1077,y:790,t:1527023276128};\\\", \\\"{x:1112,y:784,t:1527023276145};\\\", \\\"{x:1138,y:782,t:1527023276162};\\\", \\\"{x:1161,y:781,t:1527023276178};\\\", \\\"{x:1184,y:780,t:1527023276195};\\\", \\\"{x:1196,y:780,t:1527023276212};\\\", \\\"{x:1201,y:784,t:1527023276228};\\\", \\\"{x:1204,y:788,t:1527023276245};\\\", \\\"{x:1207,y:801,t:1527023276262};\\\", \\\"{x:1209,y:811,t:1527023276278};\\\", \\\"{x:1209,y:821,t:1527023276295};\\\", \\\"{x:1209,y:830,t:1527023276312};\\\", \\\"{x:1209,y:836,t:1527023276328};\\\", \\\"{x:1209,y:841,t:1527023276346};\\\", \\\"{x:1209,y:848,t:1527023276362};\\\", \\\"{x:1209,y:853,t:1527023276379};\\\", \\\"{x:1209,y:859,t:1527023276395};\\\", \\\"{x:1209,y:862,t:1527023276413};\\\", \\\"{x:1209,y:863,t:1527023276428};\\\", \\\"{x:1209,y:865,t:1527023276445};\\\", \\\"{x:1209,y:870,t:1527023276462};\\\", \\\"{x:1209,y:877,t:1527023276479};\\\", \\\"{x:1216,y:889,t:1527023276495};\\\", \\\"{x:1221,y:896,t:1527023276512};\\\", \\\"{x:1224,y:897,t:1527023276530};\\\", \\\"{x:1227,y:898,t:1527023276546};\\\", \\\"{x:1228,y:899,t:1527023276563};\\\", \\\"{x:1230,y:901,t:1527023276579};\\\", \\\"{x:1233,y:901,t:1527023276595};\\\", \\\"{x:1234,y:901,t:1527023276612};\\\", \\\"{x:1236,y:903,t:1527023276629};\\\", \\\"{x:1237,y:903,t:1527023276645};\\\", \\\"{x:1239,y:903,t:1527023276663};\\\", \\\"{x:1241,y:903,t:1527023276679};\\\", \\\"{x:1244,y:904,t:1527023276695};\\\", \\\"{x:1248,y:905,t:1527023276712};\\\", \\\"{x:1250,y:905,t:1527023276729};\\\", \\\"{x:1251,y:906,t:1527023276763};\\\", \\\"{x:1253,y:906,t:1527023276828};\\\", \\\"{x:1254,y:906,t:1527023276860};\\\", \\\"{x:1256,y:906,t:1527023276899};\\\", \\\"{x:1257,y:905,t:1527023276913};\\\", \\\"{x:1258,y:905,t:1527023276930};\\\", \\\"{x:1259,y:905,t:1527023276946};\\\", \\\"{x:1262,y:905,t:1527023276963};\\\", \\\"{x:1265,y:905,t:1527023276980};\\\", \\\"{x:1269,y:905,t:1527023276996};\\\", \\\"{x:1270,y:905,t:1527023277013};\\\", \\\"{x:1272,y:905,t:1527023277051};\\\", \\\"{x:1273,y:905,t:1527023277083};\\\", \\\"{x:1274,y:905,t:1527023277115};\\\", \\\"{x:1275,y:905,t:1527023277130};\\\", \\\"{x:1276,y:905,t:1527023277147};\\\", \\\"{x:1278,y:905,t:1527023277212};\\\", \\\"{x:1279,y:905,t:1527023277229};\\\", \\\"{x:1280,y:906,t:1527023277247};\\\", \\\"{x:1281,y:906,t:1527023277308};\\\", \\\"{x:1282,y:906,t:1527023277716};\\\", \\\"{x:1284,y:905,t:1527023277755};\\\", \\\"{x:1285,y:904,t:1527023277804};\\\", \\\"{x:1285,y:903,t:1527023277884};\\\", \\\"{x:1282,y:900,t:1527023277896};\\\", \\\"{x:1274,y:891,t:1527023277913};\\\", \\\"{x:1260,y:877,t:1527023277929};\\\", \\\"{x:1229,y:851,t:1527023277946};\\\", \\\"{x:1171,y:807,t:1527023277962};\\\", \\\"{x:1132,y:783,t:1527023277980};\\\", \\\"{x:1097,y:754,t:1527023277996};\\\", \\\"{x:1046,y:718,t:1527023278012};\\\", \\\"{x:1009,y:692,t:1527023278029};\\\", \\\"{x:982,y:674,t:1527023278048};\\\", \\\"{x:960,y:663,t:1527023278063};\\\", \\\"{x:939,y:650,t:1527023278080};\\\", \\\"{x:917,y:639,t:1527023278096};\\\", \\\"{x:895,y:632,t:1527023278112};\\\", \\\"{x:881,y:628,t:1527023278130};\\\", \\\"{x:867,y:623,t:1527023278146};\\\", \\\"{x:835,y:611,t:1527023278163};\\\", \\\"{x:809,y:601,t:1527023278179};\\\", \\\"{x:774,y:586,t:1527023278196};\\\", \\\"{x:718,y:563,t:1527023278212};\\\", \\\"{x:652,y:534,t:1527023278230};\\\", \\\"{x:599,y:516,t:1527023278246};\\\", \\\"{x:566,y:503,t:1527023278263};\\\", \\\"{x:541,y:493,t:1527023278280};\\\", \\\"{x:527,y:486,t:1527023278297};\\\", \\\"{x:520,y:484,t:1527023278313};\\\", \\\"{x:520,y:483,t:1527023278330};\\\", \\\"{x:523,y:483,t:1527023278442};\\\", \\\"{x:527,y:483,t:1527023278451};\\\", \\\"{x:533,y:484,t:1527023278464};\\\", \\\"{x:550,y:486,t:1527023278480};\\\", \\\"{x:576,y:492,t:1527023278498};\\\", \\\"{x:617,y:501,t:1527023278513};\\\", \\\"{x:680,y:510,t:1527023278530};\\\", \\\"{x:715,y:511,t:1527023278547};\\\", \\\"{x:743,y:511,t:1527023278564};\\\", \\\"{x:768,y:512,t:1527023278581};\\\", \\\"{x:787,y:512,t:1527023278597};\\\", \\\"{x:802,y:512,t:1527023278613};\\\", \\\"{x:808,y:512,t:1527023278630};\\\", \\\"{x:812,y:512,t:1527023278648};\\\", \\\"{x:813,y:512,t:1527023278664};\\\", \\\"{x:814,y:512,t:1527023278681};\\\", \\\"{x:817,y:512,t:1527023278771};\\\", \\\"{x:817,y:513,t:1527023278781};\\\", \\\"{x:818,y:513,t:1527023278797};\\\", \\\"{x:819,y:513,t:1527023278813};\\\", \\\"{x:820,y:513,t:1527023278843};\\\", \\\"{x:820,y:514,t:1527023279794};\\\", \\\"{x:820,y:516,t:1527023279802};\\\", \\\"{x:820,y:517,t:1527023279815};\\\", \\\"{x:820,y:522,t:1527023279832};\\\", \\\"{x:820,y:527,t:1527023279848};\\\", \\\"{x:820,y:530,t:1527023279865};\\\", \\\"{x:820,y:532,t:1527023279881};\\\", \\\"{x:820,y:534,t:1527023279898};\\\", \\\"{x:823,y:534,t:1527023279971};\\\", \\\"{x:824,y:532,t:1527023279982};\\\", \\\"{x:828,y:528,t:1527023280000};\\\", \\\"{x:832,y:524,t:1527023280015};\\\", \\\"{x:834,y:521,t:1527023280032};\\\", \\\"{x:835,y:520,t:1527023280048};\\\", \\\"{x:835,y:519,t:1527023280130};\\\", \\\"{x:836,y:519,t:1527023280138};\\\", \\\"{x:836,y:518,t:1527023280154};\\\", \\\"{x:836,y:517,t:1527023280171};\\\", \\\"{x:837,y:516,t:1527023280187};\\\", \\\"{x:838,y:516,t:1527023280612};\\\", \\\"{x:840,y:518,t:1527023280620};\\\", \\\"{x:841,y:519,t:1527023280632};\\\", \\\"{x:849,y:525,t:1527023280649};\\\", \\\"{x:855,y:529,t:1527023280666};\\\", \\\"{x:863,y:535,t:1527023280682};\\\", \\\"{x:874,y:543,t:1527023280699};\\\", \\\"{x:884,y:549,t:1527023280715};\\\", \\\"{x:901,y:560,t:1527023280732};\\\", \\\"{x:919,y:569,t:1527023280748};\\\", \\\"{x:937,y:577,t:1527023280765};\\\", \\\"{x:960,y:588,t:1527023280783};\\\", \\\"{x:984,y:600,t:1527023280799};\\\", \\\"{x:1005,y:607,t:1527023280816};\\\", \\\"{x:1022,y:611,t:1527023280833};\\\", \\\"{x:1049,y:614,t:1527023280849};\\\", \\\"{x:1086,y:617,t:1527023280866};\\\", \\\"{x:1154,y:618,t:1527023280882};\\\", \\\"{x:1204,y:615,t:1527023280899};\\\", \\\"{x:1252,y:599,t:1527023280916};\\\", \\\"{x:1301,y:580,t:1527023280933};\\\", \\\"{x:1334,y:566,t:1527023280949};\\\", \\\"{x:1359,y:550,t:1527023280966};\\\", \\\"{x:1378,y:537,t:1527023280983};\\\", \\\"{x:1397,y:522,t:1527023281000};\\\", \\\"{x:1410,y:509,t:1527023281018};\\\", \\\"{x:1416,y:501,t:1527023281034};\\\", \\\"{x:1420,y:494,t:1527023281050};\\\", \\\"{x:1421,y:490,t:1527023281066};\\\", \\\"{x:1424,y:486,t:1527023281083};\\\", \\\"{x:1425,y:485,t:1527023281100};\\\", \\\"{x:1427,y:484,t:1527023281116};\\\", \\\"{x:1427,y:483,t:1527023281187};\\\", \\\"{x:1426,y:482,t:1527023281199};\\\", \\\"{x:1419,y:482,t:1527023281217};\\\", \\\"{x:1409,y:479,t:1527023281233};\\\", \\\"{x:1385,y:477,t:1527023281251};\\\", \\\"{x:1377,y:475,t:1527023281267};\\\", \\\"{x:1353,y:472,t:1527023281284};\\\", \\\"{x:1347,y:470,t:1527023281300};\\\", \\\"{x:1345,y:469,t:1527023281317};\\\", \\\"{x:1344,y:469,t:1527023281334};\\\", \\\"{x:1343,y:469,t:1527023281351};\\\", \\\"{x:1342,y:469,t:1527023281367};\\\", \\\"{x:1341,y:467,t:1527023281384};\\\", \\\"{x:1339,y:465,t:1527023281400};\\\", \\\"{x:1338,y:464,t:1527023281416};\\\", \\\"{x:1337,y:464,t:1527023281433};\\\", \\\"{x:1335,y:460,t:1527023281451};\\\", \\\"{x:1334,y:459,t:1527023281467};\\\", \\\"{x:1333,y:457,t:1527023281483};\\\", \\\"{x:1332,y:457,t:1527023281500};\\\", \\\"{x:1332,y:456,t:1527023281539};\\\", \\\"{x:1332,y:455,t:1527023281555};\\\", \\\"{x:1331,y:454,t:1527023281567};\\\", \\\"{x:1329,y:453,t:1527023281584};\\\", \\\"{x:1329,y:452,t:1527023281600};\\\", \\\"{x:1327,y:450,t:1527023281617};\\\", \\\"{x:1326,y:449,t:1527023281633};\\\", \\\"{x:1325,y:447,t:1527023281651};\\\", \\\"{x:1324,y:446,t:1527023281668};\\\", \\\"{x:1323,y:446,t:1527023281700};\\\", \\\"{x:1321,y:456,t:1527023281771};\\\", \\\"{x:1315,y:468,t:1527023281784};\\\", \\\"{x:1293,y:507,t:1527023281801};\\\", \\\"{x:1258,y:582,t:1527023281817};\\\", \\\"{x:1210,y:675,t:1527023281834};\\\", \\\"{x:1115,y:780,t:1527023281851};\\\", \\\"{x:1066,y:797,t:1527023281867};\\\", \\\"{x:1022,y:797,t:1527023281885};\\\", \\\"{x:951,y:771,t:1527023281901};\\\", \\\"{x:858,y:718,t:1527023281917};\\\", \\\"{x:742,y:648,t:1527023281934};\\\", \\\"{x:635,y:581,t:1527023281952};\\\", \\\"{x:523,y:517,t:1527023281967};\\\", \\\"{x:416,y:454,t:1527023281984};\\\", \\\"{x:317,y:397,t:1527023282000};\\\", \\\"{x:253,y:349,t:1527023282017};\\\", \\\"{x:216,y:322,t:1527023282033};\\\", \\\"{x:210,y:317,t:1527023282050};\\\", \\\"{x:210,y:315,t:1527023282066};\\\", \\\"{x:223,y:310,t:1527023282083};\\\", \\\"{x:248,y:305,t:1527023282100};\\\", \\\"{x:280,y:305,t:1527023282117};\\\", \\\"{x:319,y:305,t:1527023282132};\\\", \\\"{x:366,y:310,t:1527023282149};\\\", \\\"{x:418,y:321,t:1527023282167};\\\", \\\"{x:469,y:337,t:1527023282183};\\\", \\\"{x:500,y:350,t:1527023282200};\\\", \\\"{x:538,y:370,t:1527023282217};\\\", \\\"{x:590,y:404,t:1527023282233};\\\", \\\"{x:683,y:471,t:1527023282251};\\\", \\\"{x:722,y:498,t:1527023282266};\\\", \\\"{x:864,y:599,t:1527023282283};\\\", \\\"{x:961,y:667,t:1527023282300};\\\", \\\"{x:1049,y:721,t:1527023282316};\\\", \\\"{x:1112,y:759,t:1527023282334};\\\", \\\"{x:1154,y:778,t:1527023282350};\\\", \\\"{x:1179,y:792,t:1527023282367};\\\", \\\"{x:1201,y:808,t:1527023282384};\\\", \\\"{x:1220,y:823,t:1527023282400};\\\", \\\"{x:1241,y:838,t:1527023282417};\\\", \\\"{x:1252,y:848,t:1527023282434};\\\", \\\"{x:1261,y:858,t:1527023282450};\\\", \\\"{x:1269,y:875,t:1527023282467};\\\", \\\"{x:1279,y:899,t:1527023282484};\\\", \\\"{x:1295,y:928,t:1527023282500};\\\", \\\"{x:1319,y:966,t:1527023282518};\\\", \\\"{x:1346,y:999,t:1527023282534};\\\", \\\"{x:1359,y:1011,t:1527023282550};\\\", \\\"{x:1366,y:1018,t:1527023282567};\\\", \\\"{x:1367,y:1018,t:1527023282584};\\\", \\\"{x:1363,y:1018,t:1527023282635};\\\", \\\"{x:1356,y:1016,t:1527023282651};\\\", \\\"{x:1336,y:1008,t:1527023282667};\\\", \\\"{x:1321,y:999,t:1527023282685};\\\", \\\"{x:1308,y:990,t:1527023282701};\\\", \\\"{x:1300,y:979,t:1527023282717};\\\", \\\"{x:1296,y:971,t:1527023282735};\\\", \\\"{x:1292,y:957,t:1527023282752};\\\", \\\"{x:1290,y:945,t:1527023282768};\\\", \\\"{x:1289,y:938,t:1527023282784};\\\", \\\"{x:1289,y:933,t:1527023282801};\\\", \\\"{x:1289,y:929,t:1527023282818};\\\", \\\"{x:1289,y:927,t:1527023282834};\\\", \\\"{x:1289,y:926,t:1527023282954};\\\", \\\"{x:1289,y:925,t:1527023282967};\\\", \\\"{x:1289,y:923,t:1527023282984};\\\", \\\"{x:1288,y:920,t:1527023283001};\\\", \\\"{x:1286,y:919,t:1527023283017};\\\", \\\"{x:1285,y:918,t:1527023283033};\\\", \\\"{x:1284,y:917,t:1527023283051};\\\", \\\"{x:1283,y:916,t:1527023283099};\\\", \\\"{x:1282,y:915,t:1527023283364};\\\", \\\"{x:1282,y:914,t:1527023283371};\\\", \\\"{x:1281,y:913,t:1527023283385};\\\", \\\"{x:1280,y:912,t:1527023283404};\\\", \\\"{x:1279,y:910,t:1527023283427};\\\", \\\"{x:1279,y:908,t:1527023283435};\\\", \\\"{x:1277,y:906,t:1527023283453};\\\", \\\"{x:1277,y:900,t:1527023283468};\\\", \\\"{x:1276,y:893,t:1527023283485};\\\", \\\"{x:1276,y:879,t:1527023283501};\\\", \\\"{x:1276,y:864,t:1527023283519};\\\", \\\"{x:1274,y:853,t:1527023283535};\\\", \\\"{x:1272,y:833,t:1527023283552};\\\", \\\"{x:1268,y:809,t:1527023283569};\\\", \\\"{x:1268,y:770,t:1527023283585};\\\", \\\"{x:1268,y:719,t:1527023283602};\\\", \\\"{x:1268,y:689,t:1527023283619};\\\", \\\"{x:1268,y:667,t:1527023283636};\\\", \\\"{x:1268,y:653,t:1527023283652};\\\", \\\"{x:1268,y:642,t:1527023283668};\\\", \\\"{x:1268,y:635,t:1527023283685};\\\", \\\"{x:1268,y:632,t:1527023283702};\\\", \\\"{x:1268,y:631,t:1527023283719};\\\", \\\"{x:1268,y:634,t:1527023283868};\\\", \\\"{x:1268,y:640,t:1527023283885};\\\", \\\"{x:1268,y:650,t:1527023283902};\\\", \\\"{x:1268,y:655,t:1527023283918};\\\", \\\"{x:1268,y:658,t:1527023283936};\\\", \\\"{x:1268,y:657,t:1527023284044};\\\", \\\"{x:1268,y:653,t:1527023284052};\\\", \\\"{x:1269,y:644,t:1527023284069};\\\", \\\"{x:1269,y:641,t:1527023284086};\\\", \\\"{x:1270,y:640,t:1527023284102};\\\", \\\"{x:1270,y:639,t:1527023284467};\\\", \\\"{x:1271,y:639,t:1527023284485};\\\", \\\"{x:1273,y:638,t:1527023284692};\\\", \\\"{x:1273,y:637,t:1527023285179};\\\", \\\"{x:1274,y:637,t:1527023285187};\\\", \\\"{x:1275,y:637,t:1527023285211};\\\", \\\"{x:1278,y:638,t:1527023285243};\\\", \\\"{x:1279,y:640,t:1527023285491};\\\", \\\"{x:1279,y:641,t:1527023285532};\\\", \\\"{x:1279,y:642,t:1527023285546};\\\", \\\"{x:1280,y:643,t:1527023285554};\\\", \\\"{x:1281,y:644,t:1527023285569};\\\", \\\"{x:1282,y:648,t:1527023285586};\\\", \\\"{x:1284,y:652,t:1527023285602};\\\", \\\"{x:1286,y:657,t:1527023285619};\\\", \\\"{x:1289,y:663,t:1527023285636};\\\", \\\"{x:1290,y:666,t:1527023285652};\\\", \\\"{x:1292,y:671,t:1527023285669};\\\", \\\"{x:1294,y:674,t:1527023285686};\\\", \\\"{x:1295,y:679,t:1527023285703};\\\", \\\"{x:1298,y:684,t:1527023285719};\\\", \\\"{x:1299,y:689,t:1527023285736};\\\", \\\"{x:1301,y:691,t:1527023285752};\\\", \\\"{x:1301,y:694,t:1527023285769};\\\", \\\"{x:1301,y:695,t:1527023285787};\\\", \\\"{x:1301,y:696,t:1527023285803};\\\", \\\"{x:1301,y:697,t:1527023285835};\\\", \\\"{x:1301,y:698,t:1527023285851};\\\", \\\"{x:1302,y:700,t:1527023285882};\\\", \\\"{x:1303,y:701,t:1527023286130};\\\", \\\"{x:1304,y:702,t:1527023286154};\\\", \\\"{x:1306,y:703,t:1527023286202};\\\", \\\"{x:1308,y:704,t:1527023286282};\\\", \\\"{x:1309,y:705,t:1527023286313};\\\", \\\"{x:1310,y:705,t:1527023286338};\\\", \\\"{x:1310,y:706,t:1527023286426};\\\", \\\"{x:1311,y:706,t:1527023286626};\\\", \\\"{x:1312,y:706,t:1527023286636};\\\", \\\"{x:1311,y:706,t:1527023286794};\\\", \\\"{x:1310,y:705,t:1527023286803};\\\", \\\"{x:1305,y:703,t:1527023286821};\\\", \\\"{x:1300,y:700,t:1527023286836};\\\", \\\"{x:1293,y:694,t:1527023286853};\\\", \\\"{x:1279,y:687,t:1527023286870};\\\", \\\"{x:1260,y:679,t:1527023286886};\\\", \\\"{x:1211,y:658,t:1527023286903};\\\", \\\"{x:1135,y:628,t:1527023286920};\\\", \\\"{x:1042,y:592,t:1527023286936};\\\", \\\"{x:944,y:556,t:1527023286953};\\\", \\\"{x:801,y:509,t:1527023286970};\\\", \\\"{x:759,y:496,t:1527023286986};\\\", \\\"{x:739,y:489,t:1527023287004};\\\", \\\"{x:729,y:485,t:1527023287021};\\\", \\\"{x:728,y:484,t:1527023287037};\\\", \\\"{x:730,y:484,t:1527023287218};\\\", \\\"{x:734,y:484,t:1527023287226};\\\", \\\"{x:738,y:485,t:1527023287238};\\\", \\\"{x:752,y:488,t:1527023287255};\\\", \\\"{x:770,y:494,t:1527023287272};\\\", \\\"{x:788,y:499,t:1527023287288};\\\", \\\"{x:801,y:502,t:1527023287304};\\\", \\\"{x:812,y:503,t:1527023287322};\\\", \\\"{x:825,y:506,t:1527023287339};\\\", \\\"{x:831,y:507,t:1527023287355};\\\", \\\"{x:835,y:507,t:1527023287371};\\\", \\\"{x:839,y:507,t:1527023287387};\\\", \\\"{x:848,y:511,t:1527023287404};\\\", \\\"{x:862,y:515,t:1527023287420};\\\", \\\"{x:875,y:518,t:1527023287437};\\\", \\\"{x:896,y:526,t:1527023287454};\\\", \\\"{x:943,y:542,t:1527023287472};\\\", \\\"{x:1004,y:560,t:1527023287489};\\\", \\\"{x:1071,y:580,t:1527023287504};\\\", \\\"{x:1135,y:597,t:1527023287522};\\\", \\\"{x:1208,y:619,t:1527023287538};\\\", \\\"{x:1240,y:628,t:1527023287554};\\\", \\\"{x:1259,y:632,t:1527023287572};\\\", \\\"{x:1268,y:636,t:1527023287589};\\\", \\\"{x:1271,y:637,t:1527023287605};\\\", \\\"{x:1273,y:638,t:1527023287621};\\\", \\\"{x:1273,y:639,t:1527023287803};\\\", \\\"{x:1276,y:643,t:1527023287812};\\\", \\\"{x:1276,y:647,t:1527023287823};\\\", \\\"{x:1278,y:651,t:1527023287839};\\\", \\\"{x:1280,y:655,t:1527023287856};\\\", \\\"{x:1281,y:656,t:1527023287873};\\\", \\\"{x:1281,y:657,t:1527023287889};\\\", \\\"{x:1283,y:656,t:1527023288092};\\\", \\\"{x:1283,y:655,t:1527023288106};\\\", \\\"{x:1283,y:654,t:1527023288131};\\\", \\\"{x:1283,y:652,t:1527023288618};\\\", \\\"{x:1286,y:651,t:1527023288627};\\\", \\\"{x:1288,y:651,t:1527023288639};\\\", \\\"{x:1296,y:650,t:1527023288657};\\\", \\\"{x:1308,y:646,t:1527023288673};\\\", \\\"{x:1322,y:640,t:1527023288690};\\\", \\\"{x:1346,y:629,t:1527023288706};\\\", \\\"{x:1357,y:625,t:1527023288723};\\\", \\\"{x:1369,y:617,t:1527023288739};\\\", \\\"{x:1371,y:615,t:1527023288756};\\\", \\\"{x:1372,y:616,t:1527023289122};\\\", \\\"{x:1374,y:618,t:1527023289130};\\\", \\\"{x:1375,y:619,t:1527023289140};\\\", \\\"{x:1376,y:620,t:1527023289156};\\\", \\\"{x:1376,y:624,t:1527023289174};\\\", \\\"{x:1380,y:631,t:1527023289190};\\\", \\\"{x:1382,y:633,t:1527023289207};\\\", \\\"{x:1382,y:634,t:1527023289223};\\\", \\\"{x:1383,y:637,t:1527023289240};\\\", \\\"{x:1386,y:640,t:1527023289257};\\\", \\\"{x:1386,y:642,t:1527023289273};\\\", \\\"{x:1387,y:643,t:1527023289290};\\\", \\\"{x:1388,y:644,t:1527023289307};\\\", \\\"{x:1389,y:645,t:1527023289323};\\\", \\\"{x:1389,y:646,t:1527023289340};\\\", \\\"{x:1389,y:653,t:1527023289358};\\\", \\\"{x:1389,y:668,t:1527023289373};\\\", \\\"{x:1389,y:680,t:1527023289390};\\\", \\\"{x:1389,y:694,t:1527023289407};\\\", \\\"{x:1389,y:703,t:1527023289423};\\\", \\\"{x:1388,y:709,t:1527023289440};\\\", \\\"{x:1384,y:714,t:1527023289457};\\\", \\\"{x:1378,y:717,t:1527023289473};\\\", \\\"{x:1354,y:718,t:1527023289489};\\\", \\\"{x:1330,y:718,t:1527023289507};\\\", \\\"{x:1308,y:710,t:1527023289523};\\\", \\\"{x:1289,y:703,t:1527023289540};\\\", \\\"{x:1275,y:696,t:1527023289557};\\\", \\\"{x:1271,y:694,t:1527023289574};\\\", \\\"{x:1270,y:694,t:1527023289590};\\\", \\\"{x:1269,y:692,t:1527023289666};\\\", \\\"{x:1270,y:690,t:1527023289682};\\\", \\\"{x:1274,y:687,t:1527023289690};\\\", \\\"{x:1282,y:680,t:1527023289708};\\\", \\\"{x:1294,y:672,t:1527023289724};\\\", \\\"{x:1303,y:666,t:1527023289739};\\\", \\\"{x:1314,y:657,t:1527023289757};\\\", \\\"{x:1321,y:652,t:1527023289774};\\\", \\\"{x:1323,y:650,t:1527023289790};\\\", \\\"{x:1323,y:647,t:1527023289807};\\\", \\\"{x:1323,y:646,t:1527023289824};\\\", \\\"{x:1323,y:644,t:1527023289841};\\\", \\\"{x:1323,y:640,t:1527023289857};\\\", \\\"{x:1323,y:627,t:1527023289874};\\\", \\\"{x:1323,y:616,t:1527023289891};\\\", \\\"{x:1323,y:602,t:1527023289907};\\\", \\\"{x:1323,y:595,t:1527023289924};\\\", \\\"{x:1323,y:587,t:1527023289941};\\\", \\\"{x:1323,y:580,t:1527023289957};\\\", \\\"{x:1323,y:571,t:1527023289974};\\\", \\\"{x:1323,y:567,t:1527023289991};\\\", \\\"{x:1323,y:564,t:1527023290007};\\\", \\\"{x:1323,y:566,t:1527023290154};\\\", \\\"{x:1323,y:569,t:1527023290162};\\\", \\\"{x:1323,y:571,t:1527023290174};\\\", \\\"{x:1323,y:574,t:1527023290191};\\\", \\\"{x:1322,y:577,t:1527023290208};\\\", \\\"{x:1320,y:582,t:1527023290224};\\\", \\\"{x:1318,y:585,t:1527023290241};\\\", \\\"{x:1317,y:588,t:1527023290258};\\\", \\\"{x:1316,y:589,t:1527023290274};\\\", \\\"{x:1312,y:590,t:1527023290291};\\\", \\\"{x:1308,y:593,t:1527023290308};\\\", \\\"{x:1302,y:595,t:1527023290324};\\\", \\\"{x:1296,y:595,t:1527023290341};\\\", \\\"{x:1288,y:595,t:1527023290358};\\\", \\\"{x:1284,y:595,t:1527023290374};\\\", \\\"{x:1281,y:595,t:1527023290391};\\\", \\\"{x:1281,y:599,t:1527023290522};\\\", \\\"{x:1281,y:602,t:1527023290530};\\\", \\\"{x:1281,y:605,t:1527023290541};\\\", \\\"{x:1282,y:610,t:1527023290558};\\\", \\\"{x:1284,y:614,t:1527023290575};\\\", \\\"{x:1286,y:618,t:1527023290590};\\\", \\\"{x:1286,y:619,t:1527023290610};\\\", \\\"{x:1286,y:620,t:1527023290730};\\\", \\\"{x:1286,y:621,t:1527023290746};\\\", \\\"{x:1286,y:622,t:1527023290757};\\\", \\\"{x:1282,y:625,t:1527023290775};\\\", \\\"{x:1280,y:626,t:1527023290792};\\\", \\\"{x:1274,y:630,t:1527023290808};\\\", \\\"{x:1270,y:632,t:1527023290825};\\\", \\\"{x:1266,y:634,t:1527023290842};\\\", \\\"{x:1263,y:635,t:1527023290858};\\\", \\\"{x:1262,y:636,t:1527023290875};\\\", \\\"{x:1261,y:636,t:1527023290892};\\\", \\\"{x:1259,y:637,t:1527023291002};\\\", \\\"{x:1258,y:637,t:1527023291010};\\\", \\\"{x:1254,y:637,t:1527023291025};\\\", \\\"{x:1231,y:637,t:1527023291041};\\\", \\\"{x:1190,y:637,t:1527023291059};\\\", \\\"{x:1130,y:634,t:1527023291075};\\\", \\\"{x:1044,y:621,t:1527023291092};\\\", \\\"{x:931,y:595,t:1527023291109};\\\", \\\"{x:804,y:556,t:1527023291126};\\\", \\\"{x:687,y:517,t:1527023291143};\\\", \\\"{x:604,y:496,t:1527023291157};\\\", \\\"{x:559,y:482,t:1527023291172};\\\", \\\"{x:537,y:479,t:1527023291191};\\\", \\\"{x:518,y:473,t:1527023291207};\\\", \\\"{x:517,y:472,t:1527023291224};\\\", \\\"{x:516,y:471,t:1527023291250};\\\", \\\"{x:519,y:471,t:1527023291274};\\\", \\\"{x:529,y:469,t:1527023291291};\\\", \\\"{x:552,y:469,t:1527023291307};\\\", \\\"{x:579,y:469,t:1527023291324};\\\", \\\"{x:618,y:469,t:1527023291341};\\\", \\\"{x:663,y:469,t:1527023291358};\\\", \\\"{x:713,y:469,t:1527023291374};\\\", \\\"{x:766,y:469,t:1527023291391};\\\", \\\"{x:803,y:469,t:1527023291408};\\\", \\\"{x:824,y:471,t:1527023291424};\\\", \\\"{x:834,y:472,t:1527023291441};\\\", \\\"{x:834,y:473,t:1527023291570};\\\", \\\"{x:834,y:474,t:1527023291577};\\\", \\\"{x:834,y:477,t:1527023291591};\\\", \\\"{x:834,y:482,t:1527023291609};\\\", \\\"{x:834,y:488,t:1527023291625};\\\", \\\"{x:834,y:493,t:1527023291642};\\\", \\\"{x:834,y:497,t:1527023291657};\\\", \\\"{x:835,y:498,t:1527023291690};\\\", \\\"{x:836,y:500,t:1527023292354};\\\", \\\"{x:839,y:502,t:1527023292362};\\\", \\\"{x:843,y:504,t:1527023292375};\\\", \\\"{x:852,y:508,t:1527023292392};\\\", \\\"{x:864,y:513,t:1527023292408};\\\", \\\"{x:873,y:514,t:1527023292426};\\\", \\\"{x:884,y:519,t:1527023292442};\\\", \\\"{x:890,y:520,t:1527023292459};\\\", \\\"{x:892,y:521,t:1527023292475};\\\", \\\"{x:893,y:521,t:1527023292493};\\\", \\\"{x:893,y:522,t:1527023292509};\\\", \\\"{x:894,y:522,t:1527023292836};\\\", \\\"{x:897,y:522,t:1527023292843};\\\", \\\"{x:908,y:524,t:1527023292859};\\\", \\\"{x:929,y:524,t:1527023292875};\\\", \\\"{x:945,y:524,t:1527023292892};\\\", \\\"{x:946,y:524,t:1527023293364};\\\", \\\"{x:946,y:525,t:1527023293376};\\\", \\\"{x:947,y:525,t:1527023293392};\\\", \\\"{x:948,y:525,t:1527023293539};\\\", \\\"{x:949,y:525,t:1527023293547};\\\", \\\"{x:950,y:525,t:1527023293579};\\\", \\\"{x:951,y:525,t:1527023293595};\\\", \\\"{x:953,y:525,t:1527023293610};\\\", \\\"{x:961,y:525,t:1527023293627};\\\", \\\"{x:972,y:525,t:1527023293643};\\\", \\\"{x:985,y:525,t:1527023293660};\\\", \\\"{x:999,y:528,t:1527023293677};\\\", \\\"{x:1018,y:537,t:1527023293694};\\\", \\\"{x:1043,y:544,t:1527023293711};\\\", \\\"{x:1076,y:554,t:1527023293727};\\\", \\\"{x:1112,y:563,t:1527023293744};\\\", \\\"{x:1149,y:575,t:1527023293760};\\\", \\\"{x:1185,y:585,t:1527023293777};\\\", \\\"{x:1211,y:595,t:1527023293794};\\\", \\\"{x:1239,y:603,t:1527023293810};\\\", \\\"{x:1270,y:611,t:1527023293827};\\\", \\\"{x:1272,y:611,t:1527023293844};\\\", \\\"{x:1272,y:612,t:1527023294258};\\\", \\\"{x:1273,y:612,t:1527023294266};\\\", \\\"{x:1273,y:613,t:1527023294306};\\\", \\\"{x:1274,y:614,t:1527023294339};\\\", \\\"{x:1275,y:615,t:1527023294379};\\\", \\\"{x:1276,y:616,t:1527023294394};\\\", \\\"{x:1278,y:618,t:1527023294410};\\\", \\\"{x:1280,y:622,t:1527023294427};\\\", \\\"{x:1282,y:624,t:1527023294443};\\\", \\\"{x:1288,y:630,t:1527023294460};\\\", \\\"{x:1300,y:640,t:1527023294478};\\\", \\\"{x:1315,y:649,t:1527023294494};\\\", \\\"{x:1330,y:656,t:1527023294510};\\\", \\\"{x:1344,y:665,t:1527023294528};\\\", \\\"{x:1356,y:675,t:1527023294544};\\\", \\\"{x:1367,y:682,t:1527023294561};\\\", \\\"{x:1373,y:688,t:1527023294578};\\\", \\\"{x:1379,y:695,t:1527023294594};\\\", \\\"{x:1381,y:701,t:1527023294611};\\\", \\\"{x:1381,y:705,t:1527023294628};\\\", \\\"{x:1381,y:709,t:1527023294644};\\\", \\\"{x:1381,y:717,t:1527023294661};\\\", \\\"{x:1374,y:730,t:1527023294678};\\\", \\\"{x:1367,y:742,t:1527023294694};\\\", \\\"{x:1358,y:751,t:1527023294711};\\\", \\\"{x:1349,y:757,t:1527023294728};\\\", \\\"{x:1339,y:765,t:1527023294744};\\\", \\\"{x:1332,y:770,t:1527023294760};\\\", \\\"{x:1329,y:771,t:1527023294778};\\\", \\\"{x:1326,y:774,t:1527023294794};\\\", \\\"{x:1324,y:774,t:1527023294811};\\\", \\\"{x:1321,y:774,t:1527023294828};\\\", \\\"{x:1314,y:774,t:1527023294845};\\\", \\\"{x:1302,y:773,t:1527023294861};\\\", \\\"{x:1284,y:771,t:1527023294878};\\\", \\\"{x:1263,y:768,t:1527023294895};\\\", \\\"{x:1243,y:766,t:1527023294911};\\\", \\\"{x:1222,y:762,t:1527023294928};\\\", \\\"{x:1206,y:760,t:1527023294945};\\\", \\\"{x:1199,y:760,t:1527023294961};\\\", \\\"{x:1198,y:760,t:1527023294977};\\\", \\\"{x:1197,y:759,t:1527023295012};\\\", \\\"{x:1197,y:758,t:1527023295035};\\\", \\\"{x:1198,y:758,t:1527023295045};\\\", \\\"{x:1199,y:759,t:1527023295061};\\\", \\\"{x:1200,y:761,t:1527023295078};\\\", \\\"{x:1203,y:764,t:1527023295095};\\\", \\\"{x:1205,y:766,t:1527023295111};\\\", \\\"{x:1206,y:766,t:1527023295129};\\\", \\\"{x:1209,y:769,t:1527023295145};\\\", \\\"{x:1211,y:769,t:1527023295161};\\\", \\\"{x:1212,y:770,t:1527023295178};\\\", \\\"{x:1214,y:771,t:1527023295195};\\\", \\\"{x:1216,y:771,t:1527023296179};\\\", \\\"{x:1223,y:773,t:1527023296196};\\\", \\\"{x:1237,y:777,t:1527023296212};\\\", \\\"{x:1257,y:783,t:1527023296229};\\\", \\\"{x:1283,y:788,t:1527023296245};\\\", \\\"{x:1313,y:793,t:1527023296262};\\\", \\\"{x:1341,y:797,t:1527023296278};\\\", \\\"{x:1367,y:802,t:1527023296295};\\\", \\\"{x:1385,y:804,t:1527023296312};\\\", \\\"{x:1398,y:806,t:1527023296329};\\\", \\\"{x:1404,y:807,t:1527023296346};\\\", \\\"{x:1405,y:807,t:1527023296361};\\\", \\\"{x:1407,y:807,t:1527023296427};\\\", \\\"{x:1408,y:807,t:1527023296435};\\\", \\\"{x:1412,y:807,t:1527023296447};\\\", \\\"{x:1420,y:807,t:1527023296462};\\\", \\\"{x:1429,y:805,t:1527023296480};\\\", \\\"{x:1430,y:805,t:1527023296858};\\\", \\\"{x:1432,y:806,t:1527023296866};\\\", \\\"{x:1434,y:806,t:1527023296890};\\\", \\\"{x:1436,y:807,t:1527023296906};\\\", \\\"{x:1437,y:808,t:1527023296922};\\\", \\\"{x:1438,y:808,t:1527023296938};\\\", \\\"{x:1439,y:808,t:1527023296962};\\\", \\\"{x:1441,y:808,t:1527023296986};\\\", \\\"{x:1441,y:807,t:1527023296995};\\\", \\\"{x:1443,y:806,t:1527023297013};\\\", \\\"{x:1444,y:805,t:1527023297029};\\\", \\\"{x:1445,y:804,t:1527023297045};\\\", \\\"{x:1443,y:804,t:1527023297683};\\\", \\\"{x:1442,y:803,t:1527023297697};\\\", \\\"{x:1441,y:801,t:1527023297713};\\\", \\\"{x:1437,y:799,t:1527023297730};\\\", \\\"{x:1426,y:792,t:1527023297748};\\\", \\\"{x:1413,y:786,t:1527023297763};\\\", \\\"{x:1400,y:781,t:1527023297781};\\\", \\\"{x:1386,y:775,t:1527023297797};\\\", \\\"{x:1371,y:768,t:1527023297814};\\\", \\\"{x:1355,y:761,t:1527023297831};\\\", \\\"{x:1343,y:755,t:1527023297848};\\\", \\\"{x:1335,y:751,t:1527023297864};\\\", \\\"{x:1331,y:749,t:1527023297881};\\\", \\\"{x:1330,y:749,t:1527023297898};\\\", \\\"{x:1328,y:748,t:1527023297927};\\\", \\\"{x:1327,y:746,t:1527023297954};\\\", \\\"{x:1326,y:746,t:1527023297994};\\\", \\\"{x:1325,y:745,t:1527023298002};\\\", \\\"{x:1324,y:745,t:1527023298013};\\\", \\\"{x:1323,y:743,t:1527023298029};\\\", \\\"{x:1319,y:739,t:1527023298047};\\\", \\\"{x:1317,y:737,t:1527023298064};\\\", \\\"{x:1317,y:736,t:1527023298080};\\\", \\\"{x:1316,y:735,t:1527023298097};\\\", \\\"{x:1315,y:735,t:1527023298162};\\\", \\\"{x:1313,y:737,t:1527023298171};\\\", \\\"{x:1310,y:742,t:1527023298180};\\\", \\\"{x:1306,y:754,t:1527023298197};\\\", \\\"{x:1301,y:770,t:1527023298214};\\\", \\\"{x:1298,y:783,t:1527023298230};\\\", \\\"{x:1295,y:794,t:1527023298247};\\\", \\\"{x:1294,y:804,t:1527023298264};\\\", \\\"{x:1291,y:812,t:1527023298281};\\\", \\\"{x:1291,y:817,t:1527023298297};\\\", \\\"{x:1291,y:822,t:1527023298314};\\\", \\\"{x:1290,y:829,t:1527023298330};\\\", \\\"{x:1290,y:835,t:1527023298347};\\\", \\\"{x:1290,y:837,t:1527023298364};\\\", \\\"{x:1290,y:839,t:1527023298381};\\\", \\\"{x:1290,y:842,t:1527023298398};\\\", \\\"{x:1290,y:845,t:1527023298415};\\\", \\\"{x:1290,y:850,t:1527023298431};\\\", \\\"{x:1286,y:855,t:1527023298447};\\\", \\\"{x:1283,y:860,t:1527023298465};\\\", \\\"{x:1281,y:864,t:1527023298481};\\\", \\\"{x:1279,y:866,t:1527023298497};\\\", \\\"{x:1277,y:871,t:1527023298514};\\\", \\\"{x:1275,y:876,t:1527023298530};\\\", \\\"{x:1274,y:878,t:1527023298547};\\\", \\\"{x:1274,y:880,t:1527023298564};\\\", \\\"{x:1274,y:882,t:1527023298581};\\\", \\\"{x:1274,y:885,t:1527023298598};\\\", \\\"{x:1274,y:889,t:1527023298614};\\\", \\\"{x:1274,y:892,t:1527023298631};\\\", \\\"{x:1275,y:895,t:1527023298647};\\\", \\\"{x:1276,y:898,t:1527023298664};\\\", \\\"{x:1277,y:899,t:1527023298683};\\\", \\\"{x:1277,y:900,t:1527023298698};\\\", \\\"{x:1279,y:901,t:1527023298714};\\\", \\\"{x:1279,y:902,t:1527023298732};\\\", \\\"{x:1280,y:903,t:1527023298836};\\\", \\\"{x:1281,y:903,t:1527023298899};\\\", \\\"{x:1282,y:904,t:1527023298940};\\\", \\\"{x:1282,y:905,t:1527023298963};\\\", \\\"{x:1282,y:904,t:1527023299155};\\\", \\\"{x:1282,y:902,t:1527023299165};\\\", \\\"{x:1282,y:899,t:1527023299181};\\\", \\\"{x:1281,y:895,t:1527023299199};\\\", \\\"{x:1281,y:891,t:1527023299215};\\\", \\\"{x:1281,y:885,t:1527023299231};\\\", \\\"{x:1281,y:878,t:1527023299248};\\\", \\\"{x:1281,y:872,t:1527023299265};\\\", \\\"{x:1280,y:865,t:1527023299281};\\\", \\\"{x:1280,y:850,t:1527023299299};\\\", \\\"{x:1280,y:841,t:1527023299314};\\\", \\\"{x:1280,y:819,t:1527023299331};\\\", \\\"{x:1280,y:804,t:1527023299348};\\\", \\\"{x:1280,y:789,t:1527023299366};\\\", \\\"{x:1280,y:777,t:1527023299381};\\\", \\\"{x:1280,y:766,t:1527023299399};\\\", \\\"{x:1280,y:753,t:1527023299416};\\\", \\\"{x:1280,y:739,t:1527023299431};\\\", \\\"{x:1280,y:731,t:1527023299449};\\\", \\\"{x:1280,y:722,t:1527023299465};\\\", \\\"{x:1280,y:710,t:1527023299482};\\\", \\\"{x:1280,y:697,t:1527023299499};\\\", \\\"{x:1280,y:680,t:1527023299516};\\\", \\\"{x:1280,y:665,t:1527023299531};\\\", \\\"{x:1280,y:655,t:1527023299549};\\\", \\\"{x:1280,y:640,t:1527023299565};\\\", \\\"{x:1283,y:626,t:1527023299581};\\\", \\\"{x:1284,y:616,t:1527023299598};\\\", \\\"{x:1286,y:607,t:1527023299615};\\\", \\\"{x:1286,y:605,t:1527023299631};\\\", \\\"{x:1286,y:602,t:1527023299648};\\\", \\\"{x:1287,y:600,t:1527023299665};\\\", \\\"{x:1287,y:597,t:1527023299682};\\\", \\\"{x:1288,y:595,t:1527023299699};\\\", \\\"{x:1288,y:593,t:1527023299715};\\\", \\\"{x:1288,y:589,t:1527023299732};\\\", \\\"{x:1290,y:581,t:1527023299748};\\\", \\\"{x:1291,y:577,t:1527023299765};\\\", \\\"{x:1292,y:571,t:1527023299782};\\\", \\\"{x:1292,y:567,t:1527023299797};\\\", \\\"{x:1292,y:562,t:1527023299814};\\\", \\\"{x:1293,y:556,t:1527023299831};\\\", \\\"{x:1293,y:549,t:1527023299847};\\\", \\\"{x:1294,y:544,t:1527023299864};\\\", \\\"{x:1294,y:541,t:1527023299882};\\\", \\\"{x:1295,y:540,t:1527023299898};\\\", \\\"{x:1295,y:539,t:1527023299930};\\\", \\\"{x:1295,y:537,t:1527023299938};\\\", \\\"{x:1295,y:536,t:1527023299962};\\\", \\\"{x:1295,y:535,t:1527023299970};\\\", \\\"{x:1295,y:534,t:1527023299982};\\\", \\\"{x:1295,y:533,t:1527023300003};\\\", \\\"{x:1295,y:532,t:1527023300027};\\\", \\\"{x:1295,y:531,t:1527023300035};\\\", \\\"{x:1295,y:529,t:1527023300051};\\\", \\\"{x:1295,y:528,t:1527023300065};\\\", \\\"{x:1294,y:524,t:1527023300083};\\\", \\\"{x:1294,y:520,t:1527023300099};\\\", \\\"{x:1292,y:517,t:1527023300114};\\\", \\\"{x:1291,y:515,t:1527023300131};\\\", \\\"{x:1290,y:512,t:1527023300147};\\\", \\\"{x:1290,y:511,t:1527023300164};\\\", \\\"{x:1289,y:510,t:1527023300181};\\\", \\\"{x:1287,y:509,t:1527023300708};\\\", \\\"{x:1287,y:508,t:1527023300717};\\\", \\\"{x:1286,y:508,t:1527023300916};\\\", \\\"{x:1285,y:508,t:1527023301091};\\\", \\\"{x:1285,y:510,t:1527023301147};\\\", \\\"{x:1284,y:510,t:1527023301195};\\\", \\\"{x:1284,y:511,t:1527023301243};\\\", \\\"{x:1284,y:513,t:1527023301268};\\\", \\\"{x:1282,y:515,t:1527023301284};\\\", \\\"{x:1282,y:516,t:1527023301300};\\\", \\\"{x:1282,y:518,t:1527023301331};\\\", \\\"{x:1282,y:519,t:1527023301339};\\\", \\\"{x:1282,y:520,t:1527023301349};\\\", \\\"{x:1282,y:521,t:1527023301365};\\\", \\\"{x:1282,y:523,t:1527023301382};\\\", \\\"{x:1282,y:524,t:1527023301410};\\\", \\\"{x:1282,y:526,t:1527023301417};\\\", \\\"{x:1282,y:527,t:1527023301442};\\\", \\\"{x:1282,y:529,t:1527023301450};\\\", \\\"{x:1282,y:533,t:1527023301466};\\\", \\\"{x:1282,y:538,t:1527023301482};\\\", \\\"{x:1282,y:541,t:1527023301500};\\\", \\\"{x:1281,y:547,t:1527023301516};\\\", \\\"{x:1281,y:553,t:1527023301533};\\\", \\\"{x:1281,y:565,t:1527023301550};\\\", \\\"{x:1283,y:579,t:1527023301566};\\\", \\\"{x:1285,y:597,t:1527023301583};\\\", \\\"{x:1288,y:611,t:1527023301600};\\\", \\\"{x:1289,y:624,t:1527023301616};\\\", \\\"{x:1290,y:634,t:1527023301633};\\\", \\\"{x:1293,y:638,t:1527023301650};\\\", \\\"{x:1293,y:645,t:1527023301666};\\\", \\\"{x:1293,y:648,t:1527023301683};\\\", \\\"{x:1293,y:653,t:1527023301701};\\\", \\\"{x:1293,y:657,t:1527023301717};\\\", \\\"{x:1292,y:664,t:1527023301734};\\\", \\\"{x:1291,y:670,t:1527023301750};\\\", \\\"{x:1290,y:677,t:1527023301766};\\\", \\\"{x:1288,y:687,t:1527023301783};\\\", \\\"{x:1286,y:703,t:1527023301800};\\\", \\\"{x:1286,y:716,t:1527023301816};\\\", \\\"{x:1285,y:732,t:1527023301833};\\\", \\\"{x:1285,y:751,t:1527023301851};\\\", \\\"{x:1285,y:759,t:1527023301866};\\\", \\\"{x:1285,y:767,t:1527023301883};\\\", \\\"{x:1285,y:772,t:1527023301900};\\\", \\\"{x:1285,y:777,t:1527023301917};\\\", \\\"{x:1285,y:781,t:1527023301934};\\\", \\\"{x:1285,y:783,t:1527023301950};\\\", \\\"{x:1285,y:784,t:1527023301968};\\\", \\\"{x:1285,y:786,t:1527023301983};\\\", \\\"{x:1285,y:787,t:1527023302001};\\\", \\\"{x:1284,y:787,t:1527023302212};\\\", \\\"{x:1283,y:787,t:1527023302227};\\\", \\\"{x:1283,y:786,t:1527023302252};\\\", \\\"{x:1282,y:785,t:1527023302267};\\\", \\\"{x:1281,y:784,t:1527023302283};\\\", \\\"{x:1280,y:783,t:1527023302507};\\\", \\\"{x:1279,y:782,t:1527023302517};\\\", \\\"{x:1278,y:781,t:1527023302535};\\\", \\\"{x:1277,y:781,t:1527023302555};\\\", \\\"{x:1277,y:780,t:1527023303052};\\\", \\\"{x:1277,y:779,t:1527023303068};\\\", \\\"{x:1277,y:778,t:1527023303085};\\\", \\\"{x:1277,y:777,t:1527023303102};\\\", \\\"{x:1278,y:776,t:1527023303812};\\\", \\\"{x:1279,y:776,t:1527023303843};\\\", \\\"{x:1280,y:776,t:1527023303852};\\\", \\\"{x:1281,y:776,t:1527023303891};\\\", \\\"{x:1281,y:778,t:1527023306554};\\\", \\\"{x:1281,y:780,t:1527023306867};\\\", \\\"{x:1276,y:781,t:1527023306882};\\\", \\\"{x:1261,y:782,t:1527023306890};\\\", \\\"{x:1248,y:782,t:1527023306904};\\\", \\\"{x:1215,y:780,t:1527023306920};\\\", \\\"{x:1172,y:777,t:1527023306937};\\\", \\\"{x:1103,y:767,t:1527023306954};\\\", \\\"{x:1042,y:758,t:1527023306970};\\\", \\\"{x:965,y:753,t:1527023306987};\\\", \\\"{x:879,y:740,t:1527023307004};\\\", \\\"{x:793,y:729,t:1527023307020};\\\", \\\"{x:706,y:716,t:1527023307037};\\\", \\\"{x:629,y:705,t:1527023307054};\\\", \\\"{x:573,y:697,t:1527023307070};\\\", \\\"{x:539,y:690,t:1527023307088};\\\", \\\"{x:518,y:690,t:1527023307105};\\\", \\\"{x:500,y:688,t:1527023307121};\\\", \\\"{x:481,y:685,t:1527023307137};\\\", \\\"{x:456,y:681,t:1527023307156};\\\", \\\"{x:448,y:681,t:1527023307170};\\\", \\\"{x:440,y:681,t:1527023307187};\\\", \\\"{x:436,y:681,t:1527023307200};\\\", \\\"{x:432,y:681,t:1527023307217};\\\", \\\"{x:431,y:681,t:1527023307234};\\\", \\\"{x:430,y:680,t:1527023307274};\\\", \\\"{x:430,y:678,t:1527023307289};\\\", \\\"{x:431,y:676,t:1527023307300};\\\", \\\"{x:439,y:673,t:1527023307317};\\\", \\\"{x:451,y:670,t:1527023307334};\\\", \\\"{x:465,y:666,t:1527023307350};\\\", \\\"{x:484,y:661,t:1527023307371};\\\", \\\"{x:492,y:658,t:1527023307388};\\\", \\\"{x:495,y:658,t:1527023307404};\\\", \\\"{x:496,y:658,t:1527023307421};\\\", \\\"{x:498,y:659,t:1527023307787};\\\", \\\"{x:500,y:660,t:1527023307810};\\\", \\\"{x:501,y:661,t:1527023308340};\\\", \\\"{x:503,y:661,t:1527023308363};\\\", \\\"{x:505,y:662,t:1527023308373};\\\", \\\"{x:510,y:663,t:1527023308389};\\\", \\\"{x:516,y:664,t:1527023308406};\\\", \\\"{x:521,y:664,t:1527023308423};\\\", \\\"{x:523,y:665,t:1527023308440};\\\", \\\"{x:525,y:665,t:1527023308455};\\\", \\\"{x:529,y:665,t:1527023310707};\\\", \\\"{x:547,y:662,t:1527023310725};\\\", \\\"{x:601,y:648,t:1527023310742};\\\", \\\"{x:702,y:626,t:1527023310757};\\\", \\\"{x:826,y:596,t:1527023310774};\\\", \\\"{x:967,y:553,t:1527023310790};\\\", \\\"{x:1084,y:513,t:1527023310807};\\\", \\\"{x:1184,y:464,t:1527023310824};\\\", \\\"{x:1265,y:411,t:1527023310841};\\\", \\\"{x:1348,y:352,t:1527023310857};\\\", \\\"{x:1443,y:272,t:1527023310874};\\\", \\\"{x:1465,y:245,t:1527023310890};\\\", \\\"{x:1467,y:237,t:1527023310907};\\\", \\\"{x:1467,y:232,t:1527023310925};\\\", \\\"{x:1467,y:229,t:1527023310942};\\\", \\\"{x:1467,y:225,t:1527023310957};\\\", \\\"{x:1466,y:223,t:1527023310975};\\\", \\\"{x:1465,y:221,t:1527023311002};\\\", \\\"{x:1464,y:220,t:1527023311044};\\\", \\\"{x:1464,y:219,t:1527023311058};\\\", \\\"{x:1462,y:217,t:1527023311075};\\\", \\\"{x:1462,y:216,t:1527023311091};\\\", \\\"{x:1462,y:215,t:1527023311107};\\\", \\\"{x:1460,y:212,t:1527023311126};\\\", \\\"{x:1457,y:208,t:1527023311142};\\\", \\\"{x:1454,y:203,t:1527023311158};\\\", \\\"{x:1450,y:197,t:1527023311175};\\\", \\\"{x:1447,y:192,t:1527023311192};\\\", \\\"{x:1444,y:188,t:1527023311208};\\\", \\\"{x:1443,y:186,t:1527023311225};\\\", \\\"{x:1443,y:185,t:1527023311243};\\\", \\\"{x:1443,y:183,t:1527023311259};\\\", \\\"{x:1443,y:182,t:1527023311275};\\\", \\\"{x:1443,y:179,t:1527023311292};\\\", \\\"{x:1443,y:177,t:1527023311307};\\\", \\\"{x:1443,y:173,t:1527023311325};\\\", \\\"{x:1443,y:172,t:1527023311342};\\\", \\\"{x:1443,y:168,t:1527023311359};\\\", \\\"{x:1443,y:165,t:1527023311375};\\\", \\\"{x:1443,y:161,t:1527023311392};\\\", \\\"{x:1443,y:158,t:1527023311409};\\\", \\\"{x:1443,y:156,t:1527023311424};\\\", \\\"{x:1443,y:155,t:1527023311442};\\\", \\\"{x:1443,y:153,t:1527023311491};\\\", \\\"{x:1444,y:153,t:1527023311675};\\\", \\\"{x:1451,y:153,t:1527023311692};\\\", \\\"{x:1458,y:152,t:1527023311709};\\\", \\\"{x:1463,y:152,t:1527023311726};\\\", \\\"{x:1469,y:150,t:1527023311741};\\\", \\\"{x:1476,y:148,t:1527023311758};\\\", \\\"{x:1480,y:147,t:1527023311775};\\\", \\\"{x:1483,y:145,t:1527023311791};\\\", \\\"{x:1485,y:144,t:1527023311810};\\\", \\\"{x:1485,y:143,t:1527023311906};\\\", \\\"{x:1485,y:142,t:1527023311915};\\\", \\\"{x:1485,y:141,t:1527023311926};\\\", \\\"{x:1484,y:140,t:1527023311955};\\\", \\\"{x:1483,y:140,t:1527023311962};\\\", \\\"{x:1482,y:139,t:1527023311976};\\\", \\\"{x:1478,y:136,t:1527023311991};\\\", \\\"{x:1476,y:134,t:1527023312009};\\\", \\\"{x:1474,y:134,t:1527023312026};\\\", \\\"{x:1473,y:134,t:1527023312042};\\\", \\\"{x:1472,y:133,t:1527023312059};\\\", \\\"{x:1470,y:132,t:1527023312076};\\\", \\\"{x:1470,y:131,t:1527023312467};\\\", \\\"{x:1472,y:131,t:1527023312476};\\\", \\\"{x:1478,y:128,t:1527023312493};\\\", \\\"{x:1481,y:128,t:1527023312510};\\\", \\\"{x:1481,y:127,t:1527023312620};\\\", \\\"{x:1483,y:127,t:1527023312635};\\\", \\\"{x:1484,y:127,t:1527023312667};\\\", \\\"{x:1485,y:126,t:1527023312698};\\\", \\\"{x:1485,y:125,t:1527023312709};\\\", \\\"{x:1487,y:123,t:1527023312726};\\\", \\\"{x:1487,y:121,t:1527023312742};\\\", \\\"{x:1487,y:119,t:1527023312759};\\\", \\\"{x:1487,y:118,t:1527023312775};\\\", \\\"{x:1487,y:115,t:1527023312792};\\\", \\\"{x:1487,y:112,t:1527023312809};\\\", \\\"{x:1487,y:111,t:1527023312825};\\\", \\\"{x:1487,y:109,t:1527023312842};\\\", \\\"{x:1487,y:108,t:1527023312859};\\\", \\\"{x:1487,y:107,t:1527023312875};\\\", \\\"{x:1486,y:105,t:1527023312893};\\\", \\\"{x:1485,y:104,t:1527023312909};\\\", \\\"{x:1485,y:103,t:1527023312927};\\\", \\\"{x:1485,y:102,t:1527023312942};\\\", \\\"{x:1483,y:102,t:1527023316842};\\\", \\\"{x:1481,y:102,t:1527023316850};\\\", \\\"{x:1481,y:103,t:1527023316863};\\\", \\\"{x:1480,y:105,t:1527023316879};\\\", \\\"{x:1478,y:106,t:1527023316895};\\\", \\\"{x:1476,y:112,t:1527023320083};\\\", \\\"{x:1467,y:139,t:1527023320099};\\\", \\\"{x:1460,y:166,t:1527023320116};\\\", \\\"{x:1454,y:186,t:1527023320132};\\\", \\\"{x:1450,y:204,t:1527023320149};\\\", \\\"{x:1448,y:215,t:1527023320166};\\\", \\\"{x:1445,y:217,t:1527023320182};\\\", \\\"{x:1444,y:217,t:1527023320199};\\\", \\\"{x:1444,y:218,t:1527023320726};\\\", \\\"{x:1444,y:220,t:1527023320762};\\\", \\\"{x:1444,y:221,t:1527023320770};\\\", \\\"{x:1444,y:222,t:1527023320782};\\\", \\\"{x:1444,y:223,t:1527023320833};\\\", \\\"{x:1443,y:225,t:1527023320850};\\\", \\\"{x:1442,y:225,t:1527023320874};\\\", \\\"{x:1442,y:226,t:1527023320898};\\\", \\\"{x:1442,y:227,t:1527023320906};\\\", \\\"{x:1442,y:228,t:1527023320916};\\\", \\\"{x:1442,y:229,t:1527023320932};\\\", \\\"{x:1442,y:231,t:1527023320950};\\\", \\\"{x:1441,y:233,t:1527023320965};\\\", \\\"{x:1441,y:234,t:1527023320983};\\\", \\\"{x:1439,y:237,t:1527023320999};\\\", \\\"{x:1439,y:239,t:1527023321015};\\\", \\\"{x:1439,y:243,t:1527023321033};\\\", \\\"{x:1437,y:251,t:1527023321050};\\\", \\\"{x:1436,y:256,t:1527023321065};\\\", \\\"{x:1434,y:262,t:1527023321082};\\\", \\\"{x:1433,y:269,t:1527023321099};\\\", \\\"{x:1431,y:279,t:1527023321115};\\\", \\\"{x:1428,y:291,t:1527023321132};\\\", \\\"{x:1427,y:299,t:1527023321150};\\\", \\\"{x:1424,y:308,t:1527023321167};\\\", \\\"{x:1422,y:318,t:1527023321183};\\\", \\\"{x:1421,y:327,t:1527023321200};\\\", \\\"{x:1420,y:335,t:1527023321216};\\\", \\\"{x:1419,y:341,t:1527023321233};\\\", \\\"{x:1418,y:347,t:1527023321250};\\\", \\\"{x:1417,y:352,t:1527023321266};\\\", \\\"{x:1417,y:355,t:1527023321283};\\\", \\\"{x:1416,y:357,t:1527023321300};\\\", \\\"{x:1416,y:361,t:1527023321317};\\\", \\\"{x:1416,y:366,t:1527023321332};\\\", \\\"{x:1414,y:369,t:1527023321349};\\\", \\\"{x:1414,y:371,t:1527023321367};\\\", \\\"{x:1414,y:372,t:1527023321383};\\\", \\\"{x:1414,y:373,t:1527023321400};\\\", \\\"{x:1414,y:374,t:1527023321418};\\\", \\\"{x:1413,y:374,t:1527023321433};\\\", \\\"{x:1413,y:376,t:1527023324411};\\\", \\\"{x:1413,y:378,t:1527023324419};\\\", \\\"{x:1413,y:379,t:1527023324437};\\\", \\\"{x:1414,y:380,t:1527023324453};\\\", \\\"{x:1415,y:383,t:1527023324471};\\\", \\\"{x:1415,y:384,t:1527023324507};\\\", \\\"{x:1415,y:385,t:1527023324539};\\\", \\\"{x:1416,y:387,t:1527023324555};\\\", \\\"{x:1417,y:387,t:1527023324570};\\\", \\\"{x:1417,y:388,t:1527023324595};\\\", \\\"{x:1417,y:390,t:1527023324603};\\\", \\\"{x:1419,y:393,t:1527023324620};\\\", \\\"{x:1421,y:394,t:1527023324636};\\\", \\\"{x:1421,y:398,t:1527023325003};\\\", \\\"{x:1421,y:401,t:1527023325020};\\\", \\\"{x:1421,y:403,t:1527023325036};\\\", \\\"{x:1421,y:404,t:1527023325059};\\\", \\\"{x:1421,y:406,t:1527023325074};\\\", \\\"{x:1421,y:407,t:1527023325091};\\\", \\\"{x:1421,y:409,t:1527023325105};\\\", \\\"{x:1421,y:410,t:1527023325121};\\\", \\\"{x:1421,y:414,t:1527023325137};\\\", \\\"{x:1422,y:418,t:1527023325153};\\\", \\\"{x:1422,y:422,t:1527023325171};\\\", \\\"{x:1422,y:424,t:1527023325186};\\\", \\\"{x:1423,y:427,t:1527023325204};\\\", \\\"{x:1425,y:433,t:1527023325221};\\\", \\\"{x:1426,y:438,t:1527023325237};\\\", \\\"{x:1429,y:444,t:1527023325254};\\\", \\\"{x:1430,y:447,t:1527023325269};\\\", \\\"{x:1430,y:452,t:1527023325287};\\\", \\\"{x:1431,y:455,t:1527023325303};\\\", \\\"{x:1431,y:460,t:1527023325320};\\\", \\\"{x:1431,y:468,t:1527023325337};\\\", \\\"{x:1431,y:477,t:1527023325352};\\\", \\\"{x:1431,y:487,t:1527023325369};\\\", \\\"{x:1431,y:492,t:1527023325387};\\\", \\\"{x:1431,y:497,t:1527023325403};\\\", \\\"{x:1431,y:500,t:1527023325420};\\\", \\\"{x:1431,y:504,t:1527023325436};\\\", \\\"{x:1431,y:507,t:1527023325453};\\\", \\\"{x:1431,y:510,t:1527023325469};\\\", \\\"{x:1431,y:513,t:1527023325486};\\\", \\\"{x:1431,y:514,t:1527023325503};\\\", \\\"{x:1431,y:516,t:1527023325520};\\\", \\\"{x:1430,y:517,t:1527023325538};\\\", \\\"{x:1430,y:518,t:1527023325554};\\\", \\\"{x:1430,y:519,t:1527023325569};\\\", \\\"{x:1428,y:519,t:1527023325682};\\\", \\\"{x:1426,y:519,t:1527023325722};\\\", \\\"{x:1425,y:519,t:1527023325745};\\\", \\\"{x:1423,y:519,t:1527023325762};\\\", \\\"{x:1422,y:519,t:1527023325785};\\\", \\\"{x:1419,y:519,t:1527023325802};\\\", \\\"{x:1419,y:518,t:1527023325810};\\\", \\\"{x:1418,y:517,t:1527023325820};\\\", \\\"{x:1418,y:515,t:1527023325837};\\\", \\\"{x:1416,y:512,t:1527023325854};\\\", \\\"{x:1415,y:505,t:1527023325870};\\\", \\\"{x:1414,y:492,t:1527023325887};\\\", \\\"{x:1411,y:477,t:1527023325905};\\\", \\\"{x:1411,y:464,t:1527023325920};\\\", \\\"{x:1411,y:448,t:1527023325937};\\\", \\\"{x:1411,y:424,t:1527023325953};\\\", \\\"{x:1411,y:416,t:1527023325970};\\\", \\\"{x:1411,y:414,t:1527023325988};\\\", \\\"{x:1411,y:413,t:1527023326005};\\\", \\\"{x:1411,y:417,t:1527023326099};\\\", \\\"{x:1411,y:420,t:1527023326107};\\\", \\\"{x:1411,y:424,t:1527023326122};\\\", \\\"{x:1411,y:429,t:1527023326137};\\\", \\\"{x:1411,y:435,t:1527023326154};\\\", \\\"{x:1411,y:438,t:1527023326171};\\\", \\\"{x:1411,y:441,t:1527023326187};\\\", \\\"{x:1411,y:443,t:1527023326204};\\\", \\\"{x:1411,y:444,t:1527023326222};\\\", \\\"{x:1411,y:446,t:1527023326237};\\\", \\\"{x:1411,y:449,t:1527023326254};\\\", \\\"{x:1411,y:451,t:1527023326271};\\\", \\\"{x:1412,y:453,t:1527023326288};\\\", \\\"{x:1412,y:455,t:1527023326304};\\\", \\\"{x:1414,y:458,t:1527023326322};\\\", \\\"{x:1415,y:461,t:1527023326338};\\\", \\\"{x:1416,y:464,t:1527023326355};\\\", \\\"{x:1417,y:466,t:1527023326371};\\\", \\\"{x:1419,y:468,t:1527023326387};\\\", \\\"{x:1419,y:470,t:1527023326405};\\\", \\\"{x:1421,y:472,t:1527023326422};\\\", \\\"{x:1421,y:473,t:1527023326443};\\\", \\\"{x:1421,y:474,t:1527023326459};\\\", \\\"{x:1421,y:475,t:1527023326471};\\\", \\\"{x:1421,y:477,t:1527023326490};\\\", \\\"{x:1421,y:478,t:1527023326506};\\\", \\\"{x:1422,y:480,t:1527023326523};\\\", \\\"{x:1422,y:481,t:1527023326579};\\\", \\\"{x:1422,y:483,t:1527023326908};\\\", \\\"{x:1422,y:484,t:1527023326930};\\\", \\\"{x:1422,y:485,t:1527023326962};\\\", \\\"{x:1422,y:486,t:1527023326971};\\\", \\\"{x:1422,y:487,t:1527023327050};\\\", \\\"{x:1421,y:488,t:1527023327066};\\\", \\\"{x:1420,y:490,t:1527023327074};\\\", \\\"{x:1420,y:491,t:1527023327098};\\\", \\\"{x:1420,y:492,t:1527023327106};\\\", \\\"{x:1420,y:493,t:1527023327122};\\\", \\\"{x:1420,y:494,t:1527023327138};\\\", \\\"{x:1418,y:496,t:1527023327156};\\\", \\\"{x:1418,y:497,t:1527023327171};\\\", \\\"{x:1418,y:499,t:1527023327188};\\\", \\\"{x:1418,y:500,t:1527023327218};\\\", \\\"{x:1418,y:501,t:1527023327226};\\\", \\\"{x:1417,y:502,t:1527023327243};\\\", \\\"{x:1417,y:503,t:1527023327283};\\\", \\\"{x:1417,y:504,t:1527023327315};\\\", \\\"{x:1417,y:505,t:1527023327325};\\\", \\\"{x:1417,y:506,t:1527023327611};\\\", \\\"{x:1417,y:507,t:1527023327626};\\\", \\\"{x:1417,y:508,t:1527023327642};\\\", \\\"{x:1416,y:509,t:1527023327658};\\\", \\\"{x:1415,y:510,t:1527023327763};\\\", \\\"{x:1414,y:510,t:1527023329391};\\\", \\\"{x:1413,y:510,t:1527023329426};\\\", \\\"{x:1412,y:510,t:1527023329538};\\\", \\\"{x:1411,y:510,t:1527023329562};\\\", \\\"{x:1410,y:510,t:1527023329578};\\\", \\\"{x:1406,y:513,t:1527023329988};\\\", \\\"{x:1401,y:518,t:1527023329995};\\\", \\\"{x:1394,y:525,t:1527023330008};\\\", \\\"{x:1376,y:546,t:1527023330024};\\\", \\\"{x:1359,y:566,t:1527023330041};\\\", \\\"{x:1345,y:584,t:1527023330058};\\\", \\\"{x:1322,y:610,t:1527023330074};\\\", \\\"{x:1307,y:630,t:1527023330090};\\\", \\\"{x:1284,y:664,t:1527023330107};\\\", \\\"{x:1260,y:698,t:1527023330125};\\\", \\\"{x:1231,y:735,t:1527023330141};\\\", \\\"{x:1209,y:776,t:1527023330158};\\\", \\\"{x:1191,y:814,t:1527023330175};\\\", \\\"{x:1175,y:842,t:1527023330192};\\\", \\\"{x:1168,y:858,t:1527023330207};\\\", \\\"{x:1160,y:872,t:1527023330225};\\\", \\\"{x:1159,y:878,t:1527023330241};\\\", \\\"{x:1158,y:881,t:1527023330258};\\\", \\\"{x:1158,y:882,t:1527023330275};\\\", \\\"{x:1160,y:882,t:1527023330331};\\\", \\\"{x:1161,y:882,t:1527023330342};\\\", \\\"{x:1164,y:882,t:1527023330358};\\\", \\\"{x:1167,y:880,t:1527023330374};\\\", \\\"{x:1168,y:880,t:1527023330392};\\\", \\\"{x:1168,y:878,t:1527023330523};\\\", \\\"{x:1170,y:875,t:1527023330530};\\\", \\\"{x:1171,y:873,t:1527023330541};\\\", \\\"{x:1174,y:863,t:1527023330558};\\\", \\\"{x:1177,y:854,t:1527023330574};\\\", \\\"{x:1179,y:838,t:1527023330591};\\\", \\\"{x:1182,y:819,t:1527023330608};\\\", \\\"{x:1188,y:796,t:1527023330624};\\\", \\\"{x:1193,y:771,t:1527023330641};\\\", \\\"{x:1202,y:733,t:1527023330658};\\\", \\\"{x:1213,y:702,t:1527023330674};\\\", \\\"{x:1228,y:670,t:1527023330691};\\\", \\\"{x:1238,y:643,t:1527023330708};\\\", \\\"{x:1259,y:606,t:1527023330724};\\\", \\\"{x:1286,y:550,t:1527023330741};\\\", \\\"{x:1330,y:468,t:1527023330759};\\\", \\\"{x:1369,y:388,t:1527023330774};\\\", \\\"{x:1406,y:315,t:1527023330791};\\\", \\\"{x:1444,y:245,t:1527023330808};\\\", \\\"{x:1484,y:179,t:1527023330825};\\\", \\\"{x:1514,y:124,t:1527023330841};\\\", \\\"{x:1542,y:69,t:1527023330858};\\\", \\\"{x:1552,y:44,t:1527023330874};\\\", \\\"{x:1558,y:25,t:1527023330891};\\\", \\\"{x:1560,y:10,t:1527023330908};\\\", \\\"{x:1562,y:2,t:1527023330922};\\\", \\\"{x:1555,y:0,t:1527023331075};\\\", \\\"{x:1539,y:30,t:1527023331092};\\\", \\\"{x:1515,y:73,t:1527023331108};\\\", \\\"{x:1503,y:102,t:1527023331126};\\\", \\\"{x:1493,y:121,t:1527023331141};\\\", \\\"{x:1490,y:130,t:1527023331159};\\\", \\\"{x:1489,y:131,t:1527023331176};\\\", \\\"{x:1488,y:132,t:1527023331191};\\\", \\\"{x:1487,y:133,t:1527023331235};\\\", \\\"{x:1486,y:135,t:1527023331242};\\\", \\\"{x:1484,y:137,t:1527023331258};\\\", \\\"{x:1480,y:147,t:1527023331276};\\\", \\\"{x:1473,y:164,t:1527023331292};\\\", \\\"{x:1464,y:187,t:1527023331309};\\\", \\\"{x:1453,y:211,t:1527023331326};\\\", \\\"{x:1438,y:243,t:1527023331343};\\\", \\\"{x:1422,y:281,t:1527023331359};\\\", \\\"{x:1399,y:334,t:1527023331376};\\\", \\\"{x:1372,y:390,t:1527023331392};\\\", \\\"{x:1348,y:435,t:1527023331409};\\\", \\\"{x:1327,y:470,t:1527023331425};\\\", \\\"{x:1295,y:527,t:1527023331443};\\\", \\\"{x:1284,y:561,t:1527023331458};\\\", \\\"{x:1275,y:592,t:1527023331476};\\\", \\\"{x:1266,y:621,t:1527023331493};\\\", \\\"{x:1257,y:645,t:1527023331509};\\\", \\\"{x:1247,y:666,t:1527023331525};\\\", \\\"{x:1239,y:687,t:1527023331543};\\\", \\\"{x:1232,y:711,t:1527023331559};\\\", \\\"{x:1225,y:736,t:1527023331576};\\\", \\\"{x:1212,y:766,t:1527023331593};\\\", \\\"{x:1204,y:791,t:1527023331609};\\\", \\\"{x:1192,y:811,t:1527023331626};\\\", \\\"{x:1178,y:837,t:1527023331642};\\\", \\\"{x:1171,y:852,t:1527023331659};\\\", \\\"{x:1160,y:868,t:1527023331675};\\\", \\\"{x:1153,y:882,t:1527023331693};\\\", \\\"{x:1143,y:897,t:1527023331709};\\\", \\\"{x:1129,y:912,t:1527023331726};\\\", \\\"{x:1120,y:924,t:1527023331743};\\\", \\\"{x:1113,y:934,t:1527023331759};\\\", \\\"{x:1103,y:941,t:1527023331775};\\\", \\\"{x:1098,y:946,t:1527023331793};\\\", \\\"{x:1093,y:951,t:1527023331810};\\\", \\\"{x:1088,y:955,t:1527023331826};\\\", \\\"{x:1086,y:957,t:1527023331843};\\\", \\\"{x:1085,y:958,t:1527023331860};\\\", \\\"{x:1085,y:957,t:1527023331947};\\\", \\\"{x:1085,y:954,t:1527023331960};\\\", \\\"{x:1085,y:951,t:1527023331976};\\\", \\\"{x:1088,y:948,t:1527023331993};\\\", \\\"{x:1090,y:945,t:1527023332010};\\\", \\\"{x:1093,y:942,t:1527023332026};\\\", \\\"{x:1095,y:933,t:1527023332042};\\\", \\\"{x:1098,y:923,t:1527023332060};\\\", \\\"{x:1102,y:908,t:1527023332077};\\\", \\\"{x:1108,y:896,t:1527023332093};\\\", \\\"{x:1114,y:886,t:1527023332110};\\\", \\\"{x:1122,y:871,t:1527023332126};\\\", \\\"{x:1131,y:848,t:1527023332143};\\\", \\\"{x:1141,y:824,t:1527023332160};\\\", \\\"{x:1152,y:798,t:1527023332176};\\\", \\\"{x:1168,y:770,t:1527023332192};\\\", \\\"{x:1182,y:742,t:1527023332210};\\\", \\\"{x:1200,y:705,t:1527023332227};\\\", \\\"{x:1214,y:683,t:1527023332242};\\\", \\\"{x:1224,y:665,t:1527023332260};\\\", \\\"{x:1231,y:653,t:1527023332277};\\\", \\\"{x:1237,y:642,t:1527023332292};\\\", \\\"{x:1245,y:631,t:1527023332310};\\\", \\\"{x:1252,y:616,t:1527023332326};\\\", \\\"{x:1259,y:602,t:1527023332343};\\\", \\\"{x:1265,y:589,t:1527023332360};\\\", \\\"{x:1274,y:572,t:1527023332376};\\\", \\\"{x:1279,y:563,t:1527023332392};\\\", \\\"{x:1287,y:548,t:1527023332409};\\\", \\\"{x:1294,y:529,t:1527023332426};\\\", \\\"{x:1305,y:508,t:1527023332442};\\\", \\\"{x:1317,y:478,t:1527023332459};\\\", \\\"{x:1331,y:452,t:1527023332476};\\\", \\\"{x:1341,y:435,t:1527023332492};\\\", \\\"{x:1352,y:412,t:1527023332509};\\\", \\\"{x:1365,y:388,t:1527023332527};\\\", \\\"{x:1379,y:360,t:1527023332543};\\\", \\\"{x:1390,y:340,t:1527023332560};\\\", \\\"{x:1397,y:325,t:1527023332577};\\\", \\\"{x:1408,y:300,t:1527023332593};\\\", \\\"{x:1420,y:271,t:1527023332610};\\\", \\\"{x:1433,y:238,t:1527023332626};\\\", \\\"{x:1444,y:212,t:1527023332644};\\\", \\\"{x:1455,y:188,t:1527023332659};\\\", \\\"{x:1461,y:170,t:1527023332677};\\\", \\\"{x:1466,y:159,t:1527023332694};\\\", \\\"{x:1472,y:144,t:1527023332709};\\\", \\\"{x:1477,y:135,t:1527023332727};\\\", \\\"{x:1480,y:128,t:1527023332743};\\\", \\\"{x:1484,y:121,t:1527023332760};\\\", \\\"{x:1485,y:118,t:1527023332779};\\\", \\\"{x:1485,y:116,t:1527023332795};\\\", \\\"{x:1487,y:113,t:1527023332810};\\\", \\\"{x:1488,y:111,t:1527023332827};\\\", \\\"{x:1488,y:117,t:1527023333195};\\\", \\\"{x:1488,y:124,t:1527023333210};\\\", \\\"{x:1475,y:159,t:1527023333227};\\\", \\\"{x:1467,y:187,t:1527023333243};\\\", \\\"{x:1453,y:225,t:1527023333261};\\\", \\\"{x:1438,y:258,t:1527023333276};\\\", \\\"{x:1425,y:293,t:1527023333294};\\\", \\\"{x:1410,y:324,t:1527023333311};\\\", \\\"{x:1400,y:350,t:1527023333327};\\\", \\\"{x:1385,y:377,t:1527023333344};\\\", \\\"{x:1375,y:402,t:1527023333361};\\\", \\\"{x:1364,y:431,t:1527023333377};\\\", \\\"{x:1348,y:465,t:1527023333395};\\\", \\\"{x:1332,y:506,t:1527023333410};\\\", \\\"{x:1317,y:531,t:1527023333427};\\\", \\\"{x:1295,y:563,t:1527023333444};\\\", \\\"{x:1281,y:590,t:1527023333461};\\\", \\\"{x:1268,y:614,t:1527023333478};\\\", \\\"{x:1255,y:638,t:1527023333494};\\\", \\\"{x:1241,y:660,t:1527023333510};\\\", \\\"{x:1223,y:690,t:1527023333528};\\\", \\\"{x:1204,y:723,t:1527023333543};\\\", \\\"{x:1185,y:755,t:1527023333561};\\\", \\\"{x:1160,y:792,t:1527023333578};\\\", \\\"{x:1138,y:826,t:1527023333594};\\\", \\\"{x:1105,y:872,t:1527023333610};\\\", \\\"{x:1089,y:894,t:1527023333628};\\\", \\\"{x:1077,y:912,t:1527023333644};\\\", \\\"{x:1067,y:928,t:1527023333661};\\\", \\\"{x:1061,y:943,t:1527023333678};\\\", \\\"{x:1057,y:952,t:1527023333694};\\\", \\\"{x:1055,y:958,t:1527023333711};\\\", \\\"{x:1054,y:962,t:1527023333728};\\\", \\\"{x:1052,y:967,t:1527023333743};\\\", \\\"{x:1051,y:970,t:1527023333761};\\\", \\\"{x:1050,y:971,t:1527023333778};\\\", \\\"{x:1050,y:970,t:1527023333923};\\\", \\\"{x:1051,y:970,t:1527023333931};\\\", \\\"{x:1053,y:967,t:1527023333945};\\\", \\\"{x:1054,y:964,t:1527023333960};\\\", \\\"{x:1058,y:957,t:1527023333977};\\\", \\\"{x:1066,y:942,t:1527023333995};\\\", \\\"{x:1078,y:920,t:1527023334011};\\\", \\\"{x:1098,y:886,t:1527023334028};\\\", \\\"{x:1120,y:838,t:1527023334045};\\\", \\\"{x:1148,y:789,t:1527023334060};\\\", \\\"{x:1184,y:724,t:1527023334077};\\\", \\\"{x:1241,y:631,t:1527023334095};\\\", \\\"{x:1301,y:514,t:1527023334111};\\\", \\\"{x:1361,y:387,t:1527023334128};\\\", \\\"{x:1407,y:279,t:1527023334144};\\\", \\\"{x:1446,y:194,t:1527023334161};\\\", \\\"{x:1477,y:137,t:1527023334178};\\\", \\\"{x:1512,y:75,t:1527023334195};\\\", \\\"{x:1529,y:43,t:1527023334211};\\\", \\\"{x:1539,y:23,t:1527023334228};\\\", \\\"{x:1544,y:7,t:1527023334245};\\\", \\\"{x:1548,y:1,t:1527023334262};\\\", \\\"{x:1548,y:0,t:1527023334274};\\\", \\\"{x:1548,y:0,t:1527023334393};\\\", \\\"{x:1546,y:13,t:1527023334411};\\\", \\\"{x:1545,y:21,t:1527023334427};\\\", \\\"{x:1543,y:26,t:1527023334445};\\\", \\\"{x:1542,y:29,t:1527023334462};\\\", \\\"{x:1542,y:33,t:1527023334478};\\\", \\\"{x:1540,y:38,t:1527023334495};\\\", \\\"{x:1539,y:40,t:1527023334511};\\\", \\\"{x:1539,y:41,t:1527023334532};\\\", \\\"{x:1539,y:42,t:1527023334550};\\\", \\\"{x:1537,y:45,t:1527023334567};\\\", \\\"{x:1535,y:47,t:1527023334583};\\\", \\\"{x:1533,y:49,t:1527023334599};\\\", \\\"{x:1532,y:50,t:1527023334616};\\\", \\\"{x:1530,y:51,t:1527023334632};\\\", \\\"{x:1527,y:53,t:1527023334649};\\\", \\\"{x:1524,y:54,t:1527023334666};\\\", \\\"{x:1519,y:56,t:1527023334683};\\\", \\\"{x:1518,y:56,t:1527023334699};\\\", \\\"{x:1518,y:57,t:1527023334758};\\\", \\\"{x:1516,y:58,t:1527023334766};\\\", \\\"{x:1516,y:60,t:1527023334783};\\\", \\\"{x:1516,y:67,t:1527023334798};\\\", \\\"{x:1516,y:76,t:1527023334816};\\\", \\\"{x:1516,y:92,t:1527023334833};\\\", \\\"{x:1516,y:108,t:1527023334849};\\\", \\\"{x:1519,y:129,t:1527023334866};\\\", \\\"{x:1525,y:151,t:1527023334883};\\\", \\\"{x:1534,y:178,t:1527023334899};\\\", \\\"{x:1545,y:205,t:1527023334916};\\\", \\\"{x:1560,y:244,t:1527023334933};\\\", \\\"{x:1579,y:277,t:1527023334949};\\\", \\\"{x:1615,y:337,t:1527023334967};\\\", \\\"{x:1633,y:365,t:1527023334982};\\\", \\\"{x:1649,y:391,t:1527023334999};\\\", \\\"{x:1668,y:417,t:1527023335016};\\\", \\\"{x:1685,y:441,t:1527023335032};\\\", \\\"{x:1709,y:471,t:1527023335049};\\\", \\\"{x:1744,y:512,t:1527023335066};\\\", \\\"{x:1777,y:548,t:1527023335083};\\\", \\\"{x:1798,y:573,t:1527023335100};\\\", \\\"{x:1819,y:589,t:1527023335116};\\\", \\\"{x:1840,y:609,t:1527023335133};\\\", \\\"{x:1861,y:632,t:1527023335150};\\\", \\\"{x:1876,y:653,t:1527023335166};\\\", \\\"{x:1893,y:679,t:1527023335182};\\\", \\\"{x:1905,y:701,t:1527023335200};\\\", \\\"{x:1910,y:724,t:1527023335216};\\\", \\\"{x:1916,y:749,t:1527023335232};\\\", \\\"{x:1918,y:766,t:1527023335248};\\\", \\\"{x:1918,y:780,t:1527023335265};\\\", \\\"{x:1918,y:795,t:1527023335282};\\\", \\\"{x:1918,y:810,t:1527023335299};\\\", \\\"{x:1918,y:821,t:1527023335315};\\\", \\\"{x:1918,y:828,t:1527023335332};\\\", \\\"{x:1918,y:833,t:1527023335348};\\\", \\\"{x:1918,y:841,t:1527023335365};\\\", \\\"{x:1919,y:844,t:1527023335381};\\\", \\\"{x:1919,y:851,t:1527023335397};\\\", \\\"{x:1919,y:856,t:1527023335415};\\\", \\\"{x:1919,y:859,t:1527023335431};\\\", \\\"{x:1919,y:865,t:1527023335448};\\\", \\\"{x:1919,y:867,t:1527023335466};\\\", \\\"{x:1919,y:869,t:1527023335481};\\\", \\\"{x:1918,y:871,t:1527023335498};\\\", \\\"{x:1918,y:872,t:1527023335518};\\\", \\\"{x:1917,y:872,t:1527023335531};\\\", \\\"{x:1915,y:873,t:1527023335548};\\\", \\\"{x:1908,y:873,t:1527023335565};\\\", \\\"{x:1891,y:870,t:1527023335582};\\\", \\\"{x:1853,y:858,t:1527023335599};\\\", \\\"{x:1834,y:846,t:1527023335616};\\\", \\\"{x:1834,y:845,t:1527023335632};\\\", \\\"{x:1834,y:844,t:1527023336007};\\\", \\\"{x:1834,y:841,t:1527023336023};\\\", \\\"{x:1836,y:840,t:1527023336033};\\\", \\\"{x:1837,y:834,t:1527023336049};\\\", \\\"{x:1840,y:829,t:1527023336066};\\\", \\\"{x:1840,y:828,t:1527023336083};\\\", \\\"{x:1840,y:827,t:1527023336135};\\\", \\\"{x:1837,y:826,t:1527023336151};\\\", \\\"{x:1825,y:825,t:1527023336166};\\\", \\\"{x:1800,y:821,t:1527023336183};\\\", \\\"{x:1777,y:819,t:1527023336200};\\\", \\\"{x:1747,y:814,t:1527023336216};\\\", \\\"{x:1717,y:813,t:1527023336233};\\\", \\\"{x:1686,y:813,t:1527023336250};\\\", \\\"{x:1652,y:813,t:1527023336266};\\\", \\\"{x:1625,y:813,t:1527023336283};\\\", \\\"{x:1597,y:816,t:1527023336300};\\\", \\\"{x:1572,y:819,t:1527023336316};\\\", \\\"{x:1560,y:821,t:1527023336333};\\\", \\\"{x:1558,y:821,t:1527023336350};\\\", \\\"{x:1556,y:821,t:1527023336502};\\\", \\\"{x:1555,y:821,t:1527023336516};\\\", \\\"{x:1550,y:821,t:1527023336533};\\\", \\\"{x:1547,y:822,t:1527023336549};\\\", \\\"{x:1540,y:825,t:1527023336567};\\\", \\\"{x:1537,y:828,t:1527023336583};\\\", \\\"{x:1534,y:828,t:1527023336600};\\\", \\\"{x:1530,y:830,t:1527023336617};\\\", \\\"{x:1526,y:833,t:1527023336633};\\\", \\\"{x:1521,y:838,t:1527023336650};\\\", \\\"{x:1517,y:841,t:1527023336667};\\\", \\\"{x:1514,y:843,t:1527023336683};\\\", \\\"{x:1514,y:844,t:1527023336797};\\\", \\\"{x:1514,y:845,t:1527023336806};\\\", \\\"{x:1514,y:847,t:1527023336816};\\\", \\\"{x:1514,y:848,t:1527023336832};\\\", \\\"{x:1514,y:850,t:1527023336850};\\\", \\\"{x:1514,y:851,t:1527023336877};\\\", \\\"{x:1514,y:852,t:1527023336894};\\\", \\\"{x:1514,y:853,t:1527023336902};\\\", \\\"{x:1514,y:854,t:1527023336934};\\\", \\\"{x:1515,y:855,t:1527023336966};\\\", \\\"{x:1519,y:856,t:1527023336984};\\\", \\\"{x:1528,y:856,t:1527023337000};\\\", \\\"{x:1535,y:856,t:1527023337017};\\\", \\\"{x:1550,y:855,t:1527023337034};\\\", \\\"{x:1570,y:852,t:1527023337050};\\\", \\\"{x:1589,y:850,t:1527023337067};\\\", \\\"{x:1613,y:845,t:1527023337083};\\\", \\\"{x:1633,y:844,t:1527023337099};\\\", \\\"{x:1647,y:844,t:1527023337117};\\\", \\\"{x:1656,y:844,t:1527023337133};\\\", \\\"{x:1663,y:844,t:1527023337149};\\\", \\\"{x:1665,y:844,t:1527023337167};\\\", \\\"{x:1667,y:844,t:1527023337184};\\\", \\\"{x:1667,y:845,t:1527023337279};\\\", \\\"{x:1668,y:847,t:1527023337295};\\\", \\\"{x:1668,y:848,t:1527023337302};\\\", \\\"{x:1669,y:850,t:1527023337316};\\\", \\\"{x:1670,y:851,t:1527023337334};\\\", \\\"{x:1671,y:852,t:1527023337350};\\\", \\\"{x:1673,y:855,t:1527023337367};\\\", \\\"{x:1673,y:856,t:1527023337384};\\\", \\\"{x:1674,y:857,t:1527023337401};\\\", \\\"{x:1677,y:859,t:1527023337417};\\\", \\\"{x:1677,y:860,t:1527023337434};\\\", \\\"{x:1678,y:861,t:1527023337451};\\\", \\\"{x:1679,y:862,t:1527023337575};\\\", \\\"{x:1674,y:864,t:1527023337591};\\\", \\\"{x:1671,y:865,t:1527023337601};\\\", \\\"{x:1655,y:865,t:1527023337617};\\\", \\\"{x:1629,y:865,t:1527023337634};\\\", \\\"{x:1598,y:864,t:1527023337652};\\\", \\\"{x:1559,y:862,t:1527023337667};\\\", \\\"{x:1527,y:857,t:1527023337684};\\\", \\\"{x:1485,y:850,t:1527023337701};\\\", \\\"{x:1440,y:845,t:1527023337717};\\\", \\\"{x:1403,y:838,t:1527023337735};\\\", \\\"{x:1372,y:831,t:1527023337751};\\\", \\\"{x:1362,y:830,t:1527023337768};\\\", \\\"{x:1359,y:830,t:1527023337784};\\\", \\\"{x:1359,y:829,t:1527023337846};\\\", \\\"{x:1357,y:828,t:1527023337894};\\\", \\\"{x:1353,y:829,t:1527023337973};\\\", \\\"{x:1347,y:833,t:1527023337983};\\\", \\\"{x:1339,y:839,t:1527023338000};\\\", \\\"{x:1332,y:843,t:1527023338018};\\\", \\\"{x:1327,y:844,t:1527023338034};\\\", \\\"{x:1323,y:845,t:1527023338050};\\\", \\\"{x:1316,y:847,t:1527023338068};\\\", \\\"{x:1310,y:849,t:1527023338083};\\\", \\\"{x:1307,y:850,t:1527023338100};\\\", \\\"{x:1299,y:853,t:1527023338118};\\\", \\\"{x:1297,y:854,t:1527023338134};\\\", \\\"{x:1294,y:854,t:1527023338151};\\\", \\\"{x:1286,y:854,t:1527023338167};\\\", \\\"{x:1284,y:854,t:1527023338184};\\\", \\\"{x:1283,y:854,t:1527023338759};\\\", \\\"{x:1282,y:854,t:1527023338807};\\\", \\\"{x:1281,y:855,t:1527023338818};\\\", \\\"{x:1281,y:856,t:1527023338855};\\\", \\\"{x:1279,y:856,t:1527023338911};\\\", \\\"{x:1278,y:856,t:1527023338919};\\\", \\\"{x:1273,y:856,t:1527023338935};\\\", \\\"{x:1269,y:856,t:1527023338952};\\\", \\\"{x:1268,y:856,t:1527023338969};\\\", \\\"{x:1267,y:856,t:1527023339214};\\\", \\\"{x:1266,y:856,t:1527023339221};\\\", \\\"{x:1262,y:857,t:1527023339234};\\\", \\\"{x:1259,y:857,t:1527023339251};\\\", \\\"{x:1255,y:858,t:1527023339268};\\\", \\\"{x:1250,y:858,t:1527023339284};\\\", \\\"{x:1244,y:857,t:1527023339301};\\\", \\\"{x:1243,y:857,t:1527023339333};\\\", \\\"{x:1243,y:856,t:1527023339406};\\\", \\\"{x:1243,y:855,t:1527023339494};\\\", \\\"{x:1244,y:856,t:1527023339503};\\\", \\\"{x:1249,y:860,t:1527023339518};\\\", \\\"{x:1252,y:862,t:1527023339536};\\\", \\\"{x:1256,y:865,t:1527023339552};\\\", \\\"{x:1259,y:868,t:1527023339568};\\\", \\\"{x:1264,y:872,t:1527023339586};\\\", \\\"{x:1265,y:874,t:1527023339602};\\\", \\\"{x:1267,y:874,t:1527023339619};\\\", \\\"{x:1268,y:876,t:1527023339636};\\\", \\\"{x:1269,y:876,t:1527023339655};\\\", \\\"{x:1269,y:877,t:1527023339669};\\\", \\\"{x:1270,y:878,t:1527023339686};\\\", \\\"{x:1271,y:880,t:1527023339702};\\\", \\\"{x:1272,y:882,t:1527023339719};\\\", \\\"{x:1273,y:885,t:1527023339736};\\\", \\\"{x:1274,y:889,t:1527023339752};\\\", \\\"{x:1275,y:891,t:1527023339770};\\\", \\\"{x:1275,y:893,t:1527023339786};\\\", \\\"{x:1276,y:895,t:1527023339802};\\\", \\\"{x:1277,y:898,t:1527023339820};\\\", \\\"{x:1279,y:899,t:1527023339836};\\\", \\\"{x:1279,y:901,t:1527023339852};\\\", \\\"{x:1280,y:902,t:1527023339870};\\\", \\\"{x:1280,y:903,t:1527023339886};\\\", \\\"{x:1281,y:903,t:1527023340095};\\\", \\\"{x:1281,y:902,t:1527023340103};\\\", \\\"{x:1279,y:899,t:1527023340119};\\\", \\\"{x:1277,y:895,t:1527023340136};\\\", \\\"{x:1274,y:889,t:1527023340154};\\\", \\\"{x:1273,y:886,t:1527023340169};\\\", \\\"{x:1271,y:880,t:1527023340186};\\\", \\\"{x:1269,y:875,t:1527023340204};\\\", \\\"{x:1269,y:870,t:1527023340219};\\\", \\\"{x:1269,y:864,t:1527023340237};\\\", \\\"{x:1267,y:856,t:1527023340253};\\\", \\\"{x:1266,y:850,t:1527023340269};\\\", \\\"{x:1265,y:847,t:1527023340287};\\\", \\\"{x:1265,y:846,t:1527023340304};\\\", \\\"{x:1265,y:844,t:1527023340319};\\\", \\\"{x:1265,y:843,t:1527023340343};\\\", \\\"{x:1265,y:842,t:1527023340353};\\\", \\\"{x:1265,y:841,t:1527023340369};\\\", \\\"{x:1265,y:840,t:1527023340391};\\\", \\\"{x:1266,y:841,t:1527023340559};\\\", \\\"{x:1266,y:843,t:1527023340571};\\\", \\\"{x:1270,y:849,t:1527023340586};\\\", \\\"{x:1271,y:853,t:1527023340604};\\\", \\\"{x:1272,y:857,t:1527023340621};\\\", \\\"{x:1272,y:858,t:1527023340636};\\\", \\\"{x:1272,y:859,t:1527023341007};\\\", \\\"{x:1270,y:860,t:1527023341020};\\\", \\\"{x:1259,y:862,t:1527023341037};\\\", \\\"{x:1247,y:867,t:1527023341053};\\\", \\\"{x:1214,y:875,t:1527023341071};\\\", \\\"{x:1192,y:878,t:1527023341087};\\\", \\\"{x:1171,y:882,t:1527023341103};\\\", \\\"{x:1147,y:883,t:1527023341120};\\\", \\\"{x:1138,y:886,t:1527023341137};\\\", \\\"{x:1128,y:888,t:1527023341154};\\\", \\\"{x:1114,y:891,t:1527023341170};\\\", \\\"{x:1106,y:895,t:1527023341187};\\\", \\\"{x:1104,y:896,t:1527023341203};\\\", \\\"{x:1102,y:897,t:1527023341220};\\\", \\\"{x:1102,y:898,t:1527023341263};\\\", \\\"{x:1101,y:899,t:1527023341471};\\\", \\\"{x:1100,y:900,t:1527023341487};\\\", \\\"{x:1100,y:901,t:1527023341504};\\\", \\\"{x:1098,y:902,t:1527023341520};\\\", \\\"{x:1097,y:902,t:1527023341655};\\\", \\\"{x:1097,y:903,t:1527023341711};\\\", \\\"{x:1096,y:903,t:1527023341720};\\\", \\\"{x:1095,y:904,t:1527023341742};\\\", \\\"{x:1094,y:904,t:1527023341774};\\\", \\\"{x:1095,y:904,t:1527023342311};\\\", \\\"{x:1096,y:904,t:1527023342321};\\\", \\\"{x:1098,y:904,t:1527023342338};\\\", \\\"{x:1102,y:904,t:1527023342354};\\\", \\\"{x:1108,y:904,t:1527023342371};\\\", \\\"{x:1115,y:904,t:1527023342387};\\\", \\\"{x:1123,y:904,t:1527023342404};\\\", \\\"{x:1133,y:904,t:1527023342421};\\\", \\\"{x:1152,y:904,t:1527023342438};\\\", \\\"{x:1166,y:904,t:1527023342454};\\\", \\\"{x:1173,y:904,t:1527023342471};\\\", \\\"{x:1176,y:904,t:1527023342488};\\\", \\\"{x:1174,y:905,t:1527023342623};\\\", \\\"{x:1165,y:910,t:1527023342639};\\\", \\\"{x:1160,y:912,t:1527023342655};\\\", \\\"{x:1154,y:914,t:1527023342671};\\\", \\\"{x:1148,y:915,t:1527023342689};\\\", \\\"{x:1146,y:915,t:1527023342705};\\\", \\\"{x:1146,y:914,t:1527023342838};\\\", \\\"{x:1146,y:913,t:1527023342855};\\\", \\\"{x:1150,y:910,t:1527023342872};\\\", \\\"{x:1152,y:908,t:1527023342888};\\\", \\\"{x:1155,y:905,t:1527023342905};\\\", \\\"{x:1161,y:900,t:1527023342922};\\\", \\\"{x:1167,y:894,t:1527023342938};\\\", \\\"{x:1172,y:888,t:1527023342955};\\\", \\\"{x:1178,y:880,t:1527023342972};\\\", \\\"{x:1183,y:872,t:1527023342988};\\\", \\\"{x:1188,y:863,t:1527023343006};\\\", \\\"{x:1192,y:854,t:1527023343021};\\\", \\\"{x:1198,y:844,t:1527023343038};\\\", \\\"{x:1201,y:840,t:1527023343055};\\\", \\\"{x:1203,y:835,t:1527023343072};\\\", \\\"{x:1205,y:830,t:1527023343088};\\\", \\\"{x:1208,y:822,t:1527023343105};\\\", \\\"{x:1209,y:817,t:1527023343122};\\\", \\\"{x:1211,y:811,t:1527023343138};\\\", \\\"{x:1212,y:807,t:1527023343155};\\\", \\\"{x:1213,y:805,t:1527023343172};\\\", \\\"{x:1213,y:803,t:1527023343351};\\\", \\\"{x:1213,y:802,t:1527023343358};\\\", \\\"{x:1213,y:800,t:1527023343372};\\\", \\\"{x:1213,y:797,t:1527023343388};\\\", \\\"{x:1213,y:796,t:1527023343406};\\\", \\\"{x:1213,y:793,t:1527023343423};\\\", \\\"{x:1213,y:792,t:1527023343454};\\\", \\\"{x:1213,y:791,t:1527023343719};\\\", \\\"{x:1213,y:790,t:1527023343727};\\\", \\\"{x:1213,y:789,t:1527023343740};\\\", \\\"{x:1213,y:788,t:1527023343755};\\\", \\\"{x:1214,y:786,t:1527023343773};\\\", \\\"{x:1215,y:786,t:1527023343789};\\\", \\\"{x:1215,y:785,t:1527023343806};\\\", \\\"{x:1215,y:783,t:1527023345127};\\\", \\\"{x:1215,y:780,t:1527023345141};\\\", \\\"{x:1215,y:778,t:1527023345156};\\\", \\\"{x:1215,y:777,t:1527023345173};\\\", \\\"{x:1215,y:776,t:1527023345198};\\\", \\\"{x:1215,y:775,t:1527023345206};\\\", \\\"{x:1215,y:774,t:1527023345238};\\\", \\\"{x:1215,y:775,t:1527023345534};\\\", \\\"{x:1211,y:780,t:1527023345542};\\\", \\\"{x:1209,y:783,t:1527023345558};\\\", \\\"{x:1204,y:793,t:1527023345573};\\\", \\\"{x:1195,y:811,t:1527023345590};\\\", \\\"{x:1190,y:822,t:1527023345608};\\\", \\\"{x:1186,y:830,t:1527023345624};\\\", \\\"{x:1184,y:839,t:1527023345640};\\\", \\\"{x:1180,y:849,t:1527023345658};\\\", \\\"{x:1175,y:860,t:1527023345673};\\\", \\\"{x:1171,y:872,t:1527023345691};\\\", \\\"{x:1167,y:880,t:1527023345708};\\\", \\\"{x:1164,y:886,t:1527023345724};\\\", \\\"{x:1162,y:890,t:1527023345741};\\\", \\\"{x:1160,y:894,t:1527023345757};\\\", \\\"{x:1159,y:900,t:1527023345774};\\\", \\\"{x:1158,y:902,t:1527023345790};\\\", \\\"{x:1157,y:903,t:1527023345807};\\\", \\\"{x:1157,y:904,t:1527023345846};\\\", \\\"{x:1157,y:903,t:1527023345997};\\\", \\\"{x:1159,y:900,t:1527023346006};\\\", \\\"{x:1166,y:889,t:1527023346024};\\\", \\\"{x:1178,y:875,t:1527023346040};\\\", \\\"{x:1192,y:856,t:1527023346057};\\\", \\\"{x:1206,y:840,t:1527023346074};\\\", \\\"{x:1218,y:827,t:1527023346089};\\\", \\\"{x:1229,y:817,t:1527023346107};\\\", \\\"{x:1237,y:811,t:1527023346124};\\\", \\\"{x:1239,y:809,t:1527023346140};\\\", \\\"{x:1241,y:809,t:1527023346157};\\\", \\\"{x:1241,y:811,t:1527023346215};\\\", \\\"{x:1242,y:817,t:1527023346225};\\\", \\\"{x:1242,y:835,t:1527023346242};\\\", \\\"{x:1245,y:856,t:1527023346258};\\\", \\\"{x:1247,y:871,t:1527023346274};\\\", \\\"{x:1248,y:881,t:1527023346291};\\\", \\\"{x:1248,y:888,t:1527023346308};\\\", \\\"{x:1248,y:895,t:1527023346324};\\\", \\\"{x:1248,y:901,t:1527023346342};\\\", \\\"{x:1248,y:905,t:1527023346357};\\\", \\\"{x:1248,y:908,t:1527023346374};\\\", \\\"{x:1248,y:909,t:1527023346391};\\\", \\\"{x:1248,y:911,t:1527023346408};\\\", \\\"{x:1248,y:912,t:1527023346446};\\\", \\\"{x:1248,y:913,t:1527023346458};\\\", \\\"{x:1248,y:914,t:1527023346474};\\\", \\\"{x:1248,y:916,t:1527023346491};\\\", \\\"{x:1247,y:918,t:1527023346508};\\\", \\\"{x:1247,y:919,t:1527023346525};\\\", \\\"{x:1245,y:921,t:1527023346541};\\\", \\\"{x:1242,y:924,t:1527023346558};\\\", \\\"{x:1237,y:924,t:1527023346574};\\\", \\\"{x:1233,y:925,t:1527023346592};\\\", \\\"{x:1231,y:926,t:1527023346609};\\\", \\\"{x:1232,y:926,t:1527023346735};\\\", \\\"{x:1233,y:926,t:1527023346743};\\\", \\\"{x:1239,y:924,t:1527023346760};\\\", \\\"{x:1245,y:923,t:1527023346775};\\\", \\\"{x:1254,y:920,t:1527023346791};\\\", \\\"{x:1263,y:918,t:1527023346809};\\\", \\\"{x:1271,y:917,t:1527023346825};\\\", \\\"{x:1274,y:916,t:1527023346841};\\\", \\\"{x:1279,y:915,t:1527023346859};\\\", \\\"{x:1280,y:913,t:1527023347046};\\\", \\\"{x:1283,y:909,t:1527023347058};\\\", \\\"{x:1289,y:897,t:1527023347074};\\\", \\\"{x:1295,y:883,t:1527023347091};\\\", \\\"{x:1303,y:867,t:1527023347108};\\\", \\\"{x:1308,y:855,t:1527023347125};\\\", \\\"{x:1314,y:839,t:1527023347141};\\\", \\\"{x:1325,y:812,t:1527023347157};\\\", \\\"{x:1330,y:791,t:1527023347175};\\\", \\\"{x:1336,y:774,t:1527023347191};\\\", \\\"{x:1340,y:757,t:1527023347208};\\\", \\\"{x:1347,y:736,t:1527023347226};\\\", \\\"{x:1353,y:720,t:1527023347242};\\\", \\\"{x:1359,y:708,t:1527023347258};\\\", \\\"{x:1362,y:701,t:1527023347275};\\\", \\\"{x:1363,y:696,t:1527023347291};\\\", \\\"{x:1365,y:693,t:1527023347308};\\\", \\\"{x:1366,y:692,t:1527023347325};\\\", \\\"{x:1368,y:692,t:1527023347374};\\\", \\\"{x:1368,y:691,t:1527023347422};\\\", \\\"{x:1370,y:691,t:1527023347486};\\\", \\\"{x:1373,y:692,t:1527023347494};\\\", \\\"{x:1374,y:694,t:1527023347509};\\\", \\\"{x:1377,y:699,t:1527023347526};\\\", \\\"{x:1379,y:700,t:1527023347543};\\\", \\\"{x:1379,y:701,t:1527023347878};\\\", \\\"{x:1380,y:702,t:1527023347892};\\\", \\\"{x:1380,y:704,t:1527023347909};\\\", \\\"{x:1380,y:705,t:1527023347926};\\\", \\\"{x:1382,y:710,t:1527023351679};\\\", \\\"{x:1383,y:712,t:1527023351696};\\\", \\\"{x:1384,y:715,t:1527023351711};\\\", \\\"{x:1386,y:718,t:1527023351730};\\\", \\\"{x:1388,y:720,t:1527023351746};\\\", \\\"{x:1390,y:723,t:1527023351762};\\\", \\\"{x:1391,y:727,t:1527023351779};\\\", \\\"{x:1394,y:731,t:1527023351795};\\\", \\\"{x:1395,y:734,t:1527023351812};\\\", \\\"{x:1397,y:740,t:1527023351829};\\\", \\\"{x:1398,y:743,t:1527023351846};\\\", \\\"{x:1401,y:749,t:1527023351862};\\\", \\\"{x:1403,y:753,t:1527023351878};\\\", \\\"{x:1405,y:757,t:1527023351896};\\\", \\\"{x:1406,y:763,t:1527023351913};\\\", \\\"{x:1410,y:768,t:1527023351929};\\\", \\\"{x:1412,y:773,t:1527023351946};\\\", \\\"{x:1416,y:780,t:1527023351963};\\\", \\\"{x:1418,y:784,t:1527023351978};\\\", \\\"{x:1425,y:793,t:1527023351996};\\\", \\\"{x:1429,y:800,t:1527023352013};\\\", \\\"{x:1435,y:808,t:1527023352029};\\\", \\\"{x:1439,y:816,t:1527023352046};\\\", \\\"{x:1445,y:824,t:1527023352062};\\\", \\\"{x:1455,y:839,t:1527023352078};\\\", \\\"{x:1458,y:844,t:1527023352096};\\\", \\\"{x:1461,y:851,t:1527023352112};\\\", \\\"{x:1462,y:854,t:1527023352129};\\\", \\\"{x:1463,y:857,t:1527023352146};\\\", \\\"{x:1465,y:861,t:1527023352163};\\\", \\\"{x:1467,y:864,t:1527023352179};\\\", \\\"{x:1468,y:866,t:1527023352195};\\\", \\\"{x:1469,y:867,t:1527023352213};\\\", \\\"{x:1470,y:869,t:1527023352228};\\\", \\\"{x:1471,y:870,t:1527023352246};\\\", \\\"{x:1473,y:872,t:1527023352262};\\\", \\\"{x:1473,y:873,t:1527023352286};\\\", \\\"{x:1475,y:875,t:1527023352302};\\\", \\\"{x:1476,y:876,t:1527023352343};\\\", \\\"{x:1476,y:877,t:1527023352359};\\\", \\\"{x:1478,y:879,t:1527023352374};\\\", \\\"{x:1478,y:881,t:1527023352390};\\\", \\\"{x:1478,y:884,t:1527023352398};\\\", \\\"{x:1479,y:887,t:1527023352413};\\\", \\\"{x:1482,y:899,t:1527023352430};\\\", \\\"{x:1483,y:911,t:1527023352446};\\\", \\\"{x:1480,y:911,t:1527023354255};\\\", \\\"{x:1474,y:907,t:1527023354264};\\\", \\\"{x:1462,y:898,t:1527023354281};\\\", \\\"{x:1448,y:880,t:1527023354298};\\\", \\\"{x:1432,y:851,t:1527023354314};\\\", \\\"{x:1411,y:809,t:1527023354331};\\\", \\\"{x:1397,y:771,t:1527023354347};\\\", \\\"{x:1390,y:750,t:1527023354364};\\\", \\\"{x:1386,y:734,t:1527023354381};\\\", \\\"{x:1383,y:718,t:1527023354399};\\\", \\\"{x:1383,y:714,t:1527023354414};\\\", \\\"{x:1383,y:691,t:1527023354431};\\\", \\\"{x:1383,y:682,t:1527023354448};\\\", \\\"{x:1383,y:683,t:1527023354566};\\\", \\\"{x:1383,y:689,t:1527023354580};\\\", \\\"{x:1384,y:702,t:1527023354597};\\\", \\\"{x:1384,y:709,t:1527023354613};\\\", \\\"{x:1384,y:718,t:1527023354631};\\\", \\\"{x:1384,y:723,t:1527023354648};\\\", \\\"{x:1384,y:726,t:1527023354664};\\\", \\\"{x:1384,y:727,t:1527023354686};\\\", \\\"{x:1384,y:726,t:1527023355263};\\\", \\\"{x:1384,y:725,t:1527023355278};\\\", \\\"{x:1384,y:724,t:1527023355286};\\\", \\\"{x:1384,y:723,t:1527023355327};\\\", \\\"{x:1385,y:722,t:1527023355479};\\\", \\\"{x:1386,y:722,t:1527023355494};\\\", \\\"{x:1387,y:721,t:1527023355510};\\\", \\\"{x:1387,y:720,t:1527023356287};\\\", \\\"{x:1387,y:718,t:1527023356303};\\\", \\\"{x:1387,y:717,t:1527023356335};\\\", \\\"{x:1387,y:715,t:1527023356623};\\\", \\\"{x:1389,y:714,t:1527023356633};\\\", \\\"{x:1390,y:713,t:1527023360687};\\\", \\\"{x:1389,y:713,t:1527023360759};\\\", \\\"{x:1388,y:713,t:1527023360790};\\\", \\\"{x:1387,y:713,t:1527023360847};\\\", \\\"{x:1386,y:713,t:1527023360871};\\\", \\\"{x:1384,y:713,t:1527023360886};\\\", \\\"{x:1381,y:713,t:1527023360902};\\\", \\\"{x:1379,y:713,t:1527023360920};\\\", \\\"{x:1376,y:713,t:1527023360936};\\\", \\\"{x:1371,y:717,t:1527023360954};\\\", \\\"{x:1358,y:729,t:1527023360969};\\\", \\\"{x:1338,y:753,t:1527023360986};\\\", \\\"{x:1307,y:793,t:1527023361003};\\\", \\\"{x:1283,y:819,t:1527023361019};\\\", \\\"{x:1270,y:837,t:1527023361036};\\\", \\\"{x:1261,y:851,t:1527023361054};\\\", \\\"{x:1255,y:859,t:1527023361069};\\\", \\\"{x:1251,y:867,t:1527023361086};\\\", \\\"{x:1250,y:870,t:1527023361103};\\\", \\\"{x:1248,y:876,t:1527023361120};\\\", \\\"{x:1246,y:882,t:1527023361137};\\\", \\\"{x:1242,y:890,t:1527023361153};\\\", \\\"{x:1239,y:896,t:1527023361170};\\\", \\\"{x:1238,y:903,t:1527023361186};\\\", \\\"{x:1236,y:908,t:1527023361203};\\\", \\\"{x:1236,y:910,t:1527023361221};\\\", \\\"{x:1235,y:912,t:1527023361237};\\\", \\\"{x:1235,y:913,t:1527023361255};\\\", \\\"{x:1235,y:914,t:1527023361287};\\\", \\\"{x:1234,y:915,t:1527023361303};\\\", \\\"{x:1233,y:915,t:1527023361327};\\\", \\\"{x:1233,y:916,t:1527023361336};\\\", \\\"{x:1232,y:916,t:1527023361353};\\\", \\\"{x:1231,y:917,t:1527023361370};\\\", \\\"{x:1230,y:917,t:1527023361386};\\\", \\\"{x:1233,y:917,t:1527023361647};\\\", \\\"{x:1233,y:916,t:1527023361654};\\\", \\\"{x:1237,y:915,t:1527023361671};\\\", \\\"{x:1240,y:913,t:1527023361686};\\\", \\\"{x:1245,y:911,t:1527023361704};\\\", \\\"{x:1249,y:909,t:1527023361720};\\\", \\\"{x:1251,y:908,t:1527023361737};\\\", \\\"{x:1253,y:908,t:1527023361753};\\\", \\\"{x:1254,y:908,t:1527023361771};\\\", \\\"{x:1254,y:907,t:1527023361799};\\\", \\\"{x:1255,y:907,t:1527023361870};\\\", \\\"{x:1256,y:906,t:1527023361887};\\\", \\\"{x:1257,y:906,t:1527023361966};\\\", \\\"{x:1258,y:905,t:1527023361990};\\\", \\\"{x:1258,y:904,t:1527023362003};\\\", \\\"{x:1259,y:904,t:1527023362020};\\\", \\\"{x:1260,y:903,t:1527023362038};\\\", \\\"{x:1260,y:901,t:1527023362054};\\\", \\\"{x:1261,y:900,t:1527023362070};\\\", \\\"{x:1261,y:898,t:1527023362095};\\\", \\\"{x:1261,y:897,t:1527023362134};\\\", \\\"{x:1262,y:896,t:1527023362143};\\\", \\\"{x:1263,y:895,t:1527023362159};\\\", \\\"{x:1263,y:894,t:1527023362170};\\\", \\\"{x:1264,y:893,t:1527023362188};\\\", \\\"{x:1265,y:891,t:1527023362204};\\\", \\\"{x:1266,y:889,t:1527023362220};\\\", \\\"{x:1267,y:887,t:1527023362237};\\\", \\\"{x:1271,y:877,t:1527023362254};\\\", \\\"{x:1275,y:871,t:1527023362270};\\\", \\\"{x:1280,y:856,t:1527023362287};\\\", \\\"{x:1286,y:840,t:1527023362304};\\\", \\\"{x:1295,y:823,t:1527023362321};\\\", \\\"{x:1301,y:808,t:1527023362337};\\\", \\\"{x:1309,y:791,t:1527023362354};\\\", \\\"{x:1315,y:766,t:1527023362370};\\\", \\\"{x:1317,y:753,t:1527023362387};\\\", \\\"{x:1315,y:745,t:1527023362404};\\\", \\\"{x:1303,y:740,t:1527023362420};\\\", \\\"{x:1280,y:739,t:1527023362437};\\\", \\\"{x:1216,y:739,t:1527023362454};\\\", \\\"{x:1138,y:739,t:1527023362470};\\\", \\\"{x:1016,y:739,t:1527023362488};\\\", \\\"{x:856,y:739,t:1527023362504};\\\", \\\"{x:679,y:739,t:1527023362521};\\\", \\\"{x:504,y:728,t:1527023362537};\\\", \\\"{x:335,y:703,t:1527023362554};\\\", \\\"{x:224,y:685,t:1527023362571};\\\", \\\"{x:171,y:671,t:1527023362587};\\\", \\\"{x:159,y:665,t:1527023362604};\\\", \\\"{x:156,y:662,t:1527023362620};\\\", \\\"{x:157,y:659,t:1527023362637};\\\", \\\"{x:178,y:629,t:1527023362654};\\\", \\\"{x:198,y:604,t:1527023362670};\\\", \\\"{x:214,y:588,t:1527023362689};\\\", \\\"{x:232,y:566,t:1527023362704};\\\", \\\"{x:258,y:532,t:1527023362721};\\\", \\\"{x:279,y:507,t:1527023362738};\\\", \\\"{x:297,y:487,t:1527023362755};\\\", \\\"{x:313,y:477,t:1527023362771};\\\", \\\"{x:334,y:469,t:1527023362787};\\\", \\\"{x:357,y:463,t:1527023362804};\\\", \\\"{x:376,y:458,t:1527023362821};\\\", \\\"{x:405,y:454,t:1527023362838};\\\", \\\"{x:416,y:454,t:1527023362854};\\\", \\\"{x:417,y:454,t:1527023362870};\\\", \\\"{x:418,y:455,t:1527023362901};\\\", \\\"{x:418,y:456,t:1527023362917};\\\", \\\"{x:418,y:457,t:1527023362941};\\\", \\\"{x:418,y:458,t:1527023362955};\\\", \\\"{x:414,y:461,t:1527023362971};\\\", \\\"{x:403,y:466,t:1527023362987};\\\", \\\"{x:392,y:472,t:1527023363004};\\\", \\\"{x:384,y:477,t:1527023363020};\\\", \\\"{x:377,y:480,t:1527023363037};\\\", \\\"{x:377,y:481,t:1527023363053};\\\", \\\"{x:376,y:483,t:1527023363071};\\\", \\\"{x:375,y:484,t:1527023363088};\\\", \\\"{x:373,y:488,t:1527023363105};\\\", \\\"{x:372,y:490,t:1527023363122};\\\", \\\"{x:370,y:495,t:1527023363137};\\\", \\\"{x:370,y:498,t:1527023363154};\\\", \\\"{x:370,y:500,t:1527023363171};\\\", \\\"{x:369,y:501,t:1527023363187};\\\", \\\"{x:369,y:502,t:1527023363205};\\\", \\\"{x:369,y:504,t:1527023363221};\\\", \\\"{x:371,y:505,t:1527023363238};\\\", \\\"{x:373,y:507,t:1527023363255};\\\", \\\"{x:374,y:507,t:1527023363272};\\\", \\\"{x:375,y:509,t:1527023363551};\\\", \\\"{x:378,y:512,t:1527023363557};\\\", \\\"{x:382,y:519,t:1527023363572};\\\", \\\"{x:392,y:537,t:1527023363590};\\\", \\\"{x:403,y:557,t:1527023363605};\\\", \\\"{x:422,y:587,t:1527023363622};\\\", \\\"{x:434,y:605,t:1527023363639};\\\", \\\"{x:447,y:619,t:1527023363654};\\\", \\\"{x:457,y:634,t:1527023363672};\\\", \\\"{x:470,y:648,t:1527023363689};\\\", \\\"{x:481,y:662,t:1527023363706};\\\", \\\"{x:488,y:669,t:1527023363721};\\\", \\\"{x:493,y:674,t:1527023363738};\\\", \\\"{x:497,y:677,t:1527023363756};\\\", \\\"{x:499,y:678,t:1527023363771};\\\", \\\"{x:501,y:681,t:1527023363789};\\\", \\\"{x:502,y:681,t:1527023363805};\\\", \\\"{x:500,y:673,t:1527023363822};\\\", \\\"{x:487,y:653,t:1527023363839};\\\", \\\"{x:475,y:635,t:1527023363856};\\\", \\\"{x:462,y:618,t:1527023363873};\\\", \\\"{x:437,y:581,t:1527023363890};\\\", \\\"{x:422,y:556,t:1527023363906};\\\", \\\"{x:413,y:542,t:1527023363922};\\\", \\\"{x:410,y:538,t:1527023363939};\\\", \\\"{x:409,y:535,t:1527023363955};\\\", \\\"{x:409,y:533,t:1527023363972};\\\", \\\"{x:409,y:532,t:1527023363989};\\\", \\\"{x:406,y:530,t:1527023364127};\\\", \\\"{x:406,y:528,t:1527023364139};\\\", \\\"{x:402,y:525,t:1527023364155};\\\", \\\"{x:399,y:523,t:1527023364172};\\\", \\\"{x:397,y:521,t:1527023364189};\\\", \\\"{x:392,y:516,t:1527023364205};\\\", \\\"{x:389,y:514,t:1527023364222};\\\", \\\"{x:393,y:519,t:1527023364639};\\\", \\\"{x:416,y:541,t:1527023364656};\\\", \\\"{x:457,y:588,t:1527023364673};\\\", \\\"{x:501,y:636,t:1527023364691};\\\", \\\"{x:532,y:666,t:1527023364706};\\\", \\\"{x:553,y:681,t:1527023364722};\\\", \\\"{x:564,y:690,t:1527023364740};\\\", \\\"{x:568,y:694,t:1527023364756};\\\", \\\"{x:568,y:691,t:1527023365055};\\\", \\\"{x:566,y:689,t:1527023365062};\\\", \\\"{x:565,y:688,t:1527023365078};\\\", \\\"{x:565,y:687,t:1527023365094};\\\", \\\"{x:564,y:687,t:1527023365438};\\\", \\\"{x:563,y:687,t:1527023365445};\\\", \\\"{x:561,y:686,t:1527023365457};\\\", \\\"{x:561,y:685,t:1527023365474};\\\", \\\"{x:560,y:685,t:1527023365493};\\\", \\\"{x:559,y:685,t:1527023365509};\\\", \\\"{x:558,y:685,t:1527023365524};\\\", \\\"{x:557,y:685,t:1527023365639};\\\", \\\"{x:556,y:683,t:1527023366269};\\\", \\\"{x:554,y:678,t:1527023366277};\\\", \\\"{x:549,y:673,t:1527023366291};\\\", \\\"{x:545,y:668,t:1527023366306};\\\", \\\"{x:541,y:662,t:1527023366323};\\\", \\\"{x:538,y:659,t:1527023366340};\\\", \\\"{x:537,y:656,t:1527023366358};\\\", \\\"{x:538,y:656,t:1527023367118};\\\", \\\"{x:542,y:656,t:1527023367126};\\\", \\\"{x:547,y:656,t:1527023367141};\\\", \\\"{x:567,y:656,t:1527023367158};\\\", \\\"{x:586,y:656,t:1527023367176};\\\", \\\"{x:596,y:656,t:1527023367192};\\\", \\\"{x:597,y:656,t:1527023367208};\\\" ] }, { \\\"rt\\\": 20998, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 6, \\\"time_elapsed\\\": 474260, \\\"internal_node_id\\\": \\\"0.0-5.0-1.0\\\", \\\"subject\\\": \\\"QOJ6L\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"hotel\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 2, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"K\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:597,y:651,t:1527023368297};\\\", \\\"{x:597,y:649,t:1527023368309};\\\", \\\"{x:597,y:648,t:1527023368373};\\\", \\\"{x:597,y:646,t:1527023368421};\\\", \\\"{x:597,y:645,t:1527023368469};\\\", \\\"{x:597,y:641,t:1527023369565};\\\", \\\"{x:597,y:633,t:1527023369577};\\\", \\\"{x:597,y:611,t:1527023369593};\\\", \\\"{x:583,y:565,t:1527023369610};\\\", \\\"{x:561,y:506,t:1527023369627};\\\", \\\"{x:542,y:462,t:1527023369643};\\\", \\\"{x:527,y:430,t:1527023369661};\\\", \\\"{x:506,y:397,t:1527023369677};\\\", \\\"{x:496,y:384,t:1527023369694};\\\", \\\"{x:489,y:372,t:1527023369710};\\\", \\\"{x:481,y:363,t:1527023369727};\\\", \\\"{x:478,y:359,t:1527023369744};\\\", \\\"{x:473,y:360,t:1527023369861};\\\", \\\"{x:470,y:364,t:1527023369876};\\\", \\\"{x:461,y:375,t:1527023369892};\\\", \\\"{x:456,y:383,t:1527023369909};\\\", \\\"{x:447,y:395,t:1527023369927};\\\", \\\"{x:443,y:401,t:1527023369943};\\\", \\\"{x:442,y:402,t:1527023369960};\\\", \\\"{x:441,y:403,t:1527023369977};\\\", \\\"{x:444,y:406,t:1527023370190};\\\", \\\"{x:447,y:408,t:1527023370198};\\\", \\\"{x:453,y:409,t:1527023370211};\\\", \\\"{x:471,y:414,t:1527023370226};\\\", \\\"{x:491,y:416,t:1527023370244};\\\", \\\"{x:509,y:419,t:1527023370261};\\\", \\\"{x:524,y:420,t:1527023370277};\\\", \\\"{x:538,y:421,t:1527023370294};\\\", \\\"{x:539,y:422,t:1527023370311};\\\", \\\"{x:541,y:422,t:1527023370526};\\\", \\\"{x:542,y:421,t:1527023370534};\\\", \\\"{x:543,y:421,t:1527023370544};\\\", \\\"{x:546,y:419,t:1527023370561};\\\", \\\"{x:548,y:419,t:1527023370579};\\\", \\\"{x:553,y:419,t:1527023370594};\\\", \\\"{x:559,y:419,t:1527023370611};\\\", \\\"{x:569,y:419,t:1527023370628};\\\", \\\"{x:581,y:419,t:1527023370644};\\\", \\\"{x:597,y:419,t:1527023370661};\\\", \\\"{x:627,y:422,t:1527023370678};\\\", \\\"{x:650,y:426,t:1527023370694};\\\", \\\"{x:678,y:430,t:1527023370711};\\\", \\\"{x:709,y:435,t:1527023370729};\\\", \\\"{x:743,y:440,t:1527023370745};\\\", \\\"{x:778,y:445,t:1527023370762};\\\", \\\"{x:821,y:452,t:1527023370778};\\\", \\\"{x:912,y:452,t:1527023370794};\\\", \\\"{x:998,y:452,t:1527023370811};\\\", \\\"{x:1071,y:452,t:1527023370828};\\\", \\\"{x:1129,y:452,t:1527023370844};\\\", \\\"{x:1188,y:452,t:1527023370862};\\\", \\\"{x:1262,y:455,t:1527023370878};\\\", \\\"{x:1285,y:455,t:1527023370895};\\\", \\\"{x:1285,y:458,t:1527023371358};\\\", \\\"{x:1286,y:459,t:1527023371382};\\\", \\\"{x:1288,y:459,t:1527023371396};\\\", \\\"{x:1297,y:462,t:1527023371413};\\\", \\\"{x:1303,y:462,t:1527023371429};\\\", \\\"{x:1310,y:464,t:1527023371446};\\\", \\\"{x:1319,y:465,t:1527023371462};\\\", \\\"{x:1332,y:466,t:1527023371478};\\\", \\\"{x:1343,y:468,t:1527023371495};\\\", \\\"{x:1360,y:471,t:1527023371513};\\\", \\\"{x:1381,y:471,t:1527023371528};\\\", \\\"{x:1401,y:472,t:1527023371546};\\\", \\\"{x:1423,y:472,t:1527023371562};\\\", \\\"{x:1445,y:472,t:1527023371579};\\\", \\\"{x:1466,y:472,t:1527023371595};\\\", \\\"{x:1489,y:469,t:1527023371612};\\\", \\\"{x:1508,y:464,t:1527023371628};\\\", \\\"{x:1535,y:455,t:1527023371645};\\\", \\\"{x:1552,y:448,t:1527023371662};\\\", \\\"{x:1564,y:443,t:1527023371678};\\\", \\\"{x:1578,y:438,t:1527023371695};\\\", \\\"{x:1586,y:434,t:1527023371712};\\\", \\\"{x:1593,y:431,t:1527023371728};\\\", \\\"{x:1596,y:428,t:1527023371745};\\\", \\\"{x:1600,y:425,t:1527023371762};\\\", \\\"{x:1604,y:422,t:1527023371779};\\\", \\\"{x:1607,y:420,t:1527023371795};\\\", \\\"{x:1610,y:418,t:1527023371812};\\\", \\\"{x:1611,y:417,t:1527023371829};\\\", \\\"{x:1613,y:415,t:1527023371845};\\\", \\\"{x:1614,y:413,t:1527023371862};\\\", \\\"{x:1616,y:411,t:1527023371880};\\\", \\\"{x:1617,y:409,t:1527023371896};\\\", \\\"{x:1617,y:408,t:1527023371913};\\\", \\\"{x:1619,y:405,t:1527023371929};\\\", \\\"{x:1619,y:401,t:1527023371946};\\\", \\\"{x:1620,y:396,t:1527023371962};\\\", \\\"{x:1620,y:392,t:1527023371980};\\\", \\\"{x:1621,y:389,t:1527023371995};\\\", \\\"{x:1621,y:385,t:1527023372013};\\\", \\\"{x:1621,y:383,t:1527023372030};\\\", \\\"{x:1621,y:382,t:1527023372046};\\\", \\\"{x:1621,y:380,t:1527023372062};\\\", \\\"{x:1620,y:380,t:1527023372542};\\\", \\\"{x:1619,y:382,t:1527023372550};\\\", \\\"{x:1616,y:388,t:1527023372562};\\\", \\\"{x:1610,y:397,t:1527023372579};\\\", \\\"{x:1607,y:405,t:1527023372597};\\\", \\\"{x:1602,y:411,t:1527023372613};\\\", \\\"{x:1598,y:417,t:1527023372629};\\\", \\\"{x:1593,y:424,t:1527023372646};\\\", \\\"{x:1590,y:429,t:1527023372662};\\\", \\\"{x:1587,y:435,t:1527023372679};\\\", \\\"{x:1584,y:440,t:1527023372697};\\\", \\\"{x:1580,y:447,t:1527023372713};\\\", \\\"{x:1572,y:461,t:1527023372729};\\\", \\\"{x:1561,y:476,t:1527023372746};\\\", \\\"{x:1550,y:491,t:1527023372764};\\\", \\\"{x:1539,y:503,t:1527023372779};\\\", \\\"{x:1527,y:514,t:1527023372796};\\\", \\\"{x:1518,y:524,t:1527023372814};\\\", \\\"{x:1504,y:544,t:1527023372830};\\\", \\\"{x:1493,y:557,t:1527023372846};\\\", \\\"{x:1473,y:573,t:1527023372864};\\\", \\\"{x:1451,y:591,t:1527023372880};\\\", \\\"{x:1427,y:636,t:1527023372896};\\\", \\\"{x:1405,y:684,t:1527023372913};\\\", \\\"{x:1385,y:728,t:1527023372930};\\\", \\\"{x:1372,y:749,t:1527023372946};\\\", \\\"{x:1366,y:755,t:1527023372963};\\\", \\\"{x:1359,y:758,t:1527023372979};\\\", \\\"{x:1353,y:760,t:1527023372996};\\\", \\\"{x:1348,y:762,t:1527023373014};\\\", \\\"{x:1338,y:764,t:1527023373030};\\\", \\\"{x:1326,y:766,t:1527023373046};\\\", \\\"{x:1314,y:767,t:1527023373064};\\\", \\\"{x:1301,y:768,t:1527023373079};\\\", \\\"{x:1276,y:772,t:1527023373096};\\\", \\\"{x:1239,y:773,t:1527023373113};\\\", \\\"{x:1177,y:773,t:1527023373131};\\\", \\\"{x:1083,y:773,t:1527023373146};\\\", \\\"{x:978,y:773,t:1527023373164};\\\", \\\"{x:853,y:772,t:1527023373180};\\\", \\\"{x:712,y:755,t:1527023373196};\\\", \\\"{x:582,y:736,t:1527023373213};\\\", \\\"{x:431,y:704,t:1527023373230};\\\", \\\"{x:379,y:683,t:1527023373247};\\\", \\\"{x:343,y:658,t:1527023373263};\\\", \\\"{x:320,y:639,t:1527023373280};\\\", \\\"{x:311,y:628,t:1527023373296};\\\", \\\"{x:309,y:622,t:1527023373313};\\\", \\\"{x:309,y:616,t:1527023373330};\\\", \\\"{x:309,y:611,t:1527023373347};\\\", \\\"{x:313,y:603,t:1527023373363};\\\", \\\"{x:319,y:593,t:1527023373382};\\\", \\\"{x:331,y:583,t:1527023373395};\\\", \\\"{x:356,y:565,t:1527023373413};\\\", \\\"{x:377,y:555,t:1527023373430};\\\", \\\"{x:410,y:544,t:1527023373447};\\\", \\\"{x:443,y:535,t:1527023373463};\\\", \\\"{x:472,y:526,t:1527023373480};\\\", \\\"{x:499,y:523,t:1527023373497};\\\", \\\"{x:520,y:520,t:1527023373513};\\\", \\\"{x:530,y:519,t:1527023373530};\\\", \\\"{x:536,y:519,t:1527023373546};\\\", \\\"{x:537,y:519,t:1527023373563};\\\", \\\"{x:538,y:519,t:1527023373613};\\\", \\\"{x:533,y:523,t:1527023373631};\\\", \\\"{x:523,y:524,t:1527023373647};\\\", \\\"{x:503,y:528,t:1527023373663};\\\", \\\"{x:479,y:530,t:1527023373680};\\\", \\\"{x:448,y:533,t:1527023373697};\\\", \\\"{x:420,y:537,t:1527023373712};\\\", \\\"{x:399,y:540,t:1527023373730};\\\", \\\"{x:388,y:541,t:1527023373747};\\\", \\\"{x:385,y:542,t:1527023373763};\\\", \\\"{x:384,y:544,t:1527023373780};\\\", \\\"{x:383,y:544,t:1527023373829};\\\", \\\"{x:390,y:544,t:1527023377862};\\\", \\\"{x:401,y:544,t:1527023377870};\\\", \\\"{x:413,y:545,t:1527023377883};\\\", \\\"{x:438,y:547,t:1527023377901};\\\", \\\"{x:464,y:550,t:1527023377918};\\\", \\\"{x:473,y:551,t:1527023377934};\\\", \\\"{x:475,y:551,t:1527023377950};\\\", \\\"{x:477,y:551,t:1527023378422};\\\", \\\"{x:480,y:551,t:1527023378434};\\\", \\\"{x:485,y:549,t:1527023378451};\\\", \\\"{x:495,y:549,t:1527023378467};\\\", \\\"{x:513,y:549,t:1527023378486};\\\", \\\"{x:532,y:550,t:1527023378500};\\\", \\\"{x:571,y:552,t:1527023378517};\\\", \\\"{x:600,y:553,t:1527023378534};\\\", \\\"{x:626,y:553,t:1527023378550};\\\", \\\"{x:656,y:553,t:1527023378567};\\\", \\\"{x:687,y:553,t:1527023378584};\\\", \\\"{x:723,y:553,t:1527023378601};\\\", \\\"{x:755,y:553,t:1527023378617};\\\", \\\"{x:785,y:553,t:1527023378634};\\\", \\\"{x:810,y:553,t:1527023378650};\\\", \\\"{x:840,y:553,t:1527023378667};\\\", \\\"{x:888,y:546,t:1527023378684};\\\", \\\"{x:985,y:531,t:1527023378701};\\\", \\\"{x:1033,y:523,t:1527023378717};\\\", \\\"{x:1066,y:517,t:1527023378734};\\\", \\\"{x:1102,y:514,t:1527023378751};\\\", \\\"{x:1134,y:512,t:1527023378767};\\\", \\\"{x:1167,y:510,t:1527023378784};\\\", \\\"{x:1195,y:510,t:1527023378802};\\\", \\\"{x:1214,y:510,t:1527023378817};\\\", \\\"{x:1231,y:511,t:1527023378834};\\\", \\\"{x:1236,y:511,t:1527023378851};\\\", \\\"{x:1238,y:513,t:1527023378867};\\\", \\\"{x:1241,y:517,t:1527023378884};\\\", \\\"{x:1242,y:518,t:1527023378901};\\\", \\\"{x:1243,y:520,t:1527023379302};\\\", \\\"{x:1243,y:521,t:1527023379319};\\\", \\\"{x:1243,y:522,t:1527023379335};\\\", \\\"{x:1243,y:523,t:1527023379414};\\\", \\\"{x:1243,y:524,t:1527023379421};\\\", \\\"{x:1244,y:525,t:1527023379470};\\\", \\\"{x:1246,y:526,t:1527023379614};\\\", \\\"{x:1247,y:527,t:1527023379646};\\\", \\\"{x:1248,y:528,t:1527023379678};\\\", \\\"{x:1249,y:529,t:1527023379710};\\\", \\\"{x:1250,y:529,t:1527023379734};\\\", \\\"{x:1252,y:529,t:1527023379966};\\\", \\\"{x:1254,y:529,t:1527023379973};\\\", \\\"{x:1257,y:529,t:1527023379986};\\\", \\\"{x:1264,y:530,t:1527023380002};\\\", \\\"{x:1271,y:531,t:1527023380019};\\\", \\\"{x:1283,y:533,t:1527023380035};\\\", \\\"{x:1296,y:535,t:1527023380052};\\\", \\\"{x:1323,y:538,t:1527023380069};\\\", \\\"{x:1345,y:542,t:1527023380085};\\\", \\\"{x:1374,y:543,t:1527023380103};\\\", \\\"{x:1405,y:546,t:1527023380119};\\\", \\\"{x:1436,y:546,t:1527023380136};\\\", \\\"{x:1469,y:548,t:1527023380153};\\\", \\\"{x:1497,y:548,t:1527023380169};\\\", \\\"{x:1520,y:548,t:1527023380185};\\\", \\\"{x:1543,y:548,t:1527023380203};\\\", \\\"{x:1563,y:548,t:1527023380219};\\\", \\\"{x:1580,y:548,t:1527023380235};\\\", \\\"{x:1596,y:548,t:1527023380252};\\\", \\\"{x:1613,y:545,t:1527023380269};\\\", \\\"{x:1618,y:543,t:1527023380286};\\\", \\\"{x:1619,y:543,t:1527023380334};\\\", \\\"{x:1616,y:546,t:1527023380407};\\\", \\\"{x:1611,y:547,t:1527023380420};\\\", \\\"{x:1604,y:551,t:1527023380437};\\\", \\\"{x:1601,y:553,t:1527023380453};\\\", \\\"{x:1590,y:561,t:1527023380470};\\\", \\\"{x:1584,y:567,t:1527023380486};\\\", \\\"{x:1578,y:573,t:1527023380502};\\\", \\\"{x:1575,y:579,t:1527023380520};\\\", \\\"{x:1574,y:583,t:1527023380537};\\\", \\\"{x:1573,y:589,t:1527023380552};\\\", \\\"{x:1571,y:595,t:1527023380570};\\\", \\\"{x:1570,y:599,t:1527023380587};\\\", \\\"{x:1569,y:601,t:1527023380603};\\\", \\\"{x:1569,y:604,t:1527023380620};\\\", \\\"{x:1569,y:607,t:1527023380637};\\\", \\\"{x:1567,y:610,t:1527023380653};\\\", \\\"{x:1567,y:616,t:1527023380670};\\\", \\\"{x:1566,y:621,t:1527023380686};\\\", \\\"{x:1566,y:630,t:1527023380703};\\\", \\\"{x:1566,y:647,t:1527023380720};\\\", \\\"{x:1567,y:669,t:1527023380737};\\\", \\\"{x:1574,y:697,t:1527023380754};\\\", \\\"{x:1579,y:719,t:1527023380770};\\\", \\\"{x:1586,y:741,t:1527023380787};\\\", \\\"{x:1591,y:759,t:1527023380803};\\\", \\\"{x:1597,y:775,t:1527023380820};\\\", \\\"{x:1601,y:786,t:1527023380837};\\\", \\\"{x:1604,y:798,t:1527023380854};\\\", \\\"{x:1606,y:805,t:1527023380870};\\\", \\\"{x:1609,y:809,t:1527023380887};\\\", \\\"{x:1609,y:812,t:1527023380904};\\\", \\\"{x:1610,y:814,t:1527023380920};\\\", \\\"{x:1610,y:816,t:1527023380937};\\\", \\\"{x:1611,y:818,t:1527023380954};\\\", \\\"{x:1611,y:819,t:1527023380970};\\\", \\\"{x:1612,y:820,t:1527023380987};\\\", \\\"{x:1612,y:821,t:1527023381004};\\\", \\\"{x:1613,y:824,t:1527023381020};\\\", \\\"{x:1615,y:827,t:1527023381037};\\\", \\\"{x:1616,y:829,t:1527023381054};\\\", \\\"{x:1618,y:832,t:1527023381070};\\\", \\\"{x:1622,y:836,t:1527023381087};\\\", \\\"{x:1624,y:838,t:1527023381104};\\\", \\\"{x:1627,y:840,t:1527023381120};\\\", \\\"{x:1630,y:842,t:1527023381137};\\\", \\\"{x:1633,y:844,t:1527023381153};\\\", \\\"{x:1637,y:846,t:1527023381170};\\\", \\\"{x:1640,y:848,t:1527023381186};\\\", \\\"{x:1645,y:850,t:1527023381204};\\\", \\\"{x:1650,y:853,t:1527023381221};\\\", \\\"{x:1652,y:854,t:1527023381236};\\\", \\\"{x:1654,y:855,t:1527023381254};\\\", \\\"{x:1654,y:856,t:1527023381270};\\\", \\\"{x:1655,y:857,t:1527023381286};\\\", \\\"{x:1656,y:858,t:1527023381304};\\\", \\\"{x:1657,y:858,t:1527023381326};\\\", \\\"{x:1657,y:859,t:1527023381590};\\\", \\\"{x:1657,y:860,t:1527023382199};\\\", \\\"{x:1656,y:860,t:1527023382421};\\\", \\\"{x:1655,y:860,t:1527023382438};\\\", \\\"{x:1651,y:860,t:1527023382454};\\\", \\\"{x:1644,y:860,t:1527023382471};\\\", \\\"{x:1639,y:860,t:1527023382487};\\\", \\\"{x:1631,y:860,t:1527023382505};\\\", \\\"{x:1622,y:863,t:1527023382522};\\\", \\\"{x:1609,y:864,t:1527023382537};\\\", \\\"{x:1600,y:864,t:1527023382555};\\\", \\\"{x:1591,y:864,t:1527023382572};\\\", \\\"{x:1581,y:864,t:1527023382589};\\\", \\\"{x:1567,y:864,t:1527023382605};\\\", \\\"{x:1548,y:864,t:1527023382622};\\\", \\\"{x:1539,y:864,t:1527023382638};\\\", \\\"{x:1530,y:866,t:1527023382654};\\\", \\\"{x:1522,y:868,t:1527023382671};\\\", \\\"{x:1513,y:871,t:1527023382688};\\\", \\\"{x:1506,y:874,t:1527023382704};\\\", \\\"{x:1500,y:877,t:1527023382721};\\\", \\\"{x:1493,y:881,t:1527023382739};\\\", \\\"{x:1489,y:882,t:1527023382754};\\\", \\\"{x:1484,y:885,t:1527023382771};\\\", \\\"{x:1481,y:888,t:1527023382788};\\\", \\\"{x:1479,y:889,t:1527023382804};\\\", \\\"{x:1476,y:890,t:1527023382821};\\\", \\\"{x:1475,y:892,t:1527023382845};\\\", \\\"{x:1474,y:892,t:1527023382855};\\\", \\\"{x:1473,y:892,t:1527023382877};\\\", \\\"{x:1472,y:892,t:1527023382889};\\\", \\\"{x:1471,y:893,t:1527023382910};\\\", \\\"{x:1470,y:894,t:1527023383686};\\\", \\\"{x:1468,y:896,t:1527023383694};\\\", \\\"{x:1466,y:897,t:1527023383706};\\\", \\\"{x:1465,y:898,t:1527023383723};\\\", \\\"{x:1464,y:899,t:1527023383740};\\\", \\\"{x:1463,y:899,t:1527023383755};\\\", \\\"{x:1462,y:899,t:1527023384102};\\\", \\\"{x:1461,y:899,t:1527023384110};\\\", \\\"{x:1458,y:899,t:1527023384166};\\\", \\\"{x:1457,y:899,t:1527023384670};\\\", \\\"{x:1455,y:899,t:1527023384678};\\\", \\\"{x:1454,y:899,t:1527023384691};\\\", \\\"{x:1448,y:899,t:1527023384707};\\\", \\\"{x:1445,y:899,t:1527023384724};\\\", \\\"{x:1443,y:898,t:1527023384741};\\\", \\\"{x:1441,y:898,t:1527023384757};\\\", \\\"{x:1439,y:896,t:1527023384774};\\\", \\\"{x:1438,y:896,t:1527023384790};\\\", \\\"{x:1436,y:895,t:1527023384822};\\\", \\\"{x:1435,y:894,t:1527023384830};\\\", \\\"{x:1434,y:894,t:1527023384846};\\\", \\\"{x:1433,y:894,t:1527023384857};\\\", \\\"{x:1431,y:893,t:1527023384874};\\\", \\\"{x:1428,y:892,t:1527023384891};\\\", \\\"{x:1424,y:891,t:1527023384907};\\\", \\\"{x:1415,y:890,t:1527023384924};\\\", \\\"{x:1407,y:889,t:1527023384941};\\\", \\\"{x:1397,y:889,t:1527023384958};\\\", \\\"{x:1379,y:889,t:1527023384974};\\\", \\\"{x:1367,y:890,t:1527023384991};\\\", \\\"{x:1346,y:895,t:1527023385007};\\\", \\\"{x:1305,y:909,t:1527023385024};\\\", \\\"{x:1257,y:927,t:1527023385041};\\\", \\\"{x:1219,y:939,t:1527023385058};\\\", \\\"{x:1182,y:947,t:1527023385074};\\\", \\\"{x:1150,y:948,t:1527023385091};\\\", \\\"{x:1116,y:951,t:1527023385108};\\\", \\\"{x:1063,y:951,t:1527023385124};\\\", \\\"{x:996,y:951,t:1527023385141};\\\", \\\"{x:870,y:948,t:1527023385158};\\\", \\\"{x:789,y:937,t:1527023385174};\\\", \\\"{x:703,y:922,t:1527023385190};\\\", \\\"{x:630,y:909,t:1527023385208};\\\", \\\"{x:571,y:891,t:1527023385224};\\\", \\\"{x:526,y:877,t:1527023385240};\\\", \\\"{x:487,y:860,t:1527023385258};\\\", \\\"{x:456,y:838,t:1527023385274};\\\", \\\"{x:418,y:808,t:1527023385291};\\\", \\\"{x:393,y:785,t:1527023385308};\\\", \\\"{x:385,y:774,t:1527023385323};\\\", \\\"{x:384,y:770,t:1527023385341};\\\", \\\"{x:384,y:751,t:1527023385358};\\\", \\\"{x:382,y:741,t:1527023385374};\\\", \\\"{x:383,y:741,t:1527023385807};\\\", \\\"{x:384,y:741,t:1527023385830};\\\", \\\"{x:386,y:741,t:1527023385842};\\\", \\\"{x:391,y:740,t:1527023385857};\\\", \\\"{x:397,y:740,t:1527023385875};\\\", \\\"{x:402,y:740,t:1527023385892};\\\", \\\"{x:408,y:739,t:1527023385908};\\\", \\\"{x:413,y:738,t:1527023385925};\\\", \\\"{x:418,y:738,t:1527023385942};\\\", \\\"{x:419,y:738,t:1527023385958};\\\", \\\"{x:422,y:738,t:1527023385975};\\\", \\\"{x:423,y:738,t:1527023385991};\\\", \\\"{x:424,y:738,t:1527023386008};\\\", \\\"{x:424,y:737,t:1527023386134};\\\", \\\"{x:425,y:737,t:1527023386150};\\\", \\\"{x:429,y:735,t:1527023386414};\\\", \\\"{x:434,y:734,t:1527023386425};\\\", \\\"{x:443,y:731,t:1527023386442};\\\", \\\"{x:452,y:727,t:1527023386459};\\\", \\\"{x:459,y:724,t:1527023386475};\\\", \\\"{x:464,y:722,t:1527023386492};\\\", \\\"{x:467,y:720,t:1527023386509};\\\", \\\"{x:468,y:719,t:1527023386525};\\\", \\\"{x:470,y:717,t:1527023386542};\\\", \\\"{x:471,y:715,t:1527023386582};\\\", \\\"{x:471,y:714,t:1527023386646};\\\", \\\"{x:471,y:713,t:1527023386659};\\\", \\\"{x:471,y:710,t:1527023386676};\\\", \\\"{x:473,y:707,t:1527023386692};\\\", \\\"{x:478,y:698,t:1527023386709};\\\", \\\"{x:482,y:693,t:1527023386726};\\\", \\\"{x:485,y:688,t:1527023386742};\\\", \\\"{x:488,y:685,t:1527023386759};\\\", \\\"{x:489,y:684,t:1527023386775};\\\", \\\"{x:491,y:682,t:1527023386793};\\\", \\\"{x:492,y:681,t:1527023386808};\\\", \\\"{x:497,y:677,t:1527023386825};\\\", \\\"{x:501,y:674,t:1527023386841};\\\", \\\"{x:503,y:672,t:1527023386857};\\\", \\\"{x:506,y:670,t:1527023386874};\\\", \\\"{x:508,y:668,t:1527023386891};\\\", \\\"{x:509,y:667,t:1527023386908};\\\", \\\"{x:510,y:666,t:1527023386924};\\\", \\\"{x:512,y:665,t:1527023386941};\\\", \\\"{x:512,y:664,t:1527023386958};\\\", \\\"{x:513,y:664,t:1527023386997};\\\", \\\"{x:514,y:663,t:1527023389718};\\\", \\\"{x:514,y:662,t:1527023389727};\\\", \\\"{x:514,y:660,t:1527023389744};\\\", \\\"{x:514,y:659,t:1527023389759};\\\", \\\"{x:515,y:652,t:1527023389776};\\\", \\\"{x:515,y:651,t:1527023389794};\\\" ] }, { \\\"rt\\\": 21828, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 7, \\\"time_elapsed\\\": 497367, \\\"internal_node_id\\\": \\\"0.0-5.0-2.0\\\", \\\"subject\\\": \\\"QOJ6L\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"hotel\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 3, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-C -F -U -U \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:515,y:650,t:1527023390443};\\\", \\\"{x:515,y:649,t:1527023390477};\\\", \\\"{x:515,y:648,t:1527023390517};\\\", \\\"{x:513,y:645,t:1527023390862};\\\", \\\"{x:501,y:639,t:1527023390877};\\\", \\\"{x:485,y:632,t:1527023390894};\\\", \\\"{x:469,y:628,t:1527023390911};\\\", \\\"{x:446,y:621,t:1527023390927};\\\", \\\"{x:429,y:618,t:1527023390945};\\\", \\\"{x:415,y:616,t:1527023390961};\\\", \\\"{x:405,y:612,t:1527023390978};\\\", \\\"{x:398,y:603,t:1527023390995};\\\", \\\"{x:394,y:590,t:1527023391011};\\\", \\\"{x:393,y:573,t:1527023391028};\\\", \\\"{x:390,y:540,t:1527023391047};\\\", \\\"{x:390,y:528,t:1527023391061};\\\", \\\"{x:390,y:498,t:1527023391078};\\\", \\\"{x:390,y:484,t:1527023391095};\\\", \\\"{x:391,y:473,t:1527023391111};\\\", \\\"{x:391,y:459,t:1527023391127};\\\", \\\"{x:391,y:448,t:1527023391145};\\\", \\\"{x:392,y:439,t:1527023391161};\\\", \\\"{x:392,y:436,t:1527023391178};\\\", \\\"{x:392,y:433,t:1527023391194};\\\", \\\"{x:392,y:431,t:1527023391213};\\\", \\\"{x:393,y:430,t:1527023391228};\\\", \\\"{x:393,y:427,t:1527023391245};\\\", \\\"{x:393,y:423,t:1527023391262};\\\", \\\"{x:393,y:422,t:1527023391278};\\\", \\\"{x:393,y:421,t:1527023391774};\\\", \\\"{x:395,y:421,t:1527023391789};\\\", \\\"{x:396,y:422,t:1527023391797};\\\", \\\"{x:398,y:423,t:1527023391813};\\\", \\\"{x:400,y:425,t:1527023391828};\\\", \\\"{x:406,y:428,t:1527023391845};\\\", \\\"{x:408,y:428,t:1527023391862};\\\", \\\"{x:412,y:431,t:1527023391880};\\\", \\\"{x:416,y:431,t:1527023391895};\\\", \\\"{x:423,y:433,t:1527023391912};\\\", \\\"{x:431,y:435,t:1527023391929};\\\", \\\"{x:436,y:435,t:1527023391946};\\\", \\\"{x:441,y:435,t:1527023391962};\\\", \\\"{x:446,y:435,t:1527023391979};\\\", \\\"{x:450,y:435,t:1527023391996};\\\", \\\"{x:453,y:435,t:1527023392011};\\\", \\\"{x:454,y:435,t:1527023392029};\\\", \\\"{x:456,y:435,t:1527023392045};\\\", \\\"{x:457,y:435,t:1527023392062};\\\", \\\"{x:460,y:435,t:1527023392078};\\\", \\\"{x:466,y:435,t:1527023392096};\\\", \\\"{x:475,y:434,t:1527023392112};\\\", \\\"{x:482,y:430,t:1527023392128};\\\", \\\"{x:491,y:429,t:1527023392146};\\\", \\\"{x:504,y:427,t:1527023392162};\\\", \\\"{x:519,y:424,t:1527023392178};\\\", \\\"{x:537,y:424,t:1527023392196};\\\", \\\"{x:555,y:424,t:1527023392212};\\\", \\\"{x:566,y:424,t:1527023392229};\\\", \\\"{x:567,y:424,t:1527023392246};\\\", \\\"{x:569,y:425,t:1527023392758};\\\", \\\"{x:569,y:428,t:1527023393118};\\\", \\\"{x:569,y:432,t:1527023393130};\\\", \\\"{x:570,y:448,t:1527023393148};\\\", \\\"{x:576,y:460,t:1527023393165};\\\", \\\"{x:591,y:476,t:1527023393180};\\\", \\\"{x:630,y:498,t:1527023393197};\\\", \\\"{x:673,y:511,t:1527023393213};\\\", \\\"{x:722,y:522,t:1527023393230};\\\", \\\"{x:780,y:530,t:1527023393246};\\\", \\\"{x:843,y:533,t:1527023393263};\\\", \\\"{x:913,y:537,t:1527023393279};\\\", \\\"{x:961,y:537,t:1527023393296};\\\", \\\"{x:1006,y:537,t:1527023393313};\\\", \\\"{x:1036,y:537,t:1527023393330};\\\", \\\"{x:1051,y:532,t:1527023393346};\\\", \\\"{x:1051,y:531,t:1527023393362};\\\", \\\"{x:1052,y:531,t:1527023393783};\\\", \\\"{x:1055,y:529,t:1527023393797};\\\", \\\"{x:1059,y:527,t:1527023393814};\\\", \\\"{x:1062,y:527,t:1527023393830};\\\", \\\"{x:1065,y:527,t:1527023393848};\\\", \\\"{x:1066,y:527,t:1527023393864};\\\", \\\"{x:1068,y:527,t:1527023393880};\\\", \\\"{x:1074,y:527,t:1527023393897};\\\", \\\"{x:1079,y:527,t:1527023393914};\\\", \\\"{x:1087,y:527,t:1527023393930};\\\", \\\"{x:1091,y:527,t:1527023393947};\\\", \\\"{x:1097,y:527,t:1527023393964};\\\", \\\"{x:1107,y:527,t:1527023393980};\\\", \\\"{x:1116,y:527,t:1527023393998};\\\", \\\"{x:1122,y:527,t:1527023394014};\\\", \\\"{x:1126,y:527,t:1527023394030};\\\", \\\"{x:1127,y:527,t:1527023394047};\\\", \\\"{x:1129,y:527,t:1527023394064};\\\", \\\"{x:1130,y:527,t:1527023394081};\\\", \\\"{x:1132,y:527,t:1527023394097};\\\", \\\"{x:1136,y:527,t:1527023394114};\\\", \\\"{x:1140,y:527,t:1527023394130};\\\", \\\"{x:1147,y:527,t:1527023394148};\\\", \\\"{x:1155,y:527,t:1527023394164};\\\", \\\"{x:1169,y:527,t:1527023394182};\\\", \\\"{x:1173,y:527,t:1527023394197};\\\", \\\"{x:1182,y:525,t:1527023394214};\\\", \\\"{x:1194,y:525,t:1527023394231};\\\", \\\"{x:1208,y:525,t:1527023394248};\\\", \\\"{x:1224,y:525,t:1527023394265};\\\", \\\"{x:1241,y:525,t:1527023394280};\\\", \\\"{x:1268,y:525,t:1527023394297};\\\", \\\"{x:1296,y:523,t:1527023394314};\\\", \\\"{x:1325,y:518,t:1527023394331};\\\", \\\"{x:1355,y:516,t:1527023394348};\\\", \\\"{x:1384,y:506,t:1527023394364};\\\", \\\"{x:1434,y:486,t:1527023394382};\\\", \\\"{x:1463,y:473,t:1527023394398};\\\", \\\"{x:1481,y:463,t:1527023394414};\\\", \\\"{x:1496,y:453,t:1527023394431};\\\", \\\"{x:1503,y:444,t:1527023394447};\\\", \\\"{x:1505,y:442,t:1527023394464};\\\", \\\"{x:1503,y:442,t:1527023395042};\\\", \\\"{x:1502,y:442,t:1527023395065};\\\", \\\"{x:1500,y:442,t:1527023395097};\\\", \\\"{x:1499,y:442,t:1527023395113};\\\", \\\"{x:1496,y:442,t:1527023395129};\\\", \\\"{x:1493,y:441,t:1527023395147};\\\", \\\"{x:1492,y:440,t:1527023395153};\\\", \\\"{x:1489,y:439,t:1527023395169};\\\", \\\"{x:1487,y:439,t:1527023395185};\\\", \\\"{x:1485,y:438,t:1527023395201};\\\", \\\"{x:1480,y:437,t:1527023395218};\\\", \\\"{x:1479,y:436,t:1527023395235};\\\", \\\"{x:1478,y:436,t:1527023395252};\\\", \\\"{x:1477,y:436,t:1527023395313};\\\", \\\"{x:1476,y:436,t:1527023395321};\\\", \\\"{x:1474,y:437,t:1527023395335};\\\", \\\"{x:1472,y:441,t:1527023395351};\\\", \\\"{x:1462,y:464,t:1527023395368};\\\", \\\"{x:1456,y:483,t:1527023395384};\\\", \\\"{x:1451,y:502,t:1527023395401};\\\", \\\"{x:1449,y:520,t:1527023395418};\\\", \\\"{x:1448,y:534,t:1527023395435};\\\", \\\"{x:1448,y:536,t:1527023395451};\\\", \\\"{x:1448,y:549,t:1527023395468};\\\", \\\"{x:1448,y:562,t:1527023395485};\\\", \\\"{x:1451,y:574,t:1527023395501};\\\", \\\"{x:1453,y:582,t:1527023395519};\\\", \\\"{x:1456,y:587,t:1527023395535};\\\", \\\"{x:1456,y:590,t:1527023395552};\\\", \\\"{x:1456,y:597,t:1527023395568};\\\", \\\"{x:1456,y:599,t:1527023395586};\\\", \\\"{x:1456,y:600,t:1527023395601};\\\", \\\"{x:1456,y:601,t:1527023395633};\\\", \\\"{x:1456,y:602,t:1527023396202};\\\", \\\"{x:1456,y:603,t:1527023396249};\\\", \\\"{x:1456,y:605,t:1527023396257};\\\", \\\"{x:1456,y:606,t:1527023396270};\\\", \\\"{x:1456,y:607,t:1527023396286};\\\", \\\"{x:1456,y:609,t:1527023396305};\\\", \\\"{x:1457,y:609,t:1527023396354};\\\", \\\"{x:1458,y:609,t:1527023396377};\\\", \\\"{x:1458,y:610,t:1527023396386};\\\", \\\"{x:1460,y:610,t:1527023396402};\\\", \\\"{x:1462,y:611,t:1527023396420};\\\", \\\"{x:1464,y:611,t:1527023396437};\\\", \\\"{x:1468,y:613,t:1527023396452};\\\", \\\"{x:1471,y:613,t:1527023396469};\\\", \\\"{x:1474,y:614,t:1527023396486};\\\", \\\"{x:1476,y:614,t:1527023396503};\\\", \\\"{x:1478,y:614,t:1527023396519};\\\", \\\"{x:1480,y:616,t:1527023396536};\\\", \\\"{x:1478,y:615,t:1527023397122};\\\", \\\"{x:1476,y:615,t:1527023397137};\\\", \\\"{x:1473,y:615,t:1527023397154};\\\", \\\"{x:1471,y:613,t:1527023397170};\\\", \\\"{x:1469,y:613,t:1527023397187};\\\", \\\"{x:1466,y:613,t:1527023397204};\\\", \\\"{x:1463,y:613,t:1527023397221};\\\", \\\"{x:1460,y:613,t:1527023397237};\\\", \\\"{x:1459,y:613,t:1527023397254};\\\", \\\"{x:1457,y:613,t:1527023397271};\\\", \\\"{x:1453,y:613,t:1527023397287};\\\", \\\"{x:1452,y:613,t:1527023397304};\\\", \\\"{x:1447,y:613,t:1527023397321};\\\", \\\"{x:1438,y:613,t:1527023397337};\\\", \\\"{x:1430,y:616,t:1527023397353};\\\", \\\"{x:1421,y:619,t:1527023397371};\\\", \\\"{x:1413,y:622,t:1527023397386};\\\", \\\"{x:1402,y:627,t:1527023397404};\\\", \\\"{x:1389,y:632,t:1527023397421};\\\", \\\"{x:1372,y:640,t:1527023397437};\\\", \\\"{x:1350,y:650,t:1527023397453};\\\", \\\"{x:1326,y:660,t:1527023397471};\\\", \\\"{x:1302,y:673,t:1527023397487};\\\", \\\"{x:1279,y:686,t:1527023397504};\\\", \\\"{x:1250,y:708,t:1527023397521};\\\", \\\"{x:1232,y:724,t:1527023397537};\\\", \\\"{x:1219,y:741,t:1527023397554};\\\", \\\"{x:1209,y:754,t:1527023397571};\\\", \\\"{x:1202,y:764,t:1527023397588};\\\", \\\"{x:1197,y:773,t:1527023397604};\\\", \\\"{x:1191,y:782,t:1527023397621};\\\", \\\"{x:1189,y:788,t:1527023397638};\\\", \\\"{x:1185,y:795,t:1527023397654};\\\", \\\"{x:1183,y:801,t:1527023397670};\\\", \\\"{x:1182,y:804,t:1527023397688};\\\", \\\"{x:1181,y:808,t:1527023397704};\\\", \\\"{x:1181,y:815,t:1527023397720};\\\", \\\"{x:1181,y:818,t:1527023397737};\\\", \\\"{x:1180,y:818,t:1527023397753};\\\", \\\"{x:1179,y:818,t:1527023397770};\\\", \\\"{x:1183,y:816,t:1527023398106};\\\", \\\"{x:1192,y:811,t:1527023398121};\\\", \\\"{x:1197,y:804,t:1527023398138};\\\", \\\"{x:1202,y:798,t:1527023398155};\\\", \\\"{x:1206,y:792,t:1527023398171};\\\", \\\"{x:1207,y:788,t:1527023398188};\\\", \\\"{x:1211,y:783,t:1527023398205};\\\", \\\"{x:1212,y:778,t:1527023398224};\\\", \\\"{x:1214,y:776,t:1527023398237};\\\", \\\"{x:1214,y:774,t:1527023398254};\\\", \\\"{x:1214,y:773,t:1527023398271};\\\", \\\"{x:1214,y:775,t:1527023398521};\\\", \\\"{x:1213,y:783,t:1527023398539};\\\", \\\"{x:1208,y:797,t:1527023398555};\\\", \\\"{x:1202,y:813,t:1527023398572};\\\", \\\"{x:1194,y:833,t:1527023398588};\\\", \\\"{x:1185,y:848,t:1527023398605};\\\", \\\"{x:1180,y:859,t:1527023398622};\\\", \\\"{x:1177,y:863,t:1527023398637};\\\", \\\"{x:1176,y:867,t:1527023398655};\\\", \\\"{x:1175,y:871,t:1527023398671};\\\", \\\"{x:1174,y:874,t:1527023398688};\\\", \\\"{x:1174,y:877,t:1527023398705};\\\", \\\"{x:1173,y:879,t:1527023398721};\\\", \\\"{x:1173,y:881,t:1527023398739};\\\", \\\"{x:1172,y:882,t:1527023398760};\\\", \\\"{x:1171,y:884,t:1527023398874};\\\", \\\"{x:1170,y:884,t:1527023398889};\\\", \\\"{x:1169,y:885,t:1527023398905};\\\", \\\"{x:1166,y:887,t:1527023398922};\\\", \\\"{x:1164,y:887,t:1527023398939};\\\", \\\"{x:1162,y:890,t:1527023398955};\\\", \\\"{x:1160,y:891,t:1527023398971};\\\", \\\"{x:1159,y:892,t:1527023399001};\\\", \\\"{x:1159,y:890,t:1527023399106};\\\", \\\"{x:1161,y:879,t:1527023399122};\\\", \\\"{x:1167,y:864,t:1527023399139};\\\", \\\"{x:1176,y:842,t:1527023399155};\\\", \\\"{x:1187,y:820,t:1527023399172};\\\", \\\"{x:1196,y:798,t:1527023399189};\\\", \\\"{x:1202,y:782,t:1527023399206};\\\", \\\"{x:1206,y:771,t:1527023399222};\\\", \\\"{x:1208,y:763,t:1527023399238};\\\", \\\"{x:1209,y:758,t:1527023399256};\\\", \\\"{x:1210,y:753,t:1527023399271};\\\", \\\"{x:1211,y:751,t:1527023399289};\\\", \\\"{x:1211,y:750,t:1527023399367};\\\", \\\"{x:1213,y:750,t:1527023399376};\\\", \\\"{x:1214,y:753,t:1527023399388};\\\", \\\"{x:1220,y:766,t:1527023399405};\\\", \\\"{x:1225,y:778,t:1527023399421};\\\", \\\"{x:1230,y:788,t:1527023399438};\\\", \\\"{x:1235,y:796,t:1527023399455};\\\", \\\"{x:1239,y:804,t:1527023399472};\\\", \\\"{x:1246,y:819,t:1527023399488};\\\", \\\"{x:1249,y:826,t:1527023399506};\\\", \\\"{x:1251,y:832,t:1527023399522};\\\", \\\"{x:1254,y:838,t:1527023399538};\\\", \\\"{x:1257,y:844,t:1527023399555};\\\", \\\"{x:1260,y:855,t:1527023399573};\\\", \\\"{x:1263,y:861,t:1527023399589};\\\", \\\"{x:1264,y:865,t:1527023399605};\\\", \\\"{x:1266,y:868,t:1527023399622};\\\", \\\"{x:1267,y:873,t:1527023399638};\\\", \\\"{x:1269,y:877,t:1527023399656};\\\", \\\"{x:1272,y:884,t:1527023399673};\\\", \\\"{x:1274,y:888,t:1527023399689};\\\", \\\"{x:1275,y:889,t:1527023399705};\\\", \\\"{x:1275,y:890,t:1527023399723};\\\", \\\"{x:1275,y:891,t:1527023399738};\\\", \\\"{x:1276,y:893,t:1527023399760};\\\", \\\"{x:1276,y:895,t:1527023399785};\\\", \\\"{x:1276,y:896,t:1527023399792};\\\", \\\"{x:1277,y:897,t:1527023399806};\\\", \\\"{x:1278,y:898,t:1527023399822};\\\", \\\"{x:1278,y:899,t:1527023399839};\\\", \\\"{x:1279,y:901,t:1527023399856};\\\", \\\"{x:1279,y:904,t:1527023399873};\\\", \\\"{x:1279,y:905,t:1527023399890};\\\", \\\"{x:1281,y:908,t:1527023399907};\\\", \\\"{x:1281,y:910,t:1527023399923};\\\", \\\"{x:1282,y:911,t:1527023399940};\\\", \\\"{x:1283,y:912,t:1527023400650};\\\", \\\"{x:1284,y:912,t:1527023400665};\\\", \\\"{x:1285,y:911,t:1527023400681};\\\", \\\"{x:1285,y:910,t:1527023400690};\\\", \\\"{x:1286,y:909,t:1527023400707};\\\", \\\"{x:1286,y:908,t:1527023400729};\\\", \\\"{x:1287,y:907,t:1527023400753};\\\", \\\"{x:1288,y:907,t:1527023400858};\\\", \\\"{x:1287,y:907,t:1527023401153};\\\", \\\"{x:1286,y:907,t:1527023401186};\\\", \\\"{x:1284,y:907,t:1527023401193};\\\", \\\"{x:1284,y:908,t:1527023401216};\\\", \\\"{x:1283,y:908,t:1527023401256};\\\", \\\"{x:1282,y:908,t:1527023401385};\\\", \\\"{x:1282,y:909,t:1527023401409};\\\", \\\"{x:1281,y:910,t:1527023401433};\\\", \\\"{x:1281,y:911,t:1527023401465};\\\", \\\"{x:1280,y:911,t:1527023401858};\\\", \\\"{x:1280,y:910,t:1527023401881};\\\", \\\"{x:1280,y:909,t:1527023401913};\\\", \\\"{x:1280,y:908,t:1527023401924};\\\", \\\"{x:1281,y:907,t:1527023401953};\\\", \\\"{x:1282,y:906,t:1527023402034};\\\", \\\"{x:1284,y:906,t:1527023402049};\\\", \\\"{x:1285,y:905,t:1527023402073};\\\", \\\"{x:1285,y:904,t:1527023402081};\\\", \\\"{x:1285,y:902,t:1527023402091};\\\", \\\"{x:1287,y:900,t:1527023402109};\\\", \\\"{x:1288,y:898,t:1527023402125};\\\", \\\"{x:1289,y:898,t:1527023402142};\\\", \\\"{x:1289,y:897,t:1527023402158};\\\", \\\"{x:1289,y:896,t:1527023402175};\\\", \\\"{x:1291,y:893,t:1527023402192};\\\", \\\"{x:1291,y:892,t:1527023402208};\\\", \\\"{x:1292,y:889,t:1527023402225};\\\", \\\"{x:1294,y:884,t:1527023402241};\\\", \\\"{x:1296,y:881,t:1527023402258};\\\", \\\"{x:1297,y:875,t:1527023402275};\\\", \\\"{x:1299,y:871,t:1527023402292};\\\", \\\"{x:1300,y:865,t:1527023402308};\\\", \\\"{x:1303,y:858,t:1527023402326};\\\", \\\"{x:1305,y:850,t:1527023402342};\\\", \\\"{x:1307,y:841,t:1527023402358};\\\", \\\"{x:1309,y:835,t:1527023402376};\\\", \\\"{x:1313,y:826,t:1527023402392};\\\", \\\"{x:1313,y:817,t:1527023402408};\\\", \\\"{x:1318,y:801,t:1527023402425};\\\", \\\"{x:1323,y:788,t:1527023402442};\\\", \\\"{x:1328,y:774,t:1527023402458};\\\", \\\"{x:1334,y:761,t:1527023402475};\\\", \\\"{x:1337,y:751,t:1527023402492};\\\", \\\"{x:1342,y:741,t:1527023402508};\\\", \\\"{x:1346,y:734,t:1527023402525};\\\", \\\"{x:1349,y:725,t:1527023402542};\\\", \\\"{x:1355,y:712,t:1527023402559};\\\", \\\"{x:1358,y:699,t:1527023402575};\\\", \\\"{x:1363,y:686,t:1527023402592};\\\", \\\"{x:1366,y:678,t:1527023402609};\\\", \\\"{x:1369,y:669,t:1527023402624};\\\", \\\"{x:1370,y:664,t:1527023402642};\\\", \\\"{x:1372,y:662,t:1527023402659};\\\", \\\"{x:1372,y:661,t:1527023402697};\\\", \\\"{x:1372,y:662,t:1527023403097};\\\", \\\"{x:1372,y:666,t:1527023403109};\\\", \\\"{x:1371,y:672,t:1527023403126};\\\", \\\"{x:1367,y:678,t:1527023403142};\\\", \\\"{x:1365,y:685,t:1527023403159};\\\", \\\"{x:1364,y:690,t:1527023403176};\\\", \\\"{x:1363,y:694,t:1527023403192};\\\", \\\"{x:1360,y:703,t:1527023403209};\\\", \\\"{x:1357,y:708,t:1527023403226};\\\", \\\"{x:1357,y:712,t:1527023403242};\\\", \\\"{x:1356,y:713,t:1527023403259};\\\", \\\"{x:1355,y:718,t:1527023403276};\\\", \\\"{x:1353,y:720,t:1527023403292};\\\", \\\"{x:1351,y:724,t:1527023403309};\\\", \\\"{x:1349,y:730,t:1527023403326};\\\", \\\"{x:1349,y:735,t:1527023403343};\\\", \\\"{x:1348,y:741,t:1527023403359};\\\", \\\"{x:1346,y:750,t:1527023403376};\\\", \\\"{x:1344,y:759,t:1527023403393};\\\", \\\"{x:1344,y:765,t:1527023403409};\\\", \\\"{x:1344,y:769,t:1527023403426};\\\", \\\"{x:1344,y:770,t:1527023403443};\\\", \\\"{x:1343,y:771,t:1527023403473};\\\", \\\"{x:1344,y:771,t:1527023403561};\\\", \\\"{x:1345,y:770,t:1527023403576};\\\", \\\"{x:1346,y:769,t:1527023403593};\\\", \\\"{x:1347,y:769,t:1527023403609};\\\", \\\"{x:1347,y:767,t:1527023403626};\\\", \\\"{x:1348,y:766,t:1527023403643};\\\", \\\"{x:1349,y:764,t:1527023403659};\\\", \\\"{x:1350,y:763,t:1527023403676};\\\", \\\"{x:1351,y:760,t:1527023403694};\\\", \\\"{x:1352,y:758,t:1527023403709};\\\", \\\"{x:1353,y:756,t:1527023403726};\\\", \\\"{x:1355,y:752,t:1527023403743};\\\", \\\"{x:1356,y:750,t:1527023403760};\\\", \\\"{x:1357,y:746,t:1527023403776};\\\", \\\"{x:1360,y:743,t:1527023403793};\\\", \\\"{x:1361,y:742,t:1527023403811};\\\", \\\"{x:1362,y:740,t:1527023403827};\\\", \\\"{x:1363,y:739,t:1527023403843};\\\", \\\"{x:1363,y:737,t:1527023403860};\\\", \\\"{x:1365,y:735,t:1527023403876};\\\", \\\"{x:1366,y:734,t:1527023403897};\\\", \\\"{x:1367,y:732,t:1527023403912};\\\", \\\"{x:1368,y:731,t:1527023403929};\\\", \\\"{x:1369,y:730,t:1527023403961};\\\", \\\"{x:1369,y:728,t:1527023404009};\\\", \\\"{x:1369,y:727,t:1527023404041};\\\", \\\"{x:1370,y:727,t:1527023404049};\\\", \\\"{x:1370,y:726,t:1527023404065};\\\", \\\"{x:1371,y:726,t:1527023404081};\\\", \\\"{x:1371,y:725,t:1527023404097};\\\", \\\"{x:1371,y:724,t:1527023404110};\\\", \\\"{x:1372,y:724,t:1527023404128};\\\", \\\"{x:1373,y:723,t:1527023404143};\\\", \\\"{x:1374,y:722,t:1527023404177};\\\", \\\"{x:1374,y:721,t:1527023404209};\\\", \\\"{x:1375,y:720,t:1527023404233};\\\", \\\"{x:1375,y:718,t:1527023404456};\\\", \\\"{x:1376,y:716,t:1527023404464};\\\", \\\"{x:1377,y:714,t:1527023404477};\\\", \\\"{x:1378,y:713,t:1527023404493};\\\", \\\"{x:1378,y:711,t:1527023404510};\\\", \\\"{x:1378,y:710,t:1527023404527};\\\", \\\"{x:1380,y:707,t:1527023404543};\\\", \\\"{x:1380,y:706,t:1527023404569};\\\", \\\"{x:1381,y:706,t:1527023404577};\\\", \\\"{x:1381,y:707,t:1527023405177};\\\", \\\"{x:1383,y:713,t:1527023405194};\\\", \\\"{x:1385,y:719,t:1527023405211};\\\", \\\"{x:1388,y:726,t:1527023405228};\\\", \\\"{x:1392,y:734,t:1527023405244};\\\", \\\"{x:1394,y:737,t:1527023405261};\\\", \\\"{x:1396,y:743,t:1527023405278};\\\", \\\"{x:1397,y:748,t:1527023405294};\\\", \\\"{x:1401,y:754,t:1527023405311};\\\", \\\"{x:1406,y:765,t:1527023405329};\\\", \\\"{x:1408,y:770,t:1527023405345};\\\", \\\"{x:1410,y:776,t:1527023405361};\\\", \\\"{x:1412,y:779,t:1527023405378};\\\", \\\"{x:1414,y:783,t:1527023405394};\\\", \\\"{x:1417,y:786,t:1527023405411};\\\", \\\"{x:1421,y:793,t:1527023405429};\\\", \\\"{x:1426,y:802,t:1527023405444};\\\", \\\"{x:1430,y:809,t:1527023405461};\\\", \\\"{x:1433,y:813,t:1527023405478};\\\", \\\"{x:1438,y:818,t:1527023405495};\\\", \\\"{x:1439,y:821,t:1527023405511};\\\", \\\"{x:1443,y:830,t:1527023405529};\\\", \\\"{x:1446,y:839,t:1527023405545};\\\", \\\"{x:1450,y:849,t:1527023405560};\\\", \\\"{x:1454,y:856,t:1527023405578};\\\", \\\"{x:1456,y:861,t:1527023405594};\\\", \\\"{x:1458,y:866,t:1527023405611};\\\", \\\"{x:1460,y:871,t:1527023405628};\\\", \\\"{x:1463,y:877,t:1527023405645};\\\", \\\"{x:1466,y:885,t:1527023405660};\\\", \\\"{x:1468,y:889,t:1527023405678};\\\", \\\"{x:1470,y:894,t:1527023405694};\\\", \\\"{x:1472,y:897,t:1527023405711};\\\", \\\"{x:1475,y:905,t:1527023405728};\\\", \\\"{x:1476,y:908,t:1527023405744};\\\", \\\"{x:1478,y:911,t:1527023405761};\\\", \\\"{x:1479,y:912,t:1527023405777};\\\", \\\"{x:1479,y:913,t:1527023405794};\\\", \\\"{x:1478,y:911,t:1527023406073};\\\", \\\"{x:1476,y:908,t:1527023406081};\\\", \\\"{x:1472,y:904,t:1527023406095};\\\", \\\"{x:1459,y:895,t:1527023406113};\\\", \\\"{x:1436,y:887,t:1527023406129};\\\", \\\"{x:1404,y:884,t:1527023406145};\\\", \\\"{x:1348,y:876,t:1527023406162};\\\", \\\"{x:1286,y:870,t:1527023406178};\\\", \\\"{x:1227,y:870,t:1527023406195};\\\", \\\"{x:1174,y:870,t:1527023406212};\\\", \\\"{x:1143,y:870,t:1527023406227};\\\", \\\"{x:1118,y:874,t:1527023406244};\\\", \\\"{x:1091,y:886,t:1527023406262};\\\", \\\"{x:1062,y:901,t:1527023406278};\\\", \\\"{x:1038,y:914,t:1527023406295};\\\", \\\"{x:1022,y:925,t:1527023406312};\\\", \\\"{x:1021,y:926,t:1527023406328};\\\", \\\"{x:1018,y:926,t:1527023406737};\\\", \\\"{x:1008,y:924,t:1527023406746};\\\", \\\"{x:1007,y:924,t:1527023406763};\\\", \\\"{x:998,y:922,t:1527023406779};\\\", \\\"{x:991,y:922,t:1527023406796};\\\", \\\"{x:981,y:922,t:1527023406812};\\\", \\\"{x:970,y:922,t:1527023406829};\\\", \\\"{x:964,y:922,t:1527023406846};\\\", \\\"{x:958,y:922,t:1527023406862};\\\", \\\"{x:950,y:923,t:1527023406878};\\\", \\\"{x:943,y:924,t:1527023406896};\\\", \\\"{x:936,y:925,t:1527023406912};\\\", \\\"{x:928,y:925,t:1527023406929};\\\", \\\"{x:922,y:926,t:1527023406946};\\\", \\\"{x:912,y:926,t:1527023406962};\\\", \\\"{x:907,y:926,t:1527023406979};\\\", \\\"{x:902,y:924,t:1527023406996};\\\", \\\"{x:900,y:923,t:1527023407012};\\\", \\\"{x:896,y:921,t:1527023407029};\\\", \\\"{x:894,y:919,t:1527023407046};\\\", \\\"{x:893,y:918,t:1527023407062};\\\", \\\"{x:892,y:917,t:1527023407079};\\\", \\\"{x:891,y:916,t:1527023407096};\\\", \\\"{x:890,y:915,t:1527023407153};\\\", \\\"{x:890,y:914,t:1527023407721};\\\", \\\"{x:887,y:914,t:1527023407817};\\\", \\\"{x:886,y:914,t:1527023407841};\\\", \\\"{x:884,y:914,t:1527023407848};\\\", \\\"{x:883,y:914,t:1527023407864};\\\", \\\"{x:881,y:914,t:1527023407881};\\\", \\\"{x:880,y:914,t:1527023407896};\\\", \\\"{x:878,y:914,t:1527023407913};\\\", \\\"{x:876,y:914,t:1527023407930};\\\", \\\"{x:873,y:914,t:1527023407947};\\\", \\\"{x:870,y:914,t:1527023407963};\\\", \\\"{x:869,y:914,t:1527023407980};\\\", \\\"{x:867,y:914,t:1527023407997};\\\", \\\"{x:865,y:914,t:1527023408013};\\\", \\\"{x:861,y:914,t:1527023408030};\\\", \\\"{x:858,y:914,t:1527023408047};\\\", \\\"{x:857,y:914,t:1527023408063};\\\", \\\"{x:855,y:914,t:1527023408080};\\\", \\\"{x:854,y:914,t:1527023408098};\\\", \\\"{x:853,y:913,t:1527023408113};\\\", \\\"{x:852,y:913,t:1527023408131};\\\", \\\"{x:851,y:913,t:1527023408147};\\\", \\\"{x:849,y:913,t:1527023408163};\\\", \\\"{x:847,y:914,t:1527023408180};\\\", \\\"{x:845,y:914,t:1527023408197};\\\", \\\"{x:843,y:915,t:1527023408213};\\\", \\\"{x:839,y:915,t:1527023408230};\\\", \\\"{x:837,y:915,t:1527023408247};\\\", \\\"{x:832,y:915,t:1527023408265};\\\", \\\"{x:829,y:915,t:1527023408280};\\\", \\\"{x:813,y:914,t:1527023408297};\\\", \\\"{x:794,y:908,t:1527023408314};\\\", \\\"{x:764,y:893,t:1527023408330};\\\", \\\"{x:719,y:863,t:1527023408347};\\\", \\\"{x:644,y:794,t:1527023408364};\\\", \\\"{x:555,y:694,t:1527023408380};\\\", \\\"{x:461,y:611,t:1527023408397};\\\", \\\"{x:372,y:546,t:1527023408415};\\\", \\\"{x:295,y:502,t:1527023408432};\\\", \\\"{x:223,y:469,t:1527023408464};\\\", \\\"{x:223,y:470,t:1527023408552};\\\", \\\"{x:223,y:472,t:1527023408562};\\\", \\\"{x:224,y:476,t:1527023408579};\\\", \\\"{x:227,y:481,t:1527023408596};\\\", \\\"{x:234,y:490,t:1527023408613};\\\", \\\"{x:245,y:501,t:1527023408629};\\\", \\\"{x:258,y:514,t:1527023408646};\\\", \\\"{x:273,y:526,t:1527023408662};\\\", \\\"{x:289,y:539,t:1527023408680};\\\", \\\"{x:314,y:556,t:1527023408695};\\\", \\\"{x:326,y:565,t:1527023408712};\\\", \\\"{x:336,y:573,t:1527023408729};\\\", \\\"{x:343,y:576,t:1527023408746};\\\", \\\"{x:344,y:578,t:1527023408762};\\\", \\\"{x:346,y:579,t:1527023408779};\\\", \\\"{x:347,y:580,t:1527023408796};\\\", \\\"{x:348,y:581,t:1527023408813};\\\", \\\"{x:349,y:582,t:1527023408829};\\\", \\\"{x:352,y:585,t:1527023408846};\\\", \\\"{x:357,y:588,t:1527023408862};\\\", \\\"{x:359,y:589,t:1527023408878};\\\", \\\"{x:365,y:594,t:1527023408896};\\\", \\\"{x:365,y:597,t:1527023408912};\\\", \\\"{x:367,y:599,t:1527023408930};\\\", \\\"{x:367,y:600,t:1527023409456};\\\", \\\"{x:372,y:602,t:1527023409464};\\\", \\\"{x:379,y:602,t:1527023409480};\\\", \\\"{x:383,y:602,t:1527023409497};\\\", \\\"{x:385,y:602,t:1527023409514};\\\", \\\"{x:389,y:603,t:1527023409530};\\\", \\\"{x:392,y:603,t:1527023409546};\\\", \\\"{x:394,y:603,t:1527023409564};\\\", \\\"{x:395,y:603,t:1527023409580};\\\", \\\"{x:396,y:603,t:1527023409597};\\\", \\\"{x:397,y:603,t:1527023409614};\\\", \\\"{x:398,y:603,t:1527023409632};\\\", \\\"{x:399,y:603,t:1527023409647};\\\", \\\"{x:404,y:602,t:1527023409664};\\\", \\\"{x:407,y:602,t:1527023409680};\\\", \\\"{x:409,y:601,t:1527023409697};\\\", \\\"{x:411,y:600,t:1527023409714};\\\", \\\"{x:413,y:598,t:1527023409731};\\\", \\\"{x:416,y:597,t:1527023409752};\\\", \\\"{x:417,y:596,t:1527023409824};\\\", \\\"{x:417,y:595,t:1527023409831};\\\", \\\"{x:415,y:591,t:1527023409846};\\\", \\\"{x:407,y:586,t:1527023409864};\\\", \\\"{x:400,y:582,t:1527023409879};\\\", \\\"{x:394,y:578,t:1527023409896};\\\", \\\"{x:388,y:574,t:1527023409913};\\\", \\\"{x:378,y:567,t:1527023409930};\\\", \\\"{x:366,y:561,t:1527023409947};\\\", \\\"{x:352,y:553,t:1527023409963};\\\", \\\"{x:337,y:549,t:1527023409979};\\\", \\\"{x:320,y:544,t:1527023409996};\\\", \\\"{x:303,y:539,t:1527023410014};\\\", \\\"{x:289,y:536,t:1527023410029};\\\", \\\"{x:272,y:531,t:1527023410047};\\\", \\\"{x:245,y:527,t:1527023410064};\\\", \\\"{x:232,y:522,t:1527023410080};\\\", \\\"{x:221,y:521,t:1527023410097};\\\", \\\"{x:212,y:520,t:1527023410113};\\\", \\\"{x:207,y:519,t:1527023410129};\\\", \\\"{x:208,y:518,t:1527023410201};\\\", \\\"{x:209,y:518,t:1527023410214};\\\", \\\"{x:224,y:517,t:1527023410230};\\\", \\\"{x:247,y:517,t:1527023410246};\\\", \\\"{x:310,y:517,t:1527023410266};\\\", \\\"{x:362,y:513,t:1527023410280};\\\", \\\"{x:417,y:513,t:1527023410296};\\\", \\\"{x:451,y:513,t:1527023410314};\\\", \\\"{x:467,y:513,t:1527023410330};\\\", \\\"{x:471,y:513,t:1527023410347};\\\", \\\"{x:470,y:513,t:1527023410440};\\\", \\\"{x:466,y:513,t:1527023410448};\\\", \\\"{x:456,y:513,t:1527023410464};\\\", \\\"{x:441,y:513,t:1527023410481};\\\", \\\"{x:426,y:513,t:1527023410497};\\\", \\\"{x:414,y:513,t:1527023410515};\\\", \\\"{x:407,y:513,t:1527023410531};\\\", \\\"{x:400,y:513,t:1527023410547};\\\", \\\"{x:394,y:513,t:1527023410564};\\\", \\\"{x:389,y:513,t:1527023410580};\\\", \\\"{x:387,y:513,t:1527023410596};\\\", \\\"{x:386,y:513,t:1527023410614};\\\", \\\"{x:385,y:513,t:1527023410631};\\\", \\\"{x:383,y:513,t:1527023410647};\\\", \\\"{x:382,y:513,t:1527023410663};\\\", \\\"{x:381,y:516,t:1527023410952};\\\", \\\"{x:386,y:524,t:1527023410964};\\\", \\\"{x:403,y:549,t:1527023410981};\\\", \\\"{x:420,y:566,t:1527023410998};\\\", \\\"{x:438,y:584,t:1527023411014};\\\", \\\"{x:454,y:596,t:1527023411031};\\\", \\\"{x:471,y:610,t:1527023411048};\\\", \\\"{x:482,y:620,t:1527023411064};\\\", \\\"{x:493,y:628,t:1527023411080};\\\", \\\"{x:503,y:638,t:1527023411098};\\\", \\\"{x:511,y:647,t:1527023411114};\\\", \\\"{x:515,y:651,t:1527023411131};\\\", \\\"{x:516,y:652,t:1527023411148};\\\", \\\"{x:518,y:653,t:1527023411164};\\\", \\\"{x:518,y:654,t:1527023411181};\\\", \\\"{x:518,y:655,t:1527023411198};\\\", \\\"{x:519,y:657,t:1527023411214};\\\", \\\"{x:521,y:660,t:1527023411231};\\\", \\\"{x:522,y:664,t:1527023411248};\\\", \\\"{x:523,y:665,t:1527023411265};\\\", \\\"{x:523,y:666,t:1527023411281};\\\", \\\"{x:524,y:667,t:1527023412929};\\\", \\\"{x:527,y:667,t:1527023412936};\\\", \\\"{x:529,y:667,t:1527023412949};\\\", \\\"{x:532,y:665,t:1527023412966};\\\", \\\"{x:534,y:663,t:1527023412982};\\\", \\\"{x:536,y:662,t:1527023412999};\\\", \\\"{x:537,y:662,t:1527023413016};\\\", \\\"{x:538,y:661,t:1527023413033};\\\", \\\"{x:539,y:661,t:1527023413056};\\\", \\\"{x:539,y:660,t:1527023413073};\\\", \\\"{x:540,y:660,t:1527023413083};\\\", \\\"{x:541,y:659,t:1527023413099};\\\", \\\"{x:543,y:659,t:1527023413120};\\\", \\\"{x:544,y:659,t:1527023413136};\\\", \\\"{x:547,y:659,t:1527023413149};\\\", \\\"{x:555,y:659,t:1527023413166};\\\", \\\"{x:566,y:659,t:1527023413183};\\\", \\\"{x:578,y:659,t:1527023413199};\\\", \\\"{x:597,y:655,t:1527023413217};\\\", \\\"{x:617,y:647,t:1527023413246};\\\", \\\"{x:618,y:646,t:1527023413249};\\\", \\\"{x:619,y:646,t:1527023413266};\\\" ] }, { \\\"rt\\\": 16273, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 8, \\\"time_elapsed\\\": 514855, \\\"internal_node_id\\\": \\\"0.0-5.0-3.0\\\", \\\"subject\\\": \\\"QOJ6L\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"hotel\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 4, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"H\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-09 AM\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:619,y:644,t:1527023414008};\\\", \\\"{x:619,y:641,t:1527023414017};\\\", \\\"{x:618,y:639,t:1527023414033};\\\", \\\"{x:615,y:630,t:1527023414050};\\\", \\\"{x:611,y:615,t:1527023414067};\\\", \\\"{x:606,y:595,t:1527023414084};\\\", \\\"{x:598,y:571,t:1527023414100};\\\", \\\"{x:595,y:547,t:1527023414116};\\\", \\\"{x:591,y:525,t:1527023414133};\\\", \\\"{x:589,y:506,t:1527023414150};\\\", \\\"{x:587,y:492,t:1527023414167};\\\", \\\"{x:585,y:480,t:1527023414184};\\\", \\\"{x:582,y:471,t:1527023414200};\\\", \\\"{x:581,y:469,t:1527023414217};\\\", \\\"{x:581,y:472,t:1527023414521};\\\", \\\"{x:585,y:478,t:1527023414534};\\\", \\\"{x:595,y:492,t:1527023414552};\\\", \\\"{x:610,y:505,t:1527023414568};\\\", \\\"{x:645,y:512,t:1527023414584};\\\", \\\"{x:674,y:516,t:1527023414600};\\\", \\\"{x:705,y:521,t:1527023414617};\\\", \\\"{x:735,y:522,t:1527023414634};\\\", \\\"{x:751,y:522,t:1527023414650};\\\", \\\"{x:755,y:522,t:1527023414667};\\\", \\\"{x:756,y:522,t:1527023415089};\\\", \\\"{x:757,y:522,t:1527023415103};\\\", \\\"{x:762,y:526,t:1527023415119};\\\", \\\"{x:769,y:531,t:1527023415137};\\\", \\\"{x:784,y:546,t:1527023415152};\\\", \\\"{x:798,y:559,t:1527023415168};\\\", \\\"{x:822,y:577,t:1527023415185};\\\", \\\"{x:862,y:600,t:1527023415201};\\\", \\\"{x:918,y:629,t:1527023415218};\\\", \\\"{x:981,y:651,t:1527023415235};\\\", \\\"{x:1078,y:681,t:1527023415252};\\\", \\\"{x:1181,y:711,t:1527023415268};\\\", \\\"{x:1280,y:737,t:1527023415284};\\\", \\\"{x:1355,y:746,t:1527023415301};\\\", \\\"{x:1401,y:749,t:1527023415319};\\\", \\\"{x:1425,y:749,t:1527023415335};\\\", \\\"{x:1446,y:751,t:1527023415351};\\\", \\\"{x:1466,y:752,t:1527023415368};\\\", \\\"{x:1472,y:753,t:1527023415384};\\\", \\\"{x:1473,y:753,t:1527023415408};\\\", \\\"{x:1473,y:754,t:1527023415745};\\\", \\\"{x:1475,y:757,t:1527023415760};\\\", \\\"{x:1475,y:758,t:1527023415769};\\\", \\\"{x:1475,y:760,t:1527023415786};\\\", \\\"{x:1477,y:764,t:1527023415802};\\\", \\\"{x:1477,y:765,t:1527023415819};\\\", \\\"{x:1478,y:766,t:1527023415836};\\\", \\\"{x:1480,y:770,t:1527023415851};\\\", \\\"{x:1483,y:773,t:1527023415869};\\\", \\\"{x:1490,y:781,t:1527023415886};\\\", \\\"{x:1499,y:792,t:1527023415902};\\\", \\\"{x:1514,y:805,t:1527023415919};\\\", \\\"{x:1529,y:817,t:1527023415936};\\\", \\\"{x:1543,y:827,t:1527023415952};\\\", \\\"{x:1563,y:841,t:1527023415969};\\\", \\\"{x:1579,y:852,t:1527023415985};\\\", \\\"{x:1590,y:861,t:1527023416002};\\\", \\\"{x:1602,y:870,t:1527023416019};\\\", \\\"{x:1608,y:879,t:1527023416036};\\\", \\\"{x:1613,y:885,t:1527023416053};\\\", \\\"{x:1616,y:889,t:1527023416069};\\\", \\\"{x:1618,y:893,t:1527023416085};\\\", \\\"{x:1618,y:894,t:1527023416103};\\\", \\\"{x:1619,y:896,t:1527023416118};\\\", \\\"{x:1619,y:899,t:1527023416136};\\\", \\\"{x:1619,y:901,t:1527023416152};\\\", \\\"{x:1619,y:902,t:1527023416185};\\\", \\\"{x:1619,y:903,t:1527023416202};\\\", \\\"{x:1619,y:904,t:1527023416219};\\\", \\\"{x:1618,y:906,t:1527023416235};\\\", \\\"{x:1617,y:907,t:1527023416252};\\\", \\\"{x:1617,y:910,t:1527023416269};\\\", \\\"{x:1617,y:912,t:1527023416286};\\\", \\\"{x:1617,y:913,t:1527023416303};\\\", \\\"{x:1617,y:914,t:1527023416319};\\\", \\\"{x:1615,y:915,t:1527023416472};\\\", \\\"{x:1614,y:915,t:1527023416503};\\\", \\\"{x:1613,y:915,t:1527023416519};\\\", \\\"{x:1611,y:915,t:1527023416534};\\\", \\\"{x:1611,y:914,t:1527023416552};\\\", \\\"{x:1609,y:913,t:1527023416569};\\\", \\\"{x:1610,y:913,t:1527023418697};\\\", \\\"{x:1611,y:913,t:1527023418704};\\\", \\\"{x:1614,y:913,t:1527023418720};\\\", \\\"{x:1615,y:913,t:1527023418745};\\\", \\\"{x:1615,y:912,t:1527023419689};\\\", \\\"{x:1605,y:912,t:1527023427353};\\\", \\\"{x:1578,y:912,t:1527023427361};\\\", \\\"{x:1473,y:912,t:1527023427378};\\\", \\\"{x:1323,y:920,t:1527023427394};\\\", \\\"{x:1139,y:929,t:1527023427411};\\\", \\\"{x:942,y:921,t:1527023427429};\\\", \\\"{x:739,y:907,t:1527023427444};\\\", \\\"{x:574,y:887,t:1527023427461};\\\", \\\"{x:438,y:868,t:1527023427478};\\\", \\\"{x:338,y:855,t:1527023427495};\\\", \\\"{x:273,y:843,t:1527023427511};\\\", \\\"{x:188,y:814,t:1527023427528};\\\", \\\"{x:164,y:795,t:1527023427545};\\\", \\\"{x:142,y:761,t:1527023427561};\\\", \\\"{x:124,y:704,t:1527023427578};\\\", \\\"{x:111,y:662,t:1527023427595};\\\", \\\"{x:103,y:633,t:1527023427611};\\\", \\\"{x:102,y:591,t:1527023427629};\\\", \\\"{x:102,y:541,t:1527023427646};\\\", \\\"{x:102,y:512,t:1527023427661};\\\", \\\"{x:116,y:477,t:1527023427695};\\\", \\\"{x:137,y:462,t:1527023427711};\\\", \\\"{x:157,y:457,t:1527023427728};\\\", \\\"{x:183,y:450,t:1527023427744};\\\", \\\"{x:214,y:446,t:1527023427761};\\\", \\\"{x:251,y:446,t:1527023427778};\\\", \\\"{x:279,y:446,t:1527023427794};\\\", \\\"{x:306,y:446,t:1527023427812};\\\", \\\"{x:331,y:446,t:1527023427828};\\\", \\\"{x:350,y:452,t:1527023427845};\\\", \\\"{x:366,y:459,t:1527023427862};\\\", \\\"{x:384,y:474,t:1527023427879};\\\", \\\"{x:412,y:487,t:1527023427895};\\\", \\\"{x:455,y:500,t:1527023427912};\\\", \\\"{x:489,y:511,t:1527023427928};\\\", \\\"{x:528,y:520,t:1527023427945};\\\", \\\"{x:561,y:527,t:1527023427962};\\\", \\\"{x:589,y:533,t:1527023427979};\\\", \\\"{x:606,y:536,t:1527023427994};\\\", \\\"{x:616,y:537,t:1527023428012};\\\", \\\"{x:621,y:537,t:1527023428029};\\\", \\\"{x:623,y:538,t:1527023428044};\\\", \\\"{x:623,y:539,t:1527023428080};\\\", \\\"{x:628,y:539,t:1527023428096};\\\", \\\"{x:634,y:539,t:1527023428112};\\\", \\\"{x:636,y:539,t:1527023428128};\\\", \\\"{x:637,y:538,t:1527023428146};\\\", \\\"{x:638,y:537,t:1527023428217};\\\", \\\"{x:638,y:536,t:1527023428229};\\\", \\\"{x:635,y:532,t:1527023428247};\\\", \\\"{x:632,y:529,t:1527023428264};\\\", \\\"{x:628,y:526,t:1527023428281};\\\", \\\"{x:626,y:523,t:1527023428295};\\\", \\\"{x:623,y:522,t:1527023428311};\\\", \\\"{x:623,y:521,t:1527023428327};\\\", \\\"{x:621,y:520,t:1527023428520};\\\", \\\"{x:618,y:517,t:1527023428530};\\\", \\\"{x:616,y:515,t:1527023428546};\\\", \\\"{x:616,y:518,t:1527023428793};\\\", \\\"{x:616,y:524,t:1527023428800};\\\", \\\"{x:613,y:534,t:1527023428813};\\\", \\\"{x:602,y:563,t:1527023428829};\\\", \\\"{x:587,y:599,t:1527023428846};\\\", \\\"{x:562,y:638,t:1527023428862};\\\", \\\"{x:535,y:670,t:1527023428879};\\\", \\\"{x:508,y:699,t:1527023428896};\\\", \\\"{x:498,y:709,t:1527023428913};\\\", \\\"{x:494,y:714,t:1527023428928};\\\", \\\"{x:492,y:717,t:1527023428946};\\\", \\\"{x:491,y:717,t:1527023428962};\\\", \\\"{x:491,y:715,t:1527023429129};\\\", \\\"{x:491,y:706,t:1527023429146};\\\", \\\"{x:492,y:699,t:1527023429162};\\\", \\\"{x:494,y:693,t:1527023429179};\\\", \\\"{x:496,y:689,t:1527023429196};\\\", \\\"{x:496,y:684,t:1527023429212};\\\", \\\"{x:496,y:682,t:1527023429230};\\\", \\\"{x:496,y:681,t:1527023429497};\\\", \\\"{x:497,y:679,t:1527023429514};\\\", \\\"{x:498,y:679,t:1527023430256};\\\", \\\"{x:504,y:679,t:1527023430264};\\\", \\\"{x:525,y:679,t:1527023430280};\\\", \\\"{x:551,y:679,t:1527023430297};\\\", \\\"{x:574,y:679,t:1527023430314};\\\", \\\"{x:591,y:678,t:1527023430330};\\\", \\\"{x:595,y:677,t:1527023430347};\\\", \\\"{x:596,y:677,t:1527023430364};\\\" ] }, { \\\"rt\\\": 16976, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 9, \\\"time_elapsed\\\": 533060, \\\"internal_node_id\\\": \\\"0.0-5.0-4.0\\\", \\\"subject\\\": \\\"QOJ6L\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"hotel\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 5, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"A\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-04 PM-01 PM-A \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:597,y:674,t:1527023430930};\\\", \\\"{x:598,y:672,t:1527023430963};\\\", \\\"{x:598,y:671,t:1527023431016};\\\", \\\"{x:598,y:669,t:1527023431047};\\\", \\\"{x:598,y:668,t:1527023431064};\\\", \\\"{x:598,y:666,t:1527023431088};\\\", \\\"{x:598,y:665,t:1527023431119};\\\", \\\"{x:598,y:663,t:1527023431143};\\\", \\\"{x:598,y:662,t:1527023431167};\\\", \\\"{x:598,y:661,t:1527023431191};\\\", \\\"{x:598,y:659,t:1527023431208};\\\", \\\"{x:597,y:659,t:1527023431265};\\\", \\\"{x:597,y:657,t:1527023431281};\\\", \\\"{x:597,y:656,t:1527023431298};\\\", \\\"{x:578,y:609,t:1527023431402};\\\", \\\"{x:574,y:596,t:1527023431415};\\\", \\\"{x:562,y:558,t:1527023431431};\\\", \\\"{x:532,y:455,t:1527023431448};\\\", \\\"{x:507,y:402,t:1527023431464};\\\", \\\"{x:486,y:373,t:1527023431480};\\\", \\\"{x:476,y:361,t:1527023431498};\\\", \\\"{x:473,y:358,t:1527023431515};\\\", \\\"{x:471,y:358,t:1527023431592};\\\", \\\"{x:467,y:358,t:1527023431600};\\\", \\\"{x:459,y:362,t:1527023431615};\\\", \\\"{x:437,y:373,t:1527023431631};\\\", \\\"{x:405,y:382,t:1527023431648};\\\", \\\"{x:388,y:389,t:1527023431664};\\\", \\\"{x:369,y:396,t:1527023431681};\\\", \\\"{x:356,y:400,t:1527023431698};\\\", \\\"{x:347,y:403,t:1527023431715};\\\", \\\"{x:346,y:403,t:1527023431732};\\\", \\\"{x:345,y:403,t:1527023431936};\\\", \\\"{x:344,y:403,t:1527023431947};\\\", \\\"{x:340,y:403,t:1527023431965};\\\", \\\"{x:337,y:404,t:1527023431981};\\\", \\\"{x:334,y:405,t:1527023431998};\\\", \\\"{x:332,y:406,t:1527023432014};\\\", \\\"{x:330,y:406,t:1527023432032};\\\", \\\"{x:329,y:406,t:1527023432048};\\\", \\\"{x:328,y:406,t:1527023432065};\\\", \\\"{x:330,y:406,t:1527023432289};\\\", \\\"{x:332,y:406,t:1527023432300};\\\", \\\"{x:337,y:406,t:1527023432315};\\\", \\\"{x:352,y:406,t:1527023432331};\\\", \\\"{x:370,y:406,t:1527023432349};\\\", \\\"{x:394,y:406,t:1527023432366};\\\", \\\"{x:422,y:406,t:1527023432382};\\\", \\\"{x:456,y:406,t:1527023432398};\\\", \\\"{x:484,y:406,t:1527023432414};\\\", \\\"{x:522,y:406,t:1527023432431};\\\", \\\"{x:543,y:406,t:1527023432449};\\\", \\\"{x:560,y:406,t:1527023432465};\\\", \\\"{x:574,y:406,t:1527023432482};\\\", \\\"{x:581,y:406,t:1527023432498};\\\", \\\"{x:586,y:406,t:1527023432515};\\\", \\\"{x:589,y:406,t:1527023432532};\\\", \\\"{x:592,y:406,t:1527023432549};\\\", \\\"{x:593,y:406,t:1527023432565};\\\", \\\"{x:596,y:406,t:1527023432582};\\\", \\\"{x:601,y:407,t:1527023432599};\\\", \\\"{x:606,y:407,t:1527023432615};\\\", \\\"{x:608,y:407,t:1527023432631};\\\", \\\"{x:611,y:408,t:1527023432649};\\\", \\\"{x:613,y:408,t:1527023432666};\\\", \\\"{x:614,y:409,t:1527023432682};\\\", \\\"{x:615,y:409,t:1527023432699};\\\", \\\"{x:616,y:409,t:1527023432716};\\\", \\\"{x:616,y:409,t:1527023432753};\\\", \\\"{x:616,y:410,t:1527023432792};\\\", \\\"{x:617,y:411,t:1527023432800};\\\", \\\"{x:618,y:411,t:1527023432815};\\\", \\\"{x:620,y:413,t:1527023432832};\\\", \\\"{x:621,y:414,t:1527023432849};\\\", \\\"{x:623,y:416,t:1527023433456};\\\", \\\"{x:624,y:417,t:1527023433466};\\\", \\\"{x:630,y:418,t:1527023433483};\\\", \\\"{x:635,y:418,t:1527023433500};\\\", \\\"{x:637,y:418,t:1527023433517};\\\", \\\"{x:638,y:418,t:1527023433534};\\\", \\\"{x:640,y:419,t:1527023433738};\\\", \\\"{x:641,y:420,t:1527023433752};\\\", \\\"{x:642,y:424,t:1527023433768};\\\", \\\"{x:646,y:428,t:1527023433784};\\\", \\\"{x:648,y:431,t:1527023433801};\\\", \\\"{x:652,y:432,t:1527023433818};\\\", \\\"{x:655,y:432,t:1527023433834};\\\", \\\"{x:659,y:432,t:1527023433851};\\\", \\\"{x:661,y:432,t:1527023433868};\\\", \\\"{x:665,y:432,t:1527023433884};\\\", \\\"{x:668,y:432,t:1527023433901};\\\", \\\"{x:674,y:432,t:1527023433919};\\\", \\\"{x:685,y:432,t:1527023433934};\\\", \\\"{x:697,y:432,t:1527023433951};\\\", \\\"{x:701,y:432,t:1527023433968};\\\", \\\"{x:701,y:433,t:1527023435072};\\\", \\\"{x:701,y:437,t:1527023435087};\\\", \\\"{x:684,y:446,t:1527023435104};\\\", \\\"{x:679,y:448,t:1527023435120};\\\", \\\"{x:678,y:448,t:1527023435137};\\\", \\\"{x:677,y:448,t:1527023435185};\\\", \\\"{x:679,y:448,t:1527023435338};\\\", \\\"{x:680,y:448,t:1527023435360};\\\", \\\"{x:679,y:448,t:1527023435505};\\\", \\\"{x:676,y:448,t:1527023435521};\\\", \\\"{x:674,y:448,t:1527023435539};\\\", \\\"{x:669,y:448,t:1527023435555};\\\", \\\"{x:666,y:448,t:1527023435572};\\\", \\\"{x:662,y:448,t:1527023435588};\\\", \\\"{x:660,y:448,t:1527023435604};\\\", \\\"{x:659,y:448,t:1527023435621};\\\", \\\"{x:658,y:448,t:1527023435639};\\\", \\\"{x:657,y:448,t:1527023435656};\\\", \\\"{x:656,y:448,t:1527023435689};\\\", \\\"{x:653,y:448,t:1527023435705};\\\", \\\"{x:648,y:448,t:1527023435722};\\\", \\\"{x:641,y:448,t:1527023435739};\\\", \\\"{x:638,y:448,t:1527023435755};\\\", \\\"{x:632,y:448,t:1527023435772};\\\", \\\"{x:626,y:448,t:1527023435789};\\\", \\\"{x:617,y:448,t:1527023435805};\\\", \\\"{x:609,y:448,t:1527023435822};\\\", \\\"{x:600,y:448,t:1527023435838};\\\", \\\"{x:591,y:448,t:1527023435854};\\\", \\\"{x:580,y:448,t:1527023435871};\\\", \\\"{x:572,y:448,t:1527023435888};\\\", \\\"{x:568,y:449,t:1527023435905};\\\", \\\"{x:564,y:449,t:1527023435922};\\\", \\\"{x:563,y:449,t:1527023435939};\\\", \\\"{x:561,y:449,t:1527023435955};\\\", \\\"{x:560,y:450,t:1527023435972};\\\", \\\"{x:559,y:450,t:1527023435999};\\\", \\\"{x:558,y:451,t:1527023436007};\\\", \\\"{x:557,y:451,t:1527023436023};\\\", \\\"{x:556,y:451,t:1527023436047};\\\", \\\"{x:555,y:451,t:1527023436056};\\\", \\\"{x:554,y:452,t:1527023436080};\\\", \\\"{x:553,y:452,t:1527023436103};\\\", \\\"{x:552,y:453,t:1527023436112};\\\", \\\"{x:551,y:453,t:1527023436122};\\\", \\\"{x:549,y:453,t:1527023436139};\\\", \\\"{x:545,y:455,t:1527023436156};\\\", \\\"{x:542,y:455,t:1527023436172};\\\", \\\"{x:539,y:456,t:1527023436189};\\\", \\\"{x:535,y:456,t:1527023436206};\\\", \\\"{x:531,y:457,t:1527023436222};\\\", \\\"{x:527,y:457,t:1527023436239};\\\", \\\"{x:522,y:458,t:1527023436255};\\\", \\\"{x:520,y:458,t:1527023436272};\\\", \\\"{x:518,y:458,t:1527023436289};\\\", \\\"{x:517,y:459,t:1527023436306};\\\", \\\"{x:516,y:459,t:1527023436323};\\\", \\\"{x:515,y:460,t:1527023436339};\\\", \\\"{x:514,y:460,t:1527023436511};\\\", \\\"{x:514,y:461,t:1527023436527};\\\", \\\"{x:513,y:461,t:1527023436559};\\\", \\\"{x:513,y:462,t:1527023436743};\\\", \\\"{x:513,y:463,t:1527023436757};\\\", \\\"{x:516,y:467,t:1527023436775};\\\", \\\"{x:528,y:472,t:1527023436789};\\\", \\\"{x:538,y:476,t:1527023436807};\\\", \\\"{x:549,y:479,t:1527023436818};\\\", \\\"{x:552,y:480,t:1527023436835};\\\", \\\"{x:553,y:481,t:1527023436852};\\\", \\\"{x:554,y:482,t:1527023437392};\\\", \\\"{x:555,y:483,t:1527023437401};\\\", \\\"{x:574,y:481,t:1527023437419};\\\", \\\"{x:621,y:486,t:1527023437435};\\\", \\\"{x:707,y:497,t:1527023437452};\\\", \\\"{x:805,y:501,t:1527023437470};\\\", \\\"{x:909,y:511,t:1527023437486};\\\", \\\"{x:998,y:522,t:1527023437504};\\\", \\\"{x:1063,y:525,t:1527023437519};\\\", \\\"{x:1137,y:525,t:1527023437536};\\\", \\\"{x:1140,y:525,t:1527023437553};\\\", \\\"{x:1142,y:524,t:1527023437569};\\\", \\\"{x:1142,y:525,t:1527023438504};\\\", \\\"{x:1143,y:529,t:1527023438520};\\\", \\\"{x:1146,y:533,t:1527023438537};\\\", \\\"{x:1150,y:537,t:1527023438553};\\\", \\\"{x:1154,y:540,t:1527023438570};\\\", \\\"{x:1159,y:543,t:1527023438586};\\\", \\\"{x:1164,y:546,t:1527023438603};\\\", \\\"{x:1169,y:547,t:1527023438620};\\\", \\\"{x:1174,y:550,t:1527023438637};\\\", \\\"{x:1178,y:553,t:1527023438653};\\\", \\\"{x:1182,y:555,t:1527023438670};\\\", \\\"{x:1183,y:555,t:1527023438687};\\\", \\\"{x:1185,y:555,t:1527023439031};\\\", \\\"{x:1188,y:555,t:1527023439039};\\\", \\\"{x:1189,y:555,t:1527023439095};\\\", \\\"{x:1191,y:555,t:1527023439104};\\\", \\\"{x:1200,y:561,t:1527023439120};\\\", \\\"{x:1213,y:568,t:1527023439137};\\\", \\\"{x:1229,y:575,t:1527023439154};\\\", \\\"{x:1249,y:584,t:1527023439170};\\\", \\\"{x:1271,y:593,t:1527023439187};\\\", \\\"{x:1297,y:605,t:1527023439204};\\\", \\\"{x:1320,y:614,t:1527023439220};\\\", \\\"{x:1341,y:619,t:1527023439237};\\\", \\\"{x:1359,y:626,t:1527023439254};\\\", \\\"{x:1372,y:630,t:1527023439270};\\\", \\\"{x:1385,y:636,t:1527023439287};\\\", \\\"{x:1404,y:644,t:1527023439304};\\\", \\\"{x:1412,y:647,t:1527023439319};\\\", \\\"{x:1417,y:650,t:1527023439337};\\\", \\\"{x:1420,y:651,t:1527023439354};\\\", \\\"{x:1422,y:652,t:1527023439375};\\\", \\\"{x:1423,y:652,t:1527023439391};\\\", \\\"{x:1427,y:653,t:1527023439404};\\\", \\\"{x:1428,y:653,t:1527023439421};\\\", \\\"{x:1429,y:653,t:1527023439437};\\\", \\\"{x:1430,y:654,t:1527023439736};\\\", \\\"{x:1430,y:658,t:1527023439743};\\\", \\\"{x:1430,y:664,t:1527023439754};\\\", \\\"{x:1430,y:670,t:1527023439771};\\\", \\\"{x:1434,y:683,t:1527023439787};\\\", \\\"{x:1435,y:688,t:1527023439804};\\\", \\\"{x:1435,y:694,t:1527023439821};\\\", \\\"{x:1434,y:695,t:1527023439837};\\\", \\\"{x:1433,y:695,t:1527023439854};\\\", \\\"{x:1433,y:696,t:1527023440264};\\\", \\\"{x:1434,y:696,t:1527023440271};\\\", \\\"{x:1435,y:696,t:1527023440296};\\\", \\\"{x:1436,y:696,t:1527023440304};\\\", \\\"{x:1437,y:696,t:1527023440321};\\\", \\\"{x:1439,y:694,t:1527023440338};\\\", \\\"{x:1443,y:693,t:1527023440354};\\\", \\\"{x:1445,y:691,t:1527023440371};\\\", \\\"{x:1447,y:690,t:1527023440388};\\\", \\\"{x:1447,y:689,t:1527023440404};\\\", \\\"{x:1448,y:688,t:1527023440421};\\\", \\\"{x:1449,y:686,t:1527023440438};\\\", \\\"{x:1449,y:685,t:1527023440454};\\\", \\\"{x:1449,y:684,t:1527023440471};\\\", \\\"{x:1449,y:679,t:1527023440487};\\\", \\\"{x:1446,y:670,t:1527023440504};\\\", \\\"{x:1440,y:655,t:1527023440521};\\\", \\\"{x:1425,y:629,t:1527023440539};\\\", \\\"{x:1407,y:599,t:1527023440554};\\\", \\\"{x:1391,y:570,t:1527023440571};\\\", \\\"{x:1382,y:555,t:1527023440588};\\\", \\\"{x:1374,y:542,t:1527023440604};\\\", \\\"{x:1370,y:530,t:1527023440621};\\\", \\\"{x:1366,y:521,t:1527023440638};\\\", \\\"{x:1365,y:515,t:1527023440655};\\\", \\\"{x:1364,y:512,t:1527023440671};\\\", \\\"{x:1364,y:510,t:1527023440689};\\\", \\\"{x:1363,y:510,t:1527023440824};\\\", \\\"{x:1360,y:512,t:1527023440838};\\\", \\\"{x:1352,y:524,t:1527023440855};\\\", \\\"{x:1338,y:549,t:1527023440871};\\\", \\\"{x:1327,y:567,t:1527023440888};\\\", \\\"{x:1320,y:578,t:1527023440905};\\\", \\\"{x:1317,y:584,t:1527023440921};\\\", \\\"{x:1311,y:591,t:1527023440938};\\\", \\\"{x:1306,y:596,t:1527023440955};\\\", \\\"{x:1296,y:605,t:1527023440971};\\\", \\\"{x:1288,y:615,t:1527023440988};\\\", \\\"{x:1279,y:624,t:1527023441005};\\\", \\\"{x:1272,y:632,t:1527023441021};\\\", \\\"{x:1263,y:640,t:1527023441038};\\\", \\\"{x:1253,y:652,t:1527023441056};\\\", \\\"{x:1251,y:658,t:1527023441071};\\\", \\\"{x:1244,y:671,t:1527023441089};\\\", \\\"{x:1241,y:675,t:1527023441105};\\\", \\\"{x:1238,y:682,t:1527023441121};\\\", \\\"{x:1232,y:699,t:1527023441138};\\\", \\\"{x:1222,y:720,t:1527023441156};\\\", \\\"{x:1209,y:742,t:1527023441172};\\\", \\\"{x:1196,y:761,t:1527023441188};\\\", \\\"{x:1188,y:773,t:1527023441206};\\\", \\\"{x:1180,y:785,t:1527023441221};\\\", \\\"{x:1176,y:794,t:1527023441238};\\\", \\\"{x:1172,y:801,t:1527023441256};\\\", \\\"{x:1171,y:807,t:1527023441271};\\\", \\\"{x:1169,y:810,t:1527023441288};\\\", \\\"{x:1167,y:814,t:1527023441305};\\\", \\\"{x:1165,y:818,t:1527023441323};\\\", \\\"{x:1163,y:822,t:1527023441338};\\\", \\\"{x:1158,y:827,t:1527023441355};\\\", \\\"{x:1151,y:834,t:1527023441372};\\\", \\\"{x:1142,y:845,t:1527023441388};\\\", \\\"{x:1130,y:857,t:1527023441406};\\\", \\\"{x:1123,y:862,t:1527023441422};\\\", \\\"{x:1115,y:868,t:1527023441438};\\\", \\\"{x:1107,y:872,t:1527023441456};\\\", \\\"{x:1105,y:873,t:1527023441471};\\\", \\\"{x:1105,y:871,t:1527023441552};\\\", \\\"{x:1105,y:868,t:1527023441560};\\\", \\\"{x:1105,y:866,t:1527023441573};\\\", \\\"{x:1105,y:857,t:1527023441589};\\\", \\\"{x:1114,y:843,t:1527023441605};\\\", \\\"{x:1123,y:832,t:1527023441623};\\\", \\\"{x:1134,y:818,t:1527023441638};\\\", \\\"{x:1144,y:806,t:1527023441656};\\\", \\\"{x:1160,y:782,t:1527023441672};\\\", \\\"{x:1177,y:756,t:1527023441688};\\\", \\\"{x:1203,y:708,t:1527023441706};\\\", \\\"{x:1228,y:664,t:1527023441722};\\\", \\\"{x:1243,y:637,t:1527023441738};\\\", \\\"{x:1254,y:617,t:1527023441755};\\\", \\\"{x:1262,y:604,t:1527023441772};\\\", \\\"{x:1273,y:583,t:1527023441788};\\\", \\\"{x:1282,y:563,t:1527023441805};\\\", \\\"{x:1291,y:541,t:1527023441822};\\\", \\\"{x:1299,y:523,t:1527023441839};\\\", \\\"{x:1308,y:500,t:1527023441856};\\\", \\\"{x:1311,y:491,t:1527023441872};\\\", \\\"{x:1316,y:479,t:1527023441889};\\\", \\\"{x:1323,y:465,t:1527023441905};\\\", \\\"{x:1326,y:453,t:1527023441922};\\\", \\\"{x:1329,y:445,t:1527023441939};\\\", \\\"{x:1334,y:437,t:1527023441955};\\\", \\\"{x:1335,y:431,t:1527023441972};\\\", \\\"{x:1337,y:428,t:1527023441989};\\\", \\\"{x:1340,y:432,t:1527023442040};\\\", \\\"{x:1344,y:440,t:1527023442055};\\\", \\\"{x:1366,y:496,t:1527023442073};\\\", \\\"{x:1394,y:557,t:1527023442089};\\\", \\\"{x:1424,y:619,t:1527023442105};\\\", \\\"{x:1448,y:667,t:1527023442122};\\\", \\\"{x:1470,y:714,t:1527023442139};\\\", \\\"{x:1488,y:745,t:1527023442155};\\\", \\\"{x:1514,y:779,t:1527023442172};\\\", \\\"{x:1533,y:814,t:1527023442189};\\\", \\\"{x:1552,y:839,t:1527023442206};\\\", \\\"{x:1563,y:855,t:1527023442222};\\\", \\\"{x:1572,y:870,t:1527023442239};\\\", \\\"{x:1578,y:882,t:1527023442255};\\\", \\\"{x:1588,y:903,t:1527023442273};\\\", \\\"{x:1591,y:917,t:1527023442289};\\\", \\\"{x:1595,y:929,t:1527023442306};\\\", \\\"{x:1596,y:938,t:1527023442322};\\\", \\\"{x:1597,y:943,t:1527023442339};\\\", \\\"{x:1597,y:947,t:1527023442355};\\\", \\\"{x:1597,y:953,t:1527023442372};\\\", \\\"{x:1595,y:957,t:1527023442390};\\\", \\\"{x:1591,y:960,t:1527023442405};\\\", \\\"{x:1588,y:963,t:1527023442422};\\\", \\\"{x:1586,y:963,t:1527023442440};\\\", \\\"{x:1583,y:963,t:1527023442455};\\\", \\\"{x:1575,y:963,t:1527023442472};\\\", \\\"{x:1562,y:961,t:1527023442489};\\\", \\\"{x:1548,y:961,t:1527023442505};\\\", \\\"{x:1527,y:957,t:1527023442522};\\\", \\\"{x:1505,y:951,t:1527023442539};\\\", \\\"{x:1480,y:945,t:1527023442556};\\\", \\\"{x:1456,y:935,t:1527023442572};\\\", \\\"{x:1429,y:917,t:1527023442589};\\\", \\\"{x:1401,y:894,t:1527023442607};\\\", \\\"{x:1381,y:873,t:1527023442622};\\\", \\\"{x:1366,y:859,t:1527023442640};\\\", \\\"{x:1349,y:840,t:1527023442655};\\\", \\\"{x:1339,y:825,t:1527023442672};\\\", \\\"{x:1330,y:807,t:1527023442689};\\\", \\\"{x:1321,y:787,t:1527023442706};\\\", \\\"{x:1314,y:770,t:1527023442722};\\\", \\\"{x:1305,y:753,t:1527023442740};\\\", \\\"{x:1300,y:733,t:1527023442756};\\\", \\\"{x:1298,y:718,t:1527023442772};\\\", \\\"{x:1295,y:708,t:1527023442789};\\\", \\\"{x:1294,y:704,t:1527023442806};\\\", \\\"{x:1295,y:703,t:1527023443304};\\\", \\\"{x:1296,y:703,t:1527023443328};\\\", \\\"{x:1297,y:702,t:1527023443339};\\\", \\\"{x:1298,y:702,t:1527023443356};\\\", \\\"{x:1301,y:702,t:1527023443373};\\\", \\\"{x:1302,y:702,t:1527023443389};\\\", \\\"{x:1303,y:701,t:1527023443406};\\\", \\\"{x:1305,y:701,t:1527023443440};\\\", \\\"{x:1306,y:701,t:1527023443471};\\\", \\\"{x:1307,y:701,t:1527023443480};\\\", \\\"{x:1308,y:701,t:1527023443544};\\\", \\\"{x:1308,y:703,t:1527023443800};\\\", \\\"{x:1308,y:704,t:1527023443816};\\\", \\\"{x:1308,y:706,t:1527023443832};\\\", \\\"{x:1309,y:706,t:1527023443840};\\\", \\\"{x:1309,y:707,t:1527023443863};\\\", \\\"{x:1309,y:708,t:1527023443880};\\\", \\\"{x:1310,y:709,t:1527023443890};\\\", \\\"{x:1310,y:711,t:1527023444408};\\\", \\\"{x:1310,y:716,t:1527023444423};\\\", \\\"{x:1312,y:721,t:1527023444440};\\\", \\\"{x:1317,y:731,t:1527023444457};\\\", \\\"{x:1324,y:748,t:1527023444473};\\\", \\\"{x:1330,y:767,t:1527023444491};\\\", \\\"{x:1333,y:783,t:1527023444507};\\\", \\\"{x:1338,y:798,t:1527023444523};\\\", \\\"{x:1342,y:808,t:1527023444540};\\\", \\\"{x:1346,y:820,t:1527023444557};\\\", \\\"{x:1348,y:829,t:1527023444573};\\\", \\\"{x:1350,y:836,t:1527023444591};\\\", \\\"{x:1351,y:843,t:1527023444607};\\\", \\\"{x:1351,y:847,t:1527023444624};\\\", \\\"{x:1354,y:855,t:1527023444640};\\\", \\\"{x:1356,y:864,t:1527023444658};\\\", \\\"{x:1356,y:865,t:1527023444680};\\\", \\\"{x:1357,y:865,t:1527023445080};\\\", \\\"{x:1357,y:864,t:1527023445136};\\\", \\\"{x:1356,y:864,t:1527023445144};\\\", \\\"{x:1355,y:863,t:1527023445157};\\\", \\\"{x:1353,y:862,t:1527023445174};\\\", \\\"{x:1351,y:860,t:1527023445190};\\\", \\\"{x:1343,y:856,t:1527023445207};\\\", \\\"{x:1333,y:850,t:1527023445225};\\\", \\\"{x:1323,y:844,t:1527023445241};\\\", \\\"{x:1315,y:840,t:1527023445257};\\\", \\\"{x:1311,y:838,t:1527023445275};\\\", \\\"{x:1308,y:837,t:1527023445291};\\\", \\\"{x:1307,y:837,t:1527023445307};\\\", \\\"{x:1307,y:836,t:1527023445324};\\\", \\\"{x:1306,y:836,t:1527023445342};\\\", \\\"{x:1305,y:835,t:1527023445584};\\\", \\\"{x:1305,y:832,t:1527023445592};\\\", \\\"{x:1305,y:822,t:1527023445608};\\\", \\\"{x:1303,y:804,t:1527023445624};\\\", \\\"{x:1300,y:787,t:1527023445641};\\\", \\\"{x:1300,y:780,t:1527023445658};\\\", \\\"{x:1300,y:776,t:1527023445674};\\\", \\\"{x:1300,y:772,t:1527023445692};\\\", \\\"{x:1300,y:770,t:1527023445707};\\\", \\\"{x:1300,y:769,t:1527023445724};\\\", \\\"{x:1300,y:768,t:1527023445752};\\\", \\\"{x:1300,y:767,t:1527023445855};\\\", \\\"{x:1294,y:766,t:1527023445928};\\\", \\\"{x:1280,y:765,t:1527023445942};\\\", \\\"{x:1208,y:758,t:1527023445958};\\\", \\\"{x:1089,y:758,t:1527023445974};\\\", \\\"{x:912,y:746,t:1527023445991};\\\", \\\"{x:815,y:734,t:1527023446007};\\\", \\\"{x:715,y:718,t:1527023446024};\\\", \\\"{x:612,y:698,t:1527023446041};\\\", \\\"{x:523,y:675,t:1527023446059};\\\", \\\"{x:437,y:651,t:1527023446075};\\\", \\\"{x:375,y:628,t:1527023446091};\\\", \\\"{x:356,y:616,t:1527023446102};\\\", \\\"{x:319,y:598,t:1527023446118};\\\", \\\"{x:289,y:579,t:1527023446135};\\\", \\\"{x:282,y:573,t:1527023446143};\\\", \\\"{x:270,y:565,t:1527023446160};\\\", \\\"{x:260,y:557,t:1527023446176};\\\", \\\"{x:249,y:548,t:1527023446193};\\\", \\\"{x:235,y:538,t:1527023446210};\\\", \\\"{x:221,y:527,t:1527023446227};\\\", \\\"{x:208,y:514,t:1527023446244};\\\", \\\"{x:192,y:502,t:1527023446260};\\\", \\\"{x:182,y:493,t:1527023446277};\\\", \\\"{x:173,y:488,t:1527023446293};\\\", \\\"{x:164,y:485,t:1527023446309};\\\", \\\"{x:162,y:484,t:1527023446326};\\\", \\\"{x:166,y:486,t:1527023446439};\\\", \\\"{x:173,y:488,t:1527023446448};\\\", \\\"{x:180,y:490,t:1527023446460};\\\", \\\"{x:205,y:490,t:1527023446477};\\\", \\\"{x:233,y:490,t:1527023446493};\\\", \\\"{x:266,y:490,t:1527023446510};\\\", \\\"{x:336,y:490,t:1527023446528};\\\", \\\"{x:366,y:490,t:1527023446543};\\\", \\\"{x:390,y:490,t:1527023446561};\\\", \\\"{x:405,y:490,t:1527023446577};\\\", \\\"{x:412,y:490,t:1527023446594};\\\", \\\"{x:413,y:490,t:1527023446611};\\\", \\\"{x:413,y:491,t:1527023447079};\\\", \\\"{x:416,y:494,t:1527023447093};\\\", \\\"{x:423,y:506,t:1527023447111};\\\", \\\"{x:437,y:525,t:1527023447127};\\\", \\\"{x:453,y:543,t:1527023447145};\\\", \\\"{x:466,y:562,t:1527023447160};\\\", \\\"{x:481,y:583,t:1527023447177};\\\", \\\"{x:498,y:609,t:1527023447195};\\\", \\\"{x:518,y:637,t:1527023447211};\\\", \\\"{x:539,y:663,t:1527023447228};\\\", \\\"{x:552,y:679,t:1527023447244};\\\", \\\"{x:557,y:686,t:1527023447260};\\\", \\\"{x:560,y:690,t:1527023447277};\\\", \\\"{x:562,y:692,t:1527023447294};\\\", \\\"{x:560,y:692,t:1527023447615};\\\", \\\"{x:555,y:691,t:1527023447629};\\\", \\\"{x:550,y:688,t:1527023447645};\\\", \\\"{x:548,y:686,t:1527023447661};\\\", \\\"{x:547,y:686,t:1527023447678};\\\" ] }, { \\\"rt\\\": 15676, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 10, \\\"time_elapsed\\\": 549976, \\\"internal_node_id\\\": \\\"0.0-6.0-0.0\\\", \\\"subject\\\": \\\"QOJ6L\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"hotel\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration\\\", \\\"q\\\": 6, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\", \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-4-3-E -G -G -03 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:545,y:686,t:1527023449695};\\\", \\\"{x:542,y:686,t:1527023449704};\\\", \\\"{x:541,y:685,t:1527023449728};\\\", \\\"{x:540,y:684,t:1527023449735};\\\", \\\"{x:539,y:684,t:1527023449751};\\\", \\\"{x:537,y:683,t:1527023449783};\\\", \\\"{x:537,y:680,t:1527023449975};\\\", \\\"{x:544,y:676,t:1527023449984};\\\", \\\"{x:554,y:670,t:1527023449997};\\\", \\\"{x:570,y:657,t:1527023450014};\\\", \\\"{x:584,y:643,t:1527023450031};\\\", \\\"{x:598,y:625,t:1527023450046};\\\", \\\"{x:615,y:588,t:1527023450063};\\\", \\\"{x:617,y:558,t:1527023450080};\\\", \\\"{x:617,y:534,t:1527023450097};\\\", \\\"{x:617,y:519,t:1527023450113};\\\", \\\"{x:617,y:508,t:1527023450130};\\\", \\\"{x:609,y:494,t:1527023450146};\\\", \\\"{x:604,y:488,t:1527023450163};\\\", \\\"{x:602,y:486,t:1527023450180};\\\", \\\"{x:603,y:486,t:1527023450431};\\\", \\\"{x:654,y:493,t:1527023450447};\\\", \\\"{x:756,y:505,t:1527023450464};\\\", \\\"{x:861,y:517,t:1527023450481};\\\", \\\"{x:969,y:517,t:1527023450497};\\\", \\\"{x:1088,y:517,t:1527023450513};\\\", \\\"{x:1183,y:519,t:1527023450531};\\\", \\\"{x:1272,y:519,t:1527023450546};\\\", \\\"{x:1303,y:519,t:1527023450564};\\\", \\\"{x:1303,y:520,t:1527023451119};\\\", \\\"{x:1296,y:527,t:1527023451131};\\\", \\\"{x:1245,y:531,t:1527023451149};\\\", \\\"{x:1182,y:528,t:1527023451165};\\\", \\\"{x:1092,y:523,t:1527023451181};\\\", \\\"{x:1012,y:512,t:1527023451199};\\\", \\\"{x:910,y:487,t:1527023451217};\\\", \\\"{x:849,y:470,t:1527023451232};\\\", \\\"{x:799,y:458,t:1527023451247};\\\", \\\"{x:754,y:444,t:1527023451264};\\\", \\\"{x:720,y:438,t:1527023451281};\\\", \\\"{x:695,y:432,t:1527023451297};\\\", \\\"{x:678,y:430,t:1527023451315};\\\", \\\"{x:666,y:427,t:1527023451331};\\\", \\\"{x:661,y:426,t:1527023451348};\\\", \\\"{x:656,y:425,t:1527023451364};\\\", \\\"{x:648,y:424,t:1527023451381};\\\", \\\"{x:632,y:424,t:1527023451397};\\\", \\\"{x:610,y:423,t:1527023451415};\\\", \\\"{x:573,y:423,t:1527023451431};\\\", \\\"{x:546,y:423,t:1527023451449};\\\", \\\"{x:512,y:423,t:1527023451464};\\\", \\\"{x:483,y:423,t:1527023451481};\\\", \\\"{x:458,y:423,t:1527023451499};\\\", \\\"{x:438,y:423,t:1527023451515};\\\", \\\"{x:432,y:421,t:1527023451531};\\\", \\\"{x:431,y:421,t:1527023451548};\\\", \\\"{x:431,y:420,t:1527023451615};\\\", \\\"{x:431,y:418,t:1527023451639};\\\", \\\"{x:431,y:417,t:1527023451648};\\\", \\\"{x:431,y:413,t:1527023451666};\\\", \\\"{x:431,y:406,t:1527023451683};\\\", \\\"{x:432,y:402,t:1527023451700};\\\", \\\"{x:432,y:399,t:1527023451716};\\\", \\\"{x:433,y:398,t:1527023451736};\\\", \\\"{x:434,y:398,t:1527023451904};\\\", \\\"{x:436,y:398,t:1527023451916};\\\", \\\"{x:448,y:404,t:1527023451934};\\\", \\\"{x:461,y:410,t:1527023451951};\\\", \\\"{x:470,y:414,t:1527023451967};\\\", \\\"{x:482,y:419,t:1527023451984};\\\", \\\"{x:487,y:424,t:1527023452001};\\\", \\\"{x:495,y:430,t:1527023452018};\\\", \\\"{x:509,y:437,t:1527023452034};\\\", \\\"{x:520,y:444,t:1527023452050};\\\", \\\"{x:532,y:452,t:1527023452065};\\\", \\\"{x:540,y:457,t:1527023452082};\\\", \\\"{x:543,y:458,t:1527023452099};\\\", \\\"{x:546,y:460,t:1527023452114};\\\", \\\"{x:547,y:461,t:1527023452136};\\\", \\\"{x:549,y:462,t:1527023452152};\\\", \\\"{x:549,y:463,t:1527023452164};\\\", \\\"{x:551,y:464,t:1527023452182};\\\", \\\"{x:552,y:466,t:1527023452199};\\\", \\\"{x:553,y:466,t:1527023452215};\\\", \\\"{x:554,y:469,t:1527023452231};\\\", \\\"{x:556,y:470,t:1527023452249};\\\", \\\"{x:557,y:471,t:1527023452264};\\\", \\\"{x:560,y:473,t:1527023452282};\\\", \\\"{x:562,y:475,t:1527023452298};\\\", \\\"{x:566,y:478,t:1527023452315};\\\", \\\"{x:568,y:478,t:1527023452332};\\\", \\\"{x:570,y:480,t:1527023452348};\\\", \\\"{x:571,y:480,t:1527023452364};\\\", \\\"{x:573,y:481,t:1527023452382};\\\", \\\"{x:578,y:483,t:1527023452399};\\\", \\\"{x:582,y:485,t:1527023452414};\\\", \\\"{x:595,y:492,t:1527023452431};\\\", \\\"{x:604,y:494,t:1527023452449};\\\", \\\"{x:616,y:498,t:1527023452464};\\\", \\\"{x:628,y:503,t:1527023452482};\\\", \\\"{x:642,y:507,t:1527023452498};\\\", \\\"{x:659,y:513,t:1527023452515};\\\", \\\"{x:680,y:518,t:1527023452532};\\\", \\\"{x:704,y:525,t:1527023452549};\\\", \\\"{x:739,y:533,t:1527023452566};\\\", \\\"{x:772,y:537,t:1527023452581};\\\", \\\"{x:820,y:545,t:1527023452599};\\\", \\\"{x:868,y:552,t:1527023452615};\\\", \\\"{x:962,y:566,t:1527023452632};\\\", \\\"{x:1018,y:574,t:1527023452649};\\\", \\\"{x:1071,y:582,t:1527023452666};\\\", \\\"{x:1117,y:584,t:1527023452681};\\\", \\\"{x:1150,y:584,t:1527023452699};\\\", \\\"{x:1180,y:586,t:1527023452715};\\\", \\\"{x:1208,y:586,t:1527023452731};\\\", \\\"{x:1234,y:586,t:1527023452749};\\\", \\\"{x:1255,y:586,t:1527023452766};\\\", \\\"{x:1272,y:586,t:1527023452783};\\\", \\\"{x:1283,y:586,t:1527023452799};\\\", \\\"{x:1296,y:586,t:1527023452815};\\\", \\\"{x:1300,y:586,t:1527023452833};\\\", \\\"{x:1301,y:586,t:1527023452849};\\\", \\\"{x:1302,y:586,t:1527023452952};\\\", \\\"{x:1300,y:584,t:1527023452965};\\\", \\\"{x:1294,y:584,t:1527023452982};\\\", \\\"{x:1280,y:583,t:1527023452999};\\\", \\\"{x:1267,y:580,t:1527023453016};\\\", \\\"{x:1257,y:579,t:1527023453033};\\\", \\\"{x:1243,y:577,t:1527023453050};\\\", \\\"{x:1229,y:575,t:1527023453065};\\\", \\\"{x:1220,y:574,t:1527023453083};\\\", \\\"{x:1211,y:573,t:1527023453099};\\\", \\\"{x:1206,y:572,t:1527023453116};\\\", \\\"{x:1203,y:572,t:1527023453132};\\\", \\\"{x:1201,y:572,t:1527023453150};\\\", \\\"{x:1200,y:572,t:1527023453166};\\\", \\\"{x:1199,y:572,t:1527023453279};\\\", \\\"{x:1197,y:572,t:1527023453295};\\\", \\\"{x:1196,y:572,t:1527023453303};\\\", \\\"{x:1193,y:572,t:1527023453317};\\\", \\\"{x:1190,y:572,t:1527023453332};\\\", \\\"{x:1185,y:572,t:1527023453350};\\\", \\\"{x:1181,y:572,t:1527023453367};\\\", \\\"{x:1178,y:572,t:1527023453382};\\\", \\\"{x:1174,y:572,t:1527023453400};\\\", \\\"{x:1172,y:572,t:1527023453417};\\\", \\\"{x:1170,y:572,t:1527023453434};\\\", \\\"{x:1168,y:570,t:1527023453450};\\\", \\\"{x:1164,y:570,t:1527023453467};\\\", \\\"{x:1161,y:570,t:1527023453484};\\\", \\\"{x:1155,y:569,t:1527023453500};\\\", \\\"{x:1149,y:569,t:1527023453516};\\\", \\\"{x:1141,y:568,t:1527023453533};\\\", \\\"{x:1129,y:568,t:1527023453550};\\\", \\\"{x:1123,y:567,t:1527023453566};\\\", \\\"{x:1113,y:567,t:1527023453583};\\\", \\\"{x:1108,y:566,t:1527023453600};\\\", \\\"{x:1106,y:566,t:1527023453616};\\\", \\\"{x:1103,y:566,t:1527023453634};\\\", \\\"{x:1102,y:566,t:1527023453655};\\\", \\\"{x:1101,y:566,t:1527023453666};\\\", \\\"{x:1100,y:566,t:1527023453684};\\\", \\\"{x:1099,y:566,t:1527023453712};\\\", \\\"{x:1098,y:566,t:1527023453800};\\\", \\\"{x:1097,y:566,t:1527023453824};\\\", \\\"{x:1096,y:567,t:1527023453945};\\\", \\\"{x:1095,y:568,t:1527023453952};\\\", \\\"{x:1093,y:571,t:1527023453968};\\\", \\\"{x:1091,y:576,t:1527023453984};\\\", \\\"{x:1085,y:583,t:1527023454001};\\\", \\\"{x:1082,y:590,t:1527023454018};\\\", \\\"{x:1078,y:597,t:1527023454035};\\\", \\\"{x:1074,y:606,t:1527023454051};\\\", \\\"{x:1070,y:614,t:1527023454068};\\\", \\\"{x:1067,y:621,t:1527023454085};\\\", \\\"{x:1064,y:628,t:1527023454101};\\\", \\\"{x:1062,y:636,t:1527023454119};\\\", \\\"{x:1058,y:644,t:1527023454135};\\\", \\\"{x:1057,y:649,t:1527023454152};\\\", \\\"{x:1057,y:654,t:1527023454169};\\\", \\\"{x:1057,y:657,t:1527023454185};\\\", \\\"{x:1057,y:664,t:1527023454201};\\\", \\\"{x:1057,y:671,t:1527023454218};\\\", \\\"{x:1057,y:674,t:1527023454235};\\\", \\\"{x:1059,y:679,t:1527023454252};\\\", \\\"{x:1059,y:682,t:1527023454269};\\\", \\\"{x:1059,y:687,t:1527023454286};\\\", \\\"{x:1061,y:691,t:1527023454303};\\\", \\\"{x:1061,y:695,t:1527023454318};\\\", \\\"{x:1061,y:698,t:1527023454335};\\\", \\\"{x:1062,y:701,t:1527023454351};\\\", \\\"{x:1062,y:703,t:1527023454368};\\\", \\\"{x:1062,y:706,t:1527023454385};\\\", \\\"{x:1062,y:710,t:1527023454401};\\\", \\\"{x:1064,y:715,t:1527023454418};\\\", \\\"{x:1065,y:720,t:1527023454435};\\\", \\\"{x:1067,y:725,t:1527023454451};\\\", \\\"{x:1068,y:728,t:1527023454468};\\\", \\\"{x:1071,y:733,t:1527023454484};\\\", \\\"{x:1077,y:744,t:1527023454502};\\\", \\\"{x:1082,y:750,t:1527023454519};\\\", \\\"{x:1085,y:755,t:1527023454535};\\\", \\\"{x:1090,y:762,t:1527023454555};\\\", \\\"{x:1093,y:767,t:1527023454572};\\\", \\\"{x:1096,y:771,t:1527023454588};\\\", \\\"{x:1098,y:774,t:1527023454605};\\\", \\\"{x:1099,y:777,t:1527023454623};\\\", \\\"{x:1101,y:779,t:1527023454638};\\\", \\\"{x:1101,y:780,t:1527023454655};\\\", \\\"{x:1102,y:781,t:1527023454675};\\\", \\\"{x:1102,y:782,t:1527023454691};\\\", \\\"{x:1101,y:782,t:1527023454844};\\\", \\\"{x:1097,y:781,t:1527023454859};\\\", \\\"{x:1095,y:779,t:1527023454873};\\\", \\\"{x:1088,y:772,t:1527023454889};\\\", \\\"{x:1080,y:765,t:1527023454906};\\\", \\\"{x:1074,y:760,t:1527023454923};\\\", \\\"{x:1070,y:755,t:1527023454939};\\\", \\\"{x:1068,y:752,t:1527023454957};\\\", \\\"{x:1067,y:750,t:1527023454972};\\\", \\\"{x:1067,y:749,t:1527023454989};\\\", \\\"{x:1067,y:748,t:1527023455007};\\\", \\\"{x:1067,y:747,t:1527023455023};\\\", \\\"{x:1067,y:746,t:1527023455039};\\\", \\\"{x:1067,y:744,t:1527023455056};\\\", \\\"{x:1068,y:743,t:1527023455073};\\\", \\\"{x:1070,y:741,t:1527023455089};\\\", \\\"{x:1075,y:739,t:1527023455107};\\\", \\\"{x:1082,y:735,t:1527023455124};\\\", \\\"{x:1086,y:733,t:1527023455139};\\\", \\\"{x:1093,y:731,t:1527023455156};\\\", \\\"{x:1097,y:729,t:1527023455173};\\\", \\\"{x:1100,y:727,t:1527023455189};\\\", \\\"{x:1104,y:726,t:1527023455207};\\\", \\\"{x:1108,y:724,t:1527023455224};\\\", \\\"{x:1110,y:723,t:1527023455239};\\\", \\\"{x:1112,y:722,t:1527023455256};\\\", \\\"{x:1113,y:720,t:1527023455273};\\\", \\\"{x:1113,y:719,t:1527023455290};\\\", \\\"{x:1115,y:717,t:1527023455306};\\\", \\\"{x:1115,y:716,t:1527023455324};\\\", \\\"{x:1116,y:714,t:1527023455340};\\\", \\\"{x:1118,y:712,t:1527023455356};\\\", \\\"{x:1118,y:710,t:1527023455373};\\\", \\\"{x:1120,y:709,t:1527023455390};\\\", \\\"{x:1121,y:707,t:1527023455406};\\\", \\\"{x:1122,y:706,t:1527023455423};\\\", \\\"{x:1123,y:705,t:1527023455440};\\\", \\\"{x:1123,y:704,t:1527023455456};\\\", \\\"{x:1125,y:703,t:1527023455473};\\\", \\\"{x:1126,y:703,t:1527023455490};\\\", \\\"{x:1128,y:702,t:1527023455506};\\\", \\\"{x:1132,y:701,t:1527023455523};\\\", \\\"{x:1132,y:700,t:1527023455541};\\\", \\\"{x:1134,y:699,t:1527023455557};\\\", \\\"{x:1136,y:698,t:1527023455573};\\\", \\\"{x:1137,y:698,t:1527023455590};\\\", \\\"{x:1139,y:700,t:1527023455787};\\\", \\\"{x:1143,y:707,t:1527023455794};\\\", \\\"{x:1146,y:714,t:1527023455807};\\\", \\\"{x:1153,y:722,t:1527023455824};\\\", \\\"{x:1159,y:730,t:1527023455840};\\\", \\\"{x:1166,y:737,t:1527023455857};\\\", \\\"{x:1169,y:741,t:1527023455874};\\\", \\\"{x:1173,y:745,t:1527023455891};\\\", \\\"{x:1175,y:748,t:1527023455907};\\\", \\\"{x:1176,y:750,t:1527023455924};\\\", \\\"{x:1177,y:751,t:1527023455940};\\\", \\\"{x:1178,y:751,t:1527023456068};\\\", \\\"{x:1180,y:751,t:1527023456083};\\\", \\\"{x:1182,y:751,t:1527023456107};\\\", \\\"{x:1183,y:751,t:1527023456124};\\\", \\\"{x:1184,y:751,t:1527023456142};\\\", \\\"{x:1186,y:751,t:1527023456158};\\\", \\\"{x:1187,y:751,t:1527023456175};\\\", \\\"{x:1186,y:752,t:1527023456468};\\\", \\\"{x:1186,y:753,t:1527023456475};\\\", \\\"{x:1185,y:754,t:1527023456492};\\\", \\\"{x:1185,y:755,t:1527023456509};\\\", \\\"{x:1183,y:756,t:1527023456525};\\\", \\\"{x:1182,y:756,t:1527023456547};\\\", \\\"{x:1181,y:756,t:1527023456563};\\\", \\\"{x:1180,y:756,t:1527023456576};\\\", \\\"{x:1177,y:758,t:1527023456592};\\\", \\\"{x:1174,y:758,t:1527023456608};\\\", \\\"{x:1170,y:758,t:1527023456625};\\\", \\\"{x:1167,y:759,t:1527023456643};\\\", \\\"{x:1162,y:759,t:1527023456659};\\\", \\\"{x:1157,y:759,t:1527023456676};\\\", \\\"{x:1154,y:759,t:1527023456693};\\\", \\\"{x:1150,y:759,t:1527023456709};\\\", \\\"{x:1146,y:758,t:1527023456725};\\\", \\\"{x:1144,y:756,t:1527023456742};\\\", \\\"{x:1142,y:751,t:1527023456759};\\\", \\\"{x:1138,y:744,t:1527023456776};\\\", \\\"{x:1136,y:733,t:1527023456792};\\\", \\\"{x:1133,y:713,t:1527023456810};\\\", \\\"{x:1131,y:689,t:1527023456826};\\\", \\\"{x:1128,y:667,t:1527023456843};\\\", \\\"{x:1122,y:635,t:1527023456860};\\\", \\\"{x:1120,y:618,t:1527023456875};\\\", \\\"{x:1119,y:606,t:1527023456892};\\\", \\\"{x:1116,y:589,t:1527023456909};\\\", \\\"{x:1115,y:573,t:1527023456925};\\\", \\\"{x:1111,y:563,t:1527023456943};\\\", \\\"{x:1109,y:556,t:1527023456960};\\\", \\\"{x:1108,y:553,t:1527023456975};\\\", \\\"{x:1105,y:548,t:1527023456993};\\\", \\\"{x:1102,y:544,t:1527023457009};\\\", \\\"{x:1101,y:541,t:1527023457026};\\\", \\\"{x:1099,y:537,t:1527023457042};\\\", \\\"{x:1095,y:528,t:1527023457059};\\\", \\\"{x:1092,y:520,t:1527023457076};\\\", \\\"{x:1090,y:516,t:1527023457092};\\\", \\\"{x:1090,y:514,t:1527023457156};\\\", \\\"{x:1090,y:513,t:1527023457171};\\\", \\\"{x:1091,y:513,t:1527023457188};\\\", \\\"{x:1093,y:513,t:1527023457195};\\\", \\\"{x:1095,y:512,t:1527023457209};\\\", \\\"{x:1102,y:510,t:1527023457227};\\\", \\\"{x:1119,y:510,t:1527023457243};\\\", \\\"{x:1129,y:510,t:1527023457259};\\\", \\\"{x:1142,y:510,t:1527023457277};\\\", \\\"{x:1154,y:510,t:1527023457293};\\\", \\\"{x:1161,y:510,t:1527023457310};\\\", \\\"{x:1172,y:510,t:1527023457327};\\\", \\\"{x:1183,y:510,t:1527023457343};\\\", \\\"{x:1193,y:509,t:1527023457360};\\\", \\\"{x:1201,y:509,t:1527023457376};\\\", \\\"{x:1211,y:509,t:1527023457393};\\\", \\\"{x:1224,y:509,t:1527023457410};\\\", \\\"{x:1236,y:509,t:1527023457427};\\\", \\\"{x:1259,y:509,t:1527023457444};\\\", \\\"{x:1273,y:508,t:1527023457461};\\\", \\\"{x:1284,y:508,t:1527023457479};\\\", \\\"{x:1292,y:508,t:1527023457493};\\\", \\\"{x:1295,y:508,t:1527023457510};\\\", \\\"{x:1298,y:506,t:1527023457526};\\\", \\\"{x:1302,y:506,t:1527023457543};\\\", \\\"{x:1305,y:505,t:1527023457560};\\\", \\\"{x:1307,y:505,t:1527023457576};\\\", \\\"{x:1310,y:505,t:1527023457593};\\\", \\\"{x:1318,y:505,t:1527023457610};\\\", \\\"{x:1324,y:504,t:1527023457626};\\\", \\\"{x:1333,y:502,t:1527023457643};\\\", \\\"{x:1340,y:502,t:1527023457660};\\\", \\\"{x:1344,y:502,t:1527023457677};\\\", \\\"{x:1348,y:502,t:1527023457693};\\\", \\\"{x:1358,y:502,t:1527023457710};\\\", \\\"{x:1370,y:502,t:1527023457728};\\\", \\\"{x:1380,y:502,t:1527023457743};\\\", \\\"{x:1390,y:502,t:1527023457761};\\\", \\\"{x:1404,y:502,t:1527023457778};\\\", \\\"{x:1417,y:502,t:1527023457793};\\\", \\\"{x:1424,y:502,t:1527023457810};\\\", \\\"{x:1430,y:502,t:1527023457827};\\\", \\\"{x:1431,y:502,t:1527023457844};\\\", \\\"{x:1433,y:502,t:1527023457861};\\\", \\\"{x:1434,y:502,t:1527023457916};\\\", \\\"{x:1435,y:502,t:1527023457948};\\\", \\\"{x:1436,y:502,t:1527023458140};\\\", \\\"{x:1432,y:503,t:1527023458156};\\\", \\\"{x:1425,y:503,t:1527023458164};\\\", \\\"{x:1416,y:504,t:1527023458177};\\\", \\\"{x:1390,y:507,t:1527023458195};\\\", \\\"{x:1308,y:513,t:1527023458211};\\\", \\\"{x:1216,y:513,t:1527023458228};\\\", \\\"{x:1103,y:515,t:1527023458244};\\\", \\\"{x:970,y:515,t:1527023458262};\\\", \\\"{x:831,y:514,t:1527023458279};\\\", \\\"{x:703,y:508,t:1527023458295};\\\", \\\"{x:516,y:479,t:1527023458328};\\\", \\\"{x:476,y:472,t:1527023458341};\\\", \\\"{x:455,y:469,t:1527023458356};\\\", \\\"{x:448,y:467,t:1527023458373};\\\", \\\"{x:447,y:467,t:1527023458467};\\\", \\\"{x:446,y:467,t:1527023458474};\\\", \\\"{x:444,y:467,t:1527023458490};\\\", \\\"{x:447,y:467,t:1527023458579};\\\", \\\"{x:454,y:467,t:1527023458591};\\\", \\\"{x:470,y:467,t:1527023458608};\\\", \\\"{x:497,y:467,t:1527023458624};\\\", \\\"{x:535,y:467,t:1527023458640};\\\", \\\"{x:569,y:467,t:1527023458658};\\\", \\\"{x:603,y:467,t:1527023458675};\\\", \\\"{x:611,y:467,t:1527023458691};\\\", \\\"{x:619,y:467,t:1527023458707};\\\", \\\"{x:620,y:467,t:1527023458844};\\\", \\\"{x:620,y:466,t:1527023458857};\\\", \\\"{x:620,y:465,t:1527023458874};\\\", \\\"{x:620,y:464,t:1527023458892};\\\", \\\"{x:617,y:461,t:1527023458907};\\\", \\\"{x:617,y:458,t:1527023458924};\\\", \\\"{x:617,y:457,t:1527023458955};\\\", \\\"{x:617,y:456,t:1527023458971};\\\", \\\"{x:617,y:455,t:1527023458986};\\\", \\\"{x:617,y:454,t:1527023459386};\\\", \\\"{x:610,y:454,t:1527023459402};\\\", \\\"{x:603,y:454,t:1527023459410};\\\", \\\"{x:594,y:457,t:1527023459424};\\\", \\\"{x:571,y:464,t:1527023459441};\\\", \\\"{x:541,y:470,t:1527023459457};\\\", \\\"{x:493,y:481,t:1527023459474};\\\", \\\"{x:462,y:487,t:1527023459491};\\\", \\\"{x:427,y:491,t:1527023459507};\\\", \\\"{x:399,y:494,t:1527023459524};\\\", \\\"{x:370,y:494,t:1527023459541};\\\", \\\"{x:339,y:494,t:1527023459557};\\\", \\\"{x:309,y:496,t:1527023459574};\\\", \\\"{x:291,y:496,t:1527023459591};\\\", \\\"{x:271,y:497,t:1527023459608};\\\", \\\"{x:257,y:499,t:1527023459624};\\\", \\\"{x:241,y:500,t:1527023459641};\\\", \\\"{x:226,y:500,t:1527023459658};\\\", \\\"{x:218,y:501,t:1527023459673};\\\", \\\"{x:214,y:501,t:1527023459691};\\\", \\\"{x:213,y:501,t:1527023459723};\\\", \\\"{x:212,y:502,t:1527023459731};\\\", \\\"{x:211,y:504,t:1527023459747};\\\", \\\"{x:211,y:507,t:1527023459758};\\\", \\\"{x:210,y:513,t:1527023459775};\\\", \\\"{x:210,y:517,t:1527023459791};\\\", \\\"{x:210,y:521,t:1527023459807};\\\", \\\"{x:210,y:529,t:1527023459824};\\\", \\\"{x:212,y:539,t:1527023459841};\\\", \\\"{x:222,y:552,t:1527023459860};\\\", \\\"{x:246,y:570,t:1527023459874};\\\", \\\"{x:259,y:576,t:1527023459891};\\\", \\\"{x:270,y:580,t:1527023459908};\\\", \\\"{x:285,y:587,t:1527023459924};\\\", \\\"{x:302,y:593,t:1527023459941};\\\", \\\"{x:319,y:599,t:1527023459958};\\\", \\\"{x:336,y:602,t:1527023459974};\\\", \\\"{x:349,y:604,t:1527023459991};\\\", \\\"{x:361,y:604,t:1527023460008};\\\", \\\"{x:371,y:604,t:1527023460023};\\\", \\\"{x:375,y:604,t:1527023460042};\\\", \\\"{x:378,y:604,t:1527023460058};\\\", \\\"{x:383,y:604,t:1527023460074};\\\", \\\"{x:394,y:603,t:1527023460091};\\\", \\\"{x:411,y:599,t:1527023460108};\\\", \\\"{x:429,y:592,t:1527023460125};\\\", \\\"{x:453,y:585,t:1527023460142};\\\", \\\"{x:477,y:583,t:1527023460158};\\\", \\\"{x:500,y:580,t:1527023460174};\\\", \\\"{x:522,y:577,t:1527023460192};\\\", \\\"{x:544,y:574,t:1527023460208};\\\", \\\"{x:562,y:572,t:1527023460225};\\\", \\\"{x:580,y:569,t:1527023460241};\\\", \\\"{x:590,y:568,t:1527023460258};\\\", \\\"{x:604,y:565,t:1527023460275};\\\", \\\"{x:608,y:564,t:1527023460290};\\\", \\\"{x:612,y:563,t:1527023460308};\\\", \\\"{x:622,y:561,t:1527023460324};\\\", \\\"{x:633,y:561,t:1527023460341};\\\", \\\"{x:650,y:559,t:1527023460358};\\\", \\\"{x:666,y:558,t:1527023460374};\\\", \\\"{x:687,y:554,t:1527023460390};\\\", \\\"{x:707,y:552,t:1527023460408};\\\", \\\"{x:719,y:549,t:1527023460425};\\\", \\\"{x:733,y:549,t:1527023460443};\\\", \\\"{x:751,y:549,t:1527023460458};\\\", \\\"{x:768,y:547,t:1527023460475};\\\", \\\"{x:778,y:543,t:1527023460491};\\\", \\\"{x:785,y:542,t:1527023460508};\\\", \\\"{x:788,y:540,t:1527023460525};\\\", \\\"{x:793,y:539,t:1527023460541};\\\", \\\"{x:795,y:538,t:1527023460558};\\\", \\\"{x:797,y:536,t:1527023460575};\\\", \\\"{x:802,y:533,t:1527023460591};\\\", \\\"{x:804,y:529,t:1527023460608};\\\", \\\"{x:806,y:521,t:1527023460626};\\\", \\\"{x:807,y:514,t:1527023460641};\\\", \\\"{x:808,y:509,t:1527023460659};\\\", \\\"{x:802,y:500,t:1527023460676};\\\", \\\"{x:788,y:494,t:1527023460692};\\\", \\\"{x:772,y:488,t:1527023460708};\\\", \\\"{x:760,y:485,t:1527023460725};\\\", \\\"{x:754,y:485,t:1527023460742};\\\", \\\"{x:753,y:485,t:1527023460758};\\\", \\\"{x:754,y:485,t:1527023460803};\\\", \\\"{x:760,y:485,t:1527023460810};\\\", \\\"{x:767,y:485,t:1527023460825};\\\", \\\"{x:784,y:485,t:1527023460842};\\\", \\\"{x:803,y:485,t:1527023460858};\\\", \\\"{x:820,y:485,t:1527023460875};\\\", \\\"{x:824,y:485,t:1527023460893};\\\", \\\"{x:825,y:485,t:1527023460909};\\\", \\\"{x:826,y:486,t:1527023461611};\\\", \\\"{x:827,y:488,t:1527023461626};\\\", \\\"{x:832,y:493,t:1527023461643};\\\", \\\"{x:839,y:498,t:1527023461659};\\\", \\\"{x:852,y:504,t:1527023461678};\\\", \\\"{x:868,y:512,t:1527023461692};\\\", \\\"{x:885,y:515,t:1527023461709};\\\", \\\"{x:899,y:518,t:1527023461726};\\\", \\\"{x:916,y:520,t:1527023461743};\\\", \\\"{x:929,y:523,t:1527023461759};\\\", \\\"{x:934,y:524,t:1527023461776};\\\", \\\"{x:935,y:524,t:1527023461793};\\\", \\\"{x:936,y:525,t:1527023461819};\\\", \\\"{x:937,y:525,t:1527023461826};\\\", \\\"{x:941,y:526,t:1527023461842};\\\", \\\"{x:949,y:528,t:1527023461859};\\\", \\\"{x:961,y:530,t:1527023461877};\\\", \\\"{x:975,y:530,t:1527023461893};\\\", \\\"{x:994,y:530,t:1527023461909};\\\", \\\"{x:1013,y:530,t:1527023461926};\\\", \\\"{x:1042,y:536,t:1527023461943};\\\", \\\"{x:1078,y:540,t:1527023461959};\\\", \\\"{x:1119,y:544,t:1527023461976};\\\", \\\"{x:1154,y:545,t:1527023461993};\\\", \\\"{x:1186,y:546,t:1527023462010};\\\", \\\"{x:1215,y:550,t:1527023462026};\\\", \\\"{x:1218,y:553,t:1527023462403};\\\", \\\"{x:1222,y:553,t:1527023462411};\\\", \\\"{x:1228,y:557,t:1527023462428};\\\", \\\"{x:1229,y:560,t:1527023462443};\\\", \\\"{x:1229,y:570,t:1527023462461};\\\", \\\"{x:1219,y:598,t:1527023462476};\\\", \\\"{x:1176,y:657,t:1527023462494};\\\", \\\"{x:1126,y:727,t:1527023462510};\\\", \\\"{x:1058,y:812,t:1527023462527};\\\", \\\"{x:1000,y:885,t:1527023462544};\\\", \\\"{x:952,y:950,t:1527023462560};\\\", \\\"{x:914,y:1003,t:1527023462576};\\\", \\\"{x:892,y:1035,t:1527023462594};\\\", \\\"{x:886,y:1051,t:1527023462611};\\\", \\\"{x:886,y:1053,t:1527023462627};\\\", \\\"{x:889,y:1053,t:1527023462675};\\\", \\\"{x:892,y:1051,t:1527023462683};\\\", \\\"{x:900,y:1045,t:1527023462693};\\\", \\\"{x:925,y:1023,t:1527023462710};\\\", \\\"{x:970,y:979,t:1527023462728};\\\", \\\"{x:1039,y:906,t:1527023462744};\\\", \\\"{x:1122,y:825,t:1527023462761};\\\", \\\"{x:1195,y:756,t:1527023462778};\\\", \\\"{x:1264,y:697,t:1527023462794};\\\", \\\"{x:1356,y:618,t:1527023462811};\\\", \\\"{x:1388,y:594,t:1527023462827};\\\", \\\"{x:1408,y:588,t:1527023462844};\\\", \\\"{x:1428,y:587,t:1527023462860};\\\", \\\"{x:1451,y:609,t:1527023462878};\\\", \\\"{x:1475,y:675,t:1527023462894};\\\", \\\"{x:1508,y:778,t:1527023462910};\\\", \\\"{x:1539,y:865,t:1527023462928};\\\", \\\"{x:1566,y:931,t:1527023462944};\\\", \\\"{x:1581,y:967,t:1527023462961};\\\", \\\"{x:1593,y:986,t:1527023462978};\\\", \\\"{x:1594,y:991,t:1527023462995};\\\", \\\"{x:1594,y:989,t:1527023463068};\\\", \\\"{x:1594,y:980,t:1527023463077};\\\", \\\"{x:1594,y:938,t:1527023463094};\\\", \\\"{x:1592,y:876,t:1527023463111};\\\", \\\"{x:1592,y:773,t:1527023463128};\\\", \\\"{x:1597,y:688,t:1527023463144};\\\", \\\"{x:1629,y:611,t:1527023463160};\\\", \\\"{x:1662,y:537,t:1527023463178};\\\", \\\"{x:1697,y:488,t:1527023463194};\\\", \\\"{x:1703,y:485,t:1527023463210};\\\", \\\"{x:1706,y:485,t:1527023463227};\\\", \\\"{x:1713,y:498,t:1527023463244};\\\", \\\"{x:1725,y:553,t:1527023463260};\\\", \\\"{x:1729,y:634,t:1527023463277};\\\", \\\"{x:1735,y:725,t:1527023463294};\\\", \\\"{x:1736,y:797,t:1527023463311};\\\", \\\"{x:1742,y:845,t:1527023463327};\\\", \\\"{x:1742,y:871,t:1527023463344};\\\", \\\"{x:1742,y:884,t:1527023463361};\\\", \\\"{x:1741,y:891,t:1527023463377};\\\", \\\"{x:1729,y:898,t:1527023463395};\\\", \\\"{x:1712,y:901,t:1527023463411};\\\", \\\"{x:1675,y:903,t:1527023463428};\\\", \\\"{x:1594,y:903,t:1527023463445};\\\", \\\"{x:1478,y:903,t:1527023463462};\\\", \\\"{x:1350,y:900,t:1527023463478};\\\", \\\"{x:1187,y:900,t:1527023463495};\\\", \\\"{x:1013,y:900,t:1527023463511};\\\", \\\"{x:835,y:897,t:1527023463527};\\\", \\\"{x:693,y:891,t:1527023463545};\\\", \\\"{x:592,y:881,t:1527023463562};\\\", \\\"{x:524,y:871,t:1527023463577};\\\", \\\"{x:480,y:865,t:1527023463595};\\\", \\\"{x:464,y:859,t:1527023463612};\\\", \\\"{x:452,y:854,t:1527023463628};\\\", \\\"{x:446,y:849,t:1527023463644};\\\", \\\"{x:443,y:847,t:1527023463661};\\\", \\\"{x:442,y:846,t:1527023463678};\\\", \\\"{x:442,y:843,t:1527023463695};\\\", \\\"{x:442,y:836,t:1527023463712};\\\", \\\"{x:442,y:828,t:1527023463728};\\\", \\\"{x:442,y:820,t:1527023463745};\\\", \\\"{x:447,y:801,t:1527023463762};\\\", \\\"{x:461,y:768,t:1527023463779};\\\", \\\"{x:472,y:746,t:1527023463795};\\\", \\\"{x:483,y:729,t:1527023463812};\\\", \\\"{x:493,y:714,t:1527023463829};\\\", \\\"{x:499,y:703,t:1527023463845};\\\", \\\"{x:501,y:697,t:1527023463863};\\\", \\\"{x:503,y:695,t:1527023463878};\\\", \\\"{x:504,y:694,t:1527023463894};\\\", \\\"{x:504,y:693,t:1527023463911};\\\", \\\"{x:505,y:693,t:1527023463930};\\\", \\\"{x:506,y:692,t:1527023463944};\\\", \\\"{x:508,y:689,t:1527023463962};\\\", \\\"{x:509,y:686,t:1527023463978};\\\", \\\"{x:511,y:685,t:1527023463994};\\\" ] }, { \\\"rt\\\": 21953, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 11, \\\"time_elapsed\\\": 573144, \\\"internal_node_id\\\": \\\"0.0-6.0-1.0\\\", \\\"subject\\\": \\\"QOJ6L\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"hotel\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+starts\\\", \\\"q\\\": 7, \\\"clicks\\\": 2.5, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"X\\\", \\\"O\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-10 AM-11 AM-12 PM-X -X -X -01 PM-X -4-02 PM-01 PM-04 PM-02 PM-05 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:511,y:684,t:1527023466563};\\\", \\\"{x:514,y:678,t:1527023466574};\\\", \\\"{x:517,y:670,t:1527023466580};\\\", \\\"{x:522,y:660,t:1527023466597};\\\", \\\"{x:527,y:648,t:1527023466613};\\\", \\\"{x:534,y:633,t:1527023466629};\\\", \\\"{x:537,y:626,t:1527023466646};\\\", \\\"{x:539,y:623,t:1527023466663};\\\", \\\"{x:539,y:622,t:1527023466683};\\\", \\\"{x:539,y:621,t:1527023467155};\\\", \\\"{x:539,y:620,t:1527023467171};\\\", \\\"{x:539,y:619,t:1527023467187};\\\", \\\"{x:539,y:618,t:1527023467197};\\\", \\\"{x:539,y:614,t:1527023467213};\\\", \\\"{x:532,y:614,t:1527023467230};\\\", \\\"{x:531,y:613,t:1527023467251};\\\", \\\"{x:531,y:612,t:1527023467264};\\\", \\\"{x:529,y:609,t:1527023467280};\\\", \\\"{x:527,y:607,t:1527023467298};\\\", \\\"{x:525,y:604,t:1527023467314};\\\", \\\"{x:523,y:603,t:1527023467331};\\\", \\\"{x:522,y:601,t:1527023467347};\\\", \\\"{x:521,y:600,t:1527023467363};\\\", \\\"{x:521,y:597,t:1527023467380};\\\", \\\"{x:520,y:596,t:1527023467398};\\\", \\\"{x:519,y:593,t:1527023467414};\\\", \\\"{x:518,y:592,t:1527023467431};\\\", \\\"{x:518,y:589,t:1527023467447};\\\", \\\"{x:517,y:588,t:1527023467465};\\\", \\\"{x:517,y:587,t:1527023467480};\\\", \\\"{x:516,y:585,t:1527023467497};\\\", \\\"{x:515,y:583,t:1527023467513};\\\", \\\"{x:514,y:582,t:1527023467610};\\\", \\\"{x:514,y:581,t:1527023467627};\\\", \\\"{x:513,y:580,t:1527023467635};\\\", \\\"{x:513,y:579,t:1527023467650};\\\", \\\"{x:512,y:579,t:1527023467667};\\\", \\\"{x:512,y:578,t:1527023467684};\\\", \\\"{x:512,y:577,t:1527023467697};\\\", \\\"{x:511,y:574,t:1527023468491};\\\", \\\"{x:508,y:569,t:1527023468499};\\\", \\\"{x:502,y:557,t:1527023468515};\\\", \\\"{x:491,y:542,t:1527023468532};\\\", \\\"{x:475,y:524,t:1527023468549};\\\", \\\"{x:459,y:507,t:1527023468565};\\\", \\\"{x:438,y:490,t:1527023468582};\\\", \\\"{x:418,y:475,t:1527023468599};\\\", \\\"{x:403,y:464,t:1527023468615};\\\", \\\"{x:389,y:456,t:1527023468631};\\\", \\\"{x:374,y:448,t:1527023468648};\\\", \\\"{x:362,y:440,t:1527023468665};\\\", \\\"{x:351,y:434,t:1527023468682};\\\", \\\"{x:339,y:426,t:1527023468698};\\\", \\\"{x:335,y:422,t:1527023468714};\\\", \\\"{x:333,y:421,t:1527023468731};\\\", \\\"{x:332,y:420,t:1527023468770};\\\", \\\"{x:331,y:420,t:1527023468971};\\\", \\\"{x:332,y:419,t:1527023468982};\\\", \\\"{x:334,y:417,t:1527023468999};\\\", \\\"{x:337,y:416,t:1527023469015};\\\", \\\"{x:342,y:414,t:1527023469032};\\\", \\\"{x:346,y:413,t:1527023469050};\\\", \\\"{x:354,y:410,t:1527023469065};\\\", \\\"{x:360,y:409,t:1527023469082};\\\", \\\"{x:369,y:408,t:1527023469099};\\\", \\\"{x:373,y:408,t:1527023469114};\\\", \\\"{x:374,y:407,t:1527023469131};\\\", \\\"{x:375,y:407,t:1527023469179};\\\", \\\"{x:376,y:407,t:1527023469203};\\\", \\\"{x:377,y:406,t:1527023469219};\\\", \\\"{x:378,y:406,t:1527023469243};\\\", \\\"{x:379,y:406,t:1527023469275};\\\", \\\"{x:380,y:406,t:1527023469299};\\\", \\\"{x:381,y:406,t:1527023469315};\\\", \\\"{x:382,y:405,t:1527023469333};\\\", \\\"{x:385,y:405,t:1527023469347};\\\", \\\"{x:389,y:405,t:1527023469364};\\\", \\\"{x:394,y:405,t:1527023469382};\\\", \\\"{x:399,y:405,t:1527023469397};\\\", \\\"{x:405,y:405,t:1527023469414};\\\", \\\"{x:414,y:405,t:1527023469432};\\\", \\\"{x:422,y:405,t:1527023469448};\\\", \\\"{x:435,y:405,t:1527023469465};\\\", \\\"{x:446,y:405,t:1527023469481};\\\", \\\"{x:459,y:407,t:1527023469497};\\\", \\\"{x:468,y:407,t:1527023469514};\\\", \\\"{x:472,y:407,t:1527023469531};\\\", \\\"{x:473,y:407,t:1527023469547};\\\", \\\"{x:474,y:407,t:1527023469659};\\\", \\\"{x:475,y:407,t:1527023469675};\\\", \\\"{x:477,y:407,t:1527023469683};\\\", \\\"{x:480,y:407,t:1527023469698};\\\", \\\"{x:488,y:407,t:1527023469715};\\\", \\\"{x:494,y:407,t:1527023469731};\\\", \\\"{x:500,y:407,t:1527023469748};\\\", \\\"{x:505,y:407,t:1527023469764};\\\", \\\"{x:512,y:407,t:1527023469782};\\\", \\\"{x:520,y:407,t:1527023469798};\\\", \\\"{x:525,y:407,t:1527023469815};\\\", \\\"{x:528,y:407,t:1527023469830};\\\", \\\"{x:535,y:407,t:1527023469847};\\\", \\\"{x:538,y:407,t:1527023469864};\\\", \\\"{x:543,y:407,t:1527023469880};\\\", \\\"{x:546,y:407,t:1527023469897};\\\", \\\"{x:553,y:407,t:1527023469915};\\\", \\\"{x:556,y:407,t:1527023469931};\\\", \\\"{x:561,y:408,t:1527023469947};\\\", \\\"{x:563,y:408,t:1527023469965};\\\", \\\"{x:566,y:408,t:1527023469980};\\\", \\\"{x:568,y:408,t:1527023469998};\\\", \\\"{x:571,y:409,t:1527023470015};\\\", \\\"{x:575,y:409,t:1527023470031};\\\", \\\"{x:580,y:411,t:1527023470049};\\\", \\\"{x:587,y:412,t:1527023470064};\\\", \\\"{x:600,y:412,t:1527023470081};\\\", \\\"{x:618,y:419,t:1527023470098};\\\", \\\"{x:658,y:436,t:1527023470117};\\\", \\\"{x:714,y:461,t:1527023470131};\\\", \\\"{x:788,y:491,t:1527023470148};\\\", \\\"{x:859,y:522,t:1527023470167};\\\", \\\"{x:933,y:550,t:1527023470183};\\\", \\\"{x:1007,y:577,t:1527023470200};\\\", \\\"{x:1076,y:599,t:1527023470216};\\\", \\\"{x:1129,y:613,t:1527023470233};\\\", \\\"{x:1130,y:613,t:1527023470250};\\\", \\\"{x:1131,y:614,t:1527023470676};\\\", \\\"{x:1131,y:615,t:1527023470683};\\\", \\\"{x:1133,y:617,t:1527023470700};\\\", \\\"{x:1136,y:621,t:1527023470747};\\\", \\\"{x:1137,y:621,t:1527023470763};\\\", \\\"{x:1137,y:622,t:1527023470771};\\\", \\\"{x:1137,y:623,t:1527023470784};\\\", \\\"{x:1138,y:624,t:1527023470801};\\\", \\\"{x:1139,y:627,t:1527023470817};\\\", \\\"{x:1139,y:631,t:1527023470835};\\\", \\\"{x:1140,y:637,t:1527023470851};\\\", \\\"{x:1140,y:642,t:1527023470867};\\\", \\\"{x:1142,y:646,t:1527023470884};\\\", \\\"{x:1142,y:650,t:1527023470901};\\\", \\\"{x:1142,y:655,t:1527023470917};\\\", \\\"{x:1144,y:660,t:1527023470934};\\\", \\\"{x:1146,y:665,t:1527023470951};\\\", \\\"{x:1146,y:668,t:1527023470967};\\\", \\\"{x:1148,y:674,t:1527023470984};\\\", \\\"{x:1149,y:679,t:1527023471002};\\\", \\\"{x:1149,y:686,t:1527023471017};\\\", \\\"{x:1150,y:691,t:1527023471034};\\\", \\\"{x:1156,y:701,t:1527023471051};\\\", \\\"{x:1158,y:706,t:1527023471067};\\\", \\\"{x:1161,y:713,t:1527023471083};\\\", \\\"{x:1166,y:723,t:1527023471101};\\\", \\\"{x:1167,y:728,t:1527023471116};\\\", \\\"{x:1171,y:735,t:1527023471134};\\\", \\\"{x:1173,y:741,t:1527023471150};\\\", \\\"{x:1176,y:746,t:1527023471167};\\\", \\\"{x:1180,y:752,t:1527023471183};\\\", \\\"{x:1184,y:758,t:1527023471201};\\\", \\\"{x:1188,y:763,t:1527023471217};\\\", \\\"{x:1192,y:766,t:1527023471234};\\\", \\\"{x:1198,y:771,t:1527023471251};\\\", \\\"{x:1200,y:773,t:1527023471267};\\\", \\\"{x:1203,y:775,t:1527023471283};\\\", \\\"{x:1206,y:779,t:1527023471301};\\\", \\\"{x:1211,y:785,t:1527023471317};\\\", \\\"{x:1219,y:790,t:1527023471334};\\\", \\\"{x:1228,y:790,t:1527023471351};\\\", \\\"{x:1228,y:792,t:1527023472075};\\\", \\\"{x:1228,y:793,t:1527023472086};\\\", \\\"{x:1228,y:797,t:1527023472101};\\\", \\\"{x:1228,y:804,t:1527023472118};\\\", \\\"{x:1226,y:813,t:1527023472136};\\\", \\\"{x:1221,y:824,t:1527023472152};\\\", \\\"{x:1216,y:837,t:1527023472169};\\\", \\\"{x:1212,y:850,t:1527023472185};\\\", \\\"{x:1206,y:863,t:1527023472202};\\\", \\\"{x:1204,y:871,t:1527023472218};\\\", \\\"{x:1197,y:884,t:1527023472235};\\\", \\\"{x:1196,y:889,t:1527023472251};\\\", \\\"{x:1193,y:894,t:1527023472268};\\\", \\\"{x:1192,y:897,t:1527023472285};\\\", \\\"{x:1192,y:899,t:1527023472302};\\\", \\\"{x:1192,y:901,t:1527023472318};\\\", \\\"{x:1192,y:903,t:1527023472334};\\\", \\\"{x:1191,y:905,t:1527023472352};\\\", \\\"{x:1191,y:906,t:1527023472368};\\\", \\\"{x:1191,y:909,t:1527023472384};\\\", \\\"{x:1191,y:910,t:1527023472402};\\\", \\\"{x:1191,y:912,t:1527023472418};\\\", \\\"{x:1191,y:913,t:1527023472443};\\\", \\\"{x:1191,y:914,t:1527023472459};\\\", \\\"{x:1191,y:915,t:1527023472475};\\\", \\\"{x:1191,y:916,t:1527023472524};\\\", \\\"{x:1191,y:917,t:1527023472563};\\\", \\\"{x:1191,y:918,t:1527023472603};\\\", \\\"{x:1192,y:919,t:1527023473020};\\\", \\\"{x:1193,y:919,t:1527023473035};\\\", \\\"{x:1200,y:921,t:1527023473052};\\\", \\\"{x:1210,y:921,t:1527023473069};\\\", \\\"{x:1224,y:921,t:1527023473086};\\\", \\\"{x:1239,y:921,t:1527023473103};\\\", \\\"{x:1260,y:921,t:1527023473119};\\\", \\\"{x:1280,y:921,t:1527023473137};\\\", \\\"{x:1302,y:921,t:1527023473153};\\\", \\\"{x:1322,y:921,t:1527023473170};\\\", \\\"{x:1341,y:921,t:1527023473187};\\\", \\\"{x:1358,y:919,t:1527023473203};\\\", \\\"{x:1377,y:916,t:1527023473219};\\\", \\\"{x:1385,y:915,t:1527023473236};\\\", \\\"{x:1390,y:914,t:1527023473252};\\\", \\\"{x:1393,y:913,t:1527023473269};\\\", \\\"{x:1395,y:913,t:1527023473286};\\\", \\\"{x:1395,y:912,t:1527023473302};\\\", \\\"{x:1396,y:912,t:1527023473319};\\\", \\\"{x:1398,y:911,t:1527023473362};\\\", \\\"{x:1399,y:910,t:1527023473386};\\\", \\\"{x:1400,y:909,t:1527023473402};\\\", \\\"{x:1401,y:909,t:1527023473419};\\\", \\\"{x:1401,y:908,t:1527023473436};\\\", \\\"{x:1401,y:907,t:1527023473452};\\\", \\\"{x:1402,y:906,t:1527023473469};\\\", \\\"{x:1402,y:905,t:1527023473491};\\\", \\\"{x:1402,y:904,t:1527023473507};\\\", \\\"{x:1403,y:903,t:1527023473530};\\\", \\\"{x:1403,y:901,t:1527023473539};\\\", \\\"{x:1404,y:900,t:1527023473553};\\\", \\\"{x:1405,y:898,t:1527023473569};\\\", \\\"{x:1406,y:894,t:1527023473586};\\\", \\\"{x:1410,y:888,t:1527023473603};\\\", \\\"{x:1413,y:885,t:1527023473619};\\\", \\\"{x:1416,y:880,t:1527023473636};\\\", \\\"{x:1421,y:873,t:1527023473653};\\\", \\\"{x:1424,y:869,t:1527023473669};\\\", \\\"{x:1428,y:864,t:1527023473686};\\\", \\\"{x:1432,y:859,t:1527023473703};\\\", \\\"{x:1434,y:855,t:1527023473719};\\\", \\\"{x:1436,y:853,t:1527023473736};\\\", \\\"{x:1438,y:851,t:1527023473753};\\\", \\\"{x:1440,y:849,t:1527023473769};\\\", \\\"{x:1443,y:846,t:1527023473787};\\\", \\\"{x:1447,y:841,t:1527023473804};\\\", \\\"{x:1449,y:839,t:1527023473820};\\\", \\\"{x:1449,y:840,t:1527023473931};\\\", \\\"{x:1449,y:844,t:1527023473940};\\\", \\\"{x:1449,y:850,t:1527023473953};\\\", \\\"{x:1448,y:857,t:1527023473971};\\\", \\\"{x:1446,y:866,t:1527023473986};\\\", \\\"{x:1443,y:874,t:1527023474003};\\\", \\\"{x:1441,y:878,t:1527023474021};\\\", \\\"{x:1440,y:882,t:1527023474036};\\\", \\\"{x:1439,y:884,t:1527023474053};\\\", \\\"{x:1437,y:885,t:1527023474071};\\\", \\\"{x:1438,y:885,t:1527023474148};\\\", \\\"{x:1439,y:881,t:1527023474155};\\\", \\\"{x:1441,y:875,t:1527023474170};\\\", \\\"{x:1446,y:858,t:1527023474187};\\\", \\\"{x:1459,y:820,t:1527023474204};\\\", \\\"{x:1469,y:796,t:1527023474221};\\\", \\\"{x:1477,y:778,t:1527023474238};\\\", \\\"{x:1483,y:759,t:1527023474253};\\\", \\\"{x:1488,y:747,t:1527023474270};\\\", \\\"{x:1492,y:737,t:1527023474286};\\\", \\\"{x:1494,y:731,t:1527023474303};\\\", \\\"{x:1496,y:726,t:1527023474320};\\\", \\\"{x:1498,y:719,t:1527023474337};\\\", \\\"{x:1500,y:716,t:1527023474353};\\\", \\\"{x:1502,y:713,t:1527023474371};\\\", \\\"{x:1503,y:711,t:1527023474387};\\\", \\\"{x:1503,y:712,t:1527023474611};\\\", \\\"{x:1502,y:718,t:1527023474620};\\\", \\\"{x:1496,y:734,t:1527023474637};\\\", \\\"{x:1484,y:769,t:1527023474671};\\\", \\\"{x:1475,y:787,t:1527023474687};\\\", \\\"{x:1468,y:809,t:1527023474702};\\\", \\\"{x:1462,y:831,t:1527023474720};\\\", \\\"{x:1452,y:858,t:1527023474736};\\\", \\\"{x:1446,y:882,t:1527023474753};\\\", \\\"{x:1440,y:903,t:1527023474770};\\\", \\\"{x:1436,y:919,t:1527023474786};\\\", \\\"{x:1435,y:925,t:1527023474803};\\\", \\\"{x:1435,y:929,t:1527023474819};\\\", \\\"{x:1433,y:931,t:1527023474837};\\\", \\\"{x:1433,y:930,t:1527023475354};\\\", \\\"{x:1434,y:927,t:1527023475370};\\\", \\\"{x:1434,y:924,t:1527023475386};\\\", \\\"{x:1434,y:923,t:1527023475404};\\\", \\\"{x:1435,y:922,t:1527023475420};\\\", \\\"{x:1436,y:921,t:1527023475437};\\\", \\\"{x:1436,y:920,t:1527023475454};\\\", \\\"{x:1436,y:919,t:1527023475471};\\\", \\\"{x:1437,y:919,t:1527023475487};\\\", \\\"{x:1437,y:917,t:1527023475504};\\\", \\\"{x:1438,y:916,t:1527023475522};\\\", \\\"{x:1439,y:915,t:1527023475547};\\\", \\\"{x:1440,y:913,t:1527023476122};\\\", \\\"{x:1442,y:911,t:1527023476138};\\\", \\\"{x:1445,y:902,t:1527023476155};\\\", \\\"{x:1453,y:886,t:1527023476171};\\\", \\\"{x:1458,y:875,t:1527023476188};\\\", \\\"{x:1465,y:860,t:1527023476205};\\\", \\\"{x:1471,y:845,t:1527023476221};\\\", \\\"{x:1475,y:833,t:1527023476239};\\\", \\\"{x:1480,y:824,t:1527023476255};\\\", \\\"{x:1484,y:812,t:1527023476271};\\\", \\\"{x:1487,y:805,t:1527023476288};\\\", \\\"{x:1490,y:800,t:1527023476305};\\\", \\\"{x:1492,y:795,t:1527023476322};\\\", \\\"{x:1495,y:790,t:1527023476339};\\\", \\\"{x:1495,y:788,t:1527023476356};\\\", \\\"{x:1498,y:784,t:1527023476372};\\\", \\\"{x:1499,y:781,t:1527023476389};\\\", \\\"{x:1500,y:778,t:1527023476405};\\\", \\\"{x:1501,y:776,t:1527023476421};\\\", \\\"{x:1502,y:774,t:1527023476443};\\\", \\\"{x:1503,y:772,t:1527023476456};\\\", \\\"{x:1503,y:771,t:1527023476472};\\\", \\\"{x:1503,y:769,t:1527023476489};\\\", \\\"{x:1503,y:767,t:1527023476506};\\\", \\\"{x:1504,y:765,t:1527023476521};\\\", \\\"{x:1504,y:764,t:1527023476539};\\\", \\\"{x:1505,y:761,t:1527023476555};\\\", \\\"{x:1506,y:757,t:1527023476572};\\\", \\\"{x:1507,y:752,t:1527023476588};\\\", \\\"{x:1507,y:747,t:1527023476605};\\\", \\\"{x:1507,y:742,t:1527023476623};\\\", \\\"{x:1508,y:736,t:1527023476639};\\\", \\\"{x:1509,y:730,t:1527023476656};\\\", \\\"{x:1509,y:725,t:1527023476672};\\\", \\\"{x:1509,y:720,t:1527023476689};\\\", \\\"{x:1509,y:718,t:1527023476706};\\\", \\\"{x:1509,y:715,t:1527023476722};\\\", \\\"{x:1509,y:713,t:1527023476739};\\\", \\\"{x:1509,y:715,t:1527023476987};\\\", \\\"{x:1506,y:721,t:1527023476995};\\\", \\\"{x:1502,y:729,t:1527023477005};\\\", \\\"{x:1497,y:743,t:1527023477023};\\\", \\\"{x:1490,y:757,t:1527023477040};\\\", \\\"{x:1487,y:767,t:1527023477056};\\\", \\\"{x:1481,y:779,t:1527023477073};\\\", \\\"{x:1477,y:791,t:1527023477091};\\\", \\\"{x:1472,y:802,t:1527023477106};\\\", \\\"{x:1466,y:811,t:1527023477122};\\\", \\\"{x:1461,y:819,t:1527023477139};\\\", \\\"{x:1455,y:829,t:1527023477156};\\\", \\\"{x:1451,y:835,t:1527023477173};\\\", \\\"{x:1447,y:839,t:1527023477189};\\\", \\\"{x:1432,y:847,t:1527023477206};\\\", \\\"{x:1409,y:854,t:1527023477223};\\\", \\\"{x:1360,y:857,t:1527023477240};\\\", \\\"{x:1277,y:857,t:1527023477256};\\\", \\\"{x:1173,y:848,t:1527023477272};\\\", \\\"{x:1029,y:831,t:1527023477290};\\\", \\\"{x:889,y:801,t:1527023477305};\\\", \\\"{x:745,y:760,t:1527023477322};\\\", \\\"{x:548,y:698,t:1527023477340};\\\", \\\"{x:465,y:673,t:1527023477356};\\\", \\\"{x:428,y:660,t:1527023477372};\\\", \\\"{x:415,y:655,t:1527023477389};\\\", \\\"{x:412,y:653,t:1527023477405};\\\", \\\"{x:412,y:652,t:1527023477422};\\\", \\\"{x:412,y:650,t:1527023477438};\\\", \\\"{x:410,y:649,t:1527023477456};\\\", \\\"{x:410,y:647,t:1527023477812};\\\", \\\"{x:429,y:639,t:1527023477823};\\\", \\\"{x:459,y:627,t:1527023477840};\\\", \\\"{x:499,y:621,t:1527023477856};\\\", \\\"{x:537,y:617,t:1527023477873};\\\", \\\"{x:575,y:611,t:1527023477888};\\\", \\\"{x:623,y:601,t:1527023477905};\\\", \\\"{x:649,y:596,t:1527023477922};\\\", \\\"{x:671,y:594,t:1527023477938};\\\", \\\"{x:686,y:591,t:1527023477956};\\\", \\\"{x:696,y:588,t:1527023477973};\\\", \\\"{x:704,y:585,t:1527023477989};\\\", \\\"{x:710,y:581,t:1527023478006};\\\", \\\"{x:717,y:577,t:1527023478024};\\\", \\\"{x:726,y:572,t:1527023478039};\\\", \\\"{x:736,y:566,t:1527023478056};\\\", \\\"{x:746,y:561,t:1527023478072};\\\", \\\"{x:758,y:555,t:1527023478090};\\\", \\\"{x:770,y:548,t:1527023478105};\\\", \\\"{x:787,y:543,t:1527023478123};\\\", \\\"{x:797,y:539,t:1527023478140};\\\", \\\"{x:810,y:536,t:1527023478156};\\\", \\\"{x:819,y:533,t:1527023478173};\\\", \\\"{x:827,y:532,t:1527023478190};\\\", \\\"{x:831,y:532,t:1527023478205};\\\", \\\"{x:833,y:532,t:1527023478223};\\\", \\\"{x:835,y:532,t:1527023478240};\\\", \\\"{x:838,y:531,t:1527023478255};\\\", \\\"{x:838,y:530,t:1527023478273};\\\", \\\"{x:840,y:530,t:1527023478290};\\\", \\\"{x:838,y:530,t:1527023478570};\\\", \\\"{x:829,y:530,t:1527023478578};\\\", \\\"{x:814,y:530,t:1527023478590};\\\", \\\"{x:785,y:529,t:1527023478607};\\\", \\\"{x:744,y:527,t:1527023478623};\\\", \\\"{x:691,y:521,t:1527023478640};\\\", \\\"{x:639,y:516,t:1527023478658};\\\", \\\"{x:601,y:514,t:1527023478673};\\\", \\\"{x:559,y:509,t:1527023478690};\\\", \\\"{x:547,y:507,t:1527023478707};\\\", \\\"{x:546,y:507,t:1527023478723};\\\", \\\"{x:545,y:507,t:1527023478746};\\\", \\\"{x:545,y:506,t:1527023478757};\\\", \\\"{x:546,y:507,t:1527023478915};\\\", \\\"{x:548,y:508,t:1527023478924};\\\", \\\"{x:554,y:511,t:1527023478940};\\\", \\\"{x:559,y:513,t:1527023478957};\\\", \\\"{x:563,y:515,t:1527023478973};\\\", \\\"{x:567,y:516,t:1527023478990};\\\", \\\"{x:568,y:517,t:1527023479007};\\\", \\\"{x:569,y:517,t:1527023479024};\\\", \\\"{x:570,y:517,t:1527023479058};\\\", \\\"{x:571,y:517,t:1527023479506};\\\", \\\"{x:572,y:517,t:1527023479524};\\\", \\\"{x:573,y:517,t:1527023479541};\\\", \\\"{x:576,y:517,t:1527023479557};\\\", \\\"{x:577,y:517,t:1527023479595};\\\", \\\"{x:579,y:518,t:1527023479607};\\\", \\\"{x:580,y:519,t:1527023479626};\\\", \\\"{x:581,y:519,t:1527023479659};\\\", \\\"{x:583,y:519,t:1527023479788};\\\", \\\"{x:584,y:519,t:1527023479803};\\\", \\\"{x:585,y:519,t:1527023479810};\\\", \\\"{x:586,y:519,t:1527023479824};\\\", \\\"{x:589,y:519,t:1527023479842};\\\", \\\"{x:592,y:519,t:1527023479858};\\\", \\\"{x:596,y:519,t:1527023479874};\\\", \\\"{x:601,y:519,t:1527023479892};\\\", \\\"{x:606,y:519,t:1527023479908};\\\", \\\"{x:607,y:518,t:1527023479924};\\\", \\\"{x:608,y:518,t:1527023479941};\\\", \\\"{x:609,y:518,t:1527023480114};\\\", \\\"{x:612,y:518,t:1527023480124};\\\", \\\"{x:620,y:521,t:1527023480140};\\\", \\\"{x:634,y:527,t:1527023480158};\\\", \\\"{x:649,y:531,t:1527023480174};\\\", \\\"{x:662,y:533,t:1527023480190};\\\", \\\"{x:674,y:535,t:1527023480208};\\\", \\\"{x:685,y:538,t:1527023480225};\\\", \\\"{x:697,y:542,t:1527023480241};\\\", \\\"{x:714,y:547,t:1527023480258};\\\", \\\"{x:720,y:548,t:1527023480275};\\\", \\\"{x:724,y:550,t:1527023480292};\\\", \\\"{x:726,y:551,t:1527023480308};\\\", \\\"{x:731,y:553,t:1527023480324};\\\", \\\"{x:767,y:564,t:1527023480341};\\\", \\\"{x:860,y:589,t:1527023480358};\\\", \\\"{x:960,y:619,t:1527023480375};\\\", \\\"{x:1059,y:639,t:1527023480391};\\\", \\\"{x:1161,y:653,t:1527023480408};\\\", \\\"{x:1267,y:671,t:1527023480424};\\\", \\\"{x:1371,y:693,t:1527023480441};\\\", \\\"{x:1437,y:708,t:1527023480458};\\\", \\\"{x:1437,y:709,t:1527023480827};\\\", \\\"{x:1439,y:711,t:1527023480841};\\\", \\\"{x:1442,y:712,t:1527023480858};\\\", \\\"{x:1444,y:713,t:1527023480874};\\\", \\\"{x:1452,y:719,t:1527023480891};\\\", \\\"{x:1462,y:725,t:1527023480908};\\\", \\\"{x:1473,y:729,t:1527023480923};\\\", \\\"{x:1484,y:730,t:1527023480940};\\\", \\\"{x:1495,y:732,t:1527023480957};\\\", \\\"{x:1505,y:733,t:1527023480973};\\\", \\\"{x:1514,y:733,t:1527023480990};\\\", \\\"{x:1521,y:733,t:1527023481007};\\\", \\\"{x:1531,y:734,t:1527023481023};\\\", \\\"{x:1538,y:736,t:1527023481040};\\\", \\\"{x:1545,y:737,t:1527023481057};\\\", \\\"{x:1548,y:738,t:1527023481073};\\\", \\\"{x:1550,y:738,t:1527023481091};\\\", \\\"{x:1551,y:741,t:1527023481131};\\\", \\\"{x:1553,y:743,t:1527023481141};\\\", \\\"{x:1553,y:754,t:1527023481156};\\\", \\\"{x:1553,y:774,t:1527023481174};\\\", \\\"{x:1550,y:799,t:1527023481190};\\\", \\\"{x:1541,y:834,t:1527023481207};\\\", \\\"{x:1522,y:874,t:1527023481223};\\\", \\\"{x:1493,y:921,t:1527023481240};\\\", \\\"{x:1467,y:962,t:1527023481257};\\\", \\\"{x:1440,y:989,t:1527023481274};\\\", \\\"{x:1420,y:1004,t:1527023481290};\\\", \\\"{x:1394,y:1017,t:1527023481307};\\\", \\\"{x:1382,y:1020,t:1527023481322};\\\", \\\"{x:1376,y:1020,t:1527023481339};\\\", \\\"{x:1375,y:1021,t:1527023481356};\\\", \\\"{x:1374,y:1021,t:1527023481459};\\\", \\\"{x:1373,y:1018,t:1527023481473};\\\", \\\"{x:1373,y:1014,t:1527023481489};\\\", \\\"{x:1373,y:1006,t:1527023481507};\\\", \\\"{x:1373,y:998,t:1527023481523};\\\", \\\"{x:1373,y:993,t:1527023481540};\\\", \\\"{x:1373,y:989,t:1527023481555};\\\", \\\"{x:1377,y:983,t:1527023481572};\\\", \\\"{x:1381,y:976,t:1527023481590};\\\", \\\"{x:1384,y:969,t:1527023481606};\\\", \\\"{x:1388,y:961,t:1527023481623};\\\", \\\"{x:1390,y:956,t:1527023481639};\\\", \\\"{x:1392,y:953,t:1527023481656};\\\", \\\"{x:1393,y:951,t:1527023481672};\\\", \\\"{x:1395,y:948,t:1527023481690};\\\", \\\"{x:1396,y:944,t:1527023481705};\\\", \\\"{x:1399,y:939,t:1527023481723};\\\", \\\"{x:1399,y:938,t:1527023481739};\\\", \\\"{x:1400,y:937,t:1527023481755};\\\", \\\"{x:1400,y:936,t:1527023481772};\\\", \\\"{x:1401,y:935,t:1527023481795};\\\", \\\"{x:1401,y:933,t:1527023481819};\\\", \\\"{x:1402,y:932,t:1527023481827};\\\", \\\"{x:1403,y:930,t:1527023481839};\\\", \\\"{x:1406,y:925,t:1527023481856};\\\", \\\"{x:1409,y:919,t:1527023481871};\\\", \\\"{x:1413,y:914,t:1527023481888};\\\", \\\"{x:1419,y:906,t:1527023481905};\\\", \\\"{x:1426,y:893,t:1527023481921};\\\", \\\"{x:1441,y:864,t:1527023481938};\\\", \\\"{x:1452,y:845,t:1527023481954};\\\", \\\"{x:1460,y:833,t:1527023481971};\\\", \\\"{x:1471,y:815,t:1527023481989};\\\", \\\"{x:1481,y:795,t:1527023482005};\\\", \\\"{x:1492,y:776,t:1527023482021};\\\", \\\"{x:1500,y:762,t:1527023482038};\\\", \\\"{x:1505,y:751,t:1527023482054};\\\", \\\"{x:1511,y:741,t:1527023482071};\\\", \\\"{x:1514,y:735,t:1527023482088};\\\", \\\"{x:1517,y:726,t:1527023482104};\\\", \\\"{x:1520,y:716,t:1527023482122};\\\", \\\"{x:1523,y:710,t:1527023482139};\\\", \\\"{x:1525,y:706,t:1527023482155};\\\", \\\"{x:1525,y:705,t:1527023482171};\\\", \\\"{x:1525,y:704,t:1527023482189};\\\", \\\"{x:1527,y:708,t:1527023482300};\\\", \\\"{x:1528,y:714,t:1527023482307};\\\", \\\"{x:1529,y:720,t:1527023482321};\\\", \\\"{x:1532,y:735,t:1527023482338};\\\", \\\"{x:1540,y:772,t:1527023482355};\\\", \\\"{x:1548,y:800,t:1527023482371};\\\", \\\"{x:1557,y:828,t:1527023482388};\\\", \\\"{x:1568,y:850,t:1527023482405};\\\", \\\"{x:1575,y:871,t:1527023482421};\\\", \\\"{x:1584,y:893,t:1527023482438};\\\", \\\"{x:1592,y:911,t:1527023482455};\\\", \\\"{x:1600,y:927,t:1527023482471};\\\", \\\"{x:1606,y:938,t:1527023482488};\\\", \\\"{x:1607,y:944,t:1527023482505};\\\", \\\"{x:1607,y:947,t:1527023482521};\\\", \\\"{x:1608,y:949,t:1527023482537};\\\", \\\"{x:1604,y:949,t:1527023482819};\\\", \\\"{x:1586,y:948,t:1527023482837};\\\", \\\"{x:1563,y:944,t:1527023482854};\\\", \\\"{x:1533,y:938,t:1527023482870};\\\", \\\"{x:1501,y:929,t:1527023482887};\\\", \\\"{x:1476,y:923,t:1527023482904};\\\", \\\"{x:1456,y:920,t:1527023482920};\\\", \\\"{x:1445,y:918,t:1527023482937};\\\", \\\"{x:1440,y:918,t:1527023482954};\\\", \\\"{x:1439,y:918,t:1527023482970};\\\", \\\"{x:1438,y:916,t:1527023483091};\\\", \\\"{x:1438,y:912,t:1527023483102};\\\", \\\"{x:1442,y:893,t:1527023483120};\\\", \\\"{x:1454,y:871,t:1527023483137};\\\", \\\"{x:1471,y:835,t:1527023483153};\\\", \\\"{x:1489,y:794,t:1527023483169};\\\", \\\"{x:1521,y:746,t:1527023483187};\\\", \\\"{x:1532,y:724,t:1527023483203};\\\", \\\"{x:1544,y:712,t:1527023483219};\\\", \\\"{x:1548,y:707,t:1527023483235};\\\", \\\"{x:1550,y:706,t:1527023483253};\\\", \\\"{x:1551,y:706,t:1527023483269};\\\", \\\"{x:1553,y:706,t:1527023483291};\\\", \\\"{x:1558,y:709,t:1527023483303};\\\", \\\"{x:1578,y:741,t:1527023483320};\\\", \\\"{x:1598,y:786,t:1527023483335};\\\", \\\"{x:1621,y:826,t:1527023483352};\\\", \\\"{x:1640,y:859,t:1527023483369};\\\", \\\"{x:1651,y:881,t:1527023483386};\\\", \\\"{x:1661,y:906,t:1527023483403};\\\", \\\"{x:1663,y:916,t:1527023483420};\\\", \\\"{x:1664,y:920,t:1527023483436};\\\", \\\"{x:1664,y:921,t:1527023483453};\\\", \\\"{x:1663,y:921,t:1527023483675};\\\", \\\"{x:1662,y:921,t:1527023483691};\\\", \\\"{x:1661,y:920,t:1527023483708};\\\", \\\"{x:1659,y:919,t:1527023483719};\\\", \\\"{x:1657,y:919,t:1527023483734};\\\", \\\"{x:1656,y:918,t:1527023483752};\\\", \\\"{x:1655,y:918,t:1527023483769};\\\", \\\"{x:1653,y:917,t:1527023483785};\\\", \\\"{x:1652,y:917,t:1527023483804};\\\", \\\"{x:1648,y:916,t:1527023483819};\\\", \\\"{x:1643,y:913,t:1527023483835};\\\", \\\"{x:1642,y:913,t:1527023483852};\\\", \\\"{x:1638,y:910,t:1527023483868};\\\", \\\"{x:1633,y:907,t:1527023483885};\\\", \\\"{x:1633,y:906,t:1527023483902};\\\", \\\"{x:1633,y:904,t:1527023483939};\\\", \\\"{x:1633,y:903,t:1527023483955};\\\", \\\"{x:1633,y:901,t:1527023483967};\\\", \\\"{x:1634,y:896,t:1527023483984};\\\", \\\"{x:1634,y:895,t:1527023484002};\\\", \\\"{x:1631,y:895,t:1527023484555};\\\", \\\"{x:1630,y:895,t:1527023484566};\\\", \\\"{x:1629,y:897,t:1527023484583};\\\", \\\"{x:1624,y:899,t:1527023484599};\\\", \\\"{x:1620,y:900,t:1527023484616};\\\", \\\"{x:1612,y:900,t:1527023484633};\\\", \\\"{x:1605,y:902,t:1527023484650};\\\", \\\"{x:1592,y:904,t:1527023484667};\\\", \\\"{x:1581,y:904,t:1527023484683};\\\", \\\"{x:1568,y:905,t:1527023484700};\\\", \\\"{x:1550,y:905,t:1527023484717};\\\", \\\"{x:1531,y:905,t:1527023484733};\\\", \\\"{x:1513,y:905,t:1527023484750};\\\", \\\"{x:1495,y:906,t:1527023484767};\\\", \\\"{x:1482,y:906,t:1527023484783};\\\", \\\"{x:1472,y:906,t:1527023484800};\\\", \\\"{x:1468,y:906,t:1527023484817};\\\", \\\"{x:1466,y:906,t:1527023484832};\\\", \\\"{x:1465,y:906,t:1527023484850};\\\", \\\"{x:1464,y:906,t:1527023484987};\\\", \\\"{x:1463,y:906,t:1527023484999};\\\", \\\"{x:1458,y:906,t:1527023485015};\\\", \\\"{x:1450,y:906,t:1527023485033};\\\", \\\"{x:1441,y:906,t:1527023485049};\\\", \\\"{x:1439,y:906,t:1527023485066};\\\", \\\"{x:1437,y:906,t:1527023485203};\\\", \\\"{x:1434,y:906,t:1527023485216};\\\", \\\"{x:1427,y:906,t:1527023485231};\\\", \\\"{x:1415,y:906,t:1527023485250};\\\", \\\"{x:1397,y:906,t:1527023485266};\\\", \\\"{x:1378,y:904,t:1527023485282};\\\", \\\"{x:1334,y:895,t:1527023485299};\\\", \\\"{x:1301,y:885,t:1527023485315};\\\", \\\"{x:1265,y:874,t:1527023485332};\\\", \\\"{x:1220,y:861,t:1527023485348};\\\", \\\"{x:1170,y:838,t:1527023485365};\\\", \\\"{x:1108,y:817,t:1527023485382};\\\", \\\"{x:1037,y:801,t:1527023485399};\\\", \\\"{x:949,y:782,t:1527023485415};\\\", \\\"{x:853,y:761,t:1527023485432};\\\", \\\"{x:721,y:728,t:1527023485451};\\\", \\\"{x:681,y:724,t:1527023485465};\\\", \\\"{x:603,y:713,t:1527023485482};\\\", \\\"{x:540,y:704,t:1527023485500};\\\", \\\"{x:524,y:701,t:1527023485515};\\\", \\\"{x:518,y:700,t:1527023485531};\\\", \\\"{x:516,y:698,t:1527023485547};\\\", \\\"{x:516,y:697,t:1527023485578};\\\", \\\"{x:515,y:695,t:1527023485586};\\\", \\\"{x:514,y:694,t:1527023485596};\\\", \\\"{x:512,y:693,t:1527023485612};\\\", \\\"{x:509,y:692,t:1527023485629};\\\", \\\"{x:505,y:691,t:1527023485646};\\\", \\\"{x:496,y:690,t:1527023485662};\\\", \\\"{x:490,y:689,t:1527023485680};\\\", \\\"{x:481,y:689,t:1527023485696};\\\", \\\"{x:479,y:689,t:1527023485712};\\\", \\\"{x:478,y:689,t:1527023485770};\\\", \\\"{x:478,y:688,t:1527023485819};\\\", \\\"{x:480,y:687,t:1527023485830};\\\", \\\"{x:484,y:687,t:1527023485846};\\\", \\\"{x:491,y:687,t:1527023485863};\\\", \\\"{x:496,y:687,t:1527023485879};\\\", \\\"{x:502,y:687,t:1527023485896};\\\", \\\"{x:507,y:687,t:1527023485913};\\\", \\\"{x:510,y:687,t:1527023485929};\\\", \\\"{x:518,y:687,t:1527023485946};\\\", \\\"{x:525,y:687,t:1527023485963};\\\", \\\"{x:530,y:687,t:1527023485979};\\\", \\\"{x:535,y:685,t:1527023485996};\\\", \\\"{x:538,y:684,t:1527023486013};\\\", \\\"{x:540,y:684,t:1527023486029};\\\", \\\"{x:541,y:683,t:1527023486339};\\\", \\\"{x:540,y:683,t:1527023486611};\\\", \\\"{x:539,y:683,t:1527023486836};\\\", \\\"{x:541,y:683,t:1527023486850};\\\", \\\"{x:550,y:684,t:1527023486865};\\\", \\\"{x:557,y:685,t:1527023486881};\\\", \\\"{x:564,y:686,t:1527023486898};\\\", \\\"{x:568,y:687,t:1527023486916};\\\", \\\"{x:568,y:688,t:1527023487186};\\\", \\\"{x:570,y:687,t:1527023487403};\\\", \\\"{x:571,y:687,t:1527023487414};\\\", \\\"{x:573,y:686,t:1527023487430};\\\", \\\"{x:579,y:686,t:1527023487450};\\\", \\\"{x:581,y:686,t:1527023487467};\\\", \\\"{x:583,y:686,t:1527023487481};\\\", \\\"{x:580,y:686,t:1527023487643};\\\", \\\"{x:579,y:686,t:1527023487651};\\\", \\\"{x:576,y:687,t:1527023487665};\\\", \\\"{x:569,y:687,t:1527023487681};\\\", \\\"{x:560,y:687,t:1527023487698};\\\", \\\"{x:548,y:687,t:1527023487714};\\\", \\\"{x:545,y:686,t:1527023487730};\\\", \\\"{x:548,y:686,t:1527023488875};\\\", \\\"{x:550,y:687,t:1527023488883};\\\", \\\"{x:558,y:689,t:1527023488898};\\\", \\\"{x:563,y:689,t:1527023488915};\\\", \\\"{x:565,y:689,t:1527023488933};\\\", \\\"{x:566,y:689,t:1527023488948};\\\", \\\"{x:567,y:689,t:1527023488970};\\\", \\\"{x:567,y:687,t:1527023488982};\\\", \\\"{x:567,y:674,t:1527023489055};\\\" ] }, { \\\"rt\\\": 55131, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 12, \\\"time_elapsed\\\": 629553, \\\"internal_node_id\\\": \\\"0.0-6.0-2.0\\\", \\\"subject\\\": \\\"QOJ6L\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"hotel\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+contained\\\", \\\"q\\\": 8, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-H -03 PM-B -B -10 AM-10 AM-B -B -11 AM-B -B -B -B -B -L -3-J -O \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:568,y:672,t:1527023489855};\\\", \\\"{x:568,y:670,t:1527023489994};\\\", \\\"{x:568,y:669,t:1527023490002};\\\", \\\"{x:568,y:668,t:1527023490017};\\\", \\\"{x:567,y:666,t:1527023490032};\\\", \\\"{x:566,y:664,t:1527023490050};\\\", \\\"{x:566,y:663,t:1527023490074};\\\", \\\"{x:568,y:663,t:1527023490474};\\\", \\\"{x:576,y:663,t:1527023490483};\\\", \\\"{x:597,y:665,t:1527023490499};\\\", \\\"{x:628,y:669,t:1527023490517};\\\", \\\"{x:684,y:677,t:1527023490534};\\\", \\\"{x:754,y:689,t:1527023490549};\\\", \\\"{x:826,y:696,t:1527023490567};\\\", \\\"{x:880,y:699,t:1527023490583};\\\", \\\"{x:935,y:704,t:1527023490599};\\\", \\\"{x:975,y:707,t:1527023490616};\\\", \\\"{x:1006,y:709,t:1527023490634};\\\", \\\"{x:1016,y:709,t:1527023490650};\\\", \\\"{x:1020,y:708,t:1527023490666};\\\", \\\"{x:1021,y:707,t:1527023491939};\\\", \\\"{x:1021,y:706,t:1527023491952};\\\", \\\"{x:1022,y:706,t:1527023491987};\\\", \\\"{x:1022,y:705,t:1527023492018};\\\", \\\"{x:1022,y:703,t:1527023492035};\\\", \\\"{x:1025,y:699,t:1527023492053};\\\", \\\"{x:1026,y:696,t:1527023492068};\\\", \\\"{x:1030,y:689,t:1527023492084};\\\", \\\"{x:1033,y:684,t:1527023492102};\\\", \\\"{x:1038,y:680,t:1527023492118};\\\", \\\"{x:1041,y:677,t:1527023492134};\\\", \\\"{x:1044,y:674,t:1527023492151};\\\", \\\"{x:1048,y:667,t:1527023492169};\\\", \\\"{x:1052,y:663,t:1527023492185};\\\", \\\"{x:1048,y:660,t:1527023492611};\\\", \\\"{x:1040,y:656,t:1527023492619};\\\", \\\"{x:1009,y:646,t:1527023492636};\\\", \\\"{x:931,y:624,t:1527023492654};\\\", \\\"{x:842,y:612,t:1527023492669};\\\", \\\"{x:733,y:590,t:1527023492686};\\\", \\\"{x:609,y:556,t:1527023492705};\\\", \\\"{x:490,y:525,t:1527023492721};\\\", \\\"{x:383,y:497,t:1527023492733};\\\", \\\"{x:297,y:472,t:1527023492749};\\\", \\\"{x:252,y:460,t:1527023492770};\\\", \\\"{x:225,y:451,t:1527023492785};\\\", \\\"{x:212,y:446,t:1527023492801};\\\", \\\"{x:207,y:443,t:1527023492818};\\\", \\\"{x:207,y:442,t:1527023492835};\\\", \\\"{x:207,y:436,t:1527023492851};\\\", \\\"{x:207,y:432,t:1527023492869};\\\", \\\"{x:209,y:427,t:1527023492884};\\\", \\\"{x:212,y:422,t:1527023492902};\\\", \\\"{x:216,y:416,t:1527023492918};\\\", \\\"{x:224,y:411,t:1527023492935};\\\", \\\"{x:234,y:407,t:1527023492952};\\\", \\\"{x:245,y:403,t:1527023492969};\\\", \\\"{x:251,y:400,t:1527023492985};\\\", \\\"{x:257,y:397,t:1527023493001};\\\", \\\"{x:261,y:396,t:1527023493018};\\\", \\\"{x:263,y:396,t:1527023493036};\\\", \\\"{x:264,y:396,t:1527023493052};\\\", \\\"{x:266,y:396,t:1527023493069};\\\", \\\"{x:264,y:396,t:1527023493291};\\\", \\\"{x:263,y:396,t:1527023493306};\\\", \\\"{x:262,y:396,t:1527023493319};\\\", \\\"{x:260,y:396,t:1527023493336};\\\", \\\"{x:255,y:396,t:1527023493352};\\\", \\\"{x:249,y:396,t:1527023493369};\\\", \\\"{x:242,y:396,t:1527023493386};\\\", \\\"{x:236,y:396,t:1527023493403};\\\", \\\"{x:226,y:396,t:1527023493419};\\\", \\\"{x:222,y:396,t:1527023493436};\\\", \\\"{x:216,y:396,t:1527023493453};\\\", \\\"{x:213,y:396,t:1527023493469};\\\", \\\"{x:208,y:396,t:1527023493486};\\\", \\\"{x:207,y:396,t:1527023493503};\\\", \\\"{x:204,y:398,t:1527023493519};\\\", \\\"{x:203,y:398,t:1527023493536};\\\", \\\"{x:201,y:398,t:1527023493553};\\\", \\\"{x:200,y:398,t:1527023493667};\\\", \\\"{x:200,y:401,t:1527023493683};\\\", \\\"{x:204,y:403,t:1527023493690};\\\", \\\"{x:210,y:406,t:1527023493703};\\\", \\\"{x:228,y:409,t:1527023493719};\\\", \\\"{x:250,y:415,t:1527023493736};\\\", \\\"{x:281,y:419,t:1527023493753};\\\", \\\"{x:322,y:425,t:1527023493770};\\\", \\\"{x:373,y:425,t:1527023493786};\\\", \\\"{x:448,y:425,t:1527023493803};\\\", \\\"{x:498,y:425,t:1527023493820};\\\", \\\"{x:559,y:432,t:1527023493836};\\\", \\\"{x:618,y:440,t:1527023493855};\\\", \\\"{x:668,y:448,t:1527023493869};\\\", \\\"{x:712,y:451,t:1527023493886};\\\", \\\"{x:744,y:451,t:1527023493904};\\\", \\\"{x:768,y:451,t:1527023493920};\\\", \\\"{x:783,y:451,t:1527023493935};\\\", \\\"{x:790,y:451,t:1527023493953};\\\", \\\"{x:791,y:450,t:1527023493970};\\\", \\\"{x:791,y:449,t:1527023493985};\\\", \\\"{x:791,y:442,t:1527023494003};\\\", \\\"{x:790,y:436,t:1527023494020};\\\", \\\"{x:787,y:432,t:1527023494036};\\\", \\\"{x:781,y:428,t:1527023494053};\\\", \\\"{x:773,y:426,t:1527023494070};\\\", \\\"{x:764,y:425,t:1527023494085};\\\", \\\"{x:751,y:425,t:1527023494102};\\\", \\\"{x:735,y:422,t:1527023494120};\\\", \\\"{x:711,y:422,t:1527023494136};\\\", \\\"{x:681,y:420,t:1527023494153};\\\", \\\"{x:620,y:413,t:1527023494171};\\\", \\\"{x:592,y:413,t:1527023494186};\\\", \\\"{x:481,y:395,t:1527023494202};\\\", \\\"{x:426,y:388,t:1527023494220};\\\", \\\"{x:395,y:383,t:1527023494237};\\\", \\\"{x:378,y:381,t:1527023494253};\\\", \\\"{x:375,y:379,t:1527023494269};\\\", \\\"{x:375,y:380,t:1527023494474};\\\", \\\"{x:376,y:382,t:1527023494487};\\\", \\\"{x:381,y:386,t:1527023494503};\\\", \\\"{x:392,y:389,t:1527023494519};\\\", \\\"{x:402,y:392,t:1527023494536};\\\", \\\"{x:410,y:393,t:1527023494553};\\\", \\\"{x:430,y:396,t:1527023494569};\\\", \\\"{x:441,y:397,t:1527023494586};\\\", \\\"{x:446,y:397,t:1527023494602};\\\", \\\"{x:451,y:397,t:1527023494620};\\\", \\\"{x:454,y:397,t:1527023494636};\\\", \\\"{x:458,y:397,t:1527023494653};\\\", \\\"{x:460,y:397,t:1527023494670};\\\", \\\"{x:463,y:397,t:1527023494686};\\\", \\\"{x:472,y:397,t:1527023494704};\\\", \\\"{x:484,y:397,t:1527023494720};\\\", \\\"{x:498,y:397,t:1527023494737};\\\", \\\"{x:512,y:397,t:1527023494754};\\\", \\\"{x:535,y:397,t:1527023494770};\\\", \\\"{x:550,y:397,t:1527023494786};\\\", \\\"{x:571,y:397,t:1527023494803};\\\", \\\"{x:587,y:397,t:1527023494819};\\\", \\\"{x:605,y:397,t:1527023494837};\\\", \\\"{x:615,y:398,t:1527023494854};\\\", \\\"{x:621,y:398,t:1527023494870};\\\", \\\"{x:623,y:398,t:1527023494887};\\\", \\\"{x:619,y:398,t:1527023495083};\\\", \\\"{x:606,y:395,t:1527023495091};\\\", \\\"{x:584,y:388,t:1527023495104};\\\", \\\"{x:581,y:388,t:1527023495121};\\\", \\\"{x:580,y:388,t:1527023495795};\\\", \\\"{x:579,y:388,t:1527023495804};\\\", \\\"{x:578,y:389,t:1527023495826};\\\", \\\"{x:576,y:390,t:1527023495923};\\\", \\\"{x:576,y:391,t:1527023495939};\\\", \\\"{x:575,y:393,t:1527023495955};\\\", \\\"{x:574,y:394,t:1527023495971};\\\", \\\"{x:573,y:396,t:1527023495988};\\\", \\\"{x:572,y:397,t:1527023496005};\\\", \\\"{x:572,y:398,t:1527023496021};\\\", \\\"{x:571,y:400,t:1527023496067};\\\", \\\"{x:569,y:402,t:1527023496339};\\\", \\\"{x:566,y:404,t:1527023496355};\\\", \\\"{x:561,y:408,t:1527023496372};\\\", \\\"{x:553,y:413,t:1527023496388};\\\", \\\"{x:547,y:415,t:1527023496405};\\\", \\\"{x:539,y:421,t:1527023496422};\\\", \\\"{x:536,y:423,t:1527023496438};\\\", \\\"{x:528,y:427,t:1527023496455};\\\", \\\"{x:522,y:431,t:1527023496472};\\\", \\\"{x:518,y:434,t:1527023496489};\\\", \\\"{x:514,y:437,t:1527023496505};\\\", \\\"{x:511,y:439,t:1527023496521};\\\", \\\"{x:510,y:440,t:1527023496537};\\\", \\\"{x:510,y:441,t:1527023496955};\\\", \\\"{x:512,y:445,t:1527023496973};\\\", \\\"{x:531,y:449,t:1527023496990};\\\", \\\"{x:556,y:455,t:1527023497005};\\\", \\\"{x:590,y:461,t:1527023497022};\\\", \\\"{x:632,y:468,t:1527023497040};\\\", \\\"{x:683,y:468,t:1527023497055};\\\", \\\"{x:736,y:469,t:1527023497072};\\\", \\\"{x:775,y:472,t:1527023497090};\\\", \\\"{x:806,y:478,t:1527023497104};\\\", \\\"{x:833,y:482,t:1527023497122};\\\", \\\"{x:839,y:482,t:1527023497139};\\\", \\\"{x:840,y:482,t:1527023497155};\\\", \\\"{x:841,y:482,t:1527023497178};\\\", \\\"{x:843,y:481,t:1527023497218};\\\", \\\"{x:843,y:478,t:1527023497226};\\\", \\\"{x:843,y:475,t:1527023497239};\\\", \\\"{x:843,y:474,t:1527023497556};\\\", \\\"{x:836,y:469,t:1527023497572};\\\", \\\"{x:820,y:454,t:1527023497589};\\\", \\\"{x:801,y:440,t:1527023497606};\\\", \\\"{x:785,y:431,t:1527023497622};\\\", \\\"{x:769,y:422,t:1527023497639};\\\", \\\"{x:757,y:416,t:1527023497656};\\\", \\\"{x:748,y:412,t:1527023497673};\\\", \\\"{x:744,y:410,t:1527023497688};\\\", \\\"{x:741,y:408,t:1527023497706};\\\", \\\"{x:740,y:407,t:1527023497754};\\\", \\\"{x:746,y:407,t:1527023498307};\\\", \\\"{x:763,y:407,t:1527023498323};\\\", \\\"{x:777,y:407,t:1527023498339};\\\", \\\"{x:786,y:407,t:1527023498356};\\\", \\\"{x:789,y:407,t:1527023498372};\\\", \\\"{x:790,y:407,t:1527023498390};\\\", \\\"{x:791,y:407,t:1527023498571};\\\", \\\"{x:801,y:407,t:1527023498589};\\\", \\\"{x:831,y:416,t:1527023498607};\\\", \\\"{x:920,y:445,t:1527023498624};\\\", \\\"{x:1061,y:482,t:1527023498640};\\\", \\\"{x:1210,y:523,t:1527023498656};\\\", \\\"{x:1355,y:554,t:1527023498672};\\\", \\\"{x:1547,y:579,t:1527023498689};\\\", \\\"{x:1633,y:590,t:1527023498707};\\\", \\\"{x:1683,y:598,t:1527023498724};\\\", \\\"{x:1710,y:603,t:1527023498740};\\\", \\\"{x:1716,y:603,t:1527023498756};\\\", \\\"{x:1716,y:602,t:1527023498778};\\\", \\\"{x:1716,y:599,t:1527023498790};\\\", \\\"{x:1709,y:585,t:1527023498807};\\\", \\\"{x:1693,y:570,t:1527023498824};\\\", \\\"{x:1669,y:552,t:1527023498840};\\\", \\\"{x:1650,y:535,t:1527023498857};\\\", \\\"{x:1628,y:508,t:1527023498875};\\\", \\\"{x:1612,y:487,t:1527023498891};\\\", \\\"{x:1600,y:471,t:1527023498907};\\\", \\\"{x:1589,y:458,t:1527023498924};\\\", \\\"{x:1584,y:454,t:1527023498940};\\\", \\\"{x:1581,y:451,t:1527023498957};\\\", \\\"{x:1580,y:451,t:1527023498974};\\\", \\\"{x:1579,y:450,t:1527023499060};\\\", \\\"{x:1572,y:446,t:1527023499075};\\\", \\\"{x:1559,y:433,t:1527023499091};\\\", \\\"{x:1545,y:419,t:1527023499108};\\\", \\\"{x:1530,y:400,t:1527023499125};\\\", \\\"{x:1516,y:382,t:1527023499142};\\\", \\\"{x:1513,y:377,t:1527023499158};\\\", \\\"{x:1513,y:378,t:1527023499244};\\\", \\\"{x:1513,y:382,t:1527023499257};\\\", \\\"{x:1523,y:399,t:1527023499275};\\\", \\\"{x:1532,y:412,t:1527023499290};\\\", \\\"{x:1540,y:423,t:1527023499309};\\\", \\\"{x:1544,y:429,t:1527023499324};\\\", \\\"{x:1550,y:432,t:1527023499341};\\\", \\\"{x:1550,y:433,t:1527023499358};\\\", \\\"{x:1550,y:437,t:1527023499375};\\\", \\\"{x:1551,y:438,t:1527023499391};\\\", \\\"{x:1551,y:456,t:1527023500234};\\\", \\\"{x:1551,y:457,t:1527023500250};\\\", \\\"{x:1551,y:458,t:1527023500258};\\\", \\\"{x:1550,y:458,t:1527023500274};\\\", \\\"{x:1548,y:460,t:1527023500291};\\\", \\\"{x:1546,y:464,t:1527023500308};\\\", \\\"{x:1546,y:467,t:1527023500325};\\\", \\\"{x:1543,y:473,t:1527023500342};\\\", \\\"{x:1541,y:478,t:1527023500358};\\\", \\\"{x:1539,y:483,t:1527023500375};\\\", \\\"{x:1538,y:484,t:1527023500392};\\\", \\\"{x:1538,y:485,t:1527023500408};\\\", \\\"{x:1538,y:488,t:1527023500425};\\\", \\\"{x:1538,y:491,t:1527023500442};\\\", \\\"{x:1538,y:493,t:1527023500459};\\\", \\\"{x:1538,y:497,t:1527023500475};\\\", \\\"{x:1538,y:503,t:1527023500492};\\\", \\\"{x:1543,y:516,t:1527023500510};\\\", \\\"{x:1551,y:529,t:1527023500525};\\\", \\\"{x:1557,y:540,t:1527023500542};\\\", \\\"{x:1565,y:551,t:1527023500560};\\\", \\\"{x:1573,y:563,t:1527023500575};\\\", \\\"{x:1584,y:577,t:1527023500595};\\\", \\\"{x:1596,y:591,t:1527023500609};\\\", \\\"{x:1605,y:601,t:1527023500625};\\\", \\\"{x:1617,y:613,t:1527023500641};\\\", \\\"{x:1621,y:616,t:1527023500659};\\\", \\\"{x:1624,y:618,t:1527023500675};\\\", \\\"{x:1624,y:619,t:1527023500692};\\\", \\\"{x:1624,y:620,t:1527023500709};\\\", \\\"{x:1625,y:620,t:1527023500727};\\\", \\\"{x:1625,y:609,t:1527023500842};\\\", \\\"{x:1625,y:608,t:1527023500875};\\\", \\\"{x:1625,y:609,t:1527023500891};\\\", \\\"{x:1625,y:612,t:1527023500908};\\\", \\\"{x:1624,y:614,t:1527023500925};\\\", \\\"{x:1624,y:615,t:1527023501507};\\\", \\\"{x:1622,y:616,t:1527023501515};\\\", \\\"{x:1619,y:618,t:1527023501527};\\\", \\\"{x:1617,y:619,t:1527023501542};\\\", \\\"{x:1612,y:621,t:1527023501560};\\\", \\\"{x:1604,y:624,t:1527023501577};\\\", \\\"{x:1600,y:626,t:1527023501592};\\\", \\\"{x:1591,y:630,t:1527023501609};\\\", \\\"{x:1575,y:637,t:1527023501626};\\\", \\\"{x:1553,y:647,t:1527023501643};\\\", \\\"{x:1528,y:657,t:1527023501659};\\\", \\\"{x:1500,y:671,t:1527023501676};\\\", \\\"{x:1470,y:686,t:1527023501693};\\\", \\\"{x:1456,y:695,t:1527023501709};\\\", \\\"{x:1444,y:701,t:1527023501727};\\\", \\\"{x:1437,y:706,t:1527023501743};\\\", \\\"{x:1431,y:713,t:1527023501760};\\\", \\\"{x:1429,y:718,t:1527023501777};\\\", \\\"{x:1427,y:724,t:1527023501792};\\\", \\\"{x:1425,y:730,t:1527023501809};\\\", \\\"{x:1423,y:735,t:1527023501826};\\\", \\\"{x:1423,y:738,t:1527023501843};\\\", \\\"{x:1423,y:740,t:1527023501859};\\\", \\\"{x:1423,y:744,t:1527023501876};\\\", \\\"{x:1423,y:747,t:1527023501893};\\\", \\\"{x:1423,y:753,t:1527023501910};\\\", \\\"{x:1423,y:755,t:1527023502346};\\\", \\\"{x:1424,y:757,t:1527023502427};\\\", \\\"{x:1430,y:761,t:1527023502443};\\\", \\\"{x:1436,y:768,t:1527023502460};\\\", \\\"{x:1448,y:782,t:1527023502476};\\\", \\\"{x:1457,y:794,t:1527023502493};\\\", \\\"{x:1466,y:804,t:1527023502510};\\\", \\\"{x:1471,y:808,t:1527023502526};\\\", \\\"{x:1473,y:810,t:1527023502544};\\\", \\\"{x:1475,y:810,t:1527023502659};\\\", \\\"{x:1477,y:809,t:1527023502677};\\\", \\\"{x:1478,y:807,t:1527023502694};\\\", \\\"{x:1479,y:803,t:1527023502711};\\\", \\\"{x:1481,y:799,t:1527023502726};\\\", \\\"{x:1481,y:796,t:1527023502743};\\\", \\\"{x:1483,y:792,t:1527023502761};\\\", \\\"{x:1483,y:790,t:1527023502794};\\\", \\\"{x:1484,y:790,t:1527023503020};\\\", \\\"{x:1485,y:792,t:1527023503035};\\\", \\\"{x:1486,y:793,t:1527023503043};\\\", \\\"{x:1489,y:801,t:1527023503060};\\\", \\\"{x:1494,y:810,t:1527023503078};\\\", \\\"{x:1498,y:818,t:1527023503094};\\\", \\\"{x:1502,y:824,t:1527023503110};\\\", \\\"{x:1506,y:830,t:1527023503127};\\\", \\\"{x:1512,y:841,t:1527023503144};\\\", \\\"{x:1516,y:849,t:1527023503160};\\\", \\\"{x:1520,y:855,t:1527023503178};\\\", \\\"{x:1523,y:862,t:1527023503194};\\\", \\\"{x:1529,y:872,t:1527023503211};\\\", \\\"{x:1532,y:877,t:1527023503228};\\\", \\\"{x:1536,y:885,t:1527023503244};\\\", \\\"{x:1538,y:891,t:1527023503260};\\\", \\\"{x:1540,y:893,t:1527023503277};\\\", \\\"{x:1541,y:896,t:1527023503294};\\\", \\\"{x:1542,y:899,t:1527023503310};\\\", \\\"{x:1543,y:901,t:1527023503327};\\\", \\\"{x:1544,y:903,t:1527023503344};\\\", \\\"{x:1544,y:905,t:1527023503360};\\\", \\\"{x:1544,y:909,t:1527023503377};\\\", \\\"{x:1547,y:914,t:1527023503394};\\\", \\\"{x:1547,y:916,t:1527023503410};\\\", \\\"{x:1548,y:917,t:1527023503458};\\\", \\\"{x:1547,y:917,t:1527023504187};\\\", \\\"{x:1546,y:917,t:1527023504194};\\\", \\\"{x:1545,y:916,t:1527023504211};\\\", \\\"{x:1544,y:915,t:1527023504228};\\\", \\\"{x:1543,y:914,t:1527023504244};\\\", \\\"{x:1543,y:913,t:1527023504266};\\\", \\\"{x:1542,y:911,t:1527023504298};\\\", \\\"{x:1541,y:911,t:1527023504330};\\\", \\\"{x:1541,y:910,t:1527023504344};\\\", \\\"{x:1541,y:909,t:1527023504370};\\\", \\\"{x:1540,y:908,t:1527023504411};\\\", \\\"{x:1540,y:907,t:1527023504450};\\\", \\\"{x:1539,y:906,t:1527023504481};\\\", \\\"{x:1539,y:903,t:1527023504555};\\\", \\\"{x:1538,y:903,t:1527023504578};\\\", \\\"{x:1538,y:902,t:1527023504603};\\\", \\\"{x:1537,y:902,t:1527023504651};\\\", \\\"{x:1537,y:901,t:1527023504661};\\\", \\\"{x:1536,y:900,t:1527023504678};\\\", \\\"{x:1535,y:900,t:1527023504695};\\\", \\\"{x:1532,y:900,t:1527023504711};\\\", \\\"{x:1528,y:899,t:1527023504728};\\\", \\\"{x:1520,y:895,t:1527023504746};\\\", \\\"{x:1504,y:886,t:1527023504761};\\\", \\\"{x:1472,y:863,t:1527023504779};\\\", \\\"{x:1448,y:846,t:1527023504795};\\\", \\\"{x:1424,y:831,t:1527023504811};\\\", \\\"{x:1402,y:816,t:1527023504828};\\\", \\\"{x:1386,y:804,t:1527023504845};\\\", \\\"{x:1373,y:792,t:1527023504862};\\\", \\\"{x:1365,y:777,t:1527023504879};\\\", \\\"{x:1360,y:764,t:1527023504895};\\\", \\\"{x:1354,y:747,t:1527023504912};\\\", \\\"{x:1353,y:736,t:1527023504928};\\\", \\\"{x:1353,y:728,t:1527023504946};\\\", \\\"{x:1353,y:722,t:1527023504961};\\\", \\\"{x:1353,y:715,t:1527023504978};\\\", \\\"{x:1353,y:711,t:1527023504996};\\\", \\\"{x:1351,y:709,t:1527023505012};\\\", \\\"{x:1351,y:707,t:1527023505028};\\\", \\\"{x:1351,y:705,t:1527023505046};\\\", \\\"{x:1351,y:704,t:1527023505063};\\\", \\\"{x:1351,y:705,t:1527023505411};\\\", \\\"{x:1351,y:706,t:1527023505420};\\\", \\\"{x:1351,y:707,t:1527023505899};\\\", \\\"{x:1350,y:707,t:1527023505913};\\\", \\\"{x:1349,y:709,t:1527023505929};\\\", \\\"{x:1348,y:711,t:1527023505946};\\\", \\\"{x:1347,y:712,t:1527023505963};\\\", \\\"{x:1346,y:713,t:1527023505995};\\\", \\\"{x:1346,y:715,t:1527023509987};\\\", \\\"{x:1345,y:718,t:1527023510000};\\\", \\\"{x:1338,y:727,t:1527023510016};\\\", \\\"{x:1334,y:735,t:1527023510033};\\\", \\\"{x:1330,y:744,t:1527023510050};\\\", \\\"{x:1323,y:759,t:1527023510066};\\\", \\\"{x:1314,y:782,t:1527023510083};\\\", \\\"{x:1304,y:803,t:1527023510100};\\\", \\\"{x:1297,y:820,t:1527023510116};\\\", \\\"{x:1291,y:836,t:1527023510133};\\\", \\\"{x:1287,y:849,t:1527023510150};\\\", \\\"{x:1283,y:860,t:1527023510166};\\\", \\\"{x:1281,y:867,t:1527023510183};\\\", \\\"{x:1278,y:875,t:1527023510200};\\\", \\\"{x:1275,y:882,t:1527023510217};\\\", \\\"{x:1273,y:890,t:1527023510233};\\\", \\\"{x:1269,y:897,t:1527023510250};\\\", \\\"{x:1264,y:904,t:1527023510266};\\\", \\\"{x:1264,y:906,t:1527023510283};\\\", \\\"{x:1262,y:909,t:1527023510300};\\\", \\\"{x:1261,y:911,t:1527023510318};\\\", \\\"{x:1257,y:915,t:1527023510333};\\\", \\\"{x:1252,y:920,t:1527023510350};\\\", \\\"{x:1245,y:925,t:1527023510366};\\\", \\\"{x:1241,y:926,t:1527023510383};\\\", \\\"{x:1237,y:929,t:1527023510400};\\\", \\\"{x:1234,y:930,t:1527023510416};\\\", \\\"{x:1231,y:932,t:1527023510434};\\\", \\\"{x:1229,y:932,t:1527023510450};\\\", \\\"{x:1228,y:932,t:1527023510475};\\\", \\\"{x:1226,y:932,t:1527023510539};\\\", \\\"{x:1225,y:929,t:1527023510550};\\\", \\\"{x:1222,y:923,t:1527023510567};\\\", \\\"{x:1220,y:916,t:1527023510582};\\\", \\\"{x:1219,y:912,t:1527023510601};\\\", \\\"{x:1218,y:908,t:1527023510617};\\\", \\\"{x:1218,y:906,t:1527023510633};\\\", \\\"{x:1218,y:904,t:1527023510650};\\\", \\\"{x:1218,y:902,t:1527023510675};\\\", \\\"{x:1218,y:901,t:1527023510707};\\\", \\\"{x:1218,y:899,t:1527023510717};\\\", \\\"{x:1218,y:896,t:1527023510734};\\\", \\\"{x:1218,y:895,t:1527023510751};\\\", \\\"{x:1218,y:892,t:1527023510767};\\\", \\\"{x:1218,y:891,t:1527023510784};\\\", \\\"{x:1218,y:890,t:1527023510800};\\\", \\\"{x:1218,y:892,t:1527023510995};\\\", \\\"{x:1218,y:893,t:1527023511011};\\\", \\\"{x:1218,y:894,t:1527023511018};\\\", \\\"{x:1218,y:893,t:1527023511218};\\\", \\\"{x:1218,y:892,t:1527023511234};\\\", \\\"{x:1219,y:886,t:1527023511250};\\\", \\\"{x:1222,y:875,t:1527023511268};\\\", \\\"{x:1226,y:865,t:1527023511284};\\\", \\\"{x:1230,y:851,t:1527023511301};\\\", \\\"{x:1235,y:831,t:1527023511317};\\\", \\\"{x:1243,y:807,t:1527023511334};\\\", \\\"{x:1254,y:778,t:1527023511351};\\\", \\\"{x:1265,y:754,t:1527023511367};\\\", \\\"{x:1276,y:733,t:1527023511383};\\\", \\\"{x:1281,y:717,t:1527023511401};\\\", \\\"{x:1286,y:708,t:1527023511416};\\\", \\\"{x:1293,y:695,t:1527023511434};\\\", \\\"{x:1297,y:689,t:1527023511451};\\\", \\\"{x:1300,y:683,t:1527023511467};\\\", \\\"{x:1303,y:680,t:1527023511484};\\\", \\\"{x:1306,y:676,t:1527023511501};\\\", \\\"{x:1309,y:673,t:1527023511517};\\\", \\\"{x:1312,y:669,t:1527023511534};\\\", \\\"{x:1314,y:668,t:1527023511551};\\\", \\\"{x:1316,y:670,t:1527023511627};\\\", \\\"{x:1318,y:678,t:1527023511634};\\\", \\\"{x:1321,y:692,t:1527023511651};\\\", \\\"{x:1326,y:714,t:1527023511668};\\\", \\\"{x:1330,y:734,t:1527023511684};\\\", \\\"{x:1332,y:754,t:1527023511701};\\\", \\\"{x:1332,y:775,t:1527023511718};\\\", \\\"{x:1332,y:791,t:1527023511734};\\\", \\\"{x:1332,y:804,t:1527023511751};\\\", \\\"{x:1332,y:815,t:1527023511768};\\\", \\\"{x:1332,y:823,t:1527023511784};\\\", \\\"{x:1329,y:832,t:1527023511801};\\\", \\\"{x:1325,y:842,t:1527023511818};\\\", \\\"{x:1315,y:862,t:1527023511834};\\\", \\\"{x:1309,y:872,t:1527023511850};\\\", \\\"{x:1303,y:880,t:1527023511867};\\\", \\\"{x:1298,y:889,t:1527023511883};\\\", \\\"{x:1291,y:896,t:1527023511900};\\\", \\\"{x:1285,y:901,t:1527023511917};\\\", \\\"{x:1281,y:905,t:1527023511933};\\\", \\\"{x:1278,y:908,t:1527023511951};\\\", \\\"{x:1277,y:910,t:1527023511967};\\\", \\\"{x:1273,y:912,t:1527023511984};\\\", \\\"{x:1269,y:914,t:1527023512001};\\\", \\\"{x:1265,y:915,t:1527023512017};\\\", \\\"{x:1261,y:917,t:1527023512034};\\\", \\\"{x:1254,y:919,t:1527023512051};\\\", \\\"{x:1253,y:920,t:1527023512067};\\\", \\\"{x:1253,y:918,t:1527023512171};\\\", \\\"{x:1253,y:913,t:1527023512185};\\\", \\\"{x:1258,y:900,t:1527023512201};\\\", \\\"{x:1264,y:884,t:1527023512218};\\\", \\\"{x:1276,y:859,t:1527023512235};\\\", \\\"{x:1289,y:834,t:1527023512251};\\\", \\\"{x:1309,y:803,t:1527023512268};\\\", \\\"{x:1320,y:785,t:1527023512285};\\\", \\\"{x:1331,y:771,t:1527023512301};\\\", \\\"{x:1340,y:757,t:1527023512318};\\\", \\\"{x:1346,y:749,t:1527023512335};\\\", \\\"{x:1351,y:742,t:1527023512351};\\\", \\\"{x:1354,y:734,t:1527023512367};\\\", \\\"{x:1355,y:730,t:1527023512385};\\\", \\\"{x:1357,y:726,t:1527023512400};\\\", \\\"{x:1358,y:723,t:1527023512418};\\\", \\\"{x:1359,y:721,t:1527023512434};\\\", \\\"{x:1359,y:720,t:1527023512452};\\\", \\\"{x:1360,y:719,t:1527023512481};\\\", \\\"{x:1360,y:718,t:1527023512490};\\\", \\\"{x:1361,y:717,t:1527023512502};\\\", \\\"{x:1361,y:715,t:1527023512517};\\\", \\\"{x:1361,y:714,t:1527023512535};\\\", \\\"{x:1361,y:712,t:1527023512552};\\\", \\\"{x:1361,y:711,t:1527023512567};\\\", \\\"{x:1361,y:710,t:1527023512585};\\\", \\\"{x:1361,y:709,t:1527023512602};\\\", \\\"{x:1361,y:708,t:1527023512618};\\\", \\\"{x:1361,y:707,t:1527023513979};\\\", \\\"{x:1359,y:707,t:1527023513987};\\\", \\\"{x:1357,y:707,t:1527023514002};\\\", \\\"{x:1353,y:707,t:1527023514019};\\\", \\\"{x:1349,y:707,t:1527023514037};\\\", \\\"{x:1348,y:707,t:1527023514053};\\\", \\\"{x:1346,y:708,t:1527023514179};\\\", \\\"{x:1345,y:709,t:1527023514187};\\\", \\\"{x:1343,y:711,t:1527023514202};\\\", \\\"{x:1342,y:713,t:1527023514220};\\\", \\\"{x:1341,y:713,t:1527023514236};\\\", \\\"{x:1343,y:713,t:1527023514388};\\\", \\\"{x:1349,y:713,t:1527023514403};\\\", \\\"{x:1352,y:710,t:1527023514420};\\\", \\\"{x:1356,y:707,t:1527023514437};\\\", \\\"{x:1358,y:707,t:1527023514452};\\\", \\\"{x:1359,y:706,t:1527023514469};\\\", \\\"{x:1359,y:707,t:1527023514582};\\\", \\\"{x:1359,y:709,t:1527023514589};\\\", \\\"{x:1357,y:712,t:1527023514606};\\\", \\\"{x:1355,y:715,t:1527023514624};\\\", \\\"{x:1354,y:716,t:1527023514646};\\\", \\\"{x:1353,y:716,t:1527023514678};\\\", \\\"{x:1353,y:717,t:1527023514919};\\\", \\\"{x:1351,y:718,t:1527023514926};\\\", \\\"{x:1351,y:719,t:1527023514941};\\\", \\\"{x:1349,y:721,t:1527023514956};\\\", \\\"{x:1347,y:722,t:1527023514973};\\\", \\\"{x:1345,y:724,t:1527023514990};\\\", \\\"{x:1344,y:725,t:1527023515007};\\\", \\\"{x:1342,y:727,t:1527023515024};\\\", \\\"{x:1341,y:729,t:1527023515040};\\\", \\\"{x:1340,y:731,t:1527023515057};\\\", \\\"{x:1338,y:735,t:1527023515074};\\\", \\\"{x:1337,y:739,t:1527023515091};\\\", \\\"{x:1334,y:744,t:1527023515107};\\\", \\\"{x:1332,y:750,t:1527023515123};\\\", \\\"{x:1331,y:755,t:1527023515140};\\\", \\\"{x:1326,y:766,t:1527023515158};\\\", \\\"{x:1326,y:769,t:1527023515174};\\\", \\\"{x:1323,y:777,t:1527023515190};\\\", \\\"{x:1322,y:781,t:1527023515208};\\\", \\\"{x:1321,y:784,t:1527023515224};\\\", \\\"{x:1319,y:791,t:1527023515241};\\\", \\\"{x:1318,y:796,t:1527023515258};\\\", \\\"{x:1316,y:802,t:1527023515274};\\\", \\\"{x:1314,y:807,t:1527023515291};\\\", \\\"{x:1313,y:812,t:1527023515308};\\\", \\\"{x:1311,y:818,t:1527023515324};\\\", \\\"{x:1310,y:822,t:1527023515341};\\\", \\\"{x:1307,y:828,t:1527023515358};\\\", \\\"{x:1305,y:833,t:1527023515374};\\\", \\\"{x:1300,y:847,t:1527023515390};\\\", \\\"{x:1297,y:857,t:1527023515407};\\\", \\\"{x:1293,y:869,t:1527023515424};\\\", \\\"{x:1287,y:880,t:1527023515441};\\\", \\\"{x:1281,y:891,t:1527023515458};\\\", \\\"{x:1277,y:900,t:1527023515474};\\\", \\\"{x:1273,y:909,t:1527023515491};\\\", \\\"{x:1272,y:912,t:1527023515508};\\\", \\\"{x:1270,y:916,t:1527023515524};\\\", \\\"{x:1269,y:919,t:1527023515541};\\\", \\\"{x:1267,y:923,t:1527023515558};\\\", \\\"{x:1265,y:926,t:1527023515575};\\\", \\\"{x:1265,y:927,t:1527023515591};\\\", \\\"{x:1263,y:928,t:1527023515622};\\\", \\\"{x:1263,y:929,t:1527023515639};\\\", \\\"{x:1262,y:929,t:1527023515654};\\\", \\\"{x:1262,y:930,t:1527023515879};\\\", \\\"{x:1261,y:930,t:1527023515891};\\\", \\\"{x:1259,y:929,t:1527023515908};\\\", \\\"{x:1257,y:927,t:1527023515925};\\\", \\\"{x:1255,y:922,t:1527023515941};\\\", \\\"{x:1252,y:913,t:1527023515958};\\\", \\\"{x:1253,y:911,t:1527023516215};\\\", \\\"{x:1253,y:908,t:1527023516225};\\\", \\\"{x:1258,y:900,t:1527023516242};\\\", \\\"{x:1263,y:887,t:1527023516258};\\\", \\\"{x:1270,y:874,t:1527023516275};\\\", \\\"{x:1278,y:859,t:1527023516291};\\\", \\\"{x:1284,y:844,t:1527023516307};\\\", \\\"{x:1292,y:828,t:1527023516325};\\\", \\\"{x:1299,y:811,t:1527023516342};\\\", \\\"{x:1313,y:779,t:1527023516358};\\\", \\\"{x:1320,y:762,t:1527023516375};\\\", \\\"{x:1325,y:751,t:1527023516392};\\\", \\\"{x:1330,y:741,t:1527023516408};\\\", \\\"{x:1334,y:731,t:1527023516426};\\\", \\\"{x:1337,y:724,t:1527023516442};\\\", \\\"{x:1340,y:717,t:1527023516459};\\\", \\\"{x:1341,y:713,t:1527023516475};\\\", \\\"{x:1344,y:709,t:1527023516492};\\\", \\\"{x:1344,y:707,t:1527023516509};\\\", \\\"{x:1344,y:706,t:1527023516524};\\\", \\\"{x:1345,y:705,t:1527023516541};\\\", \\\"{x:1346,y:703,t:1527023516560};\\\", \\\"{x:1347,y:701,t:1527023516575};\\\", \\\"{x:1347,y:703,t:1527023516783};\\\", \\\"{x:1348,y:706,t:1527023516793};\\\", \\\"{x:1350,y:713,t:1527023516810};\\\", \\\"{x:1350,y:716,t:1527023516826};\\\", \\\"{x:1350,y:718,t:1527023516842};\\\", \\\"{x:1351,y:723,t:1527023516859};\\\", \\\"{x:1351,y:725,t:1527023516875};\\\", \\\"{x:1353,y:729,t:1527023516892};\\\", \\\"{x:1353,y:731,t:1527023516909};\\\", \\\"{x:1355,y:736,t:1527023516925};\\\", \\\"{x:1358,y:746,t:1527023516942};\\\", \\\"{x:1359,y:752,t:1527023516958};\\\", \\\"{x:1360,y:760,t:1527023516976};\\\", \\\"{x:1363,y:768,t:1527023516991};\\\", \\\"{x:1368,y:778,t:1527023517009};\\\", \\\"{x:1371,y:786,t:1527023517026};\\\", \\\"{x:1377,y:796,t:1527023517042};\\\", \\\"{x:1380,y:803,t:1527023517061};\\\", \\\"{x:1383,y:809,t:1527023517075};\\\", \\\"{x:1386,y:816,t:1527023517091};\\\", \\\"{x:1389,y:823,t:1527023517108};\\\", \\\"{x:1394,y:833,t:1527023517125};\\\", \\\"{x:1398,y:842,t:1527023517141};\\\", \\\"{x:1401,y:853,t:1527023517159};\\\", \\\"{x:1404,y:859,t:1527023517175};\\\", \\\"{x:1407,y:865,t:1527023517191};\\\", \\\"{x:1409,y:869,t:1527023517208};\\\", \\\"{x:1412,y:874,t:1527023517225};\\\", \\\"{x:1414,y:876,t:1527023517242};\\\", \\\"{x:1415,y:879,t:1527023517258};\\\", \\\"{x:1416,y:881,t:1527023517276};\\\", \\\"{x:1418,y:884,t:1527023517292};\\\", \\\"{x:1418,y:885,t:1527023517308};\\\", \\\"{x:1421,y:887,t:1527023517325};\\\", \\\"{x:1421,y:889,t:1527023517342};\\\", \\\"{x:1422,y:889,t:1527023517359};\\\", \\\"{x:1422,y:890,t:1527023517375};\\\", \\\"{x:1423,y:890,t:1527023517393};\\\", \\\"{x:1424,y:890,t:1527023517409};\\\", \\\"{x:1426,y:892,t:1527023517426};\\\", \\\"{x:1428,y:893,t:1527023517442};\\\", \\\"{x:1429,y:895,t:1527023517459};\\\", \\\"{x:1430,y:895,t:1527023517476};\\\", \\\"{x:1431,y:896,t:1527023517493};\\\", \\\"{x:1433,y:897,t:1527023517509};\\\", \\\"{x:1434,y:898,t:1527023517526};\\\", \\\"{x:1432,y:898,t:1527023517655};\\\", \\\"{x:1432,y:896,t:1527023517663};\\\", \\\"{x:1430,y:891,t:1527023517676};\\\", \\\"{x:1424,y:877,t:1527023517693};\\\", \\\"{x:1417,y:863,t:1527023517709};\\\", \\\"{x:1403,y:829,t:1527023517727};\\\", \\\"{x:1390,y:809,t:1527023517743};\\\", \\\"{x:1384,y:790,t:1527023517759};\\\", \\\"{x:1371,y:767,t:1527023517776};\\\", \\\"{x:1360,y:747,t:1527023517793};\\\", \\\"{x:1350,y:732,t:1527023517809};\\\", \\\"{x:1346,y:721,t:1527023517826};\\\", \\\"{x:1343,y:712,t:1527023517844};\\\", \\\"{x:1341,y:706,t:1527023517862};\\\", \\\"{x:1340,y:703,t:1527023517876};\\\", \\\"{x:1340,y:702,t:1527023517893};\\\", \\\"{x:1337,y:702,t:1527023517975};\\\", \\\"{x:1327,y:719,t:1527023517993};\\\", \\\"{x:1320,y:741,t:1527023518010};\\\", \\\"{x:1308,y:766,t:1527023518026};\\\", \\\"{x:1298,y:791,t:1527023518043};\\\", \\\"{x:1285,y:825,t:1527023518060};\\\", \\\"{x:1273,y:864,t:1527023518076};\\\", \\\"{x:1267,y:889,t:1527023518093};\\\", \\\"{x:1261,y:909,t:1527023518110};\\\", \\\"{x:1260,y:916,t:1527023518126};\\\", \\\"{x:1258,y:921,t:1527023518143};\\\", \\\"{x:1257,y:925,t:1527023518160};\\\", \\\"{x:1257,y:927,t:1527023518176};\\\", \\\"{x:1257,y:928,t:1527023518193};\\\", \\\"{x:1257,y:929,t:1527023518210};\\\", \\\"{x:1257,y:928,t:1527023518390};\\\", \\\"{x:1257,y:926,t:1527023518398};\\\", \\\"{x:1258,y:922,t:1527023518410};\\\", \\\"{x:1265,y:907,t:1527023518427};\\\", \\\"{x:1276,y:885,t:1527023518443};\\\", \\\"{x:1290,y:859,t:1527023518462};\\\", \\\"{x:1303,y:826,t:1527023518477};\\\", \\\"{x:1315,y:800,t:1527023518494};\\\", \\\"{x:1336,y:764,t:1527023518511};\\\", \\\"{x:1346,y:745,t:1527023518526};\\\", \\\"{x:1354,y:728,t:1527023518543};\\\", \\\"{x:1363,y:713,t:1527023518560};\\\", \\\"{x:1368,y:704,t:1527023518576};\\\", \\\"{x:1368,y:701,t:1527023518592};\\\", \\\"{x:1369,y:700,t:1527023518610};\\\", \\\"{x:1368,y:700,t:1527023519031};\\\", \\\"{x:1367,y:701,t:1527023519044};\\\", \\\"{x:1365,y:701,t:1527023519064};\\\", \\\"{x:1364,y:702,t:1527023519077};\\\", \\\"{x:1363,y:702,t:1527023519094};\\\", \\\"{x:1362,y:702,t:1527023519117};\\\", \\\"{x:1360,y:704,t:1527023520750};\\\", \\\"{x:1358,y:705,t:1527023520762};\\\", \\\"{x:1350,y:708,t:1527023520779};\\\", \\\"{x:1345,y:710,t:1527023520794};\\\", \\\"{x:1340,y:710,t:1527023520813};\\\", \\\"{x:1336,y:712,t:1527023520828};\\\", \\\"{x:1334,y:712,t:1527023520845};\\\", \\\"{x:1336,y:712,t:1527023521590};\\\", \\\"{x:1337,y:712,t:1527023521606};\\\", \\\"{x:1338,y:712,t:1527023521622};\\\", \\\"{x:1339,y:712,t:1527023521638};\\\", \\\"{x:1339,y:708,t:1527023523031};\\\", \\\"{x:1339,y:699,t:1527023523048};\\\", \\\"{x:1336,y:689,t:1527023523064};\\\", \\\"{x:1330,y:672,t:1527023523080};\\\", \\\"{x:1324,y:656,t:1527023523097};\\\", \\\"{x:1317,y:635,t:1527023523113};\\\", \\\"{x:1308,y:613,t:1527023523130};\\\", \\\"{x:1301,y:595,t:1527023523146};\\\", \\\"{x:1292,y:579,t:1527023523164};\\\", \\\"{x:1284,y:565,t:1527023523179};\\\", \\\"{x:1275,y:552,t:1527023523196};\\\", \\\"{x:1264,y:524,t:1527023523214};\\\", \\\"{x:1259,y:506,t:1527023523229};\\\", \\\"{x:1255,y:490,t:1527023523246};\\\", \\\"{x:1254,y:485,t:1527023523264};\\\", \\\"{x:1254,y:483,t:1527023523279};\\\", \\\"{x:1254,y:482,t:1527023523297};\\\", \\\"{x:1254,y:481,t:1527023523314};\\\", \\\"{x:1256,y:480,t:1527023523330};\\\", \\\"{x:1263,y:479,t:1527023523346};\\\", \\\"{x:1272,y:478,t:1527023523364};\\\", \\\"{x:1285,y:476,t:1527023523380};\\\", \\\"{x:1304,y:473,t:1527023523396};\\\", \\\"{x:1328,y:469,t:1527023523414};\\\", \\\"{x:1345,y:467,t:1527023523431};\\\", \\\"{x:1369,y:466,t:1527023523447};\\\", \\\"{x:1388,y:464,t:1527023523464};\\\", \\\"{x:1409,y:462,t:1527023523480};\\\", \\\"{x:1425,y:460,t:1527023523497};\\\", \\\"{x:1437,y:459,t:1527023523514};\\\", \\\"{x:1445,y:457,t:1527023523531};\\\", \\\"{x:1447,y:457,t:1527023523547};\\\", \\\"{x:1449,y:457,t:1527023523564};\\\", \\\"{x:1452,y:457,t:1527023523581};\\\", \\\"{x:1460,y:457,t:1527023523597};\\\", \\\"{x:1479,y:457,t:1527023523614};\\\", \\\"{x:1490,y:457,t:1527023523631};\\\", \\\"{x:1503,y:457,t:1527023523648};\\\", \\\"{x:1508,y:456,t:1527023523664};\\\", \\\"{x:1513,y:456,t:1527023523681};\\\", \\\"{x:1520,y:456,t:1527023523697};\\\", \\\"{x:1527,y:455,t:1527023523714};\\\", \\\"{x:1531,y:453,t:1527023523731};\\\", \\\"{x:1535,y:452,t:1527023523747};\\\", \\\"{x:1539,y:452,t:1527023523764};\\\", \\\"{x:1541,y:451,t:1527023523781};\\\", \\\"{x:1545,y:449,t:1527023523797};\\\", \\\"{x:1548,y:449,t:1527023523814};\\\", \\\"{x:1549,y:448,t:1527023523832};\\\", \\\"{x:1550,y:448,t:1527023523870};\\\", \\\"{x:1551,y:448,t:1527023523881};\\\", \\\"{x:1552,y:448,t:1527023523897};\\\", \\\"{x:1555,y:446,t:1527023523915};\\\", \\\"{x:1558,y:446,t:1527023523932};\\\", \\\"{x:1561,y:446,t:1527023523949};\\\", \\\"{x:1564,y:446,t:1527023523964};\\\", \\\"{x:1567,y:445,t:1527023523981};\\\", \\\"{x:1570,y:444,t:1527023523998};\\\", \\\"{x:1572,y:444,t:1527023524014};\\\", \\\"{x:1575,y:443,t:1527023524032};\\\", \\\"{x:1576,y:443,t:1527023524048};\\\", \\\"{x:1578,y:442,t:1527023524064};\\\", \\\"{x:1580,y:442,t:1527023524086};\\\", \\\"{x:1581,y:442,t:1527023524098};\\\", \\\"{x:1580,y:442,t:1527023526423};\\\", \\\"{x:1573,y:442,t:1527023526435};\\\", \\\"{x:1562,y:442,t:1527023526449};\\\", \\\"{x:1547,y:442,t:1527023526466};\\\", \\\"{x:1531,y:442,t:1527023526483};\\\", \\\"{x:1517,y:442,t:1527023526499};\\\", \\\"{x:1503,y:442,t:1527023526517};\\\", \\\"{x:1493,y:442,t:1527023526534};\\\", \\\"{x:1486,y:442,t:1527023526550};\\\", \\\"{x:1478,y:442,t:1527023526566};\\\", \\\"{x:1471,y:442,t:1527023526583};\\\", \\\"{x:1464,y:442,t:1527023526600};\\\", \\\"{x:1454,y:442,t:1527023526616};\\\", \\\"{x:1445,y:442,t:1527023526633};\\\", \\\"{x:1436,y:442,t:1527023526650};\\\", \\\"{x:1422,y:442,t:1527023526666};\\\", \\\"{x:1412,y:443,t:1527023526683};\\\", \\\"{x:1397,y:444,t:1527023526701};\\\", \\\"{x:1380,y:447,t:1527023526716};\\\", \\\"{x:1360,y:449,t:1527023526733};\\\", \\\"{x:1335,y:451,t:1527023526750};\\\", \\\"{x:1322,y:451,t:1527023526767};\\\", \\\"{x:1306,y:453,t:1527023526784};\\\", \\\"{x:1296,y:454,t:1527023526801};\\\", \\\"{x:1291,y:454,t:1527023526816};\\\", \\\"{x:1289,y:455,t:1527023526833};\\\", \\\"{x:1288,y:455,t:1527023526910};\\\", \\\"{x:1288,y:457,t:1527023526918};\\\", \\\"{x:1287,y:459,t:1527023526934};\\\", \\\"{x:1287,y:468,t:1527023526951};\\\", \\\"{x:1287,y:472,t:1527023526966};\\\", \\\"{x:1287,y:477,t:1527023526983};\\\", \\\"{x:1289,y:483,t:1527023526999};\\\", \\\"{x:1291,y:489,t:1527023527017};\\\", \\\"{x:1294,y:497,t:1527023527032};\\\", \\\"{x:1297,y:503,t:1527023527050};\\\", \\\"{x:1298,y:509,t:1527023527067};\\\", \\\"{x:1298,y:511,t:1527023527082};\\\", \\\"{x:1298,y:512,t:1527023527100};\\\", \\\"{x:1298,y:514,t:1527023527116};\\\", \\\"{x:1298,y:515,t:1527023527133};\\\", \\\"{x:1296,y:518,t:1527023527149};\\\", \\\"{x:1294,y:520,t:1527023527167};\\\", \\\"{x:1292,y:521,t:1527023527183};\\\", \\\"{x:1290,y:522,t:1527023527200};\\\", \\\"{x:1289,y:522,t:1527023527217};\\\", \\\"{x:1288,y:522,t:1527023527233};\\\", \\\"{x:1287,y:522,t:1527023527270};\\\", \\\"{x:1288,y:523,t:1527023531326};\\\", \\\"{x:1296,y:523,t:1527023531337};\\\", \\\"{x:1332,y:523,t:1527023531353};\\\", \\\"{x:1382,y:523,t:1527023531370};\\\", \\\"{x:1441,y:522,t:1527023531386};\\\", \\\"{x:1503,y:522,t:1527023531404};\\\", \\\"{x:1542,y:522,t:1527023531421};\\\", \\\"{x:1568,y:522,t:1527023531437};\\\", \\\"{x:1578,y:522,t:1527023531454};\\\", \\\"{x:1580,y:522,t:1527023531470};\\\", \\\"{x:1579,y:522,t:1527023531606};\\\", \\\"{x:1571,y:522,t:1527023531621};\\\", \\\"{x:1545,y:522,t:1527023531637};\\\", \\\"{x:1515,y:522,t:1527023531653};\\\", \\\"{x:1476,y:522,t:1527023531670};\\\", \\\"{x:1451,y:520,t:1527023531688};\\\", \\\"{x:1432,y:518,t:1527023531704};\\\", \\\"{x:1422,y:516,t:1527023531720};\\\", \\\"{x:1419,y:515,t:1527023531738};\\\", \\\"{x:1418,y:515,t:1527023531754};\\\", \\\"{x:1399,y:515,t:1527023532942};\\\", \\\"{x:1372,y:519,t:1527023532954};\\\", \\\"{x:1276,y:536,t:1527023532972};\\\", \\\"{x:1142,y:569,t:1527023532988};\\\", \\\"{x:994,y:601,t:1527023533005};\\\", \\\"{x:757,y:634,t:1527023533022};\\\", \\\"{x:606,y:645,t:1527023533038};\\\", \\\"{x:501,y:645,t:1527023533054};\\\", \\\"{x:437,y:645,t:1527023533071};\\\", \\\"{x:405,y:645,t:1527023533088};\\\", \\\"{x:393,y:641,t:1527023533104};\\\", \\\"{x:385,y:635,t:1527023533121};\\\", \\\"{x:382,y:630,t:1527023533139};\\\", \\\"{x:382,y:626,t:1527023533154};\\\", \\\"{x:381,y:618,t:1527023533172};\\\", \\\"{x:379,y:608,t:1527023533191};\\\", \\\"{x:377,y:595,t:1527023533204};\\\", \\\"{x:377,y:581,t:1527023533221};\\\", \\\"{x:377,y:563,t:1527023533239};\\\", \\\"{x:378,y:551,t:1527023533256};\\\", \\\"{x:379,y:541,t:1527023533272};\\\", \\\"{x:387,y:529,t:1527023533290};\\\", \\\"{x:395,y:521,t:1527023533305};\\\", \\\"{x:407,y:511,t:1527023533322};\\\", \\\"{x:423,y:505,t:1527023533339};\\\", \\\"{x:443,y:501,t:1527023533356};\\\", \\\"{x:465,y:499,t:1527023533372};\\\", \\\"{x:487,y:495,t:1527023533389};\\\", \\\"{x:488,y:495,t:1527023533405};\\\", \\\"{x:481,y:497,t:1527023533437};\\\", \\\"{x:461,y:503,t:1527023533446};\\\", \\\"{x:439,y:509,t:1527023533455};\\\", \\\"{x:388,y:516,t:1527023533472};\\\", \\\"{x:327,y:523,t:1527023533489};\\\", \\\"{x:258,y:523,t:1527023533506};\\\", \\\"{x:185,y:523,t:1527023533522};\\\", \\\"{x:135,y:523,t:1527023533539};\\\", \\\"{x:98,y:523,t:1527023533556};\\\", \\\"{x:72,y:523,t:1527023533572};\\\", \\\"{x:57,y:522,t:1527023533589};\\\", \\\"{x:61,y:522,t:1527023533709};\\\", \\\"{x:69,y:522,t:1527023533723};\\\", \\\"{x:95,y:522,t:1527023533739};\\\", \\\"{x:121,y:522,t:1527023533756};\\\", \\\"{x:155,y:522,t:1527023533773};\\\", \\\"{x:175,y:522,t:1527023533789};\\\", \\\"{x:188,y:519,t:1527023533806};\\\", \\\"{x:197,y:517,t:1527023533823};\\\", \\\"{x:200,y:516,t:1527023533839};\\\", \\\"{x:200,y:515,t:1527023533861};\\\", \\\"{x:200,y:514,t:1527023533941};\\\", \\\"{x:202,y:514,t:1527023534007};\\\", \\\"{x:213,y:514,t:1527023534024};\\\", \\\"{x:234,y:515,t:1527023534039};\\\", \\\"{x:261,y:519,t:1527023534056};\\\", \\\"{x:294,y:524,t:1527023534075};\\\", \\\"{x:331,y:529,t:1527023534089};\\\", \\\"{x:368,y:536,t:1527023534106};\\\", \\\"{x:387,y:538,t:1527023534123};\\\", \\\"{x:406,y:543,t:1527023534140};\\\", \\\"{x:419,y:544,t:1527023534156};\\\", \\\"{x:427,y:546,t:1527023534173};\\\", \\\"{x:422,y:546,t:1527023534382};\\\", \\\"{x:418,y:546,t:1527023534390};\\\", \\\"{x:410,y:546,t:1527023534406};\\\", \\\"{x:405,y:546,t:1527023534423};\\\", \\\"{x:404,y:546,t:1527023534440};\\\", \\\"{x:404,y:545,t:1527023534509};\\\", \\\"{x:409,y:544,t:1527023534523};\\\", \\\"{x:426,y:538,t:1527023534540};\\\", \\\"{x:452,y:531,t:1527023534556};\\\", \\\"{x:548,y:522,t:1527023534573};\\\", \\\"{x:630,y:520,t:1527023534590};\\\", \\\"{x:710,y:520,t:1527023534606};\\\", \\\"{x:805,y:523,t:1527023534624};\\\", \\\"{x:883,y:534,t:1527023534640};\\\", \\\"{x:931,y:540,t:1527023534657};\\\", \\\"{x:951,y:542,t:1527023534673};\\\", \\\"{x:956,y:542,t:1527023534689};\\\", \\\"{x:953,y:542,t:1527023534813};\\\", \\\"{x:947,y:542,t:1527023534823};\\\", \\\"{x:935,y:540,t:1527023534839};\\\", \\\"{x:921,y:534,t:1527023534856};\\\", \\\"{x:908,y:529,t:1527023534873};\\\", \\\"{x:891,y:522,t:1527023534890};\\\", \\\"{x:877,y:513,t:1527023534907};\\\", \\\"{x:869,y:509,t:1527023534924};\\\", \\\"{x:864,y:507,t:1527023534940};\\\", \\\"{x:859,y:504,t:1527023534958};\\\", \\\"{x:852,y:500,t:1527023534975};\\\", \\\"{x:849,y:499,t:1527023534990};\\\", \\\"{x:848,y:498,t:1527023535007};\\\", \\\"{x:847,y:497,t:1527023535023};\\\", \\\"{x:845,y:496,t:1527023535041};\\\", \\\"{x:844,y:494,t:1527023535057};\\\", \\\"{x:842,y:491,t:1527023535073};\\\", \\\"{x:841,y:489,t:1527023535090};\\\", \\\"{x:839,y:488,t:1527023535107};\\\", \\\"{x:839,y:491,t:1527023535671};\\\", \\\"{x:839,y:497,t:1527023535677};\\\", \\\"{x:839,y:502,t:1527023535692};\\\", \\\"{x:842,y:515,t:1527023535709};\\\", \\\"{x:850,y:531,t:1527023535724};\\\", \\\"{x:868,y:560,t:1527023535742};\\\", \\\"{x:886,y:578,t:1527023535756};\\\", \\\"{x:908,y:595,t:1527023535774};\\\", \\\"{x:925,y:610,t:1527023535790};\\\", \\\"{x:941,y:619,t:1527023535807};\\\", \\\"{x:953,y:629,t:1527023535823};\\\", \\\"{x:959,y:633,t:1527023535841};\\\", \\\"{x:962,y:635,t:1527023535858};\\\", \\\"{x:963,y:636,t:1527023535874};\\\", \\\"{x:965,y:637,t:1527023535901};\\\", \\\"{x:966,y:637,t:1527023535918};\\\", \\\"{x:966,y:638,t:1527023535926};\\\", \\\"{x:968,y:639,t:1527023535941};\\\", \\\"{x:970,y:640,t:1527023535958};\\\", \\\"{x:972,y:642,t:1527023535975};\\\", \\\"{x:976,y:645,t:1527023535992};\\\", \\\"{x:978,y:647,t:1527023536008};\\\", \\\"{x:981,y:649,t:1527023536025};\\\", \\\"{x:983,y:651,t:1527023536042};\\\", \\\"{x:984,y:652,t:1527023536060};\\\", \\\"{x:986,y:655,t:1527023536074};\\\", \\\"{x:986,y:656,t:1527023536091};\\\", \\\"{x:987,y:658,t:1527023536108};\\\", \\\"{x:988,y:660,t:1527023536124};\\\", \\\"{x:991,y:666,t:1527023536141};\\\", \\\"{x:993,y:670,t:1527023536158};\\\", \\\"{x:994,y:673,t:1527023536174};\\\", \\\"{x:997,y:678,t:1527023536191};\\\", \\\"{x:1001,y:682,t:1527023536208};\\\", \\\"{x:1012,y:689,t:1527023536224};\\\", \\\"{x:1025,y:692,t:1527023536241};\\\", \\\"{x:1036,y:692,t:1527023536258};\\\", \\\"{x:1038,y:692,t:1527023536275};\\\", \\\"{x:1041,y:693,t:1527023537294};\\\", \\\"{x:1044,y:695,t:1527023537309};\\\", \\\"{x:1048,y:698,t:1527023537326};\\\", \\\"{x:1051,y:701,t:1527023537343};\\\", \\\"{x:1053,y:702,t:1527023537359};\\\", \\\"{x:1056,y:703,t:1527023537376};\\\", \\\"{x:1057,y:704,t:1527023537392};\\\", \\\"{x:1058,y:705,t:1527023537430};\\\", \\\"{x:1059,y:706,t:1527023537446};\\\", \\\"{x:1059,y:707,t:1527023537462};\\\", \\\"{x:1060,y:708,t:1527023537486};\\\", \\\"{x:1061,y:709,t:1527023537502};\\\", \\\"{x:1061,y:710,t:1527023537526};\\\", \\\"{x:1062,y:711,t:1527023537542};\\\", \\\"{x:1062,y:712,t:1527023537574};\\\", \\\"{x:1062,y:713,t:1527023537614};\\\", \\\"{x:1063,y:713,t:1527023537626};\\\", \\\"{x:1063,y:714,t:1527023537646};\\\", \\\"{x:1064,y:715,t:1527023537662};\\\", \\\"{x:1064,y:716,t:1527023537677};\\\", \\\"{x:1065,y:717,t:1527023537694};\\\", \\\"{x:1065,y:719,t:1527023537726};\\\", \\\"{x:1065,y:720,t:1527023537766};\\\", \\\"{x:1066,y:720,t:1527023537782};\\\", \\\"{x:1067,y:721,t:1527023537822};\\\", \\\"{x:1068,y:723,t:1527023537927};\\\", \\\"{x:1069,y:724,t:1527023537943};\\\", \\\"{x:1070,y:724,t:1527023537960};\\\", \\\"{x:1072,y:726,t:1527023537977};\\\", \\\"{x:1072,y:727,t:1527023537993};\\\", \\\"{x:1073,y:728,t:1527023538009};\\\", \\\"{x:1074,y:729,t:1527023538027};\\\", \\\"{x:1075,y:729,t:1527023538043};\\\", \\\"{x:1075,y:730,t:1527023538061};\\\", \\\"{x:1076,y:730,t:1527023538077};\\\", \\\"{x:1077,y:732,t:1527023538094};\\\", \\\"{x:1078,y:732,t:1527023538109};\\\", \\\"{x:1082,y:734,t:1527023538127};\\\", \\\"{x:1086,y:736,t:1527023538144};\\\", \\\"{x:1091,y:737,t:1527023538160};\\\", \\\"{x:1098,y:739,t:1527023538177};\\\", \\\"{x:1109,y:743,t:1527023538194};\\\", \\\"{x:1115,y:744,t:1527023538210};\\\", \\\"{x:1123,y:746,t:1527023538227};\\\", \\\"{x:1131,y:748,t:1527023538244};\\\", \\\"{x:1136,y:750,t:1527023538261};\\\", \\\"{x:1142,y:751,t:1527023538277};\\\", \\\"{x:1146,y:753,t:1527023538294};\\\", \\\"{x:1148,y:753,t:1527023538310};\\\", \\\"{x:1150,y:755,t:1527023538327};\\\", \\\"{x:1151,y:755,t:1527023538375};\\\", \\\"{x:1152,y:755,t:1527023538390};\\\", \\\"{x:1153,y:756,t:1527023538406};\\\", \\\"{x:1155,y:756,t:1527023538422};\\\", \\\"{x:1156,y:756,t:1527023538446};\\\", \\\"{x:1158,y:758,t:1527023538461};\\\", \\\"{x:1160,y:759,t:1527023538477};\\\", \\\"{x:1165,y:760,t:1527023538494};\\\", \\\"{x:1168,y:761,t:1527023538510};\\\", \\\"{x:1170,y:761,t:1527023538527};\\\", \\\"{x:1173,y:762,t:1527023538544};\\\", \\\"{x:1174,y:763,t:1527023538561};\\\", \\\"{x:1178,y:765,t:1527023538576};\\\", \\\"{x:1185,y:766,t:1527023538594};\\\", \\\"{x:1192,y:767,t:1527023538611};\\\", \\\"{x:1201,y:770,t:1527023538626};\\\", \\\"{x:1218,y:774,t:1527023538644};\\\", \\\"{x:1234,y:780,t:1527023538662};\\\", \\\"{x:1255,y:783,t:1527023538677};\\\", \\\"{x:1298,y:796,t:1527023538694};\\\", \\\"{x:1337,y:807,t:1527023538710};\\\", \\\"{x:1369,y:815,t:1527023538727};\\\", \\\"{x:1403,y:825,t:1527023538744};\\\", \\\"{x:1430,y:831,t:1527023538760};\\\", \\\"{x:1455,y:837,t:1527023538777};\\\", \\\"{x:1469,y:842,t:1527023538794};\\\", \\\"{x:1489,y:847,t:1527023538811};\\\", \\\"{x:1506,y:852,t:1527023538827};\\\", \\\"{x:1523,y:858,t:1527023538844};\\\", \\\"{x:1535,y:861,t:1527023538861};\\\", \\\"{x:1545,y:864,t:1527023538877};\\\", \\\"{x:1554,y:867,t:1527023538894};\\\", \\\"{x:1559,y:869,t:1527023538911};\\\", \\\"{x:1561,y:870,t:1527023538927};\\\", \\\"{x:1562,y:871,t:1527023538943};\\\", \\\"{x:1563,y:872,t:1527023538960};\\\", \\\"{x:1564,y:873,t:1527023538977};\\\", \\\"{x:1565,y:874,t:1527023538994};\\\", \\\"{x:1566,y:875,t:1527023539011};\\\", \\\"{x:1566,y:877,t:1527023539028};\\\", \\\"{x:1567,y:880,t:1527023539044};\\\", \\\"{x:1567,y:882,t:1527023539061};\\\", \\\"{x:1569,y:886,t:1527023539078};\\\", \\\"{x:1569,y:887,t:1527023539094};\\\", \\\"{x:1569,y:889,t:1527023539111};\\\", \\\"{x:1569,y:891,t:1527023539127};\\\", \\\"{x:1568,y:893,t:1527023539143};\\\", \\\"{x:1567,y:894,t:1527023539160};\\\", \\\"{x:1566,y:894,t:1527023539177};\\\", \\\"{x:1565,y:896,t:1527023539206};\\\", \\\"{x:1563,y:896,t:1527023539230};\\\", \\\"{x:1563,y:897,t:1527023539262};\\\", \\\"{x:1563,y:898,t:1527023539334};\\\", \\\"{x:1563,y:899,t:1527023539350};\\\", \\\"{x:1563,y:900,t:1527023539414};\\\", \\\"{x:1563,y:901,t:1527023539438};\\\", \\\"{x:1564,y:902,t:1527023539910};\\\", \\\"{x:1569,y:903,t:1527023539928};\\\", \\\"{x:1576,y:903,t:1527023539945};\\\", \\\"{x:1583,y:904,t:1527023539962};\\\", \\\"{x:1587,y:906,t:1527023539977};\\\", \\\"{x:1590,y:906,t:1527023539994};\\\", \\\"{x:1593,y:907,t:1527023540011};\\\", \\\"{x:1593,y:906,t:1527023540125};\\\", \\\"{x:1593,y:904,t:1527023540133};\\\", \\\"{x:1593,y:902,t:1527023540144};\\\", \\\"{x:1593,y:895,t:1527023540161};\\\", \\\"{x:1589,y:881,t:1527023540178};\\\", \\\"{x:1581,y:863,t:1527023540194};\\\", \\\"{x:1574,y:839,t:1527023540212};\\\", \\\"{x:1563,y:812,t:1527023540227};\\\", \\\"{x:1559,y:796,t:1527023540245};\\\", \\\"{x:1550,y:774,t:1527023540261};\\\", \\\"{x:1547,y:753,t:1527023540278};\\\", \\\"{x:1546,y:740,t:1527023540295};\\\", \\\"{x:1544,y:730,t:1527023540311};\\\", \\\"{x:1542,y:726,t:1527023540328};\\\", \\\"{x:1540,y:722,t:1527023540344};\\\", \\\"{x:1539,y:720,t:1527023540362};\\\", \\\"{x:1537,y:717,t:1527023540379};\\\", \\\"{x:1535,y:713,t:1527023540394};\\\", \\\"{x:1533,y:710,t:1527023540412};\\\", \\\"{x:1532,y:710,t:1527023540428};\\\", \\\"{x:1532,y:709,t:1527023540445};\\\", \\\"{x:1525,y:707,t:1527023540838};\\\", \\\"{x:1516,y:703,t:1527023540847};\\\", \\\"{x:1498,y:695,t:1527023540863};\\\", \\\"{x:1471,y:678,t:1527023540879};\\\", \\\"{x:1441,y:661,t:1527023540896};\\\", \\\"{x:1423,y:649,t:1527023540912};\\\", \\\"{x:1408,y:637,t:1527023540929};\\\", \\\"{x:1399,y:627,t:1527023540946};\\\", \\\"{x:1394,y:617,t:1527023540962};\\\", \\\"{x:1392,y:610,t:1527023540979};\\\", \\\"{x:1390,y:601,t:1527023540996};\\\", \\\"{x:1390,y:591,t:1527023541012};\\\", \\\"{x:1390,y:581,t:1527023541028};\\\", \\\"{x:1390,y:570,t:1527023541046};\\\", \\\"{x:1390,y:566,t:1527023541062};\\\", \\\"{x:1391,y:562,t:1527023541079};\\\", \\\"{x:1394,y:557,t:1527023541096};\\\", \\\"{x:1395,y:554,t:1527023541112};\\\", \\\"{x:1395,y:553,t:1527023541129};\\\", \\\"{x:1396,y:553,t:1527023541214};\\\", \\\"{x:1397,y:553,t:1527023541230};\\\", \\\"{x:1397,y:556,t:1527023541246};\\\", \\\"{x:1397,y:558,t:1527023541318};\\\", \\\"{x:1397,y:559,t:1527023541329};\\\", \\\"{x:1397,y:561,t:1527023541346};\\\", \\\"{x:1397,y:562,t:1527023541363};\\\", \\\"{x:1397,y:563,t:1527023541379};\\\", \\\"{x:1398,y:564,t:1527023541406};\\\", \\\"{x:1400,y:565,t:1527023541422};\\\", \\\"{x:1400,y:566,t:1527023541438};\\\", \\\"{x:1401,y:566,t:1527023541446};\\\", \\\"{x:1404,y:568,t:1527023541463};\\\", \\\"{x:1407,y:568,t:1527023541479};\\\", \\\"{x:1409,y:568,t:1527023541496};\\\", \\\"{x:1415,y:568,t:1527023541513};\\\", \\\"{x:1419,y:568,t:1527023541529};\\\", \\\"{x:1426,y:568,t:1527023541546};\\\", \\\"{x:1430,y:568,t:1527023541563};\\\", \\\"{x:1437,y:568,t:1527023541579};\\\", \\\"{x:1439,y:568,t:1527023541596};\\\", \\\"{x:1440,y:568,t:1527023541613};\\\", \\\"{x:1440,y:569,t:1527023541702};\\\", \\\"{x:1440,y:572,t:1527023541713};\\\", \\\"{x:1434,y:584,t:1527023541730};\\\", \\\"{x:1427,y:602,t:1527023541746};\\\", \\\"{x:1416,y:622,t:1527023541763};\\\", \\\"{x:1405,y:643,t:1527023541781};\\\", \\\"{x:1391,y:668,t:1527023541796};\\\", \\\"{x:1384,y:685,t:1527023541813};\\\", \\\"{x:1378,y:707,t:1527023541830};\\\", \\\"{x:1375,y:716,t:1527023541846};\\\", \\\"{x:1374,y:722,t:1527023541863};\\\", \\\"{x:1370,y:731,t:1527023541880};\\\", \\\"{x:1366,y:741,t:1527023541896};\\\", \\\"{x:1362,y:750,t:1527023541913};\\\", \\\"{x:1359,y:757,t:1527023541930};\\\", \\\"{x:1355,y:764,t:1527023541946};\\\", \\\"{x:1353,y:768,t:1527023541963};\\\", \\\"{x:1351,y:773,t:1527023541980};\\\", \\\"{x:1349,y:778,t:1527023541996};\\\", \\\"{x:1345,y:786,t:1527023542013};\\\", \\\"{x:1343,y:792,t:1527023542030};\\\", \\\"{x:1341,y:797,t:1527023542047};\\\", \\\"{x:1341,y:800,t:1527023542063};\\\", \\\"{x:1339,y:802,t:1527023542080};\\\", \\\"{x:1337,y:806,t:1527023542097};\\\", \\\"{x:1335,y:811,t:1527023542113};\\\", \\\"{x:1332,y:815,t:1527023542130};\\\", \\\"{x:1330,y:818,t:1527023542146};\\\", \\\"{x:1329,y:821,t:1527023542163};\\\", \\\"{x:1327,y:825,t:1527023542180};\\\", \\\"{x:1325,y:827,t:1527023542196};\\\", \\\"{x:1323,y:832,t:1527023542212};\\\", \\\"{x:1319,y:840,t:1527023542230};\\\", \\\"{x:1317,y:845,t:1527023542247};\\\", \\\"{x:1315,y:849,t:1527023542263};\\\", \\\"{x:1314,y:852,t:1527023542279};\\\", \\\"{x:1312,y:856,t:1527023542297};\\\", \\\"{x:1311,y:858,t:1527023542313};\\\", \\\"{x:1310,y:860,t:1527023542330};\\\", \\\"{x:1308,y:864,t:1527023542347};\\\", \\\"{x:1307,y:868,t:1527023542364};\\\", \\\"{x:1305,y:872,t:1527023542380};\\\", \\\"{x:1303,y:875,t:1527023542397};\\\", \\\"{x:1302,y:877,t:1527023542413};\\\", \\\"{x:1300,y:880,t:1527023542430};\\\", \\\"{x:1297,y:883,t:1527023542447};\\\", \\\"{x:1296,y:885,t:1527023542464};\\\", \\\"{x:1294,y:889,t:1527023542480};\\\", \\\"{x:1293,y:890,t:1527023542497};\\\", \\\"{x:1292,y:891,t:1527023542514};\\\", \\\"{x:1291,y:892,t:1527023542530};\\\", \\\"{x:1292,y:892,t:1527023542726};\\\", \\\"{x:1294,y:890,t:1527023542734};\\\", \\\"{x:1297,y:886,t:1527023542750};\\\", \\\"{x:1298,y:883,t:1527023542764};\\\", \\\"{x:1302,y:879,t:1527023542780};\\\", \\\"{x:1308,y:868,t:1527023542797};\\\", \\\"{x:1317,y:854,t:1527023542814};\\\", \\\"{x:1322,y:842,t:1527023542830};\\\", \\\"{x:1325,y:833,t:1527023542847};\\\", \\\"{x:1327,y:826,t:1527023542864};\\\", \\\"{x:1328,y:819,t:1527023542880};\\\", \\\"{x:1329,y:815,t:1527023542897};\\\", \\\"{x:1329,y:811,t:1527023542915};\\\", \\\"{x:1329,y:809,t:1527023542931};\\\", \\\"{x:1329,y:807,t:1527023542947};\\\", \\\"{x:1328,y:807,t:1527023542966};\\\", \\\"{x:1326,y:807,t:1527023542981};\\\", \\\"{x:1314,y:807,t:1527023542997};\\\", \\\"{x:1276,y:822,t:1527023543014};\\\", \\\"{x:1215,y:850,t:1527023543030};\\\", \\\"{x:1131,y:877,t:1527023543048};\\\", \\\"{x:1065,y:894,t:1527023543064};\\\", \\\"{x:1003,y:903,t:1527023543081};\\\", \\\"{x:953,y:908,t:1527023543098};\\\", \\\"{x:924,y:908,t:1527023543114};\\\", \\\"{x:892,y:908,t:1527023543131};\\\", \\\"{x:861,y:903,t:1527023543147};\\\", \\\"{x:836,y:898,t:1527023543163};\\\", \\\"{x:811,y:885,t:1527023543181};\\\", \\\"{x:787,y:864,t:1527023543197};\\\", \\\"{x:756,y:838,t:1527023543214};\\\", \\\"{x:726,y:814,t:1527023543231};\\\", \\\"{x:687,y:778,t:1527023543247};\\\", \\\"{x:636,y:739,t:1527023543264};\\\", \\\"{x:602,y:715,t:1527023543281};\\\", \\\"{x:571,y:694,t:1527023543297};\\\", \\\"{x:537,y:665,t:1527023543314};\\\", \\\"{x:505,y:631,t:1527023543331};\\\", \\\"{x:478,y:609,t:1527023543348};\\\", \\\"{x:453,y:595,t:1527023543363};\\\", \\\"{x:437,y:586,t:1527023543380};\\\", \\\"{x:424,y:580,t:1527023543397};\\\", \\\"{x:422,y:578,t:1527023543414};\\\", \\\"{x:421,y:585,t:1527023543509};\\\", \\\"{x:422,y:589,t:1527023543517};\\\", \\\"{x:427,y:596,t:1527023543530};\\\", \\\"{x:438,y:608,t:1527023543547};\\\", \\\"{x:445,y:619,t:1527023543565};\\\", \\\"{x:454,y:632,t:1527023543581};\\\", \\\"{x:466,y:646,t:1527023543598};\\\", \\\"{x:470,y:653,t:1527023543614};\\\", \\\"{x:472,y:654,t:1527023543630};\\\", \\\"{x:473,y:656,t:1527023543647};\\\", \\\"{x:473,y:658,t:1527023543677};\\\", \\\"{x:473,y:659,t:1527023543693};\\\", \\\"{x:475,y:660,t:1527023543702};\\\", \\\"{x:475,y:661,t:1527023543713};\\\", \\\"{x:476,y:664,t:1527023543731};\\\", \\\"{x:477,y:665,t:1527023543746};\\\", \\\"{x:478,y:668,t:1527023543766};\\\", \\\"{x:479,y:670,t:1527023543780};\\\", \\\"{x:479,y:673,t:1527023543797};\\\", \\\"{x:479,y:675,t:1527023543814};\\\", \\\"{x:479,y:676,t:1527023543831};\\\", \\\"{x:480,y:679,t:1527023543847};\\\", \\\"{x:480,y:680,t:1527023543864};\\\", \\\"{x:480,y:682,t:1527023543882};\\\", \\\"{x:480,y:683,t:1527023543898};\\\", \\\"{x:482,y:683,t:1527023544598};\\\", \\\"{x:487,y:678,t:1527023544615};\\\", \\\"{x:492,y:671,t:1527023544631};\\\", \\\"{x:497,y:666,t:1527023544649};\\\", \\\"{x:503,y:661,t:1527023544665};\\\", \\\"{x:508,y:657,t:1527023544682};\\\", \\\"{x:510,y:655,t:1527023544698};\\\", \\\"{x:515,y:655,t:1527023544715};\\\", \\\"{x:522,y:654,t:1527023544731};\\\", \\\"{x:532,y:654,t:1527023544749};\\\", \\\"{x:558,y:655,t:1527023544765};\\\", \\\"{x:580,y:656,t:1527023544781};\\\", \\\"{x:608,y:659,t:1527023544799};\\\", \\\"{x:637,y:660,t:1527023544816};\\\", \\\"{x:669,y:662,t:1527023544832};\\\", \\\"{x:700,y:662,t:1527023544849};\\\", \\\"{x:721,y:662,t:1527023544865};\\\", \\\"{x:734,y:662,t:1527023544882};\\\", \\\"{x:742,y:662,t:1527023544899};\\\", \\\"{x:749,y:662,t:1527023544915};\\\", \\\"{x:756,y:659,t:1527023544932};\\\", \\\"{x:762,y:654,t:1527023544949};\\\", \\\"{x:768,y:648,t:1527023544965};\\\", \\\"{x:770,y:644,t:1527023544981};\\\", \\\"{x:770,y:642,t:1527023544998};\\\", \\\"{x:770,y:640,t:1527023545016};\\\", \\\"{x:770,y:638,t:1527023545031};\\\", \\\"{x:771,y:638,t:1527023545048};\\\", \\\"{x:771,y:637,t:1527023545066};\\\" ] }, { \\\"rt\\\": 70860, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 13, \\\"time_elapsed\\\": 701645, \\\"internal_node_id\\\": \\\"0.0-6.0-3.0\\\", \\\"subject\\\": \\\"QOJ6L\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"hotel\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime+before+endtime+during\\\", \\\"q\\\": 9, \\\"clicks\\\": 0, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-J -12 PM-11 AM-0-0-I -I -J -I -01 PM-01 PM-M -08 AM-10 AM-01 PM-11 AM-10 AM-E -E -E -I -I -11 AM-4-I -I -B -10 AM-B -B -02 PM-02 PM-12 PM-M -M -01 PM-12 PM-M -11 AM-M -B -B -11 AM-B -10 AM-B -B -B -02 PM-12 PM-11 AM-02 PM-02 PM-B -B -M -12 PM-12 PM-B -12 PM-12 PM-M -09 AM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:771,y:636,t:1527023547141};\\\", \\\"{x:771,y:634,t:1527023547151};\\\", \\\"{x:759,y:626,t:1527023547166};\\\", \\\"{x:752,y:620,t:1527023547183};\\\", \\\"{x:749,y:615,t:1527023547200};\\\", \\\"{x:742,y:606,t:1527023547217};\\\", \\\"{x:736,y:594,t:1527023547233};\\\", \\\"{x:728,y:581,t:1527023547250};\\\", \\\"{x:718,y:567,t:1527023547267};\\\", \\\"{x:711,y:557,t:1527023547283};\\\", \\\"{x:706,y:551,t:1527023547300};\\\", \\\"{x:698,y:545,t:1527023547316};\\\", \\\"{x:694,y:539,t:1527023547333};\\\", \\\"{x:684,y:527,t:1527023547350};\\\", \\\"{x:673,y:512,t:1527023547366};\\\", \\\"{x:661,y:493,t:1527023547384};\\\", \\\"{x:643,y:470,t:1527023547401};\\\", \\\"{x:629,y:448,t:1527023547418};\\\", \\\"{x:613,y:429,t:1527023547434};\\\", \\\"{x:601,y:418,t:1527023547450};\\\", \\\"{x:600,y:417,t:1527023547467};\\\", \\\"{x:602,y:417,t:1527023547622};\\\", \\\"{x:606,y:418,t:1527023547635};\\\", \\\"{x:614,y:420,t:1527023547652};\\\", \\\"{x:624,y:423,t:1527023547669};\\\", \\\"{x:634,y:428,t:1527023547685};\\\", \\\"{x:641,y:432,t:1527023547702};\\\", \\\"{x:642,y:433,t:1527023547719};\\\", \\\"{x:641,y:434,t:1527023547799};\\\", \\\"{x:638,y:435,t:1527023547818};\\\", \\\"{x:631,y:435,t:1527023547833};\\\", \\\"{x:625,y:435,t:1527023547850};\\\", \\\"{x:614,y:435,t:1527023547866};\\\", \\\"{x:604,y:433,t:1527023547883};\\\", \\\"{x:586,y:430,t:1527023547899};\\\", \\\"{x:538,y:424,t:1527023547917};\\\", \\\"{x:512,y:423,t:1527023547935};\\\", \\\"{x:501,y:422,t:1527023547951};\\\", \\\"{x:494,y:422,t:1527023547968};\\\", \\\"{x:493,y:422,t:1527023548046};\\\", \\\"{x:492,y:422,t:1527023548054};\\\", \\\"{x:487,y:422,t:1527023548068};\\\", \\\"{x:483,y:422,t:1527023548085};\\\", \\\"{x:481,y:420,t:1527023548102};\\\", \\\"{x:479,y:420,t:1527023548118};\\\", \\\"{x:478,y:420,t:1527023548198};\\\", \\\"{x:477,y:419,t:1527023548206};\\\", \\\"{x:476,y:418,t:1527023548218};\\\", \\\"{x:470,y:416,t:1527023548235};\\\", \\\"{x:462,y:414,t:1527023548251};\\\", \\\"{x:455,y:412,t:1527023548267};\\\", \\\"{x:448,y:408,t:1527023548285};\\\", \\\"{x:441,y:407,t:1527023548301};\\\", \\\"{x:440,y:407,t:1527023548317};\\\", \\\"{x:437,y:406,t:1527023548335};\\\", \\\"{x:433,y:406,t:1527023548352};\\\", \\\"{x:430,y:405,t:1527023548367};\\\", \\\"{x:427,y:405,t:1527023548385};\\\", \\\"{x:424,y:405,t:1527023548401};\\\", \\\"{x:427,y:405,t:1527023548606};\\\", \\\"{x:433,y:407,t:1527023548618};\\\", \\\"{x:453,y:414,t:1527023548635};\\\", \\\"{x:483,y:420,t:1527023548652};\\\", \\\"{x:527,y:425,t:1527023548669};\\\", \\\"{x:578,y:432,t:1527023548685};\\\", \\\"{x:669,y:447,t:1527023548703};\\\", \\\"{x:724,y:454,t:1527023548720};\\\", \\\"{x:762,y:460,t:1527023548735};\\\", \\\"{x:776,y:461,t:1527023548752};\\\", \\\"{x:777,y:462,t:1527023548773};\\\", \\\"{x:775,y:462,t:1527023548813};\\\", \\\"{x:770,y:462,t:1527023548821};\\\", \\\"{x:760,y:462,t:1527023548835};\\\", \\\"{x:739,y:462,t:1527023548852};\\\", \\\"{x:710,y:462,t:1527023548869};\\\", \\\"{x:660,y:462,t:1527023548885};\\\", \\\"{x:576,y:455,t:1527023548901};\\\", \\\"{x:541,y:447,t:1527023548919};\\\", \\\"{x:504,y:435,t:1527023548935};\\\", \\\"{x:484,y:430,t:1527023548953};\\\", \\\"{x:470,y:424,t:1527023548969};\\\", \\\"{x:465,y:423,t:1527023548985};\\\", \\\"{x:465,y:422,t:1527023549002};\\\", \\\"{x:465,y:421,t:1527023549118};\\\", \\\"{x:467,y:419,t:1527023549125};\\\", \\\"{x:470,y:417,t:1527023549135};\\\", \\\"{x:475,y:414,t:1527023549152};\\\", \\\"{x:477,y:412,t:1527023549168};\\\", \\\"{x:480,y:411,t:1527023549184};\\\", \\\"{x:485,y:409,t:1527023549202};\\\", \\\"{x:490,y:406,t:1527023549218};\\\", \\\"{x:492,y:406,t:1527023549236};\\\", \\\"{x:495,y:405,t:1527023549252};\\\", \\\"{x:497,y:405,t:1527023549326};\\\", \\\"{x:505,y:405,t:1527023549336};\\\", \\\"{x:559,y:413,t:1527023549352};\\\", \\\"{x:668,y:433,t:1527023549369};\\\", \\\"{x:797,y:469,t:1527023549386};\\\", \\\"{x:953,y:498,t:1527023549403};\\\", \\\"{x:1125,y:527,t:1527023549420};\\\", \\\"{x:1300,y:561,t:1527023549436};\\\", \\\"{x:1448,y:591,t:1527023549452};\\\", \\\"{x:1562,y:607,t:1527023549469};\\\", \\\"{x:1645,y:620,t:1527023549485};\\\", \\\"{x:1659,y:622,t:1527023549502};\\\", \\\"{x:1656,y:623,t:1527023549581};\\\", \\\"{x:1653,y:623,t:1527023549589};\\\", \\\"{x:1653,y:624,t:1527023549602};\\\", \\\"{x:1647,y:624,t:1527023549619};\\\", \\\"{x:1638,y:628,t:1527023549636};\\\", \\\"{x:1617,y:636,t:1527023549652};\\\", \\\"{x:1564,y:666,t:1527023549669};\\\", \\\"{x:1538,y:679,t:1527023549685};\\\", \\\"{x:1516,y:689,t:1527023549702};\\\", \\\"{x:1501,y:697,t:1527023549719};\\\", \\\"{x:1493,y:700,t:1527023549735};\\\", \\\"{x:1484,y:704,t:1527023549751};\\\", \\\"{x:1474,y:709,t:1527023549768};\\\", \\\"{x:1461,y:712,t:1527023549786};\\\", \\\"{x:1447,y:717,t:1527023549802};\\\", \\\"{x:1430,y:722,t:1527023549819};\\\", \\\"{x:1411,y:728,t:1527023549836};\\\", \\\"{x:1396,y:733,t:1527023549852};\\\", \\\"{x:1377,y:737,t:1527023549869};\\\", \\\"{x:1346,y:750,t:1527023549886};\\\", \\\"{x:1329,y:757,t:1527023549903};\\\", \\\"{x:1314,y:765,t:1527023549919};\\\", \\\"{x:1297,y:770,t:1527023549936};\\\", \\\"{x:1280,y:775,t:1527023549954};\\\", \\\"{x:1265,y:779,t:1527023549969};\\\", \\\"{x:1254,y:783,t:1527023549985};\\\", \\\"{x:1243,y:786,t:1527023550003};\\\", \\\"{x:1235,y:788,t:1527023550019};\\\", \\\"{x:1231,y:789,t:1527023550036};\\\", \\\"{x:1229,y:789,t:1527023550053};\\\", \\\"{x:1225,y:789,t:1527023550069};\\\", \\\"{x:1220,y:789,t:1527023550086};\\\", \\\"{x:1217,y:789,t:1527023550103};\\\", \\\"{x:1215,y:788,t:1527023550199};\\\", \\\"{x:1215,y:786,t:1527023550206};\\\", \\\"{x:1215,y:785,t:1527023550219};\\\", \\\"{x:1214,y:781,t:1527023550238};\\\", \\\"{x:1214,y:779,t:1527023550277};\\\", \\\"{x:1214,y:778,t:1527023550286};\\\", \\\"{x:1214,y:776,t:1527023550302};\\\", \\\"{x:1214,y:774,t:1527023550319};\\\", \\\"{x:1213,y:775,t:1527023552358};\\\", \\\"{x:1212,y:775,t:1527023552370};\\\", \\\"{x:1209,y:779,t:1527023552387};\\\", \\\"{x:1206,y:782,t:1527023552405};\\\", \\\"{x:1202,y:786,t:1527023552422};\\\", \\\"{x:1199,y:788,t:1527023552438};\\\", \\\"{x:1192,y:791,t:1527023552454};\\\", \\\"{x:1182,y:795,t:1527023552471};\\\", \\\"{x:1165,y:797,t:1527023552487};\\\", \\\"{x:1146,y:797,t:1527023552504};\\\", \\\"{x:1122,y:797,t:1527023552521};\\\", \\\"{x:1085,y:792,t:1527023552538};\\\", \\\"{x:1023,y:773,t:1527023552554};\\\", \\\"{x:938,y:739,t:1527023552572};\\\", \\\"{x:858,y:700,t:1527023552587};\\\", \\\"{x:786,y:657,t:1527023552604};\\\", \\\"{x:713,y:598,t:1527023552622};\\\", \\\"{x:688,y:564,t:1527023552639};\\\", \\\"{x:670,y:532,t:1527023552654};\\\", \\\"{x:655,y:509,t:1527023552671};\\\", \\\"{x:645,y:489,t:1527023552688};\\\", \\\"{x:639,y:471,t:1527023552705};\\\", \\\"{x:634,y:461,t:1527023552722};\\\", \\\"{x:629,y:451,t:1527023552738};\\\", \\\"{x:627,y:447,t:1527023552755};\\\", \\\"{x:624,y:439,t:1527023552772};\\\", \\\"{x:615,y:419,t:1527023552789};\\\", \\\"{x:607,y:408,t:1527023552804};\\\", \\\"{x:585,y:395,t:1527023552821};\\\", \\\"{x:564,y:387,t:1527023552838};\\\", \\\"{x:539,y:385,t:1527023552855};\\\", \\\"{x:514,y:385,t:1527023552871};\\\", \\\"{x:491,y:385,t:1527023552888};\\\", \\\"{x:470,y:381,t:1527023552905};\\\", \\\"{x:452,y:379,t:1527023552922};\\\", \\\"{x:435,y:379,t:1527023552938};\\\", \\\"{x:423,y:379,t:1527023552955};\\\", \\\"{x:412,y:379,t:1527023552972};\\\", \\\"{x:400,y:383,t:1527023552989};\\\", \\\"{x:395,y:386,t:1527023553005};\\\", \\\"{x:393,y:387,t:1527023553021};\\\", \\\"{x:391,y:388,t:1527023553039};\\\", \\\"{x:390,y:389,t:1527023553054};\\\", \\\"{x:385,y:391,t:1527023553072};\\\", \\\"{x:380,y:393,t:1527023553089};\\\", \\\"{x:375,y:394,t:1527023553105};\\\", \\\"{x:370,y:394,t:1527023553121};\\\", \\\"{x:364,y:394,t:1527023553139};\\\", \\\"{x:356,y:396,t:1527023553155};\\\", \\\"{x:347,y:396,t:1527023553172};\\\", \\\"{x:332,y:398,t:1527023553189};\\\", \\\"{x:322,y:399,t:1527023553206};\\\", \\\"{x:315,y:401,t:1527023553222};\\\", \\\"{x:313,y:402,t:1527023553239};\\\", \\\"{x:312,y:402,t:1527023553255};\\\", \\\"{x:312,y:404,t:1527023553510};\\\", \\\"{x:315,y:406,t:1527023553522};\\\", \\\"{x:343,y:411,t:1527023553540};\\\", \\\"{x:371,y:416,t:1527023553556};\\\", \\\"{x:428,y:422,t:1527023553574};\\\", \\\"{x:465,y:423,t:1527023553590};\\\", \\\"{x:492,y:423,t:1527023553606};\\\", \\\"{x:510,y:423,t:1527023553623};\\\", \\\"{x:514,y:423,t:1527023553639};\\\", \\\"{x:509,y:423,t:1527023553854};\\\", \\\"{x:501,y:423,t:1527023553862};\\\", \\\"{x:494,y:423,t:1527023553873};\\\", \\\"{x:478,y:422,t:1527023553891};\\\", \\\"{x:463,y:419,t:1527023553906};\\\", \\\"{x:453,y:417,t:1527023553923};\\\", \\\"{x:447,y:417,t:1527023553940};\\\", \\\"{x:446,y:417,t:1527023553956};\\\", \\\"{x:446,y:416,t:1527023554006};\\\", \\\"{x:444,y:415,t:1527023554142};\\\", \\\"{x:442,y:413,t:1527023554156};\\\", \\\"{x:430,y:410,t:1527023554173};\\\", \\\"{x:424,y:409,t:1527023554189};\\\", \\\"{x:419,y:408,t:1527023554206};\\\", \\\"{x:417,y:408,t:1527023554223};\\\", \\\"{x:416,y:407,t:1527023554241};\\\", \\\"{x:415,y:407,t:1527023554257};\\\", \\\"{x:414,y:406,t:1527023554273};\\\", \\\"{x:416,y:406,t:1527023554462};\\\", \\\"{x:420,y:406,t:1527023554474};\\\", \\\"{x:433,y:406,t:1527023554490};\\\", \\\"{x:452,y:406,t:1527023554506};\\\", \\\"{x:472,y:405,t:1527023554523};\\\", \\\"{x:493,y:404,t:1527023554540};\\\", \\\"{x:512,y:404,t:1527023554556};\\\", \\\"{x:520,y:403,t:1527023554572};\\\", \\\"{x:523,y:403,t:1527023554590};\\\", \\\"{x:525,y:403,t:1527023554645};\\\", \\\"{x:527,y:403,t:1527023554657};\\\", \\\"{x:532,y:405,t:1527023554674};\\\", \\\"{x:545,y:412,t:1527023554690};\\\", \\\"{x:558,y:421,t:1527023554707};\\\", \\\"{x:584,y:435,t:1527023554725};\\\", \\\"{x:637,y:458,t:1527023554740};\\\", \\\"{x:743,y:504,t:1527023554757};\\\", \\\"{x:786,y:521,t:1527023554771};\\\", \\\"{x:886,y:570,t:1527023554788};\\\", \\\"{x:1051,y:654,t:1527023554808};\\\", \\\"{x:1144,y:707,t:1527023554822};\\\", \\\"{x:1232,y:756,t:1527023554840};\\\", \\\"{x:1297,y:794,t:1527023554857};\\\", \\\"{x:1344,y:822,t:1527023554873};\\\", \\\"{x:1368,y:839,t:1527023554889};\\\", \\\"{x:1381,y:850,t:1527023554907};\\\", \\\"{x:1388,y:858,t:1527023554924};\\\", \\\"{x:1391,y:869,t:1527023554941};\\\", \\\"{x:1391,y:874,t:1527023554957};\\\", \\\"{x:1391,y:882,t:1527023554974};\\\", \\\"{x:1391,y:890,t:1527023554991};\\\", \\\"{x:1391,y:898,t:1527023555009};\\\", \\\"{x:1391,y:908,t:1527023555025};\\\", \\\"{x:1391,y:914,t:1527023555041};\\\", \\\"{x:1391,y:919,t:1527023555058};\\\", \\\"{x:1388,y:924,t:1527023555074};\\\", \\\"{x:1374,y:927,t:1527023555091};\\\", \\\"{x:1359,y:929,t:1527023555109};\\\", \\\"{x:1328,y:931,t:1527023555126};\\\", \\\"{x:1304,y:930,t:1527023555142};\\\", \\\"{x:1283,y:923,t:1527023555158};\\\", \\\"{x:1266,y:916,t:1527023555176};\\\", \\\"{x:1255,y:911,t:1527023555193};\\\", \\\"{x:1245,y:907,t:1527023555209};\\\", \\\"{x:1238,y:904,t:1527023555225};\\\", \\\"{x:1235,y:901,t:1527023555243};\\\", \\\"{x:1233,y:897,t:1527023555260};\\\", \\\"{x:1231,y:891,t:1527023555275};\\\", \\\"{x:1230,y:886,t:1527023555292};\\\", \\\"{x:1229,y:882,t:1527023555310};\\\", \\\"{x:1226,y:880,t:1527023555325};\\\", \\\"{x:1221,y:879,t:1527023555343};\\\", \\\"{x:1216,y:878,t:1527023555359};\\\", \\\"{x:1211,y:878,t:1527023555377};\\\", \\\"{x:1205,y:882,t:1527023555393};\\\", \\\"{x:1194,y:887,t:1527023555409};\\\", \\\"{x:1187,y:892,t:1527023555426};\\\", \\\"{x:1183,y:895,t:1527023555444};\\\", \\\"{x:1182,y:895,t:1527023555459};\\\", \\\"{x:1181,y:896,t:1527023555477};\\\", \\\"{x:1181,y:897,t:1527023555493};\\\", \\\"{x:1180,y:897,t:1527023555679};\\\", \\\"{x:1180,y:896,t:1527023555702};\\\", \\\"{x:1179,y:894,t:1527023555718};\\\", \\\"{x:1178,y:894,t:1527023555742};\\\", \\\"{x:1178,y:893,t:1527023556006};\\\", \\\"{x:1177,y:893,t:1527023556014};\\\", \\\"{x:1174,y:893,t:1527023556030};\\\", \\\"{x:1170,y:894,t:1527023556046};\\\", \\\"{x:1167,y:897,t:1527023556063};\\\", \\\"{x:1165,y:898,t:1527023556079};\\\", \\\"{x:1163,y:898,t:1527023556095};\\\", \\\"{x:1162,y:899,t:1527023556112};\\\", \\\"{x:1163,y:897,t:1527023556238};\\\", \\\"{x:1165,y:895,t:1527023556246};\\\", \\\"{x:1170,y:889,t:1527023556264};\\\", \\\"{x:1175,y:883,t:1527023556281};\\\", \\\"{x:1181,y:875,t:1527023556297};\\\", \\\"{x:1185,y:865,t:1527023556313};\\\", \\\"{x:1195,y:852,t:1527023556331};\\\", \\\"{x:1202,y:839,t:1527023556347};\\\", \\\"{x:1207,y:824,t:1527023556363};\\\", \\\"{x:1213,y:813,t:1527023556380};\\\", \\\"{x:1214,y:807,t:1527023556398};\\\", \\\"{x:1215,y:804,t:1527023556414};\\\", \\\"{x:1215,y:801,t:1527023556430};\\\", \\\"{x:1215,y:800,t:1527023556484};\\\", \\\"{x:1215,y:799,t:1527023556497};\\\", \\\"{x:1215,y:797,t:1527023556514};\\\", \\\"{x:1215,y:796,t:1527023556531};\\\", \\\"{x:1214,y:794,t:1527023556547};\\\", \\\"{x:1214,y:792,t:1527023556564};\\\", \\\"{x:1214,y:789,t:1527023556581};\\\", \\\"{x:1214,y:788,t:1527023556599};\\\", \\\"{x:1214,y:787,t:1527023556614};\\\", \\\"{x:1213,y:787,t:1527023556694};\\\", \\\"{x:1211,y:789,t:1527023556702};\\\", \\\"{x:1209,y:790,t:1527023556716};\\\", \\\"{x:1201,y:798,t:1527023556733};\\\", \\\"{x:1193,y:805,t:1527023556748};\\\", \\\"{x:1182,y:812,t:1527023556764};\\\", \\\"{x:1177,y:815,t:1527023556782};\\\", \\\"{x:1173,y:817,t:1527023556798};\\\", \\\"{x:1171,y:818,t:1527023556869};\\\", \\\"{x:1170,y:820,t:1527023556882};\\\", \\\"{x:1166,y:824,t:1527023556899};\\\", \\\"{x:1156,y:835,t:1527023556916};\\\", \\\"{x:1142,y:847,t:1527023556933};\\\", \\\"{x:1119,y:865,t:1527023556949};\\\", \\\"{x:1103,y:876,t:1527023556967};\\\", \\\"{x:1085,y:889,t:1527023556983};\\\", \\\"{x:1076,y:896,t:1527023556999};\\\", \\\"{x:1067,y:904,t:1527023557016};\\\", \\\"{x:1062,y:909,t:1527023557034};\\\", \\\"{x:1060,y:914,t:1527023557049};\\\", \\\"{x:1058,y:918,t:1527023557066};\\\", \\\"{x:1056,y:922,t:1527023557083};\\\", \\\"{x:1056,y:923,t:1527023557101};\\\", \\\"{x:1056,y:924,t:1527023557126};\\\", \\\"{x:1056,y:923,t:1527023557261};\\\", \\\"{x:1056,y:922,t:1527023557268};\\\", \\\"{x:1056,y:921,t:1527023557284};\\\", \\\"{x:1057,y:921,t:1527023557301};\\\", \\\"{x:1058,y:919,t:1527023557429};\\\", \\\"{x:1060,y:917,t:1527023557437};\\\", \\\"{x:1062,y:917,t:1527023557451};\\\", \\\"{x:1070,y:913,t:1527023557469};\\\", \\\"{x:1083,y:905,t:1527023557485};\\\", \\\"{x:1092,y:899,t:1527023557501};\\\", \\\"{x:1101,y:891,t:1527023557518};\\\", \\\"{x:1110,y:881,t:1527023557535};\\\", \\\"{x:1116,y:872,t:1527023557553};\\\", \\\"{x:1120,y:861,t:1527023557568};\\\", \\\"{x:1122,y:850,t:1527023557585};\\\", \\\"{x:1123,y:842,t:1527023557602};\\\", \\\"{x:1124,y:835,t:1527023557619};\\\", \\\"{x:1126,y:823,t:1527023557636};\\\", \\\"{x:1128,y:812,t:1527023557652};\\\", \\\"{x:1131,y:795,t:1527023557669};\\\", \\\"{x:1133,y:789,t:1527023557685};\\\", \\\"{x:1133,y:784,t:1527023557702};\\\", \\\"{x:1137,y:776,t:1527023557719};\\\", \\\"{x:1142,y:764,t:1527023557736};\\\", \\\"{x:1149,y:751,t:1527023557753};\\\", \\\"{x:1158,y:732,t:1527023557769};\\\", \\\"{x:1164,y:720,t:1527023557786};\\\", \\\"{x:1170,y:711,t:1527023557804};\\\", \\\"{x:1175,y:704,t:1527023557820};\\\", \\\"{x:1182,y:697,t:1527023557837};\\\", \\\"{x:1191,y:686,t:1527023557854};\\\", \\\"{x:1193,y:682,t:1527023557870};\\\", \\\"{x:1196,y:679,t:1527023557887};\\\", \\\"{x:1196,y:678,t:1527023557904};\\\", \\\"{x:1196,y:679,t:1527023558062};\\\", \\\"{x:1196,y:682,t:1527023558071};\\\", \\\"{x:1194,y:687,t:1527023558088};\\\", \\\"{x:1191,y:690,t:1527023558105};\\\", \\\"{x:1190,y:694,t:1527023558122};\\\", \\\"{x:1189,y:695,t:1527023558138};\\\", \\\"{x:1188,y:697,t:1527023558154};\\\", \\\"{x:1188,y:698,t:1527023558182};\\\", \\\"{x:1188,y:699,t:1527023558189};\\\", \\\"{x:1187,y:700,t:1527023558205};\\\", \\\"{x:1187,y:701,t:1527023558221};\\\", \\\"{x:1185,y:702,t:1527023558262};\\\", \\\"{x:1184,y:703,t:1527023558302};\\\", \\\"{x:1183,y:705,t:1527023558351};\\\", \\\"{x:1182,y:705,t:1527023558373};\\\", \\\"{x:1181,y:706,t:1527023558838};\\\", \\\"{x:1181,y:707,t:1527023558918};\\\", \\\"{x:1181,y:708,t:1527023558958};\\\", \\\"{x:1181,y:709,t:1527023558998};\\\", \\\"{x:1180,y:709,t:1527023559062};\\\", \\\"{x:1179,y:710,t:1527023559085};\\\", \\\"{x:1179,y:711,t:1527023559134};\\\", \\\"{x:1178,y:712,t:1527023559462};\\\", \\\"{x:1177,y:713,t:1527023559477};\\\", \\\"{x:1175,y:716,t:1527023559495};\\\", \\\"{x:1174,y:718,t:1527023559511};\\\", \\\"{x:1173,y:719,t:1527023559528};\\\", \\\"{x:1172,y:720,t:1527023559549};\\\", \\\"{x:1173,y:720,t:1527023559854};\\\", \\\"{x:1177,y:719,t:1527023559862};\\\", \\\"{x:1182,y:714,t:1527023559879};\\\", \\\"{x:1187,y:709,t:1527023559896};\\\", \\\"{x:1198,y:695,t:1527023559913};\\\", \\\"{x:1209,y:680,t:1527023559929};\\\", \\\"{x:1222,y:663,t:1527023559946};\\\", \\\"{x:1231,y:644,t:1527023559963};\\\", \\\"{x:1239,y:624,t:1527023559979};\\\", \\\"{x:1247,y:607,t:1527023559996};\\\", \\\"{x:1248,y:598,t:1527023560013};\\\", \\\"{x:1253,y:583,t:1527023560029};\\\", \\\"{x:1254,y:578,t:1527023560046};\\\", \\\"{x:1254,y:575,t:1527023560063};\\\", \\\"{x:1254,y:574,t:1527023560079};\\\", \\\"{x:1254,y:573,t:1527023560101};\\\", \\\"{x:1254,y:572,t:1527023560134};\\\", \\\"{x:1254,y:571,t:1527023560146};\\\", \\\"{x:1256,y:567,t:1527023560164};\\\", \\\"{x:1257,y:562,t:1527023560180};\\\", \\\"{x:1257,y:555,t:1527023560197};\\\", \\\"{x:1257,y:546,t:1527023560214};\\\", \\\"{x:1257,y:537,t:1527023560230};\\\", \\\"{x:1257,y:526,t:1527023560246};\\\", \\\"{x:1258,y:520,t:1527023560263};\\\", \\\"{x:1260,y:515,t:1527023560280};\\\", \\\"{x:1262,y:509,t:1527023560297};\\\", \\\"{x:1264,y:506,t:1527023560313};\\\", \\\"{x:1264,y:503,t:1527023560330};\\\", \\\"{x:1265,y:502,t:1527023560349};\\\", \\\"{x:1265,y:503,t:1527023560550};\\\", \\\"{x:1266,y:511,t:1527023560565};\\\", \\\"{x:1268,y:544,t:1527023560582};\\\", \\\"{x:1268,y:574,t:1527023560599};\\\", \\\"{x:1268,y:606,t:1527023560615};\\\", \\\"{x:1260,y:642,t:1527023560631};\\\", \\\"{x:1253,y:670,t:1527023560649};\\\", \\\"{x:1244,y:692,t:1527023560666};\\\", \\\"{x:1237,y:711,t:1527023560682};\\\", \\\"{x:1228,y:726,t:1527023560699};\\\", \\\"{x:1223,y:734,t:1527023560716};\\\", \\\"{x:1215,y:743,t:1527023560733};\\\", \\\"{x:1209,y:750,t:1527023560748};\\\", \\\"{x:1199,y:756,t:1527023560765};\\\", \\\"{x:1195,y:758,t:1527023560783};\\\", \\\"{x:1189,y:761,t:1527023560799};\\\", \\\"{x:1185,y:762,t:1527023560816};\\\", \\\"{x:1184,y:763,t:1527023560833};\\\", \\\"{x:1183,y:763,t:1527023560850};\\\", \\\"{x:1182,y:763,t:1527023560878};\\\", \\\"{x:1180,y:763,t:1527023560902};\\\", \\\"{x:1179,y:762,t:1527023560917};\\\", \\\"{x:1178,y:757,t:1527023560933};\\\", \\\"{x:1178,y:751,t:1527023560949};\\\", \\\"{x:1178,y:746,t:1527023560967};\\\", \\\"{x:1178,y:738,t:1527023560984};\\\", \\\"{x:1180,y:731,t:1527023561001};\\\", \\\"{x:1183,y:724,t:1527023561017};\\\", \\\"{x:1186,y:721,t:1527023561034};\\\", \\\"{x:1189,y:714,t:1527023561051};\\\", \\\"{x:1194,y:707,t:1527023561067};\\\", \\\"{x:1197,y:701,t:1527023561083};\\\", \\\"{x:1200,y:693,t:1527023561101};\\\", \\\"{x:1205,y:685,t:1527023561117};\\\", \\\"{x:1206,y:683,t:1527023561133};\\\", \\\"{x:1206,y:684,t:1527023561254};\\\", \\\"{x:1206,y:688,t:1527023561268};\\\", \\\"{x:1203,y:697,t:1527023561285};\\\", \\\"{x:1200,y:705,t:1527023561301};\\\", \\\"{x:1199,y:710,t:1527023561319};\\\", \\\"{x:1196,y:716,t:1527023561335};\\\", \\\"{x:1196,y:720,t:1527023561352};\\\", \\\"{x:1194,y:724,t:1527023561368};\\\", \\\"{x:1194,y:725,t:1527023561385};\\\", \\\"{x:1193,y:726,t:1527023561402};\\\", \\\"{x:1192,y:728,t:1527023561798};\\\", \\\"{x:1192,y:730,t:1527023561806};\\\", \\\"{x:1192,y:732,t:1527023561821};\\\", \\\"{x:1191,y:738,t:1527023561837};\\\", \\\"{x:1188,y:748,t:1527023561854};\\\", \\\"{x:1187,y:750,t:1527023561871};\\\", \\\"{x:1187,y:752,t:1527023561888};\\\", \\\"{x:1185,y:754,t:1527023561904};\\\", \\\"{x:1184,y:757,t:1527023561921};\\\", \\\"{x:1183,y:759,t:1527023561937};\\\", \\\"{x:1182,y:762,t:1527023561954};\\\", \\\"{x:1181,y:764,t:1527023561971};\\\", \\\"{x:1179,y:768,t:1527023561988};\\\", \\\"{x:1178,y:769,t:1527023562005};\\\", \\\"{x:1177,y:773,t:1527023562020};\\\", \\\"{x:1175,y:779,t:1527023562038};\\\", \\\"{x:1174,y:780,t:1527023562055};\\\", \\\"{x:1171,y:785,t:1527023562072};\\\", \\\"{x:1169,y:792,t:1527023562088};\\\", \\\"{x:1169,y:797,t:1527023562105};\\\", \\\"{x:1169,y:802,t:1527023562122};\\\", \\\"{x:1168,y:808,t:1527023562139};\\\", \\\"{x:1167,y:810,t:1527023562155};\\\", \\\"{x:1169,y:808,t:1527023562260};\\\", \\\"{x:1171,y:806,t:1527023562272};\\\", \\\"{x:1179,y:797,t:1527023562289};\\\", \\\"{x:1190,y:784,t:1527023562305};\\\", \\\"{x:1200,y:772,t:1527023562322};\\\", \\\"{x:1205,y:764,t:1527023562338};\\\", \\\"{x:1208,y:760,t:1527023562356};\\\", \\\"{x:1209,y:759,t:1527023562372};\\\", \\\"{x:1210,y:759,t:1527023562437};\\\", \\\"{x:1209,y:765,t:1527023562462};\\\", \\\"{x:1208,y:772,t:1527023562473};\\\", \\\"{x:1204,y:786,t:1527023562489};\\\", \\\"{x:1196,y:802,t:1527023562507};\\\", \\\"{x:1190,y:818,t:1527023562523};\\\", \\\"{x:1183,y:832,t:1527023562539};\\\", \\\"{x:1177,y:843,t:1527023562557};\\\", \\\"{x:1172,y:852,t:1527023562573};\\\", \\\"{x:1169,y:856,t:1527023562590};\\\", \\\"{x:1167,y:859,t:1527023562606};\\\", \\\"{x:1166,y:860,t:1527023562624};\\\", \\\"{x:1165,y:862,t:1527023562641};\\\", \\\"{x:1164,y:863,t:1527023562657};\\\", \\\"{x:1162,y:865,t:1527023562674};\\\", \\\"{x:1160,y:866,t:1527023562690};\\\", \\\"{x:1159,y:867,t:1527023562708};\\\", \\\"{x:1153,y:870,t:1527023562724};\\\", \\\"{x:1147,y:873,t:1527023562741};\\\", \\\"{x:1140,y:878,t:1527023562758};\\\", \\\"{x:1135,y:882,t:1527023562775};\\\", \\\"{x:1127,y:886,t:1527023562791};\\\", \\\"{x:1124,y:889,t:1527023562808};\\\", \\\"{x:1122,y:891,t:1527023562826};\\\", \\\"{x:1119,y:893,t:1527023562842};\\\", \\\"{x:1118,y:894,t:1527023562858};\\\", \\\"{x:1117,y:894,t:1527023562875};\\\", \\\"{x:1115,y:896,t:1527023562892};\\\", \\\"{x:1113,y:897,t:1527023562909};\\\", \\\"{x:1111,y:897,t:1527023562927};\\\", \\\"{x:1110,y:899,t:1527023562941};\\\", \\\"{x:1110,y:895,t:1527023563012};\\\", \\\"{x:1110,y:890,t:1527023563025};\\\", \\\"{x:1111,y:868,t:1527023563041};\\\", \\\"{x:1124,y:835,t:1527023563058};\\\", \\\"{x:1142,y:795,t:1527023563075};\\\", \\\"{x:1158,y:761,t:1527023563092};\\\", \\\"{x:1170,y:737,t:1527023563108};\\\", \\\"{x:1183,y:706,t:1527023563125};\\\", \\\"{x:1192,y:688,t:1527023563142};\\\", \\\"{x:1195,y:679,t:1527023563159};\\\", \\\"{x:1196,y:677,t:1527023563176};\\\", \\\"{x:1197,y:677,t:1527023563230};\\\", \\\"{x:1200,y:681,t:1527023563243};\\\", \\\"{x:1207,y:699,t:1527023563260};\\\", \\\"{x:1222,y:732,t:1527023563277};\\\", \\\"{x:1253,y:790,t:1527023563293};\\\", \\\"{x:1272,y:823,t:1527023563310};\\\", \\\"{x:1287,y:846,t:1527023563327};\\\", \\\"{x:1299,y:864,t:1527023563344};\\\", \\\"{x:1304,y:874,t:1527023563360};\\\", \\\"{x:1308,y:881,t:1527023563377};\\\", \\\"{x:1309,y:885,t:1527023563393};\\\", \\\"{x:1311,y:886,t:1527023563411};\\\", \\\"{x:1311,y:887,t:1527023563437};\\\", \\\"{x:1314,y:883,t:1527023563615};\\\", \\\"{x:1321,y:874,t:1527023563628};\\\", \\\"{x:1334,y:851,t:1527023563645};\\\", \\\"{x:1357,y:815,t:1527023563662};\\\", \\\"{x:1373,y:793,t:1527023563677};\\\", \\\"{x:1385,y:776,t:1527023563695};\\\", \\\"{x:1389,y:768,t:1527023563711};\\\", \\\"{x:1390,y:763,t:1527023563728};\\\", \\\"{x:1390,y:760,t:1527023563745};\\\", \\\"{x:1390,y:757,t:1527023563762};\\\", \\\"{x:1390,y:754,t:1527023563778};\\\", \\\"{x:1390,y:751,t:1527023563796};\\\", \\\"{x:1390,y:747,t:1527023563812};\\\", \\\"{x:1390,y:744,t:1527023563829};\\\", \\\"{x:1390,y:743,t:1527023563853};\\\", \\\"{x:1390,y:742,t:1527023563863};\\\", \\\"{x:1389,y:741,t:1527023563879};\\\", \\\"{x:1388,y:740,t:1527023563896};\\\", \\\"{x:1386,y:736,t:1527023563913};\\\", \\\"{x:1385,y:734,t:1527023563929};\\\", \\\"{x:1382,y:730,t:1527023563946};\\\", \\\"{x:1379,y:728,t:1527023563963};\\\", \\\"{x:1377,y:725,t:1527023563980};\\\", \\\"{x:1375,y:724,t:1527023563996};\\\", \\\"{x:1374,y:723,t:1527023564013};\\\", \\\"{x:1373,y:722,t:1527023564334};\\\", \\\"{x:1371,y:722,t:1527023564349};\\\", \\\"{x:1365,y:719,t:1527023564365};\\\", \\\"{x:1362,y:716,t:1527023564382};\\\", \\\"{x:1358,y:715,t:1527023564398};\\\", \\\"{x:1357,y:716,t:1527023564540};\\\", \\\"{x:1357,y:719,t:1527023564549};\\\", \\\"{x:1359,y:727,t:1527023564565};\\\", \\\"{x:1362,y:737,t:1527023564581};\\\", \\\"{x:1364,y:749,t:1527023564599};\\\", \\\"{x:1368,y:763,t:1527023564615};\\\", \\\"{x:1372,y:774,t:1527023564631};\\\", \\\"{x:1374,y:783,t:1527023564648};\\\", \\\"{x:1378,y:796,t:1527023564666};\\\", \\\"{x:1382,y:813,t:1527023564682};\\\", \\\"{x:1387,y:828,t:1527023564699};\\\", \\\"{x:1389,y:837,t:1527023564715};\\\", \\\"{x:1394,y:849,t:1527023564732};\\\", \\\"{x:1399,y:864,t:1527023564749};\\\", \\\"{x:1403,y:873,t:1527023564766};\\\", \\\"{x:1408,y:884,t:1527023564782};\\\", \\\"{x:1413,y:895,t:1527023564799};\\\", \\\"{x:1418,y:904,t:1527023564816};\\\", \\\"{x:1421,y:912,t:1527023564832};\\\", \\\"{x:1425,y:920,t:1527023564850};\\\", \\\"{x:1429,y:926,t:1527023564866};\\\", \\\"{x:1431,y:931,t:1527023564884};\\\", \\\"{x:1433,y:933,t:1527023564900};\\\", \\\"{x:1433,y:934,t:1527023564916};\\\", \\\"{x:1434,y:935,t:1527023564934};\\\", \\\"{x:1434,y:934,t:1527023565110};\\\", \\\"{x:1434,y:933,t:1527023565118};\\\", \\\"{x:1433,y:929,t:1527023565136};\\\", \\\"{x:1430,y:925,t:1527023565151};\\\", \\\"{x:1427,y:921,t:1527023565168};\\\", \\\"{x:1421,y:911,t:1527023565185};\\\", \\\"{x:1414,y:897,t:1527023565202};\\\", \\\"{x:1408,y:880,t:1527023565218};\\\", \\\"{x:1398,y:858,t:1527023565235};\\\", \\\"{x:1385,y:833,t:1527023565252};\\\", \\\"{x:1375,y:811,t:1527023565269};\\\", \\\"{x:1364,y:780,t:1527023565285};\\\", \\\"{x:1358,y:762,t:1527023565302};\\\", \\\"{x:1351,y:743,t:1527023565319};\\\", \\\"{x:1344,y:730,t:1527023565335};\\\", \\\"{x:1341,y:722,t:1527023565352};\\\", \\\"{x:1338,y:718,t:1527023565369};\\\", \\\"{x:1336,y:715,t:1527023565386};\\\", \\\"{x:1335,y:715,t:1527023565454};\\\", \\\"{x:1319,y:723,t:1527023565470};\\\", \\\"{x:1287,y:745,t:1527023565486};\\\", \\\"{x:1239,y:781,t:1527023565503};\\\", \\\"{x:1190,y:820,t:1527023565520};\\\", \\\"{x:1136,y:862,t:1527023565536};\\\", \\\"{x:1090,y:896,t:1527023565553};\\\", \\\"{x:1066,y:917,t:1527023565570};\\\", \\\"{x:1049,y:931,t:1527023565586};\\\", \\\"{x:1038,y:940,t:1527023565603};\\\", \\\"{x:1035,y:945,t:1527023565620};\\\", \\\"{x:1034,y:947,t:1527023565637};\\\", \\\"{x:1033,y:947,t:1527023565653};\\\", \\\"{x:1033,y:942,t:1527023565742};\\\", \\\"{x:1034,y:931,t:1527023565754};\\\", \\\"{x:1041,y:901,t:1527023565771};\\\", \\\"{x:1053,y:861,t:1527023565787};\\\", \\\"{x:1070,y:817,t:1527023565804};\\\", \\\"{x:1099,y:757,t:1527023565821};\\\", \\\"{x:1110,y:736,t:1527023565837};\\\", \\\"{x:1135,y:683,t:1527023565854};\\\", \\\"{x:1150,y:654,t:1527023565871};\\\", \\\"{x:1161,y:631,t:1527023565888};\\\", \\\"{x:1168,y:618,t:1527023565904};\\\", \\\"{x:1174,y:606,t:1527023565921};\\\", \\\"{x:1179,y:593,t:1527023565938};\\\", \\\"{x:1184,y:583,t:1527023565955};\\\", \\\"{x:1186,y:579,t:1527023565971};\\\", \\\"{x:1186,y:578,t:1527023565988};\\\", \\\"{x:1187,y:577,t:1527023566006};\\\", \\\"{x:1188,y:576,t:1527023566022};\\\", \\\"{x:1190,y:576,t:1527023566086};\\\", \\\"{x:1194,y:580,t:1527023566094};\\\", \\\"{x:1199,y:590,t:1527023566105};\\\", \\\"{x:1214,y:620,t:1527023566122};\\\", \\\"{x:1236,y:662,t:1527023566139};\\\", \\\"{x:1265,y:731,t:1527023566156};\\\", \\\"{x:1300,y:791,t:1527023566172};\\\", \\\"{x:1334,y:846,t:1527023566189};\\\", \\\"{x:1369,y:899,t:1527023566206};\\\", \\\"{x:1384,y:922,t:1527023566223};\\\", \\\"{x:1396,y:940,t:1527023566239};\\\", \\\"{x:1405,y:953,t:1527023566256};\\\", \\\"{x:1412,y:964,t:1527023566272};\\\", \\\"{x:1417,y:974,t:1527023566289};\\\", \\\"{x:1420,y:980,t:1527023566305};\\\", \\\"{x:1425,y:986,t:1527023566323};\\\", \\\"{x:1428,y:990,t:1527023566340};\\\", \\\"{x:1429,y:992,t:1527023566355};\\\", \\\"{x:1430,y:993,t:1527023566373};\\\", \\\"{x:1431,y:993,t:1527023566518};\\\", \\\"{x:1431,y:988,t:1527023566525};\\\", \\\"{x:1432,y:986,t:1527023566541};\\\", \\\"{x:1433,y:974,t:1527023566557};\\\", \\\"{x:1436,y:962,t:1527023566574};\\\", \\\"{x:1436,y:950,t:1527023566590};\\\", \\\"{x:1436,y:932,t:1527023566606};\\\", \\\"{x:1436,y:907,t:1527023566624};\\\", \\\"{x:1428,y:880,t:1527023566640};\\\", \\\"{x:1422,y:858,t:1527023566657};\\\", \\\"{x:1416,y:833,t:1527023566673};\\\", \\\"{x:1411,y:816,t:1527023566690};\\\", \\\"{x:1408,y:806,t:1527023566707};\\\", \\\"{x:1405,y:799,t:1527023566725};\\\", \\\"{x:1403,y:796,t:1527023566741};\\\", \\\"{x:1397,y:798,t:1527023566806};\\\", \\\"{x:1383,y:806,t:1527023566813};\\\", \\\"{x:1362,y:819,t:1527023566825};\\\", \\\"{x:1310,y:849,t:1527023566842};\\\", \\\"{x:1272,y:871,t:1527023566859};\\\", \\\"{x:1228,y:891,t:1527023566875};\\\", \\\"{x:1201,y:904,t:1527023566892};\\\", \\\"{x:1182,y:915,t:1527023566910};\\\", \\\"{x:1176,y:919,t:1527023566925};\\\", \\\"{x:1176,y:920,t:1527023567110};\\\", \\\"{x:1178,y:920,t:1527023567126};\\\", \\\"{x:1184,y:920,t:1527023567143};\\\", \\\"{x:1189,y:920,t:1527023567160};\\\", \\\"{x:1195,y:920,t:1527023567177};\\\", \\\"{x:1199,y:920,t:1527023567193};\\\", \\\"{x:1202,y:920,t:1527023567210};\\\", \\\"{x:1204,y:919,t:1527023567227};\\\", \\\"{x:1206,y:918,t:1527023567243};\\\", \\\"{x:1211,y:916,t:1527023567261};\\\", \\\"{x:1214,y:915,t:1527023567278};\\\", \\\"{x:1216,y:915,t:1527023567294};\\\", \\\"{x:1218,y:915,t:1527023567310};\\\", \\\"{x:1219,y:915,t:1527023567327};\\\", \\\"{x:1220,y:915,t:1527023567358};\\\", \\\"{x:1221,y:915,t:1527023567374};\\\", \\\"{x:1222,y:915,t:1527023567414};\\\", \\\"{x:1224,y:914,t:1527023567429};\\\", \\\"{x:1225,y:914,t:1527023567462};\\\", \\\"{x:1225,y:913,t:1527023567485};\\\", \\\"{x:1226,y:913,t:1527023567525};\\\", \\\"{x:1227,y:912,t:1527023567534};\\\", \\\"{x:1229,y:912,t:1527023567545};\\\", \\\"{x:1232,y:908,t:1527023567562};\\\", \\\"{x:1238,y:900,t:1527023567578};\\\", \\\"{x:1244,y:889,t:1527023567595};\\\", \\\"{x:1256,y:866,t:1527023567612};\\\", \\\"{x:1270,y:843,t:1527023567629};\\\", \\\"{x:1287,y:806,t:1527023567646};\\\", \\\"{x:1305,y:764,t:1527023567662};\\\", \\\"{x:1312,y:743,t:1527023567679};\\\", \\\"{x:1320,y:727,t:1527023567695};\\\", \\\"{x:1325,y:716,t:1527023567712};\\\", \\\"{x:1327,y:709,t:1527023567729};\\\", \\\"{x:1332,y:701,t:1527023567745};\\\", \\\"{x:1333,y:699,t:1527023567761};\\\", \\\"{x:1334,y:699,t:1527023567779};\\\", \\\"{x:1334,y:698,t:1527023567796};\\\", \\\"{x:1334,y:697,t:1527023567812};\\\", \\\"{x:1335,y:699,t:1527023567902};\\\", \\\"{x:1338,y:709,t:1527023567913};\\\", \\\"{x:1346,y:728,t:1527023567931};\\\", \\\"{x:1355,y:749,t:1527023567947};\\\", \\\"{x:1371,y:776,t:1527023567964};\\\", \\\"{x:1381,y:792,t:1527023567981};\\\", \\\"{x:1392,y:807,t:1527023567997};\\\", \\\"{x:1400,y:819,t:1527023568014};\\\", \\\"{x:1405,y:826,t:1527023568030};\\\", \\\"{x:1408,y:834,t:1527023568048};\\\", \\\"{x:1413,y:841,t:1527023568064};\\\", \\\"{x:1414,y:845,t:1527023568079};\\\", \\\"{x:1418,y:853,t:1527023568097};\\\", \\\"{x:1424,y:866,t:1527023568114};\\\", \\\"{x:1426,y:874,t:1527023568131};\\\", \\\"{x:1427,y:880,t:1527023568147};\\\", \\\"{x:1430,y:887,t:1527023568164};\\\", \\\"{x:1436,y:898,t:1527023568181};\\\", \\\"{x:1438,y:903,t:1527023568198};\\\", \\\"{x:1440,y:906,t:1527023568214};\\\", \\\"{x:1443,y:911,t:1527023568231};\\\", \\\"{x:1444,y:912,t:1527023568253};\\\", \\\"{x:1444,y:913,t:1527023568264};\\\", \\\"{x:1445,y:915,t:1527023568281};\\\", \\\"{x:1445,y:916,t:1527023568298};\\\", \\\"{x:1445,y:917,t:1527023568315};\\\", \\\"{x:1447,y:919,t:1527023568331};\\\", \\\"{x:1447,y:921,t:1527023568357};\\\", \\\"{x:1448,y:921,t:1527023568365};\\\", \\\"{x:1448,y:922,t:1527023569046};\\\", \\\"{x:1442,y:922,t:1527023569062};\\\", \\\"{x:1432,y:920,t:1527023569070};\\\", \\\"{x:1406,y:913,t:1527023569085};\\\", \\\"{x:1380,y:904,t:1527023569101};\\\", \\\"{x:1362,y:892,t:1527023569118};\\\", \\\"{x:1343,y:879,t:1527023569134};\\\", \\\"{x:1331,y:865,t:1527023569152};\\\", \\\"{x:1326,y:852,t:1527023569167};\\\", \\\"{x:1325,y:830,t:1527023569185};\\\", \\\"{x:1325,y:799,t:1527023569202};\\\", \\\"{x:1330,y:766,t:1527023569217};\\\", \\\"{x:1334,y:740,t:1527023569235};\\\", \\\"{x:1339,y:728,t:1527023569252};\\\", \\\"{x:1340,y:724,t:1527023569269};\\\", \\\"{x:1340,y:723,t:1527023569286};\\\", \\\"{x:1341,y:723,t:1527023569326};\\\", \\\"{x:1341,y:729,t:1527023569336};\\\", \\\"{x:1341,y:751,t:1527023569352};\\\", \\\"{x:1341,y:781,t:1527023569370};\\\", \\\"{x:1341,y:812,t:1527023569386};\\\", \\\"{x:1333,y:837,t:1527023569402};\\\", \\\"{x:1328,y:858,t:1527023569419};\\\", \\\"{x:1320,y:873,t:1527023569436};\\\", \\\"{x:1315,y:886,t:1527023569453};\\\", \\\"{x:1314,y:889,t:1527023569469};\\\", \\\"{x:1313,y:891,t:1527023569485};\\\", \\\"{x:1313,y:892,t:1527023569503};\\\", \\\"{x:1312,y:894,t:1527023569519};\\\", \\\"{x:1311,y:897,t:1527023569537};\\\", \\\"{x:1307,y:904,t:1527023569552};\\\", \\\"{x:1305,y:906,t:1527023569570};\\\", \\\"{x:1301,y:911,t:1527023569586};\\\", \\\"{x:1295,y:915,t:1527023569603};\\\", \\\"{x:1286,y:919,t:1527023569620};\\\", \\\"{x:1274,y:924,t:1527023569637};\\\", \\\"{x:1266,y:926,t:1527023569653};\\\", \\\"{x:1260,y:929,t:1527023569670};\\\", \\\"{x:1250,y:930,t:1527023569686};\\\", \\\"{x:1237,y:931,t:1527023569704};\\\", \\\"{x:1221,y:931,t:1527023569722};\\\", \\\"{x:1202,y:931,t:1527023569737};\\\", \\\"{x:1185,y:930,t:1527023569755};\\\", \\\"{x:1173,y:922,t:1527023569771};\\\", \\\"{x:1159,y:912,t:1527023569788};\\\", \\\"{x:1141,y:897,t:1527023569804};\\\", \\\"{x:1120,y:869,t:1527023569821};\\\", \\\"{x:1100,y:852,t:1527023569837};\\\", \\\"{x:1088,y:847,t:1527023569854};\\\", \\\"{x:1083,y:846,t:1527023569871};\\\", \\\"{x:1078,y:847,t:1527023569888};\\\", \\\"{x:1076,y:848,t:1527023569905};\\\", \\\"{x:1072,y:853,t:1527023569921};\\\", \\\"{x:1068,y:860,t:1527023569938};\\\", \\\"{x:1065,y:867,t:1527023569955};\\\", \\\"{x:1063,y:872,t:1527023569972};\\\", \\\"{x:1062,y:875,t:1527023569988};\\\", \\\"{x:1061,y:877,t:1527023570006};\\\", \\\"{x:1062,y:877,t:1527023570054};\\\", \\\"{x:1066,y:872,t:1527023570062};\\\", \\\"{x:1071,y:863,t:1527023570072};\\\", \\\"{x:1084,y:844,t:1527023570089};\\\", \\\"{x:1099,y:821,t:1527023570105};\\\", \\\"{x:1120,y:788,t:1527023570123};\\\", \\\"{x:1151,y:740,t:1527023570139};\\\", \\\"{x:1178,y:684,t:1527023570156};\\\", \\\"{x:1201,y:641,t:1527023570172};\\\", \\\"{x:1221,y:605,t:1527023570190};\\\", \\\"{x:1237,y:581,t:1527023570205};\\\", \\\"{x:1248,y:561,t:1527023570223};\\\", \\\"{x:1258,y:546,t:1527023570240};\\\", \\\"{x:1261,y:540,t:1527023570256};\\\", \\\"{x:1263,y:537,t:1527023570273};\\\", \\\"{x:1264,y:536,t:1527023570309};\\\", \\\"{x:1266,y:536,t:1527023570341};\\\", \\\"{x:1266,y:533,t:1527023570550};\\\", \\\"{x:1266,y:531,t:1527023570558};\\\", \\\"{x:1266,y:527,t:1527023570575};\\\", \\\"{x:1266,y:526,t:1527023570591};\\\", \\\"{x:1266,y:527,t:1527023570670};\\\", \\\"{x:1265,y:535,t:1527023570678};\\\", \\\"{x:1261,y:548,t:1527023570691};\\\", \\\"{x:1252,y:576,t:1527023570708};\\\", \\\"{x:1237,y:624,t:1527023570725};\\\", \\\"{x:1226,y:650,t:1527023570742};\\\", \\\"{x:1215,y:673,t:1527023570758};\\\", \\\"{x:1208,y:690,t:1527023570775};\\\", \\\"{x:1200,y:707,t:1527023570792};\\\", \\\"{x:1195,y:720,t:1527023570809};\\\", \\\"{x:1188,y:739,t:1527023570826};\\\", \\\"{x:1180,y:762,t:1527023570842};\\\", \\\"{x:1175,y:777,t:1527023570860};\\\", \\\"{x:1167,y:791,t:1527023570876};\\\", \\\"{x:1163,y:801,t:1527023570893};\\\", \\\"{x:1158,y:816,t:1527023570909};\\\", \\\"{x:1154,y:827,t:1527023570926};\\\", \\\"{x:1152,y:837,t:1527023570943};\\\", \\\"{x:1149,y:846,t:1527023570960};\\\", \\\"{x:1145,y:853,t:1527023570976};\\\", \\\"{x:1142,y:857,t:1527023570993};\\\", \\\"{x:1139,y:861,t:1527023571009};\\\", \\\"{x:1137,y:863,t:1527023571026};\\\", \\\"{x:1136,y:865,t:1527023571043};\\\", \\\"{x:1136,y:866,t:1527023571060};\\\", \\\"{x:1134,y:868,t:1527023571076};\\\", \\\"{x:1129,y:870,t:1527023571094};\\\", \\\"{x:1123,y:874,t:1527023571110};\\\", \\\"{x:1114,y:879,t:1527023571127};\\\", \\\"{x:1103,y:885,t:1527023571143};\\\", \\\"{x:1093,y:893,t:1527023571160};\\\", \\\"{x:1090,y:894,t:1527023571177};\\\", \\\"{x:1089,y:896,t:1527023571193};\\\", \\\"{x:1091,y:895,t:1527023572814};\\\", \\\"{x:1099,y:894,t:1527023572822};\\\", \\\"{x:1109,y:892,t:1527023572833};\\\", \\\"{x:1136,y:890,t:1527023572849};\\\", \\\"{x:1164,y:885,t:1527023572867};\\\", \\\"{x:1186,y:878,t:1527023572884};\\\", \\\"{x:1204,y:873,t:1527023572900};\\\", \\\"{x:1207,y:871,t:1527023572917};\\\", \\\"{x:1208,y:870,t:1527023572949};\\\", \\\"{x:1209,y:870,t:1527023572965};\\\", \\\"{x:1209,y:869,t:1527023573101};\\\", \\\"{x:1203,y:873,t:1527023573118};\\\", \\\"{x:1193,y:878,t:1527023573135};\\\", \\\"{x:1186,y:882,t:1527023573151};\\\", \\\"{x:1179,y:885,t:1527023573167};\\\", \\\"{x:1174,y:887,t:1527023573185};\\\", \\\"{x:1171,y:889,t:1527023573202};\\\", \\\"{x:1169,y:890,t:1527023573318};\\\", \\\"{x:1168,y:892,t:1527023573341};\\\", \\\"{x:1167,y:893,t:1527023573357};\\\", \\\"{x:1166,y:893,t:1527023573369};\\\", \\\"{x:1163,y:896,t:1527023573386};\\\", \\\"{x:1162,y:897,t:1527023573403};\\\", \\\"{x:1161,y:898,t:1527023573419};\\\", \\\"{x:1159,y:900,t:1527023573436};\\\", \\\"{x:1154,y:904,t:1527023573453};\\\", \\\"{x:1152,y:905,t:1527023573470};\\\", \\\"{x:1154,y:902,t:1527023573598};\\\", \\\"{x:1158,y:898,t:1527023573605};\\\", \\\"{x:1164,y:890,t:1527023573621};\\\", \\\"{x:1176,y:874,t:1527023573637};\\\", \\\"{x:1182,y:865,t:1527023573653};\\\", \\\"{x:1183,y:864,t:1527023573672};\\\", \\\"{x:1179,y:865,t:1527023573742};\\\", \\\"{x:1176,y:867,t:1527023573754};\\\", \\\"{x:1169,y:874,t:1527023573771};\\\", \\\"{x:1159,y:882,t:1527023573788};\\\", \\\"{x:1151,y:886,t:1527023573804};\\\", \\\"{x:1146,y:891,t:1527023573821};\\\", \\\"{x:1143,y:894,t:1527023573838};\\\", \\\"{x:1142,y:896,t:1527023573856};\\\", \\\"{x:1139,y:898,t:1527023573871};\\\", \\\"{x:1138,y:900,t:1527023573888};\\\", \\\"{x:1137,y:901,t:1527023573905};\\\", \\\"{x:1135,y:903,t:1527023573922};\\\", \\\"{x:1135,y:904,t:1527023573938};\\\", \\\"{x:1134,y:905,t:1527023573956};\\\", \\\"{x:1132,y:907,t:1527023573973};\\\", \\\"{x:1129,y:910,t:1527023573989};\\\", \\\"{x:1127,y:910,t:1527023574005};\\\", \\\"{x:1126,y:911,t:1527023574022};\\\", \\\"{x:1125,y:911,t:1527023574166};\\\", \\\"{x:1125,y:909,t:1527023574174};\\\", \\\"{x:1125,y:906,t:1527023574190};\\\", \\\"{x:1125,y:904,t:1527023574206};\\\", \\\"{x:1124,y:904,t:1527023574310};\\\", \\\"{x:1122,y:904,t:1527023574324};\\\", \\\"{x:1118,y:904,t:1527023574341};\\\", \\\"{x:1113,y:907,t:1527023574358};\\\", \\\"{x:1108,y:909,t:1527023574374};\\\", \\\"{x:1105,y:910,t:1527023574391};\\\", \\\"{x:1105,y:911,t:1527023574408};\\\", \\\"{x:1104,y:911,t:1527023574426};\\\", \\\"{x:1103,y:910,t:1527023574518};\\\", \\\"{x:1105,y:903,t:1527023574526};\\\", \\\"{x:1118,y:882,t:1527023574541};\\\", \\\"{x:1136,y:857,t:1527023574557};\\\", \\\"{x:1168,y:815,t:1527023574574};\\\", \\\"{x:1203,y:767,t:1527023574595};\\\", \\\"{x:1242,y:718,t:1527023574612};\\\", \\\"{x:1287,y:665,t:1527023574629};\\\", \\\"{x:1334,y:623,t:1527023574645};\\\", \\\"{x:1393,y:568,t:1527023574662};\\\", \\\"{x:1444,y:527,t:1527023574679};\\\", \\\"{x:1477,y:498,t:1527023574695};\\\", \\\"{x:1499,y:479,t:1527023574712};\\\", \\\"{x:1518,y:467,t:1527023574729};\\\", \\\"{x:1519,y:464,t:1527023574746};\\\", \\\"{x:1519,y:463,t:1527023574762};\\\", \\\"{x:1516,y:462,t:1527023574833};\\\", \\\"{x:1505,y:461,t:1527023574846};\\\", \\\"{x:1491,y:457,t:1527023574863};\\\", \\\"{x:1457,y:455,t:1527023574879};\\\", \\\"{x:1423,y:450,t:1527023574895};\\\", \\\"{x:1379,y:450,t:1527023574913};\\\", \\\"{x:1357,y:450,t:1527023574931};\\\", \\\"{x:1345,y:450,t:1527023574947};\\\", \\\"{x:1341,y:449,t:1527023574962};\\\", \\\"{x:1340,y:449,t:1527023575024};\\\", \\\"{x:1338,y:449,t:1527023575032};\\\", \\\"{x:1338,y:451,t:1527023575048};\\\", \\\"{x:1336,y:453,t:1527023575063};\\\", \\\"{x:1333,y:459,t:1527023575080};\\\", \\\"{x:1330,y:464,t:1527023575096};\\\", \\\"{x:1327,y:468,t:1527023575113};\\\", \\\"{x:1322,y:472,t:1527023575130};\\\", \\\"{x:1315,y:479,t:1527023575146};\\\", \\\"{x:1305,y:486,t:1527023575163};\\\", \\\"{x:1301,y:489,t:1527023575180};\\\", \\\"{x:1298,y:491,t:1527023575197};\\\", \\\"{x:1298,y:492,t:1527023575213};\\\", \\\"{x:1297,y:494,t:1527023575272};\\\", \\\"{x:1296,y:496,t:1527023575280};\\\", \\\"{x:1292,y:504,t:1527023575297};\\\", \\\"{x:1288,y:512,t:1527023575315};\\\", \\\"{x:1284,y:517,t:1527023575332};\\\", \\\"{x:1280,y:521,t:1527023575348};\\\", \\\"{x:1279,y:521,t:1527023575364};\\\", \\\"{x:1277,y:523,t:1527023575381};\\\", \\\"{x:1277,y:519,t:1527023575530};\\\", \\\"{x:1279,y:515,t:1527023575537};\\\", \\\"{x:1280,y:512,t:1527023575549};\\\", \\\"{x:1281,y:509,t:1527023575565};\\\", \\\"{x:1282,y:508,t:1527023575583};\\\", \\\"{x:1283,y:514,t:1527023575697};\\\", \\\"{x:1284,y:519,t:1527023575706};\\\", \\\"{x:1287,y:525,t:1527023575717};\\\", \\\"{x:1292,y:537,t:1527023575733};\\\", \\\"{x:1295,y:542,t:1527023575750};\\\", \\\"{x:1296,y:548,t:1527023575767};\\\", \\\"{x:1298,y:551,t:1527023575783};\\\", \\\"{x:1299,y:554,t:1527023575800};\\\", \\\"{x:1302,y:560,t:1527023575817};\\\", \\\"{x:1303,y:563,t:1527023575833};\\\", \\\"{x:1305,y:569,t:1527023575850};\\\", \\\"{x:1306,y:571,t:1527023575867};\\\", \\\"{x:1308,y:575,t:1527023575884};\\\", \\\"{x:1310,y:579,t:1527023575901};\\\", \\\"{x:1311,y:582,t:1527023575917};\\\", \\\"{x:1313,y:586,t:1527023575933};\\\", \\\"{x:1314,y:588,t:1527023575951};\\\", \\\"{x:1315,y:589,t:1527023575968};\\\", \\\"{x:1316,y:592,t:1527023575984};\\\", \\\"{x:1317,y:594,t:1527023576000};\\\", \\\"{x:1318,y:596,t:1527023576018};\\\", \\\"{x:1319,y:597,t:1527023576041};\\\", \\\"{x:1319,y:598,t:1527023576051};\\\", \\\"{x:1321,y:599,t:1527023576067};\\\", \\\"{x:1324,y:603,t:1527023576085};\\\", \\\"{x:1328,y:607,t:1527023576101};\\\", \\\"{x:1341,y:612,t:1527023576118};\\\", \\\"{x:1345,y:613,t:1527023576135};\\\", \\\"{x:1348,y:613,t:1527023576152};\\\", \\\"{x:1345,y:610,t:1527023576593};\\\", \\\"{x:1343,y:605,t:1527023576604};\\\", \\\"{x:1333,y:588,t:1527023576620};\\\", \\\"{x:1320,y:571,t:1527023576637};\\\", \\\"{x:1309,y:546,t:1527023576654};\\\", \\\"{x:1294,y:520,t:1527023576671};\\\", \\\"{x:1283,y:499,t:1527023576687};\\\", \\\"{x:1275,y:485,t:1527023576704};\\\", \\\"{x:1271,y:478,t:1527023576721};\\\", \\\"{x:1271,y:479,t:1527023576786};\\\", \\\"{x:1271,y:487,t:1527023576793};\\\", \\\"{x:1277,y:502,t:1527023576804};\\\", \\\"{x:1287,y:536,t:1527023576822};\\\", \\\"{x:1301,y:574,t:1527023576837};\\\", \\\"{x:1316,y:619,t:1527023576854};\\\", \\\"{x:1334,y:661,t:1527023576871};\\\", \\\"{x:1353,y:700,t:1527023576888};\\\", \\\"{x:1380,y:758,t:1527023576903};\\\", \\\"{x:1403,y:798,t:1527023576921};\\\", \\\"{x:1418,y:832,t:1527023576938};\\\", \\\"{x:1427,y:856,t:1527023576954};\\\", \\\"{x:1437,y:875,t:1527023576971};\\\", \\\"{x:1446,y:896,t:1527023576989};\\\", \\\"{x:1456,y:920,t:1527023577004};\\\", \\\"{x:1464,y:937,t:1527023577022};\\\", \\\"{x:1473,y:954,t:1527023577038};\\\", \\\"{x:1477,y:962,t:1527023577055};\\\", \\\"{x:1478,y:965,t:1527023577071};\\\", \\\"{x:1476,y:965,t:1527023577104};\\\", \\\"{x:1466,y:964,t:1527023577122};\\\", \\\"{x:1445,y:952,t:1527023577138};\\\", \\\"{x:1410,y:932,t:1527023577156};\\\", \\\"{x:1360,y:900,t:1527023577172};\\\", \\\"{x:1275,y:855,t:1527023577188};\\\", \\\"{x:1209,y:826,t:1527023577205};\\\", \\\"{x:1176,y:804,t:1527023577223};\\\", \\\"{x:1161,y:796,t:1527023577239};\\\", \\\"{x:1156,y:793,t:1527023577255};\\\", \\\"{x:1153,y:790,t:1527023577273};\\\", \\\"{x:1149,y:787,t:1527023577290};\\\", \\\"{x:1144,y:780,t:1527023577307};\\\", \\\"{x:1138,y:773,t:1527023577323};\\\", \\\"{x:1134,y:765,t:1527023577339};\\\", \\\"{x:1126,y:755,t:1527023577357};\\\", \\\"{x:1117,y:744,t:1527023577374};\\\", \\\"{x:1113,y:739,t:1527023577390};\\\", \\\"{x:1112,y:736,t:1527023577407};\\\", \\\"{x:1112,y:732,t:1527023577424};\\\", \\\"{x:1112,y:727,t:1527023577440};\\\", \\\"{x:1114,y:718,t:1527023577457};\\\", \\\"{x:1119,y:712,t:1527023577474};\\\", \\\"{x:1124,y:706,t:1527023577491};\\\", \\\"{x:1129,y:705,t:1527023577507};\\\", \\\"{x:1137,y:701,t:1527023577524};\\\", \\\"{x:1143,y:699,t:1527023577540};\\\", \\\"{x:1149,y:698,t:1527023577558};\\\", \\\"{x:1155,y:695,t:1527023577574};\\\", \\\"{x:1160,y:692,t:1527023577591};\\\", \\\"{x:1166,y:690,t:1527023577608};\\\", \\\"{x:1175,y:686,t:1527023577625};\\\", \\\"{x:1176,y:685,t:1527023577641};\\\", \\\"{x:1177,y:686,t:1527023577785};\\\", \\\"{x:1177,y:688,t:1527023577793};\\\", \\\"{x:1177,y:692,t:1527023577809};\\\", \\\"{x:1177,y:696,t:1527023577824};\\\", \\\"{x:1177,y:698,t:1527023577841};\\\", \\\"{x:1177,y:699,t:1527023577859};\\\", \\\"{x:1178,y:701,t:1527023577875};\\\", \\\"{x:1179,y:707,t:1527023577893};\\\", \\\"{x:1184,y:718,t:1527023577910};\\\", \\\"{x:1194,y:745,t:1527023577926};\\\", \\\"{x:1217,y:795,t:1527023577943};\\\", \\\"{x:1244,y:853,t:1527023577959};\\\", \\\"{x:1278,y:903,t:1527023577976};\\\", \\\"{x:1327,y:960,t:1527023577993};\\\", \\\"{x:1348,y:987,t:1527023578010};\\\", \\\"{x:1359,y:1005,t:1527023578026};\\\", \\\"{x:1366,y:1014,t:1527023578042};\\\", \\\"{x:1368,y:1018,t:1527023578059};\\\", \\\"{x:1369,y:1019,t:1527023578077};\\\", \\\"{x:1369,y:1017,t:1527023578361};\\\", \\\"{x:1368,y:1012,t:1527023578377};\\\", \\\"{x:1365,y:1007,t:1527023578394};\\\", \\\"{x:1361,y:1000,t:1527023578410};\\\", \\\"{x:1355,y:992,t:1527023578428};\\\", \\\"{x:1351,y:985,t:1527023578445};\\\", \\\"{x:1340,y:971,t:1527023578462};\\\", \\\"{x:1322,y:959,t:1527023578478};\\\", \\\"{x:1303,y:943,t:1527023578495};\\\", \\\"{x:1283,y:930,t:1527023578512};\\\", \\\"{x:1261,y:915,t:1527023578528};\\\", \\\"{x:1229,y:893,t:1527023578545};\\\", \\\"{x:1210,y:878,t:1527023578562};\\\", \\\"{x:1188,y:859,t:1527023578579};\\\", \\\"{x:1161,y:830,t:1527023578595};\\\", \\\"{x:1125,y:786,t:1527023578612};\\\", \\\"{x:1075,y:739,t:1527023578631};\\\", \\\"{x:1033,y:703,t:1527023578646};\\\", \\\"{x:1002,y:685,t:1527023578662};\\\", \\\"{x:983,y:673,t:1527023578679};\\\", \\\"{x:974,y:659,t:1527023578696};\\\", \\\"{x:971,y:649,t:1527023578712};\\\", \\\"{x:971,y:642,t:1527023578728};\\\", \\\"{x:962,y:642,t:1527023579121};\\\", \\\"{x:941,y:643,t:1527023579131};\\\", \\\"{x:889,y:656,t:1527023579148};\\\", \\\"{x:836,y:671,t:1527023579163};\\\", \\\"{x:786,y:685,t:1527023579181};\\\", \\\"{x:759,y:693,t:1527023579198};\\\", \\\"{x:739,y:695,t:1527023579215};\\\", \\\"{x:723,y:696,t:1527023579231};\\\", \\\"{x:712,y:699,t:1527023579248};\\\", \\\"{x:687,y:701,t:1527023579265};\\\", \\\"{x:661,y:701,t:1527023579281};\\\", \\\"{x:634,y:701,t:1527023579297};\\\", \\\"{x:610,y:701,t:1527023579315};\\\", \\\"{x:587,y:701,t:1527023579332};\\\", \\\"{x:567,y:701,t:1527023579349};\\\", \\\"{x:558,y:701,t:1527023579365};\\\", \\\"{x:552,y:701,t:1527023579383};\\\", \\\"{x:547,y:701,t:1527023579398};\\\", \\\"{x:545,y:701,t:1527023579414};\\\", \\\"{x:539,y:699,t:1527023579428};\\\", \\\"{x:537,y:699,t:1527023579445};\\\", \\\"{x:535,y:698,t:1527023579461};\\\", \\\"{x:535,y:697,t:1527023579576};\\\", \\\"{x:535,y:696,t:1527023579585};\\\", \\\"{x:535,y:695,t:1527023579594};\\\", \\\"{x:534,y:693,t:1527023579611};\\\", \\\"{x:534,y:692,t:1527023579641};\\\", \\\"{x:534,y:690,t:1527023579656};\\\", \\\"{x:534,y:689,t:1527023579689};\\\", \\\"{x:533,y:688,t:1527023579977};\\\", \\\"{x:532,y:685,t:1527023579984};\\\", \\\"{x:531,y:679,t:1527023579996};\\\", \\\"{x:529,y:671,t:1527023580012};\\\", \\\"{x:527,y:665,t:1527023580029};\\\", \\\"{x:526,y:663,t:1527023580045};\\\", \\\"{x:533,y:663,t:1527023580152};\\\", \\\"{x:545,y:663,t:1527023580165};\\\", \\\"{x:602,y:663,t:1527023580180};\\\", \\\"{x:710,y:663,t:1527023580197};\\\", \\\"{x:840,y:663,t:1527023580214};\\\", \\\"{x:934,y:663,t:1527023580231};\\\", \\\"{x:993,y:663,t:1527023580248};\\\", \\\"{x:1050,y:663,t:1527023580264};\\\", \\\"{x:1066,y:663,t:1527023580281};\\\", \\\"{x:1074,y:663,t:1527023580297};\\\", \\\"{x:1076,y:663,t:1527023580315};\\\", \\\"{x:1074,y:663,t:1527023580369};\\\", \\\"{x:1073,y:663,t:1527023580382};\\\", \\\"{x:1069,y:663,t:1527023580397};\\\", \\\"{x:1064,y:663,t:1527023580414};\\\", \\\"{x:1053,y:658,t:1527023580432};\\\", \\\"{x:1047,y:653,t:1527023580447};\\\", \\\"{x:1047,y:652,t:1527023580969};\\\", \\\"{x:1047,y:651,t:1527023580982};\\\", \\\"{x:1052,y:651,t:1527023580998};\\\", \\\"{x:1060,y:649,t:1527023581015};\\\", \\\"{x:1064,y:647,t:1527023581032};\\\", \\\"{x:1082,y:641,t:1527023581049};\\\", \\\"{x:1092,y:639,t:1527023581065};\\\", \\\"{x:1099,y:638,t:1527023581082};\\\", \\\"{x:1105,y:637,t:1527023581099};\\\", \\\"{x:1111,y:637,t:1527023581115};\\\", \\\"{x:1115,y:639,t:1527023581131};\\\", \\\"{x:1120,y:643,t:1527023581149};\\\", \\\"{x:1126,y:649,t:1527023581165};\\\", \\\"{x:1134,y:657,t:1527023581182};\\\", \\\"{x:1143,y:668,t:1527023581199};\\\", \\\"{x:1159,y:677,t:1527023581215};\\\", \\\"{x:1166,y:682,t:1527023581232};\\\", \\\"{x:1171,y:683,t:1527023581249};\\\", \\\"{x:1172,y:683,t:1527023581265};\\\", \\\"{x:1173,y:683,t:1527023581313};\\\", \\\"{x:1175,y:685,t:1527023581794};\\\", \\\"{x:1175,y:686,t:1527023581801};\\\", \\\"{x:1175,y:684,t:1527023582017};\\\", \\\"{x:1173,y:679,t:1527023582032};\\\", \\\"{x:1165,y:663,t:1527023582048};\\\", \\\"{x:1165,y:662,t:1527023582088};\\\", \\\"{x:1165,y:660,t:1527023582321};\\\", \\\"{x:1165,y:659,t:1527023582332};\\\", \\\"{x:1165,y:654,t:1527023582349};\\\", \\\"{x:1167,y:651,t:1527023582366};\\\", \\\"{x:1168,y:646,t:1527023582383};\\\", \\\"{x:1168,y:641,t:1527023582399};\\\", \\\"{x:1168,y:634,t:1527023582417};\\\", \\\"{x:1168,y:633,t:1527023582433};\\\", \\\"{x:1168,y:632,t:1527023582449};\\\", \\\"{x:1168,y:633,t:1527023583097};\\\", \\\"{x:1168,y:636,t:1527023583105};\\\", \\\"{x:1168,y:638,t:1527023583121};\\\", \\\"{x:1168,y:639,t:1527023583133};\\\", \\\"{x:1168,y:642,t:1527023583150};\\\", \\\"{x:1168,y:646,t:1527023583167};\\\", \\\"{x:1168,y:653,t:1527023583183};\\\", \\\"{x:1168,y:659,t:1527023583201};\\\", \\\"{x:1169,y:662,t:1527023583217};\\\", \\\"{x:1172,y:668,t:1527023583232};\\\", \\\"{x:1175,y:673,t:1527023583250};\\\", \\\"{x:1175,y:676,t:1527023583266};\\\", \\\"{x:1176,y:681,t:1527023583283};\\\", \\\"{x:1177,y:687,t:1527023583300};\\\", \\\"{x:1178,y:692,t:1527023583316};\\\", \\\"{x:1179,y:699,t:1527023583333};\\\", \\\"{x:1181,y:706,t:1527023583350};\\\", \\\"{x:1181,y:715,t:1527023583365};\\\", \\\"{x:1181,y:725,t:1527023583384};\\\", \\\"{x:1181,y:734,t:1527023583400};\\\", \\\"{x:1181,y:742,t:1527023583417};\\\", \\\"{x:1181,y:747,t:1527023583433};\\\", \\\"{x:1179,y:752,t:1527023583450};\\\", \\\"{x:1178,y:756,t:1527023583466};\\\", \\\"{x:1177,y:764,t:1527023583483};\\\", \\\"{x:1176,y:770,t:1527023583500};\\\", \\\"{x:1175,y:776,t:1527023583516};\\\", \\\"{x:1175,y:782,t:1527023583533};\\\", \\\"{x:1175,y:787,t:1527023583550};\\\", \\\"{x:1172,y:797,t:1527023583566};\\\", \\\"{x:1169,y:806,t:1527023583583};\\\", \\\"{x:1166,y:817,t:1527023583600};\\\", \\\"{x:1159,y:832,t:1527023583617};\\\", \\\"{x:1151,y:848,t:1527023583633};\\\", \\\"{x:1148,y:853,t:1527023583650};\\\", \\\"{x:1146,y:856,t:1527023583668};\\\", \\\"{x:1145,y:857,t:1527023583683};\\\", \\\"{x:1145,y:859,t:1527023583700};\\\", \\\"{x:1145,y:861,t:1527023583717};\\\", \\\"{x:1145,y:863,t:1527023583734};\\\", \\\"{x:1145,y:864,t:1527023583753};\\\", \\\"{x:1145,y:865,t:1527023583785};\\\", \\\"{x:1145,y:867,t:1527023583801};\\\", \\\"{x:1146,y:867,t:1527023583817};\\\", \\\"{x:1147,y:871,t:1527023583833};\\\", \\\"{x:1150,y:875,t:1527023583851};\\\", \\\"{x:1152,y:877,t:1527023583867};\\\", \\\"{x:1153,y:882,t:1527023583883};\\\", \\\"{x:1156,y:890,t:1527023583900};\\\", \\\"{x:1156,y:897,t:1527023583917};\\\", \\\"{x:1156,y:902,t:1527023583933};\\\", \\\"{x:1156,y:903,t:1527023583950};\\\", \\\"{x:1155,y:906,t:1527023583967};\\\", \\\"{x:1154,y:906,t:1527023584513};\\\", \\\"{x:1153,y:906,t:1527023584529};\\\", \\\"{x:1152,y:902,t:1527023584537};\\\", \\\"{x:1151,y:900,t:1527023584550};\\\", \\\"{x:1147,y:895,t:1527023584567};\\\", \\\"{x:1145,y:890,t:1527023584584};\\\", \\\"{x:1142,y:887,t:1527023584600};\\\", \\\"{x:1141,y:886,t:1527023584618};\\\", \\\"{x:1140,y:886,t:1527023584785};\\\", \\\"{x:1138,y:886,t:1527023584801};\\\", \\\"{x:1138,y:887,t:1527023584817};\\\", \\\"{x:1138,y:889,t:1527023584834};\\\", \\\"{x:1138,y:890,t:1527023584857};\\\", \\\"{x:1138,y:891,t:1527023584867};\\\", \\\"{x:1138,y:892,t:1527023584889};\\\", \\\"{x:1136,y:892,t:1527023585873};\\\", \\\"{x:1135,y:893,t:1527023585888};\\\", \\\"{x:1134,y:893,t:1527023585905};\\\", \\\"{x:1133,y:893,t:1527023585918};\\\", \\\"{x:1132,y:894,t:1527023585936};\\\", \\\"{x:1132,y:895,t:1527023585952};\\\", \\\"{x:1130,y:895,t:1527023586017};\\\", \\\"{x:1131,y:895,t:1527023586473};\\\", \\\"{x:1137,y:894,t:1527023586485};\\\", \\\"{x:1149,y:888,t:1527023586501};\\\", \\\"{x:1165,y:882,t:1527023586518};\\\", \\\"{x:1182,y:877,t:1527023586535};\\\", \\\"{x:1195,y:871,t:1527023586551};\\\", \\\"{x:1213,y:860,t:1527023586569};\\\", \\\"{x:1228,y:847,t:1527023586585};\\\", \\\"{x:1243,y:831,t:1527023586602};\\\", \\\"{x:1255,y:814,t:1527023586618};\\\", \\\"{x:1268,y:793,t:1527023586636};\\\", \\\"{x:1278,y:771,t:1527023586651};\\\", \\\"{x:1289,y:748,t:1527023586669};\\\", \\\"{x:1297,y:732,t:1527023586686};\\\", \\\"{x:1304,y:720,t:1527023586701};\\\", \\\"{x:1310,y:705,t:1527023586719};\\\", \\\"{x:1317,y:690,t:1527023586735};\\\", \\\"{x:1322,y:676,t:1527023586751};\\\", \\\"{x:1329,y:666,t:1527023586769};\\\", \\\"{x:1331,y:656,t:1527023586784};\\\", \\\"{x:1332,y:652,t:1527023586801};\\\", \\\"{x:1332,y:650,t:1527023586914};\\\", \\\"{x:1332,y:649,t:1527023586921};\\\", \\\"{x:1331,y:646,t:1527023586935};\\\", \\\"{x:1320,y:634,t:1527023586953};\\\", \\\"{x:1318,y:628,t:1527023586968};\\\", \\\"{x:1310,y:618,t:1527023586985};\\\", \\\"{x:1305,y:609,t:1527023587003};\\\", \\\"{x:1294,y:595,t:1527023587018};\\\", \\\"{x:1284,y:578,t:1527023587035};\\\", \\\"{x:1281,y:568,t:1527023587052};\\\", \\\"{x:1279,y:565,t:1527023587069};\\\", \\\"{x:1278,y:563,t:1527023587085};\\\", \\\"{x:1278,y:561,t:1527023587102};\\\", \\\"{x:1278,y:560,t:1527023587118};\\\", \\\"{x:1278,y:559,t:1527023587135};\\\", \\\"{x:1277,y:559,t:1527023587393};\\\", \\\"{x:1277,y:560,t:1527023587426};\\\", \\\"{x:1277,y:561,t:1527023587441};\\\", \\\"{x:1277,y:562,t:1527023587473};\\\", \\\"{x:1277,y:563,t:1527023587485};\\\", \\\"{x:1277,y:564,t:1527023587505};\\\", \\\"{x:1277,y:565,t:1527023587520};\\\", \\\"{x:1277,y:566,t:1527023587535};\\\", \\\"{x:1278,y:569,t:1527023587552};\\\", \\\"{x:1278,y:570,t:1527023587585};\\\", \\\"{x:1279,y:574,t:1527023587603};\\\", \\\"{x:1284,y:581,t:1527023587620};\\\", \\\"{x:1288,y:591,t:1527023587636};\\\", \\\"{x:1299,y:607,t:1527023587653};\\\", \\\"{x:1310,y:621,t:1527023587670};\\\", \\\"{x:1320,y:634,t:1527023587685};\\\", \\\"{x:1330,y:646,t:1527023587702};\\\", \\\"{x:1335,y:657,t:1527023587720};\\\", \\\"{x:1341,y:673,t:1527023587735};\\\", \\\"{x:1349,y:706,t:1527023587753};\\\", \\\"{x:1353,y:729,t:1527023587769};\\\", \\\"{x:1355,y:755,t:1527023587786};\\\", \\\"{x:1355,y:779,t:1527023587802};\\\", \\\"{x:1355,y:796,t:1527023587819};\\\", \\\"{x:1352,y:811,t:1527023587835};\\\", \\\"{x:1351,y:821,t:1527023587852};\\\", \\\"{x:1351,y:827,t:1527023587870};\\\", \\\"{x:1350,y:832,t:1527023587885};\\\", \\\"{x:1349,y:836,t:1527023587902};\\\", \\\"{x:1348,y:839,t:1527023587920};\\\", \\\"{x:1347,y:841,t:1527023587935};\\\", \\\"{x:1344,y:846,t:1527023587953};\\\", \\\"{x:1341,y:850,t:1527023587969};\\\", \\\"{x:1338,y:853,t:1527023587985};\\\", \\\"{x:1333,y:856,t:1527023588003};\\\", \\\"{x:1329,y:858,t:1527023588020};\\\", \\\"{x:1325,y:861,t:1527023588035};\\\", \\\"{x:1322,y:863,t:1527023588052};\\\", \\\"{x:1321,y:863,t:1527023588081};\\\", \\\"{x:1321,y:861,t:1527023588153};\\\", \\\"{x:1321,y:854,t:1527023588169};\\\", \\\"{x:1321,y:843,t:1527023588186};\\\", \\\"{x:1321,y:831,t:1527023588203};\\\", \\\"{x:1321,y:815,t:1527023588219};\\\", \\\"{x:1321,y:800,t:1527023588235};\\\", \\\"{x:1324,y:783,t:1527023588251};\\\", \\\"{x:1326,y:767,t:1527023588268};\\\", \\\"{x:1329,y:751,t:1527023588285};\\\", \\\"{x:1332,y:736,t:1527023588302};\\\", \\\"{x:1334,y:721,t:1527023588319};\\\", \\\"{x:1336,y:710,t:1527023588336};\\\", \\\"{x:1338,y:699,t:1527023588352};\\\", \\\"{x:1339,y:692,t:1527023588369};\\\", \\\"{x:1340,y:687,t:1527023588386};\\\", \\\"{x:1340,y:680,t:1527023588402};\\\", \\\"{x:1340,y:677,t:1527023588419};\\\", \\\"{x:1342,y:674,t:1527023588436};\\\", \\\"{x:1337,y:685,t:1527023588529};\\\", \\\"{x:1329,y:701,t:1527023588536};\\\", \\\"{x:1316,y:734,t:1527023588552};\\\", \\\"{x:1305,y:766,t:1527023588570};\\\", \\\"{x:1290,y:809,t:1527023588587};\\\", \\\"{x:1276,y:846,t:1527023588603};\\\", \\\"{x:1264,y:875,t:1527023588620};\\\", \\\"{x:1258,y:892,t:1527023588637};\\\", \\\"{x:1256,y:902,t:1527023588653};\\\", \\\"{x:1254,y:908,t:1527023588669};\\\", \\\"{x:1254,y:913,t:1527023588686};\\\", \\\"{x:1254,y:916,t:1527023588703};\\\", \\\"{x:1254,y:919,t:1527023588719};\\\", \\\"{x:1254,y:922,t:1527023588736};\\\", \\\"{x:1254,y:924,t:1527023588752};\\\", \\\"{x:1254,y:929,t:1527023588769};\\\", \\\"{x:1252,y:933,t:1527023588786};\\\", \\\"{x:1249,y:936,t:1527023588803};\\\", \\\"{x:1247,y:938,t:1527023588820};\\\", \\\"{x:1245,y:939,t:1527023588836};\\\", \\\"{x:1243,y:940,t:1527023588853};\\\", \\\"{x:1242,y:941,t:1527023588869};\\\", \\\"{x:1241,y:941,t:1527023588886};\\\", \\\"{x:1237,y:941,t:1527023588903};\\\", \\\"{x:1233,y:941,t:1527023588920};\\\", \\\"{x:1225,y:941,t:1527023588936};\\\", \\\"{x:1217,y:940,t:1527023588953};\\\", \\\"{x:1210,y:936,t:1527023588969};\\\", \\\"{x:1205,y:932,t:1527023588987};\\\", \\\"{x:1201,y:929,t:1527023589003};\\\", \\\"{x:1199,y:927,t:1527023589019};\\\", \\\"{x:1198,y:925,t:1527023589036};\\\", \\\"{x:1197,y:924,t:1527023589053};\\\", \\\"{x:1197,y:923,t:1527023589069};\\\", \\\"{x:1197,y:922,t:1527023589086};\\\", \\\"{x:1197,y:921,t:1527023589103};\\\", \\\"{x:1197,y:919,t:1527023589119};\\\", \\\"{x:1197,y:916,t:1527023589136};\\\", \\\"{x:1197,y:914,t:1527023589153};\\\", \\\"{x:1200,y:910,t:1527023589170};\\\", \\\"{x:1204,y:906,t:1527023589186};\\\", \\\"{x:1208,y:901,t:1527023589203};\\\", \\\"{x:1214,y:895,t:1527023589219};\\\", \\\"{x:1222,y:885,t:1527023589236};\\\", \\\"{x:1230,y:877,t:1527023589253};\\\", \\\"{x:1236,y:867,t:1527023589269};\\\", \\\"{x:1242,y:857,t:1527023589286};\\\", \\\"{x:1250,y:845,t:1527023589303};\\\", \\\"{x:1258,y:830,t:1527023589319};\\\", \\\"{x:1270,y:804,t:1527023589337};\\\", \\\"{x:1280,y:787,t:1527023589353};\\\", \\\"{x:1286,y:771,t:1527023589369};\\\", \\\"{x:1294,y:755,t:1527023589386};\\\", \\\"{x:1301,y:739,t:1527023589403};\\\", \\\"{x:1306,y:728,t:1527023589419};\\\", \\\"{x:1311,y:718,t:1527023589437};\\\", \\\"{x:1313,y:712,t:1527023589454};\\\", \\\"{x:1316,y:708,t:1527023589471};\\\", \\\"{x:1316,y:705,t:1527023589486};\\\", \\\"{x:1317,y:705,t:1527023589504};\\\", \\\"{x:1317,y:714,t:1527023589570};\\\", \\\"{x:1312,y:737,t:1527023589586};\\\", \\\"{x:1306,y:760,t:1527023589603};\\\", \\\"{x:1300,y:784,t:1527023589621};\\\", \\\"{x:1288,y:811,t:1527023589637};\\\", \\\"{x:1275,y:836,t:1527023589654};\\\", \\\"{x:1265,y:859,t:1527023589671};\\\", \\\"{x:1257,y:874,t:1527023589687};\\\", \\\"{x:1254,y:885,t:1527023589703};\\\", \\\"{x:1249,y:898,t:1527023589721};\\\", \\\"{x:1249,y:900,t:1527023589737};\\\", \\\"{x:1248,y:902,t:1527023589753};\\\", \\\"{x:1247,y:904,t:1527023589771};\\\", \\\"{x:1247,y:905,t:1527023589786};\\\", \\\"{x:1247,y:907,t:1527023589804};\\\", \\\"{x:1247,y:908,t:1527023589905};\\\", \\\"{x:1248,y:911,t:1527023589921};\\\", \\\"{x:1249,y:913,t:1527023589937};\\\", \\\"{x:1251,y:916,t:1527023589954};\\\", \\\"{x:1251,y:917,t:1527023589971};\\\", \\\"{x:1252,y:918,t:1527023589987};\\\", \\\"{x:1252,y:915,t:1527023590841};\\\", \\\"{x:1254,y:913,t:1527023590854};\\\", \\\"{x:1254,y:908,t:1527023590871};\\\", \\\"{x:1254,y:906,t:1527023590888};\\\", \\\"{x:1254,y:904,t:1527023590904};\\\", \\\"{x:1254,y:903,t:1527023590921};\\\", \\\"{x:1255,y:901,t:1527023590937};\\\", \\\"{x:1255,y:900,t:1527023590954};\\\", \\\"{x:1255,y:898,t:1527023590970};\\\", \\\"{x:1255,y:897,t:1527023590987};\\\", \\\"{x:1256,y:894,t:1527023591005};\\\", \\\"{x:1258,y:890,t:1527023591020};\\\", \\\"{x:1259,y:884,t:1527023591038};\\\", \\\"{x:1259,y:880,t:1527023591054};\\\", \\\"{x:1262,y:873,t:1527023591070};\\\", \\\"{x:1265,y:860,t:1527023591088};\\\", \\\"{x:1272,y:843,t:1527023591105};\\\", \\\"{x:1279,y:827,t:1527023591120};\\\", \\\"{x:1289,y:809,t:1527023591138};\\\", \\\"{x:1298,y:795,t:1527023591155};\\\", \\\"{x:1303,y:787,t:1527023591171};\\\", \\\"{x:1309,y:778,t:1527023591188};\\\", \\\"{x:1314,y:769,t:1527023591204};\\\", \\\"{x:1319,y:759,t:1527023591221};\\\", \\\"{x:1324,y:750,t:1527023591237};\\\", \\\"{x:1328,y:742,t:1527023591255};\\\", \\\"{x:1330,y:738,t:1527023591271};\\\", \\\"{x:1332,y:735,t:1527023591287};\\\", \\\"{x:1339,y:725,t:1527023591305};\\\", \\\"{x:1343,y:717,t:1527023591320};\\\", \\\"{x:1345,y:713,t:1527023591338};\\\", \\\"{x:1349,y:707,t:1527023591354};\\\", \\\"{x:1351,y:703,t:1527023591372};\\\", \\\"{x:1351,y:701,t:1527023591388};\\\", \\\"{x:1352,y:698,t:1527023591405};\\\", \\\"{x:1354,y:697,t:1527023591422};\\\", \\\"{x:1354,y:696,t:1527023591437};\\\", \\\"{x:1354,y:698,t:1527023591625};\\\", \\\"{x:1354,y:699,t:1527023591637};\\\", \\\"{x:1354,y:702,t:1527023591655};\\\", \\\"{x:1354,y:704,t:1527023591672};\\\", \\\"{x:1354,y:705,t:1527023591688};\\\", \\\"{x:1354,y:707,t:1527023591705};\\\", \\\"{x:1354,y:710,t:1527023592226};\\\", \\\"{x:1352,y:714,t:1527023592239};\\\", \\\"{x:1339,y:724,t:1527023592256};\\\", \\\"{x:1328,y:737,t:1527023592271};\\\", \\\"{x:1313,y:755,t:1527023592289};\\\", \\\"{x:1303,y:772,t:1527023592305};\\\", \\\"{x:1293,y:788,t:1527023592321};\\\", \\\"{x:1286,y:804,t:1527023592338};\\\", \\\"{x:1278,y:822,t:1527023592355};\\\", \\\"{x:1271,y:842,t:1527023592371};\\\", \\\"{x:1262,y:857,t:1527023592389};\\\", \\\"{x:1257,y:870,t:1527023592405};\\\", \\\"{x:1252,y:885,t:1527023592422};\\\", \\\"{x:1247,y:897,t:1527023592438};\\\", \\\"{x:1244,y:907,t:1527023592454};\\\", \\\"{x:1243,y:915,t:1527023592471};\\\", \\\"{x:1242,y:923,t:1527023592488};\\\", \\\"{x:1241,y:927,t:1527023592503};\\\", \\\"{x:1241,y:929,t:1527023592521};\\\", \\\"{x:1244,y:925,t:1527023592673};\\\", \\\"{x:1247,y:916,t:1527023592689};\\\", \\\"{x:1255,y:902,t:1527023592704};\\\", \\\"{x:1260,y:882,t:1527023592721};\\\", \\\"{x:1271,y:859,t:1527023592739};\\\", \\\"{x:1278,y:838,t:1527023592756};\\\", \\\"{x:1287,y:818,t:1527023592772};\\\", \\\"{x:1293,y:805,t:1527023592789};\\\", \\\"{x:1300,y:790,t:1527023592806};\\\", \\\"{x:1307,y:774,t:1527023592822};\\\", \\\"{x:1310,y:764,t:1527023592839};\\\", \\\"{x:1315,y:750,t:1527023592856};\\\", \\\"{x:1320,y:740,t:1527023592872};\\\", \\\"{x:1327,y:728,t:1527023592888};\\\", \\\"{x:1329,y:723,t:1527023592905};\\\", \\\"{x:1330,y:720,t:1527023592921};\\\", \\\"{x:1332,y:719,t:1527023592938};\\\", \\\"{x:1332,y:718,t:1527023592969};\\\", \\\"{x:1334,y:719,t:1527023593010};\\\", \\\"{x:1336,y:726,t:1527023593021};\\\", \\\"{x:1351,y:749,t:1527023593039};\\\", \\\"{x:1366,y:779,t:1527023593056};\\\", \\\"{x:1390,y:816,t:1527023593072};\\\", \\\"{x:1424,y:862,t:1527023593089};\\\", \\\"{x:1444,y:890,t:1527023593105};\\\", \\\"{x:1464,y:915,t:1527023593121};\\\", \\\"{x:1480,y:931,t:1527023593139};\\\", \\\"{x:1485,y:936,t:1527023593156};\\\", \\\"{x:1488,y:938,t:1527023593172};\\\", \\\"{x:1489,y:939,t:1527023593189};\\\", \\\"{x:1489,y:937,t:1527023593465};\\\", \\\"{x:1486,y:931,t:1527023593473};\\\", \\\"{x:1479,y:923,t:1527023593489};\\\", \\\"{x:1469,y:913,t:1527023593506};\\\", \\\"{x:1450,y:902,t:1527023593522};\\\", \\\"{x:1429,y:893,t:1527023593538};\\\", \\\"{x:1407,y:886,t:1527023593555};\\\", \\\"{x:1386,y:885,t:1527023593572};\\\", \\\"{x:1356,y:885,t:1527023593588};\\\", \\\"{x:1326,y:885,t:1527023593605};\\\", \\\"{x:1299,y:889,t:1527023593622};\\\", \\\"{x:1276,y:896,t:1527023593638};\\\", \\\"{x:1259,y:905,t:1527023593655};\\\", \\\"{x:1250,y:912,t:1527023593672};\\\", \\\"{x:1249,y:913,t:1527023593688};\\\", \\\"{x:1249,y:912,t:1527023593768};\\\", \\\"{x:1250,y:906,t:1527023593776};\\\", \\\"{x:1256,y:894,t:1527023593787};\\\", \\\"{x:1265,y:869,t:1527023593805};\\\", \\\"{x:1283,y:832,t:1527023593821};\\\", \\\"{x:1297,y:797,t:1527023593838};\\\", \\\"{x:1315,y:756,t:1527023593855};\\\", \\\"{x:1331,y:707,t:1527023593871};\\\", \\\"{x:1336,y:692,t:1527023593889};\\\", \\\"{x:1337,y:687,t:1527023593905};\\\", \\\"{x:1338,y:686,t:1527023593922};\\\", \\\"{x:1340,y:683,t:1527023593939};\\\", \\\"{x:1343,y:683,t:1527023593955};\\\", \\\"{x:1345,y:685,t:1527023593972};\\\", \\\"{x:1353,y:700,t:1527023593989};\\\", \\\"{x:1361,y:720,t:1527023594005};\\\", \\\"{x:1372,y:743,t:1527023594022};\\\", \\\"{x:1383,y:763,t:1527023594039};\\\", \\\"{x:1392,y:780,t:1527023594055};\\\", \\\"{x:1400,y:799,t:1527023594072};\\\", \\\"{x:1404,y:810,t:1527023594089};\\\", \\\"{x:1406,y:818,t:1527023594105};\\\", \\\"{x:1408,y:824,t:1527023594122};\\\", \\\"{x:1410,y:833,t:1527023594139};\\\", \\\"{x:1413,y:841,t:1527023594155};\\\", \\\"{x:1415,y:846,t:1527023594172};\\\", \\\"{x:1420,y:852,t:1527023594189};\\\", \\\"{x:1421,y:857,t:1527023594204};\\\", \\\"{x:1423,y:861,t:1527023594223};\\\", \\\"{x:1424,y:863,t:1527023594239};\\\", \\\"{x:1426,y:867,t:1527023594255};\\\", \\\"{x:1426,y:868,t:1527023594272};\\\", \\\"{x:1426,y:869,t:1527023594312};\\\", \\\"{x:1426,y:870,t:1527023594322};\\\", \\\"{x:1426,y:871,t:1527023594360};\\\", \\\"{x:1424,y:871,t:1527023594372};\\\", \\\"{x:1417,y:871,t:1527023594389};\\\", \\\"{x:1410,y:871,t:1527023594405};\\\", \\\"{x:1405,y:871,t:1527023594422};\\\", \\\"{x:1402,y:869,t:1527023594439};\\\", \\\"{x:1397,y:866,t:1527023594455};\\\", \\\"{x:1393,y:863,t:1527023594471};\\\", \\\"{x:1390,y:862,t:1527023594489};\\\", \\\"{x:1389,y:860,t:1527023594505};\\\", \\\"{x:1387,y:861,t:1527023594624};\\\", \\\"{x:1386,y:863,t:1527023594639};\\\", \\\"{x:1384,y:868,t:1527023594656};\\\", \\\"{x:1382,y:872,t:1527023594672};\\\", \\\"{x:1381,y:874,t:1527023594689};\\\", \\\"{x:1381,y:876,t:1527023594706};\\\", \\\"{x:1379,y:880,t:1527023594722};\\\", \\\"{x:1377,y:882,t:1527023594739};\\\", \\\"{x:1376,y:886,t:1527023594756};\\\", \\\"{x:1375,y:887,t:1527023594772};\\\", \\\"{x:1373,y:889,t:1527023594789};\\\", \\\"{x:1371,y:892,t:1527023594806};\\\", \\\"{x:1369,y:896,t:1527023594822};\\\", \\\"{x:1368,y:897,t:1527023594839};\\\", \\\"{x:1367,y:899,t:1527023594855};\\\", \\\"{x:1365,y:899,t:1527023594872};\\\", \\\"{x:1364,y:901,t:1527023594889};\\\", \\\"{x:1363,y:901,t:1527023594906};\\\", \\\"{x:1362,y:902,t:1527023594922};\\\", \\\"{x:1361,y:903,t:1527023594939};\\\", \\\"{x:1360,y:903,t:1527023595000};\\\", \\\"{x:1360,y:904,t:1527023595007};\\\", \\\"{x:1358,y:904,t:1527023595022};\\\", \\\"{x:1356,y:905,t:1527023595039};\\\", \\\"{x:1354,y:908,t:1527023595056};\\\", \\\"{x:1353,y:908,t:1527023595072};\\\", \\\"{x:1351,y:909,t:1527023595089};\\\", \\\"{x:1350,y:911,t:1527023595106};\\\", \\\"{x:1350,y:910,t:1527023595287};\\\", \\\"{x:1350,y:907,t:1527023595296};\\\", \\\"{x:1350,y:904,t:1527023595306};\\\", \\\"{x:1350,y:900,t:1527023595323};\\\", \\\"{x:1351,y:894,t:1527023595339};\\\", \\\"{x:1351,y:889,t:1527023595356};\\\", \\\"{x:1353,y:887,t:1527023595373};\\\", \\\"{x:1354,y:884,t:1527023595389};\\\", \\\"{x:1354,y:882,t:1527023595416};\\\", \\\"{x:1354,y:880,t:1527023595527};\\\", \\\"{x:1354,y:879,t:1527023595539};\\\", \\\"{x:1356,y:877,t:1527023595556};\\\", \\\"{x:1356,y:875,t:1527023595576};\\\", \\\"{x:1356,y:874,t:1527023595720};\\\", \\\"{x:1357,y:872,t:1527023595784};\\\", \\\"{x:1358,y:871,t:1527023595792};\\\", \\\"{x:1358,y:870,t:1527023595815};\\\", \\\"{x:1359,y:869,t:1527023595832};\\\", \\\"{x:1360,y:867,t:1527023595864};\\\", \\\"{x:1361,y:867,t:1527023595880};\\\", \\\"{x:1361,y:866,t:1527023595890};\\\", \\\"{x:1361,y:869,t:1527023596720};\\\", \\\"{x:1358,y:873,t:1527023596728};\\\", \\\"{x:1358,y:874,t:1527023596740};\\\", \\\"{x:1354,y:881,t:1527023596758};\\\", \\\"{x:1352,y:886,t:1527023596773};\\\", \\\"{x:1347,y:892,t:1527023596790};\\\", \\\"{x:1346,y:894,t:1527023596808};\\\", \\\"{x:1345,y:897,t:1527023596823};\\\", \\\"{x:1343,y:902,t:1527023596840};\\\", \\\"{x:1343,y:904,t:1527023596857};\\\", \\\"{x:1342,y:907,t:1527023596873};\\\", \\\"{x:1341,y:909,t:1527023596890};\\\", \\\"{x:1341,y:910,t:1527023596920};\\\", \\\"{x:1341,y:908,t:1527023597376};\\\", \\\"{x:1343,y:906,t:1527023597390};\\\", \\\"{x:1344,y:904,t:1527023597408};\\\", \\\"{x:1345,y:902,t:1527023597424};\\\", \\\"{x:1348,y:899,t:1527023597440};\\\", \\\"{x:1349,y:898,t:1527023597457};\\\", \\\"{x:1351,y:896,t:1527023597474};\\\", \\\"{x:1353,y:894,t:1527023597490};\\\", \\\"{x:1353,y:893,t:1527023597507};\\\", \\\"{x:1355,y:891,t:1527023597525};\\\", \\\"{x:1357,y:890,t:1527023597540};\\\", \\\"{x:1360,y:887,t:1527023597557};\\\", \\\"{x:1363,y:885,t:1527023597575};\\\", \\\"{x:1365,y:883,t:1527023597590};\\\", \\\"{x:1366,y:881,t:1527023597607};\\\", \\\"{x:1368,y:879,t:1527023597623};\\\", \\\"{x:1370,y:877,t:1527023597640};\\\", \\\"{x:1371,y:874,t:1527023597664};\\\", \\\"{x:1372,y:874,t:1527023597674};\\\", \\\"{x:1372,y:873,t:1527023597690};\\\", \\\"{x:1373,y:871,t:1527023597707};\\\", \\\"{x:1374,y:870,t:1527023597725};\\\", \\\"{x:1374,y:869,t:1527023597743};\\\", \\\"{x:1375,y:869,t:1527023597757};\\\", \\\"{x:1375,y:868,t:1527023597774};\\\", \\\"{x:1376,y:868,t:1527023598152};\\\", \\\"{x:1376,y:867,t:1527023598176};\\\", \\\"{x:1377,y:866,t:1527023598191};\\\", \\\"{x:1377,y:869,t:1527023598353};\\\", \\\"{x:1375,y:874,t:1527023598360};\\\", \\\"{x:1373,y:880,t:1527023598374};\\\", \\\"{x:1367,y:891,t:1527023598391};\\\", \\\"{x:1359,y:908,t:1527023598408};\\\", \\\"{x:1356,y:917,t:1527023598424};\\\", \\\"{x:1354,y:921,t:1527023598441};\\\", \\\"{x:1354,y:922,t:1527023598458};\\\", \\\"{x:1353,y:923,t:1527023598474};\\\", \\\"{x:1353,y:920,t:1527023598608};\\\", \\\"{x:1353,y:915,t:1527023598625};\\\", \\\"{x:1355,y:906,t:1527023598641};\\\", \\\"{x:1358,y:892,t:1527023598659};\\\", \\\"{x:1365,y:872,t:1527023598675};\\\", \\\"{x:1369,y:855,t:1527023598691};\\\", \\\"{x:1372,y:843,t:1527023598708};\\\", \\\"{x:1375,y:836,t:1527023598724};\\\", \\\"{x:1376,y:833,t:1527023598741};\\\", \\\"{x:1376,y:830,t:1527023598758};\\\", \\\"{x:1377,y:829,t:1527023598774};\\\", \\\"{x:1378,y:827,t:1527023598791};\\\", \\\"{x:1380,y:832,t:1527023598880};\\\", \\\"{x:1381,y:839,t:1527023598891};\\\", \\\"{x:1386,y:856,t:1527023598909};\\\", \\\"{x:1391,y:873,t:1527023598925};\\\", \\\"{x:1398,y:893,t:1527023598941};\\\", \\\"{x:1403,y:903,t:1527023598959};\\\", \\\"{x:1407,y:911,t:1527023598974};\\\", \\\"{x:1409,y:915,t:1527023598992};\\\", \\\"{x:1410,y:916,t:1527023599009};\\\", \\\"{x:1409,y:916,t:1527023599151};\\\", \\\"{x:1404,y:916,t:1527023599159};\\\", \\\"{x:1397,y:916,t:1527023599175};\\\", \\\"{x:1383,y:916,t:1527023599192};\\\", \\\"{x:1359,y:916,t:1527023599208};\\\", \\\"{x:1343,y:916,t:1527023599225};\\\", \\\"{x:1329,y:916,t:1527023599241};\\\", \\\"{x:1318,y:916,t:1527023599259};\\\", \\\"{x:1313,y:916,t:1527023599275};\\\", \\\"{x:1311,y:916,t:1527023599291};\\\", \\\"{x:1310,y:916,t:1527023599308};\\\", \\\"{x:1309,y:914,t:1527023599424};\\\", \\\"{x:1309,y:912,t:1527023599432};\\\", \\\"{x:1309,y:910,t:1527023599441};\\\", \\\"{x:1310,y:905,t:1527023599459};\\\", \\\"{x:1312,y:899,t:1527023599475};\\\", \\\"{x:1316,y:890,t:1527023599491};\\\", \\\"{x:1325,y:879,t:1527023599509};\\\", \\\"{x:1335,y:867,t:1527023599526};\\\", \\\"{x:1341,y:860,t:1527023599541};\\\", \\\"{x:1346,y:854,t:1527023599558};\\\", \\\"{x:1353,y:850,t:1527023599576};\\\", \\\"{x:1362,y:844,t:1527023599591};\\\", \\\"{x:1375,y:838,t:1527023599608};\\\", \\\"{x:1384,y:834,t:1527023599625};\\\", \\\"{x:1389,y:833,t:1527023599641};\\\", \\\"{x:1394,y:833,t:1527023599658};\\\", \\\"{x:1399,y:832,t:1527023599675};\\\", \\\"{x:1402,y:832,t:1527023599692};\\\", \\\"{x:1407,y:834,t:1527023599708};\\\", \\\"{x:1412,y:839,t:1527023599725};\\\", \\\"{x:1420,y:852,t:1527023599742};\\\", \\\"{x:1431,y:867,t:1527023599758};\\\", \\\"{x:1438,y:884,t:1527023599775};\\\", \\\"{x:1448,y:900,t:1527023599792};\\\", \\\"{x:1451,y:905,t:1527023599808};\\\", \\\"{x:1451,y:906,t:1527023599825};\\\", \\\"{x:1451,y:907,t:1527023599847};\\\", \\\"{x:1451,y:908,t:1527023599863};\\\", \\\"{x:1451,y:909,t:1527023599875};\\\", \\\"{x:1451,y:911,t:1527023599892};\\\", \\\"{x:1447,y:911,t:1527023599908};\\\", \\\"{x:1434,y:908,t:1527023599925};\\\", \\\"{x:1419,y:903,t:1527023599942};\\\", \\\"{x:1403,y:897,t:1527023599959};\\\", \\\"{x:1387,y:889,t:1527023599975};\\\", \\\"{x:1370,y:872,t:1527023599991};\\\", \\\"{x:1365,y:863,t:1527023600008};\\\", \\\"{x:1363,y:848,t:1527023600025};\\\", \\\"{x:1360,y:836,t:1527023600043};\\\", \\\"{x:1358,y:821,t:1527023600058};\\\", \\\"{x:1358,y:809,t:1527023600075};\\\", \\\"{x:1356,y:792,t:1527023600092};\\\", \\\"{x:1355,y:778,t:1527023600108};\\\", \\\"{x:1355,y:769,t:1527023600125};\\\", \\\"{x:1353,y:757,t:1527023600142};\\\", \\\"{x:1350,y:749,t:1527023600158};\\\", \\\"{x:1349,y:743,t:1527023600175};\\\", \\\"{x:1348,y:738,t:1527023600192};\\\", \\\"{x:1347,y:737,t:1527023600208};\\\", \\\"{x:1344,y:737,t:1527023600239};\\\", \\\"{x:1338,y:747,t:1527023600248};\\\", \\\"{x:1335,y:757,t:1527023600258};\\\", \\\"{x:1323,y:786,t:1527023600275};\\\", \\\"{x:1304,y:825,t:1527023600292};\\\", \\\"{x:1288,y:857,t:1527023600309};\\\", \\\"{x:1278,y:879,t:1527023600325};\\\", \\\"{x:1268,y:903,t:1527023600342};\\\", \\\"{x:1261,y:924,t:1527023600358};\\\", \\\"{x:1258,y:937,t:1527023600376};\\\", \\\"{x:1257,y:944,t:1527023600391};\\\", \\\"{x:1258,y:941,t:1527023600448};\\\", \\\"{x:1263,y:931,t:1527023600460};\\\", \\\"{x:1274,y:911,t:1527023600476};\\\", \\\"{x:1287,y:886,t:1527023600492};\\\", \\\"{x:1301,y:853,t:1527023600509};\\\", \\\"{x:1319,y:816,t:1527023600525};\\\", \\\"{x:1333,y:776,t:1527023600542};\\\", \\\"{x:1344,y:741,t:1527023600559};\\\", \\\"{x:1350,y:720,t:1527023600575};\\\", \\\"{x:1359,y:703,t:1527023600592};\\\", \\\"{x:1361,y:698,t:1527023600609};\\\", \\\"{x:1362,y:697,t:1527023600625};\\\", \\\"{x:1364,y:697,t:1527023600672};\\\", \\\"{x:1365,y:700,t:1527023600680};\\\", \\\"{x:1369,y:707,t:1527023600692};\\\", \\\"{x:1376,y:729,t:1527023600709};\\\", \\\"{x:1386,y:752,t:1527023600725};\\\", \\\"{x:1396,y:781,t:1527023600742};\\\", \\\"{x:1413,y:825,t:1527023600760};\\\", \\\"{x:1418,y:836,t:1527023600775};\\\", \\\"{x:1429,y:867,t:1527023600793};\\\", \\\"{x:1434,y:880,t:1527023600810};\\\", \\\"{x:1439,y:892,t:1527023600825};\\\", \\\"{x:1440,y:897,t:1527023600842};\\\", \\\"{x:1440,y:898,t:1527023600944};\\\", \\\"{x:1440,y:899,t:1527023600959};\\\", \\\"{x:1439,y:900,t:1527023600976};\\\", \\\"{x:1434,y:898,t:1527023600992};\\\", \\\"{x:1422,y:889,t:1527023601009};\\\", \\\"{x:1408,y:873,t:1527023601027};\\\", \\\"{x:1392,y:856,t:1527023601043};\\\", \\\"{x:1381,y:843,t:1527023601059};\\\", \\\"{x:1369,y:827,t:1527023601076};\\\", \\\"{x:1358,y:810,t:1527023601092};\\\", \\\"{x:1349,y:795,t:1527023601109};\\\", \\\"{x:1343,y:782,t:1527023601127};\\\", \\\"{x:1336,y:766,t:1527023601143};\\\", \\\"{x:1327,y:745,t:1527023601159};\\\", \\\"{x:1315,y:703,t:1527023601176};\\\", \\\"{x:1307,y:678,t:1527023601192};\\\", \\\"{x:1295,y:649,t:1527023601210};\\\", \\\"{x:1287,y:625,t:1527023601226};\\\", \\\"{x:1284,y:610,t:1527023601242};\\\", \\\"{x:1282,y:604,t:1527023601259};\\\", \\\"{x:1281,y:603,t:1527023601277};\\\", \\\"{x:1282,y:604,t:1527023601319};\\\", \\\"{x:1285,y:607,t:1527023601328};\\\", \\\"{x:1288,y:613,t:1527023601342};\\\", \\\"{x:1295,y:625,t:1527023601359};\\\", \\\"{x:1307,y:646,t:1527023601375};\\\", \\\"{x:1316,y:658,t:1527023601392};\\\", \\\"{x:1322,y:664,t:1527023601410};\\\", \\\"{x:1325,y:667,t:1527023601427};\\\", \\\"{x:1326,y:673,t:1527023601443};\\\", \\\"{x:1328,y:675,t:1527023601459};\\\", \\\"{x:1329,y:677,t:1527023601476};\\\", \\\"{x:1329,y:679,t:1527023601496};\\\", \\\"{x:1332,y:682,t:1527023601509};\\\", \\\"{x:1335,y:686,t:1527023601526};\\\", \\\"{x:1337,y:689,t:1527023601542};\\\", \\\"{x:1344,y:698,t:1527023601559};\\\", \\\"{x:1350,y:707,t:1527023601576};\\\", \\\"{x:1355,y:717,t:1527023601593};\\\", \\\"{x:1360,y:726,t:1527023601610};\\\", \\\"{x:1363,y:738,t:1527023601627};\\\", \\\"{x:1364,y:749,t:1527023601644};\\\", \\\"{x:1364,y:763,t:1527023601659};\\\", \\\"{x:1363,y:777,t:1527023601677};\\\", \\\"{x:1360,y:794,t:1527023601693};\\\", \\\"{x:1356,y:806,t:1527023601709};\\\", \\\"{x:1349,y:820,t:1527023601726};\\\", \\\"{x:1342,y:836,t:1527023601743};\\\", \\\"{x:1331,y:854,t:1527023601760};\\\", \\\"{x:1317,y:876,t:1527023601776};\\\", \\\"{x:1306,y:890,t:1527023601793};\\\", \\\"{x:1295,y:903,t:1527023601809};\\\", \\\"{x:1288,y:912,t:1527023601827};\\\", \\\"{x:1285,y:917,t:1527023601843};\\\", \\\"{x:1283,y:921,t:1527023601859};\\\", \\\"{x:1282,y:923,t:1527023601876};\\\", \\\"{x:1281,y:922,t:1527023601992};\\\", \\\"{x:1281,y:921,t:1527023602095};\\\", \\\"{x:1278,y:921,t:1527023602112};\\\", \\\"{x:1273,y:921,t:1527023602126};\\\", \\\"{x:1264,y:921,t:1527023602143};\\\", \\\"{x:1258,y:922,t:1527023602159};\\\", \\\"{x:1256,y:922,t:1527023602176};\\\", \\\"{x:1254,y:922,t:1527023602200};\\\", \\\"{x:1254,y:921,t:1527023602209};\\\", \\\"{x:1254,y:916,t:1527023602227};\\\", \\\"{x:1254,y:912,t:1527023602244};\\\", \\\"{x:1254,y:904,t:1527023602259};\\\", \\\"{x:1258,y:892,t:1527023602276};\\\", \\\"{x:1259,y:886,t:1527023602294};\\\", \\\"{x:1262,y:881,t:1527023602310};\\\", \\\"{x:1263,y:878,t:1527023602326};\\\", \\\"{x:1263,y:877,t:1527023602343};\\\", \\\"{x:1264,y:877,t:1527023602359};\\\", \\\"{x:1264,y:874,t:1527023602440};\\\", \\\"{x:1265,y:870,t:1527023602448};\\\", \\\"{x:1267,y:864,t:1527023602460};\\\", \\\"{x:1271,y:853,t:1527023602476};\\\", \\\"{x:1277,y:835,t:1527023602493};\\\", \\\"{x:1288,y:814,t:1527023602510};\\\", \\\"{x:1297,y:796,t:1527023602527};\\\", \\\"{x:1310,y:770,t:1527023602543};\\\", \\\"{x:1334,y:732,t:1527023602560};\\\", \\\"{x:1345,y:712,t:1527023602577};\\\", \\\"{x:1352,y:698,t:1527023602594};\\\", \\\"{x:1357,y:690,t:1527023602611};\\\", \\\"{x:1360,y:685,t:1527023602626};\\\", \\\"{x:1361,y:684,t:1527023602643};\\\", \\\"{x:1363,y:691,t:1527023602776};\\\", \\\"{x:1370,y:714,t:1527023602793};\\\", \\\"{x:1377,y:742,t:1527023602810};\\\", \\\"{x:1384,y:764,t:1527023602826};\\\", \\\"{x:1393,y:787,t:1527023602843};\\\", \\\"{x:1400,y:804,t:1527023602861};\\\", \\\"{x:1408,y:821,t:1527023602876};\\\", \\\"{x:1414,y:835,t:1527023602894};\\\", \\\"{x:1418,y:848,t:1527023602910};\\\", \\\"{x:1420,y:858,t:1527023602927};\\\", \\\"{x:1423,y:867,t:1527023602944};\\\", \\\"{x:1427,y:876,t:1527023602960};\\\", \\\"{x:1428,y:879,t:1527023602977};\\\", \\\"{x:1429,y:883,t:1527023602994};\\\", \\\"{x:1431,y:885,t:1527023603011};\\\", \\\"{x:1432,y:889,t:1527023603027};\\\", \\\"{x:1434,y:891,t:1527023603043};\\\", \\\"{x:1436,y:895,t:1527023603061};\\\", \\\"{x:1438,y:898,t:1527023603077};\\\", \\\"{x:1439,y:900,t:1527023603094};\\\", \\\"{x:1440,y:901,t:1527023603110};\\\", \\\"{x:1442,y:903,t:1527023603127};\\\", \\\"{x:1443,y:904,t:1527023603143};\\\", \\\"{x:1438,y:904,t:1527023603280};\\\", \\\"{x:1428,y:904,t:1527023603294};\\\", \\\"{x:1401,y:904,t:1527023603311};\\\", \\\"{x:1353,y:904,t:1527023603328};\\\", \\\"{x:1327,y:904,t:1527023603344};\\\", \\\"{x:1299,y:904,t:1527023603360};\\\", \\\"{x:1276,y:907,t:1527023603377};\\\", \\\"{x:1251,y:919,t:1527023603393};\\\", \\\"{x:1236,y:926,t:1527023603410};\\\", \\\"{x:1233,y:928,t:1527023603428};\\\", \\\"{x:1232,y:929,t:1527023603444};\\\", \\\"{x:1231,y:928,t:1527023603528};\\\", \\\"{x:1234,y:914,t:1527023603544};\\\", \\\"{x:1239,y:896,t:1527023603560};\\\", \\\"{x:1247,y:873,t:1527023603577};\\\", \\\"{x:1256,y:852,t:1527023603594};\\\", \\\"{x:1267,y:829,t:1527023603611};\\\", \\\"{x:1278,y:808,t:1527023603628};\\\", \\\"{x:1290,y:784,t:1527023603644};\\\", \\\"{x:1302,y:755,t:1527023603660};\\\", \\\"{x:1316,y:722,t:1527023603678};\\\", \\\"{x:1324,y:703,t:1527023603695};\\\", \\\"{x:1330,y:690,t:1527023603711};\\\", \\\"{x:1333,y:682,t:1527023603728};\\\", \\\"{x:1335,y:678,t:1527023603744};\\\", \\\"{x:1336,y:674,t:1527023603760};\\\", \\\"{x:1336,y:672,t:1527023603777};\\\", \\\"{x:1337,y:671,t:1527023603794};\\\", \\\"{x:1338,y:671,t:1527023603895};\\\", \\\"{x:1339,y:673,t:1527023603910};\\\", \\\"{x:1343,y:688,t:1527023603928};\\\", \\\"{x:1348,y:700,t:1527023603944};\\\", \\\"{x:1350,y:709,t:1527023603961};\\\", \\\"{x:1353,y:721,t:1527023603978};\\\", \\\"{x:1359,y:732,t:1527023603994};\\\", \\\"{x:1363,y:738,t:1527023604010};\\\", \\\"{x:1365,y:745,t:1527023604028};\\\", \\\"{x:1369,y:753,t:1527023604044};\\\", \\\"{x:1373,y:762,t:1527023604060};\\\", \\\"{x:1376,y:773,t:1527023604078};\\\", \\\"{x:1384,y:785,t:1527023604094};\\\", \\\"{x:1393,y:802,t:1527023604110};\\\", \\\"{x:1410,y:825,t:1527023604127};\\\", \\\"{x:1419,y:840,t:1527023604144};\\\", \\\"{x:1425,y:850,t:1527023604160};\\\", \\\"{x:1429,y:857,t:1527023604177};\\\", \\\"{x:1433,y:863,t:1527023604195};\\\", \\\"{x:1436,y:866,t:1527023604210};\\\", \\\"{x:1437,y:870,t:1527023604228};\\\", \\\"{x:1439,y:873,t:1527023604244};\\\", \\\"{x:1439,y:874,t:1527023604271};\\\", \\\"{x:1439,y:875,t:1527023604416};\\\", \\\"{x:1437,y:875,t:1527023604428};\\\", \\\"{x:1425,y:875,t:1527023604444};\\\", \\\"{x:1405,y:874,t:1527023604462};\\\", \\\"{x:1381,y:871,t:1527023604477};\\\", \\\"{x:1343,y:870,t:1527023604495};\\\", \\\"{x:1283,y:872,t:1527023604512};\\\", \\\"{x:1251,y:882,t:1527023604528};\\\", \\\"{x:1231,y:891,t:1527023604545};\\\", \\\"{x:1222,y:894,t:1527023604561};\\\", \\\"{x:1218,y:897,t:1527023604578};\\\", \\\"{x:1218,y:898,t:1527023604601};\\\", \\\"{x:1218,y:899,t:1527023604624};\\\", \\\"{x:1218,y:900,t:1527023604632};\\\", \\\"{x:1218,y:902,t:1527023604644};\\\", \\\"{x:1219,y:903,t:1527023604662};\\\", \\\"{x:1220,y:906,t:1527023604678};\\\", \\\"{x:1220,y:907,t:1527023604696};\\\", \\\"{x:1221,y:909,t:1527023604712};\\\", \\\"{x:1222,y:912,t:1527023604728};\\\", \\\"{x:1223,y:913,t:1527023604752};\\\", \\\"{x:1224,y:914,t:1527023604848};\\\", \\\"{x:1225,y:914,t:1527023604864};\\\", \\\"{x:1226,y:912,t:1527023604879};\\\", \\\"{x:1231,y:904,t:1527023604894};\\\", \\\"{x:1244,y:881,t:1527023604911};\\\", \\\"{x:1254,y:857,t:1527023604928};\\\", \\\"{x:1265,y:836,t:1527023604945};\\\", \\\"{x:1275,y:816,t:1527023604961};\\\", \\\"{x:1283,y:797,t:1527023604979};\\\", \\\"{x:1290,y:777,t:1527023604994};\\\", \\\"{x:1296,y:759,t:1527023605011};\\\", \\\"{x:1301,y:743,t:1527023605028};\\\", \\\"{x:1306,y:724,t:1527023605045};\\\", \\\"{x:1311,y:712,t:1527023605062};\\\", \\\"{x:1314,y:706,t:1527023605078};\\\", \\\"{x:1315,y:704,t:1527023605095};\\\", \\\"{x:1316,y:701,t:1527023605112};\\\", \\\"{x:1317,y:700,t:1527023605344};\\\", \\\"{x:1318,y:700,t:1527023605352};\\\", \\\"{x:1321,y:700,t:1527023605361};\\\", \\\"{x:1324,y:700,t:1527023605378};\\\", \\\"{x:1331,y:700,t:1527023605394};\\\", \\\"{x:1334,y:699,t:1527023605412};\\\", \\\"{x:1335,y:699,t:1527023605428};\\\", \\\"{x:1336,y:699,t:1527023605519};\\\", \\\"{x:1337,y:699,t:1527023605543};\\\", \\\"{x:1339,y:699,t:1527023605552};\\\", \\\"{x:1340,y:701,t:1527023605562};\\\", \\\"{x:1340,y:702,t:1527023605579};\\\", \\\"{x:1341,y:704,t:1527023605595};\\\", \\\"{x:1343,y:706,t:1527023605611};\\\", \\\"{x:1343,y:707,t:1527023605688};\\\", \\\"{x:1344,y:708,t:1527023605696};\\\", \\\"{x:1345,y:710,t:1527023605711};\\\", \\\"{x:1347,y:713,t:1527023605728};\\\", \\\"{x:1350,y:716,t:1527023605746};\\\", \\\"{x:1353,y:722,t:1527023605762};\\\", \\\"{x:1357,y:730,t:1527023605779};\\\", \\\"{x:1363,y:740,t:1527023605796};\\\", \\\"{x:1367,y:747,t:1527023605811};\\\", \\\"{x:1372,y:753,t:1527023605828};\\\", \\\"{x:1378,y:762,t:1527023605845};\\\", \\\"{x:1383,y:770,t:1527023605862};\\\", \\\"{x:1387,y:777,t:1527023605879};\\\", \\\"{x:1395,y:789,t:1527023605896};\\\", \\\"{x:1398,y:796,t:1527023605911};\\\", \\\"{x:1402,y:802,t:1527023605929};\\\", \\\"{x:1403,y:806,t:1527023605946};\\\", \\\"{x:1406,y:813,t:1527023605962};\\\", \\\"{x:1410,y:818,t:1527023605978};\\\", \\\"{x:1412,y:824,t:1527023605996};\\\", \\\"{x:1414,y:827,t:1527023606012};\\\", \\\"{x:1416,y:829,t:1527023606028};\\\", \\\"{x:1417,y:833,t:1527023606045};\\\", \\\"{x:1419,y:839,t:1527023606061};\\\", \\\"{x:1423,y:845,t:1527023606079};\\\", \\\"{x:1426,y:854,t:1527023606096};\\\", \\\"{x:1428,y:859,t:1527023606112};\\\", \\\"{x:1429,y:862,t:1527023606129};\\\", \\\"{x:1432,y:868,t:1527023606145};\\\", \\\"{x:1434,y:872,t:1527023606163};\\\", \\\"{x:1438,y:880,t:1527023606179};\\\", \\\"{x:1439,y:883,t:1527023606196};\\\", \\\"{x:1442,y:888,t:1527023606212};\\\", \\\"{x:1445,y:891,t:1527023606229};\\\", \\\"{x:1446,y:893,t:1527023606245};\\\", \\\"{x:1447,y:896,t:1527023606263};\\\", \\\"{x:1450,y:899,t:1527023606279};\\\", \\\"{x:1454,y:903,t:1527023606295};\\\", \\\"{x:1455,y:904,t:1527023606312};\\\", \\\"{x:1457,y:905,t:1527023606328};\\\", \\\"{x:1458,y:907,t:1527023606345};\\\", \\\"{x:1459,y:908,t:1527023606362};\\\", \\\"{x:1458,y:908,t:1527023606552};\\\", \\\"{x:1456,y:908,t:1527023606568};\\\", \\\"{x:1453,y:908,t:1527023606578};\\\", \\\"{x:1446,y:908,t:1527023606596};\\\", \\\"{x:1431,y:906,t:1527023606613};\\\", \\\"{x:1406,y:902,t:1527023606629};\\\", \\\"{x:1377,y:902,t:1527023606646};\\\", \\\"{x:1347,y:899,t:1527023606662};\\\", \\\"{x:1317,y:899,t:1527023606679};\\\", \\\"{x:1283,y:899,t:1527023606695};\\\", \\\"{x:1264,y:899,t:1527023606712};\\\", \\\"{x:1256,y:899,t:1527023606729};\\\", \\\"{x:1252,y:899,t:1527023606745};\\\", \\\"{x:1250,y:900,t:1527023606762};\\\", \\\"{x:1248,y:901,t:1527023606780};\\\", \\\"{x:1248,y:902,t:1527023606799};\\\", \\\"{x:1248,y:903,t:1527023606815};\\\", \\\"{x:1248,y:902,t:1527023606912};\\\", \\\"{x:1249,y:890,t:1527023606929};\\\", \\\"{x:1256,y:874,t:1527023606946};\\\", \\\"{x:1268,y:848,t:1527023606963};\\\", \\\"{x:1278,y:825,t:1527023606980};\\\", \\\"{x:1289,y:794,t:1527023606996};\\\", \\\"{x:1303,y:756,t:1527023607013};\\\", \\\"{x:1313,y:724,t:1527023607030};\\\", \\\"{x:1321,y:707,t:1527023607046};\\\", \\\"{x:1326,y:700,t:1527023607063};\\\", \\\"{x:1328,y:698,t:1527023607080};\\\", \\\"{x:1329,y:698,t:1527023607096};\\\", \\\"{x:1331,y:698,t:1527023607113};\\\", \\\"{x:1347,y:730,t:1527023607129};\\\", \\\"{x:1381,y:792,t:1527023607146};\\\", \\\"{x:1418,y:850,t:1527023607162};\\\", \\\"{x:1451,y:891,t:1527023607180};\\\", \\\"{x:1477,y:914,t:1527023607196};\\\", \\\"{x:1492,y:930,t:1527023607213};\\\", \\\"{x:1505,y:939,t:1527023607230};\\\", \\\"{x:1510,y:944,t:1527023607246};\\\", \\\"{x:1512,y:947,t:1527023607262};\\\", \\\"{x:1513,y:949,t:1527023607280};\\\", \\\"{x:1511,y:950,t:1527023607433};\\\", \\\"{x:1501,y:950,t:1527023607446};\\\", \\\"{x:1480,y:950,t:1527023607463};\\\", \\\"{x:1442,y:944,t:1527023607480};\\\", \\\"{x:1404,y:938,t:1527023607496};\\\", \\\"{x:1370,y:931,t:1527023607513};\\\", \\\"{x:1335,y:928,t:1527023607531};\\\", \\\"{x:1313,y:924,t:1527023607547};\\\", \\\"{x:1300,y:924,t:1527023607563};\\\", \\\"{x:1296,y:923,t:1527023607580};\\\", \\\"{x:1295,y:923,t:1527023607597};\\\", \\\"{x:1295,y:922,t:1527023607729};\\\", \\\"{x:1295,y:916,t:1527023607747};\\\", \\\"{x:1298,y:900,t:1527023607764};\\\", \\\"{x:1305,y:873,t:1527023607780};\\\", \\\"{x:1316,y:831,t:1527023607798};\\\", \\\"{x:1325,y:798,t:1527023607813};\\\", \\\"{x:1330,y:777,t:1527023607830};\\\", \\\"{x:1339,y:761,t:1527023607848};\\\", \\\"{x:1344,y:752,t:1527023607863};\\\", \\\"{x:1348,y:738,t:1527023607881};\\\", \\\"{x:1353,y:728,t:1527023607896};\\\", \\\"{x:1355,y:720,t:1527023607914};\\\", \\\"{x:1357,y:715,t:1527023607930};\\\", \\\"{x:1357,y:714,t:1527023607947};\\\", \\\"{x:1357,y:713,t:1527023607964};\\\", \\\"{x:1358,y:713,t:1527023608008};\\\", \\\"{x:1359,y:713,t:1527023608016};\\\", \\\"{x:1363,y:718,t:1527023608030};\\\", \\\"{x:1375,y:745,t:1527023608047};\\\", \\\"{x:1404,y:795,t:1527023608063};\\\", \\\"{x:1447,y:861,t:1527023608080};\\\", \\\"{x:1471,y:891,t:1527023608098};\\\", \\\"{x:1485,y:910,t:1527023608114};\\\", \\\"{x:1495,y:925,t:1527023608131};\\\", \\\"{x:1502,y:934,t:1527023608148};\\\", \\\"{x:1503,y:936,t:1527023608163};\\\", \\\"{x:1503,y:938,t:1527023608180};\\\", \\\"{x:1502,y:938,t:1527023608337};\\\", \\\"{x:1498,y:937,t:1527023608348};\\\", \\\"{x:1490,y:932,t:1527023608365};\\\", \\\"{x:1477,y:923,t:1527023608381};\\\", \\\"{x:1461,y:914,t:1527023608398};\\\", \\\"{x:1448,y:907,t:1527023608414};\\\", \\\"{x:1434,y:899,t:1527023608430};\\\", \\\"{x:1423,y:893,t:1527023608447};\\\", \\\"{x:1414,y:887,t:1527023608465};\\\", \\\"{x:1412,y:881,t:1527023608480};\\\", \\\"{x:1407,y:872,t:1527023608497};\\\", \\\"{x:1402,y:860,t:1527023608514};\\\", \\\"{x:1397,y:847,t:1527023608530};\\\", \\\"{x:1392,y:836,t:1527023608548};\\\", \\\"{x:1387,y:825,t:1527023608564};\\\", \\\"{x:1384,y:813,t:1527023608581};\\\", \\\"{x:1380,y:797,t:1527023608597};\\\", \\\"{x:1374,y:780,t:1527023608615};\\\", \\\"{x:1367,y:765,t:1527023608631};\\\", \\\"{x:1363,y:756,t:1527023608647};\\\", \\\"{x:1357,y:741,t:1527023608664};\\\", \\\"{x:1351,y:726,t:1527023608680};\\\", \\\"{x:1347,y:712,t:1527023608697};\\\", \\\"{x:1345,y:705,t:1527023608714};\\\", \\\"{x:1343,y:702,t:1527023608731};\\\", \\\"{x:1343,y:700,t:1527023608747};\\\", \\\"{x:1342,y:700,t:1527023608817};\\\", \\\"{x:1341,y:700,t:1527023608831};\\\", \\\"{x:1341,y:712,t:1527023608847};\\\", \\\"{x:1347,y:740,t:1527023608865};\\\", \\\"{x:1355,y:761,t:1527023608880};\\\", \\\"{x:1366,y:786,t:1527023608898};\\\", \\\"{x:1377,y:810,t:1527023608914};\\\", \\\"{x:1383,y:829,t:1527023608931};\\\", \\\"{x:1393,y:844,t:1527023608948};\\\", \\\"{x:1399,y:855,t:1527023608964};\\\", \\\"{x:1403,y:863,t:1527023608981};\\\", \\\"{x:1407,y:868,t:1527023608997};\\\", \\\"{x:1407,y:871,t:1527023609015};\\\", \\\"{x:1409,y:873,t:1527023609032};\\\", \\\"{x:1409,y:875,t:1527023609047};\\\", \\\"{x:1411,y:879,t:1527023609064};\\\", \\\"{x:1413,y:883,t:1527023609080};\\\", \\\"{x:1414,y:886,t:1527023609098};\\\", \\\"{x:1417,y:890,t:1527023609114};\\\", \\\"{x:1417,y:891,t:1527023609131};\\\", \\\"{x:1418,y:893,t:1527023609147};\\\", \\\"{x:1419,y:896,t:1527023609164};\\\", \\\"{x:1419,y:897,t:1527023609181};\\\", \\\"{x:1419,y:898,t:1527023609197};\\\", \\\"{x:1419,y:901,t:1527023609215};\\\", \\\"{x:1418,y:905,t:1527023609231};\\\", \\\"{x:1411,y:908,t:1527023609247};\\\", \\\"{x:1395,y:913,t:1527023609265};\\\", \\\"{x:1382,y:915,t:1527023609281};\\\", \\\"{x:1367,y:917,t:1527023609298};\\\", \\\"{x:1356,y:918,t:1527023609314};\\\", \\\"{x:1346,y:920,t:1527023609331};\\\", \\\"{x:1342,y:920,t:1527023609347};\\\", \\\"{x:1342,y:921,t:1527023609376};\\\", \\\"{x:1342,y:920,t:1527023609448};\\\", \\\"{x:1346,y:912,t:1527023609464};\\\", \\\"{x:1351,y:903,t:1527023609481};\\\", \\\"{x:1357,y:894,t:1527023609498};\\\", \\\"{x:1362,y:887,t:1527023609514};\\\", \\\"{x:1365,y:882,t:1527023609531};\\\", \\\"{x:1368,y:879,t:1527023609548};\\\", \\\"{x:1369,y:877,t:1527023609564};\\\", \\\"{x:1371,y:881,t:1527023609639};\\\", \\\"{x:1372,y:888,t:1527023609647};\\\", \\\"{x:1380,y:908,t:1527023609664};\\\", \\\"{x:1389,y:923,t:1527023609681};\\\", \\\"{x:1397,y:934,t:1527023609698};\\\", \\\"{x:1404,y:939,t:1527023609714};\\\", \\\"{x:1407,y:944,t:1527023609731};\\\", \\\"{x:1409,y:945,t:1527023609748};\\\", \\\"{x:1409,y:946,t:1527023609784};\\\", \\\"{x:1407,y:944,t:1527023609865};\\\", \\\"{x:1399,y:939,t:1527023609881};\\\", \\\"{x:1388,y:937,t:1527023609898};\\\", \\\"{x:1367,y:933,t:1527023609914};\\\", \\\"{x:1345,y:930,t:1527023609931};\\\", \\\"{x:1324,y:925,t:1527023609949};\\\", \\\"{x:1308,y:919,t:1527023609965};\\\", \\\"{x:1299,y:913,t:1527023609982};\\\", \\\"{x:1295,y:903,t:1527023609999};\\\", \\\"{x:1293,y:886,t:1527023610015};\\\", \\\"{x:1293,y:862,t:1527023610031};\\\", \\\"{x:1298,y:821,t:1527023610048};\\\", \\\"{x:1303,y:798,t:1527023610064};\\\", \\\"{x:1310,y:773,t:1527023610081};\\\", \\\"{x:1321,y:745,t:1527023610099};\\\", \\\"{x:1332,y:723,t:1527023610116};\\\", \\\"{x:1341,y:704,t:1527023610132};\\\", \\\"{x:1343,y:700,t:1527023610148};\\\", \\\"{x:1344,y:699,t:1527023610165};\\\", \\\"{x:1345,y:699,t:1527023610184};\\\", \\\"{x:1347,y:700,t:1527023610198};\\\", \\\"{x:1353,y:717,t:1527023610216};\\\", \\\"{x:1367,y:751,t:1527023610232};\\\", \\\"{x:1399,y:834,t:1527023610248};\\\", \\\"{x:1419,y:881,t:1527023610264};\\\", \\\"{x:1433,y:912,t:1527023610281};\\\", \\\"{x:1443,y:932,t:1527023610298};\\\", \\\"{x:1448,y:944,t:1527023610315};\\\", \\\"{x:1450,y:949,t:1527023610331};\\\", \\\"{x:1450,y:951,t:1527023610348};\\\", \\\"{x:1450,y:946,t:1527023610721};\\\", \\\"{x:1450,y:938,t:1527023610731};\\\", \\\"{x:1445,y:921,t:1527023610748};\\\", \\\"{x:1436,y:895,t:1527023610766};\\\", \\\"{x:1422,y:866,t:1527023610782};\\\", \\\"{x:1412,y:846,t:1527023610799};\\\", \\\"{x:1402,y:825,t:1527023610816};\\\", \\\"{x:1367,y:749,t:1527023610833};\\\", \\\"{x:1336,y:665,t:1527023610849};\\\", \\\"{x:1302,y:597,t:1527023610865};\\\", \\\"{x:1288,y:569,t:1527023610882};\\\", \\\"{x:1284,y:564,t:1527023610898};\\\", \\\"{x:1283,y:563,t:1527023610916};\\\", \\\"{x:1283,y:568,t:1527023610969};\\\", \\\"{x:1283,y:583,t:1527023610982};\\\", \\\"{x:1283,y:625,t:1527023610999};\\\", \\\"{x:1284,y:668,t:1527023611016};\\\", \\\"{x:1286,y:715,t:1527023611032};\\\", \\\"{x:1286,y:734,t:1527023611049};\\\", \\\"{x:1286,y:737,t:1527023611065};\\\", \\\"{x:1287,y:737,t:1527023611113};\\\", \\\"{x:1291,y:729,t:1527023611121};\\\", \\\"{x:1291,y:719,t:1527023611133};\\\", \\\"{x:1294,y:703,t:1527023611149};\\\", \\\"{x:1296,y:694,t:1527023611166};\\\", \\\"{x:1298,y:691,t:1527023611182};\\\", \\\"{x:1300,y:691,t:1527023611198};\\\", \\\"{x:1310,y:702,t:1527023611215};\\\", \\\"{x:1340,y:759,t:1527023611233};\\\", \\\"{x:1365,y:805,t:1527023611249};\\\", \\\"{x:1388,y:848,t:1527023611266};\\\", \\\"{x:1418,y:893,t:1527023611282};\\\", \\\"{x:1436,y:925,t:1527023611298};\\\", \\\"{x:1447,y:940,t:1527023611316};\\\", \\\"{x:1449,y:943,t:1527023611332};\\\", \\\"{x:1449,y:944,t:1527023611384};\\\", \\\"{x:1449,y:945,t:1527023611408};\\\", \\\"{x:1447,y:945,t:1527023611417};\\\", \\\"{x:1440,y:945,t:1527023611432};\\\", \\\"{x:1429,y:945,t:1527023611448};\\\", \\\"{x:1410,y:945,t:1527023611466};\\\", \\\"{x:1388,y:941,t:1527023611483};\\\", \\\"{x:1364,y:934,t:1527023611499};\\\", \\\"{x:1344,y:925,t:1527023611515};\\\", \\\"{x:1335,y:918,t:1527023611533};\\\", \\\"{x:1329,y:912,t:1527023611550};\\\", \\\"{x:1327,y:909,t:1527023611566};\\\", \\\"{x:1326,y:908,t:1527023611582};\\\", \\\"{x:1327,y:908,t:1527023611616};\\\", \\\"{x:1332,y:908,t:1527023611632};\\\", \\\"{x:1343,y:913,t:1527023611649};\\\", \\\"{x:1358,y:921,t:1527023611666};\\\", \\\"{x:1370,y:927,t:1527023611683};\\\", \\\"{x:1378,y:929,t:1527023611699};\\\", \\\"{x:1380,y:929,t:1527023611716};\\\", \\\"{x:1381,y:929,t:1527023611753};\\\", \\\"{x:1381,y:921,t:1527023611765};\\\", \\\"{x:1377,y:894,t:1527023611782};\\\", \\\"{x:1358,y:855,t:1527023611799};\\\", \\\"{x:1339,y:806,t:1527023611816};\\\", \\\"{x:1301,y:726,t:1527023611833};\\\", \\\"{x:1286,y:706,t:1527023611849};\\\", \\\"{x:1285,y:706,t:1527023611865};\\\", \\\"{x:1289,y:712,t:1527023611897};\\\", \\\"{x:1300,y:727,t:1527023611905};\\\", \\\"{x:1319,y:753,t:1527023611916};\\\", \\\"{x:1358,y:802,t:1527023611932};\\\", \\\"{x:1384,y:843,t:1527023611950};\\\", \\\"{x:1399,y:871,t:1527023611967};\\\", \\\"{x:1406,y:885,t:1527023611982};\\\", \\\"{x:1408,y:890,t:1527023612000};\\\", \\\"{x:1408,y:891,t:1527023612016};\\\", \\\"{x:1399,y:892,t:1527023612032};\\\", \\\"{x:1367,y:880,t:1527023612049};\\\", \\\"{x:1301,y:835,t:1527023612066};\\\", \\\"{x:1218,y:782,t:1527023612083};\\\", \\\"{x:1125,y:727,t:1527023612099};\\\", \\\"{x:1038,y:682,t:1527023612116};\\\", \\\"{x:982,y:655,t:1527023612132};\\\", \\\"{x:946,y:639,t:1527023612149};\\\", \\\"{x:942,y:638,t:1527023612166};\\\", \\\"{x:941,y:638,t:1527023612183};\\\", \\\"{x:944,y:657,t:1527023612199};\\\", \\\"{x:974,y:722,t:1527023612216};\\\", \\\"{x:1006,y:782,t:1527023612233};\\\", \\\"{x:1043,y:842,t:1527023612249};\\\", \\\"{x:1077,y:875,t:1527023612266};\\\", \\\"{x:1108,y:898,t:1527023612282};\\\", \\\"{x:1131,y:914,t:1527023612299};\\\", \\\"{x:1147,y:922,t:1527023612317};\\\", \\\"{x:1149,y:923,t:1527023612332};\\\", \\\"{x:1146,y:923,t:1527023612425};\\\", \\\"{x:1141,y:923,t:1527023612433};\\\", \\\"{x:1125,y:921,t:1527023612449};\\\", \\\"{x:1103,y:918,t:1527023612465};\\\", \\\"{x:1085,y:915,t:1527023612482};\\\", \\\"{x:1064,y:911,t:1527023612498};\\\", \\\"{x:1042,y:909,t:1527023612516};\\\", \\\"{x:1023,y:907,t:1527023612532};\\\", \\\"{x:1010,y:907,t:1527023612548};\\\", \\\"{x:1009,y:907,t:1527023612566};\\\", \\\"{x:1008,y:907,t:1527023615017};\\\", \\\"{x:1001,y:907,t:1527023615035};\\\", \\\"{x:984,y:907,t:1527023615050};\\\", \\\"{x:964,y:907,t:1527023615068};\\\", \\\"{x:941,y:907,t:1527023615084};\\\", \\\"{x:912,y:906,t:1527023615100};\\\", \\\"{x:885,y:904,t:1527023615117};\\\", \\\"{x:863,y:900,t:1527023615134};\\\", \\\"{x:844,y:895,t:1527023615150};\\\", \\\"{x:822,y:887,t:1527023615167};\\\", \\\"{x:781,y:868,t:1527023615184};\\\", \\\"{x:747,y:853,t:1527023615200};\\\", \\\"{x:709,y:831,t:1527023615218};\\\", \\\"{x:645,y:783,t:1527023615235};\\\", \\\"{x:563,y:723,t:1527023615251};\\\", \\\"{x:473,y:669,t:1527023615268};\\\", \\\"{x:415,y:634,t:1527023615284};\\\", \\\"{x:380,y:616,t:1527023615301};\\\", \\\"{x:365,y:609,t:1527023615327};\\\", \\\"{x:364,y:609,t:1527023615344};\\\", \\\"{x:365,y:609,t:1527023615416};\\\", \\\"{x:366,y:610,t:1527023615428};\\\", \\\"{x:371,y:613,t:1527023615444};\\\", \\\"{x:377,y:616,t:1527023615459};\\\", \\\"{x:384,y:618,t:1527023615478};\\\", \\\"{x:397,y:623,t:1527023615493};\\\", \\\"{x:412,y:626,t:1527023615510};\\\", \\\"{x:432,y:634,t:1527023615527};\\\", \\\"{x:462,y:641,t:1527023615543};\\\", \\\"{x:483,y:648,t:1527023615560};\\\", \\\"{x:503,y:653,t:1527023615576};\\\", \\\"{x:521,y:662,t:1527023615594};\\\", \\\"{x:536,y:668,t:1527023615611};\\\", \\\"{x:548,y:673,t:1527023615626};\\\", \\\"{x:555,y:676,t:1527023615644};\\\", \\\"{x:556,y:677,t:1527023615660};\\\", \\\"{x:556,y:678,t:1527023615792};\\\", \\\"{x:556,y:680,t:1527023615800};\\\", \\\"{x:556,y:683,t:1527023615810};\\\", \\\"{x:556,y:685,t:1527023615829};\\\", \\\"{x:556,y:686,t:1527023615844};\\\" ] }, { \\\"rt\\\": 13610, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 14, \\\"time_elapsed\\\": 716809, \\\"internal_node_id\\\": \\\"0.0-6.0-4.0\\\", \\\"subject\\\": \\\"QOJ6L\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"hotel\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"ends\\\", \\\"q\\\": 10, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-12 PM-11 AM-12 PM-11 AM-08 AM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:558,y:687,t:1527023618697};\\\", \\\"{x:580,y:687,t:1527023618716};\\\", \\\"{x:610,y:688,t:1527023618730};\\\", \\\"{x:645,y:688,t:1527023618746};\\\", \\\"{x:671,y:686,t:1527023618763};\\\", \\\"{x:692,y:680,t:1527023618779};\\\", \\\"{x:712,y:671,t:1527023618796};\\\", \\\"{x:719,y:665,t:1527023618813};\\\", \\\"{x:726,y:660,t:1527023618829};\\\", \\\"{x:731,y:652,t:1527023618846};\\\", \\\"{x:733,y:647,t:1527023618863};\\\", \\\"{x:735,y:642,t:1527023618879};\\\", \\\"{x:737,y:640,t:1527023618896};\\\", \\\"{x:740,y:638,t:1527023618913};\\\", \\\"{x:742,y:637,t:1527023618931};\\\", \\\"{x:745,y:636,t:1527023618946};\\\", \\\"{x:745,y:635,t:1527023618968};\\\", \\\"{x:745,y:634,t:1527023618981};\\\", \\\"{x:746,y:633,t:1527023618996};\\\", \\\"{x:748,y:632,t:1527023620449};\\\", \\\"{x:754,y:629,t:1527023620464};\\\", \\\"{x:766,y:627,t:1527023620482};\\\", \\\"{x:787,y:624,t:1527023620498};\\\", \\\"{x:810,y:620,t:1527023620514};\\\", \\\"{x:838,y:617,t:1527023620532};\\\", \\\"{x:865,y:614,t:1527023620548};\\\", \\\"{x:891,y:611,t:1527023620564};\\\", \\\"{x:914,y:608,t:1527023620581};\\\", \\\"{x:933,y:604,t:1527023620598};\\\", \\\"{x:944,y:600,t:1527023620615};\\\", \\\"{x:948,y:599,t:1527023620632};\\\", \\\"{x:950,y:598,t:1527023620647};\\\", \\\"{x:951,y:598,t:1527023621185};\\\", \\\"{x:952,y:598,t:1527023621198};\\\", \\\"{x:954,y:598,t:1527023621214};\\\", \\\"{x:955,y:599,t:1527023621232};\\\", \\\"{x:955,y:600,t:1527023621248};\\\", \\\"{x:955,y:601,t:1527023621689};\\\", \\\"{x:956,y:601,t:1527023621699};\\\", \\\"{x:957,y:601,t:1527023621737};\\\", \\\"{x:958,y:601,t:1527023621749};\\\", \\\"{x:958,y:602,t:1527023621766};\\\", \\\"{x:958,y:603,t:1527023621783};\\\", \\\"{x:959,y:604,t:1527023621799};\\\", \\\"{x:960,y:605,t:1527023621816};\\\", \\\"{x:961,y:606,t:1527023621833};\\\", \\\"{x:962,y:607,t:1527023621849};\\\", \\\"{x:963,y:608,t:1527023621872};\\\", \\\"{x:964,y:609,t:1527023621889};\\\", \\\"{x:964,y:610,t:1527023621937};\\\", \\\"{x:967,y:612,t:1527023622224};\\\", \\\"{x:968,y:613,t:1527023622233};\\\", \\\"{x:975,y:616,t:1527023622249};\\\", \\\"{x:985,y:618,t:1527023622267};\\\", \\\"{x:1004,y:621,t:1527023622283};\\\", \\\"{x:1029,y:624,t:1527023622299};\\\", \\\"{x:1057,y:628,t:1527023622316};\\\", \\\"{x:1087,y:632,t:1527023622333};\\\", \\\"{x:1128,y:635,t:1527023622350};\\\", \\\"{x:1162,y:636,t:1527023622365};\\\", \\\"{x:1196,y:636,t:1527023622382};\\\", \\\"{x:1235,y:636,t:1527023622399};\\\", \\\"{x:1242,y:636,t:1527023622416};\\\", \\\"{x:1244,y:636,t:1527023622432};\\\", \\\"{x:1247,y:636,t:1527023622449};\\\", \\\"{x:1250,y:636,t:1527023622809};\\\", \\\"{x:1252,y:638,t:1527023622816};\\\", \\\"{x:1257,y:640,t:1527023622834};\\\", \\\"{x:1265,y:642,t:1527023622849};\\\", \\\"{x:1271,y:643,t:1527023622867};\\\", \\\"{x:1281,y:647,t:1527023622884};\\\", \\\"{x:1288,y:647,t:1527023622900};\\\", \\\"{x:1294,y:648,t:1527023622918};\\\", \\\"{x:1299,y:649,t:1527023622933};\\\", \\\"{x:1302,y:651,t:1527023622949};\\\", \\\"{x:1308,y:654,t:1527023622967};\\\", \\\"{x:1313,y:657,t:1527023622983};\\\", \\\"{x:1317,y:659,t:1527023623000};\\\", \\\"{x:1320,y:661,t:1527023623017};\\\", \\\"{x:1321,y:662,t:1527023623033};\\\", \\\"{x:1323,y:663,t:1527023623050};\\\", \\\"{x:1324,y:665,t:1527023623067};\\\", \\\"{x:1325,y:666,t:1527023623208};\\\", \\\"{x:1325,y:668,t:1527023623305};\\\", \\\"{x:1326,y:668,t:1527023623592};\\\", \\\"{x:1332,y:668,t:1527023623600};\\\", \\\"{x:1343,y:667,t:1527023623617};\\\", \\\"{x:1358,y:666,t:1527023623634};\\\", \\\"{x:1374,y:663,t:1527023623650};\\\", \\\"{x:1391,y:661,t:1527023623667};\\\", \\\"{x:1402,y:658,t:1527023623684};\\\", \\\"{x:1407,y:657,t:1527023623701};\\\", \\\"{x:1408,y:657,t:1527023623718};\\\", \\\"{x:1408,y:656,t:1527023623768};\\\", \\\"{x:1408,y:652,t:1527023623785};\\\", \\\"{x:1405,y:648,t:1527023623800};\\\", \\\"{x:1398,y:645,t:1527023623817};\\\", \\\"{x:1383,y:643,t:1527023623835};\\\", \\\"{x:1366,y:641,t:1527023623851};\\\", \\\"{x:1352,y:638,t:1527023623867};\\\", \\\"{x:1342,y:638,t:1527023623884};\\\", \\\"{x:1338,y:638,t:1527023623901};\\\", \\\"{x:1336,y:638,t:1527023624217};\\\", \\\"{x:1335,y:638,t:1527023624256};\\\", \\\"{x:1333,y:638,t:1527023624268};\\\", \\\"{x:1332,y:639,t:1527023624288};\\\", \\\"{x:1331,y:639,t:1527023624301};\\\", \\\"{x:1330,y:641,t:1527023624319};\\\", \\\"{x:1327,y:644,t:1527023624334};\\\", \\\"{x:1324,y:646,t:1527023624351};\\\", \\\"{x:1319,y:651,t:1527023624368};\\\", \\\"{x:1312,y:662,t:1527023624385};\\\", \\\"{x:1303,y:674,t:1527023624400};\\\", \\\"{x:1295,y:690,t:1527023624418};\\\", \\\"{x:1288,y:703,t:1527023624434};\\\", \\\"{x:1282,y:717,t:1527023624451};\\\", \\\"{x:1279,y:734,t:1527023624468};\\\", \\\"{x:1276,y:756,t:1527023624484};\\\", \\\"{x:1271,y:781,t:1527023624502};\\\", \\\"{x:1266,y:804,t:1527023624518};\\\", \\\"{x:1263,y:823,t:1527023624534};\\\", \\\"{x:1259,y:842,t:1527023624551};\\\", \\\"{x:1256,y:868,t:1527023624568};\\\", \\\"{x:1255,y:880,t:1527023624584};\\\", \\\"{x:1254,y:887,t:1527023624601};\\\", \\\"{x:1254,y:891,t:1527023624619};\\\", \\\"{x:1254,y:892,t:1527023624635};\\\", \\\"{x:1254,y:893,t:1527023624651};\\\", \\\"{x:1254,y:894,t:1527023624668};\\\", \\\"{x:1254,y:895,t:1527023624685};\\\", \\\"{x:1254,y:899,t:1527023624701};\\\", \\\"{x:1254,y:903,t:1527023624719};\\\", \\\"{x:1253,y:906,t:1527023624735};\\\", \\\"{x:1252,y:909,t:1527023624751};\\\", \\\"{x:1250,y:910,t:1527023624769};\\\", \\\"{x:1248,y:911,t:1527023624785};\\\", \\\"{x:1247,y:911,t:1527023624801};\\\", \\\"{x:1245,y:912,t:1527023624819};\\\", \\\"{x:1243,y:912,t:1527023624835};\\\", \\\"{x:1239,y:912,t:1527023624851};\\\", \\\"{x:1238,y:913,t:1527023624869};\\\", \\\"{x:1236,y:913,t:1527023624884};\\\", \\\"{x:1235,y:913,t:1527023624901};\\\", \\\"{x:1234,y:913,t:1527023624918};\\\", \\\"{x:1236,y:913,t:1527023625145};\\\", \\\"{x:1240,y:910,t:1527023625153};\\\", \\\"{x:1248,y:906,t:1527023625169};\\\", \\\"{x:1254,y:901,t:1527023625185};\\\", \\\"{x:1267,y:890,t:1527023625202};\\\", \\\"{x:1279,y:880,t:1527023625218};\\\", \\\"{x:1290,y:870,t:1527023625235};\\\", \\\"{x:1301,y:855,t:1527023625252};\\\", \\\"{x:1311,y:840,t:1527023625268};\\\", \\\"{x:1320,y:826,t:1527023625285};\\\", \\\"{x:1330,y:809,t:1527023625302};\\\", \\\"{x:1338,y:792,t:1527023625318};\\\", \\\"{x:1343,y:778,t:1527023625335};\\\", \\\"{x:1350,y:764,t:1527023625353};\\\", \\\"{x:1355,y:749,t:1527023625368};\\\", \\\"{x:1358,y:739,t:1527023625385};\\\", \\\"{x:1360,y:730,t:1527023625402};\\\", \\\"{x:1363,y:721,t:1527023625418};\\\", \\\"{x:1364,y:712,t:1527023625435};\\\", \\\"{x:1365,y:705,t:1527023625452};\\\", \\\"{x:1365,y:700,t:1527023625468};\\\", \\\"{x:1368,y:691,t:1527023625485};\\\", \\\"{x:1369,y:684,t:1527023625502};\\\", \\\"{x:1369,y:677,t:1527023625518};\\\", \\\"{x:1369,y:672,t:1527023625535};\\\", \\\"{x:1369,y:667,t:1527023625553};\\\", \\\"{x:1369,y:665,t:1527023625568};\\\", \\\"{x:1369,y:663,t:1527023625585};\\\", \\\"{x:1369,y:662,t:1527023625602};\\\", \\\"{x:1369,y:660,t:1527023625619};\\\", \\\"{x:1369,y:659,t:1527023625635};\\\", \\\"{x:1369,y:657,t:1527023625652};\\\", \\\"{x:1369,y:656,t:1527023625721};\\\", \\\"{x:1369,y:655,t:1527023625735};\\\", \\\"{x:1369,y:654,t:1527023625921};\\\", \\\"{x:1369,y:653,t:1527023625935};\\\", \\\"{x:1367,y:652,t:1527023625953};\\\", \\\"{x:1364,y:650,t:1527023625968};\\\", \\\"{x:1360,y:649,t:1527023625986};\\\", \\\"{x:1357,y:648,t:1527023626002};\\\", \\\"{x:1356,y:649,t:1527023626129};\\\", \\\"{x:1356,y:650,t:1527023626137};\\\", \\\"{x:1356,y:653,t:1527023626152};\\\", \\\"{x:1356,y:656,t:1527023626169};\\\", \\\"{x:1357,y:661,t:1527023626186};\\\", \\\"{x:1359,y:667,t:1527023626202};\\\", \\\"{x:1362,y:674,t:1527023626219};\\\", \\\"{x:1365,y:688,t:1527023626236};\\\", \\\"{x:1372,y:704,t:1527023626252};\\\", \\\"{x:1381,y:727,t:1527023626269};\\\", \\\"{x:1391,y:750,t:1527023626286};\\\", \\\"{x:1402,y:774,t:1527023626302};\\\", \\\"{x:1413,y:801,t:1527023626319};\\\", \\\"{x:1431,y:837,t:1527023626337};\\\", \\\"{x:1439,y:853,t:1527023626352};\\\", \\\"{x:1448,y:866,t:1527023626369};\\\", \\\"{x:1454,y:877,t:1527023626386};\\\", \\\"{x:1461,y:887,t:1527023626402};\\\", \\\"{x:1466,y:892,t:1527023626419};\\\", \\\"{x:1470,y:900,t:1527023626436};\\\", \\\"{x:1474,y:905,t:1527023626452};\\\", \\\"{x:1477,y:908,t:1527023626469};\\\", \\\"{x:1478,y:910,t:1527023626487};\\\", \\\"{x:1481,y:913,t:1527023626502};\\\", \\\"{x:1481,y:914,t:1527023626519};\\\", \\\"{x:1480,y:913,t:1527023626657};\\\", \\\"{x:1477,y:910,t:1527023626670};\\\", \\\"{x:1467,y:900,t:1527023626686};\\\", \\\"{x:1450,y:888,t:1527023626703};\\\", \\\"{x:1414,y:867,t:1527023626719};\\\", \\\"{x:1298,y:812,t:1527023626736};\\\", \\\"{x:1190,y:778,t:1527023626753};\\\", \\\"{x:1064,y:731,t:1527023626769};\\\", \\\"{x:940,y:677,t:1527023626787};\\\", \\\"{x:813,y:624,t:1527023626803};\\\", \\\"{x:704,y:582,t:1527023626819};\\\", \\\"{x:609,y:553,t:1527023626838};\\\", \\\"{x:534,y:533,t:1527023626853};\\\", \\\"{x:503,y:520,t:1527023626868};\\\", \\\"{x:497,y:517,t:1527023626887};\\\", \\\"{x:497,y:514,t:1527023626936};\\\", \\\"{x:497,y:512,t:1527023626954};\\\", \\\"{x:497,y:507,t:1527023626970};\\\", \\\"{x:499,y:499,t:1527023626987};\\\", \\\"{x:499,y:492,t:1527023627002};\\\", \\\"{x:499,y:489,t:1527023627019};\\\", \\\"{x:499,y:488,t:1527023627047};\\\", \\\"{x:500,y:487,t:1527023627064};\\\", \\\"{x:501,y:487,t:1527023627079};\\\", \\\"{x:502,y:487,t:1527023627087};\\\", \\\"{x:503,y:487,t:1527023627103};\\\", \\\"{x:519,y:493,t:1527023627120};\\\", \\\"{x:533,y:496,t:1527023627136};\\\", \\\"{x:551,y:496,t:1527023627153};\\\", \\\"{x:573,y:496,t:1527023627169};\\\", \\\"{x:593,y:496,t:1527023627186};\\\", \\\"{x:614,y:492,t:1527023627204};\\\", \\\"{x:623,y:488,t:1527023627219};\\\", \\\"{x:627,y:485,t:1527023627237};\\\", \\\"{x:629,y:482,t:1527023627254};\\\", \\\"{x:629,y:480,t:1527023627270};\\\", \\\"{x:630,y:476,t:1527023627287};\\\", \\\"{x:630,y:473,t:1527023627304};\\\", \\\"{x:630,y:470,t:1527023627321};\\\", \\\"{x:629,y:467,t:1527023627337};\\\", \\\"{x:628,y:465,t:1527023627353};\\\", \\\"{x:627,y:464,t:1527023627371};\\\", \\\"{x:627,y:463,t:1527023627386};\\\", \\\"{x:625,y:461,t:1527023627404};\\\", \\\"{x:624,y:460,t:1527023627421};\\\", \\\"{x:622,y:458,t:1527023627437};\\\", \\\"{x:623,y:459,t:1527023628066};\\\", \\\"{x:652,y:476,t:1527023628088};\\\", \\\"{x:705,y:492,t:1527023628103};\\\", \\\"{x:783,y:514,t:1527023628121};\\\", \\\"{x:890,y:536,t:1527023628138};\\\", \\\"{x:993,y:554,t:1527023628154};\\\", \\\"{x:1110,y:573,t:1527023628170};\\\", \\\"{x:1211,y:595,t:1527023628187};\\\", \\\"{x:1300,y:622,t:1527023628204};\\\", \\\"{x:1371,y:651,t:1527023628220};\\\", \\\"{x:1419,y:684,t:1527023628238};\\\", \\\"{x:1444,y:712,t:1527023628254};\\\", \\\"{x:1455,y:734,t:1527023628271};\\\", \\\"{x:1455,y:772,t:1527023628288};\\\", \\\"{x:1446,y:801,t:1527023628304};\\\", \\\"{x:1432,y:823,t:1527023628321};\\\", \\\"{x:1414,y:849,t:1527023628338};\\\", \\\"{x:1397,y:870,t:1527023628354};\\\", \\\"{x:1381,y:888,t:1527023628371};\\\", \\\"{x:1370,y:905,t:1527023628388};\\\", \\\"{x:1358,y:921,t:1527023628404};\\\", \\\"{x:1345,y:937,t:1527023628422};\\\", \\\"{x:1333,y:948,t:1527023628438};\\\", \\\"{x:1326,y:957,t:1527023628454};\\\", \\\"{x:1318,y:962,t:1527023628471};\\\", \\\"{x:1310,y:962,t:1527023628488};\\\", \\\"{x:1303,y:962,t:1527023628504};\\\", \\\"{x:1298,y:962,t:1527023628521};\\\", \\\"{x:1293,y:960,t:1527023628538};\\\", \\\"{x:1290,y:957,t:1527023628553};\\\", \\\"{x:1287,y:953,t:1527023628570};\\\", \\\"{x:1284,y:945,t:1527023628588};\\\", \\\"{x:1283,y:933,t:1527023628604};\\\", \\\"{x:1283,y:917,t:1527023628621};\\\", \\\"{x:1283,y:898,t:1527023628638};\\\", \\\"{x:1286,y:881,t:1527023628654};\\\", \\\"{x:1291,y:860,t:1527023628671};\\\", \\\"{x:1307,y:820,t:1527023628688};\\\", \\\"{x:1316,y:793,t:1527023628704};\\\", \\\"{x:1326,y:771,t:1527023628720};\\\", \\\"{x:1333,y:746,t:1527023628738};\\\", \\\"{x:1345,y:716,t:1527023628754};\\\", \\\"{x:1356,y:693,t:1527023628771};\\\", \\\"{x:1362,y:681,t:1527023628788};\\\", \\\"{x:1363,y:678,t:1527023628804};\\\", \\\"{x:1364,y:678,t:1527023628849};\\\", \\\"{x:1368,y:684,t:1527023628856};\\\", \\\"{x:1373,y:696,t:1527023628871};\\\", \\\"{x:1389,y:737,t:1527023628889};\\\", \\\"{x:1404,y:773,t:1527023628904};\\\", \\\"{x:1424,y:810,t:1527023628921};\\\", \\\"{x:1440,y:838,t:1527023628938};\\\", \\\"{x:1454,y:857,t:1527023628954};\\\", \\\"{x:1463,y:872,t:1527023628971};\\\", \\\"{x:1469,y:883,t:1527023628988};\\\", \\\"{x:1473,y:891,t:1527023629005};\\\", \\\"{x:1476,y:896,t:1527023629021};\\\", \\\"{x:1477,y:901,t:1527023629037};\\\", \\\"{x:1479,y:905,t:1527023629054};\\\", \\\"{x:1480,y:909,t:1527023629071};\\\", \\\"{x:1480,y:910,t:1527023629087};\\\", \\\"{x:1480,y:911,t:1527023629104};\\\", \\\"{x:1476,y:914,t:1527023629122};\\\", \\\"{x:1463,y:914,t:1527023629137};\\\", \\\"{x:1440,y:914,t:1527023629154};\\\", \\\"{x:1408,y:914,t:1527023629171};\\\", \\\"{x:1351,y:918,t:1527023629188};\\\", \\\"{x:1280,y:923,t:1527023629204};\\\", \\\"{x:1201,y:936,t:1527023629222};\\\", \\\"{x:1143,y:944,t:1527023629238};\\\", \\\"{x:1107,y:952,t:1527023629254};\\\", \\\"{x:1089,y:957,t:1527023629272};\\\", \\\"{x:1084,y:959,t:1527023629287};\\\", \\\"{x:1084,y:957,t:1527023629320};\\\", \\\"{x:1082,y:949,t:1527023629337};\\\", \\\"{x:1081,y:940,t:1527023629354};\\\", \\\"{x:1080,y:932,t:1527023629371};\\\", \\\"{x:1079,y:924,t:1527023629387};\\\", \\\"{x:1077,y:918,t:1527023629404};\\\", \\\"{x:1077,y:906,t:1527023629422};\\\", \\\"{x:1077,y:889,t:1527023629437};\\\", \\\"{x:1077,y:863,t:1527023629454};\\\", \\\"{x:1077,y:828,t:1527023629471};\\\", \\\"{x:1087,y:771,t:1527023629487};\\\", \\\"{x:1109,y:705,t:1527023629504};\\\", \\\"{x:1126,y:671,t:1527023629521};\\\", \\\"{x:1148,y:631,t:1527023629537};\\\", \\\"{x:1172,y:593,t:1527023629554};\\\", \\\"{x:1188,y:565,t:1527023629571};\\\", \\\"{x:1199,y:550,t:1527023629586};\\\", \\\"{x:1204,y:541,t:1527023629604};\\\", \\\"{x:1208,y:537,t:1527023629621};\\\", \\\"{x:1208,y:536,t:1527023629636};\\\", \\\"{x:1209,y:535,t:1527023629654};\\\", \\\"{x:1210,y:535,t:1527023629670};\\\", \\\"{x:1214,y:535,t:1527023629696};\\\", \\\"{x:1219,y:541,t:1527023629703};\\\", \\\"{x:1233,y:565,t:1527023629721};\\\", \\\"{x:1259,y:606,t:1527023629737};\\\", \\\"{x:1289,y:655,t:1527023629753};\\\", \\\"{x:1327,y:711,t:1527023629771};\\\", \\\"{x:1363,y:762,t:1527023629787};\\\", \\\"{x:1398,y:812,t:1527023629803};\\\", \\\"{x:1420,y:850,t:1527023629821};\\\", \\\"{x:1441,y:882,t:1527023629836};\\\", \\\"{x:1450,y:898,t:1527023629853};\\\", \\\"{x:1456,y:912,t:1527023629869};\\\", \\\"{x:1461,y:924,t:1527023629886};\\\", \\\"{x:1470,y:943,t:1527023629903};\\\", \\\"{x:1477,y:956,t:1527023629921};\\\", \\\"{x:1481,y:964,t:1527023629937};\\\", \\\"{x:1485,y:969,t:1527023629953};\\\", \\\"{x:1488,y:973,t:1527023629969};\\\", \\\"{x:1488,y:974,t:1527023629986};\\\", \\\"{x:1489,y:975,t:1527023630004};\\\", \\\"{x:1489,y:973,t:1527023630353};\\\", \\\"{x:1488,y:972,t:1527023630370};\\\", \\\"{x:1487,y:969,t:1527023630387};\\\", \\\"{x:1484,y:966,t:1527023630404};\\\", \\\"{x:1477,y:960,t:1527023630420};\\\", \\\"{x:1468,y:954,t:1527023630437};\\\", \\\"{x:1458,y:949,t:1527023630454};\\\", \\\"{x:1454,y:945,t:1527023630470};\\\", \\\"{x:1448,y:942,t:1527023630487};\\\", \\\"{x:1445,y:940,t:1527023630504};\\\", \\\"{x:1443,y:939,t:1527023630536};\\\", \\\"{x:1442,y:937,t:1527023630601};\\\", \\\"{x:1441,y:935,t:1527023630608};\\\", \\\"{x:1441,y:933,t:1527023630621};\\\", \\\"{x:1440,y:930,t:1527023630638};\\\", \\\"{x:1440,y:924,t:1527023630655};\\\", \\\"{x:1440,y:919,t:1527023630670};\\\", \\\"{x:1440,y:916,t:1527023630687};\\\", \\\"{x:1440,y:910,t:1527023630704};\\\", \\\"{x:1440,y:909,t:1527023630729};\\\", \\\"{x:1440,y:908,t:1527023630737};\\\", \\\"{x:1440,y:907,t:1527023630760};\\\", \\\"{x:1438,y:905,t:1527023630784};\\\", \\\"{x:1435,y:905,t:1527023630792};\\\", \\\"{x:1431,y:903,t:1527023630804};\\\", \\\"{x:1409,y:903,t:1527023630820};\\\", \\\"{x:1372,y:905,t:1527023630837};\\\", \\\"{x:1309,y:920,t:1527023630853};\\\", \\\"{x:1207,y:932,t:1527023630870};\\\", \\\"{x:1101,y:934,t:1527023630887};\\\", \\\"{x:990,y:934,t:1527023630904};\\\", \\\"{x:841,y:934,t:1527023630920};\\\", \\\"{x:756,y:916,t:1527023630937};\\\", \\\"{x:689,y:899,t:1527023630953};\\\", \\\"{x:642,y:885,t:1527023630970};\\\", \\\"{x:605,y:868,t:1527023630987};\\\", \\\"{x:576,y:853,t:1527023631003};\\\", \\\"{x:556,y:841,t:1527023631020};\\\", \\\"{x:537,y:824,t:1527023631037};\\\", \\\"{x:513,y:806,t:1527023631053};\\\", \\\"{x:488,y:787,t:1527023631070};\\\", \\\"{x:458,y:771,t:1527023631087};\\\", \\\"{x:438,y:757,t:1527023631103};\\\", \\\"{x:425,y:749,t:1527023631120};\\\", \\\"{x:423,y:747,t:1527023631137};\\\", \\\"{x:423,y:744,t:1527023631153};\\\", \\\"{x:423,y:742,t:1527023631170};\\\", \\\"{x:423,y:738,t:1527023631187};\\\", \\\"{x:425,y:733,t:1527023631204};\\\", \\\"{x:433,y:728,t:1527023631221};\\\", \\\"{x:445,y:723,t:1527023631237};\\\", \\\"{x:461,y:716,t:1527023631253};\\\", \\\"{x:475,y:712,t:1527023631270};\\\", \\\"{x:490,y:710,t:1527023631287};\\\", \\\"{x:496,y:709,t:1527023631303};\\\", \\\"{x:500,y:709,t:1527023631320};\\\", \\\"{x:501,y:708,t:1527023631352};\\\", \\\"{x:502,y:707,t:1527023631370};\\\", \\\"{x:505,y:705,t:1527023631387};\\\", \\\"{x:507,y:703,t:1527023631403};\\\", \\\"{x:508,y:702,t:1527023631421};\\\", \\\"{x:509,y:699,t:1527023631438};\\\", \\\"{x:511,y:696,t:1527023631453};\\\", \\\"{x:511,y:693,t:1527023631469};\\\", \\\"{x:513,y:689,t:1527023631491};\\\", \\\"{x:514,y:689,t:1527023632384};\\\", \\\"{x:516,y:687,t:1527023632391};\\\", \\\"{x:518,y:687,t:1527023632407};\\\", \\\"{x:521,y:687,t:1527023632424};\\\", \\\"{x:524,y:687,t:1527023632441};\\\", \\\"{x:530,y:687,t:1527023632458};\\\", \\\"{x:533,y:687,t:1527023632474};\\\", \\\"{x:535,y:687,t:1527023632491};\\\", \\\"{x:535,y:686,t:1527023632511};\\\" ] }, { \\\"rt\\\": 18213, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 15, \\\"time_elapsed\\\": 736238, \\\"internal_node_id\\\": \\\"0.0-6.0-5.0\\\", \\\"subject\\\": \\\"QOJ6L\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"hotel\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 11, \\\"clicks\\\": 2.5, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"M\\\", \\\"L\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-4-12 PM-11 AM-03 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:536,y:686,t:1527023633353};\\\", \\\"{x:537,y:685,t:1527023633656};\\\", \\\"{x:538,y:684,t:1527023633704};\\\", \\\"{x:538,y:682,t:1527023633744};\\\", \\\"{x:538,y:681,t:1527023633757};\\\", \\\"{x:538,y:679,t:1527023633774};\\\", \\\"{x:538,y:678,t:1527023633791};\\\", \\\"{x:538,y:677,t:1527023633807};\\\", \\\"{x:538,y:676,t:1527023633824};\\\", \\\"{x:539,y:674,t:1527023633841};\\\", \\\"{x:539,y:673,t:1527023633880};\\\", \\\"{x:539,y:672,t:1527023633896};\\\", \\\"{x:539,y:671,t:1527023633907};\\\", \\\"{x:540,y:670,t:1527023633924};\\\", \\\"{x:540,y:668,t:1527023633941};\\\", \\\"{x:541,y:667,t:1527023633960};\\\", \\\"{x:541,y:666,t:1527023633977};\\\", \\\"{x:541,y:665,t:1527023633990};\\\", \\\"{x:543,y:664,t:1527023634009};\\\", \\\"{x:547,y:661,t:1527023634026};\\\", \\\"{x:557,y:657,t:1527023634042};\\\", \\\"{x:570,y:655,t:1527023634059};\\\", \\\"{x:592,y:653,t:1527023634076};\\\", \\\"{x:628,y:653,t:1527023634092};\\\", \\\"{x:679,y:651,t:1527023634109};\\\", \\\"{x:735,y:651,t:1527023634126};\\\", \\\"{x:782,y:651,t:1527023634142};\\\", \\\"{x:820,y:651,t:1527023634159};\\\", \\\"{x:851,y:653,t:1527023634176};\\\", \\\"{x:857,y:653,t:1527023634192};\\\", \\\"{x:857,y:654,t:1527023634731};\\\", \\\"{x:857,y:655,t:1527023634746};\\\", \\\"{x:866,y:656,t:1527023634763};\\\", \\\"{x:880,y:656,t:1527023634779};\\\", \\\"{x:896,y:656,t:1527023634796};\\\", \\\"{x:909,y:656,t:1527023634813};\\\", \\\"{x:918,y:656,t:1527023634829};\\\", \\\"{x:931,y:656,t:1527023634846};\\\", \\\"{x:942,y:656,t:1527023634863};\\\", \\\"{x:950,y:656,t:1527023634880};\\\", \\\"{x:956,y:656,t:1527023634896};\\\", \\\"{x:960,y:656,t:1527023634913};\\\", \\\"{x:964,y:656,t:1527023634929};\\\", \\\"{x:965,y:656,t:1527023634946};\\\", \\\"{x:968,y:655,t:1527023634963};\\\", \\\"{x:972,y:654,t:1527023634979};\\\", \\\"{x:975,y:654,t:1527023634997};\\\", \\\"{x:978,y:653,t:1527023635013};\\\", \\\"{x:983,y:653,t:1527023635030};\\\", \\\"{x:986,y:653,t:1527023635046};\\\", \\\"{x:989,y:653,t:1527023635063};\\\", \\\"{x:992,y:653,t:1527023635080};\\\", \\\"{x:993,y:653,t:1527023635096};\\\", \\\"{x:994,y:653,t:1527023635113};\\\", \\\"{x:995,y:653,t:1527023635236};\\\", \\\"{x:996,y:653,t:1527023635267};\\\", \\\"{x:998,y:652,t:1527023635283};\\\", \\\"{x:999,y:652,t:1527023635323};\\\", \\\"{x:1000,y:652,t:1527023635339};\\\", \\\"{x:1002,y:652,t:1527023635347};\\\", \\\"{x:1004,y:652,t:1527023635363};\\\", \\\"{x:1007,y:652,t:1527023635380};\\\", \\\"{x:1011,y:652,t:1527023635397};\\\", \\\"{x:1014,y:652,t:1527023635414};\\\", \\\"{x:1019,y:654,t:1527023635430};\\\", \\\"{x:1024,y:656,t:1527023635447};\\\", \\\"{x:1032,y:661,t:1527023635464};\\\", \\\"{x:1040,y:663,t:1527023635480};\\\", \\\"{x:1044,y:663,t:1527023635498};\\\", \\\"{x:1045,y:664,t:1527023635828};\\\", \\\"{x:1045,y:665,t:1527023635835};\\\", \\\"{x:1046,y:665,t:1527023635883};\\\", \\\"{x:1047,y:665,t:1527023635947};\\\", \\\"{x:1048,y:665,t:1527023636019};\\\", \\\"{x:1048,y:664,t:1527023636035};\\\", \\\"{x:1049,y:664,t:1527023636051};\\\", \\\"{x:1050,y:664,t:1527023636064};\\\", \\\"{x:1051,y:663,t:1527023636080};\\\", \\\"{x:1052,y:661,t:1527023636097};\\\", \\\"{x:1054,y:659,t:1527023636114};\\\", \\\"{x:1055,y:655,t:1527023636130};\\\", \\\"{x:1058,y:651,t:1527023636147};\\\", \\\"{x:1058,y:650,t:1527023636164};\\\", \\\"{x:1059,y:650,t:1527023636180};\\\", \\\"{x:1060,y:650,t:1527023636763};\\\", \\\"{x:1061,y:650,t:1527023636782};\\\", \\\"{x:1064,y:648,t:1527023636799};\\\", \\\"{x:1066,y:647,t:1527023636815};\\\", \\\"{x:1068,y:645,t:1527023636832};\\\", \\\"{x:1068,y:644,t:1527023636848};\\\", \\\"{x:1070,y:643,t:1527023636864};\\\", \\\"{x:1071,y:642,t:1527023636924};\\\", \\\"{x:1072,y:641,t:1527023637092};\\\", \\\"{x:1073,y:641,t:1527023637107};\\\", \\\"{x:1073,y:640,t:1527023637115};\\\", \\\"{x:1074,y:640,t:1527023637139};\\\", \\\"{x:1075,y:640,t:1527023637148};\\\", \\\"{x:1078,y:639,t:1527023638148};\\\", \\\"{x:1081,y:639,t:1527023638155};\\\", \\\"{x:1086,y:639,t:1527023638165};\\\", \\\"{x:1101,y:640,t:1527023638182};\\\", \\\"{x:1124,y:645,t:1527023638199};\\\", \\\"{x:1139,y:646,t:1527023638216};\\\", \\\"{x:1150,y:647,t:1527023638233};\\\", \\\"{x:1157,y:647,t:1527023638249};\\\", \\\"{x:1160,y:648,t:1527023638265};\\\", \\\"{x:1161,y:648,t:1527023638282};\\\", \\\"{x:1161,y:649,t:1527023640172};\\\", \\\"{x:1161,y:650,t:1527023640187};\\\", \\\"{x:1158,y:650,t:1527023640201};\\\", \\\"{x:1147,y:650,t:1527023640218};\\\", \\\"{x:1131,y:652,t:1527023640234};\\\", \\\"{x:1108,y:652,t:1527023640251};\\\", \\\"{x:1072,y:646,t:1527023640267};\\\", \\\"{x:1050,y:644,t:1527023640284};\\\", \\\"{x:1033,y:639,t:1527023640301};\\\", \\\"{x:1020,y:634,t:1527023640317};\\\", \\\"{x:1012,y:631,t:1527023640334};\\\", \\\"{x:1005,y:627,t:1527023640350};\\\", \\\"{x:1004,y:625,t:1527023640368};\\\", \\\"{x:1002,y:623,t:1527023640385};\\\", \\\"{x:1001,y:615,t:1527023640401};\\\", \\\"{x:992,y:597,t:1527023640418};\\\", \\\"{x:976,y:577,t:1527023640435};\\\", \\\"{x:960,y:567,t:1527023640451};\\\", \\\"{x:934,y:556,t:1527023640469};\\\", \\\"{x:905,y:543,t:1527023640485};\\\", \\\"{x:875,y:534,t:1527023640500};\\\", \\\"{x:848,y:522,t:1527023640517};\\\", \\\"{x:812,y:506,t:1527023640535};\\\", \\\"{x:780,y:493,t:1527023640551};\\\", \\\"{x:751,y:485,t:1527023640567};\\\", \\\"{x:734,y:480,t:1527023640583};\\\", \\\"{x:728,y:480,t:1527023640601};\\\", \\\"{x:729,y:480,t:1527023640690};\\\", \\\"{x:733,y:480,t:1527023640700};\\\", \\\"{x:738,y:484,t:1527023640717};\\\", \\\"{x:741,y:490,t:1527023640734};\\\", \\\"{x:742,y:497,t:1527023640750};\\\", \\\"{x:735,y:507,t:1527023640768};\\\", \\\"{x:711,y:520,t:1527023640785};\\\", \\\"{x:663,y:537,t:1527023640801};\\\", \\\"{x:595,y:549,t:1527023640821};\\\", \\\"{x:461,y:553,t:1527023640834};\\\", \\\"{x:389,y:553,t:1527023640851};\\\", \\\"{x:338,y:553,t:1527023640868};\\\", \\\"{x:313,y:553,t:1527023640884};\\\", \\\"{x:298,y:553,t:1527023640900};\\\", \\\"{x:291,y:553,t:1527023640917};\\\", \\\"{x:291,y:552,t:1527023641099};\\\", \\\"{x:295,y:552,t:1527023641106};\\\", \\\"{x:302,y:551,t:1527023641118};\\\", \\\"{x:312,y:548,t:1527023641136};\\\", \\\"{x:321,y:545,t:1527023641153};\\\", \\\"{x:326,y:543,t:1527023641168};\\\", \\\"{x:328,y:543,t:1527023641184};\\\", \\\"{x:334,y:539,t:1527023641202};\\\", \\\"{x:339,y:537,t:1527023641218};\\\", \\\"{x:341,y:535,t:1527023641235};\\\", \\\"{x:341,y:534,t:1527023641251};\\\", \\\"{x:343,y:534,t:1527023641339};\\\", \\\"{x:345,y:535,t:1527023641355};\\\", \\\"{x:345,y:536,t:1527023641368};\\\", \\\"{x:347,y:540,t:1527023641385};\\\", \\\"{x:349,y:544,t:1527023641402};\\\", \\\"{x:353,y:546,t:1527023641418};\\\", \\\"{x:354,y:547,t:1527023641434};\\\", \\\"{x:355,y:548,t:1527023641451};\\\", \\\"{x:357,y:548,t:1527023641468};\\\", \\\"{x:359,y:550,t:1527023641485};\\\", \\\"{x:360,y:550,t:1527023641501};\\\", \\\"{x:361,y:550,t:1527023641626};\\\", \\\"{x:362,y:550,t:1527023641634};\\\", \\\"{x:364,y:549,t:1527023641770};\\\", \\\"{x:364,y:546,t:1527023641786};\\\", \\\"{x:368,y:534,t:1527023641803};\\\", \\\"{x:370,y:525,t:1527023641818};\\\", \\\"{x:372,y:521,t:1527023641835};\\\", \\\"{x:374,y:515,t:1527023641851};\\\", \\\"{x:374,y:510,t:1527023641869};\\\", \\\"{x:375,y:504,t:1527023641886};\\\", \\\"{x:375,y:502,t:1527023641903};\\\", \\\"{x:376,y:499,t:1527023641919};\\\", \\\"{x:376,y:498,t:1527023641935};\\\", \\\"{x:376,y:497,t:1527023641952};\\\", \\\"{x:377,y:495,t:1527023641968};\\\", \\\"{x:377,y:494,t:1527023641994};\\\", \\\"{x:377,y:493,t:1527023642010};\\\", \\\"{x:377,y:492,t:1527023642018};\\\", \\\"{x:377,y:491,t:1527023642059};\\\", \\\"{x:377,y:489,t:1527023642074};\\\", \\\"{x:378,y:489,t:1527023642085};\\\", \\\"{x:379,y:486,t:1527023642102};\\\", \\\"{x:380,y:485,t:1527023642118};\\\", \\\"{x:380,y:487,t:1527023642386};\\\", \\\"{x:380,y:494,t:1527023642402};\\\", \\\"{x:380,y:501,t:1527023642420};\\\", \\\"{x:380,y:507,t:1527023642435};\\\", \\\"{x:380,y:512,t:1527023642453};\\\", \\\"{x:380,y:517,t:1527023642469};\\\", \\\"{x:380,y:521,t:1527023642485};\\\", \\\"{x:380,y:524,t:1527023642502};\\\", \\\"{x:380,y:526,t:1527023642519};\\\", \\\"{x:380,y:528,t:1527023642536};\\\", \\\"{x:380,y:530,t:1527023642552};\\\", \\\"{x:380,y:533,t:1527023642569};\\\", \\\"{x:380,y:534,t:1527023642586};\\\", \\\"{x:380,y:537,t:1527023642603};\\\", \\\"{x:380,y:538,t:1527023642627};\\\", \\\"{x:380,y:539,t:1527023642643};\\\", \\\"{x:380,y:540,t:1527023642653};\\\", \\\"{x:380,y:541,t:1527023642845};\\\", \\\"{x:381,y:542,t:1527023642853};\\\", \\\"{x:382,y:544,t:1527023642869};\\\", \\\"{x:383,y:547,t:1527023643163};\\\", \\\"{x:384,y:549,t:1527023643180};\\\", \\\"{x:384,y:551,t:1527023643194};\\\", \\\"{x:385,y:552,t:1527023643210};\\\", \\\"{x:386,y:553,t:1527023643234};\\\", \\\"{x:391,y:553,t:1527023647362};\\\", \\\"{x:407,y:566,t:1527023647373};\\\", \\\"{x:466,y:596,t:1527023647390};\\\", \\\"{x:545,y:640,t:1527023647407};\\\", \\\"{x:664,y:695,t:1527023647424};\\\", \\\"{x:818,y:760,t:1527023647439};\\\", \\\"{x:972,y:818,t:1527023647457};\\\", \\\"{x:1105,y:863,t:1527023647473};\\\", \\\"{x:1227,y:899,t:1527023647490};\\\", \\\"{x:1314,y:925,t:1527023647506};\\\", \\\"{x:1336,y:933,t:1527023647523};\\\", \\\"{x:1342,y:938,t:1527023647540};\\\", \\\"{x:1344,y:938,t:1527023647556};\\\", \\\"{x:1345,y:939,t:1527023647573};\\\", \\\"{x:1345,y:940,t:1527023647755};\\\", \\\"{x:1343,y:938,t:1527023647762};\\\", \\\"{x:1339,y:933,t:1527023647774};\\\", \\\"{x:1332,y:926,t:1527023647791};\\\", \\\"{x:1321,y:919,t:1527023647807};\\\", \\\"{x:1313,y:915,t:1527023647824};\\\", \\\"{x:1307,y:914,t:1527023647841};\\\", \\\"{x:1300,y:912,t:1527023647857};\\\", \\\"{x:1293,y:910,t:1527023647874};\\\", \\\"{x:1284,y:909,t:1527023647891};\\\", \\\"{x:1279,y:909,t:1527023647907};\\\", \\\"{x:1277,y:909,t:1527023647924};\\\", \\\"{x:1276,y:909,t:1527023647941};\\\", \\\"{x:1271,y:909,t:1527023647957};\\\", \\\"{x:1268,y:909,t:1527023647973};\\\", \\\"{x:1266,y:909,t:1527023647991};\\\", \\\"{x:1264,y:909,t:1527023648007};\\\", \\\"{x:1260,y:913,t:1527023648023};\\\", \\\"{x:1257,y:916,t:1527023648041};\\\", \\\"{x:1250,y:919,t:1527023648057};\\\", \\\"{x:1246,y:920,t:1527023648074};\\\", \\\"{x:1240,y:923,t:1527023648091};\\\", \\\"{x:1241,y:923,t:1527023648299};\\\", \\\"{x:1243,y:923,t:1527023648308};\\\", \\\"{x:1246,y:923,t:1527023648324};\\\", \\\"{x:1250,y:923,t:1527023648341};\\\", \\\"{x:1254,y:923,t:1527023648358};\\\", \\\"{x:1257,y:923,t:1527023648374};\\\", \\\"{x:1265,y:923,t:1527023648391};\\\", \\\"{x:1270,y:923,t:1527023648408};\\\", \\\"{x:1277,y:923,t:1527023648424};\\\", \\\"{x:1284,y:923,t:1527023648441};\\\", \\\"{x:1291,y:920,t:1527023648457};\\\", \\\"{x:1298,y:918,t:1527023648474};\\\", \\\"{x:1314,y:912,t:1527023648492};\\\", \\\"{x:1317,y:911,t:1527023648508};\\\", \\\"{x:1321,y:910,t:1527023648524};\\\", \\\"{x:1322,y:910,t:1527023648541};\\\", \\\"{x:1323,y:909,t:1527023648558};\\\", \\\"{x:1326,y:909,t:1527023648676};\\\", \\\"{x:1326,y:910,t:1527023648690};\\\", \\\"{x:1329,y:910,t:1527023648707};\\\", \\\"{x:1332,y:912,t:1527023648724};\\\", \\\"{x:1333,y:912,t:1527023648740};\\\", \\\"{x:1334,y:912,t:1527023648757};\\\", \\\"{x:1335,y:912,t:1527023648803};\\\", \\\"{x:1336,y:912,t:1527023648875};\\\", \\\"{x:1337,y:912,t:1527023648971};\\\", \\\"{x:1338,y:910,t:1527023648987};\\\", \\\"{x:1339,y:908,t:1527023648995};\\\", \\\"{x:1340,y:907,t:1527023649008};\\\", \\\"{x:1342,y:902,t:1527023649025};\\\", \\\"{x:1348,y:894,t:1527023649041};\\\", \\\"{x:1353,y:882,t:1527023649058};\\\", \\\"{x:1363,y:851,t:1527023649075};\\\", \\\"{x:1380,y:809,t:1527023649091};\\\", \\\"{x:1396,y:771,t:1527023649108};\\\", \\\"{x:1407,y:747,t:1527023649125};\\\", \\\"{x:1415,y:728,t:1527023649141};\\\", \\\"{x:1420,y:716,t:1527023649158};\\\", \\\"{x:1423,y:706,t:1527023649175};\\\", \\\"{x:1426,y:700,t:1527023649192};\\\", \\\"{x:1426,y:698,t:1527023649208};\\\", \\\"{x:1427,y:696,t:1527023649226};\\\", \\\"{x:1427,y:695,t:1527023649332};\\\", \\\"{x:1427,y:691,t:1527023649342};\\\", \\\"{x:1431,y:680,t:1527023649358};\\\", \\\"{x:1441,y:664,t:1527023649375};\\\", \\\"{x:1450,y:654,t:1527023649392};\\\", \\\"{x:1457,y:648,t:1527023649408};\\\", \\\"{x:1464,y:641,t:1527023649424};\\\", \\\"{x:1472,y:634,t:1527023649442};\\\", \\\"{x:1481,y:624,t:1527023649459};\\\", \\\"{x:1510,y:596,t:1527023649475};\\\", \\\"{x:1551,y:561,t:1527023649493};\\\", \\\"{x:1583,y:538,t:1527023649508};\\\", \\\"{x:1614,y:517,t:1527023649525};\\\", \\\"{x:1633,y:502,t:1527023649542};\\\", \\\"{x:1648,y:489,t:1527023649559};\\\", \\\"{x:1651,y:486,t:1527023649574};\\\", \\\"{x:1652,y:485,t:1527023649592};\\\", \\\"{x:1652,y:489,t:1527023649755};\\\", \\\"{x:1651,y:498,t:1527023649763};\\\", \\\"{x:1650,y:508,t:1527023649775};\\\", \\\"{x:1647,y:525,t:1527023649792};\\\", \\\"{x:1643,y:539,t:1527023649809};\\\", \\\"{x:1639,y:551,t:1527023649825};\\\", \\\"{x:1633,y:564,t:1527023649842};\\\", \\\"{x:1621,y:598,t:1527023649859};\\\", \\\"{x:1602,y:664,t:1527023649875};\\\", \\\"{x:1579,y:755,t:1527023649892};\\\", \\\"{x:1558,y:843,t:1527023649909};\\\", \\\"{x:1550,y:881,t:1527023649925};\\\", \\\"{x:1546,y:898,t:1527023649942};\\\", \\\"{x:1543,y:906,t:1527023649959};\\\", \\\"{x:1543,y:907,t:1527023649975};\\\", \\\"{x:1543,y:910,t:1527023649992};\\\", \\\"{x:1543,y:914,t:1527023650009};\\\", \\\"{x:1543,y:917,t:1527023650027};\\\", \\\"{x:1541,y:922,t:1527023650042};\\\", \\\"{x:1516,y:936,t:1527023650059};\\\", \\\"{x:1478,y:949,t:1527023650075};\\\", \\\"{x:1413,y:958,t:1527023650092};\\\", \\\"{x:1305,y:970,t:1527023650108};\\\", \\\"{x:1152,y:979,t:1527023650125};\\\", \\\"{x:983,y:981,t:1527023650141};\\\", \\\"{x:812,y:981,t:1527023650158};\\\", \\\"{x:666,y:971,t:1527023650176};\\\", \\\"{x:524,y:959,t:1527023650191};\\\", \\\"{x:404,y:942,t:1527023650209};\\\", \\\"{x:307,y:929,t:1527023650225};\\\", \\\"{x:226,y:914,t:1527023650242};\\\", \\\"{x:170,y:898,t:1527023650258};\\\", \\\"{x:148,y:890,t:1527023650276};\\\", \\\"{x:136,y:883,t:1527023650291};\\\", \\\"{x:126,y:875,t:1527023650309};\\\", \\\"{x:118,y:863,t:1527023650326};\\\", \\\"{x:110,y:848,t:1527023650342};\\\", \\\"{x:106,y:838,t:1527023650359};\\\", \\\"{x:105,y:832,t:1527023650376};\\\", \\\"{x:104,y:829,t:1527023650392};\\\", \\\"{x:104,y:820,t:1527023650409};\\\", \\\"{x:104,y:809,t:1527023650426};\\\", \\\"{x:104,y:799,t:1527023650442};\\\", \\\"{x:121,y:781,t:1527023650459};\\\", \\\"{x:145,y:767,t:1527023650476};\\\", \\\"{x:189,y:749,t:1527023650493};\\\", \\\"{x:243,y:729,t:1527023650509};\\\", \\\"{x:317,y:711,t:1527023650526};\\\", \\\"{x:398,y:700,t:1527023650543};\\\", \\\"{x:456,y:692,t:1527023650560};\\\", \\\"{x:507,y:684,t:1527023650576};\\\", \\\"{x:534,y:677,t:1527023650592};\\\", \\\"{x:546,y:673,t:1527023650608};\\\", \\\"{x:550,y:673,t:1527023650625};\\\", \\\"{x:551,y:672,t:1527023650643};\\\" ] }, { \\\"rt\\\": 13357, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 16, \\\"time_elapsed\\\": 750848, \\\"internal_node_id\\\": \\\"0.0-6.0-6.0\\\", \\\"subject\\\": \\\"QOJ6L\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"hotel\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 12, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F -F -G -G -G \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:553,y:672,t:1527023653051};\\\", \\\"{x:555,y:674,t:1527023653062};\\\", \\\"{x:557,y:675,t:1527023653283};\\\", \\\"{x:558,y:675,t:1527023653306};\\\", \\\"{x:560,y:675,t:1527023653314};\\\", \\\"{x:561,y:675,t:1527023653330};\\\", \\\"{x:562,y:675,t:1527023653346};\\\", \\\"{x:575,y:675,t:1527023653362};\\\", \\\"{x:590,y:675,t:1527023653378};\\\", \\\"{x:607,y:673,t:1527023653394};\\\", \\\"{x:632,y:667,t:1527023653411};\\\", \\\"{x:669,y:659,t:1527023653427};\\\", \\\"{x:707,y:649,t:1527023653444};\\\", \\\"{x:738,y:637,t:1527023653462};\\\", \\\"{x:763,y:621,t:1527023653478};\\\", \\\"{x:776,y:609,t:1527023653495};\\\", \\\"{x:777,y:606,t:1527023653512};\\\", \\\"{x:778,y:606,t:1527023654379};\\\", \\\"{x:779,y:606,t:1527023654411};\\\", \\\"{x:780,y:607,t:1527023654451};\\\", \\\"{x:782,y:610,t:1527023654467};\\\", \\\"{x:783,y:610,t:1527023654479};\\\", \\\"{x:788,y:610,t:1527023654496};\\\", \\\"{x:790,y:610,t:1527023654512};\\\", \\\"{x:793,y:607,t:1527023655147};\\\", \\\"{x:809,y:601,t:1527023655163};\\\", \\\"{x:832,y:594,t:1527023655180};\\\", \\\"{x:860,y:588,t:1527023655197};\\\", \\\"{x:892,y:583,t:1527023655213};\\\", \\\"{x:922,y:577,t:1527023655232};\\\", \\\"{x:949,y:575,t:1527023655247};\\\", \\\"{x:969,y:571,t:1527023655263};\\\", \\\"{x:987,y:570,t:1527023655280};\\\", \\\"{x:996,y:567,t:1527023655296};\\\", \\\"{x:999,y:567,t:1527023655313};\\\", \\\"{x:1000,y:566,t:1527023655329};\\\", \\\"{x:1001,y:566,t:1527023655410};\\\", \\\"{x:1002,y:566,t:1527023655426};\\\", \\\"{x:1003,y:566,t:1527023655435};\\\", \\\"{x:1004,y:565,t:1527023655450};\\\", \\\"{x:1005,y:564,t:1527023655463};\\\", \\\"{x:1006,y:564,t:1527023655480};\\\", \\\"{x:1009,y:564,t:1527023655495};\\\", \\\"{x:1012,y:564,t:1527023655513};\\\", \\\"{x:1013,y:564,t:1527023655530};\\\", \\\"{x:1014,y:564,t:1527023655546};\\\", \\\"{x:1015,y:564,t:1527023655563};\\\", \\\"{x:1016,y:564,t:1527023655580};\\\", \\\"{x:1018,y:564,t:1527023655597};\\\", \\\"{x:1021,y:564,t:1527023655613};\\\", \\\"{x:1022,y:564,t:1527023655630};\\\", \\\"{x:1025,y:565,t:1527023655646};\\\", \\\"{x:1025,y:566,t:1527023655859};\\\", \\\"{x:1025,y:568,t:1527023655866};\\\", \\\"{x:1025,y:570,t:1527023655880};\\\", \\\"{x:1026,y:571,t:1527023655896};\\\", \\\"{x:1027,y:574,t:1527023655913};\\\", \\\"{x:1028,y:577,t:1527023655930};\\\", \\\"{x:1029,y:578,t:1527023655954};\\\", \\\"{x:1029,y:580,t:1527023655962};\\\", \\\"{x:1030,y:580,t:1527023655994};\\\", \\\"{x:1030,y:581,t:1527023656002};\\\", \\\"{x:1031,y:581,t:1527023656014};\\\", \\\"{x:1034,y:583,t:1527023656029};\\\", \\\"{x:1036,y:584,t:1527023656047};\\\", \\\"{x:1042,y:585,t:1527023656064};\\\", \\\"{x:1051,y:589,t:1527023656079};\\\", \\\"{x:1067,y:590,t:1527023656096};\\\", \\\"{x:1088,y:593,t:1527023656114};\\\", \\\"{x:1110,y:595,t:1527023656130};\\\", \\\"{x:1146,y:598,t:1527023656147};\\\", \\\"{x:1171,y:598,t:1527023656164};\\\", \\\"{x:1195,y:598,t:1527023656180};\\\", \\\"{x:1211,y:597,t:1527023656197};\\\", \\\"{x:1231,y:592,t:1527023656214};\\\", \\\"{x:1250,y:589,t:1527023656230};\\\", \\\"{x:1259,y:584,t:1527023656247};\\\", \\\"{x:1261,y:584,t:1527023657036};\\\", \\\"{x:1265,y:586,t:1527023657048};\\\", \\\"{x:1271,y:590,t:1527023657064};\\\", \\\"{x:1276,y:593,t:1527023657081};\\\", \\\"{x:1285,y:597,t:1527023657099};\\\", \\\"{x:1288,y:599,t:1527023657114};\\\", \\\"{x:1296,y:602,t:1527023657131};\\\", \\\"{x:1299,y:603,t:1527023657148};\\\", \\\"{x:1299,y:604,t:1527023657165};\\\", \\\"{x:1301,y:604,t:1527023657181};\\\", \\\"{x:1304,y:606,t:1527023657199};\\\", \\\"{x:1304,y:607,t:1527023657214};\\\", \\\"{x:1307,y:609,t:1527023657232};\\\", \\\"{x:1309,y:610,t:1527023657249};\\\", \\\"{x:1312,y:612,t:1527023657264};\\\", \\\"{x:1316,y:614,t:1527023657281};\\\", \\\"{x:1323,y:618,t:1527023657299};\\\", \\\"{x:1326,y:620,t:1527023657315};\\\", \\\"{x:1329,y:621,t:1527023657332};\\\", \\\"{x:1329,y:622,t:1527023657349};\\\", \\\"{x:1331,y:623,t:1527023657364};\\\", \\\"{x:1333,y:623,t:1527023657381};\\\", \\\"{x:1334,y:624,t:1527023657403};\\\", \\\"{x:1335,y:624,t:1527023657414};\\\", \\\"{x:1336,y:625,t:1527023657431};\\\", \\\"{x:1338,y:625,t:1527023657449};\\\", \\\"{x:1339,y:625,t:1527023657464};\\\", \\\"{x:1339,y:626,t:1527023657491};\\\", \\\"{x:1340,y:626,t:1527023657588};\\\", \\\"{x:1342,y:626,t:1527023657598};\\\", \\\"{x:1343,y:626,t:1527023657616};\\\", \\\"{x:1345,y:626,t:1527023657632};\\\", \\\"{x:1347,y:627,t:1527023657875};\\\", \\\"{x:1347,y:629,t:1527023657890};\\\", \\\"{x:1348,y:632,t:1527023657898};\\\", \\\"{x:1349,y:634,t:1527023657914};\\\", \\\"{x:1349,y:635,t:1527023657932};\\\", \\\"{x:1350,y:636,t:1527023657950};\\\", \\\"{x:1350,y:637,t:1527023658459};\\\", \\\"{x:1348,y:639,t:1527023658469};\\\", \\\"{x:1344,y:645,t:1527023658482};\\\", \\\"{x:1338,y:653,t:1527023658498};\\\", \\\"{x:1331,y:660,t:1527023658515};\\\", \\\"{x:1327,y:666,t:1527023658532};\\\", \\\"{x:1319,y:673,t:1527023658549};\\\", \\\"{x:1311,y:683,t:1527023658564};\\\", \\\"{x:1301,y:694,t:1527023658582};\\\", \\\"{x:1291,y:708,t:1527023658599};\\\", \\\"{x:1284,y:722,t:1527023658615};\\\", \\\"{x:1279,y:732,t:1527023658632};\\\", \\\"{x:1274,y:747,t:1527023658649};\\\", \\\"{x:1271,y:761,t:1527023658665};\\\", \\\"{x:1269,y:778,t:1527023658682};\\\", \\\"{x:1266,y:791,t:1527023658698};\\\", \\\"{x:1264,y:800,t:1527023658715};\\\", \\\"{x:1261,y:810,t:1527023658732};\\\", \\\"{x:1255,y:821,t:1527023658749};\\\", \\\"{x:1250,y:828,t:1527023658765};\\\", \\\"{x:1243,y:839,t:1527023658782};\\\", \\\"{x:1239,y:848,t:1527023658799};\\\", \\\"{x:1234,y:854,t:1527023658815};\\\", \\\"{x:1229,y:861,t:1527023658832};\\\", \\\"{x:1223,y:871,t:1527023658849};\\\", \\\"{x:1218,y:877,t:1527023658865};\\\", \\\"{x:1211,y:889,t:1527023658882};\\\", \\\"{x:1206,y:897,t:1527023658898};\\\", \\\"{x:1201,y:906,t:1527023658915};\\\", \\\"{x:1194,y:917,t:1527023658932};\\\", \\\"{x:1187,y:923,t:1527023658949};\\\", \\\"{x:1186,y:925,t:1527023658966};\\\", \\\"{x:1185,y:926,t:1527023658987};\\\", \\\"{x:1184,y:926,t:1527023659123};\\\", \\\"{x:1184,y:925,t:1527023659139};\\\", \\\"{x:1184,y:924,t:1527023659155};\\\", \\\"{x:1184,y:923,t:1527023659166};\\\", \\\"{x:1188,y:919,t:1527023659182};\\\", \\\"{x:1190,y:916,t:1527023659199};\\\", \\\"{x:1193,y:911,t:1527023659216};\\\", \\\"{x:1196,y:908,t:1527023659233};\\\", \\\"{x:1198,y:904,t:1527023659250};\\\", \\\"{x:1205,y:899,t:1527023659266};\\\", \\\"{x:1210,y:892,t:1527023659283};\\\", \\\"{x:1214,y:886,t:1527023659300};\\\", \\\"{x:1219,y:877,t:1527023659316};\\\", \\\"{x:1225,y:869,t:1527023659333};\\\", \\\"{x:1230,y:859,t:1527023659349};\\\", \\\"{x:1235,y:850,t:1527023659367};\\\", \\\"{x:1242,y:842,t:1527023659383};\\\", \\\"{x:1247,y:832,t:1527023659399};\\\", \\\"{x:1255,y:821,t:1527023659416};\\\", \\\"{x:1262,y:810,t:1527023659434};\\\", \\\"{x:1271,y:799,t:1527023659450};\\\", \\\"{x:1285,y:776,t:1527023659467};\\\", \\\"{x:1291,y:764,t:1527023659482};\\\", \\\"{x:1301,y:749,t:1527023659500};\\\", \\\"{x:1314,y:726,t:1527023659517};\\\", \\\"{x:1333,y:694,t:1527023659534};\\\", \\\"{x:1349,y:660,t:1527023659549};\\\", \\\"{x:1364,y:635,t:1527023659567};\\\", \\\"{x:1372,y:619,t:1527023659582};\\\", \\\"{x:1379,y:606,t:1527023659599};\\\", \\\"{x:1385,y:593,t:1527023659615};\\\", \\\"{x:1391,y:580,t:1527023659633};\\\", \\\"{x:1396,y:566,t:1527023659649};\\\", \\\"{x:1401,y:547,t:1527023659666};\\\", \\\"{x:1405,y:537,t:1527023659682};\\\", \\\"{x:1408,y:527,t:1527023659699};\\\", \\\"{x:1412,y:519,t:1527023659716};\\\", \\\"{x:1416,y:510,t:1527023659733};\\\", \\\"{x:1418,y:503,t:1527023659750};\\\", \\\"{x:1419,y:501,t:1527023659766};\\\", \\\"{x:1419,y:502,t:1527023660675};\\\", \\\"{x:1419,y:505,t:1527023660683};\\\", \\\"{x:1419,y:509,t:1527023660701};\\\", \\\"{x:1419,y:515,t:1527023660718};\\\", \\\"{x:1419,y:521,t:1527023660734};\\\", \\\"{x:1419,y:528,t:1527023660751};\\\", \\\"{x:1419,y:536,t:1527023660768};\\\", \\\"{x:1419,y:543,t:1527023660783};\\\", \\\"{x:1420,y:550,t:1527023660801};\\\", \\\"{x:1420,y:556,t:1527023660817};\\\", \\\"{x:1422,y:562,t:1527023660835};\\\", \\\"{x:1424,y:569,t:1527023660850};\\\", \\\"{x:1426,y:574,t:1527023660867};\\\", \\\"{x:1428,y:579,t:1527023660884};\\\", \\\"{x:1431,y:583,t:1527023660901};\\\", \\\"{x:1434,y:586,t:1527023660918};\\\", \\\"{x:1436,y:589,t:1527023660934};\\\", \\\"{x:1442,y:590,t:1527023660951};\\\", \\\"{x:1444,y:591,t:1527023660968};\\\", \\\"{x:1447,y:592,t:1527023660985};\\\", \\\"{x:1450,y:593,t:1527023661001};\\\", \\\"{x:1452,y:594,t:1527023661017};\\\", \\\"{x:1453,y:595,t:1527023661051};\\\", \\\"{x:1453,y:601,t:1527023661068};\\\", \\\"{x:1453,y:611,t:1527023661084};\\\", \\\"{x:1450,y:626,t:1527023661101};\\\", \\\"{x:1438,y:647,t:1527023661118};\\\", \\\"{x:1403,y:691,t:1527023661135};\\\", \\\"{x:1337,y:747,t:1527023661150};\\\", \\\"{x:1249,y:799,t:1527023661168};\\\", \\\"{x:1139,y:847,t:1527023661185};\\\", \\\"{x:1033,y:877,t:1527023661200};\\\", \\\"{x:924,y:900,t:1527023661217};\\\", \\\"{x:781,y:923,t:1527023661234};\\\", \\\"{x:707,y:939,t:1527023661251};\\\", \\\"{x:685,y:949,t:1527023661267};\\\", \\\"{x:685,y:950,t:1527023661284};\\\", \\\"{x:676,y:939,t:1527023661651};\\\", \\\"{x:653,y:891,t:1527023661667};\\\", \\\"{x:632,y:837,t:1527023661684};\\\", \\\"{x:617,y:761,t:1527023661702};\\\", \\\"{x:608,y:689,t:1527023661718};\\\", \\\"{x:607,y:643,t:1527023661734};\\\", \\\"{x:600,y:603,t:1527023661751};\\\", \\\"{x:597,y:580,t:1527023661767};\\\", \\\"{x:593,y:560,t:1527023661785};\\\", \\\"{x:592,y:550,t:1527023661801};\\\", \\\"{x:590,y:547,t:1527023661818};\\\", \\\"{x:590,y:544,t:1527023661898};\\\", \\\"{x:589,y:542,t:1527023661906};\\\", \\\"{x:583,y:539,t:1527023661919};\\\", \\\"{x:557,y:534,t:1527023661935};\\\", \\\"{x:509,y:528,t:1527023661952};\\\", \\\"{x:426,y:518,t:1527023661969};\\\", \\\"{x:342,y:516,t:1527023661985};\\\", \\\"{x:238,y:504,t:1527023662002};\\\", \\\"{x:204,y:499,t:1527023662020};\\\", \\\"{x:193,y:499,t:1527023662035};\\\", \\\"{x:191,y:497,t:1527023662052};\\\", \\\"{x:190,y:497,t:1527023662170};\\\", \\\"{x:186,y:497,t:1527023662185};\\\", \\\"{x:172,y:498,t:1527023662203};\\\", \\\"{x:153,y:498,t:1527023662219};\\\", \\\"{x:133,y:498,t:1527023662235};\\\", \\\"{x:122,y:498,t:1527023662252};\\\", \\\"{x:120,y:498,t:1527023662269};\\\", \\\"{x:120,y:499,t:1527023662346};\\\", \\\"{x:120,y:501,t:1527023662354};\\\", \\\"{x:125,y:502,t:1527023662369};\\\", \\\"{x:141,y:506,t:1527023662386};\\\", \\\"{x:170,y:509,t:1527023662402};\\\", \\\"{x:192,y:509,t:1527023662419};\\\", \\\"{x:225,y:509,t:1527023662437};\\\", \\\"{x:258,y:510,t:1527023662453};\\\", \\\"{x:291,y:510,t:1527023662469};\\\", \\\"{x:321,y:510,t:1527023662485};\\\", \\\"{x:347,y:510,t:1527023662501};\\\", \\\"{x:366,y:510,t:1527023662519};\\\", \\\"{x:387,y:510,t:1527023662535};\\\", \\\"{x:401,y:510,t:1527023662552};\\\", \\\"{x:408,y:510,t:1527023662569};\\\", \\\"{x:412,y:510,t:1527023662586};\\\", \\\"{x:414,y:512,t:1527023662602};\\\", \\\"{x:420,y:513,t:1527023662619};\\\", \\\"{x:424,y:514,t:1527023662635};\\\", \\\"{x:439,y:516,t:1527023662653};\\\", \\\"{x:460,y:520,t:1527023662670};\\\", \\\"{x:489,y:525,t:1527023662686};\\\", \\\"{x:531,y:531,t:1527023662703};\\\", \\\"{x:588,y:532,t:1527023662718};\\\", \\\"{x:650,y:536,t:1527023662736};\\\", \\\"{x:714,y:536,t:1527023662751};\\\", \\\"{x:767,y:536,t:1527023662769};\\\", \\\"{x:829,y:536,t:1527023662786};\\\", \\\"{x:857,y:536,t:1527023662802};\\\", \\\"{x:873,y:536,t:1527023662819};\\\", \\\"{x:882,y:533,t:1527023662836};\\\", \\\"{x:885,y:532,t:1527023662852};\\\", \\\"{x:888,y:531,t:1527023662869};\\\", \\\"{x:890,y:529,t:1527023662886};\\\", \\\"{x:892,y:528,t:1527023662902};\\\", \\\"{x:895,y:527,t:1527023662919};\\\", \\\"{x:896,y:526,t:1527023662936};\\\", \\\"{x:896,y:524,t:1527023662995};\\\", \\\"{x:896,y:521,t:1527023663003};\\\", \\\"{x:893,y:519,t:1527023663019};\\\", \\\"{x:891,y:518,t:1527023663037};\\\", \\\"{x:888,y:516,t:1527023663052};\\\", \\\"{x:881,y:514,t:1527023663069};\\\", \\\"{x:875,y:512,t:1527023663087};\\\", \\\"{x:869,y:510,t:1527023663102};\\\", \\\"{x:860,y:507,t:1527023663120};\\\", \\\"{x:854,y:506,t:1527023663136};\\\", \\\"{x:848,y:503,t:1527023663152};\\\", \\\"{x:847,y:503,t:1527023663169};\\\", \\\"{x:846,y:502,t:1527023663186};\\\", \\\"{x:845,y:500,t:1527023663234};\\\", \\\"{x:845,y:499,t:1527023663242};\\\", \\\"{x:842,y:496,t:1527023663253};\\\", \\\"{x:837,y:492,t:1527023663269};\\\", \\\"{x:835,y:489,t:1527023663286};\\\", \\\"{x:831,y:487,t:1527023663303};\\\", \\\"{x:830,y:485,t:1527023663319};\\\", \\\"{x:827,y:486,t:1527023663691};\\\", \\\"{x:827,y:490,t:1527023663703};\\\", \\\"{x:823,y:503,t:1527023663721};\\\", \\\"{x:819,y:517,t:1527023663737};\\\", \\\"{x:810,y:536,t:1527023663753};\\\", \\\"{x:785,y:574,t:1527023663770};\\\", \\\"{x:769,y:599,t:1527023663786};\\\", \\\"{x:748,y:628,t:1527023663802};\\\", \\\"{x:726,y:653,t:1527023663820};\\\", \\\"{x:703,y:672,t:1527023663836};\\\", \\\"{x:681,y:688,t:1527023663853};\\\", \\\"{x:665,y:700,t:1527023663870};\\\", \\\"{x:651,y:709,t:1527023663887};\\\", \\\"{x:639,y:716,t:1527023663903};\\\", \\\"{x:627,y:721,t:1527023663920};\\\", \\\"{x:617,y:726,t:1527023663937};\\\", \\\"{x:609,y:729,t:1527023663953};\\\", \\\"{x:596,y:731,t:1527023663970};\\\", \\\"{x:586,y:732,t:1527023663987};\\\", \\\"{x:573,y:732,t:1527023664003};\\\", \\\"{x:562,y:734,t:1527023664020};\\\", \\\"{x:553,y:734,t:1527023664037};\\\", \\\"{x:545,y:734,t:1527023664053};\\\", \\\"{x:540,y:735,t:1527023664071};\\\", \\\"{x:537,y:735,t:1527023664087};\\\", \\\"{x:534,y:736,t:1527023664103};\\\", \\\"{x:532,y:737,t:1527023664121};\\\", \\\"{x:532,y:738,t:1527023664138};\\\", \\\"{x:530,y:738,t:1527023664154};\\\", \\\"{x:528,y:741,t:1527023664169};\\\", \\\"{x:526,y:745,t:1527023664187};\\\", \\\"{x:524,y:749,t:1527023664204};\\\", \\\"{x:523,y:752,t:1527023664220};\\\", \\\"{x:523,y:754,t:1527023664237};\\\", \\\"{x:521,y:756,t:1527023664253};\\\", \\\"{x:520,y:757,t:1527023664270};\\\", \\\"{x:519,y:759,t:1527023664287};\\\", \\\"{x:517,y:760,t:1527023664304};\\\", \\\"{x:516,y:761,t:1527023664320};\\\", \\\"{x:516,y:762,t:1527023664337};\\\", \\\"{x:515,y:762,t:1527023664354};\\\", \\\"{x:514,y:763,t:1527023664370};\\\", \\\"{x:513,y:764,t:1527023664402};\\\", \\\"{x:512,y:764,t:1527023664418};\\\", \\\"{x:512,y:765,t:1527023664435};\\\", \\\"{x:511,y:765,t:1527023664459};\\\", \\\"{x:509,y:765,t:1527023664474};\\\", \\\"{x:508,y:765,t:1527023664507};\\\", \\\"{x:506,y:765,t:1527023664523};\\\", \\\"{x:505,y:765,t:1527023664537};\\\", \\\"{x:501,y:765,t:1527023664554};\\\", \\\"{x:499,y:765,t:1527023664571};\\\", \\\"{x:495,y:765,t:1527023664587};\\\", \\\"{x:494,y:765,t:1527023664604};\\\", \\\"{x:492,y:765,t:1527023664621};\\\", \\\"{x:491,y:764,t:1527023664637};\\\", \\\"{x:490,y:764,t:1527023664653};\\\", \\\"{x:489,y:762,t:1527023664682};\\\", \\\"{x:489,y:761,t:1527023664698};\\\", \\\"{x:489,y:758,t:1527023664706};\\\", \\\"{x:489,y:755,t:1527023664720};\\\", \\\"{x:489,y:750,t:1527023664737};\\\", \\\"{x:489,y:744,t:1527023664754};\\\", \\\"{x:489,y:738,t:1527023664771};\\\", \\\"{x:490,y:731,t:1527023664788};\\\", \\\"{x:492,y:726,t:1527023664804};\\\", \\\"{x:494,y:721,t:1527023664821};\\\", \\\"{x:495,y:718,t:1527023664837};\\\", \\\"{x:497,y:715,t:1527023664854};\\\", \\\"{x:498,y:713,t:1527023664871};\\\", \\\"{x:501,y:709,t:1527023664887};\\\", \\\"{x:501,y:707,t:1527023664904};\\\", \\\"{x:504,y:704,t:1527023664921};\\\", \\\"{x:505,y:702,t:1527023664937};\\\", \\\"{x:508,y:697,t:1527023664955};\\\", \\\"{x:508,y:695,t:1527023664972};\\\", \\\"{x:509,y:692,t:1527023664987};\\\", \\\"{x:510,y:689,t:1527023665004};\\\", \\\"{x:512,y:686,t:1527023665021};\\\", \\\"{x:513,y:683,t:1527023665038};\\\", \\\"{x:515,y:680,t:1527023665054};\\\", \\\"{x:515,y:678,t:1527023665071};\\\" ] }, { \\\"rt\\\": 14860, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 17, \\\"time_elapsed\\\": 766934, \\\"internal_node_id\\\": \\\"0.0-6.0-7.0\\\", \\\"subject\\\": \\\"QOJ6L\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"hotel\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 13, \\\"clicks\\\": 3, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"E\\\", \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-Z -02 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:536,y:662,t:1527023667377};\\\", \\\"{x:544,y:655,t:1527023667391};\\\", \\\"{x:552,y:645,t:1527023667406};\\\", \\\"{x:563,y:633,t:1527023667423};\\\", \\\"{x:574,y:619,t:1527023667444};\\\", \\\"{x:578,y:614,t:1527023667457};\\\", \\\"{x:583,y:607,t:1527023667472};\\\", \\\"{x:589,y:602,t:1527023667489};\\\", \\\"{x:597,y:597,t:1527023667506};\\\", \\\"{x:603,y:591,t:1527023667522};\\\", \\\"{x:605,y:591,t:1527023667539};\\\", \\\"{x:605,y:590,t:1527023668219};\\\", \\\"{x:605,y:589,t:1527023668227};\\\", \\\"{x:605,y:588,t:1527023668239};\\\", \\\"{x:605,y:586,t:1527023668257};\\\", \\\"{x:605,y:585,t:1527023668274};\\\", \\\"{x:605,y:583,t:1527023668290};\\\", \\\"{x:606,y:581,t:1527023668306};\\\", \\\"{x:606,y:580,t:1527023668323};\\\", \\\"{x:606,y:579,t:1527023668339};\\\", \\\"{x:606,y:578,t:1527023668364};\\\", \\\"{x:606,y:577,t:1527023668466};\\\", \\\"{x:606,y:574,t:1527023668482};\\\", \\\"{x:606,y:573,t:1527023668497};\\\", \\\"{x:606,y:572,t:1527023668513};\\\", \\\"{x:606,y:571,t:1527023668524};\\\", \\\"{x:606,y:569,t:1527023668626};\\\", \\\"{x:609,y:567,t:1527023668640};\\\", \\\"{x:625,y:563,t:1527023668658};\\\", \\\"{x:648,y:563,t:1527023668676};\\\", \\\"{x:677,y:566,t:1527023668690};\\\", \\\"{x:755,y:577,t:1527023668709};\\\", \\\"{x:863,y:593,t:1527023668724};\\\", \\\"{x:985,y:612,t:1527023668741};\\\", \\\"{x:1113,y:618,t:1527023668757};\\\", \\\"{x:1237,y:626,t:1527023668774};\\\", \\\"{x:1326,y:642,t:1527023668790};\\\", \\\"{x:1375,y:651,t:1527023668807};\\\", \\\"{x:1412,y:663,t:1527023668824};\\\", \\\"{x:1437,y:669,t:1527023668841};\\\", \\\"{x:1454,y:672,t:1527023668858};\\\", \\\"{x:1457,y:672,t:1527023668874};\\\", \\\"{x:1457,y:671,t:1527023668890};\\\", \\\"{x:1458,y:671,t:1527023669227};\\\", \\\"{x:1459,y:669,t:1527023669242};\\\", \\\"{x:1459,y:666,t:1527023669259};\\\", \\\"{x:1461,y:661,t:1527023669274};\\\", \\\"{x:1461,y:658,t:1527023669292};\\\", \\\"{x:1463,y:656,t:1527023669309};\\\", \\\"{x:1465,y:654,t:1527023669330};\\\", \\\"{x:1466,y:653,t:1527023669342};\\\", \\\"{x:1467,y:652,t:1527023669358};\\\", \\\"{x:1467,y:651,t:1527023669375};\\\", \\\"{x:1468,y:650,t:1527023669392};\\\", \\\"{x:1470,y:648,t:1527023669408};\\\", \\\"{x:1473,y:647,t:1527023669425};\\\", \\\"{x:1475,y:646,t:1527023669442};\\\", \\\"{x:1477,y:644,t:1527023669459};\\\", \\\"{x:1478,y:643,t:1527023669475};\\\", \\\"{x:1480,y:642,t:1527023669492};\\\", \\\"{x:1482,y:641,t:1527023669509};\\\", \\\"{x:1483,y:640,t:1527023669531};\\\", \\\"{x:1484,y:640,t:1527023669542};\\\", \\\"{x:1485,y:639,t:1527023669558};\\\", \\\"{x:1487,y:639,t:1527023669575};\\\", \\\"{x:1489,y:637,t:1527023669592};\\\", \\\"{x:1494,y:637,t:1527023669608};\\\", \\\"{x:1502,y:636,t:1527023669625};\\\", \\\"{x:1509,y:636,t:1527023669641};\\\", \\\"{x:1517,y:636,t:1527023669657};\\\", \\\"{x:1525,y:636,t:1527023669674};\\\", \\\"{x:1538,y:636,t:1527023669691};\\\", \\\"{x:1549,y:638,t:1527023669708};\\\", \\\"{x:1562,y:639,t:1527023669724};\\\", \\\"{x:1572,y:640,t:1527023669741};\\\", \\\"{x:1580,y:642,t:1527023669759};\\\", \\\"{x:1584,y:642,t:1527023669775};\\\", \\\"{x:1587,y:642,t:1527023669791};\\\", \\\"{x:1592,y:642,t:1527023671835};\\\", \\\"{x:1600,y:642,t:1527023671844};\\\", \\\"{x:1611,y:642,t:1527023671863};\\\", \\\"{x:1620,y:642,t:1527023671876};\\\", \\\"{x:1626,y:642,t:1527023671894};\\\", \\\"{x:1628,y:642,t:1527023671910};\\\", \\\"{x:1629,y:642,t:1527023671926};\\\", \\\"{x:1630,y:643,t:1527023671944};\\\", \\\"{x:1628,y:643,t:1527023672163};\\\", \\\"{x:1626,y:644,t:1527023672282};\\\", \\\"{x:1625,y:644,t:1527023672370};\\\", \\\"{x:1625,y:645,t:1527023672393};\\\", \\\"{x:1624,y:645,t:1527023672411};\\\", \\\"{x:1623,y:646,t:1527023672450};\\\", \\\"{x:1622,y:646,t:1527023672482};\\\", \\\"{x:1621,y:646,t:1527023672563};\\\", \\\"{x:1620,y:648,t:1527023672651};\\\", \\\"{x:1620,y:651,t:1527023672661};\\\", \\\"{x:1613,y:659,t:1527023672678};\\\", \\\"{x:1606,y:669,t:1527023672695};\\\", \\\"{x:1597,y:688,t:1527023672711};\\\", \\\"{x:1582,y:713,t:1527023672728};\\\", \\\"{x:1561,y:746,t:1527023672745};\\\", \\\"{x:1546,y:782,t:1527023672761};\\\", \\\"{x:1537,y:806,t:1527023672778};\\\", \\\"{x:1530,y:827,t:1527023672794};\\\", \\\"{x:1523,y:853,t:1527023672811};\\\", \\\"{x:1521,y:868,t:1527023672828};\\\", \\\"{x:1521,y:880,t:1527023672845};\\\", \\\"{x:1521,y:893,t:1527023672861};\\\", \\\"{x:1521,y:903,t:1527023672878};\\\", \\\"{x:1520,y:911,t:1527023672896};\\\", \\\"{x:1518,y:918,t:1527023672911};\\\", \\\"{x:1517,y:923,t:1527023672928};\\\", \\\"{x:1516,y:927,t:1527023672945};\\\", \\\"{x:1514,y:930,t:1527023672962};\\\", \\\"{x:1513,y:931,t:1527023672978};\\\", \\\"{x:1512,y:933,t:1527023672995};\\\", \\\"{x:1510,y:934,t:1527023673012};\\\", \\\"{x:1504,y:937,t:1527023673027};\\\", \\\"{x:1501,y:938,t:1527023673045};\\\", \\\"{x:1498,y:938,t:1527023673062};\\\", \\\"{x:1494,y:938,t:1527023673078};\\\", \\\"{x:1490,y:938,t:1527023673095};\\\", \\\"{x:1489,y:938,t:1527023673112};\\\", \\\"{x:1487,y:938,t:1527023673128};\\\", \\\"{x:1486,y:938,t:1527023673145};\\\", \\\"{x:1483,y:937,t:1527023673162};\\\", \\\"{x:1483,y:936,t:1527023673178};\\\", \\\"{x:1482,y:931,t:1527023673195};\\\", \\\"{x:1481,y:929,t:1527023673212};\\\", \\\"{x:1480,y:926,t:1527023673228};\\\", \\\"{x:1480,y:924,t:1527023673245};\\\", \\\"{x:1480,y:923,t:1527023673262};\\\", \\\"{x:1479,y:923,t:1527023673291};\\\", \\\"{x:1479,y:921,t:1527023673331};\\\", \\\"{x:1479,y:920,t:1527023673563};\\\", \\\"{x:1479,y:919,t:1527023673579};\\\", \\\"{x:1479,y:918,t:1527023673595};\\\", \\\"{x:1479,y:917,t:1527023673612};\\\", \\\"{x:1478,y:916,t:1527023674578};\\\", \\\"{x:1477,y:916,t:1527023674596};\\\", \\\"{x:1476,y:916,t:1527023674634};\\\", \\\"{x:1477,y:916,t:1527023675210};\\\", \\\"{x:1479,y:916,t:1527023675235};\\\", \\\"{x:1481,y:914,t:1527023675248};\\\", \\\"{x:1481,y:913,t:1527023675263};\\\", \\\"{x:1484,y:911,t:1527023675280};\\\", \\\"{x:1485,y:910,t:1527023675297};\\\", \\\"{x:1486,y:908,t:1527023675314};\\\", \\\"{x:1487,y:907,t:1527023675331};\\\", \\\"{x:1487,y:906,t:1527023675347};\\\", \\\"{x:1487,y:905,t:1527023675363};\\\", \\\"{x:1489,y:905,t:1527023675683};\\\", \\\"{x:1488,y:905,t:1527023675851};\\\", \\\"{x:1486,y:905,t:1527023675865};\\\", \\\"{x:1480,y:905,t:1527023675881};\\\", \\\"{x:1474,y:905,t:1527023675898};\\\", \\\"{x:1469,y:907,t:1527023675915};\\\", \\\"{x:1468,y:907,t:1527023675931};\\\", \\\"{x:1465,y:909,t:1527023675947};\\\", \\\"{x:1464,y:909,t:1527023675970};\\\", \\\"{x:1463,y:909,t:1527023675987};\\\", \\\"{x:1462,y:909,t:1527023676019};\\\", \\\"{x:1461,y:909,t:1527023676050};\\\", \\\"{x:1460,y:909,t:1527023676064};\\\", \\\"{x:1459,y:909,t:1527023676171};\\\", \\\"{x:1459,y:908,t:1527023676186};\\\", \\\"{x:1460,y:908,t:1527023676202};\\\", \\\"{x:1461,y:908,t:1527023676215};\\\", \\\"{x:1463,y:907,t:1527023676231};\\\", \\\"{x:1465,y:906,t:1527023676248};\\\", \\\"{x:1466,y:905,t:1527023676264};\\\", \\\"{x:1467,y:904,t:1527023676282};\\\", \\\"{x:1472,y:901,t:1527023676298};\\\", \\\"{x:1483,y:894,t:1527023676315};\\\", \\\"{x:1498,y:879,t:1527023676331};\\\", \\\"{x:1516,y:861,t:1527023676348};\\\", \\\"{x:1539,y:830,t:1527023676364};\\\", \\\"{x:1560,y:797,t:1527023676381};\\\", \\\"{x:1590,y:745,t:1527023676398};\\\", \\\"{x:1619,y:669,t:1527023676415};\\\", \\\"{x:1644,y:593,t:1527023676431};\\\", \\\"{x:1657,y:558,t:1527023676449};\\\", \\\"{x:1662,y:541,t:1527023676465};\\\", \\\"{x:1665,y:530,t:1527023676481};\\\", \\\"{x:1668,y:521,t:1527023676498};\\\", \\\"{x:1665,y:524,t:1527023676683};\\\", \\\"{x:1648,y:544,t:1527023676698};\\\", \\\"{x:1606,y:587,t:1527023676715};\\\", \\\"{x:1533,y:647,t:1527023676731};\\\", \\\"{x:1428,y:717,t:1527023676748};\\\", \\\"{x:1295,y:780,t:1527023676764};\\\", \\\"{x:1132,y:820,t:1527023676780};\\\", \\\"{x:962,y:838,t:1527023676798};\\\", \\\"{x:765,y:838,t:1527023676815};\\\", \\\"{x:580,y:838,t:1527023676830};\\\", \\\"{x:416,y:830,t:1527023676848};\\\", \\\"{x:289,y:798,t:1527023676864};\\\", \\\"{x:204,y:764,t:1527023676881};\\\", \\\"{x:151,y:728,t:1527023676897};\\\", \\\"{x:137,y:715,t:1527023676914};\\\", \\\"{x:131,y:709,t:1527023676930};\\\", \\\"{x:129,y:706,t:1527023676947};\\\", \\\"{x:129,y:703,t:1527023676965};\\\", \\\"{x:129,y:698,t:1527023676980};\\\", \\\"{x:142,y:685,t:1527023676998};\\\", \\\"{x:169,y:667,t:1527023677015};\\\", \\\"{x:183,y:653,t:1527023677031};\\\", \\\"{x:189,y:644,t:1527023677048};\\\", \\\"{x:197,y:637,t:1527023677065};\\\", \\\"{x:206,y:630,t:1527023677082};\\\", \\\"{x:213,y:626,t:1527023677098};\\\", \\\"{x:218,y:625,t:1527023677115};\\\", \\\"{x:233,y:621,t:1527023677132};\\\", \\\"{x:246,y:614,t:1527023677149};\\\", \\\"{x:266,y:604,t:1527023677165};\\\", \\\"{x:285,y:593,t:1527023677182};\\\", \\\"{x:300,y:584,t:1527023677197};\\\", \\\"{x:314,y:573,t:1527023677214};\\\", \\\"{x:331,y:561,t:1527023677231};\\\", \\\"{x:353,y:545,t:1527023677248};\\\", \\\"{x:375,y:530,t:1527023677265};\\\", \\\"{x:394,y:518,t:1527023677281};\\\", \\\"{x:420,y:503,t:1527023677297};\\\", \\\"{x:439,y:494,t:1527023677315};\\\", \\\"{x:459,y:487,t:1527023677331};\\\", \\\"{x:481,y:477,t:1527023677347};\\\", \\\"{x:506,y:466,t:1527023677365};\\\", \\\"{x:531,y:460,t:1527023677382};\\\", \\\"{x:545,y:456,t:1527023677397};\\\", \\\"{x:552,y:454,t:1527023677415};\\\", \\\"{x:561,y:451,t:1527023677432};\\\", \\\"{x:568,y:449,t:1527023677448};\\\", \\\"{x:575,y:445,t:1527023677465};\\\", \\\"{x:581,y:441,t:1527023677481};\\\", \\\"{x:582,y:440,t:1527023677497};\\\", \\\"{x:584,y:439,t:1527023677514};\\\", \\\"{x:584,y:438,t:1527023677532};\\\", \\\"{x:585,y:437,t:1527023677548};\\\", \\\"{x:587,y:437,t:1527023677565};\\\", \\\"{x:587,y:436,t:1527023677619};\\\", \\\"{x:588,y:436,t:1527023677634};\\\", \\\"{x:588,y:435,t:1527023677651};\\\", \\\"{x:589,y:435,t:1527023677665};\\\", \\\"{x:590,y:435,t:1527023677739};\\\", \\\"{x:591,y:435,t:1527023677748};\\\", \\\"{x:592,y:435,t:1527023677803};\\\", \\\"{x:592,y:434,t:1527023677875};\\\", \\\"{x:593,y:433,t:1527023677932};\\\", \\\"{x:594,y:433,t:1527023677949};\\\", \\\"{x:595,y:433,t:1527023678090};\\\", \\\"{x:596,y:434,t:1527023678107};\\\", \\\"{x:596,y:436,t:1527023678267};\\\", \\\"{x:596,y:437,t:1527023678282};\\\", \\\"{x:597,y:439,t:1527023678299};\\\", \\\"{x:602,y:440,t:1527023678563};\\\", \\\"{x:628,y:447,t:1527023678583};\\\", \\\"{x:659,y:453,t:1527023678600};\\\", \\\"{x:715,y:461,t:1527023678615};\\\", \\\"{x:768,y:469,t:1527023678633};\\\", \\\"{x:811,y:470,t:1527023678648};\\\", \\\"{x:854,y:475,t:1527023678667};\\\", \\\"{x:861,y:476,t:1527023678683};\\\", \\\"{x:862,y:476,t:1527023678762};\\\", \\\"{x:863,y:476,t:1527023678778};\\\", \\\"{x:863,y:475,t:1527023678785};\\\", \\\"{x:863,y:474,t:1527023678802};\\\", \\\"{x:863,y:473,t:1527023678818};\\\", \\\"{x:863,y:472,t:1527023678833};\\\", \\\"{x:863,y:471,t:1527023678858};\\\", \\\"{x:863,y:470,t:1527023678874};\\\", \\\"{x:863,y:469,t:1527023678882};\\\", \\\"{x:863,y:468,t:1527023678905};\\\", \\\"{x:863,y:467,t:1527023678916};\\\", \\\"{x:863,y:466,t:1527023678932};\\\", \\\"{x:862,y:464,t:1527023678950};\\\", \\\"{x:858,y:464,t:1527023678966};\\\", \\\"{x:853,y:463,t:1527023678982};\\\", \\\"{x:851,y:463,t:1527023678999};\\\", \\\"{x:850,y:462,t:1527023679016};\\\", \\\"{x:848,y:462,t:1527023679283};\\\", \\\"{x:837,y:462,t:1527023679300};\\\", \\\"{x:818,y:462,t:1527023679316};\\\", \\\"{x:790,y:462,t:1527023679333};\\\", \\\"{x:743,y:462,t:1527023679349};\\\", \\\"{x:685,y:462,t:1527023679367};\\\", \\\"{x:623,y:452,t:1527023679383};\\\", \\\"{x:581,y:446,t:1527023679400};\\\", \\\"{x:554,y:442,t:1527023679417};\\\", \\\"{x:541,y:441,t:1527023679433};\\\", \\\"{x:536,y:439,t:1527023679450};\\\", \\\"{x:535,y:439,t:1527023679466};\\\", \\\"{x:538,y:439,t:1527023679595};\\\", \\\"{x:544,y:439,t:1527023679602};\\\", \\\"{x:551,y:439,t:1527023679616};\\\", \\\"{x:569,y:439,t:1527023679633};\\\", \\\"{x:598,y:443,t:1527023679651};\\\", \\\"{x:608,y:444,t:1527023679667};\\\", \\\"{x:611,y:444,t:1527023679682};\\\", \\\"{x:612,y:444,t:1527023679699};\\\", \\\"{x:613,y:444,t:1527023680002};\\\", \\\"{x:614,y:444,t:1527023680017};\\\", \\\"{x:620,y:444,t:1527023680033};\\\", \\\"{x:625,y:444,t:1527023680050};\\\", \\\"{x:630,y:444,t:1527023680067};\\\", \\\"{x:637,y:444,t:1527023680084};\\\", \\\"{x:656,y:447,t:1527023680100};\\\", \\\"{x:681,y:452,t:1527023680117};\\\", \\\"{x:707,y:454,t:1527023680134};\\\", \\\"{x:732,y:459,t:1527023680150};\\\", \\\"{x:758,y:461,t:1527023680166};\\\", \\\"{x:781,y:464,t:1527023680183};\\\", \\\"{x:796,y:466,t:1527023680201};\\\", \\\"{x:802,y:466,t:1527023680217};\\\", \\\"{x:804,y:466,t:1527023680234};\\\", \\\"{x:805,y:466,t:1527023680339};\\\", \\\"{x:807,y:465,t:1527023680351};\\\", \\\"{x:809,y:464,t:1527023680387};\\\", \\\"{x:810,y:463,t:1527023680400};\\\", \\\"{x:813,y:461,t:1527023680417};\\\", \\\"{x:818,y:458,t:1527023680433};\\\", \\\"{x:819,y:458,t:1527023680451};\\\", \\\"{x:820,y:457,t:1527023680467};\\\", \\\"{x:822,y:456,t:1527023680484};\\\", \\\"{x:824,y:455,t:1527023680501};\\\", \\\"{x:825,y:455,t:1527023680518};\\\", \\\"{x:825,y:453,t:1527023680538};\\\", \\\"{x:826,y:453,t:1527023680551};\\\", \\\"{x:827,y:453,t:1527023680586};\\\", \\\"{x:827,y:454,t:1527023680866};\\\", \\\"{x:825,y:459,t:1527023680874};\\\", \\\"{x:823,y:463,t:1527023680884};\\\", \\\"{x:822,y:465,t:1527023680902};\\\", \\\"{x:822,y:466,t:1527023680917};\\\", \\\"{x:821,y:467,t:1527023680933};\\\", \\\"{x:817,y:474,t:1527023680951};\\\", \\\"{x:795,y:496,t:1527023680968};\\\", \\\"{x:743,y:537,t:1527023680985};\\\", \\\"{x:681,y:587,t:1527023681002};\\\", \\\"{x:581,y:655,t:1527023681017};\\\", \\\"{x:528,y:687,t:1527023681035};\\\", \\\"{x:484,y:716,t:1527023681051};\\\", \\\"{x:454,y:732,t:1527023681067};\\\", \\\"{x:438,y:741,t:1527023681084};\\\", \\\"{x:431,y:744,t:1527023681101};\\\", \\\"{x:429,y:744,t:1527023681117};\\\", \\\"{x:428,y:744,t:1527023681227};\\\", \\\"{x:429,y:741,t:1527023681235};\\\", \\\"{x:434,y:736,t:1527023681250};\\\", \\\"{x:441,y:730,t:1527023681267};\\\", \\\"{x:453,y:722,t:1527023681284};\\\", \\\"{x:469,y:715,t:1527023681300};\\\", \\\"{x:479,y:709,t:1527023681317};\\\", \\\"{x:486,y:706,t:1527023681333};\\\", \\\"{x:490,y:704,t:1527023681350};\\\", \\\"{x:494,y:702,t:1527023681368};\\\", \\\"{x:496,y:702,t:1527023681386};\\\", \\\"{x:496,y:701,t:1527023681401};\\\", \\\"{x:498,y:701,t:1527023681416};\\\", \\\"{x:498,y:700,t:1527023681435};\\\", \\\"{x:499,y:699,t:1527023682426};\\\", \\\"{x:501,y:699,t:1527023682434};\\\", \\\"{x:522,y:693,t:1527023682452};\\\", \\\"{x:548,y:686,t:1527023682468};\\\", \\\"{x:577,y:671,t:1527023682485};\\\", \\\"{x:589,y:663,t:1527023682502};\\\" ] }, { \\\"rt\\\": 12841, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 18, \\\"time_elapsed\\\": 780992, \\\"internal_node_id\\\": \\\"0.0-6.0-8.0\\\", \\\"subject\\\": \\\"QOJ6L\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"hotel\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 14, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-03 PM-X \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:590,y:663,t:1527023683363};\\\", \\\"{x:590,y:661,t:1527023683387};\\\", \\\"{x:592,y:660,t:1527023683683};\\\", \\\"{x:592,y:659,t:1527023683690};\\\", \\\"{x:592,y:658,t:1527023683703};\\\", \\\"{x:592,y:655,t:1527023683720};\\\", \\\"{x:593,y:654,t:1527023683736};\\\", \\\"{x:593,y:652,t:1527023683753};\\\", \\\"{x:593,y:651,t:1527023683769};\\\", \\\"{x:593,y:650,t:1527023683786};\\\", \\\"{x:593,y:649,t:1527023683817};\\\", \\\"{x:593,y:648,t:1527023683849};\\\", \\\"{x:593,y:647,t:1527023683858};\\\", \\\"{x:593,y:646,t:1527023683871};\\\", \\\"{x:593,y:645,t:1527023683890};\\\", \\\"{x:593,y:642,t:1527023684251};\\\", \\\"{x:593,y:639,t:1527023684258};\\\", \\\"{x:593,y:638,t:1527023684270};\\\", \\\"{x:593,y:634,t:1527023684288};\\\", \\\"{x:593,y:632,t:1527023684304};\\\", \\\"{x:593,y:629,t:1527023684321};\\\", \\\"{x:593,y:627,t:1527023684337};\\\", \\\"{x:594,y:625,t:1527023684355};\\\", \\\"{x:594,y:623,t:1527023684371};\\\", \\\"{x:595,y:621,t:1527023684395};\\\", \\\"{x:595,y:620,t:1527023684405};\\\", \\\"{x:596,y:619,t:1527023684420};\\\", \\\"{x:596,y:617,t:1527023684438};\\\", \\\"{x:596,y:616,t:1527023684455};\\\", \\\"{x:596,y:613,t:1527023684470};\\\", \\\"{x:597,y:612,t:1527023684487};\\\", \\\"{x:598,y:611,t:1527023684506};\\\", \\\"{x:600,y:610,t:1527023684747};\\\", \\\"{x:602,y:609,t:1527023684754};\\\", \\\"{x:606,y:609,t:1527023684770};\\\", \\\"{x:608,y:609,t:1527023684786};\\\", \\\"{x:609,y:609,t:1527023684804};\\\", \\\"{x:611,y:609,t:1527023684821};\\\", \\\"{x:616,y:609,t:1527023684836};\\\", \\\"{x:620,y:610,t:1527023684853};\\\", \\\"{x:623,y:610,t:1527023684871};\\\", \\\"{x:624,y:610,t:1527023687739};\\\", \\\"{x:628,y:610,t:1527023687747};\\\", \\\"{x:637,y:610,t:1527023687756};\\\", \\\"{x:649,y:610,t:1527023687773};\\\", \\\"{x:667,y:610,t:1527023687790};\\\", \\\"{x:703,y:610,t:1527023687807};\\\", \\\"{x:738,y:610,t:1527023687823};\\\", \\\"{x:792,y:610,t:1527023687841};\\\", \\\"{x:870,y:610,t:1527023687856};\\\", \\\"{x:942,y:610,t:1527023687873};\\\", \\\"{x:1029,y:610,t:1527023687891};\\\", \\\"{x:1086,y:605,t:1527023687907};\\\", \\\"{x:1136,y:599,t:1527023687924};\\\", \\\"{x:1170,y:597,t:1527023687941};\\\", \\\"{x:1194,y:595,t:1527023687957};\\\", \\\"{x:1195,y:595,t:1527023688523};\\\", \\\"{x:1197,y:595,t:1527023688763};\\\", \\\"{x:1199,y:597,t:1527023688774};\\\", \\\"{x:1209,y:603,t:1527023688791};\\\", \\\"{x:1220,y:609,t:1527023688808};\\\", \\\"{x:1235,y:614,t:1527023688824};\\\", \\\"{x:1251,y:620,t:1527023688841};\\\", \\\"{x:1276,y:627,t:1527023688858};\\\", \\\"{x:1284,y:630,t:1527023688874};\\\", \\\"{x:1302,y:636,t:1527023688891};\\\", \\\"{x:1309,y:636,t:1527023688908};\\\", \\\"{x:1311,y:636,t:1527023688925};\\\", \\\"{x:1311,y:637,t:1527023689411};\\\", \\\"{x:1311,y:638,t:1527023689425};\\\", \\\"{x:1311,y:639,t:1527023689442};\\\", \\\"{x:1310,y:641,t:1527023689459};\\\", \\\"{x:1309,y:642,t:1527023689475};\\\", \\\"{x:1309,y:643,t:1527023689595};\\\", \\\"{x:1309,y:645,t:1527023689609};\\\", \\\"{x:1309,y:648,t:1527023689626};\\\", \\\"{x:1309,y:652,t:1527023689642};\\\", \\\"{x:1309,y:656,t:1527023689658};\\\", \\\"{x:1311,y:674,t:1527023689675};\\\", \\\"{x:1313,y:684,t:1527023689692};\\\", \\\"{x:1317,y:698,t:1527023689709};\\\", \\\"{x:1322,y:710,t:1527023689725};\\\", \\\"{x:1328,y:720,t:1527023689742};\\\", \\\"{x:1334,y:729,t:1527023689759};\\\", \\\"{x:1336,y:732,t:1527023689775};\\\", \\\"{x:1338,y:738,t:1527023689792};\\\", \\\"{x:1340,y:747,t:1527023689808};\\\", \\\"{x:1344,y:757,t:1527023689825};\\\", \\\"{x:1351,y:775,t:1527023689842};\\\", \\\"{x:1354,y:782,t:1527023689858};\\\", \\\"{x:1360,y:790,t:1527023689875};\\\", \\\"{x:1369,y:799,t:1527023689892};\\\", \\\"{x:1378,y:807,t:1527023689909};\\\", \\\"{x:1394,y:815,t:1527023689925};\\\", \\\"{x:1413,y:823,t:1527023689941};\\\", \\\"{x:1434,y:829,t:1527023689959};\\\", \\\"{x:1460,y:834,t:1527023689975};\\\", \\\"{x:1487,y:844,t:1527023689992};\\\", \\\"{x:1513,y:846,t:1527023690009};\\\", \\\"{x:1538,y:850,t:1527023690026};\\\", \\\"{x:1556,y:853,t:1527023690042};\\\", \\\"{x:1582,y:857,t:1527023690059};\\\", \\\"{x:1597,y:860,t:1527023690076};\\\", \\\"{x:1607,y:862,t:1527023690092};\\\", \\\"{x:1614,y:862,t:1527023690109};\\\", \\\"{x:1619,y:862,t:1527023690126};\\\", \\\"{x:1625,y:862,t:1527023690142};\\\", \\\"{x:1626,y:862,t:1527023690227};\\\", \\\"{x:1626,y:863,t:1527023690242};\\\", \\\"{x:1626,y:865,t:1527023690267};\\\", \\\"{x:1625,y:867,t:1527023690275};\\\", \\\"{x:1623,y:869,t:1527023690292};\\\", \\\"{x:1614,y:873,t:1527023690309};\\\", \\\"{x:1607,y:877,t:1527023690326};\\\", \\\"{x:1596,y:881,t:1527023690342};\\\", \\\"{x:1586,y:882,t:1527023690359};\\\", \\\"{x:1575,y:882,t:1527023690375};\\\", \\\"{x:1563,y:885,t:1527023690392};\\\", \\\"{x:1559,y:888,t:1527023690409};\\\", \\\"{x:1556,y:889,t:1527023690427};\\\", \\\"{x:1554,y:890,t:1527023690442};\\\", \\\"{x:1552,y:890,t:1527023690459};\\\", \\\"{x:1552,y:891,t:1527023690476};\\\", \\\"{x:1551,y:891,t:1527023690493};\\\", \\\"{x:1551,y:892,t:1527023690509};\\\", \\\"{x:1551,y:894,t:1527023690538};\\\", \\\"{x:1551,y:895,t:1527023690562};\\\", \\\"{x:1551,y:897,t:1527023690578};\\\", \\\"{x:1551,y:898,t:1527023690643};\\\", \\\"{x:1551,y:900,t:1527023690683};\\\", \\\"{x:1551,y:901,t:1527023690739};\\\", \\\"{x:1551,y:902,t:1527023690763};\\\", \\\"{x:1551,y:903,t:1527023690776};\\\", \\\"{x:1551,y:904,t:1527023690810};\\\", \\\"{x:1551,y:905,t:1527023690827};\\\", \\\"{x:1551,y:906,t:1527023690843};\\\", \\\"{x:1552,y:907,t:1527023690923};\\\", \\\"{x:1553,y:907,t:1527023690931};\\\", \\\"{x:1553,y:908,t:1527023690962};\\\", \\\"{x:1553,y:909,t:1527023690995};\\\", \\\"{x:1553,y:910,t:1527023691491};\\\", \\\"{x:1553,y:912,t:1527023691507};\\\", \\\"{x:1553,y:913,t:1527023691530};\\\", \\\"{x:1553,y:914,t:1527023691546};\\\", \\\"{x:1553,y:915,t:1527023691560};\\\", \\\"{x:1553,y:916,t:1527023691577};\\\", \\\"{x:1553,y:917,t:1527023691771};\\\", \\\"{x:1553,y:916,t:1527023691786};\\\", \\\"{x:1552,y:915,t:1527023691795};\\\", \\\"{x:1551,y:914,t:1527023691874};\\\", \\\"{x:1548,y:913,t:1527023692140};\\\", \\\"{x:1547,y:913,t:1527023692162};\\\", \\\"{x:1546,y:913,t:1527023692176};\\\", \\\"{x:1545,y:912,t:1527023692259};\\\", \\\"{x:1544,y:911,t:1527023692474};\\\", \\\"{x:1543,y:909,t:1527023692482};\\\", \\\"{x:1543,y:908,t:1527023692493};\\\", \\\"{x:1541,y:904,t:1527023692510};\\\", \\\"{x:1541,y:898,t:1527023692527};\\\", \\\"{x:1537,y:892,t:1527023692543};\\\", \\\"{x:1534,y:882,t:1527023692561};\\\", \\\"{x:1532,y:870,t:1527023692577};\\\", \\\"{x:1527,y:854,t:1527023692593};\\\", \\\"{x:1517,y:823,t:1527023692611};\\\", \\\"{x:1511,y:807,t:1527023692627};\\\", \\\"{x:1507,y:798,t:1527023692644};\\\", \\\"{x:1503,y:790,t:1527023692661};\\\", \\\"{x:1501,y:783,t:1527023692677};\\\", \\\"{x:1499,y:778,t:1527023692694};\\\", \\\"{x:1497,y:775,t:1527023692711};\\\", \\\"{x:1497,y:773,t:1527023692728};\\\", \\\"{x:1496,y:773,t:1527023692744};\\\", \\\"{x:1495,y:773,t:1527023693235};\\\", \\\"{x:1494,y:773,t:1527023693245};\\\", \\\"{x:1491,y:773,t:1527023693261};\\\", \\\"{x:1488,y:775,t:1527023693278};\\\", \\\"{x:1486,y:775,t:1527023693297};\\\", \\\"{x:1484,y:776,t:1527023693490};\\\", \\\"{x:1476,y:777,t:1527023693498};\\\", \\\"{x:1461,y:777,t:1527023693511};\\\", \\\"{x:1421,y:777,t:1527023693528};\\\", \\\"{x:1313,y:764,t:1527023693545};\\\", \\\"{x:1111,y:730,t:1527023693561};\\\", \\\"{x:1057,y:723,t:1527023693578};\\\", \\\"{x:1042,y:721,t:1527023693595};\\\", \\\"{x:1040,y:721,t:1527023693939};\\\", \\\"{x:1035,y:714,t:1527023693946};\\\", \\\"{x:1023,y:698,t:1527023693962};\\\", \\\"{x:1007,y:675,t:1527023693979};\\\", \\\"{x:988,y:652,t:1527023693995};\\\", \\\"{x:953,y:619,t:1527023694012};\\\", \\\"{x:902,y:582,t:1527023694029};\\\", \\\"{x:823,y:536,t:1527023694046};\\\", \\\"{x:742,y:497,t:1527023694061};\\\", \\\"{x:629,y:457,t:1527023694095};\\\", \\\"{x:609,y:447,t:1527023694112};\\\", \\\"{x:605,y:444,t:1527023694128};\\\", \\\"{x:604,y:444,t:1527023694153};\\\", \\\"{x:600,y:444,t:1527023694161};\\\", \\\"{x:578,y:452,t:1527023694179};\\\", \\\"{x:530,y:460,t:1527023694195};\\\", \\\"{x:463,y:468,t:1527023694211};\\\", \\\"{x:411,y:473,t:1527023694228};\\\", \\\"{x:372,y:478,t:1527023694245};\\\", \\\"{x:340,y:478,t:1527023694261};\\\", \\\"{x:322,y:480,t:1527023694278};\\\", \\\"{x:317,y:483,t:1527023694295};\\\", \\\"{x:317,y:486,t:1527023694311};\\\", \\\"{x:328,y:497,t:1527023694328};\\\", \\\"{x:382,y:510,t:1527023694347};\\\", \\\"{x:435,y:516,t:1527023694361};\\\", \\\"{x:486,y:524,t:1527023694378};\\\", \\\"{x:530,y:530,t:1527023694396};\\\", \\\"{x:562,y:531,t:1527023694412};\\\", \\\"{x:588,y:531,t:1527023694428};\\\", \\\"{x:607,y:531,t:1527023694446};\\\", \\\"{x:616,y:531,t:1527023694461};\\\", \\\"{x:620,y:531,t:1527023694479};\\\", \\\"{x:623,y:531,t:1527023694496};\\\", \\\"{x:623,y:532,t:1527023695166};\\\", \\\"{x:621,y:543,t:1527023695185};\\\", \\\"{x:614,y:568,t:1527023695200};\\\", \\\"{x:606,y:602,t:1527023695216};\\\", \\\"{x:600,y:646,t:1527023695233};\\\", \\\"{x:586,y:697,t:1527023695249};\\\", \\\"{x:577,y:723,t:1527023695267};\\\", \\\"{x:570,y:738,t:1527023695283};\\\", \\\"{x:567,y:742,t:1527023695300};\\\", \\\"{x:566,y:743,t:1527023695317};\\\", \\\"{x:565,y:743,t:1527023695375};\\\", \\\"{x:564,y:740,t:1527023695383};\\\", \\\"{x:559,y:726,t:1527023695400};\\\", \\\"{x:556,y:720,t:1527023695416};\\\", \\\"{x:549,y:710,t:1527023695434};\\\", \\\"{x:544,y:705,t:1527023695450};\\\", \\\"{x:540,y:700,t:1527023695467};\\\", \\\"{x:537,y:697,t:1527023695483};\\\", \\\"{x:534,y:693,t:1527023695500};\\\", \\\"{x:532,y:690,t:1527023695517};\\\", \\\"{x:530,y:690,t:1527023696214};\\\", \\\"{x:527,y:690,t:1527023696230};\\\", \\\"{x:523,y:689,t:1527023696238};\\\", \\\"{x:517,y:689,t:1527023696250};\\\", \\\"{x:500,y:685,t:1527023696267};\\\", \\\"{x:479,y:680,t:1527023696284};\\\", \\\"{x:464,y:679,t:1527023696300};\\\", \\\"{x:447,y:676,t:1527023696317};\\\", \\\"{x:442,y:675,t:1527023696334};\\\", \\\"{x:440,y:674,t:1527023696350};\\\", \\\"{x:438,y:673,t:1527023696462};\\\", \\\"{x:437,y:672,t:1527023696470};\\\", \\\"{x:436,y:672,t:1527023696484};\\\", \\\"{x:433,y:671,t:1527023696500};\\\", \\\"{x:431,y:670,t:1527023696518};\\\", \\\"{x:430,y:669,t:1527023696535};\\\" ] }, { \\\"rt\\\": 16906, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 19, \\\"time_elapsed\\\": 799150, \\\"internal_node_id\\\": \\\"0.0-6.0-9.0\\\", \\\"subject\\\": \\\"QOJ6L\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"hotel\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 15, \\\"clicks\\\": 2.5, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"K\\\", \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-X -X -02 PM-X \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:428,y:668,t:1527023697253};\\\", \\\"{x:426,y:667,t:1527023697268};\\\", \\\"{x:424,y:665,t:1527023697284};\\\", \\\"{x:419,y:663,t:1527023697302};\\\", \\\"{x:416,y:661,t:1527023697318};\\\", \\\"{x:413,y:659,t:1527023697334};\\\", \\\"{x:410,y:658,t:1527023697351};\\\", \\\"{x:408,y:657,t:1527023697368};\\\", \\\"{x:407,y:655,t:1527023697384};\\\", \\\"{x:409,y:653,t:1527023697797};\\\", \\\"{x:422,y:649,t:1527023697805};\\\", \\\"{x:433,y:643,t:1527023697818};\\\", \\\"{x:460,y:634,t:1527023697835};\\\", \\\"{x:486,y:624,t:1527023697852};\\\", \\\"{x:511,y:608,t:1527023697869};\\\", \\\"{x:542,y:581,t:1527023697886};\\\", \\\"{x:549,y:575,t:1527023697902};\\\", \\\"{x:550,y:575,t:1527023697918};\\\", \\\"{x:549,y:570,t:1527023698358};\\\", \\\"{x:546,y:564,t:1527023698369};\\\", \\\"{x:543,y:554,t:1527023698387};\\\", \\\"{x:538,y:537,t:1527023698402};\\\", \\\"{x:530,y:510,t:1527023698420};\\\", \\\"{x:521,y:485,t:1527023698437};\\\", \\\"{x:509,y:462,t:1527023698453};\\\", \\\"{x:492,y:438,t:1527023698469};\\\", \\\"{x:483,y:429,t:1527023698485};\\\", \\\"{x:477,y:424,t:1527023698503};\\\", \\\"{x:472,y:421,t:1527023698519};\\\", \\\"{x:472,y:420,t:1527023698536};\\\", \\\"{x:470,y:420,t:1527023698552};\\\", \\\"{x:469,y:418,t:1527023698718};\\\", \\\"{x:468,y:418,t:1527023698726};\\\", \\\"{x:468,y:416,t:1527023698736};\\\", \\\"{x:466,y:412,t:1527023698752};\\\", \\\"{x:464,y:409,t:1527023698770};\\\", \\\"{x:462,y:406,t:1527023698786};\\\", \\\"{x:461,y:401,t:1527023698803};\\\", \\\"{x:458,y:397,t:1527023698819};\\\", \\\"{x:458,y:394,t:1527023698837};\\\", \\\"{x:456,y:389,t:1527023698853};\\\", \\\"{x:454,y:382,t:1527023698870};\\\", \\\"{x:454,y:378,t:1527023698886};\\\", \\\"{x:453,y:377,t:1527023698903};\\\", \\\"{x:453,y:376,t:1527023698934};\\\", \\\"{x:455,y:377,t:1527023699375};\\\", \\\"{x:457,y:378,t:1527023699387};\\\", \\\"{x:461,y:379,t:1527023699404};\\\", \\\"{x:465,y:379,t:1527023699420};\\\", \\\"{x:471,y:379,t:1527023699436};\\\", \\\"{x:478,y:379,t:1527023699454};\\\", \\\"{x:484,y:379,t:1527023699470};\\\", \\\"{x:489,y:379,t:1527023699487};\\\", \\\"{x:497,y:379,t:1527023699503};\\\", \\\"{x:507,y:379,t:1527023699520};\\\", \\\"{x:518,y:380,t:1527023699537};\\\", \\\"{x:529,y:380,t:1527023699554};\\\", \\\"{x:538,y:382,t:1527023699570};\\\", \\\"{x:544,y:383,t:1527023699587};\\\", \\\"{x:551,y:384,t:1527023699604};\\\", \\\"{x:560,y:386,t:1527023699620};\\\", \\\"{x:568,y:388,t:1527023699636};\\\", \\\"{x:579,y:388,t:1527023699653};\\\", \\\"{x:581,y:388,t:1527023699670};\\\", \\\"{x:582,y:388,t:1527023700238};\\\", \\\"{x:582,y:389,t:1527023700294};\\\", \\\"{x:581,y:390,t:1527023701686};\\\", \\\"{x:580,y:391,t:1527023701694};\\\", \\\"{x:579,y:393,t:1527023701705};\\\", \\\"{x:580,y:404,t:1527023701722};\\\", \\\"{x:593,y:419,t:1527023701739};\\\", \\\"{x:615,y:434,t:1527023701756};\\\", \\\"{x:643,y:447,t:1527023701772};\\\", \\\"{x:671,y:457,t:1527023701790};\\\", \\\"{x:723,y:473,t:1527023701805};\\\", \\\"{x:752,y:481,t:1527023701821};\\\", \\\"{x:776,y:483,t:1527023701838};\\\", \\\"{x:791,y:485,t:1527023701855};\\\", \\\"{x:794,y:485,t:1527023701872};\\\", \\\"{x:795,y:485,t:1527023702422};\\\", \\\"{x:796,y:485,t:1527023702439};\\\", \\\"{x:800,y:487,t:1527023702458};\\\", \\\"{x:814,y:492,t:1527023702473};\\\", \\\"{x:837,y:501,t:1527023702488};\\\", \\\"{x:866,y:508,t:1527023702505};\\\", \\\"{x:929,y:525,t:1527023702524};\\\", \\\"{x:1016,y:542,t:1527023702540};\\\", \\\"{x:1123,y:563,t:1527023702555};\\\", \\\"{x:1223,y:578,t:1527023702572};\\\", \\\"{x:1307,y:593,t:1527023702589};\\\", \\\"{x:1415,y:620,t:1527023702605};\\\", \\\"{x:1473,y:635,t:1527023702622};\\\", \\\"{x:1508,y:649,t:1527023702639};\\\", \\\"{x:1528,y:661,t:1527023702655};\\\", \\\"{x:1544,y:674,t:1527023702672};\\\", \\\"{x:1554,y:685,t:1527023702690};\\\", \\\"{x:1558,y:694,t:1527023702706};\\\", \\\"{x:1558,y:695,t:1527023702723};\\\", \\\"{x:1558,y:696,t:1527023703029};\\\", \\\"{x:1554,y:702,t:1527023703040};\\\", \\\"{x:1547,y:712,t:1527023703057};\\\", \\\"{x:1532,y:723,t:1527023703072};\\\", \\\"{x:1515,y:733,t:1527023703089};\\\", \\\"{x:1495,y:745,t:1527023703107};\\\", \\\"{x:1473,y:756,t:1527023703122};\\\", \\\"{x:1454,y:769,t:1527023703140};\\\", \\\"{x:1437,y:782,t:1527023703157};\\\", \\\"{x:1425,y:792,t:1527023703172};\\\", \\\"{x:1416,y:802,t:1527023703190};\\\", \\\"{x:1415,y:805,t:1527023703207};\\\", \\\"{x:1415,y:809,t:1527023703223};\\\", \\\"{x:1415,y:813,t:1527023703241};\\\", \\\"{x:1420,y:821,t:1527023703257};\\\", \\\"{x:1424,y:827,t:1527023703273};\\\", \\\"{x:1426,y:831,t:1527023703290};\\\", \\\"{x:1428,y:836,t:1527023703307};\\\", \\\"{x:1429,y:838,t:1527023703324};\\\", \\\"{x:1430,y:839,t:1527023703340};\\\", \\\"{x:1430,y:840,t:1527023703358};\\\", \\\"{x:1431,y:846,t:1527023703374};\\\", \\\"{x:1434,y:853,t:1527023703390};\\\", \\\"{x:1434,y:855,t:1527023703407};\\\", \\\"{x:1435,y:855,t:1527023703423};\\\", \\\"{x:1435,y:856,t:1527023703440};\\\", \\\"{x:1435,y:857,t:1527023703662};\\\", \\\"{x:1435,y:858,t:1527023703674};\\\", \\\"{x:1438,y:862,t:1527023703691};\\\", \\\"{x:1438,y:863,t:1527023703707};\\\", \\\"{x:1438,y:865,t:1527023703724};\\\", \\\"{x:1439,y:868,t:1527023703740};\\\", \\\"{x:1440,y:871,t:1527023703757};\\\", \\\"{x:1441,y:876,t:1527023703774};\\\", \\\"{x:1442,y:881,t:1527023703791};\\\", \\\"{x:1443,y:885,t:1527023703807};\\\", \\\"{x:1445,y:890,t:1527023703824};\\\", \\\"{x:1446,y:894,t:1527023703841};\\\", \\\"{x:1448,y:897,t:1527023703857};\\\", \\\"{x:1449,y:898,t:1527023703874};\\\", \\\"{x:1451,y:901,t:1527023703891};\\\", \\\"{x:1452,y:901,t:1527023703907};\\\", \\\"{x:1452,y:902,t:1527023703924};\\\", \\\"{x:1454,y:902,t:1527023703942};\\\", \\\"{x:1455,y:902,t:1527023703966};\\\", \\\"{x:1456,y:902,t:1527023703990};\\\", \\\"{x:1459,y:902,t:1527023704008};\\\", \\\"{x:1463,y:903,t:1527023704024};\\\", \\\"{x:1464,y:904,t:1527023704042};\\\", \\\"{x:1465,y:904,t:1527023704057};\\\", \\\"{x:1467,y:905,t:1527023704074};\\\", \\\"{x:1469,y:905,t:1527023704094};\\\", \\\"{x:1470,y:907,t:1527023704109};\\\", \\\"{x:1472,y:908,t:1527023704124};\\\", \\\"{x:1473,y:908,t:1527023704142};\\\", \\\"{x:1474,y:909,t:1527023704158};\\\", \\\"{x:1475,y:909,t:1527023704255};\\\", \\\"{x:1476,y:909,t:1527023704271};\\\", \\\"{x:1477,y:909,t:1527023704302};\\\", \\\"{x:1479,y:910,t:1527023704326};\\\", \\\"{x:1480,y:911,t:1527023704359};\\\", \\\"{x:1481,y:911,t:1527023704662};\\\", \\\"{x:1482,y:910,t:1527023704676};\\\", \\\"{x:1483,y:908,t:1527023704692};\\\", \\\"{x:1483,y:905,t:1527023704709};\\\", \\\"{x:1483,y:901,t:1527023704725};\\\", \\\"{x:1484,y:899,t:1527023704741};\\\", \\\"{x:1484,y:895,t:1527023704759};\\\", \\\"{x:1484,y:893,t:1527023704775};\\\", \\\"{x:1484,y:892,t:1527023704793};\\\", \\\"{x:1484,y:891,t:1527023704808};\\\", \\\"{x:1484,y:890,t:1527023704826};\\\", \\\"{x:1484,y:887,t:1527023704842};\\\", \\\"{x:1484,y:885,t:1527023704859};\\\", \\\"{x:1484,y:882,t:1527023704875};\\\", \\\"{x:1484,y:881,t:1527023704892};\\\", \\\"{x:1484,y:879,t:1527023704908};\\\", \\\"{x:1484,y:877,t:1527023704926};\\\", \\\"{x:1484,y:875,t:1527023704941};\\\", \\\"{x:1484,y:872,t:1527023704958};\\\", \\\"{x:1484,y:866,t:1527023704975};\\\", \\\"{x:1484,y:861,t:1527023704992};\\\", \\\"{x:1484,y:854,t:1527023705009};\\\", \\\"{x:1484,y:849,t:1527023705025};\\\", \\\"{x:1484,y:844,t:1527023705042};\\\", \\\"{x:1485,y:837,t:1527023705058};\\\", \\\"{x:1487,y:822,t:1527023705075};\\\", \\\"{x:1487,y:805,t:1527023705092};\\\", \\\"{x:1487,y:782,t:1527023705108};\\\", \\\"{x:1487,y:764,t:1527023705126};\\\", \\\"{x:1487,y:745,t:1527023705142};\\\", \\\"{x:1487,y:738,t:1527023705159};\\\", \\\"{x:1487,y:733,t:1527023705175};\\\", \\\"{x:1487,y:731,t:1527023705193};\\\", \\\"{x:1487,y:732,t:1527023705382};\\\", \\\"{x:1487,y:734,t:1527023705392};\\\", \\\"{x:1487,y:736,t:1527023705410};\\\", \\\"{x:1488,y:739,t:1527023705425};\\\", \\\"{x:1488,y:740,t:1527023705443};\\\", \\\"{x:1488,y:741,t:1527023705460};\\\", \\\"{x:1488,y:743,t:1527023705475};\\\", \\\"{x:1488,y:745,t:1527023705492};\\\", \\\"{x:1488,y:748,t:1527023705509};\\\", \\\"{x:1488,y:754,t:1527023705525};\\\", \\\"{x:1488,y:766,t:1527023705542};\\\", \\\"{x:1488,y:769,t:1527023705559};\\\", \\\"{x:1488,y:772,t:1527023705577};\\\", \\\"{x:1488,y:775,t:1527023705592};\\\", \\\"{x:1488,y:776,t:1527023705614};\\\", \\\"{x:1487,y:778,t:1527023705627};\\\", \\\"{x:1487,y:780,t:1527023705654};\\\", \\\"{x:1487,y:781,t:1527023705711};\\\", \\\"{x:1487,y:782,t:1527023705734};\\\", \\\"{x:1486,y:783,t:1527023705743};\\\", \\\"{x:1485,y:785,t:1527023705760};\\\", \\\"{x:1484,y:786,t:1527023705776};\\\", \\\"{x:1483,y:787,t:1527023705792};\\\", \\\"{x:1482,y:788,t:1527023705809};\\\", \\\"{x:1481,y:788,t:1527023706054};\\\", \\\"{x:1481,y:786,t:1527023706310};\\\", \\\"{x:1480,y:780,t:1527023706326};\\\", \\\"{x:1476,y:760,t:1527023706343};\\\", \\\"{x:1472,y:728,t:1527023706360};\\\", \\\"{x:1465,y:686,t:1527023706376};\\\", \\\"{x:1459,y:657,t:1527023706392};\\\", \\\"{x:1455,y:633,t:1527023706409};\\\", \\\"{x:1453,y:618,t:1527023706426};\\\", \\\"{x:1452,y:607,t:1527023706443};\\\", \\\"{x:1452,y:600,t:1527023706460};\\\", \\\"{x:1452,y:597,t:1527023706476};\\\", \\\"{x:1452,y:596,t:1527023706783};\\\", \\\"{x:1452,y:595,t:1527023706822};\\\", \\\"{x:1452,y:594,t:1527023706838};\\\", \\\"{x:1453,y:593,t:1527023706854};\\\", \\\"{x:1454,y:593,t:1527023706878};\\\", \\\"{x:1456,y:591,t:1527023706894};\\\", \\\"{x:1459,y:586,t:1527023706910};\\\", \\\"{x:1461,y:580,t:1527023706927};\\\", \\\"{x:1463,y:569,t:1527023706943};\\\", \\\"{x:1465,y:555,t:1527023706960};\\\", \\\"{x:1469,y:540,t:1527023706977};\\\", \\\"{x:1471,y:523,t:1527023706993};\\\", \\\"{x:1473,y:504,t:1527023707010};\\\", \\\"{x:1477,y:483,t:1527023707027};\\\", \\\"{x:1480,y:465,t:1527023707043};\\\", \\\"{x:1484,y:446,t:1527023707060};\\\", \\\"{x:1490,y:422,t:1527023707078};\\\", \\\"{x:1490,y:415,t:1527023707093};\\\", \\\"{x:1495,y:381,t:1527023707110};\\\", \\\"{x:1496,y:360,t:1527023707127};\\\", \\\"{x:1500,y:344,t:1527023707144};\\\", \\\"{x:1501,y:331,t:1527023707160};\\\", \\\"{x:1502,y:321,t:1527023707177};\\\", \\\"{x:1502,y:311,t:1527023707194};\\\", \\\"{x:1502,y:303,t:1527023707210};\\\", \\\"{x:1501,y:294,t:1527023707227};\\\", \\\"{x:1501,y:290,t:1527023707244};\\\", \\\"{x:1501,y:288,t:1527023707260};\\\", \\\"{x:1499,y:282,t:1527023707278};\\\", \\\"{x:1497,y:277,t:1527023707294};\\\", \\\"{x:1497,y:275,t:1527023707310};\\\", \\\"{x:1495,y:271,t:1527023707327};\\\", \\\"{x:1494,y:269,t:1527023707344};\\\", \\\"{x:1494,y:268,t:1527023707374};\\\", \\\"{x:1493,y:269,t:1527023707454};\\\", \\\"{x:1493,y:274,t:1527023707462};\\\", \\\"{x:1493,y:280,t:1527023707478};\\\", \\\"{x:1493,y:327,t:1527023707494};\\\", \\\"{x:1493,y:364,t:1527023707512};\\\", \\\"{x:1493,y:412,t:1527023707527};\\\", \\\"{x:1493,y:448,t:1527023707544};\\\", \\\"{x:1493,y:477,t:1527023707561};\\\", \\\"{x:1493,y:504,t:1527023707578};\\\", \\\"{x:1492,y:529,t:1527023707594};\\\", \\\"{x:1491,y:553,t:1527023707612};\\\", \\\"{x:1488,y:581,t:1527023707628};\\\", \\\"{x:1488,y:612,t:1527023707644};\\\", \\\"{x:1488,y:651,t:1527023707662};\\\", \\\"{x:1487,y:676,t:1527023707677};\\\", \\\"{x:1487,y:696,t:1527023707694};\\\", \\\"{x:1487,y:718,t:1527023707711};\\\", \\\"{x:1487,y:737,t:1527023707727};\\\", \\\"{x:1487,y:754,t:1527023707745};\\\", \\\"{x:1487,y:769,t:1527023707761};\\\", \\\"{x:1487,y:781,t:1527023707777};\\\", \\\"{x:1486,y:790,t:1527023707794};\\\", \\\"{x:1486,y:795,t:1527023707811};\\\", \\\"{x:1484,y:802,t:1527023707826};\\\", \\\"{x:1484,y:806,t:1527023707843};\\\", \\\"{x:1484,y:810,t:1527023707861};\\\", \\\"{x:1484,y:814,t:1527023707876};\\\", \\\"{x:1484,y:821,t:1527023707894};\\\", \\\"{x:1483,y:826,t:1527023707910};\\\", \\\"{x:1483,y:832,t:1527023707928};\\\", \\\"{x:1482,y:840,t:1527023707944};\\\", \\\"{x:1482,y:848,t:1527023707961};\\\", \\\"{x:1482,y:853,t:1527023707978};\\\", \\\"{x:1482,y:860,t:1527023707994};\\\", \\\"{x:1482,y:869,t:1527023708011};\\\", \\\"{x:1482,y:878,t:1527023708029};\\\", \\\"{x:1482,y:888,t:1527023708044};\\\", \\\"{x:1482,y:894,t:1527023708061};\\\", \\\"{x:1482,y:903,t:1527023708078};\\\", \\\"{x:1482,y:906,t:1527023708094};\\\", \\\"{x:1482,y:910,t:1527023708111};\\\", \\\"{x:1482,y:913,t:1527023708128};\\\", \\\"{x:1482,y:916,t:1527023708145};\\\", \\\"{x:1482,y:917,t:1527023708161};\\\", \\\"{x:1483,y:920,t:1527023708178};\\\", \\\"{x:1482,y:920,t:1527023708254};\\\", \\\"{x:1482,y:919,t:1527023708261};\\\", \\\"{x:1482,y:914,t:1527023708279};\\\", \\\"{x:1479,y:905,t:1527023708295};\\\", \\\"{x:1478,y:894,t:1527023708312};\\\", \\\"{x:1477,y:881,t:1527023708328};\\\", \\\"{x:1477,y:866,t:1527023708346};\\\", \\\"{x:1477,y:850,t:1527023708361};\\\", \\\"{x:1477,y:833,t:1527023708378};\\\", \\\"{x:1477,y:813,t:1527023708395};\\\", \\\"{x:1479,y:788,t:1527023708411};\\\", \\\"{x:1481,y:766,t:1527023708428};\\\", \\\"{x:1485,y:728,t:1527023708445};\\\", \\\"{x:1489,y:698,t:1527023708461};\\\", \\\"{x:1496,y:648,t:1527023708478};\\\", \\\"{x:1502,y:603,t:1527023708496};\\\", \\\"{x:1508,y:567,t:1527023708511};\\\", \\\"{x:1508,y:539,t:1527023708528};\\\", \\\"{x:1509,y:512,t:1527023708545};\\\", \\\"{x:1510,y:483,t:1527023708562};\\\", \\\"{x:1512,y:455,t:1527023708578};\\\", \\\"{x:1513,y:433,t:1527023708595};\\\", \\\"{x:1513,y:413,t:1527023708612};\\\", \\\"{x:1513,y:397,t:1527023708628};\\\", \\\"{x:1513,y:391,t:1527023708646};\\\", \\\"{x:1513,y:386,t:1527023708662};\\\", \\\"{x:1513,y:383,t:1527023708679};\\\", \\\"{x:1513,y:382,t:1527023708695};\\\", \\\"{x:1513,y:381,t:1527023708712};\\\", \\\"{x:1513,y:380,t:1527023708729};\\\", \\\"{x:1513,y:379,t:1527023708745};\\\", \\\"{x:1513,y:378,t:1527023708991};\\\", \\\"{x:1513,y:376,t:1527023709214};\\\", \\\"{x:1513,y:371,t:1527023709229};\\\", \\\"{x:1517,y:363,t:1527023709246};\\\", \\\"{x:1521,y:359,t:1527023709263};\\\", \\\"{x:1522,y:357,t:1527023709280};\\\", \\\"{x:1523,y:356,t:1527023709295};\\\", \\\"{x:1523,y:355,t:1527023709313};\\\", \\\"{x:1521,y:355,t:1527023709359};\\\", \\\"{x:1520,y:362,t:1527023709366};\\\", \\\"{x:1516,y:375,t:1527023709379};\\\", \\\"{x:1507,y:424,t:1527023709396};\\\", \\\"{x:1498,y:496,t:1527023709412};\\\", \\\"{x:1477,y:629,t:1527023709430};\\\", \\\"{x:1464,y:713,t:1527023709445};\\\", \\\"{x:1454,y:777,t:1527023709463};\\\", \\\"{x:1451,y:820,t:1527023709480};\\\", \\\"{x:1447,y:847,t:1527023709497};\\\", \\\"{x:1447,y:859,t:1527023709512};\\\", \\\"{x:1446,y:866,t:1527023709530};\\\", \\\"{x:1444,y:868,t:1527023709546};\\\", \\\"{x:1443,y:869,t:1527023709566};\\\", \\\"{x:1441,y:870,t:1527023709579};\\\", \\\"{x:1423,y:871,t:1527023709596};\\\", \\\"{x:1394,y:871,t:1527023709613};\\\", \\\"{x:1331,y:866,t:1527023709629};\\\", \\\"{x:1141,y:837,t:1527023709646};\\\", \\\"{x:977,y:804,t:1527023709662};\\\", \\\"{x:816,y:779,t:1527023709679};\\\", \\\"{x:691,y:761,t:1527023709695};\\\", \\\"{x:625,y:744,t:1527023709712};\\\", \\\"{x:586,y:735,t:1527023709729};\\\", \\\"{x:566,y:726,t:1527023709746};\\\", \\\"{x:558,y:718,t:1527023709762};\\\", \\\"{x:567,y:718,t:1527023710086};\\\", \\\"{x:582,y:718,t:1527023710096};\\\", \\\"{x:607,y:718,t:1527023710113};\\\", \\\"{x:642,y:721,t:1527023710129};\\\", \\\"{x:677,y:722,t:1527023710147};\\\", \\\"{x:719,y:722,t:1527023710163};\\\", \\\"{x:745,y:722,t:1527023710180};\\\", \\\"{x:768,y:721,t:1527023710196};\\\", \\\"{x:786,y:716,t:1527023710213};\\\", \\\"{x:795,y:712,t:1527023710230};\\\", \\\"{x:795,y:711,t:1527023710302};\\\", \\\"{x:795,y:708,t:1527023710314};\\\", \\\"{x:794,y:703,t:1527023710330};\\\", \\\"{x:793,y:701,t:1527023710346};\\\", \\\"{x:793,y:700,t:1527023710518};\\\", \\\"{x:784,y:696,t:1527023710530};\\\", \\\"{x:764,y:686,t:1527023710547};\\\", \\\"{x:724,y:671,t:1527023710563};\\\", \\\"{x:673,y:651,t:1527023710580};\\\", \\\"{x:607,y:622,t:1527023710598};\\\", \\\"{x:585,y:615,t:1527023710613};\\\", \\\"{x:520,y:588,t:1527023710631};\\\", \\\"{x:504,y:579,t:1527023710646};\\\", \\\"{x:492,y:572,t:1527023710663};\\\", \\\"{x:483,y:564,t:1527023710678};\\\", \\\"{x:478,y:558,t:1527023710696};\\\", \\\"{x:475,y:555,t:1527023710712};\\\", \\\"{x:472,y:549,t:1527023710729};\\\", \\\"{x:470,y:545,t:1527023710746};\\\", \\\"{x:470,y:543,t:1527023710762};\\\", \\\"{x:468,y:541,t:1527023710778};\\\", \\\"{x:468,y:540,t:1527023710795};\\\", \\\"{x:468,y:538,t:1527023710813};\\\", \\\"{x:470,y:536,t:1527023710828};\\\", \\\"{x:475,y:536,t:1527023710846};\\\", \\\"{x:484,y:536,t:1527023710863};\\\", \\\"{x:495,y:536,t:1527023710878};\\\", \\\"{x:511,y:536,t:1527023710897};\\\", \\\"{x:532,y:537,t:1527023710913};\\\", \\\"{x:551,y:537,t:1527023710929};\\\", \\\"{x:570,y:537,t:1527023710946};\\\", \\\"{x:586,y:537,t:1527023710963};\\\", \\\"{x:599,y:537,t:1527023710979};\\\", \\\"{x:604,y:537,t:1527023710997};\\\", \\\"{x:605,y:537,t:1527023711526};\\\", \\\"{x:605,y:538,t:1527023711542};\\\", \\\"{x:605,y:540,t:1527023711558};\\\", \\\"{x:603,y:540,t:1527023711565};\\\", \\\"{x:599,y:540,t:1527023711581};\\\", \\\"{x:568,y:537,t:1527023711597};\\\", \\\"{x:545,y:532,t:1527023711613};\\\", \\\"{x:517,y:527,t:1527023711630};\\\", \\\"{x:494,y:524,t:1527023711648};\\\", \\\"{x:467,y:518,t:1527023711663};\\\", \\\"{x:448,y:514,t:1527023711681};\\\", \\\"{x:437,y:511,t:1527023711696};\\\", \\\"{x:434,y:510,t:1527023711712};\\\", \\\"{x:432,y:509,t:1527023711730};\\\", \\\"{x:431,y:509,t:1527023711797};\\\", \\\"{x:429,y:509,t:1527023711813};\\\", \\\"{x:427,y:509,t:1527023711830};\\\", \\\"{x:422,y:509,t:1527023711847};\\\", \\\"{x:414,y:509,t:1527023711864};\\\", \\\"{x:407,y:509,t:1527023711880};\\\", \\\"{x:397,y:510,t:1527023711896};\\\", \\\"{x:385,y:512,t:1527023711914};\\\", \\\"{x:377,y:513,t:1527023711930};\\\", \\\"{x:363,y:514,t:1527023711946};\\\", \\\"{x:353,y:514,t:1527023711964};\\\", \\\"{x:348,y:514,t:1527023711980};\\\", \\\"{x:343,y:514,t:1527023711997};\\\", \\\"{x:342,y:514,t:1527023712014};\\\", \\\"{x:342,y:515,t:1527023712077};\\\", \\\"{x:343,y:517,t:1527023712086};\\\", \\\"{x:346,y:517,t:1527023712097};\\\", \\\"{x:350,y:518,t:1527023712114};\\\", \\\"{x:358,y:521,t:1527023712130};\\\", \\\"{x:363,y:522,t:1527023712147};\\\", \\\"{x:369,y:524,t:1527023712165};\\\", \\\"{x:371,y:525,t:1527023712180};\\\", \\\"{x:374,y:525,t:1527023712196};\\\", \\\"{x:377,y:527,t:1527023712559};\\\", \\\"{x:380,y:532,t:1527023712566};\\\", \\\"{x:386,y:539,t:1527023712581};\\\", \\\"{x:391,y:545,t:1527023712597};\\\", \\\"{x:396,y:549,t:1527023712615};\\\", \\\"{x:397,y:550,t:1527023712631};\\\", \\\"{x:394,y:548,t:1527023712750};\\\", \\\"{x:392,y:546,t:1527023712764};\\\", \\\"{x:387,y:544,t:1527023712781};\\\", \\\"{x:387,y:542,t:1527023712798};\\\", \\\"{x:385,y:542,t:1527023712813};\\\", \\\"{x:388,y:543,t:1527023713141};\\\", \\\"{x:392,y:549,t:1527023713149};\\\", \\\"{x:397,y:555,t:1527023713165};\\\", \\\"{x:419,y:577,t:1527023713183};\\\", \\\"{x:436,y:597,t:1527023713199};\\\", \\\"{x:453,y:611,t:1527023713215};\\\", \\\"{x:468,y:627,t:1527023713231};\\\", \\\"{x:481,y:638,t:1527023713248};\\\", \\\"{x:489,y:647,t:1527023713264};\\\", \\\"{x:496,y:654,t:1527023713281};\\\", \\\"{x:503,y:664,t:1527023713298};\\\", \\\"{x:508,y:671,t:1527023713315};\\\", \\\"{x:513,y:678,t:1527023713331};\\\", \\\"{x:514,y:681,t:1527023713349};\\\", \\\"{x:516,y:685,t:1527023713365};\\\", \\\"{x:518,y:687,t:1527023713381};\\\", \\\"{x:518,y:688,t:1527023713398};\\\", \\\"{x:519,y:689,t:1527023713415};\\\", \\\"{x:519,y:690,t:1527023713431};\\\", \\\"{x:520,y:693,t:1527023713449};\\\", \\\"{x:521,y:695,t:1527023713465};\\\", \\\"{x:521,y:696,t:1527023713481};\\\", \\\"{x:522,y:698,t:1527023713499};\\\", \\\"{x:523,y:698,t:1527023713515};\\\" ] }, { \\\"rt\\\": 123812, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 20, \\\"time_elapsed\\\": 924178, \\\"internal_node_id\\\": \\\"0.0-7.0-0.0\\\", \\\"subject\\\": \\\"QOJ6L\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"hotel\\\", \\\"condition\\\": \\\"121\\\", \\\"q\\\": 16, \\\"answer\\\": \\\"First find the point of 12PM on x-axis, then trace the line towards the up-right direction of the 12PM point;the points lie on the line are the events we are looking for, which is M and L.\\\", \\\"block\\\": \\\"triangular_testing\\\" }, { \\\"rt\\\": 7648, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"22\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"China\\\\\\\"}\\\", \\\"block\\\": \\\"demo-1\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 21, \\\"time_elapsed\\\": 932831, \\\"internal_node_id\\\": \\\"0.0-8.0\\\", \\\"subject\\\": \\\"QOJ6L\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"hotel\\\", \\\"condition\\\": \\\"121\\\" }, { \\\"rt\\\": 30984, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"Mandarin or Cantonese\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"Fifth\\\\\\\",\\\\\\\"Q2\\\\\\\":\\\\\\\"Social Sciences (incl. CogSci)\\\\\\\",\\\\\\\"Q3\\\\\\\":\\\\\\\"Male\\\\\\\"}\\\", \\\"block\\\": \\\"demo-2\\\", \\\"trial_type\\\": \\\"survey-multi-choice\\\", \\\"trial_index\\\": 22, \\\"time_elapsed\\\": 964843, \\\"internal_node_id\\\": \\\"0.0-9.0\\\", \\\"subject\\\": \\\"QOJ6L\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"hotel\\\", \\\"condition\\\": \\\"121\\\" }, { \\\"rt\\\": 44121, \\\"url\\\": \\\"../views/src/external/debrief.html\\\", \\\"block\\\": \\\"debrief\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 23, \\\"time_elapsed\\\": 1010307, \\\"internal_node_id\\\": \\\"0.0-10.0\\\", \\\"subject\\\": \\\"QOJ6L\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"hotel\\\", \\\"condition\\\": \\\"121\\\" } ]\",\"parentNode\":{\"id\":2765}}],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"META\",\"attributes\":{\"charset\":\"utf-8\"}},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":8,\"id\":59},{\"nodeType\":3,\"id\":60,\"textContent\":\" \"},{\"nodeType\":1,\"id\":61,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":62,\"textContent\":\" \"},{\"nodeType\":1,\"id\":63,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":64,\"textContent\":\" \"},{\"nodeType\":1,\"id\":65,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":66,\"textContent\":\" \"},{\"nodeType\":1,\"id\":67,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":68,\"textContent\":\" \"},{\"nodeType\":1,\"id\":69,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":70,\"textContent\":\" \"},{\"nodeType\":1,\"id\":71,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":72,\"textContent\":\" \"},{\"nodeType\":1,\"id\":73,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"stimulus\"},\"childNodes\":[{\"nodeType\":3,\"id\":74,\"textContent\":\" \"},{\"nodeType\":1,\"id\":75,\"tagName\":\"P\",\"attributes\":{\"class\":\"userid\",\"id\":\"userid\"},\"childNodes\":[{\"nodeType\":3,\"id\":76,\"textContent\":\"QOJ6L\"}]},{\"nodeType\":3,\"id\":77,\"textContent\":\" \"},{\"nodeType\":1,\"id\":78,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"userinput\"},\"childNodes\":[{\"nodeType\":3,\"id\":79,\"textContent\":\" \"},{\"nodeType\":8,\"id\":80},{\"nodeType\":3,\"id\":81,\"textContent\":\" \"},{\"nodeType\":1,\"id\":82,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"legend\",\"id\":\"hint-interactive\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":83,\"textContent\":\" \"},{\"nodeType\":1,\"id\":84,\"tagName\":\"P\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":85,\"textContent\":\"Hint: Hover your mouse over the data points in the graph\"}]},{\"nodeType\":3,\"id\":86,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":87,\"textContent\":\" \"},{\"nodeType\":8,\"id\":88},{\"nodeType\":3,\"id\":89,\"textContent\":\" \"},{\"nodeType\":8,\"id\":90},{\"nodeType\":3,\"id\":91,\"textContent\":\" \"},{\"nodeType\":1,\"id\":92,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"test\"},\"childNodes\":[{\"nodeType\":3,\"id\":93,\"textContent\":\" \"},{\"nodeType\":1,\"id\":94,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":95,\"textContent\":\" \"},{\"nodeType\":1,\"id\":96,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":97,\"textContent\":\"Which shift(s) start at 11 am? \"}]},{\"nodeType\":3,\"id\":98,\"textContent\":\" \"},{\"nodeType\":1,\"id\":99,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":100,\"textContent\":\" \"},{\"nodeType\":1,\"id\":101,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":102,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":103,\"textContent\":\" \"},{\"nodeType\":1,\"id\":104,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":105,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":106,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":107,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":108,\"textContent\":\" \"},{\"nodeType\":1,\"id\":109,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":110,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":111,\"textContent\":\" \"},{\"nodeType\":1,\"id\":112,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":113,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":115,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":116,\"textContent\":\" \"},{\"nodeType\":1,\"id\":117,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":118,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":120,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":121,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":122,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":123,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":125,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":126,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":127,\"textContent\":\" \"},{\"nodeType\":1,\"id\":128,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":129,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":130,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":132,\"textContent\":\" \"},{\"nodeType\":1,\"id\":133,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":134,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":135,\"textContent\":\" \"},{\"nodeType\":1,\"id\":136,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":137,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":138,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":140,\"textContent\":\" \"},{\"nodeType\":1,\"id\":141,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":142,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":143,\"textContent\":\" \"},{\"nodeType\":1,\"id\":144,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":145,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":146,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":147,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":148,\"textContent\":\" \"},{\"nodeType\":1,\"id\":149,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":150,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":151,\"textContent\":\" \"},{\"nodeType\":1,\"id\":152,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":153,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":154,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":156,\"textContent\":\" \"},{\"nodeType\":1,\"id\":157,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":158,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":159,\"textContent\":\" \"},{\"nodeType\":1,\"id\":160,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":161,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":162,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":163,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":164,\"textContent\":\" \"},{\"nodeType\":1,\"id\":165,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":166,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":167,\"textContent\":\" \"},{\"nodeType\":1,\"id\":168,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":169,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":170,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":171,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":172,\"textContent\":\" \"},{\"nodeType\":1,\"id\":173,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":174,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":175,\"textContent\":\" \"},{\"nodeType\":1,\"id\":176,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":177,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":178,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":179,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":180,\"textContent\":\" \"},{\"nodeType\":1,\"id\":181,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":182,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":183,\"textContent\":\" \"},{\"nodeType\":1,\"id\":184,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":185,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":186,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":187,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":188,\"textContent\":\" \"},{\"nodeType\":1,\"id\":189,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":190,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":191,\"textContent\":\" \"},{\"nodeType\":1,\"id\":192,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":193,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":194,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":196,\"textContent\":\" \"},{\"nodeType\":1,\"id\":197,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":198,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":200,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":201,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":202,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":203,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":205,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":206,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":207,\"textContent\":\" \"},{\"nodeType\":1,\"id\":208,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":209,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":210,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":211,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":212,\"textContent\":\" \"},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":214,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":215,\"textContent\":\" \"},{\"nodeType\":1,\"id\":216,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":217,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":218,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":219,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":220,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":221,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":223,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":224,\"textContent\":\" \"},{\"nodeType\":1,\"id\":225,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":226,\"textContent\":\"Which shift(s) start at the same time as D?\"}]},{\"nodeType\":3,\"id\":227,\"textContent\":\" \"},{\"nodeType\":1,\"id\":228,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":229,\"textContent\":\" \"},{\"nodeType\":1,\"id\":230,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":231,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":232,\"textContent\":\" \"},{\"nodeType\":1,\"id\":233,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":234,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":235,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":236,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":237,\"textContent\":\" \"},{\"nodeType\":1,\"id\":238,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":239,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":240,\"textContent\":\" \"},{\"nodeType\":1,\"id\":241,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":242,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":243,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":244,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":245,\"textContent\":\" \"},{\"nodeType\":1,\"id\":246,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":247,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":248,\"textContent\":\" \"},{\"nodeType\":1,\"id\":249,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":250,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":251,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":252,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":253,\"textContent\":\" \"},{\"nodeType\":1,\"id\":254,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":255,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":256,\"textContent\":\" \"},{\"nodeType\":1,\"id\":257,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":258,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":259,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":260,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":261,\"textContent\":\" \"},{\"nodeType\":1,\"id\":262,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":263,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":264,\"textContent\":\" \"},{\"nodeType\":1,\"id\":265,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":266,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":267,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":268,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":269,\"textContent\":\" \"},{\"nodeType\":1,\"id\":270,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":271,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":273,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":274,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":275,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":276,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":278,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":279,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":280,\"textContent\":\" \"},{\"nodeType\":1,\"id\":281,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":282,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":283,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":284,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":286,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":287,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":288,\"textContent\":\" \"},{\"nodeType\":1,\"id\":289,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":290,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":291,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":292,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":293,\"textContent\":\" \"},{\"nodeType\":1,\"id\":294,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":295,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":296,\"textContent\":\" \"},{\"nodeType\":1,\"id\":297,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":298,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":299,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":300,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":301,\"textContent\":\" \"},{\"nodeType\":1,\"id\":302,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":303,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":304,\"textContent\":\" \"},{\"nodeType\":1,\"id\":305,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":306,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":307,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":308,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":309,\"textContent\":\" \"},{\"nodeType\":1,\"id\":310,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":311,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":312,\"textContent\":\" \"},{\"nodeType\":1,\"id\":313,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":314,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":315,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":316,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":317,\"textContent\":\" \"},{\"nodeType\":1,\"id\":318,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":319,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":320,\"textContent\":\" \"},{\"nodeType\":1,\"id\":321,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":322,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":323,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":324,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":325,\"textContent\":\" \"},{\"nodeType\":1,\"id\":326,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":327,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":328,\"textContent\":\" \"},{\"nodeType\":1,\"id\":329,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":330,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":331,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":332,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":333,\"textContent\":\" \"},{\"nodeType\":1,\"id\":334,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":335,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":336,\"textContent\":\" \"},{\"nodeType\":1,\"id\":337,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":338,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":339,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":340,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":341,\"textContent\":\" \"},{\"nodeType\":1,\"id\":342,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":343,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":344,\"textContent\":\" \"},{\"nodeType\":1,\"id\":345,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":346,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":347,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":348,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":349,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":351,\"textContent\":\" \"},{\"nodeType\":1,\"id\":352,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":353,\"textContent\":\" \"},{\"nodeType\":1,\"id\":354,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":355,\"textContent\":\"Which shift(s) begin when C ends?\"}]},{\"nodeType\":3,\"id\":356,\"textContent\":\" \"},{\"nodeType\":1,\"id\":357,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":358,\"textContent\":\" \"},{\"nodeType\":1,\"id\":359,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":360,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":361,\"textContent\":\" \"},{\"nodeType\":1,\"id\":362,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":363,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":364,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":365,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":366,\"textContent\":\" \"},{\"nodeType\":1,\"id\":367,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":368,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":369,\"textContent\":\" \"},{\"nodeType\":1,\"id\":370,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":371,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":372,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":373,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":374,\"textContent\":\" \"},{\"nodeType\":1,\"id\":375,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":376,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":377,\"textContent\":\" \"},{\"nodeType\":1,\"id\":378,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":379,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":380,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":381,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":382,\"textContent\":\" \"},{\"nodeType\":1,\"id\":383,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":384,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":385,\"textContent\":\" \"},{\"nodeType\":1,\"id\":386,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":387,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":388,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":389,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":390,\"textContent\":\" \"},{\"nodeType\":1,\"id\":391,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":392,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":393,\"textContent\":\" \"},{\"nodeType\":1,\"id\":394,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":395,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":396,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":397,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":398,\"textContent\":\" \"},{\"nodeType\":1,\"id\":399,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":400,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":401,\"textContent\":\" \"},{\"nodeType\":1,\"id\":402,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":403,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":404,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":405,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":406,\"textContent\":\" \"},{\"nodeType\":1,\"id\":407,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":408,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":409,\"textContent\":\" \"},{\"nodeType\":1,\"id\":410,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":411,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":412,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":413,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":414,\"textContent\":\" \"},{\"nodeType\":1,\"id\":415,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":416,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":417,\"textContent\":\" \"},{\"nodeType\":1,\"id\":418,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":419,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":420,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":421,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":422,\"textContent\":\" \"},{\"nodeType\":1,\"id\":423,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":424,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":425,\"textContent\":\" \"},{\"nodeType\":1,\"id\":426,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":427,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":428,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":429,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":430,\"textContent\":\" \"},{\"nodeType\":1,\"id\":431,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":432,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":433,\"textContent\":\" \"},{\"nodeType\":1,\"id\":434,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":435,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":436,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":437,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":438,\"textContent\":\" \"},{\"nodeType\":1,\"id\":439,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":440,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":441,\"textContent\":\" \"},{\"nodeType\":1,\"id\":442,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":443,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":444,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":445,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":446,\"textContent\":\" \"},{\"nodeType\":1,\"id\":447,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":448,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":449,\"textContent\":\" \"},{\"nodeType\":1,\"id\":450,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":451,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":452,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":453,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":454,\"textContent\":\" \"},{\"nodeType\":1,\"id\":455,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":456,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":457,\"textContent\":\" \"},{\"nodeType\":1,\"id\":458,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":459,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":460,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":461,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":462,\"textContent\":\" \"},{\"nodeType\":1,\"id\":463,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":464,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":465,\"textContent\":\" \"},{\"nodeType\":1,\"id\":466,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":467,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":468,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":469,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":470,\"textContent\":\" \"},{\"nodeType\":1,\"id\":471,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":472,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":473,\"textContent\":\" \"},{\"nodeType\":1,\"id\":474,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":475,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":476,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":477,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":478,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":479,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":480,\"textContent\":\" \"},{\"nodeType\":1,\"id\":481,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":483,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":484,\"textContent\":\" Which shift(s) end at 4 pm?\"}]},{\"nodeType\":3,\"id\":485,\"textContent\":\" \"},{\"nodeType\":1,\"id\":486,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":492,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":500,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":503,\"textContent\":\" \"},{\"nodeType\":1,\"id\":504,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":505,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":506,\"textContent\":\" \"},{\"nodeType\":1,\"id\":507,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":508,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":509,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":510,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":511,\"textContent\":\" \"},{\"nodeType\":1,\"id\":512,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":513,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":514,\"textContent\":\" \"},{\"nodeType\":1,\"id\":515,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":516,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":517,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":518,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":519,\"textContent\":\" \"},{\"nodeType\":1,\"id\":520,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":521,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":522,\"textContent\":\" \"},{\"nodeType\":1,\"id\":523,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":524,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":525,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":526,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":527,\"textContent\":\" \"},{\"nodeType\":1,\"id\":528,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":529,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":530,\"textContent\":\" \"},{\"nodeType\":1,\"id\":531,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":532,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":533,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":534,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":535,\"textContent\":\" \"},{\"nodeType\":1,\"id\":536,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":537,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":538,\"textContent\":\" \"},{\"nodeType\":1,\"id\":539,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":540,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":541,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":542,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":543,\"textContent\":\" \"},{\"nodeType\":1,\"id\":544,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":545,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":546,\"textContent\":\" \"},{\"nodeType\":1,\"id\":547,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":548,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":549,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":550,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":551,\"textContent\":\" \"},{\"nodeType\":1,\"id\":552,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":553,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":554,\"textContent\":\" \"},{\"nodeType\":1,\"id\":555,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":556,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":557,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":558,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":559,\"textContent\":\" \"},{\"nodeType\":1,\"id\":560,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":561,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":562,\"textContent\":\" \"},{\"nodeType\":1,\"id\":563,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":564,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":565,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":566,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":567,\"textContent\":\" \"},{\"nodeType\":1,\"id\":568,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":569,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":570,\"textContent\":\" \"},{\"nodeType\":1,\"id\":571,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":572,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":573,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":574,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":575,\"textContent\":\" \"},{\"nodeType\":1,\"id\":576,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":577,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":578,\"textContent\":\" \"},{\"nodeType\":1,\"id\":579,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":580,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":581,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":582,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":583,\"textContent\":\" \"},{\"nodeType\":1,\"id\":584,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":585,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":586,\"textContent\":\" \"},{\"nodeType\":1,\"id\":587,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":588,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":589,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":590,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":592,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":593,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":594,\"textContent\":\" \"},{\"nodeType\":1,\"id\":595,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":596,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":597,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":598,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":599,\"textContent\":\" \"},{\"nodeType\":1,\"id\":600,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":601,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":602,\"textContent\":\" \"},{\"nodeType\":1,\"id\":603,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":604,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":605,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":606,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":607,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":608,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":609,\"textContent\":\" \"},{\"nodeType\":1,\"id\":610,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":612,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":613,\"textContent\":\"Coffee breaks happen halfway through a shift.\"},{\"nodeType\":1,\"id\":614,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":615,\"textContent\":\" Which shift(s) share a break with I?\"}]},{\"nodeType\":3,\"id\":616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":617,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":618,\"textContent\":\" \"},{\"nodeType\":1,\"id\":619,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":620,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":621,\"textContent\":\" \"},{\"nodeType\":1,\"id\":622,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":623,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":624,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":625,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":626,\"textContent\":\" \"},{\"nodeType\":1,\"id\":627,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":628,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":629,\"textContent\":\" \"},{\"nodeType\":1,\"id\":630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":631,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":632,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":633,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":634,\"textContent\":\" \"},{\"nodeType\":1,\"id\":635,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":636,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":637,\"textContent\":\" \"},{\"nodeType\":1,\"id\":638,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":639,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":640,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":641,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":642,\"textContent\":\" \"},{\"nodeType\":1,\"id\":643,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":644,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":645,\"textContent\":\" \"},{\"nodeType\":1,\"id\":646,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":647,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":648,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":649,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":650,\"textContent\":\" \"},{\"nodeType\":1,\"id\":651,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":653,\"textContent\":\" \"},{\"nodeType\":1,\"id\":654,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":655,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":656,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":657,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":659,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":660,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":661,\"textContent\":\" \"},{\"nodeType\":1,\"id\":662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":663,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":664,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":665,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":666,\"textContent\":\" \"},{\"nodeType\":1,\"id\":667,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":668,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":669,\"textContent\":\" \"},{\"nodeType\":1,\"id\":670,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":671,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":672,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":673,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":674,\"textContent\":\" \"},{\"nodeType\":1,\"id\":675,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":676,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":677,\"textContent\":\" \"},{\"nodeType\":1,\"id\":678,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":679,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":680,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":681,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":682,\"textContent\":\" \"},{\"nodeType\":1,\"id\":683,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":685,\"textContent\":\" \"},{\"nodeType\":1,\"id\":686,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":687,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":688,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":689,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":690,\"textContent\":\" \"},{\"nodeType\":1,\"id\":691,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":692,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":693,\"textContent\":\" \"},{\"nodeType\":1,\"id\":694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":695,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":696,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":697,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":698,\"textContent\":\" \"},{\"nodeType\":1,\"id\":699,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":700,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":701,\"textContent\":\" \"},{\"nodeType\":1,\"id\":702,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":703,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":704,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":705,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":706,\"textContent\":\" \"},{\"nodeType\":1,\"id\":707,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":708,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":709,\"textContent\":\" \"},{\"nodeType\":1,\"id\":710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":711,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":712,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":713,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":714,\"textContent\":\" \"},{\"nodeType\":1,\"id\":715,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":716,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":717,\"textContent\":\" \"},{\"nodeType\":1,\"id\":718,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":719,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":720,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":721,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":722,\"textContent\":\" \"},{\"nodeType\":1,\"id\":723,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":724,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":725,\"textContent\":\" \"},{\"nodeType\":1,\"id\":726,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":727,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":728,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":729,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":730,\"textContent\":\" \"},{\"nodeType\":1,\"id\":731,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":732,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":733,\"textContent\":\" \"},{\"nodeType\":1,\"id\":734,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":735,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":736,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":737,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":738,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":739,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":741,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":742,\"textContent\":\" \"},{\"nodeType\":1,\"id\":743,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":744,\"textContent\":\"Which shift(s) are six hours long?\"}]},{\"nodeType\":3,\"id\":745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":746,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":747,\"textContent\":\" \"},{\"nodeType\":1,\"id\":748,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":749,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":750,\"textContent\":\" \"},{\"nodeType\":1,\"id\":751,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":752,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":753,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":754,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":755,\"textContent\":\" \"},{\"nodeType\":1,\"id\":756,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":757,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":758,\"textContent\":\" \"},{\"nodeType\":1,\"id\":759,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":760,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":761,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":762,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":763,\"textContent\":\" \"},{\"nodeType\":1,\"id\":764,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":765,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":766,\"textContent\":\" \"},{\"nodeType\":1,\"id\":767,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":768,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":769,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":770,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":771,\"textContent\":\" \"},{\"nodeType\":1,\"id\":772,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":773,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":774,\"textContent\":\" \"},{\"nodeType\":1,\"id\":775,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":776,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":777,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":778,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":779,\"textContent\":\" \"},{\"nodeType\":1,\"id\":780,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":781,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":782,\"textContent\":\" \"},{\"nodeType\":1,\"id\":783,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":784,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":785,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":786,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":787,\"textContent\":\" \"},{\"nodeType\":1,\"id\":788,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":789,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":790,\"textContent\":\" \"},{\"nodeType\":1,\"id\":791,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":792,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":793,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":794,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":795,\"textContent\":\" \"},{\"nodeType\":1,\"id\":796,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":797,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":798,\"textContent\":\" \"},{\"nodeType\":1,\"id\":799,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":800,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":801,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":802,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":803,\"textContent\":\" \"},{\"nodeType\":1,\"id\":804,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":805,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":806,\"textContent\":\" \"},{\"nodeType\":1,\"id\":807,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":808,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":809,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":810,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":812,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":813,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":814,\"textContent\":\" \"},{\"nodeType\":1,\"id\":815,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":816,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":817,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":818,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":819,\"textContent\":\" \"},{\"nodeType\":1,\"id\":820,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":821,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":822,\"textContent\":\" \"},{\"nodeType\":1,\"id\":823,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":824,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":825,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":826,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":827,\"textContent\":\" \"},{\"nodeType\":1,\"id\":828,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":829,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":830,\"textContent\":\" \"},{\"nodeType\":1,\"id\":831,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":832,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":833,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":834,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":835,\"textContent\":\" \"},{\"nodeType\":1,\"id\":836,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":837,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":838,\"textContent\":\" \"},{\"nodeType\":1,\"id\":839,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":840,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":841,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":842,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":843,\"textContent\":\" \"},{\"nodeType\":1,\"id\":844,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":845,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":846,\"textContent\":\" \"},{\"nodeType\":1,\"id\":847,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":848,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":849,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":850,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":851,\"textContent\":\" \"},{\"nodeType\":1,\"id\":852,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":853,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":854,\"textContent\":\" \"},{\"nodeType\":1,\"id\":855,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":856,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":857,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":858,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":859,\"textContent\":\" \"},{\"nodeType\":1,\"id\":860,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":861,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":862,\"textContent\":\" \"},{\"nodeType\":1,\"id\":863,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":864,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":865,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":866,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":867,\"textContent\":\" \"},{\"nodeType\":1,\"id\":868,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":869,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":870,\"textContent\":\" \"},{\"nodeType\":1,\"id\":871,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":872,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":873,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":874,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":875,\"textContent\":\" \"},{\"nodeType\":1,\"id\":876,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":877,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":878,\"textContent\":\" \"},{\"nodeType\":1,\"id\":879,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":880,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":881,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":882,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":883,\"textContent\":\" \"},{\"nodeType\":1,\"id\":884,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":885,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":886,\"textContent\":\" \"},{\"nodeType\":1,\"id\":887,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":888,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":889,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":890,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":891,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":892,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":894,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":895,\"textContent\":\" \"},{\"nodeType\":1,\"id\":896,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":897,\"textContent\":\"Which 2 shifts less than 5 hours long start at the same time?\"}]},{\"nodeType\":3,\"id\":898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":899,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":900,\"textContent\":\" \"},{\"nodeType\":1,\"id\":901,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":902,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":903,\"textContent\":\" \"},{\"nodeType\":1,\"id\":904,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":905,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":906,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":907,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":908,\"textContent\":\" \"},{\"nodeType\":1,\"id\":909,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":910,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":911,\"textContent\":\" \"},{\"nodeType\":1,\"id\":912,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":913,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":914,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":915,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":916,\"textContent\":\" \"},{\"nodeType\":1,\"id\":917,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":918,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":919,\"textContent\":\" \"},{\"nodeType\":1,\"id\":920,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":921,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":922,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":923,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":924,\"textContent\":\" \"},{\"nodeType\":1,\"id\":925,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":926,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":927,\"textContent\":\" \"},{\"nodeType\":1,\"id\":928,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":929,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":930,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":931,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":932,\"textContent\":\" \"},{\"nodeType\":1,\"id\":933,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":934,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":935,\"textContent\":\" \"},{\"nodeType\":1,\"id\":936,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":937,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":938,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":939,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":940,\"textContent\":\" \"},{\"nodeType\":1,\"id\":941,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":942,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":943,\"textContent\":\" \"},{\"nodeType\":1,\"id\":944,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":945,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":946,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":947,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":948,\"textContent\":\" \"},{\"nodeType\":1,\"id\":949,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":950,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":951,\"textContent\":\" \"},{\"nodeType\":1,\"id\":952,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":953,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":954,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":955,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":956,\"textContent\":\" \"},{\"nodeType\":1,\"id\":957,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":958,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":959,\"textContent\":\" \"},{\"nodeType\":1,\"id\":960,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":961,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":962,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":963,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":965,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":966,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":967,\"textContent\":\" \"},{\"nodeType\":1,\"id\":968,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":969,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":970,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":971,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":972,\"textContent\":\" \"},{\"nodeType\":1,\"id\":973,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":974,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":975,\"textContent\":\" \"},{\"nodeType\":1,\"id\":976,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":977,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":978,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":979,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":980,\"textContent\":\" \"},{\"nodeType\":1,\"id\":981,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":982,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":983,\"textContent\":\" \"},{\"nodeType\":1,\"id\":984,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":985,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":986,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":987,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":988,\"textContent\":\" \"},{\"nodeType\":1,\"id\":989,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":990,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":991,\"textContent\":\" \"},{\"nodeType\":1,\"id\":992,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":993,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":994,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":995,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":996,\"textContent\":\" \"},{\"nodeType\":1,\"id\":997,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":998,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":999,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1000,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1001,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1002,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1003,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1004,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1005,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1006,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1007,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1008,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1009,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1010,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1011,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1012,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1013,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1014,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1015,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1016,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1017,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1018,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1019,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1020,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1021,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1022,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1023,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1024,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1025,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1026,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1027,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1028,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1029,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1030,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1031,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1032,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1033,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1034,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1035,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1036,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1037,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1038,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1039,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1040,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1041,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1042,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1043,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1044,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1045,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1047,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+contained\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1048,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1049,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1050,\"textContent\":\"Which shift(s) under 7 hours long starts before B starts, and ends after X ends?\"}]},{\"nodeType\":3,\"id\":1051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1052,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1053,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1054,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1055,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1056,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1057,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1058,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1059,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1060,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1061,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1062,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1063,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1064,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1065,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1066,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1067,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1068,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1069,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1070,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1071,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1072,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1073,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1074,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1075,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1076,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1077,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1078,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1079,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1080,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1081,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1082,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1083,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1084,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1085,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1086,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1087,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1088,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1089,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1090,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1091,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1092,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1093,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1094,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1095,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1096,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1097,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1098,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1099,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1100,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1101,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1102,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1103,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1104,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1105,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1106,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1107,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1108,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1109,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1110,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1111,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1112,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1113,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1114,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1115,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1116,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1118,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1119,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1120,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1121,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1122,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1123,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1124,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1125,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1126,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1127,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1128,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1129,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1130,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1131,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1132,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1133,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1134,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1135,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1136,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1137,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1138,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1139,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1140,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1141,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1142,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1143,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1144,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1145,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1146,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1147,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1148,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1149,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1150,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1151,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1152,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1153,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1154,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1155,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1156,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1157,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1158,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1159,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1160,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1161,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1162,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1163,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1164,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1165,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1166,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1167,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1168,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1169,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1170,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1171,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1172,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1173,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1174,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1175,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1176,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1177,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1178,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1179,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1180,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1181,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1182,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1183,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1184,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1185,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1186,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1187,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1188,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1189,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1190,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1191,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1192,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1193,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1194,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1195,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1196,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1197,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1198,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1200,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime+before+endtime+during\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1202,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1203,\"textContent\":\"Which shift(s) begins before J begins and ends during B?\"}]},{\"nodeType\":3,\"id\":1204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1205,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1211,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1219,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1227,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1235,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1243,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1251,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1259,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1267,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1270,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1271,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1272,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1273,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1274,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1275,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1276,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1277,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1278,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1279,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1280,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1281,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1282,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1283,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1284,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1285,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1286,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1287,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1288,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1289,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1290,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1291,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1292,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1293,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1294,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1295,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1296,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1298,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1299,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1300,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1301,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1302,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1303,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1304,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1305,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1306,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1307,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1308,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1309,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1310,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1311,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1312,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1313,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1314,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1315,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1316,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1317,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1318,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1319,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1320,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1321,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1322,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1323,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1324,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1325,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1326,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1327,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1328,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1329,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1330,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1331,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1332,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1333,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1334,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1335,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1336,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1337,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1338,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1339,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1340,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1341,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1342,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1343,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1344,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1345,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1346,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1347,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1348,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1349,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1351,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1352,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1353,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.ends\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1354,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1355,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1356,\"textContent\":\"Which shift(s) end at the same time as F?\"}]},{\"nodeType\":3,\"id\":1357,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1358,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1359,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1360,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1361,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1362,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1363,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1364,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1365,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1366,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1367,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1368,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1369,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1370,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1371,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1372,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1373,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1374,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1375,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1376,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1377,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1378,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1379,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1380,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1381,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1382,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1383,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1384,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1385,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1386,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1387,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1388,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1389,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1390,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1391,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1392,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1393,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1394,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1395,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1396,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1397,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1398,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1399,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1400,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1401,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1402,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1403,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1404,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1405,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1406,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1407,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1408,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1409,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1410,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1411,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1412,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1413,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1414,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1415,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1416,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1417,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1418,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1419,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1420,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1421,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1422,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1423,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1424,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1425,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1426,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1427,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1428,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1429,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1430,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1431,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1432,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1433,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1434,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1435,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1436,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1437,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1438,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1439,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1440,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1441,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1442,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1443,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1444,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1445,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1446,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1447,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1448,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1449,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1450,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1451,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1452,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1453,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1454,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1455,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1456,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1457,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1458,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1459,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1460,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1461,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1462,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1463,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1464,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1465,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1466,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1467,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1468,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1469,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1470,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1471,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1472,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1473,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1474,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1475,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1476,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1477,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1478,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1479,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1480,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1481,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1483,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1484,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1485,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1486,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1492,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1500,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1503,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1504,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1505,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1506,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1507,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1508,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1509,\"textContent\":\"Which shift(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":1510,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1511,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1512,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1513,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1514,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1515,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1516,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1517,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1518,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1519,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1520,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1521,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1522,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1523,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1524,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1525,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1526,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1527,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1528,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1529,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1530,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1531,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1532,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1533,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1534,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1535,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1536,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1537,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1538,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1539,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1540,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1541,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1542,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1543,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1544,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1545,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1546,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1547,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1548,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1549,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1550,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1551,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1552,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1553,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1554,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1555,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1556,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1557,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1558,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1559,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1560,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1561,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1562,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1563,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1564,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1565,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1566,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1567,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1568,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1569,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1570,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1571,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1572,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1573,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1574,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1575,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1576,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1577,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1578,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1579,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1580,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1581,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1582,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1583,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1584,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1585,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1586,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1587,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1588,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1589,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1590,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1591,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1592,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1593,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1594,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1595,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1596,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1597,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1598,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1599,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1600,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1601,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1602,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1603,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1604,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1605,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1606,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1607,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1608,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1609,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1610,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1612,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1613,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1614,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1615,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1617,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1618,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1619,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1620,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1621,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1622,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1623,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1624,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1625,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1627,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1628,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1629,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1630,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1631,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1632,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1633,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1634,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1635,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1636,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1637,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1638,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1639,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1640,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1641,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1642,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1643,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1644,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1645,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1646,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1647,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1648,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1649,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1650,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1651,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1652,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1653,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1654,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1655,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1656,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1657,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1659,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1660,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1661,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1662,\"textContent\":\"Which shift(s) start at the same time as F?\"}]},{\"nodeType\":3,\"id\":1663,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1664,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1665,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1666,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1667,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1668,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1669,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1670,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1671,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1672,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1673,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1674,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1675,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1676,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1677,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1678,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1679,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1680,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1681,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1682,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1683,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1684,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1686,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1687,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1688,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1689,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1690,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1691,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1692,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1693,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1694,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1695,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1696,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1697,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1698,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1699,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1700,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1701,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1702,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1703,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1704,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1705,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1706,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1707,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1708,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1709,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1710,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1711,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1712,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1713,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1714,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1715,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1716,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1717,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1718,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1720,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1721,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1722,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1723,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1724,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1725,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1726,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1727,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1728,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1729,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1730,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1731,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1732,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1733,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1734,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1735,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1736,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1737,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1738,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1739,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1741,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1742,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1743,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1744,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1746,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1747,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1748,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1749,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1750,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1751,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1752,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1753,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1754,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1755,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1756,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1757,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1758,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1759,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1760,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1761,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1762,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1763,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1764,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1765,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1766,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1767,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1768,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1769,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1770,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1771,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1772,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1773,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1774,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1775,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1776,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1777,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1778,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1779,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1780,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1781,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1782,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1783,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1784,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1785,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1786,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1787,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1788,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1789,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1790,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1791,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1792,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1793,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1794,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1795,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1796,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1797,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1798,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1799,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1800,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1801,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1802,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1803,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1804,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1805,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1806,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1807,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1808,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1809,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1810,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1812,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1813,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1814,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1815,\"textContent\":\"Which 2 shifts end when Z begins?\"}]},{\"nodeType\":3,\"id\":1816,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1817,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1818,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1819,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1820,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1821,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1822,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1823,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1824,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1825,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1826,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1827,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1828,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1829,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1830,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1831,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1832,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1833,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1834,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1835,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1836,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1837,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1838,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1839,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1840,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1841,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1842,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1843,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1844,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1845,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1846,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1847,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1848,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1849,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1850,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1851,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1852,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1853,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1854,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1855,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1856,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1857,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1858,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1859,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1860,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1861,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1862,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1863,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1864,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1865,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1866,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1867,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1868,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1869,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1870,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1871,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1872,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1873,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1874,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1875,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1876,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1877,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1878,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1879,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1880,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1881,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1882,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1883,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1884,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1885,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1886,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1887,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1888,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1889,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1890,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1891,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1892,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1894,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1895,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1896,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1897,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1899,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1900,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1901,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1902,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1903,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1904,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1905,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1906,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1907,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1908,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1909,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1910,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1911,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1912,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1913,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1914,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1915,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1916,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1917,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1918,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1919,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1920,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1921,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1922,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1923,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1924,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1925,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1926,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1927,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1928,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1929,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1930,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1931,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1932,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1933,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1934,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1935,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1936,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1937,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1938,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1939,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1940,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1941,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1942,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1943,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1944,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1945,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1946,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1947,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1948,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1949,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1950,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1951,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1952,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1953,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1954,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1955,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1956,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1957,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1958,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1959,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1960,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1961,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1962,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1963,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1965,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1966,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1967,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1968,\"textContent\":\"Which shift(s) end at 3pm?\"}]},{\"nodeType\":3,\"id\":1969,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1970,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1971,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1972,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1973,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1974,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1975,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1976,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1977,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1978,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1979,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1980,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1981,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1982,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1983,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1984,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1985,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1986,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1987,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1988,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1989,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1990,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1991,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1992,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1993,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1994,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1995,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1996,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1997,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1998,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1999,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2000,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2001,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2002,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2003,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2004,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2005,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2006,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2007,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2008,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2009,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2010,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2011,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2012,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2013,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2014,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2015,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2016,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2017,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2018,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2019,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2020,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2021,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2022,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2023,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2024,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2025,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2026,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2027,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2028,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2029,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2030,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2031,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2032,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2033,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2034,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2035,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2036,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2037,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2038,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2039,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2040,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2041,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2042,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2043,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2044,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2045,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2047,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2048,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2049,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2050,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2052,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2053,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2054,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2055,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2056,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2057,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2058,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2059,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2060,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2061,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2062,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2063,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2064,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2065,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2066,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2067,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2068,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2069,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2070,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2071,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2072,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2073,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2074,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2075,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2076,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2077,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2078,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2079,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2080,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2081,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2082,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2083,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2084,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2085,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2086,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2087,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2088,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2089,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2090,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2091,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2092,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2093,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2094,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2095,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2096,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2097,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2098,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2099,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2100,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2101,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2102,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2103,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2104,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2105,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2106,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2107,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2108,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2109,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2110,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2111,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2112,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2113,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2114,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2115,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2116,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2118,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":2119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2120,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2121,\"textContent\":\"Coffee breaks happen halfway through a shift. \"},{\"nodeType\":1,\"id\":2122,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":2123,\"textContent\":\"Which shifts share a break at 2pm?\"}]},{\"nodeType\":3,\"id\":2124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2125,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":2126,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2127,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2128,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2129,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2130,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2131,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":2132,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2133,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2134,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2135,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2136,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2137,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2138,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2139,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":2140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2141,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2142,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2143,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2144,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2145,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2146,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2147,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":2148,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2149,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2150,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2151,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2152,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2153,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2154,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2155,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2156,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2157,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2158,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2159,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2160,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2161,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2162,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2163,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2164,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2165,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2166,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2167,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2168,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2169,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2170,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2171,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2172,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2173,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2174,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2175,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2176,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2177,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2178,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2179,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2180,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2181,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2182,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2183,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2184,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2185,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2186,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2187,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2188,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2189,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2190,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2191,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2192,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2193,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2194,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2195,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2196,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2197,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2198,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2199,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2200,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2202,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2203,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2204,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2205,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2211,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2219,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2227,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2235,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2243,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2251,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2259,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2267,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2270,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2271,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2273,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\".strategy\",\"style\":\"display: block;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2274,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2275,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2276,\"textContent\":\"Please describe how to determine what event(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":2277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2278,\"tagName\":\"TEXTAREA\",\"attributes\":{\"id\":\"strategyAnswer\",\"rows\":\"5\",\"cols\":\"80\"}},{\"nodeType\":3,\"id\":2279,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2280,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2281,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2282},{\"nodeType\":3,\"id\":2283,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2284},{\"nodeType\":3,\"id\":2285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2286,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"fixbottom\"},\"childNodes\":[{\"nodeType\":3,\"id\":2287,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2288,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"testingButton\",\"style\":\"display:none;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2289,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2290,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2291,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"strategyButton\",\"style\":\"display: block;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2292,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2293,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2294,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2295,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2296},{\"nodeType\":3,\"id\":2297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2298,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"d3container\"},\"childNodes\":[{\"nodeType\":1,\"id\":2299,\"tagName\":\"svg\",\"attributes\":{\"width\":\"930\",\"height\":\"915\"},\"childNodes\":[{\"nodeType\":1,\"id\":2300,\"tagName\":\"g\",\"attributes\":{\"transform\":\"translate(100,25)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2301,\"tagName\":\"g\",\"attributes\":{\"class\":\"leaders\"}},{\"nodeType\":1,\"id\":2302,\"tagName\":\"g\",\"attributes\":{\"class\":\"static-scaffold\"}},{\"nodeType\":1,\"id\":2303,\"tagName\":\"g\",\"attributes\":{\"class\":\"xaxis\",\"transform\":\"translate(0,800)\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"middle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2304,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M0.5,6V0.5H800.5V6\"}},{\"nodeType\":1,\"id\":2305,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2306,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2307,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2308,\"textContent\":\"08 AM\"}]}]},{\"nodeType\":1,\"id\":2309,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(33.83333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2310,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2311,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2312,\"textContent\":\"08:30\"}]}]},{\"nodeType\":1,\"id\":2313,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(67.16666666666666,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2314,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2315,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2316,\"textContent\":\"09 AM\"}]}]},{\"nodeType\":1,\"id\":2317,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(100.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2318,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2319,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2320,\"textContent\":\"09:30\"}]}]},{\"nodeType\":1,\"id\":2321,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(133.83333333333331,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2322,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2323,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2324,\"textContent\":\"10 AM\"}]}]},{\"nodeType\":1,\"id\":2325,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(167.16666666666669,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2326,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2327,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2328,\"textContent\":\"10:30\"}]}]},{\"nodeType\":1,\"id\":2329,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(200.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2330,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2331,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2332,\"textContent\":\"11 AM\"}]}]},{\"nodeType\":1,\"id\":2333,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(233.83333333333334,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2334,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2335,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2336,\"textContent\":\"11:30\"}]}]},{\"nodeType\":1,\"id\":2337,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(267.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2338,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2339,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2340,\"textContent\":\"12 PM\"}]}]},{\"nodeType\":1,\"id\":2341,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(300.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2342,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2343,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2344,\"textContent\":\"12:30\"}]}]},{\"nodeType\":1,\"id\":2345,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(333.83333333333337,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2346,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2347,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2348,\"textContent\":\"01 PM\"}]}]},{\"nodeType\":1,\"id\":2349,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(367.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2350,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2351,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2352,\"textContent\":\"01:30\"}]}]},{\"nodeType\":1,\"id\":2353,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(400.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2354,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2355,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2356,\"textContent\":\"02 PM\"}]}]},{\"nodeType\":1,\"id\":2357,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(433.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2358,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2359,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2360,\"textContent\":\"02:30\"}]}]},{\"nodeType\":1,\"id\":2361,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(467.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2362,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2363,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2364,\"textContent\":\"03 PM\"}]}]},{\"nodeType\":1,\"id\":2365,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(500.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2366,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2367,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2368,\"textContent\":\"03:30\"}]}]},{\"nodeType\":1,\"id\":2369,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(533.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2370,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2371,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2372,\"textContent\":\"04 PM\"}]}]},{\"nodeType\":1,\"id\":2373,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(567.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2374,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2375,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2376,\"textContent\":\"04:30\"}]}]},{\"nodeType\":1,\"id\":2377,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(600.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2378,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2379,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2380,\"textContent\":\"05 PM\"}]}]},{\"nodeType\":1,\"id\":2381,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(633.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2382,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2383,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2384,\"textContent\":\"05:30\"}]}]},{\"nodeType\":1,\"id\":2385,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(667.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2386,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2387,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2388,\"textContent\":\"06 PM\"}]}]},{\"nodeType\":1,\"id\":2389,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(700.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2390,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2391,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2392,\"textContent\":\"06:30\"}]}]},{\"nodeType\":1,\"id\":2393,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(733.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2394,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2395,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2396,\"textContent\":\"07 PM\"}]}]},{\"nodeType\":1,\"id\":2397,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(767.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2398,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2399,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2400,\"textContent\":\"07:30\"}]}]},{\"nodeType\":1,\"id\":2401,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(800.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2402,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2403,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2404,\"textContent\":\"08 PM\"}]}]},{\"nodeType\":1,\"id\":2405,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2406,\"tagName\":\"text\",\"attributes\":{\"x\":\"533.3333333333334\",\"y\":\"80\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2407,\"textContent\":\"START & END TIME (time of day)\"}]}]}]},{\"nodeType\":1,\"id\":2408,\"tagName\":\"g\",\"attributes\":{\"class\":\"yaxis\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"end\"},\"childNodes\":[{\"nodeType\":1,\"id\":2409,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M-15,800.5H0.5V0.5H-15\"}},{\"nodeType\":1,\"id\":2410,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,800.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2411,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2412,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2413,\"textContent\":\"0\"}]}]},{\"nodeType\":1,\"id\":2414,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,733.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2415,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2416,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2417,\"textContent\":\"1\"}]}]},{\"nodeType\":1,\"id\":2418,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,667.1666666666667)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2419,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2420,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2421,\"textContent\":\"2\"}]}]},{\"nodeType\":1,\"id\":2422,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,600.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2423,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2424,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2425,\"textContent\":\"3\"}]}]},{\"nodeType\":1,\"id\":2426,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,533.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2427,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2428,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2429,\"textContent\":\"4\"}]}]},{\"nodeType\":1,\"id\":2430,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,467.16666666666663)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2431,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2432,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2433,\"textContent\":\"5\"}]}]},{\"nodeType\":1,\"id\":2434,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,400.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2435,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2436,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2437,\"textContent\":\"6\"}]}]},{\"nodeType\":1,\"id\":2438,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,333.8333333333333)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2439,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2440,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2441,\"textContent\":\"7\"}]}]},{\"nodeType\":1,\"id\":2442,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,267.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2443,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2444,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2445,\"textContent\":\"8\"}]}]},{\"nodeType\":1,\"id\":2446,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,200.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2447,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2448,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2449,\"textContent\":\"9\"}]}]},{\"nodeType\":1,\"id\":2450,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,133.83333333333326)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2451,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2452,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2453,\"textContent\":\"10\"}]}]},{\"nodeType\":1,\"id\":2454,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,67.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2455,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2456,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2457,\"textContent\":\"11\"}]}]},{\"nodeType\":1,\"id\":2458,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,0.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2459,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2460,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2461,\"textContent\":\"12\"}]}]},{\"nodeType\":1,\"id\":2462,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2463,\"tagName\":\"text\",\"attributes\":{\"transform\":\"rotate(-90)\",\"x\":\"-350\",\"y\":\"-60\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2464,\"textContent\":\"DURATION (in hours)\"}]}]}]},{\"nodeType\":1,\"id\":2465,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2466,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2467,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"733.3333333333334\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2468,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2469,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"666.6666666666667\",\"y2\":\"666.6666666666667\"}}]},{\"nodeType\":1,\"id\":2470,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2471,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"600\",\"y2\":\"600\"}}]},{\"nodeType\":1,\"id\":2472,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2473,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"533.3333333333334\",\"y2\":\"533.3333333333334\"}}]},{\"nodeType\":1,\"id\":2474,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2475,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"466.66666666666663\",\"y2\":\"466.66666666666663\"}}]},{\"nodeType\":1,\"id\":2476,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2477,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"400\",\"y2\":\"400\"}}]},{\"nodeType\":1,\"id\":2478,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2479,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"333.3333333333333\",\"y2\":\"333.3333333333333\"}}]},{\"nodeType\":1,\"id\":2480,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2481,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"266.66666666666674\",\"y2\":\"266.66666666666674\"}}]},{\"nodeType\":1,\"id\":2482,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2483,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"200\",\"y2\":\"200\"}}]},{\"nodeType\":1,\"id\":2484,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2485,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"133.33333333333326\",\"y2\":\"133.33333333333326\"}}]},{\"nodeType\":1,\"id\":2486,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2487,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"66.66666666666674\",\"y2\":\"66.66666666666674\"}}]},{\"nodeType\":1,\"id\":2488,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2489,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"0\",\"y2\":\"0\"}}]}]},{\"nodeType\":1,\"id\":2490,\"tagName\":\"g\",\"attributes\":{\"class\":\"xgrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2491,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"0\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2492,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"800\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2493,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"433.3333333333333\",\"y2\":\"66.66666666666674\"}},{\"nodeType\":1,\"id\":2494,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"366.66666666666663\",\"y2\":\"66.66666666666674\"}},{\"nodeType\":1,\"id\":2495,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"466.6666666666667\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2496,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"333.33333333333337\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2497,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"500\",\"y2\":\"200\"}},{\"nodeType\":1,\"id\":2498,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"300\",\"y2\":\"200\"}},{\"nodeType\":1,\"id\":2499,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"533.3333333333333\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2500,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"266.66666666666663\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2501,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"566.6666666666667\",\"y2\":\"333.3333333333333\"}},{\"nodeType\":1,\"id\":2502,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"233.33333333333334\",\"y2\":\"333.3333333333333\"}},{\"nodeType\":1,\"id\":2503,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"600\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2504,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"200\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2505,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"633.3333333333333\",\"y2\":\"466.66666666666663\"}},{\"nodeType\":1,\"id\":2506,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"166.66666666666669\",\"y2\":\"466.66666666666663\"}},{\"nodeType\":1,\"id\":2507,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"666.6666666666667\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2508,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"133.33333333333331\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2509,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"700\",\"y2\":\"600\"}},{\"nodeType\":1,\"id\":2510,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"100\",\"y2\":\"600\"}},{\"nodeType\":1,\"id\":2511,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"733.3333333333333\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2512,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"66.66666666666666\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2513,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"766.6666666666667\",\"y2\":\"733.3333333333334\"}},{\"nodeType\":1,\"id\":2514,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"33.33333333333333\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2515,\"tagName\":\"g\",\"attributes\":{\"class\":\"data\"},\"childNodes\":[{\"nodeType\":1,\"id\":2516,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2517,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"266.66666666666674\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2518,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"258.66666666666674\"},\"childNodes\":[{\"nodeType\":3,\"id\":2519,\"textContent\":\"A \"}]}]},{\"nodeType\":1,\"id\":2520,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2521,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2522,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2523,\"textContent\":\"B \"}]}]},{\"nodeType\":1,\"id\":2524,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2525,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"366.66666666666663\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2526,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"361.66666666666663\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2527,\"textContent\":\"C \"}]}]},{\"nodeType\":1,\"id\":2528,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2529,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"666.6666666666667\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2530,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"661.6666666666667\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2531,\"textContent\":\"D \"}]}]},{\"nodeType\":1,\"id\":2532,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2533,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"200\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2534,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"195\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2535,\"textContent\":\"E \"}]}]},{\"nodeType\":1,\"id\":2536,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2537,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2538,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2539,\"textContent\":\"F \"}]}]},{\"nodeType\":1,\"id\":2540,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2541,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2542,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2543,\"textContent\":\"G \"}]}]},{\"nodeType\":1,\"id\":2544,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2545,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2546,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2547,\"textContent\":\"H \"}]}]},{\"nodeType\":1,\"id\":2548,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2549,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"100\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2550,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"95\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2551,\"textContent\":\"I \"}]}]},{\"nodeType\":1,\"id\":2552,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2553,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"133.33333333333331\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2554,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"128.33333333333331\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2555,\"textContent\":\"J \"}]}]},{\"nodeType\":1,\"id\":2556,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2557,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"133.33333333333326\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2558,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"125.33333333333326\"},\"childNodes\":[{\"nodeType\":3,\"id\":2559,\"textContent\":\"K \"}]}]},{\"nodeType\":1,\"id\":2560,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2561,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"333.3333333333333\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2562,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"325.3333333333333\"},\"childNodes\":[{\"nodeType\":3,\"id\":2563,\"textContent\":\"L \"}]}]},{\"nodeType\":1,\"id\":2564,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2565,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"300\",\"cy\":\"733.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2566,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"295\",\"y\":\"725.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2567,\"textContent\":\"M \"}]}]},{\"nodeType\":1,\"id\":2568,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2569,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"600\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2570,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"595\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2571,\"textContent\":\"N \"}]}]},{\"nodeType\":1,\"id\":2572,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2573,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"433.3333333333333\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2574,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"428.3333333333333\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2575,\"textContent\":\"O \"}]}]},{\"nodeType\":1,\"id\":2576,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2577,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"200\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2578,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"192\"},\"childNodes\":[{\"nodeType\":3,\"id\":2579,\"textContent\":\"P \"}]}]},{\"nodeType\":1,\"id\":2580,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2581,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"533.3333333333333\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2582,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"528.3333333333333\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2583,\"textContent\":\"Z \"}]}]},{\"nodeType\":1,\"id\":2584,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2585,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2586,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2587,\"textContent\":\"X \"}]}]}]}]}]}]},{\"nodeType\":3,\"id\":2588,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2589,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2590},{\"nodeType\":3,\"id\":2591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2592,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2593,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2594,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2595,\"textContent\":\" \"}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 277, dom: 1117, initialDom: 1186",
  "javascriptErrors": []
}