var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["05250585cc81b205bb26f4001e4e31ddea56332d"] = {
  "startTime": "2018-05-25T18:06:05.8998383Z",
  "websitePageUrl": "/",
  "visitTime": 195834,
  "engagementTime": 62543,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1094,
  "tags": [
    "form-interact"
  ],
  "session": {
    "id": "41007c843c87cc894cb64ca9a4b31eeb",
    "created": "2018-05-25T18:06:05.8998383+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.181",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/",
    "tags": [
      "form-interact"
    ],
    "variables": [],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "8be698fe4d96acde48bef76dda9fbf5e",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/41007c843c87cc894cb64ca9a4b31eeb/play"
  },
  "events": [
    {
      "t": 102,
      "e": 102,
      "ty": 0,
      "x": 1920,
      "y": 1094
    },
    {
      "t": 257,
      "e": 257,
      "ty": 14,
      "x": 0,
      "y": 1093
    },
    {
      "t": 10001,
      "e": 5102,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 33971,
      "e": 5102,
      "ty": 40,
      "x": 0,
      "y": 0
    },
    {
      "t": 34001,
      "e": 5132,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 34002,
      "e": 5133,
      "ty": 2,
      "x": 551,
      "y": 30
    },
    {
      "t": 34003,
      "e": 5134,
      "ty": 41,
      "x": 18699,
      "y": 1218,
      "ta": "html > body"
    },
    {
      "t": 40001,
      "e": 10134,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 140121,
      "e": 10134,
      "ty": 2,
      "x": 553,
      "y": 82
    },
    {
      "t": 140220,
      "e": 10233,
      "ty": 2,
      "x": 510,
      "y": 805
    },
    {
      "t": 140271,
      "e": 10284,
      "ty": 41,
      "x": 9423,
      "y": 58562,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 140321,
      "e": 10334,
      "ty": 2,
      "x": 479,
      "y": 1005
    },
    {
      "t": 140421,
      "e": 10434,
      "ty": 2,
      "x": 529,
      "y": 999
    },
    {
      "t": 140520,
      "e": 10533,
      "ty": 2,
      "x": 957,
      "y": 860
    },
    {
      "t": 140521,
      "e": 10534,
      "ty": 41,
      "x": 32644,
      "y": 33956,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 140621,
      "e": 10634,
      "ty": 2,
      "x": 964,
      "y": 860
    },
    {
      "t": 140721,
      "e": 10734,
      "ty": 2,
      "x": 894,
      "y": 890
    },
    {
      "t": 140771,
      "e": 10784,
      "ty": 41,
      "x": 28019,
      "y": 62223,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 140820,
      "e": 10833,
      "ty": 2,
      "x": 863,
      "y": 902
    },
    {
      "t": 141021,
      "e": 11034,
      "ty": 2,
      "x": 840,
      "y": 916
    },
    {
      "t": 141021,
      "e": 11034,
      "ty": 41,
      "x": 7677,
      "y": 23877,
      "ta": "> div.masterdiv > div:[2] > div > div > label"
    },
    {
      "t": 141120,
      "e": 11133,
      "ty": 2,
      "x": 807,
      "y": 929
    },
    {
      "t": 141271,
      "e": 11284,
      "ty": 41,
      "x": 14950,
      "y": 55755,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 141320,
      "e": 11333,
      "ty": 2,
      "x": 809,
      "y": 924
    },
    {
      "t": 141421,
      "e": 11434,
      "ty": 2,
      "x": 810,
      "y": 922
    },
    {
      "t": 141485,
      "e": 11498,
      "ty": 3,
      "x": 811,
      "y": 922,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 141520,
      "e": 11533,
      "ty": 2,
      "x": 812,
      "y": 922
    },
    {
      "t": 141520,
      "e": 11533,
      "ty": 41,
      "x": 28057,
      "y": 36095,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 141580,
      "e": 11593,
      "ty": 4,
      "x": 28057,
      "y": 36095,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 141580,
      "e": 11593,
      "ty": 5,
      "x": 812,
      "y": 922,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 141581,
      "e": 11594,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox"
    },
    {
      "t": 141585,
      "e": 11598,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox",
      "v": "on"
    },
    {
      "t": 141721,
      "e": 11734,
      "ty": 2,
      "x": 829,
      "y": 949
    },
    {
      "t": 141771,
      "e": 11784,
      "ty": 41,
      "x": 26839,
      "y": 59393,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 141820,
      "e": 11833,
      "ty": 2,
      "x": 838,
      "y": 994
    },
    {
      "t": 141920,
      "e": 11933,
      "ty": 2,
      "x": 837,
      "y": 994
    },
    {
      "t": 142021,
      "e": 12034,
      "ty": 41,
      "x": 26740,
      "y": 60086,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 142220,
      "e": 12233,
      "ty": 2,
      "x": 831,
      "y": 891
    },
    {
      "t": 142271,
      "e": 12284,
      "ty": 41,
      "x": 26937,
      "y": 50339,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 142320,
      "e": 12333,
      "ty": 2,
      "x": 869,
      "y": 855
    },
    {
      "t": 142421,
      "e": 12434,
      "ty": 2,
      "x": 943,
      "y": 832
    },
    {
      "t": 142521,
      "e": 12534,
      "ty": 2,
      "x": 1018,
      "y": 884
    },
    {
      "t": 142521,
      "e": 12534,
      "ty": 41,
      "x": 35645,
      "y": 62042,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 142620,
      "e": 12633,
      "ty": 2,
      "x": 1043,
      "y": 939
    },
    {
      "t": 142721,
      "e": 12734,
      "ty": 2,
      "x": 1050,
      "y": 968
    },
    {
      "t": 142772,
      "e": 12785,
      "ty": 41,
      "x": 37219,
      "y": 58908,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 142821,
      "e": 12834,
      "ty": 2,
      "x": 1050,
      "y": 985
    },
    {
      "t": 142921,
      "e": 12934,
      "ty": 2,
      "x": 1050,
      "y": 1013
    },
    {
      "t": 143020,
      "e": 13033,
      "ty": 2,
      "x": 1048,
      "y": 1027
    },
    {
      "t": 143021,
      "e": 13034,
      "ty": 41,
      "x": 37121,
      "y": 62371,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 143121,
      "e": 13134,
      "ty": 2,
      "x": 1044,
      "y": 1033
    },
    {
      "t": 143221,
      "e": 13234,
      "ty": 2,
      "x": 1043,
      "y": 1033
    },
    {
      "t": 143271,
      "e": 13284,
      "ty": 41,
      "x": 36875,
      "y": 62786,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 143521,
      "e": 13534,
      "ty": 2,
      "x": 1042,
      "y": 1033
    },
    {
      "t": 143521,
      "e": 13534,
      "ty": 41,
      "x": 36826,
      "y": 62786,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 143621,
      "e": 13634,
      "ty": 2,
      "x": 1041,
      "y": 1034
    },
    {
      "t": 143771,
      "e": 13784,
      "ty": 41,
      "x": 36777,
      "y": 62855,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 144021,
      "e": 14034,
      "ty": 2,
      "x": 1040,
      "y": 1034
    },
    {
      "t": 144021,
      "e": 14034,
      "ty": 41,
      "x": 36727,
      "y": 62855,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 144921,
      "e": 14934,
      "ty": 2,
      "x": 1037,
      "y": 1036
    },
    {
      "t": 145021,
      "e": 15034,
      "ty": 2,
      "x": 1036,
      "y": 1037
    },
    {
      "t": 145021,
      "e": 15034,
      "ty": 41,
      "x": 36531,
      "y": 63063,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 145520,
      "e": 15533,
      "ty": 2,
      "x": 1034,
      "y": 1040
    },
    {
      "t": 145522,
      "e": 15535,
      "ty": 41,
      "x": 36432,
      "y": 63271,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 145621,
      "e": 15634,
      "ty": 2,
      "x": 1033,
      "y": 1042
    },
    {
      "t": 145771,
      "e": 15784,
      "ty": 41,
      "x": 36383,
      "y": 63409,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 146221,
      "e": 16234,
      "ty": 2,
      "x": 1030,
      "y": 1049
    },
    {
      "t": 146271,
      "e": 16284,
      "ty": 41,
      "x": 36235,
      "y": 63894,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 146521,
      "e": 16534,
      "ty": 2,
      "x": 1022,
      "y": 1049
    },
    {
      "t": 146521,
      "e": 16534,
      "ty": 41,
      "x": 35842,
      "y": 63894,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 146621,
      "e": 16634,
      "ty": 2,
      "x": 1020,
      "y": 1049
    },
    {
      "t": 146721,
      "e": 16734,
      "ty": 2,
      "x": 1018,
      "y": 1049
    },
    {
      "t": 146771,
      "e": 16784,
      "ty": 41,
      "x": 35547,
      "y": 63894,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 146821,
      "e": 16834,
      "ty": 2,
      "x": 1013,
      "y": 1051
    },
    {
      "t": 146920,
      "e": 16933,
      "ty": 2,
      "x": 1012,
      "y": 1051
    },
    {
      "t": 147021,
      "e": 17034,
      "ty": 41,
      "x": 35350,
      "y": 64033,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 149270,
      "e": 19283,
      "ty": 41,
      "x": 35301,
      "y": 64033,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 149320,
      "e": 19333,
      "ty": 2,
      "x": 1006,
      "y": 1052
    },
    {
      "t": 149420,
      "e": 19433,
      "ty": 2,
      "x": 999,
      "y": 1053
    },
    {
      "t": 149520,
      "e": 19533,
      "ty": 2,
      "x": 996,
      "y": 1058
    },
    {
      "t": 149521,
      "e": 19534,
      "ty": 41,
      "x": 34563,
      "y": 64517,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 149620,
      "e": 19633,
      "ty": 2,
      "x": 990,
      "y": 1087
    },
    {
      "t": 149770,
      "e": 19783,
      "ty": 41,
      "x": 43963,
      "y": 27587,
      "ta": "#start"
    },
    {
      "t": 149845,
      "e": 19858,
      "ty": 3,
      "x": 990,
      "y": 1087,
      "ta": "#start"
    },
    {
      "t": 149847,
      "e": 19860,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox"
    },
    {
      "t": 149847,
      "e": 19860,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 149915,
      "e": 19928,
      "ty": 4,
      "x": 43963,
      "y": 27587,
      "ta": "#start"
    },
    {
      "t": 149916,
      "e": 19929,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 149917,
      "e": 19930,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 149917,
      "e": 19930,
      "ty": 5,
      "x": 990,
      "y": 1087,
      "ta": "#start"
    },
    {
      "t": 150020,
      "e": 20033,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 150419,
      "e": 20432,
      "ty": 2,
      "x": 987,
      "y": 1081
    },
    {
      "t": 150520,
      "e": 20533,
      "ty": 2,
      "x": 985,
      "y": 1081
    },
    {
      "t": 150520,
      "e": 20533,
      "ty": 41,
      "x": 33645,
      "y": 59441,
      "ta": "html > body"
    },
    {
      "t": 150820,
      "e": 20833,
      "ty": 2,
      "x": 984,
      "y": 1080
    },
    {
      "t": 150924,
      "e": 20937,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 150938,
      "e": 20951,
      "ty": 2,
      "x": 977,
      "y": 1068
    },
    {
      "t": 151020,
      "e": 21033,
      "ty": 2,
      "x": 975,
      "y": 1066
    },
    {
      "t": 151020,
      "e": 21033,
      "ty": 41,
      "x": 33301,
      "y": 58610,
      "ta": "html > body"
    },
    {
      "t": 151220,
      "e": 21233,
      "ty": 2,
      "x": 973,
      "y": 1066
    },
    {
      "t": 151270,
      "e": 21283,
      "ty": 41,
      "x": 33197,
      "y": 58610,
      "ta": "html > body"
    },
    {
      "t": 151320,
      "e": 21333,
      "ty": 2,
      "x": 972,
      "y": 1066
    },
    {
      "t": 151520,
      "e": 21533,
      "ty": 2,
      "x": 963,
      "y": 1044
    },
    {
      "t": 151520,
      "e": 21533,
      "ty": 41,
      "x": 32888,
      "y": 57391,
      "ta": "html > body"
    },
    {
      "t": 151620,
      "e": 21633,
      "ty": 2,
      "x": 917,
      "y": 796
    },
    {
      "t": 151661,
      "e": 21674,
      "ty": 6,
      "x": 906,
      "y": 728,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 151693,
      "e": 21706,
      "ty": 7,
      "x": 902,
      "y": 701,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 151710,
      "e": 21723,
      "ty": 6,
      "x": 899,
      "y": 692,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 151719,
      "e": 21732,
      "ty": 2,
      "x": 899,
      "y": 692
    },
    {
      "t": 151770,
      "e": 21783,
      "ty": 41,
      "x": 19249,
      "y": 18724,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 151811,
      "e": 21824,
      "ty": 7,
      "x": 896,
      "y": 673,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 151820,
      "e": 21833,
      "ty": 2,
      "x": 896,
      "y": 673
    },
    {
      "t": 151920,
      "e": 21933,
      "ty": 2,
      "x": 889,
      "y": 632
    },
    {
      "t": 152020,
      "e": 22033,
      "ty": 2,
      "x": 885,
      "y": 615
    },
    {
      "t": 152021,
      "e": 22034,
      "ty": 41,
      "x": 16654,
      "y": 0,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 152120,
      "e": 22133,
      "ty": 2,
      "x": 883,
      "y": 610
    },
    {
      "t": 152148,
      "e": 22161,
      "ty": 6,
      "x": 882,
      "y": 605,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 152220,
      "e": 22233,
      "ty": 2,
      "x": 879,
      "y": 599
    },
    {
      "t": 152270,
      "e": 22283,
      "ty": 41,
      "x": 15356,
      "y": 40569,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 152320,
      "e": 22333,
      "ty": 2,
      "x": 879,
      "y": 597
    },
    {
      "t": 152372,
      "e": 22385,
      "ty": 3,
      "x": 879,
      "y": 597,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 152373,
      "e": 22386,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 152419,
      "e": 22432,
      "ty": 4,
      "x": 15356,
      "y": 34327,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 152419,
      "e": 22432,
      "ty": 5,
      "x": 879,
      "y": 597,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 152520,
      "e": 22533,
      "ty": 41,
      "x": 15356,
      "y": 34327,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 153137,
      "e": 23150,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "16"
    },
    {
      "t": 153288,
      "e": 23301,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "78"
    },
    {
      "t": 153289,
      "e": 23302,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 153335,
      "e": 23348,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "N"
    },
    {
      "t": 153447,
      "e": 23460,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "79"
    },
    {
      "t": 153447,
      "e": 23460,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 153472,
      "e": 23485,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "No"
    },
    {
      "t": 153568,
      "e": 23581,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "No"
    },
    {
      "t": 153584,
      "e": 23597,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "86"
    },
    {
      "t": 153585,
      "e": 23598,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 153640,
      "e": 23653,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "Nov"
    },
    {
      "t": 153752,
      "e": 23765,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "69"
    },
    {
      "t": 153752,
      "e": 23765,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 153847,
      "e": 23860,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "Nove"
    },
    {
      "t": 153855,
      "e": 23868,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "77"
    },
    {
      "t": 153855,
      "e": 23868,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 153927,
      "e": 23940,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "+||m"
    },
    {
      "t": 153991,
      "e": 24004,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "69"
    },
    {
      "t": 153992,
      "e": 24005,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 154063,
      "e": 24076,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "+||e"
    },
    {
      "t": 154072,
      "e": 24085,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "66"
    },
    {
      "t": 154073,
      "e": 24086,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 154119,
      "e": 24132,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "+||b"
    },
    {
      "t": 154225,
      "e": 24238,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "Novemeb"
    },
    {
      "t": 154416,
      "e": 24429,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "8"
    },
    {
      "t": 154463,
      "e": 24476,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "Noveme"
    },
    {
      "t": 154568,
      "e": 24581,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "8"
    },
    {
      "t": 154624,
      "e": 24637,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "Novem"
    },
    {
      "t": 154816,
      "e": 24829,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "66"
    },
    {
      "t": 154816,
      "e": 24829,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 154872,
      "e": 24885,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "+||b"
    },
    {
      "t": 154873,
      "e": 24886,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "69"
    },
    {
      "t": 154874,
      "e": 24887,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 154959,
      "e": 24972,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "+||e"
    },
    {
      "t": 155031,
      "e": 25044,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "82"
    },
    {
      "t": 155032,
      "e": 25045,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 155104,
      "e": 25117,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "+||r"
    },
    {
      "t": 155225,
      "e": 25238,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "November"
    },
    {
      "t": 155248,
      "e": 25261,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "32"
    },
    {
      "t": 155249,
      "e": 25262,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 155287,
      "e": 25300,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "+|| "
    },
    {
      "t": 155425,
      "e": 25438,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "November "
    },
    {
      "t": 156064,
      "e": 26077,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "8"
    },
    {
      "t": 156127,
      "e": 26140,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "November"
    },
    {
      "t": 156720,
      "e": 26733,
      "ty": 2,
      "x": 894,
      "y": 587
    },
    {
      "t": 156733,
      "e": 26746,
      "ty": 7,
      "x": 930,
      "y": 579,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 156765,
      "e": 26778,
      "ty": 6,
      "x": 934,
      "y": 586,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 156771,
      "e": 26784,
      "ty": 41,
      "x": 27252,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 156799,
      "e": 26812,
      "ty": 7,
      "x": 901,
      "y": 621,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 156821,
      "e": 26834,
      "ty": 2,
      "x": 889,
      "y": 638
    },
    {
      "t": 156920,
      "e": 26933,
      "ty": 2,
      "x": 867,
      "y": 672
    },
    {
      "t": 156966,
      "e": 26979,
      "ty": 6,
      "x": 859,
      "y": 680,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 157021,
      "e": 27034,
      "ty": 2,
      "x": 858,
      "y": 685
    },
    {
      "t": 157021,
      "e": 27034,
      "ty": 41,
      "x": 10814,
      "y": 18724,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 157204,
      "e": 27217,
      "ty": 3,
      "x": 858,
      "y": 685,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 157206,
      "e": 27219,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "November"
    },
    {
      "t": 157207,
      "e": 27220,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 157207,
      "e": 27220,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 157315,
      "e": 27328,
      "ty": 4,
      "x": 10814,
      "y": 18724,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 157315,
      "e": 27328,
      "ty": 5,
      "x": 858,
      "y": 685,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 157744,
      "e": 27757,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "49"
    },
    {
      "t": 157746,
      "e": 27759,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 157831,
      "e": 27844,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "1"
    },
    {
      "t": 157895,
      "e": 27908,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "49"
    },
    {
      "t": 157896,
      "e": 27909,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 157967,
      "e": 27980,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "11"
    },
    {
      "t": 158152,
      "e": 28165,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "52"
    },
    {
      "t": 158153,
      "e": 28166,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 158215,
      "e": 28228,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "11*"
    },
    {
      "t": 158417,
      "e": 28430,
      "ty": 7,
      "x": 895,
      "y": 736,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 158417,
      "e": 28430,
      "ty": 6,
      "x": 895,
      "y": 736,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 158420,
      "e": 28433,
      "ty": 2,
      "x": 895,
      "y": 736
    },
    {
      "t": 158433,
      "e": 28446,
      "ty": 7,
      "x": 908,
      "y": 759,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 158520,
      "e": 28533,
      "ty": 2,
      "x": 916,
      "y": 769
    },
    {
      "t": 158520,
      "e": 28533,
      "ty": 41,
      "x": 31269,
      "y": 42157,
      "ta": "html > body"
    },
    {
      "t": 158621,
      "e": 28634,
      "ty": 2,
      "x": 930,
      "y": 756
    },
    {
      "t": 158667,
      "e": 28680,
      "ty": 6,
      "x": 942,
      "y": 740,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 158720,
      "e": 28733,
      "ty": 2,
      "x": 954,
      "y": 729
    },
    {
      "t": 158771,
      "e": 28784,
      "ty": 41,
      "x": 31994,
      "y": 35746,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 158820,
      "e": 28833,
      "ty": 2,
      "x": 958,
      "y": 726
    },
    {
      "t": 160020,
      "e": 30033,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 160957,
      "e": 30970,
      "ty": 3,
      "x": 958,
      "y": 726,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 160958,
      "e": 30971,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "11*"
    },
    {
      "t": 160959,
      "e": 30972,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 160959,
      "e": 30972,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 161051,
      "e": 31064,
      "ty": 4,
      "x": 31994,
      "y": 35746,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 161053,
      "e": 31066,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 161053,
      "e": 31066,
      "ty": 5,
      "x": 958,
      "y": 726,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 161053,
      "e": 31066,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 162121,
      "e": 32134,
      "ty": 2,
      "x": 957,
      "y": 726
    },
    {
      "t": 162151,
      "e": 32164,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 162159,
      "e": 32172,
      "ty": 6,
      "x": 941,
      "y": 726,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 162221,
      "e": 32234,
      "ty": 2,
      "x": 923,
      "y": 726
    },
    {
      "t": 162271,
      "e": 32284,
      "ty": 41,
      "x": 29738,
      "y": 63231,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 162320,
      "e": 32333,
      "ty": 2,
      "x": 919,
      "y": 726
    },
    {
      "t": 163020,
      "e": 33033,
      "ty": 2,
      "x": 899,
      "y": 719
    },
    {
      "t": 163020,
      "e": 33033,
      "ty": 41,
      "x": 28725,
      "y": 46847,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 163052,
      "e": 33065,
      "ty": 7,
      "x": 846,
      "y": 696,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 163053,
      "e": 33066,
      "ty": 6,
      "x": 846,
      "y": 696,
      "ta": "> div.masterdiv > div:[2] > div > ul > li"
    },
    {
      "t": 163087,
      "e": 33100,
      "ty": 7,
      "x": 773,
      "y": 657,
      "ta": "> div.masterdiv > div:[2] > div > ul > li"
    },
    {
      "t": 163120,
      "e": 33133,
      "ty": 2,
      "x": 727,
      "y": 631
    },
    {
      "t": 163221,
      "e": 33234,
      "ty": 2,
      "x": 685,
      "y": 600
    },
    {
      "t": 163271,
      "e": 33284,
      "ty": 41,
      "x": 43037,
      "y": 55755,
      "ta": "> div.masterdiv > div:[2] > div > table > tbody > tr:[5] > td > i"
    },
    {
      "t": 163420,
      "e": 33433,
      "ty": 2,
      "x": 685,
      "y": 602
    },
    {
      "t": 163520,
      "e": 33533,
      "ty": 2,
      "x": 678,
      "y": 602
    },
    {
      "t": 163520,
      "e": 33533,
      "ty": 41,
      "x": 42180,
      "y": 62309,
      "ta": "> div.masterdiv > div:[2] > div > table > tbody > tr:[5] > td > i"
    },
    {
      "t": 163604,
      "e": 33617,
      "ty": 6,
      "x": 618,
      "y": 673,
      "ta": "> div.masterdiv > div:[2] > div > ul > li"
    },
    {
      "t": 163620,
      "e": 33633,
      "ty": 7,
      "x": 603,
      "y": 703,
      "ta": "> div.masterdiv > div:[2] > div > ul > li"
    },
    {
      "t": 163620,
      "e": 33633,
      "ty": 6,
      "x": 603,
      "y": 703,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 163621,
      "e": 33634,
      "ty": 2,
      "x": 603,
      "y": 703
    },
    {
      "t": 163654,
      "e": 33667,
      "ty": 7,
      "x": 593,
      "y": 736,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 163655,
      "e": 33668,
      "ty": 6,
      "x": 593,
      "y": 736,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 163704,
      "e": 33717,
      "ty": 7,
      "x": 595,
      "y": 760,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 163704,
      "e": 33717,
      "ty": 6,
      "x": 595,
      "y": 760,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[4]"
    },
    {
      "t": 163720,
      "e": 33733,
      "ty": 2,
      "x": 596,
      "y": 769
    },
    {
      "t": 163771,
      "e": 33784,
      "ty": 41,
      "x": 13475,
      "y": 44506,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[4]"
    },
    {
      "t": 163820,
      "e": 33833,
      "ty": 2,
      "x": 598,
      "y": 774
    },
    {
      "t": 163921,
      "e": 33934,
      "ty": 2,
      "x": 598,
      "y": 775
    },
    {
      "t": 164021,
      "e": 34034,
      "ty": 2,
      "x": 568,
      "y": 773
    },
    {
      "t": 164021,
      "e": 34034,
      "ty": 41,
      "x": 11955,
      "y": 42166,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[4]"
    },
    {
      "t": 164087,
      "e": 34100,
      "ty": 7,
      "x": 513,
      "y": 746,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[4]"
    },
    {
      "t": 164087,
      "e": 34100,
      "ty": 6,
      "x": 513,
      "y": 746,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 164120,
      "e": 34133,
      "ty": 2,
      "x": 496,
      "y": 732
    },
    {
      "t": 164121,
      "e": 34134,
      "ty": 7,
      "x": 481,
      "y": 718,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 164122,
      "e": 34135,
      "ty": 6,
      "x": 481,
      "y": 718,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 164155,
      "e": 34168,
      "ty": 7,
      "x": 459,
      "y": 695,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 164155,
      "e": 34168,
      "ty": 6,
      "x": 459,
      "y": 695,
      "ta": "> div.masterdiv > div:[2] > div > ul > li"
    },
    {
      "t": 164220,
      "e": 34233,
      "ty": 2,
      "x": 452,
      "y": 680
    },
    {
      "t": 164270,
      "e": 34283,
      "ty": 41,
      "x": 6078,
      "y": 9398,
      "ta": "> div.masterdiv > div:[2] > div > ul > li"
    },
    {
      "t": 164320,
      "e": 34333,
      "ty": 2,
      "x": 455,
      "y": 672
    },
    {
      "t": 164339,
      "e": 34352,
      "ty": 7,
      "x": 455,
      "y": 669,
      "ta": "> div.masterdiv > div:[2] > div > ul > li"
    },
    {
      "t": 164421,
      "e": 34434,
      "ty": 2,
      "x": 457,
      "y": 668
    },
    {
      "t": 164522,
      "e": 34535,
      "ty": 41,
      "x": 8046,
      "y": 40593,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 164621,
      "e": 34634,
      "ty": 2,
      "x": 453,
      "y": 665
    },
    {
      "t": 164720,
      "e": 34733,
      "ty": 2,
      "x": 371,
      "y": 636
    },
    {
      "t": 164770,
      "e": 34783,
      "ty": 41,
      "x": 1453,
      "y": 33312,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 164820,
      "e": 34833,
      "ty": 2,
      "x": 321,
      "y": 620
    },
    {
      "t": 165021,
      "e": 35034,
      "ty": 41,
      "x": 1355,
      "y": 33157,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 165120,
      "e": 35133,
      "ty": 2,
      "x": 349,
      "y": 619
    },
    {
      "t": 165221,
      "e": 35234,
      "ty": 2,
      "x": 360,
      "y": 619
    },
    {
      "t": 165271,
      "e": 35284,
      "ty": 41,
      "x": 3273,
      "y": 33002,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 167220,
      "e": 37233,
      "ty": 2,
      "x": 361,
      "y": 620
    },
    {
      "t": 167270,
      "e": 37283,
      "ty": 41,
      "x": 4946,
      "y": 7058,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 167321,
      "e": 37334,
      "ty": 2,
      "x": 450,
      "y": 634
    },
    {
      "t": 167420,
      "e": 37433,
      "ty": 2,
      "x": 493,
      "y": 634
    },
    {
      "t": 167521,
      "e": 37534,
      "ty": 41,
      "x": 43622,
      "y": 16434,
      "ta": "> div.masterdiv > div:[2] > div > p:[2] > b"
    },
    {
      "t": 167620,
      "e": 37633,
      "ty": 2,
      "x": 493,
      "y": 635
    },
    {
      "t": 167771,
      "e": 37784,
      "ty": 41,
      "x": 43622,
      "y": 19711,
      "ta": "> div.masterdiv > div:[2] > div > p:[2] > b"
    },
    {
      "t": 167821,
      "e": 37834,
      "ty": 2,
      "x": 494,
      "y": 629
    },
    {
      "t": 167921,
      "e": 37934,
      "ty": 2,
      "x": 507,
      "y": 586
    },
    {
      "t": 168021,
      "e": 38034,
      "ty": 2,
      "x": 507,
      "y": 552
    },
    {
      "t": 168021,
      "e": 38034,
      "ty": 41,
      "x": 18924,
      "y": 2377,
      "ta": "> div.masterdiv > div:[2] > div > table > tbody > tr:[4] > td:[2]"
    },
    {
      "t": 168075,
      "e": 38088,
      "ty": 6,
      "x": 496,
      "y": 526,
      "ta": "#da1"
    },
    {
      "t": 168107,
      "e": 38120,
      "ty": 7,
      "x": 484,
      "y": 507,
      "ta": "#da1"
    },
    {
      "t": 168120,
      "e": 38133,
      "ty": 2,
      "x": 484,
      "y": 507
    },
    {
      "t": 168220,
      "e": 38233,
      "ty": 2,
      "x": 477,
      "y": 484
    },
    {
      "t": 168271,
      "e": 38284,
      "ty": 41,
      "x": 15652,
      "y": 36,
      "ta": "> div.masterdiv > div:[2] > div > table > tbody > tr > td:[2]"
    },
    {
      "t": 168321,
      "e": 38334,
      "ty": 2,
      "x": 477,
      "y": 478
    },
    {
      "t": 168421,
      "e": 38434,
      "ty": 2,
      "x": 477,
      "y": 475
    },
    {
      "t": 168521,
      "e": 38534,
      "ty": 41,
      "x": 9029,
      "y": 10692,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 170020,
      "e": 40033,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 170221,
      "e": 40234,
      "ty": 2,
      "x": 476,
      "y": 477
    },
    {
      "t": 170271,
      "e": 40284,
      "ty": 41,
      "x": 8882,
      "y": 11002,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 170321,
      "e": 40334,
      "ty": 2,
      "x": 469,
      "y": 479
    },
    {
      "t": 170421,
      "e": 40434,
      "ty": 2,
      "x": 454,
      "y": 484
    },
    {
      "t": 170520,
      "e": 40533,
      "ty": 2,
      "x": 445,
      "y": 487
    },
    {
      "t": 170520,
      "e": 40533,
      "ty": 41,
      "x": 12163,
      "y": 16420,
      "ta": "> div.masterdiv > div:[2] > div > table > tbody > tr > td:[2]"
    },
    {
      "t": 170621,
      "e": 40634,
      "ty": 2,
      "x": 440,
      "y": 490
    },
    {
      "t": 170721,
      "e": 40734,
      "ty": 2,
      "x": 437,
      "y": 493
    },
    {
      "t": 170770,
      "e": 40783,
      "ty": 41,
      "x": 11182,
      "y": 30463,
      "ta": "> div.masterdiv > div:[2] > div > table > tbody > tr > td:[2]"
    },
    {
      "t": 170820,
      "e": 40833,
      "ty": 2,
      "x": 435,
      "y": 494
    },
    {
      "t": 170921,
      "e": 40934,
      "ty": 2,
      "x": 430,
      "y": 498
    },
    {
      "t": 171021,
      "e": 41034,
      "ty": 41,
      "x": 10527,
      "y": 42166,
      "ta": "> div.masterdiv > div:[2] > div > table > tbody > tr > td:[2]"
    },
    {
      "t": 171121,
      "e": 41134,
      "ty": 2,
      "x": 429,
      "y": 501
    },
    {
      "t": 171221,
      "e": 41234,
      "ty": 2,
      "x": 434,
      "y": 502
    },
    {
      "t": 171270,
      "e": 41283,
      "ty": 41,
      "x": 12599,
      "y": 51528,
      "ta": "> div.masterdiv > div:[2] > div > table > tbody > tr > td:[2]"
    },
    {
      "t": 171321,
      "e": 41334,
      "ty": 2,
      "x": 464,
      "y": 502
    },
    {
      "t": 171421,
      "e": 41434,
      "ty": 2,
      "x": 489,
      "y": 502
    },
    {
      "t": 171520,
      "e": 41533,
      "ty": 2,
      "x": 491,
      "y": 502
    },
    {
      "t": 171520,
      "e": 41533,
      "ty": 41,
      "x": 17179,
      "y": 51528,
      "ta": "> div.masterdiv > div:[2] > div > table > tbody > tr > td:[2]"
    },
    {
      "t": 171620,
      "e": 41633,
      "ty": 2,
      "x": 492,
      "y": 499
    },
    {
      "t": 171719,
      "e": 41732,
      "ty": 2,
      "x": 491,
      "y": 491
    },
    {
      "t": 171770,
      "e": 41783,
      "ty": 41,
      "x": 17179,
      "y": 25782,
      "ta": "> div.masterdiv > div:[2] > div > table > tbody > tr > td:[2]"
    },
    {
      "t": 171819,
      "e": 41832,
      "ty": 2,
      "x": 491,
      "y": 488
    },
    {
      "t": 171921,
      "e": 41934,
      "ty": 2,
      "x": 488,
      "y": 478
    },
    {
      "t": 172021,
      "e": 42034,
      "ty": 2,
      "x": 475,
      "y": 440
    },
    {
      "t": 172021,
      "e": 42034,
      "ty": 41,
      "x": 8931,
      "y": 39807,
      "ta": "> div.masterdiv > div:[2] > div > p"
    },
    {
      "t": 172121,
      "e": 42134,
      "ty": 2,
      "x": 455,
      "y": 405
    },
    {
      "t": 172220,
      "e": 42233,
      "ty": 2,
      "x": 449,
      "y": 395
    },
    {
      "t": 172271,
      "e": 42284,
      "ty": 41,
      "x": 7652,
      "y": 18606,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 173419,
      "e": 43432,
      "ty": 2,
      "x": 450,
      "y": 394
    },
    {
      "t": 173520,
      "e": 43533,
      "ty": 41,
      "x": 7701,
      "y": 18537,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 173820,
      "e": 43833,
      "ty": 2,
      "x": 452,
      "y": 390
    },
    {
      "t": 173919,
      "e": 43932,
      "ty": 2,
      "x": 455,
      "y": 383
    },
    {
      "t": 174019,
      "e": 44032,
      "ty": 2,
      "x": 457,
      "y": 370
    },
    {
      "t": 174019,
      "e": 44032,
      "ty": 41,
      "x": 8046,
      "y": 16875,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 174120,
      "e": 44133,
      "ty": 2,
      "x": 473,
      "y": 317
    },
    {
      "t": 174220,
      "e": 44233,
      "ty": 2,
      "x": 476,
      "y": 309
    },
    {
      "t": 174270,
      "e": 44283,
      "ty": 41,
      "x": 8980,
      "y": 12651,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 174820,
      "e": 44833,
      "ty": 2,
      "x": 478,
      "y": 309
    },
    {
      "t": 174920,
      "e": 44933,
      "ty": 2,
      "x": 482,
      "y": 311
    },
    {
      "t": 175020,
      "e": 45033,
      "ty": 41,
      "x": 9275,
      "y": 12790,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 175119,
      "e": 45132,
      "ty": 2,
      "x": 482,
      "y": 312
    },
    {
      "t": 175220,
      "e": 45233,
      "ty": 2,
      "x": 483,
      "y": 314
    },
    {
      "t": 175270,
      "e": 45283,
      "ty": 41,
      "x": 9325,
      "y": 12997,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 175620,
      "e": 45633,
      "ty": 2,
      "x": 484,
      "y": 315
    },
    {
      "t": 175720,
      "e": 45733,
      "ty": 2,
      "x": 485,
      "y": 316
    },
    {
      "t": 175770,
      "e": 45783,
      "ty": 41,
      "x": 9423,
      "y": 13136,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 176270,
      "e": 46283,
      "ty": 41,
      "x": 9472,
      "y": 13205,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 176320,
      "e": 46333,
      "ty": 2,
      "x": 486,
      "y": 317
    },
    {
      "t": 176620,
      "e": 46633,
      "ty": 2,
      "x": 487,
      "y": 327
    },
    {
      "t": 176720,
      "e": 46733,
      "ty": 2,
      "x": 494,
      "y": 338
    },
    {
      "t": 176770,
      "e": 46783,
      "ty": 41,
      "x": 10112,
      "y": 15421,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 176820,
      "e": 46833,
      "ty": 2,
      "x": 499,
      "y": 359
    },
    {
      "t": 176920,
      "e": 46933,
      "ty": 2,
      "x": 500,
      "y": 365
    },
    {
      "t": 177020,
      "e": 47033,
      "ty": 2,
      "x": 500,
      "y": 366
    },
    {
      "t": 177020,
      "e": 47033,
      "ty": 41,
      "x": 10161,
      "y": 16598,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 177120,
      "e": 47133,
      "ty": 2,
      "x": 499,
      "y": 372
    },
    {
      "t": 177270,
      "e": 47283,
      "ty": 41,
      "x": 10112,
      "y": 17014,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 178020,
      "e": 48033,
      "ty": 2,
      "x": 509,
      "y": 372
    },
    {
      "t": 178020,
      "e": 48033,
      "ty": 41,
      "x": 10604,
      "y": 17014,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 178520,
      "e": 48533,
      "ty": 2,
      "x": 513,
      "y": 373
    },
    {
      "t": 178520,
      "e": 48533,
      "ty": 41,
      "x": 10801,
      "y": 17083,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 178620,
      "e": 48633,
      "ty": 2,
      "x": 524,
      "y": 375
    },
    {
      "t": 178720,
      "e": 48733,
      "ty": 2,
      "x": 530,
      "y": 375
    },
    {
      "t": 178770,
      "e": 48783,
      "ty": 41,
      "x": 12030,
      "y": 17222,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 178820,
      "e": 48833,
      "ty": 2,
      "x": 562,
      "y": 375
    },
    {
      "t": 178920,
      "e": 48933,
      "ty": 2,
      "x": 666,
      "y": 375
    },
    {
      "t": 179020,
      "e": 49033,
      "ty": 2,
      "x": 739,
      "y": 376
    },
    {
      "t": 179021,
      "e": 49034,
      "ty": 41,
      "x": 21919,
      "y": 17291,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 179120,
      "e": 49133,
      "ty": 2,
      "x": 746,
      "y": 379
    },
    {
      "t": 179220,
      "e": 49233,
      "ty": 2,
      "x": 771,
      "y": 391
    },
    {
      "t": 179270,
      "e": 49283,
      "ty": 41,
      "x": 24330,
      "y": 18606,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 179320,
      "e": 49333,
      "ty": 2,
      "x": 828,
      "y": 404
    },
    {
      "t": 179420,
      "e": 49433,
      "ty": 2,
      "x": 880,
      "y": 446
    },
    {
      "t": 179520,
      "e": 49533,
      "ty": 2,
      "x": 881,
      "y": 448
    },
    {
      "t": 179520,
      "e": 49533,
      "ty": 41,
      "x": 28905,
      "y": 49169,
      "ta": "> div.masterdiv > div:[2] > div > p"
    },
    {
      "t": 179620,
      "e": 49633,
      "ty": 2,
      "x": 788,
      "y": 509
    },
    {
      "t": 179642,
      "e": 49655,
      "ty": 6,
      "x": 749,
      "y": 519,
      "ta": "#da1"
    },
    {
      "t": 179729,
      "e": 49742,
      "ty": 2,
      "x": 630,
      "y": 530
    },
    {
      "t": 179759,
      "e": 49772,
      "ty": 7,
      "x": 606,
      "y": 532,
      "ta": "#da1"
    },
    {
      "t": 179780,
      "e": 49793,
      "ty": 41,
      "x": 28847,
      "y": 58549,
      "ta": "> div.masterdiv > div:[2] > div > table > tbody > tr:[2] > td"
    },
    {
      "t": 179826,
      "e": 49839,
      "ty": 6,
      "x": 594,
      "y": 529,
      "ta": "#da1"
    },
    {
      "t": 179829,
      "e": 49842,
      "ty": 2,
      "x": 594,
      "y": 529
    },
    {
      "t": 179875,
      "e": 49888,
      "ty": 7,
      "x": 592,
      "y": 505,
      "ta": "#da1"
    },
    {
      "t": 179930,
      "e": 49943,
      "ty": 2,
      "x": 605,
      "y": 477
    },
    {
      "t": 180030,
      "e": 50043,
      "ty": 2,
      "x": 632,
      "y": 454
    },
    {
      "t": 180030,
      "e": 50043,
      "ty": 41,
      "x": 16655,
      "y": 56191,
      "ta": "> div.masterdiv > div:[2] > div > p"
    },
    {
      "t": 180030,
      "e": 50043,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 180129,
      "e": 50142,
      "ty": 2,
      "x": 703,
      "y": 477
    },
    {
      "t": 180230,
      "e": 50243,
      "ty": 2,
      "x": 749,
      "y": 494
    },
    {
      "t": 180280,
      "e": 50293,
      "ty": 41,
      "x": 46184,
      "y": 46847,
      "ta": "> div.masterdiv > div:[2] > div > table > tbody > tr > td:[2]"
    },
    {
      "t": 180310,
      "e": 50323,
      "ty": 6,
      "x": 773,
      "y": 513,
      "ta": "#da1"
    },
    {
      "t": 180330,
      "e": 50343,
      "ty": 2,
      "x": 784,
      "y": 523
    },
    {
      "t": 180360,
      "e": 50373,
      "ty": 7,
      "x": 805,
      "y": 540,
      "ta": "#da1"
    },
    {
      "t": 180429,
      "e": 50442,
      "ty": 2,
      "x": 833,
      "y": 568
    },
    {
      "t": 180529,
      "e": 50542,
      "ty": 2,
      "x": 844,
      "y": 655
    },
    {
      "t": 180529,
      "e": 50542,
      "ty": 41,
      "x": 27085,
      "y": 38579,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 180560,
      "e": 50573,
      "ty": 6,
      "x": 844,
      "y": 673,
      "ta": "> div.masterdiv > div:[2] > div > ul > li"
    },
    {
      "t": 180593,
      "e": 50606,
      "ty": 7,
      "x": 851,
      "y": 726,
      "ta": "> div.masterdiv > div:[2] > div > ul > li"
    },
    {
      "t": 180594,
      "e": 50607,
      "ty": 6,
      "x": 851,
      "y": 726,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 180610,
      "e": 50623,
      "ty": 7,
      "x": 855,
      "y": 772,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 180610,
      "e": 50623,
      "ty": 6,
      "x": 855,
      "y": 772,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[4]"
    },
    {
      "t": 180627,
      "e": 50640,
      "ty": 7,
      "x": 855,
      "y": 800,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[4]"
    },
    {
      "t": 180629,
      "e": 50642,
      "ty": 2,
      "x": 855,
      "y": 800
    },
    {
      "t": 180780,
      "e": 50793,
      "ty": 41,
      "x": 27626,
      "y": 61044,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 181030,
      "e": 51043,
      "ty": 2,
      "x": 861,
      "y": 797
    },
    {
      "t": 181030,
      "e": 51043,
      "ty": 41,
      "x": 27921,
      "y": 60579,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 181129,
      "e": 51142,
      "ty": 2,
      "x": 1022,
      "y": 914
    },
    {
      "t": 181229,
      "e": 51242,
      "ty": 2,
      "x": 1061,
      "y": 993
    },
    {
      "t": 181280,
      "e": 51293,
      "ty": 41,
      "x": 36727,
      "y": 62648,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 181330,
      "e": 51343,
      "ty": 2,
      "x": 1021,
      "y": 1047
    },
    {
      "t": 181430,
      "e": 51443,
      "ty": 2,
      "x": 1001,
      "y": 1052
    },
    {
      "t": 181494,
      "e": 51507,
      "ty": 6,
      "x": 982,
      "y": 1079,
      "ta": "#start"
    },
    {
      "t": 181530,
      "e": 51543,
      "ty": 2,
      "x": 977,
      "y": 1092
    },
    {
      "t": 181530,
      "e": 51543,
      "ty": 41,
      "x": 36863,
      "y": 37224,
      "ta": "#start"
    },
    {
      "t": 181629,
      "e": 51642,
      "ty": 2,
      "x": 975,
      "y": 1094
    },
    {
      "t": 181730,
      "e": 51743,
      "ty": 2,
      "x": 975,
      "y": 1102
    },
    {
      "t": 181780,
      "e": 51793,
      "ty": 41,
      "x": 35771,
      "y": 56499,
      "ta": "#start"
    },
    {
      "t": 182030,
      "e": 52043,
      "ty": 2,
      "x": 975,
      "y": 1094
    },
    {
      "t": 182030,
      "e": 52043,
      "ty": 41,
      "x": 35771,
      "y": 41079,
      "ta": "#start"
    },
    {
      "t": 182605,
      "e": 52618,
      "ty": 3,
      "x": 975,
      "y": 1094,
      "ta": "#start"
    },
    {
      "t": 182606,
      "e": 52619,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 182700,
      "e": 52713,
      "ty": 4,
      "x": 35771,
      "y": 41079,
      "ta": "#start"
    },
    {
      "t": 182701,
      "e": 52714,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 182701,
      "e": 52714,
      "ty": 5,
      "x": 975,
      "y": 1094,
      "ta": "#start"
    },
    {
      "t": 182702,
      "e": 52715,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 183630,
      "e": 53643,
      "ty": 2,
      "x": 975,
      "y": 1093
    },
    {
      "t": 183703,
      "e": 53716,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 183730,
      "e": 53743,
      "ty": 2,
      "x": 978,
      "y": 1087
    },
    {
      "t": 183779,
      "e": 53792,
      "ty": 41,
      "x": 33439,
      "y": 59773,
      "ta": "html > body"
    },
    {
      "t": 183830,
      "e": 53843,
      "ty": 2,
      "x": 980,
      "y": 1087
    },
    {
      "t": 183929,
      "e": 53942,
      "ty": 2,
      "x": 981,
      "y": 1085
    },
    {
      "t": 184029,
      "e": 54042,
      "ty": 41,
      "x": 33507,
      "y": 59662,
      "ta": "html > body"
    },
    {
      "t": 184429,
      "e": 54442,
      "ty": 2,
      "x": 981,
      "y": 1083
    },
    {
      "t": 184530,
      "e": 54543,
      "ty": 41,
      "x": 33507,
      "y": 59552,
      "ta": "html > body"
    },
    {
      "t": 184780,
      "e": 54793,
      "ty": 41,
      "x": 33473,
      "y": 59496,
      "ta": "html > body"
    },
    {
      "t": 184830,
      "e": 54843,
      "ty": 2,
      "x": 978,
      "y": 1078
    },
    {
      "t": 184929,
      "e": 54942,
      "ty": 2,
      "x": 978,
      "y": 1077
    },
    {
      "t": 185030,
      "e": 55043,
      "ty": 41,
      "x": 33404,
      "y": 59219,
      "ta": "html > body"
    },
    {
      "t": 185230,
      "e": 55243,
      "ty": 2,
      "x": 976,
      "y": 1077
    },
    {
      "t": 185280,
      "e": 55293,
      "ty": 41,
      "x": 33335,
      "y": 59219,
      "ta": "html > body"
    },
    {
      "t": 185780,
      "e": 55793,
      "ty": 41,
      "x": 33301,
      "y": 59219,
      "ta": "html > body"
    },
    {
      "t": 185830,
      "e": 55843,
      "ty": 2,
      "x": 975,
      "y": 1077
    },
    {
      "t": 186280,
      "e": 56293,
      "ty": 41,
      "x": 33301,
      "y": 59164,
      "ta": "html > body"
    },
    {
      "t": 186330,
      "e": 56343,
      "ty": 2,
      "x": 975,
      "y": 1076
    },
    {
      "t": 186630,
      "e": 56643,
      "ty": 2,
      "x": 975,
      "y": 1075
    },
    {
      "t": 186780,
      "e": 56793,
      "ty": 41,
      "x": 33301,
      "y": 59108,
      "ta": "html > body"
    },
    {
      "t": 187530,
      "e": 57543,
      "ty": 2,
      "x": 974,
      "y": 1075
    },
    {
      "t": 187530,
      "e": 57543,
      "ty": 41,
      "x": 33266,
      "y": 59108,
      "ta": "html > body"
    },
    {
      "t": 190030,
      "e": 60043,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 194832,
      "e": 62543,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 195834,
      "e": 62543,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":60},{\"id\":63},{\"id\":64},{\"id\":74},{\"id\":75},{\"id\":77},{\"id\":78},{\"id\":80},{\"id\":79},{\"id\":76},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":81},{\"id\":82},{\"id\":84},{\"id\":85},{\"id\":97},{\"id\":86},{\"id\":87},{\"id\":98},{\"id\":88},{\"id\":89},{\"id\":99},{\"id\":90},{\"id\":91},{\"id\":100},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":101},{\"id\":102},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":103},{\"id\":96},{\"id\":83},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":109},{\"id\":110},{\"id\":112},{\"id\":111},{\"id\":72},{\"id\":73},{\"id\":61},{\"id\":62}],[],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":113,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":113},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":115,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":114},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":116,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":115},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":117,\"tagName\":\"P\",\"attributes\":{},\"parentNode\":{\"id\":113}},{\"nodeType\":3,\"id\":118,\"textContent\":\"Please enter the following information from your participant card\",\"parentNode\":{\"id\":117}},{\"nodeType\":1,\"id\":119,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":114}},{\"nodeType\":1,\"id\":120,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":119},\"parentNode\":{\"id\":114}},{\"nodeType\":3,\"id\":121,\"textContent\":\"Session code: \",\"parentNode\":{\"id\":119}},{\"nodeType\":1,\"id\":122,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":115}},{\"nodeType\":1,\"id\":123,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":122},\"parentNode\":{\"id\":115}},{\"nodeType\":3,\"id\":124,\"textContent\":\"Condition code: \",\"parentNode\":{\"id\":122}},{\"nodeType\":3,\"id\":125,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":116}}],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":113},{\"id\":117},{\"id\":118},{\"id\":114},{\"id\":119},{\"id\":121},{\"id\":120},{\"id\":115},{\"id\":122},{\"id\":124},{\"id\":123},{\"id\":116},{\"id\":125}],[],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":126,\"tagName\":\"SCRIPT\",\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":127,\"textContent\":\" \",\"previousSibling\":{\"id\":126},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":128,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"previousSibling\":{\"id\":127},\"parentNode\":{\"id\":55}},{\"nodeType\":8,\"id\":129,\"previousSibling\":{\"id\":128},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":130,\"textContent\":\" \",\"previousSibling\":{\"id\":129},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \\t//set text of scenario descriptions based on scenario randomization order in main switch(scenarios[0]) { case \\\"acme\\\": $('#da1').text(\\\"Answer 15 questions to help a manager coordinate a factory shift schedule.\\\"); break; } \",\"parentNode\":{\"id\":126}},{\"nodeType\":3,\"id\":132,\"textContent\":\" \",\"parentNode\":{\"id\":128}},{\"nodeType\":1,\"id\":133,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":132},\"parentNode\":{\"id\":128}},{\"nodeType\":8,\"id\":134,\"previousSibling\":{\"id\":133},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":135,\"textContent\":\" \",\"previousSibling\":{\"id\":134},\"parentNode\":{\"id\":128}},{\"nodeType\":1,\"id\":136,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":135},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":137,\"textContent\":\" \",\"previousSibling\":{\"id\":136},\"parentNode\":{\"id\":128}},{\"nodeType\":8,\"id\":138,\"previousSibling\":{\"id\":137},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \",\"previousSibling\":{\"id\":138},\"parentNode\":{\"id\":128}},{\"nodeType\":1,\"id\":140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":139},\"parentNode\":{\"id\":128}},{\"nodeType\":8,\"id\":141,\"previousSibling\":{\"id\":140},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":142,\"textContent\":\" \",\"previousSibling\":{\"id\":141},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":143,\"textContent\":\" \",\"parentNode\":{\"id\":133}},{\"nodeType\":1,\"id\":144,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":143},\"parentNode\":{\"id\":133}},{\"nodeType\":3,\"id\":145,\"textContent\":\" \",\"previousSibling\":{\"id\":144},\"parentNode\":{\"id\":133}},{\"nodeType\":3,\"id\":146,\"textContent\":\" \",\"parentNode\":{\"id\":144}},{\"nodeType\":1,\"id\":147,\"tagName\":\"H1\",\"attributes\":{},\"previousSibling\":{\"id\":146},\"parentNode\":{\"id\":144}},{\"nodeType\":3,\"id\":148,\"textContent\":\" \",\"previousSibling\":{\"id\":147},\"parentNode\":{\"id\":144}},{\"nodeType\":3,\"id\":149,\"textContent\":\"Instructions\",\"parentNode\":{\"id\":147}},{\"nodeType\":3,\"id\":150,\"textContent\":\" \",\"parentNode\":{\"id\":136}},{\"nodeType\":1,\"id\":151,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":150},\"parentNode\":{\"id\":136}},{\"nodeType\":3,\"id\":152,\"textContent\":\" \",\"previousSibling\":{\"id\":151},\"parentNode\":{\"id\":136}},{\"nodeType\":8,\"id\":153,\"previousSibling\":{\"id\":152},\"parentNode\":{\"id\":136}},{\"nodeType\":3,\"id\":154,\"textContent\":\" \",\"previousSibling\":{\"id\":153},\"parentNode\":{\"id\":136}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \",\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":156,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":155},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":157,\"tagName\":\"TABLE\",\"attributes\":{\"cellspacing\":\"0\",\"cellpadding\":\"0\",\"border\":\"0\",\"style\":\"display:block;\"},\"previousSibling\":{\"id\":156},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":158,\"textContent\":\" \",\"previousSibling\":{\"id\":157},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":159,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":158},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":160,\"textContent\":\" \",\"previousSibling\":{\"id\":159},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":161,\"tagName\":\"UL\",\"attributes\":{\"class\":\"fa-ul\"},\"previousSibling\":{\"id\":160},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":162,\"textContent\":\" \",\"previousSibling\":{\"id\":161},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":163,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":162},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":164,\"textContent\":\" \",\"previousSibling\":{\"id\":163},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":165,\"textContent\":\"We are interested in learning about how people make decisions about time. In this study, you are going to solve a series of problems about scheduling events. To help you solve the problems, we are going to give you a variety of graphs and diagrams. You are going to complete \",\"parentNode\":{\"id\":156}},{\"nodeType\":1,\"id\":166,\"tagName\":\"I\",\"attributes\":{},\"previousSibling\":{\"id\":165},\"parentNode\":{\"id\":156}},{\"nodeType\":3,\"id\":167,\"textContent\":\" of the activities on this computer. \",\"previousSibling\":{\"id\":166},\"parentNode\":{\"id\":156}},{\"nodeType\":3,\"id\":168,\"textContent\":\"all\",\"parentNode\":{\"id\":166}},{\"nodeType\":3,\"id\":169,\"textContent\":\" \",\"parentNode\":{\"id\":157}},{\"nodeType\":1,\"id\":170,\"tagName\":\"TBODY\",\"attributes\":{},\"previousSibling\":{\"id\":169},\"parentNode\":{\"id\":157}},{\"nodeType\":1,\"id\":171,\"tagName\":\"TR\",\"attributes\":{},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":172,\"textContent\":\" \",\"previousSibling\":{\"id\":171},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":173,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":172},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":174,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":173},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":175,\"tagName\":\"TR\",\"attributes\":{\"height\":\"15\"},\"previousSibling\":{\"id\":174},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":176,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":175},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":177,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":176},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":178,\"textContent\":\" \",\"previousSibling\":{\"id\":177},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":179,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":178},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":180,\"textContent\":\" \",\"previousSibling\":{\"id\":179},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":181,\"textContent\":\" \",\"parentNode\":{\"id\":171}},{\"nodeType\":1,\"id\":182,\"tagName\":\"TD\",\"attributes\":{\"width\":\"40\",\"rowspan\":\"2\"},\"previousSibling\":{\"id\":181},\"parentNode\":{\"id\":171}},{\"nodeType\":3,\"id\":183,\"textContent\":\" \",\"previousSibling\":{\"id\":182},\"parentNode\":{\"id\":171}},{\"nodeType\":1,\"id\":184,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":183},\"parentNode\":{\"id\":171}},{\"nodeType\":3,\"id\":185,\"textContent\":\" \",\"previousSibling\":{\"id\":184},\"parentNode\":{\"id\":171}},{\"nodeType\":1,\"id\":186,\"tagName\":\"A\",\"attributes\":{\"class\":\"fa fa-desktop fa-lg\"},\"parentNode\":{\"id\":182}},{\"nodeType\":3,\"id\":187,\"textContent\":\"Acme Factory [20 minutes]\",\"parentNode\":{\"id\":184}},{\"nodeType\":3,\"id\":188,\"textContent\":\" \",\"parentNode\":{\"id\":173}},{\"nodeType\":1,\"id\":189,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":188},\"parentNode\":{\"id\":173}},{\"nodeType\":3,\"id\":190,\"textContent\":\" \",\"previousSibling\":{\"id\":189},\"parentNode\":{\"id\":173}},{\"nodeType\":1,\"id\":191,\"tagName\":\"A\",\"attributes\":{\"id\":\"da1\",\"class\":\"subheading\"},\"parentNode\":{\"id\":189}},{\"nodeType\":3,\"id\":192,\"textContent\":\"Answer 15 questions to help a manager coordinate a factory shift schedule.\",\"parentNode\":{\"id\":191}},{\"nodeType\":3,\"id\":193,\"textContent\":\" \",\"parentNode\":{\"id\":177}},{\"nodeType\":1,\"id\":194,\"tagName\":\"TD\",\"attributes\":{\"rowspan\":\"2\"},\"previousSibling\":{\"id\":193},\"parentNode\":{\"id\":177}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \",\"previousSibling\":{\"id\":194},\"parentNode\":{\"id\":177}},{\"nodeType\":1,\"id\":196,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":195},\"parentNode\":{\"id\":177}},{\"nodeType\":3,\"id\":197,\"textContent\":\" \",\"previousSibling\":{\"id\":196},\"parentNode\":{\"id\":177}},{\"nodeType\":1,\"id\":198,\"tagName\":\"A\",\"attributes\":{\"class\":\"fa fa-desktop fa-lg\"},\"parentNode\":{\"id\":194}},{\"nodeType\":3,\"id\":199,\"textContent\":\"Final Survey [5 minutes]\",\"parentNode\":{\"id\":196}},{\"nodeType\":3,\"id\":200,\"textContent\":\" \",\"parentNode\":{\"id\":179}},{\"nodeType\":1,\"id\":201,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":200},\"parentNode\":{\"id\":179}},{\"nodeType\":3,\"id\":202,\"textContent\":\" \",\"previousSibling\":{\"id\":201},\"parentNode\":{\"id\":179}},{\"nodeType\":1,\"id\":203,\"tagName\":\"I\",\"attributes\":{},\"parentNode\":{\"id\":201}},{\"nodeType\":3,\"id\":204,\"textContent\":\"Complete a demographic survey and feedback on your experience.\",\"parentNode\":{\"id\":203}},{\"nodeType\":1,\"id\":205,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":159}},{\"nodeType\":3,\"id\":206,\"textContent\":\" \",\"previousSibling\":{\"id\":205},\"parentNode\":{\"id\":159}},{\"nodeType\":3,\"id\":207,\"textContent\":\"To ensure accurate results, please:\",\"parentNode\":{\"id\":205}},{\"nodeType\":3,\"id\":208,\"textContent\":\" \\t\",\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":209,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":208},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":210,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":209},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":211,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":210},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":212,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":211},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":212},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":214,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":213},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":215,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":214},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":216,\"textContent\":\" \",\"previousSibling\":{\"id\":215},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":217,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-check\",\"style\":\"color:green\"},\"parentNode\":{\"id\":209}},{\"nodeType\":3,\"id\":218,\"textContent\":\"DO read all instructions \",\"previousSibling\":{\"id\":217},\"parentNode\":{\"id\":209}},{\"nodeType\":1,\"id\":219,\"tagName\":\"I\",\"attributes\":{},\"previousSibling\":{\"id\":218},\"parentNode\":{\"id\":209}},{\"nodeType\":3,\"id\":220,\"textContent\":\" \",\"previousSibling\":{\"id\":219},\"parentNode\":{\"id\":209}},{\"nodeType\":3,\"id\":221,\"textContent\":\"carefully\",\"parentNode\":{\"id\":219}},{\"nodeType\":1,\"id\":222,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":211}},{\"nodeType\":3,\"id\":223,\"textContent\":\"DO NOT close this browser window\",\"previousSibling\":{\"id\":222},\"parentNode\":{\"id\":211}},{\"nodeType\":1,\"id\":224,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":213}},{\"nodeType\":3,\"id\":225,\"textContent\":\"DO NOT try to return to a previous page \",\"previousSibling\":{\"id\":224},\"parentNode\":{\"id\":213}},{\"nodeType\":1,\"id\":226,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":215}},{\"nodeType\":3,\"id\":227,\"textContent\":\"DO NOT use the back button on the mouse or web browser\",\"previousSibling\":{\"id\":226},\"parentNode\":{\"id\":215}},{\"nodeType\":3,\"id\":228,\"textContent\":\"If you have questions at any time, please raise your hand and the experimenter will assist you. \",\"parentNode\":{\"id\":163}},{\"nodeType\":3,\"id\":229,\"textContent\":\" \\t\",\"parentNode\":{\"id\":140}},{\"nodeType\":1,\"id\":230,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":229},\"parentNode\":{\"id\":140}},{\"nodeType\":3,\"id\":231,\"textContent\":\" \",\"previousSibling\":{\"id\":230},\"parentNode\":{\"id\":140}},{\"nodeType\":3,\"id\":232,\"textContent\":\"BEGIN\",\"parentNode\":{\"id\":230}}],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":126},{\"id\":131},{\"id\":127},{\"id\":128},{\"id\":132},{\"id\":133},{\"id\":143},{\"id\":144},{\"id\":146},{\"id\":147},{\"id\":149},{\"id\":148},{\"id\":145},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":150},{\"id\":151},{\"id\":155},{\"id\":156},{\"id\":165},{\"id\":166},{\"id\":168},{\"id\":167},{\"id\":157},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":181},{\"id\":182},{\"id\":186},{\"id\":183},{\"id\":184},{\"id\":187},{\"id\":185},{\"id\":172},{\"id\":173},{\"id\":188},{\"id\":189},{\"id\":191},{\"id\":192},{\"id\":190},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":193},{\"id\":194},{\"id\":198},{\"id\":195},{\"id\":196},{\"id\":199},{\"id\":197},{\"id\":178},{\"id\":179},{\"id\":200},{\"id\":201},{\"id\":203},{\"id\":204},{\"id\":202},{\"id\":180},{\"id\":158},{\"id\":159},{\"id\":205},{\"id\":207},{\"id\":206},{\"id\":160},{\"id\":161},{\"id\":208},{\"id\":209},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":221},{\"id\":220},{\"id\":210},{\"id\":211},{\"id\":222},{\"id\":223},{\"id\":212},{\"id\":213},{\"id\":224},{\"id\":225},{\"id\":214},{\"id\":215},{\"id\":226},{\"id\":227},{\"id\":216},{\"id\":162},{\"id\":163},{\"id\":228},{\"id\":164},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":229},{\"id\":230},{\"id\":232},{\"id\":231},{\"id\":141},{\"id\":142},{\"id\":129},{\"id\":130}],[],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":233,\"tagName\":\"IMG\",\"attributes\":{\"src\":\"img/acme.png\",\"id\":\"jspsych-single-stim-stimulus\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":234,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":233},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":235,\"textContent\":\"Press enter to continue\",\"parentNode\":{\"id\":234}}],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":233},{\"id\":234},{\"id\":235}],[],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":1,\"id\":59,\"tagName\":\"IMG\",\"attributes\":{\"src\":\"img/phone.png\",\"id\":\"jspsych-single-stim-stimulus\"}}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 321, dom: 699, initialDom: 702",
  "javascriptErrors": []
}