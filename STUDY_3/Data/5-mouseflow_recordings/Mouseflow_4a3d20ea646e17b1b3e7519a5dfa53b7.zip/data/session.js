var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "4a3d20ea646e17b1b3e7519a5dfa53b7",
  "created": "2018-05-18T10:13:07.0305865-07:00",
  "lastActivity": "2018-05-18T10:13:22.9075865-07:00",
  "pageViews": [
    {
      "id": "051806469fe43f9954f0c5d2a6d3372a8bb74ff2",
      "startTime": "2018-05-18T10:13:07.0305865-07:00",
      "endTime": "2018-05-18T10:13:22.9075865-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/2",
      "visitTime": 15877,
      "engagementTime": 15734,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 15877,
  "engagementTime": 15734,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.32",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=J994U",
    "CONDITION=111",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "28f1a3f9a72b2c793c11efd3bc4047d4",
  "gdpr": false
}