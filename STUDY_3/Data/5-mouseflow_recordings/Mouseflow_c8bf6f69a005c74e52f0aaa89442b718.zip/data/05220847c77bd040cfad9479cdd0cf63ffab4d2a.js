var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["05220847c77bd040cfad9479cdd0cf63ffab4d2a"] = {
  "startTime": "2018-05-22T23:17:07.9599771Z",
  "websitePageUrl": "/16",
  "visitTime": 77229,
  "engagementTime": 76814,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1200,
  "tags": [
    "form-interact",
    "submit"
  ],
  "session": {
    "id": "c8bf6f69a005c74e52f0aaa89442b718",
    "created": "2018-05-22T23:17:07.9599771+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.181",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/16",
    "tags": [
      "form-interact",
      "submit"
    ],
    "variables": [
      "SID=E5L6P",
      "CONDITION=115"
    ],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "1e7525473d0ff4b924df68917d558c5d",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/c8bf6f69a005c74e52f0aaa89442b718/play"
  },
  "events": [
    {
      "t": 1,
      "e": 1,
      "ty": 14,
      "x": 0,
      "y": 1199
    },
    {
      "t": 100,
      "e": 100,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 100,
      "e": 100,
      "ty": 2,
      "x": 506,
      "y": 749
    },
    {
      "t": 100,
      "e": 100,
      "ty": 1,
      "x": 0,
      "y": 16
    },
    {
      "t": 200,
      "e": 200,
      "ty": 2,
      "x": 504,
      "y": 749
    },
    {
      "t": 250,
      "e": 250,
      "ty": 41,
      "x": 17081,
      "y": 41049,
      "ta": "html > body"
    },
    {
      "t": 478,
      "e": 478,
      "ty": 2,
      "x": 501,
      "y": 749
    },
    {
      "t": 501,
      "e": 501,
      "ty": 41,
      "x": 45403,
      "y": 41049,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 751,
      "e": 751,
      "ty": 41,
      "x": 44953,
      "y": 41160,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 801,
      "e": 801,
      "ty": 2,
      "x": 496,
      "y": 752
    },
    {
      "t": 1001,
      "e": 1001,
      "ty": 41,
      "x": 44841,
      "y": 41215,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 1100,
      "e": 1100,
      "ty": 2,
      "x": 492,
      "y": 749
    },
    {
      "t": 1200,
      "e": 1200,
      "ty": 2,
      "x": 410,
      "y": 706
    },
    {
      "t": 1250,
      "e": 1250,
      "ty": 41,
      "x": 35766,
      "y": 49980,
      "ta": "> div.stimulus > div > div:[3]"
    },
    {
      "t": 1300,
      "e": 1300,
      "ty": 2,
      "x": 384,
      "y": 695
    },
    {
      "t": 1359,
      "e": 1359,
      "ty": 6,
      "x": 361,
      "y": 686,
      "ta": "#strategyButton"
    },
    {
      "t": 1400,
      "e": 1400,
      "ty": 2,
      "x": 345,
      "y": 680
    },
    {
      "t": 1409,
      "e": 1409,
      "ty": 7,
      "x": 334,
      "y": 675,
      "ta": "#strategyButton"
    },
    {
      "t": 1501,
      "e": 1501,
      "ty": 2,
      "x": 288,
      "y": 639
    },
    {
      "t": 1501,
      "e": 1501,
      "ty": 41,
      "x": 21459,
      "y": 34955,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 1600,
      "e": 1600,
      "ty": 2,
      "x": 279,
      "y": 622
    },
    {
      "t": 1701,
      "e": 1701,
      "ty": 2,
      "x": 278,
      "y": 619
    },
    {
      "t": 1751,
      "e": 1751,
      "ty": 41,
      "x": 20672,
      "y": 63841,
      "ta": "> div.stimulus > div > div:[2]"
    },
    {
      "t": 1800,
      "e": 1800,
      "ty": 2,
      "x": 284,
      "y": 616
    },
    {
      "t": 1901,
      "e": 1901,
      "ty": 2,
      "x": 290,
      "y": 613
    },
    {
      "t": 2001,
      "e": 2001,
      "ty": 2,
      "x": 295,
      "y": 612
    },
    {
      "t": 2001,
      "e": 2001,
      "ty": 41,
      "x": 22246,
      "y": 61119,
      "ta": "> div.stimulus > div > div:[2]"
    },
    {
      "t": 2101,
      "e": 2101,
      "ty": 2,
      "x": 296,
      "y": 612
    },
    {
      "t": 2251,
      "e": 2251,
      "ty": 41,
      "x": 22359,
      "y": 61119,
      "ta": "> div.stimulus > div > div:[2]"
    },
    {
      "t": 2401,
      "e": 2401,
      "ty": 2,
      "x": 302,
      "y": 609
    },
    {
      "t": 2444,
      "e": 2444,
      "ty": 6,
      "x": 346,
      "y": 603,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2501,
      "e": 2501,
      "ty": 2,
      "x": 363,
      "y": 601
    },
    {
      "t": 2501,
      "e": 2501,
      "ty": 41,
      "x": 29890,
      "y": 63322,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2601,
      "e": 2601,
      "ty": 2,
      "x": 371,
      "y": 600
    },
    {
      "t": 2701,
      "e": 2701,
      "ty": 2,
      "x": 392,
      "y": 594
    },
    {
      "t": 2751,
      "e": 2751,
      "ty": 41,
      "x": 35173,
      "y": 56041,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2801,
      "e": 2801,
      "ty": 2,
      "x": 424,
      "y": 590
    },
    {
      "t": 2901,
      "e": 2901,
      "ty": 2,
      "x": 433,
      "y": 586
    },
    {
      "t": 3001,
      "e": 3001,
      "ty": 2,
      "x": 441,
      "y": 582
    },
    {
      "t": 3001,
      "e": 3001,
      "ty": 41,
      "x": 38658,
      "y": 47950,
      "ta": "#strategyAnswer"
    },
    {
      "t": 3100,
      "e": 3100,
      "ty": 2,
      "x": 443,
      "y": 581
    },
    {
      "t": 3251,
      "e": 3251,
      "ty": 41,
      "x": 38883,
      "y": 47141,
      "ta": "#strategyAnswer"
    },
    {
      "t": 5660,
      "e": 5660,
      "ty": 3,
      "x": 443,
      "y": 581,
      "ta": "#strategyAnswer"
    },
    {
      "t": 5661,
      "e": 5661,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 5843,
      "e": 5843,
      "ty": 4,
      "x": 38883,
      "y": 47141,
      "ta": "#strategyAnswer"
    },
    {
      "t": 5843,
      "e": 5843,
      "ty": 5,
      "x": 443,
      "y": 581,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10001,
      "e": 10001,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 10352,
      "e": 10352,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 10353,
      "e": 10353,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10462,
      "e": 10462,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "l"
    },
    {
      "t": 10615,
      "e": 10615,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 10615,
      "e": 10615,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10671,
      "e": 10671,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "lo"
    },
    {
      "t": 10767,
      "e": 10767,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 10767,
      "e": 10767,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10822,
      "e": 10822,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "loo"
    },
    {
      "t": 10934,
      "e": 10934,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "75"
    },
    {
      "t": 10936,
      "e": 10936,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11038,
      "e": 11038,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look"
    },
    {
      "t": 11078,
      "e": 11078,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 11078,
      "e": 11078,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11203,
      "e": 11203,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "looka"
    },
    {
      "t": 11271,
      "e": 11271,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 11271,
      "e": 11271,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11278,
      "e": 11278,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||at"
    },
    {
      "t": 11403,
      "e": 11403,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "lookat"
    },
    {
      "t": 11422,
      "e": 11422,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 11438,
      "e": 11438,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 11438,
      "e": 11438,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11550,
      "e": 11550,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 12204,
      "e": 12204,
      "ty": 0,
      "x": 1920,
      "y": 1094
    },
    {
      "t": 12204,
      "e": 12204,
      "ty": 2,
      "x": 443,
      "y": 515
    },
    {
      "t": 12251,
      "e": 12251,
      "ty": 41,
      "x": 38883,
      "y": 36623,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12318,
      "e": 12318,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "122"
    },
    {
      "t": 12374,
      "e": 12374,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 12401,
      "e": 12401,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 12401,
      "e": 12401,
      "ty": 2,
      "x": 443,
      "y": 581
    },
    {
      "t": 12501,
      "e": 12501,
      "ty": 41,
      "x": 38883,
      "y": 47141,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13675,
      "e": 13675,
      "ty": 3,
      "x": 443,
      "y": 581,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13762,
      "e": 13762,
      "ty": 4,
      "x": 38883,
      "y": 47141,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13762,
      "e": 13762,
      "ty": 5,
      "x": 443,
      "y": 581,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14399,
      "e": 14399,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 14486,
      "e": 14486,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "lookat"
    },
    {
      "t": 14622,
      "e": 14622,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 14710,
      "e": 14710,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "looka"
    },
    {
      "t": 14975,
      "e": 14975,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 15045,
      "e": 15045,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look"
    },
    {
      "t": 15550,
      "e": 15550,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 15552,
      "e": 15552,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15670,
      "e": 15670,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 15798,
      "e": 15798,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 15799,
      "e": 15799,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15950,
      "e": 15950,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 16094,
      "e": 16094,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 16094,
      "e": 16094,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16182,
      "e": 16182,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 16214,
      "e": 16214,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 16214,
      "e": 16214,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16318,
      "e": 16318,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 16320,
      "e": 16320,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 16320,
      "e": 16320,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16422,
      "e": 16422,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 16462,
      "e": 16462,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 16462,
      "e": 16462,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16590,
      "e": 16590,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 16590,
      "e": 16590,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16606,
      "e": 16606,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||he"
    },
    {
      "t": 16735,
      "e": 16735,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 16735,
      "e": 16735,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16742,
      "e": 16742,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 16822,
      "e": 16822,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 17903,
      "e": 17903,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 17903,
      "e": 17903,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18047,
      "e": 18047,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||x"
    },
    {
      "t": 18358,
      "e": 18358,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "189"
    },
    {
      "t": 18360,
      "e": 18360,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18478,
      "e": 18478,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||-"
    },
    {
      "t": 18735,
      "e": 18735,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 18735,
      "e": 18735,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18862,
      "e": 18862,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 19103,
      "e": 19103,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 19103,
      "e": 19103,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19198,
      "e": 19198,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||x"
    },
    {
      "t": 19327,
      "e": 19327,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 19328,
      "e": 19328,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19430,
      "e": 19430,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 19478,
      "e": 19478,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 19478,
      "e": 19478,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19575,
      "e": 19575,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 19590,
      "e": 19590,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 19591,
      "e": 19591,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19686,
      "e": 19686,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 19734,
      "e": 19734,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 19734,
      "e": 19734,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19863,
      "e": 19863,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 19887,
      "e": 19887,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 19888,
      "e": 19888,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19983,
      "e": 19983,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 20001,
      "e": 20001,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 20038,
      "e": 20038,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 20038,
      "e": 20038,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20182,
      "e": 20182,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 20214,
      "e": 20214,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 20214,
      "e": 20214,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20318,
      "e": 20318,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 22168,
      "e": 22168,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 22262,
      "e": 22262,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look at the x-axis and"
    },
    {
      "t": 22286,
      "e": 22286,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 22391,
      "e": 22391,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look at the x-axis an"
    },
    {
      "t": 22471,
      "e": 22471,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 22517,
      "e": 22517,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look at the x-axis a"
    },
    {
      "t": 22598,
      "e": 22598,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 22662,
      "e": 22662,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look at the x-axis "
    },
    {
      "t": 23502,
      "e": 23502,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 23503,
      "e": 23503,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23598,
      "e": 23598,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||f"
    },
    {
      "t": 23662,
      "e": 23662,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 23663,
      "e": 23663,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23775,
      "e": 23775,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 23783,
      "e": 23783,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 23783,
      "e": 23783,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23862,
      "e": 23862,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 23903,
      "e": 23903,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 23904,
      "e": 23904,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24022,
      "e": 24022,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 24238,
      "e": 24238,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 24240,
      "e": 24240,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24334,
      "e": 24334,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||1"
    },
    {
      "t": 24494,
      "e": 24494,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 24496,
      "e": 24496,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24566,
      "e": 24566,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||2"
    },
    {
      "t": 27487,
      "e": 27487,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 27487,
      "e": 27487,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27582,
      "e": 27582,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 27847,
      "e": 27847,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 27847,
      "e": 27847,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27926,
      "e": 27926,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 28910,
      "e": 28910,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "188"
    },
    {
      "t": 28910,
      "e": 28910,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29030,
      "e": 29030,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 29030,
      "e": 29030,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29038,
      "e": 29038,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||, "
    },
    {
      "t": 29166,
      "e": 29166,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 29191,
      "e": 29191,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 29191,
      "e": 29191,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29310,
      "e": 29310,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 29310,
      "e": 29310,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29350,
      "e": 29350,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||an"
    },
    {
      "t": 29414,
      "e": 29414,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 29422,
      "e": 29422,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 29422,
      "e": 29422,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29535,
      "e": 29535,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 29535,
      "e": 29535,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29557,
      "e": 29557,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d "
    },
    {
      "t": 29645,
      "e": 29645,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 30000,
      "e": 30000,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 31711,
      "e": 31711,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "86"
    },
    {
      "t": 31711,
      "e": 31711,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31806,
      "e": 31806,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||v"
    },
    {
      "t": 32086,
      "e": 32086,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 32087,
      "e": 32087,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32202,
      "e": 32202,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look at the x-axis for 12pm, and vi"
    },
    {
      "t": 32206,
      "e": 32206,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 32206,
      "e": 32206,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32214,
      "e": 32214,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ie"
    },
    {
      "t": 32327,
      "e": 32327,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 32430,
      "e": 32430,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 32431,
      "e": 32431,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32541,
      "e": 32541,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||w"
    },
    {
      "t": 32558,
      "e": 32558,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 32558,
      "e": 32558,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32662,
      "e": 32662,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 32662,
      "e": 32662,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32670,
      "e": 32670,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| a"
    },
    {
      "t": 32783,
      "e": 32783,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 32815,
      "e": 32815,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 32815,
      "e": 32815,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32894,
      "e": 32894,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 33003,
      "e": 33003,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look at the x-axis for 12pm, and view al"
    },
    {
      "t": 33030,
      "e": 33030,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 33031,
      "e": 33031,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33102,
      "e": 33102,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 33206,
      "e": 33206,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 33207,
      "e": 33207,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33286,
      "e": 33286,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 33403,
      "e": 33403,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look at the x-axis for 12pm, and view all "
    },
    {
      "t": 33502,
      "e": 33502,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 33503,
      "e": 33503,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33589,
      "e": 33589,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 33590,
      "e": 33590,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33597,
      "e": 33597,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||th"
    },
    {
      "t": 33718,
      "e": 33718,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 33734,
      "e": 33734,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 33735,
      "e": 33735,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33838,
      "e": 33838,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 33838,
      "e": 33838,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33854,
      "e": 33854,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e "
    },
    {
      "t": 33950,
      "e": 33950,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 34743,
      "e": 34743,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 34743,
      "e": 34743,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34870,
      "e": 34870,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 34893,
      "e": 34893,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 34894,
      "e": 34894,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35003,
      "e": 35003,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look at the x-axis for 12pm, and view all the do"
    },
    {
      "t": 35039,
      "e": 35039,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 35039,
      "e": 35039,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35053,
      "e": 35053,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ot"
    },
    {
      "t": 35126,
      "e": 35126,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 35198,
      "e": 35198,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 35198,
      "e": 35198,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35334,
      "e": 35334,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 35334,
      "e": 35334,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 35335,
      "e": 35335,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35431,
      "e": 35431,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 35447,
      "e": 35447,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 35447,
      "e": 35447,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35526,
      "e": 35526,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 35526,
      "e": 35526,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35533,
      "e": 35533,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||th"
    },
    {
      "t": 35654,
      "e": 35654,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 35655,
      "e": 35655,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35685,
      "e": 35685,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 35803,
      "e": 35803,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look at the x-axis for 12pm, and view all the dots tha"
    },
    {
      "t": 35830,
      "e": 35830,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 35830,
      "e": 35830,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35838,
      "e": 35838,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 35918,
      "e": 35918,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 35919,
      "e": 35919,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35942,
      "e": 35942,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 36007,
      "e": 36007,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 36430,
      "e": 36430,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 36432,
      "e": 36432,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36542,
      "e": 36542,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 36615,
      "e": 36615,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 36615,
      "e": 36615,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36701,
      "e": 36701,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 36766,
      "e": 36766,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 36767,
      "e": 36767,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36871,
      "e": 36871,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 36925,
      "e": 36925,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 36926,
      "e": 36926,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37013,
      "e": 37013,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 37037,
      "e": 37037,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 37038,
      "e": 37038,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37110,
      "e": 37110,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 37159,
      "e": 37159,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 37160,
      "e": 37160,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37254,
      "e": 37254,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 37414,
      "e": 37414,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 37416,
      "e": 37416,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37510,
      "e": 37510,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 37550,
      "e": 37550,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 37550,
      "e": 37550,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37622,
      "e": 37622,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 37654,
      "e": 37654,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 37656,
      "e": 37656,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37804,
      "e": 37657,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look at the x-axis for 12pm, and view all the dots that align lin"
    },
    {
      "t": 37822,
      "e": 37675,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 37830,
      "e": 37683,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 37830,
      "e": 37683,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37950,
      "e": 37803,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 37950,
      "e": 37803,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 37950,
      "e": 37803,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38096,
      "e": 37949,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 38097,
      "e": 37950,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38118,
      "e": 37971,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ar"
    },
    {
      "t": 38214,
      "e": 38067,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 38367,
      "e": 38220,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 38367,
      "e": 38220,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38486,
      "e": 38339,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 38486,
      "e": 38339,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38494,
      "e": 38347,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ly"
    },
    {
      "t": 38574,
      "e": 38427,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 39540,
      "e": 39393,
      "ty": 7,
      "x": 444,
      "y": 621,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39573,
      "e": 39426,
      "ty": 6,
      "x": 431,
      "y": 665,
      "ta": "#strategyButton"
    },
    {
      "t": 39601,
      "e": 39454,
      "ty": 2,
      "x": 426,
      "y": 672
    },
    {
      "t": 39701,
      "e": 39554,
      "ty": 2,
      "x": 424,
      "y": 675
    },
    {
      "t": 39751,
      "e": 39604,
      "ty": 41,
      "x": 46642,
      "y": 39061,
      "ta": "#strategyButton"
    },
    {
      "t": 39901,
      "e": 39754,
      "ty": 2,
      "x": 403,
      "y": 679
    },
    {
      "t": 40001,
      "e": 39854,
      "ty": 2,
      "x": 354,
      "y": 676
    },
    {
      "t": 40002,
      "e": 39855,
      "ty": 41,
      "x": 8413,
      "y": 40989,
      "ta": "#strategyButton"
    },
    {
      "t": 40100,
      "e": 39953,
      "ty": 2,
      "x": 351,
      "y": 658
    },
    {
      "t": 40107,
      "e": 39960,
      "ty": 7,
      "x": 358,
      "y": 653,
      "ta": "#strategyButton"
    },
    {
      "t": 40201,
      "e": 40054,
      "ty": 2,
      "x": 427,
      "y": 628
    },
    {
      "t": 40251,
      "e": 40104,
      "ty": 41,
      "x": 41019,
      "y": 61573,
      "ta": "> div.stimulus > div > div:[2]"
    },
    {
      "t": 40290,
      "e": 40143,
      "ty": 6,
      "x": 496,
      "y": 598,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40301,
      "e": 40154,
      "ty": 2,
      "x": 496,
      "y": 598
    },
    {
      "t": 40401,
      "e": 40254,
      "ty": 2,
      "x": 520,
      "y": 540
    },
    {
      "t": 40501,
      "e": 40354,
      "ty": 2,
      "x": 544,
      "y": 526
    },
    {
      "t": 40501,
      "e": 40354,
      "ty": 41,
      "x": 50236,
      "y": 2642,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40601,
      "e": 40454,
      "ty": 2,
      "x": 537,
      "y": 544
    },
    {
      "t": 40640,
      "e": 40493,
      "ty": 7,
      "x": 480,
      "y": 616,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40700,
      "e": 40553,
      "ty": 2,
      "x": 417,
      "y": 648
    },
    {
      "t": 40751,
      "e": 40604,
      "ty": 41,
      "x": 32021,
      "y": 13281,
      "ta": "> div.stimulus > div > div:[3]"
    },
    {
      "t": 40801,
      "e": 40654,
      "ty": 2,
      "x": 379,
      "y": 642
    },
    {
      "t": 40891,
      "e": 40744,
      "ty": 6,
      "x": 370,
      "y": 661,
      "ta": "#strategyButton"
    },
    {
      "t": 40901,
      "e": 40754,
      "ty": 2,
      "x": 370,
      "y": 661
    },
    {
      "t": 40975,
      "e": 40828,
      "ty": 7,
      "x": 376,
      "y": 692,
      "ta": "#strategyButton"
    },
    {
      "t": 41000,
      "e": 40853,
      "ty": 2,
      "x": 379,
      "y": 696
    },
    {
      "t": 41001,
      "e": 40854,
      "ty": 41,
      "x": 28276,
      "y": 48669,
      "ta": "> div.stimulus > div > div:[3]"
    },
    {
      "t": 41101,
      "e": 40954,
      "ty": 2,
      "x": 385,
      "y": 697
    },
    {
      "t": 41201,
      "e": 41054,
      "ty": 2,
      "x": 390,
      "y": 692
    },
    {
      "t": 41251,
      "e": 41104,
      "ty": 41,
      "x": 33425,
      "y": 46048,
      "ta": "> div.stimulus > div > div:[3]"
    },
    {
      "t": 41301,
      "e": 41154,
      "ty": 2,
      "x": 390,
      "y": 691
    },
    {
      "t": 41401,
      "e": 41254,
      "ty": 2,
      "x": 390,
      "y": 689
    },
    {
      "t": 41501,
      "e": 41354,
      "ty": 2,
      "x": 388,
      "y": 689
    },
    {
      "t": 41501,
      "e": 41354,
      "ty": 41,
      "x": 32489,
      "y": 44082,
      "ta": "> div.stimulus > div > div:[3]"
    },
    {
      "t": 41601,
      "e": 41454,
      "ty": 2,
      "x": 383,
      "y": 689
    },
    {
      "t": 41751,
      "e": 41604,
      "ty": 41,
      "x": 30149,
      "y": 44082,
      "ta": "> div.stimulus > div > div:[3]"
    },
    {
      "t": 42251,
      "e": 42104,
      "ty": 41,
      "x": 29680,
      "y": 44082,
      "ta": "> div.stimulus > div > div:[3]"
    },
    {
      "t": 42274,
      "e": 42127,
      "ty": 6,
      "x": 382,
      "y": 688,
      "ta": "#strategyButton"
    },
    {
      "t": 42301,
      "e": 42154,
      "ty": 2,
      "x": 382,
      "y": 687
    },
    {
      "t": 42401,
      "e": 42254,
      "ty": 2,
      "x": 382,
      "y": 681
    },
    {
      "t": 42501,
      "e": 42354,
      "ty": 2,
      "x": 383,
      "y": 677
    },
    {
      "t": 42502,
      "e": 42355,
      "ty": 41,
      "x": 24251,
      "y": 42916,
      "ta": "#strategyButton"
    },
    {
      "t": 43101,
      "e": 42954,
      "ty": 2,
      "x": 383,
      "y": 675
    },
    {
      "t": 43251,
      "e": 43104,
      "ty": 41,
      "x": 24251,
      "y": 39061,
      "ta": "#strategyButton"
    },
    {
      "t": 43868,
      "e": 43721,
      "ty": 3,
      "x": 383,
      "y": 675,
      "ta": "#strategyButton"
    },
    {
      "t": 43869,
      "e": 43722,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look at the x-axis for 12pm, and view all the dots that align linearly"
    },
    {
      "t": 43870,
      "e": 43723,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43870,
      "e": 43723,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 43954,
      "e": 43807,
      "ty": 4,
      "x": 24251,
      "y": 39061,
      "ta": "#strategyButton"
    },
    {
      "t": 43964,
      "e": 43817,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 43965,
      "e": 43818,
      "ty": 5,
      "x": 383,
      "y": 675,
      "ta": "#strategyButton"
    },
    {
      "t": 43970,
      "e": 43823,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 44972,
      "e": 44825,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 45501,
      "e": 45354,
      "ty": 2,
      "x": 431,
      "y": 657
    },
    {
      "t": 45501,
      "e": 45354,
      "ty": 41,
      "x": 14567,
      "y": 35952,
      "ta": "html > body"
    },
    {
      "t": 45601,
      "e": 45454,
      "ty": 2,
      "x": 461,
      "y": 653
    },
    {
      "t": 45702,
      "e": 45555,
      "ty": 2,
      "x": 623,
      "y": 651
    },
    {
      "t": 45752,
      "e": 45605,
      "ty": 41,
      "x": 25931,
      "y": 35620,
      "ta": "html > body"
    },
    {
      "t": 45762,
      "e": 45615,
      "ty": 6,
      "x": 833,
      "y": 651,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 45801,
      "e": 45654,
      "ty": 2,
      "x": 902,
      "y": 650
    },
    {
      "t": 45812,
      "e": 45665,
      "ty": 7,
      "x": 924,
      "y": 646,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 45902,
      "e": 45755,
      "ty": 2,
      "x": 969,
      "y": 635
    },
    {
      "t": 46001,
      "e": 45854,
      "ty": 2,
      "x": 977,
      "y": 594
    },
    {
      "t": 46001,
      "e": 45854,
      "ty": 41,
      "x": 36552,
      "y": 7751,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 46029,
      "e": 45882,
      "ty": 6,
      "x": 982,
      "y": 564,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 46062,
      "e": 45915,
      "ty": 7,
      "x": 986,
      "y": 552,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 46101,
      "e": 45954,
      "ty": 2,
      "x": 989,
      "y": 546
    },
    {
      "t": 46202,
      "e": 46055,
      "ty": 2,
      "x": 989,
      "y": 544
    },
    {
      "t": 46251,
      "e": 46104,
      "ty": 41,
      "x": 39147,
      "y": 38052,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 46301,
      "e": 46154,
      "ty": 2,
      "x": 989,
      "y": 547
    },
    {
      "t": 46330,
      "e": 46183,
      "ty": 6,
      "x": 989,
      "y": 555,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 46401,
      "e": 46254,
      "ty": 2,
      "x": 989,
      "y": 560
    },
    {
      "t": 46501,
      "e": 46354,
      "ty": 2,
      "x": 989,
      "y": 565
    },
    {
      "t": 46502,
      "e": 46355,
      "ty": 41,
      "x": 39147,
      "y": 34327,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 46571,
      "e": 46424,
      "ty": 3,
      "x": 989,
      "y": 565,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 46572,
      "e": 46425,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 46642,
      "e": 46495,
      "ty": 4,
      "x": 39147,
      "y": 34327,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 46643,
      "e": 46496,
      "ty": 5,
      "x": 989,
      "y": 565,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 47550,
      "e": 47403,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "49"
    },
    {
      "t": 47551,
      "e": 47404,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 47646,
      "e": 47499,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "1"
    },
    {
      "t": 47653,
      "e": 47506,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "57"
    },
    {
      "t": 47653,
      "e": 47506,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 47717,
      "e": 47570,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "19"
    },
    {
      "t": 48297,
      "e": 48150,
      "ty": 7,
      "x": 957,
      "y": 552,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 48301,
      "e": 48154,
      "ty": 2,
      "x": 957,
      "y": 552
    },
    {
      "t": 48301,
      "e": 48154,
      "ty": 1,
      "x": 0,
      "y": 6
    },
    {
      "t": 48314,
      "e": 48167,
      "ty": 6,
      "x": 936,
      "y": 554,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 48381,
      "e": 48234,
      "ty": 7,
      "x": 929,
      "y": 575,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 48402,
      "e": 48255,
      "ty": 2,
      "x": 929,
      "y": 577
    },
    {
      "t": 48402,
      "e": 48255,
      "ty": 1,
      "x": 0,
      "y": 0
    },
    {
      "t": 48501,
      "e": 48354,
      "ty": 2,
      "x": 929,
      "y": 592
    },
    {
      "t": 48501,
      "e": 48354,
      "ty": 41,
      "x": 26170,
      "y": 6342,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 48601,
      "e": 48454,
      "ty": 2,
      "x": 929,
      "y": 612
    },
    {
      "t": 48701,
      "e": 48554,
      "ty": 2,
      "x": 929,
      "y": 628
    },
    {
      "t": 48752,
      "e": 48605,
      "ty": 41,
      "x": 26170,
      "y": 40871,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 48800,
      "e": 48653,
      "ty": 2,
      "x": 929,
      "y": 644
    },
    {
      "t": 48831,
      "e": 48684,
      "ty": 6,
      "x": 930,
      "y": 649,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 48900,
      "e": 48753,
      "ty": 2,
      "x": 935,
      "y": 656
    },
    {
      "t": 49001,
      "e": 48854,
      "ty": 41,
      "x": 27468,
      "y": 28086,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 49100,
      "e": 48953,
      "ty": 2,
      "x": 936,
      "y": 659
    },
    {
      "t": 49200,
      "e": 49053,
      "ty": 2,
      "x": 937,
      "y": 659
    },
    {
      "t": 49251,
      "e": 49104,
      "ty": 41,
      "x": 27901,
      "y": 37448,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 49347,
      "e": 49104,
      "ty": 3,
      "x": 937,
      "y": 659,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 49349,
      "e": 49106,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "19"
    },
    {
      "t": 49350,
      "e": 49107,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 49350,
      "e": 49107,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 49450,
      "e": 49207,
      "ty": 4,
      "x": 27901,
      "y": 37448,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 49450,
      "e": 49207,
      "ty": 5,
      "x": 937,
      "y": 659,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 50102,
      "e": 49859,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 50286,
      "e": 50043,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "73"
    },
    {
      "t": 50287,
      "e": 50044,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 50398,
      "e": 50155,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "I"
    },
    {
      "t": 50405,
      "e": 50162,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "I"
    },
    {
      "t": 50461,
      "e": 50218,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "78"
    },
    {
      "t": 50461,
      "e": 50218,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 50566,
      "e": 50323,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "In"
    },
    {
      "t": 50630,
      "e": 50387,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "68"
    },
    {
      "t": 50630,
      "e": 50387,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 50726,
      "e": 50483,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "73"
    },
    {
      "t": 50726,
      "e": 50483,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 50741,
      "e": 50498,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Indi"
    },
    {
      "t": 50829,
      "e": 50586,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 50862,
      "e": 50619,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "65"
    },
    {
      "t": 50862,
      "e": 50619,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 50990,
      "e": 50747,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||a"
    },
    {
      "t": 51483,
      "e": 51240,
      "ty": 7,
      "x": 942,
      "y": 669,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 51500,
      "e": 51257,
      "ty": 6,
      "x": 943,
      "y": 676,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 51500,
      "e": 51257,
      "ty": 2,
      "x": 943,
      "y": 676
    },
    {
      "t": 51500,
      "e": 51257,
      "ty": 41,
      "x": 24263,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 51600,
      "e": 51357,
      "ty": 2,
      "x": 947,
      "y": 704
    },
    {
      "t": 51701,
      "e": 51458,
      "ty": 2,
      "x": 947,
      "y": 705
    },
    {
      "t": 51751,
      "e": 51508,
      "ty": 41,
      "x": 26325,
      "y": 47661,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 51800,
      "e": 51557,
      "ty": 2,
      "x": 947,
      "y": 686
    },
    {
      "t": 51891,
      "e": 51648,
      "ty": 3,
      "x": 946,
      "y": 679,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 51892,
      "e": 51649,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "India"
    },
    {
      "t": 51892,
      "e": 51649,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 51893,
      "e": 51650,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 51900,
      "e": 51657,
      "ty": 2,
      "x": 946,
      "y": 679
    },
    {
      "t": 51977,
      "e": 51734,
      "ty": 4,
      "x": 25809,
      "y": 5957,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 51979,
      "e": 51736,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 51979,
      "e": 51736,
      "ty": 5,
      "x": 946,
      "y": 679,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 51979,
      "e": 51736,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 52000,
      "e": 51757,
      "ty": 41,
      "x": 32302,
      "y": 37171,
      "ta": "html > body"
    },
    {
      "t": 52999,
      "e": 52756,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 53750,
      "e": 53507,
      "ty": 41,
      "x": 42117,
      "y": 34844,
      "ta": "html > body"
    },
    {
      "t": 53801,
      "e": 53558,
      "ty": 2,
      "x": 1368,
      "y": 632
    },
    {
      "t": 53901,
      "e": 53658,
      "ty": 2,
      "x": 1308,
      "y": 87
    },
    {
      "t": 54001,
      "e": 53758,
      "ty": 2,
      "x": 1031,
      "y": 0
    },
    {
      "t": 54001,
      "e": 53758,
      "ty": 41,
      "x": 35505,
      "y": 0,
      "ta": "html"
    },
    {
      "t": 54101,
      "e": 53858,
      "ty": 2,
      "x": 447,
      "y": 241
    },
    {
      "t": 54200,
      "e": 53957,
      "ty": 2,
      "x": 410,
      "y": 293
    },
    {
      "t": 54251,
      "e": 54008,
      "ty": 41,
      "x": 16047,
      "y": 14514,
      "ta": "html > body"
    },
    {
      "t": 54300,
      "e": 54057,
      "ty": 2,
      "x": 647,
      "y": 238
    },
    {
      "t": 54401,
      "e": 54158,
      "ty": 2,
      "x": 685,
      "y": 226
    },
    {
      "t": 54501,
      "e": 54258,
      "ty": 2,
      "x": 755,
      "y": 233
    },
    {
      "t": 54501,
      "e": 54258,
      "ty": 41,
      "x": 25724,
      "y": 12464,
      "ta": "html > body"
    },
    {
      "t": 54601,
      "e": 54358,
      "ty": 2,
      "x": 922,
      "y": 203
    },
    {
      "t": 54701,
      "e": 54458,
      "ty": 2,
      "x": 925,
      "y": 203
    },
    {
      "t": 54751,
      "e": 54508,
      "ty": 41,
      "x": 27429,
      "y": 51491,
      "ta": "#jspsych-survey-multi-choice-0 > p"
    },
    {
      "t": 54800,
      "e": 54557,
      "ty": 2,
      "x": 947,
      "y": 198
    },
    {
      "t": 54901,
      "e": 54658,
      "ty": 2,
      "x": 960,
      "y": 196
    },
    {
      "t": 55001,
      "e": 54758,
      "ty": 2,
      "x": 994,
      "y": 194
    },
    {
      "t": 55002,
      "e": 54759,
      "ty": 41,
      "x": 40957,
      "y": 35108,
      "ta": "#jspsych-survey-multi-choice-0 > p"
    },
    {
      "t": 55100,
      "e": 54857,
      "ty": 2,
      "x": 1009,
      "y": 193
    },
    {
      "t": 55200,
      "e": 54957,
      "ty": 2,
      "x": 995,
      "y": 194
    },
    {
      "t": 55251,
      "e": 55008,
      "ty": 41,
      "x": 32176,
      "y": 60853,
      "ta": "#jspsych-survey-multi-choice-0 > p"
    },
    {
      "t": 55300,
      "e": 55057,
      "ty": 2,
      "x": 927,
      "y": 211
    },
    {
      "t": 55401,
      "e": 55158,
      "ty": 2,
      "x": 918,
      "y": 216
    },
    {
      "t": 55500,
      "e": 55257,
      "ty": 2,
      "x": 894,
      "y": 231
    },
    {
      "t": 55501,
      "e": 55258,
      "ty": 41,
      "x": 59431,
      "y": 6553,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 55601,
      "e": 55358,
      "ty": 2,
      "x": 876,
      "y": 247
    },
    {
      "t": 55700,
      "e": 55457,
      "ty": 2,
      "x": 859,
      "y": 270
    },
    {
      "t": 55750,
      "e": 55507,
      "ty": 41,
      "x": 7494,
      "y": 2340,
      "ta": "#jspsych-survey-multi-choice-option-0-2"
    },
    {
      "t": 55800,
      "e": 55557,
      "ty": 2,
      "x": 846,
      "y": 293
    },
    {
      "t": 55901,
      "e": 55658,
      "ty": 2,
      "x": 839,
      "y": 307
    },
    {
      "t": 55971,
      "e": 55728,
      "ty": 6,
      "x": 832,
      "y": 317,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 56001,
      "e": 55758,
      "ty": 2,
      "x": 831,
      "y": 318
    },
    {
      "t": 56001,
      "e": 55758,
      "ty": 41,
      "x": 23079,
      "y": 10082,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 56104,
      "e": 55861,
      "ty": 2,
      "x": 829,
      "y": 321
    },
    {
      "t": 56204,
      "e": 55961,
      "ty": 2,
      "x": 828,
      "y": 321
    },
    {
      "t": 56239,
      "e": 55996,
      "ty": 3,
      "x": 828,
      "y": 321,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 56240,
      "e": 55997,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 56255,
      "e": 56012,
      "ty": 41,
      "x": 7955,
      "y": 25205,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 56349,
      "e": 56106,
      "ty": 4,
      "x": 7955,
      "y": 25205,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 56349,
      "e": 56106,
      "ty": 5,
      "x": 828,
      "y": 321,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 56350,
      "e": 56107,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf",
      "v": "Other"
    },
    {
      "t": 56574,
      "e": 56331,
      "ty": 7,
      "x": 829,
      "y": 330,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 56604,
      "e": 56361,
      "ty": 2,
      "x": 831,
      "y": 333
    },
    {
      "t": 56704,
      "e": 56461,
      "ty": 2,
      "x": 833,
      "y": 366
    },
    {
      "t": 56755,
      "e": 56512,
      "ty": 41,
      "x": 2747,
      "y": 56172,
      "ta": "#jspsych-survey-multi-choice-1 > p"
    },
    {
      "t": 56804,
      "e": 56561,
      "ty": 2,
      "x": 833,
      "y": 381
    },
    {
      "t": 56905,
      "e": 56662,
      "ty": 2,
      "x": 833,
      "y": 392
    },
    {
      "t": 57005,
      "e": 56762,
      "ty": 2,
      "x": 830,
      "y": 405
    },
    {
      "t": 57005,
      "e": 56762,
      "ty": 41,
      "x": 10041,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-1-0 > label"
    },
    {
      "t": 57101,
      "e": 56762,
      "ty": 6,
      "x": 828,
      "y": 408,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 57105,
      "e": 56766,
      "ty": 2,
      "x": 828,
      "y": 408
    },
    {
      "t": 57204,
      "e": 56865,
      "ty": 2,
      "x": 827,
      "y": 412
    },
    {
      "t": 57254,
      "e": 56915,
      "ty": 41,
      "x": 2914,
      "y": 20164,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 57397,
      "e": 57058,
      "ty": 7,
      "x": 827,
      "y": 421,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 57405,
      "e": 57066,
      "ty": 2,
      "x": 827,
      "y": 421
    },
    {
      "t": 57504,
      "e": 57165,
      "ty": 41,
      "x": 6529,
      "y": 52428,
      "ta": "#jspsych-survey-multi-choice-option-1-0 > label"
    },
    {
      "t": 57805,
      "e": 57466,
      "ty": 2,
      "x": 827,
      "y": 425
    },
    {
      "t": 57904,
      "e": 57565,
      "ty": 2,
      "x": 827,
      "y": 435
    },
    {
      "t": 57966,
      "e": 57627,
      "ty": 6,
      "x": 827,
      "y": 436,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 58005,
      "e": 57666,
      "ty": 2,
      "x": 828,
      "y": 436
    },
    {
      "t": 58005,
      "e": 57666,
      "ty": 41,
      "x": 7955,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 58104,
      "e": 57765,
      "ty": 2,
      "x": 829,
      "y": 440
    },
    {
      "t": 58205,
      "e": 57866,
      "ty": 2,
      "x": 829,
      "y": 444
    },
    {
      "t": 58255,
      "e": 57916,
      "ty": 41,
      "x": 23079,
      "y": 50411,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 58305,
      "e": 57966,
      "ty": 2,
      "x": 831,
      "y": 448
    },
    {
      "t": 58310,
      "e": 57971,
      "ty": 7,
      "x": 831,
      "y": 449,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 58405,
      "e": 58066,
      "ty": 2,
      "x": 831,
      "y": 453
    },
    {
      "t": 58504,
      "e": 58165,
      "ty": 2,
      "x": 831,
      "y": 457
    },
    {
      "t": 58505,
      "e": 58166,
      "ty": 41,
      "x": 2273,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-1-2"
    },
    {
      "t": 58904,
      "e": 58565,
      "ty": 2,
      "x": 831,
      "y": 455
    },
    {
      "t": 58993,
      "e": 58654,
      "ty": 6,
      "x": 834,
      "y": 446,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 59004,
      "e": 58665,
      "ty": 2,
      "x": 834,
      "y": 446
    },
    {
      "t": 59004,
      "e": 58665,
      "ty": 41,
      "x": 38202,
      "y": 50411,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 59105,
      "e": 58766,
      "ty": 2,
      "x": 836,
      "y": 442
    },
    {
      "t": 59255,
      "e": 58916,
      "ty": 41,
      "x": 48284,
      "y": 30246,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 59405,
      "e": 59066,
      "ty": 2,
      "x": 836,
      "y": 441
    },
    {
      "t": 59505,
      "e": 59166,
      "ty": 2,
      "x": 836,
      "y": 440
    },
    {
      "t": 59505,
      "e": 59166,
      "ty": 41,
      "x": 48284,
      "y": 20164,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 60287,
      "e": 59948,
      "ty": 3,
      "x": 836,
      "y": 440,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 60288,
      "e": 59949,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 60289,
      "e": 59950,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 60373,
      "e": 60034,
      "ty": 4,
      "x": 48284,
      "y": 20164,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 60373,
      "e": 60034,
      "ty": 5,
      "x": 836,
      "y": 440,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 60374,
      "e": 60035,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf",
      "v": "Second"
    },
    {
      "t": 60646,
      "e": 60307,
      "ty": 7,
      "x": 837,
      "y": 452,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 60705,
      "e": 60366,
      "ty": 2,
      "x": 851,
      "y": 499
    },
    {
      "t": 60755,
      "e": 60416,
      "ty": 41,
      "x": 24275,
      "y": 9830,
      "ta": "#jspsych-survey-multi-choice-option-1-5 > label"
    },
    {
      "t": 60805,
      "e": 60466,
      "ty": 2,
      "x": 862,
      "y": 594
    },
    {
      "t": 60905,
      "e": 60566,
      "ty": 2,
      "x": 866,
      "y": 645
    },
    {
      "t": 61004,
      "e": 60665,
      "ty": 2,
      "x": 865,
      "y": 662
    },
    {
      "t": 61005,
      "e": 60666,
      "ty": 41,
      "x": 10342,
      "y": 2340,
      "ta": "#jspsych-survey-multi-choice-option-2-0"
    },
    {
      "t": 61105,
      "e": 60766,
      "ty": 2,
      "x": 863,
      "y": 668
    },
    {
      "t": 61205,
      "e": 60866,
      "ty": 2,
      "x": 859,
      "y": 672
    },
    {
      "t": 61255,
      "e": 60916,
      "ty": 41,
      "x": 9552,
      "y": 39321,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 61304,
      "e": 60965,
      "ty": 2,
      "x": 854,
      "y": 682
    },
    {
      "t": 61405,
      "e": 61066,
      "ty": 2,
      "x": 852,
      "y": 688
    },
    {
      "t": 61505,
      "e": 61166,
      "ty": 2,
      "x": 850,
      "y": 694
    },
    {
      "t": 61505,
      "e": 61166,
      "ty": 41,
      "x": 7201,
      "y": 3276,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 61605,
      "e": 61266,
      "ty": 2,
      "x": 848,
      "y": 702
    },
    {
      "t": 61705,
      "e": 61366,
      "ty": 2,
      "x": 847,
      "y": 706
    },
    {
      "t": 61755,
      "e": 61416,
      "ty": 41,
      "x": 6445,
      "y": 45874,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 61804,
      "e": 61465,
      "ty": 2,
      "x": 844,
      "y": 709
    },
    {
      "t": 61905,
      "e": 61566,
      "ty": 2,
      "x": 842,
      "y": 712
    },
    {
      "t": 62005,
      "e": 61666,
      "ty": 2,
      "x": 835,
      "y": 715
    },
    {
      "t": 62005,
      "e": 61666,
      "ty": 41,
      "x": 3222,
      "y": 60853,
      "ta": "#jspsych-survey-multi-choice-option-2-1"
    },
    {
      "t": 62105,
      "e": 61766,
      "ty": 2,
      "x": 832,
      "y": 717
    },
    {
      "t": 62206,
      "e": 61867,
      "ty": 2,
      "x": 832,
      "y": 715
    },
    {
      "t": 62254,
      "e": 61915,
      "ty": 41,
      "x": 2917,
      "y": 62258,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 62304,
      "e": 61965,
      "ty": 2,
      "x": 833,
      "y": 712
    },
    {
      "t": 62380,
      "e": 61965,
      "ty": 6,
      "x": 834,
      "y": 708,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 62405,
      "e": 61990,
      "ty": 2,
      "x": 835,
      "y": 707
    },
    {
      "t": 62505,
      "e": 62090,
      "ty": 41,
      "x": 43243,
      "y": 55452,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 62559,
      "e": 62144,
      "ty": 7,
      "x": 834,
      "y": 711,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 62605,
      "e": 62190,
      "ty": 2,
      "x": 834,
      "y": 712
    },
    {
      "t": 62705,
      "e": 62290,
      "ty": 2,
      "x": 834,
      "y": 716
    },
    {
      "t": 62755,
      "e": 62340,
      "ty": 41,
      "x": 2985,
      "y": 2340,
      "ta": "#jspsych-survey-multi-choice-option-2-2"
    },
    {
      "t": 62805,
      "e": 62390,
      "ty": 2,
      "x": 834,
      "y": 719
    },
    {
      "t": 62905,
      "e": 62490,
      "ty": 2,
      "x": 833,
      "y": 721
    },
    {
      "t": 62991,
      "e": 62576,
      "ty": 6,
      "x": 833,
      "y": 724,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 63005,
      "e": 62590,
      "ty": 2,
      "x": 833,
      "y": 724
    },
    {
      "t": 63005,
      "e": 62590,
      "ty": 41,
      "x": 33161,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 63255,
      "e": 62840,
      "ty": 41,
      "x": 33161,
      "y": 15123,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 63304,
      "e": 62889,
      "ty": 2,
      "x": 833,
      "y": 727
    },
    {
      "t": 63405,
      "e": 62990,
      "ty": 2,
      "x": 833,
      "y": 728
    },
    {
      "t": 63505,
      "e": 63090,
      "ty": 41,
      "x": 33161,
      "y": 20164,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 64575,
      "e": 64160,
      "ty": 3,
      "x": 833,
      "y": 728,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 64576,
      "e": 64161,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 64577,
      "e": 64162,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 64709,
      "e": 64294,
      "ty": 4,
      "x": 33161,
      "y": 20164,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 64709,
      "e": 64294,
      "ty": 5,
      "x": 833,
      "y": 728,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 64710,
      "e": 64295,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf",
      "v": "Biomedical & Health Sciences"
    },
    {
      "t": 65305,
      "e": 64890,
      "ty": 2,
      "x": 833,
      "y": 732
    },
    {
      "t": 65358,
      "e": 64943,
      "ty": 7,
      "x": 831,
      "y": 737,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 65404,
      "e": 64989,
      "ty": 2,
      "x": 831,
      "y": 739
    },
    {
      "t": 65505,
      "e": 65090,
      "ty": 2,
      "x": 830,
      "y": 743
    },
    {
      "t": 65505,
      "e": 65090,
      "ty": 41,
      "x": 2035,
      "y": 60853,
      "ta": "#jspsych-survey-multi-choice-option-2-2"
    },
    {
      "t": 65605,
      "e": 65190,
      "ty": 2,
      "x": 828,
      "y": 749
    },
    {
      "t": 65647,
      "e": 65232,
      "ty": 6,
      "x": 826,
      "y": 752,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 65678,
      "e": 65263,
      "ty": 7,
      "x": 825,
      "y": 753,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 65704,
      "e": 65289,
      "ty": 2,
      "x": 825,
      "y": 754
    },
    {
      "t": 65755,
      "e": 65340,
      "ty": 41,
      "x": 1075,
      "y": 22937,
      "ta": "#jspsych-survey-multi-choice-option-2-3 > label"
    },
    {
      "t": 65804,
      "e": 65389,
      "ty": 2,
      "x": 823,
      "y": 758
    },
    {
      "t": 65905,
      "e": 65490,
      "ty": 2,
      "x": 822,
      "y": 764
    },
    {
      "t": 66005,
      "e": 65590,
      "ty": 2,
      "x": 820,
      "y": 769
    },
    {
      "t": 66006,
      "e": 65591,
      "ty": 41,
      "x": 27963,
      "y": 42157,
      "ta": "html > body"
    },
    {
      "t": 66105,
      "e": 65690,
      "ty": 2,
      "x": 820,
      "y": 775
    },
    {
      "t": 66205,
      "e": 65790,
      "ty": 2,
      "x": 820,
      "y": 785
    },
    {
      "t": 66255,
      "e": 65840,
      "ty": 41,
      "x": 27928,
      "y": 43209,
      "ta": "html > body"
    },
    {
      "t": 66305,
      "e": 65890,
      "ty": 2,
      "x": 819,
      "y": 792
    },
    {
      "t": 66405,
      "e": 65990,
      "ty": 2,
      "x": 818,
      "y": 800
    },
    {
      "t": 66505,
      "e": 66090,
      "ty": 2,
      "x": 818,
      "y": 809
    },
    {
      "t": 66505,
      "e": 66090,
      "ty": 41,
      "x": 27894,
      "y": 44373,
      "ta": "html > body"
    },
    {
      "t": 66604,
      "e": 66189,
      "ty": 2,
      "x": 818,
      "y": 816
    },
    {
      "t": 66705,
      "e": 66290,
      "ty": 2,
      "x": 816,
      "y": 821
    },
    {
      "t": 66755,
      "e": 66340,
      "ty": 41,
      "x": 27791,
      "y": 45204,
      "ta": "html > body"
    },
    {
      "t": 66805,
      "e": 66390,
      "ty": 2,
      "x": 813,
      "y": 829
    },
    {
      "t": 66905,
      "e": 66490,
      "ty": 2,
      "x": 811,
      "y": 838
    },
    {
      "t": 67005,
      "e": 66590,
      "ty": 41,
      "x": 27653,
      "y": 45979,
      "ta": "html > body"
    },
    {
      "t": 67254,
      "e": 66839,
      "ty": 41,
      "x": 27619,
      "y": 46256,
      "ta": "html > body"
    },
    {
      "t": 67305,
      "e": 66890,
      "ty": 2,
      "x": 807,
      "y": 851
    },
    {
      "t": 67405,
      "e": 66990,
      "ty": 2,
      "x": 799,
      "y": 865
    },
    {
      "t": 67504,
      "e": 67089,
      "ty": 2,
      "x": 794,
      "y": 873
    },
    {
      "t": 67505,
      "e": 67090,
      "ty": 41,
      "x": 27068,
      "y": 47918,
      "ta": "html > body"
    },
    {
      "t": 67605,
      "e": 67190,
      "ty": 2,
      "x": 792,
      "y": 885
    },
    {
      "t": 67705,
      "e": 67290,
      "ty": 2,
      "x": 791,
      "y": 886
    },
    {
      "t": 67755,
      "e": 67340,
      "ty": 41,
      "x": 26964,
      "y": 48638,
      "ta": "html > body"
    },
    {
      "t": 68005,
      "e": 67590,
      "ty": 2,
      "x": 802,
      "y": 911
    },
    {
      "t": 68005,
      "e": 67590,
      "ty": 41,
      "x": 27343,
      "y": 50023,
      "ta": "html > body"
    },
    {
      "t": 68105,
      "e": 67690,
      "ty": 2,
      "x": 804,
      "y": 919
    },
    {
      "t": 68205,
      "e": 67790,
      "ty": 2,
      "x": 807,
      "y": 937
    },
    {
      "t": 68255,
      "e": 67840,
      "ty": 41,
      "x": 27515,
      "y": 51574,
      "ta": "html > body"
    },
    {
      "t": 68305,
      "e": 67890,
      "ty": 2,
      "x": 808,
      "y": 944
    },
    {
      "t": 68405,
      "e": 67990,
      "ty": 2,
      "x": 817,
      "y": 962
    },
    {
      "t": 68504,
      "e": 68089,
      "ty": 2,
      "x": 821,
      "y": 967
    },
    {
      "t": 68505,
      "e": 68090,
      "ty": 41,
      "x": 0,
      "y": 45874,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 68705,
      "e": 68290,
      "ty": 2,
      "x": 823,
      "y": 967
    },
    {
      "t": 68734,
      "e": 68319,
      "ty": 6,
      "x": 828,
      "y": 964,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 68755,
      "e": 68340,
      "ty": 41,
      "x": 12996,
      "y": 40329,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 68805,
      "e": 68390,
      "ty": 2,
      "x": 830,
      "y": 963
    },
    {
      "t": 68951,
      "e": 68536,
      "ty": 3,
      "x": 830,
      "y": 963,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 68954,
      "e": 68539,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 68955,
      "e": 68540,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 69005,
      "e": 68590,
      "ty": 41,
      "x": 18037,
      "y": 35288,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 69053,
      "e": 68638,
      "ty": 4,
      "x": 18037,
      "y": 30246,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 69053,
      "e": 68638,
      "ty": 5,
      "x": 830,
      "y": 962,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 69054,
      "e": 68639,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf",
      "v": "Female"
    },
    {
      "t": 69105,
      "e": 68690,
      "ty": 2,
      "x": 830,
      "y": 962
    },
    {
      "t": 69168,
      "e": 68753,
      "ty": 7,
      "x": 837,
      "y": 972,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 69205,
      "e": 68790,
      "ty": 2,
      "x": 843,
      "y": 984
    },
    {
      "t": 69255,
      "e": 68840,
      "ty": 41,
      "x": 26384,
      "y": 45874,
      "ta": "#jspsych-survey-multi-choice-option-3-2 > label"
    },
    {
      "t": 69305,
      "e": 68890,
      "ty": 2,
      "x": 848,
      "y": 995
    },
    {
      "t": 69405,
      "e": 68990,
      "ty": 2,
      "x": 849,
      "y": 998
    },
    {
      "t": 69452,
      "e": 69037,
      "ty": 6,
      "x": 853,
      "y": 1006,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 69505,
      "e": 69090,
      "ty": 2,
      "x": 860,
      "y": 1019
    },
    {
      "t": 69505,
      "e": 69090,
      "ty": 41,
      "x": 15759,
      "y": 27802,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 69605,
      "e": 69190,
      "ty": 2,
      "x": 860,
      "y": 1022
    },
    {
      "t": 69654,
      "e": 69239,
      "ty": 3,
      "x": 860,
      "y": 1022,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 69655,
      "e": 69240,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 69656,
      "e": 69241,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 69741,
      "e": 69326,
      "ty": 4,
      "x": 15759,
      "y": 33760,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 69741,
      "e": 69326,
      "ty": 5,
      "x": 860,
      "y": 1022,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 69744,
      "e": 69329,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 69745,
      "e": 69330,
      "ty": 13,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 69745,
      "e": 69330,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 69755,
      "e": 69340,
      "ty": 41,
      "x": 29340,
      "y": 56172,
      "ta": "html > body"
    },
    {
      "t": 71086,
      "e": 70671,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 71505,
      "e": 71090,
      "ty": 2,
      "x": 851,
      "y": 1000
    },
    {
      "t": 71505,
      "e": 71090,
      "ty": 41,
      "x": 27429,
      "y": 60501,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 71605,
      "e": 71190,
      "ty": 2,
      "x": 852,
      "y": 994
    },
    {
      "t": 71705,
      "e": 71290,
      "ty": 2,
      "x": 876,
      "y": 1024
    },
    {
      "t": 71755,
      "e": 71340,
      "ty": 41,
      "x": 29249,
      "y": 63340,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 71805,
      "e": 71390,
      "ty": 2,
      "x": 910,
      "y": 1060
    },
    {
      "t": 71870,
      "e": 71455,
      "ty": 6,
      "x": 925,
      "y": 1073,
      "ta": "#start"
    },
    {
      "t": 71905,
      "e": 71490,
      "ty": 2,
      "x": 929,
      "y": 1076
    },
    {
      "t": 72005,
      "e": 71590,
      "ty": 2,
      "x": 941,
      "y": 1088
    },
    {
      "t": 72005,
      "e": 71590,
      "ty": 41,
      "x": 17202,
      "y": 29514,
      "ta": "#start"
    },
    {
      "t": 72105,
      "e": 71690,
      "ty": 2,
      "x": 942,
      "y": 1088
    },
    {
      "t": 72255,
      "e": 71840,
      "ty": 41,
      "x": 17749,
      "y": 29514,
      "ta": "#start"
    },
    {
      "t": 74134,
      "e": 73719,
      "ty": 3,
      "x": 942,
      "y": 1088,
      "ta": "#start"
    },
    {
      "t": 74135,
      "e": 73720,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 74237,
      "e": 73822,
      "ty": 4,
      "x": 17749,
      "y": 29514,
      "ta": "#start"
    },
    {
      "t": 74238,
      "e": 73823,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 74238,
      "e": 73823,
      "ty": 5,
      "x": 942,
      "y": 1088,
      "ta": "#start"
    },
    {
      "t": 74238,
      "e": 73823,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 75286,
      "e": 74871,
      "ty": 38,
      "x": 8,
      "y": 0
    },
    {
      "t": 76704,
      "e": 76289,
      "ty": 2,
      "x": 940,
      "y": 1090
    },
    {
      "t": 76754,
      "e": 76339,
      "ty": 41,
      "x": 31211,
      "y": 32851,
      "ta": "#jspsych-data-display"
    },
    {
      "t": 76804,
      "e": 76389,
      "ty": 2,
      "x": 916,
      "y": 1082
    },
    {
      "t": 76904,
      "e": 76489,
      "ty": 2,
      "x": 888,
      "y": 1063
    },
    {
      "t": 77005,
      "e": 76590,
      "ty": 2,
      "x": 885,
      "y": 1061
    },
    {
      "t": 77005,
      "e": 76590,
      "ty": 41,
      "x": 28551,
      "y": 32846,
      "ta": "#jspsych-data-display"
    },
    {
      "t": 77229,
      "e": 76814,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":56},{\"id\":57},{\"id\":58},{\"id\":59},{\"id\":60},{\"id\":61},{\"id\":62},{\"id\":63},{\"id\":64},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":72},{\"id\":73},{\"id\":74},{\"id\":75},{\"id\":76},{\"id\":77},{\"id\":78},{\"id\":79},{\"id\":80},{\"id\":81},{\"id\":82},{\"id\":83},{\"id\":84},{\"id\":85},{\"id\":86},{\"id\":87},{\"id\":88},{\"id\":89},{\"id\":90},{\"id\":91},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":96},{\"id\":97},{\"id\":98},{\"id\":99},{\"id\":100},{\"id\":101},{\"id\":102},{\"id\":103},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":109},{\"id\":110},{\"id\":111},{\"id\":112},{\"id\":113},{\"id\":114},{\"id\":115},{\"id\":116},{\"id\":117},{\"id\":118},{\"id\":119},{\"id\":120},{\"id\":121},{\"id\":122},{\"id\":123},{\"id\":124},{\"id\":125},{\"id\":126},{\"id\":127},{\"id\":128},{\"id\":129},{\"id\":130},{\"id\":131},{\"id\":132},{\"id\":133},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":141},{\"id\":142},{\"id\":143},{\"id\":144},{\"id\":145},{\"id\":146},{\"id\":147},{\"id\":148},{\"id\":149},{\"id\":150},{\"id\":151},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":155},{\"id\":156},{\"id\":157},{\"id\":158},{\"id\":159},{\"id\":160},{\"id\":161},{\"id\":162},{\"id\":163},{\"id\":164},{\"id\":165},{\"id\":166},{\"id\":167},{\"id\":168},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":172},{\"id\":173},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":178},{\"id\":179},{\"id\":180},{\"id\":181},{\"id\":182},{\"id\":183},{\"id\":184},{\"id\":185},{\"id\":186},{\"id\":187},{\"id\":188},{\"id\":189},{\"id\":190},{\"id\":191},{\"id\":192},{\"id\":193},{\"id\":194},{\"id\":195},{\"id\":196},{\"id\":197},{\"id\":198},{\"id\":199},{\"id\":200},{\"id\":201},{\"id\":202},{\"id\":203},{\"id\":204},{\"id\":205},{\"id\":206},{\"id\":207},{\"id\":208},{\"id\":209},{\"id\":210},{\"id\":211},{\"id\":212},{\"id\":213},{\"id\":214},{\"id\":215},{\"id\":216},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":220},{\"id\":221},{\"id\":222},{\"id\":223},{\"id\":224},{\"id\":225},{\"id\":226},{\"id\":227},{\"id\":228},{\"id\":229},{\"id\":230},{\"id\":231},{\"id\":232},{\"id\":233},{\"id\":234},{\"id\":235},{\"id\":236},{\"id\":237},{\"id\":238},{\"id\":239},{\"id\":240},{\"id\":241},{\"id\":242},{\"id\":243},{\"id\":244},{\"id\":245},{\"id\":246},{\"id\":247},{\"id\":248},{\"id\":249},{\"id\":250},{\"id\":251},{\"id\":252},{\"id\":253},{\"id\":254},{\"id\":255},{\"id\":256},{\"id\":257},{\"id\":258},{\"id\":259},{\"id\":260},{\"id\":261},{\"id\":262},{\"id\":263},{\"id\":264},{\"id\":265},{\"id\":266},{\"id\":267},{\"id\":268},{\"id\":269},{\"id\":270},{\"id\":271},{\"id\":272},{\"id\":273},{\"id\":274},{\"id\":275},{\"id\":276},{\"id\":277},{\"id\":278},{\"id\":279},{\"id\":280},{\"id\":281},{\"id\":282},{\"id\":283},{\"id\":284},{\"id\":285},{\"id\":286},{\"id\":287},{\"id\":288},{\"id\":289},{\"id\":290},{\"id\":291},{\"id\":292},{\"id\":293},{\"id\":294},{\"id\":295},{\"id\":296},{\"id\":297},{\"id\":298},{\"id\":299},{\"id\":300},{\"id\":301},{\"id\":302},{\"id\":303},{\"id\":304},{\"id\":305},{\"id\":306},{\"id\":307},{\"id\":308},{\"id\":309},{\"id\":310},{\"id\":311},{\"id\":312},{\"id\":313},{\"id\":314},{\"id\":315},{\"id\":316},{\"id\":317},{\"id\":318},{\"id\":319},{\"id\":320},{\"id\":321},{\"id\":322},{\"id\":323},{\"id\":324},{\"id\":325},{\"id\":326},{\"id\":327},{\"id\":328},{\"id\":329},{\"id\":330},{\"id\":331},{\"id\":332},{\"id\":333},{\"id\":334},{\"id\":335},{\"id\":336},{\"id\":337},{\"id\":338},{\"id\":339},{\"id\":340},{\"id\":341},{\"id\":342},{\"id\":343},{\"id\":344},{\"id\":345},{\"id\":346},{\"id\":347},{\"id\":348},{\"id\":349},{\"id\":350},{\"id\":351},{\"id\":352},{\"id\":353},{\"id\":354},{\"id\":355},{\"id\":356},{\"id\":357},{\"id\":358},{\"id\":359},{\"id\":360},{\"id\":361},{\"id\":362},{\"id\":363},{\"id\":364},{\"id\":365},{\"id\":366},{\"id\":367},{\"id\":368},{\"id\":369},{\"id\":370},{\"id\":371},{\"id\":372},{\"id\":373},{\"id\":374},{\"id\":375},{\"id\":376},{\"id\":377},{\"id\":378},{\"id\":379},{\"id\":380},{\"id\":381},{\"id\":382},{\"id\":383},{\"id\":384},{\"id\":385},{\"id\":386},{\"id\":387},{\"id\":388},{\"id\":389},{\"id\":390},{\"id\":391},{\"id\":392},{\"id\":393},{\"id\":394},{\"id\":395},{\"id\":396},{\"id\":397},{\"id\":398},{\"id\":399},{\"id\":400},{\"id\":401},{\"id\":402},{\"id\":403},{\"id\":404},{\"id\":405},{\"id\":406},{\"id\":407},{\"id\":408},{\"id\":409},{\"id\":410},{\"id\":411},{\"id\":412},{\"id\":413},{\"id\":414},{\"id\":415},{\"id\":416},{\"id\":417},{\"id\":418},{\"id\":419},{\"id\":420},{\"id\":421},{\"id\":422},{\"id\":423},{\"id\":424},{\"id\":425},{\"id\":426},{\"id\":427},{\"id\":428},{\"id\":429},{\"id\":430},{\"id\":431},{\"id\":432},{\"id\":433},{\"id\":434},{\"id\":435},{\"id\":436},{\"id\":437},{\"id\":438},{\"id\":439},{\"id\":440},{\"id\":441},{\"id\":442},{\"id\":443},{\"id\":444},{\"id\":445},{\"id\":446},{\"id\":447},{\"id\":448},{\"id\":449},{\"id\":450},{\"id\":451},{\"id\":452},{\"id\":453},{\"id\":454},{\"id\":455},{\"id\":456},{\"id\":457},{\"id\":458},{\"id\":459},{\"id\":460},{\"id\":461},{\"id\":462},{\"id\":463},{\"id\":464},{\"id\":465},{\"id\":466},{\"id\":467},{\"id\":468},{\"id\":469},{\"id\":470},{\"id\":471},{\"id\":472},{\"id\":473},{\"id\":474},{\"id\":475},{\"id\":476},{\"id\":477},{\"id\":478},{\"id\":479},{\"id\":480},{\"id\":481},{\"id\":482},{\"id\":483},{\"id\":484},{\"id\":485},{\"id\":486},{\"id\":487},{\"id\":488},{\"id\":489},{\"id\":490},{\"id\":491},{\"id\":492},{\"id\":493},{\"id\":494},{\"id\":495},{\"id\":496},{\"id\":497},{\"id\":498},{\"id\":499},{\"id\":500},{\"id\":501},{\"id\":502},{\"id\":503},{\"id\":504},{\"id\":505},{\"id\":506},{\"id\":507},{\"id\":508},{\"id\":509},{\"id\":510},{\"id\":511},{\"id\":512},{\"id\":513},{\"id\":514},{\"id\":515},{\"id\":516},{\"id\":517},{\"id\":518},{\"id\":519},{\"id\":520},{\"id\":521},{\"id\":522},{\"id\":523},{\"id\":524},{\"id\":525},{\"id\":526},{\"id\":527},{\"id\":528},{\"id\":529},{\"id\":530},{\"id\":531},{\"id\":532},{\"id\":533},{\"id\":534},{\"id\":535},{\"id\":536},{\"id\":537},{\"id\":538},{\"id\":539},{\"id\":540},{\"id\":541},{\"id\":542},{\"id\":543},{\"id\":544},{\"id\":545},{\"id\":546},{\"id\":547},{\"id\":548},{\"id\":549},{\"id\":550},{\"id\":551},{\"id\":552},{\"id\":553},{\"id\":554},{\"id\":555},{\"id\":556},{\"id\":557},{\"id\":558},{\"id\":559},{\"id\":560},{\"id\":561},{\"id\":562},{\"id\":563},{\"id\":564},{\"id\":565},{\"id\":566},{\"id\":567},{\"id\":568},{\"id\":569},{\"id\":570},{\"id\":571},{\"id\":572},{\"id\":573},{\"id\":574},{\"id\":575},{\"id\":576},{\"id\":577},{\"id\":578},{\"id\":579},{\"id\":580},{\"id\":581},{\"id\":582},{\"id\":583},{\"id\":584},{\"id\":585},{\"id\":586},{\"id\":587},{\"id\":588},{\"id\":589},{\"id\":590},{\"id\":591},{\"id\":592},{\"id\":593},{\"id\":594},{\"id\":595},{\"id\":596},{\"id\":597},{\"id\":598},{\"id\":599},{\"id\":600},{\"id\":601},{\"id\":602},{\"id\":603},{\"id\":604},{\"id\":605},{\"id\":606},{\"id\":607},{\"id\":608},{\"id\":609},{\"id\":610},{\"id\":611},{\"id\":612},{\"id\":613},{\"id\":614},{\"id\":615},{\"id\":616},{\"id\":617},{\"id\":618},{\"id\":619},{\"id\":620},{\"id\":621},{\"id\":622},{\"id\":623},{\"id\":624},{\"id\":625},{\"id\":626},{\"id\":627},{\"id\":628},{\"id\":629},{\"id\":630},{\"id\":631},{\"id\":632},{\"id\":633},{\"id\":634},{\"id\":635},{\"id\":636},{\"id\":637},{\"id\":638},{\"id\":639},{\"id\":640},{\"id\":641},{\"id\":642},{\"id\":643},{\"id\":644},{\"id\":645},{\"id\":646},{\"id\":647},{\"id\":648},{\"id\":649},{\"id\":650},{\"id\":651},{\"id\":652},{\"id\":653},{\"id\":654},{\"id\":655},{\"id\":656},{\"id\":657},{\"id\":658},{\"id\":659},{\"id\":660},{\"id\":661},{\"id\":662},{\"id\":663},{\"id\":664},{\"id\":665},{\"id\":666},{\"id\":667},{\"id\":668},{\"id\":669},{\"id\":670},{\"id\":671},{\"id\":672},{\"id\":673},{\"id\":674},{\"id\":675},{\"id\":676},{\"id\":677},{\"id\":678},{\"id\":679},{\"id\":680},{\"id\":681},{\"id\":682},{\"id\":683},{\"id\":684},{\"id\":685},{\"id\":686},{\"id\":687},{\"id\":688},{\"id\":689},{\"id\":690},{\"id\":691},{\"id\":692},{\"id\":693},{\"id\":694},{\"id\":695},{\"id\":696},{\"id\":697},{\"id\":698},{\"id\":699},{\"id\":700},{\"id\":701},{\"id\":702},{\"id\":703},{\"id\":704},{\"id\":705},{\"id\":706},{\"id\":707},{\"id\":708},{\"id\":709},{\"id\":710},{\"id\":711},{\"id\":712},{\"id\":713},{\"id\":714},{\"id\":715},{\"id\":716},{\"id\":717},{\"id\":718},{\"id\":719},{\"id\":720},{\"id\":721},{\"id\":722},{\"id\":723},{\"id\":724},{\"id\":725},{\"id\":726},{\"id\":727},{\"id\":728},{\"id\":729},{\"id\":730},{\"id\":731},{\"id\":732},{\"id\":733},{\"id\":734},{\"id\":735},{\"id\":736},{\"id\":737},{\"id\":738},{\"id\":739},{\"id\":740},{\"id\":741},{\"id\":742},{\"id\":743},{\"id\":744},{\"id\":745},{\"id\":746},{\"id\":747},{\"id\":748},{\"id\":749},{\"id\":750},{\"id\":751},{\"id\":752},{\"id\":753},{\"id\":754},{\"id\":755},{\"id\":756},{\"id\":757},{\"id\":758},{\"id\":759},{\"id\":760},{\"id\":761},{\"id\":762},{\"id\":763},{\"id\":764},{\"id\":765},{\"id\":766},{\"id\":767},{\"id\":768},{\"id\":769},{\"id\":770},{\"id\":771},{\"id\":772},{\"id\":773},{\"id\":774},{\"id\":775},{\"id\":776},{\"id\":777},{\"id\":778},{\"id\":779},{\"id\":780},{\"id\":781},{\"id\":782},{\"id\":783},{\"id\":784},{\"id\":785},{\"id\":786},{\"id\":787},{\"id\":788},{\"id\":789},{\"id\":790},{\"id\":791},{\"id\":792},{\"id\":793},{\"id\":794},{\"id\":795},{\"id\":796},{\"id\":797},{\"id\":798},{\"id\":799},{\"id\":800},{\"id\":801},{\"id\":802},{\"id\":803},{\"id\":804},{\"id\":805},{\"id\":806},{\"id\":807},{\"id\":808},{\"id\":809},{\"id\":810},{\"id\":811},{\"id\":812},{\"id\":813},{\"id\":814},{\"id\":815},{\"id\":816},{\"id\":817},{\"id\":818},{\"id\":819},{\"id\":820},{\"id\":821},{\"id\":822},{\"id\":823},{\"id\":824},{\"id\":825},{\"id\":826},{\"id\":827},{\"id\":828},{\"id\":829},{\"id\":830},{\"id\":831},{\"id\":832},{\"id\":833},{\"id\":834},{\"id\":835},{\"id\":836},{\"id\":837},{\"id\":838},{\"id\":839},{\"id\":840},{\"id\":841},{\"id\":842},{\"id\":843},{\"id\":844},{\"id\":845},{\"id\":846},{\"id\":847},{\"id\":848},{\"id\":849},{\"id\":850},{\"id\":851},{\"id\":852},{\"id\":853},{\"id\":854},{\"id\":855},{\"id\":856},{\"id\":857},{\"id\":858},{\"id\":859},{\"id\":860},{\"id\":861},{\"id\":862},{\"id\":863},{\"id\":864},{\"id\":865},{\"id\":866},{\"id\":867},{\"id\":868},{\"id\":869},{\"id\":870},{\"id\":871},{\"id\":872},{\"id\":873},{\"id\":874},{\"id\":875},{\"id\":876},{\"id\":877},{\"id\":878},{\"id\":879},{\"id\":880},{\"id\":881},{\"id\":882},{\"id\":883},{\"id\":884},{\"id\":885},{\"id\":886},{\"id\":887},{\"id\":888},{\"id\":889},{\"id\":890},{\"id\":891},{\"id\":892},{\"id\":893},{\"id\":894},{\"id\":895},{\"id\":896},{\"id\":897},{\"id\":898},{\"id\":899},{\"id\":900},{\"id\":901},{\"id\":902},{\"id\":903},{\"id\":904},{\"id\":905},{\"id\":906},{\"id\":907},{\"id\":908},{\"id\":909},{\"id\":910},{\"id\":911},{\"id\":912},{\"id\":913},{\"id\":914},{\"id\":915},{\"id\":916},{\"id\":917},{\"id\":918},{\"id\":919},{\"id\":920},{\"id\":921},{\"id\":922},{\"id\":923},{\"id\":924},{\"id\":925},{\"id\":926},{\"id\":927},{\"id\":928},{\"id\":929},{\"id\":930},{\"id\":931},{\"id\":932},{\"id\":933},{\"id\":934},{\"id\":935},{\"id\":936},{\"id\":937},{\"id\":938},{\"id\":939},{\"id\":940},{\"id\":941},{\"id\":942},{\"id\":943},{\"id\":944},{\"id\":945},{\"id\":946},{\"id\":947},{\"id\":948},{\"id\":949},{\"id\":950},{\"id\":951},{\"id\":952},{\"id\":953},{\"id\":954},{\"id\":955},{\"id\":956},{\"id\":957},{\"id\":958},{\"id\":959},{\"id\":960},{\"id\":961},{\"id\":962},{\"id\":963},{\"id\":964},{\"id\":965},{\"id\":966},{\"id\":967},{\"id\":968},{\"id\":969},{\"id\":970},{\"id\":971},{\"id\":972},{\"id\":973},{\"id\":974},{\"id\":975},{\"id\":976},{\"id\":977},{\"id\":978},{\"id\":979},{\"id\":980},{\"id\":981},{\"id\":982},{\"id\":983},{\"id\":984},{\"id\":985},{\"id\":986},{\"id\":987},{\"id\":988},{\"id\":989},{\"id\":990},{\"id\":991},{\"id\":992},{\"id\":993},{\"id\":994},{\"id\":995},{\"id\":996},{\"id\":997},{\"id\":998},{\"id\":999},{\"id\":1000},{\"id\":1001},{\"id\":1002},{\"id\":1003},{\"id\":1004},{\"id\":1005},{\"id\":1006},{\"id\":1007},{\"id\":1008},{\"id\":1009},{\"id\":1010},{\"id\":1011},{\"id\":1012},{\"id\":1013},{\"id\":1014},{\"id\":1015},{\"id\":1016},{\"id\":1017},{\"id\":1018},{\"id\":1019},{\"id\":1020},{\"id\":1021},{\"id\":1022},{\"id\":1023},{\"id\":1024},{\"id\":1025},{\"id\":1026},{\"id\":1027},{\"id\":1028},{\"id\":1029},{\"id\":1030},{\"id\":1031},{\"id\":1032},{\"id\":1033},{\"id\":1034},{\"id\":1035},{\"id\":1036},{\"id\":1037},{\"id\":1038},{\"id\":1039},{\"id\":1040},{\"id\":1041},{\"id\":1042},{\"id\":1043},{\"id\":1044},{\"id\":1045},{\"id\":1046},{\"id\":1047},{\"id\":1048},{\"id\":1049},{\"id\":1050},{\"id\":1051},{\"id\":1052},{\"id\":1053},{\"id\":1054},{\"id\":1055},{\"id\":1056},{\"id\":1057},{\"id\":1058},{\"id\":1059},{\"id\":1060},{\"id\":1061},{\"id\":1062},{\"id\":1063},{\"id\":1064},{\"id\":1065},{\"id\":1066},{\"id\":1067},{\"id\":1068},{\"id\":1069},{\"id\":1070},{\"id\":1071},{\"id\":1072},{\"id\":1073},{\"id\":1074},{\"id\":1075},{\"id\":1076},{\"id\":1077},{\"id\":1078},{\"id\":1079},{\"id\":1080},{\"id\":1081},{\"id\":1082},{\"id\":1083},{\"id\":1084},{\"id\":1085},{\"id\":1086},{\"id\":1087},{\"id\":1088},{\"id\":1089},{\"id\":1090},{\"id\":1091},{\"id\":1092},{\"id\":1093},{\"id\":1094},{\"id\":1095},{\"id\":1096},{\"id\":1097},{\"id\":1098},{\"id\":1099},{\"id\":1100},{\"id\":1101},{\"id\":1102},{\"id\":1103},{\"id\":1104},{\"id\":1105},{\"id\":1106},{\"id\":1107},{\"id\":1108},{\"id\":1109},{\"id\":1110},{\"id\":1111},{\"id\":1112},{\"id\":1113},{\"id\":1114},{\"id\":1115},{\"id\":1116},{\"id\":1117},{\"id\":1118},{\"id\":1119},{\"id\":1120},{\"id\":1121},{\"id\":1122},{\"id\":1123},{\"id\":1124},{\"id\":1125},{\"id\":1126},{\"id\":1127},{\"id\":1128},{\"id\":1129},{\"id\":1130},{\"id\":1131},{\"id\":1132},{\"id\":1133},{\"id\":1134},{\"id\":1135},{\"id\":1136},{\"id\":1137},{\"id\":1138},{\"id\":1139},{\"id\":1140},{\"id\":1141},{\"id\":1142},{\"id\":1143},{\"id\":1144},{\"id\":1145},{\"id\":1146},{\"id\":1147},{\"id\":1148},{\"id\":1149},{\"id\":1150},{\"id\":1151},{\"id\":1152},{\"id\":1153},{\"id\":1154},{\"id\":1155},{\"id\":1156},{\"id\":1157},{\"id\":1158},{\"id\":1159},{\"id\":1160},{\"id\":1161},{\"id\":1162},{\"id\":1163},{\"id\":1164},{\"id\":1165},{\"id\":1166},{\"id\":1167},{\"id\":1168},{\"id\":1169},{\"id\":1170},{\"id\":1171},{\"id\":1172},{\"id\":1173},{\"id\":1174},{\"id\":1175},{\"id\":1176},{\"id\":1177},{\"id\":1178},{\"id\":1179},{\"id\":1180},{\"id\":1181},{\"id\":1182},{\"id\":1183},{\"id\":1184},{\"id\":1185},{\"id\":1186},{\"id\":1187},{\"id\":1188},{\"id\":1189},{\"id\":1190},{\"id\":1191},{\"id\":1192},{\"id\":1193},{\"id\":1194},{\"id\":1195},{\"id\":1196},{\"id\":1197},{\"id\":1198},{\"id\":1199},{\"id\":1200},{\"id\":1201},{\"id\":1202},{\"id\":1203},{\"id\":1204},{\"id\":1205},{\"id\":1206},{\"id\":1207},{\"id\":1208},{\"id\":1209},{\"id\":1210},{\"id\":1211},{\"id\":1212},{\"id\":1213},{\"id\":1214},{\"id\":1215},{\"id\":1216},{\"id\":1217},{\"id\":1218},{\"id\":1219},{\"id\":1220},{\"id\":1221},{\"id\":1222},{\"id\":1223},{\"id\":1224},{\"id\":1225},{\"id\":1226},{\"id\":1227},{\"id\":1228},{\"id\":1229},{\"id\":1230},{\"id\":1231},{\"id\":1232},{\"id\":1233},{\"id\":1234},{\"id\":1235},{\"id\":1236},{\"id\":1237},{\"id\":1238},{\"id\":1239},{\"id\":1240},{\"id\":1241},{\"id\":1242},{\"id\":1243},{\"id\":1244},{\"id\":1245},{\"id\":1246},{\"id\":1247},{\"id\":1248},{\"id\":1249},{\"id\":1250},{\"id\":1251},{\"id\":1252},{\"id\":1253},{\"id\":1254},{\"id\":1255},{\"id\":1256},{\"id\":1257},{\"id\":1258},{\"id\":1259},{\"id\":1260},{\"id\":1261},{\"id\":1262},{\"id\":1263},{\"id\":1264},{\"id\":1265},{\"id\":1266},{\"id\":1267},{\"id\":1268},{\"id\":1269},{\"id\":1270},{\"id\":1271},{\"id\":1272},{\"id\":1273},{\"id\":1274},{\"id\":1275},{\"id\":1276},{\"id\":1277},{\"id\":1278},{\"id\":1279},{\"id\":1280},{\"id\":1281},{\"id\":1282},{\"id\":1283},{\"id\":1284},{\"id\":1285},{\"id\":1286},{\"id\":1287},{\"id\":1288},{\"id\":1289},{\"id\":1290},{\"id\":1291},{\"id\":1292},{\"id\":1293},{\"id\":1294},{\"id\":1295},{\"id\":1296},{\"id\":1297},{\"id\":1298},{\"id\":1299},{\"id\":1300},{\"id\":1301},{\"id\":1302},{\"id\":1303},{\"id\":1304},{\"id\":1305},{\"id\":1306},{\"id\":1307},{\"id\":1308},{\"id\":1309},{\"id\":1310},{\"id\":1311},{\"id\":1312},{\"id\":1313},{\"id\":1314},{\"id\":1315},{\"id\":1316},{\"id\":1317},{\"id\":1318},{\"id\":1319},{\"id\":1320},{\"id\":1321},{\"id\":1322},{\"id\":1323},{\"id\":1324},{\"id\":1325},{\"id\":1326},{\"id\":1327},{\"id\":1328},{\"id\":1329},{\"id\":1330},{\"id\":1331},{\"id\":1332},{\"id\":1333},{\"id\":1334},{\"id\":1335},{\"id\":1336},{\"id\":1337},{\"id\":1338},{\"id\":1339},{\"id\":1340},{\"id\":1341},{\"id\":1342},{\"id\":1343},{\"id\":1344},{\"id\":1345},{\"id\":1346},{\"id\":1347},{\"id\":1348},{\"id\":1349},{\"id\":1350},{\"id\":1351},{\"id\":1352},{\"id\":1353},{\"id\":1354},{\"id\":1355},{\"id\":1356},{\"id\":1357},{\"id\":1358},{\"id\":1359},{\"id\":1360},{\"id\":1361},{\"id\":1362},{\"id\":1363},{\"id\":1364},{\"id\":1365},{\"id\":1366},{\"id\":1367},{\"id\":1368},{\"id\":1369},{\"id\":1370},{\"id\":1371},{\"id\":1372},{\"id\":1373},{\"id\":1374},{\"id\":1375},{\"id\":1376},{\"id\":1377},{\"id\":1378},{\"id\":1379},{\"id\":1380},{\"id\":1381},{\"id\":1382},{\"id\":1383},{\"id\":1384},{\"id\":1385},{\"id\":1386},{\"id\":1387},{\"id\":1388},{\"id\":1389},{\"id\":1390},{\"id\":1391},{\"id\":1392},{\"id\":1393},{\"id\":1394},{\"id\":1395},{\"id\":1396},{\"id\":1397},{\"id\":1398},{\"id\":1399},{\"id\":1400},{\"id\":1401},{\"id\":1402},{\"id\":1403},{\"id\":1404},{\"id\":1405},{\"id\":1406},{\"id\":1407},{\"id\":1408},{\"id\":1409},{\"id\":1410},{\"id\":1411},{\"id\":1412},{\"id\":1413},{\"id\":1414},{\"id\":1415},{\"id\":1416},{\"id\":1417},{\"id\":1418},{\"id\":1419},{\"id\":1420},{\"id\":1421},{\"id\":1422},{\"id\":1423},{\"id\":1424},{\"id\":1425},{\"id\":1426},{\"id\":1427},{\"id\":1428},{\"id\":1429},{\"id\":1430},{\"id\":1431},{\"id\":1432},{\"id\":1433},{\"id\":1434},{\"id\":1435},{\"id\":1436},{\"id\":1437},{\"id\":1438},{\"id\":1439},{\"id\":1440},{\"id\":1441},{\"id\":1442},{\"id\":1443},{\"id\":1444},{\"id\":1445},{\"id\":1446},{\"id\":1447},{\"id\":1448},{\"id\":1449},{\"id\":1450},{\"id\":1451},{\"id\":1452},{\"id\":1453},{\"id\":1454},{\"id\":1455},{\"id\":1456},{\"id\":1457},{\"id\":1458},{\"id\":1459},{\"id\":1460},{\"id\":1461},{\"id\":1462},{\"id\":1463},{\"id\":1464},{\"id\":1465},{\"id\":1466},{\"id\":1467},{\"id\":1468},{\"id\":1469},{\"id\":1470},{\"id\":1471},{\"id\":1472},{\"id\":1473},{\"id\":1474},{\"id\":1475},{\"id\":1476},{\"id\":1477},{\"id\":1478},{\"id\":1479},{\"id\":1480},{\"id\":1481},{\"id\":1482},{\"id\":1483},{\"id\":1484},{\"id\":1485},{\"id\":1486},{\"id\":1487},{\"id\":1488},{\"id\":1489},{\"id\":1490},{\"id\":1491},{\"id\":1492},{\"id\":1493},{\"id\":1494},{\"id\":1495},{\"id\":1496},{\"id\":1497},{\"id\":1498},{\"id\":1499},{\"id\":1500},{\"id\":1501},{\"id\":1502},{\"id\":1503},{\"id\":1504},{\"id\":1505},{\"id\":1506},{\"id\":1507},{\"id\":1508},{\"id\":1509},{\"id\":1510},{\"id\":1511},{\"id\":1512},{\"id\":1513},{\"id\":1514},{\"id\":1515},{\"id\":1516},{\"id\":1517},{\"id\":1518},{\"id\":1519},{\"id\":1520},{\"id\":1521},{\"id\":1522},{\"id\":1523},{\"id\":1524},{\"id\":1525},{\"id\":1526},{\"id\":1527},{\"id\":1528},{\"id\":1529},{\"id\":1530},{\"id\":1531},{\"id\":1532},{\"id\":1533},{\"id\":1534},{\"id\":1535},{\"id\":1536},{\"id\":1537},{\"id\":1538},{\"id\":1539},{\"id\":1540},{\"id\":1541},{\"id\":1542},{\"id\":1543},{\"id\":1544},{\"id\":1545},{\"id\":1546},{\"id\":1547},{\"id\":1548},{\"id\":1549},{\"id\":1550},{\"id\":1551},{\"id\":1552},{\"id\":1553},{\"id\":1554},{\"id\":1555},{\"id\":1556},{\"id\":1557},{\"id\":1558},{\"id\":1559},{\"id\":1560},{\"id\":1561},{\"id\":1562},{\"id\":1563},{\"id\":1564},{\"id\":1565},{\"id\":1566},{\"id\":1567},{\"id\":1568},{\"id\":1569},{\"id\":1570},{\"id\":1571},{\"id\":1572},{\"id\":1573},{\"id\":1574},{\"id\":1575},{\"id\":1576},{\"id\":1577},{\"id\":1578},{\"id\":1579},{\"id\":1580},{\"id\":1581},{\"id\":1582},{\"id\":1583},{\"id\":1584},{\"id\":1585},{\"id\":1586},{\"id\":1587},{\"id\":1588},{\"id\":1589},{\"id\":1590},{\"id\":1591},{\"id\":1592},{\"id\":1593},{\"id\":1594},{\"id\":1595},{\"id\":1596},{\"id\":1597},{\"id\":1598},{\"id\":1599},{\"id\":1600},{\"id\":1601},{\"id\":1602},{\"id\":1603},{\"id\":1604},{\"id\":1605},{\"id\":1606},{\"id\":1607},{\"id\":1608},{\"id\":1609},{\"id\":1610},{\"id\":1611},{\"id\":1612},{\"id\":1613},{\"id\":1614},{\"id\":1615},{\"id\":1616},{\"id\":1617},{\"id\":1618},{\"id\":1619},{\"id\":1620},{\"id\":1621},{\"id\":1622},{\"id\":1623},{\"id\":1624},{\"id\":1625},{\"id\":1626},{\"id\":1627},{\"id\":1628},{\"id\":1629},{\"id\":1630},{\"id\":1631},{\"id\":1632},{\"id\":1633},{\"id\":1634},{\"id\":1635},{\"id\":1636},{\"id\":1637},{\"id\":1638},{\"id\":1639},{\"id\":1640},{\"id\":1641},{\"id\":1642},{\"id\":1643},{\"id\":1644},{\"id\":1645},{\"id\":1646},{\"id\":1647},{\"id\":1648},{\"id\":1649},{\"id\":1650},{\"id\":1651},{\"id\":1652},{\"id\":1653},{\"id\":1654},{\"id\":1655},{\"id\":1656},{\"id\":1657},{\"id\":1658},{\"id\":1659},{\"id\":1660},{\"id\":1661},{\"id\":1662},{\"id\":1663},{\"id\":1664},{\"id\":1665},{\"id\":1666},{\"id\":1667},{\"id\":1668},{\"id\":1669},{\"id\":1670},{\"id\":1671},{\"id\":1672},{\"id\":1673},{\"id\":1674},{\"id\":1675},{\"id\":1676},{\"id\":1677},{\"id\":1678},{\"id\":1679},{\"id\":1680},{\"id\":1681},{\"id\":1682},{\"id\":1683},{\"id\":1684},{\"id\":1685},{\"id\":1686},{\"id\":1687},{\"id\":1688},{\"id\":1689},{\"id\":1690},{\"id\":1691},{\"id\":1692},{\"id\":1693},{\"id\":1694},{\"id\":1695},{\"id\":1696},{\"id\":1697},{\"id\":1698},{\"id\":1699},{\"id\":1700},{\"id\":1701},{\"id\":1702},{\"id\":1703},{\"id\":1704},{\"id\":1705},{\"id\":1706},{\"id\":1707},{\"id\":1708},{\"id\":1709},{\"id\":1710},{\"id\":1711},{\"id\":1712},{\"id\":1713},{\"id\":1714},{\"id\":1715},{\"id\":1716},{\"id\":1717},{\"id\":1718},{\"id\":1719},{\"id\":1720},{\"id\":1721},{\"id\":1722},{\"id\":1723},{\"id\":1724},{\"id\":1725},{\"id\":1726},{\"id\":1727},{\"id\":1728},{\"id\":1729},{\"id\":1730},{\"id\":1731},{\"id\":1732},{\"id\":1733},{\"id\":1734},{\"id\":1735},{\"id\":1736},{\"id\":1737},{\"id\":1738},{\"id\":1739},{\"id\":1740},{\"id\":1741},{\"id\":1742},{\"id\":1743},{\"id\":1744},{\"id\":1745},{\"id\":1746},{\"id\":1747},{\"id\":1748},{\"id\":1749},{\"id\":1750},{\"id\":1751},{\"id\":1752},{\"id\":1753},{\"id\":1754},{\"id\":1755},{\"id\":1756},{\"id\":1757},{\"id\":1758},{\"id\":1759},{\"id\":1760},{\"id\":1761},{\"id\":1762},{\"id\":1763},{\"id\":1764},{\"id\":1765},{\"id\":1766},{\"id\":1767},{\"id\":1768},{\"id\":1769},{\"id\":1770},{\"id\":1771},{\"id\":1772},{\"id\":1773},{\"id\":1774},{\"id\":1775},{\"id\":1776},{\"id\":1777},{\"id\":1778},{\"id\":1779},{\"id\":1780},{\"id\":1781},{\"id\":1782},{\"id\":1783},{\"id\":1784},{\"id\":1785},{\"id\":1786},{\"id\":1787},{\"id\":1788},{\"id\":1789},{\"id\":1790},{\"id\":1791},{\"id\":1792},{\"id\":1793},{\"id\":1794},{\"id\":1795},{\"id\":1796},{\"id\":1797},{\"id\":1798},{\"id\":1799},{\"id\":1800},{\"id\":1801},{\"id\":1802},{\"id\":1803},{\"id\":1804},{\"id\":1805},{\"id\":1806},{\"id\":1807},{\"id\":1808},{\"id\":1809},{\"id\":1810},{\"id\":1811},{\"id\":1812},{\"id\":1813},{\"id\":1814},{\"id\":1815},{\"id\":1816},{\"id\":1817},{\"id\":1818},{\"id\":1819},{\"id\":1820},{\"id\":1821},{\"id\":1822},{\"id\":1823},{\"id\":1824},{\"id\":1825},{\"id\":1826},{\"id\":1827},{\"id\":1828},{\"id\":1829},{\"id\":1830},{\"id\":1831},{\"id\":1832},{\"id\":1833},{\"id\":1834},{\"id\":1835},{\"id\":1836},{\"id\":1837},{\"id\":1838},{\"id\":1839},{\"id\":1840},{\"id\":1841},{\"id\":1842},{\"id\":1843},{\"id\":1844},{\"id\":1845},{\"id\":1846},{\"id\":1847},{\"id\":1848},{\"id\":1849},{\"id\":1850},{\"id\":1851},{\"id\":1852},{\"id\":1853},{\"id\":1854},{\"id\":1855},{\"id\":1856},{\"id\":1857},{\"id\":1858},{\"id\":1859},{\"id\":1860},{\"id\":1861},{\"id\":1862},{\"id\":1863},{\"id\":1864},{\"id\":1865},{\"id\":1866},{\"id\":1867},{\"id\":1868},{\"id\":1869},{\"id\":1870},{\"id\":1871},{\"id\":1872},{\"id\":1873},{\"id\":1874},{\"id\":1875},{\"id\":1876},{\"id\":1877},{\"id\":1878},{\"id\":1879},{\"id\":1880},{\"id\":1881},{\"id\":1882},{\"id\":1883},{\"id\":1884},{\"id\":1885},{\"id\":1886},{\"id\":1887},{\"id\":1888},{\"id\":1889},{\"id\":1890},{\"id\":1891},{\"id\":1892},{\"id\":1893},{\"id\":1894},{\"id\":1895},{\"id\":1896},{\"id\":1897},{\"id\":1898},{\"id\":1899},{\"id\":1900},{\"id\":1901},{\"id\":1902},{\"id\":1903},{\"id\":1904},{\"id\":1905},{\"id\":1906},{\"id\":1907},{\"id\":1908},{\"id\":1909},{\"id\":1910},{\"id\":1911},{\"id\":1912},{\"id\":1913},{\"id\":1914},{\"id\":1915},{\"id\":1916},{\"id\":1917},{\"id\":1918},{\"id\":1919},{\"id\":1920},{\"id\":1921},{\"id\":1922},{\"id\":1923},{\"id\":1924},{\"id\":1925},{\"id\":1926},{\"id\":1927},{\"id\":1928},{\"id\":1929},{\"id\":1930},{\"id\":1931},{\"id\":1932},{\"id\":1933},{\"id\":1934},{\"id\":1935},{\"id\":1936},{\"id\":1937},{\"id\":1938},{\"id\":1939},{\"id\":1940},{\"id\":1941},{\"id\":1942},{\"id\":1943},{\"id\":1944},{\"id\":1945},{\"id\":1946},{\"id\":1947},{\"id\":1948},{\"id\":1949},{\"id\":1950},{\"id\":1951},{\"id\":1952},{\"id\":1953},{\"id\":1954},{\"id\":1955},{\"id\":1956},{\"id\":1957},{\"id\":1958},{\"id\":1959},{\"id\":1960},{\"id\":1961},{\"id\":1962},{\"id\":1963},{\"id\":1964},{\"id\":1965},{\"id\":1966},{\"id\":1967},{\"id\":1968},{\"id\":1969},{\"id\":1970},{\"id\":1971},{\"id\":1972},{\"id\":1973},{\"id\":1974},{\"id\":1975},{\"id\":1976},{\"id\":1977},{\"id\":1978},{\"id\":1979},{\"id\":1980},{\"id\":1981},{\"id\":1982},{\"id\":1983},{\"id\":1984},{\"id\":1985},{\"id\":1986},{\"id\":1987},{\"id\":1988},{\"id\":1989},{\"id\":1990},{\"id\":1991},{\"id\":1992},{\"id\":1993},{\"id\":1994},{\"id\":1995},{\"id\":1996},{\"id\":1997},{\"id\":1998},{\"id\":1999},{\"id\":2000},{\"id\":2001},{\"id\":2002},{\"id\":2003},{\"id\":2004},{\"id\":2005},{\"id\":2006},{\"id\":2007},{\"id\":2008},{\"id\":2009},{\"id\":2010},{\"id\":2011},{\"id\":2012},{\"id\":2013},{\"id\":2014},{\"id\":2015},{\"id\":2016},{\"id\":2017},{\"id\":2018},{\"id\":2019},{\"id\":2020},{\"id\":2021},{\"id\":2022},{\"id\":2023},{\"id\":2024},{\"id\":2025},{\"id\":2026},{\"id\":2027},{\"id\":2028},{\"id\":2029},{\"id\":2030},{\"id\":2031},{\"id\":2032},{\"id\":2033},{\"id\":2034},{\"id\":2035},{\"id\":2036},{\"id\":2037},{\"id\":2038},{\"id\":2039},{\"id\":2040},{\"id\":2041},{\"id\":2042},{\"id\":2043},{\"id\":2044},{\"id\":2045},{\"id\":2046},{\"id\":2047},{\"id\":2048},{\"id\":2049},{\"id\":2050},{\"id\":2051},{\"id\":2052},{\"id\":2053},{\"id\":2054},{\"id\":2055},{\"id\":2056},{\"id\":2057},{\"id\":2058},{\"id\":2059},{\"id\":2060},{\"id\":2061},{\"id\":2062},{\"id\":2063},{\"id\":2064},{\"id\":2065},{\"id\":2066},{\"id\":2067},{\"id\":2068},{\"id\":2069},{\"id\":2070},{\"id\":2071},{\"id\":2072},{\"id\":2073},{\"id\":2074},{\"id\":2075},{\"id\":2076},{\"id\":2077},{\"id\":2078},{\"id\":2079},{\"id\":2080},{\"id\":2081},{\"id\":2082},{\"id\":2083},{\"id\":2084},{\"id\":2085},{\"id\":2086},{\"id\":2087},{\"id\":2088},{\"id\":2089},{\"id\":2090},{\"id\":2091},{\"id\":2092},{\"id\":2093},{\"id\":2094},{\"id\":2095},{\"id\":2096},{\"id\":2097},{\"id\":2098},{\"id\":2099},{\"id\":2100},{\"id\":2101},{\"id\":2102},{\"id\":2103},{\"id\":2104},{\"id\":2105},{\"id\":2106},{\"id\":2107},{\"id\":2108},{\"id\":2109},{\"id\":2110},{\"id\":2111},{\"id\":2112},{\"id\":2113},{\"id\":2114},{\"id\":2115},{\"id\":2116},{\"id\":2117},{\"id\":2118},{\"id\":2119},{\"id\":2120},{\"id\":2121},{\"id\":2122},{\"id\":2123},{\"id\":2124},{\"id\":2125},{\"id\":2126},{\"id\":2127},{\"id\":2128},{\"id\":2129},{\"id\":2130},{\"id\":2131},{\"id\":2132},{\"id\":2133},{\"id\":2134},{\"id\":2135},{\"id\":2136},{\"id\":2137},{\"id\":2138},{\"id\":2139},{\"id\":2140},{\"id\":2141},{\"id\":2142},{\"id\":2143},{\"id\":2144},{\"id\":2145},{\"id\":2146},{\"id\":2147},{\"id\":2148},{\"id\":2149},{\"id\":2150},{\"id\":2151},{\"id\":2152},{\"id\":2153},{\"id\":2154},{\"id\":2155},{\"id\":2156},{\"id\":2157},{\"id\":2158},{\"id\":2159},{\"id\":2160},{\"id\":2161},{\"id\":2162},{\"id\":2163},{\"id\":2164},{\"id\":2165},{\"id\":2166},{\"id\":2167},{\"id\":2168},{\"id\":2169},{\"id\":2170},{\"id\":2171},{\"id\":2172},{\"id\":2173},{\"id\":2174},{\"id\":2175},{\"id\":2176},{\"id\":2177},{\"id\":2178},{\"id\":2179},{\"id\":2180},{\"id\":2181},{\"id\":2182},{\"id\":2183},{\"id\":2184},{\"id\":2185},{\"id\":2186},{\"id\":2187},{\"id\":2188},{\"id\":2189},{\"id\":2190},{\"id\":2191},{\"id\":2192},{\"id\":2193},{\"id\":2194},{\"id\":2195},{\"id\":2196},{\"id\":2197},{\"id\":2198},{\"id\":2199},{\"id\":2200},{\"id\":2201},{\"id\":2202},{\"id\":2203},{\"id\":2204},{\"id\":2205},{\"id\":2206},{\"id\":2207},{\"id\":2208},{\"id\":2209},{\"id\":2210},{\"id\":2211},{\"id\":2212},{\"id\":2213},{\"id\":2214},{\"id\":2215},{\"id\":2216},{\"id\":2217},{\"id\":2218},{\"id\":2219},{\"id\":2220},{\"id\":2221},{\"id\":2222},{\"id\":2223},{\"id\":2224},{\"id\":2225},{\"id\":2226},{\"id\":2227},{\"id\":2228},{\"id\":2229},{\"id\":2230},{\"id\":2231},{\"id\":2232},{\"id\":2233},{\"id\":2234},{\"id\":2235},{\"id\":2236},{\"id\":2237},{\"id\":2238},{\"id\":2239},{\"id\":2240},{\"id\":2241},{\"id\":2242},{\"id\":2243},{\"id\":2244},{\"id\":2245},{\"id\":2246},{\"id\":2247},{\"id\":2248},{\"id\":2249},{\"id\":2250},{\"id\":2251},{\"id\":2252},{\"id\":2253},{\"id\":2254},{\"id\":2255},{\"id\":2256},{\"id\":2257},{\"id\":2258},{\"id\":2259},{\"id\":2260},{\"id\":2261},{\"id\":2262},{\"id\":2263},{\"id\":2264},{\"id\":2265},{\"id\":2266},{\"id\":2267},{\"id\":2268},{\"id\":2269},{\"id\":2270},{\"id\":2271},{\"id\":2272},{\"id\":2273},{\"id\":2274},{\"id\":2275},{\"id\":2276},{\"id\":2277},{\"id\":2278},{\"id\":2279},{\"id\":2280},{\"id\":2281},{\"id\":2282},{\"id\":2283},{\"id\":2284},{\"id\":2285},{\"id\":2286},{\"id\":2287},{\"id\":2288},{\"id\":2289},{\"id\":2290},{\"id\":2291},{\"id\":2292},{\"id\":2293},{\"id\":2294},{\"id\":2295},{\"id\":2296},{\"id\":2297},{\"id\":2298},{\"id\":2299},{\"id\":2300},{\"id\":2301},{\"id\":2302},{\"id\":2303},{\"id\":2304},{\"id\":2305},{\"id\":2306},{\"id\":2307},{\"id\":2308},{\"id\":2309},{\"id\":2310},{\"id\":2311},{\"id\":2312},{\"id\":2313},{\"id\":2314},{\"id\":2315},{\"id\":2316},{\"id\":2317},{\"id\":2318},{\"id\":2319},{\"id\":2320},{\"id\":2321},{\"id\":2322},{\"id\":2323},{\"id\":2324},{\"id\":2325},{\"id\":2326},{\"id\":2327},{\"id\":2328},{\"id\":2329},{\"id\":2330},{\"id\":2331},{\"id\":2332},{\"id\":2333},{\"id\":2334},{\"id\":2335},{\"id\":2336},{\"id\":2337},{\"id\":2338},{\"id\":2339},{\"id\":2340},{\"id\":2341},{\"id\":2342},{\"id\":2343},{\"id\":2344},{\"id\":2345},{\"id\":2346},{\"id\":2347},{\"id\":2348},{\"id\":2349},{\"id\":2350},{\"id\":2351},{\"id\":2352},{\"id\":2353},{\"id\":2354},{\"id\":2355},{\"id\":2356},{\"id\":2357},{\"id\":2358},{\"id\":2359},{\"id\":2360},{\"id\":2361},{\"id\":2362},{\"id\":2363},{\"id\":2364},{\"id\":2365},{\"id\":2366},{\"id\":2367},{\"id\":2368},{\"id\":2369},{\"id\":2370},{\"id\":2371},{\"id\":2372},{\"id\":2373},{\"id\":2374},{\"id\":2375},{\"id\":2376},{\"id\":2377},{\"id\":2378},{\"id\":2379},{\"id\":2380},{\"id\":2381},{\"id\":2382},{\"id\":2383},{\"id\":2384},{\"id\":2385},{\"id\":2386},{\"id\":2387},{\"id\":2388},{\"id\":2389},{\"id\":2390},{\"id\":2391},{\"id\":2392},{\"id\":2393},{\"id\":2394},{\"id\":2395},{\"id\":2396},{\"id\":2397},{\"id\":2398},{\"id\":2399},{\"id\":2400},{\"id\":2401},{\"id\":2402},{\"id\":2403},{\"id\":2404},{\"id\":2405},{\"id\":2406},{\"id\":2407},{\"id\":2408},{\"id\":2409},{\"id\":2410},{\"id\":2411},{\"id\":2412},{\"id\":2413},{\"id\":2414},{\"id\":2415},{\"id\":2416},{\"id\":2417},{\"id\":2418},{\"id\":2419},{\"id\":2420},{\"id\":2421},{\"id\":2422},{\"id\":2423},{\"id\":2424},{\"id\":2425},{\"id\":2426},{\"id\":2427},{\"id\":2428},{\"id\":2429},{\"id\":2430},{\"id\":2431},{\"id\":2432},{\"id\":2433},{\"id\":2434},{\"id\":2435},{\"id\":2436},{\"id\":2437},{\"id\":2438},{\"id\":2439},{\"id\":2440},{\"id\":2441},{\"id\":2442},{\"id\":2443},{\"id\":2444},{\"id\":2445},{\"id\":2446},{\"id\":2447},{\"id\":2448},{\"id\":2449},{\"id\":2450},{\"id\":2451},{\"id\":2452},{\"id\":2453},{\"id\":2454},{\"id\":2455},{\"id\":2456},{\"id\":2457},{\"id\":2458},{\"id\":2459},{\"id\":2460},{\"id\":2461},{\"id\":2462},{\"id\":2463},{\"id\":2464},{\"id\":2465},{\"id\":2466},{\"id\":2467},{\"id\":2468},{\"id\":2469},{\"id\":2470},{\"id\":2471},{\"id\":2472},{\"id\":2473},{\"id\":2474},{\"id\":2475},{\"id\":2476},{\"id\":2477},{\"id\":2478},{\"id\":2479},{\"id\":2480},{\"id\":2481},{\"id\":2482},{\"id\":2483},{\"id\":2484},{\"id\":2485},{\"id\":2486},{\"id\":2487},{\"id\":2488},{\"id\":2489},{\"id\":2490},{\"id\":2491},{\"id\":2492},{\"id\":2493},{\"id\":2494},{\"id\":2495},{\"id\":2496},{\"id\":2497},{\"id\":2498},{\"id\":2499},{\"id\":2500},{\"id\":2501},{\"id\":2502},{\"id\":2503},{\"id\":2504},{\"id\":2505},{\"id\":2506},{\"id\":2507},{\"id\":2508},{\"id\":2509},{\"id\":2510},{\"id\":2511},{\"id\":2512},{\"id\":2513},{\"id\":2514},{\"id\":2515},{\"id\":2516},{\"id\":2517},{\"id\":2518},{\"id\":2519},{\"id\":2520},{\"id\":2521},{\"id\":2522},{\"id\":2523},{\"id\":2524},{\"id\":2525},{\"id\":2526},{\"id\":2527},{\"id\":2528},{\"id\":2529},{\"id\":2530},{\"id\":2531},{\"id\":2532},{\"id\":2533},{\"id\":2534},{\"id\":2535},{\"id\":2536},{\"id\":2537},{\"id\":2538},{\"id\":2539},{\"id\":2540},{\"id\":2541},{\"id\":2542},{\"id\":2543},{\"id\":2544},{\"id\":2545},{\"id\":2546},{\"id\":2547},{\"id\":2548},{\"id\":2549},{\"id\":2550},{\"id\":2551},{\"id\":2552},{\"id\":2553},{\"id\":2554},{\"id\":2555},{\"id\":2556},{\"id\":2557},{\"id\":2558},{\"id\":2559},{\"id\":2560},{\"id\":2561},{\"id\":2562},{\"id\":2563},{\"id\":2564},{\"id\":2565},{\"id\":2566},{\"id\":2567},{\"id\":2568},{\"id\":2569},{\"id\":2570},{\"id\":2571},{\"id\":2572},{\"id\":2573},{\"id\":2574},{\"id\":2575},{\"id\":2576},{\"id\":2577},{\"id\":2578},{\"id\":2579},{\"id\":2580},{\"id\":2581},{\"id\":2582},{\"id\":2583},{\"id\":2584},{\"id\":2585},{\"id\":2586},{\"id\":2587},{\"id\":2588},{\"id\":2589},{\"id\":2590},{\"id\":2591},{\"id\":2592},{\"nodeType\":3,\"id\":2596,\"textContent\":\" // Track clicks on page $(document).ready(function() { $(\\\".control\\\").click(function(e) { e.stopImmediatePropagation(); clicks = clicks + 1; console.log(clicks); }); }); $('.userid').html(sid); // console.log(\\\"start of clicked array: \\\"+clicked); // console.log(\\\"start of hovered string: \\\"+hovered); //set correct answers for each question var triangular_answers = { \\\"acme.starttime.1\\\" : [\\\"F\\\"], \\\"acme.starts.1\\\" : [\\\"K\\\"], \\\"acme.meets.1\\\" : [\\\"F\\\"], \\\"acme.endtime.1\\\" : [\\\"H\\\"], \\\"acme.midpoint.1\\\" : [\\\"O\\\"], \\\"acme.starttime.2\\\" : [\\\"F\\\"], \\\"acme.starts.2\\\" : [\\\"K\\\"], \\\"acme.meets.2\\\" : [\\\"F\\\"], \\\"acme.endtime.2\\\" : [\\\"H\\\"], \\\"acme.midpoint.2\\\" : [\\\"A\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"E\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"E\\\"], \\\"bigset.starttime.1\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.1\\\" : [\\\"G\\\"], \\\"bigset.meets.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.1\\\" : [\\\"X\\\"], \\\"bigset.midpoint.1\\\" : [\\\"K\\\",\\\"X\\\"], \\\"bigset.starttime.2\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.2\\\" : [\\\"G\\\"], \\\"bigset.meets.2\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.2\\\" : [\\\"X\\\"], \\\"bigset.midpoint.2\\\" : [\\\"K\\\",\\\"X\\\"] } var orthogonal_answers = { \\\"acme.starttime.1\\\" : [\\\"A\\\"], \\\"acme.starts.1\\\" : [\\\"E\\\"], \\\"acme.meets.1\\\" : [\\\"Z\\\"], \\\"acme.endtime.1\\\" : [\\\"U\\\"], \\\"acme.midpoint.1\\\" : [\\\"U\\\"], \\\"acme.starttime.2\\\" : [\\\"0\\\"], \\\"acme.starts.2\\\" : [\\\"0\\\"], \\\"acme.meets.2\\\" : [\\\"0\\\"], \\\"acme.endtime.2\\\" : [\\\"0\\\"], \\\"acme.midpoint.2\\\" : [\\\"0\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"X\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"X\\\"], \\\"bigset.starttime.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.1\\\" : [\\\"B\\\"], \\\"bigset.meets.1\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.1\\\" : [\\\"B\\\"], \\\"bigset.midpoint.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.starttime.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.2\\\" : [\\\"B\\\"], \\\"bigset.meets.2\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.2\\\" : [\\\"B\\\"], \\\"bigset.midpoint.2\\\" : [\\\"E\\\",\\\"F\\\"] } //display the question and answer buttons based on input values from jsPsych document.getElementById(scenario+\\\".\\\"+question).style.display = \\\"block\\\"; if (question == \\\"strategy\\\") {document.getElementById(\\\"strategyButton\\\").style.display = \\\"block\\\";} else {document.getElementById(\\\"testingButton\\\").style.display = \\\"block\\\";} //---------SET PROPERTIES OF THE GRAPH -------------// // set the dimensions and margins of the graph var margin = {top: 25, right: 30, bottom: 90, left: 100}, width = 800, height = 800; var intersects = false; //default value for intersects scaffold var xAxisTitle, yAxisTitle; var datafile =\\\"\\\"; // SET AXIS VALUES if (axis == 1){ axis = \\\"Orthogonal-XInside-YFull\\\"; } else if (axis == 2){ axis = \\\"Orthogonal-XInside-YPartial\\\"; } else if (axis ==3){ axis = \\\"Triangular-XInside-YInside\\\"; } else if (axis ==4){ axis = \\\"Orthogonal-XInside-YInside\\\"; } else if (axis ==5){ axis = \\\"Orthogonal-XFull-YFull\\\"; } // SET EXPLICIT SCAFFOLD FEATURES if (explicit ==2 && axis != \\\"diagonal\\\"){ scaffold = 2; intersects = false; } else if (explicit == 2 && axis == \\\"diagonal\\\"){ scaffold = 2; intersects = false; } //TODO: not sure if above two lines are still valid since leaders are now generated on the fly else if (explicit == 3){ $('#hint-interactive').css(\\\"display\\\",\\\"block\\\"); //display textimage scaffold intersects = true; } //SET DATA FILE FOR IMPLICIT SCAFFOLD if (impasse == 1){ datafile = \\\"../views/src/data/acme_nonimpasse.csv\\\"; } else if (impasse == 2){ datafile = \\\"../views/src/data/acme_impasse.csv\\\"; } //OVERRIDE DATA FILE FOR NON-SCAFFOLD QUESTIONS if (q > 5) { //override data file if q# is greater than 5 datafile = \\\"../views/src/data/bigset.csv\\\"; console.log(\\\"override data file\\\"); $('#orthogonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#diagonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#hint-interactive').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold intersects = false; } // //---------CREATE THE SVG ------------------------// var svg = d3.select(\\\".d3container\\\").append(\\\"svg\\\") .attr(\\\"width\\\", width + margin.left + margin.right) .attr(\\\"height\\\", height + margin.top + margin.bottom) .append(\\\"g\\\") .attr(\\\"transform\\\", \\\"translate(\\\" + margin.left + \\\",\\\" + margin.top + \\\")\\\"); //---------DRAW THE GRAPH ------------------------// xAxisTitle = \\\"START & END TIME (time of day)\\\"; yAxisTitle = \\\"DURATION (in hours)\\\"; drawTriangleModel(datafile,intersects,axis,scaffold,q); \"},{\"id\":2593},{\"id\":2594},{\"nodeType\":3,\"id\":2597,\"textContent\":\" //MOUSE LOGGING SCRIPT var mouseLog = [] var xwidth = $(document).width(); var xheight = $(document).width(); mouseLog.push(\\\"{x:\\\"+xwidth+\\\",y:\\\"+xheight+\\\",t:\\\"+\\\"0};\\\") document.onmousemove = function(e){ var pageCoords = \\\"{x:\\\" + e.pageX + \\\",y:\\\"+ e.pageY +\\\",t:\\\"+ Date.now()+ \\\"};\\\" ; mouseLog.push(pageCoords); // console.log(pageCoords); }; \"},{\"id\":2595}],[],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2598,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2599,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2598},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2600,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2599},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2601,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":2600},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2602,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2599}},{\"nodeType\":1,\"id\":2603,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2602},\"parentNode\":{\"id\":2599}},{\"nodeType\":3,\"id\":2604,\"textContent\":\"What is your age?\",\"parentNode\":{\"id\":2602}},{\"nodeType\":1,\"id\":2605,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2600}},{\"nodeType\":1,\"id\":2606,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2605},\"parentNode\":{\"id\":2600}},{\"nodeType\":3,\"id\":2607,\"textContent\":\"In what country were you born?\",\"parentNode\":{\"id\":2605}},{\"nodeType\":3,\"id\":2608,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":2601}}],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2598},{\"id\":2599},{\"id\":2602},{\"id\":2604},{\"id\":2603},{\"id\":2600},{\"id\":2605},{\"id\":2607},{\"id\":2606},{\"id\":2601},{\"id\":2608}],[],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2609,\"tagName\":\"FORM\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-form\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2610,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-preamble\",\"class\":\"jspsych-survey-multi-choice-preamble\"},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2611,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-0\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2610},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2612,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-1\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2611},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2613,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-2\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2612},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2614,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-3\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2613},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2615,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"submit\",\"id\":\"jspsych-survey-multi-choice-next\",\"class\":\"jspsych-survey-multi-choice jspsych-btn\",\"value\":\"Submit Answers\"},\"previousSibling\":{\"id\":2614},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2616,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2617,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2616},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2618,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2617},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2619,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2618},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2620,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2619},\"parentNode\":{\"id\":2611}},{\"nodeType\":3,\"id\":2621,\"textContent\":\"What is your first language?\",\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2622,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2621},\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2623,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2624,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2623}},{\"nodeType\":3,\"id\":2625,\"textContent\":\"English\",\"previousSibling\":{\"id\":2624},\"parentNode\":{\"id\":2623}},{\"nodeType\":1,\"id\":2626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2618}},{\"nodeType\":1,\"id\":2627,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2626}},{\"nodeType\":3,\"id\":2628,\"textContent\":\"Spanish\",\"previousSibling\":{\"id\":2627},\"parentNode\":{\"id\":2626}},{\"nodeType\":1,\"id\":2629,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2619}},{\"nodeType\":1,\"id\":2630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2629}},{\"nodeType\":3,\"id\":2631,\"textContent\":\"Mandarin or Cantonese\",\"previousSibling\":{\"id\":2630},\"parentNode\":{\"id\":2629}},{\"nodeType\":1,\"id\":2632,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2633,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2634,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2633},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2635,\"textContent\":\"*\",\"parentNode\":{\"id\":2622}},{\"nodeType\":1,\"id\":2636,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2637,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2636},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2638,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2637},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2639,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2638},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2640,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2639},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2641,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2640},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2642,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2641},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2643,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2642},\"parentNode\":{\"id\":2612}},{\"nodeType\":3,\"id\":2644,\"textContent\":\"What is your year in school?\",\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2645,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2644},\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2646,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2637}},{\"nodeType\":1,\"id\":2647,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2646}},{\"nodeType\":3,\"id\":2648,\"textContent\":\"First\",\"previousSibling\":{\"id\":2647},\"parentNode\":{\"id\":2646}},{\"nodeType\":1,\"id\":2649,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2638}},{\"nodeType\":1,\"id\":2650,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2649}},{\"nodeType\":3,\"id\":2651,\"textContent\":\"Second\",\"previousSibling\":{\"id\":2650},\"parentNode\":{\"id\":2649}},{\"nodeType\":1,\"id\":2652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2639}},{\"nodeType\":1,\"id\":2653,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2652}},{\"nodeType\":3,\"id\":2654,\"textContent\":\"Third\",\"previousSibling\":{\"id\":2653},\"parentNode\":{\"id\":2652}},{\"nodeType\":1,\"id\":2655,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2640}},{\"nodeType\":1,\"id\":2656,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2655}},{\"nodeType\":3,\"id\":2657,\"textContent\":\"Fourth\",\"previousSibling\":{\"id\":2656},\"parentNode\":{\"id\":2655}},{\"nodeType\":1,\"id\":2658,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2641}},{\"nodeType\":1,\"id\":2659,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2658}},{\"nodeType\":3,\"id\":2660,\"textContent\":\"Fifth\",\"previousSibling\":{\"id\":2659},\"parentNode\":{\"id\":2658}},{\"nodeType\":1,\"id\":2661,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2642}},{\"nodeType\":1,\"id\":2662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2661}},{\"nodeType\":3,\"id\":2663,\"textContent\":\"Graduate\",\"previousSibling\":{\"id\":2662},\"parentNode\":{\"id\":2661}},{\"nodeType\":1,\"id\":2664,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2643}},{\"nodeType\":1,\"id\":2665,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2666,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2665},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2667,\"textContent\":\"*\",\"parentNode\":{\"id\":2645}},{\"nodeType\":1,\"id\":2668,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2669,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2668},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2670,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2669},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2671,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2670},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2672,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2671},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2673,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2672},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2674,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2673},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2675,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2674},\"parentNode\":{\"id\":2613}},{\"nodeType\":3,\"id\":2676,\"textContent\":\"What is your major area of study?\",\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2677,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2676},\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2678,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2669}},{\"nodeType\":1,\"id\":2679,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2678}},{\"nodeType\":3,\"id\":2680,\"textContent\":\"Math or Computer Sciences\",\"previousSibling\":{\"id\":2679},\"parentNode\":{\"id\":2678}},{\"nodeType\":1,\"id\":2681,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2670}},{\"nodeType\":1,\"id\":2682,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2681}},{\"nodeType\":3,\"id\":2683,\"textContent\":\"Social Sciences (incl. CogSci)\",\"previousSibling\":{\"id\":2682},\"parentNode\":{\"id\":2681}},{\"nodeType\":1,\"id\":2684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2671}},{\"nodeType\":1,\"id\":2685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2684}},{\"nodeType\":3,\"id\":2686,\"textContent\":\"Biomedical & Health Sciences\",\"previousSibling\":{\"id\":2685},\"parentNode\":{\"id\":2684}},{\"nodeType\":1,\"id\":2687,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2672}},{\"nodeType\":1,\"id\":2688,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2687}},{\"nodeType\":3,\"id\":2689,\"textContent\":\"Natural Sciences\",\"previousSibling\":{\"id\":2688},\"parentNode\":{\"id\":2687}},{\"nodeType\":1,\"id\":2690,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2673}},{\"nodeType\":1,\"id\":2691,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2690}},{\"nodeType\":3,\"id\":2692,\"textContent\":\"Engineering\",\"previousSibling\":{\"id\":2691},\"parentNode\":{\"id\":2690}},{\"nodeType\":1,\"id\":2693,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2674}},{\"nodeType\":1,\"id\":2694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2693}},{\"nodeType\":3,\"id\":2695,\"textContent\":\"Humanities\",\"previousSibling\":{\"id\":2694},\"parentNode\":{\"id\":2693}},{\"nodeType\":1,\"id\":2696,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2675}},{\"nodeType\":1,\"id\":2697,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2698,\"textContent\":\"Fine Arts\",\"previousSibling\":{\"id\":2697},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2699,\"textContent\":\"*\",\"parentNode\":{\"id\":2677}},{\"nodeType\":1,\"id\":2700,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2701,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2700},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2702,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2701},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2703,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2702},\"parentNode\":{\"id\":2614}},{\"nodeType\":3,\"id\":2704,\"textContent\":\"What is your gender?\",\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2705,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2704},\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2706,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2701}},{\"nodeType\":1,\"id\":2707,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2706}},{\"nodeType\":3,\"id\":2708,\"textContent\":\"Male\",\"previousSibling\":{\"id\":2707},\"parentNode\":{\"id\":2706}},{\"nodeType\":1,\"id\":2709,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2702}},{\"nodeType\":1,\"id\":2710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2709}},{\"nodeType\":3,\"id\":2711,\"textContent\":\"Female\",\"previousSibling\":{\"id\":2710},\"parentNode\":{\"id\":2709}},{\"nodeType\":1,\"id\":2712,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2703}},{\"nodeType\":1,\"id\":2713,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2714,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2713},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2715,\"textContent\":\"*\",\"parentNode\":{\"id\":2705}}],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2609},{\"id\":2610},{\"id\":2611},{\"id\":2616},{\"id\":2621},{\"id\":2622},{\"id\":2635},{\"id\":2617},{\"id\":2623},{\"id\":2624},{\"id\":2625},{\"id\":2618},{\"id\":2626},{\"id\":2627},{\"id\":2628},{\"id\":2619},{\"id\":2629},{\"id\":2630},{\"id\":2631},{\"id\":2620},{\"id\":2632},{\"id\":2633},{\"id\":2634},{\"id\":2612},{\"id\":2636},{\"id\":2644},{\"id\":2645},{\"id\":2667},{\"id\":2637},{\"id\":2646},{\"id\":2647},{\"id\":2648},{\"id\":2638},{\"id\":2649},{\"id\":2650},{\"id\":2651},{\"id\":2639},{\"id\":2652},{\"id\":2653},{\"id\":2654},{\"id\":2640},{\"id\":2655},{\"id\":2656},{\"id\":2657},{\"id\":2641},{\"id\":2658},{\"id\":2659},{\"id\":2660},{\"id\":2642},{\"id\":2661},{\"id\":2662},{\"id\":2663},{\"id\":2643},{\"id\":2664},{\"id\":2665},{\"id\":2666},{\"id\":2613},{\"id\":2668},{\"id\":2676},{\"id\":2677},{\"id\":2699},{\"id\":2669},{\"id\":2678},{\"id\":2679},{\"id\":2680},{\"id\":2670},{\"id\":2681},{\"id\":2682},{\"id\":2683},{\"id\":2671},{\"id\":2684},{\"id\":2685},{\"id\":2686},{\"id\":2672},{\"id\":2687},{\"id\":2688},{\"id\":2689},{\"id\":2673},{\"id\":2690},{\"id\":2691},{\"id\":2692},{\"id\":2674},{\"id\":2693},{\"id\":2694},{\"id\":2695},{\"id\":2675},{\"id\":2696},{\"id\":2697},{\"id\":2698},{\"id\":2614},{\"id\":2700},{\"id\":2704},{\"id\":2705},{\"id\":2715},{\"id\":2701},{\"id\":2706},{\"id\":2707},{\"id\":2708},{\"id\":2702},{\"id\":2709},{\"id\":2710},{\"id\":2711},{\"id\":2703},{\"id\":2712},{\"id\":2713},{\"id\":2714},{\"id\":2615}],[],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2716,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2717,\"textContent\":\" \",\"previousSibling\":{\"id\":2716},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2718,\"textContent\":\" \",\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":2718},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2720,\"textContent\":\" \",\"previousSibling\":{\"id\":2719},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2721,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":2720},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2722,\"textContent\":\" \",\"previousSibling\":{\"id\":2721},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2723,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":2722},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2724,\"textContent\":\" \",\"previousSibling\":{\"id\":2723},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2725,\"textContent\":\" \",\"parentNode\":{\"id\":2719}},{\"nodeType\":1,\"id\":2726,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":2725},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2727,\"textContent\":\" \",\"previousSibling\":{\"id\":2726},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2728,\"textContent\":\" \",\"parentNode\":{\"id\":2726}},{\"nodeType\":1,\"id\":2729,\"tagName\":\"H3\",\"attributes\":{},\"previousSibling\":{\"id\":2728},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2730,\"textContent\":\" \",\"previousSibling\":{\"id\":2729},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2731,\"textContent\":\"DEBRIEFING\",\"parentNode\":{\"id\":2729}},{\"nodeType\":3,\"id\":2732,\"textContent\":\" \",\"parentNode\":{\"id\":2721}},{\"nodeType\":1,\"id\":2733,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":2732},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2734,\"textContent\":\" \",\"previousSibling\":{\"id\":2733},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2735,\"textContent\":\" \",\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2736,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic\"},\"previousSibling\":{\"id\":2735},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2737,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2736},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2738,\"textContent\":\" \",\"previousSibling\":{\"id\":2737},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2739,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2738},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2740,\"textContent\":\" \",\"previousSibling\":{\"id\":2739},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2741,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2740},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2742,\"textContent\":\" \",\"previousSibling\":{\"id\":2741},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2743,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:bold;\"},\"previousSibling\":{\"id\":2742},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2744,\"textContent\":\" \",\"previousSibling\":{\"id\":2743},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2745,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":2744},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2746,\"textContent\":\" \",\"previousSibling\":{\"id\":2745},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2747,\"textContent\":\"Thank you very much for your participation! This debriefing will tell you more about the study, what you did, and why. \",\"parentNode\":{\"id\":2736}},{\"nodeType\":3,\"id\":2748,\"textContent\":\" \",\"parentNode\":{\"id\":2737}},{\"nodeType\":1,\"id\":2749,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2748},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2750,\"textContent\":\" You have just used a series of pictures (charts, graphs and diagrams) accompanied by different types of instructions to answer a series of problem solving questions. While you were using the pictures, we measured where you clicked, scrolled and pointed with the computer mouse. We also measured the accuracy of your responses and the time it took to complete each question.\",\"previousSibling\":{\"id\":2749},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2751,\"textContent\":\"What did you just do?\",\"parentNode\":{\"id\":2749}},{\"nodeType\":3,\"id\":2752,\"textContent\":\" \",\"parentNode\":{\"id\":2739}},{\"nodeType\":1,\"id\":2753,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2752},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2754,\"textContent\":\" Researchers of learning and cognition have long been interested in how graphic displays of information can be used to communicate, solve problems, and generate insights. As powerful as graphics may be in their communicative efficiency, they're not always immediately intuitive to understand. In short, we know a great deal more about learning with representations than we do about the learning of representations. In this project we are building upon previous research on reading and graph comprehension to explore how readers make sense of unfamiliar representations. The instructions you saw for each type of graph are known as “scaffolding techniques”, and we will compare your performance with the scaffolding techniques you saw with the performance of other participants to determine which types of instructions are most effective in helping humans to make sense of unfamiliar graphs. \",\"previousSibling\":{\"id\":2753},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2755,\"textContent\":\"Why did we have you do it?\",\"parentNode\":{\"id\":2753}},{\"nodeType\":1,\"id\":2756,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2757,\"textContent\":\" We expect that you will have found some of the graphics more difficult to use than others. We also expect that with the assistance of the instructions, after solving several problems you will learn to use the difficult graphics so that you can answer the questions even more quickly than without. If you would like to receive a copy of the results of the study, or have any further questions, please contact the researchers Primary Researcher: Amy Fox : a2fox@ucsd.edu Faculty Advisor : Dr. Jim Hollan : hollan@ucsd.edu \",\"previousSibling\":{\"id\":2756},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2758,\"textContent\":\"What do we expect to find?\",\"parentNode\":{\"id\":2756}},{\"nodeType\":3,\"id\":2759,\"textContent\":\"It is important that you do not discuss this experiment with other students who might participate after you. They must participate in the same way as you did, without any knowledge of what the experiment entails, or the reasoning behind it.\",\"parentNode\":{\"id\":2743}},{\"nodeType\":3,\"id\":2760,\"textContent\":\"Thank you for your time! We hope you enjoyed participating in this study as much as we enjoyed designing it.\",\"parentNode\":{\"id\":2745}},{\"nodeType\":3,\"id\":2761,\"textContent\":\" \",\"parentNode\":{\"id\":2723}},{\"nodeType\":1,\"id\":2762,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":2761},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2763,\"textContent\":\" \",\"previousSibling\":{\"id\":2762},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2764,\"textContent\":\"FINISH\",\"parentNode\":{\"id\":2762}}],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2716},{\"id\":2718},{\"id\":2719},{\"id\":2725},{\"id\":2726},{\"id\":2728},{\"id\":2729},{\"id\":2731},{\"id\":2730},{\"id\":2727},{\"id\":2720},{\"id\":2721},{\"id\":2732},{\"id\":2733},{\"id\":2735},{\"id\":2736},{\"id\":2747},{\"id\":2737},{\"id\":2748},{\"id\":2749},{\"id\":2751},{\"id\":2750},{\"id\":2738},{\"id\":2739},{\"id\":2752},{\"id\":2753},{\"id\":2755},{\"id\":2754},{\"id\":2740},{\"id\":2741},{\"id\":2756},{\"id\":2758},{\"id\":2757},{\"id\":2742},{\"id\":2743},{\"id\":2759},{\"id\":2744},{\"id\":2745},{\"id\":2760},{\"id\":2746},{\"id\":2734},{\"id\":2722},{\"id\":2723},{\"id\":2761},{\"id\":2762},{\"id\":2764},{\"id\":2763},{\"id\":2724},{\"id\":2717}],[],[],[]]}"
    },
    {
      "sequence": 8,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2765,\"tagName\":\"PRE\",\"attributes\":{\"id\":\"jspsych-data-display\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2766,\"textContent\":\"[ { \\\"rt\\\": 27829, \\\"stimulus\\\": \\\"img/phone.png\\\", \\\"key_press\\\": 32, \\\"block\\\": \\\"phone\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 0, \\\"time_elapsed\\\": 27832, \\\"internal_node_id\\\": \\\"0.0-0.0\\\", \\\"subject\\\": \\\"E5L6P\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 13570, \\\"url\\\": \\\"../views/src/external/consent.html\\\", \\\"block\\\": \\\"consent\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 1, \\\"time_elapsed\\\": 42492, \\\"internal_node_id\\\": \\\"0.0-1.0\\\", \\\"subject\\\": \\\"E5L6P\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 12024, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"juliet\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"115\\\\\\\"}\\\", \\\"block\\\": \\\"codes\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 2, \\\"time_elapsed\\\": 55524, \\\"internal_node_id\\\": \\\"0.0-2.0\\\", \\\"subject\\\": \\\"E5L6P\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 38479, \\\"url\\\": \\\"../views/src/external/instructions_lab.html\\\", \\\"block\\\": \\\"instructions_lab\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 3, \\\"time_elapsed\\\": 95086, \\\"internal_node_id\\\": \\\"0.0-3.0\\\", \\\"subject\\\": \\\"E5L6P\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 17194, \\\"stimulus\\\": \\\"img/acme.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"scenario\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 4, \\\"time_elapsed\\\": 113283, \\\"internal_node_id\\\": \\\"0.0-4.0\\\", \\\"subject\\\": \\\"E5L6P\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 54744, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 5, \\\"time_elapsed\\\": 169308, \\\"internal_node_id\\\": \\\"0.0-5.0-0.0\\\", \\\"subject\\\": \\\"E5L6P\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 1, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"A\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-11 AM-11 AM-11 AM-11 AM-02 PM-12 PM-A -A \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:912,y:954,t:1527030365524};\\\", \\\"{x:923,y:952,t:1527030365530};\\\", \\\"{x:944,y:950,t:1527030365546};\\\", \\\"{x:958,y:949,t:1527030365563};\\\", \\\"{x:972,y:947,t:1527030365579};\\\", \\\"{x:987,y:947,t:1527030365597};\\\", \\\"{x:999,y:947,t:1527030365613};\\\", \\\"{x:1012,y:947,t:1527030365630};\\\", \\\"{x:1019,y:948,t:1527030365648};\\\", \\\"{x:1025,y:949,t:1527030365663};\\\", \\\"{x:1033,y:950,t:1527030365679};\\\", \\\"{x:1038,y:950,t:1527030365697};\\\", \\\"{x:1043,y:951,t:1527030365714};\\\", \\\"{x:1046,y:952,t:1527030365730};\\\", \\\"{x:1054,y:952,t:1527030365747};\\\", \\\"{x:1061,y:952,t:1527030365762};\\\", \\\"{x:1070,y:952,t:1527030365779};\\\", \\\"{x:1083,y:952,t:1527030365796};\\\", \\\"{x:1099,y:952,t:1527030365813};\\\", \\\"{x:1122,y:952,t:1527030365829};\\\", \\\"{x:1151,y:952,t:1527030365848};\\\", \\\"{x:1179,y:952,t:1527030365863};\\\", \\\"{x:1209,y:952,t:1527030365879};\\\", \\\"{x:1239,y:952,t:1527030365897};\\\", \\\"{x:1265,y:953,t:1527030365913};\\\", \\\"{x:1284,y:953,t:1527030365930};\\\", \\\"{x:1299,y:953,t:1527030365947};\\\", \\\"{x:1312,y:953,t:1527030365963};\\\", \\\"{x:1316,y:953,t:1527030365980};\\\", \\\"{x:1318,y:953,t:1527030365996};\\\", \\\"{x:1319,y:954,t:1527030366219};\\\", \\\"{x:1318,y:956,t:1527030366231};\\\", \\\"{x:1314,y:960,t:1527030366248};\\\", \\\"{x:1308,y:968,t:1527030366263};\\\", \\\"{x:1302,y:974,t:1527030366280};\\\", \\\"{x:1295,y:978,t:1527030366297};\\\", \\\"{x:1288,y:982,t:1527030366314};\\\", \\\"{x:1281,y:985,t:1527030366332};\\\", \\\"{x:1280,y:985,t:1527030366347};\\\", \\\"{x:1279,y:985,t:1527030366531};\\\", \\\"{x:1278,y:985,t:1527030366546};\\\", \\\"{x:1278,y:983,t:1527030366564};\\\", \\\"{x:1278,y:979,t:1527030366580};\\\", \\\"{x:1278,y:978,t:1527030366597};\\\", \\\"{x:1278,y:975,t:1527030366613};\\\", \\\"{x:1278,y:974,t:1527030366635};\\\", \\\"{x:1278,y:973,t:1527030366669};\\\", \\\"{x:1278,y:972,t:1527030366690};\\\", \\\"{x:1278,y:971,t:1527030368924};\\\", \\\"{x:1278,y:969,t:1527030368933};\\\", \\\"{x:1278,y:968,t:1527030368949};\\\", \\\"{x:1278,y:965,t:1527030368966};\\\", \\\"{x:1277,y:964,t:1527030368983};\\\", \\\"{x:1277,y:963,t:1527030368999};\\\", \\\"{x:1277,y:962,t:1527030369019};\\\", \\\"{x:1277,y:960,t:1527030369067};\\\", \\\"{x:1277,y:959,t:1527030369091};\\\", \\\"{x:1277,y:958,t:1527030369115};\\\", \\\"{x:1277,y:957,t:1527030369132};\\\", \\\"{x:1277,y:959,t:1527030369243};\\\", \\\"{x:1277,y:960,t:1527030369251};\\\", \\\"{x:1277,y:962,t:1527030369266};\\\", \\\"{x:1277,y:965,t:1527030369283};\\\", \\\"{x:1279,y:967,t:1527030370291};\\\", \\\"{x:1280,y:969,t:1527030370300};\\\", \\\"{x:1280,y:970,t:1527030370317};\\\", \\\"{x:1280,y:972,t:1527030370333};\\\", \\\"{x:1281,y:973,t:1527030370350};\\\", \\\"{x:1282,y:974,t:1527030370371};\\\", \\\"{x:1287,y:974,t:1527030382539};\\\", \\\"{x:1296,y:974,t:1527030382547};\\\", \\\"{x:1305,y:974,t:1527030382560};\\\", \\\"{x:1321,y:970,t:1527030382576};\\\", \\\"{x:1335,y:968,t:1527030382592};\\\", \\\"{x:1347,y:964,t:1527030382610};\\\", \\\"{x:1361,y:961,t:1527030382626};\\\", \\\"{x:1364,y:959,t:1527030382642};\\\", \\\"{x:1367,y:958,t:1527030382659};\\\", \\\"{x:1368,y:956,t:1527030382676};\\\", \\\"{x:1372,y:954,t:1527030382692};\\\", \\\"{x:1378,y:950,t:1527030382709};\\\", \\\"{x:1383,y:946,t:1527030382726};\\\", \\\"{x:1391,y:941,t:1527030382742};\\\", \\\"{x:1396,y:938,t:1527030382759};\\\", \\\"{x:1401,y:935,t:1527030382776};\\\", \\\"{x:1408,y:930,t:1527030382792};\\\", \\\"{x:1412,y:927,t:1527030382809};\\\", \\\"{x:1419,y:924,t:1527030382827};\\\", \\\"{x:1423,y:924,t:1527030382842};\\\", \\\"{x:1425,y:922,t:1527030382859};\\\", \\\"{x:1427,y:922,t:1527030382876};\\\", \\\"{x:1428,y:922,t:1527030382892};\\\", \\\"{x:1429,y:922,t:1527030382923};\\\", \\\"{x:1426,y:922,t:1527030384427};\\\", \\\"{x:1419,y:925,t:1527030384444};\\\", \\\"{x:1412,y:929,t:1527030384460};\\\", \\\"{x:1407,y:932,t:1527030384477};\\\", \\\"{x:1401,y:934,t:1527030384494};\\\", \\\"{x:1397,y:936,t:1527030384510};\\\", \\\"{x:1395,y:937,t:1527030384527};\\\", \\\"{x:1394,y:938,t:1527030384545};\\\", \\\"{x:1392,y:938,t:1527030384560};\\\", \\\"{x:1391,y:939,t:1527030384577};\\\", \\\"{x:1389,y:940,t:1527030384595};\\\", \\\"{x:1386,y:942,t:1527030384610};\\\", \\\"{x:1384,y:942,t:1527030384627};\\\", \\\"{x:1383,y:943,t:1527030384644};\\\", \\\"{x:1381,y:944,t:1527030384660};\\\", \\\"{x:1379,y:944,t:1527030384677};\\\", \\\"{x:1378,y:945,t:1527030384695};\\\", \\\"{x:1376,y:945,t:1527030384710};\\\", \\\"{x:1372,y:945,t:1527030384727};\\\", \\\"{x:1368,y:946,t:1527030384744};\\\", \\\"{x:1361,y:948,t:1527030384760};\\\", \\\"{x:1353,y:949,t:1527030384778};\\\", \\\"{x:1343,y:952,t:1527030384795};\\\", \\\"{x:1337,y:953,t:1527030384810};\\\", \\\"{x:1330,y:953,t:1527030384827};\\\", \\\"{x:1329,y:953,t:1527030384844};\\\", \\\"{x:1326,y:953,t:1527030384860};\\\", \\\"{x:1322,y:955,t:1527030384877};\\\", \\\"{x:1318,y:956,t:1527030384894};\\\", \\\"{x:1315,y:956,t:1527030384910};\\\", \\\"{x:1313,y:957,t:1527030384927};\\\", \\\"{x:1311,y:957,t:1527030384944};\\\", \\\"{x:1310,y:957,t:1527030384961};\\\", \\\"{x:1308,y:957,t:1527030384977};\\\", \\\"{x:1307,y:957,t:1527030385003};\\\", \\\"{x:1306,y:957,t:1527030385011};\\\", \\\"{x:1305,y:957,t:1527030385043};\\\", \\\"{x:1304,y:957,t:1527030385066};\\\", \\\"{x:1302,y:957,t:1527030385077};\\\", \\\"{x:1301,y:957,t:1527030385094};\\\", \\\"{x:1298,y:957,t:1527030385111};\\\", \\\"{x:1297,y:958,t:1527030385128};\\\", \\\"{x:1295,y:958,t:1527030385144};\\\", \\\"{x:1293,y:959,t:1527030385161};\\\", \\\"{x:1292,y:960,t:1527030385178};\\\", \\\"{x:1291,y:960,t:1527030385195};\\\", \\\"{x:1289,y:960,t:1527030385226};\\\", \\\"{x:1289,y:961,t:1527030385245};\\\", \\\"{x:1288,y:961,t:1527030385261};\\\", \\\"{x:1288,y:962,t:1527030385277};\\\", \\\"{x:1287,y:963,t:1527030385294};\\\", \\\"{x:1286,y:963,t:1527030385311};\\\", \\\"{x:1285,y:965,t:1527030385328};\\\", \\\"{x:1282,y:966,t:1527030385345};\\\", \\\"{x:1280,y:968,t:1527030385361};\\\", \\\"{x:1279,y:969,t:1527030385377};\\\", \\\"{x:1277,y:970,t:1527030385395};\\\", \\\"{x:1276,y:972,t:1527030385427};\\\", \\\"{x:1275,y:972,t:1527030385459};\\\", \\\"{x:1274,y:973,t:1527030385483};\\\", \\\"{x:1273,y:973,t:1527030385515};\\\", \\\"{x:1272,y:974,t:1527030385530};\\\", \\\"{x:1273,y:972,t:1527030385827};\\\", \\\"{x:1274,y:970,t:1527030385834};\\\", \\\"{x:1275,y:968,t:1527030385844};\\\", \\\"{x:1277,y:966,t:1527030385861};\\\", \\\"{x:1279,y:964,t:1527030385879};\\\", \\\"{x:1281,y:962,t:1527030385896};\\\", \\\"{x:1282,y:961,t:1527030385939};\\\", \\\"{x:1283,y:960,t:1527030385954};\\\", \\\"{x:1284,y:959,t:1527030385980};\\\", \\\"{x:1280,y:955,t:1527030386667};\\\", \\\"{x:1261,y:947,t:1527030386678};\\\", \\\"{x:1209,y:928,t:1527030386695};\\\", \\\"{x:1149,y:906,t:1527030386713};\\\", \\\"{x:1088,y:885,t:1527030386728};\\\", \\\"{x:1032,y:869,t:1527030386745};\\\", \\\"{x:951,y:846,t:1527030386762};\\\", \\\"{x:893,y:829,t:1527030386779};\\\", \\\"{x:844,y:818,t:1527030386795};\\\", \\\"{x:801,y:805,t:1527030386812};\\\", \\\"{x:771,y:798,t:1527030386829};\\\", \\\"{x:745,y:791,t:1527030386845};\\\", \\\"{x:722,y:785,t:1527030386862};\\\", \\\"{x:697,y:776,t:1527030386879};\\\", \\\"{x:674,y:768,t:1527030386895};\\\", \\\"{x:646,y:760,t:1527030386912};\\\", \\\"{x:614,y:751,t:1527030386930};\\\", \\\"{x:580,y:741,t:1527030386945};\\\", \\\"{x:535,y:734,t:1527030386964};\\\", \\\"{x:503,y:729,t:1527030386979};\\\", \\\"{x:482,y:726,t:1527030386994};\\\", \\\"{x:471,y:726,t:1527030387013};\\\", \\\"{x:465,y:726,t:1527030387031};\\\", \\\"{x:463,y:726,t:1527030387048};\\\", \\\"{x:462,y:726,t:1527030387063};\\\", \\\"{x:461,y:724,t:1527030388371};\\\", \\\"{x:461,y:723,t:1527030388382};\\\", \\\"{x:461,y:722,t:1527030388399};\\\", \\\"{x:461,y:720,t:1527030388415};\\\", \\\"{x:461,y:718,t:1527030388433};\\\", \\\"{x:461,y:717,t:1527030388449};\\\", \\\"{x:461,y:715,t:1527030388465};\\\", \\\"{x:462,y:714,t:1527030388482};\\\", \\\"{x:463,y:712,t:1527030388498};\\\", \\\"{x:463,y:711,t:1527030388515};\\\", \\\"{x:463,y:709,t:1527030388532};\\\", \\\"{x:463,y:708,t:1527030388549};\\\", \\\"{x:463,y:705,t:1527030388565};\\\", \\\"{x:463,y:704,t:1527030388582};\\\", \\\"{x:463,y:703,t:1527030388599};\\\", \\\"{x:463,y:701,t:1527030388616};\\\", \\\"{x:462,y:700,t:1527030388633};\\\", \\\"{x:460,y:698,t:1527030388648};\\\", \\\"{x:459,y:695,t:1527030388665};\\\", \\\"{x:458,y:694,t:1527030388682};\\\", \\\"{x:457,y:694,t:1527030388699};\\\", \\\"{x:457,y:693,t:1527030388737};\\\", \\\"{x:457,y:692,t:1527030388753};\\\", \\\"{x:456,y:690,t:1527030388764};\\\", \\\"{x:454,y:688,t:1527030388782};\\\", \\\"{x:453,y:685,t:1527030388799};\\\", \\\"{x:450,y:681,t:1527030388814};\\\", \\\"{x:447,y:678,t:1527030388831};\\\", \\\"{x:446,y:677,t:1527030388848};\\\", \\\"{x:444,y:675,t:1527030388865};\\\", \\\"{x:443,y:673,t:1527030388882};\\\", \\\"{x:443,y:672,t:1527030388899};\\\", \\\"{x:442,y:672,t:1527030388922};\\\", \\\"{x:441,y:671,t:1527030388954};\\\", \\\"{x:439,y:670,t:1527030389027};\\\", \\\"{x:437,y:669,t:1527030389042};\\\", \\\"{x:435,y:668,t:1527030389058};\\\", \\\"{x:433,y:668,t:1527030389066};\\\", \\\"{x:429,y:665,t:1527030389082};\\\", \\\"{x:425,y:664,t:1527030389099};\\\", \\\"{x:419,y:662,t:1527030389116};\\\", \\\"{x:412,y:660,t:1527030389132};\\\", \\\"{x:406,y:656,t:1527030389149};\\\", \\\"{x:402,y:656,t:1527030389166};\\\", \\\"{x:397,y:654,t:1527030389182};\\\", \\\"{x:395,y:654,t:1527030389199};\\\", \\\"{x:392,y:652,t:1527030389216};\\\", \\\"{x:390,y:651,t:1527030389232};\\\", \\\"{x:387,y:650,t:1527030389251};\\\", \\\"{x:383,y:649,t:1527030389265};\\\", \\\"{x:379,y:649,t:1527030389282};\\\", \\\"{x:375,y:646,t:1527030389299};\\\", \\\"{x:370,y:646,t:1527030389315};\\\", \\\"{x:364,y:643,t:1527030389332};\\\", \\\"{x:357,y:642,t:1527030389349};\\\", \\\"{x:347,y:638,t:1527030389365};\\\", \\\"{x:336,y:634,t:1527030389382};\\\", \\\"{x:329,y:632,t:1527030389398};\\\", \\\"{x:322,y:630,t:1527030389416};\\\", \\\"{x:318,y:629,t:1527030389432};\\\", \\\"{x:315,y:628,t:1527030389448};\\\", \\\"{x:311,y:627,t:1527030389465};\\\", \\\"{x:308,y:626,t:1527030389483};\\\", \\\"{x:305,y:625,t:1527030389498};\\\", \\\"{x:302,y:623,t:1527030389516};\\\", \\\"{x:299,y:621,t:1527030389533};\\\", \\\"{x:296,y:619,t:1527030389551};\\\", \\\"{x:292,y:616,t:1527030389565};\\\", \\\"{x:291,y:614,t:1527030389582};\\\", \\\"{x:291,y:609,t:1527030389599};\\\", \\\"{x:290,y:604,t:1527030389616};\\\", \\\"{x:290,y:600,t:1527030389632};\\\", \\\"{x:290,y:594,t:1527030389648};\\\", \\\"{x:288,y:589,t:1527030389665};\\\", \\\"{x:288,y:587,t:1527030389682};\\\", \\\"{x:288,y:584,t:1527030389698};\\\", \\\"{x:287,y:583,t:1527030389716};\\\", \\\"{x:287,y:582,t:1527030389733};\\\", \\\"{x:287,y:581,t:1527030389749};\\\", \\\"{x:286,y:579,t:1527030389766};\\\", \\\"{x:286,y:578,t:1527030391466};\\\", \\\"{x:285,y:578,t:1527030391473};\\\", \\\"{x:285,y:579,t:1527030391851};\\\", \\\"{x:284,y:580,t:1527030391869};\\\", \\\"{x:283,y:580,t:1527030391885};\\\", \\\"{x:282,y:580,t:1527030391901};\\\", \\\"{x:282,y:581,t:1527030391918};\\\", \\\"{x:280,y:582,t:1527030391936};\\\", \\\"{x:279,y:583,t:1527030391950};\\\", \\\"{x:278,y:584,t:1527030391968};\\\", \\\"{x:277,y:586,t:1527030391985};\\\", \\\"{x:277,y:587,t:1527030392018};\\\", \\\"{x:276,y:588,t:1527030392035};\\\", \\\"{x:275,y:589,t:1527030392051};\\\", \\\"{x:275,y:590,t:1527030392068};\\\", \\\"{x:274,y:591,t:1527030392507};\\\", \\\"{x:273,y:593,t:1527030392546};\\\", \\\"{x:272,y:594,t:1527030392588};\\\", \\\"{x:272,y:595,t:1527030392609};\\\", \\\"{x:271,y:595,t:1527030392633};\\\", \\\"{x:271,y:596,t:1527030392697};\\\", \\\"{x:270,y:597,t:1527030392738};\\\", \\\"{x:270,y:598,t:1527030392761};\\\", \\\"{x:269,y:598,t:1527030393203};\\\", \\\"{x:268,y:599,t:1527030393219};\\\", \\\"{x:267,y:599,t:1527030393235};\\\", \\\"{x:265,y:600,t:1527030393252};\\\", \\\"{x:263,y:601,t:1527030393269};\\\", \\\"{x:262,y:602,t:1527030393285};\\\", \\\"{x:260,y:602,t:1527030393303};\\\", \\\"{x:257,y:603,t:1527030393320};\\\", \\\"{x:252,y:605,t:1527030393335};\\\", \\\"{x:248,y:607,t:1527030393353};\\\", \\\"{x:242,y:609,t:1527030393370};\\\", \\\"{x:236,y:610,t:1527030393386};\\\", \\\"{x:233,y:611,t:1527030393402};\\\", \\\"{x:229,y:612,t:1527030393419};\\\", \\\"{x:226,y:613,t:1527030393437};\\\", \\\"{x:223,y:613,t:1527030393452};\\\", \\\"{x:221,y:613,t:1527030393469};\\\", \\\"{x:219,y:614,t:1527030394275};\\\", \\\"{x:215,y:616,t:1527030394286};\\\", \\\"{x:207,y:617,t:1527030394304};\\\", \\\"{x:204,y:617,t:1527030394321};\\\", \\\"{x:199,y:617,t:1527030394336};\\\", \\\"{x:193,y:618,t:1527030394354};\\\", \\\"{x:187,y:618,t:1527030394370};\\\", \\\"{x:186,y:618,t:1527030394387};\\\", \\\"{x:185,y:618,t:1527030394546};\\\", \\\"{x:183,y:618,t:1527030394554};\\\", \\\"{x:177,y:612,t:1527030394572};\\\", \\\"{x:170,y:606,t:1527030394586};\\\", \\\"{x:164,y:598,t:1527030394603};\\\", \\\"{x:158,y:590,t:1527030394620};\\\", \\\"{x:154,y:584,t:1527030394637};\\\", \\\"{x:150,y:578,t:1527030394653};\\\", \\\"{x:146,y:574,t:1527030394670};\\\", \\\"{x:143,y:570,t:1527030394686};\\\", \\\"{x:139,y:568,t:1527030394702};\\\", \\\"{x:136,y:565,t:1527030394720};\\\", \\\"{x:135,y:562,t:1527030394736};\\\", \\\"{x:132,y:559,t:1527030394753};\\\", \\\"{x:132,y:557,t:1527030394770};\\\", \\\"{x:130,y:555,t:1527030394787};\\\", \\\"{x:128,y:552,t:1527030394803};\\\", \\\"{x:127,y:549,t:1527030394820};\\\", \\\"{x:126,y:547,t:1527030394837};\\\", \\\"{x:125,y:546,t:1527030394853};\\\", \\\"{x:125,y:544,t:1527030394869};\\\", \\\"{x:123,y:542,t:1527030394887};\\\", \\\"{x:123,y:541,t:1527030394903};\\\", \\\"{x:123,y:540,t:1527030394930};\\\", \\\"{x:122,y:539,t:1527030394937};\\\", \\\"{x:121,y:539,t:1527030396402};\\\", \\\"{x:120,y:539,t:1527030396409};\\\", \\\"{x:117,y:538,t:1527030396425};\\\", \\\"{x:114,y:537,t:1527030396442};\\\", \\\"{x:113,y:536,t:1527030396460};\\\", \\\"{x:111,y:536,t:1527030396475};\\\", \\\"{x:110,y:535,t:1527030396487};\\\", \\\"{x:108,y:534,t:1527030396505};\\\", \\\"{x:107,y:532,t:1527030396521};\\\", \\\"{x:107,y:530,t:1527030396538};\\\", \\\"{x:105,y:528,t:1527030396555};\\\", \\\"{x:102,y:524,t:1527030396572};\\\", \\\"{x:100,y:522,t:1527030396588};\\\", \\\"{x:99,y:514,t:1527030396606};\\\", \\\"{x:99,y:506,t:1527030396622};\\\", \\\"{x:99,y:498,t:1527030396639};\\\", \\\"{x:99,y:491,t:1527030396655};\\\", \\\"{x:99,y:486,t:1527030396672};\\\", \\\"{x:99,y:482,t:1527030396688};\\\", \\\"{x:103,y:476,t:1527030396705};\\\", \\\"{x:108,y:472,t:1527030396721};\\\", \\\"{x:109,y:470,t:1527030396738};\\\", \\\"{x:111,y:470,t:1527030396811};\\\", \\\"{x:113,y:470,t:1527030396823};\\\", \\\"{x:118,y:473,t:1527030396838};\\\", \\\"{x:121,y:477,t:1527030396855};\\\", \\\"{x:124,y:485,t:1527030396872};\\\", \\\"{x:129,y:495,t:1527030396889};\\\", \\\"{x:138,y:504,t:1527030396906};\\\", \\\"{x:150,y:515,t:1527030396923};\\\", \\\"{x:160,y:521,t:1527030396938};\\\", \\\"{x:168,y:527,t:1527030396955};\\\", \\\"{x:174,y:528,t:1527030396972};\\\", \\\"{x:180,y:531,t:1527030396988};\\\", \\\"{x:183,y:531,t:1527030397005};\\\", \\\"{x:185,y:531,t:1527030397021};\\\", \\\"{x:187,y:531,t:1527030397039};\\\", \\\"{x:188,y:531,t:1527030397055};\\\", \\\"{x:190,y:531,t:1527030397073};\\\", \\\"{x:191,y:531,t:1527030397089};\\\", \\\"{x:192,y:531,t:1527030397450};\\\", \\\"{x:193,y:531,t:1527030397458};\\\", \\\"{x:194,y:531,t:1527030397472};\\\", \\\"{x:202,y:528,t:1527030397489};\\\", \\\"{x:205,y:526,t:1527030397505};\\\", \\\"{x:218,y:523,t:1527030397522};\\\", \\\"{x:223,y:521,t:1527030397539};\\\", \\\"{x:227,y:521,t:1527030397555};\\\", \\\"{x:232,y:520,t:1527030397571};\\\", \\\"{x:237,y:519,t:1527030397589};\\\", \\\"{x:245,y:518,t:1527030397605};\\\", \\\"{x:250,y:518,t:1527030397622};\\\", \\\"{x:256,y:518,t:1527030397639};\\\", \\\"{x:262,y:518,t:1527030397655};\\\", \\\"{x:271,y:518,t:1527030397672};\\\", \\\"{x:280,y:517,t:1527030397691};\\\", \\\"{x:282,y:515,t:1527030397705};\\\", \\\"{x:290,y:515,t:1527030397722};\\\", \\\"{x:296,y:515,t:1527030397739};\\\", \\\"{x:301,y:515,t:1527030397756};\\\", \\\"{x:308,y:515,t:1527030397773};\\\", \\\"{x:311,y:515,t:1527030397791};\\\", \\\"{x:312,y:515,t:1527030397807};\\\", \\\"{x:313,y:515,t:1527030397841};\\\", \\\"{x:315,y:514,t:1527030397856};\\\", \\\"{x:316,y:513,t:1527030397872};\\\", \\\"{x:325,y:512,t:1527030397889};\\\", \\\"{x:334,y:511,t:1527030397906};\\\", \\\"{x:342,y:510,t:1527030397923};\\\", \\\"{x:351,y:510,t:1527030397939};\\\", \\\"{x:361,y:510,t:1527030397956};\\\", \\\"{x:369,y:510,t:1527030397973};\\\", \\\"{x:378,y:511,t:1527030397989};\\\", \\\"{x:384,y:512,t:1527030398006};\\\", \\\"{x:394,y:513,t:1527030398023};\\\", \\\"{x:404,y:516,t:1527030398040};\\\", \\\"{x:408,y:517,t:1527030398056};\\\", \\\"{x:410,y:518,t:1527030398073};\\\", \\\"{x:411,y:518,t:1527030398249};\\\", \\\"{x:411,y:519,t:1527030398257};\\\", \\\"{x:409,y:520,t:1527030398273};\\\", \\\"{x:408,y:520,t:1527030398289};\\\", \\\"{x:404,y:521,t:1527030398306};\\\", \\\"{x:402,y:521,t:1527030398323};\\\", \\\"{x:401,y:521,t:1527030399067};\\\", \\\"{x:402,y:523,t:1527030399074};\\\", \\\"{x:418,y:530,t:1527030399091};\\\", \\\"{x:438,y:536,t:1527030399107};\\\", \\\"{x:455,y:543,t:1527030399123};\\\", \\\"{x:478,y:550,t:1527030399141};\\\", \\\"{x:495,y:555,t:1527030399157};\\\", \\\"{x:515,y:560,t:1527030399173};\\\", \\\"{x:536,y:566,t:1527030399190};\\\", \\\"{x:560,y:573,t:1527030399206};\\\", \\\"{x:578,y:579,t:1527030399223};\\\", \\\"{x:600,y:585,t:1527030399240};\\\", \\\"{x:631,y:596,t:1527030399257};\\\", \\\"{x:648,y:600,t:1527030399273};\\\", \\\"{x:671,y:607,t:1527030399289};\\\", \\\"{x:695,y:614,t:1527030399307};\\\", \\\"{x:714,y:621,t:1527030399323};\\\", \\\"{x:741,y:631,t:1527030399341};\\\", \\\"{x:768,y:641,t:1527030399357};\\\", \\\"{x:795,y:649,t:1527030399374};\\\", \\\"{x:822,y:659,t:1527030399389};\\\", \\\"{x:851,y:668,t:1527030399407};\\\", \\\"{x:886,y:682,t:1527030399424};\\\", \\\"{x:919,y:697,t:1527030399440};\\\", \\\"{x:975,y:719,t:1527030399457};\\\", \\\"{x:1019,y:737,t:1527030399474};\\\", \\\"{x:1078,y:765,t:1527030399491};\\\", \\\"{x:1157,y:793,t:1527030399508};\\\", \\\"{x:1228,y:823,t:1527030399524};\\\", \\\"{x:1291,y:849,t:1527030399540};\\\", \\\"{x:1352,y:875,t:1527030399557};\\\", \\\"{x:1414,y:898,t:1527030399574};\\\", \\\"{x:1473,y:914,t:1527030399590};\\\", \\\"{x:1523,y:930,t:1527030399608};\\\", \\\"{x:1552,y:940,t:1527030399625};\\\", \\\"{x:1572,y:948,t:1527030399641};\\\", \\\"{x:1582,y:949,t:1527030399658};\\\", \\\"{x:1583,y:950,t:1527030400563};\\\", \\\"{x:1583,y:951,t:1527030400587};\\\", \\\"{x:1582,y:952,t:1527030400643};\\\", \\\"{x:1581,y:953,t:1527030400699};\\\", \\\"{x:1580,y:954,t:1527030400939};\\\", \\\"{x:1579,y:954,t:1527030400946};\\\", \\\"{x:1579,y:955,t:1527030400962};\\\", \\\"{x:1578,y:955,t:1527030400976};\\\", \\\"{x:1577,y:956,t:1527030400995};\\\", \\\"{x:1576,y:957,t:1527030401018};\\\", \\\"{x:1574,y:958,t:1527030401723};\\\", \\\"{x:1572,y:959,t:1527030401739};\\\", \\\"{x:1570,y:959,t:1527030401746};\\\", \\\"{x:1568,y:961,t:1527030401760};\\\", \\\"{x:1564,y:962,t:1527030401777};\\\", \\\"{x:1559,y:962,t:1527030401793};\\\", \\\"{x:1552,y:963,t:1527030401810};\\\", \\\"{x:1549,y:964,t:1527030401826};\\\", \\\"{x:1546,y:965,t:1527030401843};\\\", \\\"{x:1544,y:965,t:1527030401860};\\\", \\\"{x:1542,y:966,t:1527030401877};\\\", \\\"{x:1539,y:966,t:1527030401893};\\\", \\\"{x:1536,y:967,t:1527030401910};\\\", \\\"{x:1532,y:967,t:1527030401927};\\\", \\\"{x:1528,y:968,t:1527030401943};\\\", \\\"{x:1521,y:969,t:1527030401960};\\\", \\\"{x:1516,y:971,t:1527030401977};\\\", \\\"{x:1509,y:972,t:1527030401993};\\\", \\\"{x:1500,y:973,t:1527030402010};\\\", \\\"{x:1494,y:974,t:1527030402026};\\\", \\\"{x:1487,y:975,t:1527030402043};\\\", \\\"{x:1482,y:976,t:1527030402059};\\\", \\\"{x:1477,y:976,t:1527030402076};\\\", \\\"{x:1474,y:977,t:1527030402092};\\\", \\\"{x:1472,y:977,t:1527030402109};\\\", \\\"{x:1471,y:978,t:1527030402126};\\\", \\\"{x:1470,y:978,t:1527030402145};\\\", \\\"{x:1468,y:978,t:1527030402258};\\\", \\\"{x:1467,y:978,t:1527030402273};\\\", \\\"{x:1465,y:978,t:1527030402282};\\\", \\\"{x:1463,y:980,t:1527030402299};\\\", \\\"{x:1462,y:980,t:1527030402314};\\\", \\\"{x:1461,y:980,t:1527030402328};\\\", \\\"{x:1461,y:981,t:1527030402344};\\\", \\\"{x:1459,y:981,t:1527030402360};\\\", \\\"{x:1458,y:981,t:1527030402377};\\\", \\\"{x:1457,y:981,t:1527030402394};\\\", \\\"{x:1456,y:983,t:1527030402410};\\\", \\\"{x:1455,y:983,t:1527030402427};\\\", \\\"{x:1452,y:983,t:1527030402444};\\\", \\\"{x:1451,y:983,t:1527030402467};\\\", \\\"{x:1449,y:984,t:1527030402482};\\\", \\\"{x:1448,y:984,t:1527030402498};\\\", \\\"{x:1445,y:984,t:1527030402510};\\\", \\\"{x:1443,y:984,t:1527030402526};\\\", \\\"{x:1439,y:985,t:1527030402544};\\\", \\\"{x:1434,y:985,t:1527030402561};\\\", \\\"{x:1428,y:985,t:1527030402577};\\\", \\\"{x:1414,y:985,t:1527030402594};\\\", \\\"{x:1403,y:985,t:1527030402611};\\\", \\\"{x:1389,y:985,t:1527030402627};\\\", \\\"{x:1380,y:985,t:1527030402644};\\\", \\\"{x:1370,y:985,t:1527030402661};\\\", \\\"{x:1360,y:985,t:1527030402677};\\\", \\\"{x:1349,y:982,t:1527030402695};\\\", \\\"{x:1342,y:980,t:1527030402711};\\\", \\\"{x:1335,y:978,t:1527030402727};\\\", \\\"{x:1327,y:974,t:1527030402744};\\\", \\\"{x:1320,y:970,t:1527030402760};\\\", \\\"{x:1315,y:966,t:1527030402779};\\\", \\\"{x:1309,y:955,t:1527030402793};\\\", \\\"{x:1305,y:931,t:1527030402810};\\\", \\\"{x:1297,y:902,t:1527030402826};\\\", \\\"{x:1293,y:881,t:1527030402844};\\\", \\\"{x:1290,y:863,t:1527030402861};\\\", \\\"{x:1289,y:853,t:1527030402876};\\\", \\\"{x:1285,y:841,t:1527030402893};\\\", \\\"{x:1282,y:834,t:1527030402911};\\\", \\\"{x:1280,y:831,t:1527030402926};\\\", \\\"{x:1278,y:826,t:1527030402943};\\\", \\\"{x:1271,y:817,t:1527030402961};\\\", \\\"{x:1261,y:804,t:1527030402977};\\\", \\\"{x:1257,y:797,t:1527030402994};\\\", \\\"{x:1255,y:795,t:1527030403010};\\\", \\\"{x:1254,y:795,t:1527030403028};\\\", \\\"{x:1253,y:795,t:1527030403123};\\\", \\\"{x:1253,y:798,t:1527030403130};\\\", \\\"{x:1253,y:802,t:1527030403144};\\\", \\\"{x:1254,y:815,t:1527030403161};\\\", \\\"{x:1261,y:829,t:1527030403178};\\\", \\\"{x:1262,y:835,t:1527030403194};\\\", \\\"{x:1264,y:838,t:1527030403211};\\\", \\\"{x:1264,y:840,t:1527030403228};\\\", \\\"{x:1266,y:843,t:1527030403244};\\\", \\\"{x:1266,y:844,t:1527030403267};\\\", \\\"{x:1267,y:844,t:1527030403278};\\\", \\\"{x:1267,y:845,t:1527030403294};\\\", \\\"{x:1268,y:845,t:1527030403315};\\\", \\\"{x:1269,y:845,t:1527030403363};\\\", \\\"{x:1275,y:845,t:1527030403378};\\\", \\\"{x:1282,y:841,t:1527030403394};\\\", \\\"{x:1286,y:839,t:1527030403411};\\\", \\\"{x:1289,y:837,t:1527030403428};\\\", \\\"{x:1294,y:833,t:1527030403445};\\\", \\\"{x:1294,y:832,t:1527030403461};\\\", \\\"{x:1295,y:832,t:1527030403478};\\\", \\\"{x:1296,y:831,t:1527030403514};\\\", \\\"{x:1296,y:830,t:1527030404395};\\\", \\\"{x:1295,y:830,t:1527030404450};\\\", \\\"{x:1294,y:830,t:1527030404474};\\\", \\\"{x:1293,y:830,t:1527030404498};\\\", \\\"{x:1292,y:830,t:1527030404512};\\\", \\\"{x:1291,y:831,t:1527030404577};\\\", \\\"{x:1290,y:831,t:1527030404633};\\\", \\\"{x:1289,y:832,t:1527030404778};\\\", \\\"{x:1288,y:832,t:1527030406322};\\\", \\\"{x:1283,y:835,t:1527030406329};\\\", \\\"{x:1272,y:842,t:1527030406347};\\\", \\\"{x:1266,y:844,t:1527030406363};\\\", \\\"{x:1263,y:844,t:1527030406379};\\\", \\\"{x:1262,y:844,t:1527030406396};\\\", \\\"{x:1259,y:840,t:1527030406413};\\\", \\\"{x:1256,y:830,t:1527030406429};\\\", \\\"{x:1254,y:825,t:1527030406448};\\\", \\\"{x:1253,y:824,t:1527030407122};\\\", \\\"{x:1252,y:824,t:1527030407131};\\\", \\\"{x:1249,y:826,t:1527030407148};\\\", \\\"{x:1247,y:830,t:1527030407164};\\\", \\\"{x:1244,y:833,t:1527030407181};\\\", \\\"{x:1242,y:836,t:1527030407198};\\\", \\\"{x:1239,y:839,t:1527030407214};\\\", \\\"{x:1237,y:841,t:1527030407231};\\\", \\\"{x:1236,y:843,t:1527030407248};\\\", \\\"{x:1235,y:845,t:1527030407264};\\\", \\\"{x:1234,y:847,t:1527030407281};\\\", \\\"{x:1233,y:848,t:1527030407298};\\\", \\\"{x:1233,y:849,t:1527030407315};\\\", \\\"{x:1231,y:851,t:1527030407338};\\\", \\\"{x:1230,y:851,t:1527030410842};\\\", \\\"{x:1228,y:851,t:1527030410851};\\\", \\\"{x:1223,y:856,t:1527030410867};\\\", \\\"{x:1216,y:864,t:1527030410884};\\\", \\\"{x:1207,y:875,t:1527030410901};\\\", \\\"{x:1199,y:884,t:1527030410918};\\\", \\\"{x:1187,y:896,t:1527030410934};\\\", \\\"{x:1179,y:902,t:1527030410951};\\\", \\\"{x:1172,y:909,t:1527030410967};\\\", \\\"{x:1167,y:912,t:1527030410984};\\\", \\\"{x:1164,y:914,t:1527030411002};\\\", \\\"{x:1163,y:915,t:1527030411017};\\\", \\\"{x:1162,y:915,t:1527030411066};\\\", \\\"{x:1161,y:915,t:1527030411084};\\\", \\\"{x:1158,y:917,t:1527030411101};\\\", \\\"{x:1153,y:919,t:1527030411117};\\\", \\\"{x:1150,y:921,t:1527030411134};\\\", \\\"{x:1144,y:923,t:1527030411151};\\\", \\\"{x:1136,y:926,t:1527030411169};\\\", \\\"{x:1128,y:927,t:1527030411185};\\\", \\\"{x:1115,y:928,t:1527030411201};\\\", \\\"{x:1098,y:931,t:1527030411218};\\\", \\\"{x:1089,y:931,t:1527030411234};\\\", \\\"{x:1083,y:931,t:1527030411251};\\\", \\\"{x:1080,y:931,t:1527030411268};\\\", \\\"{x:1075,y:930,t:1527030411284};\\\", \\\"{x:1071,y:929,t:1527030411301};\\\", \\\"{x:1067,y:926,t:1527030411318};\\\", \\\"{x:1061,y:922,t:1527030411334};\\\", \\\"{x:1056,y:918,t:1527030411350};\\\", \\\"{x:1050,y:911,t:1527030411368};\\\", \\\"{x:1042,y:903,t:1527030411383};\\\", \\\"{x:1031,y:890,t:1527030411400};\\\", \\\"{x:1013,y:873,t:1527030411418};\\\", \\\"{x:1000,y:860,t:1527030411434};\\\", \\\"{x:987,y:849,t:1527030411450};\\\", \\\"{x:980,y:840,t:1527030411468};\\\", \\\"{x:974,y:834,t:1527030411483};\\\", \\\"{x:968,y:826,t:1527030411500};\\\", \\\"{x:961,y:819,t:1527030411517};\\\", \\\"{x:949,y:806,t:1527030411535};\\\", \\\"{x:939,y:796,t:1527030411550};\\\", \\\"{x:929,y:789,t:1527030411567};\\\", \\\"{x:925,y:786,t:1527030411584};\\\", \\\"{x:923,y:784,t:1527030411601};\\\", \\\"{x:919,y:783,t:1527030411617};\\\", \\\"{x:917,y:781,t:1527030411635};\\\", \\\"{x:913,y:779,t:1527030411651};\\\", \\\"{x:912,y:778,t:1527030411668};\\\", \\\"{x:910,y:777,t:1527030411685};\\\", \\\"{x:906,y:775,t:1527030411701};\\\", \\\"{x:902,y:774,t:1527030411718};\\\", \\\"{x:893,y:772,t:1527030411735};\\\", \\\"{x:887,y:770,t:1527030411751};\\\", \\\"{x:880,y:767,t:1527030411768};\\\", \\\"{x:873,y:766,t:1527030411785};\\\", \\\"{x:869,y:763,t:1527030411801};\\\", \\\"{x:862,y:762,t:1527030411818};\\\", \\\"{x:857,y:761,t:1527030411835};\\\", \\\"{x:854,y:760,t:1527030411851};\\\", \\\"{x:850,y:760,t:1527030411868};\\\", \\\"{x:847,y:759,t:1527030411885};\\\", \\\"{x:845,y:759,t:1527030411900};\\\", \\\"{x:842,y:758,t:1527030411918};\\\", \\\"{x:841,y:758,t:1527030411935};\\\", \\\"{x:839,y:758,t:1527030411951};\\\", \\\"{x:837,y:758,t:1527030411968};\\\", \\\"{x:834,y:758,t:1527030411986};\\\", \\\"{x:832,y:758,t:1527030412001};\\\", \\\"{x:829,y:758,t:1527030412018};\\\", \\\"{x:828,y:758,t:1527030412035};\\\", \\\"{x:825,y:758,t:1527030412052};\\\", \\\"{x:820,y:758,t:1527030412068};\\\", \\\"{x:814,y:758,t:1527030412085};\\\", \\\"{x:807,y:756,t:1527030412102};\\\", \\\"{x:800,y:755,t:1527030412118};\\\", \\\"{x:793,y:754,t:1527030412135};\\\", \\\"{x:783,y:753,t:1527030412152};\\\", \\\"{x:769,y:750,t:1527030412169};\\\", \\\"{x:749,y:745,t:1527030412186};\\\", \\\"{x:721,y:738,t:1527030412201};\\\", \\\"{x:701,y:733,t:1527030412218};\\\", \\\"{x:680,y:729,t:1527030412235};\\\", \\\"{x:660,y:726,t:1527030412252};\\\", \\\"{x:636,y:720,t:1527030412268};\\\", \\\"{x:610,y:717,t:1527030412285};\\\", \\\"{x:586,y:713,t:1527030412302};\\\", \\\"{x:567,y:710,t:1527030412318};\\\", \\\"{x:555,y:709,t:1527030412337};\\\", \\\"{x:547,y:708,t:1527030412352};\\\", \\\"{x:540,y:707,t:1527030412369};\\\", \\\"{x:538,y:706,t:1527030412384};\\\", \\\"{x:537,y:706,t:1527030412489};\\\", \\\"{x:536,y:706,t:1527030412500};\\\" ] }, { \\\"rt\\\": 30931, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 6, \\\"time_elapsed\\\": 201498, \\\"internal_node_id\\\": \\\"0.0-5.0-1.0\\\", \\\"subject\\\": \\\"E5L6P\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 2, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-U -D -04 PM-04 PM-04 PM-I \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:541,y:706,t:1527030415434};\\\", \\\"{x:548,y:706,t:1527030415441};\\\", \\\"{x:553,y:706,t:1527030415454};\\\", \\\"{x:564,y:706,t:1527030415470};\\\", \\\"{x:575,y:706,t:1527030415489};\\\", \\\"{x:583,y:706,t:1527030415504};\\\", \\\"{x:589,y:707,t:1527030415521};\\\", \\\"{x:599,y:708,t:1527030415537};\\\", \\\"{x:609,y:709,t:1527030415553};\\\", \\\"{x:610,y:709,t:1527030415570};\\\", \\\"{x:612,y:709,t:1527030415587};\\\", \\\"{x:613,y:709,t:1527030415610};\\\", \\\"{x:615,y:709,t:1527030415722};\\\", \\\"{x:616,y:709,t:1527030415738};\\\", \\\"{x:618,y:709,t:1527030415754};\\\", \\\"{x:620,y:709,t:1527030415770};\\\", \\\"{x:622,y:709,t:1527030415787};\\\", \\\"{x:623,y:709,t:1527030415804};\\\", \\\"{x:624,y:709,t:1527030415820};\\\", \\\"{x:625,y:709,t:1527030415837};\\\", \\\"{x:626,y:708,t:1527030415858};\\\", \\\"{x:627,y:708,t:1527030415882};\\\", \\\"{x:628,y:708,t:1527030415954};\\\", \\\"{x:629,y:708,t:1527030415977};\\\", \\\"{x:630,y:708,t:1527030415994};\\\", \\\"{x:631,y:707,t:1527030416004};\\\", \\\"{x:632,y:707,t:1527030416033};\\\", \\\"{x:633,y:707,t:1527030416041};\\\", \\\"{x:634,y:707,t:1527030416054};\\\", \\\"{x:635,y:706,t:1527030416082};\\\", \\\"{x:636,y:706,t:1527030416105};\\\", \\\"{x:637,y:706,t:1527030416121};\\\", \\\"{x:638,y:705,t:1527030416137};\\\", \\\"{x:641,y:704,t:1527030416154};\\\", \\\"{x:643,y:704,t:1527030416171};\\\", \\\"{x:644,y:704,t:1527030416187};\\\", \\\"{x:647,y:703,t:1527030416204};\\\", \\\"{x:650,y:702,t:1527030416221};\\\", \\\"{x:652,y:701,t:1527030416236};\\\", \\\"{x:654,y:701,t:1527030416254};\\\", \\\"{x:658,y:701,t:1527030416270};\\\", \\\"{x:660,y:700,t:1527030416286};\\\", \\\"{x:664,y:699,t:1527030416304};\\\", \\\"{x:668,y:698,t:1527030416321};\\\", \\\"{x:670,y:697,t:1527030416337};\\\", \\\"{x:674,y:697,t:1527030416354};\\\", \\\"{x:677,y:697,t:1527030416371};\\\", \\\"{x:680,y:697,t:1527030416387};\\\", \\\"{x:684,y:697,t:1527030416403};\\\", \\\"{x:689,y:696,t:1527030416421};\\\", \\\"{x:692,y:696,t:1527030416438};\\\", \\\"{x:695,y:695,t:1527030416454};\\\", \\\"{x:696,y:695,t:1527030416470};\\\", \\\"{x:699,y:694,t:1527030416487};\\\", \\\"{x:701,y:694,t:1527030416505};\\\", \\\"{x:702,y:694,t:1527030416529};\\\", \\\"{x:705,y:693,t:1527030416545};\\\", \\\"{x:706,y:693,t:1527030416569};\\\", \\\"{x:707,y:693,t:1527030416585};\\\", \\\"{x:708,y:693,t:1527030416593};\\\", \\\"{x:709,y:693,t:1527030416604};\\\", \\\"{x:711,y:693,t:1527030416621};\\\", \\\"{x:715,y:693,t:1527030416638};\\\", \\\"{x:718,y:691,t:1527030416654};\\\", \\\"{x:722,y:691,t:1527030416670};\\\", \\\"{x:726,y:690,t:1527030416688};\\\", \\\"{x:730,y:690,t:1527030416704};\\\", \\\"{x:734,y:690,t:1527030416721};\\\", \\\"{x:736,y:690,t:1527030416738};\\\", \\\"{x:740,y:690,t:1527030416754};\\\", \\\"{x:742,y:690,t:1527030416771};\\\", \\\"{x:743,y:690,t:1527030417186};\\\", \\\"{x:746,y:690,t:1527030417194};\\\", \\\"{x:750,y:690,t:1527030417205};\\\", \\\"{x:759,y:685,t:1527030417221};\\\", \\\"{x:770,y:680,t:1527030417238};\\\", \\\"{x:780,y:675,t:1527030417255};\\\", \\\"{x:791,y:672,t:1527030417271};\\\", \\\"{x:803,y:669,t:1527030417288};\\\", \\\"{x:815,y:667,t:1527030417305};\\\", \\\"{x:818,y:666,t:1527030417321};\\\", \\\"{x:819,y:665,t:1527030417338};\\\", \\\"{x:820,y:665,t:1527030417386};\\\", \\\"{x:821,y:665,t:1527030417402};\\\", \\\"{x:822,y:665,t:1527030417409};\\\", \\\"{x:823,y:664,t:1527030417426};\\\", \\\"{x:824,y:663,t:1527030417441};\\\", \\\"{x:825,y:662,t:1527030417455};\\\", \\\"{x:828,y:660,t:1527030417472};\\\", \\\"{x:832,y:659,t:1527030417488};\\\", \\\"{x:835,y:657,t:1527030417506};\\\", \\\"{x:836,y:656,t:1527030417522};\\\", \\\"{x:839,y:656,t:1527030417538};\\\", \\\"{x:840,y:655,t:1527030417555};\\\", \\\"{x:842,y:654,t:1527030417572};\\\", \\\"{x:844,y:654,t:1527030417588};\\\", \\\"{x:846,y:652,t:1527030417605};\\\", \\\"{x:850,y:651,t:1527030417622};\\\", \\\"{x:853,y:650,t:1527030417637};\\\", \\\"{x:857,y:649,t:1527030417655};\\\", \\\"{x:860,y:649,t:1527030417672};\\\", \\\"{x:869,y:648,t:1527030417687};\\\", \\\"{x:885,y:646,t:1527030417705};\\\", \\\"{x:897,y:646,t:1527030417722};\\\", \\\"{x:912,y:646,t:1527030417739};\\\", \\\"{x:930,y:646,t:1527030417754};\\\", \\\"{x:942,y:646,t:1527030417772};\\\", \\\"{x:956,y:646,t:1527030417788};\\\", \\\"{x:971,y:646,t:1527030417804};\\\", \\\"{x:992,y:646,t:1527030417822};\\\", \\\"{x:1012,y:646,t:1527030417839};\\\", \\\"{x:1031,y:646,t:1527030417855};\\\", \\\"{x:1050,y:646,t:1527030417872};\\\", \\\"{x:1084,y:646,t:1527030417889};\\\", \\\"{x:1111,y:646,t:1527030417905};\\\", \\\"{x:1140,y:646,t:1527030417921};\\\", \\\"{x:1172,y:653,t:1527030417939};\\\", \\\"{x:1202,y:656,t:1527030417955};\\\", \\\"{x:1226,y:662,t:1527030417972};\\\", \\\"{x:1257,y:671,t:1527030417989};\\\", \\\"{x:1293,y:680,t:1527030418005};\\\", \\\"{x:1335,y:693,t:1527030418022};\\\", \\\"{x:1368,y:702,t:1527030418039};\\\", \\\"{x:1403,y:712,t:1527030418055};\\\", \\\"{x:1431,y:720,t:1527030418072};\\\", \\\"{x:1459,y:728,t:1527030418090};\\\", \\\"{x:1464,y:730,t:1527030418106};\\\", \\\"{x:1465,y:730,t:1527030418122};\\\", \\\"{x:1466,y:730,t:1527030418139};\\\", \\\"{x:1466,y:731,t:1527030418185};\\\", \\\"{x:1466,y:732,t:1527030418201};\\\", \\\"{x:1466,y:733,t:1527030418225};\\\", \\\"{x:1464,y:733,t:1527030418248};\\\", \\\"{x:1463,y:733,t:1527030418273};\\\", \\\"{x:1460,y:733,t:1527030418289};\\\", \\\"{x:1456,y:733,t:1527030418305};\\\", \\\"{x:1453,y:733,t:1527030418322};\\\", \\\"{x:1448,y:732,t:1527030418339};\\\", \\\"{x:1445,y:731,t:1527030418356};\\\", \\\"{x:1442,y:731,t:1527030418372};\\\", \\\"{x:1441,y:731,t:1527030418389};\\\", \\\"{x:1438,y:731,t:1527030418406};\\\", \\\"{x:1436,y:731,t:1527030418422};\\\", \\\"{x:1435,y:731,t:1527030418439};\\\", \\\"{x:1433,y:731,t:1527030418456};\\\", \\\"{x:1432,y:731,t:1527030418571};\\\", \\\"{x:1432,y:732,t:1527030418585};\\\", \\\"{x:1432,y:735,t:1527030418594};\\\", \\\"{x:1432,y:738,t:1527030418607};\\\", \\\"{x:1433,y:743,t:1527030418622};\\\", \\\"{x:1437,y:751,t:1527030418639};\\\", \\\"{x:1440,y:756,t:1527030418656};\\\", \\\"{x:1443,y:759,t:1527030418673};\\\", \\\"{x:1446,y:762,t:1527030418689};\\\", \\\"{x:1449,y:764,t:1527030418706};\\\", \\\"{x:1451,y:764,t:1527030418723};\\\", \\\"{x:1452,y:766,t:1527030418739};\\\", \\\"{x:1454,y:766,t:1527030418842};\\\", \\\"{x:1455,y:767,t:1527030418856};\\\", \\\"{x:1456,y:768,t:1527030418873};\\\", \\\"{x:1457,y:769,t:1527030418890};\\\", \\\"{x:1458,y:771,t:1527030418906};\\\", \\\"{x:1459,y:774,t:1527030418923};\\\", \\\"{x:1460,y:778,t:1527030418940};\\\", \\\"{x:1462,y:785,t:1527030418956};\\\", \\\"{x:1465,y:792,t:1527030418973};\\\", \\\"{x:1468,y:798,t:1527030418989};\\\", \\\"{x:1471,y:807,t:1527030419006};\\\", \\\"{x:1472,y:813,t:1527030419024};\\\", \\\"{x:1473,y:819,t:1527030419040};\\\", \\\"{x:1476,y:827,t:1527030419059};\\\", \\\"{x:1478,y:837,t:1527030419073};\\\", \\\"{x:1479,y:843,t:1527030419089};\\\", \\\"{x:1481,y:850,t:1527030419106};\\\", \\\"{x:1483,y:855,t:1527030419122};\\\", \\\"{x:1483,y:858,t:1527030419140};\\\", \\\"{x:1483,y:861,t:1527030419155};\\\", \\\"{x:1484,y:866,t:1527030419173};\\\", \\\"{x:1484,y:867,t:1527030419190};\\\", \\\"{x:1484,y:869,t:1527030419205};\\\", \\\"{x:1484,y:871,t:1527030419223};\\\", \\\"{x:1484,y:872,t:1527030419240};\\\", \\\"{x:1484,y:873,t:1527030419265};\\\", \\\"{x:1484,y:874,t:1527030419273};\\\", \\\"{x:1484,y:875,t:1527030419490};\\\", \\\"{x:1483,y:876,t:1527030419522};\\\", \\\"{x:1482,y:877,t:1527030419691};\\\", \\\"{x:1480,y:878,t:1527030419707};\\\", \\\"{x:1477,y:881,t:1527030419723};\\\", \\\"{x:1472,y:884,t:1527030419740};\\\", \\\"{x:1469,y:887,t:1527030419757};\\\", \\\"{x:1466,y:890,t:1527030419773};\\\", \\\"{x:1463,y:892,t:1527030419790};\\\", \\\"{x:1461,y:893,t:1527030419807};\\\", \\\"{x:1460,y:895,t:1527030419823};\\\", \\\"{x:1459,y:896,t:1527030419842};\\\", \\\"{x:1458,y:897,t:1527030419857};\\\", \\\"{x:1457,y:899,t:1527030419873};\\\", \\\"{x:1456,y:900,t:1527030419890};\\\", \\\"{x:1456,y:901,t:1527030419907};\\\", \\\"{x:1456,y:902,t:1527030419954};\\\", \\\"{x:1456,y:903,t:1527030420130};\\\", \\\"{x:1456,y:904,t:1527030420141};\\\", \\\"{x:1456,y:905,t:1527030420157};\\\", \\\"{x:1454,y:907,t:1527030420175};\\\", \\\"{x:1453,y:909,t:1527030420190};\\\", \\\"{x:1452,y:910,t:1527030420208};\\\", \\\"{x:1451,y:912,t:1527030420224};\\\", \\\"{x:1449,y:913,t:1527030420239};\\\", \\\"{x:1447,y:916,t:1527030420257};\\\", \\\"{x:1446,y:917,t:1527030420273};\\\", \\\"{x:1444,y:920,t:1527030420290};\\\", \\\"{x:1442,y:924,t:1527030420307};\\\", \\\"{x:1438,y:929,t:1527030420324};\\\", \\\"{x:1435,y:931,t:1527030420340};\\\", \\\"{x:1434,y:935,t:1527030420356};\\\", \\\"{x:1433,y:936,t:1527030420373};\\\", \\\"{x:1432,y:937,t:1527030420389};\\\", \\\"{x:1431,y:937,t:1527030420406};\\\", \\\"{x:1430,y:939,t:1527030420423};\\\", \\\"{x:1429,y:942,t:1527030420440};\\\", \\\"{x:1427,y:945,t:1527030420457};\\\", \\\"{x:1426,y:947,t:1527030420474};\\\", \\\"{x:1424,y:948,t:1527030420490};\\\", \\\"{x:1423,y:949,t:1527030420507};\\\", \\\"{x:1422,y:950,t:1527030420524};\\\", \\\"{x:1421,y:952,t:1527030420540};\\\", \\\"{x:1420,y:952,t:1527030420557};\\\", \\\"{x:1420,y:953,t:1527030420585};\\\", \\\"{x:1419,y:953,t:1527030420609};\\\", \\\"{x:1419,y:954,t:1527030420690};\\\", \\\"{x:1418,y:954,t:1527030420730};\\\", \\\"{x:1418,y:955,t:1527030420745};\\\", \\\"{x:1417,y:956,t:1527030421554};\\\", \\\"{x:1417,y:957,t:1527030421570};\\\", \\\"{x:1416,y:957,t:1527030421578};\\\", \\\"{x:1415,y:957,t:1527030421594};\\\", \\\"{x:1415,y:958,t:1527030421609};\\\", \\\"{x:1414,y:958,t:1527030421625};\\\", \\\"{x:1413,y:959,t:1527030421665};\\\", \\\"{x:1412,y:959,t:1527030423098};\\\", \\\"{x:1411,y:959,t:1527030423110};\\\", \\\"{x:1409,y:959,t:1527030423130};\\\", \\\"{x:1408,y:960,t:1527030423143};\\\", \\\"{x:1407,y:960,t:1527030423159};\\\", \\\"{x:1406,y:960,t:1527030423176};\\\", \\\"{x:1404,y:960,t:1527030423193};\\\", \\\"{x:1404,y:959,t:1527030424086};\\\", \\\"{x:1406,y:957,t:1527030424097};\\\", \\\"{x:1407,y:955,t:1527030424114};\\\", \\\"{x:1409,y:952,t:1527030424129};\\\", \\\"{x:1410,y:950,t:1527030424147};\\\", \\\"{x:1411,y:948,t:1527030424164};\\\", \\\"{x:1412,y:947,t:1527030424180};\\\", \\\"{x:1414,y:943,t:1527030424196};\\\", \\\"{x:1416,y:941,t:1527030424213};\\\", \\\"{x:1419,y:936,t:1527030424230};\\\", \\\"{x:1422,y:932,t:1527030424247};\\\", \\\"{x:1424,y:929,t:1527030424264};\\\", \\\"{x:1426,y:924,t:1527030424280};\\\", \\\"{x:1430,y:918,t:1527030424297};\\\", \\\"{x:1435,y:912,t:1527030424314};\\\", \\\"{x:1439,y:904,t:1527030424330};\\\", \\\"{x:1444,y:898,t:1527030424347};\\\", \\\"{x:1447,y:892,t:1527030424363};\\\", \\\"{x:1450,y:885,t:1527030424380};\\\", \\\"{x:1453,y:876,t:1527030424396};\\\", \\\"{x:1455,y:871,t:1527030424414};\\\", \\\"{x:1456,y:865,t:1527030424431};\\\", \\\"{x:1458,y:860,t:1527030424447};\\\", \\\"{x:1459,y:854,t:1527030424463};\\\", \\\"{x:1460,y:851,t:1527030424481};\\\", \\\"{x:1461,y:846,t:1527030424497};\\\", \\\"{x:1463,y:842,t:1527030424514};\\\", \\\"{x:1464,y:837,t:1527030424531};\\\", \\\"{x:1466,y:829,t:1527030424547};\\\", \\\"{x:1467,y:824,t:1527030424564};\\\", \\\"{x:1472,y:813,t:1527030424580};\\\", \\\"{x:1474,y:802,t:1527030424596};\\\", \\\"{x:1478,y:792,t:1527030424614};\\\", \\\"{x:1483,y:777,t:1527030424631};\\\", \\\"{x:1488,y:763,t:1527030424647};\\\", \\\"{x:1495,y:746,t:1527030424664};\\\", \\\"{x:1504,y:730,t:1527030424681};\\\", \\\"{x:1515,y:711,t:1527030424697};\\\", \\\"{x:1526,y:693,t:1527030424714};\\\", \\\"{x:1534,y:674,t:1527030424731};\\\", \\\"{x:1542,y:656,t:1527030424747};\\\", \\\"{x:1549,y:636,t:1527030424763};\\\", \\\"{x:1559,y:605,t:1527030424780};\\\", \\\"{x:1567,y:584,t:1527030424797};\\\", \\\"{x:1572,y:568,t:1527030424814};\\\", \\\"{x:1577,y:552,t:1527030424831};\\\", \\\"{x:1580,y:537,t:1527030424847};\\\", \\\"{x:1582,y:521,t:1527030424864};\\\", \\\"{x:1585,y:508,t:1527030424880};\\\", \\\"{x:1586,y:498,t:1527030424897};\\\", \\\"{x:1589,y:488,t:1527030424914};\\\", \\\"{x:1590,y:477,t:1527030424931};\\\", \\\"{x:1591,y:468,t:1527030424948};\\\", \\\"{x:1593,y:456,t:1527030424964};\\\", \\\"{x:1594,y:439,t:1527030424981};\\\", \\\"{x:1595,y:428,t:1527030424998};\\\", \\\"{x:1599,y:419,t:1527030425014};\\\", \\\"{x:1603,y:410,t:1527030425031};\\\", \\\"{x:1605,y:403,t:1527030425048};\\\", \\\"{x:1609,y:398,t:1527030425064};\\\", \\\"{x:1612,y:392,t:1527030425081};\\\", \\\"{x:1615,y:386,t:1527030425098};\\\", \\\"{x:1617,y:383,t:1527030425114};\\\", \\\"{x:1620,y:378,t:1527030425132};\\\", \\\"{x:1622,y:376,t:1527030425148};\\\", \\\"{x:1622,y:375,t:1527030425165};\\\", \\\"{x:1623,y:375,t:1527030425213};\\\", \\\"{x:1624,y:381,t:1527030425231};\\\", \\\"{x:1626,y:389,t:1527030425248};\\\", \\\"{x:1626,y:400,t:1527030425264};\\\", \\\"{x:1626,y:412,t:1527030425281};\\\", \\\"{x:1626,y:424,t:1527030425299};\\\", \\\"{x:1626,y:437,t:1527030425314};\\\", \\\"{x:1626,y:447,t:1527030425331};\\\", \\\"{x:1626,y:454,t:1527030425348};\\\", \\\"{x:1625,y:459,t:1527030425365};\\\", \\\"{x:1625,y:460,t:1527030425381};\\\", \\\"{x:1625,y:459,t:1527030425580};\\\", \\\"{x:1624,y:456,t:1527030425598};\\\", \\\"{x:1623,y:455,t:1527030425614};\\\", \\\"{x:1623,y:453,t:1527030425631};\\\", \\\"{x:1622,y:451,t:1527030425648};\\\", \\\"{x:1620,y:448,t:1527030425665};\\\", \\\"{x:1620,y:447,t:1527030425681};\\\", \\\"{x:1620,y:446,t:1527030425698};\\\", \\\"{x:1620,y:444,t:1527030425715};\\\", \\\"{x:1619,y:441,t:1527030425730};\\\", \\\"{x:1618,y:438,t:1527030425748};\\\", \\\"{x:1617,y:433,t:1527030425765};\\\", \\\"{x:1616,y:430,t:1527030425781};\\\", \\\"{x:1616,y:429,t:1527030425798};\\\", \\\"{x:1615,y:427,t:1527030425815};\\\", \\\"{x:1615,y:426,t:1527030425831};\\\", \\\"{x:1614,y:426,t:1527030426006};\\\", \\\"{x:1613,y:426,t:1527030426029};\\\", \\\"{x:1612,y:427,t:1527030426077};\\\", \\\"{x:1612,y:429,t:1527030426653};\\\", \\\"{x:1612,y:430,t:1527030426665};\\\", \\\"{x:1613,y:436,t:1527030426684};\\\", \\\"{x:1614,y:442,t:1527030426700};\\\", \\\"{x:1615,y:451,t:1527030426715};\\\", \\\"{x:1618,y:465,t:1527030426732};\\\", \\\"{x:1625,y:487,t:1527030426749};\\\", \\\"{x:1630,y:500,t:1527030426766};\\\", \\\"{x:1636,y:511,t:1527030426782};\\\", \\\"{x:1640,y:519,t:1527030426799};\\\", \\\"{x:1643,y:527,t:1527030426815};\\\", \\\"{x:1646,y:537,t:1527030426833};\\\", \\\"{x:1649,y:546,t:1527030426849};\\\", \\\"{x:1651,y:554,t:1527030426866};\\\", \\\"{x:1652,y:559,t:1527030426882};\\\", \\\"{x:1652,y:563,t:1527030426900};\\\", \\\"{x:1652,y:567,t:1527030426917};\\\", \\\"{x:1652,y:569,t:1527030426932};\\\", \\\"{x:1652,y:574,t:1527030426949};\\\", \\\"{x:1652,y:577,t:1527030426966};\\\", \\\"{x:1652,y:580,t:1527030426983};\\\", \\\"{x:1652,y:582,t:1527030427000};\\\", \\\"{x:1652,y:586,t:1527030427016};\\\", \\\"{x:1652,y:589,t:1527030427033};\\\", \\\"{x:1650,y:592,t:1527030427050};\\\", \\\"{x:1650,y:597,t:1527030427066};\\\", \\\"{x:1648,y:599,t:1527030427083};\\\", \\\"{x:1648,y:603,t:1527030427099};\\\", \\\"{x:1645,y:611,t:1527030427119};\\\", \\\"{x:1645,y:613,t:1527030427132};\\\", \\\"{x:1641,y:621,t:1527030427150};\\\", \\\"{x:1640,y:627,t:1527030427167};\\\", \\\"{x:1637,y:637,t:1527030427183};\\\", \\\"{x:1634,y:648,t:1527030427200};\\\", \\\"{x:1632,y:655,t:1527030427216};\\\", \\\"{x:1630,y:664,t:1527030427233};\\\", \\\"{x:1627,y:673,t:1527030427250};\\\", \\\"{x:1624,y:680,t:1527030427266};\\\", \\\"{x:1624,y:685,t:1527030427284};\\\", \\\"{x:1622,y:690,t:1527030427300};\\\", \\\"{x:1621,y:697,t:1527030427317};\\\", \\\"{x:1620,y:700,t:1527030427333};\\\", \\\"{x:1620,y:703,t:1527030427349};\\\", \\\"{x:1619,y:704,t:1527030427366};\\\", \\\"{x:1619,y:706,t:1527030427383};\\\", \\\"{x:1619,y:707,t:1527030427413};\\\", \\\"{x:1619,y:708,t:1527030427421};\\\", \\\"{x:1619,y:709,t:1527030427434};\\\", \\\"{x:1618,y:709,t:1527030427449};\\\", \\\"{x:1618,y:710,t:1527030427466};\\\", \\\"{x:1618,y:713,t:1527030427484};\\\", \\\"{x:1617,y:715,t:1527030427500};\\\", \\\"{x:1617,y:719,t:1527030427517};\\\", \\\"{x:1616,y:722,t:1527030427533};\\\", \\\"{x:1616,y:727,t:1527030427550};\\\", \\\"{x:1616,y:733,t:1527030427566};\\\", \\\"{x:1616,y:740,t:1527030427583};\\\", \\\"{x:1615,y:746,t:1527030427599};\\\", \\\"{x:1615,y:751,t:1527030427616};\\\", \\\"{x:1615,y:753,t:1527030427633};\\\", \\\"{x:1615,y:755,t:1527030427649};\\\", \\\"{x:1615,y:756,t:1527030427666};\\\", \\\"{x:1615,y:758,t:1527030427693};\\\", \\\"{x:1615,y:759,t:1527030427734};\\\", \\\"{x:1615,y:761,t:1527030427757};\\\", \\\"{x:1615,y:762,t:1527030427781};\\\", \\\"{x:1615,y:764,t:1527030427797};\\\", \\\"{x:1615,y:765,t:1527030427813};\\\", \\\"{x:1615,y:767,t:1527030427821};\\\", \\\"{x:1615,y:768,t:1527030427833};\\\", \\\"{x:1615,y:770,t:1527030427850};\\\", \\\"{x:1615,y:772,t:1527030427866};\\\", \\\"{x:1615,y:774,t:1527030427884};\\\", \\\"{x:1615,y:775,t:1527030427900};\\\", \\\"{x:1615,y:781,t:1527030427917};\\\", \\\"{x:1615,y:785,t:1527030427933};\\\", \\\"{x:1615,y:789,t:1527030427950};\\\", \\\"{x:1615,y:793,t:1527030427966};\\\", \\\"{x:1615,y:799,t:1527030427984};\\\", \\\"{x:1615,y:805,t:1527030428000};\\\", \\\"{x:1615,y:811,t:1527030428017};\\\", \\\"{x:1615,y:816,t:1527030428034};\\\", \\\"{x:1615,y:820,t:1527030428051};\\\", \\\"{x:1616,y:823,t:1527030428067};\\\", \\\"{x:1616,y:826,t:1527030428083};\\\", \\\"{x:1617,y:828,t:1527030428101};\\\", \\\"{x:1617,y:832,t:1527030428118};\\\", \\\"{x:1617,y:836,t:1527030428133};\\\", \\\"{x:1618,y:839,t:1527030428150};\\\", \\\"{x:1618,y:841,t:1527030428166};\\\", \\\"{x:1619,y:844,t:1527030428183};\\\", \\\"{x:1620,y:847,t:1527030428200};\\\", \\\"{x:1620,y:850,t:1527030428218};\\\", \\\"{x:1620,y:853,t:1527030428233};\\\", \\\"{x:1621,y:857,t:1527030428250};\\\", \\\"{x:1621,y:860,t:1527030428267};\\\", \\\"{x:1621,y:865,t:1527030428283};\\\", \\\"{x:1623,y:872,t:1527030428301};\\\", \\\"{x:1624,y:880,t:1527030428317};\\\", \\\"{x:1624,y:889,t:1527030428333};\\\", \\\"{x:1624,y:896,t:1527030428350};\\\", \\\"{x:1624,y:902,t:1527030428368};\\\", \\\"{x:1624,y:907,t:1527030428383};\\\", \\\"{x:1624,y:913,t:1527030428401};\\\", \\\"{x:1624,y:919,t:1527030428418};\\\", \\\"{x:1624,y:926,t:1527030428434};\\\", \\\"{x:1624,y:931,t:1527030428450};\\\", \\\"{x:1624,y:936,t:1527030428467};\\\", \\\"{x:1624,y:942,t:1527030428483};\\\", \\\"{x:1624,y:946,t:1527030428500};\\\", \\\"{x:1624,y:951,t:1527030428517};\\\", \\\"{x:1624,y:953,t:1527030428533};\\\", \\\"{x:1624,y:956,t:1527030428551};\\\", \\\"{x:1624,y:960,t:1527030428567};\\\", \\\"{x:1624,y:962,t:1527030428584};\\\", \\\"{x:1624,y:965,t:1527030428601};\\\", \\\"{x:1624,y:967,t:1527030428617};\\\", \\\"{x:1624,y:968,t:1527030428633};\\\", \\\"{x:1623,y:969,t:1527030428651};\\\", \\\"{x:1623,y:971,t:1527030428667};\\\", \\\"{x:1623,y:972,t:1527030428684};\\\", \\\"{x:1623,y:973,t:1527030428701};\\\", \\\"{x:1623,y:974,t:1527030428718};\\\", \\\"{x:1623,y:975,t:1527030428734};\\\", \\\"{x:1623,y:976,t:1527030428765};\\\", \\\"{x:1623,y:977,t:1527030428781};\\\", \\\"{x:1623,y:974,t:1527030429294};\\\", \\\"{x:1623,y:969,t:1527030429302};\\\", \\\"{x:1624,y:959,t:1527030429318};\\\", \\\"{x:1625,y:951,t:1527030429334};\\\", \\\"{x:1628,y:941,t:1527030429351};\\\", \\\"{x:1630,y:932,t:1527030429366};\\\", \\\"{x:1634,y:920,t:1527030429384};\\\", \\\"{x:1635,y:910,t:1527030429401};\\\", \\\"{x:1638,y:901,t:1527030429417};\\\", \\\"{x:1639,y:893,t:1527030429434};\\\", \\\"{x:1640,y:887,t:1527030429451};\\\", \\\"{x:1642,y:882,t:1527030429467};\\\", \\\"{x:1643,y:876,t:1527030429484};\\\", \\\"{x:1643,y:870,t:1527030429500};\\\", \\\"{x:1643,y:866,t:1527030429517};\\\", \\\"{x:1643,y:863,t:1527030429534};\\\", \\\"{x:1643,y:858,t:1527030429551};\\\", \\\"{x:1643,y:852,t:1527030429567};\\\", \\\"{x:1643,y:848,t:1527030429584};\\\", \\\"{x:1643,y:844,t:1527030429601};\\\", \\\"{x:1643,y:842,t:1527030429617};\\\", \\\"{x:1645,y:838,t:1527030429634};\\\", \\\"{x:1645,y:834,t:1527030429651};\\\", \\\"{x:1645,y:829,t:1527030429667};\\\", \\\"{x:1642,y:823,t:1527030429684};\\\", \\\"{x:1640,y:815,t:1527030429701};\\\", \\\"{x:1637,y:810,t:1527030429718};\\\", \\\"{x:1636,y:807,t:1527030429735};\\\", \\\"{x:1634,y:802,t:1527030429751};\\\", \\\"{x:1631,y:795,t:1527030429769};\\\", \\\"{x:1625,y:785,t:1527030429784};\\\", \\\"{x:1622,y:779,t:1527030429802};\\\", \\\"{x:1620,y:775,t:1527030429818};\\\", \\\"{x:1618,y:773,t:1527030429834};\\\", \\\"{x:1618,y:778,t:1527030429942};\\\", \\\"{x:1616,y:791,t:1527030429951};\\\", \\\"{x:1610,y:817,t:1527030429968};\\\", \\\"{x:1606,y:842,t:1527030429985};\\\", \\\"{x:1604,y:862,t:1527030430001};\\\", \\\"{x:1602,y:887,t:1527030430018};\\\", \\\"{x:1602,y:910,t:1527030430034};\\\", \\\"{x:1602,y:928,t:1527030430052};\\\", \\\"{x:1602,y:946,t:1527030430069};\\\", \\\"{x:1602,y:952,t:1527030430085};\\\", \\\"{x:1604,y:961,t:1527030430101};\\\", \\\"{x:1605,y:968,t:1527030430118};\\\", \\\"{x:1607,y:976,t:1527030430135};\\\", \\\"{x:1610,y:982,t:1527030430151};\\\", \\\"{x:1610,y:986,t:1527030430168};\\\", \\\"{x:1612,y:989,t:1527030430185};\\\", \\\"{x:1612,y:990,t:1527030430212};\\\", \\\"{x:1612,y:991,t:1527030430252};\\\", \\\"{x:1613,y:990,t:1527030430317};\\\", \\\"{x:1615,y:982,t:1527030430335};\\\", \\\"{x:1615,y:977,t:1527030430351};\\\", \\\"{x:1615,y:970,t:1527030430368};\\\", \\\"{x:1615,y:966,t:1527030430386};\\\", \\\"{x:1615,y:962,t:1527030430401};\\\", \\\"{x:1615,y:960,t:1527030430418};\\\", \\\"{x:1615,y:958,t:1527030430435};\\\", \\\"{x:1615,y:957,t:1527030430451};\\\", \\\"{x:1615,y:956,t:1527030430469};\\\", \\\"{x:1615,y:953,t:1527030430485};\\\", \\\"{x:1615,y:952,t:1527030430653};\\\", \\\"{x:1615,y:951,t:1527030430669};\\\", \\\"{x:1615,y:950,t:1527030430685};\\\", \\\"{x:1615,y:948,t:1527030430702};\\\", \\\"{x:1615,y:945,t:1527030430718};\\\", \\\"{x:1615,y:941,t:1527030430736};\\\", \\\"{x:1614,y:936,t:1527030430752};\\\", \\\"{x:1613,y:926,t:1527030430769};\\\", \\\"{x:1611,y:916,t:1527030430786};\\\", \\\"{x:1609,y:904,t:1527030430802};\\\", \\\"{x:1608,y:895,t:1527030430818};\\\", \\\"{x:1608,y:891,t:1527030430835};\\\", \\\"{x:1608,y:885,t:1527030430852};\\\", \\\"{x:1608,y:878,t:1527030430868};\\\", \\\"{x:1608,y:868,t:1527030430885};\\\", \\\"{x:1608,y:856,t:1527030430902};\\\", \\\"{x:1608,y:848,t:1527030430918};\\\", \\\"{x:1608,y:844,t:1527030430935};\\\", \\\"{x:1608,y:841,t:1527030430952};\\\", \\\"{x:1608,y:839,t:1527030430969};\\\", \\\"{x:1608,y:833,t:1527030430985};\\\", \\\"{x:1608,y:828,t:1527030431003};\\\", \\\"{x:1608,y:822,t:1527030431019};\\\", \\\"{x:1608,y:815,t:1527030431035};\\\", \\\"{x:1608,y:810,t:1527030431052};\\\", \\\"{x:1608,y:806,t:1527030431068};\\\", \\\"{x:1608,y:800,t:1527030431086};\\\", \\\"{x:1608,y:796,t:1527030431102};\\\", \\\"{x:1608,y:792,t:1527030431120};\\\", \\\"{x:1607,y:788,t:1527030431134};\\\", \\\"{x:1607,y:784,t:1527030431151};\\\", \\\"{x:1605,y:781,t:1527030431168};\\\", \\\"{x:1605,y:778,t:1527030431185};\\\", \\\"{x:1605,y:777,t:1527030431204};\\\", \\\"{x:1605,y:775,t:1527030431229};\\\", \\\"{x:1605,y:773,t:1527030431348};\\\", \\\"{x:1607,y:771,t:1527030431365};\\\", \\\"{x:1608,y:770,t:1527030431380};\\\", \\\"{x:1609,y:769,t:1527030431397};\\\", \\\"{x:1609,y:768,t:1527030431421};\\\", \\\"{x:1609,y:767,t:1527030431437};\\\", \\\"{x:1609,y:761,t:1527030432398};\\\", \\\"{x:1609,y:759,t:1527030432405};\\\", \\\"{x:1609,y:758,t:1527030432420};\\\", \\\"{x:1609,y:756,t:1527030432436};\\\", \\\"{x:1609,y:754,t:1527030432453};\\\", \\\"{x:1609,y:753,t:1527030432486};\\\", \\\"{x:1609,y:754,t:1527030432773};\\\", \\\"{x:1607,y:751,t:1527030433598};\\\", \\\"{x:1604,y:744,t:1527030433605};\\\", \\\"{x:1603,y:739,t:1527030433621};\\\", \\\"{x:1601,y:727,t:1527030433637};\\\", \\\"{x:1598,y:718,t:1527030433655};\\\", \\\"{x:1596,y:714,t:1527030433671};\\\", \\\"{x:1595,y:709,t:1527030433688};\\\", \\\"{x:1594,y:705,t:1527030433705};\\\", \\\"{x:1591,y:699,t:1527030433720};\\\", \\\"{x:1590,y:695,t:1527030433738};\\\", \\\"{x:1589,y:692,t:1527030433755};\\\", \\\"{x:1588,y:689,t:1527030433770};\\\", \\\"{x:1588,y:686,t:1527030433787};\\\", \\\"{x:1588,y:684,t:1527030433805};\\\", \\\"{x:1587,y:681,t:1527030433820};\\\", \\\"{x:1587,y:677,t:1527030433837};\\\", \\\"{x:1587,y:674,t:1527030433854};\\\", \\\"{x:1585,y:668,t:1527030433870};\\\", \\\"{x:1584,y:660,t:1527030433887};\\\", \\\"{x:1583,y:650,t:1527030433905};\\\", \\\"{x:1580,y:640,t:1527030433920};\\\", \\\"{x:1579,y:631,t:1527030433938};\\\", \\\"{x:1577,y:616,t:1527030433954};\\\", \\\"{x:1572,y:595,t:1527030433972};\\\", \\\"{x:1565,y:578,t:1527030433987};\\\", \\\"{x:1562,y:566,t:1527030434004};\\\", \\\"{x:1558,y:548,t:1527030434021};\\\", \\\"{x:1557,y:538,t:1527030434038};\\\", \\\"{x:1554,y:529,t:1527030434054};\\\", \\\"{x:1552,y:522,t:1527030434071};\\\", \\\"{x:1551,y:514,t:1527030434088};\\\", \\\"{x:1549,y:509,t:1527030434105};\\\", \\\"{x:1547,y:501,t:1527030434121};\\\", \\\"{x:1545,y:494,t:1527030434136};\\\", \\\"{x:1542,y:486,t:1527030434154};\\\", \\\"{x:1540,y:481,t:1527030434171};\\\", \\\"{x:1537,y:477,t:1527030434187};\\\", \\\"{x:1531,y:471,t:1527030434204};\\\", \\\"{x:1523,y:469,t:1527030434220};\\\", \\\"{x:1510,y:467,t:1527030434237};\\\", \\\"{x:1491,y:465,t:1527030434253};\\\", \\\"{x:1472,y:465,t:1527030434271};\\\", \\\"{x:1447,y:465,t:1527030434287};\\\", \\\"{x:1421,y:466,t:1527030434303};\\\", \\\"{x:1394,y:471,t:1527030434321};\\\", \\\"{x:1361,y:476,t:1527030434337};\\\", \\\"{x:1335,y:482,t:1527030434354};\\\", \\\"{x:1312,y:488,t:1527030434371};\\\", \\\"{x:1294,y:493,t:1527030434388};\\\", \\\"{x:1271,y:505,t:1527030434404};\\\", \\\"{x:1254,y:516,t:1527030434420};\\\", \\\"{x:1239,y:527,t:1527030434438};\\\", \\\"{x:1221,y:540,t:1527030434454};\\\", \\\"{x:1201,y:554,t:1527030434471};\\\", \\\"{x:1181,y:565,t:1527030434488};\\\", \\\"{x:1154,y:575,t:1527030434504};\\\", \\\"{x:1130,y:581,t:1527030434521};\\\", \\\"{x:1111,y:583,t:1527030434539};\\\", \\\"{x:1092,y:586,t:1527030434555};\\\", \\\"{x:1070,y:586,t:1527030434572};\\\", \\\"{x:1037,y:586,t:1527030434588};\\\", \\\"{x:1010,y:586,t:1527030434604};\\\", \\\"{x:982,y:590,t:1527030434621};\\\", \\\"{x:957,y:590,t:1527030434642};\\\", \\\"{x:937,y:592,t:1527030434654};\\\", \\\"{x:927,y:593,t:1527030434670};\\\", \\\"{x:926,y:593,t:1527030434689};\\\", \\\"{x:925,y:594,t:1527030435565};\\\", \\\"{x:924,y:594,t:1527030435574};\\\", \\\"{x:923,y:594,t:1527030435620};\\\", \\\"{x:922,y:594,t:1527030435700};\\\", \\\"{x:921,y:594,t:1527030435708};\\\", \\\"{x:920,y:594,t:1527030435723};\\\", \\\"{x:918,y:594,t:1527030435740};\\\", \\\"{x:917,y:595,t:1527030435756};\\\", \\\"{x:915,y:596,t:1527030435773};\\\", \\\"{x:913,y:596,t:1527030435790};\\\", \\\"{x:910,y:597,t:1527030435806};\\\", \\\"{x:909,y:597,t:1527030435823};\\\", \\\"{x:906,y:597,t:1527030435844};\\\", \\\"{x:905,y:599,t:1527030435856};\\\", \\\"{x:904,y:599,t:1527030435873};\\\", \\\"{x:903,y:600,t:1527030435890};\\\", \\\"{x:901,y:602,t:1527030435907};\\\", \\\"{x:900,y:603,t:1527030435923};\\\", \\\"{x:897,y:603,t:1527030435940};\\\", \\\"{x:896,y:604,t:1527030435957};\\\", \\\"{x:894,y:605,t:1527030436013};\\\", \\\"{x:893,y:606,t:1527030436037};\\\", \\\"{x:892,y:606,t:1527030436061};\\\", \\\"{x:890,y:606,t:1527030436300};\\\", \\\"{x:889,y:607,t:1527030436308};\\\", \\\"{x:888,y:608,t:1527030436324};\\\", \\\"{x:887,y:609,t:1527030436340};\\\", \\\"{x:885,y:610,t:1527030436357};\\\", \\\"{x:884,y:611,t:1527030436388};\\\", \\\"{x:883,y:612,t:1527030436396};\\\", \\\"{x:882,y:613,t:1527030436420};\\\", \\\"{x:881,y:613,t:1527030436444};\\\", \\\"{x:881,y:614,t:1527030436457};\\\", \\\"{x:879,y:616,t:1527030436474};\\\", \\\"{x:878,y:616,t:1527030436492};\\\", \\\"{x:877,y:618,t:1527030436507};\\\", \\\"{x:876,y:618,t:1527030436524};\\\", \\\"{x:875,y:619,t:1527030436540};\\\", \\\"{x:874,y:619,t:1527030436581};\\\", \\\"{x:873,y:620,t:1527030437373};\\\", \\\"{x:872,y:621,t:1527030437693};\\\", \\\"{x:871,y:621,t:1527030437708};\\\", \\\"{x:869,y:622,t:1527030437725};\\\", \\\"{x:867,y:624,t:1527030437741};\\\", \\\"{x:866,y:624,t:1527030437765};\\\", \\\"{x:865,y:625,t:1527030437780};\\\", \\\"{x:863,y:626,t:1527030437796};\\\", \\\"{x:862,y:626,t:1527030437808};\\\", \\\"{x:859,y:628,t:1527030437825};\\\", \\\"{x:856,y:629,t:1527030437841};\\\", \\\"{x:854,y:632,t:1527030437859};\\\", \\\"{x:849,y:635,t:1527030437875};\\\", \\\"{x:844,y:639,t:1527030437892};\\\", \\\"{x:832,y:646,t:1527030437909};\\\", \\\"{x:826,y:650,t:1527030437925};\\\", \\\"{x:821,y:653,t:1527030437941};\\\", \\\"{x:817,y:656,t:1527030437958};\\\", \\\"{x:813,y:657,t:1527030437976};\\\", \\\"{x:811,y:659,t:1527030437992};\\\", \\\"{x:810,y:660,t:1527030438008};\\\", \\\"{x:809,y:660,t:1527030438025};\\\", \\\"{x:806,y:662,t:1527030438042};\\\", \\\"{x:806,y:663,t:1527030438059};\\\", \\\"{x:803,y:665,t:1527030438076};\\\", \\\"{x:801,y:667,t:1527030438092};\\\", \\\"{x:796,y:671,t:1527030438109};\\\", \\\"{x:791,y:674,t:1527030438125};\\\", \\\"{x:785,y:678,t:1527030438142};\\\", \\\"{x:781,y:681,t:1527030438159};\\\", \\\"{x:775,y:685,t:1527030438175};\\\", \\\"{x:771,y:686,t:1527030438192};\\\", \\\"{x:766,y:689,t:1527030438208};\\\", \\\"{x:763,y:689,t:1527030438226};\\\", \\\"{x:760,y:691,t:1527030438243};\\\", \\\"{x:756,y:693,t:1527030438258};\\\", \\\"{x:755,y:694,t:1527030438276};\\\", \\\"{x:748,y:696,t:1527030438293};\\\", \\\"{x:746,y:697,t:1527030438308};\\\", \\\"{x:741,y:699,t:1527030438325};\\\", \\\"{x:737,y:700,t:1527030438343};\\\", \\\"{x:729,y:702,t:1527030438359};\\\", \\\"{x:721,y:704,t:1527030438375};\\\", \\\"{x:714,y:706,t:1527030438393};\\\", \\\"{x:702,y:710,t:1527030438409};\\\", \\\"{x:683,y:720,t:1527030438425};\\\", \\\"{x:663,y:731,t:1527030438443};\\\", \\\"{x:638,y:744,t:1527030438458};\\\", \\\"{x:611,y:756,t:1527030438475};\\\", \\\"{x:557,y:777,t:1527030438492};\\\", \\\"{x:517,y:792,t:1527030438509};\\\", \\\"{x:475,y:805,t:1527030438525};\\\", \\\"{x:444,y:811,t:1527030438542};\\\", \\\"{x:423,y:818,t:1527030438558};\\\", \\\"{x:408,y:820,t:1527030438574};\\\", \\\"{x:400,y:821,t:1527030438592};\\\", \\\"{x:399,y:821,t:1527030438609};\\\", \\\"{x:398,y:821,t:1527030438717};\\\", \\\"{x:397,y:818,t:1527030438725};\\\", \\\"{x:395,y:806,t:1527030438742};\\\", \\\"{x:395,y:802,t:1527030438759};\\\", \\\"{x:394,y:798,t:1527030438775};\\\", \\\"{x:394,y:793,t:1527030438792};\\\", \\\"{x:394,y:788,t:1527030438809};\\\", \\\"{x:394,y:784,t:1527030438825};\\\", \\\"{x:394,y:781,t:1527030438842};\\\", \\\"{x:394,y:777,t:1527030438859};\\\", \\\"{x:394,y:774,t:1527030438875};\\\", \\\"{x:394,y:771,t:1527030438892};\\\", \\\"{x:394,y:768,t:1527030438909};\\\", \\\"{x:394,y:765,t:1527030438925};\\\", \\\"{x:395,y:761,t:1527030438943};\\\", \\\"{x:398,y:755,t:1527030438959};\\\", \\\"{x:401,y:748,t:1527030438975};\\\", \\\"{x:402,y:745,t:1527030438992};\\\", \\\"{x:404,y:740,t:1527030439010};\\\", \\\"{x:408,y:735,t:1527030439026};\\\", \\\"{x:413,y:728,t:1527030439042};\\\", \\\"{x:418,y:719,t:1527030439059};\\\", \\\"{x:424,y:711,t:1527030439077};\\\", \\\"{x:438,y:686,t:1527030439092};\\\", \\\"{x:445,y:671,t:1527030439109};\\\", \\\"{x:449,y:666,t:1527030439126};\\\", \\\"{x:453,y:660,t:1527030439143};\\\", \\\"{x:457,y:654,t:1527030439160};\\\", \\\"{x:460,y:646,t:1527030439178};\\\", \\\"{x:464,y:634,t:1527030439192};\\\", \\\"{x:466,y:624,t:1527030439209};\\\", \\\"{x:469,y:612,t:1527030439226};\\\", \\\"{x:471,y:602,t:1527030439243};\\\", \\\"{x:472,y:596,t:1527030439259};\\\", \\\"{x:472,y:592,t:1527030439276};\\\", \\\"{x:472,y:590,t:1527030439293};\\\", \\\"{x:472,y:589,t:1527030439316};\\\", \\\"{x:472,y:588,t:1527030439331};\\\", \\\"{x:472,y:587,t:1527030439343};\\\", \\\"{x:472,y:583,t:1527030439359};\\\", \\\"{x:472,y:577,t:1527030439377};\\\", \\\"{x:469,y:573,t:1527030439394};\\\", \\\"{x:467,y:569,t:1527030439410};\\\", \\\"{x:465,y:569,t:1527030439485};\\\", \\\"{x:462,y:569,t:1527030439493};\\\", \\\"{x:458,y:569,t:1527030439510};\\\", \\\"{x:453,y:569,t:1527030439527};\\\", \\\"{x:448,y:569,t:1527030439544};\\\", \\\"{x:439,y:569,t:1527030439560};\\\", \\\"{x:429,y:568,t:1527030439577};\\\", \\\"{x:414,y:565,t:1527030439595};\\\", \\\"{x:397,y:560,t:1527030439610};\\\", \\\"{x:382,y:558,t:1527030439626};\\\", \\\"{x:370,y:556,t:1527030439644};\\\", \\\"{x:351,y:553,t:1527030439660};\\\", \\\"{x:342,y:551,t:1527030439676};\\\", \\\"{x:337,y:551,t:1527030439693};\\\", \\\"{x:333,y:551,t:1527030439710};\\\", \\\"{x:329,y:550,t:1527030439727};\\\", \\\"{x:324,y:549,t:1527030439743};\\\", \\\"{x:319,y:549,t:1527030439760};\\\", \\\"{x:315,y:549,t:1527030439776};\\\", \\\"{x:307,y:549,t:1527030439794};\\\", \\\"{x:293,y:549,t:1527030439810};\\\", \\\"{x:279,y:547,t:1527030439826};\\\", \\\"{x:264,y:547,t:1527030439845};\\\", \\\"{x:244,y:547,t:1527030439860};\\\", \\\"{x:233,y:549,t:1527030439876};\\\", \\\"{x:221,y:556,t:1527030439893};\\\", \\\"{x:214,y:562,t:1527030439910};\\\", \\\"{x:208,y:568,t:1527030439926};\\\", \\\"{x:202,y:574,t:1527030439943};\\\", \\\"{x:199,y:577,t:1527030439961};\\\", \\\"{x:195,y:581,t:1527030439976};\\\", \\\"{x:193,y:583,t:1527030439994};\\\", \\\"{x:191,y:587,t:1527030440011};\\\", \\\"{x:189,y:589,t:1527030440026};\\\", \\\"{x:188,y:592,t:1527030440043};\\\", \\\"{x:186,y:594,t:1527030440060};\\\", \\\"{x:186,y:595,t:1527030440077};\\\", \\\"{x:185,y:598,t:1527030440093};\\\", \\\"{x:184,y:598,t:1527030440115};\\\", \\\"{x:183,y:599,t:1527030440164};\\\", \\\"{x:182,y:599,t:1527030440197};\\\", \\\"{x:181,y:599,t:1527030440213};\\\", \\\"{x:180,y:601,t:1527030440228};\\\", \\\"{x:178,y:602,t:1527030440252};\\\", \\\"{x:176,y:604,t:1527030440285};\\\", \\\"{x:175,y:604,t:1527030440294};\\\", \\\"{x:174,y:606,t:1527030440310};\\\", \\\"{x:171,y:610,t:1527030440327};\\\", \\\"{x:171,y:612,t:1527030440344};\\\", \\\"{x:170,y:614,t:1527030440360};\\\", \\\"{x:169,y:616,t:1527030440376};\\\", \\\"{x:168,y:618,t:1527030440393};\\\", \\\"{x:168,y:619,t:1527030440411};\\\", \\\"{x:168,y:620,t:1527030440428};\\\", \\\"{x:168,y:622,t:1527030440444};\\\", \\\"{x:168,y:623,t:1527030440460};\\\", \\\"{x:168,y:625,t:1527030440477};\\\", \\\"{x:168,y:627,t:1527030440494};\\\", \\\"{x:168,y:628,t:1527030440510};\\\", \\\"{x:167,y:630,t:1527030440527};\\\", \\\"{x:167,y:631,t:1527030440555};\\\", \\\"{x:166,y:632,t:1527030440564};\\\", \\\"{x:166,y:633,t:1527030440577};\\\", \\\"{x:165,y:635,t:1527030440594};\\\", \\\"{x:164,y:636,t:1527030440610};\\\", \\\"{x:164,y:637,t:1527030440627};\\\", \\\"{x:164,y:639,t:1527030441605};\\\", \\\"{x:171,y:642,t:1527030441613};\\\", \\\"{x:190,y:647,t:1527030441629};\\\", \\\"{x:207,y:654,t:1527030441645};\\\", \\\"{x:223,y:660,t:1527030441661};\\\", \\\"{x:241,y:665,t:1527030441678};\\\", \\\"{x:259,y:671,t:1527030441694};\\\", \\\"{x:278,y:675,t:1527030441711};\\\", \\\"{x:291,y:679,t:1527030441728};\\\", \\\"{x:298,y:683,t:1527030441744};\\\", \\\"{x:303,y:685,t:1527030441761};\\\", \\\"{x:305,y:686,t:1527030441779};\\\", \\\"{x:307,y:686,t:1527030441794};\\\", \\\"{x:308,y:687,t:1527030441811};\\\", \\\"{x:309,y:688,t:1527030441828};\\\", \\\"{x:311,y:688,t:1527030441845};\\\", \\\"{x:311,y:689,t:1527030441861};\\\", \\\"{x:316,y:691,t:1527030441878};\\\", \\\"{x:320,y:693,t:1527030441895};\\\", \\\"{x:327,y:696,t:1527030441911};\\\", \\\"{x:336,y:700,t:1527030441928};\\\", \\\"{x:348,y:705,t:1527030441945};\\\", \\\"{x:354,y:707,t:1527030441961};\\\", \\\"{x:363,y:710,t:1527030441979};\\\", \\\"{x:369,y:711,t:1527030441995};\\\", \\\"{x:374,y:712,t:1527030442011};\\\", \\\"{x:382,y:714,t:1527030442028};\\\", \\\"{x:388,y:715,t:1527030442045};\\\", \\\"{x:392,y:716,t:1527030442062};\\\", \\\"{x:396,y:717,t:1527030442079};\\\", \\\"{x:396,y:718,t:1527030442095};\\\", \\\"{x:397,y:718,t:1527030442112};\\\", \\\"{x:399,y:719,t:1527030442128};\\\", \\\"{x:401,y:719,t:1527030442145};\\\", \\\"{x:405,y:721,t:1527030442162};\\\", \\\"{x:408,y:721,t:1527030442179};\\\", \\\"{x:411,y:722,t:1527030442196};\\\", \\\"{x:414,y:722,t:1527030442212};\\\", \\\"{x:419,y:723,t:1527030442228};\\\", \\\"{x:425,y:725,t:1527030442246};\\\", \\\"{x:428,y:725,t:1527030442261};\\\", \\\"{x:432,y:725,t:1527030442278};\\\", \\\"{x:436,y:726,t:1527030442295};\\\", \\\"{x:438,y:726,t:1527030442312};\\\", \\\"{x:439,y:727,t:1527030442328};\\\", \\\"{x:442,y:728,t:1527030442346};\\\", \\\"{x:443,y:728,t:1527030442362};\\\", \\\"{x:445,y:728,t:1527030442380};\\\", \\\"{x:447,y:728,t:1527030442395};\\\", \\\"{x:452,y:729,t:1527030442412};\\\", \\\"{x:456,y:730,t:1527030442428};\\\", \\\"{x:459,y:730,t:1527030442445};\\\", \\\"{x:462,y:730,t:1527030442462};\\\", \\\"{x:464,y:730,t:1527030442478};\\\", \\\"{x:468,y:732,t:1527030442496};\\\", \\\"{x:472,y:732,t:1527030442512};\\\", \\\"{x:473,y:732,t:1527030442528};\\\", \\\"{x:475,y:732,t:1527030442545};\\\", \\\"{x:476,y:732,t:1527030442562};\\\", \\\"{x:478,y:733,t:1527030442578};\\\", \\\"{x:479,y:733,t:1527030442596};\\\", \\\"{x:481,y:733,t:1527030442613};\\\", \\\"{x:482,y:733,t:1527030442628};\\\", \\\"{x:484,y:733,t:1527030442653};\\\", \\\"{x:485,y:733,t:1527030442677};\\\", \\\"{x:487,y:733,t:1527030442701};\\\", \\\"{x:488,y:733,t:1527030442949};\\\", \\\"{x:490,y:733,t:1527030442973};\\\", \\\"{x:491,y:733,t:1527030442980};\\\", \\\"{x:492,y:733,t:1527030442996};\\\", \\\"{x:495,y:731,t:1527030443013};\\\", \\\"{x:497,y:729,t:1527030443030};\\\", \\\"{x:498,y:728,t:1527030443045};\\\", \\\"{x:501,y:726,t:1527030443063};\\\", \\\"{x:502,y:725,t:1527030443079};\\\", \\\"{x:504,y:724,t:1527030443095};\\\", \\\"{x:505,y:723,t:1527030443113};\\\", \\\"{x:506,y:720,t:1527030443130};\\\", \\\"{x:507,y:719,t:1527030443146};\\\", \\\"{x:508,y:716,t:1527030443163};\\\", \\\"{x:510,y:714,t:1527030443180};\\\", \\\"{x:511,y:712,t:1527030443197};\\\", \\\"{x:513,y:708,t:1527030443212};\\\", \\\"{x:514,y:706,t:1527030443230};\\\", \\\"{x:514,y:705,t:1527030443247};\\\", \\\"{x:514,y:703,t:1527030443263};\\\", \\\"{x:515,y:701,t:1527030443280};\\\", \\\"{x:516,y:699,t:1527030443297};\\\", \\\"{x:516,y:697,t:1527030443312};\\\", \\\"{x:516,y:696,t:1527030443329};\\\", \\\"{x:517,y:694,t:1527030443346};\\\", \\\"{x:518,y:693,t:1527030443362};\\\", \\\"{x:518,y:692,t:1527030443379};\\\", \\\"{x:518,y:690,t:1527030443396};\\\", \\\"{x:520,y:689,t:1527030443428};\\\", \\\"{x:520,y:690,t:1527030443549};\\\", \\\"{x:520,y:691,t:1527030443563};\\\", \\\"{x:520,y:695,t:1527030443579};\\\", \\\"{x:520,y:701,t:1527030443596};\\\", \\\"{x:520,y:704,t:1527030443612};\\\", \\\"{x:520,y:705,t:1527030443644};\\\", \\\"{x:520,y:707,t:1527030443869};\\\", \\\"{x:520,y:710,t:1527030443880};\\\", \\\"{x:520,y:712,t:1527030443896};\\\", \\\"{x:523,y:715,t:1527030443913};\\\", \\\"{x:524,y:717,t:1527030443930};\\\", \\\"{x:525,y:720,t:1527030443947};\\\", \\\"{x:526,y:720,t:1527030443964};\\\", \\\"{x:526,y:721,t:1527030443980};\\\" ] }, { \\\"rt\\\": 26492, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 7, \\\"time_elapsed\\\": 229261, \\\"internal_node_id\\\": \\\"0.0-5.0-2.0\\\", \\\"subject\\\": \\\"E5L6P\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 3, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"Z\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-01 PM-C -C -10 AM-10 AM-C -A -Z -Z -Z -Z \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:527,y:716,t:1527030447229};\\\", \\\"{x:527,y:691,t:1527030447238};\\\", \\\"{x:524,y:668,t:1527030447248};\\\", \\\"{x:516,y:636,t:1527030447267};\\\", \\\"{x:508,y:612,t:1527030447283};\\\", \\\"{x:502,y:588,t:1527030447299};\\\", \\\"{x:497,y:567,t:1527030447316};\\\", \\\"{x:491,y:547,t:1527030447332};\\\", \\\"{x:490,y:537,t:1527030447350};\\\", \\\"{x:486,y:528,t:1527030447367};\\\", \\\"{x:484,y:516,t:1527030447382};\\\", \\\"{x:482,y:505,t:1527030447399};\\\", \\\"{x:481,y:495,t:1527030447416};\\\", \\\"{x:479,y:482,t:1527030447433};\\\", \\\"{x:478,y:473,t:1527030447449};\\\", \\\"{x:477,y:468,t:1527030447466};\\\", \\\"{x:476,y:461,t:1527030447483};\\\", \\\"{x:476,y:458,t:1527030447499};\\\", \\\"{x:476,y:454,t:1527030447516};\\\", \\\"{x:476,y:452,t:1527030447533};\\\", \\\"{x:476,y:451,t:1527030447556};\\\", \\\"{x:476,y:449,t:1527030447596};\\\", \\\"{x:477,y:448,t:1527030447629};\\\", \\\"{x:478,y:448,t:1527030447652};\\\", \\\"{x:478,y:451,t:1527030447789};\\\", \\\"{x:478,y:453,t:1527030447801};\\\", \\\"{x:478,y:456,t:1527030447818};\\\", \\\"{x:478,y:459,t:1527030447834};\\\", \\\"{x:479,y:462,t:1527030447851};\\\", \\\"{x:480,y:462,t:1527030447868};\\\", \\\"{x:480,y:463,t:1527030447884};\\\", \\\"{x:480,y:464,t:1527030447901};\\\", \\\"{x:481,y:466,t:1527030447918};\\\", \\\"{x:482,y:467,t:1527030447935};\\\", \\\"{x:483,y:469,t:1527030447951};\\\", \\\"{x:484,y:471,t:1527030447967};\\\", \\\"{x:485,y:472,t:1527030447985};\\\", \\\"{x:486,y:473,t:1527030448005};\\\", \\\"{x:487,y:473,t:1527030448018};\\\", \\\"{x:487,y:474,t:1527030448035};\\\", \\\"{x:488,y:475,t:1527030448052};\\\", \\\"{x:489,y:475,t:1527030448077};\\\", \\\"{x:491,y:476,t:1527030448093};\\\", \\\"{x:492,y:477,t:1527030448109};\\\", \\\"{x:493,y:478,t:1527030448133};\\\", \\\"{x:494,y:479,t:1527030448149};\\\", \\\"{x:495,y:479,t:1527030448157};\\\", \\\"{x:496,y:479,t:1527030448189};\\\", \\\"{x:498,y:479,t:1527030448277};\\\", \\\"{x:501,y:479,t:1527030448286};\\\", \\\"{x:505,y:479,t:1527030448302};\\\", \\\"{x:509,y:479,t:1527030448318};\\\", \\\"{x:513,y:479,t:1527030448335};\\\", \\\"{x:515,y:477,t:1527030448352};\\\", \\\"{x:516,y:477,t:1527030448368};\\\", \\\"{x:517,y:477,t:1527030448386};\\\", \\\"{x:519,y:477,t:1527030448404};\\\", \\\"{x:520,y:476,t:1527030448420};\\\", \\\"{x:521,y:476,t:1527030448435};\\\", \\\"{x:525,y:474,t:1527030448452};\\\", \\\"{x:526,y:473,t:1527030448469};\\\", \\\"{x:528,y:473,t:1527030448486};\\\", \\\"{x:529,y:473,t:1527030448508};\\\", \\\"{x:530,y:471,t:1527030448524};\\\", \\\"{x:532,y:471,t:1527030448556};\\\", \\\"{x:534,y:471,t:1527030448741};\\\", \\\"{x:536,y:471,t:1527030448753};\\\", \\\"{x:540,y:471,t:1527030448770};\\\", \\\"{x:543,y:471,t:1527030448787};\\\", \\\"{x:545,y:471,t:1527030448804};\\\", \\\"{x:546,y:471,t:1527030448820};\\\", \\\"{x:547,y:471,t:1527030448837};\\\", \\\"{x:548,y:471,t:1527030448860};\\\", \\\"{x:549,y:471,t:1527030448965};\\\", \\\"{x:550,y:471,t:1527030448972};\\\", \\\"{x:551,y:471,t:1527030448987};\\\", \\\"{x:554,y:471,t:1527030449004};\\\", \\\"{x:558,y:472,t:1527030449021};\\\", \\\"{x:559,y:472,t:1527030449038};\\\", \\\"{x:564,y:474,t:1527030449054};\\\", \\\"{x:566,y:475,t:1527030449070};\\\", \\\"{x:571,y:476,t:1527030449087};\\\", \\\"{x:577,y:478,t:1527030449104};\\\", \\\"{x:587,y:483,t:1527030449121};\\\", \\\"{x:601,y:490,t:1527030449138};\\\", \\\"{x:623,y:499,t:1527030449154};\\\", \\\"{x:646,y:509,t:1527030449171};\\\", \\\"{x:681,y:523,t:1527030449187};\\\", \\\"{x:759,y:556,t:1527030449204};\\\", \\\"{x:786,y:568,t:1527030449218};\\\", \\\"{x:835,y:597,t:1527030449235};\\\", \\\"{x:895,y:631,t:1527030449251};\\\", \\\"{x:959,y:663,t:1527030449267};\\\", \\\"{x:1017,y:698,t:1527030449283};\\\", \\\"{x:1105,y:739,t:1527030449301};\\\", \\\"{x:1158,y:766,t:1527030449317};\\\", \\\"{x:1202,y:792,t:1527030449334};\\\", \\\"{x:1248,y:820,t:1527030449350};\\\", \\\"{x:1284,y:843,t:1527030449368};\\\", \\\"{x:1326,y:871,t:1527030449383};\\\", \\\"{x:1365,y:896,t:1527030449400};\\\", \\\"{x:1386,y:911,t:1527030449417};\\\", \\\"{x:1409,y:922,t:1527030449433};\\\", \\\"{x:1429,y:935,t:1527030449451};\\\", \\\"{x:1459,y:949,t:1527030449466};\\\", \\\"{x:1489,y:967,t:1527030449483};\\\", \\\"{x:1526,y:987,t:1527030449500};\\\", \\\"{x:1540,y:997,t:1527030449517};\\\", \\\"{x:1548,y:1001,t:1527030449534};\\\", \\\"{x:1550,y:1002,t:1527030449550};\\\", \\\"{x:1551,y:1002,t:1527030449567};\\\", \\\"{x:1551,y:1004,t:1527030449603};\\\", \\\"{x:1549,y:1004,t:1527030449620};\\\", \\\"{x:1547,y:1004,t:1527030449634};\\\", \\\"{x:1541,y:1005,t:1527030449649};\\\", \\\"{x:1535,y:1006,t:1527030449666};\\\", \\\"{x:1526,y:1007,t:1527030449683};\\\", \\\"{x:1515,y:1007,t:1527030449699};\\\", \\\"{x:1494,y:1005,t:1527030449716};\\\", \\\"{x:1481,y:1000,t:1527030449733};\\\", \\\"{x:1464,y:995,t:1527030449750};\\\", \\\"{x:1446,y:985,t:1527030449766};\\\", \\\"{x:1428,y:979,t:1527030449783};\\\", \\\"{x:1413,y:974,t:1527030449799};\\\", \\\"{x:1401,y:969,t:1527030449816};\\\", \\\"{x:1390,y:965,t:1527030449834};\\\", \\\"{x:1379,y:960,t:1527030449850};\\\", \\\"{x:1373,y:958,t:1527030449866};\\\", \\\"{x:1365,y:955,t:1527030449883};\\\", \\\"{x:1361,y:954,t:1527030449900};\\\", \\\"{x:1355,y:951,t:1527030449915};\\\", \\\"{x:1347,y:950,t:1527030449932};\\\", \\\"{x:1343,y:949,t:1527030449950};\\\", \\\"{x:1337,y:948,t:1527030449966};\\\", \\\"{x:1332,y:947,t:1527030449983};\\\", \\\"{x:1327,y:947,t:1527030449999};\\\", \\\"{x:1322,y:947,t:1527030450016};\\\", \\\"{x:1319,y:947,t:1527030450033};\\\", \\\"{x:1317,y:947,t:1527030450049};\\\", \\\"{x:1314,y:947,t:1527030450066};\\\", \\\"{x:1313,y:949,t:1527030450083};\\\", \\\"{x:1310,y:951,t:1527030450098};\\\", \\\"{x:1309,y:953,t:1527030450116};\\\", \\\"{x:1308,y:954,t:1527030450132};\\\", \\\"{x:1307,y:955,t:1527030450149};\\\", \\\"{x:1307,y:957,t:1527030450166};\\\", \\\"{x:1305,y:959,t:1527030450181};\\\", \\\"{x:1305,y:960,t:1527030450229};\\\", \\\"{x:1305,y:961,t:1527030450245};\\\", \\\"{x:1304,y:961,t:1527030450253};\\\", \\\"{x:1304,y:962,t:1527030450502};\\\", \\\"{x:1310,y:959,t:1527030450515};\\\", \\\"{x:1320,y:948,t:1527030450532};\\\", \\\"{x:1326,y:928,t:1527030450548};\\\", \\\"{x:1328,y:888,t:1527030450565};\\\", \\\"{x:1322,y:860,t:1527030450581};\\\", \\\"{x:1310,y:835,t:1527030450598};\\\", \\\"{x:1299,y:810,t:1527030450616};\\\", \\\"{x:1287,y:791,t:1527030450631};\\\", \\\"{x:1277,y:776,t:1527030450648};\\\", \\\"{x:1269,y:767,t:1527030450665};\\\", \\\"{x:1263,y:759,t:1527030450681};\\\", \\\"{x:1254,y:752,t:1527030450698};\\\", \\\"{x:1247,y:745,t:1527030450713};\\\", \\\"{x:1241,y:740,t:1527030450731};\\\", \\\"{x:1233,y:734,t:1527030450748};\\\", \\\"{x:1229,y:731,t:1527030450764};\\\", \\\"{x:1228,y:730,t:1527030450780};\\\", \\\"{x:1227,y:730,t:1527030450804};\\\", \\\"{x:1226,y:730,t:1527030450852};\\\", \\\"{x:1225,y:730,t:1527030450869};\\\", \\\"{x:1224,y:731,t:1527030450881};\\\", \\\"{x:1221,y:741,t:1527030450897};\\\", \\\"{x:1219,y:754,t:1527030450914};\\\", \\\"{x:1217,y:771,t:1527030450930};\\\", \\\"{x:1214,y:790,t:1527030450947};\\\", \\\"{x:1213,y:803,t:1527030450964};\\\", \\\"{x:1211,y:811,t:1527030450981};\\\", \\\"{x:1211,y:812,t:1527030450997};\\\", \\\"{x:1211,y:815,t:1527030451014};\\\", \\\"{x:1211,y:818,t:1527030451030};\\\", \\\"{x:1211,y:821,t:1527030451047};\\\", \\\"{x:1213,y:824,t:1527030451064};\\\", \\\"{x:1213,y:825,t:1527030451082};\\\", \\\"{x:1213,y:826,t:1527030451096};\\\", \\\"{x:1213,y:827,t:1527030451284};\\\", \\\"{x:1213,y:828,t:1527030451333};\\\", \\\"{x:1213,y:829,t:1527030452229};\\\", \\\"{x:1213,y:840,t:1527030452246};\\\", \\\"{x:1213,y:855,t:1527030452261};\\\", \\\"{x:1215,y:876,t:1527030452277};\\\", \\\"{x:1218,y:901,t:1527030452294};\\\", \\\"{x:1220,y:918,t:1527030452311};\\\", \\\"{x:1222,y:928,t:1527030452328};\\\", \\\"{x:1224,y:933,t:1527030452344};\\\", \\\"{x:1224,y:935,t:1527030452361};\\\", \\\"{x:1224,y:937,t:1527030452377};\\\", \\\"{x:1224,y:938,t:1527030452394};\\\", \\\"{x:1224,y:939,t:1527030452445};\\\", \\\"{x:1224,y:940,t:1527030452461};\\\", \\\"{x:1224,y:943,t:1527030452477};\\\", \\\"{x:1223,y:948,t:1527030452495};\\\", \\\"{x:1222,y:954,t:1527030452510};\\\", \\\"{x:1220,y:959,t:1527030452527};\\\", \\\"{x:1219,y:961,t:1527030452544};\\\", \\\"{x:1219,y:966,t:1527030452561};\\\", \\\"{x:1218,y:969,t:1527030452578};\\\", \\\"{x:1216,y:974,t:1527030452593};\\\", \\\"{x:1215,y:978,t:1527030452611};\\\", \\\"{x:1213,y:982,t:1527030452627};\\\", \\\"{x:1211,y:985,t:1527030452643};\\\", \\\"{x:1211,y:986,t:1527030452660};\\\", \\\"{x:1211,y:985,t:1527030452813};\\\", \\\"{x:1211,y:980,t:1527030452826};\\\", \\\"{x:1211,y:973,t:1527030452843};\\\", \\\"{x:1211,y:966,t:1527030452859};\\\", \\\"{x:1211,y:949,t:1527030452877};\\\", \\\"{x:1211,y:935,t:1527030452893};\\\", \\\"{x:1211,y:923,t:1527030452909};\\\", \\\"{x:1211,y:913,t:1527030452927};\\\", \\\"{x:1211,y:909,t:1527030452943};\\\", \\\"{x:1211,y:905,t:1527030452959};\\\", \\\"{x:1211,y:898,t:1527030452976};\\\", \\\"{x:1211,y:892,t:1527030452993};\\\", \\\"{x:1209,y:886,t:1527030453009};\\\", \\\"{x:1208,y:880,t:1527030453026};\\\", \\\"{x:1208,y:874,t:1527030453043};\\\", \\\"{x:1207,y:870,t:1527030453060};\\\", \\\"{x:1205,y:863,t:1527030453076};\\\", \\\"{x:1205,y:860,t:1527030453093};\\\", \\\"{x:1203,y:856,t:1527030453109};\\\", \\\"{x:1203,y:852,t:1527030453126};\\\", \\\"{x:1202,y:849,t:1527030453142};\\\", \\\"{x:1201,y:846,t:1527030453159};\\\", \\\"{x:1200,y:844,t:1527030453175};\\\", \\\"{x:1200,y:842,t:1527030453192};\\\", \\\"{x:1200,y:841,t:1527030453213};\\\", \\\"{x:1200,y:840,t:1527030453237};\\\", \\\"{x:1200,y:839,t:1527030453252};\\\", \\\"{x:1200,y:838,t:1527030453501};\\\", \\\"{x:1200,y:837,t:1527030453509};\\\", \\\"{x:1201,y:836,t:1527030453525};\\\", \\\"{x:1202,y:834,t:1527030453541};\\\", \\\"{x:1204,y:833,t:1527030453558};\\\", \\\"{x:1204,y:832,t:1527030453574};\\\", \\\"{x:1205,y:831,t:1527030453605};\\\", \\\"{x:1206,y:830,t:1527030453637};\\\", \\\"{x:1207,y:829,t:1527030453653};\\\", \\\"{x:1208,y:828,t:1527030453684};\\\", \\\"{x:1209,y:827,t:1527030453708};\\\", \\\"{x:1209,y:828,t:1527030454116};\\\", \\\"{x:1209,y:829,t:1527030454132};\\\", \\\"{x:1210,y:830,t:1527030454139};\\\", \\\"{x:1212,y:832,t:1527030454155};\\\", \\\"{x:1218,y:836,t:1527030454173};\\\", \\\"{x:1223,y:838,t:1527030454190};\\\", \\\"{x:1226,y:839,t:1527030454205};\\\", \\\"{x:1229,y:840,t:1527030454222};\\\", \\\"{x:1231,y:840,t:1527030454240};\\\", \\\"{x:1235,y:840,t:1527030454256};\\\", \\\"{x:1239,y:840,t:1527030454272};\\\", \\\"{x:1246,y:840,t:1527030454290};\\\", \\\"{x:1251,y:840,t:1527030454306};\\\", \\\"{x:1253,y:840,t:1527030454323};\\\", \\\"{x:1254,y:840,t:1527030454453};\\\", \\\"{x:1255,y:839,t:1527030454461};\\\", \\\"{x:1255,y:838,t:1527030454492};\\\", \\\"{x:1256,y:838,t:1527030454507};\\\", \\\"{x:1258,y:838,t:1527030454523};\\\", \\\"{x:1259,y:837,t:1527030454538};\\\", \\\"{x:1263,y:835,t:1527030454556};\\\", \\\"{x:1265,y:834,t:1527030454572};\\\", \\\"{x:1267,y:834,t:1527030454589};\\\", \\\"{x:1270,y:832,t:1527030454606};\\\", \\\"{x:1272,y:832,t:1527030454877};\\\", \\\"{x:1273,y:831,t:1527030454889};\\\", \\\"{x:1274,y:831,t:1527030454906};\\\", \\\"{x:1275,y:830,t:1527030454922};\\\", \\\"{x:1277,y:830,t:1527030454939};\\\", \\\"{x:1278,y:829,t:1527030454955};\\\", \\\"{x:1279,y:829,t:1527030455573};\\\", \\\"{x:1280,y:829,t:1527030455587};\\\", \\\"{x:1283,y:829,t:1527030455603};\\\", \\\"{x:1288,y:833,t:1527030455621};\\\", \\\"{x:1297,y:841,t:1527030455636};\\\", \\\"{x:1306,y:848,t:1527030455654};\\\", \\\"{x:1313,y:853,t:1527030455670};\\\", \\\"{x:1318,y:857,t:1527030455686};\\\", \\\"{x:1322,y:860,t:1527030455703};\\\", \\\"{x:1327,y:862,t:1527030455719};\\\", \\\"{x:1330,y:864,t:1527030455736};\\\", \\\"{x:1334,y:866,t:1527030455753};\\\", \\\"{x:1335,y:867,t:1527030455769};\\\", \\\"{x:1337,y:868,t:1527030455786};\\\", \\\"{x:1339,y:870,t:1527030455802};\\\", \\\"{x:1340,y:871,t:1527030455820};\\\", \\\"{x:1340,y:873,t:1527030455836};\\\", \\\"{x:1343,y:875,t:1527030455853};\\\", \\\"{x:1350,y:885,t:1527030455869};\\\", \\\"{x:1355,y:891,t:1527030455886};\\\", \\\"{x:1360,y:896,t:1527030455902};\\\", \\\"{x:1362,y:899,t:1527030455919};\\\", \\\"{x:1363,y:901,t:1527030455936};\\\", \\\"{x:1363,y:902,t:1527030456132};\\\", \\\"{x:1360,y:899,t:1527030456139};\\\", \\\"{x:1354,y:893,t:1527030456152};\\\", \\\"{x:1343,y:883,t:1527030456169};\\\", \\\"{x:1339,y:879,t:1527030456185};\\\", \\\"{x:1336,y:878,t:1527030456202};\\\", \\\"{x:1336,y:877,t:1527030456218};\\\", \\\"{x:1333,y:877,t:1527030456235};\\\", \\\"{x:1331,y:877,t:1527030456260};\\\", \\\"{x:1330,y:878,t:1527030456396};\\\", \\\"{x:1330,y:880,t:1527030456403};\\\", \\\"{x:1330,y:881,t:1527030456418};\\\", \\\"{x:1330,y:884,t:1527030456434};\\\", \\\"{x:1331,y:887,t:1527030456451};\\\", \\\"{x:1333,y:892,t:1527030456468};\\\", \\\"{x:1336,y:896,t:1527030456483};\\\", \\\"{x:1339,y:899,t:1527030456501};\\\", \\\"{x:1340,y:899,t:1527030456524};\\\", \\\"{x:1341,y:900,t:1527030456534};\\\", \\\"{x:1342,y:901,t:1527030456551};\\\", \\\"{x:1342,y:902,t:1527030456568};\\\", \\\"{x:1343,y:902,t:1527030456584};\\\", \\\"{x:1344,y:902,t:1527030456685};\\\", \\\"{x:1344,y:901,t:1527030456702};\\\", \\\"{x:1345,y:899,t:1527030456717};\\\", \\\"{x:1345,y:898,t:1527030456734};\\\", \\\"{x:1345,y:900,t:1527030461228};\\\", \\\"{x:1345,y:901,t:1527030461245};\\\", \\\"{x:1344,y:902,t:1527030461262};\\\", \\\"{x:1344,y:903,t:1527030461273};\\\", \\\"{x:1343,y:905,t:1527030461290};\\\", \\\"{x:1343,y:907,t:1527030461306};\\\", \\\"{x:1341,y:910,t:1527030461323};\\\", \\\"{x:1341,y:913,t:1527030461340};\\\", \\\"{x:1341,y:914,t:1527030461364};\\\", \\\"{x:1340,y:915,t:1527030461380};\\\", \\\"{x:1340,y:916,t:1527030461390};\\\", \\\"{x:1340,y:917,t:1527030461406};\\\", \\\"{x:1340,y:919,t:1527030461423};\\\", \\\"{x:1340,y:921,t:1527030461440};\\\", \\\"{x:1340,y:923,t:1527030461456};\\\", \\\"{x:1340,y:927,t:1527030461473};\\\", \\\"{x:1340,y:930,t:1527030461491};\\\", \\\"{x:1338,y:931,t:1527030461506};\\\", \\\"{x:1338,y:932,t:1527030461523};\\\", \\\"{x:1338,y:933,t:1527030461539};\\\", \\\"{x:1339,y:930,t:1527030462445};\\\", \\\"{x:1339,y:929,t:1527030462455};\\\", \\\"{x:1342,y:926,t:1527030462472};\\\", \\\"{x:1343,y:922,t:1527030462487};\\\", \\\"{x:1345,y:917,t:1527030462505};\\\", \\\"{x:1345,y:915,t:1527030462522};\\\", \\\"{x:1346,y:912,t:1527030462538};\\\", \\\"{x:1346,y:910,t:1527030462554};\\\", \\\"{x:1346,y:909,t:1527030462571};\\\", \\\"{x:1346,y:905,t:1527030462587};\\\", \\\"{x:1347,y:901,t:1527030462605};\\\", \\\"{x:1348,y:899,t:1527030462620};\\\", \\\"{x:1348,y:898,t:1527030462637};\\\", \\\"{x:1348,y:897,t:1527030462654};\\\", \\\"{x:1348,y:896,t:1527030462671};\\\", \\\"{x:1348,y:895,t:1527030462700};\\\", \\\"{x:1348,y:894,t:1527030462708};\\\", \\\"{x:1348,y:893,t:1527030462724};\\\", \\\"{x:1348,y:892,t:1527030462749};\\\", \\\"{x:1348,y:890,t:1527030462806};\\\", \\\"{x:1348,y:889,t:1527030462820};\\\", \\\"{x:1348,y:888,t:1527030462837};\\\", \\\"{x:1347,y:886,t:1527030463020};\\\", \\\"{x:1344,y:879,t:1527030463036};\\\", \\\"{x:1342,y:875,t:1527030463053};\\\", \\\"{x:1340,y:870,t:1527030463069};\\\", \\\"{x:1337,y:865,t:1527030463086};\\\", \\\"{x:1335,y:859,t:1527030463103};\\\", \\\"{x:1333,y:853,t:1527030463119};\\\", \\\"{x:1332,y:850,t:1527030463136};\\\", \\\"{x:1331,y:846,t:1527030463152};\\\", \\\"{x:1331,y:844,t:1527030463169};\\\", \\\"{x:1331,y:841,t:1527030463186};\\\", \\\"{x:1330,y:838,t:1527030463202};\\\", \\\"{x:1330,y:835,t:1527030463219};\\\", \\\"{x:1330,y:831,t:1527030463236};\\\", \\\"{x:1330,y:830,t:1527030463293};\\\", \\\"{x:1330,y:827,t:1527030463308};\\\", \\\"{x:1330,y:826,t:1527030463319};\\\", \\\"{x:1330,y:821,t:1527030463336};\\\", \\\"{x:1330,y:817,t:1527030463352};\\\", \\\"{x:1333,y:811,t:1527030463369};\\\", \\\"{x:1335,y:806,t:1527030463385};\\\", \\\"{x:1339,y:800,t:1527030463402};\\\", \\\"{x:1342,y:795,t:1527030463418};\\\", \\\"{x:1344,y:792,t:1527030463436};\\\", \\\"{x:1347,y:784,t:1527030463452};\\\", \\\"{x:1350,y:773,t:1527030463469};\\\", \\\"{x:1354,y:756,t:1527030463485};\\\", \\\"{x:1359,y:738,t:1527030463503};\\\", \\\"{x:1365,y:713,t:1527030463519};\\\", \\\"{x:1367,y:692,t:1527030463535};\\\", \\\"{x:1370,y:668,t:1527030463552};\\\", \\\"{x:1376,y:648,t:1527030463569};\\\", \\\"{x:1383,y:627,t:1527030463586};\\\", \\\"{x:1385,y:609,t:1527030463602};\\\", \\\"{x:1389,y:591,t:1527030463619};\\\", \\\"{x:1390,y:574,t:1527030463635};\\\", \\\"{x:1390,y:559,t:1527030463652};\\\", \\\"{x:1387,y:535,t:1527030463669};\\\", \\\"{x:1381,y:523,t:1527030463686};\\\", \\\"{x:1373,y:515,t:1527030463702};\\\", \\\"{x:1361,y:510,t:1527030463718};\\\", \\\"{x:1346,y:508,t:1527030463735};\\\", \\\"{x:1324,y:508,t:1527030463751};\\\", \\\"{x:1300,y:508,t:1527030463768};\\\", \\\"{x:1269,y:512,t:1527030463784};\\\", \\\"{x:1222,y:524,t:1527030463801};\\\", \\\"{x:1179,y:531,t:1527030463818};\\\", \\\"{x:1139,y:544,t:1527030463834};\\\", \\\"{x:1100,y:555,t:1527030463851};\\\", \\\"{x:1056,y:574,t:1527030463867};\\\", \\\"{x:1005,y:595,t:1527030463884};\\\", \\\"{x:980,y:608,t:1527030463901};\\\", \\\"{x:956,y:618,t:1527030463917};\\\", \\\"{x:933,y:628,t:1527030463935};\\\", \\\"{x:913,y:636,t:1527030463952};\\\", \\\"{x:894,y:645,t:1527030463968};\\\", \\\"{x:876,y:654,t:1527030463984};\\\", \\\"{x:863,y:658,t:1527030464000};\\\", \\\"{x:849,y:662,t:1527030464017};\\\", \\\"{x:840,y:663,t:1527030464034};\\\", \\\"{x:824,y:666,t:1527030464050};\\\", \\\"{x:814,y:666,t:1527030464068};\\\", \\\"{x:801,y:666,t:1527030464084};\\\", \\\"{x:792,y:666,t:1527030464101};\\\", \\\"{x:781,y:666,t:1527030464117};\\\", \\\"{x:771,y:666,t:1527030464134};\\\", \\\"{x:761,y:662,t:1527030464150};\\\", \\\"{x:742,y:645,t:1527030464167};\\\", \\\"{x:721,y:626,t:1527030464184};\\\", \\\"{x:700,y:608,t:1527030464201};\\\", \\\"{x:688,y:599,t:1527030464217};\\\", \\\"{x:680,y:592,t:1527030464229};\\\", \\\"{x:667,y:583,t:1527030464246};\\\", \\\"{x:657,y:577,t:1527030464263};\\\", \\\"{x:647,y:570,t:1527030464280};\\\", \\\"{x:634,y:563,t:1527030464296};\\\", \\\"{x:626,y:559,t:1527030464313};\\\", \\\"{x:623,y:558,t:1527030464330};\\\", \\\"{x:622,y:557,t:1527030464346};\\\", \\\"{x:621,y:557,t:1527030464428};\\\", \\\"{x:620,y:557,t:1527030464436};\\\", \\\"{x:618,y:557,t:1527030464452};\\\", \\\"{x:616,y:557,t:1527030464463};\\\", \\\"{x:614,y:557,t:1527030464480};\\\", \\\"{x:609,y:557,t:1527030464496};\\\", \\\"{x:601,y:560,t:1527030464513};\\\", \\\"{x:596,y:561,t:1527030464531};\\\", \\\"{x:588,y:562,t:1527030464546};\\\", \\\"{x:580,y:564,t:1527030464563};\\\", \\\"{x:575,y:564,t:1527030464579};\\\", \\\"{x:563,y:566,t:1527030464596};\\\", \\\"{x:559,y:567,t:1527030464613};\\\", \\\"{x:550,y:568,t:1527030464630};\\\", \\\"{x:544,y:569,t:1527030464646};\\\", \\\"{x:533,y:570,t:1527030464663};\\\", \\\"{x:519,y:571,t:1527030464680};\\\", \\\"{x:505,y:571,t:1527030464696};\\\", \\\"{x:494,y:571,t:1527030464714};\\\", \\\"{x:480,y:571,t:1527030464729};\\\", \\\"{x:470,y:571,t:1527030464746};\\\", \\\"{x:462,y:571,t:1527030464763};\\\", \\\"{x:449,y:571,t:1527030464779};\\\", \\\"{x:441,y:571,t:1527030464797};\\\", \\\"{x:436,y:571,t:1527030464813};\\\", \\\"{x:433,y:571,t:1527030464830};\\\", \\\"{x:430,y:571,t:1527030464847};\\\", \\\"{x:427,y:571,t:1527030464863};\\\", \\\"{x:423,y:571,t:1527030464880};\\\", \\\"{x:419,y:573,t:1527030464897};\\\", \\\"{x:410,y:573,t:1527030464913};\\\", \\\"{x:399,y:573,t:1527030464930};\\\", \\\"{x:387,y:573,t:1527030464948};\\\", \\\"{x:366,y:573,t:1527030464963};\\\", \\\"{x:336,y:573,t:1527030464980};\\\", \\\"{x:319,y:573,t:1527030464997};\\\", \\\"{x:297,y:573,t:1527030465014};\\\", \\\"{x:271,y:575,t:1527030465032};\\\", \\\"{x:247,y:578,t:1527030465047};\\\", \\\"{x:224,y:579,t:1527030465063};\\\", \\\"{x:205,y:580,t:1527030465081};\\\", \\\"{x:194,y:581,t:1527030465098};\\\", \\\"{x:190,y:583,t:1527030465115};\\\", \\\"{x:188,y:584,t:1527030465130};\\\", \\\"{x:187,y:584,t:1527030465148};\\\", \\\"{x:185,y:585,t:1527030465165};\\\", \\\"{x:184,y:585,t:1527030465180};\\\", \\\"{x:182,y:587,t:1527030465197};\\\", \\\"{x:179,y:587,t:1527030465214};\\\", \\\"{x:178,y:588,t:1527030465229};\\\", \\\"{x:175,y:590,t:1527030465246};\\\", \\\"{x:174,y:590,t:1527030465340};\\\", \\\"{x:173,y:587,t:1527030465348};\\\", \\\"{x:171,y:579,t:1527030465365};\\\", \\\"{x:170,y:572,t:1527030465381};\\\", \\\"{x:168,y:566,t:1527030465397};\\\", \\\"{x:167,y:564,t:1527030465414};\\\", \\\"{x:167,y:562,t:1527030465430};\\\", \\\"{x:165,y:559,t:1527030465447};\\\", \\\"{x:165,y:556,t:1527030465465};\\\", \\\"{x:163,y:553,t:1527030465480};\\\", \\\"{x:163,y:552,t:1527030465497};\\\", \\\"{x:162,y:551,t:1527030465514};\\\", \\\"{x:165,y:554,t:1527030466029};\\\", \\\"{x:169,y:560,t:1527030466036};\\\", \\\"{x:175,y:568,t:1527030466048};\\\", \\\"{x:185,y:581,t:1527030466066};\\\", \\\"{x:206,y:598,t:1527030466082};\\\", \\\"{x:234,y:618,t:1527030466099};\\\", \\\"{x:271,y:643,t:1527030466114};\\\", \\\"{x:312,y:669,t:1527030466131};\\\", \\\"{x:372,y:703,t:1527030466147};\\\", \\\"{x:409,y:724,t:1527030466164};\\\", \\\"{x:436,y:733,t:1527030466181};\\\", \\\"{x:452,y:741,t:1527030466198};\\\", \\\"{x:459,y:742,t:1527030466214};\\\", \\\"{x:464,y:742,t:1527030466231};\\\", \\\"{x:466,y:742,t:1527030466248};\\\", \\\"{x:467,y:742,t:1527030466264};\\\", \\\"{x:469,y:742,t:1527030466281};\\\", \\\"{x:470,y:742,t:1527030466300};\\\", \\\"{x:472,y:742,t:1527030466314};\\\", \\\"{x:473,y:742,t:1527030466331};\\\", \\\"{x:476,y:741,t:1527030466348};\\\", \\\"{x:482,y:738,t:1527030466364};\\\", \\\"{x:485,y:736,t:1527030466381};\\\", \\\"{x:488,y:733,t:1527030466399};\\\", \\\"{x:491,y:730,t:1527030466414};\\\", \\\"{x:493,y:728,t:1527030466432};\\\", \\\"{x:493,y:727,t:1527030466448};\\\", \\\"{x:494,y:727,t:1527030466466};\\\", \\\"{x:495,y:726,t:1527030466492};\\\", \\\"{x:496,y:725,t:1527030466508};\\\", \\\"{x:496,y:724,t:1527030466524};\\\", \\\"{x:497,y:724,t:1527030466540};\\\", \\\"{x:497,y:723,t:1527030470301};\\\" ] }, { \\\"rt\\\": 70757, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 8, \\\"time_elapsed\\\": 301276, \\\"internal_node_id\\\": \\\"0.0-5.0-3.0\\\", \\\"subject\\\": \\\"E5L6P\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 4, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"U\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-02 PM-10 AM-C -A -Z -Z -Z -Z -Z -O -F -F -U -04 PM-U -02 PM-U -11 AM-H -O -U \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:497,y:720,t:1527030475877};\\\", \\\"{x:503,y:708,t:1527030475889};\\\", \\\"{x:515,y:673,t:1527030475907};\\\", \\\"{x:516,y:645,t:1527030475923};\\\", \\\"{x:516,y:624,t:1527030475938};\\\", \\\"{x:516,y:593,t:1527030475956};\\\", \\\"{x:515,y:567,t:1527030475973};\\\", \\\"{x:513,y:545,t:1527030475988};\\\", \\\"{x:508,y:519,t:1527030476006};\\\", \\\"{x:506,y:497,t:1527030476023};\\\", \\\"{x:506,y:480,t:1527030476040};\\\", \\\"{x:511,y:470,t:1527030476056};\\\", \\\"{x:519,y:456,t:1527030476073};\\\", \\\"{x:527,y:445,t:1527030476090};\\\", \\\"{x:530,y:440,t:1527030476106};\\\", \\\"{x:532,y:437,t:1527030476123};\\\", \\\"{x:532,y:438,t:1527030476259};\\\", \\\"{x:532,y:447,t:1527030476272};\\\", \\\"{x:532,y:465,t:1527030476289};\\\", \\\"{x:532,y:478,t:1527030476307};\\\", \\\"{x:532,y:486,t:1527030476323};\\\", \\\"{x:532,y:493,t:1527030476340};\\\", \\\"{x:532,y:495,t:1527030476356};\\\", \\\"{x:533,y:495,t:1527030476541};\\\", \\\"{x:540,y:491,t:1527030476556};\\\", \\\"{x:545,y:487,t:1527030476574};\\\", \\\"{x:550,y:483,t:1527030476590};\\\", \\\"{x:555,y:479,t:1527030476607};\\\", \\\"{x:560,y:478,t:1527030476624};\\\", \\\"{x:561,y:477,t:1527030476639};\\\", \\\"{x:565,y:476,t:1527030476657};\\\", \\\"{x:567,y:476,t:1527030476674};\\\", \\\"{x:572,y:476,t:1527030476690};\\\", \\\"{x:577,y:476,t:1527030476707};\\\", \\\"{x:589,y:476,t:1527030476724};\\\", \\\"{x:596,y:476,t:1527030476739};\\\", \\\"{x:605,y:477,t:1527030476756};\\\", \\\"{x:614,y:482,t:1527030476774};\\\", \\\"{x:627,y:487,t:1527030476790};\\\", \\\"{x:646,y:496,t:1527030476807};\\\", \\\"{x:660,y:499,t:1527030476823};\\\", \\\"{x:677,y:504,t:1527030476841};\\\", \\\"{x:697,y:510,t:1527030476858};\\\", \\\"{x:718,y:515,t:1527030476874};\\\", \\\"{x:736,y:521,t:1527030476891};\\\", \\\"{x:757,y:527,t:1527030476906};\\\", \\\"{x:787,y:535,t:1527030476923};\\\", \\\"{x:807,y:541,t:1527030476939};\\\", \\\"{x:825,y:543,t:1527030476956};\\\", \\\"{x:843,y:546,t:1527030476973};\\\", \\\"{x:853,y:547,t:1527030476990};\\\", \\\"{x:864,y:548,t:1527030477007};\\\", \\\"{x:877,y:551,t:1527030477024};\\\", \\\"{x:886,y:554,t:1527030477040};\\\", \\\"{x:891,y:555,t:1527030477056};\\\", \\\"{x:895,y:556,t:1527030477073};\\\", \\\"{x:903,y:559,t:1527030477090};\\\", \\\"{x:911,y:561,t:1527030477107};\\\", \\\"{x:929,y:569,t:1527030477123};\\\", \\\"{x:957,y:577,t:1527030477141};\\\", \\\"{x:984,y:586,t:1527030477157};\\\", \\\"{x:1027,y:602,t:1527030477174};\\\", \\\"{x:1083,y:627,t:1527030477191};\\\", \\\"{x:1141,y:651,t:1527030477207};\\\", \\\"{x:1199,y:680,t:1527030477224};\\\", \\\"{x:1263,y:709,t:1527030477240};\\\", \\\"{x:1320,y:742,t:1527030477257};\\\", \\\"{x:1358,y:764,t:1527030477274};\\\", \\\"{x:1387,y:782,t:1527030477290};\\\", \\\"{x:1405,y:794,t:1527030477307};\\\", \\\"{x:1428,y:813,t:1527030477323};\\\", \\\"{x:1439,y:828,t:1527030477341};\\\", \\\"{x:1446,y:841,t:1527030477357};\\\", \\\"{x:1460,y:857,t:1527030477373};\\\", \\\"{x:1467,y:873,t:1527030477391};\\\", \\\"{x:1476,y:896,t:1527030477408};\\\", \\\"{x:1485,y:916,t:1527030477424};\\\", \\\"{x:1490,y:933,t:1527030477441};\\\", \\\"{x:1495,y:950,t:1527030477458};\\\", \\\"{x:1498,y:959,t:1527030477474};\\\", \\\"{x:1498,y:965,t:1527030477491};\\\", \\\"{x:1500,y:973,t:1527030477509};\\\", \\\"{x:1500,y:977,t:1527030477524};\\\", \\\"{x:1500,y:981,t:1527030477541};\\\", \\\"{x:1500,y:986,t:1527030477559};\\\", \\\"{x:1500,y:990,t:1527030477574};\\\", \\\"{x:1500,y:993,t:1527030477591};\\\", \\\"{x:1498,y:1000,t:1527030477608};\\\", \\\"{x:1496,y:1005,t:1527030477625};\\\", \\\"{x:1493,y:1009,t:1527030477641};\\\", \\\"{x:1489,y:1014,t:1527030477658};\\\", \\\"{x:1484,y:1019,t:1527030477675};\\\", \\\"{x:1478,y:1022,t:1527030477690};\\\", \\\"{x:1474,y:1025,t:1527030477708};\\\", \\\"{x:1474,y:1026,t:1527030477724};\\\", \\\"{x:1471,y:1027,t:1527030477740};\\\", \\\"{x:1470,y:1028,t:1527030477764};\\\", \\\"{x:1469,y:1028,t:1527030477780};\\\", \\\"{x:1468,y:1029,t:1527030477791};\\\", \\\"{x:1467,y:1030,t:1527030477808};\\\", \\\"{x:1467,y:1031,t:1527030477825};\\\", \\\"{x:1466,y:1031,t:1527030477851};\\\", \\\"{x:1465,y:1033,t:1527030477860};\\\", \\\"{x:1465,y:1035,t:1527030477875};\\\", \\\"{x:1465,y:1042,t:1527030477892};\\\", \\\"{x:1466,y:1049,t:1527030477908};\\\", \\\"{x:1479,y:1060,t:1527030477925};\\\", \\\"{x:1497,y:1067,t:1527030477942};\\\", \\\"{x:1511,y:1074,t:1527030477958};\\\", \\\"{x:1516,y:1076,t:1527030477975};\\\", \\\"{x:1519,y:1076,t:1527030477992};\\\", \\\"{x:1522,y:1078,t:1527030478008};\\\", \\\"{x:1526,y:1078,t:1527030478026};\\\", \\\"{x:1528,y:1079,t:1527030478041};\\\", \\\"{x:1529,y:1079,t:1527030478058};\\\", \\\"{x:1530,y:1079,t:1527030478075};\\\", \\\"{x:1531,y:1079,t:1527030478141};\\\", \\\"{x:1532,y:1079,t:1527030478148};\\\", \\\"{x:1533,y:1079,t:1527030478159};\\\", \\\"{x:1536,y:1077,t:1527030478175};\\\", \\\"{x:1540,y:1073,t:1527030478192};\\\", \\\"{x:1543,y:1069,t:1527030478209};\\\", \\\"{x:1547,y:1065,t:1527030478224};\\\", \\\"{x:1549,y:1063,t:1527030478243};\\\", \\\"{x:1548,y:1063,t:1527030478445};\\\", \\\"{x:1542,y:1063,t:1527030478459};\\\", \\\"{x:1523,y:1063,t:1527030478476};\\\", \\\"{x:1504,y:1063,t:1527030478492};\\\", \\\"{x:1486,y:1063,t:1527030478509};\\\", \\\"{x:1457,y:1060,t:1527030478526};\\\", \\\"{x:1433,y:1056,t:1527030478542};\\\", \\\"{x:1399,y:1049,t:1527030478560};\\\", \\\"{x:1365,y:1043,t:1527030478576};\\\", \\\"{x:1332,y:1038,t:1527030478593};\\\", \\\"{x:1310,y:1031,t:1527030478609};\\\", \\\"{x:1289,y:1025,t:1527030478628};\\\", \\\"{x:1273,y:1018,t:1527030478643};\\\", \\\"{x:1257,y:1013,t:1527030478659};\\\", \\\"{x:1243,y:1003,t:1527030478676};\\\", \\\"{x:1234,y:997,t:1527030478693};\\\", \\\"{x:1222,y:985,t:1527030478710};\\\", \\\"{x:1211,y:971,t:1527030478727};\\\", \\\"{x:1201,y:958,t:1527030478744};\\\", \\\"{x:1194,y:944,t:1527030478761};\\\", \\\"{x:1189,y:931,t:1527030478777};\\\", \\\"{x:1185,y:918,t:1527030478794};\\\", \\\"{x:1182,y:905,t:1527030478811};\\\", \\\"{x:1181,y:894,t:1527030478827};\\\", \\\"{x:1181,y:893,t:1527030478844};\\\", \\\"{x:1181,y:890,t:1527030478860};\\\", \\\"{x:1181,y:889,t:1527030478876};\\\", \\\"{x:1181,y:887,t:1527030478894};\\\", \\\"{x:1182,y:886,t:1527030478910};\\\", \\\"{x:1184,y:883,t:1527030478927};\\\", \\\"{x:1186,y:881,t:1527030478944};\\\", \\\"{x:1189,y:877,t:1527030478960};\\\", \\\"{x:1191,y:876,t:1527030478977};\\\", \\\"{x:1193,y:874,t:1527030478993};\\\", \\\"{x:1195,y:872,t:1527030479010};\\\", \\\"{x:1198,y:868,t:1527030479028};\\\", \\\"{x:1199,y:866,t:1527030479044};\\\", \\\"{x:1202,y:863,t:1527030479060};\\\", \\\"{x:1204,y:859,t:1527030479077};\\\", \\\"{x:1205,y:857,t:1527030479094};\\\", \\\"{x:1206,y:855,t:1527030479110};\\\", \\\"{x:1206,y:853,t:1527030479127};\\\", \\\"{x:1206,y:850,t:1527030479145};\\\", \\\"{x:1207,y:847,t:1527030479160};\\\", \\\"{x:1207,y:845,t:1527030479177};\\\", \\\"{x:1207,y:843,t:1527030479195};\\\", \\\"{x:1207,y:840,t:1527030479211};\\\", \\\"{x:1207,y:836,t:1527030479227};\\\", \\\"{x:1207,y:832,t:1527030479244};\\\", \\\"{x:1207,y:830,t:1527030479260};\\\", \\\"{x:1207,y:829,t:1527030479278};\\\", \\\"{x:1207,y:828,t:1527030479295};\\\", \\\"{x:1207,y:827,t:1527030479311};\\\", \\\"{x:1207,y:826,t:1527030479328};\\\", \\\"{x:1207,y:824,t:1527030479344};\\\", \\\"{x:1207,y:823,t:1527030479364};\\\", \\\"{x:1207,y:822,t:1527030479380};\\\", \\\"{x:1207,y:821,t:1527030479412};\\\", \\\"{x:1207,y:822,t:1527030479908};\\\", \\\"{x:1207,y:823,t:1527030479917};\\\", \\\"{x:1207,y:824,t:1527030479948};\\\", \\\"{x:1207,y:825,t:1527030479964};\\\", \\\"{x:1207,y:826,t:1527030479996};\\\", \\\"{x:1208,y:828,t:1527030480140};\\\", \\\"{x:1209,y:830,t:1527030480159};\\\", \\\"{x:1210,y:831,t:1527030480195};\\\", \\\"{x:1211,y:832,t:1527030480213};\\\", \\\"{x:1212,y:833,t:1527030480228};\\\", \\\"{x:1213,y:833,t:1527030480252};\\\", \\\"{x:1213,y:834,t:1527030480268};\\\", \\\"{x:1214,y:834,t:1527030480301};\\\", \\\"{x:1215,y:834,t:1527030480780};\\\", \\\"{x:1218,y:834,t:1527030480796};\\\", \\\"{x:1222,y:834,t:1527030480814};\\\", \\\"{x:1224,y:834,t:1527030480829};\\\", \\\"{x:1225,y:833,t:1527030480846};\\\", \\\"{x:1227,y:832,t:1527030480863};\\\", \\\"{x:1228,y:832,t:1527030480892};\\\", \\\"{x:1228,y:831,t:1527030480901};\\\", \\\"{x:1229,y:830,t:1527030480916};\\\", \\\"{x:1229,y:829,t:1527030480957};\\\", \\\"{x:1230,y:829,t:1527030480997};\\\", \\\"{x:1229,y:829,t:1527030481644};\\\", \\\"{x:1228,y:829,t:1527030481669};\\\", \\\"{x:1227,y:829,t:1527030481682};\\\", \\\"{x:1226,y:829,t:1527030481697};\\\", \\\"{x:1224,y:829,t:1527030481715};\\\", \\\"{x:1223,y:829,t:1527030481732};\\\", \\\"{x:1222,y:830,t:1527030482077};\\\", \\\"{x:1222,y:831,t:1527030482085};\\\", \\\"{x:1222,y:832,t:1527030482099};\\\", \\\"{x:1222,y:834,t:1527030482116};\\\", \\\"{x:1222,y:836,t:1527030482131};\\\", \\\"{x:1224,y:840,t:1527030482148};\\\", \\\"{x:1226,y:843,t:1527030482165};\\\", \\\"{x:1227,y:846,t:1527030482183};\\\", \\\"{x:1227,y:847,t:1527030482199};\\\", \\\"{x:1229,y:849,t:1527030482216};\\\", \\\"{x:1229,y:851,t:1527030482232};\\\", \\\"{x:1230,y:852,t:1527030482248};\\\", \\\"{x:1230,y:854,t:1527030482265};\\\", \\\"{x:1232,y:857,t:1527030482283};\\\", \\\"{x:1232,y:858,t:1527030482298};\\\", \\\"{x:1233,y:860,t:1527030482315};\\\", \\\"{x:1234,y:861,t:1527030482333};\\\", \\\"{x:1234,y:862,t:1527030482349};\\\", \\\"{x:1234,y:863,t:1527030482366};\\\", \\\"{x:1236,y:863,t:1527030482445};\\\", \\\"{x:1238,y:862,t:1527030482452};\\\", \\\"{x:1241,y:860,t:1527030482465};\\\", \\\"{x:1244,y:858,t:1527030482483};\\\", \\\"{x:1247,y:856,t:1527030482499};\\\", \\\"{x:1250,y:853,t:1527030482515};\\\", \\\"{x:1253,y:851,t:1527030482531};\\\", \\\"{x:1254,y:851,t:1527030482549};\\\", \\\"{x:1257,y:849,t:1527030482564};\\\", \\\"{x:1259,y:848,t:1527030482581};\\\", \\\"{x:1261,y:847,t:1527030482599};\\\", \\\"{x:1262,y:846,t:1527030482615};\\\", \\\"{x:1263,y:845,t:1527030482631};\\\", \\\"{x:1264,y:843,t:1527030482648};\\\", \\\"{x:1265,y:843,t:1527030482667};\\\", \\\"{x:1266,y:841,t:1527030482691};\\\", \\\"{x:1267,y:841,t:1527030482723};\\\", \\\"{x:1267,y:840,t:1527030482739};\\\", \\\"{x:1268,y:840,t:1527030482749};\\\", \\\"{x:1269,y:839,t:1527030482766};\\\", \\\"{x:1270,y:838,t:1527030482782};\\\", \\\"{x:1271,y:837,t:1527030482803};\\\", \\\"{x:1272,y:836,t:1527030482843};\\\", \\\"{x:1273,y:836,t:1527030482860};\\\", \\\"{x:1274,y:836,t:1527030482876};\\\", \\\"{x:1276,y:834,t:1527030482883};\\\", \\\"{x:1276,y:833,t:1527030482899};\\\", \\\"{x:1278,y:833,t:1527030482924};\\\", \\\"{x:1279,y:832,t:1527030483316};\\\", \\\"{x:1280,y:831,t:1527030483397};\\\", \\\"{x:1281,y:830,t:1527030483412};\\\", \\\"{x:1283,y:829,t:1527030485472};\\\", \\\"{x:1284,y:829,t:1527030485504};\\\", \\\"{x:1285,y:829,t:1527030485512};\\\", \\\"{x:1290,y:830,t:1527030485525};\\\", \\\"{x:1291,y:832,t:1527030485542};\\\", \\\"{x:1292,y:835,t:1527030485558};\\\", \\\"{x:1294,y:838,t:1527030485575};\\\", \\\"{x:1296,y:842,t:1527030485591};\\\", \\\"{x:1298,y:845,t:1527030485608};\\\", \\\"{x:1305,y:854,t:1527030485625};\\\", \\\"{x:1309,y:860,t:1527030485642};\\\", \\\"{x:1312,y:864,t:1527030485659};\\\", \\\"{x:1314,y:869,t:1527030485674};\\\", \\\"{x:1317,y:871,t:1527030485691};\\\", \\\"{x:1321,y:875,t:1527030485708};\\\", \\\"{x:1324,y:879,t:1527030485725};\\\", \\\"{x:1328,y:885,t:1527030485741};\\\", \\\"{x:1331,y:888,t:1527030485758};\\\", \\\"{x:1335,y:892,t:1527030485774};\\\", \\\"{x:1339,y:895,t:1527030485792};\\\", \\\"{x:1344,y:899,t:1527030485808};\\\", \\\"{x:1345,y:900,t:1527030485841};\\\", \\\"{x:1346,y:901,t:1527030485858};\\\", \\\"{x:1347,y:902,t:1527030485928};\\\", \\\"{x:1349,y:903,t:1527030485945};\\\", \\\"{x:1349,y:904,t:1527030485959};\\\", \\\"{x:1350,y:902,t:1527030486097};\\\", \\\"{x:1350,y:900,t:1527030486120};\\\", \\\"{x:1350,y:899,t:1527030486144};\\\", \\\"{x:1350,y:897,t:1527030486167};\\\", \\\"{x:1350,y:896,t:1527030486184};\\\", \\\"{x:1350,y:895,t:1527030486191};\\\", \\\"{x:1350,y:894,t:1527030486208};\\\", \\\"{x:1349,y:893,t:1527030486225};\\\", \\\"{x:1348,y:893,t:1527030486280};\\\", \\\"{x:1348,y:891,t:1527030486311};\\\", \\\"{x:1346,y:890,t:1527030486326};\\\", \\\"{x:1346,y:889,t:1527030486351};\\\", \\\"{x:1345,y:889,t:1527030486383};\\\", \\\"{x:1344,y:889,t:1527030487016};\\\", \\\"{x:1343,y:889,t:1527030487280};\\\", \\\"{x:1343,y:890,t:1527030487295};\\\", \\\"{x:1343,y:891,t:1527030487309};\\\", \\\"{x:1344,y:893,t:1527030487327};\\\", \\\"{x:1346,y:896,t:1527030488088};\\\", \\\"{x:1346,y:897,t:1527030488095};\\\", \\\"{x:1347,y:898,t:1527030488136};\\\", \\\"{x:1347,y:897,t:1527030489272};\\\", \\\"{x:1347,y:895,t:1527030489280};\\\", \\\"{x:1347,y:891,t:1527030489298};\\\", \\\"{x:1344,y:885,t:1527030489313};\\\", \\\"{x:1341,y:880,t:1527030489331};\\\", \\\"{x:1340,y:875,t:1527030489348};\\\", \\\"{x:1337,y:870,t:1527030489364};\\\", \\\"{x:1334,y:864,t:1527030489381};\\\", \\\"{x:1332,y:859,t:1527030489397};\\\", \\\"{x:1330,y:853,t:1527030489413};\\\", \\\"{x:1325,y:839,t:1527030489432};\\\", \\\"{x:1324,y:827,t:1527030489448};\\\", \\\"{x:1324,y:815,t:1527030489464};\\\", \\\"{x:1324,y:801,t:1527030489480};\\\", \\\"{x:1324,y:789,t:1527030489497};\\\", \\\"{x:1324,y:776,t:1527030489514};\\\", \\\"{x:1323,y:757,t:1527030489530};\\\", \\\"{x:1323,y:741,t:1527030489547};\\\", \\\"{x:1323,y:727,t:1527030489565};\\\", \\\"{x:1323,y:712,t:1527030489581};\\\", \\\"{x:1323,y:701,t:1527030489597};\\\", \\\"{x:1323,y:690,t:1527030489614};\\\", \\\"{x:1323,y:676,t:1527030489632};\\\", \\\"{x:1320,y:665,t:1527030489648};\\\", \\\"{x:1319,y:658,t:1527030489664};\\\", \\\"{x:1318,y:652,t:1527030489681};\\\", \\\"{x:1317,y:649,t:1527030489697};\\\", \\\"{x:1316,y:648,t:1527030489728};\\\", \\\"{x:1316,y:646,t:1527030490729};\\\", \\\"{x:1316,y:644,t:1527030490736};\\\", \\\"{x:1316,y:643,t:1527030490749};\\\", \\\"{x:1316,y:640,t:1527030490765};\\\", \\\"{x:1315,y:638,t:1527030490783};\\\", \\\"{x:1315,y:634,t:1527030490800};\\\", \\\"{x:1314,y:633,t:1527030490816};\\\", \\\"{x:1314,y:631,t:1527030490840};\\\", \\\"{x:1314,y:632,t:1527030506360};\\\", \\\"{x:1314,y:633,t:1527030506375};\\\", \\\"{x:1314,y:634,t:1527030506390};\\\", \\\"{x:1314,y:635,t:1527030506407};\\\", \\\"{x:1314,y:636,t:1527030506426};\\\", \\\"{x:1314,y:637,t:1527030506441};\\\", \\\"{x:1314,y:638,t:1527030506464};\\\", \\\"{x:1314,y:639,t:1527030506479};\\\", \\\"{x:1314,y:640,t:1527030506495};\\\", \\\"{x:1316,y:643,t:1527030506512};\\\", \\\"{x:1317,y:647,t:1527030506527};\\\", \\\"{x:1318,y:650,t:1527030506541};\\\", \\\"{x:1321,y:659,t:1527030506557};\\\", \\\"{x:1326,y:670,t:1527030506574};\\\", \\\"{x:1335,y:688,t:1527030506592};\\\", \\\"{x:1341,y:696,t:1527030506608};\\\", \\\"{x:1346,y:704,t:1527030506625};\\\", \\\"{x:1354,y:714,t:1527030506641};\\\", \\\"{x:1362,y:725,t:1527030506657};\\\", \\\"{x:1368,y:734,t:1527030506675};\\\", \\\"{x:1373,y:739,t:1527030506691};\\\", \\\"{x:1375,y:742,t:1527030506708};\\\", \\\"{x:1377,y:744,t:1527030506725};\\\", \\\"{x:1377,y:745,t:1527030506743};\\\", \\\"{x:1378,y:746,t:1527030506760};\\\", \\\"{x:1378,y:747,t:1527030506774};\\\", \\\"{x:1380,y:749,t:1527030506791};\\\", \\\"{x:1380,y:751,t:1527030506808};\\\", \\\"{x:1381,y:753,t:1527030506832};\\\", \\\"{x:1381,y:754,t:1527030506880};\\\", \\\"{x:1382,y:754,t:1527030506903};\\\", \\\"{x:1382,y:755,t:1527030506935};\\\", \\\"{x:1382,y:756,t:1527030506943};\\\", \\\"{x:1383,y:757,t:1527030506958};\\\", \\\"{x:1384,y:758,t:1527030506975};\\\", \\\"{x:1384,y:759,t:1527030506991};\\\", \\\"{x:1384,y:760,t:1527030507007};\\\", \\\"{x:1384,y:761,t:1527030507031};\\\", \\\"{x:1385,y:761,t:1527030507055};\\\", \\\"{x:1385,y:762,t:1527030507320};\\\", \\\"{x:1385,y:763,t:1527030507328};\\\", \\\"{x:1385,y:764,t:1527030507342};\\\", \\\"{x:1385,y:765,t:1527030507359};\\\", \\\"{x:1384,y:765,t:1527030508648};\\\", \\\"{x:1383,y:765,t:1527030509303};\\\", \\\"{x:1382,y:765,t:1527030509327};\\\", \\\"{x:1381,y:765,t:1527030509345};\\\", \\\"{x:1379,y:765,t:1527030509362};\\\", \\\"{x:1378,y:765,t:1527030509378};\\\", \\\"{x:1377,y:765,t:1527030509395};\\\", \\\"{x:1376,y:765,t:1527030509412};\\\", \\\"{x:1375,y:765,t:1527030509429};\\\", \\\"{x:1374,y:764,t:1527030517768};\\\", \\\"{x:1374,y:760,t:1527030517775};\\\", \\\"{x:1374,y:756,t:1527030517791};\\\", \\\"{x:1374,y:752,t:1527030517809};\\\", \\\"{x:1374,y:750,t:1527030517826};\\\", \\\"{x:1374,y:747,t:1527030517842};\\\", \\\"{x:1374,y:746,t:1527030517858};\\\", \\\"{x:1374,y:744,t:1527030517876};\\\", \\\"{x:1373,y:741,t:1527030517892};\\\", \\\"{x:1373,y:739,t:1527030517908};\\\", \\\"{x:1373,y:736,t:1527030517926};\\\", \\\"{x:1373,y:730,t:1527030517943};\\\", \\\"{x:1373,y:726,t:1527030517958};\\\", \\\"{x:1375,y:717,t:1527030517975};\\\", \\\"{x:1376,y:711,t:1527030517992};\\\", \\\"{x:1379,y:704,t:1527030518009};\\\", \\\"{x:1380,y:699,t:1527030518026};\\\", \\\"{x:1382,y:693,t:1527030518042};\\\", \\\"{x:1383,y:687,t:1527030518058};\\\", \\\"{x:1387,y:679,t:1527030518075};\\\", \\\"{x:1388,y:673,t:1527030518093};\\\", \\\"{x:1391,y:667,t:1527030518109};\\\", \\\"{x:1392,y:664,t:1527030518125};\\\", \\\"{x:1393,y:660,t:1527030518143};\\\", \\\"{x:1394,y:654,t:1527030518160};\\\", \\\"{x:1395,y:650,t:1527030518176};\\\", \\\"{x:1396,y:646,t:1527030518193};\\\", \\\"{x:1398,y:642,t:1527030518210};\\\", \\\"{x:1398,y:639,t:1527030518226};\\\", \\\"{x:1399,y:636,t:1527030518243};\\\", \\\"{x:1399,y:635,t:1527030518263};\\\", \\\"{x:1399,y:634,t:1527030518600};\\\", \\\"{x:1399,y:633,t:1527030518610};\\\", \\\"{x:1399,y:632,t:1527030518632};\\\", \\\"{x:1401,y:636,t:1527030522472};\\\", \\\"{x:1405,y:647,t:1527030522482};\\\", \\\"{x:1408,y:665,t:1527030522499};\\\", \\\"{x:1409,y:683,t:1527030522516};\\\", \\\"{x:1409,y:700,t:1527030522533};\\\", \\\"{x:1409,y:715,t:1527030522550};\\\", \\\"{x:1410,y:726,t:1527030522566};\\\", \\\"{x:1410,y:730,t:1527030522583};\\\", \\\"{x:1410,y:732,t:1527030522599};\\\", \\\"{x:1411,y:733,t:1527030522616};\\\", \\\"{x:1414,y:736,t:1527030522633};\\\", \\\"{x:1418,y:742,t:1527030522650};\\\", \\\"{x:1422,y:747,t:1527030522665};\\\", \\\"{x:1429,y:757,t:1527030522683};\\\", \\\"{x:1437,y:768,t:1527030522699};\\\", \\\"{x:1448,y:783,t:1527030522717};\\\", \\\"{x:1461,y:799,t:1527030522732};\\\", \\\"{x:1475,y:810,t:1527030522749};\\\", \\\"{x:1491,y:825,t:1527030522767};\\\", \\\"{x:1503,y:836,t:1527030522782};\\\", \\\"{x:1519,y:855,t:1527030522800};\\\", \\\"{x:1528,y:868,t:1527030522817};\\\", \\\"{x:1533,y:877,t:1527030522834};\\\", \\\"{x:1536,y:883,t:1527030522849};\\\", \\\"{x:1537,y:886,t:1527030522867};\\\", \\\"{x:1538,y:888,t:1527030522882};\\\", \\\"{x:1538,y:889,t:1527030522900};\\\", \\\"{x:1538,y:890,t:1527030522917};\\\", \\\"{x:1538,y:891,t:1527030523024};\\\", \\\"{x:1536,y:891,t:1527030523039};\\\", \\\"{x:1531,y:888,t:1527030523049};\\\", \\\"{x:1524,y:885,t:1527030523067};\\\", \\\"{x:1516,y:882,t:1527030523084};\\\", \\\"{x:1511,y:878,t:1527030523100};\\\", \\\"{x:1508,y:877,t:1527030523117};\\\", \\\"{x:1505,y:875,t:1527030523134};\\\", \\\"{x:1501,y:871,t:1527030523151};\\\", \\\"{x:1498,y:870,t:1527030523167};\\\", \\\"{x:1496,y:868,t:1527030523183};\\\", \\\"{x:1494,y:867,t:1527030523201};\\\", \\\"{x:1492,y:865,t:1527030523216};\\\", \\\"{x:1491,y:864,t:1527030523234};\\\", \\\"{x:1489,y:864,t:1527030523251};\\\", \\\"{x:1488,y:864,t:1527030523267};\\\", \\\"{x:1486,y:862,t:1527030523284};\\\", \\\"{x:1485,y:861,t:1527030523300};\\\", \\\"{x:1484,y:860,t:1527030523317};\\\", \\\"{x:1483,y:859,t:1527030523334};\\\", \\\"{x:1481,y:857,t:1527030523352};\\\", \\\"{x:1481,y:856,t:1527030523376};\\\", \\\"{x:1481,y:855,t:1527030523399};\\\", \\\"{x:1481,y:853,t:1527030523418};\\\", \\\"{x:1480,y:851,t:1527030523434};\\\", \\\"{x:1480,y:847,t:1527030523451};\\\", \\\"{x:1480,y:844,t:1527030523468};\\\", \\\"{x:1480,y:840,t:1527030523484};\\\", \\\"{x:1480,y:838,t:1527030523500};\\\", \\\"{x:1480,y:837,t:1527030523518};\\\", \\\"{x:1480,y:836,t:1527030523534};\\\", \\\"{x:1480,y:835,t:1527030523560};\\\", \\\"{x:1480,y:834,t:1527030523567};\\\", \\\"{x:1480,y:833,t:1527030523584};\\\", \\\"{x:1480,y:832,t:1527030523614};\\\", \\\"{x:1479,y:832,t:1527030525663};\\\", \\\"{x:1475,y:830,t:1527030525672};\\\", \\\"{x:1461,y:829,t:1527030525687};\\\", \\\"{x:1448,y:827,t:1527030525704};\\\", \\\"{x:1429,y:824,t:1527030525720};\\\", \\\"{x:1404,y:822,t:1527030525738};\\\", \\\"{x:1376,y:817,t:1527030525755};\\\", \\\"{x:1345,y:812,t:1527030525771};\\\", \\\"{x:1303,y:799,t:1527030525788};\\\", \\\"{x:1249,y:789,t:1527030525804};\\\", \\\"{x:1190,y:771,t:1527030525821};\\\", \\\"{x:1127,y:755,t:1527030525838};\\\", \\\"{x:1019,y:725,t:1527030525855};\\\", \\\"{x:947,y:709,t:1527030525871};\\\", \\\"{x:883,y:690,t:1527030525888};\\\", \\\"{x:826,y:670,t:1527030525905};\\\", \\\"{x:763,y:643,t:1527030525921};\\\", \\\"{x:722,y:626,t:1527030525939};\\\", \\\"{x:695,y:615,t:1527030525954};\\\", \\\"{x:657,y:598,t:1527030525971};\\\", \\\"{x:589,y:568,t:1527030525998};\\\", \\\"{x:534,y:546,t:1527030526013};\\\", \\\"{x:479,y:523,t:1527030526034};\\\", \\\"{x:458,y:512,t:1527030526050};\\\", \\\"{x:440,y:502,t:1527030526067};\\\", \\\"{x:424,y:493,t:1527030526084};\\\", \\\"{x:416,y:487,t:1527030526100};\\\", \\\"{x:413,y:486,t:1527030526116};\\\", \\\"{x:414,y:489,t:1527030526222};\\\", \\\"{x:424,y:496,t:1527030526233};\\\", \\\"{x:446,y:507,t:1527030526251};\\\", \\\"{x:469,y:521,t:1527030526267};\\\", \\\"{x:488,y:532,t:1527030526283};\\\", \\\"{x:508,y:543,t:1527030526300};\\\", \\\"{x:531,y:556,t:1527030526318};\\\", \\\"{x:551,y:567,t:1527030526333};\\\", \\\"{x:576,y:580,t:1527030526351};\\\", \\\"{x:592,y:586,t:1527030526367};\\\", \\\"{x:597,y:589,t:1527030526383};\\\", \\\"{x:602,y:591,t:1527030526400};\\\", \\\"{x:604,y:592,t:1527030526417};\\\", \\\"{x:606,y:593,t:1527030526446};\\\", \\\"{x:607,y:595,t:1527030526568};\\\", \\\"{x:612,y:597,t:1527030527432};\\\", \\\"{x:627,y:604,t:1527030527439};\\\", \\\"{x:642,y:614,t:1527030527451};\\\", \\\"{x:716,y:644,t:1527030527467};\\\", \\\"{x:818,y:689,t:1527030527485};\\\", \\\"{x:931,y:737,t:1527030527502};\\\", \\\"{x:1039,y:789,t:1527030527517};\\\", \\\"{x:1193,y:861,t:1527030527534};\\\", \\\"{x:1303,y:909,t:1527030527552};\\\", \\\"{x:1408,y:954,t:1527030527568};\\\", \\\"{x:1495,y:989,t:1527030527584};\\\", \\\"{x:1544,y:1008,t:1527030527601};\\\", \\\"{x:1568,y:1013,t:1527030527618};\\\", \\\"{x:1578,y:1014,t:1527030527634};\\\", \\\"{x:1580,y:1014,t:1527030527652};\\\", \\\"{x:1581,y:1014,t:1527030527669};\\\", \\\"{x:1582,y:1013,t:1527030527684};\\\", \\\"{x:1585,y:1009,t:1527030527702};\\\", \\\"{x:1591,y:1004,t:1527030527719};\\\", \\\"{x:1599,y:999,t:1527030527734};\\\", \\\"{x:1609,y:988,t:1527030527751};\\\", \\\"{x:1614,y:977,t:1527030527769};\\\", \\\"{x:1615,y:966,t:1527030527785};\\\", \\\"{x:1615,y:951,t:1527030527802};\\\", \\\"{x:1609,y:931,t:1527030527819};\\\", \\\"{x:1604,y:915,t:1527030527835};\\\", \\\"{x:1595,y:899,t:1527030527852};\\\", \\\"{x:1590,y:892,t:1527030527868};\\\", \\\"{x:1586,y:887,t:1527030527885};\\\", \\\"{x:1580,y:882,t:1527030527902};\\\", \\\"{x:1567,y:877,t:1527030527918};\\\", \\\"{x:1554,y:875,t:1527030527934};\\\", \\\"{x:1539,y:868,t:1527030527952};\\\", \\\"{x:1520,y:859,t:1527030527969};\\\", \\\"{x:1502,y:852,t:1527030527985};\\\", \\\"{x:1490,y:845,t:1527030528002};\\\", \\\"{x:1482,y:844,t:1527030528019};\\\", \\\"{x:1479,y:842,t:1527030528035};\\\", \\\"{x:1478,y:842,t:1527030528256};\\\", \\\"{x:1478,y:840,t:1527030528269};\\\", \\\"{x:1478,y:834,t:1527030528286};\\\", \\\"{x:1478,y:826,t:1527030528302};\\\", \\\"{x:1475,y:816,t:1527030528320};\\\", \\\"{x:1474,y:810,t:1527030528335};\\\", \\\"{x:1472,y:801,t:1527030528352};\\\", \\\"{x:1469,y:796,t:1527030528369};\\\", \\\"{x:1467,y:787,t:1527030528386};\\\", \\\"{x:1465,y:778,t:1527030528402};\\\", \\\"{x:1462,y:771,t:1527030528419};\\\", \\\"{x:1461,y:762,t:1527030528436};\\\", \\\"{x:1456,y:749,t:1527030528452};\\\", \\\"{x:1454,y:737,t:1527030528469};\\\", \\\"{x:1451,y:724,t:1527030528486};\\\", \\\"{x:1450,y:713,t:1527030528502};\\\", \\\"{x:1449,y:699,t:1527030528519};\\\", \\\"{x:1449,y:689,t:1527030528535};\\\", \\\"{x:1449,y:678,t:1527030528552};\\\", \\\"{x:1452,y:666,t:1527030528569};\\\", \\\"{x:1454,y:657,t:1527030528586};\\\", \\\"{x:1458,y:649,t:1527030528603};\\\", \\\"{x:1461,y:644,t:1527030528619};\\\", \\\"{x:1462,y:641,t:1527030528636};\\\", \\\"{x:1464,y:637,t:1527030528653};\\\", \\\"{x:1465,y:631,t:1527030528669};\\\", \\\"{x:1465,y:622,t:1527030528686};\\\", \\\"{x:1467,y:609,t:1527030528703};\\\", \\\"{x:1469,y:604,t:1527030528719};\\\", \\\"{x:1469,y:598,t:1527030528736};\\\", \\\"{x:1469,y:595,t:1527030528753};\\\", \\\"{x:1469,y:594,t:1527030528769};\\\", \\\"{x:1469,y:591,t:1527030528786};\\\", \\\"{x:1469,y:590,t:1527030528807};\\\", \\\"{x:1469,y:577,t:1527030529103};\\\", \\\"{x:1451,y:503,t:1527030529120};\\\", \\\"{x:1421,y:406,t:1527030529136};\\\", \\\"{x:1402,y:342,t:1527030529153};\\\", \\\"{x:1401,y:315,t:1527030529170};\\\", \\\"{x:1401,y:289,t:1527030529186};\\\", \\\"{x:1401,y:268,t:1527030529203};\\\", \\\"{x:1403,y:244,t:1527030529220};\\\", \\\"{x:1403,y:222,t:1527030529236};\\\", \\\"{x:1403,y:197,t:1527030529253};\\\", \\\"{x:1403,y:178,t:1527030529270};\\\", \\\"{x:1403,y:165,t:1527030529286};\\\", \\\"{x:1404,y:153,t:1527030529303};\\\", \\\"{x:1405,y:148,t:1527030529320};\\\", \\\"{x:1406,y:145,t:1527030529336};\\\", \\\"{x:1407,y:142,t:1527030529353};\\\", \\\"{x:1408,y:141,t:1527030529370};\\\", \\\"{x:1408,y:139,t:1527030529386};\\\", \\\"{x:1409,y:138,t:1527030529403};\\\", \\\"{x:1410,y:137,t:1527030529420};\\\", \\\"{x:1411,y:137,t:1527030529439};\\\", \\\"{x:1413,y:137,t:1527030529479};\\\", \\\"{x:1414,y:137,t:1527030529495};\\\", \\\"{x:1415,y:137,t:1527030529519};\\\", \\\"{x:1416,y:137,t:1527030529537};\\\", \\\"{x:1417,y:137,t:1527030529553};\\\", \\\"{x:1418,y:138,t:1527030529570};\\\", \\\"{x:1420,y:140,t:1527030529587};\\\", \\\"{x:1424,y:146,t:1527030529603};\\\", \\\"{x:1429,y:156,t:1527030529620};\\\", \\\"{x:1436,y:172,t:1527030529638};\\\", \\\"{x:1442,y:191,t:1527030529654};\\\", \\\"{x:1448,y:214,t:1527030529671};\\\", \\\"{x:1470,y:283,t:1527030529687};\\\", \\\"{x:1485,y:336,t:1527030529703};\\\", \\\"{x:1499,y:409,t:1527030529720};\\\", \\\"{x:1510,y:484,t:1527030529737};\\\", \\\"{x:1521,y:578,t:1527030529753};\\\", \\\"{x:1537,y:689,t:1527030529770};\\\", \\\"{x:1552,y:805,t:1527030529787};\\\", \\\"{x:1561,y:907,t:1527030529803};\\\", \\\"{x:1570,y:982,t:1527030529820};\\\", \\\"{x:1572,y:1035,t:1527030529837};\\\", \\\"{x:1572,y:1075,t:1527030529853};\\\", \\\"{x:1572,y:1111,t:1527030529870};\\\", \\\"{x:1572,y:1151,t:1527030529886};\\\", \\\"{x:1569,y:1170,t:1527030529903};\\\", \\\"{x:1564,y:1183,t:1527030529919};\\\", \\\"{x:1562,y:1186,t:1527030529937};\\\", \\\"{x:1561,y:1186,t:1527030529967};\\\", \\\"{x:1560,y:1186,t:1527030529974};\\\", \\\"{x:1555,y:1177,t:1527030529987};\\\", \\\"{x:1540,y:1138,t:1527030530004};\\\", \\\"{x:1516,y:1057,t:1527030530020};\\\", \\\"{x:1495,y:969,t:1527030530037};\\\", \\\"{x:1486,y:920,t:1527030530054};\\\", \\\"{x:1483,y:898,t:1527030530070};\\\", \\\"{x:1481,y:877,t:1527030530087};\\\", \\\"{x:1478,y:862,t:1527030530103};\\\", \\\"{x:1471,y:842,t:1527030530120};\\\", \\\"{x:1464,y:823,t:1527030530137};\\\", \\\"{x:1462,y:815,t:1527030530154};\\\", \\\"{x:1462,y:812,t:1527030530170};\\\", \\\"{x:1462,y:810,t:1527030530187};\\\", \\\"{x:1462,y:809,t:1527030530204};\\\", \\\"{x:1462,y:807,t:1527030530220};\\\", \\\"{x:1464,y:808,t:1527030530328};\\\", \\\"{x:1473,y:818,t:1527030530337};\\\", \\\"{x:1492,y:840,t:1527030530354};\\\", \\\"{x:1502,y:854,t:1527030530370};\\\", \\\"{x:1505,y:860,t:1527030530387};\\\", \\\"{x:1506,y:864,t:1527030530404};\\\", \\\"{x:1508,y:868,t:1527030530420};\\\", \\\"{x:1508,y:866,t:1527030530520};\\\", \\\"{x:1508,y:856,t:1527030530538};\\\", \\\"{x:1508,y:847,t:1527030530555};\\\", \\\"{x:1508,y:840,t:1527030530571};\\\", \\\"{x:1508,y:836,t:1527030530587};\\\", \\\"{x:1508,y:833,t:1527030530604};\\\", \\\"{x:1508,y:832,t:1527030530621};\\\", \\\"{x:1508,y:829,t:1527030530637};\\\", \\\"{x:1508,y:826,t:1527030530655};\\\", \\\"{x:1507,y:825,t:1527030530671};\\\", \\\"{x:1507,y:824,t:1527030530687};\\\", \\\"{x:1506,y:823,t:1527030530711};\\\", \\\"{x:1504,y:823,t:1527030530735};\\\", \\\"{x:1503,y:823,t:1527030530743};\\\", \\\"{x:1501,y:822,t:1527030530754};\\\", \\\"{x:1496,y:821,t:1527030530771};\\\", \\\"{x:1492,y:821,t:1527030530787};\\\", \\\"{x:1488,y:821,t:1527030530804};\\\", \\\"{x:1485,y:821,t:1527030530822};\\\", \\\"{x:1484,y:821,t:1527030530837};\\\", \\\"{x:1482,y:821,t:1527030530927};\\\", \\\"{x:1481,y:821,t:1527030530937};\\\", \\\"{x:1480,y:821,t:1527030530954};\\\", \\\"{x:1479,y:821,t:1527030530971};\\\", \\\"{x:1478,y:821,t:1527030530988};\\\", \\\"{x:1477,y:821,t:1527030531183};\\\", \\\"{x:1477,y:822,t:1527030531199};\\\", \\\"{x:1477,y:823,t:1527030531207};\\\", \\\"{x:1474,y:826,t:1527030531224};\\\", \\\"{x:1473,y:827,t:1527030531239};\\\", \\\"{x:1473,y:828,t:1527030531254};\\\", \\\"{x:1472,y:828,t:1527030531271};\\\", \\\"{x:1472,y:829,t:1527030531664};\\\", \\\"{x:1471,y:829,t:1527030531671};\\\", \\\"{x:1471,y:830,t:1527030531808};\\\", \\\"{x:1469,y:830,t:1527030531839};\\\", \\\"{x:1469,y:831,t:1527030531855};\\\", \\\"{x:1468,y:831,t:1527030531879};\\\", \\\"{x:1461,y:834,t:1527030532935};\\\", \\\"{x:1455,y:840,t:1527030532943};\\\", \\\"{x:1444,y:848,t:1527030532956};\\\", \\\"{x:1423,y:867,t:1527030532972};\\\", \\\"{x:1389,y:892,t:1527030532990};\\\", \\\"{x:1352,y:922,t:1527030533006};\\\", \\\"{x:1308,y:963,t:1527030533023};\\\", \\\"{x:1272,y:1009,t:1527030533039};\\\", \\\"{x:1268,y:1014,t:1527030533056};\\\", \\\"{x:1270,y:1008,t:1527030533184};\\\", \\\"{x:1277,y:995,t:1527030533191};\\\", \\\"{x:1283,y:982,t:1527030533206};\\\", \\\"{x:1293,y:960,t:1527030533223};\\\", \\\"{x:1301,y:927,t:1527030533239};\\\", \\\"{x:1306,y:909,t:1527030533256};\\\", \\\"{x:1311,y:892,t:1527030533272};\\\", \\\"{x:1317,y:870,t:1527030533290};\\\", \\\"{x:1322,y:840,t:1527030533306};\\\", \\\"{x:1327,y:808,t:1527030533323};\\\", \\\"{x:1329,y:772,t:1527030533339};\\\", \\\"{x:1334,y:742,t:1527030533356};\\\", \\\"{x:1339,y:720,t:1527030533373};\\\", \\\"{x:1340,y:698,t:1527030533389};\\\", \\\"{x:1343,y:676,t:1527030533407};\\\", \\\"{x:1343,y:638,t:1527030533423};\\\", \\\"{x:1342,y:616,t:1527030533439};\\\", \\\"{x:1342,y:594,t:1527030533456};\\\", \\\"{x:1343,y:572,t:1527030533473};\\\", \\\"{x:1347,y:555,t:1527030533490};\\\", \\\"{x:1352,y:542,t:1527030533507};\\\", \\\"{x:1355,y:539,t:1527030533523};\\\", \\\"{x:1356,y:539,t:1527030533615};\\\", \\\"{x:1357,y:539,t:1527030533623};\\\", \\\"{x:1364,y:547,t:1527030533639};\\\", \\\"{x:1374,y:562,t:1527030533656};\\\", \\\"{x:1384,y:577,t:1527030533673};\\\", \\\"{x:1392,y:587,t:1527030533690};\\\", \\\"{x:1397,y:594,t:1527030533706};\\\", \\\"{x:1400,y:595,t:1527030533723};\\\", \\\"{x:1401,y:596,t:1527030533740};\\\", \\\"{x:1402,y:596,t:1527030533792};\\\", \\\"{x:1403,y:596,t:1527030533807};\\\", \\\"{x:1407,y:589,t:1527030533824};\\\", \\\"{x:1409,y:582,t:1527030533841};\\\", \\\"{x:1413,y:576,t:1527030533857};\\\", \\\"{x:1416,y:572,t:1527030533873};\\\", \\\"{x:1416,y:571,t:1527030534086};\\\", \\\"{x:1417,y:571,t:1527030534118};\\\", \\\"{x:1418,y:571,t:1527030534150};\\\", \\\"{x:1418,y:570,t:1527030534463};\\\", \\\"{x:1418,y:569,t:1527030534473};\\\", \\\"{x:1417,y:569,t:1527030534491};\\\", \\\"{x:1415,y:569,t:1527030534507};\\\", \\\"{x:1414,y:569,t:1527030534640};\\\", \\\"{x:1413,y:568,t:1527030534657};\\\", \\\"{x:1412,y:568,t:1527030534673};\\\", \\\"{x:1411,y:568,t:1527030537521};\\\", \\\"{x:1406,y:568,t:1527030537592};\\\", \\\"{x:1401,y:568,t:1527030537609};\\\", \\\"{x:1396,y:572,t:1527030537626};\\\", \\\"{x:1392,y:578,t:1527030537642};\\\", \\\"{x:1387,y:584,t:1527030537659};\\\", \\\"{x:1384,y:590,t:1527030537676};\\\", \\\"{x:1379,y:599,t:1527030537692};\\\", \\\"{x:1376,y:604,t:1527030537709};\\\", \\\"{x:1374,y:608,t:1527030537726};\\\", \\\"{x:1372,y:614,t:1527030537742};\\\", \\\"{x:1370,y:622,t:1527030537759};\\\", \\\"{x:1369,y:629,t:1527030537776};\\\", \\\"{x:1369,y:636,t:1527030537793};\\\", \\\"{x:1369,y:643,t:1527030537809};\\\", \\\"{x:1369,y:650,t:1527030537826};\\\", \\\"{x:1370,y:660,t:1527030537842};\\\", \\\"{x:1376,y:679,t:1527030537859};\\\", \\\"{x:1386,y:698,t:1527030537876};\\\", \\\"{x:1391,y:714,t:1527030537893};\\\", \\\"{x:1396,y:725,t:1527030537909};\\\", \\\"{x:1401,y:735,t:1527030537927};\\\", \\\"{x:1406,y:749,t:1527030537943};\\\", \\\"{x:1416,y:771,t:1527030537959};\\\", \\\"{x:1421,y:792,t:1527030537977};\\\", \\\"{x:1425,y:807,t:1527030537994};\\\", \\\"{x:1426,y:815,t:1527030538010};\\\", \\\"{x:1427,y:822,t:1527030538026};\\\", \\\"{x:1428,y:828,t:1527030538042};\\\", \\\"{x:1428,y:832,t:1527030538059};\\\", \\\"{x:1428,y:835,t:1527030538076};\\\", \\\"{x:1428,y:836,t:1527030538152};\\\", \\\"{x:1428,y:837,t:1527030538159};\\\", \\\"{x:1428,y:838,t:1527030538176};\\\", \\\"{x:1428,y:839,t:1527030538193};\\\", \\\"{x:1428,y:841,t:1527030538209};\\\", \\\"{x:1427,y:842,t:1527030538227};\\\", \\\"{x:1423,y:848,t:1527030538243};\\\", \\\"{x:1421,y:852,t:1527030538260};\\\", \\\"{x:1418,y:864,t:1527030538276};\\\", \\\"{x:1417,y:873,t:1527030538293};\\\", \\\"{x:1413,y:882,t:1527030538310};\\\", \\\"{x:1410,y:894,t:1527030538326};\\\", \\\"{x:1404,y:907,t:1527030538343};\\\", \\\"{x:1402,y:912,t:1527030538360};\\\", \\\"{x:1401,y:917,t:1527030538377};\\\", \\\"{x:1401,y:923,t:1527030538393};\\\", \\\"{x:1400,y:926,t:1527030538410};\\\", \\\"{x:1400,y:928,t:1527030538427};\\\", \\\"{x:1400,y:929,t:1527030538443};\\\", \\\"{x:1399,y:931,t:1527030538459};\\\", \\\"{x:1399,y:933,t:1527030538476};\\\", \\\"{x:1399,y:936,t:1527030538494};\\\", \\\"{x:1399,y:939,t:1527030538510};\\\", \\\"{x:1397,y:942,t:1527030538527};\\\", \\\"{x:1397,y:944,t:1527030538543};\\\", \\\"{x:1396,y:948,t:1527030538560};\\\", \\\"{x:1395,y:952,t:1527030538576};\\\", \\\"{x:1394,y:959,t:1527030538594};\\\", \\\"{x:1392,y:968,t:1527030538610};\\\", \\\"{x:1390,y:975,t:1527030538626};\\\", \\\"{x:1389,y:977,t:1527030538643};\\\", \\\"{x:1388,y:980,t:1527030538660};\\\", \\\"{x:1387,y:982,t:1527030538677};\\\", \\\"{x:1386,y:978,t:1527030538799};\\\", \\\"{x:1385,y:971,t:1527030538810};\\\", \\\"{x:1383,y:950,t:1527030538827};\\\", \\\"{x:1381,y:932,t:1527030538844};\\\", \\\"{x:1380,y:914,t:1527030538860};\\\", \\\"{x:1380,y:902,t:1527030538876};\\\", \\\"{x:1379,y:888,t:1527030538893};\\\", \\\"{x:1376,y:875,t:1527030538910};\\\", \\\"{x:1375,y:866,t:1527030538926};\\\", \\\"{x:1373,y:857,t:1527030538943};\\\", \\\"{x:1373,y:853,t:1527030538961};\\\", \\\"{x:1373,y:847,t:1527030538977};\\\", \\\"{x:1373,y:843,t:1527030538993};\\\", \\\"{x:1373,y:838,t:1527030539011};\\\", \\\"{x:1373,y:832,t:1527030539026};\\\", \\\"{x:1373,y:828,t:1527030539044};\\\", \\\"{x:1373,y:824,t:1527030539060};\\\", \\\"{x:1373,y:818,t:1527030539077};\\\", \\\"{x:1373,y:812,t:1527030539094};\\\", \\\"{x:1373,y:805,t:1527030539111};\\\", \\\"{x:1373,y:797,t:1527030539127};\\\", \\\"{x:1373,y:790,t:1527030539143};\\\", \\\"{x:1373,y:784,t:1527030539160};\\\", \\\"{x:1373,y:777,t:1527030539178};\\\", \\\"{x:1373,y:769,t:1527030539193};\\\", \\\"{x:1373,y:761,t:1527030539211};\\\", \\\"{x:1373,y:751,t:1527030539227};\\\", \\\"{x:1373,y:740,t:1527030539244};\\\", \\\"{x:1373,y:731,t:1527030539260};\\\", \\\"{x:1373,y:725,t:1527030539278};\\\", \\\"{x:1371,y:718,t:1527030539294};\\\", \\\"{x:1371,y:714,t:1527030539310};\\\", \\\"{x:1371,y:708,t:1527030539327};\\\", \\\"{x:1370,y:705,t:1527030539343};\\\", \\\"{x:1370,y:701,t:1527030539361};\\\", \\\"{x:1370,y:698,t:1527030539377};\\\", \\\"{x:1370,y:696,t:1527030539394};\\\", \\\"{x:1370,y:693,t:1527030539411};\\\", \\\"{x:1370,y:692,t:1527030539428};\\\", \\\"{x:1370,y:690,t:1527030539444};\\\", \\\"{x:1370,y:689,t:1527030539463};\\\", \\\"{x:1370,y:688,t:1527030539478};\\\", \\\"{x:1369,y:685,t:1527030539495};\\\", \\\"{x:1367,y:682,t:1527030539511};\\\", \\\"{x:1366,y:680,t:1527030539527};\\\", \\\"{x:1366,y:678,t:1527030539545};\\\", \\\"{x:1364,y:677,t:1527030539561};\\\", \\\"{x:1363,y:673,t:1527030539578};\\\", \\\"{x:1361,y:671,t:1527030539595};\\\", \\\"{x:1359,y:669,t:1527030539610};\\\", \\\"{x:1358,y:667,t:1527030539627};\\\", \\\"{x:1356,y:665,t:1527030539644};\\\", \\\"{x:1354,y:664,t:1527030539663};\\\", \\\"{x:1354,y:663,t:1527030539677};\\\", \\\"{x:1353,y:662,t:1527030539694};\\\", \\\"{x:1353,y:661,t:1527030539719};\\\", \\\"{x:1352,y:660,t:1527030539759};\\\", \\\"{x:1351,y:659,t:1527030539777};\\\", \\\"{x:1351,y:658,t:1527030539799};\\\", \\\"{x:1351,y:657,t:1527030539815};\\\", \\\"{x:1350,y:656,t:1527030539827};\\\", \\\"{x:1349,y:654,t:1527030539845};\\\", \\\"{x:1348,y:654,t:1527030539861};\\\", \\\"{x:1348,y:653,t:1527030539879};\\\", \\\"{x:1347,y:653,t:1527030539903};\\\", \\\"{x:1347,y:652,t:1527030539911};\\\", \\\"{x:1345,y:651,t:1527030539927};\\\", \\\"{x:1343,y:651,t:1527030539944};\\\", \\\"{x:1341,y:649,t:1527030539961};\\\", \\\"{x:1339,y:648,t:1527030539977};\\\", \\\"{x:1335,y:647,t:1527030539994};\\\", \\\"{x:1332,y:644,t:1527030540011};\\\", \\\"{x:1331,y:644,t:1527030540028};\\\", \\\"{x:1330,y:644,t:1527030540088};\\\", \\\"{x:1328,y:644,t:1527030540143};\\\", \\\"{x:1325,y:643,t:1527030540161};\\\", \\\"{x:1322,y:643,t:1527030540178};\\\", \\\"{x:1320,y:642,t:1527030540194};\\\", \\\"{x:1318,y:642,t:1527030540212};\\\", \\\"{x:1314,y:641,t:1527030540227};\\\", \\\"{x:1313,y:641,t:1527030540246};\\\", \\\"{x:1312,y:641,t:1527030540261};\\\", \\\"{x:1311,y:640,t:1527030540503};\\\", \\\"{x:1311,y:639,t:1527030540519};\\\", \\\"{x:1311,y:638,t:1527030540534};\\\", \\\"{x:1311,y:637,t:1527030540566};\\\", \\\"{x:1311,y:636,t:1527030540589};\\\", \\\"{x:1311,y:635,t:1527030540606};\\\", \\\"{x:1311,y:634,t:1527030540718};\\\", \\\"{x:1311,y:633,t:1527030540744};\\\", \\\"{x:1311,y:632,t:1527030540879};\\\", \\\"{x:1311,y:631,t:1527030540919};\\\", \\\"{x:1310,y:631,t:1527030543136};\\\", \\\"{x:1309,y:632,t:1527030543147};\\\", \\\"{x:1308,y:633,t:1527030543384};\\\", \\\"{x:1306,y:633,t:1527030543415};\\\", \\\"{x:1306,y:634,t:1527030543433};\\\", \\\"{x:1305,y:637,t:1527030543447};\\\", \\\"{x:1305,y:644,t:1527030543464};\\\", \\\"{x:1305,y:656,t:1527030543481};\\\", \\\"{x:1308,y:672,t:1527030543497};\\\", \\\"{x:1315,y:685,t:1527030543513};\\\", \\\"{x:1325,y:703,t:1527030543531};\\\", \\\"{x:1338,y:722,t:1527030543547};\\\", \\\"{x:1351,y:745,t:1527030543564};\\\", \\\"{x:1368,y:763,t:1527030543581};\\\", \\\"{x:1387,y:782,t:1527030543596};\\\", \\\"{x:1412,y:809,t:1527030543613};\\\", \\\"{x:1448,y:845,t:1527030543630};\\\", \\\"{x:1473,y:865,t:1527030543646};\\\", \\\"{x:1489,y:880,t:1527030543662};\\\", \\\"{x:1503,y:890,t:1527030543680};\\\", \\\"{x:1516,y:901,t:1527030543697};\\\", \\\"{x:1524,y:906,t:1527030543713};\\\", \\\"{x:1526,y:908,t:1527030543730};\\\", \\\"{x:1527,y:908,t:1527030543774};\\\", \\\"{x:1528,y:908,t:1527030543782};\\\", \\\"{x:1530,y:908,t:1527030543796};\\\", \\\"{x:1532,y:907,t:1527030543814};\\\", \\\"{x:1536,y:904,t:1527030543835};\\\", \\\"{x:1537,y:902,t:1527030543850};\\\", \\\"{x:1538,y:899,t:1527030543868};\\\", \\\"{x:1539,y:893,t:1527030543885};\\\", \\\"{x:1539,y:885,t:1527030543902};\\\", \\\"{x:1538,y:875,t:1527030543917};\\\", \\\"{x:1533,y:862,t:1527030543935};\\\", \\\"{x:1528,y:851,t:1527030543952};\\\", \\\"{x:1521,y:844,t:1527030543968};\\\", \\\"{x:1514,y:836,t:1527030543985};\\\", \\\"{x:1508,y:831,t:1527030544002};\\\", \\\"{x:1498,y:823,t:1527030544018};\\\", \\\"{x:1488,y:816,t:1527030544038};\\\", \\\"{x:1483,y:813,t:1527030544050};\\\", \\\"{x:1476,y:810,t:1527030544068};\\\", \\\"{x:1470,y:808,t:1527030544085};\\\", \\\"{x:1460,y:806,t:1527030544102};\\\", \\\"{x:1444,y:802,t:1527030544117};\\\", \\\"{x:1415,y:794,t:1527030544134};\\\", \\\"{x:1361,y:785,t:1527030544151};\\\", \\\"{x:1269,y:765,t:1527030544166};\\\", \\\"{x:1148,y:738,t:1527030544184};\\\", \\\"{x:1025,y:718,t:1527030544200};\\\", \\\"{x:816,y:688,t:1527030544218};\\\", \\\"{x:705,y:672,t:1527030544235};\\\", \\\"{x:602,y:666,t:1527030544251};\\\", \\\"{x:528,y:662,t:1527030544268};\\\", \\\"{x:469,y:659,t:1527030544284};\\\", \\\"{x:430,y:655,t:1527030544301};\\\", \\\"{x:414,y:652,t:1527030544318};\\\", \\\"{x:412,y:651,t:1527030544334};\\\", \\\"{x:413,y:651,t:1527030544410};\\\", \\\"{x:417,y:652,t:1527030544419};\\\", \\\"{x:425,y:658,t:1527030544435};\\\", \\\"{x:436,y:668,t:1527030544451};\\\", \\\"{x:449,y:677,t:1527030544468};\\\", \\\"{x:462,y:687,t:1527030544484};\\\", \\\"{x:473,y:695,t:1527030544502};\\\", \\\"{x:483,y:700,t:1527030544519};\\\", \\\"{x:491,y:703,t:1527030544535};\\\", \\\"{x:497,y:706,t:1527030544551};\\\", \\\"{x:501,y:707,t:1527030544567};\\\", \\\"{x:503,y:707,t:1527030544581};\\\", \\\"{x:504,y:707,t:1527030544601};\\\", \\\"{x:505,y:707,t:1527030544626};\\\", \\\"{x:506,y:707,t:1527030544642};\\\", \\\"{x:507,y:707,t:1527030544649};\\\", \\\"{x:509,y:707,t:1527030544665};\\\", \\\"{x:513,y:707,t:1527030544681};\\\", \\\"{x:517,y:709,t:1527030544698};\\\", \\\"{x:519,y:711,t:1527030544715};\\\", \\\"{x:521,y:712,t:1527030544732};\\\", \\\"{x:522,y:714,t:1527030544748};\\\", \\\"{x:523,y:715,t:1527030544765};\\\", \\\"{x:526,y:717,t:1527030544782};\\\", \\\"{x:527,y:718,t:1527030544799};\\\", \\\"{x:528,y:719,t:1527030544815};\\\", \\\"{x:529,y:719,t:1527030544833};\\\", \\\"{x:530,y:719,t:1527030545627};\\\", \\\"{x:530,y:720,t:1527030545650};\\\", \\\"{x:529,y:720,t:1527030545706};\\\", \\\"{x:528,y:721,t:1527030545787};\\\", \\\"{x:527,y:721,t:1527030545803};\\\", \\\"{x:526,y:722,t:1527030545835};\\\", \\\"{x:525,y:722,t:1527030546003};\\\", \\\"{x:524,y:723,t:1527030546021};\\\", \\\"{x:521,y:724,t:1527030546043};\\\", \\\"{x:520,y:725,t:1527030546070};\\\", \\\"{x:519,y:725,t:1527030546087};\\\", \\\"{x:518,y:726,t:1527030546103};\\\", \\\"{x:517,y:727,t:1527030546120};\\\" ] }, { \\\"rt\\\": 88814, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 9, \\\"time_elapsed\\\": 391605, \\\"internal_node_id\\\": \\\"0.0-5.0-4.0\\\", \\\"subject\\\": \\\"E5L6P\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 5, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"U\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-U -I -I -I -I -I -I -O -O -A -A -O -O -O -O -I -I -O -O -I -Z -Z -F -A -U -U -U -U \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:516,y:727,t:1527030546527};\\\", \\\"{x:515,y:728,t:1527030547627};\\\", \\\"{x:513,y:728,t:1527030547638};\\\", \\\"{x:506,y:728,t:1527030547654};\\\", \\\"{x:500,y:728,t:1527030547671};\\\", \\\"{x:493,y:728,t:1527030547688};\\\", \\\"{x:485,y:728,t:1527030547706};\\\", \\\"{x:481,y:728,t:1527030547722};\\\", \\\"{x:477,y:728,t:1527030547738};\\\", \\\"{x:476,y:728,t:1527030547755};\\\", \\\"{x:474,y:728,t:1527030548547};\\\", \\\"{x:473,y:728,t:1527030548555};\\\", \\\"{x:472,y:728,t:1527030548572};\\\", \\\"{x:467,y:728,t:1527030548588};\\\", \\\"{x:462,y:728,t:1527030548605};\\\", \\\"{x:459,y:726,t:1527030548622};\\\", \\\"{x:454,y:726,t:1527030548640};\\\", \\\"{x:453,y:726,t:1527030548655};\\\", \\\"{x:451,y:725,t:1527030548673};\\\", \\\"{x:448,y:724,t:1527030548689};\\\", \\\"{x:447,y:724,t:1527030548715};\\\", \\\"{x:445,y:722,t:1527030549131};\\\", \\\"{x:443,y:720,t:1527030549141};\\\", \\\"{x:437,y:716,t:1527030549157};\\\", \\\"{x:435,y:713,t:1527030549172};\\\", \\\"{x:429,y:709,t:1527030549189};\\\", \\\"{x:422,y:703,t:1527030549206};\\\", \\\"{x:416,y:700,t:1527030549223};\\\", \\\"{x:412,y:697,t:1527030549239};\\\", \\\"{x:408,y:694,t:1527030549256};\\\", \\\"{x:406,y:691,t:1527030549273};\\\", \\\"{x:404,y:689,t:1527030549289};\\\", \\\"{x:402,y:686,t:1527030549306};\\\", \\\"{x:402,y:685,t:1527030549323};\\\", \\\"{x:402,y:684,t:1527030549339};\\\", \\\"{x:402,y:682,t:1527030549356};\\\", \\\"{x:402,y:680,t:1527030549373};\\\", \\\"{x:402,y:678,t:1527030549389};\\\", \\\"{x:402,y:676,t:1527030549406};\\\", \\\"{x:402,y:675,t:1527030549423};\\\", \\\"{x:402,y:672,t:1527030549439};\\\", \\\"{x:402,y:670,t:1527030549456};\\\", \\\"{x:402,y:669,t:1527030549474};\\\", \\\"{x:402,y:665,t:1527030549489};\\\", \\\"{x:402,y:658,t:1527030549507};\\\", \\\"{x:404,y:654,t:1527030549523};\\\", \\\"{x:405,y:646,t:1527030549539};\\\", \\\"{x:407,y:634,t:1527030549556};\\\", \\\"{x:410,y:622,t:1527030549574};\\\", \\\"{x:412,y:609,t:1527030549590};\\\", \\\"{x:417,y:595,t:1527030549607};\\\", \\\"{x:422,y:580,t:1527030549623};\\\", \\\"{x:426,y:565,t:1527030549640};\\\", \\\"{x:429,y:549,t:1527030549656};\\\", \\\"{x:432,y:535,t:1527030549674};\\\", \\\"{x:434,y:522,t:1527030549690};\\\", \\\"{x:436,y:514,t:1527030549707};\\\", \\\"{x:439,y:505,t:1527030549723};\\\", \\\"{x:441,y:500,t:1527030549740};\\\", \\\"{x:442,y:495,t:1527030549756};\\\", \\\"{x:442,y:491,t:1527030549773};\\\", \\\"{x:444,y:488,t:1527030549789};\\\", \\\"{x:444,y:486,t:1527030549807};\\\", \\\"{x:444,y:483,t:1527030549823};\\\", \\\"{x:444,y:480,t:1527030549839};\\\", \\\"{x:444,y:479,t:1527030549856};\\\", \\\"{x:444,y:477,t:1527030549873};\\\", \\\"{x:444,y:476,t:1527030549889};\\\", \\\"{x:446,y:476,t:1527030550187};\\\", \\\"{x:447,y:476,t:1527030550194};\\\", \\\"{x:449,y:477,t:1527030550206};\\\", \\\"{x:454,y:483,t:1527030550223};\\\", \\\"{x:457,y:487,t:1527030550240};\\\", \\\"{x:464,y:494,t:1527030550257};\\\", \\\"{x:470,y:499,t:1527030550273};\\\", \\\"{x:478,y:504,t:1527030550290};\\\", \\\"{x:488,y:509,t:1527030550307};\\\", \\\"{x:492,y:511,t:1527030550323};\\\", \\\"{x:496,y:512,t:1527030550340};\\\", \\\"{x:501,y:514,t:1527030550356};\\\", \\\"{x:502,y:515,t:1527030550373};\\\", \\\"{x:503,y:515,t:1527030550390};\\\", \\\"{x:504,y:515,t:1527030550426};\\\", \\\"{x:505,y:515,t:1527030550442};\\\", \\\"{x:507,y:515,t:1527030550459};\\\", \\\"{x:508,y:515,t:1527030550474};\\\", \\\"{x:510,y:515,t:1527030550490};\\\", \\\"{x:511,y:515,t:1527030550506};\\\", \\\"{x:512,y:514,t:1527030550524};\\\", \\\"{x:513,y:514,t:1527030550540};\\\", \\\"{x:514,y:513,t:1527030550557};\\\", \\\"{x:515,y:512,t:1527030550573};\\\", \\\"{x:516,y:511,t:1527030550590};\\\", \\\"{x:518,y:509,t:1527030550606};\\\", \\\"{x:518,y:508,t:1527030550624};\\\", \\\"{x:519,y:507,t:1527030550640};\\\", \\\"{x:520,y:505,t:1527030550656};\\\", \\\"{x:521,y:502,t:1527030550674};\\\", \\\"{x:522,y:501,t:1527030550690};\\\", \\\"{x:522,y:499,t:1527030550706};\\\", \\\"{x:523,y:499,t:1527030550724};\\\", \\\"{x:523,y:498,t:1527030550843};\\\", \\\"{x:523,y:497,t:1527030550857};\\\", \\\"{x:524,y:496,t:1527030550874};\\\", \\\"{x:530,y:496,t:1527030550890};\\\", \\\"{x:540,y:496,t:1527030550906};\\\", \\\"{x:543,y:496,t:1527030550923};\\\", \\\"{x:546,y:496,t:1527030550939};\\\", \\\"{x:550,y:497,t:1527030550957};\\\", \\\"{x:552,y:497,t:1527030550974};\\\", \\\"{x:558,y:497,t:1527030550990};\\\", \\\"{x:563,y:499,t:1527030551007};\\\", \\\"{x:566,y:499,t:1527030551024};\\\", \\\"{x:567,y:499,t:1527030551040};\\\", \\\"{x:569,y:499,t:1527030551057};\\\", \\\"{x:570,y:499,t:1527030551155};\\\", \\\"{x:573,y:499,t:1527030551161};\\\", \\\"{x:574,y:499,t:1527030551178};\\\", \\\"{x:575,y:499,t:1527030551189};\\\", \\\"{x:579,y:499,t:1527030551206};\\\", \\\"{x:583,y:499,t:1527030551223};\\\", \\\"{x:589,y:499,t:1527030551239};\\\", \\\"{x:597,y:499,t:1527030551256};\\\", \\\"{x:605,y:499,t:1527030551273};\\\", \\\"{x:613,y:498,t:1527030551289};\\\", \\\"{x:622,y:495,t:1527030551306};\\\", \\\"{x:625,y:495,t:1527030551322};\\\", \\\"{x:631,y:495,t:1527030551339};\\\", \\\"{x:634,y:494,t:1527030551356};\\\", \\\"{x:638,y:493,t:1527030551373};\\\", \\\"{x:642,y:493,t:1527030551389};\\\", \\\"{x:646,y:492,t:1527030551406};\\\", \\\"{x:650,y:492,t:1527030551423};\\\", \\\"{x:654,y:492,t:1527030551439};\\\", \\\"{x:661,y:492,t:1527030551456};\\\", \\\"{x:670,y:492,t:1527030551472};\\\", \\\"{x:679,y:493,t:1527030551489};\\\", \\\"{x:698,y:500,t:1527030551506};\\\", \\\"{x:719,y:507,t:1527030551523};\\\", \\\"{x:744,y:519,t:1527030551540};\\\", \\\"{x:770,y:529,t:1527030551558};\\\", \\\"{x:795,y:541,t:1527030551573};\\\", \\\"{x:818,y:549,t:1527030551589};\\\", \\\"{x:843,y:555,t:1527030551608};\\\", \\\"{x:868,y:565,t:1527030551624};\\\", \\\"{x:895,y:570,t:1527030551641};\\\", \\\"{x:934,y:582,t:1527030551658};\\\", \\\"{x:959,y:588,t:1527030551674};\\\", \\\"{x:987,y:590,t:1527030551691};\\\", \\\"{x:1011,y:595,t:1527030551708};\\\", \\\"{x:1032,y:601,t:1527030551724};\\\", \\\"{x:1053,y:606,t:1527030551741};\\\", \\\"{x:1074,y:612,t:1527030551758};\\\", \\\"{x:1098,y:618,t:1527030551774};\\\", \\\"{x:1125,y:627,t:1527030551792};\\\", \\\"{x:1150,y:633,t:1527030551809};\\\", \\\"{x:1172,y:640,t:1527030551824};\\\", \\\"{x:1197,y:647,t:1527030551841};\\\", \\\"{x:1225,y:653,t:1527030551858};\\\", \\\"{x:1267,y:665,t:1527030551874};\\\", \\\"{x:1291,y:672,t:1527030551891};\\\", \\\"{x:1311,y:678,t:1527030551908};\\\", \\\"{x:1335,y:686,t:1527030551925};\\\", \\\"{x:1362,y:698,t:1527030551942};\\\", \\\"{x:1388,y:708,t:1527030551958};\\\", \\\"{x:1412,y:719,t:1527030551975};\\\", \\\"{x:1436,y:727,t:1527030551992};\\\", \\\"{x:1454,y:732,t:1527030552007};\\\", \\\"{x:1466,y:737,t:1527030552024};\\\", \\\"{x:1479,y:743,t:1527030552041};\\\", \\\"{x:1493,y:752,t:1527030552057};\\\", \\\"{x:1500,y:757,t:1527030552074};\\\", \\\"{x:1503,y:761,t:1527030552092};\\\", \\\"{x:1506,y:764,t:1527030552108};\\\", \\\"{x:1507,y:767,t:1527030552125};\\\", \\\"{x:1508,y:773,t:1527030552142};\\\", \\\"{x:1508,y:776,t:1527030552158};\\\", \\\"{x:1508,y:780,t:1527030552175};\\\", \\\"{x:1508,y:786,t:1527030552192};\\\", \\\"{x:1504,y:792,t:1527030552208};\\\", \\\"{x:1498,y:800,t:1527030552225};\\\", \\\"{x:1490,y:809,t:1527030552241};\\\", \\\"{x:1481,y:819,t:1527030552258};\\\", \\\"{x:1467,y:831,t:1527030552275};\\\", \\\"{x:1458,y:837,t:1527030552291};\\\", \\\"{x:1450,y:841,t:1527030552308};\\\", \\\"{x:1443,y:843,t:1527030552325};\\\", \\\"{x:1439,y:846,t:1527030552341};\\\", \\\"{x:1437,y:846,t:1527030552358};\\\", \\\"{x:1436,y:847,t:1527030552375};\\\", \\\"{x:1434,y:848,t:1527030552394};\\\", \\\"{x:1433,y:849,t:1527030552411};\\\", \\\"{x:1431,y:850,t:1527030552426};\\\", \\\"{x:1427,y:852,t:1527030552440};\\\", \\\"{x:1423,y:853,t:1527030552458};\\\", \\\"{x:1416,y:856,t:1527030552474};\\\", \\\"{x:1412,y:858,t:1527030552491};\\\", \\\"{x:1409,y:859,t:1527030552508};\\\", \\\"{x:1407,y:860,t:1527030552525};\\\", \\\"{x:1403,y:861,t:1527030552541};\\\", \\\"{x:1399,y:863,t:1527030552558};\\\", \\\"{x:1395,y:865,t:1527030552575};\\\", \\\"{x:1390,y:866,t:1527030552591};\\\", \\\"{x:1386,y:868,t:1527030552608};\\\", \\\"{x:1385,y:868,t:1527030552625};\\\", \\\"{x:1382,y:870,t:1527030552641};\\\", \\\"{x:1380,y:870,t:1527030552658};\\\", \\\"{x:1379,y:871,t:1527030552673};\\\", \\\"{x:1376,y:872,t:1527030552691};\\\", \\\"{x:1374,y:872,t:1527030552708};\\\", \\\"{x:1373,y:873,t:1527030552723};\\\", \\\"{x:1371,y:873,t:1527030552741};\\\", \\\"{x:1369,y:873,t:1527030552758};\\\", \\\"{x:1366,y:873,t:1527030552774};\\\", \\\"{x:1363,y:873,t:1527030552791};\\\", \\\"{x:1355,y:873,t:1527030552808};\\\", \\\"{x:1349,y:873,t:1527030552824};\\\", \\\"{x:1339,y:873,t:1527030552840};\\\", \\\"{x:1328,y:869,t:1527030552858};\\\", \\\"{x:1312,y:863,t:1527030552875};\\\", \\\"{x:1291,y:852,t:1527030552890};\\\", \\\"{x:1279,y:843,t:1527030552909};\\\", \\\"{x:1262,y:831,t:1527030552923};\\\", \\\"{x:1247,y:814,t:1527030552941};\\\", \\\"{x:1232,y:796,t:1527030552958};\\\", \\\"{x:1220,y:781,t:1527030552974};\\\", \\\"{x:1214,y:772,t:1527030552991};\\\", \\\"{x:1211,y:761,t:1527030553007};\\\", \\\"{x:1208,y:752,t:1527030553023};\\\", \\\"{x:1206,y:746,t:1527030553041};\\\", \\\"{x:1203,y:738,t:1527030553057};\\\", \\\"{x:1202,y:728,t:1527030553073};\\\", \\\"{x:1201,y:713,t:1527030553090};\\\", \\\"{x:1199,y:702,t:1527030553106};\\\", \\\"{x:1199,y:692,t:1527030553123};\\\", \\\"{x:1199,y:679,t:1527030553141};\\\", \\\"{x:1199,y:666,t:1527030553157};\\\", \\\"{x:1199,y:654,t:1527030553173};\\\", \\\"{x:1199,y:645,t:1527030553190};\\\", \\\"{x:1199,y:638,t:1527030553207};\\\", \\\"{x:1199,y:633,t:1527030553223};\\\", \\\"{x:1199,y:627,t:1527030553240};\\\", \\\"{x:1199,y:621,t:1527030553256};\\\", \\\"{x:1199,y:615,t:1527030553274};\\\", \\\"{x:1199,y:605,t:1527030553290};\\\", \\\"{x:1199,y:599,t:1527030553307};\\\", \\\"{x:1199,y:591,t:1527030553324};\\\", \\\"{x:1200,y:585,t:1527030553340};\\\", \\\"{x:1204,y:577,t:1527030553357};\\\", \\\"{x:1207,y:572,t:1527030553374};\\\", \\\"{x:1208,y:567,t:1527030553391};\\\", \\\"{x:1210,y:563,t:1527030553406};\\\", \\\"{x:1212,y:560,t:1527030553424};\\\", \\\"{x:1214,y:556,t:1527030553440};\\\", \\\"{x:1216,y:552,t:1527030553457};\\\", \\\"{x:1219,y:548,t:1527030553474};\\\", \\\"{x:1223,y:544,t:1527030553490};\\\", \\\"{x:1227,y:540,t:1527030553507};\\\", \\\"{x:1230,y:537,t:1527030553524};\\\", \\\"{x:1232,y:534,t:1527030553540};\\\", \\\"{x:1234,y:532,t:1527030553557};\\\", \\\"{x:1237,y:530,t:1527030553574};\\\", \\\"{x:1239,y:528,t:1527030553590};\\\", \\\"{x:1241,y:527,t:1527030553607};\\\", \\\"{x:1242,y:526,t:1527030553624};\\\", \\\"{x:1243,y:525,t:1527030553640};\\\", \\\"{x:1244,y:525,t:1527030553659};\\\", \\\"{x:1245,y:525,t:1527030553675};\\\", \\\"{x:1247,y:523,t:1527030553923};\\\", \\\"{x:1248,y:523,t:1527030553940};\\\", \\\"{x:1249,y:523,t:1527030553957};\\\", \\\"{x:1249,y:522,t:1527030553973};\\\", \\\"{x:1251,y:522,t:1527030555235};\\\", \\\"{x:1256,y:519,t:1527030555242};\\\", \\\"{x:1260,y:518,t:1527030555256};\\\", \\\"{x:1267,y:515,t:1527030555272};\\\", \\\"{x:1274,y:512,t:1527030555288};\\\", \\\"{x:1278,y:510,t:1527030555306};\\\", \\\"{x:1286,y:506,t:1527030555321};\\\", \\\"{x:1296,y:502,t:1527030555338};\\\", \\\"{x:1301,y:501,t:1527030555355};\\\", \\\"{x:1307,y:497,t:1527030555372};\\\", \\\"{x:1317,y:491,t:1527030555391};\\\", \\\"{x:1327,y:483,t:1527030555405};\\\", \\\"{x:1332,y:474,t:1527030555422};\\\", \\\"{x:1336,y:470,t:1527030555439};\\\", \\\"{x:1339,y:462,t:1527030555455};\\\", \\\"{x:1341,y:458,t:1527030555472};\\\", \\\"{x:1343,y:455,t:1527030555488};\\\", \\\"{x:1344,y:451,t:1527030555504};\\\", \\\"{x:1344,y:447,t:1527030555522};\\\", \\\"{x:1346,y:443,t:1527030555539};\\\", \\\"{x:1346,y:441,t:1527030555555};\\\", \\\"{x:1346,y:440,t:1527030555572};\\\", \\\"{x:1346,y:439,t:1527030555589};\\\", \\\"{x:1345,y:439,t:1527030555692};\\\", \\\"{x:1343,y:439,t:1527030555705};\\\", \\\"{x:1343,y:440,t:1527030555763};\\\", \\\"{x:1342,y:440,t:1527030555797};\\\", \\\"{x:1341,y:441,t:1527030555806};\\\", \\\"{x:1340,y:442,t:1527030555821};\\\", \\\"{x:1339,y:443,t:1527030555837};\\\", \\\"{x:1337,y:445,t:1527030555854};\\\", \\\"{x:1336,y:448,t:1527030555871};\\\", \\\"{x:1332,y:452,t:1527030555887};\\\", \\\"{x:1329,y:457,t:1527030555905};\\\", \\\"{x:1326,y:462,t:1527030555921};\\\", \\\"{x:1324,y:470,t:1527030555937};\\\", \\\"{x:1320,y:483,t:1527030555955};\\\", \\\"{x:1317,y:490,t:1527030555971};\\\", \\\"{x:1316,y:495,t:1527030555988};\\\", \\\"{x:1314,y:500,t:1527030556004};\\\", \\\"{x:1313,y:503,t:1527030556022};\\\", \\\"{x:1313,y:509,t:1527030556038};\\\", \\\"{x:1313,y:510,t:1527030556054};\\\", \\\"{x:1313,y:512,t:1527030556071};\\\", \\\"{x:1313,y:513,t:1527030556088};\\\", \\\"{x:1313,y:511,t:1527030556409};\\\", \\\"{x:1313,y:510,t:1527030557817};\\\", \\\"{x:1313,y:507,t:1527030557825};\\\", \\\"{x:1313,y:506,t:1527030557836};\\\", \\\"{x:1313,y:504,t:1527030557853};\\\", \\\"{x:1314,y:503,t:1527030557905};\\\", \\\"{x:1315,y:499,t:1527030557919};\\\", \\\"{x:1318,y:489,t:1527030557936};\\\", \\\"{x:1318,y:485,t:1527030557953};\\\", \\\"{x:1319,y:479,t:1527030557969};\\\", \\\"{x:1319,y:477,t:1527030557986};\\\", \\\"{x:1319,y:476,t:1527030558002};\\\", \\\"{x:1318,y:477,t:1527030558170};\\\", \\\"{x:1317,y:478,t:1527030558194};\\\", \\\"{x:1315,y:479,t:1527030558234};\\\", \\\"{x:1314,y:479,t:1527030558243};\\\", \\\"{x:1313,y:480,t:1527030558253};\\\", \\\"{x:1311,y:481,t:1527030558270};\\\", \\\"{x:1307,y:483,t:1527030558286};\\\", \\\"{x:1305,y:484,t:1527030558303};\\\", \\\"{x:1304,y:484,t:1527030558319};\\\", \\\"{x:1303,y:484,t:1527030558346};\\\", \\\"{x:1302,y:485,t:1527030558362};\\\", \\\"{x:1302,y:486,t:1527030558378};\\\", \\\"{x:1300,y:486,t:1527030558410};\\\", \\\"{x:1300,y:487,t:1527030558426};\\\", \\\"{x:1298,y:487,t:1527030558435};\\\", \\\"{x:1297,y:489,t:1527030558453};\\\", \\\"{x:1295,y:493,t:1527030558469};\\\", \\\"{x:1295,y:495,t:1527030558486};\\\", \\\"{x:1294,y:497,t:1527030558503};\\\", \\\"{x:1294,y:498,t:1527030558522};\\\", \\\"{x:1294,y:500,t:1527030558554};\\\", \\\"{x:1295,y:500,t:1527030558569};\\\", \\\"{x:1295,y:501,t:1527030558594};\\\", \\\"{x:1296,y:501,t:1527030558610};\\\", \\\"{x:1297,y:501,t:1527030558626};\\\", \\\"{x:1299,y:501,t:1527030558636};\\\", \\\"{x:1303,y:502,t:1527030558652};\\\", \\\"{x:1309,y:502,t:1527030558669};\\\", \\\"{x:1315,y:502,t:1527030558686};\\\", \\\"{x:1320,y:502,t:1527030558703};\\\", \\\"{x:1322,y:502,t:1527030558718};\\\", \\\"{x:1327,y:502,t:1527030558736};\\\", \\\"{x:1330,y:502,t:1527030558753};\\\", \\\"{x:1331,y:501,t:1527030558769};\\\", \\\"{x:1332,y:501,t:1527030558803};\\\", \\\"{x:1330,y:501,t:1527030559019};\\\", \\\"{x:1328,y:501,t:1527030559036};\\\", \\\"{x:1326,y:502,t:1527030559052};\\\", \\\"{x:1324,y:502,t:1527030559069};\\\", \\\"{x:1323,y:502,t:1527030559086};\\\", \\\"{x:1321,y:502,t:1527030559102};\\\", \\\"{x:1320,y:502,t:1527030559119};\\\", \\\"{x:1319,y:503,t:1527030559203};\\\", \\\"{x:1316,y:504,t:1527030559219};\\\", \\\"{x:1311,y:509,t:1527030559235};\\\", \\\"{x:1306,y:515,t:1527030559252};\\\", \\\"{x:1302,y:520,t:1527030559269};\\\", \\\"{x:1300,y:523,t:1527030559285};\\\", \\\"{x:1299,y:528,t:1527030559302};\\\", \\\"{x:1299,y:535,t:1527030559319};\\\", \\\"{x:1298,y:546,t:1527030559334};\\\", \\\"{x:1298,y:559,t:1527030559352};\\\", \\\"{x:1298,y:571,t:1527030559368};\\\", \\\"{x:1298,y:584,t:1527030559384};\\\", \\\"{x:1302,y:608,t:1527030559402};\\\", \\\"{x:1304,y:623,t:1527030559419};\\\", \\\"{x:1305,y:633,t:1527030559435};\\\", \\\"{x:1307,y:645,t:1527030559452};\\\", \\\"{x:1307,y:651,t:1527030559469};\\\", \\\"{x:1308,y:657,t:1527030559485};\\\", \\\"{x:1309,y:663,t:1527030559501};\\\", \\\"{x:1312,y:671,t:1527030559518};\\\", \\\"{x:1312,y:677,t:1527030559535};\\\", \\\"{x:1313,y:679,t:1527030559552};\\\", \\\"{x:1313,y:680,t:1527030559569};\\\", \\\"{x:1313,y:682,t:1527030559771};\\\", \\\"{x:1313,y:683,t:1527030559786};\\\", \\\"{x:1313,y:685,t:1527030559802};\\\", \\\"{x:1313,y:686,t:1527030559818};\\\", \\\"{x:1313,y:687,t:1527030559931};\\\", \\\"{x:1313,y:688,t:1527030559938};\\\", \\\"{x:1313,y:690,t:1527030559955};\\\", \\\"{x:1313,y:691,t:1527030559968};\\\", \\\"{x:1313,y:693,t:1527030559986};\\\", \\\"{x:1313,y:700,t:1527030560003};\\\", \\\"{x:1313,y:703,t:1527030560018};\\\", \\\"{x:1313,y:707,t:1527030560034};\\\", \\\"{x:1313,y:712,t:1527030560051};\\\", \\\"{x:1313,y:716,t:1527030560068};\\\", \\\"{x:1313,y:720,t:1527030560085};\\\", \\\"{x:1313,y:723,t:1527030560102};\\\", \\\"{x:1313,y:726,t:1527030560118};\\\", \\\"{x:1313,y:730,t:1527030560135};\\\", \\\"{x:1313,y:735,t:1527030560151};\\\", \\\"{x:1313,y:739,t:1527030560168};\\\", \\\"{x:1313,y:740,t:1527030560184};\\\", \\\"{x:1313,y:741,t:1527030560217};\\\", \\\"{x:1313,y:742,t:1527030560235};\\\", \\\"{x:1313,y:744,t:1527030560251};\\\", \\\"{x:1313,y:747,t:1527030560267};\\\", \\\"{x:1313,y:750,t:1527030560284};\\\", \\\"{x:1313,y:754,t:1527030560301};\\\", \\\"{x:1313,y:757,t:1527030560317};\\\", \\\"{x:1313,y:762,t:1527030560335};\\\", \\\"{x:1312,y:769,t:1527030560351};\\\", \\\"{x:1312,y:775,t:1527030560367};\\\", \\\"{x:1311,y:781,t:1527030560384};\\\", \\\"{x:1309,y:786,t:1527030560401};\\\", \\\"{x:1307,y:790,t:1527030560418};\\\", \\\"{x:1307,y:793,t:1527030560434};\\\", \\\"{x:1306,y:797,t:1527030560451};\\\", \\\"{x:1305,y:801,t:1527030560469};\\\", \\\"{x:1304,y:801,t:1527030560484};\\\", \\\"{x:1304,y:803,t:1527030560501};\\\", \\\"{x:1304,y:806,t:1527030560518};\\\", \\\"{x:1304,y:808,t:1527030560534};\\\", \\\"{x:1304,y:810,t:1527030560551};\\\", \\\"{x:1303,y:814,t:1527030560568};\\\", \\\"{x:1303,y:820,t:1527030560583};\\\", \\\"{x:1303,y:829,t:1527030560601};\\\", \\\"{x:1303,y:846,t:1527030560618};\\\", \\\"{x:1304,y:859,t:1527030560634};\\\", \\\"{x:1306,y:873,t:1527030560651};\\\", \\\"{x:1307,y:884,t:1527030560668};\\\", \\\"{x:1309,y:898,t:1527030560683};\\\", \\\"{x:1310,y:907,t:1527030560701};\\\", \\\"{x:1311,y:912,t:1527030560718};\\\", \\\"{x:1311,y:920,t:1527030560734};\\\", \\\"{x:1313,y:927,t:1527030560751};\\\", \\\"{x:1314,y:935,t:1527030560768};\\\", \\\"{x:1314,y:944,t:1527030560784};\\\", \\\"{x:1314,y:949,t:1527030560801};\\\", \\\"{x:1314,y:952,t:1527030560817};\\\", \\\"{x:1314,y:959,t:1527030560834};\\\", \\\"{x:1314,y:962,t:1527030560850};\\\", \\\"{x:1314,y:965,t:1527030560867};\\\", \\\"{x:1314,y:966,t:1527030560883};\\\", \\\"{x:1314,y:968,t:1527030560901};\\\", \\\"{x:1314,y:970,t:1527030560918};\\\", \\\"{x:1314,y:971,t:1527030560934};\\\", \\\"{x:1314,y:972,t:1527030560951};\\\", \\\"{x:1314,y:973,t:1527030560967};\\\", \\\"{x:1314,y:974,t:1527030560984};\\\", \\\"{x:1314,y:975,t:1527030561001};\\\", \\\"{x:1313,y:976,t:1527030561018};\\\", \\\"{x:1313,y:975,t:1527030561267};\\\", \\\"{x:1313,y:973,t:1527030561284};\\\", \\\"{x:1313,y:972,t:1527030561300};\\\", \\\"{x:1313,y:970,t:1527030561322};\\\", \\\"{x:1314,y:970,t:1527030561347};\\\", \\\"{x:1314,y:969,t:1527030561354};\\\", \\\"{x:1314,y:968,t:1527030561370};\\\", \\\"{x:1314,y:967,t:1527030561386};\\\", \\\"{x:1314,y:966,t:1527030561399};\\\", \\\"{x:1315,y:964,t:1527030561416};\\\", \\\"{x:1316,y:963,t:1527030561434};\\\", \\\"{x:1317,y:961,t:1527030561450};\\\", \\\"{x:1317,y:960,t:1527030561467};\\\", \\\"{x:1317,y:959,t:1527030561506};\\\", \\\"{x:1314,y:960,t:1527030561747};\\\", \\\"{x:1314,y:961,t:1527030561754};\\\", \\\"{x:1313,y:962,t:1527030561771};\\\", \\\"{x:1313,y:957,t:1527030564019};\\\", \\\"{x:1316,y:947,t:1527030564031};\\\", \\\"{x:1321,y:921,t:1527030564048};\\\", \\\"{x:1336,y:873,t:1527030564065};\\\", \\\"{x:1358,y:800,t:1527030564081};\\\", \\\"{x:1376,y:671,t:1527030564099};\\\", \\\"{x:1382,y:570,t:1527030564115};\\\", \\\"{x:1382,y:470,t:1527030564131};\\\", \\\"{x:1382,y:387,t:1527030564148};\\\", \\\"{x:1382,y:320,t:1527030564166};\\\", \\\"{x:1382,y:281,t:1527030564180};\\\", \\\"{x:1382,y:252,t:1527030564198};\\\", \\\"{x:1382,y:232,t:1527030564215};\\\", \\\"{x:1382,y:218,t:1527030564231};\\\", \\\"{x:1382,y:209,t:1527030564248};\\\", \\\"{x:1382,y:204,t:1527030564265};\\\", \\\"{x:1382,y:202,t:1527030564280};\\\", \\\"{x:1377,y:202,t:1527030564338};\\\", \\\"{x:1372,y:207,t:1527030564348};\\\", \\\"{x:1357,y:231,t:1527030564364};\\\", \\\"{x:1343,y:264,t:1527030564381};\\\", \\\"{x:1334,y:298,t:1527030564398};\\\", \\\"{x:1329,y:325,t:1527030564414};\\\", \\\"{x:1326,y:347,t:1527030564431};\\\", \\\"{x:1324,y:364,t:1527030564448};\\\", \\\"{x:1324,y:376,t:1527030564463};\\\", \\\"{x:1324,y:385,t:1527030564481};\\\", \\\"{x:1324,y:396,t:1527030564498};\\\", \\\"{x:1324,y:405,t:1527030564514};\\\", \\\"{x:1324,y:414,t:1527030564531};\\\", \\\"{x:1324,y:424,t:1527030564548};\\\", \\\"{x:1324,y:438,t:1527030564563};\\\", \\\"{x:1324,y:450,t:1527030564581};\\\", \\\"{x:1324,y:460,t:1527030564598};\\\", \\\"{x:1324,y:469,t:1527030564614};\\\", \\\"{x:1324,y:476,t:1527030564631};\\\", \\\"{x:1324,y:481,t:1527030564648};\\\", \\\"{x:1323,y:485,t:1527030564664};\\\", \\\"{x:1323,y:489,t:1527030564682};\\\", \\\"{x:1323,y:490,t:1527030564697};\\\", \\\"{x:1323,y:491,t:1527030564714};\\\", \\\"{x:1323,y:492,t:1527030564731};\\\", \\\"{x:1323,y:493,t:1527030564747};\\\", \\\"{x:1323,y:494,t:1527030564765};\\\", \\\"{x:1322,y:496,t:1527030564980};\\\", \\\"{x:1321,y:496,t:1527030564994};\\\", \\\"{x:1320,y:497,t:1527030565002};\\\", \\\"{x:1319,y:497,t:1527030565014};\\\", \\\"{x:1318,y:498,t:1527030565031};\\\", \\\"{x:1315,y:498,t:1527030565047};\\\", \\\"{x:1315,y:499,t:1527030565063};\\\", \\\"{x:1314,y:499,t:1527030565138};\\\", \\\"{x:1314,y:498,t:1527030568738};\\\", \\\"{x:1312,y:496,t:1527030568747};\\\", \\\"{x:1312,y:495,t:1527030568762};\\\", \\\"{x:1312,y:494,t:1527030568778};\\\", \\\"{x:1312,y:493,t:1527030568794};\\\", \\\"{x:1311,y:493,t:1527030574050};\\\", \\\"{x:1309,y:493,t:1527030574082};\\\", \\\"{x:1307,y:494,t:1527030574122};\\\", \\\"{x:1307,y:495,t:1527030574938};\\\", \\\"{x:1306,y:496,t:1527030574986};\\\", \\\"{x:1306,y:497,t:1527030575244};\\\", \\\"{x:1306,y:500,t:1527030575256};\\\", \\\"{x:1306,y:504,t:1527030575272};\\\", \\\"{x:1305,y:508,t:1527030575289};\\\", \\\"{x:1305,y:512,t:1527030575306};\\\", \\\"{x:1305,y:519,t:1527030575323};\\\", \\\"{x:1305,y:527,t:1527030575339};\\\", \\\"{x:1305,y:531,t:1527030575356};\\\", \\\"{x:1305,y:534,t:1527030575373};\\\", \\\"{x:1305,y:538,t:1527030575389};\\\", \\\"{x:1305,y:542,t:1527030575406};\\\", \\\"{x:1305,y:545,t:1527030575422};\\\", \\\"{x:1305,y:547,t:1527030575438};\\\", \\\"{x:1305,y:548,t:1527030575458};\\\", \\\"{x:1305,y:550,t:1527030575474};\\\", \\\"{x:1305,y:551,t:1527030575507};\\\", \\\"{x:1305,y:553,t:1527030575522};\\\", \\\"{x:1305,y:556,t:1527030575539};\\\", \\\"{x:1306,y:561,t:1527030575556};\\\", \\\"{x:1306,y:567,t:1527030575571};\\\", \\\"{x:1307,y:572,t:1527030575587};\\\", \\\"{x:1308,y:580,t:1527030575605};\\\", \\\"{x:1311,y:588,t:1527030575621};\\\", \\\"{x:1314,y:597,t:1527030575638};\\\", \\\"{x:1317,y:608,t:1527030575655};\\\", \\\"{x:1318,y:613,t:1527030575671};\\\", \\\"{x:1320,y:619,t:1527030575688};\\\", \\\"{x:1322,y:627,t:1527030575706};\\\", \\\"{x:1323,y:630,t:1527030575722};\\\", \\\"{x:1323,y:631,t:1527030575739};\\\", \\\"{x:1324,y:634,t:1527030575755};\\\", \\\"{x:1325,y:635,t:1527030575771};\\\", \\\"{x:1325,y:637,t:1527030575788};\\\", \\\"{x:1325,y:638,t:1527030575805};\\\", \\\"{x:1325,y:639,t:1527030575821};\\\", \\\"{x:1325,y:640,t:1527030575838};\\\", \\\"{x:1321,y:641,t:1527030576035};\\\", \\\"{x:1318,y:642,t:1527030576042};\\\", \\\"{x:1316,y:642,t:1527030576054};\\\", \\\"{x:1314,y:643,t:1527030576071};\\\", \\\"{x:1313,y:643,t:1527030576313};\\\", \\\"{x:1313,y:640,t:1527030576322};\\\", \\\"{x:1314,y:635,t:1527030576337};\\\", \\\"{x:1314,y:633,t:1527030576371};\\\", \\\"{x:1314,y:632,t:1527030576387};\\\", \\\"{x:1315,y:631,t:1527030576404};\\\", \\\"{x:1313,y:632,t:1527030577115};\\\", \\\"{x:1310,y:638,t:1527030577123};\\\", \\\"{x:1302,y:664,t:1527030577138};\\\", \\\"{x:1291,y:711,t:1527030577154};\\\", \\\"{x:1287,y:752,t:1527030577170};\\\", \\\"{x:1284,y:788,t:1527030577187};\\\", \\\"{x:1284,y:812,t:1527030577203};\\\", \\\"{x:1284,y:827,t:1527030577220};\\\", \\\"{x:1284,y:840,t:1527030577237};\\\", \\\"{x:1284,y:848,t:1527030577253};\\\", \\\"{x:1284,y:857,t:1527030577271};\\\", \\\"{x:1284,y:869,t:1527030577287};\\\", \\\"{x:1284,y:881,t:1527030577303};\\\", \\\"{x:1284,y:892,t:1527030577320};\\\", \\\"{x:1285,y:900,t:1527030577337};\\\", \\\"{x:1287,y:907,t:1527030577353};\\\", \\\"{x:1290,y:913,t:1527030577370};\\\", \\\"{x:1294,y:921,t:1527030577388};\\\", \\\"{x:1296,y:923,t:1527030577403};\\\", \\\"{x:1298,y:926,t:1527030577475};\\\", \\\"{x:1304,y:932,t:1527030577487};\\\", \\\"{x:1314,y:944,t:1527030577504};\\\", \\\"{x:1321,y:952,t:1527030577520};\\\", \\\"{x:1322,y:955,t:1527030577537};\\\", \\\"{x:1323,y:957,t:1527030577554};\\\", \\\"{x:1323,y:958,t:1527030577570};\\\", \\\"{x:1324,y:960,t:1527030577586};\\\", \\\"{x:1324,y:961,t:1527030577604};\\\", \\\"{x:1325,y:966,t:1527030577621};\\\", \\\"{x:1325,y:968,t:1527030577636};\\\", \\\"{x:1325,y:970,t:1527030577706};\\\", \\\"{x:1325,y:971,t:1527030577746};\\\", \\\"{x:1325,y:973,t:1527030577779};\\\", \\\"{x:1325,y:974,t:1527030577827};\\\", \\\"{x:1324,y:975,t:1527030577858};\\\", \\\"{x:1323,y:975,t:1527030577898};\\\", \\\"{x:1322,y:975,t:1527030577914};\\\", \\\"{x:1321,y:975,t:1527030577922};\\\", \\\"{x:1319,y:975,t:1527030577962};\\\", \\\"{x:1319,y:970,t:1527030577970};\\\", \\\"{x:1318,y:966,t:1527030577986};\\\", \\\"{x:1317,y:961,t:1527030578003};\\\", \\\"{x:1316,y:950,t:1527030578020};\\\", \\\"{x:1316,y:937,t:1527030578037};\\\", \\\"{x:1316,y:925,t:1527030578053};\\\", \\\"{x:1316,y:915,t:1527030578069};\\\", \\\"{x:1318,y:903,t:1527030578086};\\\", \\\"{x:1320,y:888,t:1527030578103};\\\", \\\"{x:1325,y:871,t:1527030578119};\\\", \\\"{x:1327,y:858,t:1527030578136};\\\", \\\"{x:1330,y:840,t:1527030578153};\\\", \\\"{x:1332,y:830,t:1527030578169};\\\", \\\"{x:1334,y:814,t:1527030578186};\\\", \\\"{x:1336,y:795,t:1527030578203};\\\", \\\"{x:1339,y:777,t:1527030578219};\\\", \\\"{x:1341,y:762,t:1527030578237};\\\", \\\"{x:1344,y:746,t:1527030578253};\\\", \\\"{x:1347,y:721,t:1527030578269};\\\", \\\"{x:1350,y:690,t:1527030578286};\\\", \\\"{x:1353,y:660,t:1527030578302};\\\", \\\"{x:1353,y:634,t:1527030578320};\\\", \\\"{x:1353,y:618,t:1527030578337};\\\", \\\"{x:1353,y:610,t:1527030578352};\\\", \\\"{x:1353,y:606,t:1527030578370};\\\", \\\"{x:1353,y:605,t:1527030578385};\\\", \\\"{x:1352,y:605,t:1527030578491};\\\", \\\"{x:1351,y:606,t:1527030578503};\\\", \\\"{x:1347,y:615,t:1527030578520};\\\", \\\"{x:1345,y:619,t:1527030578537};\\\", \\\"{x:1342,y:625,t:1527030578553};\\\", \\\"{x:1340,y:631,t:1527030578570};\\\", \\\"{x:1340,y:633,t:1527030578586};\\\", \\\"{x:1339,y:633,t:1527030578603};\\\", \\\"{x:1338,y:634,t:1527030578875};\\\", \\\"{x:1336,y:635,t:1527030578889};\\\", \\\"{x:1335,y:635,t:1527030578905};\\\", \\\"{x:1334,y:636,t:1527030578929};\\\", \\\"{x:1333,y:636,t:1527030578969};\\\", \\\"{x:1333,y:637,t:1527030579002};\\\", \\\"{x:1332,y:637,t:1527030579033};\\\", \\\"{x:1331,y:637,t:1527030579057};\\\", \\\"{x:1330,y:637,t:1527030579098};\\\", \\\"{x:1328,y:638,t:1527030579106};\\\", \\\"{x:1327,y:638,t:1527030579129};\\\", \\\"{x:1325,y:638,t:1527030579138};\\\", \\\"{x:1324,y:638,t:1527030579153};\\\", \\\"{x:1323,y:638,t:1527030579168};\\\", \\\"{x:1322,y:638,t:1527030579185};\\\", \\\"{x:1321,y:638,t:1527030579202};\\\", \\\"{x:1320,y:637,t:1527030579387};\\\", \\\"{x:1319,y:633,t:1527030579403};\\\", \\\"{x:1317,y:628,t:1527030579418};\\\", \\\"{x:1317,y:626,t:1527030579436};\\\", \\\"{x:1317,y:624,t:1527030579453};\\\", \\\"{x:1316,y:623,t:1527030579469};\\\", \\\"{x:1315,y:622,t:1527030579486};\\\", \\\"{x:1314,y:622,t:1527030579506};\\\", \\\"{x:1314,y:621,t:1527030579518};\\\", \\\"{x:1312,y:621,t:1527030579536};\\\", \\\"{x:1310,y:621,t:1527030579552};\\\", \\\"{x:1309,y:621,t:1527030579569};\\\", \\\"{x:1307,y:621,t:1527030579586};\\\", \\\"{x:1306,y:621,t:1527030579602};\\\", \\\"{x:1305,y:621,t:1527030579618};\\\", \\\"{x:1305,y:622,t:1527030579923};\\\", \\\"{x:1306,y:623,t:1527030579938};\\\", \\\"{x:1307,y:624,t:1527030579954};\\\", \\\"{x:1308,y:625,t:1527030579994};\\\", \\\"{x:1308,y:626,t:1527030580106};\\\", \\\"{x:1308,y:627,t:1527030580119};\\\", \\\"{x:1309,y:628,t:1527030580135};\\\", \\\"{x:1310,y:631,t:1527030580151};\\\", \\\"{x:1310,y:632,t:1527030580169};\\\", \\\"{x:1311,y:633,t:1527030580185};\\\", \\\"{x:1312,y:634,t:1527030580210};\\\", \\\"{x:1313,y:634,t:1527030580218};\\\", \\\"{x:1314,y:634,t:1527030580242};\\\", \\\"{x:1315,y:634,t:1527030580274};\\\", \\\"{x:1316,y:634,t:1527030580290};\\\", \\\"{x:1317,y:634,t:1527030580314};\\\", \\\"{x:1318,y:633,t:1527030580338};\\\", \\\"{x:1318,y:632,t:1527030580354};\\\", \\\"{x:1318,y:629,t:1527030580368};\\\", \\\"{x:1318,y:626,t:1527030580385};\\\", \\\"{x:1318,y:620,t:1527030580402};\\\", \\\"{x:1318,y:616,t:1527030580418};\\\", \\\"{x:1318,y:611,t:1527030580435};\\\", \\\"{x:1318,y:606,t:1527030580452};\\\", \\\"{x:1318,y:599,t:1527030580467};\\\", \\\"{x:1318,y:588,t:1527030580485};\\\", \\\"{x:1318,y:570,t:1527030580502};\\\", \\\"{x:1318,y:554,t:1527030580518};\\\", \\\"{x:1318,y:539,t:1527030580535};\\\", \\\"{x:1318,y:530,t:1527030580552};\\\", \\\"{x:1318,y:526,t:1527030580568};\\\", \\\"{x:1318,y:521,t:1527030580585};\\\", \\\"{x:1318,y:515,t:1527030580601};\\\", \\\"{x:1317,y:506,t:1527030580618};\\\", \\\"{x:1316,y:493,t:1527030580635};\\\", \\\"{x:1313,y:484,t:1527030580652};\\\", \\\"{x:1313,y:480,t:1527030580668};\\\", \\\"{x:1312,y:477,t:1527030580685};\\\", \\\"{x:1311,y:477,t:1527030580851};\\\", \\\"{x:1307,y:482,t:1527030580868};\\\", \\\"{x:1305,y:487,t:1527030580885};\\\", \\\"{x:1304,y:489,t:1527030580901};\\\", \\\"{x:1302,y:492,t:1527030580918};\\\", \\\"{x:1302,y:493,t:1527030580934};\\\", \\\"{x:1302,y:494,t:1527030580954};\\\", \\\"{x:1302,y:496,t:1527030581099};\\\", \\\"{x:1303,y:497,t:1527030581106};\\\", \\\"{x:1304,y:498,t:1527030581130};\\\", \\\"{x:1306,y:499,t:1527030581147};\\\", \\\"{x:1306,y:500,t:1527030581155};\\\", \\\"{x:1307,y:500,t:1527030581168};\\\", \\\"{x:1308,y:501,t:1527030581184};\\\", \\\"{x:1310,y:502,t:1527030581200};\\\", \\\"{x:1311,y:502,t:1527030581218};\\\", \\\"{x:1312,y:502,t:1527030581242};\\\", \\\"{x:1314,y:502,t:1527030581307};\\\", \\\"{x:1315,y:502,t:1527030581354};\\\", \\\"{x:1315,y:503,t:1527030581538};\\\", \\\"{x:1315,y:505,t:1527030581551};\\\", \\\"{x:1315,y:517,t:1527030581566};\\\", \\\"{x:1313,y:531,t:1527030581583};\\\", \\\"{x:1311,y:551,t:1527030581601};\\\", \\\"{x:1308,y:569,t:1527030581616};\\\", \\\"{x:1307,y:591,t:1527030581633};\\\", \\\"{x:1306,y:600,t:1527030581650};\\\", \\\"{x:1306,y:604,t:1527030581666};\\\", \\\"{x:1306,y:609,t:1527030581684};\\\", \\\"{x:1306,y:611,t:1527030581701};\\\", \\\"{x:1306,y:615,t:1527030581717};\\\", \\\"{x:1306,y:618,t:1527030581734};\\\", \\\"{x:1306,y:621,t:1527030581750};\\\", \\\"{x:1306,y:623,t:1527030581767};\\\", \\\"{x:1306,y:624,t:1527030581786};\\\", \\\"{x:1306,y:625,t:1527030581802};\\\", \\\"{x:1306,y:626,t:1527030581818};\\\", \\\"{x:1306,y:627,t:1527030581842};\\\", \\\"{x:1306,y:628,t:1527030581866};\\\", \\\"{x:1306,y:629,t:1527030581884};\\\", \\\"{x:1307,y:630,t:1527030581915};\\\", \\\"{x:1308,y:630,t:1527030581931};\\\", \\\"{x:1310,y:630,t:1527030581954};\\\", \\\"{x:1311,y:630,t:1527030581967};\\\", \\\"{x:1313,y:630,t:1527030581984};\\\", \\\"{x:1317,y:630,t:1527030582000};\\\", \\\"{x:1320,y:630,t:1527030582017};\\\", \\\"{x:1321,y:630,t:1527030582035};\\\", \\\"{x:1324,y:630,t:1527030582049};\\\", \\\"{x:1325,y:630,t:1527030582089};\\\", \\\"{x:1326,y:630,t:1527030582410};\\\", \\\"{x:1324,y:630,t:1527030582779};\\\", \\\"{x:1323,y:630,t:1527030582786};\\\", \\\"{x:1321,y:630,t:1527030582800};\\\", \\\"{x:1320,y:630,t:1527030582817};\\\", \\\"{x:1318,y:630,t:1527030582832};\\\", \\\"{x:1317,y:630,t:1527030582850};\\\", \\\"{x:1316,y:631,t:1527030583482};\\\", \\\"{x:1312,y:639,t:1527030583500};\\\", \\\"{x:1308,y:649,t:1527030583515};\\\", \\\"{x:1304,y:661,t:1527030583532};\\\", \\\"{x:1302,y:670,t:1527030583549};\\\", \\\"{x:1302,y:676,t:1527030583566};\\\", \\\"{x:1300,y:683,t:1527030583581};\\\", \\\"{x:1299,y:687,t:1527030583599};\\\", \\\"{x:1298,y:693,t:1527030583616};\\\", \\\"{x:1298,y:699,t:1527030583632};\\\", \\\"{x:1298,y:712,t:1527030583649};\\\", \\\"{x:1298,y:717,t:1527030583666};\\\", \\\"{x:1298,y:720,t:1527030583683};\\\", \\\"{x:1298,y:722,t:1527030583699};\\\", \\\"{x:1298,y:724,t:1527030583715};\\\", \\\"{x:1298,y:725,t:1527030583732};\\\", \\\"{x:1298,y:727,t:1527030583749};\\\", \\\"{x:1298,y:728,t:1527030583765};\\\", \\\"{x:1298,y:729,t:1527030583782};\\\", \\\"{x:1298,y:722,t:1527030583891};\\\", \\\"{x:1300,y:713,t:1527030583898};\\\", \\\"{x:1306,y:685,t:1527030583915};\\\", \\\"{x:1313,y:662,t:1527030583932};\\\", \\\"{x:1317,y:647,t:1527030583949};\\\", \\\"{x:1319,y:639,t:1527030583965};\\\", \\\"{x:1320,y:634,t:1527030583982};\\\", \\\"{x:1321,y:629,t:1527030583999};\\\", \\\"{x:1322,y:624,t:1527030584015};\\\", \\\"{x:1322,y:619,t:1527030584032};\\\", \\\"{x:1323,y:615,t:1527030584049};\\\", \\\"{x:1325,y:611,t:1527030584065};\\\", \\\"{x:1325,y:610,t:1527030584081};\\\", \\\"{x:1325,y:609,t:1527030584097};\\\", \\\"{x:1325,y:613,t:1527030584243};\\\", \\\"{x:1322,y:619,t:1527030584250};\\\", \\\"{x:1320,y:626,t:1527030584265};\\\", \\\"{x:1314,y:646,t:1527030584282};\\\", \\\"{x:1309,y:662,t:1527030584297};\\\", \\\"{x:1307,y:675,t:1527030584315};\\\", \\\"{x:1305,y:690,t:1527030584332};\\\", \\\"{x:1305,y:700,t:1527030584348};\\\", \\\"{x:1305,y:707,t:1527030584365};\\\", \\\"{x:1305,y:713,t:1527030584382};\\\", \\\"{x:1305,y:718,t:1527030584398};\\\", \\\"{x:1305,y:721,t:1527030584415};\\\", \\\"{x:1305,y:723,t:1527030584432};\\\", \\\"{x:1305,y:724,t:1527030584448};\\\", \\\"{x:1305,y:727,t:1527030584465};\\\", \\\"{x:1305,y:728,t:1527030584490};\\\", \\\"{x:1304,y:730,t:1527030584922};\\\", \\\"{x:1304,y:731,t:1527030584931};\\\", \\\"{x:1302,y:736,t:1527030584948};\\\", \\\"{x:1301,y:739,t:1527030584964};\\\", \\\"{x:1300,y:742,t:1527030584981};\\\", \\\"{x:1299,y:743,t:1527030584998};\\\", \\\"{x:1299,y:745,t:1527030585014};\\\", \\\"{x:1299,y:746,t:1527030585031};\\\", \\\"{x:1299,y:747,t:1527030585048};\\\", \\\"{x:1298,y:749,t:1527030585064};\\\", \\\"{x:1298,y:750,t:1527030585081};\\\", \\\"{x:1298,y:749,t:1527030586842};\\\", \\\"{x:1298,y:747,t:1527030586850};\\\", \\\"{x:1298,y:738,t:1527030593707};\\\", \\\"{x:1297,y:710,t:1527030593725};\\\", \\\"{x:1291,y:688,t:1527030593740};\\\", \\\"{x:1290,y:663,t:1527030593757};\\\", \\\"{x:1287,y:643,t:1527030593774};\\\", \\\"{x:1285,y:623,t:1527030593790};\\\", \\\"{x:1285,y:602,t:1527030593808};\\\", \\\"{x:1284,y:582,t:1527030593824};\\\", \\\"{x:1281,y:566,t:1527030593840};\\\", \\\"{x:1280,y:550,t:1527030593857};\\\", \\\"{x:1278,y:537,t:1527030593873};\\\", \\\"{x:1276,y:533,t:1527030593890};\\\", \\\"{x:1276,y:529,t:1527030593908};\\\", \\\"{x:1276,y:526,t:1527030593923};\\\", \\\"{x:1276,y:522,t:1527030593941};\\\", \\\"{x:1276,y:516,t:1527030593957};\\\", \\\"{x:1276,y:512,t:1527030593973};\\\", \\\"{x:1276,y:511,t:1527030593991};\\\", \\\"{x:1276,y:507,t:1527030594008};\\\", \\\"{x:1276,y:504,t:1527030594024};\\\", \\\"{x:1278,y:498,t:1527030594040};\\\", \\\"{x:1279,y:495,t:1527030594057};\\\", \\\"{x:1280,y:491,t:1527030594074};\\\", \\\"{x:1280,y:490,t:1527030594091};\\\", \\\"{x:1280,y:489,t:1527030594108};\\\", \\\"{x:1281,y:489,t:1527030594123};\\\", \\\"{x:1281,y:488,t:1527030594146};\\\", \\\"{x:1282,y:487,t:1527030594170};\\\", \\\"{x:1283,y:487,t:1527030594394};\\\", \\\"{x:1285,y:487,t:1527030594407};\\\", \\\"{x:1288,y:489,t:1527030594423};\\\", \\\"{x:1291,y:491,t:1527030594441};\\\", \\\"{x:1294,y:493,t:1527030594457};\\\", \\\"{x:1297,y:494,t:1527030594474};\\\", \\\"{x:1298,y:495,t:1527030594490};\\\", \\\"{x:1299,y:495,t:1527030594506};\\\", \\\"{x:1300,y:496,t:1527030594523};\\\", \\\"{x:1301,y:497,t:1527030594541};\\\", \\\"{x:1303,y:498,t:1527030594557};\\\", \\\"{x:1304,y:499,t:1527030594573};\\\", \\\"{x:1305,y:499,t:1527030594590};\\\", \\\"{x:1306,y:499,t:1527030594714};\\\", \\\"{x:1305,y:499,t:1527030596698};\\\", \\\"{x:1304,y:501,t:1527030596706};\\\", \\\"{x:1302,y:502,t:1527030596722};\\\", \\\"{x:1301,y:502,t:1527030596739};\\\", \\\"{x:1300,y:503,t:1527030596930};\\\", \\\"{x:1300,y:504,t:1527030596937};\\\", \\\"{x:1298,y:506,t:1527030596955};\\\", \\\"{x:1294,y:507,t:1527030596971};\\\", \\\"{x:1290,y:508,t:1527030596988};\\\", \\\"{x:1291,y:508,t:1527030597050};\\\", \\\"{x:1292,y:508,t:1527030597058};\\\", \\\"{x:1292,y:507,t:1527030597074};\\\", \\\"{x:1295,y:507,t:1527030597146};\\\", \\\"{x:1302,y:504,t:1527030597154};\\\", \\\"{x:1322,y:495,t:1527030597172};\\\", \\\"{x:1341,y:486,t:1527030597187};\\\", \\\"{x:1344,y:485,t:1527030597205};\\\", \\\"{x:1344,y:486,t:1527030597619};\\\", \\\"{x:1339,y:491,t:1527030597626};\\\", \\\"{x:1330,y:499,t:1527030597637};\\\", \\\"{x:1319,y:513,t:1527030597654};\\\", \\\"{x:1317,y:514,t:1527030597671};\\\", \\\"{x:1317,y:512,t:1527030597714};\\\", \\\"{x:1316,y:507,t:1527030597722};\\\", \\\"{x:1315,y:500,t:1527030597738};\\\", \\\"{x:1315,y:505,t:1527030607950};\\\", \\\"{x:1320,y:530,t:1527030607965};\\\", \\\"{x:1324,y:550,t:1527030607982};\\\", \\\"{x:1330,y:570,t:1527030607999};\\\", \\\"{x:1337,y:593,t:1527030608015};\\\", \\\"{x:1343,y:614,t:1527030608033};\\\", \\\"{x:1345,y:630,t:1527030608049};\\\", \\\"{x:1350,y:644,t:1527030608066};\\\", \\\"{x:1354,y:653,t:1527030608082};\\\", \\\"{x:1362,y:667,t:1527030608100};\\\", \\\"{x:1369,y:679,t:1527030608116};\\\", \\\"{x:1376,y:693,t:1527030608132};\\\", \\\"{x:1382,y:701,t:1527030608148};\\\", \\\"{x:1384,y:708,t:1527030608165};\\\", \\\"{x:1384,y:710,t:1527030608182};\\\", \\\"{x:1386,y:716,t:1527030608198};\\\", \\\"{x:1386,y:719,t:1527030608215};\\\", \\\"{x:1387,y:724,t:1527030608232};\\\", \\\"{x:1388,y:732,t:1527030608249};\\\", \\\"{x:1388,y:739,t:1527030608265};\\\", \\\"{x:1388,y:743,t:1527030608282};\\\", \\\"{x:1388,y:751,t:1527030608298};\\\", \\\"{x:1388,y:757,t:1527030608315};\\\", \\\"{x:1388,y:763,t:1527030608333};\\\", \\\"{x:1388,y:769,t:1527030608349};\\\", \\\"{x:1386,y:777,t:1527030608365};\\\", \\\"{x:1383,y:782,t:1527030608382};\\\", \\\"{x:1379,y:788,t:1527030608398};\\\", \\\"{x:1374,y:796,t:1527030608415};\\\", \\\"{x:1373,y:801,t:1527030608432};\\\", \\\"{x:1372,y:805,t:1527030608451};\\\", \\\"{x:1371,y:810,t:1527030608465};\\\", \\\"{x:1371,y:814,t:1527030608482};\\\", \\\"{x:1371,y:819,t:1527030608499};\\\", \\\"{x:1369,y:824,t:1527030608515};\\\", \\\"{x:1369,y:828,t:1527030608531};\\\", \\\"{x:1368,y:836,t:1527030608548};\\\", \\\"{x:1365,y:848,t:1527030608565};\\\", \\\"{x:1362,y:857,t:1527030608582};\\\", \\\"{x:1360,y:864,t:1527030608599};\\\", \\\"{x:1353,y:874,t:1527030608615};\\\", \\\"{x:1345,y:884,t:1527030608632};\\\", \\\"{x:1335,y:893,t:1527030608649};\\\", \\\"{x:1325,y:901,t:1527030608665};\\\", \\\"{x:1320,y:905,t:1527030608681};\\\", \\\"{x:1319,y:906,t:1527030608697};\\\", \\\"{x:1318,y:907,t:1527030608797};\\\", \\\"{x:1320,y:906,t:1527030608893};\\\", \\\"{x:1322,y:905,t:1527030608901};\\\", \\\"{x:1324,y:904,t:1527030608914};\\\", \\\"{x:1329,y:904,t:1527030608931};\\\", \\\"{x:1334,y:901,t:1527030608948};\\\", \\\"{x:1335,y:901,t:1527030608965};\\\", \\\"{x:1338,y:901,t:1527030608982};\\\", \\\"{x:1340,y:901,t:1527030608998};\\\", \\\"{x:1341,y:901,t:1527030609014};\\\", \\\"{x:1342,y:900,t:1527030609037};\\\", \\\"{x:1344,y:899,t:1527030609054};\\\", \\\"{x:1345,y:898,t:1527030609109};\\\", \\\"{x:1346,y:898,t:1527030609117};\\\", \\\"{x:1347,y:898,t:1527030609165};\\\", \\\"{x:1348,y:898,t:1527030610741};\\\", \\\"{x:1350,y:896,t:1527030611893};\\\", \\\"{x:1351,y:891,t:1527030611902};\\\", \\\"{x:1351,y:890,t:1527030611913};\\\", \\\"{x:1353,y:883,t:1527030611930};\\\", \\\"{x:1356,y:874,t:1527030611945};\\\", \\\"{x:1359,y:866,t:1527030611962};\\\", \\\"{x:1359,y:861,t:1527030611979};\\\", \\\"{x:1359,y:855,t:1527030611995};\\\", \\\"{x:1359,y:845,t:1527030612013};\\\", \\\"{x:1359,y:837,t:1527030612029};\\\", \\\"{x:1359,y:827,t:1527030612046};\\\", \\\"{x:1360,y:819,t:1527030612062};\\\", \\\"{x:1360,y:812,t:1527030612078};\\\", \\\"{x:1360,y:805,t:1527030612095};\\\", \\\"{x:1360,y:800,t:1527030612112};\\\", \\\"{x:1360,y:796,t:1527030612129};\\\", \\\"{x:1360,y:792,t:1527030612145};\\\", \\\"{x:1362,y:787,t:1527030612163};\\\", \\\"{x:1363,y:782,t:1527030612179};\\\", \\\"{x:1364,y:779,t:1527030612196};\\\", \\\"{x:1364,y:775,t:1527030612213};\\\", \\\"{x:1364,y:773,t:1527030612229};\\\", \\\"{x:1364,y:772,t:1527030612245};\\\", \\\"{x:1365,y:771,t:1527030612263};\\\", \\\"{x:1366,y:769,t:1527030612279};\\\", \\\"{x:1366,y:768,t:1527030612296};\\\", \\\"{x:1367,y:766,t:1527030612313};\\\", \\\"{x:1367,y:765,t:1527030612365};\\\", \\\"{x:1369,y:763,t:1527030612389};\\\", \\\"{x:1369,y:762,t:1527030612414};\\\", \\\"{x:1370,y:761,t:1527030612429};\\\", \\\"{x:1371,y:760,t:1527030612445};\\\", \\\"{x:1371,y:759,t:1527030612469};\\\", \\\"{x:1372,y:759,t:1527030612549};\\\", \\\"{x:1373,y:759,t:1527030612562};\\\", \\\"{x:1374,y:759,t:1527030612579};\\\", \\\"{x:1375,y:759,t:1527030612595};\\\", \\\"{x:1376,y:759,t:1527030612645};\\\", \\\"{x:1376,y:760,t:1527030612734};\\\", \\\"{x:1376,y:761,t:1527030612744};\\\", \\\"{x:1376,y:762,t:1527030612762};\\\", \\\"{x:1377,y:763,t:1527030612789};\\\", \\\"{x:1379,y:765,t:1527030612845};\\\", \\\"{x:1380,y:766,t:1527030612893};\\\", \\\"{x:1380,y:768,t:1527030618541};\\\", \\\"{x:1376,y:769,t:1527030618558};\\\", \\\"{x:1374,y:770,t:1527030618573};\\\", \\\"{x:1371,y:772,t:1527030618590};\\\", \\\"{x:1369,y:773,t:1527030618607};\\\", \\\"{x:1367,y:773,t:1527030618624};\\\", \\\"{x:1366,y:775,t:1527030618640};\\\", \\\"{x:1364,y:775,t:1527030618656};\\\", \\\"{x:1361,y:776,t:1527030618674};\\\", \\\"{x:1358,y:779,t:1527030618690};\\\", \\\"{x:1356,y:780,t:1527030618707};\\\", \\\"{x:1354,y:782,t:1527030618724};\\\", \\\"{x:1351,y:783,t:1527030618740};\\\", \\\"{x:1348,y:786,t:1527030618757};\\\", \\\"{x:1347,y:789,t:1527030618773};\\\", \\\"{x:1345,y:792,t:1527030618789};\\\", \\\"{x:1343,y:795,t:1527030618806};\\\", \\\"{x:1340,y:798,t:1527030618824};\\\", \\\"{x:1337,y:801,t:1527030618840};\\\", \\\"{x:1336,y:803,t:1527030618856};\\\", \\\"{x:1333,y:805,t:1527030618874};\\\", \\\"{x:1331,y:808,t:1527030618890};\\\", \\\"{x:1329,y:809,t:1527030618907};\\\", \\\"{x:1329,y:810,t:1527030618924};\\\", \\\"{x:1327,y:811,t:1527030618940};\\\", \\\"{x:1323,y:815,t:1527030618957};\\\", \\\"{x:1321,y:817,t:1527030618973};\\\", \\\"{x:1319,y:819,t:1527030618990};\\\", \\\"{x:1318,y:820,t:1527030619007};\\\", \\\"{x:1316,y:821,t:1527030619022};\\\", \\\"{x:1314,y:822,t:1527030619040};\\\", \\\"{x:1312,y:824,t:1527030619057};\\\", \\\"{x:1310,y:824,t:1527030619073};\\\", \\\"{x:1307,y:826,t:1527030619089};\\\", \\\"{x:1304,y:827,t:1527030619107};\\\", \\\"{x:1300,y:830,t:1527030619123};\\\", \\\"{x:1300,y:831,t:1527030619140};\\\", \\\"{x:1294,y:834,t:1527030619156};\\\", \\\"{x:1291,y:835,t:1527030619173};\\\", \\\"{x:1288,y:837,t:1527030619190};\\\", \\\"{x:1285,y:839,t:1527030619207};\\\", \\\"{x:1281,y:841,t:1527030619223};\\\", \\\"{x:1276,y:844,t:1527030619240};\\\", \\\"{x:1274,y:845,t:1527030619256};\\\", \\\"{x:1270,y:848,t:1527030619273};\\\", \\\"{x:1268,y:848,t:1527030619290};\\\", \\\"{x:1267,y:849,t:1527030619307};\\\", \\\"{x:1265,y:850,t:1527030619322};\\\", \\\"{x:1264,y:851,t:1527030619340};\\\", \\\"{x:1264,y:847,t:1527030619541};\\\", \\\"{x:1265,y:844,t:1527030619555};\\\", \\\"{x:1266,y:837,t:1527030619573};\\\", \\\"{x:1268,y:832,t:1527030619589};\\\", \\\"{x:1269,y:829,t:1527030619606};\\\", \\\"{x:1270,y:828,t:1527030619622};\\\", \\\"{x:1271,y:825,t:1527030619640};\\\", \\\"{x:1271,y:823,t:1527030619656};\\\", \\\"{x:1271,y:822,t:1527030619673};\\\", \\\"{x:1272,y:822,t:1527030619690};\\\", \\\"{x:1272,y:820,t:1527030619705};\\\", \\\"{x:1273,y:820,t:1527030619902};\\\", \\\"{x:1273,y:821,t:1527030619933};\\\", \\\"{x:1273,y:822,t:1527030619941};\\\", \\\"{x:1274,y:824,t:1527030619965};\\\", \\\"{x:1275,y:825,t:1527030619981};\\\", \\\"{x:1276,y:827,t:1527030621094};\\\", \\\"{x:1277,y:828,t:1527030621125};\\\", \\\"{x:1278,y:828,t:1527030621141};\\\", \\\"{x:1279,y:829,t:1527030621157};\\\", \\\"{x:1281,y:829,t:1527030621171};\\\", \\\"{x:1281,y:830,t:1527030621188};\\\", \\\"{x:1282,y:830,t:1527030621204};\\\", \\\"{x:1285,y:830,t:1527030623333};\\\", \\\"{x:1287,y:830,t:1527030623349};\\\", \\\"{x:1289,y:830,t:1527030623357};\\\", \\\"{x:1290,y:830,t:1527030623370};\\\", \\\"{x:1293,y:830,t:1527030623386};\\\", \\\"{x:1299,y:830,t:1527030623403};\\\", \\\"{x:1305,y:830,t:1527030623420};\\\", \\\"{x:1313,y:830,t:1527030623436};\\\", \\\"{x:1330,y:832,t:1527030623453};\\\", \\\"{x:1341,y:835,t:1527030623470};\\\", \\\"{x:1352,y:837,t:1527030623486};\\\", \\\"{x:1362,y:838,t:1527030623503};\\\", \\\"{x:1369,y:838,t:1527030623520};\\\", \\\"{x:1374,y:838,t:1527030623536};\\\", \\\"{x:1382,y:838,t:1527030623553};\\\", \\\"{x:1388,y:838,t:1527030623570};\\\", \\\"{x:1393,y:838,t:1527030623586};\\\", \\\"{x:1398,y:838,t:1527030623603};\\\", \\\"{x:1400,y:838,t:1527030623620};\\\", \\\"{x:1403,y:838,t:1527030623636};\\\", \\\"{x:1405,y:838,t:1527030623653};\\\", \\\"{x:1406,y:838,t:1527030623670};\\\", \\\"{x:1407,y:837,t:1527030623687};\\\", \\\"{x:1409,y:837,t:1527030623717};\\\", \\\"{x:1410,y:836,t:1527030623732};\\\", \\\"{x:1411,y:836,t:1527030623741};\\\", \\\"{x:1413,y:835,t:1527030623753};\\\", \\\"{x:1414,y:834,t:1527030623769};\\\", \\\"{x:1415,y:834,t:1527030623786};\\\", \\\"{x:1420,y:832,t:1527030623802};\\\", \\\"{x:1422,y:831,t:1527030623819};\\\", \\\"{x:1427,y:830,t:1527030623837};\\\", \\\"{x:1431,y:827,t:1527030623853};\\\", \\\"{x:1434,y:826,t:1527030623869};\\\", \\\"{x:1435,y:826,t:1527030623886};\\\", \\\"{x:1438,y:825,t:1527030623903};\\\", \\\"{x:1438,y:824,t:1527030623925};\\\", \\\"{x:1439,y:824,t:1527030623941};\\\", \\\"{x:1440,y:824,t:1527030623953};\\\", \\\"{x:1443,y:823,t:1527030623970};\\\", \\\"{x:1446,y:821,t:1527030623986};\\\", \\\"{x:1449,y:820,t:1527030624003};\\\", \\\"{x:1452,y:819,t:1527030624019};\\\", \\\"{x:1455,y:817,t:1527030624036};\\\", \\\"{x:1458,y:817,t:1527030624052};\\\", \\\"{x:1461,y:817,t:1527030624068};\\\", \\\"{x:1463,y:816,t:1527030624086};\\\", \\\"{x:1468,y:816,t:1527030624102};\\\", \\\"{x:1475,y:816,t:1527030624120};\\\", \\\"{x:1482,y:816,t:1527030624136};\\\", \\\"{x:1489,y:816,t:1527030624152};\\\", \\\"{x:1492,y:816,t:1527030624169};\\\", \\\"{x:1494,y:816,t:1527030624186};\\\", \\\"{x:1495,y:816,t:1527030624229};\\\", \\\"{x:1496,y:820,t:1527030624357};\\\", \\\"{x:1498,y:822,t:1527030624369};\\\", \\\"{x:1498,y:828,t:1527030624386};\\\", \\\"{x:1495,y:834,t:1527030624401};\\\", \\\"{x:1490,y:835,t:1527030624419};\\\", \\\"{x:1487,y:837,t:1527030624435};\\\", \\\"{x:1484,y:837,t:1527030624702};\\\", \\\"{x:1480,y:836,t:1527030624719};\\\", \\\"{x:1477,y:835,t:1527030624735};\\\", \\\"{x:1475,y:834,t:1527030624752};\\\", \\\"{x:1473,y:832,t:1527030624773};\\\", \\\"{x:1473,y:831,t:1527030624845};\\\", \\\"{x:1473,y:830,t:1527030624893};\\\", \\\"{x:1475,y:830,t:1527030625165};\\\", \\\"{x:1476,y:830,t:1527030625173};\\\", \\\"{x:1478,y:830,t:1527030625185};\\\", \\\"{x:1482,y:831,t:1527030625200};\\\", \\\"{x:1484,y:832,t:1527030625218};\\\", \\\"{x:1485,y:832,t:1527030625235};\\\", \\\"{x:1485,y:834,t:1527030625708};\\\", \\\"{x:1481,y:837,t:1527030625718};\\\", \\\"{x:1459,y:840,t:1527030625733};\\\", \\\"{x:1422,y:840,t:1527030625750};\\\", \\\"{x:1361,y:840,t:1527030625767};\\\", \\\"{x:1297,y:840,t:1527030625783};\\\", \\\"{x:1230,y:832,t:1527030625800};\\\", \\\"{x:1152,y:818,t:1527030625817};\\\", \\\"{x:1075,y:801,t:1527030625834};\\\", \\\"{x:1019,y:783,t:1527030625850};\\\", \\\"{x:974,y:770,t:1527030625867};\\\", \\\"{x:935,y:760,t:1527030625883};\\\", \\\"{x:903,y:754,t:1527030625900};\\\", \\\"{x:891,y:751,t:1527030625917};\\\", \\\"{x:884,y:751,t:1527030625933};\\\", \\\"{x:883,y:751,t:1527030625950};\\\", \\\"{x:881,y:751,t:1527030625966};\\\", \\\"{x:879,y:751,t:1527030625983};\\\", \\\"{x:876,y:751,t:1527030626000};\\\", \\\"{x:868,y:751,t:1527030626016};\\\", \\\"{x:860,y:751,t:1527030626034};\\\", \\\"{x:852,y:751,t:1527030626050};\\\", \\\"{x:848,y:750,t:1527030626067};\\\", \\\"{x:845,y:749,t:1527030626083};\\\", \\\"{x:841,y:747,t:1527030626100};\\\", \\\"{x:839,y:746,t:1527030626117};\\\", \\\"{x:837,y:744,t:1527030626133};\\\", \\\"{x:837,y:743,t:1527030626151};\\\", \\\"{x:835,y:743,t:1527030626166};\\\", \\\"{x:834,y:742,t:1527030626183};\\\", \\\"{x:833,y:741,t:1527030626200};\\\", \\\"{x:833,y:740,t:1527030626216};\\\", \\\"{x:833,y:738,t:1527030626234};\\\", \\\"{x:833,y:737,t:1527030626251};\\\", \\\"{x:836,y:733,t:1527030626266};\\\", \\\"{x:848,y:729,t:1527030626284};\\\", \\\"{x:869,y:727,t:1527030626299};\\\", \\\"{x:890,y:727,t:1527030626317};\\\", \\\"{x:919,y:732,t:1527030626334};\\\", \\\"{x:965,y:741,t:1527030626351};\\\", \\\"{x:1028,y:753,t:1527030626367};\\\", \\\"{x:1109,y:766,t:1527030626384};\\\", \\\"{x:1178,y:774,t:1527030626400};\\\", \\\"{x:1251,y:785,t:1527030626417};\\\", \\\"{x:1319,y:801,t:1527030626434};\\\", \\\"{x:1372,y:809,t:1527030626450};\\\", \\\"{x:1407,y:815,t:1527030626466};\\\", \\\"{x:1431,y:818,t:1527030626484};\\\", \\\"{x:1443,y:820,t:1527030626500};\\\", \\\"{x:1446,y:820,t:1527030626517};\\\", \\\"{x:1448,y:820,t:1527030626773};\\\", \\\"{x:1449,y:820,t:1527030626783};\\\", \\\"{x:1453,y:820,t:1527030626800};\\\", \\\"{x:1457,y:820,t:1527030626817};\\\", \\\"{x:1459,y:821,t:1527030626837};\\\", \\\"{x:1461,y:821,t:1527030626861};\\\", \\\"{x:1461,y:822,t:1527030626869};\\\", \\\"{x:1463,y:823,t:1527030626882};\\\", \\\"{x:1464,y:823,t:1527030626900};\\\", \\\"{x:1467,y:824,t:1527030626917};\\\", \\\"{x:1468,y:824,t:1527030626933};\\\", \\\"{x:1469,y:824,t:1527030626956};\\\", \\\"{x:1470,y:824,t:1527030626980};\\\", \\\"{x:1471,y:824,t:1527030626987};\\\", \\\"{x:1472,y:824,t:1527030626999};\\\", \\\"{x:1471,y:824,t:1527030627044};\\\", \\\"{x:1469,y:824,t:1527030627051};\\\", \\\"{x:1464,y:823,t:1527030627067};\\\", \\\"{x:1449,y:822,t:1527030627082};\\\", \\\"{x:1402,y:813,t:1527030627100};\\\", \\\"{x:1248,y:772,t:1527030627116};\\\", \\\"{x:1107,y:733,t:1527030627133};\\\", \\\"{x:963,y:694,t:1527030627150};\\\", \\\"{x:806,y:650,t:1527030627166};\\\", \\\"{x:654,y:608,t:1527030627184};\\\", \\\"{x:502,y:568,t:1527030627201};\\\", \\\"{x:345,y:522,t:1527030627216};\\\", \\\"{x:119,y:467,t:1527030627240};\\\", \\\"{x:0,y:442,t:1527030627256};\\\", \\\"{x:0,y:424,t:1527030627272};\\\", \\\"{x:0,y:414,t:1527030627290};\\\", \\\"{x:0,y:409,t:1527030627305};\\\", \\\"{x:0,y:404,t:1527030627322};\\\", \\\"{x:0,y:403,t:1527030627340};\\\", \\\"{x:2,y:403,t:1527030627372};\\\", \\\"{x:18,y:404,t:1527030627389};\\\", \\\"{x:43,y:412,t:1527030627405};\\\", \\\"{x:93,y:424,t:1527030627423};\\\", \\\"{x:136,y:441,t:1527030627440};\\\", \\\"{x:175,y:452,t:1527030627456};\\\", \\\"{x:221,y:467,t:1527030627472};\\\", \\\"{x:270,y:488,t:1527030627490};\\\", \\\"{x:343,y:508,t:1527030627506};\\\", \\\"{x:429,y:535,t:1527030627523};\\\", \\\"{x:512,y:557,t:1527030627540};\\\", \\\"{x:569,y:577,t:1527030627556};\\\", \\\"{x:638,y:604,t:1527030627573};\\\", \\\"{x:660,y:611,t:1527030627589};\\\", \\\"{x:669,y:614,t:1527030627607};\\\", \\\"{x:670,y:615,t:1527030627622};\\\", \\\"{x:671,y:615,t:1527030627724};\\\", \\\"{x:671,y:617,t:1527030627748};\\\", \\\"{x:670,y:617,t:1527030627764};\\\", \\\"{x:668,y:617,t:1527030627780};\\\", \\\"{x:667,y:617,t:1527030627789};\\\", \\\"{x:659,y:617,t:1527030627806};\\\", \\\"{x:650,y:617,t:1527030627822};\\\", \\\"{x:641,y:617,t:1527030627840};\\\", \\\"{x:634,y:617,t:1527030627857};\\\", \\\"{x:628,y:615,t:1527030627872};\\\", \\\"{x:620,y:612,t:1527030627889};\\\", \\\"{x:615,y:608,t:1527030627907};\\\", \\\"{x:613,y:608,t:1527030627923};\\\", \\\"{x:625,y:615,t:1527030628462};\\\", \\\"{x:646,y:624,t:1527030628475};\\\", \\\"{x:698,y:647,t:1527030628490};\\\", \\\"{x:777,y:673,t:1527030628506};\\\", \\\"{x:918,y:712,t:1527030628523};\\\", \\\"{x:1042,y:746,t:1527030628539};\\\", \\\"{x:1179,y:778,t:1527030628557};\\\", \\\"{x:1322,y:811,t:1527030628574};\\\", \\\"{x:1462,y:841,t:1527030628591};\\\", \\\"{x:1588,y:870,t:1527030628607};\\\", \\\"{x:1706,y:895,t:1527030628623};\\\", \\\"{x:1804,y:915,t:1527030628641};\\\", \\\"{x:1896,y:930,t:1527030628656};\\\", \\\"{x:1919,y:940,t:1527030628674};\\\", \\\"{x:1919,y:946,t:1527030628690};\\\", \\\"{x:1919,y:949,t:1527030628706};\\\", \\\"{x:1919,y:951,t:1527030628723};\\\", \\\"{x:1918,y:950,t:1527030628805};\\\", \\\"{x:1909,y:944,t:1527030628824};\\\", \\\"{x:1887,y:931,t:1527030628840};\\\", \\\"{x:1860,y:915,t:1527030628856};\\\", \\\"{x:1818,y:894,t:1527030628873};\\\", \\\"{x:1755,y:870,t:1527030628890};\\\", \\\"{x:1671,y:845,t:1527030628908};\\\", \\\"{x:1637,y:834,t:1527030628923};\\\", \\\"{x:1615,y:829,t:1527030628941};\\\", \\\"{x:1594,y:820,t:1527030628958};\\\", \\\"{x:1580,y:815,t:1527030628974};\\\", \\\"{x:1574,y:811,t:1527030628991};\\\", \\\"{x:1572,y:811,t:1527030629008};\\\", \\\"{x:1571,y:810,t:1527030629036};\\\", \\\"{x:1570,y:809,t:1527030629084};\\\", \\\"{x:1569,y:809,t:1527030629099};\\\", \\\"{x:1568,y:809,t:1527030629107};\\\", \\\"{x:1565,y:809,t:1527030629124};\\\", \\\"{x:1558,y:809,t:1527030629141};\\\", \\\"{x:1547,y:809,t:1527030629158};\\\", \\\"{x:1530,y:809,t:1527030629174};\\\", \\\"{x:1517,y:809,t:1527030629191};\\\", \\\"{x:1504,y:810,t:1527030629208};\\\", \\\"{x:1498,y:810,t:1527030629225};\\\", \\\"{x:1494,y:813,t:1527030629241};\\\", \\\"{x:1493,y:813,t:1527030629261};\\\", \\\"{x:1492,y:813,t:1527030629493};\\\", \\\"{x:1491,y:814,t:1527030629508};\\\", \\\"{x:1489,y:814,t:1527030629525};\\\", \\\"{x:1488,y:815,t:1527030629542};\\\", \\\"{x:1486,y:817,t:1527030629565};\\\", \\\"{x:1486,y:818,t:1527030629597};\\\", \\\"{x:1486,y:819,t:1527030629613};\\\", \\\"{x:1485,y:821,t:1527030629901};\\\", \\\"{x:1485,y:822,t:1527030629908};\\\", \\\"{x:1483,y:823,t:1527030629926};\\\", \\\"{x:1482,y:825,t:1527030629942};\\\", \\\"{x:1480,y:828,t:1527030629959};\\\", \\\"{x:1479,y:829,t:1527030630236};\\\", \\\"{x:1478,y:829,t:1527030630244};\\\", \\\"{x:1478,y:831,t:1527030630259};\\\", \\\"{x:1477,y:833,t:1527030630276};\\\", \\\"{x:1476,y:834,t:1527030630294};\\\", \\\"{x:1476,y:835,t:1527030630309};\\\", \\\"{x:1476,y:836,t:1527030630341};\\\", \\\"{x:1473,y:837,t:1527030630677};\\\", \\\"{x:1455,y:837,t:1527030630693};\\\", \\\"{x:1419,y:825,t:1527030630710};\\\", \\\"{x:1339,y:800,t:1527030630726};\\\", \\\"{x:1220,y:767,t:1527030630742};\\\", \\\"{x:1093,y:733,t:1527030630760};\\\", \\\"{x:986,y:711,t:1527030630776};\\\", \\\"{x:917,y:702,t:1527030630792};\\\", \\\"{x:880,y:697,t:1527030630810};\\\", \\\"{x:856,y:690,t:1527030630827};\\\", \\\"{x:844,y:687,t:1527030630843};\\\", \\\"{x:841,y:686,t:1527030630859};\\\", \\\"{x:840,y:686,t:1527030630916};\\\", \\\"{x:840,y:690,t:1527030630927};\\\", \\\"{x:840,y:695,t:1527030630943};\\\", \\\"{x:840,y:701,t:1527030630960};\\\", \\\"{x:840,y:706,t:1527030630977};\\\", \\\"{x:840,y:712,t:1527030630993};\\\", \\\"{x:840,y:719,t:1527030631010};\\\", \\\"{x:840,y:727,t:1527030631026};\\\", \\\"{x:841,y:740,t:1527030631043};\\\", \\\"{x:845,y:756,t:1527030631060};\\\", \\\"{x:846,y:764,t:1527030631077};\\\", \\\"{x:847,y:773,t:1527030631094};\\\", \\\"{x:848,y:779,t:1527030631110};\\\", \\\"{x:849,y:784,t:1527030631127};\\\", \\\"{x:850,y:792,t:1527030631144};\\\", \\\"{x:851,y:800,t:1527030631160};\\\", \\\"{x:851,y:801,t:1527030631176};\\\", \\\"{x:851,y:802,t:1527030631194};\\\", \\\"{x:851,y:803,t:1527030631209};\\\", \\\"{x:851,y:804,t:1527030631228};\\\", \\\"{x:851,y:806,t:1527030631244};\\\", \\\"{x:851,y:807,t:1527030631269};\\\", \\\"{x:851,y:808,t:1527030631284};\\\", \\\"{x:851,y:809,t:1527030631300};\\\", \\\"{x:851,y:810,t:1527030631324};\\\", \\\"{x:851,y:811,t:1527030631341};\\\", \\\"{x:851,y:812,t:1527030631348};\\\", \\\"{x:851,y:813,t:1527030631360};\\\", \\\"{x:849,y:815,t:1527030631377};\\\", \\\"{x:849,y:816,t:1527030631394};\\\", \\\"{x:849,y:817,t:1527030631411};\\\", \\\"{x:848,y:818,t:1527030631427};\\\", \\\"{x:848,y:819,t:1527030631444};\\\", \\\"{x:847,y:821,t:1527030631468};\\\", \\\"{x:846,y:822,t:1527030631525};\\\", \\\"{x:845,y:822,t:1527030631540};\\\", \\\"{x:844,y:823,t:1527030631565};\\\", \\\"{x:843,y:823,t:1527030631581};\\\", \\\"{x:843,y:824,t:1527030631594};\\\", \\\"{x:841,y:825,t:1527030631620};\\\", \\\"{x:840,y:825,t:1527030631636};\\\", \\\"{x:838,y:825,t:1527030631661};\\\", \\\"{x:837,y:826,t:1527030631678};\\\", \\\"{x:835,y:826,t:1527030631694};\\\", \\\"{x:832,y:827,t:1527030631711};\\\", \\\"{x:830,y:828,t:1527030631728};\\\", \\\"{x:828,y:828,t:1527030631744};\\\", \\\"{x:824,y:828,t:1527030631761};\\\", \\\"{x:822,y:828,t:1527030631778};\\\", \\\"{x:820,y:828,t:1527030631794};\\\", \\\"{x:816,y:828,t:1527030631811};\\\", \\\"{x:810,y:828,t:1527030631828};\\\", \\\"{x:803,y:828,t:1527030631844};\\\", \\\"{x:796,y:828,t:1527030631861};\\\", \\\"{x:787,y:828,t:1527030631878};\\\", \\\"{x:777,y:828,t:1527030631894};\\\", \\\"{x:769,y:828,t:1527030631911};\\\", \\\"{x:762,y:828,t:1527030631928};\\\", \\\"{x:755,y:828,t:1527030631944};\\\", \\\"{x:749,y:828,t:1527030631961};\\\", \\\"{x:744,y:828,t:1527030631978};\\\", \\\"{x:741,y:828,t:1527030631995};\\\", \\\"{x:739,y:828,t:1527030632011};\\\", \\\"{x:735,y:828,t:1527030632028};\\\", \\\"{x:734,y:828,t:1527030632109};\\\", \\\"{x:733,y:828,t:1527030632117};\\\", \\\"{x:732,y:828,t:1527030632141};\\\", \\\"{x:731,y:828,t:1527030632157};\\\", \\\"{x:730,y:828,t:1527030632165};\\\", \\\"{x:729,y:828,t:1527030632180};\\\", \\\"{x:727,y:828,t:1527030632195};\\\", \\\"{x:726,y:828,t:1527030632221};\\\", \\\"{x:725,y:828,t:1527030632245};\\\", \\\"{x:724,y:828,t:1527030632891};\\\", \\\"{x:722,y:829,t:1527030632915};\\\", \\\"{x:721,y:829,t:1527030632940};\\\", \\\"{x:720,y:829,t:1527030632947};\\\", \\\"{x:719,y:829,t:1527030632963};\\\", \\\"{x:718,y:829,t:1527030632979};\\\", \\\"{x:716,y:829,t:1527030632996};\\\", \\\"{x:714,y:829,t:1527030633012};\\\", \\\"{x:713,y:829,t:1527030633029};\\\", \\\"{x:712,y:829,t:1527030633046};\\\", \\\"{x:711,y:829,t:1527030633061};\\\", \\\"{x:709,y:829,t:1527030633078};\\\", \\\"{x:707,y:829,t:1527030633095};\\\", \\\"{x:705,y:829,t:1527030633112};\\\", \\\"{x:704,y:829,t:1527030633128};\\\", \\\"{x:702,y:831,t:1527030633146};\\\", \\\"{x:699,y:831,t:1527030633162};\\\", \\\"{x:696,y:831,t:1527030633178};\\\", \\\"{x:689,y:831,t:1527030633196};\\\", \\\"{x:685,y:831,t:1527030633213};\\\", \\\"{x:681,y:831,t:1527030633229};\\\", \\\"{x:678,y:831,t:1527030633246};\\\", \\\"{x:674,y:831,t:1527030633263};\\\", \\\"{x:671,y:831,t:1527030633278};\\\", \\\"{x:668,y:831,t:1527030633296};\\\", \\\"{x:667,y:831,t:1527030633313};\\\", \\\"{x:665,y:831,t:1527030633329};\\\", \\\"{x:663,y:831,t:1527030633346};\\\", \\\"{x:661,y:831,t:1527030633363};\\\", \\\"{x:656,y:832,t:1527030633380};\\\", \\\"{x:652,y:833,t:1527030633396};\\\", \\\"{x:647,y:834,t:1527030633413};\\\", \\\"{x:640,y:834,t:1527030633430};\\\", \\\"{x:631,y:834,t:1527030633446};\\\", \\\"{x:618,y:834,t:1527030633463};\\\", \\\"{x:607,y:832,t:1527030633480};\\\", \\\"{x:594,y:829,t:1527030633496};\\\", \\\"{x:582,y:825,t:1527030633513};\\\", \\\"{x:575,y:824,t:1527030633530};\\\", \\\"{x:564,y:822,t:1527030633546};\\\", \\\"{x:553,y:818,t:1527030633563};\\\", \\\"{x:539,y:815,t:1527030633580};\\\", \\\"{x:528,y:813,t:1527030633596};\\\", \\\"{x:515,y:809,t:1527030633614};\\\", \\\"{x:499,y:803,t:1527030633630};\\\", \\\"{x:482,y:798,t:1527030633646};\\\", \\\"{x:466,y:794,t:1527030633664};\\\", \\\"{x:450,y:786,t:1527030633680};\\\", \\\"{x:434,y:779,t:1527030633697};\\\", \\\"{x:423,y:773,t:1527030633714};\\\", \\\"{x:415,y:769,t:1527030633730};\\\", \\\"{x:410,y:765,t:1527030633748};\\\", \\\"{x:405,y:761,t:1527030633763};\\\", \\\"{x:401,y:756,t:1527030633780};\\\", \\\"{x:401,y:755,t:1527030633797};\\\", \\\"{x:400,y:753,t:1527030633813};\\\", \\\"{x:399,y:751,t:1527030633830};\\\", \\\"{x:399,y:750,t:1527030633849};\\\", \\\"{x:399,y:749,t:1527030633863};\\\", \\\"{x:399,y:747,t:1527030633880};\\\", \\\"{x:399,y:746,t:1527030633897};\\\", \\\"{x:399,y:745,t:1527030633913};\\\", \\\"{x:399,y:744,t:1527030633930};\\\", \\\"{x:399,y:742,t:1527030633955};\\\", \\\"{x:399,y:741,t:1527030633963};\\\", \\\"{x:400,y:740,t:1527030633979};\\\", \\\"{x:405,y:738,t:1527030633997};\\\", \\\"{x:408,y:737,t:1527030634014};\\\", \\\"{x:415,y:736,t:1527030634029};\\\", \\\"{x:422,y:733,t:1527030634047};\\\", \\\"{x:429,y:733,t:1527030634064};\\\", \\\"{x:435,y:733,t:1527030634080};\\\", \\\"{x:442,y:733,t:1527030634097};\\\", \\\"{x:446,y:733,t:1527030634114};\\\", \\\"{x:450,y:733,t:1527030634130};\\\", \\\"{x:456,y:733,t:1527030634146};\\\", \\\"{x:462,y:733,t:1527030634161};\\\", \\\"{x:465,y:733,t:1527030634178};\\\", \\\"{x:468,y:733,t:1527030634194};\\\", \\\"{x:470,y:733,t:1527030634211};\\\", \\\"{x:472,y:733,t:1527030634228};\\\", \\\"{x:475,y:733,t:1527030634244};\\\", \\\"{x:477,y:733,t:1527030634261};\\\", \\\"{x:481,y:733,t:1527030634277};\\\", \\\"{x:483,y:733,t:1527030634294};\\\", \\\"{x:485,y:733,t:1527030634311};\\\", \\\"{x:488,y:733,t:1527030634328};\\\", \\\"{x:489,y:733,t:1527030634344};\\\", \\\"{x:490,y:733,t:1527030634361};\\\", \\\"{x:488,y:733,t:1527030636508};\\\", \\\"{x:487,y:733,t:1527030636531};\\\" ] }, { \\\"rt\\\": 10344, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 10, \\\"time_elapsed\\\": 403590, \\\"internal_node_id\\\": \\\"0.0-6.0-0.0\\\", \\\"subject\\\": \\\"E5L6P\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration\\\", \\\"q\\\": 6, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\", \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:486,y:727,t:1527030637988};\\\", \\\"{x:486,y:694,t:1527030637999};\\\", \\\"{x:486,y:622,t:1527030638014};\\\", \\\"{x:486,y:555,t:1527030638031};\\\", \\\"{x:486,y:499,t:1527030638049};\\\", \\\"{x:480,y:441,t:1527030638066};\\\", \\\"{x:461,y:380,t:1527030638081};\\\", \\\"{x:438,y:322,t:1527030638098};\\\", \\\"{x:424,y:294,t:1527030638114};\\\", \\\"{x:413,y:275,t:1527030638131};\\\", \\\"{x:403,y:260,t:1527030638148};\\\", \\\"{x:401,y:258,t:1527030638164};\\\", \\\"{x:400,y:257,t:1527030638212};\\\", \\\"{x:400,y:265,t:1527030638244};\\\", \\\"{x:400,y:277,t:1527030638252};\\\", \\\"{x:400,y:290,t:1527030638263};\\\", \\\"{x:400,y:315,t:1527030638281};\\\", \\\"{x:400,y:337,t:1527030638298};\\\", \\\"{x:400,y:358,t:1527030638314};\\\", \\\"{x:403,y:378,t:1527030638330};\\\", \\\"{x:417,y:401,t:1527030638348};\\\", \\\"{x:426,y:416,t:1527030638365};\\\", \\\"{x:439,y:429,t:1527030638381};\\\", \\\"{x:450,y:441,t:1527030638398};\\\", \\\"{x:461,y:451,t:1527030638415};\\\", \\\"{x:469,y:457,t:1527030638431};\\\", \\\"{x:474,y:461,t:1527030638449};\\\", \\\"{x:477,y:464,t:1527030638464};\\\", \\\"{x:479,y:465,t:1527030638482};\\\", \\\"{x:479,y:466,t:1527030638497};\\\", \\\"{x:480,y:466,t:1527030638540};\\\", \\\"{x:483,y:466,t:1527030638575};\\\", \\\"{x:485,y:466,t:1527030638581};\\\", \\\"{x:490,y:464,t:1527030638597};\\\", \\\"{x:495,y:462,t:1527030638614};\\\", \\\"{x:503,y:460,t:1527030638631};\\\", \\\"{x:508,y:459,t:1527030638646};\\\", \\\"{x:513,y:459,t:1527030638664};\\\", \\\"{x:515,y:459,t:1527030638681};\\\", \\\"{x:517,y:459,t:1527030638696};\\\", \\\"{x:519,y:459,t:1527030638714};\\\", \\\"{x:521,y:458,t:1527030638731};\\\", \\\"{x:524,y:458,t:1527030638747};\\\", \\\"{x:530,y:457,t:1527030638764};\\\", \\\"{x:534,y:456,t:1527030638781};\\\", \\\"{x:537,y:455,t:1527030638797};\\\", \\\"{x:542,y:455,t:1527030638814};\\\", \\\"{x:546,y:455,t:1527030638831};\\\", \\\"{x:552,y:455,t:1527030638847};\\\", \\\"{x:559,y:455,t:1527030638864};\\\", \\\"{x:570,y:457,t:1527030638882};\\\", \\\"{x:583,y:462,t:1527030638897};\\\", \\\"{x:596,y:466,t:1527030638915};\\\", \\\"{x:612,y:473,t:1527030638930};\\\", \\\"{x:631,y:477,t:1527030638948};\\\", \\\"{x:655,y:483,t:1527030638964};\\\", \\\"{x:674,y:489,t:1527030638982};\\\", \\\"{x:693,y:494,t:1527030638997};\\\", \\\"{x:714,y:501,t:1527030639015};\\\", \\\"{x:735,y:504,t:1527030639032};\\\", \\\"{x:752,y:511,t:1527030639048};\\\", \\\"{x:773,y:517,t:1527030639065};\\\", \\\"{x:791,y:522,t:1527030639082};\\\", \\\"{x:812,y:528,t:1527030639099};\\\", \\\"{x:834,y:534,t:1527030639115};\\\", \\\"{x:869,y:545,t:1527030639132};\\\", \\\"{x:895,y:552,t:1527030639149};\\\", \\\"{x:917,y:560,t:1527030639165};\\\", \\\"{x:940,y:567,t:1527030639182};\\\", \\\"{x:961,y:574,t:1527030639199};\\\", \\\"{x:986,y:583,t:1527030639215};\\\", \\\"{x:1016,y:591,t:1527030639232};\\\", \\\"{x:1045,y:598,t:1527030639249};\\\", \\\"{x:1079,y:609,t:1527030639266};\\\", \\\"{x:1119,y:621,t:1527030639282};\\\", \\\"{x:1164,y:633,t:1527030639299};\\\", \\\"{x:1237,y:655,t:1527030639315};\\\", \\\"{x:1284,y:669,t:1527030639332};\\\", \\\"{x:1334,y:683,t:1527030639349};\\\", \\\"{x:1368,y:693,t:1527030639366};\\\", \\\"{x:1412,y:711,t:1527030639383};\\\", \\\"{x:1443,y:720,t:1527030639400};\\\", \\\"{x:1466,y:729,t:1527030639416};\\\", \\\"{x:1477,y:731,t:1527030639434};\\\", \\\"{x:1483,y:731,t:1527030639449};\\\", \\\"{x:1488,y:733,t:1527030639466};\\\", \\\"{x:1490,y:733,t:1527030639483};\\\", \\\"{x:1492,y:735,t:1527030639499};\\\", \\\"{x:1497,y:735,t:1527030639515};\\\", \\\"{x:1499,y:737,t:1527030639533};\\\", \\\"{x:1502,y:739,t:1527030639556};\\\", \\\"{x:1504,y:739,t:1527030639621};\\\", \\\"{x:1504,y:740,t:1527030639693};\\\", \\\"{x:1502,y:740,t:1527030639700};\\\", \\\"{x:1493,y:738,t:1527030639718};\\\", \\\"{x:1483,y:734,t:1527030639734};\\\", \\\"{x:1475,y:732,t:1527030639751};\\\", \\\"{x:1470,y:731,t:1527030639767};\\\", \\\"{x:1464,y:730,t:1527030639785};\\\", \\\"{x:1455,y:729,t:1527030639801};\\\", \\\"{x:1447,y:727,t:1527030639817};\\\", \\\"{x:1442,y:726,t:1527030639835};\\\", \\\"{x:1438,y:725,t:1527030639850};\\\", \\\"{x:1434,y:725,t:1527030639868};\\\", \\\"{x:1429,y:724,t:1527030639884};\\\", \\\"{x:1428,y:724,t:1527030639901};\\\", \\\"{x:1425,y:723,t:1527030639918};\\\", \\\"{x:1421,y:723,t:1527030639934};\\\", \\\"{x:1414,y:722,t:1527030639951};\\\", \\\"{x:1403,y:719,t:1527030639968};\\\", \\\"{x:1386,y:717,t:1527030639985};\\\", \\\"{x:1362,y:710,t:1527030640002};\\\", \\\"{x:1336,y:706,t:1527030640017};\\\", \\\"{x:1300,y:699,t:1527030640034};\\\", \\\"{x:1273,y:695,t:1527030640052};\\\", \\\"{x:1224,y:680,t:1527030640068};\\\", \\\"{x:1190,y:662,t:1527030640085};\\\", \\\"{x:1146,y:644,t:1527030640102};\\\", \\\"{x:1114,y:628,t:1527030640119};\\\", \\\"{x:1095,y:617,t:1527030640135};\\\", \\\"{x:1077,y:609,t:1527030640152};\\\", \\\"{x:1062,y:600,t:1527030640169};\\\", \\\"{x:1051,y:594,t:1527030640186};\\\", \\\"{x:1042,y:587,t:1527030640201};\\\", \\\"{x:1039,y:583,t:1527030640218};\\\", \\\"{x:1035,y:579,t:1527030640236};\\\", \\\"{x:1030,y:571,t:1527030640252};\\\", \\\"{x:1022,y:557,t:1527030640269};\\\", \\\"{x:1018,y:549,t:1527030640286};\\\", \\\"{x:1015,y:545,t:1527030640302};\\\", \\\"{x:1014,y:540,t:1527030640318};\\\", \\\"{x:1013,y:537,t:1527030640336};\\\", \\\"{x:1013,y:536,t:1527030640352};\\\", \\\"{x:1013,y:537,t:1527030640516};\\\", \\\"{x:1015,y:542,t:1527030640524};\\\", \\\"{x:1017,y:546,t:1527030640536};\\\", \\\"{x:1021,y:558,t:1527030640553};\\\", \\\"{x:1029,y:570,t:1527030640570};\\\", \\\"{x:1035,y:579,t:1527030640586};\\\", \\\"{x:1039,y:585,t:1527030640603};\\\", \\\"{x:1041,y:588,t:1527030640620};\\\", \\\"{x:1042,y:588,t:1527030640637};\\\", \\\"{x:1043,y:588,t:1527030640869};\\\", \\\"{x:1044,y:587,t:1527030640876};\\\", \\\"{x:1045,y:586,t:1527030640886};\\\", \\\"{x:1045,y:585,t:1527030640903};\\\", \\\"{x:1046,y:582,t:1527030640921};\\\", \\\"{x:1048,y:580,t:1527030640937};\\\", \\\"{x:1051,y:578,t:1527030640953};\\\", \\\"{x:1053,y:577,t:1527030640970};\\\", \\\"{x:1058,y:576,t:1527030640988};\\\", \\\"{x:1060,y:574,t:1527030641004};\\\", \\\"{x:1065,y:571,t:1527030641021};\\\", \\\"{x:1066,y:571,t:1527030641038};\\\", \\\"{x:1067,y:570,t:1527030641179};\\\", \\\"{x:1068,y:570,t:1527030641187};\\\", \\\"{x:1070,y:569,t:1527030641204};\\\", \\\"{x:1073,y:568,t:1527030641221};\\\", \\\"{x:1075,y:567,t:1527030641237};\\\", \\\"{x:1078,y:566,t:1527030641254};\\\", \\\"{x:1083,y:565,t:1527030641271};\\\", \\\"{x:1086,y:565,t:1527030641287};\\\", \\\"{x:1089,y:565,t:1527030641304};\\\", \\\"{x:1094,y:565,t:1527030641322};\\\", \\\"{x:1098,y:565,t:1527030641338};\\\", \\\"{x:1104,y:565,t:1527030641354};\\\", \\\"{x:1109,y:565,t:1527030641371};\\\", \\\"{x:1115,y:565,t:1527030641388};\\\", \\\"{x:1119,y:565,t:1527030641404};\\\", \\\"{x:1124,y:565,t:1527030641422};\\\", \\\"{x:1129,y:566,t:1527030641439};\\\", \\\"{x:1135,y:568,t:1527030641454};\\\", \\\"{x:1140,y:568,t:1527030641471};\\\", \\\"{x:1146,y:568,t:1527030641488};\\\", \\\"{x:1155,y:570,t:1527030641505};\\\", \\\"{x:1161,y:570,t:1527030641522};\\\", \\\"{x:1168,y:572,t:1527030641539};\\\", \\\"{x:1176,y:573,t:1527030641556};\\\", \\\"{x:1186,y:574,t:1527030641572};\\\", \\\"{x:1198,y:574,t:1527030641588};\\\", \\\"{x:1208,y:574,t:1527030641604};\\\", \\\"{x:1216,y:574,t:1527030641621};\\\", \\\"{x:1225,y:574,t:1527030641638};\\\", \\\"{x:1233,y:574,t:1527030641655};\\\", \\\"{x:1241,y:574,t:1527030641672};\\\", \\\"{x:1245,y:576,t:1527030641688};\\\", \\\"{x:1251,y:576,t:1527030641705};\\\", \\\"{x:1255,y:578,t:1527030641722};\\\", \\\"{x:1259,y:578,t:1527030641739};\\\", \\\"{x:1264,y:578,t:1527030641755};\\\", \\\"{x:1269,y:578,t:1527030641772};\\\", \\\"{x:1271,y:580,t:1527030641789};\\\", \\\"{x:1274,y:580,t:1527030641805};\\\", \\\"{x:1278,y:581,t:1527030641822};\\\", \\\"{x:1281,y:582,t:1527030641840};\\\", \\\"{x:1286,y:582,t:1527030641856};\\\", \\\"{x:1289,y:583,t:1527030641872};\\\", \\\"{x:1293,y:583,t:1527030641890};\\\", \\\"{x:1297,y:584,t:1527030641907};\\\", \\\"{x:1301,y:585,t:1527030641923};\\\", \\\"{x:1304,y:585,t:1527030641939};\\\", \\\"{x:1307,y:585,t:1527030641956};\\\", \\\"{x:1309,y:585,t:1527030641974};\\\", \\\"{x:1311,y:585,t:1527030641990};\\\", \\\"{x:1315,y:585,t:1527030642007};\\\", \\\"{x:1318,y:585,t:1527030642024};\\\", \\\"{x:1321,y:585,t:1527030642040};\\\", \\\"{x:1322,y:585,t:1527030642057};\\\", \\\"{x:1325,y:585,t:1527030642073};\\\", \\\"{x:1328,y:585,t:1527030642090};\\\", \\\"{x:1332,y:585,t:1527030642106};\\\", \\\"{x:1338,y:585,t:1527030642124};\\\", \\\"{x:1349,y:585,t:1527030642140};\\\", \\\"{x:1359,y:585,t:1527030642156};\\\", \\\"{x:1367,y:585,t:1527030642174};\\\", \\\"{x:1375,y:585,t:1527030642191};\\\", \\\"{x:1384,y:585,t:1527030642207};\\\", \\\"{x:1393,y:584,t:1527030642223};\\\", \\\"{x:1400,y:583,t:1527030642240};\\\", \\\"{x:1410,y:582,t:1527030642257};\\\", \\\"{x:1415,y:581,t:1527030642273};\\\", \\\"{x:1419,y:579,t:1527030642291};\\\", \\\"{x:1424,y:578,t:1527030642308};\\\", \\\"{x:1429,y:577,t:1527030642324};\\\", \\\"{x:1436,y:575,t:1527030642341};\\\", \\\"{x:1440,y:574,t:1527030642358};\\\", \\\"{x:1446,y:571,t:1527030642377};\\\", \\\"{x:1448,y:571,t:1527030642390};\\\", \\\"{x:1450,y:571,t:1527030642408};\\\", \\\"{x:1452,y:569,t:1527030642424};\\\", \\\"{x:1447,y:572,t:1527030642525};\\\", \\\"{x:1438,y:573,t:1527030642542};\\\", \\\"{x:1416,y:580,t:1527030642558};\\\", \\\"{x:1389,y:588,t:1527030642574};\\\", \\\"{x:1339,y:596,t:1527030642591};\\\", \\\"{x:1280,y:604,t:1527030642607};\\\", \\\"{x:1220,y:607,t:1527030642624};\\\", \\\"{x:1148,y:607,t:1527030642641};\\\", \\\"{x:1062,y:607,t:1527030642658};\\\", \\\"{x:973,y:607,t:1527030642674};\\\", \\\"{x:870,y:609,t:1527030642691};\\\", \\\"{x:748,y:618,t:1527030642707};\\\", \\\"{x:708,y:624,t:1527030642719};\\\", \\\"{x:647,y:631,t:1527030642735};\\\", \\\"{x:610,y:637,t:1527030642751};\\\", \\\"{x:583,y:637,t:1527030642768};\\\", \\\"{x:560,y:637,t:1527030642785};\\\", \\\"{x:543,y:637,t:1527030642801};\\\", \\\"{x:529,y:637,t:1527030642818};\\\", \\\"{x:521,y:635,t:1527030642834};\\\", \\\"{x:510,y:630,t:1527030642852};\\\", \\\"{x:503,y:626,t:1527030642867};\\\", \\\"{x:500,y:622,t:1527030642885};\\\", \\\"{x:497,y:617,t:1527030642902};\\\", \\\"{x:496,y:610,t:1527030642918};\\\", \\\"{x:496,y:602,t:1527030642935};\\\", \\\"{x:497,y:589,t:1527030642952};\\\", \\\"{x:506,y:569,t:1527030642969};\\\", \\\"{x:519,y:548,t:1527030642986};\\\", \\\"{x:533,y:529,t:1527030643002};\\\", \\\"{x:542,y:517,t:1527030643018};\\\", \\\"{x:546,y:509,t:1527030643035};\\\", \\\"{x:551,y:505,t:1527030643051};\\\", \\\"{x:554,y:502,t:1527030643068};\\\", \\\"{x:560,y:499,t:1527030643085};\\\", \\\"{x:570,y:496,t:1527030643102};\\\", \\\"{x:582,y:493,t:1527030643118};\\\", \\\"{x:591,y:492,t:1527030643135};\\\", \\\"{x:598,y:489,t:1527030643152};\\\", \\\"{x:601,y:489,t:1527030643168};\\\", \\\"{x:605,y:489,t:1527030643185};\\\", \\\"{x:607,y:489,t:1527030643202};\\\", \\\"{x:610,y:489,t:1527030643218};\\\", \\\"{x:611,y:489,t:1527030643235};\\\", \\\"{x:611,y:490,t:1527030643276};\\\", \\\"{x:611,y:492,t:1527030643285};\\\", \\\"{x:611,y:495,t:1527030643302};\\\", \\\"{x:611,y:498,t:1527030643318};\\\", \\\"{x:611,y:499,t:1527030643335};\\\", \\\"{x:612,y:501,t:1527030643836};\\\", \\\"{x:623,y:507,t:1527030643852};\\\", \\\"{x:634,y:512,t:1527030643869};\\\", \\\"{x:650,y:519,t:1527030643887};\\\", \\\"{x:671,y:528,t:1527030643903};\\\", \\\"{x:693,y:533,t:1527030643919};\\\", \\\"{x:710,y:540,t:1527030643936};\\\", \\\"{x:729,y:544,t:1527030643953};\\\", \\\"{x:751,y:550,t:1527030643969};\\\", \\\"{x:769,y:552,t:1527030643986};\\\", \\\"{x:780,y:553,t:1527030644002};\\\", \\\"{x:788,y:555,t:1527030644019};\\\", \\\"{x:793,y:555,t:1527030644036};\\\", \\\"{x:795,y:555,t:1527030644052};\\\", \\\"{x:796,y:555,t:1527030644069};\\\", \\\"{x:798,y:555,t:1527030644087};\\\", \\\"{x:799,y:554,t:1527030644102};\\\", \\\"{x:803,y:553,t:1527030644120};\\\", \\\"{x:805,y:552,t:1527030644137};\\\", \\\"{x:806,y:551,t:1527030644153};\\\", \\\"{x:807,y:551,t:1527030644196};\\\", \\\"{x:808,y:551,t:1527030644220};\\\", \\\"{x:810,y:549,t:1527030644236};\\\", \\\"{x:814,y:548,t:1527030644253};\\\", \\\"{x:816,y:547,t:1527030644269};\\\", \\\"{x:817,y:547,t:1527030644341};\\\", \\\"{x:817,y:546,t:1527030644356};\\\", \\\"{x:819,y:546,t:1527030644369};\\\", \\\"{x:821,y:545,t:1527030644404};\\\", \\\"{x:821,y:544,t:1527030644460};\\\", \\\"{x:822,y:544,t:1527030644572};\\\", \\\"{x:825,y:544,t:1527030644589};\\\", \\\"{x:829,y:544,t:1527030644603};\\\", \\\"{x:841,y:544,t:1527030644619};\\\", \\\"{x:845,y:544,t:1527030644636};\\\", \\\"{x:848,y:544,t:1527030644653};\\\", \\\"{x:851,y:544,t:1527030644670};\\\", \\\"{x:852,y:544,t:1527030644686};\\\", \\\"{x:854,y:544,t:1527030644764};\\\", \\\"{x:850,y:546,t:1527030645148};\\\", \\\"{x:845,y:548,t:1527030645155};\\\", \\\"{x:836,y:553,t:1527030645171};\\\", \\\"{x:820,y:563,t:1527030645188};\\\", \\\"{x:799,y:573,t:1527030645203};\\\", \\\"{x:753,y:593,t:1527030645220};\\\", \\\"{x:723,y:607,t:1527030645238};\\\", \\\"{x:700,y:619,t:1527030645253};\\\", \\\"{x:679,y:629,t:1527030645270};\\\", \\\"{x:660,y:637,t:1527030645287};\\\", \\\"{x:643,y:645,t:1527030645304};\\\", \\\"{x:630,y:652,t:1527030645320};\\\", \\\"{x:618,y:659,t:1527030645337};\\\", \\\"{x:605,y:667,t:1527030645353};\\\", \\\"{x:593,y:672,t:1527030645371};\\\", \\\"{x:582,y:678,t:1527030645387};\\\", \\\"{x:565,y:685,t:1527030645403};\\\", \\\"{x:557,y:689,t:1527030645420};\\\", \\\"{x:554,y:690,t:1527030645437};\\\", \\\"{x:551,y:690,t:1527030645454};\\\", \\\"{x:548,y:691,t:1527030645470};\\\", \\\"{x:544,y:694,t:1527030645488};\\\", \\\"{x:541,y:695,t:1527030645504};\\\", \\\"{x:535,y:699,t:1527030645520};\\\", \\\"{x:531,y:703,t:1527030645538};\\\", \\\"{x:527,y:707,t:1527030645554};\\\", \\\"{x:524,y:711,t:1527030645571};\\\", \\\"{x:521,y:715,t:1527030645587};\\\", \\\"{x:516,y:724,t:1527030645605};\\\", \\\"{x:513,y:729,t:1527030645620};\\\", \\\"{x:512,y:731,t:1527030645637};\\\", \\\"{x:512,y:734,t:1527030645654};\\\", \\\"{x:511,y:735,t:1527030645670};\\\", \\\"{x:511,y:736,t:1527030645692};\\\" ] }, { \\\"rt\\\": 25216, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 11, \\\"time_elapsed\\\": 430027, \\\"internal_node_id\\\": \\\"0.0-6.0-1.0\\\", \\\"subject\\\": \\\"E5L6P\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+starts\\\", \\\"q\\\": 7, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:510,y:734,t:1527030652556};\\\", \\\"{x:506,y:714,t:1527030652567};\\\", \\\"{x:493,y:669,t:1527030652582};\\\", \\\"{x:478,y:636,t:1527030652599};\\\", \\\"{x:473,y:622,t:1527030652610};\\\", \\\"{x:462,y:597,t:1527030652627};\\\", \\\"{x:452,y:574,t:1527030652643};\\\", \\\"{x:434,y:538,t:1527030652660};\\\", \\\"{x:428,y:518,t:1527030652676};\\\", \\\"{x:421,y:500,t:1527030652693};\\\", \\\"{x:416,y:486,t:1527030652710};\\\", \\\"{x:413,y:477,t:1527030652726};\\\", \\\"{x:412,y:471,t:1527030652743};\\\", \\\"{x:412,y:467,t:1527030652760};\\\", \\\"{x:412,y:463,t:1527030652776};\\\", \\\"{x:412,y:461,t:1527030652793};\\\", \\\"{x:410,y:460,t:1527030652809};\\\", \\\"{x:410,y:459,t:1527030652843};\\\", \\\"{x:409,y:457,t:1527030653044};\\\", \\\"{x:402,y:454,t:1527030653060};\\\", \\\"{x:395,y:451,t:1527030653076};\\\", \\\"{x:387,y:449,t:1527030653093};\\\", \\\"{x:380,y:446,t:1527030653110};\\\", \\\"{x:374,y:446,t:1527030653127};\\\", \\\"{x:370,y:445,t:1527030653143};\\\", \\\"{x:369,y:445,t:1527030653293};\\\", \\\"{x:368,y:445,t:1527030653310};\\\", \\\"{x:366,y:446,t:1527030653327};\\\", \\\"{x:365,y:447,t:1527030653343};\\\", \\\"{x:365,y:450,t:1527030653361};\\\", \\\"{x:364,y:451,t:1527030653380};\\\", \\\"{x:364,y:452,t:1527030653396};\\\", \\\"{x:364,y:453,t:1527030653410};\\\", \\\"{x:364,y:454,t:1527030653436};\\\", \\\"{x:364,y:456,t:1527030653444};\\\", \\\"{x:364,y:458,t:1527030653460};\\\", \\\"{x:364,y:459,t:1527030653476};\\\", \\\"{x:364,y:461,t:1527030653493};\\\", \\\"{x:364,y:462,t:1527030653509};\\\", \\\"{x:364,y:464,t:1527030653527};\\\", \\\"{x:364,y:465,t:1527030653548};\\\", \\\"{x:364,y:466,t:1527030653572};\\\", \\\"{x:366,y:466,t:1527030653684};\\\", \\\"{x:367,y:466,t:1527030653693};\\\", \\\"{x:370,y:466,t:1527030653710};\\\", \\\"{x:375,y:464,t:1527030653727};\\\", \\\"{x:381,y:461,t:1527030653743};\\\", \\\"{x:383,y:460,t:1527030653761};\\\", \\\"{x:385,y:459,t:1527030653777};\\\", \\\"{x:387,y:457,t:1527030653793};\\\", \\\"{x:388,y:456,t:1527030653810};\\\", \\\"{x:389,y:455,t:1527030653827};\\\", \\\"{x:390,y:455,t:1527030653843};\\\", \\\"{x:391,y:454,t:1527030653860};\\\", \\\"{x:392,y:453,t:1527030653875};\\\", \\\"{x:394,y:451,t:1527030653893};\\\", \\\"{x:395,y:450,t:1527030653910};\\\", \\\"{x:396,y:450,t:1527030653926};\\\", \\\"{x:397,y:449,t:1527030653943};\\\", \\\"{x:398,y:448,t:1527030653964};\\\", \\\"{x:400,y:447,t:1527030654012};\\\", \\\"{x:401,y:447,t:1527030654043};\\\", \\\"{x:403,y:447,t:1527030654116};\\\", \\\"{x:404,y:446,t:1527030654140};\\\", \\\"{x:406,y:446,t:1527030654156};\\\", \\\"{x:407,y:446,t:1527030654172};\\\", \\\"{x:410,y:446,t:1527030654188};\\\", \\\"{x:411,y:446,t:1527030654203};\\\", \\\"{x:413,y:446,t:1527030654212};\\\", \\\"{x:414,y:446,t:1527030654228};\\\", \\\"{x:415,y:446,t:1527030654243};\\\", \\\"{x:418,y:446,t:1527030654260};\\\", \\\"{x:419,y:446,t:1527030654276};\\\", \\\"{x:420,y:446,t:1527030654292};\\\", \\\"{x:423,y:446,t:1527030654310};\\\", \\\"{x:425,y:447,t:1527030654326};\\\", \\\"{x:426,y:447,t:1527030654343};\\\", \\\"{x:428,y:447,t:1527030654361};\\\", \\\"{x:430,y:448,t:1527030654376};\\\", \\\"{x:433,y:448,t:1527030654393};\\\", \\\"{x:436,y:449,t:1527030654410};\\\", \\\"{x:440,y:451,t:1527030654426};\\\", \\\"{x:442,y:451,t:1527030654443};\\\", \\\"{x:443,y:452,t:1527030654460};\\\", \\\"{x:445,y:452,t:1527030654476};\\\", \\\"{x:446,y:453,t:1527030654493};\\\", \\\"{x:448,y:453,t:1527030654510};\\\", \\\"{x:450,y:454,t:1527030654526};\\\", \\\"{x:452,y:455,t:1527030654543};\\\", \\\"{x:455,y:455,t:1527030654561};\\\", \\\"{x:458,y:455,t:1527030654576};\\\", \\\"{x:461,y:456,t:1527030654592};\\\", \\\"{x:466,y:458,t:1527030654610};\\\", \\\"{x:469,y:459,t:1527030654626};\\\", \\\"{x:473,y:460,t:1527030654642};\\\", \\\"{x:479,y:461,t:1527030654659};\\\", \\\"{x:481,y:461,t:1527030654675};\\\", \\\"{x:485,y:462,t:1527030654692};\\\", \\\"{x:489,y:463,t:1527030654710};\\\", \\\"{x:491,y:463,t:1527030654725};\\\", \\\"{x:493,y:463,t:1527030654742};\\\", \\\"{x:495,y:463,t:1527030654761};\\\", \\\"{x:497,y:464,t:1527030654776};\\\", \\\"{x:499,y:464,t:1527030654793};\\\", \\\"{x:500,y:464,t:1527030654809};\\\", \\\"{x:504,y:465,t:1527030654826};\\\", \\\"{x:506,y:465,t:1527030654843};\\\", \\\"{x:511,y:465,t:1527030654859};\\\", \\\"{x:514,y:465,t:1527030654876};\\\", \\\"{x:517,y:465,t:1527030654892};\\\", \\\"{x:519,y:465,t:1527030654908};\\\", \\\"{x:521,y:465,t:1527030654926};\\\", \\\"{x:523,y:465,t:1527030654943};\\\", \\\"{x:525,y:465,t:1527030654961};\\\", \\\"{x:527,y:465,t:1527030654976};\\\", \\\"{x:529,y:465,t:1527030654993};\\\", \\\"{x:532,y:465,t:1527030655010};\\\", \\\"{x:533,y:464,t:1527030655025};\\\", \\\"{x:535,y:464,t:1527030655043};\\\", \\\"{x:539,y:464,t:1527030655060};\\\", \\\"{x:540,y:463,t:1527030655076};\\\", \\\"{x:543,y:462,t:1527030655092};\\\", \\\"{x:546,y:462,t:1527030655110};\\\", \\\"{x:550,y:462,t:1527030655126};\\\", \\\"{x:553,y:461,t:1527030655143};\\\", \\\"{x:555,y:461,t:1527030655162};\\\", \\\"{x:557,y:460,t:1527030655176};\\\", \\\"{x:559,y:460,t:1527030655195};\\\", \\\"{x:560,y:459,t:1527030655209};\\\", \\\"{x:561,y:458,t:1527030655228};\\\", \\\"{x:562,y:458,t:1527030655243};\\\", \\\"{x:563,y:458,t:1527030655268};\\\", \\\"{x:564,y:458,t:1527030655284};\\\", \\\"{x:566,y:457,t:1527030655300};\\\", \\\"{x:566,y:456,t:1527030655316};\\\", \\\"{x:568,y:456,t:1527030655340};\\\", \\\"{x:569,y:456,t:1527030655347};\\\", \\\"{x:570,y:456,t:1527030655364};\\\", \\\"{x:571,y:456,t:1527030655376};\\\", \\\"{x:573,y:456,t:1527030655393};\\\", \\\"{x:576,y:455,t:1527030655409};\\\", \\\"{x:581,y:455,t:1527030655426};\\\", \\\"{x:585,y:455,t:1527030655443};\\\", \\\"{x:587,y:455,t:1527030655460};\\\", \\\"{x:590,y:455,t:1527030655476};\\\", \\\"{x:594,y:455,t:1527030655492};\\\", \\\"{x:597,y:455,t:1527030655509};\\\", \\\"{x:603,y:455,t:1527030655526};\\\", \\\"{x:607,y:457,t:1527030655543};\\\", \\\"{x:613,y:458,t:1527030655559};\\\", \\\"{x:621,y:459,t:1527030655576};\\\", \\\"{x:630,y:461,t:1527030655592};\\\", \\\"{x:638,y:462,t:1527030655609};\\\", \\\"{x:648,y:465,t:1527030655625};\\\", \\\"{x:658,y:466,t:1527030655643};\\\", \\\"{x:669,y:470,t:1527030655659};\\\", \\\"{x:695,y:475,t:1527030655676};\\\", \\\"{x:714,y:479,t:1527030655693};\\\", \\\"{x:734,y:483,t:1527030655709};\\\", \\\"{x:755,y:491,t:1527030655727};\\\", \\\"{x:774,y:494,t:1527030655742};\\\", \\\"{x:793,y:499,t:1527030655759};\\\", \\\"{x:813,y:507,t:1527030655778};\\\", \\\"{x:836,y:514,t:1527030655795};\\\", \\\"{x:864,y:520,t:1527030655812};\\\", \\\"{x:883,y:526,t:1527030655828};\\\", \\\"{x:901,y:531,t:1527030655846};\\\", \\\"{x:922,y:538,t:1527030655862};\\\", \\\"{x:952,y:549,t:1527030655879};\\\", \\\"{x:976,y:559,t:1527030655895};\\\", \\\"{x:1001,y:567,t:1527030655911};\\\", \\\"{x:1025,y:573,t:1527030655928};\\\", \\\"{x:1051,y:578,t:1527030655945};\\\", \\\"{x:1076,y:587,t:1527030655961};\\\", \\\"{x:1102,y:594,t:1527030655978};\\\", \\\"{x:1136,y:604,t:1527030655996};\\\", \\\"{x:1154,y:608,t:1527030656011};\\\", \\\"{x:1166,y:611,t:1527030656029};\\\", \\\"{x:1175,y:614,t:1527030656045};\\\", \\\"{x:1183,y:616,t:1527030656062};\\\", \\\"{x:1187,y:616,t:1527030656078};\\\", \\\"{x:1188,y:616,t:1527030656096};\\\", \\\"{x:1190,y:617,t:1527030656112};\\\", \\\"{x:1193,y:617,t:1527030656148};\\\", \\\"{x:1195,y:617,t:1527030656162};\\\", \\\"{x:1202,y:618,t:1527030656179};\\\", \\\"{x:1209,y:619,t:1527030656195};\\\", \\\"{x:1226,y:623,t:1527030656212};\\\", \\\"{x:1239,y:627,t:1527030656229};\\\", \\\"{x:1259,y:632,t:1527030656245};\\\", \\\"{x:1281,y:634,t:1527030656262};\\\", \\\"{x:1303,y:640,t:1527030656279};\\\", \\\"{x:1322,y:643,t:1527030656296};\\\", \\\"{x:1340,y:645,t:1527030656312};\\\", \\\"{x:1350,y:646,t:1527030656329};\\\", \\\"{x:1358,y:648,t:1527030656345};\\\", \\\"{x:1363,y:648,t:1527030656362};\\\", \\\"{x:1366,y:649,t:1527030656379};\\\", \\\"{x:1369,y:649,t:1527030656396};\\\", \\\"{x:1373,y:649,t:1527030656412};\\\", \\\"{x:1376,y:649,t:1527030656429};\\\", \\\"{x:1378,y:650,t:1527030656445};\\\", \\\"{x:1379,y:650,t:1527030656463};\\\", \\\"{x:1380,y:650,t:1527030656479};\\\", \\\"{x:1383,y:651,t:1527030656495};\\\", \\\"{x:1384,y:651,t:1527030656513};\\\", \\\"{x:1386,y:651,t:1527030656529};\\\", \\\"{x:1390,y:651,t:1527030656546};\\\", \\\"{x:1392,y:651,t:1527030656562};\\\", \\\"{x:1394,y:651,t:1527030656579};\\\", \\\"{x:1395,y:651,t:1527030656596};\\\", \\\"{x:1393,y:651,t:1527030656676};\\\", \\\"{x:1391,y:651,t:1527030656684};\\\", \\\"{x:1389,y:651,t:1527030656695};\\\", \\\"{x:1385,y:651,t:1527030656712};\\\", \\\"{x:1381,y:650,t:1527030656728};\\\", \\\"{x:1375,y:650,t:1527030656745};\\\", \\\"{x:1367,y:650,t:1527030656761};\\\", \\\"{x:1358,y:648,t:1527030656778};\\\", \\\"{x:1354,y:648,t:1527030656795};\\\", \\\"{x:1349,y:648,t:1527030656811};\\\", \\\"{x:1347,y:647,t:1527030656828};\\\", \\\"{x:1344,y:647,t:1527030656846};\\\", \\\"{x:1343,y:646,t:1527030657013};\\\", \\\"{x:1346,y:640,t:1527030657028};\\\", \\\"{x:1351,y:632,t:1527030657044};\\\", \\\"{x:1356,y:625,t:1527030657062};\\\", \\\"{x:1358,y:620,t:1527030657079};\\\", \\\"{x:1360,y:617,t:1527030657095};\\\", \\\"{x:1362,y:615,t:1527030657111};\\\", \\\"{x:1362,y:614,t:1527030657140};\\\", \\\"{x:1363,y:614,t:1527030657268};\\\", \\\"{x:1363,y:617,t:1527030657278};\\\", \\\"{x:1362,y:622,t:1527030657295};\\\", \\\"{x:1359,y:627,t:1527030657311};\\\", \\\"{x:1358,y:632,t:1527030657327};\\\", \\\"{x:1356,y:636,t:1527030657344};\\\", \\\"{x:1356,y:637,t:1527030657361};\\\", \\\"{x:1355,y:637,t:1527030657377};\\\", \\\"{x:1355,y:638,t:1527030657395};\\\", \\\"{x:1354,y:638,t:1527030657436};\\\", \\\"{x:1353,y:640,t:1527030657916};\\\", \\\"{x:1353,y:641,t:1527030657932};\\\", \\\"{x:1353,y:643,t:1527030657972};\\\", \\\"{x:1353,y:644,t:1527030658005};\\\", \\\"{x:1353,y:645,t:1527030658483};\\\", \\\"{x:1354,y:646,t:1527030658492};\\\", \\\"{x:1354,y:647,t:1527030658516};\\\", \\\"{x:1355,y:648,t:1527030658531};\\\", \\\"{x:1355,y:649,t:1527030658548};\\\", \\\"{x:1356,y:650,t:1527030658559};\\\", \\\"{x:1357,y:652,t:1527030658576};\\\", \\\"{x:1357,y:654,t:1527030658592};\\\", \\\"{x:1357,y:656,t:1527030658609};\\\", \\\"{x:1359,y:658,t:1527030658626};\\\", \\\"{x:1359,y:660,t:1527030658642};\\\", \\\"{x:1359,y:662,t:1527030658659};\\\", \\\"{x:1360,y:665,t:1527030658676};\\\", \\\"{x:1360,y:668,t:1527030658692};\\\", \\\"{x:1360,y:669,t:1527030658709};\\\", \\\"{x:1360,y:672,t:1527030658726};\\\", \\\"{x:1360,y:673,t:1527030658743};\\\", \\\"{x:1360,y:675,t:1527030658759};\\\", \\\"{x:1360,y:676,t:1527030658776};\\\", \\\"{x:1360,y:677,t:1527030658792};\\\", \\\"{x:1360,y:678,t:1527030658809};\\\", \\\"{x:1360,y:679,t:1527030658825};\\\", \\\"{x:1360,y:680,t:1527030658842};\\\", \\\"{x:1360,y:682,t:1527030658860};\\\", \\\"{x:1360,y:683,t:1527030658875};\\\", \\\"{x:1360,y:684,t:1527030658892};\\\", \\\"{x:1360,y:685,t:1527030658909};\\\", \\\"{x:1360,y:687,t:1527030658925};\\\", \\\"{x:1359,y:688,t:1527030658943};\\\", \\\"{x:1359,y:689,t:1527030658972};\\\", \\\"{x:1359,y:690,t:1527030658980};\\\", \\\"{x:1359,y:691,t:1527030658992};\\\", \\\"{x:1359,y:692,t:1527030659020};\\\", \\\"{x:1358,y:693,t:1527030659028};\\\", \\\"{x:1357,y:694,t:1527030659052};\\\", \\\"{x:1356,y:697,t:1527030659076};\\\", \\\"{x:1355,y:698,t:1527030659125};\\\", \\\"{x:1353,y:699,t:1527030659687};\\\", \\\"{x:1352,y:700,t:1527030659708};\\\", \\\"{x:1351,y:700,t:1527030659796};\\\", \\\"{x:1350,y:701,t:1527030659932};\\\", \\\"{x:1349,y:705,t:1527030668536};\\\", \\\"{x:1349,y:708,t:1527030668551};\\\", \\\"{x:1341,y:723,t:1527030668568};\\\", \\\"{x:1329,y:735,t:1527030668583};\\\", \\\"{x:1320,y:743,t:1527030668600};\\\", \\\"{x:1309,y:750,t:1527030668617};\\\", \\\"{x:1301,y:757,t:1527030668634};\\\", \\\"{x:1295,y:762,t:1527030668650};\\\", \\\"{x:1289,y:765,t:1527030668667};\\\", \\\"{x:1283,y:769,t:1527030668684};\\\", \\\"{x:1274,y:779,t:1527030668700};\\\", \\\"{x:1266,y:785,t:1527030668717};\\\", \\\"{x:1256,y:790,t:1527030668733};\\\", \\\"{x:1243,y:796,t:1527030668750};\\\", \\\"{x:1218,y:806,t:1527030668767};\\\", \\\"{x:1203,y:812,t:1527030668783};\\\", \\\"{x:1192,y:815,t:1527030668801};\\\", \\\"{x:1179,y:819,t:1527030668817};\\\", \\\"{x:1169,y:820,t:1527030668834};\\\", \\\"{x:1159,y:823,t:1527030668850};\\\", \\\"{x:1147,y:826,t:1527030668867};\\\", \\\"{x:1131,y:831,t:1527030668883};\\\", \\\"{x:1112,y:837,t:1527030668900};\\\", \\\"{x:1091,y:843,t:1527030668916};\\\", \\\"{x:1067,y:846,t:1527030668933};\\\", \\\"{x:1042,y:848,t:1527030668950};\\\", \\\"{x:1018,y:848,t:1527030668967};\\\", \\\"{x:980,y:845,t:1527030668983};\\\", \\\"{x:958,y:833,t:1527030668999};\\\", \\\"{x:935,y:815,t:1527030669016};\\\", \\\"{x:910,y:791,t:1527030669033};\\\", \\\"{x:882,y:756,t:1527030669051};\\\", \\\"{x:859,y:720,t:1527030669066};\\\", \\\"{x:840,y:694,t:1527030669083};\\\", \\\"{x:827,y:675,t:1527030669101};\\\", \\\"{x:812,y:657,t:1527030669116};\\\", \\\"{x:798,y:639,t:1527030669133};\\\", \\\"{x:786,y:624,t:1527030669151};\\\", \\\"{x:778,y:611,t:1527030669165};\\\", \\\"{x:773,y:604,t:1527030669182};\\\", \\\"{x:771,y:603,t:1527030669191};\\\", \\\"{x:771,y:602,t:1527030669214};\\\", \\\"{x:767,y:604,t:1527030669279};\\\", \\\"{x:760,y:613,t:1527030669291};\\\", \\\"{x:747,y:632,t:1527030669310};\\\", \\\"{x:731,y:648,t:1527030669326};\\\", \\\"{x:706,y:664,t:1527030669344};\\\", \\\"{x:693,y:671,t:1527030669360};\\\", \\\"{x:681,y:675,t:1527030669377};\\\", \\\"{x:672,y:678,t:1527030669394};\\\", \\\"{x:663,y:679,t:1527030669410};\\\", \\\"{x:653,y:680,t:1527030669427};\\\", \\\"{x:639,y:680,t:1527030669444};\\\", \\\"{x:625,y:677,t:1527030669460};\\\", \\\"{x:609,y:671,t:1527030669477};\\\", \\\"{x:593,y:663,t:1527030669494};\\\", \\\"{x:575,y:653,t:1527030669509};\\\", \\\"{x:542,y:629,t:1527030669527};\\\", \\\"{x:523,y:616,t:1527030669544};\\\", \\\"{x:509,y:605,t:1527030669560};\\\", \\\"{x:503,y:598,t:1527030669577};\\\", \\\"{x:498,y:590,t:1527030669594};\\\", \\\"{x:493,y:578,t:1527030669609};\\\", \\\"{x:491,y:569,t:1527030669626};\\\", \\\"{x:491,y:564,t:1527030669644};\\\", \\\"{x:489,y:561,t:1527030669660};\\\", \\\"{x:489,y:559,t:1527030669676};\\\", \\\"{x:489,y:558,t:1527030669695};\\\", \\\"{x:489,y:557,t:1527030669727};\\\", \\\"{x:489,y:556,t:1527030669744};\\\", \\\"{x:490,y:556,t:1527030669767};\\\", \\\"{x:491,y:555,t:1527030669778};\\\", \\\"{x:492,y:555,t:1527030669793};\\\", \\\"{x:495,y:555,t:1527030669810};\\\", \\\"{x:499,y:555,t:1527030669827};\\\", \\\"{x:508,y:555,t:1527030669844};\\\", \\\"{x:518,y:553,t:1527030669860};\\\", \\\"{x:528,y:551,t:1527030669877};\\\", \\\"{x:538,y:550,t:1527030669893};\\\", \\\"{x:558,y:545,t:1527030669910};\\\", \\\"{x:575,y:540,t:1527030669927};\\\", \\\"{x:591,y:535,t:1527030669943};\\\", \\\"{x:608,y:531,t:1527030669961};\\\", \\\"{x:628,y:526,t:1527030669977};\\\", \\\"{x:646,y:523,t:1527030669994};\\\", \\\"{x:660,y:518,t:1527030670010};\\\", \\\"{x:676,y:514,t:1527030670027};\\\", \\\"{x:687,y:512,t:1527030670044};\\\", \\\"{x:700,y:509,t:1527030670060};\\\", \\\"{x:716,y:505,t:1527030670078};\\\", \\\"{x:729,y:502,t:1527030670094};\\\", \\\"{x:750,y:495,t:1527030670110};\\\", \\\"{x:762,y:493,t:1527030670127};\\\", \\\"{x:774,y:490,t:1527030670143};\\\", \\\"{x:785,y:488,t:1527030670161};\\\", \\\"{x:792,y:487,t:1527030670177};\\\", \\\"{x:797,y:486,t:1527030670194};\\\", \\\"{x:801,y:485,t:1527030670211};\\\", \\\"{x:804,y:485,t:1527030670228};\\\", \\\"{x:808,y:485,t:1527030670243};\\\", \\\"{x:814,y:485,t:1527030670261};\\\", \\\"{x:815,y:485,t:1527030670277};\\\", \\\"{x:817,y:485,t:1527030670294};\\\", \\\"{x:817,y:486,t:1527030670343};\\\", \\\"{x:817,y:490,t:1527030670351};\\\", \\\"{x:817,y:493,t:1527030670361};\\\", \\\"{x:817,y:500,t:1527030670378};\\\", \\\"{x:817,y:505,t:1527030670393};\\\", \\\"{x:817,y:509,t:1527030670410};\\\", \\\"{x:817,y:511,t:1527030670428};\\\", \\\"{x:817,y:512,t:1527030670470};\\\", \\\"{x:817,y:513,t:1527030670478};\\\", \\\"{x:822,y:514,t:1527030670494};\\\", \\\"{x:833,y:516,t:1527030670510};\\\", \\\"{x:843,y:517,t:1527030670528};\\\", \\\"{x:848,y:517,t:1527030670543};\\\", \\\"{x:851,y:517,t:1527030670560};\\\", \\\"{x:853,y:517,t:1527030670577};\\\", \\\"{x:856,y:517,t:1527030670595};\\\", \\\"{x:858,y:517,t:1527030670611};\\\", \\\"{x:859,y:516,t:1527030670628};\\\", \\\"{x:860,y:516,t:1527030670645};\\\", \\\"{x:861,y:515,t:1527030670660};\\\", \\\"{x:861,y:514,t:1527030670790};\\\", \\\"{x:860,y:513,t:1527030670806};\\\", \\\"{x:859,y:513,t:1527030670814};\\\", \\\"{x:857,y:513,t:1527030670828};\\\", \\\"{x:856,y:512,t:1527030670845};\\\", \\\"{x:853,y:511,t:1527030670860};\\\", \\\"{x:850,y:510,t:1527030670877};\\\", \\\"{x:846,y:508,t:1527030670894};\\\", \\\"{x:843,y:508,t:1527030670910};\\\", \\\"{x:841,y:506,t:1527030670927};\\\", \\\"{x:840,y:506,t:1527030670945};\\\", \\\"{x:839,y:506,t:1527030671311};\\\", \\\"{x:833,y:506,t:1527030671318};\\\", \\\"{x:825,y:509,t:1527030671329};\\\", \\\"{x:807,y:522,t:1527030671346};\\\", \\\"{x:775,y:541,t:1527030671363};\\\", \\\"{x:742,y:560,t:1527030671379};\\\", \\\"{x:708,y:576,t:1527030671395};\\\", \\\"{x:682,y:586,t:1527030671412};\\\", \\\"{x:660,y:594,t:1527030671430};\\\", \\\"{x:643,y:596,t:1527030671445};\\\", \\\"{x:629,y:597,t:1527030671461};\\\", \\\"{x:618,y:597,t:1527030671478};\\\", \\\"{x:601,y:597,t:1527030671494};\\\", \\\"{x:587,y:597,t:1527030671512};\\\", \\\"{x:575,y:597,t:1527030671528};\\\", \\\"{x:560,y:597,t:1527030671544};\\\", \\\"{x:547,y:597,t:1527030671562};\\\", \\\"{x:528,y:597,t:1527030671578};\\\", \\\"{x:509,y:597,t:1527030671594};\\\", \\\"{x:489,y:597,t:1527030671611};\\\", \\\"{x:467,y:597,t:1527030671628};\\\", \\\"{x:448,y:597,t:1527030671645};\\\", \\\"{x:428,y:594,t:1527030671661};\\\", \\\"{x:412,y:591,t:1527030671680};\\\", \\\"{x:398,y:590,t:1527030671695};\\\", \\\"{x:390,y:589,t:1527030671712};\\\", \\\"{x:385,y:589,t:1527030671729};\\\", \\\"{x:383,y:589,t:1527030671745};\\\", \\\"{x:381,y:589,t:1527030671895};\\\", \\\"{x:378,y:584,t:1527030671912};\\\", \\\"{x:373,y:579,t:1527030671930};\\\", \\\"{x:365,y:576,t:1527030671946};\\\", \\\"{x:352,y:573,t:1527030671962};\\\", \\\"{x:337,y:573,t:1527030671979};\\\", \\\"{x:314,y:573,t:1527030671996};\\\", \\\"{x:289,y:573,t:1527030672012};\\\", \\\"{x:263,y:573,t:1527030672030};\\\", \\\"{x:239,y:573,t:1527030672045};\\\", \\\"{x:219,y:575,t:1527030672062};\\\", \\\"{x:204,y:578,t:1527030672079};\\\", \\\"{x:201,y:578,t:1527030672096};\\\", \\\"{x:198,y:578,t:1527030672112};\\\", \\\"{x:195,y:578,t:1527030672176};\\\", \\\"{x:194,y:578,t:1527030672184};\\\", \\\"{x:192,y:578,t:1527030672197};\\\", \\\"{x:186,y:578,t:1527030672212};\\\", \\\"{x:178,y:578,t:1527030672229};\\\", \\\"{x:168,y:572,t:1527030672247};\\\", \\\"{x:161,y:566,t:1527030672264};\\\", \\\"{x:156,y:561,t:1527030672281};\\\", \\\"{x:153,y:558,t:1527030672296};\\\", \\\"{x:152,y:556,t:1527030672313};\\\", \\\"{x:152,y:553,t:1527030672329};\\\", \\\"{x:151,y:553,t:1527030672346};\\\", \\\"{x:151,y:552,t:1527030672363};\\\", \\\"{x:151,y:551,t:1527030672379};\\\", \\\"{x:151,y:550,t:1527030672395};\\\", \\\"{x:151,y:547,t:1527030672413};\\\", \\\"{x:150,y:545,t:1527030672429};\\\", \\\"{x:150,y:541,t:1527030672446};\\\", \\\"{x:149,y:540,t:1527030672462};\\\", \\\"{x:149,y:539,t:1527030672479};\\\", \\\"{x:149,y:538,t:1527030672568};\\\", \\\"{x:150,y:538,t:1527030672823};\\\", \\\"{x:157,y:548,t:1527030672830};\\\", \\\"{x:167,y:560,t:1527030672846};\\\", \\\"{x:196,y:588,t:1527030672863};\\\", \\\"{x:220,y:605,t:1527030672881};\\\", \\\"{x:255,y:626,t:1527030672896};\\\", \\\"{x:285,y:638,t:1527030672913};\\\", \\\"{x:309,y:650,t:1527030672930};\\\", \\\"{x:329,y:658,t:1527030672946};\\\", \\\"{x:345,y:663,t:1527030672964};\\\", \\\"{x:358,y:667,t:1527030672979};\\\", \\\"{x:368,y:672,t:1527030672997};\\\", \\\"{x:378,y:677,t:1527030673013};\\\", \\\"{x:380,y:677,t:1527030673030};\\\", \\\"{x:381,y:678,t:1527030673047};\\\", \\\"{x:382,y:679,t:1527030673120};\\\", \\\"{x:386,y:679,t:1527030673130};\\\", \\\"{x:397,y:683,t:1527030673146};\\\", \\\"{x:419,y:702,t:1527030673164};\\\", \\\"{x:447,y:720,t:1527030673180};\\\", \\\"{x:466,y:732,t:1527030673198};\\\", \\\"{x:478,y:739,t:1527030673213};\\\", \\\"{x:488,y:747,t:1527030673230};\\\", \\\"{x:507,y:758,t:1527030673248};\\\", \\\"{x:514,y:764,t:1527030673263};\\\", \\\"{x:517,y:765,t:1527030673280};\\\", \\\"{x:518,y:765,t:1527030673408};\\\", \\\"{x:520,y:765,t:1527030673415};\\\", \\\"{x:521,y:763,t:1527030673430};\\\", \\\"{x:527,y:751,t:1527030673449};\\\", \\\"{x:531,y:745,t:1527030673464};\\\", \\\"{x:533,y:742,t:1527030673480};\\\", \\\"{x:533,y:741,t:1527030673497};\\\", \\\"{x:534,y:740,t:1527030673534};\\\" ] }, { \\\"rt\\\": 38320, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 12, \\\"time_elapsed\\\": 469593, \\\"internal_node_id\\\": \\\"0.0-6.0-2.0\\\", \\\"subject\\\": \\\"E5L6P\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+contained\\\", \\\"q\\\": 8, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-E \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:534,y:733,t:1527030675614};\\\", \\\"{x:529,y:717,t:1527030675630};\\\", \\\"{x:514,y:684,t:1527030675646};\\\", \\\"{x:484,y:635,t:1527030675665};\\\", \\\"{x:459,y:598,t:1527030675682};\\\", \\\"{x:431,y:561,t:1527030675699};\\\", \\\"{x:407,y:529,t:1527030675715};\\\", \\\"{x:390,y:509,t:1527030675732};\\\", \\\"{x:381,y:494,t:1527030675749};\\\", \\\"{x:375,y:485,t:1527030675765};\\\", \\\"{x:372,y:482,t:1527030675782};\\\", \\\"{x:371,y:481,t:1527030675799};\\\", \\\"{x:371,y:480,t:1527030675815};\\\", \\\"{x:369,y:480,t:1527030675904};\\\", \\\"{x:366,y:479,t:1527030675919};\\\", \\\"{x:359,y:476,t:1527030675932};\\\", \\\"{x:346,y:472,t:1527030675950};\\\", \\\"{x:331,y:469,t:1527030675967};\\\", \\\"{x:310,y:461,t:1527030675983};\\\", \\\"{x:294,y:453,t:1527030675999};\\\", \\\"{x:279,y:448,t:1527030676017};\\\", \\\"{x:267,y:443,t:1527030676034};\\\", \\\"{x:257,y:439,t:1527030676051};\\\", \\\"{x:251,y:438,t:1527030676066};\\\", \\\"{x:247,y:436,t:1527030676084};\\\", \\\"{x:246,y:436,t:1527030676100};\\\", \\\"{x:244,y:436,t:1527030676160};\\\", \\\"{x:243,y:436,t:1527030676176};\\\", \\\"{x:242,y:437,t:1527030676184};\\\", \\\"{x:241,y:438,t:1527030676200};\\\", \\\"{x:241,y:440,t:1527030676392};\\\", \\\"{x:241,y:441,t:1527030676401};\\\", \\\"{x:241,y:443,t:1527030676418};\\\", \\\"{x:244,y:446,t:1527030676435};\\\", \\\"{x:248,y:449,t:1527030676451};\\\", \\\"{x:252,y:451,t:1527030676468};\\\", \\\"{x:259,y:454,t:1527030676485};\\\", \\\"{x:264,y:455,t:1527030676502};\\\", \\\"{x:268,y:457,t:1527030676519};\\\", \\\"{x:274,y:458,t:1527030676535};\\\", \\\"{x:279,y:459,t:1527030676551};\\\", \\\"{x:283,y:459,t:1527030676568};\\\", \\\"{x:286,y:459,t:1527030676586};\\\", \\\"{x:289,y:459,t:1527030676602};\\\", \\\"{x:292,y:459,t:1527030676618};\\\", \\\"{x:294,y:459,t:1527030676636};\\\", \\\"{x:295,y:459,t:1527030676653};\\\", \\\"{x:298,y:459,t:1527030676668};\\\", \\\"{x:300,y:459,t:1527030676688};\\\", \\\"{x:302,y:459,t:1527030676702};\\\", \\\"{x:304,y:459,t:1527030676719};\\\", \\\"{x:307,y:459,t:1527030676736};\\\", \\\"{x:309,y:459,t:1527030676752};\\\", \\\"{x:310,y:459,t:1527030676770};\\\", \\\"{x:312,y:458,t:1527030676785};\\\", \\\"{x:314,y:457,t:1527030676802};\\\", \\\"{x:316,y:457,t:1527030676824};\\\", \\\"{x:317,y:456,t:1527030676836};\\\", \\\"{x:319,y:455,t:1527030676852};\\\", \\\"{x:320,y:454,t:1527030676869};\\\", \\\"{x:323,y:453,t:1527030676886};\\\", \\\"{x:324,y:453,t:1527030676902};\\\", \\\"{x:328,y:451,t:1527030676919};\\\", \\\"{x:332,y:451,t:1527030676937};\\\", \\\"{x:336,y:450,t:1527030676954};\\\", \\\"{x:342,y:449,t:1527030676969};\\\", \\\"{x:347,y:448,t:1527030676986};\\\", \\\"{x:350,y:447,t:1527030677004};\\\", \\\"{x:354,y:447,t:1527030677019};\\\", \\\"{x:358,y:446,t:1527030677036};\\\", \\\"{x:361,y:446,t:1527030677054};\\\", \\\"{x:364,y:446,t:1527030677071};\\\", \\\"{x:368,y:446,t:1527030677087};\\\", \\\"{x:371,y:446,t:1527030677104};\\\", \\\"{x:375,y:446,t:1527030677121};\\\", \\\"{x:376,y:446,t:1527030677137};\\\", \\\"{x:380,y:446,t:1527030677153};\\\", \\\"{x:382,y:446,t:1527030677170};\\\", \\\"{x:385,y:446,t:1527030677187};\\\", \\\"{x:387,y:446,t:1527030677204};\\\", \\\"{x:390,y:446,t:1527030677220};\\\", \\\"{x:392,y:446,t:1527030677237};\\\", \\\"{x:394,y:446,t:1527030677254};\\\", \\\"{x:397,y:446,t:1527030677270};\\\", \\\"{x:400,y:446,t:1527030677287};\\\", \\\"{x:406,y:447,t:1527030677304};\\\", \\\"{x:407,y:447,t:1527030677320};\\\", \\\"{x:410,y:448,t:1527030677337};\\\", \\\"{x:413,y:449,t:1527030677354};\\\", \\\"{x:415,y:449,t:1527030677371};\\\", \\\"{x:416,y:450,t:1527030677388};\\\", \\\"{x:419,y:450,t:1527030677405};\\\", \\\"{x:420,y:451,t:1527030677421};\\\", \\\"{x:422,y:451,t:1527030677438};\\\", \\\"{x:424,y:451,t:1527030677454};\\\", \\\"{x:428,y:453,t:1527030677471};\\\", \\\"{x:432,y:454,t:1527030677488};\\\", \\\"{x:435,y:454,t:1527030677504};\\\", \\\"{x:438,y:456,t:1527030677521};\\\", \\\"{x:445,y:456,t:1527030677539};\\\", \\\"{x:445,y:457,t:1527030677556};\\\", \\\"{x:446,y:458,t:1527030677572};\\\", \\\"{x:448,y:458,t:1527030677588};\\\", \\\"{x:449,y:458,t:1527030677606};\\\", \\\"{x:451,y:458,t:1527030677623};\\\", \\\"{x:452,y:459,t:1527030677639};\\\", \\\"{x:453,y:459,t:1527030677655};\\\", \\\"{x:455,y:460,t:1527030677672};\\\", \\\"{x:456,y:461,t:1527030677688};\\\", \\\"{x:459,y:461,t:1527030677706};\\\", \\\"{x:460,y:461,t:1527030677723};\\\", \\\"{x:462,y:461,t:1527030677739};\\\", \\\"{x:463,y:461,t:1527030677760};\\\", \\\"{x:465,y:461,t:1527030677773};\\\", \\\"{x:466,y:462,t:1527030677789};\\\", \\\"{x:470,y:462,t:1527030677806};\\\", \\\"{x:473,y:462,t:1527030677823};\\\", \\\"{x:476,y:463,t:1527030677839};\\\", \\\"{x:479,y:463,t:1527030677857};\\\", \\\"{x:483,y:463,t:1527030677873};\\\", \\\"{x:490,y:463,t:1527030677889};\\\", \\\"{x:497,y:463,t:1527030677906};\\\", \\\"{x:504,y:463,t:1527030677923};\\\", \\\"{x:511,y:463,t:1527030677940};\\\", \\\"{x:519,y:463,t:1527030677956};\\\", \\\"{x:526,y:463,t:1527030677974};\\\", \\\"{x:530,y:463,t:1527030677989};\\\", \\\"{x:532,y:462,t:1527030678007};\\\", \\\"{x:536,y:460,t:1527030678023};\\\", \\\"{x:540,y:459,t:1527030678040};\\\", \\\"{x:543,y:457,t:1527030678056};\\\", \\\"{x:547,y:456,t:1527030678074};\\\", \\\"{x:550,y:456,t:1527030678090};\\\", \\\"{x:554,y:455,t:1527030678106};\\\", \\\"{x:556,y:454,t:1527030678124};\\\", \\\"{x:557,y:454,t:1527030678140};\\\", \\\"{x:558,y:453,t:1527030678158};\\\", \\\"{x:560,y:452,t:1527030678183};\\\", \\\"{x:562,y:452,t:1527030678384};\\\", \\\"{x:563,y:452,t:1527030678416};\\\", \\\"{x:565,y:450,t:1527030678439};\\\", \\\"{x:567,y:450,t:1527030678448};\\\", \\\"{x:568,y:450,t:1527030678459};\\\", \\\"{x:569,y:450,t:1527030678475};\\\", \\\"{x:571,y:450,t:1527030678491};\\\", \\\"{x:573,y:450,t:1527030678509};\\\", \\\"{x:574,y:450,t:1527030678525};\\\", \\\"{x:577,y:450,t:1527030678542};\\\", \\\"{x:580,y:450,t:1527030678559};\\\", \\\"{x:587,y:450,t:1527030678575};\\\", \\\"{x:591,y:450,t:1527030678591};\\\", \\\"{x:597,y:450,t:1527030678609};\\\", \\\"{x:604,y:450,t:1527030678626};\\\", \\\"{x:608,y:450,t:1527030678642};\\\", \\\"{x:612,y:450,t:1527030678658};\\\", \\\"{x:615,y:450,t:1527030678675};\\\", \\\"{x:618,y:450,t:1527030678693};\\\", \\\"{x:620,y:450,t:1527030678709};\\\", \\\"{x:621,y:449,t:1527030678726};\\\", \\\"{x:623,y:449,t:1527030678742};\\\", \\\"{x:624,y:449,t:1527030678760};\\\", \\\"{x:626,y:449,t:1527030678776};\\\", \\\"{x:627,y:449,t:1527030678792};\\\", \\\"{x:629,y:449,t:1527030678810};\\\", \\\"{x:630,y:449,t:1527030678827};\\\", \\\"{x:632,y:449,t:1527030678842};\\\", \\\"{x:633,y:449,t:1527030678860};\\\", \\\"{x:635,y:449,t:1527030678876};\\\", \\\"{x:637,y:449,t:1527030678895};\\\", \\\"{x:638,y:449,t:1527030678911};\\\", \\\"{x:639,y:449,t:1527030678926};\\\", \\\"{x:642,y:449,t:1527030678943};\\\", \\\"{x:644,y:449,t:1527030678960};\\\", \\\"{x:648,y:449,t:1527030678977};\\\", \\\"{x:650,y:449,t:1527030678993};\\\", \\\"{x:651,y:449,t:1527030679010};\\\", \\\"{x:654,y:449,t:1527030679027};\\\", \\\"{x:656,y:449,t:1527030679044};\\\", \\\"{x:658,y:450,t:1527030679061};\\\", \\\"{x:660,y:451,t:1527030679087};\\\", \\\"{x:661,y:451,t:1527030679111};\\\", \\\"{x:662,y:451,t:1527030679143};\\\", \\\"{x:663,y:452,t:1527030679161};\\\", \\\"{x:664,y:453,t:1527030679177};\\\", \\\"{x:665,y:453,t:1527030679199};\\\", \\\"{x:666,y:453,t:1527030679210};\\\", \\\"{x:667,y:454,t:1527030679227};\\\", \\\"{x:669,y:454,t:1527030679245};\\\", \\\"{x:671,y:454,t:1527030679260};\\\", \\\"{x:675,y:455,t:1527030679278};\\\", \\\"{x:679,y:456,t:1527030679295};\\\", \\\"{x:685,y:457,t:1527030679311};\\\", \\\"{x:688,y:457,t:1527030679327};\\\", \\\"{x:692,y:458,t:1527030679344};\\\", \\\"{x:693,y:458,t:1527030679361};\\\", \\\"{x:694,y:458,t:1527030679378};\\\", \\\"{x:696,y:459,t:1527030679394};\\\", \\\"{x:698,y:459,t:1527030679411};\\\", \\\"{x:699,y:459,t:1527030679439};\\\", \\\"{x:701,y:459,t:1527030679464};\\\", \\\"{x:702,y:460,t:1527030679479};\\\", \\\"{x:703,y:460,t:1527030679503};\\\", \\\"{x:704,y:461,t:1527030679519};\\\", \\\"{x:705,y:461,t:1527030679560};\\\", \\\"{x:706,y:461,t:1527030679567};\\\", \\\"{x:707,y:461,t:1527030679583};\\\", \\\"{x:709,y:461,t:1527030679599};\\\", \\\"{x:710,y:461,t:1527030679613};\\\", \\\"{x:712,y:461,t:1527030679629};\\\", \\\"{x:715,y:460,t:1527030679646};\\\", \\\"{x:718,y:460,t:1527030679663};\\\", \\\"{x:720,y:460,t:1527030679679};\\\", \\\"{x:724,y:460,t:1527030679695};\\\", \\\"{x:728,y:460,t:1527030679712};\\\", \\\"{x:731,y:460,t:1527030679729};\\\", \\\"{x:735,y:460,t:1527030679745};\\\", \\\"{x:738,y:460,t:1527030679762};\\\", \\\"{x:742,y:460,t:1527030679780};\\\", \\\"{x:746,y:461,t:1527030679797};\\\", \\\"{x:749,y:464,t:1527030679812};\\\", \\\"{x:750,y:464,t:1527030679829};\\\", \\\"{x:752,y:465,t:1527030679847};\\\", \\\"{x:754,y:466,t:1527030679863};\\\", \\\"{x:756,y:467,t:1527030679880};\\\", \\\"{x:756,y:469,t:1527030680152};\\\", \\\"{x:756,y:470,t:1527030680175};\\\", \\\"{x:756,y:472,t:1527030680519};\\\", \\\"{x:756,y:474,t:1527030680532};\\\", \\\"{x:756,y:477,t:1527030680549};\\\", \\\"{x:755,y:480,t:1527030680566};\\\", \\\"{x:755,y:482,t:1527030680583};\\\", \\\"{x:755,y:483,t:1527030680598};\\\", \\\"{x:755,y:486,t:1527030680616};\\\", \\\"{x:755,y:487,t:1527030680635};\\\", \\\"{x:755,y:488,t:1527030680662};\\\", \\\"{x:755,y:489,t:1527030681320};\\\", \\\"{x:754,y:493,t:1527030681334};\\\", \\\"{x:754,y:497,t:1527030681350};\\\", \\\"{x:752,y:503,t:1527030681367};\\\", \\\"{x:750,y:508,t:1527030681383};\\\", \\\"{x:750,y:511,t:1527030681400};\\\", \\\"{x:749,y:512,t:1527030681417};\\\", \\\"{x:749,y:514,t:1527030681433};\\\", \\\"{x:748,y:515,t:1527030681449};\\\", \\\"{x:748,y:516,t:1527030681467};\\\", \\\"{x:748,y:517,t:1527030681483};\\\", \\\"{x:748,y:518,t:1527030681501};\\\", \\\"{x:747,y:518,t:1527030681516};\\\", \\\"{x:748,y:519,t:1527030682919};\\\", \\\"{x:749,y:519,t:1527030682927};\\\", \\\"{x:754,y:519,t:1527030682937};\\\", \\\"{x:766,y:519,t:1527030682955};\\\", \\\"{x:782,y:519,t:1527030682972};\\\", \\\"{x:803,y:519,t:1527030682988};\\\", \\\"{x:822,y:516,t:1527030683006};\\\", \\\"{x:842,y:512,t:1527030683022};\\\", \\\"{x:869,y:505,t:1527030683038};\\\", \\\"{x:890,y:499,t:1527030683054};\\\", \\\"{x:909,y:494,t:1527030683072};\\\", \\\"{x:924,y:489,t:1527030683088};\\\", \\\"{x:938,y:484,t:1527030683105};\\\", \\\"{x:953,y:480,t:1527030683121};\\\", \\\"{x:961,y:479,t:1527030683139};\\\", \\\"{x:971,y:478,t:1527030683154};\\\", \\\"{x:980,y:477,t:1527030683171};\\\", \\\"{x:987,y:477,t:1527030683188};\\\", \\\"{x:998,y:475,t:1527030683204};\\\", \\\"{x:1011,y:475,t:1527030683222};\\\", \\\"{x:1049,y:478,t:1527030683239};\\\", \\\"{x:1067,y:482,t:1527030683255};\\\", \\\"{x:1106,y:487,t:1527030683272};\\\", \\\"{x:1119,y:489,t:1527030683289};\\\", \\\"{x:1134,y:494,t:1527030683304};\\\", \\\"{x:1143,y:497,t:1527030683321};\\\", \\\"{x:1148,y:500,t:1527030683339};\\\", \\\"{x:1152,y:501,t:1527030683356};\\\", \\\"{x:1162,y:505,t:1527030683371};\\\", \\\"{x:1171,y:506,t:1527030683388};\\\", \\\"{x:1184,y:507,t:1527030683406};\\\", \\\"{x:1199,y:507,t:1527030683423};\\\", \\\"{x:1207,y:507,t:1527030683439};\\\", \\\"{x:1216,y:507,t:1527030683455};\\\", \\\"{x:1224,y:507,t:1527030683472};\\\", \\\"{x:1236,y:509,t:1527030683489};\\\", \\\"{x:1241,y:509,t:1527030683506};\\\", \\\"{x:1243,y:509,t:1527030683522};\\\", \\\"{x:1245,y:509,t:1527030683539};\\\", \\\"{x:1247,y:508,t:1527030683556};\\\", \\\"{x:1248,y:507,t:1527030683573};\\\", \\\"{x:1249,y:507,t:1527030692480};\\\", \\\"{x:1254,y:507,t:1527030692487};\\\", \\\"{x:1262,y:508,t:1527030692502};\\\", \\\"{x:1274,y:517,t:1527030692519};\\\", \\\"{x:1284,y:533,t:1527030692536};\\\", \\\"{x:1295,y:547,t:1527030692553};\\\", \\\"{x:1303,y:559,t:1527030692570};\\\", \\\"{x:1311,y:569,t:1527030692585};\\\", \\\"{x:1316,y:578,t:1527030692602};\\\", \\\"{x:1320,y:584,t:1527030692619};\\\", \\\"{x:1325,y:592,t:1527030692635};\\\", \\\"{x:1329,y:600,t:1527030692652};\\\", \\\"{x:1334,y:609,t:1527030692670};\\\", \\\"{x:1337,y:618,t:1527030692685};\\\", \\\"{x:1340,y:626,t:1527030692702};\\\", \\\"{x:1344,y:639,t:1527030692719};\\\", \\\"{x:1349,y:654,t:1527030692736};\\\", \\\"{x:1350,y:666,t:1527030692752};\\\", \\\"{x:1353,y:683,t:1527030692769};\\\", \\\"{x:1357,y:702,t:1527030692786};\\\", \\\"{x:1360,y:717,t:1527030692802};\\\", \\\"{x:1365,y:730,t:1527030692820};\\\", \\\"{x:1369,y:737,t:1527030692837};\\\", \\\"{x:1368,y:735,t:1527030692968};\\\", \\\"{x:1365,y:723,t:1527030692975};\\\", \\\"{x:1359,y:715,t:1527030692986};\\\", \\\"{x:1350,y:688,t:1527030693003};\\\", \\\"{x:1337,y:664,t:1527030693020};\\\", \\\"{x:1326,y:642,t:1527030693036};\\\", \\\"{x:1312,y:623,t:1527030693054};\\\", \\\"{x:1302,y:613,t:1527030693069};\\\", \\\"{x:1296,y:607,t:1527030693086};\\\", \\\"{x:1291,y:603,t:1527030693103};\\\", \\\"{x:1288,y:601,t:1527030693119};\\\", \\\"{x:1288,y:600,t:1527030693136};\\\", \\\"{x:1287,y:599,t:1527030693153};\\\", \\\"{x:1286,y:598,t:1527030693170};\\\", \\\"{x:1286,y:597,t:1527030693191};\\\", \\\"{x:1286,y:596,t:1527030693203};\\\", \\\"{x:1285,y:594,t:1527030693221};\\\", \\\"{x:1285,y:592,t:1527030693236};\\\", \\\"{x:1284,y:588,t:1527030693254};\\\", \\\"{x:1283,y:586,t:1527030693271};\\\", \\\"{x:1283,y:584,t:1527030693286};\\\", \\\"{x:1283,y:581,t:1527030693304};\\\", \\\"{x:1283,y:579,t:1527030693320};\\\", \\\"{x:1283,y:577,t:1527030693337};\\\", \\\"{x:1282,y:574,t:1527030693353};\\\", \\\"{x:1281,y:571,t:1527030693369};\\\", \\\"{x:1281,y:570,t:1527030693386};\\\", \\\"{x:1281,y:568,t:1527030693404};\\\", \\\"{x:1281,y:567,t:1527030693436};\\\", \\\"{x:1281,y:566,t:1527030693453};\\\", \\\"{x:1280,y:565,t:1527030693526};\\\", \\\"{x:1275,y:566,t:1527030710545};\\\", \\\"{x:1258,y:573,t:1527030710562};\\\", \\\"{x:1229,y:577,t:1527030710579};\\\", \\\"{x:1196,y:577,t:1527030710595};\\\", \\\"{x:1165,y:577,t:1527030710612};\\\", \\\"{x:1139,y:577,t:1527030710629};\\\", \\\"{x:1106,y:577,t:1527030710645};\\\", \\\"{x:1069,y:577,t:1527030710662};\\\", \\\"{x:992,y:589,t:1527030710678};\\\", \\\"{x:925,y:599,t:1527030710695};\\\", \\\"{x:847,y:620,t:1527030710713};\\\", \\\"{x:789,y:636,t:1527030710729};\\\", \\\"{x:734,y:651,t:1527030710744};\\\", \\\"{x:686,y:665,t:1527030710760};\\\", \\\"{x:647,y:674,t:1527030710778};\\\", \\\"{x:617,y:680,t:1527030710794};\\\", \\\"{x:588,y:685,t:1527030710810};\\\", \\\"{x:560,y:692,t:1527030710828};\\\", \\\"{x:536,y:696,t:1527030710844};\\\", \\\"{x:514,y:698,t:1527030710860};\\\", \\\"{x:488,y:701,t:1527030710878};\\\", \\\"{x:464,y:701,t:1527030710894};\\\", \\\"{x:433,y:701,t:1527030710910};\\\", \\\"{x:412,y:699,t:1527030710928};\\\", \\\"{x:392,y:692,t:1527030710944};\\\", \\\"{x:377,y:684,t:1527030710961};\\\", \\\"{x:369,y:675,t:1527030710978};\\\", \\\"{x:363,y:664,t:1527030710995};\\\", \\\"{x:357,y:648,t:1527030711010};\\\", \\\"{x:355,y:628,t:1527030711028};\\\", \\\"{x:355,y:599,t:1527030711044};\\\", \\\"{x:355,y:579,t:1527030711060};\\\", \\\"{x:356,y:564,t:1527030711077};\\\", \\\"{x:359,y:553,t:1527030711093};\\\", \\\"{x:368,y:535,t:1527030711111};\\\", \\\"{x:379,y:523,t:1527030711128};\\\", \\\"{x:391,y:516,t:1527030711144};\\\", \\\"{x:405,y:510,t:1527030711161};\\\", \\\"{x:419,y:506,t:1527030711178};\\\", \\\"{x:434,y:503,t:1527030711195};\\\", \\\"{x:443,y:501,t:1527030711210};\\\", \\\"{x:451,y:497,t:1527030711228};\\\", \\\"{x:459,y:493,t:1527030711243};\\\", \\\"{x:471,y:492,t:1527030711260};\\\", \\\"{x:481,y:490,t:1527030711277};\\\", \\\"{x:490,y:486,t:1527030711294};\\\", \\\"{x:499,y:482,t:1527030711310};\\\", \\\"{x:502,y:481,t:1527030711328};\\\", \\\"{x:504,y:480,t:1527030711344};\\\", \\\"{x:505,y:480,t:1527030711360};\\\", \\\"{x:506,y:479,t:1527030711377};\\\", \\\"{x:507,y:479,t:1527030711398};\\\", \\\"{x:508,y:479,t:1527030711414};\\\", \\\"{x:509,y:479,t:1527030711428};\\\", \\\"{x:511,y:479,t:1527030711444};\\\", \\\"{x:519,y:481,t:1527030711460};\\\", \\\"{x:526,y:486,t:1527030711477};\\\", \\\"{x:538,y:494,t:1527030711494};\\\", \\\"{x:546,y:498,t:1527030711510};\\\", \\\"{x:549,y:500,t:1527030711527};\\\", \\\"{x:552,y:503,t:1527030711545};\\\", \\\"{x:556,y:506,t:1527030711561};\\\", \\\"{x:558,y:508,t:1527030711577};\\\", \\\"{x:558,y:509,t:1527030711594};\\\", \\\"{x:560,y:511,t:1527030711611};\\\", \\\"{x:561,y:513,t:1527030711627};\\\", \\\"{x:562,y:515,t:1527030711644};\\\", \\\"{x:562,y:516,t:1527030711661};\\\", \\\"{x:563,y:517,t:1527030711677};\\\", \\\"{x:564,y:517,t:1527030711702};\\\", \\\"{x:565,y:519,t:1527030711776};\\\", \\\"{x:566,y:519,t:1527030711795};\\\", \\\"{x:567,y:519,t:1527030711811};\\\", \\\"{x:570,y:520,t:1527030711827};\\\", \\\"{x:576,y:522,t:1527030711844};\\\", \\\"{x:582,y:522,t:1527030711861};\\\", \\\"{x:584,y:522,t:1527030711877};\\\", \\\"{x:588,y:521,t:1527030711894};\\\", \\\"{x:592,y:520,t:1527030711911};\\\", \\\"{x:594,y:519,t:1527030711928};\\\", \\\"{x:595,y:518,t:1527030711945};\\\", \\\"{x:597,y:517,t:1527030711962};\\\", \\\"{x:598,y:517,t:1527030711978};\\\", \\\"{x:600,y:516,t:1527030712030};\\\", \\\"{x:602,y:516,t:1527030712054};\\\", \\\"{x:603,y:515,t:1527030712062};\\\", \\\"{x:604,y:514,t:1527030712078};\\\", \\\"{x:608,y:512,t:1527030712095};\\\", \\\"{x:611,y:511,t:1527030712111};\\\", \\\"{x:613,y:509,t:1527030712127};\\\", \\\"{x:615,y:508,t:1527030712145};\\\", \\\"{x:618,y:507,t:1527030712162};\\\", \\\"{x:620,y:506,t:1527030712179};\\\", \\\"{x:622,y:504,t:1527030712196};\\\", \\\"{x:624,y:503,t:1527030712212};\\\", \\\"{x:626,y:502,t:1527030712229};\\\", \\\"{x:627,y:501,t:1527030712429};\\\", \\\"{x:626,y:501,t:1527030712583};\\\", \\\"{x:624,y:501,t:1527030712598};\\\", \\\"{x:620,y:502,t:1527030712612};\\\", \\\"{x:616,y:505,t:1527030712628};\\\", \\\"{x:606,y:509,t:1527030712646};\\\", \\\"{x:593,y:519,t:1527030712663};\\\", \\\"{x:563,y:540,t:1527030712679};\\\", \\\"{x:544,y:556,t:1527030712696};\\\", \\\"{x:527,y:573,t:1527030712712};\\\", \\\"{x:511,y:591,t:1527030712728};\\\", \\\"{x:498,y:608,t:1527030712746};\\\", \\\"{x:491,y:624,t:1527030712762};\\\", \\\"{x:486,y:636,t:1527030712779};\\\", \\\"{x:485,y:642,t:1527030712795};\\\", \\\"{x:484,y:645,t:1527030712811};\\\", \\\"{x:484,y:650,t:1527030712829};\\\", \\\"{x:484,y:656,t:1527030712846};\\\", \\\"{x:486,y:662,t:1527030712861};\\\", \\\"{x:491,y:674,t:1527030712879};\\\", \\\"{x:496,y:682,t:1527030712895};\\\", \\\"{x:504,y:691,t:1527030712911};\\\", \\\"{x:512,y:700,t:1527030712928};\\\", \\\"{x:520,y:708,t:1527030712945};\\\", \\\"{x:524,y:712,t:1527030712962};\\\", \\\"{x:526,y:714,t:1527030712978};\\\", \\\"{x:527,y:716,t:1527030712996};\\\", \\\"{x:528,y:717,t:1527030713012};\\\", \\\"{x:530,y:718,t:1527030713028};\\\", \\\"{x:530,y:721,t:1527030713046};\\\", \\\"{x:532,y:728,t:1527030713062};\\\", \\\"{x:532,y:732,t:1527030713078};\\\", \\\"{x:532,y:735,t:1527030713096};\\\", \\\"{x:532,y:736,t:1527030713112};\\\", \\\"{x:532,y:735,t:1527030714071};\\\", \\\"{x:532,y:733,t:1527030714094};\\\", \\\"{x:532,y:731,t:1527030714110};\\\", \\\"{x:532,y:730,t:1527030714126};\\\" ] }, { \\\"rt\\\": 36221, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 13, \\\"time_elapsed\\\": 507038, \\\"internal_node_id\\\": \\\"0.0-6.0-3.0\\\", \\\"subject\\\": \\\"E5L6P\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime+before+endtime+during\\\", \\\"q\\\": 9, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"I\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-G -G -J -J -J \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:532,y:729,t:1527030714934};\\\", \\\"{x:529,y:723,t:1527030714948};\\\", \\\"{x:516,y:705,t:1527030714965};\\\", \\\"{x:494,y:679,t:1527030714981};\\\", \\\"{x:476,y:660,t:1527030714996};\\\", \\\"{x:459,y:643,t:1527030715014};\\\", \\\"{x:428,y:613,t:1527030715030};\\\", \\\"{x:401,y:589,t:1527030715047};\\\", \\\"{x:322,y:533,t:1527030715122};\\\", \\\"{x:321,y:532,t:1527030715131};\\\", \\\"{x:318,y:531,t:1527030715147};\\\", \\\"{x:318,y:530,t:1527030715163};\\\", \\\"{x:318,y:529,t:1527030715198};\\\", \\\"{x:318,y:528,t:1527030715214};\\\", \\\"{x:324,y:525,t:1527030715230};\\\", \\\"{x:327,y:523,t:1527030715248};\\\", \\\"{x:332,y:521,t:1527030715263};\\\", \\\"{x:336,y:518,t:1527030715281};\\\", \\\"{x:339,y:515,t:1527030715298};\\\", \\\"{x:345,y:511,t:1527030715313};\\\", \\\"{x:355,y:504,t:1527030715330};\\\", \\\"{x:367,y:496,t:1527030715347};\\\", \\\"{x:382,y:487,t:1527030715363};\\\", \\\"{x:399,y:475,t:1527030715382};\\\", \\\"{x:408,y:468,t:1527030715397};\\\", \\\"{x:415,y:462,t:1527030715413};\\\", \\\"{x:423,y:457,t:1527030715431};\\\", \\\"{x:424,y:456,t:1527030715448};\\\", \\\"{x:425,y:455,t:1527030715464};\\\", \\\"{x:426,y:454,t:1527030715481};\\\", \\\"{x:426,y:452,t:1527030715497};\\\", \\\"{x:429,y:450,t:1527030715514};\\\", \\\"{x:430,y:449,t:1527030715535};\\\", \\\"{x:431,y:448,t:1527030715550};\\\", \\\"{x:432,y:448,t:1527030715565};\\\", \\\"{x:433,y:447,t:1527030715743};\\\", \\\"{x:435,y:448,t:1527030715750};\\\", \\\"{x:437,y:448,t:1527030715765};\\\", \\\"{x:443,y:452,t:1527030715781};\\\", \\\"{x:447,y:453,t:1527030715798};\\\", \\\"{x:451,y:455,t:1527030715814};\\\", \\\"{x:458,y:457,t:1527030715830};\\\", \\\"{x:462,y:458,t:1527030715848};\\\", \\\"{x:469,y:460,t:1527030715864};\\\", \\\"{x:472,y:461,t:1527030715881};\\\", \\\"{x:473,y:462,t:1527030715898};\\\", \\\"{x:475,y:462,t:1527030715915};\\\", \\\"{x:476,y:462,t:1527030716143};\\\", \\\"{x:479,y:462,t:1527030716150};\\\", \\\"{x:481,y:462,t:1527030716167};\\\", \\\"{x:482,y:462,t:1527030716182};\\\", \\\"{x:483,y:462,t:1527030716198};\\\", \\\"{x:484,y:462,t:1527030716215};\\\", \\\"{x:485,y:462,t:1527030716232};\\\", \\\"{x:486,y:462,t:1527030716248};\\\", \\\"{x:487,y:462,t:1527030716264};\\\", \\\"{x:488,y:462,t:1527030716282};\\\", \\\"{x:489,y:462,t:1527030716298};\\\", \\\"{x:490,y:462,t:1527030716315};\\\", \\\"{x:492,y:462,t:1527030716332};\\\", \\\"{x:495,y:462,t:1527030716348};\\\", \\\"{x:498,y:462,t:1527030716365};\\\", \\\"{x:504,y:462,t:1527030716382};\\\", \\\"{x:514,y:463,t:1527030716398};\\\", \\\"{x:522,y:464,t:1527030716415};\\\", \\\"{x:532,y:466,t:1527030716432};\\\", \\\"{x:543,y:466,t:1527030716449};\\\", \\\"{x:551,y:466,t:1527030716465};\\\", \\\"{x:560,y:466,t:1527030716482};\\\", \\\"{x:563,y:466,t:1527030716499};\\\", \\\"{x:565,y:466,t:1527030716514};\\\", \\\"{x:567,y:466,t:1527030716532};\\\", \\\"{x:568,y:466,t:1527030716549};\\\", \\\"{x:569,y:466,t:1527030716565};\\\", \\\"{x:573,y:466,t:1527030716581};\\\", \\\"{x:579,y:466,t:1527030716598};\\\", \\\"{x:582,y:466,t:1527030716615};\\\", \\\"{x:586,y:466,t:1527030716631};\\\", \\\"{x:592,y:466,t:1527030716648};\\\", \\\"{x:599,y:466,t:1527030716664};\\\", \\\"{x:604,y:466,t:1527030716682};\\\", \\\"{x:610,y:466,t:1527030716699};\\\", \\\"{x:615,y:465,t:1527030716716};\\\", \\\"{x:617,y:465,t:1527030716732};\\\", \\\"{x:619,y:465,t:1527030716748};\\\", \\\"{x:620,y:465,t:1527030716766};\\\", \\\"{x:621,y:465,t:1527030716782};\\\", \\\"{x:622,y:465,t:1527030716798};\\\", \\\"{x:623,y:465,t:1527030716815};\\\", \\\"{x:625,y:465,t:1527030716846};\\\", \\\"{x:626,y:464,t:1527030716871};\\\", \\\"{x:628,y:464,t:1527030716882};\\\", \\\"{x:629,y:464,t:1527030716902};\\\", \\\"{x:630,y:464,t:1527030716916};\\\", \\\"{x:631,y:464,t:1527030716932};\\\", \\\"{x:632,y:464,t:1527030716951};\\\", \\\"{x:633,y:464,t:1527030716966};\\\", \\\"{x:634,y:464,t:1527030716982};\\\", \\\"{x:637,y:464,t:1527030716999};\\\", \\\"{x:641,y:464,t:1527030717016};\\\", \\\"{x:644,y:464,t:1527030717032};\\\", \\\"{x:648,y:464,t:1527030717049};\\\", \\\"{x:650,y:464,t:1527030717066};\\\", \\\"{x:653,y:464,t:1527030717082};\\\", \\\"{x:656,y:464,t:1527030717099};\\\", \\\"{x:657,y:464,t:1527030717116};\\\", \\\"{x:660,y:464,t:1527030717132};\\\", \\\"{x:664,y:465,t:1527030717149};\\\", \\\"{x:669,y:466,t:1527030717166};\\\", \\\"{x:676,y:468,t:1527030717182};\\\", \\\"{x:683,y:470,t:1527030717199};\\\", \\\"{x:691,y:472,t:1527030717216};\\\", \\\"{x:698,y:475,t:1527030717233};\\\", \\\"{x:708,y:476,t:1527030717248};\\\", \\\"{x:725,y:480,t:1527030717266};\\\", \\\"{x:742,y:481,t:1527030717282};\\\", \\\"{x:761,y:482,t:1527030717299};\\\", \\\"{x:780,y:482,t:1527030717316};\\\", \\\"{x:798,y:484,t:1527030717333};\\\", \\\"{x:813,y:484,t:1527030717349};\\\", \\\"{x:825,y:485,t:1527030717366};\\\", \\\"{x:838,y:486,t:1527030717382};\\\", \\\"{x:845,y:486,t:1527030717399};\\\", \\\"{x:848,y:487,t:1527030717417};\\\", \\\"{x:850,y:487,t:1527030717432};\\\", \\\"{x:851,y:487,t:1527030717448};\\\", \\\"{x:846,y:487,t:1527030720007};\\\", \\\"{x:833,y:487,t:1527030720018};\\\", \\\"{x:809,y:483,t:1527030720035};\\\", \\\"{x:789,y:481,t:1527030720051};\\\", \\\"{x:765,y:478,t:1527030720068};\\\", \\\"{x:741,y:477,t:1527030720085};\\\", \\\"{x:708,y:472,t:1527030720100};\\\", \\\"{x:669,y:466,t:1527030720118};\\\", \\\"{x:644,y:461,t:1527030720134};\\\", \\\"{x:619,y:456,t:1527030720151};\\\", \\\"{x:601,y:450,t:1527030720168};\\\", \\\"{x:588,y:447,t:1527030720184};\\\", \\\"{x:579,y:445,t:1527030720201};\\\", \\\"{x:576,y:444,t:1527030720218};\\\", \\\"{x:586,y:445,t:1527030720327};\\\", \\\"{x:604,y:449,t:1527030720334};\\\", \\\"{x:648,y:454,t:1527030720351};\\\", \\\"{x:682,y:460,t:1527030720368};\\\", \\\"{x:730,y:461,t:1527030720384};\\\", \\\"{x:756,y:461,t:1527030720401};\\\", \\\"{x:795,y:461,t:1527030720418};\\\", \\\"{x:831,y:467,t:1527030720434};\\\", \\\"{x:871,y:471,t:1527030720452};\\\", \\\"{x:903,y:476,t:1527030720468};\\\", \\\"{x:936,y:480,t:1527030720485};\\\", \\\"{x:978,y:480,t:1527030720502};\\\", \\\"{x:1008,y:480,t:1527030720518};\\\", \\\"{x:1037,y:480,t:1527030720535};\\\", \\\"{x:1068,y:480,t:1527030720552};\\\", \\\"{x:1100,y:480,t:1527030720568};\\\", \\\"{x:1121,y:480,t:1527030720585};\\\", \\\"{x:1144,y:478,t:1527030720602};\\\", \\\"{x:1170,y:474,t:1527030720618};\\\", \\\"{x:1192,y:471,t:1527030720636};\\\", \\\"{x:1211,y:468,t:1527030720652};\\\", \\\"{x:1230,y:466,t:1527030720668};\\\", \\\"{x:1248,y:466,t:1527030720685};\\\", \\\"{x:1270,y:466,t:1527030720703};\\\", \\\"{x:1282,y:465,t:1527030720719};\\\", \\\"{x:1294,y:465,t:1527030720735};\\\", \\\"{x:1309,y:465,t:1527030720752};\\\", \\\"{x:1324,y:465,t:1527030720769};\\\", \\\"{x:1335,y:465,t:1527030720785};\\\", \\\"{x:1342,y:465,t:1527030720802};\\\", \\\"{x:1355,y:468,t:1527030720818};\\\", \\\"{x:1378,y:486,t:1527030720835};\\\", \\\"{x:1400,y:513,t:1527030720853};\\\", \\\"{x:1410,y:533,t:1527030720868};\\\", \\\"{x:1414,y:547,t:1527030720885};\\\", \\\"{x:1418,y:562,t:1527030720905};\\\", \\\"{x:1418,y:569,t:1527030720919};\\\", \\\"{x:1418,y:575,t:1527030720934};\\\", \\\"{x:1418,y:583,t:1527030720952};\\\", \\\"{x:1418,y:590,t:1527030720969};\\\", \\\"{x:1418,y:594,t:1527030720985};\\\", \\\"{x:1416,y:601,t:1527030721002};\\\", \\\"{x:1416,y:609,t:1527030721018};\\\", \\\"{x:1416,y:621,t:1527030721034};\\\", \\\"{x:1419,y:639,t:1527030721051};\\\", \\\"{x:1428,y:663,t:1527030721069};\\\", \\\"{x:1437,y:681,t:1527030721084};\\\", \\\"{x:1448,y:703,t:1527030721102};\\\", \\\"{x:1457,y:712,t:1527030721119};\\\", \\\"{x:1465,y:723,t:1527030721135};\\\", \\\"{x:1471,y:729,t:1527030721152};\\\", \\\"{x:1474,y:734,t:1527030721168};\\\", \\\"{x:1478,y:740,t:1527030721185};\\\", \\\"{x:1482,y:746,t:1527030721201};\\\", \\\"{x:1482,y:748,t:1527030721218};\\\", \\\"{x:1482,y:752,t:1527030721235};\\\", \\\"{x:1482,y:756,t:1527030721252};\\\", \\\"{x:1482,y:761,t:1527030721269};\\\", \\\"{x:1480,y:769,t:1527030721285};\\\", \\\"{x:1475,y:776,t:1527030721302};\\\", \\\"{x:1473,y:780,t:1527030721319};\\\", \\\"{x:1469,y:785,t:1527030721336};\\\", \\\"{x:1466,y:788,t:1527030721352};\\\", \\\"{x:1464,y:791,t:1527030721369};\\\", \\\"{x:1463,y:795,t:1527030721386};\\\", \\\"{x:1462,y:800,t:1527030721402};\\\", \\\"{x:1462,y:802,t:1527030721419};\\\", \\\"{x:1460,y:805,t:1527030721436};\\\", \\\"{x:1460,y:808,t:1527030721452};\\\", \\\"{x:1460,y:811,t:1527030721469};\\\", \\\"{x:1460,y:820,t:1527030721487};\\\", \\\"{x:1460,y:824,t:1527030721502};\\\", \\\"{x:1460,y:828,t:1527030721519};\\\", \\\"{x:1461,y:834,t:1527030721536};\\\", \\\"{x:1462,y:836,t:1527030721552};\\\", \\\"{x:1462,y:839,t:1527030721569};\\\", \\\"{x:1463,y:839,t:1527030721591};\\\", \\\"{x:1460,y:839,t:1527030721687};\\\", \\\"{x:1457,y:839,t:1527030721703};\\\", \\\"{x:1454,y:838,t:1527030721719};\\\", \\\"{x:1450,y:837,t:1527030721737};\\\", \\\"{x:1446,y:834,t:1527030721753};\\\", \\\"{x:1443,y:834,t:1527030721769};\\\", \\\"{x:1439,y:834,t:1527030721786};\\\", \\\"{x:1435,y:834,t:1527030721803};\\\", \\\"{x:1432,y:834,t:1527030721819};\\\", \\\"{x:1426,y:834,t:1527030721836};\\\", \\\"{x:1420,y:834,t:1527030721852};\\\", \\\"{x:1412,y:833,t:1527030721870};\\\", \\\"{x:1395,y:833,t:1527030721886};\\\", \\\"{x:1388,y:833,t:1527030721903};\\\", \\\"{x:1382,y:833,t:1527030721920};\\\", \\\"{x:1376,y:833,t:1527030721936};\\\", \\\"{x:1368,y:834,t:1527030721954};\\\", \\\"{x:1356,y:834,t:1527030721970};\\\", \\\"{x:1355,y:834,t:1527030721986};\\\", \\\"{x:1350,y:834,t:1527030722004};\\\", \\\"{x:1345,y:834,t:1527030722020};\\\", \\\"{x:1337,y:834,t:1527030722037};\\\", \\\"{x:1324,y:834,t:1527030722053};\\\", \\\"{x:1305,y:829,t:1527030722069};\\\", \\\"{x:1277,y:823,t:1527030722087};\\\", \\\"{x:1256,y:822,t:1527030722103};\\\", \\\"{x:1237,y:819,t:1527030722119};\\\", \\\"{x:1221,y:817,t:1527030722136};\\\", \\\"{x:1209,y:817,t:1527030722154};\\\", \\\"{x:1196,y:817,t:1527030722169};\\\", \\\"{x:1192,y:817,t:1527030722186};\\\", \\\"{x:1188,y:817,t:1527030722203};\\\", \\\"{x:1186,y:817,t:1527030722220};\\\", \\\"{x:1185,y:817,t:1527030722351};\\\", \\\"{x:1188,y:821,t:1527030722359};\\\", \\\"{x:1191,y:825,t:1527030722370};\\\", \\\"{x:1194,y:828,t:1527030722386};\\\", \\\"{x:1199,y:830,t:1527030722402};\\\", \\\"{x:1207,y:835,t:1527030722420};\\\", \\\"{x:1217,y:839,t:1527030722436};\\\", \\\"{x:1224,y:840,t:1527030722453};\\\", \\\"{x:1225,y:840,t:1527030722470};\\\", \\\"{x:1226,y:840,t:1527030722607};\\\", \\\"{x:1226,y:839,t:1527030722620};\\\", \\\"{x:1226,y:834,t:1527030722637};\\\", \\\"{x:1222,y:828,t:1527030722653};\\\", \\\"{x:1219,y:823,t:1527030722671};\\\", \\\"{x:1218,y:822,t:1527030722687};\\\", \\\"{x:1217,y:821,t:1527030722704};\\\", \\\"{x:1216,y:821,t:1527030722721};\\\", \\\"{x:1216,y:820,t:1527030722742};\\\", \\\"{x:1215,y:818,t:1527030722754};\\\", \\\"{x:1215,y:817,t:1527030722775};\\\", \\\"{x:1214,y:817,t:1527030722791};\\\", \\\"{x:1214,y:818,t:1527030722943};\\\", \\\"{x:1214,y:820,t:1527030722959};\\\", \\\"{x:1214,y:822,t:1527030722970};\\\", \\\"{x:1214,y:827,t:1527030722988};\\\", \\\"{x:1214,y:830,t:1527030723003};\\\", \\\"{x:1214,y:832,t:1527030723020};\\\", \\\"{x:1214,y:834,t:1527030723063};\\\", \\\"{x:1213,y:832,t:1527030723351};\\\", \\\"{x:1213,y:831,t:1527030723374};\\\", \\\"{x:1213,y:829,t:1527030723387};\\\", \\\"{x:1213,y:828,t:1527030723403};\\\", \\\"{x:1213,y:827,t:1527030723420};\\\", \\\"{x:1213,y:826,t:1527030723437};\\\", \\\"{x:1211,y:823,t:1527030730676};\\\", \\\"{x:1209,y:820,t:1527030730683};\\\", \\\"{x:1204,y:816,t:1527030730697};\\\", \\\"{x:1199,y:813,t:1527030730713};\\\", \\\"{x:1191,y:808,t:1527030730729};\\\", \\\"{x:1177,y:799,t:1527030730746};\\\", \\\"{x:1172,y:797,t:1527030730763};\\\", \\\"{x:1166,y:793,t:1527030730780};\\\", \\\"{x:1163,y:790,t:1527030730797};\\\", \\\"{x:1159,y:788,t:1527030730814};\\\", \\\"{x:1159,y:787,t:1527030730830};\\\", \\\"{x:1157,y:786,t:1527030730846};\\\", \\\"{x:1155,y:785,t:1527030730863};\\\", \\\"{x:1151,y:783,t:1527030730881};\\\", \\\"{x:1147,y:779,t:1527030730897};\\\", \\\"{x:1137,y:771,t:1527030730914};\\\", \\\"{x:1110,y:753,t:1527030730931};\\\", \\\"{x:1086,y:738,t:1527030730947};\\\", \\\"{x:1056,y:721,t:1527030730964};\\\", \\\"{x:1030,y:706,t:1527030730980};\\\", \\\"{x:997,y:691,t:1527030730996};\\\", \\\"{x:963,y:677,t:1527030731014};\\\", \\\"{x:933,y:664,t:1527030731030};\\\", \\\"{x:911,y:655,t:1527030731046};\\\", \\\"{x:886,y:648,t:1527030731064};\\\", \\\"{x:865,y:642,t:1527030731080};\\\", \\\"{x:848,y:637,t:1527030731096};\\\", \\\"{x:831,y:633,t:1527030731113};\\\", \\\"{x:804,y:623,t:1527030731131};\\\", \\\"{x:791,y:618,t:1527030731146};\\\", \\\"{x:783,y:615,t:1527030731163};\\\", \\\"{x:779,y:613,t:1527030731180};\\\", \\\"{x:775,y:612,t:1527030731197};\\\", \\\"{x:772,y:611,t:1527030731214};\\\", \\\"{x:767,y:609,t:1527030731230};\\\", \\\"{x:760,y:608,t:1527030731247};\\\", \\\"{x:750,y:608,t:1527030731263};\\\", \\\"{x:736,y:608,t:1527030731280};\\\", \\\"{x:721,y:608,t:1527030731298};\\\", \\\"{x:700,y:606,t:1527030731313};\\\", \\\"{x:687,y:606,t:1527030731330};\\\", \\\"{x:673,y:606,t:1527030731347};\\\", \\\"{x:659,y:606,t:1527030731364};\\\", \\\"{x:649,y:606,t:1527030731381};\\\", \\\"{x:642,y:606,t:1527030731398};\\\", \\\"{x:636,y:606,t:1527030731414};\\\", \\\"{x:630,y:606,t:1527030731431};\\\", \\\"{x:626,y:605,t:1527030731447};\\\", \\\"{x:625,y:605,t:1527030731464};\\\", \\\"{x:623,y:605,t:1527030731481};\\\", \\\"{x:622,y:605,t:1527030731506};\\\", \\\"{x:620,y:605,t:1527030731779};\\\", \\\"{x:619,y:605,t:1527030731786};\\\", \\\"{x:617,y:605,t:1527030731799};\\\", \\\"{x:615,y:605,t:1527030731814};\\\", \\\"{x:613,y:605,t:1527030731832};\\\", \\\"{x:609,y:605,t:1527030731848};\\\", \\\"{x:606,y:605,t:1527030731864};\\\", \\\"{x:603,y:605,t:1527030731881};\\\", \\\"{x:599,y:605,t:1527030731900};\\\", \\\"{x:598,y:605,t:1527030731914};\\\", \\\"{x:596,y:605,t:1527030731931};\\\", \\\"{x:595,y:605,t:1527030731948};\\\", \\\"{x:594,y:601,t:1527030737155};\\\", \\\"{x:594,y:588,t:1527030737173};\\\", \\\"{x:592,y:575,t:1527030737189};\\\", \\\"{x:591,y:565,t:1527030737205};\\\", \\\"{x:589,y:553,t:1527030737219};\\\", \\\"{x:587,y:541,t:1527030737235};\\\", \\\"{x:586,y:535,t:1527030737252};\\\", \\\"{x:584,y:525,t:1527030737269};\\\", \\\"{x:583,y:515,t:1527030737286};\\\", \\\"{x:583,y:505,t:1527030737302};\\\", \\\"{x:583,y:499,t:1527030737319};\\\", \\\"{x:583,y:490,t:1527030737335};\\\", \\\"{x:583,y:484,t:1527030737353};\\\", \\\"{x:583,y:476,t:1527030737369};\\\", \\\"{x:583,y:470,t:1527030737385};\\\", \\\"{x:583,y:463,t:1527030737402};\\\", \\\"{x:583,y:457,t:1527030737419};\\\", \\\"{x:585,y:450,t:1527030737436};\\\", \\\"{x:588,y:444,t:1527030737453};\\\", \\\"{x:591,y:439,t:1527030737469};\\\", \\\"{x:592,y:437,t:1527030737486};\\\", \\\"{x:592,y:436,t:1527030737503};\\\", \\\"{x:593,y:435,t:1527030737519};\\\", \\\"{x:594,y:434,t:1527030737538};\\\", \\\"{x:595,y:433,t:1527030737552};\\\", \\\"{x:597,y:432,t:1527030737578};\\\", \\\"{x:598,y:432,t:1527030737610};\\\", \\\"{x:600,y:432,t:1527030737691};\\\", \\\"{x:602,y:432,t:1527030737702};\\\", \\\"{x:608,y:440,t:1527030737720};\\\", \\\"{x:614,y:449,t:1527030737736};\\\", \\\"{x:617,y:453,t:1527030737753};\\\", \\\"{x:621,y:459,t:1527030737770};\\\", \\\"{x:622,y:460,t:1527030737786};\\\", \\\"{x:622,y:462,t:1527030737802};\\\", \\\"{x:622,y:463,t:1527030737819};\\\", \\\"{x:623,y:465,t:1527030737836};\\\", \\\"{x:623,y:466,t:1527030737858};\\\", \\\"{x:623,y:467,t:1527030737875};\\\", \\\"{x:623,y:468,t:1527030737890};\\\", \\\"{x:623,y:469,t:1527030737914};\\\", \\\"{x:623,y:470,t:1527030737922};\\\", \\\"{x:623,y:471,t:1527030737936};\\\", \\\"{x:623,y:472,t:1527030737952};\\\", \\\"{x:623,y:473,t:1527030737970};\\\", \\\"{x:623,y:475,t:1527030737986};\\\", \\\"{x:623,y:476,t:1527030738002};\\\", \\\"{x:622,y:478,t:1527030738020};\\\", \\\"{x:622,y:479,t:1527030738036};\\\", \\\"{x:621,y:481,t:1527030738052};\\\", \\\"{x:620,y:481,t:1527030738070};\\\", \\\"{x:620,y:482,t:1527030738086};\\\", \\\"{x:619,y:483,t:1527030738103};\\\", \\\"{x:618,y:485,t:1527030738119};\\\", \\\"{x:617,y:486,t:1527030738154};\\\", \\\"{x:617,y:487,t:1527030738171};\\\", \\\"{x:615,y:489,t:1527030738186};\\\", \\\"{x:614,y:490,t:1527030738202};\\\", \\\"{x:614,y:491,t:1527030738219};\\\", \\\"{x:613,y:492,t:1527030738237};\\\", \\\"{x:612,y:493,t:1527030738258};\\\", \\\"{x:612,y:494,t:1527030738306};\\\", \\\"{x:611,y:495,t:1527030738337};\\\", \\\"{x:610,y:497,t:1527030738361};\\\", \\\"{x:609,y:498,t:1527030738393};\\\", \\\"{x:608,y:498,t:1527030738410};\\\", \\\"{x:608,y:499,t:1527030738426};\\\", \\\"{x:607,y:500,t:1527030738442};\\\", \\\"{x:606,y:501,t:1527030738454};\\\", \\\"{x:605,y:501,t:1527030738469};\\\", \\\"{x:605,y:502,t:1527030738490};\\\", \\\"{x:605,y:503,t:1527030738504};\\\", \\\"{x:604,y:504,t:1527030738530};\\\", \\\"{x:602,y:504,t:1527030738571};\\\", \\\"{x:601,y:506,t:1527030738587};\\\", \\\"{x:600,y:507,t:1527030738626};\\\", \\\"{x:599,y:507,t:1527030738667};\\\", \\\"{x:599,y:508,t:1527030738723};\\\", \\\"{x:598,y:510,t:1527030740274};\\\", \\\"{x:596,y:511,t:1527030740290};\\\", \\\"{x:593,y:514,t:1527030740307};\\\", \\\"{x:589,y:517,t:1527030740324};\\\", \\\"{x:586,y:519,t:1527030740342};\\\", \\\"{x:582,y:521,t:1527030740357};\\\", \\\"{x:580,y:523,t:1527030740373};\\\", \\\"{x:578,y:523,t:1527030740389};\\\", \\\"{x:577,y:524,t:1527030740404};\\\", \\\"{x:573,y:524,t:1527030742450};\\\", \\\"{x:568,y:524,t:1527030742458};\\\", \\\"{x:561,y:521,t:1527030742474};\\\", \\\"{x:556,y:517,t:1527030742491};\\\", \\\"{x:555,y:515,t:1527030742506};\\\", \\\"{x:554,y:513,t:1527030742522};\\\", \\\"{x:553,y:512,t:1527030742539};\\\", \\\"{x:552,y:510,t:1527030742556};\\\", \\\"{x:552,y:507,t:1527030742572};\\\", \\\"{x:552,y:503,t:1527030742589};\\\", \\\"{x:552,y:496,t:1527030742607};\\\", \\\"{x:552,y:489,t:1527030742623};\\\", \\\"{x:552,y:483,t:1527030742640};\\\", \\\"{x:552,y:480,t:1527030742656};\\\", \\\"{x:553,y:477,t:1527030742673};\\\", \\\"{x:555,y:477,t:1527030742689};\\\", \\\"{x:558,y:477,t:1527030742707};\\\", \\\"{x:559,y:477,t:1527030742754};\\\", \\\"{x:558,y:481,t:1527030742769};\\\", \\\"{x:556,y:482,t:1527030742777};\\\", \\\"{x:553,y:485,t:1527030742789};\\\", \\\"{x:538,y:492,t:1527030742808};\\\", \\\"{x:524,y:496,t:1527030742823};\\\", \\\"{x:500,y:501,t:1527030742840};\\\", \\\"{x:479,y:503,t:1527030742858};\\\", \\\"{x:446,y:506,t:1527030742873};\\\", \\\"{x:429,y:506,t:1527030742891};\\\", \\\"{x:414,y:506,t:1527030742906};\\\", \\\"{x:401,y:506,t:1527030742923};\\\", \\\"{x:391,y:506,t:1527030742941};\\\", \\\"{x:384,y:507,t:1527030742956};\\\", \\\"{x:378,y:508,t:1527030742973};\\\", \\\"{x:371,y:511,t:1527030742991};\\\", \\\"{x:362,y:514,t:1527030743006};\\\", \\\"{x:354,y:519,t:1527030743024};\\\", \\\"{x:348,y:523,t:1527030743040};\\\", \\\"{x:343,y:525,t:1527030743057};\\\", \\\"{x:336,y:530,t:1527030743073};\\\", \\\"{x:328,y:535,t:1527030743090};\\\", \\\"{x:325,y:537,t:1527030743106};\\\", \\\"{x:319,y:540,t:1527030743123};\\\", \\\"{x:313,y:543,t:1527030743141};\\\", \\\"{x:311,y:543,t:1527030743157};\\\", \\\"{x:302,y:543,t:1527030743174};\\\", \\\"{x:294,y:543,t:1527030743190};\\\", \\\"{x:285,y:542,t:1527030743206};\\\", \\\"{x:271,y:537,t:1527030743225};\\\", \\\"{x:256,y:528,t:1527030743241};\\\", \\\"{x:241,y:523,t:1527030743257};\\\", \\\"{x:221,y:516,t:1527030743274};\\\", \\\"{x:211,y:512,t:1527030743291};\\\", \\\"{x:203,y:510,t:1527030743307};\\\", \\\"{x:199,y:508,t:1527030743323};\\\", \\\"{x:197,y:508,t:1527030743341};\\\", \\\"{x:196,y:508,t:1527030743362};\\\", \\\"{x:195,y:508,t:1527030743386};\\\", \\\"{x:194,y:508,t:1527030743394};\\\", \\\"{x:193,y:508,t:1527030743410};\\\", \\\"{x:192,y:508,t:1527030743424};\\\", \\\"{x:191,y:508,t:1527030743441};\\\", \\\"{x:188,y:509,t:1527030743458};\\\", \\\"{x:184,y:509,t:1527030743474};\\\", \\\"{x:179,y:509,t:1527030743490};\\\", \\\"{x:174,y:509,t:1527030743507};\\\", \\\"{x:173,y:509,t:1527030743523};\\\", \\\"{x:170,y:509,t:1527030743541};\\\", \\\"{x:169,y:509,t:1527030743625};\\\", \\\"{x:170,y:509,t:1527030749818};\\\", \\\"{x:184,y:518,t:1527030749831};\\\", \\\"{x:232,y:553,t:1527030749847};\\\", \\\"{x:299,y:589,t:1527030749862};\\\", \\\"{x:368,y:630,t:1527030749879};\\\", \\\"{x:430,y:664,t:1527030749896};\\\", \\\"{x:491,y:690,t:1527030749913};\\\", \\\"{x:541,y:714,t:1527030749929};\\\", \\\"{x:595,y:738,t:1527030749946};\\\", \\\"{x:610,y:745,t:1527030749963};\\\", \\\"{x:615,y:747,t:1527030749978};\\\", \\\"{x:616,y:748,t:1527030750034};\\\", \\\"{x:618,y:749,t:1527030750045};\\\", \\\"{x:619,y:751,t:1527030750063};\\\", \\\"{x:619,y:752,t:1527030750079};\\\", \\\"{x:619,y:754,t:1527030750097};\\\", \\\"{x:618,y:754,t:1527030750130};\\\", \\\"{x:614,y:754,t:1527030750145};\\\", \\\"{x:611,y:753,t:1527030750163};\\\", \\\"{x:609,y:753,t:1527030750202};\\\", \\\"{x:607,y:753,t:1527030750213};\\\", \\\"{x:606,y:754,t:1527030750234};\\\", \\\"{x:605,y:754,t:1527030750273};\\\", \\\"{x:604,y:754,t:1527030750289};\\\", \\\"{x:602,y:754,t:1527030750306};\\\", \\\"{x:601,y:754,t:1527030750330};\\\", \\\"{x:599,y:754,t:1527030750346};\\\", \\\"{x:593,y:754,t:1527030750363};\\\", \\\"{x:583,y:753,t:1527030750379};\\\", \\\"{x:574,y:749,t:1527030750396};\\\", \\\"{x:568,y:748,t:1527030750413};\\\", \\\"{x:559,y:745,t:1527030750431};\\\", \\\"{x:546,y:741,t:1527030750446};\\\", \\\"{x:534,y:739,t:1527030750462};\\\", \\\"{x:526,y:736,t:1527030750480};\\\", \\\"{x:519,y:735,t:1527030750497};\\\", \\\"{x:516,y:732,t:1527030750512};\\\", \\\"{x:514,y:731,t:1527030750529};\\\" ] }, { \\\"rt\\\": 77579, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 14, \\\"time_elapsed\\\": 585828, \\\"internal_node_id\\\": \\\"0.0-6.0-4.0\\\", \\\"subject\\\": \\\"E5L6P\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"ends\\\", \\\"q\\\": 10, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F -F -12 PM-11 AM-M -C -M -M -X -X -F -X -X -X -B -B -F -B -M -J \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:513,y:731,t:1527030761026};\\\", \\\"{x:513,y:730,t:1527030761035};\\\", \\\"{x:513,y:728,t:1527030761045};\\\", \\\"{x:513,y:727,t:1527030761062};\\\", \\\"{x:513,y:726,t:1527030761079};\\\", \\\"{x:512,y:726,t:1527030763346};\\\", \\\"{x:511,y:726,t:1527030763354};\\\", \\\"{x:510,y:726,t:1527030763366};\\\", \\\"{x:508,y:726,t:1527030763383};\\\", \\\"{x:507,y:727,t:1527030763400};\\\", \\\"{x:505,y:727,t:1527030763416};\\\", \\\"{x:504,y:728,t:1527030763433};\\\", \\\"{x:503,y:729,t:1527030763507};\\\", \\\"{x:502,y:729,t:1527030763522};\\\", \\\"{x:501,y:730,t:1527030763546};\\\", \\\"{x:499,y:730,t:1527030763578};\\\", \\\"{x:498,y:730,t:1527030763602};\\\", \\\"{x:497,y:731,t:1527030763618};\\\", \\\"{x:496,y:731,t:1527030763634};\\\", \\\"{x:494,y:732,t:1527030763649};\\\", \\\"{x:493,y:732,t:1527030763667};\\\", \\\"{x:491,y:733,t:1527030763684};\\\", \\\"{x:490,y:733,t:1527030763699};\\\", \\\"{x:489,y:734,t:1527030763717};\\\", \\\"{x:488,y:734,t:1527030763738};\\\", \\\"{x:488,y:736,t:1527030763802};\\\", \\\"{x:488,y:739,t:1527030763816};\\\", \\\"{x:491,y:750,t:1527030763833};\\\", \\\"{x:496,y:757,t:1527030763851};\\\", \\\"{x:498,y:759,t:1527030763866};\\\", \\\"{x:499,y:760,t:1527030763883};\\\", \\\"{x:502,y:759,t:1527030763945};\\\", \\\"{x:502,y:753,t:1527030763957};\\\", \\\"{x:502,y:736,t:1527030763974};\\\", \\\"{x:502,y:711,t:1527030763991};\\\", \\\"{x:496,y:680,t:1527030764008};\\\", \\\"{x:485,y:651,t:1527030764024};\\\", \\\"{x:472,y:627,t:1527030764041};\\\", \\\"{x:449,y:593,t:1527030764058};\\\", \\\"{x:434,y:574,t:1527030764074};\\\", \\\"{x:415,y:559,t:1527030764091};\\\", \\\"{x:396,y:548,t:1527030764107};\\\", \\\"{x:382,y:542,t:1527030764125};\\\", \\\"{x:375,y:540,t:1527030764140};\\\", \\\"{x:372,y:539,t:1527030764157};\\\", \\\"{x:371,y:539,t:1527030764174};\\\", \\\"{x:369,y:540,t:1527030764209};\\\", \\\"{x:366,y:543,t:1527030764224};\\\", \\\"{x:361,y:557,t:1527030764241};\\\", \\\"{x:352,y:575,t:1527030764258};\\\", \\\"{x:348,y:585,t:1527030764274};\\\", \\\"{x:346,y:591,t:1527030764290};\\\", \\\"{x:344,y:596,t:1527030764308};\\\", \\\"{x:344,y:598,t:1527030764324};\\\", \\\"{x:344,y:599,t:1527030764341};\\\", \\\"{x:343,y:601,t:1527030764358};\\\", \\\"{x:342,y:604,t:1527030764374};\\\", \\\"{x:341,y:605,t:1527030764391};\\\", \\\"{x:340,y:606,t:1527030764408};\\\", \\\"{x:338,y:608,t:1527030764424};\\\", \\\"{x:335,y:609,t:1527030764440};\\\", \\\"{x:332,y:609,t:1527030764457};\\\", \\\"{x:330,y:611,t:1527030764475};\\\", \\\"{x:328,y:611,t:1527030764490};\\\", \\\"{x:324,y:611,t:1527030764507};\\\", \\\"{x:315,y:612,t:1527030764525};\\\", \\\"{x:301,y:615,t:1527030764542};\\\", \\\"{x:288,y:616,t:1527030764558};\\\", \\\"{x:277,y:617,t:1527030764574};\\\", \\\"{x:263,y:617,t:1527030764592};\\\", \\\"{x:249,y:618,t:1527030764607};\\\", \\\"{x:238,y:620,t:1527030764624};\\\", \\\"{x:227,y:624,t:1527030764640};\\\", \\\"{x:226,y:625,t:1527030764657};\\\", \\\"{x:226,y:627,t:1527030764675};\\\", \\\"{x:230,y:632,t:1527030764691};\\\", \\\"{x:245,y:639,t:1527030764708};\\\", \\\"{x:287,y:645,t:1527030764725};\\\", \\\"{x:363,y:647,t:1527030764741};\\\", \\\"{x:430,y:647,t:1527030764757};\\\", \\\"{x:485,y:647,t:1527030764775};\\\", \\\"{x:523,y:647,t:1527030764792};\\\", \\\"{x:547,y:647,t:1527030764808};\\\", \\\"{x:564,y:644,t:1527030764824};\\\", \\\"{x:578,y:637,t:1527030764841};\\\", \\\"{x:582,y:633,t:1527030764857};\\\", \\\"{x:583,y:629,t:1527030764875};\\\", \\\"{x:583,y:623,t:1527030764891};\\\", \\\"{x:583,y:617,t:1527030764907};\\\", \\\"{x:583,y:614,t:1527030764924};\\\", \\\"{x:581,y:611,t:1527030764941};\\\", \\\"{x:579,y:607,t:1527030764958};\\\", \\\"{x:575,y:604,t:1527030764974};\\\", \\\"{x:574,y:602,t:1527030764991};\\\", \\\"{x:572,y:600,t:1527030765008};\\\", \\\"{x:572,y:599,t:1527030765025};\\\", \\\"{x:570,y:595,t:1527030765041};\\\", \\\"{x:570,y:589,t:1527030765059};\\\", \\\"{x:570,y:585,t:1527030765074};\\\", \\\"{x:572,y:580,t:1527030765091};\\\", \\\"{x:573,y:577,t:1527030765108};\\\", \\\"{x:575,y:576,t:1527030765124};\\\", \\\"{x:578,y:574,t:1527030765141};\\\", \\\"{x:579,y:572,t:1527030765158};\\\", \\\"{x:580,y:572,t:1527030765175};\\\", \\\"{x:581,y:572,t:1527030765191};\\\", \\\"{x:584,y:571,t:1527030765208};\\\", \\\"{x:586,y:570,t:1527030765225};\\\", \\\"{x:586,y:569,t:1527030765242};\\\", \\\"{x:588,y:569,t:1527030765258};\\\", \\\"{x:589,y:569,t:1527030765313};\\\", \\\"{x:590,y:569,t:1527030765325};\\\", \\\"{x:592,y:571,t:1527030765342};\\\", \\\"{x:593,y:573,t:1527030765359};\\\", \\\"{x:593,y:574,t:1527030765402};\\\", \\\"{x:594,y:575,t:1527030765409};\\\", \\\"{x:595,y:575,t:1527030765426};\\\", \\\"{x:596,y:576,t:1527030765441};\\\", \\\"{x:599,y:578,t:1527030765459};\\\", \\\"{x:599,y:579,t:1527030765475};\\\", \\\"{x:601,y:580,t:1527030765493};\\\", \\\"{x:602,y:580,t:1527030765508};\\\", \\\"{x:604,y:580,t:1527030765537};\\\", \\\"{x:604,y:581,t:1527030765545};\\\", \\\"{x:606,y:581,t:1527030765559};\\\", \\\"{x:606,y:582,t:1527030765575};\\\", \\\"{x:608,y:583,t:1527030765593};\\\", \\\"{x:610,y:583,t:1527030766418};\\\", \\\"{x:615,y:587,t:1527030766425};\\\", \\\"{x:633,y:598,t:1527030766444};\\\", \\\"{x:657,y:608,t:1527030766459};\\\", \\\"{x:685,y:618,t:1527030766475};\\\", \\\"{x:715,y:629,t:1527030766493};\\\", \\\"{x:738,y:634,t:1527030766510};\\\", \\\"{x:759,y:640,t:1527030766526};\\\", \\\"{x:776,y:645,t:1527030766543};\\\", \\\"{x:792,y:650,t:1527030766559};\\\", \\\"{x:809,y:656,t:1527030766575};\\\", \\\"{x:818,y:659,t:1527030766593};\\\", \\\"{x:830,y:661,t:1527030766609};\\\", \\\"{x:838,y:664,t:1527030766625};\\\", \\\"{x:850,y:668,t:1527030766643};\\\", \\\"{x:866,y:673,t:1527030766659};\\\", \\\"{x:881,y:676,t:1527030766676};\\\", \\\"{x:901,y:681,t:1527030766693};\\\", \\\"{x:929,y:687,t:1527030766709};\\\", \\\"{x:955,y:693,t:1527030766726};\\\", \\\"{x:982,y:697,t:1527030766743};\\\", \\\"{x:1012,y:702,t:1527030766760};\\\", \\\"{x:1043,y:707,t:1527030766777};\\\", \\\"{x:1081,y:717,t:1527030766793};\\\", \\\"{x:1138,y:735,t:1527030766810};\\\", \\\"{x:1172,y:744,t:1527030766828};\\\", \\\"{x:1204,y:751,t:1527030766843};\\\", \\\"{x:1238,y:760,t:1527030766859};\\\", \\\"{x:1270,y:767,t:1527030766876};\\\", \\\"{x:1298,y:774,t:1527030766893};\\\", \\\"{x:1323,y:780,t:1527030766909};\\\", \\\"{x:1349,y:786,t:1527030766927};\\\", \\\"{x:1374,y:790,t:1527030766943};\\\", \\\"{x:1394,y:793,t:1527030766959};\\\", \\\"{x:1407,y:796,t:1527030766976};\\\", \\\"{x:1413,y:796,t:1527030766993};\\\", \\\"{x:1414,y:796,t:1527030767010};\\\", \\\"{x:1415,y:795,t:1527030767027};\\\", \\\"{x:1415,y:793,t:1527030767044};\\\", \\\"{x:1415,y:786,t:1527030767060};\\\", \\\"{x:1415,y:776,t:1527030767077};\\\", \\\"{x:1408,y:761,t:1527030767093};\\\", \\\"{x:1401,y:750,t:1527030767110};\\\", \\\"{x:1395,y:740,t:1527030767127};\\\", \\\"{x:1391,y:736,t:1527030767143};\\\", \\\"{x:1388,y:732,t:1527030767159};\\\", \\\"{x:1386,y:731,t:1527030767177};\\\", \\\"{x:1385,y:729,t:1527030767194};\\\", \\\"{x:1384,y:729,t:1527030767290};\\\", \\\"{x:1383,y:729,t:1527030767298};\\\", \\\"{x:1381,y:727,t:1527030767310};\\\", \\\"{x:1375,y:724,t:1527030767328};\\\", \\\"{x:1363,y:717,t:1527030767345};\\\", \\\"{x:1341,y:706,t:1527030767360};\\\", \\\"{x:1316,y:689,t:1527030767377};\\\", \\\"{x:1284,y:674,t:1527030767394};\\\", \\\"{x:1280,y:672,t:1527030767409};\\\", \\\"{x:1276,y:670,t:1527030767426};\\\", \\\"{x:1275,y:670,t:1527030767444};\\\", \\\"{x:1278,y:671,t:1527030767545};\\\", \\\"{x:1281,y:675,t:1527030767560};\\\", \\\"{x:1291,y:685,t:1527030767577};\\\", \\\"{x:1310,y:702,t:1527030767593};\\\", \\\"{x:1327,y:713,t:1527030767611};\\\", \\\"{x:1345,y:721,t:1527030767626};\\\", \\\"{x:1364,y:729,t:1527030767643};\\\", \\\"{x:1382,y:734,t:1527030767661};\\\", \\\"{x:1397,y:739,t:1527030767677};\\\", \\\"{x:1402,y:740,t:1527030767693};\\\", \\\"{x:1404,y:740,t:1527030767711};\\\", \\\"{x:1404,y:739,t:1527030767730};\\\", \\\"{x:1404,y:738,t:1527030767746};\\\", \\\"{x:1404,y:737,t:1527030767761};\\\", \\\"{x:1401,y:732,t:1527030767777};\\\", \\\"{x:1396,y:726,t:1527030767794};\\\", \\\"{x:1393,y:724,t:1527030767811};\\\", \\\"{x:1391,y:723,t:1527030767827};\\\", \\\"{x:1390,y:721,t:1527030767844};\\\", \\\"{x:1386,y:719,t:1527030767861};\\\", \\\"{x:1383,y:716,t:1527030767877};\\\", \\\"{x:1379,y:712,t:1527030767894};\\\", \\\"{x:1369,y:705,t:1527030767911};\\\", \\\"{x:1360,y:698,t:1527030767928};\\\", \\\"{x:1352,y:695,t:1527030767947};\\\", \\\"{x:1348,y:693,t:1527030767960};\\\", \\\"{x:1347,y:692,t:1527030767978};\\\", \\\"{x:1345,y:691,t:1527030767995};\\\", \\\"{x:1344,y:691,t:1527030768017};\\\", \\\"{x:1342,y:691,t:1527030768043};\\\", \\\"{x:1340,y:691,t:1527030768066};\\\", \\\"{x:1340,y:692,t:1527030768082};\\\", \\\"{x:1340,y:693,t:1527030768094};\\\", \\\"{x:1340,y:694,t:1527030768110};\\\", \\\"{x:1340,y:696,t:1527030768129};\\\", \\\"{x:1340,y:698,t:1527030768145};\\\", \\\"{x:1340,y:700,t:1527030768161};\\\", \\\"{x:1340,y:702,t:1527030768177};\\\", \\\"{x:1340,y:703,t:1527030768194};\\\", \\\"{x:1340,y:704,t:1527030768232};\\\", \\\"{x:1340,y:705,t:1527030768249};\\\", \\\"{x:1340,y:707,t:1527030768260};\\\", \\\"{x:1340,y:710,t:1527030768277};\\\", \\\"{x:1340,y:716,t:1527030768294};\\\", \\\"{x:1340,y:723,t:1527030768310};\\\", \\\"{x:1340,y:730,t:1527030768328};\\\", \\\"{x:1340,y:738,t:1527030768345};\\\", \\\"{x:1340,y:743,t:1527030768361};\\\", \\\"{x:1340,y:750,t:1527030768377};\\\", \\\"{x:1340,y:757,t:1527030768395};\\\", \\\"{x:1339,y:762,t:1527030768411};\\\", \\\"{x:1339,y:767,t:1527030768428};\\\", \\\"{x:1339,y:772,t:1527030768445};\\\", \\\"{x:1339,y:777,t:1527030768461};\\\", \\\"{x:1337,y:782,t:1527030768478};\\\", \\\"{x:1337,y:787,t:1527030768495};\\\", \\\"{x:1337,y:791,t:1527030768511};\\\", \\\"{x:1337,y:798,t:1527030768528};\\\", \\\"{x:1337,y:803,t:1527030768545};\\\", \\\"{x:1337,y:810,t:1527030768561};\\\", \\\"{x:1338,y:818,t:1527030768578};\\\", \\\"{x:1340,y:825,t:1527030768595};\\\", \\\"{x:1342,y:828,t:1527030768611};\\\", \\\"{x:1342,y:832,t:1527030768628};\\\", \\\"{x:1344,y:834,t:1527030768645};\\\", \\\"{x:1344,y:836,t:1527030768661};\\\", \\\"{x:1346,y:839,t:1527030768679};\\\", \\\"{x:1347,y:843,t:1527030768695};\\\", \\\"{x:1348,y:845,t:1527030768712};\\\", \\\"{x:1349,y:847,t:1527030768728};\\\", \\\"{x:1352,y:853,t:1527030768745};\\\", \\\"{x:1356,y:859,t:1527030768761};\\\", \\\"{x:1358,y:863,t:1527030768778};\\\", \\\"{x:1359,y:865,t:1527030768795};\\\", \\\"{x:1361,y:869,t:1527030768811};\\\", \\\"{x:1363,y:871,t:1527030768828};\\\", \\\"{x:1364,y:873,t:1527030768846};\\\", \\\"{x:1366,y:877,t:1527030768862};\\\", \\\"{x:1367,y:878,t:1527030768878};\\\", \\\"{x:1368,y:881,t:1527030768895};\\\", \\\"{x:1369,y:883,t:1527030768912};\\\", \\\"{x:1370,y:885,t:1527030768929};\\\", \\\"{x:1371,y:885,t:1527030768945};\\\", \\\"{x:1371,y:886,t:1527030768962};\\\", \\\"{x:1373,y:888,t:1527030768978};\\\", \\\"{x:1373,y:889,t:1527030769001};\\\", \\\"{x:1373,y:891,t:1527030769034};\\\", \\\"{x:1374,y:892,t:1527030769045};\\\", \\\"{x:1374,y:893,t:1527030769074};\\\", \\\"{x:1374,y:894,t:1527030769098};\\\", \\\"{x:1374,y:895,t:1527030769130};\\\", \\\"{x:1374,y:897,t:1527030769162};\\\", \\\"{x:1374,y:898,t:1527030769179};\\\", \\\"{x:1374,y:900,t:1527030769195};\\\", \\\"{x:1374,y:906,t:1527030769212};\\\", \\\"{x:1372,y:910,t:1527030769228};\\\", \\\"{x:1370,y:915,t:1527030769245};\\\", \\\"{x:1368,y:919,t:1527030769262};\\\", \\\"{x:1367,y:922,t:1527030769278};\\\", \\\"{x:1365,y:925,t:1527030769295};\\\", \\\"{x:1363,y:927,t:1527030769312};\\\", \\\"{x:1363,y:928,t:1527030769330};\\\", \\\"{x:1360,y:931,t:1527030769345};\\\", \\\"{x:1359,y:936,t:1527030769362};\\\", \\\"{x:1357,y:939,t:1527030769379};\\\", \\\"{x:1356,y:942,t:1527030769395};\\\", \\\"{x:1353,y:945,t:1527030769412};\\\", \\\"{x:1351,y:949,t:1527030769429};\\\", \\\"{x:1347,y:953,t:1527030769444};\\\", \\\"{x:1343,y:957,t:1527030769461};\\\", \\\"{x:1340,y:961,t:1527030769479};\\\", \\\"{x:1336,y:963,t:1527030769496};\\\", \\\"{x:1333,y:966,t:1527030769512};\\\", \\\"{x:1330,y:969,t:1527030769528};\\\", \\\"{x:1327,y:972,t:1527030769545};\\\", \\\"{x:1325,y:974,t:1527030769561};\\\", \\\"{x:1324,y:974,t:1527030769579};\\\", \\\"{x:1321,y:976,t:1527030769596};\\\", \\\"{x:1319,y:977,t:1527030769611};\\\", \\\"{x:1318,y:978,t:1527030769629};\\\", \\\"{x:1317,y:979,t:1527030769646};\\\", \\\"{x:1316,y:979,t:1527030769661};\\\", \\\"{x:1315,y:979,t:1527030769679};\\\", \\\"{x:1313,y:979,t:1527030769696};\\\", \\\"{x:1311,y:980,t:1527030769712};\\\", \\\"{x:1306,y:980,t:1527030769729};\\\", \\\"{x:1300,y:981,t:1527030769746};\\\", \\\"{x:1294,y:981,t:1527030769762};\\\", \\\"{x:1290,y:982,t:1527030769779};\\\", \\\"{x:1287,y:982,t:1527030769796};\\\", \\\"{x:1284,y:983,t:1527030769812};\\\", \\\"{x:1283,y:983,t:1527030769828};\\\", \\\"{x:1281,y:983,t:1527030769845};\\\", \\\"{x:1280,y:983,t:1527030769862};\\\", \\\"{x:1281,y:980,t:1527030770186};\\\", \\\"{x:1283,y:979,t:1527030770196};\\\", \\\"{x:1286,y:976,t:1527030770213};\\\", \\\"{x:1288,y:975,t:1527030770229};\\\", \\\"{x:1288,y:974,t:1527030770246};\\\", \\\"{x:1289,y:973,t:1527030770263};\\\", \\\"{x:1288,y:972,t:1527030770842};\\\", \\\"{x:1288,y:971,t:1527030770850};\\\", \\\"{x:1287,y:971,t:1527030770874};\\\", \\\"{x:1287,y:970,t:1527030770882};\\\", \\\"{x:1286,y:969,t:1527030770905};\\\", \\\"{x:1286,y:968,t:1527030770914};\\\", \\\"{x:1285,y:967,t:1527030770930};\\\", \\\"{x:1284,y:966,t:1527030770947};\\\", \\\"{x:1282,y:964,t:1527030770963};\\\", \\\"{x:1281,y:964,t:1527030770979};\\\", \\\"{x:1281,y:963,t:1527030770997};\\\", \\\"{x:1278,y:962,t:1527030771013};\\\", \\\"{x:1276,y:962,t:1527030771029};\\\", \\\"{x:1273,y:962,t:1527030771047};\\\", \\\"{x:1272,y:962,t:1527030771062};\\\", \\\"{x:1271,y:962,t:1527030771080};\\\", \\\"{x:1271,y:961,t:1527030771434};\\\", \\\"{x:1272,y:961,t:1527030771450};\\\", \\\"{x:1273,y:961,t:1527030771464};\\\", \\\"{x:1273,y:960,t:1527030771480};\\\", \\\"{x:1274,y:960,t:1527030771497};\\\", \\\"{x:1275,y:959,t:1527030771514};\\\", \\\"{x:1276,y:959,t:1527030771553};\\\", \\\"{x:1276,y:958,t:1527030775880};\\\", \\\"{x:1285,y:953,t:1527030775888};\\\", \\\"{x:1302,y:953,t:1527030775900};\\\", \\\"{x:1328,y:955,t:1527030775917};\\\", \\\"{x:1329,y:955,t:1527030775934};\\\", \\\"{x:1330,y:955,t:1527030775951};\\\", \\\"{x:1333,y:954,t:1527030775968};\\\", \\\"{x:1343,y:948,t:1527030775984};\\\", \\\"{x:1357,y:940,t:1527030776001};\\\", \\\"{x:1365,y:936,t:1527030776018};\\\", \\\"{x:1372,y:933,t:1527030776033};\\\", \\\"{x:1377,y:931,t:1527030776050};\\\", \\\"{x:1383,y:928,t:1527030776067};\\\", \\\"{x:1385,y:926,t:1527030776084};\\\", \\\"{x:1387,y:912,t:1527030776101};\\\", \\\"{x:1387,y:895,t:1527030776118};\\\", \\\"{x:1385,y:880,t:1527030776134};\\\", \\\"{x:1379,y:864,t:1527030776150};\\\", \\\"{x:1371,y:845,t:1527030776168};\\\", \\\"{x:1362,y:828,t:1527030776184};\\\", \\\"{x:1353,y:805,t:1527030776200};\\\", \\\"{x:1345,y:791,t:1527030776218};\\\", \\\"{x:1340,y:782,t:1527030776234};\\\", \\\"{x:1336,y:775,t:1527030776251};\\\", \\\"{x:1333,y:772,t:1527030776268};\\\", \\\"{x:1333,y:770,t:1527030776284};\\\", \\\"{x:1332,y:770,t:1527030776301};\\\", \\\"{x:1331,y:770,t:1527030776345};\\\", \\\"{x:1330,y:770,t:1527030776361};\\\", \\\"{x:1327,y:769,t:1527030776466};\\\", \\\"{x:1324,y:767,t:1527030776474};\\\", \\\"{x:1317,y:766,t:1527030776486};\\\", \\\"{x:1302,y:764,t:1527030776501};\\\", \\\"{x:1286,y:761,t:1527030776518};\\\", \\\"{x:1261,y:759,t:1527030776535};\\\", \\\"{x:1239,y:756,t:1527030776551};\\\", \\\"{x:1222,y:754,t:1527030776568};\\\", \\\"{x:1212,y:751,t:1527030776585};\\\", \\\"{x:1209,y:750,t:1527030776601};\\\", \\\"{x:1208,y:749,t:1527030776713};\\\", \\\"{x:1208,y:747,t:1527030776744};\\\", \\\"{x:1208,y:743,t:1527030776752};\\\", \\\"{x:1208,y:741,t:1527030776768};\\\", \\\"{x:1208,y:740,t:1527030777225};\\\", \\\"{x:1209,y:739,t:1527030777241};\\\", \\\"{x:1212,y:739,t:1527030777251};\\\", \\\"{x:1216,y:738,t:1527030777269};\\\", \\\"{x:1221,y:736,t:1527030777284};\\\", \\\"{x:1223,y:736,t:1527030777301};\\\", \\\"{x:1228,y:733,t:1527030777318};\\\", \\\"{x:1231,y:733,t:1527030777334};\\\", \\\"{x:1233,y:732,t:1527030777351};\\\", \\\"{x:1235,y:731,t:1527030777369};\\\", \\\"{x:1236,y:730,t:1527030777384};\\\", \\\"{x:1238,y:730,t:1527030777401};\\\", \\\"{x:1240,y:729,t:1527030777418};\\\", \\\"{x:1241,y:728,t:1527030777434};\\\", \\\"{x:1244,y:727,t:1527030777452};\\\", \\\"{x:1245,y:727,t:1527030777469};\\\", \\\"{x:1245,y:726,t:1527030777484};\\\", \\\"{x:1247,y:726,t:1527030777504};\\\", \\\"{x:1247,y:724,t:1527030777519};\\\", \\\"{x:1247,y:721,t:1527030777534};\\\", \\\"{x:1247,y:716,t:1527030777551};\\\", \\\"{x:1248,y:708,t:1527030777568};\\\", \\\"{x:1248,y:704,t:1527030777585};\\\", \\\"{x:1249,y:698,t:1527030777601};\\\", \\\"{x:1249,y:695,t:1527030777618};\\\", \\\"{x:1249,y:694,t:1527030777636};\\\", \\\"{x:1249,y:691,t:1527030777652};\\\", \\\"{x:1249,y:688,t:1527030777669};\\\", \\\"{x:1250,y:687,t:1527030777685};\\\", \\\"{x:1250,y:684,t:1527030777702};\\\", \\\"{x:1251,y:682,t:1527030777719};\\\", \\\"{x:1253,y:681,t:1527030777736};\\\", \\\"{x:1256,y:679,t:1527030777752};\\\", \\\"{x:1262,y:676,t:1527030777768};\\\", \\\"{x:1268,y:673,t:1527030777786};\\\", \\\"{x:1273,y:670,t:1527030777801};\\\", \\\"{x:1281,y:665,t:1527030777819};\\\", \\\"{x:1293,y:661,t:1527030777836};\\\", \\\"{x:1301,y:658,t:1527030777852};\\\", \\\"{x:1312,y:653,t:1527030777869};\\\", \\\"{x:1324,y:648,t:1527030777886};\\\", \\\"{x:1331,y:644,t:1527030777902};\\\", \\\"{x:1338,y:642,t:1527030777919};\\\", \\\"{x:1344,y:639,t:1527030777936};\\\", \\\"{x:1347,y:637,t:1527030777952};\\\", \\\"{x:1352,y:636,t:1527030777969};\\\", \\\"{x:1355,y:634,t:1527030777986};\\\", \\\"{x:1357,y:633,t:1527030778002};\\\", \\\"{x:1358,y:632,t:1527030778019};\\\", \\\"{x:1360,y:632,t:1527030778036};\\\", \\\"{x:1360,y:631,t:1527030778057};\\\", \\\"{x:1361,y:630,t:1527030778114};\\\", \\\"{x:1363,y:628,t:1527030778249};\\\", \\\"{x:1369,y:628,t:1527030778257};\\\", \\\"{x:1373,y:628,t:1527030778268};\\\", \\\"{x:1383,y:627,t:1527030778286};\\\", \\\"{x:1393,y:626,t:1527030778303};\\\", \\\"{x:1399,y:626,t:1527030778319};\\\", \\\"{x:1408,y:626,t:1527030778336};\\\", \\\"{x:1418,y:626,t:1527030778353};\\\", \\\"{x:1423,y:627,t:1527030778369};\\\", \\\"{x:1426,y:627,t:1527030778386};\\\", \\\"{x:1428,y:627,t:1527030778403};\\\", \\\"{x:1429,y:628,t:1527030778421};\\\", \\\"{x:1430,y:629,t:1527030778586};\\\", \\\"{x:1430,y:641,t:1527030778603};\\\", \\\"{x:1429,y:660,t:1527030778620};\\\", \\\"{x:1426,y:677,t:1527030778636};\\\", \\\"{x:1423,y:697,t:1527030778652};\\\", \\\"{x:1422,y:712,t:1527030778670};\\\", \\\"{x:1422,y:727,t:1527030778686};\\\", \\\"{x:1422,y:738,t:1527030778702};\\\", \\\"{x:1422,y:748,t:1527030778719};\\\", \\\"{x:1424,y:754,t:1527030778736};\\\", \\\"{x:1425,y:755,t:1527030778753};\\\", \\\"{x:1426,y:755,t:1527030778801};\\\", \\\"{x:1428,y:753,t:1527030778808};\\\", \\\"{x:1431,y:746,t:1527030778820};\\\", \\\"{x:1433,y:731,t:1527030778836};\\\", \\\"{x:1436,y:713,t:1527030778852};\\\", \\\"{x:1441,y:697,t:1527030778870};\\\", \\\"{x:1444,y:683,t:1527030778887};\\\", \\\"{x:1444,y:666,t:1527030778903};\\\", \\\"{x:1444,y:650,t:1527030778920};\\\", \\\"{x:1439,y:633,t:1527030778937};\\\", \\\"{x:1439,y:627,t:1527030778953};\\\", \\\"{x:1437,y:620,t:1527030778970};\\\", \\\"{x:1437,y:618,t:1527030778986};\\\", \\\"{x:1436,y:617,t:1527030779003};\\\", \\\"{x:1437,y:619,t:1527030779122};\\\", \\\"{x:1442,y:627,t:1527030779137};\\\", \\\"{x:1443,y:631,t:1527030779153};\\\", \\\"{x:1444,y:633,t:1527030779169};\\\", \\\"{x:1445,y:634,t:1527030779186};\\\", \\\"{x:1446,y:635,t:1527030779203};\\\", \\\"{x:1446,y:640,t:1527030779761};\\\", \\\"{x:1446,y:647,t:1527030779771};\\\", \\\"{x:1446,y:655,t:1527030779787};\\\", \\\"{x:1446,y:664,t:1527030779803};\\\", \\\"{x:1445,y:673,t:1527030779820};\\\", \\\"{x:1443,y:688,t:1527030779837};\\\", \\\"{x:1442,y:706,t:1527030779854};\\\", \\\"{x:1439,y:724,t:1527030779871};\\\", \\\"{x:1437,y:740,t:1527030779887};\\\", \\\"{x:1434,y:755,t:1527030779904};\\\", \\\"{x:1431,y:779,t:1527030779921};\\\", \\\"{x:1428,y:797,t:1527030779936};\\\", \\\"{x:1426,y:818,t:1527030779954};\\\", \\\"{x:1423,y:836,t:1527030779971};\\\", \\\"{x:1421,y:851,t:1527030779987};\\\", \\\"{x:1419,y:867,t:1527030780004};\\\", \\\"{x:1418,y:878,t:1527030780021};\\\", \\\"{x:1415,y:892,t:1527030780038};\\\", \\\"{x:1413,y:904,t:1527030780054};\\\", \\\"{x:1413,y:915,t:1527030780071};\\\", \\\"{x:1413,y:923,t:1527030780087};\\\", \\\"{x:1412,y:930,t:1527030780104};\\\", \\\"{x:1412,y:933,t:1527030780120};\\\", \\\"{x:1411,y:933,t:1527030780264};\\\", \\\"{x:1411,y:930,t:1527030780272};\\\", \\\"{x:1411,y:929,t:1527030780287};\\\", \\\"{x:1410,y:926,t:1527030780303};\\\", \\\"{x:1410,y:924,t:1527030780320};\\\", \\\"{x:1410,y:923,t:1527030780657};\\\", \\\"{x:1410,y:920,t:1527030780671};\\\", \\\"{x:1410,y:917,t:1527030780688};\\\", \\\"{x:1411,y:913,t:1527030780705};\\\", \\\"{x:1413,y:910,t:1527030780721};\\\", \\\"{x:1414,y:907,t:1527030780738};\\\", \\\"{x:1416,y:904,t:1527030780755};\\\", \\\"{x:1417,y:902,t:1527030780770};\\\", \\\"{x:1417,y:901,t:1527030780792};\\\", \\\"{x:1419,y:898,t:1527030780805};\\\", \\\"{x:1420,y:897,t:1527030780821};\\\", \\\"{x:1421,y:895,t:1527030780838};\\\", \\\"{x:1422,y:893,t:1527030780855};\\\", \\\"{x:1423,y:892,t:1527030780872};\\\", \\\"{x:1424,y:890,t:1527030780887};\\\", \\\"{x:1425,y:889,t:1527030780905};\\\", \\\"{x:1426,y:888,t:1527030780922};\\\", \\\"{x:1427,y:888,t:1527030780938};\\\", \\\"{x:1427,y:887,t:1527030780954};\\\", \\\"{x:1428,y:886,t:1527030780972};\\\", \\\"{x:1430,y:886,t:1527030781056};\\\", \\\"{x:1433,y:888,t:1527030781072};\\\", \\\"{x:1440,y:893,t:1527030781088};\\\", \\\"{x:1443,y:896,t:1527030781105};\\\", \\\"{x:1445,y:898,t:1527030781122};\\\", \\\"{x:1446,y:898,t:1527030781138};\\\", \\\"{x:1446,y:899,t:1527030781313};\\\", \\\"{x:1447,y:900,t:1527030781328};\\\", \\\"{x:1448,y:900,t:1527030781377};\\\", \\\"{x:1449,y:900,t:1527030781569};\\\", \\\"{x:1449,y:899,t:1527030781584};\\\", \\\"{x:1450,y:898,t:1527030781608};\\\", \\\"{x:1450,y:896,t:1527030781632};\\\", \\\"{x:1451,y:895,t:1527030781656};\\\", \\\"{x:1448,y:895,t:1527030781872};\\\", \\\"{x:1447,y:895,t:1527030781913};\\\", \\\"{x:1446,y:895,t:1527030781969};\\\", \\\"{x:1445,y:896,t:1527030782000};\\\", \\\"{x:1445,y:897,t:1527030787621};\\\", \\\"{x:1444,y:898,t:1527030787632};\\\", \\\"{x:1441,y:899,t:1527030787649};\\\", \\\"{x:1433,y:899,t:1527030787664};\\\", \\\"{x:1427,y:900,t:1527030787681};\\\", \\\"{x:1422,y:902,t:1527030787698};\\\", \\\"{x:1414,y:903,t:1527030787714};\\\", \\\"{x:1409,y:903,t:1527030787731};\\\", \\\"{x:1403,y:904,t:1527030787748};\\\", \\\"{x:1396,y:906,t:1527030787764};\\\", \\\"{x:1393,y:906,t:1527030787782};\\\", \\\"{x:1389,y:906,t:1527030787799};\\\", \\\"{x:1387,y:906,t:1527030787814};\\\", \\\"{x:1385,y:907,t:1527030787832};\\\", \\\"{x:1382,y:907,t:1527030787849};\\\", \\\"{x:1381,y:908,t:1527030787866};\\\", \\\"{x:1379,y:908,t:1527030787882};\\\", \\\"{x:1378,y:908,t:1527030787899};\\\", \\\"{x:1374,y:909,t:1527030787916};\\\", \\\"{x:1372,y:910,t:1527030787933};\\\", \\\"{x:1370,y:909,t:1527030789686};\\\", \\\"{x:1368,y:905,t:1527030789700};\\\", \\\"{x:1367,y:901,t:1527030789717};\\\", \\\"{x:1366,y:895,t:1527030789733};\\\", \\\"{x:1365,y:891,t:1527030789750};\\\", \\\"{x:1364,y:890,t:1527030789767};\\\", \\\"{x:1364,y:889,t:1527030789789};\\\", \\\"{x:1364,y:888,t:1527030789805};\\\", \\\"{x:1364,y:885,t:1527030790110};\\\", \\\"{x:1365,y:885,t:1527030790182};\\\", \\\"{x:1366,y:885,t:1527030790198};\\\", \\\"{x:1367,y:885,t:1527030790253};\\\", \\\"{x:1368,y:886,t:1527030790278};\\\", \\\"{x:1369,y:886,t:1527030790303};\\\", \\\"{x:1371,y:887,t:1527030790318};\\\", \\\"{x:1371,y:888,t:1527030790334};\\\", \\\"{x:1372,y:889,t:1527030790351};\\\", \\\"{x:1373,y:890,t:1527030790368};\\\", \\\"{x:1374,y:890,t:1527030790389};\\\", \\\"{x:1376,y:891,t:1527030790401};\\\", \\\"{x:1377,y:892,t:1527030790422};\\\", \\\"{x:1378,y:893,t:1527030790433};\\\", \\\"{x:1379,y:893,t:1527030790451};\\\", \\\"{x:1379,y:894,t:1527030790477};\\\", \\\"{x:1380,y:894,t:1527030791182};\\\", \\\"{x:1381,y:895,t:1527030791205};\\\", \\\"{x:1381,y:896,t:1527030791892};\\\", \\\"{x:1380,y:897,t:1527030791901};\\\", \\\"{x:1379,y:897,t:1527030791924};\\\", \\\"{x:1378,y:897,t:1527030791965};\\\", \\\"{x:1375,y:889,t:1527030794767};\\\", \\\"{x:1369,y:874,t:1527030794773};\\\", \\\"{x:1365,y:864,t:1527030794788};\\\", \\\"{x:1364,y:841,t:1527030794805};\\\", \\\"{x:1362,y:827,t:1527030794821};\\\", \\\"{x:1362,y:821,t:1527030794838};\\\", \\\"{x:1361,y:815,t:1527030794854};\\\", \\\"{x:1361,y:813,t:1527030794871};\\\", \\\"{x:1361,y:812,t:1527030794888};\\\", \\\"{x:1361,y:811,t:1527030794904};\\\", \\\"{x:1364,y:811,t:1527030794920};\\\", \\\"{x:1367,y:809,t:1527030794938};\\\", \\\"{x:1375,y:809,t:1527030794955};\\\", \\\"{x:1386,y:809,t:1527030794970};\\\", \\\"{x:1402,y:812,t:1527030794987};\\\", \\\"{x:1418,y:816,t:1527030795004};\\\", \\\"{x:1422,y:819,t:1527030795021};\\\", \\\"{x:1423,y:819,t:1527030795038};\\\", \\\"{x:1424,y:819,t:1527030795198};\\\", \\\"{x:1424,y:818,t:1527030795212};\\\", \\\"{x:1424,y:817,t:1527030795221};\\\", \\\"{x:1424,y:816,t:1527030795252};\\\", \\\"{x:1424,y:815,t:1527030795276};\\\", \\\"{x:1425,y:813,t:1527030795300};\\\", \\\"{x:1426,y:813,t:1527030795316};\\\", \\\"{x:1427,y:813,t:1527030795340};\\\", \\\"{x:1428,y:813,t:1527030795354};\\\", \\\"{x:1431,y:813,t:1527030795372};\\\", \\\"{x:1433,y:813,t:1527030795388};\\\", \\\"{x:1438,y:813,t:1527030795404};\\\", \\\"{x:1443,y:813,t:1527030795421};\\\", \\\"{x:1457,y:817,t:1527030795437};\\\", \\\"{x:1469,y:820,t:1527030795455};\\\", \\\"{x:1484,y:825,t:1527030795472};\\\", \\\"{x:1493,y:827,t:1527030795489};\\\", \\\"{x:1494,y:828,t:1527030795652};\\\", \\\"{x:1493,y:828,t:1527030795676};\\\", \\\"{x:1490,y:828,t:1527030795689};\\\", \\\"{x:1488,y:828,t:1527030795704};\\\", \\\"{x:1485,y:828,t:1527030795722};\\\", \\\"{x:1482,y:827,t:1527030795738};\\\", \\\"{x:1479,y:825,t:1527030795754};\\\", \\\"{x:1472,y:824,t:1527030795772};\\\", \\\"{x:1459,y:824,t:1527030795788};\\\", \\\"{x:1450,y:823,t:1527030795804};\\\", \\\"{x:1449,y:822,t:1527030795822};\\\", \\\"{x:1446,y:822,t:1527030795838};\\\", \\\"{x:1441,y:822,t:1527030795855};\\\", \\\"{x:1434,y:822,t:1527030795871};\\\", \\\"{x:1426,y:822,t:1527030795889};\\\", \\\"{x:1423,y:822,t:1527030795905};\\\", \\\"{x:1422,y:822,t:1527030795922};\\\", \\\"{x:1417,y:822,t:1527030795939};\\\", \\\"{x:1412,y:822,t:1527030795956};\\\", \\\"{x:1407,y:822,t:1527030795973};\\\", \\\"{x:1396,y:822,t:1527030795988};\\\", \\\"{x:1392,y:822,t:1527030796005};\\\", \\\"{x:1385,y:820,t:1527030796022};\\\", \\\"{x:1379,y:818,t:1527030796039};\\\", \\\"{x:1373,y:816,t:1527030796056};\\\", \\\"{x:1366,y:811,t:1527030796072};\\\", \\\"{x:1359,y:806,t:1527030796089};\\\", \\\"{x:1351,y:797,t:1527030796106};\\\", \\\"{x:1341,y:783,t:1527030796122};\\\", \\\"{x:1328,y:768,t:1527030796139};\\\", \\\"{x:1320,y:753,t:1527030796156};\\\", \\\"{x:1310,y:741,t:1527030796172};\\\", \\\"{x:1302,y:727,t:1527030796189};\\\", \\\"{x:1298,y:721,t:1527030796206};\\\", \\\"{x:1297,y:719,t:1527030796222};\\\", \\\"{x:1297,y:714,t:1527030796239};\\\", \\\"{x:1296,y:710,t:1527030796256};\\\", \\\"{x:1296,y:706,t:1527030796272};\\\", \\\"{x:1295,y:706,t:1527030796289};\\\", \\\"{x:1295,y:705,t:1527030796317};\\\", \\\"{x:1295,y:704,t:1527030796326};\\\", \\\"{x:1295,y:703,t:1527030796341};\\\", \\\"{x:1296,y:703,t:1527030796356};\\\", \\\"{x:1298,y:702,t:1527030796373};\\\", \\\"{x:1304,y:700,t:1527030796389};\\\", \\\"{x:1307,y:699,t:1527030796406};\\\", \\\"{x:1309,y:698,t:1527030796423};\\\", \\\"{x:1312,y:697,t:1527030796439};\\\", \\\"{x:1313,y:696,t:1527030796457};\\\", \\\"{x:1315,y:696,t:1527030796473};\\\", \\\"{x:1317,y:695,t:1527030796490};\\\", \\\"{x:1319,y:695,t:1527030796733};\\\", \\\"{x:1322,y:698,t:1527030796740};\\\", \\\"{x:1323,y:701,t:1527030796756};\\\", \\\"{x:1326,y:704,t:1527030796773};\\\", \\\"{x:1327,y:708,t:1527030796789};\\\", \\\"{x:1329,y:709,t:1527030796806};\\\", \\\"{x:1330,y:710,t:1527030796823};\\\", \\\"{x:1331,y:711,t:1527030796840};\\\", \\\"{x:1332,y:711,t:1527030796933};\\\", \\\"{x:1333,y:711,t:1527030796941};\\\", \\\"{x:1335,y:711,t:1527030796956};\\\", \\\"{x:1337,y:707,t:1527030796973};\\\", \\\"{x:1340,y:703,t:1527030796990};\\\", \\\"{x:1343,y:699,t:1527030797006};\\\", \\\"{x:1343,y:697,t:1527030797023};\\\", \\\"{x:1344,y:697,t:1527030797040};\\\", \\\"{x:1344,y:696,t:1527030797056};\\\", \\\"{x:1347,y:696,t:1527030799317};\\\", \\\"{x:1356,y:704,t:1527030799326};\\\", \\\"{x:1379,y:726,t:1527030799342};\\\", \\\"{x:1396,y:742,t:1527030799358};\\\", \\\"{x:1412,y:755,t:1527030799375};\\\", \\\"{x:1439,y:775,t:1527030799392};\\\", \\\"{x:1469,y:793,t:1527030799408};\\\", \\\"{x:1493,y:810,t:1527030799425};\\\", \\\"{x:1509,y:817,t:1527030799442};\\\", \\\"{x:1519,y:825,t:1527030799459};\\\", \\\"{x:1528,y:832,t:1527030799475};\\\", \\\"{x:1543,y:843,t:1527030799493};\\\", \\\"{x:1556,y:855,t:1527030799508};\\\", \\\"{x:1569,y:872,t:1527030799525};\\\", \\\"{x:1575,y:879,t:1527030799542};\\\", \\\"{x:1581,y:886,t:1527030799558};\\\", \\\"{x:1585,y:893,t:1527030799575};\\\", \\\"{x:1589,y:899,t:1527030799592};\\\", \\\"{x:1595,y:911,t:1527030799609};\\\", \\\"{x:1605,y:925,t:1527030799625};\\\", \\\"{x:1611,y:937,t:1527030799642};\\\", \\\"{x:1615,y:947,t:1527030799660};\\\", \\\"{x:1617,y:956,t:1527030799675};\\\", \\\"{x:1619,y:962,t:1527030799693};\\\", \\\"{x:1620,y:967,t:1527030799709};\\\", \\\"{x:1617,y:965,t:1527030799926};\\\", \\\"{x:1611,y:954,t:1527030799943};\\\", \\\"{x:1608,y:948,t:1527030799960};\\\", \\\"{x:1602,y:939,t:1527030799975};\\\", \\\"{x:1595,y:930,t:1527030799992};\\\", \\\"{x:1586,y:921,t:1527030800009};\\\", \\\"{x:1579,y:912,t:1527030800026};\\\", \\\"{x:1572,y:903,t:1527030800043};\\\", \\\"{x:1568,y:898,t:1527030800060};\\\", \\\"{x:1563,y:891,t:1527030800076};\\\", \\\"{x:1558,y:885,t:1527030800092};\\\", \\\"{x:1544,y:872,t:1527030800109};\\\", \\\"{x:1535,y:865,t:1527030800126};\\\", \\\"{x:1529,y:860,t:1527030800142};\\\", \\\"{x:1526,y:858,t:1527030800159};\\\", \\\"{x:1524,y:857,t:1527030800177};\\\", \\\"{x:1520,y:854,t:1527030800192};\\\", \\\"{x:1518,y:853,t:1527030800210};\\\", \\\"{x:1515,y:851,t:1527030800226};\\\", \\\"{x:1513,y:850,t:1527030800242};\\\", \\\"{x:1511,y:848,t:1527030800260};\\\", \\\"{x:1510,y:848,t:1527030800276};\\\", \\\"{x:1509,y:847,t:1527030800292};\\\", \\\"{x:1505,y:845,t:1527030800309};\\\", \\\"{x:1504,y:845,t:1527030800327};\\\", \\\"{x:1502,y:845,t:1527030800342};\\\", \\\"{x:1501,y:844,t:1527030800359};\\\", \\\"{x:1497,y:844,t:1527030800376};\\\", \\\"{x:1496,y:843,t:1527030800393};\\\", \\\"{x:1494,y:843,t:1527030800409};\\\", \\\"{x:1493,y:843,t:1527030800426};\\\", \\\"{x:1491,y:842,t:1527030800444};\\\", \\\"{x:1489,y:841,t:1527030800459};\\\", \\\"{x:1487,y:840,t:1527030800476};\\\", \\\"{x:1486,y:839,t:1527030800494};\\\", \\\"{x:1486,y:838,t:1527030800509};\\\", \\\"{x:1485,y:838,t:1527030800533};\\\", \\\"{x:1483,y:837,t:1527030800813};\\\", \\\"{x:1481,y:836,t:1527030800837};\\\", \\\"{x:1480,y:834,t:1527030801158};\\\", \\\"{x:1479,y:832,t:1527030801176};\\\", \\\"{x:1478,y:831,t:1527030801196};\\\", \\\"{x:1478,y:830,t:1527030801212};\\\", \\\"{x:1477,y:830,t:1527030801244};\\\", \\\"{x:1477,y:829,t:1527030802108};\\\", \\\"{x:1478,y:828,t:1527030802124};\\\", \\\"{x:1479,y:827,t:1527030802148};\\\", \\\"{x:1480,y:827,t:1527030802164};\\\", \\\"{x:1481,y:826,t:1527030802180};\\\", \\\"{x:1482,y:825,t:1527030802212};\\\", \\\"{x:1483,y:825,t:1527030802236};\\\", \\\"{x:1484,y:825,t:1527030802260};\\\", \\\"{x:1486,y:824,t:1527030802277};\\\", \\\"{x:1488,y:823,t:1527030802294};\\\", \\\"{x:1490,y:822,t:1527030802311};\\\", \\\"{x:1491,y:822,t:1527030802327};\\\", \\\"{x:1492,y:822,t:1527030802344};\\\", \\\"{x:1493,y:821,t:1527030802360};\\\", \\\"{x:1494,y:821,t:1527030802377};\\\", \\\"{x:1495,y:821,t:1527030802394};\\\", \\\"{x:1498,y:821,t:1527030802411};\\\", \\\"{x:1503,y:821,t:1527030802428};\\\", \\\"{x:1506,y:822,t:1527030802444};\\\", \\\"{x:1514,y:824,t:1527030802460};\\\", \\\"{x:1519,y:828,t:1527030802477};\\\", \\\"{x:1525,y:830,t:1527030802494};\\\", \\\"{x:1531,y:831,t:1527030802511};\\\", \\\"{x:1536,y:834,t:1527030802528};\\\", \\\"{x:1540,y:835,t:1527030802544};\\\", \\\"{x:1543,y:836,t:1527030802561};\\\", \\\"{x:1544,y:837,t:1527030802581};\\\", \\\"{x:1541,y:837,t:1527030802902};\\\", \\\"{x:1539,y:837,t:1527030802912};\\\", \\\"{x:1532,y:834,t:1527030802928};\\\", \\\"{x:1520,y:833,t:1527030802946};\\\", \\\"{x:1508,y:832,t:1527030802961};\\\", \\\"{x:1494,y:831,t:1527030802979};\\\", \\\"{x:1482,y:831,t:1527030802995};\\\", \\\"{x:1474,y:831,t:1527030803011};\\\", \\\"{x:1465,y:831,t:1527030803027};\\\", \\\"{x:1455,y:831,t:1527030803044};\\\", \\\"{x:1452,y:831,t:1527030803060};\\\", \\\"{x:1450,y:831,t:1527030803078};\\\", \\\"{x:1449,y:831,t:1527030803157};\\\", \\\"{x:1448,y:831,t:1527030803181};\\\", \\\"{x:1449,y:831,t:1527030803389};\\\", \\\"{x:1449,y:830,t:1527030803398};\\\", \\\"{x:1451,y:830,t:1527030803412};\\\", \\\"{x:1453,y:830,t:1527030803428};\\\", \\\"{x:1460,y:829,t:1527030803446};\\\", \\\"{x:1463,y:829,t:1527030803462};\\\", \\\"{x:1466,y:829,t:1527030803478};\\\", \\\"{x:1470,y:829,t:1527030803495};\\\", \\\"{x:1473,y:829,t:1527030803512};\\\", \\\"{x:1478,y:829,t:1527030803529};\\\", \\\"{x:1480,y:829,t:1527030803545};\\\", \\\"{x:1482,y:829,t:1527030803563};\\\", \\\"{x:1483,y:828,t:1527030803578};\\\", \\\"{x:1481,y:828,t:1527030804381};\\\", \\\"{x:1480,y:828,t:1527030804396};\\\", \\\"{x:1477,y:828,t:1527030804413};\\\", \\\"{x:1475,y:828,t:1527030804430};\\\", \\\"{x:1473,y:828,t:1527030806022};\\\", \\\"{x:1469,y:828,t:1527030806030};\\\", \\\"{x:1460,y:828,t:1527030806047};\\\", \\\"{x:1446,y:828,t:1527030806064};\\\", \\\"{x:1430,y:826,t:1527030806081};\\\", \\\"{x:1413,y:823,t:1527030806097};\\\", \\\"{x:1399,y:819,t:1527030806115};\\\", \\\"{x:1394,y:817,t:1527030806131};\\\", \\\"{x:1388,y:815,t:1527030806147};\\\", \\\"{x:1387,y:815,t:1527030806164};\\\", \\\"{x:1383,y:812,t:1527030806181};\\\", \\\"{x:1381,y:810,t:1527030806198};\\\", \\\"{x:1379,y:809,t:1527030806214};\\\", \\\"{x:1377,y:807,t:1527030806231};\\\", \\\"{x:1374,y:803,t:1527030806248};\\\", \\\"{x:1371,y:798,t:1527030806265};\\\", \\\"{x:1368,y:792,t:1527030806282};\\\", \\\"{x:1362,y:787,t:1527030806298};\\\", \\\"{x:1358,y:782,t:1527030806314};\\\", \\\"{x:1357,y:780,t:1527030806331};\\\", \\\"{x:1355,y:778,t:1527030806347};\\\", \\\"{x:1355,y:777,t:1527030806365};\\\", \\\"{x:1355,y:773,t:1527030806381};\\\", \\\"{x:1353,y:769,t:1527030806397};\\\", \\\"{x:1351,y:762,t:1527030806415};\\\", \\\"{x:1351,y:757,t:1527030806432};\\\", \\\"{x:1350,y:753,t:1527030806448};\\\", \\\"{x:1350,y:746,t:1527030806464};\\\", \\\"{x:1350,y:740,t:1527030806482};\\\", \\\"{x:1350,y:734,t:1527030806498};\\\", \\\"{x:1350,y:729,t:1527030806515};\\\", \\\"{x:1352,y:720,t:1527030806531};\\\", \\\"{x:1356,y:706,t:1527030806548};\\\", \\\"{x:1357,y:698,t:1527030806564};\\\", \\\"{x:1360,y:690,t:1527030806581};\\\", \\\"{x:1361,y:683,t:1527030806597};\\\", \\\"{x:1362,y:679,t:1527030806613};\\\", \\\"{x:1363,y:678,t:1527030806630};\\\", \\\"{x:1363,y:677,t:1527030806647};\\\", \\\"{x:1362,y:679,t:1527030806749};\\\", \\\"{x:1359,y:689,t:1527030806764};\\\", \\\"{x:1358,y:701,t:1527030806781};\\\", \\\"{x:1355,y:713,t:1527030806798};\\\", \\\"{x:1355,y:719,t:1527030806814};\\\", \\\"{x:1355,y:722,t:1527030806831};\\\", \\\"{x:1355,y:724,t:1527030806848};\\\", \\\"{x:1354,y:723,t:1527030807022};\\\", \\\"{x:1352,y:721,t:1527030807032};\\\", \\\"{x:1351,y:716,t:1527030807048};\\\", \\\"{x:1351,y:712,t:1527030807066};\\\", \\\"{x:1350,y:712,t:1527030807081};\\\", \\\"{x:1349,y:710,t:1527030807099};\\\", \\\"{x:1349,y:709,t:1527030807115};\\\", \\\"{x:1349,y:708,t:1527030807131};\\\", \\\"{x:1348,y:707,t:1527030807148};\\\", \\\"{x:1348,y:705,t:1527030807165};\\\", \\\"{x:1348,y:704,t:1527030807181};\\\", \\\"{x:1348,y:703,t:1527030807198};\\\", \\\"{x:1348,y:702,t:1527030807216};\\\", \\\"{x:1348,y:701,t:1527030807405};\\\", \\\"{x:1348,y:700,t:1527030807421};\\\", \\\"{x:1347,y:699,t:1527030807432};\\\", \\\"{x:1346,y:700,t:1527030807486};\\\", \\\"{x:1345,y:707,t:1527030807499};\\\", \\\"{x:1343,y:724,t:1527030807516};\\\", \\\"{x:1341,y:749,t:1527030807533};\\\", \\\"{x:1340,y:759,t:1527030807549};\\\", \\\"{x:1340,y:763,t:1527030807566};\\\", \\\"{x:1340,y:766,t:1527030807583};\\\", \\\"{x:1341,y:766,t:1527030807862};\\\", \\\"{x:1341,y:765,t:1527030807877};\\\", \\\"{x:1342,y:764,t:1527030808526};\\\", \\\"{x:1343,y:763,t:1527030808533};\\\", \\\"{x:1344,y:763,t:1527030808549};\\\", \\\"{x:1344,y:762,t:1527030808566};\\\", \\\"{x:1344,y:763,t:1527030809636};\\\", \\\"{x:1344,y:765,t:1527030809650};\\\", \\\"{x:1344,y:768,t:1527030809669};\\\", \\\"{x:1344,y:772,t:1527030809684};\\\", \\\"{x:1344,y:777,t:1527030809701};\\\", \\\"{x:1344,y:782,t:1527030809717};\\\", \\\"{x:1344,y:785,t:1527030809734};\\\", \\\"{x:1344,y:788,t:1527030809751};\\\", \\\"{x:1346,y:790,t:1527030809767};\\\", \\\"{x:1347,y:793,t:1527030809784};\\\", \\\"{x:1348,y:797,t:1527030809800};\\\", \\\"{x:1352,y:801,t:1527030809818};\\\", \\\"{x:1359,y:810,t:1527030809835};\\\", \\\"{x:1368,y:817,t:1527030809850};\\\", \\\"{x:1379,y:826,t:1527030809867};\\\", \\\"{x:1395,y:841,t:1527030809884};\\\", \\\"{x:1409,y:854,t:1527030809900};\\\", \\\"{x:1432,y:873,t:1527030809917};\\\", \\\"{x:1457,y:899,t:1527030809934};\\\", \\\"{x:1474,y:920,t:1527030809950};\\\", \\\"{x:1485,y:933,t:1527030809967};\\\", \\\"{x:1489,y:941,t:1527030809984};\\\", \\\"{x:1491,y:942,t:1527030810000};\\\", \\\"{x:1491,y:943,t:1527030810017};\\\", \\\"{x:1489,y:943,t:1527030810157};\\\", \\\"{x:1487,y:943,t:1527030810168};\\\", \\\"{x:1479,y:939,t:1527030810184};\\\", \\\"{x:1469,y:933,t:1527030810201};\\\", \\\"{x:1458,y:926,t:1527030810218};\\\", \\\"{x:1452,y:921,t:1527030810235};\\\", \\\"{x:1448,y:918,t:1527030810251};\\\", \\\"{x:1443,y:914,t:1527030810268};\\\", \\\"{x:1435,y:908,t:1527030810285};\\\", \\\"{x:1423,y:900,t:1527030810301};\\\", \\\"{x:1418,y:899,t:1527030810318};\\\", \\\"{x:1413,y:897,t:1527030810334};\\\", \\\"{x:1411,y:897,t:1527030810352};\\\", \\\"{x:1409,y:896,t:1527030810368};\\\", \\\"{x:1408,y:896,t:1527030810385};\\\", \\\"{x:1407,y:896,t:1527030810401};\\\", \\\"{x:1404,y:896,t:1527030810417};\\\", \\\"{x:1403,y:896,t:1527030810434};\\\", \\\"{x:1401,y:896,t:1527030810452};\\\", \\\"{x:1400,y:896,t:1527030810467};\\\", \\\"{x:1397,y:899,t:1527030810485};\\\", \\\"{x:1395,y:901,t:1527030810501};\\\", \\\"{x:1394,y:903,t:1527030810518};\\\", \\\"{x:1393,y:903,t:1527030810534};\\\", \\\"{x:1392,y:903,t:1527030810552};\\\", \\\"{x:1391,y:904,t:1527030810569};\\\", \\\"{x:1390,y:904,t:1527030810957};\\\", \\\"{x:1388,y:903,t:1527030810969};\\\", \\\"{x:1381,y:900,t:1527030810985};\\\", \\\"{x:1377,y:897,t:1527030811002};\\\", \\\"{x:1371,y:893,t:1527030811020};\\\", \\\"{x:1367,y:890,t:1527030811036};\\\", \\\"{x:1364,y:889,t:1527030811051};\\\", \\\"{x:1359,y:886,t:1527030811068};\\\", \\\"{x:1356,y:884,t:1527030811085};\\\", \\\"{x:1355,y:884,t:1527030811101};\\\", \\\"{x:1355,y:883,t:1527030811119};\\\", \\\"{x:1354,y:883,t:1527030811174};\\\", \\\"{x:1353,y:882,t:1527030811196};\\\", \\\"{x:1353,y:881,t:1527030811220};\\\", \\\"{x:1352,y:881,t:1527030811236};\\\", \\\"{x:1352,y:880,t:1527030811251};\\\", \\\"{x:1351,y:880,t:1527030811268};\\\", \\\"{x:1351,y:879,t:1527030811285};\\\", \\\"{x:1351,y:878,t:1527030811301};\\\", \\\"{x:1350,y:877,t:1527030811318};\\\", \\\"{x:1350,y:873,t:1527030811335};\\\", \\\"{x:1348,y:870,t:1527030811352};\\\", \\\"{x:1346,y:866,t:1527030811368};\\\", \\\"{x:1344,y:861,t:1527030811385};\\\", \\\"{x:1342,y:858,t:1527030811403};\\\", \\\"{x:1338,y:854,t:1527030811418};\\\", \\\"{x:1334,y:851,t:1527030811435};\\\", \\\"{x:1320,y:843,t:1527030811452};\\\", \\\"{x:1313,y:840,t:1527030811469};\\\", \\\"{x:1308,y:838,t:1527030811485};\\\", \\\"{x:1303,y:837,t:1527030811502};\\\", \\\"{x:1301,y:836,t:1527030811518};\\\", \\\"{x:1300,y:836,t:1527030811536};\\\", \\\"{x:1298,y:835,t:1527030811553};\\\", \\\"{x:1297,y:835,t:1527030811568};\\\", \\\"{x:1295,y:835,t:1527030811585};\\\", \\\"{x:1294,y:835,t:1527030811602};\\\", \\\"{x:1292,y:835,t:1527030811618};\\\", \\\"{x:1291,y:835,t:1527030811636};\\\", \\\"{x:1288,y:835,t:1527030811652};\\\", \\\"{x:1284,y:835,t:1527030811668};\\\", \\\"{x:1278,y:836,t:1527030811686};\\\", \\\"{x:1272,y:836,t:1527030811703};\\\", \\\"{x:1266,y:836,t:1527030811719};\\\", \\\"{x:1262,y:836,t:1527030811736};\\\", \\\"{x:1258,y:837,t:1527030811753};\\\", \\\"{x:1255,y:837,t:1527030811770};\\\", \\\"{x:1253,y:837,t:1527030811786};\\\", \\\"{x:1251,y:837,t:1527030811806};\\\", \\\"{x:1250,y:837,t:1527030811828};\\\", \\\"{x:1249,y:837,t:1527030811852};\\\", \\\"{x:1248,y:838,t:1527030811875};\\\", \\\"{x:1247,y:838,t:1527030811924};\\\", \\\"{x:1246,y:838,t:1527030811940};\\\", \\\"{x:1245,y:838,t:1527030811972};\\\", \\\"{x:1244,y:838,t:1527030811985};\\\", \\\"{x:1243,y:838,t:1527030812002};\\\", \\\"{x:1242,y:838,t:1527030812019};\\\", \\\"{x:1241,y:838,t:1527030812035};\\\", \\\"{x:1240,y:838,t:1527030812437};\\\", \\\"{x:1237,y:838,t:1527030812453};\\\", \\\"{x:1234,y:838,t:1527030812469};\\\", \\\"{x:1230,y:838,t:1527030812486};\\\", \\\"{x:1225,y:838,t:1527030812502};\\\", \\\"{x:1221,y:838,t:1527030812520};\\\", \\\"{x:1218,y:837,t:1527030812537};\\\", \\\"{x:1217,y:837,t:1527030812554};\\\", \\\"{x:1215,y:836,t:1527030812570};\\\", \\\"{x:1213,y:836,t:1527030812586};\\\", \\\"{x:1213,y:835,t:1527030812603};\\\", \\\"{x:1212,y:835,t:1527030812619};\\\", \\\"{x:1210,y:835,t:1527030812773};\\\", \\\"{x:1209,y:835,t:1527030812804};\\\", \\\"{x:1207,y:835,t:1527030812821};\\\", \\\"{x:1206,y:835,t:1527030812837};\\\", \\\"{x:1204,y:835,t:1527030812853};\\\", \\\"{x:1203,y:835,t:1527030812877};\\\", \\\"{x:1201,y:835,t:1527030812893};\\\", \\\"{x:1200,y:835,t:1527030812932};\\\", \\\"{x:1198,y:834,t:1527030813484};\\\", \\\"{x:1195,y:832,t:1527030813492};\\\", \\\"{x:1193,y:832,t:1527030813503};\\\", \\\"{x:1188,y:829,t:1527030813520};\\\", \\\"{x:1184,y:826,t:1527030813538};\\\", \\\"{x:1177,y:822,t:1527030813553};\\\", \\\"{x:1175,y:820,t:1527030813570};\\\", \\\"{x:1174,y:819,t:1527030813588};\\\", \\\"{x:1174,y:818,t:1527030813603};\\\", \\\"{x:1173,y:814,t:1527030813621};\\\", \\\"{x:1170,y:810,t:1527030813637};\\\", \\\"{x:1169,y:806,t:1527030813653};\\\", \\\"{x:1169,y:803,t:1527030813670};\\\", \\\"{x:1168,y:800,t:1527030813686};\\\", \\\"{x:1167,y:797,t:1527030813704};\\\", \\\"{x:1167,y:796,t:1527030813720};\\\", \\\"{x:1167,y:793,t:1527030813737};\\\", \\\"{x:1166,y:792,t:1527030813753};\\\", \\\"{x:1166,y:790,t:1527030813770};\\\", \\\"{x:1166,y:789,t:1527030813787};\\\", \\\"{x:1166,y:788,t:1527030813804};\\\", \\\"{x:1165,y:787,t:1527030813820};\\\", \\\"{x:1165,y:786,t:1527030813844};\\\", \\\"{x:1163,y:785,t:1527030813884};\\\", \\\"{x:1162,y:785,t:1527030813932};\\\", \\\"{x:1162,y:784,t:1527030813940};\\\", \\\"{x:1161,y:784,t:1527030813955};\\\", \\\"{x:1160,y:784,t:1527030813970};\\\", \\\"{x:1159,y:784,t:1527030813987};\\\", \\\"{x:1155,y:784,t:1527030814003};\\\", \\\"{x:1150,y:782,t:1527030814020};\\\", \\\"{x:1142,y:780,t:1527030814037};\\\", \\\"{x:1135,y:779,t:1527030814054};\\\", \\\"{x:1128,y:776,t:1527030814070};\\\", \\\"{x:1121,y:775,t:1527030814087};\\\", \\\"{x:1115,y:774,t:1527030814104};\\\", \\\"{x:1109,y:771,t:1527030814120};\\\", \\\"{x:1104,y:771,t:1527030814138};\\\", \\\"{x:1098,y:771,t:1527030814154};\\\", \\\"{x:1095,y:770,t:1527030814170};\\\", \\\"{x:1090,y:770,t:1527030814187};\\\", \\\"{x:1070,y:768,t:1527030814204};\\\", \\\"{x:1042,y:768,t:1527030814221};\\\", \\\"{x:1012,y:767,t:1527030814237};\\\", \\\"{x:980,y:764,t:1527030814255};\\\", \\\"{x:944,y:758,t:1527030814271};\\\", \\\"{x:890,y:755,t:1527030814288};\\\", \\\"{x:831,y:745,t:1527030814304};\\\", \\\"{x:767,y:736,t:1527030814322};\\\", \\\"{x:698,y:719,t:1527030814337};\\\", \\\"{x:646,y:701,t:1527030814354};\\\", \\\"{x:585,y:684,t:1527030814372};\\\", \\\"{x:532,y:666,t:1527030814387};\\\", \\\"{x:472,y:646,t:1527030814405};\\\", \\\"{x:430,y:635,t:1527030814422};\\\", \\\"{x:386,y:622,t:1527030814454};\\\", \\\"{x:366,y:609,t:1527030814468};\\\", \\\"{x:348,y:592,t:1527030814486};\\\", \\\"{x:326,y:566,t:1527030814502};\\\", \\\"{x:307,y:539,t:1527030814518};\\\", \\\"{x:293,y:516,t:1527030814536};\\\", \\\"{x:286,y:505,t:1527030814552};\\\", \\\"{x:282,y:496,t:1527030814567};\\\", \\\"{x:278,y:488,t:1527030814585};\\\", \\\"{x:275,y:482,t:1527030814604};\\\", \\\"{x:273,y:480,t:1527030814618};\\\", \\\"{x:273,y:477,t:1527030814635};\\\", \\\"{x:273,y:476,t:1527030814651};\\\", \\\"{x:273,y:474,t:1527030814669};\\\", \\\"{x:273,y:473,t:1527030814686};\\\", \\\"{x:276,y:472,t:1527030814702};\\\", \\\"{x:282,y:472,t:1527030814719};\\\", \\\"{x:298,y:478,t:1527030814737};\\\", \\\"{x:320,y:494,t:1527030814754};\\\", \\\"{x:339,y:507,t:1527030814769};\\\", \\\"{x:357,y:525,t:1527030814785};\\\", \\\"{x:373,y:543,t:1527030814802};\\\", \\\"{x:394,y:566,t:1527030814820};\\\", \\\"{x:406,y:583,t:1527030814835};\\\", \\\"{x:420,y:607,t:1527030814853};\\\", \\\"{x:425,y:621,t:1527030814868};\\\", \\\"{x:430,y:633,t:1527030814886};\\\", \\\"{x:432,y:645,t:1527030814902};\\\", \\\"{x:436,y:655,t:1527030814919};\\\", \\\"{x:437,y:662,t:1527030814935};\\\", \\\"{x:439,y:672,t:1527030814953};\\\", \\\"{x:441,y:681,t:1527030814969};\\\", \\\"{x:446,y:694,t:1527030814985};\\\", \\\"{x:452,y:707,t:1527030815003};\\\", \\\"{x:462,y:721,t:1527030815020};\\\", \\\"{x:465,y:725,t:1527030815036};\\\", \\\"{x:467,y:726,t:1527030815084};\\\", \\\"{x:468,y:727,t:1527030815093};\\\", \\\"{x:471,y:729,t:1527030815103};\\\", \\\"{x:477,y:735,t:1527030815119};\\\", \\\"{x:485,y:744,t:1527030815135};\\\", \\\"{x:492,y:751,t:1527030815152};\\\", \\\"{x:493,y:753,t:1527030815170};\\\", \\\"{x:494,y:753,t:1527030815213};\\\", \\\"{x:495,y:753,t:1527030815237};\\\", \\\"{x:497,y:753,t:1527030815253};\\\", \\\"{x:497,y:752,t:1527030815269};\\\", \\\"{x:499,y:750,t:1527030815286};\\\", \\\"{x:499,y:749,t:1527030815303};\\\", \\\"{x:500,y:747,t:1527030815320};\\\", \\\"{x:500,y:742,t:1527030815337};\\\", \\\"{x:500,y:735,t:1527030815353};\\\", \\\"{x:501,y:730,t:1527030815369};\\\", \\\"{x:501,y:727,t:1527030815387};\\\", \\\"{x:501,y:726,t:1527030815404};\\\", \\\"{x:501,y:725,t:1527030817533};\\\", \\\"{x:501,y:723,t:1527030817813};\\\", \\\"{x:501,y:721,t:1527030817836};\\\", \\\"{x:501,y:720,t:1527030817861};\\\", \\\"{x:501,y:725,t:1527030825061};\\\", \\\"{x:502,y:734,t:1527030825078};\\\", \\\"{x:506,y:743,t:1527030825095};\\\", \\\"{x:507,y:752,t:1527030825111};\\\", \\\"{x:510,y:759,t:1527030825129};\\\", \\\"{x:511,y:760,t:1527030825145};\\\", \\\"{x:513,y:760,t:1527030825308};\\\", \\\"{x:515,y:751,t:1527030825324};\\\", \\\"{x:522,y:741,t:1527030825340};\\\", \\\"{x:525,y:735,t:1527030825361};\\\", \\\"{x:527,y:733,t:1527030825377};\\\", \\\"{x:527,y:731,t:1527030825394};\\\", \\\"{x:527,y:730,t:1527030825411};\\\" ] }, { \\\"rt\\\": 16090, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 15, \\\"time_elapsed\\\": 603468, \\\"internal_node_id\\\": \\\"0.0-6.0-5.0\\\", \\\"subject\\\": \\\"E5L6P\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 11, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-12 PM-12 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:527,y:733,t:1527030831653};\\\", \\\"{x:527,y:734,t:1527030831668};\\\", \\\"{x:527,y:735,t:1527030831685};\\\", \\\"{x:527,y:736,t:1527030831702};\\\", \\\"{x:527,y:737,t:1527030831725};\\\", \\\"{x:527,y:739,t:1527030832140};\\\", \\\"{x:532,y:741,t:1527030832154};\\\", \\\"{x:552,y:749,t:1527030832170};\\\", \\\"{x:577,y:755,t:1527030832188};\\\", \\\"{x:624,y:755,t:1527030832203};\\\", \\\"{x:636,y:750,t:1527030832215};\\\", \\\"{x:661,y:736,t:1527030832232};\\\", \\\"{x:681,y:714,t:1527030832249};\\\", \\\"{x:701,y:674,t:1527030832266};\\\", \\\"{x:717,y:633,t:1527030832282};\\\", \\\"{x:724,y:593,t:1527030832301};\\\", \\\"{x:725,y:566,t:1527030832315};\\\", \\\"{x:718,y:536,t:1527030832335};\\\", \\\"{x:706,y:515,t:1527030832350};\\\", \\\"{x:694,y:496,t:1527030832367};\\\", \\\"{x:682,y:483,t:1527030832384};\\\", \\\"{x:671,y:472,t:1527030832400};\\\", \\\"{x:656,y:461,t:1527030832415};\\\", \\\"{x:641,y:451,t:1527030832432};\\\", \\\"{x:626,y:443,t:1527030832449};\\\", \\\"{x:614,y:437,t:1527030832466};\\\", \\\"{x:606,y:433,t:1527030832483};\\\", \\\"{x:598,y:431,t:1527030832499};\\\", \\\"{x:593,y:431,t:1527030832517};\\\", \\\"{x:591,y:431,t:1527030832533};\\\", \\\"{x:589,y:431,t:1527030832550};\\\", \\\"{x:588,y:432,t:1527030832566};\\\", \\\"{x:585,y:434,t:1527030832583};\\\", \\\"{x:581,y:439,t:1527030832600};\\\", \\\"{x:581,y:448,t:1527030832618};\\\", \\\"{x:581,y:456,t:1527030832633};\\\", \\\"{x:581,y:463,t:1527030832650};\\\", \\\"{x:581,y:470,t:1527030832667};\\\", \\\"{x:583,y:474,t:1527030832683};\\\", \\\"{x:589,y:479,t:1527030832699};\\\", \\\"{x:594,y:482,t:1527030832717};\\\", \\\"{x:608,y:487,t:1527030832734};\\\", \\\"{x:623,y:490,t:1527030832750};\\\", \\\"{x:644,y:493,t:1527030832767};\\\", \\\"{x:666,y:496,t:1527030832783};\\\", \\\"{x:688,y:496,t:1527030832800};\\\", \\\"{x:711,y:496,t:1527030832817};\\\", \\\"{x:733,y:498,t:1527030832834};\\\", \\\"{x:760,y:499,t:1527030832850};\\\", \\\"{x:790,y:505,t:1527030832867};\\\", \\\"{x:848,y:515,t:1527030832884};\\\", \\\"{x:885,y:525,t:1527030832902};\\\", \\\"{x:927,y:539,t:1527030832917};\\\", \\\"{x:982,y:552,t:1527030832934};\\\", \\\"{x:1039,y:574,t:1527030832949};\\\", \\\"{x:1116,y:606,t:1527030832967};\\\", \\\"{x:1205,y:652,t:1527030832984};\\\", \\\"{x:1296,y:704,t:1527030833000};\\\", \\\"{x:1375,y:748,t:1527030833017};\\\", \\\"{x:1438,y:786,t:1527030833034};\\\", \\\"{x:1503,y:820,t:1527030833050};\\\", \\\"{x:1557,y:851,t:1527030833067};\\\", \\\"{x:1619,y:891,t:1527030833084};\\\", \\\"{x:1643,y:907,t:1527030833099};\\\", \\\"{x:1658,y:923,t:1527030833117};\\\", \\\"{x:1666,y:931,t:1527030833134};\\\", \\\"{x:1671,y:939,t:1527030833150};\\\", \\\"{x:1672,y:943,t:1527030833167};\\\", \\\"{x:1672,y:945,t:1527030833185};\\\", \\\"{x:1671,y:947,t:1527030833200};\\\", \\\"{x:1665,y:950,t:1527030833217};\\\", \\\"{x:1653,y:953,t:1527030833234};\\\", \\\"{x:1635,y:958,t:1527030833250};\\\", \\\"{x:1616,y:968,t:1527030833267};\\\", \\\"{x:1570,y:989,t:1527030833283};\\\", \\\"{x:1537,y:1004,t:1527030833300};\\\", \\\"{x:1512,y:1011,t:1527030833317};\\\", \\\"{x:1490,y:1014,t:1527030833335};\\\", \\\"{x:1473,y:1015,t:1527030833350};\\\", \\\"{x:1465,y:1015,t:1527030833367};\\\", \\\"{x:1461,y:1015,t:1527030833384};\\\", \\\"{x:1460,y:1015,t:1527030833400};\\\", \\\"{x:1458,y:1015,t:1527030833485};\\\", \\\"{x:1455,y:1015,t:1527030833500};\\\", \\\"{x:1451,y:1015,t:1527030833517};\\\", \\\"{x:1445,y:1015,t:1527030833534};\\\", \\\"{x:1441,y:1014,t:1527030833551};\\\", \\\"{x:1439,y:1012,t:1527030833567};\\\", \\\"{x:1437,y:1012,t:1527030833584};\\\", \\\"{x:1435,y:1012,t:1527030833601};\\\", \\\"{x:1434,y:1012,t:1527030833620};\\\", \\\"{x:1433,y:1012,t:1527030833635};\\\", \\\"{x:1432,y:1012,t:1527030833661};\\\", \\\"{x:1431,y:1012,t:1527030833668};\\\", \\\"{x:1429,y:1012,t:1527030833684};\\\", \\\"{x:1428,y:1012,t:1527030833702};\\\", \\\"{x:1427,y:1012,t:1527030833717};\\\", \\\"{x:1425,y:1012,t:1527030833741};\\\", \\\"{x:1425,y:1011,t:1527030834245};\\\", \\\"{x:1425,y:1010,t:1527030834252};\\\", \\\"{x:1427,y:1008,t:1527030834268};\\\", \\\"{x:1429,y:1006,t:1527030834285};\\\", \\\"{x:1432,y:1004,t:1527030834300};\\\", \\\"{x:1434,y:1003,t:1527030834318};\\\", \\\"{x:1438,y:1001,t:1527030834334};\\\", \\\"{x:1443,y:1000,t:1527030834351};\\\", \\\"{x:1450,y:998,t:1527030834367};\\\", \\\"{x:1454,y:997,t:1527030834385};\\\", \\\"{x:1459,y:996,t:1527030834401};\\\", \\\"{x:1464,y:995,t:1527030834418};\\\", \\\"{x:1470,y:995,t:1527030834434};\\\", \\\"{x:1477,y:994,t:1527030834451};\\\", \\\"{x:1492,y:994,t:1527030834468};\\\", \\\"{x:1503,y:994,t:1527030834485};\\\", \\\"{x:1513,y:994,t:1527030834501};\\\", \\\"{x:1527,y:994,t:1527030834518};\\\", \\\"{x:1539,y:993,t:1527030834535};\\\", \\\"{x:1548,y:993,t:1527030834551};\\\", \\\"{x:1560,y:993,t:1527030834568};\\\", \\\"{x:1574,y:993,t:1527030834585};\\\", \\\"{x:1589,y:993,t:1527030834601};\\\", \\\"{x:1602,y:993,t:1527030834618};\\\", \\\"{x:1613,y:993,t:1527030834635};\\\", \\\"{x:1624,y:993,t:1527030834651};\\\", \\\"{x:1639,y:993,t:1527030834667};\\\", \\\"{x:1649,y:993,t:1527030834685};\\\", \\\"{x:1660,y:993,t:1527030834701};\\\", \\\"{x:1669,y:993,t:1527030834719};\\\", \\\"{x:1678,y:993,t:1527030834735};\\\", \\\"{x:1688,y:993,t:1527030834751};\\\", \\\"{x:1697,y:993,t:1527030834769};\\\", \\\"{x:1706,y:993,t:1527030834785};\\\", \\\"{x:1715,y:993,t:1527030834801};\\\", \\\"{x:1727,y:993,t:1527030834819};\\\", \\\"{x:1740,y:993,t:1527030834835};\\\", \\\"{x:1760,y:993,t:1527030834852};\\\", \\\"{x:1774,y:993,t:1527030834868};\\\", \\\"{x:1785,y:993,t:1527030834885};\\\", \\\"{x:1796,y:993,t:1527030834902};\\\", \\\"{x:1807,y:993,t:1527030834918};\\\", \\\"{x:1817,y:993,t:1527030834935};\\\", \\\"{x:1828,y:993,t:1527030834952};\\\", \\\"{x:1835,y:993,t:1527030834968};\\\", \\\"{x:1842,y:992,t:1527030834986};\\\", \\\"{x:1846,y:991,t:1527030835002};\\\", \\\"{x:1849,y:991,t:1527030835018};\\\", \\\"{x:1852,y:990,t:1527030835035};\\\", \\\"{x:1856,y:989,t:1527030835052};\\\", \\\"{x:1858,y:989,t:1527030835068};\\\", \\\"{x:1859,y:989,t:1527030835085};\\\", \\\"{x:1859,y:987,t:1527030835197};\\\", \\\"{x:1859,y:986,t:1527030835212};\\\", \\\"{x:1858,y:986,t:1527030835221};\\\", \\\"{x:1856,y:985,t:1527030835235};\\\", \\\"{x:1855,y:985,t:1527030835252};\\\", \\\"{x:1851,y:985,t:1527030835269};\\\", \\\"{x:1840,y:985,t:1527030835286};\\\", \\\"{x:1822,y:989,t:1527030835302};\\\", \\\"{x:1793,y:993,t:1527030835318};\\\", \\\"{x:1753,y:996,t:1527030835335};\\\", \\\"{x:1711,y:1001,t:1527030835352};\\\", \\\"{x:1668,y:1010,t:1527030835369};\\\", \\\"{x:1625,y:1011,t:1527030835385};\\\", \\\"{x:1578,y:1011,t:1527030835402};\\\", \\\"{x:1542,y:1011,t:1527030835420};\\\", \\\"{x:1515,y:1011,t:1527030835436};\\\", \\\"{x:1489,y:1011,t:1527030835453};\\\", \\\"{x:1482,y:1011,t:1527030835469};\\\", \\\"{x:1475,y:1011,t:1527030835486};\\\", \\\"{x:1471,y:1011,t:1527030835503};\\\", \\\"{x:1467,y:1011,t:1527030835520};\\\", \\\"{x:1462,y:1011,t:1527030835535};\\\", \\\"{x:1456,y:1011,t:1527030835552};\\\", \\\"{x:1448,y:1011,t:1527030835569};\\\", \\\"{x:1439,y:1010,t:1527030835586};\\\", \\\"{x:1430,y:1007,t:1527030835603};\\\", \\\"{x:1422,y:1004,t:1527030835619};\\\", \\\"{x:1412,y:1003,t:1527030835636};\\\", \\\"{x:1396,y:1000,t:1527030835653};\\\", \\\"{x:1387,y:1000,t:1527030835670};\\\", \\\"{x:1384,y:1000,t:1527030835685};\\\", \\\"{x:1380,y:1000,t:1527030835702};\\\", \\\"{x:1378,y:1000,t:1527030835719};\\\", \\\"{x:1374,y:1000,t:1527030835736};\\\", \\\"{x:1372,y:999,t:1527030835752};\\\", \\\"{x:1369,y:999,t:1527030835769};\\\", \\\"{x:1366,y:999,t:1527030835786};\\\", \\\"{x:1364,y:998,t:1527030835802};\\\", \\\"{x:1363,y:998,t:1527030835819};\\\", \\\"{x:1361,y:998,t:1527030835836};\\\", \\\"{x:1359,y:998,t:1527030835852};\\\", \\\"{x:1358,y:998,t:1527030835869};\\\", \\\"{x:1356,y:998,t:1527030835892};\\\", \\\"{x:1355,y:997,t:1527030835924};\\\", \\\"{x:1355,y:996,t:1527030835973};\\\", \\\"{x:1353,y:996,t:1527030835986};\\\", \\\"{x:1351,y:995,t:1527030836004};\\\", \\\"{x:1350,y:994,t:1527030836020};\\\", \\\"{x:1349,y:993,t:1527030836036};\\\", \\\"{x:1348,y:993,t:1527030836052};\\\", \\\"{x:1347,y:993,t:1527030836070};\\\", \\\"{x:1346,y:991,t:1527030836087};\\\", \\\"{x:1345,y:991,t:1527030836102};\\\", \\\"{x:1344,y:989,t:1527030836119};\\\", \\\"{x:1343,y:988,t:1527030836137};\\\", \\\"{x:1342,y:987,t:1527030836153};\\\", \\\"{x:1342,y:985,t:1527030836188};\\\", \\\"{x:1342,y:984,t:1527030836205};\\\", \\\"{x:1342,y:983,t:1527030836221};\\\", \\\"{x:1342,y:982,t:1527030836237};\\\", \\\"{x:1342,y:981,t:1527030836253};\\\", \\\"{x:1342,y:979,t:1527030836269};\\\", \\\"{x:1342,y:978,t:1527030836286};\\\", \\\"{x:1342,y:976,t:1527030836303};\\\", \\\"{x:1342,y:974,t:1527030836319};\\\", \\\"{x:1343,y:972,t:1527030836336};\\\", \\\"{x:1343,y:971,t:1527030836356};\\\", \\\"{x:1344,y:971,t:1527030836370};\\\", \\\"{x:1344,y:970,t:1527030836387};\\\", \\\"{x:1344,y:968,t:1527030836405};\\\", \\\"{x:1344,y:966,t:1527030836691};\\\", \\\"{x:1345,y:965,t:1527030836703};\\\", \\\"{x:1346,y:964,t:1527030836720};\\\", \\\"{x:1346,y:963,t:1527030836736};\\\", \\\"{x:1347,y:961,t:1527030836753};\\\", \\\"{x:1347,y:960,t:1527030837477};\\\", \\\"{x:1349,y:960,t:1527030837488};\\\", \\\"{x:1350,y:961,t:1527030837533};\\\", \\\"{x:1350,y:963,t:1527030837797};\\\", \\\"{x:1351,y:964,t:1527030837812};\\\", \\\"{x:1352,y:965,t:1527030837821};\\\", \\\"{x:1352,y:966,t:1527030837868};\\\", \\\"{x:1352,y:968,t:1527030837933};\\\", \\\"{x:1352,y:969,t:1527030837965};\\\", \\\"{x:1352,y:971,t:1527030837996};\\\", \\\"{x:1352,y:972,t:1527030838028};\\\", \\\"{x:1351,y:973,t:1527030838060};\\\", \\\"{x:1351,y:974,t:1527030838084};\\\", \\\"{x:1350,y:975,t:1527030838100};\\\", \\\"{x:1350,y:974,t:1527030838501};\\\", \\\"{x:1350,y:972,t:1527030838516};\\\", \\\"{x:1350,y:971,t:1527030838524};\\\", \\\"{x:1350,y:969,t:1527030838540};\\\", \\\"{x:1350,y:968,t:1527030838573};\\\", \\\"{x:1350,y:966,t:1527030838596};\\\", \\\"{x:1350,y:965,t:1527030838605};\\\", \\\"{x:1350,y:963,t:1527030838622};\\\", \\\"{x:1350,y:962,t:1527030838639};\\\", \\\"{x:1350,y:960,t:1527030838668};\\\", \\\"{x:1350,y:959,t:1527030838685};\\\", \\\"{x:1350,y:957,t:1527030838709};\\\", \\\"{x:1350,y:956,t:1527030838725};\\\", \\\"{x:1350,y:954,t:1527030838737};\\\", \\\"{x:1350,y:953,t:1527030838755};\\\", \\\"{x:1350,y:952,t:1527030838771};\\\", \\\"{x:1349,y:951,t:1527030838788};\\\", \\\"{x:1349,y:950,t:1527030838805};\\\", \\\"{x:1349,y:949,t:1527030838829};\\\", \\\"{x:1349,y:948,t:1527030838868};\\\", \\\"{x:1348,y:948,t:1527030838893};\\\", \\\"{x:1348,y:947,t:1527030838973};\\\", \\\"{x:1348,y:945,t:1527030838996};\\\", \\\"{x:1348,y:944,t:1527030839004};\\\", \\\"{x:1348,y:943,t:1527030839022};\\\", \\\"{x:1348,y:942,t:1527030839038};\\\", \\\"{x:1347,y:940,t:1527030839054};\\\", \\\"{x:1347,y:939,t:1527030839109};\\\", \\\"{x:1347,y:938,t:1527030839165};\\\", \\\"{x:1347,y:937,t:1527030839196};\\\", \\\"{x:1347,y:936,t:1527030839213};\\\", \\\"{x:1347,y:935,t:1527030839237};\\\", \\\"{x:1348,y:934,t:1527030839253};\\\", \\\"{x:1350,y:932,t:1527030839260};\\\", \\\"{x:1352,y:932,t:1527030839276};\\\", \\\"{x:1352,y:931,t:1527030839289};\\\", \\\"{x:1353,y:930,t:1527030839306};\\\", \\\"{x:1354,y:930,t:1527030839324};\\\", \\\"{x:1353,y:929,t:1527030839485};\\\", \\\"{x:1334,y:927,t:1527030839492};\\\", \\\"{x:1288,y:917,t:1527030839506};\\\", \\\"{x:1175,y:888,t:1527030839522};\\\", \\\"{x:1040,y:854,t:1527030839539};\\\", \\\"{x:900,y:820,t:1527030839555};\\\", \\\"{x:689,y:779,t:1527030839571};\\\", \\\"{x:570,y:745,t:1527030839588};\\\", \\\"{x:463,y:698,t:1527030839605};\\\", \\\"{x:365,y:649,t:1527030839623};\\\", \\\"{x:279,y:593,t:1527030839639};\\\", \\\"{x:224,y:534,t:1527030839655};\\\", \\\"{x:205,y:509,t:1527030839667};\\\", \\\"{x:168,y:451,t:1527030839684};\\\", \\\"{x:158,y:431,t:1527030839705};\\\", \\\"{x:157,y:423,t:1527030839722};\\\", \\\"{x:157,y:417,t:1527030839739};\\\", \\\"{x:157,y:412,t:1527030839755};\\\", \\\"{x:157,y:404,t:1527030839772};\\\", \\\"{x:154,y:396,t:1527030839789};\\\", \\\"{x:151,y:387,t:1527030839805};\\\", \\\"{x:144,y:378,t:1527030839822};\\\", \\\"{x:140,y:374,t:1527030839839};\\\", \\\"{x:139,y:372,t:1527030839855};\\\", \\\"{x:139,y:371,t:1527030839884};\\\", \\\"{x:139,y:370,t:1527030839915};\\\", \\\"{x:140,y:370,t:1527030839931};\\\", \\\"{x:143,y:370,t:1527030839939};\\\", \\\"{x:171,y:385,t:1527030839956};\\\", \\\"{x:243,y:428,t:1527030839972};\\\", \\\"{x:326,y:483,t:1527030839989};\\\", \\\"{x:400,y:529,t:1527030840008};\\\", \\\"{x:456,y:567,t:1527030840023};\\\", \\\"{x:491,y:589,t:1527030840038};\\\", \\\"{x:520,y:604,t:1527030840056};\\\", \\\"{x:542,y:612,t:1527030840072};\\\", \\\"{x:554,y:617,t:1527030840089};\\\", \\\"{x:559,y:618,t:1527030840107};\\\", \\\"{x:557,y:613,t:1527030840165};\\\", \\\"{x:551,y:610,t:1527030840173};\\\", \\\"{x:528,y:601,t:1527030840190};\\\", \\\"{x:492,y:587,t:1527030840208};\\\", \\\"{x:453,y:576,t:1527030840223};\\\", \\\"{x:414,y:565,t:1527030840238};\\\", \\\"{x:390,y:560,t:1527030840256};\\\", \\\"{x:363,y:556,t:1527030840273};\\\", \\\"{x:335,y:550,t:1527030840290};\\\", \\\"{x:313,y:545,t:1527030840306};\\\", \\\"{x:291,y:543,t:1527030840323};\\\", \\\"{x:271,y:540,t:1527030840340};\\\", \\\"{x:262,y:539,t:1527030840356};\\\", \\\"{x:260,y:539,t:1527030840373};\\\", \\\"{x:258,y:539,t:1527030840389};\\\", \\\"{x:256,y:539,t:1527030840406};\\\", \\\"{x:254,y:540,t:1527030840423};\\\", \\\"{x:252,y:541,t:1527030840439};\\\", \\\"{x:248,y:542,t:1527030840456};\\\", \\\"{x:243,y:543,t:1527030840472};\\\", \\\"{x:237,y:543,t:1527030840489};\\\", \\\"{x:230,y:543,t:1527030840507};\\\", \\\"{x:222,y:543,t:1527030840523};\\\", \\\"{x:215,y:543,t:1527030840539};\\\", \\\"{x:209,y:543,t:1527030840556};\\\", \\\"{x:205,y:543,t:1527030840573};\\\", \\\"{x:199,y:540,t:1527030840589};\\\", \\\"{x:194,y:538,t:1527030840607};\\\", \\\"{x:190,y:536,t:1527030840624};\\\", \\\"{x:187,y:535,t:1527030840644};\\\", \\\"{x:186,y:535,t:1527030840660};\\\", \\\"{x:184,y:535,t:1527030840673};\\\", \\\"{x:183,y:535,t:1527030840689};\\\", \\\"{x:181,y:535,t:1527030840706};\\\", \\\"{x:179,y:535,t:1527030840723};\\\", \\\"{x:178,y:534,t:1527030840739};\\\", \\\"{x:177,y:534,t:1527030840756};\\\", \\\"{x:176,y:534,t:1527030840819};\\\", \\\"{x:175,y:534,t:1527030840827};\\\", \\\"{x:174,y:534,t:1527030840839};\\\", \\\"{x:171,y:534,t:1527030840856};\\\", \\\"{x:168,y:535,t:1527030840873};\\\", \\\"{x:167,y:535,t:1527030840889};\\\", \\\"{x:164,y:535,t:1527030840906};\\\", \\\"{x:163,y:535,t:1527030840923};\\\", \\\"{x:161,y:535,t:1527030840939};\\\", \\\"{x:160,y:535,t:1527030840981};\\\", \\\"{x:159,y:535,t:1527030840990};\\\", \\\"{x:157,y:535,t:1527030841123};\\\", \\\"{x:157,y:535,t:1527030841224};\\\", \\\"{x:167,y:537,t:1527030841379};\\\", \\\"{x:180,y:538,t:1527030841390};\\\", \\\"{x:219,y:545,t:1527030841408};\\\", \\\"{x:264,y:551,t:1527030841423};\\\", \\\"{x:300,y:554,t:1527030841440};\\\", \\\"{x:343,y:557,t:1527030841457};\\\", \\\"{x:405,y:559,t:1527030841473};\\\", \\\"{x:466,y:559,t:1527030841491};\\\", \\\"{x:536,y:559,t:1527030841507};\\\", \\\"{x:573,y:559,t:1527030841524};\\\", \\\"{x:596,y:559,t:1527030841540};\\\", \\\"{x:618,y:554,t:1527030841558};\\\", \\\"{x:633,y:551,t:1527030841574};\\\", \\\"{x:648,y:549,t:1527030841590};\\\", \\\"{x:659,y:544,t:1527030841607};\\\", \\\"{x:667,y:541,t:1527030841623};\\\", \\\"{x:676,y:537,t:1527030841640};\\\", \\\"{x:686,y:534,t:1527030841657};\\\", \\\"{x:701,y:530,t:1527030841674};\\\", \\\"{x:717,y:527,t:1527030841690};\\\", \\\"{x:756,y:523,t:1527030841708};\\\", \\\"{x:774,y:520,t:1527030841723};\\\", \\\"{x:783,y:519,t:1527030841740};\\\", \\\"{x:787,y:519,t:1527030841757};\\\", \\\"{x:789,y:518,t:1527030841774};\\\", \\\"{x:790,y:517,t:1527030841791};\\\", \\\"{x:792,y:517,t:1527030841807};\\\", \\\"{x:793,y:516,t:1527030841892};\\\", \\\"{x:796,y:514,t:1527030841907};\\\", \\\"{x:798,y:512,t:1527030841924};\\\", \\\"{x:799,y:511,t:1527030841940};\\\", \\\"{x:800,y:510,t:1527030841957};\\\", \\\"{x:801,y:509,t:1527030841974};\\\", \\\"{x:802,y:509,t:1527030841990};\\\", \\\"{x:804,y:507,t:1527030842008};\\\", \\\"{x:806,y:507,t:1527030842025};\\\", \\\"{x:806,y:506,t:1527030842041};\\\", \\\"{x:808,y:506,t:1527030842057};\\\", \\\"{x:810,y:504,t:1527030842075};\\\", \\\"{x:811,y:504,t:1527030842090};\\\", \\\"{x:812,y:503,t:1527030842108};\\\", \\\"{x:815,y:503,t:1527030842124};\\\", \\\"{x:816,y:502,t:1527030842157};\\\", \\\"{x:817,y:502,t:1527030842172};\\\", \\\"{x:818,y:502,t:1527030842196};\\\", \\\"{x:819,y:502,t:1527030842253};\\\", \\\"{x:821,y:502,t:1527030842260};\\\", \\\"{x:823,y:502,t:1527030842275};\\\", \\\"{x:830,y:502,t:1527030842293};\\\", \\\"{x:832,y:502,t:1527030842307};\\\", \\\"{x:834,y:502,t:1527030842324};\\\", \\\"{x:835,y:502,t:1527030842341};\\\", \\\"{x:835,y:503,t:1527030842964};\\\", \\\"{x:835,y:505,t:1527030842976};\\\", \\\"{x:833,y:508,t:1527030842992};\\\", \\\"{x:829,y:512,t:1527030843008};\\\", \\\"{x:826,y:514,t:1527030843027};\\\", \\\"{x:823,y:517,t:1527030843041};\\\", \\\"{x:821,y:520,t:1527030843059};\\\", \\\"{x:818,y:522,t:1527030843074};\\\", \\\"{x:816,y:523,t:1527030843091};\\\", \\\"{x:814,y:526,t:1527030843108};\\\", \\\"{x:812,y:527,t:1527030843124};\\\", \\\"{x:810,y:529,t:1527030843141};\\\", \\\"{x:809,y:530,t:1527030843158};\\\", \\\"{x:807,y:531,t:1527030843175};\\\", \\\"{x:806,y:532,t:1527030843191};\\\", \\\"{x:804,y:533,t:1527030843209};\\\", \\\"{x:802,y:535,t:1527030843225};\\\", \\\"{x:800,y:536,t:1527030843241};\\\", \\\"{x:798,y:538,t:1527030843258};\\\", \\\"{x:797,y:539,t:1527030843275};\\\", \\\"{x:794,y:541,t:1527030843292};\\\", \\\"{x:793,y:543,t:1527030843308};\\\", \\\"{x:791,y:545,t:1527030843325};\\\", \\\"{x:790,y:545,t:1527030843342};\\\", \\\"{x:789,y:548,t:1527030843358};\\\", \\\"{x:788,y:549,t:1527030843375};\\\", \\\"{x:784,y:552,t:1527030843392};\\\", \\\"{x:781,y:554,t:1527030843409};\\\", \\\"{x:780,y:556,t:1527030843427};\\\", \\\"{x:777,y:559,t:1527030843443};\\\", \\\"{x:773,y:562,t:1527030843458};\\\", \\\"{x:764,y:572,t:1527030843477};\\\", \\\"{x:756,y:582,t:1527030843492};\\\", \\\"{x:742,y:596,t:1527030843508};\\\", \\\"{x:727,y:614,t:1527030843526};\\\", \\\"{x:714,y:634,t:1527030843543};\\\", \\\"{x:696,y:659,t:1527030843558};\\\", \\\"{x:679,y:681,t:1527030843575};\\\", \\\"{x:663,y:700,t:1527030843592};\\\", \\\"{x:643,y:726,t:1527030843608};\\\", \\\"{x:623,y:757,t:1527030843625};\\\", \\\"{x:600,y:786,t:1527030843642};\\\", \\\"{x:586,y:806,t:1527030843658};\\\", \\\"{x:573,y:820,t:1527030843675};\\\", \\\"{x:570,y:823,t:1527030843691};\\\", \\\"{x:569,y:824,t:1527030843708};\\\", \\\"{x:568,y:826,t:1527030843725};\\\", \\\"{x:566,y:828,t:1527030843742};\\\", \\\"{x:562,y:831,t:1527030843758};\\\", \\\"{x:560,y:833,t:1527030843775};\\\", \\\"{x:555,y:836,t:1527030843793};\\\", \\\"{x:551,y:837,t:1527030843809};\\\", \\\"{x:550,y:837,t:1527030843828};\\\", \\\"{x:549,y:837,t:1527030843860};\\\", \\\"{x:548,y:837,t:1527030843876};\\\", \\\"{x:534,y:807,t:1527030843892};\\\", \\\"{x:520,y:775,t:1527030843909};\\\", \\\"{x:511,y:753,t:1527030843927};\\\", \\\"{x:502,y:741,t:1527030843942};\\\", \\\"{x:497,y:731,t:1527030843959};\\\", \\\"{x:492,y:727,t:1527030843975};\\\", \\\"{x:490,y:725,t:1527030843992};\\\", \\\"{x:491,y:729,t:1527030844188};\\\", \\\"{x:495,y:732,t:1527030844196};\\\", \\\"{x:498,y:737,t:1527030844213};\\\", \\\"{x:501,y:741,t:1527030844229};\\\", \\\"{x:504,y:745,t:1527030844246};\\\", \\\"{x:507,y:747,t:1527030844263};\\\", \\\"{x:507,y:746,t:1527030844712};\\\", \\\"{x:507,y:743,t:1527030844730};\\\", \\\"{x:507,y:741,t:1527030844746};\\\", \\\"{x:507,y:739,t:1527030844764};\\\", \\\"{x:506,y:737,t:1527030844780};\\\", \\\"{x:506,y:736,t:1527030844797};\\\", \\\"{x:506,y:735,t:1527030844813};\\\", \\\"{x:506,y:734,t:1527030844864};\\\" ] }, { \\\"rt\\\": 11646, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 16, \\\"time_elapsed\\\": 616343, \\\"internal_node_id\\\": \\\"0.0-6.0-6.0\\\", \\\"subject\\\": \\\"E5L6P\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 12, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:503,y:725,t:1527030854360};\\\", \\\"{x:487,y:701,t:1527030854374};\\\", \\\"{x:425,y:626,t:1527030854393};\\\", \\\"{x:407,y:600,t:1527030854404};\\\", \\\"{x:382,y:570,t:1527030854421};\\\", \\\"{x:366,y:544,t:1527030854438};\\\", \\\"{x:358,y:530,t:1527030854454};\\\", \\\"{x:355,y:523,t:1527030854471};\\\", \\\"{x:354,y:521,t:1527030854488};\\\", \\\"{x:353,y:519,t:1527030854504};\\\", \\\"{x:350,y:516,t:1527030854521};\\\", \\\"{x:342,y:507,t:1527030854537};\\\", \\\"{x:327,y:497,t:1527030854555};\\\", \\\"{x:311,y:485,t:1527030854572};\\\", \\\"{x:295,y:473,t:1527030854587};\\\", \\\"{x:284,y:462,t:1527030854604};\\\", \\\"{x:277,y:457,t:1527030854621};\\\", \\\"{x:276,y:455,t:1527030854638};\\\", \\\"{x:278,y:459,t:1527030854671};\\\", \\\"{x:319,y:495,t:1527030854689};\\\", \\\"{x:388,y:540,t:1527030854705};\\\", \\\"{x:469,y:584,t:1527030854722};\\\", \\\"{x:534,y:614,t:1527030854739};\\\", \\\"{x:596,y:637,t:1527030854755};\\\", \\\"{x:631,y:644,t:1527030854771};\\\", \\\"{x:656,y:644,t:1527030854788};\\\", \\\"{x:667,y:643,t:1527030854804};\\\", \\\"{x:668,y:639,t:1527030854821};\\\", \\\"{x:668,y:631,t:1527030854839};\\\", \\\"{x:655,y:615,t:1527030854854};\\\", \\\"{x:614,y:601,t:1527030854871};\\\", \\\"{x:583,y:589,t:1527030854888};\\\", \\\"{x:535,y:582,t:1527030854904};\\\", \\\"{x:475,y:570,t:1527030854922};\\\", \\\"{x:417,y:562,t:1527030854939};\\\", \\\"{x:356,y:557,t:1527030854956};\\\", \\\"{x:290,y:553,t:1527030854972};\\\", \\\"{x:237,y:553,t:1527030854989};\\\", \\\"{x:206,y:553,t:1527030855005};\\\", \\\"{x:177,y:550,t:1527030855021};\\\", \\\"{x:151,y:550,t:1527030855038};\\\", \\\"{x:117,y:550,t:1527030855055};\\\", \\\"{x:95,y:550,t:1527030855071};\\\", \\\"{x:80,y:550,t:1527030855089};\\\", \\\"{x:72,y:555,t:1527030855104};\\\", \\\"{x:70,y:558,t:1527030855122};\\\", \\\"{x:68,y:560,t:1527030855138};\\\", \\\"{x:67,y:561,t:1527030855156};\\\", \\\"{x:67,y:562,t:1527030855171};\\\", \\\"{x:68,y:560,t:1527030855231};\\\", \\\"{x:73,y:558,t:1527030855239};\\\", \\\"{x:82,y:551,t:1527030855255};\\\", \\\"{x:85,y:548,t:1527030855272};\\\", \\\"{x:91,y:544,t:1527030855288};\\\", \\\"{x:97,y:539,t:1527030855305};\\\", \\\"{x:99,y:538,t:1527030855321};\\\", \\\"{x:102,y:537,t:1527030855338};\\\", \\\"{x:106,y:534,t:1527030855355};\\\", \\\"{x:111,y:533,t:1527030855371};\\\", \\\"{x:115,y:531,t:1527030855388};\\\", \\\"{x:120,y:529,t:1527030855405};\\\", \\\"{x:124,y:528,t:1527030855421};\\\", \\\"{x:127,y:528,t:1527030855438};\\\", \\\"{x:130,y:528,t:1527030855455};\\\", \\\"{x:132,y:528,t:1527030855479};\\\", \\\"{x:137,y:530,t:1527030855488};\\\", \\\"{x:147,y:541,t:1527030855505};\\\", \\\"{x:157,y:548,t:1527030855523};\\\", \\\"{x:165,y:555,t:1527030855539};\\\", \\\"{x:173,y:561,t:1527030855555};\\\", \\\"{x:176,y:562,t:1527030855573};\\\", \\\"{x:177,y:562,t:1527030855588};\\\", \\\"{x:178,y:562,t:1527030855623};\\\", \\\"{x:178,y:561,t:1527030855639};\\\", \\\"{x:180,y:555,t:1527030855656};\\\", \\\"{x:181,y:551,t:1527030855672};\\\", \\\"{x:181,y:550,t:1527030855689};\\\", \\\"{x:181,y:548,t:1527030855706};\\\", \\\"{x:181,y:547,t:1527030855722};\\\", \\\"{x:181,y:545,t:1527030855744};\\\", \\\"{x:180,y:544,t:1527030855759};\\\", \\\"{x:179,y:543,t:1527030855775};\\\", \\\"{x:179,y:542,t:1527030855792};\\\", \\\"{x:177,y:541,t:1527030855807};\\\", \\\"{x:176,y:540,t:1527030855959};\\\", \\\"{x:175,y:540,t:1527030856040};\\\", \\\"{x:174,y:540,t:1527030856106};\\\", \\\"{x:174,y:540,t:1527030856155};\\\", \\\"{x:174,y:541,t:1527030856368};\\\", \\\"{x:176,y:544,t:1527030856376};\\\", \\\"{x:178,y:546,t:1527030856389};\\\", \\\"{x:189,y:553,t:1527030856407};\\\", \\\"{x:209,y:563,t:1527030856424};\\\", \\\"{x:249,y:581,t:1527030856438};\\\", \\\"{x:293,y:601,t:1527030856456};\\\", \\\"{x:339,y:618,t:1527030856473};\\\", \\\"{x:386,y:636,t:1527030856490};\\\", \\\"{x:437,y:662,t:1527030856507};\\\", \\\"{x:491,y:691,t:1527030856523};\\\", \\\"{x:532,y:715,t:1527030856539};\\\", \\\"{x:564,y:736,t:1527030856557};\\\", \\\"{x:575,y:744,t:1527030856573};\\\", \\\"{x:574,y:743,t:1527030856807};\\\", \\\"{x:573,y:743,t:1527030856822};\\\", \\\"{x:566,y:739,t:1527030856839};\\\", \\\"{x:560,y:738,t:1527030856857};\\\", \\\"{x:555,y:737,t:1527030856872};\\\", \\\"{x:548,y:736,t:1527030856889};\\\", \\\"{x:543,y:736,t:1527030856906};\\\", \\\"{x:537,y:734,t:1527030856923};\\\", \\\"{x:535,y:734,t:1527030856939};\\\", \\\"{x:534,y:734,t:1527030856956};\\\" ] }, { \\\"rt\\\": 27987, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 17, \\\"time_elapsed\\\": 645545, \\\"internal_node_id\\\": \\\"0.0-6.0-7.0\\\", \\\"subject\\\": \\\"E5L6P\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 13, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-M -X -Z -Z -04 PM-X -O \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:533,y:734,t:1527030862648};\\\", \\\"{x:533,y:732,t:1527030863767};\\\", \\\"{x:539,y:729,t:1527030863781};\\\", \\\"{x:546,y:728,t:1527030863798};\\\", \\\"{x:557,y:726,t:1527030863815};\\\", \\\"{x:565,y:726,t:1527030863833};\\\", \\\"{x:579,y:726,t:1527030863848};\\\", \\\"{x:597,y:726,t:1527030863865};\\\", \\\"{x:620,y:726,t:1527030863878};\\\", \\\"{x:639,y:728,t:1527030863896};\\\", \\\"{x:658,y:728,t:1527030863912};\\\", \\\"{x:672,y:728,t:1527030863929};\\\", \\\"{x:688,y:728,t:1527030863945};\\\", \\\"{x:708,y:728,t:1527030863962};\\\", \\\"{x:725,y:728,t:1527030863978};\\\", \\\"{x:747,y:728,t:1527030863996};\\\", \\\"{x:769,y:728,t:1527030864012};\\\", \\\"{x:793,y:727,t:1527030864029};\\\", \\\"{x:832,y:722,t:1527030864045};\\\", \\\"{x:919,y:714,t:1527030864063};\\\", \\\"{x:987,y:710,t:1527030864080};\\\", \\\"{x:1052,y:705,t:1527030864096};\\\", \\\"{x:1117,y:704,t:1527030864113};\\\", \\\"{x:1168,y:702,t:1527030864129};\\\", \\\"{x:1224,y:702,t:1527030864146};\\\", \\\"{x:1268,y:702,t:1527030864163};\\\", \\\"{x:1319,y:702,t:1527030864178};\\\", \\\"{x:1361,y:702,t:1527030864195};\\\", \\\"{x:1403,y:702,t:1527030864212};\\\", \\\"{x:1439,y:702,t:1527030864228};\\\", \\\"{x:1475,y:702,t:1527030864246};\\\", \\\"{x:1526,y:702,t:1527030864263};\\\", \\\"{x:1555,y:702,t:1527030864279};\\\", \\\"{x:1578,y:702,t:1527030864296};\\\", \\\"{x:1594,y:702,t:1527030864313};\\\", \\\"{x:1601,y:702,t:1527030864330};\\\", \\\"{x:1603,y:702,t:1527030864345};\\\", \\\"{x:1602,y:705,t:1527030864424};\\\", \\\"{x:1602,y:708,t:1527030864431};\\\", \\\"{x:1599,y:713,t:1527030864447};\\\", \\\"{x:1595,y:721,t:1527030864463};\\\", \\\"{x:1591,y:729,t:1527030864480};\\\", \\\"{x:1586,y:740,t:1527030864497};\\\", \\\"{x:1582,y:749,t:1527030864514};\\\", \\\"{x:1581,y:756,t:1527030864531};\\\", \\\"{x:1579,y:764,t:1527030864547};\\\", \\\"{x:1579,y:768,t:1527030864563};\\\", \\\"{x:1579,y:772,t:1527030864580};\\\", \\\"{x:1579,y:777,t:1527030864597};\\\", \\\"{x:1579,y:782,t:1527030864614};\\\", \\\"{x:1581,y:787,t:1527030864631};\\\", \\\"{x:1585,y:793,t:1527030864648};\\\", \\\"{x:1587,y:799,t:1527030864663};\\\", \\\"{x:1589,y:803,t:1527030864680};\\\", \\\"{x:1593,y:808,t:1527030864698};\\\", \\\"{x:1597,y:814,t:1527030864714};\\\", \\\"{x:1600,y:816,t:1527030864731};\\\", \\\"{x:1602,y:819,t:1527030864747};\\\", \\\"{x:1603,y:819,t:1527030864763};\\\", \\\"{x:1604,y:820,t:1527030864780};\\\", \\\"{x:1606,y:822,t:1527030864797};\\\", \\\"{x:1607,y:822,t:1527030864815};\\\", \\\"{x:1607,y:823,t:1527030864831};\\\", \\\"{x:1607,y:826,t:1527030864847};\\\", \\\"{x:1607,y:828,t:1527030864872};\\\", \\\"{x:1604,y:830,t:1527030864881};\\\", \\\"{x:1597,y:835,t:1527030864897};\\\", \\\"{x:1582,y:840,t:1527030864913};\\\", \\\"{x:1564,y:845,t:1527030864931};\\\", \\\"{x:1543,y:846,t:1527030864948};\\\", \\\"{x:1512,y:846,t:1527030864963};\\\", \\\"{x:1482,y:846,t:1527030864980};\\\", \\\"{x:1453,y:846,t:1527030864997};\\\", \\\"{x:1430,y:846,t:1527030865015};\\\", \\\"{x:1414,y:846,t:1527030865031};\\\", \\\"{x:1395,y:846,t:1527030865047};\\\", \\\"{x:1382,y:847,t:1527030865063};\\\", \\\"{x:1374,y:847,t:1527030865081};\\\", \\\"{x:1364,y:847,t:1527030865097};\\\", \\\"{x:1357,y:847,t:1527030865115};\\\", \\\"{x:1348,y:848,t:1527030865130};\\\", \\\"{x:1339,y:850,t:1527030865147};\\\", \\\"{x:1334,y:852,t:1527030865163};\\\", \\\"{x:1327,y:852,t:1527030865180};\\\", \\\"{x:1321,y:854,t:1527030865197};\\\", \\\"{x:1316,y:854,t:1527030865214};\\\", \\\"{x:1313,y:855,t:1527030865230};\\\", \\\"{x:1304,y:858,t:1527030865246};\\\", \\\"{x:1301,y:859,t:1527030865263};\\\", \\\"{x:1297,y:862,t:1527030865280};\\\", \\\"{x:1296,y:863,t:1527030865297};\\\", \\\"{x:1294,y:864,t:1527030865313};\\\", \\\"{x:1294,y:865,t:1527030865330};\\\", \\\"{x:1294,y:869,t:1527030865347};\\\", \\\"{x:1294,y:877,t:1527030865365};\\\", \\\"{x:1298,y:882,t:1527030865381};\\\", \\\"{x:1305,y:889,t:1527030865397};\\\", \\\"{x:1313,y:892,t:1527030865414};\\\", \\\"{x:1325,y:900,t:1527030865432};\\\", \\\"{x:1335,y:903,t:1527030865447};\\\", \\\"{x:1343,y:905,t:1527030865465};\\\", \\\"{x:1346,y:907,t:1527030865481};\\\", \\\"{x:1351,y:907,t:1527030865497};\\\", \\\"{x:1354,y:907,t:1527030865514};\\\", \\\"{x:1356,y:907,t:1527030865531};\\\", \\\"{x:1357,y:907,t:1527030865547};\\\", \\\"{x:1360,y:906,t:1527030865564};\\\", \\\"{x:1364,y:903,t:1527030865582};\\\", \\\"{x:1373,y:897,t:1527030865597};\\\", \\\"{x:1384,y:887,t:1527030865615};\\\", \\\"{x:1400,y:875,t:1527030865632};\\\", \\\"{x:1408,y:868,t:1527030865648};\\\", \\\"{x:1419,y:861,t:1527030865664};\\\", \\\"{x:1431,y:855,t:1527030865682};\\\", \\\"{x:1437,y:851,t:1527030865699};\\\", \\\"{x:1445,y:847,t:1527030865715};\\\", \\\"{x:1451,y:842,t:1527030865732};\\\", \\\"{x:1458,y:837,t:1527030865748};\\\", \\\"{x:1463,y:833,t:1527030865764};\\\", \\\"{x:1468,y:828,t:1527030865781};\\\", \\\"{x:1472,y:824,t:1527030865799};\\\", \\\"{x:1476,y:821,t:1527030865814};\\\", \\\"{x:1480,y:816,t:1527030865831};\\\", \\\"{x:1482,y:814,t:1527030865847};\\\", \\\"{x:1482,y:811,t:1527030865865};\\\", \\\"{x:1485,y:805,t:1527030865881};\\\", \\\"{x:1485,y:801,t:1527030865899};\\\", \\\"{x:1485,y:795,t:1527030865914};\\\", \\\"{x:1485,y:789,t:1527030865932};\\\", \\\"{x:1485,y:784,t:1527030865949};\\\", \\\"{x:1485,y:779,t:1527030865964};\\\", \\\"{x:1485,y:774,t:1527030865982};\\\", \\\"{x:1485,y:772,t:1527030865999};\\\", \\\"{x:1485,y:770,t:1527030866014};\\\", \\\"{x:1485,y:769,t:1527030866055};\\\", \\\"{x:1485,y:767,t:1527030866066};\\\", \\\"{x:1485,y:764,t:1527030866082};\\\", \\\"{x:1485,y:757,t:1527030866098};\\\", \\\"{x:1485,y:749,t:1527030866116};\\\", \\\"{x:1485,y:744,t:1527030866131};\\\", \\\"{x:1486,y:737,t:1527030866148};\\\", \\\"{x:1486,y:732,t:1527030866165};\\\", \\\"{x:1487,y:724,t:1527030866182};\\\", \\\"{x:1489,y:718,t:1527030866199};\\\", \\\"{x:1489,y:712,t:1527030866216};\\\", \\\"{x:1490,y:707,t:1527030866231};\\\", \\\"{x:1490,y:705,t:1527030866248};\\\", \\\"{x:1490,y:703,t:1527030866265};\\\", \\\"{x:1490,y:700,t:1527030866632};\\\", \\\"{x:1479,y:667,t:1527030866648};\\\", \\\"{x:1453,y:604,t:1527030866664};\\\", \\\"{x:1428,y:551,t:1527030866682};\\\", \\\"{x:1419,y:527,t:1527030866699};\\\", \\\"{x:1411,y:513,t:1527030866715};\\\", \\\"{x:1406,y:493,t:1527030866732};\\\", \\\"{x:1394,y:470,t:1527030866749};\\\", \\\"{x:1383,y:454,t:1527030866765};\\\", \\\"{x:1373,y:440,t:1527030866781};\\\", \\\"{x:1365,y:428,t:1527030866798};\\\", \\\"{x:1364,y:423,t:1527030866814};\\\", \\\"{x:1364,y:418,t:1527030866832};\\\", \\\"{x:1364,y:413,t:1527030866849};\\\", \\\"{x:1364,y:409,t:1527030866865};\\\", \\\"{x:1364,y:404,t:1527030866882};\\\", \\\"{x:1364,y:402,t:1527030866898};\\\", \\\"{x:1366,y:397,t:1527030866915};\\\", \\\"{x:1367,y:395,t:1527030866931};\\\", \\\"{x:1369,y:394,t:1527030866949};\\\", \\\"{x:1372,y:391,t:1527030866965};\\\", \\\"{x:1375,y:389,t:1527030866982};\\\", \\\"{x:1381,y:386,t:1527030866999};\\\", \\\"{x:1385,y:384,t:1527030867016};\\\", \\\"{x:1389,y:382,t:1527030867032};\\\", \\\"{x:1391,y:380,t:1527030867048};\\\", \\\"{x:1395,y:377,t:1527030867066};\\\", \\\"{x:1398,y:376,t:1527030867082};\\\", \\\"{x:1400,y:374,t:1527030867099};\\\", \\\"{x:1402,y:372,t:1527030867116};\\\", \\\"{x:1403,y:372,t:1527030867131};\\\", \\\"{x:1405,y:370,t:1527030867149};\\\", \\\"{x:1407,y:368,t:1527030867166};\\\", \\\"{x:1408,y:367,t:1527030867182};\\\", \\\"{x:1409,y:366,t:1527030867199};\\\", \\\"{x:1410,y:364,t:1527030867216};\\\", \\\"{x:1411,y:364,t:1527030867232};\\\", \\\"{x:1412,y:369,t:1527030867408};\\\", \\\"{x:1415,y:378,t:1527030867417};\\\", \\\"{x:1420,y:396,t:1527030867433};\\\", \\\"{x:1428,y:413,t:1527030867449};\\\", \\\"{x:1433,y:428,t:1527030867466};\\\", \\\"{x:1442,y:441,t:1527030867483};\\\", \\\"{x:1450,y:455,t:1527030867499};\\\", \\\"{x:1463,y:470,t:1527030867516};\\\", \\\"{x:1482,y:487,t:1527030867533};\\\", \\\"{x:1500,y:508,t:1527030867548};\\\", \\\"{x:1520,y:531,t:1527030867566};\\\", \\\"{x:1549,y:565,t:1527030867582};\\\", \\\"{x:1565,y:587,t:1527030867599};\\\", \\\"{x:1576,y:605,t:1527030867616};\\\", \\\"{x:1585,y:616,t:1527030867633};\\\", \\\"{x:1590,y:624,t:1527030867649};\\\", \\\"{x:1594,y:631,t:1527030867665};\\\", \\\"{x:1597,y:636,t:1527030867682};\\\", \\\"{x:1600,y:640,t:1527030867700};\\\", \\\"{x:1601,y:647,t:1527030867716};\\\", \\\"{x:1602,y:652,t:1527030867733};\\\", \\\"{x:1602,y:656,t:1527030867750};\\\", \\\"{x:1603,y:659,t:1527030867766};\\\", \\\"{x:1603,y:663,t:1527030867783};\\\", \\\"{x:1605,y:668,t:1527030867800};\\\", \\\"{x:1607,y:674,t:1527030867816};\\\", \\\"{x:1610,y:682,t:1527030867833};\\\", \\\"{x:1614,y:691,t:1527030867850};\\\", \\\"{x:1614,y:696,t:1527030867867};\\\", \\\"{x:1615,y:699,t:1527030867883};\\\", \\\"{x:1615,y:701,t:1527030867900};\\\", \\\"{x:1618,y:706,t:1527030867917};\\\", \\\"{x:1620,y:710,t:1527030867933};\\\", \\\"{x:1623,y:714,t:1527030867950};\\\", \\\"{x:1626,y:719,t:1527030867966};\\\", \\\"{x:1627,y:721,t:1527030867983};\\\", \\\"{x:1627,y:722,t:1527030868000};\\\", \\\"{x:1626,y:722,t:1527030868136};\\\", \\\"{x:1623,y:719,t:1527030868150};\\\", \\\"{x:1617,y:713,t:1527030868167};\\\", \\\"{x:1615,y:709,t:1527030868183};\\\", \\\"{x:1612,y:707,t:1527030868200};\\\", \\\"{x:1610,y:705,t:1527030868217};\\\", \\\"{x:1609,y:704,t:1527030868234};\\\", \\\"{x:1607,y:702,t:1527030868251};\\\", \\\"{x:1606,y:702,t:1527030868267};\\\", \\\"{x:1605,y:701,t:1527030868287};\\\", \\\"{x:1605,y:703,t:1527030868438};\\\", \\\"{x:1605,y:707,t:1527030868449};\\\", \\\"{x:1606,y:713,t:1527030868467};\\\", \\\"{x:1609,y:719,t:1527030868483};\\\", \\\"{x:1609,y:723,t:1527030868500};\\\", \\\"{x:1612,y:733,t:1527030868516};\\\", \\\"{x:1617,y:747,t:1527030868534};\\\", \\\"{x:1623,y:768,t:1527030868549};\\\", \\\"{x:1626,y:805,t:1527030868566};\\\", \\\"{x:1629,y:848,t:1527030868584};\\\", \\\"{x:1632,y:900,t:1527030868600};\\\", \\\"{x:1636,y:936,t:1527030868617};\\\", \\\"{x:1638,y:963,t:1527030868634};\\\", \\\"{x:1638,y:984,t:1527030868650};\\\", \\\"{x:1638,y:996,t:1527030868667};\\\", \\\"{x:1638,y:1000,t:1527030868683};\\\", \\\"{x:1638,y:1003,t:1527030868701};\\\", \\\"{x:1638,y:1004,t:1527030868717};\\\", \\\"{x:1638,y:1007,t:1527030868734};\\\", \\\"{x:1638,y:1012,t:1527030868751};\\\", \\\"{x:1638,y:1014,t:1527030868767};\\\", \\\"{x:1637,y:1018,t:1527030868784};\\\", \\\"{x:1636,y:1018,t:1527030868807};\\\", \\\"{x:1636,y:1017,t:1527030868887};\\\", \\\"{x:1633,y:1014,t:1527030868901};\\\", \\\"{x:1628,y:1005,t:1527030868918};\\\", \\\"{x:1624,y:998,t:1527030868934};\\\", \\\"{x:1621,y:992,t:1527030868951};\\\", \\\"{x:1620,y:989,t:1527030868968};\\\", \\\"{x:1619,y:988,t:1527030868984};\\\", \\\"{x:1618,y:987,t:1527030869015};\\\", \\\"{x:1617,y:986,t:1527030869056};\\\", \\\"{x:1617,y:985,t:1527030869343};\\\", \\\"{x:1617,y:982,t:1527030869351};\\\", \\\"{x:1616,y:979,t:1527030869375};\\\", \\\"{x:1615,y:977,t:1527030869385};\\\", \\\"{x:1614,y:972,t:1527030869402};\\\", \\\"{x:1613,y:970,t:1527030869419};\\\", \\\"{x:1612,y:968,t:1527030869436};\\\", \\\"{x:1611,y:967,t:1527030869451};\\\", \\\"{x:1611,y:966,t:1527030869468};\\\", \\\"{x:1611,y:965,t:1527030869485};\\\", \\\"{x:1611,y:964,t:1527030869502};\\\", \\\"{x:1611,y:961,t:1527030870208};\\\", \\\"{x:1611,y:959,t:1527030870219};\\\", \\\"{x:1610,y:956,t:1527030870236};\\\", \\\"{x:1609,y:953,t:1527030870253};\\\", \\\"{x:1608,y:950,t:1527030870269};\\\", \\\"{x:1608,y:949,t:1527030870296};\\\", \\\"{x:1608,y:948,t:1527030870312};\\\", \\\"{x:1607,y:946,t:1527030870680};\\\", \\\"{x:1604,y:943,t:1527030870688};\\\", \\\"{x:1596,y:934,t:1527030870702};\\\", \\\"{x:1583,y:917,t:1527030870719};\\\", \\\"{x:1568,y:901,t:1527030870736};\\\", \\\"{x:1554,y:889,t:1527030870752};\\\", \\\"{x:1539,y:879,t:1527030870769};\\\", \\\"{x:1526,y:869,t:1527030870786};\\\", \\\"{x:1513,y:860,t:1527030870803};\\\", \\\"{x:1504,y:854,t:1527030870819};\\\", \\\"{x:1502,y:852,t:1527030870836};\\\", \\\"{x:1499,y:849,t:1527030870853};\\\", \\\"{x:1498,y:848,t:1527030870869};\\\", \\\"{x:1497,y:848,t:1527030870886};\\\", \\\"{x:1496,y:846,t:1527030871088};\\\", \\\"{x:1493,y:843,t:1527030871103};\\\", \\\"{x:1493,y:842,t:1527030871120};\\\", \\\"{x:1492,y:842,t:1527030871136};\\\", \\\"{x:1492,y:841,t:1527030871166};\\\", \\\"{x:1491,y:840,t:1527030871183};\\\", \\\"{x:1491,y:839,t:1527030871191};\\\", \\\"{x:1490,y:839,t:1527030871215};\\\", \\\"{x:1490,y:838,t:1527030871238};\\\", \\\"{x:1489,y:838,t:1527030871255};\\\", \\\"{x:1488,y:837,t:1527030871279};\\\", \\\"{x:1488,y:836,t:1527030871311};\\\", \\\"{x:1486,y:836,t:1527030871327};\\\", \\\"{x:1486,y:835,t:1527030871359};\\\", \\\"{x:1485,y:835,t:1527030871415};\\\", \\\"{x:1484,y:835,t:1527030871464};\\\", \\\"{x:1483,y:835,t:1527030871480};\\\", \\\"{x:1482,y:835,t:1527030871503};\\\", \\\"{x:1481,y:835,t:1527030871527};\\\", \\\"{x:1480,y:834,t:1527030871558};\\\", \\\"{x:1480,y:833,t:1527030871574};\\\", \\\"{x:1479,y:833,t:1527030871687};\\\", \\\"{x:1479,y:832,t:1527030871703};\\\", \\\"{x:1479,y:836,t:1527030872105};\\\", \\\"{x:1481,y:846,t:1527030872122};\\\", \\\"{x:1483,y:854,t:1527030872138};\\\", \\\"{x:1485,y:866,t:1527030872154};\\\", \\\"{x:1488,y:875,t:1527030872171};\\\", \\\"{x:1490,y:884,t:1527030872187};\\\", \\\"{x:1492,y:890,t:1527030872204};\\\", \\\"{x:1493,y:892,t:1527030872222};\\\", \\\"{x:1494,y:894,t:1527030872237};\\\", \\\"{x:1494,y:895,t:1527030872288};\\\", \\\"{x:1494,y:898,t:1527030872305};\\\", \\\"{x:1494,y:901,t:1527030872321};\\\", \\\"{x:1494,y:903,t:1527030872337};\\\", \\\"{x:1494,y:904,t:1527030872355};\\\", \\\"{x:1494,y:908,t:1527030872371};\\\", \\\"{x:1493,y:911,t:1527030872388};\\\", \\\"{x:1492,y:916,t:1527030872404};\\\", \\\"{x:1492,y:919,t:1527030872422};\\\", \\\"{x:1492,y:925,t:1527030872438};\\\", \\\"{x:1492,y:931,t:1527030872455};\\\", \\\"{x:1490,y:936,t:1527030872471};\\\", \\\"{x:1488,y:938,t:1527030872488};\\\", \\\"{x:1487,y:938,t:1527030872511};\\\", \\\"{x:1486,y:938,t:1527030872527};\\\", \\\"{x:1483,y:938,t:1527030872538};\\\", \\\"{x:1468,y:929,t:1527030872554};\\\", \\\"{x:1439,y:912,t:1527030872572};\\\", \\\"{x:1393,y:885,t:1527030872588};\\\", \\\"{x:1313,y:839,t:1527030872604};\\\", \\\"{x:1217,y:796,t:1527030872622};\\\", \\\"{x:1147,y:773,t:1527030872639};\\\", \\\"{x:1055,y:745,t:1527030872655};\\\", \\\"{x:1007,y:732,t:1527030872671};\\\", \\\"{x:972,y:718,t:1527030872688};\\\", \\\"{x:949,y:711,t:1527030872706};\\\", \\\"{x:936,y:708,t:1527030872722};\\\", \\\"{x:931,y:707,t:1527030872739};\\\", \\\"{x:930,y:707,t:1527030872815};\\\", \\\"{x:927,y:707,t:1527030872823};\\\", \\\"{x:926,y:707,t:1527030872839};\\\", \\\"{x:920,y:707,t:1527030872855};\\\", \\\"{x:917,y:708,t:1527030872872};\\\", \\\"{x:913,y:711,t:1527030872888};\\\", \\\"{x:909,y:712,t:1527030872905};\\\", \\\"{x:905,y:715,t:1527030872922};\\\", \\\"{x:898,y:720,t:1527030872938};\\\", \\\"{x:894,y:723,t:1527030872955};\\\", \\\"{x:891,y:727,t:1527030872971};\\\", \\\"{x:888,y:731,t:1527030872989};\\\", \\\"{x:886,y:734,t:1527030873005};\\\", \\\"{x:885,y:734,t:1527030873023};\\\", \\\"{x:883,y:735,t:1527030873038};\\\", \\\"{x:882,y:735,t:1527030873055};\\\", \\\"{x:881,y:736,t:1527030873072};\\\", \\\"{x:880,y:736,t:1527030873111};\\\", \\\"{x:879,y:735,t:1527030873122};\\\", \\\"{x:871,y:731,t:1527030873138};\\\", \\\"{x:863,y:727,t:1527030873155};\\\", \\\"{x:848,y:721,t:1527030873172};\\\", \\\"{x:834,y:714,t:1527030873187};\\\", \\\"{x:820,y:707,t:1527030873205};\\\", \\\"{x:809,y:701,t:1527030873222};\\\", \\\"{x:800,y:696,t:1527030873238};\\\", \\\"{x:795,y:691,t:1527030873255};\\\", \\\"{x:794,y:690,t:1527030873279};\\\", \\\"{x:793,y:690,t:1527030873295};\\\", \\\"{x:793,y:688,t:1527030873615};\\\", \\\"{x:792,y:686,t:1527030873623};\\\", \\\"{x:789,y:679,t:1527030873639};\\\", \\\"{x:784,y:671,t:1527030873656};\\\", \\\"{x:777,y:660,t:1527030873672};\\\", \\\"{x:767,y:648,t:1527030873689};\\\", \\\"{x:754,y:635,t:1527030873706};\\\", \\\"{x:740,y:621,t:1527030873724};\\\", \\\"{x:725,y:604,t:1527030873739};\\\", \\\"{x:715,y:592,t:1527030873756};\\\", \\\"{x:710,y:585,t:1527030873770};\\\", \\\"{x:705,y:576,t:1527030873786};\\\", \\\"{x:700,y:564,t:1527030873803};\\\", \\\"{x:693,y:547,t:1527030873821};\\\", \\\"{x:684,y:533,t:1527030873837};\\\", \\\"{x:674,y:520,t:1527030873853};\\\", \\\"{x:666,y:513,t:1527030873870};\\\", \\\"{x:651,y:507,t:1527030873886};\\\", \\\"{x:640,y:504,t:1527030873903};\\\", \\\"{x:632,y:504,t:1527030873920};\\\", \\\"{x:619,y:503,t:1527030873937};\\\", \\\"{x:608,y:503,t:1527030873953};\\\", \\\"{x:594,y:503,t:1527030873970};\\\", \\\"{x:583,y:503,t:1527030873987};\\\", \\\"{x:577,y:503,t:1527030874003};\\\", \\\"{x:568,y:505,t:1527030874020};\\\", \\\"{x:564,y:507,t:1527030874037};\\\", \\\"{x:559,y:509,t:1527030874053};\\\", \\\"{x:556,y:511,t:1527030874070};\\\", \\\"{x:554,y:513,t:1527030874087};\\\", \\\"{x:552,y:514,t:1527030874104};\\\", \\\"{x:550,y:516,t:1527030874121};\\\", \\\"{x:550,y:517,t:1527030874137};\\\", \\\"{x:549,y:518,t:1527030874155};\\\", \\\"{x:548,y:519,t:1527030874199};\\\", \\\"{x:547,y:519,t:1527030874206};\\\", \\\"{x:546,y:520,t:1527030874231};\\\", \\\"{x:545,y:521,t:1527030874246};\\\", \\\"{x:544,y:521,t:1527030874254};\\\", \\\"{x:544,y:522,t:1527030874270};\\\", \\\"{x:541,y:523,t:1527030874287};\\\", \\\"{x:540,y:524,t:1527030874327};\\\", \\\"{x:539,y:524,t:1527030874337};\\\", \\\"{x:538,y:525,t:1527030874376};\\\", \\\"{x:537,y:525,t:1527030874407};\\\", \\\"{x:536,y:526,t:1527030874420};\\\", \\\"{x:534,y:526,t:1527030874437};\\\", \\\"{x:530,y:528,t:1527030874454};\\\", \\\"{x:527,y:528,t:1527030874471};\\\", \\\"{x:524,y:529,t:1527030874487};\\\", \\\"{x:521,y:529,t:1527030874504};\\\", \\\"{x:518,y:529,t:1527030874520};\\\", \\\"{x:516,y:529,t:1527030874537};\\\", \\\"{x:514,y:529,t:1527030874555};\\\", \\\"{x:509,y:529,t:1527030874571};\\\", \\\"{x:505,y:529,t:1527030874587};\\\", \\\"{x:501,y:529,t:1527030874604};\\\", \\\"{x:496,y:529,t:1527030874624};\\\", \\\"{x:490,y:528,t:1527030874637};\\\", \\\"{x:487,y:527,t:1527030874653};\\\", \\\"{x:483,y:526,t:1527030874671};\\\", \\\"{x:482,y:526,t:1527030874687};\\\", \\\"{x:481,y:525,t:1527030874704};\\\", \\\"{x:480,y:525,t:1527030874721};\\\", \\\"{x:477,y:524,t:1527030874737};\\\", \\\"{x:473,y:524,t:1527030874754};\\\", \\\"{x:469,y:523,t:1527030874771};\\\", \\\"{x:464,y:523,t:1527030874787};\\\", \\\"{x:461,y:521,t:1527030874804};\\\", \\\"{x:458,y:521,t:1527030874821};\\\", \\\"{x:454,y:521,t:1527030874837};\\\", \\\"{x:451,y:521,t:1527030874854};\\\", \\\"{x:445,y:521,t:1527030874870};\\\", \\\"{x:442,y:522,t:1527030874887};\\\", \\\"{x:440,y:522,t:1527030874904};\\\", \\\"{x:437,y:522,t:1527030874921};\\\", \\\"{x:435,y:524,t:1527030874937};\\\", \\\"{x:434,y:524,t:1527030874958};\\\", \\\"{x:432,y:524,t:1527030874975};\\\", \\\"{x:430,y:524,t:1527030874991};\\\", \\\"{x:429,y:524,t:1527030875004};\\\", \\\"{x:426,y:524,t:1527030875021};\\\", \\\"{x:421,y:525,t:1527030875038};\\\", \\\"{x:416,y:526,t:1527030875055};\\\", \\\"{x:404,y:528,t:1527030875072};\\\", \\\"{x:392,y:529,t:1527030875089};\\\", \\\"{x:378,y:529,t:1527030875104};\\\", \\\"{x:360,y:529,t:1527030875122};\\\", \\\"{x:343,y:530,t:1527030875138};\\\", \\\"{x:326,y:531,t:1527030875154};\\\", \\\"{x:310,y:531,t:1527030875171};\\\", \\\"{x:292,y:534,t:1527030875188};\\\", \\\"{x:281,y:535,t:1527030875205};\\\", \\\"{x:268,y:538,t:1527030875222};\\\", \\\"{x:258,y:541,t:1527030875238};\\\", \\\"{x:239,y:548,t:1527030875254};\\\", \\\"{x:227,y:551,t:1527030875271};\\\", \\\"{x:216,y:556,t:1527030875289};\\\", \\\"{x:207,y:559,t:1527030875304};\\\", \\\"{x:200,y:565,t:1527030875322};\\\", \\\"{x:195,y:568,t:1527030875338};\\\", \\\"{x:189,y:573,t:1527030875354};\\\", \\\"{x:187,y:581,t:1527030875371};\\\", \\\"{x:187,y:593,t:1527030875389};\\\", \\\"{x:190,y:609,t:1527030875406};\\\", \\\"{x:203,y:622,t:1527030875422};\\\", \\\"{x:227,y:634,t:1527030875439};\\\", \\\"{x:278,y:658,t:1527030875456};\\\", \\\"{x:313,y:665,t:1527030875471};\\\", \\\"{x:343,y:666,t:1527030875488};\\\", \\\"{x:371,y:666,t:1527030875504};\\\", \\\"{x:401,y:666,t:1527030875520};\\\", \\\"{x:428,y:663,t:1527030875538};\\\", \\\"{x:466,y:658,t:1527030875554};\\\", \\\"{x:504,y:650,t:1527030875572};\\\", \\\"{x:531,y:643,t:1527030875588};\\\", \\\"{x:548,y:638,t:1527030875604};\\\", \\\"{x:556,y:634,t:1527030875621};\\\", \\\"{x:558,y:632,t:1527030875638};\\\", \\\"{x:560,y:627,t:1527030875655};\\\", \\\"{x:564,y:621,t:1527030875671};\\\", \\\"{x:567,y:617,t:1527030875688};\\\", \\\"{x:570,y:614,t:1527030875705};\\\", \\\"{x:571,y:612,t:1527030875721};\\\", \\\"{x:573,y:610,t:1527030875737};\\\", \\\"{x:574,y:609,t:1527030875755};\\\", \\\"{x:575,y:606,t:1527030875771};\\\", \\\"{x:578,y:603,t:1527030875788};\\\", \\\"{x:581,y:600,t:1527030875806};\\\", \\\"{x:582,y:596,t:1527030875821};\\\", \\\"{x:583,y:594,t:1527030875838};\\\", \\\"{x:584,y:594,t:1527030875854};\\\", \\\"{x:586,y:592,t:1527030875874};\\\", \\\"{x:589,y:589,t:1527030875888};\\\", \\\"{x:590,y:587,t:1527030875905};\\\", \\\"{x:592,y:585,t:1527030875922};\\\", \\\"{x:593,y:584,t:1527030875938};\\\", \\\"{x:594,y:582,t:1527030875955};\\\", \\\"{x:596,y:580,t:1527030875972};\\\", \\\"{x:597,y:580,t:1527030875988};\\\", \\\"{x:598,y:578,t:1527030876005};\\\", \\\"{x:598,y:577,t:1527030876022};\\\", \\\"{x:599,y:577,t:1527030876047};\\\", \\\"{x:600,y:577,t:1527030876055};\\\", \\\"{x:600,y:576,t:1527030876086};\\\", \\\"{x:602,y:577,t:1527030876446};\\\", \\\"{x:611,y:586,t:1527030876455};\\\", \\\"{x:632,y:603,t:1527030876473};\\\", \\\"{x:658,y:623,t:1527030876489};\\\", \\\"{x:693,y:643,t:1527030876505};\\\", \\\"{x:744,y:671,t:1527030876522};\\\", \\\"{x:814,y:704,t:1527030876539};\\\", \\\"{x:907,y:741,t:1527030876555};\\\", \\\"{x:995,y:781,t:1527030876573};\\\", \\\"{x:1083,y:814,t:1527030876589};\\\", \\\"{x:1171,y:851,t:1527030876605};\\\", \\\"{x:1292,y:893,t:1527030876623};\\\", \\\"{x:1361,y:914,t:1527030876639};\\\", \\\"{x:1423,y:933,t:1527030876655};\\\", \\\"{x:1462,y:937,t:1527030876672};\\\", \\\"{x:1485,y:939,t:1527030876689};\\\", \\\"{x:1501,y:939,t:1527030876705};\\\", \\\"{x:1516,y:934,t:1527030876723};\\\", \\\"{x:1526,y:929,t:1527030876739};\\\", \\\"{x:1533,y:924,t:1527030876756};\\\", \\\"{x:1539,y:919,t:1527030876773};\\\", \\\"{x:1544,y:915,t:1527030876789};\\\", \\\"{x:1547,y:906,t:1527030876806};\\\", \\\"{x:1550,y:898,t:1527030876823};\\\", \\\"{x:1552,y:886,t:1527030876839};\\\", \\\"{x:1552,y:870,t:1527030876857};\\\", \\\"{x:1551,y:860,t:1527030876872};\\\", \\\"{x:1548,y:851,t:1527030876889};\\\", \\\"{x:1544,y:845,t:1527030876906};\\\", \\\"{x:1540,y:841,t:1527030876923};\\\", \\\"{x:1534,y:835,t:1527030876939};\\\", \\\"{x:1531,y:834,t:1527030876957};\\\", \\\"{x:1526,y:833,t:1527030876973};\\\", \\\"{x:1522,y:830,t:1527030876990};\\\", \\\"{x:1516,y:830,t:1527030877006};\\\", \\\"{x:1515,y:829,t:1527030877022};\\\", \\\"{x:1512,y:828,t:1527030877039};\\\", \\\"{x:1510,y:826,t:1527030877056};\\\", \\\"{x:1508,y:824,t:1527030877072};\\\", \\\"{x:1506,y:822,t:1527030877089};\\\", \\\"{x:1505,y:820,t:1527030877107};\\\", \\\"{x:1505,y:817,t:1527030877122};\\\", \\\"{x:1504,y:815,t:1527030877139};\\\", \\\"{x:1503,y:812,t:1527030877157};\\\", \\\"{x:1501,y:810,t:1527030877173};\\\", \\\"{x:1499,y:808,t:1527030877189};\\\", \\\"{x:1499,y:807,t:1527030877207};\\\", \\\"{x:1499,y:806,t:1527030877280};\\\", \\\"{x:1499,y:804,t:1527030877290};\\\", \\\"{x:1499,y:802,t:1527030877307};\\\", \\\"{x:1499,y:800,t:1527030877323};\\\", \\\"{x:1499,y:797,t:1527030877339};\\\", \\\"{x:1501,y:793,t:1527030877356};\\\", \\\"{x:1503,y:790,t:1527030877374};\\\", \\\"{x:1503,y:787,t:1527030877390};\\\", \\\"{x:1505,y:783,t:1527030877407};\\\", \\\"{x:1506,y:783,t:1527030877423};\\\", \\\"{x:1507,y:780,t:1527030877440};\\\", \\\"{x:1507,y:778,t:1527030877488};\\\", \\\"{x:1507,y:777,t:1527030877511};\\\", \\\"{x:1509,y:775,t:1527030877524};\\\", \\\"{x:1509,y:774,t:1527030877540};\\\", \\\"{x:1509,y:772,t:1527030877560};\\\", \\\"{x:1510,y:770,t:1527030877573};\\\", \\\"{x:1510,y:768,t:1527030877590};\\\", \\\"{x:1512,y:766,t:1527030877607};\\\", \\\"{x:1512,y:765,t:1527030877640};\\\", \\\"{x:1507,y:765,t:1527030880593};\\\", \\\"{x:1496,y:774,t:1527030880609};\\\", \\\"{x:1482,y:786,t:1527030880626};\\\", \\\"{x:1461,y:802,t:1527030880643};\\\", \\\"{x:1441,y:816,t:1527030880659};\\\", \\\"{x:1421,y:831,t:1527030880676};\\\", \\\"{x:1404,y:843,t:1527030880693};\\\", \\\"{x:1387,y:855,t:1527030880710};\\\", \\\"{x:1374,y:863,t:1527030880725};\\\", \\\"{x:1359,y:876,t:1527030880742};\\\", \\\"{x:1352,y:883,t:1527030880759};\\\", \\\"{x:1346,y:891,t:1527030880775};\\\", \\\"{x:1342,y:897,t:1527030880792};\\\", \\\"{x:1338,y:904,t:1527030880809};\\\", \\\"{x:1335,y:910,t:1527030880825};\\\", \\\"{x:1334,y:912,t:1527030880843};\\\", \\\"{x:1332,y:916,t:1527030880860};\\\", \\\"{x:1332,y:915,t:1527030881032};\\\", \\\"{x:1332,y:908,t:1527030881043};\\\", \\\"{x:1332,y:897,t:1527030881060};\\\", \\\"{x:1332,y:885,t:1527030881076};\\\", \\\"{x:1332,y:874,t:1527030881092};\\\", \\\"{x:1332,y:866,t:1527030881110};\\\", \\\"{x:1331,y:863,t:1527030881127};\\\", \\\"{x:1331,y:862,t:1527030881142};\\\", \\\"{x:1331,y:860,t:1527030881159};\\\", \\\"{x:1330,y:859,t:1527030881177};\\\", \\\"{x:1330,y:857,t:1527030881207};\\\", \\\"{x:1329,y:856,t:1527030881214};\\\", \\\"{x:1329,y:855,t:1527030881226};\\\", \\\"{x:1328,y:853,t:1527030881242};\\\", \\\"{x:1327,y:848,t:1527030881259};\\\", \\\"{x:1326,y:843,t:1527030881276};\\\", \\\"{x:1325,y:837,t:1527030881292};\\\", \\\"{x:1324,y:826,t:1527030881309};\\\", \\\"{x:1322,y:811,t:1527030881327};\\\", \\\"{x:1320,y:801,t:1527030881343};\\\", \\\"{x:1319,y:792,t:1527030881360};\\\", \\\"{x:1319,y:786,t:1527030881377};\\\", \\\"{x:1319,y:782,t:1527030881392};\\\", \\\"{x:1319,y:778,t:1527030881409};\\\", \\\"{x:1319,y:776,t:1527030881426};\\\", \\\"{x:1319,y:775,t:1527030881442};\\\", \\\"{x:1319,y:774,t:1527030881702};\\\", \\\"{x:1319,y:773,t:1527030881719};\\\", \\\"{x:1320,y:772,t:1527030881727};\\\", \\\"{x:1321,y:771,t:1527030881743};\\\", \\\"{x:1322,y:771,t:1527030881822};\\\", \\\"{x:1322,y:770,t:1527030881831};\\\", \\\"{x:1322,y:769,t:1527030881846};\\\", \\\"{x:1323,y:769,t:1527030881859};\\\", \\\"{x:1324,y:766,t:1527030881877};\\\", \\\"{x:1325,y:765,t:1527030881894};\\\", \\\"{x:1327,y:762,t:1527030881910};\\\", \\\"{x:1329,y:760,t:1527030881926};\\\", \\\"{x:1330,y:758,t:1527030881943};\\\", \\\"{x:1331,y:757,t:1527030881960};\\\", \\\"{x:1331,y:755,t:1527030883432};\\\", \\\"{x:1332,y:752,t:1527030883445};\\\", \\\"{x:1332,y:748,t:1527030883462};\\\", \\\"{x:1332,y:745,t:1527030883478};\\\", \\\"{x:1332,y:741,t:1527030883495};\\\", \\\"{x:1332,y:739,t:1527030883511};\\\", \\\"{x:1332,y:736,t:1527030883527};\\\", \\\"{x:1332,y:734,t:1527030883545};\\\", \\\"{x:1332,y:732,t:1527030883561};\\\", \\\"{x:1332,y:729,t:1527030883577};\\\", \\\"{x:1332,y:727,t:1527030883594};\\\", \\\"{x:1332,y:726,t:1527030883611};\\\", \\\"{x:1332,y:725,t:1527030883628};\\\", \\\"{x:1332,y:723,t:1527030883645};\\\", \\\"{x:1332,y:722,t:1527030883663};\\\", \\\"{x:1332,y:721,t:1527030883678};\\\", \\\"{x:1332,y:718,t:1527030883694};\\\", \\\"{x:1332,y:716,t:1527030883711};\\\", \\\"{x:1332,y:715,t:1527030883729};\\\", \\\"{x:1333,y:714,t:1527030883745};\\\", \\\"{x:1333,y:713,t:1527030883762};\\\", \\\"{x:1334,y:712,t:1527030883779};\\\", \\\"{x:1335,y:711,t:1527030883795};\\\", \\\"{x:1335,y:710,t:1527030883815};\\\", \\\"{x:1335,y:709,t:1527030883829};\\\", \\\"{x:1335,y:708,t:1527030883863};\\\", \\\"{x:1336,y:708,t:1527030883879};\\\", \\\"{x:1336,y:707,t:1527030883895};\\\", \\\"{x:1337,y:706,t:1527030883912};\\\", \\\"{x:1338,y:705,t:1527030883928};\\\", \\\"{x:1339,y:704,t:1527030883945};\\\", \\\"{x:1339,y:702,t:1527030883962};\\\", \\\"{x:1340,y:701,t:1527030883979};\\\", \\\"{x:1341,y:701,t:1527030883995};\\\", \\\"{x:1341,y:700,t:1527030884012};\\\", \\\"{x:1341,y:698,t:1527030884488};\\\", \\\"{x:1334,y:697,t:1527030884496};\\\", \\\"{x:1316,y:693,t:1527030884512};\\\", \\\"{x:1296,y:687,t:1527030884529};\\\", \\\"{x:1276,y:683,t:1527030884545};\\\", \\\"{x:1257,y:678,t:1527030884562};\\\", \\\"{x:1247,y:677,t:1527030884579};\\\", \\\"{x:1237,y:676,t:1527030884596};\\\", \\\"{x:1227,y:674,t:1527030884613};\\\", \\\"{x:1219,y:673,t:1527030884628};\\\", \\\"{x:1212,y:672,t:1527030884645};\\\", \\\"{x:1207,y:672,t:1527030884663};\\\", \\\"{x:1199,y:672,t:1527030884679};\\\", \\\"{x:1192,y:672,t:1527030884696};\\\", \\\"{x:1178,y:672,t:1527030884713};\\\", \\\"{x:1159,y:672,t:1527030884729};\\\", \\\"{x:1139,y:672,t:1527030884746};\\\", \\\"{x:1116,y:672,t:1527030884763};\\\", \\\"{x:1089,y:671,t:1527030884779};\\\", \\\"{x:1057,y:671,t:1527030884796};\\\", \\\"{x:1030,y:671,t:1527030884813};\\\", \\\"{x:1003,y:671,t:1527030884829};\\\", \\\"{x:976,y:671,t:1527030884846};\\\", \\\"{x:935,y:671,t:1527030884862};\\\", \\\"{x:912,y:671,t:1527030884879};\\\", \\\"{x:891,y:671,t:1527030884896};\\\", \\\"{x:870,y:671,t:1527030884913};\\\", \\\"{x:843,y:671,t:1527030884929};\\\", \\\"{x:817,y:671,t:1527030884946};\\\", \\\"{x:799,y:669,t:1527030884962};\\\", \\\"{x:788,y:669,t:1527030884979};\\\", \\\"{x:774,y:669,t:1527030884996};\\\", \\\"{x:761,y:669,t:1527030885013};\\\", \\\"{x:747,y:668,t:1527030885030};\\\", \\\"{x:735,y:667,t:1527030885046};\\\", \\\"{x:720,y:666,t:1527030885063};\\\", \\\"{x:709,y:666,t:1527030885080};\\\", \\\"{x:703,y:666,t:1527030885096};\\\", \\\"{x:696,y:666,t:1527030885113};\\\", \\\"{x:693,y:666,t:1527030885130};\\\", \\\"{x:690,y:666,t:1527030885146};\\\", \\\"{x:688,y:666,t:1527030885163};\\\", \\\"{x:681,y:666,t:1527030885180};\\\", \\\"{x:669,y:664,t:1527030885195};\\\", \\\"{x:652,y:656,t:1527030885213};\\\", \\\"{x:620,y:641,t:1527030885230};\\\", \\\"{x:589,y:627,t:1527030885247};\\\", \\\"{x:540,y:602,t:1527030885262};\\\", \\\"{x:520,y:593,t:1527030885280};\\\", \\\"{x:508,y:589,t:1527030885296};\\\", \\\"{x:499,y:587,t:1527030885312};\\\", \\\"{x:491,y:584,t:1527030885330};\\\", \\\"{x:485,y:583,t:1527030885346};\\\", \\\"{x:478,y:579,t:1527030885362};\\\", \\\"{x:474,y:578,t:1527030885380};\\\", \\\"{x:471,y:577,t:1527030885396};\\\", \\\"{x:470,y:576,t:1527030885422};\\\", \\\"{x:469,y:576,t:1527030885487};\\\", \\\"{x:469,y:574,t:1527030885496};\\\", \\\"{x:468,y:569,t:1527030885512};\\\", \\\"{x:465,y:560,t:1527030885530};\\\", \\\"{x:463,y:556,t:1527030885546};\\\", \\\"{x:460,y:552,t:1527030885562};\\\", \\\"{x:456,y:548,t:1527030885580};\\\", \\\"{x:453,y:546,t:1527030885596};\\\", \\\"{x:446,y:544,t:1527030885612};\\\", \\\"{x:441,y:543,t:1527030885630};\\\", \\\"{x:429,y:543,t:1527030885646};\\\", \\\"{x:415,y:543,t:1527030885662};\\\", \\\"{x:399,y:543,t:1527030885679};\\\", \\\"{x:378,y:543,t:1527030885696};\\\", \\\"{x:359,y:543,t:1527030885713};\\\", \\\"{x:339,y:543,t:1527030885729};\\\", \\\"{x:320,y:541,t:1527030885747};\\\", \\\"{x:303,y:541,t:1527030885762};\\\", \\\"{x:289,y:541,t:1527030885780};\\\", \\\"{x:281,y:541,t:1527030885797};\\\", \\\"{x:280,y:541,t:1527030885848};\\\", \\\"{x:283,y:544,t:1527030885863};\\\", \\\"{x:297,y:545,t:1527030885880};\\\", \\\"{x:316,y:547,t:1527030885896};\\\", \\\"{x:349,y:549,t:1527030885914};\\\", \\\"{x:392,y:549,t:1527030885930};\\\", \\\"{x:442,y:549,t:1527030885947};\\\", \\\"{x:487,y:549,t:1527030885963};\\\", \\\"{x:534,y:549,t:1527030885980};\\\", \\\"{x:579,y:549,t:1527030885997};\\\", \\\"{x:613,y:549,t:1527030886013};\\\", \\\"{x:637,y:549,t:1527030886029};\\\", \\\"{x:663,y:549,t:1527030886047};\\\", \\\"{x:669,y:549,t:1527030886063};\\\", \\\"{x:668,y:549,t:1527030886110};\\\", \\\"{x:664,y:549,t:1527030886126};\\\", \\\"{x:660,y:549,t:1527030886134};\\\", \\\"{x:654,y:549,t:1527030886146};\\\", \\\"{x:638,y:549,t:1527030886163};\\\", \\\"{x:615,y:549,t:1527030886179};\\\", \\\"{x:586,y:549,t:1527030886197};\\\", \\\"{x:555,y:549,t:1527030886213};\\\", \\\"{x:514,y:549,t:1527030886230};\\\", \\\"{x:493,y:549,t:1527030886247};\\\", \\\"{x:477,y:549,t:1527030886263};\\\", \\\"{x:470,y:549,t:1527030886280};\\\", \\\"{x:468,y:549,t:1527030886296};\\\", \\\"{x:467,y:549,t:1527030886313};\\\", \\\"{x:466,y:549,t:1527030886359};\\\", \\\"{x:465,y:549,t:1527030886375};\\\", \\\"{x:463,y:549,t:1527030886383};\\\", \\\"{x:461,y:549,t:1527030886397};\\\", \\\"{x:455,y:550,t:1527030886414};\\\", \\\"{x:442,y:552,t:1527030886431};\\\", \\\"{x:429,y:555,t:1527030886446};\\\", \\\"{x:415,y:556,t:1527030886465};\\\", \\\"{x:401,y:559,t:1527030886480};\\\", \\\"{x:392,y:560,t:1527030886496};\\\", \\\"{x:385,y:561,t:1527030886514};\\\", \\\"{x:380,y:561,t:1527030886531};\\\", \\\"{x:376,y:563,t:1527030886547};\\\", \\\"{x:374,y:564,t:1527030886563};\\\", \\\"{x:373,y:564,t:1527030886582};\\\", \\\"{x:372,y:564,t:1527030886630};\\\", \\\"{x:371,y:565,t:1527030886648};\\\", \\\"{x:369,y:566,t:1527030886663};\\\", \\\"{x:366,y:567,t:1527030886681};\\\", \\\"{x:361,y:570,t:1527030886698};\\\", \\\"{x:356,y:571,t:1527030886713};\\\", \\\"{x:349,y:572,t:1527030886731};\\\", \\\"{x:340,y:575,t:1527030886747};\\\", \\\"{x:331,y:576,t:1527030886764};\\\", \\\"{x:320,y:577,t:1527030886781};\\\", \\\"{x:309,y:579,t:1527030886797};\\\", \\\"{x:301,y:580,t:1527030886814};\\\", \\\"{x:284,y:580,t:1527030886831};\\\", \\\"{x:276,y:580,t:1527030886847};\\\", \\\"{x:266,y:580,t:1527030886865};\\\", \\\"{x:257,y:581,t:1527030886880};\\\", \\\"{x:244,y:584,t:1527030886897};\\\", \\\"{x:234,y:584,t:1527030886913};\\\", \\\"{x:223,y:586,t:1527030886930};\\\", \\\"{x:208,y:589,t:1527030886948};\\\", \\\"{x:199,y:590,t:1527030886963};\\\", \\\"{x:191,y:591,t:1527030886980};\\\", \\\"{x:186,y:593,t:1527030886998};\\\", \\\"{x:183,y:593,t:1527030887013};\\\", \\\"{x:178,y:594,t:1527030887031};\\\", \\\"{x:177,y:594,t:1527030887048};\\\", \\\"{x:176,y:594,t:1527030887064};\\\", \\\"{x:176,y:595,t:1527030887103};\\\", \\\"{x:181,y:595,t:1527030887115};\\\", \\\"{x:204,y:595,t:1527030887131};\\\", \\\"{x:253,y:595,t:1527030887148};\\\", \\\"{x:311,y:595,t:1527030887165};\\\", \\\"{x:376,y:595,t:1527030887181};\\\", \\\"{x:434,y:595,t:1527030887197};\\\", \\\"{x:515,y:595,t:1527030887214};\\\", \\\"{x:563,y:595,t:1527030887230};\\\", \\\"{x:599,y:595,t:1527030887248};\\\", \\\"{x:624,y:595,t:1527030887265};\\\", \\\"{x:641,y:595,t:1527030887281};\\\", \\\"{x:648,y:592,t:1527030887299};\\\", \\\"{x:650,y:591,t:1527030887316};\\\", \\\"{x:651,y:591,t:1527030887331};\\\", \\\"{x:653,y:589,t:1527030887348};\\\", \\\"{x:658,y:588,t:1527030887365};\\\", \\\"{x:667,y:584,t:1527030887380};\\\", \\\"{x:679,y:579,t:1527030887398};\\\", \\\"{x:696,y:571,t:1527030887415};\\\", \\\"{x:704,y:568,t:1527030887430};\\\", \\\"{x:709,y:565,t:1527030887448};\\\", \\\"{x:712,y:563,t:1527030887465};\\\", \\\"{x:716,y:561,t:1527030887482};\\\", \\\"{x:722,y:558,t:1527030887498};\\\", \\\"{x:731,y:553,t:1527030887518};\\\", \\\"{x:741,y:549,t:1527030887531};\\\", \\\"{x:749,y:547,t:1527030887547};\\\", \\\"{x:755,y:543,t:1527030887564};\\\", \\\"{x:763,y:540,t:1527030887581};\\\", \\\"{x:767,y:537,t:1527030887597};\\\", \\\"{x:774,y:532,t:1527030887614};\\\", \\\"{x:778,y:529,t:1527030887631};\\\", \\\"{x:780,y:528,t:1527030887647};\\\", \\\"{x:784,y:525,t:1527030887665};\\\", \\\"{x:788,y:523,t:1527030887681};\\\", \\\"{x:791,y:521,t:1527030887697};\\\", \\\"{x:795,y:517,t:1527030887716};\\\", \\\"{x:800,y:516,t:1527030887731};\\\", \\\"{x:802,y:514,t:1527030887747};\\\", \\\"{x:803,y:513,t:1527030887764};\\\", \\\"{x:804,y:512,t:1527030887781};\\\", \\\"{x:806,y:511,t:1527030887798};\\\", \\\"{x:808,y:510,t:1527030887814};\\\", \\\"{x:812,y:508,t:1527030887831};\\\", \\\"{x:815,y:506,t:1527030887847};\\\", \\\"{x:820,y:504,t:1527030887865};\\\", \\\"{x:823,y:503,t:1527030887882};\\\", \\\"{x:824,y:503,t:1527030887897};\\\", \\\"{x:827,y:501,t:1527030887917};\\\", \\\"{x:830,y:501,t:1527030887931};\\\", \\\"{x:831,y:501,t:1527030887947};\\\", \\\"{x:834,y:500,t:1527030887964};\\\", \\\"{x:837,y:499,t:1527030887982};\\\", \\\"{x:840,y:498,t:1527030887997};\\\", \\\"{x:841,y:497,t:1527030888014};\\\", \\\"{x:835,y:501,t:1527030888302};\\\", \\\"{x:818,y:511,t:1527030888315};\\\", \\\"{x:773,y:539,t:1527030888332};\\\", \\\"{x:713,y:574,t:1527030888350};\\\", \\\"{x:631,y:607,t:1527030888365};\\\", \\\"{x:567,y:635,t:1527030888382};\\\", \\\"{x:469,y:680,t:1527030888398};\\\", \\\"{x:411,y:702,t:1527030888416};\\\", \\\"{x:363,y:719,t:1527030888431};\\\", \\\"{x:338,y:730,t:1527030888449};\\\", \\\"{x:316,y:742,t:1527030888466};\\\", \\\"{x:302,y:753,t:1527030888482};\\\", \\\"{x:295,y:760,t:1527030888499};\\\", \\\"{x:292,y:763,t:1527030888516};\\\", \\\"{x:292,y:764,t:1527030888532};\\\", \\\"{x:293,y:766,t:1527030888549};\\\", \\\"{x:296,y:770,t:1527030888565};\\\", \\\"{x:301,y:774,t:1527030888582};\\\", \\\"{x:310,y:780,t:1527030888598};\\\", \\\"{x:313,y:781,t:1527030888615};\\\", \\\"{x:316,y:782,t:1527030888632};\\\", \\\"{x:318,y:782,t:1527030888649};\\\", \\\"{x:325,y:782,t:1527030888666};\\\", \\\"{x:343,y:778,t:1527030888682};\\\", \\\"{x:370,y:771,t:1527030888699};\\\", \\\"{x:413,y:760,t:1527030888716};\\\", \\\"{x:458,y:749,t:1527030888732};\\\", \\\"{x:498,y:740,t:1527030888748};\\\", \\\"{x:527,y:733,t:1527030888766};\\\", \\\"{x:555,y:729,t:1527030888782};\\\", \\\"{x:561,y:728,t:1527030888799};\\\", \\\"{x:563,y:727,t:1527030888816};\\\", \\\"{x:562,y:727,t:1527030888943};\\\", \\\"{x:561,y:728,t:1527030888951};\\\", \\\"{x:558,y:729,t:1527030888966};\\\", \\\"{x:544,y:737,t:1527030888982};\\\", \\\"{x:535,y:742,t:1527030889000};\\\", \\\"{x:525,y:744,t:1527030889017};\\\", \\\"{x:517,y:746,t:1527030889033};\\\", \\\"{x:514,y:748,t:1527030889050};\\\", \\\"{x:513,y:748,t:1527030889079};\\\", \\\"{x:512,y:747,t:1527030889390};\\\", \\\"{x:512,y:745,t:1527030889399};\\\", \\\"{x:513,y:744,t:1527030889415};\\\" ] }, { \\\"rt\\\": 36299, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 18, \\\"time_elapsed\\\": 683148, \\\"internal_node_id\\\": \\\"0.0-6.0-8.0\\\", \\\"subject\\\": \\\"E5L6P\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 14, \\\"clicks\\\": 1.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-03 PM-12 PM-J -J -X -01 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:513,y:740,t:1527030891079};\\\", \\\"{x:403,y:632,t:1527030891204};\\\", \\\"{x:393,y:624,t:1527030891218};\\\", \\\"{x:384,y:618,t:1527030891233};\\\", \\\"{x:381,y:614,t:1527030891251};\\\", \\\"{x:376,y:609,t:1527030891266};\\\", \\\"{x:375,y:606,t:1527030891283};\\\", \\\"{x:374,y:604,t:1527030891300};\\\", \\\"{x:373,y:602,t:1527030891318};\\\", \\\"{x:373,y:601,t:1527030891333};\\\", \\\"{x:374,y:599,t:1527030891351};\\\", \\\"{x:376,y:598,t:1527030891368};\\\", \\\"{x:376,y:595,t:1527030891606};\\\", \\\"{x:376,y:591,t:1527030891619};\\\", \\\"{x:376,y:588,t:1527030891636};\\\", \\\"{x:376,y:587,t:1527030891650};\\\", \\\"{x:377,y:585,t:1527030891668};\\\", \\\"{x:377,y:584,t:1527030891685};\\\", \\\"{x:377,y:583,t:1527030891799};\\\", \\\"{x:378,y:583,t:1527030891806};\\\", \\\"{x:380,y:580,t:1527030891818};\\\", \\\"{x:389,y:576,t:1527030891835};\\\", \\\"{x:404,y:568,t:1527030891852};\\\", \\\"{x:434,y:554,t:1527030891869};\\\", \\\"{x:472,y:532,t:1527030891885};\\\", \\\"{x:506,y:517,t:1527030891903};\\\", \\\"{x:529,y:506,t:1527030891917};\\\", \\\"{x:565,y:488,t:1527030891934};\\\", \\\"{x:589,y:482,t:1527030891951};\\\", \\\"{x:609,y:473,t:1527030891968};\\\", \\\"{x:626,y:466,t:1527030891985};\\\", \\\"{x:637,y:463,t:1527030892002};\\\", \\\"{x:644,y:459,t:1527030892018};\\\", \\\"{x:646,y:458,t:1527030892035};\\\", \\\"{x:647,y:457,t:1527030892052};\\\", \\\"{x:648,y:457,t:1527030892068};\\\", \\\"{x:649,y:456,t:1527030892085};\\\", \\\"{x:652,y:456,t:1527030892311};\\\", \\\"{x:659,y:455,t:1527030892320};\\\", \\\"{x:686,y:455,t:1527030892334};\\\", \\\"{x:718,y:457,t:1527030892352};\\\", \\\"{x:772,y:466,t:1527030892368};\\\", \\\"{x:844,y:477,t:1527030892385};\\\", \\\"{x:940,y:483,t:1527030892402};\\\", \\\"{x:1045,y:485,t:1527030892418};\\\", \\\"{x:1168,y:487,t:1527030892436};\\\", \\\"{x:1293,y:489,t:1527030892452};\\\", \\\"{x:1416,y:499,t:1527030892468};\\\", \\\"{x:1528,y:518,t:1527030892485};\\\", \\\"{x:1625,y:535,t:1527030892503};\\\", \\\"{x:1708,y:556,t:1527030892519};\\\", \\\"{x:1807,y:589,t:1527030892535};\\\", \\\"{x:1863,y:618,t:1527030892552};\\\", \\\"{x:1915,y:661,t:1527030892569};\\\", \\\"{x:1919,y:703,t:1527030892585};\\\", \\\"{x:1919,y:740,t:1527030892602};\\\", \\\"{x:1919,y:770,t:1527030892618};\\\", \\\"{x:1919,y:798,t:1527030892636};\\\", \\\"{x:1919,y:826,t:1527030892652};\\\", \\\"{x:1919,y:856,t:1527030892668};\\\", \\\"{x:1919,y:883,t:1527030892686};\\\", \\\"{x:1914,y:908,t:1527030892702};\\\", \\\"{x:1892,y:938,t:1527030892719};\\\", \\\"{x:1872,y:950,t:1527030892736};\\\", \\\"{x:1852,y:959,t:1527030892752};\\\", \\\"{x:1827,y:961,t:1527030892768};\\\", \\\"{x:1799,y:961,t:1527030892786};\\\", \\\"{x:1760,y:958,t:1527030892801};\\\", \\\"{x:1709,y:950,t:1527030892819};\\\", \\\"{x:1656,y:941,t:1527030892836};\\\", \\\"{x:1615,y:938,t:1527030892852};\\\", \\\"{x:1586,y:935,t:1527030892869};\\\", \\\"{x:1561,y:933,t:1527030892886};\\\", \\\"{x:1546,y:933,t:1527030892902};\\\", \\\"{x:1526,y:930,t:1527030892919};\\\", \\\"{x:1524,y:930,t:1527030892936};\\\", \\\"{x:1525,y:930,t:1527030893031};\\\", \\\"{x:1526,y:931,t:1527030893039};\\\", \\\"{x:1527,y:932,t:1527030893052};\\\", \\\"{x:1532,y:939,t:1527030893069};\\\", \\\"{x:1538,y:948,t:1527030893087};\\\", \\\"{x:1543,y:955,t:1527030893102};\\\", \\\"{x:1550,y:965,t:1527030893121};\\\", \\\"{x:1553,y:969,t:1527030893137};\\\", \\\"{x:1555,y:972,t:1527030893152};\\\", \\\"{x:1558,y:975,t:1527030893170};\\\", \\\"{x:1559,y:976,t:1527030893186};\\\", \\\"{x:1559,y:975,t:1527030893328};\\\", \\\"{x:1556,y:972,t:1527030893336};\\\", \\\"{x:1552,y:967,t:1527030893354};\\\", \\\"{x:1552,y:966,t:1527030893369};\\\", \\\"{x:1551,y:964,t:1527030893386};\\\", \\\"{x:1550,y:963,t:1527030893403};\\\", \\\"{x:1549,y:961,t:1527030893420};\\\", \\\"{x:1548,y:961,t:1527030893439};\\\", \\\"{x:1547,y:960,t:1527030894031};\\\", \\\"{x:1540,y:951,t:1527030900342};\\\", \\\"{x:1496,y:894,t:1527030900357};\\\", \\\"{x:1447,y:837,t:1527030900374};\\\", \\\"{x:1378,y:775,t:1527030900391};\\\", \\\"{x:1304,y:715,t:1527030900408};\\\", \\\"{x:1215,y:652,t:1527030900424};\\\", \\\"{x:1125,y:602,t:1527030900441};\\\", \\\"{x:1013,y:556,t:1527030900458};\\\", \\\"{x:897,y:508,t:1527030900474};\\\", \\\"{x:778,y:475,t:1527030900492};\\\", \\\"{x:651,y:441,t:1527030900508};\\\", \\\"{x:524,y:407,t:1527030900525};\\\", \\\"{x:343,y:365,t:1527030900541};\\\", \\\"{x:240,y:349,t:1527030900558};\\\", \\\"{x:165,y:339,t:1527030900574};\\\", \\\"{x:124,y:334,t:1527030900591};\\\", \\\"{x:103,y:334,t:1527030900608};\\\", \\\"{x:95,y:333,t:1527030900625};\\\", \\\"{x:91,y:333,t:1527030900642};\\\", \\\"{x:89,y:335,t:1527030900658};\\\", \\\"{x:88,y:340,t:1527030900675};\\\", \\\"{x:91,y:352,t:1527030900691};\\\", \\\"{x:108,y:377,t:1527030900708};\\\", \\\"{x:125,y:404,t:1527030900725};\\\", \\\"{x:143,y:437,t:1527030900742};\\\", \\\"{x:156,y:456,t:1527030900758};\\\", \\\"{x:171,y:471,t:1527030900775};\\\", \\\"{x:184,y:482,t:1527030900792};\\\", \\\"{x:197,y:489,t:1527030900809};\\\", \\\"{x:206,y:495,t:1527030900825};\\\", \\\"{x:214,y:497,t:1527030900842};\\\", \\\"{x:221,y:498,t:1527030900858};\\\", \\\"{x:227,y:498,t:1527030900875};\\\", \\\"{x:238,y:498,t:1527030900892};\\\", \\\"{x:250,y:498,t:1527030900908};\\\", \\\"{x:269,y:498,t:1527030900925};\\\", \\\"{x:293,y:502,t:1527030900942};\\\", \\\"{x:307,y:504,t:1527030900958};\\\", \\\"{x:324,y:507,t:1527030900975};\\\", \\\"{x:343,y:508,t:1527030900992};\\\", \\\"{x:361,y:509,t:1527030901009};\\\", \\\"{x:381,y:509,t:1527030901025};\\\", \\\"{x:401,y:509,t:1527030901042};\\\", \\\"{x:417,y:509,t:1527030901059};\\\", \\\"{x:433,y:509,t:1527030901075};\\\", \\\"{x:457,y:510,t:1527030901092};\\\", \\\"{x:481,y:514,t:1527030901109};\\\", \\\"{x:502,y:515,t:1527030901126};\\\", \\\"{x:531,y:519,t:1527030901142};\\\", \\\"{x:553,y:520,t:1527030901160};\\\", \\\"{x:577,y:521,t:1527030901175};\\\", \\\"{x:599,y:523,t:1527030901192};\\\", \\\"{x:621,y:525,t:1527030901210};\\\", \\\"{x:635,y:525,t:1527030901226};\\\", \\\"{x:644,y:526,t:1527030901242};\\\", \\\"{x:651,y:526,t:1527030901259};\\\", \\\"{x:661,y:528,t:1527030901276};\\\", \\\"{x:676,y:530,t:1527030901292};\\\", \\\"{x:689,y:530,t:1527030901309};\\\", \\\"{x:702,y:530,t:1527030901326};\\\", \\\"{x:706,y:530,t:1527030901342};\\\", \\\"{x:707,y:530,t:1527030901359};\\\", \\\"{x:706,y:530,t:1527030901454};\\\", \\\"{x:698,y:530,t:1527030901461};\\\", \\\"{x:691,y:530,t:1527030901476};\\\", \\\"{x:667,y:530,t:1527030901493};\\\", \\\"{x:636,y:530,t:1527030901510};\\\", \\\"{x:584,y:538,t:1527030901526};\\\", \\\"{x:525,y:546,t:1527030901541};\\\", \\\"{x:460,y:549,t:1527030901560};\\\", \\\"{x:388,y:549,t:1527030901576};\\\", \\\"{x:324,y:549,t:1527030901592};\\\", \\\"{x:276,y:549,t:1527030901609};\\\", \\\"{x:255,y:548,t:1527030901627};\\\", \\\"{x:247,y:547,t:1527030901642};\\\", \\\"{x:245,y:546,t:1527030901658};\\\", \\\"{x:242,y:545,t:1527030901676};\\\", \\\"{x:239,y:545,t:1527030901692};\\\", \\\"{x:232,y:545,t:1527030901709};\\\", \\\"{x:223,y:545,t:1527030901726};\\\", \\\"{x:214,y:545,t:1527030901742};\\\", \\\"{x:205,y:544,t:1527030901759};\\\", \\\"{x:195,y:541,t:1527030901776};\\\", \\\"{x:187,y:539,t:1527030901793};\\\", \\\"{x:180,y:537,t:1527030901809};\\\", \\\"{x:178,y:536,t:1527030901826};\\\", \\\"{x:178,y:537,t:1527030901886};\\\", \\\"{x:178,y:539,t:1527030901894};\\\", \\\"{x:178,y:541,t:1527030901909};\\\", \\\"{x:175,y:549,t:1527030901925};\\\", \\\"{x:175,y:551,t:1527030901944};\\\", \\\"{x:175,y:556,t:1527030901959};\\\", \\\"{x:175,y:557,t:1527030901976};\\\", \\\"{x:175,y:558,t:1527030901993};\\\", \\\"{x:175,y:561,t:1527030902009};\\\", \\\"{x:175,y:564,t:1527030902027};\\\", \\\"{x:174,y:565,t:1527030902119};\\\", \\\"{x:171,y:565,t:1527030902126};\\\", \\\"{x:162,y:554,t:1527030902144};\\\", \\\"{x:156,y:543,t:1527030902159};\\\", \\\"{x:153,y:537,t:1527030902176};\\\", \\\"{x:152,y:533,t:1527030902193};\\\", \\\"{x:149,y:531,t:1527030902209};\\\", \\\"{x:148,y:529,t:1527030902227};\\\", \\\"{x:148,y:530,t:1527030902991};\\\", \\\"{x:148,y:532,t:1527030902999};\\\", \\\"{x:150,y:534,t:1527030903011};\\\", \\\"{x:152,y:536,t:1527030903027};\\\", \\\"{x:153,y:538,t:1527030903044};\\\", \\\"{x:157,y:541,t:1527030903462};\\\", \\\"{x:167,y:547,t:1527030903477};\\\", \\\"{x:206,y:572,t:1527030903495};\\\", \\\"{x:255,y:599,t:1527030903512};\\\", \\\"{x:316,y:629,t:1527030903528};\\\", \\\"{x:405,y:669,t:1527030903545};\\\", \\\"{x:499,y:711,t:1527030903562};\\\", \\\"{x:606,y:756,t:1527030903577};\\\", \\\"{x:713,y:799,t:1527030903594};\\\", \\\"{x:823,y:845,t:1527030903610};\\\", \\\"{x:927,y:881,t:1527030903628};\\\", \\\"{x:1019,y:915,t:1527030903645};\\\", \\\"{x:1090,y:943,t:1527030903661};\\\", \\\"{x:1135,y:956,t:1527030903678};\\\", \\\"{x:1165,y:961,t:1527030903694};\\\", \\\"{x:1167,y:961,t:1527030903712};\\\", \\\"{x:1168,y:960,t:1527030903734};\\\", \\\"{x:1168,y:956,t:1527030903751};\\\", \\\"{x:1168,y:953,t:1527030903762};\\\", \\\"{x:1171,y:947,t:1527030903777};\\\", \\\"{x:1171,y:938,t:1527030903794};\\\", \\\"{x:1174,y:926,t:1527030903812};\\\", \\\"{x:1179,y:914,t:1527030903828};\\\", \\\"{x:1189,y:907,t:1527030903845};\\\", \\\"{x:1201,y:902,t:1527030903861};\\\", \\\"{x:1219,y:896,t:1527030903877};\\\", \\\"{x:1243,y:891,t:1527030903895};\\\", \\\"{x:1258,y:886,t:1527030903912};\\\", \\\"{x:1269,y:881,t:1527030903927};\\\", \\\"{x:1278,y:876,t:1527030903944};\\\", \\\"{x:1283,y:874,t:1527030903961};\\\", \\\"{x:1287,y:871,t:1527030903978};\\\", \\\"{x:1290,y:868,t:1527030903994};\\\", \\\"{x:1292,y:867,t:1527030904011};\\\", \\\"{x:1293,y:867,t:1527030904027};\\\", \\\"{x:1294,y:866,t:1527030904275};\\\", \\\"{x:1297,y:867,t:1527030904282};\\\", \\\"{x:1305,y:877,t:1527030904299};\\\", \\\"{x:1314,y:890,t:1527030904316};\\\", \\\"{x:1322,y:902,t:1527030904332};\\\", \\\"{x:1331,y:914,t:1527030904349};\\\", \\\"{x:1340,y:924,t:1527030904365};\\\", \\\"{x:1346,y:933,t:1527030904382};\\\", \\\"{x:1349,y:940,t:1527030904400};\\\", \\\"{x:1351,y:943,t:1527030904416};\\\", \\\"{x:1352,y:947,t:1527030904432};\\\", \\\"{x:1354,y:950,t:1527030904449};\\\", \\\"{x:1354,y:951,t:1527030904465};\\\", \\\"{x:1354,y:956,t:1527030904483};\\\", \\\"{x:1354,y:957,t:1527030904500};\\\", \\\"{x:1354,y:959,t:1527030904516};\\\", \\\"{x:1352,y:960,t:1527030904533};\\\", \\\"{x:1351,y:960,t:1527030904563};\\\", \\\"{x:1350,y:960,t:1527030904571};\\\", \\\"{x:1349,y:960,t:1527030904594};\\\", \\\"{x:1347,y:960,t:1527030904611};\\\", \\\"{x:1346,y:960,t:1527030904626};\\\", \\\"{x:1344,y:960,t:1527030904635};\\\", \\\"{x:1342,y:960,t:1527030904650};\\\", \\\"{x:1340,y:960,t:1527030904666};\\\", \\\"{x:1336,y:958,t:1527030904683};\\\", \\\"{x:1332,y:955,t:1527030904699};\\\", \\\"{x:1330,y:954,t:1527030904716};\\\", \\\"{x:1328,y:953,t:1527030904732};\\\", \\\"{x:1326,y:952,t:1527030904749};\\\", \\\"{x:1330,y:952,t:1527030905219};\\\", \\\"{x:1332,y:955,t:1527030905233};\\\", \\\"{x:1341,y:962,t:1527030905250};\\\", \\\"{x:1346,y:968,t:1527030905267};\\\", \\\"{x:1348,y:970,t:1527030905283};\\\", \\\"{x:1350,y:971,t:1527030905299};\\\", \\\"{x:1350,y:970,t:1527030905571};\\\", \\\"{x:1350,y:966,t:1527030905583};\\\", \\\"{x:1350,y:962,t:1527030905598};\\\", \\\"{x:1350,y:959,t:1527030905616};\\\", \\\"{x:1350,y:958,t:1527030905633};\\\", \\\"{x:1350,y:956,t:1527030905851};\\\", \\\"{x:1350,y:953,t:1527030905866};\\\", \\\"{x:1350,y:951,t:1527030905883};\\\", \\\"{x:1350,y:949,t:1527030905900};\\\", \\\"{x:1350,y:947,t:1527030905917};\\\", \\\"{x:1350,y:946,t:1527030905933};\\\", \\\"{x:1350,y:945,t:1527030905950};\\\", \\\"{x:1350,y:944,t:1527030905978};\\\", \\\"{x:1350,y:943,t:1527030905986};\\\", \\\"{x:1350,y:942,t:1527030906427};\\\", \\\"{x:1351,y:942,t:1527030906442};\\\", \\\"{x:1353,y:941,t:1527030906451};\\\", \\\"{x:1354,y:939,t:1527030906468};\\\", \\\"{x:1357,y:938,t:1527030906485};\\\", \\\"{x:1358,y:936,t:1527030906501};\\\", \\\"{x:1360,y:936,t:1527030906517};\\\", \\\"{x:1360,y:935,t:1527030906538};\\\", \\\"{x:1361,y:934,t:1527030906554};\\\", \\\"{x:1361,y:933,t:1527030906571};\\\", \\\"{x:1361,y:932,t:1527030906602};\\\", \\\"{x:1361,y:931,t:1527030906625};\\\", \\\"{x:1361,y:930,t:1527030906665};\\\", \\\"{x:1361,y:929,t:1527030906705};\\\", \\\"{x:1361,y:928,t:1527030906717};\\\", \\\"{x:1361,y:927,t:1527030906734};\\\", \\\"{x:1361,y:925,t:1527030906751};\\\", \\\"{x:1359,y:923,t:1527030906767};\\\", \\\"{x:1351,y:917,t:1527030906784};\\\", \\\"{x:1341,y:912,t:1527030906801};\\\", \\\"{x:1326,y:909,t:1527030906817};\\\", \\\"{x:1292,y:898,t:1527030906834};\\\", \\\"{x:1254,y:890,t:1527030906851};\\\", \\\"{x:1205,y:881,t:1527030906867};\\\", \\\"{x:1164,y:871,t:1527030906884};\\\", \\\"{x:1137,y:861,t:1527030906901};\\\", \\\"{x:1119,y:856,t:1527030906917};\\\", \\\"{x:1108,y:854,t:1527030906934};\\\", \\\"{x:1103,y:851,t:1527030906951};\\\", \\\"{x:1101,y:850,t:1527030906968};\\\", \\\"{x:1099,y:848,t:1527030906984};\\\", \\\"{x:1098,y:848,t:1527030907002};\\\", \\\"{x:1097,y:847,t:1527030907018};\\\", \\\"{x:1096,y:844,t:1527030907035};\\\", \\\"{x:1096,y:842,t:1527030907052};\\\", \\\"{x:1096,y:840,t:1527030907068};\\\", \\\"{x:1096,y:839,t:1527030907085};\\\", \\\"{x:1096,y:837,t:1527030907102};\\\", \\\"{x:1096,y:836,t:1527030907118};\\\", \\\"{x:1097,y:834,t:1527030907135};\\\", \\\"{x:1099,y:833,t:1527030907151};\\\", \\\"{x:1103,y:832,t:1527030907168};\\\", \\\"{x:1105,y:831,t:1527030907185};\\\", \\\"{x:1107,y:830,t:1527030907202};\\\", \\\"{x:1111,y:828,t:1527030907219};\\\", \\\"{x:1114,y:827,t:1527030907235};\\\", \\\"{x:1115,y:827,t:1527030907258};\\\", \\\"{x:1116,y:827,t:1527030907282};\\\", \\\"{x:1117,y:826,t:1527030907290};\\\", \\\"{x:1118,y:826,t:1527030907324};\\\", \\\"{x:1120,y:825,t:1527030907401};\\\", \\\"{x:1123,y:824,t:1527030907426};\\\", \\\"{x:1125,y:823,t:1527030907434};\\\", \\\"{x:1130,y:822,t:1527030907451};\\\", \\\"{x:1136,y:821,t:1527030907468};\\\", \\\"{x:1143,y:821,t:1527030907485};\\\", \\\"{x:1151,y:821,t:1527030907502};\\\", \\\"{x:1160,y:821,t:1527030907518};\\\", \\\"{x:1167,y:821,t:1527030907534};\\\", \\\"{x:1172,y:821,t:1527030907551};\\\", \\\"{x:1179,y:821,t:1527030907568};\\\", \\\"{x:1184,y:821,t:1527030907585};\\\", \\\"{x:1190,y:821,t:1527030907601};\\\", \\\"{x:1197,y:821,t:1527030907618};\\\", \\\"{x:1201,y:821,t:1527030907635};\\\", \\\"{x:1203,y:821,t:1527030907651};\\\", \\\"{x:1205,y:821,t:1527030907668};\\\", \\\"{x:1208,y:820,t:1527030907685};\\\", \\\"{x:1209,y:820,t:1527030907706};\\\", \\\"{x:1210,y:820,t:1527030907737};\\\", \\\"{x:1211,y:820,t:1527030907770};\\\", \\\"{x:1212,y:820,t:1527030907785};\\\", \\\"{x:1214,y:821,t:1527030908139};\\\", \\\"{x:1214,y:822,t:1527030908171};\\\", \\\"{x:1214,y:823,t:1527030908186};\\\", \\\"{x:1215,y:825,t:1527030908205};\\\", \\\"{x:1215,y:826,t:1527030908218};\\\", \\\"{x:1216,y:827,t:1527030908236};\\\", \\\"{x:1217,y:828,t:1527030908252};\\\", \\\"{x:1218,y:830,t:1527030908269};\\\", \\\"{x:1218,y:831,t:1527030908286};\\\", \\\"{x:1219,y:832,t:1527030908314};\\\", \\\"{x:1219,y:831,t:1527030909035};\\\", \\\"{x:1219,y:830,t:1527030909050};\\\", \\\"{x:1219,y:828,t:1527030909082};\\\", \\\"{x:1219,y:827,t:1527030909139};\\\", \\\"{x:1219,y:825,t:1527030909188};\\\", \\\"{x:1220,y:824,t:1527030909204};\\\", \\\"{x:1221,y:824,t:1527030909220};\\\", \\\"{x:1223,y:824,t:1527030909236};\\\", \\\"{x:1226,y:824,t:1527030909253};\\\", \\\"{x:1230,y:824,t:1527030909270};\\\", \\\"{x:1235,y:824,t:1527030909287};\\\", \\\"{x:1247,y:824,t:1527030909303};\\\", \\\"{x:1259,y:824,t:1527030909320};\\\", \\\"{x:1273,y:825,t:1527030909336};\\\", \\\"{x:1287,y:827,t:1527030909353};\\\", \\\"{x:1300,y:830,t:1527030909369};\\\", \\\"{x:1318,y:831,t:1527030909386};\\\", \\\"{x:1330,y:831,t:1527030909403};\\\", \\\"{x:1336,y:831,t:1527030909419};\\\", \\\"{x:1338,y:831,t:1527030909436};\\\", \\\"{x:1339,y:831,t:1527030909453};\\\", \\\"{x:1341,y:831,t:1527030909469};\\\", \\\"{x:1342,y:831,t:1527030909486};\\\", \\\"{x:1347,y:831,t:1527030909503};\\\", \\\"{x:1353,y:830,t:1527030909519};\\\", \\\"{x:1360,y:830,t:1527030909536};\\\", \\\"{x:1369,y:829,t:1527030909554};\\\", \\\"{x:1377,y:829,t:1527030909569};\\\", \\\"{x:1396,y:829,t:1527030909586};\\\", \\\"{x:1408,y:829,t:1527030909603};\\\", \\\"{x:1420,y:828,t:1527030909620};\\\", \\\"{x:1431,y:828,t:1527030909637};\\\", \\\"{x:1440,y:828,t:1527030909653};\\\", \\\"{x:1447,y:828,t:1527030909670};\\\", \\\"{x:1454,y:828,t:1527030909687};\\\", \\\"{x:1459,y:828,t:1527030909704};\\\", \\\"{x:1462,y:828,t:1527030909720};\\\", \\\"{x:1466,y:828,t:1527030909736};\\\", \\\"{x:1468,y:828,t:1527030909754};\\\", \\\"{x:1475,y:829,t:1527030909771};\\\", \\\"{x:1483,y:830,t:1527030909787};\\\", \\\"{x:1489,y:831,t:1527030909805};\\\", \\\"{x:1492,y:833,t:1527030909821};\\\", \\\"{x:1497,y:834,t:1527030909837};\\\", \\\"{x:1500,y:834,t:1527030909854};\\\", \\\"{x:1501,y:834,t:1527030910130};\\\", \\\"{x:1500,y:834,t:1527030910170};\\\", \\\"{x:1499,y:834,t:1527030910363};\\\", \\\"{x:1498,y:834,t:1527030910378};\\\", \\\"{x:1497,y:834,t:1527030910388};\\\", \\\"{x:1495,y:834,t:1527030910404};\\\", \\\"{x:1494,y:834,t:1527030910421};\\\", \\\"{x:1493,y:835,t:1527030910438};\\\", \\\"{x:1492,y:835,t:1527030910455};\\\", \\\"{x:1492,y:836,t:1527030910471};\\\", \\\"{x:1490,y:837,t:1527030910794};\\\", \\\"{x:1488,y:837,t:1527030910827};\\\", \\\"{x:1487,y:838,t:1527030910891};\\\", \\\"{x:1486,y:839,t:1527030911299};\\\", \\\"{x:1486,y:840,t:1527030911307};\\\", \\\"{x:1486,y:842,t:1527030911322};\\\", \\\"{x:1484,y:845,t:1527030911337};\\\", \\\"{x:1484,y:847,t:1527030911354};\\\", \\\"{x:1484,y:849,t:1527030911372};\\\", \\\"{x:1484,y:851,t:1527030911388};\\\", \\\"{x:1484,y:853,t:1527030911404};\\\", \\\"{x:1484,y:858,t:1527030911421};\\\", \\\"{x:1486,y:861,t:1527030911438};\\\", \\\"{x:1488,y:865,t:1527030911454};\\\", \\\"{x:1488,y:868,t:1527030911471};\\\", \\\"{x:1491,y:872,t:1527030911489};\\\", \\\"{x:1492,y:875,t:1527030911504};\\\", \\\"{x:1493,y:878,t:1527030911521};\\\", \\\"{x:1494,y:880,t:1527030911538};\\\", \\\"{x:1494,y:881,t:1527030911738};\\\", \\\"{x:1494,y:882,t:1527030911762};\\\", \\\"{x:1494,y:883,t:1527030911772};\\\", \\\"{x:1494,y:884,t:1527030911788};\\\", \\\"{x:1494,y:885,t:1527030911806};\\\", \\\"{x:1494,y:886,t:1527030911821};\\\", \\\"{x:1494,y:887,t:1527030911838};\\\", \\\"{x:1494,y:888,t:1527030911855};\\\", \\\"{x:1494,y:889,t:1527030911872};\\\", \\\"{x:1494,y:890,t:1527030911889};\\\", \\\"{x:1494,y:891,t:1527030911906};\\\", \\\"{x:1495,y:892,t:1527030911937};\\\", \\\"{x:1494,y:892,t:1527030913002};\\\", \\\"{x:1491,y:891,t:1527030913010};\\\", \\\"{x:1487,y:885,t:1527030913023};\\\", \\\"{x:1480,y:877,t:1527030913040};\\\", \\\"{x:1475,y:868,t:1527030913057};\\\", \\\"{x:1469,y:862,t:1527030913073};\\\", \\\"{x:1464,y:855,t:1527030913089};\\\", \\\"{x:1460,y:851,t:1527030913107};\\\", \\\"{x:1459,y:849,t:1527030913123};\\\", \\\"{x:1457,y:848,t:1527030913140};\\\", \\\"{x:1457,y:847,t:1527030913156};\\\", \\\"{x:1456,y:846,t:1527030913218};\\\", \\\"{x:1456,y:845,t:1527030913242};\\\", \\\"{x:1456,y:844,t:1527030913257};\\\", \\\"{x:1456,y:842,t:1527030913274};\\\", \\\"{x:1454,y:839,t:1527030913290};\\\", \\\"{x:1453,y:838,t:1527030913306};\\\", \\\"{x:1453,y:837,t:1527030913324};\\\", \\\"{x:1453,y:835,t:1527030913340};\\\", \\\"{x:1453,y:834,t:1527030913356};\\\", \\\"{x:1453,y:833,t:1527030913386};\\\", \\\"{x:1453,y:832,t:1527030913410};\\\", \\\"{x:1453,y:831,t:1527030913426};\\\", \\\"{x:1454,y:830,t:1527030913440};\\\", \\\"{x:1454,y:829,t:1527030913457};\\\", \\\"{x:1454,y:826,t:1527030914379};\\\", \\\"{x:1454,y:819,t:1527030914391};\\\", \\\"{x:1454,y:801,t:1527030914408};\\\", \\\"{x:1452,y:784,t:1527030914424};\\\", \\\"{x:1451,y:779,t:1527030914442};\\\", \\\"{x:1451,y:776,t:1527030914458};\\\", \\\"{x:1450,y:775,t:1527030914474};\\\", \\\"{x:1449,y:774,t:1527030914491};\\\", \\\"{x:1448,y:774,t:1527030914523};\\\", \\\"{x:1448,y:773,t:1527030914541};\\\", \\\"{x:1447,y:772,t:1527030915251};\\\", \\\"{x:1446,y:772,t:1527030915258};\\\", \\\"{x:1442,y:771,t:1527030915275};\\\", \\\"{x:1441,y:771,t:1527030915298};\\\", \\\"{x:1440,y:771,t:1527030915308};\\\", \\\"{x:1439,y:771,t:1527030915326};\\\", \\\"{x:1437,y:769,t:1527030915342};\\\", \\\"{x:1436,y:769,t:1527030915363};\\\", \\\"{x:1435,y:769,t:1527030915627};\\\", \\\"{x:1434,y:769,t:1527030915642};\\\", \\\"{x:1433,y:769,t:1527030915659};\\\", \\\"{x:1433,y:771,t:1527030915675};\\\", \\\"{x:1433,y:772,t:1527030915692};\\\", \\\"{x:1433,y:774,t:1527030915709};\\\", \\\"{x:1433,y:776,t:1527030915726};\\\", \\\"{x:1433,y:777,t:1527030915742};\\\", \\\"{x:1433,y:780,t:1527030915759};\\\", \\\"{x:1433,y:784,t:1527030915775};\\\", \\\"{x:1433,y:786,t:1527030915792};\\\", \\\"{x:1434,y:789,t:1527030915809};\\\", \\\"{x:1436,y:795,t:1527030915827};\\\", \\\"{x:1437,y:796,t:1527030915843};\\\", \\\"{x:1437,y:798,t:1527030915858};\\\", \\\"{x:1437,y:799,t:1527030915882};\\\", \\\"{x:1437,y:800,t:1527030915892};\\\", \\\"{x:1438,y:802,t:1527030915909};\\\", \\\"{x:1438,y:804,t:1527030915926};\\\", \\\"{x:1440,y:808,t:1527030915942};\\\", \\\"{x:1440,y:815,t:1527030915959};\\\", \\\"{x:1441,y:820,t:1527030915976};\\\", \\\"{x:1441,y:827,t:1527030915992};\\\", \\\"{x:1441,y:834,t:1527030916009};\\\", \\\"{x:1441,y:846,t:1527030916027};\\\", \\\"{x:1440,y:858,t:1527030916042};\\\", \\\"{x:1439,y:868,t:1527030916059};\\\", \\\"{x:1438,y:875,t:1527030916076};\\\", \\\"{x:1436,y:881,t:1527030916092};\\\", \\\"{x:1435,y:884,t:1527030916109};\\\", \\\"{x:1434,y:888,t:1527030916126};\\\", \\\"{x:1433,y:891,t:1527030916142};\\\", \\\"{x:1432,y:893,t:1527030916159};\\\", \\\"{x:1431,y:893,t:1527030916176};\\\", \\\"{x:1431,y:894,t:1527030916192};\\\", \\\"{x:1431,y:896,t:1527030916225};\\\", \\\"{x:1431,y:897,t:1527030916249};\\\", \\\"{x:1430,y:898,t:1527030916258};\\\", \\\"{x:1429,y:899,t:1527030916275};\\\", \\\"{x:1428,y:900,t:1527030916292};\\\", \\\"{x:1427,y:902,t:1527030916308};\\\", \\\"{x:1426,y:904,t:1527030916325};\\\", \\\"{x:1422,y:908,t:1527030916342};\\\", \\\"{x:1421,y:911,t:1527030916358};\\\", \\\"{x:1418,y:917,t:1527030916375};\\\", \\\"{x:1415,y:926,t:1527030916392};\\\", \\\"{x:1414,y:931,t:1527030916409};\\\", \\\"{x:1411,y:939,t:1527030916425};\\\", \\\"{x:1409,y:943,t:1527030916442};\\\", \\\"{x:1409,y:947,t:1527030916458};\\\", \\\"{x:1407,y:950,t:1527030916475};\\\", \\\"{x:1406,y:952,t:1527030916492};\\\", \\\"{x:1406,y:954,t:1527030916508};\\\", \\\"{x:1405,y:956,t:1527030916526};\\\", \\\"{x:1404,y:958,t:1527030916543};\\\", \\\"{x:1403,y:959,t:1527030916559};\\\", \\\"{x:1403,y:960,t:1527030916593};\\\", \\\"{x:1402,y:961,t:1527030916609};\\\", \\\"{x:1401,y:962,t:1527030916625};\\\", \\\"{x:1400,y:963,t:1527030916643};\\\", \\\"{x:1400,y:964,t:1527030916659};\\\", \\\"{x:1399,y:965,t:1527030916676};\\\", \\\"{x:1398,y:967,t:1527030916693};\\\", \\\"{x:1397,y:967,t:1527030916754};\\\", \\\"{x:1397,y:968,t:1527030916761};\\\", \\\"{x:1396,y:969,t:1527030916778};\\\", \\\"{x:1395,y:970,t:1527030916793};\\\", \\\"{x:1394,y:971,t:1527030916810};\\\", \\\"{x:1393,y:972,t:1527030916825};\\\", \\\"{x:1393,y:973,t:1527030916843};\\\", \\\"{x:1392,y:975,t:1527030916859};\\\", \\\"{x:1391,y:975,t:1527030916876};\\\", \\\"{x:1390,y:976,t:1527030916893};\\\", \\\"{x:1388,y:978,t:1527030916910};\\\", \\\"{x:1388,y:979,t:1527030916926};\\\", \\\"{x:1387,y:980,t:1527030916942};\\\", \\\"{x:1386,y:980,t:1527030916962};\\\", \\\"{x:1386,y:981,t:1527030916994};\\\", \\\"{x:1384,y:980,t:1527030917211};\\\", \\\"{x:1381,y:972,t:1527030917226};\\\", \\\"{x:1376,y:963,t:1527030917243};\\\", \\\"{x:1373,y:957,t:1527030917260};\\\", \\\"{x:1372,y:955,t:1527030917277};\\\", \\\"{x:1371,y:952,t:1527030917293};\\\", \\\"{x:1370,y:950,t:1527030917309};\\\", \\\"{x:1369,y:949,t:1527030917327};\\\", \\\"{x:1369,y:948,t:1527030917354};\\\", \\\"{x:1369,y:947,t:1527030917362};\\\", \\\"{x:1369,y:946,t:1527030917378};\\\", \\\"{x:1368,y:946,t:1527030917394};\\\", \\\"{x:1363,y:941,t:1527030917899};\\\", \\\"{x:1354,y:934,t:1527030917911};\\\", \\\"{x:1330,y:920,t:1527030917928};\\\", \\\"{x:1298,y:905,t:1527030917944};\\\", \\\"{x:1253,y:889,t:1527030917962};\\\", \\\"{x:1195,y:876,t:1527030917977};\\\", \\\"{x:1096,y:863,t:1527030917994};\\\", \\\"{x:1024,y:852,t:1527030918011};\\\", \\\"{x:970,y:842,t:1527030918027};\\\", \\\"{x:913,y:833,t:1527030918043};\\\", \\\"{x:869,y:827,t:1527030918061};\\\", \\\"{x:837,y:823,t:1527030918077};\\\", \\\"{x:815,y:820,t:1527030918094};\\\", \\\"{x:801,y:818,t:1527030918111};\\\", \\\"{x:796,y:817,t:1527030918127};\\\", \\\"{x:793,y:817,t:1527030918144};\\\", \\\"{x:792,y:817,t:1527030918161};\\\", \\\"{x:790,y:817,t:1527030918177};\\\", \\\"{x:786,y:816,t:1527030918194};\\\", \\\"{x:781,y:813,t:1527030918210};\\\", \\\"{x:773,y:812,t:1527030918228};\\\", \\\"{x:765,y:810,t:1527030918244};\\\", \\\"{x:748,y:806,t:1527030918261};\\\", \\\"{x:734,y:802,t:1527030918278};\\\", \\\"{x:724,y:800,t:1527030918294};\\\", \\\"{x:712,y:796,t:1527030918311};\\\", \\\"{x:700,y:792,t:1527030918328};\\\", \\\"{x:690,y:790,t:1527030918344};\\\", \\\"{x:680,y:786,t:1527030918360};\\\", \\\"{x:663,y:779,t:1527030918378};\\\", \\\"{x:648,y:770,t:1527030918394};\\\", \\\"{x:627,y:758,t:1527030918411};\\\", \\\"{x:598,y:744,t:1527030918428};\\\", \\\"{x:574,y:734,t:1527030918443};\\\", \\\"{x:552,y:724,t:1527030918462};\\\", \\\"{x:534,y:717,t:1527030918478};\\\", \\\"{x:521,y:712,t:1527030918494};\\\", \\\"{x:517,y:708,t:1527030918510};\\\", \\\"{x:513,y:707,t:1527030918526};\\\", \\\"{x:511,y:706,t:1527030918543};\\\", \\\"{x:511,y:705,t:1527030918559};\\\", \\\"{x:508,y:704,t:1527030918576};\\\", \\\"{x:507,y:703,t:1527030918593};\\\", \\\"{x:506,y:703,t:1527030918610};\\\", \\\"{x:505,y:702,t:1527030918626};\\\", \\\"{x:503,y:701,t:1527030918643};\\\", \\\"{x:501,y:700,t:1527030918659};\\\", \\\"{x:500,y:699,t:1527030918676};\\\", \\\"{x:498,y:698,t:1527030918693};\\\", \\\"{x:497,y:697,t:1527030918709};\\\", \\\"{x:494,y:696,t:1527030918726};\\\", \\\"{x:491,y:694,t:1527030918743};\\\", \\\"{x:488,y:692,t:1527030918760};\\\", \\\"{x:487,y:691,t:1527030918776};\\\", \\\"{x:483,y:689,t:1527030918794};\\\", \\\"{x:481,y:687,t:1527030918810};\\\", \\\"{x:473,y:685,t:1527030918827};\\\", \\\"{x:469,y:682,t:1527030918843};\\\", \\\"{x:462,y:681,t:1527030918860};\\\", \\\"{x:455,y:678,t:1527030918877};\\\", \\\"{x:449,y:677,t:1527030918894};\\\", \\\"{x:444,y:674,t:1527030918911};\\\", \\\"{x:440,y:674,t:1527030918926};\\\", \\\"{x:433,y:672,t:1527030918943};\\\", \\\"{x:430,y:671,t:1527030918961};\\\", \\\"{x:426,y:670,t:1527030918977};\\\", \\\"{x:422,y:668,t:1527030918995};\\\", \\\"{x:419,y:667,t:1527030919010};\\\", \\\"{x:419,y:666,t:1527030919026};\\\", \\\"{x:417,y:666,t:1527030919043};\\\", \\\"{x:415,y:666,t:1527030919060};\\\", \\\"{x:413,y:665,t:1527030919089};\\\", \\\"{x:412,y:664,t:1527030919122};\\\", \\\"{x:411,y:664,t:1527030919153};\\\", \\\"{x:409,y:663,t:1527030919161};\\\", \\\"{x:408,y:663,t:1527030919193};\\\", \\\"{x:406,y:661,t:1527030919210};\\\", \\\"{x:403,y:661,t:1527030919228};\\\", \\\"{x:400,y:661,t:1527030919243};\\\", \\\"{x:399,y:661,t:1527030919260};\\\", \\\"{x:398,y:661,t:1527030919277};\\\", \\\"{x:397,y:661,t:1527030919294};\\\", \\\"{x:396,y:661,t:1527030919314};\\\", \\\"{x:396,y:664,t:1527030919329};\\\", \\\"{x:404,y:679,t:1527030919344};\\\", \\\"{x:412,y:691,t:1527030919361};\\\", \\\"{x:420,y:705,t:1527030919377};\\\", \\\"{x:424,y:716,t:1527030919393};\\\", \\\"{x:430,y:724,t:1527030919410};\\\", \\\"{x:438,y:733,t:1527030919427};\\\", \\\"{x:444,y:738,t:1527030919444};\\\", \\\"{x:451,y:742,t:1527030919460};\\\", \\\"{x:464,y:748,t:1527030919477};\\\", \\\"{x:482,y:755,t:1527030919495};\\\", \\\"{x:498,y:763,t:1527030919511};\\\", \\\"{x:511,y:766,t:1527030919528};\\\", \\\"{x:515,y:768,t:1527030919544};\\\", \\\"{x:519,y:768,t:1527030919561};\\\", \\\"{x:522,y:768,t:1527030919577};\\\", \\\"{x:525,y:765,t:1527030919595};\\\", \\\"{x:527,y:760,t:1527030919610};\\\", \\\"{x:528,y:751,t:1527030919628};\\\", \\\"{x:528,y:743,t:1527030919644};\\\", \\\"{x:528,y:734,t:1527030919660};\\\", \\\"{x:528,y:729,t:1527030919678};\\\", \\\"{x:528,y:725,t:1527030919695};\\\", \\\"{x:528,y:724,t:1527030919754};\\\", \\\"{x:528,y:725,t:1527030919906};\\\", \\\"{x:528,y:727,t:1527030919914};\\\", \\\"{x:527,y:730,t:1527030919928};\\\", \\\"{x:525,y:734,t:1527030919945};\\\", \\\"{x:524,y:739,t:1527030919961};\\\", \\\"{x:522,y:743,t:1527030919978};\\\", \\\"{x:521,y:745,t:1527030919995};\\\", \\\"{x:520,y:746,t:1527030920011};\\\", \\\"{x:517,y:749,t:1527030921481};\\\", \\\"{x:516,y:751,t:1527030921495};\\\", \\\"{x:514,y:753,t:1527030921512};\\\", \\\"{x:512,y:754,t:1527030921528};\\\", \\\"{x:510,y:755,t:1527030921545};\\\", \\\"{x:508,y:756,t:1527030921563};\\\", \\\"{x:508,y:754,t:1527030922732};\\\", \\\"{x:508,y:750,t:1527030922746};\\\", \\\"{x:508,y:749,t:1527030922764};\\\", \\\"{x:508,y:746,t:1527030922779};\\\", \\\"{x:508,y:745,t:1527030922817};\\\", \\\"{x:508,y:743,t:1527030922849};\\\", \\\"{x:508,y:740,t:1527030924633};\\\", \\\"{x:508,y:739,t:1527030924647};\\\", \\\"{x:508,y:737,t:1527030924664};\\\", \\\"{x:509,y:734,t:1527030924681};\\\" ] }, { \\\"rt\\\": 99144, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 19, \\\"time_elapsed\\\": 783584, \\\"internal_node_id\\\": \\\"0.0-6.0-9.0\\\", \\\"subject\\\": \\\"E5L6P\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 15, \\\"clicks\\\": 3, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"E\\\", \\\"F\\\", \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F -F -F -B -B -E -E -08 AM-01 PM-02 PM-O -X -X -X -X -X -3-F -O -O -03 PM-02 PM-X -X -M -M -C -E -E \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:508,y:734,t:1527030928657};\\\", \\\"{x:507,y:736,t:1527030928673};\\\", \\\"{x:505,y:742,t:1527030928783};\\\", \\\"{x:508,y:740,t:1527030930890};\\\", \\\"{x:512,y:740,t:1527030930904};\\\", \\\"{x:516,y:737,t:1527030930922};\\\", \\\"{x:520,y:736,t:1527030930937};\\\", \\\"{x:522,y:735,t:1527030930954};\\\", \\\"{x:524,y:733,t:1527030930972};\\\", \\\"{x:525,y:732,t:1527030930987};\\\", \\\"{x:530,y:728,t:1527030931004};\\\", \\\"{x:533,y:725,t:1527030931019};\\\", \\\"{x:540,y:717,t:1527030931035};\\\", \\\"{x:546,y:711,t:1527030931053};\\\", \\\"{x:550,y:704,t:1527030931069};\\\", \\\"{x:556,y:695,t:1527030931086};\\\", \\\"{x:559,y:690,t:1527030931103};\\\", \\\"{x:563,y:681,t:1527030931119};\\\", \\\"{x:567,y:665,t:1527030931136};\\\", \\\"{x:571,y:653,t:1527030931152};\\\", \\\"{x:576,y:643,t:1527030931170};\\\", \\\"{x:578,y:638,t:1527030931186};\\\", \\\"{x:579,y:637,t:1527030931202};\\\", \\\"{x:580,y:636,t:1527030931220};\\\", \\\"{x:582,y:636,t:1527030931236};\\\", \\\"{x:583,y:635,t:1527030931253};\\\", \\\"{x:584,y:635,t:1527030931270};\\\", \\\"{x:585,y:634,t:1527030931287};\\\", \\\"{x:586,y:633,t:1527030931303};\\\", \\\"{x:592,y:630,t:1527030931320};\\\", \\\"{x:608,y:623,t:1527030931338};\\\", \\\"{x:631,y:617,t:1527030931353};\\\", \\\"{x:656,y:614,t:1527030931370};\\\", \\\"{x:682,y:607,t:1527030931387};\\\", \\\"{x:704,y:605,t:1527030931403};\\\", \\\"{x:724,y:605,t:1527030931421};\\\", \\\"{x:750,y:605,t:1527030931436};\\\", \\\"{x:777,y:605,t:1527030931453};\\\", \\\"{x:807,y:605,t:1527030931470};\\\", \\\"{x:832,y:607,t:1527030931487};\\\", \\\"{x:856,y:610,t:1527030931504};\\\", \\\"{x:878,y:614,t:1527030931520};\\\", \\\"{x:914,y:619,t:1527030931537};\\\", \\\"{x:936,y:622,t:1527030931553};\\\", \\\"{x:958,y:625,t:1527030931570};\\\", \\\"{x:982,y:629,t:1527030931587};\\\", \\\"{x:1004,y:631,t:1527030931604};\\\", \\\"{x:1027,y:636,t:1527030931620};\\\", \\\"{x:1055,y:641,t:1527030931637};\\\", \\\"{x:1082,y:644,t:1527030931654};\\\", \\\"{x:1107,y:649,t:1527030931670};\\\", \\\"{x:1130,y:652,t:1527030931686};\\\", \\\"{x:1156,y:655,t:1527030931703};\\\", \\\"{x:1188,y:661,t:1527030931721};\\\", \\\"{x:1204,y:664,t:1527030931737};\\\", \\\"{x:1214,y:665,t:1527030931754};\\\", \\\"{x:1228,y:665,t:1527030931770};\\\", \\\"{x:1243,y:666,t:1527030931787};\\\", \\\"{x:1247,y:668,t:1527030931804};\\\", \\\"{x:1248,y:668,t:1527030931821};\\\", \\\"{x:1250,y:668,t:1527030931837};\\\", \\\"{x:1251,y:669,t:1527030931854};\\\", \\\"{x:1256,y:670,t:1527030931871};\\\", \\\"{x:1262,y:673,t:1527030931887};\\\", \\\"{x:1268,y:676,t:1527030931904};\\\", \\\"{x:1283,y:682,t:1527030931921};\\\", \\\"{x:1288,y:683,t:1527030931937};\\\", \\\"{x:1305,y:692,t:1527030931955};\\\", \\\"{x:1313,y:697,t:1527030931971};\\\", \\\"{x:1320,y:702,t:1527030931987};\\\", \\\"{x:1326,y:706,t:1527030932004};\\\", \\\"{x:1334,y:710,t:1527030932021};\\\", \\\"{x:1339,y:713,t:1527030932037};\\\", \\\"{x:1343,y:717,t:1527030932054};\\\", \\\"{x:1347,y:718,t:1527030932071};\\\", \\\"{x:1348,y:719,t:1527030932087};\\\", \\\"{x:1350,y:720,t:1527030932105};\\\", \\\"{x:1350,y:721,t:1527030932121};\\\", \\\"{x:1353,y:722,t:1527030932137};\\\", \\\"{x:1354,y:724,t:1527030932154};\\\", \\\"{x:1356,y:727,t:1527030932171};\\\", \\\"{x:1358,y:730,t:1527030932187};\\\", \\\"{x:1361,y:733,t:1527030932204};\\\", \\\"{x:1362,y:735,t:1527030932221};\\\", \\\"{x:1364,y:738,t:1527030932237};\\\", \\\"{x:1365,y:741,t:1527030932255};\\\", \\\"{x:1366,y:743,t:1527030932272};\\\", \\\"{x:1367,y:746,t:1527030932289};\\\", \\\"{x:1367,y:747,t:1527030932304};\\\", \\\"{x:1368,y:750,t:1527030932321};\\\", \\\"{x:1368,y:751,t:1527030932337};\\\", \\\"{x:1369,y:753,t:1527030932355};\\\", \\\"{x:1369,y:755,t:1527030932371};\\\", \\\"{x:1369,y:756,t:1527030932388};\\\", \\\"{x:1370,y:756,t:1527030932405};\\\", \\\"{x:1370,y:757,t:1527030933739};\\\", \\\"{x:1371,y:757,t:1527030934674};\\\", \\\"{x:1377,y:746,t:1527030934689};\\\", \\\"{x:1384,y:730,t:1527030934706};\\\", \\\"{x:1389,y:712,t:1527030934724};\\\", \\\"{x:1392,y:696,t:1527030934739};\\\", \\\"{x:1396,y:683,t:1527030934756};\\\", \\\"{x:1399,y:674,t:1527030934773};\\\", \\\"{x:1399,y:670,t:1527030934789};\\\", \\\"{x:1399,y:669,t:1527030934806};\\\", \\\"{x:1399,y:668,t:1527030934824};\\\", \\\"{x:1396,y:668,t:1527030934898};\\\", \\\"{x:1390,y:668,t:1527030934907};\\\", \\\"{x:1379,y:669,t:1527030934924};\\\", \\\"{x:1368,y:676,t:1527030934940};\\\", \\\"{x:1353,y:681,t:1527030934957};\\\", \\\"{x:1341,y:686,t:1527030934973};\\\", \\\"{x:1335,y:688,t:1527030934990};\\\", \\\"{x:1330,y:692,t:1527030935006};\\\", \\\"{x:1329,y:692,t:1527030935023};\\\", \\\"{x:1327,y:693,t:1527030935039};\\\", \\\"{x:1328,y:695,t:1527030936195};\\\", \\\"{x:1330,y:696,t:1527030936208};\\\", \\\"{x:1333,y:698,t:1527030936225};\\\", \\\"{x:1337,y:700,t:1527030936240};\\\", \\\"{x:1345,y:703,t:1527030936258};\\\", \\\"{x:1349,y:704,t:1527030936275};\\\", \\\"{x:1351,y:705,t:1527030936291};\\\", \\\"{x:1352,y:705,t:1527030936307};\\\", \\\"{x:1353,y:705,t:1527030936348};\\\", \\\"{x:1355,y:705,t:1527030936402};\\\", \\\"{x:1356,y:705,t:1527030936443};\\\", \\\"{x:1357,y:703,t:1527030936475};\\\", \\\"{x:1357,y:702,t:1527030936498};\\\", \\\"{x:1357,y:700,t:1527030936514};\\\", \\\"{x:1357,y:699,t:1527030936554};\\\", \\\"{x:1357,y:698,t:1527030936570};\\\", \\\"{x:1356,y:698,t:1527030936577};\\\", \\\"{x:1355,y:698,t:1527030936610};\\\", \\\"{x:1354,y:698,t:1527030936625};\\\", \\\"{x:1353,y:698,t:1527030936653};\\\", \\\"{x:1352,y:698,t:1527030936769};\\\", \\\"{x:1351,y:698,t:1527030936777};\\\", \\\"{x:1350,y:698,t:1527030936793};\\\", \\\"{x:1349,y:698,t:1527030936809};\\\", \\\"{x:1347,y:698,t:1527030936825};\\\", \\\"{x:1346,y:698,t:1527030936849};\\\", \\\"{x:1345,y:698,t:1527030936881};\\\", \\\"{x:1344,y:698,t:1527030936891};\\\", \\\"{x:1343,y:698,t:1527030936907};\\\", \\\"{x:1342,y:698,t:1527030936925};\\\", \\\"{x:1340,y:697,t:1527030936942};\\\", \\\"{x:1338,y:697,t:1527030936978};\\\", \\\"{x:1338,y:696,t:1527030937002};\\\", \\\"{x:1337,y:696,t:1527030937058};\\\", \\\"{x:1323,y:696,t:1527030937074};\\\", \\\"{x:1282,y:689,t:1527030937091};\\\", \\\"{x:1169,y:658,t:1527030937109};\\\", \\\"{x:1017,y:616,t:1527030937125};\\\", \\\"{x:835,y:566,t:1527030937143};\\\", \\\"{x:663,y:534,t:1527030937158};\\\", \\\"{x:508,y:513,t:1527030937174};\\\", \\\"{x:372,y:494,t:1527030937191};\\\", \\\"{x:262,y:482,t:1527030937209};\\\", \\\"{x:159,y:470,t:1527030937224};\\\", \\\"{x:136,y:470,t:1527030937241};\\\", \\\"{x:130,y:470,t:1527030937258};\\\", \\\"{x:131,y:471,t:1527030937337};\\\", \\\"{x:133,y:472,t:1527030937345};\\\", \\\"{x:134,y:473,t:1527030937358};\\\", \\\"{x:140,y:477,t:1527030937375};\\\", \\\"{x:144,y:480,t:1527030937391};\\\", \\\"{x:149,y:484,t:1527030937408};\\\", \\\"{x:160,y:492,t:1527030937425};\\\", \\\"{x:175,y:503,t:1527030937443};\\\", \\\"{x:190,y:515,t:1527030937458};\\\", \\\"{x:203,y:526,t:1527030937474};\\\", \\\"{x:214,y:540,t:1527030937492};\\\", \\\"{x:226,y:551,t:1527030937507};\\\", \\\"{x:235,y:557,t:1527030937525};\\\", \\\"{x:241,y:563,t:1527030937542};\\\", \\\"{x:244,y:565,t:1527030937558};\\\", \\\"{x:247,y:568,t:1527030937575};\\\", \\\"{x:238,y:567,t:1527030937673};\\\", \\\"{x:233,y:566,t:1527030937682};\\\", \\\"{x:221,y:562,t:1527030937692};\\\", \\\"{x:199,y:557,t:1527030937708};\\\", \\\"{x:177,y:556,t:1527030937727};\\\", \\\"{x:153,y:555,t:1527030937742};\\\", \\\"{x:128,y:549,t:1527030937759};\\\", \\\"{x:106,y:546,t:1527030937775};\\\", \\\"{x:96,y:545,t:1527030937792};\\\", \\\"{x:92,y:544,t:1527030937809};\\\", \\\"{x:91,y:544,t:1527030937833};\\\", \\\"{x:91,y:546,t:1527030937842};\\\", \\\"{x:93,y:553,t:1527030937859};\\\", \\\"{x:96,y:560,t:1527030937875};\\\", \\\"{x:101,y:570,t:1527030937892};\\\", \\\"{x:105,y:581,t:1527030937910};\\\", \\\"{x:113,y:591,t:1527030937925};\\\", \\\"{x:118,y:598,t:1527030937942};\\\", \\\"{x:127,y:607,t:1527030937958};\\\", \\\"{x:141,y:618,t:1527030937976};\\\", \\\"{x:157,y:629,t:1527030937992};\\\", \\\"{x:178,y:640,t:1527030938008};\\\", \\\"{x:223,y:657,t:1527030938025};\\\", \\\"{x:253,y:664,t:1527030938042};\\\", \\\"{x:292,y:670,t:1527030938059};\\\", \\\"{x:335,y:671,t:1527030938075};\\\", \\\"{x:373,y:674,t:1527030938092};\\\", \\\"{x:421,y:675,t:1527030938109};\\\", \\\"{x:478,y:679,t:1527030938126};\\\", \\\"{x:541,y:685,t:1527030938143};\\\", \\\"{x:589,y:691,t:1527030938159};\\\", \\\"{x:622,y:691,t:1527030938175};\\\", \\\"{x:642,y:691,t:1527030938192};\\\", \\\"{x:663,y:689,t:1527030938209};\\\", \\\"{x:675,y:685,t:1527030938227};\\\", \\\"{x:688,y:681,t:1527030938242};\\\", \\\"{x:696,y:678,t:1527030938259};\\\", \\\"{x:704,y:673,t:1527030938276};\\\", \\\"{x:708,y:669,t:1527030938293};\\\", \\\"{x:712,y:664,t:1527030938310};\\\", \\\"{x:719,y:658,t:1527030938326};\\\", \\\"{x:725,y:652,t:1527030938344};\\\", \\\"{x:734,y:646,t:1527030938359};\\\", \\\"{x:744,y:637,t:1527030938377};\\\", \\\"{x:759,y:627,t:1527030938393};\\\", \\\"{x:765,y:622,t:1527030938409};\\\", \\\"{x:771,y:616,t:1527030938426};\\\", \\\"{x:775,y:610,t:1527030938442};\\\", \\\"{x:778,y:602,t:1527030938459};\\\", \\\"{x:779,y:594,t:1527030938476};\\\", \\\"{x:779,y:587,t:1527030938492};\\\", \\\"{x:781,y:583,t:1527030938509};\\\", \\\"{x:783,y:580,t:1527030938526};\\\", \\\"{x:784,y:578,t:1527030938542};\\\", \\\"{x:784,y:577,t:1527030938559};\\\", \\\"{x:784,y:576,t:1527030938577};\\\", \\\"{x:785,y:574,t:1527030938601};\\\", \\\"{x:786,y:573,t:1527030938617};\\\", \\\"{x:787,y:573,t:1527030938626};\\\", \\\"{x:789,y:570,t:1527030938643};\\\", \\\"{x:792,y:569,t:1527030938659};\\\", \\\"{x:796,y:565,t:1527030938676};\\\", \\\"{x:798,y:563,t:1527030938693};\\\", \\\"{x:802,y:560,t:1527030938709};\\\", \\\"{x:808,y:556,t:1527030938726};\\\", \\\"{x:813,y:553,t:1527030938743};\\\", \\\"{x:817,y:548,t:1527030938759};\\\", \\\"{x:823,y:543,t:1527030938776};\\\", \\\"{x:828,y:537,t:1527030938794};\\\", \\\"{x:832,y:532,t:1527030938809};\\\", \\\"{x:836,y:528,t:1527030938827};\\\", \\\"{x:840,y:524,t:1527030938843};\\\", \\\"{x:842,y:521,t:1527030938859};\\\", \\\"{x:844,y:518,t:1527030938876};\\\", \\\"{x:844,y:516,t:1527030938897};\\\", \\\"{x:845,y:515,t:1527030938909};\\\", \\\"{x:845,y:514,t:1527030938953};\\\", \\\"{x:846,y:513,t:1527030938961};\\\", \\\"{x:846,y:512,t:1527030938985};\\\", \\\"{x:847,y:512,t:1527030939098};\\\", \\\"{x:853,y:512,t:1527030939594};\\\", \\\"{x:886,y:519,t:1527030939612};\\\", \\\"{x:961,y:541,t:1527030939627};\\\", \\\"{x:1059,y:571,t:1527030939643};\\\", \\\"{x:1163,y:609,t:1527030939660};\\\", \\\"{x:1259,y:647,t:1527030939677};\\\", \\\"{x:1351,y:677,t:1527030939693};\\\", \\\"{x:1414,y:694,t:1527030939710};\\\", \\\"{x:1459,y:700,t:1527030939727};\\\", \\\"{x:1481,y:700,t:1527030939743};\\\", \\\"{x:1492,y:700,t:1527030939760};\\\", \\\"{x:1495,y:699,t:1527030939777};\\\", \\\"{x:1496,y:697,t:1527030939793};\\\", \\\"{x:1496,y:696,t:1527030939810};\\\", \\\"{x:1493,y:689,t:1527030939827};\\\", \\\"{x:1483,y:679,t:1527030939844};\\\", \\\"{x:1465,y:664,t:1527030939860};\\\", \\\"{x:1443,y:652,t:1527030939877};\\\", \\\"{x:1422,y:639,t:1527030939893};\\\", \\\"{x:1402,y:634,t:1527030939910};\\\", \\\"{x:1380,y:632,t:1527030939927};\\\", \\\"{x:1358,y:632,t:1527030939944};\\\", \\\"{x:1338,y:645,t:1527030939960};\\\", \\\"{x:1318,y:685,t:1527030939977};\\\", \\\"{x:1310,y:713,t:1527030939995};\\\", \\\"{x:1303,y:734,t:1527030940010};\\\", \\\"{x:1300,y:744,t:1527030940027};\\\", \\\"{x:1299,y:751,t:1527030940045};\\\", \\\"{x:1299,y:752,t:1527030940061};\\\", \\\"{x:1300,y:752,t:1527030940490};\\\", \\\"{x:1301,y:752,t:1527030940498};\\\", \\\"{x:1305,y:752,t:1527030940512};\\\", \\\"{x:1315,y:752,t:1527030940527};\\\", \\\"{x:1331,y:750,t:1527030940544};\\\", \\\"{x:1356,y:746,t:1527030940560};\\\", \\\"{x:1368,y:745,t:1527030940577};\\\", \\\"{x:1380,y:743,t:1527030940594};\\\", \\\"{x:1389,y:740,t:1527030940611};\\\", \\\"{x:1398,y:739,t:1527030940627};\\\", \\\"{x:1409,y:738,t:1527030940645};\\\", \\\"{x:1418,y:736,t:1527030940662};\\\", \\\"{x:1424,y:734,t:1527030940678};\\\", \\\"{x:1426,y:732,t:1527030940694};\\\", \\\"{x:1428,y:731,t:1527030940711};\\\", \\\"{x:1429,y:730,t:1527030940727};\\\", \\\"{x:1430,y:728,t:1527030940745};\\\", \\\"{x:1430,y:724,t:1527030940761};\\\", \\\"{x:1430,y:720,t:1527030940777};\\\", \\\"{x:1430,y:715,t:1527030940794};\\\", \\\"{x:1428,y:708,t:1527030940812};\\\", \\\"{x:1423,y:703,t:1527030940827};\\\", \\\"{x:1420,y:698,t:1527030940845};\\\", \\\"{x:1417,y:694,t:1527030940862};\\\", \\\"{x:1412,y:690,t:1527030940877};\\\", \\\"{x:1409,y:687,t:1527030940894};\\\", \\\"{x:1406,y:686,t:1527030940912};\\\", \\\"{x:1403,y:683,t:1527030940927};\\\", \\\"{x:1402,y:683,t:1527030940944};\\\", \\\"{x:1401,y:682,t:1527030940961};\\\", \\\"{x:1400,y:682,t:1527030940979};\\\", \\\"{x:1399,y:682,t:1527030940995};\\\", \\\"{x:1398,y:682,t:1527030941017};\\\", \\\"{x:1397,y:682,t:1527030941443};\\\", \\\"{x:1395,y:682,t:1527030941450};\\\", \\\"{x:1393,y:682,t:1527030941462};\\\", \\\"{x:1389,y:682,t:1527030941479};\\\", \\\"{x:1384,y:682,t:1527030941496};\\\", \\\"{x:1377,y:682,t:1527030941512};\\\", \\\"{x:1372,y:682,t:1527030941529};\\\", \\\"{x:1365,y:682,t:1527030941546};\\\", \\\"{x:1361,y:682,t:1527030941561};\\\", \\\"{x:1356,y:682,t:1527030941579};\\\", \\\"{x:1354,y:682,t:1527030941596};\\\", \\\"{x:1351,y:682,t:1527030941611};\\\", \\\"{x:1347,y:682,t:1527030941628};\\\", \\\"{x:1344,y:682,t:1527030941646};\\\", \\\"{x:1340,y:684,t:1527030941663};\\\", \\\"{x:1337,y:684,t:1527030941679};\\\", \\\"{x:1334,y:684,t:1527030941696};\\\", \\\"{x:1330,y:684,t:1527030941712};\\\", \\\"{x:1326,y:684,t:1527030941728};\\\", \\\"{x:1319,y:686,t:1527030941744};\\\", \\\"{x:1316,y:686,t:1527030941761};\\\", \\\"{x:1312,y:686,t:1527030941778};\\\", \\\"{x:1310,y:686,t:1527030941795};\\\", \\\"{x:1309,y:686,t:1527030941811};\\\", \\\"{x:1308,y:686,t:1527030942155};\\\", \\\"{x:1307,y:686,t:1527030942163};\\\", \\\"{x:1305,y:687,t:1527030942186};\\\", \\\"{x:1304,y:688,t:1527030942202};\\\", \\\"{x:1303,y:688,t:1527030942213};\\\", \\\"{x:1304,y:688,t:1527030943706};\\\", \\\"{x:1305,y:688,t:1527030943722};\\\", \\\"{x:1306,y:688,t:1527030943737};\\\", \\\"{x:1307,y:688,t:1527030943778};\\\", \\\"{x:1308,y:688,t:1527030943907};\\\", \\\"{x:1309,y:688,t:1527030943913};\\\", \\\"{x:1314,y:688,t:1527030943931};\\\", \\\"{x:1317,y:689,t:1527030943947};\\\", \\\"{x:1321,y:691,t:1527030943963};\\\", \\\"{x:1323,y:692,t:1527030943980};\\\", \\\"{x:1327,y:693,t:1527030943997};\\\", \\\"{x:1330,y:693,t:1527030944013};\\\", \\\"{x:1332,y:695,t:1527030944030};\\\", \\\"{x:1333,y:695,t:1527030944047};\\\", \\\"{x:1334,y:695,t:1527030944081};\\\", \\\"{x:1336,y:696,t:1527030944482};\\\", \\\"{x:1337,y:696,t:1527030944497};\\\", \\\"{x:1339,y:698,t:1527030944514};\\\", \\\"{x:1341,y:698,t:1527030944531};\\\", \\\"{x:1342,y:698,t:1527030944562};\\\", \\\"{x:1342,y:699,t:1527030945499};\\\", \\\"{x:1342,y:700,t:1527030945515};\\\", \\\"{x:1337,y:702,t:1527030945532};\\\", \\\"{x:1335,y:703,t:1527030945548};\\\", \\\"{x:1328,y:710,t:1527030945565};\\\", \\\"{x:1319,y:721,t:1527030945582};\\\", \\\"{x:1306,y:738,t:1527030945598};\\\", \\\"{x:1288,y:757,t:1527030945616};\\\", \\\"{x:1270,y:774,t:1527030945632};\\\", \\\"{x:1251,y:787,t:1527030945648};\\\", \\\"{x:1233,y:799,t:1527030945666};\\\", \\\"{x:1213,y:804,t:1527030945681};\\\", \\\"{x:1209,y:805,t:1527030945699};\\\", \\\"{x:1208,y:805,t:1527030945754};\\\", \\\"{x:1208,y:804,t:1527030945770};\\\", \\\"{x:1208,y:803,t:1527030945786};\\\", \\\"{x:1208,y:801,t:1527030945799};\\\", \\\"{x:1208,y:797,t:1527030945815};\\\", \\\"{x:1213,y:787,t:1527030945833};\\\", \\\"{x:1223,y:775,t:1527030945849};\\\", \\\"{x:1235,y:763,t:1527030945865};\\\", \\\"{x:1256,y:745,t:1527030945882};\\\", \\\"{x:1267,y:739,t:1527030945899};\\\", \\\"{x:1275,y:733,t:1527030945915};\\\", \\\"{x:1286,y:727,t:1527030945932};\\\", \\\"{x:1292,y:724,t:1527030945950};\\\", \\\"{x:1295,y:721,t:1527030945965};\\\", \\\"{x:1298,y:718,t:1527030945982};\\\", \\\"{x:1299,y:715,t:1527030945999};\\\", \\\"{x:1301,y:710,t:1527030946015};\\\", \\\"{x:1302,y:706,t:1527030946032};\\\", \\\"{x:1302,y:701,t:1527030946049};\\\", \\\"{x:1304,y:696,t:1527030946066};\\\", \\\"{x:1304,y:694,t:1527030946082};\\\", \\\"{x:1304,y:693,t:1527030946099};\\\", \\\"{x:1304,y:688,t:1527030946116};\\\", \\\"{x:1304,y:680,t:1527030946132};\\\", \\\"{x:1309,y:665,t:1527030946149};\\\", \\\"{x:1312,y:650,t:1527030946166};\\\", \\\"{x:1315,y:632,t:1527030946182};\\\", \\\"{x:1316,y:614,t:1527030946200};\\\", \\\"{x:1316,y:595,t:1527030946216};\\\", \\\"{x:1316,y:577,t:1527030946232};\\\", \\\"{x:1313,y:562,t:1527030946250};\\\", \\\"{x:1304,y:546,t:1527030946266};\\\", \\\"{x:1298,y:533,t:1527030946282};\\\", \\\"{x:1290,y:522,t:1527030946299};\\\", \\\"{x:1282,y:513,t:1527030946316};\\\", \\\"{x:1277,y:509,t:1527030946333};\\\", \\\"{x:1274,y:507,t:1527030946349};\\\", \\\"{x:1274,y:506,t:1527030946376};\\\", \\\"{x:1274,y:507,t:1527030946433};\\\", \\\"{x:1275,y:513,t:1527030946449};\\\", \\\"{x:1292,y:531,t:1527030946465};\\\", \\\"{x:1302,y:540,t:1527030946481};\\\", \\\"{x:1310,y:546,t:1527030946499};\\\", \\\"{x:1316,y:550,t:1527030946516};\\\", \\\"{x:1318,y:550,t:1527030946531};\\\", \\\"{x:1319,y:551,t:1527030946818};\\\", \\\"{x:1319,y:552,t:1527030946849};\\\", \\\"{x:1318,y:555,t:1527030946865};\\\", \\\"{x:1316,y:558,t:1527030946883};\\\", \\\"{x:1314,y:562,t:1527030946900};\\\", \\\"{x:1312,y:567,t:1527030946916};\\\", \\\"{x:1310,y:576,t:1527030946933};\\\", \\\"{x:1308,y:586,t:1527030946949};\\\", \\\"{x:1308,y:601,t:1527030946965};\\\", \\\"{x:1308,y:621,t:1527030946983};\\\", \\\"{x:1308,y:634,t:1527030946999};\\\", \\\"{x:1307,y:638,t:1527030947015};\\\", \\\"{x:1307,y:644,t:1527030947033};\\\", \\\"{x:1304,y:651,t:1527030947049};\\\", \\\"{x:1304,y:654,t:1527030947066};\\\", \\\"{x:1304,y:655,t:1527030947089};\\\", \\\"{x:1303,y:657,t:1527030947099};\\\", \\\"{x:1303,y:660,t:1527030947115};\\\", \\\"{x:1305,y:667,t:1527030947132};\\\", \\\"{x:1307,y:672,t:1527030947149};\\\", \\\"{x:1312,y:679,t:1527030947165};\\\", \\\"{x:1312,y:681,t:1527030947183};\\\", \\\"{x:1312,y:686,t:1527030947200};\\\", \\\"{x:1313,y:688,t:1527030947216};\\\", \\\"{x:1314,y:688,t:1527030947378};\\\", \\\"{x:1315,y:688,t:1527030947450};\\\", \\\"{x:1320,y:694,t:1527030947466};\\\", \\\"{x:1325,y:703,t:1527030947483};\\\", \\\"{x:1329,y:712,t:1527030947500};\\\", \\\"{x:1340,y:726,t:1527030947516};\\\", \\\"{x:1342,y:740,t:1527030947533};\\\", \\\"{x:1347,y:753,t:1527030947550};\\\", \\\"{x:1350,y:761,t:1527030947566};\\\", \\\"{x:1351,y:764,t:1527030947583};\\\", \\\"{x:1351,y:767,t:1527030947600};\\\", \\\"{x:1349,y:770,t:1527030947617};\\\", \\\"{x:1344,y:775,t:1527030947633};\\\", \\\"{x:1342,y:777,t:1527030947649};\\\", \\\"{x:1340,y:784,t:1527030947667};\\\", \\\"{x:1338,y:788,t:1527030947683};\\\", \\\"{x:1338,y:792,t:1527030947700};\\\", \\\"{x:1336,y:803,t:1527030947717};\\\", \\\"{x:1334,y:812,t:1527030947733};\\\", \\\"{x:1334,y:820,t:1527030947750};\\\", \\\"{x:1334,y:827,t:1527030947767};\\\", \\\"{x:1334,y:830,t:1527030947783};\\\", \\\"{x:1334,y:833,t:1527030947801};\\\", \\\"{x:1334,y:832,t:1527030947914};\\\", \\\"{x:1336,y:826,t:1527030947922};\\\", \\\"{x:1337,y:819,t:1527030947933};\\\", \\\"{x:1337,y:800,t:1527030947950};\\\", \\\"{x:1337,y:772,t:1527030947966};\\\", \\\"{x:1330,y:734,t:1527030947982};\\\", \\\"{x:1323,y:697,t:1527030947999};\\\", \\\"{x:1321,y:674,t:1527030948017};\\\", \\\"{x:1319,y:646,t:1527030948033};\\\", \\\"{x:1317,y:633,t:1527030948050};\\\", \\\"{x:1313,y:621,t:1527030948067};\\\", \\\"{x:1310,y:612,t:1527030948083};\\\", \\\"{x:1307,y:605,t:1527030948099};\\\", \\\"{x:1306,y:601,t:1527030948117};\\\", \\\"{x:1305,y:599,t:1527030948133};\\\", \\\"{x:1304,y:595,t:1527030948150};\\\", \\\"{x:1304,y:591,t:1527030948167};\\\", \\\"{x:1303,y:585,t:1527030948184};\\\", \\\"{x:1302,y:580,t:1527030948200};\\\", \\\"{x:1301,y:571,t:1527030948217};\\\", \\\"{x:1299,y:562,t:1527030948233};\\\", \\\"{x:1297,y:554,t:1527030948250};\\\", \\\"{x:1294,y:549,t:1527030948266};\\\", \\\"{x:1292,y:546,t:1527030948284};\\\", \\\"{x:1290,y:542,t:1527030948299};\\\", \\\"{x:1289,y:541,t:1527030948317};\\\", \\\"{x:1289,y:540,t:1527030948334};\\\", \\\"{x:1288,y:539,t:1527030948350};\\\", \\\"{x:1287,y:538,t:1527030948367};\\\", \\\"{x:1284,y:537,t:1527030948384};\\\", \\\"{x:1280,y:537,t:1527030948400};\\\", \\\"{x:1272,y:537,t:1527030948417};\\\", \\\"{x:1258,y:537,t:1527030948433};\\\", \\\"{x:1244,y:537,t:1527030948450};\\\", \\\"{x:1228,y:539,t:1527030948468};\\\", \\\"{x:1211,y:544,t:1527030948484};\\\", \\\"{x:1198,y:548,t:1527030948500};\\\", \\\"{x:1184,y:553,t:1527030948517};\\\", \\\"{x:1175,y:557,t:1527030948535};\\\", \\\"{x:1170,y:558,t:1527030948550};\\\", \\\"{x:1168,y:558,t:1527030948568};\\\", \\\"{x:1169,y:558,t:1527030948674};\\\", \\\"{x:1174,y:556,t:1527030948684};\\\", \\\"{x:1182,y:553,t:1527030948701};\\\", \\\"{x:1190,y:548,t:1527030948718};\\\", \\\"{x:1198,y:545,t:1527030948734};\\\", \\\"{x:1203,y:543,t:1527030948751};\\\", \\\"{x:1208,y:542,t:1527030948768};\\\", \\\"{x:1213,y:542,t:1527030948785};\\\", \\\"{x:1216,y:542,t:1527030948801};\\\", \\\"{x:1220,y:542,t:1527030948817};\\\", \\\"{x:1224,y:540,t:1527030948834};\\\", \\\"{x:1227,y:539,t:1527030948851};\\\", \\\"{x:1231,y:539,t:1527030948868};\\\", \\\"{x:1236,y:538,t:1527030948884};\\\", \\\"{x:1242,y:538,t:1527030948901};\\\", \\\"{x:1246,y:538,t:1527030948917};\\\", \\\"{x:1250,y:538,t:1527030948935};\\\", \\\"{x:1251,y:538,t:1527030948952};\\\", \\\"{x:1253,y:538,t:1527030948968};\\\", \\\"{x:1255,y:538,t:1527030948986};\\\", \\\"{x:1259,y:539,t:1527030949002};\\\", \\\"{x:1265,y:540,t:1527030949017};\\\", \\\"{x:1271,y:540,t:1527030949034};\\\", \\\"{x:1277,y:540,t:1527030949051};\\\", \\\"{x:1289,y:544,t:1527030949069};\\\", \\\"{x:1298,y:546,t:1527030949085};\\\", \\\"{x:1308,y:550,t:1527030949101};\\\", \\\"{x:1311,y:551,t:1527030949118};\\\", \\\"{x:1311,y:552,t:1527030949235};\\\", \\\"{x:1311,y:553,t:1527030949258};\\\", \\\"{x:1311,y:554,t:1527030949268};\\\", \\\"{x:1308,y:557,t:1527030949285};\\\", \\\"{x:1306,y:557,t:1527030949301};\\\", \\\"{x:1303,y:558,t:1527030949318};\\\", \\\"{x:1301,y:559,t:1527030949334};\\\", \\\"{x:1300,y:560,t:1527030949354};\\\", \\\"{x:1299,y:560,t:1527030949368};\\\", \\\"{x:1299,y:561,t:1527030949386};\\\", \\\"{x:1298,y:561,t:1527030949491};\\\", \\\"{x:1296,y:561,t:1527030949514};\\\", \\\"{x:1294,y:561,t:1527030949522};\\\", \\\"{x:1293,y:561,t:1527030949534};\\\", \\\"{x:1289,y:561,t:1527030949552};\\\", \\\"{x:1286,y:563,t:1527030949569};\\\", \\\"{x:1283,y:564,t:1527030949585};\\\", \\\"{x:1281,y:564,t:1527030949601};\\\", \\\"{x:1279,y:565,t:1527030949618};\\\", \\\"{x:1278,y:565,t:1527030950058};\\\", \\\"{x:1277,y:566,t:1527030950068};\\\", \\\"{x:1277,y:567,t:1527030950085};\\\", \\\"{x:1276,y:568,t:1527030950102};\\\", \\\"{x:1275,y:569,t:1527030950121};\\\", \\\"{x:1275,y:566,t:1527030950330};\\\", \\\"{x:1276,y:566,t:1527030950346};\\\", \\\"{x:1276,y:564,t:1527030950367};\\\", \\\"{x:1277,y:562,t:1527030950385};\\\", \\\"{x:1277,y:560,t:1527030950432};\\\", \\\"{x:1278,y:560,t:1527030950457};\\\", \\\"{x:1271,y:560,t:1527030958163};\\\", \\\"{x:1250,y:560,t:1527030958174};\\\", \\\"{x:1180,y:560,t:1527030958191};\\\", \\\"{x:1090,y:566,t:1527030958207};\\\", \\\"{x:1019,y:571,t:1527030958225};\\\", \\\"{x:943,y:571,t:1527030958242};\\\", \\\"{x:896,y:571,t:1527030958257};\\\", \\\"{x:859,y:571,t:1527030958274};\\\", \\\"{x:823,y:571,t:1527030958291};\\\", \\\"{x:762,y:571,t:1527030958307};\\\", \\\"{x:670,y:571,t:1527030958325};\\\", \\\"{x:546,y:586,t:1527030958342};\\\", \\\"{x:413,y:605,t:1527030958357};\\\", \\\"{x:274,y:626,t:1527030958374};\\\", \\\"{x:12,y:664,t:1527030958409};\\\", \\\"{x:0,y:664,t:1527030958425};\\\", \\\"{x:0,y:663,t:1527030958464};\\\", \\\"{x:0,y:661,t:1527030958475};\\\", \\\"{x:0,y:647,t:1527030958492};\\\", \\\"{x:12,y:626,t:1527030958509};\\\", \\\"{x:38,y:602,t:1527030958525};\\\", \\\"{x:70,y:583,t:1527030958543};\\\", \\\"{x:114,y:567,t:1527030958560};\\\", \\\"{x:167,y:551,t:1527030958576};\\\", \\\"{x:207,y:538,t:1527030958592};\\\", \\\"{x:261,y:521,t:1527030958609};\\\", \\\"{x:278,y:513,t:1527030958625};\\\", \\\"{x:291,y:506,t:1527030958642};\\\", \\\"{x:302,y:502,t:1527030958659};\\\", \\\"{x:318,y:495,t:1527030958675};\\\", \\\"{x:332,y:488,t:1527030958692};\\\", \\\"{x:344,y:482,t:1527030958709};\\\", \\\"{x:354,y:476,t:1527030958726};\\\", \\\"{x:370,y:471,t:1527030958742};\\\", \\\"{x:388,y:468,t:1527030958758};\\\", \\\"{x:407,y:466,t:1527030958776};\\\", \\\"{x:429,y:466,t:1527030958792};\\\", \\\"{x:472,y:475,t:1527030958808};\\\", \\\"{x:507,y:485,t:1527030958826};\\\", \\\"{x:536,y:494,t:1527030958842};\\\", \\\"{x:560,y:499,t:1527030958859};\\\", \\\"{x:581,y:504,t:1527030958877};\\\", \\\"{x:599,y:504,t:1527030958892};\\\", \\\"{x:611,y:504,t:1527030958909};\\\", \\\"{x:616,y:503,t:1527030958926};\\\", \\\"{x:617,y:503,t:1527030958942};\\\", \\\"{x:619,y:503,t:1527030959009};\\\", \\\"{x:621,y:503,t:1527030959065};\\\", \\\"{x:619,y:503,t:1527030959129};\\\", \\\"{x:617,y:503,t:1527030959144};\\\", \\\"{x:614,y:504,t:1527030959159};\\\", \\\"{x:610,y:504,t:1527030959176};\\\", \\\"{x:608,y:505,t:1527030959192};\\\", \\\"{x:607,y:505,t:1527030959249};\\\", \\\"{x:608,y:507,t:1527030959755};\\\", \\\"{x:609,y:508,t:1527030959777};\\\", \\\"{x:610,y:508,t:1527030959794};\\\", \\\"{x:612,y:509,t:1527030959810};\\\", \\\"{x:614,y:510,t:1527030959826};\\\", \\\"{x:617,y:513,t:1527030959843};\\\", \\\"{x:621,y:516,t:1527030959861};\\\", \\\"{x:625,y:519,t:1527030959877};\\\", \\\"{x:633,y:523,t:1527030959893};\\\", \\\"{x:647,y:524,t:1527030959911};\\\", \\\"{x:662,y:524,t:1527030959927};\\\", \\\"{x:684,y:524,t:1527030959943};\\\", \\\"{x:707,y:524,t:1527030959960};\\\", \\\"{x:728,y:524,t:1527030959977};\\\", \\\"{x:750,y:527,t:1527030959992};\\\", \\\"{x:771,y:528,t:1527030960010};\\\", \\\"{x:790,y:528,t:1527030960026};\\\", \\\"{x:809,y:528,t:1527030960043};\\\", \\\"{x:835,y:528,t:1527030960061};\\\", \\\"{x:862,y:528,t:1527030960076};\\\", \\\"{x:890,y:528,t:1527030960093};\\\", \\\"{x:920,y:528,t:1527030960110};\\\", \\\"{x:952,y:528,t:1527030960128};\\\", \\\"{x:982,y:528,t:1527030960144};\\\", \\\"{x:1006,y:528,t:1527030960161};\\\", \\\"{x:1022,y:528,t:1527030960177};\\\", \\\"{x:1041,y:528,t:1527030960193};\\\", \\\"{x:1052,y:529,t:1527030960211};\\\", \\\"{x:1059,y:531,t:1527030960227};\\\", \\\"{x:1060,y:531,t:1527030960244};\\\", \\\"{x:1062,y:531,t:1527030961410};\\\", \\\"{x:1063,y:531,t:1527030961442};\\\", \\\"{x:1064,y:531,t:1527030961449};\\\", \\\"{x:1065,y:531,t:1527030961459};\\\", \\\"{x:1066,y:531,t:1527030961477};\\\", \\\"{x:1069,y:531,t:1527030961493};\\\", \\\"{x:1070,y:531,t:1527030961509};\\\", \\\"{x:1072,y:531,t:1527030961527};\\\", \\\"{x:1073,y:531,t:1527030961544};\\\", \\\"{x:1075,y:531,t:1527030961560};\\\", \\\"{x:1077,y:531,t:1527030961577};\\\", \\\"{x:1078,y:531,t:1527030961593};\\\", \\\"{x:1080,y:532,t:1527030961610};\\\", \\\"{x:1083,y:536,t:1527030961627};\\\", \\\"{x:1088,y:546,t:1527030961643};\\\", \\\"{x:1102,y:563,t:1527030961660};\\\", \\\"{x:1117,y:594,t:1527030961677};\\\", \\\"{x:1124,y:642,t:1527030961693};\\\", \\\"{x:1127,y:693,t:1527030961710};\\\", \\\"{x:1131,y:732,t:1527030961727};\\\", \\\"{x:1135,y:753,t:1527030961743};\\\", \\\"{x:1136,y:764,t:1527030961760};\\\", \\\"{x:1139,y:770,t:1527030961776};\\\", \\\"{x:1139,y:773,t:1527030961793};\\\", \\\"{x:1139,y:775,t:1527030961841};\\\", \\\"{x:1140,y:781,t:1527030961849};\\\", \\\"{x:1140,y:789,t:1527030961861};\\\", \\\"{x:1140,y:806,t:1527030961878};\\\", \\\"{x:1140,y:827,t:1527030961895};\\\", \\\"{x:1140,y:851,t:1527030961911};\\\", \\\"{x:1140,y:870,t:1527030961927};\\\", \\\"{x:1137,y:889,t:1527030961945};\\\", \\\"{x:1131,y:911,t:1527030961960};\\\", \\\"{x:1120,y:960,t:1527030961977};\\\", \\\"{x:1109,y:1002,t:1527030961994};\\\", \\\"{x:1098,y:1034,t:1527030962011};\\\", \\\"{x:1093,y:1052,t:1527030962028};\\\", \\\"{x:1093,y:1056,t:1527030962045};\\\", \\\"{x:1094,y:1056,t:1527030962122};\\\", \\\"{x:1094,y:1052,t:1527030962130};\\\", \\\"{x:1094,y:1051,t:1527030962144};\\\", \\\"{x:1094,y:1048,t:1527030962160};\\\", \\\"{x:1093,y:1021,t:1527030962177};\\\", \\\"{x:1090,y:998,t:1527030962195};\\\", \\\"{x:1090,y:978,t:1527030962211};\\\", \\\"{x:1090,y:958,t:1527030962228};\\\", \\\"{x:1090,y:939,t:1527030962244};\\\", \\\"{x:1090,y:920,t:1527030962260};\\\", \\\"{x:1090,y:902,t:1527030962278};\\\", \\\"{x:1085,y:888,t:1527030962295};\\\", \\\"{x:1082,y:880,t:1527030962311};\\\", \\\"{x:1082,y:875,t:1527030962327};\\\", \\\"{x:1079,y:870,t:1527030962345};\\\", \\\"{x:1077,y:864,t:1527030962361};\\\", \\\"{x:1075,y:860,t:1527030962378};\\\", \\\"{x:1073,y:860,t:1527030962801};\\\", \\\"{x:1072,y:865,t:1527030962811};\\\", \\\"{x:1071,y:880,t:1527030962827};\\\", \\\"{x:1072,y:895,t:1527030962844};\\\", \\\"{x:1081,y:909,t:1527030962861};\\\", \\\"{x:1093,y:916,t:1527030962878};\\\", \\\"{x:1101,y:920,t:1527030962895};\\\", \\\"{x:1107,y:921,t:1527030962911};\\\", \\\"{x:1109,y:922,t:1527030962928};\\\", \\\"{x:1106,y:922,t:1527030963282};\\\", \\\"{x:1105,y:922,t:1527030963295};\\\", \\\"{x:1097,y:918,t:1527030963312};\\\", \\\"{x:1092,y:914,t:1527030963328};\\\", \\\"{x:1086,y:910,t:1527030963345};\\\", \\\"{x:1084,y:908,t:1527030963362};\\\", \\\"{x:1086,y:908,t:1527030965141};\\\", \\\"{x:1094,y:908,t:1527030965149};\\\", \\\"{x:1112,y:908,t:1527030965165};\\\", \\\"{x:1132,y:903,t:1527030965181};\\\", \\\"{x:1157,y:895,t:1527030965197};\\\", \\\"{x:1179,y:892,t:1527030965215};\\\", \\\"{x:1200,y:892,t:1527030965232};\\\", \\\"{x:1209,y:892,t:1527030965247};\\\", \\\"{x:1213,y:892,t:1527030965265};\\\", \\\"{x:1217,y:892,t:1527030965282};\\\", \\\"{x:1222,y:897,t:1527030965298};\\\", \\\"{x:1235,y:906,t:1527030965315};\\\", \\\"{x:1251,y:916,t:1527030965331};\\\", \\\"{x:1274,y:929,t:1527030965349};\\\", \\\"{x:1285,y:936,t:1527030965365};\\\", \\\"{x:1294,y:941,t:1527030965382};\\\", \\\"{x:1310,y:948,t:1527030965398};\\\", \\\"{x:1330,y:958,t:1527030965415};\\\", \\\"{x:1350,y:963,t:1527030965432};\\\", \\\"{x:1368,y:968,t:1527030965448};\\\", \\\"{x:1388,y:971,t:1527030965465};\\\", \\\"{x:1407,y:974,t:1527030965482};\\\", \\\"{x:1428,y:976,t:1527030965499};\\\", \\\"{x:1449,y:978,t:1527030965516};\\\", \\\"{x:1464,y:978,t:1527030965532};\\\", \\\"{x:1472,y:978,t:1527030965549};\\\", \\\"{x:1476,y:978,t:1527030965565};\\\", \\\"{x:1479,y:977,t:1527030965582};\\\", \\\"{x:1484,y:975,t:1527030965599};\\\", \\\"{x:1488,y:974,t:1527030965616};\\\", \\\"{x:1495,y:972,t:1527030965632};\\\", \\\"{x:1498,y:970,t:1527030965650};\\\", \\\"{x:1501,y:969,t:1527030965666};\\\", \\\"{x:1503,y:968,t:1527030965683};\\\", \\\"{x:1504,y:968,t:1527030965699};\\\", \\\"{x:1505,y:968,t:1527030965717};\\\", \\\"{x:1506,y:968,t:1527030965732};\\\", \\\"{x:1507,y:968,t:1527030965750};\\\", \\\"{x:1508,y:968,t:1527030965765};\\\", \\\"{x:1509,y:966,t:1527030965941};\\\", \\\"{x:1509,y:963,t:1527030965949};\\\", \\\"{x:1509,y:956,t:1527030965964};\\\", \\\"{x:1509,y:948,t:1527030965982};\\\", \\\"{x:1510,y:940,t:1527030965998};\\\", \\\"{x:1512,y:934,t:1527030966014};\\\", \\\"{x:1515,y:926,t:1527030966032};\\\", \\\"{x:1520,y:914,t:1527030966048};\\\", \\\"{x:1522,y:908,t:1527030966065};\\\", \\\"{x:1525,y:899,t:1527030966082};\\\", \\\"{x:1525,y:895,t:1527030966099};\\\", \\\"{x:1525,y:892,t:1527030966115};\\\", \\\"{x:1530,y:884,t:1527030966132};\\\", \\\"{x:1533,y:871,t:1527030966148};\\\", \\\"{x:1538,y:853,t:1527030966165};\\\", \\\"{x:1542,y:830,t:1527030966182};\\\", \\\"{x:1546,y:806,t:1527030966200};\\\", \\\"{x:1549,y:781,t:1527030966215};\\\", \\\"{x:1552,y:752,t:1527030966232};\\\", \\\"{x:1555,y:726,t:1527030966249};\\\", \\\"{x:1557,y:711,t:1527030966265};\\\", \\\"{x:1561,y:698,t:1527030966282};\\\", \\\"{x:1562,y:689,t:1527030966299};\\\", \\\"{x:1562,y:686,t:1527030966316};\\\", \\\"{x:1562,y:685,t:1527030966332};\\\", \\\"{x:1561,y:687,t:1527030966413};\\\", \\\"{x:1559,y:693,t:1527030966421};\\\", \\\"{x:1557,y:700,t:1527030966433};\\\", \\\"{x:1555,y:714,t:1527030966450};\\\", \\\"{x:1552,y:727,t:1527030966466};\\\", \\\"{x:1552,y:734,t:1527030966482};\\\", \\\"{x:1552,y:738,t:1527030966500};\\\", \\\"{x:1551,y:742,t:1527030966516};\\\", \\\"{x:1550,y:745,t:1527030966532};\\\", \\\"{x:1549,y:747,t:1527030966550};\\\", \\\"{x:1548,y:749,t:1527030966565};\\\", \\\"{x:1548,y:750,t:1527030966693};\\\", \\\"{x:1547,y:751,t:1527030966701};\\\", \\\"{x:1545,y:752,t:1527030966716};\\\", \\\"{x:1541,y:752,t:1527030966732};\\\", \\\"{x:1537,y:755,t:1527030966748};\\\", \\\"{x:1531,y:758,t:1527030966765};\\\", \\\"{x:1529,y:760,t:1527030966781};\\\", \\\"{x:1526,y:762,t:1527030966798};\\\", \\\"{x:1522,y:763,t:1527030966816};\\\", \\\"{x:1518,y:765,t:1527030966832};\\\", \\\"{x:1516,y:765,t:1527030966849};\\\", \\\"{x:1514,y:765,t:1527030966866};\\\", \\\"{x:1513,y:765,t:1527030966884};\\\", \\\"{x:1512,y:765,t:1527030966898};\\\", \\\"{x:1511,y:765,t:1527030966916};\\\", \\\"{x:1510,y:765,t:1527030966932};\\\", \\\"{x:1509,y:765,t:1527030966997};\\\", \\\"{x:1509,y:766,t:1527030969430};\\\", \\\"{x:1509,y:768,t:1527030969437};\\\", \\\"{x:1509,y:769,t:1527030969450};\\\", \\\"{x:1506,y:776,t:1527030969466};\\\", \\\"{x:1506,y:780,t:1527030969483};\\\", \\\"{x:1503,y:788,t:1527030969500};\\\", \\\"{x:1503,y:792,t:1527030969516};\\\", \\\"{x:1503,y:798,t:1527030969533};\\\", \\\"{x:1503,y:807,t:1527030969550};\\\", \\\"{x:1503,y:817,t:1527030969566};\\\", \\\"{x:1503,y:831,t:1527030969583};\\\", \\\"{x:1503,y:841,t:1527030969600};\\\", \\\"{x:1503,y:851,t:1527030969616};\\\", \\\"{x:1504,y:863,t:1527030969633};\\\", \\\"{x:1505,y:871,t:1527030969651};\\\", \\\"{x:1507,y:876,t:1527030969667};\\\", \\\"{x:1509,y:882,t:1527030969684};\\\", \\\"{x:1511,y:888,t:1527030969700};\\\", \\\"{x:1511,y:890,t:1527030969716};\\\", \\\"{x:1513,y:892,t:1527030969734};\\\", \\\"{x:1513,y:893,t:1527030969751};\\\", \\\"{x:1514,y:894,t:1527030969766};\\\", \\\"{x:1515,y:895,t:1527030969813};\\\", \\\"{x:1515,y:896,t:1527030970013};\\\", \\\"{x:1515,y:897,t:1527030970021};\\\", \\\"{x:1515,y:898,t:1527030970037};\\\", \\\"{x:1515,y:899,t:1527030970053};\\\", \\\"{x:1514,y:897,t:1527030972910};\\\", \\\"{x:1513,y:891,t:1527030972918};\\\", \\\"{x:1509,y:877,t:1527030972934};\\\", \\\"{x:1507,y:871,t:1527030972951};\\\", \\\"{x:1506,y:866,t:1527030972967};\\\", \\\"{x:1506,y:862,t:1527030972984};\\\", \\\"{x:1505,y:860,t:1527030973001};\\\", \\\"{x:1505,y:857,t:1527030973017};\\\", \\\"{x:1505,y:855,t:1527030973034};\\\", \\\"{x:1505,y:852,t:1527030973573};\\\", \\\"{x:1505,y:848,t:1527030973585};\\\", \\\"{x:1505,y:842,t:1527030973601};\\\", \\\"{x:1505,y:837,t:1527030973618};\\\", \\\"{x:1505,y:835,t:1527030973634};\\\", \\\"{x:1505,y:832,t:1527030973652};\\\", \\\"{x:1507,y:827,t:1527030973668};\\\", \\\"{x:1509,y:822,t:1527030973685};\\\", \\\"{x:1511,y:820,t:1527030973702};\\\", \\\"{x:1512,y:818,t:1527030973718};\\\", \\\"{x:1513,y:816,t:1527030973735};\\\", \\\"{x:1514,y:814,t:1527030973752};\\\", \\\"{x:1515,y:813,t:1527030973769};\\\", \\\"{x:1515,y:812,t:1527030974205};\\\", \\\"{x:1517,y:812,t:1527030974219};\\\", \\\"{x:1518,y:814,t:1527030974235};\\\", \\\"{x:1519,y:814,t:1527030974252};\\\", \\\"{x:1519,y:815,t:1527030974269};\\\", \\\"{x:1519,y:816,t:1527030974292};\\\", \\\"{x:1520,y:817,t:1527030974301};\\\", \\\"{x:1520,y:818,t:1527030974319};\\\", \\\"{x:1522,y:819,t:1527030974335};\\\", \\\"{x:1522,y:820,t:1527030974351};\\\", \\\"{x:1522,y:821,t:1527030974369};\\\", \\\"{x:1523,y:823,t:1527030974384};\\\", \\\"{x:1523,y:824,t:1527030974401};\\\", \\\"{x:1523,y:825,t:1527030974419};\\\", \\\"{x:1523,y:827,t:1527030974434};\\\", \\\"{x:1523,y:828,t:1527030974452};\\\", \\\"{x:1523,y:831,t:1527030974469};\\\", \\\"{x:1523,y:833,t:1527030974485};\\\", \\\"{x:1523,y:834,t:1527030974502};\\\", \\\"{x:1521,y:836,t:1527030974525};\\\", \\\"{x:1520,y:837,t:1527030974549};\\\", \\\"{x:1519,y:837,t:1527030974557};\\\", \\\"{x:1517,y:838,t:1527030974573};\\\", \\\"{x:1516,y:838,t:1527030974585};\\\", \\\"{x:1511,y:839,t:1527030974601};\\\", \\\"{x:1507,y:840,t:1527030974618};\\\", \\\"{x:1503,y:841,t:1527030974634};\\\", \\\"{x:1497,y:841,t:1527030974651};\\\", \\\"{x:1486,y:841,t:1527030974668};\\\", \\\"{x:1477,y:841,t:1527030974684};\\\", \\\"{x:1468,y:841,t:1527030974701};\\\", \\\"{x:1464,y:841,t:1527030974718};\\\", \\\"{x:1459,y:840,t:1527030974734};\\\", \\\"{x:1458,y:840,t:1527030974756};\\\", \\\"{x:1457,y:839,t:1527030974780};\\\", \\\"{x:1456,y:839,t:1527030974870};\\\", \\\"{x:1456,y:838,t:1527030974885};\\\", \\\"{x:1455,y:838,t:1527030974902};\\\", \\\"{x:1455,y:837,t:1527030974919};\\\", \\\"{x:1454,y:836,t:1527030974936};\\\", \\\"{x:1454,y:835,t:1527030974981};\\\", \\\"{x:1454,y:834,t:1527030975037};\\\", \\\"{x:1454,y:833,t:1527030975052};\\\", \\\"{x:1454,y:832,t:1527030975068};\\\", \\\"{x:1454,y:831,t:1527030975086};\\\", \\\"{x:1454,y:830,t:1527030975102};\\\", \\\"{x:1456,y:830,t:1527030975157};\\\", \\\"{x:1457,y:830,t:1527030975213};\\\", \\\"{x:1459,y:830,t:1527030975277};\\\", \\\"{x:1460,y:830,t:1527030975300};\\\", \\\"{x:1462,y:830,t:1527030975319};\\\", \\\"{x:1463,y:830,t:1527030975341};\\\", \\\"{x:1465,y:830,t:1527030975357};\\\", \\\"{x:1466,y:830,t:1527030975373};\\\", \\\"{x:1467,y:830,t:1527030975386};\\\", \\\"{x:1468,y:830,t:1527030975402};\\\", \\\"{x:1469,y:831,t:1527030975419};\\\", \\\"{x:1471,y:831,t:1527030975526};\\\", \\\"{x:1472,y:831,t:1527030975581};\\\", \\\"{x:1473,y:831,t:1527030975589};\\\", \\\"{x:1474,y:831,t:1527030975605};\\\", \\\"{x:1475,y:831,t:1527030975621};\\\", \\\"{x:1476,y:831,t:1527030975636};\\\", \\\"{x:1479,y:830,t:1527030975651};\\\", \\\"{x:1485,y:827,t:1527030975669};\\\", \\\"{x:1489,y:826,t:1527030975687};\\\", \\\"{x:1491,y:824,t:1527030975702};\\\", \\\"{x:1492,y:824,t:1527030975718};\\\", \\\"{x:1493,y:824,t:1527030976549};\\\", \\\"{x:1493,y:826,t:1527030976564};\\\", \\\"{x:1492,y:827,t:1527030976573};\\\", \\\"{x:1491,y:828,t:1527030976585};\\\", \\\"{x:1489,y:831,t:1527030976603};\\\", \\\"{x:1488,y:832,t:1527030976619};\\\", \\\"{x:1488,y:833,t:1527030976636};\\\", \\\"{x:1487,y:834,t:1527030976653};\\\", \\\"{x:1487,y:835,t:1527030977262};\\\", \\\"{x:1486,y:836,t:1527030977284};\\\", \\\"{x:1485,y:837,t:1527030977303};\\\", \\\"{x:1484,y:836,t:1527030977637};\\\", \\\"{x:1484,y:835,t:1527030977652};\\\", \\\"{x:1484,y:834,t:1527030977670};\\\", \\\"{x:1483,y:833,t:1527030977686};\\\", \\\"{x:1482,y:833,t:1527030977933};\\\", \\\"{x:1482,y:832,t:1527030980125};\\\", \\\"{x:1483,y:832,t:1527030980137};\\\", \\\"{x:1485,y:830,t:1527030980154};\\\", \\\"{x:1488,y:829,t:1527030980171};\\\", \\\"{x:1491,y:827,t:1527030980187};\\\", \\\"{x:1494,y:827,t:1527030980204};\\\", \\\"{x:1496,y:826,t:1527030980220};\\\", \\\"{x:1497,y:826,t:1527030980237};\\\", \\\"{x:1497,y:825,t:1527030980276};\\\", \\\"{x:1496,y:825,t:1527030980454};\\\", \\\"{x:1490,y:825,t:1527030980470};\\\", \\\"{x:1485,y:825,t:1527030980487};\\\", \\\"{x:1480,y:825,t:1527030980505};\\\", \\\"{x:1475,y:825,t:1527030980521};\\\", \\\"{x:1468,y:827,t:1527030980537};\\\", \\\"{x:1463,y:827,t:1527030980554};\\\", \\\"{x:1461,y:827,t:1527030980570};\\\", \\\"{x:1459,y:828,t:1527030980587};\\\", \\\"{x:1459,y:829,t:1527030980661};\\\", \\\"{x:1461,y:828,t:1527030980869};\\\", \\\"{x:1463,y:828,t:1527030980877};\\\", \\\"{x:1466,y:827,t:1527030980887};\\\", \\\"{x:1470,y:826,t:1527030980904};\\\", \\\"{x:1474,y:825,t:1527030980920};\\\", \\\"{x:1474,y:824,t:1527030980937};\\\", \\\"{x:1475,y:824,t:1527030980954};\\\", \\\"{x:1476,y:824,t:1527030981003};\\\", \\\"{x:1478,y:823,t:1527030981019};\\\", \\\"{x:1480,y:824,t:1527030981148};\\\", \\\"{x:1481,y:824,t:1527030981157};\\\", \\\"{x:1481,y:825,t:1527030981228};\\\", \\\"{x:1481,y:826,t:1527030981236};\\\", \\\"{x:1481,y:827,t:1527030981253};\\\", \\\"{x:1482,y:830,t:1527030981270};\\\", \\\"{x:1482,y:831,t:1527030981286};\\\", \\\"{x:1482,y:832,t:1527030981308};\\\", \\\"{x:1481,y:834,t:1527030981501};\\\", \\\"{x:1474,y:835,t:1527030981510};\\\", \\\"{x:1465,y:840,t:1527030981521};\\\", \\\"{x:1444,y:844,t:1527030981537};\\\", \\\"{x:1425,y:844,t:1527030981554};\\\", \\\"{x:1370,y:840,t:1527030981571};\\\", \\\"{x:1265,y:824,t:1527030981587};\\\", \\\"{x:1141,y:794,t:1527030981604};\\\", \\\"{x:904,y:755,t:1527030981621};\\\", \\\"{x:713,y:728,t:1527030981637};\\\", \\\"{x:504,y:702,t:1527030981654};\\\", \\\"{x:311,y:686,t:1527030981671};\\\", \\\"{x:140,y:664,t:1527030981688};\\\", \\\"{x:17,y:654,t:1527030981704};\\\", \\\"{x:0,y:654,t:1527030981720};\\\", \\\"{x:0,y:650,t:1527030981732};\\\", \\\"{x:0,y:647,t:1527030981747};\\\", \\\"{x:0,y:635,t:1527030981765};\\\", \\\"{x:0,y:633,t:1527030981812};\\\", \\\"{x:3,y:630,t:1527030981820};\\\", \\\"{x:8,y:626,t:1527030981831};\\\", \\\"{x:23,y:615,t:1527030981849};\\\", \\\"{x:36,y:606,t:1527030981864};\\\", \\\"{x:50,y:596,t:1527030981882};\\\", \\\"{x:62,y:588,t:1527030981898};\\\", \\\"{x:74,y:580,t:1527030981915};\\\", \\\"{x:82,y:575,t:1527030981931};\\\", \\\"{x:92,y:570,t:1527030981947};\\\", \\\"{x:104,y:564,t:1527030981965};\\\", \\\"{x:118,y:559,t:1527030981981};\\\", \\\"{x:137,y:555,t:1527030981997};\\\", \\\"{x:163,y:551,t:1527030982015};\\\", \\\"{x:193,y:550,t:1527030982032};\\\", \\\"{x:223,y:550,t:1527030982049};\\\", \\\"{x:258,y:550,t:1527030982064};\\\", \\\"{x:300,y:550,t:1527030982082};\\\", \\\"{x:337,y:550,t:1527030982098};\\\", \\\"{x:376,y:550,t:1527030982115};\\\", \\\"{x:407,y:549,t:1527030982132};\\\", \\\"{x:448,y:538,t:1527030982149};\\\", \\\"{x:475,y:531,t:1527030982165};\\\", \\\"{x:484,y:526,t:1527030982181};\\\", \\\"{x:493,y:519,t:1527030982198};\\\", \\\"{x:497,y:517,t:1527030982214};\\\", \\\"{x:504,y:513,t:1527030982231};\\\", \\\"{x:511,y:510,t:1527030982248};\\\", \\\"{x:517,y:508,t:1527030982264};\\\", \\\"{x:521,y:506,t:1527030982281};\\\", \\\"{x:526,y:504,t:1527030982298};\\\", \\\"{x:528,y:502,t:1527030982314};\\\", \\\"{x:531,y:501,t:1527030982332};\\\", \\\"{x:533,y:499,t:1527030982349};\\\", \\\"{x:535,y:498,t:1527030982372};\\\", \\\"{x:536,y:498,t:1527030982469};\\\", \\\"{x:537,y:498,t:1527030982481};\\\", \\\"{x:540,y:499,t:1527030982498};\\\", \\\"{x:543,y:501,t:1527030982516};\\\", \\\"{x:546,y:503,t:1527030982532};\\\", \\\"{x:550,y:505,t:1527030982548};\\\", \\\"{x:551,y:507,t:1527030982565};\\\", \\\"{x:552,y:509,t:1527030982582};\\\", \\\"{x:553,y:510,t:1527030982598};\\\", \\\"{x:554,y:511,t:1527030982615};\\\", \\\"{x:554,y:512,t:1527030982636};\\\", \\\"{x:554,y:513,t:1527030982829};\\\", \\\"{x:552,y:515,t:1527030982844};\\\", \\\"{x:550,y:516,t:1527030982860};\\\", \\\"{x:549,y:516,t:1527030982868};\\\", \\\"{x:548,y:516,t:1527030982881};\\\", \\\"{x:546,y:518,t:1527030982898};\\\", \\\"{x:545,y:518,t:1527030982915};\\\", \\\"{x:544,y:519,t:1527030982930};\\\", \\\"{x:542,y:521,t:1527030982973};\\\", \\\"{x:541,y:522,t:1527030982981};\\\", \\\"{x:540,y:525,t:1527030982998};\\\", \\\"{x:539,y:528,t:1527030983015};\\\", \\\"{x:539,y:531,t:1527030983031};\\\", \\\"{x:539,y:534,t:1527030983049};\\\", \\\"{x:539,y:538,t:1527030983065};\\\", \\\"{x:540,y:543,t:1527030983082};\\\", \\\"{x:541,y:546,t:1527030983098};\\\", \\\"{x:545,y:552,t:1527030983116};\\\", \\\"{x:547,y:554,t:1527030983132};\\\", \\\"{x:551,y:554,t:1527030983150};\\\", \\\"{x:552,y:554,t:1527030983165};\\\", \\\"{x:555,y:555,t:1527030983183};\\\", \\\"{x:559,y:555,t:1527030983199};\\\", \\\"{x:565,y:555,t:1527030983216};\\\", \\\"{x:573,y:553,t:1527030983232};\\\", \\\"{x:587,y:548,t:1527030983249};\\\", \\\"{x:598,y:543,t:1527030983265};\\\", \\\"{x:612,y:538,t:1527030983283};\\\", \\\"{x:624,y:533,t:1527030983299};\\\", \\\"{x:631,y:530,t:1527030983316};\\\", \\\"{x:637,y:527,t:1527030983332};\\\", \\\"{x:642,y:526,t:1527030983350};\\\", \\\"{x:644,y:524,t:1527030983366};\\\", \\\"{x:645,y:524,t:1527030983383};\\\", \\\"{x:647,y:524,t:1527030983399};\\\", \\\"{x:652,y:523,t:1527030983416};\\\", \\\"{x:656,y:521,t:1527030983433};\\\", \\\"{x:658,y:521,t:1527030983449};\\\", \\\"{x:659,y:521,t:1527030983465};\\\", \\\"{x:664,y:521,t:1527030983483};\\\", \\\"{x:670,y:520,t:1527030983500};\\\", \\\"{x:672,y:520,t:1527030983516};\\\", \\\"{x:676,y:520,t:1527030983533};\\\", \\\"{x:677,y:520,t:1527030983581};\\\", \\\"{x:677,y:521,t:1527030983588};\\\", \\\"{x:677,y:524,t:1527030983605};\\\", \\\"{x:674,y:526,t:1527030983617};\\\", \\\"{x:667,y:530,t:1527030983633};\\\", \\\"{x:662,y:534,t:1527030983651};\\\", \\\"{x:653,y:539,t:1527030983669};\\\", \\\"{x:644,y:545,t:1527030983682};\\\", \\\"{x:638,y:549,t:1527030983699};\\\", \\\"{x:631,y:553,t:1527030983715};\\\", \\\"{x:614,y:559,t:1527030983732};\\\", \\\"{x:607,y:561,t:1527030983750};\\\", \\\"{x:599,y:564,t:1527030983766};\\\", \\\"{x:591,y:566,t:1527030983782};\\\", \\\"{x:587,y:568,t:1527030983800};\\\", \\\"{x:583,y:569,t:1527030983816};\\\", \\\"{x:577,y:571,t:1527030983833};\\\", \\\"{x:575,y:572,t:1527030983849};\\\", \\\"{x:573,y:573,t:1527030983867};\\\", \\\"{x:570,y:574,t:1527030983882};\\\", \\\"{x:569,y:575,t:1527030983924};\\\", \\\"{x:566,y:576,t:1527030983956};\\\", \\\"{x:564,y:577,t:1527030984006};\\\", \\\"{x:563,y:577,t:1527030984020};\\\", \\\"{x:563,y:578,t:1527030984032};\\\", \\\"{x:560,y:579,t:1527030984049};\\\", \\\"{x:557,y:579,t:1527030984066};\\\", \\\"{x:555,y:581,t:1527030984082};\\\", \\\"{x:549,y:583,t:1527030984099};\\\", \\\"{x:545,y:585,t:1527030984116};\\\", \\\"{x:541,y:587,t:1527030984132};\\\", \\\"{x:536,y:590,t:1527030984149};\\\", \\\"{x:533,y:591,t:1527030984166};\\\", \\\"{x:530,y:593,t:1527030984183};\\\", \\\"{x:526,y:594,t:1527030984199};\\\", \\\"{x:524,y:595,t:1527030984216};\\\", \\\"{x:523,y:596,t:1527030984232};\\\", \\\"{x:521,y:597,t:1527030984250};\\\", \\\"{x:518,y:597,t:1527030984267};\\\", \\\"{x:516,y:598,t:1527030984283};\\\", \\\"{x:514,y:599,t:1527030984299};\\\", \\\"{x:507,y:599,t:1527030984316};\\\", \\\"{x:503,y:600,t:1527030984333};\\\", \\\"{x:497,y:601,t:1527030984351};\\\", \\\"{x:492,y:601,t:1527030984366};\\\", \\\"{x:488,y:602,t:1527030984383};\\\", \\\"{x:484,y:602,t:1527030984400};\\\", \\\"{x:481,y:602,t:1527030984417};\\\", \\\"{x:476,y:602,t:1527030984433};\\\", \\\"{x:473,y:602,t:1527030984449};\\\", \\\"{x:469,y:603,t:1527030984466};\\\", \\\"{x:464,y:604,t:1527030984484};\\\", \\\"{x:460,y:605,t:1527030984499};\\\", \\\"{x:456,y:606,t:1527030984516};\\\", \\\"{x:454,y:607,t:1527030984534};\\\", \\\"{x:453,y:607,t:1527030984550};\\\", \\\"{x:449,y:608,t:1527030984568};\\\", \\\"{x:446,y:608,t:1527030984584};\\\", \\\"{x:442,y:608,t:1527030984599};\\\", \\\"{x:436,y:608,t:1527030984616};\\\", \\\"{x:432,y:608,t:1527030984634};\\\", \\\"{x:431,y:608,t:1527030984649};\\\", \\\"{x:429,y:608,t:1527030984667};\\\", \\\"{x:425,y:608,t:1527030984684};\\\", \\\"{x:422,y:608,t:1527030984700};\\\", \\\"{x:418,y:608,t:1527030984717};\\\", \\\"{x:414,y:608,t:1527030984733};\\\", \\\"{x:408,y:610,t:1527030984750};\\\", \\\"{x:403,y:611,t:1527030984766};\\\", \\\"{x:398,y:612,t:1527030984784};\\\", \\\"{x:387,y:612,t:1527030984801};\\\", \\\"{x:376,y:612,t:1527030984817};\\\", \\\"{x:366,y:612,t:1527030984834};\\\", \\\"{x:356,y:614,t:1527030984850};\\\", \\\"{x:350,y:615,t:1527030984868};\\\", \\\"{x:342,y:616,t:1527030984883};\\\", \\\"{x:335,y:617,t:1527030984901};\\\", \\\"{x:325,y:617,t:1527030984916};\\\", \\\"{x:315,y:617,t:1527030984934};\\\", \\\"{x:303,y:617,t:1527030984950};\\\", \\\"{x:292,y:617,t:1527030984966};\\\", \\\"{x:286,y:617,t:1527030984984};\\\", \\\"{x:285,y:616,t:1527030985036};\\\", \\\"{x:285,y:611,t:1527030985051};\\\", \\\"{x:292,y:603,t:1527030985069};\\\", \\\"{x:298,y:600,t:1527030985084};\\\", \\\"{x:301,y:598,t:1527030985100};\\\", \\\"{x:302,y:598,t:1527030985117};\\\", \\\"{x:303,y:597,t:1527030985133};\\\", \\\"{x:304,y:597,t:1527030985151};\\\", \\\"{x:306,y:596,t:1527030985168};\\\", \\\"{x:311,y:595,t:1527030985184};\\\", \\\"{x:316,y:594,t:1527030985201};\\\", \\\"{x:323,y:594,t:1527030985218};\\\", \\\"{x:327,y:594,t:1527030985234};\\\", \\\"{x:328,y:592,t:1527030985251};\\\", \\\"{x:331,y:592,t:1527030985268};\\\", \\\"{x:334,y:592,t:1527030985284};\\\", \\\"{x:338,y:592,t:1527030985300};\\\", \\\"{x:345,y:591,t:1527030985318};\\\", \\\"{x:350,y:590,t:1527030985334};\\\", \\\"{x:359,y:587,t:1527030985350};\\\", \\\"{x:369,y:584,t:1527030985368};\\\", \\\"{x:381,y:582,t:1527030985384};\\\", \\\"{x:395,y:580,t:1527030985401};\\\", \\\"{x:412,y:576,t:1527030985417};\\\", \\\"{x:434,y:573,t:1527030985434};\\\", \\\"{x:456,y:569,t:1527030985451};\\\", \\\"{x:489,y:565,t:1527030985467};\\\", \\\"{x:511,y:562,t:1527030985484};\\\", \\\"{x:532,y:561,t:1527030985500};\\\", \\\"{x:550,y:559,t:1527030985517};\\\", \\\"{x:563,y:556,t:1527030985533};\\\", \\\"{x:575,y:554,t:1527030985551};\\\", \\\"{x:591,y:554,t:1527030985567};\\\", \\\"{x:607,y:551,t:1527030985584};\\\", \\\"{x:619,y:550,t:1527030985600};\\\", \\\"{x:628,y:549,t:1527030985618};\\\", \\\"{x:631,y:549,t:1527030985634};\\\", \\\"{x:632,y:549,t:1527030985651};\\\", \\\"{x:632,y:550,t:1527030985741};\\\", \\\"{x:631,y:552,t:1527030985757};\\\", \\\"{x:631,y:553,t:1527030985768};\\\", \\\"{x:630,y:556,t:1527030985785};\\\", \\\"{x:628,y:558,t:1527030985802};\\\", \\\"{x:626,y:560,t:1527030985817};\\\", \\\"{x:625,y:560,t:1527030985835};\\\", \\\"{x:621,y:561,t:1527030985852};\\\", \\\"{x:620,y:563,t:1527030985868};\\\", \\\"{x:618,y:565,t:1527030985885};\\\", \\\"{x:616,y:568,t:1527030985902};\\\", \\\"{x:613,y:572,t:1527030985918};\\\", \\\"{x:611,y:575,t:1527030985935};\\\", \\\"{x:611,y:576,t:1527030985952};\\\", \\\"{x:609,y:578,t:1527030985968};\\\", \\\"{x:608,y:580,t:1527030985985};\\\", \\\"{x:608,y:583,t:1527030986001};\\\", \\\"{x:608,y:584,t:1527030986017};\\\", \\\"{x:609,y:588,t:1527030986034};\\\", \\\"{x:609,y:591,t:1527030986051};\\\", \\\"{x:609,y:595,t:1527030986068};\\\", \\\"{x:609,y:597,t:1527030986085};\\\", \\\"{x:611,y:599,t:1527030986101};\\\", \\\"{x:611,y:601,t:1527030986118};\\\", \\\"{x:611,y:600,t:1527030986300};\\\", \\\"{x:611,y:596,t:1527030986316};\\\", \\\"{x:611,y:595,t:1527030986334};\\\", \\\"{x:611,y:594,t:1527030986351};\\\", \\\"{x:618,y:594,t:1527030986948};\\\", \\\"{x:631,y:600,t:1527030986956};\\\", \\\"{x:642,y:606,t:1527030986969};\\\", \\\"{x:681,y:625,t:1527030986986};\\\", \\\"{x:745,y:653,t:1527030987002};\\\", \\\"{x:838,y:689,t:1527030987018};\\\", \\\"{x:970,y:736,t:1527030987035};\\\", \\\"{x:1061,y:757,t:1527030987052};\\\", \\\"{x:1121,y:772,t:1527030987069};\\\", \\\"{x:1193,y:781,t:1527030987086};\\\", \\\"{x:1230,y:781,t:1527030987102};\\\", \\\"{x:1253,y:779,t:1527030987118};\\\", \\\"{x:1268,y:771,t:1527030987136};\\\", \\\"{x:1275,y:765,t:1527030987151};\\\", \\\"{x:1283,y:757,t:1527030987169};\\\", \\\"{x:1291,y:749,t:1527030987186};\\\", \\\"{x:1302,y:739,t:1527030987202};\\\", \\\"{x:1308,y:729,t:1527030987219};\\\", \\\"{x:1319,y:713,t:1527030987236};\\\", \\\"{x:1329,y:703,t:1527030987251};\\\", \\\"{x:1340,y:698,t:1527030987269};\\\", \\\"{x:1349,y:694,t:1527030987286};\\\", \\\"{x:1359,y:694,t:1527030987304};\\\", \\\"{x:1373,y:694,t:1527030987319};\\\", \\\"{x:1391,y:696,t:1527030987336};\\\", \\\"{x:1427,y:709,t:1527030987353};\\\", \\\"{x:1464,y:725,t:1527030987369};\\\", \\\"{x:1491,y:741,t:1527030987386};\\\", \\\"{x:1515,y:755,t:1527030987403};\\\", \\\"{x:1533,y:768,t:1527030987419};\\\", \\\"{x:1553,y:781,t:1527030987436};\\\", \\\"{x:1556,y:783,t:1527030987452};\\\", \\\"{x:1557,y:784,t:1527030987533};\\\", \\\"{x:1558,y:784,t:1527030987541};\\\", \\\"{x:1560,y:784,t:1527030987557};\\\", \\\"{x:1561,y:784,t:1527030987573};\\\", \\\"{x:1562,y:784,t:1527030987661};\\\", \\\"{x:1564,y:784,t:1527030987670};\\\", \\\"{x:1565,y:784,t:1527030987693};\\\", \\\"{x:1565,y:782,t:1527030987997};\\\", \\\"{x:1562,y:777,t:1527030988004};\\\", \\\"{x:1551,y:771,t:1527030988021};\\\", \\\"{x:1546,y:767,t:1527030988037};\\\", \\\"{x:1545,y:766,t:1527030988053};\\\", \\\"{x:1543,y:764,t:1527030988071};\\\", \\\"{x:1540,y:763,t:1527030988087};\\\", \\\"{x:1535,y:760,t:1527030988103};\\\", \\\"{x:1532,y:758,t:1527030988120};\\\", \\\"{x:1530,y:757,t:1527030988137};\\\", \\\"{x:1529,y:757,t:1527030988153};\\\", \\\"{x:1524,y:756,t:1527030988170};\\\", \\\"{x:1518,y:756,t:1527030988187};\\\", \\\"{x:1509,y:753,t:1527030988203};\\\", \\\"{x:1499,y:749,t:1527030988219};\\\", \\\"{x:1491,y:745,t:1527030988237};\\\", \\\"{x:1487,y:742,t:1527030988253};\\\", \\\"{x:1486,y:741,t:1527030988270};\\\", \\\"{x:1484,y:740,t:1527030988287};\\\", \\\"{x:1476,y:736,t:1527030988303};\\\", \\\"{x:1466,y:730,t:1527030988320};\\\", \\\"{x:1463,y:727,t:1527030988336};\\\", \\\"{x:1462,y:727,t:1527030988725};\\\", \\\"{x:1460,y:727,t:1527030988737};\\\", \\\"{x:1459,y:727,t:1527030988755};\\\", \\\"{x:1458,y:727,t:1527030988769};\\\", \\\"{x:1457,y:727,t:1527030988787};\\\", \\\"{x:1455,y:727,t:1527030988811};\\\", \\\"{x:1454,y:728,t:1527030988820};\\\", \\\"{x:1453,y:728,t:1527030988837};\\\", \\\"{x:1451,y:729,t:1527030988854};\\\", \\\"{x:1449,y:730,t:1527030988870};\\\", \\\"{x:1443,y:731,t:1527030988887};\\\", \\\"{x:1437,y:732,t:1527030988904};\\\", \\\"{x:1431,y:734,t:1527030988920};\\\", \\\"{x:1428,y:734,t:1527030988937};\\\", \\\"{x:1424,y:734,t:1527030988954};\\\", \\\"{x:1421,y:734,t:1527030988970};\\\", \\\"{x:1417,y:734,t:1527030988987};\\\", \\\"{x:1414,y:734,t:1527030989004};\\\", \\\"{x:1413,y:734,t:1527030989020};\\\", \\\"{x:1411,y:734,t:1527030989213};\\\", \\\"{x:1410,y:734,t:1527030989221};\\\", \\\"{x:1409,y:734,t:1527030989238};\\\", \\\"{x:1409,y:735,t:1527030989445};\\\", \\\"{x:1407,y:740,t:1527030989455};\\\", \\\"{x:1407,y:744,t:1527030989472};\\\", \\\"{x:1407,y:749,t:1527030989487};\\\", \\\"{x:1407,y:752,t:1527030989505};\\\", \\\"{x:1407,y:755,t:1527030989521};\\\", \\\"{x:1409,y:756,t:1527030989537};\\\", \\\"{x:1409,y:757,t:1527030990813};\\\", \\\"{x:1415,y:762,t:1527030990822};\\\", \\\"{x:1438,y:771,t:1527030990838};\\\", \\\"{x:1454,y:784,t:1527030990855};\\\", \\\"{x:1465,y:791,t:1527030990873};\\\", \\\"{x:1467,y:792,t:1527030990889};\\\", \\\"{x:1468,y:792,t:1527030990905};\\\", \\\"{x:1468,y:793,t:1527030991021};\\\", \\\"{x:1469,y:793,t:1527030991027};\\\", \\\"{x:1471,y:794,t:1527030991039};\\\", \\\"{x:1473,y:795,t:1527030991067};\\\", \\\"{x:1474,y:796,t:1527030991076};\\\", \\\"{x:1475,y:797,t:1527030991089};\\\", \\\"{x:1481,y:802,t:1527030991104};\\\", \\\"{x:1490,y:811,t:1527030991121};\\\", \\\"{x:1499,y:821,t:1527030991139};\\\", \\\"{x:1506,y:826,t:1527030991155};\\\", \\\"{x:1518,y:833,t:1527030991172};\\\", \\\"{x:1521,y:836,t:1527030991189};\\\", \\\"{x:1523,y:837,t:1527030991205};\\\", \\\"{x:1524,y:837,t:1527030991222};\\\", \\\"{x:1525,y:838,t:1527030991239};\\\", \\\"{x:1527,y:840,t:1527030991255};\\\", \\\"{x:1529,y:842,t:1527030991272};\\\", \\\"{x:1534,y:849,t:1527030991288};\\\", \\\"{x:1538,y:857,t:1527030991305};\\\", \\\"{x:1548,y:875,t:1527030991322};\\\", \\\"{x:1558,y:891,t:1527030991339};\\\", \\\"{x:1564,y:907,t:1527030991355};\\\", \\\"{x:1568,y:924,t:1527030991372};\\\", \\\"{x:1568,y:933,t:1527030991389};\\\", \\\"{x:1568,y:940,t:1527030991405};\\\", \\\"{x:1568,y:947,t:1527030991422};\\\", \\\"{x:1568,y:952,t:1527030991439};\\\", \\\"{x:1568,y:956,t:1527030991455};\\\", \\\"{x:1568,y:958,t:1527030991472};\\\", \\\"{x:1567,y:959,t:1527030991489};\\\", \\\"{x:1566,y:961,t:1527030991506};\\\", \\\"{x:1565,y:961,t:1527030991532};\\\", \\\"{x:1564,y:961,t:1527030991540};\\\", \\\"{x:1559,y:963,t:1527030991555};\\\", \\\"{x:1556,y:966,t:1527030991571};\\\", \\\"{x:1554,y:968,t:1527030991589};\\\", \\\"{x:1551,y:971,t:1527030991606};\\\", \\\"{x:1549,y:973,t:1527030991622};\\\", \\\"{x:1548,y:974,t:1527030991639};\\\", \\\"{x:1546,y:975,t:1527030991656};\\\", \\\"{x:1545,y:975,t:1527030991672};\\\", \\\"{x:1542,y:976,t:1527030991690};\\\", \\\"{x:1537,y:978,t:1527030991706};\\\", \\\"{x:1534,y:978,t:1527030991722};\\\", \\\"{x:1532,y:980,t:1527030991739};\\\", \\\"{x:1524,y:980,t:1527030991756};\\\", \\\"{x:1513,y:980,t:1527030991772};\\\", \\\"{x:1495,y:979,t:1527030991788};\\\", \\\"{x:1479,y:974,t:1527030991806};\\\", \\\"{x:1467,y:971,t:1527030991822};\\\", \\\"{x:1460,y:969,t:1527030991839};\\\", \\\"{x:1454,y:967,t:1527030991856};\\\", \\\"{x:1450,y:965,t:1527030991872};\\\", \\\"{x:1452,y:965,t:1527030991990};\\\", \\\"{x:1458,y:963,t:1527030992007};\\\", \\\"{x:1463,y:963,t:1527030992024};\\\", \\\"{x:1466,y:962,t:1527030992039};\\\", \\\"{x:1470,y:960,t:1527030992056};\\\", \\\"{x:1471,y:960,t:1527030992073};\\\", \\\"{x:1473,y:959,t:1527030992089};\\\", \\\"{x:1474,y:958,t:1527030992106};\\\", \\\"{x:1475,y:957,t:1527030992123};\\\", \\\"{x:1476,y:956,t:1527030992140};\\\", \\\"{x:1476,y:955,t:1527030992156};\\\", \\\"{x:1477,y:954,t:1527030992173};\\\", \\\"{x:1478,y:951,t:1527030992189};\\\", \\\"{x:1479,y:949,t:1527030992207};\\\", \\\"{x:1479,y:946,t:1527030992223};\\\", \\\"{x:1479,y:945,t:1527030992239};\\\", \\\"{x:1479,y:943,t:1527030992256};\\\", \\\"{x:1480,y:940,t:1527030992273};\\\", \\\"{x:1480,y:935,t:1527030992289};\\\", \\\"{x:1480,y:928,t:1527030992306};\\\", \\\"{x:1480,y:918,t:1527030992323};\\\", \\\"{x:1480,y:907,t:1527030992339};\\\", \\\"{x:1480,y:885,t:1527030992356};\\\", \\\"{x:1480,y:870,t:1527030992373};\\\", \\\"{x:1480,y:859,t:1527030992389};\\\", \\\"{x:1480,y:850,t:1527030992407};\\\", \\\"{x:1479,y:844,t:1527030992424};\\\", \\\"{x:1479,y:839,t:1527030992440};\\\", \\\"{x:1479,y:836,t:1527030992457};\\\", \\\"{x:1479,y:833,t:1527030992474};\\\", \\\"{x:1480,y:831,t:1527030992506};\\\", \\\"{x:1480,y:829,t:1527030992523};\\\", \\\"{x:1480,y:826,t:1527030992540};\\\", \\\"{x:1480,y:824,t:1527030992557};\\\", \\\"{x:1480,y:822,t:1527030992573};\\\", \\\"{x:1480,y:820,t:1527030992590};\\\", \\\"{x:1480,y:817,t:1527030992606};\\\", \\\"{x:1480,y:816,t:1527030992623};\\\", \\\"{x:1480,y:812,t:1527030992640};\\\", \\\"{x:1479,y:808,t:1527030992657};\\\", \\\"{x:1479,y:805,t:1527030992673};\\\", \\\"{x:1478,y:801,t:1527030992690};\\\", \\\"{x:1478,y:800,t:1527030992707};\\\", \\\"{x:1478,y:798,t:1527030992723};\\\", \\\"{x:1478,y:795,t:1527030992740};\\\", \\\"{x:1478,y:794,t:1527030992756};\\\", \\\"{x:1478,y:793,t:1527030992774};\\\", \\\"{x:1478,y:791,t:1527030992790};\\\", \\\"{x:1479,y:790,t:1527030992807};\\\", \\\"{x:1479,y:787,t:1527030992824};\\\", \\\"{x:1482,y:782,t:1527030992840};\\\", \\\"{x:1482,y:780,t:1527030992868};\\\", \\\"{x:1482,y:779,t:1527030992877};\\\", \\\"{x:1482,y:777,t:1527030992892};\\\", \\\"{x:1482,y:775,t:1527030992908};\\\", \\\"{x:1482,y:774,t:1527030992923};\\\", \\\"{x:1482,y:773,t:1527030992941};\\\", \\\"{x:1482,y:771,t:1527030992957};\\\", \\\"{x:1482,y:770,t:1527030992980};\\\", \\\"{x:1482,y:768,t:1527030993012};\\\", \\\"{x:1482,y:767,t:1527030993035};\\\", \\\"{x:1482,y:765,t:1527030993076};\\\", \\\"{x:1482,y:764,t:1527030993107};\\\", \\\"{x:1482,y:762,t:1527030993148};\\\", \\\"{x:1482,y:761,t:1527030993164};\\\", \\\"{x:1482,y:759,t:1527030993195};\\\", \\\"{x:1482,y:758,t:1527030993220};\\\", \\\"{x:1482,y:756,t:1527030993236};\\\", \\\"{x:1483,y:754,t:1527030993252};\\\", \\\"{x:1481,y:756,t:1527030996956};\\\", \\\"{x:1471,y:760,t:1527030996964};\\\", \\\"{x:1461,y:762,t:1527030996977};\\\", \\\"{x:1442,y:768,t:1527030996993};\\\", \\\"{x:1428,y:772,t:1527030997010};\\\", \\\"{x:1416,y:776,t:1527030997026};\\\", \\\"{x:1402,y:782,t:1527030997043};\\\", \\\"{x:1382,y:788,t:1527030997060};\\\", \\\"{x:1356,y:795,t:1527030997076};\\\", \\\"{x:1347,y:800,t:1527030997094};\\\", \\\"{x:1340,y:803,t:1527030997110};\\\", \\\"{x:1340,y:805,t:1527030997127};\\\", \\\"{x:1340,y:806,t:1527030997144};\\\", \\\"{x:1340,y:812,t:1527030997160};\\\", \\\"{x:1340,y:816,t:1527030997177};\\\", \\\"{x:1340,y:820,t:1527030997194};\\\", \\\"{x:1340,y:823,t:1527030997211};\\\", \\\"{x:1341,y:825,t:1527030997227};\\\", \\\"{x:1342,y:827,t:1527030997244};\\\", \\\"{x:1342,y:829,t:1527030997260};\\\", \\\"{x:1343,y:829,t:1527030997357};\\\", \\\"{x:1344,y:829,t:1527030997365};\\\", \\\"{x:1345,y:829,t:1527030997377};\\\", \\\"{x:1348,y:829,t:1527030997394};\\\", \\\"{x:1351,y:828,t:1527030997411};\\\", \\\"{x:1356,y:823,t:1527030997427};\\\", \\\"{x:1359,y:819,t:1527030997444};\\\", \\\"{x:1361,y:814,t:1527030997460};\\\", \\\"{x:1364,y:810,t:1527030997476};\\\", \\\"{x:1365,y:807,t:1527030997494};\\\", \\\"{x:1366,y:804,t:1527030997510};\\\", \\\"{x:1366,y:801,t:1527030997526};\\\", \\\"{x:1367,y:799,t:1527030997544};\\\", \\\"{x:1367,y:797,t:1527030997560};\\\", \\\"{x:1369,y:793,t:1527030997576};\\\", \\\"{x:1369,y:792,t:1527030997593};\\\", \\\"{x:1369,y:791,t:1527030997610};\\\", \\\"{x:1369,y:788,t:1527030997626};\\\", \\\"{x:1369,y:786,t:1527030997643};\\\", \\\"{x:1369,y:785,t:1527030997675};\\\", \\\"{x:1367,y:785,t:1527030997724};\\\", \\\"{x:1366,y:785,t:1527030997732};\\\", \\\"{x:1364,y:789,t:1527030997744};\\\", \\\"{x:1361,y:798,t:1527030997761};\\\", \\\"{x:1360,y:808,t:1527030997777};\\\", \\\"{x:1360,y:818,t:1527030997793};\\\", \\\"{x:1360,y:832,t:1527030997811};\\\", \\\"{x:1360,y:844,t:1527030997827};\\\", \\\"{x:1363,y:861,t:1527030997843};\\\", \\\"{x:1372,y:888,t:1527030997860};\\\", \\\"{x:1374,y:899,t:1527030997878};\\\", \\\"{x:1377,y:905,t:1527030997894};\\\", \\\"{x:1378,y:907,t:1527030997911};\\\", \\\"{x:1380,y:904,t:1527030997996};\\\", \\\"{x:1381,y:897,t:1527030998010};\\\", \\\"{x:1382,y:886,t:1527030998027};\\\", \\\"{x:1385,y:870,t:1527030998043};\\\", \\\"{x:1390,y:845,t:1527030998060};\\\", \\\"{x:1391,y:830,t:1527030998077};\\\", \\\"{x:1391,y:816,t:1527030998093};\\\", \\\"{x:1391,y:803,t:1527030998110};\\\", \\\"{x:1391,y:791,t:1527030998127};\\\", \\\"{x:1390,y:782,t:1527030998144};\\\", \\\"{x:1389,y:777,t:1527030998160};\\\", \\\"{x:1387,y:773,t:1527030998177};\\\", \\\"{x:1387,y:772,t:1527030998194};\\\", \\\"{x:1387,y:771,t:1527030998210};\\\", \\\"{x:1387,y:770,t:1527030998228};\\\", \\\"{x:1387,y:769,t:1527030998276};\\\", \\\"{x:1386,y:768,t:1527030998301};\\\", \\\"{x:1386,y:767,t:1527030998310};\\\", \\\"{x:1386,y:766,t:1527030998328};\\\", \\\"{x:1386,y:763,t:1527030998345};\\\", \\\"{x:1386,y:760,t:1527030998361};\\\", \\\"{x:1386,y:757,t:1527030998378};\\\", \\\"{x:1386,y:753,t:1527030998395};\\\", \\\"{x:1386,y:752,t:1527030998411};\\\", \\\"{x:1386,y:750,t:1527030998453};\\\", \\\"{x:1385,y:750,t:1527030998564};\\\", \\\"{x:1384,y:750,t:1527030998578};\\\", \\\"{x:1381,y:750,t:1527030998595};\\\", \\\"{x:1378,y:753,t:1527030998611};\\\", \\\"{x:1377,y:753,t:1527030998627};\\\", \\\"{x:1375,y:754,t:1527030998644};\\\", \\\"{x:1375,y:755,t:1527030998661};\\\", \\\"{x:1375,y:756,t:1527030998678};\\\", \\\"{x:1375,y:757,t:1527030998695};\\\", \\\"{x:1375,y:759,t:1527030998712};\\\", \\\"{x:1375,y:761,t:1527030998728};\\\", \\\"{x:1375,y:762,t:1527030998745};\\\", \\\"{x:1375,y:763,t:1527030998762};\\\", \\\"{x:1375,y:764,t:1527030998781};\\\", \\\"{x:1375,y:765,t:1527030998853};\\\", \\\"{x:1376,y:765,t:1527030998862};\\\", \\\"{x:1377,y:764,t:1527030998878};\\\", \\\"{x:1380,y:764,t:1527030998895};\\\", \\\"{x:1382,y:763,t:1527030998912};\\\", \\\"{x:1383,y:762,t:1527030998928};\\\", \\\"{x:1384,y:761,t:1527030998948};\\\", \\\"{x:1384,y:760,t:1527030998981};\\\", \\\"{x:1383,y:760,t:1527030999301};\\\", \\\"{x:1382,y:760,t:1527030999477};\\\", \\\"{x:1382,y:762,t:1527030999493};\\\", \\\"{x:1381,y:763,t:1527030999509};\\\", \\\"{x:1381,y:764,t:1527030999524};\\\", \\\"{x:1380,y:765,t:1527030999533};\\\", \\\"{x:1380,y:766,t:1527030999580};\\\", \\\"{x:1379,y:766,t:1527030999637};\\\", \\\"{x:1379,y:765,t:1527031000125};\\\", \\\"{x:1379,y:764,t:1527031001180};\\\", \\\"{x:1379,y:754,t:1527031001196};\\\", \\\"{x:1381,y:742,t:1527031001212};\\\", \\\"{x:1382,y:731,t:1527031001229};\\\", \\\"{x:1385,y:716,t:1527031001246};\\\", \\\"{x:1385,y:706,t:1527031001263};\\\", \\\"{x:1387,y:701,t:1527031001279};\\\", \\\"{x:1388,y:698,t:1527031001296};\\\", \\\"{x:1389,y:696,t:1527031001312};\\\", \\\"{x:1389,y:695,t:1527031001329};\\\", \\\"{x:1390,y:695,t:1527031001347};\\\", \\\"{x:1390,y:694,t:1527031001362};\\\", \\\"{x:1390,y:693,t:1527031004292};\\\", \\\"{x:1391,y:692,t:1527031004308};\\\", \\\"{x:1392,y:692,t:1527031004316};\\\", \\\"{x:1394,y:692,t:1527031004332};\\\", \\\"{x:1395,y:691,t:1527031004349};\\\", \\\"{x:1396,y:690,t:1527031004366};\\\", \\\"{x:1397,y:690,t:1527031004972};\\\", \\\"{x:1398,y:689,t:1527031004983};\\\", \\\"{x:1402,y:688,t:1527031004999};\\\", \\\"{x:1405,y:688,t:1527031005016};\\\", \\\"{x:1412,y:687,t:1527031005033};\\\", \\\"{x:1421,y:686,t:1527031005049};\\\", \\\"{x:1424,y:685,t:1527031005066};\\\", \\\"{x:1425,y:684,t:1527031005085};\\\", \\\"{x:1428,y:684,t:1527031005100};\\\", \\\"{x:1429,y:684,t:1527031005141};\\\", \\\"{x:1430,y:684,t:1527031005149};\\\", \\\"{x:1431,y:683,t:1527031005166};\\\", \\\"{x:1433,y:683,t:1527031005187};\\\", \\\"{x:1433,y:682,t:1527031005211};\\\", \\\"{x:1434,y:682,t:1527031005219};\\\", \\\"{x:1434,y:681,t:1527031005235};\\\", \\\"{x:1435,y:681,t:1527031005251};\\\", \\\"{x:1436,y:681,t:1527031005275};\\\", \\\"{x:1437,y:681,t:1527031005299};\\\", \\\"{x:1439,y:681,t:1527031005323};\\\", \\\"{x:1440,y:681,t:1527031005347};\\\", \\\"{x:1441,y:681,t:1527031005397};\\\", \\\"{x:1442,y:681,t:1527031005404};\\\", \\\"{x:1443,y:681,t:1527031005416};\\\", \\\"{x:1444,y:681,t:1527031005433};\\\", \\\"{x:1446,y:681,t:1527031005450};\\\", \\\"{x:1447,y:681,t:1527031005468};\\\", \\\"{x:1448,y:681,t:1527031005483};\\\", \\\"{x:1449,y:681,t:1527031005501};\\\", \\\"{x:1450,y:681,t:1527031005573};\\\", \\\"{x:1451,y:681,t:1527031005597};\\\", \\\"{x:1452,y:681,t:1527031005612};\\\", \\\"{x:1453,y:681,t:1527031005628};\\\", \\\"{x:1454,y:682,t:1527031005652};\\\", \\\"{x:1455,y:682,t:1527031005668};\\\", \\\"{x:1455,y:683,t:1527031005683};\\\", \\\"{x:1457,y:683,t:1527031005700};\\\", \\\"{x:1457,y:685,t:1527031005716};\\\", \\\"{x:1459,y:685,t:1527031005733};\\\", \\\"{x:1459,y:686,t:1527031005750};\\\", \\\"{x:1461,y:687,t:1527031005805};\\\", \\\"{x:1461,y:688,t:1527031005821};\\\", \\\"{x:1462,y:688,t:1527031005833};\\\", \\\"{x:1464,y:688,t:1527031005852};\\\", \\\"{x:1465,y:689,t:1527031005867};\\\", \\\"{x:1466,y:690,t:1527031005883};\\\", \\\"{x:1469,y:692,t:1527031005900};\\\", \\\"{x:1472,y:692,t:1527031005916};\\\", \\\"{x:1474,y:694,t:1527031005933};\\\", \\\"{x:1475,y:694,t:1527031005950};\\\", \\\"{x:1476,y:694,t:1527031005967};\\\", \\\"{x:1478,y:694,t:1527031005983};\\\", \\\"{x:1479,y:694,t:1527031006000};\\\", \\\"{x:1481,y:694,t:1527031006017};\\\", \\\"{x:1482,y:694,t:1527031006052};\\\", \\\"{x:1483,y:694,t:1527031006076};\\\", \\\"{x:1484,y:694,t:1527031006117};\\\", \\\"{x:1485,y:694,t:1527031006461};\\\", \\\"{x:1485,y:696,t:1527031006501};\\\", \\\"{x:1484,y:696,t:1527031006516};\\\", \\\"{x:1484,y:697,t:1527031006535};\\\", \\\"{x:1483,y:698,t:1527031006629};\\\", \\\"{x:1483,y:699,t:1527031006725};\\\", \\\"{x:1482,y:699,t:1527031006756};\\\", \\\"{x:1481,y:699,t:1527031007013};\\\", \\\"{x:1480,y:699,t:1527031007052};\\\", \\\"{x:1479,y:699,t:1527031007101};\\\", \\\"{x:1478,y:699,t:1527031007140};\\\", \\\"{x:1478,y:698,t:1527031007396};\\\", \\\"{x:1478,y:697,t:1527031007437};\\\", \\\"{x:1478,y:696,t:1527031007469};\\\", \\\"{x:1478,y:695,t:1527031008381};\\\", \\\"{x:1480,y:693,t:1527031010837};\\\", \\\"{x:1484,y:688,t:1527031010853};\\\", \\\"{x:1486,y:681,t:1527031010870};\\\", \\\"{x:1488,y:676,t:1527031010888};\\\", \\\"{x:1489,y:673,t:1527031010904};\\\", \\\"{x:1490,y:671,t:1527031010920};\\\", \\\"{x:1490,y:669,t:1527031010937};\\\", \\\"{x:1491,y:667,t:1527031010953};\\\", \\\"{x:1491,y:666,t:1527031010972};\\\", \\\"{x:1491,y:665,t:1527031011013};\\\", \\\"{x:1491,y:664,t:1527031011020};\\\", \\\"{x:1491,y:662,t:1527031011037};\\\", \\\"{x:1491,y:657,t:1527031011055};\\\", \\\"{x:1491,y:651,t:1527031011070};\\\", \\\"{x:1492,y:647,t:1527031011087};\\\", \\\"{x:1492,y:642,t:1527031011105};\\\", \\\"{x:1492,y:639,t:1527031011120};\\\", \\\"{x:1492,y:634,t:1527031011137};\\\", \\\"{x:1492,y:629,t:1527031011155};\\\", \\\"{x:1492,y:626,t:1527031011170};\\\", \\\"{x:1492,y:623,t:1527031011188};\\\", \\\"{x:1492,y:622,t:1527031011204};\\\", \\\"{x:1492,y:621,t:1527031011557};\\\", \\\"{x:1491,y:622,t:1527031011716};\\\", \\\"{x:1490,y:623,t:1527031011739};\\\", \\\"{x:1490,y:624,t:1527031011753};\\\", \\\"{x:1489,y:626,t:1527031011771};\\\", \\\"{x:1488,y:628,t:1527031011787};\\\", \\\"{x:1487,y:629,t:1527031011804};\\\", \\\"{x:1487,y:631,t:1527031011821};\\\", \\\"{x:1486,y:632,t:1527031011837};\\\", \\\"{x:1484,y:633,t:1527031014605};\\\", \\\"{x:1481,y:633,t:1527031014612};\\\", \\\"{x:1479,y:633,t:1527031014624};\\\", \\\"{x:1476,y:633,t:1527031014639};\\\", \\\"{x:1472,y:633,t:1527031014656};\\\", \\\"{x:1469,y:633,t:1527031014674};\\\", \\\"{x:1466,y:633,t:1527031014690};\\\", \\\"{x:1465,y:632,t:1527031014706};\\\", \\\"{x:1464,y:632,t:1527031014723};\\\", \\\"{x:1460,y:632,t:1527031014739};\\\", \\\"{x:1449,y:632,t:1527031014756};\\\", \\\"{x:1438,y:632,t:1527031014774};\\\", \\\"{x:1425,y:632,t:1527031014789};\\\", \\\"{x:1419,y:632,t:1527031014806};\\\", \\\"{x:1414,y:632,t:1527031014823};\\\", \\\"{x:1409,y:632,t:1527031014841};\\\", \\\"{x:1407,y:632,t:1527031014856};\\\", \\\"{x:1405,y:632,t:1527031014873};\\\", \\\"{x:1403,y:632,t:1527031014891};\\\", \\\"{x:1402,y:632,t:1527031014906};\\\", \\\"{x:1401,y:632,t:1527031014924};\\\", \\\"{x:1400,y:632,t:1527031014940};\\\", \\\"{x:1399,y:632,t:1527031015140};\\\", \\\"{x:1395,y:632,t:1527031015156};\\\", \\\"{x:1389,y:632,t:1527031015173};\\\", \\\"{x:1386,y:632,t:1527031015190};\\\", \\\"{x:1383,y:632,t:1527031015207};\\\", \\\"{x:1381,y:632,t:1527031015223};\\\", \\\"{x:1380,y:632,t:1527031015240};\\\", \\\"{x:1379,y:632,t:1527031015256};\\\", \\\"{x:1378,y:631,t:1527031015274};\\\", \\\"{x:1377,y:631,t:1527031015290};\\\", \\\"{x:1375,y:631,t:1527031015307};\\\", \\\"{x:1373,y:631,t:1527031015323};\\\", \\\"{x:1371,y:631,t:1527031015340};\\\", \\\"{x:1369,y:631,t:1527031015358};\\\", \\\"{x:1367,y:631,t:1527031015373};\\\", \\\"{x:1365,y:631,t:1527031015390};\\\", \\\"{x:1364,y:631,t:1527031015407};\\\", \\\"{x:1363,y:631,t:1527031015423};\\\", \\\"{x:1360,y:631,t:1527031015441};\\\", \\\"{x:1358,y:631,t:1527031015468};\\\", \\\"{x:1357,y:631,t:1527031016549};\\\", \\\"{x:1355,y:631,t:1527031016557};\\\", \\\"{x:1349,y:630,t:1527031016575};\\\", \\\"{x:1343,y:630,t:1527031016591};\\\", \\\"{x:1334,y:627,t:1527031016608};\\\", \\\"{x:1325,y:627,t:1527031016624};\\\", \\\"{x:1316,y:626,t:1527031016641};\\\", \\\"{x:1310,y:624,t:1527031016658};\\\", \\\"{x:1307,y:624,t:1527031016674};\\\", \\\"{x:1304,y:623,t:1527031016691};\\\", \\\"{x:1302,y:623,t:1527031016708};\\\", \\\"{x:1301,y:623,t:1527031016724};\\\", \\\"{x:1299,y:623,t:1527031016741};\\\", \\\"{x:1296,y:623,t:1527031016758};\\\", \\\"{x:1295,y:623,t:1527031016774};\\\", \\\"{x:1291,y:622,t:1527031016792};\\\", \\\"{x:1289,y:622,t:1527031016808};\\\", \\\"{x:1288,y:621,t:1527031016824};\\\", \\\"{x:1288,y:620,t:1527031017844};\\\", \\\"{x:1289,y:620,t:1527031017893};\\\", \\\"{x:1291,y:620,t:1527031017916};\\\", \\\"{x:1293,y:620,t:1527031017940};\\\", \\\"{x:1294,y:620,t:1527031017948};\\\", \\\"{x:1295,y:620,t:1527031017979};\\\", \\\"{x:1296,y:620,t:1527031017992};\\\", \\\"{x:1297,y:620,t:1527031018027};\\\", \\\"{x:1298,y:620,t:1527031018051};\\\", \\\"{x:1299,y:620,t:1527031018059};\\\", \\\"{x:1300,y:620,t:1527031018083};\\\", \\\"{x:1301,y:620,t:1527031018140};\\\", \\\"{x:1303,y:620,t:1527031018171};\\\", \\\"{x:1304,y:620,t:1527031018220};\\\", \\\"{x:1305,y:620,t:1527031018228};\\\", \\\"{x:1305,y:621,t:1527031018243};\\\", \\\"{x:1306,y:621,t:1527031018260};\\\", \\\"{x:1307,y:621,t:1527031018284};\\\", \\\"{x:1308,y:622,t:1527031018300};\\\", \\\"{x:1309,y:622,t:1527031018310};\\\", \\\"{x:1310,y:622,t:1527031018325};\\\", \\\"{x:1311,y:623,t:1527031018343};\\\", \\\"{x:1312,y:623,t:1527031018364};\\\", \\\"{x:1313,y:623,t:1527031018404};\\\", \\\"{x:1314,y:623,t:1527031018700};\\\", \\\"{x:1314,y:621,t:1527031018757};\\\", \\\"{x:1314,y:618,t:1527031019973};\\\", \\\"{x:1317,y:613,t:1527031019980};\\\", \\\"{x:1318,y:611,t:1527031019993};\\\", \\\"{x:1320,y:606,t:1527031020011};\\\", \\\"{x:1322,y:602,t:1527031020026};\\\", \\\"{x:1325,y:599,t:1527031020044};\\\", \\\"{x:1325,y:598,t:1527031020084};\\\", \\\"{x:1327,y:597,t:1527031020094};\\\", \\\"{x:1327,y:596,t:1527031020110};\\\", \\\"{x:1327,y:593,t:1527031020127};\\\", \\\"{x:1328,y:591,t:1527031020143};\\\", \\\"{x:1328,y:589,t:1527031020160};\\\", \\\"{x:1328,y:588,t:1527031020177};\\\", \\\"{x:1328,y:585,t:1527031020193};\\\", \\\"{x:1328,y:581,t:1527031020210};\\\", \\\"{x:1331,y:573,t:1527031020227};\\\", \\\"{x:1338,y:564,t:1527031020243};\\\", \\\"{x:1349,y:557,t:1527031020261};\\\", \\\"{x:1355,y:553,t:1527031020278};\\\", \\\"{x:1358,y:550,t:1527031020293};\\\", \\\"{x:1359,y:547,t:1527031020310};\\\", \\\"{x:1361,y:543,t:1527031020327};\\\", \\\"{x:1362,y:542,t:1527031020344};\\\", \\\"{x:1362,y:541,t:1527031020360};\\\", \\\"{x:1361,y:541,t:1527031020780};\\\", \\\"{x:1360,y:541,t:1527031020795};\\\", \\\"{x:1359,y:541,t:1527031020836};\\\", \\\"{x:1359,y:542,t:1527031020853};\\\", \\\"{x:1358,y:542,t:1527031020868};\\\", \\\"{x:1357,y:542,t:1527031020878};\\\", \\\"{x:1355,y:544,t:1527031020895};\\\", \\\"{x:1353,y:546,t:1527031020911};\\\", \\\"{x:1352,y:547,t:1527031020928};\\\", \\\"{x:1351,y:547,t:1527031020945};\\\", \\\"{x:1351,y:548,t:1527031020960};\\\", \\\"{x:1351,y:549,t:1527031021028};\\\", \\\"{x:1350,y:550,t:1527031021045};\\\", \\\"{x:1350,y:551,t:1527031021062};\\\", \\\"{x:1349,y:551,t:1527031021084};\\\", \\\"{x:1347,y:551,t:1527031021331};\\\", \\\"{x:1346,y:551,t:1527031021420};\\\", \\\"{x:1345,y:553,t:1527031021468};\\\", \\\"{x:1344,y:553,t:1527031021516};\\\", \\\"{x:1343,y:553,t:1527031021556};\\\", \\\"{x:1342,y:554,t:1527031022221};\\\", \\\"{x:1341,y:555,t:1527031022228};\\\", \\\"{x:1340,y:555,t:1527031022246};\\\", \\\"{x:1338,y:555,t:1527031022262};\\\", \\\"{x:1337,y:555,t:1527031022278};\\\", \\\"{x:1336,y:555,t:1527031022296};\\\", \\\"{x:1335,y:555,t:1527031022332};\\\", \\\"{x:1334,y:555,t:1527031022396};\\\", \\\"{x:1332,y:555,t:1527031022412};\\\", \\\"{x:1328,y:555,t:1527031022429};\\\", \\\"{x:1323,y:555,t:1527031022445};\\\", \\\"{x:1317,y:555,t:1527031022462};\\\", \\\"{x:1311,y:555,t:1527031022479};\\\", \\\"{x:1304,y:555,t:1527031022496};\\\", \\\"{x:1298,y:555,t:1527031022512};\\\", \\\"{x:1293,y:555,t:1527031022528};\\\", \\\"{x:1288,y:555,t:1527031022547};\\\", \\\"{x:1282,y:555,t:1527031022562};\\\", \\\"{x:1279,y:555,t:1527031022579};\\\", \\\"{x:1276,y:555,t:1527031022596};\\\", \\\"{x:1275,y:555,t:1527031022685};\\\", \\\"{x:1274,y:555,t:1527031022708};\\\", \\\"{x:1273,y:555,t:1527031022716};\\\", \\\"{x:1272,y:555,t:1527031022728};\\\", \\\"{x:1271,y:555,t:1527031022747};\\\", \\\"{x:1270,y:555,t:1527031022764};\\\", \\\"{x:1269,y:555,t:1527031022779};\\\", \\\"{x:1268,y:555,t:1527031023372};\\\", \\\"{x:1268,y:556,t:1527031023380};\\\", \\\"{x:1268,y:557,t:1527031023412};\\\", \\\"{x:1267,y:558,t:1527031023429};\\\", \\\"{x:1267,y:559,t:1527031023492};\\\", \\\"{x:1266,y:560,t:1527031023516};\\\", \\\"{x:1266,y:561,t:1527031023564};\\\", \\\"{x:1268,y:561,t:1527031024888};\\\", \\\"{x:1270,y:561,t:1527031024901};\\\", \\\"{x:1274,y:558,t:1527031024917};\\\", \\\"{x:1276,y:557,t:1527031024935};\\\", \\\"{x:1270,y:557,t:1527031026561};\\\", \\\"{x:1263,y:557,t:1527031026569};\\\", \\\"{x:1242,y:557,t:1527031026585};\\\", \\\"{x:1197,y:562,t:1527031026603};\\\", \\\"{x:1127,y:571,t:1527031026619};\\\", \\\"{x:1061,y:580,t:1527031026635};\\\", \\\"{x:1005,y:588,t:1527031026653};\\\", \\\"{x:932,y:596,t:1527031026669};\\\", \\\"{x:846,y:611,t:1527031026685};\\\", \\\"{x:723,y:647,t:1527031026718};\\\", \\\"{x:690,y:667,t:1527031026733};\\\", \\\"{x:665,y:689,t:1527031026750};\\\", \\\"{x:657,y:700,t:1527031026768};\\\", \\\"{x:650,y:708,t:1527031026783};\\\", \\\"{x:645,y:714,t:1527031026801};\\\", \\\"{x:639,y:720,t:1527031026818};\\\", \\\"{x:634,y:725,t:1527031026833};\\\", \\\"{x:626,y:736,t:1527031026851};\\\", \\\"{x:616,y:747,t:1527031026868};\\\", \\\"{x:610,y:757,t:1527031026883};\\\", \\\"{x:606,y:761,t:1527031026901};\\\", \\\"{x:602,y:764,t:1527031026918};\\\", \\\"{x:596,y:768,t:1527031026934};\\\", \\\"{x:593,y:768,t:1527031026951};\\\", \\\"{x:590,y:768,t:1527031026968};\\\", \\\"{x:584,y:768,t:1527031026984};\\\", \\\"{x:574,y:768,t:1527031027000};\\\", \\\"{x:559,y:768,t:1527031027018};\\\", \\\"{x:544,y:766,t:1527031027034};\\\", \\\"{x:528,y:761,t:1527031027051};\\\", \\\"{x:514,y:754,t:1527031027072};\\\", \\\"{x:510,y:751,t:1527031027087};\\\", \\\"{x:509,y:750,t:1527031027105};\\\", \\\"{x:508,y:749,t:1527031027127};\\\", \\\"{x:507,y:749,t:1527031028415};\\\", \\\"{x:506,y:749,t:1527031028431};\\\", \\\"{x:505,y:749,t:1527031028454};\\\", \\\"{x:504,y:749,t:1527031028462};\\\" ] }, { \\\"rt\\\": 43479, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 20, \\\"time_elapsed\\\": 828566, \\\"internal_node_id\\\": \\\"0.0-7.0-0.0\\\", \\\"subject\\\": \\\"E5L6P\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\", \\\"q\\\": 16, \\\"answer\\\": \\\"look at the x-axis for 12pm, and view all the dots that align linearly\\\", \\\"block\\\": \\\"triangular_testing\\\" }, { \\\"rt\\\": 7007, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"19\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"India\\\\\\\"}\\\", \\\"block\\\": \\\"demo-1\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 21, \\\"time_elapsed\\\": 836581, \\\"internal_node_id\\\": \\\"0.0-8.0\\\", \\\"subject\\\": \\\"E5L6P\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 16745, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"Other\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"Second\\\\\\\",\\\\\\\"Q2\\\\\\\":\\\\\\\"Biomedical & Health Sciences\\\\\\\",\\\\\\\"Q3\\\\\\\":\\\\\\\"Female\\\\\\\"}\\\", \\\"block\\\": \\\"demo-2\\\", \\\"trial_type\\\": \\\"survey-multi-choice\\\", \\\"trial_index\\\": 22, \\\"time_elapsed\\\": 854346, \\\"internal_node_id\\\": \\\"0.0-9.0\\\", \\\"subject\\\": \\\"E5L6P\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 3163, \\\"url\\\": \\\"../views/src/external/debrief.html\\\", \\\"block\\\": \\\"debrief\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 23, \\\"time_elapsed\\\": 858840, \\\"internal_node_id\\\": \\\"0.0-10.0\\\", \\\"subject\\\": \\\"E5L6P\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\" } ]\",\"parentNode\":{\"id\":2765}}],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"META\",\"attributes\":{\"charset\":\"utf-8\"}},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":8,\"id\":59},{\"nodeType\":3,\"id\":60,\"textContent\":\" \"},{\"nodeType\":1,\"id\":61,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":62,\"textContent\":\" \"},{\"nodeType\":1,\"id\":63,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":64,\"textContent\":\" \"},{\"nodeType\":1,\"id\":65,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":66,\"textContent\":\" \"},{\"nodeType\":1,\"id\":67,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":68,\"textContent\":\" \"},{\"nodeType\":1,\"id\":69,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":70,\"textContent\":\" \"},{\"nodeType\":1,\"id\":71,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":72,\"textContent\":\" \"},{\"nodeType\":1,\"id\":73,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"stimulus\"},\"childNodes\":[{\"nodeType\":3,\"id\":74,\"textContent\":\" \"},{\"nodeType\":1,\"id\":75,\"tagName\":\"P\",\"attributes\":{\"class\":\"userid\",\"id\":\"userid\"},\"childNodes\":[{\"nodeType\":3,\"id\":76,\"textContent\":\"E5L6P\"}]},{\"nodeType\":3,\"id\":77,\"textContent\":\" \"},{\"nodeType\":1,\"id\":78,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"userinput\"},\"childNodes\":[{\"nodeType\":3,\"id\":79,\"textContent\":\" \"},{\"nodeType\":8,\"id\":80},{\"nodeType\":3,\"id\":81,\"textContent\":\" \"},{\"nodeType\":1,\"id\":82,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"legend\",\"id\":\"hint-interactive\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":83,\"textContent\":\" \"},{\"nodeType\":1,\"id\":84,\"tagName\":\"P\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":85,\"textContent\":\"Hint: Hover your mouse over the data points in the graph\"}]},{\"nodeType\":3,\"id\":86,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":87,\"textContent\":\" \"},{\"nodeType\":8,\"id\":88},{\"nodeType\":3,\"id\":89,\"textContent\":\" \"},{\"nodeType\":8,\"id\":90},{\"nodeType\":3,\"id\":91,\"textContent\":\" \"},{\"nodeType\":1,\"id\":92,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"test\"},\"childNodes\":[{\"nodeType\":3,\"id\":93,\"textContent\":\" \"},{\"nodeType\":1,\"id\":94,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":95,\"textContent\":\" \"},{\"nodeType\":1,\"id\":96,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":97,\"textContent\":\"Which shift(s) start at 11 am? \"}]},{\"nodeType\":3,\"id\":98,\"textContent\":\" \"},{\"nodeType\":1,\"id\":99,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":100,\"textContent\":\" \"},{\"nodeType\":1,\"id\":101,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":102,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":103,\"textContent\":\" \"},{\"nodeType\":1,\"id\":104,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":105,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":106,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":107,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":108,\"textContent\":\" \"},{\"nodeType\":1,\"id\":109,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":110,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":111,\"textContent\":\" \"},{\"nodeType\":1,\"id\":112,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":113,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":115,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":116,\"textContent\":\" \"},{\"nodeType\":1,\"id\":117,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":118,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":120,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":121,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":122,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":123,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":125,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":126,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":127,\"textContent\":\" \"},{\"nodeType\":1,\"id\":128,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":129,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":130,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":132,\"textContent\":\" \"},{\"nodeType\":1,\"id\":133,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":134,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":135,\"textContent\":\" \"},{\"nodeType\":1,\"id\":136,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":137,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":138,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":140,\"textContent\":\" \"},{\"nodeType\":1,\"id\":141,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":142,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":143,\"textContent\":\" \"},{\"nodeType\":1,\"id\":144,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":145,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":146,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":147,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":148,\"textContent\":\" \"},{\"nodeType\":1,\"id\":149,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":150,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":151,\"textContent\":\" \"},{\"nodeType\":1,\"id\":152,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":153,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":154,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":156,\"textContent\":\" \"},{\"nodeType\":1,\"id\":157,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":158,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":159,\"textContent\":\" \"},{\"nodeType\":1,\"id\":160,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":161,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":162,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":163,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":164,\"textContent\":\" \"},{\"nodeType\":1,\"id\":165,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":166,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":167,\"textContent\":\" \"},{\"nodeType\":1,\"id\":168,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":169,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":170,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":171,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":172,\"textContent\":\" \"},{\"nodeType\":1,\"id\":173,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":174,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":175,\"textContent\":\" \"},{\"nodeType\":1,\"id\":176,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":177,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":178,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":179,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":180,\"textContent\":\" \"},{\"nodeType\":1,\"id\":181,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":182,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":183,\"textContent\":\" \"},{\"nodeType\":1,\"id\":184,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":185,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":186,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":187,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":188,\"textContent\":\" \"},{\"nodeType\":1,\"id\":189,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":190,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":191,\"textContent\":\" \"},{\"nodeType\":1,\"id\":192,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":193,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":194,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":196,\"textContent\":\" \"},{\"nodeType\":1,\"id\":197,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":198,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":200,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":201,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":202,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":203,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":205,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":206,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":207,\"textContent\":\" \"},{\"nodeType\":1,\"id\":208,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":209,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":210,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":211,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":212,\"textContent\":\" \"},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":214,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":215,\"textContent\":\" \"},{\"nodeType\":1,\"id\":216,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":217,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":218,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":219,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":220,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":221,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":223,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":224,\"textContent\":\" \"},{\"nodeType\":1,\"id\":225,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":226,\"textContent\":\"Which shift(s) start at the same time as D?\"}]},{\"nodeType\":3,\"id\":227,\"textContent\":\" \"},{\"nodeType\":1,\"id\":228,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":229,\"textContent\":\" \"},{\"nodeType\":1,\"id\":230,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":231,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":232,\"textContent\":\" \"},{\"nodeType\":1,\"id\":233,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":234,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":235,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":236,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":237,\"textContent\":\" \"},{\"nodeType\":1,\"id\":238,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":239,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":240,\"textContent\":\" \"},{\"nodeType\":1,\"id\":241,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":242,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":243,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":244,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":245,\"textContent\":\" \"},{\"nodeType\":1,\"id\":246,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":247,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":248,\"textContent\":\" \"},{\"nodeType\":1,\"id\":249,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":250,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":251,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":252,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":253,\"textContent\":\" \"},{\"nodeType\":1,\"id\":254,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":255,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":256,\"textContent\":\" \"},{\"nodeType\":1,\"id\":257,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":258,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":259,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":260,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":261,\"textContent\":\" \"},{\"nodeType\":1,\"id\":262,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":263,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":264,\"textContent\":\" \"},{\"nodeType\":1,\"id\":265,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":266,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":267,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":268,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":269,\"textContent\":\" \"},{\"nodeType\":1,\"id\":270,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":271,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":273,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":274,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":275,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":276,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":278,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":279,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":280,\"textContent\":\" \"},{\"nodeType\":1,\"id\":281,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":282,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":283,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":284,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":286,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":287,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":288,\"textContent\":\" \"},{\"nodeType\":1,\"id\":289,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":290,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":291,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":292,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":293,\"textContent\":\" \"},{\"nodeType\":1,\"id\":294,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":295,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":296,\"textContent\":\" \"},{\"nodeType\":1,\"id\":297,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":298,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":299,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":300,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":301,\"textContent\":\" \"},{\"nodeType\":1,\"id\":302,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":303,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":304,\"textContent\":\" \"},{\"nodeType\":1,\"id\":305,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":306,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":307,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":308,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":309,\"textContent\":\" \"},{\"nodeType\":1,\"id\":310,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":311,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":312,\"textContent\":\" \"},{\"nodeType\":1,\"id\":313,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":314,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":315,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":316,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":317,\"textContent\":\" \"},{\"nodeType\":1,\"id\":318,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":319,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":320,\"textContent\":\" \"},{\"nodeType\":1,\"id\":321,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":322,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":323,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":324,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":325,\"textContent\":\" \"},{\"nodeType\":1,\"id\":326,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":327,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":328,\"textContent\":\" \"},{\"nodeType\":1,\"id\":329,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":330,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":331,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":332,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":333,\"textContent\":\" \"},{\"nodeType\":1,\"id\":334,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":335,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":336,\"textContent\":\" \"},{\"nodeType\":1,\"id\":337,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":338,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":339,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":340,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":341,\"textContent\":\" \"},{\"nodeType\":1,\"id\":342,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":343,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":344,\"textContent\":\" \"},{\"nodeType\":1,\"id\":345,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":346,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":347,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":348,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":349,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":351,\"textContent\":\" \"},{\"nodeType\":1,\"id\":352,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":353,\"textContent\":\" \"},{\"nodeType\":1,\"id\":354,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":355,\"textContent\":\"Which shift(s) begin when C ends?\"}]},{\"nodeType\":3,\"id\":356,\"textContent\":\" \"},{\"nodeType\":1,\"id\":357,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":358,\"textContent\":\" \"},{\"nodeType\":1,\"id\":359,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":360,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":361,\"textContent\":\" \"},{\"nodeType\":1,\"id\":362,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":363,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":364,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":365,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":366,\"textContent\":\" \"},{\"nodeType\":1,\"id\":367,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":368,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":369,\"textContent\":\" \"},{\"nodeType\":1,\"id\":370,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":371,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":372,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":373,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":374,\"textContent\":\" \"},{\"nodeType\":1,\"id\":375,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":376,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":377,\"textContent\":\" \"},{\"nodeType\":1,\"id\":378,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":379,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":380,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":381,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":382,\"textContent\":\" \"},{\"nodeType\":1,\"id\":383,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":384,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":385,\"textContent\":\" \"},{\"nodeType\":1,\"id\":386,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":387,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":388,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":389,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":390,\"textContent\":\" \"},{\"nodeType\":1,\"id\":391,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":392,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":393,\"textContent\":\" \"},{\"nodeType\":1,\"id\":394,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":395,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":396,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":397,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":398,\"textContent\":\" \"},{\"nodeType\":1,\"id\":399,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":400,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":401,\"textContent\":\" \"},{\"nodeType\":1,\"id\":402,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":403,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":404,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":405,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":406,\"textContent\":\" \"},{\"nodeType\":1,\"id\":407,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":408,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":409,\"textContent\":\" \"},{\"nodeType\":1,\"id\":410,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":411,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":412,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":413,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":414,\"textContent\":\" \"},{\"nodeType\":1,\"id\":415,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":416,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":417,\"textContent\":\" \"},{\"nodeType\":1,\"id\":418,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":419,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":420,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":421,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":422,\"textContent\":\" \"},{\"nodeType\":1,\"id\":423,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":424,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":425,\"textContent\":\" \"},{\"nodeType\":1,\"id\":426,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":427,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":428,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":429,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":430,\"textContent\":\" \"},{\"nodeType\":1,\"id\":431,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":432,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":433,\"textContent\":\" \"},{\"nodeType\":1,\"id\":434,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":435,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":436,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":437,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":438,\"textContent\":\" \"},{\"nodeType\":1,\"id\":439,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":440,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":441,\"textContent\":\" \"},{\"nodeType\":1,\"id\":442,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":443,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":444,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":445,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":446,\"textContent\":\" \"},{\"nodeType\":1,\"id\":447,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":448,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":449,\"textContent\":\" \"},{\"nodeType\":1,\"id\":450,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":451,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":452,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":453,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":454,\"textContent\":\" \"},{\"nodeType\":1,\"id\":455,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":456,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":457,\"textContent\":\" \"},{\"nodeType\":1,\"id\":458,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":459,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":460,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":461,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":462,\"textContent\":\" \"},{\"nodeType\":1,\"id\":463,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":464,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":465,\"textContent\":\" \"},{\"nodeType\":1,\"id\":466,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":467,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":468,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":469,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":470,\"textContent\":\" \"},{\"nodeType\":1,\"id\":471,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":472,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":473,\"textContent\":\" \"},{\"nodeType\":1,\"id\":474,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":475,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":476,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":477,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":478,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":479,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":480,\"textContent\":\" \"},{\"nodeType\":1,\"id\":481,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":483,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":484,\"textContent\":\" Which shift(s) end at 4 pm?\"}]},{\"nodeType\":3,\"id\":485,\"textContent\":\" \"},{\"nodeType\":1,\"id\":486,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":492,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":500,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":503,\"textContent\":\" \"},{\"nodeType\":1,\"id\":504,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":505,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":506,\"textContent\":\" \"},{\"nodeType\":1,\"id\":507,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":508,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":509,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":510,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":511,\"textContent\":\" \"},{\"nodeType\":1,\"id\":512,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":513,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":514,\"textContent\":\" \"},{\"nodeType\":1,\"id\":515,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":516,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":517,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":518,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":519,\"textContent\":\" \"},{\"nodeType\":1,\"id\":520,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":521,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":522,\"textContent\":\" \"},{\"nodeType\":1,\"id\":523,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":524,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":525,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":526,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":527,\"textContent\":\" \"},{\"nodeType\":1,\"id\":528,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":529,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":530,\"textContent\":\" \"},{\"nodeType\":1,\"id\":531,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":532,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":533,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":534,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":535,\"textContent\":\" \"},{\"nodeType\":1,\"id\":536,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":537,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":538,\"textContent\":\" \"},{\"nodeType\":1,\"id\":539,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":540,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":541,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":542,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":543,\"textContent\":\" \"},{\"nodeType\":1,\"id\":544,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":545,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":546,\"textContent\":\" \"},{\"nodeType\":1,\"id\":547,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":548,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":549,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":550,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":551,\"textContent\":\" \"},{\"nodeType\":1,\"id\":552,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":553,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":554,\"textContent\":\" \"},{\"nodeType\":1,\"id\":555,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":556,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":557,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":558,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":559,\"textContent\":\" \"},{\"nodeType\":1,\"id\":560,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":561,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":562,\"textContent\":\" \"},{\"nodeType\":1,\"id\":563,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":564,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":565,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":566,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":567,\"textContent\":\" \"},{\"nodeType\":1,\"id\":568,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":569,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":570,\"textContent\":\" \"},{\"nodeType\":1,\"id\":571,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":572,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":573,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":574,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":575,\"textContent\":\" \"},{\"nodeType\":1,\"id\":576,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":577,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":578,\"textContent\":\" \"},{\"nodeType\":1,\"id\":579,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":580,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":581,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":582,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":583,\"textContent\":\" \"},{\"nodeType\":1,\"id\":584,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":585,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":586,\"textContent\":\" \"},{\"nodeType\":1,\"id\":587,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":588,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":589,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":590,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":592,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":593,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":594,\"textContent\":\" \"},{\"nodeType\":1,\"id\":595,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":596,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":597,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":598,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":599,\"textContent\":\" \"},{\"nodeType\":1,\"id\":600,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":601,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":602,\"textContent\":\" \"},{\"nodeType\":1,\"id\":603,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":604,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":605,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":606,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":607,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":608,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":609,\"textContent\":\" \"},{\"nodeType\":1,\"id\":610,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":612,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":613,\"textContent\":\"Coffee breaks happen halfway through a shift.\"},{\"nodeType\":1,\"id\":614,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":615,\"textContent\":\" Which shift(s) share a break with I?\"}]},{\"nodeType\":3,\"id\":616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":617,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":618,\"textContent\":\" \"},{\"nodeType\":1,\"id\":619,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":620,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":621,\"textContent\":\" \"},{\"nodeType\":1,\"id\":622,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":623,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":624,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":625,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":626,\"textContent\":\" \"},{\"nodeType\":1,\"id\":627,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":628,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":629,\"textContent\":\" \"},{\"nodeType\":1,\"id\":630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":631,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":632,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":633,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":634,\"textContent\":\" \"},{\"nodeType\":1,\"id\":635,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":636,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":637,\"textContent\":\" \"},{\"nodeType\":1,\"id\":638,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":639,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":640,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":641,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":642,\"textContent\":\" \"},{\"nodeType\":1,\"id\":643,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":644,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":645,\"textContent\":\" \"},{\"nodeType\":1,\"id\":646,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":647,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":648,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":649,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":650,\"textContent\":\" \"},{\"nodeType\":1,\"id\":651,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":653,\"textContent\":\" \"},{\"nodeType\":1,\"id\":654,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":655,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":656,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":657,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":659,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":660,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":661,\"textContent\":\" \"},{\"nodeType\":1,\"id\":662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":663,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":664,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":665,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":666,\"textContent\":\" \"},{\"nodeType\":1,\"id\":667,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":668,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":669,\"textContent\":\" \"},{\"nodeType\":1,\"id\":670,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":671,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":672,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":673,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":674,\"textContent\":\" \"},{\"nodeType\":1,\"id\":675,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":676,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":677,\"textContent\":\" \"},{\"nodeType\":1,\"id\":678,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":679,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":680,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":681,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":682,\"textContent\":\" \"},{\"nodeType\":1,\"id\":683,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":685,\"textContent\":\" \"},{\"nodeType\":1,\"id\":686,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":687,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":688,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":689,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":690,\"textContent\":\" \"},{\"nodeType\":1,\"id\":691,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":692,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":693,\"textContent\":\" \"},{\"nodeType\":1,\"id\":694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":695,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":696,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":697,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":698,\"textContent\":\" \"},{\"nodeType\":1,\"id\":699,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":700,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":701,\"textContent\":\" \"},{\"nodeType\":1,\"id\":702,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":703,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":704,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":705,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":706,\"textContent\":\" \"},{\"nodeType\":1,\"id\":707,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":708,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":709,\"textContent\":\" \"},{\"nodeType\":1,\"id\":710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":711,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":712,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":713,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":714,\"textContent\":\" \"},{\"nodeType\":1,\"id\":715,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":716,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":717,\"textContent\":\" \"},{\"nodeType\":1,\"id\":718,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":719,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":720,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":721,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":722,\"textContent\":\" \"},{\"nodeType\":1,\"id\":723,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":724,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":725,\"textContent\":\" \"},{\"nodeType\":1,\"id\":726,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":727,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":728,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":729,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":730,\"textContent\":\" \"},{\"nodeType\":1,\"id\":731,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":732,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":733,\"textContent\":\" \"},{\"nodeType\":1,\"id\":734,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":735,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":736,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":737,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":738,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":739,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":741,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":742,\"textContent\":\" \"},{\"nodeType\":1,\"id\":743,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":744,\"textContent\":\"Which shift(s) are six hours long?\"}]},{\"nodeType\":3,\"id\":745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":746,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":747,\"textContent\":\" \"},{\"nodeType\":1,\"id\":748,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":749,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":750,\"textContent\":\" \"},{\"nodeType\":1,\"id\":751,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":752,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":753,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":754,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":755,\"textContent\":\" \"},{\"nodeType\":1,\"id\":756,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":757,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":758,\"textContent\":\" \"},{\"nodeType\":1,\"id\":759,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":760,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":761,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":762,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":763,\"textContent\":\" \"},{\"nodeType\":1,\"id\":764,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":765,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":766,\"textContent\":\" \"},{\"nodeType\":1,\"id\":767,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":768,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":769,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":770,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":771,\"textContent\":\" \"},{\"nodeType\":1,\"id\":772,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":773,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":774,\"textContent\":\" \"},{\"nodeType\":1,\"id\":775,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":776,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":777,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":778,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":779,\"textContent\":\" \"},{\"nodeType\":1,\"id\":780,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":781,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":782,\"textContent\":\" \"},{\"nodeType\":1,\"id\":783,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":784,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":785,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":786,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":787,\"textContent\":\" \"},{\"nodeType\":1,\"id\":788,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":789,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":790,\"textContent\":\" \"},{\"nodeType\":1,\"id\":791,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":792,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":793,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":794,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":795,\"textContent\":\" \"},{\"nodeType\":1,\"id\":796,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":797,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":798,\"textContent\":\" \"},{\"nodeType\":1,\"id\":799,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":800,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":801,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":802,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":803,\"textContent\":\" \"},{\"nodeType\":1,\"id\":804,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":805,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":806,\"textContent\":\" \"},{\"nodeType\":1,\"id\":807,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":808,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":809,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":810,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":812,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":813,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":814,\"textContent\":\" \"},{\"nodeType\":1,\"id\":815,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":816,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":817,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":818,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":819,\"textContent\":\" \"},{\"nodeType\":1,\"id\":820,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":821,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":822,\"textContent\":\" \"},{\"nodeType\":1,\"id\":823,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":824,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":825,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":826,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":827,\"textContent\":\" \"},{\"nodeType\":1,\"id\":828,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":829,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":830,\"textContent\":\" \"},{\"nodeType\":1,\"id\":831,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":832,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":833,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":834,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":835,\"textContent\":\" \"},{\"nodeType\":1,\"id\":836,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":837,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":838,\"textContent\":\" \"},{\"nodeType\":1,\"id\":839,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":840,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":841,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":842,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":843,\"textContent\":\" \"},{\"nodeType\":1,\"id\":844,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":845,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":846,\"textContent\":\" \"},{\"nodeType\":1,\"id\":847,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":848,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":849,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":850,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":851,\"textContent\":\" \"},{\"nodeType\":1,\"id\":852,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":853,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":854,\"textContent\":\" \"},{\"nodeType\":1,\"id\":855,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":856,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":857,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":858,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":859,\"textContent\":\" \"},{\"nodeType\":1,\"id\":860,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":861,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":862,\"textContent\":\" \"},{\"nodeType\":1,\"id\":863,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":864,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":865,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":866,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":867,\"textContent\":\" \"},{\"nodeType\":1,\"id\":868,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":869,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":870,\"textContent\":\" \"},{\"nodeType\":1,\"id\":871,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":872,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":873,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":874,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":875,\"textContent\":\" \"},{\"nodeType\":1,\"id\":876,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":877,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":878,\"textContent\":\" \"},{\"nodeType\":1,\"id\":879,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":880,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":881,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":882,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":883,\"textContent\":\" \"},{\"nodeType\":1,\"id\":884,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":885,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":886,\"textContent\":\" \"},{\"nodeType\":1,\"id\":887,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":888,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":889,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":890,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":891,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":892,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":894,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":895,\"textContent\":\" \"},{\"nodeType\":1,\"id\":896,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":897,\"textContent\":\"Which 2 shifts less than 5 hours long start at the same time?\"}]},{\"nodeType\":3,\"id\":898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":899,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":900,\"textContent\":\" \"},{\"nodeType\":1,\"id\":901,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":902,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":903,\"textContent\":\" \"},{\"nodeType\":1,\"id\":904,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":905,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":906,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":907,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":908,\"textContent\":\" \"},{\"nodeType\":1,\"id\":909,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":910,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":911,\"textContent\":\" \"},{\"nodeType\":1,\"id\":912,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":913,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":914,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":915,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":916,\"textContent\":\" \"},{\"nodeType\":1,\"id\":917,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":918,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":919,\"textContent\":\" \"},{\"nodeType\":1,\"id\":920,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":921,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":922,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":923,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":924,\"textContent\":\" \"},{\"nodeType\":1,\"id\":925,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":926,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":927,\"textContent\":\" \"},{\"nodeType\":1,\"id\":928,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":929,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":930,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":931,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":932,\"textContent\":\" \"},{\"nodeType\":1,\"id\":933,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":934,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":935,\"textContent\":\" \"},{\"nodeType\":1,\"id\":936,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":937,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":938,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":939,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":940,\"textContent\":\" \"},{\"nodeType\":1,\"id\":941,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":942,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":943,\"textContent\":\" \"},{\"nodeType\":1,\"id\":944,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":945,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":946,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":947,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":948,\"textContent\":\" \"},{\"nodeType\":1,\"id\":949,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":950,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":951,\"textContent\":\" \"},{\"nodeType\":1,\"id\":952,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":953,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":954,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":955,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":956,\"textContent\":\" \"},{\"nodeType\":1,\"id\":957,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":958,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":959,\"textContent\":\" \"},{\"nodeType\":1,\"id\":960,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":961,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":962,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":963,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":965,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":966,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":967,\"textContent\":\" \"},{\"nodeType\":1,\"id\":968,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":969,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":970,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":971,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":972,\"textContent\":\" \"},{\"nodeType\":1,\"id\":973,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":974,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":975,\"textContent\":\" \"},{\"nodeType\":1,\"id\":976,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":977,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":978,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":979,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":980,\"textContent\":\" \"},{\"nodeType\":1,\"id\":981,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":982,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":983,\"textContent\":\" \"},{\"nodeType\":1,\"id\":984,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":985,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":986,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":987,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":988,\"textContent\":\" \"},{\"nodeType\":1,\"id\":989,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":990,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":991,\"textContent\":\" \"},{\"nodeType\":1,\"id\":992,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":993,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":994,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":995,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":996,\"textContent\":\" \"},{\"nodeType\":1,\"id\":997,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":998,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":999,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1000,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1001,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1002,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1003,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1004,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1005,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1006,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1007,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1008,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1009,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1010,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1011,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1012,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1013,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1014,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1015,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1016,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1017,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1018,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1019,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1020,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1021,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1022,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1023,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1024,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1025,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1026,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1027,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1028,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1029,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1030,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1031,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1032,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1033,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1034,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1035,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1036,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1037,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1038,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1039,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1040,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1041,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1042,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1043,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1044,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1045,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1047,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+contained\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1048,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1049,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1050,\"textContent\":\"Which shift(s) under 7 hours long starts before B starts, and ends after X ends?\"}]},{\"nodeType\":3,\"id\":1051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1052,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1053,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1054,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1055,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1056,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1057,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1058,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1059,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1060,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1061,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1062,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1063,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1064,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1065,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1066,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1067,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1068,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1069,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1070,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1071,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1072,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1073,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1074,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1075,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1076,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1077,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1078,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1079,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1080,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1081,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1082,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1083,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1084,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1085,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1086,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1087,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1088,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1089,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1090,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1091,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1092,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1093,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1094,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1095,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1096,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1097,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1098,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1099,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1100,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1101,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1102,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1103,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1104,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1105,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1106,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1107,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1108,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1109,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1110,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1111,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1112,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1113,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1114,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1115,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1116,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1118,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1119,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1120,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1121,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1122,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1123,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1124,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1125,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1126,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1127,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1128,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1129,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1130,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1131,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1132,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1133,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1134,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1135,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1136,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1137,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1138,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1139,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1140,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1141,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1142,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1143,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1144,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1145,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1146,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1147,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1148,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1149,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1150,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1151,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1152,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1153,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1154,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1155,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1156,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1157,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1158,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1159,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1160,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1161,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1162,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1163,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1164,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1165,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1166,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1167,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1168,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1169,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1170,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1171,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1172,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1173,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1174,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1175,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1176,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1177,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1178,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1179,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1180,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1181,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1182,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1183,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1184,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1185,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1186,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1187,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1188,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1189,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1190,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1191,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1192,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1193,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1194,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1195,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1196,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1197,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1198,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1200,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime+before+endtime+during\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1202,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1203,\"textContent\":\"Which shift(s) begins before J begins and ends during B?\"}]},{\"nodeType\":3,\"id\":1204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1205,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1211,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1219,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1227,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1235,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1243,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1251,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1259,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1267,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1270,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1271,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1272,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1273,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1274,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1275,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1276,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1277,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1278,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1279,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1280,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1281,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1282,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1283,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1284,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1285,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1286,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1287,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1288,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1289,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1290,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1291,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1292,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1293,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1294,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1295,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1296,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1298,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1299,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1300,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1301,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1302,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1303,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1304,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1305,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1306,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1307,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1308,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1309,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1310,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1311,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1312,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1313,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1314,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1315,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1316,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1317,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1318,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1319,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1320,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1321,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1322,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1323,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1324,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1325,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1326,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1327,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1328,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1329,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1330,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1331,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1332,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1333,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1334,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1335,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1336,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1337,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1338,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1339,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1340,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1341,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1342,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1343,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1344,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1345,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1346,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1347,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1348,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1349,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1351,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1352,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1353,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.ends\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1354,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1355,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1356,\"textContent\":\"Which shift(s) end at the same time as F?\"}]},{\"nodeType\":3,\"id\":1357,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1358,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1359,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1360,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1361,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1362,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1363,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1364,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1365,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1366,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1367,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1368,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1369,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1370,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1371,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1372,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1373,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1374,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1375,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1376,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1377,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1378,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1379,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1380,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1381,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1382,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1383,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1384,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1385,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1386,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1387,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1388,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1389,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1390,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1391,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1392,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1393,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1394,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1395,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1396,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1397,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1398,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1399,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1400,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1401,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1402,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1403,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1404,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1405,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1406,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1407,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1408,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1409,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1410,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1411,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1412,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1413,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1414,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1415,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1416,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1417,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1418,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1419,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1420,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1421,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1422,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1423,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1424,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1425,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1426,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1427,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1428,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1429,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1430,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1431,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1432,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1433,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1434,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1435,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1436,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1437,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1438,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1439,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1440,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1441,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1442,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1443,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1444,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1445,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1446,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1447,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1448,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1449,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1450,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1451,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1452,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1453,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1454,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1455,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1456,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1457,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1458,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1459,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1460,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1461,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1462,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1463,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1464,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1465,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1466,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1467,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1468,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1469,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1470,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1471,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1472,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1473,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1474,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1475,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1476,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1477,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1478,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1479,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1480,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1481,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1483,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1484,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1485,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1486,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1492,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1500,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1503,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1504,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1505,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1506,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1507,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1508,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1509,\"textContent\":\"Which shift(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":1510,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1511,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1512,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1513,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1514,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1515,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1516,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1517,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1518,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1519,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1520,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1521,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1522,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1523,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1524,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1525,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1526,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1527,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1528,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1529,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1530,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1531,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1532,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1533,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1534,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1535,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1536,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1537,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1538,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1539,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1540,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1541,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1542,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1543,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1544,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1545,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1546,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1547,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1548,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1549,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1550,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1551,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1552,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1553,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1554,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1555,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1556,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1557,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1558,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1559,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1560,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1561,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1562,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1563,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1564,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1565,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1566,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1567,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1568,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1569,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1570,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1571,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1572,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1573,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1574,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1575,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1576,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1577,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1578,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1579,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1580,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1581,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1582,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1583,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1584,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1585,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1586,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1587,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1588,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1589,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1590,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1591,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1592,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1593,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1594,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1595,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1596,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1597,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1598,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1599,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1600,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1601,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1602,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1603,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1604,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1605,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1606,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1607,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1608,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1609,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1610,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1612,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1613,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1614,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1615,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1617,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1618,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1619,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1620,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1621,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1622,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1623,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1624,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1625,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1627,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1628,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1629,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1630,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1631,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1632,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1633,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1634,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1635,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1636,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1637,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1638,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1639,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1640,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1641,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1642,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1643,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1644,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1645,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1646,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1647,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1648,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1649,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1650,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1651,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1652,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1653,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1654,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1655,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1656,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1657,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1659,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1660,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1661,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1662,\"textContent\":\"Which shift(s) start at the same time as F?\"}]},{\"nodeType\":3,\"id\":1663,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1664,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1665,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1666,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1667,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1668,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1669,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1670,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1671,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1672,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1673,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1674,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1675,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1676,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1677,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1678,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1679,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1680,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1681,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1682,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1683,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1684,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1686,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1687,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1688,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1689,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1690,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1691,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1692,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1693,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1694,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1695,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1696,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1697,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1698,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1699,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1700,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1701,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1702,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1703,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1704,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1705,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1706,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1707,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1708,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1709,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1710,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1711,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1712,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1713,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1714,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1715,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1716,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1717,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1718,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1720,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1721,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1722,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1723,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1724,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1725,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1726,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1727,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1728,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1729,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1730,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1731,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1732,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1733,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1734,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1735,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1736,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1737,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1738,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1739,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1741,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1742,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1743,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1744,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1746,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1747,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1748,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1749,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1750,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1751,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1752,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1753,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1754,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1755,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1756,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1757,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1758,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1759,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1760,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1761,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1762,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1763,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1764,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1765,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1766,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1767,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1768,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1769,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1770,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1771,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1772,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1773,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1774,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1775,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1776,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1777,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1778,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1779,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1780,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1781,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1782,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1783,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1784,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1785,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1786,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1787,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1788,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1789,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1790,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1791,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1792,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1793,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1794,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1795,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1796,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1797,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1798,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1799,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1800,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1801,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1802,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1803,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1804,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1805,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1806,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1807,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1808,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1809,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1810,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1812,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1813,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1814,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1815,\"textContent\":\"Which 2 shifts end when Z begins?\"}]},{\"nodeType\":3,\"id\":1816,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1817,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1818,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1819,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1820,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1821,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1822,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1823,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1824,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1825,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1826,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1827,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1828,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1829,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1830,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1831,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1832,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1833,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1834,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1835,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1836,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1837,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1838,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1839,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1840,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1841,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1842,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1843,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1844,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1845,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1846,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1847,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1848,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1849,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1850,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1851,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1852,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1853,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1854,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1855,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1856,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1857,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1858,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1859,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1860,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1861,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1862,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1863,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1864,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1865,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1866,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1867,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1868,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1869,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1870,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1871,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1872,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1873,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1874,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1875,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1876,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1877,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1878,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1879,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1880,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1881,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1882,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1883,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1884,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1885,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1886,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1887,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1888,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1889,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1890,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1891,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1892,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1894,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1895,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1896,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1897,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1899,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1900,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1901,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1902,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1903,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1904,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1905,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1906,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1907,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1908,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1909,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1910,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1911,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1912,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1913,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1914,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1915,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1916,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1917,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1918,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1919,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1920,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1921,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1922,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1923,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1924,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1925,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1926,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1927,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1928,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1929,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1930,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1931,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1932,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1933,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1934,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1935,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1936,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1937,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1938,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1939,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1940,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1941,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1942,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1943,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1944,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1945,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1946,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1947,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1948,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1949,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1950,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1951,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1952,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1953,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1954,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1955,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1956,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1957,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1958,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1959,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1960,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1961,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1962,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1963,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1965,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1966,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1967,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1968,\"textContent\":\"Which shift(s) end at 3pm?\"}]},{\"nodeType\":3,\"id\":1969,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1970,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1971,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1972,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1973,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1974,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1975,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1976,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1977,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1978,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1979,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1980,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1981,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1982,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1983,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1984,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1985,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1986,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1987,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1988,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1989,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1990,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1991,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1992,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1993,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1994,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1995,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1996,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1997,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1998,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1999,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2000,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2001,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2002,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2003,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2004,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2005,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2006,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2007,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2008,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2009,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2010,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2011,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2012,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2013,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2014,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2015,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2016,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2017,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2018,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2019,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2020,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2021,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2022,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2023,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2024,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2025,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2026,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2027,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2028,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2029,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2030,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2031,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2032,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2033,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2034,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2035,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2036,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2037,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2038,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2039,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2040,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2041,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2042,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2043,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2044,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2045,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2047,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2048,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2049,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2050,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2052,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2053,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2054,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2055,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2056,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2057,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2058,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2059,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2060,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2061,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2062,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2063,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2064,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2065,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2066,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2067,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2068,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2069,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2070,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2071,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2072,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2073,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2074,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2075,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2076,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2077,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2078,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2079,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2080,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2081,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2082,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2083,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2084,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2085,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2086,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2087,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2088,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2089,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2090,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2091,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2092,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2093,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2094,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2095,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2096,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2097,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2098,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2099,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2100,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2101,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2102,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2103,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2104,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2105,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2106,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2107,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2108,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2109,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2110,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2111,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2112,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2113,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2114,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2115,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2116,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2118,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":2119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2120,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2121,\"textContent\":\"Coffee breaks happen halfway through a shift. \"},{\"nodeType\":1,\"id\":2122,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":2123,\"textContent\":\"Which shifts share a break at 2pm?\"}]},{\"nodeType\":3,\"id\":2124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2125,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":2126,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2127,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2128,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2129,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2130,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2131,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":2132,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2133,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2134,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2135,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2136,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2137,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2138,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2139,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":2140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2141,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2142,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2143,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2144,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2145,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2146,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2147,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":2148,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2149,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2150,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2151,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2152,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2153,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2154,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2155,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2156,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2157,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2158,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2159,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2160,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2161,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2162,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2163,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2164,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2165,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2166,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2167,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2168,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2169,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2170,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2171,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2172,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2173,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2174,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2175,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2176,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2177,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2178,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2179,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2180,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2181,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2182,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2183,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2184,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2185,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2186,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2187,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2188,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2189,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2190,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2191,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2192,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2193,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2194,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2195,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2196,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2197,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2198,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2199,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2200,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2202,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2203,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2204,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2205,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2211,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2219,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2227,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2235,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2243,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2251,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2259,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2267,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2270,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2271,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2273,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\".strategy\",\"style\":\"display: block;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2274,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2275,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2276,\"textContent\":\"Please describe how to determine what event(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":2277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2278,\"tagName\":\"TEXTAREA\",\"attributes\":{\"id\":\"strategyAnswer\",\"rows\":\"5\",\"cols\":\"80\"}},{\"nodeType\":3,\"id\":2279,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2280,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2281,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2282},{\"nodeType\":3,\"id\":2283,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2284},{\"nodeType\":3,\"id\":2285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2286,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"fixbottom\"},\"childNodes\":[{\"nodeType\":3,\"id\":2287,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2288,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"testingButton\",\"style\":\"display:none;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2289,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2290,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2291,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"strategyButton\",\"style\":\"display: block;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2292,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2293,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2294,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2295,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2296},{\"nodeType\":3,\"id\":2297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2298,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"d3container\"},\"childNodes\":[{\"nodeType\":1,\"id\":2299,\"tagName\":\"svg\",\"attributes\":{\"width\":\"930\",\"height\":\"915\"},\"childNodes\":[{\"nodeType\":1,\"id\":2300,\"tagName\":\"g\",\"attributes\":{\"transform\":\"translate(100,25)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2301,\"tagName\":\"g\",\"attributes\":{\"class\":\"leaders\"}},{\"nodeType\":1,\"id\":2302,\"tagName\":\"g\",\"attributes\":{\"class\":\"static-scaffold\"}},{\"nodeType\":1,\"id\":2303,\"tagName\":\"g\",\"attributes\":{\"class\":\"xaxis\",\"transform\":\"translate(0,800)\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"middle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2304,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M0.5,6V0.5H800.5V6\"}},{\"nodeType\":1,\"id\":2305,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2306,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2307,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2308,\"textContent\":\"08 AM\"}]}]},{\"nodeType\":1,\"id\":2309,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(33.83333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2310,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2311,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2312,\"textContent\":\"08:30\"}]}]},{\"nodeType\":1,\"id\":2313,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(67.16666666666666,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2314,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2315,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2316,\"textContent\":\"09 AM\"}]}]},{\"nodeType\":1,\"id\":2317,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(100.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2318,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2319,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2320,\"textContent\":\"09:30\"}]}]},{\"nodeType\":1,\"id\":2321,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(133.83333333333331,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2322,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2323,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2324,\"textContent\":\"10 AM\"}]}]},{\"nodeType\":1,\"id\":2325,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(167.16666666666669,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2326,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2327,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2328,\"textContent\":\"10:30\"}]}]},{\"nodeType\":1,\"id\":2329,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(200.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2330,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2331,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2332,\"textContent\":\"11 AM\"}]}]},{\"nodeType\":1,\"id\":2333,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(233.83333333333334,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2334,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2335,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2336,\"textContent\":\"11:30\"}]}]},{\"nodeType\":1,\"id\":2337,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(267.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2338,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2339,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2340,\"textContent\":\"12 PM\"}]}]},{\"nodeType\":1,\"id\":2341,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(300.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2342,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2343,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2344,\"textContent\":\"12:30\"}]}]},{\"nodeType\":1,\"id\":2345,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(333.83333333333337,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2346,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2347,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2348,\"textContent\":\"01 PM\"}]}]},{\"nodeType\":1,\"id\":2349,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(367.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2350,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2351,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2352,\"textContent\":\"01:30\"}]}]},{\"nodeType\":1,\"id\":2353,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(400.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2354,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2355,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2356,\"textContent\":\"02 PM\"}]}]},{\"nodeType\":1,\"id\":2357,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(433.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2358,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2359,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2360,\"textContent\":\"02:30\"}]}]},{\"nodeType\":1,\"id\":2361,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(467.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2362,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2363,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2364,\"textContent\":\"03 PM\"}]}]},{\"nodeType\":1,\"id\":2365,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(500.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2366,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2367,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2368,\"textContent\":\"03:30\"}]}]},{\"nodeType\":1,\"id\":2369,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(533.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2370,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2371,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2372,\"textContent\":\"04 PM\"}]}]},{\"nodeType\":1,\"id\":2373,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(567.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2374,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2375,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2376,\"textContent\":\"04:30\"}]}]},{\"nodeType\":1,\"id\":2377,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(600.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2378,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2379,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2380,\"textContent\":\"05 PM\"}]}]},{\"nodeType\":1,\"id\":2381,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(633.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2382,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2383,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2384,\"textContent\":\"05:30\"}]}]},{\"nodeType\":1,\"id\":2385,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(667.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2386,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2387,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2388,\"textContent\":\"06 PM\"}]}]},{\"nodeType\":1,\"id\":2389,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(700.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2390,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2391,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2392,\"textContent\":\"06:30\"}]}]},{\"nodeType\":1,\"id\":2393,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(733.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2394,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2395,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2396,\"textContent\":\"07 PM\"}]}]},{\"nodeType\":1,\"id\":2397,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(767.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2398,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2399,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2400,\"textContent\":\"07:30\"}]}]},{\"nodeType\":1,\"id\":2401,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(800.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2402,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2403,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2404,\"textContent\":\"08 PM\"}]}]},{\"nodeType\":1,\"id\":2405,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2406,\"tagName\":\"text\",\"attributes\":{\"x\":\"533.3333333333334\",\"y\":\"80\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2407,\"textContent\":\"START & END TIME (time of day)\"}]}]}]},{\"nodeType\":1,\"id\":2408,\"tagName\":\"g\",\"attributes\":{\"class\":\"yaxis\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"end\"},\"childNodes\":[{\"nodeType\":1,\"id\":2409,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M-15,800.5H0.5V0.5H-15\"}},{\"nodeType\":1,\"id\":2410,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,800.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2411,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2412,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2413,\"textContent\":\"0\"}]}]},{\"nodeType\":1,\"id\":2414,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,733.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2415,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2416,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2417,\"textContent\":\"1\"}]}]},{\"nodeType\":1,\"id\":2418,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,667.1666666666667)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2419,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2420,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2421,\"textContent\":\"2\"}]}]},{\"nodeType\":1,\"id\":2422,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,600.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2423,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2424,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2425,\"textContent\":\"3\"}]}]},{\"nodeType\":1,\"id\":2426,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,533.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2427,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2428,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2429,\"textContent\":\"4\"}]}]},{\"nodeType\":1,\"id\":2430,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,467.16666666666663)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2431,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2432,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2433,\"textContent\":\"5\"}]}]},{\"nodeType\":1,\"id\":2434,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,400.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2435,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2436,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2437,\"textContent\":\"6\"}]}]},{\"nodeType\":1,\"id\":2438,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,333.8333333333333)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2439,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2440,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2441,\"textContent\":\"7\"}]}]},{\"nodeType\":1,\"id\":2442,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,267.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2443,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2444,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2445,\"textContent\":\"8\"}]}]},{\"nodeType\":1,\"id\":2446,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,200.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2447,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2448,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2449,\"textContent\":\"9\"}]}]},{\"nodeType\":1,\"id\":2450,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,133.83333333333326)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2451,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2452,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2453,\"textContent\":\"10\"}]}]},{\"nodeType\":1,\"id\":2454,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,67.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2455,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2456,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2457,\"textContent\":\"11\"}]}]},{\"nodeType\":1,\"id\":2458,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,0.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2459,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2460,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2461,\"textContent\":\"12\"}]}]},{\"nodeType\":1,\"id\":2462,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2463,\"tagName\":\"text\",\"attributes\":{\"transform\":\"rotate(-90)\",\"x\":\"-350\",\"y\":\"-60\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2464,\"textContent\":\"DURATION (in hours)\"}]}]}]},{\"nodeType\":1,\"id\":2465,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2466,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2467,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"733.3333333333334\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2468,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2469,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"666.6666666666667\",\"y2\":\"666.6666666666667\"}}]},{\"nodeType\":1,\"id\":2470,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2471,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"600\",\"y2\":\"600\"}}]},{\"nodeType\":1,\"id\":2472,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2473,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"533.3333333333334\",\"y2\":\"533.3333333333334\"}}]},{\"nodeType\":1,\"id\":2474,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2475,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"466.66666666666663\",\"y2\":\"466.66666666666663\"}}]},{\"nodeType\":1,\"id\":2476,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2477,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"400\",\"y2\":\"400\"}}]},{\"nodeType\":1,\"id\":2478,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2479,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"333.3333333333333\",\"y2\":\"333.3333333333333\"}}]},{\"nodeType\":1,\"id\":2480,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2481,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"266.66666666666674\",\"y2\":\"266.66666666666674\"}}]},{\"nodeType\":1,\"id\":2482,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2483,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"200\",\"y2\":\"200\"}}]},{\"nodeType\":1,\"id\":2484,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2485,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"133.33333333333326\",\"y2\":\"133.33333333333326\"}}]},{\"nodeType\":1,\"id\":2486,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2487,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"66.66666666666674\",\"y2\":\"66.66666666666674\"}}]},{\"nodeType\":1,\"id\":2488,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2489,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"0\",\"y2\":\"0\"}}]}]},{\"nodeType\":1,\"id\":2490,\"tagName\":\"g\",\"attributes\":{\"class\":\"xgrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2491,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"0\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2492,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"800\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2493,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"466.6666666666667\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2494,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"333.33333333333337\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2495,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"533.3333333333333\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2496,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"266.66666666666663\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2497,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"600\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2498,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"200\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2499,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"666.6666666666667\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2500,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"133.33333333333331\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2501,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"733.3333333333333\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2502,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"66.66666666666666\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2503,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2504,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2505,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2506,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2507,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2508,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2509,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2510,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2511,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2512,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2513,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2514,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"666.6666666666667\"}}]},{\"nodeType\":1,\"id\":2515,\"tagName\":\"g\",\"attributes\":{\"class\":\"data\"},\"childNodes\":[{\"nodeType\":1,\"id\":2516,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2517,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"266.66666666666674\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2518,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"258.66666666666674\"},\"childNodes\":[{\"nodeType\":3,\"id\":2519,\"textContent\":\"A \"}]}]},{\"nodeType\":1,\"id\":2520,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2521,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2522,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2523,\"textContent\":\"B \"}]}]},{\"nodeType\":1,\"id\":2524,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2525,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"366.66666666666663\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2526,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"361.66666666666663\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2527,\"textContent\":\"C \"}]}]},{\"nodeType\":1,\"id\":2528,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2529,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"666.6666666666667\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2530,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"661.6666666666667\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2531,\"textContent\":\"D \"}]}]},{\"nodeType\":1,\"id\":2532,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2533,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"200\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2534,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"195\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2535,\"textContent\":\"E \"}]}]},{\"nodeType\":1,\"id\":2536,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2537,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2538,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2539,\"textContent\":\"F \"}]}]},{\"nodeType\":1,\"id\":2540,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2541,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2542,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2543,\"textContent\":\"G \"}]}]},{\"nodeType\":1,\"id\":2544,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2545,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2546,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2547,\"textContent\":\"H \"}]}]},{\"nodeType\":1,\"id\":2548,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2549,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"100\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2550,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"95\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2551,\"textContent\":\"I \"}]}]},{\"nodeType\":1,\"id\":2552,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2553,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"133.33333333333331\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2554,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"128.33333333333331\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2555,\"textContent\":\"J \"}]}]},{\"nodeType\":1,\"id\":2556,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2557,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"133.33333333333326\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2558,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"125.33333333333326\"},\"childNodes\":[{\"nodeType\":3,\"id\":2559,\"textContent\":\"K \"}]}]},{\"nodeType\":1,\"id\":2560,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2561,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"333.3333333333333\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2562,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"325.3333333333333\"},\"childNodes\":[{\"nodeType\":3,\"id\":2563,\"textContent\":\"L \"}]}]},{\"nodeType\":1,\"id\":2564,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2565,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"300\",\"cy\":\"733.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2566,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"295\",\"y\":\"725.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2567,\"textContent\":\"M \"}]}]},{\"nodeType\":1,\"id\":2568,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2569,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"600\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2570,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"595\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2571,\"textContent\":\"N \"}]}]},{\"nodeType\":1,\"id\":2572,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2573,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"433.3333333333333\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2574,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"428.3333333333333\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2575,\"textContent\":\"O \"}]}]},{\"nodeType\":1,\"id\":2576,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2577,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"200\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2578,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"192\"},\"childNodes\":[{\"nodeType\":3,\"id\":2579,\"textContent\":\"P \"}]}]},{\"nodeType\":1,\"id\":2580,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2581,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"533.3333333333333\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2582,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"528.3333333333333\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2583,\"textContent\":\"Z \"}]}]},{\"nodeType\":1,\"id\":2584,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2585,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2586,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2587,\"textContent\":\"X \"}]}]}]}]}]}]},{\"nodeType\":3,\"id\":2588,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2589,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2590},{\"nodeType\":3,\"id\":2591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2592,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2593,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2594,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2595,\"textContent\":\" \"}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 204, dom: 757, initialDom: 820",
  "javascriptErrors": []
}