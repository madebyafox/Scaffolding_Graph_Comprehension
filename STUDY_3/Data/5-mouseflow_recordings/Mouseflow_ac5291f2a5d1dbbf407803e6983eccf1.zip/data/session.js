var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "ac5291f2a5d1dbbf407803e6983eccf1",
  "created": "2018-06-04T13:21:43.3017346-07:00",
  "lastActivity": "2018-06-04T13:22:29.7257346-07:00",
  "pageViews": [
    {
      "id": "06044328137b2a5a29ddaa57eeb70e3cd6e9cb0e",
      "startTime": "2018-06-04T13:21:43.3017346-07:00",
      "endTime": "2018-06-04T13:22:29.7257346-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/7",
      "visitTime": 46424,
      "engagementTime": 42847,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 46424,
  "engagementTime": 42847,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.24",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=MKTF4",
    "CONDITION=211",
    "TRI_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "403a967faaed8e22177181d1b1499219",
  "gdpr": false
}