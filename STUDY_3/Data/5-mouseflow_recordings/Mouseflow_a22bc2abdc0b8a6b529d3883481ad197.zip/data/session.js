var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "a22bc2abdc0b8a6b529d3883481ad197",
  "created": "2018-05-22T16:08:45.5639223-07:00",
  "lastActivity": "2018-05-22T16:10:06.4096438-07:00",
  "pageViews": [
    {
      "id": "0522452754a4f654bd6e9a79ecb7e4912168b3ee",
      "startTime": "2018-05-22T16:08:45.835354-07:00",
      "endTime": "2018-05-22T16:10:06.4096438-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/3",
      "visitTime": 80696,
      "engagementTime": 70495,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 80696,
  "engagementTime": 70495,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.30",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=PRRKJ",
    "CONDITION=115"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "b772d31c75957d423b0fcc00f430c445",
  "gdpr": false
}