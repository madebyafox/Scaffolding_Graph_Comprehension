var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "2adc6054e9e182b4dac1b8636b792c26",
  "created": "2018-05-29T16:15:24.4575826-07:00",
  "lastActivity": "2018-05-29T16:15:36.2505826-07:00",
  "pageViews": [
    {
      "id": "05292411771f43cccb4fb0bc798491824e43d7d8",
      "startTime": "2018-05-29T16:15:24.4575826-07:00",
      "endTime": "2018-05-29T16:15:36.2505826-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/11",
      "visitTime": 11793,
      "engagementTime": 11761,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 11793,
  "engagementTime": 11761,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.22",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=0CR6Z",
    "CONDITION=113",
    "TRI_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "6e58f601918becd1693e8cd41a909ac2",
  "gdpr": false
}