var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "d45524abaf962866c7c4c44c6cb77f6c",
  "created": "2018-05-24T12:06:47.5553123-07:00",
  "lastActivity": "2018-05-24T12:07:08.5908424-07:00",
  "pageViews": [
    {
      "id": "05244721dc8a67d64d677b15290dabc8aae371af",
      "startTime": "2018-05-24T12:06:47.7938424-07:00",
      "endTime": "2018-05-24T12:07:08.5908424-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/3",
      "visitTime": 20797,
      "engagementTime": 20797,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 20797,
  "engagementTime": 20797,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.27",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=HZWEH",
    "CONDITION=113",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "174a6e3e2e8561d3e5726c18b089f393",
  "gdpr": false
}