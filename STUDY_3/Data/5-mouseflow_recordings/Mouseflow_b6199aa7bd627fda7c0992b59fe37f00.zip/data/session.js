var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "b6199aa7bd627fda7c0992b59fe37f00",
  "created": "2018-06-01T11:09:01.3372477-07:00",
  "lastActivity": "2018-06-01T11:09:55.8454542-07:00",
  "pageViews": [
    {
      "id": "06010118decd1b5d136fee82dd999d2240823f9a",
      "startTime": "2018-06-01T11:09:01.4884542-07:00",
      "endTime": "2018-06-01T11:09:55.8454542-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/1",
      "visitTime": 54357,
      "engagementTime": 54285,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 54357,
  "engagementTime": 54285,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.32",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=2ZXKM",
    "CONDITION=311"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "d798db44cef370ba6b0ddc717f23fac9",
  "gdpr": false
}