var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["05293359a7761fc29d7fe65414df437e16294ce3"] = {
  "startTime": "2018-05-29T19:02:33.0568136Z",
  "websitePageUrl": "/",
  "visitTime": 179166,
  "engagementTime": 40538,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1094,
  "tags": [
    "form-interact"
  ],
  "session": {
    "id": "2eb994228972b753e07c4c87c3b91c43",
    "created": "2018-05-29T19:02:33.0568136+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.181",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/",
    "tags": [
      "form-interact"
    ],
    "variables": [],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "cd5d8ae5618d4023959d62279cbc8020",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/2eb994228972b753e07c4c87c3b91c43/play"
  },
  "events": [
    {
      "t": 102,
      "e": 102,
      "ty": 0,
      "x": 1920,
      "y": 1094
    },
    {
      "t": 316,
      "e": 316,
      "ty": 14,
      "x": 0,
      "y": 1093
    },
    {
      "t": 2202,
      "e": 2202,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 2212,
      "e": 2212,
      "ty": 40,
      "x": 0,
      "y": 0
    },
    {
      "t": 2252,
      "e": 2252,
      "ty": 41,
      "x": 12432,
      "y": 2105,
      "ta": "html > body"
    },
    {
      "t": 2301,
      "e": 2301,
      "ty": 2,
      "x": 369,
      "y": 46
    },
    {
      "t": 10007,
      "e": 7301,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 137705,
      "e": 7301,
      "ty": 2,
      "x": 383,
      "y": 343
    },
    {
      "t": 137757,
      "e": 7353,
      "ty": 41,
      "x": 1699,
      "y": 42913,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 137805,
      "e": 7401,
      "ty": 2,
      "x": 321,
      "y": 663
    },
    {
      "t": 137906,
      "e": 7502,
      "ty": 2,
      "x": 352,
      "y": 734
    },
    {
      "t": 138006,
      "e": 7602,
      "ty": 2,
      "x": 526,
      "y": 850
    },
    {
      "t": 138006,
      "e": 7602,
      "ty": 41,
      "x": 11440,
      "y": 22253,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 138105,
      "e": 7701,
      "ty": 2,
      "x": 611,
      "y": 917
    },
    {
      "t": 138205,
      "e": 7801,
      "ty": 2,
      "x": 628,
      "y": 912
    },
    {
      "t": 138256,
      "e": 7852,
      "ty": 41,
      "x": 16950,
      "y": 62327,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 138305,
      "e": 7901,
      "ty": 2,
      "x": 672,
      "y": 898
    },
    {
      "t": 138405,
      "e": 8001,
      "ty": 2,
      "x": 784,
      "y": 931
    },
    {
      "t": 138505,
      "e": 8101,
      "ty": 2,
      "x": 788,
      "y": 928
    },
    {
      "t": 138506,
      "e": 8102,
      "ty": 41,
      "x": 24330,
      "y": 52011,
      "ta": "> div.masterdiv > div:[2] > div > div"
    },
    {
      "t": 138606,
      "e": 8202,
      "ty": 2,
      "x": 788,
      "y": 926
    },
    {
      "t": 138705,
      "e": 8301,
      "ty": 2,
      "x": 804,
      "y": 921
    },
    {
      "t": 138756,
      "e": 8352,
      "ty": 41,
      "x": 1843,
      "y": 32818,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 138818,
      "e": 8414,
      "ty": 3,
      "x": 804,
      "y": 921,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 138923,
      "e": 8519,
      "ty": 4,
      "x": 1843,
      "y": 32818,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 138923,
      "e": 8519,
      "ty": 5,
      "x": 804,
      "y": 921,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 138925,
      "e": 8521,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox"
    },
    {
      "t": 138932,
      "e": 8528,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox",
      "v": "on"
    },
    {
      "t": 139105,
      "e": 8701,
      "ty": 2,
      "x": 928,
      "y": 1013
    },
    {
      "t": 139206,
      "e": 8802,
      "ty": 2,
      "x": 940,
      "y": 1020
    },
    {
      "t": 139256,
      "e": 8852,
      "ty": 41,
      "x": 31808,
      "y": 61886,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 139305,
      "e": 8901,
      "ty": 2,
      "x": 943,
      "y": 1024
    },
    {
      "t": 139406,
      "e": 9002,
      "ty": 2,
      "x": 964,
      "y": 1053
    },
    {
      "t": 139506,
      "e": 9102,
      "ty": 2,
      "x": 965,
      "y": 1062
    },
    {
      "t": 139506,
      "e": 9102,
      "ty": 41,
      "x": 33038,
      "y": 64794,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 139606,
      "e": 9202,
      "ty": 2,
      "x": 968,
      "y": 1079
    },
    {
      "t": 139699,
      "e": 9295,
      "ty": 3,
      "x": 968,
      "y": 1079,
      "ta": "#start"
    },
    {
      "t": 139700,
      "e": 9296,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox"
    },
    {
      "t": 139701,
      "e": 9297,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 139755,
      "e": 9351,
      "ty": 41,
      "x": 31948,
      "y": 12167,
      "ta": "#start"
    },
    {
      "t": 139818,
      "e": 9414,
      "ty": 4,
      "x": 31948,
      "y": 12167,
      "ta": "#start"
    },
    {
      "t": 139819,
      "e": 9415,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 139821,
      "e": 9417,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 139821,
      "e": 9417,
      "ty": 5,
      "x": 968,
      "y": 1079,
      "ta": "#start"
    },
    {
      "t": 140206,
      "e": 9802,
      "ty": 2,
      "x": 981,
      "y": 979
    },
    {
      "t": 140256,
      "e": 9852,
      "ty": 41,
      "x": 33645,
      "y": 43265,
      "ta": "html > body"
    },
    {
      "t": 140306,
      "e": 9902,
      "ty": 2,
      "x": 996,
      "y": 690
    },
    {
      "t": 140406,
      "e": 10002,
      "ty": 2,
      "x": 992,
      "y": 607
    },
    {
      "t": 140506,
      "e": 10102,
      "ty": 2,
      "x": 990,
      "y": 597
    },
    {
      "t": 140506,
      "e": 10102,
      "ty": 41,
      "x": 33817,
      "y": 32629,
      "ta": "html > body"
    },
    {
      "t": 140825,
      "e": 10421,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 140853,
      "e": 10449,
      "ty": 6,
      "x": 990,
      "y": 597,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 142370,
      "e": 11966,
      "ty": 3,
      "x": 990,
      "y": 597,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 142372,
      "e": 11968,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 142481,
      "e": 12077,
      "ty": 4,
      "x": 39364,
      "y": 34327,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 142482,
      "e": 12078,
      "ty": 5,
      "x": 990,
      "y": 597,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 143086,
      "e": 12682,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "80"
    },
    {
      "t": 143086,
      "e": 12682,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 143211,
      "e": 12807,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "p"
    },
    {
      "t": 143238,
      "e": 12834,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "p"
    },
    {
      "t": 143262,
      "e": 12858,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "65"
    },
    {
      "t": 143262,
      "e": 12858,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 143406,
      "e": 13002,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "80"
    },
    {
      "t": 143407,
      "e": 13003,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 143421,
      "e": 13017,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "pap"
    },
    {
      "t": 143534,
      "e": 13130,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "pap"
    },
    {
      "t": 143622,
      "e": 13218,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "65"
    },
    {
      "t": 143623,
      "e": 13219,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 143717,
      "e": 13313,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "papa"
    },
    {
      "t": 143966,
      "e": 13562,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "9"
    },
    {
      "t": 143966,
      "e": 13562,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "papa"
    },
    {
      "t": 143967,
      "e": 13563,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 143967,
      "e": 13563,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 144077,
      "e": 13673,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": ""
    },
    {
      "t": 144630,
      "e": 14226,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "49"
    },
    {
      "t": 144631,
      "e": 14227,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 144750,
      "e": 14346,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "1"
    },
    {
      "t": 144894,
      "e": 14490,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "49"
    },
    {
      "t": 144895,
      "e": 14491,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 144998,
      "e": 14594,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "11"
    },
    {
      "t": 145222,
      "e": 14818,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "52"
    },
    {
      "t": 145223,
      "e": 14819,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 145326,
      "e": 14922,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "11*"
    },
    {
      "t": 145702,
      "e": 15298,
      "ty": 7,
      "x": 990,
      "y": 609,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 145705,
      "e": 15301,
      "ty": 2,
      "x": 990,
      "y": 609
    },
    {
      "t": 145755,
      "e": 15351,
      "ty": 41,
      "x": 40878,
      "y": 25745,
      "ta": "#jspsych-survey-text-1 > p"
    },
    {
      "t": 145806,
      "e": 15402,
      "ty": 2,
      "x": 1000,
      "y": 673
    },
    {
      "t": 145835,
      "e": 15431,
      "ty": 6,
      "x": 1000,
      "y": 682,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 145906,
      "e": 15502,
      "ty": 2,
      "x": 995,
      "y": 693
    },
    {
      "t": 145935,
      "e": 15531,
      "ty": 7,
      "x": 990,
      "y": 700,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 145952,
      "e": 15548,
      "ty": 6,
      "x": 984,
      "y": 708,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 146006,
      "e": 15602,
      "ty": 2,
      "x": 976,
      "y": 718
    },
    {
      "t": 146006,
      "e": 15602,
      "ty": 41,
      "x": 41271,
      "y": 19859,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 146106,
      "e": 15702,
      "ty": 2,
      "x": 975,
      "y": 718
    },
    {
      "t": 146257,
      "e": 15853,
      "ty": 41,
      "x": 40756,
      "y": 19859,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 146706,
      "e": 16302,
      "ty": 2,
      "x": 973,
      "y": 720
    },
    {
      "t": 146756,
      "e": 16352,
      "ty": 41,
      "x": 39209,
      "y": 27802,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 146806,
      "e": 16402,
      "ty": 2,
      "x": 972,
      "y": 722
    },
    {
      "t": 147539,
      "e": 17135,
      "ty": 3,
      "x": 972,
      "y": 722,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 147540,
      "e": 17136,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "11*"
    },
    {
      "t": 147541,
      "e": 17137,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 147541,
      "e": 17137,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 147698,
      "e": 17294,
      "ty": 4,
      "x": 39209,
      "y": 27802,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 147700,
      "e": 17296,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 147701,
      "e": 17296,
      "ty": 5,
      "x": 972,
      "y": 722,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 147702,
      "e": 17297,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 148794,
      "e": 18389,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 148822,
      "e": 18417,
      "ty": 6,
      "x": 972,
      "y": 722,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 156006,
      "e": 23417,
      "ty": 2,
      "x": 971,
      "y": 723
    },
    {
      "t": 156007,
      "e": 23418,
      "ty": 41,
      "x": 32373,
      "y": 56209,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 160006,
      "e": 27417,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 165387,
      "e": 28418,
      "ty": 7,
      "x": 968,
      "y": 732,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 165387,
      "e": 28418,
      "ty": 6,
      "x": 968,
      "y": 732,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 165405,
      "e": 28436,
      "ty": 2,
      "x": 964,
      "y": 741
    },
    {
      "t": 165417,
      "e": 28448,
      "ty": 7,
      "x": 957,
      "y": 768,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 165418,
      "e": 28449,
      "ty": 6,
      "x": 957,
      "y": 768,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[4]"
    },
    {
      "t": 165434,
      "e": 28465,
      "ty": 7,
      "x": 946,
      "y": 803,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[4]"
    },
    {
      "t": 165506,
      "e": 28537,
      "ty": 2,
      "x": 915,
      "y": 949
    },
    {
      "t": 165507,
      "e": 28538,
      "ty": 41,
      "x": 30578,
      "y": 56969,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 165584,
      "e": 28615,
      "ty": 6,
      "x": 915,
      "y": 1091,
      "ta": "#start"
    },
    {
      "t": 165600,
      "e": 28631,
      "ty": 7,
      "x": 912,
      "y": 1108,
      "ta": "#start"
    },
    {
      "t": 165606,
      "e": 28637,
      "ty": 2,
      "x": 912,
      "y": 1108
    },
    {
      "t": 165706,
      "e": 28737,
      "ty": 2,
      "x": 912,
      "y": 1124
    },
    {
      "t": 165756,
      "e": 28787,
      "ty": 41,
      "x": 12404,
      "y": 27318,
      "ta": "> div.masterdiv > div:[3]"
    },
    {
      "t": 165806,
      "e": 28837,
      "ty": 2,
      "x": 932,
      "y": 1114
    },
    {
      "t": 165906,
      "e": 28937,
      "ty": 2,
      "x": 935,
      "y": 1111
    },
    {
      "t": 166006,
      "e": 29037,
      "ty": 2,
      "x": 940,
      "y": 1108
    },
    {
      "t": 166006,
      "e": 29037,
      "ty": 41,
      "x": 23639,
      "y": 19562,
      "ta": "> div.masterdiv > div:[3]"
    },
    {
      "t": 166019,
      "e": 29050,
      "ty": 6,
      "x": 942,
      "y": 1104,
      "ta": "#start"
    },
    {
      "t": 166105,
      "e": 29136,
      "ty": 2,
      "x": 953,
      "y": 1088
    },
    {
      "t": 166162,
      "e": 29193,
      "ty": 3,
      "x": 953,
      "y": 1088,
      "ta": "#start"
    },
    {
      "t": 166163,
      "e": 29194,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 166256,
      "e": 29287,
      "ty": 41,
      "x": 23756,
      "y": 29514,
      "ta": "#start"
    },
    {
      "t": 166266,
      "e": 29297,
      "ty": 4,
      "x": 23756,
      "y": 29514,
      "ta": "#start"
    },
    {
      "t": 166268,
      "e": 29299,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 166270,
      "e": 29301,
      "ty": 5,
      "x": 953,
      "y": 1088,
      "ta": "#start"
    },
    {
      "t": 166276,
      "e": 29307,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 166806,
      "e": 29837,
      "ty": 2,
      "x": 954,
      "y": 1069
    },
    {
      "t": 166905,
      "e": 29936,
      "ty": 2,
      "x": 940,
      "y": 887
    },
    {
      "t": 167006,
      "e": 30037,
      "ty": 41,
      "x": 32095,
      "y": 48694,
      "ta": "html > body"
    },
    {
      "t": 167274,
      "e": 30305,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 167756,
      "e": 30787,
      "ty": 41,
      "x": 32015,
      "y": 55013,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 167806,
      "e": 30837,
      "ty": 2,
      "x": 958,
      "y": 748
    },
    {
      "t": 167906,
      "e": 30937,
      "ty": 2,
      "x": 963,
      "y": 722
    },
    {
      "t": 168006,
      "e": 31037,
      "ty": 41,
      "x": 32937,
      "y": 44764,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 168206,
      "e": 31237,
      "ty": 2,
      "x": 968,
      "y": 642
    },
    {
      "t": 168256,
      "e": 31287,
      "ty": 41,
      "x": 33083,
      "y": 37465,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 168306,
      "e": 31337,
      "ty": 2,
      "x": 966,
      "y": 628
    },
    {
      "t": 168756,
      "e": 31787,
      "ty": 41,
      "x": 32160,
      "y": 37154,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 168806,
      "e": 31837,
      "ty": 2,
      "x": 892,
      "y": 615
    },
    {
      "t": 168906,
      "e": 31937,
      "ty": 2,
      "x": 861,
      "y": 602
    },
    {
      "t": 169006,
      "e": 32037,
      "ty": 2,
      "x": 801,
      "y": 573
    },
    {
      "t": 169006,
      "e": 32037,
      "ty": 41,
      "x": 25073,
      "y": 33194,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 169106,
      "e": 32137,
      "ty": 2,
      "x": 718,
      "y": 564
    },
    {
      "t": 169206,
      "e": 32237,
      "ty": 2,
      "x": 735,
      "y": 534
    },
    {
      "t": 169256,
      "e": 32287,
      "ty": 41,
      "x": 23616,
      "y": 29001,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 169306,
      "e": 32337,
      "ty": 2,
      "x": 822,
      "y": 509
    },
    {
      "t": 169406,
      "e": 32437,
      "ty": 2,
      "x": 898,
      "y": 505
    },
    {
      "t": 169506,
      "e": 32537,
      "ty": 2,
      "x": 915,
      "y": 516
    },
    {
      "t": 169506,
      "e": 32537,
      "ty": 41,
      "x": 30607,
      "y": 28768,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 169606,
      "e": 32637,
      "ty": 2,
      "x": 950,
      "y": 543
    },
    {
      "t": 169705,
      "e": 32736,
      "ty": 2,
      "x": 954,
      "y": 563
    },
    {
      "t": 169756,
      "e": 32787,
      "ty": 41,
      "x": 30995,
      "y": 36688,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 169806,
      "e": 32837,
      "ty": 2,
      "x": 807,
      "y": 690
    },
    {
      "t": 169906,
      "e": 32937,
      "ty": 2,
      "x": 640,
      "y": 730
    },
    {
      "t": 170007,
      "e": 33038,
      "ty": 2,
      "x": 603,
      "y": 732
    },
    {
      "t": 170007,
      "e": 33038,
      "ty": 41,
      "x": 15461,
      "y": 45540,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 170105,
      "e": 33136,
      "ty": 2,
      "x": 575,
      "y": 701
    },
    {
      "t": 170206,
      "e": 33237,
      "ty": 2,
      "x": 566,
      "y": 692
    },
    {
      "t": 170256,
      "e": 33287,
      "ty": 41,
      "x": 13665,
      "y": 42434,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 170306,
      "e": 33337,
      "ty": 2,
      "x": 566,
      "y": 690
    },
    {
      "t": 170405,
      "e": 33436,
      "ty": 2,
      "x": 577,
      "y": 685
    },
    {
      "t": 170505,
      "e": 33536,
      "ty": 2,
      "x": 611,
      "y": 681
    },
    {
      "t": 170505,
      "e": 33536,
      "ty": 41,
      "x": 15849,
      "y": 41580,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 170606,
      "e": 33637,
      "ty": 2,
      "x": 720,
      "y": 685
    },
    {
      "t": 170706,
      "e": 33737,
      "ty": 2,
      "x": 727,
      "y": 685
    },
    {
      "t": 170756,
      "e": 33787,
      "ty": 41,
      "x": 21578,
      "y": 41891,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 170806,
      "e": 33837,
      "ty": 2,
      "x": 735,
      "y": 688
    },
    {
      "t": 170906,
      "e": 33937,
      "ty": 2,
      "x": 807,
      "y": 761
    },
    {
      "t": 171006,
      "e": 34037,
      "ty": 2,
      "x": 826,
      "y": 802
    },
    {
      "t": 171006,
      "e": 34037,
      "ty": 41,
      "x": 26286,
      "y": 50975,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 171107,
      "e": 34138,
      "ty": 2,
      "x": 849,
      "y": 838
    },
    {
      "t": 171207,
      "e": 34238,
      "ty": 2,
      "x": 884,
      "y": 891
    },
    {
      "t": 171255,
      "e": 34286,
      "ty": 41,
      "x": 29684,
      "y": 58973,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 171305,
      "e": 34336,
      "ty": 2,
      "x": 899,
      "y": 909
    },
    {
      "t": 171406,
      "e": 34437,
      "ty": 2,
      "x": 919,
      "y": 936
    },
    {
      "t": 171507,
      "e": 34538,
      "ty": 41,
      "x": 30801,
      "y": 61380,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 172407,
      "e": 35438,
      "ty": 2,
      "x": 920,
      "y": 937
    },
    {
      "t": 172507,
      "e": 35538,
      "ty": 41,
      "x": 30849,
      "y": 61458,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 178160,
      "e": 40538,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 179166,
      "e": 40538,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":60},{\"id\":63},{\"id\":64},{\"id\":74},{\"id\":75},{\"id\":77},{\"id\":78},{\"id\":80},{\"id\":79},{\"id\":76},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":81},{\"id\":82},{\"id\":84},{\"id\":85},{\"id\":97},{\"id\":86},{\"id\":87},{\"id\":98},{\"id\":88},{\"id\":89},{\"id\":99},{\"id\":90},{\"id\":91},{\"id\":100},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":101},{\"id\":102},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":103},{\"id\":96},{\"id\":83},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":109},{\"id\":110},{\"id\":112},{\"id\":111},{\"id\":72},{\"id\":73},{\"id\":61},{\"id\":62}],[],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":113,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":113},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":115,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":114},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":116,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":115},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":117,\"tagName\":\"P\",\"attributes\":{},\"parentNode\":{\"id\":113}},{\"nodeType\":3,\"id\":118,\"textContent\":\"Please enter the following information from your participant card\",\"parentNode\":{\"id\":117}},{\"nodeType\":1,\"id\":119,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":114}},{\"nodeType\":1,\"id\":120,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":119},\"parentNode\":{\"id\":114}},{\"nodeType\":3,\"id\":121,\"textContent\":\"Session code: \",\"parentNode\":{\"id\":119}},{\"nodeType\":1,\"id\":122,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":115}},{\"nodeType\":1,\"id\":123,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":122},\"parentNode\":{\"id\":115}},{\"nodeType\":3,\"id\":124,\"textContent\":\"Condition code: \",\"parentNode\":{\"id\":122}},{\"nodeType\":3,\"id\":125,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":116}}],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":113},{\"id\":117},{\"id\":118},{\"id\":114},{\"id\":119},{\"id\":121},{\"id\":120},{\"id\":115},{\"id\":122},{\"id\":124},{\"id\":123},{\"id\":116},{\"id\":125}],[],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":126,\"tagName\":\"SCRIPT\",\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":127,\"textContent\":\" \",\"previousSibling\":{\"id\":126},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":128,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"previousSibling\":{\"id\":127},\"parentNode\":{\"id\":55}},{\"nodeType\":8,\"id\":129,\"previousSibling\":{\"id\":128},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":130,\"textContent\":\" \",\"previousSibling\":{\"id\":129},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \\t//set text of scenario descriptions based on scenario randomization order in main switch(scenarios[0]) { case \\\"acme\\\": $('#da1').text(\\\"Answer 15 questions to help a manager coordinate a factory shift schedule.\\\"); break; } \",\"parentNode\":{\"id\":126}},{\"nodeType\":3,\"id\":132,\"textContent\":\" \",\"parentNode\":{\"id\":128}},{\"nodeType\":1,\"id\":133,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":132},\"parentNode\":{\"id\":128}},{\"nodeType\":8,\"id\":134,\"previousSibling\":{\"id\":133},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":135,\"textContent\":\" \",\"previousSibling\":{\"id\":134},\"parentNode\":{\"id\":128}},{\"nodeType\":1,\"id\":136,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":135},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":137,\"textContent\":\" \",\"previousSibling\":{\"id\":136},\"parentNode\":{\"id\":128}},{\"nodeType\":8,\"id\":138,\"previousSibling\":{\"id\":137},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \",\"previousSibling\":{\"id\":138},\"parentNode\":{\"id\":128}},{\"nodeType\":1,\"id\":140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":139},\"parentNode\":{\"id\":128}},{\"nodeType\":8,\"id\":141,\"previousSibling\":{\"id\":140},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":142,\"textContent\":\" \",\"previousSibling\":{\"id\":141},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":143,\"textContent\":\" \",\"parentNode\":{\"id\":133}},{\"nodeType\":1,\"id\":144,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":143},\"parentNode\":{\"id\":133}},{\"nodeType\":3,\"id\":145,\"textContent\":\" \",\"previousSibling\":{\"id\":144},\"parentNode\":{\"id\":133}},{\"nodeType\":3,\"id\":146,\"textContent\":\" \",\"parentNode\":{\"id\":144}},{\"nodeType\":1,\"id\":147,\"tagName\":\"H1\",\"attributes\":{},\"previousSibling\":{\"id\":146},\"parentNode\":{\"id\":144}},{\"nodeType\":3,\"id\":148,\"textContent\":\" \",\"previousSibling\":{\"id\":147},\"parentNode\":{\"id\":144}},{\"nodeType\":3,\"id\":149,\"textContent\":\"Instructions\",\"parentNode\":{\"id\":147}},{\"nodeType\":3,\"id\":150,\"textContent\":\" \",\"parentNode\":{\"id\":136}},{\"nodeType\":1,\"id\":151,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":150},\"parentNode\":{\"id\":136}},{\"nodeType\":3,\"id\":152,\"textContent\":\" \",\"previousSibling\":{\"id\":151},\"parentNode\":{\"id\":136}},{\"nodeType\":8,\"id\":153,\"previousSibling\":{\"id\":152},\"parentNode\":{\"id\":136}},{\"nodeType\":3,\"id\":154,\"textContent\":\" \",\"previousSibling\":{\"id\":153},\"parentNode\":{\"id\":136}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \",\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":156,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":155},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":157,\"tagName\":\"TABLE\",\"attributes\":{\"cellspacing\":\"0\",\"cellpadding\":\"0\",\"border\":\"0\",\"style\":\"display:block;\"},\"previousSibling\":{\"id\":156},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":158,\"textContent\":\" \",\"previousSibling\":{\"id\":157},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":159,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":158},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":160,\"textContent\":\" \",\"previousSibling\":{\"id\":159},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":161,\"tagName\":\"UL\",\"attributes\":{\"class\":\"fa-ul\"},\"previousSibling\":{\"id\":160},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":162,\"textContent\":\" \",\"previousSibling\":{\"id\":161},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":163,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":162},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":164,\"textContent\":\" \",\"previousSibling\":{\"id\":163},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":165,\"textContent\":\"We are interested in learning about how people make decisions about time. In this study, you are going to solve a series of problems about scheduling events. To help you solve the problems, we are going to give you a variety of graphs and diagrams. You are going to complete \",\"parentNode\":{\"id\":156}},{\"nodeType\":1,\"id\":166,\"tagName\":\"I\",\"attributes\":{},\"previousSibling\":{\"id\":165},\"parentNode\":{\"id\":156}},{\"nodeType\":3,\"id\":167,\"textContent\":\" of the activities on this computer. \",\"previousSibling\":{\"id\":166},\"parentNode\":{\"id\":156}},{\"nodeType\":3,\"id\":168,\"textContent\":\"all\",\"parentNode\":{\"id\":166}},{\"nodeType\":3,\"id\":169,\"textContent\":\" \",\"parentNode\":{\"id\":157}},{\"nodeType\":1,\"id\":170,\"tagName\":\"TBODY\",\"attributes\":{},\"previousSibling\":{\"id\":169},\"parentNode\":{\"id\":157}},{\"nodeType\":1,\"id\":171,\"tagName\":\"TR\",\"attributes\":{},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":172,\"textContent\":\" \",\"previousSibling\":{\"id\":171},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":173,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":172},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":174,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":173},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":175,\"tagName\":\"TR\",\"attributes\":{\"height\":\"15\"},\"previousSibling\":{\"id\":174},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":176,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":175},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":177,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":176},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":178,\"textContent\":\" \",\"previousSibling\":{\"id\":177},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":179,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":178},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":180,\"textContent\":\" \",\"previousSibling\":{\"id\":179},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":181,\"textContent\":\" \",\"parentNode\":{\"id\":171}},{\"nodeType\":1,\"id\":182,\"tagName\":\"TD\",\"attributes\":{\"width\":\"40\",\"rowspan\":\"2\"},\"previousSibling\":{\"id\":181},\"parentNode\":{\"id\":171}},{\"nodeType\":3,\"id\":183,\"textContent\":\" \",\"previousSibling\":{\"id\":182},\"parentNode\":{\"id\":171}},{\"nodeType\":1,\"id\":184,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":183},\"parentNode\":{\"id\":171}},{\"nodeType\":3,\"id\":185,\"textContent\":\" \",\"previousSibling\":{\"id\":184},\"parentNode\":{\"id\":171}},{\"nodeType\":1,\"id\":186,\"tagName\":\"A\",\"attributes\":{\"class\":\"fa fa-desktop fa-lg\"},\"parentNode\":{\"id\":182}},{\"nodeType\":3,\"id\":187,\"textContent\":\"Acme Factory [20 minutes]\",\"parentNode\":{\"id\":184}},{\"nodeType\":3,\"id\":188,\"textContent\":\" \",\"parentNode\":{\"id\":173}},{\"nodeType\":1,\"id\":189,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":188},\"parentNode\":{\"id\":173}},{\"nodeType\":3,\"id\":190,\"textContent\":\" \",\"previousSibling\":{\"id\":189},\"parentNode\":{\"id\":173}},{\"nodeType\":1,\"id\":191,\"tagName\":\"A\",\"attributes\":{\"id\":\"da1\",\"class\":\"subheading\"},\"parentNode\":{\"id\":189}},{\"nodeType\":3,\"id\":192,\"textContent\":\"Answer 15 questions to help a manager coordinate a factory shift schedule.\",\"parentNode\":{\"id\":191}},{\"nodeType\":3,\"id\":193,\"textContent\":\" \",\"parentNode\":{\"id\":177}},{\"nodeType\":1,\"id\":194,\"tagName\":\"TD\",\"attributes\":{\"rowspan\":\"2\"},\"previousSibling\":{\"id\":193},\"parentNode\":{\"id\":177}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \",\"previousSibling\":{\"id\":194},\"parentNode\":{\"id\":177}},{\"nodeType\":1,\"id\":196,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":195},\"parentNode\":{\"id\":177}},{\"nodeType\":3,\"id\":197,\"textContent\":\" \",\"previousSibling\":{\"id\":196},\"parentNode\":{\"id\":177}},{\"nodeType\":1,\"id\":198,\"tagName\":\"A\",\"attributes\":{\"class\":\"fa fa-desktop fa-lg\"},\"parentNode\":{\"id\":194}},{\"nodeType\":3,\"id\":199,\"textContent\":\"Final Survey [5 minutes]\",\"parentNode\":{\"id\":196}},{\"nodeType\":3,\"id\":200,\"textContent\":\" \",\"parentNode\":{\"id\":179}},{\"nodeType\":1,\"id\":201,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":200},\"parentNode\":{\"id\":179}},{\"nodeType\":3,\"id\":202,\"textContent\":\" \",\"previousSibling\":{\"id\":201},\"parentNode\":{\"id\":179}},{\"nodeType\":1,\"id\":203,\"tagName\":\"I\",\"attributes\":{},\"parentNode\":{\"id\":201}},{\"nodeType\":3,\"id\":204,\"textContent\":\"Complete a demographic survey and feedback on your experience.\",\"parentNode\":{\"id\":203}},{\"nodeType\":1,\"id\":205,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":159}},{\"nodeType\":3,\"id\":206,\"textContent\":\" \",\"previousSibling\":{\"id\":205},\"parentNode\":{\"id\":159}},{\"nodeType\":3,\"id\":207,\"textContent\":\"To ensure accurate results, please:\",\"parentNode\":{\"id\":205}},{\"nodeType\":3,\"id\":208,\"textContent\":\" \\t\",\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":209,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":208},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":210,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":209},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":211,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":210},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":212,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":211},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":212},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":214,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":213},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":215,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":214},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":216,\"textContent\":\" \",\"previousSibling\":{\"id\":215},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":217,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-check\",\"style\":\"color:green\"},\"parentNode\":{\"id\":209}},{\"nodeType\":3,\"id\":218,\"textContent\":\"DO read all instructions \",\"previousSibling\":{\"id\":217},\"parentNode\":{\"id\":209}},{\"nodeType\":1,\"id\":219,\"tagName\":\"I\",\"attributes\":{},\"previousSibling\":{\"id\":218},\"parentNode\":{\"id\":209}},{\"nodeType\":3,\"id\":220,\"textContent\":\" \",\"previousSibling\":{\"id\":219},\"parentNode\":{\"id\":209}},{\"nodeType\":3,\"id\":221,\"textContent\":\"carefully\",\"parentNode\":{\"id\":219}},{\"nodeType\":1,\"id\":222,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":211}},{\"nodeType\":3,\"id\":223,\"textContent\":\"DO NOT close this browser window\",\"previousSibling\":{\"id\":222},\"parentNode\":{\"id\":211}},{\"nodeType\":1,\"id\":224,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":213}},{\"nodeType\":3,\"id\":225,\"textContent\":\"DO NOT try to return to a previous page \",\"previousSibling\":{\"id\":224},\"parentNode\":{\"id\":213}},{\"nodeType\":1,\"id\":226,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":215}},{\"nodeType\":3,\"id\":227,\"textContent\":\"DO NOT use the back button on the mouse or web browser\",\"previousSibling\":{\"id\":226},\"parentNode\":{\"id\":215}},{\"nodeType\":3,\"id\":228,\"textContent\":\"If you have questions at any time, please raise your hand and the experimenter will assist you. \",\"parentNode\":{\"id\":163}},{\"nodeType\":3,\"id\":229,\"textContent\":\" \\t\",\"parentNode\":{\"id\":140}},{\"nodeType\":1,\"id\":230,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":229},\"parentNode\":{\"id\":140}},{\"nodeType\":3,\"id\":231,\"textContent\":\" \",\"previousSibling\":{\"id\":230},\"parentNode\":{\"id\":140}},{\"nodeType\":3,\"id\":232,\"textContent\":\"BEGIN\",\"parentNode\":{\"id\":230}}],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":126},{\"id\":131},{\"id\":127},{\"id\":128},{\"id\":132},{\"id\":133},{\"id\":143},{\"id\":144},{\"id\":146},{\"id\":147},{\"id\":149},{\"id\":148},{\"id\":145},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":150},{\"id\":151},{\"id\":155},{\"id\":156},{\"id\":165},{\"id\":166},{\"id\":168},{\"id\":167},{\"id\":157},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":181},{\"id\":182},{\"id\":186},{\"id\":183},{\"id\":184},{\"id\":187},{\"id\":185},{\"id\":172},{\"id\":173},{\"id\":188},{\"id\":189},{\"id\":191},{\"id\":192},{\"id\":190},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":193},{\"id\":194},{\"id\":198},{\"id\":195},{\"id\":196},{\"id\":199},{\"id\":197},{\"id\":178},{\"id\":179},{\"id\":200},{\"id\":201},{\"id\":203},{\"id\":204},{\"id\":202},{\"id\":180},{\"id\":158},{\"id\":159},{\"id\":205},{\"id\":207},{\"id\":206},{\"id\":160},{\"id\":161},{\"id\":208},{\"id\":209},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":221},{\"id\":220},{\"id\":210},{\"id\":211},{\"id\":222},{\"id\":223},{\"id\":212},{\"id\":213},{\"id\":224},{\"id\":225},{\"id\":214},{\"id\":215},{\"id\":226},{\"id\":227},{\"id\":216},{\"id\":162},{\"id\":163},{\"id\":228},{\"id\":164},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":229},{\"id\":230},{\"id\":232},{\"id\":231},{\"id\":141},{\"id\":142},{\"id\":129},{\"id\":130}],[],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":233,\"tagName\":\"IMG\",\"attributes\":{\"src\":\"img/acme.png\",\"id\":\"jspsych-single-stim-stimulus\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":234,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":233},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":235,\"textContent\":\"Press enter to continue\",\"parentNode\":{\"id\":234}}],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":233},{\"id\":234},{\"id\":235}],[],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":1,\"id\":59,\"tagName\":\"IMG\",\"attributes\":{\"src\":\"img/phone.png\",\"id\":\"jspsych-single-stim-stimulus\"}}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 204, dom: 550, initialDom: 556",
  "javascriptErrors": []
}