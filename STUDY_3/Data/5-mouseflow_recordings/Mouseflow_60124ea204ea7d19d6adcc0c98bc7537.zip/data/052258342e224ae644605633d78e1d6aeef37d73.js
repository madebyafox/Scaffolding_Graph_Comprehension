var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["052258342e224ae644605633d78e1d6aeef37d73"] = {
  "startTime": "2018-05-22T21:02:58.3004066Z",
  "websitePageUrl": "/",
  "visitTime": 258786,
  "engagementTime": 51918,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1094,
  "tags": [
    "form-interact"
  ],
  "session": {
    "id": "60124ea204ea7d19d6adcc0c98bc7537",
    "created": "2018-05-22T21:02:58.3004066+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.181",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/",
    "tags": [
      "form-interact"
    ],
    "variables": [],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "7627697b9c77ba2dc7e370f9a6100705",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/60124ea204ea7d19d6adcc0c98bc7537/play"
  },
  "events": [
    {
      "t": 101,
      "e": 101,
      "ty": 0,
      "x": 1920,
      "y": 1094
    },
    {
      "t": 334,
      "e": 334,
      "ty": 14,
      "x": 0,
      "y": 1093
    },
    {
      "t": 1980,
      "e": 1980,
      "ty": 40,
      "x": 0,
      "y": 0
    },
    {
      "t": 2001,
      "e": 2001,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 2001,
      "e": 2001,
      "ty": 2,
      "x": 200,
      "y": 47
    },
    {
      "t": 2001,
      "e": 2001,
      "ty": 41,
      "x": 6612,
      "y": 2160,
      "ta": "html > body"
    },
    {
      "t": 10001,
      "e": 7001,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 24860,
      "e": 7001,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 24901,
      "e": 7001,
      "ty": 1,
      "x": 0,
      "y": 1
    },
    {
      "t": 25001,
      "e": 7101,
      "ty": 1,
      "x": 0,
      "y": 15
    },
    {
      "t": 25100,
      "e": 7200,
      "ty": 1,
      "x": 0,
      "y": 16
    },
    {
      "t": 25960,
      "e": 8060,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 30001,
      "e": 12101,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 214262,
      "e": 12200,
      "ty": 41,
      "x": 9745,
      "y": 14015,
      "ta": "> div.masterdiv"
    },
    {
      "t": 214312,
      "e": 12250,
      "ty": 2,
      "x": 378,
      "y": 549
    },
    {
      "t": 214411,
      "e": 12349,
      "ty": 2,
      "x": 493,
      "y": 836
    },
    {
      "t": 214512,
      "e": 12450,
      "ty": 2,
      "x": 633,
      "y": 930
    },
    {
      "t": 214512,
      "e": 12450,
      "ty": 41,
      "x": 16704,
      "y": 56530,
      "ta": "> div.masterdiv > div:[2] > div > div"
    },
    {
      "t": 214610,
      "e": 12548,
      "ty": 2,
      "x": 816,
      "y": 960
    },
    {
      "t": 214711,
      "e": 12649,
      "ty": 2,
      "x": 920,
      "y": 931
    },
    {
      "t": 214761,
      "e": 12699,
      "ty": 41,
      "x": 22375,
      "y": 17919,
      "ta": "> div.masterdiv > div:[2] > div > div > label"
    },
    {
      "t": 214811,
      "e": 12749,
      "ty": 2,
      "x": 875,
      "y": 903
    },
    {
      "t": 214911,
      "e": 12849,
      "ty": 2,
      "x": 861,
      "y": 908
    },
    {
      "t": 215011,
      "e": 12949,
      "ty": 2,
      "x": 847,
      "y": 920
    },
    {
      "t": 215012,
      "e": 12950,
      "ty": 41,
      "x": 9147,
      "y": 35792,
      "ta": "> div.masterdiv > div:[2] > div > div > label"
    },
    {
      "t": 215112,
      "e": 13050,
      "ty": 2,
      "x": 836,
      "y": 925
    },
    {
      "t": 215211,
      "e": 13149,
      "ty": 2,
      "x": 813,
      "y": 930
    },
    {
      "t": 215264,
      "e": 13202,
      "ty": 41,
      "x": 21503,
      "y": 62309,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 215311,
      "e": 13249,
      "ty": 2,
      "x": 810,
      "y": 930
    },
    {
      "t": 215341,
      "e": 13279,
      "ty": 3,
      "x": 810,
      "y": 930,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 215411,
      "e": 13349,
      "ty": 4,
      "x": 21503,
      "y": 62309,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 215411,
      "e": 13349,
      "ty": 5,
      "x": 810,
      "y": 930,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 215411,
      "e": 13349,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox"
    },
    {
      "t": 215415,
      "e": 13353,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox",
      "v": "on"
    },
    {
      "t": 215711,
      "e": 13649,
      "ty": 2,
      "x": 841,
      "y": 981
    },
    {
      "t": 215761,
      "e": 13699,
      "ty": 41,
      "x": 31463,
      "y": 65002,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 215764,
      "e": 13702,
      "ty": 6,
      "x": 952,
      "y": 1078,
      "ta": "#start"
    },
    {
      "t": 215811,
      "e": 13749,
      "ty": 2,
      "x": 975,
      "y": 1092
    },
    {
      "t": 215911,
      "e": 13849,
      "ty": 2,
      "x": 977,
      "y": 1094
    },
    {
      "t": 215947,
      "e": 13885,
      "ty": 7,
      "x": 993,
      "y": 1108,
      "ta": "#start"
    },
    {
      "t": 216011,
      "e": 13949,
      "ty": 2,
      "x": 1015,
      "y": 1126
    },
    {
      "t": 216012,
      "e": 13950,
      "ty": 41,
      "x": 58747,
      "y": 29534,
      "ta": "> div.masterdiv > div:[3]"
    },
    {
      "t": 216112,
      "e": 14050,
      "ty": 2,
      "x": 1015,
      "y": 1120
    },
    {
      "t": 216182,
      "e": 14120,
      "ty": 6,
      "x": 1011,
      "y": 1106,
      "ta": "#start"
    },
    {
      "t": 216212,
      "e": 14150,
      "ty": 2,
      "x": 1011,
      "y": 1104
    },
    {
      "t": 216262,
      "e": 14200,
      "ty": 41,
      "x": 54885,
      "y": 58427,
      "ta": "#start"
    },
    {
      "t": 216311,
      "e": 14249,
      "ty": 2,
      "x": 1010,
      "y": 1103
    },
    {
      "t": 216387,
      "e": 14325,
      "ty": 3,
      "x": 1010,
      "y": 1103,
      "ta": "#start"
    },
    {
      "t": 216388,
      "e": 14326,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox"
    },
    {
      "t": 216390,
      "e": 14328,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 216483,
      "e": 14421,
      "ty": 4,
      "x": 54885,
      "y": 58427,
      "ta": "#start"
    },
    {
      "t": 216484,
      "e": 14422,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 216485,
      "e": 14423,
      "ty": 5,
      "x": 1010,
      "y": 1103,
      "ta": "#start"
    },
    {
      "t": 216485,
      "e": 14423,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 217493,
      "e": 15431,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 218111,
      "e": 16049,
      "ty": 2,
      "x": 930,
      "y": 889
    },
    {
      "t": 218148,
      "e": 16086,
      "ty": 6,
      "x": 873,
      "y": 683,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 218166,
      "e": 16104,
      "ty": 7,
      "x": 870,
      "y": 657,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 218199,
      "e": 16137,
      "ty": 6,
      "x": 870,
      "y": 602,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 218211,
      "e": 16149,
      "ty": 2,
      "x": 870,
      "y": 602
    },
    {
      "t": 218231,
      "e": 16169,
      "ty": 7,
      "x": 876,
      "y": 582,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 218261,
      "e": 16199,
      "ty": 41,
      "x": 15356,
      "y": 38052,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 218311,
      "e": 16249,
      "ty": 2,
      "x": 886,
      "y": 530
    },
    {
      "t": 218411,
      "e": 16349,
      "ty": 2,
      "x": 894,
      "y": 537
    },
    {
      "t": 218511,
      "e": 16449,
      "ty": 2,
      "x": 902,
      "y": 565
    },
    {
      "t": 218512,
      "e": 16450,
      "ty": 41,
      "x": 20330,
      "y": 58513,
      "ta": "#jspsych-survey-text-0 > p"
    },
    {
      "t": 218612,
      "e": 16550,
      "ty": 2,
      "x": 903,
      "y": 576
    },
    {
      "t": 218634,
      "e": 16572,
      "ty": 6,
      "x": 906,
      "y": 587,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 218712,
      "e": 16650,
      "ty": 2,
      "x": 907,
      "y": 598
    },
    {
      "t": 218740,
      "e": 16678,
      "ty": 3,
      "x": 907,
      "y": 598,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 218740,
      "e": 16678,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 218761,
      "e": 16699,
      "ty": 41,
      "x": 21412,
      "y": 37448,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 218842,
      "e": 16780,
      "ty": 4,
      "x": 21412,
      "y": 37448,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 218842,
      "e": 16780,
      "ty": 5,
      "x": 907,
      "y": 598,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 220012,
      "e": 17950,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 221695,
      "e": 19633,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "72"
    },
    {
      "t": 221696,
      "e": 19634,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 221766,
      "e": 19704,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "79"
    },
    {
      "t": 221766,
      "e": 19704,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 221846,
      "e": 19784,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "ho"
    },
    {
      "t": 221871,
      "e": 19809,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "84"
    },
    {
      "t": 221871,
      "e": 19809,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 221887,
      "e": 19825,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "hot"
    },
    {
      "t": 221927,
      "e": 19865,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "69"
    },
    {
      "t": 221927,
      "e": 19865,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 221990,
      "e": 19928,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "hote"
    },
    {
      "t": 222030,
      "e": 19968,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "+||"
    },
    {
      "t": 222039,
      "e": 19977,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "76"
    },
    {
      "t": 222039,
      "e": 19977,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 222134,
      "e": 20072,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "+||l"
    },
    {
      "t": 223510,
      "e": 21448,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "9"
    },
    {
      "t": 223510,
      "e": 21448,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "hotel"
    },
    {
      "t": 223510,
      "e": 21448,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 223511,
      "e": 21449,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 223550,
      "e": 21488,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": ""
    },
    {
      "t": 223895,
      "e": 21833,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "49"
    },
    {
      "t": 223896,
      "e": 21834,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 223966,
      "e": 21904,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "50"
    },
    {
      "t": 223966,
      "e": 21904,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 224014,
      "e": 21952,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "12"
    },
    {
      "t": 224119,
      "e": 22057,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "49"
    },
    {
      "t": 224119,
      "e": 22057,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 224150,
      "e": 22088,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "12*"
    },
    {
      "t": 224190,
      "e": 22128,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "12*"
    },
    {
      "t": 224622,
      "e": 22560,
      "ty": 7,
      "x": 1000,
      "y": 579,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 224711,
      "e": 22649,
      "ty": 2,
      "x": 1792,
      "y": 439
    },
    {
      "t": 224761,
      "e": 22699,
      "ty": 41,
      "x": 61230,
      "y": 23599,
      "ta": "html > body"
    },
    {
      "t": 224811,
      "e": 22749,
      "ty": 2,
      "x": 1580,
      "y": 432
    },
    {
      "t": 224911,
      "e": 22849,
      "ty": 2,
      "x": 1268,
      "y": 865
    },
    {
      "t": 225010,
      "e": 22948,
      "ty": 2,
      "x": 1032,
      "y": 964
    },
    {
      "t": 225011,
      "e": 22949,
      "ty": 41,
      "x": 35264,
      "y": 52959,
      "ta": "html > body"
    },
    {
      "t": 225111,
      "e": 23049,
      "ty": 2,
      "x": 899,
      "y": 915
    },
    {
      "t": 225211,
      "e": 23149,
      "ty": 2,
      "x": 792,
      "y": 772
    },
    {
      "t": 225261,
      "e": 23199,
      "ty": 41,
      "x": 27274,
      "y": 41880,
      "ta": "html > body"
    },
    {
      "t": 225311,
      "e": 23249,
      "ty": 2,
      "x": 828,
      "y": 755
    },
    {
      "t": 225410,
      "e": 23348,
      "ty": 2,
      "x": 859,
      "y": 746
    },
    {
      "t": 225511,
      "e": 23449,
      "ty": 2,
      "x": 877,
      "y": 730
    },
    {
      "t": 225511,
      "e": 23449,
      "ty": 41,
      "x": 29926,
      "y": 39996,
      "ta": "html > body"
    },
    {
      "t": 225538,
      "e": 23476,
      "ty": 6,
      "x": 897,
      "y": 724,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 225611,
      "e": 23549,
      "ty": 2,
      "x": 942,
      "y": 714
    },
    {
      "t": 225710,
      "e": 23648,
      "ty": 2,
      "x": 962,
      "y": 709
    },
    {
      "t": 225761,
      "e": 23699,
      "ty": 41,
      "x": 34055,
      "y": 1985,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 225916,
      "e": 23854,
      "ty": 3,
      "x": 962,
      "y": 709,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 225917,
      "e": 23855,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "12*"
    },
    {
      "t": 225918,
      "e": 23856,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 225918,
      "e": 23856,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 226011,
      "e": 23949,
      "ty": 4,
      "x": 34055,
      "y": 1985,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 226012,
      "e": 23950,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 226012,
      "e": 23950,
      "ty": 5,
      "x": 962,
      "y": 709,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 226012,
      "e": 23950,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 227311,
      "e": 25249,
      "ty": 2,
      "x": 962,
      "y": 705
    },
    {
      "t": 227351,
      "e": 25289,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 227359,
      "e": 25297,
      "ty": 6,
      "x": 953,
      "y": 691,
      "ta": "> div.masterdiv > div:[2] > div > ul > li"
    },
    {
      "t": 227406,
      "e": 25344,
      "ty": 7,
      "x": 936,
      "y": 669,
      "ta": "> div.masterdiv > div:[2] > div > ul > li"
    },
    {
      "t": 227411,
      "e": 25349,
      "ty": 2,
      "x": 936,
      "y": 669
    },
    {
      "t": 227510,
      "e": 25448,
      "ty": 2,
      "x": 931,
      "y": 664
    },
    {
      "t": 227511,
      "e": 25449,
      "ty": 41,
      "x": 31365,
      "y": 39974,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 227911,
      "e": 25849,
      "ty": 2,
      "x": 898,
      "y": 620
    },
    {
      "t": 228011,
      "e": 25949,
      "ty": 2,
      "x": 894,
      "y": 612
    },
    {
      "t": 228012,
      "e": 25950,
      "ty": 41,
      "x": 29545,
      "y": 31917,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 228110,
      "e": 26048,
      "ty": 2,
      "x": 893,
      "y": 610
    },
    {
      "t": 228261,
      "e": 26199,
      "ty": 41,
      "x": 29495,
      "y": 31607,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 230011,
      "e": 27949,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 235910,
      "e": 31199,
      "ty": 2,
      "x": 893,
      "y": 650
    },
    {
      "t": 235944,
      "e": 31233,
      "ty": 6,
      "x": 895,
      "y": 680,
      "ta": "> div.masterdiv > div:[2] > div > ul > li"
    },
    {
      "t": 235977,
      "e": 31266,
      "ty": 7,
      "x": 897,
      "y": 708,
      "ta": "> div.masterdiv > div:[2] > div > ul > li"
    },
    {
      "t": 235977,
      "e": 31266,
      "ty": 6,
      "x": 897,
      "y": 708,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 236011,
      "e": 31300,
      "ty": 2,
      "x": 900,
      "y": 722
    },
    {
      "t": 236011,
      "e": 31300,
      "ty": 41,
      "x": 28776,
      "y": 53868,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 243168,
      "e": 36300,
      "ty": 7,
      "x": 903,
      "y": 730,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 243168,
      "e": 36300,
      "ty": 6,
      "x": 903,
      "y": 730,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 243214,
      "e": 36346,
      "ty": 2,
      "x": 906,
      "y": 734
    },
    {
      "t": 243265,
      "e": 36397,
      "ty": 41,
      "x": 29080,
      "y": 16420,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 243314,
      "e": 36446,
      "ty": 2,
      "x": 907,
      "y": 735
    },
    {
      "t": 243515,
      "e": 36647,
      "ty": 41,
      "x": 29130,
      "y": 18760,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 244185,
      "e": 37317,
      "ty": 7,
      "x": 925,
      "y": 769,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 244186,
      "e": 37318,
      "ty": 6,
      "x": 925,
      "y": 769,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[4]"
    },
    {
      "t": 244202,
      "e": 37334,
      "ty": 7,
      "x": 935,
      "y": 787,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[4]"
    },
    {
      "t": 244215,
      "e": 37347,
      "ty": 2,
      "x": 935,
      "y": 787
    },
    {
      "t": 244265,
      "e": 37397,
      "ty": 41,
      "x": 33382,
      "y": 50806,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 244314,
      "e": 37446,
      "ty": 2,
      "x": 987,
      "y": 908
    },
    {
      "t": 244415,
      "e": 37547,
      "ty": 2,
      "x": 987,
      "y": 913
    },
    {
      "t": 244515,
      "e": 37647,
      "ty": 2,
      "x": 987,
      "y": 915
    },
    {
      "t": 244515,
      "e": 37647,
      "ty": 41,
      "x": 34120,
      "y": 54615,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 244614,
      "e": 37746,
      "ty": 2,
      "x": 1004,
      "y": 987
    },
    {
      "t": 244703,
      "e": 37835,
      "ty": 6,
      "x": 1021,
      "y": 1080,
      "ta": "#start"
    },
    {
      "t": 244715,
      "e": 37847,
      "ty": 2,
      "x": 1021,
      "y": 1080
    },
    {
      "t": 244765,
      "e": 37897,
      "ty": 41,
      "x": 53793,
      "y": 50717,
      "ta": "#start"
    },
    {
      "t": 244774,
      "e": 37906,
      "ty": 7,
      "x": 1004,
      "y": 1109,
      "ta": "#start"
    },
    {
      "t": 244813,
      "e": 37945,
      "ty": 2,
      "x": 1001,
      "y": 1125
    },
    {
      "t": 244913,
      "e": 38045,
      "ty": 2,
      "x": 1002,
      "y": 1153
    },
    {
      "t": 245014,
      "e": 38146,
      "ty": 2,
      "x": 1000,
      "y": 1131
    },
    {
      "t": 245014,
      "e": 38146,
      "ty": 41,
      "x": 51725,
      "y": 32304,
      "ta": "> div.masterdiv > div:[3]"
    },
    {
      "t": 245041,
      "e": 38173,
      "ty": 6,
      "x": 993,
      "y": 1106,
      "ta": "#start"
    },
    {
      "t": 245113,
      "e": 38245,
      "ty": 2,
      "x": 987,
      "y": 1091
    },
    {
      "t": 245264,
      "e": 38396,
      "ty": 41,
      "x": 42324,
      "y": 35297,
      "ta": "#start"
    },
    {
      "t": 245271,
      "e": 38403,
      "ty": 3,
      "x": 987,
      "y": 1091,
      "ta": "#start"
    },
    {
      "t": 245272,
      "e": 38404,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 245357,
      "e": 38489,
      "ty": 4,
      "x": 42324,
      "y": 35297,
      "ta": "#start"
    },
    {
      "t": 245357,
      "e": 38489,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 245359,
      "e": 38491,
      "ty": 5,
      "x": 987,
      "y": 1091,
      "ta": "#start"
    },
    {
      "t": 245359,
      "e": 38491,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 246013,
      "e": 39145,
      "ty": 2,
      "x": 987,
      "y": 1089
    },
    {
      "t": 246013,
      "e": 39145,
      "ty": 41,
      "x": 33714,
      "y": 59884,
      "ta": "html > body"
    },
    {
      "t": 246113,
      "e": 39245,
      "ty": 2,
      "x": 987,
      "y": 1086
    },
    {
      "t": 246264,
      "e": 39396,
      "ty": 41,
      "x": 33714,
      "y": 59718,
      "ta": "html > body"
    },
    {
      "t": 246361,
      "e": 39493,
      "ty": 38,
      "x": 8,
      "y": 0
    },
    {
      "t": 246413,
      "e": 39545,
      "ty": 2,
      "x": 1013,
      "y": 1084
    },
    {
      "t": 246513,
      "e": 39645,
      "ty": 2,
      "x": 1243,
      "y": 1080
    },
    {
      "t": 246514,
      "e": 39646,
      "ty": 41,
      "x": 42530,
      "y": 59385,
      "ta": "html > body"
    },
    {
      "t": 246614,
      "e": 39746,
      "ty": 2,
      "x": 1244,
      "y": 1074
    },
    {
      "t": 246714,
      "e": 39846,
      "ty": 2,
      "x": 1232,
      "y": 1050
    },
    {
      "t": 246764,
      "e": 39896,
      "ty": 41,
      "x": 41910,
      "y": 57280,
      "ta": "html > body"
    },
    {
      "t": 246814,
      "e": 39946,
      "ty": 2,
      "x": 1216,
      "y": 1030
    },
    {
      "t": 246914,
      "e": 40046,
      "ty": 2,
      "x": 1197,
      "y": 1004
    },
    {
      "t": 247013,
      "e": 40145,
      "ty": 2,
      "x": 1174,
      "y": 970
    },
    {
      "t": 247013,
      "e": 40145,
      "ty": 41,
      "x": 43180,
      "y": 64020,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 247114,
      "e": 40246,
      "ty": 2,
      "x": 1166,
      "y": 960
    },
    {
      "t": 247265,
      "e": 40397,
      "ty": 41,
      "x": 42791,
      "y": 63244,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 247614,
      "e": 40746,
      "ty": 2,
      "x": 1166,
      "y": 964
    },
    {
      "t": 247764,
      "e": 40896,
      "ty": 41,
      "x": 42791,
      "y": 63554,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 250014,
      "e": 43146,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 250614,
      "e": 43746,
      "ty": 2,
      "x": 1166,
      "y": 689
    },
    {
      "t": 250714,
      "e": 43846,
      "ty": 2,
      "x": 1121,
      "y": 581
    },
    {
      "t": 250764,
      "e": 43896,
      "ty": 41,
      "x": 39151,
      "y": 31874,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 250814,
      "e": 43946,
      "ty": 2,
      "x": 1042,
      "y": 542
    },
    {
      "t": 250914,
      "e": 44046,
      "ty": 2,
      "x": 968,
      "y": 542
    },
    {
      "t": 251014,
      "e": 44146,
      "ty": 2,
      "x": 942,
      "y": 544
    },
    {
      "t": 251014,
      "e": 44146,
      "ty": 41,
      "x": 31917,
      "y": 30942,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 253414,
      "e": 46546,
      "ty": 2,
      "x": 942,
      "y": 552
    },
    {
      "t": 253514,
      "e": 46646,
      "ty": 2,
      "x": 958,
      "y": 696
    },
    {
      "t": 253515,
      "e": 46647,
      "ty": 41,
      "x": 32694,
      "y": 42745,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 253614,
      "e": 46746,
      "ty": 2,
      "x": 984,
      "y": 873
    },
    {
      "t": 253714,
      "e": 46846,
      "ty": 2,
      "x": 984,
      "y": 874
    },
    {
      "t": 253764,
      "e": 46896,
      "ty": 41,
      "x": 33956,
      "y": 56566,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 254214,
      "e": 47346,
      "ty": 2,
      "x": 981,
      "y": 876
    },
    {
      "t": 254264,
      "e": 47396,
      "ty": 41,
      "x": 33762,
      "y": 56877,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 254314,
      "e": 47446,
      "ty": 2,
      "x": 979,
      "y": 881
    },
    {
      "t": 254414,
      "e": 47546,
      "ty": 2,
      "x": 978,
      "y": 889
    },
    {
      "t": 254514,
      "e": 47646,
      "ty": 2,
      "x": 976,
      "y": 897
    },
    {
      "t": 254515,
      "e": 47647,
      "ty": 41,
      "x": 33568,
      "y": 58352,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 254614,
      "e": 47746,
      "ty": 2,
      "x": 975,
      "y": 908
    },
    {
      "t": 254714,
      "e": 47846,
      "ty": 2,
      "x": 975,
      "y": 919
    },
    {
      "t": 254765,
      "e": 47897,
      "ty": 41,
      "x": 33519,
      "y": 60992,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 254814,
      "e": 47946,
      "ty": 2,
      "x": 979,
      "y": 942
    },
    {
      "t": 254914,
      "e": 48046,
      "ty": 2,
      "x": 984,
      "y": 958
    },
    {
      "t": 255014,
      "e": 48146,
      "ty": 2,
      "x": 989,
      "y": 968
    },
    {
      "t": 255015,
      "e": 48147,
      "ty": 41,
      "x": 34199,
      "y": 63865,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 255114,
      "e": 48246,
      "ty": 2,
      "x": 1006,
      "y": 999
    },
    {
      "t": 255214,
      "e": 48346,
      "ty": 2,
      "x": 1026,
      "y": 1024
    },
    {
      "t": 255264,
      "e": 48396,
      "ty": 41,
      "x": 59499,
      "y": 55002,
      "ta": "> p"
    },
    {
      "t": 255315,
      "e": 48447,
      "ty": 2,
      "x": 1057,
      "y": 1036
    },
    {
      "t": 255414,
      "e": 48546,
      "ty": 2,
      "x": 1068,
      "y": 1047
    },
    {
      "t": 255515,
      "e": 48647,
      "ty": 41,
      "x": 36503,
      "y": 57557,
      "ta": "html > body"
    },
    {
      "t": 257780,
      "e": 50912,
      "ty": 38,
      "x": 9,
      "y": 0
    },
    {
      "t": 258414,
      "e": 51546,
      "ty": 2,
      "x": 1004,
      "y": 986
    },
    {
      "t": 258514,
      "e": 51646,
      "ty": 2,
      "x": 990,
      "y": 972
    },
    {
      "t": 258515,
      "e": 51647,
      "ty": 41,
      "x": 33817,
      "y": 53402,
      "ta": "html > body"
    },
    {
      "t": 258786,
      "e": 51918,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":56},{\"id\":57},{\"id\":58},{\"id\":59}],[],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":60,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"parentNode\":{\"id\":55}},{\"nodeType\":8,\"id\":61,\"previousSibling\":{\"id\":60},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":62,\"textContent\":\" \",\"previousSibling\":{\"id\":61},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":63,\"textContent\":\" \",\"parentNode\":{\"id\":60}},{\"nodeType\":1,\"id\":64,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":63},\"parentNode\":{\"id\":60}},{\"nodeType\":3,\"id\":65,\"textContent\":\" \",\"previousSibling\":{\"id\":64},\"parentNode\":{\"id\":60}},{\"nodeType\":8,\"id\":66,\"previousSibling\":{\"id\":65},\"parentNode\":{\"id\":60}},{\"nodeType\":3,\"id\":67,\"textContent\":\" \",\"previousSibling\":{\"id\":66},\"parentNode\":{\"id\":60}},{\"nodeType\":1,\"id\":68,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":67},\"parentNode\":{\"id\":60}},{\"nodeType\":8,\"id\":69,\"previousSibling\":{\"id\":68},\"parentNode\":{\"id\":60}},{\"nodeType\":3,\"id\":70,\"textContent\":\" \",\"previousSibling\":{\"id\":69},\"parentNode\":{\"id\":60}},{\"nodeType\":1,\"id\":71,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":70},\"parentNode\":{\"id\":60}},{\"nodeType\":8,\"id\":72,\"previousSibling\":{\"id\":71},\"parentNode\":{\"id\":60}},{\"nodeType\":3,\"id\":73,\"textContent\":\" \",\"previousSibling\":{\"id\":72},\"parentNode\":{\"id\":60}},{\"nodeType\":3,\"id\":74,\"textContent\":\" \",\"parentNode\":{\"id\":64}},{\"nodeType\":1,\"id\":75,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":74},\"parentNode\":{\"id\":64}},{\"nodeType\":3,\"id\":76,\"textContent\":\" \",\"previousSibling\":{\"id\":75},\"parentNode\":{\"id\":64}},{\"nodeType\":3,\"id\":77,\"textContent\":\" \",\"parentNode\":{\"id\":75}},{\"nodeType\":1,\"id\":78,\"tagName\":\"H3\",\"attributes\":{},\"previousSibling\":{\"id\":77},\"parentNode\":{\"id\":75}},{\"nodeType\":3,\"id\":79,\"textContent\":\" \",\"previousSibling\":{\"id\":78},\"parentNode\":{\"id\":75}},{\"nodeType\":3,\"id\":80,\"textContent\":\"UNIVERSITY OF CALIFORNIA, SAN DIEGO CONSENT TO ACT AS A RESEARCH SUBJECT\",\"parentNode\":{\"id\":78}},{\"nodeType\":3,\"id\":81,\"textContent\":\" \",\"parentNode\":{\"id\":68}},{\"nodeType\":1,\"id\":82,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":81},\"parentNode\":{\"id\":68}},{\"nodeType\":3,\"id\":83,\"textContent\":\" \",\"previousSibling\":{\"id\":82},\"parentNode\":{\"id\":68}},{\"nodeType\":3,\"id\":84,\"textContent\":\" \",\"parentNode\":{\"id\":82}},{\"nodeType\":1,\"id\":85,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":84},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":86,\"textContent\":\" \",\"previousSibling\":{\"id\":85},\"parentNode\":{\"id\":82}},{\"nodeType\":1,\"id\":87,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":86},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":88,\"textContent\":\" \",\"previousSibling\":{\"id\":87},\"parentNode\":{\"id\":82}},{\"nodeType\":1,\"id\":89,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":88},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":90,\"textContent\":\" \",\"previousSibling\":{\"id\":89},\"parentNode\":{\"id\":82}},{\"nodeType\":1,\"id\":91,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic\"},\"previousSibling\":{\"id\":90},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":92,\"textContent\":\" \",\"previousSibling\":{\"id\":91},\"parentNode\":{\"id\":82}},{\"nodeType\":8,\"id\":93,\"previousSibling\":{\"id\":92},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":94,\"textContent\":\" \",\"previousSibling\":{\"id\":93},\"parentNode\":{\"id\":82}},{\"nodeType\":1,\"id\":95,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control-group centered\"},\"previousSibling\":{\"id\":94},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":96,\"textContent\":\" \",\"previousSibling\":{\"id\":95},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":97,\"textContent\":\" You are being invited to participate in a research study titled Learning Diagrams: Evaluating Learning With External Representations. This study is being done by Amy Fox and Dr. Jim Hollan from the University of California - San Diego (UCSD). You were selected to participate in this study because we think you might use graphs and diagrams in your work and educational activities.\",\"parentNode\":{\"id\":85}},{\"nodeType\":3,\"id\":98,\"textContent\":\" The purpose of this research study is to understand how humans try to make sense of charts, diagrams and graphs that are unconventional and that we may not have seen before. If you agree to take part in this study, you will be asked to read a series of instructions and answer a series of questions. The entire study should take no more than 60 minutes to complete. The researchers expect there will be no direct benefit to you from this research, other than any enjoyment you might have in contributing to research. We hope that you will find the questions interesting, though at times you may feel bored. The investigator(s), however, may learn more about how different types of instructions trigger different levels of understanding when using graphs. There are minimal risks associated with this research study, including a loss of confidentiality of your participation. The researchers are taking all required steps to protect your confidentiality, including storing all of your responses to questions in a secure, encrypted database separate from any information that can personally identify you. The only records containing your name and other personally identifying information are those stored in the system through which you signed up to participate in the study. These records will never be connected with the data we collect from you today. Research records will be kept confidential to the extent allowed by law and may be reviewed by the UCSD Institutional Review Board.\",\"parentNode\":{\"id\":87}},{\"nodeType\":3,\"id\":99,\"textContent\":\" Your participation in this study is completely voluntary and you can withdraw at any time by notifying the researcher that you wish to end your participation. Choosing not to participate or withdrawing will result in no penalty or loss of benefits to which you are entitled. You are free to skip any questions that you choose. If you have questions about this project or if you have a research-related problem, you may contact the researcher(s), Amy Fox: 919 886 4455: a2fox@ucsd.edu, and Jim Hollan: hollan@ucsd.edu. If you have any questions concerning your rights as a research subject, you may contact the UCSD Human Research Protections Program Office at 858-246-HRPP (858-246-4777). \",\"parentNode\":{\"id\":89}},{\"nodeType\":3,\"id\":100,\"textContent\":\" By clicking “I agree” below you are indicating that: you are at least 18 years old, have read this consent form, and agree to participate in this research study. If you do not wish to participate in the study, please notify the researcher now.\",\"parentNode\":{\"id\":91}},{\"nodeType\":3,\"id\":101,\"textContent\":\" \",\"parentNode\":{\"id\":95}},{\"nodeType\":1,\"id\":102,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"centered control control-checkbox\"},\"previousSibling\":{\"id\":101},\"parentNode\":{\"id\":95}},{\"nodeType\":3,\"id\":103,\"textContent\":\" \",\"previousSibling\":{\"id\":102},\"parentNode\":{\"id\":95}},{\"nodeType\":3,\"id\":104,\"textContent\":\" I agree to take part in this study. \",\"parentNode\":{\"id\":102}},{\"nodeType\":1,\"id\":105,\"tagName\":\"INPUT\",\"attributes\":{\"id\":\"consent_checkbox\",\"type\":\"checkbox\"},\"previousSibling\":{\"id\":104},\"parentNode\":{\"id\":102}},{\"nodeType\":3,\"id\":106,\"textContent\":\" \",\"previousSibling\":{\"id\":105},\"parentNode\":{\"id\":102}},{\"nodeType\":1,\"id\":107,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"},\"previousSibling\":{\"id\":106},\"parentNode\":{\"id\":102}},{\"nodeType\":3,\"id\":108,\"textContent\":\" \",\"previousSibling\":{\"id\":107},\"parentNode\":{\"id\":102}},{\"nodeType\":3,\"id\":109,\"textContent\":\" \",\"parentNode\":{\"id\":71}},{\"nodeType\":1,\"id\":110,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":109},\"parentNode\":{\"id\":71}},{\"nodeType\":3,\"id\":111,\"textContent\":\" \",\"previousSibling\":{\"id\":110},\"parentNode\":{\"id\":71}},{\"nodeType\":3,\"id\":112,\"textContent\":\"START\",\"parentNode\":{\"id\":110}}],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":60},{\"id\":63},{\"id\":64},{\"id\":74},{\"id\":75},{\"id\":77},{\"id\":78},{\"id\":80},{\"id\":79},{\"id\":76},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":81},{\"id\":82},{\"id\":84},{\"id\":85},{\"id\":97},{\"id\":86},{\"id\":87},{\"id\":98},{\"id\":88},{\"id\":89},{\"id\":99},{\"id\":90},{\"id\":91},{\"id\":100},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":101},{\"id\":102},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":103},{\"id\":96},{\"id\":83},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":109},{\"id\":110},{\"id\":112},{\"id\":111},{\"id\":72},{\"id\":73},{\"id\":61},{\"id\":62}],[],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":113,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":113},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":115,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":114},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":116,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":115},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":117,\"tagName\":\"P\",\"attributes\":{},\"parentNode\":{\"id\":113}},{\"nodeType\":3,\"id\":118,\"textContent\":\"Please enter the following information from your participant card\",\"parentNode\":{\"id\":117}},{\"nodeType\":1,\"id\":119,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":114}},{\"nodeType\":1,\"id\":120,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":119},\"parentNode\":{\"id\":114}},{\"nodeType\":3,\"id\":121,\"textContent\":\"Session code: \",\"parentNode\":{\"id\":119}},{\"nodeType\":1,\"id\":122,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":115}},{\"nodeType\":1,\"id\":123,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":122},\"parentNode\":{\"id\":115}},{\"nodeType\":3,\"id\":124,\"textContent\":\"Condition code: \",\"parentNode\":{\"id\":122}},{\"nodeType\":3,\"id\":125,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":116}}],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":113},{\"id\":117},{\"id\":118},{\"id\":114},{\"id\":119},{\"id\":121},{\"id\":120},{\"id\":115},{\"id\":122},{\"id\":124},{\"id\":123},{\"id\":116},{\"id\":125}],[],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":126,\"tagName\":\"SCRIPT\",\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":127,\"textContent\":\" \",\"previousSibling\":{\"id\":126},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":128,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"previousSibling\":{\"id\":127},\"parentNode\":{\"id\":55}},{\"nodeType\":8,\"id\":129,\"previousSibling\":{\"id\":128},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":130,\"textContent\":\" \",\"previousSibling\":{\"id\":129},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \\t//set text of scenario descriptions based on scenario randomization order in main switch(scenarios[0]) { case \\\"acme\\\": $('#da1').text(\\\"Answer 15 questions to help a manager coordinate a factory shift schedule.\\\"); break; } \",\"parentNode\":{\"id\":126}},{\"nodeType\":3,\"id\":132,\"textContent\":\" \",\"parentNode\":{\"id\":128}},{\"nodeType\":1,\"id\":133,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":132},\"parentNode\":{\"id\":128}},{\"nodeType\":8,\"id\":134,\"previousSibling\":{\"id\":133},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":135,\"textContent\":\" \",\"previousSibling\":{\"id\":134},\"parentNode\":{\"id\":128}},{\"nodeType\":1,\"id\":136,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":135},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":137,\"textContent\":\" \",\"previousSibling\":{\"id\":136},\"parentNode\":{\"id\":128}},{\"nodeType\":8,\"id\":138,\"previousSibling\":{\"id\":137},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \",\"previousSibling\":{\"id\":138},\"parentNode\":{\"id\":128}},{\"nodeType\":1,\"id\":140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":139},\"parentNode\":{\"id\":128}},{\"nodeType\":8,\"id\":141,\"previousSibling\":{\"id\":140},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":142,\"textContent\":\" \",\"previousSibling\":{\"id\":141},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":143,\"textContent\":\" \",\"parentNode\":{\"id\":133}},{\"nodeType\":1,\"id\":144,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":143},\"parentNode\":{\"id\":133}},{\"nodeType\":3,\"id\":145,\"textContent\":\" \",\"previousSibling\":{\"id\":144},\"parentNode\":{\"id\":133}},{\"nodeType\":3,\"id\":146,\"textContent\":\" \",\"parentNode\":{\"id\":144}},{\"nodeType\":1,\"id\":147,\"tagName\":\"H1\",\"attributes\":{},\"previousSibling\":{\"id\":146},\"parentNode\":{\"id\":144}},{\"nodeType\":3,\"id\":148,\"textContent\":\" \",\"previousSibling\":{\"id\":147},\"parentNode\":{\"id\":144}},{\"nodeType\":3,\"id\":149,\"textContent\":\"Instructions\",\"parentNode\":{\"id\":147}},{\"nodeType\":3,\"id\":150,\"textContent\":\" \",\"parentNode\":{\"id\":136}},{\"nodeType\":1,\"id\":151,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":150},\"parentNode\":{\"id\":136}},{\"nodeType\":3,\"id\":152,\"textContent\":\" \",\"previousSibling\":{\"id\":151},\"parentNode\":{\"id\":136}},{\"nodeType\":8,\"id\":153,\"previousSibling\":{\"id\":152},\"parentNode\":{\"id\":136}},{\"nodeType\":3,\"id\":154,\"textContent\":\" \",\"previousSibling\":{\"id\":153},\"parentNode\":{\"id\":136}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \",\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":156,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":155},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":157,\"tagName\":\"TABLE\",\"attributes\":{\"cellspacing\":\"0\",\"cellpadding\":\"0\",\"border\":\"0\",\"style\":\"display:block;\"},\"previousSibling\":{\"id\":156},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":158,\"textContent\":\" \",\"previousSibling\":{\"id\":157},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":159,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":158},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":160,\"textContent\":\" \",\"previousSibling\":{\"id\":159},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":161,\"tagName\":\"UL\",\"attributes\":{\"class\":\"fa-ul\"},\"previousSibling\":{\"id\":160},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":162,\"textContent\":\" \",\"previousSibling\":{\"id\":161},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":163,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":162},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":164,\"textContent\":\" \",\"previousSibling\":{\"id\":163},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":165,\"textContent\":\"We are interested in learning about how people make decisions about time. In this study, you are going to solve a series of problems about scheduling events. To help you solve the problems, we are going to give you a variety of graphs and diagrams. You are going to complete \",\"parentNode\":{\"id\":156}},{\"nodeType\":1,\"id\":166,\"tagName\":\"I\",\"attributes\":{},\"previousSibling\":{\"id\":165},\"parentNode\":{\"id\":156}},{\"nodeType\":3,\"id\":167,\"textContent\":\" of the activities on this computer. \",\"previousSibling\":{\"id\":166},\"parentNode\":{\"id\":156}},{\"nodeType\":3,\"id\":168,\"textContent\":\"all\",\"parentNode\":{\"id\":166}},{\"nodeType\":3,\"id\":169,\"textContent\":\" \",\"parentNode\":{\"id\":157}},{\"nodeType\":1,\"id\":170,\"tagName\":\"TBODY\",\"attributes\":{},\"previousSibling\":{\"id\":169},\"parentNode\":{\"id\":157}},{\"nodeType\":1,\"id\":171,\"tagName\":\"TR\",\"attributes\":{},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":172,\"textContent\":\" \",\"previousSibling\":{\"id\":171},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":173,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":172},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":174,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":173},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":175,\"tagName\":\"TR\",\"attributes\":{\"height\":\"15\"},\"previousSibling\":{\"id\":174},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":176,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":175},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":177,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":176},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":178,\"textContent\":\" \",\"previousSibling\":{\"id\":177},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":179,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":178},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":180,\"textContent\":\" \",\"previousSibling\":{\"id\":179},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":181,\"textContent\":\" \",\"parentNode\":{\"id\":171}},{\"nodeType\":1,\"id\":182,\"tagName\":\"TD\",\"attributes\":{\"width\":\"40\",\"rowspan\":\"2\"},\"previousSibling\":{\"id\":181},\"parentNode\":{\"id\":171}},{\"nodeType\":3,\"id\":183,\"textContent\":\" \",\"previousSibling\":{\"id\":182},\"parentNode\":{\"id\":171}},{\"nodeType\":1,\"id\":184,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":183},\"parentNode\":{\"id\":171}},{\"nodeType\":3,\"id\":185,\"textContent\":\" \",\"previousSibling\":{\"id\":184},\"parentNode\":{\"id\":171}},{\"nodeType\":1,\"id\":186,\"tagName\":\"A\",\"attributes\":{\"class\":\"fa fa-desktop fa-lg\"},\"parentNode\":{\"id\":182}},{\"nodeType\":3,\"id\":187,\"textContent\":\"Acme Factory [20 minutes]\",\"parentNode\":{\"id\":184}},{\"nodeType\":3,\"id\":188,\"textContent\":\" \",\"parentNode\":{\"id\":173}},{\"nodeType\":1,\"id\":189,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":188},\"parentNode\":{\"id\":173}},{\"nodeType\":3,\"id\":190,\"textContent\":\" \",\"previousSibling\":{\"id\":189},\"parentNode\":{\"id\":173}},{\"nodeType\":1,\"id\":191,\"tagName\":\"A\",\"attributes\":{\"id\":\"da1\",\"class\":\"subheading\"},\"parentNode\":{\"id\":189}},{\"nodeType\":3,\"id\":192,\"textContent\":\"Answer 15 questions to help a manager coordinate a factory shift schedule.\",\"parentNode\":{\"id\":191}},{\"nodeType\":3,\"id\":193,\"textContent\":\" \",\"parentNode\":{\"id\":177}},{\"nodeType\":1,\"id\":194,\"tagName\":\"TD\",\"attributes\":{\"rowspan\":\"2\"},\"previousSibling\":{\"id\":193},\"parentNode\":{\"id\":177}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \",\"previousSibling\":{\"id\":194},\"parentNode\":{\"id\":177}},{\"nodeType\":1,\"id\":196,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":195},\"parentNode\":{\"id\":177}},{\"nodeType\":3,\"id\":197,\"textContent\":\" \",\"previousSibling\":{\"id\":196},\"parentNode\":{\"id\":177}},{\"nodeType\":1,\"id\":198,\"tagName\":\"A\",\"attributes\":{\"class\":\"fa fa-desktop fa-lg\"},\"parentNode\":{\"id\":194}},{\"nodeType\":3,\"id\":199,\"textContent\":\"Final Survey [5 minutes]\",\"parentNode\":{\"id\":196}},{\"nodeType\":3,\"id\":200,\"textContent\":\" \",\"parentNode\":{\"id\":179}},{\"nodeType\":1,\"id\":201,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":200},\"parentNode\":{\"id\":179}},{\"nodeType\":3,\"id\":202,\"textContent\":\" \",\"previousSibling\":{\"id\":201},\"parentNode\":{\"id\":179}},{\"nodeType\":1,\"id\":203,\"tagName\":\"I\",\"attributes\":{},\"parentNode\":{\"id\":201}},{\"nodeType\":3,\"id\":204,\"textContent\":\"Complete a demographic survey and feedback on your experience.\",\"parentNode\":{\"id\":203}},{\"nodeType\":1,\"id\":205,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":159}},{\"nodeType\":3,\"id\":206,\"textContent\":\" \",\"previousSibling\":{\"id\":205},\"parentNode\":{\"id\":159}},{\"nodeType\":3,\"id\":207,\"textContent\":\"To ensure accurate results, please:\",\"parentNode\":{\"id\":205}},{\"nodeType\":3,\"id\":208,\"textContent\":\" \\t\",\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":209,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":208},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":210,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":209},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":211,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":210},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":212,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":211},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":212},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":214,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":213},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":215,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":214},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":216,\"textContent\":\" \",\"previousSibling\":{\"id\":215},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":217,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-check\",\"style\":\"color:green\"},\"parentNode\":{\"id\":209}},{\"nodeType\":3,\"id\":218,\"textContent\":\"DO read all instructions \",\"previousSibling\":{\"id\":217},\"parentNode\":{\"id\":209}},{\"nodeType\":1,\"id\":219,\"tagName\":\"I\",\"attributes\":{},\"previousSibling\":{\"id\":218},\"parentNode\":{\"id\":209}},{\"nodeType\":3,\"id\":220,\"textContent\":\" \",\"previousSibling\":{\"id\":219},\"parentNode\":{\"id\":209}},{\"nodeType\":3,\"id\":221,\"textContent\":\"carefully\",\"parentNode\":{\"id\":219}},{\"nodeType\":1,\"id\":222,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":211}},{\"nodeType\":3,\"id\":223,\"textContent\":\"DO NOT close this browser window\",\"previousSibling\":{\"id\":222},\"parentNode\":{\"id\":211}},{\"nodeType\":1,\"id\":224,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":213}},{\"nodeType\":3,\"id\":225,\"textContent\":\"DO NOT try to return to a previous page \",\"previousSibling\":{\"id\":224},\"parentNode\":{\"id\":213}},{\"nodeType\":1,\"id\":226,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":215}},{\"nodeType\":3,\"id\":227,\"textContent\":\"DO NOT use the back button on the mouse or web browser\",\"previousSibling\":{\"id\":226},\"parentNode\":{\"id\":215}},{\"nodeType\":3,\"id\":228,\"textContent\":\"If you have questions at any time, please raise your hand and the experimenter will assist you. \",\"parentNode\":{\"id\":163}},{\"nodeType\":3,\"id\":229,\"textContent\":\" \\t\",\"parentNode\":{\"id\":140}},{\"nodeType\":1,\"id\":230,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":229},\"parentNode\":{\"id\":140}},{\"nodeType\":3,\"id\":231,\"textContent\":\" \",\"previousSibling\":{\"id\":230},\"parentNode\":{\"id\":140}},{\"nodeType\":3,\"id\":232,\"textContent\":\"BEGIN\",\"parentNode\":{\"id\":230}}],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":126},{\"id\":131},{\"id\":127},{\"id\":128},{\"id\":132},{\"id\":133},{\"id\":143},{\"id\":144},{\"id\":146},{\"id\":147},{\"id\":149},{\"id\":148},{\"id\":145},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":150},{\"id\":151},{\"id\":155},{\"id\":156},{\"id\":165},{\"id\":166},{\"id\":168},{\"id\":167},{\"id\":157},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":181},{\"id\":182},{\"id\":186},{\"id\":183},{\"id\":184},{\"id\":187},{\"id\":185},{\"id\":172},{\"id\":173},{\"id\":188},{\"id\":189},{\"id\":191},{\"id\":192},{\"id\":190},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":193},{\"id\":194},{\"id\":198},{\"id\":195},{\"id\":196},{\"id\":199},{\"id\":197},{\"id\":178},{\"id\":179},{\"id\":200},{\"id\":201},{\"id\":203},{\"id\":204},{\"id\":202},{\"id\":180},{\"id\":158},{\"id\":159},{\"id\":205},{\"id\":207},{\"id\":206},{\"id\":160},{\"id\":161},{\"id\":208},{\"id\":209},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":221},{\"id\":220},{\"id\":210},{\"id\":211},{\"id\":222},{\"id\":223},{\"id\":212},{\"id\":213},{\"id\":224},{\"id\":225},{\"id\":214},{\"id\":215},{\"id\":226},{\"id\":227},{\"id\":216},{\"id\":162},{\"id\":163},{\"id\":228},{\"id\":164},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":229},{\"id\":230},{\"id\":232},{\"id\":231},{\"id\":141},{\"id\":142},{\"id\":129},{\"id\":130}],[],[],[]]}"
    },
    {
      "sequence": 8,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":233,\"tagName\":\"IMG\",\"attributes\":{\"src\":\"img/acme.png\",\"id\":\"jspsych-single-stim-stimulus\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":234,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":233},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":235,\"textContent\":\"Press enter to continue\",\"parentNode\":{\"id\":234}}],[],[]]}"
    },
    {
      "sequence": 9,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":233},{\"id\":234},{\"id\":235}],[],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":1,\"id\":59,\"tagName\":\"IMG\",\"attributes\":{\"src\":\"img/phone.png\",\"id\":\"jspsych-single-stim-stimulus\"}}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 176, dom: 943, initialDom: 947",
  "javascriptErrors": []
}