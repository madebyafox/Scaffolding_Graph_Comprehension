var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "ce949a7b240215792d57dd83aa4d1805",
  "created": "2018-05-21T09:15:43.8243113-07:00",
  "lastActivity": "2018-05-21T09:17:58.0875583-07:00",
  "pageViews": [
    {
      "id": "05214393f7f79c589517cf9500d0d8eedb7f21d7",
      "startTime": "2018-05-21T09:15:43.8243113-07:00",
      "endTime": "2018-05-21T09:17:58.0875583-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/16",
      "visitTime": 134282,
      "engagementTime": 90835,
      "scroll": 100.0,
      "tags": [
        "form-interact",
        "submit"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 134282,
  "engagementTime": 90835,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.33",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact",
    "submit"
  ],
  "variables": [
    "SID=9D6O3",
    "CONDITION=3"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "4bd2c0ec4c5ea2f797ce7e00045e2ac3",
  "gdpr": false
}